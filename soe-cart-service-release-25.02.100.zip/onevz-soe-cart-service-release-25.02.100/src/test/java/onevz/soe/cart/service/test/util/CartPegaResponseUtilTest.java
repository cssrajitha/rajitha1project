package onevz.soe.cart.service.test.util;

import onevz.soe.cart.initiatecart.CpcFeatureResponse;
import onevz.soe.cart.initiatecart.InitiateCartUIResponse;
import onevz.soe.cart.model.common.CartServiceCartInfo;
import onevz.soe.cart.requests.MoversUpdatePlanPegaResponse;
import onevz.soe.cart.requests.MoversUpdatePlanRequest;
import onevz.soe.cart.responses.AddFeaturesPEGAResponse;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.cart.util.CartPegaResponseUtil1;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.wsclient.bpm.model.response.Error;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import onevz.soe.cart.util.SourceFileReaderUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import onevz.soe.cart.model.AccessoryFinancingOffers.AccessoryFinancingOffersPegaResponse;
import onevz.soe.cart.model.addTrialContactInfoAndAddress.AddTrialContactInfoAndAddressUIResponse;
import onevz.soe.cart.model.affirmfinancing.AffirmFinancingPegaResponse;
import onevz.soe.cart.model.getCase.GetCaseResponse;
import onevz.soe.cart.model.initiateValidateDeviceSim.InitiateValidateDeviceSimUIResponse;
import onevz.soe.cart.requests.AddMoveDatesPegaResponse;
import onevz.soe.cart.responses.AccountPinPEGAResponse;
import onevz.soe.cart.responses.ActivateLaterPEGAResponse;
import onevz.soe.cart.responses.Add5GBulkOrderPEGAResponse;
import onevz.soe.cart.responses.AddAccessoriesPEGAResponse;
import onevz.soe.cart.responses.AddBuyoutPEGAResponse;
import onevz.soe.cart.responses.AddDevicePEGAResponse;
import onevz.soe.cart.responses.AddDownPaymentPEGAResponse;
import onevz.soe.cart.responses.AddNickNamePEGAResponse;
import onevz.soe.cart.responses.AddPlanAndDevicePEGAResponse;
import onevz.soe.cart.responses.AddPlanPEGAResponse;
import onevz.soe.cart.responses.AddReplenishmentToCartPEGAResponse;
import onevz.soe.cart.responses.AddTrialContactInfoAndAddressPEGAResponse;
import onevz.soe.cart.ui.requests.AddZipCodeUIRequest;
import onevz.soe.cart.responses.AddZipcodePEGAResponse;
import onevz.soe.cart.responses.AssignMtnPEGAResponse;
import onevz.soe.cart.responses.BbpGetProcessStepPEGAResponse;
import onevz.soe.cart.responses.BillingAddressPEGAResponse;
import onevz.soe.cart.responses.CancelCasePEGAResponse;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.CheckExistingCartPEGAResponse;
import onevz.soe.cart.responses.CreateCasePEGAResponse;
import onevz.soe.cart.responses.CreateLinePEGAResponse;
import onevz.soe.cart.responses.DeassignMtnPEGAResponse;
import onevz.soe.cart.responses.DeviceIdValidationPEGAResponse;
import onevz.soe.cart.responses.E911AddressPEGAResponse;
import onevz.soe.cart.responses.EffectiveDateOverridePEGAResponse;
import onevz.soe.cart.responses.EffectiveDatePEGAResponse;
import onevz.soe.cart.responses.GetCasePEGAResponse;
import onevz.soe.cart.responses.GuestChoicePEGAResponse;
import onevz.soe.cart.responses.InitiateCheckoutPEGAResponse;
import onevz.soe.cart.responses.InitiateValidateDeviceSimPEGAResponse;
import onevz.soe.cart.responses.InstantCreditDownPaymentPEGAResponse;
import onevz.soe.cart.responses.IspuToDfillPEGAResponse;
import onevz.soe.cart.responses.ManualDiscountPEGAResponse;
import onevz.soe.cart.responses.ManualPairingPEGAResponse;
import onevz.soe.cart.responses.NumberSharePEGAResponse;
import onevz.soe.cart.responses.PastDuesPEGAResponse;
import onevz.soe.cart.responses.PortinLaterPEGAResponse;
import onevz.soe.cart.responses.RemoveLinesPEGAResponse;
import onevz.soe.cart.responses.RemoveLockPEGAResponse;
import onevz.soe.cart.responses.ResumeAndContinuePegaResponse;
import onevz.soe.cart.responses.RetrieveActivationStatusPEGAResponse;
import onevz.soe.cart.responses.RevokeRebatesPEGAResponse;
import onevz.soe.cart.responses.SalesOrderAdjustmentPEGAResponse;
import onevz.soe.cart.responses.SalesRepAndLocationCodePEGAResponse;
import onevz.soe.cart.responses.SaveCartPEGAResponse;
import onevz.soe.cart.responses.ServiceAddressPEGAResponse;
import onevz.soe.cart.responses.SplitExceededAmountPEGAResponse;
import onevz.soe.cart.responses.UpdateAddressChangePEGAResponse;
import onevz.soe.cart.responses.UpdateBarCodePEGAResponse;
import onevz.soe.cart.responses.UpdateBvoOffersPEGAResponse;
import onevz.soe.cart.responses.UpdateChatIdPEGAResponse;
import onevz.soe.cart.responses.UpdateDeviceSIMIdPEGAResponse;
import onevz.soe.cart.responses.UpdateEdgeupPEGAResponse;
import onevz.soe.cart.responses.UpdateGiftItemPEGAResponse;
import onevz.soe.cart.responses.UpdateSellerPricePEGAResponse;
import onevz.soe.cart.responses.UpdateTransferUpgradePEGAResponse;
import onevz.soe.cart.responses.UpdateWFMInfoPEGAResponse;
import onevz.soe.cart.responses.VoidOrderPEGAResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.tys.reviewOrder.ReviewOrderPegaResponse;
import onevz.soe.cart.ui.common.CartInfo;
import onevz.soe.cart.ui.requests.Add5GBulkOrderUIRequest;
import onevz.soe.cart.ui.requests.AddAccessoriesUIRequest;
import onevz.soe.cart.ui.requests.AddDeviceUIRequest;
import onevz.soe.cart.ui.requests.AddReplenishmentToCartUIRequest;
import onevz.soe.cart.ui.requests.AssignMtnUIRequest;
import onevz.soe.cart.ui.requests.CancelCaseUIRequest;
import onevz.soe.cart.ui.requests.CreateLineUIRequest;
import onevz.soe.cart.ui.requests.DeassignMtnUIRequest;
import onevz.soe.cart.ui.requests.DownPaymentUIRequest;
import onevz.soe.cart.ui.requests.E911AddressUIRequest;
import onevz.soe.cart.ui.requests.EffectiveDateOverrideUIRequest;
import onevz.soe.cart.ui.requests.InstantCreditDownPaymentUIRequest;
import onevz.soe.cart.ui.requests.IspuToDfillUIRequest;
import onevz.soe.cart.ui.requests.NumberShareUIRequest;
import onevz.soe.cart.ui.requests.PastDuesUIRequest;
import onevz.soe.cart.ui.requests.PortinLaterUIRequest;
import onevz.soe.cart.ui.requests.RemoveLinesUIRequest;
import onevz.soe.cart.ui.requests.ReviewOrderTYSUIRequest;
import onevz.soe.cart.ui.requests.RevokeRebatesUIRequest;
import onevz.soe.cart.ui.requests.SalesRepAndLocationCodeUIRequest;
import onevz.soe.cart.ui.requests.UpdateBarcodeUIRequest;
import onevz.soe.cart.ui.requests.UpdateDeviceSIMIdUIRequest;
import onevz.soe.cart.ui.requests.UpdateGiftItemUIResponse;
import onevz.soe.cart.ui.requests.UpdateManualDiscountUIRequest;
import onevz.soe.cart.ui.requests.UpdateSellerPriceUIRequestNew;
import onevz.soe.cart.ui.requests.UpdateTransferUpgradeUIRequest;
import onevz.soe.cart.ui.requests.UpdateWFMInfoUIRequest;
import onevz.soe.cart.ui.requests.VoidOrderUIRequest;
import onevz.soe.cart.util.CartPegaResponseUtil;
import onevz.soe.wsclient.bpm.model.ServiceHeader;
import onevz.soe.wsclient.bpm.model.response.ServiceResponse;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;
import onevz.soe.cart.responses.ClearAndContinuePegaResponse;
import onevz.soe.cart.responses.ClearCartPEGAResponse;
import onevz.soe.cart.ui.responses.ClearAndContinueUIResponse;

import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(CartPegaResponseUtil.class)
public class CartPegaResponseUtilTest {

	@Autowired
	private ObjectMapper mapper;
	
	@MockBean
	CartPegaResponseUtil util;

	@MockBean
	CartPegaResponseUtil1 util1;
	
	@Value("${onevz.soe.cart.test.fileLocation}")
    private String testFileLocation;
	
	 @Autowired
	 SourceFileReaderUtil sourceFileReaderUtil;
	
	@Test
	public void formatUpdateAddressChangeUiResponseTest() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\": {}, \"errors\": [{}]}";
		RPSE911AddressUpdateUIResponse soeResponse = new RPSE911AddressUpdateUIResponse();
		UpdateAddressChangePEGAResponse pegaResponse = mapper.readValue(pegaResponseString, UpdateAddressChangePEGAResponse.class);
		util1.formatUpdateAddressChangeUiResponse(pegaResponse, soeResponse);
	}
	
	@Test
	public void formatUpdateAddressChangeUiResponseTest2() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\": null, \"errors\": []}";
		RPSE911AddressUpdateUIResponse soeResponse = new RPSE911AddressUpdateUIResponse();
		UpdateAddressChangePEGAResponse pegaResponse = mapper.readValue(pegaResponseString, UpdateAddressChangePEGAResponse.class);
		util1.formatUpdateAddressChangeUiResponse(pegaResponse, soeResponse);
	}
	
	@Test
	public void formatUpdateAddressChangeUiResponseTest3() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\": {}, \"errors\": null}";
		RPSE911AddressUpdateUIResponse soeResponse = new RPSE911AddressUpdateUIResponse();
		UpdateAddressChangePEGAResponse pegaResponse = mapper.readValue(pegaResponseString, UpdateAddressChangePEGAResponse.class);
		util1.formatUpdateAddressChangeUiResponse(pegaResponse, soeResponse);
	}
	
	@Test
	public void formatUpdateAddressChangeUiResponseTest4() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\": {}, \"errors\": [{}]}";
		RPSE911AddressUpdateUIResponse soeResponse = new RPSE911AddressUpdateUIResponse();
		UpdateAddressChangePEGAResponse pegaResponse = null;
		util1.formatUpdateAddressChangeUiResponse(pegaResponse, soeResponse);
	}
	
	
	@Test
	public void formatAddReplenishmentResponseTest() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"errors\":[{\"namespace\":\"CXP_Pega_BPM\",\"name\":\"Provided Case Id is resolved or Invalid.\",\"id\":\"1008\",\"debug_id\":\"20220920T052555.145 GMT||pega-010adfc9-5170-4da9-b381-0f7da3573a30-09192022-102555-140|soe-cart-2022.09.20.10.54.43-862.9557849437155\",\"message\":\"Invalid Case Id\",\"severity\":\"High\",\"errorCategory\":\"UNKNW\",\"details\":[{\"field\":\"Case ID\",\"value\":\"SOF-8624507-C01\",\"issue\":\"Either CaseID provided resolved or Invalid.\",\"location\":\"context\",\"lockedChannelID\":\"\"}]}]}";
		AddReplenishmentToCartUIResponse soeResponse = new AddReplenishmentToCartUIResponse();
		AddReplenishmentToCartUIRequest uiRequest=new AddReplenishmentToCartUIRequest();
		AddReplenishmentToCartPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, AddReplenishmentToCartPEGAResponse.class);
		util.formatAddReplenishmentResponse(pegaResponse, soeResponse, uiRequest);
	}
	
	@Test
	public void formatAddReplenishmentResponseTest2() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-TELESALES\",\"statusMsg\":\"SUCCESS\",\"correlationId\":\"\",\"serviceName\":\"SalesOrderFlex\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"cartInfo\":{\"cartId\":\"d2d21206-d2e8-476e-9a0f-0f85a513ed8c\",\"statusCode\":1,\"statusMsg\":\"Replenishment Amount added successfully to cart\",\"addedReplenishmentAmt\":10.0,\"cartItemPrice\":60.0},\"contextInfo\":{\"availablePaths\":[{\"path\":\"LandingScreen\"}],\"processAction\":\"\",\"processStep\":\"LandingScreen\",\"callReason\":\"SalesOrderFlex\"},\"caseId\":\"SOF-8703675-E01\",\"customerInfo\":{\"cartCreator\":\"9142996416\",\"processingMTN\":\"newLine1\",\"accountNumber\":\"0385770139-00001\"},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\",\"AddReplenishment\"]}]}}}}";
		AddReplenishmentToCartUIResponse soeResponse = new AddReplenishmentToCartUIResponse();
		AddReplenishmentToCartUIRequest uiRequest=new AddReplenishmentToCartUIRequest();
		AddReplenishmentToCartPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, AddReplenishmentToCartPEGAResponse.class);
		util.formatAddReplenishmentResponse(pegaResponse, soeResponse, uiRequest);
	}
	@Test
	public void formatMoveDatesResponseTest() throws JsonMappingException, JsonProcessingException {
		AddMoveDatesUIResponse soeResponse=new AddMoveDatesUIResponse();
		String pegaResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"correlationId\":\"\",\"serviceName\":\"SalesOrderFlex\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"cartInfo\":{\"cartId\":\"d2d21206-d2e8-476e-9a0f-0f85a513ed8c\",\"statusCode\":1,\"statusMsg\":\"Replenishment Amount added successfully to cart\",\"addedReplenishmentAmt\":10.0,\"cartItemPrice\":60.0},\"contextInfo\":{\"availablePaths\":[{\"path\":\"LandingScreen\"}],\"processAction\":\"\",\"processStep\":\"LandingScreen\",\"callReason\":\"SalesOrderFlex\"},\"caseId\":\"SOF-8703675-E01\",\"customerInfo\":{\"cartCreator\":\"9142996416\",\"processingMTN\":\"newLine1\",\"accountNumber\":\"0385770139-00001\"},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\",\"AddReplenishment\"]}]}}}}";
		AddMoveDatesPegaResponse PegaResponse=mapper.readValue(pegaResponseString,AddMoveDatesPegaResponse.class);
		util1.formatMoveDatesResponse(soeResponse, PegaResponse);

	}
	@Test
	public void formatSaveCartResponseTest() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString ="{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-514162-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"GridWallPDP\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addBuyOutAmt\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"0100007530-00001\",\"cartCreator\":\"4125102507\"},\"cartInfo\":{\"cartId\":\"8ab56dcb-4268-4ea8-99f2-99955effe2cd\",\"statusCode\":\"0\",\"statusMsg\":\"Success\"}}}}}";
		SaveCartUIResponse uiResponse = new SaveCartUIResponse();
		SaveCartPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, SaveCartPEGAResponse.class);
		Assert.assertNull(pegaResponse.getErrors());;
		Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util.formatSaveCartResponse(uiResponse,pegaResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util.formatSaveCartResponse(uiResponse,pegaResponse);
		Assert.assertNotNull(pegaResponse);
		
	}
	
	@Test
	public void formatSaveCartResponseTest1() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString ="{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-514162-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"GridWallPDP\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addBuyOutAmt\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"0100007530-00001\",\"cartCreator\":\"4125102507\"},\"cartInfo\":null}}}}";
		String sampleRequestString = "{\"serviceHeader\":null,\"serviceBody\": {\"serviceResponse\": {}}}";
		SaveCartUIResponse uiResponse = mapper.readValue(sampleRequestString, SaveCartUIResponse.class);
		SaveCartPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, SaveCartPEGAResponse.class);
		util.formatSaveCartResponse(uiResponse,pegaResponse);
	}

	@Test
	public void formatAddFeaturesResponseTest() throws JsonProcessingException {
		String pegaResponse ="{\n" +
				"    \"errorData\": {\n" +
				"        \"lines\": [\n" +
				"            {\n" +
				"                \"mtn\": \"9452510149\",\n" +
				"                \"anySpoOrSfoChangeIndicator\": \"E\",\n" +
				"                \"planValidationFailed\": \"true\",\n" +
				"                \"fomSFOActivity\": {\n" +
				"                    \"fomActionSFO1\": \"89412\",\n" +
				"                    \"fomReasonCodeDescription\": \"FOM Error on this line\",\n" +
				"                    \"fomActionSFO1Desc\": \"MOBILE HOT SPOT TRIGGER $0\",\n" +
				"                    \"fomActionReasonCode\": \"P\",\n" +
				"                    \"fomActionFeature1\": \"0\",\n" +
				"                    \"fomActionSFO2\": \"77249\"\n" +
				"                }\n" +
				"            }\n" +
				"        ],\n" +
				"        \"statusCode\": \"0\"\n" +
				"    },\n" +
				"    \"errors\": [\n" +
				"        {\n" +
				"            \"id\": \"3000\",\n" +
				"            \"message\": \"Validate plan domain service returned indicator 'E' for AnySpoOrSfoChangeIndicator\",\n" +
				"            \"debug_id\": \"2023-10-13T09:16:04.+0000:c8e809915d3ca367:cxp-shopping-services-8684bd9b66-xvgxf:kubernetes\",\n" +
				"            \"name\": \"VALIDATION_ERROR\"\n" +
				"        }\n" +
				"    ]\n" +
				"}";
		AddFeaturesUIResponse uiResponse = new AddFeaturesUIResponse();

		AddFeaturesPEGAResponse pegaResponse1  = mapper.readValue(pegaResponse, AddFeaturesPEGAResponse.class);
		util.formatAddFeaturesResponse(uiResponse,pegaResponse1 );
		

	}

	@Test
	public void formatSaveCartResponseTest2() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString ="{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-514162-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"GridWallPDP\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addBuyOutAmt\"},\"customerInfo\":null,\"cartInfo\":null}}}}";
		String sampleRequestString = "{\"serviceHeader\":null,\"serviceBody\": {\"serviceResponse\": {}}}";
		SaveCartUIResponse uiResponse = mapper.readValue(sampleRequestString, SaveCartUIResponse.class);
		SaveCartPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, SaveCartPEGAResponse.class);
		util.formatSaveCartResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatSaveCartResponseTest3() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString ="{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-514162-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"GridWallPDP\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addBuyOutAmt\"},\"customerInfo\":{\"customerType\":null,\"accountNumber\":\"0100007530-00001\",\"cartCreator\":\"4125102507\"},\"cartInfo\":null}}}}";
		String sampleRequestString = "{\"serviceHeader\":null,\"serviceBody\": {\"serviceResponse\": {}}}";
		SaveCartUIResponse uiResponse = mapper.readValue(sampleRequestString, SaveCartUIResponse.class);
		SaveCartPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, SaveCartPEGAResponse.class);
		util.formatSaveCartResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatSaveCartResponseTest4() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString ="{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-514162-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"GridWallPDP\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addBuyOutAmt\"},\"customerInfo\":{\"customerType\":\"Y\",\"accountNumber\":\"0100007530-00001\",\"cartCreator\":\"4125102507\"},\"cartInfo\":null}}}}";
		String sampleRequestString = "{\"serviceHeader\":null,\"serviceBody\": {\"serviceResponse\": {}}}";
		SaveCartUIResponse uiResponse = mapper.readValue(sampleRequestString, SaveCartUIResponse.class);
		SaveCartPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, SaveCartPEGAResponse.class);
		util.formatSaveCartResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatSaveCartResponseTest5() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString ="{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":null,\"customerInfo\":{\"customerType\":\"Y\",\"accountNumber\":\"0100007530-00001\",\"cartCreator\":\"4125102507\"},\"cartInfo\":null}}}}";
		String sampleRequestString = "{\"serviceHeader\":null,\"serviceBody\": {\"serviceResponse\": {}}}";
		SaveCartUIResponse uiResponse = mapper.readValue(sampleRequestString, SaveCartUIResponse.class);
		SaveCartPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, SaveCartPEGAResponse.class);
		util.formatSaveCartResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatSaveCartResponseTest6() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString ="{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":null}}";
		String sampleRequestString = "{\"serviceHeader\":null,\"serviceBody\": {\"serviceResponse\": {}}}";
		SaveCartUIResponse uiResponse = mapper.readValue(sampleRequestString, SaveCartUIResponse.class);
		SaveCartPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, SaveCartPEGAResponse.class);
		util.formatSaveCartResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatUpdateBarCodeResponseTest() throws JsonMappingException, JsonProcessingException {
		 String responseString = "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \" SOP-1583186-DEV3\",\"customerInfo\": {\"accountNumber\": \"07893451230-00001\",\"cartCreator\": \"2515813861\",\"processingMTN\": \"2515813860\"},\"processMTNList\": [{\"mtn\": \"2515813860\",\"completedprocessSteps\": [\"MTNSelectionPage\",\"GridWallPDP\"]},{\"mtn\": \"2515813861\",\"completedprocessSteps\": []}],\"cartInfo\": {\"cartId\": \"8c5fa64a-9811-4eb8-85cd-b5939cae298b\",\"statusCode\": \"1\",\"statusMsg\": \"Barcode validated successfully\",\"lines\": [{\"mtn\": \"3014674968\",\"status\": 1,\"errors\": null}]},\"contextInfo\": {\"processAction\": \"\",\"processStep\": \"ShoppingCart\"}}}}}";
		 UpdateBarcodeUIResponse response = mapper.readValue(responseString, UpdateBarcodeUIResponse.class);
		 String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"MOTRN1\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-277-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"\",\"processAction\":\"\"},\"cartInfo\":{\"cartId\":\"69a66ef4d-7e344dfb-2db299209-ea8333\"},\"customerInfo\":{\"accountNumber\":\"0220335087-00001\",\"cartCreator\":\"8643804638\",\"processingMTN\":\"8643804638\"},\"processMTNList\":[{\"mtn\":\"8643804638\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\"]}],\"removeItem\":{\"lines\":[{\"mtn\":\"2564409659\",\"lineId\":\"null\",\"status\":1}]}}}}}";
		 UpdateBarCodePEGAResponse pegaResponse = null;
		 pegaResponse = mapper.readValue(sampleResponseString, UpdateBarCodePEGAResponse.class);
		 Error error =new Error();
		 error.setMessage("abc type error");
		 List<Error> list = new ArrayList<>();
		 list.add(error);
		 pegaResponse.setErrors(list);
		 util1.formatUpdateBarCodeResponse(response,pegaResponse);
		 Assert.assertNotNull(pegaResponse);
		 pegaResponse.setServiceBody(null);
		 pegaResponse.setServiceHeader(null);
		 pegaResponse.setErrors(null);
		 util1.formatUpdateBarCodeResponse(response,pegaResponse);
		 Assert.assertNotNull(pegaResponse);
		
	}
	
	@Test
	public void formatUpdateBarCodeResponseTest1() throws JsonMappingException, JsonProcessingException {
		String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"MOTRN1\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-277-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"\",\"processAction\":\"\"},\"cartInfo\":{\"cartId\":\"69a66ef4d-7e344dfb-2db299209-ea8333\"},\"customerInfo\":{\"accountNumber\":\"0220335087-00001\",\"cartCreator\":\"8643804638\",\"processingMTN\":\"8643804638\"},\"processMTNList\":[{\"mtn\":\"8643804638\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\"]}],\"removeItem\":{\"lines\":[{\"mtn\":\"2564409659\",\"lineId\":\"null\",\"status\":1}]}}}}}";
		UpdateBarcodeUIResponse uiResponse = new UpdateBarcodeUIResponse();
		UpdateBarCodePEGAResponse pegaResponse = mapper.readValue(sampleResponseString, UpdateBarCodePEGAResponse.class);
		util1.formatUpdateBarCodeResponse(uiResponse,pegaResponse);
		
	}
	
	@Test
	public void formatUpdateBarCodeResponseTest2() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"errors\":[{\"message\":\"Error while processing. Try again later\",\"debug_id\":\"1004\",\"name\":\"System Error\"}],\"serviceHeader\":null,\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-277-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"\",\"processAction\":\"\"},\"cartInfo\":{\"cartId\":\"69a66ef4d-7e344dfb-2db299209-ea8333\"},\"customerInfo\":{\"accountNumber\":\"0220335087-00001\",\"cartCreator\":\"8643804638\",\"processingMTN\":\"8643804638\"},\"processMTNList\":[{\"mtn\":\"8643804638\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\"]}],\"removeItem\":{\"lines\":[{\"mtn\":\"2564409659\",\"lineId\":\"null\",\"status\":1}]}}}}}";
		UpdateBarcodeUIResponse uiResponse = new UpdateBarcodeUIResponse();
		UpdateBarCodePEGAResponse pegaResponse = mapper.readValue(pegaResponseString, UpdateBarCodePEGAResponse.class);
		util1.formatUpdateBarCodeResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatDeviceIdValidationResponseTest() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"deviceInfo\":{\"deviceId\":\"1234\"}}}}}";
		DeviceIdValidationUIResponse  uiResponse = new DeviceIdValidationUIResponse ();
		DeviceIdValidationPEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, DeviceIdValidationPEGAResponse .class);
		Error error =new Error();
		 error.setMessage("abc type error");
		 List<Error> list = new ArrayList<>();
		 list.add(error);
		 pegaResponse.setErrors(list);
		 util1.formatDeviceIdValidationResponse(pegaResponse,uiResponse);
		 Assert.assertNotNull(pegaResponse);
		 pegaResponse.setServiceBody(null);
		 pegaResponse.setServiceHeader(null);
		 pegaResponse.setErrors(null);
		 util1.formatDeviceIdValidationResponse(pegaResponse,uiResponse);
		 Assert.assertNotNull(pegaResponse);
		
	}
	
	@Test
	public void formatUpdateEdgeUpResponseTest() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-NETACE\", \"statusMsg\": \"PEGA generated message\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"sessionId\": \"\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\",\"statusCode\": \"0\"}, \"serviceBody\": {\"serviceResponse\": {\"context\":null,\"CartInfo\": {\"cartId\":\"bea202a6-42cb-40d4-ac87-d3f1db2b3f13\",\"statusCode\": 1,\"statusMsg\": \"Edge Up cancelled successfully.\"},\"contextInfo\": {\"processAction\": \"\", \"callReason\": \"SalesOrderPurchase\",\"processStep\": \"MTNSelectionPage\",\"availablePaths\":[{\"path\":\"MTNSelectionPage\"}]}}}}}";
		UpdateEdgeupUIResponse  uiResponse = new UpdateEdgeupUIResponse();
		UpdateEdgeupPEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, UpdateEdgeupPEGAResponse .class);
		Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util.formatUpdateEdgeUpResponse(uiResponse,pegaResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util.formatUpdateEdgeUpResponse(uiResponse,pegaResponse);
		Assert.assertNotNull(pegaResponse);
	}
	
	@Test
	public void formatAddBuyoutResponseTest() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"PEGA generated message\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"exceptions\":[{\"system\":\"CXP\",\"service\":\"validateCart\",\"type\":\"Error\",\"code\":\"E1223\",\"message\":\"Account validation failed\"},{\"system\":\"CXP\",\"service\":\"addToCartService\",\"type\":\"Warning\",\"code\":\"E1223\",\"message\":\"Account validation failed\"}],\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\" SOP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"processMTNList\":[{\"mtn\":\"2515813860\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"BuyOut\"]},{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}],\"cartInfo\":null,\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"GridWallPDP\",\"availablePaths\":[{\"path\":\" GridWallPDP `\"}],\"callReason\":\" SalesOrderPurchase \"}}}}}";
		AddBuyoutUIResponse uiResponse = new AddBuyoutUIResponse();
		AddBuyoutPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, AddBuyoutPEGAResponse.class);
		Assert.assertNull(pegaResponse.getErrors());
		Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util.formatAddBuyoutResponse(uiResponse,pegaResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util.formatAddBuyoutResponse(uiResponse,pegaResponse);
		Assert.assertNotNull(pegaResponse);
		
	}
	
	@Test
	public void formatAddBuyoutResponseTest1() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"PEGA generated message\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"exceptions\":[{\"system\":\"CXP\",\"service\":\"validateCart\",\"type\":\"Error\",\"code\":\"E1223\",\"message\":\"Account validation failed\"},{\"system\":\"CXP\",\"service\":\"addToCartService\",\"type\":\"Warning\",\"code\":\"E1223\",\"message\":\"Account validation failed\"}],\"serviceBody\":{\"serviceResponse\":{\"context\":null,\"cartInfo\":null,\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"GridWallPDP\",\"availablePaths\":[{\"path\":\" GridWallPDP `\"}],\"callReason\":\" SalesOrderPurchase \"}}}}}";
		AddBuyoutUIResponse uiResponse = new AddBuyoutUIResponse();
		AddBuyoutPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, AddBuyoutPEGAResponse.class);
		util.formatAddBuyoutResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatInitiateCheckoutResponseTest() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
		InitiateCheckoutUIResponse uiResponse = new InitiateCheckoutUIResponse();
		InitiateCheckoutPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, InitiateCheckoutPEGAResponse.class);
		util.formatInitiateCheckoutResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatInitiateCheckoutResponseTest1() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"errors\":null,\"serviceHeader\": {},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"cartInfo\": {},\"validateOrder\": {\"readyForOrderSubmit\": true}}}}}";
		InitiateCheckoutUIResponse uiResponse = new InitiateCheckoutUIResponse();
		InitiateCheckoutPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, InitiateCheckoutPEGAResponse.class);
		util.formatInitiateCheckoutResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatResumeAndContinueResponseTest() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"errors\":null, \"serviceHeader\": { \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\", \"correlationId\": \"soe-cart-2021.10.10.17.03.54-730.0257111089085\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \"SOP-302710488-W01\", \"contextInfo\": { \"availablePaths\": [{ \"path\": \"PromoHub\" }], \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"AccessoryInterestial\", \"processAction\": \"\" }, \"customerInfo\": { \"accountNumber\": \"0270012394-00001\", \"cartCreator\": \"5106852800\", \"processingMTN\": \"\", \"registerNumber\": 0, \"number_share_capable\": \"\", \"e911_addr_ind\": \"false\", \"existingCase\": \"\" }, \"cartInfo\": { \"financeLimitExceeded\": \"false\", \"cartItemCount\": 1, \"cartId\": \"3e57c2cd-efb7-41cb-87cf-edf2b6e52a67\", \"statusMsg\": \"Success\", \"statusCode\": \"1\", \"lines\": [{ \"status\": 1, \"firstMonthInstallment\": 43.42, \"monthlyInstallment\": 43.33, \"reasonCode\": \"PLAN_DEVICE_COMPATIBLE\", \"selectedPromoType\": \"TRADEIN_PROMO\", \"mtn\": \"newLine1\", \"device\": { \"upgradeReasonCode\": \"\", \"id\": \"MLRE3LL/A\", \"installmentTerm\": \"0\", \"itemPrice\": \"1299.99\", \"finalPrice\": \"0.0\", \"discountAmount\": \"0.0\", \"qty\": 1, \"edgeUpEnabled\": false, \"numberShareEnabled\": false, \"existingDeviceName\": \"iPhone 13 Pro\", \"fiveGToFourGDownGrade\": false, \"byodESimPhone\": false }, \"sim\": { \"id\": \"EMBDSIM5G\" }, \"warranty\": { \"itemPrice\": \"0.0\" }, \"devicePlanCompatible\": false, \"planValidationFailed\": false, \"lineActivityType\": \"AAL\", \"currentPlanType\": \"LLP\", \"planQualifiedForPromotion\": false, \"fiveGUpSell\": false, \"is5GBoltEligible\": false, \"fiveGPlanAdded\": false, \"editSim\": false, \"lineWithSkipMDN\": false, \"inWithVerizonOpted\": false, \"protectionNotRequired\": false }], \"expressCheckout\": false, \"effectiveDateDetails\": { \"suggestedBackDate\": \"\", \"suggestedFutureDate\": \"\", \"currentBillCycleBeginDate\": \"\", \"nextBillCycleBeginDate\": \"\", \"onDemandDate\": \"\", \"onDemandRangeInDays\": \"\", \"selectedDate\": \"10/10/2021\" }, \"preAuthSuccess\": false, \"promoLossIndicator\": false, \"monthlyCreditAmount\": \"0.0\", \"agreementNumber\": \"0\", \"vztDiscountGain\": false, \"vztDiscountLoss\": false, \"discountPromoTotal\": 0.0, \"registerNumber\": 0, \"hasMixAndMatchPlan\": true, \"oneBillEnrolled\": false, \"protectionNotRequired\": false }, \"processMTNList\": [{ \"mtn\": \"\", \"completedprocessSteps\": [\"TradeInHomePage\", \"Initiate\", \"MTNSelectionPage\", \"GridWallPDP\", \"MTNSelectionPage\", \"GridWallPDP\"] }] } } } }";
		ResumeAndContinueUIResponse uiResponse = new ResumeAndContinueUIResponse();
		ResumeAndContinuePegaResponse pegaResponse = mapper.readValue(pegaResponseString, ResumeAndContinuePegaResponse.class);
		Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util.formatResumeAndContinueResponse(uiResponse,pegaResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util.formatResumeAndContinueResponse(uiResponse,pegaResponse);
		Assert.assertNotNull(pegaResponse);
	}
	
	@Test
	public void formatServiceAddressResponseTest() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-543157-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"showDevices\"},{\"path\":\"showAccessory\"},{\"path\":\"TradeIn\"},{\"path\":\"showFeatures\"},{\"path\":\"addDevice\"}]},\"customerInfo\":{\"customerType\":\"N\",\"registerNumber\":0,\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"cartInfo\":{\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\"},\"processMTNList\":[{\"mtn\":\"4235344191\",\"completedprocessSteps\":[\"\"]}]}}}}";
		ServiceAddressUIResponse uiResponse = new ServiceAddressUIResponse();
		ServiceAddressPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, ServiceAddressPEGAResponse.class);
		Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util.formatServiceAddressResponse(uiResponse,pegaResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util.formatServiceAddressResponse(uiResponse,pegaResponse);
		Assert.assertNotNull(pegaResponse);
		
	}
	
	@Test
	public void formatServiceAddressResponseTest1() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-543157-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"showDevices\"},{\"path\":\"showAccessory\"},{\"path\":\"TradeIn\"},{\"path\":\"showFeatures\"},{\"path\":\"addDevice\"}]},\"customerInfo\":{\"customerType\":\"N\",\"registerNumber\":0,\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"cartInfo\":null,\"processMTNList\":[{\"mtn\":\"4235344191\",\"completedprocessSteps\":[\"\"]}]}}}}";
		ServiceAddressUIResponse uiResponse = new ServiceAddressUIResponse();
		ServiceAddressPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, ServiceAddressPEGAResponse.class);
		util.formatServiceAddressResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatServiceAddressResponseTest2() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-543157-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"showDevices\"},{\"path\":\"showAccessory\"},{\"path\":\"TradeIn\"},{\"path\":\"showFeatures\"},{\"path\":\"addDevice\"}]},\"customerInfo\":{\"customerType\":\"Y\",\"registerNumber\":0,\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"cartInfo\":null,\"processMTNList\":[{\"mtn\":\"4235344191\",\"completedprocessSteps\":[\"\"]}]}}}}";
		ServiceAddressUIResponse uiResponse = new ServiceAddressUIResponse();
		ServiceAddressPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, ServiceAddressPEGAResponse.class);
		util.formatServiceAddressResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatServiceAddressResponseTest3() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-543157-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"showDevices\"},{\"path\":\"showAccessory\"},{\"path\":\"TradeIn\"},{\"path\":\"showFeatures\"},{\"path\":\"addDevice\"}]},\"customerInfo\":null,\"cartInfo\":null,\"processMTNList\":[{\"mtn\":\"4235344191\",\"completedprocessSteps\":[\"\"]}]}}}}";
		ServiceAddressUIResponse uiResponse = new ServiceAddressUIResponse();
		ServiceAddressPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, ServiceAddressPEGAResponse.class);
		util.formatServiceAddressResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatServiceAddressResponseTest4() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":null,\"customerInfo\":null,\"cartInfo\":null,\"processMTNList\":[{\"mtn\":\"4235344191\",\"completedprocessSteps\":[\"\"]}]}}}}";
		ServiceAddressUIResponse uiResponse = new ServiceAddressUIResponse();
		ServiceAddressPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, ServiceAddressPEGAResponse.class);
		util.formatServiceAddressResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatServiceAddressResponseTest5() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":null}}";
		ServiceAddressUIResponse uiResponse = new ServiceAddressUIResponse();
		ServiceAddressPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, ServiceAddressPEGAResponse.class);
		util.formatServiceAddressResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatBillingAddressResponseTest() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-DOTCOM-MOB\", \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\", \"correlationId\": \"soe-cart-2021.10.10.20.03.28-592.6550588551962\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"contextInfo\": { \"availablePaths\": [{ \"path\": \"updateServiceAddress\" }], \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"OrderReview\", \"processAction\": \"\" }, \"customerInfo\": { \"customerType\": \"N\", \"accountNumber\": \"\", \"cartCreator\": \"POE-M-05de7b5c-2ccb-458b-84e6-6017fce2a382\", \"processingMTN\": \"newLine1\", \"registerNumber\": 0, \"mtnFlow\": \"D\", \"globalId\": \"POE-M-05de7b5c-2ccb-458b-84e6-6017fce2a382\" }, \"cartInfo\": { \"cartItemCount\": 0, \"statusMsg\": \"Success\", \"statusCode\": \"1\", \"effectiveDateDetails\": { \"suggestedBackDate\": \"\", \"suggestedFutureDate\": \"\", \"currentBillCycleBeginDate\": \"\", \"nextBillCycleBeginDate\": \"\", \"onDemandRangeInDays\": \"\", \"selectedDate\": \"\" }, \"preAuthSuccess\": false, \"discountPromoTotal\": 0.0, \"registerNumber\": 0, \"protectionNotRequired\": false }, \"processMTNList\": [{ \"mtn\": \"newLine1\", \"completedprocessSteps\": [\"PlanSelection\", \"BYODDeviceIDPage\", \"BYODSimIDPage\", \"DeviceConfigurator\", \"DeviceConfigurator\", \"ContactInfo\", \"EligibilityReview\", \"EligibilityReview\", \"EligibilityReview\", \"AccountInfo\", \"Agreement\", \"Agreement\", \"Shipment\", \"Shipment\", \"OrderReview\", \"OrderReview\", \"Shipment\", \"OrderReview\", \"Shipment\", \"OrderReview\"] }] } } } }";
		BillingAddressUIResponse uiResponse = new BillingAddressUIResponse();
		BillingAddressPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, BillingAddressPEGAResponse.class);
		Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util.formatBillingAddressResponse(uiResponse,pegaResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util.formatBillingAddressResponse(uiResponse,pegaResponse);
		Assert.assertNotNull(pegaResponse);
		
	}
	
	@Test
	public void formatBillingAddressResponseTest1() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-DOTCOM-MOB\", \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\", \"correlationId\": \"soe-cart-2021.10.10.20.03.28-592.6550588551962\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"contextInfo\": { \"availablePaths\": [{ \"path\": \"updateServiceAddress\" }], \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"OrderReview\", \"processAction\": \"\" }, \"customerInfo\": { \"customerType\": \"N\", \"accountNumber\": \"\", \"cartCreator\": \"POE-M-05de7b5c-2ccb-458b-84e6-6017fce2a382\", \"processingMTN\": \"newLine1\", \"registerNumber\": 0, \"mtnFlow\": \"D\", \"globalId\": \"POE-M-05de7b5c-2ccb-458b-84e6-6017fce2a382\" }, \"cartInfo\": null, \"preAuthSuccess\": false, \"discountPromoTotal\": 0.0, \"registerNumber\": 0, \"protectionNotRequired\": false }, \"processMTNList\": [{ \"mtn\": \"newLine1\", \"completedprocessSteps\": [\"PlanSelection\", \"BYODDeviceIDPage\", \"BYODSimIDPage\", \"DeviceConfigurator\", \"DeviceConfigurator\", \"ContactInfo\", \"EligibilityReview\", \"EligibilityReview\", \"EligibilityReview\", \"AccountInfo\", \"Agreement\", \"Agreement\", \"Shipment\", \"Shipment\", \"OrderReview\", \"OrderReview\", \"Shipment\", \"OrderReview\", \"Shipment\", \"OrderReview\"] }] } } } }";
		BillingAddressUIResponse uiResponse = new BillingAddressUIResponse();
		BillingAddressPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, BillingAddressPEGAResponse.class);
		util.formatBillingAddressResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatBillingAddressResponseTest2() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-DOTCOM-MOB\", \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\", \"correlationId\": \"soe-cart-2021.10.10.20.03.28-592.6550588551962\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"contextInfo\": { \"availablePaths\": [{ \"path\": \"updateServiceAddress\" }], \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"OrderReview\", \"processAction\": \"\" }, \"customerInfo\": { \"customerType\": \"Y\", \"accountNumber\": \"\", \"cartCreator\": \"POE-M-05de7b5c-2ccb-458b-84e6-6017fce2a382\", \"processingMTN\": \"newLine1\", \"registerNumber\": 0, \"mtnFlow\": \"D\", \"globalId\": \"POE-M-05de7b5c-2ccb-458b-84e6-6017fce2a382\" }, \"cartInfo\": null, \"preAuthSuccess\": false, \"discountPromoTotal\": 0.0, \"registerNumber\": 0, \"protectionNotRequired\": false }, \"processMTNList\": [{ \"mtn\": \"newLine1\", \"completedprocessSteps\": [\"PlanSelection\", \"BYODDeviceIDPage\", \"BYODSimIDPage\", \"DeviceConfigurator\", \"DeviceConfigurator\", \"ContactInfo\", \"EligibilityReview\", \"EligibilityReview\", \"EligibilityReview\", \"AccountInfo\", \"Agreement\", \"Agreement\", \"Shipment\", \"Shipment\", \"OrderReview\", \"OrderReview\", \"Shipment\", \"OrderReview\", \"Shipment\", \"OrderReview\"] }] } } } }";
		BillingAddressUIResponse uiResponse = new BillingAddressUIResponse();
		BillingAddressPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, BillingAddressPEGAResponse.class);
		util.formatBillingAddressResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatBillingAddressResponseTest3() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-DOTCOM-MOB\", \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\", \"correlationId\": \"soe-cart-2021.10.10.20.03.28-592.6550588551962\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"contextInfo\": { \"availablePaths\": [{ \"path\": \"updateServiceAddress\" }], \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"OrderReview\", \"processAction\": \"\" }, \"customerInfo\": { \"customerType\": null, \"accountNumber\": \"\", \"cartCreator\": \"POE-M-05de7b5c-2ccb-458b-84e6-6017fce2a382\", \"processingMTN\": \"newLine1\", \"registerNumber\": 0, \"mtnFlow\": \"D\", \"globalId\": \"POE-M-05de7b5c-2ccb-458b-84e6-6017fce2a382\" }, \"cartInfo\": null, \"preAuthSuccess\": false, \"discountPromoTotal\": 0.0, \"registerNumber\": 0, \"protectionNotRequired\": false }, \"processMTNList\": [{ \"mtn\": \"newLine1\", \"completedprocessSteps\": [\"PlanSelection\", \"BYODDeviceIDPage\", \"BYODSimIDPage\", \"DeviceConfigurator\", \"DeviceConfigurator\", \"ContactInfo\", \"EligibilityReview\", \"EligibilityReview\", \"EligibilityReview\", \"AccountInfo\", \"Agreement\", \"Agreement\", \"Shipment\", \"Shipment\", \"OrderReview\", \"OrderReview\", \"Shipment\", \"OrderReview\", \"Shipment\", \"OrderReview\"] }] } } } }";
		BillingAddressUIResponse uiResponse = new BillingAddressUIResponse();
		BillingAddressPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, BillingAddressPEGAResponse.class);
		util.formatBillingAddressResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatBillingAddressResponseTest4() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-DOTCOM-MOB\", \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\", \"correlationId\": \"soe-cart-2021.10.10.20.03.28-592.6550588551962\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"contextInfo\": { \"availablePaths\": [{ \"path\": \"updateServiceAddress\" }], \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"OrderReview\", \"processAction\": \"\" }, \"customerInfo\": null, \"cartInfo\": null, \"preAuthSuccess\": false, \"discountPromoTotal\": 0.0, \"registerNumber\": 0, \"protectionNotRequired\": false }, \"processMTNList\": [{ \"mtn\": \"newLine1\", \"completedprocessSteps\": [\"PlanSelection\", \"BYODDeviceIDPage\", \"BYODSimIDPage\", \"DeviceConfigurator\", \"DeviceConfigurator\", \"ContactInfo\", \"EligibilityReview\", \"EligibilityReview\", \"EligibilityReview\", \"AccountInfo\", \"Agreement\", \"Agreement\", \"Shipment\", \"Shipment\", \"OrderReview\", \"OrderReview\", \"Shipment\", \"OrderReview\", \"Shipment\", \"OrderReview\"] }] } } } }";
		BillingAddressUIResponse uiResponse = new BillingAddressUIResponse();
		BillingAddressPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, BillingAddressPEGAResponse.class);
		util.formatBillingAddressResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatBillingAddressResponseTest5() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-DOTCOM-MOB\", \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\", \"correlationId\": \"soe-cart-2021.10.10.20.03.28-592.6550588551962\" }, \"serviceBody\": { \"serviceResponse\": { \"context\":null, \"customerInfo\": null, \"cartInfo\": null, \"preAuthSuccess\": false, \"discountPromoTotal\": 0.0, \"registerNumber\": 0, \"protectionNotRequired\": false }, \"processMTNList\": [{ \"mtn\": \"newLine1\", \"completedprocessSteps\": [\"PlanSelection\", \"BYODDeviceIDPage\", \"BYODSimIDPage\", \"DeviceConfigurator\", \"DeviceConfigurator\", \"ContactInfo\", \"EligibilityReview\", \"EligibilityReview\", \"EligibilityReview\", \"AccountInfo\", \"Agreement\", \"Agreement\", \"Shipment\", \"Shipment\", \"OrderReview\", \"OrderReview\", \"Shipment\", \"OrderReview\", \"Shipment\", \"OrderReview\"] }] } } } }";
		BillingAddressUIResponse uiResponse = new BillingAddressUIResponse();
		BillingAddressPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, BillingAddressPEGAResponse.class);
		util.formatBillingAddressResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatBillingAddressResponseTest6() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-DOTCOM-MOB\", \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\", \"correlationId\": \"soe-cart-2021.10.10.20.03.28-592.6550588551962\" }, \"serviceBody\": { \"serviceResponse\":null } }";
		BillingAddressUIResponse uiResponse = new BillingAddressUIResponse();
		BillingAddressPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, BillingAddressPEGAResponse.class);
		util.formatBillingAddressResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatAssignMtnResponseTest() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \" SOP-1583186-DEV3\",\"customerInfo\": {\"accountNumber\": \"07893451230-00001\",\"cartCreator\": \"2515813861\",\"processingMTN\": \"2515813860\"},\"cartInfo\": {\"cartId\": \"69a66ef4d-7e344dfb-2db299209-ea8333\",\"statusCode\": 1,\"statusMsg\": \"Success\",\"lines\": [{\"mtn\": \"6186979119\",\"lineNumber\": \"newLine1\",\"status\": 1,\"planValidationFailed\": false,\"lineActivityType\": \"AAL\",\"currentPlanType\": \"LLP\",\"devicePlanCompatible\": false}],\"preAuthSuccess\": false}},\"contextInfo\": {\"processAction\": \"\",\"processStep\": \"InterimPage\",\"callReason\": \" SalesOrderPurchase \"}}}}";
		AssignMtnUIRequest uiRequest = new AssignMtnUIRequest();
		CartInfo cartInfo = new CartInfo();
		cartInfo.setIntendType("NSE");
		uiRequest.setCartInfo(cartInfo);
		AssignMtnUIResponse uiResponse = new AssignMtnUIResponse();
		AssignMtnPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, AssignMtnPEGAResponse.class);
		Error error =new Error();
		 error.setMessage("abc type error");
		 List<Error> list = new ArrayList<>();
		 list.add(error);
		 pegaResponse.setErrors(list);
		 util.formatAssignMtnResponse(pegaResponse,uiResponse,uiRequest);
		 Assert.assertNotNull(pegaResponse);
		 pegaResponse.setServiceBody(null);
		 pegaResponse.setServiceHeader(null);
		 pegaResponse.setErrors(null);
		 util.formatAssignMtnResponse(pegaResponse,uiResponse,uiRequest);
		 Assert.assertNotNull(pegaResponse);
		
	}
	
	@Test
	public void formatAssignMtnResponseTest1() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \" SOP-1583186-DEV3\",\"customerInfo\": {\"accountNumber\": \"07893451230-00001\",\"cartCreator\": \"2515813861\",\"processingMTN\": \"2515813860\"},\"cartInfo\": {\"cartId\": \"69a66ef4d-7e344dfb-2db299209-ea8333\",\"statusCode\": 1,\"statusMsg\": \"Success\",\"lines\": [{\"mtn\": \"6186979119\",\"lineNumber\": \"newLine1\",\"status\": 1,\"planValidationFailed\": false,\"lineActivityType\": \"AAL\",\"currentPlanType\": \"LLP\",\"devicePlanCompatible\": false}],\"preAuthSuccess\": false}},\"contextInfo\": {\"processAction\": \"\",\"processStep\": \"InterimPage\",\"callReason\": \" SalesOrderPurchase \"}}}}";
		AssignMtnUIRequest uiRequest = new AssignMtnUIRequest();
		CartInfo cartInfo = new CartInfo();
		cartInfo.setIntendType("NSEBYOD");
		uiRequest.setCartInfo(cartInfo);
		AssignMtnUIResponse uiResponse = new AssignMtnUIResponse();
		AssignMtnPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, AssignMtnPEGAResponse.class);
		util.formatAssignMtnResponse(pegaResponse,uiResponse,uiRequest);
	}
	
	@Test
	public void formatAssignMtnResponseTest2() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \" SOP-1583186-DEV3\",\"customerInfo\": {\"accountNumber\": \"07893451230-00001\",\"cartCreator\": \"2515813861\",\"processingMTN\": \"2515813860\"},\"cartInfo\": {\"cartId\": \"69a66ef4d-7e344dfb-2db299209-ea8333\",\"statusCode\": 1,\"statusMsg\": \"Success\",\"lines\": [{\"mtn\": \"6186979119\",\"lineNumber\": \"newLine1\",\"status\": 1,\"planValidationFailed\": false,\"lineActivityType\": \"AAL\",\"currentPlanType\": \"LLP\",\"devicePlanCompatible\": false}],\"preAuthSuccess\": false}},\"contextInfo\": {\"processAction\": \"\",\"processStep\": \"InterimPage\",\"callReason\": \" SalesOrderPurchase \"}}}}";
		AssignMtnUIRequest uiRequest = new AssignMtnUIRequest();
		CartInfo cartInfo = new CartInfo();
		cartInfo.setIntendType("EUP");
		uiRequest.setCartInfo(cartInfo);
		AssignMtnUIResponse uiResponse = new AssignMtnUIResponse();
		AssignMtnPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, AssignMtnPEGAResponse.class);
		util.formatAssignMtnResponse(pegaResponse,uiResponse,uiRequest);
	}
	
	@Test
	public void formatAssignMtnResponseTest3() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\":null,\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \" SOP-1583186-DEV3\",\"customerInfo\": {\"accountNumber\": \"07893451230-00001\",\"cartCreator\": \"2515813861\",\"processingMTN\": \"2515813860\"},\"cartInfo\": {\"cartId\": \"69a66ef4d-7e344dfb-2db299209-ea8333\",\"statusCode\": 1,\"statusMsg\": \"Success\",\"lines\": [{\"mtn\": \"6186979119\",\"lineNumber\": \"newLine1\",\"status\": 1,\"planValidationFailed\": false,\"lineActivityType\": \"AAL\",\"currentPlanType\": \"LLP\",\"devicePlanCompatible\": false}],\"preAuthSuccess\": false}},\"contextInfo\": {\"processAction\": \"\",\"processStep\": \"InterimPage\",\"callReason\": \" SalesOrderPurchase \"}}}}";
		AssignMtnUIRequest uiRequest = new AssignMtnUIRequest();
		CartInfo cartInfo = new CartInfo();
		cartInfo.setIntendType("NSE");
		uiRequest.setCartInfo(cartInfo);
		AssignMtnUIResponse uiResponse = new AssignMtnUIResponse();
		AssignMtnPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, AssignMtnPEGAResponse.class);
		util.formatAssignMtnResponse(pegaResponse,uiResponse,uiRequest);
	}
	
	@Test
	public void formatAssignMtnResponseTest4() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\":null,\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \" SOP-1583186-DEV3\",\"customerInfo\": null,\"cartInfo\": {\"cartId\": \"69a66ef4d-7e344dfb-2db299209-ea8333\",\"statusCode\": 1,\"statusMsg\": \"Success\",\"lines\": [{\"mtn\": \"6186979119\",\"lineNumber\": \"newLine1\",\"status\": 1,\"planValidationFailed\": false,\"lineActivityType\": \"AAL\",\"currentPlanType\": \"LLP\",\"devicePlanCompatible\": false}],\"preAuthSuccess\": false}},\"contextInfo\": {\"processAction\": \"\",\"processStep\": \"InterimPage\",\"callReason\": \" SalesOrderPurchase \"}}}}";
		AssignMtnUIRequest uiRequest = new AssignMtnUIRequest();
		CartInfo cartInfo = new CartInfo();
		cartInfo.setIntendType("NSE");
		uiRequest.setCartInfo(cartInfo);
		AssignMtnUIResponse uiResponse = new AssignMtnUIResponse();
		AssignMtnPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, AssignMtnPEGAResponse.class);
		util.formatAssignMtnResponse(pegaResponse,uiResponse,uiRequest);
	}
	
	@Test
	public void formatAssignMtnResponseTest5() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\":null,\"serviceBody\": {\"serviceResponse\": {\"context\":null}}}";
		AssignMtnUIRequest uiRequest = new AssignMtnUIRequest();
		CartInfo cartInfo = new CartInfo();
		cartInfo.setIntendType("NSE");
		uiRequest.setCartInfo(cartInfo);
		AssignMtnUIResponse uiResponse = new AssignMtnUIResponse();
		AssignMtnPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, AssignMtnPEGAResponse.class);
		util.formatAssignMtnResponse(pegaResponse,uiResponse,uiRequest);
	}
	
	@Test
	public void formatAssignMtnResponseTest6() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\":null,\"serviceBody\": {\"serviceResponse\":null}}";
		AssignMtnUIRequest uiRequest = new AssignMtnUIRequest();
		CartInfo cartInfo = new CartInfo();
		cartInfo.setIntendType("NSE");
		uiRequest.setCartInfo(cartInfo);
		AssignMtnUIResponse uiResponse = new AssignMtnUIResponse();
		AssignMtnPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, AssignMtnPEGAResponse.class);
		util.formatAssignMtnResponse(pegaResponse,uiResponse,uiRequest);
	}
	
	@Test
	public void formatManualPairingResponseTest() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \" SOP-1583186-DEV3\",\"customerInfo\": {\"accountNumber\": \"07893451230-00001\",\"cartCreator\": \"2515813861\",\"processingMTN\": \"2515813860\"},\"cartInfo\": {\"cartId\": \"69a66ef4d-7e344dfb-2db299209-ea8333\",\"statusCode\": 1,\"statusMsg\": \"Success\",\"lines\": [{\"mtn\": \"6186979119\",\"lineNumber\": \"newLine1\",\"status\": 1,\"planValidationFailed\": false,\"lineActivityType\": \"AAL\",\"currentPlanType\": \"LLP\",\"devicePlanCompatible\": false}],\"preAuthSuccess\": false}},\"contextInfo\": {\"processAction\": \"\",\"processStep\": \"InterimPage\",\"callReason\": \" SalesOrderPurchase \"}}}}";
		ManualPairingUIResponse uiResponse = new ManualPairingUIResponse();
		ManualPairingPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, ManualPairingPEGAResponse.class);
		Error error =new Error();
		 error.setMessage("abc type error");
		 List<Error> list = new ArrayList<>();
		 list.add(error);
		 pegaResponse.setErrors(list);
		 util.formatManualPairingResponse(uiResponse,pegaResponse);
		 Assert.assertNotNull(pegaResponse);
		 pegaResponse.setServiceBody(null);
		 pegaResponse.setServiceHeader(null);
		 pegaResponse.setErrors(null);
		 util.formatManualPairingResponse(uiResponse,pegaResponse);
		 Assert.assertNotNull(pegaResponse);
		
	}
	
	@Test
	public void formatUpdateEdgeUpResponseTest1() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-NETACE\", \"statusMsg\": \"PEGA generated message\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"sessionId\": \"\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\",\"statusCode\": \"0\"}, \"serviceBody\": {\"serviceResponse\": {\"context\":{\"cartInfo\": {\"promoLossIndicator\":true,\"cartId\":\"bea202a6-42cb-40d4-ac87-d3f1db2b3f13\",\"statusCode\": 1,\"statusMsg\": \"Edge Up cancelled successfully.\",\"monthlyCreditAmount\":\"100\",\"agreementNumber\":\"POS374583237\"},\"contextInfo\": {\"processAction\": \"\", \"callReason\": \"SalesOrderPurchase\",\"processStep\": \"MTNSelectionPage\",\"availablePaths\":[{\"path\":\"MTNSelectionPage\"}]}}}}}";
		UpdateEdgeupUIResponse  uiResponse = new UpdateEdgeupUIResponse();
		UpdateEdgeupPEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, UpdateEdgeupPEGAResponse .class);
		util.formatUpdateEdgeUpResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatUpdateEdgeUpResponseTest2() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-NETACE\", \"statusMsg\": \"PEGA generated message\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"sessionId\": \"\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\",\"statusCode\": \"0\"}, \"serviceBody\": {\"serviceResponse\": {\"context\":{\"cartInfo\": {\"promoLossIndicator\":false,\"cartId\":\"bea202a6-42cb-40d4-ac87-d3f1db2b3f13\",\"statusCode\": 1,\"statusMsg\": \"Edge Up cancelled successfully.\",\"monthlyCreditAmount\":\"100\",\"agreementNumber\":\"POS374583237\"},\"contextInfo\": {\"processAction\": \"\", \"callReason\": \"SalesOrderPurchase\",\"processStep\": \"MTNSelectionPage\",\"availablePaths\":[{\"path\":\"MTNSelectionPage\"}]}}}}}";
		UpdateEdgeupUIResponse  uiResponse = new UpdateEdgeupUIResponse();
		UpdateEdgeupPEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, UpdateEdgeupPEGAResponse .class);
		util.formatUpdateEdgeUpResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatUpdateEdgeUpResponseTest3() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-NETACE\", \"statusMsg\": \"PEGA generated message\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"sessionId\": \"\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\",\"statusCode\": \"0\"}, \"serviceBody\": {\"serviceResponse\": {\"context\":{\"cartInfo\": {\"promoLossIndicator\":null,\"cartId\":\"bea202a6-42cb-40d4-ac87-d3f1db2b3f13\",\"statusCode\": 1,\"statusMsg\": \"Edge Up cancelled successfully.\",\"monthlyCreditAmount\":\"100\",\"agreementNumber\":\"POS374583237\"},\"contextInfo\": {\"processAction\": \"\", \"callReason\": \"SalesOrderPurchase\",\"processStep\": \"MTNSelectionPage\",\"availablePaths\":[{\"path\":\"MTNSelectionPage\"}]}}}}}";
		UpdateEdgeupUIResponse  uiResponse = new UpdateEdgeupUIResponse();
		UpdateEdgeupPEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, UpdateEdgeupPEGAResponse .class);
		util.formatUpdateEdgeUpResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatAddNickNameResponseTest() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\":null,\"serviceBody\":null,\"errors\":[{\"namespace\":\"CXP_Pega_BPM\",\"name\":\"Provided Case Id is resolved or Invalid.\",\"id\":\"1008\",\"debug_id\":\"20220920T052555.145 GMT||pega-010adfc9-5170-4da9-b381-0f7da3573a30-09192022-102555-140|soe-cart-2022.09.20.10.54.43-862.9557849437155\",\"message\":\"Invalid Case Id\",\"severity\":\"High\",\"errorCategory\":\"UNKNW\",\"details\":[{\"field\":\"Case ID\",\"value\":\"SOF-8624507-C01\",\"issue\":\"Either CaseID provided resolved or Invalid.\",\"location\":\"context\",\"lockedChannelID\":\"\"}]}]}";
		AddNickNameUIResponse  uiResponse = new AddNickNameUIResponse();
		AddNickNamePEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, AddNickNamePEGAResponse.class);
		Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util1.formatAddNickNameResponse(uiResponse,pegaResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util1.formatAddNickNameResponse(uiResponse,pegaResponse);
		Assert.assertNotNull(pegaResponse);	
	}
	
	@Test
	public void formatGetCaseResponseResponseTest() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{ \"serviceHeader\": { \"clientId\": \"OMNI-TELESALES\", \"serviceName\": \"GetCases\", \"userId\": \"tabmgr\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"customerInfo\": { \"accountNumber\": \"0212875226-00001\", \"cartCreator\": \"\", \"registerNumber\": 0, \"skipMissedProfileEmailValidation\": false, \"originalCreditApprovalNumber\": 0, \"standAloneTradein\": false }, \"cases\": [{ \"cartCreator\": \"4349961104\", \"cartId\": \"4d3fcf52-9a57-4638-8378-d1b05f0a547b\", \"intent\": \"Sales Order Purchase\", \"caseID\": \"SOP-4312496-E01\", \"lastUpdateTime\": \"20211011T095624.333 GMT\", \"amRole\": \"\", \"originatingChannelId\": \"OMNI-RETAIL\", \"preConfiguredCartTypeDuringAddDevice\": \"\", \"lineCreator\": \"\", \"quoteId\": \"\", \"showWarning\": \"No\", \"lastActiveChannelID\": \"OMNI-TELESALES\" }] } } } }";
		GetCaseResponse  uiResponse = new GetCaseResponse();
		GetCasePEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, GetCasePEGAResponse.class);
		util1.formatGetCaseResponseResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatGetCaseResponseResponseTest1() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\":null,\"serviceBody\":null,\"errors\":[{\"namespace\":\"CXP_Pega_BPM\",\"name\":\"Provided Case Id is resolved or Invalid.\",\"id\":\"1008\",\"debug_id\":\"20220920T052555.145 GMT||pega-010adfc9-5170-4da9-b381-0f7da3573a30-09192022-102555-140|soe-cart-2022.09.20.10.54.43-862.9557849437155\",\"message\":\"Invalid Case Id\",\"severity\":\"High\",\"errorCategory\":\"UNKNW\",\"details\":[{\"field\":\"Case ID\",\"value\":\"SOF-8624507-C01\",\"issue\":\"Either CaseID provided resolved or Invalid.\",\"location\":\"context\",\"lockedChannelID\":\"\"}]}]}";
		GetCaseResponse  uiResponse = new GetCaseResponse();
		GetCasePEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, GetCasePEGAResponse.class);
		util1.formatGetCaseResponseResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatAccountPinResponseTest() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString =  "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \" SOP-1583186-DEV3\",\"customerInfo\": {\"accountNumber\": \"07893451230-00001\",\"cartCreator\": \"2515813861\",\"processingMTN\": \"2515813860\"},\"cartInfo\": {\"cartId\": \"69a66ef4d-7e344dfb-2db299209-ea8333\",\"statusCode\": 1,\"statusMsg\": \"Success\",\"lines\": [{\"mtn\": \"6186979119\",\"lineNumber\": \"newLine1\",\"status\": 1,\"planValidationFailed\": false,\"lineActivityType\": \"AAL\",\"currentPlanType\": \"LLP\",\"devicePlanCompatible\": false}],\"preAuthSuccess\": false}},\"contextInfo\": {\"processAction\": \"\",\"processStep\": \"InterimPage\",\"callReason\": \" SalesOrderPurchase \"}}}}";
		AccountPinUIResponse  uiResponse = new AccountPinUIResponse();
		AccountPinPEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, AccountPinPEGAResponse.class);
		util1.formatAccountPinResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatAccountPinResponseTest1() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString =  "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \" SOP-1583186-DEV3\",\"customerInfo\": {\"accountNumber\": \"07893451230-00001\",\"cartCreator\": \"2515813861\",\"processingMTN\": \"2515813860\"},\"cartInfo\":null,\"preAuthSuccess\": false}},\"contextInfo\": {\"processAction\": \"\",\"processStep\": \"InterimPage\",\"callReason\": \" SalesOrderPurchase \"}}}}";
		AccountPinUIResponse  uiResponse = new AccountPinUIResponse();
		AccountPinPEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, AccountPinPEGAResponse.class);
		util1.formatAccountPinResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatAccountPinResponseTest2() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString =  "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\":null}}}";
		AccountPinUIResponse  uiResponse = new AccountPinUIResponse();
		AccountPinPEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, AccountPinPEGAResponse.class);
		util1.formatAccountPinResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatAccountPinResponseTest3() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString =  "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\":null}}";
		AccountPinUIResponse  uiResponse = new AccountPinUIResponse();
		AccountPinPEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, AccountPinPEGAResponse.class);
		util1.formatAccountPinResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatAccountPinResponseTest4() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString =  "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\":null}";
		AccountPinUIResponse  uiResponse = new AccountPinUIResponse();
		AccountPinPEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, AccountPinPEGAResponse.class);
		util1.formatAccountPinResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatAccountPinResponseTest5() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString =  "{\"serviceHeader\":null,\"serviceBody\": {\"serviceResponse\": {\"context\":null}}}";
		AccountPinUIResponse  uiResponse = new AccountPinUIResponse();
		AccountPinPEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, AccountPinPEGAResponse.class);
		util1.formatAccountPinResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatAccountPinResponseTest6() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString =  "{\"errors\":[{\"namespace\":\"CXP_Pega_BPM\",\"name\":\"Provided Case Id is resolved or Invalid.\",\"id\":\"1008\",\"debug_id\":\"20220920T052555.145 GMT||pega-010adfc9-5170-4da9-b381-0f7da3573a30-09192022-102555-140|soe-cart-2022.09.20.10.54.43-862.9557849437155\",\"message\":\"Invalid Case Id\",\"severity\":\"High\",\"errorCategory\":\"UNKNW\",\"details\":[{\"field\":\"Case ID\",\"value\":\"SOF-8624507-C01\",\"issue\":\"Either CaseID provided resolved or Invalid.\",\"location\":\"context\",\"lockedChannelID\":\"\"}]}]}";
		AccountPinUIResponse  uiResponse = new AccountPinUIResponse();
		AccountPinPEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, AccountPinPEGAResponse.class);
		util1.formatAccountPinResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatSalesOrderAdjustmentResponseTest() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString =  "{\"serviceHeader\":null,\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOA-7743065-C01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShopLandingPage\"}],\"callReason\":\"SalesOrderAdjustment\",\"processStep\":\"ShopLandingPage\"},\"customerInfo\":{\"accountNumber\":\"0430583693-00001\",\"cartCreator\":\"2792994\",\"processingMTN\":\"\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"refundOrderDetails\":{\"lines\":{\"lineInfo\":[{\"lineActivityType\":\"PAD\",\"mtnDetails\":{\"lineNumber\":\"8327077668\",\"mobileNumber\":\"8327077668\"},\"multiLineSeqNumber\":\"1\",\"items\":[{\"deviceId\":\"\"}]},{\"lineActivityType\":\"PAD\",\"mtnDetails\":{\"lineNumber\":\"8327077645\",\"mobileNumber\":\"8327077645\"},\"multiLineSeqNumber\":\"2\",\"items\":[{\"deviceId\":\"\"}]}]}},\"missedProfileInfo\":{\"firstName\":\"\",\"lastName\":\"\",\"email\":\"\",\"city\":\"\",\"state\":\"\",\"zipCode\":\"\",\"streetNumber\":\"\",\"streetName\":\"\",\"businessName\":\"\",\"zipCode4\":\"\"},\"cartId\":\"855a06ef-17b7-4618-a728-a65c081a00f9\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";
		SalesOrderAdjustmentUIResponse  uiResponse = new SalesOrderAdjustmentUIResponse();
		SalesOrderAdjustmentPEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, SalesOrderAdjustmentPEGAResponse.class);
		util1.formatSalesOrderAdjustmentResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatProcessStepResponseTest() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString =  "{\"serviceHeader\":null,\"serviceBody\":null,\"errors\":[{\"namespace\":\"CXP_Pega_BPM\",\"name\":\"Provided Case Id is resolved or Invalid.\",\"id\":\"1008\",\"debug_id\":\"20220920T052555.145 GMT||pega-010adfc9-5170-4da9-b381-0f7da3573a30-09192022-102555-140|soe-cart-2022.09.20.10.54.43-862.9557849437155\",\"message\":\"Invalid Case Id\",\"severity\":\"High\",\"errorCategory\":\"UNKNW\",\"details\":[{\"field\":\"Case ID\",\"value\":\"SOF-8624507-C01\",\"issue\":\"Either CaseID provided resolved or Invalid.\",\"location\":\"context\",\"lockedChannelID\":\"\"}]}]}";
		BbpGetProcessStepUIResponse  uiResponse = new BbpGetProcessStepUIResponse();
		BbpGetProcessStepPEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, BbpGetProcessStepPEGAResponse.class);
		util.formatProcessStepResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatProcessStepResponseTest1() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString =  "{\"serviceHeader\":null,\"serviceBody\":null,\"errors\":null}";
		BbpGetProcessStepUIResponse  uiResponse = new BbpGetProcessStepUIResponse();
		BbpGetProcessStepPEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, BbpGetProcessStepPEGAResponse.class);
		util.formatProcessStepResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatRemoveLockResponseTest() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString =  "{\"errors\":null,\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \" SOP-1583186-DEV3\",\"customerInfo\": {\"accountNumber\": \"07893451230-00001\",\"cartCreator\": \"2515813861\",\"processingMTN\": \"2515813860\"},\"cartInfo\": {\"cartId\": \"69a66ef4d-7e344dfb-2db299209-ea8333\",\"statusCode\": 1,\"statusMsg\": \"Success\",\"lines\": [{\"mtn\": \"6186979119\",\"lineNumber\": \"newLine1\",\"status\": 1,\"planValidationFailed\": false,\"lineActivityType\": \"AAL\",\"currentPlanType\": \"LLP\",\"devicePlanCompatible\": false}],\"preAuthSuccess\": false}},\"contextInfo\": {\"processAction\": \"\",\"processStep\": \"InterimPage\",\"callReason\": \" SalesOrderPurchase \"}}}}";
		RemoveLockUIResponse  uiResponse = new RemoveLockUIResponse();
		RemoveLockPEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, RemoveLockPEGAResponse.class);
		Error error =new Error();
		 error.setMessage("abc type error");
		 List<Error> list = new ArrayList<>();
		 list.add(error);
		 pegaResponse.setErrors(list);
		 util1.formatRemoveLockResponse(uiResponse, pegaResponse);
		 Assert.assertNotNull(pegaResponse);
		 pegaResponse.setServiceBody(null);
		 pegaResponse.setServiceHeader(null);
		 pegaResponse.setErrors(null);
		 util1.formatRemoveLockResponse(uiResponse, pegaResponse);
		 Assert.assertNotNull(pegaResponse);
		
	}
	
	@Test
	public void formatManualDiscountResponseTest() throws JsonMappingException, JsonProcessingException {
        String responseString = "{\"serviceHeader\": { \"clientId\": \"VZW-NETACE\", \"statusMsg\": \"PEGA generated message\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"sessionId\": \"\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"0\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \" SOP-1583186-DEV3\", \"customerInfo\" : { \"accountNumber\": \"07893451230-00001\", \"cartCreator\":\"2515813861\", \"processingMTN\": \"2515813860\" }, \"processMTNList\": [ { \"mtn\":\"2515813860\", \"completedprocessSteps\": [\"MTNSelectionPage\",\"GridWallPDP\"] }, { \"mtn\":\"2515813861\", \"completedprocessSteps\": [] } ], \"cartInfo\": { \"cartId\": \"4f306cb7-27ae-4c53-98d8-c42b2276ff05\", \"statusCode\": 1, \"statusMsg\": \"ManualDiscount Updated Successfully.\" },  \"contextInfo\": { \"processAction\": \"\", \"processStep\": \"OrderReview-Shipping\", \"availablePaths\":[ { \"path\":\"OrderReview-Shipping\" }], \"callReason\": \" SalesOrderPurchase \" } } } } }";
        String sampleResponseString = "{ \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \"SOP-4286392-E01\", \"contextInfo\": { \"availablePaths\": [{ \"path\": \"OrderReview-Shipping\" }], \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"OrderReview-Shipping\" }, \"customerInfo\": { \"accountNumber\": \"0000920049-00001\", \"cartCreator\": \"7034835124\", \"processingMTN\": \"7034835124\", \"registerNumber\": 0 }, \"cartInfo\": { \"cartItemCount\": 0, \"cartId\": \"909e3c35-8eea-4200-81ce-9ff15f57b2b1\", \"statusMsg\": \"ManualDiscount Updated Successfully.\", \"statusCode\": \"1\", \"discountPromoTotal\": 0.0, \"registerNumber\": 0, \"protectionNotRequired\": false } } } }, \"serviceHeader\": { \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\", \"correlationId\": \"soe-cart-2021.10.09.10.05.26-246.2210010821554\" } }";
        UpdateManualDiscountUIResponse uiResponse = mapper.readValue(responseString, UpdateManualDiscountUIResponse.class);
		ManualDiscountPEGAResponse pegaResponse = null;
		pegaResponse = mapper.readValue(sampleResponseString, ManualDiscountPEGAResponse.class);
		Error error =new Error();
		 error.setMessage("abc type error");
		 List<Error> list = new ArrayList<>();
		 list.add(error);
		 pegaResponse.setErrors(list);
		 util1.formatManualDiscountResponse(uiResponse, pegaResponse);
		 Assert.assertNotNull(pegaResponse);
		 pegaResponse.setServiceBody(null);
		 pegaResponse.setServiceHeader(null);
		 pegaResponse.setErrors(null);
		 util1.formatManualDiscountResponse(uiResponse, pegaResponse);
		 Assert.assertNotNull(pegaResponse);
	}
	
	@Test
	public void formatRetrieveActivationStatusResponseTest() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString =  "{\"serviceHeader\":null,\"serviceBody\":null,\"errors\":[{\"namespace\":\"CXP_Pega_BPM\",\"name\":\"Provided Case Id is resolved or Invalid.\",\"id\":\"1008\",\"debug_id\":\"20220920T052555.145 GMT||pega-010adfc9-5170-4da9-b381-0f7da3573a30-09192022-102555-140|soe-cart-2022.09.20.10.54.43-862.9557849437155\",\"message\":\"Invalid Case Id\",\"severity\":\"High\",\"errorCategory\":\"UNKNW\",\"details\":[{\"field\":\"Case ID\",\"value\":\"SOF-8624507-C01\",\"issue\":\"Either CaseID provided resolved or Invalid.\",\"location\":\"context\",\"lockedChannelID\":\"\"}]}]}";
		RetrieveActivationStatusUIResponse  uiResponse = new RetrieveActivationStatusUIResponse();
		RetrieveActivationStatusPEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, RetrieveActivationStatusPEGAResponse.class);
		util.formatRetrieveActivationStatusResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatRetrieveActivationStatusResponseTest1() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString =  "{\"serviceHeader\":null,\"serviceBody\":null,\"errors\":null}";
		RetrieveActivationStatusUIResponse  uiResponse = new RetrieveActivationStatusUIResponse();
		RetrieveActivationStatusPEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, RetrieveActivationStatusPEGAResponse.class);
		util.formatRetrieveActivationStatusResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatRemoveBvoOffersResponseTest1() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\":null,\"serviceBody\":null,\"errors\":[{\"namespace\":\"CXP_Pega_BPM\",\"name\":\"Provided Case Id is resolved or Invalid.\",\"id\":\"1008\",\"debug_id\":\"20220920T052555.145 GMT||pega-010adfc9-5170-4da9-b381-0f7da3573a30-09192022-102555-140|soe-cart-2022.09.20.10.54.43-862.9557849437155\",\"message\":\"Invalid Case Id\",\"severity\":\"High\",\"errorCategory\":\"UNKNW\",\"details\":[{\"field\":\"Case ID\",\"value\":\"SOF-8624507-C01\",\"issue\":\"Either CaseID provided resolved or Invalid.\",\"location\":\"context\",\"lockedChannelID\":\"\"}]}]}";
		UpdateBvoOffersUIResponse  uiResponse = new UpdateBvoOffersUIResponse();
		UpdateBvoOffersPEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, UpdateBvoOffersPEGAResponse.class);
		util.formatRemoveBvoOffersResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatRemoveBvoOffersResponseTest2() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\":null,\"serviceBody\":null,\"errors\":null}";
		UpdateBvoOffersUIResponse  uiResponse = new UpdateBvoOffersUIResponse();
		UpdateBvoOffersPEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, UpdateBvoOffersPEGAResponse.class);
		util.formatRemoveBvoOffersResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatEffectiveDateResponseTest() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\":null,\"serviceBody\":null,\"errors\":[{\"namespace\":\"CXP_Pega_BPM\",\"name\":\"Provided Case Id is resolved or Invalid.\",\"id\":\"1008\",\"debug_id\":\"20220920T052555.145 GMT||pega-010adfc9-5170-4da9-b381-0f7da3573a30-09192022-102555-140|soe-cart-2022.09.20.10.54.43-862.9557849437155\",\"message\":\"Invalid Case Id\",\"severity\":\"High\",\"errorCategory\":\"UNKNW\",\"details\":[{\"field\":\"Case ID\",\"value\":\"SOF-8624507-C01\",\"issue\":\"Either CaseID provided resolved or Invalid.\",\"location\":\"context\",\"lockedChannelID\":\"\"}]}]}";
		UpdateEffectiveDateUIResponse  uiResponse = new UpdateEffectiveDateUIResponse();
		EffectiveDatePEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, EffectiveDatePEGAResponse.class);
		util1.formatEffectiveDateResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatInitiateValidateDeviceSimResponseTest() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\":null,\"serviceBody\":null,\"errors\":[{\"namespace\":\"CXP_Pega_BPM\",\"name\":\"Provided Case Id is resolved or Invalid.\",\"id\":\"1008\",\"debug_id\":\"20220920T052555.145 GMT||pega-010adfc9-5170-4da9-b381-0f7da3573a30-09192022-102555-140|soe-cart-2022.09.20.10.54.43-862.9557849437155\",\"message\":\"Invalid Case Id\",\"severity\":\"High\",\"errorCategory\":\"UNKNW\",\"details\":[{\"field\":\"Case ID\",\"value\":\"SOF-8624507-C01\",\"issue\":\"Either CaseID provided resolved or Invalid.\",\"location\":\"context\",\"lockedChannelID\":\"\"}]}]}";
		InitiateValidateDeviceSimUIResponse  uiResponse = new InitiateValidateDeviceSimUIResponse();
		InitiateValidateDeviceSimPEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, InitiateValidateDeviceSimPEGAResponse.class);
		util1.formatInitiateValidateDeviceSimResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatInitiateValidateDeviceSimResponseTest1() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\":null,\"serviceBody\":null,\"errors\":null}";
		InitiateValidateDeviceSimUIResponse  uiResponse = new InitiateValidateDeviceSimUIResponse();
		InitiateValidateDeviceSimPEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, InitiateValidateDeviceSimPEGAResponse.class);
		util1.formatInitiateValidateDeviceSimResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatResponseForBBPChannelTest() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"SignInOrderReview\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"SignInOrderReview\"},{\"path\":\"SignIn\"},{\"path\":\"GuestCheckOut\"}]},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POW-D-4072df6b-69a3-4c1d-a8bd-6bdcdff1ee29\",\"processingMTN\":\"9999999999\",\"registerNumber\":0},\"cartInfo\":null}}";
		ServiceHeader  header = new ServiceHeader();
		header.setClientId("VZW-DOTCOM-BBP");
		ServiceResponse  pegaResponse = mapper.readValue(pegaResponseString, ServiceResponse.class);
		util.formatResponseForBBPChannel(header,pegaResponse);
	}
	
	@Test
	public void formatResponseForBBPChannelTest1() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"SignInOrderReview\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"SignInOrderReview\"},{\"path\":\"SignIn\"},{\"path\":\"GuestCheckOut\"}]},\"customerInfo\":null,\"registerNumber\":0},\"cartInfo\":null}}";
		ServiceHeader  header = new ServiceHeader();
		header.setClientId("VZW-DOTCOM-BBP");
		ServiceResponse  pegaResponse = mapper.readValue(pegaResponseString, ServiceResponse.class);
		util.formatResponseForBBPChannel(header,pegaResponse);
	}
	
	@Test
	public void formatResponseForBBPChannelTest2() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"context\":null}";
		ServiceHeader  header = new ServiceHeader();
		header.setClientId("VZW-DOTCOM-BBP");
		ServiceResponse  pegaResponse = mapper.readValue(pegaResponseString, ServiceResponse.class);
		util.formatResponseForBBPChannel(header,pegaResponse);
	}
	
	@Test
	public void formatCheckExistingCartPegaResponseTest() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"errors\":null,\"serviceHeader\":null,\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \" SOP-1583186-DEV3\",\"customerInfo\": {\"accountNumber\": \"07893451230-00001\",\"cartCreator\": \"2515813861\",\"processingMTN\": \"2515813860\"},\"cartInfo\": {\"cartId\": \"69a66ef4d-7e344dfb-2db299209-ea8333\",\"statusCode\": 1,\"statusMsg\": \"Success\",\"lines\": [{\"mtn\": \"6186979119\",\"lineNumber\": \"newLine1\",\"status\": 1,\"planValidationFailed\": false,\"lineActivityType\": \"AAL\",\"currentPlanType\": \"LLP\",\"devicePlanCompatible\": false}],\"preAuthSuccess\": false}},\"contextInfo\": {\"processAction\": \"\",\"processStep\": \"InterimPage\",\"callReason\": \" SalesOrderPurchase \"}}}}";
		
		CheckExistingCartUIResponse  uiResponse = new CheckExistingCartUIResponse();
		CheckExistingCartPEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, CheckExistingCartPEGAResponse.class);
		util1.formatCheckExistingCartPegaResponse(pegaResponse,uiResponse);
	}
	
	@Test
	public void formatUpdateGiftItemResponseTest() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"errors\":null,\"serviceHeader\":null,\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \" SOP-1583186-DEV3\",\"customerInfo\": {\"accountNumber\": \"07893451230-00001\",\"cartCreator\": \"2515813861\",\"processingMTN\": \"2515813860\"},\"cartInfo\": {\"cartId\": \"69a66ef4d-7e344dfb-2db299209-ea8333\",\"statusCode\": 1,\"statusMsg\": \"Success\",\"lines\": [{\"mtn\": \"6186979119\",\"lineNumber\": \"newLine1\",\"status\": 1,\"planValidationFailed\": false,\"lineActivityType\": \"AAL\",\"currentPlanType\": \"LLP\",\"devicePlanCompatible\": false}],\"preAuthSuccess\": false}},\"contextInfo\": {\"processAction\": \"\",\"processStep\": \"InterimPage\",\"callReason\": \" SalesOrderPurchase \"}}}}";
		UpdateGiftItemUIResponse  uiResponse = new UpdateGiftItemUIResponse();
		UpdateGiftItemPEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, UpdateGiftItemPEGAResponse.class);
		util1.formatUpdateGiftItemResponse(pegaResponse,uiResponse);
	}
	
	
	@Test
	public void formatAccessoryFinancingOffersResponseTest() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\":null,\"serviceBody\":null,\"errors\":[{\"namespace\":\"CXP_Pega_BPM\",\"name\":\"Provided Case Id is resolved or Invalid.\",\"id\":\"1008\",\"debug_id\":\"20220920T052555.145 GMT||pega-010adfc9-5170-4da9-b381-0f7da3573a30-09192022-102555-140|soe-cart-2022.09.20.10.54.43-862.9557849437155\",\"message\":\"Invalid Case Id\",\"severity\":\"High\",\"errorCategory\":\"UNKNW\",\"details\":[{\"field\":\"Case ID\",\"value\":\"SOF-8624507-C01\",\"issue\":\"Either CaseID provided resolved or Invalid.\",\"location\":\"context\",\"lockedChannelID\":\"\"}]}]}";
		AccessoryFinancingOffersUIResponse  uiResponse = new AccessoryFinancingOffersUIResponse();
		AccessoryFinancingOffersPegaResponse  pegaResponse = mapper.readValue(pegaResponseString, AccessoryFinancingOffersPegaResponse.class);
		util1.formatAccessoryFinancingOffersResponse(uiResponse,pegaResponse);
	}
	
	
	@Test
	public void formatCheckExistingCartPegaResponseTest1() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\":null,\"serviceBody\":null,\"errors\":[{\"namespace\":\"CXP_Pega_BPM\",\"name\":\"Provided Case Id is resolved or Invalid.\",\"id\":\"1008\",\"debug_id\":\"20220920T052555.145 GMT||pega-010adfc9-5170-4da9-b381-0f7da3573a30-09192022-102555-140|soe-cart-2022.09.20.10.54.43-862.9557849437155\",\"message\":\"Invalid Case Id\",\"severity\":\"High\",\"errorCategory\":\"UNKNW\",\"details\":[{\"field\":\"Case ID\",\"value\":\"SOF-8624507-C01\",\"issue\":\"Either CaseID provided resolved or Invalid.\",\"location\":\"context\",\"lockedChannelID\":\"\"}]}]}";
		CheckExistingCartUIResponse  uiResponse = new CheckExistingCartUIResponse();
		CheckExistingCartPEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, CheckExistingCartPEGAResponse.class);
		util1.formatCheckExistingCartPegaResponse(pegaResponse,uiResponse);
	}
	
	@Test
	public void formatUpdateGiftItemResponseTest1() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\":null,\"serviceBody\":null,\"errors\":[{\"namespace\":\"CXP_Pega_BPM\",\"name\":\"Provided Case Id is resolved or Invalid.\",\"id\":\"1008\",\"debug_id\":\"20220920T052555.145 GMT||pega-010adfc9-5170-4da9-b381-0f7da3573a30-09192022-102555-140|soe-cart-2022.09.20.10.54.43-862.9557849437155\",\"message\":\"Invalid Case Id\",\"severity\":\"High\",\"errorCategory\":\"UNKNW\",\"details\":[{\"field\":\"Case ID\",\"value\":\"SOF-8624507-C01\",\"issue\":\"Either CaseID provided resolved or Invalid.\",\"location\":\"context\",\"lockedChannelID\":\"\"}]}]}";
		
		UpdateGiftItemUIResponse  uiResponse = new UpdateGiftItemUIResponse();
		UpdateGiftItemPEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, UpdateGiftItemPEGAResponse.class);
		util1.formatUpdateGiftItemResponse(pegaResponse,uiResponse);
	}
	
	@Test
	public void formatAddTrialContactInfoAndAddressPegaResponseTest() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"errors\":[{\"namespace\":\"CXP_Pega_BPM\",\"name\":\"Provided Case Id is resolved or Invalid.\",\"id\":\"1008\",\"debug_id\":\"20220920T052555.145 GMT||pega-010adfc9-5170-4da9-b381-0f7da3573a30-09192022-102555-140|soe-cart-2022.09.20.10.54.43-862.9557849437155\",\"message\":\"Invalid Case Id\",\"severity\":\"High\",\"errorCategory\":\"UNKNW\",\"details\":[{\"field\":\"Case ID\",\"value\":\"SOF-8624507-C01\",\"issue\":\"Either CaseID provided resolved or Invalid.\",\"location\":\"context\",\"lockedChannelID\":\"\"}]}],\"serviceHeader\":null,\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \" SOP-1583186-DEV3\",\"customerInfo\": {\"accountNumber\": \"07893451230-00001\",\"cartCreator\": \"2515813861\",\"processingMTN\": \"2515813860\"},\"cartInfo\": {\"cartId\": \"69a66ef4d-7e344dfb-2db299209-ea8333\",\"statusCode\": 1,\"statusMsg\": \"Success\",\"lines\": [{\"mtn\": \"6186979119\",\"lineNumber\": \"newLine1\",\"status\": 1,\"planValidationFailed\": false,\"lineActivityType\": \"AAL\",\"currentPlanType\": \"LLP\",\"devicePlanCompatible\": false}],\"preAuthSuccess\": false}},\"contextInfo\": {\"processAction\": \"\",\"processStep\": \"InterimPage\",\"callReason\": \" SalesOrderPurchase \"}}}}";
		AddTrialContactInfoAndAddressUIResponse  uiResponse = new AddTrialContactInfoAndAddressUIResponse();
		AddTrialContactInfoAndAddressPEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, AddTrialContactInfoAndAddressPEGAResponse.class);
		util1.formatAddTrialContactInfoAndAddressPegaResponse(pegaResponse,uiResponse);
	}
	
	@Test
	public void formatAffirmResponseTest() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\":null,\"serviceBody\":null,\"errors\":[{\"namespace\":\"CXP_Pega_BPM\",\"name\":\"Provided Case Id is resolved or Invalid.\",\"id\":\"1008\",\"debug_id\":\"20220920T052555.145 GMT||pega-010adfc9-5170-4da9-b381-0f7da3573a30-09192022-102555-140|soe-cart-2022.09.20.10.54.43-862.9557849437155\",\"message\":\"Invalid Case Id\",\"severity\":\"High\",\"errorCategory\":\"UNKNW\",\"details\":[{\"field\":\"Case ID\",\"value\":\"SOF-8624507-C01\",\"issue\":\"Either CaseID provided resolved or Invalid.\",\"location\":\"context\",\"lockedChannelID\":\"\"}]}]}";
		AffirmFinancingUIResponse  uiResponse = new AffirmFinancingUIResponse();
		AffirmFinancingPegaResponse  pegaResponse = mapper.readValue(pegaResponseString, AffirmFinancingPegaResponse.class);
		util.formatAffirmResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatAffirmResponseTest1() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-ECOM\", \"statusMsg\": \"PEGA generated message\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"sessionId\": \"\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"0\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \"SOP-1583186-DEV3\", \"customerInfo\": { \"accountNumber\": \"07893451230-00001\", \"cartCreator\": \"2515813861\", \"processingMTN\": \"2515813860\" }, \"cartInfo\": { \"cartId\": \"cff57848-8bbd-4c27-9afa-5bfd39c2b5ad\", \"statusCode\": 1, \"statusMsg\": \"SUCCESS\" } }, \"contextInfo\": { \"processAction\": \"\", \"processStep\": \"ShoppingCart\", \"availablePaths\": [ { \"path\": \"ShoppingCart`\" } ], \"callReason\": \" SalesOrderPurchase \" } } } }";
   	    AffirmFinancingUIResponse  uiResponse = new AffirmFinancingUIResponse();
		AffirmFinancingPegaResponse  pegaResponse = mapper.readValue(pegaResponseString, AffirmFinancingPegaResponse.class);
		util.formatAffirmResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatCreateCaseResponseTest() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-DOTCOM-BBP\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SuspendReconnect\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceRequest\":{},\"serviceResponse\":{\"context\": {\"caseId\": \"AC-1583186-DEV3\",\"customerInfo\": {\"accountNumber\": \"0219399801-00001\"},\"contextInfo\": {\"orderRestrictions\":null,\"processAction\": \"\",\"processStep\": \"DisconnectLine\"}}}}}";
		CreateCasePEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, CreateCasePEGAResponse.class);
		CreateCaseAndGetCustomerInfoUIResponse  uiResponse = new CreateCaseAndGetCustomerInfoUIResponse();
		try {
				util1.formatCreateCaseResponse(uiResponse,pegaResponse,"63311682147");
		} catch (NullPointerException e) {
				e.printStackTrace();
		}
	}
	
	@Test
	public void formatCreateCaseResponseTest1() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-DOTCOM-BBP\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SuspendReconnect\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceRequest\":{},\"serviceResponse\":{\"context\": {\"caseId\": \"AC-1583186-DEV3\",\"customerInfo\": {\"accountNumber\": \"0219399801-00001\"},\"contextInfo\":null}}}}";
		CreateCasePEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, CreateCasePEGAResponse.class);
		CreateCaseAndGetCustomerInfoUIResponse  uiResponse = new CreateCaseAndGetCustomerInfoUIResponse();
		util1.formatCreateCaseResponse(uiResponse,pegaResponse,"63311682147");
	}
	
	@Test
	public void formatCreateCaseResponseTest2() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-DOTCOM-BBP\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SuspendReconnect\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceRequest\":{},\"serviceResponse\":{\"context\": {\"caseId\": \"AC-1583186-DEV3\",\"customerInfo\": null,\"contextInfo\":null}}}}";
		CreateCasePEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, CreateCasePEGAResponse.class);
		CreateCaseAndGetCustomerInfoUIResponse  uiResponse = new CreateCaseAndGetCustomerInfoUIResponse();
		try {
				util1.formatCreateCaseResponse(uiResponse,pegaResponse,"63311682147");
		} catch (NullPointerException e) {
				e.printStackTrace();
		}
	}
	
	@Test
	public void formatCreateCaseResponseTest3() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-DOTCOM-BBP\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SuspendReconnect\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceRequest\":{},\"serviceResponse\":{\"context\":null}}}";
		CreateCasePEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, CreateCasePEGAResponse.class);
		CreateCaseAndGetCustomerInfoUIResponse  uiResponse = new CreateCaseAndGetCustomerInfoUIResponse();
		try {
				util1.formatCreateCaseResponse(uiResponse,pegaResponse,"63311682147");
		} catch (NullPointerException e) {
				e.printStackTrace();
		}
	}
	
	@Test
	public void formatCreateCaseResponseTest4() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-DOTCOM-BBP\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SuspendReconnect\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceRequest\":{},\"serviceResponse\":null}}";
		CreateCasePEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, CreateCasePEGAResponse.class);
		CreateCaseAndGetCustomerInfoUIResponse  uiResponse = new CreateCaseAndGetCustomerInfoUIResponse();
		util1.formatCreateCaseResponse(uiResponse,pegaResponse,"63311682147");
	}
	
	@Test
	public void formatCreateCaseResponseTest5() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-DOTCOM-BBP\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SuspendReconnect\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": null}";
		CreateCasePEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, CreateCasePEGAResponse.class);
		CreateCaseAndGetCustomerInfoUIResponse  uiResponse = new CreateCaseAndGetCustomerInfoUIResponse();
		util1.formatCreateCaseResponse(uiResponse,pegaResponse,"63311682147");
	}
	
	@Test
	public void formatCreateCaseResponseTest6() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\": null,\"serviceBody\": null}";
		CreateCasePEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, CreateCasePEGAResponse.class);
		CreateCaseAndGetCustomerInfoUIResponse  uiResponse = new CreateCaseAndGetCustomerInfoUIResponse();
		util1.formatCreateCaseResponse(uiResponse,pegaResponse,"63311682147");
	}
	
	@Test
	public void formataddPlanAndDeviceResponseTest() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"errors\":null,\"serviceHeader\":null,\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \" SOP-1583186-DEV3\",\"customerInfo\": {\"accountNumber\": \"07893451230-00001\",\"cartCreator\": \"2515813861\",\"processingMTN\": \"2515813860\"},\"cartInfo\": {\"cartId\": \"69a66ef4d-7e344dfb-2db299209-ea8333\",\"statusCode\": 1,\"statusMsg\": \"Success\",\"lines\": [{\"mtn\": \"6186979119\",\"lineNumber\": \"newLine1\",\"status\": 1,\"planValidationFailed\": false,\"lineActivityType\": \"AAL\",\"currentPlanType\": \"LLP\",\"devicePlanCompatible\": false}],\"preAuthSuccess\": false}},\"contextInfo\": {\"processAction\": \"\",\"processStep\": \"InterimPage\",\"callReason\": \" SalesOrderPurchase \"}}}}";
		AddPlanAndDevicePEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, AddPlanAndDevicePEGAResponse.class);
		AddPlanAndDeviceUIResponse  uiResponse = new AddPlanAndDeviceUIResponse();
		Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util1.formataddPlanAndDeviceResponse(uiResponse,pegaResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util1.formataddPlanAndDeviceResponse(uiResponse,pegaResponse);
		Assert.assertNotNull(pegaResponse);
		
	}
	
	@Test
	public void formatMoveDatesResponseTest1() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString =  "{\"serviceHeader\":null,\"serviceBody\":null,\"errors\":[{\"namespace\":\"CXP_Pega_BPM\",\"name\":\"Provided Case Id is resolved or Invalid.\",\"id\":\"1008\",\"debug_id\":\"20220920T052555.145 GMT||pega-010adfc9-5170-4da9-b381-0f7da3573a30-09192022-102555-140|soe-cart-2022.09.20.10.54.43-862.9557849437155\",\"message\":\"Invalid Case Id\",\"severity\":\"High\",\"errorCategory\":\"UNKNW\",\"details\":[{\"field\":\"Case ID\",\"value\":\"SOF-8624507-C01\",\"issue\":\"Either CaseID provided resolved or Invalid.\",\"location\":\"context\",\"lockedChannelID\":\"\"}]}]}";
		AddMoveDatesPegaResponse  pegaResponse = mapper.readValue(pegaResponseString, AddMoveDatesPegaResponse.class);
		AddMoveDatesUIResponse  uiResponse = new AddMoveDatesUIResponse();
		util1.formatMoveDatesResponse(uiResponse,pegaResponse);
	}

	@Test
	public void formatUpdatePlanChangesTest() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString =  "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"Movers\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"processStep\":\"OrderReview-Shipping-Payment-Agreement\",\"callReason\":\"FiveGMovers\"},\"caseId\":\"MOV-2049711958-E01\",\"customerInfo\":{\"accountNumber\":\"0526690813-00001\"},\"processMTNList\":[{\"mtn\":\"5623201991\",\"completedprocessSteps\":[\"DateSelection\"]}],\"cartInfo\":{\"cartId\":\"a9a63f4d-008c-40a4-b6e2-6a4488df08ca\",\"effectiveDateDetails\":{\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"02/27/2024\",\"currentBillCycleBeginDate\":\"01/27/2024\",\"currentBillCycleEndDate\":\"02/26/2024\",\"nextBillCycleBeginDate\":\"02/27/2024\",\"nextBillCycleEndDate\":\"03/26/2024\",\"onDemandDate\":\"02/19/2024\",\"onDemandRangeInDays\":\"45\",\"selectedDate\":\"\",\"userSelectedDate\":\"\",\"onDemandOverageInd\":null,\"isOnDemandAllowed\":true,\"isBackDateAllowed\":false,\"isFutureDateAllowed\":true,\"onDemandAllowed\":false,\"backDateAllowed\":false,\"futureDateAllowed\":false},\"lines\":[{\"mtn\":\"3157617637\",\"sortingNumber\":0,\"status\":1,\"planValidationFailed\":false,\"currentPlanType\":\"LLP\",\"plan\":{\"id\":\"67571\",\"price\":\"60.00\",\"discountedPrice\":null,\"promos\":null,\"discountsResponse\":null},\"correlationID\":\"192000000001027196\",\"isFreeAppleMusicLoss\":\"N\",\"devicePlanCompatible\":true,\"fiveGUpSell\":false,\"tabletJetpackDiscountLoss\":\"N\",\"planQualifiedForPromotion\":false,\"displayHumWiFi\":false,\"pairingInfo\":{\"newPairedPhone\":null,\"currentPairedPhone\":null,\"benefitPairType\":null,\"grantorLineItem\":null,\"granteeLineItem\":null,\"grantorPlan\":null},\"droppedProducts\":[],\"downPaymentAmtApplied\":0.0,\"firstMonthInstallment\":0.0,\"isVzCloudGain600GB\":\"N\",\"isSecondNumber\":false,\"fiveGPlanAdded\":false,\"fiveGMUCEligible\":false,\"isAppendedLine\":false,\"disqualifiedPropositions\":[],\"qualifiedPropositions\":[],\"isFreeAppleMusicGain\":\"N\",\"isFreeAppleMusicLossNM\":\"N\",\"isDeviceSelected\":false,\"showGlobalChoiceOffer\":false,\"protectionNotRequired\":false,\"tabletJetpackDiscountGain\":\"N\",\"featureMessages\":[{\"name\":\"VZCLOUD_5GUNLIMITED\",\"action\":\"DROP\",\"nextPrice\":null,\"fields\":null},{\"name\":\"HOME_INTERNET_DISCOUNT\",\"action\":\"STEP_DOWN\",\"nextPrice\":null,\"fields\":null}],\"networkBandwidthTypeChanged\":false,\"lacWithNumberShare\":false,\"activateSecDeviceNumShareElig\":false,\"numberShareOverlay\":false,\"gs4Device\":false,\"rioDevice\":false,\"simCompatibility\":false,\"eSimCapable\":false,\"networkBandwidthType\":\"CBD\",\"prevNetworkBandwidthType\":\"CBD\",\"totalDueMonthly\":0.0,\"planTradeInEligible\":false,\"spos\":[{\"id\":\"1747\",\"actionIndicator\":\"Z\",\"autoAttached\":true,\"description\":\"Disney Bundle Included with Plan\",\"spoBillDesc\":\"DISNEY BUNDLE INCLUDED W PLAN\",\"price\":\"0.00\",\"success\":true,\"accountLevel\":true,\"sddSetupEligible\":false,\"categoryCodes\":[\"BYPVREQUAL\",\"DISNEY\",\"NOSPLANRQD\",\"AS\",\"BOOKTAX\",\"DISNEYALL\",\"SUBELIG\",\"BYPGRPREQL\",\"BYPACST189\",\"VZVIDEO\"],\"categoryClassCodes\":[],\"parentProductsSorIds\":[\"DISNEY\",\"VZVIDEO\",\"BOOKTAX\",\"BYPGRPREQL\",\"SUBELIG\",\"NOSPLANRQD\",\"BYPACST189\",\"AS\",\"BYPVREQUAL\",\"DISNEYALL\"],\"endDate\":\"12/31/9999\",\"effectiveDate\":\"02/24/2022\",\"is5GBolt\":false},{\"id\":\"2162\",\"actionIndicator\":\"D\",\"autoAttached\":true,\"description\":\"Service ID Indicator 5G C-band Plus\",\"spoBillDesc\":\"SERVICE ID INDICATOR 5GC PLUS\",\"price\":\"0.00\",\"success\":true,\"sddSetupEligible\":false,\"categoryCodes\":[\"SERVICEID\",\"MI\"],\"categoryClassCodes\":[],\"parentProductsSorIds\":[\"MI\",\"SERVICEID\"],\"endDate\":\"02/18/2024\",\"effectiveDate\":\"12/20/2023\",\"is5GBolt\":false},{\"id\":\"2196\",\"actionIndicator\":\"D\",\"autoAttached\":true,\"description\":\"3-Year Price Guarantee\",\"spoBillDesc\":\"3 YEAR PRICE GUARANTEE\",\"price\":\"0.00\",\"success\":true,\"sddSetupEligible\":false,\"categoryCodes\":[\"PLNPRCGRNT\",\"MI\"],\"categoryClassCodes\":[],\"parentProductsSorIds\":[\"MI\",\"PLNPRCGRNT\"],\"endDate\":\"02/18/2024\",\"effectiveDate\":\"12/20/2023\",\"is5GBolt\":false},{\"id\":\"2462\",\"actionIndicator\":\"D\",\"autoAttached\":true,\"description\":\"5G HOME 5G CORE\",\"spoBillDesc\":\"5G HOME 5G CORE\",\"price\":\"0.00\",\"success\":true,\"sddSetupEligible\":false,\"categoryCodes\":[\"5GCOREPROV\",\"BYPGRPQUAL\",\"BYPPVQUAL\",\"TP\"],\"categoryClassCodes\":[],\"parentProductsSorIds\":[\"TP\",\"BYPGRPQUAL\",\"BYPPVQUAL\",\"5GCOREPROV\"],\"endDate\":\"02/18/2024\",\"effectiveDate\":\"12/20/2023\",\"is5GBolt\":false},{\"id\":\"2722\",\"actionIndicator\":\"D\",\"autoAttached\":true,\"description\":\"MOBILE + HOME DISCOUNT\",\"spoBillDesc\":\"MOBILE + HOME DISCOUNT\",\"price\":\"-25.00\",\"success\":true,\"sddSetupEligible\":false,\"categoryCodes\":[\"EBBBEFORE\",\"VFBEFORE\",\"BYPPVQUAL\",\"FWADISCNT\",\"BYPVREQUAL\",\"SRVCDISC\",\"DISCPROMO\",\"FWABEFORE\",\"PLANDISC\",\"ULPLANDISC\",\"BYPGRPQUAL\",\"BYPGRPREQL\",\"5GLOYALTY\"],\"categoryClassCodes\":[],\"parentProductsSorIds\":[\"BYPGRPQUAL\",\"VFBEFORE\",\"ULPLANDISC\",\"BYPVREQUAL\",\"DISCPROMO\",\"5GLOYALTY\",\"FWABEFORE\",\"PLANDISC\",\"BYPPVQUAL\",\"BYPGRPREQL\",\"FWADISCNT\",\"EBBBEFORE\",\"SRVCDISC\"],\"endDate\":\"02/18/2024\",\"effectiveDate\":\"12/20/2023\",\"is5GBolt\":false},{\"id\":\"732\",\"actionIndicator\":\"Z\",\"autoAttached\":true,\"description\":\"CDMA-LESS ROAM TIER OVERRIDE\",\"spoBillDesc\":\"CDMA-LESS ROAM TIER OVERRIDE\",\"price\":\"0.00\",\"success\":true,\"sddSetupEligible\":false,\"categoryCodes\":[\"TP\"],\"categoryClassCodes\":[],\"parentProductsSorIds\":[\"TP\"],\"endDate\":\"12/31/9999\",\"effectiveDate\":\"12/20/2023\",\"is5GBolt\":false},{\"id\":\"2600\",\"actionIndicator\":\"Z\",\"autoAttached\":true,\"description\":\"5G HOME 5G CORE SA\",\"spoBillDesc\":\"5G CORE SA\",\"price\":\"0.00\",\"success\":true,\"sddSetupEligible\":false,\"categoryCodes\":[\"TP\"],\"categoryClassCodes\":[],\"parentProductsSorIds\":[\"TP\"],\"endDate\":\"12/31/9999\",\"effectiveDate\":\"12/20/2023\",\"is5GBolt\":false},{\"id\":\"2824\",\"actionIndicator\":\"Z\",\"autoAttached\":true,\"description\":\"5-Year Price Guarantee\",\"spoBillDesc\":\"5 YEAR PRICE GUARANTEE\",\"price\":\"0.00\",\"success\":true,\"sddSetupEligible\":false,\"categoryCodes\":[\"PLNPRCGRNT\",\"MI\"],\"categoryClassCodes\":[],\"parentProductsSorIds\":[\"MI\",\"PLNPRCGRNT\"],\"endDate\":\"12/26/2028\",\"effectiveDate\":\"12/20/2023\",\"is5GBolt\":false},{\"id\":\"2195\",\"actionIndicator\":\"A\",\"autoAttached\":true,\"description\":\"2-Year Price Guarantee\",\"spoBillDesc\":\"2 YEAR PRICE GUARANTEE\",\"price\":\"0.00\",\"success\":true,\"sddSetupEligible\":false,\"categoryCodes\":[\"PLNPRCGRNT\",\"MI\"],\"categoryClassCodes\":[],\"parentProductsSorIds\":[\"MI\",\"PLNPRCGRNT\"],\"endDate\":\"02/26/2026\",\"effectiveDate\":\"02/19/2024\",\"is5GBolt\":false},{\"id\":\"2725\",\"actionIndicator\":\"A\",\"autoAttached\":true,\"description\":\"MOBILE + HOME DISCOUNT\",\"spoBillDesc\":\"MOBILE + HOME DISCOUNT\",\"price\":\"-15.00\",\"success\":true,\"sddSetupEligible\":false,\"categoryCodes\":[\"EBBBEFORE\",\"VFBEFORE\",\"BYPPVQUAL\",\"FWADISCNT\",\"BYPVREQUAL\",\"SRVCDISC\",\"DISCPROMO\",\"FWABEFORE\",\"PLANDISC\",\"ULPLANDISC\",\"BYPGRPQUAL\",\"BYPGRPREQL\",\"5GLOYALTY\"],\"categoryClassCodes\":[],\"parentProductsSorIds\":[\"BYPGRPQUAL\",\"VFBEFORE\",\"ULPLANDISC\",\"BYPVREQUAL\",\"DISCPROMO\",\"5GLOYALTY\",\"FWABEFORE\",\"PLANDISC\",\"BYPPVQUAL\",\"BYPGRPREQL\",\"FWADISCNT\",\"EBBBEFORE\",\"SRVCDISC\"],\"endDate\":\"12/31/9999\",\"effectiveDate\":\"02/19/2024\",\"is5GBolt\":false},{\"id\":\"2732\",\"actionIndicator\":\"A\",\"autoAttached\":true,\"description\":\"5G HOME 5G CORE\",\"spoBillDesc\":\"5G HOME 5G CORE\",\"price\":\"0.00\",\"success\":true,\"sddSetupEligible\":false,\"categoryCodes\":[\"5GCOREPROV\",\"BYPGRPQUAL\",\"BYPPVQUAL\",\"TP\"],\"categoryClassCodes\":[],\"parentProductsSorIds\":[\"TP\",\"BYPGRPQUAL\",\"BYPPVQUAL\",\"5GCOREPROV\"],\"endDate\":\"12/31/9999\",\"effectiveDate\":\"02/19/2024\",\"is5GBolt\":false},{\"id\":\"2776\",\"actionIndicator\":\"A\",\"autoAttached\":true,\"description\":\"SERVICE ID INDICATOR 5GC\",\"spoBillDesc\":\"SERVICE ID INDICATOR 5GC\",\"price\":\"0.00\",\"success\":true,\"sddSetupEligible\":false,\"categoryCodes\":[\"SERVICEID\",\"MI\"],\"categoryClassCodes\":[],\"parentProductsSorIds\":[\"MI\",\"SERVICEID\"],\"endDate\":\"12/31/9999\",\"effectiveDate\":\"02/19/2024\",\"is5GBolt\":false},{\"id\":\"2817\",\"actionIndicator\":\"A\",\"autoAttached\":true,\"description\":\"LRA BLOCK $0\",\"spoBillDesc\":\"LRA BLOCK\",\"price\":\"0.00\",\"success\":true,\"sddSetupEligible\":false,\"categoryCodes\":[\"TP\"],\"categoryClassCodes\":[],\"parentProductsSorIds\":[\"TP\"],\"endDate\":\"12/31/9999\",\"effectiveDate\":\"02/19/2024\",\"is5GBolt\":false},{\"id\":\"2819\",\"actionIndicator\":\"A\",\"autoAttached\":true,\"description\":\"QCI 132 $0\",\"spoBillDesc\":\"QCI 132 $0\",\"price\":\"0.00\",\"success\":true,\"sddSetupEligible\":false,\"categoryCodes\":[\"TP\"],\"categoryClassCodes\":[],\"parentProductsSorIds\":[\"TP\"],\"endDate\":\"12/31/9999\",\"effectiveDate\":\"02/19/2024\",\"is5GBolt\":false}],\"sfos\":[{\"id\":\"48526\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"Text Messaging Pay Per Message\",\"sfoBillDesc\":\"TXT MSG W PER MSG CHARGES\",\"price\":\"0.00\",\"embeddedFeatures\":[{\"featureId\":\"61\",\"description\":\"TXT MSG W PER MSG CHARGES\",\"featureTypeCode\":\"\"}],\"hotlineMtn\":[],\"success\":true,\"defaultPrice\":\"0.00\",\"isSfoAddedDueToSpoConflicts\":false,\"sfoStatusInd\":\"B\",\"displayHumWiFi\":false,\"sddSetupEligible\":false,\"sfoDisplayInd\":\"A\"},{\"id\":\"48553\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"Streamlined Billing\",\"sfoBillDesc\":\"STREAMLINED BILLING - $0\",\"price\":\"0.00\",\"embeddedFeatures\":[{\"featureId\":\"612\",\"description\":\"STREAMLINE BILLING\",\"featureTypeCode\":\"\"}],\"hotlineMtn\":[],\"success\":true,\"defaultPrice\":\"0.00\",\"isSfoAddedDueToSpoConflicts\":false,\"sfoStatusInd\":\"O\",\"displayHumWiFi\":false,\"sddSetupEligible\":false,\"sfoDisplayInd\":\"S\"},{\"id\":\"54307\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"Block Messaging\",\"sfoBillDesc\":\"BLOCK TEXT MESSAGING\",\"price\":\"0.00\",\"embeddedFeatures\":[{\"featureId\":\"403\",\"description\":\"TXT MSG-SERVICE BLOCKED\",\"featureTypeCode\":\"\"}],\"hotlineMtn\":[],\"success\":true,\"defaultPrice\":\"0.00\",\"isSfoAddedDueToSpoConflicts\":false,\"sfoStatusInd\":\"O\",\"displayHumWiFi\":false,\"sddSetupEligible\":false,\"sfoDisplayInd\":\"Q\"},{\"id\":\"68872\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"CALL DELIVERY\",\"sfoBillDesc\":\"CALL DELIVERY\",\"price\":\"0.00\",\"embeddedFeatures\":[{\"featureId\":\"16\",\"description\":\"CALL DELIVERY\",\"featureTypeCode\":\"\"}],\"hotlineMtn\":[],\"success\":true,\"defaultPrice\":\"0.00\",\"isSfoAddedDueToSpoConflicts\":false,\"sfoStatusInd\":\"O\",\"displayHumWiFi\":false,\"sddSetupEligible\":false,\"sfoDisplayInd\":\"S\"},{\"id\":\"70421\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"Block Voice Calls - Hotline\",\"sfoBillDesc\":\"BLOCK VOICE-HOTLN (PKT DATA)\",\"price\":\"0.00\",\"embeddedFeatures\":[{\"featureId\":\"1112\",\"description\":\"PACKET DATA ONLY\",\"featureTypeCode\":\"HLCS\"}],\"hotlineMtn\":[],\"success\":true,\"defaultPrice\":\"0.00\",\"isSfoAddedDueToSpoConflicts\":false,\"sfoStatusInd\":\"O\",\"displayHumWiFi\":false,\"sddSetupEligible\":false,\"sfoDisplayInd\":\"S\"},{\"id\":\"78003\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"4G BLOCK DATA ROAM (M)\",\"sfoBillDesc\":\"4G BLOCK DATA ROAM (M)\",\"price\":\"0.00\",\"embeddedFeatures\":[{\"featureId\":\"3706\",\"description\":\"4G BLOCK DATA ROAM (M)\",\"featureTypeCode\":\"\"}],\"hotlineMtn\":[],\"success\":true,\"defaultPrice\":\"0.00\",\"isSfoAddedDueToSpoConflicts\":false,\"sfoStatusInd\":\"B\",\"displayHumWiFi\":false,\"sddSetupEligible\":false,\"sfoDisplayInd\":\"Q\"},{\"id\":\"83856\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"CDMA-LESS DEVICE PROVISIONING\",\"sfoBillDesc\":\"CDMA-LESS DEVICE PROVISIONING\",\"price\":\"0.00\",\"embeddedFeatures\":[{\"featureId\":\"5389\",\"description\":\"CDMA-LESS PROVISIONING\",\"featureTypeCode\":\"\"}],\"hotlineMtn\":[],\"success\":true,\"defaultPrice\":\"0.00\",\"isSfoAddedDueToSpoConflicts\":false,\"sfoStatusInd\":\"O\",\"displayHumWiFi\":false,\"sddSetupEligible\":false,\"sfoDisplayInd\":\"Q\"},{\"id\":\"85503\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"Unlimited Data\",\"sfoBillDesc\":\"UNLIMITED DATA\",\"price\":\"0.00\",\"embeddedFeatures\":[{\"featureId\":\"5913\",\"description\":\"UNL DATA B2B GB\",\"featureTypeCode\":\"1XKB\"}],\"hotlineMtn\":[],\"success\":true,\"defaultPrice\":\"0.00\",\"isSfoAddedDueToSpoConflicts\":false,\"sfoStatusInd\":\"B\",\"displayHumWiFi\":false,\"sddSetupEligible\":false,\"sfoDisplayInd\":\"Q\"},{\"id\":\"86112\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"5G IPv4/IPv6 IP (Dynamic IP)\",\"sfoBillDesc\":\"5G IPV4/IPV6 IP\",\"price\":\"0.00\",\"embeddedFeatures\":[{\"featureId\":\"6102\",\"description\":\"5G IPV4/IPV6 FRAMED POOL\",\"featureTypeCode\":\"\"}],\"hotlineMtn\":[],\"success\":true,\"defaultPrice\":\"0.00\",\"isSfoAddedDueToSpoConflicts\":false,\"sfoStatusInd\":\"O\",\"displayHumWiFi\":false,\"sddSetupEligible\":false,\"sfoDisplayInd\":\"Q\"},{\"id\":\"86926\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"5G LINE OF SERVICE\",\"sfoBillDesc\":\"5G LINE OF SERVICE\",\"price\":\"0.00\",\"embeddedFeatures\":[{\"featureId\":\"6490\",\"description\":\"5G FCL LINE SERVICE FCL\",\"featureTypeCode\":\"FW5GF\"}],\"hotlineMtn\":[],\"success\":true,\"defaultPrice\":\"0.00\",\"isSfoAddedDueToSpoConflicts\":false,\"sfoStatusInd\":\"O\",\"displayHumWiFi\":false,\"sddSetupEligible\":false,\"sfoDisplayInd\":\"Q\"},{\"id\":\"86928\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"5G DATA TRANSPORT\",\"sfoBillDesc\":\"5G DATA TRANSPORT\",\"price\":\"0.00\",\"embeddedFeatures\":[{\"featureId\":\"6492\",\"description\":\"5G FCL DATA TRANSPORT\",\"featureTypeCode\":\"\"}],\"hotlineMtn\":[],\"success\":true,\"defaultPrice\":\"0.00\",\"isSfoAddedDueToSpoConflicts\":false,\"sfoStatusInd\":\"B\",\"displayHumWiFi\":false,\"sddSetupEligible\":false,\"sfoDisplayInd\":\"Q\"},{\"id\":\"87800\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"LTE PROVISIONING\",\"sfoBillDesc\":\"LTE PROVISIONING\",\"price\":\"0.00\",\"embeddedFeatures\":[{\"featureId\":\"6898\",\"description\":\"WW LTE PROVISIONING\",\"featureTypeCode\":\"4GWWD\"}],\"hotlineMtn\":[],\"success\":true,\"defaultPrice\":\"0.00\",\"isSfoAddedDueToSpoConflicts\":false,\"sfoStatusInd\":\"B\",\"displayHumWiFi\":false,\"sddSetupEligible\":false,\"sfoDisplayInd\":\"A\"},{\"id\":\"88855\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"HSS PROVISIONING\",\"sfoBillDesc\":\"HSS PROVISIONING\",\"price\":\"0.00\",\"embeddedFeatures\":[{\"featureId\":\"7430\",\"description\":\"5G HSS PROVISIONING WK4\",\"featureTypeCode\":\"\"},{\"featureId\":\"7429\",\"description\":\"5G HSS PROVISIONING QX2\",\"featureTypeCode\":\"\"},{\"featureId\":\"7428\",\"description\":\"5G HSS PROVISIONING QFZ\",\"featureTypeCode\":\"\"},{\"featureId\":\"5683\",\"description\":\"HSS ALI PROVISIONING\",\"featureTypeCode\":\"\"},{\"featureId\":\"5430\",\"description\":\"HSS SY PROVISOINING\",\"featureTypeCode\":\"\"}],\"hotlineMtn\":[],\"success\":true,\"defaultPrice\":\"0.00\",\"isSfoAddedDueToSpoConflicts\":false,\"sfoStatusInd\":\"D\",\"displayHumWiFi\":false,\"sddSetupEligible\":false,\"sfoDisplayInd\":\"T\"},{\"id\":\"88920\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"VERIZON CLOUD UNL 5G OWNER $0\",\"sfoBillDesc\":\"VERIZON CLOUD UNL 5G OWNER $0\",\"price\":\"0.00\",\"embeddedFeatures\":[{\"featureId\":\"7467\",\"description\":\"VERIZON CLOUD UNL OWNER\",\"featureTypeCode\":\"\"}],\"hotlineMtn\":[],\"success\":true,\"defaultPrice\":\"0.00\",\"isSfoAddedDueToSpoConflicts\":false,\"sfoStatusInd\":\"T\",\"displayHumWiFi\":false,\"sddSetupEligible\":false,\"sfoDisplayInd\":\"T\"},{\"id\":\"88966\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"5G INTERNET ACCESS\",\"sfoBillDesc\":\"5G INTERNET ACCESS\",\"price\":\"0.00\",\"embeddedFeatures\":[{\"featureId\":\"7495\",\"description\":\"5G INTERNET APN J5G\",\"featureTypeCode\":\"\"}],\"hotlineMtn\":[],\"success\":true,\"defaultPrice\":\"0.00\",\"isSfoAddedDueToSpoConflicts\":false,\"sfoStatusInd\":\"B\",\"displayHumWiFi\":false,\"sddSetupEligible\":false,\"sfoDisplayInd\":\"Q\"},{\"id\":\"89090\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"VERIZON CLOUD TRIGGER\",\"sfoBillDesc\":\"VERIZON CLOUD TRIGGER\",\"price\":\"0.00\",\"embeddedFeatures\":[{\"featureId\":\"7568\",\"description\":\"VERIZON CLOUD TRIGGER HOM\",\"featureTypeCode\":\"\"}],\"hotlineMtn\":[],\"success\":true,\"defaultPrice\":\"0.00\",\"isSfoAddedDueToSpoConflicts\":false,\"sfoStatusInd\":\"D\",\"displayHumWiFi\":false,\"sddSetupEligible\":false,\"sfoDisplayInd\":\"T\"},{\"id\":\"89405\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"5G CORE TRIGGER\",\"sfoBillDesc\":\"5G CORE TRIGGER\",\"price\":\"0.00\",\"embeddedFeatures\":[{\"featureId\":\"7798\",\"description\":\"5G CORE TRIGGER\",\"featureTypeCode\":\"\"}],\"hotlineMtn\":[],\"success\":true,\"defaultPrice\":\"0.00\",\"isSfoAddedDueToSpoConflicts\":false,\"sfoStatusInd\":\"O\",\"displayHumWiFi\":false,\"sddSetupEligible\":false,\"sfoDisplayInd\":\"S\"},{\"id\":\"89907\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"5G HSS PROVISIONING\",\"sfoBillDesc\":\"5G HSS PROVISIONING\",\"price\":\"0.00\",\"embeddedFeatures\":[{\"featureId\":\"7428\",\"description\":\"5G HSS PROVISIONING QFZ\",\"featureTypeCode\":\"\"},{\"featureId\":\"8050\",\"description\":\"HSS WK9 PROVISIONING\",\"featureTypeCode\":\"\"},{\"featureId\":\"8053\",\"description\":\"HSS QXF PROVISIONING\",\"featureTypeCode\":\"\"},{\"featureId\":\"5683\",\"description\":\"HSS ALI PROVISIONING\",\"featureTypeCode\":\"\"},{\"featureId\":\"5430\",\"description\":\"HSS SY PROVISOINING\",\"featureTypeCode\":\"\"}],\"hotlineMtn\":[],\"success\":true,\"defaultPrice\":\"0.00\",\"isSfoAddedDueToSpoConflicts\":false,\"sfoStatusInd\":\"A\",\"displayHumWiFi\":false,\"sddSetupEligible\":false,\"sfoDisplayInd\":\"A\"},{\"id\":\"89963\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"RTR PROVISIONING\",\"sfoBillDesc\":\"RTR PROVISIONING\",\"price\":\"0.00\",\"embeddedFeatures\":[{\"featureId\":\"7343\",\"description\":\"5G RTR RMA\",\"featureTypeCode\":\"RTRU5G\"},{\"featureId\":\"7342\",\"description\":\"5G/4G  RTR COUNTER MBC\",\"featureTypeCode\":\"\"}],\"hotlineMtn\":[],\"success\":true,\"defaultPrice\":\"0.00\",\"isSfoAddedDueToSpoConflicts\":false,\"sfoStatusInd\":\"B\",\"displayHumWiFi\":false,\"sddSetupEligible\":false,\"sfoDisplayInd\":\"A\"}],\"bundleBuilderFlow\":false,\"offerInterstitial\":false,\"userSelectedPlan\":false,\"ltehomeLine\":false,\"monthlyInstallment\":0.0,\"is5GBoltEligible\":false,\"is5gUltraWidebandDrop\":\"N\",\"is5GDevice\":false,\"isBundleBuilderFlow\":false,\"isOfferInterstitial\":false}],\"autoPayEnrollmentDetails\":{\"isAutoPayEnrolled\":\"N\",\"isPaperLessEnrolled\":\"Y\",\"isAutoPayPaperLessDiscountEligible\":\"Y\",\"isCustomerEnrolledForAutopay\":\"Y\",\"totalEligibleAutoPayPaperLessDiscount\":\"70.00\"},\"preAuthSuccess\":false,\"spoLossReferenceDataList\":[],\"sfoLossReferenceDataList\":[],\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"tabletJetpackDiscountMultiLineLoss\":\"N\",\"financeLimitExceeded\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":0.0,\"agreementNumber\":0,\"expressCheckout\":true,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"discountGainIndicators\":[],\"discountLossIndicators\":[],\"validateOrderStatus\":false,\"subscriptionInfos\":[],\"showIntercept\":false,\"instantCreditEligible\":false,\"instantCreditValue\":0.0,\"showICPage\":false,\"preConfiguredCartType\":\"BAU\",\"preConfiguredCartTypeDuringAddDevice\":\"BAU\",\"cartItemCount\":0,\"spoGainReferenceDataList\":[],\"sfoGainReferenceDataList\":[],\"numOfLinesWithDevices\":0,\"availableSlotsForGrantee\":\"1\",\"totalDueToday\":0.0,\"totalDueMonthly\":0.0,\"planSelectionRequired\":false,\"creditApplicationNum\":0,\"showGlobalChoiceOffer\":false,\"deviceCount\":0,\"affirmPaymentComplete\":false,\"upcomingAppointmentsAvailable\":false,\"relinquishTradeAmount\":0.0,\"vvcBannerInd\":false,\"autoPairNumberShare\":false,\"lineDevices\":[{\"mtn\":\"3157617637\",\"deviceCategory\":null,\"promoIntent\":null,\"lineActivityType\":\"CPC\",\"serviceInfo\":{\"pricePlanInfo\":{\"pricePlanCode\":\"67576\",\"categoryCode\":\"74\"},\"newPricePlanInfo\":{\"pricePlanCode\":\"67571\",\"categoryCode\":\"74\"},\"selectedFeaturesList\":{\"visFeature\":[]}},\"multiLineSeqNumber\":1}],\"hasSharePlan\":false,\"paymentUpdated\":false,\"featureMessages\":[],\"accountLevelProtectionExistsInProfile\":false,\"emptyLine\":false,\"noPromoForBatteryDamage\":false,\"isRemoveTradeIn\":false,\"isIspuShippingWarningMsg\":false}}},\"serviceRequest\":{\"context\":{\"contextInfo\":{}}}}}\n";
		MoversUpdatePlanPegaResponse pegaResponse = mapper.readValue(pegaResponseString, MoversUpdatePlanPegaResponse.class);
		MoversUpdatePlanResponse uiResponse = new MoversUpdatePlanResponse();
		Error error =new Error();
		 error.setMessage("abc type error");
		 List<Error> list = new ArrayList<>();
		 list.add(error);
		 pegaResponse.setErrors(list);
		 util1.formatUpdatePlanResponse(uiResponse, pegaResponse);
		 Assert.assertNotNull(pegaResponse);
		 pegaResponse.setServiceBody(null);
		 pegaResponse.setServiceHeader(null);
		 pegaResponse.setErrors(null);
		 util1.formatUpdatePlanResponse(uiResponse, pegaResponse);
		 Assert.assertNotNull(pegaResponse);
	}
	
	@Test
	public void formataddPlanAndDeviceFromCRMResponseTest1() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString =  "{\"serviceHeader\":null,\"serviceBody\":null,\"errors\":[{\"namespace\":\"CXP_Pega_BPM\",\"name\":\"Provided Case Id is resolved or Invalid.\",\"id\":\"1008\",\"debug_id\":\"20220920T052555.145 GMT||pega-010adfc9-5170-4da9-b381-0f7da3573a30-09192022-102555-140|soe-cart-2022.09.20.10.54.43-862.9557849437155\",\"message\":\"Invalid Case Id\",\"severity\":\"High\",\"errorCategory\":\"UNKNW\",\"details\":[{\"field\":\"Case ID\",\"value\":\"SOF-8624507-C01\",\"issue\":\"Either CaseID provided resolved or Invalid.\",\"location\":\"context\",\"lockedChannelID\":\"\"}]}]}";
		
		CrmRetrieveCartPegaResponse  pegaResponse = mapper.readValue(pegaResponseString, CrmRetrieveCartPegaResponse.class);
		CrmRetrieveCartUIResponse  uiResponse = new CrmRetrieveCartUIResponse();
		util1.formataddPlanAndDeviceFromCRMResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formataddPlanAndDeviceFromCRMResponseTest2() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString =  "{\"serviceHeader\":{\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"GetCases\",\"userId\":\"\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"customerInfo\":{\"customerType\":\"N\",\"cartId\":\"89859655-b722-4199-955a-6160389d03f2\",\"accountNumber\":\"\",\"cartCreator\":\"SIT1-NSA-29-10-12-13-PM-D\",\"emailId\":\"\",\"registerNumber\":0},\"cases\":[{\"processStep\":\"ShoppingCart\",\"preConfiguredCartTypeDuringAddDevice\":\"BAU\",\"pxUpdateDateTime\":\"20211029T064236.293 GMT\",\"emailId\":\"\",\"channelId\":\"VZW-DOTCOM\",\"quoteId\":\"\",\"amRole\":\"\",\"callReason\":\"Sales Order Purchase\",\"pxCreateDateTime\":\"20211029T064227.933 GMT\",\"lineCreator\":\"\",\"lastActiveChannelID\":\"VZW-DOTCOM\",\"explicit_lock\":\"\"}]}}}}";
		CrmRetrieveCartPegaResponse  pegaResponse = mapper.readValue(pegaResponseString, CrmRetrieveCartPegaResponse.class);
		CrmRetrieveCartUIResponse  uiResponse = new CrmRetrieveCartUIResponse();
		util1.formataddPlanAndDeviceFromCRMResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatInitiateValidateDeviceSimResponseTest3() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\":null,\"serviceBody\":{\"serviceResponse\":{\"context\":null}},\"errors\":[{\"namespace\":\"CXP_Pega_BPM\",\"name\":\"Provided Case Id is resolved or Invalid.\",\"id\":\"1008\",\"debug_id\":\"20220920T052555.145 GMT||pega-010adfc9-5170-4da9-b381-0f7da3573a30-09192022-102555-140|soe-cart-2022.09.20.10.54.43-862.9557849437155\",\"message\":\"Invalid Case Id\",\"severity\":\"High\",\"errorCategory\":\"UNKNW\",\"details\":[{\"field\":\"Case ID\",\"value\":\"SOF-8624507-C01\",\"issue\":\"Either CaseID provided resolved or Invalid.\",\"location\":\"context\",\"lockedChannelID\":\"\"}]}]}";
		InitiateValidateDeviceSimUIResponse  uiResponse = new InitiateValidateDeviceSimUIResponse();
		InitiateValidateDeviceSimPEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, InitiateValidateDeviceSimPEGAResponse.class);
		util1.formatInitiateValidateDeviceSimResponse(uiResponse,pegaResponse);
	}
	
	@Test
	public void formatInitiateValidateDeviceSimResponseTest4() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{\"serviceHeader\":null,\"serviceBody\":{\"serviceResponse\":null},\"errors\":[{\"namespace\":\"CXP_Pega_BPM\",\"name\":\"Provided Case Id is resolved or Invalid.\",\"id\":\"1008\",\"debug_id\":\"20220920T052555.145 GMT||pega-010adfc9-5170-4da9-b381-0f7da3573a30-09192022-102555-140|soe-cart-2022.09.20.10.54.43-862.9557849437155\",\"message\":\"Invalid Case Id\",\"severity\":\"High\",\"errorCategory\":\"UNKNW\",\"details\":[{\"field\":\"Case ID\",\"value\":\"SOF-8624507-C01\",\"issue\":\"Either CaseID provided resolved or Invalid.\",\"location\":\"context\",\"lockedChannelID\":\"\"}]}]}";
		InitiateValidateDeviceSimUIResponse  uiResponse = new InitiateValidateDeviceSimUIResponse();
		InitiateValidateDeviceSimPEGAResponse  pegaResponse = mapper.readValue(pegaResponseString, InitiateValidateDeviceSimPEGAResponse.class);
		util1.formatInitiateValidateDeviceSimResponse(uiResponse,pegaResponse);
	}

	public void formatAddZipcodeResponse() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-DOTCOM-BBP\", \"statusMsg\": \"PEGA generated message\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"sessionId\": \"\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"0\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \"SOP-1583186-DEV3\", \"customerInfo\": { \"accountNumber\": \"07893451230-00001\", \"cartCreator\": \"2515813861\",\"customerType\":\"N\", \"processingMTN\": \"newLine1\" }, \"cartInfo\": { \"cartId\": \"cff57848-8bbd-4c27-9afa-5bfd39c2b5ad\", \"statusCode\": 1, \"statusMsg\": \"SUCCESS\" } }, \"contextInfo\": { \"processAction\": \"\", \"processStep\": \"PlanSelection\", \"availablePaths\": [ { \"path\": \"PlanCategoryPage`\" } ], \"callReason\": \" SalesOrderPurchase \" } } } }";
		BBPAddZipcodeResponse uiResponse = new BBPAddZipcodeResponse();
		AddZipcodePEGAResponse pegaResponse = mapper.readValue(pegaResponseString, AddZipcodePEGAResponse.class);
		Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util.formatAddZipcodeResponse(uiResponse,pegaResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util.formatAddZipcodeResponse(uiResponse,pegaResponse);
		Assert.assertNotNull(pegaResponse);
	}

	@Test
	public void formatAddZipcodeResponseTest() throws JsonMappingException, JsonProcessingException {
		String pegaResponseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-DOTCOM-BBP\", \"statusMsg\": \"PEGA generated message\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"sessionId\": \"\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"0\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \"SOP-1583186-DEV3\", \"customerInfo\": { \"accountNumber\": \"07893451230-00001\", \"cartCreator\": \"2515813861\",\"customerType\":\"N\", \"processingMTN\": \"newLine1\" }, \"cartInfo\": { \"cartId\": \"cff57848-8bbd-4c27-9afa-5bfd39c2b5ad\", \"statusCode\": 1, \"statusMsg\": \"SUCCESS\" } }, \"contextInfo\": { \"processAction\": \"\", \"processStep\": \"PlanSelection\", \"availablePaths\": [ { \"path\": \"PlanCategoryPage`\" } ], \"callReason\": \" SalesOrderPurchase \" } } } }";
		BBPAddZipcodeResponse uiResponse = new BBPAddZipcodeResponse();
		AddZipcodePEGAResponse pegaResponse = mapper.readValue(pegaResponseString, AddZipcodePEGAResponse.class);
		CartPegaResponseUtil.formatAddZipcodeResponse(uiResponse,pegaResponse);
		Assert.assertEquals("",pegaResponse.getServiceBody().getServiceResponse().getContext().getCaseId());
		Assert.assertEquals("",pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartId());

		pegaResponse.getServiceBody().getServiceResponse().getContext().setCaseId(null);
		pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setCartId(null);
		CartPegaResponseUtil.formatAddZipcodeResponse(uiResponse,pegaResponse);
		Assert.assertNotNull(pegaResponse);

		pegaResponse.getServiceBody().getServiceResponse().getContext().setCartInfo(null);
		CartPegaResponseUtil.formatAddZipcodeResponse(uiResponse,pegaResponse);
		Assert.assertNotNull(pegaResponse);

		pegaResponse.getServiceBody().getServiceResponse().setContext(null);
		CartPegaResponseUtil.formatAddZipcodeResponse(uiResponse,pegaResponse);
		Assert.assertNotNull(pegaResponse);

		pegaResponse.getServiceBody().setServiceResponse(null);
		CartPegaResponseUtil.formatAddZipcodeResponse(uiResponse,pegaResponse);
		Assert.assertNotNull(pegaResponse);

		pegaResponse.setServiceBody(null);
		CartPegaResponseUtil.formatAddZipcodeResponse(uiResponse,pegaResponse);
		Assert.assertNotNull(pegaResponse);
	}

	@Test
	public void formatInitiateCartPegaResponseTest() throws JsonProcessingException {

		String respString="{ \"serviceHeader\": { \"clientId\": \"VZW-DOTCOM\", \"statusMsg\": \"SUCCESS\", \"serviceName\": \"CPC\", \"statusCode\": \"00\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \"CPC-12401688-E01\", \"contextInfo\": { \"callReason\": \"CPC\", \"processStep\": \"planSelection\", \"availablePaths\": [ { \"path\": \"planSelection\" }, { \"path\": \"featureSelection\" } ], \"pastDueBalance\": \"false\", \"pendingOrderAccountLevel\": \"false\" }, \"customerInfo\": { \"accountNumber\": \"0326564274-00001\", \"cartCreator\": \"5619384700\", \"registerNumber\": 0 }, \"cartInfo\": { \"cartId\": \"5bad495f-b32f-4bc3-8293-c0064cb7750f\" } } } } }";
		InitiateCartUIResponse uiResponse = new InitiateCartUIResponse();
		CpcFeatureResponse pegaResponse = mapper.readValue(respString, CpcFeatureResponse.class);
		Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util1.formatInitiateCartPegaResponse(pegaResponse,uiResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util1.formatInitiateCartPegaResponse(pegaResponse,uiResponse);
		Assert.assertNotNull(pegaResponse);
	}
	
	@Test
	public void formatGuestChoiceResponseTest() throws JsonMappingException, JsonProcessingException {
		
		String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.05.10.06.30.07-364.8736058313525\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"SignInOrderReview\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"SignInOrderReview\"},{\"path\":\"SignIn\"},{\"path\":\"GuestCheckOut\"}]},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POW-D-4072df6b-69a3-4c1d-a8bd-6bdcdff1ee29\",\"processingMTN\":\"9999999999\",\"registerNumber\":0},\"cartInfo\":{}}}}}";
		GuestChoicePEGAResponse pegaResponse = mapper.readValue(sampleResponseString, GuestChoicePEGAResponse.class);
		GuestChoiceUIResponse response = new GuestChoiceUIResponse();
		Assert.assertNotNull(pegaResponse.getServiceHeader());
		Assert.assertNotNull(pegaResponse.getServiceBody());
		util1.formatGuestChoiceResponse(pegaResponse, response);
	}
	
	@Test
	public void formatClearAndContinueResponseTest() throws JsonMappingException, JsonProcessingException {
		
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"processStep\":\"Close\",\"callReason\":\"SalesOrderPurchase\"},\"caseId\":\"SOP-521102-E01\",\"customerInfo\":{\"accountNumber\":\"0100003375-00001\"}}}}}";
		ClearAndContinueUIResponse uiResp = new ClearAndContinueUIResponse();
		ClearAndContinuePegaResponse pegaResponse = mapper.readValue(responseString, ClearAndContinuePegaResponse.class);
		Assert.assertNotNull(pegaResponse.getServiceHeader());
		Assert.assertNotNull(pegaResponse.getServiceBody());
		pegaResponse.getServiceBody().getServiceResponse().getContext().setCartInfo(new CartServiceCartInfo());
		pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setPastDuePresent(true);
		util1.formatClearAndContinueResponse(uiResp, pegaResponse);
		Assert.assertTrue(uiResp.getServiceBody().getServiceResponse().getContext().getCartInfo().isPastDuePresent());
		pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setPastDuePresent(false);
		util1.formatClearAndContinueResponse(uiResp, pegaResponse);
		Assert.assertFalse(uiResp.getServiceBody().getServiceResponse().getContext().getCartInfo().isPastDuePresent());
		Error error =new Error();
		 error.setMessage("abc type error");
		 List<Error> list = new ArrayList<>();
		 list.add(error);
		 pegaResponse.setErrors(list);
		 util1.formatClearAndContinueResponse(uiResp, pegaResponse);
		 Assert.assertNotNull(pegaResponse);
		 pegaResponse.setServiceBody(null);
		 pegaResponse.setServiceHeader(null);
		 pegaResponse.setErrors(null);
		 util1.formatClearAndContinueResponse(uiResp, pegaResponse);
		 Assert.assertNotNull(pegaResponse);	
	}
	
	@Test
	public void formatUpdateWFMInfoResponseTest() throws JsonMappingException, JsonProcessingException{
		String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
		UpdateWFMInfoUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateWFMInfoUIResponse.class);
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"MOTRN1\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-277-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"\",\"processAction\":\"\"},\"cartInfo\":{\"cartId\":\"69a66ef4d-7e344dfb-2db299209-ea8333\"},\"customerInfo\":{\"accountNumber\":\"0220335087-00001\",\"cartCreator\":\"8643804638\",\"processingMTN\":\"8643804638\"}}}}}";
		UpdateWFMInfoPEGAResponse pegaResponse = null;
		pegaResponse = mapper.readValue(responseString, UpdateWFMInfoPEGAResponse.class);
		Assert.assertNotNull(pegaResponse.getServiceHeader());
		Assert.assertNotNull(pegaResponse.getServiceBody());
		Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util1.formatUpdateWFMInfoResponse(sampleResponse, pegaResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util1.formatUpdateWFMInfoResponse(sampleResponse, pegaResponse);
		Assert.assertNotNull(pegaResponse);	
	}

	@Test
	public void formatClearCartResponseTest() throws JsonMappingException, JsonProcessingException {
		String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"MOTRN1\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-277-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"\",\"processAction\":\"\"},\"cartInfo\":{\"cartId\":\"69a66ef4d-7e344dfb-2db299209-ea8333\"},\"customerInfo\":{\"accountNumber\":\"0220335087-00001\",\"cartCreator\":\"8643804638\",\"processingMTN\":\"8643804638\"},\"processMTNList\":[{\"mtn\":\"8643804638\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\"]}],\"removeItem\":{\"lines\":[{\"mtn\":\"2564409659\",\"lineId\":\"null\",\"status\":1}]}}}}}";
		ClearCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, ClearCartUIResponse.class);
		String pegaResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"MOTRN1\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-277-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"\",\"processAction\":\"\"},\"cartInfo\":{\"cartId\":\"69a66ef4d-7e344dfb-2db299209-ea8333\"},\"customerInfo\":{\"accountNumber\":\"0220335087-00001\",\"cartCreator\":\"8643804638\",\"processingMTN\":\"8643804638\"},\"processMTNList\":[{\"mtn\":\"8643804638\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\"]}],\"removeItem\":{\"lines\":[{\"mtn\":\"2564409659\",\"lineId\":\"null\",\"status\":1}]}}}}}";
		ClearCartPEGAResponse pegaResponse = null;
		pegaResponse = mapper.readValue(pegaResponseString, ClearCartPEGAResponse.class);
		Assert.assertNotNull(pegaResponse.getServiceHeader());
		Assert.assertNotNull(pegaResponse.getServiceBody());
		Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util1.formatClearCartResponse(sampleResponse, pegaResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util1.formatClearCartResponse(sampleResponse, pegaResponse);
		Assert.assertNotNull(pegaResponse);	
	}
	
	@Test
	public void formatUpdateChatIdResponseTest() throws JsonMappingException, JsonProcessingException {
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
		UpdateChatIdUIResponse response = mapper.readValue(responseString, UpdateChatIdUIResponse.class);
		String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"MOTRN1\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-277-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"\",\"processAction\":\"\"},\"cartInfo\":{\"cartId\":\"69a66ef4d-7e344dfb-2db299209-ea8333\"},\"customerInfo\":{\"accountNumber\":\"0220335087-00001\",\"cartCreator\":\"8643804638\",\"processingMTN\":\"8643804638\"},\"processMTNList\":[{\"mtn\":\"8643804638\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\"]}]}}}}";
		UpdateChatIdPEGAResponse pegaResponse = null;
		pegaResponse = mapper.readValue(sampleResponseString, UpdateChatIdPEGAResponse.class);
		Assert.assertNotNull(pegaResponse.getServiceHeader());
		Assert.assertNotNull(pegaResponse.getServiceBody());
		Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util1.formatUpdateChatIdResponse(response, pegaResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util1.formatUpdateChatIdResponse(response, pegaResponse);
		Assert.assertNotNull(pegaResponse);		
	}
	
	@Test
	public void formatUpdateTransferUpgradeResponseTest() throws JsonMappingException, JsonProcessingException {
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
		UpdateTransferUpgradeUIResponse response = mapper.readValue(responseString, UpdateTransferUpgradeUIResponse.class);
		String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"PEGAgeneratedmessage\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"processMTNList\":[{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}],\"cartInfo\":{\"cartId\":\"69a66ef4d-7e344dfb-2db299209-ea8333\",\"lines\":[{\"mtn\":\"3014674968\",\"status\":1,\"errors\":null,\"addAccessories\":[{\"id\":\"CM031409\",\"finalPrice\":\"7.49\",\"itemPrice\":\"9.99\",\"discountAmount\":\"2.50\",\"qty\":1,\"status\":0,\"depletionType\":\"F\",\"discounts\":[]}]}]},\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"ShoppingCart\",\"availablePaths\":[{\"path\":\"ShoppingCart`\"}],\"callReason\":\"SalesOrderPurchase\"}}}}}";
		UpdateTransferUpgradePEGAResponse pegaRes = null;
		pegaRes = mapper.readValue(sampleResponseString, UpdateTransferUpgradePEGAResponse.class);
		Assert.assertNotNull(pegaRes.getServiceHeader());
		Assert.assertNotNull(pegaRes.getServiceBody());
		Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaRes.setErrors(list);
		util1.formatUpdateTransferUpgradeResponse(response, pegaRes);
		Assert.assertNotNull(pegaRes);
		pegaRes.setServiceBody(null);
		pegaRes.setServiceHeader(null);
		pegaRes.setErrors(null);
		util1.formatUpdateTransferUpgradeResponse(response, pegaRes);
		Assert.assertNotNull(pegaRes);	
	}
	
	@Test
	public void formatActivateLaterResponseTest() throws JsonMappingException, JsonProcessingException {
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"processStep\":\"Close\",\"callReason\":\"SalesOrderPurchase\"},\"caseId\":\"SOP-521102-E01\",\"customerInfo\":{\"accountNumber\":\"0100003375-00001\"}}}}}";
		ActivateLaterUIResponse response = mapper.readValue(responseString, ActivateLaterUIResponse.class);
		String pegaResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"processStep\":\"Close\",\"callReason\":\"SalesOrderPurchase\"},\"caseId\":\"SOP-521102-E01\",\"customerInfo\":{\"accountNumber\":\"0100003375-00001\"}}}}}";
		ActivateLaterPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, ActivateLaterPEGAResponse.class);
		Assert.assertNotNull(pegaResponse.getServiceHeader());
		Assert.assertNotNull(pegaResponse.getServiceBody());
		Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util1.formatActivateLaterResponse(response, pegaResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util1.formatActivateLaterResponse(response, pegaResponse);
		Assert.assertNotNull(pegaResponse);	
	}
	
	@Test
	public void formatCancelCaseResponseTest() throws JsonMappingException, JsonProcessingException {
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"processStep\":\"Close\",\"callReason\":\"SalesOrderPurchase\"},\"caseId\":\"SOP-521102-E01\",\"customerInfo\":{\"accountNumber\":\"0100003375-00001\"}}}}}";
		CancelCaseUIResponse response = mapper.readValue(responseString, CancelCaseUIResponse.class);
		String sampleUIResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"processStep\":\"Close\",\"callReason\":\"SalesOrderPurchase\"},\"caseId\":\"SOP-521102-E01\",\"customerInfo\":{\"accountNumber\":\"0100003375-00001\"}}}}}";
		CancelCasePEGAResponse pegaResponse = null;
		pegaResponse = mapper.readValue(sampleUIResponseString, CancelCasePEGAResponse.class);
		Assert.assertNotNull(pegaResponse.getServiceHeader());
		Assert.assertNotNull(pegaResponse.getServiceBody());
		Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util1.formatCancelCaseResponse(response, pegaResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util1.formatCancelCaseResponse(response, pegaResponse);
		Assert.assertNotNull(pegaResponse);	
	}
	
	@Test
	public void formatSplitExceededAmountResponseTest() throws JsonMappingException, JsonProcessingException{
		String responseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-ECOM\", \"statusMsg\": \"PEGA generated message\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"sessionId\": \"\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"0\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \" SOP-1583186-DEV3\", \"customerInfo\": { \"accountNumber\": \"07893451230-00001\", \"cartCreator\": \"2515813861\", \"processingMTN\": \"2515813860\" }, \"processMTNList\": [{ \"mtn\": \"2515813860\", \"completedprocessSteps\": [\"MTNSelectionPage\", \"GridWallPDP\"] }, { \"mtn\": \"2515813861\", \"completedprocessSteps\": [] }], \"cartInfo\": { \"cartId\": \"a705f835-c61a-4e20-b616-0c9839202a15\", \"statusCode\": \"1\", \"statusMsg\": \"\"  }, \"contextInfo\": { \"processAction\": \"\", \"processStep\": \"DownPayment\", \"availablePaths\": [{ \"path\": \" DownPayment `\" }], \"callReason\": \" SalesOrderPurchase \" } } } } }";
		SplitExceededAmountUIResponse response = mapper.readValue(responseString, SplitExceededAmountUIResponse.class);
		String sampleUIResponseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-ECOM\", \"statusMsg\": \"PEGA generated message\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"sessionId\": \"\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"0\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \" SOP-1583186-DEV3\", \"customerInfo\": { \"accountNumber\": \"07893451230-00001\", \"cartCreator\": \"2515813861\", \"processingMTN\": \"2515813860\" }, \"processMTNList\": [{ \"mtn\": \"2515813860\", \"completedprocessSteps\": [\"MTNSelectionPage\", \"GridWallPDP\"] }, { \"mtn\": \"2515813861\", \"completedprocessSteps\": [] }], \"cartInfo\": { \"cartId\": \"a705f835-c61a-4e20-b616-0c9839202a15\", \"statusCode\": \"1\", \"statusMsg\": \"\"  }, \"contextInfo\": { \"processAction\": \"\", \"processStep\": \"DownPayment\", \"availablePaths\": [{ \"path\": \" DownPayment `\" }], \"callReason\": \" SalesOrderPurchase \" } } } } }";
		SplitExceededAmountPEGAResponse pegaResponse = null;
		pegaResponse = mapper.readValue(sampleUIResponseString, SplitExceededAmountPEGAResponse.class);
		Assert.assertNotNull(pegaResponse.getServiceHeader());
		Assert.assertNotNull(pegaResponse.getServiceBody());
		Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util1.formatSplitExceededAmountResponse(response, pegaResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util1.formatSplitExceededAmountResponse(response, pegaResponse);
		Assert.assertNotNull(pegaResponse);		 
	}
	
	@Test
	public void formatUpdateSalesRepAndLocationCodeResponseTest() throws JsonMappingException, JsonProcessingException{
		String uiResponseStr = "{\"serviceHeader\": {\"clientId\": \"OMNI-RETAIL\",\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderAdjustment\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\",\"correlationId\": \"soe-cart-2023.03.10.13.36.17-137.57678548497344\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \"SOA-15633776-E01\",\"contextInfo\": {\"callReason\": \"SalesOrderAdjustment\",\"processStep\": \"ShoppingCart\",\"processAction\": \"Update-SalesRepLocation\",\"availablePaths\": [{\"path\": \"ShoppingCart\"}]},\"customerInfo\": {\"accountNumber\": \"0281455093-00001\",\"cartCreator\": \"6175814852\",\"processingMTN\": \"6175814852\",\"registerNumber\": 0},\"cartInfo\": {\"cartItemCount\": 0,\"cartId\": \"d6d94695-030a-4664-b338-e4e7f643784e\",\"statusMsg\": \"Success\",\"statusCode\": \"1\",\"promoLossIndicator\": false,\"agreementNumber\": \"0\",\"vztDiscountGain\": false,\"vztDiscountLoss\": false,\"discountPromoTotal\": 0.0,\"registerNumber\": 0,\"salesRep\": {\"givenName\": \"TEAM 1\",\"familyName\": \"NON-COMMISSIONABLE\",\"salesRepType\": \"E\",\"jobTitleId\": \"REP\",\"locationCode\": \"0026301\"},\"protectionNotRequired\": false,\"fmiCheck\": false}}}}}";
		SalesRepAndLocationCodeUIResponse uiResponse = mapper.readValue(uiResponseStr, SalesRepAndLocationCodeUIResponse.class);
		SalesRepAndLocationCodePEGAResponse pegaResponse = new SalesRepAndLocationCodePEGAResponse();
		String sampleResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \"SPA-1589374-DEV3\"}}}}";
		pegaResponse = mapper.readValue(sampleResponseString, SalesRepAndLocationCodePEGAResponse.class);
		Assert.assertNotNull(pegaResponse.getServiceHeader());
		Assert.assertNotNull(pegaResponse.getServiceBody());
		Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util1.formatUpdateSalesRepAndLocationCodeResponse(uiResponse, pegaResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util1.formatUpdateSalesRepAndLocationCodeResponse(uiResponse, pegaResponse);
		Assert.assertNotNull(pegaResponse);	 
	}
	
	@Test 
	public void formatAddDownPaymentResponseTest()throws JsonMappingException, JsonProcessingException {
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"PEGA generated message\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"exceptions\":[{\"system\":\"CXP\",\"service\":\"addToCartService\",\"type\":\"Warning\",\"code\":\"E1223\",\"message\":\"Account validation failed\"}],\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\" SOP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"processMTNList\":[{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}],\"cartInfo\":{\"cartId\":\"69a66ef4d-7e344dfb-2db299209-ea8333\",\"lines\":[{\"mtn\":\"11111111111\",\"downPayment\":{\"amount\":0,\"percentage\":10}},{\"mtn\":\"222222222222\",\"downPayment\":{\"amount\":0,\"percentage\":10}}]},\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"ShoppingCart\",\"availablePaths\":[{\"path\":\"ShoppingCart`\"}],\"callReason\":\" SalesOrderPurchase \"}}}}}";
		AddDownPaymentUIResponse uiResponse = mapper.readValue(responseString, AddDownPaymentUIResponse.class);
		String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"PEGA generated message\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"exceptions\":[{\"system\":\"CXP\",\"service\":\"addToCartService\",\"type\":\"Warning\",\"code\":\"E1223\",\"message\":\"Account validation failed\"}],\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\" SOP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"processMTNList\":[{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}],\"cartInfo\":{\"cartId\":\"69a66ef4d-7e344dfb-2db299209-ea8333\",\"lines\":[{\"mtn\":\"11111111111\",\"downPayment\":{\"amount\":0,\"percentage\":10}},{\"mtn\":\"222222222222\",\"downPayment\":{\"amount\":0,\"percentage\":10}}]},\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"ShoppingCart\",\"availablePaths\":[{\"path\":\"ShoppingCart`\"}],\"callReason\":\" SalesOrderPurchase \"}}}}}";
		AddDownPaymentPEGAResponse pegaResponse = new AddDownPaymentPEGAResponse();
		pegaResponse = mapper.readValue(sampleResponseString, AddDownPaymentPEGAResponse.class);
		Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util.formatAddDownPaymentResponse(uiResponse, pegaResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util.formatAddDownPaymentResponse(uiResponse, pegaResponse);
		Assert.assertNotNull(pegaResponse);
	}
	
	@Test
	public void formatPastDuesResponseTest() throws JsonMappingException, JsonProcessingException {
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"PEGA generated message\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"exceptions\":[{\"system\":\"CXP\",\"service\":\"validateCart\",\"type\":\"Error\",\"code\":\"E1223\",\"message\":\"Account validation failed\"},{\"system\":\"CXP\",\"service\":\"addToCartService\",\"type\":\"Warning\",\"code\":\"E1223\",\"message\":\"Account validation failed\"}],\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SAP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2324223422\"},\"cartInfo\":{\"cartId\":\"a705f835-c61a-4e20-b616-0c9839202a15\",\"statusCode\":\"1\",\"statusMsg\":\"\"},\"processMTNList\":[{\"mtn\":\"2515813860\",\"completedprocessSteps\":[]},{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}],\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"MTNSelectionPage\",\"availablePaths\":[{\"path\":\"MTNSelectionPage\"},{\"path\":\"PendingOrder\"}],\"callReason\":\"SalesOrderPurchase\",\"pastDueBalance\":false,\"pendingOrderAccountLevel\":true,\"pendingOrderMTNList\":[{\"mtn\":\"8282899487\"},{\"mtn\":\"8282899487\"}]}}}}}";
		PastDuesUIResponse uiResponse = mapper.readValue(responseString, PastDuesUIResponse.class);
		String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"PEGA generated message\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"exceptions\":[{\"system\":\"CXP\",\"service\":\"validateCart\",\"type\":\"Error\",\"code\":\"E1223\",\"message\":\"Account validation failed\"},{\"system\":\"CXP\",\"service\":\"addToCartService\",\"type\":\"Warning\",\"code\":\"E1223\",\"message\":\"Account validation failed\"}],\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SAP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2324223422\"},\"cartInfo\":{\"cartId\":\"a705f835-c61a-4e20-b616-0c9839202a15\",\"statusCode\":\"1\",\"statusMsg\":\"\"},\"processMTNList\":[{\"mtn\":\"2515813860\",\"completedprocessSteps\":[]},{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}],\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"MTNSelectionPage\",\"availablePaths\":[{\"path\":\"MTNSelectionPage\"},{\"path\":\"PendingOrder\"}],\"callReason\":\"SalesOrderPurchase\",\"pastDueBalance\":false,\"pendingOrderAccountLevel\":true,\"pendingOrderMTNList\":[{\"mtn\":\"8282899487\"},{\"mtn\":\"8282899487\"}]}}}}}";
		PastDuesPEGAResponse pegaResponse = new PastDuesPEGAResponse();
		pegaResponse = mapper.readValue(sampleResponseString, PastDuesPEGAResponse.class);
		Assert.assertNotNull(pegaResponse.getServiceHeader());
		Assert.assertNotNull(pegaResponse.getServiceBody());
		Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util.formatPastDuesResponse(uiResponse, pegaResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util.formatPastDuesResponse(uiResponse, pegaResponse);
		Assert.assertNotNull(pegaResponse);
	}
	
	@Test
	public void formatCreateLineResponseTest() throws JsonMappingException, JsonProcessingException {
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.05.13.14.11.06-127.06731644231873\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-7242794-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"PlanSelection\"}]},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-2f3f50b1-3c2f-46ab-9e22-88d793741519\",\"processingMTN\":\"\",\"registerNumber\":0,\"mtnFlow\":\"D\",\"globalId\":\"POE-D-2f3f50b1-3c2f-46ab-9e22-88d793741519\"},\"cartInfo\":{\"financeLimitExceeded\":\"false\",\"lineNumbers\":[\"newLine1\"],\"cartItemCount\":0,\"cartId\":\"bcbfe931-c214-42e1-b240-70bb8961593a\",\"statusMsg\":\"Lines created successfully\",\"userId\":\"\",\"mtn\":\"newLine1\",\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"zipCode\":\"\",\"ecpdProfileId\":\"\",\"protectionNotRequired\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}],\"homeSalesAddress\":{}}}}}";
        CreateLineUIResponse uiResponse = mapper.readValue(responseString, CreateLineUIResponse.class);
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-543157-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"showDevices\"},{\"path\":\"showAccessory\"},{\"path\":\"TradeIn\"},{\"path\":\"showFeatures\"},{\"path\":\"addDevice\"}]},\"customerInfo\":{\"registerNumber\":0,\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"cartInfo\":{\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\"},\"processMTNList\":[{\"mtn\":\"4235344191\",\"completedprocessSteps\":[\"\"]}]}}}}";
        CreateLinePEGAResponse pegaResponse = new CreateLinePEGAResponse();
        pegaResponse = mapper.readValue(sampleResponseString, CreateLinePEGAResponse.class);
		Assert.assertNotNull(pegaResponse.getServiceHeader());
		Assert.assertNotNull(pegaResponse.getServiceBody());
		Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util.formatCreateLineResponse(uiResponse, pegaResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util.formatCreateLineResponse(uiResponse, pegaResponse);
		Assert.assertNotNull(pegaResponse);
	}
	
	@Test
	public void formatInstantCreditDownPaymentResponseTest() throws JsonMappingException, JsonProcessingException {
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{}}}";
        InstantCreditDownPaymentUIResponse uiResponse = mapper.readValue(responseString,
                InstantCreditDownPaymentUIResponse.class);
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{}}}";
		InstantCreditDownPaymentPEGAResponse pegaResponse = null;
		pegaResponse = mapper.readValue(sampleResponseString, InstantCreditDownPaymentPEGAResponse.class);
		Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util.formatInstantCreditDownPaymentResponse(uiResponse, pegaResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util.formatInstantCreditDownPaymentResponse(uiResponse, pegaResponse);
		Assert.assertNotNull(pegaResponse);
	}
	
	@Test
	public void formatRemoveLinesResponseTest() throws JsonMappingException, JsonProcessingException  {
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"MOTRN1\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-277-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"\",\"processAction\":\"\"},\"cartInfo\":{\"cartId\":\"69a66ef4d-7e344dfb-2db299209-ea8333\"},\"customerInfo\":{\"accountNumber\":\"0220335087-00001\",\"cartCreator\":\"8643804638\",\"processingMTN\":\"8643804638\"},\"processMTNList\":[{\"mtn\":\"8643804638\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\"]}],\"removeItem\":{\"lines\":[{\"mtn\":\"2564409659\",\"lineId\":\"null\",\"status\":1}]}}}}}";
        RemoveLinesUIResponse uiResponse = mapper.readValue(responseString, RemoveLinesUIResponse.class);
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"MOTRN1\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-277-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"\",\"processAction\":\"\"},\"cartInfo\":{\"cartId\":\"69a66ef4d-7e344dfb-2db299209-ea8333\"},\"customerInfo\":{\"accountNumber\":\"0220335087-00001\",\"cartCreator\":\"8643804638\",\"processingMTN\":\"8643804638\"},\"processMTNList\":[{\"mtn\":\"8643804638\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\"]}],\"removeItem\":{\"lines\":[{\"mtn\":\"2564409659\",\"lineId\":\"null\",\"status\":1}]}}}}}";
        RemoveLinesPEGAResponse pegaResponse = null;
        pegaResponse = mapper.readValue(sampleResponseString, RemoveLinesPEGAResponse.class);
		Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util.formatRemoveLinesResponse(uiResponse, pegaResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util.formatRemoveLinesResponse(uiResponse, pegaResponse);
		Assert.assertNotNull(pegaResponse);
	}
	
	@Test
	public void formatAddAccessoriesResponseTest() throws JsonMappingException, JsonProcessingException {
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"PEGAgeneratedmessage\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"processMTNList\":[{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}],\"cartInfo\":{\"cartId\":\"69a66ef4d-7e344dfb-2db299209-ea8333\",\"lines\":[{\"mtn\":\"3014674968\",\"status\":1,\"errors\":null,\"addAccessories\":[{\"id\":\"CM031409\",\"finalPrice\":\"7.49\",\"itemPrice\":\"9.99\",\"discountAmount\":\"2.50\",\"qty\":1,\"status\":0,\"depletionType\":\"F\",\"discounts\":[]}]}]},\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"ShoppingCart\",\"availablePaths\":[{\"path\":\"ShoppingCart`\"}],\"callReason\":\"SalesOrderPurchase\"}}}}}";
        AddAccessoriesUIResponse uiResponse = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-TELESALES\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2021.10.07.11.22.28-252.49778997645922\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4224901-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"0819670823-00001\",\"cartCreator\":\"8645909611\",\"processingMTN\":\"3362609194\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"2544303b-ead8-45f9-b4cf-983d14a15b17\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"accessories\":{},\"status\":1,\"mtn\":\"3362609194\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false},\"processMTNList\":[{\"mtn\":\"3362609194\",\"completedprocessSteps\":[\"ShoppingCart\",\"ShoppingCart\"]}]}}}}";
		AddAccessoriesPEGAResponse pegaResponse = null;
		pegaResponse = mapper.readValue(sampleResponseString, AddAccessoriesPEGAResponse.class);
		Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util.formatAddAccessoriesResponse(uiResponse, pegaResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util.formatAddAccessoriesResponse(uiResponse, pegaResponse);
		Assert.assertNotNull(pegaResponse);
	}
	
	@Test
	public void formatAddDeviceResponseTest() throws JsonMappingException, JsonProcessingException {
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
		AddDeviceUIResponse uiResponse = mapper.readValue(responseString, AddDeviceUIResponse.class);
		String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
		AddDevicePEGAResponse pegaResponse = new AddDevicePEGAResponse();
		pegaResponse = mapper.readValue(sampleResponseString, AddDevicePEGAResponse.class);
		Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util.formatAddDeviceResponse(uiResponse, pegaResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util.formatAddDeviceResponse(uiResponse, pegaResponse);
		Assert.assertNotNull(pegaResponse);
	}
	
	@Test
	public void formatNumberShareResponseTest() throws JsonMappingException, JsonProcessingException {
        String responseString = "{\"serviceHeader\": {\"clientId\": \"VZW-NETACE\",\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\"},\"serviceBody\": {\"serviceResponse\": {\"context\":    {}}}}";
        NumberShareUIResponse uiResponse = mapper.readValue(responseString, NumberShareUIResponse.class);
		String sampleResponseString = "{\"serviceHeader\":{ \"clientId\": \"VZW-NETACE\", \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\" }, \"serviceBody\": {\"serviceResponse\": {\"context\":    { \"caseId\": \"SOP-508208-E01\", \"contextInfo\":       { \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"MTNSelectionPage/ShoppingCart\" }, \"customerInfo\": { \"registerNumber\": 0, \"accountNumber\": \"0420194063-00001\" } }}} }";
		NumberSharePEGAResponse pegaResponse = null;
		pegaResponse = mapper.readValue(sampleResponseString, NumberSharePEGAResponse.class);
		Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util.formatNumberShareResponse(uiResponse, pegaResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util.formatNumberShareResponse(uiResponse, pegaResponse);
		Assert.assertNotNull(pegaResponse);
	}

	@Test
	public void formatE911AddressResponseTest() throws JsonMappingException, JsonProcessingException {
		
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-543157-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"showDevices\"},{\"path\":\"showAccessory\"},{\"path\":\"TradeIn\"},{\"path\":\"showFeatures\"},{\"path\":\"addDevice\"}]},\"customerInfo\":{\"registerNumber\":0,\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"cartInfo\":{\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\"},\"processMTNList\":[{\"mtn\":\"4235344191\",\"completedprocessSteps\":[\"\"]}]}}}}";
        E911AddressUIResponse uiResponse = mapper.readValue(responseString, E911AddressUIResponse.class);
		String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-543157-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"showDevices\"},{\"path\":\"showAccessory\"},{\"path\":\"TradeIn\"},{\"path\":\"showFeatures\"},{\"path\":\"addDevice\"}]},\"customerInfo\":{\"registerNumber\":0,\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"cartInfo\":{\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\"},\"processMTNList\":[{\"mtn\":\"4235344191\",\"completedprocessSteps\":[\"\"]}]}}}}";
		E911AddressPEGAResponse pegaResponse = new E911AddressPEGAResponse();
		pegaResponse = mapper.readValue(sampleResponseString, E911AddressPEGAResponse.class);
		Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util.formatE911AddressResponse(uiResponse, pegaResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util.formatE911AddressResponse(uiResponse, pegaResponse);
		Assert.assertNotNull(pegaResponse);
	}
	
	
	@Test
	public void formatAddPlanResponseTest() throws JsonMappingException, JsonProcessingException  {
		String planRespStr = "{ \"serviceHeader\": { \"clientId\": \"VZW-NETACE\", \"statusMsg\": \"PEGA generated message\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"sessionId\": \"\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"0\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \" SOP-1583186-DEV3\", \"customerInfo\": { \"accountNumber\": \"07893451230-00001\", \"cartCreator\": \"2515813861\", \"processingMTN\": \"2515813860\" }, \"processMTNList\": [ { \"mtn\": \"2515813860\", \"completedprocessSteps\": [ \"MTNSelectionPage\", \"GridWallPDP\" ] }, { \"mtn\": \"2515813861\", \"completedprocessSteps\": [] } ], \"cartInfo\": { \"expressCheckout\": true, \"effectiveDateDetails\": { \"suggestedBackDate\": \"\", \"suggestedFutureDate\": \"10/08/2019\", \"currentBillCycleBeginDate\": \"09/08/2019\", \"nextBillCycleBeginDate\": \"10/08/2019\", \"onDemandDate\": \"09/10/2019\", \"onDemandRangeInDays\": \"45\", \"isOnDemandAllowed\": true, \"isBackDateAllowed\": false, \"isFutureDateAllowed\": true }, \"autoPayEnrollmentDetails\": { \"isAutoPayEnrolled\": \"Y\", \"isPaperLessEnrolled\": \"Y\", \"isAutoPayPaperLessDiscountEligible\": \"Y\", \"totalEligibleAutoPayPaperLessDiscount\": 10 }, \"cartId\": \"03927707-5fa1-4239-8ceb-eafae5138dba\", \"statusCode\": 1, \"statusMsg\": null, \"lines\": [ { \"mtn\": \"3025451823\", \"pairingInfo\": { \"newPairedPhone\": \"5512704531\", \"currentPairedPhone\": \"5512704532\", \"benefitPairType\": \"ACD\" }, \"status\": 1, \"planValidationFailed\": false, \"errors\": [], \"isFreeAppleMusicLoss\": \"Y\", \"plan\": { \"id\": \"73425\", \"price\": \"9.99\", \"discountsResponse\": null, \"discountedPrice\": \"10.00\", \"promos\": [ { \"id\": \"\", \"percentageOff\": \"\", \"amountOff\": \"\", \"description\": \"\", \"type\": \"\" } ] }, \"sfos\": [ { \"id\": \"73502\", \"actionIndicator\": \"A\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"UNL PICTURE/VIDEO MSG\", \"price\": \"0.00\" }, { \"id\": \"75622\", \"actionIndicator\": \"A\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"4G DATA TRANSPORT\", \"price\": \"0.00\" }, { \"id\": \"75632\", \"actionIndicator\": \"A\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"INTL TRVL USCAN VOICEDATA PAYG\", \"price\": \"0.00\" }, { \"id\": \"75691\", \"actionIndicator\": \"A\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"REAL TIME USAGE REPORTING\", \"price\": \"0.00\" }, { \"id\": \"76152\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"PICTURE MESSAGING\", \"price\": \"0.00\" }, { \"id\": \"76286\", \"actionIndicator\": \"A\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"CONSUMER PDA\", \"price\": \"0.00\" }, { \"id\": \"76375\", \"actionIndicator\": \"A\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"DATA PACKAGE/2GB\", \"price\": \"30.00\" }, { \"id\": \"76404\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"MOBILE HOTSPOT\", \"price\": \"0.00\" }, { \"id\": \"77249\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"MOBILE HOT SPOT TRIGGER\", \"price\": \"0.00\" }, { \"id\": \"77556\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"4G PROVISIONING\", \"price\": \"0.00\" }, { \"id\": \"77568\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"EMAIL ACCESS\", \"price\": \"0.00\" }, { \"id\": \"77581\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"EMAIL TRIGGER ALP\", \"price\": \"0.00\" }, { \"id\": \"77583\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"DATA PROVISION ALP\", \"price\": \"0.00\" }, { \"id\": \"80148\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"INTL MESSAGES WHILE IN US $0\", \"price\": \"0.00\" }, { \"id\": \"84856\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"VERIZON PLAN UNL ENTITLEMENT\", \"price\": \"0.00\" }, { \"id\": \"84860\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"SMARTPHONE LINE ACCESS\", \"price\": \"20.00\" }, { \"id\": \"84876\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"INCLUDE CANADA/MEXICO\", \"price\": \"0.00\" }, { \"id\": \"84881\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"RTR/UC TRIGGER VP UNL\", \"price\": \"0.00\" }, { \"id\": \"84882\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"RTR FOR UNLIMITED\", \"price\": \"0.00\" } ], \"spos\": [ {} ] } ] }, \"contextInfo\": { \"processAction\": \"\", \"processStep\": \"ShoppingCart/PlanSelection\", \"availablePaths\": [ { \"path\": \"\" } ], \"callReason\": \"SalesOrderPurchase\" } } } } }";
        AddPlanUIResponse uiResponse = mapper.readValue(planRespStr, AddPlanUIResponse.class);
		String addPlansRespString = "{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.04.17.05.52.22-715.8471685178683\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PromoHub\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"ComparePlan\"},{\"path\":\"PromoHub\"},{\"path\":\"ComparePlan\"},{\"path\":\"PromoHub\"}],\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"accountNumber\":\"0222282670-00001\",\"cartCreator\":\"5126216388\",\"processingMTN\":\"5126216388\",\"registerNumber\":0},\"cartInfo\":{\"tabletJetpackDiscountMultiLineLoss\":\"N\",\"cartItemCount\":0,\"subscriptionInfos\":[{\"name\": \"GOOGLEPLAY\",\"nextAction\": \"PAIDCONVERSION\",\"nextActionReason\": null,\"nextPrice\": \"4.99\",\"contentId\": \"GPLAYPASS-PAIDFR12M\", \"service\": null,\"effectiveDate\": null, \"endDate\": null}],\"spoGainReferenceDataList\":[{\"id\":\"2153\"}],\"spoLossReferenceDataList\":[{\"id\":\"2154\"}],\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"plan\":{\"id\":\"63214\",\"price\":\"30.00\",\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"isFreeAppleMusicLoss\":\"N\",\"spos\":[{\"id\":\"671\",\"actionIndicator\":\"D\",\"success\":true,\"description\":\"CarryoverData\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"ADS\",\"DATABANK\"]},{\"id\":\"672\",\"actionIndicator\":\"D\",\"success\":true,\"description\":\"SafetyMode\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"ADS\",\"SAFETYMODE\"]},{\"id\":\"2492\",\"actionIndicator\":\"D\",\"success\":true,\"description\":\"PlanRateAdjustmentMulti\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"RATEPLNADJ\",\"MI\",\"ACCESSCHRG\",\"MTXVPU\",\"SRCREQUAL\"]},{\"id\":\"1247\",\"actionIndicator\":\"A\",\"success\":true,\"description\":\"AutoPay/Paper-freeDiscountIncluded\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"ACCESSDISC\",\"NOSPLANRQD\",\"AUTOPAY\",\"PAPERFREE\",\"BYPGRPREQL\",\"TIERLINE\",\"DISCPROMO\"]},{\"id\":\"1712\",\"actionIndicator\":\"D\",\"success\":true,\"description\":\"AutoPayandPaper-FreeDiscount\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"ACCESSDISC\",\"AUTOPAY\",\"PAPERFREE\",\"BYPGRPREQL\",\"DISCPROMO\"]},{\"id\":\"1929\",\"actionIndicator\":\"Z\",\"success\":true,\"description\":\"CallFilterSpamBlock\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"MTXNCB\",\"BF\"]},{\"id\":\"1256\",\"actionIndicator\":\"A\",\"success\":true,\"description\":\"RoaminginMexico&Canadaisincludedinyourdomesticplan\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"MUTEXGCM\",\"GB\",\"MTXDITP\",\"MTXIPV6\",\"GLOBAL\",\"COMGLB\",\"MTXTPTRIG2\",\"INTLDAILY\"]}],\"sfos\":[{\"id\":\"48526\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"TextMessagingPayPerMessage\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"48553\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"StreamlinedBilling\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"66332\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"DeclineDeviceProtection\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"68869\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"CallerID\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"68870\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"BUSYTRANSFER\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"68871\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"ConferenceCalling\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"68872\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"CALLDELIVERY\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"68873\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"CallWaiting\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"68874\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"NoAnswer/BusyTransfer\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"68876\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"CallForwarding\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"71905\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"BlockWebAccess\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"73324\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"OTASOFTWAREUPDATE-$0.00\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"73502\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"UnlimitedPictureandVideoMessaging\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"73503\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"UnlimitedTextMessages\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"75632\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"DataUsageUSA&Canada\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"75706\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"PayPerMessage\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"75802\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"Dynamic-PrivateIP\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"75836\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"4GINTERNETACCESS\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"75837\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"4GAPPLICATIONACCESS\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"76152\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"PICTUREMESSAGEPROVISIONING\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"76404\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"4GMobileHotspotProvisioning\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"76414\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"NoMobileEmail\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"77249\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"MOBILEHOTSPOTTRIGGER$0\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"77556\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"4GPROVISIONING$0\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"77581\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"EMAILTRIGGERALP$0\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"77583\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"DATAPROVISIONALP\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"77885\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"IntegratedMessaging\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"78485\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"BlockMobileHotspotForNationwideBusinessData\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"78710\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"BasicVoiceMail\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"80148\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"InternationalMessagesWhileinUS\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"81143\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"ACCESS-ADVANCEDCALLING\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"81158\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"HDVoice\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"81186\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"ACCESS-HDVOICE\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"84071\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"RTRforCarryoverData\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"84076\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"ProvisionEntitlementServices\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"84077\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"RTRServiceTrigger\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"84094\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"InternationalServicesEnabledLite\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"86188\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"BasicEmailandWeb\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"86209\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"IncludeMexico&Canadainyourdomesticplan\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"87849\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"BasicPhone-LineAccess\",\"price\":\"35.00\",\"displayHumWiFi\":false},{\"id\":\"89668\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"TEXTBLOCKALLOWTRIGGER\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"89670\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"ENTITLEMENTFORUNLIMITED\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"89671\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"RTR/UCTRIGGER\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"89673\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"RTRPROVISIONING\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"89682\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"MHSTRIGGER\",\"price\":\"0.00\",\"displayHumWiFi\":false}],\"pairingInfo\":{},\"tabletJetpackDiscountLoss\":\"N\",\"tabletJetpackDiscountGain\":\"N\",\"eupNoPromoFlow\":false,\"mtn\":\"5187792855\",\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"currentPlanType\":\"LLP\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"disqualifiedPropositions\":[],\"qualifiedPropositions\":[],\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false,\"lineSubscriptionInfos\":[{\"name\":\"APPLE_ARCADE_INCLUSION\",\"nextAction\":\"STEP_UP\",\"nextActionReason\":\"STATE_NM\"},{\"name\":\"GOOGLE_ARCADE_INCLUSION\",\"nextAction\":\"STEP_UP\",\"nextActionReason\":\"STATE_NM\",\"nextPrice\":\"23.0\",\"effectiveDate\":\"18-05-23\"},{\"name\":\"VZAPLONE_BAYOU\",\"nextAction\":\"CANCEL\",\"nextActionReason\":null,\"nextPrice\":\"23.0\",\"contentId\":\"VZ_AONE_FAM_HB\"}]},{\"plan\":{\"id\":\"63217\",\"price\":\"45.00\",\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"isFreeAppleMusicLoss\":\"N\",\"spos\":[{\"id\":\"671\",\"actionIndicator\":\"D\",\"success\":true,\"description\":\"CarryoverData\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"ADS\",\"DATABANK\",\"AUTOPAY\",\"SMARTFAM\",\"KIDS4LINE\", \"MILITARY\",\"TEACHER\",\"FIRSTRESPD\"]},{\"id\":\"672\",\"actionIndicator\":\"D\",\"success\":true,\"description\":\"SafetyMode\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"ADS\",\"SAFETYMODE\"]},{\"id\":\"2492\",\"actionIndicator\":\"D\",\"success\":true,\"description\":\"PlanRateAdjustmentMulti\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"RATEPLNADJ\",\"MI\",\"ACCESSCHRG\",\"MTXVPU\",\"SRCREQUAL\"]},{\"id\":\"1247\",\"actionIndicator\":\"A\",\"success\":true,\"description\":\"AutoPay/Paper-freeDiscountIncluded\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"ACCESSDISC\",\"NOSPLANRQD\",\"AUTOPAY\",\"PAPERFREE\",\"BYPGRPREQL\",\"TIERLINE\",\"DISCPROMO\"]},{\"id\":\"1087\",\"actionIndicator\":\"D\",\"success\":true,\"description\":\"HDVideoOptimization\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"VIDEOVRIDE\",\"TP\",\"MUTEXVIDEO\"]},{\"id\":\"732\",\"actionIndicator\":\"A\",\"success\":true,\"description\":\"CDMA-LESSROAMTIEROVERRIDE\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"TP\"]},{\"id\":\"1256\",\"actionIndicator\":\"A\",\"success\":true,\"description\":\"RoaminginMexico&Canadaisincludedinyourdomesticplan\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"MUTEXGCM\",\"GB\",\"MTXDITP\",\"MTXIPV6\",\"GLOBAL\",\"COMGLB\",\"MTXTPTRIG2\",\"INTLDAILY\"]},{\"id\":\"1692\",\"actionIndicator\":\"A\",\"success\":true,\"description\":\"5GDynamicSpectrumSharing\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"TP\"]},{\"id\":\"1801\",\"actionIndicator\":\"A\",\"success\":true,\"description\":\"UnlimitedPlanIndicator\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"MI\"]},{\"id\":\"1958\",\"actionIndicator\":\"A\",\"success\":true,\"description\":\"DeviceSet-UpSupport60Days\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"60DAYTRIAL\",\"MI\",\"TECHCOACH\"]},{\"id\":\"2107\",\"actionIndicator\":\"A\",\"success\":true,\"description\":\"5GULTRAWIDEBANDACCESS\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"ADS\",\"5GUWBSEED\",\"5GUWBBOLT\"]},{\"id\":\"2608\",\"actionIndicator\":\"A\",\"success\":true,\"description\":\"5GULTRAWIDEBANDPROVISIONING\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"5GUWBBOLT\",\"5GCOREMTX4\",\"TP\",\"BYPPVQUAL\",\"BYPGRPQUAL\"]}],\"sfos\":[{\"id\":\"48526\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"TextMessagingPayPerMessage\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"48553\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"StreamlinedBilling\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"66332\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"DeclineDeviceProtection\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"68869\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"CallerID\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"68870\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"BUSYTRANSFER\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"68871\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"ConferenceCalling\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"68872\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"CALLDELIVERY\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"68873\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"CallWaiting\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"68874\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"NoAnswer/BusyTransfer\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"68876\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"CallForwarding\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"70421\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"BlockVoiceCalls-Hotline\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"73502\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"UnlimitedPictureandVideoMessaging\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"73503\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"UnlimitedTextMessages\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"74774\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"SDMREMOTEQUERYENABLED\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"75632\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"DataUsageUSA&Canada\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"75706\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"PayPerMessage\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"75802\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"Dynamic-PrivateIP\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"75836\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"4GINTERNETACCESS\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"75837\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"4GAPPLICATIONACCESS\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"76404\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"4GMobileHotspotProvisioning\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"77249\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"MOBILEHOTSPOTTRIGGER$0\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"77552\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"BlockMobileHotspot/Pre-ProvisionedMobileHotspot\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"77553\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"NON-MOBILEE-MAILDVC/PRE-PROV\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"77556\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"4GPROVISIONING$0\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"77581\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"EMAILTRIGGERALP$0\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"77583\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"DATAPROVISIONALP\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"79708\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"VisualVoiceMail\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"80148\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"InternationalMessagesWhileinUS\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"83856\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"CDMA-LESSDEVICEPROVISIONING\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"84022\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"Jetpack-LineAccess\",\"price\":\"10.00\",\"displayHumWiFi\":false},{\"id\":\"84071\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"RTRforCarryoverData\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"84076\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"ProvisionEntitlementServices\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"84077\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"RTRServiceTrigger\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"85553\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"VerizonCloudEligible\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"86189\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"EmailandWeb\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"86209\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"IncludeMexico&Canadainyourdomesticplan\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"86848\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"4GSERVICEON5GDEVICE\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"86905\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"GSMRoamingPriority\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"87046\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"MobileHotspot30GB\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"88888\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"ENTITLEMENTTRIGGER\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"89668\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"TEXTBLOCKALLOWTRIGGER\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"89670\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"ENTITLEMENTFORUNLIMITED\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"89672\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"RTR/UCTRIGGER\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"89674\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"RTRPROVISIONING\",\"price\":\"0.00\",\"displayHumWiFi\":false}],\"pairingInfo\":{},\"firstMonthInstallment\":28.04,\"monthlyInstallment\":27.77,\"tabletJetpackDiscountLoss\":\"N\",\"tabletJetpackDiscountGain\":\"N\",\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"eupNoPromoFlow\":false,\"featureMessages\":[{\"name\":\"5GUWBBOLT\",\"action\":\"ADD\"},{\"name\":\"5GUWBBOLT\",\"action\":\"DROP\"}],\"mtn\":\"5126216388\",\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"currentPlanType\":\"LLP\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"disqualifiedPropositions\":[],\"qualifiedPropositions\":[],\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false,\"lineSubscriptionInfos\":[{\"name\":\"APPLE_ARCADE_INCLUSION\",\"nextAction\":\"PAIDCONVERSION\",\"nextActionReason\":null},{\"name\":\"GOOGLE_ARCADE_INCLUSION\",\"nextAction\":\"PAIDCONVERSION\",\"nextActionReason\":null}]},{\"plan\":{\"id\":\"63217\",\"price\":\"45.00\",\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"isFreeAppleMusicLoss\":\"N\",\"spos\":[{\"id\":\"671\",\"actionIndicator\":\"D\",\"success\":true,\"description\":\"CarryoverData\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"ADS\",\"DATABANK\"]},{\"id\":\"672\",\"actionIndicator\":\"D\",\"success\":true,\"description\":\"SafetyMode\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"ADS\",\"SAFETYMODE\"]},{\"id\":\"2492\",\"actionIndicator\":\"D\",\"success\":true,\"description\":\"PlanRateAdjustmentMulti\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"RATEPLNADJ\",\"MI\",\"ACCESSCHRG\",\"MTXVPU\",\"SRCREQUAL\"]},{\"id\":\"1247\",\"actionIndicator\":\"A\",\"success\":true,\"description\":\"AutoPay/Paper-freeDiscountIncluded\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"ACCESSDISC\",\"NOSPLANRQD\",\"AUTOPAY\",\"PAPERFREE\",\"BYPGRPREQL\",\"TIERLINE\",\"DISCPROMO\"]},{\"id\":\"1712\",\"actionIndicator\":\"D\",\"success\":true,\"description\":\"AutoPayandPaper-FreeDiscount\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"ACCESSDISC\",\"AUTOPAY\",\"PAPERFREE\",\"BYPGRPREQL\",\"DISCPROMO\"]},{\"id\":\"732\",\"actionIndicator\":\"A\",\"success\":true,\"description\":\"CDMA-LESSROAMTIEROVERRIDE\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"TP\"]},{\"id\":\"1256\",\"actionIndicator\":\"A\",\"success\":true,\"description\":\"RoaminginMexico&Canadaisincludedinyourdomesticplan\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"MUTEXGCM\",\"GB\",\"MTXDITP\",\"MTXIPV6\",\"GLOBAL\",\"COMGLB\",\"MTXTPTRIG2\",\"INTLDAILY\"]},{\"id\":\"1692\",\"actionIndicator\":\"A\",\"success\":true,\"description\":\"5GDynamicSpectrumSharing\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"TP\"]},{\"id\":\"1801\",\"actionIndicator\":\"A\",\"success\":true,\"description\":\"UnlimitedPlanIndicator\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"MI\"]},{\"id\":\"1958\",\"actionIndicator\":\"A\",\"success\":true,\"description\":\"DeviceSet-UpSupport60Days\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"60DAYTRIAL\",\"MI\",\"TECHCOACH\"]},{\"id\":\"2107\",\"actionIndicator\":\"A\",\"success\":true,\"description\":\"5GULTRAWIDEBANDACCESS\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"ADS\",\"5GUWBSEED\",\"5GUWBBOLT\"]},{\"id\":\"2608\",\"actionIndicator\":\"A\",\"success\":true,\"description\":\"5GULTRAWIDEBANDPROVISIONING\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"5GUWBBOLT\",\"5GCOREMTX4\",\"TP\",\"BYPPVQUAL\",\"BYPGRPQUAL\"]}],\"sfos\":[{\"id\":\"48526\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"TextMessagingPayPerMessage\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"48553\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"StreamlinedBilling\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"66332\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"DeclineDeviceProtection\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"68869\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"CallerID\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"68870\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"BUSYTRANSFER\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"68871\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"ConferenceCalling\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"68872\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"CALLDELIVERY\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"68873\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"CallWaiting\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"68874\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"NoAnswer/BusyTransfer\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"68876\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"CallForwarding\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"73502\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"UnlimitedPictureandVideoMessaging\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"73503\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"UnlimitedTextMessages\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"75632\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"DataUsageUSA&Canada\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"75706\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"PayPerMessage\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"75802\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"Dynamic-PrivateIP\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"75836\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"4GINTERNETACCESS\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"75837\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"4GAPPLICATIONACCESS\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"76152\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"PICTUREMESSAGEPROVISIONING\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"76404\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"4GMobileHotspotProvisioning\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"76600\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"SHARENAMEID\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"77249\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"MOBILEHOTSPOTTRIGGER$0\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"77552\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"BlockMobileHotspot/Pre-ProvisionedMobileHotspot\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"77556\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"4GPROVISIONING$0\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"77568\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"EMAILACCESSPDA$0\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"77581\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"EMAILTRIGGERALP$0\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"77583\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"DATAPROVISIONALP\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"79708\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"VisualVoiceMail\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"80148\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"InternationalMessagesWhileinUS\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"81143\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"ACCESS-ADVANCEDCALLING\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"81158\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"HDVoice\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"81186\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"ACCESS-HDVOICE\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"82419\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"AccessWi-fiCalling\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"83856\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"CDMA-LESSDEVICEPROVISIONING\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"84071\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"RTRforCarryoverData\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"84076\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"ProvisionEntitlementServices\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"84077\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"RTRServiceTrigger\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"84094\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"InternationalServicesEnabledLite\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"85553\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"VerizonCloudEligible\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"86189\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"EmailandWeb\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"86209\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"IncludeMexico&Canadainyourdomesticplan\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"86848\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"4GSERVICEON5GDEVICE\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"86869\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"CallFilter\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"86905\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"GSMRoamingPriority\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"87046\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"MobileHotspot30GB\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"87850\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"Smartphone-LineAccess\",\"price\":\"35.00\",\"displayHumWiFi\":false},{\"id\":\"88888\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"ENTITLEMENTTRIGGER\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"89668\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"TEXTBLOCKALLOWTRIGGER\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"89670\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"ENTITLEMENTFORUNLIMITED\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"89672\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"RTR/UCTRIGGER\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"89674\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"RTRPROVISIONING\",\"price\":\"0.00\",\"displayHumWiFi\":false}],\"pairingInfo\":{},\"firstMonthInstallment\":28.04,\"monthlyInstallment\":27.77,\"tabletJetpackDiscountLoss\":\"N\",\"tabletJetpackDiscountGain\":\"N\",\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"eupNoPromoFlow\":false,\"featureMessages\":[{\"name\":\"5GUWBBOLT\",\"action\":\"ADD\"}],\"mtn\":\"5127998837\",\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"currentPlanType\":\"LLP\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"disqualifiedPropositions\":[],\"qualifiedPropositions\":[],\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false},{\"plan\":{\"id\":\"63217\",\"price\":\"45.00\",\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"isFreeAppleMusicLoss\":\"N\",\"spos\":[{\"id\":\"671\",\"actionIndicator\":\"D\",\"success\":true,\"description\":\"CarryoverData\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"ADS\",\"DATABANK\"]},{\"id\":\"2153\",\"actionIndicator\":\"A\",\"success\":true,\"description\":\"CarryoverData\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"ADS\",\"DATABANK\"]},{\"id\":\"2154\",\"actionIndicator\":\"D\",\"success\":true,\"description\":\"CarryoverData\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"ADS\",\"DATABANK\"]},{\"id\":\"672\",\"actionIndicator\":\"D\",\"success\":true,\"description\":\"SafetyMode\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"ADS\",\"SAFETYMODE\"]},{\"id\":\"2492\",\"actionIndicator\":\"D\",\"success\":true,\"description\":\"PlanRateAdjustmentMulti\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"RATEPLNADJ\",\"MI\",\"ACCESSCHRG\",\"MTXVPU\",\"SRCREQUAL\"]},{\"id\":\"1247\",\"actionIndicator\":\"A\",\"success\":true,\"description\":\"AutoPay/Paper-freeDiscountIncluded\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"ACCESSDISC\",\"NOSPLANRQD\",\"AUTOPAY\",\"PAPERFREE\",\"BYPGRPREQL\",\"TIERLINE\",\"DISCPROMO\"]},{\"id\":\"383\",\"actionIndicator\":\"D\",\"success\":true,\"description\":\"TravelPass\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"GB\",\"MTXDITP\",\"COMGLB\",\"MTXGBLNPNL\",\"GLOBAL\",\"MTXTPTRIG2\",\"TPUPRWDELG\",\"INTLDAILY\"]},{\"id\":\"1712\",\"actionIndicator\":\"D\",\"success\":true,\"description\":\"AutoPayandPaper-FreeDiscount\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"ACCESSDISC\",\"AUTOPAY\",\"PAPERFREE\",\"BYPGRPREQL\",\"DISCPROMO\"]},{\"id\":\"1802\",\"actionIndicator\":\"D\",\"success\":true,\"description\":\"MeteredPlanIndicator\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"MI\"]},{\"id\":\"384\",\"actionIndicator\":\"Z\",\"success\":true,\"description\":\"IntlTravelVoice&DataPaygo\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"MUTEXGCM\",\"GB\",\"MTXIPV6\",\"GLOBAL\",\"MTXGLBNPSK\",\"COMGLB\",\"MTXGBLNPNL\",\"HELPER\"]},{\"id\":\"732\",\"actionIndicator\":\"Z\",\"success\":true,\"description\":\"CDMA-LESSROAMTIEROVERRIDE\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"TP\"]},{\"id\":\"1692\",\"actionIndicator\":\"Z\",\"success\":true,\"description\":\"5GDynamicSpectrumSharing\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"TP\"]},{\"id\":\"1255\",\"actionIndicator\":\"A\",\"success\":true,\"description\":\"TravelPass\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"GB\",\"MTXDITP\",\"GLOBAL\",\"INTLDAILY\",\"COMGLB\",\"MTXGBLNPNL\",\"MTXTPTRIG2\",\"TPUPRWDELG\"]},{\"id\":\"1801\",\"actionIndicator\":\"A\",\"success\":true,\"description\":\"UnlimitedPlanIndicator\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"MI\"]},{\"id\":\"2107\",\"actionIndicator\":\"A\",\"success\":true,\"description\":\"5GULTRAWIDEBANDACCESS\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"ADS\",\"5GUWBSEED\",\"5GUWBBOLT\"]},{\"id\":\"2608\",\"actionIndicator\":\"A\",\"success\":true,\"description\":\"5GULTRAWIDEBANDPROVISIONING\",\"is5GBolt\":false,\"parentProductsSorIds\":[\"5GUWBBOLT\",\"5GCOREMTX4\",\"TP\",\"BYPPVQUAL\",\"BYPGRPQUAL\"]}],\"sfos\":[{\"id\":\"48526\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"TextMessagingPayPerMessage\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"48553\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"StreamlinedBilling\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"66332\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"DeclineDeviceProtection\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"68869\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"CallerID\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"68870\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"BUSYTRANSFER\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"68871\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"ConferenceCalling\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"68872\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"CALLDELIVERY\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"68873\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"CallWaiting\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"68874\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"NoAnswer/BusyTransfer\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"68876\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"CallForwarding\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"73502\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"UnlimitedPictureandVideoMessaging\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"73503\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"UnlimitedTextMessages\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"75706\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"PayPerMessage\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"75802\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"Dynamic-PrivateIP\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"75836\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"4GINTERNETACCESS\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"75837\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"4GAPPLICATIONACCESS\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"76152\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"PICTUREMESSAGEPROVISIONING\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"76404\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"4GMobileHotspotProvisioning\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"77249\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"MOBILEHOTSPOTTRIGGER$0\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"77552\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"BlockMobileHotspot/Pre-ProvisionedMobileHotspot\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"77556\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"4GPROVISIONING$0\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"77568\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"EMAILACCESSPDA$0\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"77581\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"EMAILTRIGGERALP$0\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"77583\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"DATAPROVISIONALP\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"79708\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"VisualVoiceMail\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"80148\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"InternationalMessagesWhileinUS\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"81143\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"ACCESS-ADVANCEDCALLING\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"81158\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"HDVoice\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"81186\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"ACCESS-HDVOICE\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"83186\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"ROAMALTERNATEFEATURE\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"83856\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"CDMA-LESSDEVICEPROVISIONING\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"84071\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"RTRforCarryoverData\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"84076\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"ProvisionEntitlementServices\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"84077\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"RTRServiceTrigger\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"84094\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"InternationalServicesEnabledLite\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"85553\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"VerizonCloudEligible\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"86189\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"EmailandWeb\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"86209\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"IncludeMexico&Canadainyourdomesticplan\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"86848\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"4GSERVICEON5GDEVICE\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"86869\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"CallFilter\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"86905\",\"actionIndicator\":\"Z\",\"customerAddedInd\":\"N\",\"description\":\"GSMRoamingPriority\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"87046\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"MobileHotspot30GB\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"87850\",\"actionIndicator\":\"D\",\"customerAddedInd\":\"N\",\"description\":\"Smartphone-LineAccess\",\"price\":\"35.00\",\"displayHumWiFi\":false},{\"id\":\"88888\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"ENTITLEMENTTRIGGER\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"89668\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"TEXTBLOCKALLOWTRIGGER\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"89670\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"ENTITLEMENTFORUNLIMITED\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"89672\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"RTR/UCTRIGGER\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"89674\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"RTRPROVISIONING\",\"price\":\"0.00\",\"displayHumWiFi\":false}],\"pairingInfo\":{},\"tabletJetpackDiscountLoss\":\"N\",\"tabletJetpackDiscountGain\":\"Y\",\"eupNoPromoFlow\":false,\"featureMessages\":[{\"name\":\"5GUWBBOLT\",\"action\":\"ADD\"}],\"mtn\":\"5127998985\",\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"currentPlanType\":\"LLP\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"disqualifiedPropositions\":[],\"qualifiedPropositions\":[],\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"isOnDemandAllowed\":false,\"isBackDateAllowed\":false,\"isFutureDateAllowed\":true,\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"05/04/2023\",\"currentBillCycleBeginDate\":\"04/04/2023\",\"nextBillCycleBeginDate\":\"05/04/2023\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"45\"},\"autoPayEnrollmentDetails\":{\"isAutoPayEnrolled\":\"Y\",\"isPaperLessEnrolled\":\"Y\",\"isAutoPayPaperLessDiscountEligible\":\"N\"},\"featureChangeDetails\":[{\"mtnList\":[\"5126216388\",\"5127998837\",\"5127998985\"],\"changedFeatureCode\":\"5GUWBBOLTGAIN\",\"mtn\":\"5126216388\"}],\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"discountLossIndicators\":[],\"fmiCheck\":false},\"processMTNList\":[{\"mtn\":\"5126216388\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\",\"MTNSelectionPage\",\"GridWallPDP\",\"MTNSelectionPage\",\"Initiate\",\"BuildYourPlan\",\"BuildYourPlan\",\"BuildYourPlan\",\"BuildYourPlan\",\"NewRecommendedPlanSelection\"]}]}}}}";
		AddPlanPEGAResponse pegaResponse  = mapper.readValue(addPlansRespString, AddPlanPEGAResponse.class);
		Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util.formatAddPlanResponse(uiResponse, pegaResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util.formatAddPlanResponse(uiResponse, pegaResponse);
		Assert.assertNotNull(pegaResponse);
	}
	
	@Test
	public void formatEffectiveDateOverrideResponseTest() throws JsonMappingException, JsonProcessingException  {
		String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"PEGA generated message\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\" SAP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"processMTNList\":[{\"mtn\":\"2515813860\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\",\"ShoppingCart\",\"CreditPage\"]},{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}],\"cartInfo\":{\"cartId\":\"69a66ef4d-7e344dfb-2db299209-ea8333\",\"lines\":[{\"mtn\":\"9207400273\",\"lineId\":\"9207400273\",\"status\":1,\"planValidationFailed\":false,\"errors\":[],\"activationDate\":null,\"activateLaterInd\":false,\"legalDisclosure\":null,\"plan\":{\"sorId\":\"97928\",\"price\":null,\"discountsResponse\":null},\"showInsurancePage\":false}],\"status\":1,\"effectiveDateDetails\":{\"isOnDemandAllowed\":true,\"isBackDateAllowed\":true,\"isFutureDateAllowed\":true,\"suggestedBackDate\":\"07/01/2019\",\"suggestedFutureDate\":\"08/01/2019\",\"currentBillCycleBeginDate\":\"08/26/2019\",\"nextBillCycleBeginDate\":\"09/26/2019\"},\"autoServiceValidationEnabled\":true}}},\"contextInfo\":{\"processAction\":\"\",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"Interim\",\"availablePaths\":[{\"path\":\"Interim\"}]}}}";
		EffectiveDateOverridePEGAResponse pegaResponse = new EffectiveDateOverridePEGAResponse();
		pegaResponse = mapper.readValue(sampleResponseString, EffectiveDateOverridePEGAResponse.class);
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"PEGA generated message\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\" SAP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"processMTNList\":[{\"mtn\":\"2515813860\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\",\"ShoppingCart\",\"CreditPage\"]},{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}],\"cartInfo\":{\"cartId\":\"69a66ef4d-7e344dfb-2db299209-ea8333\",\"lines\":[{\"mtn\":\"9207400273\",\"lineId\":\"9207400273\",\"status\":1,\"planValidationFailed\":false,\"errors\":[],\"activationDate\":null,\"activateLaterInd\":false,\"legalDisclosure\":null,\"plan\":{\"sorId\":\"97928\",\"price\":null,\"discountsResponse\":null},\"showInsurancePage\":false}],\"status\":1,\"effectiveDateDetails\":{\"isOnDemandAllowed\":true,\"isBackDateAllowed\":true,\"isFutureDateAllowed\":true,\"suggestedBackDate\":\"07/01/2019\",\"suggestedFutureDate\":\"08/01/2019\",\"currentBillCycleBeginDate\":\"08/26/2019\",\"nextBillCycleBeginDate\":\"09/26/2019\"},\"autoServiceValidationEnabled\":true}}},\"contextInfo\":{\"processAction\":\"\",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"Interim\",\"availablePaths\":[{\"path\":\"Interim\"}]}}}";
        EffectiveDateOverrideUIResponse uiResponse = mapper.readValue(responseString,
                EffectiveDateOverrideUIResponse.class);
		Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util.formatEffectiveDateOverrideResponse(pegaResponse, uiResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util.formatEffectiveDateOverrideResponse(pegaResponse, uiResponse);
		Assert.assertNotNull(pegaResponse);
	}
	
	@Test
	public void formatUpdateDeviceSimIdResponseTest() throws JsonMappingException, JsonProcessingException  {
		String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-RETAIL\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2021.10.11.04.58.27-70.0633169932694\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4309810-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ValidateDeviceSimIdPage\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"ValidateDeviceSimIdPage\"},{\"path\":\"ShoppingCart\"}]},\"customerInfo\":{\"accountNumber\":\"0880463580-00001\",\"processingMTN\":\"9736341496\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"87093ae1-a611-411d-b189-475d28b3c86e\",\"statusMsg\":\"Device Id and Sim ID updated successfully.\",\"statusCode\":\"1\",\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false},\"mtnDetailsList\":[{\"simIdProvided\":\"true\",\"mtn\":\"9736341496\",\"deviceIdProvided\":\"true\",\"ispuItem\":true}],\"processMTNList\":[{\"completedprocessSteps\":[\"MTNSelectionPage\",\"InterimPage\",\"BYODDeviceIDPage\",\"GridWallPDP\",\"PlanSelection\",\"ShoppingCart\",\"ValidateDeviceSimIdPage\",\"ValidateDeviceSimIdPage\"]},{\"mtn\":\"9736341496\"}]}}}}";
		UpdateDeviceSIMIdPEGAResponse pegaResponse = new UpdateDeviceSIMIdPEGAResponse();
		pegaResponse = mapper.readValue(sampleResponseString, UpdateDeviceSIMIdPEGAResponse.class);
        String responseString = "{\"meta\": {\"timestamp\": \"2019-08-05T13:27:07Z\",\"cxpCorrelationId\": \"3d5f3c15-aa3b-4a42-9245-5cb4177468e4\"},\"data\": {\"cartId\": \"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\": \"Device Id and Sim ID updated successfully.\"}}";
        UpdateDeviceSIMIdUIResponse uiResponse = mapper.readValue(responseString, UpdateDeviceSIMIdUIResponse.class);
        Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util.formatUpdateDeviceSimIdResponse(pegaResponse, uiResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util.formatUpdateDeviceSimIdResponse(pegaResponse, uiResponse);
		Assert.assertNotNull(pegaResponse);
	}
	
	@Test
	public void formatDeassignMtnResponseTest() throws JsonMappingException, JsonProcessingException {
		String sampleResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \" SOP-1583186-DEV3\",\"customerInfo\": {\"accountNumber\": \"07893451230-00001\",\"cartCreator\": \"2515813861\",\"processingMTN\": \"2515813860\"},\"cartInfo\": {\"cartId\": \"69a66ef4d-7e344dfb-2db299209-ea8333\",\"statusCode\": 1,\"statusMsg\": \"Success\",\"preAuthSuccess\": false}},\"contextInfo\": {\"processAction\": \"\",\"processStep\": \"InterimPage\",\"callReason\": \" SalesOrderPurchase \"}}}}";
		DeassignMtnPEGAResponse pegaResponse = null;
		pegaResponse = mapper.readValue(sampleResponseString, DeassignMtnPEGAResponse.class);
		String responseString = "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \" SOP-1583186-DEV3\",\"customerInfo\": {\"accountNumber\": \"07893451230-00001\",\"cartCreator\": \"2515813861\",\"processingMTN\": \"2515813860\"},\"cartInfo\": {\"cartId\": \"69a66ef4d-7e344dfb-2db299209-ea8333\",\"statusCode\": 1,\"statusMsg\": \"Success\",\"preAuthSuccess\": false}},\"contextInfo\": {\"processAction\": \"\",\"processStep\": \"InterimPage\",\"callReason\": \" SalesOrderPurchase \"}}}}";
        DeassignMtnUIResponse uiResponse = mapper.readValue(responseString, DeassignMtnUIResponse.class);
        Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util.formatDeassignMtnResponse(pegaResponse, uiResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util.formatDeassignMtnResponse(pegaResponse, uiResponse);
		Assert.assertNotNull(pegaResponse);
	}
	
	@Test 
	public void formatAdd5GBulkOrderResponseTest() throws JsonMappingException, JsonProcessingException {
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        Add5GBulkOrderUIResponse uiResponse = mapper.readValue(responseString, Add5GBulkOrderUIResponse.class);
		String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
		Add5GBulkOrderPEGAResponse pegaResponse = new Add5GBulkOrderPEGAResponse();
		pegaResponse = mapper.readValue(sampleResponseString, Add5GBulkOrderPEGAResponse.class);
		Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util.formatAdd5GBulkOrderResponse(uiResponse, pegaResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util.formatAdd5GBulkOrderResponse(uiResponse, pegaResponse);
		Assert.assertNotNull(pegaResponse);
	}
	
	@Test
	public void formatRevokeRebatesResponseTest() throws JsonMappingException, JsonProcessingException { 
        String responseString = "{\"serviceHeader\": {\"clientId\": \"VZW-NETACE\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \" SAP-1583186-DEV3\",\"customerInfo\": {\"accountNumber\": \"07893451230-00001\",\"cartCreator\": \"2515813861\",\"processingMTN\": \"2515813860\"},\"cartInfo\": {\"cartId\": \"69a66ef4d-7e344dfb-2db299209-ea8333\",\"statusCode\": \"1\",\"statusMsg\": \"Updated my offers details successfully\"},\"contextInfo\": {\"processAction\": \"\",\"processStep\": \"OrderReview-Shipping\",\"availablePaths\": [{\"path\": \"OrderReview-Shipping\"}],\"callReason\": \" SalesOrderPurchase \"}}}}}";
        RevokeRebatesUIResponse uiResponse = mapper.readValue(responseString, RevokeRebatesUIResponse.class);
		String sampleResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-NETACE\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \" SAP-1583186-DEV3\",\"customerInfo\": {\"accountNumber\": \"07893451230-00001\",\"cartCreator\": \"2515813861\",\"processingMTN\": \"2515813860\"},\"cartInfo\": {\"cartId\": \"69a66ef4d-7e344dfb-2db299209-ea8333\",\"statusCode\": \"1\",\"statusMsg\": \"Updated my offers details successfully\"},\"contextInfo\": {\"processAction\": \"\",\"processStep\": \"OrderReview-Shipping\",\"availablePaths\": [{\"path\": \"OrderReview-Shipping\"}],\"callReason\": \" SalesOrderPurchase \"}}}}}";
		RevokeRebatesPEGAResponse pegaResponse = null;
		pegaResponse = mapper.readValue(sampleResponseString, RevokeRebatesPEGAResponse.class);
		Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util.formatRevokeRebatesResponse(uiResponse, pegaResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util.formatRevokeRebatesResponse(uiResponse, pegaResponse);
		Assert.assertNotNull(pegaResponse);
	}
	
	@Test
	public void formatUpdatePortInLaterResponseTest() throws JsonMappingException, JsonProcessingException {
		String responseString = "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \" SOP-1583186-DEV3\",\"customerInfo\": {\"accountNumber\": \"07893451230-00001\",\"cartCreator\": \"2515813861\",\"processingMTN\": \"2515813860\"},\"cartInfo\": {\"cartId\": \"69a66ef4d-7e344dfb-2db299209-ea8333\",\"statusMsg\": \"PortInLater updated successfully.\"},\"contextInfo\": {\"processAction\": \"\",\"processStep\": \"InterimPage\",\"callReason\": \" SalesOrderPurchase \"}}}}}";
        PortinLaterUIResponse uiResponse = mapper.readValue(responseString, PortinLaterUIResponse.class);
        String sampleResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \" SOP-1583186-DEV3\",\"customerInfo\": {\"accountNumber\": \"07893451230-00001\",\"cartCreator\": \"2515813861\",\"processingMTN\": \"2515813860\"},\"cartInfo\": {\"cartId\": \"69a66ef4d-7e344dfb-2db299209-ea8333\",\"statusMsg\": \"PortInLater updated successfully.\"},\"contextInfo\": {\"processAction\": \"\",\"processStep\": \"InterimPage\",\"callReason\": \" SalesOrderPurchase \"}}}}}";
		PortinLaterPEGAResponse pegaResponse = null;
		pegaResponse = mapper.readValue(sampleResponseString, PortinLaterPEGAResponse.class);
		Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util.formatUpdatePortInLaterResponse(uiResponse, pegaResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util.formatUpdatePortInLaterResponse(uiResponse, pegaResponse);
		Assert.assertNotNull(pegaResponse); 
	}
	
	@Test
	public void formatVoidOrderResponseTest() throws JsonMappingException, JsonProcessingException { 
		String sampleUIResponseString = "{\"serviceHeader\":{\"clientId\":\" VZW-NETACE\",\"statusMsg\":\"PEGA generated message\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"cartInfo\":{\"cartId\":\"bea202a6-42cb-40d4-ac87-d3f1db2b3f13\"},\"CancelOrderResponse\":{\"cartId\":\"0d95729d-7989-48a0-b79c-3b40153efb5a\",\"locationCode\":\"N833301\",\"userId\":\"ENC\",\"orderDetails\":[{\"orderNumber\":\"1634\",\"status\":\"SUCCESS\",\"statusCode\":\"0\",\"statusMsg\":\"Order Cancelled Successfully\"},{\"orderNumber\":\"4459\",\"status\":\"FAIL\",\"statusCode\":\"ISPU-102\",\"statusMsg\":\"Zip code authentication failed\"}]},\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ExitPage\"}}}}}";
		VoidOrderPEGAResponse pegaResponse = null;
		pegaResponse = mapper.readValue(sampleUIResponseString, VoidOrderPEGAResponse.class);
        String responseString = "{\"data\": { \"isIspuItemsInCarts\": true,   \"isDfillItemsInCart\": false,   \"isLocalItemsInCart\": true}}{\"topKey\":\"write1\",\"subKey\":\"demo4\",\"cartId\":\"\",\"caseId\":\"\",\"mtn\":\"\",\"accountNumber\":\"0486105182-00001\",\"device\":{\"id\":\"SMN976VZSV\",\"contractTerm\":\"MONTH_TO_MONTH\",\"dppMonths\":\"\"}}";
        VoidOrderUIResponse response = mapper.readValue(responseString, VoidOrderUIResponse.class);
        Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util.formatVoidOrderResponse(pegaResponse, response);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util.formatVoidOrderResponse(pegaResponse, response);
		Assert.assertNotNull(pegaResponse); 
	}
	
	@Test
	public void formatIspuToDfillResponseTest() throws JsonMappingException, JsonProcessingException {
		String sampleUIResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"PEGA generated message\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\" SOP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"processMTNList\":[{\"mtn\":\"2515813860\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\"]},{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}],\"cartInfo\":{\"cartId\":\"3ef39561-697e-486c-befc-4996c8a6921f\",\"statusCode\":1,\"statusMsg\":\"Success\",\"preAuthSuccess\":false,\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"financeLimitExceeded\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":0,\"agreementNumber\":0},\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"GridWallPDP\",\"availablePaths\":[{\"path\":\"ShoppingCart`\"},{\"path\":\"addDevice\"},{\"path\":\"addFeatures`\"},{\"path\":\"showFeatures\"},{\"path\":\"showDevice`\"},{\"path\":\"showAccessory\"},{\"path\":\"addAccessory\"},{\"path\":\"TradeIn\"}],\"callReason\":\" SalesOrderPurchase \"}}}}}";
		IspuToDfillPEGAResponse pegaResponse = null;
		pegaResponse = mapper.readValue(sampleUIResponseString, IspuToDfillPEGAResponse.class);
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"PEGA generated message\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\" SOP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"processMTNList\":[{\"mtn\":\"2515813860\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\"]},{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}],\"cartInfo\":{\"cartId\":\"3ef39561-697e-486c-befc-4996c8a6921f\",\"statusCode\":1,\"statusMsg\":\"Success\",\"preAuthSuccess\":false,\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"financeLimitExceeded\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":0,\"agreementNumber\":0},\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"GridWallPDP\",\"availablePaths\":[{\"path\":\"ShoppingCart`\"},{\"path\":\"addDevice\"},{\"path\":\"addFeatures`\"},{\"path\":\"showFeatures\"},{\"path\":\"showDevice`\"},{\"path\":\"showAccessory\"},{\"path\":\"addAccessory\"},{\"path\":\"TradeIn\"}],\"callReason\":\" SalesOrderPurchase \"}}}}}";
        IspuToDfillUIResponse response = mapper.readValue(responseString, IspuToDfillUIResponse.class);
        Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util.formatIspuToDfillResponse(pegaResponse, response);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util.formatIspuToDfillResponse(pegaResponse, response);
		Assert.assertNotNull(pegaResponse); 
	}
	
	@Test
	public void formatUpdateSellerPriceResponseTest() throws JsonMappingException, JsonProcessingException {
		String responseString ="{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"processAction\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"availablePaths\":[ { \"path\": \"AccessoryPDP\" } ]},\"customerInfo\":{\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\",\"accountNumber\":\"0820215913-00001\"},\"cartInfo\":{\"cartId\":\"2515813861\",\"statusCode\":\"0\",\"statusMsg\":\"Success\"},\"processMTNList\": [ { \"mtn\": \"2515813860\", \"completedprocessSteps\": [ \"MTNSelectionPage\", \"GridWallPDP\" ] },{ \"mtn\": \"2515813861\", \"completedprocessSteps\": [] } ]}}}}";
		UpdateSellerPriceUIResponseNew response = mapper.readValue(responseString, UpdateSellerPriceUIResponseNew.class);
		String sampleResponseString ="{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2021.10.11.07.27.54-971.878116739433\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4316492-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"},{\"path\":\"addDevice\"},{\"path\":\"addFeatures\"},{\"path\":\"showFeatures\"},{\"path\":\"showDevice\"},{\"path\":\"addAccessory\"},{\"path\":\"TradeIn\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\"},\"customerInfo\":{\"accountNumber\":\"0308437318-00001\",\"cartCreator\":\"4157987559\",\"processingMTN\":\"4157987559\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"43d7506f-c2e0-4e41-9d9e-4960536bf41e\",\"statusMsg\":\"SellerPrice Updated Successfully.\",\"statusCode\":\"1\",\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";
		UpdateSellerPricePEGAResponse pegaResponse = null;
		pegaResponse = mapper.readValue(sampleResponseString, UpdateSellerPricePEGAResponse.class);
		Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util.formatUpdateSellerPriceResponse(response, pegaResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util.formatUpdateSellerPriceResponse(response, pegaResponse);
		Assert.assertNotNull(pegaResponse); 
	}
	
	@Test
	public void formatOrderReviewTYSResponseTest() throws JsonMappingException, JsonProcessingException {
        String responseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-NETACE\", \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \"SOP-20647-E01\", \"contextInfo\": { \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"OrderReview-Shipping-Payment-Agreement\", \"processAction\": \"\", \"availablePaths\": [ { \"path\": \"AvailablePaths\" } ] }, \"cartInfo\": { \"cartId\": \"cbf26bd7-035a-49a0-ba2c-e320bc46f3bf\", \"method\": \"addtoCart\" }, \"customerInfo\": { \"registerNumber\": 0, \"accountNumber\": \"0224065213-00001\", \"cartCreator\": \"2402169848\", \"processingMTN\": \"2402169848\" }, \"processMTNList\": [ { \"mtn\": \"2402169848\", \"completedprocessSteps\": [ \"MTNSelectionPage\", \"GridWallPDP\", \"ShoppingCart\" ] } ], \"validateOrder\": { \"orderDetails\": [ { \"systemId\": \"\", \"creditApplicationNum\": \"382938499\", \"orderStatus\": \"SUCCESS\", \"shipmentAddressValidated\": true, \"userId\": \"\", \"statusMsg\": \"\", \"creditApprovalStatus\": \"AP\", \"creditStatusReason\": \"CA CVAS AUTOMATIC APPROVAL\", \"securityDepositAmount\": \"0\", \"loveligibility\": false, \"statusCode\": \"\" } ], \"cartId\": \"cbf26bd7-035a-49a0-ba2c-e320bc46f3bf\", \"locationCode\": \"E247201\" } } } }, \"cartReadyForCheckout\": true }";
        ReviewOrderTYSUIResponse response = mapper.readValue(responseString, ReviewOrderTYSUIResponse.class);
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-TELESALES\",\"statusMsg\":\"SUCCESS\",\"correlationId\":\"\",\"serviceName\":\"SalesOrderFlex\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"cartInfo\":{\"cartId\":\"d2d21206-d2e8-476e-9a0f-0f85a513ed8c\",\"statusCode\":1,\"statusMsg\":\"Replenishment Amount added successfully to cart\",\"addedReplenishmentAmt\":10.0,\"cartItemPrice\":60.0},\"contextInfo\":{\"availablePaths\":[{\"path\":\"LandingScreen\"}],\"processAction\":\"\",\"processStep\":\"LandingScreen\",\"callReason\":\"SalesOrderFlex\"},\"caseId\":\"SOF-8703675-E01\",\"customerInfo\":{\"cartCreator\":\"9142996416\",\"processingMTN\":\"newLine1\",\"accountNumber\":\"0385770139-00001\"},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\",\"AddReplenishment\"]}]}}}}";
		ReviewOrderPegaResponse pegaResponse = mapper.readValue(sampleResponseString, ReviewOrderPegaResponse.class);
		Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util.formatOrderReviewTYSResponse(response, pegaResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util.formatOrderReviewTYSResponse(response, pegaResponse);
		Assert.assertNotNull(pegaResponse);
	}
	
	@Test
	public void formatAddUpgradeDetailsResponseTest() throws JsonMappingException, JsonProcessingException {
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1858878952-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"AccessoryInterestial\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryInterestial\",\"processAction\":\"\",\"cradleFlowJourney\":\"AccessoryInterestialProspectPG\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\"},\"cartInfo\":{\"financeLimitExceeded\":\"true\",\"cartItemCount\":1,\"totalDueToday\":54.25,\"totalDueMonthly\":0.0,\"cartId\":\"a144d317-de87-468e-88ee-a5e223fdf152\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":19.59,\"monthlyInstallment\":19.44,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"MLA23LL/A\",\"installmentTerm\":\"0\",\"itemPrice\":\"699.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"iPhone 13\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0},\"sim\":{\"id\":\"EMBDSIM5G\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"isOnDemandAllowed\":false,\"isBackDateAllowed\":false,\"isFutureDateAllowed\":false,\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"ecpdProfileId\":\"\",\"protectionNotRequired\":false,\"fmiCheck\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}\n" +
                "\n";
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
		AddDevicePEGAResponse pegaResponse = new AddDevicePEGAResponse();
		pegaResponse = mapper.readValue(sampleResponseString, AddDevicePEGAResponse.class);
		Error error =new Error();
		error.setMessage("abc type error");
		List<Error> list = new ArrayList<>();
		list.add(error);
		pegaResponse.setErrors(list);
		util.formatAddUpgradeDetailsResponse(response, pegaResponse);
		Assert.assertNotNull(pegaResponse);
		pegaResponse.setServiceBody(null);
		pegaResponse.setServiceHeader(null);
		pegaResponse.setErrors(null);
		util.formatAddUpgradeDetailsResponse(response, pegaResponse);
		Assert.assertNotNull(pegaResponse);
        
	}
}