package onevz.soe.cart.util;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.cxp.feature.Flag;
import onevz.cxp.feature.util.FeatureFlag;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.constants.FeatureFlagConstants;
import onevz.soe.cart.model.addDevice.AddDeviceContext;
import onevz.soe.cart.model.addPromoIntent.AddPromoIntent;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.edgeup.EdgeUp;
import onevz.soe.cart.requests.AddDevicePEGARequest;
import onevz.soe.cart.requests.AddReplenishmentToCartPEGARequest;
import onevz.soe.cart.requests.SalesRepAndLocationCodePEGARequest;
import onevz.soe.cart.service.test.common.CartAbstractService;
import onevz.soe.cart.ui.common.AddDeviceData;
import onevz.soe.cart.ui.common.DeviceCartInfo;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.AddDeviceUIRequest;
import onevz.soe.cart.ui.requests.AddReplenishmentToCartUIRequest;
import onevz.soe.cart.ui.requests.SalesRepAndLocationCodeUIRequest;
import onevz.soe.wsclient.bpm.model.request.Add;
import onevz.soe.wsclient.bpm.model.request.Features;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.ResourceUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.*;

import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@WebFluxTest
public class CartPegaRequestUtil9Test extends CartAbstractService {

    String upgradeDetailsUIRequest="{\"cartInfo\":{\"cartId\":\"cartid\",\"caseId\":\"caseid\",\"amRole\":\"amRole\",\"ClientAppName\":\"ClientAppName\",\"accountNumber\":\"021313424200001\",\"cartCreator\":\"2513678339\",\"processingMTN\":\"2513678339\",\"processStep\":\"GridWallPDP\",\"processAction\":\"ExpressUpgrade\",\"intendType\":\"EUP\",\"isTradeInSelected\":false,\"IsComboOrderAllowed\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"noPendingOfferExists\":false,\"isPromoPDP\":false,\"mtnFlow\":\"M\",\"myvPage\":true},\"data\":{\"lines\":[{\"isCommonPDP\":true,\"mtn\":\"2513678339\",\"purchasePath\":\"EUP\",\"portInNumber\":\"\",\"eupNoPromoFlow\":false,\"editSim\":false,\"device\":{\"id\":\"SMS926UZAV\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":36,\"productId\":\"dev21411193\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"DFILLUNIV5G-SA-A\"},\"plan\":{\"isRecommendedPlan\":\"false\",\"id\":\"26907\"},\n" +
            "\"edgeup\":{\"deviceId\":\"26907\"},\"ispuFlow\":false,\"estimatedReadyByDate\":\"\",\"LineWithSkipMDN\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"newLineOrAAL\":false,\"isNewLine\":false,\"selectedPromoId\":\"promo4393822\",\"selectedPromoType\":\"TRADEIN_PROMO\",\"promoRejectionIndicator\":false,\"restrictedProductType\":\"EQP\",\"isIconicPhone\":false,\"selectedSedOfferId\":\"\",\"selectedSpoId\":\"\",\"isStrategicOffer\":false,\"restricted\":\"\",\"isTradeInIntentSelected\":true,\"tradeInInfo\":{\"deviceBrand\":\"Samsung\",\"deviceModel\":\"S23 Ultra\",\"aemOfferIds\":[\"1234\"],\"tradeinMarketingId\":\"1234\"}}],\"rtm\":{\"url\":\"https://vzwqa30.verizonwireless.com/smartphones/samsung-galaxy-s24-plus/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e2-marblegray\",\"name\":\"Galaxy S24+\",\"make\":\"Samsung\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://vzwqa30.verizonwireless.com/smartphones/samsung-galaxy-s24-plus/\"},\"enableFcc\":true}}";
    @Autowired
	private ObjectMapper mapper;

    @Value("${onevz.soe.cart.test.fileLocation}")
    private String testFileLocation;

    @Autowired
    SourceFileReaderUtil sourceFileReaderUtil;

    @Test
    public void formatAddReplenishmentRequestTest() throws IOException {
        //TestConfig gwConfig = getData(CartServiceTestConstants.ADD_ACCESSORY_PATH, "add-plan-5ghome");
        String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"OMNI-RETAIL\",\"accountNumber\":\"429134425\",\"cartCreator\":\"429134425\",\"creditAppNum\":\"429134425\",\"cartId\":\"f9d35199-5d42-4de2-815f-0adaa81b2a9c\",\"caseId\":\"SOF-9050592-E01\",\"processingMTN\":\"newLine1\",\"intendType\":\"NSE\",\"processStep\":\"removeReplenishment\"},\"data\":{\"lines\":[{\"mtn\":\"6127915731\",\"isActivateWithoutReplenish\":true,\"replenishmentAmount\":\"0.00\",\"processingMTN\":\"newLine1\"}]}}";
        AddReplenishmentToCartUIRequest UIRequest = new AddReplenishmentToCartUIRequest();
        AddReplenishmentToCartPEGARequest pegaRequest = new AddReplenishmentToCartPEGARequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddReplenishmentToCartUIRequest.class);
        CartPegaRequestUtil9.formatAddReplenishmentRequest(UIRequest, pegaRequest);
        StepVerifier.create(Mono.just(pegaRequest))
                .assertNext(req -> Assert.assertNotNull(pegaRequest))
                .expectComplete().verify();
    }
    @Test
    public void formatAddReplenishmentRequestTest1() throws IOException {
        //TestConfig gwConfig = getData(CartServiceTestConstants.ADD_ACCESSORY_PATH, "add-plan-5ghome");
        String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"OMNI-RETAIL\",\"accountNumber\":\"429134425\",\"cartCreator\":\"429134425\",\"creditAppNum\":\"429134425\",\"cartId\":\"f9d35199-5d42-4de2-815f-0adaa81b2a9c\",\"caseId\":\"SOF-9050592-E01\",\"processingMTN\":\"newLine1\",\"intendType\":\"AAL\",\"processStep\":\"addReplenishment\"},\"data\":{\"lines\":[{\"mtn\":\"6127915731\",\"isActivateWithoutReplenish\":true,\"replenishmentAmount\":\"0.00\",\"processingMTN\":\"newLine1\"}]}}";
        AddReplenishmentToCartUIRequest UIRequest = new AddReplenishmentToCartUIRequest();
        AddReplenishmentToCartPEGARequest pegaRequest = new AddReplenishmentToCartPEGARequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddReplenishmentToCartUIRequest.class);
        CartPegaRequestUtil9.formatAddReplenishmentRequest(UIRequest, pegaRequest);
        StepVerifier.create(Mono.just(pegaRequest))
                .assertNext(req -> Assert.assertNotNull(pegaRequest))
                .expectComplete().verify();
    }
    @Test
    public void formatAddReplenishmentRequestTest2() throws IOException {
        //TestConfig gwConfig = getData(CartServiceTestConstants.ADD_ACCESSORY_PATH, "add-plan-5ghome");
        String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"OMNI-RETAIL\",\"accountNumber\":\"429134425\",\"cartCreator\":\"429134425\",\"creditAppNum\":\"429134425\",\"cartId\":\"f9d35199-5d42-4de2-815f-0adaa81b2a9c\",\"caseId\":\"SOF-9050592-E01\",\"processingMTN\":\"newLine1\",\"intendType\":\"BYOD\",\"processStep\":\"addReplenishment\"},\"data\":{\"lines\":[{\"mtn\":\"6127915731\",\"isActivateWithoutReplenish\":true,\"replenishmentAmount\":\"0.00\",\"processingMTN\":\"newLine1\"}]}}";
        AddReplenishmentToCartUIRequest UIRequest = new AddReplenishmentToCartUIRequest();
        AddReplenishmentToCartPEGARequest pegaRequest = new AddReplenishmentToCartPEGARequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddReplenishmentToCartUIRequest.class);
        CartPegaRequestUtil9.formatAddReplenishmentRequest(UIRequest, pegaRequest);
        StepVerifier.create(Mono.just(pegaRequest))
                .assertNext(req -> Assert.assertNotNull(pegaRequest))
                .expectComplete().verify();
    }
    @Test
    public void formatUpdateSalesRepAndLocationCodeRequestAALTest() throws JsonProcessingException {
        String uiRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"accountNumber\": \"12345\",\"throttleName\":\"|Afo_Assisted|AssistedPreToPostTrial|\",\"bucketAllocator\":\"BAU\",\"caseId\": \"SOF-12038282-C01\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"\",\"intendType\": \"AAL\",\"mtnFlow\": \"mtnFlow\",\"scheduleOrder\": true,\"cartId\": \"cartId\",\"processAction\": \"processAction\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"creditAppNum\"},\"data\": {\"orderLocationCode\": \"orderLocationCode\",\"salesRepId\": \"salesRepId\"},\"safeTechSessionId\": \"safeTechSessionId\",\"globalId\": \"globalId\"}";
        SalesRepAndLocationCodePEGARequest pegaRequest = new SalesRepAndLocationCodePEGARequest();
        SalesRepAndLocationCodeUIRequest uiRequest = mapper.readValue(uiRequestString, SalesRepAndLocationCodeUIRequest.class);
        SalesRepAndLocationCodePEGARequest response = CartPegaRequestUtil9.formatUpdateSalesRepAndLocationCodeRequest(pegaRequest, uiRequest);
        Assert.assertEquals("AAL", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
    }

    @Test
    public void formatUpdateSalesRepAndLocationCodeRequestBYODTest() throws JsonProcessingException {
        String uiRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"accountNumber\": \"12345\",\"throttleName\":\"|Afo_Assisted|AssistedPreToPostTrial|\",\"bucketAllocator\":\"BAU\",\"caseId\": \"SOF-12038282-C01\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"\",\"intendType\": \"BYOD\",\"mtnFlow\": \"mtnFlow\",\"scheduleOrder\": true,\"cartId\": \"cartId\",\"processAction\": \"processAction\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"creditAppNum\"},\"data\": {\"orderLocationCode\": \"orderLocationCode\",\"salesRepId\": \"salesRepId\"},\"safeTechSessionId\": \"safeTechSessionId\",\"globalId\": \"globalId\"}";
        SalesRepAndLocationCodePEGARequest pegaRequest = new SalesRepAndLocationCodePEGARequest();
        SalesRepAndLocationCodeUIRequest uiRequest = mapper.readValue(uiRequestString, SalesRepAndLocationCodeUIRequest.class);
        SalesRepAndLocationCodePEGARequest response = CartPegaRequestUtil9.formatUpdateSalesRepAndLocationCodeRequest(pegaRequest, uiRequest);
        Assert.assertEquals("BYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
    }

    @Test
    public void formatUpdateSalesRepAndLocationCodeRequestBYODTestWithoutIntendTypeEmpty() throws JsonProcessingException {
        String uiRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"accountNumber\": \"12345\",\"caseId\": \"SOF-12038282-C01\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"\",\"intendType\": \"\",\"mtnFlow\": \"mtnFlow\",\"scheduleOrder\": true,\"cartId\": \"cartId\",\"processAction\": \"processAction\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"creditAppNum\"},\"data\": {\"orderLocationCode\": \"orderLocationCode\",\"salesRepId\": \"salesRepId\"},\"safeTechSessionId\": \"safeTechSessionId\",\"globalId\": \"globalId\"}";
        SalesRepAndLocationCodePEGARequest pegaRequest = new SalesRepAndLocationCodePEGARequest();
        SalesRepAndLocationCodeUIRequest uiRequest = mapper.readValue(uiRequestString, SalesRepAndLocationCodeUIRequest.class);
        SalesRepAndLocationCodePEGARequest response = CartPegaRequestUtil9.formatUpdateSalesRepAndLocationCodeRequest(pegaRequest, uiRequest);
        Assert.assertEquals("AAL", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
    }

    @Test
    public void formatUpdateSalesRepAndLocationCodeRequestBYODTestWithoutIntendTypeNULL() throws JsonProcessingException {
        String uiRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"accountNumber\": \"12345\",\"caseId\": \"SOF-12038282-C01\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"\",\"mtnFlow\": \"mtnFlow\",\"scheduleOrder\": true,\"cartId\": \"cartId\",\"processAction\": \"processAction\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"creditAppNum\"},\"data\": {\"orderLocationCode\": \"orderLocationCode\",\"salesRepId\": \"salesRepId\"},\"safeTechSessionId\": \"safeTechSessionId\",\"globalId\": \"globalId\"}";
        SalesRepAndLocationCodePEGARequest pegaRequest = new SalesRepAndLocationCodePEGARequest();
        SalesRepAndLocationCodeUIRequest uiRequest = mapper.readValue(uiRequestString, SalesRepAndLocationCodeUIRequest.class);
        SalesRepAndLocationCodePEGARequest response = CartPegaRequestUtil9.formatUpdateSalesRepAndLocationCodeRequest(pegaRequest, uiRequest);
        Assert.assertEquals("AAL", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
    }
    
    @Test
    public void formatUpdateSalesRepAndLocationCodeRequestBYODTestWithoutIntendTypeNULLTEST() throws JsonProcessingException {
        String uiRequestString = "{\"cartInfo\":{\"cartId\":\"06377135-2790-43ad-b570-6f04d2c2c3fc\",\"caseId\":\"SOA-12729706-C01\",\"accountNumber\":\"0316938161-00001\",\"cartCreator\":\"11110915\",\"processingMTN\":\"3023578822\",\"processStep\":\"ShoppingCart\",\"intendType\":\"REX\",\"creditAppNum\":null},\"data\":{\"orderLocationCode\":null,\"salesRepId\":\"ENC01\"}}";
        SalesRepAndLocationCodePEGARequest pegaRequest = new SalesRepAndLocationCodePEGARequest();
        SalesRepAndLocationCodeUIRequest uiRequest = mapper.readValue(uiRequestString, SalesRepAndLocationCodeUIRequest.class);
        SalesRepAndLocationCodePEGARequest response = CartPegaRequestUtil9.formatUpdateSalesRepAndLocationCodeRequest(pegaRequest, uiRequest);
        Assert.assertEquals("REX", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
    }

    @Test
    public void formatAddUpgradeDeailsRequestTest() throws IOException{
        AddDeviceUIRequest request = mapper.readValue(upgradeDetailsUIRequest, AddDeviceUIRequest.class);
        AddDevicePEGARequest pegareq = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(),request,false,false);
        StepVerifier.create(Mono.just(pegareq))
                .assertNext(req -> Assert.assertNotNull(pegareq.getServiceBody().getServiceRequest().getContext().getCartInfo()))
                .expectComplete().verify();
    }

    @Test
    public void formatAddUpgradeDeailsRequestForSecondNumberTest() throws IOException{
        AddDeviceUIRequest request = mapper.readValue(upgradeDetailsUIRequest, AddDeviceUIRequest.class);
        Lines secondLine = new Lines();
        BeanUtils.copyProperties(request.getData().getLines().get(0),secondLine);
        SecondNumber secondNumber = new SecondNumber();
        secondNumber.setIsSecondNumber(true);
        secondNumber.setPrimaryMtn("1234567890");
        secondNumber.setSecondMtn("0987654321");
        secondLine.setSecondNumber(secondNumber);
        request.getData().getLines().add(secondLine);
        AddDevicePEGARequest pegareq = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(),request,false,false);
        StepVerifier.create(Mono.just(pegareq))
                .assertNext(req -> Assert.assertNotNull(pegareq.getServiceBody().getServiceRequest().getContext().getCartInfo()))
                .expectComplete().verify();
    }

    @Test
    public void formatAddUDREmptyProcessStepTest() throws IOException{
        AddDeviceUIRequest request = mapper.readValue(upgradeDetailsUIRequest, AddDeviceUIRequest.class);
        request.getCartInfo().setProcessStep("");
        request.getCartInfo().setProcessAction("");
        request.getCartInfo().setIsTradeInSelected(null);
        request.getData().getLines().get(0).setMtn("");
        AddDevicePEGARequest pegareq = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(),request,false,false);
        StepVerifier.create(Mono.just(pegareq))
                .assertNext(req -> Assert.assertNotNull(pegareq.getServiceBody().getServiceRequest().getContext().getCartInfo()))
                .expectComplete().verify();

    }

    @Test
    public void formatAddUpgradeDetailNonLoggedInCRMEmailTest() throws IOException {
        AddDeviceUIRequest request = mapper.readValue(upgradeDetailsUIRequest, AddDeviceUIRequest.class);

        request.getCartInfo().setCartCreator("1234567890");
        request.getCartInfo().setProcessingMTN("");

        AddDevicePEGARequest pegareq1 = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(), request,false,false);
        StepVerifier.create(Mono.just(pegareq1)).assertNext(req -> Assert.assertNotNull(pegareq1.getServiceBody().getServiceRequest().getContext().getCartInfo())).expectComplete().verify();

        request.getCartInfo().setCartCreator("1234567890");
        request.getCartInfo().setProcessingMTN("1234567891");

        AddDevicePEGARequest pegareq2 = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(), request,false,false);
        StepVerifier.create(Mono.just(pegareq2)).assertNext(req -> Assert.assertNotNull(pegareq2.getServiceBody().getServiceRequest().getContext().getCartInfo())).expectComplete().verify();

        request.getCartInfo().setCartCreator("");
        request.getCartInfo().setProcessingMTN("1234567891");

        AddDevicePEGARequest pegareq3 = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(), request, false,false);
        StepVerifier.create(Mono.just(pegareq3)).assertNext(req -> Assert.assertNotNull(pegareq3.getServiceBody().getServiceRequest().getContext().getCartInfo())).expectComplete().verify();

        request.getCartInfo().setCartCreator("");
        request.getCartInfo().setProcessingMTN("");

        AddDevicePEGARequest pegareq4 = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(), request, false,false);
        StepVerifier.create(Mono.just(pegareq4)).assertNext(req -> Assert.assertNotNull(pegareq4.getServiceBody().getServiceRequest().getContext().getCartInfo())).expectComplete().verify();

        request.getCartInfo().setBuyOutFlag("Y");

        AddDevicePEGARequest pegareq5 = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(), request, false,false);
        StepVerifier.create(Mono.just(pegareq5)).assertNext(req -> Assert.assertNotNull(pegareq4.getServiceBody().getServiceRequest().getContext().getCartInfo())).expectComplete().verify();

        request.getCartInfo().setBuyOutFlag("N");

        AddDevicePEGARequest pegareq6 = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(), request, false,false);
        StepVerifier.create(Mono.just(pegareq6)).assertNext(req -> Assert.assertNotNull(pegareq4.getServiceBody().getServiceRequest().getContext().getCartInfo())).expectComplete().verify();

        request.getCartInfo().setBuyOutFlag("");

        AddDevicePEGARequest pegareq7 = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(), request, false,false);
        StepVerifier.create(Mono.just(pegareq7)).assertNext(req -> Assert.assertNotNull(pegareq4.getServiceBody().getServiceRequest().getContext().getCartInfo())).expectComplete().verify();
    }

    @Test
    public void formatAddUDREmptyTradeInSelectedTest() throws IOException{
        AddDeviceUIRequest request = mapper.readValue(upgradeDetailsUIRequest, AddDeviceUIRequest.class);
        request.getCartInfo().setProcessStep("");
        request.getCartInfo().setIsTradeInSelected(null);
        request.getData().getLines().get(0).setIsTradeInIntentSelected(null);
        request.getData().getLines().get(0).setMtn(null);
        request.getData().getLines().get(0).setSelectedSedOfferId("123456");
        request.getData().getLines().get(0).setLineWithSkipMDN(true);
        request.getData().getLines().get(0).setIspuFlow(true);
        request.getData().getLines().get(0).setQaIconicTesting(true);
        request.getData().getLines().get(0).setEstimatedReadyByDate("123");
        List<BvoOffers> selectedOffers = new ArrayList<>();
        BvoOffers selectedoffer = new BvoOffers();
        selectedoffer.setId("12345");
        selectedOffers.add(selectedoffer);
        request.getData().getLines().get(0).setSelectedOffers(selectedOffers);
        request.getData().getLines().get(0).setEditSim(true);
        request.getData().getLines().get(0).setEupNoPromoFlow(true);
        request.getData().getLines().get(0).setDepletionLocationCode(null);
        request.getData().getLines().get(0).setRestrictedProductType(null);
        request.getData().getLines().get(0).setInWithVerizonOpted(true);
        request.getCartInfo().setIsPromoPDP(true);
        request.getCartInfo().setNoPendingOfferExists(true);
        request.getCartInfo().setIsComboOrderAllowed(true);
        request.getCartInfo().setFlexV2(true);
        request.getCartInfo().setPrepaidToPostpaidMigration(true);
        AddDevicePEGARequest pegareq = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(),request, false,false);
        StepVerifier.create(Mono.just(pegareq))
                .assertNext(req -> Assert.assertNotNull(pegareq.getServiceBody().getServiceRequest().getContext().getCartInfo()))
                .expectComplete().verify();

        request.getCartInfo().setIsTradeInSelected(true);
        AddDevicePEGARequest pegareq1 = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(),request, false,false);
        StepVerifier.create(Mono.just(pegareq))
                .assertNext(req -> Assert.assertNotNull(pegareq.getServiceBody().getServiceRequest().getContext().getCartInfo()))
                .expectComplete().verify();
    }

    @Test
    public void formatAddUpgradeDetailBatteryDamaged() throws IOException {
        AddDeviceUIRequest request = mapper.readValue(upgradeDetailsUIRequest, AddDeviceUIRequest.class);

        request.getData().getLines().get(0).setIsBatteryDamaged(true);

        AddDevicePEGARequest pegareq1 = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(), request, false,false);
        StepVerifier.create(Mono.just(pegareq1)).assertNext(req -> Assert.assertNotNull(pegareq1.getServiceBody().getServiceRequest().getContext().getCartInfo())).expectComplete().verify();

        request.getData().getLines().get(0).setIsBatteryDamaged(false);
        AddDevicePEGARequest pegareq2 = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(), request, false,false);
        StepVerifier.create(Mono.just(pegareq2)).assertNext(req -> Assert.assertNotNull(pegareq2.getServiceBody().getServiceRequest().getContext().getCartInfo())).expectComplete().verify();

        request.getData().getLines().get(0).setIsBatteryDamaged(null);
        AddDevicePEGARequest pegareq3 = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(), request, false,false);
        StepVerifier.create(Mono.just(pegareq3)).assertNext(req -> Assert.assertNotNull(pegareq2.getServiceBody().getServiceRequest().getContext().getCartInfo())).expectComplete().verify();
    }

    @Test
    public void formatAddUpgradeDetailPlanTest() throws IOException {
        AddDeviceUIRequest request = mapper.readValue(upgradeDetailsUIRequest, AddDeviceUIRequest.class);

        request.getData().getLines().get(0).getPlan().setId("");

        AddDevicePEGARequest pegareq1 = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(), request, false,false);
        StepVerifier.create(Mono.just(pegareq1)).assertNext(req -> Assert.assertNotNull(pegareq1.getServiceBody().getServiceRequest().getContext().getCartInfo())).expectComplete().verify();

        request.getData().getLines().get(0).setPlan(null);
        AddDevicePEGARequest pegareq2 = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(), request, false,false);
        StepVerifier.create(Mono.just(pegareq2)).assertNext(req -> Assert.assertNotNull(pegareq2.getServiceBody().getServiceRequest().getContext().getCartInfo())).expectComplete().verify();

        request.getData().getLines().get(0).setMtn("");
        request.getCartInfo().setProcessingMTN("");
        request.getCartInfo().setCartCreator("123456789");
        AddDevicePEGARequest pegareq3 = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(), request, false,false);
        StepVerifier.create(Mono.just(pegareq3)).assertNext(req -> Assert.assertNotNull(pegareq2.getServiceBody().getServiceRequest().getContext().getCartInfo())).expectComplete().verify();

        request.getData().getLines().get(0).setMtn("");
        request.getCartInfo().setProcessingMTN("");
        request.getCartInfo().setCartCreator("");
        AddDevicePEGARequest pegareq4 = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(), request, false,false);
        StepVerifier.create(Mono.just(pegareq4)).assertNext(req -> Assert.assertNotNull(pegareq2.getServiceBody().getServiceRequest().getContext().getCartInfo())).expectComplete().verify();
    }

    @Test
    public void formatAddUpgradeDetailEdgeupTest() throws IOException {
        AddDeviceUIRequest request = mapper.readValue(upgradeDetailsUIRequest, AddDeviceUIRequest.class);
        request.getData().getLines().get(0).getEdgeup().setDeviceId("");
        AddDevicePEGARequest edgeup = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(), request, false,false);
        StepVerifier.create(Mono.just(edgeup)).assertNext(req -> Assert.assertNotNull(edgeup.getServiceBody().getServiceRequest().getContext().getCartInfo())).expectComplete().verify();

        request.getData().getLines().get(0).setEdgeup(null);
        AddDevicePEGARequest pegareq2 = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(), request, false,false);
        StepVerifier.create(Mono.just(pegareq2)).assertNext(req -> Assert.assertNotNull(pegareq2.getServiceBody().getServiceRequest().getContext().getCartInfo())).expectComplete().verify();

    }

    @Test
    public void formatAddUpgradeDeailsRequestEdgeUpTest() throws IOException{
        AddDeviceUIRequest request = mapper.readValue(upgradeDetailsUIRequest, AddDeviceUIRequest.class);
        EdgeUp edgeUp = new EdgeUp();
        edgeUp.setDeviceId("1234567890");
        request.getData().getLines().get(0).setEdgeup(edgeUp);
        AddDevicePEGARequest pegareq = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(),request, false,false);
        StepVerifier.create(Mono.just(pegareq))
                .assertNext(req -> Assert.assertNotNull(pegareq.getServiceBody().getServiceRequest().getContext().getCartInfo()))
                .expectComplete().verify();
    }

    @Test
    public void formatAddUpgradeDeailsRequestEdgeBuyOutTest() throws IOException{
        AddDeviceUIRequest request = mapper.readValue(upgradeDetailsUIRequest, AddDeviceUIRequest.class);
        request.getData().getLines().get(0).setIsEdgeBuyOut(true);
        AddDevicePEGARequest pegareq = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(),request, false,false);
        StepVerifier.create(Mono.just(pegareq))
                .assertNext(req -> Assert.assertNotNull(pegareq.getServiceBody().getServiceRequest().getContext().getCartInfo()))
                .expectComplete().verify();
    }

    @Test
    public void formatAddUpgradeDetailDeaturesTest() throws IOException {
        AddDeviceUIRequest request = mapper.readValue(upgradeDetailsUIRequest, AddDeviceUIRequest.class);

        Features features=new Features();
        List<Add> list=new ArrayList<>();
        Add add=new Add();
        add.setId("1");
        add.setActionIndicator("A");
        add.setQuantity("1");
        add.setType("SFO");
        list.add(add);
        features.setAdd(list);
        request.getData().getLines().get(0).setExpressUpgradeFeatures(features);

        AddDevicePEGARequest pegareq1 = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(), request, false,false);
        StepVerifier.create(Mono.just(pegareq1)).assertNext(req -> Assert.assertNotNull(pegareq1.getServiceBody().getServiceRequest().getContext().getCartInfo())).expectComplete().verify();
    }
    
    @Test
    public void formatAddUpgradeDetailsCodeCoverageTest() {
        var addDeviceUIRequest = new AddDeviceUIRequest();
        addDeviceUIRequest.setCartInfo(new DeviceCartInfo());
        AddDeviceData data = new AddDeviceData();
        Lines e1 = new Lines();
        e1.setDevice(new Device());
        e1.setRestricted("Y");
        AddDeviceTradeInInfo tradeInInfo = new AddDeviceTradeInInfo();
        tradeInInfo.setTradeinMarketingId("Yes");
        e1.setTradeInInfo(tradeInInfo);
        data.setLines(List.of(e1, new Lines()));
        addDeviceUIRequest.setData(data);
        var addDevicePEGARequest = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(),addDeviceUIRequest, false,false);
        StepVerifier.create(Mono.just(addDevicePEGARequest))
                .assertNext(req -> Assert.assertNotNull(addDevicePEGARequest.getServiceBody()))
                .expectComplete().verify();
    }

    @Test
    public void formatAddUpgradeDetailTradeInShippingTypeTest() throws IOException {
        AddDeviceUIRequest request = mapper.readValue(upgradeDetailsUIRequest, AddDeviceUIRequest.class);

        request.getData().getLines().get(0).setTradeInShippingType("UPSDrop-off_QRCode");

        AddDevicePEGARequest pegareq1 = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(), request, false,false);
        StepVerifier.create(Mono.just(pegareq1)).assertNext(req -> Assert.assertNotNull(pegareq1.getServiceBody().getServiceRequest().getContext().getCartInfo())).expectComplete().verify();

        request.getData().getLines().get(0).setTradeInShippingType(null);
        AddDevicePEGARequest pegareq2 = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(), request, false,false);
        StepVerifier.create(Mono.just(pegareq2)).assertNext(req -> Assert.assertNotNull(pegareq2.getServiceBody().getServiceRequest().getContext().getCartInfo())).expectComplete().verify();
    }

    @Test
    public void formatAddUpgradeDetailTradeTest() throws IOException {
        AddDeviceUIRequest request = mapper.readValue(upgradeDetailsUIRequest, AddDeviceUIRequest.class);

        request.getData().getLines().get(0).setTradeDeviceId("354058242721132");
        request.getData().getLines().get(0).setTradeRecycleDeviceSku("MU6C3LL/A");

        AddDevicePEGARequest pegareq1 = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(), request, false,false);
        StepVerifier.create(Mono.just(pegareq1)).assertNext(req -> Assert.assertNotNull(pegareq1.getServiceBody().getServiceRequest().getContext().getCartInfo())).expectComplete().verify();

        request.getData().getLines().get(0).setTradeDeviceId("354058242721132");
        request.getData().getLines().get(0).setTradeRecycleDeviceSku("");

        AddDevicePEGARequest pegareq2 = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(), request, false,false);
        StepVerifier.create(Mono.just(pegareq2)).assertNext(req -> Assert.assertNotNull(pegareq2.getServiceBody().getServiceRequest().getContext().getCartInfo())).expectComplete().verify();

        request.getData().getLines().get(0).setTradeDeviceId("");
        request.getData().getLines().get(0).setTradeRecycleDeviceSku("MU6C3LL/A");

        AddDevicePEGARequest pegareq3 = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(), request, false,false);
        StepVerifier.create(Mono.just(pegareq3)).assertNext(req -> Assert.assertNotNull(pegareq3.getServiceBody().getServiceRequest().getContext().getCartInfo())).expectComplete().verify();

        request.getData().getLines().get(0).setTradeDeviceId(null);
        request.getData().getLines().get(0).setTradeRecycleDeviceSku("");

        AddDevicePEGARequest pegareq4 = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(), request, false,false);
        StepVerifier.create(Mono.just(pegareq4)).assertNext(req -> Assert.assertNotNull(pegareq4.getServiceBody().getServiceRequest().getContext().getCartInfo())).expectComplete().verify();


    }

    @Test
    public void formatAddUpgradeDeailsRequestChoiceTest() throws IOException{
        AddDeviceUIRequest request = mapper.readValue(upgradeDetailsUIRequest, AddDeviceUIRequest.class);
        EdgeUp edgeUp = new EdgeUp();
        edgeUp.setDeviceId("1234567890");
        request.getData().getLines().get(0).setEdgeup(edgeUp);
        AddPromoIntent promoIntent = new AddPromoIntent();
        List<AddPromoIntent> promIntentList = new ArrayList<>();
        promoIntent.setPromotionId("123");
        promoIntent.setOfferId("1234");
        promoIntent.setPromoType("TRADEIN_PROMO");
        promoIntent.setChoiceOffer(true);
        promIntentList.add(promoIntent);
        request.getData().getLines().get(0).setPromoIntent(promIntentList);

        AddDevicePEGARequest pegareq = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(),request, true,false);
        StepVerifier.create(Mono.just(pegareq))
                .assertNext(req -> Assert.assertNotNull(pegareq.getServiceBody().getServiceRequest().getContext().getCartInfo()))
                .expectComplete().verify();
    }

    @Test
    public void formatAddDeviceRequestTestNumberShareAIQuote() throws IOException {
        //NumberShare enabled
        File file = ResourceUtils.getFile("classpath:data/Requests/AIQuoteNumberShareYReq.json");
        String requestString = new String(Files.readAllBytes(file.toPath()));
        AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDevicePEGARequest pegaRequest = new AddDevicePEGARequest();
        AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(pegaRequest, uiRequest, "",true,true,true, getFFlag());
        Assert.assertTrue(response.getServiceBody().getServiceRequest().getContext().getCartInfo().getTriggerPricingValidation());

        //NumberShare enabled, mtnFlow is empty
        uiRequest.getCartInfo().setMtnFlow("");
        response = CartPegaRequestUtil4.formatAddDeviceRequest(pegaRequest, uiRequest, "",true,true,true, getFFlag());
        Assert.assertFalse(response.getServiceBody().getServiceRequest().getContext().getCartInfo().getTriggerPricingValidation());

        //NumberShare enabled, mtnFlow is not empty and not AIQuote
        uiRequest.getCartInfo().setMtnFlow("NotAIQuote");
        response = CartPegaRequestUtil4.formatAddDeviceRequest(pegaRequest, uiRequest, "",true,true,true, getFFlag());
        Assert.assertFalse(response.getServiceBody().getServiceRequest().getContext().getCartInfo().getTriggerPricingValidation());

        //NumberShare disabled
        file = ResourceUtils.getFile("classpath:data/Requests/AIQuoteNumberShareNReq.json");
        requestString = new String(Files.readAllBytes(file.toPath()));
        uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
        response = CartPegaRequestUtil4.formatAddDeviceRequest(pegaRequest, uiRequest, "",true,true,true, getFFlag());
        Assert.assertTrue(response.getServiceBody().getServiceRequest().getContext().getCartInfo().getTriggerPricingValidation());
    }
    private Flag getFFlag() {
        Flag flag = new Flag();
        flag.setName(FeatureFlagConstants.FLAG_NAME_ACTIVATION_FEE_WAIVER_FFAG);
        flag.setEnabled(true);
        flag.setFound(true);
        List<String> offerCode = new ArrayList<>();
        offerCode.add("DP2PM");
        Map<String, List<String>> fmap = new HashMap<>();
        fmap.put("offerCode", offerCode);
        flag.setAttributes(fmap);

        return flag;
    }

    @Test
    public void updatesForSalesOrderFlexFlow(){
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        DeviceCartInfo deviceCartInfo= new DeviceCartInfo();
        AddDeviceData data= new AddDeviceData();
        Lines lines= new Lines();
        Device device= new Device();
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartServiceContextInfo cartServiceContextInfo = new CartServiceContextInfo();
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();

        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class,"updatesForSalesOrderFlexFlow",request, cartServiceContextInfo, serviceHeader, cartInfo);
        Assert.assertNull(cartInfo.getIsPrepayCart());

        request.setCartInfo(deviceCartInfo);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class,"updatesForSalesOrderFlexFlow",request, cartServiceContextInfo, serviceHeader, cartInfo);
        Assert.assertNull(cartInfo.getIsPrepayCart());

        deviceCartInfo.setCaseId("TEST");
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class,"updatesForSalesOrderFlexFlow",request, cartServiceContextInfo, serviceHeader, cartInfo);
        Assert.assertNull(cartInfo.getIsPrepayCart());

        deviceCartInfo.setCaseId("SOF");
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class,"updatesForSalesOrderFlexFlow",request, cartServiceContextInfo, serviceHeader, cartInfo);
        Assert.assertNull(cartInfo.getOneClick());

        deviceCartInfo.setOneClick(false);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class,"updatesForSalesOrderFlexFlow",request, cartServiceContextInfo, serviceHeader, cartInfo);
        Assert.assertNull(cartInfo.getOneClick());

        deviceCartInfo.setOneClick(true);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class,"updatesForSalesOrderFlexFlow",request, cartServiceContextInfo, serviceHeader, cartInfo);
        Assert.assertTrue(cartInfo.getOneClick());

        request.setChannelId(CartConstants.OMNI_D2D);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class,"updatesForSalesOrderFlexFlow",request, cartServiceContextInfo, serviceHeader, cartInfo);
        Assert.assertNull(cartInfo.getIsPrepayCart());

        request.setChannelId(CartConstants.OMNI_TELESALES);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class,"updatesForSalesOrderFlexFlow",request, cartServiceContextInfo, serviceHeader, cartInfo);
        Assert.assertNull(cartInfo.getIsPrepayCart());

        request.setData(data);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class,"updatesForSalesOrderFlexFlow",request, cartServiceContextInfo, serviceHeader, cartInfo);
        Assert.assertNull(cartInfo.getIsPrepayCart());

        data.setLines(Collections.singletonList(null));
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class,"updatesForSalesOrderFlexFlow",request, cartServiceContextInfo, serviceHeader, cartInfo);
        Assert.assertNull(cartInfo.getIsPrepayCart());

        data.setLines(Collections.singletonList(lines));
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class,"updatesForSalesOrderFlexFlow",request, cartServiceContextInfo, serviceHeader, cartInfo);
        Assert.assertNull(cartInfo.getIsPrepayCart());

        lines.setDevice(device);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class,"updatesForSalesOrderFlexFlow",request, cartServiceContextInfo, serviceHeader, cartInfo);
        Assert.assertNull(cartInfo.getIsPrepayCart());

        device.setIsCustomerProvidedEquipment(false);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class,"updatesForSalesOrderFlexFlow",request, cartServiceContextInfo, serviceHeader, cartInfo);
        Assert.assertNull(cartInfo.getIsPrepayCart());

        device.setIsCustomerProvidedEquipment(true);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class,"updatesForSalesOrderFlexFlow",request, cartServiceContextInfo, serviceHeader, cartInfo);
        Assert.assertTrue(cartInfo.getIsPrepayCart());
    }

    @Test
    public void setServiceHeader(){
        CartServiceServiceHeader serviceHeader= new CartServiceServiceHeader();
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        DeviceCartInfo cartInfo= new DeviceCartInfo();

        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setServiceHeader", serviceHeader,request);
        Assert.assertNull(serviceHeader.getServiceName());

        request.setCartInfo(cartInfo);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setServiceHeader", serviceHeader,request);
        Assert.assertNull( serviceHeader.getServiceName());

        cartInfo.setIntendType(CartConstants.REFUND_EXCHANGE);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setServiceHeader", serviceHeader,request);
        Assert.assertEquals(CartConstants.SALES_ORDER_ADJUSTMENT, serviceHeader.getServiceName());

        cartInfo.setIntendType(CartConstants.CONTRACT_CHANGE);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setServiceHeader", serviceHeader,request);
        Assert.assertEquals(CartConstants.SALES_ORDER_ADJUSTMENT, serviceHeader.getServiceName());

        cartInfo.setIntendType(CartConstants.EXCHANGE);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setServiceHeader", serviceHeader,request);
        Assert.assertEquals(CartConstants.SALES_ORDER_ADJUSTMENT, serviceHeader.getServiceName());

        cartInfo.setIntendType(CartConstants.CLNR_FLOW);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setServiceHeader", serviceHeader,request);
        Assert.assertEquals(CartConstants.SALES_ORDER_ADJUSTMENT, serviceHeader.getServiceName());

        cartInfo.setIntendType(CartConstants.EXCBYOD);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setServiceHeader", serviceHeader,request);
        Assert.assertEquals(CartConstants.SALES_ORDER_ADJUSTMENT, serviceHeader.getServiceName());

        cartInfo.setIntendType(CartConstants.PAD);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setServiceHeader", serviceHeader,request);
        Assert.assertEquals(CartConstants.SALES_ORDER_ADJUSTMENT, serviceHeader.getServiceName());

        cartInfo.setIntendType("");
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setServiceHeader", serviceHeader,request);
        Assert.assertEquals(CartConstants.SALES_ORDER_ADJUSTMENT, serviceHeader.getServiceName());

    }
    @Test
    public void setCaseId(){
        AddDeviceContext context= new AddDeviceContext();
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        request.setCartInfo(new DeviceCartInfo());

        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setCaseId", context,request);
        Assert.assertEquals(request.getCartInfo().getCaseId(), context.getCaseId());

        request.setRequestApiName("test");
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setCaseId", context,request);
        Assert.assertEquals(request.getCartInfo().getCaseId(), context.getCaseId());

        request.setRequestApiName("add-step");
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setCaseId", context,request);
        Assert.assertNotEquals(request.getCartInfo().getCaseId(), context.getCaseId());

    }

    @Test
    public void setIntent(){
        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        DeviceCartInfo deviceCartInfo = new DeviceCartInfo();
        AddDeviceData addDeviceData = new AddDeviceData();
        Lines lines = new Lines();
        Device device = new Device();
        device.setNetworkBandwidthType("Test");
        lines.setDevice(device);
        addDeviceData.setLines(Collections.singletonList(lines));
        request.setCartInfo(deviceCartInfo);
        request.setData(addDeviceData);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setIntent", contextInfo,cartInfo, request);
        Assert.assertNull(contextInfo.getIntent());

        deviceCartInfo.setRpsIntent("Test");
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setIntent", contextInfo,cartInfo, request);
        Assert.assertNotNull(contextInfo.getIntent());

        deviceCartInfo.setIntendType(CartConstants.INTEND_TYPE);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setIntent", contextInfo,cartInfo, request);
        Assert.assertNull(cartInfo.getIntendType());

        deviceCartInfo.setIntendType(CartConstants.NSE);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setIntent", contextInfo,cartInfo, request);
        Assert.assertNotNull(cartInfo.getIntendType());

        device.setNetworkBandwidthType("CBD");
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setIntent", contextInfo,cartInfo, request);
        Assert.assertNotNull(cartInfo.getIntendType());

        device.setNetworkBandwidthType("LTE");
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setIntent", contextInfo,cartInfo, request);
        Assert.assertNotNull(cartInfo.getIntendType());

    }

    @Test
    public void finalUpdates(){
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        AddDeviceContext context=  new AddDeviceContext();
        AddDevicePEGARequest pegaRequest= new AddDevicePEGARequest();
        Boolean skipResumeCaseFFlag= false;
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        DeviceCartInfo deviceCartInfo= new DeviceCartInfo();

        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "finalUpdates", cartInfo,contextInfo,context,pegaRequest,skipResumeCaseFFlag, request);
        Assert.assertNull(request.getCartInfo());

        request.setCartInfo(deviceCartInfo);
        deviceCartInfo.setVztExternalAccountId("Test");
        deviceCartInfo.setPastdue(new PastDue());
        deviceCartInfo.setPastDueAccepted("test");
        deviceCartInfo.setSkipResumeCase(false);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "finalUpdates", cartInfo,contextInfo,context,pegaRequest,skipResumeCaseFFlag, request);
        Assert.assertNotNull(cartInfo.getVztExternalAccountId());

    }

    @Test
    public void setIntentForNSEBYOD(){
        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        DeviceCartInfo deviceCartInfo= new DeviceCartInfo();
        AddDeviceData addDeviceData= new AddDeviceData();
        Lines lines= new Lines();
        Device device= new Device();
        request.setCartInfo(deviceCartInfo);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setIntentForNSEBYOD", contextInfo,cartInfo,customerInfo,request);
        Assert.assertNull(contextInfo.getIntent());

        deviceCartInfo.setIntendType("intent");
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setIntentForNSEBYOD", contextInfo,cartInfo,customerInfo,request);
        Assert.assertNull(contextInfo.getIntent());

        deviceCartInfo.setIntendType(CartConstants.NSE_BYOD);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setIntentForNSEBYOD", contextInfo,cartInfo,customerInfo,request);
        Assert.assertNotNull(contextInfo.getIntent());

        request.setData(addDeviceData);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setIntentForNSEBYOD", contextInfo,cartInfo,customerInfo,request);
        Assert.assertNotNull(contextInfo.getIntent());

        addDeviceData.setLines(Collections.emptyList());
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setIntentForNSEBYOD", contextInfo,cartInfo,customerInfo,request);
        Assert.assertNotNull(contextInfo.getIntent());

        addDeviceData.setLines(Collections.singletonList(lines));
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setIntentForNSEBYOD", contextInfo,cartInfo,customerInfo,request);
        Assert.assertNotNull(contextInfo.getIntent());

        lines.setDevice(device);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setIntentForNSEBYOD", contextInfo,cartInfo,customerInfo,request);
        Assert.assertNotNull(contextInfo.getIntent());

        device.setByodESimPhone(false);
        lines.setEditSim(true);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setIntentForNSEBYOD", contextInfo,cartInfo,customerInfo,request);
        Assert.assertNotNull(customerInfo.getEditSim());
    }

    @Test
    public  void setTriggerPricingValidation(){
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        DeviceCartInfo deviceCartInfo= new DeviceCartInfo();
        request.setCartInfo(deviceCartInfo);

        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setTriggerPricingValidation", cartInfo,request);
        Assert.assertNull(cartInfo.getTriggerPricingValidation());

        deviceCartInfo.setClientAppName(CartConstants.VZW_RPS);
        deviceCartInfo.setTriggerPricingValidation(true);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setTriggerPricingValidation", cartInfo,request);
        Assert.assertTrue(cartInfo.getTriggerPricingValidation());

        cartInfo.setTriggerPricingValidation(null);
        deviceCartInfo.setClientAppName(CartConstants.VZW_BBP);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setTriggerPricingValidation", cartInfo,request);
        Assert.assertNull(cartInfo.getTriggerPricingValidation());

        request.setChannelId(CartConstants.RETAIL);
        deviceCartInfo.setMtnFlow(CartConstants.PROMOBUNDLE);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setTriggerPricingValidation", cartInfo,request);
        Assert.assertTrue(cartInfo.getTriggerPricingValidation());

        cartInfo.setTriggerPricingValidation(null);
        request.setChannelId(CartConstants.RETAIL);
        deviceCartInfo.setMtnFlow(CartConstants.PROMO_HUB);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setTriggerPricingValidation", cartInfo,request);
        Assert.assertNull(cartInfo.getTriggerPricingValidation());

        request.setChannelId(CartConstants.RETAIL_IPAD);
        deviceCartInfo.setMtnFlow(CartConstants.PROMOBUNDLE);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setTriggerPricingValidation", cartInfo,request);
        Assert.assertTrue(cartInfo.getTriggerPricingValidation());

        cartInfo.setTriggerPricingValidation(null);
        request.setChannelId(CartConstants.RETAIL_IPAD);
        deviceCartInfo.setMtnFlow(CartConstants.PROMO_HUB);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setTriggerPricingValidation", cartInfo,request);
        Assert.assertNull(cartInfo.getTriggerPricingValidation());

    }

    @Test
    public void setItemTypeAndIntendType(){
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        DeviceCartInfo deviceCartInfo= new DeviceCartInfo();
        request.setCartInfo(deviceCartInfo);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setItemTypeAndIntendType", cartInfo,request);
        Assert.assertNotNull(cartInfo.getItemType());

        deviceCartInfo.setItemType("itemType");
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setItemTypeAndIntendType", cartInfo,request);
        Assert.assertEquals(cartInfo.getItemType(),deviceCartInfo.getItemType());

        cartInfo.setItemType(null);
        deviceCartInfo.setIntendType(CartConstants.DEO);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setItemTypeAndIntendType", cartInfo,request);
        Assert.assertNotNull(cartInfo.getItemType());

        cartInfo.setItemType(null);
        deviceCartInfo.setIntendType(CartConstants.DEVID);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setItemTypeAndIntendType", cartInfo,request);
        Assert.assertNotNull(cartInfo.getItemType());

    }

    @Test
    public void setIsPromoPDP(){
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        DeviceCartInfo deviceCartInfo= new DeviceCartInfo();
        request.setCartInfo(deviceCartInfo);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setIsPromoPDP",request,customerInfo);
        Assert.assertFalse(customerInfo.getIsPromoPDP());

        deviceCartInfo.setIsPromoPDP(false);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setIsPromoPDP",request,customerInfo);
        Assert.assertFalse(customerInfo.getIsPromoPDP());

        deviceCartInfo.setIsPromoPDP(true);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setIsPromoPDP",request,customerInfo);
        Assert.assertTrue(customerInfo.getIsPromoPDP());
    }

    @Test
    public void setNoPendingOfferExists(){
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        DeviceCartInfo deviceCartInfo= new DeviceCartInfo();
        request.setCartInfo(deviceCartInfo);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setNoPendingOfferExists",request,customerInfo);
        Assert.assertFalse(customerInfo.getNoPendingOfferExists());

        deviceCartInfo.setNoPendingOfferExists(false);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setNoPendingOfferExists",request,customerInfo);
        Assert.assertFalse(customerInfo.getNoPendingOfferExists());

        deviceCartInfo.setNoPendingOfferExists(true);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setNoPendingOfferExists",request,customerInfo);
        Assert.assertTrue(customerInfo.getNoPendingOfferExists());
    }

    @Test
    public void setProcessingStep(){
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        DeviceCartInfo deviceCartInfo= new DeviceCartInfo();
        request.setCartInfo(deviceCartInfo);
        deviceCartInfo.setClientAppName(CartConstants.VZW_BBP);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setProcessingStep",request,contextInfo);
        Assert.assertNotNull(contextInfo.getProcessStep());

    }

    @Test
    public void setCustomerInfo(){
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        DeviceCartInfo deviceCartInfo = new DeviceCartInfo();
        request.setCartInfo(deviceCartInfo);
        deviceCartInfo.setTwoYearUpgrade("test");
        deviceCartInfo.setEditFromPage("editPage");
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setCustomerInfo",request,customerInfo);
        Assert.assertNotNull(customerInfo.getEditFromPage());
        Assert.assertNotNull(customerInfo.getTwoYearUpgrade());
    }

    @Test
    public void setCartInfo(){
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        AddDeviceContext context = new AddDeviceContext();
        AddDeviceData addDeviceData= new AddDeviceData();
        DeviceCartInfo cartInfo1 = new DeviceCartInfo();
        request.setCartInfo(cartInfo1);
        cartInfo1.setFlexV2(true);
        cartInfo1.setPrepaidToPostpaidMigration(true);
        addDeviceData.setPrepaidMtn("testmtn");
        request.setData(addDeviceData);
        request.setRequestApiName("add-step");
        cartInfo1.setValidateDevicePlanCompatible(true);
        cartInfo1.setClientAppName(CartConstants.VZW_BBP);
        cartInfo1.setIsConnectedCarRequired(true);
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setCartInfo",cartInfo, request, contextInfo, context);
        Assert.assertTrue(cartInfo.isPrepaidToPostpaidMigration());
    }

    @Test
    public void setNewLine(){
        Line newLine = new Line();
        Lines reqLine = new Lines();
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        String preToPostMigrationCookie ="";
        String throttleName= "";
        Flag preToPostActivationFeeFFlag = new Flag();
        CartServiceCartInfo cartInfo= new CartServiceCartInfo();
        Boolean westWorldRouterFlag = true;
        Boolean isTradeInPromoCheckFlag = true;
        Device device = new Device();
        DeviceCartInfo cartInfo1= new DeviceCartInfo();
        request.setCartInfo(cartInfo1);
        reqLine.setBuyGetInd("d");
        reqLine.setPromoIntent(Collections.singletonList(new AddPromoIntent()));
        reqLine.setContractTerm("d");
        reqLine.setDevice(device);
        device.setConnectedCarDetails(new ConnectedCarDetails());
        cartInfo1.setClientAppName(CartConstants.CHANNEL_ID_BBP);
        reqLine.setDepletionType(CartConstants.P);
        device.setNetworkBandwidthType(CartConstants.TRAVEL_PASS_GAIN);
        reqLine.setAddAccessories(new Accessory[0]);
        reqLine.setBuyDeviceLineMtn("e");
        reqLine.setHighDecileIndicator("f");
        reqLine.setPortInNumber("f");
        reqLine.setEupNoPromoFlow(true);
        reqLine.setSelectedSpoId("test");
        reqLine.setLineWithSkipMDN(true);
        reqLine.setTradeInPromoSelected(String.valueOf(true));
        reqLine.setAddFeatures(Collections.singletonList(new Feature()));
        reqLine.setRemoveFeatures(Collections.singletonList(new Feature()));
        reqLine.setE911Address(new ServiceAddress());
        cartInfo1.setIntendType(CartConstants.NSE);
        reqLine.setNumbersharePairingMode("d");
        reqLine.setBuyDevSorId("d");
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setNewLine",newLine,reqLine,request,customerInfo,preToPostMigrationCookie,
                throttleName,preToPostActivationFeeFFlag,cartInfo,westWorldRouterFlag,isTradeInPromoCheckFlag);
        Assert.assertTrue(newLine.isLineWithSkipMDN());

        cartInfo1.setIntendType(CartConstants.CLNR_FLOW);
        reqLine.setClnrInfo(new ClnrInfo());
        ReflectionTestUtils.invokeMethod(CartPegaRequestUtil4.class, "setNewLine",newLine,reqLine,request,customerInfo,preToPostMigrationCookie,
                throttleName,preToPostActivationFeeFFlag,cartInfo,westWorldRouterFlag,isTradeInPromoCheckFlag);
        Assert.assertNotNull(newLine.getClnrInfo());
    }
    @Test
    public void addDeviceWithTradeIn_formatAddUpgReq_Test() throws IOException{
        AddDeviceUIRequest request = mapper.readValue(upgradeDetailsUIRequest, AddDeviceUIRequest.class);
        request.getCartInfo().setProcessAction("");
        AddDevicePEGARequest response = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(),request,false, false);
        Assert.assertNotNull(response);

        request.getCartInfo().setProcessAction("");
        response = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(),request,false, true);
        Assert.assertNotNull(response);

        request.getCartInfo().setProcessAction("dummy");
        response = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(),request,false, true);
        Assert.assertNotNull(response);

        request.getCartInfo().setProcessAction("addDeviceWithTradeIn");
        response = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(),request,false, true);
        Assert.assertNotNull(response);

        request.getCartInfo().setSkipResumeCase(true);
        request.getCartInfo().setCaseId("");
        request.getCartInfo().setCartId("");
        response = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(),request,false, true);
        Assert.assertNotNull(response);

        request.getCartInfo().setCaseId("");
        request.getCartInfo().setCartId("cartId");
        response = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(),request,false, true);
        Assert.assertNotNull(response);

        request.getCartInfo().setCaseId("caseId");
        request.getCartInfo().setCartId("");
        response = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(),request,false, true);
        Assert.assertNotNull(response);

        request.getCartInfo().setSkipResumeCase(false);
        request.getCartInfo().setCaseId("");
        request.getCartInfo().setCartId("");
        response = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(),request,false, true);
        Assert.assertNotNull(response);
    }

    @Test
    public void formatAddUpgradeDetailEdgeupTest_AcccountMemberFlow() throws IOException {
        String upgradeDetailsUIRequest="{\"cartInfo\":{\"cartId\":\"cartid\",\"caseId\":\"caseid\",\"amRole\":\"mobileSecure\",\"ClientAppName\":\"ClientAppName\",\"accountNumber\":\"021313424200001\",\"cartCreator\":\"2513678339\",\"processingMTN\":\"2513678339\",\"processStep\":\"GridWallPDP\",\"processAction\":\"ExpressUpgrade\",\"intendType\":\"EUP\",\"isTradeInSelected\":false,\"IsComboOrderAllowed\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"noPendingOfferExists\":false,\"isPromoPDP\":false,\"mtnFlow\":\"M\",\"myvPage\":true},\"data\":{\"lines\":[{\"isCommonPDP\":true,\"mtn\":\"2513678339\",\"purchasePath\":\"EUP\",\"portInNumber\":\"\",\"eupNoPromoFlow\":false,\"editSim\":false,\"device\":{\"id\":\"SMS926UZAV\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":36,\"productId\":\"dev21411193\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"DFILLUNIV5G-SA-A\"},\"plan\":{\"isRecommendedPlan\":\"false\",\"id\":\"26907\"},\n" +
                "\"edgeup\":{\"deviceId\":\"26907\"},\"ispuFlow\":false,\"estimatedReadyByDate\":\"\",\"LineWithSkipMDN\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"newLineOrAAL\":false,\"isNewLine\":false,\"selectedPromoId\":\"promo4393822\",\"selectedPromoType\":\"TRADEIN_PROMO\",\"promoRejectionIndicator\":false,\"restrictedProductType\":\"EQP\",\"isIconicPhone\":false,\"selectedSedOfferId\":\"\",\"selectedSpoId\":\"\",\"isStrategicOffer\":false,\"restricted\":\"\",\"isTradeInIntentSelected\":true,\"tradeInInfo\":{\"deviceBrand\":\"Samsung\",\"deviceModel\":\"S23 Ultra\",\"aemOfferIds\":[\"1234\"],\"tradeinMarketingId\":\"1234\"}}],\"rtm\":{\"url\":\"https://vzwqa30.verizonwireless.com/smartphones/samsung-galaxy-s24-plus/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e2-marblegray\",\"name\":\"Galaxy S24+\",\"make\":\"Samsung\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://vzwqa30.verizonwireless.com/smartphones/samsung-galaxy-s24-plus/\"},\"enableFcc\":true}}";
        AddDeviceUIRequest request = mapper.readValue(upgradeDetailsUIRequest, AddDeviceUIRequest.class);
        request.getData().getLines().get(0).getEdgeup().setDeviceId("");
        AddDevicePEGARequest edgeup = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(), request, false,false);
        StepVerifier.create(Mono.just(edgeup)).assertNext(req -> Assert.assertNotNull(edgeup.getServiceBody().getServiceRequest().getContext().getCartInfo())).expectComplete().verify();

        request.getData().getLines().get(0).setEdgeup(null);
        AddDevicePEGARequest pegareq2 = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(), request, false,false);
        StepVerifier.create(Mono.just(pegareq2)).assertNext(req -> Assert.assertNotNull(pegareq2.getServiceBody().getServiceRequest().getContext().getCartInfo())).expectComplete().verify();

        upgradeDetailsUIRequest="{\"cartInfo\":{\"cartId\":\"cartid\",\"caseId\":\"caseid\",\"amRole\":\"mobileSecure\",\"isLineLevelPlanAccount\":null,\"ClientAppName\":\"ClientAppName\",\"accountNumber\":\"021313424200001\",\"cartCreator\":\"2513678339\",\"processingMTN\":\"2513678339\",\"processStep\":\"GridWallPDP\",\"processAction\":\"ExpressUpgrade\",\"intendType\":\"EUP\",\"isTradeInSelected\":false,\"IsComboOrderAllowed\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"noPendingOfferExists\":false,\"isPromoPDP\":false,\"mtnFlow\":\"M\",\"myvPage\":true},\"data\":{\"lines\":[{\"isCommonPDP\":true,\"mtn\":\"2513678339\",\"purchasePath\":\"EUP\",\"portInNumber\":\"\",\"eupNoPromoFlow\":false,\"editSim\":false,\"device\":{\"id\":\"SMS926UZAV\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":36,\"productId\":\"dev21411193\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"DFILLUNIV5G-SA-A\"},\"plan\":{\"isRecommendedPlan\":\"false\",\"id\":\"26907\"},\n" +
                "\"edgeup\":{\"deviceId\":\"26907\"},\"ispuFlow\":false,\"estimatedReadyByDate\":\"\",\"LineWithSkipMDN\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"newLineOrAAL\":false,\"isNewLine\":false,\"selectedPromoId\":\"promo4393822\",\"selectedPromoType\":\"TRADEIN_PROMO\",\"promoRejectionIndicator\":false,\"restrictedProductType\":\"EQP\",\"isIconicPhone\":false,\"selectedSedOfferId\":\"\",\"selectedSpoId\":\"\",\"isStrategicOffer\":false,\"restricted\":\"\",\"isTradeInIntentSelected\":true,\"tradeInInfo\":{\"deviceBrand\":\"Samsung\",\"deviceModel\":\"S23 Ultra\",\"aemOfferIds\":[\"1234\"],\"tradeinMarketingId\":\"1234\"}}],\"rtm\":{\"url\":\"https://vzwqa30.verizonwireless.com/smartphones/samsung-galaxy-s24-plus/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e2-marblegray\",\"name\":\"Galaxy S24+\",\"make\":\"Samsung\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://vzwqa30.verizonwireless.com/smartphones/samsung-galaxy-s24-plus/\"},\"enableFcc\":true}}";
        request = mapper.readValue(upgradeDetailsUIRequest, AddDeviceUIRequest.class);
        request.getData().getLines().get(0).setEdgeup(null);
        AddDevicePEGARequest pegareq3 = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(), request, false,false);
        StepVerifier.create(Mono.just(pegareq2)).assertNext(req -> Assert.assertNotNull(pegareq3.getServiceBody().getServiceRequest().getContext().getCartInfo())).expectComplete().verify();

        upgradeDetailsUIRequest="{\"cartInfo\":{\"cartId\":\"cartid\",\"caseId\":\"caseid\",\"amRole\":\"dummy\",\"isLineLevelPlanAccount\":null,\"ClientAppName\":\"ClientAppName\",\"accountNumber\":\"021313424200001\",\"cartCreator\":\"2513678339\",\"processingMTN\":\"2513678339\",\"processStep\":\"GridWallPDP\",\"processAction\":\"ExpressUpgrade\",\"intendType\":\"EUP\",\"isTradeInSelected\":false,\"IsComboOrderAllowed\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"noPendingOfferExists\":false,\"isPromoPDP\":false,\"mtnFlow\":\"M\",\"myvPage\":true},\"data\":{\"lines\":[{\"isCommonPDP\":true,\"mtn\":\"2513678339\",\"purchasePath\":\"EUP\",\"portInNumber\":\"\",\"eupNoPromoFlow\":false,\"editSim\":false,\"device\":{\"id\":\"SMS926UZAV\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":36,\"productId\":\"dev21411193\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"DFILLUNIV5G-SA-A\"},\"plan\":{\"isRecommendedPlan\":\"false\",\"id\":\"26907\"},\n" +
                "\"edgeup\":{\"deviceId\":\"26907\"},\"ispuFlow\":false,\"estimatedReadyByDate\":\"\",\"LineWithSkipMDN\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"newLineOrAAL\":false,\"isNewLine\":false,\"selectedPromoId\":\"promo4393822\",\"selectedPromoType\":\"TRADEIN_PROMO\",\"promoRejectionIndicator\":false,\"restrictedProductType\":\"EQP\",\"isIconicPhone\":false,\"selectedSedOfferId\":\"\",\"selectedSpoId\":\"\",\"isStrategicOffer\":false,\"restricted\":\"\",\"isTradeInIntentSelected\":true,\"tradeInInfo\":{\"deviceBrand\":\"Samsung\",\"deviceModel\":\"S23 Ultra\",\"aemOfferIds\":[\"1234\"],\"tradeinMarketingId\":\"1234\"}}],\"rtm\":{\"url\":\"https://vzwqa30.verizonwireless.com/smartphones/samsung-galaxy-s24-plus/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e2-marblegray\",\"name\":\"Galaxy S24+\",\"make\":\"Samsung\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://vzwqa30.verizonwireless.com/smartphones/samsung-galaxy-s24-plus/\"},\"enableFcc\":true}}";
        request = mapper.readValue(upgradeDetailsUIRequest, AddDeviceUIRequest.class);
        request.getData().getLines().get(0).setEdgeup(null);
        AddDevicePEGARequest pegareq4 = CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(new AddDevicePEGARequest(), request, false,false);
        StepVerifier.create(Mono.just(pegareq2)).assertNext(req -> Assert.assertNotNull(pegareq4.getServiceBody().getServiceRequest().getContext().getCartInfo())).expectComplete().verify();

    }

}