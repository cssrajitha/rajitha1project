package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.helper.RemoveLockHelper;
import onevz.soe.cart.helper.SaveCartHelper;
import onevz.soe.cart.helper.UpdateCartHelper;
import onevz.soe.cart.nbx.NBXFeedbackService;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.requests.RemoveLockRequest;
import onevz.soe.cart.ui.requests.SaveCartForLaterUIRequest;
import onevz.soe.cart.ui.requests.SaveCartUIRequest;
import onevz.soe.cart.ui.responses.RemoveLockUIResponse;
import onevz.soe.cart.ui.responses.SaveCartUIResponse;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.cradle.CradleAllocator;
import onevz.soe.omnidl.util.DLUtilityService;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(RemoveLockHelper.class)
//@SpringBootTest
public class RemoveLockHelperTest {


	@MockBean
	private CartServiceBpmHelper bpmHelper;

	@MockBean
	private RedisHelper redisHelper;

	@Autowired
	private ObjectMapper mapper;
	
	@Autowired
	private RemoveLockHelper removeLockHelper;
	
	@Autowired
	SourceFileReaderUtil sourceFileReaderUtil;
	
	@Value("${onevz.soe.cart.test.fileLocation}")
	private String testFileLocation;

	@Test
	public void setRemoveLockHelperTest() throws IOException, SOEHTTPException {

		String redisFile = "MockRedisData.json";
		String redisDataString = sourceFileReaderUtil.readFile(redisFile, testFileLocation);
		RemoveLockRequest sampleRequest = new RemoveLockRequest();
		RemoveLockUIResponse sampleResponse = new RemoveLockUIResponse();
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<RemoveLockUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper.removeLock(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		RemoveLockUIResponse expectedResponse = sampleResponse;
		Mono<RemoveLockUIResponse> response = removeLockHelper.updateRemoveLock(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
	}

	@Test
	public void setRemoveLockHelperTest2() throws IOException, SOEHTTPException {

		String redisFile = "MockRedisData.json";
		String redisDataString = sourceFileReaderUtil.readFile(redisFile, testFileLocation);
		RemoveLockRequest sampleRequest = new RemoveLockRequest();
		RemoveLockUIResponse sampleResponse = new RemoveLockUIResponse();
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRedisData.setAccountNumber("");
		Mono<RemoveLockUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper.removeLock(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		RemoveLockUIResponse expectedResponse = sampleResponse;
		Mono<RemoveLockUIResponse> response = removeLockHelper.updateRemoveLock(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
	}
}
