
package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.databind.ObjectMapper;
import junit.framework.Assert;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.controller.SaveCartController;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.helper.SaveCartHelper;
import onevz.soe.cart.helper.UpdateCartHelper;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.ui.requests.SaveCartForLaterUIRequest;
import onevz.soe.cart.ui.requests.SaveCartUIRequest;
import onevz.soe.cart.ui.responses.SaveCartUIResponse;
import onevz.soe.omnidl.util.DLUtilityService;
import onevz.soe.security.TokenProcessor;
import static org.junit.Assert.assertNotNull;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.http.server.reactive.MockServerHttpResponse;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.WebDataBinder;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.net.URI;
import java.util.Arrays;

import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(SaveCartController.class)
public class SaveCartControllerTest {

	@MockBean
	private UpdateCartHelper cartHelper;
	
	@MockBean
	private SaveCartHelper saveCartHelper;

	@Autowired
	private SaveCartController cartController;

	@Autowired
	private ObjectMapper mapper;

	@MockBean
	private RedisHelper redisHelper;

	@MockBean
	private DLUtilityService dlUtilityService;

	@MockBean
	private TokenProcessor tokenProcessor;

	@Test
	public void saveCartTest() throws IOException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"saveCartEmailId\":null,\"intendType\":\"AAL\"}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-514162-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"GridWallPDP\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addBuyOutAmt\"},\"customerInfo\":{\"accountNumber\":\"0100007530-00001\",\"cartCreator\":\"4125102507\"},\"cartInfo\":{\"cartId\":\"8ab56dcb-4268-4ea8-99f2-99955effe2cd\",\"saveCartEmailId\":null,\"statusCode\":\"0\",\"statusMsg\":\"Success\"}}}}}";
		SaveCartUIRequest request = mapper.readValue(requestString, SaveCartUIRequest.class);
		SaveCartUIResponse response = mapper.readValue(responseString, SaveCartUIResponse.class);
		URI url = URI.create("http://localhost/save-cart");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		when(saveCartHelper.saveCart(Mockito.any())).thenReturn(Mono.just(response));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.saveCart(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
		HttpCookie digital_ig_session = new HttpCookie("random", "digital_ig_session");
		bodyMap.add("random", digital_ig_session);
		httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", CartConstants.EXPRESS_STORE).cookies(bodyMap).build();
		request.getCartInfo().setIntendType("NSE");
		request.getCartInfo().setSaveCartEmailId("random");
		StepVerifier.create(cartController.saveCart(httpHeader, httpResponse,request)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", CartConstants.ASSISTED).cookies(bodyMap).build();
		request.getCartInfo().setIntendType("NSE");
		request.getCartInfo().setSaveCartEmailId(null);
		StepVerifier.create(cartController.saveCart(httpHeader, httpResponse,request)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		digital_ig_session = new HttpCookie("digital_ig_session", "digital_ig_session");
		bodyMap.add("digital_ig_session", digital_ig_session);
		httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", CartConstants.DIGITAL).cookies(bodyMap).build();
		request.getCartInfo().setIntendType("random");
		request.getCartInfo().setSaveCartEmailId("random");
		StepVerifier.create(cartController.saveCart(httpHeader, httpResponse,request)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		response.setErrors(Arrays.asList(new CartError(), new CartError(), new CartError()));
		when(saveCartHelper.saveCart(Mockito.any())).thenReturn(Mono.just(response));
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "random").cookies(bodyMap).build();
		request.getCartInfo().setIntendType(null);
		request.getCartInfo().setSaveCartEmailId(null);
		StepVerifier.create(cartController.saveCart(httpHeader, httpResponse,request)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void saveCartForNSETest() throws IOException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"saveCartEmailId\":\"abc@verizon.com\",\"intendType\":\"NSE\"}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-514162-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"GridWallPDP\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addBuyOutAmt\"},\"customerInfo\":{\"accountNumber\":\"0100007530-00001\",\"cartCreator\":\"4125102507\"},\"cartInfo\":{\"cartId\":\"8ab56dcb-4268-4ea8-99f2-99955effe2cd\",\"saveCartEmailId\":null,\"statusCode\":\"0\",\"statusMsg\":\"Success\"}}}}}";
		SaveCartUIRequest request = mapper.readValue(requestString, SaveCartUIRequest.class);
		SaveCartUIResponse response = mapper.readValue(responseString, SaveCartUIResponse.class);
		URI url = URI.create("http://localhost/save-cart");
		MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
		HttpCookie digital_ig_session = new HttpCookie("digital_ig_session", "digital_ig_session");
		bodyMap.add("digital_ig_session", digital_ig_session);
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-DOTCOM").cookies(bodyMap).build();
		ServerHttpResponse httpResponse = null;
		when(saveCartHelper.saveCart(Mockito.any())).thenReturn(Mono.just(response));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.saveCart(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void saveCartForAssistedTest() throws IOException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"saveCartEmailId\":\"abc@verizon.com\",\"intendType\":\"NSE\"}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-514162-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"GridWallPDP\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addBuyOutAmt\"},\"customerInfo\":{\"accountNumber\":\"0100007530-00001\",\"cartCreator\":\"4125102507\"},\"cartInfo\":{\"cartId\":\"8ab56dcb-4268-4ea8-99f2-99955effe2cd\",\"saveCartEmailId\":null,\"statusCode\":\"0\",\"statusMsg\":\"Success\"}}}}}";
		SaveCartUIRequest request = mapper.readValue(requestString, SaveCartUIRequest.class);
		SaveCartUIResponse response = mapper.readValue(responseString, SaveCartUIResponse.class);
		URI url = URI.create("http://localhost/save-cart");
		MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
		HttpCookie assisted_ig_session = new HttpCookie("assisted_ig_session", "assisted_ig_session");
		bodyMap.add("assisted_ig_session", assisted_ig_session);
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","OMNI-CARE").cookies(bodyMap).build();
		ServerHttpResponse httpResponse = null;
		when(saveCartHelper.saveCart(Mockito.any())).thenReturn(Mono.just(response));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.saveCart(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void saveCartErrorTest() throws IOException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
		SaveCartUIRequest request = mapper.readValue(requestString, SaveCartUIRequest.class);
		SaveCartUIResponse response = mapper.readValue(responseString, SaveCartUIResponse.class);
		URI url = URI.create("http://localhost/save-cart");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = null;
		when(saveCartHelper.saveCart(Mockito.any())).thenReturn(Mono.just(response));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.saveCart(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).expectError().verify();
	}

	@Test
	public void saveCartForLaterErrorTest() throws IOException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
		SaveCartForLaterUIRequest request = mapper.readValue(requestString, SaveCartForLaterUIRequest.class);
		SaveCartUIResponse response = mapper.readValue(responseString, SaveCartUIResponse.class);
		URI url = URI.create("http://localhost/save-cartforlater");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = null;
		when(saveCartHelper.saveCartForLater(Mockito.any())).thenReturn(Mono.just(response));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.saveCartForLater(httpHeader,
				httpResponse, request);
		StepVerifier.create(controllerResponse).expectError().verify();
	}

	@Test
	public void saveCartForLaterTest() throws IOException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-514162-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"GridWallPDP\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addBuyOutAmt\"},\"customerInfo\":{\"accountNumber\":\"0100007530-00001\",\"cartCreator\":\"4125102507\"},\"cartInfo\":{\"cartId\":\"8ab56dcb-4268-4ea8-99f2-99955effe2cd\",\"statusCode\":\"0\",\"statusMsg\":\"Success\"}}}}}";
		SaveCartForLaterUIRequest request = mapper.readValue(requestString, SaveCartForLaterUIRequest.class);
		SaveCartUIResponse response = mapper.readValue(responseString, SaveCartUIResponse.class);
		URI url = URI.create("http://localhost/save-cartforlater");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = null;
		when(saveCartHelper.saveCartForLater(Mockito.any())).thenReturn(Mono.just(response));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.saveCartForLater(httpHeader,
				httpResponse, request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void initBinderByNameTest() {
		WebDataBinder binder = new WebDataBinder(null);
		cartController.initBinderByName(binder);
		assertNotNull(binder.getDisallowedFields());
	}

	@Test
	public void saveCartForLaterNSETest() throws IOException {
		String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"itemType\":\"SAVE-FOR-LATER\",\"processStep\":\"ShoppingCart\",\"processAction\":\"saveForLater\",\"intendType\":\"\"},\"data\":{\"lines\":[{\"mtn\":\"newLine1\"}]}}";
		String responseString = "{\"serviceHeader\": {\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"correlationId\":\"soe-cart-2022.07.12.14.52.53-970.2567167617408\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\": {\"serviceResponse\":{\"context\":{\"cartInfo\":{\"statusMsg\":\"\",\"cartId\":\"\",\"statusCode\":\"0\"},\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"}],\"processAction\":\"ShoppingCart\",\"processStep\":\"ShoppingCart\",\"callReason\":\"SalesOrderPurchase\"},\"caseId\":\"SOP-7616727-E01\",\"customerInfo\":{\"cartCreator\":\"POW-D-1896580b-600a-4561-925e-074f9b702b6d\",\"processingMTN\":\"newLine1\",\"accountNumber\":\"\"},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"ShoppingCart\"]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"ShoppingCart\"]}]}}}}\n" +
				"\t";
		SaveCartForLaterUIRequest request = mapper.readValue(requestString, SaveCartForLaterUIRequest.class);
		SaveCartUIResponse response = mapper.readValue(responseString, SaveCartUIResponse.class);
		URI url = URI.create("http://localhost/nse/saveCartforlater");
		MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
		HttpCookie session_id = new HttpCookie("digital_ig_session", "abcd");
		bodyMap.add("digital_ig_session",session_id);
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-DOTCOM").cookies(bodyMap).build();
		ServerHttpResponse httpResponse = null;
		when(saveCartHelper.saveCartForLater(Mockito.any())).thenReturn(Mono.just(response));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.saveCartForLater(httpHeader,
				httpResponse, request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void saveCartForLaterTest2() throws IOException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-514162-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"GridWallPDP\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addBuyOutAmt\"},\"customerInfo\":{\"accountNumber\":\"0100007530-00001\",\"cartCreator\":\"4125102507\"},\"cartInfo\":{\"cartId\":\"8ab56dcb-4268-4ea8-99f2-99955effe2cd\",\"statusCode\":\"0\",\"statusMsg\":\"Success\"}}}}}";
		SaveCartForLaterUIRequest request = mapper.readValue(requestString, SaveCartForLaterUIRequest.class);
		SaveCartUIResponse response = mapper.readValue(responseString, SaveCartUIResponse.class);
		URI url = URI.create("http://localhost/save-cartforlater");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = null;
		when(saveCartHelper.saveCartForLater(Mockito.any())).thenReturn(Mono.just(response));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.saveCartForLater(httpHeader,
				httpResponse, request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}
	
	@Test
	public void saveCartForLaterTest3() throws IOException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-514162-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"GridWallPDP\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addBuyOutAmt\"},\"customerInfo\":{\"accountNumber\":\"0100007530-00001\",\"cartCreator\":\"4125102507\"},\"cartInfo\":{\"cartId\":\"8ab56dcb-4268-4ea8-99f2-99955effe2cd\",\"statusCode\":\"0\",\"statusMsg\":\"Success\"}}}}}";
		SaveCartForLaterUIRequest request = mapper.readValue(requestString, SaveCartForLaterUIRequest.class);
		SaveCartUIResponse response = mapper.readValue(responseString, SaveCartUIResponse.class);
		URI url = URI.create("http://localhost");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = null;
		when(saveCartHelper.saveCartForLater(Mockito.any())).thenReturn(Mono.just(response));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.saveCartForLater(httpHeader,
				httpResponse, request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void saveCartForAssistedTest_flexv2() throws IOException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"saveCartEmailId\":\"abc@verizon.com\",\"intendType\":\"NSE\"}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-514162-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"GridWallPDP\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addBuyOutAmt\"},\"customerInfo\":{\"accountNumber\":\"0100007530-00001\",\"cartCreator\":\"4125102507\"},\"cartInfo\":{\"cartId\":\"8ab56dcb-4268-4ea8-99f2-99955effe2cd\",\"saveCartEmailId\":null,\"statusCode\":\"0\",\"statusMsg\":\"Success\"}}}}}";
		SaveCartUIRequest request = mapper.readValue(requestString, SaveCartUIRequest.class);
		SaveCartUIResponse response = mapper.readValue(responseString, SaveCartUIResponse.class);
		URI url = URI.create("http://localhost/flexV2/save-cart");
		MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
		HttpCookie assisted_ig_session = new HttpCookie("assisted_ig_session", "assisted_ig_session");
		bodyMap.add("assisted_ig_session", assisted_ig_session);
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","OMNI-CARE").cookies(bodyMap).build();
		ServerHttpResponse httpResponse = null;
		when(saveCartHelper.saveCart(Mockito.any())).thenReturn(Mono.just(response));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.saveCart(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
		url = URI.create("http://localhost/save-cart");
		httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","OMNI-CARE").cookies(bodyMap).build();
		when(saveCartHelper.saveCart(Mockito.any())).thenReturn(Mono.just(response));
		controllerResponse = cartController.saveCart(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		url = URI.create("");
		httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","OMNI-CARE").cookies(bodyMap).build();
		when(saveCartHelper.saveCart(Mockito.any())).thenReturn(Mono.just(response));
		controllerResponse = cartController.saveCart(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

	}
}
