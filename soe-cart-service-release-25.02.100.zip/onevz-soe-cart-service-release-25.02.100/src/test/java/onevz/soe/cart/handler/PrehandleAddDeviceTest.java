package onevz.soe.cart.handler;


import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper3;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.helper.RedisHelper2;
import onevz.soe.cart.helper.UpdateCartHelper;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.requests.AddDeviceUIRequest;
import onevz.soe.cart.ui.requests.ClearCartUIRequest;
import onevz.soe.cart.ui.responses.ClearCartUIResponse;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.spring.web.filter.RequestAccessContext;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseCookie;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpResponse;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.LinkedMultiValueMap;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = {CartServiceTestConfig.class})
public class PrehandleAddDeviceTest {
    @MockBean
    private UpdateCartHelper updateCartHelper;

    @Autowired
    private ObjectMapper mapper;

    @Autowired
    SourceFileReaderUtil sourceFileReaderUtil;

    @MockBean
    private RedisHelper redisHelper;

    @MockBean
    private RedisHelper2 redisHelper2;
    @MockBean
    private CartServiceBpmHelper3 bpmHelper3;

    @Autowired
    private PreHandleAddDevice preHandleAddDevice;

    @Value("${onevz.soe.cart.test.fileLocation}")
    private String testFileLocation;


    @Before
    public void setUp() {
        final LinkedMultiValueMap<String, HttpCookie> cookies = new LinkedMultiValueMap<>();
        HttpCookie migrationCookie = new HttpCookie(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, "true");
        HttpCookie prospectCartCount = new HttpCookie(CartConstants.PROSPECT_CART_COUNT, "1");
        cookies.add(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, migrationCookie);
        cookies.add(CartConstants.PROSPECT_CART_COUNT, prospectCartCount);
        RequestAccessContext.RequestAccess requestAccess = new RequestAccessContext.RequestAccess(cookies, new HttpHeaders());
        RequestAccessContext.updateRequestData(requestAccess);
    }

    @Test
    public void clearCartTest() throws IOException, SOEHTTPException {
        String sampleadddeviceRequestString = "{\"channelId\":\"OMNI-TELESALES\", \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-DOTCOM-BBP\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\", \"restrictMultiLinePreToPost\": true }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
        AddDeviceUIRequest UIRequest = new AddDeviceUIRequest();
        UIRequest = mapper.readValue(sampleadddeviceRequestString, AddDeviceUIRequest.class);
        String redisDataString = "{ \"cartId\": \"f61a7954-4300-4e97-9478-f001475bdf9b\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ClearCartUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ClearCartUIResponse.json", testFileLocation);
        ClearCartUIRequest request = mapper.readValue(sampleRequestString, ClearCartUIRequest.class);
        ClearCartUIResponse response = mapper.readValue(sampleResponseString, ClearCartUIResponse.class);
        when(updateCartHelper.clearCart(any())).thenReturn(Mono.just(new ClearCartUIResponse()));

        StepVerifier.create(preHandleAddDevice.execute(UIRequest, sampleRedisData)).expectNext(false).verifyComplete();

    }

    @Test
    public void executeTest() throws IOException, SOEHTTPException {

        String sampleadddeviceRequestString = "{\"channelId\":\"VZW-DOTCOM\", \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-DOTCOM-BBP\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\", \"restrictMultiLinePreToPost\": true }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
        AddDeviceUIRequest UIRequest = new AddDeviceUIRequest();
        UIRequest = mapper.readValue(sampleadddeviceRequestString, AddDeviceUIRequest.class);
        String redisDataString = "{ \"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\", \"caseId\": \"SOP-741350-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"0663dce6-2103-49e4-ba25-28e55fb94d70\",\"caseId\":\"SOP-741350-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-741350-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"GridWallPDP\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addBuyOutAmt\"},\"customerInfo\":{\"accountNumber\":\"0100007530-00001\",\"cartCreator\":\"4125102507\"},\"cartInfo\":{\"cartId\":\"0663dce6-2103-49e4-ba25-28e55fb94d70\",\"statusCode\":\"0\",\"statusMsg\":\"Success\"}}}}}";
        ClearCartUIRequest request = mapper.readValue(requestString, ClearCartUIRequest.class);
        ClearCartUIResponse response = mapper.readValue(responseString, ClearCartUIResponse.class);
        when(updateCartHelper.clearCart(any(ClearCartUIRequest.class))).thenReturn(Mono.just(response));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.deleteAddDeviceDataFromRedis(any())).thenReturn(Mono.just(1L));
        when(redisHelper2.updateDeviceCartCount(any(), any())).thenReturn(Mono.just(Boolean.TRUE));
        LinkedMultiValueMap<String, HttpCookie> cookies = new LinkedMultiValueMap<>();
        HttpCookie migrationCookie = new HttpCookie(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, "true");
        HttpCookie prospectCartCount = new HttpCookie(CartConstants.PROSPECT_CART_COUNT, "2");
        cookies.add(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, migrationCookie);
        cookies.add(CartConstants.PROSPECT_CART_COUNT, prospectCartCount);
        RequestAccessContext.RequestAccess requestAccess = new RequestAccessContext.RequestAccess(cookies, new HttpHeaders());
        RequestAccessContext.updateRequestData(requestAccess);
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        httpResponse.addCookie(ResponseCookie.from("prospectCartCount", "1").build());
        UIRequest.setHttpResponse(httpResponse);

        StepVerifier.create(preHandleAddDevice.execute(UIRequest, sampleRedisData)).expectNext(true).verifyComplete();

        UIRequest.getCartInfo().setEditDevice(true);
        StepVerifier.create(preHandleAddDevice.execute(UIRequest, sampleRedisData)).expectNext(true).verifyComplete();

        UIRequest.getCartInfo().setRestrictMultiLinePreToPost(false);
        StepVerifier.create(preHandleAddDevice.execute(UIRequest, sampleRedisData)).expectNext(true).verifyComplete();

        UIRequest.setCartInfo(null);
        StepVerifier.create(preHandleAddDevice.execute(UIRequest, sampleRedisData)).expectNext(true).verifyComplete();

        UIRequest=null;
        StepVerifier.create(preHandleAddDevice.execute(UIRequest, sampleRedisData)).expectNext(true).verifyComplete();

    }
        @Test
    public void updateRadisDataTest() throws IOException, SOEHTTPException {

        String sampleadddeviceRequestString = "{\"channelId\":\"VZW-DOTCOM\", \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-DOTCOM-BBP\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\", \"restrictMultiLinePreToPost\": true }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
        AddDeviceUIRequest UIRequest = new AddDeviceUIRequest();
        UIRequest = mapper.readValue(sampleadddeviceRequestString, AddDeviceUIRequest.class);
        String redisDataString = "{ \"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\", \"caseId\": \"SOP-741350-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"0663dce6-2103-49e4-ba25-28e55fb94d70\",\"caseId\":\"SOP-741350-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-741350-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"GridWallPDP\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addBuyOutAmt\"},\"customerInfo\":{\"accountNumber\":\"0100007530-00001\",\"cartCreator\":\"4125102507\"},\"cartInfo\":{\"cartId\":\"0663dce6-2103-49e4-ba25-28e55fb94d70\",\"statusCode\":\"0\",\"statusMsg\":\"Success\"}}}}}";
        ClearCartUIRequest request = mapper.readValue(requestString, ClearCartUIRequest.class);
        ClearCartUIResponse response = mapper.readValue(responseString, ClearCartUIResponse.class);
        when(updateCartHelper.clearCart(any(ClearCartUIRequest.class))).thenReturn(Mono.just(response));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.deleteAddDeviceDataFromRedis(any())).thenReturn(Mono.just(1L));
        when(redisHelper2.updateDeviceCartCount(any(),any())).thenReturn(Mono.just(Boolean.TRUE));
        LinkedMultiValueMap<String, HttpCookie> cookies = new LinkedMultiValueMap<>();
        HttpCookie migrationCookie = new HttpCookie(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, "true");
        HttpCookie prospectCartCount = new HttpCookie(CartConstants.PROSPECT_CART_COUNT, "2");
        cookies.add(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, migrationCookie);
        cookies.add(CartConstants.PROSPECT_CART_COUNT, prospectCartCount);
        RequestAccessContext.RequestAccess requestAccess = new RequestAccessContext.RequestAccess(cookies, new HttpHeaders());
        RequestAccessContext.updateRequestData(requestAccess);
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        httpResponse.addCookie(ResponseCookie.from("prospectCartCount","1").build());
        UIRequest.setHttpResponse(httpResponse);

        StepVerifier.create(preHandleAddDevice.execute(UIRequest, sampleRedisData)).expectNext(true).verifyComplete();

        RequestAccessContext.updateRequestData(requestAccess);
        response.getServiceBody().getServiceResponse().getContext().setCartInfo(null);
        StepVerifier.create(preHandleAddDevice.execute(UIRequest, sampleRedisData)).expectNext(true).verifyComplete();

        RequestAccessContext.updateRequestData(requestAccess);
        response.getServiceBody().getServiceResponse().setContext(null);
        StepVerifier.create(preHandleAddDevice.execute(UIRequest, sampleRedisData)).expectNext(true).verifyComplete();

        RequestAccessContext.updateRequestData(requestAccess);
        response.getServiceBody().setServiceResponse(null);
        StepVerifier.create(preHandleAddDevice.execute(UIRequest, sampleRedisData)).expectNext(true).verifyComplete();

        UIRequest.setChannelId("abc");
        RequestAccessContext.updateRequestData(requestAccess);
        StepVerifier.create(preHandleAddDevice.execute(UIRequest, sampleRedisData)).expectNext(true).verifyComplete();

        RequestAccessContext.updateRequestData(requestAccess);
        response.setServiceBody(null);
        response.setCartCount("");
        StepVerifier.create(preHandleAddDevice.execute(UIRequest, sampleRedisData)).expectNext(true).verifyComplete();

        RequestAccessContext.updateRequestData(requestAccess);
        List<CartError> error=new ArrayList<>();
        response.setErrors(error);
        StepVerifier.create(preHandleAddDevice.execute(UIRequest, sampleRedisData)).expectNext(true).verifyComplete();

    }
    @Test
    public void isPrepayToPostpayMigrationFlowTest() throws IOException, SOEHTTPException {

        String sampleadddeviceRequestString = "{\"channelId\":\"VZW-DOTCOM\", \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-DOTCOM-BBP\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\", \"restrictMultiLinePreToPost\": true }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
        AddDeviceUIRequest UIRequest = new AddDeviceUIRequest();
        UIRequest = mapper.readValue(sampleadddeviceRequestString, AddDeviceUIRequest.class);
        String redisDataString = "{ \"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\", \"caseId\": \"SOP-741350-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"0663dce6-2103-49e4-ba25-28e55fb94d70\",\"caseId\":\"SOP-741350-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-741350-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"GridWallPDP\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addBuyOutAmt\"},\"customerInfo\":{\"accountNumber\":\"0100007530-00001\",\"cartCreator\":\"4125102507\"},\"cartInfo\":{\"cartId\":\"0663dce6-2103-49e4-ba25-28e55fb94d70\",\"statusCode\":\"0\",\"statusMsg\":\"Success\"}}}}}";
        ClearCartUIRequest request = mapper.readValue(requestString, ClearCartUIRequest.class);
        ClearCartUIResponse response = mapper.readValue(responseString, ClearCartUIResponse.class);
        when(updateCartHelper.clearCart(any(ClearCartUIRequest.class))).thenReturn(Mono.just(response));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.deleteAddDeviceDataFromRedis(any())).thenReturn(Mono.just(1L));
        when(redisHelper2.updateDeviceCartCount(any(), any())).thenReturn(Mono.just(Boolean.TRUE));
        LinkedMultiValueMap<String, HttpCookie> cookies = new LinkedMultiValueMap<>();
        HttpCookie migrationCookie = new HttpCookie(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, "true");
        HttpCookie prospectCartCount = new HttpCookie(CartConstants.PROSPECT_CART_COUNT, "2");
        cookies.add(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, migrationCookie);
        cookies.add(CartConstants.PROSPECT_CART_COUNT, prospectCartCount);
        RequestAccessContext.RequestAccess requestAccess = new RequestAccessContext.RequestAccess(cookies, new HttpHeaders());
        RequestAccessContext.updateRequestData(requestAccess);
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        httpResponse.addCookie(ResponseCookie.from("prospectCartCount", "1").build());
        UIRequest.setHttpResponse(httpResponse);

        StepVerifier.create(preHandleAddDevice.execute(UIRequest, sampleRedisData)).expectNext(true).verifyComplete();

        cookies.clear();
        migrationCookie = new HttpCookie(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, "true");
        prospectCartCount = new HttpCookie(CartConstants.PROSPECT_CART_COUNT, "abc");
        cookies.add(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, migrationCookie);
        cookies.add(CartConstants.PROSPECT_CART_COUNT, prospectCartCount);
        requestAccess = new RequestAccessContext.RequestAccess(cookies, new HttpHeaders());
        RequestAccessContext.updateRequestData(requestAccess);
        StepVerifier.create(preHandleAddDevice.execute(UIRequest, sampleRedisData)).expectNext(true).verifyComplete();

        sampleRedisData.setCartId(null);
        RequestAccessContext.updateRequestData(requestAccess);
        StepVerifier.create(preHandleAddDevice.execute(UIRequest, sampleRedisData)).expectNext(true).verifyComplete();

        cookies.clear();
        migrationCookie = new HttpCookie(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, "false");
        prospectCartCount = new HttpCookie(CartConstants.PROSPECT_CART_COUNT, "abc");
        cookies.add(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, migrationCookie);
        cookies.add(CartConstants.PROSPECT_CART_COUNT, prospectCartCount);
        requestAccess = new RequestAccessContext.RequestAccess(cookies, new HttpHeaders());
        RequestAccessContext.updateRequestData(requestAccess);
        StepVerifier.create(preHandleAddDevice.execute(UIRequest, sampleRedisData)).expectNext(true).verifyComplete();

        cookies.clear();
        migrationCookie = new HttpCookie(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, "true");
        prospectCartCount = new HttpCookie(CartConstants.PROSPECT_CART_COUNT, "");
        cookies.add(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, migrationCookie);
        cookies.add(CartConstants.PROSPECT_CART_COUNT, prospectCartCount);
        requestAccess = new RequestAccessContext.RequestAccess(cookies, new HttpHeaders());
        RequestAccessContext.updateRequestData(requestAccess);
        StepVerifier.create(preHandleAddDevice.execute(UIRequest, sampleRedisData)).expectNext(true).verifyComplete();

        cookies.clear();
        migrationCookie = new HttpCookie(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, "");
        prospectCartCount = new HttpCookie(CartConstants.PROSPECT_CART_COUNT, "");
        cookies.add(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, migrationCookie);
        cookies.add(CartConstants.PROSPECT_CART_COUNT, prospectCartCount);
        requestAccess = new RequestAccessContext.RequestAccess(cookies, new HttpHeaders());
        RequestAccessContext.updateRequestData(requestAccess);
        StepVerifier.create(preHandleAddDevice.execute(UIRequest, sampleRedisData)).expectNext(true).verifyComplete();

    }

    }
