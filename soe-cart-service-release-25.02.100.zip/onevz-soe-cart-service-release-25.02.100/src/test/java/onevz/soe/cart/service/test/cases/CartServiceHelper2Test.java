package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.aem.errorhandling.aem.model.CreditErrorContent;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper2;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper3;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelperAddPlan;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper2;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.helper.*;
import onevz.soe.cart.model.addDevice.AddDeviceContext;
import onevz.soe.cart.model.addDevice.AddDeviceServiceBody;
import onevz.soe.cart.model.addDevice.AddDeviceServiceResponse;
import onevz.soe.cart.model.addDevice.ShowAALPromoIntercept;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.initiateValidateDeviceSim.InitiateValidateDeviceSimUIRequest;
import onevz.soe.cart.model.initiateValidateDeviceSim.InitiateValidateDeviceSimUIResponse;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.responses.MyOfferETRRedisData;
import onevz.soe.cart.responses.UpdateTradeInOfferCXPResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.common.CartInfo;
import onevz.soe.cart.ui.common.DeviceCartInfo;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.net.URI;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { CartServiceTestConfig.class })
public class CartServiceHelper2Test {

    @Autowired
    private UpdateCartHelper helper;

    @MockBean
    private CartServiceCxpHelper cxpHelper;

    @MockBean
    private CartServiceCxpHelper2 cxpHelper2;

    @MockBean
    private CartServiceCXPServices cxpService;

    @MockBean
    private CartServiceBpmHelperAddPlan bpmHelperAddPlan;

    @MockBean
    private CartServiceBpmHelper2 bpmHelper2;

    @MockBean
    private CartServiceBpmHelper3 bpmHelper3;

    @MockBean
    private CartServiceBpmHelper bpmHelper4;

    @MockBean
    private RedisHelper redisHelper;

    @MockBean
    private RedisHelper2 redisHelper2;

    @Autowired
    private ObjectMapper mapper;

    @Autowired
    SourceFileReaderUtil sourceFileReaderUtil;

    @MockBean
    CartAddDeviceHelper deviceHelper;

    @Autowired
    UpdateCartHelper1 helper1;

    @MockBean
    FeatureFlagHelper featureFlagHelper;
    @MockBean
    OmniDLHelper omniDLHelper;
    @MockBean
    SOELoginSessionBean sessionBean;

    @Value("${onevz.soe.cart.test.fileLocation}")
    private String testFileLocation;

    @Test
    public void populateProtectionVersionHelperversionTest() throws IOException, SOEHTTPException {
        String sampleResponseString  =sourceFileReaderUtil.readFile("data/cartServiceHelperTest/GenericResponse.json", testFileLocation);
        AddFeaturesUIRequest sampleRequest = new AddFeaturesUIRequest();
        CartInfo cartInfo=new CartInfo();
        cartInfo.setProtectionVersion("version");
        cartInfo.setIntendType("NSE");
        sampleRequest.setCartInfo(cartInfo);
        GenericResponse sampleResponse = null;
        sampleResponse = mapper.readValue(sampleResponseString, GenericResponse.class);
        when(redisHelper.updateProtectionVersionInRedis("version")).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> response = helper.populateProtectionVersion(sampleRequest,sampleResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateTradeInOfferTest() throws JsonParseException, JsonMappingException, IOException {
        String sampleCXPRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateTradeInOfferUIRequest.json", testFileLocation);
        String sampleCXPresponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CalculateMultilineTaxUIResponse.json", testFileLocation);

        String sampleUIresponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CalculateMultilineTaxUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setCreditAppNum("1234567890");
        sampleRedisData.setCartCreator("nse");
        sampleRedisData.setAccountNumber("1234567890");
        sampleRedisData.setMtn("123456789");
        sampleRedisData.setProcessingMTN("12345678");

        UpdateTradeInOfferUIRequest sampleRequest = null;
        UpdateTradeInOfferUIResponse sampleResponse = null;
        UpdateTradeInOfferCXPResponse samplecxpResponse = null;


        sampleRequest = mapper.readValue(sampleCXPRequestString, UpdateTradeInOfferUIRequest.class);
        sampleResponse = mapper.readValue(sampleUIresponseString, UpdateTradeInOfferUIResponse.class);
        samplecxpResponse = mapper.readValue(sampleCXPresponseString, UpdateTradeInOfferCXPResponse.class);
        Mono<UpdateTradeInOfferCXPResponse> sampleResponseMono = Mono.just(samplecxpResponse);

        sampleRequest.setIsTradeInOfferSelected(true);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(cxpService.updateTradeInOffer(Mockito.any())).thenReturn(sampleResponseMono);

        when(cxpHelper2.updateTradeInOffer(Mockito.any())).thenReturn(Mono.just(sampleResponse));

        Mono<UpdateTradeInOfferUIResponse> respMono = helper.updateTradeInOffer(sampleRequest);

        StepVerifier.create(respMono).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

    }

    @Test
    public void addDeviceClearAndContinueTest() throws JsonParseException, JsonMappingException, IOException {

        String sampleUIresponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CalculateMultilineTaxUIResponse.json", testFileLocation);
        CartRedisData sampleRedisData =new CartRedisData();
        ServerHttpResponse httpResponse = Mockito.mock(ServerHttpResponse.class);
        sampleRedisData.setIntendType("NSE");
        Lines lines1=new Lines();
        lines1.setCurrentDeviceID("123");
        List<Lines> lines=new ArrayList<>();
        lines.add(lines1);
        sampleRedisData.setLines(lines);
        sampleRedisData.setDepletionType("depl");
        sampleRedisData.setChannelId("VZW-ACSS");
        sampleRedisData.setCreditAppNum("1234567890");
        sampleRedisData.setCartCreator("nse");
        sampleRedisData.setAccountNumber("1234567890");
        sampleRedisData.setMtn("123456789");
        sampleRedisData.setProcessingMTN("12345678");
        sampleRedisData.setExistingCase("123456789");
        DeviceCartInfo deviceCartInfo=new DeviceCartInfo();
        deviceCartInfo.setCartId("1234567890");
        deviceCartInfo.setCaseId("12345");
        deviceCartInfo.setIntendType("NSE");
        sampleRedisData.setDeviceCartInfo(deviceCartInfo);
        UpdateTradeInOfferUIRequest sampleRequest = null;
        AddDeviceUIResponse sampleResponse = new AddDeviceUIResponse();
        AddDeviceServiceBody serviceBody=new AddDeviceServiceBody();
        AddDeviceServiceResponse serviceResponse=new AddDeviceServiceResponse();
        AddDeviceContext context=new AddDeviceContext();
        CartServiceCartInfo cartInfo=new CartServiceCartInfo();
        cartInfo.setCartId("1234");
        context.setCartInfo(cartInfo);
        context.setCaseId("12345");
        Line line1=new Line();
        line1.setMtn("123456");
        Line line2=new Line();
        line2.setMtn("123456");
        Line[] linesc= {line1,line2};
        context.setLines(linesc);
        CartServiceContextInfo contextInfo=new CartServiceContextInfo();
        contextInfo.setProcessStep("step");
        context.setContextInfo(contextInfo);
        CartServiceCustomerInfo customerInfo=new CartServiceCustomerInfo();
        customerInfo.setExistingCase("existingCase");
        context.setCustomerInfo(customerInfo);
        ShowAALPromoIntercept showAALPromoIntercept=new ShowAALPromoIntercept();
        showAALPromoIntercept.setMyOfferEligibile(true);
        context.setShowAALPromoIntercept(showAALPromoIntercept);
        serviceResponse.setContext(context);
        serviceBody.setServiceResponse(serviceResponse);
        sampleResponse.setServiceBody(serviceBody);
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));

        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleResponse));
        StepVerifier.create(helper.addDeviceClearAndContinue(sampleRedisData,"SOP-329-E01","20ae6bcb-1150-4d16-99dd-14b7d9f128c7", "VZW-ACSS",httpResponse,null)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }
    @Test
    public void addDeviceClearAndContinueconditionTest() throws JsonParseException, JsonMappingException, IOException {
        String sampleUIresponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CalculateMultilineTaxUIResponse.json", testFileLocation);
        CartRedisData sampleRedisData =new CartRedisData();
        ServerHttpResponse httpResponse = Mockito.mock(ServerHttpResponse.class);
        Lines lines1=new Lines();
        lines1.setCurrentDeviceID("123");
        List<Lines> lines=new ArrayList<>();
        lines.add(lines1);
        sampleRedisData.setLines(lines);
        sampleRedisData.setDepletionType("depl");
        sampleRedisData.setChannelId("VZW-ACSS");
        sampleRedisData.setCreditAppNum("1234567890");
        sampleRedisData.setCartCreator("nse");
        sampleRedisData.setAccountNumber("1234567890");
        sampleRedisData.setMtn("123456789");
        sampleRedisData.setProcessingMTN("12345678");
        sampleRedisData.setExistingCase("123456789");
        DeviceCartInfo deviceCartInfo=new DeviceCartInfo();
        deviceCartInfo.setCartId("1234567890");
        deviceCartInfo.setCaseId("12345");
        deviceCartInfo.setIntendType("NSE");
        sampleRedisData.setDeviceCartInfo(deviceCartInfo);
        UpdateTradeInOfferUIRequest sampleRequest = null;
        AddDeviceUIResponse sampleResponse = new AddDeviceUIResponse();
        AddDeviceServiceBody serviceBody=new AddDeviceServiceBody();
        AddDeviceServiceResponse serviceResponse=new AddDeviceServiceResponse();
        AddDeviceContext context=new AddDeviceContext();
        CartServiceCartInfo cartInfo=new CartServiceCartInfo();
        serviceResponse.setContext(context);
        serviceBody.setServiceResponse(serviceResponse);
        sampleResponse.setServiceBody(serviceBody);
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleResponse));
        StepVerifier.create(helper.addDeviceClearAndContinue(sampleRedisData,"SOP-329-E01","20ae6bcb-1150-4d16-99dd-14b7d9f128c7", "VZW-ACSS",httpResponse,null)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addTransferUpgradeHelperTest1() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateTransferUpgradeUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        UpdateTransferUpgradeUIRequest sampleUIRequest = null;
        UpdateTransferUpgradeUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData19.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateTransferUpgradeUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, UpdateTransferUpgradeUIResponse.class);
        when(bpmHelper3.addTransferUpgrade(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateTransferUpgradeUIResponse expectedResponse = sampleResponse;
        Mono<UpdateTransferUpgradeUIResponse> response = helper.addTransferUpgrade(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void removeTransferUpgradeHelperTest1() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateTransferUpgradeUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        UpdateTransferUpgradeUIRequest sampleUIRequest = null;
        UpdateTransferUpgradeUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData19.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateTransferUpgradeUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, UpdateTransferUpgradeUIResponse.class);
        when(bpmHelper3.removeTransferUpgrade(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateTransferUpgradeUIResponse expectedResponse = sampleResponse;
        Mono<UpdateTransferUpgradeUIResponse> response = helper.removeTransferUpgrade(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void addNickNameTest1() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddNickNameUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        AddNickNameUIRequest sampleUIRequest = null;
        AddNickNameUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData19.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setCreditAppNum("1234567890");
        sampleUIRequest = mapper.readValue(sampleUIRequestString, AddNickNameUIRequest.class);
        sampleUIRequest.setChannelId(null);
        sampleResponse = mapper.readValue(sampleResponseString, AddNickNameUIResponse.class);
        when(bpmHelper3.addNickName(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<AddNickNameUIResponse> response = helper.addNickName(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
    }

    @Test
    public void emailCartToCustomerTest1() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/EmailCartToCustomerUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/EmailCartToCustomerUIResponse.json", testFileLocation);
        EmailCartToCustomerUIRequest sampleUIRequest = null;
        EmailCartToCustomerUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData19.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, EmailCartToCustomerUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, EmailCartToCustomerUIResponse.class);
        when(bpmHelper3.emailCartToCustomer(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        EmailCartToCustomerUIResponse expectedResponse = sampleResponse;
        Mono<EmailCartToCustomerUIResponse> response = helper.emailCartToCustomer(sampleUIRequest);

        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateVZCCAppStatusTest1() throws IOException {
        String requestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/VZCCAppStatusUIRequest.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/VZCCAppStatusUIResponse.json", testFileLocation);
        VZCCAppStatusUIRequest sampleUIRequest = null;
        VZCCAppStatusUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData20.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setIntendType(null);
        sampleUIRequest = mapper.readValue(requestString, VZCCAppStatusUIRequest.class);
        sampleResponse = mapper.readValue(responseString, VZCCAppStatusUIResponse.class);
        when(cxpHelper2.updateVZCCAppStatus(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        VZCCAppStatusUIResponse expectedResponse = sampleResponse;
        Mono<VZCCAppStatusUIResponse> response = helper.updateVZCCAppStatus(sampleUIRequest);

        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateChatIdTest1() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateChatIdUIRequest2.json", testFileLocation);
        String sampleUIRequestnotnseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateChatIdUIRequest1.json", testFileLocation);

        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateChatIdUIResponse.json", testFileLocation);
        UpdateChatIdUIRequest sampleUIRequest = null;
        UpdateChatIdUIRequest sampleUIRequest1 = null;

        UpdateChatIdUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData19.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setCreditAppNum("");
        sampleRedisData.setAccountNumber("");
        sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateChatIdUIRequest.class);
        sampleUIRequest1 = mapper.readValue(sampleUIRequestnotnseString, UpdateChatIdUIRequest.class);

        sampleResponse = mapper.readValue(sampleResponseString, UpdateChatIdUIResponse.class);
        when(bpmHelper3.updateChatId(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<UpdateChatIdUIResponse> response = helper.updateChatId(sampleUIRequest);
        Mono<UpdateChatIdUIResponse> response1 = helper.updateChatId(sampleUIRequest1);
        StepVerifier.create(response1).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
    }

    @Test
    public void clearCartHelperTest1() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddNickNameUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData19.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setCreditAppNum("");
        ClearCartUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, ClearCartUIRequest.class);
        sampleUIRequest.setChannelId("");
        ClearCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, ClearCartUIResponse.class);
        when(bpmHelper3.clearCart(Mockito.any(),Mockito.any())).thenReturn((Mono<ClearCartUIResponse>) Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        ClearCartUIResponse expectedResponse = sampleResponse;
        Mono<ClearCartUIResponse> response = helper.clearCart(sampleUIRequest);
        final Duration verify = StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
        final Duration verify1 = StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void initiateValidateDeviceSimTest() throws IOException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/IntiateDeviceSimActivationUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateDeviceSimActivationUIResponse.json", testFileLocation);
        InitiateValidateDeviceSimUIRequest request = mapper.readValue(sampleRequestString, InitiateValidateDeviceSimUIRequest.class);
        InitiateValidateDeviceSimUIResponse response = mapper.readValue(sampleResponseString, InitiateValidateDeviceSimUIResponse.class);
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        CartRedisData redisData = new CartRedisData();
        URI url = URI.create("http://localhost/add-accessories");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").cookies(bodyMap).build();
        when(bpmHelper4.initiateValidateDeviceSim(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        Mono<InitiateValidateDeviceSimUIResponse> activationResponse = helper.initiateValidateDeviceSim(request,httpRequest,redisData);
        StepVerifier.create(activationResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void clearXboxFromCartOnDppSummaryTest() throws IOException {
        String requestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ClearCartUIRequest2.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ClearCartUIResponse1.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData19.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setCreditAppNum("");
        ClearCartUIRequest request = mapper.readValue(requestString, ClearCartUIRequest.class);
        ClearCartUIResponse response = mapper.readValue(responseString, ClearCartUIResponse.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(bpmHelper3.clearCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.deleteProcessingMtnFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        when(redisHelper2.updateDeviceCartCount(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        Mono<ClearCartUIResponse> uiResponse = helper.clearCart(request);
        StepVerifier.create(uiResponse).assertNext(res -> {
            Assert.assertEquals("SUCCESS", res.getServiceHeader().getStatusMsg());
        }).expectComplete().verify();
    }

    @Test
    public void updateUserInfoHelperTest2() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateUserInfoUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateUserInfoUIResponse1.json", testFileLocation);
        UpdateUserInfoUIRequest sampleRequest = mapper.readValue(sampleRequestString, UpdateUserInfoUIRequest.class);
        UpdateUserInfoUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateUserInfoUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData2.json", testFileLocation);;
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<UpdateUserInfoUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(cxpHelper.updateUserInfo(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateUserInfoUIResponse expectedResponse = sampleResponse;
        Mono<UpdateUserInfoUIResponse> response = helper.updateUserInfo(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void paperlessBillingHelperTest2() throws IOException, SOEHTTPException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/PaperlessBillingUIResponse.json", testFileLocation);
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/PaperlessBillingUIRequest.json", testFileLocation);
        PaperlessBillingUIRequest sampleRequest = mapper.readValue(sampleRequestString, PaperlessBillingUIRequest.class);
        PaperlessBillingUIResponse sampleResponse = mapper.readValue(sampleResponseString, PaperlessBillingUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData2.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<PaperlessBillingUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(cxpHelper.paperlessBilling(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        PaperlessBillingUIResponse expectedResponse = sampleResponse;
        Mono<PaperlessBillingUIResponse> response = helper.paperlessBilling(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateBarcodeHelperTest2() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIRequest2.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData21.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setCreditAppNum("1234567890");
        UpdateBarcodeUIRequest sampleRequest = mapper.readValue(sampleRequestString, UpdateBarcodeUIRequest.class);
        UpdateBarcodeUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateBarcodeUIResponse.class);
        Mono<UpdateBarcodeUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse1.json", testFileLocation);
        ValidateCartUIResponse sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(bpmHelper3.updateBarcode(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.upsertValueInRedis(Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        Mono<UpdateBarcodeUIResponse> response = helper.updateBarcode(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateBarcodeHelperTest3() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIRequest5.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData22.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        UpdateBarcodeUIRequest sampleRequest = mapper.readValue(sampleRequestString, UpdateBarcodeUIRequest.class);
        UpdateBarcodeUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateBarcodeUIResponse.class);
        Mono<UpdateBarcodeUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse1.json", testFileLocation);
        ValidateCartUIResponse sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(bpmHelper3.updateBarcode(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.upsertValueInRedis(Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        Mono<UpdateBarcodeUIResponse> response = helper.updateBarcode(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateBarcodeHelperTest4() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIRequest6.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIResponse2.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData22.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        UpdateBarcodeUIRequest sampleRequest = mapper.readValue(sampleRequestString, UpdateBarcodeUIRequest.class);
        UpdateBarcodeUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateBarcodeUIResponse.class);
        Mono<UpdateBarcodeUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse1.json", testFileLocation);
        ValidateCartUIResponse sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(bpmHelper3.updateBarcode(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.upsertValueInRedis(Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        Mono<UpdateBarcodeUIResponse> response = helper.updateBarcode(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateBarcodeHelperTest5() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIRequest7.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIResponse3.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData22.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        UpdateBarcodeUIRequest sampleRequest = mapper.readValue(sampleRequestString, UpdateBarcodeUIRequest.class);
        UpdateBarcodeUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateBarcodeUIResponse.class);
        Mono<UpdateBarcodeUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse1.json", testFileLocation);
        ValidateCartUIResponse sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(bpmHelper3.updateBarcode(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.upsertValueInRedis(Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        Mono<UpdateBarcodeUIResponse> response = helper.updateBarcode(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateBarcodeHelperTest6() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIRequest8.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIResponse3.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData22.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        UpdateBarcodeUIRequest sampleRequest = mapper.readValue(sampleRequestString, UpdateBarcodeUIRequest.class);
        UpdateBarcodeUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateBarcodeUIResponse.class);
        Mono<UpdateBarcodeUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse1.json", testFileLocation);
        ValidateCartUIResponse sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(bpmHelper3.updateBarcode(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.upsertValueInRedis(Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        Mono<UpdateBarcodeUIResponse> response = helper.updateBarcode(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateBarcodeHelperTest7() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIRequest8.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIResponse4.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData22.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        UpdateBarcodeUIRequest sampleRequest = mapper.readValue(sampleRequestString, UpdateBarcodeUIRequest.class);
        UpdateBarcodeUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateBarcodeUIResponse.class);
        Mono<UpdateBarcodeUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse1.json", testFileLocation);
        ValidateCartUIResponse sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(bpmHelper3.updateBarcode(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.upsertValueInRedis(Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        Mono<UpdateBarcodeUIResponse> response = helper.updateBarcode(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateBarcodeHelperTest8() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIRequest8.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIResponse5.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData22.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        UpdateBarcodeUIRequest sampleRequest = mapper.readValue(sampleRequestString, UpdateBarcodeUIRequest.class);
        UpdateBarcodeUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateBarcodeUIResponse.class);
        Mono<UpdateBarcodeUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse1.json", testFileLocation);
        ValidateCartUIResponse sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(sessionBean.isFWADigitalFlow()).thenReturn(false);
        when(bpmHelper3.updateBarcode(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.upsertValueInRedis(Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        Mono<UpdateBarcodeUIResponse> response = helper.updateBarcode(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateBarcodeHelperSkipValidateTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIRequest8.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIResponse6.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData22.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        UpdateBarcodeUIRequest sampleRequest = mapper.readValue(sampleRequestString, UpdateBarcodeUIRequest.class);
        when(sessionBean.isFWADigitalFlow()).thenReturn(true);
        sampleRequest.setChannelId("VZW-DOTCOM");
        sampleRequest.getCartInfo().setProcessStep("ExpressCheckOut");
        when(featureFlagHelper.isSkipCartValidationOnUpdateCouponForFWA()).thenReturn(true);
        UpdateBarcodeUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateBarcodeUIResponse.class);
        Mono<UpdateBarcodeUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper3.updateBarcode(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.upsertValueInRedis(Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<UpdateBarcodeUIResponse> response = helper.updateBarcode(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        when(featureFlagHelper.isSkipCartValidationOnUpdateCouponForFWA()).thenReturn(false);
        response = helper.updateBarcode(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        when(sessionBean.isFWADigitalFlow()).thenReturn(false);
        when(featureFlagHelper.isSkipCartValidationOnUpdateCouponForFWA()).thenReturn(true);
        response = helper.updateBarcode(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateBarcodeHelperTest9() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIRequest9.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData22.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        UpdateBarcodeUIRequest sampleRequest = mapper.readValue(sampleRequestString, UpdateBarcodeUIRequest.class);
        UpdateBarcodeUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateBarcodeUIResponse.class);
        Mono<UpdateBarcodeUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse7.json", testFileLocation);
        ValidateCartUIResponse sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(bpmHelper3.updateBarcode(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.upsertValueInRedis(Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        Mono<UpdateBarcodeUIResponse> response = helper.updateBarcode(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateBarcodeHelperTest10() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIRequest9.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData23.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        UpdateBarcodeUIRequest sampleRequest = mapper.readValue(sampleRequestString, UpdateBarcodeUIRequest.class);
        UpdateBarcodeUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateBarcodeUIResponse.class);
        Mono<UpdateBarcodeUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse8.json", testFileLocation);
        ValidateCartUIResponse sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(bpmHelper3.updateBarcode(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.upsertValueInRedis(Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        Mono<UpdateBarcodeUIResponse> response = helper.updateBarcode(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateBarcodeHelperTest11() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIRequest9.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData24.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        UpdateBarcodeUIRequest sampleRequest = mapper.readValue(sampleRequestString, UpdateBarcodeUIRequest.class);
        UpdateBarcodeUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateBarcodeUIResponse.class);
        Mono<UpdateBarcodeUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse9.json", testFileLocation);
        ValidateCartUIResponse sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(bpmHelper3.updateBarcode(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.upsertValueInRedis(Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        Mono<UpdateBarcodeUIResponse> response = helper.updateBarcode(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateBarcodeHelperTest12() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIRequest9.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData25.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        UpdateBarcodeUIRequest sampleRequest = mapper.readValue(sampleRequestString, UpdateBarcodeUIRequest.class);
        UpdateBarcodeUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateBarcodeUIResponse.class);
        Mono<UpdateBarcodeUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper3.updateBarcode(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.upsertValueInRedis(Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(new ValidateCartUIResponse()));
        Mono<UpdateBarcodeUIResponse> response = helper.updateBarcode(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateBarcodeHelperTest13() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIRequest10.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData24.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        UpdateBarcodeUIRequest sampleRequest = mapper.readValue(sampleRequestString, UpdateBarcodeUIRequest.class);
        UpdateBarcodeUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateBarcodeUIResponse.class);
        Mono<UpdateBarcodeUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper3.updateBarcode(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.upsertValueInRedis(Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(new ValidateCartUIResponse()));
        Mono<UpdateBarcodeUIResponse> response = helper.updateBarcode(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateTradeinTypeHelperTest2() throws IOException, SOEHTTPException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateTradeinTypeUIResponse.json", testFileLocation);
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateTradeinTypeUIRequest.json", testFileLocation);
        UpdateTradeinTypeUIRequest sampleRequest = mapper.readValue(sampleRequestString, UpdateTradeinTypeUIRequest.class);
        UpdateTradeinTypeUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateTradeinTypeUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData2.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<UpdateTradeinTypeUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(cxpHelper2.updateTradeinType(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<UpdateTradeinTypeUIResponse> response = helper.updateTradeinType(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
    }

    @Test
    public void updateSellerPriceNewHelperTest2() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIRequestNew2.json", testFileLocation);
        String sampleResponseString =sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIResponseNew.json", testFileLocation);
        UpdateSellerPriceUIRequestNew sampleRequest = mapper.readValue(sampleRequestString, UpdateSellerPriceUIRequestNew.class);
        UpdateSellerPriceUIResponseNew sampleResponse = mapper.readValue(sampleResponseString, UpdateSellerPriceUIResponseNew.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData26.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<UpdateSellerPriceUIResponseNew> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper3.updateSellerPrice(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateSellerPriceUIResponseNew expectedResponse = sampleResponse;
        Mono<UpdateSellerPriceUIResponseNew> response = helper.updateSellerPriceNew(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateSellerPriceNewHelperTest3() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIRequestNew3.json", testFileLocation);
        String sampleResponseString =sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIResponseNew.json", testFileLocation);
        UpdateSellerPriceUIRequestNew sampleRequest = mapper.readValue(sampleRequestString, UpdateSellerPriceUIRequestNew.class);
        UpdateSellerPriceUIResponseNew sampleResponse = mapper.readValue(sampleResponseString, UpdateSellerPriceUIResponseNew.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData26.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<UpdateSellerPriceUIResponseNew> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper3.updateSellerPrice(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateSellerPriceUIResponseNew expectedResponse = sampleResponse;
        Mono<UpdateSellerPriceUIResponseNew> response = helper.updateSellerPriceNew(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateSellerPriceNewHelperTest4() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIRequestNew4.json", testFileLocation);
        String sampleResponseString =sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIResponseNew.json", testFileLocation);
        UpdateSellerPriceUIRequestNew sampleRequest = mapper.readValue(sampleRequestString, UpdateSellerPriceUIRequestNew.class);
        UpdateSellerPriceUIResponseNew sampleResponse = mapper.readValue(sampleResponseString, UpdateSellerPriceUIResponseNew.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData26.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<UpdateSellerPriceUIResponseNew> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper3.updateSellerPrice(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateSellerPriceUIResponseNew expectedResponse = sampleResponse;
        Mono<UpdateSellerPriceUIResponseNew> response = helper.updateSellerPriceNew(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateSellerPriceNewHelperTest5() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIRequestNew5.json", testFileLocation);
        String sampleResponseString =sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIResponseNew.json", testFileLocation);
        UpdateSellerPriceUIRequestNew sampleRequest = mapper.readValue(sampleRequestString, UpdateSellerPriceUIRequestNew.class);
        UpdateSellerPriceUIResponseNew sampleResponse = mapper.readValue(sampleResponseString, UpdateSellerPriceUIResponseNew.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData26.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<UpdateSellerPriceUIResponseNew> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper3.updateSellerPrice(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateSellerPriceUIResponseNew expectedResponse = sampleResponse;
        Mono<UpdateSellerPriceUIResponseNew> response = helper.updateSellerPriceNew(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateSellerPriceNewHelperTest6() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIRequestNew3.json", testFileLocation);
        String sampleResponseString =sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIResponseNew.json", testFileLocation);
        UpdateSellerPriceUIRequestNew sampleRequest = mapper.readValue(sampleRequestString, UpdateSellerPriceUIRequestNew.class);
        UpdateSellerPriceUIResponseNew sampleResponse = mapper.readValue(sampleResponseString, UpdateSellerPriceUIResponseNew.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData27.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<UpdateSellerPriceUIResponseNew> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper3.updateSellerPrice(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateSellerPriceUIResponseNew expectedResponse = sampleResponse;
        Mono<UpdateSellerPriceUIResponseNew> response = helper.updateSellerPriceNew(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateSellerPriceNewHelperTest7() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIRequestNew6.json", testFileLocation);
        String sampleResponseString =sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIResponseNew.json", testFileLocation);
        UpdateSellerPriceUIRequestNew sampleRequest = mapper.readValue(sampleRequestString, UpdateSellerPriceUIRequestNew.class);
        UpdateSellerPriceUIResponseNew sampleResponse = mapper.readValue(sampleResponseString, UpdateSellerPriceUIResponseNew.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData26.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<UpdateSellerPriceUIResponseNew> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper3.updateSellerPrice(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateSellerPriceUIResponseNew expectedResponse = sampleResponse;
        Mono<UpdateSellerPriceUIResponseNew> response = helper.updateSellerPriceNew(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addPlanTest() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIRequest4.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIResponse.json", testFileLocation);
        AddPlanUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
        AddPlanUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddPlanUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData28.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(omniDLHelper.upsertPlanTaggingValueToRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(bpmHelperAddPlan.addPlan(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just("true"));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("true"));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(new MyOfferETRRedisData()));
        AddPlanUIResponse expectedResponse = sampleResponse;
        Mono<AddPlanUIResponse> response = helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }
    @Test
    public void addPlanFlexV2Test() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIRequest4.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIResponse.json", testFileLocation);
        AddPlanUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
        AddPlanUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddPlanUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData28.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        UIRequest.getCartInfo().setFlexV2(true);
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(omniDLHelper.upsertPlanTaggingValueToRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(bpmHelperAddPlan.addPlan(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just("true"));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("true"));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(new MyOfferETRRedisData()));
        AddPlanUIResponse expectedResponse = sampleResponse;
        Mono<AddPlanUIResponse> response = helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addPlanTest2() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIRequest5.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIResponse.json", testFileLocation);
        AddPlanUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
        AddPlanUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddPlanUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData28.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(omniDLHelper.upsertPlanTaggingValueToRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(bpmHelperAddPlan.addPlan(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just(""));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just(""));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(new MyOfferETRRedisData()));
        AddPlanUIResponse expectedResponse = sampleResponse;
        Mono<AddPlanUIResponse> response = helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void validateOrderTest() throws IOException {
        ReflectionTestUtils.setField(helper, "enableMHOffers", true);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse1.json", testFileLocation);
        String sampleCrediErrorString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CreditErrorContent.json", testFileLocation);
        InitiateCheckoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
        CreditErrorContent samleCreditErrorResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData29.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        samleCreditErrorResponse = mapper.readValue(sampleCrediErrorString, CreditErrorContent.class);
        when(bpmHelper2.validateOrder(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.readCreditException()).thenReturn(Mono.just(samleCreditErrorResponse));
        when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(true));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        when(redisHelper2.upsertCreditCheckFailureCountIntoRedis(Mockito.anyInt(), Mockito.any())).thenReturn(Mono.just(true));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        Mono<InitiateCheckoutUIResponse> response = helper.validateOrder(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void validateOrderTest1() throws IOException {
        ReflectionTestUtils.setField(helper, "enableMHOffers", false);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse1.json", testFileLocation);
        String sampleResponseString1 = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse6.json", testFileLocation);


        String sampleCrediErrorString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CreditErrorContent.json", testFileLocation);
        InitiateCheckoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
        CreditErrorContent samleCreditErrorResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData29.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        samleCreditErrorResponse = mapper.readValue(sampleCrediErrorString, CreditErrorContent.class);
        when(bpmHelper2.validateOrder(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.readCreditException()).thenReturn(Mono.just(samleCreditErrorResponse));
        when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(true));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        when(redisHelper2.upsertCreditCheckFailureCountIntoRedis(Mockito.anyInt(), Mockito.any())).thenReturn(Mono.just(true));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        Mono<InitiateCheckoutUIResponse> response = helper.validateOrder(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();

        InitiateCheckoutUIResponse sampleResponse1 = mapper.readValue(sampleResponseString1, InitiateCheckoutUIResponse.class);
        when(bpmHelper2.validateOrder(sampleUIRequest)).thenReturn(Mono.just(sampleResponse1));
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();

    }

    @Test
    public void validateOrderTest2() throws IOException {
        ReflectionTestUtils.setField(helper, "enableMHOffers", true);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse1.json", testFileLocation);
        String sampleCrediErrorString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CreditErrorContent.json", testFileLocation);
        InitiateCheckoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
        CreditErrorContent samleCreditErrorResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData30.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        samleCreditErrorResponse = mapper.readValue(sampleCrediErrorString, CreditErrorContent.class);
        when(bpmHelper2.validateOrder(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.readCreditException()).thenReturn(Mono.just(samleCreditErrorResponse));
        when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(true));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        when(redisHelper2.upsertCreditCheckFailureCountIntoRedis(Mockito.anyInt(), Mockito.any())).thenReturn(Mono.just(true));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        Mono<InitiateCheckoutUIResponse> response = helper.validateOrder(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void validateOrderTest3() throws IOException {
        ReflectionTestUtils.setField(helper, "enableMHOffers", true);
        ReflectionTestUtils.setField(helper, "enableSecurityForCart", true);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest4.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse1.json", testFileLocation);
        String sampleCrediErrorString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CreditErrorContent2.json", testFileLocation);
        InitiateCheckoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
        CreditErrorContent samleCreditErrorResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData31.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        samleCreditErrorResponse = mapper.readValue(sampleCrediErrorString, CreditErrorContent.class);
        when(bpmHelper2.validateOrder(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.readCreditException()).thenReturn(Mono.just(samleCreditErrorResponse));
        when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(true));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        when(redisHelper2.upsertCreditCheckFailureCountIntoRedis(Mockito.anyInt(), Mockito.any())).thenReturn(Mono.just(true));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        Mono<InitiateCheckoutUIResponse> response = helper.validateOrder(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void validateOrderTest4() throws IOException {
        ReflectionTestUtils.setField(helper, "enableMHOffers", true);
        ReflectionTestUtils.setField(helper, "enableSecurityForCart", false);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest4.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse1.json", testFileLocation);
        String sampleCrediErrorString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CreditErrorContent2.json", testFileLocation);
        InitiateCheckoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
        CreditErrorContent samleCreditErrorResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData31.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        samleCreditErrorResponse = mapper.readValue(sampleCrediErrorString, CreditErrorContent.class);
        when(bpmHelper2.validateOrder(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.readCreditException()).thenReturn(Mono.just(samleCreditErrorResponse));
        when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(true));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        when(redisHelper2.upsertCreditCheckFailureCountIntoRedis(Mockito.anyInt(), Mockito.any())).thenReturn(Mono.just(true));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        Mono<InitiateCheckoutUIResponse> response = helper.validateOrder(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void validateOrderTest5() throws IOException {
        ReflectionTestUtils.setField(helper, "enableMHOffers", true);
        ReflectionTestUtils.setField(helper, "enableSecurityForCart", false);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest4.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse1.json", testFileLocation);
        String sampleCrediErrorString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CreditErrorContent2.json", testFileLocation);
        InitiateCheckoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
        CreditErrorContent samleCreditErrorResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData31.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        samleCreditErrorResponse = mapper.readValue(sampleCrediErrorString, CreditErrorContent.class);
        when(bpmHelper2.validateOrder(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.readCreditException()).thenReturn(Mono.just(samleCreditErrorResponse));
        when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(true));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        when(redisHelper2.upsertCreditCheckFailureCountIntoRedis(Mockito.anyInt(), Mockito.any())).thenReturn(Mono.just(true));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        Mono<InitiateCheckoutUIResponse> response = helper.validateOrder(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void validateOrderTest6() throws IOException {
        ReflectionTestUtils.setField(helper, "enableMHOffers", true);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse7.json", testFileLocation);
        String sampleCrediErrorString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CreditErrorContent.json", testFileLocation);
        InitiateCheckoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
        CreditErrorContent samleCreditErrorResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData29.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        samleCreditErrorResponse = mapper.readValue(sampleCrediErrorString, CreditErrorContent.class);
        when(bpmHelper2.validateOrder(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.readCreditException()).thenReturn(Mono.just(samleCreditErrorResponse));
        when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(true));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        when(redisHelper2.upsertCreditCheckFailureCountIntoRedis(Mockito.anyInt(), Mockito.any())).thenReturn(Mono.just(true));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        Mono<InitiateCheckoutUIResponse> response = helper.validateOrder(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void validateOrderTest7() throws IOException {
        ReflectionTestUtils.setField(helper, "enableMHOffers", true);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse8.json", testFileLocation);
        String sampleCrediErrorString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CreditErrorContent.json", testFileLocation);
        InitiateCheckoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
        CreditErrorContent samleCreditErrorResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData29.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        samleCreditErrorResponse = mapper.readValue(sampleCrediErrorString, CreditErrorContent.class);
        when(bpmHelper2.validateOrder(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.readCreditException()).thenReturn(Mono.just(samleCreditErrorResponse));
        when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(true));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        when(redisHelper2.upsertCreditCheckFailureCountIntoRedis(Mockito.anyInt(), Mockito.any())).thenReturn(Mono.just(true));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        Mono<InitiateCheckoutUIResponse> response = helper.validateOrder(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void validateOrderTest8() throws IOException {
        ReflectionTestUtils.setField(helper, "enableMHOffers", true);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse9.json", testFileLocation);
        String sampleCrediErrorString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CreditErrorContent.json", testFileLocation);
        InitiateCheckoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
        CreditErrorContent samleCreditErrorResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData29.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        samleCreditErrorResponse = mapper.readValue(sampleCrediErrorString, CreditErrorContent.class);
        when(bpmHelper2.validateOrder(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.readCreditException()).thenReturn(Mono.just(samleCreditErrorResponse));
        when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(true));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        when(redisHelper2.upsertCreditCheckFailureCountIntoRedis(Mockito.anyInt(), Mockito.any())).thenReturn(Mono.just(true));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        Mono<InitiateCheckoutUIResponse> response = helper.validateOrder(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void validateOrderTest9() throws IOException {
        ReflectionTestUtils.setField(helper, "enableMHOffers", true);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse10.json", testFileLocation);
        String sampleCrediErrorString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CreditErrorContent.json", testFileLocation);
        InitiateCheckoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
        CreditErrorContent samleCreditErrorResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData29.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        samleCreditErrorResponse = mapper.readValue(sampleCrediErrorString, CreditErrorContent.class);
        when(bpmHelper2.validateOrder(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.readCreditException()).thenReturn(Mono.just(samleCreditErrorResponse));
        when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(true));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        when(redisHelper2.upsertCreditCheckFailureCountIntoRedis(Mockito.anyInt(), Mockito.any())).thenReturn(Mono.just(true));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        Mono<InitiateCheckoutUIResponse> response = helper.validateOrder(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void validateOrderTest10() throws IOException {
        ReflectionTestUtils.setField(helper, "enableMHOffers", true);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse11.json", testFileLocation);
        String sampleCrediErrorString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CreditErrorContent3.json", testFileLocation);
        InitiateCheckoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
        CreditErrorContent samleCreditErrorResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData29.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        samleCreditErrorResponse = mapper.readValue(sampleCrediErrorString, CreditErrorContent.class);
        when(bpmHelper2.validateOrder(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.readCreditException()).thenReturn(Mono.just(samleCreditErrorResponse));
        when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(true));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        when(redisHelper2.upsertCreditCheckFailureCountIntoRedis(Mockito.anyInt(), Mockito.any())).thenReturn(Mono.just(true));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        Mono<InitiateCheckoutUIResponse> response = helper.validateOrder(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void validateOrderTest12() throws IOException {
        ReflectionTestUtils.setField(helper, "enableSecurityForCart", true);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest4.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse12.json", testFileLocation);
        String sampleCrediErrorString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CreditErrorContent3.json", testFileLocation);
        InitiateCheckoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
        CreditErrorContent samleCreditErrorResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData29.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        samleCreditErrorResponse = mapper.readValue(sampleCrediErrorString, CreditErrorContent.class);
        when(bpmHelper2.validateOrder(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.readCreditException()).thenReturn(Mono.just(samleCreditErrorResponse));
        when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(true));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        when(redisHelper2.upsertCreditCheckFailureCountIntoRedis(Mockito.anyInt(), Mockito.any())).thenReturn(Mono.just(true));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        Mono<InitiateCheckoutUIResponse> response = helper.validateOrder(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void validateOrderTest13() throws IOException {
        ReflectionTestUtils.setField(helper, "enableSecurityForCart", false);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest4.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse12.json", testFileLocation);
        String sampleCrediErrorString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CreditErrorContent3.json", testFileLocation);
        InitiateCheckoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
        CreditErrorContent samleCreditErrorResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData29.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        samleCreditErrorResponse = mapper.readValue(sampleCrediErrorString, CreditErrorContent.class);
        when(bpmHelper2.validateOrder(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.readCreditException()).thenReturn(Mono.just(samleCreditErrorResponse));
        when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(true));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        when(redisHelper2.upsertCreditCheckFailureCountIntoRedis(Mockito.anyInt(), Mockito.any())).thenReturn(Mono.just(true));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        Mono<InitiateCheckoutUIResponse> response = helper.validateOrder(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void validateOrderTest14() throws IOException {
        ReflectionTestUtils.setField(helper, "enableSecurityForCart", false);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest4.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse13.json", testFileLocation);
        String sampleCrediErrorString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CreditErrorContent3.json", testFileLocation);
        InitiateCheckoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
        CreditErrorContent samleCreditErrorResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData29.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        samleCreditErrorResponse = mapper.readValue(sampleCrediErrorString, CreditErrorContent.class);
        when(bpmHelper2.validateOrder(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.readCreditException()).thenReturn(Mono.just(samleCreditErrorResponse));
        when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(true));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        when(redisHelper2.upsertCreditCheckFailureCountIntoRedis(Mockito.anyInt(), Mockito.any())).thenReturn(Mono.just(true));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        Mono<InitiateCheckoutUIResponse> response = helper.validateOrder(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void validateOrderTest15() throws IOException {
        ReflectionTestUtils.setField(helper, "enableSecurityForCart", false);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest4.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse14.json", testFileLocation);
        String sampleCrediErrorString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CreditErrorContent3.json", testFileLocation);
        InitiateCheckoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
        CreditErrorContent samleCreditErrorResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData29.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        samleCreditErrorResponse = mapper.readValue(sampleCrediErrorString, CreditErrorContent.class);
        when(bpmHelper2.validateOrder(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.readCreditException()).thenReturn(Mono.just(samleCreditErrorResponse));
        when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(true));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        when(redisHelper2.upsertCreditCheckFailureCountIntoRedis(Mockito.anyInt(), Mockito.any())).thenReturn(Mono.just(true));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        Mono<InitiateCheckoutUIResponse> response = helper.validateOrder(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void validateOrderTest16() throws IOException {
        ReflectionTestUtils.setField(helper, "enableSecurityForCart", false);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest4.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse15.json", testFileLocation);
        String sampleCrediErrorString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CreditErrorContent3.json", testFileLocation);
        InitiateCheckoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
        CreditErrorContent samleCreditErrorResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData29.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        samleCreditErrorResponse = mapper.readValue(sampleCrediErrorString, CreditErrorContent.class);
        when(bpmHelper2.validateOrder(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.readCreditException()).thenReturn(Mono.just(samleCreditErrorResponse));
        when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(true));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        when(redisHelper2.upsertCreditCheckFailureCountIntoRedis(Mockito.anyInt(), Mockito.any())).thenReturn(Mono.just(true));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        Mono<InitiateCheckoutUIResponse> response = helper.validateOrder(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void validateOrderTest17() throws IOException {
        ReflectionTestUtils.setField(helper, "enableSecurityForCart", false);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest4.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse16.json", testFileLocation);
        String sampleCrediErrorString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CreditErrorContent3.json", testFileLocation);
        InitiateCheckoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
        CreditErrorContent samleCreditErrorResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData29.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        samleCreditErrorResponse = mapper.readValue(sampleCrediErrorString, CreditErrorContent.class);
        when(bpmHelper2.validateOrder(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.readCreditException()).thenReturn(Mono.just(samleCreditErrorResponse));
        when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(true));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        when(redisHelper2.upsertCreditCheckFailureCountIntoRedis(Mockito.anyInt(), Mockito.any())).thenReturn(Mono.just(true));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        Mono<InitiateCheckoutUIResponse> response = helper.validateOrder(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void validateOrderTest18() throws IOException {
        ReflectionTestUtils.setField(helper, "enableSecurityForCart", false);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest4.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse17.json", testFileLocation);
        String sampleCrediErrorString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CreditErrorContent3.json", testFileLocation);
        InitiateCheckoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
        CreditErrorContent samleCreditErrorResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData29.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        samleCreditErrorResponse = mapper.readValue(sampleCrediErrorString, CreditErrorContent.class);
        when(bpmHelper2.validateOrder(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.readCreditException()).thenReturn(Mono.just(samleCreditErrorResponse));
        when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(true));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        when(redisHelper2.upsertCreditCheckFailureCountIntoRedis(Mockito.anyInt(), Mockito.any())).thenReturn(Mono.just(true));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        Mono<InitiateCheckoutUIResponse> response = helper.validateOrder(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void validateOrderTest19() throws IOException {
        ReflectionTestUtils.setField(helper, "enableSecurityForCart", false);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest4.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse18.json", testFileLocation);
        String sampleCrediErrorString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CreditErrorContent3.json", testFileLocation);
        InitiateCheckoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
        CreditErrorContent samleCreditErrorResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData29.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        samleCreditErrorResponse = mapper.readValue(sampleCrediErrorString, CreditErrorContent.class);
        when(bpmHelper2.validateOrder(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.readCreditException()).thenReturn(Mono.just(samleCreditErrorResponse));
        when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(true));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        when(redisHelper2.upsertCreditCheckFailureCountIntoRedis(Mockito.anyInt(), Mockito.any())).thenReturn(Mono.just(true));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        Mono<InitiateCheckoutUIResponse> response = helper.validateOrder(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void validateOrderTest20() throws IOException {
        ReflectionTestUtils.setField(helper, "enableSecurityForCart", false);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest4.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse19.json", testFileLocation);
        String sampleCrediErrorString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CreditErrorContent3.json", testFileLocation);
        InitiateCheckoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
        CreditErrorContent samleCreditErrorResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData29.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        samleCreditErrorResponse = mapper.readValue(sampleCrediErrorString, CreditErrorContent.class);
        when(bpmHelper2.validateOrder(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.readCreditException()).thenReturn(Mono.just(samleCreditErrorResponse));
        when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(true));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        when(redisHelper2.upsertCreditCheckFailureCountIntoRedis(Mockito.anyInt(), Mockito.any())).thenReturn(Mono.just(true));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        Mono<InitiateCheckoutUIResponse> response = helper.validateOrder(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateCartHelperCreditHoldTest1() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse1.json", testFileLocation);
        String sampleCrediErrorString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CreditErrorContent.json", testFileLocation);
        InitiateCheckoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
        CreditErrorContent samleCreditErrorResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData32.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        samleCreditErrorResponse = mapper.readValue(sampleCrediErrorString, CreditErrorContent.class);
        when(bpmHelper2.validateOrder(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.readCreditException()).thenReturn(Mono.just(samleCreditErrorResponse));
        when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(true));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        when(redisHelper2.upsertCreditCheckFailureCountIntoRedis(Mockito.anyInt(), Mockito.any())).thenReturn(Mono.just(true));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        Mono<InitiateCheckoutUIResponse> response = helper.validateOrder(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addPlanFlexV2Test1() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIRequest4.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIResponse.json", testFileLocation);
        AddPlanUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
        AddPlanUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddPlanUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData28.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setFlowName("");
        UIRequest.getCartInfo().setFlexV2(true);
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(omniDLHelper.upsertPlanTaggingValueToRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(bpmHelperAddPlan.addPlan(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just("true"));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("true"));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(new MyOfferETRRedisData()));
        AddPlanUIResponse expectedResponse = sampleResponse;
        Mono<AddPlanUIResponse> response = helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();

        sampleRedisData.setFlowName("EUP");
        when(bpmHelperAddPlan.addPlan(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        response = helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();

    }

    @Test
    public void ngdDeleteCartHelperTest() throws IOException, ExecutionException, InterruptedException {
        String sampleUIRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"ngdFlow\": true,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
        String sampleResponseString = "{\"serviceBody\":{\"serviceResponse\":{\"context\":{\"cartInfo\":{\"cartItemCount\":0,\"couponCode\":\"\",\"discountPromoTotal\":0,\"fmiCheck\":false,\"instantCreditAmount\":0,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false,\"protectionNotRequired\":false,\"registerNumber\":0,\"statusCode\":\"1\",\"statusMsg\":\"cart cleared successfully!\"},\"contextInfo\":{\"availablePaths\":[],\"callReason\":\"SalesOrderPurchase\",\"processAction\":\"\",\"processStep\":\"PromoHub\"},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POW-D-a4374a66-327a-49db-8889-0583f3e260e8\",\"customerType\":\"N\",\"globalId\":\"POW-D-a4374a66-327a-49db-8889-0583f3e260e8\",\"myvPage\":false,\"noc\":false,\"nocByod\":false,\"processingMTN\":\"newLine1\",\"registerNumber\":0}}}},\"serviceHeader\":{\"correlationId\":\"soe-cart-2024.07.03.03.06.45-644.8149291665973\",\"serviceName\":\"SalesOrderPurchase\",\"sessionId\":\"\",\"statusCode\":\"00\",\"statusMsg\":\"SUCCESS\",\"userId\":\"\"}}";
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData42.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        DeleteCartUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, DeleteCartUIRequest.class);
        DeleteCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeleteCartUIResponse.class);
        when(bpmHelper3.ngdDeleteCart(Mockito.any(), Mockito.any())).thenReturn((Mono<DeleteCartUIResponse>) Mono.just(sampleResponse));
        Mono<CartRedisData> rr = Mono.just(sampleRedisData);
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(rr);
        DeleteCartUIResponse expectedResponse = sampleResponse;
        Mono<DeleteCartUIResponse> response = helper1.ngdDeleteCart(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }
    @Test
    public void test_ClearAndContinue_AddDevice_WhenPastDue() throws JsonParseException, JsonMappingException, IOException {

        //CartRedisData sampleRedisData =new CartRedisData();
        ServerHttpResponse httpResponse = Mockito.mock(ServerHttpResponse.class);
        //   sampleRedisData.setIntendType("NSE");
        Lines lines1=new Lines();
        lines1.setCurrentDeviceID("123");
        List<Lines> lines=new ArrayList<>();
        lines.add(lines1);
        /*sampleRedisData.setLines(lines);
        sampleRedisData.setDepletionType("depl");
        sampleRedisData.setChannelId("VZW-DOTCOM");
        sampleRedisData.setCreditAppNum("1234567890");
        sampleRedisData.setCartCreator("nse");
        sampleRedisData.setAccountNumber("1234567890");
        sampleRedisData.setMtn("123456789");
        sampleRedisData.setProcessingMTN("12345678");
        sampleRedisData.setExistingCase("123456789");*/
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        DeviceCartInfo deviceCartInfo=new DeviceCartInfo();
        deviceCartInfo.setCartId("1234567890");
        deviceCartInfo.setCaseId("12345");
        deviceCartInfo.setIntendType("AAL");
        sampleRedisData.setDeviceCartInfo(deviceCartInfo);
        UpdateTradeInOfferUIRequest sampleRequest = null;
        AddDeviceUIResponse sampleResponse = new AddDeviceUIResponse();
        AddDeviceServiceBody serviceBody=new AddDeviceServiceBody();
        AddDeviceServiceResponse serviceResponse=new AddDeviceServiceResponse();
        AddDeviceContext context=new AddDeviceContext();
        CartServiceCartInfo cartInfo=new CartServiceCartInfo();
        cartInfo.setCartId("1234");
        context.setCartInfo(cartInfo);
        context.setCaseId("12345");
        Line line1=new Line();
        line1.setMtn("123456");
        Line line2=new Line();
        line2.setMtn("123456");
        Line[] linesc= {line1,line2};
        context.setLines(linesc);
        CartServiceContextInfo contextInfo=new CartServiceContextInfo();
        contextInfo.setProcessStep("step");
        context.setContextInfo(contextInfo);
        CartServiceCustomerInfo customerInfo=new CartServiceCustomerInfo();
        customerInfo.setExistingCase("existingCase");
        context.setCustomerInfo(customerInfo);
        ShowAALPromoIntercept showAALPromoIntercept=new ShowAALPromoIntercept();
        showAALPromoIntercept.setMyOfferEligibile(true);
        context.setShowAALPromoIntercept(showAALPromoIntercept);
        serviceResponse.setContext(context);
        serviceBody.setServiceResponse(serviceResponse);
        sampleResponse.setServiceBody(serviceBody);
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleResponse));

        CartInfo cartInfoPastDue = new CartInfo();

        //past due is null
        cartInfoPastDue.setPastdue(null);
        StepVerifier.create(helper.addDeviceClearAndContinue(sampleRedisData,"SOP-329-E01","20ae6bcb-1150-4d16-99dd-14b7d9f128c7", "VZW-ACSS",httpResponse,null)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        //past due is present
        cartInfoPastDue.setPastdue(new PastDue("100.00"));
        StepVerifier.create(helper.addDeviceClearAndContinue(sampleRedisData,"SOP-329-E01","20ae6bcb-1150-4d16-99dd-14b7d9f128c7", "VZW-ACSS",httpResponse,cartInfoPastDue)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }
}
