package onevz.soe.cart.service.test.util;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.util.OrderFlowTypeUtil;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(OrderFlowTypeUtil.class)
public class OrderFlowTypeUtilTest {


	@Test
	public void calculateCartOrderFlowTypeTest() {
		String orderFlowType = CartConstants.EXPRESS;
		String processStep = CartConstants.PROMO_HUB;
		String reqIntendType = CartConstants.NSE_BYOD;

		String cartOrderFlowType = OrderFlowTypeUtil.calculateCartOrderFlowType(
				orderFlowType,
				processStep,
				reqIntendType);
		Assert.assertNotNull(cartOrderFlowType);
	}

	@Test
	public void calculateCartOrderFlowTypeTest1() {
		String orderFlowType = CartConstants.EXPRESS;
		String processStep = CartConstants.PROMO_HUB;
		String reqIntendType = CartConstants.ESO;

		String cartOrderFlowType = OrderFlowTypeUtil.calculateCartOrderFlowType(
				orderFlowType,
				processStep,
				reqIntendType);
		Assert.assertNotNull(cartOrderFlowType);
	}

	@Test
	public void calculateCartOrderFlowTypeTest2() {
		String orderFlowType = " ";
		String processStep = " ";
		String reqIntendType = " ";

		String cartOrderFlowType = OrderFlowTypeUtil.calculateCartOrderFlowType(
				orderFlowType,
				processStep,
				reqIntendType);
		Assert.assertNotNull(cartOrderFlowType);
	}

	@Test
	public void calculateCartOrderFlowTypeTest3() {
		String orderFlowType = CartConstants.EXPRESS;
		String processStep = "TEST3";
		String reqIntendType = "TEST3";

		String cartOrderFlowType = OrderFlowTypeUtil.calculateCartOrderFlowType(
				orderFlowType,
				processStep,
				reqIntendType);
		Assert.assertNotNull(cartOrderFlowType);
	}

	@Test
	public void calculateCartOrderFlowTypeTest4() {
		String orderFlowType = "TEST4";
		String processStep = CartConstants.PROMO_HUB;
		String reqIntendType = CartConstants.NSE_BYOD;

		String cartOrderFlowType = OrderFlowTypeUtil.calculateCartOrderFlowType(
				orderFlowType,
				processStep,
				reqIntendType);
		Assert.assertNotNull(cartOrderFlowType);
	}

	@Test
	public void getFlowTypeValue() {
		String cartOrderFlowType = "TEST";
		String flowType = OrderFlowTypeUtil.getFlowTypeValue(cartOrderFlowType);
		Assert.assertNotNull(flowType);
		Assert.assertNotNull(OrderFlowTypeUtil.getFlowTypeValue(""));
	}

	@Test
	public void calculateCartOrderFlowTypeNullCheck() {
		OrderFlowTypeUtil OrderFlowTypeUtilObj = new OrderFlowTypeUtil();
		OrderFlowTypeUtilObj.calculateCartOrderFlowType(CartConstants.EXPRESS,CartConstants.ACCESSORIES_INTERSTIAL,CartConstants.NSE);
		OrderFlowTypeUtilObj.calculateCartOrderFlowType(CartConstants.EXPRESS,"random",CartConstants.NSE_BYOD);
		OrderFlowTypeUtilObj.calculateCartOrderFlowType("random",CartConstants.PROMO_HUB,"random");
		OrderFlowTypeUtilObj.calculateCartOrderFlowType("random","random",CartConstants.NSE_BYOD);

		OrderFlowTypeUtilObj.calculateCartOrderFlowType(CartConstants.EXPRESS+"nse",CartConstants.ACCESSORIES_INTERSTIAL,CartConstants.NSE);
		OrderFlowTypeUtilObj.calculateCartOrderFlowType(CartConstants.EXPRESS+"nso","random",CartConstants.NSE_BYOD);
		OrderFlowTypeUtilObj.calculateCartOrderFlowType("express random",CartConstants.PROMO_HUB,"random");
		OrderFlowTypeUtilObj.calculateCartOrderFlowType("random nso","random",CartConstants.NSE_BYOD);

		Assert.assertNotNull( OrderFlowTypeUtilObj.calculateCartOrderFlowType("random","random","random"));
		Assert.assertNotNull( OrderFlowTypeUtilObj.calculateCartOrderFlowType("none","random","random"));

	}
}
