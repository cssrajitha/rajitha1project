package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper2;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelperAddPlan;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper2;
import onevz.soe.cart.helper.*;
import onevz.soe.cart.model.addressQualificationSession.AddressValidationRespToSessionData;
import onevz.soe.cart.model.common.Page;
import onevz.soe.cart.model.common.Vzdl;
import onevz.soe.cart.model.initiateValidateDeviceSim.InitiateValidateDeviceSimUIResponse;
import onevz.soe.cart.model.retrieveCart.CXPRetrieveCartDataVO;
import onevz.soe.cart.nbx.NBXFeedbackService;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.customerprofile.response.CustomerProfileResponse;
import onevz.soe.omnidl.service.OmniDLService;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(UpdateCartHelper.class)
public class CartServiceHelper6Test {

    @Autowired
    private UpdateCartHelper helper;

    @MockBean
    private CartServiceCxpHelper cxpHelper;

    @MockBean
    private CartServiceCxpHelper2 cxpHelper2;

    @MockBean
    private CartServiceBpmHelperAddPlan bpmHelperAddPlan;

    @MockBean
    private CartServiceBpmHelper2 bpmHelper2;

    @MockBean
    private CartServiceBpmHelper bpmHelper4;

    @MockBean
    private RedisHelper redisHelper;

    @MockBean
    private RedisHelper2 redisHelper2;

    @Autowired
    private ObjectMapper mapper;

    @MockBean
    private NBXFeedbackService nbxService;

    @Autowired
    SourceFileReaderUtil sourceFileReaderUtil;

    @Value("${onevz.soe.cart.test.fileLocation}")
    private String testFileLocation;

    @Autowired
    private OmniDLHelper dlHelper;

    @MockBean
    private OmniDLHelper omniDLHelper;
    @MockBean
    OmniDLService dlService;
    @MockBean
    FeatureFlagHelper featureFlagHelper;

    @Test
    public void populateProtectionVersionHelperTest1() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddFeaturesUIRequest6.json", testFileLocation);
        String sampleResponseString  =sourceFileReaderUtil.readFile("data/cartServiceHelperTest/GenericResponse.json", testFileLocation);
        AddFeaturesUIRequest sampleRequest = mapper.readValue(sampleRequestString, AddFeaturesUIRequest.class);
        GenericResponse sampleResponse = mapper.readValue(sampleResponseString, GenericResponse.class);
        when(redisHelper.updateProtectionVersionInRedis(" ")).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> response = helper.populateProtectionVersion(sampleRequest,sampleResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void populateProtectionVersionHelperTest2() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddFeaturesUIRequest2.json", testFileLocation);
        String sampleResponseString  =sourceFileReaderUtil.readFile("data/cartServiceHelperTest/GenericResponse.json", testFileLocation);
        AddFeaturesUIRequest sampleRequest = mapper.readValue(sampleRequestString, AddFeaturesUIRequest.class);
        GenericResponse sampleResponse = mapper.readValue(sampleResponseString, GenericResponse.class);
        when(redisHelper.updateProtectionVersionInRedis(" ")).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> response = helper.populateProtectionVersion(sampleRequest,sampleResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addManualDiscountHelperTest1() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateManualDiscountUIRequest2.json", testFileLocation);
        String sampleResponseString =sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateManualDiscountUIResponse.json", testFileLocation);
        UpdateManualDiscountUIRequest sampleRequest = mapper.readValue(sampleRequestString, UpdateManualDiscountUIRequest.class);
        UpdateManualDiscountUIResponse sampleUIResponse = mapper.readValue(sampleResponseString, UpdateManualDiscountUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData122.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setCreditAppNum("");
        sampleRequest.setChannelId("OMNI-RETAIL");
        Mono<UpdateManualDiscountUIResponse> sampleResponseMono = Mono.just(sampleUIResponse);
        when(bpmHelper4.addManualdiscount(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateManualDiscountUIResponse expectedResponse = sampleUIResponse;
        Mono<UpdateManualDiscountUIResponse> response = helper.addManualDiscount(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addManualDiscountHelperTest2() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateManualDiscountUIRequest3.json", testFileLocation);
        String sampleResponseString =sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateManualDiscountUIResponse.json", testFileLocation);
        UpdateManualDiscountUIRequest sampleRequest = mapper.readValue(sampleRequestString, UpdateManualDiscountUIRequest.class);
        UpdateManualDiscountUIResponse sampleUIResponse = mapper.readValue(sampleResponseString, UpdateManualDiscountUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData123.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setCreditAppNum("");
        sampleRequest.setChannelId("OMNI-RETAIL");
        Mono<UpdateManualDiscountUIResponse> sampleResponseMono = Mono.just(sampleUIResponse);
        when(bpmHelper4.addManualdiscount(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateManualDiscountUIResponse expectedResponse = sampleUIResponse;
        Mono<UpdateManualDiscountUIResponse> response = helper.addManualDiscount(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addManualDiscountHelperTest3() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateManualDiscountUIRequest4.json", testFileLocation);
        String sampleResponseString =sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateManualDiscountUIResponse.json", testFileLocation);
        UpdateManualDiscountUIRequest sampleRequest = mapper.readValue(sampleRequestString, UpdateManualDiscountUIRequest.class);
        UpdateManualDiscountUIResponse sampleUIResponse = mapper.readValue(sampleResponseString, UpdateManualDiscountUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData123.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setCreditAppNum("");
        Mono<UpdateManualDiscountUIResponse> sampleResponseMono = Mono.just(sampleUIResponse);
        when(bpmHelper4.addManualdiscount(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateManualDiscountUIResponse expectedResponse = sampleUIResponse;
        Mono<UpdateManualDiscountUIResponse> response = helper.addManualDiscount(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addManualDiscountHelperTest4() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateManualDiscountUIRequest5.json", testFileLocation);
        String sampleResponseString =sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateManualDiscountUIResponse.json", testFileLocation);
        UpdateManualDiscountUIRequest sampleRequest = mapper.readValue(sampleRequestString, UpdateManualDiscountUIRequest.class);
        UpdateManualDiscountUIResponse sampleUIResponse = mapper.readValue(sampleResponseString, UpdateManualDiscountUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData124.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setCreditAppNum("");
        Mono<UpdateManualDiscountUIResponse> sampleResponseMono = Mono.just(sampleUIResponse);
        when(bpmHelper4.addManualdiscount(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateManualDiscountUIResponse expectedResponse = sampleUIResponse;
        Mono<UpdateManualDiscountUIResponse> response = helper.addManualDiscount(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateZipcodeToCartTest() throws IOException, SOEHTTPException {
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData124.json", testFileLocation);
        AddZipcodeRedisData sampleRedisData = mapper.readValue(redisDataString, AddZipcodeRedisData.class);
        Mono<AddZipcodeRedisData> sampleResponseMono = Mono.just(sampleRedisData);
        try {
            Mono<AddZipcodeRedisData> response = helper.updateZipcodeToCart("VZW-DOTCOM","60920");
        } catch (NullPointerException e)
        {
            e.printStackTrace();
        }
    }

    @Test
    public void updateZipcodeToCartTest1() throws IOException, SOEHTTPException {
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData124.json", testFileLocation);
        AddZipcodeRedisData sampleRedisData = mapper.readValue(redisDataString, AddZipcodeRedisData.class);
        Mono<AddZipcodeRedisData> sampleResponseMono = Mono.just(sampleRedisData);
        try {
            Mono<AddZipcodeRedisData> response = helper.updateZipcodeToCart(null,null);
        } catch (NullPointerException e)
        {
            e.printStackTrace();
        }
    }

    @Test
    public void getPairedDevicesHelperTest1() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/MyOffersCXPRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddZipcodeRedisData.json", testFileLocation);
        GetPairedDevicesUIRequest sampleRequest = mapper.readValue(sampleRequestString, GetPairedDevicesUIRequest.class);
        GetPairedDevicesUIResponse sampleResponse =  mapper.readValue(sampleResponseString, GetPairedDevicesUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData125.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<GetPairedDevicesUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(cxpHelper2.getPairedDevices(sampleRequest)).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        GetPairedDevicesUIResponse expectedResponse = sampleResponse;
        Mono<GetPairedDevicesUIResponse> response = helper.getPairedDevices(sampleRequest,"assisted");
        StepVerifier.create(response).expectError().verify();
    }

    @Test
    public void updateEffectiveDateHelperTest1() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEffectiveDateUIRequest3.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEffectiveDateUIResponse.json", testFileLocation);
        UpdateEffectiveDateUIRequest sampleRequest = null;
        UpdateEffectiveDateUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setCartCreator("nse");
        sampleRedisData.setAccountNumber("1234567890");
        sampleRedisData.setMtn("123456789");
        sampleRedisData.setProcessingMTN("12345678");
        sampleRequest = mapper.readValue(sampleRequestString, UpdateEffectiveDateUIRequest.class);
        sampleRequest.setChannelId("OMNI-RETAIL");
        sampleResponse = mapper.readValue(sampleResponseString, UpdateEffectiveDateUIResponse.class);
        Mono<UpdateEffectiveDateUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper4.updateEffectiveDate(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateEffectiveDateUIResponse expectedResponse = sampleResponse;
        Mono<UpdateEffectiveDateUIResponse> response = helper.updateEffectiveDate(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateEffectiveDateHelperTest2() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEffectiveDateUIRequest2.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEffectiveDateUIResponse.json", testFileLocation);
        UpdateEffectiveDateUIRequest sampleRequest = null;
        UpdateEffectiveDateUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData126.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRequest = mapper.readValue(sampleRequestString, UpdateEffectiveDateUIRequest.class);
        sampleRequest.setChannelId("OMNI-RETAIL");
        sampleResponse = mapper.readValue(sampleResponseString, UpdateEffectiveDateUIResponse.class);
        Mono<UpdateEffectiveDateUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper4.updateEffectiveDate(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateEffectiveDateUIResponse expectedResponse = sampleResponse;
        Mono<UpdateEffectiveDateUIResponse> response = helper.updateEffectiveDate(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateEffectiveDateHelperTest3() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEffectiveDateUIRequest2.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEffectiveDateUIResponse.json", testFileLocation);
        UpdateEffectiveDateUIRequest sampleRequest = null;
        UpdateEffectiveDateUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData127.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRequest = mapper.readValue(sampleRequestString, UpdateEffectiveDateUIRequest.class);
        sampleRequest.setChannelId("VZW-DOTCOM");
        sampleResponse = mapper.readValue(sampleResponseString, UpdateEffectiveDateUIResponse.class);
        Mono<UpdateEffectiveDateUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper4.updateEffectiveDate(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateEffectiveDateUIResponse expectedResponse = sampleResponse;
        Mono<UpdateEffectiveDateUIResponse> response = helper.updateEffectiveDate(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateEffectiveDateHelperTest4() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEffectiveDateUIRequest2.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEffectiveDateUIResponse.json", testFileLocation);
        UpdateEffectiveDateUIRequest sampleRequest = null;
        UpdateEffectiveDateUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData127.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRequest = mapper.readValue(sampleRequestString, UpdateEffectiveDateUIRequest.class);
        sampleRequest.setChannelId("");
        sampleResponse = mapper.readValue(sampleResponseString, UpdateEffectiveDateUIResponse.class);
        Mono<UpdateEffectiveDateUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper4.updateEffectiveDate(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateEffectiveDateUIResponse expectedResponse = sampleResponse;
        Mono<UpdateEffectiveDateUIResponse> response = helper.updateEffectiveDate(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateVzccNBXInfoHelperTest1() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/MyOffersCXPRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddZipcodeRedisData.json", testFileLocation);
        UpdateVzccNBXInfoUIRequest sampleRequest = null;
        UpdateVzccNBXInfoUIResponse sampleResponse = null;
        sampleRequest = mapper.readValue(sampleRequestString, UpdateVzccNBXInfoUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, UpdateVzccNBXInfoUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData121.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setIntendType("AAL");
        Mono<UpdateVzccNBXInfoUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(cxpHelper2.updateVzccNBXInfo(sampleRequest)).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateVzccNBXInfoUIResponse expectedResponse = sampleResponse;
        Mono<UpdateVzccNBXInfoUIResponse> response = helper.updateVzccNBXInfo(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateVzccNBXInfoHelperTest2() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/MyOffersCXPRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddZipcodeRedisData.json", testFileLocation);
        UpdateVzccNBXInfoUIRequest sampleRequest = null;
        UpdateVzccNBXInfoUIResponse sampleResponse = null;
        sampleRequest = mapper.readValue(sampleRequestString, UpdateVzccNBXInfoUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, UpdateVzccNBXInfoUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData121.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setIntendType("");
        Mono<UpdateVzccNBXInfoUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(cxpHelper2.updateVzccNBXInfo(sampleRequest)).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateVzccNBXInfoUIResponse expectedResponse = sampleResponse;
        Mono<UpdateVzccNBXInfoUIResponse> response = helper.updateVzccNBXInfo(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void customerNameByMtnTest1() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateDeviceSimActivationUIResponse.json", testFileLocation);
        InitiateValidateDeviceSimUIResponse response = mapper.readValue(sampleResponseString, InitiateValidateDeviceSimUIResponse.class);
        when(cxpHelper2.customerNameByMtn(Mockito.any())).thenReturn(Mono.just(response));
        Mono<InitiateValidateDeviceSimUIResponse> activationResponse = helper.customerNameByMtn(null);
        StepVerifier.create(activationResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateGiftItemTest1() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateGiftItemUIRequest2.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateGiftItemUIResponse.json", testFileLocation);
        UpdateGiftItemUIRequest sampleRequest = mapper.readValue(sampleRequestString, UpdateGiftItemUIRequest.class);
        UpdateGiftItemUIResponse sampleResponse =  mapper.readValue(sampleResponseString, UpdateGiftItemUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData36.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<UpdateGiftItemUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper4.updateGiftItem(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateGiftItemUIResponse expectedResponse = sampleResponse;
        Mono<UpdateGiftItemUIResponse> response = helper.updateGiftItem(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateGiftItemTest2() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateGiftItemUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateGiftItemUIResponse.json", testFileLocation);
        UpdateGiftItemUIRequest sampleRequest = mapper.readValue(sampleRequestString, UpdateGiftItemUIRequest.class);
        UpdateGiftItemUIResponse sampleResponse =  mapper.readValue(sampleResponseString, UpdateGiftItemUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData36.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<UpdateGiftItemUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper4.updateGiftItem(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateGiftItemUIResponse expectedResponse = sampleResponse;
        Mono<UpdateGiftItemUIResponse> response = helper.updateGiftItem(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateGiftItemTest3() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateGiftItemUIRequest3.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateGiftItemUIResponse.json", testFileLocation);
        UpdateGiftItemUIRequest sampleRequest = mapper.readValue(sampleRequestString, UpdateGiftItemUIRequest.class);
        UpdateGiftItemUIResponse sampleResponse =  mapper.readValue(sampleResponseString, UpdateGiftItemUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData36.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<UpdateGiftItemUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper4.updateGiftItem(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateGiftItemUIResponse expectedResponse = sampleResponse;
        Mono<UpdateGiftItemUIResponse> response = helper.updateGiftItem(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addBuyoutAndConsentHelperTest1() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddBuyoutUIResponse1.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddDeviceUIRequest4.json", testFileLocation);
        String consentResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateConsentCxpResponse.json", testFileLocation);
        String buyoutAndConsentResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddDeviceUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData35.json", testFileLocation);
        UpdateConsentCxpResponse sampleConsentResponse = mapper.readValue(consentResponseString, UpdateConsentCxpResponse.class);
        AddDeviceUIRequest sampleUIRequest =  mapper.readValue(sampleUIRequestString, AddDeviceUIRequest.class);
        AddBuyoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddBuyoutUIResponse.class);
        AddDeviceUIResponse sampleDeviceResponse =  mapper.readValue(buyoutAndConsentResponseString, AddDeviceUIResponse.class);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addBuyout(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(cxpHelper.updateCustomerConsent(Mockito.any())).thenReturn(Mono.just(sampleConsentResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        AddDeviceUIResponse expectedResponse = sampleDeviceResponse;
        Mono<AddDeviceUIResponse> response = helper.addBuyoutAndConsent(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse.getIsConsentUpdated(), resp.getIsConsentUpdated())).expectComplete().verify();
    }

    @Test
    public void addBuyoutAndConsentHelperTest2() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddBuyoutUIResponse1.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddDeviceUIRequest5.json", testFileLocation);
        String consentResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateConsentCxpResponse.json", testFileLocation);
        String buyoutAndConsentResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddDeviceUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData36.json", testFileLocation);
        UpdateConsentCxpResponse sampleConsentResponse = mapper.readValue(consentResponseString, UpdateConsentCxpResponse.class);
        AddDeviceUIRequest sampleUIRequest =  mapper.readValue(sampleUIRequestString, AddDeviceUIRequest.class);
        AddBuyoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddBuyoutUIResponse.class);
        AddDeviceUIResponse sampleDeviceResponse =  mapper.readValue(buyoutAndConsentResponseString, AddDeviceUIResponse.class);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addBuyout(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(cxpHelper.updateCustomerConsent(Mockito.any())).thenReturn(Mono.just(sampleConsentResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        AddDeviceUIResponse expectedResponse = sampleDeviceResponse;
        Mono<AddDeviceUIResponse> response = helper.addBuyoutAndConsent(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addBuyoutAndConsentHelperTest3() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddBuyoutUIResponse1.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddDeviceUIRequest6.json", testFileLocation);
        String consentResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateConsentCxpResponse.json", testFileLocation);
        String buyoutAndConsentResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddDeviceUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData36.json", testFileLocation);
        UpdateConsentCxpResponse sampleConsentResponse = mapper.readValue(consentResponseString, UpdateConsentCxpResponse.class);
        AddDeviceUIRequest sampleUIRequest =  mapper.readValue(sampleUIRequestString, AddDeviceUIRequest.class);
        AddBuyoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddBuyoutUIResponse.class);
        AddDeviceUIResponse sampleDeviceResponse =  mapper.readValue(buyoutAndConsentResponseString, AddDeviceUIResponse.class);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addBuyout(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(cxpHelper.updateCustomerConsent(Mockito.any())).thenReturn(Mono.just(sampleConsentResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        AddDeviceUIResponse expectedResponse = sampleDeviceResponse;
        Mono<AddDeviceUIResponse> response = helper.addBuyoutAndConsent(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addBuyoutAndConsentHelperTest4() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddBuyoutUIResponse2.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddDeviceUIRequest.json", testFileLocation);
        String consentResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateConsentCxpResponse.json", testFileLocation);
        String buyoutAndConsentResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddDeviceUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        UpdateConsentCxpResponse sampleConsentResponse = mapper.readValue(consentResponseString, UpdateConsentCxpResponse.class);
        AddDeviceUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, AddDeviceUIRequest.class);
        AddBuyoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddBuyoutUIResponse.class);
        AddDeviceUIResponse sampleDeviceResponse = mapper.readValue(buyoutAndConsentResponseString, AddDeviceUIResponse.class);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addBuyout(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(cxpHelper.updateCustomerConsent(Mockito.any())).thenReturn(Mono.just(sampleConsentResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        AddDeviceUIResponse expectedResponse = sampleDeviceResponse;
        Mono<AddDeviceUIResponse> response = helper.addBuyoutAndConsent(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addBuyoutAndConsentHelperTest5() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddBuyoutUIResponse3.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddDeviceUIRequest.json", testFileLocation);
        String consentResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateConsentCxpResponse2.json", testFileLocation);
        String buyoutAndConsentResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddDeviceUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        UpdateConsentCxpResponse sampleConsentResponse = mapper.readValue(consentResponseString, UpdateConsentCxpResponse.class);
        AddDeviceUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, AddDeviceUIRequest.class);
        AddBuyoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddBuyoutUIResponse.class);
        AddDeviceUIResponse sampleDeviceResponse = mapper.readValue(buyoutAndConsentResponseString, AddDeviceUIResponse.class);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addBuyout(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(cxpHelper.updateCustomerConsent(Mockito.any())).thenReturn(Mono.just(sampleConsentResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        AddDeviceUIResponse expectedResponse = sampleDeviceResponse;
        Mono<AddDeviceUIResponse> response = helper.addBuyoutAndConsent(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }


    @Test
    public void addPlanforNSETest1() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIRequest6.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIResponse.json", testFileLocation);
        String sampleRetrieveCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RetrieveCartCXPResponse.json", testFileLocation);;
        AddPlanUIRequest UIRequest = new AddPlanUIRequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
        AddPlanUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData128.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleResponse = mapper.readValue(sampleResponseString, AddPlanUIResponse.class);
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(omniDLHelper.upsertPlanTaggingValueToRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(bpmHelperAddPlan.addPlan(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just("true"));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(new MyOfferETRRedisData()));
        RetrieveCartCXPResponse sampleCXPResponse = null;
        sampleCXPResponse = mapper.readValue(sampleRetrieveCartResponseString, RetrieveCartCXPResponse.class);
        Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
        AddPlanUIResponse expectedResponse = sampleResponse;
        Mono<AddPlanUIResponse> response = helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addPlanforNSETest2() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIRequest7.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIResponse.json", testFileLocation);
        String sampleRetrieveCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RetrieveCartCXPResponse.json", testFileLocation);;
        AddPlanUIRequest UIRequest = new AddPlanUIRequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
        AddPlanUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData128.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleResponse = mapper.readValue(sampleResponseString, AddPlanUIResponse.class);
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(omniDLHelper.upsertPlanTaggingValueToRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(bpmHelperAddPlan.addPlan(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just("true"));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(new MyOfferETRRedisData()));
        RetrieveCartCXPResponse sampleCXPResponse = null;
        sampleCXPResponse = mapper.readValue(sampleRetrieveCartResponseString, RetrieveCartCXPResponse.class);
        Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
        AddPlanUIResponse expectedResponse = sampleResponse;
        Mono<AddPlanUIResponse> response = helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addPlanforNSETest3() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIRequest8.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIResponse.json", testFileLocation);
        String sampleRetrieveCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RetrieveCartCXPResponse.json", testFileLocation);;
        AddPlanUIRequest UIRequest = new AddPlanUIRequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
        AddPlanUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData129.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleResponse = mapper.readValue(sampleResponseString, AddPlanUIResponse.class);
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(omniDLHelper.upsertPlanTaggingValueToRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(bpmHelperAddPlan.addPlan(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just("true"));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(new MyOfferETRRedisData()));
        RetrieveCartCXPResponse sampleCXPResponse = null;
        sampleCXPResponse = mapper.readValue(sampleRetrieveCartResponseString, RetrieveCartCXPResponse.class);
        Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
        AddPlanUIResponse expectedResponse = sampleResponse;
        Mono<AddPlanUIResponse> response = helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addPlanHelperTest1() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIRequest9.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIResponse.json", testFileLocation);
        String sampleRetrieveCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RetrieveCartCXPResponse.json", testFileLocation);;
        AddPlanUIRequest UIRequest = new AddPlanUIRequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
        AddPlanUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData122.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleResponse = mapper.readValue(sampleResponseString, AddPlanUIResponse.class);
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(omniDLHelper.upsertPlanTaggingValueToRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(bpmHelperAddPlan.addPlan(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just("false"));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        String etrString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/MyOfferETRRedisData.json", testFileLocation);
        MyOfferETRRedisData etrData = mapper.readValue(etrString, MyOfferETRRedisData.class);
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        RetrieveCartCXPResponse sampleCXPResponse = null;
        sampleCXPResponse = mapper.readValue(sampleRetrieveCartResponseString, RetrieveCartCXPResponse.class);
        Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
        AddPlanUIResponse expectedResponse = sampleResponse;
        Mono<AddPlanUIResponse> response = helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }
    //added changes for addressValidation here
    @Test
    public void addPlanHelperTest2() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIRequest10.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIResponse.json", testFileLocation);
        String sampleRetrieveCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RetrieveCartCXPResponse.json", testFileLocation);;
        AddPlanUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
        AddPlanUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData104.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);

        String addressQualByMtnStr= "{\"data\":[{\"mtn\":\"9106359416\",\"netWorkBandwidthType\":\"CBD\",\"cBandQualified\":true},{\"mtn\":\"9142041798\",\"netWorkBandwidthType\":\"CBD\",\"cBandQualified\":true}]}";
        AddressValidationRespToSessionData addressQualByMtn= mapper.readValue(addressQualByMtnStr, AddressValidationRespToSessionData.class);
        sampleRedisData.setAddressQualificationSessionData(addressQualByMtn);


        sampleResponse = mapper.readValue(sampleResponseString, AddPlanUIResponse.class);
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(omniDLHelper.upsertPlanTaggingValueToRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(bpmHelperAddPlan.addPlan(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just("false"));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        String etrString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/MyOfferETRRedisData1.json", testFileLocation);
        MyOfferETRRedisData etrData = mapper.readValue(etrString, MyOfferETRRedisData.class);
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        RetrieveCartCXPResponse sampleCXPResponse = null;
        sampleCXPResponse = mapper.readValue(sampleRetrieveCartResponseString, RetrieveCartCXPResponse.class);
        Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
        AddPlanUIResponse expectedResponse = sampleResponse;
        Mono<AddPlanUIResponse> response = helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addPlanHelperTest3() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIRequest11.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIResponse.json", testFileLocation);
        String sampleRetrieveCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RetrieveCartCXPResponse.json", testFileLocation);;
        AddPlanUIRequest UIRequest = new AddPlanUIRequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
        AddPlanUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleResponse = mapper.readValue(sampleResponseString, AddPlanUIResponse.class);
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(omniDLHelper.upsertPlanTaggingValueToRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(bpmHelperAddPlan.addPlan(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just("false"));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        String etrString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/MyOfferETRRedisData2.json", testFileLocation);
        MyOfferETRRedisData etrData = mapper.readValue(etrString, MyOfferETRRedisData.class);
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        RetrieveCartCXPResponse sampleCXPResponse = null;
        sampleCXPResponse = mapper.readValue(sampleRetrieveCartResponseString, RetrieveCartCXPResponse.class);
        Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
        AddPlanUIResponse expectedResponse = sampleResponse;
        Mono<AddPlanUIResponse> response = helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addPlanHelperTest4() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIRequest11.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIResponse.json", testFileLocation);
        String sampleRetrieveCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RetrieveCartCXPResponse.json", testFileLocation);;
        AddPlanUIRequest UIRequest = new AddPlanUIRequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
        AddPlanUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleResponse = mapper.readValue(sampleResponseString, AddPlanUIResponse.class);
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(omniDLHelper.upsertPlanTaggingValueToRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(bpmHelperAddPlan.addPlan(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just("false"));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        String etrString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/MyOfferETRRedisData3.json", testFileLocation);
        MyOfferETRRedisData etrData = mapper.readValue(etrString, MyOfferETRRedisData.class);
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        RetrieveCartCXPResponse sampleCXPResponse = null;
        sampleCXPResponse = mapper.readValue(sampleRetrieveCartResponseString, RetrieveCartCXPResponse.class);
        Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
        AddPlanUIResponse expectedResponse = sampleResponse;
        Mono<AddPlanUIResponse> response = helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addPlanHelperTest5() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIRequest11.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIResponse.json", testFileLocation);
        String sampleRetrieveCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RetrieveCartCXPResponse.json", testFileLocation);;
        AddPlanUIRequest UIRequest = new AddPlanUIRequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
        AddPlanUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleResponse = mapper.readValue(sampleResponseString, AddPlanUIResponse.class);
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(omniDLHelper.upsertPlanTaggingValueToRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(bpmHelperAddPlan.addPlan(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just("false"));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        String etrString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/MyOfferETRRedisData1.json", testFileLocation);
        MyOfferETRRedisData etrData = mapper.readValue(etrString, MyOfferETRRedisData.class);
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        RetrieveCartCXPResponse sampleCXPResponse = null;
        sampleCXPResponse = mapper.readValue(sampleRetrieveCartResponseString, RetrieveCartCXPResponse.class);
        Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
        AddPlanUIResponse expectedResponse = sampleResponse;
        Mono<AddPlanUIResponse> response = helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addPlanHelperTest6() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIRequest11.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIResponse.json", testFileLocation);
        String sampleRetrieveCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RetrieveCartCXPResponse.json", testFileLocation);;
        AddPlanUIRequest UIRequest = new AddPlanUIRequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
        AddPlanUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleResponse = mapper.readValue(sampleResponseString, AddPlanUIResponse.class);
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(omniDLHelper.upsertPlanTaggingValueToRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(bpmHelperAddPlan.addPlan(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just("false"));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        String etrString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/MyOfferETRRedisData.json", testFileLocation);
        MyOfferETRRedisData etrData = mapper.readValue(etrString, MyOfferETRRedisData.class);
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        RetrieveCartCXPResponse sampleCXPResponse = null;
        sampleCXPResponse = mapper.readValue(sampleRetrieveCartResponseString, RetrieveCartCXPResponse.class);
        Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
        AddPlanUIResponse expectedResponse = sampleResponse;
        Mono<AddPlanUIResponse> response = helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addPlanHelperTest7() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIRequest11.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIResponse.json", testFileLocation);
        String sampleRetrieveCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RetrieveCartCXPResponse.json", testFileLocation);;
        AddPlanUIRequest UIRequest = new AddPlanUIRequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
        AddPlanUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleResponse = mapper.readValue(sampleResponseString, AddPlanUIResponse.class);
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(omniDLHelper.upsertPlanTaggingValueToRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(bpmHelperAddPlan.addPlan(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just("false"));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        String etrString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/MyOfferETRRedisData4.json", testFileLocation);
        MyOfferETRRedisData etrData = mapper.readValue(etrString, MyOfferETRRedisData.class);
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        RetrieveCartCXPResponse sampleCXPResponse = null;
        sampleCXPResponse = mapper.readValue(sampleRetrieveCartResponseString, RetrieveCartCXPResponse.class);
        Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
        AddPlanUIResponse expectedResponse = sampleResponse;
        Mono<AddPlanUIResponse> response = helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addPlanHelperTest8() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIRequest12.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIResponse.json", testFileLocation);
        String sampleRetrieveCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RetrieveCartCXPResponse.json", testFileLocation);;
        AddPlanUIRequest UIRequest = new AddPlanUIRequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
        AddPlanUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleResponse = mapper.readValue(sampleResponseString, AddPlanUIResponse.class);
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(omniDLHelper.upsertPlanTaggingValueToRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(bpmHelperAddPlan.addPlan(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just("false"));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        String etrString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/MyOfferETRRedisData4.json", testFileLocation);
        MyOfferETRRedisData etrData = mapper.readValue(etrString, MyOfferETRRedisData.class);
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        RetrieveCartCXPResponse sampleCXPResponse = null;
        sampleCXPResponse = mapper.readValue(sampleRetrieveCartResponseString, RetrieveCartCXPResponse.class);
        Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
        AddPlanUIResponse expectedResponse = sampleResponse;
        Mono<AddPlanUIResponse> response = helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addPlanHelperTest9() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIRequest13.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIResponse.json", testFileLocation);
        String sampleRetrieveCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RetrieveCartCXPResponse.json", testFileLocation);;
        AddPlanUIRequest UIRequest = new AddPlanUIRequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
        AddPlanUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleResponse = mapper.readValue(sampleResponseString, AddPlanUIResponse.class);
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(omniDLHelper.upsertPlanTaggingValueToRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(bpmHelperAddPlan.addPlan(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just("false"));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        String etrString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/MyOfferETRRedisData4.json", testFileLocation);
        MyOfferETRRedisData etrData = mapper.readValue(etrString, MyOfferETRRedisData.class);
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        RetrieveCartCXPResponse sampleCXPResponse = null;
        sampleCXPResponse = mapper.readValue(sampleRetrieveCartResponseString, RetrieveCartCXPResponse.class);
        Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
        AddPlanUIResponse expectedResponse = sampleResponse;
        Mono<AddPlanUIResponse> response = helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void removeLinesHelperTest1() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIRequest2.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        RemoveLinesUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse sampleResponse =  mapper.readValue(sampleResponseString, RemoveLinesUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData130.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String nbxString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackResponse.json", testFileLocation);
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        when(nbxService.nbxFeedbackCall(Mockito.any())).thenReturn(Mono.just(nbxRes));
        String bvpStr = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BVPRedisData.json", testFileLocation);
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        String validateCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse.json", testFileLocation);
        ValidateCartUIResponse validateCartResponse = mapper.readValue(validateCartResponseString, ValidateCartUIResponse.class);
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartResponse));
        when(bpmHelper2.removeLines(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(new BVPRedisData()));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just(new String()));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        RemoveLinesUIResponse expectedResponse = sampleResponse;
        Mono<RemoveLinesUIResponse> response = helper.removeLines(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();

        String customerProfileJson = "CustomerProfileResponseRD.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(customerProfileJson, testFileLocation);
        CustomerProfileResponse profileResponse = mapper.readValue(sampleRequestString, CustomerProfileResponse.class);

        String cartJson = "RetrieveCartRD.json";
        String sampleCartString = sourceFileReaderUtil.readFile(cartJson, testFileLocation);
        CXPRetrieveCartDataVO cart = mapper.readValue(sampleCartString, CXPRetrieveCartDataVO.class);
        sampleRedisData.setRetrieveCart(cart);
        sampleRedisData.setCustomerProfile(profileResponse);
        sampleUIRequest.getCartInfo().setFlexV2(true);
        sampleUIRequest.getData().setEnableAssistedTagging(true);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        sampleUIRequest.getData().getLines()[0].setMtn("9194377114");
        sampleUIRequest.getCartInfo().setProcessAction("removeDevice");
        //when(dlHelper.getVzdlDataForRemoveDevice(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(new Vzdl());
        Mono<RemoveLinesUIResponse> response2 = helper.removeLines(sampleUIRequest);
        StepVerifier.create(response2).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response2).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();

        doNothing().when(dlService).buildDLData(Mockito.any());
        StepVerifier.create(response2).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response2).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();

    }

    @Test
    public void removeLinesHelperTest2() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIRequest3.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        RemoveLinesUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse sampleResponse =  mapper.readValue(sampleResponseString, RemoveLinesUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData131.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String nbxString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackResponse.json", testFileLocation);
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        when(nbxService.nbxFeedbackCall(Mockito.any())).thenReturn(Mono.just(nbxRes));
        String bvpStr = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BVPRedisData.json", testFileLocation);
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        String validateCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse.json", testFileLocation);
        ValidateCartUIResponse validateCartResponse = mapper.readValue(validateCartResponseString, ValidateCartUIResponse.class);
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartResponse));
        when(bpmHelper2.removeLines(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(new BVPRedisData()));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just(new String()));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        RemoveLinesUIResponse expectedResponse = sampleResponse;
        Mono<RemoveLinesUIResponse> response = helper.removeLines(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void removeLinesHelperTest3() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIRequest4.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        RemoveLinesUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse sampleResponse =  mapper.readValue(sampleResponseString, RemoveLinesUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData132.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String nbxString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackResponse.json", testFileLocation);
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        when(nbxService.nbxFeedbackCall(Mockito.any())).thenReturn(Mono.just(nbxRes));
        String bvpStr = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BVPRedisData.json", testFileLocation);
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        String validateCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse.json", testFileLocation);
        ValidateCartUIResponse validateCartResponse = mapper.readValue(validateCartResponseString, ValidateCartUIResponse.class);
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartResponse));
        when(bpmHelper2.removeLines(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(new BVPRedisData()));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just(new String()));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        RemoveLinesUIResponse expectedResponse = sampleResponse;
        Mono<RemoveLinesUIResponse> response = helper.removeLines(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void removeLinesHelperTest4() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIRequest3.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        RemoveLinesUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse sampleResponse =  mapper.readValue(sampleResponseString, RemoveLinesUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData132.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String nbxString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackResponse.json", testFileLocation);
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        when(nbxService.nbxFeedbackCall(Mockito.any())).thenReturn(Mono.just(nbxRes));
        String bvpStr = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BVPRedisData.json", testFileLocation);
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        String validateCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse.json", testFileLocation);
        ValidateCartUIResponse validateCartResponse = mapper.readValue(validateCartResponseString, ValidateCartUIResponse.class);
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartResponse));
        when(bpmHelper2.removeLines(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(new BVPRedisData()));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just(new String()));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        RemoveLinesUIResponse expectedResponse = sampleResponse;
        Mono<RemoveLinesUIResponse> response = helper.removeLines(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void removeLinesHelperTest5() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIRequest5.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        RemoveLinesUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse sampleResponse =  mapper.readValue(sampleResponseString, RemoveLinesUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData133.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String nbxString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackResponse.json", testFileLocation);
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        when(nbxService.nbxFeedbackCall(Mockito.any())).thenReturn(Mono.just(nbxRes));
        String bvpStr = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BVPRedisData.json", testFileLocation);
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        String validateCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse.json", testFileLocation);
        ValidateCartUIResponse validateCartResponse = mapper.readValue(validateCartResponseString, ValidateCartUIResponse.class);
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartResponse));
        when(bpmHelper2.removeLines(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(new BVPRedisData()));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just(new String()));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        RemoveLinesUIResponse expectedResponse = sampleResponse;
        Mono<RemoveLinesUIResponse> response = helper.removeLines(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void removeLinesHelperTest6() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIRequest6.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        RemoveLinesUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse sampleResponse =  mapper.readValue(sampleResponseString, RemoveLinesUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData135.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String nbxString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackResponse.json", testFileLocation);
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        when(nbxService.nbxFeedbackCall(Mockito.any())).thenReturn(Mono.just(nbxRes));
        String bvpStr = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BVPRedisData.json", testFileLocation);
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        String validateCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse.json", testFileLocation);
        ValidateCartUIResponse validateCartResponse = mapper.readValue(validateCartResponseString, ValidateCartUIResponse.class);
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartResponse));
        when(bpmHelper2.removeLines(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(new BVPRedisData()));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just(new String()));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        RemoveLinesUIResponse expectedResponse = sampleResponse;
        Mono<RemoveLinesUIResponse> response = helper.removeLines(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void removeLinesHelperTest7() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIRequest7.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        RemoveLinesUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse sampleResponse =  mapper.readValue(sampleResponseString, RemoveLinesUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData135.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String nbxString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackResponse.json", testFileLocation);
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        when(nbxService.nbxFeedbackCall(Mockito.any())).thenReturn(Mono.just(nbxRes));
        String bvpStr = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BVPRedisData.json", testFileLocation);
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        String validateCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse.json", testFileLocation);
        ValidateCartUIResponse validateCartResponse = mapper.readValue(validateCartResponseString, ValidateCartUIResponse.class);
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartResponse));
        when(bpmHelper2.removeLines(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(new BVPRedisData()));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just(new String()));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        RemoveLinesUIResponse expectedResponse = sampleResponse;
        Mono<RemoveLinesUIResponse> response = helper.removeLines(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void removeLinesHelperTest8() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIRequest8.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        RemoveLinesUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse sampleResponse =  mapper.readValue(sampleResponseString, RemoveLinesUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData136.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String nbxString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackResponse.json", testFileLocation);
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        when(nbxService.nbxFeedbackCall(Mockito.any())).thenReturn(Mono.just(nbxRes));
        String bvpStr = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BVPRedisData.json", testFileLocation);
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        String validateCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse.json", testFileLocation);
        ValidateCartUIResponse validateCartResponse = mapper.readValue(validateCartResponseString, ValidateCartUIResponse.class);
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartResponse));
        when(bpmHelper2.removeLines(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(new BVPRedisData()));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just(new String()));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        RemoveLinesUIResponse expectedResponse = sampleResponse;
        Mono<RemoveLinesUIResponse> response = helper.removeLines(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void removeLinesHelperTest9() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIRequest8.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        RemoveLinesUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse sampleResponse =  mapper.readValue(sampleResponseString, RemoveLinesUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData137.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String nbxString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackResponse.json", testFileLocation);
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        when(nbxService.nbxFeedbackCall(Mockito.any())).thenReturn(Mono.just(nbxRes));
        String bvpStr = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BVPRedisData.json", testFileLocation);
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        String validateCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse.json", testFileLocation);
        ValidateCartUIResponse validateCartResponse = mapper.readValue(validateCartResponseString, ValidateCartUIResponse.class);
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartResponse));
        when(bpmHelper2.removeLines(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(new BVPRedisData()));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just(new String()));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        RemoveLinesUIResponse expectedResponse = sampleResponse;
        Mono<RemoveLinesUIResponse> response = helper.removeLines(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void removeLinesHelperTest10() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIRequest9.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        RemoveLinesUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse sampleResponse =  mapper.readValue(sampleResponseString, RemoveLinesUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String nbxString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackResponse.json", testFileLocation);
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        when(nbxService.nbxFeedbackCall(Mockito.any())).thenReturn(Mono.just(nbxRes));
        String bvpStr = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BVPRedisData6.json", testFileLocation);
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        String validateCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse.json", testFileLocation);
        ValidateCartUIResponse validateCartResponse = mapper.readValue(validateCartResponseString, ValidateCartUIResponse.class);
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartResponse));
        when(bpmHelper2.removeLines(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just("euser"));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        RemoveLinesUIResponse expectedResponse = sampleResponse;
        Mono<RemoveLinesUIResponse> response = helper.removeLines(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void removeLinesHelperTest11() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIRequest10.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        RemoveLinesUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse sampleResponse =  mapper.readValue(sampleResponseString, RemoveLinesUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData138.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String nbxString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackResponse.json", testFileLocation);
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        when(nbxService.nbxFeedbackCall(Mockito.any())).thenReturn(Mono.just(nbxRes));
        String bvpStr = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BVPRedisData7.json", testFileLocation);
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        String validateCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse.json", testFileLocation);
        ValidateCartUIResponse validateCartResponse = mapper.readValue(validateCartResponseString, ValidateCartUIResponse.class);
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartResponse));
        when(bpmHelper2.removeLines(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just("euser"));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        RemoveLinesUIResponse expectedResponse = sampleResponse;
        Mono<RemoveLinesUIResponse> response = helper.removeLines(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void removeLinesHelperTest12() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIRequest11.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        RemoveLinesUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse sampleResponse =  mapper.readValue(sampleResponseString, RemoveLinesUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData138.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String nbxString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackResponse.json", testFileLocation);
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        when(nbxService.nbxFeedbackCall(Mockito.any())).thenReturn(Mono.just(nbxRes));
        String bvpStr = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BVPRedisData7.json", testFileLocation);
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        String validateCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse.json", testFileLocation);
        ValidateCartUIResponse validateCartResponse = mapper.readValue(validateCartResponseString, ValidateCartUIResponse.class);
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartResponse));
        when(bpmHelper2.removeLines(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just("euser"));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        RemoveLinesUIResponse expectedResponse = sampleResponse;
        Mono<RemoveLinesUIResponse> response = helper.removeLines(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void removeLinesHelperTest13() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIRequest12.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        RemoveLinesUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse sampleResponse =  mapper.readValue(sampleResponseString, RemoveLinesUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData138.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String nbxString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackResponse.json", testFileLocation);
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        when(nbxService.nbxFeedbackCall(Mockito.any())).thenReturn(Mono.just(nbxRes));
        String bvpStr = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BVPRedisData8.json", testFileLocation);
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        String validateCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse.json", testFileLocation);
        ValidateCartUIResponse validateCartResponse = mapper.readValue(validateCartResponseString, ValidateCartUIResponse.class);
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartResponse));
        when(bpmHelper2.removeLines(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just("euser"));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        RemoveLinesUIResponse expectedResponse = sampleResponse;
        Mono<RemoveLinesUIResponse> response = helper.removeLines(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void removeLinesHelperTest14() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIRequest13.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        RemoveLinesUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse sampleResponse =  mapper.readValue(sampleResponseString, RemoveLinesUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData139.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String nbxString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackResponse.json", testFileLocation);
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        when(nbxService.nbxFeedbackCall(Mockito.any())).thenReturn(Mono.just(nbxRes));
        String bvpStr = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BVPRedisData7.json", testFileLocation);
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        String validateCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse10.json", testFileLocation);
        ValidateCartUIResponse validateCartResponse = mapper.readValue(validateCartResponseString, ValidateCartUIResponse.class);
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartResponse));
        when(bpmHelper2.removeLines(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just("euser"));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        RemoveLinesUIResponse expectedResponse = sampleResponse;
        Mono<RemoveLinesUIResponse> response = helper.removeLines(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void removeLinesHelperTest15() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIRequest13.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        RemoveLinesUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse sampleResponse =  mapper.readValue(sampleResponseString, RemoveLinesUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData140.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String nbxString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackResponse.json", testFileLocation);
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        when(nbxService.nbxFeedbackCall(Mockito.any())).thenReturn(Mono.just(nbxRes));
        String bvpStr = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BVPRedisData7.json", testFileLocation);
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        String validateCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse6.json", testFileLocation);
        ValidateCartUIResponse validateCartResponse = mapper.readValue(validateCartResponseString, ValidateCartUIResponse.class);
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartResponse));
        when(bpmHelper2.removeLines(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just("euser"));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        RemoveLinesUIResponse expectedResponse = sampleResponse;
        Mono<RemoveLinesUIResponse> response = helper.removeLines(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void removeLinesHelperTest16() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIRequest13.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        RemoveLinesUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse sampleResponse =  mapper.readValue(sampleResponseString, RemoveLinesUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData141.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String nbxString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackResponse.json", testFileLocation);
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        when(nbxService.nbxFeedbackCall(Mockito.any())).thenReturn(Mono.just(nbxRes));
        String bvpStr = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BVPRedisData7.json", testFileLocation);
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        String validateCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse11.json", testFileLocation);
        ValidateCartUIResponse validateCartResponse = mapper.readValue(validateCartResponseString, ValidateCartUIResponse.class);
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartResponse));
        when(bpmHelper2.removeLines(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just("euser"));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        RemoveLinesUIResponse expectedResponse = sampleResponse;
        Mono<RemoveLinesUIResponse> response = helper.removeLines(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void removeLinesHelperTest17() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIRequest14.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        RemoveLinesUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse sampleResponse =  mapper.readValue(sampleResponseString, RemoveLinesUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData142.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String nbxString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackResponse.json", testFileLocation);
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        when(nbxService.nbxFeedbackCall(Mockito.any())).thenReturn(Mono.just(nbxRes));
        String bvpStr = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BVPRedisData7.json", testFileLocation);
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        String validateCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse11.json", testFileLocation);
        ValidateCartUIResponse validateCartResponse = mapper.readValue(validateCartResponseString, ValidateCartUIResponse.class);
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartResponse));
        when(bpmHelper2.removeLines(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just("euser"));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        RemoveLinesUIResponse expectedResponse = sampleResponse;
        Mono<RemoveLinesUIResponse> response = helper.removeLines(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addPlanHelperTest10_tagging() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIRequest13.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIResponse.json", testFileLocation);
        String sampleRetrieveCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RetrieveCartCXPResponse.json", testFileLocation);;
        AddPlanUIRequest UIRequest = new AddPlanUIRequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
        AddPlanUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleResponse = mapper.readValue(sampleResponseString, AddPlanUIResponse.class);
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(omniDLHelper.upsertPlanTaggingValueToRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(bpmHelperAddPlan.addPlan(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just("false"));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        String etrString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/MyOfferETRRedisData4.json", testFileLocation);
        MyOfferETRRedisData etrData = mapper.readValue(etrString, MyOfferETRRedisData.class);
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        RetrieveCartCXPResponse sampleCXPResponse = null;
        sampleCXPResponse = mapper.readValue(sampleRetrieveCartResponseString, RetrieveCartCXPResponse.class);
        Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
        AddPlanUIResponse expectedResponse = sampleResponse;
        UIRequest.getCartInfo().setFlexV2(true);
        UIRequest.getData().setEnableAssistedTagging(true);
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        Vzdl vzdl = new Vzdl();
        vzdl.setPage(new Page());
        when(omniDLHelper.getVzdlDataForAddPlan(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(vzdl);

        when(omniDLHelper.getFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("CPC"));

        Mono<AddPlanUIResponse> response = helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
        //TC2
        vzdl.setPage(null);
        when(omniDLHelper.getVzdlDataForAddPlan(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(vzdl);
         response= helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
        //TC3
        UIRequest.getCartInfo().setFlexV2(false);
        response= helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();

        sampleResponse.getServiceBody().getServiceResponse().getContext().setCartInfo(null);
        response= helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();

        sampleResponse.getServiceBody().getServiceResponse().setContext(null);
        response= helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();

        sampleResponse.getServiceBody().setServiceResponse(null);
        response= helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();

        sampleResponse.setServiceBody(null);
        response= helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
        //TC4
        AddPlanUIRequest addplanUiRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
        addplanUiRequest.setRetrieveCart(null);
        response= helper.addPlan(addplanUiRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
        //TC5

        when(omniDLHelper.getVzdlDataForAddPlan(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(null);
        response= helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();

        //TC6
        sampleRedisData.setRetrieveCart(null);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        response= helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
        //TC7
        //TC8
        when(omniDLHelper.getVzdlDataForAddPlan(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(null);
        response= helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
        //tc9

        UIRequest.getData().setEnableAssistedTagging(false);
        response= helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();


        UIRequest.getData().setEnableAssistedTagging(null);
        response= helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();

//        UIRequest.setData(null);
//        response= helper.addPlan(UIRequest);
//        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
//        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();

        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.FALSE));
        response= helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }


    @Test
    public void addPlanFlexV2Test() throws Exception{
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIRequest13.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIResponse.json", testFileLocation);
        String sampleRetrieveCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RetrieveCartCXPResponse.json", testFileLocation);;
        AddPlanUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddPlanUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddPlanUIResponse.class);
        UIRequest.getCartInfo().setFlexV2(true);
        UIRequest.getData().setEnableAssistedTagging(null);
        when(bpmHelperAddPlan.addPlan(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just("false"));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        String etrString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/MyOfferETRRedisData4.json", testFileLocation);
        MyOfferETRRedisData etrData = mapper.readValue(etrString, MyOfferETRRedisData.class);
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(false));
        when(omniDLHelper.getFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(omniDLHelper.upsertPlanTaggingValueToRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        RetrieveCartCXPResponse sampleCXPResponse = null;
        sampleCXPResponse = mapper.readValue(sampleRetrieveCartResponseString, RetrieveCartCXPResponse.class);
        Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
        AddPlanUIResponse expectedResponse = sampleResponse;
        Mono<AddPlanUIResponse> response= helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        UIRequest.getData().setEnableAssistedTagging(null);
        response = helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();

        UIRequest.getData().setEnableAssistedTagging(false);
        response = helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();

        UIRequest.getData().setEnableAssistedTagging(true);
        response = helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();


        when(dlHelper.getVzdlDataForAddPlan(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(new Vzdl());

        UIRequest.setRetrieveCart(null);
        response = helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(Assert::assertNotNull).expectComplete().verify();

        UIRequest=mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
        response = helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(Assert::assertNotNull).expectComplete().verify();
        
        Vzdl vzdl= new Vzdl();
        vzdl.setPage(new Page());
        when(dlHelper.getVzdlDataForAddPlan(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(vzdl);
        response = helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(Assert::assertNotNull).expectComplete().verify();

        when(omniDLHelper.getFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just(""));
        response = helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(Assert::assertNotNull).expectComplete().verify();

        etrData.setLines(null);
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        UIRequest.setData(null);
        response = helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(Assert::assertNotNull).expectComplete().verify();

        UIRequest.getCartInfo().setFlexV2(false);
        response = helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(Assert::assertNotNull).expectComplete().verify();

        sampleResponse.setServiceBody(null);
        when(bpmHelperAddPlan.addPlan(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        response = helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(Assert::assertNotNull).expectComplete().verify();
    }
}
