package onevz.soe.cart.service.test.config;

import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;

import onevz.soe.datastore.annotations.EnableDatastoreClients;

@Configuration
@ComponentScan(basePackages = { /*"onevz.spring.config", "onevzw.soe.core.config", "onevz.soe.cart.controller",
		"onevz.soe.cart.smartimeisearch", "onevz.soe.cart.token", "onevz.soe.wsclient.bpm",  "onevz.soe.cart.bpm.helper", "onevz.soe.cart.bpm.service","onevz.soe.security","onevz.aem.errorhandling",
		"onvez.soe.cart.cxp.service", "onevz.soe.wsclient.gql", "onevz.soe.cart.cxp.helper", "onevz.soe.cart.helper", "onevz.soe.cart.nbx","onevz.soe.cart.util",
		"onevz.soe.cart.model", "onevz.soe.cart.requests", "onevz.soe.cart.responses", "onevz.soe.cart.ui" , "onevz.soe.security", "onevz.soe.core","onevz.soe.cradle.client", "onevz.soe.cart.omnidl","onevz.cxp.feature.util", "onevz.soe.cart.exceptions", */"onevz.soe.cart"})
@EnableDatastoreClients(value = "onevz.soe.cradle")
public class CartServiceTestConfig {

	@Bean
    public MessageSource messageSource() {
        ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
 
        messageSource.setBasename("i18n/messages");
        messageSource.setUseCodeAsDefaultMessage(true);
 
        return messageSource;
    }
}
