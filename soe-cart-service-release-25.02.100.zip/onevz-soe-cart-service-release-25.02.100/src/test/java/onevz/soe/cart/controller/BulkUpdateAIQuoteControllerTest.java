package onevz.soe.cart.controller;


import junit.framework.Assert;
import onevz.soe.cart.helper.BulkUpdateAIQuoteHelper;
import onevz.soe.cart.helper.BulkUpdateAIQuoteHelperTest;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.common.CartServiceServiceHeader;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.model.bulkcartupdate.BulkQuoteUIRequest;
import onevz.soe.cart.model.bulkcartupdate.BulkQuoteUIResponse;
import onevz.soe.cart.model.bulkcartupdate.CartData;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.http.server.reactive.MockServerHttpResponse;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@WebFluxTest(BulkUpdateAIQuoteControllerTest.class)
public class BulkUpdateAIQuoteControllerTest {

    @InjectMocks
    BulkUpdateAIQuoteController controller;

    @Mock
    BulkUpdateAIQuoteHelper bulkUpdateAIQuoteHelper;

    @Test
    public void testBulkUpdateCartServices() throws Exception{
        URI url = URI.create("http://localhost/cart/bulkUpdateAIQuote");
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        HttpCookie targetPricingOffer = new HttpCookie("targetPricingOffer", "true");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("targetPricingOffer", targetPricingOffer);
        bodyMap.add("channelId", new HttpCookie("VZW-DOTCOM", "true"));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-DOTCOM").cookies(bodyMap).build();
        BulkQuoteUIRequest request = new BulkQuoteUIRequest();
        CartData cartData = new CartData();
//        cartData.setPrepaidMtn("1234567890");
        request.setData(cartData);
        BulkQuoteUIResponse response = new BulkQuoteUIResponse();
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        header.setSessionId("SESSIONID");
        response.setServiceHeader(header);
        Mockito.when(bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = controller.bulkUpdateCartServices(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();

        // channel id digital
        bodyMap.add("channelId", new HttpCookie("digital", "true"));
        httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-DOTCOM").cookies(bodyMap).build();
        controllerResponse = controller.bulkUpdateCartServices(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();

        // channel is null
        httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","").cookies(bodyMap).build();
        controllerResponse = controller.bulkUpdateCartServices(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void testBulkUpdateCartServices_ErrorMsg() throws Exception {
        URI url = URI.create("http://localhost/cart/bulkUpdateAIQuote");
        HttpCookie targetPricingOffer = new HttpCookie("targetPricingOffer", "true");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("targetPricingOffer", targetPricingOffer);
        bodyMap.add("channelId", new HttpCookie("VZW-DOTCOM", "true"));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookies(bodyMap).build();
        BulkQuoteUIRequest request = new BulkQuoteUIRequest();
        CartData cartData = new CartData();
//        cartData.setPrepaidMtn("1234567890");
        request.setData(cartData);
        BulkQuoteUIResponse response = new BulkQuoteUIResponse();
        List<CartError> errorList = new ArrayList<>();
        CartError error = new CartError();
        error.setMessage("ERROR");
        errorList.add(error);
        response.setErrors(errorList);
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        header.setSessionId("SESSIONID");
        response.setServiceHeader(header);
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        Mockito.when(bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(Mockito.any(), Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = controller.bulkUpdateCartServices(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }
}
