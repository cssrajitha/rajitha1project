package onevz.soe.cart.service.test.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.ui.requests.AddAllConfiguratorUIRequest;
import onevz.soe.cart.util.CartConfiguratorPegaRequestErrorsUtil;
import onevz.soe.cart.util.SourceFileReaderUtil;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;

@RunWith(SpringJUnit4ClassRunner.class)
@WebFluxTest(CartConfiguratorPegaRequestErrorsUtil.class)
public class CartConfiguratorPegaRequestErrorsUtilTest {
    @Autowired
    SourceFileReaderUtil sourceFileReaderUtil;
    @MockBean
    CartConfiguratorPegaRequestErrorsUtil util;
    @Autowired
    private ObjectMapper mapper;
    @Value("${onevz.soe.cart.test.fileLocation}")
    private String testFileLocation;

    @Test
    public void handleAddAllConfiguratorRequestErrorsTest_with_no_intent_type() throws IOException {
        String requestFile = "data/addAllToCartConfigurator/request/requestWithoutIntent.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        AddAllConfiguratorUIRequest UIRequest = mapper.readValue(requestString, AddAllConfiguratorUIRequest.class);
        CartConfiguratorPegaRequestErrorsUtil.handleAddAllConfiguratorRequestErrors(UIRequest);
        StepVerifier.create(Mono.just(UIRequest)).assertNext(Assertions::assertNotNull).expectComplete().verify();
    }

    @Test
    public void handleAddAllConfiguratorRequestErrorsTest() throws IOException {
        String requestString = "{\"cartInfo\": null}";
        AddAllConfiguratorUIRequest UIRequest = mapper.readValue(requestString, AddAllConfiguratorUIRequest.class);
        CartConfiguratorPegaRequestErrorsUtil.handleAddAllConfiguratorRequestErrors(UIRequest);
        StepVerifier.create(Mono.just(UIRequest)).assertNext(Assertions::assertNotNull).expectComplete().verify();
    }

    @Test
    public void handleAddAllConfiguratorRequestErrorsTest_with_no_process_action() throws IOException {
        String requestFile = "data/addAllToCartConfigurator/request/requestWithoutProcessAction.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        AddAllConfiguratorUIRequest UIRequest = mapper.readValue(requestString, AddAllConfiguratorUIRequest.class);
        CartConfiguratorPegaRequestErrorsUtil.handleAddAllConfiguratorRequestErrors(UIRequest);
        StepVerifier.create(Mono.just(UIRequest)).assertNext(Assertions::assertNotNull).expectComplete().verify();
    }

    @Test
    public void handleAddAllConfiguratorRequestErrorsTest_with_no_lines() throws IOException {
        String requestFile = "data/addAllToCartConfigurator/request/requestWithoutLines.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        AddAllConfiguratorUIRequest UIRequest = mapper.readValue(requestString, AddAllConfiguratorUIRequest.class);
        CartConfiguratorPegaRequestErrorsUtil.handleAddAllConfiguratorRequestErrors(UIRequest);
        StepVerifier.create(Mono.just(UIRequest)).assertNext(Assertions::assertNotNull).expectComplete().verify();
    }
    @Test
    public void handleAddAllConfiguratorRequestErrorsTestNullCheck() throws IOException {
        String requestFile = "data/addAllToCartConfigurator/request/requestForNullCheck.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        AddAllConfiguratorUIRequest UIRequest = mapper.readValue(requestString, AddAllConfiguratorUIRequest.class);
        CartConfiguratorPegaRequestErrorsUtil.handleAddAllConfiguratorRequestErrors(UIRequest);
        StepVerifier.create(Mono.just(UIRequest)).assertNext(Assertions::assertNotNull).expectComplete().verify();
    }
}
