package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.bpm.helper.CartWithDateServiceBpmHelper;
import onevz.soe.cart.helper.UpdateCartWithDatesHelper;
import onevz.soe.cart.responses.CartWithDatePegaResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.requests.CartWithDateUIRequest;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;

import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(UpdateCartWithDatesHelper.class)
public class UpdateCartWithDatesHelperTest {
    @Autowired
    private UpdateCartWithDatesHelper updateCartWithDatesHelper;

    @MockBean
    CartWithDateServiceBpmHelper cartWithDateServiceBpmHelper;

    @Autowired
    private ObjectMapper mapper;
    
    @Test
    public void saveCartWithDateTest() throws IOException
    {
        String requestString = "{\n \"context\": {\n \"caseId\": \"SOP-3597615-E01\",\n\"contextInfo\": {\n \"callReason\": \"SalesOrderPurchase\",\n \"processStep\": \"OrderReview\",\n\"processAction\": \"UpdateScheduleAppointment\",\n \"intent\": \"MOVER\"\n},\n\"customerInfo\": {\n\"accountNumber\": \"0389467727-00001\",\n\"cartCreator\": \"6072376627\",\n\"processingMTN\": \"8136958775\",\n \"registerNumber\": 0\n},\n\"cartInfo\": {\n\"cartId\": \"cfe0a112-c547-41a6-bfde-7e0688d7a774\",\n  \"itemType\": \"SCHEDULE5GAPPT\",\n\"intendType\": \"MOVER\",\n\"moversInfo\": {\n\"moveInDate\": \"07/20/2021\",\n  \"moveOutDate\": \"07/30/2021\"\n }\n }\n }\n}";
        String responseString = "{\n \"serviceHeader\" : {\n \"statusMsg\" : \"SUCCESS\",\n \"sessionId\" : \"\",\n \"serviceName\" : \"SalesOrderPurchase\",\n \"userId\" : \"\",\n\"statusCode\" : \"00\"\n },\n \"serviceBody\" : {\n \"serviceResponse\" : {\n\"context\" : {\n\"cartInfo\" : {\n  \"statusMsg\" : \"Success\",\n\"cartId\" : \"1f69c02f-c68f-4445-b5ff-8814fbd3412d\",\n \"preAuthSuccess\" : false,\n \"statusCode\" : \"1\"\n },\n \"contextInfo\" : {\n \"availablePaths\" : [{\n \"path\" : \"OrderReview-Shipping-Payment-Agreement\"\n  }\n   ],\n  \"processAction\" : \"\",\n \"processStep\" : \"OrderReview-Shipping-Payment-Agreement\",\n  \"callReason\" : \"SalesOrderPurchase\"\n    },\n \"caseId\" : \"SOP-3335332-E01\",\n\"customerInfo\" : {\n \"cartCreator\" : \"4029847575\",\n  \"processingMTN\" : \"newLine1\",\n \"accountNumber\" : \"0283134872-00001\"\n },\n   \"processMTNList\" : [{\n   \"mtn\" : \"newLine1\",\n\"completedprocessSteps\" : [\"NumberSelection\", \"Accessories\", \"NumberSelection\", \"NumberSelection\", \"ShoppingCart\", \"ContactInfo\", \"ShippingOptions\", \"ShippingOptions\", \"AppointmentSchedule\"]\n }\n]\n }\n  }\n }\n}\n";
        CartWithDateUIRequest request = mapper.readValue(requestString, CartWithDateUIRequest.class);
        CartWithDatePegaResponse expectedResponse = mapper.readValue(responseString, CartWithDatePegaResponse.class);
        when(cartWithDateServiceBpmHelper.saveCartWithDate(Mockito.any())).thenReturn(Mono.just(expectedResponse));

     Mono<CartWithDatePegaResponse>   response =updateCartWithDatesHelper.saveCartWithDate(request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void saveCartWithDateTest2() throws IOException {
        String requestString = "{\"context\": {\"caseId\": \"SOP-3597615-E01\",\"contextInfo\": {\"callReason\": \"SalesOrderPurchase\",\"processStep\": \"OrderReview\",\"processAction\": \"UpdateScheduleAppointment\",\"intent\": \"MOVER\"},\"customerInfo\": {\"accountNumber\": \"0389467727-00001\",\"cartCreator\": \"6072376627\",\"processingMTN\": \"8136958775\",\"registerNumber\": 0},\"cartInfo\": {\"cartId\": \"cfe0a112-c547-41a6-bfde-7e0688d7a774\",\"itemType\": \"SCHEDULE5GAPPT\",\"intendType\": \"MOVER\",\"moversInfo\": {\"moveInDate\": \"07/20/2021\",\"moveOutDate\": \"07/30/2021\"}}}}";
        String responseString = "{\"errors\": [],\"serviceHeader\": {\"statusMsg\": \"SUCCESS\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"cartInfo\": {\"statusMsg\": \"Success\",\"cartId\": \"1f69c02f-c68f-4445-b5ff-8814fbd3412d\",\"preAuthSuccess\": false,\"statusCode\": \"1\"},\"contextInfo\": {\"availablePaths\": [{\"path\": \"OrderReview-Shipping-Payment-Agreement\"}],\"processAction\": \"\",\"processStep\": \"OrderReview-Shipping-Payment-Agreement\",\"callReason\": \"SalesOrderPurchase\"},\"caseId\": \"SOP-3335332-E01\",\"customerInfo\": {\"cartCreator\": \"4029847575\",\"processingMTN\": \"newLine1\",\"accountNumber\": \"0283134872-00001\"},\"processMTNList\": [{\"mtn\": \"newLine1\",\"completedprocessSteps\": [\"NumberSelection\",\"Accessories\",\"NumberSelection\",\"NumberSelection\",\"ShoppingCart\",\"ContactInfo\",\"ShippingOptions\",\"ShippingOptions\",\"AppointmentSchedule\"]}]}}}}";
        CartWithDateUIRequest request = mapper.readValue(requestString, CartWithDateUIRequest.class);
        CartWithDatePegaResponse expectedResponse = mapper.readValue(responseString, CartWithDatePegaResponse.class);
        when(cartWithDateServiceBpmHelper.saveCartWithDate(Mockito.any())).thenReturn(Mono.just(expectedResponse));
        Mono<CartWithDatePegaResponse> response = updateCartWithDatesHelper.saveCartWithDate(request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }
}
