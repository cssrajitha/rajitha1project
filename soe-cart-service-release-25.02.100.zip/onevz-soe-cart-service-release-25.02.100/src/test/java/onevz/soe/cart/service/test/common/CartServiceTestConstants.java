package onevz.soe.cart.service.test.common;

public class CartServiceTestConstants {

	public static final String ADD_ACCESSORY_PATH = "classpath:data/Requests/add-accessory/";
	
}
