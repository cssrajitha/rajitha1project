package onevz.soe.cart.service.test.common;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.databind.ObjectMapper;


public class CartAbstractService {
	
	@Autowired
	private ObjectMapper mapper;
	
 	protected TestConfig getData(String type, String testName) throws IOException{
 		TestConfig config = new TestConfig(type,testName);
 		config.populateReqAndRes();
        return config;
    }
 	
 	protected <T> Object getMapperValue(String reqrestype, Object obj) throws IOException {
		System.out.println();
		return mapper.readValue(reqrestype, (Class<T>) obj);
	}

}
