package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.cxp.service.OrderProcessCXPServices;
import onevz.soe.cart.gql.requests.CustomerByIdBillAccounts;
import onevz.soe.cart.gql.requests.CustomerByIdGQLRequest;
import onevz.soe.cart.gql.requests.CustomerByIdMtnsGQLRequest;
import onevz.soe.cart.gql.requests.CustomerByMtnGQLRequest;
import onevz.soe.cart.gql.response.CustomerByIdGQLResponse;
import onevz.soe.cart.helper.*;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.retrieveCart.fiveG.CXPOrderDetailsView;
import onevz.soe.cart.nbx.NBXFeedbackService;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.requests.fiveGAddress;
import onevz.soe.cart.util.CartPegaRequestErrorsUtil;
import onevz.soe.cradle.CradleAllocator;
import onevz.soe.exception.SOEErrorHolder;
import onevz.soe.omnidl.util.DLUtilityService;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;

import com.fasterxml.jackson.core.JsonProcessingException;

import onevz.soe.cart.bpm.helper.CartServiceBpmHelper;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;

import onevz.soe.cart.model.addDevice.AddPlanDeviceCartInfo;
import onevz.soe.cart.model.common.Address;
import onevz.soe.cart.model.common.BillingAddress;
import onevz.soe.cart.model.common.FiveG.Device;
import onevz.soe.cart.model.common.FiveG.FiveGLTEAddressRedis;
import onevz.soe.cart.model.common.FiveG.Line;
import onevz.soe.cart.model.common.ServiceAddress;
import onevz.soe.cart.model.common.SoftSKUItem;
import onevz.soe.cart.model.orderConfirmation.CXPOrderConfirm5GVO;
import onevz.soe.cart.model.retrieveCart.*;
import onevz.soe.cart.model.retrieveCart.fiveG.CXPDueItemsList;
import onevz.soe.cart.model.reviewOrderInsipico.InspicioResponseOrderInfo;
import onevz.soe.cart.model.reviewOrderInsipico.InspicioTermsAndConditions;
import onevz.soe.cart.requests.CheckoutDetailsRequest;
import onevz.soe.cart.requests.GetCartDetailsRequest;
import onevz.soe.cart.requests.RetrieveCartCXPRequest;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.ui.common.CartInfo;
import onevz.soe.cart.ui.common.DeviceCartInfo;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.AddPlanAndDeviceUIRequest;
import onevz.soe.cart.ui.requests.SaveCartWithEmailUIRequest;
import onevz.soe.cart.ui.responses.AddPlanAndDeviceUIResponse;
import onevz.soe.cart.ui.responses.CrmRetrieveCartUIResponse;
import onevz.soe.cart.ui.responses.OrderConfirmationUIResponse;
import onevz.soe.cart.ui.responses.RetrieveCartUIResponse;
import onevz.soe.cart.util.CommonUtil;
import onevz.soe.cart.util.CommonUtil2;

import org.junit.Assert;
import org.mockito.Mockito;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.http.server.reactive.MockServerHttpResponse;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;
import java.net.URI;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static reactor.core.publisher.Mono.just;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { CartServiceTestConfig.class })
//@NotThreadSafe
public class FiveGhomeCommonHelper2Test {

    @InjectMocks
    private FiveGhomeCommonHelper fiveGhomeCommonHelper;

    @Mock
    private RedisHelper3 redisHelper3;

    @Mock
    private RedisHelper redisHelper;

    @Test
    public void test_addPlanAndDevice() {
        AddPlanAndDeviceUIRequest request = new AddPlanAndDeviceUIRequest();
        FiveGLTEAddressRedis a = new FiveGLTEAddressRedis();
        a.setErrors(new ArrayList<>());
        a.getErrors().add(new CartError());
        ReflectionTestUtils.setField(fiveGhomeCommonHelper, "fwaSkipValidationProcessActions", Arrays.asList("ABC", "gotoagreements"));
        request.setCartInfo(new AddPlanDeviceCartInfo());
        request.getCartInfo().setIntendType("AAL_5G");
        request.getCartInfo().setProcessAction("ABC");
        request.getCartInfo().setProcessStep(CartConstants.ORDER_NOW);
        request.getCartInfo().setCartCreator("DDDCartConstants.ORDER_NOW");
        request.getCartInfo().setProcessingMTN("DDDCartConstants.ORDER_NOW");
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        doReturn(Mono.just(new CartRedisData())).when(mock(RedisHelper.class)).getDataFromRedis();
        when(redisHelper3.getFiveGAddressFromRedisFromFiveGFlow()).thenReturn(Mono.just(a));
        when(redisHelper3.getBulkQualificationAddressFromRedis(any())).thenReturn(Mono.just(a));
        when(redisHelper3.fetchTechnicianDataFromRedis()).thenReturn(Mono.just(new TechFlowRedisData()));
        StepVerifier.create(fiveGhomeCommonHelper.addPlanAndDevice(request)).assertNext(addPlanAndDeviceUIResponse -> Assertions.assertNotNull(addPlanAndDeviceUIResponse)).expectComplete().verify();
        request.getCartInfo().setProcessAction("gotoagreements");
        StepVerifier.create(fiveGhomeCommonHelper.addPlanAndDevice(request)).verifyError();
    }
}
