package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.aem.errorhandling.service.CartAEMService;
import onevz.aem.response.*;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper2;
import onevz.soe.cart.cxp.helper.CatalogServiceHelper;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.cxp.service.CatalogService;
import onevz.soe.cart.helper.FeatureFlagHelper;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.helper.RedisHelper2;
import onevz.soe.cart.helper.RedisHelper3;
import onevz.soe.cart.model.common.Device;
import onevz.soe.cart.model.deviceIdValidation.SearchAttributes;
import onevz.soe.cart.model.deviceSimValidation.CustomerReqType;
import onevz.soe.cart.model.deviceSimValidation.DeviceAttributes;
import onevz.soe.cart.model.deviceSimValidation.EsimInfo;
import onevz.soe.cart.model.elasticsearch.TypeAheadData;
import onevz.soe.cart.model.initiateValidateDeviceSim.InitiateValidateDeviceSimUIResponse;
import onevz.soe.cart.model.orderConfirmation.CXPOrderConfirm5GVO;
import onevz.soe.cart.model.orderConfirmation.CXPOrderConfirmation5GDataVO;
import onevz.soe.cart.model.retrieveCart.*;
import onevz.soe.cart.model.retrieveCart.ServiceInfo;
import onevz.soe.cart.model.validateCart.CXPValidateCartDataVO;
import onevz.soe.cart.requests.*;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.common.CartInfo;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.cart.util.CommonUtil;
import onevz.soe.exception.SOEError;
import onevz.soe.exception.SOEErrorHolder;
import onevz.soe.omnidl.service.OmniDLService;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.util.*;

import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;


@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { CartServiceTestConfig.class })
public class CartServiceCxpHelper1Test {

	private static final Logger logger = LoggerFactory.getLogger(CartServiceCxpHelper1Test.class);

	@Mock
	private CartServiceCXPServices cxpService;

	@Mock
	Environment environment;

	@Mock
	private CatalogService catalogService;

	@Mock
	CommonUtil commonUtil;

	@InjectMocks
	private CartServiceCxpHelper cxpHelper;
	
	@InjectMocks
	private CartServiceCxpHelper2 cxpHelper2;

	@Autowired
	private ObjectMapper mapper;

	@Mock
	private RedisHelper redisHelper;

	@Mock
	CatalogServiceHelper catalogServiceHelper;

	@Mock
	private RedisHelper2 redisHelper2;

	@Mock
	private RedisHelper3 redisHelper3;

	@Mock
	OmniDLService dlService;

	@Mock
	private CartAEMService cartAEMService;

	@Mock
	SOELoginSessionBean sessionBean;
	@Mock
	FeatureFlagHelper featureFlagHelper;
	@Mock
	ObjectMapper objectMapper;

	@Test
	public void updatePurchaseOrderNoTest1() throws IOException {

		String sampleRequestString = "{\"client\": \"CXP\",\"cartId\":\"bea202a6 - 42 cb - 40 d4 - ac87 - d3f1db2b3f13\",\"intendType\": \"EUP\",\"itemType\": \"UPDATECART\" ,\"purchaseOrderNumber\": \"545566826384\"}";
		UpdatePurchaseOrderUIRequest UIRequest = mapper.readValue(sampleRequestString,UpdatePurchaseOrderUIRequest.class);
		Mono<UpdatePurchaseOrderCXPResponse> CXPResponse = null;
		when(cxpService.updatePurchaseOrderNo(Mockito.any())).thenReturn(CXPResponse);
		Mono<UpdatePurchaseOrderUIResponse> respMono = cxpHelper2.updatePurchaseOrderNo(UIRequest);
		StepVerifier.create(respMono).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void macAddressTest1() throws IOException, SOEHTTPException {

		String sampleRequestString = "{\"cartId\":\"bea202a6 - 42 cb - 40 d4 - ac87 - d3f1db2b3f13\",\"intendType\":\"EUP\",\"data\":{\"cartId\":\"bea202a6-42cb-40d4-ac87-d3f1db2b3f14\",\"intendType\":\"EUP\",\"lines\":[{\"mtn\":\"5467851254\",\"macAddress\":\"FC6257934C18\"}]}}";
		MacAddressUIRequest sampleUIRequest = null;
		sampleUIRequest = mapper.readValue(sampleRequestString, MacAddressUIRequest.class);
		Mono<MacAddressCXPResponse> sampleResponseMono = null;
		when(cxpService.updateMacAddress(Mockito.any())).thenReturn(sampleResponseMono);
		Mono<MacAddressUIResponse> respMono = cxpHelper2.updateMacAddress(sampleUIRequest);
		StepVerifier.create(respMono).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateTradeinTypeTest1() throws IOException, SOEHTTPException {

		String sampleRequestString = "{                        \"client\": \"CXP\",                       \"cartId\": \"bea202a6-42cb-40d4-ac87-d3f1db2b3f13\",                                \"intendType\": \"AAL\",                                \"tradeInType\": \"HOME\"        }";
		UpdateTradeinTypeUIRequest sampleRequest = null;
		sampleRequest = mapper.readValue(sampleRequestString, UpdateTradeinTypeUIRequest.class);
		Mono<UpdateTradeinTypeCXPResponse> sampleResponseMono = null;
		when(cxpService.updateTradeinType(Mockito.any())).thenReturn(sampleResponseMono);
		Mono<UpdateTradeinTypeUIResponse> respMono = cxpHelper2.updateTradeinType(sampleRequest);
		StepVerifier.create(respMono).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void retrieveURCForCartTest1() throws JsonParseException, JsonMappingException, IOException {

		String sampleRequestString = "{\"cartId\":\"b38b97bb-db7d-448c-b087-924cb8d8e8b8\",\"mtnList\":[\"2153788055\"],\"fullRetailPricing\":false,\"twoYearPricing\":false,\"monthlyPricing\":false}";
		RetrieveURCForCartUIRequest request = mapper.readValue(sampleRequestString, RetrieveURCForCartUIRequest.class);
		Mono<RetrieveURCForCartCXPResponse> sampleCXPResponseMono = null;
		when(cxpService.retrieveURCForCart(Mockito.any())).thenReturn(sampleCXPResponseMono);
		Mono<RetrieveURCForCartUIResponse> UIResponse = cxpHelper.retrieveURCForCart(request);
		logger.debug("cxpResponse " + UIResponse);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void calculateMultiLineTaxForCartTest1() throws JsonParseException, JsonMappingException, IOException {

		String sampleUIRequestString = "{\"cartId\":\"fbcda2fc-41a4-41d7-a8fa-037fb4144de4\",\"zipCode\":\"08831\"}";
		CalculateMultilineTaxUIRequest sampleRequest = null;
		sampleRequest = mapper.readValue(sampleUIRequestString, CalculateMultilineTaxUIRequest.class);
		Mono<CalculateMultilineTaxCXPResponse> sampleResponseMono = null;
		when(cxpService.calculateMultiLineTaxForCart(Mockito.any())).thenReturn(sampleResponseMono);
		Mono<CalculateMultilineTaxUIResponse> respMono = cxpHelper.calculateMultiLineTaxForCart(sampleRequest);
		StepVerifier.create(respMono).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void validateBYODToolTest1() throws JsonParseException, JsonMappingException, IOException {

		String sampleCXPRequestString ="{\"deviceId\":\"352530085081859\"}";
		ValidateBYODToolCXPRequest sampleRequest = null;
		sampleRequest = mapper.readValue(sampleCXPRequestString, ValidateBYODToolCXPRequest.class);
		Mono<ValidateBYODToolCXPResponse> sampleResponseMono =null;
		when(cxpService.validateBYODTool(Mockito.any())).thenReturn(sampleResponseMono);
		Mono<ValidateBYODToolUIResponse> respMono = cxpHelper.validateBYODTool(sampleRequest);
		StepVerifier.create(respMono).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void retrieve5GValidateCartTest() throws JsonProcessingException, IOException {
		String cxpResponse="{\"meta\":{\"timestamp\":1648039132342,\"cxpCorrelationId\":\"2022-03-23T12:38:52.+0000:a4e470f0-b6b5-4dd0-aa56-dba2aab5c694:cxp-shopping-services-qa-ev6v-sit3e-nscxp-f9d9d48ff-d96sv:nssit3\"},\"data\":{\"validateCartAndUpdate\":{\"ecpdProfile\":{\"profileId\":\"707052\",\"accessoryDiscount\":\"25\",\"ecpdLiabilityTypeCode\":\"E\",\"activationWaiveDesc\":\"No Waiver\",\"custFacingAccDiscount\":\"0\",\"profileName\":\"UAT3TEST - 707052\",\"businessAddress\":{\"addressLine1\":\"1 VERIZON PL\",\"city\":\"ALPHARETTA\",\"state\":\"GA\",\"zipCode\":\"30004\"},\"accountRules\":{\"accessoryShippingInfo\":{\"defaultShippingCode\":\"SHP002\",\"defaultShippingCost\":\"0\",\"defaultShippingDescription\":\"2 DAY SHIP BY 8PM\",\"defaultShippingType\":\"Standard Shipping\",\"preferredShipper\":\"DEFAULT\",\"shippingOptions\":[{\"shipper\":\"DEFAULT\",\"shippingCode\":\"SHP004\",\"shippingCost\":\"12.99\",\"shippingDescription\":\"NEXT DAY BY 8PM\",\"shippingType\":\"Standard Overnight Shipping\"},{\"shipper\":\"DEFAULT\",\"shippingCode\":\"SHP006\",\"shippingCost\":\"19.99\",\"shippingDescription\":\"SATURDAY SHIP BY 12PM\",\"shippingType\":\"Saturday Shipping\"},{\"shipper\":\"DEFAULT\",\"shippingCode\":\"SHP005\",\"shippingCost\":\"14.99\",\"shippingDescription\":\"PRIORITY OVERNIGHT BY 12PM\",\"shippingType\":\"Priority Overnight Shipping\"},{\"shipper\":\"DEFAULT\",\"shippingCode\":\"SDD_SAMEDAY\",\"shippingCost\":\"0\",\"shippingDescription\":\"SDD SHIPPING\",\"shippingType\":\"Same Day Shipping\"},{\"shipper\":\"DEFAULT\",\"shippingCode\":\"SHP004\",\"shippingCost\":\"12.99\",\"shippingDescription\":\"NEXT DAY BY 8PM\",\"shippingType\":\"Standard Overnight Shipping\"},{\"shipper\":\"DEFAULT\",\"shippingCode\":\"SHP006\",\"shippingCost\":\"19.99\",\"shippingDescription\":\"SATURDAY SHIP BY 12PM\",\"shippingType\":\"Saturday Shipping\"},{\"shipper\":\"DEFAULT\",\"shippingCode\":\"SHP005\",\"shippingCost\":\"14.99\",\"shippingDescription\":\"PRIORITY OVERNIGHT BY 12PM\",\"shippingType\":\"Priority Overnight Shipping\"},{\"shipper\":\"DEFAULT\",\"shippingCode\":\"SDD_SAMEDAY\",\"shippingCost\":\"0\",\"shippingDescription\":\"SDD SHIPPING\",\"shippingType\":\"Same Day Shipping\"}]}}},\"cartId\":\"dfd05c21-532a-4ab4-a05e-a9aebb7c7036\",\"cartHeader\":{\"vendorId\":\"VZWCOM\",\"d2dFlag\":\"N\",\"sourceSystem\":\"VZW-DOTCOM\",\"cartId\":\"dfd05c21-532a-4ab4-a05e-a9aebb7c7036\",\"fullAccountNumber\":\"0287302241-1\",\"status\":\"A\",\"createTimestamp\":\"2022-03-23T08:38:26.991403-04:00[US/Eastern]\",\"lastUpdateTimestamp\":\"2022-03-23T08:39:01.012877-04:00[US/Eastern]\",\"cartCreator\":\"3306214504\",\"cartCreatorChannelId\":\"VZW-DOTCOM\",\"cartCreatorOrderLocationCode\":\"N833301\",\"cartCreatorSalesRepId\":\"ETS09\",\"caseId\":\"SOP-7273461-E01\",\"visionCustomerType\":\"PE\",\"maverickLocation\":false,\"preConfiguredCartType\":\"BAU\",\"preConfiguredCartTypeDuringAddDevice\":\"BAU\",\"isCoreRep\":false,\"isERTRep\":false},\"orderDetails\":{\"totalUpgradeFee\":0.0,\"totalDeviceDollar\":0.0,\"totalRemainingDeviceDollar\":0.0,\"totalUsedDeviceDollar\":0.0,\"totalAccountLevelAccCost\":0.0,\"totalAccountLevelAccCostWithTax\":0.0,\"verizonCardPromoOfferList\":[],\"taxDetailsList\":[],\"subTotalDueTodayWithoutUpgradeFee\":0.0,\"subTotalDueMonthlyForAALBYODEUP\":50.0,\"shipTogetherPref\":true,\"assistanceOptedByCustomer\":false,\"totalVerizonDollarUsed\":\"0.0\",\"isShellAccountSelected\":false,\"guestOrInactiveRefundLines\":false,\"totalDueMonthlyOnProfile\":0.0,\"subTotalDueMonthlyOnProfile\":0.0,\"totalMonthlyTaxesOnProfile\":0.0,\"subTotalOtherLinesOnProfile\":0.0,\"estimatedNextMonthChargeOnProfile\":0.0,\"totalDueMonthlyAfterDiscounts\":0.0,\"totalActivationFees\":0.0,\"orderType\":\"PS\",\"locationCode\":\"N833301\",\"customerType\":\"E\",\"billingSystem\":\"VN\",\"totalTaxAmount\":\"0.0\",\"totalDueToday\":0.0,\"totalDueMonthly\":50.0,\"subTotalDueMonthly\":50.0,\"subTotalDueToday\":0.0,\"subTotalMonthlyTaxes\":0.0,\"estimatedNextMonthCharge\":67.74,\"totalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"orderChannelId\":\"VZW-DOTCOM\",\"orderList\":[{\"creditApplication\":{\"creditApplicationNum\":745920391,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CA CVAS AUTOMATIC APPROVAL\",\"internationalEligibility\":false,\"creditAdvisory\":\"APP 745920391 APPROVED  - WITH NO DEPOSIT REQUIRED 'B '\",\"securityDepositAmount\":\"0\",\"serviceClass\":\"B\",\"lineCreditClass\":\"1D\"},\"orderActivityType\":\"AAL\",\"orderNumber\":3101217,\"numOfLinesForOrderActivityType\":1,\"preOrderNumber\":0,\"managerApprovalRequired\":false}],\"outletId\":\"000124648\",\"registerNumber\":\"0\",\"saleType\":\"P\",\"salesRepId\":\"ETS09\",\"enableSplitShipment\":false,\"splitShipmentIndicator\":false,\"cartReadyForCheckout\":true,\"isSingleModConnectedDevice\":false,\"fiveGUpSellAccountLevel\":false,\"customerOnTrialPlan\":false,\"availableSlotsForGrantee\":\"0\",\"totalDownPaymentAmt\":0.0,\"totalEdgeBuyOutAmount\":0.0,\"expressCheckout\":false,\"isEQPandPPLOfferApplied\":false,\"cartTotalDiscounts\":{\"totalDiscount\":\"0.0\",\"discountDetails\":[]},\"memberTotalDueToday\":0.0,\"eligible5GHomeBundle\":[],\"customerConsent\":\"N\",\"totalDwosCost\":\"0.0\",\"billingState\":\"OH\",\"isTradeInOfferSelected\":false},\"lineDetails\":{\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"AAL\",\"totalDueToday\":0.0,\"totalDueTodayWithoutTax\":0.0,\"totalDueMonthly\":50.0,\"mobileNumber\":\"newLine1\",\"serviceInfo\":{\"pairingInfo\":{},\"planDiscount\":{\"planEligibleForAutoPayPaperLessDiscount\":true,\"eligibleAutoPayPaperlessDiscount\":\"10.0\",\"discountIncluded\":false,\"totalPlanCostIncludingLineAccessFee\":\"60.0\"},\"otherPromotions\":[],\"primaryUserInfo\":{\"firstName\":\"RAVI\",\"lastName\":\"MANNING\",\"address\":{\"firmName\":\"\",\"apartmentNo\":\"A\",\"type\":\"AVE\",\"streetNumber\":\"682\",\"streetName\":\"KATHERINE\",\"addressLine2\":\"\",\"addressLine1\":\"682 KATHERINE AVE APT A\",\"poBoxNo\":\"\",\"ruralRouteNo\":\"\",\"ruralDelNo\":\"\",\"city\":\"ASHLAND\",\"state\":\"OH\",\"zipCode\":\"44805\",\"zipCode4\":\"3613\",\"county\":\"\",\"countryCode\":\"\",\"fipsCode\":\"3900502568\",\"firstName\":\"RAVI\",\"lastName\":\"MANNING\",\"emailId\":\"TZIIRHLMNZIOZ53@VZW.COM\",\"phoneNumber\":\"1101587107\",\"streetType\":\"AVE\",\"streetDirection\":\"\"},\"isValidAddress\":true,\"bsnsName\":\"\",\"emailId\":\"TZIIRHLMNZIOZ53@VZW.COM\"},\"cart5GAddress\":{\"streetNumber\":\"4808\",\"streetName\":\"CHENEVERT\",\"addressLine2\":\"A\",\"addressLine1\":\"4808 CHENEVERT ST\",\"city\":\"HOUSTON\",\"state\":\"TX\",\"zipCode\":\"77004\",\"zipCode4\":\"\",\"countryCode\":\"\",\"fipsCode\":\"4820135000\",\"streetType\":\"ST\",\"floor\":0},\"mtn\":\"newLine1\",\"newPricePlanId\":\"50127\",\"contractTermId\":\"48\",\"newPricePlanInfo\":{\"pricePlanCategory\":\"N\",\"ratePlanType\":\"L\",\"accessFeeRange\":\"75\",\"categoryCode\":\"74\",\"contractRange\":\"-1\",\"contractDuration\":0,\"pricePlanCode\":\"50127\",\"pricePlanDesc\":\"5G HOME\",\"contractTermId\":\"48\",\"imageUrlMap\":{},\"planPrice\":60.0},\"selectedFeaturesList\":{\"featuresCount\":22,\"visFeature\":[{\"displayReceiptIndicator\":\"\",\"visFeatureCode\":\"48526\",\"featureDesc\":\"TXT MSG W PER MSG CHARGES\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"Y\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"MI\",\"protection\":false,\"callFilter\":false,\"conflictMessage\":\"\",\"declinedProtection\":false,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216\"},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"\",\"visFeatureCode\":\"48553\",\"featureDesc\":\"STREAMLINED BILLING - $0\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"Y\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"BL\",\"protection\":false,\"callFilter\":false,\"conflictMessage\":\"\",\"declinedProtection\":false,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216\"},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"\",\"visFeatureCode\":\"54307\",\"featureDesc\":\"BLOCK TEXT MESSAGING\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"Y\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"MS\",\"protection\":false,\"callFilter\":false,\"conflictMessage\":\"Add SFO due to missing DACC SFO Sequence\",\"declinedProtection\":false,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Messaging_012918\"},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"\",\"visFeatureCode\":\"68872\",\"featureDesc\":\"CALL DELIVERY\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"Y\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"BF\",\"protection\":false,\"callFilter\":false,\"conflictMessage\":\"\",\"declinedProtection\":false,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216\"},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"\",\"visFeatureCode\":\"70421\",\"featureDesc\":\"BLOCK VOICE-HOTLN (PKT DATA)\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"Y\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"HT\",\"protection\":false,\"callFilter\":false,\"conflictMessage\":\"\",\"declinedProtection\":false,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216\"},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"\",\"visFeatureCode\":\"78003\",\"featureDesc\":\"4G BLOCK DATA ROAM (M)\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"Y\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"VS\",\"protection\":false,\"callFilter\":false,\"conflictMessage\":\"\",\"declinedProtection\":false,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216\"},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"\",\"visFeatureCode\":\"83856\",\"featureDesc\":\"CDMA-LESS DEVICE PROVISIONING\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"Y\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"TP\",\"protection\":false,\"callFilter\":false,\"conflictMessage\":\"Add SFO due to missing DACC SFO Sequence\",\"declinedProtection\":false,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216\"},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"\",\"visFeatureCode\":\"85503\",\"featureDesc\":\"UNLIMITED DATA\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"Y\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"DT\",\"protection\":false,\"callFilter\":false,\"conflictMessage\":\"\",\"declinedProtection\":false,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Data_012918\"},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"\",\"visFeatureCode\":\"86112\",\"featureDesc\":\"5G IPV4/IPV6 IP\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"Y\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"TP\",\"protection\":false,\"callFilter\":false,\"conflictMessage\":\"Add SFO due to missing DACC SFO Sequence\",\"declinedProtection\":false,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216\"},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"\",\"visFeatureCode\":\"86926\",\"featureDesc\":\"5G LINE OF SERVICE\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"Y\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"TP\",\"protection\":false,\"callFilter\":false,\"conflictMessage\":\"Add SFO due to missing DACC SFO Sequence\",\"declinedProtection\":false,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216\"},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"\",\"visFeatureCode\":\"86928\",\"featureDesc\":\"5G DATA TRANSPORT\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"Y\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"TP\",\"protection\":false,\"callFilter\":false,\"conflictMessage\":\"\",\"declinedProtection\":false,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216\"},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"\",\"visFeatureCode\":\"87800\",\"featureDesc\":\"LTE PROVISIONING\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"Y\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"TP\",\"protection\":false,\"callFilter\":false,\"conflictMessage\":\"\",\"declinedProtection\":false,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216\"},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"\",\"visFeatureCode\":\"88685\",\"featureDesc\":\"RTR PROVISIONING\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"Y\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"TP\",\"protection\":false,\"callFilter\":false,\"conflictMessage\":\"\",\"declinedProtection\":false,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216\"},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"\",\"visFeatureCode\":\"88855\",\"featureDesc\":\"HSS PROVISIONING\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"Y\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"TP\",\"protection\":false,\"callFilter\":false,\"conflictMessage\":\"\",\"declinedProtection\":false,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216\"},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"\",\"visFeatureCode\":\"88966\",\"featureDesc\":\"5G INTERNET ACCESS\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"Y\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"TP\",\"protection\":false,\"callFilter\":false,\"conflictMessage\":\"\",\"declinedProtection\":false,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216\"},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"visFeatureCode\":\"671\",\"featureDesc\":\"Carryover Data\",\"addDeleteInd\":\"Z\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"A\",\"type\":\"SPO\",\"featurePrice\":\"0.00\",\"source\":\"EXISTING\",\"protection\":false,\"callFilter\":false,\"conflictMessage\":\"\",\"declinedProtection\":false,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Carry_Over_021618\"},\"featureDiscounts\":[],\"categoryCodes\":[\"ADS\",\"DATABANK\"],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"visFeatureCode\":\"672\",\"featureDesc\":\"Safety Mode\",\"addDeleteInd\":\"Z\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"A\",\"type\":\"SPO\",\"featurePrice\":\"0.00\",\"source\":\"EXISTING\",\"protection\":false,\"callFilter\":false,\"conflictMessage\":\"\",\"declinedProtection\":false,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Safety_Mode_021618\"},\"featureDiscounts\":[],\"categoryCodes\":[\"ADS\",\"SAFETYMODE\"],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"visFeatureCode\":\"732\",\"featureDesc\":\"CDMA-LESS ROAM TIER OVERRIDE\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"Y\",\"level\":\"L\",\"type\":\"SPO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"protection\":false,\"callFilter\":false,\"conflictMessage\":\"\",\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[\"TP\"],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"visFeatureCode\":\"1508\",\"featureDesc\":\"30 Day Free Setup Support\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"Y\",\"level\":\"L\",\"type\":\"SPO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"protection\":false,\"callFilter\":false,\"conflictMessage\":\"\",\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[\"5GHOMESUP\",\"MI\"],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"visFeatureCode\":\"2155\",\"featureDesc\":\"Loyalty Discount\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"Y\",\"level\":\"L\",\"type\":\"SPO\",\"featurePrice\":\"-10.00\",\"source\":\"FOM\",\"protection\":false,\"callFilter\":false,\"conflictMessage\":\"\",\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[\"BYPVREQUAL\",\"SRVCDISC\",\"DISCPROMO\",\"EBBBEFORE\",\"PLANDISC\",\"BYPGRPQUAL\",\"BYPGRPREQL\",\"BYPPVQUAL\",\"5GBUNDLE\",\"5GLOYALTY\"],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"visFeatureCode\":\"2161\",\"featureDesc\":\"Service ID Indicator 5G C-band\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"Y\",\"level\":\"L\",\"type\":\"SPO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"protection\":false,\"callFilter\":false,\"conflictMessage\":\"\",\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[\"SERVICEID\",\"MI\"],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"visFeatureCode\":\"2195\",\"featureDesc\":\"2 YEAR PRICE GUARANTEE\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"Y\",\"level\":\"L\",\"type\":\"SPO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"protection\":false,\"callFilter\":false,\"conflictMessage\":\"\",\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[\"MI\"],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false}]},\"planDetails\":{\"planPrice\":60.0,\"planDiscounts\":[]},\"correlationID\":\"192000000001794272\",\"currentDevice\":{},\"isSharePlanAdded\":false,\"mea\":\"A05\",\"dacc\":\"01598\",\"isE911AddressValidated\":false,\"isFreeAppleMusicLoss\":\"N\",\"newBgsa\":\"978\",\"newPlanFlag\":\"L\",\"orderDevice\":{\"lteVoraEquipInfo\":{\"lteEqpt\":{},\"lteVoraDeviceInfo\":{\"deviceType\":\"5GE\"}}},\"kidsPlanParentMtn\":false,\"mcsSubscription\":[],\"fiveGUpSell\":false,\"e911AddressSameAsServiceAddress\":false,\"unpairedGrantor\":false,\"hasVerizonCloudUnlimitedIncluded\":false},\"itemsInfo\":[{\"depletionType\":\"O\",\"attention\":\"RAVI MANNING\",\"shipping\":{\"address\":{\"apartmentNo\":\"A\",\"type\":\"R\",\"streetNumber\":\"682\",\"streetName\":\"KATHERINE\",\"addressLine2\":\"\",\"addressLine1\":\"682 KATHERINE AVE APT A\",\"city\":\"ASHLAND\",\"state\":\"OH\",\"zipCode\":\"44805\",\"zipCode4\":\"3613\",\"county\":\"\",\"countryCode\":\"\",\"fipsCode\":\"3900502568\",\"firstName\":\"RAVI\",\"lastName\":\"MANNING\",\"emailId\":\"TZIIRHLMNZIOZ53@VZW.COM\",\"phoneNumber\":\"1101587107\",\"streetType\":\"AVE\",\"streetDirection\":\"\"},\"cbrPhone\":\"1101587107\",\"firstName\":\"RAVI\",\"lastName\":\"MANNING\",\"midInitials\":\"\",\"isUseUnVerifiedAddress\":false,\"isValidAddress\":false,\"email\":\"TZIIRHLMNZIOZ53@VZW.COM\"},\"fipsCode\":\"3900502568\",\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"discountAmount\":0.0,\"deviceDollarApplied\":0.0,\"itemPriceOnDeviceDollarApplied\":0.0,\"promoHubOfferList\":{\"promoHubOfferList\":[],\"offerCount\":0},\"qrScanNeededForEsimActivation\":false,\"isPreconfigureDuringAddDevice\":false,\"deviceDisplayName\":\"VZ INTERNET GATEWAY ASK-NCQ1338\",\"accessoryGiftCardAmount\":0.0,\"tradeInAmountTowardsUserDPUsed\":0.0,\"sorDeviceCategory\":\"5G Router\",\"sorDeviceType\":\"5GE\",\"operatingSystem\":\"Linux\",\"vendingKioskItem\":\"false\",\"tradeInAutoPull\":false,\"priceAdjustment\":false,\"priceAdjustmentQty\":0,\"newPurchasedQty\":0,\"canonicalUrl\":\"internet-devices/verizon-internet-gateway/\",\"networkBandwidthType\":\"CBD\",\"selectedForRFEX\":false,\"selectedForPAD\":false,\"bogoItem\":false,\"refxItemSeqNum\":0,\"restrictedAccySku\":false,\"maxAccyPurchaseLimit\":false,\"itemCode\":\"ASK-NCQ1338\",\"totalPriceWithDiscount\":0.0,\"sorId\":\"ASK-NCQ1338\",\"skuId\":\"sku4390060\",\"cartItemType\":\"DEVICE\",\"mobileNumber\":\"newLine1\",\"description\":\"Verizon Internet Gateway\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":\"0.0\",\"discountedPercentage\":0.0,\"discountedPrice\":0.0,\"buyOutTaxAmountUnbilled\":0.0,\"buyOutAmountWithoutTax\":0.0,\"taxAmount\":0.0,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/vzw-internet-gateway-askey-titan-i-router-white-ask-ncq1338\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/vzw-internet-gateway-askey-titan-i-router-white-ask-ncq1338?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/vzw-internet-gateway-askey-titan-i-router-white-ask-ncq1338?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/vzw-internet-gateway-askey-titan-i-router-white-ask-ncq1338?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/vzw-internet-gateway-askey-titan-i-router-white-ask-ncq1338?$device-thumb$\"},\"prodCode1\":\"5GD\",\"prodCode2\":\"NIC\",\"prodCode3\":\"5IR\",\"prodCode4\":\"B2B\",\"prodCode5\":\"4GH\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"depletionType\":\"O\",\"catalogPrice\":0.0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"color\":{\"color\":\"#F9F8F3\",\"colorDisplayName\":\"WHITE\"},\"unitTaxBasedPrice\":0.0,\"itemNrpPrice\":0.0,\"itemCost\":0.0,\"upgradeReasonCode\":\"\",\"upgradeReasonDesc\":\"Invalid Reason Code - 0yr\",\"itemPriceType\":\"R\",\"discounts\":[],\"availableReasonCode\":[],\"inventory\":{\"isAvailable\":true,\"isBackorder\":false,\"isDeliverBy\":false,\"isPreOrder\":false,\"qtyAvailable\":69893},\"isCustomerProvidedSIM\":false,\"sedOfferList\":{\"sedOffer\":[{\"offerId\":\"204326\",\"description\":\"UAT CUSTOMERS WHO PURCHASE 5G HOME INTERNET GET ONE TITAN 1 DEVICE FOR FREE FRP - ALL CHANNELS\",\"offerType\":\"ITP\",\"discAmt\":\"0.00\",\"discPrcnt\":0,\"priceInfo\":{\"basePriceUsed\":\"Y\"},\"rebatesAllowed\":\"N\",\"itemMonthlyDiscount\":0.0,\"itemMonthlyDiscountedPrice\":0.0,\"discountedRetailPrice\":0.0,\"itemMonthlyRetailPrice\":0.0,\"promoBadges\":[{\"badgeText\":\"Congratulations, you're saving on this device.\",\"placement\":\"ITEM-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"CART\",\"promoOverlayEnable\":false}]}],\"count\":0},\"isNetworkExtender\":false,\"ispuEligible\":true,\"itemSeqNum\":1,\"sddEligible\":true,\"smartIMEI\":false,\"year\":0,\"sellerPrice\":\"0.0\",\"edgeDeviceCap\":\"240\",\"productId\":\"dev15280028\",\"numberShareCapabilityInfo\":{\"sorHdVoiceInd\":false,\"isNumberShareCapable\":false,\"isNumberShareMandatory\":false},\"taxDetailsList\":[],\"hasDeviceUnlockPolicy\":false,\"manufacturer\":\"Askey\",\"iconicPhone\":false,\"ringBell\":false,\"isPreconfigureEnabled\":false,\"isHumDevice\":false,\"isSmartLocator\":false,\"isSecurityAlarm\":false,\"isMotoMod\":false,\"isConnectedCar\":false,\"accountLevelAccessory\":false,\"byodESimPhone\":false,\"appleCareAccessoryFlag\":false},{\"discountAmount\":0.0,\"deviceDollarApplied\":0.0,\"promoHubOfferList\":{\"promoHubOfferList\":[],\"offerCount\":0},\"qrScanNeededForEsimActivation\":false,\"isPreconfigureDuringAddDevice\":false,\"accessoryGiftCardAmount\":0.0,\"tradeInAmountTowardsUserDPUsed\":0.0,\"vendingKioskItem\":\"false\",\"tradeInAutoPull\":false,\"priceAdjustment\":false,\"priceAdjustmentQty\":0,\"newPurchasedQty\":0,\"selectedForRFEX\":false,\"selectedForPAD\":false,\"bogoItem\":false,\"refxItemSeqNum\":0,\"restrictedAccySku\":false,\"maxAccyPurchaseLimit\":false,\"itemCode\":\"EMBDSIM5G\",\"totalPriceWithDiscount\":0.0,\"sorId\":\"EMBDSIM5G\",\"cartItemType\":\"SIM\",\"description\":\"Virtual 4G 5G Interim SIM\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":\"0.0\",\"discountedPercentage\":0.0,\"discountedPrice\":0.0,\"buyOutTaxAmountUnbilled\":0.0,\"buyOutAmountWithoutTax\":0.0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":2,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0,\"sellerPrice\":\"0.0\",\"taxDetailsList\":[],\"iconicPhone\":false,\"ringBell\":false,\"isPreconfigureEnabled\":false,\"isHumDevice\":false,\"isSmartLocator\":false,\"isSecurityAlarm\":false,\"isMotoMod\":false,\"isConnectedCar\":false,\"accountLevelAccessory\":false,\"byodESimPhone\":false,\"appleCareAccessoryFlag\":false},{\"discountAmount\":0.0,\"deviceDollarApplied\":0.0,\"promoHubOfferList\":{\"promoHubOfferList\":[],\"offerCount\":0},\"qrScanNeededForEsimActivation\":false,\"isPreconfigureDuringAddDevice\":false,\"accessoryGiftCardAmount\":0.0,\"tradeInAmountTowardsUserDPUsed\":0.0,\"vendingKioskItem\":\"false\",\"tradeInAutoPull\":false,\"priceAdjustment\":false,\"priceAdjustmentQty\":0,\"newPurchasedQty\":0,\"selectedForRFEX\":false,\"selectedForPAD\":false,\"bogoItem\":false,\"refxItemSeqNum\":0,\"restrictedAccySku\":false,\"maxAccyPurchaseLimit\":false,\"itemCode\":\"WAR6002\",\"totalPriceWithDiscount\":0.0,\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":\"0.0\",\"discountedPercentage\":0.0,\"discountedPrice\":0.0,\"buyOutTaxAmountUnbilled\":0.0,\"buyOutAmountWithoutTax\":0.0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":3,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0,\"sellerPrice\":\"0.0\",\"taxDetailsList\":[],\"iconicPhone\":false,\"ringBell\":false,\"isPreconfigureEnabled\":false,\"isHumDevice\":false,\"isSmartLocator\":false,\"isSecurityAlarm\":false,\"isMotoMod\":false,\"isConnectedCar\":false,\"accountLevelAccessory\":false,\"byodESimPhone\":false,\"appleCareAccessoryFlag\":false}]},\"isPromoSelected\":false,\"isTradeInSelected\":false,\"taxExemptionTypes\":\"\"}],\"assignMTNIndicator\":\"Y\",\"mtnDetails\":{\"dummyMTNForDomain\":\"0621450401\",\"lineNumber\":\"newLine1\",\"mobileNumber\":\"0000000000\",\"assignMTNTimestamp\":\"2022-03-23T08:38:39.771308-04:00[US/Eastern]\",\"npaNXX\":\"419512\"},\"lineNumber\":\"newLine1\",\"oneTimeCharges\":[{\"chargeType\":\"ActivationFee\",\"amount\":0.0,\"finalPrice\":\"0.0\"}],\"fiveGToFourGDownGrade\":false,\"deviceTypeSelected\":\"5G Router\",\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"lineCreator\":\"3306214504\",\"lineRefundTotal\":0.0,\"lineExchangeTotal\":0.0,\"totalDueMonthlyBeforeCredit\":0.0,\"isCpe\":false,\"isLTEHomeLine\":true,\"isDevicePlanCompatible\":true,\"portinMtnAssignment\":false,\"impactedLine\":false,\"preOrBackOrder\":false,\"ispuItem\":false,\"ispuItemBYOD\":false,\"isModConnected\":false,\"modDevice\":false,\"byodCapable\":false,\"isCarLine\":false,\"buySimOnly\":false,\"broadBandInd\":false,\"protectionNotRequired\":false}],\"numOfAccessoryAndDeviceItemsInCart\":1,\"totalEdgeUpAmount\":0.0,\"totalEdgeBuyOutAmount\":0.0,\"totalDownPaymentAmt\":0.0,\"subscriptionInfos\":[],\"numOfLines\":1,\"numofLinesAAL\":1,\"numofLinesEUP\":0,\"payments\":[],\"lineSeq\":0,\"vlcactivePhoneCount\":0,\"fivegOrderind\":false,\"aceOrderCreated\":true,\"serviceLinesCreated\":false,\"aceItemsModified\":true,\"clnrOrderFlag\":false,\"broadbandInd\":false,\"acctMcsSubscription\":[],\"spendingLimitAmountExceededBy\":\"0.0\",\"numofAccessories\":0,\"subAccountNBSInfo\":[{\"billAccounts\":[{\"billSummary\":{\"grandTotal\":{\"newMonthCharge\":\"50.00\",\"nextMonthCharge\":\"67.74\"},\"planCharge\":{\"newMonthCharge\":\"60.00\",\"nextMonthCharge\":\"81.29\"},\"lineAccessFees\":{\"newMonthCharge\":\"0.00\",\"nextMonthCharge\":\"0.00\"},\"devicePayments\":{\"newMonthCharge\":\"0.00\",\"nextMonthCharge\":\"0.00\"},\"surcharges\":{\"newMonthCharge\":\"0.00\",\"nextMonthCharge\":\"0.00\"},\"taxesAndFees\":{\"newMonthCharge\":\"0.00\",\"nextMonthCharge\":\"0.00\"},\"totalAddOns\":{\"newMonthCharge\":\"0.00\",\"nextMonthCharge\":\"0.00\"},\"appleMusic\":{\"newMonthCharge\":\"0.00\",\"nextMonthCharge\":\"0.00\"},\"mobileProtection\":{\"newMonthCharge\":\"0.00\",\"nextMonthCharge\":\"0.00\"},\"planAccessFeeTotal\":{\"newMonthCharge\":\"60.00\",\"nextMonthCharge\":\"81.29\"},\"taxGrandTotal\":{\"newMonthCharge\":\"0.00\",\"nextMonthCharge\":\"0.00\"},\"subTotal\":{\"newMonthCharge\":\"50.00\",\"nextMonthCharge\":\"67.74\"},\"autoPayDiscount\":{\"accountTotalAutoPayDiscount\":\"0.00\",\"isCustomerEnrolledForAutopay\":false},\"dateRange\":{\"thisMonth\":\"03/03/2022-04/02/2022\",\"nextMonth\":\"04/03/2022-05/02/2022\"}},\"nbs\":{\"accountNumber\":\"0287302241-00001\",\"nextBillCycleStartDate\":\"04/03/2022\",\"balancePastDue\":{\"pastDueAmount\":\"0.00\",\"paymentsReceived\":\"0\",\"previousBalance\":\"69.30\",\"balanceType\":\"Current Balance\",\"unbilledPayment\":\"-69.30\",\"totUnpaidBalance\":\"0.00\",\"paymentMessage\":\"You've paid your bill amount of  $69.30. Thank you!\",\"unbilledOCC\":\"0.00\"},\"monthlyChargesInfo\":{\"accountLevelCharges\":[],\"accountLevelTotal\":{\"thisMonthCharge\":\"0.00\",\"nextMonthCharge\":\"0.00\",\"differenceBetweenThisMonthAndNextMonthCharge\":\"0.00\",\"totalOneTimeCharge\":\"0.00\",\"newMonthMrcWithNoAddOn\":\"0.00\",\"nextMonthMrcWithNoAddOn\":\"0.00\",\"nextMonthAcctLevelSurcharges\":\"0.00\",\"newMonthAcctLevelSurcharges\":\"0.00\",\"nextMonthAccountLevelTax\":\"0.00\",\"newMonthAccountLevelTax\":\"0.00\",\"chargeTotals\":[{\"itemRef\":\"Total Addons\",\"differenceBetweenThisAndNextMonthCharge\":\"0.00\",\"thisMonthCharge\":\"0.00\",\"nextMonthCharge\":\"0.00\"}]},\"mtnLevelChargeDetails\":[{\"mtn\":\"0621450401\",\"thisMonthCharge\":\"50.00\",\"nextMonthCharge\":\"67.74\",\"differenceBetweenThisMonthAndNextMonthCharge\":\"17.74\",\"thisMonthSurcharges\":\"0.00\",\"previousMonthCharge\":\"0.00\",\"nextMonthSurcharges\":\"0.00\",\"differenceBetweenThisMonthAndNextMonthSurcharges\":\"0.00\",\"thisMonthTax\":\"0.00\",\"nextMonthTax\":\"0.00\",\"differenceBetweenThisMonthAndNextMonthTax\":\"0.00\",\"chargeDetails\":[{\"thisMonthCharge\":\"60.00\",\"nextMonthCharge\":\"60.00\",\"chargeRefId\":\"50127\",\"description\":\"5G HOME\",\"itemType\":[{\"accequipment\":false,\"equipment\":false,\"feature\":false,\"naf\":false,\"occ\":false,\"plan\":false,\"promo\":false,\"sfo\":false,\"spo\":false,\"addOn\":false}],\"differenceBetweenThisMonthAndNextMonthCharge\":\"0.00\",\"listPrice\":\"60.00\",\"netPrice\":\"60.00\",\"promo1Id\":\"0\",\"promo1Discount\":\"0.00\",\"promo2Id\":\"0\",\"promo2Discount\":\"0.00\",\"promo3Id\":\"0\",\"promo3Discount\":\"0.00\"},{\"thisMonthCharge\":\"-10.00\",\"nextMonthCharge\":\"-10.00\",\"chargeRefId\":\"2155\",\"description\":\"$10 LOYALTY DISCOUNT\",\"itemType\":[{\"accequipment\":false,\"equipment\":false,\"feature\":false,\"naf\":false,\"occ\":false,\"plan\":false,\"promo\":false,\"sfo\":false,\"spo\":false,\"addOn\":false}],\"differenceBetweenThisMonthAndNextMonthCharge\":\"0.00\",\"listPrice\":\"-10.00\",\"netPrice\":\"-10.00\",\"promo1Id\":\"0\",\"promo1Discount\":\"0.00\",\"promo2Id\":\"0\",\"promo2Discount\":\"0.00\",\"promo3Id\":\"0\",\"promo3Discount\":\"0.00\"}],\"oneTimeChargeDetails\":[{\"thisMonthCharge\":\"21.29\",\"nextMonthCharge\":\"21.29\",\"chargeRefId\":\"50127\",\"description\":\"5G HOME\",\"itemType\":[{\"accequipment\":false,\"equipment\":false,\"feature\":false,\"naf\":false,\"occ\":false,\"plan\":false,\"promo\":false,\"sfo\":false,\"spo\":false,\"addOn\":false}],\"differenceBetweenThisMonthAndNextMonthCharge\":\"0.00\",\"listPrice\":\"21.29\",\"netPrice\":\"21.29\",\"promo1Id\":\"0\",\"promo1Discount\":\"0.00\",\"promo2Id\":\"0\",\"promo2Discount\":\"0.00\",\"promo3Id\":\"0\",\"promo3Discount\":\"0.00\"},{\"thisMonthCharge\":\"-3.55\",\"nextMonthCharge\":\"-3.55\",\"chargeRefId\":\"2155\",\"description\":\"$10 LOYALTY DISCOUNT\",\"itemType\":[{\"accequipment\":false,\"equipment\":false,\"feature\":false,\"naf\":false,\"occ\":false,\"plan\":false,\"promo\":false,\"sfo\":false,\"spo\":false,\"addOn\":false}],\"differenceBetweenThisMonthAndNextMonthCharge\":\"0.00\",\"listPrice\":\"-3.55\",\"netPrice\":\"-3.55\",\"promo1Id\":\"0\",\"promo1Discount\":\"0.00\",\"promo2Id\":\"0\",\"promo2Discount\":\"0.00\",\"promo3Id\":\"0\",\"promo3Discount\":\"0.00\"}],\"nickname\":\"RAVI MANNING\",\"suppressAdvInd\":\"N\",\"newMonthMtnMrcWithNoAddOn\":\"50.00\",\"nextMonthMtnMrcWithNoAddOn\":\"50.00\",\"newMonthGrandTotalWithTaxes\":\"50.00\",\"nextMonthGrandTotalWithTaxes\":\"67.74\",\"chargeTotals\":[{\"itemRef\":\"PPLAN\",\"differenceBetweenThisAndNextMonthCharge\":\"0.00\",\"thisMonthCharge\":\"60.00\",\"nextMonthCharge\":\"60.00\"},{\"itemRef\":\"Total Addons\",\"differenceBetweenThisAndNextMonthCharge\":\"0\"}],\"mtnChangeInd\":false}],\"accountLevelOneTimeCharges\":[]},\"monthlyTotalsInfo\":{\"thisMonthCharge\":\"50.00\",\"thisMonthChargeDateRange\":\"03/03/2022-04/02/2022\",\"nextMonthCharge\":\"67.74\",\"nextMonthChargeDateRange\":\"04/03/2022-05/02/2022\",\"differenceBetweenThisMonthAndNextMonthCharge\":\"17.74\",\"previousCycleFormattedDateRange\":\"Feb 03,2022 - Mar 02,2022\"},\"surchargesInfo\":{\"thisMonthCharge\":0.0,\"nextMonthCharge\":0.0,\"differenceBetweenThisMonthAndNextMonthSurcharges\":\"0.00\"},\"taxesAndFeesInfo\":{\"thisMonthCharge\":0.0,\"nextMonthCharge\":0.0,\"differenceBetweenThisMonthAndNextMonthTax\":\"0.00\"},\"autoPayDiscount\":{\"accountTotalAutoPayDiscount\":\"0.00\",\"isCustomerEnrolledForAutopay\":false},\"barGraphDetails\":{\"invoiceCount\":\"109\",\"invoiceLastMonth\":\"69.30\",\"invoiceLastMonthCycleEnddate\":\"01/02/2022\",\"invoiceTwoMonthPrevious\":\"69.37\",\"invoiceTwoMonthCycleEnddate\":\"12/02/2021\"},\"nbsIndicators\":{\"languageIndicator\":\"E\",\"partialBillIndicator\":\"Y\"}},\"billAccountNo\":\"1\"}]}]},\"refundOrderDetails\":{\"orderNum\":0,\"totalDueToday\":\"0.0\",\"subTotalDueToday\":\"0.0\",\"totalTaxAmount\":\"0.0\",\"creditApplicationNum\":0},\"globalPromotions\":{},\"verizonUpToastMessage\":{\"toastMessages\":[],\"eligibleProducts\":[]},\"cartValidationErrors\":[{\"errorCategory\":\"Cart\",\"errorLevel\":\"Warning\",\"errorCode\":\"1090\",\"errorMessage\":\"Shipping is Required\",\"fieldPath\":\"\"}],\"accountEligibility\":false}}}";
		String cxprequestString = "{\"data\": {\"cartId\": \"\", \"retrieveCurrentFeatures\": true}, \"meta\": {\"type\": \"\"}}";
		ValidateCartCXPResponse sampleCXPResponse = mapper.readValue(cxpResponse, ValidateCartCXPResponse.class);
		when(cxpService.retrieveNSE5GValidateCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleCXPResponse));
		RetrieveCartCXPRequest cxprequest = mapper.readValue(cxprequestString, RetrieveCartCXPRequest.class);
		when(cxpService.retrieve5GValidateCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleCXPResponse));
		Mono<ValidateCartCXPResponse> UIResponse = cxpHelper.retrieve5GValidateCart(cxprequest, null, false);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		sampleCXPResponse.setData(new CXPValidateCartDataVO());
		when(cxpService.retrieve5GValidateCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleCXPResponse));
		cxprequest.getData().setCartId("random");
		StepVerifier.create(cxpHelper.retrieve5GValidateCart(cxprequest, "", false)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void retrieve5GValidateCartTest2() throws JsonProcessingException, IOException {
		String cxpResponse = "{\"meta\":{\"timestamp\":1648039132342,\"cxpCorrelationId\":\"2022-03-23T12:38:52.+0000:a4e470f0-b6b5-4dd0-aa56-dba2aab5c694:cxp-shopping-services-qa-ev6v-sit3e-nscxp-f9d9d48ff-d96sv:nssit3\"},\"data\":null}";
		String cxprequestString = "{\"data\": {\"cartId\": \"cartId\", \"retrieveCurrentFeatures\": true}, \"meta\": {\"type\": \"type\"}}";
		ValidateCartCXPResponse sampleCXPResponse = mapper.readValue(cxpResponse, ValidateCartCXPResponse.class);
		when(cxpService.retrieveNSE5GValidateCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleCXPResponse));
		RetrieveCartCXPRequest cxprequest = mapper.readValue(cxprequestString, RetrieveCartCXPRequest.class);
		when(cxpService.retrieve5GValidateCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleCXPResponse));
		Mono<ValidateCartCXPResponse> UIResponse = cxpHelper.retrieve5GValidateCart(cxprequest, null,false);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void retrieve5GValidateCartTest3() throws JsonProcessingException, IOException {
		String cxpResponse = "{\"meta\":{\"timestamp\":1648039132342,\"cxpCorrelationId\":\"2022-03-23T12:38:52.+0000:a4e470f0-b6b5-4dd0-aa56-dba2aab5c694:cxp-shopping-services-qa-ev6v-sit3e-nscxp-f9d9d48ff-d96sv:nssit3\"},\"data\":null}";
		String cxprequestString = "{\"data\": {\"cartId\": \"cartId\", \"retrieveCurrentFeatures\": true}, \"meta\": {}}";
		ValidateCartCXPResponse sampleCXPResponse = mapper.readValue(cxpResponse, ValidateCartCXPResponse.class);
		when(cxpService.retrieveNSE5GValidateCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleCXPResponse));
		RetrieveCartCXPRequest cxprequest = mapper.readValue(cxprequestString, RetrieveCartCXPRequest.class);
		when(cxpService.retrieve5GValidateCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleCXPResponse));
		Mono<ValidateCartCXPResponse> UIResponse = cxpHelper.retrieve5GValidateCart(cxprequest, null,false);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void swapOrderConfirmationTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartId\": \"\"}";
		CXPOrderConfirmation5GDataVO request = mapper.readValue(requestString, CXPOrderConfirmation5GDataVO.class);
		when(redisHelper2.getCartIdFromRedis()).thenReturn(Mono.just(""));
		Mono<OrderConfirmationUIResponse> uiResponse = cxpHelper.swapOrderConfirmation(request, null);
		StepVerifier.create(uiResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(redisHelper2.getCartIdFromRedis()).thenReturn(Mono.just("random"));
		OrderConfirmationCXPResponse OrderConfirmationCXPResponseObj = new OrderConfirmationCXPResponse();
		OrderConfirmationCXPResponseObj.setData(new CXPOrderConfirmation5GDataVO());
		OrderConfirmationCXPResponseObj.getData().setCart(new CXPOrderConfirm5GVO());
		CXPOrderDetails CXPOrderDetailsObj = new CXPOrderDetails();
		OrderList OrderListObj =new OrderList();
		OrderListObj.setOrderNumber(12345);
		CXPOrderDetailsObj.setOrderList(Arrays.asList(OrderListObj));
		OrderConfirmationCXPResponseObj.getData().getCart().setOrderDetails(CXPOrderDetailsObj);
		when(cxpService.getOrderConfirmationData(Mockito.any())).thenReturn(Mono.just(OrderConfirmationCXPResponseObj));
		StepVerifier.create(cxpHelper.swapOrderConfirmation(request, new TechFlowRedisData())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		SOEErrorHolder SOEErrorHolderObj = new SOEErrorHolder();
		SOEErrorHolderObj.setErrors(Arrays.asList(new SOEError()));
		SOEHTTPException SOEHTTPExceptionObj = new SOEHTTPException(0,SOEErrorHolderObj);
		when(cxpService.getOrderConfirmationData(Mockito.any())).thenReturn(Mono.error(SOEHTTPExceptionObj));
		StepVerifier.create(cxpHelper.swapOrderConfirmation(request, new TechFlowRedisData())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		SOEErrorHolderObj.setErrors(null);
		SOEHTTPExceptionObj = new SOEHTTPException(0,SOEErrorHolderObj);
		when(cxpService.getOrderConfirmationData(Mockito.any())).thenReturn(Mono.error(SOEHTTPExceptionObj));
		StepVerifier.create(cxpHelper.swapOrderConfirmation(request, new TechFlowRedisData())).expectComplete().verify();

		SOEHTTPExceptionObj = new SOEHTTPException(0, (SOEErrorHolder) null);
		when(cxpService.getOrderConfirmationData(Mockito.any())).thenReturn(Mono.error(SOEHTTPExceptionObj));
		StepVerifier.create(cxpHelper.swapOrderConfirmation(request, new TechFlowRedisData())).expectComplete().verify();

		when(cxpService.getOrderConfirmationData(Mockito.any())).thenReturn(Mono.error(IllegalArgumentException::new));
		StepVerifier.create(cxpHelper.swapOrderConfirmation(request, new TechFlowRedisData())).expectError();
	}

	@Test
	public void swapOrderConfirmationTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartId\": \"carTId\"}";
		String responseString = "{\"data\": null}";
		OrderConfirmationCXPResponse response = mapper.readValue(responseString, OrderConfirmationCXPResponse.class);
		CXPOrderConfirmation5GDataVO request = mapper.readValue(requestString, CXPOrderConfirmation5GDataVO.class);
		when(redisHelper2.getCartIdFromRedis()).thenReturn(Mono.just("cartId"));
		when(cxpService.getOrderConfirmationData(Mockito.any())).thenReturn(Mono.just(response));
		Mono<OrderConfirmationUIResponse> uiResponse = cxpHelper.swapOrderConfirmation(request, null);
		StepVerifier.create(uiResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void swapOrderConfirmationTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartId\": \"carTId\"}";
		String responseString = "{\"data\": {}}";
		OrderConfirmationCXPResponse response = mapper.readValue(responseString, OrderConfirmationCXPResponse.class);
		CXPOrderConfirmation5GDataVO request = mapper.readValue(requestString, CXPOrderConfirmation5GDataVO.class);
		when(redisHelper2.getCartIdFromRedis()).thenReturn(Mono.just("cartId"));
		when(cxpService.getOrderConfirmationData(Mockito.any())).thenReturn(Mono.just(response));
		Mono<OrderConfirmationUIResponse> uiResponse = cxpHelper.swapOrderConfirmation(request, null	);
		StepVerifier.create(uiResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateRPSE911AddressTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"VZW-NUMBERLINK\"}";
		String responseString = "{\"data\": {\"status\": \"SUCCESS\"}}";
		String dataString = "{\"successUrl\": \"\"}";
		CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
		RPSE911AddressUpdateUIRequest uiRequest = mapper.readValue(requestString, RPSE911AddressUpdateUIRequest.class);
		RPSE911AddressCXPResponse response = mapper.readValue(responseString, RPSE911AddressCXPResponse.class);
		response.getData().setSuccessUrl("Random");
		when(sessionBean.getSessionData(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CartRedisData()));
		data.setSuccessUrl("random");
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(data));
		when(cxpService.updateAccountE911Address(Mockito.any())).thenReturn(Mono.just(response));
		Mono<RPSE911AddressUpdateUIResponse> uiResponse = cxpHelper2.updateRPSE911Address(uiRequest);
		StepVerifier.create(uiResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateRPSE911AddressTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"VZW-DOTCOM\"}";
		String responseString = "{\"data\": {\"status\": \"\"}}";
		String dataString = "{\"successUrl\": \"\"}";
		CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
		RPSE911AddressUpdateUIRequest uiRequest = mapper.readValue(requestString, RPSE911AddressUpdateUIRequest.class);
		RPSE911AddressCXPResponse response = mapper.readValue(responseString, RPSE911AddressCXPResponse.class);
		when(cxpService.updateAccountE911Address(Mockito.any())).thenReturn(Mono.just(response));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(data));
		Mono<RPSE911AddressUpdateUIResponse> uiResponse = cxpHelper2.updateRPSE911Address(uiRequest);
		StepVerifier.create(uiResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateRPSE911AddressTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"VZW-NUMBERLINK\"}";
		String responseString = "{\"data\": {\"status\": \"\"}}";
		String dataString = "{\"successUrl\": \"\"}";
		CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
		RPSE911AddressUpdateUIRequest uiRequest = mapper.readValue(requestString, RPSE911AddressUpdateUIRequest.class);
		RPSE911AddressCXPResponse response = mapper.readValue(responseString, RPSE911AddressCXPResponse.class);
		when(cxpService.updateAccountE911Address(Mockito.any())).thenReturn(Mono.just(response));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(data));
		Mono<RPSE911AddressUpdateUIResponse> uiResponse = cxpHelper2.updateRPSE911Address(uiRequest);
		StepVerifier.create(uiResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateRPSE911AddressTest4() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"VZW-NUMBERLINK\"}";
		String responseString = "{\"data\": {\"status\": \"SUCCESS\"}}";
		String dataString = "{\"successUrl\": \"success\"}";
		CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
		RPSE911AddressUpdateUIRequest uiRequest = mapper.readValue(requestString, RPSE911AddressUpdateUIRequest.class);
		RPSE911AddressCXPResponse response = mapper.readValue(responseString, RPSE911AddressCXPResponse.class);
		when(cxpService.updateAccountE911Address(Mockito.any())).thenReturn(Mono.just(response));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(data));
		Mono<RPSE911AddressUpdateUIResponse> uiResponse = cxpHelper2.updateRPSE911Address(uiRequest);
		StepVerifier.create(uiResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateRPSE911AddressTest5() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"VZW-NUMBERLINK\"}";
		String dataString = "{\"successUrl\": \"success\"}";
		CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
		RPSE911AddressUpdateUIRequest uiRequest = mapper.readValue(requestString, RPSE911AddressUpdateUIRequest.class);
		when(cxpService.updateAccountE911Address(Mockito.any())).thenReturn(null);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(data));
		Mono<RPSE911AddressUpdateUIResponse> uiResponse = cxpHelper2.updateRPSE911Address(uiRequest);
		StepVerifier.create(uiResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void retrieveRPSE911AddressTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelID\": \"VZW-NUMBERLINK\", \"mtn\": [\"\"]}";
		String responseString = "{\"data\": null}";
		RPSE911AddressRetrieveUIRequest uiRequest = mapper.readValue(requestString, RPSE911AddressRetrieveUIRequest.class);
		NLinlk911AddressCXPResponse response = mapper.readValue(responseString, NLinlk911AddressCXPResponse.class);
		when(cxpService.retrieveNLinkE911Address(Mockito.any())).thenReturn(Mono.just(response));
		Mono<RPSE911AddressRetrieveUIResponse> uiResponse = cxpHelper2.retrieveRPSE911Address(uiRequest);
		StepVerifier.create(uiResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void retrieveRPSE911AddressTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelID\": \"\", \"mtn\": [\"\"]}";
		String responseString = "{\"data\": {\"status\": \"SUCCESS\"}}";
		RPSE911AddressCXPResponse response = mapper.readValue(responseString, RPSE911AddressCXPResponse.class);
		RPSE911AddressRetrieveUIRequest uiRequest = mapper.readValue(requestString, RPSE911AddressRetrieveUIRequest.class);
		when(cxpService.retrieveRPSE911Address(Mockito.any())).thenReturn(Mono.just(response));
		Mono<RPSE911AddressRetrieveUIResponse> uiResponse = cxpHelper2.retrieveRPSE911Address(uiRequest);
		StepVerifier.create(uiResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void retrieveRPSE911AddressTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelID\": \"VZW-NUMBERLINK\", \"mtn\": [\"\"]}";
		RPSE911AddressRetrieveUIRequest uiRequest = mapper.readValue(requestString, RPSE911AddressRetrieveUIRequest.class);
		when(cxpService.retrieveNLinkE911Address(Mockito.any())).thenReturn(null);
		Mono<RPSE911AddressRetrieveUIResponse> uiResponse = cxpHelper2.retrieveRPSE911Address(uiRequest);
		StepVerifier.create(uiResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void retrieveRPSE911AddressTest4() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelID\": \"\", \"mtn\": [\"\"]}";
		RPSE911AddressRetrieveUIRequest uiRequest = mapper.readValue(requestString, RPSE911AddressRetrieveUIRequest.class);
		when(cxpService.retrieveRPSE911Address(Mockito.any())).thenReturn(null);
		Mono<RPSE911AddressRetrieveUIResponse> uiResponse = cxpHelper2.retrieveRPSE911Address(uiRequest);
		StepVerifier.create(uiResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void retrieveCartTest3() throws JsonParseException, JsonMappingException, IOException {
		ReflectionTestUtils.setField(cxpHelper,"noPromoDQreasonCodesList",Arrays.asList("CE,CR,CU,FR,FX,LN,MX,SN,WP".split(",")));
		ReflectionTestUtils.setField(cxpHelper, "enableOptimisedDigitalRetrieveCart", true);
		String sampleRequestString = "{\"channelId\": \"OMNI-RETAIL\",\"meta\":{\"type\": \"optimised\",\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"5560eeed-2ad2-4634-866b-c4986502594b\"}}";
		String sampleResponseString = "{\"data\":{\"cart\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"status\":\"A\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"cartCreator\":\"4434541510\",\"cartCreatorOrderLocationCode\":\"E248201\",\"cartCreatorSalesRepId\":\"ENC\",\"creditApplicationNum\":\"388936130\",\"secondaryCreditApplicationNum\":0},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"customerType\":\"U\",\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"totalTaxAmount\":\"38.75\",\"spocs\":{\"notificationOptions\":{\"contactPhoneNumber\":\"1196120299\",\"primaryEmailId\":\"YFOOWLTH659034@VZW.COM\"}},\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"instantCreditAmount\":0.0,\"instantCreditAmountRemaining\":0.0,\"instantCreditEligible\":false,\"orderList\":[{\"creditApplication\":{\"creditApplicationNum\":388936130,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CACVASAUTOMATICAPPROVAL\",\"internationalEligibility\":\"true\",\"creditAdvisory\":\"APP388936130APPROVED-WITHNODEPOSITREQUIRED'B'\",\"securityDepositAmount\":\"0\",\"serviceClass\":\"B\",\"lineCreditClass\":\"\"},\"orderActivityType\":\"EUP\",\"orderNumber\":\"1112\"}],\"orderNumber\":0,\"outletId\":\"124632\",\"registerNumber\":0,\"saleType\":\"P\",\"salesRepId\":\"ENC\",\"totalInstantCreditAmount\":0.0,\"totalInstantCreditAmountUsed\":0.0},\"lineDetails\":{\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"mldTrunkMTN\":0,\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"zipCode4\":\"7848\"},\"isValidAddress\":true},\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"currentDevice\":{\"oldLteVoraEquipInfo\":{\"iccid\":\"89148000004671963398\",\"lteVoraDeviceInfo\":{\"deviceId\":\"352530085081859\",\"deviceType\":\"4GE\"}}},\"isSharePlanAdded\":false,\"edgeLine\":false,\"vlcLine\":false,\"isE911AddressValidated\":false,\"oldPlanFlag\":\"L\",\"orderDevice\":{\"lteVoraEquipInfo\":{\"lteEqpt\":{},\"lteVoraDeviceInfo\":{}}}},\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"shippingCost\":\"0.0\",\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"isUseUnVerifiedAddress\":false,\"isValidAddress\":false},\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"mobileNumber\":\"4434541510\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"groupDiscInd\":0,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-thumb$\"},\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"color\":{\"color\":\"#cfbea9\",\"colorDisplayName\":\"GOLD/PINKSAND\"},\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"discounts\":[],\"availableReasonCode\":[],\"inventory\":{\"isAvailable\":true,\"isBackorder\":false,\"isPreOrder\":false,\"qtyAvailable\":39437.0},\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"numberShareEligible\":\"true\",\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0}]},\"isPromoSelected\":false,\"isTradeInSelected\":false}],\"lineIdentifier\":0,\"itemSeqNum5GL\":0,\"itemSeqNum4GR\":0,\"lineExchangeTotal\":0.0,\"lineRefundTotal\":0.0,\"isCpe\":false,\"isDevicePlanCompatible\":false,\"portinMtnAssignment\":false,\"impactedLine\":false,\"preOrBackOrder\":false,\"ispuItem\":true,\"ispuItemBYOD\":false}],\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"numofLinesAAL\":0,\"numofLinesEUP\":0,\"validationMessages\":[],\"payments\":[],\"lineSeq\":0,\"vlcactivePhoneCount\":0,\"fivegOrderind\":false,\"aceOrderCreated\":false,\"serviceLinesCreated\":false,\"aceItemsModified\":false,\"clnrOrderFlag\":false,\"broadbandInd\":false,\"isPaperLessBilling\":\"false\"}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveCartCXPRequest request = mapper.readValue(sampleRequestString, RetrieveCartCXPRequest.class);
		RetrieveCartCXPResponse sampleCXPResponse = mapper.readValue(sampleResponseString, RetrieveCartCXPResponse.class);
		Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
		when(cxpService.retrieveCart(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sampleCXPResponseMono);
		when(catalogService.getCatalogRefData(Mockito.any())).thenReturn(Mono.just(new CatalogResponse()));
		when(catalogServiceHelper.getCatalogDomainData(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CatalogResponse()));
		when(redisHelper3.upsertCartCreator(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		when(cxpService.retrieveCartDigital(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sampleCXPResponseMono);
		Mono<RetrieveCartUIResponse> UIResponse = cxpHelper.retrieveCart(request);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
	}

	@Test
	public void retrieveCartTest4() throws JsonParseException, JsonMappingException, IOException {
		ReflectionTestUtils.setField(cxpHelper,"noPromoDQreasonCodesList",Arrays.asList("CE,CR,CU,FR,FX,LN,MX,SN,WP".split(",")));
		ReflectionTestUtils.setField(cxpHelper, "enableOptimisedDigitalRetrieveCart", true);
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"meta\":{\"type\": \"type\",\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"5560eeed-2ad2-4634-866b-c4986502594b\"}}";
		String sampleResponseString = "{\"data\":{\"cart\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"status\":\"A\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"cartCreator\":\"4434541510\",\"cartCreatorOrderLocationCode\":\"E248201\",\"cartCreatorSalesRepId\":\"ENC\",\"creditApplicationNum\":\"388936130\",\"secondaryCreditApplicationNum\":0},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"customerType\":\"U\",\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"totalTaxAmount\":\"38.75\",\"spocs\":{\"notificationOptions\":{\"contactPhoneNumber\":\"1196120299\",\"primaryEmailId\":\"YFOOWLTH659034@VZW.COM\"}},\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"instantCreditAmount\":0.0,\"instantCreditAmountRemaining\":0.0,\"instantCreditEligible\":false,\"orderList\":[{\"creditApplication\":{\"creditApplicationNum\":388936130,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CACVASAUTOMATICAPPROVAL\",\"internationalEligibility\":\"true\",\"creditAdvisory\":\"APP388936130APPROVED-WITHNODEPOSITREQUIRED'B'\",\"securityDepositAmount\":\"0\",\"serviceClass\":\"B\",\"lineCreditClass\":\"\"},\"orderActivityType\":\"EUP\",\"orderNumber\":\"1112\"}],\"orderNumber\":0,\"outletId\":\"124632\",\"registerNumber\":0,\"saleType\":\"P\",\"salesRepId\":\"ENC\",\"totalInstantCreditAmount\":0.0,\"totalInstantCreditAmountUsed\":0.0},\"lineDetails\":{\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"mldTrunkMTN\":0,\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"zipCode4\":\"7848\"},\"isValidAddress\":true},\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"currentDevice\":{\"oldLteVoraEquipInfo\":{\"iccid\":\"89148000004671963398\",\"lteVoraDeviceInfo\":{\"deviceId\":\"352530085081859\",\"deviceType\":\"4GE\"}}},\"isSharePlanAdded\":false,\"edgeLine\":false,\"vlcLine\":false,\"isE911AddressValidated\":false,\"oldPlanFlag\":\"L\",\"orderDevice\":{\"lteVoraEquipInfo\":{\"lteEqpt\":{},\"lteVoraDeviceInfo\":{}}}},\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"shippingCost\":\"0.0\",\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"isUseUnVerifiedAddress\":false,\"isValidAddress\":false},\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"mobileNumber\":\"4434541510\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"groupDiscInd\":0,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-thumb$\"},\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"color\":{\"color\":\"#cfbea9\",\"colorDisplayName\":\"GOLD/PINKSAND\"},\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"UN\",\"itemPriceType\":\"R\",\"discounts\":[],\"availableReasonCode\":[],\"inventory\":{\"isAvailable\":true,\"isBackorder\":false,\"isPreOrder\":false,\"qtyAvailable\":39437.0},\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"numberShareEligible\":\"true\",\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0}]},\"isPromoSelected\":false,\"isTradeInSelected\":false}],\"lineIdentifier\":0,\"itemSeqNum5GL\":0,\"itemSeqNum4GR\":0,\"lineExchangeTotal\":0.0,\"lineRefundTotal\":0.0,\"isCpe\":false,\"isDevicePlanCompatible\":false,\"portinMtnAssignment\":false,\"impactedLine\":false,\"preOrBackOrder\":false,\"ispuItem\":true,\"ispuItemBYOD\":false}],\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"numofLinesAAL\":0,\"numofLinesEUP\":0,\"validationMessages\":[],\"payments\":[],\"lineSeq\":0,\"vlcactivePhoneCount\":0,\"fivegOrderind\":false,\"aceOrderCreated\":false,\"serviceLinesCreated\":false,\"aceItemsModified\":false,\"clnrOrderFlag\":false,\"broadbandInd\":false,\"isPaperLessBilling\":\"false\"}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveCartCXPRequest request = mapper.readValue(sampleRequestString, RetrieveCartCXPRequest.class);
		RetrieveCartCXPResponse sampleCXPResponse = mapper.readValue(sampleResponseString, RetrieveCartCXPResponse.class);
		Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
		when(cxpService.retrieveCart(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sampleCXPResponseMono);
		when(catalogService.getCatalogRefData(Mockito.any())).thenReturn(Mono.just(new CatalogResponse()));
		when(catalogServiceHelper.getCatalogDomainData(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CatalogResponse()));
		when(redisHelper3.upsertCartCreator(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<RetrieveCartUIResponse> UIResponse = cxpHelper.retrieveCart(request);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
	}

	@Test
	public void retrieveCartTest5() throws JsonParseException, JsonMappingException, IOException {
		ReflectionTestUtils.setField(cxpHelper,"noPromoDQreasonCodesList",Arrays.asList("CE,CR,CU,FR,FX,LN,MX,SN,UN,WP".split(",")));
		ReflectionTestUtils.setField(cxpHelper, "enableOptimisedDigitalRetrieveCart", true);
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"meta\":{\"type\": \"\",\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"5560eeed-2ad2-4634-866b-c4986502594b\"}}";
		String sampleResponseString = "{\"data\":{\"cart\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"status\":\"A\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"cartCreator\":\"4434541510\",\"cartCreatorOrderLocationCode\":\"E248201\",\"cartCreatorSalesRepId\":\"ENC\",\"creditApplicationNum\":\"388936130\",\"secondaryCreditApplicationNum\":0},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"customerType\":\"U\",\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"totalTaxAmount\":\"38.75\",\"spocs\":{\"notificationOptions\":{\"contactPhoneNumber\":\"1196120299\",\"primaryEmailId\":\"YFOOWLTH659034@VZW.COM\"}},\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"instantCreditAmount\":0.0,\"instantCreditAmountRemaining\":0.0,\"instantCreditEligible\":false,\"orderList\":[{\"creditApplication\":{\"creditApplicationNum\":388936130,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CACVASAUTOMATICAPPROVAL\",\"internationalEligibility\":\"true\",\"creditAdvisory\":\"APP388936130APPROVED-WITHNODEPOSITREQUIRED'B'\",\"securityDepositAmount\":\"0\",\"serviceClass\":\"B\",\"lineCreditClass\":\"\"},\"orderActivityType\":\"EUP\",\"orderNumber\":\"1112\"}],\"orderNumber\":0,\"outletId\":\"124632\",\"registerNumber\":0,\"saleType\":\"P\",\"salesRepId\":\"ENC\",\"totalInstantCreditAmount\":0.0,\"totalInstantCreditAmountUsed\":0.0},\"lineDetails\":{\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"mldTrunkMTN\":0,\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"zipCode4\":\"7848\"},\"isValidAddress\":true},\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"currentDevice\":{\"oldLteVoraEquipInfo\":{\"iccid\":\"89148000004671963398\",\"lteVoraDeviceInfo\":{\"deviceId\":\"352530085081859\",\"deviceType\":\"4GE\"}}},\"isSharePlanAdded\":false,\"edgeLine\":false,\"vlcLine\":false,\"isE911AddressValidated\":false,\"oldPlanFlag\":\"L\",\"orderDevice\":{\"lteVoraEquipInfo\":{\"lteEqpt\":{},\"lteVoraDeviceInfo\":{}}}},\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"shippingCost\":\"0.0\",\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"isUseUnVerifiedAddress\":false,\"isValidAddress\":false},\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"mobileNumber\":\"4434541510\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"groupDiscInd\":0,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-thumb$\"},\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"color\":{\"color\":\"#cfbea9\",\"colorDisplayName\":\"GOLD/PINKSAND\"},\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"discounts\":[],\"availableReasonCode\":[],\"inventory\":{\"isAvailable\":true,\"isBackorder\":false,\"isPreOrder\":false,\"qtyAvailable\":39437.0},\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"numberShareEligible\":\"true\",\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0}]},\"isPromoSelected\":false,\"isTradeInSelected\":false}],\"lineIdentifier\":0,\"itemSeqNum5GL\":0,\"itemSeqNum4GR\":0,\"lineExchangeTotal\":0.0,\"lineRefundTotal\":0.0,\"isCpe\":false,\"isDevicePlanCompatible\":false,\"portinMtnAssignment\":false,\"impactedLine\":false,\"preOrBackOrder\":false,\"ispuItem\":true,\"ispuItemBYOD\":false}],\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"numofLinesAAL\":0,\"numofLinesEUP\":0,\"validationMessages\":[],\"payments\":[],\"lineSeq\":0,\"vlcactivePhoneCount\":0,\"fivegOrderind\":false,\"aceOrderCreated\":false,\"serviceLinesCreated\":false,\"aceItemsModified\":false,\"clnrOrderFlag\":false,\"broadbandInd\":false,\"isPaperLessBilling\":\"false\"}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveCartCXPRequest request = mapper.readValue(sampleRequestString, RetrieveCartCXPRequest.class);
		RetrieveCartCXPResponse sampleCXPResponse = mapper.readValue(sampleResponseString, RetrieveCartCXPResponse.class);
		Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
		when(cxpService.retrieveCart(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sampleCXPResponseMono);
		when(catalogService.getCatalogRefData(Mockito.any())).thenReturn(Mono.just(new CatalogResponse()));
		when(catalogServiceHelper.getCatalogDomainData(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CatalogResponse()));
		when(redisHelper3.upsertCartCreator(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<RetrieveCartUIResponse> UIResponse = cxpHelper.retrieveCart(request);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
	}

	@Test
	public void retrieveCartTest6() throws JsonParseException, JsonMappingException, IOException {
		ReflectionTestUtils.setField(cxpHelper,"noPromoDQreasonCodesList",Arrays.asList("CE,CR,CU,FR,FX,LN,MX,SN,UN,WP".split(",")));
		ReflectionTestUtils.setField(cxpHelper, "enableOptimisedDigitalRetrieveCart", true);
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"meta\":{\"type\": \"portIn\",\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"5560eeed-2ad2-4634-866b-c4986502594b\"}}";
		String sampleResponseString = "{\"data\":{\"cart\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"status\":\"A\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"cartCreator\":\"4434541510\",\"cartCreatorOrderLocationCode\":\"E248201\",\"cartCreatorSalesRepId\":\"ENC\",\"creditApplicationNum\":\"388936130\",\"secondaryCreditApplicationNum\":0},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"customerType\":\"U\",\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"totalTaxAmount\":\"38.75\",\"spocs\":{\"notificationOptions\":{\"contactPhoneNumber\":\"1196120299\",\"primaryEmailId\":\"YFOOWLTH659034@VZW.COM\"}},\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"instantCreditAmount\":0.0,\"instantCreditAmountRemaining\":0.0,\"instantCreditEligible\":false,\"orderList\":[{\"creditApplication\":{\"creditApplicationNum\":388936130,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CACVASAUTOMATICAPPROVAL\",\"internationalEligibility\":\"true\",\"creditAdvisory\":\"APP388936130APPROVED-WITHNODEPOSITREQUIRED'B'\",\"securityDepositAmount\":\"0\",\"serviceClass\":\"B\",\"lineCreditClass\":\"\"},\"orderActivityType\":\"EUP\",\"orderNumber\":\"1112\"}],\"orderNumber\":0,\"outletId\":\"124632\",\"registerNumber\":0,\"saleType\":\"P\",\"salesRepId\":\"ENC\",\"totalInstantCreditAmount\":0.0,\"totalInstantCreditAmountUsed\":0.0},\"lineDetails\":{\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"mldTrunkMTN\":0,\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"zipCode4\":\"7848\"},\"isValidAddress\":true},\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"currentDevice\":{\"oldLteVoraEquipInfo\":{\"iccid\":\"89148000004671963398\",\"lteVoraDeviceInfo\":{\"deviceId\":\"352530085081859\",\"deviceType\":\"4GE\"}}},\"isSharePlanAdded\":false,\"edgeLine\":false,\"vlcLine\":false,\"isE911AddressValidated\":false,\"oldPlanFlag\":\"L\",\"orderDevice\":{\"lteVoraEquipInfo\":{\"lteEqpt\":{},\"lteVoraDeviceInfo\":{}}}},\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"shippingCost\":\"0.0\",\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"isUseUnVerifiedAddress\":false,\"isValidAddress\":false},\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"mobileNumber\":\"4434541510\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"groupDiscInd\":0,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-thumb$\"},\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"color\":{\"color\":\"#cfbea9\",\"colorDisplayName\":\"GOLD/PINKSAND\"},\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"discounts\":[],\"availableReasonCode\":[],\"inventory\":{\"isAvailable\":true,\"isBackorder\":false,\"isPreOrder\":false,\"qtyAvailable\":39437.0},\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"numberShareEligible\":\"true\",\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0}]},\"isPromoSelected\":false,\"isTradeInSelected\":false}],\"lineIdentifier\":0,\"itemSeqNum5GL\":0,\"itemSeqNum4GR\":0,\"lineExchangeTotal\":0.0,\"lineRefundTotal\":0.0,\"isCpe\":false,\"isDevicePlanCompatible\":false,\"portinMtnAssignment\":false,\"impactedLine\":false,\"preOrBackOrder\":false,\"ispuItem\":true,\"ispuItemBYOD\":false}],\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"numofLinesAAL\":0,\"numofLinesEUP\":0,\"validationMessages\":[],\"payments\":[],\"lineSeq\":0,\"vlcactivePhoneCount\":0,\"fivegOrderind\":false,\"aceOrderCreated\":false,\"serviceLinesCreated\":false,\"aceItemsModified\":false,\"clnrOrderFlag\":false,\"broadbandInd\":false,\"isPaperLessBilling\":\"false\"}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveCartCXPRequest request = mapper.readValue(sampleRequestString, RetrieveCartCXPRequest.class);
		RetrieveCartCXPResponse sampleCXPResponse = mapper.readValue(sampleResponseString, RetrieveCartCXPResponse.class);
		Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
		when(cxpService.retrieveCart(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sampleCXPResponseMono);
		when(catalogService.getCatalogRefData(Mockito.any())).thenReturn(Mono.just(new CatalogResponse()));
		when(catalogServiceHelper.getCatalogDomainData(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CatalogResponse()));
		when(cxpService.retrieveCartNewNumberPortIn(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sampleCXPResponseMono);
		when(redisHelper3.upsertCartCreator(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<RetrieveCartUIResponse> UIResponse = cxpHelper.retrieveCart(request);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
	}
	@Test
	public void retrieveCartTestBby() throws JsonParseException, JsonMappingException, IOException {
		ReflectionTestUtils.setField(cxpHelper,"noPromoDQreasonCodesList",Arrays.asList("CE,CR,CU,FR,FX,LN,MX,SN,UN,WP".split(",")));
		ReflectionTestUtils.setField(cxpHelper, "enableOptimisedDigitalRetrieveCart", true);
		String responseData = "{\"data\":{\"locationCodeLookup\":{\"response\":{\"locationCode\":\"D593801\",\"locationName\":\"TESTINGONLY\",\"realAgentCode\":\"BBYOMNI\"}}}}";
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"meta\":{\"type\": \"portIn\",\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"5560eeed-2ad2-4634-866b-c4986502594b\"}}";
		String sampleResponseString = "{\"data\":{\"cart\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"status\":\"A\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"cartCreator\":\"4434541510\",\"cartCreatorOrderLocationCode\":\"E248201\",\"cartCreatorSalesRepId\":\"ENC\",\"creditApplicationNum\":\"388936130\",\"secondaryCreditApplicationNum\":0},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"customerType\":\"U\",\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"totalTaxAmount\":\"38.75\",\"spocs\":{\"notificationOptions\":{\"contactPhoneNumber\":\"1196120299\",\"primaryEmailId\":\"YFOOWLTH659034@VZW.COM\"}},\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"instantCreditAmount\":0.0,\"instantCreditAmountRemaining\":0.0,\"instantCreditEligible\":false,\"orderList\":[{\"creditApplication\":{\"creditApplicationNum\":388936130,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CACVASAUTOMATICAPPROVAL\",\"internationalEligibility\":\"true\",\"creditAdvisory\":\"APP388936130APPROVED-WITHNODEPOSITREQUIRED'B'\",\"securityDepositAmount\":\"0\",\"serviceClass\":\"B\",\"lineCreditClass\":\"\"},\"orderActivityType\":\"EUP\",\"orderNumber\":\"1112\"}],\"orderNumber\":0,\"outletId\":\"124632\",\"registerNumber\":0,\"saleType\":\"P\",\"salesRepId\":\"ENC\",\"totalInstantCreditAmount\":0.0,\"totalInstantCreditAmountUsed\":0.0},\"lineDetails\":{\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"mldTrunkMTN\":0,\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"zipCode4\":\"7848\"},\"isValidAddress\":true},\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"currentDevice\":{\"oldLteVoraEquipInfo\":{\"iccid\":\"89148000004671963398\",\"lteVoraDeviceInfo\":{\"deviceId\":\"352530085081859\",\"deviceType\":\"4GE\"}}},\"isSharePlanAdded\":false,\"edgeLine\":false,\"vlcLine\":false,\"isE911AddressValidated\":false,\"oldPlanFlag\":\"L\",\"orderDevice\":{\"lteVoraEquipInfo\":{\"lteEqpt\":{},\"lteVoraDeviceInfo\":{}}}},\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"shippingCost\":\"0.0\",\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"isUseUnVerifiedAddress\":false,\"isValidAddress\":false},\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"mobileNumber\":\"4434541510\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"groupDiscInd\":0,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-thumb$\"},\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"color\":{\"color\":\"#cfbea9\",\"colorDisplayName\":\"GOLD/PINKSAND\"},\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"discounts\":[],\"availableReasonCode\":[],\"inventory\":{\"isAvailable\":true,\"isBackorder\":false,\"isPreOrder\":false,\"qtyAvailable\":39437.0},\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"numberShareEligible\":\"true\",\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0}]},\"isPromoSelected\":false,\"isTradeInSelected\":false}],\"lineIdentifier\":0,\"itemSeqNum5GL\":0,\"itemSeqNum4GR\":0,\"lineExchangeTotal\":0.0,\"lineRefundTotal\":0.0,\"isCpe\":false,\"isDevicePlanCompatible\":false,\"portinMtnAssignment\":false,\"impactedLine\":false,\"preOrBackOrder\":false,\"ispuItem\":true,\"ispuItemBYOD\":false}],\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"numofLinesAAL\":0,\"numofLinesEUP\":0,\"validationMessages\":[],\"payments\":[],\"lineSeq\":0,\"vlcactivePhoneCount\":0,\"fivegOrderind\":false,\"aceOrderCreated\":false,\"serviceLinesCreated\":false,\"aceItemsModified\":false,\"clnrOrderFlag\":false,\"broadbandInd\":false,\"isPaperLessBilling\":\"false\"}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveCartCXPRequest request = mapper.readValue(sampleRequestString, RetrieveCartCXPRequest.class);
		RetrieveCartCXPResponse sampleCXPResponse = mapper.readValue(sampleResponseString, RetrieveCartCXPResponse.class);
		Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
		when(cxpService.retrieveCart(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sampleCXPResponseMono);
		when(catalogService.getCatalogRefData(Mockito.any())).thenReturn(Mono.just(new CatalogResponse()));
		when(catalogServiceHelper.getCatalogDomainData(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CatalogResponse()));
		when(cxpService.retrieveCartNewNumberPortIn(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sampleCXPResponseMono);
		when(redisHelper3.upsertCartCreator(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));

		CartRedisData data = new CartRedisData();
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(data));
		Mono<RetrieveCartUIResponse> UIResponse = cxpHelper.retrieveCart(request);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();

		when(redisHelper2.upsertrealAgentCodeSession(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		request.getData().setLocationSubtype("GX");
		request.getData().setMaid("BBY");
		UIResponse = cxpHelper.retrieveCart(request);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();

		request.getData().setLocationSubtype(null);
		request.getData().setMaid(null);
		when(redisHelper2.upsertrealAgentCodeSession(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		UIResponse = cxpHelper.retrieveCart(request);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();

		request.getData().setLocationSubtype("GN");
		request.getData().setMaid("BBX");
		request.getData().setUpc(null);
		request.getData().setPriceId(null);
		RetrieveGlobalLocationDetailsCxpResponse locResp = mapper.readValue(responseData, RetrieveGlobalLocationDetailsCxpResponse.class);
		when(cxpService.retrieveGlobalLocationDetails(Mockito.any())).thenReturn(Mono.just(locResp));
		when(redisHelper2.upsertrealAgentCodeSession(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		UIResponse = cxpHelper.retrieveCart(request);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();

		request.getData().setLocationSubtype("GN");
		request.getData().setMaid("BBX");
		request.getData().setUpc("upc");
		request.getData().setPriceId("priceId");
		when(cxpService.retrieveGlobalLocationDetails(Mockito.any())).thenReturn(Mono.just(locResp));
		when(redisHelper2.upsertrealAgentCodeSession(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		UIResponse = cxpHelper.retrieveCart(request);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();

		locResp.getData().getLocationCodeLookup().getResponse().setRealAgentCode(null);
		when(cxpService.retrieveGlobalLocationDetails(Mockito.any())).thenReturn(Mono.just(locResp));
		UIResponse = cxpHelper.retrieveCart(request);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();

		locResp.getData().getLocationCodeLookup().setResponse(null);
		when(cxpService.retrieveGlobalLocationDetails(Mockito.any())).thenReturn(Mono.just(locResp));
		UIResponse = cxpHelper.retrieveCart(request);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();

		locResp.getData().setLocationCodeLookup(null);
		when(cxpService.retrieveGlobalLocationDetails(Mockito.any())).thenReturn(Mono.just(locResp));
		UIResponse = cxpHelper.retrieveCart(request);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();

		locResp.setData(null);
		when(cxpService.retrieveGlobalLocationDetails(Mockito.any())).thenReturn(Mono.just(locResp));
		UIResponse = cxpHelper.retrieveCart(request);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
	}


	@Test
	public void convertCXPResponseToUiResponseTest() throws JsonMappingException, JsonProcessingException {
		ReflectionTestUtils.setField(cxpHelper, "SMART_IMEI_TYPEAHEAD_MERGE_ENABLED","Y");
		ReflectionTestUtils.setField(cxpHelper, "simOutWordList",Arrays.asList("SimOut","PP","Sim Out", "SO"));
		String respString = "{\"data\": {\"smartImeiTypeAheadDetails\": [{\"modelName\": \"SAMSUNG\"}]}}";
		SmartImeiTypeAheadCXPResponse resp = mapper.readValue(respString , SmartImeiTypeAheadCXPResponse.class);
		String requestString = "{\"model\": \"model 1\"}";
		SmartImeiTypeAheadSearchRequest uiRequest = mapper.readValue(requestString, SmartImeiTypeAheadSearchRequest.class);
		cxpHelper.convertCXPResponseToUiResponse(resp, uiRequest);

		uiRequest.setModel("");
		ReflectionTestUtils.setField(cxpHelper, "simOutWordList",Arrays.asList(""));
		cxpHelper.convertCXPResponseToUiResponse(resp, uiRequest);
		ReflectionTestUtils.setField(cxpHelper, "simOutWordList", Collections.emptyList());
		cxpHelper.convertCXPResponseToUiResponse(resp, uiRequest);

		ReflectionTestUtils.setField(cxpHelper, "SMART_IMEI_TYPEAHEAD_MERGE_ENABLED","random");
		StepVerifier.create( cxpHelper.convertCXPResponseToUiResponse(resp, uiRequest)).assertNext(response -> Assert.assertNotNull(response));
	}

	@Test
	public void convertCXPResponseToUiResponseTest2() throws JsonMappingException, JsonProcessingException {
		ReflectionTestUtils.setField(cxpHelper, "SMART_IMEI_TYPEAHEAD_MERGE_ENABLED","Y");
		ReflectionTestUtils.setField(cxpHelper, "simOutWordList",Arrays.asList("SimOut","PP","Sim Out", "SO"));
		String respString = "{\"data\": {\"smartImeiTypeAheadDetails\": [{\"modelName\": \"MOTOROLA\"}]}}";
		SmartImeiTypeAheadCXPResponse resp = mapper.readValue(respString , SmartImeiTypeAheadCXPResponse.class);
		String requestString = "{\"model\": \"model MM\"}";
		SmartImeiTypeAheadSearchRequest uiRequest = mapper.readValue(requestString, SmartImeiTypeAheadSearchRequest.class);
		StepVerifier.create( cxpHelper.convertCXPResponseToUiResponse(resp, uiRequest)).assertNext( response -> Assert.assertNotNull(response));
	}

	@Test
	public void convertCXPResponseToUiResponseTest3() throws JsonMappingException, JsonProcessingException {
		ReflectionTestUtils.setField(cxpHelper, "SMART_IMEI_TYPEAHEAD_MERGE_ENABLED","Y");
		ReflectionTestUtils.setField(cxpHelper, "simOutWordList",Arrays.asList("SimOut","PP","Sim Out", "SO"));
		String respString = "{\"data\": {\"smartImeiTypeAheadDetails\": [{\"modelName\": \"SONY\"}]}}";
		SmartImeiTypeAheadCXPResponse resp = mapper.readValue(respString , SmartImeiTypeAheadCXPResponse.class);
		String requestString = "{\"model\": \"model M\"}";
		SmartImeiTypeAheadSearchRequest uiRequest = mapper.readValue(requestString, SmartImeiTypeAheadSearchRequest.class);
		StepVerifier.create( cxpHelper.convertCXPResponseToUiResponse(resp, uiRequest)).assertNext( response -> Assert.assertNotNull(response));
	}

	@Test
	public void convertCXPResponseToUiResponseTest4() throws JsonMappingException, JsonProcessingException {
		ReflectionTestUtils.setField(cxpHelper, "SMART_IMEI_TYPEAHEAD_MERGE_ENABLED","Y");
		ReflectionTestUtils.setField(cxpHelper, "simOutWordList",Arrays.asList("SimOut","PP","Sim Out", "SO"));
		String respString = "{\"data\": {\"smartImeiTypeAheadDetails\": [{\"modelName\": \"SONY\"}]}}";
		SmartImeiTypeAheadCXPResponse resp = mapper.readValue(respString , SmartImeiTypeAheadCXPResponse.class);
		String requestString = "{\"model\": \"\"}";
		SmartImeiTypeAheadSearchRequest uiRequest = mapper.readValue(requestString, SmartImeiTypeAheadSearchRequest.class);
		StepVerifier.create( cxpHelper.convertCXPResponseToUiResponse(resp, uiRequest)).assertNext( response -> Assert.assertNotNull(response));
	}

	@Test
	public void deviceSimValidationTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"imei\": \"imei\", \"eid\": \"eid\", \"techType\": \"tech\", \"imei2\": \"\"}";
		String dataString = "{\"mtn\": \"\"}";
		String cxpResponseString = "{\"data\": {\"esimInfo\": null, \"deviceInfo\": {\"deivceAttributes\": null}}}";
		EsimInfo esimInfo = new EsimInfo();
		DeviceAttributes deviceAttributes = mapper.readValue("{\"daccCode\": \"dacc\", \"deviceCategory\": \"Smartphone\"}", DeviceAttributes.class);
		DeviceSimValidationCXPResponse cxpResponse = mapper.readValue(cxpResponseString, DeviceSimValidationCXPResponse.class);
		cxpResponse.getData().setEsimInfo(esimInfo);
		cxpResponse.getData().getDeviceInfo().setDeviceAttributes(deviceAttributes);
		CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
		DeviceSimValidationUIRequest uiRequest = mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
		URI url = URI.create("http://localhost/nse/deviceSimValidation");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(data));
		when(cxpService.deviceSimValidation(Mockito.any())).thenReturn(Mono.just(cxpResponse));
		when(environment.getProperty(Mockito.any())).thenReturn("esim.ipad.daccs");
		Mono<DeviceSimValidationUIResponse> response = cxpHelper2.deviceSimValidation(httpHeader, uiRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deviceSimValidationTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"imei\": \"imei\", \"eid\": \"eid\", \"techType\": \"tech\", \"imei2\": \"imei2\"}";
		String dataString = "{\"mtn\": \"\"}";
		String cxpResponseString = "{\"data\": {\"esimInfo\": null, \"deviceInfo\": {\"deivceAttributes\": null}}}";
		EsimInfo esimInfo = new EsimInfo();
		DeviceAttributes deviceAttributes = mapper.readValue("{\"daccCode\": \"01157\", \"deviceCategory\": \"Smartphone\"}", DeviceAttributes.class);
		DeviceSimValidationCXPResponse cxpResponse = mapper.readValue(cxpResponseString, DeviceSimValidationCXPResponse.class);
		cxpResponse.getData().setEsimInfo(esimInfo);
		cxpResponse.getData().getDeviceInfo().setDeviceAttributes(deviceAttributes);
		CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
		DeviceSimValidationUIRequest uiRequest = mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
		URI url = URI.create("http://localhost/deviceSimValidation");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(data));
		when(cxpService.deviceSimValidation(Mockito.any())).thenReturn(Mono.just(cxpResponse));
		when(environment.getProperty(Mockito.any())).thenReturn("esim.ipad.daccs");
		Mono<DeviceSimValidationUIResponse> response = cxpHelper2.deviceSimValidation(httpHeader, uiRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deviceSimValidationTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"imei\": \"imei\", \"eid\": \"\", \"techType\": \"tech\", \"imei2\": \"imei2\"}";
		String dataString = "{\"mtn\": \"\"}";
		String cxpResponseString = "{\"data\": {\"esimInfo\": null, \"deviceInfo\": {\"deivceAttributes\": null}}}";
		EsimInfo esimInfo = new EsimInfo();
		esimInfo.setEId("eid");
		DeviceAttributes deviceAttributes = mapper.readValue("{\"daccCode\": \"01159\", \"deviceCategory\": \"phone\"}", DeviceAttributes.class);
		DeviceSimValidationCXPResponse cxpResponse = mapper.readValue(cxpResponseString, DeviceSimValidationCXPResponse.class);
		cxpResponse.getData().setEsimInfo(esimInfo);
		cxpResponse.getData().getDeviceInfo().setDeviceAttributes(deviceAttributes);
		CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
		DeviceSimValidationUIRequest uiRequest = mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
		URI url = URI.create("http://localhost/nse/deviceSimValidation");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(data));
		when(cxpService.deviceSimValidation(Mockito.any())).thenReturn(Mono.just(cxpResponse));
		when(environment.getProperty(Mockito.any())).thenReturn("esim.ipad.daccs");
		Mono<DeviceSimValidationUIResponse> response = cxpHelper2.deviceSimValidation(httpHeader, uiRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deviceSimValidationTest4() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"imei\": \"imei\", \"eid\": \"\", \"techType\": \"tech\", \"imei2\": \"imei2\"}";
		String dataString = "{\"mtn\": \"\"}";
		String cxpResponseString = "{\"data\": {\"esimInfo\": null, \"deviceInfo\": {\"deivceAttributes\": null}}}";
		EsimInfo esimInfo = new EsimInfo();
		esimInfo.setEId("eid");
		DeviceAttributes deviceAttributes = mapper.readValue("{\"daccCode\": \"01312\", \"deviceCategory\": \"\"}", DeviceAttributes.class);
		DeviceSimValidationCXPResponse cxpResponse = mapper.readValue(cxpResponseString, DeviceSimValidationCXPResponse.class);
		cxpResponse.getData().setEsimInfo(esimInfo);
		cxpResponse.getData().getDeviceInfo().setDeviceAttributes(deviceAttributes);
		CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
		DeviceSimValidationUIRequest uiRequest = mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
		URI url = URI.create("http://localhost");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(data));
		when(cxpService.deviceSimValidation(Mockito.any())).thenReturn(Mono.just(cxpResponse));
		when(environment.getProperty(Mockito.any())).thenReturn("esim.ipad.daccs");
		Mono<DeviceSimValidationUIResponse> response = cxpHelper2.deviceSimValidation(httpHeader, uiRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deviceSimValidationTest5() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"imei\": \"imei\", \"eid\": \"\", \"techType\": \"tech\", \"imei2\": \"imei2\"}";
		String dataString = "{\"mtn\": \"\"}";
		String cxpResponseString = "{\"data\": {\"esimInfo\": null, \"deviceInfo\": {\"deivceAttributes\": null}}}";
		EsimInfo esimInfo = new EsimInfo();
		esimInfo.setEId("eid");
		DeviceAttributes deviceAttributes = mapper.readValue("{\"daccCode\": \"01483\", \"deviceCategory\": \"Smartphone\"}", DeviceAttributes.class);
		DeviceSimValidationCXPResponse cxpResponse = mapper.readValue(cxpResponseString, DeviceSimValidationCXPResponse.class);
		cxpResponse.getData().setEsimInfo(esimInfo);
		cxpResponse.getData().getDeviceInfo().setDeviceAttributes(deviceAttributes);
		CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
		DeviceSimValidationUIRequest uiRequest = mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
		URI url = URI.create("http://localhost/nse/deviceSimValidation");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(data));
		when(cxpService.deviceSimValidation(Mockito.any())).thenReturn(Mono.just(cxpResponse));
		when(environment.getProperty(Mockito.any())).thenReturn("esim.ipad.daccs");
		Mono<DeviceSimValidationUIResponse> response = cxpHelper2.deviceSimValidation(httpHeader, uiRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deviceSimValidationTest6() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"imei\": \"imei\", \"eid\": \"eid\", \"techType\": \"tech\", \"imei2\": \"imei2\"}";
		String dataString = "{\"mtn\": \"\"}";
		String cxpResponseString = "{\"data\": {\"esimInfo\": null, \"deviceInfo\": {\"deivceAttributes\": null}}}";
		EsimInfo esimInfo = new EsimInfo();
		DeviceAttributes deviceAttributes = mapper.readValue("{\"daccCode\": \"01435\", \"deviceCategory\": \"Smartphone\"}", DeviceAttributes.class);
		DeviceSimValidationCXPResponse cxpResponse = mapper.readValue(cxpResponseString, DeviceSimValidationCXPResponse.class);
		cxpResponse.getData().setEsimInfo(esimInfo);
		cxpResponse.getData().getDeviceInfo().setDeviceAttributes(deviceAttributes);
		CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
		DeviceSimValidationUIRequest uiRequest = mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
		URI url = URI.create("http://localhost/nse/deviceSimValidation");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(data));
		when(cxpService.deviceSimValidation(Mockito.any())).thenReturn(Mono.just(cxpResponse));
		when(environment.getProperty(Mockito.any())).thenReturn("esim.ipad.daccs");
		Mono<DeviceSimValidationUIResponse> response = cxpHelper2.deviceSimValidation(httpHeader, uiRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deviceSimValidationTest7() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"imei\": \"imei\", \"eid\": \"eid\", \"techType\": \"tech\", \"imei2\": \"imei2\"}";
		String dataString = "{\"mtn\": \"\"}";
		String cxpResponseString = "{\"data\": {\"esimInfo\": null, \"deviceInfo\": {\"deivceAttributes\": null}}}";
		EsimInfo esimInfo = new EsimInfo();
		esimInfo.setEId("eid");
		DeviceAttributes deviceAttributes = mapper.readValue("{\"daccCode\": \"\", \"deviceCategory\": \"\"}", DeviceAttributes.class);
		DeviceSimValidationCXPResponse cxpResponse = mapper.readValue(cxpResponseString, DeviceSimValidationCXPResponse.class);
		cxpResponse.getData().setEsimInfo(esimInfo);
		cxpResponse.getData().getDeviceInfo().setDeviceAttributes(deviceAttributes);
		CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
		DeviceSimValidationUIRequest uiRequest = mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
		URI url = URI.create("http://localhost/nse/deviceSimValidation");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(data));
		when(cxpService.deviceSimValidation(Mockito.any())).thenReturn(Mono.just(cxpResponse));
		Mono<DeviceSimValidationUIResponse> response = cxpHelper2.deviceSimValidation(httpHeader, uiRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deviceSimValidationTest8() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"imei\": \"imei\", \"eid\": \"eid\", \"techType\": \"tech\", \"imei2\": \"imei2\"}";
		String dataString = "{\"mtn\": \"\"}";
		CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
		DeviceSimValidationUIRequest uiRequest = mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
		URI url = URI.create("http://localhost/nse/deviceSimValidation");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(data));
		when(cxpService.deviceSimValidation(Mockito.any())).thenReturn(null);
		Mono<DeviceSimValidationUIResponse> response = cxpHelper2.deviceSimValidation(httpHeader, uiRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deviceIdValidationTest2() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"esimFlow\": true,\"mtn\": \"6159691822\",\"device\": {\"identifier\": \"identifier\",\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"skuCarrier\": \"skuCarrier\",\"giftBox\": {\"id\": \"LVSKPGB\"}}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\", \"data\": {  \"lines\": [{  \"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		String respString = "{\"ddata\": {\"aemoutput\": {\"output\": {\"deviceModelMap\": [{\"Key\": \"key\"},{\"Key\": \"identifier\"},{\"Key\": \"\"}]}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		ProspectDeviceModelMapResponse respo = mapper.readValue(respString, ProspectDeviceModelMapResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(cartAEMService.getSKUDetail(Mockito.any())).thenReturn(Mono.just(respo));
		DeviceModelMap modelMap=new DeviceModelMap();
		modelMap.setModel("model");
		List<DeviceModelMap> list=new ArrayList<>();
		list.add(modelMap);
		respo.setDeviceModelMap(list);
		when(redisHelper3.updateByodDeviceDetailRedis(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).expectError().verify();
	}

	@Test
	public void deviceIdValidationTest3() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"esimFlow\": true,\"mtn\": \"6159691822\",\"device\": {\"identifier\": \"identifier\",\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"skuCarrier\": \"skuCarrier\",\"giftBox\": {\"id\": \"LVSKPGB\"}}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\", \"data\": {  \"lines\": [{  \"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		String respString = "{\"ddata\": {\"aemoutput\": {\"output\": {\"deviceModelMap\": [{}]}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		ProspectDeviceModelMapResponse respo = mapper.readValue(respString, ProspectDeviceModelMapResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(cartAEMService.getSKUDetail(Mockito.any())).thenReturn(Mono.just(respo));
		when(redisHelper3.updateByodDeviceDetailRedis(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		DeviceModelMap modelMap=new DeviceModelMap();
		modelMap.setModel("model");
		List<DeviceModelMap> list=new ArrayList<>();
		list.add(modelMap);
		respo.setDeviceModelMap(list);
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).expectError().verify();
	}

	@Test
	public void deviceIdValidationTest4() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"esimFlow\": true,\"mtn\": \"6159691822\",\"device\": {\"identifier\": \"identifier\",\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"skuCarrier\": null,\"giftBox\": {\"id\": \"LVSKPGB\"}}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\", \"data\": {  \"lines\": [{  \"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		String respString = "{\"ddata\": {\"aemoutput\": {\"output\": {\"deviceModelMap\": null}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		ProspectDeviceModelMapResponse respo = mapper.readValue(respString, ProspectDeviceModelMapResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(cartAEMService.getSKUDetail(Mockito.any())).thenReturn(Mono.just(respo));
		when(redisHelper3.updateByodDeviceDetailRedis(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		Assert.assertNotNull(response);
	}

	@Test
	public void deviceIdValidationTest5() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"esimFlow\": true,\"mtn\": \"6159691822\",\"device\": {\"identifier\": \"identifier\",\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"skuCarrier\": null,\"giftBox\": {\"id\": \"LVSKPGB\"}}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\", \"data\": {  \"lines\": [{  \"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		String respString = "{\"ddata\": {\"aemoutput\": {\"output\": {\"deviceModelMap\": [{\"Key\": \"identifier\"}]}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		ProspectDeviceModelMapResponse respo = mapper.readValue(respString, ProspectDeviceModelMapResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(cartAEMService.getSKUDetail(Mockito.any())).thenReturn(Mono.just(respo));
		when(redisHelper3.updateByodDeviceDetailRedis(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		DeviceModelMap modelMap=new DeviceModelMap();
		modelMap.setModel("model");
		List<DeviceModelMap> list=new ArrayList<>();
		list.add(modelMap);
		respo.setDeviceModelMap(list);
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).expectError().verify();
	}

	@Test
	public void deviceIdValidationTest6() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"esimFlow\": true,\"mtn\": \"6159691822\",\"device\": {\"identifier\": \"identifier\",\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"skuCarrier\": \"VERIZON\",\"giftBox\": {\"id\": \"LVSKPGB\"}}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\", \"data\": {  \"lines\": [{  \"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		String respString = "{\"ddata\": {\"aemoutput\": {\"output\": {\"deviceModelMap\": [{\"Key\": \"identifier\", \"Model\": \"model\", \"eSim\": {}, \"pSim\": {}}]}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		ProspectDeviceModelMapResponse respo = mapper.readValue(respString, ProspectDeviceModelMapResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(cartAEMService.getSKUDetail(Mockito.any())).thenReturn(Mono.just(respo));
		when(redisHelper3.updateByodDeviceDetailRedis(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		DeviceModelMap modelMap=new DeviceModelMap();
		modelMap.setModel("model");
		List<DeviceModelMap> list=new ArrayList<>();
		list.add(modelMap);
		respo.setDeviceModelMap(list);
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).expectError().verify();
	}

	@Test
	public void deviceIdValidationTest7() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"esimFlow\": true,\"mtn\": \"6159691822\",\"device\": {\"identifier\": \"identifier\",\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"skuCarrier\": \"AT&T\",\"giftBox\": {\"id\": \"LVSKPGB\"}}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\", \"data\": {  \"lines\": [{  \"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		String respString = "{\"ddata\": {\"aemoutput\": {\"output\": {\"deviceModelMap\": [{\"Key\": \"identifier\", \"Model\": \"model\", \"eSim\": {}, \"pSim\": {}}]}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		ProspectDeviceModelMapResponse respo = mapper.readValue(respString, ProspectDeviceModelMapResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(cartAEMService.getSKUDetail(Mockito.any())).thenReturn(Mono.just(respo));
		when(redisHelper3.updateByodDeviceDetailRedis(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		DeviceModelMap modelMap=new DeviceModelMap();
		modelMap.setModel("model");
		List<DeviceModelMap> list=new ArrayList<>();
		list.add(modelMap);
		respo.setDeviceModelMap(list);
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).expectError().verify();
	}

	@Test
	public void deviceIdValidationTest8() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"esimFlow\": true,\"mtn\": \"6159691822\",\"device\": {\"identifier\": \"identifier\",\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"skuCarrier\": \"SPRINT\",\"giftBox\": {\"id\": \"LVSKPGB\"}}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\", \"data\": {  \"lines\": [{  \"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		String respString = "{\"ddata\": {\"aemoutput\": {\"output\": {\"deviceModelMap\": [{\"Key\": \"identifier\", \"Model\": \"model\", \"eSim\": {}, \"pSim\": {}}]}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		ProspectDeviceModelMapResponse respo = mapper.readValue(respString, ProspectDeviceModelMapResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(cartAEMService.getSKUDetail(Mockito.any())).thenReturn(Mono.just(respo));
		when(redisHelper3.updateByodDeviceDetailRedis(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		DeviceModelMap modelMap=new DeviceModelMap();
		modelMap.setModel("model");
		List<DeviceModelMap> list=new ArrayList<>();
		list.add(modelMap);
		respo.setDeviceModelMap(list);
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).expectError().verify();
	}

	@Test
	public void deviceIdValidationTest9() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"esimFlow\": true,\"mtn\": \"6159691822\",\"device\": {\"identifier\": \"identifier\",\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"skuCarrier\": \"T-MOBILE\",\"giftBox\": {\"id\": \"LVSKPGB\"}}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\", \"data\": {  \"lines\": [{  \"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		String respString = "{\"ddata\": {\"aemoutput\": {\"output\": {\"deviceModelMap\": [{\"Key\": \"identifier\", \"Model\": \"model\", \"eSim\": {}, \"pSim\": {}}]}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		ProspectDeviceModelMapResponse respo = mapper.readValue(respString, ProspectDeviceModelMapResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(cartAEMService.getSKUDetail(Mockito.any())).thenReturn(Mono.just(respo));
		when(redisHelper3.updateByodDeviceDetailRedis(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		DeviceModelMap modelMap=new DeviceModelMap();
		modelMap.setModel("model");
		List<DeviceModelMap> list=new ArrayList<>();
		list.add(modelMap);
		respo.setDeviceModelMap(list);
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).expectError().verify();
	}

	@Test
	public void deviceIdValidationTest10() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"esimFlow\": true,\"mtn\": \"6159691822\",\"device\": {\"identifier\": \"identifier\",\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"skuCarrier\": \"MOBILE\",\"giftBox\": {\"id\": \"LVSKPGB\"}}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\", \"data\": {  \"lines\": [{  \"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		String respString = "{\"ddata\": {\"aemoutput\": {\"output\": {\"deviceModelMap\": [{\"Key\": \"identifier\", \"Model\": \"model\", \"eSim\": {}, \"pSim\": {}}]}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		ProspectDeviceModelMapResponse respo = mapper.readValue(respString, ProspectDeviceModelMapResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(cartAEMService.getSKUDetail(Mockito.any())).thenReturn(Mono.just(respo));
		when(redisHelper3.updateByodDeviceDetailRedis(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		DeviceModelMap modelMap=new DeviceModelMap();
		modelMap.setModel("model");
		List<DeviceModelMap> list=new ArrayList<>();
		list.add(modelMap);
		respo.setDeviceModelMap(list);
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).expectError().verify();
	}

	@Test
	public void deviceIdValidationTest11() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"esimFlow\": true,\"mtn\": \"6159691822\",\"device\": {\"identifier\": \"(identifier)\",\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"skuCarrier\": \"MOBILE\",\"giftBox\": {\"id\": \"LVSKPGB\"}}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\", \"data\": {  \"lines\": [{  \"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		String respString = "{\"ddata\": {\"aemoutput\": {\"output\": {\"deviceModelMap\": [{\"Key\": \"(identifier)\", \"Model\": \"model\", \"eSim\": {\"Other\": \"other\"}, \"pSim\": {}}]}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		ProspectDeviceModelMapResponse respo = mapper.readValue(respString, ProspectDeviceModelMapResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(cartAEMService.getSKUDetail(Mockito.any())).thenReturn(Mono.just(respo));
		when(redisHelper3.updateByodDeviceDetailRedis(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		DeviceModelMap modelMap=new DeviceModelMap();
		modelMap.setModel("model");
		List<DeviceModelMap> list=new ArrayList<>();
		list.add(modelMap);
		respo.setDeviceModelMap(list);
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).expectError().verify();
	}

	@Test
	public void deviceIdValidationTest12() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"esimFlow\": true,\"mtn\": \"6159691822\",\"device\": {\"identifier\": \"\",\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"skuCarrier\": \"MOBILE\",\"giftBox\": {\"id\": \"LVSKPGB\"}}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\", \"data\": {  \"lines\": [{  \"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		String respString = "{\"ddata\": {\"aemoutput\": {\"output\": {\"deviceModelMap\": [{\"Key\": \"\", \"Model\": \"model\", \"eSim\": {\"Other\": \"other\"}, \"pSim\": {}}]}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		ProspectDeviceModelMapResponse respo = mapper.readValue(respString, ProspectDeviceModelMapResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(cartAEMService.getSKUDetail(Mockito.any())).thenReturn(Mono.just(respo));
		when(redisHelper3.updateByodDeviceDetailRedis(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		DeviceModelMap modelMap=new DeviceModelMap();
		modelMap.setModel("model");
		List<DeviceModelMap> list=new ArrayList<>();
		list.add(modelMap);
		respo.setDeviceModelMap(list);
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).expectError().verify();
	}

	@Test
	public void deviceIdValidationTest13() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"device\": {\"simSelected\": \"pSim\",\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"giftBox\": {\"id\": \"LVSKPGB\"}},\"editSim\": true,\"esimFlow\": true,\"mtn\": \"6159691822\"}]}}";
		String sampleResponseString = "{\"client\": \"CXP\", \"data\": {  \"lines\": [{  \"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper3.getDeviceSorDisplayNameFromRedis()).thenReturn(Mono.just(""));
		when(redisHelper3.getPsimSKUFromRedis()).thenReturn(Mono.just(""));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deviceIdValidationTest14() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"device\": {\"simSelected\": \"pSim\",\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"giftBox\": {\"id\": \"LVSKPGB\"}},\"editSim\": true,\"esimFlow\": true,\"mtn\": \"6159691822\"}]}}";
		String sampleResponseString = "{\"client\": \"CXP\", \"data\": {  \"lines\": [{  \"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper3.getDeviceSorDisplayNameFromRedis()).thenReturn(Mono.just(""));
		when(redisHelper3.getPsimSKUFromRedis()).thenReturn(Mono.just("psim"));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deviceIdValidationTest15() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"device\": {\"simSelected\": \"pSim\",\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"giftBox\": {\"id\": \"LVSKPGB\"}},\"editSim\": true,\"esimFlow\": true,\"mtn\": \"6159691822\"}]}}";
		String sampleResponseString = "{\"client\": \"CXP\", \"data\": {  \"lines\": [{  \"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		SearchAttributes searchAttributes = mapper.readValue("{\"sku\": \"sku\"}", SearchAttributes.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper3.getDeviceSorDisplayNameFromRedis()).thenReturn(Mono.just(""));
		when(redisHelper3.getPsimSKUFromRedis()).thenReturn(Mono.just(""));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deviceIdValidationTest16() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"device\": {\"simSelected\": \"pSim\",\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"giftBox\": {\"id\": \"LVSKPGB\"}},\"editSim\": true,\"esimFlow\": true,\"mtn\": \"6159691822\"}]}}";
		String sampleResponseString = "{\"client\": \"CXP\", \"data\": {  \"lines\": [{  \"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		SearchAttributes searchAttributes = mapper.readValue("{\"sku\": null}", SearchAttributes.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper3.getDeviceSorDisplayNameFromRedis()).thenReturn(Mono.just(""));
		when(redisHelper3.getPsimSKUFromRedis()).thenReturn(Mono.just(""));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deviceIdValidationTest17() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"device\": {\"simSelected\": \"pSim\",\"smartIMEI\": true,\"id\": \"\", \"CurrentId\": \"\",\"giftBox\": {\"id\": \"LVSKPGB\"}},\"editSim\": true,\"esimFlow\": true,\"mtn\": \"6159691822\"}]}}";
		String sampleResponseString = "{\"client\": \"CXP\", \"data\": {  \"lines\": [{  \"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		SearchAttributes searchAttributes = mapper.readValue("{\"sku\": null}", SearchAttributes.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper3.getDeviceSorDisplayNameFromRedis()).thenReturn(Mono.just(""));
		when(redisHelper3.getPsimSKUFromRedis()).thenReturn(Mono.just(""));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deviceIdValidationTest18() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"esimFlow\": true,\"mtn\": \"6159691822\",\"device\": {\"identifier\": \"VERIZON\",\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"skuCarrier\": \"VERIZON\",\"giftBox\": {\"id\": \"LVSKPGB\"}}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\", \"data\": {  \"lines\": [{  \"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		String respString = "{\"ddata\": {\"aemoutput\": {\"output\": {\"deviceModelMap\": [{\"Key\": \"identifier\", \"Model\": \"model\", \"eSim\": {}, \"pSim\": {}}]}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		ProspectDeviceModelMapResponse respo = mapper.readValue(respString, ProspectDeviceModelMapResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(cartAEMService.getSKUDetail(Mockito.any())).thenReturn(Mono.just(respo));
		when(redisHelper3.updateByodDeviceDetailRedis(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		DeviceModelMap modelMap=new DeviceModelMap();
		modelMap.setModel("model");
		modelMap.setKey("VERIZON");
		PSim psim=new PSim();
		psim.setVERIZON("");
		ESim esim=new ESim();
		esim.setVERIZON("");
		modelMap.setESim(esim);
		modelMap.setPSim(psim);
		List<DeviceModelMap> list=new ArrayList<>();
		list.add(modelMap);
		respo.setDeviceModelMap(list);
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).expectError().verify();
	}

	@Test
	public void deviceIdValidationTest19() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"esimFlow\": true,\"mtn\": \"6159691822\",\"device\": {\"identifier\": \"VERIZON\",\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"skuCarrier\": \"VERIZON\",\"giftBox\": {\"id\": \"LVSKPGB\"}}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\", \"data\": {  \"lines\": [{  \"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		String respString = "{\"ddata\": {\"aemoutput\": {\"output\": {\"deviceModelMap\": [{\"Key\": \"identifier\", \"Model\": \"model\", \"eSim\": {}, \"pSim\": {}}]}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		ProspectDeviceModelMapResponse respo = mapper.readValue(respString, ProspectDeviceModelMapResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(cartAEMService.getSKUDetail(Mockito.any())).thenReturn(Mono.just(respo));
		when(redisHelper3.updateByodDeviceDetailRedis(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		DeviceModelMap modelMap=new DeviceModelMap();
		modelMap.setModel("model");
		modelMap.setKey("VERIZON");
		ESim esim=new ESim();
		esim.setVERIZON("");
		modelMap.setESim(esim);
		List<DeviceModelMap> list=new ArrayList<>();
		list.add(modelMap);
		respo.setDeviceModelMap(list);
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).expectError().verify();
	}

	@Test
	public void deviceIdValidationTest20() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"esimFlow\": true,\"mtn\": \"6159691822\",\"device\": {\"identifier\": \"VERIZON\",\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"skuCarrier\": \"VERIZON\",\"giftBox\": {\"id\": \"LVSKPGB\"}}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\", \"data\": {  \"lines\": [{  \"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		String respString = "{\"ddata\": {\"aemoutput\": {\"output\": {\"deviceModelMap\": [{\"Key\": \"identifier\", \"Model\": \"model\", \"eSim\": {}, \"pSim\": {}}]}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		ProspectDeviceModelMapResponse respo = mapper.readValue(respString, ProspectDeviceModelMapResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(cartAEMService.getSKUDetail(Mockito.any())).thenReturn(Mono.just(respo));
		when(redisHelper3.updateByodDeviceDetailRedis(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		DeviceModelMap modelMap=new DeviceModelMap();
		modelMap.setModel("model");
		modelMap.setKey("VERIZON");
		PSim psim=new PSim();
		psim.setVERIZON("");
		modelMap.setPSim(psim);
		List<DeviceModelMap> list=new ArrayList<>();
		list.add(modelMap);
		respo.setDeviceModelMap(list);
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).expectError().verify();
	}

	@Test
	public void getDeviceCartMapTestOne() throws IOException {
		String sampleResponseString = "{\"data\":{\"cart\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"status\":\"A\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"cartCreator\":\"4434541510\",\"cartCreatorOrderLocationCode\":\"E248201\",\"cartCreatorSalesRepId\":\"ENC\",\"creditApplicationNum\":\"388936130\",\"secondaryCreditApplicationNum\":0},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"customerType\":\"U\",\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"totalTaxAmount\":\"38.75\",\"spocs\":{\"notificationOptions\":{\"contactPhoneNumber\":\"1196120299\",\"primaryEmailId\":\"YFOOWLTH659034@VZW.COM\"}},\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"instantCreditAmount\":0.0,\"instantCreditAmountRemaining\":0.0,\"instantCreditEligible\":false,\"orderList\":[{\"creditApplication\":{\"creditApplicationNum\":388936130,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CACVASAUTOMATICAPPROVAL\",\"internationalEligibility\":\"true\",\"creditAdvisory\":\"APP388936130APPROVED-WITHNODEPOSITREQUIRED'B'\",\"securityDepositAmount\":\"0\",\"serviceClass\":\"B\",\"lineCreditClass\":\"\"},\"orderActivityType\":\"EUP\",\"orderNumber\":\"1112\"}],\"orderNumber\":0,\"outletId\":\"124632\",\"registerNumber\":0,\"saleType\":\"P\",\"salesRepId\":\"ENC\",\"totalInstantCreditAmount\":0.0,\"totalInstantCreditAmountUsed\":0.0},\"lineDetails\":{\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"mldTrunkMTN\":0,\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"zipCode4\":\"7848\"},\"isValidAddress\":true},\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"currentDevice\":{\"oldLteVoraEquipInfo\":{\"iccid\":\"89148000004671963398\",\"lteVoraDeviceInfo\":{\"deviceId\":\"352530085081859\",\"deviceType\":\"4GE\"}}},\"isSharePlanAdded\":false,\"edgeLine\":false,\"vlcLine\":false,\"isE911AddressValidated\":false,\"oldPlanFlag\":\"L\",\"orderDevice\":{\"lteVoraEquipInfo\":{\"lteEqpt\":{},\"lteVoraDeviceInfo\":{}}}},\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"shippingCost\":\"0.0\",\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"isUseUnVerifiedAddress\":false,\"isValidAddress\":false},\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"mobileNumber\":\"4434541510\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"groupDiscInd\":0,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-thumb$\"},\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"color\":{\"color\":\"#cfbea9\",\"colorDisplayName\":\"GOLD/PINKSAND\"},\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"discounts\":[],\"availableReasonCode\":[],\"inventory\":{\"isAvailable\":true,\"isBackorder\":false,\"isPreOrder\":false,\"qtyAvailable\":39437.0},\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"numberShareEligible\":\"true\",\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0}]},\"isPromoSelected\":false,\"isTradeInSelected\":false}],\"lineIdentifier\":0,\"itemSeqNum5GL\":0,\"itemSeqNum4GR\":0,\"lineExchangeTotal\":0.0,\"lineRefundTotal\":0.0,\"isCpe\":false,\"isDevicePlanCompatible\":false,\"portinMtnAssignment\":false,\"impactedLine\":false,\"preOrBackOrder\":false,\"ispuItem\":true,\"ispuItemBYOD\":false}],\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"numofLinesAAL\":0,\"numofLinesEUP\":0,\"validationMessages\":[],\"payments\":[],\"lineSeq\":0,\"vlcactivePhoneCount\":0,\"fivegOrderind\":false,\"aceOrderCreated\":false,\"serviceLinesCreated\":false,\"aceItemsModified\":false,\"clnrOrderFlag\":false,\"broadbandInd\":false,\"isPaperLessBilling\":\"false\"}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveCartCXPResponse sampleCXPResponse = mapper.readValue(sampleResponseString, RetrieveCartCXPResponse.class);

		when(cxpService.deviceCountInCart(Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleCXPResponse));
		Mono<Map<String, String>> response=cxpHelper.getDeviceCartMap("3efad59a-f94e-45fa-9ed9-fd72aeae9bd5");
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getDeviceCartMapTestTwo() throws IOException {
		Mono<RetrieveCartCXPResponse> sampleCXPResponse =null;
		when(cxpService.deviceCountInCart("3efad59a-f94e-45fa-9ed9-fd72aeae9bd5", Boolean.FALSE,null)).thenReturn(sampleCXPResponse);
		Mono<Map<String, String>> response=cxpHelper.getDeviceCartMap("3efad59a-f94e-45fa-9ed9-fd72aeae9bd5");
		StepVerifier.create(response).expectNextCount(0).verifyComplete();
	}

	@Test
	public void getDeviceCartMapTestThree() throws IOException {
		Mono<Map<String, String>> response=cxpHelper.getDeviceCartMap("");
		StepVerifier.create(response).expectNextCount(0).verifyComplete();
	}

	@Test
	public void retrieveCartTest7() throws JsonParseException, JsonMappingException, IOException {
		ReflectionTestUtils.setField(cxpHelper, "enableOptimisedDigitalRetrieveCart", true);
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"meta\":{\"type\": \"NEWCUSTOMER\",\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"5560eeed-2ad2-4634-866b-c4986502594b\"}}";
		String sampleResponseString = "{\"data\":{\"cart\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"status\":\"A\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"cartCreator\":\"4434541510\",\"cartCreatorOrderLocationCode\":\"E248201\",\"cartCreatorSalesRepId\":\"ENC\",\"creditApplicationNum\":\"388936130\",\"secondaryCreditApplicationNum\":0},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"customerType\":\"U\",\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"totalTaxAmount\":\"38.75\",\"spocs\":{\"notificationOptions\":{\"contactPhoneNumber\":\"1196120299\",\"primaryEmailId\":\"YFOOWLTH659034@VZW.COM\"}},\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"instantCreditAmount\":0.0,\"instantCreditAmountRemaining\":0.0,\"instantCreditEligible\":false,\"orderList\":[{\"creditApplication\":{\"creditApplicationNum\":388936130,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CACVASAUTOMATICAPPROVAL\",\"internationalEligibility\":\"true\",\"creditAdvisory\":\"APP388936130APPROVED-WITHNODEPOSITREQUIRED'B'\",\"securityDepositAmount\":\"0\",\"serviceClass\":\"B\",\"lineCreditClass\":\"\"},\"orderActivityType\":\"EUP\",\"orderNumber\":\"1112\"}],\"orderNumber\":0,\"outletId\":\"124632\",\"registerNumber\":0,\"saleType\":\"P\",\"salesRepId\":\"ENC\",\"totalInstantCreditAmount\":0.0,\"totalInstantCreditAmountUsed\":0.0},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"numofLinesAAL\":0,\"numofLinesEUP\":0,\"validationMessages\":[],\"payments\":[],\"lineSeq\":0,\"vlcactivePhoneCount\":0,\"fivegOrderind\":false,\"aceOrderCreated\":false,\"serviceLinesCreated\":false,\"aceItemsModified\":false,\"clnrOrderFlag\":false,\"broadbandInd\":false,\"isPaperLessBilling\":\"false\"}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveCartCXPRequest request = mapper.readValue(sampleRequestString, RetrieveCartCXPRequest.class);
		RetrieveCartCXPResponse sampleCXPResponse = mapper.readValue(sampleResponseString, RetrieveCartCXPResponse.class);
		Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
		when(cxpService.retrieveCart(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sampleCXPResponseMono);
		when(catalogService.getCatalogRefData(Mockito.any())).thenReturn(Mono.just(new CatalogResponse()));
		when(cxpService.retrieveCartNewCustomer(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sampleCXPResponseMono);
		when(redisHelper3.upsertCartCreator(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<RetrieveCartUIResponse> UIResponse = cxpHelper.retrieveCart(request);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
	}

	@Test
	public void retrieveCartTest8() throws JsonParseException, JsonMappingException, IOException {
		ReflectionTestUtils.setField(cxpHelper, "enableOptimisedDigitalRetrieveCart", true);
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"meta\":{\"type\": \"deviceItemsCountInCart\",\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"5560eeed-2ad2-4634-866b-c4986502594b\"}}";
		String sampleResponseString = "{\"data\":{\"cart\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"status\":\"A\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"cartCreator\":\"4434541510\",\"cartCreatorOrderLocationCode\":\"E248201\",\"cartCreatorSalesRepId\":\"ENC\",\"creditApplicationNum\":\"388936130\",\"secondaryCreditApplicationNum\":0},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"customerType\":\"U\",\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"totalTaxAmount\":\"38.75\",\"spocs\":{\"notificationOptions\":{\"contactPhoneNumber\":\"1196120299\",\"primaryEmailId\":\"YFOOWLTH659034@VZW.COM\"}},\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"instantCreditAmount\":0.0,\"instantCreditAmountRemaining\":0.0,\"instantCreditEligible\":false,\"orderList\":[{\"creditApplication\":{\"creditApplicationNum\":388936130,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CACVASAUTOMATICAPPROVAL\",\"internationalEligibility\":\"true\",\"creditAdvisory\":\"APP388936130APPROVED-WITHNODEPOSITREQUIRED'B'\",\"securityDepositAmount\":\"0\",\"serviceClass\":\"B\",\"lineCreditClass\":\"\"},\"orderActivityType\":\"EUP\",\"orderNumber\":\"1112\"}],\"orderNumber\":0,\"outletId\":\"124632\",\"registerNumber\":0,\"saleType\":\"P\",\"salesRepId\":\"ENC\",\"totalInstantCreditAmount\":0.0,\"totalInstantCreditAmountUsed\":0.0}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveCartCXPRequest request = mapper.readValue(sampleRequestString, RetrieveCartCXPRequest.class);
		RetrieveCartCXPResponse sampleCXPResponse = mapper.readValue(sampleResponseString, RetrieveCartCXPResponse.class);
		Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
		when(cxpService.retrieveCart(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sampleCXPResponseMono);
		when(catalogService.getCatalogRefData(Mockito.any())).thenReturn(Mono.just(new CatalogResponse()));
		when(cxpService.deviceCountInCart(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sampleCXPResponseMono);
		when(redisHelper3.upsertCartCreator(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<RetrieveCartUIResponse> UIResponse = cxpHelper.retrieveCart(request);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
	}

	@Test
	public void retrieveCartTest9() throws JsonParseException, JsonMappingException, IOException {
		ReflectionTestUtils.setField(cxpHelper, "enableOptimisedDigitalRetrieveCart", true);
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"meta\":{\"type\": \"\",\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"5560eeed-2ad2-4634-866b-c4986502594b\"}}";
		String sampleResponseString = "{\"data\":{},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveCartCXPRequest request = mapper.readValue(sampleRequestString, RetrieveCartCXPRequest.class);
		RetrieveCartCXPResponse sampleCXPResponse = mapper.readValue(sampleResponseString, RetrieveCartCXPResponse.class);
		Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
		when(cxpService.retrieveCart(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sampleCXPResponseMono);
		when(catalogService.getCatalogRefData(Mockito.any())).thenReturn(Mono.just(new CatalogResponse()));
		when(cxpService.cartItems(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sampleCXPResponseMono);
		when(redisHelper3.upsertCartCreator(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<RetrieveCartUIResponse> UIResponse = cxpHelper.retrieveCart(request);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
	}

	@Test
	public void retrieveCartTest10() throws JsonParseException, JsonMappingException, IOException {
		ReflectionTestUtils.setField(cxpHelper,"noPromoDQreasonCodesList",Arrays.asList("CE,CR,CU,FR,FX,LN,MX,SN,UN,WP".split(",")));
		ReflectionTestUtils.setField(cxpHelper, "enableOptimisedDigitalRetrieveCart", true);
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"meta\":{\"type\": \"cartItems\",\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"5560eeed-2ad2-4634-866b-c4986502594b\"}}";
		String sampleResponseString = "{\"data\":{\"cart\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"status\":\"A\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"cartCreator\":\"4434541510\",\"cartCreatorOrderLocationCode\":\"E248201\",\"cartCreatorSalesRepId\":\"ENC\",\"creditApplicationNum\":\"388936130\",\"secondaryCreditApplicationNum\":0},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"customerType\":\"U\",\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"totalTaxAmount\":\"38.75\",\"spocs\":{\"notificationOptions\":{\"contactPhoneNumber\":\"1196120299\",\"primaryEmailId\":\"YFOOWLTH659034@VZW.COM\"}},\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"instantCreditAmount\":0.0,\"instantCreditAmountRemaining\":0.0,\"instantCreditEligible\":false,\"orderList\":[{\"creditApplication\":{\"creditApplicationNum\":388936130,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CACVASAUTOMATICAPPROVAL\",\"internationalEligibility\":\"true\",\"creditAdvisory\":\"APP388936130APPROVED-WITHNODEPOSITREQUIRED'B'\",\"securityDepositAmount\":\"0\",\"serviceClass\":\"B\",\"lineCreditClass\":\"\"},\"orderActivityType\":\"EUP\",\"orderNumber\":\"1112\"}],\"orderNumber\":0,\"outletId\":\"124632\",\"registerNumber\":0,\"saleType\":\"P\",\"salesRepId\":\"ENC\",\"totalInstantCreditAmount\":0.0,\"totalInstantCreditAmountUsed\":0.0},\"lineDetails\":{\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"selectedFeaturesList\": {},\"newPricePlanId\": \"new\",\"mldTrunkMTN\":0,\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"zipCode4\":\"7848\"},\"isValidAddress\":true},\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"currentDevice\":{\"oldLteVoraEquipInfo\":{\"iccid\":\"89148000004671963398\",\"lteVoraDeviceInfo\":{\"deviceId\":\"352530085081859\",\"deviceType\":\"4GE\"}}},\"isSharePlanAdded\":false,\"edgeLine\":false,\"vlcLine\":false,\"isE911AddressValidated\":false,\"oldPlanFlag\":\"L\",\"orderDevice\":{\"lteVoraEquipInfo\":{\"lteEqpt\":{},\"lteVoraDeviceInfo\":{}}}},\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"shippingCost\":\"0.0\",\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"isUseUnVerifiedAddress\":false,\"isValidAddress\":false},\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"mobileNumber\":\"4434541510\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"groupDiscInd\":0,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-thumb$\"},\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"color\":{\"color\":\"#cfbea9\",\"colorDisplayName\":\"GOLD/PINKSAND\"},\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"discounts\":[],\"availableReasonCode\":[],\"inventory\":{\"isAvailable\":true,\"isBackorder\":false,\"isPreOrder\":false,\"qtyAvailable\":39437.0},\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"numberShareEligible\":\"true\",\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0}]},\"isPromoSelected\":false,\"isTradeInSelected\":false}],\"lineIdentifier\":0,\"itemSeqNum5GL\":0,\"itemSeqNum4GR\":0,\"lineExchangeTotal\":0.0,\"lineRefundTotal\":0.0,\"isCpe\":false,\"isDevicePlanCompatible\":false,\"portinMtnAssignment\":false,\"impactedLine\":false,\"preOrBackOrder\":false,\"ispuItem\":true,\"ispuItemBYOD\":false}],\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"numofLinesAAL\":0,\"numofLinesEUP\":0,\"validationMessages\":[],\"payments\":[],\"lineSeq\":0,\"vlcactivePhoneCount\":0,\"fivegOrderind\":false,\"aceOrderCreated\":false,\"serviceLinesCreated\":false,\"aceItemsModified\":false,\"clnrOrderFlag\":false,\"broadbandInd\":false,\"isPaperLessBilling\":\"false\"}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveCartCXPRequest request = mapper.readValue(sampleRequestString, RetrieveCartCXPRequest.class);
		RetrieveCartCXPResponse sampleCXPResponse = mapper.readValue(sampleResponseString, RetrieveCartCXPResponse.class);
		Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
		when(cxpService.retrieveCart(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sampleCXPResponseMono);
		when(catalogService.getCatalogRefData(Mockito.any())).thenReturn(Mono.just(new CatalogResponse()));
		when(cxpService.cartItems(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sampleCXPResponseMono);
		when(redisHelper3.upsertCartCreator(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<RetrieveCartUIResponse> UIResponse = cxpHelper.retrieveCart(request);
		when(featureFlagHelper.isLineInfoFeatureFlag()).thenReturn(true);
		when(catalogServiceHelper.getCatalogDomainData(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CatalogResponse()));
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
	}

	@Test
	public void retrieveCartTest11() throws JsonParseException, JsonMappingException, IOException {
		ReflectionTestUtils.setField(cxpHelper, "enableOptimisedDigitalRetrieveCart", true);
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"meta\":{\"type\": \"cartItems\",\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"5560eeed-2ad2-4634-866b-c4986502594b\"}}";
		String sampleResponseString = "{\"data\":{\"cart\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"status\":\"A\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"cartCreator\":\"4434541510\",\"cartCreatorOrderLocationCode\":\"E248201\",\"cartCreatorSalesRepId\":\"ENC\",\"creditApplicationNum\":\"388936130\",\"secondaryCreditApplicationNum\":0},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"customerType\":\"U\",\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"totalTaxAmount\":\"38.75\",\"spocs\":{\"notificationOptions\":{\"contactPhoneNumber\":\"1196120299\",\"primaryEmailId\":\"YFOOWLTH659034@VZW.COM\"}},\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"instantCreditAmount\":0.0,\"instantCreditAmountRemaining\":0.0,\"instantCreditEligible\":false,\"orderList\":[{\"creditApplication\":{\"creditApplicationNum\":388936130,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CACVASAUTOMATICAPPROVAL\",\"internationalEligibility\":\"true\",\"creditAdvisory\":\"APP388936130APPROVED-WITHNODEPOSITREQUIRED'B'\",\"securityDepositAmount\":\"0\",\"serviceClass\":\"B\",\"lineCreditClass\":\"\"},\"orderActivityType\":\"EUP\",\"orderNumber\":\"1112\"}],\"orderNumber\":0,\"outletId\":\"124632\",\"registerNumber\":0,\"saleType\":\"P\",\"salesRepId\":\"ENC\",\"totalInstantCreditAmount\":0.0,\"totalInstantCreditAmountUsed\":0.0},\"lineDetails\":{\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"selectedFeaturesList\": {\"visFeature\": [null]},\"newPricePlanId\": \"new\",\"mldTrunkMTN\":0,\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"zipCode4\":\"7848\"},\"isValidAddress\":true},\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"currentDevice\":{\"oldLteVoraEquipInfo\":{\"iccid\":\"89148000004671963398\",\"lteVoraDeviceInfo\":{\"deviceId\":\"352530085081859\",\"deviceType\":\"4GE\"}}},\"isSharePlanAdded\":false,\"edgeLine\":false,\"vlcLine\":false,\"isE911AddressValidated\":false,\"oldPlanFlag\":\"L\",\"orderDevice\":{\"lteVoraEquipInfo\":{\"lteEqpt\":{},\"lteVoraDeviceInfo\":{}}}},\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"shippingCost\":\"0.0\",\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"isUseUnVerifiedAddress\":false,\"isValidAddress\":false},\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"totalPriceWithDiscount\": 70.00,\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"accessory\",\"mobileNumber\":\"4434541510\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"groupDiscInd\":0,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-thumb$\"},\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"color\":{\"color\":\"#cfbea9\",\"colorDisplayName\":\"GOLD/PINKSAND\"},\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"discounts\":[],\"availableReasonCode\":[],\"inventory\":{\"isAvailable\":true,\"isBackorder\":false,\"isPreOrder\":false,\"qtyAvailable\":39437.0},\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"numberShareEligible\":\"true\",\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0}]},\"isPromoSelected\":false,\"isTradeInSelected\":false}],\"lineIdentifier\":0,\"itemSeqNum5GL\":0,\"itemSeqNum4GR\":0,\"lineExchangeTotal\":0.0,\"lineRefundTotal\":0.0,\"isCpe\":false,\"isDevicePlanCompatible\":false,\"portinMtnAssignment\":false,\"impactedLine\":false,\"preOrBackOrder\":false,\"ispuItem\":true,\"ispuItemBYOD\":false}],\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"numofLinesAAL\":0,\"numofLinesEUP\":0,\"validationMessages\":[],\"payments\":[],\"lineSeq\":0,\"vlcactivePhoneCount\":0,\"fivegOrderind\":false,\"aceOrderCreated\":false,\"serviceLinesCreated\":false,\"aceItemsModified\":false,\"clnrOrderFlag\":false,\"broadbandInd\":false,\"isPaperLessBilling\":\"false\"}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveCartCXPRequest request = mapper.readValue(sampleRequestString, RetrieveCartCXPRequest.class);
		RetrieveCartCXPResponse sampleCXPResponse = mapper.readValue(sampleResponseString, RetrieveCartCXPResponse.class);
		Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
		when(cxpService.retrieveCart(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sampleCXPResponseMono);
		when(catalogService.getCatalogRefData(Mockito.any())).thenReturn(Mono.just(new CatalogResponse()));
		when(catalogServiceHelper.getCatalogDomainData(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CatalogResponse()));
		when(cxpService.cartItems(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sampleCXPResponseMono);
		when(redisHelper3.upsertCartCreator(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<RetrieveCartUIResponse> UIResponse = cxpHelper.retrieveCart(request);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
	}

	@Test
	public void retrieveCartTest12() throws JsonParseException, JsonMappingException, IOException {
		ReflectionTestUtils.setField(cxpHelper, "enableOptimisedDigitalRetrieveCart", true);
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"meta\":{\"type\": \"cartItems\",\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"5560eeed-2ad2-4634-866b-c4986502594b\"}}";
		String sampleResponseString = "{\"data\":{\"cart\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"status\":\"A\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"cartCreator\":\"4434541510\",\"cartCreatorOrderLocationCode\":\"E248201\",\"cartCreatorSalesRepId\":\"ENC\",\"creditApplicationNum\":\"388936130\",\"secondaryCreditApplicationNum\":0},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"customerType\":\"U\",\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"totalTaxAmount\":\"38.75\",\"spocs\":{\"notificationOptions\":{\"contactPhoneNumber\":\"1196120299\",\"primaryEmailId\":\"YFOOWLTH659034@VZW.COM\"}},\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"instantCreditAmount\":0.0,\"instantCreditAmountRemaining\":0.0,\"instantCreditEligible\":false,\"orderList\":[{\"creditApplication\":{\"creditApplicationNum\":388936130,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CACVASAUTOMATICAPPROVAL\",\"internationalEligibility\":\"true\",\"creditAdvisory\":\"APP388936130APPROVED-WITHNODEPOSITREQUIRED'B'\",\"securityDepositAmount\":\"0\",\"serviceClass\":\"B\",\"lineCreditClass\":\"\"},\"orderActivityType\":\"EUP\",\"orderNumber\":\"1112\"}],\"orderNumber\":0,\"outletId\":\"124632\",\"registerNumber\":0,\"saleType\":\"P\",\"salesRepId\":\"ENC\",\"totalInstantCreditAmount\":0.0,\"totalInstantCreditAmountUsed\":0.0},\"lineDetails\":{\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"selectedFeaturesList\": {\"visFeature\": [{\"visFeatureCode\": \"1614\"}]},\"newPricePlanId\": \"new\",\"mldTrunkMTN\":0,\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"zipCode4\":\"7848\"},\"isValidAddress\":true},\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"currentDevice\":{\"oldLteVoraEquipInfo\":{\"iccid\":\"89148000004671963398\",\"lteVoraDeviceInfo\":{\"deviceId\":\"352530085081859\",\"deviceType\":\"4GE\"}}},\"isSharePlanAdded\":false,\"edgeLine\":false,\"vlcLine\":false,\"isE911AddressValidated\":false,\"oldPlanFlag\":\"L\",\"orderDevice\":{\"lteVoraEquipInfo\":{\"lteEqpt\":{},\"lteVoraDeviceInfo\":{}}}},\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"shippingCost\":\"0.0\",\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"isUseUnVerifiedAddress\":false,\"isValidAddress\":false},\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"totalPriceWithDiscount\": 60.00,\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"accessory\",\"mobileNumber\":\"4434541510\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"groupDiscInd\":0,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-thumb$\"},\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"color\":{\"color\":\"#cfbea9\",\"colorDisplayName\":\"GOLD/PINKSAND\"},\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"discounts\":[],\"availableReasonCode\":[],\"inventory\":{\"isAvailable\":true,\"isBackorder\":false,\"isPreOrder\":false,\"qtyAvailable\":39437.0},\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"numberShareEligible\":\"true\",\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0}]},\"isPromoSelected\":false,\"isTradeInSelected\":false}],\"lineIdentifier\":0,\"itemSeqNum5GL\":0,\"itemSeqNum4GR\":0,\"lineExchangeTotal\":0.0,\"lineRefundTotal\":0.0,\"isCpe\":false,\"isDevicePlanCompatible\":false,\"portinMtnAssignment\":false,\"impactedLine\":false,\"preOrBackOrder\":false,\"ispuItem\":true,\"ispuItemBYOD\":false}],\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"numofLinesAAL\":0,\"numofLinesEUP\":0,\"validationMessages\":[],\"payments\":[],\"lineSeq\":0,\"vlcactivePhoneCount\":0,\"fivegOrderind\":false,\"aceOrderCreated\":false,\"serviceLinesCreated\":false,\"aceItemsModified\":false,\"clnrOrderFlag\":false,\"broadbandInd\":false,\"isPaperLessBilling\":\"false\"}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveCartCXPRequest request = mapper.readValue(sampleRequestString, RetrieveCartCXPRequest.class);
		RetrieveCartCXPResponse sampleCXPResponse = mapper.readValue(sampleResponseString, RetrieveCartCXPResponse.class);
		Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
		when(cxpService.retrieveCart(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sampleCXPResponseMono);
		when(catalogService.getCatalogRefData(Mockito.any())).thenReturn(Mono.just(new CatalogResponse()));
		when(catalogServiceHelper.getCatalogDomainData(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CatalogResponse()));
		when(cxpService.cartItems(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sampleCXPResponseMono);
		when(redisHelper3.upsertCartCreator(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<RetrieveCartUIResponse> UIResponse = cxpHelper.retrieveCart(request);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
	}

	@Test
	public void retrieveCartTest13() throws JsonParseException, JsonMappingException, IOException {
		ReflectionTestUtils.setField(cxpHelper, "enableOptimisedDigitalRetrieveCart", true);
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"meta\":{\"type\": \"cartItems\",\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"5560eeed-2ad2-4634-866b-c4986502594b\"}}";
		String sampleResponseString = "{\"data\":{\"cart\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"status\":\"A\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"cartCreator\":\"4434541510\",\"cartCreatorOrderLocationCode\":\"E248201\",\"cartCreatorSalesRepId\":\"ENC\",\"creditApplicationNum\":\"388936130\",\"secondaryCreditApplicationNum\":0},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"customerType\":\"U\",\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"totalTaxAmount\":\"38.75\",\"spocs\":{\"notificationOptions\":{\"contactPhoneNumber\":\"1196120299\",\"primaryEmailId\":\"YFOOWLTH659034@VZW.COM\"}},\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"instantCreditAmount\":0.0,\"instantCreditAmountRemaining\":0.0,\"instantCreditEligible\":false,\"orderList\":[{\"creditApplication\":{\"creditApplicationNum\":388936130,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CACVASAUTOMATICAPPROVAL\",\"internationalEligibility\":\"true\",\"creditAdvisory\":\"APP388936130APPROVED-WITHNODEPOSITREQUIRED'B'\",\"securityDepositAmount\":\"0\",\"serviceClass\":\"B\",\"lineCreditClass\":\"\"},\"orderActivityType\":\"EUP\",\"orderNumber\":\"1112\"}],\"orderNumber\":0,\"outletId\":\"124632\",\"registerNumber\":0,\"saleType\":\"P\",\"salesRepId\":\"ENC\",\"totalInstantCreditAmount\":0.0,\"totalInstantCreditAmountUsed\":0.0},\"lineDetails\":{\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"selectedFeaturesList\": {\"visFeature\": [{}]},\"newPricePlanId\": \"new\",\"mldTrunkMTN\":0,\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"zipCode4\":\"7848\"},\"isValidAddress\":true},\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"currentDevice\":{\"oldLteVoraEquipInfo\":{\"iccid\":\"89148000004671963398\",\"lteVoraDeviceInfo\":{\"deviceId\":\"352530085081859\",\"deviceType\":\"4GE\"}}},\"isSharePlanAdded\":false,\"edgeLine\":false,\"vlcLine\":false,\"isE911AddressValidated\":false,\"oldPlanFlag\":\"L\",\"orderDevice\":{\"lteVoraEquipInfo\":{\"lteEqpt\":{},\"lteVoraDeviceInfo\":{}}}},\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"shippingCost\":\"0.0\",\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"isUseUnVerifiedAddress\":false,\"isValidAddress\":false},\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"totalPriceWithDiscount\": 60.00,\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"accessory\",\"mobileNumber\":\"4434541510\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"groupDiscInd\":0,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-thumb$\"},\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"color\":{\"color\":\"#cfbea9\",\"colorDisplayName\":\"GOLD/PINKSAND\"},\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"discounts\":[],\"availableReasonCode\":[],\"inventory\":{\"isAvailable\":true,\"isBackorder\":false,\"isPreOrder\":false,\"qtyAvailable\":39437.0},\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"numberShareEligible\":\"true\",\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0}]},\"isPromoSelected\":false,\"isTradeInSelected\":false}],\"lineIdentifier\":0,\"itemSeqNum5GL\":0,\"itemSeqNum4GR\":0,\"lineExchangeTotal\":0.0,\"lineRefundTotal\":0.0,\"isCpe\":false,\"isDevicePlanCompatible\":false,\"portinMtnAssignment\":false,\"impactedLine\":false,\"preOrBackOrder\":false,\"ispuItem\":true,\"ispuItemBYOD\":false}],\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"numofLinesAAL\":0,\"numofLinesEUP\":0,\"validationMessages\":[],\"payments\":[],\"lineSeq\":0,\"vlcactivePhoneCount\":0,\"fivegOrderind\":false,\"aceOrderCreated\":false,\"serviceLinesCreated\":false,\"aceItemsModified\":false,\"clnrOrderFlag\":false,\"broadbandInd\":false,\"isPaperLessBilling\":\"false\"}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveCartCXPRequest request = mapper.readValue(sampleRequestString, RetrieveCartCXPRequest.class);
		RetrieveCartCXPResponse sampleCXPResponse = mapper.readValue(sampleResponseString, RetrieveCartCXPResponse.class);
		Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
		when(cxpService.retrieveCart(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sampleCXPResponseMono);
		when(catalogService.getCatalogRefData(Mockito.any())).thenReturn(Mono.just(new CatalogResponse()));
		when(catalogServiceHelper.getCatalogDomainData(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CatalogResponse()));
		when(cxpService.cartItems(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sampleCXPResponseMono);
		when(redisHelper3.upsertCartCreator(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<RetrieveCartUIResponse> UIResponse = cxpHelper.retrieveCart(request);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
	}

	@Test
	public void retrieveCartTest14() throws JsonParseException, JsonMappingException, IOException {
		ReflectionTestUtils.setField(cxpHelper, "enableOptimisedDigitalRetrieveCart", true);
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"meta\":{\"type\": \"cartItems\",\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"5560eeed-2ad2-4634-866b-c4986502594b\"}}";
		String sampleResponseString = "{\"data\":{\"cart\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"status\":\"A\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"cartCreator\":\"4434541510\",\"cartCreatorOrderLocationCode\":\"E248201\",\"cartCreatorSalesRepId\":\"ENC\",\"creditApplicationNum\":\"388936130\",\"secondaryCreditApplicationNum\":0},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"customerType\":\"U\",\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"totalTaxAmount\":\"38.75\",\"spocs\":{\"notificationOptions\":{\"contactPhoneNumber\":\"1196120299\",\"primaryEmailId\":\"YFOOWLTH659034@VZW.COM\"}},\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"instantCreditAmount\":0.0,\"instantCreditAmountRemaining\":0.0,\"instantCreditEligible\":false,\"orderList\":[{\"creditApplication\":{\"creditApplicationNum\":388936130,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CACVASAUTOMATICAPPROVAL\",\"internationalEligibility\":\"true\",\"creditAdvisory\":\"APP388936130APPROVED-WITHNODEPOSITREQUIRED'B'\",\"securityDepositAmount\":\"0\",\"serviceClass\":\"B\",\"lineCreditClass\":\"\"},\"orderActivityType\":\"EUP\",\"orderNumber\":\"1112\"}],\"orderNumber\":0,\"outletId\":\"124632\",\"registerNumber\":0,\"saleType\":\"P\",\"salesRepId\":\"ENC\",\"totalInstantCreditAmount\":0.0,\"totalInstantCreditAmountUsed\":0.0},\"lineDetails\":{\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"selectedFeaturesList\": {\"visFeature\": [{\"visFeatureCode\": \"16\"}]},\"newPricePlanId\": \"new\",\"mldTrunkMTN\":0,\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"zipCode4\":\"7848\"},\"isValidAddress\":true},\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"currentDevice\":{\"oldLteVoraEquipInfo\":{\"iccid\":\"89148000004671963398\",\"lteVoraDeviceInfo\":{\"deviceId\":\"352530085081859\",\"deviceType\":\"4GE\"}}},\"isSharePlanAdded\":false,\"edgeLine\":false,\"vlcLine\":false,\"isE911AddressValidated\":false,\"oldPlanFlag\":\"L\",\"orderDevice\":{\"lteVoraEquipInfo\":{\"lteEqpt\":{},\"lteVoraDeviceInfo\":{}}}},\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"shippingCost\":\"0.0\",\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"isUseUnVerifiedAddress\":false,\"isValidAddress\":false},\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"totalPriceWithDiscount\": 60.00,\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"accessory\",\"mobileNumber\":\"4434541510\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"groupDiscInd\":0,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-thumb$\"},\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"color\":{\"color\":\"#cfbea9\",\"colorDisplayName\":\"GOLD/PINKSAND\"},\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"discounts\":[],\"availableReasonCode\":[],\"inventory\":{\"isAvailable\":true,\"isBackorder\":false,\"isPreOrder\":false,\"qtyAvailable\":39437.0},\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"numberShareEligible\":\"true\",\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0}]},\"isPromoSelected\":false,\"isTradeInSelected\":false}],\"lineIdentifier\":0,\"itemSeqNum5GL\":0,\"itemSeqNum4GR\":0,\"lineExchangeTotal\":0.0,\"lineRefundTotal\":0.0,\"isCpe\":false,\"isDevicePlanCompatible\":false,\"portinMtnAssignment\":false,\"impactedLine\":false,\"preOrBackOrder\":false,\"ispuItem\":true,\"ispuItemBYOD\":false}],\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"numofLinesAAL\":0,\"numofLinesEUP\":0,\"validationMessages\":[],\"payments\":[],\"lineSeq\":0,\"vlcactivePhoneCount\":0,\"fivegOrderind\":false,\"aceOrderCreated\":false,\"serviceLinesCreated\":false,\"aceItemsModified\":false,\"clnrOrderFlag\":false,\"broadbandInd\":false,\"isPaperLessBilling\":\"false\"}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveCartCXPRequest request = mapper.readValue(sampleRequestString, RetrieveCartCXPRequest.class);
		RetrieveCartCXPResponse sampleCXPResponse = mapper.readValue(sampleResponseString, RetrieveCartCXPResponse.class);
		Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
		when(cxpService.retrieveCart(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sampleCXPResponseMono);
		when(catalogService.getCatalogRefData(Mockito.any())).thenReturn(Mono.just(new CatalogResponse()));
		when(catalogServiceHelper.getCatalogDomainData(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CatalogResponse()));
		when(cxpService.cartItems(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sampleCXPResponseMono);
		when(redisHelper3.upsertCartCreator(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<RetrieveCartUIResponse> UIResponse = cxpHelper.retrieveCart(request);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
	}

	@Test
	public void retrieveCartTest15() throws JsonParseException, JsonMappingException, IOException {
		ReflectionTestUtils.setField(cxpHelper, "enableOptimisedDigitalRetrieveCart", true);
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"meta\":{\"type\": \"\",\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"5560eeed-2ad2-4634-866b-c4986502594b\"}}";
		String sampleResponseString = "{\"data\":{\"cart\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"status\":\"A\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"cartCreator\":\"4434541510\",\"cartCreatorOrderLocationCode\":\"E248201\",\"cartCreatorSalesRepId\":\"ENC\",\"creditApplicationNum\":\"388936130\",\"secondaryCreditApplicationNum\":0},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"customerType\":\"U\",\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"totalTaxAmount\":\"38.75\",\"spocs\":{\"notificationOptions\":{\"contactPhoneNumber\":\"1196120299\",\"primaryEmailId\":\"YFOOWLTH659034@VZW.COM\"}},\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"instantCreditAmount\":0.0,\"instantCreditAmountRemaining\":0.0,\"instantCreditEligible\":false,\"orderList\":[{\"creditApplication\":{\"creditApplicationNum\":388936130,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CACVASAUTOMATICAPPROVAL\",\"internationalEligibility\":\"true\",\"creditAdvisory\":\"APP388936130APPROVED-WITHNODEPOSITREQUIRED'B'\",\"securityDepositAmount\":\"0\",\"serviceClass\":\"B\",\"lineCreditClass\":\"\"},\"orderActivityType\":\"EUP\",\"orderNumber\":\"1112\"}],\"orderNumber\":0,\"outletId\":\"124632\",\"registerNumber\":0,\"saleType\":\"P\",\"salesRepId\":\"ENC\",\"totalInstantCreditAmount\":0.0,\"totalInstantCreditAmountUsed\":0.0},\"lineDetails\":{\"lineInfo\":[{\"itemsInfo\":[{\"cartItems\":{\"cartItem\":[{\"cartItemType\":\"ACCESSORY\",\"sorId\":\"JBLPARTYBOXGOBAM\",\"bmsmBonusSelected\": true,\"promoHubOfferList\":{\"promoHubOfferList\":[{\"offerId\":\"600908\",\"promoType\":\"Accessory-Bonus-Offer\",\"eligibleSkuList\":[\"JBLPARTYBOXGOBAM\"]}]}}]}}],\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"lineIdentifier\":0,\"itemSeqNum5GL\":0,\"itemSeqNum4GR\":0,\"lineExchangeTotal\":0.0,\"lineRefundTotal\":0.0,\"isCpe\":false,\"isDevicePlanCompatible\":false,\"portinMtnAssignment\":false,\"impactedLine\":false,\"preOrBackOrder\":false,\"ispuItem\":true,\"ispuItemBYOD\":false}],\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"numofLinesAAL\":0,\"numofLinesEUP\":0,\"validationMessages\":[],\"payments\":[],\"lineSeq\":0,\"vlcactivePhoneCount\":0,\"fivegOrderind\":false,\"aceOrderCreated\":false,\"serviceLinesCreated\":false,\"aceItemsModified\":false,\"clnrOrderFlag\":false,\"broadbandInd\":false,\"isPaperLessBilling\":\"false\"}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveCartCXPRequest request = mapper.readValue(sampleRequestString, RetrieveCartCXPRequest.class);
		RetrieveCartCXPResponse sampleCXPResponse = mapper.readValue(sampleResponseString, RetrieveCartCXPResponse.class);
		Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
		when(cxpService.retrieveCart(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sampleCXPResponseMono);
		when(catalogService.getCatalogRefData(Mockito.any())).thenReturn(Mono.just(new CatalogResponse()));
		when(catalogServiceHelper.getCatalogDomainData(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CatalogResponse()));
		when(cxpService.cartItems(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sampleCXPResponseMono);
		when(redisHelper3.upsertCartCreator(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<RetrieveCartUIResponse> UIResponse = cxpHelper.retrieveCart(request);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
	}

	@Test
	public void retrieveCartTest16() throws JsonParseException, JsonMappingException, IOException {
		ReflectionTestUtils.setField(cxpHelper, "enableOptimisedDigitalRetrieveCart", true);
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"meta\":{\"type\": \"\",\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"5560eeed-2ad2-4634-866b-c4986502594b\"}}";
		String sampleResponseString = "{\"data\":{},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveCartCXPRequest request = mapper.readValue(sampleRequestString, RetrieveCartCXPRequest.class);
		RetrieveCartCXPResponse sampleCXPResponse = mapper.readValue(sampleResponseString, RetrieveCartCXPResponse.class);
		Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
		when(cxpService.retrieveCart(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sampleCXPResponseMono);
		when(catalogService.getCatalogRefData(Mockito.any())).thenReturn(Mono.just(new CatalogResponse()));
		when(redisHelper3.upsertCartCreator(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<RetrieveCartUIResponse> UIResponse = cxpHelper.retrieveCart(request);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
	}

	@Test
	public void getAccessoryCartMapTest() throws IOException {
		String sampleResponseString = "{\"data\":{},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveCartCXPResponse sampleCXPResponse = mapper.readValue(sampleResponseString, RetrieveCartCXPResponse.class);
		when(cxpService.cartItems(Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleCXPResponse));
		Mono<Map<String, String>> response = cxpHelper.getAccessoryCartMap("");
		StepVerifier.create(response).expectComplete().verify();

		//Assertions.assertThrows(Exception.class, () -> cxpHelper.getAccessoryCartMap(""));
		//StepVerifier.create(cxpHelper.getAccessoryCartMap("random")).expectError();
	}

	@Test
	public void getAccessoryCartMapTest2() throws IOException {
		String sampleResponseString = "{\"data\":{},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveCartCXPResponse sampleCXPResponse = mapper.readValue(sampleResponseString, RetrieveCartCXPResponse.class);
		when(cxpService.cartItems(Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleCXPResponse));
		Mono<Map<String, String>> response = cxpHelper.getAccessoryCartMap("cartId");
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void validateCartTest4() throws JsonParseException, JsonMappingException, IOException {
		String sampleRequestString = "{\"meta\":{\"type\":\"newCustomer\",\"client\":\"B2C-TELESALES\"},\"cartId\":\"5560eeed-2ad2-4634-866b-c4986502594b\",\"channel\":\"assissted\",\"pageId\":\"landing\",\"flow\":\"upgrade\"}";
		String sampleResponseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"ACCESSORY\",\"cartHasPCD\":false,\"isPreconfigureEnabled\":true,\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
		ValidateCartCXPRequest request = mapper.readValue(sampleRequestString, ValidateCartCXPRequest.class);
		ValidateCartCXPResponse sampleCXPResponse = mapper.readValue(sampleResponseString, ValidateCartCXPResponse.class);
		Mono<ValidateCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
		when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just("XYZ"));
		when(redisHelper2.updateCartOrderFlowType(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		when(cxpService.validateCart(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(sampleCXPResponseMono);
		when(redisHelper2.upsertDeviceCartMapInRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		when(cxpService.validateCartNewCustomer(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(null);
		CartRedisData data=new CartRedisData();
		Mono<ValidateCartUIResponse> UIResponse = cxpHelper.validateCart(request,data);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void validateCartTest5() throws JsonParseException, JsonMappingException, IOException {
		String sampleRequestString = "{\"cartId\":\"5560eeed-2ad2-4634-866b-c4986502594b\",\"channel\":\"assissted\",\"pageId\":\"landing\",\"flow\":\"upgrade\"}";
		String sampleResponseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"ACCESSORY\",\"cartHasPCD\":false,\"isPreconfigureEnabled\":true,\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
		ValidateCartCXPRequest request = mapper.readValue(sampleRequestString, ValidateCartCXPRequest.class);
		ValidateCartCXPResponse sampleCXPResponse = mapper.readValue(sampleResponseString, ValidateCartCXPResponse.class);
		Mono<ValidateCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
		when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just("newCustomer"));
		when(redisHelper2.updateCartOrderFlowType(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		when(cxpService.validateCart(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sampleCXPResponseMono);
		when(redisHelper2.upsertDeviceCartMapInRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		when(cxpService.validateCartNewCustomer(Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ValidateCartCXPResponse()));
		CartRedisData data=new CartRedisData();
		Mono<ValidateCartUIResponse> UIResponse = cxpHelper.validateCart(request,data);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void validateCartTest6() throws JsonParseException, JsonMappingException, IOException {
		String sampleRequestString = "{\"meta\": {\"type\": \"newCustomer\"},\"cartId\":\"5560eeed-2ad2-4634-866b-c4986502594b\",\"channel\":\"assissted\",\"pageId\":\"landing\",\"flow\":\"upgrade\"}";
		String sampleResponseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"ACCESSORY\",\"cartHasPCD\":false,\"isPreconfigureEnabled\":true,\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
		ValidateCartCXPRequest request = mapper.readValue(sampleRequestString, ValidateCartCXPRequest.class);
		ValidateCartCXPResponse sampleCXPResponse = mapper.readValue(sampleResponseString, ValidateCartCXPResponse.class);
		Mono<ValidateCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
		when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just("newCustomer"));
		when(redisHelper2.updateCartOrderFlowType(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		when(cxpService.validateCart(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(sampleCXPResponseMono);
		when(redisHelper2.upsertDeviceCartMapInRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		when(cxpService.validateCartNewCustomer(Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ValidateCartCXPResponse()));
		CartRedisData data=new CartRedisData();
		Mono<ValidateCartUIResponse> UIResponse = cxpHelper.validateCart(request,data);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void validateCartTest7() throws JsonParseException, JsonMappingException, IOException {
		String sampleRequestString = "{\"meta\": {\"type\": \"newCustomer\"},\"cartId\":\"5560eeed-2ad2-4634-866b-c4986502594b\",\"channel\":\"assissted\",\"pageId\":\"landing\",\"flow\":\"upgrade\"}";
		String sampleResponseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"ACCESSORY\",\"cartHasPCD\":false,\"isPreconfigureEnabled\":true,\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
		ValidateCartCXPRequest request = mapper.readValue(sampleRequestString, ValidateCartCXPRequest.class);
		ValidateCartCXPResponse sampleCXPResponse = mapper.readValue(sampleResponseString, ValidateCartCXPResponse.class);
		Mono<ValidateCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
		when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just("nse"));
		when(redisHelper2.updateCartOrderFlowType(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		when(cxpService.validateCart(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(sampleCXPResponseMono);
		when(redisHelper2.upsertDeviceCartMapInRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		when(cxpService.validateCartNewCustomer(Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ValidateCartCXPResponse()));
		CartRedisData data=new CartRedisData();
		Mono<ValidateCartUIResponse> UIResponse = cxpHelper.validateCart(request,data);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void validateCartTest8() throws JsonParseException, JsonMappingException, IOException {
		String sampleRequestString = "{\"meta\": {\"type\": \"customer\"},\"cartId\":\"5560eeed-2ad2-4634-866b-c4986502594b\",\"channel\":\"assissted\",\"pageId\":\"landing\",\"flow\":\"upgrade\"}";
		String sampleResponseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"cartTotalDiscounts\":{\"totalDiscount\":\"200.0\",\"barCodeOfferAppliedOnOrder\":false,\"discountDetails\":[{\"discountType\":\"Instant\",\"noOfInstallments\":0,\"totalMonthlyDiscount\":\"200.0\",\"discountItems\":[{\"discountName\":\"IPHONE 14 PM 128 DEEP PURPLE\",\"discountAmount\":\"200.0\",\"promoType\":\"REBATE\",\"offerAmount\":\"200.0\"}]}]},\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"ACCESSORY\",\"cartHasPCD\":false,\"isPreconfigureEnabled\":true,\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
		ValidateCartCXPRequest request = mapper.readValue(sampleRequestString, ValidateCartCXPRequest.class);
		ValidateCartCXPResponse sampleCXPResponse = mapper.readValue(sampleResponseString, ValidateCartCXPResponse.class);
		Mono<ValidateCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
		when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just("nse"));
		when(redisHelper2.updateCartOrderFlowType(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		when(cxpService.validateCart(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sampleCXPResponseMono);
		when(redisHelper2.upsertDeviceCartMapInRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		when(cxpService.validateCartNewCustomer(Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ValidateCartCXPResponse()));
		CartRedisData data=new CartRedisData();
		Mono<ValidateCartUIResponse> UIResponse = cxpHelper.validateCart(request,data);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		sampleCXPResponse.getData().getValidateCartAndUpdate().getOrderDetails().getCartTotalDiscounts().getDiscountDetails().get(0).setDiscountItems(null);
		when(cxpService.validateCart(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(sampleCXPResponse));
		UIResponse = cxpHelper.validateCart(request,data);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		sampleCXPResponse.getData().getValidateCartAndUpdate().getOrderDetails().getCartTotalDiscounts().setDiscountDetails(null);
		when(cxpService.validateCart(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(sampleCXPResponse));
		UIResponse = cxpHelper.validateCart(request,data);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void validateCartTest9() throws JsonParseException, JsonMappingException, IOException {
		String sampleRequestString = "{\"meta\":{\"client\":\"VZW-DOTCOM\",\"type\":\"newCustomer\"},\"pageId\":\"PROMOHUB\",\"flow\":\"ShoppingCart\",\"enableFcc\":true,\"rtCartCount\":true,\"cartId\":\"\"}";
		String sampleResponseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"ACCESSORY\",\"cartHasPCD\":false,\"isPreconfigureEnabled\":true,\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
		ValidateCartCXPRequest request = mapper.readValue(sampleRequestString, ValidateCartCXPRequest.class);
		ValidateCartCXPResponse sampleCXPResponse = mapper.readValue(sampleResponseString, ValidateCartCXPResponse.class);
		Mono<ValidateCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
		when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just("newCustomer"));
		when(redisHelper2.updateCartOrderFlowType(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		when(cxpService.validateCart(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sampleCXPResponseMono);
		when(redisHelper2.upsertDeviceCartMapInRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		ValidateCartCXPResponse cxpResponse = mapper.readValue(new File("src/test/resources/ValidateCartRespForNewCustomer.json"), ValidateCartCXPResponse.class);
		when(cxpService.validateCartNewCustomer(Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(cxpResponse));
		when(redisHelper2.upsertDataInRedis(Mockito.any())).thenReturn(Mono.empty());
		CartRedisData data=new CartRedisData();
		request.getMeta().put("type","newCustomer");
		Mono<ValidateCartUIResponse> UIResponse = cxpHelper.validateCart(request,data);
		//doReturn("invalid").when(objectMapper.writeValueAsString(Mockito.any()));
		when(objectMapper.writeValueAsString(Mockito.any())).thenReturn("invalid");
		StepVerifier.create(UIResponse).assertNext(Assert::assertNotNull).expectComplete().verify();

		//isComboOrder empty
		cxpResponse.getData().getValidateCartAndUpdate().getOrderDetails().setIsComboOrder(null);
		when(cxpService.validateCartNewCustomer(Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(cxpResponse));
		when(redisHelper2.upsertDataInRedis(Mockito.any())).thenReturn(Mono.empty());
		Mono<ValidateCartUIResponse> UIResponse1 = cxpHelper.validateCart(request,new CartRedisData());
		StepVerifier.create(UIResponse1).assertNext(Assert::assertNotNull).expectComplete().verify();
	}

	@Test
	public void checkDfillInventoryTest2() throws IOException, SOEHTTPException {
		String sampleRequestString = "{ \"meta\": { \"timestamp\": 1579024925151, \"cxpCorrelationId\": \"2020-01-14T12:02:05.-0600:5c40a72e-3f8c-496e-ad98-a13d7174801c:WTX0109ALDITAUX:cxp-cart-domain:nsd2\" }, \"data\": { \"cartId\": \"d9cdae0c-0db2-496d-8f43-55d4e9d3d9fa\", \"statusCode\": 1, \"statusMsg\": \"Success\", \"lines\": [{ \"mtn\": \"2819001513\", \"status\": 1, \"planValidationFailed\": false, \"lineActivityType\": \"ACC\", \"currentPlanType\": \"LLP\", \"accessory\": { \"cartItemType\": \"ACCESSORY\", \"quantityOnHand\": 27037, \"description\": \"4G LTE Network Extender 2\" }, \"devicePlanCompatible\": false }, { \"mtn\": \"7346259623\", \"status\": 1, \"planValidationFailed\": false, \"lineActivityType\": \"BYOD\", \"currentPlanType\": \"LLP\", \"device\": { \"cartItemType\": \"DEVICE\", \"quantityOnHand\": 27037, \"description\": \"IPHONE XS SPACE GRAY 64GB VZ\" }, \"accessory\": { \"cartItemType\": \"ACCESSORY\", \"quantityOnHand\": 27037, \"description\": \"4G LTE Network Extender 2\" }, \"devicePlanCompatible\": false }], \"preAuthSuccess\": false, \"vztDiscountGain\": false, \"vztDiscountLoss\": false, \"financeLimitExceeded\": false, \"promoLossIndicator\": false, \"monthlyCreditAmount\": 0.0, \"agreementNumber\": 0 } }";
		CheckDfillInventoryUIRequest sampleRequest = mapper.readValue(sampleRequestString, CheckDfillInventoryUIRequest.class);
		when(cxpService.checkDfillInventory(Mockito.any())).thenReturn(null);
		Mono<CheckDfillInventoryUIResponse> respMono = cxpHelper2.checkDfillInventory(sampleRequest);
		StepVerifier.create(respMono).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getUpgradeReasonCodesTest2() throws IOException, SOEHTTPException {
		String sampleRequestString = "{ \"meta\": { \"timestamp\": 1579024925151, \"cxpCorrelationId\": \"2020-01-14T12:02:05.-0600:5c40a72e-3f8c-496e-ad98-a13d7174801c:WTX0109ALDITAUX:cxp-cart-domain:nsd2\" }, \"data\": { \"cartId\": \"d9cdae0c-0db2-496d-8f43-55d4e9d3d9fa\", \"statusCode\": 1, \"statusMsg\": \"Success\", \"lines\": [{ \"mtn\": \"2819001513\", \"status\": 1, \"planValidationFailed\": false, \"lineActivityType\": \"ACC\", \"currentPlanType\": \"LLP\", \"accessory\": { \"cartItemType\": \"ACCESSORY\", \"quantityOnHand\": 27037, \"description\": \"4G LTE Network Extender 2\" }, \"devicePlanCompatible\": false }, { \"mtn\": \"7346259623\", \"status\": 1, \"planValidationFailed\": false, \"lineActivityType\": \"BYOD\", \"currentPlanType\": \"LLP\", \"device\": { \"cartItemType\": \"DEVICE\", \"quantityOnHand\": 27037, \"description\": \"IPHONE XS SPACE GRAY 64GB VZ\" }, \"accessory\": { \"cartItemType\": \"ACCESSORY\", \"quantityOnHand\": 27037, \"description\": \"4G LTE Network Extender 2\" }, \"devicePlanCompatible\": false }], \"preAuthSuccess\": false, \"vztDiscountGain\": false, \"vztDiscountLoss\": false, \"financeLimitExceeded\": false, \"promoLossIndicator\": false, \"monthlyCreditAmount\": 0.0, \"agreementNumber\": 0 } }";
		GetUpgradeReasonCodeUIRequest sampleRequest = mapper.readValue(sampleRequestString, GetUpgradeReasonCodeUIRequest.class);
		when(cxpService.getUpgradeReasonCodes(Mockito.any())).thenReturn(null);
		Mono<GetUpgradeReasonCodeUIResponse> respMono = cxpHelper2.getUpgradeReasonCodes(sampleRequest);
		StepVerifier.create(respMono).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void customerNameByMtnTest() throws IOException, SOEHTTPException {
		when(cxpService.customerNameByMtn(Mockito.any())).thenReturn(Mono.just(new CustomerNameByMtnCXPResponse()));
		Mono<InitiateValidateDeviceSimUIResponse> respMono = cxpHelper2.customerNameByMtn(new ArrayList<String>());
		StepVerifier.create(respMono).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void customerNameByMtnTest2() throws IOException, SOEHTTPException {
		when(cxpService.customerNameByMtn(Mockito.any())).thenReturn(null);
		Mono<InitiateValidateDeviceSimUIResponse> respMono = cxpHelper2.customerNameByMtn(new ArrayList<String>());
		StepVerifier.create(respMono).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getConfirmationKibanaLogsCartDataFromCXPTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"data\": {\"validateCartAndUpdate\": {\"lineDetails\": {\"lineInfo\": [{\"itemsInfo\": [{\"cartItems\": {\"cartItem\": [{\"cartItemType\": \"DEVICE\"}]}}],\"bundleAccessoryInfo\": [{}]}],\"numOfAccessoryAndDeviceItemsInCart\": 0},\"globalPromotions\": {\"promoDetails\": [{}]}}}}";
		ValidateCartUIResponse request = mapper.readValue(requestString, ValidateCartUIResponse.class);
		System.setProperty("bvoAccepted", "random");
		System.setProperty("bvoRejected", "random");
		System.setProperty("bvoViewed", "random");
		cxpHelper.getConfirmationKibanaLogsCartDataFromCXP(request);
		cxpHelper.getConfirmationKibanaLogsCartDataFromCXP(null);
		System.setProperty("bvoAccepted", "");
		System.setProperty("bvoRejected", "");
		System.setProperty("bvoViewed", "");
		cxpHelper.getConfirmationKibanaLogsCartDataFromCXP(request);

	}

	@Test
	public void getConfirmationKibanaLogsCartDataFromCXPTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"data\": {\"validateCartAndUpdate\": {\"lineDetails\": {\"lineInfo\": [{\"itemsInfo\": [{\"cartItems\": {\"cartItem\": [{\"cartItemType\": \"DEVICE\"}]}}],\"bundleAccessoryInfo\": [],\"serviceInfo\": {\"selectedFeaturesList\": {\"visFeature\": [{\"protection\": true}]},\"pricePlanInfo\": {\"pricePlanDesc\": \"\",\"pricePlanCode\": \"\"},\"newPricePlanInfo\": {\"pricePlanDesc\": \"\",\"pricePlanCode\": \"\"}}}],\"numOfAccessoryAndDeviceItemsInCart\": 1},\"globalPromotions\": {\"promoDetails\": []}}}}";
		ValidateCartUIResponse request = mapper.readValue(requestString, ValidateCartUIResponse.class);
		cxpHelper.getConfirmationKibanaLogsCartDataFromCXP(request);
	}

	@Test
	public void getConfirmationKibanaLogsCartDataFromCXPTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"data\": {\"validateCartAndUpdate\": {\"lineDetails\": {\"lineInfo\": [{\"itemsInfo\": [{\"cartItems\": {\"cartItem\": [{\"cartItemType\": \"DEVICE\"}]}}],\"bundleAccessoryInfo\": [],\"serviceInfo\": {\"selectedFeaturesList\": {\"visFeature\": [{\"protection\": false}]},\"pricePlanInfo\": {},\"newPricePlanInfo\": {}}}]},\"globalPromotions\": {\"promoDetails\": [{\"promotionId\": \"\"}]}}}}";
		ValidateCartUIResponse request = mapper.readValue(requestString, ValidateCartUIResponse.class);
		cxpHelper.getConfirmationKibanaLogsCartDataFromCXP(request);
	}

	@Test
	public void getConfirmationKibanaLogsCartDataFromCXPTest4() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"data\": {\"validateCartAndUpdate\": {\"lineDetails\": {\"lineInfo\": [{\"itemsInfo\": [{\"cartItems\": {\"cartItem\": [{\"cartItemType\": \"DEVICE\"}]}}],\"bundleAccessoryInfo\": [],\"serviceInfo\": {\"selectedFeaturesList\": {\"visFeature\": []},\"pricePlanInfo\": {\"pricePlanDesc\": \"\"},\"newPricePlanInfo\": {\"pricePlanDesc\": \"\"}}}],\"numOfAccessoryAndDeviceItemsInCart\": 1},\"globalPromotions\": {\"promoDetails\": []}}}}";
		ValidateCartUIResponse request = mapper.readValue(requestString, ValidateCartUIResponse.class);
		cxpHelper.getConfirmationKibanaLogsCartDataFromCXP(request);
	}

	@Test
	public void getConfirmationKibanaLogsCartDataFromCXPTest5() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"data\": {\"validateCartAndUpdate\": {\"lineDetails\": {\"lineInfo\": [{\"itemsInfo\": [{\"cartItems\": {\"cartItem\": [{\"cartItemType\": \"DEVICE\"}]}}],\"bundleAccessoryInfo\": [],\"serviceInfo\": {\"selectedFeaturesList\": {},\"pricePlanInfo\": {\"pricePlanDesc\": \"\"},\"newPricePlanInfo\": {\"pricePlanDesc\": \"\"}}}],\"numOfAccessoryAndDeviceItemsInCart\": 1},\"globalPromotions\": {\"promoDetails\": []}}}}";
		ValidateCartUIResponse request = mapper.readValue(requestString, ValidateCartUIResponse.class);
		cxpHelper.getConfirmationKibanaLogsCartDataFromCXP(request);
	}

	@Test
	public void initiateBBPFlowTest4() throws IOException {
		String responseString = "{\"data\": {\"deviceInfo\": {\"deviceLock\": \"devicelock\"}}}";
		String dataString = "{\"bbpImei\": \"352898071702915\",\"bbpIccid\": \"89148000000835900458\",\"devid\": \"devid\"}";
		CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
		DeviceSimDetailsCxpResponse deviceSimDetailsCxpResponse = mapper.readValue(responseString, DeviceSimDetailsCxpResponse.class);
		when(cxpService.deviceSimDetails(Mockito.any())).thenReturn(Mono.just(deviceSimDetailsCxpResponse));
		Mono<DeviceSimDetailsUIResponse> respMono = cxpHelper2.initiateBBPFlow(data);
		StepVerifier.create(respMono).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void initiateBBPFlowTest5() throws IOException {
		String responseString = "{\"data\": {\"deviceInfo\": {\"deviceLock\": \"devicelock\"}}}";
		String dataString = "{\"bbpImei\": \"352898071702915\",\"bbpIccid\": \"89148000000835900458\",\"eid\": \"eid\",\"imei\": \"imei\"}";
		CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
		DeviceSimDetailsCxpResponse deviceSimDetailsCxpResponse = mapper.readValue(responseString, DeviceSimDetailsCxpResponse.class);
		when(cxpService.deviceSimDetails(Mockito.any())).thenReturn(Mono.just(deviceSimDetailsCxpResponse));
		Mono<DeviceSimDetailsUIResponse> respMono = cxpHelper2.initiateBBPFlow(data);
		StepVerifier.create(respMono).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void initiateBBPFlowTest6() throws IOException {
		String responseString = "{\"data\": {\"deviceInfo\": {\"deviceLock\": \"devicelock\"}}}";
		String dataString = "{\"bbpIccid\": \"89148000000835900458\",\"imei\": \"imei\"}";
		CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
		DeviceSimDetailsCxpResponse deviceSimDetailsCxpResponse = mapper.readValue(responseString, DeviceSimDetailsCxpResponse.class);
		when(cxpService.deviceSimDetails(Mockito.any())).thenReturn(Mono.just(deviceSimDetailsCxpResponse));
		Mono<DeviceSimDetailsUIResponse> respMono = cxpHelper2.initiateBBPFlow(data);
		StepVerifier.create(respMono).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deviceIdValidationTest21() throws IOException {
		String sampleRequestString = "{\"data\": {}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(null);
		sampleRequest.setCartInfo(new CartInfo());
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deviceIdValidationTest22() throws IOException {
		String sampleRequestString = "{\"data\": {}}";
		String sampleResponseString = "{\"client\": \"CXP\",\"data\": {\"lines\": [{\"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		sampleRequest.setCartInfo(new CartInfo());
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deviceIdValidationTest23() throws IOException {
		String sampleRequestString = "{\"data\": {\"lines\": [{}]}}";
		String sampleResponseString = "{\"client\": \"CXP\",\"data\": {\"lines\": [{\"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		sampleRequest.setCartInfo(new CartInfo());
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deviceIdValidationTest24() throws IOException {
		String sampleRequestString = "{\"channelId\": \"OMNI-CARE\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"mtn\": \"6159691822\",\"device\": {\"token\": \"\",\"smartIMEI\": false,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"giftbox\": {\"id\": \"LVSKPGB\"},\"sku\": \"\",\"sim\": {}}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\",\"data\": {\"lines\": [{\"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deviceIdValidationTest25() throws IOException {
		String sampleRequestString = "{\"channelId\": \"OMNI-CARE\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"mtn\": \"6159691822\",\"device\": {\"id\": \"\",\"token\": \"\",\"smartIMEI\": false,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"giftbox\": {\"id\": \"LVSKPGB\"},\"sku\": \"\",\"sim\": {}}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\",\"data\": {\"lines\": [{\"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deviceIdValidationTest26() throws IOException {
		String sampleRequestString = "{\"channelId\": \"OMNI-CARE\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"mtn\": \"6159691822\",\"device\": {\"id\": \"id\",\"token\": \"\",\"smartIMEI\": false,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"giftbox\": {\"id\": \"LVSKPGB\"},\"sku\": \"\",\"sim\": {}}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\",\"data\": {\"lines\": [{\"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deviceIdValidationTest27() throws IOException {
		String sampleRequestString = "{\"channelId\": \"OMNI-CARE\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"mtn\": \"6159691822\",\"device\": {\"id\": \"id\",\"smartIMEI\": false,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"giftbox\": {\"id\": \"LVSKPGB\"},\"sku\": \"\",\"sim\": {}}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\",\"data\": {\"lines\": [{\"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deviceIdValidationTest28() throws IOException {
		String sampleRequestString = "{\"channelId\": \"OMNI-CARE\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"mtn\": \"6159691822\",\"device\": {\"smartIMEI\": false,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"giftbox\": {\"id\": \"LVSKPGB\"},\"sku\": \"\",\"sim\": {}}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\",\"data\": {\"lines\": [{\"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deviceIdValidationTest29() throws IOException {
		String sampleRequestString = "{\"channelId\": \"OMNI-CARE\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"mtn\": \"6159691822\",\"device\": {\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"giftbox\": {\"id\": \"LVSKPGB\"},\"sku\": \"\",\"sim\": {}}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\",\"data\": {\"lines\": [{\"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deviceIdValidationTest30() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"mtn\": \"6159691822\",\"esimFlow\": false,\"device\": {\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"giftbox\": {\"id\": \"LVSKPGB\"}}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\",\"data\": {\"lines\": [{\"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deviceIdValidationTest31() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"mtn\": \"6159691822\",\"device\": {\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"giftbox\": {\"id\": \"LVSKPGB\"}}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\",\"data\": {\"lines\": [{\"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deviceIdValidationTest32() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"mtn\": \"6159691822\",\"device\": {\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"skuCarrier\": \"sku\",\"sorDisplayName\": \"sor\"}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\",\"data\": {\"lines\": [{\"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deviceIdValidationTest33() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"mtn\": \"6159691822\",\"device\": {\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"skuCarrier\": \"sku\",\"sorDisplayName\": \"sor\"}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\",\"data\": {\"lines\": [{\"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deviceIdValidationTest34() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"mtn\": \"6159691822\",\"esimFlow\": false,\"device\": {\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"skuCarrier\": \"sku\",\"sorDisplayName\": \"sor\"}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\",\"data\": {\"lines\": [{\"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		SearchAttributes value = mapper.readValue("{\"sku\": \"\"}", SearchAttributes.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deviceIdValidationTest35() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"editSim\": false,\"mtn\": \"6159691822\",\"esimFlow\": true,\"device\": {\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"skuCarrier\": \"sku\",\"sorDisplayName\": \"sor\"}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\",\"data\": {\"lines\": [{\"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		SearchAttributes value = mapper.readValue("{\"sku\": \"\"}", SearchAttributes.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deviceIdValidationTest36() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"editSim\": true,\"mtn\": \"6159691822\",\"esimFlow\": true,\"device\": {\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"skuCarrier\": \"sku\",\"sorDisplayName\": \"sor\"}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\",\"data\": {\"lines\": [{\"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		SearchAttributes value = mapper.readValue("{\"sku\": \"\"}", SearchAttributes.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deviceIdValidationTest37() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"editSim\": true,\"mtn\": \"6159691822\",\"esimFlow\": true,\"device\": {\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"skuCarrier\": \"sku\",\"sorDisplayName\": \"sor\",\"simSelected\": \"eSim\"}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\",\"data\": {\"lines\": [{\"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		SearchAttributes value = mapper.readValue("{\"sku\": \"\"}", SearchAttributes.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		//When(redisHelper2.getEsimSKUFromRedis()).thenReturn(Mono.just(""));
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deviceIdValidationTest38() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"editSim\": true,\"mtn\": \"6159691822\",\"esimFlow\": true,\"device\": {\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"skuCarrier\": \"sku\",\"sorDisplayName\": \"sor\",\"simSelected\": \"pSim\"}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\",\"data\": {\"lines\": [{\"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		SearchAttributes value = mapper.readValue("{\"sku\": \"\"}", SearchAttributes.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper3.getPsimSKUFromRedis()).thenReturn(Mono.just("psim"));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deviceIdValidationTest39() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"editSim\": false,\"mtn\": \"6159691822\",\"esimFlow\": true,\"device\": {\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"skuCarrier\": \"AT&T\",\"sorDisplayName\": \"sor\",\"identifier\": \"key\"}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\",\"data\": {\"lines\": [{\"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		String mapString = "{\"deviceModelMap\": [{\"Key\": \"key\"}]}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		SearchAttributes value = mapper.readValue("{\"sku\": \"\"}", SearchAttributes.class);
		ProspectDeviceModelMapResponse map = mapper.readValue(mapString, ProspectDeviceModelMapResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(cartAEMService.getSKUDetail(Mockito.any())).thenReturn(Mono.just(map));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).expectError().verify();
	}

	@Test
	public void deviceIdValidationTest40() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"editSim\": false,\"mtn\": \"6159691822\",\"esimFlow\": true,\"device\": {\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"skuCarrier\": \"AT&T\",\"sorDisplayName\": \"sor\",\"identifier\": \"key\"}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\",\"data\": {\"lines\": [{\"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		String mapString = "{\"deviceModelMap\": [{\"Key\": \"key\",\"eSim\": {},\"pSim\": {}}]}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		SearchAttributes value = mapper.readValue("{\"sku\": \"\"}", SearchAttributes.class);
		ProspectDeviceModelMapResponse map = mapper.readValue(mapString, ProspectDeviceModelMapResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(cartAEMService.getSKUDetail(Mockito.any())).thenReturn(Mono.just(map));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).expectError().verify();
	}

	@Test
	public void deviceIdValidationTest41() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"editSim\": false,\"mtn\": \"6159691822\",\"esimFlow\": true,\"device\": {\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"skuCarrier\": \"SPRINT\",\"sorDisplayName\": \"sor\",\"identifier\": \"key\"}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\",\"data\": {\"lines\": [{\"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		String mapString = "{\"deviceModelMap\": [{\"Key\": \"key\"}]}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		SearchAttributes value = mapper.readValue("{\"sku\": \"\"}", SearchAttributes.class);
		ProspectDeviceModelMapResponse map = mapper.readValue(mapString, ProspectDeviceModelMapResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(cartAEMService.getSKUDetail(Mockito.any())).thenReturn(Mono.just(map));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).expectError().verify();
	}

	@Test
	public void deviceIdValidationTest42() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"editSim\": false,\"mtn\": \"6159691822\",\"esimFlow\": true,\"device\": {\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"skuCarrier\": \"SPRINT\",\"sorDisplayName\": \"sor\",\"identifier\": \"key\"}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\",\"data\": {\"lines\": [{\"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		String mapString = "{\"deviceModelMap\": [{\"Key\": \"key\",\"eSim\": {},\"pSim\": {}}]}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		SearchAttributes value = mapper.readValue("{\"sku\": \"\"}", SearchAttributes.class);
		ProspectDeviceModelMapResponse map = mapper.readValue(mapString, ProspectDeviceModelMapResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(cartAEMService.getSKUDetail(Mockito.any())).thenReturn(Mono.just(map));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).expectError().verify();
	}

	@Test
	public void deviceIdValidationTest43() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"editSim\": false,\"mtn\": \"6159691822\",\"esimFlow\": true,\"device\": {\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"skuCarrier\": \"T-MOBILE\",\"sorDisplayName\": \"sor\",\"identifier\": \"key\"}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\",\"data\": {\"lines\": [{\"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		String mapString = "{\"deviceModelMap\": [{\"Key\": \"key\"}]}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		SearchAttributes value = mapper.readValue("{\"sku\": \"\"}", SearchAttributes.class);
		ProspectDeviceModelMapResponse map = mapper.readValue(mapString, ProspectDeviceModelMapResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(cartAEMService.getSKUDetail(Mockito.any())).thenReturn(Mono.just(map));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).expectError().verify();
	}

	@Test
	public void deviceIdValidationTest44() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"editSim\": false,\"mtn\": \"6159691822\",\"esimFlow\": true,\"device\": {\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"skuCarrier\": \"T-MOBILE\",\"sorDisplayName\": \"sor\",\"identifier\": \"key\"}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\",\"data\": {\"lines\": [{\"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		String mapString = "{\"deviceModelMap\": [{\"Key\": \"key\",\"eSim\": {},\"pSim\": {}}]}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		SearchAttributes value = mapper.readValue("{\"sku\": \"\"}", SearchAttributes.class);
		ProspectDeviceModelMapResponse map = mapper.readValue(mapString, ProspectDeviceModelMapResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(cartAEMService.getSKUDetail(Mockito.any())).thenReturn(Mono.just(map));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).expectError().verify();
	}

	@Test
	public void deviceIdValidationTest45() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"editSim\": false,\"mtn\": \"6159691822\",\"esimFlow\": true,\"device\": {\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"skuCarrier\": \"other\",\"sorDisplayName\": \"sor\",\"identifier\": \"key\"}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\",\"data\": {\"lines\": [{\"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		String mapString = "{\"deviceModelMap\": [{\"Key\": \"key\"}]}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		SearchAttributes value = mapper.readValue("{\"sku\": \"\"}", SearchAttributes.class);
		ProspectDeviceModelMapResponse map = mapper.readValue(mapString, ProspectDeviceModelMapResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(cartAEMService.getSKUDetail(Mockito.any())).thenReturn(Mono.just(map));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).expectError().verify();
	}

	@Test
	public void deviceIdValidationTest46() throws IOException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"editSim\": false,\"mtn\": \"6159691822\",\"esimFlow\": true,\"device\": {\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"skuCarrier\": \"other\",\"sorDisplayName\": \"sor\",\"identifier\": \"key\"}}]}}";
		String sampleResponseString = "{\"client\": \"CXP\",\"data\": {\"lines\": [{\"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		String mapString = "{\"deviceModelMap\": [{\"Key\": \"key\",\"eSim\": {},\"pSim\": {}}]}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		SearchAttributes value = mapper.readValue("{\"sku\": \"\"}", SearchAttributes.class);
		ProspectDeviceModelMapResponse map = mapper.readValue(mapString, ProspectDeviceModelMapResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(cartAEMService.getSKUDetail(Mockito.any())).thenReturn(Mono.just(map));
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		Mono<DeviceIdValidationUIResponse> response = cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes());
		StepVerifier.create(response).expectError().verify();
	}

	@Test
	public void addZipcodeTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",\"processingMTN\": \"\",\"intent\": \"5GHome\",\"processStep\": \"GridWallPDP\",\"processAction\": \"validateGiftBoxId\"},\"data\": {\"lines\": [{\"mtn\": \"6159691822\",\"esimFlow\": true,\"device\": {\"smartIMEI\": true,\"Flowtype\": \"GIFTBOX\",\"isCustomerProvidedEquipment\": true,\"skuCarrier\": \"sku\",\"sorDisplayName\": \"sor\"}}]}}";
		AddZipCodeUIRequest uiRequest = mapper.readValue(requestString, AddZipCodeUIRequest.class);
		AddZipcodeCXPResponse cxpResponse = mapper.readValue("{\"data\": {}}", AddZipcodeCXPResponse.class);
		when(cxpService.addZipcodeToCart(Mockito.any())).thenReturn(Mono.just(cxpResponse));
		Mono<AddZipcodeRedisData> response = cxpHelper2.addZipcode(uiRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void customerByMtnTest2() throws JsonMappingException, JsonProcessingException {
		when(cxpService.customerByMtn(Mockito.any())).thenReturn(null);
		Mono<CustomerByMtnUIResponse> response = cxpHelper2.customerByMtn(new CustomerReqType());
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		SOEErrorHolder SOEErrorHolderObj = new SOEErrorHolder();
		SOEErrorHolderObj.setErrors(Arrays.asList(new SOEError()));
		SOEHTTPException SOEHTTPExceptionObj = new SOEHTTPException(0,SOEErrorHolderObj);
		when(cxpService.customerByMtn(Mockito.any())).thenReturn(Mono.error(SOEHTTPExceptionObj));
		StepVerifier.create(cxpHelper2.customerByMtn(new CustomerReqType())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		SOEErrorHolderObj.setErrors(null);
		SOEHTTPExceptionObj = new SOEHTTPException(0,SOEErrorHolderObj);
		when(cxpService.customerByMtn(Mockito.any())).thenReturn(Mono.error(SOEHTTPExceptionObj));
		StepVerifier.create(cxpHelper2.customerByMtn(new CustomerReqType())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		SOEHTTPExceptionObj = new SOEHTTPException(0, (SOEErrorHolder) null);
		when(cxpService.customerByMtn(Mockito.any())).thenReturn(Mono.error(SOEHTTPExceptionObj));
		StepVerifier.create(cxpHelper2.customerByMtn(new CustomerReqType())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(cxpService.customerByMtn(Mockito.any())).thenReturn(Mono.error(IllegalArgumentException::new));
		StepVerifier.create(cxpHelper2.customerByMtn(new CustomerReqType())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void convertCXPResponseToUiResponseTest5() throws JsonMappingException, JsonProcessingException {
		String respString = "{\"data\": {\"smartImeiTypeAheadDetails\": [{\"makeTypeahead\": \"make\",\"modelName\": \"model\"}]}}";
		SmartImeiTypeAheadCXPResponse resp = mapper.readValue(respString , SmartImeiTypeAheadCXPResponse.class);
		String requestString = "{\"model\": \"make model\"}";
		SmartImeiTypeAheadSearchRequest uiRequest = mapper.readValue(requestString, SmartImeiTypeAheadSearchRequest.class);
		StepVerifier.create( cxpHelper.convertCXPResponseToUiResponse(resp, uiRequest)).assertNext( res -> Assert.assertNotNull(res));
	}

	@Test
	public void convertCXPResponseToUiResponseTest6() throws JsonMappingException, JsonProcessingException {
		String respString = "{\"data\": {\"smartImeiTypeAheadDetails\": [{\"carrier\": [],\"makeTypeahead\": \"maker\",\"modelName\": \"\"}]}}";
		SmartImeiTypeAheadCXPResponse resp = mapper.readValue(respString , SmartImeiTypeAheadCXPResponse.class);
		String requestString = "{\"deviceCategory\": \"device\",\"model\": \"model\"}";
		SmartImeiTypeAheadSearchRequest uiRequest = mapper.readValue(requestString, SmartImeiTypeAheadSearchRequest.class);
		StepVerifier.create( cxpHelper.convertCXPResponseToUiResponse(resp, uiRequest)).assertNext( res -> Assert.assertNotNull(res));
	}

	@Test
	public void populateOrderConfirmDLDataTest() throws IOException {
		String rcString = "{\"meta\": {\"timestamp\": \"1657188174021\",\"cxpCorrelationId\": \"2022-07-07T10:02:54.+0000:f31a40f2-3f07-4aef-964b-144961e4613e:cxp-shopping-services-qa-ev6v-sit2w-nscxp-7bbf5b5f49-lh9cr:nssit2\"},\"data\": {\"cart\": {\"cartHeader\": null,\"orderDetails\": {\"totalUpgradeFee\": 0,\"totalDeviceDollar\": 0,\"totalRemainingDeviceDollar\": 0,\"totalUsedDeviceDollar\": 0,\"totalAccountLevelAccCost\": 0,\"totalAccountLevelAccCostWithTax\": 0,\"verizonCardPromoOfferList\": [],\"taxDetailsList\": [],\"subTotalDueTodayWithoutUpgradeFee\": 0,\"subTotalDueMonthlyForAALBYODEUP\": 0,\"shipTogetherPref\": true,\"assistanceOptedByCustomer\": false,\"totalVerizonDollarUsed\": \"0.0\",\"isShellAccountSelected\": false,\"guestOrInactiveRefundLines\": false,\"totalDueMonthlyOnProfile\": 0,\"subTotalDueMonthlyOnProfile\": 0,\"totalMonthlyTaxesOnProfile\": 0,\"subTotalOtherLinesOnProfile\": 0,\"estimatedNextMonthChargeOnProfile\": 0,\"totalDueMonthlyAfterDiscounts\": 0,\"totalActivationFees\": 0,\"orderType\": \"PS\",\"locationCode\": \"D239301\",\"customerType\": \"U\",\"billingSystem\": \"VN\",\"totalTaxAmount\": \"0.0\",\"totalDueToday\": null,\"totalDueMonthly\": 0,\"subTotalDueMonthly\": 0,\"subTotalDueToday\": 0,\"subTotalMonthlyTaxes\": 0,\"estimatedNextMonthCharge\": 0,\"totalMonthlyTaxes\": 0,\"subTotalOtherLines\": 0,\"subTotalOtherLinesTaxes\": 0,\"instantDRCCredit\": false,\"isAttachmentCompleted\": false,\"nextMonthBillTotal\": 0,\"orderChannelId\": \"VZW-DOTCOM-MOB\",\"orderList\": [{\"creditApplication\": {\"creditApplicationNum\": 248024166,\"creditApprovalStatus\": \"AP\",\"creditStatusReason\": \"CA CVAS AUTOMATIC APPROVAL\",\"internationalEligibility\": true,\"securityDepositAmount\": \"0\",\"serviceClass\": \"B\",\"lineCreditClass\": \"\"},\"orderActivityType\": \"EUP\",\"orderNumber\": null,\"numOfLinesForOrderActivityType\": 0,\"preOrderNumber\": 0,\"managerApprovalRequired\": false}],\"outletId\": \"85067\",\"registerNumber\": \"0\",\"saleType\": \"P\",\"salesRepId\": \"NPB2C\",\"enableSplitShipment\": false,\"splitShipmentIndicator\": false,\"cartReadyForCheckout\": true,\"isSingleModConnectedDevice\": false,\"fiveGUpSellAccountLevel\": false,\"customerOnTrialPlan\": false,\"availableSlotsForGrantee\": \"1\",\"totalDownPaymentAmt\": 0,\"totalEdgeBuyOutAmount\": 0,\"expressCheckout\": false,\"isEQPandPPLOfferApplied\": false,\"cartTotalDiscounts\": {\"totalDiscount\": \"0.0\",\"discountDetails\": []},\"memberTotalDueToday\": 0,\"customerConsent\": \"N\",\"totalDwosCost\": \"0.0\",\"billingState\": \"NJ\",\"isTradeInOfferSelected\": false},\"lineDetails\": {\"lineInfo\": [{\"multiLineSeqNumber\": 1,\"lineActivityType\": \"EUP_5G\",\"totalDueToday\": 0,\"totalDueTodayWithoutTax\": 0,\"totalDueMonthly\": 0,\"mobileNumber\": \"7085532299\",\"serviceInfo\": {\"pairingInfo\": {},\"planDiscount\": {\"planEligibleForAutoPayPaperLessDiscount\": true,\"eligibleAutoPayPaperlessDiscount\": \"10.0\",\"discountIncluded\": false,\"totalPlanCostIncludingLineAccessFee\": \"80.0\"},\"otherPromotions\": [],\"primaryUserInfo\": {\"firstName\": \"NIAL\",\"lastName\": \"BELTRAN\",\"address\": {\"firmName\": \"\",\"apartmentNo\": \"\",\"type\": \"WAY\",\"streetNumber\": \"1\",\"streetName\": \"VERIZON\",\"addressLine2\": \"\",\"addressLine1\": \"1 VERIZON WAY\",\"poBoxNo\": \"\",\"ruralRouteNo\": \"\",\"ruralDelNo\": \"\",\"city\": \"BASKING RIDGE\",\"state\": \"NJ\",\"zipCode\": \"07920\",\"zipCode4\": \"1025\",\"county\": \"\",\"countryCode\": \"\",\"fipsCode\": \"3403503340\",\"firstName\": \"NIAL\",\"lastName\": \"BELTRAN\",\"emailId\": \"CXT.DOTCOM.REGRESSION@VERIZON.COM\",\"phoneNumber\": \"9089349238\",\"streetType\": \"WAY\",\"streetDirection\": \"\"},\"isValidAddress\": true,\"bsnsName\": \"\",\"emailId\": \"CXT.DOTCOM.REGRESSION@VERIZON.COM\"},\"cartE911Address\": {\"firmName\": \"\",\"apartmentNo\": \"\",\"type\": \"WAY\",\"streetNumber\": \"1\",\"streetName\": \"VERIZON\",\"addressLine2\": \"\",\"addressLine1\": \"1 VERIZON WAY\",\"poBoxNo\": \"\",\"ruralRouteNo\": \"\",\"ruralDelNo\": \"\",\"city\": \"BASKING RIDGE\",\"state\": \"NJ\",\"zipCode\": \"07920\",\"zipCode4\": \"1025\",\"countryCode\": \"\",\"fipsCode\": \"3403503340\",\"firstName\": \"NIAL\",\"lastName\": \"BELTRAN\",\"emailId\": \"CXT.DOTCOM.REGRESSION@VERIZON.COM\",\"phoneNumber\": \"9089349238\",\"streetType\": \"WAY\",\"streetDirection\": \"\"},\"cart5GAddress\": {\"addressLine2\": \"\",\"addressLine1\": \"1 VERIZON WAY\",\"city\": \"BASKING RIDGE\",\"state\": \"NJ\",\"zipCode\": \"07920\",\"zipCode4\": \"\",\"countryCode\": \"\",\"fipsCode\": \"3403500000\",\"floor\": 0},\"mtn\": \"7085532299\",\"min\": \"7082089299\",\"oldPricePlanId\": \"25878\",\"newPricePlanId\": \"50116\",\"contractTermId\": \"48\",\"pricePlanInfo\": {\"pricePlanCategory\": \"N\",\"ratePlanType\": \"L\",\"accessFeeRange\": \"0\",\"categoryCode\": \"74\",\"contractRange\": \"-1\",\"contractDuration\": 0,\"pricePlanCode\": \"25878\",\"pricePlanDesc\": \"5G HOME INTERNET\",\"contractTermId\": \"48\",\"imageUrlMap\": {},\"planPrice\": 80},\"newPricePlanInfo\": {\"pricePlanCategory\": \"N\",\"ratePlanType\": \"L\",\"accessFeeRange\": \"0\",\"categoryCode\": \"74\",\"contractRange\": \"-1\",\"contractDuration\": 0,\"pricePlanCode\": \"50116\",\"pricePlanDesc\": \"5G HOME PLUS\",\"contractTermId\": \"48\",\"imageUrlMap\": {},\"planPrice\": 80},\"selectedFeaturesList\": {\"featuresCount\": 22,\"visFeature\": [{\"displayReceiptIndicator\": \"0\",\"visFeatureCode\": \"48526\",\"featureDesc\": \"Text Messaging Pay Per Message\",\"addDeleteInd\": \"Z\",\"currentDeviceCompatible\": false,\"customerSelected\": \"N\",\"level\": \"L\",\"type\": \"SFO\",\"featurePrice\": \"0.00\",\"source\": \"EXISTING\",\"sfopackageGroupCode\": \"MI\",\"protection\": false,\"callFilter\": false,\"conflictMessage\": \"\",\"declinedProtection\": false,\"imageUrlMap\": {\"defaultImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216\"},\"featureDiscounts\": [],\"categoryCodes\": [],\"minEligibleLines\": 0,\"maxEligibleLines\": 0,\"sddSetupEligible\": false,\"featureStatus\": \"B\"},{\"displayReceiptIndicator\": \"0\",\"visFeatureCode\": \"48553\",\"featureDesc\": \"Streamlined Billing\",\"addDeleteInd\": \"Z\",\"currentDeviceCompatible\": false,\"customerSelected\": \"N\",\"level\": \"L\",\"type\": \"SFO\",\"featurePrice\": \"0.00\",\"source\": \"EXISTING\",\"sfopackageGroupCode\": \"BL\",\"protection\": false,\"callFilter\": false,\"conflictMessage\": \"\",\"declinedProtection\": false,\"imageUrlMap\": {\"defaultImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216\"},\"featureDiscounts\": [],\"categoryCodes\": [],\"minEligibleLines\": 0,\"maxEligibleLines\": 0,\"sddSetupEligible\": false,\"featureStatus\": \"O\"},{\"displayReceiptIndicator\": \"0\",\"visFeatureCode\": \"54307\",\"featureDesc\": \"Block Messaging\",\"addDeleteInd\": \"Z\",\"currentDeviceCompatible\": false,\"customerSelected\": \"N\",\"level\": \"L\",\"type\": \"SFO\",\"featurePrice\": \"0.00\",\"source\": \"EXISTING\",\"sfopackageGroupCode\": \"MS\",\"protection\": false,\"callFilter\": false,\"conflictMessage\": \"\",\"declinedProtection\": false,\"imageUrlMap\": {\"defaultImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/Messaging_012918\"},\"featureDiscounts\": [],\"categoryCodes\": [],\"minEligibleLines\": 0,\"maxEligibleLines\": 0,\"sddSetupEligible\": false,\"featureStatus\": \"O\"},{\"displayReceiptIndicator\": \"0\",\"visFeatureCode\": \"68872\",\"featureDesc\": \"CALL DELIVERY\",\"addDeleteInd\": \"Z\",\"currentDeviceCompatible\": false,\"customerSelected\": \"N\",\"level\": \"L\",\"type\": \"SFO\",\"featurePrice\": \"0.00\",\"source\": \"EXISTING\",\"sfopackageGroupCode\": \"BF\",\"protection\": false,\"callFilter\": false,\"conflictMessage\": \"\",\"declinedProtection\": false,\"imageUrlMap\": {\"defaultImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216\"},\"featureDiscounts\": [],\"categoryCodes\": [],\"minEligibleLines\": 0,\"maxEligibleLines\": 0,\"sddSetupEligible\": false,\"featureStatus\": \"O\"},{\"displayReceiptIndicator\": \"0\",\"visFeatureCode\": \"70421\",\"featureDesc\": \"Block Voice Calls - Hotline\",\"addDeleteInd\": \"Z\",\"currentDeviceCompatible\": false,\"customerSelected\": \"N\",\"level\": \"L\",\"type\": \"SFO\",\"featurePrice\": \"0.00\",\"source\": \"EXISTING\",\"sfopackageGroupCode\": \"HT\",\"protection\": false,\"callFilter\": false,\"conflictMessage\": \"\",\"declinedProtection\": false,\"imageUrlMap\": {\"defaultImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216\"},\"featureDiscounts\": [],\"categoryCodes\": [],\"minEligibleLines\": 0,\"maxEligibleLines\": 0,\"sddSetupEligible\": false,\"featureStatus\": \"O\"},{\"displayReceiptIndicator\": \"0\",\"visFeatureCode\": \"78003\",\"featureDesc\": \"4G BLOCK DATA ROAM (M)\",\"addDeleteInd\": \"Z\",\"currentDeviceCompatible\": false,\"customerSelected\": \"N\",\"level\": \"L\",\"type\": \"SFO\",\"featurePrice\": \"0.00\",\"source\": \"EXISTING\",\"sfopackageGroupCode\": \"VS\",\"protection\": false,\"callFilter\": false,\"conflictMessage\": \"\",\"declinedProtection\": false,\"imageUrlMap\": {\"defaultImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216\"},\"featureDiscounts\": [],\"categoryCodes\": [],\"minEligibleLines\": 0,\"maxEligibleLines\": 0,\"sddSetupEligible\": false,\"featureStatus\": \"B\"},{\"displayReceiptIndicator\": \"0\",\"visFeatureCode\": \"83856\",\"featureDesc\": \"CDMA-LESS DEVICE PROVISIONING\",\"addDeleteInd\": \"Z\",\"currentDeviceCompatible\": false,\"customerSelected\": \"N\",\"level\": \"L\",\"type\": \"SFO\",\"featurePrice\": \"0.00\",\"source\": \"EXISTING\",\"sfopackageGroupCode\": \"TP\",\"protection\": false,\"callFilter\": false,\"conflictMessage\": \"\",\"declinedProtection\": false,\"imageUrlMap\": {\"defaultImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216\"},\"featureDiscounts\": [],\"categoryCodes\": [],\"minEligibleLines\": 0,\"maxEligibleLines\": 0,\"sddSetupEligible\": false,\"featureStatus\": \"O\"},{\"displayReceiptIndicator\": \"0\",\"visFeatureCode\": \"85503\",\"featureDesc\": \"Unlimited Data\",\"addDeleteInd\": \"Z\",\"currentDeviceCompatible\": false,\"customerSelected\": \"N\",\"level\": \"L\",\"type\": \"SFO\",\"featurePrice\": \"0.00\",\"source\": \"EXISTING\",\"sfopackageGroupCode\": \"DT\",\"protection\": false,\"callFilter\": false,\"conflictMessage\": \"\",\"declinedProtection\": false,\"imageUrlMap\": {\"defaultImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/Data_012918\"},\"featureDiscounts\": [],\"categoryCodes\": [],\"minEligibleLines\": 0,\"maxEligibleLines\": 0,\"sddSetupEligible\": false,\"featureStatus\": \"B\"},{\"displayReceiptIndicator\": \"0\",\"visFeatureCode\": \"86112\",\"featureDesc\": \"5G IPv4/IPv6 IP\",\"addDeleteInd\": \"Z\",\"currentDeviceCompatible\": false,\"customerSelected\": \"N\",\"level\": \"L\",\"type\": \"SFO\",\"featurePrice\": \"0.00\",\"source\": \"EXISTING\",\"sfopackageGroupCode\": \"TP\",\"protection\": false,\"callFilter\": false,\"conflictMessage\": \"\",\"declinedProtection\": false,\"imageUrlMap\": {\"defaultImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216\"},\"featureDiscounts\": [],\"categoryCodes\": [],\"minEligibleLines\": 0,\"maxEligibleLines\": 0,\"sddSetupEligible\": false,\"featureStatus\": \"O\"},{\"displayReceiptIndicator\": \"0\",\"visFeatureCode\": \"86926\",\"featureDesc\": \"5G LINE OF SERVICE\",\"addDeleteInd\": \"Z\",\"currentDeviceCompatible\": false,\"customerSelected\": \"N\",\"level\": \"L\",\"type\": \"SFO\",\"featurePrice\": \"0.00\",\"source\": \"EXISTING\",\"sfopackageGroupCode\": \"TP\",\"protection\": false,\"callFilter\": false,\"conflictMessage\": \"\",\"declinedProtection\": false,\"imageUrlMap\": {\"defaultImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216\"},\"featureDiscounts\": [],\"categoryCodes\": [],\"minEligibleLines\": 0,\"maxEligibleLines\": 0,\"sddSetupEligible\": false,\"featureStatus\": \"O\"},{\"displayReceiptIndicator\": \"0\",\"visFeatureCode\": \"86927\",\"featureDesc\": \"5G INTERNET ACCESS\",\"addDeleteInd\": \"Z\",\"currentDeviceCompatible\": false,\"customerSelected\": \"N\",\"level\": \"L\",\"type\": \"SFO\",\"featurePrice\": \"0.00\",\"source\": \"EXISTING\",\"sfopackageGroupCode\": \"TP\",\"protection\": false,\"callFilter\": false,\"conflictMessage\": \"\",\"declinedProtection\": false,\"imageUrlMap\": {\"defaultImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216\"},\"featureDiscounts\": [],\"categoryCodes\": [],\"minEligibleLines\": 0,\"maxEligibleLines\": 0,\"sddSetupEligible\": false,\"featureStatus\": \"O\"},{\"displayReceiptIndicator\": \"0\",\"visFeatureCode\": \"86928\",\"featureDesc\": \"5G DATA TRANSPORT\",\"addDeleteInd\": \"Z\",\"currentDeviceCompatible\": false,\"customerSelected\": \"N\",\"level\": \"L\",\"type\": \"SFO\",\"featurePrice\": \"0.00\",\"source\": \"EXISTING\",\"sfopackageGroupCode\": \"TP\",\"protection\": false,\"callFilter\": false,\"conflictMessage\": \"\",\"declinedProtection\": false,\"imageUrlMap\": {\"defaultImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216\"},\"featureDiscounts\": [],\"categoryCodes\": [],\"minEligibleLines\": 0,\"maxEligibleLines\": 0,\"sddSetupEligible\": false,\"featureStatus\": \"O\"},{\"displayReceiptIndicator\": \"0\",\"visFeatureCode\": \"86952\",\"featureDesc\": \"ENTITLEMENT FOR 5G\",\"addDeleteInd\": \"Z\",\"currentDeviceCompatible\": false,\"customerSelected\": \"N\",\"level\": \"L\",\"type\": \"SFO\",\"featurePrice\": \"0.00\",\"source\": \"EXISTING\",\"sfopackageGroupCode\": \"TP\",\"protection\": false,\"callFilter\": false,\"conflictMessage\": \"\",\"declinedProtection\": false,\"imageUrlMap\": {\"defaultImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216\"},\"featureDiscounts\": [],\"categoryCodes\": [],\"minEligibleLines\": 0,\"maxEligibleLines\": 0,\"sddSetupEligible\": false,\"featureStatus\": \"B\"},{\"displayReceiptIndicator\": \"0\",\"visFeatureCode\": \"86953\",\"featureDesc\": \"RTR FOR 5G\",\"addDeleteInd\": \"Z\",\"currentDeviceCompatible\": false,\"customerSelected\": \"N\",\"level\": \"L\",\"type\": \"SFO\",\"featurePrice\": \"0.00\",\"source\": \"EXISTING\",\"sfopackageGroupCode\": \"TP\",\"protection\": false,\"callFilter\": false,\"conflictMessage\": \"\",\"declinedProtection\": false,\"imageUrlMap\": {\"defaultImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216\"},\"featureDiscounts\": [],\"categoryCodes\": [],\"minEligibleLines\": 0,\"maxEligibleLines\": 0,\"sddSetupEligible\": false,\"featureStatus\": \"B\"},{\"displayReceiptIndicator\": \"0\",\"visFeatureCode\": \"88920\",\"featureDesc\": \"VERIZON CLOUD UNL 5G OWNER $0\",\"addDeleteInd\": \"A\",\"currentDeviceCompatible\": false,\"customerSelected\": \"Y\",\"level\": \"L\",\"type\": \"SFO\",\"featurePrice\": \"0.00\",\"source\": \"FOM\",\"sfopackageGroupCode\": \"VT\",\"protection\": false,\"callFilter\": false,\"conflictMessage\": \"Add SFO due to missing required parent\",\"declinedProtection\": false,\"imageUrlMap\": {\"defaultImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216\"},\"featureDiscounts\": [],\"categoryCodes\": [],\"minEligibleLines\": 0,\"maxEligibleLines\": 0,\"sddSetupEligible\": false,\"featureStatus\": \"G\"},{\"displayReceiptIndicator\": \"0\",\"visFeatureCode\": \"89090\",\"featureDesc\": \"VERIZON CLOUD TRIGGER\",\"addDeleteInd\": \"A\",\"currentDeviceCompatible\": false,\"customerSelected\": \"Y\",\"level\": \"L\",\"type\": \"SFO\",\"featurePrice\": \"0.00\",\"source\": \"FOM\",\"sfopackageGroupCode\": \"TP\",\"protection\": false,\"callFilter\": false,\"conflictMessage\": \"\",\"declinedProtection\": false,\"imageUrlMap\": {\"defaultImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/generic_Icon_22216\"},\"featureDiscounts\": [],\"categoryCodes\": [],\"minEligibleLines\": 0,\"maxEligibleLines\": 0,\"sddSetupEligible\": false,\"featureStatus\": \"A\"},{\"visFeatureCode\": \"1803\",\"featureDesc\": \"Disney+ RTB Paid 6 Month Subscription Marker\",\"addDeleteInd\": \"Z\",\"currentDeviceCompatible\": false,\"customerSelected\": \"N\",\"level\": \"A\",\"type\": \"SPO\",\"featurePrice\": \"0.00\",\"source\": \"EXISTING\",\"protection\": false,\"callFilter\": false,\"conflictMessage\": \"\",\"declinedProtection\": false,\"imageUrlMap\": {},\"featureDiscounts\": [],\"categoryCodes\": [\"BYPVREQUAL\",\"NOSPLANRQD\",\"DONOTREACT\",\"DISNEYALL\",\"SUBELIG\",\"BYPGRPREQL\",\"DISNEYPAID\",\"DISNPAYMTX\",\"SCMSUBPEGA\",\"BYPASSORD\",\"MI\",\"VZVIDEO\"],\"minEligibleLines\": 0,\"maxEligibleLines\": 0,\"sddSetupEligible\": false,\"featureStatus\": \"O\"},{\"visFeatureCode\": \"1293\",\"featureDesc\": \"$20 LOYALTY DISCOUNT\",\"addDeleteInd\": \"D\",\"currentDeviceCompatible\": false,\"customerSelected\": \"Y\",\"level\": \"L\",\"type\": \"SPO\",\"featurePrice\": \"-20.00\",\"source\": \"FOM\",\"protection\": false,\"callFilter\": false,\"conflictMessage\": \"\",\"declinedProtection\": false,\"imageUrlMap\": {},\"featureDiscounts\": [],\"categoryCodes\": [\"BYPVREQUAL\",\"SRVCDISC\",\"DISCPROMO\",\"EBBBEFORE\",\"PLANDISC\",\"BYPGRPQUAL\",\"BYPGRPREQL\",\"BYPPVQUAL\",\"FWADISCNT\",\"5GBUNDLE\",\"5GLOYALTY\"],\"minEligibleLines\": 0,\"maxEligibleLines\": 0,\"sddSetupEligible\": false,\"featureStatus\": \"T\"},{\"visFeatureCode\": \"732\",\"featureDesc\": \"CDMA-LESS ROAM TIER OVERRIDE\",\"addDeleteInd\": \"Z\",\"currentDeviceCompatible\": false,\"customerSelected\": \"N\",\"level\": \"L\",\"type\": \"SPO\",\"featurePrice\": \"0.00\",\"source\": \"EXISTING\",\"protection\": false,\"callFilter\": false,\"conflictMessage\": \"\",\"declinedProtection\": false,\"imageUrlMap\": {},\"featureDiscounts\": [],\"categoryCodes\": [\"TP\"],\"minEligibleLines\": 0,\"maxEligibleLines\": 0,\"sddSetupEligible\": false,\"featureStatus\": \"\"},{\"visFeatureCode\": \"2153\",\"featureDesc\": \"Unlimited Plan Discount\",\"addDeleteInd\": \"Z\",\"currentDeviceCompatible\": false,\"customerSelected\": \"N\",\"level\": \"L\",\"type\": \"SPO\",\"featurePrice\": \"-35.00\",\"source\": \"EXISTING\",\"protection\": false,\"callFilter\": false,\"conflictMessage\": \"\",\"declinedProtection\": false,\"imageUrlMap\": {},\"featureDiscounts\": [],\"categoryCodes\": [\"BYPVREQUAL\",\"SRVCDISC\",\"DISCPROMO\",\"EBBBEFORE\",\"PLANDISC\",\"ULPLANDISC\",\"BYPGRPQUAL\",\"BYPGRPREQL\",\"BYPPVQUAL\",\"FWADISCNT\",\"5GBUNDLE\",\"5GLOYALTY\"],\"minEligibleLines\": 0,\"maxEligibleLines\": 0,\"sddSetupEligible\": false,\"featureStatus\": \"\"},{\"visFeatureCode\": \"2196\",\"featureDesc\": \"3 YEAR PRICE GUARANTEE\",\"addDeleteInd\": \"A\",\"currentDeviceCompatible\": false,\"customerSelected\": \"Y\",\"level\": \"L\",\"type\": \"SPO\",\"featurePrice\": \"0.00\",\"source\": \"FOM\",\"protection\": false,\"callFilter\": false,\"conflictMessage\": \"\",\"declinedProtection\": false,\"imageUrlMap\": {},\"featureDiscounts\": [],\"categoryCodes\": [\"MI\"],\"minEligibleLines\": 0,\"maxEligibleLines\": 0,\"sddSetupEligible\": false,\"featureStatus\": \"\"},{\"visFeatureCode\": \"2464\",\"featureDesc\": \"5G HOME 5G CORE\",\"addDeleteInd\": \"A\",\"currentDeviceCompatible\": false,\"customerSelected\": \"Y\",\"level\": \"L\",\"type\": \"SPO\",\"featurePrice\": \"0.00\",\"source\": \"FOM\",\"protection\": false,\"callFilter\": false,\"conflictMessage\": \"\",\"declinedProtection\": false,\"imageUrlMap\": {},\"featureDiscounts\": [],\"categoryCodes\": [\"5GCOREPROV\",\"BYPGRPQUAL\",\"BYPPVQUAL\",\"TP\"],\"minEligibleLines\": 0,\"maxEligibleLines\": 0,\"sddSetupEligible\": false,\"featureStatus\": \"\"}]},\"planDetails\": {\"planPrice\": 80,\"planDiscounts\": []},\"correlationID\": \"192000000003649337\",\"currentDevice\": {\"oldLteVoraEquipInfo\": {\"iccid\": \"89148000005241096189\",\"lteVoraDeviceInfo\": {\"deviceId\": \"353450100009562\",\"deviceType\": \"5GF\",\"deviceSku\": \"LVSKODU\",\"description\": \"5G Outdoor Internet Unit\",\"imageUrlMap\": {\"defaultImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/5G-Home-Outdoor-Receiver-LVSKODU-07292019\",\"largeImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/5G-Home-Outdoor-Receiver-LVSKODU-07292019?$device-lg$\",\"mediumImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/5G-Home-Outdoor-Receiver-LVSKODU-07292019?$device-med$\",\"miniImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/5G-Home-Outdoor-Receiver-LVSKODU-07292019?$device-mini$\",\"thumbImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/5G-Home-Outdoor-Receiver-LVSKODU-07292019?$device-thumb$\"},\"color\": {},\"manufacturer\": \"Wistron\"}}},\"isSharePlanAdded\": false,\"mea\": \"M59\",\"dacc\": \"01425\",\"isE911AddressValidated\": false,\"isFreeAppleMusicLoss\": \"N\",\"newBgsa\": \"978\",\"newPlanFlag\": \"L\",\"oldPlanFlag\": \"L\",\"orderDevice\": {\"lteVoraEquipInfo\": {\"lteEqpt\": {},\"lteVoraDeviceInfo\": {\"deviceType\": \"5GF\"}}},\"kidsPlanParentMtn\": false,\"mcsSubscription\": [],\"fiveGUpSell\": false,\"e911AddressSameAsServiceAddress\": false,\"unpairedGrantor\": false,\"hasVerizonCloudUnlimitedIncluded\": false},\"itemsInfo\": [{\"depletionType\": \"O\",\"attention\": \"NIAL BELTRAN\",\"shipping\": {\"address\": {\"apartmentNo\": \"\",\"type\": \"R\",\"streetNumber\": \"1\",\"streetName\": \"VERIZON\",\"addressLine2\": \"\",\"addressLine1\": \"1 VERIZON WAY\",\"city\": \"BASKING RIDGE\",\"state\": \"NJ\",\"zipCode\": \"07920\",\"zipCode4\": \"1025\",\"county\": \"\",\"countryCode\": \"\",\"fipsCode\": \"3403503340\",\"firstName\": \"NIAL\",\"lastName\": \"BELTRAN\",\"emailId\": \"CXT.DOTCOM.REGRESSION@VERIZON.COM\",\"phoneNumber\": \"9089349238\",\"streetType\": \"WAY\",\"streetDirection\": \"\"},\"cbrPhone\": \"9089349238\",\"firstName\": \"NIAL\",\"lastName\": \"BELTRAN\",\"midInitials\": \"\",\"isUseUnVerifiedAddress\": false,\"isValidAddress\": false,\"email\": \"CXT.DOTCOM.REGRESSION@VERIZON.COM\"},\"fipsCode\": \"3403503340\",\"itemCount\": 4,\"itemTabSeqNum\": 0,\"cartItems\": {\"cartItem\": [{\"discountAmount\": 0,\"deviceDollarApplied\": 0,\"promoHubOfferList\": {\"promoHubOfferList\": [],\"offerCount\": 0},\"qrScanNeededForEsimActivation\": false,\"isPreconfigureDuringAddDevice\": false,\"accessoryGiftCardAmount\": 0,\"tradeInAmountTowardsUserDPUsed\": 0,\"sorDeviceType\": \"5GF\",\"vendingKioskItem\": \"false\",\"tradeInAutoPull\": false,\"priceAdjustment\": false,\"priceAdjustmentQty\": 0,\"newPurchasedQty\": 0,\"networkBandwidthType\": \"MMW\",\"selectedForRFEX\": false,\"selectedForPAD\": false,\"bogoItem\": false,\"refxItemSeqNum\": 0,\"restrictedAccySku\": false,\"maxAccyPurchaseLimit\": false,\"itemCode\": \"LVSKIHP\",\"totalPriceWithDiscount\": 0,\"sorId\": \"LVSKIHP\",\"cartItemType\": \"DEVICE\",\"mobileNumber\": \"7085532299\",\"minNumber\": \"7082089299\",\"description\": \"5G Internet Gateway\",\"qty\": 1,\"bundleSeqNum\": 0,\"itemPrice\": \"0.0\",\"discountedPercentage\": 0,\"discountedPrice\": 0,\"buyOutTaxAmountUnbilled\": 0,\"buyOutAmountWithoutTax\": 0,\"taxAmount\": 0,\"imageUrlMap\": {\"defaultImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/verizon-gemini-5g-internet-gateway-gen-3-high-power-cpe-lvskihp\",\"largeImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/verizon-gemini-5g-internet-gateway-gen-3-high-power-cpe-lvskihp?$device-lg$\",\"mediumImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/verizon-gemini-5g-internet-gateway-gen-3-high-power-cpe-lvskihp?$device-med$\",\"miniImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/verizon-gemini-5g-internet-gateway-gen-3-high-power-cpe-lvskihp?$device-mini$\",\"thumbImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/verizon-gemini-5g-internet-gateway-gen-3-high-power-cpe-lvskihp?$device-thumb$\"},\"prodCode1\": \"5GD\",\"prodCode2\": \"NIC\",\"prodCode3\": \"5IR\",\"prodCode4\": \"B2B\",\"prodCode5\": \"RNT\",\"priceType\": \"MONTH_TO_MONTH\",\"btaEligible\": \"true\",\"depletionType\": \"O\",\"catalogPrice\": 0,\"instantCreditAmountUsed\": 0,\"instantCreditAmountUsedForTaxes\": 0,\"itemNrpPrice\": 0,\"itemCost\": 0,\"upgradeReasonCode\": \"UN\",\"upgradeReasonDesc\": \"Upgrade, No discount\",\"itemPriceType\": \"R\",\"discounts\": [],\"availableReasonCode\": [],\"inventory\": {\"isAvailable\": true,\"isBackorder\": false,\"isPreOrder\": false,\"qtyAvailable\": 1000},\"isCustomerProvidedSIM\": false,\"isNetworkExtender\": false,\"ispuEligible\": true,\"itemSeqNum\": 1,\"sddEligible\": true,\"smartIMEI\": false,\"year\": 0,\"sellerPrice\": \"0.0\",\"edgeDeviceCap\": \"750\",\"productId\": \"16900002\",\"taxDetailsList\": [],\"iconicPhone\": false,\"ringBell\": false,\"isPreconfigureEnabled\": false,\"isHumDevice\": false,\"isSmartLocator\": false,\"isSecurityAlarm\": false,\"isMotoMod\": false,\"isConnectedCar\": false,\"accountLevelAccessory\": false,\"byodESimPhone\": false,\"appleCareAccessoryFlag\": false},{\"discountAmount\": 0,\"deviceDollarApplied\": 0,\"promoHubOfferList\": {\"promoHubOfferList\": [],\"offerCount\": 0},\"qrScanNeededForEsimActivation\": false,\"isPreconfigureDuringAddDevice\": false,\"accessoryGiftCardAmount\": 0,\"tradeInAmountTowardsUserDPUsed\": 0,\"vendingKioskItem\": \"false\",\"tradeInAutoPull\": false,\"priceAdjustment\": false,\"priceAdjustmentQty\": 0,\"newPurchasedQty\": 0,\"selectedForRFEX\": false,\"selectedForPAD\": false,\"bogoItem\": false,\"refxItemSeqNum\": 0,\"restrictedAccySku\": false,\"maxAccyPurchaseLimit\": false,\"itemCode\": \"NI-DPSIM\",\"totalPriceWithDiscount\": 0,\"sorId\": \"NI-DPSIM\",\"cartItemType\": \"SIM\",\"qty\": 1,\"bundleSeqNum\": 0,\"itemPrice\": \"0.0\",\"discountedPercentage\": 0,\"discountedPrice\": 0,\"buyOutTaxAmountUnbilled\": 0,\"buyOutAmountWithoutTax\": 0,\"instantCreditAmountUsed\": 0,\"instantCreditAmountUsedForTaxes\": 0,\"discounts\": [],\"availableReasonCode\": [],\"isCustomerProvidedSIM\": false,\"isNetworkExtender\": false,\"ispuEligible\": false,\"itemSeqNum\": 2,\"sddEligible\": false,\"smartIMEI\": false,\"year\": 0,\"sellerPrice\": \"0.0\",\"taxDetailsList\": [],\"iconicPhone\": false,\"ringBell\": false,\"isPreconfigureEnabled\": false,\"isHumDevice\": false,\"isSmartLocator\": false,\"isSecurityAlarm\": false,\"isMotoMod\": false,\"isConnectedCar\": false,\"accountLevelAccessory\": false,\"byodESimPhone\": false,\"appleCareAccessoryFlag\": false},{\"discountAmount\": 0,\"deviceDollarApplied\": 0,\"promoHubOfferList\": {\"promoHubOfferList\": [],\"offerCount\": 0},\"qrScanNeededForEsimActivation\": false,\"isPreconfigureDuringAddDevice\": false,\"accessoryGiftCardAmount\": 0,\"tradeInAmountTowardsUserDPUsed\": 0,\"vendingKioskItem\": \"false\",\"tradeInAutoPull\": false,\"priceAdjustment\": false,\"priceAdjustmentQty\": 0,\"newPurchasedQty\": 0,\"selectedForRFEX\": false,\"selectedForPAD\": false,\"bogoItem\": false,\"refxItemSeqNum\": 0,\"restrictedAccySku\": false,\"maxAccyPurchaseLimit\": false,\"itemCode\": \"WAR6002\",\"totalPriceWithDiscount\": 0,\"sorId\": \"WAR6002\",\"cartItemType\": \"WARRANTY\",\"qty\": 1,\"bundleSeqNum\": 0,\"itemPrice\": \"0.0\",\"discountedPercentage\": 0,\"discountedPrice\": 0,\"buyOutTaxAmountUnbilled\": 0,\"buyOutAmountWithoutTax\": 0,\"instantCreditAmountUsed\": 0,\"instantCreditAmountUsedForTaxes\": 0,\"discounts\": [],\"availableReasonCode\": [],\"isCustomerProvidedSIM\": false,\"isNetworkExtender\": false,\"ispuEligible\": false,\"itemSeqNum\": 3,\"sddEligible\": false,\"smartIMEI\": false,\"year\": 0,\"sellerPrice\": \"0.0\",\"taxDetailsList\": [],\"iconicPhone\": false,\"ringBell\": false,\"isPreconfigureEnabled\": false,\"isHumDevice\": false,\"isSmartLocator\": false,\"isSecurityAlarm\": false,\"isMotoMod\": false,\"isConnectedCar\": false,\"accountLevelAccessory\": false,\"byodESimPhone\": false,\"appleCareAccessoryFlag\": false},{\"discountAmount\": 0,\"bundleProductId\": \"16900002\",\"deviceDollarApplied\": 0,\"promoHubOfferList\": {\"promoHubOfferList\": [],\"offerCount\": 0},\"qrScanNeededForEsimActivation\": false,\"isPreconfigureDuringAddDevice\": false,\"accessoryGiftCardAmount\": 0,\"tradeInAmountTowardsUserDPUsed\": 0,\"vendingKioskItem\": \"false\",\"tradeInAutoPull\": false,\"priceAdjustment\": false,\"priceAdjustmentQty\": 0,\"newPurchasedQty\": 0,\"selectedForRFEX\": false,\"selectedForPAD\": false,\"bogoItem\": false,\"refxItemSeqNum\": 0,\"restrictedAccySku\": false,\"maxAccyPurchaseLimit\": false,\"itemCode\": \"LVSKR1\",\"totalPriceWithDiscount\": 0,\"sorId\": \"LVSKR1\",\"cartItemType\": \"ACCESSORY\",\"mobileNumber\": \"7085532299\",\"description\": \"Router\",\"qty\": 1,\"bundleSeqNum\": 0,\"itemPrice\": \"0.0\",\"discountedPercentage\": 0,\"discountedPrice\": 0,\"buyOutTaxAmountUnbilled\": 0,\"buyOutAmountWithoutTax\": 0,\"taxAmount\": 0,\"imageUrlMap\": {\"defaultImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/5G-Home-Router-LVSKR1-07292019_IMAGESETS\",\"largeImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/5G-Home-Router-LVSKR1-07292019_IMAGESETS?$acc-lg$\",\"mediumImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/5G-Home-Router-LVSKR1-07292019_IMAGESETS?$acc-med$\",\"miniImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/5G-Home-Router-LVSKR1-07292019_IMAGESETS?$acc-mini$\",\"thumbImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/5G-Home-Router-LVSKR1-07292019_IMAGESETS?$acc-thumb$\"},\"prodCode1\": \"ACC\",\"prodCode2\": \"RTR\",\"prodCode3\": \"OEM\",\"prodCode4\": \"000\",\"prodCode5\": \"RNT\",\"priceType\": \"MONTH_TO_MONTH\",\"btaEligible\": \"true\",\"catalogPrice\": 0,\"instantCreditAmountUsed\": 0,\"instantCreditAmountUsedForTaxes\": 0,\"itemNrpPrice\": 0,\"itemCost\": 0,\"itemPriceType\": \"R\",\"discounts\": [],\"availableReasonCode\": [],\"inventory\": {\"isAvailable\": true,\"isBackorder\": false,\"isPreOrder\": false,\"qtyAvailable\": 372771},\"isCustomerProvidedSIM\": false,\"isNetworkExtender\": false,\"ispuEligible\": true,\"itemSeqNum\": 4,\"sddEligible\": true,\"smartIMEI\": false,\"year\": 0,\"sellerPrice\": \"0.0\",\"taxDetailsList\": [],\"iconicPhone\": false,\"ringBell\": false,\"isPreconfigureEnabled\": false,\"isHumDevice\": false,\"isSmartLocator\": false,\"isSecurityAlarm\": false,\"isMotoMod\": false,\"isConnectedCar\": false,\"accountLevelAccessory\": false,\"byodESimPhone\": false,\"appleCareAccessoryFlag\": false},{\"discountAmount\": 0,\"bundleProductId\": \"16900002\",\"deviceDollarApplied\": 0,\"promoHubOfferList\": {\"promoHubOfferList\": [],\"offerCount\": 0},\"qrScanNeededForEsimActivation\": false,\"isPreconfigureDuringAddDevice\": false,\"accessoryGiftCardAmount\": 0,\"tradeInAmountTowardsUserDPUsed\": 0,\"vendingKioskItem\": \"false\",\"tradeInAutoPull\": false,\"priceAdjustment\": false,\"priceAdjustmentQty\": 0,\"newPurchasedQty\": 0,\"selectedForRFEX\": false,\"selectedForPAD\": false,\"bogoItem\": false,\"refxItemSeqNum\": 0,\"restrictedAccySku\": false,\"maxAccyPurchaseLimit\": false,\"itemCode\": \"LVSKOHP\",\"totalPriceWithDiscount\": 0,\"sorId\": \"LVSKOHP\",\"cartItemType\": \"ACCESSORY\",\"mobileNumber\": \"7085532299\",\"description\": \"Gen3 outdoor mount bracket\",\"qty\": 1,\"bundleSeqNum\": 0,\"itemPrice\": \"0.0\",\"discountedPercentage\": 0,\"discountedPrice\": 0,\"buyOutTaxAmountUnbilled\": 0,\"buyOutAmountWithoutTax\": 0,\"taxAmount\": 0,\"imageUrlMap\": {\"defaultImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/verizon -gemini-5g-internet-gateway-self-setup-indoor-mount-bracket-j-pole-lvskohp_IMAGESETS\",\"largeImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/verizon -gemini-5g-internet-gateway-self-setup-indoor-mount-bracket-j-pole-lvskohp_IMAGESETS?$acc-lg$\",\"mediumImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/verizon -gemini-5g-internet-gateway-self-setup-indoor-mount-bracket-j-pole-lvskohp_IMAGESETS?$acc-med$\",\"miniImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/verizon -gemini-5g-internet-gateway-self-setup-indoor-mount-bracket-j-pole-lvskohp_IMAGESETS?$acc-mini$\",\"thumbImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/verizon -gemini-5g-internet-gateway-self-setup-indoor-mount-bracket-j-pole-lvskohp_IMAGESETS?$acc-thumb$\"},\"prodCode1\": \"ACC\",\"prodCode2\": \"PIK\",\"prodCode3\": \"OEM\",\"prodCode4\": \"000\",\"prodCode5\": \"000\",\"priceType\": \"MONTH_TO_MONTH\",\"btaEligible\": \"true\",\"catalogPrice\": 0,\"instantCreditAmountUsed\": 0,\"instantCreditAmountUsedForTaxes\": 0,\"itemNrpPrice\": 0,\"itemCost\": 0,\"itemPriceType\": \"R\",\"discounts\": [],\"availableReasonCode\": [],\"inventory\": {\"isAvailable\": true,\"isBackorder\": false,\"isPreOrder\": false,\"qtyAvailable\": 670156},\"isCustomerProvidedSIM\": false,\"isNetworkExtender\": false,\"ispuEligible\": false,\"itemSeqNum\": 5,\"sddEligible\": false,\"smartIMEI\": false,\"year\": 0,\"sellerPrice\": \"0.0\",\"taxDetailsList\": [],\"iconicPhone\": false,\"ringBell\": false,\"isPreconfigureEnabled\": false,\"isHumDevice\": false,\"isSmartLocator\": false,\"isSecurityAlarm\": false,\"isMotoMod\": false,\"isConnectedCar\": false,\"accountLevelAccessory\": false,\"byodESimPhone\": false,\"appleCareAccessoryFlag\": false},{\"discountAmount\": 0,\"bundleProductId\": \"16900002\",\"deviceDollarApplied\": 0,\"promoHubOfferList\": {\"promoHubOfferList\": [],\"offerCount\": 0},\"qrScanNeededForEsimActivation\": false,\"isPreconfigureDuringAddDevice\": false,\"accessoryGiftCardAmount\": 0,\"tradeInAmountTowardsUserDPUsed\": 0,\"vendingKioskItem\": \"false\",\"tradeInAutoPull\": false,\"priceAdjustment\": false,\"priceAdjustmentQty\": 0,\"newPurchasedQty\": 0,\"selectedForRFEX\": false,\"selectedForPAD\": false,\"bogoItem\": false,\"refxItemSeqNum\": 0,\"restrictedAccySku\": false,\"maxAccyPurchaseLimit\": false,\"itemCode\": \"CR1000A\",\"totalPriceWithDiscount\": 0,\"sorId\": \"CR1000A\",\"cartItemType\": \"ACCESSORY\",\"mobileNumber\": \"7085532299\",\"description\": \"Verizon Router $0 SKU\",\"qty\": 1,\"bundleSeqNum\": 0,\"itemPrice\": \"0.0\",\"discountedPercentage\": 0,\"discountedPrice\": 0,\"buyOutTaxAmountUnbilled\": 0,\"buyOutAmountWithoutTax\": 0,\"taxAmount\": 0,\"imageUrlMap\": {\"defaultImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/vzw-chr-router-white-cr1000a\",\"largeImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/vzw-chr-router-white-cr1000a?$acc-lg$\",\"mediumImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/vzw-chr-router-white-cr1000a?$acc-med$\",\"miniImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/vzw-chr-router-white-cr1000a?$acc-mini$\",\"thumbImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/vzw-chr-router-white-cr1000a?$acc-thumb$\"},\"prodCode1\": \"ACC\",\"prodCode2\": \"RTR\",\"prodCode3\": \"OEM\",\"prodCode4\": \"000\",\"prodCode5\": \"RNT\",\"priceType\": \"MONTH_TO_MONTH\",\"btaEligible\": \"true\",\"catalogPrice\": 0,\"instantCreditAmountUsed\": 0,\"instantCreditAmountUsedForTaxes\": 0,\"itemNrpPrice\": 0,\"itemCost\": 0,\"itemPriceType\": \"R\",\"discounts\": [],\"availableReasonCode\": [],\"inventory\": {\"isAvailable\": true,\"isBackorder\": false,\"isPreOrder\": false,\"qtyAvailable\": 134994},\"isCustomerProvidedSIM\": false,\"isNetworkExtender\": false,\"ispuEligible\": true,\"itemSeqNum\": 6,\"sddEligible\": false,\"smartIMEI\": false,\"year\": 0,\"sellerPrice\": \"0.0\",\"taxDetailsList\": [],\"iconicPhone\": false,\"ringBell\": false,\"isPreconfigureEnabled\": false,\"isHumDevice\": false,\"isSmartLocator\": false,\"isSecurityAlarm\": false,\"isMotoMod\": false,\"isConnectedCar\": false,\"accountLevelAccessory\": false,\"byodESimPhone\": false,\"appleCareAccessoryFlag\": false},{\"discountAmount\": 0,\"deviceDollarApplied\": 0,\"promoHubOfferList\": {\"promoHubOfferList\": [],\"offerCount\": 0},\"qrScanNeededForEsimActivation\": false,\"isPreconfigureDuringAddDevice\": false,\"accessoryGiftCardAmount\": 0,\"tradeInAmountTowardsUserDPUsed\": 0,\"vendingKioskItem\": \"false\",\"tradeInAutoPull\": false,\"priceAdjustment\": false,\"priceAdjustmentQty\": 0,\"newPurchasedQty\": 0,\"selectedForRFEX\": false,\"selectedForPAD\": false,\"bogoItem\": false,\"refxItemSeqNum\": 0,\"restrictedAccySku\": false,\"maxAccyPurchaseLimit\": false,\"itemCode\": \"5GHOMEINSTALL\",\"totalPriceWithDiscount\": 0,\"sorId\": \"5GHOMEINSTALL\",\"cartItemType\": \"SOFT_SKU\",\"mobileNumber\": \"7085532299\",\"description\": \"3RD PARTY VENDOR INS\",\"qty\": 1,\"bundleSeqNum\": 0,\"discountedPercentage\": 0,\"discountedPrice\": 0,\"buyOutTaxAmountUnbilled\": 0,\"buyOutAmountWithoutTax\": 0,\"prodCode1\": \"LAB\",\"prodCode2\": \"ANT\",\"prodCode3\": \"000\",\"prodCode4\": \"PVI\",\"priceType\": \"MONTH_TO_MONTH\",\"instantCreditAmountUsed\": 0,\"instantCreditAmountUsedForTaxes\": 0,\"itemCost\": 0,\"itemPriceType\": \"R\",\"discounts\": [],\"availableReasonCode\": [],\"isCustomerProvidedSIM\": false,\"isNetworkExtender\": false,\"ispuEligible\": false,\"itemSeqNum\": 7,\"sddEligible\": false,\"smartIMEI\": false,\"year\": 0,\"sellerPrice\": \"0.0\",\"taxDetailsList\": [],\"iconicPhone\": false,\"ringBell\": false,\"isPreconfigureEnabled\": false,\"isHumDevice\": false,\"isSmartLocator\": false,\"isSecurityAlarm\": false,\"isMotoMod\": false,\"isConnectedCar\": false,\"accountLevelAccessory\": false,\"byodESimPhone\": false,\"appleCareAccessoryFlag\": false}]},\"isPromoSelected\": false,\"isTradeInSelected\": false,\"taxExemptionTypes\": \"\"}],\"mtnDetails\": {\"lineNumber\": \"7085532299\",\"mobileNumber\": \"7085532299\"},\"fiveGToFourGDownGrade\": false,\"reasonCode\": \"PLAN_DEVICE_COMPATIBLE\",\"lineCreator\": \"7085532299\",\"lineRefundTotal\": 0,\"lineExchangeTotal\": 0,\"totalDueMonthlyBeforeCredit\": 0,\"isCpe\": false,\"isLTEHomeLine\": true,\"isDevicePlanCompatible\": true,\"portinMtnAssignment\": false,\"impactedLine\": false,\"preOrBackOrder\": false,\"ispuItem\": false,\"ispuItemBYOD\": false,\"isModConnected\": false,\"modDevice\": false,\"byodCapable\": false,\"isCarLine\": false,\"buySimOnly\": false,\"broadBandInd\": false,\"protectionNotRequired\": false}],\"numOfAccessoryAndDeviceItemsInCart\": 1,\"totalEdgeUpAmount\": 0,\"totalEdgeBuyOutAmount\": 0,\"totalDownPaymentAmt\": 0,\"subscriptionInfos\": [],\"cartId\": null,\"numOfLines\": 1,\"numofLinesAAL\": 0,\"numofLinesEUP\": 0,\"payments\": [],\"lineSeq\": 0,\"vlcactivePhoneCount\": 0,\"fivegOrderind\": false,\"aceOrderCreated\": true,\"serviceLinesCreated\": false,\"aceItemsModified\": true,\"clnrOrderFlag\": false,\"broadbandInd\": false,\"acctMcsSubscription\": [],\"spendingLimitAmountExceededBy\": \"0.0\",\"numofAccessories\": 3,\"subAccountNBSInfo\": []}}}}";
		OrderConfirmationCXPResponse orderConfirmationResponse =  mapper.readValue(rcString, OrderConfirmationCXPResponse.class);
		String vcString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":{\"newAlpShareInfo\":[{},{}]},\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
		ValidateCartCXPResponse validateCartResponse = mapper.readValue(vcString, ValidateCartCXPResponse.class);
		cxpHelper.populateOrderConfirmDLData(orderConfirmationResponse,validateCartResponse, "Retrieve","fiveG");
	}

	@Test
	public void updateDeviceCartMapInRedisTest() {
		Assert.assertNotNull(cxpHelper.updateDeviceCartMapInRedis(null));
	}

	@Test(expected = NullPointerException.class)
	public void releaseRPSPendingOrderTest() {
		RPSReleasePendingOrderUIRequest RPSReleasePendingOrderUIRequestObj = new RPSReleasePendingOrderUIRequest();
		RPSReleasePendingOrderUIRequestObj.setLineItemInfoList(Arrays.asList(new RPSOrderDetailsUIRequest()));
		RPSReleasePendingOrderCXPResponse RPSReleasePendingOrderCXPResponseObj = new RPSReleasePendingOrderCXPResponse();
		RPSReleasePendingOrderRequestCXPRequest RPSReleasePendingOrderRequestCXPRequestObj = new RPSReleasePendingOrderRequestCXPRequest();
		RPSReleasePendingOrderRequestCXPRequestObj.setData(new RPSReleasePendingOrderDetails());
		RPSReleasePendingOrderRequestCXPRequestObj.getData().setLineItemInfoList(Arrays.asList(new LineItemInfo()));
		//CartCxpRequestUtil mock = org.mockito.Mockito.mock(CartCxpRequestUtil.class);
		//when(mock.formatReleasePendingOrderRequest(RPSReleasePendingOrderUIRequestObj, RPSReleasePendingOrderRequestCXPRequestObj)).thenReturn(RPSReleasePendingOrderRequestCXPRequestObj);
		when(cxpService.releaseRPSPendingOrder(Mockito.any())).thenReturn(Mono.just(RPSReleasePendingOrderCXPResponseObj));
		StepVerifier.create(cxpHelper2.releaseRPSPendingOrder(RPSReleasePendingOrderUIRequestObj)).expectError();
	}

	@Test
	public void calculateOrderFlowTypeFromValidateTest() throws IOException{
		String sampleRequestString = "{\"meta\": {\"type\": \"customer\"},\"cartId\":\"5560eeed-2ad2-4634-866b-c4986502594b\",\"channel\":\"assissted\",\"pageId\":\"landing\",\"flow\":\"upgrade\"}";
		String sampleResponseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"ACCESSORY\",\"cartHasPCD\":false,\"isPreconfigureEnabled\":true,\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
		ValidateCartCXPRequest request = mapper.readValue(sampleRequestString, ValidateCartCXPRequest.class);
		ValidateCartCXPResponse sampleCXPResponse = mapper.readValue(sampleResponseString, ValidateCartCXPResponse.class);
		when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just("nse"));
		when(redisHelper2.updateCartOrderFlowType(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		when(cxpService.validateCart(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(new ValidateCartCXPResponse()));
		when(cxpService.validateCart(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(new ValidateCartCXPResponse()));
		when(redisHelper2.upsertDeviceCartMapInRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		when(cxpService.validateCartNewCustomer(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ValidateCartCXPResponse()));
		CartRedisData data=new CartRedisData();
		StepVerifier.create(cxpHelper.validateCart(request,data)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void RetriveMinicart() throws JsonParseException, JsonMappingException, IOException {

		String sampleRequestString = "{\"meta\":{\"type\":\"retrieveMinicart\",\"client\":\"VZW-DOTCOM\"},\"cartId\":\"5560eeed-2ad2-4634-866b-c4986502594b\",\"channel\":\"assissted\",\"pageId\":\"landing\",\"flow\":\"upgrade\"}";
		String sampleResponseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"ACCESSORY\",\"cartHasPCD\":false,\"isPreconfigureEnabled\":true,\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
		ValidateCartCXPRequest request = mapper.readValue(sampleRequestString, ValidateCartCXPRequest.class);
		ValidateCartCXPResponse sampleCXPResponse = null;
		sampleCXPResponse = mapper.readValue(sampleResponseString, ValidateCartCXPResponse.class);
		Mono<ValidateCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
		when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just("XYZ"));
		when(redisHelper2.updateCartOrderFlowType(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		when(cxpService.validateCart(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sampleCXPResponseMono);
		when(redisHelper2.upsertDeviceCartMapInRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ValidateCartUIResponse> UIResponse = cxpHelper.validateCart(request,null);
		logger.debug("cxpResponse " + UIResponse);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void checkForLocalStoreOffersTest()
	{
		RetrieveCartCXPRequest request = new RetrieveCartCXPRequest();
		RetrieveCartUIResponse soeResponse = new RetrieveCartUIResponse();
		List< CXPLineInfo > cxpLineinfoList = new ArrayList<>();

		CXPRetrieveCartDataVO cxpRetrieveCartDataVO = new CXPRetrieveCartDataVO();

		ReflectionTestUtils.setField(cxpRetrieveCartDataVO, "isLocalStoreOfferEnabled", true);
		ReflectionTestUtils.setField(cxpHelper, "localStoreOfferCatCodes", "VBMOFFER6,DISCPROMO");

		cxpRetrieveCartDataVO.setEligiblePlanIdsForLocalStoreOffer("invalid,invalid");
		CXPCartVO cxpCartVO = new CXPCartVO();
		CXPLineDetailsVO cxpLineDetailsVO = new CXPLineDetailsVO();
		cxpCartVO.setLineDetails(cxpLineDetailsVO);
		cxpRetrieveCartDataVO.setCart(cxpCartVO);
		request.setData(cxpRetrieveCartDataVO);

		CXPLineInfo cxpLineInfo = new CXPLineInfo();
		cxpLineInfo.setDeviceTypeSelected("invalid");

		CXPItemInfo[] itemsInfo = new CXPItemInfo[3];
		CXPItemInfo cxpItemInfo = new CXPItemInfo();
		CXPCartItemsVO cartItems = new CXPCartItemsVO();
		CXPCartItem[] cxpCartItems = new CXPCartItem[3];
		CXPCartItem cxpCartItem = new CXPCartItem();
		cxpCartItems[0] = cxpCartItem;
		cxpCartItem.setCartItemType("DEVICE");
		cxpCartItem.setSorDeviceCategory("SMARTPHONE");
		cartItems.setCartItem(cxpCartItems);
		cxpItemInfo.setCartItems(cartItems);
		itemsInfo[0] = cxpItemInfo;
		cxpLineInfo.setItemsInfo(itemsInfo);
		ServiceInfo serviceInfo = new ServiceInfo();
		PricePlanInfo pricePlanInfo = new PricePlanInfo();
		serviceInfo.setNewPricePlanInfo(pricePlanInfo);
		serviceInfo.setNewPricePlanId("invalid");
		cxpLineInfo.setServiceInfo(serviceInfo);
		cxpLineInfo.setLineActivityType("NSE");
		SelectedFeaturesList selectedFeaturesList = new SelectedFeaturesList();
		List<VisFeature> featureList = new ArrayList<>();
		VisFeature visFeature = new VisFeature();
		String[] categoryCodes = new String[2];
		categoryCodes[0] = "VBMOFFER6";
		categoryCodes[1] = "DISCPROMO";
		visFeature.setCategoryCodes(List.of(categoryCodes));
		visFeature.setAddDeleteInd("A");
		featureList.add(visFeature);
		selectedFeaturesList.setVisFeature(featureList);
		cxpLineInfo.getServiceInfo().setSelectedFeaturesList(selectedFeaturesList);
		cxpLineinfoList.add(cxpLineInfo);

		soeResponse.setData(cxpRetrieveCartDataVO);
		ReflectionTestUtils.invokeMethod(cxpHelper, "checkForLocalStoreOffers", request, soeResponse, cxpLineinfoList);
		visFeature.setAddDeleteInd("D");
		ReflectionTestUtils.invokeMethod(cxpHelper, "checkForLocalStoreOffers", request, soeResponse, cxpLineinfoList);
	}

	@Test
	public void filterResultsByKeyWordInMakeOrModelTest()
	{
		TypeAheadData typeAheadDataObjectUI = new TypeAheadData();
		List<String> keys = new ArrayList<>();

		keys.add("test");
		typeAheadDataObjectUI.setMake_typeahead("invalid");
		typeAheadDataObjectUI.setModel_name_typeahead("valid");

		List<String> simOutWordList = new ArrayList<>();
		ReflectionTestUtils.setField(cxpHelper, "simOutWordList", simOutWordList);
		ReflectionTestUtils.invokeMethod(cxpHelper, "filterResultsByKeyWordInMakeOrModel", typeAheadDataObjectUI, keys);
	}
	@Test
	public void filterResultsByKeyWordInMakeOrModelTest1()
	{
		TypeAheadData typeAheadDataObjectUI = new TypeAheadData();
		List<String> keys = new ArrayList<>();

		keys.add("valid");
		typeAheadDataObjectUI.setMake_typeahead("invalid");
		typeAheadDataObjectUI.setModel_name_typeahead("valid");

		List<String> simOutWordList = new ArrayList<>();
		ReflectionTestUtils.setField(cxpHelper, "simOutWordList", simOutWordList);
		ReflectionTestUtils.invokeMethod(cxpHelper, "filterResultsByKeyWordInMakeOrModel", typeAheadDataObjectUI, keys);
	}
}
