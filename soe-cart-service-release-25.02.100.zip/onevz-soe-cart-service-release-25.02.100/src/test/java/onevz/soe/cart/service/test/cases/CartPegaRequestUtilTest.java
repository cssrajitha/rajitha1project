package onevz.soe.cart.service.test.cases;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.cxp.feature.Flag;
import onevz.cxp.feature.util.FeatureFlag;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelperTest;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.constants.FeatureFlagConstants;
import onevz.soe.cart.model.addPromoIntent.AddPromoIntent;
import onevz.soe.cart.model.addTrialContactInfoAndAddress.AddTrialContactInfoAndAddressUIRequest;
import onevz.soe.cart.model.common.CartServiceContextInfo;
import onevz.soe.cart.model.common.CartServiceServiceHeader;
import onevz.soe.cart.model.common.Feature;
import onevz.soe.cart.model.initiateValidateDeviceSim.InitiateValidateDeviceSimUIRequest;
import onevz.soe.cart.requests.*;
import onevz.soe.cart.responses.AddAccessoriesPEGAResponse;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.service.test.common.CartAbstractService;
import onevz.soe.cart.service.test.common.CartServiceTestConstants;
import onevz.soe.cart.service.test.common.TestConfig;
import onevz.soe.cart.ui.common.DeviceCartInfo;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.AddAccessoriesUIResponse;
import onevz.soe.cart.util.*;
import onevz.soe.spring.web.filter.RequestAccessContext;
import onevz.soe.spring.web.filter.RequestAccessContext.RequestAccess;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.LinkedMultiValueMap;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertFalse;

import java.io.IOException;
import java.lang.reflect.Field;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static onevz.soe.cart.constants.CartConstants.FLOW_TYPE_WHW;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest
public class CartPegaRequestUtilTest extends CartAbstractService {
	
	@Autowired
	private ObjectMapper mapper;

	@InjectMocks
	private CartPegaRequestUtil cartPegaRequestUtil;

	@MockBean
	FeatureFlag featureFlag;
	@Before
	public void setUp(){
//		ReflectionTestUtils.setField(cartPegaRequestUtil,"enableDvmConversionFlag",true);
		final LinkedMultiValueMap<String, HttpCookie> cookies = new LinkedMultiValueMap<>();
		HttpCookie migrationCookie = new HttpCookie(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, "true-cookie");
		HttpCookie dvmCookie = new HttpCookie(CartConstants.DVM_CONVERSION_COOKIE, "true-cookie");
		cookies.add(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, migrationCookie);
		cookies.add(CartConstants.DVM_CONVERSION_COOKIE, dvmCookie);
		RequestAccessContext.RequestAccess requestAccess = new RequestAccessContext.RequestAccess(cookies, new HttpHeaders());
		RequestAccessContext.updateRequestData(requestAccess);
	}

	private Flag getFFlag() {
		Flag flag = new Flag();
		flag.setName(FeatureFlagConstants.FLAG_NAME_ACTIVATION_FEE_WAIVER_FFAG);
		flag.setEnabled(true);
		flag.setFound(true);
		List<String> offerCode = new ArrayList<>();
		offerCode.add("DP2PM");
		Map<String, List<String>> fmap = new HashMap<>();
		fmap.put("offerCode", offerCode);
		flag.setAttributes(fmap);
		Mockito.when(featureFlag.getFeatureFlag(any(), any(), any())).thenReturn(Mono.just(flag));

		return flag;
	}



	@Test
	public void addAccessoryXboxTest() throws IOException {
		TestConfig gwConfig = getData(CartServiceTestConstants.ADD_ACCESSORY_PATH, "add-accessory-xbox");
        String sampleUIRequestString = gwConfig.getRequest();
        AddAccessoriesUIRequest UIRequest = new AddAccessoriesUIRequest();
        AddAccessoryPEGARequest pegaRequest = new AddAccessoryPEGARequest();
		UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
		CartPegaRequestUtil3.formatAddAccessoriesRequest(pegaRequest, UIRequest, "", true);
		StepVerifier.create(Mono.just(pegaRequest))
		.assertNext(req -> Assert.assertEquals("GAMINGCONSOLE", req.getServiceBody().getServiceRequest().getContext().getCartInfo().getSubscriptionType()))
		.expectComplete().verify();
	}
	
	@Test
	public void addAccessoryXboxClearCartTest() throws IOException {
		TestConfig gwConfig = getData(CartServiceTestConstants.ADD_ACCESSORY_PATH, "add-accessory-xbox-clear-cart");
        String sampleUIRequestString = gwConfig.getRequest();
        AddAccessoriesUIRequest UIRequest = new AddAccessoriesUIRequest();
        AddAccessoryPEGARequest pegaRequest = new AddAccessoryPEGARequest();
		UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
		CartPegaRequestUtil3.formatAddAccessoriesRequest(pegaRequest, UIRequest, "", true);
		StepVerifier.create(Mono.just(pegaRequest))
		.assertNext(req -> Assert.assertEquals(true, req.getServiceBody().getServiceRequest().getContext().getCartInfo().getClearCart()))
		.expectComplete().verify();
	}
	
	@Test
	public void addAccessoriesXboxResponseErrorTest() throws IOException {
			String sampleResponseString = "{\r\n" + 
					"	\"errors\": [\r\n" + 
					"		{\r\n" + 
					"			\"name\": \"Order Validation Failure: Device cannot be added because Subscription ACC and Regular ACC order cannot be created together\",\r\n" + 
					"			\"id\": \"3380\",\r\n" + 
					"			\"message\": \"Item no longer available\",\r\n" + 
					"			\"severity\": \"High\",\r\n" + 
					"			\"errorCategory\": \"BUSINESSERR\",\r\n" + 
					"			\"category\": \"BUSINESS_ERR\"\r\n" + 
					"		}\r\n" + 
					"	]\r\n" + 
					"}";
			AddAccessoriesPEGAResponse responseServiceMono = null;
			responseServiceMono = mapper.readValue(sampleResponseString, AddAccessoriesPEGAResponse.class);
			AddAccessoriesUIResponse uiResponse = new AddAccessoriesUIResponse();
			CartPegaResponseUtil.formatAddAccessoriesResponse(uiResponse, responseServiceMono);
			StepVerifier.create(Mono.just(uiResponse)).assertNext(res -> {
				Assert.assertEquals("3380", res.getErrors().get(0).getId());
			}).expectComplete().verify();
	}
	
	@Test
	public void addAccessoriesNonXboxResponseErrorTest() throws IOException {
			String sampleResponseString = "{\r\n" + 
					"	\"errors\": [\r\n" + 
					"		{\r\n" + 
					"			\"name\": \"Order Validation Failure: Device cannot be added because Subscription ACC and Regular ACC order cannot be created together\",\r\n" + 
					"			\"id\": \"3381\",\r\n" + 
					"			\"message\": \"Item no longer available\",\r\n" + 
					"			\"severity\": \"High\",\r\n" + 
					"			\"errorCategory\": \"BUSINESSERR\",\r\n" + 
					"			\"category\": \"BUSINESS_ERR\"\r\n" + 
					"		}\r\n" + 
					"	]\r\n" + 
					"}";
			AddAccessoriesPEGAResponse responseServiceMono = null;
			responseServiceMono = mapper.readValue(sampleResponseString, AddAccessoriesPEGAResponse.class);
			AddAccessoriesUIResponse uiResponse = new AddAccessoriesUIResponse();
			CartPegaResponseUtil.formatAddAccessoriesResponse(uiResponse, responseServiceMono);
			StepVerifier.create(Mono.just(uiResponse)).assertNext(res -> {
				Assert.assertEquals("3381", res.getErrors().get(0).getId());
			}).expectComplete().verify();
	}
	 
	@Test
	public void addAccessoriesXboxCountResponseErrorTest() throws IOException {
			String sampleResponseString = "{\r\n" + 
					"    \"errors\": [\r\n" + 
					"        {\r\n" + 
					"            \"name\": \"CART_ACCESSORY_ACCOUNT_RESTRICTION_EXCEPTION\",\r\n" + 
					"            \"id\": \"3331\",\r\n" + 
					"            \"message\": \"Customer already has this accessory on the Customer Account. Accessory Limit Exceeded.\",\r\n" + 
					"            \"severity\": \"High\",\r\n" + 
					"            \"category\": \"BUSINESS_ERR\",\r\n" + 
					"            \"proactiveChatCustomMSG\": \"We see you are experiencing issues with your order. Chat now to connect to a live agent for further assistance\",\r\n" + 
					"            \"proactiveChatIndicator\": \"Y\"\r\n" + 
					"        }\r\n" + 
					"    ]\r\n" + 
					"}";
			AddAccessoriesPEGAResponse responseServiceMono = null;
			responseServiceMono = mapper.readValue(sampleResponseString, AddAccessoriesPEGAResponse.class);
			AddAccessoriesUIResponse uiResponse = new AddAccessoriesUIResponse();
			CartPegaResponseUtil.formatAddAccessoriesResponse(uiResponse, responseServiceMono);
			StepVerifier.create(Mono.just(uiResponse)).assertNext(res -> {
				Assert.assertEquals("3331", res.getErrors().get(0).getId());
			}).expectComplete().verify();
	}
	
	@Test
	public void addPlanPEGARequest() throws IOException {
		//TestConfig gwConfig = getData(CartServiceTestConstants.ADD_ACCESSORY_PATH, "add-plan-5ghome");
		String sampleUIRequestString =  "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"editAccessory\":false,\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"AccessoryPDP\",\"processAction\":\"addAccessoryAndCheckout\",\"intendType\":\"ACC\",\"intent\":\"StandAloneAccessory\",\"expressflowForAcc\":true,\"expressCheckout\":false,\"subscriptionType\":\"GAMINGCONSOLE\"},\"data\":{\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"\",\"mdnFilterValue\":\"\",\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"preBackOrderDate\":\"\",\"preBackOrderDisplayType\":\"\",\"addAccessories\":[{\"giftCard\":false,\"id\":\"RRT-00001\",\"qty\":1,\"isSoftSku\":false,\"accessoryBundle\":false,\"productId\":\"acc18040009\",\"category\":\"Gaming\",\"isEcpdDiscountEligilble\":false,\"cashOptionEnabled\":true}]}],\"rtm\":{\"url\":\"https://vzwqa1.verizonwireless.com/products/xbox-console-series-x/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/microsoft-xbox-w-controller-a-a?fmt=pjpg\",\"name\":\"All Access - Series X Console\",\"make\":\"Xbox\",\"categoryId\":\"Gaming\",\"pageURL\":\"https://vzwqa1.verizonwireless.com/products/xbox-all-access-series-x-console/\",\"acc_url\":\"https://vzwqa1.verizonwireless.com/products/xbox-console-series-x/\",\"acc_img\":\"https://ss7.vzw.com/is/image/VerizonWireless/microsoft-xbox-w-controller-a-a?fmt=pjpg\",\"acc_categoryId\":\"Gaming\"}}}";
        //String sampleUIRequestString = gwConfig.getRequest();
        AddPlanUIRequest UIRequest = new AddPlanUIRequest();
        AddPlanPEGARequest pegaRequest = new AddPlanPEGARequest();
		UIRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
		CartPegaRequestUtil2.formatAddPlanRequest(pegaRequest, UIRequest, true, false, getFFlag(), true);
		StepVerifier.create(Mono.just(pegaRequest))
		.assertNext(req -> Assert.assertNotNull(pegaRequest))
		.expectComplete().verify();
	}

	@Test
	public void addPlanPEGARequestTYS() throws IOException {
		//TestConfig gwConfig = getData(CartServiceTestConstants.ADD_ACCESSORY_PATH, "add-plan-5ghome");
		String sampleUIRequestString =  "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"editAccessory\":false,\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"AccessoryPDP\",\"processAction\":\"addAccessoryAndCheckout\",\"intendType\":\"ACC\",\"intent\":\"StandAloneAccessory\",\"expressflowForAcc\":true,\"expressCheckout\":false,\"subscriptionType\":\"GAMINGCONSOLE\"},\"data\":{\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"\",\"mdnFilterValue\":\"\",\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"preBackOrderDate\":\"\",\"preBackOrderDisplayType\":\"\",\"addAccessories\":[{\"giftCard\":false,\"id\":\"RRT-00001\",\"qty\":1,\"isSoftSku\":false,\"accessoryBundle\":false,\"productId\":\"acc18040009\",\"category\":\"Gaming\",\"isEcpdDiscountEligilble\":false,\"cashOptionEnabled\":true}]}],\"rtm\":{\"url\":\"https://vzwqa1.verizonwireless.com/products/xbox-console-series-x/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/microsoft-xbox-w-controller-a-a?fmt=pjpg\",\"name\":\"All Access - Series X Console\",\"make\":\"Xbox\",\"categoryId\":\"Gaming\",\"pageURL\":\"https://vzwqa1.verizonwireless.com/products/xbox-all-access-series-x-console/\",\"acc_url\":\"https://vzwqa1.verizonwireless.com/products/xbox-console-series-x/\",\"acc_img\":\"https://ss7.vzw.com/is/image/VerizonWireless/microsoft-xbox-w-controller-a-a?fmt=pjpg\",\"acc_categoryId\":\"Gaming\"}}}";
		//String sampleUIRequestString = gwConfig.getRequest();
		AddPlanUIRequest UIRequest = new AddPlanUIRequest();
		AddPlanPEGARequest pegaRequest = new AddPlanPEGARequest();
		UIRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
		CartPegaRequestUtil2.formatAddPlanRequest(pegaRequest, UIRequest, true,false, getFFlag(), true);
		StepVerifier.create(Mono.just(pegaRequest))
				.assertNext(req -> Assert.assertNotNull(pegaRequest))
				.expectComplete().verify();
	}
	
	@Test
	public void addPlanPEGARequestOneSPO() throws IOException {
		//TestConfig gwConfig = getData(CartServiceTestConstants.ADD_ACCESSORY_PATH, "add-plan-5ghome");
		String sampleUIRequestString =  "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"editAccessory\":false,\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"AccessoryPDP\",\"processAction\":\"addAccessoryAndCheckout\",\"intendType\":\"ACC\",\"intent\":\"StandAloneAccessory\",\"expressflowForAcc\":true,\"expressCheckout\":false,\"subscriptionType\":\"GAMINGCONSOLE\"},\"data\":{\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"\",\"mdnFilterValue\":\"\",\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"preBackOrderDate\":\"\",\"preBackOrderDisplayType\":\"\",\"addAccessories\":[{\"giftCard\":false,\"id\":\"RRT-00001\",\"qty\":1,\"isSoftSku\":false,\"accessoryBundle\":false,\"productId\":\"acc18040009\",\"category\":\"Gaming\",\"isEcpdDiscountEligilble\":false,\"cashOptionEnabled\":true}]}],\"rtm\":{\"url\":\"https://vzwqa1.verizonwireless.com/products/xbox-console-series-x/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/microsoft-xbox-w-controller-a-a?fmt=pjpg\",\"name\":\"All Access - Series X Console\",\"make\":\"Xbox\",\"categoryId\":\"Gaming\",\"pageURL\":\"https://vzwqa1.verizonwireless.com/products/xbox-all-access-series-x-console/\",\"acc_url\":\"https://vzwqa1.verizonwireless.com/products/xbox-console-series-x/\",\"acc_img\":\"https://ss7.vzw.com/is/image/VerizonWireless/microsoft-xbox-w-controller-a-a?fmt=pjpg\",\"acc_categoryId\":\"Gaming\"}}}";
        AddPlanUIRequest UIRequest = new AddPlanUIRequest();
        AddPlanPEGARequest pegaRequest = new AddPlanPEGARequest();
		UIRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
		CartPegaRequestUtil2.formatAddPlanRequest(pegaRequest, UIRequest, true,false, getFFlag(), true);
		StepVerifier.create(Mono.just(pegaRequest))
		.assertNext(req -> Assert.assertNotNull(pegaRequest))
		.expectComplete().verify();
	}

	@Test
	public void addAccessoryXboxAddAccessoryTest() throws IOException {
		TestConfig gwConfig = getData(CartServiceTestConstants.ADD_ACCESSORY_PATH, "add-accessory-xbox-add-accessory");
        String sampleUIRequestString = gwConfig.getRequest();
        AddAccessoriesUIRequest UIRequest = new AddAccessoriesUIRequest();
        AddAccessoryPEGARequest pegaRequest = new AddAccessoryPEGARequest();
		UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
		CartPegaRequestUtil3.formatAddAccessoriesRequest(pegaRequest, UIRequest, "", true);
		StepVerifier.create(Mono.just(pegaRequest))
		.assertNext(req -> Assert.assertEquals("GAMINGCONSOLE", req.getServiceBody().getServiceRequest().getContext().getCartInfo().getSubscriptionType()))
		.expectComplete().verify();
	}

	@Test
	public void addAccessoryXboxRemoveAccessoryTest() throws IOException {
		TestConfig gwConfig = getData(CartServiceTestConstants.ADD_ACCESSORY_PATH, "add-accessory-xbox-remove-accessory");
        String sampleUIRequestString = gwConfig.getRequest();
        AddAccessoriesUIRequest UIRequest = new AddAccessoriesUIRequest();
        AddAccessoryPEGARequest pegaRequest = new AddAccessoryPEGARequest();
		UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
		CartPegaRequestUtil3.formatAddAccessoriesRequest(pegaRequest, UIRequest, "", true);
		StepVerifier.create(Mono.just(pegaRequest))
		.assertNext(req -> Assert.assertEquals("GAMINGCONSOLE", req.getServiceBody().getServiceRequest().getContext().getCartInfo().getSubscriptionType()))
		.expectComplete().verify();
	}

	@Test
	public void addPlanPEGARequestRFEX() throws IOException {
		//TestConfig gwConfig = getData(CartServiceTestConstants.ADD_ACCESSORY_PATH, "add-plan-5ghome");
		String sampleUIRequestString = "{\"cartInfo\":{\"cartCreator\":\"6205464031\",\"processingMTN\":\"6205464031\",\"processStep\":\"PlanSelection\",\"intendType\":\"REX\"},\"data\":{\"lines\":[{\"mtn\":\"6205464285\",\"plan\":{\"id\":\"50434\",\"isRecommendedPlan\":false,\"recommender\":\"\"}},{\"mtn\":\"6205464780\",\"plan\":{\"id\":\"50434\",\"isRecommendedPlan\":false,\"recommender\":\"\"}}],\"parentMtn\":\"\"}}";
		//String sampleUIRequestString = gwConfig.getRequest();
		AddPlanUIRequest UIRequest = new AddPlanUIRequest();
		AddPlanPEGARequest pegaRequest = new AddPlanPEGARequest();
		UIRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
		CartPegaRequestUtil2.formatAddPlanRequest(pegaRequest, UIRequest, true,false, getFFlag(), true);
		StepVerifier.create(Mono.just(pegaRequest))
				.assertNext(req -> Assert.assertNotNull(pegaRequest))
				.expectComplete().verify();
	}


	//increasing coverage
	@Test
	public void formatInitiateCheckoutRequestTest() throws IOException {
		//TestConfig gwConfig = getData(CartServiceTestConstants.ADD_ACCESSORY_PATH, "add-plan-5ghome");
		String sampleUIRequestString = "{\"cartInfo\":{\"isCareRepAssisted\":\"true\",\"intendType\":\"REX\",\"creditAppNum\":\"1234\",\"creditStatus\":\"Done\",\"flowType\":\"BBP\",\"clientAppName\":\"EXPRESS-STORE\",\"correlationId\":\"2022-05-10T13:09:15.+0000:4c0e2b23-36b8-4313-9ada-5b2c2c43d361:cxp-customerprofile-se-qa-ev6v-sit3e-nscxp-568698f4cd-rrtp8:nssit3\",\"cartId\":\"264e15b7-0259-4fb4-8677-2d721e833326\",\"caseId\":\"SOP-4073532-C01\",\"accountNumber\":\"0624305202-00003\",\"cartCreator\":\"7064009338\",\"processingMTN\":\"7064009338\",\"locationCode\":\"0026301\",\"salesRepId\":\"ENC\"}}";
		//String sampleUIRequestString = gwConfig.getRequest();
		InitiateCheckoutUIRequest UIRequest = new InitiateCheckoutUIRequest();
		InitiateCheckoutPEGARequest pegaRequest = new InitiateCheckoutPEGARequest();
		UIRequest = mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
		CartPegaRequestUtil2.formatInitiateCheckoutRequest(pegaRequest, UIRequest);
		StepVerifier.create(Mono.just(pegaRequest))
				.assertNext(req -> Assert.assertNotNull(pegaRequest))
				.expectComplete().verify();
	}

	@Test
	public void formatAddTrialContactInfoAndAddressPegaRequestTest() throws IOException {
		//TestConfig gwConfig = getData(CartServiceTestConstants.ADD_ACCESSORY_PATH, "add-plan-5ghome");
		String sampleUIRequestString = "{\r\n" +
				"    \"data\": {\r\n" +
				"        \"processStep\": \"ContactInfo\",\r\n" +
				"        \"processAction\": \"addTrailContactInfo\",\r\n" +
				"        \"intendType\": \"BYOD\",\r\n" +
				"        \"intent\": \"BYOD\",\r\n" +
				"        \"itemType\": \"TRIALADDRESS\",\r\n" +
				"        \"isAccountInfoUpdation\": \"true\",\r\n" +
				"        \"trialContactInfo\": {\r\n" +
				"            \"firstName\": \"JAMES\",\r\n" +
				"            \"lastName\": \"SMITH\",\r\n" +
				"            \"emailId\": \"JAMES.SMITH@VERIZONWIRELESS.COM\",\r\n" +
				"            \"phoneNumber\": \"9492866651\"\r\n" +
				"        },\r\n" +
				"        \"trialAddress\": null\r\n" +
				"    }\r\n" +
				"}";
		//String sampleUIRequestString = gwConfig.getRequest();
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"cartCreator\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"processingMTN\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"channelId\": \"VZW-DOTCOM-BBP\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"bbpImei\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		AddTrialContactInfoAndAddressUIRequest UIRequest = new AddTrialContactInfoAndAddressUIRequest ();
		AddTrialContactInfoAndAddressPEGARequest pegaRequest = new AddTrialContactInfoAndAddressPEGARequest ();
		UIRequest = mapper.readValue(sampleUIRequestString, AddTrialContactInfoAndAddressUIRequest.class);
		CartPegaRequestUtil8.formatAddTrialContactInfoAndAddressPegaRequest(UIRequest,pegaRequest, sampleRedisData);
		StepVerifier.create(Mono.just(pegaRequest))
				.assertNext(req -> Assert.assertNotNull(pegaRequest))
				.expectComplete().verify();
	}

	@Test
	public void formatAddTrialAddressPegaRequestTest() throws IOException {
		//TestConfig gwConfig = getData(CartServiceTestConstants.ADD_ACCESSORY_PATH, "add-plan-5ghome");
		String sampleUIRequestString = "{\r\n" +
				"    \"data\": {\r\n" +
				"        \"processStep\": \"TrialAddress\",\r\n" +
				"        \"processAction\": \"addTrialAddress\",\r\n" +
				"        \"intent\": \"BYOD\",\r\n" +
				"        \"intendType\": \"BYOD\",\r\n" +
				"        \"itemType\": \"TRIALADDRESS\",\r\n" +
				"        \"isAccountInfoUpdation\": \"false\",\r\n" +
				"        \"trialContactInfo\": null,\r\n" +
				"        \"trialAddress\": {\r\n" +
				"            \"addressLine1\": \"201 CENTENNIAL AVE\",\r\n" +
				"            \"addressLine2\": \"0795694511/4800074391\",\r\n" +
				"            \"zipCode\": \"08854\",\r\n" +
				"            \"city\": \"PISCATAWAY\",\r\n" +
				"            \"state\": \"NJ\"\r\n" +
				"        }\r\n" +
				"    }\r\n" +
				"}\r\n" +
				"";
		//String sampleUIRequestString = gwConfig.getRequest();
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"cartCreator\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"processingMTN\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"channelId\": \"VZW-DOTCOM-BBP\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"bbpImei\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		AddTrialContactInfoAndAddressUIRequest  UIRequest = new AddTrialContactInfoAndAddressUIRequest ();
		AddTrialContactInfoAndAddressPEGARequest  pegaRequest = new AddTrialContactInfoAndAddressPEGARequest ();
		UIRequest = mapper.readValue(sampleUIRequestString, AddTrialContactInfoAndAddressUIRequest.class);
		CartPegaRequestUtil8.formatAddTrialContactInfoAndAddressPegaRequest(UIRequest,pegaRequest, sampleRedisData);
		StepVerifier.create(Mono.just(pegaRequest))
				.assertNext(req -> Assert.assertNotNull(pegaRequest))
				.expectComplete().verify();
	}

	@Test
	public void formatInitiateValidateDeviceSimTest() throws IOException {
		//TestConfig gwConfig = getData(CartServiceTestConstants.ADD_ACCESSORY_PATH, "add-plan-5ghome");
		String sampleUIRequestString = "{\"data\":{\"postPaidInd\":\"Y\",\"processStep\":\"\",\"processAction\":\"initiateValidateDeviceSim\",\"intendType\":\"BYOD\"}}";
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"bbpImei\": \"8436667390\",\"bbpIccid\":\"89148000005148869944\" }";
		//String sampleUIRequestString = gwConfig.getRequest();
		InitiateValidateDeviceSimUIRequest UIRequest = new InitiateValidateDeviceSimUIRequest();
		InitiateValidateDeviceSimPEGARequest pegaRequest = new InitiateValidateDeviceSimPEGARequest();
		CartRedisData sampleRedisData = new CartRedisData();
		UIRequest = mapper.readValue(sampleUIRequestString, InitiateValidateDeviceSimUIRequest.class);
		sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, "http://localhost/initiateValidateDeviceSim").build();
		CartPegaRequestUtil8.formatInitiateValidateDeviceSimRequest(pegaRequest, UIRequest, httpHeader, sampleRedisData);
		StepVerifier.create(Mono.just(pegaRequest))
				.assertNext(req -> Assert.assertNotNull(pegaRequest))
				.expectComplete().verify();
	}

	@Test
	public void formatInitiateValidateDeviceSimWithHeadersTest() throws IOException {
		//TestConfig gwConfig = getData(CartServiceTestConstants.ADD_ACCESSORY_PATH, "add-plan-5ghome");
		String sampleUIRequestString = "{\"data\":{\"postPaidInd\":\"Y\",\"processStep\":\"\",\"processAction\":\"initiateValidateDeviceSim\",\"intendType\":\"BYOD\"}}";
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"bbpImei\": \"8436667390\",\"bbpIccid\":\"89148000005148869944\" }";
		//String sampleUIRequestString = gwConfig.getRequest();
		InitiateValidateDeviceSimUIRequest UIRequest = new InitiateValidateDeviceSimUIRequest();
		InitiateValidateDeviceSimPEGARequest pegaRequest = new InitiateValidateDeviceSimPEGARequest();
		CartRedisData sampleRedisData = new CartRedisData();
		UIRequest = mapper.readValue(sampleUIRequestString, InitiateValidateDeviceSimUIRequest.class);
		sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, "http://localhost/initiateValidateDeviceSim").header("accountNumber", "accountNumber").build();
		CartPegaRequestUtil8.formatInitiateValidateDeviceSimRequest(pegaRequest, UIRequest, httpHeader, sampleRedisData);
		StepVerifier.create(Mono.just(pegaRequest))
				.assertNext(req -> Assert.assertNotNull(pegaRequest))
				.expectComplete().verify();
	}

    @Test
    public void formatGuestChoiceTest() throws IOException {
        //TestConfig gwConfig = getData(CartServiceTestConstants.ADD_ACCESSORY_PATH, "add-plan-5ghome");
        String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"ShoppingCart\",\"processAction\":\"checkOut\",\"intendType\":\"NSEACC\",\"intent\":\"StandAloneAccessory\",\"editAccessory\":false,\"expressflowForAcc\":false,\"mtnFlow\":\"D\",\"globalId\":\"\",\"customerType\":\"N\",\"zipCode\":\"\"}}";        //String sampleUIRequestString = gwConfig.getRequest();
        GuestChoiceUIRequest UIRequest = new GuestChoiceUIRequest();
        GuestChoicePEGARequest pegaRequest = new GuestChoicePEGARequest();
        UIRequest = mapper.readValue(sampleUIRequestString, GuestChoiceUIRequest.class);
        CartPegaRequestUtil8.formatGuestChoiceRequest(UIRequest, pegaRequest);
        StepVerifier.create(Mono.just(pegaRequest))
                .assertNext(req -> Assert.assertNotNull(pegaRequest))
                .expectComplete().verify();
    }

    @Test
    public void formatAddReplenishmentRequestTest() throws IOException {
        //TestConfig gwConfig = getData(CartServiceTestConstants.ADD_ACCESSORY_PATH, "add-plan-5ghome");
        String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"OMNI-RETAIL\",\"accountNumber\":\"429134425\",\"cartCreator\":\"429134425\",\"creditAppNum\":\"429134425\",\"cartId\":\"f9d35199-5d42-4de2-815f-0adaa81b2a9c\",\"caseId\":\"SOF-9050592-E01\",\"processingMTN\":\"newLine1\",\"intendType\":\"NSE\",\"processStep\":\"removeReplenishment\"},\"data\":{\"lines\":[{\"mtn\":\"6127915731\",\"isActivateWithoutReplenish\":true,\"replenishmentAmount\":\"0.00\",\"processingMTN\":\"newLine1\"}]}}";
        AddReplenishmentToCartUIRequest UIRequest = new AddReplenishmentToCartUIRequest();
        AddReplenishmentToCartPEGARequest pegaRequest = new AddReplenishmentToCartPEGARequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddReplenishmentToCartUIRequest.class);
        CartPegaRequestUtil9.formatAddReplenishmentRequest(UIRequest, pegaRequest);
        StepVerifier.create(Mono.just(pegaRequest))
                .assertNext(req -> Assert.assertNotNull(pegaRequest))
                .expectComplete().verify();
    }
    @Test
    public void formatAddReplenishmentRequestTest1() throws IOException {
        //TestConfig gwConfig = getData(CartServiceTestConstants.ADD_ACCESSORY_PATH, "add-plan-5ghome");
        String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"OMNI-RETAIL\",\"accountNumber\":\"429134425\",\"cartCreator\":\"429134425\",\"creditAppNum\":\"429134425\",\"cartId\":\"f9d35199-5d42-4de2-815f-0adaa81b2a9c\",\"caseId\":\"SOF-9050592-E01\",\"processingMTN\":\"newLine1\",\"intendType\":\"NSE_5G\",\"processStep\":\"removeReplenishment\"},\"data\":{\"lines\":[{\"mtn\":\"6127915731\",\"isActivateWithoutReplenish\":true,\"replenishmentAmount\":\"0.00\",\"processingMTN\":\"newLine1\"}]}}";
        AddReplenishmentToCartUIRequest UIRequest = new AddReplenishmentToCartUIRequest();
        AddReplenishmentToCartPEGARequest pegaRequest = new AddReplenishmentToCartPEGARequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddReplenishmentToCartUIRequest.class);
        CartPegaRequestUtil9.formatAddReplenishmentRequest(UIRequest, pegaRequest);
        StepVerifier.create(Mono.just(pegaRequest))
                .assertNext(req -> Assert.assertNotNull(pegaRequest))
                .expectComplete().verify();
    }
    
    @Test
    public void formatAddReplenishmentRequestTest2() throws IOException {
        //TestConfig gwConfig = getData(CartServiceTestConstants.ADD_ACCESSORY_PATH, "add-plan-5ghome");
        String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"OMNI-RETAIL\",\"accountNumber\":\"429134425\",\"cartCreator\":\"429134425\",\"creditAppNum\":\"429134425\",\"cartId\":\"f9d35199-5d42-4de2-815f-0adaa81b2a9c\",\"caseId\":\"SOF-9050592-E01\",\"processingMTN\":\"newLine1\",\"intendType\":\"AAL_5G\",\"processStep\":\"removeReplenishment\"},\"data\":{\"lines\":[{\"mtn\":\"6127915731\",\"isActivateWithoutReplenish\":true,\"replenishmentAmount\":\"0.00\",\"processingMTN\":\"newLine1\"}]}}";
        AddReplenishmentToCartUIRequest UIRequest = new AddReplenishmentToCartUIRequest();
        AddReplenishmentToCartPEGARequest pegaRequest = new AddReplenishmentToCartPEGARequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddReplenishmentToCartUIRequest.class);
        CartPegaRequestUtil9.formatAddReplenishmentRequest(UIRequest, pegaRequest);
        StepVerifier.create(Mono.just(pegaRequest))
                .assertNext(req -> Assert.assertNotNull(pegaRequest))
                .expectComplete().verify();
    }
    @Test
    public void formatAddReplenishmentRequestTest3() throws IOException {
        //TestConfig gwConfig = getData(CartServiceTestConstants.ADD_ACCESSORY_PATH, "add-plan-5ghome");
        String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"OMNI-RETAIL\",\"accountNumber\":\"429134425\",\"cartCreator\":\"429134425\",\"creditAppNum\":\"429134425\",\"cartId\":\"f9d35199-5d42-4de2-815f-0adaa81b2a9c\",\"caseId\":\"SOF-9050592-E01\",\"processingMTN\":\"newLine1\",\"intendType\":\"NSE_LTE\",\"processStep\":\"removeReplenishment\"},\"data\":{\"lines\":[{\"mtn\":\"6127915731\",\"isActivateWithoutReplenish\":true,\"replenishmentAmount\":\"0.00\",\"processingMTN\":\"newLine1\"}]}}";
        AddReplenishmentToCartUIRequest UIRequest = new AddReplenishmentToCartUIRequest();
        AddReplenishmentToCartPEGARequest pegaRequest = new AddReplenishmentToCartPEGARequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddReplenishmentToCartUIRequest.class);
        CartPegaRequestUtil9.formatAddReplenishmentRequest(UIRequest, pegaRequest);
        StepVerifier.create(Mono.just(pegaRequest))
                .assertNext(req -> Assert.assertNotNull(pegaRequest))
                .expectComplete().verify();
    }
    
    @Test
    public void formatAddReplenishmentRequestTest4() throws IOException {
        //TestConfig gwConfig = getData(CartServiceTestConstants.ADD_ACCESSORY_PATH, "add-plan-5ghome");
        String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"OMNI-RETAIL\",\"accountNumber\":\"429134425\",\"cartCreator\":\"429134425\",\"creditAppNum\":\"429134425\",\"cartId\":\"f9d35199-5d42-4de2-815f-0adaa81b2a9c\",\"caseId\":\"SOF-9050592-E01\",\"processingMTN\":\"newLine1\",\"intendType\":\"\",\"processStep\":\"removeReplenishment\"},\"data\":{\"lines\":[{\"mtn\":\"6127915731\",\"isActivateWithoutReplenish\":true,\"replenishmentAmount\":\"0.00\",\"processingMTN\":\"newLine1\"}]}}";
        AddReplenishmentToCartUIRequest UIRequest = new AddReplenishmentToCartUIRequest();
        AddReplenishmentToCartPEGARequest pegaRequest = new AddReplenishmentToCartPEGARequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddReplenishmentToCartUIRequest.class);
        CartPegaRequestUtil9.formatAddReplenishmentRequest(UIRequest, pegaRequest);
        StepVerifier.create(Mono.just(pegaRequest))
                .assertNext(req -> Assert.assertNotNull(pegaRequest))
                .expectComplete().verify();
    }
    
    @Test
    public void formatAddReplenishmentRequestTest5() throws IOException {
        //TestConfig gwConfig = getData(CartServiceTestConstants.ADD_ACCESSORY_PATH, "add-plan-5ghome");
        String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"OMNI-RETAIL\",\"accountNumber\":\"429134425\",\"cartCreator\":\"429134425\",\"creditAppNum\":\"429134425\",\"cartId\":\"f9d35199-5d42-4de2-815f-0adaa81b2a9c\",\"caseId\":\"SOF-9050592-E01\",\"processingMTN\":\"newLine1\",\"intendType\":\"AAL_LTE\",\"processStep\":\"removeReplenishment\"},\"data\":{\"lines\":[{\"mtn\":\"6127915731\",\"isActivateWithoutReplenish\":true,\"replenishmentAmount\":\"0.00\",\"processingMTN\":\"newLine1\"}]}}";
        AddReplenishmentToCartUIRequest UIRequest = new AddReplenishmentToCartUIRequest();
        AddReplenishmentToCartPEGARequest pegaRequest = new AddReplenishmentToCartPEGARequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddReplenishmentToCartUIRequest.class);
        CartPegaRequestUtil9.formatAddReplenishmentRequest(UIRequest, pegaRequest);
        StepVerifier.create(Mono.just(pegaRequest))
                .assertNext(req -> Assert.assertNotNull(pegaRequest))
                .expectComplete().verify();
    }
    
    @Test
    public void formatAddReplenishmentRequestTest6() throws IOException {
        //TestConfig gwConfig = getData(CartServiceTestConstants.ADD_ACCESSORY_PATH, "add-plan-5ghome");
        String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"OMNI-RETAIL\",\"accountNumber\":\"429134425\",\"cartCreator\":\"429134425\",\"creditAppNum\":\"429134425\",\"cartId\":\"f9d35199-5d42-4de2-815f-0adaa81b2a9c\",\"caseId\":\"SOF-9050592-E01\",\"processingMTN\":\"newLine1\",\"intendType\":\"AAL_LTE\",\"processStep\":\"removeReplenishment\",\"processAction\":\"removeReplenishment\"},\"data\":{\"lines\":[{\"mtn\":\"6127915731\",\"isActivateWithoutReplenish\":true,\"replenishmentAmount\":\"0.00\",\"processingMTN\":\"newLine1\"}]}}";
        AddReplenishmentToCartUIRequest UIRequest = new AddReplenishmentToCartUIRequest();
        AddReplenishmentToCartPEGARequest pegaRequest = new AddReplenishmentToCartPEGARequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddReplenishmentToCartUIRequest.class);
        CartPegaRequestUtil9.formatAddReplenishmentRequest(UIRequest, pegaRequest);
        StepVerifier.create(Mono.just(pegaRequest))
                .assertNext(req -> Assert.assertNotNull(pegaRequest))
                .expectComplete().verify();
    }
    
    @Test
    public void formatAccountPinRequestTest() throws IOException {
        //TestConfig gwConfig = getData(CartServiceTestConstants.ADD_ACCESSORY_PATH, "add-plan-5ghome");
        String sampleUIRequestString = "{\"cartInfo\":{\"processingMTN\": \"4235344191\",\"intendTpye\": \"AAL\"},\"data\": {\"itemType\": \"SELLERPRICE\",\"action\": \"UPDATE\",\"lines\": [{\"mtn\": \"4699199099\",\"sellerPrice\":\"4699199099\"},{\"mtn\": \"4699199098\",\"sellerPrice\":\"4699199099\"}]}}";
        AccountPinUIRequest UIRequest = new AccountPinUIRequest();
        AccountPinPEGARequest pegaRequest = new AccountPinPEGARequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AccountPinUIRequest.class);
        CartPegaRequestUtil7.formatAccountPinRequest(pegaRequest, UIRequest);
        StepVerifier.create(Mono.just(pegaRequest))
                .assertNext(req -> Assert.assertNotNull(pegaRequest))
                .expectComplete().verify();
    }

    @Test
    public void formatSaveCartWithEmailTest() throws IOException {
        //TestConfig gwConfig = getData(CartServiceTestConstants.ADD_ACCESSORY_PATH, "add-plan-5ghome");
        String sampleUIRequestString = "{\"emaild\":\"usha.kammara@veriozn.com\",\"intendType\":\"NSE_LTE\",\"cartInfo\":{\"globalId\":\"4235344191\"}}";
        SaveCartWithEmailUIRequest UIRequest = new SaveCartWithEmailUIRequest();
        AddPlanAndDevicePEGARequest pegaRequest = new AddPlanAndDevicePEGARequest();
        UIRequest = mapper.readValue(sampleUIRequestString, SaveCartWithEmailUIRequest.class);
        CartPegaRequestUtil8.formatSaveCartWithEmailRequest(pegaRequest, UIRequest);
        StepVerifier.create(Mono.just(pegaRequest))
                .assertNext(req -> Assert.assertNotNull(pegaRequest))
                .expectComplete().verify();
    }

	@Test
	public void indirectCustAddServiceHeader() throws IOException{
		CartServiceServiceHeader cartServiceServiceHeader = new CartServiceServiceHeader();
		CartServiceServiceHeader serviceHeader = CartPegaRequestUtil8.indirectCustAddServiceHeader(cartServiceServiceHeader);
		StepVerifier.create(Mono.just(serviceHeader))
				.assertNext(req -> Assert.assertNotNull(cartServiceServiceHeader))
				.expectComplete().verify();
	}

	@Test
	public void addServiceHeader() throws IOException{
		CartServiceServiceHeader cartServiceServiceHeader = new CartServiceServiceHeader();
		CartServiceServiceHeader serviceHeader = CartPegaRequestUtil.addServiceHeader(cartServiceServiceHeader);
		StepVerifier.create(Mono.just(serviceHeader))
				.assertNext(req -> Assert.assertNotNull(cartServiceServiceHeader))
				.expectComplete().verify();
	}


	@Test
	public void formatUpdateAddressChangePEGARequestTest() throws IOException {

		String sampleUIRequestString = "{\"addressLine1\":\"8 NIBBE LN\",\"streetNumber\":\"8\",\"streetName\":\"NIBBE LN\",\"addressLine2\":\"\",\"cityName\":\"BETHPAGE\",\"state\":\"NY\",\"zipCode\":\"11714\",\"mtn\":null,\"orderNumber\":null,\"lineItemNumber\":null,\"channelID\":\"VZW-NUMBERLINK\",\"streetType\":\"LN\",\"apartmentNo\":\"2\",\"streetDirection\":\"NE\"}\t";

		UpdateAddressChangePEGARequest  pegaRequest = new UpdateAddressChangePEGARequest();
		RPSE911AddressUpdateUIRequest UIRequest = mapper.readValue(sampleUIRequestString, RPSE911AddressUpdateUIRequest.class);
		CartPegaRequestUtil9.formatUpdateAddressChangePEGARequest("","","",UIRequest,pegaRequest);
		StepVerifier.create(Mono.just(pegaRequest))
				.assertNext(req -> Assert.assertNotNull(pegaRequest))
				.expectComplete().verify();
	}
	
	@Test
	public void addServiceHeaderForProcessStep() throws IOException{
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"\",\"correlationId\":\"2022-05-10T13:09:15.+0000:4c0e2b23-36b8-4313-9ada-5b2c2c43d361:cxp-customerprofile-se-qa-ev6v-sit3e-nscxp-568698f4cd-rrtp8:nssit3\",\"cartId\":\"\",\"caseId\":\"\",\"cartCreator\": \"\",\"processingMTN\": \"\",\"accountNumber\": \"\", \"processStep\": \"\", \"processAction\": \"\" , \"deviceType\": \"\",\"customertype\": \"\"}}";
		CartServiceServiceHeader cartServiceServiceHeader = new CartServiceServiceHeader();
		BBPGetProcessStepUIRequest request = mapper.readValue(sampleUIRequestString,BBPGetProcessStepUIRequest.class);
		CartServiceServiceHeader serviceHeader = CartPegaRequestUtil.addServiceHeaderForProcessStep(cartServiceServiceHeader,request);
		StepVerifier.create(Mono.just(serviceHeader))
				.assertNext(req -> Assert.assertNotNull(cartServiceServiceHeader))
				.expectComplete().verify();
	}

	@Test
	public void formatAddDeviceRequestWithAccountgrowthIntentTest() throws IOException{
		String sampleUIRequestString = "{\"validateCartRequest\":null,\"preConfigured\":null,\"externalId\":null,\"vzId\":null,\"path\":null,\"cartInfo\":{\"editDeviceConfiguratorClick\":null,\"editPlanClick\":null,\"specialItemType\":null,\"salesRepId\":null,\"flowType\":null,\"rpsIntent\":null,\"sessionId\":null,\"customerType\":null,\"accountType\":null,\"globalId\":null,\"bbpIntent\":null,\"clientAppName\":\"VZW-ECOM\",\"cartId\":\"15eccfe3-574e-402a-91b4-11c669769d2b\",\"caseId\":\"SOP-7676963-C01\",\"accountNumber\":\"0219838656-00001\",\"cartCreator\":\"5126807507\",\"processingMTN\":\"5126808210\",\"buyOutFlag\":\"Y\",\"buyOutSelected\":\"Y\",\"edgeUpSelected\":\"N\",\"processStep\":\"DPPSummary\",\"intendType\":\"EUP\",\"isQuoteCart\":null,\"processAction\":\"addBuyoutAmtAndDevice\",\"mtnFlow\":\"G\",\"fetchDataFromRedis\":null,\"editDevice\":null,\"showICPage\":null,\"isSmartLocator\":null,\"triggerPricingValidation\":null,\"barCodeIds\":[],\"isGemini\":null,\"isTradeInSelected\":null,\"expressCheckout\":null,\"replaceDevice\":null,\"amRole\":\"accountManager\",\"cradleFlowJourney\":null,\"activateSwitchFlow\":null,\"adobeId\":null,\"referralVendorId\":null,\"ecpdToken\":null,\"rylEcpdUrl\":null,\"referralSaleRepId\":null,\"zipCode\":null,\"disableMyLink\":null,\"authorizedUser\":null,\"cartCreatorSalesRepId\":null,\"fiveGMUCEligible\":null,\"customerConsent\":null},\"data\":{\"recommDevId\":null,\"recommSkuId\":null,\"rtm\":null,\"lines\":[{\"preBackOrderDate\":null,\"preBackOrderDisplayType\":null,\"rebateUpdate\":null,\"instantcredit\":null,\"mldTrunkMtn\":null,\"rtdOfferId\":null,\"restricted\":null,\"restrictedProductType\":null,\"selectedSedOfferId\":null,\"selectedSpoId\":null,\"reasonCode\":null,\"lineActivityType\":null,\"currentPlanType\":null,\"barCodeId\":null,\"inEligibleReason\":null,\"sellerPrice\":null,\"nickName\":null,\"purchasePath\":\"AccountGrowth\",\"donorMtn\":null,\"selectedPromoType\":\"NOPROMO\",\"selectedPromoId\":\"\",\"giftBox\":null,\"idu\":null,\"eupNoPromoFlow\":false,\"accountOwner\":null,\"mtn\":\"5126808210\",\"trialSelected\":null, \"rtdOfferId\":\"345\",\"restricted\":\"Y\",\"subscriptionSelected\":null,\"trialAllowance\":null,\"trialValidityPeriod\":null,\"device\":{\"cartItemType\":null,\"quantityOnHand\":null,\"upgradeReasonCode\":null,\"warningMessage\":null,\"connectedCarMobile\":null,\"connectedCarColor\":null,\"category\":\"Smartphones\",\"giftbox\":null,\"connectedCarDetails\":null,\"refundType\":null,\"id\":\"MLAR3LL/A\",\"dppMonths\":36,\"contractTerm\":\"VERIZON_EDGE\",\"qty\":1,\"fiveGToFourGDownGrade\":null,\"productId\":\"dev16720001\",\"iconicPhone\":true,\"preconfigure\":\"false\",\"token\":null},\"sim\":{\"id\":\"EMBD4GSIM-N\",\"imei2\":null},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"isEdgeBuyOut\":true,\"triggerPricingValidation\":null,\"tabletJetPackDiscountIncluded\":null,\"fiveGUpSell\":null,\"is5GBoltEligible\":null,\"devicePlanCompatible\":null,\"activateLater\":null,\"setUpLater\":null,\"selectedEUPDeviceForBYOD\":null,\"promoRejectionIndicator\":true,\"unpairDevice\":null,\"tradeInInfo\":null,\"editSim\":null,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false}],\"mtnSOIRecommendation\":null,\"totalDeviceDollar\":null,\"selectedMtn\":null},\"channelId\":\"VZW-DOTCOM\"}";
		AddDeviceUIRequest request = mapper.readValue(sampleUIRequestString,AddDeviceUIRequest.class);
		AddDevicePEGARequest pegareq = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(),request,null,true,true, true, getFFlag());
		StepVerifier.create(Mono.just(pegareq))
				.assertNext(req -> Assert.assertNotNull(pegareq.getServiceBody().getServiceRequest().getContext().getCartInfo()))
				.expectComplete().verify();

		//Choice Offer - PromoIntent
		AddPromoIntent promoIntent =  new AddPromoIntent();
		promoIntent.setOfferId("592666");
		promoIntent.setChoiceOffer(true);
		List<AddPromoIntent> promoIntents = new ArrayList<>();
		promoIntents.add(promoIntent);
		request.getData().getLines().get(0).setPromoIntent(promoIntents);
		AddDevicePEGARequest pegareq1 = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(),request,null,true,false, false, getFFlag());
		StepVerifier.create(Mono.just(pegareq))
				.assertNext(req -> Assert.assertNotNull(pegareq.getServiceBody().getServiceRequest().getContext().getCartInfo()))
				.expectComplete().verify();

	}

	@Test
	public void formatAddDeviceRequestNSEBYODNextGenTest() throws IOException{
		String sampleUIRequestString = "{\"validateCartRequest\":null,\"preConfigured\":null,\"externalId\":null,\"vzId\":null,\"path\":null,\"cartInfo\":{\"editDeviceConfiguratorClick\":null,\"editPlanClick\":null,\"specialItemType\":null,\"salesRepId\":null,\"flowType\":null,\"rpsIntent\":null,\"sessionId\":null,\"customerType\":null,\"accountType\":null,\"globalId\":null,\"bbpIntent\":null,\"clientAppName\":\"VZW-ECOM\",\"cartId\":\"15eccfe3-574e-402a-91b4-11c669769d2b\",\"caseId\":\"SOP-7676963-C01\",\"accountNumber\":\"0219838656-00001\",\"cartCreator\":\"5126807507\",\"processingMTN\":\"5126808210\",\"buyOutFlag\":\"Y\",\"buyOutSelected\":\"Y\",\"edgeUpSelected\":\"N\",\"processStep\":\"DPPSummary\",\"intendType\":\"NSEBYOD\",\"cradleFlowJourney\":\"NEXTGEN\",\"isQuoteCart\":null,\"processAction\":\"addBuyoutAmtAndDevice\",\"mtnFlow\":\"G\",\"fetchDataFromRedis\":null,\"editDevice\":null,\"showICPage\":null,\"isSmartLocator\":null,\"triggerPricingValidation\":null,\"barCodeIds\":[],\"isGemini\":null,\"isTradeInSelected\":null,\"expressCheckout\":null,\"replaceDevice\":null,\"amRole\":\"accountManager\",\"cradleFlowJourney\":null,\"activateSwitchFlow\":null,\"adobeId\":null,\"referralVendorId\":null,\"ecpdToken\":null,\"rylEcpdUrl\":null,\"referralSaleRepId\":null,\"zipCode\":null,\"disableMyLink\":null,\"authorizedUser\":null,\"cartCreatorSalesRepId\":null,\"fiveGMUCEligible\":null,\"customerConsent\":null},\"data\":{\"recommDevId\":null,\"recommSkuId\":null,\"rtm\":null,\"lines\":[{\"preBackOrderDate\":null,\"preBackOrderDisplayType\":null,\"rebateUpdate\":null,\"instantcredit\":null,\"mldTrunkMtn\":null,\"rtdOfferId\":null,\"restricted\":null,\"restrictedProductType\":null,\"selectedSedOfferId\":null,\"selectedSpoId\":null,\"reasonCode\":null,\"lineActivityType\":null,\"currentPlanType\":null,\"barCodeId\":null,\"inEligibleReason\":null,\"sellerPrice\":null,\"nickName\":null,\"purchasePath\":\"AccountGrowth\",\"donorMtn\":null,\"selectedPromoType\":\"NOPROMO\",\"selectedPromoId\":\"\",\"giftBox\":null,\"idu\":null,\"eupNoPromoFlow\":false,\"accountOwner\":null,\"mtn\":\"5126808210\",\"trialSelected\":null, \"rtdOfferId\":\"345\",\"restricted\":\"Y\",\"subscriptionSelected\":null,\"trialAllowance\":null,\"trialValidityPeriod\":null,\"device\":{\"cartItemType\":null,\"quantityOnHand\":null,\"upgradeReasonCode\":null,\"warningMessage\":null,\"connectedCarMobile\":null,\"connectedCarColor\":null,\"category\":\"Smartphones\",\"giftbox\":null,\"connectedCarDetails\":null,\"refundType\":null,\"id\":\"MLAR3LL/A\",\"dppMonths\":36,\"contractTerm\":\"VERIZON_EDGE\",\"qty\":1,\"fiveGToFourGDownGrade\":null,\"productId\":\"dev16720001\",\"iconicPhone\":true,\"preconfigure\":\"false\",\"token\":null},\"sim\":{\"id\":\"EMBD4GSIM-N\",\"imei2\":null},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"isEdgeBuyOut\":true,\"triggerPricingValidation\":null,\"tabletJetPackDiscountIncluded\":null,\"fiveGUpSell\":null,\"is5GBoltEligible\":null,\"devicePlanCompatible\":null,\"activateLater\":null,\"setUpLater\":null,\"selectedEUPDeviceForBYOD\":null,\"promoRejectionIndicator\":true,\"unpairDevice\":null,\"tradeInInfo\":null,\"editSim\":null,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false}],\"mtnSOIRecommendation\":null,\"totalDeviceDollar\":null,\"selectedMtn\":null},\"channelId\":\"VZW-DOTCOM\"}";
		AddDeviceUIRequest request = mapper.readValue(sampleUIRequestString,AddDeviceUIRequest.class);
		request.getCartInfo().setCradleFlowJourney("NEXTGEN");
		AddDevicePEGARequest pegareq = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(),request,null,true,false, false, getFFlag());
		StepVerifier.create(Mono.just(pegareq))
				.assertNext(req -> Assert.assertNotNull(pegareq.getServiceBody().getServiceRequest().getContext().getCartInfo()))
				.expectComplete().verify();
		request.getCartInfo().setValidateDevicePlanCompatible(Boolean.TRUE);
		AddDevicePEGARequest addDevicePegaReq = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(),request,null,true,false, false, getFFlag());
		StepVerifier.create(Mono.just(addDevicePegaReq))
				.assertNext(req -> Assert.assertNotNull(addDevicePegaReq.getServiceBody().getServiceRequest().getContext().getCartInfo()))
				.expectComplete().verify();
	}


	@Test
	public void formatAddDeviceRequestForEsimTest() throws IOException{
		String sampleUIRequestString = "{\"validateCartRequest\":null,\"preConfigured\":null,\"externalId\":null,\"vzId\":null,\"path\":null,\"cartInfo\":{\"editDeviceConfiguratorClick\":null,\"editPlanClick\":null,\"specialItemType\":null,\"salesRepId\":null,\"flowType\":null,\"rpsIntent\":null,\"sessionId\":null,\"customerType\":null,\"accountType\":null,\"globalId\":null,\"bbpIntent\":null,\"clientAppName\":\"VZW-ECOM\",\"cartId\":\"15eccfe3-574e-402a-91b4-11c669769d2b\",\"caseId\":\"SOP-7676963-C01\",\"accountNumber\":\"0219838656-00001\",\"cartCreator\":\"5126807507\",\"processingMTN\":\"5126808210\",\"buyOutFlag\":\"Y\",\"buyOutSelected\":\"Y\",\"edgeUpSelected\":\"N\",\"processStep\":\"DPPSummary\",\"intendType\":\"EUP\",\"isQuoteCart\":null,\"processAction\":\"addBuyoutAmtAndDevice\",\"mtnFlow\":\"G\",\"fetchDataFromRedis\":null,\"editDevice\":null,\"showICPage\":null,\"isSmartLocator\":null,\"triggerPricingValidation\":null,\"barCodeIds\":[],\"isGemini\":null,\"isTradeInSelected\":null,\"expressCheckout\":null,\"replaceDevice\":null,\"amRole\":\"accountManager\",\"cradleFlowJourney\":null,\"activateSwitchFlow\":null,\"adobeId\":null,\"referralVendorId\":null,\"ecpdToken\":null,\"rylEcpdUrl\":null,\"referralSaleRepId\":null,\"zipCode\":null,\"disableMyLink\":null,\"authorizedUser\":null,\"cartCreatorSalesRepId\":null,\"fiveGMUCEligible\":null,\"customerConsent\":null},\"data\":{\"recommDevId\":null,\"recommSkuId\":null,\"rtm\":null,\"lines\":[{\"preBackOrderDate\":null,\"preBackOrderDisplayType\":null,\"rebateUpdate\":null,\"instantcredit\":null,\"mldTrunkMtn\":null,\"rtdOfferId\":null,\"restricted\":null,\"restrictedProductType\":null,\"selectedSedOfferId\":null,\"selectedSpoId\":null,\"reasonCode\":null,\"lineActivityType\":null,\"currentPlanType\":null,\"barCodeId\":null,\"inEligibleReason\":null,\"sellerPrice\":null,\"nickName\":null,\"purchasePath\":\"AccountGrowth\",\"donorMtn\":null,\"selectedPromoType\":\"NOPROMO\",\"selectedPromoId\":\"\",\"giftBox\":null,\"idu\":null,\"eupNoPromoFlow\":false,\"accountOwner\":null,\"mtn\":\"5126808210\",\"trialSelected\":null, \"rtdOfferId\":\"345\",\"restricted\":\"Y\",\"subscriptionSelected\":null,\"trialAllowance\":null,\"trialValidityPeriod\":null,\"device\":{\"cartItemType\":null,\"quantityOnHand\":null,\"upgradeReasonCode\":null,\"warningMessage\":null,\"connectedCarMobile\":null,\"connectedCarColor\":null,\"category\":\"Smartphones\",\"giftbox\":null,\"connectedCarDetails\":null,\"refundType\":null,\"id\":\"MLAR3LL/A\",\"dppMonths\":36,\"contractTerm\":\"VERIZON_EDGE\",\"qty\":1,\"fiveGToFourGDownGrade\":null,\"productId\":\"dev16720001\",\"iconicPhone\":true,\"preconfigure\":\"false\",\"token\":null},\"sim\":{\"id\":\"EMBD4GSIM-N\",\"imei2\":null},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"isEdgeBuyOut\":true,\"triggerPricingValidation\":null,\"tabletJetPackDiscountIncluded\":null,\"fiveGUpSell\":null,\"is5GBoltEligible\":null,\"devicePlanCompatible\":null,\"activateLater\":null,\"setUpLater\":null,\"selectedEUPDeviceForBYOD\":null,\"promoRejectionIndicator\":true,\"unpairDevice\":null,\"tradeInInfo\":null,\"editSim\":null,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false}],\"mtnSOIRecommendation\":null,\"totalDeviceDollar\":null,\"selectedMtn\":null},\"channelId\":\"VZW-DOTCOM\"}";
		AddDeviceUIRequest request = mapper.readValue(sampleUIRequestString,AddDeviceUIRequest.class);
		request.getCartInfo().setIntendType("NSEBYOD");
		request.getData().getLines().get(0).getDevice().setByodESimPhone(Boolean.TRUE);
		AddDevicePEGARequest pegareq = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(),request,null,true,true, true, getFFlag());
		StepVerifier.create(Mono.just(pegareq))
				.assertNext(req -> Assert.assertNotNull(pegareq.getServiceBody().getServiceRequest().getContext().getCartInfo()))
				.expectComplete().verify();
	}

	@Test
	public void formatAddDeviceRequestWithNotAccountgrowthIntentTest() throws IOException{
		String sampleUIRequestString = "{\"validateCartRequest\":null,\"preConfigured\":null,\"externalId\":null,\"vzId\":null,\"path\":null,\"cartInfo\":{\"editDeviceConfiguratorClick\":null,\"editPlanClick\":null,\"specialItemType\":null,\"salesRepId\":null,\"flowType\":null,\"rpsIntent\":null,\"sessionId\":null,\"customerType\":null,\"accountType\":null,\"globalId\":null,\"bbpIntent\":null,\"clientAppName\":\"VZW-ECOM\",\"cartId\":\"15eccfe3-574e-402a-91b4-11c669769d2b\",\"caseId\":\"SOP-7676963-C01\",\"accountNumber\":\"0219838656-00001\",\"cartCreator\":\"5126807507\",\"processingMTN\":\"5126808210\",\"buyOutFlag\":\"Y\",\"buyOutSelected\":\"Y\",\"edgeUpSelected\":\"N\",\"processStep\":\"DPPSummary\",\"intendType\":\"EUP\",\"isQuoteCart\":null,\"processAction\":\"addBuyoutAmtAndDevice\",\"mtnFlow\":\"G\",\"fetchDataFromRedis\":null,\"editDevice\":null,\"showICPage\":null,\"isSmartLocator\":null,\"triggerPricingValidation\":null,\"barCodeIds\":[],\"isGemini\":null,\"isTradeInSelected\":null,\"expressCheckout\":null,\"replaceDevice\":null,\"amRole\":\"accountManager\",\"cradleFlowJourney\":null,\"activateSwitchFlow\":null,\"adobeId\":null,\"referralVendorId\":null,\"ecpdToken\":null,\"rylEcpdUrl\":null,\"referralSaleRepId\":null,\"zipCode\":null,\"disableMyLink\":null,\"authorizedUser\":null,\"cartCreatorSalesRepId\":null,\"fiveGMUCEligible\":null,\"customerConsent\":null},\"data\":{\"recommDevId\":null,\"recommSkuId\":null,\"rtm\":null,\"lines\":[{\"preBackOrderDate\":null,\"preBackOrderDisplayType\":null,\"rebateUpdate\":null,\"instantcredit\":null,\"mldTrunkMtn\":null,\"rtdOfferId\":null,\"restricted\":null,\"restrictedProductType\":null,\"selectedSedOfferId\":null,\"selectedSpoId\":null,\"reasonCode\":null,\"lineActivityType\":null,\"currentPlanType\":null,\"barCodeId\":null,\"inEligibleReason\":null,\"sellerPrice\":null,\"nickName\":null,\"purchasePath\":\"EUP\",\"donorMtn\":null,\"selectedPromoType\":\"NOPROMO\",\"selectedPromoId\":\"\",\"giftBox\":null,\"idu\":null,\"eupNoPromoFlow\":false,\"accountOwner\":null,\"mtn\":\"5126808210\",\"trialSelected\":null, \"rtdOfferId\":\"345\",\"restricted\":\"Y\",\"subscriptionSelected\":null,\"trialAllowance\":null,\"trialValidityPeriod\":null,\"device\":{\"cartItemType\":null,\"quantityOnHand\":null,\"upgradeReasonCode\":null,\"warningMessage\":null,\"connectedCarMobile\":null,\"connectedCarColor\":null,\"category\":\"Smartphones\",\"giftbox\":null,\"connectedCarDetails\":null,\"refundType\":null,\"id\":\"MLAR3LL/A\",\"dppMonths\":36,\"contractTerm\":\"VERIZON_EDGE\",\"qty\":1,\"fiveGToFourGDownGrade\":null,\"productId\":\"dev16720001\",\"iconicPhone\":true,\"preconfigure\":\"false\",\"token\":null},\"sim\":{\"id\":\"EMBD4GSIM-N\",\"imei2\":null},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"isEdgeBuyOut\":true,\"triggerPricingValidation\":null,\"tabletJetPackDiscountIncluded\":null,\"fiveGUpSell\":null,\"is5GBoltEligible\":null,\"devicePlanCompatible\":null,\"activateLater\":null,\"setUpLater\":null,\"selectedEUPDeviceForBYOD\":null,\"promoRejectionIndicator\":true,\"unpairDevice\":null,\"tradeInInfo\":null,\"editSim\":null,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false}],\"mtnSOIRecommendation\":null,\"totalDeviceDollar\":null,\"selectedMtn\":null},\"channelId\":\"VZW-DOTCOM\"}";
		AddDeviceUIRequest request = mapper.readValue(sampleUIRequestString,AddDeviceUIRequest.class);
		AddDevicePEGARequest pegareq = new AddDevicePEGARequest();
		CartPegaRequestUtil4.formatAddDeviceRequest(pegareq,request,null,true,false, false, getFFlag());
		StepVerifier.create(Mono.just(pegareq))
				.assertNext(req -> Assert.assertNotNull(pegareq.getServiceBody().getServiceRequest().getContext().getCartInfo()))
				.expectComplete().verify();
	}

	@Test
	public void formatAddDeviceRequestWithAccountgrowthSelectedSPOIdTest() throws IOException{
		String sampleUIRequestString = "{\"validateCartRequest\":null,\"preConfigured\":null,\"externalId\":null,\"vzId\":null,\"path\":null,\"cartInfo\":{\"editDeviceConfiguratorClick\":null,\"editPlanClick\":null,\"specialItemType\":null,\"salesRepId\":null,\"flowType\":null,\"rpsIntent\":null,\"sessionId\":null,\"customerType\":null,\"accountType\":null,\"globalId\":null,\"bbpIntent\":null,\"clientAppName\":\"VZW-ECOM\",\"cartId\":\"15eccfe3-574e-402a-91b4-11c669769d2b\",\"caseId\":\"SOP-7676963-C01\",\"accountNumber\":\"0219838656-00001\",\"cartCreator\":\"5126807507\",\"processingMTN\":\"5126808210\",\"buyOutFlag\":\"Y\",\"buyOutSelected\":\"Y\",\"edgeUpSelected\":\"N\",\"processStep\":\"DPPSummary\",\"intendType\":\"EUP\",\"isQuoteCart\":null,\"processAction\":\"addBuyoutAmtAndDevice\",\"mtnFlow\":\"G\",\"fetchDataFromRedis\":null,\"editDevice\":null,\"showICPage\":null,\"isSmartLocator\":null,\"triggerPricingValidation\":null,\"barCodeIds\":[],\"isGemini\":null,\"isTradeInSelected\":null,\"expressCheckout\":null,\"replaceDevice\":null,\"amRole\":\"accountManager\",\"cradleFlowJourney\":null,\"activateSwitchFlow\":null,\"adobeId\":null,\"referralVendorId\":null,\"ecpdToken\":null,\"rylEcpdUrl\":null,\"referralSaleRepId\":null,\"zipCode\":null,\"disableMyLink\":null,\"authorizedUser\":null,\"cartCreatorSalesRepId\":null,\"fiveGMUCEligible\":null,\"customerConsent\":null},\"data\":{\"recommDevId\":null,\"recommSkuId\":null,\"rtm\":null,\"lines\":[{\"preBackOrderDate\":null,\"preBackOrderDisplayType\":null,\"rebateUpdate\":null,\"instantcredit\":null,\"mldTrunkMtn\":null,\"rtdOfferId\":null,\"restricted\":null,\"restrictedProductType\":null,\"selectedSedOfferId\":null,\"selectedSpoId\":1710,\"reasonCode\":null,\"lineActivityType\":null,\"currentPlanType\":null,\"barCodeId\":null,\"inEligibleReason\":null,\"sellerPrice\":null,\"nickName\":null,\"purchasePath\":\"AccountGrowth\",\"donorMtn\":null,\"selectedPromoType\":\"NOPROMO\",\"selectedPromoId\":\"\",\"giftBox\":null,\"idu\":null,\"eupNoPromoFlow\":false,\"accountOwner\":null,\"mtn\":\"5126808210\",\"trialSelected\":null, \"rtdOfferId\":\"345\",\"restricted\":\"Y\",\"subscriptionSelected\":null,\"trialAllowance\":null,\"trialValidityPeriod\":null,\"device\":{\"cartItemType\":null,\"quantityOnHand\":null,\"upgradeReasonCode\":null,\"warningMessage\":null,\"connectedCarMobile\":null,\"connectedCarColor\":null,\"category\":\"Smartphones\",\"giftbox\":null,\"connectedCarDetails\":null,\"refundType\":null,\"id\":\"MLAR3LL/A\",\"dppMonths\":36,\"contractTerm\":\"VERIZON_EDGE\",\"qty\":1,\"fiveGToFourGDownGrade\":null,\"productId\":\"dev16720002\",\"iconicPhone\":true,\"preconfigure\":\"false\",\"token\":null},\"sim\":{\"id\":\"EMBD4GSIM-N\",\"imei2\":null},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"isEdgeBuyOut\":true,\"triggerPricingValidation\":null,\"tabletJetPackDiscountIncluded\":null,\"fiveGUpSell\":null,\"is5GBoltEligible\":null,\"devicePlanCompatible\":null,\"activateLater\":null,\"setUpLater\":null,\"selectedEUPDeviceForBYOD\":null,\"promoRejectionIndicator\":true,\"unpairDevice\":null,\"tradeInInfo\":null,\"editSim\":null,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false}],\"mtnSOIRecommendation\":null,\"totalDeviceDollar\":null,\"selectedMtn\":null},\"channelId\":\"VZW-DOTCOM\"}";
		AddDeviceUIRequest request = mapper.readValue(sampleUIRequestString,AddDeviceUIRequest.class);
		AddDevicePEGARequest pegareq = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(),request,null,true,false, false, getFFlag());
		StepVerifier.create(Mono.just(pegareq))
				.assertNext(req -> Assert.assertNotNull(pegareq.getServiceBody().getServiceRequest().getContext().getCartInfo()))
				.expectComplete().verify();
	}

	@Test
	public void formatAddDeviceRequestPurchasePathEmty() throws IOException{
		String sampleUIRequestString = "{\"validateCartRequest\":null,\"preConfigured\":null,\"externalId\":null,\"vzId\":null,\"path\":null,\"cartInfo\":{\"editDeviceConfiguratorClick\":null,\"editPlanClick\":null,\"specialItemType\":null,\"salesRepId\":null,\"flowType\":null,\"rpsIntent\":null,\"sessionId\":null,\"customerType\":null,\"accountType\":null,\"globalId\":null,\"bbpIntent\":null,\"clientAppName\":\"VZW-ECOM\",\"cartId\":\"15eccfe3-574e-402a-91b4-11c669769d2b\",\"caseId\":\"SOP-7676963-C01\",\"accountNumber\":\"0219838656-00001\",\"cartCreator\":\"5126807507\",\"processingMTN\":\"5126808210\",\"buyOutFlag\":\"Y\",\"buyOutSelected\":\"Y\",\"edgeUpSelected\":\"N\",\"processStep\":\"DPPSummary\",\"intendType\":\"EUP\",\"isQuoteCart\":null,\"processAction\":\"addBuyoutAmtAndDevice\",\"mtnFlow\":\"G\",\"fetchDataFromRedis\":null,\"editDevice\":null,\"showICPage\":null,\"isSmartLocator\":null,\"triggerPricingValidation\":null,\"barCodeIds\":[],\"isGemini\":null,\"isTradeInSelected\":null,\"expressCheckout\":null,\"replaceDevice\":null,\"amRole\":\"accountManager\",\"cradleFlowJourney\":null,\"activateSwitchFlow\":null,\"adobeId\":null,\"referralVendorId\":null,\"ecpdToken\":null,\"rylEcpdUrl\":null,\"referralSaleRepId\":null,\"zipCode\":null,\"disableMyLink\":null,\"authorizedUser\":null,\"cartCreatorSalesRepId\":null,\"fiveGMUCEligible\":null,\"customerConsent\":null},\"data\":{\"recommDevId\":null,\"recommSkuId\":null,\"rtm\":null,\"lines\":[{\"preBackOrderDate\":null,\"preBackOrderDisplayType\":null,\"rebateUpdate\":null,\"instantcredit\":null,\"mldTrunkMtn\":null,\"rtdOfferId\":null,\"restricted\":null,\"restrictedProductType\":null,\"selectedSedOfferId\":null,\"selectedSpoId\":null,\"reasonCode\":null,\"lineActivityType\":null,\"currentPlanType\":null,\"barCodeId\":null,\"inEligibleReason\":null,\"sellerPrice\":null,\"nickName\":null,\"purchasePath\":\"\",\"donorMtn\":null,\"selectedPromoType\":\"NOPROMO\",\"selectedPromoId\":\"\",\"giftBox\":null,\"idu\":null,\"eupNoPromoFlow\":false,\"accountOwner\":null,\"mtn\":\"5126808210\",\"trialSelected\":null, \"rtdOfferId\":\"345\",\"restricted\":\"Y\",\"subscriptionSelected\":null,\"trialAllowance\":null,\"trialValidityPeriod\":null,\"device\":{\"cartItemType\":null,\"quantityOnHand\":null,\"upgradeReasonCode\":null,\"warningMessage\":null,\"connectedCarMobile\":null,\"connectedCarColor\":null,\"category\":\"Smartphones\",\"giftbox\":null,\"connectedCarDetails\":null,\"refundType\":null,\"id\":\"MLAR3LL/A\",\"dppMonths\":36,\"contractTerm\":\"VERIZON_EDGE\",\"qty\":1,\"fiveGToFourGDownGrade\":null,\"productId\":\"dev16720001\",\"iconicPhone\":true,\"preconfigure\":\"false\",\"token\":null},\"sim\":{\"id\":\"EMBD4GSIM-N\",\"imei2\":null},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"isEdgeBuyOut\":true,\"triggerPricingValidation\":null,\"tabletJetPackDiscountIncluded\":null,\"fiveGUpSell\":null,\"is5GBoltEligible\":null,\"devicePlanCompatible\":null,\"activateLater\":null,\"setUpLater\":null,\"selectedEUPDeviceForBYOD\":null,\"promoRejectionIndicator\":true,\"unpairDevice\":null,\"tradeInInfo\":null,\"editSim\":null,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false}],\"mtnSOIRecommendation\":null,\"totalDeviceDollar\":null,\"selectedMtn\":null},\"channelId\":\"VZW-DOTCOM\"}";
		AddDeviceUIRequest request = mapper.readValue(sampleUIRequestString,AddDeviceUIRequest.class);
		AddDevicePEGARequest pegareq = new AddDevicePEGARequest();
		CartPegaRequestUtil4.formatAddDeviceRequest(pegareq,request,null,true,false, false, getFFlag());
		StepVerifier.create(Mono.just(pegareq))
				.assertNext(req -> Assert.assertNotNull(pegareq.getServiceBody().getServiceRequest().getContext().getCartInfo()))
				.expectComplete().verify();
	}

	@Test
	public void addContextInfoTest() {
		CartServiceContextInfo contextInfo = new CartServiceContextInfo();
		String operationType = "removeLines";
		String clientAppName = "VZW-DOTCOM-BBP";

		CartServiceContextInfo response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("removeItem", response.getProcessAction());

		operationType = "removeAccessory";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("removeAccessory", response.getProcessAction());

		operationType = "addFeatures";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("addFeatures", response.getProcessAction());

		operationType = "mayBeLater";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("mayBeLater", response.getProcessAction());

		operationType = "removeOffer";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("removeOffer", response.getProcessAction());

		operationType = "addSellerPrice";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("addSellerPrice", response.getProcessAction());

		operationType = "removeFeature";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("removeFeature", response.getProcessAction());

		operationType = "addBuyOutAmt";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("addBuyOutAmt", response.getProcessAction());

		operationType = "addEdgeUpAmt";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("addEdgeUpAmt", response.getProcessAction());

		operationType = "addDownPayment";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("addDownPayment", response.getProcessAction());

		operationType = "addDownPayment";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("addDownPayment", response.getProcessAction());

		operationType = "pastDue";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("", response.getProcessAction());

		operationType = "createLine";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("createLine", response.getProcessAction());

		operationType = "addNumberShare";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("addNumberShare", response.getProcessAction());

		operationType = "addServiceAddress";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("updateServiceAddress", response.getProcessAction());

		operationType = "addE911Address";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("addE911Address", response.getProcessAction());

		operationType = "addBarCodeOffer";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("addBarCodeOffer", response.getProcessAction());

		operationType = "updateDeviceSimId";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("updateDeviceSimId", response.getProcessAction());

		operationType = "assignMtn";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("AssignNumbers", response.getProcessAction());

		operationType = "deassignMtn";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("De-assignNumbers", response.getProcessAction());

		operationType = "FIVEGBULK";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("FIVEGBULK", response.getProcessAction());

		operationType = "REVOKEREBATES";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("revokeRebates", response.getProcessAction());

		operationType = "PortInLater";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("PortInLater", response.getProcessAction());

		operationType = "voidOrder";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("CancelISPU-LocalOrder", response.getProcessAction());


	}
		@Test
	public void addContextInfoTest1() {
		CartServiceContextInfo contextInfo = new CartServiceContextInfo();
		String operationType = "removeLines";
		String clientAppName = "VZW-DOTCOM-BBP";
		
		CartServiceContextInfo response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("removeItem", response.getProcessAction());

		operationType = "ispuToDFill";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("ispuToDFill", response.getProcessAction());
		
		operationType = "Update-ManualPairing";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("Update-ManualPairing", response.getProcessAction());
		
		operationType = "Update-SalesRepLocation";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("Update-SalesRepLocation", response.getProcessAction());
		
		operationType = "splitExceededAmount";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("splitExceededAmount", response.getProcessAction());
		
		operationType = "Cancel";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("Cancel", response.getProcessAction());
		
		operationType = "addInstantCreditDownPayment";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("addAllocationAmount", response.getProcessAction());
		
		operationType = "saveCart";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("saveCart", response.getProcessAction());
		
		operationType = "saveCartAndQuotes";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("saveCartAndQuotes", response.getProcessAction());
		
		operationType = "ACTIVATELATER";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("SetUpLater", response.getProcessAction());
		
		operationType = "addDeviceSim";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("addDeviceSim", response.getProcessAction());
		
		operationType = "cancelEdgeUp";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("cancelEdgeUp", response.getProcessAction());
		
		operationType = "addNickName";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("addNickName", response.getProcessAction());
		
		operationType = "saveForLater";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("saveForLater", response.getProcessAction());
		
		operationType = "deleteSaveForLater";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("deleteSaveForLater", response.getProcessAction());
		
		operationType = "removeSaveForLater";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("removeSaveForLater", response.getProcessAction());
		
		operationType = "EffectiveDateUpdate";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("EffectiveDateUpdate", response.getProcessAction());
		
		operationType = "CLEARCART";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("Cancel", response.getProcessAction());

		operationType = "addDeviceWithTradeIn";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, clientAppName);
		Assert.assertEquals("addDeviceWithTradeIn", response.getProcessAction());
		
		operationType = "CLEARCART";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, "");
		Assert.assertEquals("ClearAll", response.getProcessAction());

		operationType = "addPlanAndFeatures";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, "");
		Assert.assertEquals("addPlanAndFeatures", response.getProcessAction());
		
		operationType = "";
		response = CartPegaRequestUtil.addContextInfo(contextInfo, operationType, "");
		Assert.assertEquals("", response.getProcessAction());
	}
	
	@Test
	public void formatSaveCartRequest() throws JsonMappingException, JsonProcessingException {
		String uiRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"accountNumber\": \"12345\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"PromoHub\",\"intendType\": \"NSE\",\"mtnFlow\": \"mtnFlow\",\"scheduleOrder\": true,\"cartId\": \"cartId\",\"saveCartEmailId\": \"saveCartEmailId@verizon.com\",\"storeName\": \"store\",\"loggedInUser\": \"loggedInUser\",\"repId\": \"repId\",\"processAction\": \"processAction\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"creditAppNum\",\"emailId\": \"sanchit.goyal@verizon.com\",\"expressCheckout\": true,\"cartSavedByCustomer\": true,\"isDirectApply\": true},\"data\": {\"email\": \"sanchit.goyal@verizon.com\",\"customerName\": \"Name\",\"createLead\": true,\"updateLead\": {\"leadOwner\": \"leadOwner\",\"leadOwnerName\": \"ownerName\",\"isMobileNumber\": true,\"cartDetails\": [],\"addressInfo\": {\"state\": \"state\",\"city\": \"city\",\"addressLine1\": \"addressLine1\",\"addressLine2\": \"addressLine2\"},\"eCode\": \"eCode\"},\"quoteId\": \"quoteId\",\"zipCode\": \"33097\",\"compareQuotePdfEnabled\": true,\"quoteLowerBillEnabled\": true,\"viewQrCode\": true},\"safeTechSessionId\": \"safeTechSessionId\",\"globalId\": \"globalId\",\"enforceData\": null}";
		SaveCartPEGARequest pegaRequest = new SaveCartPEGARequest();
		SaveCartUIRequest uiRequest = mapper.readValue(uiRequestString, SaveCartUIRequest.class);
		SaveCartPEGARequest response = CartPegaRequestUtil.formatSaveCartRequest(pegaRequest, uiRequest);
		Assert.assertTrue(response.getServiceBody().getServiceRequest().getContext().getCartInfo().getCartSavedByCustomer());
	}

	@Test
	public void formatSaveCartRequestWithHeaders() throws JsonMappingException, JsonProcessingException {
		String uiRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"accountNumber\": \"12345\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"PromoHub\",\"intendType\": \"NSE\",\"mtnFlow\": \"mtnFlow\",\"scheduleOrder\": true,\"cartId\": \"cartId\",\"saveCartEmailId\": \"saveCartEmailId@verizon.com\",\"storeName\": \"store\",\"loggedInUser\": \"loggedInUser\",\"repId\": \"repId\",\"processAction\": \"processAction\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"creditAppNum\",\"emailId\": \"sanchit.goyal@verizon.com\",\"expressCheckout\": true,\"cartSavedByCustomer\": true,\"isDirectApply\": true},\"data\": {\"email\": \"sanchit.goyal@verizon.com\",\"customerName\": \"Name\",\"createLead\": true,\"updateLead\": {\"leadOwner\": \"leadOwner\",\"leadOwnerName\": \"ownerName\",\"isMobileNumber\": true,\"cartDetails\": [],\"addressInfo\": {\"state\": \"state\",\"city\": \"city\",\"addressLine1\": \"addressLine1\",\"addressLine2\": \"addressLine2\"},\"eCode\": \"eCode\"},\"quoteId\": \"quoteId\",\"zipCode\": \"33097\",\"compareQuotePdfEnabled\": true,\"quoteLowerBillEnabled\": true,\"viewQrCode\": true},\"safeTechSessionId\": \"safeTechSessionId\",\"globalId\": \"globalId\",\"enforceData\": null}";
		SaveCartPEGARequest pegaRequest = new SaveCartPEGARequest();
		SaveCartUIRequest uiRequest = mapper.readValue(uiRequestString, SaveCartUIRequest.class);
		URI url = URI.create("http://localhost/nse/saveCart");
		MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url)
				.header("channelId", "VZW-DOTCOM")
				.header("Accept", "Accept")
				.header("Accept-Encoding", "Accept-Encoding")
				.header("Accept-Language", "Accept-Language")
				.header("Connection", "Connection")
				.header("Host", "Host")
				.header("Referer", "Referer")
				.build();
		uiRequest.setHttpRequest(httpRequest);
		EnforceData data = new EnforceData();
		data.setCookieStatus("cookieStatus");
		data.setTouchSupport("touchSupport");
		uiRequest.setEnforceData(data);
		SaveCartPEGARequest response = CartPegaRequestUtil.formatSaveCartRequest(pegaRequest, uiRequest);
		Assert.assertTrue(response.getServiceBody().getServiceRequest().getContext().getCartInfo().getCartSavedByCustomer());
	}

	@Test
	public void formatSaveCartRequest2() throws JsonMappingException, JsonProcessingException {
		String uiRequestString = "{\"channelId\": \"OMNI-CARE\",\"cartInfo\": {\"accountNumber\": \"12345\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"\",\"intendType\": \"NSEBYOD\",\"mtnFlow\": \"\",\"scheduleOrder\": null,\"cartId\": \"cartId\",\"saveCartEmailId\": null,\"storeName\": \"\",\"loggedInUser\": \"loggedInUser\",\"repId\": \"repId\",\"processAction\": \"\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"creditAppNum\",\"emailId\": \"\",\"expressCheckout\": false,\"cartSavedByCustomer\": false,\"isDirectApply\": null,\"quoteId\": \"0001\"},\"data\": {\"email\": \"\",\"customerName\": \"\",\"createLead\": true,\"updateLead\": {\"leadOwner\": \"\",\"leadOwnerName\": \"\",\"isMobileNumber\": null,\"cartDetails\": null,\"addressInfo\": {\"state\": \"\",\"city\": \"\",\"addressLine1\": \"\",\"addressLine2\": \"\"},\"eCode\": null},\"quoteId\": \"\",\"zipCode\": \"\",\"compareQuotePdfEnabled\": null,\"quoteLowerBillEnabled\": null,\"viewQrCode\": null},\"safeTechSessionId\": \"\",\"globalId\": \"globalId\",\"enforceData\": null}";
		SaveCartPEGARequest pegaRequest = new SaveCartPEGARequest();
		SaveCartUIRequest uiRequest = mapper.readValue(uiRequestString, SaveCartUIRequest.class);
		SaveCartPEGARequest response = CartPegaRequestUtil.formatSaveCartRequest(pegaRequest, uiRequest);
		Assert.assertFalse(response.getServiceBody().getServiceRequest().getContext().getCartInfo().getCartSavedByCustomer());
	}
	
	@Test
	public void formatSaveCartRequest3() throws JsonMappingException, JsonProcessingException {
		String uiRequestString = "{\"channelId\": \"OMNI-TELESALES\",\"cartInfo\": {\"accountNumber\": \"12345\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"\",\"intendType\": \"\",\"mtnFlow\": \"\",\"scheduleOrder\": null,\"cartId\": \"cartId\",\"saveCartEmailId\": null,\"storeName\": \"\",\"loggedInUser\": \"loggedInUser\",\"repId\": \"repId\",\"processAction\": \"\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"\",\"emailId\": \"\",\"expressCheckout\": null,\"cartSavedByCustomer\": null,\"isDirectApply\": null},\"data\": null,\"safeTechSessionId\": \"\",\"globalId\": \"globalId\",\"enforceData\": null}";
		SaveCartPEGARequest pegaRequest = new SaveCartPEGARequest();
		SaveCartUIRequest uiRequest = mapper.readValue(uiRequestString, SaveCartUIRequest.class);
		SaveCartPEGARequest response = CartPegaRequestUtil.formatSaveCartRequest(pegaRequest, uiRequest);
		Assert.assertNotNull(response);
	}
	
	@Test
	public void formatSaveCartRequest4() throws JsonMappingException, JsonProcessingException {
		String uiRequestString = "{\"channelId\": \"CHAT-STORE\",\"cartInfo\": {\"accountNumber\": \"12345\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"OrderReview-Shipping\",\"intendType\": \"NSE_5G\",\"mtnFlow\": \"\",\"scheduleOrder\": null,\"cartId\": \"cartId\",\"saveCartEmailId\": null,\"storeName\": \"\",\"loggedInUser\": \"loggedInUser\",\"repId\": \"repId\",\"processAction\": \"\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"\",\"emailId\": \"\",\"expressCheckout\": null,\"cartSavedByCustomer\": null,\"isDirectApply\": null},\"data\": null,\"safeTechSessionId\": \"\",\"globalId\": \"globalId\",\"enforceData\": null}";
		SaveCartPEGARequest pegaRequest = new SaveCartPEGARequest();
		SaveCartUIRequest uiRequest = mapper.readValue(uiRequestString, SaveCartUIRequest.class);
		SaveCartPEGARequest response = CartPegaRequestUtil.formatSaveCartRequest(pegaRequest, uiRequest);
		Assert.assertNotNull(response);
	}
	
	@Test
	public void formatSaveCartRequest5() throws JsonMappingException, JsonProcessingException {
		String uiRequestString = "{\"channelId\": \"\",\"cartInfo\": {\"accountNumber\": \"12345\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"PromoHub\",\"intendType\": \"REX\",\"mtnFlow\": \"mtnFlow\",\"scheduleOrder\": true,\"cartId\": \"cartId\",\"saveCartEmailId\": \"saveCartEmailId@verizon.com\",\"storeName\": \"store\",\"loggedInUser\": \"\",\"repId\": \"repId\",\"processAction\": \"processAction\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"creditAppNum\",\"emailId\": \"sanchit.goyal@verizon.com\",\"expressCheckout\": true,\"cartSavedByCustomer\": true,\"isDirectApply\": true},\"data\": {\"email\": \"sanchit.goyal@verizon.com\",\"customerName\": \"Name\",\"createLead\": false,\"updateLead\": null,\"quoteId\": \"quoteId\",\"zipCode\": \"33097\",\"compareQuotePdfEnabled\": true,\"quoteLowerBillEnabled\": true,\"viewQrCode\": true},\"safeTechSessionId\": \"safeTechSessionId\",\"globalId\": \"globalId\",\"enforceData\": null}";
		SaveCartPEGARequest pegaRequest = new SaveCartPEGARequest();
		SaveCartUIRequest uiRequest = mapper.readValue(uiRequestString, SaveCartUIRequest.class);
		SaveCartPEGARequest response = CartPegaRequestUtil.formatSaveCartRequest(pegaRequest, uiRequest);
		Assert.assertNotNull(response);
	}
	
	@Test
	public void formatSaveCartRequest6() throws JsonMappingException, JsonProcessingException {
		String uiRequestString = "{\"channelId\": \"\",\"cartInfo\": {\"accountNumber\": \"12345\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"PromoHub\",\"intendType\": \"NSEBYOD\",\"mtnFlow\": \"mtnFlow\",\"scheduleOrder\": true,\"cartId\": \"cartId\",\"saveCartEmailId\": \"saveCartEmailId@verizon.com\",\"storeName\": \"store\",\"loggedInUser\": \"loggedInUser\",\"repId\": \"\",\"processAction\": \"processAction\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"creditAppNum\",\"emailId\": \"sanchit.goyal@verizon.com\",\"expressCheckout\": true,\"cartSavedByCustomer\": true,\"isDirectApply\": true},\"data\": {\"email\": \"sanchit.goyal@verizon.com\",\"customerName\": \"Name\",\"createLead\": true,\"updateLead\": {\"leadOwner\": \"leadOwner\",\"leadOwnerName\": \"\",\"isMobileNumber\": null,\"cartDetails\": null,\"addressInfo\": null,\"eCode\": \"eCode\"},\"quoteId\": \"quoteId\",\"zipCode\": \"33097\",\"compareQuotePdfEnabled\": true,\"quoteLowerBillEnabled\": true,\"viewQrCode\": true},\"safeTechSessionId\": \"safeTechSessionId\",\"globalId\": \"globalId\",\"enforceData\": null}";
		SaveCartPEGARequest pegaRequest = new SaveCartPEGARequest();
		SaveCartUIRequest uiRequest = mapper.readValue(uiRequestString, SaveCartUIRequest.class);
		SaveCartPEGARequest response = CartPegaRequestUtil.formatSaveCartRequest(pegaRequest, uiRequest);
		Assert.assertNotNull(response);
	}
	
	@Test
	public void formatUpdateBarCodeRequestTest() throws JsonMappingException, JsonProcessingException {
		String uiRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"accountNumber\": \"12345\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"PromoHub\",\"intendType\": \"\",\"mtnFlow\": \"mtnFlow\",\"scheduleOrder\": true,\"cartId\": \"cartId\",\"saveCartEmailId\": \"saveCartEmailId@verizon.com\",\"storeName\": \"store\",\"loggedInUser\": \"loggedInUser\",\"repId\": \"repId\",\"processAction\": \"processAction\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"creditAppNum\",\"emailId\": \"sanchit.goyal@verizon.com\",\"expressCheckout\": true,\"cartSavedByCustomer\": true,\"isDirectApply\": true},\"data\": {\"email\": \"sanchit.goyal@verizon.com\",\"customerName\": \"Name\",\"createLead\": true,\"updateLead\": {\"leadOwner\": \"leadOwner\",\"leadOwnerName\": \"ownerName\",\"isMobileNumber\": true,\"cartDetails\": [],\"addressInfo\": {\"state\": \"state\",\"city\": \"city\",\"addressLine1\": \"addressLine1\",\"addressLine2\": \"addressLine2\"},\"eCode\": \"eCode\"},\"quoteId\": \"quoteId\",\"zipCode\": \"33097\",\"compareQuotePdfEnabled\": true,\"quoteLowerBillEnabled\": true,\"viewQrCode\": true},\"safeTechSessionId\": \"safeTechSessionId\",\"globalId\": \"globalId\",\"enforceData\": null}";
		UpdateBarCodePEGARequest pegaRequest = new UpdateBarCodePEGARequest();
		UpdateBarcodeUIRequest uiRequest = mapper.readValue(uiRequestString, UpdateBarcodeUIRequest.class);
		UpdateBarCodePEGARequest response = CartPegaRequestUtil.formatUpdateBarCodeRequest(pegaRequest, uiRequest, "");
		Assert.assertNotNull(response);
	}
	
	@Test
	public void formatUpdateBarCodeRequestTest2() throws JsonMappingException, JsonProcessingException {
		String uiRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"accountNumber\": \"12345\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"PromoHub\",\"intendType\": \"REX\",\"mtnFlow\": \"mtnFlow\",\"scheduleOrder\": true,\"cartId\": \"cartId\",\"saveCartEmailId\": \"saveCartEmailId@verizon.com\",\"storeName\": \"store\",\"loggedInUser\": \"loggedInUser\",\"repId\": \"repId\",\"processAction\": \"processAction\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"creditAppNum\",\"emailId\": \"sanchit.goyal@verizon.com\",\"expressCheckout\": true,\"cartSavedByCustomer\": true,\"isDirectApply\": true},\"data\": {\"email\": \"sanchit.goyal@verizon.com\",\"customerName\": \"Name\",\"createLead\": true,\"updateLead\": {\"leadOwner\": \"leadOwner\",\"leadOwnerName\": \"ownerName\",\"isMobileNumber\": true,\"cartDetails\": [],\"addressInfo\": {\"state\": \"state\",\"city\": \"city\",\"addressLine1\": \"addressLine1\",\"addressLine2\": \"addressLine2\"},\"eCode\": \"eCode\"},\"quoteId\": \"quoteId\",\"zipCode\": \"33097\",\"compareQuotePdfEnabled\": true,\"quoteLowerBillEnabled\": true,\"viewQrCode\": true},\"safeTechSessionId\": \"safeTechSessionId\",\"globalId\": \"globalId\",\"enforceData\": null}";
		UpdateBarCodePEGARequest pegaRequest = new UpdateBarCodePEGARequest();
		UpdateBarcodeUIRequest uiRequest = mapper.readValue(uiRequestString, UpdateBarcodeUIRequest.class);
		UpdateBarCodePEGARequest response = CartPegaRequestUtil.formatUpdateBarCodeRequest(pegaRequest, uiRequest, "");
		Assert.assertNotNull(response);
	}
	
	@Test
	public void formatUpdateBarCodeRequestNSEACCTest() throws JsonMappingException, JsonProcessingException {
		String uiRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"accountNumber\": \"12345\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"\",\"intendType\": \"NSEACC\",\"mtnFlow\": \"mtnFlow\",\"cartId\": \"cartId\",\"processAction\": \"processAction\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"creditAppNum\",\"emailId\": \"sanchit.goyal@verizon.com\",\"expressCheckout\": true,\"barCodeIds\": []},\"data\": {\"includeExpiryBarcodeStatus\": \"barcode status\",\"lines\": [{\"mtn\": \"98765432\"}]},\"safeTechSessionId\": \"safeTechSessionId\",\"globalId\": \"globalId\",\"enforceData\": null,\"expressCheckout\": true}";
		UpdateBarCodePEGARequest pegaRequest = new UpdateBarCodePEGARequest();
		UpdateBarcodeUIRequest uiRequest = mapper.readValue(uiRequestString, UpdateBarcodeUIRequest.class);
		UpdateBarCodePEGARequest response = CartPegaRequestUtil.formatUpdateBarCodeRequest(pegaRequest, uiRequest, "throttle");
		Assert.assertEquals("NSEACC", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	
	@Test
	public void formatUpdateBarCodeRequestNSETest() throws JsonMappingException, JsonProcessingException {
		String uiRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"accountNumber\": \"12345\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"\",\"intendType\": \"NSE\",\"mtnFlow\": \"mtnFlow\",\"cartId\": \"cartId\",\"processAction\": \"processAction\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"creditAppNum\",\"emailId\": \"sanchit.goyal@verizon.com\",\"expressCheckout\": true,\"barCodeIds\": []},\"data\": {\"includeExpiryBarcodeStatus\": \"barcode status\",\"lines\": [{\"mtn\": \"\"}]},\"safeTechSessionId\": \"safeTechSessionId\",\"globalId\": \"globalId\",\"enforceData\": null,\"expressCheckout\": true}";
		UpdateBarCodePEGARequest pegaRequest = new UpdateBarCodePEGARequest();
		UpdateBarcodeUIRequest uiRequest = mapper.readValue(uiRequestString, UpdateBarcodeUIRequest.class);
		UpdateBarCodePEGARequest response = CartPegaRequestUtil.formatUpdateBarCodeRequest(pegaRequest, uiRequest, "throttle");
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	
	@Test
	public void formatUpdateBarCodeRequestNSEBYODTest() throws JsonMappingException, JsonProcessingException {
		String uiRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"accountNumber\": \"12345\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"\",\"intendType\": \"NSEBYOD\",\"mtnFlow\": \"mtnFlow\",\"cartId\": \"cartId\",\"processAction\": \"processAction\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"creditAppNum\",\"emailId\": \"sanchit.goyal@verizon.com\",\"expressCheckout\": true,\"barCodeIds\": []},\"data\": {\"includeExpiryBarcodeStatus\": \"barcode status\",\"lines\": [{\"mtn\": null}]},\"safeTechSessionId\": \"safeTechSessionId\",\"globalId\": \"globalId\",\"enforceData\": null,\"expressCheckout\": false}";
		UpdateBarCodePEGARequest pegaRequest = new UpdateBarCodePEGARequest();
		UpdateBarcodeUIRequest uiRequest = mapper.readValue(uiRequestString, UpdateBarcodeUIRequest.class);
		UpdateBarCodePEGARequest response = CartPegaRequestUtil.formatUpdateBarCodeRequest(pegaRequest, uiRequest, "throttle");
		Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	
	@Test
	public void formatUpdateSalesRepAndLocationCodeRequestTest() throws JsonMappingException, JsonProcessingException {
		String uiRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"accountNumber\": \"12345\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"PromoHub\",\"intendType\": \"\",\"mtnFlow\": \"mtnFlow\",\"scheduleOrder\": true,\"cartId\": \"cartId\",\"saveCartEmailId\": \"saveCartEmailId@verizon.com\",\"storeName\": \"store\",\"loggedInUser\": \"loggedInUser\",\"repId\": \"repId\",\"processAction\": \"processAction\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"creditAppNum\",\"emailId\": \"sanchit.goyal@verizon.com\",\"expressCheckout\": true,\"cartSavedByCustomer\": true,\"isDirectApply\": true},\"data\": {\"email\": \"sanchit.goyal@verizon.com\",\"customerName\": \"Name\",\"createLead\": true,\"updateLead\": {\"leadOwner\": \"leadOwner\",\"leadOwnerName\": \"ownerName\",\"isMobileNumber\": true,\"cartDetails\": [],\"addressInfo\": {\"state\": \"state\",\"city\": \"city\",\"addressLine1\": \"addressLine1\",\"addressLine2\": \"addressLine2\"},\"eCode\": \"eCode\"},\"quoteId\": \"quoteId\",\"zipCode\": \"33097\",\"compareQuotePdfEnabled\": true,\"quoteLowerBillEnabled\": true,\"viewQrCode\": true},\"safeTechSessionId\": \"safeTechSessionId\",\"globalId\": \"globalId\",\"enforceData\": null}";
		SalesRepAndLocationCodePEGARequest pegaRequest = new SalesRepAndLocationCodePEGARequest();
		SalesRepAndLocationCodeUIRequest uiRequest = mapper.readValue(uiRequestString, SalesRepAndLocationCodeUIRequest.class);
		SalesRepAndLocationCodePEGARequest response = CartPegaRequestUtil9.formatUpdateSalesRepAndLocationCodeRequest(pegaRequest, uiRequest);
		Assert.assertNotNull(response);
	}
	
	@Test
	public void formatUpdateSalesRepAndLocationCodeRequestNSETest() throws JsonMappingException, JsonProcessingException {
		String uiRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"accountNumber\": \"12345\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"\",\"intendType\": \"NSE\",\"mtnFlow\": \"mtnFlow\",\"scheduleOrder\": true,\"cartId\": \"cartId\",\"processAction\": \"processAction\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"creditAppNum\"},\"data\": {\"orderLocationCode\": \"orderLocationCode\",\"salesRepId\": \"salesRepId\"},\"safeTechSessionId\": \"safeTechSessionId\",\"globalId\": \"globalId\"}";
		SalesRepAndLocationCodePEGARequest pegaRequest = new SalesRepAndLocationCodePEGARequest();
		SalesRepAndLocationCodeUIRequest uiRequest = mapper.readValue(uiRequestString, SalesRepAndLocationCodeUIRequest.class);
		SalesRepAndLocationCodePEGARequest response = CartPegaRequestUtil9.formatUpdateSalesRepAndLocationCodeRequest(pegaRequest, uiRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	
	@Test
	public void formatUpdateSalesRepAndLocationCodeRequestNSEBYODTest() throws JsonMappingException, JsonProcessingException {
		String uiRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"accountNumber\": \"12345\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"\",\"intendType\": \"NSEBYOD\",\"mtnFlow\": \"mtnFlow\",\"scheduleOrder\": true,\"cartId\": \"cartId\",\"processAction\": \"processAction\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"creditAppNum\"},\"data\": {\"orderLocationCode\": \"orderLocationCode\",\"salesRepId\": \"salesRepId\"},\"safeTechSessionId\": \"safeTechSessionId\",\"globalId\": \"globalId\"}";
		SalesRepAndLocationCodePEGARequest pegaRequest = new SalesRepAndLocationCodePEGARequest();
		SalesRepAndLocationCodeUIRequest uiRequest = mapper.readValue(uiRequestString, SalesRepAndLocationCodeUIRequest.class);
		SalesRepAndLocationCodePEGARequest response = CartPegaRequestUtil9.formatUpdateSalesRepAndLocationCodeRequest(pegaRequest, uiRequest);
		Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	
	@Test
	public void formatUpdateEdgeupRequestTest() throws JsonMappingException, JsonProcessingException {
		String uiRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"accountNumber\": \"12345\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"\",\"intendType\": \"\",\"mtnFlow\": \"mtnFlow\",\"scheduleOrder\": true,\"cartId\": \"cartId\",\"processAction\": \"processAction\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"creditAppNum\",\"caseId\": \"caseId\"},\"data\": {\"lines\": [{\"mtn\": \"98765432\",\"edgeup\": {\"deviceId\": \"deviceId\",\"deviceMismatch\": \"deviceMismatch\"}}],\"upgradeReasonCode\": \"upgradeReasonCode\",\"effectiveDate\": \"effectiveDate\"},\"safeTechSessionId\": \"safeTechSessionId\",\"globalId\": \"globalId\"}";
		UpdateEdgeupPEGARequest pegaRequest = new UpdateEdgeupPEGARequest();
		UpdateEdgeupUIRequest uiRequest = mapper.readValue(uiRequestString, UpdateEdgeupUIRequest.class);
		UpdateEdgeupPEGARequest response = CartPegaRequestUtil9.formatUpdateEdgeupRequest(pegaRequest, uiRequest);
		Assert.assertEquals("EUP", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	
	@Test
	public void formatUpdateEdgeupRequestNSETest() throws JsonMappingException, JsonProcessingException {
		String uiRequestString = "{\"channelId\": \"OMNI-CARE\",\"cartInfo\": {\"accountNumber\": \"12345\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"PromoHub\",\"intendType\": \"NSE\",\"mtnFlow\": null,\"scheduleOrder\": true,\"cartId\": \"cartId\",\"processAction\": \"\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"creditAppNum\",\"caseId\": \"caseId\"},\"data\": {\"lines\": [{\"upgradeReasonCode\": \"upgradeReasonCode\",\"mtn\": \"98765432\",\"edgeup\": {\"deviceId\": \"\",\"deviceMismatch\": \"\"}}],\"upgradeReasonCode\": \"\",\"effectiveDate\": \"effectiveDate\",\"recommDevId\": \"recommDevId\",\"recommSkuId\": \"recommSkuId\",\"mtnSOIRecommendation\": true},\"safeTechSessionId\": \"safeTechSessionId\",\"globalId\": \"globalId\"}";
		UpdateEdgeupPEGARequest pegaRequest = new UpdateEdgeupPEGARequest();
		UpdateEdgeupUIRequest uiRequest = mapper.readValue(uiRequestString, UpdateEdgeupUIRequest.class);
		UpdateEdgeupPEGARequest response = CartPegaRequestUtil9.formatUpdateEdgeupRequest(pegaRequest, uiRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	
	@Test
	public void formatRemoveEdgeUpReqTest() throws JsonMappingException, JsonProcessingException {
		String uiRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"accountNumber\": \"12345\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"\",\"intendType\": \"\",\"mtnFlow\": \"mtnFlow\",\"scheduleOrder\": true,\"cartId\": \"cartId\",\"processAction\": \"processAction\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"creditAppNum\",\"caseId\": \"caseId\"},\"data\": {\"lines\": [{\"mtn\": \"98765432\",\"edgeup\": {\"deviceId\": \"deviceId\",\"deviceMismatch\": \"deviceMismatch\"}}],\"upgradeReasonCode\": \"upgradeReasonCode\",\"effectiveDate\": \"effectiveDate\"},\"safeTechSessionId\": \"safeTechSessionId\",\"globalId\": \"globalId\"}";
		UpdateEdgeupPEGARequest pegaRequest = new UpdateEdgeupPEGARequest();
		UpdateEdgeupUIRequest uiRequest = mapper.readValue(uiRequestString, UpdateEdgeupUIRequest.class);
		UpdateEdgeupPEGARequest response = CartPegaRequestUtil2.formatRemoveEdgeUpRequest(pegaRequest, uiRequest);
		Assert.assertEquals("EUP", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	
	@Test
	public void formatRemoveEdgeUpRequestNSETest() throws JsonMappingException, JsonProcessingException {
		String uiRequestString = "{\"channelId\": \"OMNI-CARE\",\"cartInfo\": {\"accountNumber\": \"12345\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"PromoHub\",\"intendType\": \"NSE\",\"mtnFlow\": null,\"scheduleOrder\": true,\"cartId\": \"cartId\",\"processAction\": \"\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"creditAppNum\",\"caseId\": \"caseId\"},\"data\": {\"lines\": [{\"upgradeReasonCode\": \"upgradeReasonCode\",\"mtn\": \"98765432\",\"edgeup\": {\"deviceId\": \"\",\"deviceMismatch\": \"\"}}],\"upgradeReasonCode\": \"\",\"effectiveDate\": \"effectiveDate\",\"recommDevId\": \"recommDevId\",\"recommSkuId\": \"recommSkuId\",\"mtnSOIRecommendation\": true},\"safeTechSessionId\": \"safeTechSessionId\",\"globalId\": \"globalId\"}";
		UpdateEdgeupPEGARequest pegaRequest = new UpdateEdgeupPEGARequest();
		UpdateEdgeupUIRequest uiRequest = mapper.readValue(uiRequestString, UpdateEdgeupUIRequest.class);
		UpdateEdgeupPEGARequest response = CartPegaRequestUtil2.formatRemoveEdgeUpRequest(pegaRequest, uiRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	
	@Test
	public void addPlanPEGARequestTest() throws IOException {
		String sampleUIRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"cartCreator\": \"\",\"processingMTN\": \"\",\"processStep\": \"\",\"intendType\": \"\",\"cartId\": \"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\": \"\",\"accountNumber\": \"account\",\"editPlanClick\": true,\"deviceType\": \"deviceType\",\"accountLevelPlan\": true,\"isSmartLocator\": true,\"expressCheckout\": true,\"promoHubJourney\": true,\"mtnFlow\": \"mtn\",\"clientAppName\": \"VZW-DOTCOM-BBP\",\"intent\": \"\",\"rpsIntent\": \"rpsIntent\"},\"data\": {\"lines\": [{\"nickName\": \"name\",\"promoRejectionIndicator\": true,\"numbersharePairingMode\": \"numbersharePairingMode\",\"addFeatures\": [],\"deviceTypeSelected\": \"deviceTypeSelected\",\"selectedOffers\": [{}],\"device\": {},\"mtn\": null,\"contractTerm\": \"contractTerm\",\"trialSelected\": \"true\",\"subscriptionSelected\": \"true\",\"trialAllowance\": \"abcd\",\"trialValidityPeriod\": \"abcd\",\"plan\": {\"id\": \"50116\",\"isRecommendedPlan\": false,\"recommender\": \"\",\"SFO\": [{\"id\": \"2333\",\"bundlename\": \"homeSecurity\",\"actionindicator\": \"A\"},{\"id\": \"2332\",\"bundlename\": \"homeSecurity\",\"actionindicator\": \"C\"}]}}],\"parentMtn\": null,\"retrieveFeatureLossReferenceData\": \"retrieveFeatureLossReferenceData\",\"effectiveDate\": \"effectiveDate\"}}";
        AddPlanUIRequest uiRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
        AddPlanPEGARequest pegaRequest = new AddPlanPEGARequest();
		AddPlanPEGARequest response = CartPegaRequestUtil2.formatAddPlanRequest(pegaRequest, uiRequest, true,false, getFFlag(), true);
		Assert.assertEquals("CPC", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	
	@Test
	public void addPlanPEGARequestREXTest() throws IOException {
		String sampleUIRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"cartCreator\": \"\",\"processingMTN\": \"\",\"processStep\": \"PromoHub\",\"intendType\": \"REX\",\"cartId\": \"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\": \"\",\"accountNumber\": \"account\",\"editPlanClick\": null,\"deviceType\": \"deviceType\",\"accountLevelPlan\": true,\"isSmartLocator\": true,\"expressCheckout\": true,\"promoHubJourney\": true,\"mtnFlow\": \"mtn\",\"clientAppName\": \"VZW-DOTCOM\",\"intent\": \"Inline-CPC\",\"rpsIntent\": \"rpsIntent\"},\"data\": {\"checkAutoPayDiscountEligible\": \"checkAutoPayDiscountEligible\",\"lines\": [],\"parentMtn\": null,\"retrieveFeatureLossReferenceData\": \"retrieveFeatureLossReferenceData\",\"effectiveDate\": \"effectiveDate\"}}";
        AddPlanUIRequest uiRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
        AddPlanPEGARequest pegaRequest = new AddPlanPEGARequest();
		AddPlanPEGARequest response = CartPegaRequestUtil2.formatAddPlanRequest(pegaRequest, uiRequest, true,false, getFFlag(), true);
		Assert.assertEquals("FEA", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	
	@Test
	public void addPlanPEGARequestCLNRTest() throws IOException {
		String sampleUIRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"cartCreator\": \"\",\"processingMTN\": \"\",\"processStep\": \"\",\"intendType\": \"CLNR\",\"cartId\": \"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\": \"\",\"accountNumber\": \"account\",\"editPlanClick\": null,\"deviceType\": \"deviceType\",\"accountLevelPlan\": true,\"isSmartLocator\": true,\"expressCheckout\": true,\"promoHubJourney\": false,\"mtnFlow\": \"mtn\",\"clientAppName\": \"VZW-DOTCOM\",\"intent\": \"Inline\",\"rpsIntent\": \"rpsIntent\"},\"data\": {\"checkAutoPayDiscountEligible\": \"checkAutoPayDiscountEligible\",\"lines\": [],\"parentMtn\": null,\"retrieveFeatureLossReferenceData\": \"retrieveFeatureLossReferenceData\",\"effectiveDate\": \"effectiveDate\"}}";
        AddPlanUIRequest uiRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
        AddPlanPEGARequest pegaRequest = new AddPlanPEGARequest();
		AddPlanPEGARequest response = CartPegaRequestUtil2.formatAddPlanRequest(pegaRequest, uiRequest, true,false, getFFlag(), true);
		Assert.assertEquals("FEA", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	
	@Test
	public void addPlanPEGARequestNSETest() throws IOException {
		String sampleUIRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"cartCreator\": \"\",\"processingMTN\": \"\",\"processStep\": \"\",\"intendType\": \"NSE\",\"cartId\": \"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\": \"\",\"accountNumber\": \"account\",\"editPlanClick\": true,\"deviceType\": \"deviceType\",\"accountLevelPlan\": true,\"isSmartLocator\": true,\"expressCheckout\": true,\"promoHubJourney\": true,\"mtnFlow\": \"mtn\",\"clientAppName\": \"VZW-DOTCOM\",\"intent\": \"Inline\",\"rpsIntent\": \"rpsIntent\"},\"data\": {\"checkAutoPayDiscountEligible\": \"checkAutoPayDiscountEligible\",\"lines\": [],\"parentMtn\": null,\"retrieveFeatureLossReferenceData\": \"retrieveFeatureLossReferenceData\",\"effectiveDate\": \"effectiveDate\"}}";
        AddPlanUIRequest uiRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
        AddPlanPEGARequest pegaRequest = new AddPlanPEGARequest();
		AddPlanPEGARequest response = CartPegaRequestUtil2.formatAddPlanRequest(pegaRequest, uiRequest, true,false, getFFlag(), true);
		Assert.assertEquals("FEA", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	
	@Test
	public void addPlanPEGARequestNSEBYODTest() throws IOException {
		String sampleUIRequestString = "{\"channelId\": \"VZW-DOTCOM-BBP\",\"cartInfo\": {\"cartCreator\": \"\",\"processingMTN\": \"\",\"processStep\": \"\",\"intendType\": \"NSEBYOD\",\"cartId\": \"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\": \"\",\"accountNumber\": \"account\",\"editPlanClick\": true,\"deviceType\": \"deviceType\",\"accountLevelPlan\": true,\"isSmartLocator\": true,\"expressCheckout\": true,\"promoHubJourney\": true,\"mtnFlow\": \"mtn\",\"clientAppName\": \"VZW-DOTCOM-BBP\",\"intent\": \"Inline\",\"rpsIntent\": \"rpsIntent\"},\"data\": {\"checkAutoPayDiscountEligible\": \"checkAutoPayDiscountEligible\",\"lines\": [{\"nickName\": \"name\",\"promoRejectionIndicator\": true,\"numbersharePairingMode\": \"numbersharePairingMode\",\"addFeatures\": [{}],\"deviceTypeSelected\": \"\",\"selectedOffers\": [{}],\"device\": {},\"mtn\": null,\"contractTerm\": \"contractTerm\",\"trialSelected\": \"true\", \"rtdOfferId\":\"345\",\"restricted\":\"Y\",\"subscriptionSelected\": \"true\",\"trialAllowance\": \"abcd\",\"trialValidityPeriod\": \"abcd\",\"plan\": null}],\"parentMtn\": null,\"retrieveFeatureLossReferenceData\": \"retrieveFeatureLossReferenceData\",\"effectiveDate\": \"effectiveDate\"}}";
        AddPlanUIRequest uiRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
        AddPlanPEGARequest pegaRequest = new AddPlanPEGARequest();
		AddPlanPEGARequest response = CartPegaRequestUtil2.formatAddPlanRequest(pegaRequest, uiRequest, true,false, getFFlag(), true);
		Assert.assertEquals("FEA", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	
	@Test
	public void addPlanPEGARequestNSELTETest() throws IOException {
		String sampleUIRequestString = "{\"channelId\": \"VZW-DOTCOM-BBP\",\"cartInfo\": {\"cartCreator\": \"\",\"processingMTN\": \"\",\"processStep\": \"\",\"intendType\": \"NSE_LTE\",\"cartId\": \"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\": \"\",\"accountNumber\": \"account\",\"editPlanClick\": true,\"deviceType\": \"deviceType\",\"accountLevelPlan\": true,\"isSmartLocator\": true,\"expressCheckout\": true,\"promoHubJourney\": true,\"mtnFlow\": \"mtn\",\"clientAppName\": \"VZW-DOTCOM-BBP\",\"intent\": \"Inline\",\"rpsIntent\": \"rpsIntent\"},\"data\": {\"checkAutoPayDiscountEligible\": \"checkAutoPayDiscountEligible\",\"lines\": [{\"nickName\": \"name\",\"promoRejectionIndicator\": true,\"numbersharePairingMode\": \"numbersharePairingMode\",\"addFeatures\": [{}],\"deviceTypeSelected\": \"\",\"selectedOffers\": [{}],\"device\": {},\"mtn\": null,\"contractTerm\": \"contractTerm\",\"trialSelected\": \"true\", \"rtdOfferId\":\"345\",\"restricted\":\"Y\",\"subscriptionSelected\": \"true\",\"trialAllowance\": \"abcd\",\"trialValidityPeriod\": \"abcd\",\"plan\": null}],\"parentMtn\": null,\"retrieveFeatureLossReferenceData\": \"retrieveFeatureLossReferenceData\",\"effectiveDate\": \"effectiveDate\"}}";
        AddPlanUIRequest uiRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
        AddPlanPEGARequest pegaRequest = new AddPlanPEGARequest();
		AddPlanPEGARequest response = CartPegaRequestUtil2.formatAddPlanRequest(pegaRequest, uiRequest, true,false, getFFlag(), true);
		Assert.assertEquals("FEA", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	
	@Test
	public void formatRemoveLinesRequestTest() throws JsonMappingException, JsonProcessingException {
		String uiRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"expressCheckout\": null,\"accountNumber\": \"12345\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"\",\"intendType\": \"\",\"mtnFlow\": \"mtnFlow\",\"scheduleOrder\": true,\"cartId\": \"cartId\",\"processAction\": \"\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"creditAppNum\",\"caseId\": \"caseId\"},\"data\": {\"lines\": [{\"mtn\": \"98765432\",\"edgeup\": {\"deviceId\": \"deviceId\",\"deviceMismatch\": \"deviceMismatch\"}}]},\"safeTechSessionId\": \"safeTechSessionId\",\"globalId\": \"globalId\"}";
		RemoveLinesPEGARequest pegaRequest = new RemoveLinesPEGARequest();
		RemoveLinesUIRequest uiRequest = mapper.readValue(uiRequestString, RemoveLinesUIRequest.class);
		RemoveLinesPEGARequest response = CartPegaRequestUtil2.formatRemoveLinesRequest(pegaRequest, uiRequest);
		Assert.assertEquals("CPC", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	
	@Test
	public void formatRemoveLinesRequestNSELTETest() throws JsonMappingException, JsonProcessingException {
		String uiRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"expressCheckout\": true,\"accountNumber\": \"12345\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"PromoHub\",\"intendType\": \"NSE_LTE\",\"mtnFlow\": \"mtnFlow\",\"scheduleOrder\": true,\"cartId\": \"cartId\",\"processAction\": \"deleteAllAccessories\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"creditAppNum\",\"caseId\": \"caseId\"},\"data\": {\"lines\": [{\"mtn\": \"98765432\",\"edgeup\": {\"deviceId\": \"deviceId\",\"deviceMismatch\": \"deviceMismatch\"}}]},\"safeTechSessionId\": \"safeTechSessionId\",\"globalId\": \"globalId\"}";
		RemoveLinesPEGARequest pegaRequest = new RemoveLinesPEGARequest();
		RemoveLinesUIRequest uiRequest = mapper.readValue(uiRequestString, RemoveLinesUIRequest.class);
		RemoveLinesPEGARequest response = CartPegaRequestUtil2.formatRemoveLinesRequest(pegaRequest, uiRequest);
		Assert.assertEquals("NSE_LTE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	
	@Test
	public void formatRemoveLinesRequestNSE5GTest() throws JsonMappingException, JsonProcessingException {
		String uiRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"expressCheckout\": true,\"accountNumber\": \"12345\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"PromoHub\",\"intendType\": \"NSE_5G\",\"mtnFlow\": \"mtnFlow\",\"scheduleOrder\": true,\"cartId\": \"cartId\",\"processAction\": \"removeDevice\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"creditAppNum\",\"caseId\": \"caseId\"},\"data\": {\"lines\": [{\"mtn\": \"98765432\",\"edgeup\": {\"deviceId\": \"deviceId\",\"deviceMismatch\": \"deviceMismatch\"}}]},\"safeTechSessionId\": \"safeTechSessionId\",\"globalId\": \"globalId\"}";
		RemoveLinesPEGARequest pegaRequest = new RemoveLinesPEGARequest();
		RemoveLinesUIRequest uiRequest = mapper.readValue(uiRequestString, RemoveLinesUIRequest.class);
		RemoveLinesPEGARequest response = CartPegaRequestUtil2.formatRemoveLinesRequest(pegaRequest, uiRequest);
		Assert.assertEquals("NSE_5G", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	
	@Test
	public void formatRemoveLinesRequestNSETest() throws JsonMappingException, JsonProcessingException {
		String uiRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"expressCheckout\": true,\"accountNumber\": \"12345\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"PromoHub\",\"intendType\": \"NSE\",\"mtnFlow\": \"mtnFlow\",\"scheduleOrder\": true,\"cartId\": \"cartId\",\"processAction\": \"action\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"creditAppNum\",\"caseId\": \"caseId\"},\"data\": {\"lines\": [{\"mtn\": \"98765432\",\"edgeup\": {\"deviceId\": \"deviceId\",\"deviceMismatch\": \"deviceMismatch\"}}]},\"safeTechSessionId\": \"safeTechSessionId\",\"globalId\": \"globalId\"}";
		RemoveLinesPEGARequest pegaRequest = new RemoveLinesPEGARequest();
		RemoveLinesUIRequest uiRequest = mapper.readValue(uiRequestString, RemoveLinesUIRequest.class);
		RemoveLinesPEGARequest response = CartPegaRequestUtil2.formatRemoveLinesRequest(pegaRequest, uiRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	
	@Test
	public void formatRemoveLinesRequestREXTest() throws JsonMappingException, JsonProcessingException {
		String uiRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"expressCheckout\": true,\"accountNumber\": \"12345\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"PromoHub\",\"intendType\": \"REX\",\"mtnFlow\": \"mtnFlow\",\"scheduleOrder\": true,\"cartId\": \"cartId\",\"processAction\": \"action\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"creditAppNum\",\"caseId\": \"caseId\"},\"data\": {\"lines\": [{\"mtn\": \"98765432\",\"edgeup\": {\"deviceId\": \"deviceId\",\"deviceMismatch\": \"deviceMismatch\"}}]},\"safeTechSessionId\": \"safeTechSessionId\",\"globalId\": \"globalId\"}";
		RemoveLinesPEGARequest pegaRequest = new RemoveLinesPEGARequest();
		RemoveLinesUIRequest uiRequest = mapper.readValue(uiRequestString, RemoveLinesUIRequest.class);
		RemoveLinesPEGARequest response = CartPegaRequestUtil2.formatRemoveLinesRequest(pegaRequest, uiRequest);
		Assert.assertEquals("REX", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	
	@Test
	public void formatRemoveLinesRequestNSEBYODTest() throws JsonMappingException, JsonProcessingException {
		String uiRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"expressCheckout\": true,\"accountNumber\": \"12345\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"PromoHub\",\"intendType\": \"NSEBYOD\",\"mtnFlow\": \"\",\"scheduleOrder\": true,\"cartId\": \"cartId\",\"processAction\": \"action\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"creditAppNum\",\"caseId\": \"caseId\"},\"data\": {\"lines\": [{\"mtn\": \"98765432\",\"edgeup\": {\"deviceId\": \"deviceId\",\"deviceMismatch\": \"deviceMismatch\"}}]},\"safeTechSessionId\": \"safeTechSessionId\",\"globalId\": \"globalId\"}";
		RemoveLinesPEGARequest pegaRequest = new RemoveLinesPEGARequest();
		RemoveLinesUIRequest uiRequest = mapper.readValue(uiRequestString, RemoveLinesUIRequest.class);
		RemoveLinesPEGARequest response = CartPegaRequestUtil2.formatRemoveLinesRequest(pegaRequest, uiRequest);
		Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	
	@Test
	public void formatRemoveLinesRequestDEOTest() throws JsonMappingException, JsonProcessingException {
		String uiRequestString = "{\"channelId\": \"OMNI-CARE\",\"cartInfo\": {\"expressCheckout\": false,\"accountNumber\": \"12345\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"PromoHub\",\"intendType\": \"DEO\",\"mtnFlow\": \"\",\"scheduleOrder\": true,\"cartId\": \"cartId\",\"processAction\": \"action\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"creditAppNum\",\"caseId\": \"caseId\"},\"data\": {\"lines\": [{\"mtn\": \"98765432\",\"edgeup\": {\"deviceId\": \"deviceId\",\"deviceMismatch\": \"deviceMismatch\"}}]},\"safeTechSessionId\": \"safeTechSessionId\",\"globalId\": \"globalId\"}";
		RemoveLinesPEGARequest pegaRequest = new RemoveLinesPEGARequest();
		RemoveLinesUIRequest uiRequest = mapper.readValue(uiRequestString, RemoveLinesUIRequest.class);
		RemoveLinesPEGARequest response = CartPegaRequestUtil2.formatRemoveLinesRequest(pegaRequest, uiRequest);
		Assert.assertEquals("DEO", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	
	@Test
	public void formatRemoveLinesRequestACCTest() throws JsonMappingException, JsonProcessingException {
		String uiRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"expressCheckout\": true,\"accountNumber\": \"12345\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"PromoHub\",\"intendType\": \"\",\"mtnFlow\": \"mtnFlow\",\"scheduleOrder\": true,\"cartId\": \"cartId\",\"processAction\": \"deleteAllAccessories\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"creditAppNum\",\"caseId\": \"caseId\"},\"data\": {\"lines\": [{\"mtn\": \"98765432\",\"edgeup\": {\"deviceId\": \"deviceId\",\"deviceMismatch\": \"deviceMismatch\"}}]},\"safeTechSessionId\": \"safeTechSessionId\",\"globalId\": \"globalId\"}";
		RemoveLinesPEGARequest pegaRequest = new RemoveLinesPEGARequest();
		RemoveLinesUIRequest uiRequest = mapper.readValue(uiRequestString, RemoveLinesUIRequest.class);
		RemoveLinesPEGARequest response = CartPegaRequestUtil2.formatRemoveLinesRequest(pegaRequest, uiRequest);
		Assert.assertEquals("ACC", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	
	@Test
	public void formatRemoveLinesRequestAALTest() throws JsonMappingException, JsonProcessingException {
		String uiRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"expressCheckout\": true,\"accountNumber\": \"12345\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"PromoHub\",\"intendType\": \"\",\"mtnFlow\": \"mtnFlow\",\"scheduleOrder\": true,\"cartId\": \"cartId\",\"processAction\": \"removeDevice\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"creditAppNum\",\"caseId\": \"caseId\"},\"data\": {\"lines\": [{\"mtn\": \"98765432\",\"edgeup\": {\"deviceId\": \"deviceId\",\"deviceMismatch\": \"deviceMismatch\"}}]},\"safeTechSessionId\": \"safeTechSessionId\",\"globalId\": \"globalId\"}";
		RemoveLinesPEGARequest pegaRequest = new RemoveLinesPEGARequest();
		RemoveLinesUIRequest uiRequest = mapper.readValue(uiRequestString, RemoveLinesUIRequest.class);
		RemoveLinesPEGARequest response = CartPegaRequestUtil2.formatRemoveLinesRequest(pegaRequest, uiRequest);
		Assert.assertEquals("AAL", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	
	@Test
	public void formatPastDuesRequestTest() throws JsonMappingException, JsonProcessingException {
		String uiRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"pastDueAccepted\": \"pastDueAccepted\",\"expressCheckout\": null,\"accountNumber\": \"12345\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"\",\"intendType\": \"\",\"mtnFlow\": \"mtnFlow\",\"scheduleOrder\": true,\"cartId\": \"cartId\",\"processAction\": \"\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"creditAppNum\",\"caseId\": \"caseId\"},\"data\": {\"lines\": [{\"mtn\": \"98765432\",\"edgeup\": {\"deviceId\": \"deviceId\",\"deviceMismatch\": \"deviceMismatch\"}}]},\"safeTechSessionId\": \"safeTechSessionId\",\"globalId\": \"globalId\"}";
		PastDuesPEGARequest pegaRequest = new PastDuesPEGARequest();
		PastDuesUIRequest uiRequest = mapper.readValue(uiRequestString, PastDuesUIRequest.class);
		PastDuesPEGARequest response = CartPegaRequestUtil2.formatPastDuesRequest(pegaRequest, uiRequest);
		Assert.assertEquals("EUP", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	
	@Test
	public void formatPastDuesRequestNSETest() throws JsonMappingException, JsonProcessingException {
		String uiRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"pastDueAccepted\": null,\"accountNumber\": \"12345\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"PromoHub\",\"intendType\": \"NSE\",\"mtnFlow\": \"mtnFlow\",\"scheduleOrder\": true,\"cartId\": \"cartId\",\"processAction\": \"\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"creditAppNum\",\"caseId\": \"caseId\"},\"data\": {\"lines\": [{\"mtn\": \"98765432\",\"edgeup\": {\"deviceId\": \"deviceId\",\"deviceMismatch\": \"deviceMismatch\"}}]},\"safeTechSessionId\": \"safeTechSessionId\",\"globalId\": \"globalId\"}";
		PastDuesPEGARequest pegaRequest = new PastDuesPEGARequest();
		PastDuesUIRequest uiRequest = mapper.readValue(uiRequestString, PastDuesUIRequest.class);
		PastDuesPEGARequest response = CartPegaRequestUtil2.formatPastDuesRequest(pegaRequest, uiRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	
	@Test
	public void formatInitiateCheckoutRequestTest2() throws IOException {
		String sampleUIRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\":{\"quoteId\": \"quote\",\"isInterimValidation\": true,\"effectivedate\": true,\"isCareRepAssisted\":null,\"intendType\":\"\",\"creditAppNum\":null,\"creditStatus\":null,\"flowType\":\"\",\"clientAppName\":\"EXPRESS-STORE\",\"cartId\":\"264e15b7-0259-4fb4-8677-2d721e833326\",\"caseId\":\"SOP-4073532-C01\",\"accountNumber\":\"0624305202-00003\",\"cartCreator\":\"7064009338\",\"processingMTN\":\"7064009338\",\"locationCode\":\"0026301\",\"salesRepId\":\"\", \"processStep\": \"Promohub\", \"processAction\": \"ProcessAction\", \"isExpressCheckout\": false, \"rpsIntent\": \"rps\"}}";
		InitiateCheckoutUIRequest UIRequest = mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
		InitiateCheckoutPEGARequest pegaRequest = new InitiateCheckoutPEGARequest();
		InitiateCheckoutPEGARequest response = CartPegaRequestUtil2.formatInitiateCheckoutRequest(pegaRequest, UIRequest);
		Assert.assertNotNull(response);
	}
	
	@Test
	public void formatInitiateCheckoutRequestNSETest() throws IOException {
		String sampleUIRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\":{\"quoteId\": \"quote\",\"isInterimValidation\": true,\"effectivedate\": true,\"isCareRepAssisted\":null,\"intendType\":\"NSE\",\"creditAppNum\":null,\"creditStatus\":null,\"flowType\":\"\",\"clientAppName\":\"EXPRESS-STORE\",\"cartId\":\"264e15b7-0259-4fb4-8677-2d721e833326\",\"caseId\":\"SOP-4073532-C01\",\"accountNumber\":\"0624305202-00003\",\"cartCreator\":\"7064009338\",\"processingMTN\":\"7064009338\",\"locationCode\":\"0026301\",\"salesRepId\":\"\", \"processStep\": \"Promohub\", \"processAction\": \"ProcessAction\", \"isExpressCheckout\": false, \"rpsIntent\": \"rps\"}}";
		InitiateCheckoutUIRequest UIRequest = mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
		InitiateCheckoutPEGARequest pegaRequest = new InitiateCheckoutPEGARequest();
		InitiateCheckoutPEGARequest response = CartPegaRequestUtil2.formatInitiateCheckoutRequest(pegaRequest, UIRequest);
		Assert.assertNotNull(response);
	}
	
	@Test
	public void formatInitiateCheckoutRequestNSEBYODTest() throws IOException {
		String sampleUIRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\":{\"quoteId\": \"quote\",\"isInterimValidation\": true,\"effectivedate\": true,\"isCareRepAssisted\":null,\"intendType\":\"NSEBYOD\",\"creditAppNum\":null,\"creditStatus\":null,\"flowType\":\"\",\"clientAppName\":\"EXPRESS-STORE\",\"cartId\":\"264e15b7-0259-4fb4-8677-2d721e833326\",\"caseId\":\"SOP-4073532-C01\",\"accountNumber\":\"0624305202-00003\",\"cartCreator\":\"7064009338\",\"processingMTN\":\"7064009338\",\"locationCode\":\"0026301\",\"salesRepId\":\"\", \"processStep\": \"Promohub\", \"processAction\": \"ProcessAction\", \"isExpressCheckout\": false, \"rpsIntent\": \"rps\"}}";
		InitiateCheckoutUIRequest UIRequest = mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
		InitiateCheckoutPEGARequest pegaRequest = new InitiateCheckoutPEGARequest();
		InitiateCheckoutPEGARequest response = CartPegaRequestUtil2.formatInitiateCheckoutRequest(pegaRequest, UIRequest);
		Assert.assertNotNull(response);
	}
	
	@Test
	public void formatInitiateCheckoutRequestNSE5GTest() throws IOException {
		String sampleUIRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\":{\"quoteId\": \"quote\",\"isInterimValidation\": true,\"effectivedate\": true,\"isCareRepAssisted\":null,\"intendType\":\"NSE_5G\",\"creditAppNum\":null,\"creditStatus\":null,\"flowType\":\"\",\"clientAppName\":\"EXPRESS-STORE\",\"cartId\":\"264e15b7-0259-4fb4-8677-2d721e833326\",\"caseId\":\"SOP-4073532-C01\",\"accountNumber\":\"0624305202-00003\",\"cartCreator\":\"7064009338\",\"processingMTN\":\"7064009338\",\"locationCode\":\"0026301\",\"salesRepId\":\"\", \"processStep\": \"Promohub\", \"processAction\": \"ProcessAction\", \"isExpressCheckout\": false, \"rpsIntent\": \"rps\"}}";
		InitiateCheckoutUIRequest UIRequest = mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
		InitiateCheckoutPEGARequest pegaRequest = new InitiateCheckoutPEGARequest();
		InitiateCheckoutPEGARequest response = CartPegaRequestUtil2.formatInitiateCheckoutRequest(pegaRequest, UIRequest);
		Assert.assertNotNull(response);
	}
	
	@Test
	public void formatInitiateCheckoutRequestNSEACCTest() throws IOException {
		String sampleUIRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\":{\"quoteId\": \"quote\",\"isInterimValidation\": true,\"effectivedate\": true,\"isCareRepAssisted\":null,\"intendType\":\"NSEACC\",\"creditAppNum\":null,\"creditStatus\":null,\"flowType\":\"\",\"clientAppName\":\"EXPRESS-STORE\",\"cartId\":\"264e15b7-0259-4fb4-8677-2d721e833326\",\"caseId\":\"SOP-4073532-C01\",\"accountNumber\":\"0624305202-00003\",\"cartCreator\":\"7064009338\",\"processingMTN\":\"7064009338\",\"locationCode\":\"0026301\",\"salesRepId\":\"\", \"processStep\": \"Promohub\", \"processAction\": \"\", \"isExpressCheckout\": true, \"rpsIntent\": \"rps\"}}";
		InitiateCheckoutUIRequest UIRequest = mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
		InitiateCheckoutPEGARequest pegaRequest = new InitiateCheckoutPEGARequest();
		InitiateCheckoutPEGARequest response = CartPegaRequestUtil2.formatInitiateCheckoutRequest(pegaRequest, UIRequest);
		Assert.assertNotNull(response);
	}
	
	@Test
	public void formatInitiateCheckoutRequestCLNRTest() throws IOException {
		String sampleUIRequestString = "{\"channelId\": \"OMNI-CARE\",\"cartInfo\":{\"quoteId\": \"quote\",\"isInterimValidation\": true,\"effectivedate\": true,\"isCareRepAssisted\":null,\"intendType\":\"CLNR\",\"creditAppNum\":null,\"creditStatus\":null,\"flowType\":\"\",\"clientAppName\":\"EXPRESS-STORE\",\"cartId\":\"264e15b7-0259-4fb4-8677-2d721e833326\",\"caseId\":\"SOP-4073532-C01\",\"accountNumber\":\"0624305202-00003\",\"cartCreator\":\"7064009338\",\"processingMTN\":\"7064009338\",\"locationCode\":\"0026301\",\"salesRepId\":\"\", \"processStep\": \"Promohub\", \"processAction\": \"\", \"isExpressCheckout\": true, \"rpsIntent\": \"rps\"}}";
		InitiateCheckoutUIRequest UIRequest = mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
		InitiateCheckoutPEGARequest pegaRequest = new InitiateCheckoutPEGARequest();
		InitiateCheckoutPEGARequest response = CartPegaRequestUtil2.formatInitiateCheckoutRequest(pegaRequest, UIRequest);
		Assert.assertNotNull(response);
	}
	
	@Test
	public void formatInitiateCheckoutRequestAAL5GTest() throws IOException {
		String sampleUIRequestString = "{\"channelId\": \"OMNI-CARE\",\"cartInfo\":{\"quoteId\": \"quote\",\"isInterimValidation\": true,\"effectivedate\": true,\"isCareRepAssisted\":null,\"intendType\":\"AAL_CBD_TECH\",\"creditAppNum\":null,\"creditStatus\":null,\"flowType\":\"\",\"clientAppName\":\"EXPRESS-STORE\",\"cartId\":\"264e15b7-0259-4fb4-8677-2d721e833326\",\"caseId\":\"SOP-4073532-C01\",\"accountNumber\":\"0624305202-00003\",\"cartCreator\":\"7064009338\",\"processingMTN\":\"7064009338\",\"locationCode\":\"0026301\",\"salesRepId\":\"\", \"processStep\": \"Promohub\", \"processAction\": \"\", \"isExpressCheckout\": true, \"rpsIntent\": \"rps\"}}";
		InitiateCheckoutUIRequest UIRequest = mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
		InitiateCheckoutPEGARequest pegaRequest = new InitiateCheckoutPEGARequest();
		InitiateCheckoutPEGARequest response = CartPegaRequestUtil2.formatInitiateCheckoutRequest(pegaRequest, UIRequest);
		Assert.assertNotNull(response);
	}
	
	@Test
	public void formatInitiateCheckoutRequestEUP5GTest() throws IOException {
		String sampleUIRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\":{\"quoteId\": \"quote\",\"isInterimValidation\": true,\"effectivedate\": true,\"isCareRepAssisted\":null,\"intendType\":\"EUP_5G\",\"creditAppNum\":null,\"creditStatus\":null,\"flowType\":\"\",\"clientAppName\":\"EXPRESS-STORE\",\"cartId\":\"264e15b7-0259-4fb4-8677-2d721e833326\",\"caseId\":\"SOP-4073532-C01\",\"accountNumber\":\"0624305202-00003\",\"cartCreator\":\"7064009338\",\"processingMTN\":\"7064009338\",\"locationCode\":\"0026301\",\"salesRepId\":\"\", \"processStep\": \"Promohub\", \"processAction\": \"ProcessAction\", \"isExpressCheckout\": true, \"rpsIntent\": \"rps\"}}";
		InitiateCheckoutUIRequest UIRequest = mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
		InitiateCheckoutPEGARequest pegaRequest = new InitiateCheckoutPEGARequest();
		InitiateCheckoutPEGARequest response = CartPegaRequestUtil2.formatInitiateCheckoutRequest(pegaRequest, UIRequest);
		Assert.assertNotNull(response);
	}
	
	@Test
	public void formatInitiateCheckoutRequestEUPBYODTest() throws IOException {
		String sampleUIRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\":{\"quoteId\": \"quote\",\"isInterimValidation\": true,\"effectivedate\": true,\"isCareRepAssisted\":null,\"intendType\":\"EUPBYOD\",\"creditAppNum\":null,\"creditStatus\":null,\"flowType\":\"\",\"clientAppName\":\"EXPRESS-STORE\",\"cartId\":\"264e15b7-0259-4fb4-8677-2d721e833326\",\"caseId\":\"SOP-4073532-C01\",\"accountNumber\":\"0624305202-00003\",\"cartCreator\":\"7064009338\",\"processingMTN\":\"7064009338\",\"locationCode\":\"0026301\",\"salesRepId\":\"\", \"processStep\": \"Promohub\", \"processAction\": \"ProcessAction\", \"isExpressCheckout\": true, \"rpsIntent\": \"rps\"}}";
		InitiateCheckoutUIRequest UIRequest = mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
		InitiateCheckoutPEGARequest pegaRequest = new InitiateCheckoutPEGARequest();
		InitiateCheckoutPEGARequest response = CartPegaRequestUtil2.formatInitiateCheckoutRequest(pegaRequest, UIRequest);
		Assert.assertNotNull(response);
	}
	
	@Test
	public void formatAddAccessoriesRequestTest() throws IOException {
        String sampleUIRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"intendType\": \"\",\"clientAppName\": \"VZW-NUMBERLINK\",\"accountNumber\": \"0624305202-00003\",\"cartCreator\": \"7064009338\",\"processingMTN\": \"7064009338\",\"processStep\": \"\",\"processAction\": \"\",\"pageId\": \"pageId\",\"subscriptionType\": \"\"},\"data\": {\"multiAccBogoOffer\": true,\"sedBarCode\": \"sedBarCode\",\"lines\": []}}";
        AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
        AddAccessoryPEGARequest pegaRequest = new AddAccessoryPEGARequest();
        AddAccessoryPEGARequest response = CartPegaRequestUtil3.formatAddAccessoriesRequest(pegaRequest, UIRequest, "oneClickCheckoutForAccessory", true);
		Assert.assertEquals("EUP", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	
	@Test
	public void formatAddAccessoriesRequestNSETest() throws IOException {
        String sampleUIRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"intendType\": \"NSE\",\"clientAppName\": \"VZW-NUMBERLINK\",\"accountNumber\": \"0624305202-00003\",\"cartCreator\": \"7064009338\",\"processingMTN\": \"7064009338\",\"processStep\": \"\",\"processAction\": \"\",\"pageId\": \"pageId\",\"subscriptionType\": \"subscriptionType\"},\"data\": {\"multiAccBogoOffer\": true,\"sedBarCode\": \"\",\"lines\": [{}]}}";
        AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
        UIRequest.getCartInfo().setGamingGiftCard("true");
        AddAccessoryPEGARequest pegaRequest = new AddAccessoryPEGARequest();
        AddAccessoryPEGARequest response = CartPegaRequestUtil3.formatAddAccessoriesRequest(pegaRequest, UIRequest, "oneClickCheckoutForAccessory", true);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
		UIRequest.setChannelId("VZW-MFA_IOS");
		UIRequest.setAppUniversalId("abcd");
		response = CartPegaRequestUtil3.formatAddAccessoriesRequest(pegaRequest, UIRequest, "oneClickCheckoutForAccessory", true);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	
	@Test
	public void formatAddAccessoriesRequestREXTest() throws IOException {
        String sampleUIRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"intendType\": \"REX\",\"clientAppName\": \"VZW-NUMBERLINK\",\"accountNumber\": \"0624305202-00003\",\"cartCreator\": \"7064009338\",\"processingMTN\": \"7064009338\",\"processStep\": \"\",\"processAction\": \"processAction\",\"pageId\": \"pageId\",\"subscriptionType\": \"subscriptionType\"},\"data\": {\"multiAccBogoOffer\": true,\"sedBarCode\": \"\",\"lines\": []}}";
        AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
        AddAccessoryPEGARequest pegaRequest = new AddAccessoryPEGARequest();
        AddAccessoryPEGARequest response = CartPegaRequestUtil3.formatAddAccessoriesRequest(pegaRequest, UIRequest, "oneClickCheckoutForAccessory", true);
		Assert.assertEquals("REX", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	
	@Test
	public void formatAddBuyoutRequestNSETest() throws IOException {
		String sampleUIRequestString = "{\"channelId\": \"OMNI-CARE\",\"cartInfo\": {\"effectivedate\": true,\"intendType\": \"NSE\",\"flowType\": \"\",\"clientAppName\": \"EXPRESS-STORE\",\"cartId\": \"264e15b7-0259-4fb4-8677-2d721e833326\",\"caseId\": \"SOP-4073532-C01\",\"accountNumber\": \"0624305202-00003\",\"cartCreator\": \"7064009338\",\"processingMTN\": \"7064009338\",\"locationCode\": \"0026301\",\"salesRepId\": \"\",\"processStep\": \"\",\"processAction\": \"\",\"isExpressCheckout\": false,\"rpsIntent\": \"rps\",\"mtnFlow\": null,\"customerConsent\": \"\"},\"data\": {\"recommDevId\": \"\",\"recommSkuId\": \"\",\"lines\": [{}],\"mtnSOIRecommendation\": null}}";
		AddBuyoutUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddBuyoutUIRequest.class);
		AddBuyoutPEGARequest pegaRequest = new AddBuyoutPEGARequest();
		AddBuyoutPEGARequest response = CartPegaRequestUtil2.formatAddBuyoutRequest(pegaRequest, UIRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	
	@Test
	public void formatAddBuyoutRequestTest() throws IOException {
		String sampleUIRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"effectivedate\": true,\"intendType\": \"\",\"flowType\": \"\",\"clientAppName\": \"EXPRESS-STORE\",\"cartId\": \"264e15b7-0259-4fb4-8677-2d721e833326\",\"caseId\": \"SOP-4073532-C01\",\"accountNumber\": \"0624305202-00003\",\"cartCreator\": \"7064009338\",\"processingMTN\": \"7064009338\",\"locationCode\": \"0026301\",\"salesRepId\": \"\",\"processStep\": \"Promohub\",\"processAction\": \"ProcessAction\",\"isExpressCheckout\": false,\"rpsIntent\": \"rps\",\"mtnFlow\": \"mtnFlow\",\"customerConsent\": \"customerConsent\"},\"data\": {\"recommDevId\": \"recommDevId\",\"recommSkuId\": \"recommSkuId\",\"lines\": [],\"mtnSOIRecommendation\": true}}";
		AddBuyoutUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddBuyoutUIRequest.class);
		AddBuyoutPEGARequest pegaRequest = new AddBuyoutPEGARequest();
		AddBuyoutPEGARequest response = CartPegaRequestUtil2.formatAddBuyoutRequest(pegaRequest, UIRequest);
		Assert.assertEquals("EUP", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	
	@Test
	public void formatAddDownPaymentRequestTest() throws IOException {
		String sampleUIRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"effectivedate\": true,\"intendType\": \"\",\"callingPage\": \"callingPage\",\"clientAppName\": \"EXPRESS-STORE\",\"cartId\": \"264e15b7-0259-4fb4-8677-2d721e833326\",\"caseId\": \"SOP-4073532-C01\",\"accountNumber\": \"0624305202-00003\",\"cartCreator\": \"7064009338\",\"processingMTN\": \"7064009338\",\"locationCode\": \"0026301\",\"salesRepId\": \"\",\"processStep\": \"Promohub\",\"processAction\": \"ProcessAction\",\"isExpressCheckout\": false,\"rpsIntent\": \"rps\",\"mtnFlow\": \"mtnFlow\",\"totalDeviceDollar\": 100.00},\"data\": {\"totalDeviceDollar\": 100.00,\"lines\": []}}";
		DownPaymentUIRequest UIRequest = mapper.readValue(sampleUIRequestString, DownPaymentUIRequest.class);
		AddDownPaymentPEGARequest pegaRequest = new AddDownPaymentPEGARequest();
		AddDownPaymentPEGARequest response = CartPegaRequestUtil2.formatAddDownPaymentRequest(pegaRequest, UIRequest);
		Assert.assertEquals("EUP", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	
	@Test
	public void formatAddDownPaymentRequestREXTest() throws IOException {
		String sampleUIRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"effectivedate\": true,\"intendType\": \"REX\",\"callingPage\": \"callingPage\",\"clientAppName\": \"EXPRESS-STORE\",\"cartId\": \"264e15b7-0259-4fb4-8677-2d721e833326\",\"caseId\": \"SOP-4073532-C01\",\"accountNumber\": \"0624305202-00003\",\"cartCreator\": \"7064009338\",\"processingMTN\": \"7064009338\",\"locationCode\": \"0026301\",\"salesRepId\": \"\",\"processStep\": \"Promohub\",\"processAction\": \"ProcessAction\",\"isExpressCheckout\": false,\"rpsIntent\": \"rps\",\"mtnFlow\": \"mtnFlow\",\"totalDeviceDollar\": 100.00},\"data\": {\"totalDeviceDollar\": 100.00,\"lines\": []}}";
		DownPaymentUIRequest UIRequest = mapper.readValue(sampleUIRequestString, DownPaymentUIRequest.class);
		AddDownPaymentPEGARequest pegaRequest = new AddDownPaymentPEGARequest();
		AddDownPaymentPEGARequest response = CartPegaRequestUtil2.formatAddDownPaymentRequest(pegaRequest, UIRequest);
		Assert.assertEquals("SalesOrderAdjustment", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
	}
	
	@Test
	public void formatAddDownPaymentRequestNSETest() throws IOException {
		String sampleUIRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"effectivedate\": true,\"intendType\": \"NSE\",\"callingPage\": \"callingPage\",\"clientAppName\": \"EXPRESS-STORE\",\"cartId\": \"264e15b7-0259-4fb4-8677-2d721e833326\",\"caseId\": \"SOP-4073532-C01\",\"accountNumber\": \"0624305202-00003\",\"cartCreator\": \"7064009338\",\"processingMTN\": \"7064009338\",\"locationCode\": \"0026301\",\"salesRepId\": \"\",\"processStep\": \"\",\"processAction\": \"ProcessAction\",\"isExpressCheckout\": false,\"rpsIntent\": \"rps\",\"mtnFlow\": \"mtnFlow\",\"totalDeviceDollar\": null},\"data\": {\"totalDeviceDollar\": null,\"lines\": [{\"lineDeviceDollar\": 100.00,\"addFeatures\": [],\"ispuFlow\": true,\"isHumSubscription\": true,\"isVZSecureSubsription\": true,\"sellerPrice\": 100.00,\"downPayment\": {}}]}}";
		DownPaymentUIRequest UIRequest = mapper.readValue(sampleUIRequestString, DownPaymentUIRequest.class);
		AddDownPaymentPEGARequest pegaRequest = new AddDownPaymentPEGARequest();
		AddDownPaymentPEGARequest response = CartPegaRequestUtil2.formatAddDownPaymentRequest(pegaRequest, UIRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
	}
	
	@Test
	public void formatAddDownPaymentRequestNSEBYODTest() throws IOException {
		String sampleUIRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"effectivedate\": true,\"intendType\": \"NSEBYOD\",\"callingPage\": null,\"clientAppName\": \"EXPRESS-STORE\",\"cartId\": \"264e15b7-0259-4fb4-8677-2d721e833326\",\"caseId\": \"SOP-4073532-C01\",\"accountNumber\": \"0624305202-00003\",\"cartCreator\": \"7064009338\",\"processingMTN\": \"7064009338\",\"locationCode\": \"0026301\",\"salesRepId\": \"\",\"processStep\": \"Promohub\",\"processAction\": \"ProcessAction\",\"isExpressCheckout\": false,\"rpsIntent\": \"rps\",\"mtnFlow\": \"mtnFlow\",\"totalDeviceDollar\": null},\"data\": {\"totalDeviceDollar\": null,\"lines\": [{\"lineDeviceDollar\": null,\"addFeatures\": [],\"ispuFlow\": true,\"isHumSubscription\": true,\"isVZSecureSubsription\": true,\"sellerPrice\": null,\"downPayment\": {}}]}}";
		DownPaymentUIRequest UIRequest = mapper.readValue(sampleUIRequestString, DownPaymentUIRequest.class);
		AddDownPaymentPEGARequest pegaRequest = new AddDownPaymentPEGARequest();
		AddDownPaymentPEGARequest response = CartPegaRequestUtil2.formatAddDownPaymentRequest(pegaRequest, UIRequest);
		Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
	}
	
	@Test
	public void formatAddFeaturesRequestTest() throws IOException {
		String sampleUIRequestString = "{\"channelId\": null,\"skipGC\": null,\"cartInfo\": {\"effectivedate\": true,\"intendType\": \"AAL\",\"cradleFlowJourney\": \"cradleFlowJourney\",\"clientAppName\": \"VZW-NUMBERLINK\",\"cartId\": \"264e15b7-0259-4fb4-8677-2d721e833326\",\"caseId\": \"SOP-4073532-C01\",\"accountNumber\": \"0624305202-00003\",\"cartCreator\": \"7064009338\",\"processingMTN\": \"7064009338\",\"locationCode\": \"0026301\",\"salesRepId\": \"\",\"processStep\": \"Promohub\",\"processAction\": \"ProcessAction\",\"isfiveGUpSellSelected\": false,\"mtnFlow\": \"mtnFlow\",\"totalDeviceDollar\": 100.00,\"editDeviceConfiguratorClick\": true,\"isSmartLocator\": true,\"accountLevelProtection\": true,\"expressCheckout\": true,\"promoHubJourney\": null,\"rpsIntent\": \"rps\"},\"data\": {\"totalDeviceDollar\": 100.00,\"lines\": null}}";
		AddFeaturesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
		AddFeaturesPEGARequest pegaRequest = new AddFeaturesPEGARequest();
		AddFeaturesPEGARequest response = CartPegaRequestUtil3.formatAddFeaturesRequest(pegaRequest, UIRequest, getFFlag());
		Assert.assertEquals("AAL", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddFeaturesRequestTest2() throws IOException {
		String sampleUIRequestString = "{\"channelId\": null,\"skipGC\": null,\"cartInfo\": {\"effectivedate\": true,\"intendType\": \"EUP\",\"cradleFlowJourney\": \"cradleFlowJourney\",\"clientAppName\": \"VZW-NUMBERLINK\",\"cartId\": \"264e15b7-0259-4fb4-8677-2d721e833326\",\"caseId\": \"SOP-4073532-C01\",\"accountNumber\": \"0624305202-00003\",\"cartCreator\": \"7064009338\",\"processingMTN\": \"7064009338\",\"locationCode\": \"0026301\",\"salesRepId\": \"\",\"processStep\": \"Promohub\",\"processAction\": \"ProcessAction\",\"isfiveGUpSellSelected\": false,\"mtnFlow\": \"mtnFlow\",\"totalDeviceDollar\": 100.00,\"editDeviceConfiguratorClick\": true,\"isSmartLocator\": true,\"accountLevelProtection\": true,\"expressCheckout\": true,\"promoHubJourney\": null,\"rpsIntent\": \"rps\"},\"data\": {\"totalDeviceDollar\": 100.00,\"lines\": null}}";
		AddFeaturesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
		AddFeaturesPEGARequest pegaRequest = new AddFeaturesPEGARequest();
		AddFeaturesPEGARequest response = CartPegaRequestUtil3.formatAddFeaturesRequest(pegaRequest, UIRequest, getFFlag());
		Assert.assertEquals("EUP", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}

	@Test
	public void formatAddFeaturesRequestTest1() throws IOException {
		String sampleUIRequestString = "{ \"channelId\": null, \"skipGC\": null, \"cartInfo\": { \"effectivedate\": true, \"intendType\": \"FEA\", \"cradleFlowJourney\": \"cradleFlowJourney\", \"clientAppName\": \"VZW-NUMBERLINK\", \"cartId\": \"264e15b7-0259-4fb4-8677-2d721e833326\", \"caseId\": \"SOP-4073532-C01\", \"accountNumber\": \"0624305202-00003\", \"cartCreator\": \"7064009338\", \"processingMTN\": \"7064009338\", \"locationCode\": \"0026301\", \"salesRepId\": \"\", \"processStep\": \"Promohub\", \"processAction\": \"ProcessAction\", \"isfiveGUpSellSelected\": false, \"mtnFlow\": \"mtnFlow\", \"totalDeviceDollar\": 100, \"editDeviceConfiguratorClick\": true, \"isSmartLocator\": true, \"accountLevelProtection\": true, \"expressCheckout\": true, \"promoHubJourney\": null, \"rpsIntent\": \"rps\" }, \"data\": { \"totalDeviceDollar\": 100, \"lines\": null, \"account\": { \"features\": { \"add\": [ { \"id\": \"3000\", \"actionIndicator\": \"A\", \"type\": \"SPO\", \"quantity\": \"1\", \"mtns\": [ { \"mtn\": \"9198204945\" } ] } ] } } } }";
		AddFeaturesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
		AddFeaturesPEGARequest pegaRequest = new AddFeaturesPEGARequest();
		AddFeaturesPEGARequest response = CartPegaRequestUtil3.formatAddFeaturesRequest(pegaRequest, UIRequest, getFFlag());
		Assert.assertEquals("FEA", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
		List<Feature> list=new ArrayList<>();
		UIRequest.getData().getAccount().getFeatures().setAdd(list);
		AddFeaturesPEGARequest response5 = CartPegaRequestUtil3.formatAddFeaturesRequest(pegaRequest, UIRequest, getFFlag());
		Assert.assertEquals("FEA", response5.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());

		UIRequest.getData().getAccount().getFeatures().setAdd(null);
		AddFeaturesPEGARequest response1 = CartPegaRequestUtil3.formatAddFeaturesRequest(pegaRequest, UIRequest, getFFlag());
		Assert.assertEquals("FEA", response1.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());

		UIRequest.getData().getAccount().setFeatures(null);
		AddFeaturesPEGARequest response2 = CartPegaRequestUtil3.formatAddFeaturesRequest(pegaRequest, UIRequest, getFFlag());
		Assert.assertEquals("FEA", response2.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());

		UIRequest.getData().getAccount().setFeatures(null);
		AddFeaturesPEGARequest response3 = CartPegaRequestUtil3.formatAddFeaturesRequest(pegaRequest, UIRequest, getFFlag());
		Assert.assertEquals("FEA", response3.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());

		UIRequest.getData().setAccount(null);
		AddFeaturesPEGARequest response4 = CartPegaRequestUtil3.formatAddFeaturesRequest(pegaRequest, UIRequest, getFFlag());
		Assert.assertEquals("FEA", response4.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());

	}

	@Test
	public void formatAddFeaturesRequestDepletionLocationTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"cartCreator\":\"7706174608\",\"intendType\":\"AAL\",\"creditAppNum\":\"7062865443\",\"processStep\":\"FeaturesPDP\",\"depletionType\":\"L\",\"depletionLocation\":\"0621801\",\"ispuFlow\":true,\"cartId\":\"1c682054-10f3-4a23-a9ad-e5d24e5acb9b\",\"caseId\":\"SOP-11392414-C01\"},\"data\":{\"lines\":[{\"accessories\":{\"add\":[{\"qty\":\"1\",\"isSoftSku\":false,\"accessoryBundle\":false,\"accountLevelAccessory\":false,\"scannedItem\":false,\"cashOptionEnabled\":false,\"id\":\"CE1000A\"}]},\"eupNoPromoFlow\":false,\"mtn\":\"7062865443\",\"features\":{\"add\":[{\"id\":\"2625\",\"quantity\":1,\"actionIndicator\":\"A\",\"type\":\"SPO\"}]},\"ispuFlow\":true,\"depletionType\":\"L\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"selectedMtn\":\"\",\"totalDeviceDollar\":null}}";
		AddFeaturesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
		AddFeaturesPEGARequest pegaRequest = new AddFeaturesPEGARequest();
		AddFeaturesPEGARequest response = CartPegaRequestUtil3.formatAddFeaturesRequest(pegaRequest, UIRequest, getFFlag());
		Assert.assertEquals("AAL", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}

	@Test
	public void formatAddFeaturesRequestNSETest() throws IOException {
		String sampleUIRequestString = "{\"channelId\": \"VZW-CHATBOT\",\"skipGC\": true,\"cartInfo\": {\"effectivedate\": true,\"intendType\": \"NSE\",\"cradleFlowJourney\": \"\",\"clientAppName\": \"\",\"cartId\": \"264e15b7-0259-4fb4-8677-2d721e833326\",\"caseId\": \"SOP-4073532-C01\",\"accountNumber\": \"\",\"cartCreator\": \"\",\"processingMTN\": \"\",\"locationCode\": \"0026301\",\"salesRepId\": \"\",\"processStep\": \"5GBOLT\",\"processAction\": \"ProcessAction\",\"isfiveGUpSellSelected\": null,\"mtnFlow\": null,\"totalDeviceDollar\": 100.00,\"editDeviceConfiguratorClick\": true,\"isSmartLocator\": null,\"accountLevelProtection\": null,\"expressCheckout\": true,\"promoHubJourney\": true,\"rpsIntent\": \"rps\"},\"data\": {\"totalDeviceDollar\": 100.00,\"lines\": [{\"mtn\": \"987654345\",\"features\": {\"add\": [],\"remove\": []},\"mcsSubscription\": {}}]}}";
		AddFeaturesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
		AddFeaturesPEGARequest pegaRequest = new AddFeaturesPEGARequest();
		AddFeaturesPEGARequest response = CartPegaRequestUtil3.formatAddFeaturesRequest(pegaRequest, UIRequest, getFFlag());
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}

	@Test
	public void formatAddFeaturesRequestNSEBYODTest() throws IOException {
		String sampleUIRequestString = "{\"channelId\": \"OMNI-CARE\",\"skipGC\": false,\"cartInfo\": {\"effectivedate\": true,\"intendType\": \"NSEBYOD\",\"cradleFlowJourney\": \"\",\"clientAppName\": \"NUMBERLINK\",\"cartId\": \"264e15b7-0259-4fb4-8677-2d721e833326\",\"caseId\": \"SOP-4073532-C01\",\"accountNumber\": \"\",\"cartCreator\": \"\",\"processingMTN\": \"\",\"locationCode\": \"0026301\",\"salesRepId\": \"\",\"processStep\": \"5GBOLT\",\"processAction\": \"ProcessAction\",\"isfiveGUpSellSelected\": null,\"mtnFlow\": null,\"totalDeviceDollar\": 100.00,\"editDeviceConfiguratorClick\": true,\"isSmartLocator\": null,\"accountLevelProtection\": null,\"expressCheckout\": true,\"promoHubJourney\": true,\"rpsIntent\": \"rps\"},\"data\": {\"totalDeviceDollar\": 100.00,\"lines\": [{\"mtn\": \"987654345\",\"features\": {\"add\": [{}],\"remove\": [{}]},\"mcsSubscription\": {}}]}}";
		AddFeaturesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
		AddFeaturesPEGARequest pegaRequest = new AddFeaturesPEGARequest();
		AddFeaturesPEGARequest response = CartPegaRequestUtil3.formatAddFeaturesRequest(pegaRequest, UIRequest, getFFlag());
		Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}

	@Test
	public void formatAddFeaturesRequestNSELTETest() throws IOException {
		String sampleUIRequestString = "{\"channelId\": \"VZW-CHATBOT\",\"skipGC\": null,\"cartInfo\": {\"effectivedate\": true,\"intendType\": \"NSE_LTE\",\"cradleFlowJourney\": \"\",\"clientAppName\": \"VZW-NUMBERLINK\",\"intent\": \"nse\",\"cartId\": \"264e15b7-0259-4fb4-8677-2d721e833326\",\"caseId\": \"SOP-4073532-C01\",\"accountNumber\": \"\",\"cartCreator\": \"\",\"processingMTN\": \"\",\"locationCode\": \"0026301\",\"salesRepId\": \"\",\"processStep\": \"\",\"processAction\": null,\"isfiveGUpSellSelected\": null,\"mtnFlow\": null,\"totalDeviceDollar\": 100.00,\"editDeviceConfiguratorClick\": true,\"isSmartLocator\": null,\"accountLevelProtection\": null,\"expressCheckout\": true,\"promoHubJourney\": true,\"rpsIntent\": \"\"},\"data\": {\"totalDeviceDollar\": 100.00,\"lines\": [{\"mtn\": \"987654345\",\"features\": {\"add\": null,\"remove\": null},\"mcsSubscription\": null}]}}";
		AddFeaturesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
		AddFeaturesPEGARequest pegaRequest = new AddFeaturesPEGARequest();
		AddFeaturesPEGARequest response = CartPegaRequestUtil3.formatAddFeaturesRequest(pegaRequest, UIRequest, getFFlag());
		Assert.assertEquals("NSE_LTE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}

	@Test
	public void formatAddFeaturesRequestNSE5GTest() throws IOException {
		String sampleUIRequestString = "{\"channelId\": \"VZW-CHATBOT\",\"skipGC\": null,\"cartInfo\": {\"effectivedate\": true,\"intendType\": \"NSE_5G\",\"cradleFlowJourney\": \"\",\"clientAppName\": \"VZW-NUMBERLINK\",\"intent\": \"nse\",\"cartId\": \"264e15b7-0259-4fb4-8677-2d721e833326\",\"caseId\": \"SOP-4073532-C01\",\"accountNumber\": \"\",\"cartCreator\": \"\",\"processingMTN\": \"\",\"locationCode\": \"0026301\",\"salesRepId\": \"\",\"processStep\": \"\",\"processAction\": null,\"isfiveGUpSellSelected\": null,\"mtnFlow\": null,\"totalDeviceDollar\": 100.00,\"editDeviceConfiguratorClick\": true,\"isSmartLocator\": null,\"accountLevelProtection\": null,\"expressCheckout\": null,\"promoHubJourney\": null,\"rpsIntent\": \"\"},\"data\": {\"totalDeviceDollar\": 100.00,\"lines\": [{\"mtn\": \"987654345\",\"features\": null,\"mcsSubscription\": {}}]}}";
		AddFeaturesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
		AddFeaturesPEGARequest pegaRequest = new AddFeaturesPEGARequest();
		AddFeaturesPEGARequest response = CartPegaRequestUtil3.formatAddFeaturesRequest(pegaRequest, UIRequest, getFFlag());
		Assert.assertEquals("NSE_5G", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}

	@Test
	public void formatAddFeaturesRequestACCTest() throws IOException {
		String sampleUIRequestString = "{\"channelId\": \"VZW-CHATBOT\",\"skipGC\": null,\"cartInfo\": {\"effectivedate\": true,\"intendType\": \"ACC\",\"cradleFlowJourney\": \"cradleFlowJourney\",\"clientAppName\": \"VZW-NUMBERLINK\",\"intent\": \"nse\",\"cartId\": \"264e15b7-0259-4fb4-8677-2d721e833326\",\"caseId\": \"SOP-4073532-C01\",\"accountNumber\": \"\",\"cartCreator\": \"\",\"processingMTN\": \"\",\"locationCode\": \"0026301\",\"salesRepId\": \"\",\"processStep\": \"\",\"processAction\": null,\"isfiveGUpSellSelected\": null,\"mtnFlow\": null,\"totalDeviceDollar\": 100.00,\"editDeviceConfiguratorClick\": null,\"isSmartLocator\": null,\"accountLevelProtection\": null,\"expressCheckout\": true,\"promoHubJourney\": false,\"rpsIntent\": \"\"},\"data\": {\"totalDeviceDollar\": 100.00,\"lines\": [{\"mtn\": \"987654345\",\"features\": null,\"mcsSubscription\": {}}]}}";
		AddFeaturesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
		AddFeaturesPEGARequest pegaRequest = new AddFeaturesPEGARequest();
		AddFeaturesPEGARequest response = CartPegaRequestUtil3.formatAddFeaturesRequest(pegaRequest, UIRequest, getFFlag());
		Assert.assertEquals("ACC", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}

	@Test
	public void formatAddFeaturesRequestNSETest2() throws IOException {
		String sampleUIRequestString = "{\"channelId\": \"OMNI-CARE\",\"skipGC\": null,\"cartInfo\": {\"effectivedate\": true,\"intendType\": \"NSE\",\"cradleFlowJourney\": \"cradleFlowJourney\",\"clientAppName\": \"VZW-NUMBERLINK\",\"intent\": \"nse\",\"cartId\": \"264e15b7-0259-4fb4-8677-2d721e833326\",\"caseId\": \"SOP-4073532-C01\",\"accountNumber\": \"\",\"cartCreator\": \"\",\"processingMTN\": \"\",\"locationCode\": \"0026301\",\"salesRepId\": \"\",\"processStep\": \"\",\"processAction\": null,\"isfiveGUpSellSelected\": null,\"mtnFlow\": null,\"totalDeviceDollar\": 100.00,\"editDeviceConfiguratorClick\": true,\"isSmartLocator\": null,\"accountLevelProtection\": null,\"expressCheckout\": false,\"promoHubJourney\": true,\"rpsIntent\": \"\"},\"data\": {\"totalDeviceDollar\": 100.00,\"lines\": [{\"mtn\": \"987654345\",\"features\": null,\"mcsSubscription\": {}}]}}";
		AddFeaturesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
		AddFeaturesPEGARequest pegaRequest = new AddFeaturesPEGARequest();
		AddFeaturesPEGARequest response = CartPegaRequestUtil3.formatAddFeaturesRequest(pegaRequest, UIRequest, getFFlag());
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}

	@Test
	public void formatAddFeaturesRequestNSEBYODTest2() throws IOException {
		String sampleUIRequestString = "{\"channelId\": \"OMNI-CARE\",\"skipGC\": null,\"cartInfo\": {\"effectivedate\": true,\"intendType\": \"NSEBYOD\",\"cradleFlowJourney\": \"cradleFlowJourney\",\"clientAppName\": \"VZW-NUMBERLINK\",\"intent\": \"nse\",\"cartId\": \"264e15b7-0259-4fb4-8677-2d721e833326\",\"caseId\": \"SOP-4073532-C01\",\"accountNumber\": \"\",\"cartCreator\": \"\",\"processingMTN\": \"\",\"locationCode\": \"0026301\",\"salesRepId\": \"\",\"processStep\": \"\",\"processAction\": null,\"isfiveGUpSellSelected\": null,\"mtnFlow\": null,\"totalDeviceDollar\": 100.00,\"editDeviceConfiguratorClick\": true,\"isSmartLocator\": null,\"accountLevelProtection\": null,\"expressCheckout\": false,\"promoHubJourney\": true,\"rpsIntent\": \"\"},\"data\": {\"totalDeviceDollar\": 100.00,\"lines\": [{\"mtn\": \"987654345\",\"features\": null,\"mcsSubscription\": {}}]}}";
		AddFeaturesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
		AddFeaturesPEGARequest pegaRequest = new AddFeaturesPEGARequest();
		AddFeaturesPEGARequest response = CartPegaRequestUtil3.formatAddFeaturesRequest(pegaRequest, UIRequest, getFFlag());
		Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}

	@Test
	public void formatAddFeaturesRequestNSELTETest2() throws IOException {
		String sampleUIRequestString = "{\"channelId\": \"OMNI-CARE\",\"skipGC\": null,\"cartInfo\": {\"effectivedate\": true,\"intendType\": \"NSE_LTE\",\"cradleFlowJourney\": \"cradleFlowJourney\",\"clientAppName\": \"VZW-NUMBERLINK\",\"intent\": \"nse\",\"cartId\": \"264e15b7-0259-4fb4-8677-2d721e833326\",\"caseId\": \"SOP-4073532-C01\",\"accountNumber\": \"\",\"cartCreator\": \"\",\"processingMTN\": \"\",\"locationCode\": \"0026301\",\"salesRepId\": \"\",\"processStep\": \"\",\"processAction\": null,\"isfiveGUpSellSelected\": null,\"mtnFlow\": null,\"totalDeviceDollar\": 100.00,\"editDeviceConfiguratorClick\": true,\"isSmartLocator\": null,\"accountLevelProtection\": null,\"expressCheckout\": false,\"promoHubJourney\": true,\"rpsIntent\": \"\"},\"data\": {\"totalDeviceDollar\": 100.00,\"lines\": [{\"mtn\": \"987654345\",\"features\": null,\"mcsSubscription\": {}}]}}";
		AddFeaturesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
		AddFeaturesPEGARequest pegaRequest = new AddFeaturesPEGARequest();
		AddFeaturesPEGARequest response = CartPegaRequestUtil3.formatAddFeaturesRequest(pegaRequest, UIRequest, getFFlag());
		Assert.assertEquals("NSE_LTE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}

	@Test
	public void formatAddFeaturesRequestNSE5GTest2() throws IOException {
		String sampleUIRequestString = "{\"channelId\": \"OMNI-CARE\",\"skipGC\": null,\"cartInfo\": {\"effectivedate\": true,\"intendType\": \"NSE_5G\",\"cradleFlowJourney\": \"cradleFlowJourney\",\"clientAppName\": \"VZW-NUMBERLINK\",\"intent\": \"nse\",\"cartId\": \"264e15b7-0259-4fb4-8677-2d721e833326\",\"caseId\": \"SOP-4073532-C01\",\"accountNumber\": \"\",\"cartCreator\": \"\",\"processingMTN\": \"\",\"locationCode\": \"0026301\",\"salesRepId\": \"\",\"processStep\": \"\",\"processAction\": null,\"isfiveGUpSellSelected\": null,\"mtnFlow\": null,\"totalDeviceDollar\": 100.00,\"editDeviceConfiguratorClick\": true,\"isSmartLocator\": null,\"accountLevelProtection\": null,\"expressCheckout\": true,\"promoHubJourney\": true,\"rpsIntent\": \"\"},\"data\": {\"totalDeviceDollar\": 100.00,\"lines\": [{\"mtn\": \"987654345\",\"features\": null,\"mcsSubscription\": {}}]}}";
		AddFeaturesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
		AddFeaturesPEGARequest pegaRequest = new AddFeaturesPEGARequest();
		AddFeaturesPEGARequest response = CartPegaRequestUtil3.formatAddFeaturesRequest(pegaRequest, UIRequest, getFFlag());
		Assert.assertEquals("NSE_5G", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}

	@Test
	public void formatAddFeaturesRequestAAL5GTest2() throws IOException {
		String sampleUIRequestString = "{\"channelId\": \"OMNI-CARE\",\"skipGC\": null,\"cartInfo\": {\"effectivedate\": true,\"intendType\": \"AAL_5G\",\"cradleFlowJourney\": \"cradleFlowJourney\",\"clientAppName\": \"VZW-NUMBERLINK\",\"intent\": \"nse\",\"cartId\": \"264e15b7-0259-4fb4-8677-2d721e833326\",\"caseId\": \"SOP-4073532-C01\",\"accountNumber\": \"\",\"cartCreator\": \"\",\"processingMTN\": \"\",\"locationCode\": \"0026301\",\"salesRepId\": \"\",\"processStep\": \"\",\"processAction\": null,\"isfiveGUpSellSelected\": null,\"mtnFlow\": null,\"totalDeviceDollar\": 100.00,\"editDeviceConfiguratorClick\": false,\"isSmartLocator\": null,\"accountLevelProtection\": null,\"expressCheckout\": true,\"promoHubJourney\": true,\"rpsIntent\": \"\"},\"data\": {\"totalDeviceDollar\": 100.00,\"lines\": [{\"mtn\": \"987654345\",\"features\": null,\"mcsSubscription\": {}}]}}";
		AddFeaturesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
		AddFeaturesPEGARequest pegaRequest = new AddFeaturesPEGARequest();
		AddFeaturesPEGARequest response = CartPegaRequestUtil3.formatAddFeaturesRequest(pegaRequest, UIRequest, getFFlag());
		Assert.assertEquals("AAL_5G", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}

	@Test
	public void formatAddDeviceRequestTestForIndirectSelectedOffers() throws JsonProcessingException {
		String sampleUIRequestString = "{\"validateCartRequest\":null,\"preConfigured\":null,\"externalId\":\"testExternalId\",\"vzId\":\"testvzId\",\"path\":null,\"cartInfo\":{\"editDeviceConfiguratorClick\":null,\"editPlanClick\":null,\"specialItemType\":null,\"rpsIntent\":\"test\",\"sessionId\":null,\"customerType\":null,\"accountType\":null,\"globalId\":null,\"bbpIntent\":null,\"activateSwitchFlow\":false,\"number_share_capable\":\"Y\",\"e911_addr_ind\":\"N\",\"specialItemType\":\"test\",\"editDeviceConfiguratorClick\":false,\"salesRepId\":\"test\",\"flowType\":\"EUP\",\"redemptionCode\":\"test\",\"authorizedUser\":{\"firstName\":\"test\",\"lastName\":\"test\"},\"totalDeviceDollar\":\"100.00\",\"isQuoteCart\":false,\"mtnFlow\":\"PromoBundle\",\"triggerPricingValidation\":false,\"clientAppName\":\"VZW-ECOM\",\"cartId\":\"15eccfe3-574e-402a-91b4-11c669769d2b\",\"caseId\":\"SOP-7676963-C01\",\"accountNumber\":\"0219838656-00001\",\"cartCreator\":\"5126807507\",\"processingMTN\":\"5126808210\",\"buyOutFlag\":\"Y\",\"buyOutSelected\":\"Y\",\"edgeUpSelected\":\"N\",\"processStep\":null,\"intendType\":\"CLNR\",\"processAction\":\"addBuyoutAmtAndDevice\",\"fetchDataFromRedis\":null,\"editDevice\":null,\"showICPage\":false,\"isSmartLocator\":false,\"triggerPricingValidation\":null,\"barCodeIds\":[{\"barCodeId\":\"test123\"}],\"isGemini\":false,\"isTradeInSelected\":null,\"expressCheckout\":null,\"replaceDevice\":false,\"amRole\":\"accountManager\",\"cradleFlowJourney\":null,\"adobeId\":null,\"referralVendorId\":null,\"ecpdToken\":null,\"rylEcpdUrl\":null,\"referralSaleRepId\":null,\"zipCode\":null,\"disableMyLink\":null,\"cartCreatorSalesRepId\":null,\"customerConsent\":null,\"iconicTestIntent\":\"test\",\"fiveGMUCEligible\":\"test\"},\"data\":{\"recommDevId\":null,\"recommSkuId\":null,\"rtm\":null,\"expressCheckout\":true,\"lines\":[{\"preBackOrderDate\":null,\"preBackOrderDisplayType\":null,\"rebateUpdate\":null,\"instantcredit\":null,\"mldTrunkMtn\":\"9876567896\",\"rtdOfferId\":\"test\",\"restricted\":\"test\",\"restrictedProductType\":\"test\",\"selectedSedOfferId\":\"test\",\"selectedSpoId\":null,\"reasonCode\":null,\"lineActivityType\":null,\"currentPlanType\":null,\"barCodeId\":\"test123\",\"inEligibleReason\":null,\"sellerPrice\":\"200.00\",\"nickName\":null,\"purchasePath\":\"\",\"donorMtn\":null,\"selectedPromoType\":\"NOPROMO\",\"selectedPromoId\":\"test\",\"giftBox\":{\"id\":\"123\",\"deviceId\":\"34567898765\"},\"idu\":{\"id\":\"123\",\"deviceId\":\"34567898765\"},\"eupNoPromoFlow\":false,\"accountOwner\":null,\"mtn\":\"5126808210\",\"trialSelected\":null, \"rtdOfferId\":\"345\",\"restricted\":\"Y\",\"subscriptionSelected\":null,\"trialAllowance\":null,\"trialValidityPeriod\":null,\"device\":{\"cartItemType\":null,\"quantityOnHand\":null,\"upgradeReasonCode\":null,\"warningMessage\":null,\"connectedCarMobile\":null,\"connectedCarColor\":null,\"category\":\"Smartphones\",\"giftbox\":null,\"connectedCarDetails\":null,\"refundType\":null,\"id\":\"MLAR3LL/A\",\"dppMonths\":36,\"contractTerm\":\"VERIZON_EDGE\",\"qty\":1,\"fiveGToFourGDownGrade\":null,\"productId\":\"dev16720001\",\"iconicPhone\":true,\"preconfigure\":\"false\",\"token\":null},\"sim\":{\"id\":\"EMBD4GSIM-N\",\"imei2\":null},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":true,\"isEdgeBuyOut\":true,\"triggerPricingValidation\":null,\"tabletJetPackDiscountIncluded\":null,\"fiveGUpSell\":null,\"is5GBoltEligible\":null,\"devicePlanCompatible\":null,\"activateLater\":null,\"promoRejectionIndicator\":true,\"unpairDevice\":false,\"tradeInInfo\":{\"deviceBrand\":\"test\",\"deviceModel\":\"test\",\"aemOfferIds\":[\"test1\",\"test2\"]},\"editSim\":null,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":true,\"selectedOffers\":[{\"subType\":\"Trade\",\"id\":\"1234\"},{\"subType\":\"test\",\"id\":\"12345\"}],\"lineDeviceDollar\":\"50.00\",\"upgradeReasonCode\":\"test\",\"trunkMtn\":\"9997865434\",\"currentPairingModeChanged\":false,\"numbersharePairingMode\":\"test\",\"isStrategicOffer\":false,\"edgeup\":{\"deviceId\":\"3456788764444\",\"deviceMismatch\":\"test\"},\"downPayment\":{\"amount\":\"100.00\"},\"PreBackOrderDate\":\"2022-08-12\",\"setUpLater\":false,\"selectedEUPDeviceForBYOD\":false,\"customerProvidedMtn\":\"8765678767\",\"customerProvidedMtnType\":\"test\",\"lineCreatorChannel\":\"test\"}],\"mtnSOIRecommendation\":null,\"totalDeviceDollar\":\"100.00\",\"selectedMtn\":null},\"channelId\":\"OMNI-INDIRECT\"}";
		AddDeviceUIRequest request = mapper.readValue(sampleUIRequestString,AddDeviceUIRequest.class);
		AddDevicePEGARequest pegareq = new AddDevicePEGARequest();
		CartPegaRequestUtil4.formatAddDeviceRequest(pegareq,request,null,true,false, false, getFFlag());
		StepVerifier.create(Mono.just(pegareq))
				.assertNext(req -> Assert.assertNotNull(pegareq.getServiceBody().getServiceRequest().getContext().getCartInfo()))
				.expectComplete().verify();
		String sampleUIRequestString2 = "{\"validateCartRequest\":null,\"preConfigured\":null,\"externalId\":null,\"vzId\":null,\"path\":null,\"cartInfo\":{\"editDeviceConfiguratorClick\":null,\"editPlanClick\":null,\"specialItemType\":null,\"salesRepId\":null,\"flowType\":null,\"rpsIntent\":null,\"sessionId\":null,\"customerType\":null,\"accountType\":null,\"globalId\":null,\"bbpIntent\":null,\"clientAppName\":\"VZW-ECOM\",\"cartId\":\"15eccfe3-574e-402a-91b4-11c669769d2b\",\"caseId\":\"SOP-7676963-C01\",\"accountNumber\":\"0219838656-00001\",\"cartCreator\":\"5126807507\",\"processingMTN\":\"5126808210\",\"buyOutFlag\":\"Y\",\"buyOutSelected\":\"Y\",\"edgeUpSelected\":\"N\",\"processStep\":\"DPPSummary\",\"intendType\":\"EUP\",\"isQuoteCart\":null,\"processAction\":\"addBuyoutAmtAndDevice\",\"mtnFlow\":\"G\",\"fetchDataFromRedis\":null,\"editDevice\":null,\"showICPage\":null,\"isSmartLocator\":null,\"triggerPricingValidation\":null,\"barCodeIds\":[],\"isGemini\":null,\"isTradeInSelected\":null,\"expressCheckout\":null,\"replaceDevice\":null,\"amRole\":\"accountManager\",\"cradleFlowJourney\":null,\"activateSwitchFlow\":null,\"adobeId\":null,\"referralVendorId\":null,\"ecpdToken\":null,\"rylEcpdUrl\":null,\"referralSaleRepId\":null,\"zipCode\":null,\"disableMyLink\":null,\"authorizedUser\":null,\"cartCreatorSalesRepId\":null,\"fiveGMUCEligible\":null,\"customerConsent\":null},\"data\":{\"recommDevId\":null,\"recommSkuId\":null,\"rtm\":null,\"lines\":[{\"preBackOrderDate\":null,\"preBackOrderDisplayType\":null,\"rebateUpdate\":null,\"instantcredit\":null,\"mldTrunkMtn\":null,\"rtdOfferId\":null,\"restricted\":null,\"restrictedProductType\":null,\"selectedSedOfferId\":null,\"selectedSpoId\":null,\"reasonCode\":null,\"lineActivityType\":null,\"currentPlanType\":null,\"barCodeId\":null,\"inEligibleReason\":null,\"sellerPrice\":null,\"nickName\":null,\"purchasePath\":\"\",\"donorMtn\":null,\"selectedPromoType\":\"NOPROMO\",\"selectedPromoId\":\"\",\"giftBox\":null,\"idu\":null,\"eupNoPromoFlow\":false,\"accountOwner\":null,\"mtn\":\"5126808210\",\"trialSelected\":null, \"rtdOfferId\":\"345\",\"restricted\":\"Y\",\"subscriptionSelected\":null,\"trialAllowance\":null,\"trialValidityPeriod\":null,\"device\":{\"cartItemType\":null,\"quantityOnHand\":null,\"upgradeReasonCode\":null,\"warningMessage\":null,\"connectedCarMobile\":null,\"connectedCarColor\":null,\"category\":\"Smartphones\",\"giftbox\":null,\"connectedCarDetails\":null,\"refundType\":null,\"id\":\"MLAR3LL/A\",\"dppMonths\":36,\"contractTerm\":\"VERIZON_EDGE\",\"qty\":1,\"fiveGToFourGDownGrade\":null,\"productId\":\"dev16720001\",\"iconicPhone\":true,\"preconfigure\":\"false\",\"token\":null},\"sim\":{\"id\":\"EMBD4GSIM-N\",\"imei2\":null},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"isEdgeBuyOut\":true,\"triggerPricingValidation\":null,\"tabletJetPackDiscountIncluded\":null,\"fiveGUpSell\":null,\"is5GBoltEligible\":null,\"devicePlanCompatible\":null,\"activateLater\":null,\"setUpLater\":null,\"selectedEUPDeviceForBYOD\":null,\"promoRejectionIndicator\":true,\"unpairDevice\":null,\"tradeInInfo\":null,\"editSim\":null,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"selectedOffers\":[{\"subType\":\"Trade\",\"id\":\"1234\"},{\"subType\":\"test\",\"id\":\"12345\"}]}],\"mtnSOIRecommendation\":null,\"totalDeviceDollar\":null,\"selectedMtn\":null},\"channelId\":\"OMNI-INDIRECT-TAB\"}";
		AddDeviceUIRequest request2 = mapper.readValue(sampleUIRequestString2,AddDeviceUIRequest.class);
		CartPegaRequestUtil4.formatAddDeviceRequest(pegareq,request2,null,true,false, false, getFFlag());
		StepVerifier.create(Mono.just(pegareq))
				.assertNext(req -> Assert.assertNotNull(pegareq.getServiceBody().getServiceRequest().getContext().getCartInfo()))
				.expectComplete().verify();
		String sampleUIRequestString3 = "{\"validateCartRequest\":null,\"preConfigured\":null,\"externalId\":null,\"vzId\":null,\"path\":null,\"cartInfo\":{\"editDeviceConfiguratorClick\":null,\"editPlanClick\":null,\"specialItemType\":null,\"salesRepId\":null,\"flowType\":null,\"rpsIntent\":null,\"sessionId\":null,\"customerType\":null,\"accountType\":null,\"globalId\":null,\"bbpIntent\":null,\"clientAppName\":\"VZW-ECOM\",\"cartId\":\"15eccfe3-574e-402a-91b4-11c669769d2b\",\"caseId\":\"SOP-7676963-C01\",\"accountNumber\":\"0219838656-00001\",\"cartCreator\":\"5126807507\",\"processingMTN\":\"5126808210\",\"buyOutFlag\":\"Y\",\"buyOutSelected\":\"Y\",\"edgeUpSelected\":\"N\",\"processStep\":\"DPPSummary\",\"intendType\":\"EUP\",\"isQuoteCart\":null,\"processAction\":\"addBuyoutAmtAndDevice\",\"mtnFlow\":\"G\",\"fetchDataFromRedis\":null,\"editDevice\":null,\"showICPage\":null,\"isSmartLocator\":null,\"triggerPricingValidation\":null,\"barCodeIds\":[],\"isGemini\":null,\"isTradeInSelected\":null,\"expressCheckout\":null,\"replaceDevice\":null,\"amRole\":\"accountManager\",\"cradleFlowJourney\":null,\"activateSwitchFlow\":null,\"adobeId\":null,\"referralVendorId\":null,\"ecpdToken\":null,\"rylEcpdUrl\":null,\"referralSaleRepId\":null,\"zipCode\":null,\"disableMyLink\":null,\"authorizedUser\":null,\"cartCreatorSalesRepId\":null,\"fiveGMUCEligible\":null,\"customerConsent\":null},\"data\":{\"recommDevId\":null,\"recommSkuId\":null,\"rtm\":null,\"lines\":[{\"preBackOrderDate\":null,\"preBackOrderDisplayType\":null,\"rebateUpdate\":null,\"instantcredit\":null,\"mldTrunkMtn\":null,\"rtdOfferId\":null,\"restricted\":null,\"restrictedProductType\":null,\"selectedSedOfferId\":null,\"selectedSpoId\":null,\"reasonCode\":null,\"lineActivityType\":null,\"currentPlanType\":null,\"barCodeId\":null,\"inEligibleReason\":null,\"sellerPrice\":null,\"nickName\":null,\"purchasePath\":\"\",\"donorMtn\":null,\"selectedPromoType\":\"NOPROMO\",\"selectedPromoId\":\"\",\"giftBox\":null,\"idu\":null,\"eupNoPromoFlow\":false,\"accountOwner\":null,\"mtn\":\"5126808210\",\"trialSelected\":null, \"rtdOfferId\":\"345\",\"restricted\":\"Y\",\"subscriptionSelected\":null,\"trialAllowance\":null,\"trialValidityPeriod\":null,\"device\":{\"cartItemType\":null,\"quantityOnHand\":null,\"upgradeReasonCode\":null,\"warningMessage\":null,\"connectedCarMobile\":null,\"connectedCarColor\":null,\"category\":\"Smartphones\",\"giftbox\":null,\"connectedCarDetails\":null,\"refundType\":null,\"id\":\"MLAR3LL/A\",\"dppMonths\":36,\"contractTerm\":\"VERIZON_EDGE\",\"qty\":1,\"fiveGToFourGDownGrade\":null,\"productId\":\"dev16720001\",\"iconicPhone\":true,\"preconfigure\":\"false\",\"token\":null},\"sim\":{\"id\":\"EMBD4GSIM-N\",\"imei2\":null},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"isEdgeBuyOut\":true,\"triggerPricingValidation\":null,\"tabletJetPackDiscountIncluded\":null,\"fiveGUpSell\":null,\"is5GBoltEligible\":null,\"devicePlanCompatible\":null,\"activateLater\":null,\"setUpLater\":null,\"selectedEUPDeviceForBYOD\":null,\"promoRejectionIndicator\":true,\"unpairDevice\":null,\"tradeInInfo\":null,\"editSim\":null,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"selectedOffers\":[{\"subType\":\"Trade\",\"id\":\"1234\"},{\"subType\":\"test\",\"id\":\"12345\"}]}],\"mtnSOIRecommendation\":null,\"totalDeviceDollar\":null,\"selectedMtn\":null},\"channelId\":\"OMNI-RETAIL\"}";
		AddDeviceUIRequest request3 = mapper.readValue(sampleUIRequestString3,AddDeviceUIRequest.class);
		CartPegaRequestUtil4.formatAddDeviceRequest(pegareq,request3,null,true,false, false, getFFlag());
		StepVerifier.create(Mono.just(pegareq))
				.assertNext(req -> Assert.assertNotNull(pegareq.getServiceBody().getServiceRequest().getContext().getCartInfo()))
				.expectComplete().verify();
		String sampleUIRequestString4 = "{\"validateCartRequest\":null,\"preConfigured\":null,\"externalId\":\"testExternalId\",\"vzId\":\"testvzId\",\"path\":null,\"cartInfo\":{\"editDeviceConfiguratorClick\":null,\"editPlanClick\":null,\"specialItemType\":null,\"rpsIntent\":\"test\",\"sessionId\":null,\"customerType\":null,\"accountType\":null,\"globalId\":null,\"bbpIntent\":null,\"activateSwitchFlow\":false,\"number_share_capable\":\"Y\",\"e911_addr_ind\":\"N\",\"specialItemType\":\"test\",\"editDeviceConfiguratorClick\":false,\"salesRepId\":\"test\",\"flowType\":\"EUP\",\"redemptionCode\":\"test\",\"authorizedUser\":{\"firstName\":\"test\",\"lastName\":\"test\"},\"totalDeviceDollar\":\"100.00\",\"isQuoteCart\":false,\"mtnFlow\":\"PromoBundle\",\"triggerPricingValidation\":false,\"clientAppName\":\"VZW-ECOM\",\"cartId\":\"15eccfe3-574e-402a-91b4-11c669769d2b\",\"caseId\":\"SOP-7676963-C01\",\"accountNumber\":\"0219838656-00001\",\"cartCreator\":\"5126807507\",\"processingMTN\":\"5126808210\",\"buyOutFlag\":\"Y\",\"buyOutSelected\":\"Y\",\"edgeUpSelected\":\"N\",\"processStep\":null,\"intendType\":\"CLNR\",\"processAction\":\"addBuyoutAmtAndDevice\",\"fetchDataFromRedis\":null,\"editDevice\":null,\"showICPage\":false,\"isSmartLocator\":false,\"triggerPricingValidation\":null,\"barCodeIds\":[{\"barCodeId\":\"test123\"}],\"isGemini\":false,\"isTradeInSelected\":null,\"expressCheckout\":null,\"replaceDevice\":false,\"amRole\":\"accountManager\",\"cradleFlowJourney\":null,\"adobeId\":null,\"referralVendorId\":null,\"ecpdToken\":null,\"rylEcpdUrl\":null,\"referralSaleRepId\":null,\"zipCode\":null,\"disableMyLink\":null,\"cartCreatorSalesRepId\":null,\"customerConsent\":null,\"iconicTestIntent\":\"test\",\"fiveGMUCEligible\":\"test\"},\"data\":{\"recommDevId\":null,\"recommSkuId\":null,\"rtm\":null,\"expressCheckout\":true,\"lines\":[{\"preBackOrderDate\":null,\"preBackOrderDisplayType\":null,\"rebateUpdate\":null,\"instantcredit\":null,\"mldTrunkMtn\":\"9876567896\",\"rtdOfferId\":\"test\",\"restricted\":\"test\",\"restrictedProductType\":\"test\",\"selectedSedOfferId\":\"test\",\"selectedSpoId\":null,\"reasonCode\":null,\"lineActivityType\":null,\"currentPlanType\":null,\"barCodeId\":\"test123\",\"inEligibleReason\":null,\"sellerPrice\":\"200.00\",\"nickName\":null,\"purchasePath\":\"\",\"donorMtn\":null,\"selectedPromoType\":\"NOPROMO\",\"selectedPromoId\":\"test\",\"giftBox\":{\"id\":\"123\",\"deviceId\":\"34567898765\"},\"idu\":{\"id\":\"123\",\"deviceId\":\"34567898765\"},\"eupNoPromoFlow\":false,\"accountOwner\":null,\"mtn\":\"5126808210\",\"trialSelected\":null, \"rtdOfferId\":\"345\",\"restricted\":\"Y\",\"subscriptionSelected\":null,\"trialAllowance\":null,\"trialValidityPeriod\":null,\"device\":{\"cartItemType\":null,\"quantityOnHand\":null,\"upgradeReasonCode\":null,\"warningMessage\":null,\"connectedCarMobile\":null,\"connectedCarColor\":null,\"category\":\"Smartphones\",\"giftbox\":null,\"connectedCarDetails\":null,\"refundType\":null,\"id\":\"MLAR3LL/A\",\"dppMonths\":36,\"contractTerm\":\"VERIZON_EDGE\",\"qty\":1,\"fiveGToFourGDownGrade\":null,\"productId\":\"dev16720001\",\"iconicPhone\":true,\"preconfigure\":\"false\",\"token\":null},\"sim\":{\"id\":\"EMBD4GSIM-N\",\"imei2\":null},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":true,\"isEdgeBuyOut\":true,\"triggerPricingValidation\":null,\"tabletJetPackDiscountIncluded\":null,\"fiveGUpSell\":null,\"is5GBoltEligible\":null,\"devicePlanCompatible\":null,\"activateLater\":null,\"promoRejectionIndicator\":true,\"unpairDevice\":false,\"tradeInInfo\":{\"deviceBrand\":\"test\",\"deviceModel\":\"test\",\"tradeinMarketingId\":\"4201\"},\"editSim\":null,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":true,\"selectedOffers\":[{\"subType\":\"Trade\",\"id\":\"1234\"},{\"subType\":\"test\",\"id\":\"12345\"}],\"lineDeviceDollar\":\"50.00\",\"upgradeReasonCode\":\"test\",\"trunkMtn\":\"9997865434\",\"currentPairingModeChanged\":false,\"numbersharePairingMode\":\"test\",\"isStrategicOffer\":false,\"edgeup\":{\"deviceId\":\"3456788764444\",\"deviceMismatch\":\"test\"},\"downPayment\":{\"amount\":\"100.00\"},\"PreBackOrderDate\":\"2022-08-12\",\"setUpLater\":false,\"selectedEUPDeviceForBYOD\":false,\"customerProvidedMtn\":\"8765678767\",\"customerProvidedMtnType\":\"test\",\"lineCreatorChannel\":\"test\"}],\"mtnSOIRecommendation\":null,\"totalDeviceDollar\":\"100.00\",\"selectedMtn\":null},\"channelId\":\"OMNI-INDIRECT\"}";
		AddDeviceUIRequest request4 = mapper.readValue(sampleUIRequestString4,AddDeviceUIRequest.class);
		CartPegaRequestUtil4.formatAddDeviceRequest(pegareq,request4,null,true,false, false, getFFlag());
		StepVerifier.create(Mono.just(pegareq))
				.assertNext(req -> Assert.assertNotNull(pegareq.getServiceBody().getServiceRequest().getContext().getCartInfo()))
				.expectComplete().verify();
	}

	public void formatAddDeviceRequestTestForNSEIntent() throws JsonProcessingException {
		String sampleUIRequestString = "{\"validateCartRequest\":null,\"preConfigured\":null,\"externalId\":null,\"vzId\":null,\"path\":null,\"cartInfo\":{\"editDeviceConfiguratorClick\":null,\"editPlanClick\":null,\"specialItemType\":null,\"salesRepId\":null,\"flowType\":null,\"rpsIntent\":null,\"sessionId\":null,\"customerType\":null,\"accountType\":null,\"globalId\":null,\"bbpIntent\":null,\"clientAppName\":\"VZW-ECOM\",\"cartId\":\"15eccfe3-574e-402a-91b4-11c669769d2b\",\"caseId\":\"SOP-7676963-C01\",\"accountNumber\":\"0219838656-00001\",\"cartCreator\":\"5126807507\",\"processingMTN\":\"5126808210\",\"buyOutFlag\":\"Y\",\"buyOutSelected\":\"Y\",\"edgeUpSelected\":\"N\",\"processStep\":\"DPPSummary\",\"isQuoteCart\":null,\"processAction\":\"addBuyoutAmtAndDevice\",\"intendType\":\"NSE\",\"mtnFlow\":\"G\",\"fetchDataFromRedis\":null,\"editDevice\":null,\"showICPage\":null,\"isSmartLocator\":null,\"triggerPricingValidation\":null,\"barCodeIds\":[],\"isGemini\":null,\"isTradeInSelected\":null,\"expressCheckout\":null,\"replaceDevice\":null,\"amRole\":\"accountManager\",\"cradleFlowJourney\":null,\"activateSwitchFlow\":null,\"adobeId\":null,\"referralVendorId\":null,\"ecpdToken\":null,\"rylEcpdUrl\":null,\"referralSaleRepId\":null,\"zipCode\":null,\"disableMyLink\":null,\"authorizedUser\":null,\"cartCreatorSalesRepId\":null,\"fiveGMUCEligible\":null,\"customerConsent\":null},\"data\":{\"recommDevId\":null,\"recommSkuId\":null,\"rtm\":null,\"lines\":[{\"preBackOrderDate\":null,\"preBackOrderDisplayType\":null,\"rebateUpdate\":null,\"instantcredit\":null,\"mldTrunkMtn\":null,\"rtdOfferId\":null,\"restricted\":null,\"restrictedProductType\":null,\"selectedSedOfferId\":null,\"selectedSpoId\":null,\"reasonCode\":null,\"lineActivityType\":null,\"currentPlanType\":null,\"barCodeId\":null,\"inEligibleReason\":null,\"sellerPrice\":null,\"nickName\":null,\"purchasePath\":\"\",\"donorMtn\":null,\"selectedPromoType\":\"NOPROMO\",\"selectedPromoId\":\"\",\"giftBox\":null,\"idu\":null,\"eupNoPromoFlow\":false,\"accountOwner\":null,\"mtn\":\"5126808210\",\"trialSelected\":null, \"rtdOfferId\":\"345\",\"restricted\":\"Y\",\"subscriptionSelected\":null,\"trialAllowance\":null,\"trialValidityPeriod\":null,\"device\":{\"cartItemType\":null,\"quantityOnHand\":null,\"upgradeReasonCode\":null,\"networkBandwidthType\":\"CBD\",\"warningMessage\":null,\"connectedCarMobile\":null,\"connectedCarColor\":null,\"category\":\"Smartphones\",\"giftbox\":null,\"connectedCarDetails\":null,\"refundType\":null,\"id\":\"MLAR3LL/A\",\"dppMonths\":36,\"contractTerm\":\"VERIZON_EDGE\",\"qty\":1,\"fiveGToFourGDownGrade\":null,\"productId\":\"dev16720001\",\"iconicPhone\":true,\"preconfigure\":\"false\",\"token\":null},\"sim\":{\"id\":\"EMBD4GSIM-N\",\"imei2\":null},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"isEdgeBuyOut\":true,\"triggerPricingValidation\":null,\"tabletJetPackDiscountIncluded\":null,\"fiveGUpSell\":null,\"is5GBoltEligible\":null,\"devicePlanCompatible\":null,\"activateLater\":null,\"setUpLater\":null,\"selectedEUPDeviceForBYOD\":null,\"promoRejectionIndicator\":true,\"unpairDevice\":null,\"tradeInInfo\":null,\"editSim\":null,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"selectedOffers\":[{\"subType\":\"Trade\",\"id\":\"1234\"},{\"subType\":\"test\",\"id\":\"12345\"}]}],\"mtnSOIRecommendation\":null,\"totalDeviceDollar\":null,\"selectedMtn\":null},\"channelId\":\"OMNI-RETAIL\"}";
		AddDeviceUIRequest request = mapper.readValue(sampleUIRequestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest pegareq = new AddDevicePEGARequest();
		CartPegaRequestUtil4.formatAddDeviceRequest(pegareq, request, null,true,true, true, getFFlag());
		StepVerifier.create(Mono.just(pegareq))
				.assertNext(req -> Assert.assertNotNull(pegareq.getServiceBody().getServiceRequest().getContext().getCartInfo()))
				.expectComplete().verify();

		String sampleUIRequestStringNwbdt = "{\"validateCartRequest\":null,\"preConfigured\":null,\"externalId\":null,\"vzId\":null,\"path\":null,\"cartInfo\":{\"editDeviceConfiguratorClick\":null,\"editPlanClick\":null,\"specialItemType\":null,\"salesRepId\":null,\"flowType\":null,\"rpsIntent\":null,\"sessionId\":null,\"customerType\":null,\"accountType\":null,\"globalId\":null,\"bbpIntent\":null,\"clientAppName\":\"VZW-ECOM\",\"cartId\":\"15eccfe3-574e-402a-91b4-11c669769d2b\",\"caseId\":\"SOP-7676963-C01\",\"accountNumber\":\"0219838656-00001\",\"cartCreator\":\"5126807507\",\"processingMTN\":\"5126808210\",\"buyOutFlag\":\"Y\",\"buyOutSelected\":\"Y\",\"edgeUpSelected\":\"N\",\"processStep\":\"DPPSummary\",\"isQuoteCart\":null,\"processAction\":\"addBuyoutAmtAndDevice\",\"intendType\":\"NSE\",\"mtnFlow\":\"G\",\"fetchDataFromRedis\":null,\"editDevice\":null,\"showICPage\":null,\"isSmartLocator\":null,\"triggerPricingValidation\":null,\"barCodeIds\":[],\"isGemini\":null,\"isTradeInSelected\":null,\"expressCheckout\":null,\"replaceDevice\":null,\"amRole\":\"accountManager\",\"cradleFlowJourney\":null,\"activateSwitchFlow\":null,\"adobeId\":null,\"referralVendorId\":null,\"ecpdToken\":null,\"rylEcpdUrl\":null,\"referralSaleRepId\":null,\"zipCode\":null,\"disableMyLink\":null,\"authorizedUser\":null,\"cartCreatorSalesRepId\":null,\"fiveGMUCEligible\":null,\"customerConsent\":null},\"data\":{\"recommDevId\":null,\"recommSkuId\":null,\"rtm\":null,\"lines\":[{\"preBackOrderDate\":null,\"preBackOrderDisplayType\":null,\"rebateUpdate\":null,\"instantcredit\":null,\"mldTrunkMtn\":null,\"rtdOfferId\":null,\"restricted\":null,\"restrictedProductType\":null,\"selectedSedOfferId\":null,\"selectedSpoId\":null,\"reasonCode\":null,\"lineActivityType\":null,\"currentPlanType\":null,\"barCodeId\":null,\"inEligibleReason\":null,\"sellerPrice\":null,\"nickName\":null,\"purchasePath\":\"\",\"donorMtn\":null,\"selectedPromoType\":\"NOPROMO\",\"selectedPromoId\":\"\",\"giftBox\":null,\"idu\":null,\"eupNoPromoFlow\":false,\"accountOwner\":null,\"mtn\":\"5126808210\",\"trialSelected\":null, \"rtdOfferId\":\"345\",\"restricted\":\"Y\",\"subscriptionSelected\":null,\"trialAllowance\":null,\"trialValidityPeriod\":null,\"device\":{\"cartItemType\":null,\"quantityOnHand\":null,\"upgradeReasonCode\":null,\"warningMessage\":null,\"connectedCarMobile\":null,\"connectedCarColor\":null,\"category\":\"Smartphones\",\"giftbox\":null,\"connectedCarDetails\":null,\"refundType\":null,\"id\":\"MLAR3LL/A\",\"dppMonths\":36,\"contractTerm\":\"VERIZON_EDGE\",\"qty\":1,\"fiveGToFourGDownGrade\":null,\"productId\":\"dev16720001\",\"iconicPhone\":true,\"preconfigure\":\"false\",\"token\":null},\"sim\":{\"id\":\"EMBD4GSIM-N\",\"imei2\":null},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"isEdgeBuyOut\":true,\"triggerPricingValidation\":null,\"tabletJetPackDiscountIncluded\":null,\"fiveGUpSell\":null,\"is5GBoltEligible\":null,\"devicePlanCompatible\":null,\"activateLater\":null,\"setUpLater\":null,\"selectedEUPDeviceForBYOD\":null,\"promoRejectionIndicator\":true,\"unpairDevice\":null,\"tradeInInfo\":null,\"editSim\":null,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"selectedOffers\":[{\"subType\":\"Trade\",\"id\":\"1234\"},{\"subType\":\"test\",\"id\":\"12345\"}]}],\"mtnSOIRecommendation\":null,\"totalDeviceDollar\":null,\"selectedMtn\":null},\"channelId\":\"OMNI-RETAIL\"}";
		AddDeviceUIRequest request1 = mapper.readValue(sampleUIRequestStringNwbdt, AddDeviceUIRequest.class);
		AddDevicePEGARequest pegareq1 = new AddDevicePEGARequest();
		CartPegaRequestUtil4.formatAddDeviceRequest(pegareq1, request1, null,true,false, true, getFFlag());
		StepVerifier.create(Mono.just(pegareq1))
				.assertNext(req -> Assert.assertNotNull(pegareq1.getServiceBody().getServiceRequest().getContext().getCartInfo()))
				.expectComplete().verify();
	}

	@Test
	public void formatHeadersTest() throws JsonMappingException, JsonProcessingException {
		String uiRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"accountNumber\": \"12345\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"PromoHub\",\"intendType\": \"NSE\",\"mtnFlow\": \"mtnFlow\",\"scheduleOrder\": true,\"cartId\": \"cartId\",\"saveCartEmailId\": \"saveCartEmailId@verizon.com\",\"storeName\": \"store\",\"loggedInUser\": \"loggedInUser\",\"repId\": \"repId\",\"processAction\": \"processAction\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"creditAppNum\",\"emailId\": \"sanchit.goyal@verizon.com\",\"expressCheckout\": true,\"cartSavedByCustomer\": true,\"isDirectApply\": true},\"data\": {\"email\": \"sanchit.goyal@verizon.com\",\"customerName\": \"Name\",\"createLead\": true,\"updateLead\": {\"leadOwner\": \"leadOwner\",\"leadOwnerName\": \"ownerName\",\"isMobileNumber\": true,\"cartDetails\": [],\"addressInfo\": {\"state\": \"state\",\"city\": \"city\",\"addressLine1\": \"addressLine1\",\"addressLine2\": \"addressLine2\"},\"eCode\": \"eCode\"},\"quoteId\": \"quoteId\",\"zipCode\": \"33097\",\"compareQuotePdfEnabled\": true,\"quoteLowerBillEnabled\": true,\"viewQrCode\": true},\"safeTechSessionId\": \"safeTechSessionId\",\"globalId\": \"globalId\",\"enforceData\": null}";
		SaveCartPEGARequest pegaRequest = new SaveCartPEGARequest();
		SaveCartUIRequest uiRequest = mapper.readValue(uiRequestString, SaveCartUIRequest.class);
		URI url = URI.create("http://localhost/nse/saveCart");
		MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		uiRequest.setHttpRequest(httpRequest);
		EnforceData data = new EnforceData();
		data.setCookieStatus("cookieStatus");
		data.setTouchSupport("touchSupport");
		uiRequest.setEnforceData(data);
		SaveCartPEGARequest response = CartPegaRequestUtil.formatSaveCartRequest(pegaRequest, uiRequest);
		Assert.assertTrue(response.getServiceBody().getServiceRequest().getContext().getCartInfo().getCartSavedByCustomer());
	}

	@Test
	public void formatSaveCartForLaterRequestTest() throws JsonMappingException, JsonProcessingException, IOException {
		String pegaRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"accountNumber\": \"12345\",\"cartCreator\": \"1234567\",\"processingMTN\": \"98765432\",\"processStep\": \"PromoHub\",\"intendType\": \"NSE\",\"mtnFlow\": \"mtnFlow\",\"scheduleOrder\": true,\"cartId\": \"cartId\",\"saveCartEmailId\": \"saveCartEmailId@verizon.com\",\"storeName\": \"store\",\"loggedInUser\": \"loggedInUser\",\"repId\": \"repId\",\"processAction\": \"processAction\",\"clientAppName\": \"clientAppName\",\"creditAppNum\": \"creditAppNum\",\"emailId\": \"sanchit.goyal@verizon.com\",\"expressCheckout\": true,\"cartSavedByCustomer\": true,\"isDirectApply\": true},\"data\": {\"email\": \"sanchit.goyal@verizon.com\",\"customerName\": \"Name\",\"createLead\": true,\"updateLead\": {\"leadOwner\": \"leadOwner\",\"leadOwnerName\": \"ownerName\",\"isMobileNumber\": true,\"cartDetails\": [],\"addressInfo\": {\"state\": \"state\",\"city\": \"city\",\"addressLine1\": \"addressLine1\",\"addressLine2\": \"addressLine2\"},\"eCode\": \"eCode\"},\"quoteId\": \"quoteId\",\"zipCode\": \"33097\",\"compareQuotePdfEnabled\": true,\"quoteLowerBillEnabled\": true,\"viewQrCode\": true},\"safeTechSessionId\": \"safeTechSessionId\",\"globalId\": \"globalId\",\"enforceData\": null}";
		SaveCartPEGARequest pegaRequest = mapper.readValue(pegaRequestString, SaveCartPEGARequest.class);
		String sampleUIRequestString = "{ \"cartInfo\": { \"cartId\": \"\", \"caseId\": \"\", \"accountNumber\": \"\", \"cartCreator\": \"\", \"processingMTN\": \"\", \"itemType\": \"SAVE-FOR-LATER\", \"processStep\": \"PromoHub\", \"processAction\": \"deleteSaveForLater\", \"intendType\": \"AAL\", \"intent\": \"AAL\" }, \"data\": { \"lines\": [{ \"mtn\": \"newLine1\" }] }, \"expressCheckout\": \"true\" }";
		SaveCartForLaterUIRequest uiRequest = mapper.readValue(sampleUIRequestString, SaveCartForLaterUIRequest.class);
		try {
			SaveCartPEGARequest response = CartPegaRequestUtil6.formatSaveCartForLaterRequest(pegaRequest, uiRequest);
		Assert.assertNull(response.getServiceBody().getServiceRequest().getContext().getCartInfo().getCartSavedByCustomer());
		}
		catch (NullPointerException e) {
            e.printStackTrace();
		}
	}

	@Test
	public void isXboxInClearCartRequestFalseTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"281d6efa-bd6f-4e81-a531-39be26d68abb\",\"caseId\":\"SOP-8142935-C01\",\"cartCreator\":\"3155259529\",\"processingMTN\":\"3155259529\",\"expressCheckout\":\"\",\"processStep\":\"DPPSummary\",\"intendType\":\"EUP\"}}";
		ClearCartUIRequest request = mapper.readValue(requestString, ClearCartUIRequest.class);
		boolean response = CartPegaRequestUtil9.isXboxInClearCartRequest(request);
		Assert.assertFalse(response);
	}

	@Test
	public void addAccessoryXboxCashOptionEnabledTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"editAccessory\":false,\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"AccessoryPDP\",\"processAction\":\"addAccessoryAndCheckout\",\"intendType\":\"ACC\",\"intent\":\"StandAloneAccessory\",\"expressflowForAcc\":true,\"expressCheckout\":false,\"subscriptionType\":\"GAMINGCONSOLE\"},\"data\":{\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"\",\"mdnFilterValue\":\"\",\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"preBackOrderDate\":\"\",\"preBackOrderDisplayType\":\"\",\"addAccessories\":[{\"giftCard\":false,\"id\":\"RRT-00001\",\"qty\":1,\"isSoftSku\":false,\"accessoryBundle\":false,\"productId\":\"acc18040009\",\"category\":\"Gaming\",\"isEcpdDiscountEligilble\":false,\"cashOptionEnabled\":true}]}],\"rtm\":{\"url\":\"https://vzwqa1.verizonwireless.com/products/xbox-console-series-x/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/microsoft-xbox-w-controller-a-a?fmt=pjpg\",\"name\":\"All Access - Series X Console\",\"make\":\"Xbox\",\"categoryId\":\"Gaming\",\"pageURL\":\"https://vzwqa1.verizonwireless.com/products/xbox-all-access-series-x-console/\",\"acc_url\":\"https://vzwqa1.verizonwireless.com/products/xbox-console-series-x/\",\"acc_img\":\"https://ss7.vzw.com/is/image/VerizonWireless/microsoft-xbox-w-controller-a-a?fmt=pjpg\",\"acc_categoryId\":\"Gaming\"}}}";
        AddAccessoriesUIRequest UIRequest = new AddAccessoriesUIRequest();
        AddAccessoryPEGARequest pegaRequest = new AddAccessoryPEGARequest();
		UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
		CartPegaRequestUtil3.formatAddAccessoriesRequest(pegaRequest, UIRequest, "", true);
		Assert.assertTrue(pegaRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getAccessories().getAdd()[0].isCashOptionEnabled());
	}
	@Test
	public void formatUpdateBarCodeRequestForPrepayTest() throws JsonMappingException, JsonProcessingException {
		 String updateBarcodeUIRequestString="{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"52162a02-4c30-4f00-8a19-4cfc434daa2d\",\"caseId\":\"SOF-14766581-E01\",\"accountNumber\":\"A56162213783\",\"cartCreator\":\"\",\"intendType\":\"BYOD\",\"processingMTN\":\"\",\"processStep\":\"ShoppingCart\",\"barCodeIds\":[{\"barCodeId\":\"UATTSTABCD00014001\"}],\"creditAppNum\":\"\"},\"data\":{\"includeExpiryBarcodeStatus\":\"Y\",\"lines\":[{\"mtn\":\"77535345345\"}]}}";
		UpdateBarCodePEGARequest pegaRequest = new UpdateBarCodePEGARequest();
		UpdateBarcodeUIRequest uiRequest = mapper.readValue(updateBarcodeUIRequestString, UpdateBarcodeUIRequest.class);
		UpdateBarCodePEGARequest response = CartPegaRequestUtil.formatUpdateBarCodeRequest(pegaRequest, uiRequest, "");
		Assert.assertNotNull(response);
	}

	@Test
	public void formatInitiateValidateDeviceSimWithHeadersTestChannelId() throws IOException {
		//TestConfig gwConfig = getData(CartServiceTestConstants.ADD_ACCESSORY_PATH, "add-plan-5ghome");
		String sampleUIRequestString = "{\"data\":{\"postPaidInd\":\"Y\",\"processStep\":\"\",\"processAction\":\"initiateValidateDeviceSim\",\"intendType\":\"BYOD\",\"isConnectedCarRequired\":true}}";
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"bbpImei\": \"8436667390\",\"bbpIccid\":\"89148000005148869944\" }";
		//String sampleUIRequestString = gwConfig.getRequest();
		InitiateValidateDeviceSimUIRequest UIRequest = new InitiateValidateDeviceSimUIRequest();
		InitiateValidateDeviceSimPEGARequest pegaRequest = new InitiateValidateDeviceSimPEGARequest();
		CartRedisData sampleRedisData = new CartRedisData();
		UIRequest = mapper.readValue(sampleUIRequestString, InitiateValidateDeviceSimUIRequest.class);
		sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, "http://localhost/initiateValidateDeviceSim").header("channelId", "VZW-DOTCOM-BBP").build();
		CartPegaRequestUtil8.formatInitiateValidateDeviceSimRequest(pegaRequest, UIRequest, httpHeader, sampleRedisData);
		StepVerifier.create(Mono.just(pegaRequest))
				.assertNext(req -> Assert.assertNotNull(pegaRequest))
				.expectComplete().verify();
	}

	@Test
	public void formatAddDeviceRequestForEsimTestBBP() throws IOException{
		String sampleUIRequestString = "{\"validateCartRequest\":null,\"preConfigured\":null,\"externalId\":null,\"vzId\":null,\"path\":null,\"cartInfo\":{\"editDeviceConfiguratorClick\":null,\"editPlanClick\":null,\"specialItemType\":null,\"salesRepId\":null,\"flowType\":null,\"rpsIntent\":null,\"sessionId\":null,\"customerType\":null,\"accountType\":null,\"globalId\":null,\"bbpIntent\":null,\"clientAppName\":\"VZW-DOTCOM-BBP\",\"cartId\":\"15eccfe3-574e-402a-91b4-11c669769d2b\",\"caseId\":\"SOP-7676963-C01\",\"accountNumber\":\"0219838656-00001\",\"cartCreator\":\"5126807507\",\"processingMTN\":\"5126808210\",\"buyOutFlag\":\"Y\",\"buyOutSelected\":\"Y\",\"edgeUpSelected\":\"N\",\"processStep\":\"DPPSummary\",\"intendType\":\"EUP\",\"isQuoteCart\":null,\"processAction\":\"addBuyoutAmtAndDevice\",\"mtnFlow\":\"G\",\"fetchDataFromRedis\":null,\"editDevice\":null,\"showICPage\":null,\"isSmartLocator\":null,\"triggerPricingValidation\":null,\"barCodeIds\":[],\"isGemini\":null,\"isTradeInSelected\":null,\"expressCheckout\":null,\"replaceDevice\":null,\"amRole\":\"accountManager\",\"cradleFlowJourney\":null,\"activateSwitchFlow\":null,\"adobeId\":null,\"referralVendorId\":null,\"ecpdToken\":null,\"rylEcpdUrl\":null,\"referralSaleRepId\":null,\"zipCode\":null,\"disableMyLink\":null,\"authorizedUser\":null,\"cartCreatorSalesRepId\":null,\"fiveGMUCEligible\":null,\"customerConsent\":null},\"data\":{\"esimType\":\"IPAD\",\"recommDevId\":null,\"recommSkuId\":null,\"rtm\":null,\"lines\":[{\"preBackOrderDate\":null,\"preBackOrderDisplayType\":null,\"rebateUpdate\":null,\"instantcredit\":null,\"mldTrunkMtn\":null,\"rtdOfferId\":null,\"restricted\":null,\"restrictedProductType\":null,\"selectedSedOfferId\":null,\"selectedSpoId\":null,\"reasonCode\":null,\"lineActivityType\":null,\"currentPlanType\":null,\"barCodeId\":null,\"inEligibleReason\":null,\"sellerPrice\":null,\"nickName\":null,\"purchasePath\":\"AccountGrowth\",\"donorMtn\":null,\"selectedPromoType\":\"NOPROMO\",\"selectedPromoId\":\"\",\"giftBox\":null,\"idu\":null,\"eupNoPromoFlow\":false,\"accountOwner\":null,\"mtn\":\"5126808210\",\"trialSelected\":null, \"rtdOfferId\":\"345\",\"restricted\":\"Y\",\"subscriptionSelected\":null,\"trialAllowance\":null,\"trialValidityPeriod\":null,\"device\":{\"cartItemType\":null,\"quantityOnHand\":null,\"upgradeReasonCode\":null,\"warningMessage\":null,\"connectedCarMobile\":null,\"connectedCarColor\":null,\"category\":\"Smartphones\",\"giftbox\":null,\"connectedCarDetails\":null,\"refundType\":null,\"id\":\"MLAR3LL/A\",\"dppMonths\":36,\"contractTerm\":\"VERIZON_EDGE\",\"networkBandwidthType\":\"CBD\",\"qty\":1,\"fiveGToFourGDownGrade\":null,\"productId\":\"dev16720001\",\"iconicPhone\":true,\"preconfigure\":\"false\",\"token\":null},\"sim\":{\"id\":\"EMBD4GSIM-N\",\"imei2\":null},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"isEdgeBuyOut\":true,\"triggerPricingValidation\":null,\"tabletJetPackDiscountIncluded\":null,\"fiveGUpSell\":null,\"is5GBoltEligible\":null,\"devicePlanCompatible\":null,\"activateLater\":null,\"setUpLater\":null,\"selectedEUPDeviceForBYOD\":null,\"promoRejectionIndicator\":true,\"unpairDevice\":null,\"tradeInInfo\":null,\"editSim\":null,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false}],\"mtnSOIRecommendation\":null,\"totalDeviceDollar\":null,\"selectedMtn\":null},\"channelId\":\"VZW-DOTCOM\"}";
		AddDeviceUIRequest request = mapper.readValue(sampleUIRequestString,AddDeviceUIRequest.class);
		request.setChannelId("VZW-DOTCOM-BBP");
		request.getCartInfo().setIntendType("NSEBYOD");
		request.getData().getLines().get(0).getDevice().setByodESimPhone(Boolean.TRUE);
		AddDevicePEGARequest pegareq = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(),request,null,true,false, false, getFFlag());
		StepVerifier.create(Mono.just(pegareq))
				.assertNext(req -> Assert.assertNotNull(pegareq.getServiceBody().getServiceRequest().getContext().getCartInfo()))
				.expectComplete().verify();
	}

	@Test
	public void formatAddDeviceRequestComboTest() throws IOException{
		String sampleUIRequestString = "{\"validateCartRequest\":null,\"preConfigured\":null,\"externalId\":null,\"vzId\":null,\"path\":null,\"cartInfo\":{\"editDeviceConfiguratorClick\":null,\"editPlanClick\":null,\"specialItemType\":null,\"salesRepId\":null,\"flowType\":null,\"rpsIntent\":null,\"sessionId\":null,\"customerType\":null,\"accountType\":null,\"globalId\":null,\"bbpIntent\":null,\"clientAppName\":\"VZW-ECOM\",\"cartId\":\"15eccfe3-574e-402a-91b4-11c669769d2b\",\"caseId\":\"SOP-7676963-C01\",\"accountNumber\":\"0219838656-00001\",\"cartCreator\":\"5126807507\",\"processingMTN\":\"5126808210\",\"buyOutFlag\":\"Y\",\"buyOutSelected\":\"Y\",\"edgeUpSelected\":\"N\",\"processStep\":\"DPPSummary\",\"intendType\":\"NSEBYOD\",\"cradleFlowJourney\":\"NEXTGEN\",\"isQuoteCart\":null,\"processAction\":\"addBuyoutAmtAndDevice\",\"mtnFlow\":\"G\",\"fetchDataFromRedis\":null,\"editDevice\":null,\"showICPage\":null,\"isSmartLocator\":null,\"triggerPricingValidation\":null,\"barCodeIds\":[],\"isGemini\":null,\"isTradeInSelected\":null,\"expressCheckout\":null,\"replaceDevice\":null,\"amRole\":\"accountManager\",\"cradleFlowJourney\":null,\"activateSwitchFlow\":null,\"adobeId\":null,\"referralVendorId\":null,\"ecpdToken\":null,\"rylEcpdUrl\":null,\"referralSaleRepId\":null,\"zipCode\":null,\"disableMyLink\":null,\"authorizedUser\":null,\"cartCreatorSalesRepId\":null,\"fiveGMUCEligible\":null,\"customerConsent\":null},\"data\":{\"recommDevId\":null,\"recommSkuId\":null,\"rtm\":null,\"lines\":[{\"preBackOrderDate\":null,\"preBackOrderDisplayType\":null,\"rebateUpdate\":null,\"instantcredit\":null,\"mldTrunkMtn\":null,\"rtdOfferId\":null,\"restricted\":null,\"restrictedProductType\":null,\"selectedSedOfferId\":null,\"selectedSpoId\":null,\"reasonCode\":null,\"lineActivityType\":null,\"currentPlanType\":null,\"barCodeId\":null,\"inEligibleReason\":null,\"sellerPrice\":null,\"nickName\":null,\"purchasePath\":\"AccountGrowth\",\"donorMtn\":null,\"selectedPromoType\":\"NOPROMO\",\"selectedPromoId\":\"\",\"giftBox\":null,\"idu\":null,\"eupNoPromoFlow\":false,\"accountOwner\":null,\"mtn\":\"5126808210\",\"trialSelected\":null, \"rtdOfferId\":\"345\",\"restricted\":\"Y\",\"subscriptionSelected\":null,\"trialAllowance\":null,\"trialValidityPeriod\":null,\"device\":{\"cartItemType\":null,\"quantityOnHand\":null,\"upgradeReasonCode\":null,\"warningMessage\":null,\"connectedCarMobile\":null,\"connectedCarColor\":null,\"category\":\"Smartphones\",\"giftbox\":null,\"connectedCarDetails\":null,\"refundType\":null,\"id\":\"MLAR3LL/A\",\"dppMonths\":36,\"contractTerm\":\"VERIZON_EDGE\",\"qty\":1,\"fiveGToFourGDownGrade\":null,\"productId\":\"dev16720001\",\"iconicPhone\":true,\"preconfigure\":\"false\",\"token\":null},\"sim\":{\"id\":\"EMBD4GSIM-N\",\"imei2\":null},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"isEdgeBuyOut\":true,\"triggerPricingValidation\":null,\"tabletJetPackDiscountIncluded\":null,\"fiveGUpSell\":null,\"is5GBoltEligible\":null,\"devicePlanCompatible\":null,\"activateLater\":null,\"setUpLater\":null,\"selectedEUPDeviceForBYOD\":null,\"promoRejectionIndicator\":true,\"unpairDevice\":null,\"tradeInInfo\":null,\"editSim\":null,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false}],\"mtnSOIRecommendation\":null,\"totalDeviceDollar\":null,\"selectedMtn\":null},\"channelId\":\"VZW-DOTCOM\"}";
		AddDeviceUIRequest request = mapper.readValue(sampleUIRequestString,AddDeviceUIRequest.class);
		request.getCartInfo().setCradleFlowJourney("NEXTGEN");
		request.getCartInfo().setIsComboOrderAllowed(true);
		AddDevicePEGARequest pegareq = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(),request,null,true,false, false, getFFlag());
		StepVerifier.create(Mono.just(pegareq))
				.assertNext(req -> Assert.assertNotNull(pegareq.getServiceBody().getServiceRequest().getContext().getCartInfo()))
				.expectComplete().verify();
	}

	@Test
	public void formatAddDeviceRequestNonComboTest() throws IOException {
		String sampleUIRequestString = "{\"validateCartRequest\":null,\"preConfigured\":null,\"externalId\":null,\"vzId\":null,\"path\":null,\"cartInfo\":{\"editDeviceConfiguratorClick\":null,\"editPlanClick\":null,\"specialItemType\":null,\"salesRepId\":null,\"flowType\":null,\"rpsIntent\":null,\"sessionId\":null,\"customerType\":null,\"accountType\":null,\"globalId\":null,\"bbpIntent\":null,\"clientAppName\":\"VZW-ECOM\",\"cartId\":\"15eccfe3-574e-402a-91b4-11c669769d2b\",\"caseId\":\"SOP-7676963-C01\",\"accountNumber\":\"0219838656-00001\",\"cartCreator\":\"5126807507\",\"processingMTN\":\"5126808210\",\"buyOutFlag\":\"Y\",\"buyOutSelected\":\"Y\",\"edgeUpSelected\":\"N\",\"processStep\":\"DPPSummary\",\"intendType\":\"NSEBYOD\",\"cradleFlowJourney\":\"NEXTGEN\",\"isQuoteCart\":null,\"processAction\":\"addBuyoutAmtAndDevice\",\"mtnFlow\":\"G\",\"fetchDataFromRedis\":null,\"editDevice\":null,\"showICPage\":null,\"isSmartLocator\":null,\"triggerPricingValidation\":null,\"barCodeIds\":[],\"isGemini\":null,\"isTradeInSelected\":null,\"expressCheckout\":null,\"replaceDevice\":null,\"amRole\":\"accountManager\",\"cradleFlowJourney\":null,\"activateSwitchFlow\":null,\"adobeId\":null,\"referralVendorId\":null,\"ecpdToken\":null,\"rylEcpdUrl\":null,\"referralSaleRepId\":null,\"zipCode\":null,\"disableMyLink\":null,\"authorizedUser\":null,\"cartCreatorSalesRepId\":null,\"fiveGMUCEligible\":null,\"customerConsent\":null},\"data\":{\"recommDevId\":null,\"recommSkuId\":null,\"rtm\":null,\"lines\":[{\"preBackOrderDate\":null,\"preBackOrderDisplayType\":null,\"rebateUpdate\":null,\"instantcredit\":null,\"mldTrunkMtn\":null,\"rtdOfferId\":null,\"restricted\":null,\"restrictedProductType\":null,\"selectedSedOfferId\":null,\"selectedSpoId\":null,\"reasonCode\":null,\"lineActivityType\":null,\"currentPlanType\":null,\"barCodeId\":null,\"inEligibleReason\":null,\"sellerPrice\":null,\"nickName\":null,\"purchasePath\":\"AccountGrowth\",\"donorMtn\":null,\"selectedPromoType\":\"NOPROMO\",\"selectedPromoId\":\"\",\"giftBox\":null,\"idu\":null,\"eupNoPromoFlow\":false,\"accountOwner\":null,\"mtn\":\"5126808210\",\"trialSelected\":null, \"rtdOfferId\":\"345\",\"restricted\":\"Y\",\"subscriptionSelected\":null,\"trialAllowance\":null,\"trialValidityPeriod\":null,\"device\":{\"cartItemType\":null,\"quantityOnHand\":null,\"upgradeReasonCode\":null,\"warningMessage\":null,\"connectedCarMobile\":null,\"connectedCarColor\":null,\"category\":\"Smartphones\",\"giftbox\":null,\"connectedCarDetails\":null,\"refundType\":null,\"id\":\"MLAR3LL/A\",\"dppMonths\":36,\"contractTerm\":\"VERIZON_EDGE\",\"qty\":1,\"fiveGToFourGDownGrade\":null,\"productId\":\"dev16720001\",\"iconicPhone\":true,\"preconfigure\":\"false\",\"token\":null},\"sim\":{\"id\":\"EMBD4GSIM-N\",\"imei2\":null},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"isEdgeBuyOut\":true,\"triggerPricingValidation\":null,\"tabletJetPackDiscountIncluded\":null,\"fiveGUpSell\":null,\"is5GBoltEligible\":null,\"devicePlanCompatible\":null,\"activateLater\":null,\"setUpLater\":null,\"selectedEUPDeviceForBYOD\":null,\"promoRejectionIndicator\":true,\"unpairDevice\":null,\"tradeInInfo\":null,\"editSim\":null,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false}],\"mtnSOIRecommendation\":null,\"totalDeviceDollar\":null,\"selectedMtn\":null},\"channelId\":\"VZW-DOTCOM\"}";
		AddDeviceUIRequest request = mapper.readValue(sampleUIRequestString, AddDeviceUIRequest.class);
		request.getCartInfo().setCradleFlowJourney("NEXTGEN");
		request.getCartInfo().setIsComboOrderAllowed(false);
		AddDevicePEGARequest pegareq = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), request, null,true,false, false, getFFlag());
		StepVerifier.create(Mono.just(pegareq))
				.assertNext(req -> Assert.assertNotNull(pegareq.getServiceBody().getServiceRequest().getContext().getCartInfo()))
				.expectComplete().verify();
	}

	@Test
	public void addAccessorySetCartCreator() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"editAccessory\":false,\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"AccessoryPDP\",\"processAction\":\"addAccessoryAndCheckout\",\"intendType\":\"ACC\",\"intent\":\"StandAloneAccessory\",\"expressflowForAcc\":true,\"expressCheckout\":false,\"subscriptionType\":\"GAMINGCONSOLE\"},\"data\":{\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"\",\"mdnFilterValue\":\"\",\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"preBackOrderDate\":\"\",\"preBackOrderDisplayType\":\"\",\"addAccessories\":[{\"giftCard\":false,\"id\":\"RRT-00001\",\"qty\":1,\"isSoftSku\":false,\"accessoryBundle\":false,\"productId\":\"acc18040009\",\"category\":\"Gaming\",\"isEcpdDiscountEligilble\":false,\"cashOptionEnabled\":true}]}],\"rtm\":{\"url\":\"https://vzwqa1.verizonwireless.com/products/xbox-console-series-x/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/microsoft-xbox-w-controller-a-a?fmt=pjpg\",\"name\":\"All Access - Series X Console\",\"make\":\"Xbox\",\"categoryId\":\"Gaming\",\"pageURL\":\"https://vzwqa1.verizonwireless.com/products/xbox-all-access-series-x-console/\",\"acc_url\":\"https://vzwqa1.verizonwireless.com/products/xbox-console-series-x/\",\"acc_img\":\"https://ss7.vzw.com/is/image/VerizonWireless/microsoft-xbox-w-controller-a-a?fmt=pjpg\",\"acc_categoryId\":\"Gaming\"}}}";
		AddAccessoriesUIRequest request = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
		AddAccessoryPEGARequest pegaRequest = new AddAccessoryPEGARequest();
		URI url = URI.create("http://localhost/nse/add-accessories");
		MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url)
				.header("channelId", "VZW-DOTCOM")
				.header(CartConstants.DIGITAL_IG_SESSION, "POE-D-4b2b44f3-8534-4b37-bb54-f7b0dd6ca3f2")
				.header(CartConstants.MTN, "7068334365")
				.build();
		request.setHttpRequest(httpRequest);
		request.getCartInfo().setCartCreator(null);
		request.setChannelId("VZW-DOTCOM");
		CartPegaRequestUtil3.formatAddAccessoriesRequest(pegaRequest, request, "", true);
		Assert.assertEquals("POE-D-4b2b44f3-8534-4b37-bb54-f7b0dd6ca3f2",
				pegaRequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCartCreator());

		url = URI.create("http://localhost/add-accessories");
		httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url)
				.header("channelId", "VZW-DOTCOM")
				.header(CartConstants.DIGITAL_IG_SESSION, "POE-D-4b2b44f3-8534-4b37-bb54-f7b0dd6ca3f2")
				.header(CartConstants.MTN, "7068334365")
				.build();
		request.setHttpRequest(httpRequest);
		CartPegaRequestUtil3.formatAddAccessoriesRequest(pegaRequest, request, "", true);
		Assert.assertEquals("7068334365",
				pegaRequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCartCreator());

		request.getCartInfo().setCartCreator("random");
		CartPegaRequestUtil3.formatAddAccessoriesRequest(pegaRequest, request, "", true);
		Assert.assertEquals("random",
				pegaRequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCartCreator());

		request.getCartInfo().setCartCreator(null);
		request.setHttpRequest(null);
		CartPegaRequestUtil3.formatAddAccessoriesRequest(pegaRequest, request, "", true);
	}

	@Test
	public void formatAddDeviceRequestTestDigital() throws JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"SecondNumberPage\",\"processAction\":\"addDeviceSim\",\"intendType\":\"BYOD\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"isNewLine\":true,\"ispuFlow\":false,\"depletionType\":\"F\",\"depletionLocationCode\":\"\",\"isKeepingExistingEqProtection\":true,\"secondNumber\":{\"isSecondNumber\":true,\"primaryMtn\":\"2677887898\",\"secondMtn\":\"\"}}]}}";
		AddDeviceUIRequest request = mapper.readValue(sampleUIRequestString,AddDeviceUIRequest.class);
		AddDevicePEGARequest pegaRequest = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(),request,null,true,true, true, getFFlag());
		Assert.assertNotNull((pegaRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0]).getSecondNumber());
		Lines lines = request.getData().getLines().get(0);
		lines.setSkipAutoAttachForBYODCC(true);
		pegaRequest = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(),request,null,true,false, false, getFFlag());
		Assert.assertTrue((pegaRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0]).getSkipAutoAttachForBYODCC());
	}

	@Test
	public void formatAddDeviceRequestTestQuickShop() throws JsonProcessingException {
		String sampleUIQuickShopRequest = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":true,\"expressCheckout\":null,\"noPendingOfferExists\":false,\"isPromoPDP\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"30004\",\"quickShop\":true},\"data\":{\"lines\":[{\"isCommonPDP\":true,\"mtn\":\"\",\"purchasePath\":\"NSE\",\"portInNumber\":\"\",\"eupNoPromoFlow\":false,\"device\":{\"id\":\"MMX83LL/A\",\"contractTerm\":\"MONTH_TO_MONTH\",\"iconicPhone\":false,\"dppMonths\":\"\",\"productId\":\"dev18560014\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"SOFTSIM5G-SA-D\"},\"ispuFlow\":false,\"estimatedReadyByDate\":\"\",\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"newLineOrAAL\":false,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false,\"selectedSedOfferId\":\"\",\"isStrategicOffer\":\"\",\"restricted\":\"\",\"isTradeInIntentSelected\":false}],\"rtm\":{\"url\":\"https://vzwqa1.verizonwireless.com/smartphones/apple-iphone-se-2022/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-se-midnight-2022\",\"name\":\"iPhone SE (3rd Gen)\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://vzwqa1.verizonwireless.com/smartphones/apple-iphone-se-2022/\"}}}";
		AddDeviceUIRequest request = mapper.readValue(sampleUIQuickShopRequest, AddDeviceUIRequest.class);
		request.setChannelId("VZW-DOTCOM");
		request.getCartInfo().setEditFromBYOPlan(true);
		request.getCartInfo().setEditFromBYOPerk(true);
		AddDevicePEGARequest pegareq1 = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(),request,null,true,true, true, getFFlag());
		Assert.assertNotNull((pegareq1.getServiceBody().getServiceRequest().getContext().getCartInfo().getEditFromBYOPlan()));
		Assert.assertNotNull((pegareq1.getServiceBody().getServiceRequest().getContext().getCartInfo().getEditFromBYOPerk()));
		Assert.assertTrue((pegareq1.getServiceBody().getServiceRequest().getContext().getCartInfo().getEditFromBYOPlan()));
		Assert.assertTrue((pegareq1.getServiceBody().getServiceRequest().getContext().getCartInfo().getEditFromBYOPerk()));
		request.getCartInfo().setQuickShopTradeIn("true");
		request.getCartInfo().setEditFromBYOPlan(false);
		request.getCartInfo().setEditFromBYOPerk(false);
		CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(),request,null,true,false, false, getFFlag());
		request.getCartInfo().setEditFromBYOPlan(null);
		request.getCartInfo().setEditFromBYOPerk(null);
		CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(),request,null,true,true, true, getFFlag());
		request.getCartInfo().setEditDevice(null);
		CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(),request,null,true,true, true, getFFlag());
		request.getCartInfo().setEditDevice(false);
		CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(),request,null,true,false, false, getFFlag());
	}

	@Test
	public void addPlanPEGARequestPlanTestQuickShop() throws IOException {
		String sampleUIRequestString="{\"cartInfo\":{\"processingMTN\":\"newLine1\",\"processStep\":\"NewRecommendedPlanSelection\",\"intendType\":\"NSE\",\"editPlanClick\":true,\"customerType\":\"N\",\"mtnFlow\":null,\"processAction\":\"addPlan\"},\"data\":{\"lines\":[{\"path\":\"custom\",\"action\":\"customized\",\"mtn\":\"newLine1\",\"plan\":{\"id\":\"63217\"},\"addFeatures\":[],\"removeFeatures\":[]}],\"enableFcc\":false,\"parentMtn\":\"\"},\"optPlanSku\":true,\"isByou\":true}";
		AddPlanUIRequest uiRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
		uiRequest.getCartInfo().setQuickShop("true");
		uiRequest.setChannelId("VZW-DOTCOM");
		uiRequest.getCartInfo().setEditFromBYOPlan(true);
		uiRequest.getCartInfo().setEditFromBYOPerk(true);
		AddPlanPEGARequest pegareq1  = CartPegaRequestUtil2.formatAddPlanRequest( new AddPlanPEGARequest(), uiRequest, true,false, getFFlag(), true);
		Assert.assertNotNull((pegareq1.getServiceBody().getServiceRequest().getContext().getCartInfo().getEditFromBYOPlan()));
		Assert.assertNotNull((pegareq1.getServiceBody().getServiceRequest().getContext().getCartInfo().getEditFromBYOPerk()));
		Assert.assertTrue((pegareq1.getServiceBody().getServiceRequest().getContext().getCartInfo().getEditFromBYOPlan()));
		Assert.assertTrue((pegareq1.getServiceBody().getServiceRequest().getContext().getCartInfo().getEditFromBYOPerk()));
		uiRequest.getCartInfo().setEditFromBYOPlan(false);
		uiRequest.getCartInfo().setEditFromBYOPerk(false);
		CartPegaRequestUtil2.formatAddPlanRequest(new AddPlanPEGARequest(),uiRequest, true,false, getFFlag(), true);
		uiRequest.getCartInfo().setEditFromBYOPlan(null);
		uiRequest.getCartInfo().setEditFromBYOPerk(null);
		CartPegaRequestUtil2.formatAddPlanRequest(new AddPlanPEGARequest(),uiRequest, true,false, getFFlag(), true);
		uiRequest.getCartInfo().setEditPlanClick(null);
		CartPegaRequestUtil2.formatAddPlanRequest(new AddPlanPEGARequest(),uiRequest, true,false, getFFlag(), true);
		uiRequest.getCartInfo().setEditPlanClick(false);
		CartPegaRequestUtil2.formatAddPlanRequest(new AddPlanPEGARequest(),uiRequest, true,false, getFFlag(), true);
	}

	@Test
	public void formatAddFeaturesRequestNSETestQuickshop() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"newLine1\",\"intendType\":\"NSE\",\"processStep\":\"DeviceConfigurator\",\"editDeviceConfiguratorClick\":true,\"isSmartLocator\":false,\"accountLevelProtection\":false,\"expressCheckout\":true},\"data\":{\"account\":null,\"lines\":[{\"mtn\":\"newLine1\",\"features\":{\"add\":[{\"id\":\"88703\",\"actionIndicator\":\"A\",\"type\":\"SFO\",\"quantity\":1}],\"remove\":[{\"id\":\"88689\",\"type\":\"SFO\",\"quantity\":1}]}}],\"accountLevelProtection\":false}}";
		AddFeaturesUIRequest uiRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
		uiRequest.setChannelId("VZW-DOTCOM");
		uiRequest.getCartInfo().setQuickShop("true");
		uiRequest.getCartInfo().setEditFromBYOPlan(true);
		uiRequest.getCartInfo().setEditFromBYOPerk(true);
		AddFeaturesPEGARequest pegareq1 = CartPegaRequestUtil3.formatAddFeaturesRequest(new AddFeaturesPEGARequest(), uiRequest, getFFlag());
		Assert.assertNotNull((pegareq1.getServiceBody().getServiceRequest().getContext().getCartInfo().getEditFromBYOPlan()));
		Assert.assertNotNull((pegareq1.getServiceBody().getServiceRequest().getContext().getCartInfo().getEditFromBYOPerk()));
		Assert.assertTrue((pegareq1.getServiceBody().getServiceRequest().getContext().getCartInfo().getEditFromBYOPlan()));
		Assert.assertTrue((pegareq1.getServiceBody().getServiceRequest().getContext().getCartInfo().getEditFromBYOPerk()));
		uiRequest.getCartInfo().setEditFromBYOPlan(false);
		uiRequest.getCartInfo().setEditFromBYOPerk(false);
		CartPegaRequestUtil3.formatAddFeaturesRequest(new AddFeaturesPEGARequest(), uiRequest, getFFlag());
		uiRequest.getCartInfo().setEditFromBYOPlan(null);
		uiRequest.getCartInfo().setEditFromBYOPerk(null);
		CartPegaRequestUtil3.formatAddFeaturesRequest(new AddFeaturesPEGARequest(), uiRequest, getFFlag());
		uiRequest.getCartInfo().setEditDeviceConfiguratorClick(null);
		CartPegaRequestUtil3.formatAddFeaturesRequest(new AddFeaturesPEGARequest(), uiRequest, getFFlag());
		uiRequest.getCartInfo().setEditDeviceConfiguratorClick(false);
		CartPegaRequestUtil3.formatAddFeaturesRequest(new AddFeaturesPEGARequest(), uiRequest, getFFlag());
	}

	@Test
	public void isTrialCustomerFlowTest() {
		Assert.assertEquals(true, CartPegaRequestUtil.isTrialCustomerFlow("DVM"));
		Assert.assertEquals(false, CartPegaRequestUtil.isTrialCustomerFlow(null));
	}

	@Test
	public void formatAddDeviceRequestTrialTest() throws JsonMappingException, JsonProcessingException {

		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"flowType\":\"DVM\",\"processStep\":\"SecondNumberPage\",\"processAction\":\"addDeviceSim\",\"intendType\":\"BYOD\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"isNewLine\":true,\"ispuFlow\":false,\"depletionType\":\"F\",\"depletionLocationCode\":\"\",\"isKeepingExistingEqProtection\":true,\"secondNumber\":{\"isSecondNumber\":true,\"primaryMtn\":\"2677887898\",\"secondMtn\":\"\"}}]}}";
		AddDeviceUIRequest request = mapper.readValue(sampleUIRequestString,AddDeviceUIRequest.class);
		AddDevicePEGARequest pegaRequest = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(),request,null,true,true, true, getFFlag());
		Assert.assertEquals(pegaRequest.getServiceHeader().getServiceName(), "Trial");
		Assert.assertEquals(pegaRequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getFlowType(), "DVM");
		Assert.assertEquals(pegaRequest.getServiceBody().getServiceRequest().getContext().getContextInfo().getCallReason(), "TrialNWTD");

	}

	@Test
	public void formatAddPlanRequestTrialTest() throws JsonMappingException, JsonProcessingException {

		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"flowType\":\"DVM\",\"processStep\":\"SecondNumberPage\",\"processAction\":\"addDeviceSim\",\"intendType\":\"BYOD\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"isNewLine\":true,\"ispuFlow\":false,\"depletionType\":\"F\",\"depletionLocationCode\":\"\",\"isKeepingExistingEqProtection\":true,\"secondNumber\":{\"isSecondNumber\":true,\"primaryMtn\":\"2677887898\",\"secondMtn\":\"\"}}]}}";
		AddPlanUIRequest request = mapper.readValue(sampleUIRequestString,AddPlanUIRequest.class);
		AddPlanPEGARequest pegaRequest = CartPegaRequestUtil2.formatAddPlanRequest(new AddPlanPEGARequest(),request, true,false, getFFlag(), true);
		Assert.assertEquals(pegaRequest.getServiceHeader().getServiceName(), "Trial");
		Assert.assertEquals(pegaRequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getFlowType(), "DVM");
		Assert.assertEquals(pegaRequest.getServiceBody().getServiceRequest().getContext().getContextInfo().getCallReason(), "TrialNWTD");

	}

	@Test
	public void formatAccountPinRequestTrialTest() throws JsonMappingException, JsonProcessingException {

		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"flowType\":\"DVM\",\"processStep\":\"SecondNumberPage\",\"processAction\":\"addDeviceSim\",\"intendType\":\"BYOD\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"isNewLine\":true,\"ispuFlow\":false,\"depletionType\":\"F\",\"depletionLocationCode\":\"\",\"isKeepingExistingEqProtection\":true,\"secondNumber\":{\"isSecondNumber\":true,\"primaryMtn\":\"2677887898\",\"secondMtn\":\"\"}}]}}";
		AccountPinUIRequest request = mapper.readValue(sampleUIRequestString,AccountPinUIRequest.class);
		AccountPinPEGARequest pegaRequest = CartPegaRequestUtil7.formatAccountPinRequest(new AccountPinPEGARequest(),request);
		Assert.assertEquals(pegaRequest.getServiceHeader().getServiceName(), "Trial");
		Assert.assertEquals(pegaRequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getFlowType(), "DVM");
		Assert.assertEquals(pegaRequest.getServiceBody().getServiceRequest().getContext().getContextInfo().getCallReason(), "TrialNWTD");

	}

	@Test
	public void removeLinesRequestQuickShopTest() throws JsonProcessingException {
		String uiRequestString = "{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"expressCheckout\":\"true\",\"processStep\":\"BuildYourOrderPerk\",\"processAction\":\"removeItem\",\"quickShop\":true,\"intendType\":\"NSE\"},\"data\":{\"lines\":[{\"mtn\":\"newLine1\"}]},\"validateCartRequest\":{\"pageId\":\"CART\",\"retrieveCurrentFeatures\":true},\"expressCheckout\":\"true\"}";
		RemoveLinesUIRequest uiRequest1 = mapper.readValue(uiRequestString, RemoveLinesUIRequest.class);
		uiRequest1.setChannelId("VZW-DOTCOM");
		RemoveLinesPEGARequest pegaRequest1 = new RemoveLinesPEGARequest();
		CartPegaRequestUtil2.formatRemoveLinesRequest(pegaRequest1, uiRequest1);
		Assert.assertEquals("true", pegaRequest1.getServiceBody().getServiceRequest().getContext().getCartInfo().getIsQuickShopFlow());
		RemoveLinesUIRequest uiRequest2= mapper.readValue(uiRequestString, RemoveLinesUIRequest.class);
		uiRequest2.setChannelId("VZW-DOTCOM");
		uiRequest2.getCartInfo().setQuickShop(null);
		RemoveLinesPEGARequest pegaRequest2 = new RemoveLinesPEGARequest();
		CartPegaRequestUtil2.formatRemoveLinesRequest(pegaRequest2, uiRequest2);
		Assert.assertNull(pegaRequest2.getServiceBody().getServiceRequest().getContext().getCartInfo().getIsQuickShopFlow());

	}
	@Test
	public void formatRemoveLinesRequestRegNumNotNullTest() throws JsonProcessingException, IllegalAccessException, NoSuchFieldException
	{
		String uiRequestString = "{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"expressCheckout\":\"true\",\"processStep\":\"BuildYourOrderPerk\",\"processAction\":\"removeItem\",\"quickShop\":true,\"intendType\":\"NSE\"},\"data\":{\"lines\":[{\"mtn\":\"newLine1\"}]},\"validateCartRequest\":{\"pageId\":\"CART\",\"retrieveCurrentFeatures\":true},\"expressCheckout\":\"true\"}";
		RemoveLinesUIRequest uiRequest1 = mapper.readValue(uiRequestString, RemoveLinesUIRequest.class);
		uiRequest1.setChannelId("VZW-DOTCOM");
		RemoveLinesPEGARequest pegaRequest1 = new RemoveLinesPEGARequest();
		uiRequest1.getCartInfo().setRegisterNumber(12345);
		RemoveLinesPEGARequest result = CartPegaRequestUtil2.formatRemoveLinesRequest(pegaRequest1, uiRequest1);
		Assert.assertNotNull(result);

		CartPegaRequestUtil2 cartPegaRequestUtil2 = new CartPegaRequestUtil2();
		Field field = cartPegaRequestUtil2.getClass().getDeclaredField("enableCradleForExistingCustomer");
		field.setAccessible(true);
		field.set(null,true);
		uiRequest1.getCartInfo().setIntendType("invalid");
		RemoveLinesPEGARequest result1 = cartPegaRequestUtil2.formatRemoveLinesRequest(pegaRequest1, uiRequest1);
		Assert.assertNotNull(result1);
	}
	@Test
	public void formatRemoveLinesRequestEnableCradleForProspectTest() throws JsonProcessingException, IllegalAccessException, NoSuchFieldException
	{
		String uiRequestString = "{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"expressCheckout\":\"true\",\"processStep\":\"BuildYourOrderPerk\",\"processAction\":\"removeItem\",\"quickShop\":true,\"intendType\":\"NSE\"},\"data\":{\"lines\":[{\"mtn\":\"newLine1\"}]},\"validateCartRequest\":{\"pageId\":\"CART\",\"retrieveCurrentFeatures\":true},\"expressCheckout\":\"true\"}";
		RemoveLinesUIRequest uiRequest1 = mapper.readValue(uiRequestString, RemoveLinesUIRequest.class);
		uiRequest1.setChannelId("VZW-DOTCOM");
		RemoveLinesPEGARequest pegaRequest1 = new RemoveLinesPEGARequest();
		uiRequest1.getCartInfo().setRegisterNumber(12345);
		CartPegaRequestUtil2 cartPegaRequestUtil2 = new CartPegaRequestUtil2();
		Field field = cartPegaRequestUtil2.getClass().getDeclaredField("enableCradleForProspect");
		field.setAccessible(true);
		field.set(null,true);
		RemoveLinesPEGARequest result = CartPegaRequestUtil2.formatRemoveLinesRequest(pegaRequest1, uiRequest1);
		Assert.assertNotNull(result);
	}


	@Test
	public void identifyIfDiscountOnlyFlowTest() throws JsonProcessingException {
		String uiRequestString = "{ \"cartInfo\": { \"correlationId\": \"\", \"processingMTN\": \"\", \"processStep\": \"featureSelection\", \"processAction\": \"\", \"cartCreator\": \"5619384700\", \"intendType\": \"FEA\", \"creditAppNum\": \"\" }, \"data\": { \"account\": { \"features\": { \"add\": [ { \"id\": \"3000\", \"actionIndicator\": \"A\", \"type\": \"SPO\", \"quantity\": \"1\", \"mtns\": [ { \"mtn\": \"5619384700\" } ] } ] } } } }";
		AddFeaturesUIRequest uiRequest = mapper.readValue(uiRequestString, AddFeaturesUIRequest.class);
		assertTrue(CartPegaRequestUtil3.isFeatureOrSPOUpdateOnly(uiRequest));

		AddFeaturesUIRequest uiRequest1 = mapper.readValue(uiRequestString, AddFeaturesUIRequest.class);
		uiRequest1.getCartInfo().setFlowType(FLOW_TYPE_WHW);
		assertFalse(CartPegaRequestUtil3.isFeatureOrSPOUpdateOnly(uiRequest1));

		uiRequest.getCartInfo().setIntendType("");
		assertFalse(CartPegaRequestUtil3.isFeatureOrSPOUpdateOnly(uiRequest));

		uiRequest.getCartInfo().setIntendType(null);
		assertFalse(CartPegaRequestUtil3.isFeatureOrSPOUpdateOnly(uiRequest));

		uiRequest.setCartInfo(null);
		assertFalse(CartPegaRequestUtil3.isFeatureOrSPOUpdateOnly(uiRequest));




	}

	@Test
	public void isDvmConversionFlagExistsTest() {

		RequestAccess reqAccess = new RequestAccess();
		reqAccess.getCookies().add("dvmConversion", new HttpCookie("dvmConversion", "true"));
		RequestAccessContext.updateRequestData(reqAccess);
		assertTrue(CartPegaRequestUtil.isDvmConversionFlagExists());
	}



	@Test
	public void isDvmConversionFlagExistsTest11() {
//		ReflectionTestUtils.setField(cartPegaRequestUtil, "enableDvmConversionFlag", true);
		RequestAccess reqAccess = new RequestAccess();
		reqAccess.getCookies().add("dvmConversion", new HttpCookie("dvmConversion", "true"));
		RequestAccessContext.updateRequestData(reqAccess);
		assertTrue(CartPegaRequestUtil.isDvmConversionFlagExists());
	}

	@Test
	public void isDvmConversionFlagExistsTest4() {
		RequestAccess reqAccess = new RequestAccess();
		reqAccess.getCookies().add("dvmConversion", new HttpCookie("dvmConversion", "True"));
		RequestAccessContext.updateRequestData(reqAccess);
		assertTrue(CartPegaRequestUtil.isDvmConversionFlagExists());
	}

	@Test
	public void isDvmConversionFlagExistsTest1() {
//		ReflectionTestUtils.setField(cartPegaRequestUtil, "enableDvmConversionFlag", false);
		RequestAccess reqAccess = new RequestAccess();
		reqAccess.getCookies().add("dvmConversion", new HttpCookie("dvmConversion", "true"));
		RequestAccessContext.updateRequestData(reqAccess);
		assertTrue(CartPegaRequestUtil.isDvmConversionFlagExists());
	}

	@Test
	public void isDvmConversionFlagExistsTest2() {
//		ReflectionTestUtils.setField(cartPegaRequestUtil, "enableDvmConversionFlag", false);
		RequestAccess reqAccess = new RequestAccess();
		reqAccess.getCookies().add("dvmConversion", new HttpCookie("dvmConversion", "false"));
		RequestAccessContext.updateRequestData(reqAccess);
		assertFalse(CartPegaRequestUtil.isDvmConversionFlagExists());
	}

	@Test
	public void isDvmConversionFlagExistsTest3() {

		assertFalse(CartPegaRequestUtil.isDvmConversionFlagExists());
	}

	@Test
	public void formatRetrieveActivationStatusRequestTest1() throws JsonMappingException, JsonProcessingException {
//		ReflectionTestUtils.setField(cartPegaRequestUtil, "enableDvmConversionFlag", true);
		RequestAccess reqAccess = new RequestAccess();
		reqAccess.getCookies().add("dvmConversion", new HttpCookie("dvmConversion", "true"));
		RequestAccessContext.updateRequestData(reqAccess);
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"processStep\": \"promo\",\"sessionId\": \"session\",\"accountNumber\": \"4567\",\"mtnFlow\": \"mtn\",\"creditAppNum\": \"credit\",\"intendType\": \"NSE\"},\"data\": {\"lines\": []}}";
		RetrieveActivationStatusUIRequest uiRequest = mapper.readValue(requestString, RetrieveActivationStatusUIRequest.class);
		RetrieveActivationStatusPEGARequest response = CartPegaRequestUtil7.formatRetrieveActivationStatusRequest(new RetrieveActivationStatusPEGARequest(), uiRequest);
		Assert.assertEquals(CartConstants.NEW_CUSTOMER, response.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCustomerType());
	}

	@Test
	public void fetchComVzIdFromHeaderTest() {
		RequestAccess reqAccess = new RequestAccess();
		reqAccess.getHeaders().add(CartConstants.COM_VZ_ID, "");
		RequestAccessContext.updateRequestData(reqAccess);
		Assert.assertEquals("",CartPegaRequestUtil.fetchComVzIdFromHeader());

		reqAccess.getHeaders().set(CartConstants.COM_VZ_ID,"1234567");
		RequestAccessContext.updateRequestData(reqAccess);
		Assert.assertEquals("1234567",CartPegaRequestUtil.fetchComVzIdFromHeader());
	}

	@Test
	public void addPlanPEGARequestLGPOTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"processingMTN\":\"newLine3\",\"processStep\":\"NewRecommendedPlanSelection\",\"intendType\":\"NSEBYOD\",\"editPlanClick\":false,\"addressLine1\":\"\",\"city\":\"\",\"state\":\"\",\"zipCode\":\"\",\"customerType\":\"N\",\"mtnFlow\":\"D\",\"processAction\":\"addPlan\"},\"data\":{\"isLGPOEligible\":true,\"lines\":[{\"path\":\"popular\",\"action\":\"preset\",\"mtn\":\"newLine3\",\"plan\":{\"id\":\"63215\"},\"addFeatures\":[{\"id\":\"2640\",\"actionIndicator\":\"A\",\"type\":\"SPO\",\"quantity\":1,\"rank\":\"5\"},{\"id\":\"2885\",\"type\":\"SPO\",\"quantity\":1,\"actionIndicator\":\"A\"}],\"removeFeatures\":[]}],\"enableFcc\":true,\"parentMtn\":\"\"},\"optPlanSku\":true,\"isByou\":true}";
		AddPlanUIRequest UIRequest = new AddPlanUIRequest();
		AddPlanPEGARequest pegaRequest = new AddPlanPEGARequest();
		UIRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
		CartPegaRequestUtil2.formatAddPlanRequest(pegaRequest, UIRequest, true,false, getFFlag(), true);
		StepVerifier.create(Mono.just(pegaRequest))
				.assertNext(req -> Assert.assertNotNull(pegaRequest))
				.expectComplete().verify();
	}

	@Test
	public void formatFeaturesAndAccessoryRequestTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"cartCreator\":\"2197279943\",\"intendType\":\"EUP\",\"creditAppNum\":\"2197279943\",\"processStep\":\"FeaturesPDP\",\"processAction\":\"addFeaturesAndAccessory\",\"intent\":\"RedemptionAccessory\",\"flowType\":\"WHW_Redemption\"},\"data\":{\"lines\":[{\"mtn\":\"4753550127\",\"features\":{\"add\":[{\"id\":\"3240\",\"actionIndicator\":\"A\",\"type\":\"SPO\",\"quantity\":1}]},\"accessories\":{\"add\":[{\"qty\":2,\"id\":\"CE1000A\"}]}}]}}";
		AddFeaturesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
		AddFeaturesPEGARequest pegaRequest = new AddFeaturesPEGARequest();
		AddFeaturesPEGARequest response = CartPegaRequestUtil3.formatAddFeaturesRequest(pegaRequest, UIRequest, getFFlag());
		Assert.assertEquals("EUP", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}




	@Test
	public void formatAddDeviceRequestNullCheck1() throws IOException{
		AddDevicePEGARequest pegareq1 = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(),null,null,true,true,true, getFFlag());
		Assert.assertNotNull(pegareq1);

		AddDeviceUIRequest uiRequest = new AddDeviceUIRequest();
		uiRequest.setCartInfo(null);
		AddDevicePEGARequest pegareq2 = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(),uiRequest,null,true,true,true, getFFlag());
		Assert.assertNotNull(pegareq2);

		AddDeviceUIRequest uiRequest1 = new AddDeviceUIRequest();
		DeviceCartInfo deviceCartInfo = new DeviceCartInfo();
		deviceCartInfo.setIntendType(null);
		uiRequest1.setCartInfo(deviceCartInfo);
		AddDevicePEGARequest pegaRequest3 = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(),uiRequest1,null,true,true,true, getFFlag());
		Assert.assertNotNull(pegaRequest3);


		AddDeviceUIRequest uiRequest3 = new AddDeviceUIRequest();
		DeviceCartInfo deviceCartInfo2 = new DeviceCartInfo();
		deviceCartInfo2.setIntendType("rex");
		uiRequest3.setCartInfo(deviceCartInfo2);
		AddDevicePEGARequest pegaRequest5 = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(),uiRequest3,null,true,true,true, getFFlag());
		Assert.assertNotNull(pegaRequest5);


		AddDeviceUIRequest uiRequest4 = new AddDeviceUIRequest();
		DeviceCartInfo deviceCartInfo3 = new DeviceCartInfo();
		deviceCartInfo3.setIntendType("CCH");
		uiRequest4.setCartInfo(deviceCartInfo3);
		AddDevicePEGARequest pegaRequest6 = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(),uiRequest4,null,true,true,true, getFFlag());
		Assert.assertNotNull(pegaRequest6);

		AddDeviceUIRequest uiRequest5 = new AddDeviceUIRequest();
		DeviceCartInfo deviceCartInfo4 = new DeviceCartInfo();
		deviceCartInfo4.setIntendType(CartConstants.REX);
		uiRequest5.setCartInfo(deviceCartInfo3);
		AddDevicePEGARequest pegaRequest7 = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(),uiRequest5,null,true,true,true, getFFlag());
		Assert.assertNotNull(pegaRequest7);

		AddDeviceUIRequest uiRequest6 = new AddDeviceUIRequest();
		DeviceCartInfo deviceCartInfo5 = new DeviceCartInfo();
		deviceCartInfo5.setIntendType(CartConstants.CONTRACT_CHANGE);
		uiRequest6.setCartInfo(deviceCartInfo3);
		pegaRequest7 = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(),uiRequest6,null,true,true,true, getFFlag());
		Assert.assertNotNull(pegaRequest7);

		AddDeviceUIRequest uiRequest7 = new AddDeviceUIRequest();
		deviceCartInfo5 = new DeviceCartInfo();
		deviceCartInfo5.setIntendType("EXC");
		uiRequest6.setCartInfo(deviceCartInfo5);
		pegaRequest7 = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest6, null, true, true,true, getFFlag());
		Assert.assertNotNull(pegaRequest7);

		uiRequest6 = new AddDeviceUIRequest();
		deviceCartInfo5 = new DeviceCartInfo();
		deviceCartInfo5.setIntendType(CartConstants.EXCHANGE);
		uiRequest6.setCartInfo(deviceCartInfo5);
		pegaRequest7 = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest6, null, true, true,true, getFFlag());
		Assert.assertNotNull(pegaRequest7);

		uiRequest6 = new AddDeviceUIRequest();
		deviceCartInfo5 = new DeviceCartInfo();
		deviceCartInfo5.setIntendType(CartConstants.EXCBYOD);
		uiRequest6.setCartInfo(deviceCartInfo5);
		pegaRequest7 = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest6, null, true, true,true, getFFlag());
		Assert.assertNotNull(pegaRequest7);


		uiRequest6 = new AddDeviceUIRequest();
		deviceCartInfo5 = new DeviceCartInfo();
		deviceCartInfo5.setIntendType("EXCBYOD");
		uiRequest6.setCartInfo(deviceCartInfo5);
		pegaRequest7 = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest6, null, true, true,true, getFFlag());
		Assert.assertNotNull(pegaRequest7);

		uiRequest6 = new AddDeviceUIRequest();
		deviceCartInfo5 = new DeviceCartInfo();
		deviceCartInfo5.setIntendType(CartConstants.PAD);
		uiRequest6.setCartInfo(deviceCartInfo5);
		pegaRequest7 = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest6, null, true, true,true, getFFlag());
		Assert.assertNotNull(pegaRequest7);

		uiRequest6 = new AddDeviceUIRequest();
		deviceCartInfo5 = new DeviceCartInfo();
		deviceCartInfo5.setIntendType("PAD");
		uiRequest6.setCartInfo(deviceCartInfo5);
		pegaRequest7 = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest6, null, true, true,true, getFFlag());
		Assert.assertNotNull(pegaRequest7);


		uiRequest6 = new AddDeviceUIRequest();
		deviceCartInfo5 = new DeviceCartInfo();
		deviceCartInfo5.setIntendType("PAD");
		deviceCartInfo5.setByodESim(null);
		uiRequest6.setCartInfo(deviceCartInfo5);
		pegaRequest7 = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest6, null, true, true,true, getFFlag());
		Assert.assertNotNull(pegaRequest7);

		uiRequest6 = new AddDeviceUIRequest();
		deviceCartInfo5 = new DeviceCartInfo();
		deviceCartInfo5.setIntendType("PAD");
		deviceCartInfo5.setByodESim("");
		uiRequest6.setCartInfo(deviceCartInfo5);
		pegaRequest7 = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest6, null, true, true,true, getFFlag());
		Assert.assertNotNull(pegaRequest7);

		AddDeviceUIRequest uiRequest2 = new AddDeviceUIRequest();
		DeviceCartInfo deviceCartInfo1 = new DeviceCartInfo();
		deviceCartInfo1.setIntendType("");
		uiRequest2.setCartInfo(deviceCartInfo1);
		AddDevicePEGARequest pegaRequest4 = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(),uiRequest2,null,true,true,true, getFFlag());
		Assert.assertNotNull(pegaRequest4);

		uiRequest2 = new AddDeviceUIRequest();
		deviceCartInfo1 = new DeviceCartInfo();
		deviceCartInfo1.setIntendType("");
		deviceCartInfo1.setTwoYearUpgrade(null);
		deviceCartInfo1.setIsLineLevelPlanAccount(null);
		uiRequest2.setCartInfo(deviceCartInfo1);
		pegaRequest4 = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest2, null, true, true, true, getFFlag());
		Assert.assertNotNull(pegaRequest4);


		String sampleRequestString = CartServiceBpmHelperTest.readFromFile("dfoToDppCart_Ui_Request_Null_check.json");
		uiRequest2 = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
		uiRequest2.getData().getLines().get(0).getDevice().setProductId(null);
		uiRequest2.getData().getLines().get(0).getDevice().setCategory(null);

		pegaRequest4 = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest2, null, true, true, true, getFFlag());
		Assert.assertNotNull(pegaRequest4);


	}


}