package onevz.soe.cart.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.datastore.client.StoreCustomerDatastoreClient;
import onevz.soe.datastore.model.CustomerData;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@WebFluxTest(RetrieveCustomerDataUtilTest.class)
class RetrieveCustomerDataUtilTest {

    @InjectMocks
    RetrieveCustomerDataUtil retrieveCustomerDataUtil;

    @Mock
    private StoreCustomerDatastoreClient customerDatastoreClient;

    @Mock
    private ObjectMapper mapper;

    @Test
    void getCustomerDataFromSessionTest() throws JsonProcessingException {
        String reqJsonString = "{\"activeMtnCount\":0,\"viewOnlyProfile\":false,\"billPay\":false,\"cartId\":\"bfc34577-f28e-49b9-be4a-865785858496\",\"locationCode\":\"D593801\"}";
        when(customerDatastoreClient.readStoreCustomerData(any(), any())).thenReturn(Mono.just(reqJsonString));
        when(mapper.readValue(reqJsonString, CustomerData.class)).thenReturn(new CustomerData());

        Mono<CustomerData> serviceResp = retrieveCustomerDataUtil.getCustomerDataFromSession("test");
        StepVerifier.create(serviceResp).assertNext(Assert::assertNotNull).verifyComplete();
    }

    @Test
    void getCustomerDataFromSessionExceptionTest() throws JsonProcessingException {
        String reqJsonString = "{\"serviceHeader\":{\"clientId\":\"OMNI-RETAIL\",\"correlationId\":\"aaa949b99cbbac988db964f754abd726\",\"serviceName\":\"TYSUpdate\",\"sessionId\":\"\",\"callReason\":\"TransferYourService\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"TYS-13628581-E01\",\"customerInfo\":{\"accountNumber\":\"0285136385-00001\",\"mtn\":\"2483217683\",\"customerId\":\"0285136385\",\"userRole\":\"AccountOwner/AccountMember\"},\"pairInfoDetails\":{\"mtnList\":[],\"trunkMtnList\":[],\"branchMtnList\":[]},\"contextInfo\":{\"callReason\":\"TransferYourService\",\"intent\":\"POS-Transfer\",\"processStep\":\"TransferScreen\",\"processAction\":\"ExistingCustomer\"},\"selectedLines\":[{\"mtn\":\"2482513466\"}]}}}}";
        when(customerDatastoreClient.readStoreCustomerData(any(), any())).thenReturn(Mono.just(reqJsonString));
        when(mapper.readValue(reqJsonString, CustomerData.class)).thenThrow(JsonProcessingException.class);

        Mono<CustomerData> serviceResp = retrieveCustomerDataUtil.getCustomerDataFromSession("test");
        StepVerifier.create(serviceResp).assertNext(Assert::assertNotNull).verifyComplete();
    }
}
