package onevz.soe.cart.helper;

import junit.framework.Assert;
import onevz.soe.cart.bpm.service.CartServiceBPMServices;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.model.addQuickAccessoryToCart.AddQuickAccessoryRequest;
import onevz.soe.cart.model.addQuickAccessoryToCart.AddQuickAccessoryResponse;
import onevz.soe.cart.requests.FwaDeviceCartInfo;
import onevz.soe.cart.requests.FwaDeviceContext;
import onevz.soe.cart.requests.FwaServiceBody;
import onevz.soe.cart.responses.AddAccessoriesPEGAResponse;
import onevz.soe.cart.responses.FWACreateCartResponse;
import onevz.soe.cart.responses.FwaServiceResponse;
import onevz.soe.cart.responses.ValidateCartCXPResponse;
import onevz.soe.cart.util.RetrieveCustomerDataUtil;
import onevz.soe.datastore.model.CustomerData;
import onevz.soe.datastore.model.QuickAccessoryDetails;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static onevz.soe.cart.constants.CartConstants.ORD_LOC_SESSION_KEY;
import static onevz.soe.cart.constants.CartConstants.POS_ROLE_SESSION_KEY;
import static onevz.soe.cart.constants.CartConstants.SALES_REP_SESSION_KEY;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@WebFluxTest(AddQuickAccessoryToCartHelperTest.class)
class AddQuickAccessoryToCartHelperTest {
    @Mock
    SOELoginSessionBean soeLoginSessionBean;

    @Mock
    RetrieveCustomerDataUtil retrieveCustomerDataUtil;

    @Mock
    CartServiceBPMServices cartServiceBPMServices;

    @Mock
    CartServiceCXPServices cartServiceCXPServices;

    @InjectMocks
    AddQuickAccessoryToCartHelper addQuickAccessoryToCartHelper;

    @Test
    void addQuickAccessoryToCartTest() throws SOEHTTPException {
        Map<String, String> map = new HashMap<>();
        map.put(SALES_REP_SESSION_KEY, "test");
        map.put(ORD_LOC_SESSION_KEY, "test");
        map.put(POS_ROLE_SESSION_KEY, "test");

        CustomerData customerData = new CustomerData();
        QuickAccessoryDetails accessoryDetails = new QuickAccessoryDetails();
        List<QuickAccessoryDetails.AccessoryLine> lines = new ArrayList<>();
        QuickAccessoryDetails.AccessoryLine accessoryLine = new QuickAccessoryDetails.AccessoryLine();
        List<QuickAccessoryDetails.Accessories> accessories = new ArrayList<>();
        QuickAccessoryDetails.Accessories accessory = new QuickAccessoryDetails.Accessories();
        accessory.setSorId("test");
        accessories.add(accessory);
        accessoryLine.setAccessories(accessories);
        lines.add(accessoryLine);
        accessoryDetails.setLines(lines);
        customerData.setQuickAccessoryDetails(accessoryDetails);

        AddQuickAccessoryRequest request = new AddQuickAccessoryRequest();
        request.setCartId("test");

        FWACreateCartResponse createCartResponse = new FWACreateCartResponse();
        FwaServiceBody serviceBody = new FwaServiceBody();
        FwaServiceResponse fwaServiceResponse = new FwaServiceResponse();
        FwaDeviceContext context = new FwaDeviceContext();
        context.setCaseId("test");
        FwaDeviceCartInfo deviceCartInfo = new FwaDeviceCartInfo();
        deviceCartInfo.setCartId("test");
        context.setCartInfo(deviceCartInfo);
        fwaServiceResponse.setContext(context);
        serviceBody.setServiceResponse(fwaServiceResponse);
        createCartResponse.setServiceBody(serviceBody);
        when(soeLoginSessionBean.getUserSessionData(any())).thenReturn(Mono.just(map));
        when(retrieveCustomerDataUtil.getCustomerDataFromSession(any())).thenReturn(Mono.just(customerData));
        when(cartServiceBPMServices.createCart(any())).thenReturn(Mono.just(createCartResponse));
        when(cartServiceBPMServices.addAccessory(any())).thenReturn(Mono.just(new AddAccessoriesPEGAResponse()));
        when(cartServiceCXPServices.validateCart(any(), any(), any(), any(), any(), any(), any(), any())).thenReturn(Mono.just(new ValidateCartCXPResponse()));
        Mono<AddQuickAccessoryResponse> serviceResponse = addQuickAccessoryToCartHelper.addQuickAccessoryToCart("test", request);
        StepVerifier.create(serviceResponse).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    void addQuickAccessoryToCartTest_1() throws SOEHTTPException {
        CustomerData customerData = new CustomerData();
        customerData.setAccountNumber("test");
        customerData.setLookUpMtn("test");
        QuickAccessoryDetails accessoryDetails = new QuickAccessoryDetails();
        List<QuickAccessoryDetails.AccessoryLine> lines = new ArrayList<>();
        QuickAccessoryDetails.AccessoryLine accessoryLine = new QuickAccessoryDetails.AccessoryLine();
        List<QuickAccessoryDetails.Accessories> accessories = new ArrayList<>();
        QuickAccessoryDetails.Accessories accessory = new QuickAccessoryDetails.Accessories();
        accessory.setSorId("test");
        accessories.add(accessory);
        accessoryLine.setAccessories(accessories);
        lines.add(accessoryLine);
        accessoryDetails.setLines(lines);
        customerData.setQuickAccessoryDetails(accessoryDetails);

        AddQuickAccessoryRequest request = new AddQuickAccessoryRequest();
        request.setCartId("test");

        FWACreateCartResponse createCartResponse = new FWACreateCartResponse();
        FwaServiceBody serviceBody = new FwaServiceBody();
        FwaServiceResponse fwaServiceResponse = new FwaServiceResponse();
        FwaDeviceContext context = new FwaDeviceContext();
        context.setCaseId("test");
        FwaDeviceCartInfo deviceCartInfo = new FwaDeviceCartInfo();
        deviceCartInfo.setAction("test");
        context.setCartInfo(deviceCartInfo);
        fwaServiceResponse.setContext(context);
        serviceBody.setServiceResponse(fwaServiceResponse);
        createCartResponse.setServiceBody(serviceBody);
        when(soeLoginSessionBean.getUserSessionData(any())).thenReturn(Mono.just(new HashMap<>()));
        when(retrieveCustomerDataUtil.getCustomerDataFromSession(any())).thenReturn(Mono.just(customerData));
        when(cartServiceBPMServices.createCart(any())).thenReturn(Mono.just(createCartResponse));
        when(cartServiceBPMServices.addAccessory(any())).thenReturn(Mono.just(new AddAccessoriesPEGAResponse()));
        when(cartServiceCXPServices.validateCart(any(), any(), any(), any(), any(), any(), any(), any())).thenReturn(Mono.just(new ValidateCartCXPResponse()));
        Mono<AddQuickAccessoryResponse> serviceResponse = addQuickAccessoryToCartHelper.addQuickAccessoryToCart("test", request);
        StepVerifier.create(serviceResponse).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    void addEmptyQuickAccessoryToCartTest() throws SOEHTTPException {
        Map<String, String> map = new HashMap<>();
        map.put(SALES_REP_SESSION_KEY, "test");
        map.put(ORD_LOC_SESSION_KEY, "test");
        map.put(POS_ROLE_SESSION_KEY, "test");

        AddQuickAccessoryRequest request = new AddQuickAccessoryRequest();
        request.setCartId("test");

        FWACreateCartResponse createCartResponse = new FWACreateCartResponse();
        FwaServiceBody serviceBody = new FwaServiceBody();
        FwaServiceResponse fwaServiceResponse = new FwaServiceResponse();
        FwaDeviceContext context = new FwaDeviceContext();
        context.setCaseId("test");
        FwaDeviceCartInfo deviceCartInfo = new FwaDeviceCartInfo();
        deviceCartInfo.setCartId("test");
        context.setCartInfo(deviceCartInfo);
        fwaServiceResponse.setContext(context);
        serviceBody.setServiceResponse(fwaServiceResponse);
        createCartResponse.setServiceBody(serviceBody);
        when(soeLoginSessionBean.getUserSessionData(any())).thenReturn(Mono.just(map));
        when(retrieveCustomerDataUtil.getCustomerDataFromSession(any())).thenReturn(Mono.just(new CustomerData()));
        when(cartServiceBPMServices.createCart(any())).thenReturn(Mono.just(createCartResponse));
        when(cartServiceBPMServices.addAccessory(any())).thenReturn(Mono.just(new AddAccessoriesPEGAResponse()));
        when(cartServiceCXPServices.validateCart(any(), any(), any(), any(), any(), any(), any(), any())).thenReturn(Mono.just(new ValidateCartCXPResponse()));
        Mono<AddQuickAccessoryResponse> serviceResponse = addQuickAccessoryToCartHelper.addQuickAccessoryToCart("test", request);
        StepVerifier.create(serviceResponse).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    void addQuickAccessoryToCartEmptyCaseIdTest() {
        Map<String, String> map = new HashMap<>();
        map.put(SALES_REP_SESSION_KEY, "test");
        map.put(ORD_LOC_SESSION_KEY, "test");
        map.put(POS_ROLE_SESSION_KEY, "test");

        AddQuickAccessoryRequest request = new AddQuickAccessoryRequest();
        request.setCartId("test");

        FWACreateCartResponse createCartResponse = new FWACreateCartResponse();
        FwaServiceBody serviceBody = new FwaServiceBody();
        FwaServiceResponse fwaServiceResponse = new FwaServiceResponse();
        FwaDeviceContext context = new FwaDeviceContext();
        FwaDeviceCartInfo deviceCartInfo = new FwaDeviceCartInfo();
        deviceCartInfo.setCartId("test");
        context.setCartInfo(deviceCartInfo);
        fwaServiceResponse.setContext(context);
        serviceBody.setServiceResponse(fwaServiceResponse);
        createCartResponse.setServiceBody(serviceBody);
        when(soeLoginSessionBean.getUserSessionData(any())).thenReturn(Mono.just(map));
        when(retrieveCustomerDataUtil.getCustomerDataFromSession(any())).thenReturn(Mono.just(new CustomerData()));
        when(cartServiceBPMServices.createCart(any())).thenReturn(Mono.just(createCartResponse));
        Mono<AddQuickAccessoryResponse> serviceResponse = addQuickAccessoryToCartHelper.addQuickAccessoryToCart("test", request);
        StepVerifier.create(serviceResponse).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    void addQuickAccessoryToCartAddErrorTest() throws SOEHTTPException {
        Map<String, String> map = new HashMap<>();
        map.put(SALES_REP_SESSION_KEY, "test");
        map.put(ORD_LOC_SESSION_KEY, "test");
        map.put(POS_ROLE_SESSION_KEY, "test");

        AddQuickAccessoryRequest request = new AddQuickAccessoryRequest();
        request.setCartId("test");

        FWACreateCartResponse createCartResponse = new FWACreateCartResponse();
        FwaServiceBody serviceBody = new FwaServiceBody();
        FwaServiceResponse fwaServiceResponse = new FwaServiceResponse();
        FwaDeviceContext context = new FwaDeviceContext();
        context.setCaseId("test");
        FwaDeviceCartInfo deviceCartInfo = new FwaDeviceCartInfo();
        deviceCartInfo.setCartId("test");
        context.setCartInfo(deviceCartInfo);
        fwaServiceResponse.setContext(context);
        serviceBody.setServiceResponse(fwaServiceResponse);
        createCartResponse.setServiceBody(serviceBody);
        when(soeLoginSessionBean.getUserSessionData(any())).thenReturn(Mono.just(map));
        when(retrieveCustomerDataUtil.getCustomerDataFromSession(any())).thenReturn(Mono.just(new CustomerData()));
        when(cartServiceBPMServices.createCart(any())).thenReturn(Mono.just(createCartResponse));
        when(cartServiceBPMServices.addAccessory(any())).thenReturn(Mono.error(new Throwable()));
        Mono<AddQuickAccessoryResponse> serviceResponse = addQuickAccessoryToCartHelper.addQuickAccessoryToCart("test", request);
        StepVerifier.create(serviceResponse).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    void addQuickAccessoryToCartEmptyCreateCartTest() {
        Map<String, String> map = new HashMap<>();
        map.put(SALES_REP_SESSION_KEY, "test");
        map.put(ORD_LOC_SESSION_KEY, "test");
        map.put(POS_ROLE_SESSION_KEY, "test");

        AddQuickAccessoryRequest request = new AddQuickAccessoryRequest();
        request.setCartId("test");

        when(soeLoginSessionBean.getUserSessionData(any())).thenReturn(Mono.just(map));
        when(retrieveCustomerDataUtil.getCustomerDataFromSession(any())).thenReturn(Mono.just(new CustomerData()));
        when(cartServiceBPMServices.createCart(any())).thenReturn(Mono.just(new FWACreateCartResponse()));
        Mono<AddQuickAccessoryResponse> serviceResponse = addQuickAccessoryToCartHelper.addQuickAccessoryToCart("test", request);
        StepVerifier.create(serviceResponse).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    void addQuickAccessoryToCartErrorTest() {
        Map<String, String> map = new HashMap<>();
        map.put(SALES_REP_SESSION_KEY, "test");
        map.put(ORD_LOC_SESSION_KEY, "test");
        map.put(POS_ROLE_SESSION_KEY, "test");

        AddQuickAccessoryRequest request = new AddQuickAccessoryRequest();
        request.setCartId("test");

        when(soeLoginSessionBean.getUserSessionData(any())).thenReturn(Mono.just(map));
        when(retrieveCustomerDataUtil.getCustomerDataFromSession(any())).thenReturn(Mono.error(new Throwable()));
        Mono<AddQuickAccessoryResponse> serviceResponse = addQuickAccessoryToCartHelper.addQuickAccessoryToCart("test", request);
        StepVerifier.create(serviceResponse).assertNext(Assert::assertNotNull).expectComplete().verify();
    }
}
