package onevz.soe.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.v3.core.util.Json;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.requests.AddPlanUIRequest;
import onevz.soe.session.bean.SOELoginSessionBean;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static onevz.soe.cart.constants.CartConstants.ACCOUNT_NUMBER;
import static onevz.soe.cart.constants.CartConstants.MTN;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = {CartServiceTestConfig.class})
public class RedisHelper3Test {
    @MockBean
    SOELoginSessionBean sessionBean;

    @Autowired
    RedisHelper3 redisHelper3;

    @Autowired
    RedisHelper redisHelper;

    @Autowired
    private ObjectMapper mapper;


    //request.getData()=null
    @Test
    public void addPlanAndPerksToRedis1() throws Exception {
        AddPlanUIRequest request = new AddPlanUIRequest();
        StepVerifier.create(redisHelper3.addPlanAndPerksToRedis(request)).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    //request.getDataExists and sessionBean.setSessionData()=true
    @Test
    public void addPlanAndPerksToRedis2() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"lines\":[{\"plan\":{\"sorId\":\"97928\"}}]}}";
        AddPlanUIRequest request = mapper.readValue(requestString, AddPlanUIRequest.class);
        when(sessionBean.setSessionData(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        StepVerifier.create(redisHelper3.addPlanAndPerksToRedis(request)).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    //request.getDataExists and sessionBean.setSessionData()=false
    @Test
    public void addPlanAndPerksToRedis3() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"lines\":[{\"plan\":{\"sorId\":\"97928\"}}]}}";
        AddPlanUIRequest request = mapper.readValue(requestString, AddPlanUIRequest.class);
        when(sessionBean.setSessionData(Mockito.any(), Mockito.any())).thenReturn(Mono.just(false));
        StepVerifier.create(redisHelper3.addPlanAndPerksToRedis(request)).assertNext(Assert::assertNotNull).expectComplete().verify();
    }


    @Test
    public void getMtnDataForDigiTalOrderTypeTest() throws JsonProcessingException {
       String key= CartConstants.DIGITAL_ORDER_TYPE;
       String mtnData="123456";
       when(sessionBean.setSessionData(Mockito.any(), Mockito.any())).thenReturn(Mono.just(false));
       when(sessionBean.getSessionData(Mockito.any(),Mockito.any())).thenReturn(Mono.just(new HashMap<>()));
       StepVerifier.create(redisHelper3.getMtnData(key,mtnData)).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void getRequiredDataFromRedisTest()throws JsonProcessingException{
        List<String> paramList = Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE);
        Map<String,String> redisData = new HashMap<>();
        redisData.put("cartCount","1");
        redisData.put("cartOrderFlowType","");
        when(sessionBean.getSessionData(paramList)).thenReturn(Mono.just(redisData));
        StepVerifier.create(redisHelper.getRequiredDataFromRedis(paramList)).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void getRequiredDataFromRedisNullParamTest()throws JsonProcessingException{
        List<String> paramList = List.of();
        Map<String,String> redisData = new HashMap<>();
        when(sessionBean.getSessionData(paramList)).thenReturn(Mono.just(redisData));
        StepVerifier.create(redisHelper.getRequiredDataFromRedis(paramList)).verifyComplete();
    }

    @Test
    public void getMtnDataForDataCircuitTest() throws JsonProcessingException {
        String key= CartConstants.DATA_CIRCUIT_ID;
        String mtnData="123456";
        when(sessionBean.setSessionData(Mockito.any(), Mockito.any())).thenReturn(Mono.just(false));
        when(sessionBean.getSessionData(Mockito.any(),Mockito.any())).thenReturn(Mono.just(new HashMap<>()));
        StepVerifier.create(redisHelper3.getMtnData(key,mtnData)).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void getFetchProfileInfoFromRedis()  {

         Map<String,String> info =new HashMap<>();
        info.put(ACCOUNT_NUMBER,"123456");
        info.put(MTN,"1234567899");
        when(sessionBean.getSessionData(Mockito.any())).thenReturn(Mono.just(info));
        StepVerifier.create(redisHelper3.fetchProfileInfoFromRedis())
                .assertNext(Assert::assertNotNull).expectComplete().verify();


        when(sessionBean.getSessionData(Mockito.any())).thenReturn(Mono.empty());
        StepVerifier.create(redisHelper3.fetchProfileInfoFromRedis())
                .assertNext(Assert::assertNotNull).expectComplete().verify();


    }

    @Test
    public void getDataFromRedisTest() throws JsonProcessingException {
        String plan = "{\"newLine1\":{\"path\":\"dummy\",\"action\":\"dummy\"}}";
        Map sessionData = new HashMap<Object,Object>();
        sessionData.put(CartConstants.PLAN_SELECTION_PATH, plan);

        when(sessionBean.getSessionData(Mockito.any())).thenReturn(Mono.just(sessionData));
        StepVerifier.create(redisHelper3.getDataFromRedis())
                .assertNext(Assert::assertNotNull).expectComplete().verify();

        when(sessionBean.getSessionData(Mockito.any())).thenReturn(Mono.empty());
        StepVerifier.create(redisHelper3.getDataFromRedis())
                .assertNext(Assert::assertNotNull).expectComplete().verify();

        sessionData.put(CartConstants.PLAN_SELECTION_PATH, null);
        when(sessionBean.getSessionData(Mockito.any())).thenReturn(Mono.just(sessionData));
        StepVerifier.create(redisHelper3.getDataFromRedis())
                .assertNext(Assert::assertNotNull).expectComplete().verify();


        sessionData.put(CartConstants.PLAN_SELECTION_PATH, "");
        when(sessionBean.getSessionData(Mockito.any())).thenReturn(Mono.just(sessionData));
        StepVerifier.create(redisHelper3.getDataFromRedis())
                .assertNext(Assert::assertNotNull).expectComplete().verify();

        sessionData.put(CartConstants.BBY_LOCAL_ORDER_LOC_DETAILS, "");
        when(sessionBean.getSessionData(Mockito.any())).thenReturn(Mono.just(sessionData));
        StepVerifier.create(redisHelper.getDataFromRedis())
                .assertNext(Assert::assertNotNull).expectComplete().verify();

        sessionData.put(CartConstants.BBY_LOCAL_ORDER_LOC_DETAILS, new HashMap<>());
        when(sessionBean.getSessionData(Mockito.any())).thenReturn(Mono.just(sessionData));
        StepVerifier.create(redisHelper.getDataFromRedis())
                .assertNext(Assert::assertNotNull).expectComplete().verify();

       sessionData.put(CartConstants.BBY_LOCAL_ORDER_LOC_DETAILS, null);
        when(sessionBean.getSessionData(Mockito.any())).thenReturn(Mono.just(sessionData));
        StepVerifier.create(redisHelper.getDataFromRedis())
                .assertNext(Assert::assertNotNull).expectComplete().verify();
    }



}
