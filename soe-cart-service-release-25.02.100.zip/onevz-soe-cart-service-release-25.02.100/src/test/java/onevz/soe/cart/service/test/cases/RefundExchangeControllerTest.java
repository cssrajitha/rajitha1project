package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.controller.RefundExchangeController;
import onevz.soe.cart.helper.RedisHelper2;
import onevz.soe.cart.requests.UpdateUserSessionRequest;
import onevz.soe.cart.responses.UpdateUserSessionResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.bind.WebDataBinder;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(RefundExchangeController.class)
public class RefundExchangeControllerTest {
	
	@Autowired
	RefundExchangeController refundExchangeController;
	
	@Autowired
	private ObjectMapper mapper;

	@MockBean
	private RedisHelper2 redisHelper2;
	
	@Test
	public void updateUserSessionTest() throws IOException {
		
		ServerHttpResponse httpResponse = null;
		ServerHttpRequest httpRequest= null;
		String requestString = "{\"data\":{\"cartId\":\"036546cc-7f6b-4a49-9a83-8a9c1c49b8a9\",\"caseId\":\"SOA-3568094-C01\",\"cartCreator\":\"2060084\"}}";
		
		UpdateUserSessionRequest request = mapper.readValue(requestString, UpdateUserSessionRequest.class);
		Map<String,String> sessionData = new HashMap<String,String>();
		
		sessionData.put(CartConstants.INTENDTYPE, CartConstants.REX);
		sessionData.put(CartConstants.INTENTTYPE, CartConstants.REX);
		sessionData.put(CartConstants.FLOW, CartConstants.REFUND_EXC);
		sessionData.put(CartConstants.CASEID, request.getData().getCaseId());
		sessionData.put(CartConstants.CARTID, request.getData().getCartId());
		sessionData.put(CartConstants.CART_CREATOR, request.getData().getCartCreator());
		
		when(redisHelper2.upsertDataInRedis(sessionData)).thenReturn(Mono.empty());
		
		Mono<UpdateUserSessionResponse> controllerResponse = refundExchangeController.updateUserSession(httpRequest, httpResponse, request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertEquals("redis upsert done successfully", resp.getMessage())).expectComplete().verify();
		
	}

	@Test
	public void initBinderByNameTest() {
		WebDataBinder binder = new WebDataBinder(null);
		refundExchangeController.initBinderByName(binder);
		assertNotNull(binder.getDisallowedFields());
	}

}
