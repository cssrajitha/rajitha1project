package onevz.soe.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.requests.SaveQuickAccessoryRequest;
import onevz.soe.cart.ui.responses.SaveQuickAccessoryResponse;
import onevz.soe.datastore.client.StoreCustomerDatastoreClient;
import onevz.soe.datastore.model.CustomerData;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { CartServiceTestConfig.class })
public class SaveQuickAccessoryToCartHelperTest {

    @InjectMocks
    private SaveQuickAccessoryToCartHelper mockHelper;

    @Mock
    private StoreCustomerDatastoreClient datastoreClient;
    @Autowired
    ObjectMapper mapper;

    private SaveQuickAccessoryRequest request;
    String customerDataString;

    @Before
    public void setup() throws JsonProcessingException {
        ReflectionTestUtils.setField(mockHelper, "objectMapper", mapper);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        String requestJson = "{\"cartId\":\"c1b16416-55f1-45b7-88cb-dc059ef4e752\",\"flowType\":\"QuickAccessory\",\"lines\":[{\"accessories\":[{\"depletionType\":\"L\",\"qty\":1,\"sorId\":\"MV7N2AM/A\"}]}]}";
        request = mapper.readValue(requestJson, SaveQuickAccessoryRequest.class);
        CustomerData customerData = new CustomerData();
        customerData.setAuthenticationRequired("true");
        customerData.setVerified("true");
        customerDataString = mapper.writeValueAsString(customerData);
    }

    @Test
    public void saveQuickAccessory() {
        when(datastoreClient.readStoreCustomerData(anyString(), anyString())).thenReturn(Mono.just(customerDataString));
        when(datastoreClient.upsertStoreCustomerData(any(), any(), any())).thenReturn(Mono.just(true));
        Mono<SaveQuickAccessoryResponse> response = mockHelper.saveQuickAccessory(request);
        StepVerifier.create(response).assertNext(Assertions::assertNotNull).expectComplete().verify();
    }
    @Test
    public void saveQuickAccessoryOnJsonException() {
        String data = "{\"ordLocation\":\"0026301\",\"userId\":\"FNPOSAUT\",}";
        when(datastoreClient.readStoreCustomerData(anyString(), anyString())).thenReturn(Mono.just(data));
        when(datastoreClient.upsertStoreCustomerData(any(), any(), any())).thenReturn(Mono.just(true));
        Mono<SaveQuickAccessoryResponse> response = mockHelper.saveQuickAccessory(request);
        StepVerifier.create(response).assertNext(Assertions::assertNotNull).expectComplete().verify();
    }
    @Test
    public void saveQuickAccessoryOnEmptyFlowType() {
        request.setFlowType("");
        when(datastoreClient.readStoreCustomerData(anyString(), anyString())).thenReturn(Mono.just(customerDataString));
        when(datastoreClient.upsertStoreCustomerData(any(), any(), any())).thenReturn(Mono.just(true));
        Mono<SaveQuickAccessoryResponse> response = mockHelper.saveQuickAccessory(request);
        StepVerifier.create(response).assertNext(Assertions::assertNotNull).expectComplete().verify();
    }
    @Test
    public void saveQuickAccessoryOnEmptyLines() {
        request.setLines(null);
        when(datastoreClient.readStoreCustomerData(anyString(), anyString())).thenReturn(Mono.just(customerDataString));
        when(datastoreClient.upsertStoreCustomerData(any(), any(), any())).thenReturn(Mono.just(true));
        Mono<SaveQuickAccessoryResponse> response = mockHelper.saveQuickAccessory(request);
        StepVerifier.create(response).assertNext(Assertions::assertNotNull).expectComplete().verify();
    }
    @Test
    public void saveQuickAccessoryOnEmptyAccessories() {
        request.getLines().get(0).setAccessories(null);
        when(datastoreClient.readStoreCustomerData(anyString(), anyString())).thenReturn(Mono.just(customerDataString));
        when(datastoreClient.upsertStoreCustomerData(any(), any(), any())).thenReturn(Mono.just(true));
        Mono<SaveQuickAccessoryResponse> response = mockHelper.saveQuickAccessory(request);
        StepVerifier.create(response).assertNext(Assertions::assertNotNull).expectComplete().verify();
    }
}
