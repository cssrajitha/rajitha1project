package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.cradle.vo.CradleResponse;
import onevz.cxp.feature.util.FeatureFlag;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.constants.FeatureFlagConstants;
import onevz.soe.cart.controller.CartUpdateOperationsController3;
import onevz.soe.cart.cxp.helper.CatalogServiceHelper;
import onevz.soe.cart.exceptions.JsonValidator;
import onevz.soe.cart.helper.*;
import onevz.soe.cart.model.addDevice.AddDeviceContext;
import onevz.soe.cart.model.addDevice.AddDeviceServiceBody;
import onevz.soe.cart.model.addDevice.AddDeviceServiceResponse;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.responses.CatalogResponse;
import onevz.soe.cart.responses.DualNumber;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.common.AddAccessoriesData;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.AddAccessoriesUIRequest;
import onevz.soe.cart.ui.requests.AddDeviceUIRequest;
import onevz.soe.cart.ui.requests.AddFeaturesUIRequest;
import onevz.soe.cart.ui.requests.UpdateEdgeupUIRequest;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.cradle.CradleAllocator;
import onevz.soe.omnidl.service.OmniDLService;
import onevz.soe.omnidl.util.DLUtilityService;
import onevz.soe.session.bean.SOELoginSessionBean;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.*;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.http.server.reactive.MockServerHttpResponse;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.net.URI;
import java.util.*;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(CartUpdateOperationsController3.class)
public class CartUpdateOperationsController3Test {

    @Autowired
    private ObjectMapper mapper;

    @Autowired
    private CartUpdateOperationsController3 cartController3;

    @MockBean
    private RedisHelper redisHelper;

    @MockBean
    private RedisHelper2 redisHelper2;

    @MockBean
    private RedisHelper3 redisHelper3;

    @MockBean
    private CartAccessoryHelper accHelper;

    @MockBean
    private CradleAllocator cradleAllocator;

    @MockBean
    private UpdateCartHelper helper;

    @MockBean
    private CradleHelper cradleHelper;

    @Value("${onevz.soe.cart.test.fileLocation}")
    private String testFileLocation;

    @Autowired
    SourceFileReaderUtil sourceFileReaderUtil;

    @MockBean
    private DLUtilityService dlUtilityService;

    @MockBean
    private CartAddDeviceHelper deviceHelper;

    @MockBean
    private JsonValidator validator;

    @MockBean
    private CartAccessoryLoggingHelper cartAccessoryLoggingHelper;

    @MockBean
    private SOELoginSessionBean soeLoginSessionBean;

    @MockBean
    FeatureFlagHelper featureFlagHelper;
    @MockBean
    private CartAddDeviceHelper1 deviceHelper2;
    @MockBean
    CatalogServiceHelper catalogServiceHelper;
    @MockBean
    OmniDLHelper omniDLHelper;

    @MockBean
    private OmniDLService dlService;

    @MockBean
    FeatureFlag featureFlag;

    @Before
    public void setup()
    {
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
    }

    @Test
    public void addAccessoryNotWhitelistMtnTest() throws IOException {
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();

        String requestFile = "data/CartUpdateOperationsControllerTestJson/addAccessoryNotWhitelistMtnRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addAccessoryNotWhitelistMtnResponse.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/add-accessories");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("digital_ig_session", "VZW-DOTCOM-1").header("mtn", "8437299178").cookie(new HttpCookie("digital_ig_session", "digital_1")).cookie(new HttpCookie("ecpdcookie", "1234")).cookie(new HttpCookie("domainCookie", "ecpd")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        String output = "{\"inputTrialType\":\"BAU\",\"cradleFlowJourney\":\"\",\"trialType\":\"BAU\",\"decisionConfig\":{\"httpMethod\":\"GET\",\"useAemTemplate\":false},\"throttleList\":\"|test|vltmap_pdp|PDP_OOS|typeahead_here_pdp|PDPStrategicOffers|Next_JS_Test|L_BAU_C_PChk|N_BAU_C__SLP|N_PLAN|AP_C_D1|PdpCfg_CL|\",\"taggingName\":\"BAU\",\"visitedPages\":\";160;180;6;\",\"allocationType\":\"S38:NoTrial|S40:NoTrial|S41:NoTrial|S53:NoTrial|S58:NoTrial|S59:NoTrial|S68:NoTrial|S74:NoTrial|S79:NoTrial|S80:NoTrial|S103:NoTrial\"}', statusCode=200, errorMessage='null', cradleProps={}, nsaRedirect=false}";
        CradleResponse cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(output);
        Map<String,Object> redisMtnMap = new HashMap<>();
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(cradleResponse));
        when(redisHelper3.getMTNFromRedis(Mockito.any())).thenReturn(Mono.just(redisMtnMap));
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(cradleHelper.getThrottlingList(Mockito.anyMap(), Mockito.any(), Mockito.any())).thenReturn(Mono.just("NSA"));
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(false);
        List<String> requiredDataKeys = Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE);
        Map<String,String> redisData = new HashMap<>();
        redisData.put("cartCount","1");
        redisData.put("cartOrderFlowType","eup");
        when(redisHelper.getRequiredDataFromRedis(requiredDataKeys)).thenReturn(Mono.just(redisData));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpRequest, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(res -> {
            Assert.assertEquals(200, res.getStatusCodeValue());
        }).expectComplete().verify();
    }
    @Test
    public void addAccessoryMtnFromRedisWhitelistMtnTest() throws IOException {
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addAccessoryMtnFromRedisWhitelistMtnRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addAccessoryNotWhitelistMtnResponse.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/add-accessories");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        String output = "{\"inputTrialType\":\"BAU\",\"cradleFlowJourney\":\"\",\"trialType\":\"BAU\",\"decisionConfig\":{\"httpMethod\":\"GET\",\"useAemTemplate\":false},\"throttleList\":\"|XBOX|vltmap_pdp|PDP_OOS|typeahead_here_pdp|PDPStrategicOffers|Next_JS_Test|L_BAU_C_PChk|N_BAU_C__SLP|N_PLAN|AP_C_D1|PdpCfg_CL|\",\"taggingName\":\"BAU\",\"visitedPages\":\";160;180;6;\",\"allocationType\":\"S38:NoTrial|S40:NoTrial|S41:NoTrial|S53:NoTrial|S58:NoTrial|S59:NoTrial|S68:NoTrial|S74:NoTrial|S79:NoTrial|S80:NoTrial|S103:NoTrial\"}', statusCode=200, errorMessage='null', cradleProps={}, nsaRedirect=false}";
        CradleResponse cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(output);
        Map<String,Object> redisMtnMap = new HashMap<>();
        redisMtnMap.put("mtn", "8437299178");
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(cradleResponse));
        when(redisHelper3.getMTNFromRedis(Mockito.any())).thenReturn(Mono.just(redisMtnMap));
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(false);
        List<String> requiredDataKeys = Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE);
        Map<String,String> redisData = new HashMap<>();
        redisData.put("cartCount","1");
        redisData.put("cartOrderFlowType","eup");
        when(redisHelper.getRequiredDataFromRedis(requiredDataKeys)).thenReturn(Mono.just(redisData));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpRequest, httpResponse,
                request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void addAccessoryMtnFromHeaderWhitelistMtnTest() throws IOException {
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addAccessoryMtnFromRedisWhitelistMtnRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addAccessoryNotWhitelistMtnResponse.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/add-accessories");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        String output = "{\"inputTrialType\":\"BAU\",\"cradleFlowJourney\":\"\",\"trialType\":\"BAU\",\"decisionConfig\":{\"httpMethod\":\"GET\",\"useAemTemplate\":false},\"throttleList\":\"|XBOX|vltmap_pdp|PDP_OOS|typeahead_here_pdp|PDPStrategicOffers|Next_JS_Test|L_BAU_C_PChk|N_BAU_C__SLP|N_PLAN|AP_C_D1|PdpCfg_CL|\",\"taggingName\":\"BAU\",\"visitedPages\":\";160;180;6;\",\"allocationType\":\"S38:NoTrial|S40:NoTrial|S41:NoTrial|S53:NoTrial|S58:NoTrial|S59:NoTrial|S68:NoTrial|S74:NoTrial|S79:NoTrial|S80:NoTrial|S103:NoTrial\"}', statusCode=200, errorMessage='null', cradleProps={}, nsaRedirect=false}";
        CradleResponse cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(output);
        Map<String,Object> redisMtnMap = new HashMap<>();
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(cradleResponse));
        when(redisHelper3.getMTNFromRedis(Mockito.any())).thenReturn(Mono.just(redisMtnMap));
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(false));
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(false);
        List<String> requiredDataKeys = Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE);
        Map<String,String> redisData = new HashMap<>();
        redisData.put("cartCount","1");
        redisData.put("cartOrderFlowType","eup");
        when(redisHelper.getRequiredDataFromRedis(requiredDataKeys)).thenReturn(Mono.just(redisData));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpRequest, httpResponse,
                request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }


    @Test
    public void addAccessoryWhitelistNotApplicable() throws IOException {
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addAccessoryMtnFromRedisWhitelistMtnRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addAccessoryNotWhitelistMtnResponse.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/add-accessories");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        String output = "{\"inputTrialType\":\"BAU\",\"cradleFlowJourney\":\"\",\"trialType\":\"BAU\",\"decisionConfig\":{\"httpMethod\":\"GET\",\"useAemTemplate\":false},\"throttleList\":\"|test|vltmap_pdp|PDP_OOS|typeahead_here_pdp|PDPStrategicOffers|Next_JS_Test|L_BAU_C_PChk|N_BAU_C__SLP|N_PLAN|AP_C_D1|PdpCfg_CL|\",\"taggingName\":\"BAU\",\"visitedPages\":\";160;180;6;\",\"allocationType\":\"S38:NoTrial|S40:NoTrial|S41:NoTrial|S53:NoTrial|S58:NoTrial|S59:NoTrial|S68:NoTrial|S74:NoTrial|S79:NoTrial|S80:NoTrial|S103:NoTrial\"}', statusCode=200, errorMessage='null', cradleProps={}, nsaRedirect=false}";
        CradleResponse cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(output);
        Map<String,Object> redisMtnMap = new HashMap<>();
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(cradleResponse));
        when(redisHelper3.getMTNFromRedis(Mockito.any())).thenReturn(Mono.just(redisMtnMap));
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(false);
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        List<String> requiredDataKeys = Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE);
        Map<String,String> redisData = new HashMap<>();
        redisData.put("cartCount","1");
        redisData.put("cartOrderFlowType","eup");
        when(redisHelper.getRequiredDataFromRedis(requiredDataKeys)).thenReturn(Mono.just(redisData));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpRequest, httpResponse,
                request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void addAccessoryTestForWhiteListedMtn() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addAccessoryIspuFlowRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addAccessoryNotWhitelistMtnResponse.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/add-accessories");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        String channelId = "OMNI-RETAIL";
        StepVerifier.create( cartController3.isMtnWhitelistedAddAccessoryRequired(httpHeader, httpResponse, channelId,request))
                .assertNext( val -> Assert.assertTrue(val));
    }

    @Test
    public void addAccessoryTestForWhiteListedMtn1() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addAccessory1Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addAccessoryNotWhitelistMtnResponse.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/add-accessories");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        String channelId = "VZW-DOTCOM-MOB";
        StepVerifier.create( cartController3.isMtnWhitelistedAddAccessoryRequired(httpHeader, httpResponse, channelId,request))
                .assertNext( val -> Assert.assertTrue(val));
    }

    @Test
    public void addAccessoryTestForWhiteListedMtn2() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addAccessory2Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addAccessoryNotWhitelistMtnResponse.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/add-accessories");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        String channelId = "VZW-DOTCOM";
        StepVerifier.create( cartController3.isMtnWhitelistedAddAccessoryRequired(httpHeader, httpResponse, channelId,request))
                .assertNext( val -> Assert.assertTrue(val));

    }

    @Test
    public void addAccessoryTestForWhiteListedMtn3() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addAccessory3Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addAccessoryNotWhitelistMtnResponse.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/add-accessories");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        String channelId = "VZW-DOTCOM";
        StepVerifier.create( cartController3.isMtnWhitelistedAddAccessoryRequired(httpHeader, httpResponse, channelId,request))
                .assertNext(val -> Assert.assertTrue(val));
    }

    @Test
    public void addAccessory404FromPegaTest() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addAccessory404PegaRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addAccessory404PegaResponse.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/cart/add-accessories");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-MFA-IOS").header("mtn", "8437299178").cookie(new HttpCookie("cookie", "cookie")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.NOT_FOUND);
        String output = "{\"inputTrialType\":\"BAU\",\"cradleFlowJourney\":\"\",\"trialType\":\"BAU\",\"decisionConfig\":{\"httpMethod\":\"GET\",\"useAemTemplate\":false},\"throttleList\":\"|test|vltmap_pdp|PDP_OOS|typeahead_here_pdp|PDPStrategicOffers|Next_JS_Test|L_BAU_C_PChk|N_BAU_C__SLP|N_PLAN|AP_C_D1|PdpCfg_CL|\",\"taggingName\":\"BAU\",\"visitedPages\":\";160;180;6;\",\"allocationType\":\"S38:NoTrial|S40:NoTrial|S41:NoTrial|S53:NoTrial|S58:NoTrial|S59:NoTrial|S68:NoTrial|S74:NoTrial|S79:NoTrial|S80:NoTrial|S103:NoTrial\"}', statusCode=200, errorMessage='null', cradleProps={}, nsaRedirect=false}";
        CradleResponse cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(output);
        Map<String,Object> redisMtnMap = new HashMap<>();
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(cradleResponse));
        when(redisHelper3.getMTNFromRedis(Mockito.any())).thenReturn(Mono.just(redisMtnMap));
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(cradleHelper.getThrottlingList(Mockito.anyMap(), Mockito.any(), Mockito.any())).thenReturn(Mono.just("NSA"));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(cartAccessoryLoggingHelper.logAccessoryInkibana(Mockito.any())).thenReturn(Mono.just(new Object()));
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(false);
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        when(helper.populateCustomerProfileCookieIfPresent(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        List<String> requiredDataKeys = Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE);
        Map<String,String> redisData = new HashMap<>();
        redisData.put("cartCount","1");
        redisData.put("cartOrderFlowType","eup");
        when(redisHelper.getRequiredDataFromRedis(requiredDataKeys)).thenReturn(Mono.just(redisData));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpRequest, httpResponse, request);

        StepVerifier.create(controllerResponse).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();

    }

    @Test
    public void addAccessoryTest() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addAccessoryEcomRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addAccessoryNotWhitelistMtnResponse.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/cart/nse/add-accessories");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("digital_ig_session", "VZW-DOTCOM-1").header("mtn", "8437299178").cookie(new HttpCookie("digital_ig_session", "digital_1")).cookie(new HttpCookie("ecpdcookie", "1234")).cookie(new HttpCookie("domainCookie", "ecpd")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        String output = "{\"inputTrialType\":\"BAU\",\"cradleFlowJourney\":\"\",\"trialType\":\"BAU\",\"decisionConfig\":{\"httpMethod\":\"GET\",\"useAemTemplate\":false},\"throttleList\":\"|test|vltmap_pdp|PDP_OOS|typeahead_here_pdp|PDPStrategicOffers|Next_JS_Test|L_BAU_C_PChk|N_BAU_C__SLP|N_PLAN|AP_C_D1|PdpCfg_CL|\",\"taggingName\":\"BAU\",\"visitedPages\":\";160;180;6;\",\"allocationType\":\"S38:NoTrial|S40:NoTrial|S41:NoTrial|S53:NoTrial|S58:NoTrial|S59:NoTrial|S68:NoTrial|S74:NoTrial|S79:NoTrial|S80:NoTrial|S103:NoTrial\"}', statusCode=200, errorMessage='null', cradleProps={}, nsaRedirect=false}";
        CradleResponse cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(output);
        Map<String,Object> redisMtnMap = new HashMap<>();
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(cradleResponse));
        when(redisHelper3.getMTNFromRedis(Mockito.any())).thenReturn(Mono.just(redisMtnMap));
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(cradleHelper.getThrottlingList(Mockito.anyMap(), Mockito.any(), Mockito.any())).thenReturn(Mono.just("NSA"));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(new ErrorResponse());
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(false);
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        List<String> requiredDataKeys = Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE);
        Map<String,String> redisData = new HashMap<>();
        redisData.put("cartCount","1");
        redisData.put("cartOrderFlowType","eup");
        when(redisHelper.getRequiredDataFromRedis(requiredDataKeys)).thenReturn(Mono.just(redisData));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(res -> Assert.assertEquals(400, res.getStatusCodeValue())).expectComplete().verify();
    }

    @Test
    public void addAccessoryTest2() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addAccessory2ErrRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addAccessory2ErrResponse.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("digital_ig_session", "VZW-DOTCOM-1").header("mtn", "8437299178").cookie(new HttpCookie("digital_ig_session", "digital_1")).cookie(new HttpCookie("ecpdcookie", "1234")).cookie(new HttpCookie("domainCookie", "ecpd")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        String output = "{\"inputTrialType\":\"BAU\",\"cradleFlowJourney\":\"\",\"trialType\":\"BAU\",\"decisionConfig\":{\"httpMethod\":\"GET\",\"useAemTemplate\":false},\"throttleList\":\"|test|vltmap_pdp|PDP_OOS|typeahead_here_pdp|PDPStrategicOffers|Next_JS_Test|L_BAU_C_PChk|N_BAU_C__SLP|N_PLAN|AP_C_D1|PdpCfg_CL|\",\"taggingName\":\"BAU\",\"visitedPages\":\";160;180;6;\",\"allocationType\":\"S38:NoTrial|S40:NoTrial|S41:NoTrial|S53:NoTrial|S58:NoTrial|S59:NoTrial|S68:NoTrial|S74:NoTrial|S79:NoTrial|S80:NoTrial|S103:NoTrial\"}', statusCode=200, errorMessage='null', cradleProps={}, nsaRedirect=false}";
        CradleResponse cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(output);
        Map<String,Object> redisMtnMap = new HashMap<>();
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(cradleResponse));
        when(redisHelper3.getMTNFromRedis(Mockito.any())).thenReturn(Mono.just(redisMtnMap));
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(cradleHelper.getThrottlingList(Mockito.anyMap(), Mockito.any(), Mockito.any())).thenReturn(Mono.just("NSA"));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(false);
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        List<String> requiredDataKeys = Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE);
        Map<String,String> redisData = new HashMap<>();
        redisData.put(CartConstants.CART_COUNT,"1");
        redisData.put(CartConstants.CART_ORDER_FLOW_TYPE,"eup");
        when(redisHelper.getRequiredDataFromRedis(requiredDataKeys)).thenReturn(Mono.just(redisData));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(res -> Assert.assertEquals(400, res.getStatusCodeValue())).expectComplete().verify();
    }

    @Test
    public void addAccessoryTest3() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addAccessory4Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addAccessory4Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/cart/nse/add-accessories");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").cookie(new HttpCookie("digital_ig_session", "digital_1")).cookie(new HttpCookie("ecpdcookie", "1:2:3:4")).cookie(new HttpCookie("domainCookie", "ecpd")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.ACCEPTED);
        String output = "{\"inputTrialType\":\"BAU\",\"cradleFlowJourney\":\"\",\"trialType\":\"BAU\",\"decisionConfig\":{\"httpMethod\":\"GET\",\"useAemTemplate\":false},\"throttleList\":\"|test|vltmap_pdp|PDP_OOS|typeahead_here_pdp|PDPStrategicOffers|Next_JS_Test|L_BAU_C_PChk|N_BAU_C__SLP|N_PLAN|AP_C_D1|PdpCfg_CL|\",\"taggingName\":\"BAU\",\"visitedPages\":\";160;180;6;\",\"allocationType\":\"S38:NoTrial|S40:NoTrial|S41:NoTrial|S53:NoTrial|S58:NoTrial|S59:NoTrial|S68:NoTrial|S74:NoTrial|S79:NoTrial|S80:NoTrial|S103:NoTrial\"}', statusCode=200, errorMessage='null', cradleProps={}, nsaRedirect=false}";
        CradleResponse cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(output);
        Map<String,Object> redisMtnMap = new HashMap<>();
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(cradleResponse));
        when(redisHelper3.getMTNFromRedis(Mockito.any())).thenReturn(Mono.just(redisMtnMap));
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(cradleHelper.getThrottlingList(Mockito.anyMap(), Mockito.any(), Mockito.any())).thenReturn(Mono.just("NSA"));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(cartAccessoryLoggingHelper.logAccessoryInkibana(Mockito.any())).thenReturn(Mono.just(new Object()));
        when(helper.populateCustomerProfileCookieIfPresent(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(false);
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        List<String> requiredDataKeys = Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE);
        Map<String,String> redisData = new HashMap<>();
        redisData.put(CartConstants.CART_COUNT,"1");
        redisData.put(CartConstants.CART_ORDER_FLOW_TYPE,"eup");
        when(redisHelper.getRequiredDataFromRedis(requiredDataKeys)).thenReturn(Mono.just(redisData));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();
        response.getServiceBody().getServiceResponse().getContext().getContextInfo().setProcessStep(CartConstants.ACCESSORIES_INTERSTIAL);
        controllerResponse = cartController3.addAccessory(httpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();
    }

    @Test
    public void addAccessoryTest4() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addAccessory5Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addAccessoryNotWhitelistMtnResponse.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/cart/nse/add-accessories");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").cookie(new HttpCookie("cookie", "cookie")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.ACCEPTED);
        String output = "{\"inputTrialType\":\"BAU\",\"cradleFlowJourney\":\"\",\"trialType\":\"BAU\",\"decisionConfig\":{\"httpMethod\":\"GET\",\"useAemTemplate\":false},\"throttleList\":\"|test|vltmap_pdp|PDP_OOS|typeahead_here_pdp|PDPStrategicOffers|Next_JS_Test|L_BAU_C_PChk|N_BAU_C__SLP|N_PLAN|AP_C_D1|PdpCfg_CL|\",\"taggingName\":\"BAU\",\"visitedPages\":\";160;180;6;\",\"allocationType\":\"S38:NoTrial|S40:NoTrial|S41:NoTrial|S53:NoTrial|S58:NoTrial|S59:NoTrial|S68:NoTrial|S74:NoTrial|S79:NoTrial|S80:NoTrial|S103:NoTrial\"}', statusCode=200, errorMessage='null', cradleProps={}, nsaRedirect=false}";
        CradleResponse cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(output);
        Map<String,Object> redisMtnMap = new HashMap<>();
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(cradleResponse));
        when(redisHelper3.getMTNFromRedis(Mockito.any())).thenReturn(Mono.just(redisMtnMap));
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(cradleHelper.getThrottlingList(Mockito.anyMap(), Mockito.any(), Mockito.any())).thenReturn(Mono.just("NSA"));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(cartAccessoryLoggingHelper.logAccessoryInkibana(Mockito.any())).thenReturn(Mono.just(new Object()));
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(false);
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));

        when(helper.populateCustomerProfileCookieIfPresent(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();
    }

    @Test
    public void addAccessoryTest5() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addAccessory6Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addAccessoryNotWhitelistMtnResponse.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/cart/add-accessories");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").cookie(new HttpCookie("cookie", "cookie")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.ACCEPTED);
        String output = "{\"inputTrialType\":\"BAU\",\"cradleFlowJourney\":\"\",\"trialType\":\"BAU\",\"decisionConfig\":{\"httpMethod\":\"GET\",\"useAemTemplate\":false},\"throttleList\":\"|test|vltmap_pdp|PDP_OOS|typeahead_here_pdp|PDPStrategicOffers|Next_JS_Test|L_BAU_C_PChk|N_BAU_C__SLP|N_PLAN|AP_C_D1|PdpCfg_CL|\",\"taggingName\":\"BAU\",\"visitedPages\":\";160;180;6;\",\"allocationType\":\"S38:NoTrial|S40:NoTrial|S41:NoTrial|S53:NoTrial|S58:NoTrial|S59:NoTrial|S68:NoTrial|S74:NoTrial|S79:NoTrial|S80:NoTrial|S103:NoTrial\"}', statusCode=200, errorMessage='null', cradleProps={}, nsaRedirect=false}";
        CradleResponse cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(output);
        Map<String,Object> redisMtnMap = new HashMap<>();
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(cradleResponse));
        when(redisHelper3.getMTNFromRedis(Mockito.any())).thenReturn(Mono.just(redisMtnMap));
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(cradleHelper.getThrottlingList(Mockito.anyMap(), Mockito.any(), Mockito.any())).thenReturn(Mono.just("NSA"));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(cartAccessoryLoggingHelper.logAccessoryInkibana(Mockito.any())).thenReturn(Mono.just(new Object()));
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(false);
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        when(helper.populateCustomerProfileCookieIfPresent(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();
    }

    @Test
    public void addAccessoryTest6() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addAccessory7Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addAccessory7Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/cart/add-accessories");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-CARE").header("mtn", "8437299178").cookie(new HttpCookie("cookie", "cookie")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.ACCEPTED);
        String output = "{\"inputTrialType\":\"BAU\",\"cradleFlowJourney\":\"\",\"trialType\":\"BAU\",\"decisionConfig\":{\"httpMethod\":\"GET\",\"useAemTemplate\":false},\"throttleList\":\"|test|vltmap_pdp|PDP_OOS|typeahead_here_pdp|PDPStrategicOffers|Next_JS_Test|L_BAU_C_PChk|N_BAU_C__SLP|N_PLAN|AP_C_D1|PdpCfg_CL|\",\"taggingName\":\"BAU\",\"visitedPages\":\";160;180;6;\",\"allocationType\":\"S38:NoTrial|S40:NoTrial|S41:NoTrial|S53:NoTrial|S58:NoTrial|S59:NoTrial|S68:NoTrial|S74:NoTrial|S79:NoTrial|S80:NoTrial|S103:NoTrial\"}', statusCode=200, errorMessage='null', cradleProps={}, nsaRedirect=false}";
        CradleResponse cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(output);
        Map<String,Object> redisMtnMap = new HashMap<>();
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(cradleResponse));
        when(redisHelper3.getMTNFromRedis(Mockito.any())).thenReturn(Mono.just(redisMtnMap));
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(cradleHelper.getThrottlingList(Mockito.anyMap(), Mockito.any(), Mockito.any())).thenReturn(Mono.just("NSA"));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(cartAccessoryLoggingHelper.logAccessoryInkibana(Mockito.any())).thenReturn(Mono.just(new Object()));
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(false);
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        when(helper.populateCustomerProfileCookieIfPresent(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();
        List<String> requiredDataKeys = Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE);
        Map<String,String> redisData = new HashMap<>();
        redisData.put("cartCount","1");
        redisData.put("cartOrderFlowType","eup");
        when(redisHelper.getRequiredDataFromRedis(requiredDataKeys)).thenReturn(Mono.just(redisData));
        when(redisHelper.addFlowNameToRedis(Mockito.any())).thenReturn(Mono.just(true));
        controllerResponse = cartController3.addAccessory(httpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();

    }

    @Test
    public void addAccessoryTest7() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addAccessory8Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addAccessory8Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/cart/add-accessories");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").cookie(new HttpCookie("cookie", "cookie")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.ACCEPTED);
        String output = "{\"inputTrialType\":\"BAU\",\"cradleFlowJourney\":\"\",\"trialType\":\"BAU\",\"decisionConfig\":{\"httpMethod\":\"GET\",\"useAemTemplate\":false},\"throttleList\":\"|test|vltmap_pdp|PDP_OOS|typeahead_here_pdp|PDPStrategicOffers|Next_JS_Test|L_BAU_C_PChk|N_BAU_C__SLP|N_PLAN|AP_C_D1|PdpCfg_CL|\",\"taggingName\":\"BAU\",\"visitedPages\":\";160;180;6;\",\"allocationType\":\"S38:NoTrial|S40:NoTrial|S41:NoTrial|S53:NoTrial|S58:NoTrial|S59:NoTrial|S68:NoTrial|S74:NoTrial|S79:NoTrial|S80:NoTrial|S103:NoTrial\"}', statusCode=200, errorMessage='null', cradleProps={}, nsaRedirect=false}";
        CradleResponse cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(output);
        Map<String,Object> redisMtnMap = new HashMap<>();
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(cradleResponse));
        when(redisHelper3.getMTNFromRedis(Mockito.any())).thenReturn(Mono.just(redisMtnMap));
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(cradleHelper.getThrottlingList(Mockito.anyMap(), Mockito.any(), Mockito.any())).thenReturn(Mono.just("NSA"));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(false);
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        when(cartAccessoryLoggingHelper.logAccessoryInkibana(Mockito.any())).thenReturn(Mono.just(new Object()));
        when(helper.populateCustomerProfileCookieIfPresent(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        List<String> requiredDataKeys = Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE);
        Map<String,String> redisData = new HashMap<>();
        redisData.put(CartConstants.CART_COUNT,"1");
        redisData.put(CartConstants.CART_ORDER_FLOW_TYPE,"eup");
        when(redisHelper.getRequiredDataFromRedis(requiredDataKeys)).thenReturn(Mono.just(redisData));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();
    }

    @Test
    public void addAccessoryTest8() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addAccessory8Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addAccessoryCartResponse.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/cart/add-accessories");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").cookie(new HttpCookie("cookie", "cookie")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.ACCEPTED);
        String output = "{\"inputTrialType\":\"BAU\",\"cradleFlowJourney\":\"\",\"trialType\":\"BAU\",\"decisionConfig\":{\"httpMethod\":\"GET\",\"useAemTemplate\":false},\"throttleList\":\"|test|vltmap_pdp|PDP_OOS|typeahead_here_pdp|PDPStrategicOffers|Next_JS_Test|L_BAU_C_PChk|N_BAU_C__SLP|N_PLAN|AP_C_D1|PdpCfg_CL|\",\"taggingName\":\"BAU\",\"visitedPages\":\";160;180;6;\",\"allocationType\":\"S38:NoTrial|S40:NoTrial|S41:NoTrial|S53:NoTrial|S58:NoTrial|S59:NoTrial|S68:NoTrial|S74:NoTrial|S79:NoTrial|S80:NoTrial|S103:NoTrial\"}', statusCode=200, errorMessage='null', cradleProps={}, nsaRedirect=false}";
        CradleResponse cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(output);
        Map<String,Object> redisMtnMap = new HashMap<>();
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(cradleResponse));
        when(redisHelper3.getMTNFromRedis(Mockito.any())).thenReturn(Mono.just(redisMtnMap));
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(cradleHelper.getThrottlingList(Mockito.anyMap(), Mockito.any(), Mockito.any())).thenReturn(Mono.just("NSA"));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(false);
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        when(cartAccessoryLoggingHelper.logAccessoryInkibana(Mockito.any())).thenReturn(Mono.just(new Object()));
        when(helper.populateCustomerProfileCookieIfPresent(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        List<String> requiredDataKeys = Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE);
        Map<String,String> redisData = new HashMap<>();
        redisData.put(CartConstants.CART_COUNT,"1");
        redisData.put(CartConstants.CART_ORDER_FLOW_TYPE,"eup");
        when(redisHelper.getRequiredDataFromRedis(requiredDataKeys)).thenReturn(Mono.just(redisData));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();
    }

    @Test
    public void addAccessoryTest9() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addAccessory8Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addAccessoryValidateResponse.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/cart/add-accessories");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").cookie(new HttpCookie("cookie", "cookie")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.ACCEPTED);
        String output = "{\"inputTrialType\":\"BAU\",\"cradleFlowJourney\":\"\",\"trialType\":\"BAU\",\"decisionConfig\":{\"httpMethod\":\"GET\",\"useAemTemplate\":false},\"throttleList\":\"|test|vltmap_pdp|PDP_OOS|typeahead_here_pdp|PDPStrategicOffers|Next_JS_Test|L_BAU_C_PChk|N_BAU_C__SLP|N_PLAN|AP_C_D1|PdpCfg_CL|\",\"taggingName\":\"BAU\",\"visitedPages\":\";160;180;6;\",\"allocationType\":\"S38:NoTrial|S40:NoTrial|S41:NoTrial|S53:NoTrial|S58:NoTrial|S59:NoTrial|S68:NoTrial|S74:NoTrial|S79:NoTrial|S80:NoTrial|S103:NoTrial\"}', statusCode=200, errorMessage='null', cradleProps={}, nsaRedirect=false}";
        CradleResponse cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(output);
        Map<String,Object> redisMtnMap = new HashMap<>();
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(cradleResponse));
        when(redisHelper3.getMTNFromRedis(Mockito.any())).thenReturn(Mono.just(redisMtnMap));
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(cradleHelper.getThrottlingList(Mockito.anyMap(), Mockito.any(), Mockito.any())).thenReturn(Mono.just("NSA"));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(false);
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        when(cartAccessoryLoggingHelper.logAccessoryInkibana(Mockito.any())).thenReturn(Mono.just(new Object()));
        when(helper.populateCustomerProfileCookieIfPresent(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        List<String> requiredDataKeys = Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE);
        Map<String,String> redisData = new HashMap<>();
        redisData.put(CartConstants.CART_COUNT,"1");
        redisData.put(CartConstants.CART_ORDER_FLOW_TYPE,"eup");
        when(redisHelper.getRequiredDataFromRedis(requiredDataKeys)).thenReturn(Mono.just(redisData));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();
    }

    @Test
    public void addAccessoryTest10() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addAccessory8Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addAccessory9Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/cart/nse/add-accessories");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").cookie(new HttpCookie("cookie", "cookie")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.ACCEPTED);
        String output = "{\"inputTrialType\":\"BAU\",\"cradleFlowJourney\":\"\",\"trialType\":\"BAU\",\"decisionConfig\":{\"httpMethod\":\"GET\",\"useAemTemplate\":false},\"throttleList\":\"|test|vltmap_pdp|PDP_OOS|typeahead_here_pdp|PDPStrategicOffers|Next_JS_Test|L_BAU_C_PChk|N_BAU_C__SLP|N_PLAN|AP_C_D1|PdpCfg_CL|\",\"taggingName\":\"BAU\",\"visitedPages\":\";160;180;6;\",\"allocationType\":\"S38:NoTrial|S40:NoTrial|S41:NoTrial|S53:NoTrial|S58:NoTrial|S59:NoTrial|S68:NoTrial|S74:NoTrial|S79:NoTrial|S80:NoTrial|S103:NoTrial\"}', statusCode=200, errorMessage='null', cradleProps={}, nsaRedirect=false}";
        CradleResponse cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(output);
        Map<String,Object> redisMtnMap = new HashMap<>();
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(cradleResponse));
        when(redisHelper3.getMTNFromRedis(Mockito.any())).thenReturn(Mono.just(redisMtnMap));
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(cradleHelper.getThrottlingList(Mockito.anyMap(), Mockito.any(), Mockito.any())).thenReturn(Mono.just("NSA"));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(cartAccessoryLoggingHelper.logAccessoryInkibana(Mockito.any())).thenReturn(Mono.just(new Object()));
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(false);
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        when(helper.populateCustomerProfileCookieIfPresent(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        List<String> requiredDataKeys = Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE);
        Map<String,String> redisData = new HashMap<>();
        redisData.put(CartConstants.CART_COUNT,"1");
        redisData.put(CartConstants.CART_ORDER_FLOW_TYPE,"eup");
        when(redisHelper.getRequiredDataFromRedis(requiredDataKeys)).thenReturn(Mono.just(redisData));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();
    }

    @Test
    public void addAccessoryTest11() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addAccessory8Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addAccessory10Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/cart/nse/add-accessories");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").cookie(new HttpCookie("cookie", "cookie")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.ACCEPTED);
        String output = "{\"inputTrialType\":\"BAU\",\"cradleFlowJourney\":\"\",\"trialType\":\"BAU\",\"decisionConfig\":{\"httpMethod\":\"GET\",\"useAemTemplate\":false},\"throttleList\":\"|test|vltmap_pdp|PDP_OOS|typeahead_here_pdp|PDPStrategicOffers|Next_JS_Test|L_BAU_C_PChk|N_BAU_C__SLP|N_PLAN|AP_C_D1|PdpCfg_CL|\",\"taggingName\":\"BAU\",\"visitedPages\":\";160;180;6;\",\"allocationType\":\"S38:NoTrial|S40:NoTrial|S41:NoTrial|S53:NoTrial|S58:NoTrial|S59:NoTrial|S68:NoTrial|S74:NoTrial|S79:NoTrial|S80:NoTrial|S103:NoTrial\"}', statusCode=200, errorMessage='null', cradleProps={}, nsaRedirect=false}";
        CradleResponse cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(output);
        Map<String,Object> redisMtnMap = new HashMap<>();
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(cradleResponse));
        when(redisHelper3.getMTNFromRedis(Mockito.any())).thenReturn(Mono.just(redisMtnMap));
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(cradleHelper.getThrottlingList(Mockito.anyMap(), Mockito.any(), Mockito.any())).thenReturn(Mono.just("NSA"));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(cartAccessoryLoggingHelper.logAccessoryInkibana(Mockito.any())).thenReturn(Mono.just(new Object()));
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(false);
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        when(helper.populateCustomerProfileCookieIfPresent(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();
    }

    @Test
    public void addAccessoryTest13() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addAccessory8Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addAccessory11Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/cart/nse/add-accessories");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("cdlCartInfo", "cartinfo")).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").cookie(new HttpCookie("cookie", "cookie")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.ACCEPTED);
        String output = "{\"inputTrialType\":\"BAU\",\"cradleFlowJourney\":\"\",\"trialType\":\"BAU\",\"decisionConfig\":{\"httpMethod\":\"GET\",\"useAemTemplate\":false},\"throttleList\":\"|test|vltmap_pdp|PDP_OOS|typeahead_here_pdp|PDPStrategicOffers|Next_JS_Test|L_BAU_C_PChk|N_BAU_C__SLP|N_PLAN|AP_C_D1|PdpCfg_CL|\",\"taggingName\":\"BAU\",\"visitedPages\":\";160;180;6;\",\"allocationType\":\"S38:NoTrial|S40:NoTrial|S41:NoTrial|S53:NoTrial|S58:NoTrial|S59:NoTrial|S68:NoTrial|S74:NoTrial|S79:NoTrial|S80:NoTrial|S103:NoTrial\"}', statusCode=200, errorMessage='null', cradleProps={}, nsaRedirect=false}";
        CradleResponse cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(output);
        Map<String,Object> redisMtnMap = new HashMap<>();
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(cradleResponse));
        when(redisHelper3.getMTNFromRedis(Mockito.any())).thenReturn(Mono.just(redisMtnMap));
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(cradleHelper.getThrottlingList(Mockito.anyMap(), Mockito.any(), Mockito.any())).thenReturn(Mono.just("NSA"));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(cartAccessoryLoggingHelper.logAccessoryInkibana(Mockito.any())).thenReturn(Mono.just(new Object()));
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(false);
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        List<String> requiredDataKeys = Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE);
        Map<String,String> redisData = new HashMap<>();
        redisData.put(CartConstants.CART_COUNT,"1");
        redisData.put(CartConstants.CART_ORDER_FLOW_TYPE,"eup");
        when(redisHelper.getRequiredDataFromRedis(requiredDataKeys)).thenReturn(Mono.just(redisData));
        when(helper.populateCustomerProfileCookieIfPresent(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();
    }

    @Test
    public void addAccessoryTest14() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addAccessory11Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addAccessory11Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/cart/nse/add-accessories");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("cdlCartInfo", "cartinfo")).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").cookie(new HttpCookie("cookie", "cookie")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.ACCEPTED);
        String output = "{\"inputTrialType\":\"BAU\",\"cradleFlowJourney\":\"\",\"trialType\":\"BAU\",\"decisionConfig\":{\"httpMethod\":\"GET\",\"useAemTemplate\":false},\"throttleList\":\"|test|vltmap_pdp|PDP_OOS|typeahead_here_pdp|PDPStrategicOffers|Next_JS_Test|L_BAU_C_PChk|N_BAU_C__SLP|N_PLAN|AP_C_D1|PdpCfg_CL|\",\"taggingName\":\"BAU\",\"visitedPages\":\";160;180;6;\",\"allocationType\":\"S38:NoTrial|S40:NoTrial|S41:NoTrial|S53:NoTrial|S58:NoTrial|S59:NoTrial|S68:NoTrial|S74:NoTrial|S79:NoTrial|S80:NoTrial|S103:NoTrial\"}', statusCode=200, errorMessage='null', cradleProps={}, nsaRedirect=false}";
        CradleResponse cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(output);
        Map<String,Object> redisMtnMap = new HashMap<>();
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(cradleResponse));
        when(redisHelper3.getMTNFromRedis(Mockito.any())).thenReturn(Mono.just(redisMtnMap));
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(cradleHelper.getThrottlingList(Mockito.anyMap(), Mockito.any(), Mockito.any())).thenReturn(Mono.just("NSA"));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(cartAccessoryLoggingHelper.logAccessoryInkibana(Mockito.any())).thenReturn(Mono.just(new Object()));
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(false);
        List<String> requiredDataKeys = Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE);
        Map<String,String> redisData = new HashMap<>();
        redisData.put(CartConstants.CART_COUNT,"1");
        redisData.put(CartConstants.CART_ORDER_FLOW_TYPE,"eup");
        when(redisHelper.getRequiredDataFromRedis(requiredDataKeys)).thenReturn(Mono.just(redisData));
        when(helper.populateCustomerProfileCookieIfPresent(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();
    }

    @Test
    public void addAccessoryTest15() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addAccessory15Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addAccessory15Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/cart/nse/add-accessories");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("cdlCartInfo", "cartinfo")).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").cookie(new HttpCookie("cookie", "cookie")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.ACCEPTED);
        String output = "{\"inputTrialType\":\"BAU\",\"cradleFlowJourney\":\"\",\"trialType\":\"BAU\",\"decisionConfig\":{\"httpMethod\":\"GET\",\"useAemTemplate\":false},\"throttleList\":\"|test|vltmap_pdp|PDP_OOS|typeahead_here_pdp|PDPStrategicOffers|Next_JS_Test|L_BAU_C_PChk|N_BAU_C__SLP|N_PLAN|AP_C_D1|PdpCfg_CL|\",\"taggingName\":\"BAU\",\"visitedPages\":\";160;180;6;\",\"allocationType\":\"S38:NoTrial|S40:NoTrial|S41:NoTrial|S53:NoTrial|S58:NoTrial|S59:NoTrial|S68:NoTrial|S74:NoTrial|S79:NoTrial|S80:NoTrial|S103:NoTrial\"}', statusCode=200, errorMessage='null', cradleProps={}, nsaRedirect=false}";
        CradleResponse cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(output);
        Map<String,Object> redisMtnMap = new HashMap<>();
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(cradleResponse));
        when(redisHelper3.getMTNFromRedis(Mockito.any())).thenReturn(Mono.just(redisMtnMap));
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(cradleHelper.getThrottlingList(Mockito.anyMap(), Mockito.any(), Mockito.any())).thenReturn(Mono.just("NSA"));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(cartAccessoryLoggingHelper.logAccessoryInkibana(Mockito.any())).thenReturn(Mono.just(new Object()));
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(false);
        when(helper.populateCustomerProfileCookieIfPresent(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        List<String> requiredDataKeys = Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE);
        Map<String,String> redisData = new HashMap<>();
        redisData.put(CartConstants.CART_COUNT,"1");
        redisData.put(CartConstants.CART_ORDER_FLOW_TYPE,"eup");
        when(redisHelper.getRequiredDataFromRedis(requiredDataKeys)).thenReturn(Mono.just(redisData));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();
    }

    @Test
    public void addAccessoryTest16() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addAccessory15Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{\"serviceBody\":{\"serviceResponse\":{\"context\": {\"cartInfo\": {}}}}}";
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/cart/nse/add-accessories");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("cdlCartInfo", "cartinfo")).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").cookie(new HttpCookie("cookie", "cookie")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.ACCEPTED);
        String output = "{\"inputTrialType\":\"BAU\",\"cradleFlowJourney\":\"\",\"trialType\":\"BAU\",\"decisionConfig\":{\"httpMethod\":\"GET\",\"useAemTemplate\":false},\"throttleList\":\"|test|vltmap_pdp|PDP_OOS|typeahead_here_pdp|PDPStrategicOffers|Next_JS_Test|L_BAU_C_PChk|N_BAU_C__SLP|N_PLAN|AP_C_D1|PdpCfg_CL|\",\"taggingName\":\"BAU\",\"visitedPages\":\";160;180;6;\",\"allocationType\":\"S38:NoTrial|S40:NoTrial|S41:NoTrial|S53:NoTrial|S58:NoTrial|S59:NoTrial|S68:NoTrial|S74:NoTrial|S79:NoTrial|S80:NoTrial|S103:NoTrial\"}', statusCode=200, errorMessage='null', cradleProps={}, nsaRedirect=false}";
        CradleResponse cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(output);
        Map<String,Object> redisMtnMap = new HashMap<>();
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(cradleResponse));
        when(redisHelper3.getMTNFromRedis(Mockito.any())).thenReturn(Mono.just(redisMtnMap));
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(cradleHelper.getThrottlingList(Mockito.anyMap(), Mockito.any(), Mockito.any())).thenReturn(Mono.just("NSA"));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(cartAccessoryLoggingHelper.logAccessoryInkibana(Mockito.any())).thenReturn(Mono.just(new Object()));
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(false);
        when(helper.populateCustomerProfileCookieIfPresent(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        List<String> requiredDataKeys = Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE);
        Map<String,String> redisData = new HashMap<>();
        redisData.put(CartConstants.CART_COUNT,"1");
        redisData.put(CartConstants.CART_ORDER_FLOW_TYPE,"eup");
        when(redisHelper.getRequiredDataFromRedis(requiredDataKeys)).thenReturn(Mono.just(redisData));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();
    }

    @Test
    public void addAccessoryTest17() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addAccessory15Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{\"validateCartResponse\": {\"data\": {}},\"serviceBody\":{\"serviceResponse\":{\"context\": {\"cartInfo\": {}}}}}";
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/cart/nse/add-accessories");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").cookie(new HttpCookie("cdlCartInfo", "cartinfo")).cookie(new HttpCookie("cdlCartInfo", "cartinfo2")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.ACCEPTED);
        String output = "{\"inputTrialType\":\"BAU\",\"cradleFlowJourney\":\"\",\"trialType\":\"BAU\",\"decisionConfig\":{\"httpMethod\":\"GET\",\"useAemTemplate\":false},\"throttleList\":\"|test|vltmap_pdp|PDP_OOS|typeahead_here_pdp|PDPStrategicOffers|Next_JS_Test|L_BAU_C_PChk|N_BAU_C__SLP|N_PLAN|AP_C_D1|PdpCfg_CL|\",\"taggingName\":\"BAU\",\"visitedPages\":\";160;180;6;\",\"allocationType\":\"S38:NoTrial|S40:NoTrial|S41:NoTrial|S53:NoTrial|S58:NoTrial|S59:NoTrial|S68:NoTrial|S74:NoTrial|S79:NoTrial|S80:NoTrial|S103:NoTrial\"}', statusCode=200, errorMessage='null', cradleProps={}, nsaRedirect=false}";
        CradleResponse cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(output);
        Map<String,Object> redisMtnMap = new HashMap<>();
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(cradleResponse));
        when(redisHelper3.getMTNFromRedis(Mockito.any())).thenReturn(Mono.just(redisMtnMap));
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(cradleHelper.getThrottlingList(Mockito.anyMap(), Mockito.any(), Mockito.any())).thenReturn(Mono.just("NSA"));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(accHelper.isPegaResponseValid(Mockito.any())).thenReturn(true);
        when(cartAccessoryLoggingHelper.logAccessoryInkibana(Mockito.any())).thenReturn(Mono.just(new Object()));
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(false);
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        List<String> requiredDataKeys = Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE);
        Map<String,String> redisData = new HashMap<>();
        redisData.put(CartConstants.CART_COUNT,"1");
        redisData.put(CartConstants.CART_ORDER_FLOW_TYPE,"eup");
        when(redisHelper.getRequiredDataFromRedis(requiredDataKeys)).thenReturn(Mono.just(redisData));
        when(helper.populateCustomerProfileCookieIfPresent(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();
    }

    @Test
    public void addAccessoryTest18() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addAccessory15Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-MFA-IOS\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2024.05.21.07.29.06-412.9909776884849\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"availablePaths\":[{\"path\":\"PromoHub\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PromoHub\",\"processAction\":\"\"},\"customerInfo\":{\"nocByod\":false,\"cartCreator\":\"4026191952\",\"processingMTN\":\"\",\"registerNumber\":0,\"noc\":false,\"myvPage\":false},\"cartInfo\":{\"cartItemCount\":1,\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"accessories\":{},\"status\":1,\"eupNoPromoFlow\":false,\"mtn\":\"4026191952\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false,\"instantCreditAmount\":0}}}}}";

        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/cart/add-accessories");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").header("mtn", "8437299178").cookie(new HttpCookie("cookie", "cookie")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.ACCEPTED);
        String output = "{\"inputTrialType\":\"BAU\",\"cradleFlowJourney\":\"\",\"trialType\":\"BAU\",\"decisionConfig\":{\"httpMethod\":\"GET\",\"useAemTemplate\":false},\"throttleList\":\"|test|vltmap_pdp|PDP_OOS|typeahead_here_pdp|PDPStrategicOffers|Next_JS_Test|L_BAU_C_PChk|N_BAU_C__SLP|N_PLAN|AP_C_D1|PdpCfg_CL|\",\"taggingName\":\"BAU\",\"visitedPages\":\";160;180;6;\",\"allocationType\":\"S38:NoTrial|S40:NoTrial|S41:NoTrial|S53:NoTrial|S58:NoTrial|S59:NoTrial|S68:NoTrial|S74:NoTrial|S79:NoTrial|S80:NoTrial|S103:NoTrial\"}', statusCode=200, errorMessage='null', cradleProps={}, nsaRedirect=false}";
        CradleResponse cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(output);
        Map<String,Object> redisMtnMap = new HashMap<>();
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(cradleResponse));
        when(redisHelper3.getMTNFromRedis(Mockito.any())).thenReturn(Mono.just(redisMtnMap));
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(cradleHelper.getThrottlingList(Mockito.anyMap(), Mockito.any(), Mockito.any())).thenReturn(Mono.just("NSA"));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        when(cartAccessoryLoggingHelper.logAccessoryInkibana(Mockito.any())).thenReturn(Mono.just(new Object()));
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(false);

        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("NAO"));
        //true pegaresponse
        when(accHelper.isPegaResponseValid(Mockito.any())).thenReturn(true);
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        List<String> requiredDataKeys = Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE);
        Map<String,String> redisData = new HashMap<>();
        redisData.put(CartConstants.CART_COUNT,"1");
        redisData.put(CartConstants.CART_ORDER_FLOW_TYPE,"eup");
        when(redisHelper.getRequiredDataFromRedis(requiredDataKeys)).thenReturn(Mono.just(redisData));
        when(helper.populateCustomerProfileCookieIfPresent(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();

        //false feature flag
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.FALSE));
        controllerResponse = cartController3.addAccessory(httpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();


        //empty channelId
        request.setChannelId("");
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        controllerResponse = cartController3.addAccessory(httpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();

        //null channelId
        request.setChannelId(null);
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        controllerResponse = cartController3.addAccessory(httpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();

        //notassisted channelId
        request.setChannelId("VZW-DOTCOM");
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        controllerResponse = cartController3.addAccessory(httpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();
    }
    @Test
    public void addAccessoryErrorTest() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addAccessoryError1Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addAccessoryError1Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/add-accessories");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR);
        when(accHelper.addAccessory(any())).thenReturn(Mono.just(response));
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(false);
        List<String> requiredDataKeys = Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE);
        Map<String,String> redisData = new HashMap<>();
        redisData.put(CartConstants.CART_COUNT,"1");
        redisData.put(CartConstants.CART_ORDER_FLOW_TYPE,"eup");
        when(redisHelper.getRequiredDataFromRedis(requiredDataKeys)).thenReturn(Mono.just(redisData));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addAccessoryNSETest() throws IOException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"editAccessory\":false,\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"9999999999\",\"processStep\":\"AccessoryPDP\",\"processAction\":\"addAccessory\",\"intendType\":\"NSEACC\",\"intent\":\"StandAloneAccessory\",\"expressflowForAcc\":false,\"expressCheckout\":false,\"disableMyLink\":false,\"mtnFlow\":\"D\",\"globalId\":\"\",\"customerType\":\"N\",\"zipCode\":\"30004\"},\"data\":{\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"9999999999\",\"mdnFilterValue\":\"9999999999\",\"ispuFlow\":false,\"estimatedReadyByDate\":\"\",\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"preBackOrderDate\":\"\",\"preBackOrderDisplayType\":\"\",\"addAccessories\":{\"giftCard\":false,\"id\":\"77-88673\",\"qty\":1,\"isSoftSku\":false,\"accessoryBundle\":false,\"productId\":\"acc19040401\",\"category\":\"Bundle Eligible Cases\",\"isEcpdDiscountEligilble\":false}}],\"rtm\":{\"url\":\"https://vzwqa1.verizonwireless.com/products/otterbox-defender-series-pro-case-for-iphone-14-plus/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/otterbox-defender-series-pro-case-for-skye-black-77-88673-iset\",\"name\":\"Defender Series Pro Case for iPhone 14 Plus\",\"make\":\"OtterBox\",\"categoryId\":\"Bundle Eligible Cases\",\"pageURL\":\"https://vzwqa1.verizonwireless.com/products/otterbox-defender-series-pro-case-for-iphone-14-plus/\",\"acc_url\":\"https://vzwqa1.verizonwireless.com/products/otterbox-defender-series-pro-case-for-iphone-14-plus/\",\"acc_img\":\"https://ss7.vzw.com/is/image/VerizonWireless/otterbox-defender-series-pro-case-for-skye-black-77-88673-iset\",\"acc_categoryId\":\"Bundle Eligible Cases\"}}}\n" +
                "\t\n";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.11.22.18.01.46-398.6245019793273\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-11346527-C01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"PromoHub\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PromoHub\",\"processAction\":\"\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-c5d8d921-71a1-4568-b778-bf90d04dbb23\",\"processingMTN\":\"9999999999\",\"registerNumber\":0,\"existingCase\":\"\",\"globalId\":\"POE-D-c5d8d921-71a1-4568-b778-bf90d04dbb23\"},\"cartInfo\":{\"cartItemCount\":1,\"cartId\":\"257fc74f-3e64-4f40-94d0-507626625e69\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"accessories\":{},\"status\":1,\"eupNoPromoFlow\":false,\"mtn\":\"9999999999\",\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSEACC\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDateDetails\":{},\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false},\"processMTNList\":[{\"mtn\":\"9999999999\",\"completedprocessSteps\":[]}]}}}}\n" +
                "\t\n";
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/cart/nse/add-accessories");
        HttpCookie digital_ig_session = new HttpCookie("digital_ig_session","11b5e062-c453");
        HttpCookie repIdCookie = new HttpCookie("RepIdCookieText","E420");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("digital_ig_session", digital_ig_session);
        bodyMap.add("RepIdCookieText", repIdCookie);
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("digital_ig_session", "digital_1").header("channelId","VZW-DOTCOM").cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        Map<String,Object> redisMtnMap = new HashMap<>();
        when(cartAccessoryLoggingHelper.logAccessoryInkibana(Mockito.any())).thenReturn(Mono.just(new Object()));
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(false);
        List<String> requiredDataKeys = Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE);
        Map<String,String> redisData = new HashMap<>();
        redisData.put(CartConstants.CART_COUNT,"1");
        redisData.put(CartConstants.CART_ORDER_FLOW_TYPE,"eup");
        when(redisHelper.getRequiredDataFromRedis(requiredDataKeys)).thenReturn(Mono.just(redisData));
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertTrue(httpResponse.getCookies()!=null &&
                httpResponse.getCookies().containsKey("hubProspectCart"))).expectComplete().verify();

        response.getServiceBody().getServiceResponse().getContext().setCartInfo(null);
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        request.getCartInfo().setIntendType("NSE");
        controllerResponse = cartController3.addAccessory(httpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addDeviceTest() throws IOException{
        String requestFile = "AddDeviceRequestTest.json";
        String responseFile = "AddDeviceResponseTest.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddDeviceUIRequest request = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("subFlow"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(helper.populateConflictedSPOsIfPresent(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(helper.populateHumWifiConflictedSFosWithCheck(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        request.getCartInfo().setIntendType("NSEBYOD");
        URI url = URI.create("http://localhost/flexV2/add-device");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        when(featureFlagHelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART,FeatureFlagConstants.FLAG_NAME_CART_OPERATION_WITH_UUID,true)).thenReturn(Mono.just(true));
        when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART,FeatureFlagConstants.FLAG_NAME_SET_ACNEXTGEN_FOR_MVA,false)).thenReturn(Mono.just(false));
        when(redisHelper.updateDataIntoRedisAsString(any(), anyString())).thenReturn(Mono.just(true));
        when(deviceHelper2.updateSubFlowInTaggingForNextgen(anyString(), any(), any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();

        request.getCartInfo().setIntendType("BYOD");
        controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();
        request.getCartInfo().setAccountNumber("0226079630-00001");
        when(helper.populateCustomerProfileCookieIfPresent(httpResponse, request.getCartInfo().getAccountNumber(), response)).thenReturn(Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(response)));
        controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();
    }

    @Test
    public void addDeviceWithCookieTest() throws IOException{
        String requestFile = "AddDeviceRequestTest.json";
        String responseFile = "AddDeviceResponseTest.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddDeviceUIRequest request = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(helper.populateConflictedSPOsIfPresent(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(helper.populateHumWifiConflictedSFosWithCheck(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        request.getCartInfo().setIntendType("NSEBYOD");
        URI url = URI.create("http://localhost/add-device");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").cookie(new HttpCookie("digital_ig_session", "digital_1")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        when(featureFlagHelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART,FeatureFlagConstants.FLAG_NAME_CART_OPERATION_WITH_UUID,true)).thenReturn(Mono.just(true));
        when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART,FeatureFlagConstants.FLAG_NAME_SET_ACNEXTGEN_FOR_MVA,false)).thenReturn(Mono.just(false));
        when(redisHelper.updateDataIntoRedisAsString(any(), anyString())).thenReturn(Mono.just(true));
        when(deviceHelper2.updateSubFlowInTaggingForNextgen(anyString(), any(), any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();

        request.getCartInfo().setIntendType("BYOD");
        controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();

    }

    @Test
    public void addDeviceAssistedTest() throws IOException{
        String requestFile = "AddDeviceRequestTest.json";
        String responseFile = "AddDeviceResponseTest.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddDeviceUIRequest request = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(helper.populateConflictedSPOsIfPresent(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(helper.populateHumWifiConflictedSFosWithCheck(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        request.getCartInfo().setIntendType("NSEBYOD");
        URI url = URI.create("http://localhost/add-device");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").header("mtn", "8437299178").cookie(new HttpCookie("digital_ig_session", "digital_1")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        when(featureFlagHelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART,FeatureFlagConstants.FLAG_NAME_CART_OPERATION_WITH_UUID,true)).thenReturn(Mono.just(true));
        when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART,FeatureFlagConstants.FLAG_NAME_SET_ACNEXTGEN_FOR_MVA,false)).thenReturn(Mono.just(false));
        when(redisHelper.updateDataIntoRedisAsString(any(), anyString())).thenReturn(Mono.just(true));
        when(deviceHelper2.updateSubFlowInTaggingForNextgen(anyString(), any(), any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();

        request.getCartInfo().setIntendType("BYOD");
        controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();

    }

    @Test
    public void addDeviceErrorTest() throws IOException{
        String requestFile = "AddDeviceRequestTest.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        AddDeviceUIRequest request = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = new AddDeviceUIResponse();
        CartError error = new CartError();
        List<CartError> errorList = new ArrayList<>();
        error.setCode("code");
        error.setErrorCategory("error category");
        error.setId("id");
        errorList.add(error);
        response.setErrors(errorList);
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(helper.populateConflictedSPOsIfPresent(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(helper.populateHumWifiConflictedSFosWithCheck(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        request.getCartInfo().setIntendType("NSEBYOD");
        URI url = URI.create("http://localhost/add-device");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").header("mtn", "8437299178").cookie(new HttpCookie("digital_ig_session", "digital_1")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR);
        when(featureFlagHelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART,FeatureFlagConstants.FLAG_NAME_CART_OPERATION_WITH_UUID,true)).thenReturn(Mono.just(true));
        when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART,FeatureFlagConstants.FLAG_NAME_SET_ACNEXTGEN_FOR_MVA,false)).thenReturn(Mono.just(false));
        when(redisHelper.updateDataIntoRedisAsString(any(), anyString())).thenReturn(Mono.just(true));
        when(deviceHelper2.updateSubFlowInTaggingForNextgen(anyString(), any(), any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();

        request.getCartInfo().setIntendType("BYOD");
        controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();

    }

    @Test
    public void addDeviceTest1() throws IOException{
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addDevice1Request.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addDevice1Response.json";
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddDeviceUIRequest request = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(helper.populateConflictedSPOsIfPresent(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(helper.populateHumWifiConflictedSFosWithCheck(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        request.getCartInfo().setIntendType("NSEBYOD");
        URI url = URI.create("http://localhost/cart/nse/add-device");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        when(featureFlagHelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART,FeatureFlagConstants.FLAG_NAME_CART_OPERATION_WITH_UUID,true)).thenReturn(Mono.just(true));
        when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART,FeatureFlagConstants.FLAG_NAME_SET_ACNEXTGEN_FOR_MVA,false)).thenReturn(Mono.just(false));
        when(redisHelper.updateDataIntoRedisAsString(any(), anyString())).thenReturn(Mono.just(true));
        when(deviceHelper2.updateSubFlowInTaggingForNextgen(anyString(), any(), any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();
        controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();

    }

    @Test
    public void addDeviceTest2() throws IOException{
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addDevice1Request.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addDevice2Response.json";
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddDeviceUIRequest request = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(helper.populateConflictedSPOsIfPresent(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(helper.populateHumWifiConflictedSFosWithCheck(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        request.getCartInfo().setIntendType("NSEBYOD");
        URI url = URI.create("http://localhost/cart/nse/add-device");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        when(featureFlagHelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART,FeatureFlagConstants.FLAG_NAME_CART_OPERATION_WITH_UUID,true)).thenReturn(Mono.just(true));
        when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART,FeatureFlagConstants.FLAG_NAME_SET_ACNEXTGEN_FOR_MVA,false)).thenReturn(Mono.just(false));
        when(redisHelper.updateDataIntoRedisAsString(any(), anyString())).thenReturn(Mono.just(true));
        when(deviceHelper2.updateSubFlowInTaggingForNextgen(anyString(), any(), any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();
        controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();

    }

    @Test
    public void addDeviceTest3() throws IOException{
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addDevice1Request.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addDevice3Response.json";
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddDeviceUIRequest request = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(helper.populateConflictedSPOsIfPresent(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(helper.populateHumWifiConflictedSFosWithCheck(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        request.getCartInfo().setIntendType("NSEBYOD");
        URI url = URI.create("http://localhost/cart/nse/add-device");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        when(featureFlagHelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART,FeatureFlagConstants.FLAG_NAME_CART_OPERATION_WITH_UUID,true)).thenReturn(Mono.just(true));
        when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART,FeatureFlagConstants.FLAG_NAME_SET_ACNEXTGEN_FOR_MVA,false)).thenReturn(Mono.just(false));
        when(redisHelper.updateDataIntoRedisAsString(any(), anyString())).thenReturn(Mono.just(true));
        when(deviceHelper2.updateSubFlowInTaggingForNextgen(anyString(), any(), any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();
        controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();

    }

    @Test
    public void addDeviceTest4() throws IOException{
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addDevice1Request.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addDevice4Response.json";
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddDeviceUIRequest request = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(helper.populateConflictedSPOsIfPresent(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(helper.populateHumWifiConflictedSFosWithCheck(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        request.getCartInfo().setIntendType("NSEBYOD");
        URI url = URI.create("http://localhost/cart/nse/add-device");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        when(featureFlagHelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
        controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();

    }

    @Test
    public void addDeviceTest5() throws IOException{
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addDevice1Request.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addDevice5Response.json";
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddDeviceUIRequest request = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(helper.populateConflictedSPOsIfPresent(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(helper.populateHumWifiConflictedSFosWithCheck(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        request.getCartInfo().setIntendType("NSEBYOD");
        URI url = URI.create("http://localhost/cart/nse/add-device");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART,FeatureFlagConstants.FLAG_NAME_CART_OPERATION_WITH_UUID,true)).thenReturn(Mono.just(true));
        when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART,FeatureFlagConstants.FLAG_NAME_SET_ACNEXTGEN_FOR_MVA,false)).thenReturn(Mono.just(false));
        when(redisHelper.updateDataIntoRedisAsString(any(), anyString())).thenReturn(Mono.just(true));
        when(deviceHelper2.updateSubFlowInTaggingForNextgen(anyString(), any(), any())).thenReturn(Mono.just(true));
        when(featureFlagHelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();
        controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();

    }

    @Test
    public void addDeviceTest6() throws IOException{
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addDevice6Request.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addDevice6Response.json";
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddDeviceUIRequest request = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(helper.populateConflictedSPOsIfPresent(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(helper.populateHumWifiConflictedSFosWithCheck(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        request.getCartInfo().setIntendType("NSEBYOD");
        URI url = URI.create("http://localhost/cart/nse/add-device");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").cookie(new HttpCookie("digital_ig_session", "digital_1")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        when(featureFlagHelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART,FeatureFlagConstants.FLAG_NAME_CART_OPERATION_WITH_UUID,true)).thenReturn(Mono.just(true));
        when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART,FeatureFlagConstants.FLAG_NAME_SET_ACNEXTGEN_FOR_MVA,false)).thenReturn(Mono.just(false));
        when(redisHelper.updateDataIntoRedisAsString(any(), anyString())).thenReturn(Mono.just(true));
        when(deviceHelper2.updateSubFlowInTaggingForNextgen(anyString(), any(), any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();
        controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();

    }

    @Test
    public void addDeviceTest7() throws IOException{
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addDevice7Request.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addDevice7Response.json";
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddDeviceUIRequest request = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(helper.populateConflictedSPOsIfPresent(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(helper.populateHumWifiConflictedSFosWithCheck(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        request.getCartInfo().setIntendType("NSE");
        URI url = URI.create("http://localhost/cart/nse/add-device");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").cookie(new HttpCookie("digital_ig_session", "digital_1")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        when(featureFlagHelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART,FeatureFlagConstants.FLAG_NAME_CART_OPERATION_WITH_UUID,true)).thenReturn(Mono.just(true));
        when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART,FeatureFlagConstants.FLAG_NAME_SET_ACNEXTGEN_FOR_MVA,false)).thenReturn(Mono.just(false));
        when(redisHelper.updateDataIntoRedisAsString(any(), anyString())).thenReturn(Mono.just(true));
        when(deviceHelper2.updateSubFlowInTaggingForNextgen(anyString(), any(), any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();
        controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();
        when(featureFlagHelper.isHubProspectCartCookieDomainIssueFFlagEnabled()).thenReturn(Boolean.TRUE);
        response.getServiceBody().getServiceResponse().getContext().getContextInfo().setProcessStep("test");
        response.getServiceBody().getServiceResponse().getContext().getContextInfo().setCradleFlowJourney("test");
        controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();

    }

    @Test
    public void addDeviceTest8() throws IOException{
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addDevice8Request.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addDevice8Response.json";
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddDeviceUIRequest request = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(helper.populateConflictedSPOsIfPresent(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(helper.populateHumWifiConflictedSFosWithCheck(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        request.getCartInfo().setIntendType("NSE");
        URI url = URI.create("http://localhost/cart/nse/add-device");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").cookie(new HttpCookie("digital_ig_session", "digital_1")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.PARTIAL_CONTENT);
        when(featureFlagHelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
        controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();

    }

    @Test
    public void addDeviceTest9() throws IOException{
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addDevice8Request.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addDevice9Response.json";
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddDeviceUIRequest request = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(helper.populateConflictedSPOsIfPresent(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(helper.populateHumWifiConflictedSFosWithCheck(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        request.getCartInfo().setIntendType("NSE");
        URI url = URI.create("http://localhost/cart/nse/add-device");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").cookie(new HttpCookie("digital_ig_session", "digital_1")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.PARTIAL_CONTENT);
        when(featureFlagHelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
        controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();

    }

    @Test
    public void addDeviceTest10() throws IOException{
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addDevice10Request.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addDevice10Response.json";
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddDeviceUIRequest request = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(helper.populateConflictedSPOsIfPresent(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(helper.populateHumWifiConflictedSFosWithCheck(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        request.getCartInfo().setIntendType("AAL");
        URI url = URI.create("http://localhost/cart/nse/add-device");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM-BBP").header("mtn", "8437299178").cookie(new HttpCookie("digital_ig_session", "digital_1")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.PARTIAL_CONTENT);
        when(featureFlagHelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
        controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();

    }

    @Test
    public void addDeviceTest11() throws IOException{
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addDevice11Request.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addDevice11Response.json";
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddDeviceUIRequest request = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(helper.populateConflictedSPOsIfPresent(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(helper.populateHumWifiConflictedSFosWithCheck(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        request.getCartInfo().setIntendType("NSE");
        URI url = URI.create("http://localhost/cart/nse/add-device");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").header("mtn", "8437299178").cookie(new HttpCookie("digital_ig_session", "digital_1")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.PARTIAL_CONTENT);
        when(featureFlagHelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
        controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();

    }

    @Test
    public void addDeviceTest12() throws IOException{
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addDevice8Request.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addDevice12Response.json";
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddDeviceUIRequest request = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(helper.populateConflictedSPOsIfPresent(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(helper.populateHumWifiConflictedSFosWithCheck(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        request.getCartInfo().setIntendType("NSE");
        URI url = URI.create("http://localhost/cart/nse/add-device");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").cookie(new HttpCookie("digital_ig_session", "digital_1")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.PARTIAL_CONTENT);
        when(featureFlagHelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
        controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();

    }

    @Test
    public void addDeviceTest13() throws IOException{
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addDevice10Request.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addDevice10Response.json";
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddDeviceUIRequest request = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(helper.populateConflictedSPOsIfPresent(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(helper.populateHumWifiConflictedSFosWithCheck(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        request.getCartInfo().setIntendType("AAL");
        Device dev = new Device();
        dev.setId("MQ3U3LL/A");
        request.getData().getLines().get(0).setDevice(dev);
        URI url = URI.create("http://localhost/cart/nse/add-device");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM-BBP").header("mtn", "8437299178").cookie(new HttpCookie("digital_ig_session", "digital_1")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.PARTIAL_CONTENT);
        when(featureFlagHelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
        controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();

    }

    @Test
    public void addDeviceTest_tagging() throws IOException{
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addDeviceTaggingRequest.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addDevice10Response.json";
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddDeviceUIRequest request = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(helper.populateConflictedSPOsIfPresent(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(helper.populateHumWifiConflictedSFosWithCheck(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        URI url = URI.create("http://localhost/cart/nse/add-device");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").header("mtn", "8437299178").cookie(new HttpCookie("digital_ig_session", "digital_1")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.PARTIAL_CONTENT);
        when(featureFlagHelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(deviceHelper2.mapIntendType(any(),any())).thenReturn("EUP");
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("EUP"));
        when(featureFlag.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL, FeatureFlagConstants.CONFIG_PROFILE_QUICKSHOP_PDP, FeatureFlagConstants.FLAG_NAME_FOR_QUICKSHOP_TRADEIN,false)).thenReturn(true);
        when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART,FeatureFlagConstants.FLAG_NAME_CART_OPERATION_WITH_UUID,true)).thenReturn(Mono.just(true));
        when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART,FeatureFlagConstants.FLAG_NAME_SET_ACNEXTGEN_FOR_MVA,false)).thenReturn(Mono.just(false));
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();

        when(featureFlagHelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();

        when(featureFlagHelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.error(new RuntimeException()));
        controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();

        when(featureFlagHelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenThrow(new RuntimeException());
        controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();
    }

    @Test
    public void addDeviceTest14() throws IOException{
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addDevice14Request.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addDevice14Response.json";
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddDeviceUIRequest request = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(helper.populateConflictedSPOsIfPresent(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(helper.populateHumWifiConflictedSFosWithCheck(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(deviceHelper.getVzdlData(any(), any(), any(),any())).thenCallRealMethod();
        when(deviceHelper.getVzdlTxnData(any(), any(), any(),any())).thenCallRealMethod();
        request.getCartInfo().setIntendType("NSE");
        URI url = URI.create("http://localhost/cart/nse/add-device");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").header("mtn", "8437299178").cookie(new HttpCookie("digital_ig_session", "digital_1")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.PARTIAL_CONTENT);
        when(featureFlagHelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART,FeatureFlagConstants.FLAG_NAME_CART_OPERATION_WITH_UUID,true)).thenReturn(Mono.just(true));
        when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART,FeatureFlagConstants.FLAG_NAME_SET_ACNEXTGEN_FOR_MVA,false)).thenReturn(Mono.just(false));
        when(redisHelper.updateDataIntoRedisAsString(any(), anyString())).thenReturn(Mono.just(true));
        when(deviceHelper2.updateSubFlowInTaggingForNextgen(anyString(), any(), any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(Assert::assertNotNull).expectComplete().verify();
        Mockito.verify(deviceHelper, Mockito.times(1)).updateDLDataForAssisted(isNotNull());
    }

    @Test
    public void removeEdgeUpTest() throws IOException{
        String requestFile = "RemoveEdgeUpRequestTest.json";
        String responseFile = "RemoveEdgeUpResponseTest.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        UpdateEdgeupUIRequest request = mapper.readValue(sampleRequestString, UpdateEdgeupUIRequest.class);
        UpdateEdgeupUIResponse response = mapper.readValue(sampleResponseString, UpdateEdgeupUIResponse.class);
        when(helper.removeEdgeup(Mockito.any())).thenReturn(Mono.just(response));
        when(helper.removeLines(Mockito.any())).thenReturn(Mono.just(new RemoveLinesUIResponse()));
        URI url = URI.create("http://localhost/removeEdgeUp");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.removeEdgeUp(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();
    }

    @Test
    public void removeEdgeUpErrorTest1() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/removeEdgeUpError1Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addAccessoryError1Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        UpdateEdgeupUIRequest request = mapper.readValue(requestString, UpdateEdgeupUIRequest.class);
        UpdateEdgeupUIResponse response = mapper.readValue(responseString, UpdateEdgeupUIResponse.class);
        URI url = URI.create("http://localhost/removeEdgeUp");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.NOT_FOUND);
        when(helper.removeEdgeup(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.removeEdgeUp(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }


    @Test
    public void removeEdgeUpTest2() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/removeEdgeUpError1Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/removeEdgeUp2Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        String responseFile1 = "data/CartUpdateOperationsControllerTestJson/removeLines2Response.json";
        String responseString1 = sourceFileReaderUtil.readFile(responseFile1, testFileLocation);
        UpdateEdgeupUIRequest request = mapper.readValue(requestString, UpdateEdgeupUIRequest.class);
        UpdateEdgeupUIResponse response = mapper.readValue(responseString, UpdateEdgeupUIResponse.class);
        RemoveLinesUIResponse removeLinesResponse = mapper.readValue(responseString1, RemoveLinesUIResponse.class);
        URI url = URI.create("http://localhost/removeEdgeUp");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(helper.removeEdgeup(any())).thenReturn(Mono.just(response));
        when(helper.removeLines(any())).thenReturn(Mono.just(removeLinesResponse));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.removeEdgeUp(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void removeEdgeUpTest3() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/removeEdgeUpError1Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/removeEdgeUp3Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        UpdateEdgeupUIRequest request = mapper.readValue(requestString, UpdateEdgeupUIRequest.class);
        UpdateEdgeupUIResponse response = mapper.readValue(responseString, UpdateEdgeupUIResponse.class);
        RemoveLinesUIResponse removeLinesResponse = mapper.readValue(responseString, RemoveLinesUIResponse.class);
        URI url = URI.create("http://localhost/removeEdgeUp");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        when(helper.removeEdgeup(any())).thenReturn(Mono.just(response));
        when(helper.removeLines(any())).thenReturn(Mono.just(removeLinesResponse));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.removeEdgeUp(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void removeEdgeUpTest4() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/removeEdgeUpError1Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/removeEdgeUp4Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        UpdateEdgeupUIRequest request = mapper.readValue(requestString, UpdateEdgeupUIRequest.class);
        UpdateEdgeupUIResponse response = mapper.readValue(responseString, UpdateEdgeupUIResponse.class);
        RemoveLinesUIResponse removeLinesResponse = mapper.readValue(responseString, RemoveLinesUIResponse.class);
        URI url = URI.create("http://localhost/removeEdgeUp");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        when(helper.removeEdgeup(any())).thenReturn(Mono.just(response));
        when(helper.removeLines(any())).thenReturn(Mono.just(removeLinesResponse));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.removeEdgeUp(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void removeEdgeUpTest5() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/removeEdgeUpError1Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/removeEdgeUp5Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        UpdateEdgeupUIRequest request = mapper.readValue(requestString, UpdateEdgeupUIRequest.class);
        UpdateEdgeupUIResponse response = mapper.readValue(responseString, UpdateEdgeupUIResponse.class);
        RemoveLinesUIResponse removeLinesResponse = mapper.readValue(responseString, RemoveLinesUIResponse.class);
        URI url = URI.create("http://localhost/removeEdgeUp");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        when(helper.removeEdgeup(any())).thenReturn(Mono.just(response));
        when(helper.removeLines(any())).thenReturn(Mono.just(removeLinesResponse));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.removeEdgeUp(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void removeEdgeUpTest6() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/removeEdgeUpError1Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/removeEdgeUp6Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        UpdateEdgeupUIRequest request = mapper.readValue(requestString, UpdateEdgeupUIRequest.class);
        UpdateEdgeupUIResponse response = mapper.readValue(responseString, UpdateEdgeupUIResponse.class);
        RemoveLinesUIResponse removeLinesResponse = mapper.readValue(responseString, RemoveLinesUIResponse.class);
        URI url = URI.create("http://localhost/removeEdgeUp");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        when(helper.removeEdgeup(any())).thenReturn(Mono.just(response));
        when(helper.removeLines(any())).thenReturn(Mono.just(removeLinesResponse));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.removeEdgeUp(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void removeEdgeUpTest7() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/removeEdgeUpError1Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/removeEdgeUp7Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        UpdateEdgeupUIRequest request = mapper.readValue(requestString, UpdateEdgeupUIRequest.class);
        UpdateEdgeupUIResponse response = mapper.readValue(responseString, UpdateEdgeupUIResponse.class);
        RemoveLinesUIResponse removeLinesResponse = mapper.readValue(responseString, RemoveLinesUIResponse.class);
        URI url = URI.create("http://localhost/removeEdgeUp");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        when(helper.removeEdgeup(any())).thenReturn(Mono.just(response));
        when(helper.removeLines(any())).thenReturn(Mono.just(removeLinesResponse));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.removeEdgeUp(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void removeEdgeUpTest8() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/removeEdgeUp8Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/removeEdgeUp5Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        UpdateEdgeupUIRequest request = mapper.readValue(requestString, UpdateEdgeupUIRequest.class);
        UpdateEdgeupUIResponse response = mapper.readValue(responseString, UpdateEdgeupUIResponse.class);
        RemoveLinesUIResponse removeLinesResponse = mapper.readValue(responseString, RemoveLinesUIResponse.class);
        URI url = URI.create("http://localhost/removeEdgeUp");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        when(helper.removeEdgeup(any())).thenReturn(Mono.just(response));
        when(helper.removeLines(any())).thenReturn(Mono.just(removeLinesResponse));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.removeEdgeUp(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addAccessorySkipValidateCartTest() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addAccessoryEcomRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addAccessoryNotWhitelistMtnResponse.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/cart/nse/add-accessories");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("skipValidateCart","true")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        request.setHttpRequest(httpRequest);
        String output = "{\"inputTrialType\":\"BAU\",\"cradleFlowJourney\":\"\",\"trialType\":\"BAU\",\"decisionConfig\":{\"httpMethod\":\"GET\",\"useAemTemplate\":false},\"throttleList\":\"|test|vltmap_pdp|PDP_OOS|typeahead_here_pdp|PDPStrategicOffers|Next_JS_Test|L_BAU_C_PChk|N_BAU_C__SLP|N_PLAN|AP_C_D1|PdpCfg_CL|\",\"taggingName\":\"BAU\",\"visitedPages\":\";160;180;6;\",\"allocationType\":\"S38:NoTrial|S40:NoTrial|S41:NoTrial|S53:NoTrial|S58:NoTrial|S59:NoTrial|S68:NoTrial|S74:NoTrial|S79:NoTrial|S80:NoTrial|S103:NoTrial\"}', statusCode=200, errorMessage='null', cradleProps={}, nsaRedirect=false}";
        CradleResponse cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(output);
        Map<String,Object> redisMtnMap = new HashMap<>();
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(cradleResponse));
        when(redisHelper3.getMTNFromRedis(Mockito.any())).thenReturn(Mono.just(redisMtnMap));
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(cradleHelper.getThrottlingList(Mockito.anyMap(), Mockito.any(), Mockito.any())).thenReturn(Mono.just("NSA"));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(new ErrorResponse());
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(false);
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        List<String> requiredDataKeys = Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE);
        Map<String,String> redisData = new HashMap<>();
        redisData.put(CartConstants.CART_COUNT,"1");
//        redisData.put(CartConstants.CART_ORDER_FLOW_TYPE,"eup");
        when(redisHelper.getRequiredDataFromRedis(requiredDataKeys)).thenReturn(Mono.just(redisData));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(res -> Assert.assertEquals(400, res.getStatusCodeValue())).expectComplete().verify();
    }
    @Test
    public void prospectQuickShopCookieTest() throws IOException{
        String requestFile = "data/CartUpdateOperationsControllerTestJson/multiAddDeviceCookieTestRequest.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/multiAddDeviceCookieTestResponse.json";
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddDeviceUIRequest request = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        AddDeviceServiceBody serviceBody =  new AddDeviceServiceBody();
        AddDeviceServiceResponse serviceResponse = new AddDeviceServiceResponse();
        AddDeviceContext context = new AddDeviceContext();
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId("23223999239239032");
        cartInfo.setCartItemCount(1);
        context.setCartInfo(cartInfo);
        serviceResponse.setContext(context);
        serviceBody.setServiceResponse(serviceResponse);
        response.setServiceBody(serviceBody);
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(helper.populateConflictedSPOsIfPresent(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(helper.populateHumWifiConflictedSFosWithCheck(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(featureFlag.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL, FeatureFlagConstants.CONFIG_PROFILE_QUICKSHOP_PDP, FeatureFlagConstants.FLAG_NAME_FOR_QUICKSHOP_TRADEIN,false)).thenReturn(true);
        when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART,FeatureFlagConstants.FLAG_NAME_CART_OPERATION_WITH_UUID,true)).thenReturn(Mono.just(true));
        when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART,FeatureFlagConstants.FLAG_NAME_SET_ACNEXTGEN_FOR_MVA,false)).thenReturn(Mono.just(false));

        request.getCartInfo().setIntendType("NSE");
        URI url = URI.create("http://localhost/cart/nse/add-device");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").cookie(new HttpCookie("digital_ig_session", "digital_1")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        when(featureFlagHelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();
        when(featureFlag.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL, FeatureFlagConstants.CONFIG_PROFILE_QUICKSHOP_PDP, FeatureFlagConstants.FLAG_NAME_FOR_QUICKSHOP_TRADEIN,false)).thenReturn(false);
        controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertTrue(null != httpResponse.getCookies() &&
                httpResponse.getCookies().containsKey(CartConstants.QUICK_SHOP_PROSPECT_CART))).expectComplete().verify();
    }

    @Test
    public void prospectQuickShopCookieRemoveTest() throws IOException{
        String requestFile = "AddDeviceRequestTest.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "AddDeviceResponseTest.json";
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddDeviceUIRequest request = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(helper.populateConflictedSPOsIfPresent(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(helper.populateHumWifiConflictedSFosWithCheck(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        request.getCartInfo().setIntendType("NSE");
        URI url = URI.create("http://localhost/cart/nse/add-device");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM")
                .cookie(new HttpCookie("digital_ig_session", "digital_1"),new HttpCookie("quickShopProspectCart", "true"))
                .build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        when(featureFlagHelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();
        controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertTrue(null != httpResponse.getCookies() &&
                !httpResponse.getCookies().containsKey(CartConstants.QUICK_SHOP_PROSPECT_CART))).expectComplete().verify();
    }

    @Test
    public void addAccessoryTaggingVZDL() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addAccessory_flexv2_tagging_request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addAccessory_flexv2_tagging_response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/cart/flexV2/add-accessories");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").header("mtn", "2293149297")
                .header("Referer","https://sposstore-soe-nssit2.vzwcorp.com/sales/assisted/landing.html").cookie(new HttpCookie("cookie", "cookie")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.ACCEPTED);
        String output = "{\"inputTrialType\":\"BAU\",\"cradleFlowJourney\":\"\",\"trialType\":\"BAU\",\"decisionConfig\":{\"httpMethod\":\"GET\",\"useAemTemplate\":false},\"throttleList\":\"|test|vltmap_pdp|PDP_OOS|typeahead_here_pdp|PDPStrategicOffers|Next_JS_Test|L_BAU_C_PChk|N_BAU_C__SLP|N_PLAN|AP_C_D1|PdpCfg_CL|\",\"taggingName\":\"BAU\",\"visitedPages\":\";160;180;6;\",\"allocationType\":\"S38:NoTrial|S40:NoTrial|S41:NoTrial|S53:NoTrial|S58:NoTrial|S59:NoTrial|S68:NoTrial|S74:NoTrial|S79:NoTrial|S80:NoTrial|S103:NoTrial\"}', statusCode=200, errorMessage='null', cradleProps={}, nsaRedirect=false}";
        CradleResponse cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(output);
        Map<String,Object> redisMtnMap = new HashMap<>();
        when(cradleAllocator.invokeReactiveCradle(any(), any(), any())).thenReturn(Mono.just(cradleResponse));
        when(redisHelper3.getMTNFromRedis(any())).thenReturn(Mono.just(redisMtnMap));
        when(accHelper.addAccessory(any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        when(cradleHelper.getThrottlingList(anyMap(), any(), any())).thenReturn(Mono.just("NSA"));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        when(accHelper.addAccessory(any())).thenReturn(Mono.just(response));
        when(cartAccessoryLoggingHelper.logAccessoryInkibana(any())).thenReturn(Mono.just(new Object()));
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(false);
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        when(helper.populateCustomerProfileCookieIfPresent(any(), any(), any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        List<String> requiredDataKeys = Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE);
        Map<String,String> redisData = new HashMap<>();
        redisData.put("cartCount","1");
        redisData.put("cartOrderFlowType","eup");
        when(redisHelper.getRequiredDataFromRedis(requiredDataKeys)).thenReturn(Mono.just(redisData));
        when(featureFlagHelper.isAssistedLPMFETaggingFeatureFlag()).thenReturn(true);
        Vzdl vzdl = new Vzdl();
        Page page = new Page();
        page.setName("order-landing");
        User user= new User();
        user.setCustomerRole("Account Owner");
        vzdl.setPage(page);
        vzdl.setUser(user);
        request.getCartInfo().setFlexV2(true);

        String sessionId = "";
        when(omniDLHelper.getVzdlDataForAddAccessories(request,response)).thenReturn(vzdl);
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();

    }


    @Test
    public void updateVZDLMfeLandingAccessoriesTest() throws IOException {
        Mono<ResponseEntity<GenericResponse>> vzdlDataAccessoryResponse;
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addAccessory_flexv2_tagging_request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addAccessory_flexv2_tagging_response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/cart/flexV2/add-accessories");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").header("mtn", "2293149297")
                .header("Referer", "https://sposstore-soe-nssit2.vzwcorp.com/sales/assisted/landing.html").cookie(new HttpCookie("cookie", "cookie")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.ACCEPTED);
        String output = "{\"inputTrialType\":\"BAU\",\"cradleFlowJourney\":\"\",\"trialType\":\"BAU\",\"decisionConfig\":{\"httpMethod\":\"GET\",\"useAemTemplate\":false},\"throttleList\":\"|test|vltmap_pdp|PDP_OOS|typeahead_here_pdp|PDPStrategicOffers|Next_JS_Test|L_BAU_C_PChk|N_BAU_C__SLP|N_PLAN|AP_C_D1|PdpCfg_CL|\",\"taggingName\":\"BAU\",\"visitedPages\":\";160;180;6;\",\"allocationType\":\"S38:NoTrial|S40:NoTrial|S41:NoTrial|S53:NoTrial|S58:NoTrial|S59:NoTrial|S68:NoTrial|S74:NoTrial|S79:NoTrial|S80:NoTrial|S103:NoTrial\"}', statusCode=200, errorMessage='null', cradleProps={}, nsaRedirect=false}";
        CradleResponse cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(output);
        when(featureFlagHelper.isAssistedLPMFETaggingFeatureFlag()).thenReturn(true);
        Vzdl vzdl = new Vzdl();
        Page page = new Page();
        page.setName("order-landing");
        User user = new User();
        user.setCustomerRole("Account Owner");
        vzdl.setPage(page);
        vzdl.setUser(user);
        request.getCartInfo().setFlexV2(true);
        request.setChannelId("OMNI-RETAIL");

        when(omniDLHelper.getVzdlDataForAddAccessories(request, response)).thenReturn(vzdl);
        vzdlDataAccessoryResponse = cartController3.updateVZDLMfeLandingAccessories(request, response, httpRequest);
        StepVerifier.create(vzdlDataAccessoryResponse).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();

        vzdl=null;
        when(omniDLHelper.getVzdlDataForAddAccessories(request, response)).thenReturn(vzdl);
        vzdlDataAccessoryResponse = cartController3.updateVZDLMfeLandingAccessories(request, response, httpRequest);
        StepVerifier.create(vzdlDataAccessoryResponse).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();

        when(featureFlagHelper.isAssistedLPMFETaggingFeatureFlag()).thenReturn(false);
        when(omniDLHelper.getVzdlDataForAddAccessories(request, response)).thenReturn(vzdl);
        vzdlDataAccessoryResponse = cartController3.updateVZDLMfeLandingAccessories(request, response, httpRequest);
        StepVerifier.create(vzdlDataAccessoryResponse).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();


        request.getCartInfo().setFlexV2(false);
        when(omniDLHelper.getVzdlDataForAddAccessories(request, response)).thenReturn(vzdl);
        vzdlDataAccessoryResponse = cartController3.updateVZDLMfeLandingAccessories(request, response, httpRequest);
        StepVerifier.create(vzdlDataAccessoryResponse).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();

        request.setChannelId("DIGITAL");
        when(omniDLHelper.getVzdlDataForAddAccessories(request, response)).thenReturn(vzdl);
        vzdlDataAccessoryResponse = cartController3.updateVZDLMfeLandingAccessories(request, response, httpRequest);
        StepVerifier.create(vzdlDataAccessoryResponse).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();

        request.setChannelId(null);
        when(omniDLHelper.getVzdlDataForAddAccessories(request, response)).thenReturn(vzdl);
        vzdlDataAccessoryResponse = cartController3.updateVZDLMfeLandingAccessories(request, response, httpRequest);
        StepVerifier.create(vzdlDataAccessoryResponse).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();
        httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("Referer","https://sposstore-soe-nssit2.vzwcorp.com/sales/assisted/accessorypdp.html").cookie(new HttpCookie("cookie", "cookie")).build();
        when(omniDLHelper.getVzdlDataForAddAccessories(request, response)).thenReturn(vzdl);
        vzdlDataAccessoryResponse = cartController3.updateVZDLMfeLandingAccessories(request, response, httpRequest);
        StepVerifier.create(vzdlDataAccessoryResponse).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();

        httpRequest.getHeaders().getFirst("Referer").isEmpty();
        when(omniDLHelper.getVzdlDataForAddAccessories(request, response )).thenReturn(vzdl);
        vzdlDataAccessoryResponse = cartController3.updateVZDLMfeLandingAccessories(request, response, httpRequest);
        StepVerifier.create(vzdlDataAccessoryResponse).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();

        httpRequest.getHeaders().getFirst(null);
        when(omniDLHelper.getVzdlDataForAddAccessories(request, response )).thenReturn(vzdl);
        vzdlDataAccessoryResponse = cartController3.updateVZDLMfeLandingAccessories(request, response, httpRequest);
        StepVerifier.create(vzdlDataAccessoryResponse).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();

        httpRequest.getHeaders().isEmpty();
        when(omniDLHelper.getVzdlDataForAddAccessories(request, response )).thenReturn(vzdl);
        vzdlDataAccessoryResponse = cartController3.updateVZDLMfeLandingAccessories(request, response, httpRequest);
        StepVerifier.create(vzdlDataAccessoryResponse).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();

    }
    @Test
    public void addAccessoryTest_tagging() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addAccessorySetupAndGoRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-MFA-IOS\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2024.05.21.07.29.06-412.9909776884849\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"availablePaths\":[{\"path\":\"PromoHub\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PromoHub\",\"processAction\":\"\"},\"customerInfo\":{\"nocByod\":false,\"cartCreator\":\"4026191952\",\"processingMTN\":\"\",\"registerNumber\":0,\"noc\":false,\"myvPage\":false},\"cartInfo\":{\"cartItemCount\":1,\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"accessories\":{},\"status\":1,\"eupNoPromoFlow\":false,\"mtn\":\"4026191952\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false,\"instantCreditAmount\":0}}}}}";

        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/cart/add-accessories");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").header("mtn", "8437299178").cookie(new HttpCookie("cookie", "cookie")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.ACCEPTED);
        String output = "{\"inputTrialType\":\"BAU\",\"cradleFlowJourney\":\"\",\"trialType\":\"BAU\",\"decisionConfig\":{\"httpMethod\":\"GET\",\"useAemTemplate\":false},\"throttleList\":\"|test|vltmap_pdp|PDP_OOS|typeahead_here_pdp|PDPStrategicOffers|Next_JS_Test|L_BAU_C_PChk|N_BAU_C__SLP|N_PLAN|AP_C_D1|PdpCfg_CL|\",\"taggingName\":\"BAU\",\"visitedPages\":\";160;180;6;\",\"allocationType\":\"S38:NoTrial|S40:NoTrial|S41:NoTrial|S53:NoTrial|S58:NoTrial|S59:NoTrial|S68:NoTrial|S74:NoTrial|S79:NoTrial|S80:NoTrial|S103:NoTrial\"}', statusCode=200, errorMessage='null', cradleProps={}, nsaRedirect=false}";
        CradleResponse cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(output);
        Map<String,Object> redisMtnMap = new HashMap<>();
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(cradleResponse));
        when(redisHelper3.getMTNFromRedis(Mockito.any())).thenReturn(Mono.just(redisMtnMap));
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(cradleHelper.getThrottlingList(Mockito.anyMap(), Mockito.any(), Mockito.any())).thenReturn(Mono.just("NSA"));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        when(cartAccessoryLoggingHelper.logAccessoryInkibana(Mockito.any())).thenReturn(Mono.just(new Object()));
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(false);

        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("NAO"));
        //true pegaresponse
        when(accHelper.isPegaResponseValid(Mockito.any())).thenReturn(true);
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        List<String> requiredDataKeys = Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE);
        Map<String,String> redisData = new HashMap<>();
        redisData.put(CartConstants.CART_COUNT,"1");
        redisData.put(CartConstants.CART_ORDER_FLOW_TYPE,"eup");
        when(redisHelper.getRequiredDataFromRedis(requiredDataKeys)).thenReturn(Mono.just(redisData));
        when(helper.populateCustomerProfileCookieIfPresent(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(catalogServiceHelper.getCatalogDomainData(any(),any(),any(),any(),any())).thenReturn(Mono.just(new CatalogResponse()));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();

        when(catalogServiceHelper.getCatalogDomainData(any(),any(),any(),any(),any())).thenReturn(Mono.error(new RuntimeException()));
        Mono<ResponseEntity<GenericResponse>> controllerResponse1 = cartController3.addAccessory(httpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse1).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();

        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.error(new RuntimeException()));
        Mono<ResponseEntity<GenericResponse>> controllerResponse2 = cartController3.addAccessory(httpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse2).assertNext(res -> Assert.assertEquals(200, res.getStatusCodeValue())).expectComplete().verify();

        ServerHttpRequest httpRequest1 = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", CartConstants.DIGITAL_DDOT_MOB_TAB_CHANNELS).header("mtn", "8437299178").cookie(new HttpCookie("cookie", "cookie")).build();
        when(redisHelper.getRequiredDataFromRedis(requiredDataKeys)).thenReturn(Mono.just(Collections.emptyMap()));
        StepVerifier.create(cartController3.addAccessory(httpRequest1, httpResponse, request)).assertNext(resp -> org.junit.Assert.assertNotNull(resp)).expectComplete().verify();

        doThrow(new RuntimeException()).when(dlUtilityService).updateDlData(any());
        StepVerifier.create(cartController3.addAccessory(httpRequest, httpResponse, request)).assertNext(resp -> org.junit.Assert.assertNotNull(resp)).expectComplete().verify();

    }

    @Test
    public void testFetchLines(){
        AddAccessoriesUIRequest addAccessoriesUIRequest = null;
        Assert.assertNotNull(ReflectionTestUtils.invokeMethod(cartController3,"fetchLines", addAccessoriesUIRequest));

        addAccessoriesUIRequest = Mockito.mock(AddAccessoriesUIRequest.class);
        Assert.assertNotNull(ReflectionTestUtils.invokeMethod(cartController3,"fetchLines",addAccessoriesUIRequest));

        AddAccessoriesData data = Mockito.mock(AddAccessoriesData.class);
        when(addAccessoriesUIRequest.getData()).thenReturn(data);
        Assert.assertNotNull(ReflectionTestUtils.invokeMethod(cartController3,"fetchLines",addAccessoriesUIRequest));

        when(data.getLines()).thenReturn(new Lines[0]);
        Assert.assertNotNull(ReflectionTestUtils.invokeMethod(cartController3,"fetchLines",addAccessoriesUIRequest));

    }

    @Test
    public void checkIfSetupAndGo(){
        AddAccessoriesUIRequest addAccessoriesUIRequest = Mockito.mock(AddAccessoriesUIRequest.class);
        AddAccessoriesData addAccessoriesData = Mockito.mock(AddAccessoriesData.class);
        Lines lines = Mockito.mock(Lines.class);
        Accessory accessory = Mockito.mock(Accessory.class);
        when(addAccessoriesUIRequest.getData()).thenReturn(addAccessoriesData);
        Assert.assertEquals(Boolean.FALSE, ReflectionTestUtils.invokeMethod(cartController3, "checkIfSetupAndGo", addAccessoriesUIRequest));

        when(addAccessoriesData.getLines()).thenReturn(new Lines[]{lines});
        Assert.assertEquals(Boolean.FALSE, ReflectionTestUtils.invokeMethod(cartController3, "checkIfSetupAndGo", addAccessoriesUIRequest));

        when(addAccessoriesData.getLines()).thenReturn(new Lines[]{lines});
        when(lines.getAddAccessories()).thenReturn(new Accessory[]{accessory});
        Assert.assertEquals(Boolean.FALSE, ReflectionTestUtils.invokeMethod(cartController3, "checkIfSetupAndGo", addAccessoriesUIRequest));

        when(accessory.getId()).thenReturn("123");
        Assert.assertEquals(Boolean.FALSE, ReflectionTestUtils.invokeMethod(cartController3, "checkIfSetupAndGo", addAccessoriesUIRequest));

        when(accessory.getId()).thenReturn("SETUPANDGOMD");
        Assert.assertEquals(Boolean.TRUE, ReflectionTestUtils.invokeMethod(cartController3, "checkIfSetupAndGo", addAccessoriesUIRequest));

    }

    @Test
    public void getCatalogResponseData() {
        AddAccessoriesUIRequest addAccessoriesUIRequest = Mockito.mock(AddAccessoriesUIRequest.class);
        AddAccessoriesData addAccessoriesData = Mockito.mock(AddAccessoriesData.class);
        Lines lines = Mockito.mock(Lines.class);
        Accessory accessory = Mockito.mock(Accessory.class);
        when(addAccessoriesUIRequest.getData()).thenReturn(addAccessoriesData);
        when(addAccessoriesData.getLines()).thenReturn(new Lines[]{lines});
        when(lines.getAddAccessories()).thenReturn(new Accessory[]{accessory});
        when(catalogServiceHelper.getCatalogDomainData(any(),any(),any(),any(),any())).thenReturn(Mono.error(new RuntimeException()));
        Mono<CatalogResponse> response = ReflectionTestUtils.invokeMethod(cartController3, "getCatalogResponseData", addAccessoriesUIRequest);
        StepVerifier.create(response).expectError().verify();

        when(accessory.getId()).thenReturn("123");
        response = ReflectionTestUtils.invokeMethod(cartController3, "getCatalogResponseData", addAccessoriesUIRequest);
        StepVerifier.create(response).expectError().verify();

        when(accessory.getId()).thenReturn("SETUPANDGOMD");
        response = ReflectionTestUtils.invokeMethod(cartController3, "getCatalogResponseData", addAccessoriesUIRequest);
        StepVerifier.create(response).expectError().verify();

    }
    }
