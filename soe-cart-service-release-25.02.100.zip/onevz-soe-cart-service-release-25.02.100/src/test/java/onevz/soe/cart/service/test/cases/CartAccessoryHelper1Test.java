package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper2;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.helper.CartAccessoryHelper;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.helper.RedisHelper2;
import onevz.soe.cart.model.addAccessory.AddAccServiceBody;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.MyOfferETRRedisData;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.AddAccessoriesUIRequest;
import onevz.soe.cart.ui.responses.AddAccessoriesUIResponse;
import onevz.soe.cart.ui.responses.ValidateCartUIResponse;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.customerprofile.model.gql.assisted.Mtn;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.PropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
//@WebFluxTest(CartAddDeviceHelper.class)
@SpringBootTest
@PropertySource("classpath:application.properties")
public class CartAccessoryHelper1Test {

    @Autowired
    private ObjectMapper mapper;
    @MockBean
    private CartServiceBpmHelper2 bpmHelper;

    @MockBean
    private RedisHelper redisHelper;

    @MockBean
    private RedisHelper2 redisHelper2;
    @Autowired
    private CartAccessoryHelper accDevHelper;

    @MockBean
    private CartServiceCxpHelper cxpHelper;

    @Autowired
    SourceFileReaderUtil sourceFileReaderUtil;

    @Value("${onevz.soe.cart.test.fileLocation}")
    private String testFileLocation;

    @Value("${enableDepletionLocationCodeFromRedis:true}")
    public boolean enableDepletionLocationCodeFromRedis=true;

    @Test
    public void addAccessorySAGTest() throws IOException {
        String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\": null,\"processAction\":\"addAccessoryAndCheckout\",\"processStep\":\"PromoHub\",\"intendType\":\"ACC\",\"pageId\":\"PROTECTION\",\"intent\":\"ACCSG\",\"cradleFlowJourney\":\"PromoHub\",\"flowType\":\"SCAN_AND_GO\"},\"data\":{\"depletionType\":\"L\",\"lines\":[{\"mtn\":\"\",\"mdnFilterValue\":\"\",\"addAccessories\":[{\"id\":\"150013-9627\",\"qty\": 1,\"isSoftSku\": false,\"accessoryBundle\": false,\"productId\":\"acc18640006\"}],\"ispuFlow\": false,\"depletionLocationCode\":\"2933701\"}]}}";
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-MFA-IOS\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2024.05.21.07.29.06-412.9909776884849\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"availablePaths\":[{\"path\":\"PromoHub\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PromoHub\",\"processAction\":\"\"},\"customerInfo\":{\"nocByod\":false,\"cartCreator\":\"4026191952\",\"processingMTN\":\"\",\"registerNumber\":0,\"noc\":false,\"myvPage\":false},\"cartInfo\":{\"cartItemCount\":1,\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"accessories\":{},\"status\":1,\"eupNoPromoFlow\":false,\"mtn\":\"4026191952\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false,\"instantCreditAmount\":0}}}}}";
        AddAccessoriesUIResponse responseServiceMono = null;
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddAccessoriesUIRequest UIRequest = new AddAccessoriesUIRequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
        responseServiceMono = mapper.readValue(sampleResponseString, AddAccessoriesUIResponse.class);
        Mono<AddAccessoriesUIResponse> responseMono = Mono.just(responseServiceMono);
        String etrString = "{\"cartId\": \"\",\"atenaSessionId\": \"\",\"lines\": [{\"mtn\": \"5079937563\",\"offers\": [{\"complianceType\": \"ACC\",\"sku\": \"200350\",\"description\": \"UAT_73 SL: Get 50% off of Any Phone Case\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_73\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"},{\"complianceType\": \"EQP\",\"sku\": \"202617\",\"description\": \"Get $300 Recurring BIC on Smartphone Upgrade (Multi Line)\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"EA\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_85\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"}]}]}";
        MyOfferETRRedisData etrData = mapper.readValue(etrString, MyOfferETRRedisData.class);
        Map<String, String> cartMap = new HashMap<String, String>();
        cartMap.put("accessoryCount", "5");
        cartMap.put("intendType", "ACC");
        String validateCartResponseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
        ValidateCartUIResponse validateCartResponse = mapper.readValue(validateCartResponseString,
                ValidateCartUIResponse.class);

        when(bpmHelper.addAccessory(Mockito.any(), Mockito.any())).thenReturn(responseMono);
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just("true"));
        when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartResponse));
        when(redisHelper2.getRole()).thenReturn(Mono.just(CartConstants.MOBILE_SECURE));
        sampleRedisData.setUniversalId("random");
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        when(redisHelper2.updateCartOrderFlowType(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.getAccessoryCartMap(Mockito.any())).thenReturn(Mono.just(cartMap));
        when(redisHelper2.upsertValueInRedis(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
        Mono<AddAccessoriesUIResponse> response = accDevHelper.addAccessory(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addAccessorySAGRemoveAccessoriesTest() throws IOException {
        String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\": null,\"processAction\":\"addAccessoryAndCheckout\",\"processStep\":\"PromoHub\",\"intendType\":\"ACC\",\"pageId\":\"PROTECTION\",\"intent\":\"ACCSG\",\"cradleFlowJourney\":\"PromoHub\",\"flowType\":\"SCAN_AND_GO\"},\"data\":{\"depletionType\":\"L\",\"lines\":[{\"mtn\":\"\",\"mdnFilterValue\":\"\",\"removeAccessories\":[{\"id\":\"150013-9627\",\"qty\": 1,\"isSoftSku\": false,\"accessoryBundle\": false,\"productId\":\"acc18640006\"}],\"ispuFlow\": false,\"depletionLocationCode\":null}]}}";
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-MFA-IOS\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2024.05.21.07.29.06-412.9909776884849\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"availablePaths\":[{\"path\":\"PromoHub\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PromoHub\",\"processAction\":\"\"},\"customerInfo\":{\"nocByod\":false,\"cartCreator\":\"4026191952\",\"processingMTN\":\"\",\"registerNumber\":0,\"noc\":false,\"myvPage\":false},\"cartInfo\":{\"cartItemCount\":1,\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"accessories\":{},\"status\":1,\"eupNoPromoFlow\":false,\"mtn\":\"4026191952\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false,\"instantCreditAmount\":0}}}}}";
        AddAccessoriesUIResponse responseServiceMono = null;
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"retailScanAndGoDepletionLocationCode\":\"E510601\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddAccessoriesUIRequest UIRequest = new AddAccessoriesUIRequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
        responseServiceMono = mapper.readValue(sampleResponseString, AddAccessoriesUIResponse.class);
        Mono<AddAccessoriesUIResponse> responseMono = Mono.just(responseServiceMono);
        String etrString = "{\"cartId\": \"\",\"atenaSessionId\": \"\",\"lines\": [{\"mtn\": \"5079937563\",\"offers\": [{\"complianceType\": \"ACC\",\"sku\": \"200350\",\"description\": \"UAT_73 SL: Get 50% off of Any Phone Case\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_73\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"},{\"complianceType\": \"EQP\",\"sku\": \"202617\",\"description\": \"Get $300 Recurring BIC on Smartphone Upgrade (Multi Line)\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"EA\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_85\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"}]}]}";
        MyOfferETRRedisData etrData = mapper.readValue(etrString, MyOfferETRRedisData.class);
        Map<String, String> cartMap = new HashMap<String, String>();
        cartMap.put("accessoryCount", "5");
        cartMap.put("intendType", "ACC");
        String validateCartResponseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
        ValidateCartUIResponse validateCartResponse = mapper.readValue(validateCartResponseString,
                ValidateCartUIResponse.class);

        when(bpmHelper.addAccessory(Mockito.any(), Mockito.any())).thenReturn(responseMono);
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just("true"));
        when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartResponse));
        when(redisHelper2.getRole()).thenReturn(Mono.just(CartConstants.MOBILE_SECURE));
        sampleRedisData.setUniversalId("random");
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        when(redisHelper2.updateCartOrderFlowType(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.getAccessoryCartMap(Mockito.any())).thenReturn(Mono.just(cartMap));
        Mono<AddAccessoriesUIResponse> response = accDevHelper.addAccessory(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addAccessorySAGRemoveAccessories_EmptyRedisDepletionCodeTest() throws IOException {
        String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\": null,\"processAction\":\"addAccessoryAndCheckout\",\"processStep\":\"PromoHub\",\"intendType\":\"ACC\",\"pageId\":\"PROTECTION\",\"intent\":\"ACCSG\",\"cradleFlowJourney\":\"PromoHub\",\"flowType\":\"SCAN_AND_GO\"},\"data\":{\"depletionType\":\"L\",\"lines\":[{\"mtn\":\"\",\"mdnFilterValue\":\"\",\"removeAccessories\":[{\"id\":\"150013-9627\",\"qty\": 1,\"isSoftSku\": false,\"accessoryBundle\": false,\"productId\":\"acc18640006\"}],\"ispuFlow\": false,\"depletionLocationCode\":null}]}}";
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-MFA-IOS\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2024.05.21.07.29.06-412.9909776884849\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"availablePaths\":[{\"path\":\"PromoHub\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PromoHub\",\"processAction\":\"\"},\"customerInfo\":{\"nocByod\":false,\"cartCreator\":\"4026191952\",\"processingMTN\":\"\",\"registerNumber\":0,\"noc\":false,\"myvPage\":false},\"cartInfo\":{\"cartItemCount\":1,\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"accessories\":{},\"status\":1,\"eupNoPromoFlow\":false,\"mtn\":\"4026191952\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false,\"instantCreditAmount\":0}}}}}";
        AddAccessoriesUIResponse responseServiceMono = null;
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\"}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddAccessoriesUIRequest UIRequest = new AddAccessoriesUIRequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
        responseServiceMono = mapper.readValue(sampleResponseString, AddAccessoriesUIResponse.class);
        Mono<AddAccessoriesUIResponse> responseMono = Mono.just(responseServiceMono);
        String etrString = "{\"cartId\": \"\",\"atenaSessionId\": \"\",\"lines\": [{\"mtn\": \"5079937563\",\"offers\": [{\"complianceType\": \"ACC\",\"sku\": \"200350\",\"description\": \"UAT_73 SL: Get 50% off of Any Phone Case\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_73\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"},{\"complianceType\": \"EQP\",\"sku\": \"202617\",\"description\": \"Get $300 Recurring BIC on Smartphone Upgrade (Multi Line)\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"EA\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_85\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"}]}]}";
        MyOfferETRRedisData etrData = mapper.readValue(etrString, MyOfferETRRedisData.class);
        Map<String, String> cartMap = new HashMap<String, String>();
        cartMap.put("accessoryCount", "5");
        cartMap.put("intendType", "ACC");
        String validateCartResponseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
        ValidateCartUIResponse validateCartResponse = mapper.readValue(validateCartResponseString,
                ValidateCartUIResponse.class);

        when(bpmHelper.addAccessory(Mockito.any(), Mockito.any())).thenReturn(responseMono);
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just("true"));
        when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartResponse));
        when(redisHelper2.getRole()).thenReturn(Mono.just(CartConstants.MOBILE_SECURE));
        sampleRedisData.setUniversalId("random");
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        when(redisHelper2.updateCartOrderFlowType(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.getAccessoryCartMap(Mockito.any())).thenReturn(Mono.just(cartMap));
        Mono<AddAccessoriesUIResponse> response = accDevHelper.addAccessory(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addAccessorySAGRemoveAccessories_NonEmptyUIDepletionCodeTest() throws IOException {
        String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\": null,\"processAction\":\"addAccessoryAndCheckout\",\"processStep\":\"PromoHub\",\"intendType\":\"ACC\",\"pageId\":\"PROTECTION\",\"intent\":\"ACCSG\",\"cradleFlowJourney\":\"PromoHub\",\"flowType\":\"SCAN_AND_GO\"},\"data\":{\"depletionType\":\"L\",\"lines\":[{\"mtn\":\"\",\"mdnFilterValue\":\"\",\"removeAccessories\":[{\"id\":\"150013-9627\",\"qty\": 1,\"isSoftSku\": false,\"accessoryBundle\": false,\"productId\":\"acc18640006\"}],\"ispuFlow\": false,\"depletionLocationCode\":\"2933701\"}]}}";
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-MFA-IOS\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2024.05.21.07.29.06-412.9909776884849\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"availablePaths\":[{\"path\":\"PromoHub\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PromoHub\",\"processAction\":\"\"},\"customerInfo\":{\"nocByod\":false,\"cartCreator\":\"4026191952\",\"processingMTN\":\"\",\"registerNumber\":0,\"noc\":false,\"myvPage\":false},\"cartInfo\":{\"cartItemCount\":1,\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"accessories\":{},\"status\":1,\"eupNoPromoFlow\":false,\"mtn\":\"4026191952\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false,\"instantCreditAmount\":0}}}}}";
        AddAccessoriesUIResponse responseServiceMono = null;
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"retailScanAndGoDepletionLocationCode\":\"E510601\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddAccessoriesUIRequest UIRequest = new AddAccessoriesUIRequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
        responseServiceMono = mapper.readValue(sampleResponseString, AddAccessoriesUIResponse.class);
        Mono<AddAccessoriesUIResponse> responseMono = Mono.just(responseServiceMono);
        String etrString = "{\"cartId\": \"\",\"atenaSessionId\": \"\",\"lines\": [{\"mtn\": \"5079937563\",\"offers\": [{\"complianceType\": \"ACC\",\"sku\": \"200350\",\"description\": \"UAT_73 SL: Get 50% off of Any Phone Case\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_73\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"},{\"complianceType\": \"EQP\",\"sku\": \"202617\",\"description\": \"Get $300 Recurring BIC on Smartphone Upgrade (Multi Line)\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"EA\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_85\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"}]}]}";
        MyOfferETRRedisData etrData = mapper.readValue(etrString, MyOfferETRRedisData.class);
        Map<String, String> cartMap = new HashMap<String, String>();
        cartMap.put("accessoryCount", "5");
        cartMap.put("intendType", "ACC");
        String validateCartResponseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
        ValidateCartUIResponse validateCartResponse = mapper.readValue(validateCartResponseString,
                ValidateCartUIResponse.class);

        when(bpmHelper.addAccessory(Mockito.any(), Mockito.any())).thenReturn(responseMono);
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just("true"));
        when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartResponse));
        when(redisHelper2.getRole()).thenReturn(Mono.just(CartConstants.MOBILE_SECURE));
        sampleRedisData.setUniversalId("random");
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        when(redisHelper2.updateCartOrderFlowType(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.getAccessoryCartMap(Mockito.any())).thenReturn(Mono.just(cartMap));
        Mono<AddAccessoriesUIResponse> response = accDevHelper.addAccessory(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }


    @Test
    public void addAccessorySAGRemoveAccessories_NoRemoveAccessoriesTest() throws IOException {
        String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\": null,\"processAction\":\"addAccessoryAndCheckout\",\"processStep\":\"PromoHub\",\"intendType\":\"ACC\",\"pageId\":\"PROTECTION\",\"intent\":\"ACCSG\",\"cradleFlowJourney\":\"PromoHub\",\"flowType\":\"SCAN_AND_GO\"},\"data\":{\"depletionType\":\"L\",\"lines\":[{\"mtn\":\"\",\"mdnFilterValue\":\"\",\"addAccessories\":[{\"id\":\"150013-9627\",\"qty\": 1,\"isSoftSku\": false,\"accessoryBundle\": false,\"productId\":\"acc18640006\"}],\"ispuFlow\": false,\"depletionLocationCode\":\"E510601\"}]}}";
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-MFA-IOS\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2024.05.21.07.29.06-412.9909776884849\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"availablePaths\":[{\"path\":\"PromoHub\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PromoHub\",\"processAction\":\"\"},\"customerInfo\":{\"nocByod\":false,\"cartCreator\":\"4026191952\",\"processingMTN\":\"\",\"registerNumber\":0,\"noc\":false,\"myvPage\":false},\"cartInfo\":{\"cartItemCount\":1,\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"accessories\":{},\"status\":1,\"eupNoPromoFlow\":false,\"mtn\":\"4026191952\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false,\"instantCreditAmount\":0}}}}}";
        AddAccessoriesUIResponse responseServiceMono = null;
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\"}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddAccessoriesUIRequest UIRequest = new AddAccessoriesUIRequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
        responseServiceMono = mapper.readValue(sampleResponseString, AddAccessoriesUIResponse.class);
        Mono<AddAccessoriesUIResponse> responseMono = Mono.just(responseServiceMono);
        String etrString = "{\"cartId\": \"\",\"atenaSessionId\": \"\",\"lines\": [{\"mtn\": \"5079937563\",\"offers\": [{\"complianceType\": \"ACC\",\"sku\": \"200350\",\"description\": \"UAT_73 SL: Get 50% off of Any Phone Case\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_73\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"},{\"complianceType\": \"EQP\",\"sku\": \"202617\",\"description\": \"Get $300 Recurring BIC on Smartphone Upgrade (Multi Line)\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"EA\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_85\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"}]}]}";
        MyOfferETRRedisData etrData = mapper.readValue(etrString, MyOfferETRRedisData.class);
        Map<String, String> cartMap = new HashMap<String, String>();
        cartMap.put("accessoryCount", "5");
        cartMap.put("intendType", "ACC");
        String validateCartResponseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
        ValidateCartUIResponse validateCartResponse = mapper.readValue(validateCartResponseString,
                ValidateCartUIResponse.class);

        when(bpmHelper.addAccessory(Mockito.any(), Mockito.any())).thenReturn(responseMono);
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just("true"));
        when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartResponse));
        when(redisHelper2.getRole()).thenReturn(Mono.just(CartConstants.MOBILE_SECURE));
        sampleRedisData.setUniversalId("random");
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        when(redisHelper2.updateCartOrderFlowType(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.getAccessoryCartMap(Mockito.any())).thenReturn(Mono.just(cartMap));
        when(redisHelper2.upsertValueInRedis(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
        Mono<AddAccessoriesUIResponse> response = accDevHelper.addAccessory(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addAccessorySAG_NoDepletionCodeTest() throws IOException {
        String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\": null,\"processAction\":\"addAccessoryAndCheckout\",\"processStep\":\"PromoHub\",\"intendType\":\"ACC\",\"pageId\":\"PROTECTION\",\"intent\":\"ACCSG\",\"cradleFlowJourney\":\"PromoHub\",\"flowType\":\"SCAN_AND_GO\"},\"data\":{\"depletionType\":\"L\",\"lines\":[{\"mtn\":\"\",\"mdnFilterValue\":\"\",\"addAccessories\":[{\"id\":\"150013-9627\",\"qty\": 1,\"isSoftSku\": false,\"accessoryBundle\": false,\"productId\":\"acc18640006\"}],\"ispuFlow\": false,\"depletionLocationCode\":null}]}}";
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-MFA-IOS\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2024.05.21.07.29.06-412.9909776884849\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"availablePaths\":[{\"path\":\"PromoHub\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PromoHub\",\"processAction\":\"\"},\"customerInfo\":{\"nocByod\":false,\"cartCreator\":\"4026191952\",\"processingMTN\":\"\",\"registerNumber\":0,\"noc\":false,\"myvPage\":false},\"cartInfo\":{\"cartItemCount\":1,\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"accessories\":{},\"status\":1,\"eupNoPromoFlow\":false,\"mtn\":\"4026191952\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false,\"instantCreditAmount\":0}}}}}";
        AddAccessoriesUIResponse responseServiceMono = null;
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\"}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddAccessoriesUIRequest UIRequest = new AddAccessoriesUIRequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
        responseServiceMono = mapper.readValue(sampleResponseString, AddAccessoriesUIResponse.class);
        Mono<AddAccessoriesUIResponse> responseMono = Mono.just(responseServiceMono);
        String etrString = "{\"cartId\": \"\",\"atenaSessionId\": \"\",\"lines\": [{\"mtn\": \"5079937563\",\"offers\": [{\"complianceType\": \"ACC\",\"sku\": \"200350\",\"description\": \"UAT_73 SL: Get 50% off of Any Phone Case\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_73\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"},{\"complianceType\": \"EQP\",\"sku\": \"202617\",\"description\": \"Get $300 Recurring BIC on Smartphone Upgrade (Multi Line)\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"EA\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_85\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"}]}]}";
        MyOfferETRRedisData etrData = mapper.readValue(etrString, MyOfferETRRedisData.class);
        Map<String, String> cartMap = new HashMap<String, String>();
        cartMap.put("accessoryCount", "5");
        cartMap.put("intendType", "ACC");
        String validateCartResponseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
        ValidateCartUIResponse validateCartResponse = mapper.readValue(validateCartResponseString,
                ValidateCartUIResponse.class);

        when(bpmHelper.addAccessory(Mockito.any(), Mockito.any())).thenReturn(responseMono);
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just("true"));
        when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartResponse));
        when(redisHelper2.getRole()).thenReturn(Mono.just(CartConstants.MOBILE_SECURE));
        sampleRedisData.setUniversalId("random");
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        when(redisHelper2.updateCartOrderFlowType(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.getAccessoryCartMap(Mockito.any())).thenReturn(Mono.just(cartMap));
        when(redisHelper2.upsertValueInRedis(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
        Mono<AddAccessoriesUIResponse> response = accDevHelper.addAccessory(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addAccessorySAGRemoveAccessories_IncorrectFlowTypeTest() throws IOException {
        String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\": null,\"processAction\":\"addAccessoryAndCheckout\",\"processStep\":\"PromoHub\",\"intendType\":\"ACC\",\"pageId\":\"PROTECTION\",\"intent\":\"ACCSG\",\"cradleFlowJourney\":\"PromoHub\",\"flowType\":\"SCANANDGO\"},\"data\":{\"depletionType\":\"L\",\"lines\":[{\"mtn\":\"\",\"mdnFilterValue\":\"\",\"addAccessories\":[{\"id\":\"150013-9627\",\"qty\": 1,\"isSoftSku\": false,\"accessoryBundle\": false,\"productId\":\"acc18640006\"}],\"ispuFlow\": false,\"depletionLocationCode\":\"E510601\"}]}}";
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-MFA-IOS\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2024.05.21.07.29.06-412.9909776884849\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"availablePaths\":[{\"path\":\"PromoHub\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PromoHub\",\"processAction\":\"\"},\"customerInfo\":{\"nocByod\":false,\"cartCreator\":\"4026191952\",\"processingMTN\":\"\",\"registerNumber\":0,\"noc\":false,\"myvPage\":false},\"cartInfo\":{\"cartItemCount\":1,\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"accessories\":{},\"status\":1,\"eupNoPromoFlow\":false,\"mtn\":\"4026191952\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false,\"instantCreditAmount\":0}}}}}";
        AddAccessoriesUIResponse responseServiceMono = null;
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\"}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddAccessoriesUIRequest UIRequest = new AddAccessoriesUIRequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
        responseServiceMono = mapper.readValue(sampleResponseString, AddAccessoriesUIResponse.class);
        Mono<AddAccessoriesUIResponse> responseMono = Mono.just(responseServiceMono);
        String etrString = "{\"cartId\": \"\",\"atenaSessionId\": \"\",\"lines\": [{\"mtn\": \"5079937563\",\"offers\": [{\"complianceType\": \"ACC\",\"sku\": \"200350\",\"description\": \"UAT_73 SL: Get 50% off of Any Phone Case\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_73\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"},{\"complianceType\": \"EQP\",\"sku\": \"202617\",\"description\": \"Get $300 Recurring BIC on Smartphone Upgrade (Multi Line)\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"EA\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_85\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"}]}]}";
        MyOfferETRRedisData etrData = mapper.readValue(etrString, MyOfferETRRedisData.class);
        Map<String, String> cartMap = new HashMap<String, String>();
        cartMap.put("accessoryCount", "5");
        cartMap.put("intendType", "ACC");
        String validateCartResponseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
        ValidateCartUIResponse validateCartResponse = mapper.readValue(validateCartResponseString,
                ValidateCartUIResponse.class);

        when(bpmHelper.addAccessory(Mockito.any(), Mockito.any())).thenReturn(responseMono);
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just("true"));
        when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartResponse));
        when(redisHelper2.getRole()).thenReturn(Mono.just(CartConstants.MOBILE_SECURE));
        sampleRedisData.setUniversalId("random");
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        when(redisHelper2.updateCartOrderFlowType(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.getAccessoryCartMap(Mockito.any())).thenReturn(Mono.just(cartMap));
        Mono<AddAccessoriesUIResponse> response = accDevHelper.addAccessory(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addAccessorySAGRemoveAccessories_MissingFlowTypeTest() throws IOException {
        String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\": null,\"processAction\":\"addAccessoryAndCheckout\",\"processStep\":\"PromoHub\",\"intendType\":\"ACC\",\"pageId\":\"PROTECTION\",\"intent\":\"ACCSG\",\"cradleFlowJourney\":\"PromoHub\"},\"data\":{\"depletionType\":\"L\",\"lines\":[{\"mtn\":\"\",\"mdnFilterValue\":\"\",\"addAccessories\":[{\"id\":\"150013-9627\",\"qty\": 1,\"isSoftSku\": false,\"accessoryBundle\": false,\"productId\":\"acc18640006\"}],\"ispuFlow\": false,\"depletionLocationCode\":\"E510601\"}]}}";
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-MFA-IOS\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2024.05.21.07.29.06-412.9909776884849\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"availablePaths\":[{\"path\":\"PromoHub\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PromoHub\",\"processAction\":\"\"},\"customerInfo\":{\"nocByod\":false,\"cartCreator\":\"4026191952\",\"processingMTN\":\"\",\"registerNumber\":0,\"noc\":false,\"myvPage\":false},\"cartInfo\":{\"cartItemCount\":1,\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"accessories\":{},\"status\":1,\"eupNoPromoFlow\":false,\"mtn\":\"4026191952\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false,\"instantCreditAmount\":0}}}}}";
        AddAccessoriesUIResponse responseServiceMono = null;
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\"}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddAccessoriesUIRequest UIRequest = new AddAccessoriesUIRequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
        responseServiceMono = mapper.readValue(sampleResponseString, AddAccessoriesUIResponse.class);
        Mono<AddAccessoriesUIResponse> responseMono = Mono.just(responseServiceMono);
        String etrString = "{\"cartId\": \"\",\"atenaSessionId\": \"\",\"lines\": [{\"mtn\": \"5079937563\",\"offers\": [{\"complianceType\": \"ACC\",\"sku\": \"200350\",\"description\": \"UAT_73 SL: Get 50% off of Any Phone Case\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_73\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"},{\"complianceType\": \"EQP\",\"sku\": \"202617\",\"description\": \"Get $300 Recurring BIC on Smartphone Upgrade (Multi Line)\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"EA\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_85\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"}]}]}";
        MyOfferETRRedisData etrData = mapper.readValue(etrString, MyOfferETRRedisData.class);
        Map<String, String> cartMap = new HashMap<String, String>();
        cartMap.put("accessoryCount", "5");
        cartMap.put("intendType", "ACC");
        String validateCartResponseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
        ValidateCartUIResponse validateCartResponse = mapper.readValue(validateCartResponseString,
                ValidateCartUIResponse.class);

        when(bpmHelper.addAccessory(Mockito.any(), Mockito.any())).thenReturn(responseMono);
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just("true"));
        when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartResponse));
        when(redisHelper2.getRole()).thenReturn(Mono.just(CartConstants.MOBILE_SECURE));
        sampleRedisData.setUniversalId("random");
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        when(redisHelper2.updateCartOrderFlowType(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.getAccessoryCartMap(Mockito.any())).thenReturn(Mono.just(cartMap));
        Mono<AddAccessoriesUIResponse> response = accDevHelper.addAccessory(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void isScanAndGoAccessoriesEnabledTest() throws IOException {
        String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\": null,\"processAction\":\"addAccessoryAndCheckout\",\"processStep\":\"PromoHub\",\"intendType\":\"ACC\",\"pageId\":\"PROTECTION\",\"intent\":\"ACCSG\",\"cradleFlowJourney\":\"PromoHub\",\"flowType\":\"SCAN_AND_GO\"},\"data\":{\"depletionType\":\"L\",\"lines\":[{\"mtn\":\"\",\"mdnFilterValue\":\"\",\"addAccessories\":[{\"id\":\"150013-9627\",\"qty\": 1,\"isSoftSku\": false,\"accessoryBundle\": false,\"productId\":\"acc18640006\"}],\"ispuFlow\": false,\"depletionLocationCode\":\"2933701\"}]}}";
        AddAccessoriesUIRequest UIRequest = new AddAccessoriesUIRequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);

        Boolean response = accDevHelper.isScanAndGoAccessoriesEnabled(UIRequest);
        Assert.assertTrue(response);
    }

    @Test
    public void isScanAndGoAccessoriesEnabled1Test() throws IOException {
        String sampleUIRequestString = "{\"cartInfo\":null,\"data\":{\"depletionType\":\"L\",\"lines\":[{\"mtn\":\"\",\"mdnFilterValue\":\"\",\"addAccessories\":[{\"id\":\"150013-9627\",\"qty\": 1,\"isSoftSku\": false,\"accessoryBundle\": false,\"productId\":\"acc18640006\"}],\"ispuFlow\": false,\"depletionLocationCode\":\"2933701\"}]}}";
        AddAccessoriesUIRequest UIRequest = new AddAccessoriesUIRequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);

        Boolean response = accDevHelper.isScanAndGoAccessoriesEnabled(UIRequest);
        Assert.assertFalse(response);
    }
    @Test
    public void pegaResponseEmptyTest() throws JsonMappingException, JsonProcessingException {

        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-MFA-IOS\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2024.05.21.07.29.06-412.9909776884849\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"availablePaths\":[{\"path\":\"PromoHub\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PromoHub\",\"processAction\":\"\"},\"customerInfo\":{\"nocByod\":false,\"cartCreator\":\"4026191952\",\"processingMTN\":\"\",\"registerNumber\":0,\"noc\":false,\"myvPage\":false},\"cartInfo\":{\"cartItemCount\":1,\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"accessories\":{},\"status\":1,\"eupNoPromoFlow\":false,\"mtn\":\"4026191952\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false,\"instantCreditAmount\":0}}}}}";

        AddAccessoriesUIResponse response = mapper.readValue(sampleResponseString, AddAccessoriesUIResponse.class);


        Assert.assertTrue(accDevHelper.isPegaResponseValid(response));

        response.getServiceBody().getServiceResponse().getContext().setContextInfo(null);
        Assert.assertFalse(accDevHelper.isPegaResponseValid(response));

        response.getServiceBody().getServiceResponse().setContext(null);
        Assert.assertFalse(accDevHelper.isPegaResponseValid(response));

        response.getServiceBody().setServiceResponse(null);
        Assert.assertFalse(accDevHelper.isPegaResponseValid(response));

        response.setServiceBody(null);
        Assert.assertFalse(accDevHelper.isPegaResponseValid(response));

        Assert.assertFalse(accDevHelper.isPegaResponseValid(null));

    }

    @Test
    public void addAccessoryHelper_Flexv2_IntendType() throws IOException {
        String requestString = "AddAccessory_flexv2_helper_request.json";
        String responseString = "AddAccessory_response_flexv2.json";
        String redisFile = "AddAccessory_Redis_data.json";

        String redisDataString = sourceFileReaderUtil.readFile(redisFile, testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile(requestString, testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile(responseString, testFileLocation);
        AddAccessoriesUIResponse responseServiceMono = null;
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddAccessoriesUIRequest uiRequest = new AddAccessoriesUIRequest();
        uiRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
        responseServiceMono = mapper.readValue(sampleResponseString, AddAccessoriesUIResponse.class);
        Mono<AddAccessoriesUIResponse> responseMono = Mono.just(responseServiceMono);
        Map<String, String> cartMap = new HashMap<String, String>();
        ValidateCartUIResponse validateCartResponse = new ValidateCartUIResponse();
        MyOfferETRRedisData etrData = new MyOfferETRRedisData();
        uiRequest.getCartInfo().setFlexV2(true);
        when(bpmHelper.addAccessory(Mockito.any(), Mockito.any())).thenReturn(responseMono);
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just("true"));
        when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartResponse));
        when(redisHelper2.getRole()).thenReturn(Mono.just(CartConstants.MOBILE_SECURE));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        when(redisHelper2.updateCartOrderFlowType(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.getAccessoryCartMap(Mockito.any())).thenReturn(Mono.just(cartMap));
        Mono<AddAccessoriesUIResponse> response = accDevHelper.addAccessory(uiRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        response = accDevHelper.addAccessory(uiRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();


        uiRequest.getCartInfo().setIntendType(null);
        Mtn mtn = new Mtn();
        mtn.setMtn("2406760602");
        mtn.getMtnStatus().setIsDisconnected(false);

        sampleRedisData.getCustomerProfile().getData().getCustomer().getBillAccounts().stream()
                .forEach(x->x.getMtns().add(mtn));
        Arrays.stream(sampleRedisData.getRetrieveCart().getCart().getLineDetails().getLineInfo())
                .forEach(x->{
                    x.setMobileNumber("2406760602");
                    x.setLineActivityType("ACC");
                });
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        response = accDevHelper.addAccessory(uiRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();


        uiRequest.getCartInfo().setIntendType(null);
        Arrays.stream(sampleRedisData.getRetrieveCart().getCart().getLineDetails().getLineInfo())
                .forEach(x->{
                    if(x.getMobileNumber().equalsIgnoreCase("2406760602"))
                        x.setLineActivityType("UPD");
                });
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        response = accDevHelper.addAccessory(uiRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        uiRequest.getCartInfo().setIntendType(null);
        sampleRedisData.getCustomerProfile().getData().getCustomer().getBillAccounts().stream().
                forEach(z->z.getMtns().stream()
                        .filter(n->n.getMtn().equalsIgnoreCase("2406760602"))
                        .forEach(t->t.getMtnStatus().setIsDisconnected(true)));

        Arrays.stream(sampleRedisData.getRetrieveCart().getCart().getLineDetails().getLineInfo())
                .forEach(x->{
                    if(x.getMobileNumber().equalsIgnoreCase("2406760602"))
                        x.setLineActivityType("AAL");
                });

        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        response = accDevHelper.addAccessory(uiRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();


        testCartIntendtype(uiRequest, sampleRedisData);

        testInputDataLine(uiRequest, sampleRedisData);

        uiRequest.getCartInfo().setIntendType(null);
        uiRequest.getCartInfo().setFlexV2(false);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        response = accDevHelper.addAccessory(uiRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    private void testCartIntendtype(AddAccessoriesUIRequest uiRequest, CartRedisData sampleRedisData) {
        Mono<AddAccessoriesUIResponse> response;
        uiRequest.getCartInfo().setIntendType(null);
        sampleRedisData.setFlow("RF");
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        response = accDevHelper.addAccessory(uiRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        uiRequest.getCartInfo().setIntendType(null);
        sampleRedisData.setFlow("Existing");
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        response = accDevHelper.addAccessory(uiRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        uiRequest.getCartInfo().setIntendType(null);
        sampleRedisData.setCustomerType("N");
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        response = accDevHelper.addAccessory(uiRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        uiRequest.getCartInfo().setIntendType(null);
        sampleRedisData.setCustomerType("PE");
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        response = accDevHelper.addAccessory(uiRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    private void testInputDataLine(AddAccessoriesUIRequest uiRequest, CartRedisData sampleRedisData) {
        Mono<AddAccessoriesUIResponse> response;
        uiRequest.getCartInfo().setIntendType(null);
        Lines[] lineList = new Lines[0];
        uiRequest.getData().setLines(lineList);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        response = accDevHelper.addAccessory(uiRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        uiRequest.getCartInfo().setIntendType(null);
        uiRequest.getData().setLines(null);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        response= accDevHelper.addAccessory(uiRequest);
        StepVerifier.create(response).assertNext(resp-> Assert.assertNotNull(resp)).expectComplete().verify();

        uiRequest.getCartInfo().setIntendType(null);
        uiRequest.setData(null);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        response= accDevHelper.addAccessory(uiRequest);
        StepVerifier.create(response).assertNext(resp-> Assert.assertNotNull(resp)).expectComplete().verify();
    }

}
