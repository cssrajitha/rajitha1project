package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.databind.ObjectMapper;
import junit.framework.Assert;
import onevz.soe.cart.bpm.helper.RemoveHomePhoneServiceBpmHelper;
import onevz.soe.cart.helper.RemoveHomePhoneHelper;
import onevz.soe.cart.model.common.FieldValidationException;
import onevz.soe.cart.responses.RemoveHomePhonePegaResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.requests.RemoveHomePhoneUIRequest;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;


import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = {CartServiceTestConfig.class})
@WebFluxTest(RemoveHomePhoneHelper.class)
public class RemoveHomePhoneHelperTest {

    @Autowired
    private RemoveHomePhoneHelper removeHomePhoneHelper;
    @Autowired
    private ObjectMapper mapper;

    @MockBean
    private RemoveHomePhoneServiceBpmHelper removeHomePhoneServiceBpmHelper;

    @Test
    public void removeHomePhoneTest() throws Exception
    {
        String requestString = "{\n \"cartInfo\": {\n \"clientAppName\": \"VZW-DOTCOM\",\n \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\n \"cartId\": \"\",\n \"caseId\": \"\",\n  \"accountNumber\": \"0213143123-00001\", \n \"cartCreator\": \"8136958775\",\n\"processingMTN\": \"8136958775\",\n \"homePhoneMTN\":\"xxxxxx\",\n  \"processStep\": \"ShoppingCart\",\n  \"processAction\": \"removeDevice\",\n \"intendType\": \"MOVER\",\n \"action\" : \"REMOVE\"\n \n  }\n}";
        String responseString = "{\n \"serviceHeader\" : {\n   \"clientId\" : \"OMNI-RETAIL\",\n   \"statusMsg\" : \"SUCCESS\",\n \"correlationId\" : \"soe-cart-2021.08.06.17.50.24-125.72236596853669\",\n  \"sessionId\" : \"\",\n   \"serviceName\" : \"SalesOrderPurchase\",\n  \"userId\" : \"\",\n\"statusCode\" : \"00\"\n },\n \"serviceBody\" : {\n\"serviceResponse\" : {\n \"context\" : {\n    \"cartInfo\" : {\n   \"statusMsg\" : \"Success\",\n\"cartId\" : \"aa3a61e9-5410-4243-9efe-598c3ec2ac08\",\n \"statusCode\" : \"1\"\n },\n      \"contextInfo\" : {\n     \"availablePaths\" : [{\n   \"path\" : \"ShoppingCart\"\n }, {\n    \"path\" : \"addDevice\"\n }\n   ],\n \"processStep\" : \"ShoppingCart\",\n  \"callReason\" : \"SalesOrderPurchase\"\n },\n\"caseId\" : \"SOP-3647723-E01\",\n    \"customerInfo\" : {\n    \"cartCreator\" : \"4102411705\",\n\"processingMTN\" : \"4014436878\",\n   \"accountNumber\" : \"0001445545-00001\"\n },\n   \"processMTNList\" : [{\n   \"mtn\" : \"2404951496\",\n  \"completedprocessSteps\" : [\"ShoppingCart\",\"addDevice\"]\n}\n    ]\n}\n}\n}\n}\n";
        RemoveHomePhoneUIRequest request = mapper.readValue(requestString, RemoveHomePhoneUIRequest.class);
        RemoveHomePhonePegaResponse response = mapper.readValue(responseString, RemoveHomePhonePegaResponse.class);
        when(removeHomePhoneServiceBpmHelper.removeHomePhone(Mockito.any())).thenReturn(Mono.just(response));
        Mono<RemoveHomePhonePegaResponse> expectedResponse = removeHomePhoneHelper.removeHomePhone(request);
        StepVerifier.create(expectedResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
        StepVerifier.create(expectedResponse).assertNext(resp -> org.junit.Assert.assertEquals(response, resp)).expectComplete()
                .verify();

    }

    @Test
    public void validateUiRequestClienAppNameTest() throws Exception
    {
        String requestString = "{\n \"cartInfo\": {\n \"clientAppName\": \"\",\n \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\n \"cartId\": \"\",\n \"caseId\": \"\",\n  \"accountNumber\": \"0213143123-00001\", \n \"cartCreator\": \"8136958775\",\n\"processingMTN\": \"8136958775\",\n \"homePhoneMTN\":\"xxxxxx\",\n  \"processStep\": \"ShoppingCart\",\n  \"processAction\": \"removeDevice\",\n \"intendType\": \"MOVER\",\n \"action\" : \"REMOVE\"\n \n  }\n}";
        RemoveHomePhoneUIRequest request = mapper.readValue(requestString, RemoveHomePhoneUIRequest.class);
        FieldValidationException expectedResponse = removeHomePhoneHelper.validateUiRequest(request);
        StepVerifier.create(Mono.just(expectedResponse)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
        /*StepVerifier.create(expectedResponse).assertNext(resp -> org.junit.Assert.assertEquals(response, resp)).expectComplete()
                .verify();*/
    }

    @Test
    public void validateUiRequestHomePhoneMtnTest() throws Exception
    {
        String requestString = "{\n \"cartInfo\": {\n \"clientAppName\": \"VZW-DOTCOM\",\n \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\n \"cartId\": \"\",\n \"caseId\": \"\",\n  \"accountNumber\": \"0213143123-00001\", \n \"cartCreator\": \"8136958775\",\n\"processingMTN\": \"8136958775\",\n \"homePhoneMTN\":\"\",\n  \"processStep\": \"ShoppingCart\",\n  \"processAction\": \"removeDevice\",\n \"intendType\": \"MOVER\",\n \"action\" : \"REMOVE\"\n \n  }\n}";
        RemoveHomePhoneUIRequest request = mapper.readValue(requestString, RemoveHomePhoneUIRequest.class);
        FieldValidationException expectedResponse = removeHomePhoneHelper.validateUiRequest(request);
        StepVerifier.create(Mono.just(expectedResponse)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
        /*StepVerifier.create(expectedResponse).assertNext(resp -> org.junit.Assert.assertEquals(response, resp)).expectComplete()
                .verify();*/
    }

    @Test
    public void validateUiRequestActionTest() throws Exception
    {
        String requestString = "{\n \"cartInfo\": {\n \"clientAppName\": \"VZW-DOTCOM\",\n \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\n \"cartId\": \"\",\n \"caseId\": \"\",\n  \"accountNumber\": \"0213143123-00001\", \n \"cartCreator\": \"8136958775\",\n\"processingMTN\": \"8136958775\",\n \"homePhoneMTN\":\"xxxxxx\",\n  \"processStep\": \"ShoppingCart\",\n  \"processAction\": \"removeDevice\",\n \"intendType\": \"MOVER\",\n \"action\" : \"\"\n \n  }\n}";
        RemoveHomePhoneUIRequest request = mapper.readValue(requestString, RemoveHomePhoneUIRequest.class);
        FieldValidationException expectedResponse = removeHomePhoneHelper.validateUiRequest(request);
        StepVerifier.create(Mono.just(expectedResponse)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
        /*StepVerifier.create(expectedResponse).assertNext(resp -> org.junit.Assert.assertEquals(response, resp)).expectComplete()
                .verify();*/
    }

    @Test
    public void validateUiRequestIntendTypeTest() throws Exception
    {
        String requestString = "{\n \"cartInfo\": {\n \"clientAppName\": \"VZW-DOTCOM\",\n \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\n \"cartId\": \"\",\n \"caseId\": \"\",\n  \"accountNumber\": \"0213143123-00001\", \n \"cartCreator\": \"8136958775\",\n\"processingMTN\": \"8136958775\",\n \"homePhoneMTN\":\"xxxxxx\",\n  \"processStep\": \"ShoppingCart\",\n  \"processAction\": \"removeDevice\",\n \"intendType\": \"\",\n \"action\" : \"REMOVE\"\n \n  }\n}";
        RemoveHomePhoneUIRequest request = mapper.readValue(requestString, RemoveHomePhoneUIRequest.class);
        FieldValidationException expectedResponse = removeHomePhoneHelper.validateUiRequest(request);
        StepVerifier.create(Mono.just(expectedResponse)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
        /*StepVerifier.create(expectedResponse).assertNext(resp -> org.junit.Assert.assertEquals(response, resp)).expectComplete()
                .verify();*/
    }

}
