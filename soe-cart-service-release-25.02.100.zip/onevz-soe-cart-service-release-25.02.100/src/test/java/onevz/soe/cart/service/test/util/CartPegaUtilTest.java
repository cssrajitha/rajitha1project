package onevz.soe.cart.service.test.util;

import onevz.soe.cart.util.CartPegaUtil;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@WebFluxTest(CartPegaUtil.class)
public class CartPegaUtilTest {
    @Test
    public void validateCartEmptyResponseTestForNotFoundStatus() {
        HttpStatus response = CartPegaUtil.processHttpStatusForPega(HttpStatus.NOT_FOUND);
        Assertions.assertNotNull(response);
        Assertions.assertEquals(HttpStatus.OK, response);
    }

    @Test
    public void validateCartEmptyResponseTestForSuccessStatus() {
        HttpStatus response = CartPegaUtil.processHttpStatusForPega(HttpStatus.ACCEPTED);
        Assertions.assertNotNull(response);
    }
}