package onevz.soe.cart.service.test.cases;

import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import onevz.soe.cart.requests.DeviceIdValidationPEGARequest;
import onevz.soe.cart.smartimeisearch.DeviceIdValidationRequestFormatter;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import onevz.soe.cart.bpm.helper.CartServiceBpmHelper;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper3;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper2;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.helper.CartRpsHelper;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.model.deviceIdValidation.DeviceIdValidationContext;
import onevz.soe.cart.model.deviceIdValidation.DeviceIdValidationServiceBody;
import onevz.soe.cart.model.deviceIdValidation.DeviceIdValidationServiceResponse;
import onevz.soe.cart.model.deviceIdValidation.DeviceInfo;
import onevz.soe.cart.model.deviceIdValidation.SimInfo;
import onevz.soe.cart.nbx.NBXFeedbackService;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.DeviceSimValidationCXPResponse;
import onevz.soe.cart.responses.InitiateAddressChangePEGAResponse;
import onevz.soe.cart.responses.RPSRedisData;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.common.CarrierPostData;
import onevz.soe.cart.ui.requests.ClearCartUIRequest;
import onevz.soe.cart.ui.requests.DeviceSimValidationUIRequest;
import onevz.soe.cart.ui.requests.RPSApplePayloadUIRequest;
import onevz.soe.cart.ui.requests.RPSE911AddressRetrieveUIRequest;
import onevz.soe.cart.ui.requests.RPSE911AddressUpdateUIRequest;
import onevz.soe.cart.ui.requests.RPSReleasePendingOrderUIRequest;
import onevz.soe.cart.ui.responses.ClearCartUIResponse;
import onevz.soe.cart.ui.responses.DeviceIdValidationUIResponse;
import onevz.soe.cart.ui.responses.RPSE911AddressRetrieveUIResponse;
import onevz.soe.cart.ui.responses.RPSE911AddressUpdateUIResponse;
import onevz.soe.cart.ui.responses.RPSReleasePendingOrderResponse;
import onevz.soe.cart.ui.responses.ValidateE911AddressUIResponse;
import onevz.soe.cradle.CradleAllocator;
import onevz.soe.omnidl.util.DLUtilityService;
import onevz.soe.session.bean.SOELoginSessionBean;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { CartServiceTestConfig.class })
public class CartRpsHelperTest {

	@InjectMocks
	private CartRpsHelper helper;
	@InjectMocks
	private DeviceIdValidationRequestFormatter deviceIdValidationRequestFormatter;

	@Mock
	private CartServiceCxpHelper cxpHelper;
	
	@Mock
	private CartServiceCxpHelper2 cxpHelper2;
	
	@Mock
	private CartServiceCXPServices cxpService;

	@Mock
	private CartServiceBpmHelper bpmHelper;
	
	@Mock
	private CartServiceBpmHelper3 bpmHelper3;

	@Mock
	private RedisHelper redisHelper;

	@Autowired
	private ObjectMapper mapper;
	
	@Mock
	private NBXFeedbackService nbxService;
	
	@Mock
	private CradleAllocator cradleAllocator;
	
	@Mock
	private DLUtilityService dlUtilityService;

	@Mock
	SOELoginSessionBean sessionBean;

	List<String> preorderWhitelistMtnsList = new ArrayList<>();

	//UpdateCartHelper csh = new UpdateCartHelper("1234567890,9087654321","Smartphones,Connected Devices,Tablets");
	
	@Test
	public void initiateRPSFlowHelperTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"467e2a19-c2cb-4d79-b042-22e75c16bb39\",\"caseId\":\"SOP-507867-E01\",\"accountNumber\":\"0517953243-00001\",\"cartCreator\":\"3013513888\",\"processingMTN\":\"3013513888\"},\"data\":{\"lines\":[{\"mtn\":\"3013513888\"},{\"mtn\":\"3013513834\"}]}}";
		String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"MOTRN1\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-277-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"\",\"processAction\":\"\"},\"cartInfo\":{\"cartId\":\"69a66ef4d-7e344dfb-2db299209-ea8333\"},\"customerInfo\":{\"accountNumber\":\"0220335087-00001\",\"cartCreator\":\"8643804638\",\"processingMTN\":\"8643804638\"},\"processMTNList\":[{\"mtn\":\"8643804638\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\"]}],\"removeItem\":{\"lines\":[{\"mtn\":\"2564409659\",\"lineId\":\"null\",\"status\":1}]}}}}}";
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		ClearCartUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, ClearCartUIRequest.class);
		ClearCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, ClearCartUIResponse.class);
		when(bpmHelper3.initiateRPSFlow(Mockito.anyBoolean(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(Mono.just(new DeviceIdValidationUIResponse()));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
		ClearCartUIResponse expectedResponse = sampleResponse;
		Mono<DeviceIdValidationUIResponse> response = helper.initiateRPSFlow(true, "123ef");
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}
	@Test
	public void initiateAddressChangeTest() throws IOException {
		String sampleResponseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-NUMBERLINK\", \"statusMsg\": \"SUCCESS\", \"correlationId\": \"272b928e-dbc6-4296-980b-0875270b65cf\", \"transactionPod\": \"Profile\", \"serviceName\": \"ProfileUpdate\", \"callReason\": \"AcctMgmt\", \"userId\": \"MVO\", \"statusCode\": \"00\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"contextInfo\": { \"availablePaths\": [], \"processAction\": \"\", \"processStep\": \"\", \"intent\": \"AddressChange\" }, \"caseId\": \"PU-3823670-C01\", \"customerInfo\": { \"mtn\": \"7405871031\", \"accountNumber\": \"0288859293-00001\" } } } } }";
		String channelId = "VZW-NUMBERLINK";
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		InitiateAddressChangePEGAResponse sampleResponse = mapper.readValue(sampleResponseString, InitiateAddressChangePEGAResponse.class);
		when(bpmHelper.initiateAddressChange( Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		Mono<InitiateAddressChangePEGAResponse> helperResponse =
				helper.initiateAddressChange(channelId);
		StepVerifier.create(helperResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}
	@Test
	public void updateAddressChangeTest() throws IOException {
		String sampleUIRequestString = "{ \"addressLine1\": \"700 HIDDEN RIDGE\", \"addressLine2\": null, \"cityName\": \"IRVING\", \"state\": \"TX\", \"zipCode\": \"75038\", \"mtn\": null, \"orderNumber\": null, \"lineItemNumber\": null, \"streetNumber\": \"1\", \"streetName\": \"VERIZON WAY\", \"apartmentNo\":\"1234\" }";
		String sampleResponseString = "{\"data\":{\"status\":\"SUCCESS\"}}";
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		RPSE911AddressUpdateUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, RPSE911AddressUpdateUIRequest.class);
		RPSE911AddressUpdateUIResponse sampleResponse = mapper.readValue(sampleResponseString, RPSE911AddressUpdateUIResponse.class);
		when(bpmHelper.updateAddressChange( Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        String caseId = "SOP-538499-E01";
		Mono<RPSE911AddressUpdateUIResponse> helperResponse =
				helper.updateAddressChange(sampleUIRequest, caseId);
		StepVerifier.create(helperResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void getCarrierPostDataTest() throws IOException{
		String requestString = "{\"carrierPostData\":\"transaction-id=spcabcd12323&service-code=MSSU&token=MTQ4OTYwNDc0MjQ2OUBmYmM0MjFlNWVjNmY1MWJiZmMwMDhmYjY3MGYxYmI2NzVlZTY3MjZj&primary-device-mdn=8455597930&device-user-agent=Entitlement%20iOS%2F1.3&associated-subscription=2&esim-download-delay=10\",\"secondary-device-active\":{\"eid\":\"89049032005008882600031910586762\",\"display-name\":\"John's iPad\",\"device-imei\":\"356347105542208\",\"iccids\":[]},\"testScreen\":true,\"testNSA\":true,\"testreplace\":true}";
		RPSApplePayloadUIRequest request = mapper.readValue(requestString, RPSApplePayloadUIRequest.class);
		CarrierPostData helperResponse = helper.getCarrierPostData(request);
		Assert.assertNotNull(helperResponse);
	}
	@Test
	public void formatRPSRedisDataTest() throws IOException{
		String requestString = "{\"carrierPostData\":\"transaction-id=spcabcd12323&service-code=MSSU&token=MTQ4OTYwNDc0MjQ2OUBmYmM0MjFlNWVjNmY1MWJiZmMwMDhmYjY3MGYxYmI2NzVlZTY3MjZj&primary-device-mdn=8455597930&device-user-agent=Entitlement%20iOS%2F1.3&associated-subscription=2&esim-download-delay=10\",\"secondary-device-active\":{\"eid\":\"89049032005008882600031910586762\",\"display-name\":\"John's iPad\",\"device-imei\":\"356347105542208\",\"iccids\":[]},\"testScreen\":true,\"testNSA\":true,\"testreplace\":true}";
		RPSApplePayloadUIRequest request = mapper.readValue(requestString, RPSApplePayloadUIRequest.class);
		RPSRedisData rpsRedisData = helper.formatRPSRedisData(request,"");
		Assert.assertNotNull(rpsRedisData);
	}

	@Test
	public void deviceSimValidationWithEidTest9() throws JsonProcessingException {
		String sampleRequestString = "{\"meta\":{\"timestamp\":\"2019-08-05T13:27:07Z\",\"cxpCorrelationId\":\"3d5f3c15-aa3b-4a42-9245-5cb4177468e4\"},\"data\":{\"cartId\":\"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\":\"Userinformationupdatedsuccessfully.\"},\"channelId\":\"VZW-NUMBERLINK\",\"deviceId\":\"999\",\"mtn\":\"999\",\"zipCode\":\"500086\",\"lineItemNumber\":\"999\",\"orderNumber\":\"999\",\"lineItemInfoList\":{\"lineItemNumber\":\"999\",\"lineItemTimeStamp\":\"1000\",\"orderNumber\":\"9879\"},\"itemType\":\"pc\",\"intendType\":\"pc\",\"eid\":\"1234\",\"imei2\":\"1234\",\"techType\":\"MANAGEACCOUNT\",\"imei\":\"1234\",\"iccid\":\"1234\",\"billingId\":\"1234\",\"devid\":\"123\",\"iccid\":\"1234\"}}";
		String responseString = "{\"client\": \"CXP\", \"data\": {  \"lines\": [{  \"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		DeviceIdValidationServiceBody body = new DeviceIdValidationServiceBody();
		DeviceIdValidationServiceResponse serviceResponse = new DeviceIdValidationServiceResponse();
		DeviceIdValidationUIResponse uiResponse = mapper.readValue(responseString, DeviceIdValidationUIResponse.class);
		DeviceSimValidationUIRequest uiRequest=mapper.readValue(sampleRequestString, DeviceSimValidationUIRequest.class);
		DeviceIdValidationContext context = new DeviceIdValidationContext();
		DeviceInfo deviceInfo = new DeviceInfo();
		SimInfo simInfo = new SimInfo();
		simInfo.setDeviceId("deviceId");
		simInfo.setEID("EID");
		simInfo.setMtn("mtn");
		simInfo.setStatus("status");
		deviceInfo.setSimInfo(simInfo);
		context.setDeviceInfo(deviceInfo);
		serviceResponse.setContext(context);
		body.setServiceResponse(serviceResponse);
		uiResponse.setServiceBody(body);
		Mono<DeviceSimValidationCXPResponse> helperResponse = helper.deviceSimValidationWithEid(uiResponse, uiRequest);
		StepVerifier.create(helperResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void deviceSimValidationWithoutDeviceInfoTest() throws JsonProcessingException {
		String sampleRequestString = "{\"meta\":{\"timestamp\":\"2019-08-05T13:27:07Z\",\"cxpCorrelationId\":\"3d5f3c15-aa3b-4a42-9245-5cb4177468e4\"},\"data\":{\"cartId\":\"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\":\"Userinformationupdatedsuccessfully.\"},\"channelId\":\"VZW-NUMBERLINK\",\"deviceId\":\"999\",\"mtn\":\"999\",\"zipCode\":\"500086\",\"lineItemNumber\":\"999\",\"orderNumber\":\"999\",\"lineItemInfoList\":{\"lineItemNumber\":\"999\",\"lineItemTimeStamp\":\"1000\",\"orderNumber\":\"9879\"},\"itemType\":\"pc\",\"intendType\":\"pc\",\"eid\":\"1234\",\"imei2\":\"1234\",\"techType\":\"MANAGEACCOUNT\",\"imei\":\"1234\",\"iccid\":\"1234\",\"billingId\":\"1234\",\"devid\":\"123\",\"iccid\":\"1234\"}}";
		String responseString = "{\"client\": \"CXP\", \"data\": {  \"lines\": [{  \"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		DeviceIdValidationServiceBody body = new DeviceIdValidationServiceBody();
		DeviceIdValidationServiceResponse serviceResponse = new DeviceIdValidationServiceResponse();
		DeviceIdValidationUIResponse uiResponse = mapper.readValue(responseString, DeviceIdValidationUIResponse.class);
		DeviceSimValidationUIRequest uiRequest=mapper.readValue(sampleRequestString, DeviceSimValidationUIRequest.class);
		serviceResponse.setContext(new DeviceIdValidationContext());
		body.setServiceResponse(serviceResponse);
		uiResponse.setServiceBody(body);
		Mono<DeviceSimValidationCXPResponse> helperResponse = helper.deviceSimValidationWithEid(uiResponse, uiRequest);
		StepVerifier.create(helperResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void deviceSimValidationWithoutContextTest() throws JsonProcessingException {
		String sampleRequestString = "{\"meta\":{\"timestamp\":\"2019-08-05T13:27:07Z\",\"cxpCorrelationId\":\"3d5f3c15-aa3b-4a42-9245-5cb4177468e4\"},\"data\":{\"cartId\":\"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\":\"Userinformationupdatedsuccessfully.\"},\"channelId\":\"VZW-NUMBERLINK\",\"deviceId\":\"999\",\"mtn\":\"999\",\"zipCode\":\"500086\",\"lineItemNumber\":\"999\",\"orderNumber\":\"999\",\"lineItemInfoList\":{\"lineItemNumber\":\"999\",\"lineItemTimeStamp\":\"1000\",\"orderNumber\":\"9879\"},\"itemType\":\"pc\",\"intendType\":\"pc\",\"eid\":\"1234\",\"imei2\":\"1234\",\"techType\":\"MANAGEACCOUNT\",\"imei\":\"1234\",\"iccid\":\"1234\",\"billingId\":\"1234\",\"devid\":\"123\",\"iccid\":\"1234\"}}";
		String responseString = "{\"client\": \"CXP\", \"data\": {  \"lines\": [{  \"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		DeviceIdValidationServiceBody body = new DeviceIdValidationServiceBody();
		DeviceIdValidationServiceResponse serviceResponse = new DeviceIdValidationServiceResponse();
		DeviceIdValidationUIResponse uiResponse = mapper.readValue(responseString, DeviceIdValidationUIResponse.class);
		DeviceSimValidationUIRequest uiRequest=mapper.readValue(sampleRequestString, DeviceSimValidationUIRequest.class);
		body.setServiceResponse(serviceResponse);
		uiResponse.setServiceBody(body);
		Mono<DeviceSimValidationCXPResponse> helperResponse = helper.deviceSimValidationWithEid(uiResponse, uiRequest);
		StepVerifier.create(helperResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void deviceSimValidationWithoutServiceResponseTest() throws JsonProcessingException {
		String sampleRequestString = "{\"meta\":{\"timestamp\":\"2019-08-05T13:27:07Z\",\"cxpCorrelationId\":\"3d5f3c15-aa3b-4a42-9245-5cb4177468e4\"},\"data\":{\"cartId\":\"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\":\"Userinformationupdatedsuccessfully.\"},\"channelId\":\"VZW-NUMBERLINK\",\"deviceId\":\"999\",\"mtn\":\"999\",\"zipCode\":\"500086\",\"lineItemNumber\":\"999\",\"orderNumber\":\"999\",\"lineItemInfoList\":{\"lineItemNumber\":\"999\",\"lineItemTimeStamp\":\"1000\",\"orderNumber\":\"9879\"},\"itemType\":\"pc\",\"intendType\":\"pc\",\"eid\":\"1234\",\"imei2\":\"1234\",\"techType\":\"MANAGEACCOUNT\",\"imei\":\"1234\",\"iccid\":\"1234\",\"billingId\":\"1234\",\"devid\":\"123\",\"iccid\":\"1234\"}}";
		String responseString = "{\"client\": \"CXP\", \"data\": {  \"lines\": [{  \"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		DeviceIdValidationServiceBody body = new DeviceIdValidationServiceBody();
		DeviceIdValidationUIResponse uiResponse = mapper.readValue(responseString, DeviceIdValidationUIResponse.class);
		DeviceSimValidationUIRequest uiRequest=mapper.readValue(sampleRequestString, DeviceSimValidationUIRequest.class);
		uiResponse.setServiceBody(body);
		Mono<DeviceSimValidationCXPResponse> helperResponse = helper.deviceSimValidationWithEid(uiResponse, uiRequest);
		StepVerifier.create(helperResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void deviceSimValidationWithoutServiceBodyTest() throws JsonProcessingException {
		String sampleRequestString = "{\"meta\":{\"timestamp\":\"2019-08-05T13:27:07Z\",\"cxpCorrelationId\":\"3d5f3c15-aa3b-4a42-9245-5cb4177468e4\"},\"data\":{\"cartId\":\"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\":\"Userinformationupdatedsuccessfully.\"},\"channelId\":\"VZW-NUMBERLINK\",\"deviceId\":\"999\",\"mtn\":\"999\",\"zipCode\":\"500086\",\"lineItemNumber\":\"999\",\"orderNumber\":\"999\",\"lineItemInfoList\":{\"lineItemNumber\":\"999\",\"lineItemTimeStamp\":\"1000\",\"orderNumber\":\"9879\"},\"itemType\":\"pc\",\"intendType\":\"pc\",\"eid\":\"1234\",\"imei2\":\"1234\",\"techType\":\"MANAGEACCOUNT\",\"imei\":\"1234\",\"iccid\":\"1234\",\"billingId\":\"1234\",\"devid\":\"123\",\"iccid\":\"1234\"}}";
		String responseString = "{\"client\": \"CXP\", \"data\": {  \"lines\": [{  \"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		DeviceIdValidationUIResponse uiResponse = mapper.readValue(responseString, DeviceIdValidationUIResponse.class);
		DeviceSimValidationUIRequest uiRequest=mapper.readValue(sampleRequestString, DeviceSimValidationUIRequest.class);
		Mono<DeviceSimValidationCXPResponse> helperResponse = helper.deviceSimValidationWithEid(uiResponse, uiRequest);
		StepVerifier.create(helperResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}


	@Test
	public void deviceSimValidationWithoutEidTest() throws JsonProcessingException {
		String sampleRequestString = "{\"meta\":{\"timestamp\":\"2019-08-05T13:27:07Z\",\"cxpCorrelationId\":\"3d5f3c15-aa3b-4a42-9245-5cb4177468e4\"},\"data\":{\"cartId\":\"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\":\"Userinformationupdatedsuccessfully.\"},\"channelId\":\"VZW-NUMBERLINK\",\"deviceId\":\"999\",\"mtn\":\"999\",\"zipCode\":\"500086\",\"lineItemNumber\":\"999\",\"orderNumber\":\"999\",\"lineItemInfoList\":{\"lineItemNumber\":\"999\",\"lineItemTimeStamp\":\"1000\",\"orderNumber\":\"9879\"},\"itemType\":\"pc\",\"intendType\":\"pc\",\"eid\":\"1234\",\"imei2\":\"1234\",\"techType\":\"MANAGEACCOUNT\",\"imei\":\"1234\",\"iccid\":\"1234\",\"billingId\":\"1234\",\"devid\":\"123\",\"iccid\":\"1234\"}}";
		String cxpResponseString = "{\"data\": {\"esimInfo\": null, \"deviceInfo\": {\"deivceAttributes\": null}}}";
		DeviceIdValidationServiceBody body = new DeviceIdValidationServiceBody();
		DeviceIdValidationServiceResponse serviceResponse = new DeviceIdValidationServiceResponse();
		DeviceIdValidationUIResponse uiResponse = new DeviceIdValidationUIResponse();
		DeviceSimValidationUIRequest uiRequest=mapper.readValue(sampleRequestString, DeviceSimValidationUIRequest.class);
		DeviceSimValidationCXPResponse cxpResponse = mapper.readValue(cxpResponseString, DeviceSimValidationCXPResponse.class);
		DeviceIdValidationContext context = new DeviceIdValidationContext();
		DeviceInfo deviceInfo = new DeviceInfo();
		SimInfo simInfo = new SimInfo();
		simInfo.setDeviceId("deviceId");
		simInfo.setMtn("mtn");
		simInfo.setStatus("status");
		deviceInfo.setSimInfo(simInfo);
		context.setDeviceInfo(deviceInfo);
		serviceResponse.setContext(context);
		body.setServiceResponse(serviceResponse);
		uiResponse.setServiceBody(body);
		when(cxpService.deviceSimValidation(Mockito.any())).thenReturn(Mono.just(cxpResponse));
		Mono<DeviceSimValidationCXPResponse> helperResponse = helper.deviceSimValidationWithEid(uiResponse, uiRequest);
		StepVerifier.create(helperResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void deviceSimValidationWithoutSimInfoTest() throws JsonProcessingException {
		String sampleRequestString = "{\"meta\":{\"timestamp\":\"2019-08-05T13:27:07Z\",\"cxpCorrelationId\":\"3d5f3c15-aa3b-4a42-9245-5cb4177468e4\"},\"data\":{\"cartId\":\"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\":\"Userinformationupdatedsuccessfully.\"},\"channelId\":\"VZW-NUMBERLINK\",\"deviceId\":\"999\",\"mtn\":\"999\",\"zipCode\":\"500086\",\"lineItemNumber\":\"999\",\"orderNumber\":\"999\",\"lineItemInfoList\":{\"lineItemNumber\":\"999\",\"lineItemTimeStamp\":\"1000\",\"orderNumber\":\"9879\"},\"itemType\":\"pc\",\"intendType\":\"pc\",\"eid\":\"1234\",\"imei2\":\"1234\",\"techType\":\"MANAGEACCOUNT\",\"imei\":\"1234\",\"iccid\":\"1234\",\"billingId\":\"1234\",\"devid\":\"123\",\"iccid\":\"1234\"}}";
		String cxpResponseString = "{\"data\": {\"esimInfo\": null, \"deviceInfo\": {\"deivceAttributes\": null}}}";
		DeviceIdValidationServiceBody body = new DeviceIdValidationServiceBody();
		DeviceIdValidationServiceResponse serviceResponse = new DeviceIdValidationServiceResponse();
		DeviceIdValidationUIResponse uiResponse = new DeviceIdValidationUIResponse();
		DeviceSimValidationUIRequest uiRequest=mapper.readValue(sampleRequestString, DeviceSimValidationUIRequest.class);
		DeviceSimValidationCXPResponse cxpResponse = mapper.readValue(cxpResponseString, DeviceSimValidationCXPResponse.class);
		DeviceIdValidationContext context = new DeviceIdValidationContext();
		DeviceInfo deviceInfo = new DeviceInfo();
		context.setDeviceInfo(deviceInfo);
		serviceResponse.setContext(context);
		body.setServiceResponse(serviceResponse);
		uiResponse.setServiceBody(body);
		when(cxpService.deviceSimValidation(Mockito.any())).thenReturn(Mono.just(cxpResponse));
		Mono<DeviceSimValidationCXPResponse> helperResponse = helper.deviceSimValidationWithEid(uiResponse, uiRequest);
		StepVerifier.create(helperResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

		@Test
		public void updateAddressChangeTest1() throws IOException {
			String sampleUIRequestString = "{ \"addressLine1\": \"700 HIDDEN RIDGE\", \"addressLine2\": null, \"cityName\": \"IRVING\", \"state\": \"TX\", \"zipCode\": \"75038\", \"mtn\": null, \"orderNumber\": null, \"lineItemNumber\": null, \"streetNumber\": \"1\", \"streetName\": \"VERIZON WAY\", \"apartmentNo\":\"1234\" }";
			String sampleResponseString = "{\"data\":{\"status\":\"SUCCESS\"}}";
			String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"deviceId\":\"dev43667\",\"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": null,\"vzwRoles\":\"PE\", \"mtn\":null }";
			CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
			RPSE911AddressUpdateUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, RPSE911AddressUpdateUIRequest.class);
			RPSE911AddressUpdateUIResponse sampleResponse = mapper.readValue(sampleResponseString, RPSE911AddressUpdateUIResponse.class);
			when(bpmHelper.updateAddressChange( Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleResponse));
			when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
	        String caseId = "SOP-538499-E01";
			Mono<RPSE911AddressUpdateUIResponse> helperResponse =helper.updateAddressChange(sampleUIRequest, caseId);
			StepVerifier.create(helperResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		}
		
		@Test
		public void initiateAddressChangeTest1() throws IOException {
			String sampleResponseString =  "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
			String channelId = "VZW-NUMBERLINK";
			String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\":null, \"mtn\": null}";
			CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
			InitiateAddressChangePEGAResponse sampleResponse = mapper.readValue(sampleResponseString, InitiateAddressChangePEGAResponse.class);
			when(bpmHelper.initiateAddressChange( Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleResponse));
			when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
			Mono<InitiateAddressChangePEGAResponse> helperResponse =helper.initiateAddressChange(channelId);
			StepVerifier.create(helperResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		}

		@Test
		public void updateProspectSessionDataForNumberlinkTest() throws IOException {
			Map sampleSessionData = new HashMap<>();
			sampleSessionData.put("digitalSessionId", "f6885770-5816-47c1-8a96-fab64ae916g1");
			sampleSessionData.put("subkey","DIGITAL_SUBKEY");
			sampleSessionData.put("deviceId","dev6090077");
			sampleSessionData.put("intendType","AAL");
		    when(sessionBean.getProspectSessionData(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleSessionData));
			when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
			Mono<Boolean> response = helper.updateProspectSessionDataForNumberlink();
		    StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		}
		
		@Test
		public void formatRPSRedisDataTest1() throws IOException{
			String requestString = "{\"carrierPostData\":\"transaction-id=spcabcd12323&service-code=MSSU&token=MTQ4OTYwNDc0MjQ2OUBmYmM0MjFlNWVjNmY1MWJiZmMwMDhmYjY3MGYxYmI2NzVlZTY3MjZj&primary-device-mdn=8455597930&device-user-agent=Entitlement%20iOS%2F1.3&associated-subscription=2&esim-download-delay=10\",\"secondary-device-active\":{\"eid\":\"89049032005008882600031910586762\",\"display-name\":\"John's iPad\",\"device-imei\":\"356347105542208\",\"iccids\":[]},\"testScreen\":true,\"testNSA\":true,\"testreplace\":true}";
			RPSApplePayloadUIRequest request = mapper.readValue(requestString, RPSApplePayloadUIRequest.class);
			RPSRedisData rpsRedisData = helper.formatRPSRedisData(request,"drt5yy67");
			Assert.assertNotNull(rpsRedisData);
		}
		
		@Test
		public void formatRPSRedisDataTest2() throws IOException {
			RPSApplePayloadUIRequest request = null;
			RPSRedisData rpsRedisData = helper.formatRPSRedisData(request,"drt5yy67");
			Assert.assertNotNull(rpsRedisData);
		}
		
		@Test
		public void formatRPSRedisDataTest3() throws IOException{
			String requestString = "{\"carrierPostData\":\"transaction-id=spcabcd12323&service-code=MSSU&token=MTQ4OTYwNDc0MjQ2OUBmYmM0MjFlNWVjNmY1MWJiZmMwMDhmYjY3MGYxYmI2NzVlZTY3MjZj&primary-device-mdn=8455597930&device-user-agent=Entitlement%20iOS%2F1.3&associated-subscription=2&esim-download-delay=10\",\"secondary-device-active\":{\"eid\":null,\"display-name\":null,\"device-imei\":null,\"iccids\":[\"AA\"]},\"testScreen\":true,\"testNSA\":true,\"testreplace\":true}";
			RPSApplePayloadUIRequest request = mapper.readValue(requestString, RPSApplePayloadUIRequest.class);
			RPSRedisData rpsRedisData = helper.formatRPSRedisData(request,"drt5yy67");
			Assert.assertNotNull(rpsRedisData);
		}
		
		@Test
		public void formatRPSRedisDataTest4() throws IOException{
			String requestString = "{\"carrierPostData\":\"transaction-id=spcabcd12323&service-code=MSSU&token=MTQ4OTYwNDc0MjQ2OUBmYmM0MjFlNWVjNmY1MWJiZmMwMDhmYjY3MGYxYmI2NzVlZTY3MjZj&primary-device-mdn=8455597930&device-user-agent=Entitlement%20iOS%2F1.3&associated-subscription=2&esim-download-delay=10\",\"secondary-device-active\":null,\"companionDevice\":{\"eid\":\"89049032005008882600031910586762\",\"deviceModel\":\"iPhone 8\",\"imei\":\"356347105542208\",\"deviceOEM\":\"dev68734\"},\"testScreen\":true,\"testNSA\":true,\"testreplace\":true}";
			RPSApplePayloadUIRequest request = mapper.readValue(requestString, RPSApplePayloadUIRequest.class);
			RPSRedisData rpsRedisData = helper.formatRPSRedisData(request,"drt5yy67");
			Assert.assertNotNull(rpsRedisData);
		}
		
		@Test
		public void formatRPSRedisDataTest5() throws IOException{
			String requestString = "{\"carrierPostData\":\"transaction-id=spcabcd12323&service-code=MSSU&token=MTQ4OTYwNDc0MjQ2OUBmYmM0MjFlNWVjNmY1MWJiZmMwMDhmYjY3MGYxYmI2NzVlZTY3MjZj&primary-device-mdn=8455597930&device-user-agent=Entitlement%20iOS%2F1.3&associated-subscription=2&esim-download-delay=10\",\"secondary-device-active\":null,\"companionDevice\":{\"eid\":null,\"deviceModel\":null,\"imei\":null,\"deviceOEM\":null},\"testScreen\":true,\"testNSA\":true,\"testreplace\":true}";		
			RPSApplePayloadUIRequest request = mapper.readValue(requestString, RPSApplePayloadUIRequest.class);
			RPSRedisData rpsRedisData = helper.formatRPSRedisData(request,"drt5yy67");
			Assert.assertNotNull(rpsRedisData);
		}
		
		@Test
		public void formatRPSRedisDataTest6() throws IOException{
			String requestString = "{\"carrierPostData\":\"transaction-id=spcabcd12323&service-code=MSSU&token=MTQ4OTYwNDc0MjQ2OUBmYmM0MjFlNWVjNmY1MWJiZmMwMDhmYjY3MGYxYmI2NzVlZTY3MjZj&primary-device-mdn=8455597930&device-user-agent=Entitlement%20iOS%2F1.3&associated-subscription=2&esim-download-delay=10\",\"secondary-device-active\":null,\"companionDevice\":null,\"testScreen\":true,\"testNSA\":true,\"testreplace\":true}";		
			RPSApplePayloadUIRequest request = mapper.readValue(requestString, RPSApplePayloadUIRequest.class);
			RPSRedisData rpsRedisData = helper.formatRPSRedisData(request,"drt5yy67");
			Assert.assertNotNull(rpsRedisData);
		}
		
		@Test
		public void getCarrierPostDataTest1() throws IOException{
			String requestString = "{\"carrierPostData\":null,\"secondary-device-active\":{\"eid\":\"89049032005008882600031910586762\",\"display-name\":\"John's iPad\",\"device-imei\":\"356347105542208\",\"iccids\":[]},\"testScreen\":true,\"testNSA\":true,\"testreplace\":true}";
			RPSApplePayloadUIRequest request = mapper.readValue(requestString, RPSApplePayloadUIRequest.class);
			CarrierPostData helperResponse = helper.getCarrierPostData(request);
			Assert.assertNotNull(helperResponse);
		}
		
		@Test
		public void getCarrierPostDataTest2() throws IOException {
			RPSApplePayloadUIRequest request = null;
			CarrierPostData helperResponse = helper.getCarrierPostData(request);
			Assert.assertNotNull(helperResponse);
		}
		
		@Test
		public void getCarrierPostDataTest3() throws IOException{
			String requestString = "{\"carrierPostData\":\"service-code=MSSU&primary-device-mdn=8455597930&associated-subscription=2&esim-download-delay=10\",\"secondary-device-active\":{\"eid\":\"89049032005008882600031910586762\",\"display-name\":\"John's iPad\",\"device-imei\":\"356347105542208\",\"iccids\":[]},\"testScreen\":true,\"testNSA\":true,\"testreplace\":true}";
			RPSApplePayloadUIRequest request = mapper.readValue(requestString, RPSApplePayloadUIRequest.class);
			CarrierPostData helperResponse = helper.getCarrierPostData(request);
			Assert.assertNotNull(helperResponse);
		}
		
		@Test
		public void getCarrierPostDataTest4() throws IOException{
			String requestString = "{\"carrierPostData\":\"transaction-id=spcabcd12323&token=MTQ4OTYwNDc0MjQ2OUBmYmM0MjFlNWVjNmY1MWJiZmMwMDhmYjY3MGYxYmI2NzVlZTY3MjZj&device-user-agent=Entitlement%20iOS%2F1.3\",\"secondary-device-active\":{\"eid\":\"89049032005008882600031910586762\",\"display-name\":\"John's iPad\",\"device-imei\":\"356347105542208\",\"iccids\":[]},\"testScreen\":true,\"testNSA\":true,\"testreplace\":true}";
			RPSApplePayloadUIRequest request = mapper.readValue(requestString, RPSApplePayloadUIRequest.class);
			CarrierPostData helperResponse = helper.getCarrierPostData(request);
			Assert.assertNotNull(helperResponse);
		}
		
		
		@Test
		public void initiateRPSFlowHelperTest1() throws IOException {
			String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"467e2a19-c2cb-4d79-b042-22e75c16bb39\",\"caseId\":\"SOP-507867-E01\",\"accountNumber\":\"0517953243-00001\",\"cartCreator\":\"3013513888\",\"processingMTN\":\"3013513888\"},\"data\":{\"lines\":[{\"mtn\":\"3013513888\"},{\"mtn\":\"3013513834\"}]}}";
			String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"MOTRN1\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-277-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"\",\"processAction\":\"\"},\"cartInfo\":{\"cartId\":\"69a66ef4d-7e344dfb-2db299209-ea8333\"},\"customerInfo\":{\"accountNumber\":\"0220335087-00001\",\"cartCreator\":\"8643804638\",\"processingMTN\":\"8643804638\"},\"processMTNList\":[{\"mtn\":\"8643804638\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\"]}],\"removeItem\":{\"lines\":[{\"mtn\":\"2564409659\",\"lineId\":\"null\",\"status\":1}]}}}}}";
			String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"\", \"accountNumber\": \"\", \"mtn\": \"8436667390\" }";
			CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
			ClearCartUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, ClearCartUIRequest.class);
			ClearCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, ClearCartUIResponse.class);
			when(bpmHelper3.initiateRPSFlow(Mockito.anyBoolean(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(Mono.just(new DeviceIdValidationUIResponse()));
			when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
			when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
			ClearCartUIResponse expectedResponse = sampleResponse;
			Mono<DeviceIdValidationUIResponse> response = helper.initiateRPSFlow(true, "123ef");
			StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		}
		
		@Test
		public void updateRPSE911AddressTest() throws IOException {
			String sampleUIRequestString ="{\"addressLine1\":\"7553 JAMES MADISON HWY\",\"mtn\":null,\"streetNumber\":\"7553\",\"streetName\":\"JAMES MADISON HWY\",\"addressLine2\":\"\",\"cityName\":\"FORK UNION\",\"state\":\"VA\",\"zipCode\":\"23055\",\"orderNumber\":null,\"lineItemNumber\":null,\"channelId\":\"VZW-NUMBERLINK\",\"streetType\":\"HWY\"}";
			String sampleResponseString = "{\"data\":{\"status\":\"SUCCESS\"},\"serviceHeader\":{\"callReason\":\"AcctMgmt\",\"transactionPod\":\"Profile\",\"clientId\":\"VZW-NUMBERLINK\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"ProfileUpdate\",\"userId\":\"NUMBERLINK\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.08.13.06.52.24-336.40115693798043\"}}";
			String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"deviceId\":\"dev23534545\",\"processingMTN\": \"1234567890\", \"cartCreator\": \"\", \"accountNumber\": \"5787535348\", \"mtn\": \"7644321167\"}";
			CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
			RPSE911AddressUpdateUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, RPSE911AddressUpdateUIRequest.class);
			RPSE911AddressUpdateUIResponse sampleResponse = mapper.readValue(sampleResponseString, RPSE911AddressUpdateUIResponse.class);
			when(cxpHelper2.updateRPSE911Address(Mockito.any())).thenReturn(Mono.just(sampleResponse));
			when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
			Mono<RPSE911AddressUpdateUIResponse> response = helper.updateRPSE911Address(sampleUIRequest);
			StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		}
		
		@Test
		public void updateRPSE911AddressTest1() throws IOException {
			String sampleUIRequestString ="{\"addressLine1\":\"7553 JAMES MADISON HWY\",\"mtn\":[\"235365747\"],\"streetNumber\":\"7553\",\"streetName\":\"JAMES MADISON HWY\",\"addressLine2\":\"\",\"cityName\":\"FORK UNION\",\"state\":\"VA\",\"zipCode\":\"23055\",\"orderNumber\":null,\"lineItemNumber\":null,\"channelId\":\"VZW-NUMBERLINK\",\"streetType\":\"HWY\"}";
			String sampleResponseString = "{\"data\":{\"status\":\"SUCCESS\"},\"serviceHeader\":{\"callReason\":\"AcctMgmt\",\"transactionPod\":\"Profile\",\"clientId\":\"VZW-NUMBERLINK\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"ProfileUpdate\",\"userId\":\"NUMBERLINK\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.08.13.06.52.24-336.40115693798043\"}}";
			String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"deviceId\":null,\"processingMTN\": \"1234567890\", \"cartCreator\": \"\", \"accountNumber\": \"5787535348\", \"mtn\": \"7644321167\"}";
			CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
			RPSE911AddressUpdateUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, RPSE911AddressUpdateUIRequest.class);
			RPSE911AddressUpdateUIResponse sampleResponse = mapper.readValue(sampleResponseString, RPSE911AddressUpdateUIResponse.class);
			when(cxpHelper2.updateRPSE911Address(Mockito.any())).thenReturn(Mono.just(sampleResponse));
			when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
			Mono<RPSE911AddressUpdateUIResponse> response = helper.updateRPSE911Address(sampleUIRequest);
			StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		}
		
		@Test
		public void updateRPSE911AddressTest2() throws IOException {
			String sampleUIRequestString ="{\"addressLine1\":\"7553 JAMES MADISON HWY\",\"mtn\":[\"235365747\"],\"streetNumber\":\"7553\",\"streetName\":\"JAMES MADISON HWY\",\"addressLine2\":\"\",\"cityName\":\"FORK UNION\",\"state\":\"VA\",\"zipCode\":\"23055\",\"orderNumber\":null,\"lineItemNumber\":null,\"channelId\":\"VZW-NUMBERLINK\",\"streetType\":\"HWY\"}";
			String sampleResponseString = "{\"data\":{\"status\":\"SUCCESS\"},\"serviceHeader\":{\"callReason\":\"AcctMgmt\",\"transactionPod\":\"Profile\",\"clientId\":\"VZW-NUMBERLINK\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"ProfileUpdate\",\"userId\":\"NUMBERLINK\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.08.13.06.52.24-336.40115693798043\"}}";
			String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"deviceId\":null,\"processingMTN\": \"1234567890\", \"cartCreator\": \"\", \"accountNumber\": \"5787535348\", \"mtn\":null}";
			CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
			RPSE911AddressUpdateUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, RPSE911AddressUpdateUIRequest.class);
			RPSE911AddressUpdateUIResponse sampleResponse = mapper.readValue(sampleResponseString, RPSE911AddressUpdateUIResponse.class);
			when(cxpHelper2.updateRPSE911Address(Mockito.any())).thenReturn(Mono.just(sampleResponse));
			when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
			Mono<RPSE911AddressUpdateUIResponse> response = helper.updateRPSE911Address(sampleUIRequest);
			StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		}
		
		@Test
		public void releaseRPSPendingOrderTest() throws IOException {
			String sampleUIRequestString ="{\"lineItemInfoList\":[{\"orderNumber\":\"12345\",\"lineItemNumber\":\"1\",\"lineItemTimeStamp\":\"\"}]}";
			String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"POS-2445436774\",\"statusMsg\":\"SUCCESS\",\"correlationId\":\"2019-08-05T18:05:00Z\",\"userId\":\"ENCRF\",\"statusCode\":\"01\"}}";
			RPSReleasePendingOrderUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, RPSReleasePendingOrderUIRequest.class);
			RPSReleasePendingOrderResponse sampleResponse = mapper.readValue(sampleResponseString, RPSReleasePendingOrderResponse.class);
			when(cxpHelper2.releaseRPSPendingOrder(Mockito.any())).thenReturn(Mono.just(sampleResponse));
			Mono<RPSReleasePendingOrderResponse> response = helper.releaseRPSPendingOrder(sampleUIRequest);
			StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		}
		
		@Test
		public void retrieveRPSE911AddressTest() throws IOException {
			String sampleUIRequestString ="{\"channelID\":\"VZW-NUMBERLINK\",\"mtn\":null,\"modifyFlow\":true}";
			String sampleResponseString = "{\"status\":{\"code\":\"200\",\"message\":\"SUCCESS\"},\"data\":{\"mtn\":\"4349627382\",\"ep11Address\":{\"streetNumber\":\"7553\",\"streetName\":\"JAMES MADISON HWY\",\"city\":\"FORK UNION\",\"addressLine1\":\"7553 JAMES MADISON HWY\",\"addressLine2\":\"\",\"cityName\":\"FORK UNION\",\"state\":\"VA\",\"zipCode\":\"23055\",\"countryCode\":\"US\"},\"status\":\"SUCCESS\"}}";
			String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"deviceId\":\"dev23534545\",\"processingMTN\": \"1234567890\", \"cartCreator\": \"\", \"accountNumber\": \"5787535348\", \"mtn\": \"7644321167\"}";
			CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
			RPSE911AddressRetrieveUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, RPSE911AddressRetrieveUIRequest.class);
			RPSE911AddressRetrieveUIResponse sampleResponse = mapper.readValue(sampleResponseString, RPSE911AddressRetrieveUIResponse.class);
			when(cxpHelper2.retrieveRPSE911Address(Mockito.any())).thenReturn(Mono.just(sampleResponse));
			when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
			Mono<RPSE911AddressRetrieveUIResponse> response = helper.retrieveRPSE911Address(sampleUIRequest);
			StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		}
		
		@Test
		public void retrieveRPSE911AddressTest1() throws IOException {
			String sampleUIRequestString ="{\"channelID\":\"VZW-NUMBERLINK\",\"mtn\":null,\"modifyFlow\":true}";
			String sampleResponseString = "{\"status\":{\"code\":\"200\",\"message\":\"SUCCESS\"},\"data\":{\"mtn\":\"4349627382\",\"ep11Address\":{\"streetNumber\":\"7553\",\"streetName\":\"JAMES MADISON HWY\",\"city\":\"FORK UNION\",\"addressLine1\":\"7553 JAMES MADISON HWY\",\"addressLine2\":\"\",\"cityName\":\"FORK UNION\",\"state\":\"VA\",\"zipCode\":\"23055\",\"countryCode\":\"US\"},\"status\":\"SUCCESS\"}}";
			String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"deviceId\":null,\"processingMTN\": \"1234567890\", \"cartCreator\": \"\", \"accountNumber\": \"5787535348\", \"mtn\": null}";
			CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
			RPSE911AddressRetrieveUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, RPSE911AddressRetrieveUIRequest.class);
			RPSE911AddressRetrieveUIResponse sampleResponse = mapper.readValue(sampleResponseString, RPSE911AddressRetrieveUIResponse.class);
			when(cxpHelper2.retrieveRPSE911Address(Mockito.any())).thenReturn(Mono.just(sampleResponse));
			when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
			Mono<RPSE911AddressRetrieveUIResponse> response = helper.retrieveRPSE911Address(sampleUIRequest);
			StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		}
		
		@Test
		public void retrieveRPSE911AddressTest2() throws IOException {
			String sampleUIRequestString ="{\"channelID\":\"VZW-DOTCOM\",\"mtn\":null,\"modifyFlow\":true}";
			String sampleResponseString = "{\"status\":{\"code\":\"200\",\"message\":\"SUCCESS\"},\"data\":{\"mtn\":\"4349627382\",\"ep11Address\":{\"streetNumber\":\"7553\",\"streetName\":\"JAMES MADISON HWY\",\"city\":\"FORK UNION\",\"addressLine1\":\"7553 JAMES MADISON HWY\",\"addressLine2\":\"\",\"cityName\":\"FORK UNION\",\"state\":\"VA\",\"zipCode\":\"23055\",\"countryCode\":\"US\"},\"status\":\"SUCCESS\"}}";
			String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"deviceId\":null,\"processingMTN\": \"1234567890\", \"cartCreator\": \"\", \"accountNumber\": \"5787535348\", \"mtn\": null}";
			CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
			RPSE911AddressRetrieveUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, RPSE911AddressRetrieveUIRequest.class);
			RPSE911AddressRetrieveUIResponse sampleResponse = mapper.readValue(sampleResponseString, RPSE911AddressRetrieveUIResponse.class);
			when(cxpHelper2.retrieveRPSE911Address(Mockito.any())).thenReturn(Mono.just(sampleResponse));
			when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
			Mono<RPSE911AddressRetrieveUIResponse> response = helper.retrieveRPSE911Address(sampleUIRequest);
			StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		}
		
		@Test
		public void validateE911AddressTest() throws IOException {
			String sampleUIRequestString ="{\"addressLine1\":\"140 ELGIN BLVD\",\"addressLine2\":\"\",\"state\":\"FL\",\"city\":\"DAVENPORT\",\"zipCode\":\"33897\",\"type\":\"e911\"}";
			String sampleResponseString = "{\"data\":{\"validateAddress\":{\"e911Address\":{\"validAddress\":true,\"statusCode\":\"VALID\",\"statusDescription\":\"Address is valid\"}}},\"meta\":{\"timestamp\":\"1661419320387\",\"cxpCorrelationId\":\"2022-08-25T09:22:00.+0000:4f5eca08-57a0-4c5b-a038-43a65c9916d9:cxp-address-services-qa-ev6v-sit1e-nscxp-846b8cbcb9-64sct:nssit1\"}}";
			RPSE911AddressUpdateUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, RPSE911AddressUpdateUIRequest.class);
			ValidateE911AddressUIResponse sampleResponse = mapper.readValue(sampleResponseString, ValidateE911AddressUIResponse.class);
			when(cxpHelper2.validateE911Address(Mockito.any())).thenReturn(Mono.just(sampleResponse));
			Mono<ValidateE911AddressUIResponse> response = helper.validateE911Address(sampleUIRequest);
			StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		}
		
		@Test
		public void deviceSimValidationWithEidTest() throws IOException {
			String sampleUIRequestString ="{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2021.11.02.17.56.21-686.4415005162814\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"BYODSimIDPage\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"BYODSimIDPage\"}]},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"2103815015\",\"processingMTN\":\"\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false},\"deviceInfo\":{\"simInfo\":{\"iccid\":\"\",\"mfgCode\":\"\",\"launchPackageSku\":\"MT6F2LL/A\",\"prodName\":\"\",\"preferredSoftSim\":\"DFILLSIM-TRI-A\",\"launchPackageSkuType\":\"MT6F2LL/A\",\"pairedIccid\":\"\",\"type\":\"\",\"mtn\":\"\",\"mobileNumber\":\"\",\"active\":false,\"aging\":false,\"available\":false,\"retired\":false,\"grandFathered\":false,\"status\":\"\",\"euimid\":\"\",\"imsiv\":\"\",\"imsivf\":\"\",\"iccIdStat\":\"\",\"min\":\"\",\"ispuCompatibleSIM\":\"BULKSIM-TRI-A\",\"esimid\":\"\",\"eID\":null},\"deviceSimCompatible\":\"\",\"deviceSimM2MPair\":\"\",\"deviceESimCompatible\":\"\",\"deviceESimM2MPair\":\"\",\"deviceId\":\"357270090298694\",\"color\":{\"colorId\":\"clr640001\",\"displayName\":\"Space Gray\",\"description\":\"Gray\",\"colorCssStyle\":\"#807F84\"},\"imageName\":\"apple-iphonexs-max-spacegrey\",\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphonexs-max-spacegrey\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphonexs-max-spacegrey?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphonexs-max-spacegrey?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphonexs-max-spacegrey?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphonexs-max-spacegrey?$device-thumb$\"},\"skuDisplayName\":\"Apple iPhone XS Max 64GB in Space Gray\",\"deviceSku\":\"MT6F2LL/A\",\"isRestrictedDevice\":\"N\",\"deviceAttributes\":{\"mfgCode\":\"APL\",\"mfgName\":\"Apple\",\"prodName\":\"IPHONE XS MAX SPACE GRAY 64GB VZ\",\"prodType\":\"4GSmartphone-JU\",\"equipModeCode\":\"4GE\",\"equipMode\":\"4G\",\"gpsIndicator\":\"Y\",\"daccCode\":\"01188\",\"deviceType\":\"4GE\",\"deviceCategory\":\"4G Smartphone\",\"productId\":\"dev10640019\",\"postpaidRestrictStartDate\":\"\",\"prepayRestrictStartDate\":\"\",\"wholesaleRestrictStartDate\":\"\"},\"lostAndStolen\":{\"lostStolen\":\"N\",\"nonPay\":\"N\"},\"numbershareCapability\":\"\",\"price\":{\"fullRetailPrice\":{\"originalPrice\":\"999.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"Full Retail Price\"},\"oneYearPrice\":{\"originalPrice\":\"999.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"One Year Price\"},\"devicePaymentPrice\":[]},\"skipSimIdFlag\":false,\"appleWatchFlag\":false,\"fmipLocked\":false,\"e911AddrInd\":\"\",\"simClass4G\":\"PI\",\"makeEtniPersApi\":false,\"softMessages\":[],\"standalonePairingEligible\":true,\"deviceFamilyType\":\"Phone\",\"osType\":\"Apple iOS\",\"euiccCapable\":\"\",\"imei1\":\"357270090298694\",\"imei2\":\"357270090381920\"}}}}}";
			String sampleResponseString =  "{\"meta\":{\"timestamp\":\"1576738912272\",\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"userId\":\"kumasa1\",\"isVzPhEligible\":null},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"billingSystem\":\"CXP\",\"totalTaxAmount\":38.75,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"orderActivityType\":0,\"numOfLinesForOrderActivityType\":0,\"totalDueMonthlyAfterDiscounts\":0.0,\"totalActivationFees\":0.0,\"fiosAccountInfo\":null},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"lteHomeLine\":false,\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true,\"workEmailId\":null},\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"isSharePlanAdded\":false,\"hasVerizonCloudUnlimitedIncluded\":null},\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"shipping\":{\"address\":{\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"shippingCost\":0.0,\"sddSetupIncluded\":null},\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"totalPriceWithDiscount\":0.0,\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":499.99,\"buyOutTaxAmountUnbilled\":0.0,\"buyOutAmountWithoutTax\":0.0,\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":0.0,\"btaEligible\":true,\"catalogPrice\":499.99,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"itemSeqNum\":0,\"year\":0,\"financeOptionDetail\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"totalPriceWithDiscount\":0.0,\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"qty\":\"1\",\"bundleSeqNum\":0,\"buyOutTaxAmountUnbilled\":0.0,\"buyOutAmountWithoutTax\":0.0,\"taxAmount\":0.0,\"itemSeqNum\":0,\"year\":0,\"financeOptionDetail\":null},{\"itemCode\":\"WAR6002\",\"totalPriceWithDiscount\":0.0,\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"qty\":1,\"bundleSeqNum\":0,\"buyOutTaxAmountUnbilled\":0.0,\"buyOutAmountWithoutTax\":0.0,\"taxAmount\":0.0,\"itemSeqNum\":0,\"year\":0,\"financeOptionDetail\":null}]},\"refundItemExchangeInfo\":null}],\"lineRefundTotal\":0.0,\"lineExchangeTotal\":0.0,\"totalDueMonthlyBeforeCredit\":0.0,\"isBroadBand\":false,\"protectionNotRequired\":false,\"preOrderInServiceDate\":null}],\"rfexPayments\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10,\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\",\"promoOverlayEnable\":false},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\",\"promoOverlayEnable\":false,\"offerType\":null}]}]},\"accountEligibility\":false,\"isFiosCustomer\":null},\"deviceInfo\":{\"mtn\":\"4434541510\",\"deviceId\":\"353246105032488\"},\"esimInfo\":{\"eId\":\"4556723\"}}}";
			String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"deviceId\":\"dev23534545\",\"processingMTN\": \"1234567890\", \"cartCreator\": \"\", \"accountNumber\": \"5787535348\", \"mtn\": \"7644321167\"}";
			CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
			DeviceIdValidationUIResponse sampleUIRequest = mapper.readValue(sampleUIRequestString, DeviceIdValidationUIResponse.class);
			DeviceSimValidationUIRequest uiRequest = new DeviceSimValidationUIRequest();
			uiRequest.setDevid("356347105542208");
			uiRequest.setEid("89049032005008882600031910586762");
			DeviceSimValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceSimValidationCXPResponse.class);
			when(cxpService.deviceSimValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
			when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
			Mono<DeviceSimValidationCXPResponse> response = helper.deviceSimValidationWithEid(sampleUIRequest ,uiRequest );
			StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		}
		
		@Test
		public void deviceSimValidationWithEidTest1() throws IOException {
			String sampleUIRequestString ="{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2021.11.02.17.56.21-686.4415005162814\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"BYODSimIDPage\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"BYODSimIDPage\"}]},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"2103815015\",\"processingMTN\":\"\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false},\"deviceInfo\":{\"simInfo\":null,\"deviceSimCompatible\":\"\",\"deviceSimM2MPair\":\"\",\"deviceESimCompatible\":\"\",\"deviceESimM2MPair\":\"\",\"deviceId\":\"357270090298694\",\"color\":{\"colorId\":\"clr640001\",\"displayName\":\"Space Gray\",\"description\":\"Gray\",\"colorCssStyle\":\"#807F84\"},\"imageName\":\"apple-iphonexs-max-spacegrey\",\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphonexs-max-spacegrey\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphonexs-max-spacegrey?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphonexs-max-spacegrey?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphonexs-max-spacegrey?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphonexs-max-spacegrey?$device-thumb$\"},\"skuDisplayName\":\"Apple iPhone XS Max 64GB in Space Gray\",\"deviceSku\":\"MT6F2LL/A\",\"isRestrictedDevice\":\"N\",\"deviceAttributes\":{\"mfgCode\":\"APL\",\"mfgName\":\"Apple\",\"prodName\":\"IPHONE XS MAX SPACE GRAY 64GB VZ\",\"prodType\":\"4GSmartphone-JU\",\"equipModeCode\":\"4GE\",\"equipMode\":\"4G\",\"gpsIndicator\":\"Y\",\"daccCode\":\"01188\",\"deviceType\":\"4GE\",\"deviceCategory\":\"4G Smartphone\",\"productId\":\"dev10640019\",\"postpaidRestrictStartDate\":\"\",\"prepayRestrictStartDate\":\"\",\"wholesaleRestrictStartDate\":\"\"},\"lostAndStolen\":{\"lostStolen\":\"N\",\"nonPay\":\"N\"},\"numbershareCapability\":\"\",\"price\":{\"fullRetailPrice\":{\"originalPrice\":\"999.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"Full Retail Price\"},\"oneYearPrice\":{\"originalPrice\":\"999.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"One Year Price\"},\"devicePaymentPrice\":[]},\"skipSimIdFlag\":false,\"appleWatchFlag\":false,\"fmipLocked\":false,\"e911AddrInd\":\"\",\"simClass4G\":\"PI\",\"makeEtniPersApi\":false,\"softMessages\":[],\"standalonePairingEligible\":true,\"deviceFamilyType\":\"Phone\",\"osType\":\"Apple iOS\",\"euiccCapable\":\"\",\"imei1\":\"357270090298694\",\"imei2\":\"357270090381920\"}}}}}";
			String sampleResponseString =  "{\"meta\":{\"timestamp\":\"1576738912272\",\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"userId\":\"kumasa1\",\"isVzPhEligible\":null},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"billingSystem\":\"CXP\",\"totalTaxAmount\":38.75,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"orderActivityType\":0,\"numOfLinesForOrderActivityType\":0,\"totalDueMonthlyAfterDiscounts\":0.0,\"totalActivationFees\":0.0,\"fiosAccountInfo\":null},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"lteHomeLine\":false,\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true,\"workEmailId\":null},\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"isSharePlanAdded\":false,\"hasVerizonCloudUnlimitedIncluded\":null},\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"shipping\":{\"address\":{\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"shippingCost\":0.0,\"sddSetupIncluded\":null},\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"totalPriceWithDiscount\":0.0,\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":499.99,\"buyOutTaxAmountUnbilled\":0.0,\"buyOutAmountWithoutTax\":0.0,\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":0.0,\"btaEligible\":true,\"catalogPrice\":499.99,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"itemSeqNum\":0,\"year\":0,\"financeOptionDetail\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"totalPriceWithDiscount\":0.0,\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"qty\":\"1\",\"bundleSeqNum\":0,\"buyOutTaxAmountUnbilled\":0.0,\"buyOutAmountWithoutTax\":0.0,\"taxAmount\":0.0,\"itemSeqNum\":0,\"year\":0,\"financeOptionDetail\":null},{\"itemCode\":\"WAR6002\",\"totalPriceWithDiscount\":0.0,\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"qty\":1,\"bundleSeqNum\":0,\"buyOutTaxAmountUnbilled\":0.0,\"buyOutAmountWithoutTax\":0.0,\"taxAmount\":0.0,\"itemSeqNum\":0,\"year\":0,\"financeOptionDetail\":null}]},\"refundItemExchangeInfo\":null}],\"lineRefundTotal\":0.0,\"lineExchangeTotal\":0.0,\"totalDueMonthlyBeforeCredit\":0.0,\"isBroadBand\":false,\"protectionNotRequired\":false,\"preOrderInServiceDate\":null}],\"rfexPayments\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10,\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\",\"promoOverlayEnable\":false},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\",\"promoOverlayEnable\":false,\"offerType\":null}]}]},\"accountEligibility\":false,\"isFiosCustomer\":null},\"deviceInfo\":{\"mtn\":\"4434541510\",\"deviceId\":\"353246105032488\"},\"esimInfo\":{\"eId\":\"4556723\"}}}";
			String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"deviceId\":\"dev23534545\",\"processingMTN\": \"1234567890\", \"cartCreator\": \"\", \"accountNumber\": \"5787535348\", \"mtn\": \"7644321167\"}";
			CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
			DeviceIdValidationUIResponse sampleUIRequest = mapper.readValue(sampleUIRequestString, DeviceIdValidationUIResponse.class);
			DeviceSimValidationUIRequest uiRequest = new DeviceSimValidationUIRequest();
			uiRequest.setDevid("356347105542208");
			uiRequest.setEid("89049032005008882600031910586762");
			DeviceSimValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceSimValidationCXPResponse.class);
			when(cxpService.deviceSimValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
			when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
			Mono<DeviceSimValidationCXPResponse> response = helper.deviceSimValidationWithEid(sampleUIRequest ,uiRequest );
			StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		}
		
		@Test
		public void deviceSimValidationWithEidTest2() throws IOException {
			String sampleUIRequestString ="{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2021.11.02.17.56.21-686.4415005162814\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"BYODSimIDPage\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"BYODSimIDPage\"}]},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"2103815015\",\"processingMTN\":\"\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false},\"deviceInfo\":{\"simInfo\":{\"iccid\":\"\",\"mfgCode\":\"\",\"launchPackageSku\":\"MT6F2LL/A\",\"prodName\":\"\",\"preferredSoftSim\":\"DFILLSIM-TRI-A\",\"launchPackageSkuType\":\"MT6F2LL/A\",\"pairedIccid\":\"\",\"type\":\"\",\"mtn\":\"\",\"mobileNumber\":\"\",\"active\":false,\"aging\":false,\"available\":false,\"retired\":false,\"grandFathered\":false,\"status\":\"\",\"euimid\":\"\",\"imsiv\":\"\",\"imsivf\":\"\",\"iccIdStat\":\"\",\"min\":\"\",\"ispuCompatibleSIM\":\"BULKSIM-TRI-A\",\"esimid\":\"\",\"eID\":\"3465748658798697\"},\"deviceSimCompatible\":\"\",\"deviceSimM2MPair\":\"\",\"deviceESimCompatible\":\"\",\"deviceESimM2MPair\":\"\",\"deviceId\":\"357270090298694\",\"color\":{\"colorId\":\"clr640001\",\"displayName\":\"Space Gray\",\"description\":\"Gray\",\"colorCssStyle\":\"#807F84\"},\"imageName\":\"apple-iphonexs-max-spacegrey\",\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphonexs-max-spacegrey\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphonexs-max-spacegrey?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphonexs-max-spacegrey?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphonexs-max-spacegrey?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphonexs-max-spacegrey?$device-thumb$\"},\"skuDisplayName\":\"Apple iPhone XS Max 64GB in Space Gray\",\"deviceSku\":\"MT6F2LL/A\",\"isRestrictedDevice\":\"N\",\"deviceAttributes\":{\"mfgCode\":\"APL\",\"mfgName\":\"Apple\",\"prodName\":\"IPHONE XS MAX SPACE GRAY 64GB VZ\",\"prodType\":\"4GSmartphone-JU\",\"equipModeCode\":\"4GE\",\"equipMode\":\"4G\",\"gpsIndicator\":\"Y\",\"daccCode\":\"01188\",\"deviceType\":\"4GE\",\"deviceCategory\":\"4G Smartphone\",\"productId\":\"dev10640019\",\"postpaidRestrictStartDate\":\"\",\"prepayRestrictStartDate\":\"\",\"wholesaleRestrictStartDate\":\"\"},\"lostAndStolen\":{\"lostStolen\":\"N\",\"nonPay\":\"N\"},\"numbershareCapability\":\"\",\"price\":{\"fullRetailPrice\":{\"originalPrice\":\"999.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"Full Retail Price\"},\"oneYearPrice\":{\"originalPrice\":\"999.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"One Year Price\"},\"devicePaymentPrice\":[]},\"skipSimIdFlag\":false,\"appleWatchFlag\":false,\"fmipLocked\":false,\"e911AddrInd\":\"\",\"simClass4G\":\"PI\",\"makeEtniPersApi\":false,\"softMessages\":[],\"standalonePairingEligible\":true,\"deviceFamilyType\":\"Phone\",\"osType\":\"Apple iOS\",\"euiccCapable\":\"\",\"imei1\":\"357270090298694\",\"imei2\":\"357270090381920\"}}}}}";
			String sampleResponseString =  "{\"meta\":{\"timestamp\":\"1576738912272\",\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"userId\":\"kumasa1\",\"isVzPhEligible\":null},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"billingSystem\":\"CXP\",\"totalTaxAmount\":38.75,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"orderActivityType\":0,\"numOfLinesForOrderActivityType\":0,\"totalDueMonthlyAfterDiscounts\":0.0,\"totalActivationFees\":0.0,\"fiosAccountInfo\":null},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"lteHomeLine\":false,\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true,\"workEmailId\":null},\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"isSharePlanAdded\":false,\"hasVerizonCloudUnlimitedIncluded\":null},\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"shipping\":{\"address\":{\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"shippingCost\":0.0,\"sddSetupIncluded\":null},\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"totalPriceWithDiscount\":0.0,\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":499.99,\"buyOutTaxAmountUnbilled\":0.0,\"buyOutAmountWithoutTax\":0.0,\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":0.0,\"btaEligible\":true,\"catalogPrice\":499.99,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"itemSeqNum\":0,\"year\":0,\"financeOptionDetail\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"totalPriceWithDiscount\":0.0,\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"qty\":\"1\",\"bundleSeqNum\":0,\"buyOutTaxAmountUnbilled\":0.0,\"buyOutAmountWithoutTax\":0.0,\"taxAmount\":0.0,\"itemSeqNum\":0,\"year\":0,\"financeOptionDetail\":null},{\"itemCode\":\"WAR6002\",\"totalPriceWithDiscount\":0.0,\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"qty\":1,\"bundleSeqNum\":0,\"buyOutTaxAmountUnbilled\":0.0,\"buyOutAmountWithoutTax\":0.0,\"taxAmount\":0.0,\"itemSeqNum\":0,\"year\":0,\"financeOptionDetail\":null}]},\"refundItemExchangeInfo\":null}],\"lineRefundTotal\":0.0,\"lineExchangeTotal\":0.0,\"totalDueMonthlyBeforeCredit\":0.0,\"isBroadBand\":false,\"protectionNotRequired\":false,\"preOrderInServiceDate\":null}],\"rfexPayments\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10,\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\",\"promoOverlayEnable\":false},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\",\"promoOverlayEnable\":false,\"offerType\":null}]}]},\"accountEligibility\":false,\"isFiosCustomer\":null},\"deviceInfo\":{\"mtn\":\"4434541510\",\"deviceId\":\"353246105032488\"},\"esimInfo\":{\"eId\":\"4556723\"}}}";
			String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"deviceId\":\"dev23534545\",\"processingMTN\": \"1234567890\", \"cartCreator\": \"\", \"accountNumber\": \"5787535348\", \"mtn\": \"7644321167\"}";
			CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
			DeviceIdValidationUIResponse sampleUIRequest = mapper.readValue(sampleUIRequestString, DeviceIdValidationUIResponse.class);
			DeviceSimValidationUIRequest uiRequest = new DeviceSimValidationUIRequest();
			uiRequest.setDevid("356347105542208");
			uiRequest.setEid("89049032005008882600031910586762");
			DeviceSimValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceSimValidationCXPResponse.class);
			when(cxpService.deviceSimValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
			when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
			Mono<DeviceSimValidationCXPResponse> response = helper.deviceSimValidationWithEid(sampleUIRequest ,uiRequest );
			StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		}
		
		@Test
		public void deviceSimValidationWithEidTest3() throws IOException {
			String sampleUIRequestString ="{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2021.11.02.17.56.21-686.4415005162814\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"BYODSimIDPage\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"BYODSimIDPage\"}]},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"2103815015\",\"processingMTN\":\"\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false},\"deviceInfo\":null,\"deviceSimCompatible\":\"\",\"deviceSimM2MPair\":\"\",\"deviceESimCompatible\":\"\",\"deviceESimM2MPair\":\"\",\"deviceId\":\"357270090298694\",\"color\":{\"colorId\":\"clr640001\",\"displayName\":\"Space Gray\",\"description\":\"Gray\",\"colorCssStyle\":\"#807F84\"},\"imageName\":\"apple-iphonexs-max-spacegrey\",\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphonexs-max-spacegrey\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphonexs-max-spacegrey?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphonexs-max-spacegrey?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphonexs-max-spacegrey?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphonexs-max-spacegrey?$device-thumb$\"},\"skuDisplayName\":\"Apple iPhone XS Max 64GB in Space Gray\",\"deviceSku\":\"MT6F2LL/A\",\"isRestrictedDevice\":\"N\",\"deviceAttributes\":{\"mfgCode\":\"APL\",\"mfgName\":\"Apple\",\"prodName\":\"IPHONE XS MAX SPACE GRAY 64GB VZ\",\"prodType\":\"4GSmartphone-JU\",\"equipModeCode\":\"4GE\",\"equipMode\":\"4G\",\"gpsIndicator\":\"Y\",\"daccCode\":\"01188\",\"deviceType\":\"4GE\",\"deviceCategory\":\"4G Smartphone\",\"productId\":\"dev10640019\",\"postpaidRestrictStartDate\":\"\",\"prepayRestrictStartDate\":\"\",\"wholesaleRestrictStartDate\":\"\"},\"lostAndStolen\":{\"lostStolen\":\"N\",\"nonPay\":\"N\"},\"numbershareCapability\":\"\",\"price\":{\"fullRetailPrice\":{\"originalPrice\":\"999.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"Full Retail Price\"},\"oneYearPrice\":{\"originalPrice\":\"999.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"One Year Price\"},\"devicePaymentPrice\":[]},\"skipSimIdFlag\":false,\"appleWatchFlag\":false,\"fmipLocked\":false,\"e911AddrInd\":\"\",\"simClass4G\":\"PI\",\"makeEtniPersApi\":false,\"softMessages\":[],\"standalonePairingEligible\":true,\"deviceFamilyType\":\"Phone\",\"osType\":\"Apple iOS\",\"euiccCapable\":\"\",\"imei1\":\"357270090298694\",\"imei2\":\"357270090381920\"}}}}}";
			String sampleResponseString =  "{\"meta\":{\"timestamp\":\"1576738912272\",\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"userId\":\"kumasa1\",\"isVzPhEligible\":null},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"billingSystem\":\"CXP\",\"totalTaxAmount\":38.75,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"orderActivityType\":0,\"numOfLinesForOrderActivityType\":0,\"totalDueMonthlyAfterDiscounts\":0.0,\"totalActivationFees\":0.0,\"fiosAccountInfo\":null},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"lteHomeLine\":false,\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true,\"workEmailId\":null},\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"isSharePlanAdded\":false,\"hasVerizonCloudUnlimitedIncluded\":null},\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"shipping\":{\"address\":{\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"shippingCost\":0.0,\"sddSetupIncluded\":null},\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"totalPriceWithDiscount\":0.0,\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":499.99,\"buyOutTaxAmountUnbilled\":0.0,\"buyOutAmountWithoutTax\":0.0,\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":0.0,\"btaEligible\":true,\"catalogPrice\":499.99,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"itemSeqNum\":0,\"year\":0,\"financeOptionDetail\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"totalPriceWithDiscount\":0.0,\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"qty\":\"1\",\"bundleSeqNum\":0,\"buyOutTaxAmountUnbilled\":0.0,\"buyOutAmountWithoutTax\":0.0,\"taxAmount\":0.0,\"itemSeqNum\":0,\"year\":0,\"financeOptionDetail\":null},{\"itemCode\":\"WAR6002\",\"totalPriceWithDiscount\":0.0,\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"qty\":1,\"bundleSeqNum\":0,\"buyOutTaxAmountUnbilled\":0.0,\"buyOutAmountWithoutTax\":0.0,\"taxAmount\":0.0,\"itemSeqNum\":0,\"year\":0,\"financeOptionDetail\":null}]},\"refundItemExchangeInfo\":null}],\"lineRefundTotal\":0.0,\"lineExchangeTotal\":0.0,\"totalDueMonthlyBeforeCredit\":0.0,\"isBroadBand\":false,\"protectionNotRequired\":false,\"preOrderInServiceDate\":null}],\"rfexPayments\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10,\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\",\"promoOverlayEnable\":false},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\",\"promoOverlayEnable\":false,\"offerType\":null}]}]},\"accountEligibility\":false,\"isFiosCustomer\":null},\"deviceInfo\":{\"mtn\":\"4434541510\",\"deviceId\":\"353246105032488\"},\"esimInfo\":{\"eId\":\"4556723\"}}}";
			String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"deviceId\":\"dev23534545\",\"processingMTN\": \"1234567890\", \"cartCreator\": \"\", \"accountNumber\": \"5787535348\", \"mtn\": \"7644321167\"}";
			CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
			DeviceIdValidationUIResponse sampleUIRequest = mapper.readValue(sampleUIRequestString, DeviceIdValidationUIResponse.class);
			DeviceSimValidationUIRequest uiRequest = new DeviceSimValidationUIRequest();
			uiRequest.setDevid("356347105542208");
			uiRequest.setEid("89049032005008882600031910586762");
			DeviceSimValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceSimValidationCXPResponse.class);
			when(cxpService.deviceSimValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
			when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
			Mono<DeviceSimValidationCXPResponse> response = helper.deviceSimValidationWithEid(sampleUIRequest ,uiRequest );
			StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		}
		
		@Test
		public void deviceSimValidationWithEidTest4() throws IOException {
			String sampleUIRequestString ="{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2021.11.02.17.56.21-686.4415005162814\"},\"serviceBody\":{\"serviceResponse\":{\"context\":null,\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"2103815015\",\"processingMTN\":\"\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false},\"deviceInfo\":null,\"deviceSimCompatible\":\"\",\"deviceSimM2MPair\":\"\",\"deviceESimCompatible\":\"\",\"deviceESimM2MPair\":\"\",\"deviceId\":\"357270090298694\",\"color\":{\"colorId\":\"clr640001\",\"displayName\":\"Space Gray\",\"description\":\"Gray\",\"colorCssStyle\":\"#807F84\"},\"imageName\":\"apple-iphonexs-max-spacegrey\",\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphonexs-max-spacegrey\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphonexs-max-spacegrey?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphonexs-max-spacegrey?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphonexs-max-spacegrey?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphonexs-max-spacegrey?$device-thumb$\"},\"skuDisplayName\":\"Apple iPhone XS Max 64GB in Space Gray\",\"deviceSku\":\"MT6F2LL/A\",\"isRestrictedDevice\":\"N\",\"deviceAttributes\":{\"mfgCode\":\"APL\",\"mfgName\":\"Apple\",\"prodName\":\"IPHONE XS MAX SPACE GRAY 64GB VZ\",\"prodType\":\"4GSmartphone-JU\",\"equipModeCode\":\"4GE\",\"equipMode\":\"4G\",\"gpsIndicator\":\"Y\",\"daccCode\":\"01188\",\"deviceType\":\"4GE\",\"deviceCategory\":\"4G Smartphone\",\"productId\":\"dev10640019\",\"postpaidRestrictStartDate\":\"\",\"prepayRestrictStartDate\":\"\",\"wholesaleRestrictStartDate\":\"\"},\"lostAndStolen\":{\"lostStolen\":\"N\",\"nonPay\":\"N\"},\"numbershareCapability\":\"\",\"price\":{\"fullRetailPrice\":{\"originalPrice\":\"999.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"Full Retail Price\"},\"oneYearPrice\":{\"originalPrice\":\"999.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"One Year Price\"},\"devicePaymentPrice\":[]},\"skipSimIdFlag\":false,\"appleWatchFlag\":false,\"fmipLocked\":false,\"e911AddrInd\":\"\",\"simClass4G\":\"PI\",\"makeEtniPersApi\":false,\"softMessages\":[],\"standalonePairingEligible\":true,\"deviceFamilyType\":\"Phone\",\"osType\":\"Apple iOS\",\"euiccCapable\":\"\",\"imei1\":\"357270090298694\",\"imei2\":\"357270090381920\"}}}}}";
			String sampleResponseString =  "{\"meta\":{\"timestamp\":\"1576738912272\",\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"userId\":\"kumasa1\",\"isVzPhEligible\":null},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"billingSystem\":\"CXP\",\"totalTaxAmount\":38.75,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"orderActivityType\":0,\"numOfLinesForOrderActivityType\":0,\"totalDueMonthlyAfterDiscounts\":0.0,\"totalActivationFees\":0.0,\"fiosAccountInfo\":null},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"lteHomeLine\":false,\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true,\"workEmailId\":null},\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"isSharePlanAdded\":false,\"hasVerizonCloudUnlimitedIncluded\":null},\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"shipping\":{\"address\":{\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"shippingCost\":0.0,\"sddSetupIncluded\":null},\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"totalPriceWithDiscount\":0.0,\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":499.99,\"buyOutTaxAmountUnbilled\":0.0,\"buyOutAmountWithoutTax\":0.0,\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":0.0,\"btaEligible\":true,\"catalogPrice\":499.99,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"itemSeqNum\":0,\"year\":0,\"financeOptionDetail\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"totalPriceWithDiscount\":0.0,\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"qty\":\"1\",\"bundleSeqNum\":0,\"buyOutTaxAmountUnbilled\":0.0,\"buyOutAmountWithoutTax\":0.0,\"taxAmount\":0.0,\"itemSeqNum\":0,\"year\":0,\"financeOptionDetail\":null},{\"itemCode\":\"WAR6002\",\"totalPriceWithDiscount\":0.0,\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"qty\":1,\"bundleSeqNum\":0,\"buyOutTaxAmountUnbilled\":0.0,\"buyOutAmountWithoutTax\":0.0,\"taxAmount\":0.0,\"itemSeqNum\":0,\"year\":0,\"financeOptionDetail\":null}]},\"refundItemExchangeInfo\":null}],\"lineRefundTotal\":0.0,\"lineExchangeTotal\":0.0,\"totalDueMonthlyBeforeCredit\":0.0,\"isBroadBand\":false,\"protectionNotRequired\":false,\"preOrderInServiceDate\":null}],\"rfexPayments\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10,\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\",\"promoOverlayEnable\":false},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\",\"promoOverlayEnable\":false,\"offerType\":null}]}]},\"accountEligibility\":false,\"isFiosCustomer\":null},\"deviceInfo\":{\"mtn\":\"4434541510\",\"deviceId\":\"353246105032488\"},\"esimInfo\":{\"eId\":\"4556723\"}}}";
			String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"deviceId\":\"dev23534545\",\"processingMTN\": \"1234567890\", \"cartCreator\": \"\", \"accountNumber\": \"5787535348\", \"mtn\": \"7644321167\"}";
			CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
			DeviceIdValidationUIResponse sampleUIRequest = mapper.readValue(sampleUIRequestString, DeviceIdValidationUIResponse.class);
			DeviceSimValidationUIRequest uiRequest = new DeviceSimValidationUIRequest();
			uiRequest.setDevid("356347105542208");
			uiRequest.setEid("89049032005008882600031910586762");
			DeviceSimValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceSimValidationCXPResponse.class);
			when(cxpService.deviceSimValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
			when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
			Mono<DeviceSimValidationCXPResponse> response = helper.deviceSimValidationWithEid(sampleUIRequest ,uiRequest );
			StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		}
		
		@Test
		public void deviceSimValidationWithEidTest5() throws IOException {
			String sampleUIRequestString ="{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2021.11.02.17.56.21-686.4415005162814\"},\"serviceBody\":{\"serviceResponse\":null}}";
			String sampleResponseString =  "{\"meta\":{\"timestamp\":\"1576738912272\",\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"userId\":\"kumasa1\",\"isVzPhEligible\":null},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"billingSystem\":\"CXP\",\"totalTaxAmount\":38.75,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"orderActivityType\":0,\"numOfLinesForOrderActivityType\":0,\"totalDueMonthlyAfterDiscounts\":0.0,\"totalActivationFees\":0.0,\"fiosAccountInfo\":null},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"lteHomeLine\":false,\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true,\"workEmailId\":null},\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"isSharePlanAdded\":false,\"hasVerizonCloudUnlimitedIncluded\":null},\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"shipping\":{\"address\":{\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"shippingCost\":0.0,\"sddSetupIncluded\":null},\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"totalPriceWithDiscount\":0.0,\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":499.99,\"buyOutTaxAmountUnbilled\":0.0,\"buyOutAmountWithoutTax\":0.0,\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":0.0,\"btaEligible\":true,\"catalogPrice\":499.99,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"itemSeqNum\":0,\"year\":0,\"financeOptionDetail\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"totalPriceWithDiscount\":0.0,\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"qty\":\"1\",\"bundleSeqNum\":0,\"buyOutTaxAmountUnbilled\":0.0,\"buyOutAmountWithoutTax\":0.0,\"taxAmount\":0.0,\"itemSeqNum\":0,\"year\":0,\"financeOptionDetail\":null},{\"itemCode\":\"WAR6002\",\"totalPriceWithDiscount\":0.0,\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"qty\":1,\"bundleSeqNum\":0,\"buyOutTaxAmountUnbilled\":0.0,\"buyOutAmountWithoutTax\":0.0,\"taxAmount\":0.0,\"itemSeqNum\":0,\"year\":0,\"financeOptionDetail\":null}]},\"refundItemExchangeInfo\":null}],\"lineRefundTotal\":0.0,\"lineExchangeTotal\":0.0,\"totalDueMonthlyBeforeCredit\":0.0,\"isBroadBand\":false,\"protectionNotRequired\":false,\"preOrderInServiceDate\":null}],\"rfexPayments\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10,\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\",\"promoOverlayEnable\":false},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\",\"promoOverlayEnable\":false,\"offerType\":null}]}]},\"accountEligibility\":false,\"isFiosCustomer\":null},\"deviceInfo\":{\"mtn\":\"4434541510\",\"deviceId\":\"353246105032488\"},\"esimInfo\":{\"eId\":\"4556723\"}}}";
			String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"deviceId\":\"dev23534545\",\"processingMTN\": \"1234567890\", \"cartCreator\": \"\", \"accountNumber\": \"5787535348\", \"mtn\": \"7644321167\"}";
			CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
			DeviceIdValidationUIResponse sampleUIRequest = mapper.readValue(sampleUIRequestString, DeviceIdValidationUIResponse.class);
			DeviceSimValidationUIRequest uiRequest = new DeviceSimValidationUIRequest();
			uiRequest.setDevid("356347105542208");
			uiRequest.setEid("89049032005008882600031910586762");
			DeviceSimValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceSimValidationCXPResponse.class);
			when(cxpService.deviceSimValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
			when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
			Mono<DeviceSimValidationCXPResponse> response = helper.deviceSimValidationWithEid(sampleUIRequest ,uiRequest );
			StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		}
		
		@Test
		public void deviceSimValidationWithEidTest6() throws IOException {
			String sampleUIRequestString ="{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2021.11.02.17.56.21-686.4415005162814\"},\"serviceBody\":null}";
			String sampleResponseString =  "{\"meta\":{\"timestamp\":\"1576738912272\",\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"userId\":\"kumasa1\",\"isVzPhEligible\":null},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"billingSystem\":\"CXP\",\"totalTaxAmount\":38.75,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"orderActivityType\":0,\"numOfLinesForOrderActivityType\":0,\"totalDueMonthlyAfterDiscounts\":0.0,\"totalActivationFees\":0.0,\"fiosAccountInfo\":null},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"lteHomeLine\":false,\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true,\"workEmailId\":null},\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"isSharePlanAdded\":false,\"hasVerizonCloudUnlimitedIncluded\":null},\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"shipping\":{\"address\":{\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"shippingCost\":0.0,\"sddSetupIncluded\":null},\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"totalPriceWithDiscount\":0.0,\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":499.99,\"buyOutTaxAmountUnbilled\":0.0,\"buyOutAmountWithoutTax\":0.0,\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":0.0,\"btaEligible\":true,\"catalogPrice\":499.99,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"itemSeqNum\":0,\"year\":0,\"financeOptionDetail\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"totalPriceWithDiscount\":0.0,\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"qty\":\"1\",\"bundleSeqNum\":0,\"buyOutTaxAmountUnbilled\":0.0,\"buyOutAmountWithoutTax\":0.0,\"taxAmount\":0.0,\"itemSeqNum\":0,\"year\":0,\"financeOptionDetail\":null},{\"itemCode\":\"WAR6002\",\"totalPriceWithDiscount\":0.0,\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"qty\":1,\"bundleSeqNum\":0,\"buyOutTaxAmountUnbilled\":0.0,\"buyOutAmountWithoutTax\":0.0,\"taxAmount\":0.0,\"itemSeqNum\":0,\"year\":0,\"financeOptionDetail\":null}]},\"refundItemExchangeInfo\":null}],\"lineRefundTotal\":0.0,\"lineExchangeTotal\":0.0,\"totalDueMonthlyBeforeCredit\":0.0,\"isBroadBand\":false,\"protectionNotRequired\":false,\"preOrderInServiceDate\":null}],\"rfexPayments\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10,\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\",\"promoOverlayEnable\":false},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\",\"promoOverlayEnable\":false,\"offerType\":null}]}]},\"accountEligibility\":false,\"isFiosCustomer\":null},\"deviceInfo\":{\"mtn\":\"4434541510\",\"deviceId\":\"353246105032488\"},\"esimInfo\":{\"eId\":\"4556723\"}}}";
			String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"deviceId\":\"dev23534545\",\"processingMTN\": \"1234567890\", \"cartCreator\": \"\", \"accountNumber\": \"5787535348\", \"mtn\": \"7644321167\"}";
			CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
			DeviceIdValidationUIResponse sampleUIRequest = mapper.readValue(sampleUIRequestString, DeviceIdValidationUIResponse.class);
			DeviceSimValidationUIRequest uiRequest = new DeviceSimValidationUIRequest();
			uiRequest.setDevid("356347105542208");
			uiRequest.setEid("89049032005008882600031910586762");
			DeviceSimValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceSimValidationCXPResponse.class);
			when(cxpService.deviceSimValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
			when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
			Mono<DeviceSimValidationCXPResponse> response = helper.deviceSimValidationWithEid(sampleUIRequest ,uiRequest );
			StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		}

	@Test
	public void initiateRPSFlow() {
		DeviceIdValidationPEGARequest request = new DeviceIdValidationPEGARequest();
		DeviceIdValidationPEGARequest response = deviceIdValidationRequestFormatter.initiateRPSFlow(true, "123ef", "", "", request);
		StepVerifier.create(Mono.just(request))
				.assertNext(req -> Assert.assertNotNull(request))
				.expectComplete().verify();
		DeviceIdValidationPEGARequest request2 = new DeviceIdValidationPEGARequest();
		DeviceIdValidationPEGARequest response2 = deviceIdValidationRequestFormatter.initiateRPSFlow(false, "123ef", "", "", request2);
		StepVerifier.create(Mono.just(request))
				.assertNext(req -> Assert.assertNotNull(request2))
				.expectComplete().verify();
	}
}
