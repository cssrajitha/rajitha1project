package onevz.soe.cart.service.test.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.addDevice.*;
import onevz.soe.cart.model.addE911Address.E911Address;
import onevz.soe.cart.model.common.Device;
import onevz.soe.cart.model.common.FiveG.Line;
import onevz.soe.cart.model.common.FixedWirelessRequest;
import onevz.soe.cart.model.common.ServiceAddress;
import onevz.soe.cart.model.createLine.HomeSalesAddress;
import onevz.soe.cart.model.retrieveCart.CXPCartVO;
import onevz.soe.cart.model.retrieveCart.CXPLineDetailsVO;
import onevz.soe.cart.model.retrieveCart.CXPLineInfo;
import onevz.soe.cart.model.retrieveCart.CXPRetrieveCartDataVO;
import onevz.soe.cart.responses.FiveGAddressRedisData;
import onevz.soe.cart.ui.common.AddDeviceData;
import onevz.soe.cart.ui.common.CartInfo;
import onevz.soe.cart.ui.common.DeviceCartInfo;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.SaveCartUIRequest;
import onevz.soe.cart.ui.requests.TechCBandData;
import onevz.soe.cart.ui.responses.AddDeviceUIResponse;
import onevz.soe.cart.ui.responses.SaveCartUIResponse;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import onevz.soe.cart.model.common.FiveG.BundleDetails;
import onevz.soe.cart.model.common.FiveG.FiveGLTEAddressRedis;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.requests.AddDeviceUIRequest;
import onevz.soe.cart.ui.requests.AddPlanAndDeviceUIRequest;
import onevz.soe.cart.util.CartAddDeviceUtil;
import onevz.soe.cart.util.SourceFileReaderUtil;

import jakarta.validation.constraints.AssertTrue;

import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertFalse;


@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(CartAddDeviceUtil.class)
public class CartAddDeviceUtilTest {

	@Autowired
	private ObjectMapper mapper;

	@Autowired
	SourceFileReaderUtil sourceFileReaderUtil;

	@Value("${onevz.soe.cart.test.fileLocation}")
	private String testFileLocation;


	@Test
	public void populateSwapFiveGAddressFlowTest() throws JsonProcessingException {
		AddPlanAndDeviceUIRequest addPlanAndDeviceUIRequest=new AddPlanAndDeviceUIRequest();
		FiveGLTEAddressRedis fiveGLTEAddressRedis=new FiveGLTEAddressRedis();
		String requestString="{  \"cartInfo\": {    \"clientAppName\": \"VZW-DOTCOM\",    \"cartId\": \"\",    \"caseId\": \"\",    \"accountNumber\": \"\",    \"cartCreator\": \"2482006791\",    \"processingMTN\": \"\",\n" +
				"    \"processStep\": \"OrderNow\",    \"processAction\": \"DeviceAndPlan\",    \"intendType\": \"EUP_5G_REPAIR\",    \"bundleInstallType\": \"5GHomeGeminiProfSetup\"  },  \"data\": {\n" +
				"    \"lines\": [      {        \"depletionType\": \"O\",        \"mtn\": \"2482006791\"      }    ]  }}";

		addPlanAndDeviceUIRequest = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		FiveGLTEAddressRedis address = new FiveGLTEAddressRedis();

		CartAddDeviceUtil.populateSwapFiveGAddressFlow(addPlanAndDeviceUIRequest, fiveGLTEAddressRedis);
		//StepVerifier.create(controllerResponse).assertNext(resp -> org.junit.Assert.assertEquals(customerProfileAddressResponseData, resp)).expectComplete().verify();

        fiveGLTEAddressRedis.setBundleList(null);
        CartAddDeviceUtil.populateSwapFiveGAddressFlow(addPlanAndDeviceUIRequest, fiveGLTEAddressRedis);
        fiveGLTEAddressRedis.setAddressLine2("random");
        fiveGLTEAddressRedis.setFloor(01);
        CartAddDeviceUtil.populateSwapFiveGAddressFlow(addPlanAndDeviceUIRequest, fiveGLTEAddressRedis);
        fiveGLTEAddressRedis.setAddressLine2(null);
        fiveGLTEAddressRedis.setFloor(null);
        BundleDetails BundleDetailsObj = new BundleDetails();
        BundleDetailsObj.setId("random");
        fiveGLTEAddressRedis.setBundleList(Arrays.asList(BundleDetailsObj, BundleDetailsObj));
        CartAddDeviceUtil.populateSwapFiveGAddressFlow(addPlanAndDeviceUIRequest, fiveGLTEAddressRedis);
        addPlanAndDeviceUIRequest.getData().setLines(Collections.emptyList());
        CartAddDeviceUtil.populateSwapFiveGAddressFlow(addPlanAndDeviceUIRequest, fiveGLTEAddressRedis);
        addPlanAndDeviceUIRequest.getData().setLines(null);
        CartAddDeviceUtil.populateSwapFiveGAddressFlow(addPlanAndDeviceUIRequest, fiveGLTEAddressRedis);
        addPlanAndDeviceUIRequest.getData().setLines(Arrays.asList(new Line()));
        CartAddDeviceUtil.populateSwapFiveGAddressFlow(addPlanAndDeviceUIRequest, fiveGLTEAddressRedis);
        fiveGLTEAddressRedis.setBundleList(Collections.emptyList());
        CartAddDeviceUtil.populateSwapFiveGAddressFlow(addPlanAndDeviceUIRequest, fiveGLTEAddressRedis);

	}
	@Test
	public void populateFiveGAddressFiveGHomeFlowLineTest() throws JsonProcessingException {
		AddPlanAndDeviceUIRequest addPlanAndDeviceUIRequest=new AddPlanAndDeviceUIRequest();
		FiveGLTEAddressRedis fiveGLTEAddressRedis=new FiveGLTEAddressRedis();
		String requestString="{  \"cartInfo\": {    \"clientAppName\": \"VZW-DOTCOM\",    \"cartId\": \"\",    \"caseId\": \"\",    \"accountNumber\": \"\",    \"cartCreator\": \"2482006791\",    \"processingMTN\": \"\",\n" +
				"    \"processStep\": \"OrderNow\",    \"processAction\": \"DeviceAndPlan\",    \"intendType\": \"EUP_5G_REPAIR\",    \"bundleInstallType\": \"5GHomeGeminiProfSetup\"  },  \"data\": {\n" +
				"      }}";
		addPlanAndDeviceUIRequest = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		FiveGLTEAddressRedis address = new FiveGLTEAddressRedis();
		CartRedisData data=new CartRedisData();
        data.setLvSoftSku("LOCNOTE");
		CartAddDeviceUtil.populateFiveGAddressFiveGHomeFlow(addPlanAndDeviceUIRequest,address, data);
        List<BundleDetails> bundleList = new ArrayList<>();
        address.setBundleList(bundleList);
        address.setIsD2DFlow("true");
        address.setLaunchType(CartConstants.LAUNCHTYPE_FCL);
        addPlanAndDeviceUIRequest.getCartInfo().setCrmResumeCartFlow("false");
        addPlanAndDeviceUIRequest.getCartInfo().setIntendType("5G");
        addPlanAndDeviceUIRequest.getCartInfo().setProcessStep("random");
        CartAddDeviceUtil.populateFiveGAddressFiveGHomeFlow(addPlanAndDeviceUIRequest,address, data);

        address.setIsD2DFlow("true");
        address.setLaunchType(CartConstants.LAUNCHTYPE_FCL);
        addPlanAndDeviceUIRequest.getCartInfo().setCrmResumeCartFlow("true");
        addPlanAndDeviceUIRequest.getCartInfo().setIntendType("random");
        addPlanAndDeviceUIRequest.getCartInfo().setProcessStep("random");
        CartAddDeviceUtil.populateFiveGAddressFiveGHomeFlow(addPlanAndDeviceUIRequest,address, data);

        addPlanAndDeviceUIRequest.getCartInfo().setCrmResumeCartFlow("false");
        address.setLaunchType("random");
        address.setLaunchType(CartConstants.LAUNCHTYPE_FCL);
        addPlanAndDeviceUIRequest.getCartInfo().setIntendType("5G");
        addPlanAndDeviceUIRequest.getCartInfo().setProcessStep("random");
        CartAddDeviceUtil.populateFiveGAddressFiveGHomeFlow(addPlanAndDeviceUIRequest,address, data);

        address.setIsD2DFlow("true");
        addPlanAndDeviceUIRequest.getCartInfo().setCrmResumeCartFlow("false");
        address.setLaunchType(CartConstants.LAUNCHTYPE_FCL);
        addPlanAndDeviceUIRequest.getCartInfo().setIntendType("random");
        addPlanAndDeviceUIRequest.getCartInfo().setProcessStep("random");
        CartAddDeviceUtil.populateFiveGAddressFiveGHomeFlow(addPlanAndDeviceUIRequest,address, data);

        address.setIsD2DFlow("true");
        addPlanAndDeviceUIRequest.getCartInfo().setCrmResumeCartFlow("false");
        address.setLaunchType(CartConstants.LAUNCHTYPE_FCL);
        addPlanAndDeviceUIRequest.getCartInfo().setIntendType("5G");
        addPlanAndDeviceUIRequest.getCartInfo().setProcessStep("Accessories");
        CartAddDeviceUtil.populateFiveGAddressFiveGHomeFlow(addPlanAndDeviceUIRequest,address, data);

        address.setIsD2DFlow("true");
        addPlanAndDeviceUIRequest.getCartInfo().setCrmResumeCartFlow("false");
        address.setLaunchType(CartConstants.LAUNCHTYPE_FCL);
        addPlanAndDeviceUIRequest.getCartInfo().setIntendType("5G");
        addPlanAndDeviceUIRequest.getCartInfo().setProcessStep("random");
        CartAddDeviceUtil.populateFiveGAddressFiveGHomeFlow(addPlanAndDeviceUIRequest,address, data);

        addPlanAndDeviceUIRequest.getData().setLines(Collections.emptyList());
        CartAddDeviceUtil.populateFiveGAddressFiveGHomeFlow(addPlanAndDeviceUIRequest,address, data);
        addPlanAndDeviceUIRequest.getData().setLines(null);
        CartAddDeviceUtil.populateFiveGAddressFiveGHomeFlow(addPlanAndDeviceUIRequest,address, data);
        addPlanAndDeviceUIRequest.getData().setLines(Arrays.asList(new Line()));
        CartAddDeviceUtil.populateFiveGAddressFiveGHomeFlow(addPlanAndDeviceUIRequest,address, data);
        Assert.assertNotNull(addPlanAndDeviceUIRequest.getData().getLines().get(0).getDevice());
        addPlanAndDeviceUIRequest.getData().setLines(Arrays.asList(new Line(),new Line(), new Line()));
        addPlanAndDeviceUIRequest.getCartInfo().setNetworkBandwidthType("random");
        CartAddDeviceUtil.populateFiveGAddressFiveGHomeFlow(addPlanAndDeviceUIRequest,address, data);
        addPlanAndDeviceUIRequest.getCartInfo().setIntendType("random");
        CartAddDeviceUtil.populateFiveGAddressFiveGHomeFlow(addPlanAndDeviceUIRequest,address, data);

        address.setLTEHomeQualified("true");
        addPlanAndDeviceUIRequest.getCartInfo().setProcessStep("Accessories");
        addPlanAndDeviceUIRequest.getCartInfo().setIntendType(CartConstants.INTENT_EUP_LTE);
        addPlanAndDeviceUIRequest.getCartInfo().setNetworkBandwidthType("CBD");
        addPlanAndDeviceUIRequest.getCartInfo().setPriceType("VERIZON_EDGE");
        CartAddDeviceUtil.populateFiveGAddressFiveGHomeFlow(addPlanAndDeviceUIRequest,address, data);

        address.setLTEHomeQualified("false");
        addPlanAndDeviceUIRequest.getCartInfo().setProcessStep("Accessories");
        addPlanAndDeviceUIRequest.getCartInfo().setIntendType("random");
        addPlanAndDeviceUIRequest.getCartInfo().setNetworkBandwidthType("CBD");
        addPlanAndDeviceUIRequest.getCartInfo().setPriceType("VERIZON_EDGE");
        CartAddDeviceUtil.populateFiveGAddressFiveGHomeFlow(addPlanAndDeviceUIRequest,address, data);

        address.setLTEHomeQualified("false");
        addPlanAndDeviceUIRequest.getCartInfo().setProcessStep("random");
        addPlanAndDeviceUIRequest.getCartInfo().setIntendType(CartConstants.INTENT_EUP_LTE);
        addPlanAndDeviceUIRequest.getCartInfo().setNetworkBandwidthType("random");
        addPlanAndDeviceUIRequest.getCartInfo().setPriceType("VERIZON_EDGE");
        CartAddDeviceUtil.populateFiveGAddressFiveGHomeFlow(addPlanAndDeviceUIRequest,address, data);

        addPlanAndDeviceUIRequest.getCartInfo().setTransactionType(CartConstants.LTE_CBD_TRANSACTIONTYPE);
        addPlanAndDeviceUIRequest.getCartInfo().setIntendType(CartConstants.EUP_5G);
        CartAddDeviceUtil.populateFiveGAddressFiveGHomeFlow(addPlanAndDeviceUIRequest,address, data);

        data.setEventCorrelationId("45202_1681390250502_97");
        CartAddDeviceUtil.populateFiveGAddressFiveGHomeFlow(addPlanAndDeviceUIRequest,address, data);

        address.setEventCorrelationId("45202_1681390250502_97");
        CartAddDeviceUtil.populateFiveGAddressFiveGHomeFlow(addPlanAndDeviceUIRequest,address, data);

        address.setLaunchType(null);
        address.setIsD2DFlow("false");
        addPlanAndDeviceUIRequest.getCartInfo().setNetworkBandwidthType("TGW");
        CartAddDeviceUtil.populateFiveGAddressFiveGHomeFlow(addPlanAndDeviceUIRequest,address, data);

        address.setLaunchType(null);
        address.setIsD2DFlow("false");
        addPlanAndDeviceUIRequest.getCartInfo().setNetworkBandwidthType("CBD");
        CartAddDeviceUtil.populateFiveGAddressFiveGHomeFlow(addPlanAndDeviceUIRequest,address, data);
    }
	@Test
	public void populateFiveGAddressFiveGHomeFlowTest() throws JsonProcessingException {
		AddPlanAndDeviceUIRequest addPlanAndDeviceUIRequest=new AddPlanAndDeviceUIRequest();
		FiveGLTEAddressRedis fiveGLTEAddressRedis=new FiveGLTEAddressRedis();
		String requestString="{  \"cartInfo\": {    \"clientAppName\": \"VZW-DOTCOM\", \"networkBandwidthType\": \"NSE_5G\", \"bundleInstallType\": \"NSE_5G\",  \"cartId\": \"\",  \"intendType\": \"NSE_5G\",   \"caseId\": \"\",    \"accountNumber\": \"\",    \"cartCreator\": \"2482006791\",    \"processingMTN\": \"\",\n" +
				"    \"processStep\": \"OrderNow\",    \"processAction\": \"DeviceAndPlan\",    \"intendType\": \"EUP_5G_REPAIR\",    \"bundleInstallType\": \"5GHomeGeminiProfSetup\"  },  \"data\": {\n" +
				"    \"lines\": [      {        \"depletionType\": \"O\",        \"mtn\": \"2482006791\"      }    ]  }}";
		addPlanAndDeviceUIRequest = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		FiveGLTEAddressRedis address = new FiveGLTEAddressRedis();
		address.setLaunchType("FCL");
		List<BundleDetails> bundleList=new ArrayList<>();
		BundleDetails bundleDetails=new BundleDetails();
		bundleDetails.setId("Bundle");
		bundleDetails.setBundleName("5GHomeGeminiProfSetup");
		bundleList.add(bundleDetails);
		address.setBundleList(bundleList);
		CartRedisData data=new CartRedisData();
		CartAddDeviceUtil.populateFiveGAddressFiveGHomeFlow(addPlanAndDeviceUIRequest,address, data);
        Assert.assertTrue(addPlanAndDeviceUIRequest.getData().getLines().get(0).getIsNewLine());
	}
	@Test
	public void populateFiveGAddressFiveGHomeFlowLTETest() throws JsonProcessingException {
		AddPlanAndDeviceUIRequest addPlanAndDeviceUIRequest=new AddPlanAndDeviceUIRequest();
		FiveGLTEAddressRedis fiveGLTEAddressRedis=new FiveGLTEAddressRedis();
		String requestString="{  \"cartInfo\": {    \"clientAppName\": \"VZW-DOTCOM\", \"priceType\": \"VERIZON_EDGE\", \"networkBandwidthType\": \"NSE_LTE\", \"bundleInstallType\": \"\",  \"cartId\": \"\",  \"intendType\": \"EUP_LTE\",   \"caseId\": \"\",    \"accountNumber\": \"\",    \"cartCreator\": \"2482006791\",    \"processingMTN\": \"\",\n" +
				"    \"processStep\": \"OrderNow\",    \"processAction\": \"DeviceAndPlan\",    \"intendType\": \"EUP_5G_REPAIR\",    \"bundleInstallType\": \"5GHomeGeminiProfSetup\"  },  \"data\": {\n" +
				"    \"lines\": [      {        \"depletionType\": \"O\",        \"mtn\": \"2482006791\"      }    ]  }}";
		addPlanAndDeviceUIRequest = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		FiveGLTEAddressRedis address = new FiveGLTEAddressRedis();
		address.setLTEHomeQualified("true");
		address.setLTEHomeSku("123");
		List<BundleDetails> bundleList=new ArrayList<>();
		BundleDetails bundleDetails=new BundleDetails();
		bundleDetails.setId("Bundle");
		bundleDetails.setBundleName("5GHomeGeminiProfSetup");
		bundleList.add(bundleDetails);
		address.setBundleList(bundleList);
		CartRedisData data=new CartRedisData();
		CartAddDeviceUtil.populateFiveGAddressFiveGHomeFlow(addPlanAndDeviceUIRequest,address, data);
        Assert.assertNotNull(addPlanAndDeviceUIRequest.getData().getLines().get(0).getDevice());
	}
	@Test
	public void populateFiveGAddressFiveGHomeFlowLTETypeTest() throws JsonProcessingException {
		AddPlanAndDeviceUIRequest addPlanAndDeviceUIRequest=new AddPlanAndDeviceUIRequest();
		FiveGLTEAddressRedis fiveGLTEAddressRedis=new FiveGLTEAddressRedis();
		String requestFile = "MockAddDevice5GLTERequest.json";

		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);

		addPlanAndDeviceUIRequest = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		TechCBandData cBandData = new TechCBandData();
		cBandData.setFiveGPlan("DO MORE");
		FiveGLTEAddressRedis address = new FiveGLTEAddressRedis();
		address.setLTEHomeQualified("true");
		address.setLTEHomeSku("123");
		List<BundleDetails> bundleList=new ArrayList<>();
		BundleDetails bundleDetails=new BundleDetails();
		bundleDetails.setId("Bundle");
		bundleDetails.setBundleName("5GHomeGeminiProfSetup");
		bundleList.add(bundleDetails);
		address.setBundleList(bundleList);
		CartRedisData data=new CartRedisData();
		String redisFile = "MockRedisData.json";
		String redisDataString = sourceFileReaderUtil.readFile(redisFile, testFileLocation);
		data = mapper.readValue(redisDataString, CartRedisData.class);
		CartAddDeviceUtil.populateFiveGAddressFiveGHomeFlow(addPlanAndDeviceUIRequest,address, data);
        Assert.assertNotNull(addPlanAndDeviceUIRequest.getData().getLines().get(0).getDevice());
	}
	@Test
	public void populateFiveGAddressFiveGHomeFlowEUPLTETest() throws JsonProcessingException {
		AddPlanAndDeviceUIRequest addPlanAndDeviceUIRequest=new AddPlanAndDeviceUIRequest();
		FiveGLTEAddressRedis fiveGLTEAddressRedis=new FiveGLTEAddressRedis();
		String requestString="{  \"cartInfo\": {    \"clientAppName\": \"VZW-DOTCOM\", \"priceType\": \"VERIZON\",\"dppMonths\": \"12\", \"networkBandwidthType\": \"NSE_LTE\", \"bundleInstallType\": \"\",  \"cartId\": \"\",  \"intendType\": \"EUP_LTE\",   \"caseId\": \"\",    \"accountNumber\": \"\",    \"cartCreator\": \"2482006791\",    \"processingMTN\": \"\",\n" +
				"    \"processStep\": \"OrderNow\",    \"processAction\": \"DeviceAndPlan\",    \"intendType\": \"EUP_LTE\",    \"bundleInstallType\": \"5GHomeGeminiProfSetup\"  },  \"data\": {\n" +
				"    \"lines\": [      {        \"depletionType\": \"O\",        \"mtn\": \"2482006791\"      }    ]  }}";
		addPlanAndDeviceUIRequest = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		FiveGLTEAddressRedis address = new FiveGLTEAddressRedis();
		address.setLTEHomeQualified("true");
		address.setLTEHomeSku("123");
		List<BundleDetails> bundleList=new ArrayList<>();
		BundleDetails bundleDetails=new BundleDetails();
		bundleDetails.setId("Bundle");
		bundleDetails.setBundleName("5GHomeGeminiProfSetup");
		bundleList.add(bundleDetails);
		address.setBundleList(bundleList);
		CartRedisData data=new CartRedisData();
		CartAddDeviceUtil.populateFiveGAddressFiveGHomeFlow(addPlanAndDeviceUIRequest,address, data);
        Assert.assertNotNull(addPlanAndDeviceUIRequest.getData().getLines().get(0).getDevice());

	}
	
	@Test
	public void populateFiveGAddressTest() throws JsonMappingException, JsonProcessingException {
		String request = "{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"processStep\":\"GridWallPDP\",\"processingMTN\":\"2032530097\",\"processAction\":\"addDevice\",\"intendType\":\"AAL\",\"number_share_capable\":\"Y\",\"creditAppNum\":null,\"isQuoteCart\":false,\"bogoEnabled\":\"True\"},\"data\":{\"lines\":[{\"mtn\":\"2032530097\",\"lineDeviceDollar\":0,\"upgradeReasonCode\":\"\",\"device\":{\"category\":\"\",\"deviceId\":\"\",\"id\":\"ASK-NCQ1338\",\"contractTerm\":\"MONTH_TO_MONTH\",\"dppMonths\":\"\",\"isCustomerProvidedEquipment\":false,\"networkBandwidthType\":\"LTE\"},\"sim\":{\"id\":\"DFILLSIM-TRI-A\",\"iccid\":\"\",\"isCustomerProvidedSIM\":false},\"fiveG\":{\"address\":{\"streetNumber\":\"121\",\"streetName\":\"NICHOLS\",\"streetType\":\"AVE\",\"addressLine1\":\"121 NICHOLS AVE \",\"addressLine2\":\"\",\"apartmentNo\":\"\",\"city\":\"STAMFORD\",\"state\":\"CT\",\"zipCode\":\"06905\",\"zipCode4\":\"2229\",\"firstName\":\"FORTUNE\",\"lastName\":\"NOEL\",\"eventCorrelationId\":\"06905_1652876723434_253\"},\"launchType\":\"4GH\"},\"addFeatures\":[{\"id\":\"66332\",\"quantity\":1,\"actionIndicator\":\"A\",\"type\":\"SFO\"}],\"isKeepingExistingEqProtection\":\"\",\"ispuFlow\":false,\"newLineOrAAL\":true,\"isNewLine\":true,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"sddZipCode\":\"\",\"preBackOrderDate\":\"\",\"triggerPricingValidation\":true}],\"selectedMtn\":\"\",\"totalDeviceDollar\":0}}";
		String address = "{\"streetNumber\": \"121\",\"streetName\": \"NICHOLS\",\"streetType\": \"AVE\",\"addressLine2\": \"\",\"apartmentNo\": \"\",\"city\": \"STAMFORD\",\"state\": \"CT\",\"zipCode\": \"06905\",\"zipCode4\": \"2229\",\"firstName\": \"FORTUNE\",\"lastName\": \"NOEL\",\"eventCorrelationId\": \"06905_1652876723434_253\"}";
		AddDeviceUIRequest addDeviceUIRequest = new AddDeviceUIRequest();
		FiveGAddress fiveGAddress = new FiveGAddress();
		fiveGAddress = mapper.readValue(address, FiveGAddress.class);
		addDeviceUIRequest = mapper.readValue(request, AddDeviceUIRequest.class);
		CartAddDeviceUtil.populateFiveGAddress(addDeviceUIRequest, fiveGAddress);


        addDeviceUIRequest.getCartInfo().setIntendType("AAL");
        FiveG FiveGObj = new FiveG();
        FiveGObj.setAddress(null);
        addDeviceUIRequest.getData().getLines().get(0).setFiveG(FiveGObj);
        //addDeviceUIRequest.getData().getLines().get(0).getFiveG().getAddress().setStreetNumber("random");
        //addDeviceUIRequest.getData().getLines().get(0).getFiveG().getAddress().setStreetName("random");
        //addDeviceUIRequest.getData().getLines().get(0).getFiveG().getAddress().setStreetType("random");
        fiveGAddress.setFixedWirelessRequest(new FixedWirelessRequest());
        fiveGAddress.getFixedWirelessRequest().setLatitude(null);
        fiveGAddress.getFixedWirelessRequest().setLongitude(null);
        fiveGAddress.getFixedWirelessRequest().setVendorKey(null);
        CartAddDeviceUtil.populateFiveGAddress(addDeviceUIRequest, fiveGAddress);
        Assert.assertNotNull(addDeviceUIRequest.getData().getLines().get(0).getFiveG().getAddress());
    }
	
	@Test
	public void populateFiveGAddress5GTest() throws JsonMappingException, JsonProcessingException {
		String request = "{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"processStep\":\"GridWallPDP\",\"processingMTN\":\"2032530097\",\"processAction\":\"addDevice\",\"intendType\":\"AAL_5G\",\"number_share_capable\":\"Y\",\"creditAppNum\":null,\"isQuoteCart\":false,\"bogoEnabled\":\"True\"},\"data\":{\"lines\":[{\"mtn\":\"2032530097\",\"lineDeviceDollar\":0,\"upgradeReasonCode\":\"\",\"device\":{\"category\":\"\",\"deviceId\":\"\",\"id\":\"ASK-NCQ1338\",\"contractTerm\":\"MONTH_TO_MONTH\",\"dppMonths\":\"\",\"isCustomerProvidedEquipment\":false,\"networkBandwidthType\":\"LTE\"},\"sim\":{\"id\":\"DFILLSIM-TRI-A\",\"iccid\":\"\",\"isCustomerProvidedSIM\":false},\"fiveG\":{\"address\":{\"streetNumber\":\"121\",\"streetName\":\"NICHOLS\",\"streetType\":\"AVE\",\"addressLine1\":\"121 NICHOLS AVE \",\"addressLine2\":\"\",\"apartmentNo\":\"\",\"city\":\"STAMFORD\",\"state\":\"CT\",\"zipCode\":\"06905\",\"zipCode4\":\"2229\",\"firstName\":\"FORTUNE\",\"lastName\":\"NOEL\",\"eventCorrelationId\":\"06905_1652876723434_253\"},\"launchType\":\"4GH\"},\"addFeatures\":[{\"id\":\"66332\",\"quantity\":1,\"actionIndicator\":\"A\",\"type\":\"SFO\"}],\"isKeepingExistingEqProtection\":\"\",\"ispuFlow\":false,\"newLineOrAAL\":true,\"isNewLine\":true,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"sddZipCode\":\"\",\"preBackOrderDate\":\"\",\"triggerPricingValidation\":true}],\"selectedMtn\":\"\",\"totalDeviceDollar\":0}}";
		String address = "{\"streetNumber\": \"121\",\"streetName\": \"NICHOLS\",\"streetType\": \"AVE\",\"addressLine1\": \"121 NICHOLS AVE \",\"addressLine2\": \"\",\"apartmentNo\": \"\",\"city\": \"STAMFORD\",\"state\": \"CT\",\"zipCode\": \"06905\",\"zipCode4\": \"2229\",\"firstName\": \"FORTUNE\",\"lastName\": \"NOEL\",\"eventCorrelationId\": \"06905_1652876723434_253\"}";
		AddDeviceUIRequest addDeviceUIRequest = new AddDeviceUIRequest();
		FiveGAddress fiveGAddress = new FiveGAddress();
		fiveGAddress = mapper.readValue(address, FiveGAddress.class);
		addDeviceUIRequest = mapper.readValue(request, AddDeviceUIRequest.class);
		CartAddDeviceUtil.populateFiveGAddress(addDeviceUIRequest, fiveGAddress);
        Assert.assertNotNull(addDeviceUIRequest.getData().getLines().get(0).getFiveG().getAddress().getEventCorrelationId());
	}
	
	@Test
	public void isEditDeviceOneClickTest() throws JsonMappingException, JsonProcessingException {
		String request = "{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"processStep\":\"GridWallPDP\",\"processingMTN\":\"2032530097\",\"processAction\":\"addDevice\",\"intendType\":\"AAL_5G\",\"number_share_capable\":\"Y\",\"creditAppNum\":null,\"isQuoteCart\":false,\"bogoEnabled\":\"True\"},\"data\":{\"lines\":[{\"mtn\":\"2032530097\",\"lineDeviceDollar\":0,\"upgradeReasonCode\":\"\",\"device\":{\"category\":\"\",\"deviceId\":\"\",\"id\":\"ASK-NCQ1338\",\"contractTerm\":\"MONTH_TO_MONTH\",\"dppMonths\":\"\",\"isCustomerProvidedEquipment\":false,\"networkBandwidthType\":\"LTE\"},\"sim\":{\"id\":\"DFILLSIM-TRI-A\",\"iccid\":\"\",\"isCustomerProvidedSIM\":false},\"fiveG\":{\"address\":{\"streetNumber\":\"121\",\"streetName\":\"NICHOLS\",\"streetType\":\"AVE\",\"addressLine1\":\"121 NICHOLS AVE \",\"addressLine2\":\"\",\"apartmentNo\":\"\",\"city\":\"STAMFORD\",\"state\":\"CT\",\"zipCode\":\"06905\",\"zipCode4\":\"2229\",\"firstName\":\"FORTUNE\",\"lastName\":\"NOEL\",\"eventCorrelationId\":\"06905_1652876723434_253\"},\"launchType\":\"4GH\"},\"addFeatures\":[{\"id\":\"66332\",\"quantity\":1,\"actionIndicator\":\"A\",\"type\":\"SFO\"}],\"isKeepingExistingEqProtection\":\"\",\"ispuFlow\":false,\"newLineOrAAL\":true,\"isNewLine\":true,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"sddZipCode\":\"\",\"preBackOrderDate\":\"\",\"triggerPricingValidation\":true}],\"selectedMtn\":\"\",\"totalDeviceDollar\":0}}";
		AddDeviceUIRequest addDeviceUIRequest = new AddDeviceUIRequest();
		addDeviceUIRequest = mapper.readValue(request, AddDeviceUIRequest.class);
		String oneClickCheckout = "true";
		assertFalse(CartAddDeviceUtil.isEditDeviceOneClick(addDeviceUIRequest, oneClickCheckout));
	}

    @Test
    public void AllowCradleCheck_ValidEUPIntent_ReturnsTrue() {
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        request.setCartInfo(new DeviceCartInfo());
        request.getCartInfo().setProcessingMTN("1234567890");
        request.getCartInfo().setEditDevice(null);
        AddDeviceData data = new AddDeviceData();
        data.setExpressCheckout(null);
        Lines line = new Lines();
        Device device = new Device();
        device.setCategory("Smartphone");
        line.setDevice(device);
        data.setLines(Collections.singletonList(line));
        request.setData(data);

        boolean result = CartAddDeviceUtil.AllowCradleCheck(request, "EUP");

        assertTrue(result);
    }

    @Test
    public void AllowCradleCheck_ValidUpgradeIntent_ReturnsTrue() {
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        request.setCartInfo(new DeviceCartInfo());
        request.getCartInfo().setProcessingMTN("1234567890");
        request.getCartInfo().setEditDevice(null);
        AddDeviceData data = new AddDeviceData();
        data.setExpressCheckout(null);
        Lines line = new Lines();
        Device device = new Device();
        device.setCategory("Smartphone");
        line.setDevice(device);
        data.setLines(Collections.singletonList(line));
        request.setData(data);

        boolean result = CartAddDeviceUtil.AllowCradleCheck(request, "upgrade");

        assertTrue(result);
    }

    @Test
    public void AllowCradleCheck_ValidAALIntent_ReturnsTrue() {
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        request.setCartInfo(new DeviceCartInfo());
        request.getCartInfo().setEditDevice(null);
        AddDeviceData data = new AddDeviceData();
        data.setExpressCheckout(null);
        Lines line = new Lines();
        Device device = new Device();
        device.setCategory("Smartphone");
        line.setDevice(device);
        data.setLines(Collections.singletonList(line));
        request.setData(data);

        boolean result = CartAddDeviceUtil.AllowCradleCheck(request, "AAL");

        assertTrue(result);
    }

    @Test
    public void AllowCradleCheck_ValidBYODIntent_ReturnsTrue() {
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        request.setCartInfo(new DeviceCartInfo());
        request.getCartInfo().setEditDevice(null);
        AddDeviceData data = new AddDeviceData();
        data.setExpressCheckout(null);
        Lines line = new Lines();
        Device device = new Device();
        device.setCategory("Smartphone");
        line.setDevice(device);
        data.setLines(Collections.singletonList(line));
        request.setData(data);

        boolean result = CartAddDeviceUtil.AllowCradleCheck(request, "BYOD");

        assertTrue(result);
    }

    @Test
    public void AllowCradleCheck_NullIntent_ReturnsFalse() {
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        request.setCartInfo(new DeviceCartInfo());
        request.getCartInfo().setEditDevice(null);
        AddDeviceData data = new AddDeviceData();
        data.setExpressCheckout(null);
        Lines line = new Lines();
        Device device = new Device();
        device.setCategory("Smartphone");
        line.setDevice(device);
        data.setLines(Collections.singletonList(line));
        request.setData(data);

        boolean result = CartAddDeviceUtil.AllowCradleCheck(request, null);

        assertFalse(result);
    }

    @Test
    public void AllowCradleCheck_NullProcessingMTN_ReturnsFalse() {
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        request.setCartInfo(new DeviceCartInfo());
        request.getCartInfo().setProcessingMTN(null);
        request.getCartInfo().setEditDevice(null);
        AddDeviceData data = new AddDeviceData();
        data.setExpressCheckout(null);
        Lines line = new Lines();
        Device device = new Device();
        device.setCategory("Smartphone");
        line.setDevice(device);
        data.setLines(Collections.singletonList(line));
        request.setData(data);

        boolean result = CartAddDeviceUtil.AllowCradleCheck(request, "EUP");

        assertFalse(result);
    }

    @Test
    public void AllowCradleCheck_NullDeviceCategory_ReturnsFalse() {
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        request.setCartInfo(new DeviceCartInfo());
        request.getCartInfo().setProcessingMTN("1234567890");
        request.getCartInfo().setEditDevice(null);
        AddDeviceData data = new AddDeviceData();
        data.setExpressCheckout(null);
        Lines line = new Lines();
        Device device = new Device();
        device.setCategory(null);
        line.setDevice(device);
        data.setLines(Collections.singletonList(line));
        request.setData(data);

        boolean result = CartAddDeviceUtil.AllowCradleCheck(request, "EUP");

        assertFalse(result);
    }
	
	@Test
	public void allowCradleCheckTest() throws JsonMappingException, JsonProcessingException {
		String request = "{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"processStep\":\"GridWallPDP\",\"processingMTN\":\"2032530097\",\"processAction\":\"addDevice\",\"intendType\":\"AAL_5G\",\"number_share_capable\":\"Y\",\"creditAppNum\":null,\"isQuoteCart\":false,\"bogoEnabled\":\"True\"},\"data\":{\"lines\":[{\"mtn\":\"2032530097\",\"lineDeviceDollar\":0,\"upgradeReasonCode\":\"\",\"device\":{\"category\":\"Mobile\",\"deviceId\":\"\",\"id\":\"ASK-NCQ1338\",\"contractTerm\":\"MONTH_TO_MONTH\",\"dppMonths\":\"\",\"isCustomerProvidedEquipment\":false,\"networkBandwidthType\":\"LTE\"},\"sim\":{\"id\":\"DFILLSIM-TRI-A\",\"iccid\":\"\",\"isCustomerProvidedSIM\":false},\"fiveG\":{\"address\":{\"streetNumber\":\"121\",\"streetName\":\"NICHOLS\",\"streetType\":\"AVE\",\"addressLine1\":\"121 NICHOLS AVE \",\"addressLine2\":\"\",\"apartmentNo\":\"\",\"city\":\"STAMFORD\",\"state\":\"CT\",\"zipCode\":\"06905\",\"zipCode4\":\"2229\",\"firstName\":\"FORTUNE\",\"lastName\":\"NOEL\",\"eventCorrelationId\":\"06905_1652876723434_253\"},\"launchType\":\"4GH\"},\"addFeatures\":[{\"id\":\"66332\",\"quantity\":1,\"actionIndicator\":\"A\",\"type\":\"SFO\"}],\"isKeepingExistingEqProtection\":\"\",\"ispuFlow\":false,\"newLineOrAAL\":true,\"isNewLine\":true,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"sddZipCode\":\"\",\"preBackOrderDate\":\"\",\"triggerPricingValidation\":true}],\"selectedMtn\":\"\",\"totalDeviceDollar\":0}}";
		AddDeviceUIRequest addDeviceUIRequest = new AddDeviceUIRequest();
		addDeviceUIRequest = mapper.readValue(request, AddDeviceUIRequest.class);
		String intent = "EUP";
		Assert.assertTrue(CartAddDeviceUtil.AllowCradleCheck(addDeviceUIRequest, intent));

        addDeviceUIRequest.getCartInfo().setEditDevice(true);
        assertFalse(CartAddDeviceUtil.AllowCradleCheck(addDeviceUIRequest, intent));
        addDeviceUIRequest.getCartInfo().setExpressCheckout(true);
        assertFalse(CartAddDeviceUtil.AllowCradleCheck(addDeviceUIRequest, intent));
        addDeviceUIRequest.getData().setLines(null);
        assertFalse(CartAddDeviceUtil.AllowCradleCheck(addDeviceUIRequest, intent));
        addDeviceUIRequest.setData(null);
        assertFalse(CartAddDeviceUtil.AllowCradleCheck(addDeviceUIRequest, intent));
	}
	
	@Test
	public void isEditDeviceOneClickFiveGFlowTest() throws JsonMappingException, JsonProcessingException {
		String request = "{  \"cartInfo\": {    \"clientAppName\": \"VZW-DOTCOM\", \"priceType\": \"VERIZON\",\"dppMonths\": \"12\", \"networkBandwidthType\": \"NSE_LTE\", \"bundleInstallType\": \"\",  \"cartId\": \"\",  \"intendType\": \"EUP_LTE\",   \"caseId\": \"\",    \"accountNumber\": \"\",    \"cartCreator\": \"2482006791\",    \"processingMTN\": \"\",\n" +
				"    \"processStep\": \"OrderNow\",    \"processAction\": \"DeviceAndPlan\",    \"intendType\": \"EUP_LTE\",    \"bundleInstallType\": \"5GHomeGeminiProfSetup\"  },  \"data\": {\n" +
				"    \"lines\": [      {        \"depletionType\": \"O\",        \"mtn\": \"2482006791\"      }    ]  }}";
		AddPlanAndDeviceUIRequest uiRequest = new AddPlanAndDeviceUIRequest();
		uiRequest = mapper.readValue(request, AddPlanAndDeviceUIRequest.class);
		String oneClickCheckout = "true";
		assertFalse(CartAddDeviceUtil.isEditDeviceOneClickFiveGFlow(uiRequest, oneClickCheckout));
	}
	
	@Test
	public void allowCradleCheckFiveGFlowTest() throws JsonMappingException, JsonProcessingException {
		String request = "{  \"cartInfo\": {    \"clientAppName\": \"VZW-DOTCOM\", \"priceType\": \"VERIZON\",\"dppMonths\": \"12\", \"networkBandwidthType\": \"NSE_LTE\", \"bundleInstallType\": \"\",  \"cartId\": \"\",  \"intendType\": \"EUP_LTE\",   \"caseId\": \"\",    \"accountNumber\": \"\",    \"cartCreator\": \"2482006791\",    \"processingMTN\": \"\",\n" +
				"    \"processStep\": \"OrderNow\",    \"processAction\": \"DeviceAndPlan\",    \"intendType\": \"EUP_LTE\",    \"bundleInstallType\": \"5GHomeGeminiProfSetup\"  },  \"data\": {\n" +
				"    \"lines\": [      {        \"depletionType\": \"O\",        \"mtn\": \"2482006791\"      }    ]  }}";
		AddPlanAndDeviceUIRequest uiRequest = new AddPlanAndDeviceUIRequest();
		uiRequest = mapper.readValue(request, AddPlanAndDeviceUIRequest.class);
		String intent = "EUP";
		assertFalse(CartAddDeviceUtil.AllowCradleCheckFiveGFlow(uiRequest, intent));
	}

	@Test
	public void populateFiveGAddress5GTest1() throws JsonMappingException, JsonProcessingException {
		String request = "{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"processStep\":\"GridWallPDP\",\"processingMTN\":\"2032530097\",\"processAction\":\"addDevice\",\"intendType\":\"NSE_5G\",\"number_share_capable\":\"Y\",\"creditAppNum\":null,\"isQuoteCart\":false,\"bogoEnabled\":\"True\"},\"data\":{\"lines\":[{\"mtn\":\"2032530097\",\"lineDeviceDollar\":0,\"upgradeReasonCode\":\"\",\"device\":{\"category\":\"\",\"deviceId\":\"\",\"id\":\"ASK-NCQ1338\",\"contractTerm\":\"MONTH_TO_MONTH\",\"dppMonths\":\"\",\"isCustomerProvidedEquipment\":false,\"networkBandwidthType\":\"LTE\"},\"sim\":{\"id\":\"DFILLSIM-TRI-A\",\"iccid\":\"\",\"isCustomerProvidedSIM\":false},\"fiveG\":{\"address\":{\"streetNumber\":\"121\",\"streetName\":\"NICHOLS\",\"streetType\":\"AVE\",\"addressLine1\":\"121 NICHOLS AVE \",\"addressLine2\":\"\",\"apartmentNo\":\"\",\"city\":\"STAMFORD\",\"state\":\"CT\",\"zipCode\":\"06905\",\"zipCode4\":\"2229\",\"firstName\":\"FORTUNE\",\"lastName\":\"NOEL\"},\"launchType\":\"4GH\"},\"addFeatures\":[{\"id\":\"66332\",\"quantity\":1,\"actionIndicator\":\"A\",\"type\":\"SFO\"}],\"isKeepingExistingEqProtection\":\"\",\"ispuFlow\":false,\"newLineOrAAL\":true,\"isNewLine\":true,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"sddZipCode\":\"\",\"preBackOrderDate\":\"\",\"triggerPricingValidation\":true}],\"selectedMtn\":\"\",\"totalDeviceDollar\":0}}";
		String address = "{\"streetNumber\": \"121\",\"streetName\": \"NICHOLS\",\"streetType\": \"AVE\",\"addressLine2\": \"\",\"apartmentNo\": \"\",\"city\": \"STAMFORD\",\"state\": \"CT\",\"zipCode\": \"06905\",\"zipCode4\": \"2229\",\"firstName\": \"FORTUNE\",\"lastName\": \"NOEL\",\"eventCorrelationId\": \"06905_1652876723434_253\",\"launchType\":\"4GH\",\"fixedWirelessRequest\":{\"latitude\":\"23\",\"longitude\":\"50\",\"vendorKey\":\"vendor\"}}";
		AddDeviceUIRequest addDeviceUIRequest = new AddDeviceUIRequest();
		FiveGAddress fiveGAddress = new FiveGAddress();
		fiveGAddress = mapper.readValue(address, FiveGAddress.class);
		addDeviceUIRequest = mapper.readValue(request, AddDeviceUIRequest.class);
		CartAddDeviceUtil.populateFiveGAddress(addDeviceUIRequest, fiveGAddress);
        Assert.assertNotNull(addDeviceUIRequest.getData().getLines().get(0).getFiveG().getAddress().getBuildingId());
	}

	@Test
	public void populateFiveGAddress5GTest2() throws JsonMappingException, JsonProcessingException {
		String request = "{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"processStep\":\"GridWallPDP\",\"processingMTN\":\"2032530097\",\"processAction\":\"addDevice\",\"intendType\":\"AAL\",\"number_share_capable\":\"Y\",\"creditAppNum\":null,\"isQuoteCart\":false,\"bogoEnabled\":\"True\"},\"data\":{\"lines\":[{\"mtn\":\"2032530097\",\"lineDeviceDollar\":0,\"upgradeReasonCode\":\"\",\"device\":{\"category\":\"\",\"deviceId\":\"\",\"id\":\"ASK-NCQ1338\",\"contractTerm\":\"MONTH_TO_MONTH\",\"dppMonths\":\"\",\"isCustomerProvidedEquipment\":false,\"networkBandwidthType\":\"LTE\"},\"sim\":{\"id\":\"DFILLSIM-TRI-A\",\"iccid\":\"\",\"isCustomerProvidedSIM\":false},\"fiveG\":{\"launchType\":\"4GH\"},\"addFeatures\":[{\"id\":\"66332\",\"quantity\":1,\"actionIndicator\":\"A\",\"type\":\"SFO\"}],\"isKeepingExistingEqProtection\":\"\",\"ispuFlow\":false,\"newLineOrAAL\":true,\"isNewLine\":true,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"sddZipCode\":\"\",\"preBackOrderDate\":\"\",\"triggerPricingValidation\":true}],\"selectedMtn\":\"\",\"totalDeviceDollar\":0}}";
		String address = "{\"streetNumber\": \"121\",\"streetName\": \"NICHOLS\",\"streetType\": \"AVE\",\"addressLine2\": \"\",\"apartmentNo\": \"\",\"city\": \"STAMFORD\",\"state\": \"CT\",\"zipCode\": \"06905\",\"zipCode4\": \"2229\",\"firstName\": \"FORTUNE\",\"lastName\": \"NOEL\",\"eventCorrelationId\": \"06905_1652876723434_253\",\"launchType\":\"4GH\",\"fixedWirelessRequest\":{\"latitude\":\"23\",\"longitude\":\"50\",\"vendorKey\":\"vendor\"}}";
		AddDeviceUIRequest addDeviceUIRequest = new AddDeviceUIRequest();
		FiveGAddress fiveGAddress = new FiveGAddress();
		fiveGAddress = mapper.readValue(address, FiveGAddress.class);
		addDeviceUIRequest = mapper.readValue(request, AddDeviceUIRequest.class);
		CartAddDeviceUtil.populateFiveGAddress(addDeviceUIRequest, fiveGAddress);
        Assert.assertNotNull(addDeviceUIRequest.getData().getLines().get(0).getFiveG().getAddress().getBuildingId());
	}

    @Test
    public void isEditDeviceOneClickTest1() throws JsonMappingException, JsonProcessingException {
        String request = "{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"editDevice\":true,\"processStep\":\"GridWallPDP\",\"processingMTN\":\"2032530097\",\"processAction\":\"addDevice\",\"intendType\":\"AAL_5G\",\"number_share_capable\":\"Y\",\"creditAppNum\":null,\"isQuoteCart\":false,\"bogoEnabled\":\"True\"},\"data\":{\"expressCheckout\":true,\"lines\":[{\"mtn\":\"2032530097\",\"lineDeviceDollar\":0,\"upgradeReasonCode\":\"\",\"device\":{\"category\":\"\",\"deviceId\":\"\",\"id\":\"ASK-NCQ1338\",\"contractTerm\":\"MONTH_TO_MONTH\",\"dppMonths\":\"\",\"isCustomerProvidedEquipment\":false,\"networkBandwidthType\":\"LTE\"},\"sim\":{\"id\":\"DFILLSIM-TRI-A\",\"iccid\":\"\",\"isCustomerProvidedSIM\":false},\"fiveG\":{\"address\":{\"streetNumber\":\"121\",\"streetName\":\"NICHOLS\",\"streetType\":\"AVE\",\"addressLine1\":\"121 NICHOLS AVE \",\"addressLine2\":\"\",\"apartmentNo\":\"\",\"city\":\"STAMFORD\",\"state\":\"CT\",\"zipCode\":\"06905\",\"zipCode4\":\"2229\",\"firstName\":\"FORTUNE\",\"lastName\":\"NOEL\",\"eventCorrelationId\":\"06905_1652876723434_253\"},\"launchType\":\"4GH\"},\"addFeatures\":[{\"id\":\"66332\",\"quantity\":1,\"actionIndicator\":\"A\",\"type\":\"SFO\"}],\"isKeepingExistingEqProtection\":\"\",\"ispuFlow\":false,\"newLineOrAAL\":true,\"isNewLine\":true,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"sddZipCode\":\"\",\"preBackOrderDate\":\"\",\"triggerPricingValidation\":true}],\"selectedMtn\":\"\",\"totalDeviceDollar\":0}}";
        AddDeviceUIRequest addDeviceUIRequest = new AddDeviceUIRequest();
        addDeviceUIRequest = mapper.readValue(request, AddDeviceUIRequest.class);
        String oneClickCheckout = "true";
        Assert.assertTrue(CartAddDeviceUtil.isEditDeviceOneClick(addDeviceUIRequest, oneClickCheckout));
    }

	@Test
	public void isEditDeviceOneClickTest2() throws JsonMappingException, JsonProcessingException {
		String request = "{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"editDevice\":true,\"processStep\":\"GridWallPDP\",\"processingMTN\":\"2032530097\",\"processAction\":\"addDevice\",\"intendType\":\"AAL_5G\",\"number_share_capable\":\"Y\",\"creditAppNum\":null,\"isQuoteCart\":false,\"bogoEnabled\":\"True\"},\"data\":{\"expressCheckout\":false,\"lines\":[{\"mtn\":\"2032530097\",\"lineDeviceDollar\":0,\"upgradeReasonCode\":\"\",\"device\":{\"category\":\"\",\"deviceId\":\"\",\"id\":\"ASK-NCQ1338\",\"contractTerm\":\"MONTH_TO_MONTH\",\"dppMonths\":\"\",\"isCustomerProvidedEquipment\":false,\"networkBandwidthType\":\"LTE\"},\"sim\":{\"id\":\"DFILLSIM-TRI-A\",\"iccid\":\"\",\"isCustomerProvidedSIM\":false},\"fiveG\":{\"address\":{\"streetNumber\":\"121\",\"streetName\":\"NICHOLS\",\"streetType\":\"AVE\",\"addressLine1\":\"121 NICHOLS AVE \",\"addressLine2\":\"\",\"apartmentNo\":\"\",\"city\":\"STAMFORD\",\"state\":\"CT\",\"zipCode\":\"06905\",\"zipCode4\":\"2229\",\"firstName\":\"FORTUNE\",\"lastName\":\"NOEL\",\"eventCorrelationId\":\"06905_1652876723434_253\"},\"launchType\":\"4GH\"},\"addFeatures\":[{\"id\":\"66332\",\"quantity\":1,\"actionIndicator\":\"A\",\"type\":\"SFO\"}],\"isKeepingExistingEqProtection\":\"\",\"ispuFlow\":false,\"newLineOrAAL\":true,\"isNewLine\":true,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"sddZipCode\":\"\",\"preBackOrderDate\":\"\",\"triggerPricingValidation\":true}],\"selectedMtn\":\"\",\"totalDeviceDollar\":0}}";
		AddDeviceUIRequest addDeviceUIRequest = new AddDeviceUIRequest();
		addDeviceUIRequest = mapper.readValue(request, AddDeviceUIRequest.class);
		String oneClickCheckout = "true";
		assertFalse(CartAddDeviceUtil.isEditDeviceOneClick(addDeviceUIRequest, oneClickCheckout));
	}

    @Test
    public void isEditDeviceOneClickTest3() throws JsonMappingException, JsonProcessingException {
        String request = "{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"editDevice\":false,\"processStep\":\"GridWallPDP\",\"processingMTN\":\"2032530097\",\"processAction\":\"addDevice\",\"intendType\":\"AAL_5G\",\"number_share_capable\":\"Y\",\"creditAppNum\":null,\"isQuoteCart\":false,\"bogoEnabled\":\"True\"},\"data\":{\"expressCheckout\":true,\"lines\":[{\"mtn\":\"2032530097\",\"lineDeviceDollar\":0,\"upgradeReasonCode\":\"\",\"device\":{\"category\":\"\",\"deviceId\":\"\",\"id\":\"ASK-NCQ1338\",\"contractTerm\":\"MONTH_TO_MONTH\",\"dppMonths\":\"\",\"isCustomerProvidedEquipment\":false,\"networkBandwidthType\":\"LTE\"},\"sim\":{\"id\":\"DFILLSIM-TRI-A\",\"iccid\":\"\",\"isCustomerProvidedSIM\":false},\"fiveG\":{\"address\":{\"streetNumber\":\"121\",\"streetName\":\"NICHOLS\",\"streetType\":\"AVE\",\"addressLine1\":\"121 NICHOLS AVE \",\"addressLine2\":\"\",\"apartmentNo\":\"\",\"city\":\"STAMFORD\",\"state\":\"CT\",\"zipCode\":\"06905\",\"zipCode4\":\"2229\",\"firstName\":\"FORTUNE\",\"lastName\":\"NOEL\",\"eventCorrelationId\":\"06905_1652876723434_253\"},\"launchType\":\"4GH\"},\"addFeatures\":[{\"id\":\"66332\",\"quantity\":1,\"actionIndicator\":\"A\",\"type\":\"SFO\"}],\"isKeepingExistingEqProtection\":\"\",\"ispuFlow\":false,\"newLineOrAAL\":true,\"isNewLine\":true,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"sddZipCode\":\"\",\"preBackOrderDate\":\"\",\"triggerPricingValidation\":true}],\"selectedMtn\":\"\",\"totalDeviceDollar\":0}}";
        AddDeviceUIRequest addDeviceUIRequest = new AddDeviceUIRequest();
        addDeviceUIRequest = mapper.readValue(request, AddDeviceUIRequest.class);
        String oneClickCheckout = "true";
        assertFalse(CartAddDeviceUtil.isEditDeviceOneClick(addDeviceUIRequest, oneClickCheckout));
    }

    @Test
    public void isEditDeviceOneClickTest4() throws JsonMappingException, JsonProcessingException {
        String request = "{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"editDevice\":true,\"processStep\":\"GridWallPDP\",\"processingMTN\":\"2032530097\",\"processAction\":\"addDevice\",\"intendType\":\"AAL_5G\",\"number_share_capable\":\"Y\",\"creditAppNum\":null,\"isQuoteCart\":false,\"bogoEnabled\":\"True\"},\"data\":{\"expressCheckout\":null,\"lines\":[{\"mtn\":\"2032530097\",\"lineDeviceDollar\":0,\"upgradeReasonCode\":\"\",\"device\":{\"category\":\"\",\"deviceId\":\"\",\"id\":\"ASK-NCQ1338\",\"contractTerm\":\"MONTH_TO_MONTH\",\"dppMonths\":\"\",\"isCustomerProvidedEquipment\":false,\"networkBandwidthType\":\"LTE\"},\"sim\":{\"id\":\"DFILLSIM-TRI-A\",\"iccid\":\"\",\"isCustomerProvidedSIM\":false},\"fiveG\":{\"address\":{\"streetNumber\":\"121\",\"streetName\":\"NICHOLS\",\"streetType\":\"AVE\",\"addressLine1\":\"121 NICHOLS AVE \",\"addressLine2\":\"\",\"apartmentNo\":\"\",\"city\":\"STAMFORD\",\"state\":\"CT\",\"zipCode\":\"06905\",\"zipCode4\":\"2229\",\"firstName\":\"FORTUNE\",\"lastName\":\"NOEL\",\"eventCorrelationId\":\"06905_1652876723434_253\"},\"launchType\":\"4GH\"},\"addFeatures\":[{\"id\":\"66332\",\"quantity\":1,\"actionIndicator\":\"A\",\"type\":\"SFO\"}],\"isKeepingExistingEqProtection\":\"\",\"ispuFlow\":false,\"newLineOrAAL\":true,\"isNewLine\":true,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"sddZipCode\":\"\",\"preBackOrderDate\":\"\",\"triggerPricingValidation\":true}],\"selectedMtn\":\"\",\"totalDeviceDollar\":0}}";
        AddDeviceUIRequest addDeviceUIRequest = new AddDeviceUIRequest();
        addDeviceUIRequest = mapper.readValue(request, AddDeviceUIRequest.class);
        String oneClickCheckout = "true";
        assertFalse(CartAddDeviceUtil.isEditDeviceOneClick(addDeviceUIRequest, oneClickCheckout));
    }

    @Test
    public void isEditDeviceOneClickTest5() throws JsonMappingException, JsonProcessingException {
        String request = "{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"editDevice\":null,\"processStep\":\"GridWallPDP\",\"processingMTN\":\"2032530097\",\"processAction\":\"addDevice\",\"intendType\":\"AAL_5G\",\"number_share_capable\":\"Y\",\"creditAppNum\":null,\"isQuoteCart\":false,\"bogoEnabled\":\"True\"},\"data\":{\"expressCheckout\":null,\"lines\":[{\"mtn\":\"2032530097\",\"lineDeviceDollar\":0,\"upgradeReasonCode\":\"\",\"device\":{\"category\":\"\",\"deviceId\":\"\",\"id\":\"ASK-NCQ1338\",\"contractTerm\":\"MONTH_TO_MONTH\",\"dppMonths\":\"\",\"isCustomerProvidedEquipment\":false,\"networkBandwidthType\":\"LTE\"},\"sim\":{\"id\":\"DFILLSIM-TRI-A\",\"iccid\":\"\",\"isCustomerProvidedSIM\":false},\"fiveG\":{\"address\":{\"streetNumber\":\"121\",\"streetName\":\"NICHOLS\",\"streetType\":\"AVE\",\"addressLine1\":\"121 NICHOLS AVE \",\"addressLine2\":\"\",\"apartmentNo\":\"\",\"city\":\"STAMFORD\",\"state\":\"CT\",\"zipCode\":\"06905\",\"zipCode4\":\"2229\",\"firstName\":\"FORTUNE\",\"lastName\":\"NOEL\",\"eventCorrelationId\":\"06905_1652876723434_253\"},\"launchType\":\"4GH\"},\"addFeatures\":[{\"id\":\"66332\",\"quantity\":1,\"actionIndicator\":\"A\",\"type\":\"SFO\"}],\"isKeepingExistingEqProtection\":\"\",\"ispuFlow\":false,\"newLineOrAAL\":true,\"isNewLine\":true,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"sddZipCode\":\"\",\"preBackOrderDate\":\"\",\"triggerPricingValidation\":true}],\"selectedMtn\":\"\",\"totalDeviceDollar\":0}}";
        AddDeviceUIRequest addDeviceUIRequest = new AddDeviceUIRequest();
        addDeviceUIRequest = mapper.readValue(request, AddDeviceUIRequest.class);
        String oneClickCheckout = "true";
        assertFalse(CartAddDeviceUtil.isEditDeviceOneClick(addDeviceUIRequest, oneClickCheckout));
    }

    @Test
    public void isEditDeviceOneClickTest6() throws JsonMappingException, JsonProcessingException {
        String request = "{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"editDevice\":true,\"processStep\":\"GridWallPDP\",\"processingMTN\":\"2032530097\",\"processAction\":\"addDevice\",\"intendType\":\"AAL_5G\",\"number_share_capable\":\"Y\",\"creditAppNum\":null,\"isQuoteCart\":false,\"bogoEnabled\":\"True\"},\"data\":{\"expressCheckout\":true,\"lines\":[{\"mtn\":\"2032530097\",\"lineDeviceDollar\":0,\"upgradeReasonCode\":\"\",\"device\":{\"category\":\"\",\"deviceId\":\"\",\"id\":\"ASK-NCQ1338\",\"contractTerm\":\"MONTH_TO_MONTH\",\"dppMonths\":\"\",\"isCustomerProvidedEquipment\":false,\"networkBandwidthType\":\"LTE\"},\"sim\":{\"id\":\"DFILLSIM-TRI-A\",\"iccid\":\"\",\"isCustomerProvidedSIM\":false},\"fiveG\":{\"address\":{\"streetNumber\":\"121\",\"streetName\":\"NICHOLS\",\"streetType\":\"AVE\",\"addressLine1\":\"121 NICHOLS AVE \",\"addressLine2\":\"\",\"apartmentNo\":\"\",\"city\":\"STAMFORD\",\"state\":\"CT\",\"zipCode\":\"06905\",\"zipCode4\":\"2229\",\"firstName\":\"FORTUNE\",\"lastName\":\"NOEL\",\"eventCorrelationId\":\"06905_1652876723434_253\"},\"launchType\":\"4GH\"},\"addFeatures\":[{\"id\":\"66332\",\"quantity\":1,\"actionIndicator\":\"A\",\"type\":\"SFO\"}],\"isKeepingExistingEqProtection\":\"\",\"ispuFlow\":false,\"newLineOrAAL\":true,\"isNewLine\":true,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"sddZipCode\":\"\",\"preBackOrderDate\":\"\",\"triggerPricingValidation\":true}],\"selectedMtn\":\"\",\"totalDeviceDollar\":0}}";
        AddDeviceUIRequest addDeviceUIRequest = new AddDeviceUIRequest();
        addDeviceUIRequest = mapper.readValue(request, AddDeviceUIRequest.class);
        String oneClickCheckout = "false";
        assertFalse(CartAddDeviceUtil.isEditDeviceOneClick(addDeviceUIRequest, oneClickCheckout));
    }

    @Test
    public void isEditDeviceOneClickTest7() throws JsonMappingException, JsonProcessingException {
        String request = "{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"editDevice\":true,\"processStep\":\"GridWallPDP\",\"processingMTN\":\"2032530097\",\"processAction\":\"addDevice\",\"intendType\":\"AAL_5G\",\"number_share_capable\":\"Y\",\"creditAppNum\":null,\"isQuoteCart\":false,\"bogoEnabled\":\"True\"},\"data\":{\"expressCheckout\":true,\"lines\":[{\"mtn\":\"2032530097\",\"lineDeviceDollar\":0,\"upgradeReasonCode\":\"\",\"device\":{\"category\":\"\",\"deviceId\":\"\",\"id\":\"ASK-NCQ1338\",\"contractTerm\":\"MONTH_TO_MONTH\",\"dppMonths\":\"\",\"isCustomerProvidedEquipment\":false,\"networkBandwidthType\":\"LTE\"},\"sim\":{\"id\":\"DFILLSIM-TRI-A\",\"iccid\":\"\",\"isCustomerProvidedSIM\":false},\"fiveG\":{\"address\":{\"streetNumber\":\"121\",\"streetName\":\"NICHOLS\",\"streetType\":\"AVE\",\"addressLine1\":\"121 NICHOLS AVE \",\"addressLine2\":\"\",\"apartmentNo\":\"\",\"city\":\"STAMFORD\",\"state\":\"CT\",\"zipCode\":\"06905\",\"zipCode4\":\"2229\",\"firstName\":\"FORTUNE\",\"lastName\":\"NOEL\",\"eventCorrelationId\":\"06905_1652876723434_253\"},\"launchType\":\"4GH\"},\"addFeatures\":[{\"id\":\"66332\",\"quantity\":1,\"actionIndicator\":\"A\",\"type\":\"SFO\"}],\"isKeepingExistingEqProtection\":\"\",\"ispuFlow\":false,\"newLineOrAAL\":true,\"isNewLine\":true,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"sddZipCode\":\"\",\"preBackOrderDate\":\"\",\"triggerPricingValidation\":true}],\"selectedMtn\":\"\",\"totalDeviceDollar\":0}}";
        AddDeviceUIRequest addDeviceUIRequest = new AddDeviceUIRequest();
        addDeviceUIRequest = mapper.readValue(request, AddDeviceUIRequest.class);
        String oneClickCheckout = "";
        assertFalse(CartAddDeviceUtil.isEditDeviceOneClick(addDeviceUIRequest, oneClickCheckout));
    }

    @Test
    public void allowCradleCheckTest1() throws JsonMappingException, JsonProcessingException {
        String request = "{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"processStep\":\"GridWallPDP\",\"processingMTN\":\"2032530097\",\"processAction\":\"addDevice\",\"intendType\":\"AAL_5G\",\"number_share_capable\":\"Y\",\"creditAppNum\":null,\"isQuoteCart\":false,\"bogoEnabled\":\"True\",\"editDevice\":false},\"data\":{\"expressCheckout\":false,\"lines\":[{\"mtn\":\"2032530097\",\"lineDeviceDollar\":0,\"upgradeReasonCode\":\"\",\"sim\":{\"id\":\"DFILLSIM-TRI-A\",\"iccid\":\"\",\"isCustomerProvidedSIM\":false},\"fiveG\":{\"address\":{\"streetNumber\":\"121\",\"streetName\":\"NICHOLS\",\"streetType\":\"AVE\",\"addressLine1\":\"121 NICHOLS AVE \",\"addressLine2\":\"\",\"apartmentNo\":\"\",\"city\":\"STAMFORD\",\"state\":\"CT\",\"zipCode\":\"06905\",\"zipCode4\":\"2229\",\"firstName\":\"FORTUNE\",\"lastName\":\"NOEL\",\"eventCorrelationId\":\"06905_1652876723434_253\"},\"launchType\":\"4GH\"},\"addFeatures\":[{\"id\":\"66332\",\"quantity\":1,\"actionIndicator\":\"A\",\"type\":\"SFO\"}],\"isKeepingExistingEqProtection\":\"\",\"ispuFlow\":false,\"newLineOrAAL\":true,\"isNewLine\":true,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"sddZipCode\":\"\",\"preBackOrderDate\":\"\",\"triggerPricingValidation\":true}],\"selectedMtn\":\"\",\"totalDeviceDollar\":0}}";
        AddDeviceUIRequest addDeviceUIRequest = new AddDeviceUIRequest();
        addDeviceUIRequest = mapper.readValue(request, AddDeviceUIRequest.class);
        String intent = "upgrade";
        assertFalse(CartAddDeviceUtil.AllowCradleCheck(addDeviceUIRequest, intent));
    }

     @Test
    public void allowCradleCheckTest2() throws JsonMappingException, JsonProcessingException {
         String request = "{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"processStep\":\"GridWallPDP\",\"processingMTN\":\"2032530097\",\"processAction\":\"addDevice\",\"intendType\":\"AAL_5G\",\"number_share_capable\":\"Y\",\"creditAppNum\":null,\"isQuoteCart\":false,\"bogoEnabled\":\"True\",\"editDevice\":false},\"data\":{\"expressCheckout\":true,\"lines\":[{\"mtn\":\"2032530097\",\"lineDeviceDollar\":0,\"upgradeReasonCode\":\"\",\"sim\":{\"id\":\"DFILLSIM-TRI-A\",\"iccid\":\"\",\"isCustomerProvidedSIM\":false},\"fiveG\":{\"address\":{\"streetNumber\":\"121\",\"streetName\":\"NICHOLS\",\"streetType\":\"AVE\",\"addressLine1\":\"121 NICHOLS AVE \",\"addressLine2\":\"\",\"apartmentNo\":\"\",\"city\":\"STAMFORD\",\"state\":\"CT\",\"zipCode\":\"06905\",\"zipCode4\":\"2229\",\"firstName\":\"FORTUNE\",\"lastName\":\"NOEL\",\"eventCorrelationId\":\"06905_1652876723434_253\"},\"launchType\":\"4GH\"},\"addFeatures\":[{\"id\":\"66332\",\"quantity\":1,\"actionIndicator\":\"A\",\"type\":\"SFO\"}],\"isKeepingExistingEqProtection\":\"\",\"ispuFlow\":false,\"newLineOrAAL\":true,\"isNewLine\":true,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"sddZipCode\":\"\",\"preBackOrderDate\":\"\",\"triggerPricingValidation\":true}],\"selectedMtn\":\"\",\"totalDeviceDollar\":0}}";
        AddDeviceUIRequest addDeviceUIRequest = new AddDeviceUIRequest();
        addDeviceUIRequest = mapper.readValue(request, AddDeviceUIRequest.class);
        String intent = "upgrade";
        assertFalse(CartAddDeviceUtil.AllowCradleCheck(addDeviceUIRequest, intent));
    }

    @Test
    public void allowCradleCheckTest3() throws JsonMappingException, JsonProcessingException {
        String request = "{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"processStep\":\"GridWallPDP\",\"processingMTN\":\"2032530097\",\"processAction\":\"addDevice\",\"intendType\":\"AAL_5G\",\"number_share_capable\":\"Y\",\"creditAppNum\":null,\"isQuoteCart\":false,\"bogoEnabled\":\"True\",\"editDevice\":false},\"data\":{\"expressCheckout\":false,\"selectedMtn\":\"\",\"totalDeviceDollar\":0}}";
        AddDeviceUIRequest addDeviceUIRequest = new AddDeviceUIRequest();
        addDeviceUIRequest = mapper.readValue(request, AddDeviceUIRequest.class);
        String intent = "upgrade";
        assertFalse(CartAddDeviceUtil.AllowCradleCheck(addDeviceUIRequest, intent));
    }

    @Test
    public void allowCradleCheckTest4() throws JsonMappingException, JsonProcessingException {
        String request = "{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"processStep\":\"GridWallPDP\",\"processingMTN\":\"2032530097\",\"processAction\":\"addDevice\",\"intendType\":\"AAL_5G\",\"number_share_capable\":\"Y\",\"creditAppNum\":null,\"isQuoteCart\":false,\"bogoEnabled\":\"True\",\"editDevice\":true},\"data\":{\"expressCheckout\":false,\"selectedMtn\":\"\",\"totalDeviceDollar\":0}}";
        AddDeviceUIRequest addDeviceUIRequest = new AddDeviceUIRequest();
        addDeviceUIRequest = mapper.readValue(request, AddDeviceUIRequest.class);
        String intent = "upgrade";
        assertFalse(CartAddDeviceUtil.AllowCradleCheck(addDeviceUIRequest, intent));
    }

    @Test
    public void allowCradleCheckTest5() throws JsonMappingException, JsonProcessingException {
        String request = "{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"processStep\":\"GridWallPDP\",\"processingMTN\":\"2032530097\",\"processAction\":\"addDevice\",\"intendType\":\"AAL_5G\",\"number_share_capable\":\"Y\",\"creditAppNum\":null,\"isQuoteCart\":false,\"bogoEnabled\":\"True\",\"editDevice\":true},\"data\":{\"expressCheckout\":false,\"selectedMtn\":\"\",\"totalDeviceDollar\":0}}";
        AddDeviceUIRequest addDeviceUIRequest = new AddDeviceUIRequest();
        addDeviceUIRequest = mapper.readValue(request, AddDeviceUIRequest.class);
        String intent = null;
        assertFalse(CartAddDeviceUtil.AllowCradleCheck(addDeviceUIRequest, intent));
    }

    @Test
    public void logE911AddressTest() throws JsonMappingException, JsonProcessingException {
        String logMsg = "{\"address\":{\"streetNumber\": \"121\",\"streetName\": \"NICHOLS\",\"streetType\": \"AVE\",\"addressLine2\": \"\",\"apartmentNo\": \"\",\"city\": \"STAMFORD\",\"state\": \"CT\",\"zipCode\": \"06905\",\"zipCode4\": \"2229\",\"firstName\": \"FORTUNE\",\"lastName\": \"NOEL\",\"eventCorrelationId\": \"06905_1652876723434_253\",\"launchType\":\"4GH\",\"fixedWirelessRequest\":{\"latitude\":\"23\",\"longitude\":\"50\",\"vendorKey\":\"vendor\"}}}";
        ServiceAddress serviceAddress = mapper.readValue(logMsg, ServiceAddress.class);
        CartAddDeviceUtil.logE911Address(serviceAddress);
        serviceAddress.setAddress(null);
        CartAddDeviceUtil.logE911Address(serviceAddress);
    }

    @Test
    public void isEditDeviceOneClickFiveGFlowTest1() throws JsonMappingException, JsonProcessingException {
        String request = "{  \"cartInfo\": {  \"editDevice\":true,  \"clientAppName\": \"VZW-DOTCOM\", \"priceType\": \"VERIZON\",\"dppMonths\": \"12\", \"networkBandwidthType\": \"NSE_LTE\", \"bundleInstallType\": \"\",  \"cartId\": \"\",  \"intendType\": \"EUP_LTE\",   \"caseId\": \"\",    \"accountNumber\": \"\",    \"cartCreator\": \"2482006791\",    \"processingMTN\": \"\",\n" +
                "    \"processStep\": \"OrderNow\",    \"processAction\": \"DeviceAndPlan\",    \"intendType\": \"EUP_LTE\",    \"bundleInstallType\": \"5GHomeGeminiProfSetup\"  },  \"data\": {\n" +
                "    \"expressCheckout\":true,		\"lines\": [      {        \"depletionType\": \"O\",        \"mtn\": \"2482006791\"      }    ]  }}";
        AddPlanAndDeviceUIRequest uiRequest = new AddPlanAndDeviceUIRequest();
        uiRequest = mapper.readValue(request, AddPlanAndDeviceUIRequest.class);
        String oneClickCheckout = "true";
        Assert.assertTrue(CartAddDeviceUtil.isEditDeviceOneClickFiveGFlow(uiRequest, oneClickCheckout));
    }

    @Test
    public void isEditDeviceOneClickFiveGFlowTest2() throws JsonMappingException, JsonProcessingException {
        String request = "{  \"cartInfo\": {  \"editDevice\":true,  \"clientAppName\": \"VZW-DOTCOM\", \"priceType\": \"VERIZON\",\"dppMonths\": \"12\", \"networkBandwidthType\": \"NSE_LTE\", \"bundleInstallType\": \"\",  \"cartId\": \"\",  \"intendType\": \"EUP_LTE\",   \"caseId\": \"\",    \"accountNumber\": \"\",    \"cartCreator\": \"2482006791\",    \"processingMTN\": \"\",\n" +
                "    \"processStep\": \"OrderNow\",    \"processAction\": \"DeviceAndPlan\",    \"intendType\": \"EUP_LTE\",    \"bundleInstallType\": \"5GHomeGeminiProfSetup\"  },  \"data\": {\n" +
                "    \"expressCheckout\":false,		\"lines\": [      {        \"depletionType\": \"O\",        \"mtn\": \"2482006791\"      }    ]  }}";
        AddPlanAndDeviceUIRequest uiRequest = new AddPlanAndDeviceUIRequest();
        uiRequest = mapper.readValue(request, AddPlanAndDeviceUIRequest.class);
        String oneClickCheckout = "true";
        assertFalse(CartAddDeviceUtil.isEditDeviceOneClickFiveGFlow(uiRequest, oneClickCheckout));
    }

    @Test
    public void isEditDeviceOneClickFiveGFlowTest3() throws JsonMappingException, JsonProcessingException {
        String request = "{  \"cartInfo\": {  \"editDevice\":true,  \"clientAppName\": \"VZW-DOTCOM\", \"priceType\": \"VERIZON\",\"dppMonths\": \"12\", \"networkBandwidthType\": \"NSE_LTE\", \"bundleInstallType\": \"\",  \"cartId\": \"\",  \"intendType\": \"EUP_LTE\",   \"caseId\": \"\",    \"accountNumber\": \"\",    \"cartCreator\": \"2482006791\",    \"processingMTN\": \"\",\n" +
                "    \"processStep\": \"OrderNow\",    \"processAction\": \"DeviceAndPlan\",    \"intendType\": \"EUP_LTE\",    \"bundleInstallType\": \"5GHomeGeminiProfSetup\"  },  \"data\": {\n" +
                "    \"lines\": [      {        \"depletionType\": \"O\",        \"mtn\": \"2482006791\"      }    ]  }}";
        AddPlanAndDeviceUIRequest uiRequest = new AddPlanAndDeviceUIRequest();
        uiRequest = mapper.readValue(request, AddPlanAndDeviceUIRequest.class);
        String oneClickCheckout = "true";
        assertFalse(CartAddDeviceUtil.isEditDeviceOneClickFiveGFlow(uiRequest, oneClickCheckout));
    }

    @Test
    public void isEditDeviceOneClickFiveGFlowTest4() throws JsonMappingException, JsonProcessingException {
        String request = "{  \"cartInfo\": {  \"editDevice\":false,  \"clientAppName\": \"VZW-DOTCOM\", \"priceType\": \"VERIZON\",\"dppMonths\": \"12\", \"networkBandwidthType\": \"NSE_LTE\", \"bundleInstallType\": \"\",  \"cartId\": \"\",  \"intendType\": \"EUP_LTE\",   \"caseId\": \"\",    \"accountNumber\": \"\",    \"cartCreator\": \"2482006791\",    \"processingMTN\": \"\",\n" +
                "    \"processStep\": \"OrderNow\",    \"processAction\": \"DeviceAndPlan\",    \"intendType\": \"EUP_LTE\",    \"bundleInstallType\": \"5GHomeGeminiProfSetup\"  },  \"data\": {\n" +
                "    \"lines\": [      {        \"depletionType\": \"O\",        \"mtn\": \"2482006791\"      }    ]  }}";
        AddPlanAndDeviceUIRequest uiRequest = new AddPlanAndDeviceUIRequest();
        uiRequest = mapper.readValue(request, AddPlanAndDeviceUIRequest.class);
        String oneClickCheckout = "true";
        assertFalse(CartAddDeviceUtil.isEditDeviceOneClickFiveGFlow(uiRequest, oneClickCheckout));
    }

    @Test
    public void isEditDeviceOneClickFiveGFlowTest5() throws JsonMappingException, JsonProcessingException {
        String request = "{  \"cartInfo\": {  \"editDevice\":false,  \"clientAppName\": \"VZW-DOTCOM\", \"priceType\": \"VERIZON\",\"dppMonths\": \"12\", \"networkBandwidthType\": \"NSE_LTE\", \"bundleInstallType\": \"\",  \"cartId\": \"\",  \"intendType\": \"EUP_LTE\",   \"caseId\": \"\",    \"accountNumber\": \"\",    \"cartCreator\": \"2482006791\",    \"processingMTN\": \"\",\n" +
                "    \"processStep\": \"OrderNow\",    \"processAction\": \"DeviceAndPlan\",    \"intendType\": \"EUP_LTE\",    \"bundleInstallType\": \"5GHomeGeminiProfSetup\"  },  \"data\": {\n" +
                "    \"lines\": [      {        \"depletionType\": \"O\",        \"mtn\": \"2482006791\"      }    ]  }}";
        AddPlanAndDeviceUIRequest uiRequest = new AddPlanAndDeviceUIRequest();
        uiRequest = mapper.readValue(request, AddPlanAndDeviceUIRequest.class);
        String oneClickCheckout = "false";
        assertFalse(CartAddDeviceUtil.isEditDeviceOneClickFiveGFlow(uiRequest, oneClickCheckout));
    }

    @Test
    public void isEditDeviceOneClickFiveGFlowTest6() throws JsonMappingException, JsonProcessingException {
        String request = "{  \"cartInfo\": {  \"editDevice\":false,  \"clientAppName\": \"VZW-DOTCOM\", \"priceType\": \"VERIZON\",\"dppMonths\": \"12\", \"networkBandwidthType\": \"NSE_LTE\", \"bundleInstallType\": \"\",  \"cartId\": \"\",  \"intendType\": \"EUP_LTE\",   \"caseId\": \"\",    \"accountNumber\": \"\",    \"cartCreator\": \"2482006791\",    \"processingMTN\": \"\",\n" +
                "    \"processStep\": \"OrderNow\",    \"processAction\": \"DeviceAndPlan\",    \"intendType\": \"EUP_LTE\",    \"bundleInstallType\": \"5GHomeGeminiProfSetup\"  },  \"data\": {\n" +
                "    \"lines\": [      {        \"depletionType\": \"O\",        \"mtn\": \"2482006791\"      }    ]  }}";
        AddPlanAndDeviceUIRequest uiRequest = new AddPlanAndDeviceUIRequest();
        uiRequest = mapper.readValue(request, AddPlanAndDeviceUIRequest.class);
        String oneClickCheckout = "";
        assertFalse(CartAddDeviceUtil.isEditDeviceOneClickFiveGFlow(uiRequest, oneClickCheckout));
    }

    @Test
    public void allowCradleCheckFiveGFlowTest1() throws JsonMappingException, JsonProcessingException {
        String request = "{  \"cartInfo\": {    \"editDevice\":false,	\"clientAppName\": \"VZW-DOTCOM\", \"priceType\": \"VERIZON\",\"dppMonths\": \"12\", \"networkBandwidthType\": \"NSE_LTE\", \"bundleInstallType\": \"\",  \"cartId\": \"\",  \"intendType\": \"EUP_LTE\",   \"caseId\": \"\",    \"accountNumber\": \"\",    \"cartCreator\": \"2482006791\",    \"processingMTN\": \"2482006791\",\n" +
                "    \"processStep\": \"OrderNow\",    \"processAction\": \"DeviceAndPlan\",    \"intendType\": \"EUP_LTE\",    \"bundleInstallType\": \"5GHomeGeminiProfSetup\"  },  \"data\": {\n" +
                "    \"expressCheckout\":false,		\"lines\": [      {        \"device\": {\"category\":\"HOME\"},		\"depletionType\": \"O\",        \"mtn\": \"2482006791\"      }    ]  }}";
        AddPlanAndDeviceUIRequest uiRequest = new AddPlanAndDeviceUIRequest();
        uiRequest = mapper.readValue(request, AddPlanAndDeviceUIRequest.class);
        String intent = "upgrade";
        Assert.assertTrue(CartAddDeviceUtil.AllowCradleCheckFiveGFlow(uiRequest, intent));

        uiRequest.getCartInfo().setProcessingMTN("random");
        uiRequest.getData().getLines().get(0).getDevice().setCategory("random");
        uiRequest.getCartInfo().setEditDevice(true);
        assertFalse(CartAddDeviceUtil.AllowCradleCheckFiveGFlow(uiRequest, intent));
        uiRequest.getCartInfo().setEditDevice(false);
        uiRequest.getData().setExpressCheckout(true);
        assertFalse(CartAddDeviceUtil.AllowCradleCheckFiveGFlow(uiRequest, intent));
        uiRequest.getData().setExpressCheckout(false);
        uiRequest.getData().setLines(null);
        assertFalse(CartAddDeviceUtil.AllowCradleCheckFiveGFlow(uiRequest, intent));
//        uiRequest.setData(null);
//        Assert.assertFalse(CartAddDeviceUtil.AllowCradleCheckFiveGFlow(uiRequest, intent));
    }

     @Test
    public void allowCradleCheckFiveGFlowTest2() throws JsonMappingException, JsonProcessingException {
         String request = "{  \"cartInfo\": {    \"editDevice\":false,	\"clientAppName\": \"VZW-DOTCOM\", \"priceType\": \"VERIZON\",\"dppMonths\": \"12\", \"networkBandwidthType\": \"NSE_LTE\", \"bundleInstallType\": \"\",  \"cartId\": \"\",  \"intendType\": \"EUP_LTE\",   \"caseId\": \"\",    \"accountNumber\": \"\",    \"cartCreator\": \"2482006791\",    \"processingMTN\": \"2482006791\",\n" +
                 "    \"processStep\": \"OrderNow\",    \"processAction\": \"DeviceAndPlan\",    \"intendType\": \"EUP_LTE\",    \"bundleInstallType\": \"5GHomeGeminiProfSetup\"  },  \"data\": {\n" +
                 "    \"expressCheckout\":true,		\"lines\": [      {        \"device\": {},		\"depletionType\": \"O\",        \"mtn\": \"2482006791\"      }    ]  }}";
         AddPlanAndDeviceUIRequest uiRequest = new AddPlanAndDeviceUIRequest();
        uiRequest = mapper.readValue(request, AddPlanAndDeviceUIRequest.class);
        String intent = "AAL";
        assertFalse(CartAddDeviceUtil.AllowCradleCheckFiveGFlow(uiRequest, intent));
    }

    @Test
    public void allowCradleCheckFiveGFlowTest3() throws JsonMappingException, JsonProcessingException {
        String request = "{  \"cartInfo\": {    \"editDevice\":false,	\"clientAppName\": \"VZW-DOTCOM\", \"priceType\": \"VERIZON\",\"dppMonths\": \"12\", \"networkBandwidthType\": \"NSE_LTE\", \"bundleInstallType\": \"\",  \"cartId\": \"\",  \"intendType\": \"EUP_LTE\",   \"caseId\": \"\",    \"accountNumber\": \"\",    \"cartCreator\": \"2482006791\",    \"processingMTN\": \"2482006791\",\n" +
                "    \"processStep\": \"OrderNow\",    \"processAction\": \"DeviceAndPlan\",    \"intendType\": \"EUP_LTE\",    \"bundleInstallType\": \"5GHomeGeminiProfSetup\"  },  \"data\": {\n" +
                "    \"expressCheckout\":false,		\"lines\": [      {        \"device\": {},		\"depletionType\": \"O\",        \"mtn\": \"2482006791\"      }    ]  }}";
        AddPlanAndDeviceUIRequest uiRequest = new AddPlanAndDeviceUIRequest();
        uiRequest = mapper.readValue(request, AddPlanAndDeviceUIRequest.class);
        String intent = "AAL";
        assertFalse(CartAddDeviceUtil.AllowCradleCheckFiveGFlow(uiRequest, intent));
    }

    @Test
    public void allowCradleCheckFiveGFlowTest4() throws JsonMappingException, JsonProcessingException {
        String request = "{  \"cartInfo\": {    \"editDevice\":false,	\"clientAppName\": \"VZW-DOTCOM\", \"priceType\": \"VERIZON\",\"dppMonths\": \"12\", \"networkBandwidthType\": \"NSE_LTE\", \"bundleInstallType\": \"\",  \"cartId\": \"\",  \"intendType\": \"EUP_LTE\",   \"caseId\": \"\",    \"accountNumber\": \"\",    \"cartCreator\": \"2482006791\",    \"processingMTN\": \"2482006791\",\n" +
                "    \"processStep\": \"OrderNow\",    \"processAction\": \"DeviceAndPlan\",    \"intendType\": \"EUP_LTE\",    \"bundleInstallType\": \"5GHomeGeminiProfSetup\"  },  \"data\": {\n" +
                "    \"expressCheckout\":false  }}";
        AddPlanAndDeviceUIRequest uiRequest = new AddPlanAndDeviceUIRequest();
        uiRequest = mapper.readValue(request, AddPlanAndDeviceUIRequest.class);
        String intent = "AAL";
        assertFalse(CartAddDeviceUtil.AllowCradleCheckFiveGFlow(uiRequest, intent));
    }

    @Test
    public void allowCradleCheckFiveGFlowTest5() throws JsonMappingException, JsonProcessingException {
        String request = "{  \"cartInfo\": {    \"editDevice\":true,	\"clientAppName\": \"VZW-DOTCOM\", \"priceType\": \"VERIZON\",\"dppMonths\": \"12\", \"networkBandwidthType\": \"NSE_LTE\", \"bundleInstallType\": \"\",  \"cartId\": \"\",  \"intendType\": \"EUP_LTE\",   \"caseId\": \"\",    \"accountNumber\": \"\",    \"cartCreator\": \"2482006791\",    \"processingMTN\": \"2482006791\",\n" +
                "    \"processStep\": \"OrderNow\",    \"processAction\": \"DeviceAndPlan\",    \"intendType\": \"EUP_LTE\",    \"bundleInstallType\": \"5GHomeGeminiProfSetup\"  },  \"data\": {\n" +
                "     }}";
        AddPlanAndDeviceUIRequest uiRequest = new AddPlanAndDeviceUIRequest();
        uiRequest = mapper.readValue(request, AddPlanAndDeviceUIRequest.class);
        String intent = "AAL";
        assertFalse(CartAddDeviceUtil.AllowCradleCheckFiveGFlow(uiRequest, intent));
    }

    @Test
    public void allowCradleCheckFiveGFlowTest6() throws JsonMappingException, JsonProcessingException {
        String request = "{  \"cartInfo\": {  	\"clientAppName\": \"VZW-DOTCOM\", \"priceType\": \"VERIZON\",\"dppMonths\": \"12\", \"networkBandwidthType\": \"NSE_LTE\", \"bundleInstallType\": \"\",  \"cartId\": \"\",  \"intendType\": \"EUP_LTE\",   \"caseId\": \"\",    \"accountNumber\": \"\",    \"cartCreator\": \"2482006791\",    \"processingMTN\": \"2482006791\",\n" +
                "    \"processStep\": \"OrderNow\",    \"processAction\": \"DeviceAndPlan\",    \"intendType\": \"EUP_LTE\",    \"bundleInstallType\": \"5GHomeGeminiProfSetup\"  },  \"data\": {\n" +
                "     }}";
        AddPlanAndDeviceUIRequest uiRequest = new AddPlanAndDeviceUIRequest();
        uiRequest = mapper.readValue(request, AddPlanAndDeviceUIRequest.class);
        String intent = "AAL";
        assertFalse(CartAddDeviceUtil.AllowCradleCheckFiveGFlow(uiRequest, intent));
    }

    @Test
    public void allowCradleCheckFiveGFlowTest7() throws JsonMappingException, JsonProcessingException {
        String request = "{  \"cartInfo\": {  	\"clientAppName\": \"VZW-DOTCOM\", \"priceType\": \"VERIZON\",\"dppMonths\": \"12\", \"networkBandwidthType\": \"NSE_LTE\", \"bundleInstallType\": \"\",  \"cartId\": \"\",  \"intendType\": \"EUP_LTE\",   \"caseId\": \"\",    \"accountNumber\": \"\",    \"cartCreator\": \"2482006791\",    \"processingMTN\": \"2482006791\",\n" +
                "    \"processStep\": \"OrderNow\",    \"processAction\": \"DeviceAndPlan\",    \"intendType\": \"EUP_LTE\",    \"bundleInstallType\": \"5GHomeGeminiProfSetup\"  },  \"data\": {\n" +
                "     }}";
        AddPlanAndDeviceUIRequest uiRequest = new AddPlanAndDeviceUIRequest();
        uiRequest = mapper.readValue(request, AddPlanAndDeviceUIRequest.class);
        String intent = null;
        assertFalse(CartAddDeviceUtil.AllowCradleCheckFiveGFlow(uiRequest, intent));
    }

    @Test
    public void logE911Address5GFlowTest() throws JsonMappingException, JsonProcessingException {
        String logMsg = "{\"address\":{\"streetNumber\": \"121\",\"streetName\": \"NICHOLS\",\"streetType\": \"AVE\",\"addressLine2\": \"\",\"apartmentNo\": \"\",\"city\": \"STAMFORD\",\"state\": \"CT\",\"zipCode\": \"06905\",\"zipCode4\": \"2229\",\"firstName\": \"FORTUNE\",\"lastName\": \"NOEL\",\"eventCorrelationId\": \"06905_1652876723434_253\",\"launchType\":\"4GH\",\"fixedWirelessRequest\":{\"latitude\":\"23\",\"longitude\":\"50\",\"vendorKey\":\"vendor\"}}}";
        E911Address serviceAddress = mapper.readValue(logMsg, E911Address.class);
        CartAddDeviceUtil.logE911Address5GFlow(serviceAddress);
        CartAddDeviceUtil.logE911Address5GFlow(null);
    }

    @Test
    public void populateFiveGAddressFiveGHomeFlowTest1() throws JsonProcessingException {
        AddPlanAndDeviceUIRequest addPlanAndDeviceUIRequest=new AddPlanAndDeviceUIRequest();
        FiveGLTEAddressRedis fiveGLTEAddressRedis=new FiveGLTEAddressRedis();
        String requestString="{  \"cartInfo\": {	\"crmResumeCartFlow\":\"true\",    \"clientAppName\": \"VZW-DOTCOM\", \"networkBandwidthType\": \"NSE_5G\", \"bundleInstallType\": \"NSE_5G\",  \"cartId\": \"\",  \"intendType\": \"NSE_5G\",   \"caseId\": \"\",    \"accountNumber\": \"\",    \"cartCreator\": \"2482006791\",    \"processingMTN\": \"\",\n" +
                "    \"processStep\": \"OrderNow\",    \"processAction\": \"DeviceAndPlan\",    \"intendType\": \"EUP_5G_REPAIR\",    \"bundleInstallType\": \"5GHomeGeminiProfSetup\"  },  \"data\": {\n" +
                "    \"lines\": [      {        \"depletionType\": \"O\",        \"mtn\": \"2482006791\"      }    ]  }}";
        addPlanAndDeviceUIRequest = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
        FiveGLTEAddressRedis address = new FiveGLTEAddressRedis();
        address.setLaunchType("HCL");
        address.setIsD2DFlow("false");
        List<BundleDetails> bundleList=new ArrayList<>();
        BundleDetails bundleDetails=new BundleDetails();
        bundleDetails.setId("Bundle");
        bundleDetails.setBundleName("5GHomeGeminiProfSetup");
        bundleList.add(bundleDetails);
        address.setBundleList(bundleList);
        CartRedisData data=new CartRedisData();
        CartAddDeviceUtil.populateFiveGAddressFiveGHomeFlow(addPlanAndDeviceUIRequest,address, data);
        Assert.assertNotNull(addPlanAndDeviceUIRequest.getData().getLines().get(0).getDevice());
        addPlanAndDeviceUIRequest.getData().setLines(Collections.emptyList());
        CartAddDeviceUtil.populateFiveGAddressFiveGHomeFlow(addPlanAndDeviceUIRequest,address, data);
        addPlanAndDeviceUIRequest.setData(null);
        CartAddDeviceUtil.populateFiveGAddressFiveGHomeFlow(addPlanAndDeviceUIRequest,address, data);
    }

    @Test
    public void populateFiveGAddressFiveGHomeFlowTest2() throws JsonProcessingException {
        AddPlanAndDeviceUIRequest addPlanAndDeviceUIRequest=new AddPlanAndDeviceUIRequest();
        FiveGLTEAddressRedis fiveGLTEAddressRedis=new FiveGLTEAddressRedis();
        String requestString="{  \"cartInfo\": {    \"transactionType\":\"LTE_TO_CBD_UPGRADE\",    \"clientAppName\": \"VZW-DOTCOM\", \"priceType\": \"VERIZON_EDGE\",\"dppMonths\": \"12\", \"networkBandwidthType\": \"LTE\",  \"cartId\": \"\",  \"intendType\": \"EUP_LTE\",   \"caseId\": \"\",    \"accountNumber\": \"\",    \"cartCreator\": \"2482006791\",    \"processingMTN\": \"\",\n" +
                "    \"processStep\": \"Accessories\",    \"processAction\": \"DeviceAndPlan\",    \"intendType\": \"EUP_LTE\",    \"bundleInstallType\": \"5GHomeGeminiProfSetup\"  },  \"data\": {\n" +
                "    \"lines\": [      {        \"depletionType\": \"O\",        \"mtn\": \"2482006791\"      }    ]  }}";
        addPlanAndDeviceUIRequest = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
        FiveGLTEAddressRedis address = new FiveGLTEAddressRedis();
        address.setLTEHomeQualified("true");
        address.setLTEHomeSku("123");
        List<BundleDetails> bundleList=new ArrayList<>();
        BundleDetails bundleDetails=new BundleDetails();
        bundleDetails.setId("Bundle");
        bundleDetails.setBundleName("5GHomeGeminiProfSetup");
        bundleList.add(bundleDetails);
        address.setBundleList(bundleList);
        CartRedisData data=new CartRedisData();
        CartAddDeviceUtil.populateFiveGAddressFiveGHomeFlow(addPlanAndDeviceUIRequest,address, data);
        Assert.assertNotNull(addPlanAndDeviceUIRequest.getData().getLines().get(0).getDevice());
    }

    @Test
    public void allowCradleCheckTest6() throws JsonMappingException, JsonProcessingException {
        String request = "{\"cartInfo\": {\"editDevice\": false,\"clientAppName\": \"VZW-DOTCOM\",\"priceType\": \"VERIZON\",\"dppMonths\": \"12\",\"networkBandwidthType\": \"NSE_LTE\",\"bundleInstallType\": \"\",\"cartId\": \"\",\"intendType\": \"EUP_LTE\",\"caseId\": \"\",\"accountNumber\": \"\",\"cartCreator\": \"2482006791\",\"processingMTN\": \"\",\"processStep\": \"OrderNow\",\"processAction\": \"DeviceAndPlan\",\"intendType\": \"EUP_LTE\",\"bundleInstallType\": \"5GHomeGeminiProfSetup\"},\"data\": {\"expressCheckout\": true,\"lines\": [{\"device\": {},\"depletionType\": \"O\",\"mtn\": \"2482006791\"}]}}";
        AddPlanAndDeviceUIRequest uiRequest = new AddPlanAndDeviceUIRequest();
        uiRequest = mapper.readValue(request, AddPlanAndDeviceUIRequest.class);
        String intent = "AAL";
        assertFalse(CartAddDeviceUtil.AllowCradleCheckFiveGFlow(uiRequest, intent));
    }

    @Test
    public void allowCradleCheckTest7() throws JsonMappingException, JsonProcessingException {
        String request = "{\"cartInfo\": {\"editDevice\": false,\"clientAppName\": \"VZW-DOTCOM\",\"priceType\": \"VERIZON\",\"dppMonths\": \"12\",\"networkBandwidthType\": \"NSE_LTE\",\"bundleInstallType\": \"\",\"cartId\": \"\",\"intendType\": \"EUP_LTE\",\"caseId\": \"\",\"accountNumber\": \"\",\"cartCreator\": \"2482006791\",\"processingMTN\": \"23456\",\"processStep\": \"OrderNow\",\"processAction\": \"DeviceAndPlan\",\"intendType\": \"EUP_LTE\",\"bundleInstallType\": \"5GHomeGeminiProfSetup\"},\"data\": {\"expressCheckout\": true,\"lines\": [{\"device\": {},\"depletionType\": \"O\",\"mtn\": \"2482006791\"}]}}";
        AddPlanAndDeviceUIRequest uiRequest = new AddPlanAndDeviceUIRequest();
        uiRequest = mapper.readValue(request, AddPlanAndDeviceUIRequest.class);
        String intent = "BYOD";
        assertFalse(CartAddDeviceUtil.AllowCradleCheckFiveGFlow(uiRequest, intent));
    }
    @Test
    public void populateFiveGAddressFiveGHomeFlowTest3() throws JsonProcessingException {
        AddPlanAndDeviceUIRequest addPlanAndDeviceUIRequest=new AddPlanAndDeviceUIRequest();
        FiveGLTEAddressRedis fiveGLTEAddressRedis=new FiveGLTEAddressRedis();
        String requestString="{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"intendType\":\"NSE_5G\",\"bundleInstallType\":\"5GHomeCBandSelfSetup\",\"enableResume\":\"false\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
        addPlanAndDeviceUIRequest = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
        FiveGLTEAddressRedis address = new FiveGLTEAddressRedis();
        address.setLaunchType("FCL");
        List<BundleDetails> bundleList=new ArrayList<>();
        BundleDetails bundleDetails=new BundleDetails();
        bundleDetails.setId("Bundle");
        bundleDetails.setBundleName("5GHomeGeminiProfSetup");
        bundleList.add(bundleDetails);
        address.setBundleList(bundleList);
        CartRedisData data=new CartRedisData();
        data.setLvSoftSku("LOCNOTE");
        CartAddDeviceUtil.populateFiveGAddressFiveGHomeFlow(addPlanAndDeviceUIRequest,address, data);
        Assert.assertNotNull(addPlanAndDeviceUIRequest.getData().getLines().get(0).getAccessories());
    }
    @Test
    public void checkAndUpdateNetworkBdTypeTest () throws JsonProcessingException {

        String deviceRequestString ="{ \"cartInfo\": { \"clientAppName\": \"VZW-NETACE\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"cartId\": \"\", \"caseId\": \"\", \"accountNumber\": \"\", \"cartCreator\": \"400936722\", \"processingMTN\": \"newLine1\", \"processStep\": \"GridWallPDP\", \"processAction\": \"addDevice\", \"intendType\": \"NSE_5G\", \"creditAppNum\": \"400936722\" }, \"data\": { \"lines\": [ { \"depletionType\": \"O\", \"depletionLocationCode\": \"\", \"ispuFlow\": false, \"isNewLine\": false, \"mtn\": \"7576136076\", \"device\": { \"id\": \"22600001\", \"contractTerm\": \"MONTH_TO_MONTH\" }, \"sim\": { \"id\": \"NI-DPSIM5G\" }, \"fiveG\": {} } ] } }";
        AddDeviceUIRequest request = mapper.readValue(deviceRequestString, AddDeviceUIRequest.class);

        String retrieveCartString = "{ \"cart\": { \"customerProfile\": { \"billAccounts\": [ { \"mtns\": [ { \"mtn\": \"7572158943\", \"equipmentUpgradeEligibility\": { \"upgradeEligibilityDate\": \"03/28/2027\", \"upgradeEligible\": true, \"twoYearContract\": {} }, \"mobileInfoAttributes\": { \"smartFamilyParent\": false }, \"equipmentInfos\": [ { \"deviceInfo\": { \"modelName\": \"Samsung Galaxy S23 FE 128GB in Graphite\", \"deviceId\": \"351139212627823\", \"deviceIdType\": \"IME\", \"deviceSku\": \"SMS711UZAV\" }, \"simInfo\": { \"modelName\": \"5G STANDALONE SIM BY THALES\", \"simId\": \"89148000009897946036\", \"simSku\": \"EMBDSIM5GSA\" } } ], \"lineSharingIndicator\": \"\", \"pricePlanInfo\": { \"planId\": \"63217\", \"planAttributes\": { \"sharePlan\": false } } }, { \"mtn\": \"7575367905\", \"equipmentUpgradeEligibility\": { \"upgradeEligibilityDate\": \"02/11/2023\", \"upgradeEligible\": false, \"twoYearContract\": {} }, \"mobileInfoAttributes\": { \"smartFamilyParent\": false }, \"equipmentInfos\": [ { \"deviceInfo\": { \"modelName\": \"Verizon Internet Gateway WNC-CR200A\", \"deviceId\": \"357473870966213\", \"deviceIdType\": \"IME\", \"deviceSku\": \"WNC-CR200A\" }, \"simInfo\": { \"modelName\": \"THALES 5G SIM MULTIPLE PROFILES\", \"simId\": \"89148000009539336950\", \"simSku\": \"NI-DPSIM5G\" } } ], \"lineSharingIndicator\": \"\", \"pricePlanInfo\": { \"planId\": \"50127\", \"planAttributes\": { \"sharePlan\": false } } } ], \"fiosEligibilityCategory\": \"\", \"accountAddress\": { \"zipCode\": \"23523\", \"zipCodePlus4\": \"1301\", \"fipsCode\": \"5171057000\", \"addressLine1\": \"330 HARBOR POINTE CT APT 408\", \"addressLine2\": \"\", \"city\": \"NORFOLK\", \"state\": \"VA\", \"scrubbedAddress\": { \"streetName\": \"HARBOR POINTE\", \"streetNumber\": \"330\", \"streetType\": \"CT\", \"streetDirection\": \"\", \"apartmentNo\": \"408\", \"pobox\": \"\", \"ruralDeliveryNo\": \"\", \"ruralRouteNo\": \"\", \"city\": \"NORFOLK\", \"state\": \"VA\", \"country\": \"\", \"zipCode\": \"23523\", \"zipCodePlus4\": \"2249\" } }, \"accountAttributes\": { \"autopay\": { \"autoPayDiscount\": \"20.00\" } } } ], \"customerAttributes\": { \"taxExemptCode\": \"N\", \"digitalCustomerType\": \"B2C\" } }, \"cartHasOnlyAccessories\": false, \"cartHasConflicts\": false, \"conflictsAccepted\": false, \"cartHeader\": { \"winBackAccountNumber\": \"\", \"vendorId\": \"NETACE\", \"ani\": 7572158943, \"repRole\": \"POSSYSTST\", \"locationType\": \"S\", \"sourceSystem\": \"OMNI-RETAIL\", \"fullAccountNumber\": \"0726602987-1\", \"status\": \"A\", \"createTimestamp\": \"2024-07-22T10:56:24.48-04:00[US/Eastern]\", \"lastUpdateTimestamp\": \"2024-07-22T10:57:46.14-04:00[US/Eastern]\", \"cartCreator\": \"7572158943\", \"cartCreatorChannelId\": \"OMNI-RETAIL\", \"cartCreatorOrderLocationCode\": \"P332201\", \"cartCreatorSalesRepId\": \"ENC\", \"visionCustomerType\": \"PE\", \"maverickLocation\": false, \"isCoreRep\": false, \"isERTRep\": false }, \"orderDetails\": { \"totalUpgradeFee\": 0.0, \"totalDeviceDollar\": 0.0, \"totalRemainingDeviceDollar\": 0.0, \"totalUsedDeviceDollar\": 0.0, \"totalAccountLevelAccCost\": 0.0, \"totalAccountLevelAccCostWithTax\": 0.0, \"totalShippingCost\": 0.0, \"totalDiscountedShippingCost\": 0.0, \"hqUser\": false, \"returnException\": false, \"taxDetailsList\": [], \"subTotalDueTodayWithoutUpgradeFee\": 0.0, \"subTotalDueMonthlyForAALBYODEUP\": 0.0, \"shipTogetherPref\": true, \"assistanceOptedByCustomer\": false, \"locationState\": \"NC\", \"totalVerizonDollarUsed\": \"0.0\", \"isShellAccountSelected\": false, \"fullfillmentLocation\": \"1000050\", \"guestOrInactiveRefundLines\": false, \"totalDueMonthlyOnProfile\": 0.0, \"subTotalDueMonthlyOnProfile\": 0.0, \"totalMonthlyTaxesOnProfile\": 0.0, \"subTotalOtherLinesOnProfile\": 0.0, \"estimatedNextMonthChargeOnProfile\": 0.0, \"originalSubTotalDueMonthly\": 0.0, \"totalDueMonthlyAfterDiscounts\": 0.0, \"totalTaxAdjustmentAmount\": 0.0, \"totalActivationFees\": 0.0, \"fiveGHomeOrder\": false, \"totalRefundAmount\": 0.0, \"totalExchangeAmount\": 0.0, \"totalRefundTaxAmount\": 0.0, \"totalExchangeTaxAmount\": 0.0, \"digitalExchange\": false, \"remainingAmountAfterAffirmApplied\": 0.0, \"cashOptionEnabled\": false, \"affirmCreditCheckFailed\": false, \"orderType\": \"PS\", \"locationCode\": \"P332201\", \"customerType\": \"U\", \"billingSystem\": \"VE\", \"totalTaxAmount\": \"0.0\", \"spocs\": { \"notificationOptions\": { \"contactPhoneNumber\": \"4541854933\", \"primaryEmailId\": \"TVLITVTIZEVH68252@VZW.COM\" } }, \"totalDueToday\": 0.0, \"runningTotalDueToday\": 0.0, \"totalDueTodayFlag\": false, \"totalDueMonthly\": 0.0, \"subTotalDueMonthly\": 0.0, \"subTotalDueToday\": 0.0, \"subTotalMonthlyTaxes\": 0.0, \"estimatedNextMonthCharge\": 0.0, \"totalMonthlyTaxes\": 0.0, \"subTotalOtherLines\": 0.0, \"subTotalOtherLinesTaxes\": 0.0, \"instantDRCCredit\": false, \"isAttachmentCompleted\": false, \"nextMonthBillTotal\": 0.0, \"customerNotification\": { \"smsLanguage\": \"E\" }, \"orderChannelId\": \"OMNI-RETAIL\", \"orderList\": [ { \"creditApplication\": { \"creditApplicationNum\": 402936739, \"creditApprovalStatus\": \"AP\", \"creditStatusReason\": \"CA Customer Systematic Approval\", \"internationalEligibility\": true, \"securityDepositAmount\": \"0\", \"serviceClass\": \"B\", \"lineCreditClass\": \"1D\", \"creditAppEdited\": false }, \"orderActivityType\": \"EUP\", \"orderNumber\": 0, \"numOfLinesForOrderActivityType\": 0, \"preOrderNumber\": 0, \"digitalOrderId\": 0, \"managerApprovalRequired\": false }, { \"creditApplication\": { \"creditApplicationNum\": 403936739, \"creditApprovalStatus\": \"AP\", \"creditStatusReason\": \"CA Customer Systematic Approval\", \"internationalEligibility\": true, \"securityDepositAmount\": \"0\", \"lineCreditClass\": \"1D\", \"creditAppEdited\": false }, \"orderActivityType\": \"AAL_5G\", \"orderNumber\": 0, \"numOfLinesForOrderActivityType\": 0, \"preOrderNumber\": 0, \"digitalOrderId\": 0, \"managerApprovalRequired\": false } ], \"outletId\": \"000098021\", \"registerNumber\": \"51\", \"saleType\": \"P\", \"salesRepId\": \"ENC\", \"enableSplitShipment\": false, \"splitShipmentIndicator\": false, \"isSingleModConnectedDevice\": false, \"fiveGUpSellAccountLevel\": false, \"customerOnTrialPlan\": false, \"totalDownPaymentAmt\": 0.0, \"totalEdgeBuyOutAmount\": 0.0, \"expressCheckout\": false, \"isEQPandPPLOfferApplied\": false, \"cartTotalDiscounts\": { \"totalDiscount\": \"0.0\", \"barCodeOfferAppliedOnOrder\": false, \"discountDetails\": [] }, \"memberTotalDueToday\": 0.0, \"customerConsent\": \"Y\", \"totalDwosCost\": \"0.0\", \"billingState\": \"VA\", \"isTradeInOfferSelected\": false, \"isAssignMtnRequired\": false, \"fiosCapable\": false, \"fiosEligible\": false, \"quoteWithoutCredit\": false, \"uswinAuthenticationRequired\": false, \"newPreToPostInfo\": { \"newPreToPostIndicator\": \"E\", \"newPreToPostMtns\": { \"accountOwner\": \"\", \"accountMembers\": [] } }, \"totalDueTodayWithoutDiscount\": 0.0, \"subTotalDueTodayWithoutDiscount\": 0.0, \"totalPerksSavings\": \"0.0\" }, \"lineDetails\": { \"lineInfo\": [ { \"isCommonPDP\": false, \"isTradeInIntentSelected\": false, \"multiLineSeqNumber\": 1, \"lineActivityType\": \"AAL_5G\", \"totalDueToday\": 0.0, \"totalDueTodayWithoutTax\": 0.0, \"totalDueTodayWithoutTaxWithoutDiscount\": 0.0, \"totalDueMonthly\": 0.0, \"mobileNumber\": \"7576136076\", \"showGlobalChoiceOffer\": false, \"serviceInfo\": { \"serviceAddress\": { \"addressLine1\": \"330 HARBOR POINTE CT APT 408\", \"addressLine2\": \"\", \"zipCode\": \"23523\", \"zipCode4\": \"2249\", \"firstName\": \"DON\", \"lastName\": \"MANNING\", \"city\": \"NORFOLK\", \"state\": \"VA\" }, \"comparePlan\": false, \"primaryUserInfo\": { \"firstName\": \"DON\", \"lastName\": \"MANNING\", \"address\": { \"firmName\": \"\", \"apartmentNo\": \"408\", \"type\": \"CT\", \"streetNumber\": \"330\", \"streetName\": \"HARBOR POINTE\", \"addressLine2\": \"\", \"addressLine1\": \"330 HARBOR POINTE CT APT 408\", \"poBoxNo\": \"\", \"ruralRouteNo\": \"\", \"ruralDelNo\": \"\", \"city\": \"NORFOLK\", \"state\": \"VA\", \"zipCode\": \"23523\", \"zipCode4\": \"2249\", \"county\": \"\", \"countryCode\": \"US\", \"fipsCode\": \"5171057000\", \"firstName\": \"DON\", \"lastName\": \"MANNING\", \"emailId\": \"TVLITVTIZEVH68252@VZW.COM\", \"phoneNumber\": \"4541854933\", \"streetType\": \"CT\", \"streetDirection\": \"\" }, \"isValidAddress\": true, \"bsnsName\": \"\", \"emailId\": \"TVLITVTIZEVH68252@VZW.COM\", \"midInitials\": \"E\" }, \"mtn\": \"7576136076\", \"min\": \"5754367277\", \"isSharePlanAdded\": false, \"mea\": \"VNO\", \"isE911AddressValidated\": false, \"kidsPlanParentMtn\": false, \"mcsSubscription\": [], \"fiveGUpSell\": false, \"e911AddressSameAsServiceAddress\": false, \"unpairedGrantor\": false, \"totalAddedFeaturesPrice\": \"0.0\" }, \"itemsInfo\": [ { \"attention\": \"DON MANNING\", \"shipping\": { \"address\": { \"firmName\": \"\", \"apartmentNo\": \"408\", \"type\": \"R\", \"streetNumber\": \"330\", \"streetName\": \"HARBOR POINTE\", \"addressLine2\": \"\", \"addressLine1\": \"330 HARBOR POINTE CT APT 408\", \"poBoxNo\": \"\", \"ruralRouteNo\": \"\", \"ruralDelNo\": \"\", \"city\": \"NORFOLK\", \"state\": \"VA\", \"zipCode\": \"23523\", \"zipCode4\": \"2249\", \"county\": \"\", \"countryCode\": \"\", \"fipsCode\": \"5171057000\", \"firstName\": \"DON\", \"lastName\": \"MANNING\", \"emailId\": \"TVLITVTIZEVH68252@VZW.COM\", \"phoneNumber\": \"4541854933\", \"streetType\": \"CT\", \"streetDirection\": \"\" }, \"bsnsName\": \"\", \"cbrPhone\": \"4541854933\", \"firstName\": \"DON\", \"lastName\": \"MANNING\", \"midInitials\": \"E\", \"isUseUnVerifiedAddress\": false, \"isValidAddress\": false, \"email\": \"TVLITVTIZEVH68252@VZW.COM\", \"shipToCustomerAddress\": false }, \"fipsCode\": \"5171057000\", \"itemCount\": 0, \"itemTabSeqNum\": 0, \"isPromoSelected\": false, \"isTradeInSelected\": false } ], \"assignMTNIndicator\": \"Y\", \"mtnDetails\": { \"dummyMTNForDomain\": \"7215894301\", \"lineNumber\": \"newLine1\", \"minNumber\": \"5754367277\", \"mobileNumber\": \"7576136076\", \"assignMTNTimestamp\": \"2024-07-22T10:57:46.143777944-04:00[US/Eastern]\", \"npaNXX\": \"757613\" }, \"lineNumber\": \"newLine1\", \"fiveGToFourGDownGrade\": false, \"deviceTypeSelected\": \"5G Internet\", \"lineCreator\": \"7572158943\", \"lineRefundTotal\": 0.0, \"lineExchangeTotal\": 0.0, \"totalDueMonthlyBeforeCredit\": 0.0, \"sugAllowed\": false, \"totalDueAddOnMonthly\": 0.0, \"totalPriceOfPlanAndPerks\": \"0.0\", \"isCpe\": false, \"isLTEHomeLine\": false, \"isDevicePlanCompatible\": false, \"portinMtnAssignment\": false, \"impactedLine\": false, \"preOrBackOrder\": false, \"ispuItem\": false, \"ispuItemBYOD\": false, \"isModConnected\": false, \"modDevice\": false, \"byodCapable\": false, \"isCarLine\": false, \"buySimOnly\": false, \"broadBandInd\": false, \"ispuDownPaymentAdjstRequired\": false, \"ispuDownPaymentAmount\": 0.0, \"lineWithSkipMDN\": false, \"protectionNotRequired\": false } ], \"numOfAccessoryAndDeviceItemsInCart\": 0, \"totalEdgeUpAmount\": 0.0, \"totalEdgeBuyOutAmount\": 0.0, \"tradeInDetail\": {}, \"totalDownPaymentAmt\": 0.0, \"numOfLinesWithDevices\": 0, \"numofApprovedLines\": 0, \"rfexPayments\": [], \"numOfLines\": 1, \"numofLinesAAL\": 1, \"numofLinesEUP\": 0, \"payments\": [], \"lineSeq\": 0, \"vlcactivePhoneCount\": 0, \"fivegOrderind\": false, \"aceOrderCreated\": false, \"serviceLinesCreated\": false, \"aceItemsModified\": false, \"clnrOrderFlag\": false, \"broadbandInd\": false, \"acctMcsSubscription\": [], \"spendingLimitAmountExceededBy\": \"0.0\", \"numofAccessories\": 0, \"subAccountNBSInfo\": [], \"subAccountNbsDetails\": [], \"bagTax\": false, \"couponDetails\": [ {} ] }, \"refundOrderDetails\": { \"orderNum\": 0, \"totalDueToday\": \"0.0\", \"subTotalDueToday\": \"0.0\", \"totalTaxAmount\": \"0.0\", \"creditApplicationNum\": 0 }, \"accountEligibility\": false, \"displayCartValidationErrors\": true }, \"warningMessages\": [], \"basicORSmartPhoneExists\": false, \"fiveGDeviceORLTEHomeExists\": false, \"cartHasAccessories\": false, \"iscartHasVZHP\": false, \"orderPlaced\": false, \"validateAppointments\": false, \"validateCart\": false, \"redesignFlow\": false, \"newCustomer\": false, \"isLocalStoreOfferEnabled\": false }";
        CXPRetrieveCartDataVO cart = mapper.readValue(retrieveCartString, CXPRetrieveCartDataVO.class);

        CartRedisData data = new CartRedisData();
        data.setRepRole("CSSCREP");
        data.setRetrieveCart(cart);

        FiveGAddressRedisData address = new FiveGAddressRedisData();
        address.setAddressRequest(new FiveGAddress());
        address.getAddressRequest().setFiveGHomeQualified(true);

        CartAddDeviceUtil.checkAndUpdateNetworkBdType(data, request,address);

        address.getAddressRequest().setCBandQualified(true);
        address.getAddressRequest().setFiveGHomeQualified(false);
        request.getData().getLines().get(0).getDevice().setNetworkBandwidthType("");
        CartAddDeviceUtil.checkAndUpdateNetworkBdType(data, request,address);

        address.getAddressRequest().setLTEQualified(true);
        address.getAddressRequest().setCBandQualified(false);
        address.getAddressRequest().setFiveGHomeQualified(false);
        request.getData().getLines().get(0).getDevice().setNetworkBandwidthType("");
        CartAddDeviceUtil.checkAndUpdateNetworkBdType(data, request,address);
        request.getCartInfo().setIntendType("NSE_LTE");
        request.getData().getLines().get(0).getDevice().setNetworkBandwidthType("");
        CartAddDeviceUtil.checkAndUpdateNetworkBdType(data, request,address);

        request.getCartInfo().setIntendType("AAL_LTE");
        request.getData().getLines().get(0).getDevice().setNetworkBandwidthType("");
        CartAddDeviceUtil.checkAndUpdateNetworkBdType(data, request,address);

        request.getData().getLines().get(0).getDevice().setNetworkBandwidthType("");
        data.setIsHomeSales("true");
        address.getAddressRequest().setLTEQualified(false);
        data.setHomeSalesAddress(new HomeSalesAddress());
        data.getHomeSalesAddress().setCBandQualified(true);
        CartAddDeviceUtil.checkAndUpdateNetworkBdType(data, request,address);

        data.getHomeSalesAddress().setCBandQualified(false);
        data.getHomeSalesAddress().setFiveGHomeQualified(true);
        request.getData().getLines().get(0).getDevice().setNetworkBandwidthType("");
        CartAddDeviceUtil.checkAndUpdateNetworkBdType(data, request,address);

        data.getHomeSalesAddress().setCBandQualified(false);
        data.getHomeSalesAddress().setFiveGHomeQualified(true);
        request.getData().getLines().get(0).getDevice().setNetworkBandwidthType("");
        CartAddDeviceUtil.checkAndUpdateNetworkBdType(data, request,address);


        request.getCartInfo().setIntendType("AAL_5G");
        CartAddDeviceUtil.checkAndUpdateFiveGNBT(request, address, true, false);

        CartAddDeviceUtil.checkAndUpdateFiveGNBT(request, address, false, true);

        data.getHomeSalesAddress().setCBandQualified(true);
        data.getHomeSalesAddress().setFiveGHomeQualified(false);
        CartAddDeviceUtil.checkAndUpdateFiveGNBT(request, address, false, true);
        CartAddDeviceUtil.checkAndUpdateFiveGNBT(request, address, false, true);

        CXPLineInfo line = new CXPLineInfo();
        line.setLineActivityType("AAL");
        line.setDeviceTypeSelected("");
        CartAddDeviceUtil.isFiveGLine(line);

        line.setLineActivityType("AAL");
        line.setDeviceTypeSelected(CartConstants.FIVE_G_INTERNET);
        CartAddDeviceUtil.isFiveGLine(line);

        line.setLineActivityType("AAL_5G");
        line.setDeviceTypeSelected(CartConstants.FIVE_G_INTERNET);
        CartAddDeviceUtil.isFiveGLine(line);

        CartAddDeviceUtil.isDeviceType5G(request, data);

        request.getData().getLines().get(0).setMtn("newLine2");
        CartAddDeviceUtil.isDeviceType5G(request, data);

        retrieveCartString = "{ \"cart\": { \"customerProfile\": { \"billAccounts\": [ { \"mtns\": [ { \"mtn\": \"7572158943\", \"equipmentUpgradeEligibility\": { \"upgradeEligibilityDate\": \"03/28/2027\", \"upgradeEligible\": true, \"twoYearContract\": {} }, \"mobileInfoAttributes\": { \"smartFamilyParent\": false }, \"equipmentInfos\": [ { \"deviceInfo\": { \"modelName\": \"Samsung Galaxy S23 FE 128GB in Graphite\", \"deviceId\": \"351139212627823\", \"deviceIdType\": \"IME\", \"deviceSku\": \"SMS711UZAV\" }, \"simInfo\": { \"modelName\": \"5G STANDALONE SIM BY THALES\", \"simId\": \"89148000009897946036\", \"simSku\": \"EMBDSIM5GSA\" } } ], \"lineSharingIndicator\": \"\", \"pricePlanInfo\": { \"planId\": \"63217\", \"planAttributes\": { \"sharePlan\": false } } }, { \"mtn\": \"7575367905\", \"equipmentUpgradeEligibility\": { \"upgradeEligibilityDate\": \"02/11/2023\", \"upgradeEligible\": false, \"twoYearContract\": {} }, \"mobileInfoAttributes\": { \"smartFamilyParent\": false }, \"equipmentInfos\": [ { \"deviceInfo\": { \"modelName\": \"Verizon Internet Gateway WNC-CR200A\", \"deviceId\": \"357473870966213\", \"deviceIdType\": \"IME\", \"deviceSku\": \"WNC-CR200A\" }, \"simInfo\": { \"modelName\": \"THALES 5G SIM MULTIPLE PROFILES\", \"simId\": \"89148000009539336950\", \"simSku\": \"NI-DPSIM5G\" } } ], \"lineSharingIndicator\": \"\", \"pricePlanInfo\": { \"planId\": \"50127\", \"planAttributes\": { \"sharePlan\": false } } } ], \"fiosEligibilityCategory\": \"\", \"accountAddress\": { \"zipCode\": \"23523\", \"zipCodePlus4\": \"1301\", \"fipsCode\": \"5171057000\", \"addressLine1\": \"330 HARBOR POINTE CT APT 408\", \"addressLine2\": \"\", \"city\": \"NORFOLK\", \"state\": \"VA\", \"scrubbedAddress\": { \"streetName\": \"HARBOR POINTE\", \"streetNumber\": \"330\", \"streetType\": \"CT\", \"streetDirection\": \"\", \"apartmentNo\": \"408\", \"pobox\": \"\", \"ruralDeliveryNo\": \"\", \"ruralRouteNo\": \"\", \"city\": \"NORFOLK\", \"state\": \"VA\", \"country\": \"\", \"zipCode\": \"23523\", \"zipCodePlus4\": \"2249\" } }, \"accountAttributes\": { \"autopay\": { \"autoPayDiscount\": \"20.00\" } } } ], \"customerAttributes\": { \"taxExemptCode\": \"N\", \"digitalCustomerType\": \"B2C\" } }, \"cartHasOnlyAccessories\": false, \"cartHasConflicts\": false, \"conflictsAccepted\": false, \"cartHeader\": { \"winBackAccountNumber\": \"\", \"vendorId\": \"NETACE\", \"ani\": 7572158943, \"repRole\": \"POSSYSTST\", \"locationType\": \"S\", \"sourceSystem\": \"OMNI-RETAIL\", \"fullAccountNumber\": \"0726602987-1\", \"status\": \"A\", \"createTimestamp\": \"2024-07-22T10:56:24.48-04:00[US/Eastern]\", \"lastUpdateTimestamp\": \"2024-07-22T10:57:46.14-04:00[US/Eastern]\", \"cartCreator\": \"7572158943\", \"cartCreatorChannelId\": \"OMNI-RETAIL\", \"cartCreatorOrderLocationCode\": \"P332201\", \"cartCreatorSalesRepId\": \"ENC\", \"visionCustomerType\": \"PE\", \"maverickLocation\": false, \"isCoreRep\": false, \"isERTRep\": false }, \"orderDetails\": { \"totalUpgradeFee\": 0.0, \"totalDeviceDollar\": 0.0, \"totalRemainingDeviceDollar\": 0.0, \"totalUsedDeviceDollar\": 0.0, \"totalAccountLevelAccCost\": 0.0, \"totalAccountLevelAccCostWithTax\": 0.0, \"totalShippingCost\": 0.0, \"totalDiscountedShippingCost\": 0.0, \"hqUser\": false, \"returnException\": false, \"taxDetailsList\": [], \"subTotalDueTodayWithoutUpgradeFee\": 0.0, \"subTotalDueMonthlyForAALBYODEUP\": 0.0, \"shipTogetherPref\": true, \"assistanceOptedByCustomer\": false, \"locationState\": \"NC\", \"totalVerizonDollarUsed\": \"0.0\", \"isShellAccountSelected\": false, \"fullfillmentLocation\": \"1000050\", \"guestOrInactiveRefundLines\": false, \"totalDueMonthlyOnProfile\": 0.0, \"subTotalDueMonthlyOnProfile\": 0.0, \"totalMonthlyTaxesOnProfile\": 0.0, \"subTotalOtherLinesOnProfile\": 0.0, \"estimatedNextMonthChargeOnProfile\": 0.0, \"originalSubTotalDueMonthly\": 0.0, \"totalDueMonthlyAfterDiscounts\": 0.0, \"totalTaxAdjustmentAmount\": 0.0, \"totalActivationFees\": 0.0, \"fiveGHomeOrder\": false, \"totalRefundAmount\": 0.0, \"totalExchangeAmount\": 0.0, \"totalRefundTaxAmount\": 0.0, \"totalExchangeTaxAmount\": 0.0, \"digitalExchange\": false, \"remainingAmountAfterAffirmApplied\": 0.0, \"cashOptionEnabled\": false, \"affirmCreditCheckFailed\": false, \"orderType\": \"PS\", \"locationCode\": \"P332201\", \"customerType\": \"U\", \"billingSystem\": \"VE\", \"totalTaxAmount\": \"0.0\", \"spocs\": { \"notificationOptions\": { \"contactPhoneNumber\": \"4541854933\", \"primaryEmailId\": \"TVLITVTIZEVH68252@VZW.COM\" } }, \"totalDueToday\": 0.0, \"runningTotalDueToday\": 0.0, \"totalDueTodayFlag\": false, \"totalDueMonthly\": 0.0, \"subTotalDueMonthly\": 0.0, \"subTotalDueToday\": 0.0, \"subTotalMonthlyTaxes\": 0.0, \"estimatedNextMonthCharge\": 0.0, \"totalMonthlyTaxes\": 0.0, \"subTotalOtherLines\": 0.0, \"subTotalOtherLinesTaxes\": 0.0, \"instantDRCCredit\": false, \"isAttachmentCompleted\": false, \"nextMonthBillTotal\": 0.0, \"customerNotification\": { \"smsLanguage\": \"E\" }, \"orderChannelId\": \"OMNI-RETAIL\", \"orderList\": [ { \"creditApplication\": { \"creditApplicationNum\": 402936739, \"creditApprovalStatus\": \"AP\", \"creditStatusReason\": \"CA Customer Systematic Approval\", \"internationalEligibility\": true, \"securityDepositAmount\": \"0\", \"serviceClass\": \"B\", \"lineCreditClass\": \"1D\", \"creditAppEdited\": false }, \"orderActivityType\": \"EUP\", \"orderNumber\": 0, \"numOfLinesForOrderActivityType\": 0, \"preOrderNumber\": 0, \"digitalOrderId\": 0, \"managerApprovalRequired\": false }, { \"creditApplication\": { \"creditApplicationNum\": 403936739, \"creditApprovalStatus\": \"AP\", \"creditStatusReason\": \"CA Customer Systematic Approval\", \"internationalEligibility\": true, \"securityDepositAmount\": \"0\", \"lineCreditClass\": \"1D\", \"creditAppEdited\": false }, \"orderActivityType\": \"AAL_5G\", \"orderNumber\": 0, \"numOfLinesForOrderActivityType\": 0, \"preOrderNumber\": 0, \"digitalOrderId\": 0, \"managerApprovalRequired\": false } ], \"outletId\": \"000098021\", \"registerNumber\": \"51\", \"saleType\": \"P\", \"salesRepId\": \"ENC\", \"enableSplitShipment\": false, \"splitShipmentIndicator\": false, \"isSingleModConnectedDevice\": false, \"fiveGUpSellAccountLevel\": false, \"customerOnTrialPlan\": false, \"totalDownPaymentAmt\": 0.0, \"totalEdgeBuyOutAmount\": 0.0, \"expressCheckout\": false, \"isEQPandPPLOfferApplied\": false, \"cartTotalDiscounts\": { \"totalDiscount\": \"0.0\", \"barCodeOfferAppliedOnOrder\": false, \"discountDetails\": [] }, \"memberTotalDueToday\": 0.0, \"customerConsent\": \"Y\", \"totalDwosCost\": \"0.0\", \"billingState\": \"VA\", \"isTradeInOfferSelected\": false, \"isAssignMtnRequired\": false, \"fiosCapable\": false, \"fiosEligible\": false, \"quoteWithoutCredit\": false, \"uswinAuthenticationRequired\": false, \"newPreToPostInfo\": { \"newPreToPostIndicator\": \"E\", \"newPreToPostMtns\": { \"accountOwner\": \"\", \"accountMembers\": [] } }, \"totalDueTodayWithoutDiscount\": 0.0, \"subTotalDueTodayWithoutDiscount\": 0.0, \"totalPerksSavings\": \"0.0\" }, \"lineDetails\": { \"lineInfo\": [ { \"isCommonPDP\": false, \"isTradeInIntentSelected\": false, \"multiLineSeqNumber\": 1, \"lineActivityType\": \"AAL_5G\", \"totalDueToday\": 0.0, \"totalDueTodayWithoutTax\": 0.0, \"totalDueTodayWithoutTaxWithoutDiscount\": 0.0, \"totalDueMonthly\": 0.0, \"mobileNumber\": \"7576136076\", \"showGlobalChoiceOffer\": false, \"serviceInfo\": { \"serviceAddress\": { \"addressLine1\": \"330 HARBOR POINTE CT APT 408\", \"addressLine2\": \"\", \"zipCode\": \"23523\", \"zipCode4\": \"2249\", \"firstName\": \"DON\", \"lastName\": \"MANNING\", \"city\": \"NORFOLK\", \"state\": \"VA\" }, \"comparePlan\": false, \"primaryUserInfo\": { \"firstName\": \"DON\", \"lastName\": \"MANNING\", \"address\": { \"firmName\": \"\", \"apartmentNo\": \"408\", \"type\": \"CT\", \"streetNumber\": \"330\", \"streetName\": \"HARBOR POINTE\", \"addressLine2\": \"\", \"addressLine1\": \"330 HARBOR POINTE CT APT 408\", \"poBoxNo\": \"\", \"ruralRouteNo\": \"\", \"ruralDelNo\": \"\", \"city\": \"NORFOLK\", \"state\": \"VA\", \"zipCode\": \"23523\", \"zipCode4\": \"2249\", \"county\": \"\", \"countryCode\": \"US\", \"fipsCode\": \"5171057000\", \"firstName\": \"DON\", \"lastName\": \"MANNING\", \"emailId\": \"TVLITVTIZEVH68252@VZW.COM\", \"phoneNumber\": \"4541854933\", \"streetType\": \"CT\", \"streetDirection\": \"\" }, \"isValidAddress\": true, \"bsnsName\": \"\", \"emailId\": \"TVLITVTIZEVH68252@VZW.COM\", \"midInitials\": \"E\" }, \"mtn\": \"7576136076\", \"min\": \"5754367277\", \"isSharePlanAdded\": false, \"mea\": \"VNO\", \"isE911AddressValidated\": false, \"kidsPlanParentMtn\": false, \"mcsSubscription\": [], \"fiveGUpSell\": false, \"e911AddressSameAsServiceAddress\": false, \"unpairedGrantor\": false, \"totalAddedFeaturesPrice\": \"0.0\" }, \"itemsInfo\": [ { \"attention\": \"DON MANNING\", \"shipping\": { \"address\": { \"firmName\": \"\", \"apartmentNo\": \"408\", \"type\": \"R\", \"streetNumber\": \"330\", \"streetName\": \"HARBOR POINTE\", \"addressLine2\": \"\", \"addressLine1\": \"330 HARBOR POINTE CT APT 408\", \"poBoxNo\": \"\", \"ruralRouteNo\": \"\", \"ruralDelNo\": \"\", \"city\": \"NORFOLK\", \"state\": \"VA\", \"zipCode\": \"23523\", \"zipCode4\": \"2249\", \"county\": \"\", \"countryCode\": \"\", \"fipsCode\": \"5171057000\", \"firstName\": \"DON\", \"lastName\": \"MANNING\", \"emailId\": \"TVLITVTIZEVH68252@VZW.COM\", \"phoneNumber\": \"4541854933\", \"streetType\": \"CT\", \"streetDirection\": \"\" }, \"bsnsName\": \"\", \"cbrPhone\": \"4541854933\", \"firstName\": \"DON\", \"lastName\": \"MANNING\", \"midInitials\": \"E\", \"isUseUnVerifiedAddress\": false, \"isValidAddress\": false, \"email\": \"TVLITVTIZEVH68252@VZW.COM\", \"shipToCustomerAddress\": false }, \"fipsCode\": \"5171057000\", \"itemCount\": 0, \"itemTabSeqNum\": 0, \"isPromoSelected\": false, \"isTradeInSelected\": false } ], \"assignMTNIndicator\": \"Y\", \"mtnDetails\": { \"dummyMTNForDomain\": \"7215894301\", \"lineNumber\": \"newLine1\", \"minNumber\": \"5754367277\", \"mobileNumber\": \"7576136076\", \"assignMTNTimestamp\": \"2024-07-22T10:57:46.143777944-04:00[US/Eastern]\", \"npaNXX\": \"757613\" }, \"lineNumber\": \"newLine1\", \"fiveGToFourGDownGrade\": false, \"deviceTypeSelected\": \"5G Internet\", \"lineCreator\": \"7572158943\", \"lineRefundTotal\": 0.0, \"lineExchangeTotal\": 0.0, \"totalDueMonthlyBeforeCredit\": 0.0, \"sugAllowed\": false, \"totalDueAddOnMonthly\": 0.0, \"totalPriceOfPlanAndPerks\": \"0.0\", \"isCpe\": false, \"isLTEHomeLine\": false, \"isDevicePlanCompatible\": false, \"portinMtnAssignment\": false, \"impactedLine\": false, \"preOrBackOrder\": false, \"ispuItem\": false, \"ispuItemBYOD\": false, \"isModConnected\": false, \"modDevice\": false, \"byodCapable\": false, \"isCarLine\": false, \"buySimOnly\": false, \"broadBandInd\": false, \"ispuDownPaymentAdjstRequired\": false, \"ispuDownPaymentAmount\": 0.0, \"lineWithSkipMDN\": false, \"protectionNotRequired\": false } ], \"numOfAccessoryAndDeviceItemsInCart\": 0, \"totalEdgeUpAmount\": 0.0, \"totalEdgeBuyOutAmount\": 0.0, \"tradeInDetail\": {}, \"totalDownPaymentAmt\": 0.0, \"numOfLinesWithDevices\": 0, \"numofApprovedLines\": 0, \"rfexPayments\": [], \"numOfLines\": 1, \"numofLinesAAL\": 1, \"numofLinesEUP\": 0, \"payments\": [], \"lineSeq\": 0, \"vlcactivePhoneCount\": 0, \"fivegOrderind\": false, \"aceOrderCreated\": false, \"serviceLinesCreated\": false, \"aceItemsModified\": false, \"clnrOrderFlag\": false, \"broadbandInd\": false, \"acctMcsSubscription\": [], \"spendingLimitAmountExceededBy\": \"0.0\", \"numofAccessories\": 0, \"subAccountNBSInfo\": [], \"subAccountNbsDetails\": [], \"bagTax\": false, \"couponDetails\": [ {} ] }, \"refundOrderDetails\": { \"orderNum\": 0, \"totalDueToday\": \"0.0\", \"subTotalDueToday\": \"0.0\", \"totalTaxAmount\": \"0.0\", \"creditApplicationNum\": 0 }, \"accountEligibility\": false, \"displayCartValidationErrors\": true }, \"warningMessages\": [], \"basicORSmartPhoneExists\": false, \"fiveGDeviceORLTEHomeExists\": false, \"cartHasAccessories\": false, \"iscartHasVZHP\": false, \"orderPlaced\": false, \"validateAppointments\": false, \"validateCart\": false, \"redesignFlow\": false, \"newCustomer\": false, \"isLocalStoreOfferEnabled\": false }";
        cart = mapper.readValue(retrieveCartString, CXPRetrieveCartDataVO.class);

         data.setRetrieveCart(cart);
        CartAddDeviceUtil.isDeviceType5G(request, data);

        retrieveCartString = "{ \"cart\": { \"customerProfile\": { \"billAccounts\": [ { \"mtns\": [ { \"mtn\": \"7572158943\", \"equipmentUpgradeEligibility\": { \"upgradeEligibilityDate\": \"03/28/2027\", \"upgradeEligible\": true, \"twoYearContract\": {} }, \"mobileInfoAttributes\": { \"smartFamilyParent\": false }, \"equipmentInfos\": [ { \"deviceInfo\": { \"modelName\": \"Samsung Galaxy S23 FE 128GB in Graphite\", \"deviceId\": \"351139212627823\", \"deviceIdType\": \"IME\", \"deviceSku\": \"SMS711UZAV\" }, \"simInfo\": { \"modelName\": \"5G STANDALONE SIM BY THALES\", \"simId\": \"89148000009897946036\", \"simSku\": \"EMBDSIM5GSA\" } } ], \"lineSharingIndicator\": \"\", \"pricePlanInfo\": { \"planId\": \"63217\", \"planAttributes\": { \"sharePlan\": false } } }, { \"mtn\": \"7575367905\", \"equipmentUpgradeEligibility\": { \"upgradeEligibilityDate\": \"02/11/2023\", \"upgradeEligible\": false, \"twoYearContract\": {} }, \"mobileInfoAttributes\": { \"smartFamilyParent\": false }, \"equipmentInfos\": [ { \"deviceInfo\": { \"modelName\": \"Verizon Internet Gateway WNC-CR200A\", \"deviceId\": \"357473870966213\", \"deviceIdType\": \"IME\", \"deviceSku\": \"WNC-CR200A\" }, \"simInfo\": { \"modelName\": \"THALES 5G SIM MULTIPLE PROFILES\", \"simId\": \"89148000009539336950\", \"simSku\": \"NI-DPSIM5G\" } } ], \"lineSharingIndicator\": \"\", \"pricePlanInfo\": { \"planId\": \"50127\", \"planAttributes\": { \"sharePlan\": false } } } ], \"fiosEligibilityCategory\": \"\", \"accountAddress\": { \"zipCode\": \"23523\", \"zipCodePlus4\": \"1301\", \"fipsCode\": \"5171057000\", \"addressLine1\": \"330 HARBOR POINTE CT APT 408\", \"addressLine2\": \"\", \"city\": \"NORFOLK\", \"state\": \"VA\", \"scrubbedAddress\": { \"streetName\": \"HARBOR POINTE\", \"streetNumber\": \"330\", \"streetType\": \"CT\", \"streetDirection\": \"\", \"apartmentNo\": \"408\", \"pobox\": \"\", \"ruralDeliveryNo\": \"\", \"ruralRouteNo\": \"\", \"city\": \"NORFOLK\", \"state\": \"VA\", \"country\": \"\", \"zipCode\": \"23523\", \"zipCodePlus4\": \"2249\" } }, \"accountAttributes\": { \"autopay\": { \"autoPayDiscount\": \"20.00\" } } } ], \"customerAttributes\": { \"taxExemptCode\": \"N\", \"digitalCustomerType\": \"B2C\" } }, \"cartHasOnlyAccessories\": false, \"cartHasConflicts\": false, \"conflictsAccepted\": false, \"cartHeader\": { \"winBackAccountNumber\": \"\", \"vendorId\": \"NETACE\", \"ani\": 7572158943, \"repRole\": \"POSSYSTST\", \"locationType\": \"S\", \"sourceSystem\": \"OMNI-RETAIL\", \"fullAccountNumber\": \"0726602987-1\", \"status\": \"A\", \"createTimestamp\": \"2024-07-22T10:56:24.48-04:00[US/Eastern]\", \"lastUpdateTimestamp\": \"2024-07-22T10:57:46.14-04:00[US/Eastern]\", \"cartCreator\": \"7572158943\", \"cartCreatorChannelId\": \"OMNI-RETAIL\", \"cartCreatorOrderLocationCode\": \"P332201\", \"cartCreatorSalesRepId\": \"ENC\", \"visionCustomerType\": \"PE\", \"maverickLocation\": false, \"isCoreRep\": false, \"isERTRep\": false }, \"orderDetails\": { \"totalUpgradeFee\": 0.0, \"totalDeviceDollar\": 0.0, \"totalRemainingDeviceDollar\": 0.0, \"totalUsedDeviceDollar\": 0.0, \"totalAccountLevelAccCost\": 0.0, \"totalAccountLevelAccCostWithTax\": 0.0, \"totalShippingCost\": 0.0, \"totalDiscountedShippingCost\": 0.0, \"hqUser\": false, \"returnException\": false, \"taxDetailsList\": [], \"subTotalDueTodayWithoutUpgradeFee\": 0.0, \"subTotalDueMonthlyForAALBYODEUP\": 0.0, \"shipTogetherPref\": true, \"assistanceOptedByCustomer\": false, \"locationState\": \"NC\", \"totalVerizonDollarUsed\": \"0.0\", \"isShellAccountSelected\": false, \"fullfillmentLocation\": \"1000050\", \"guestOrInactiveRefundLines\": false, \"totalDueMonthlyOnProfile\": 0.0, \"subTotalDueMonthlyOnProfile\": 0.0, \"totalMonthlyTaxesOnProfile\": 0.0, \"subTotalOtherLinesOnProfile\": 0.0, \"estimatedNextMonthChargeOnProfile\": 0.0, \"originalSubTotalDueMonthly\": 0.0, \"totalDueMonthlyAfterDiscounts\": 0.0, \"totalTaxAdjustmentAmount\": 0.0, \"totalActivationFees\": 0.0, \"fiveGHomeOrder\": false, \"totalRefundAmount\": 0.0, \"totalExchangeAmount\": 0.0, \"totalRefundTaxAmount\": 0.0, \"totalExchangeTaxAmount\": 0.0, \"digitalExchange\": false, \"remainingAmountAfterAffirmApplied\": 0.0, \"cashOptionEnabled\": false, \"affirmCreditCheckFailed\": false, \"orderType\": \"PS\", \"locationCode\": \"P332201\", \"customerType\": \"U\", \"billingSystem\": \"VE\", \"totalTaxAmount\": \"0.0\", \"spocs\": { \"notificationOptions\": { \"contactPhoneNumber\": \"4541854933\", \"primaryEmailId\": \"TVLITVTIZEVH68252@VZW.COM\" } }, \"totalDueToday\": 0.0, \"runningTotalDueToday\": 0.0, \"totalDueTodayFlag\": false, \"totalDueMonthly\": 0.0, \"subTotalDueMonthly\": 0.0, \"subTotalDueToday\": 0.0, \"subTotalMonthlyTaxes\": 0.0, \"estimatedNextMonthCharge\": 0.0, \"totalMonthlyTaxes\": 0.0, \"subTotalOtherLines\": 0.0, \"subTotalOtherLinesTaxes\": 0.0, \"instantDRCCredit\": false, \"isAttachmentCompleted\": false, \"nextMonthBillTotal\": 0.0, \"customerNotification\": { \"smsLanguage\": \"E\" }, \"orderChannelId\": \"OMNI-RETAIL\", \"orderList\": [ { \"creditApplication\": { \"creditApplicationNum\": 402936739, \"creditApprovalStatus\": \"AP\", \"creditStatusReason\": \"CA Customer Systematic Approval\", \"internationalEligibility\": true, \"securityDepositAmount\": \"0\", \"serviceClass\": \"B\", \"lineCreditClass\": \"1D\", \"creditAppEdited\": false }, \"orderActivityType\": \"EUP\", \"orderNumber\": 0, \"numOfLinesForOrderActivityType\": 0, \"preOrderNumber\": 0, \"digitalOrderId\": 0, \"managerApprovalRequired\": false }, { \"creditApplication\": { \"creditApplicationNum\": 403936739, \"creditApprovalStatus\": \"AP\", \"creditStatusReason\": \"CA Customer Systematic Approval\", \"internationalEligibility\": true, \"securityDepositAmount\": \"0\", \"lineCreditClass\": \"1D\", \"creditAppEdited\": false }, \"orderActivityType\": \"AAL_5G\", \"orderNumber\": 0, \"numOfLinesForOrderActivityType\": 0, \"preOrderNumber\": 0, \"digitalOrderId\": 0, \"managerApprovalRequired\": false } ], \"outletId\": \"000098021\", \"registerNumber\": \"51\", \"saleType\": \"P\", \"salesRepId\": \"ENC\", \"enableSplitShipment\": false, \"splitShipmentIndicator\": false, \"isSingleModConnectedDevice\": false, \"fiveGUpSellAccountLevel\": false, \"customerOnTrialPlan\": false, \"totalDownPaymentAmt\": 0.0, \"totalEdgeBuyOutAmount\": 0.0, \"expressCheckout\": false, \"isEQPandPPLOfferApplied\": false, \"cartTotalDiscounts\": { \"totalDiscount\": \"0.0\", \"barCodeOfferAppliedOnOrder\": false, \"discountDetails\": [] }, \"memberTotalDueToday\": 0.0, \"customerConsent\": \"Y\", \"totalDwosCost\": \"0.0\", \"billingState\": \"VA\", \"isTradeInOfferSelected\": false, \"isAssignMtnRequired\": false, \"fiosCapable\": false, \"fiosEligible\": false, \"quoteWithoutCredit\": false, \"uswinAuthenticationRequired\": false, \"newPreToPostInfo\": { \"newPreToPostIndicator\": \"E\", \"newPreToPostMtns\": { \"accountOwner\": \"\", \"accountMembers\": [] } }, \"totalDueTodayWithoutDiscount\": 0.0, \"subTotalDueTodayWithoutDiscount\": 0.0, \"totalPerksSavings\": \"0.0\" }, \"lineDetails\": { \"lineInfo\": [ { \"isCommonPDP\": false, \"isTradeInIntentSelected\": false, \"multiLineSeqNumber\": 1, \"lineActivityType\": \"AAL_5G\", \"totalDueToday\": 0.0, \"totalDueTodayWithoutTax\": 0.0, \"totalDueTodayWithoutTaxWithoutDiscount\": 0.0, \"totalDueMonthly\": 0.0, \"mobileNumber\": \"\", \"showGlobalChoiceOffer\": false, \"serviceInfo\": { \"serviceAddress\": { \"addressLine1\": \"330 HARBOR POINTE CT APT 408\", \"addressLine2\": \"\", \"zipCode\": \"23523\", \"zipCode4\": \"2249\", \"firstName\": \"DON\", \"lastName\": \"MANNING\", \"city\": \"NORFOLK\", \"state\": \"VA\" }, \"comparePlan\": false, \"primaryUserInfo\": { \"firstName\": \"DON\", \"lastName\": \"MANNING\", \"address\": { \"firmName\": \"\", \"apartmentNo\": \"408\", \"type\": \"CT\", \"streetNumber\": \"330\", \"streetName\": \"HARBOR POINTE\", \"addressLine2\": \"\", \"addressLine1\": \"330 HARBOR POINTE CT APT 408\", \"poBoxNo\": \"\", \"ruralRouteNo\": \"\", \"ruralDelNo\": \"\", \"city\": \"NORFOLK\", \"state\": \"VA\", \"zipCode\": \"23523\", \"zipCode4\": \"2249\", \"county\": \"\", \"countryCode\": \"US\", \"fipsCode\": \"5171057000\", \"firstName\": \"DON\", \"lastName\": \"MANNING\", \"emailId\": \"TVLITVTIZEVH68252@VZW.COM\", \"phoneNumber\": \"4541854933\", \"streetType\": \"CT\", \"streetDirection\": \"\" }, \"isValidAddress\": true, \"bsnsName\": \"\", \"emailId\": \"TVLITVTIZEVH68252@VZW.COM\", \"midInitials\": \"E\" }, \"mtn\": \"7576136076\", \"min\": \"5754367277\", \"isSharePlanAdded\": false, \"mea\": \"VNO\", \"isE911AddressValidated\": false, \"kidsPlanParentMtn\": false, \"mcsSubscription\": [], \"fiveGUpSell\": false, \"e911AddressSameAsServiceAddress\": false, \"unpairedGrantor\": false, \"totalAddedFeaturesPrice\": \"0.0\" }, \"itemsInfo\": [ { \"attention\": \"DON MANNING\", \"shipping\": { \"address\": { \"firmName\": \"\", \"apartmentNo\": \"408\", \"type\": \"R\", \"streetNumber\": \"330\", \"streetName\": \"HARBOR POINTE\", \"addressLine2\": \"\", \"addressLine1\": \"330 HARBOR POINTE CT APT 408\", \"poBoxNo\": \"\", \"ruralRouteNo\": \"\", \"ruralDelNo\": \"\", \"city\": \"NORFOLK\", \"state\": \"VA\", \"zipCode\": \"23523\", \"zipCode4\": \"2249\", \"county\": \"\", \"countryCode\": \"\", \"fipsCode\": \"5171057000\", \"firstName\": \"DON\", \"lastName\": \"MANNING\", \"emailId\": \"TVLITVTIZEVH68252@VZW.COM\", \"phoneNumber\": \"4541854933\", \"streetType\": \"CT\", \"streetDirection\": \"\" }, \"bsnsName\": \"\", \"cbrPhone\": \"4541854933\", \"firstName\": \"DON\", \"lastName\": \"MANNING\", \"midInitials\": \"E\", \"isUseUnVerifiedAddress\": false, \"isValidAddress\": false, \"email\": \"TVLITVTIZEVH68252@VZW.COM\", \"shipToCustomerAddress\": false }, \"fipsCode\": \"5171057000\", \"itemCount\": 0, \"itemTabSeqNum\": 0, \"isPromoSelected\": false, \"isTradeInSelected\": false } ], \"assignMTNIndicator\": \"Y\", \"mtnDetails\": { \"dummyMTNForDomain\": \"7215894301\", \"lineNumber\": \"newLine1\", \"minNumber\": \"5754367277\", \"mobileNumber\": \"7576136076\", \"assignMTNTimestamp\": \"2024-07-22T10:57:46.143777944-04:00[US/Eastern]\", \"npaNXX\": \"757613\" }, \"lineNumber\": \"newLine1\", \"fiveGToFourGDownGrade\": false, \"deviceTypeSelected\": \"5G Internet\", \"lineCreator\": \"7572158943\", \"lineRefundTotal\": 0.0, \"lineExchangeTotal\": 0.0, \"totalDueMonthlyBeforeCredit\": 0.0, \"sugAllowed\": false, \"totalDueAddOnMonthly\": 0.0, \"totalPriceOfPlanAndPerks\": \"0.0\", \"isCpe\": false, \"isLTEHomeLine\": false, \"isDevicePlanCompatible\": false, \"portinMtnAssignment\": false, \"impactedLine\": false, \"preOrBackOrder\": false, \"ispuItem\": false, \"ispuItemBYOD\": false, \"isModConnected\": false, \"modDevice\": false, \"byodCapable\": false, \"isCarLine\": false, \"buySimOnly\": false, \"broadBandInd\": false, \"ispuDownPaymentAdjstRequired\": false, \"ispuDownPaymentAmount\": 0.0, \"lineWithSkipMDN\": false, \"protectionNotRequired\": false } ], \"numOfAccessoryAndDeviceItemsInCart\": 0, \"totalEdgeUpAmount\": 0.0, \"totalEdgeBuyOutAmount\": 0.0, \"tradeInDetail\": {}, \"totalDownPaymentAmt\": 0.0, \"numOfLinesWithDevices\": 0, \"numofApprovedLines\": 0, \"rfexPayments\": [], \"numOfLines\": 1, \"numofLinesAAL\": 1, \"numofLinesEUP\": 0, \"payments\": [], \"lineSeq\": 0, \"vlcactivePhoneCount\": 0, \"fivegOrderind\": false, \"aceOrderCreated\": false, \"serviceLinesCreated\": false, \"aceItemsModified\": false, \"clnrOrderFlag\": false, \"broadbandInd\": false, \"acctMcsSubscription\": [], \"spendingLimitAmountExceededBy\": \"0.0\", \"numofAccessories\": 0, \"subAccountNBSInfo\": [], \"subAccountNbsDetails\": [], \"bagTax\": false, \"couponDetails\": [ {} ] }, \"refundOrderDetails\": { \"orderNum\": 0, \"totalDueToday\": \"0.0\", \"subTotalDueToday\": \"0.0\", \"totalTaxAmount\": \"0.0\", \"creditApplicationNum\": 0 }, \"accountEligibility\": false, \"displayCartValidationErrors\": true }, \"warningMessages\": [], \"basicORSmartPhoneExists\": false, \"fiveGDeviceORLTEHomeExists\": false, \"cartHasAccessories\": false, \"iscartHasVZHP\": false, \"orderPlaced\": false, \"validateAppointments\": false, \"validateCart\": false, \"redesignFlow\": false, \"newCustomer\": false, \"isLocalStoreOfferEnabled\": false }";
        cart = mapper.readValue(retrieveCartString, CXPRetrieveCartDataVO.class);
        data.setRetrieveCart(cart);
        CartAddDeviceUtil.isDeviceType5G(request, data);
        retrieveCartString = "{ \"cart\": { \"customerProfile\": { \"billAccounts\": [ { \"mtns\": [ { \"mtn\": \"7572158943\", \"equipmentUpgradeEligibility\": { \"upgradeEligibilityDate\": \"03/28/2027\", \"upgradeEligible\": true, \"twoYearContract\": {} }, \"mobileInfoAttributes\": { \"smartFamilyParent\": false }, \"equipmentInfos\": [ { \"deviceInfo\": { \"modelName\": \"Samsung Galaxy S23 FE 128GB in Graphite\", \"deviceId\": \"351139212627823\", \"deviceIdType\": \"IME\", \"deviceSku\": \"SMS711UZAV\" }, \"simInfo\": { \"modelName\": \"5G STANDALONE SIM BY THALES\", \"simId\": \"89148000009897946036\", \"simSku\": \"EMBDSIM5GSA\" } } ], \"lineSharingIndicator\": \"\", \"pricePlanInfo\": { \"planId\": \"63217\", \"planAttributes\": { \"sharePlan\": false } } }, { \"mtn\": \"7575367905\", \"equipmentUpgradeEligibility\": { \"upgradeEligibilityDate\": \"02/11/2023\", \"upgradeEligible\": false, \"twoYearContract\": {} }, \"mobileInfoAttributes\": { \"smartFamilyParent\": false }, \"equipmentInfos\": [ { \"deviceInfo\": { \"modelName\": \"Verizon Internet Gateway WNC-CR200A\", \"deviceId\": \"357473870966213\", \"deviceIdType\": \"IME\", \"deviceSku\": \"WNC-CR200A\" }, \"simInfo\": { \"modelName\": \"THALES 5G SIM MULTIPLE PROFILES\", \"simId\": \"89148000009539336950\", \"simSku\": \"NI-DPSIM5G\" } } ], \"lineSharingIndicator\": \"\", \"pricePlanInfo\": { \"planId\": \"50127\", \"planAttributes\": { \"sharePlan\": false } } } ], \"fiosEligibilityCategory\": \"\", \"accountAddress\": { \"zipCode\": \"23523\", \"zipCodePlus4\": \"1301\", \"fipsCode\": \"5171057000\", \"addressLine1\": \"330 HARBOR POINTE CT APT 408\", \"addressLine2\": \"\", \"city\": \"NORFOLK\", \"state\": \"VA\", \"scrubbedAddress\": { \"streetName\": \"HARBOR POINTE\", \"streetNumber\": \"330\", \"streetType\": \"CT\", \"streetDirection\": \"\", \"apartmentNo\": \"408\", \"pobox\": \"\", \"ruralDeliveryNo\": \"\", \"ruralRouteNo\": \"\", \"city\": \"NORFOLK\", \"state\": \"VA\", \"country\": \"\", \"zipCode\": \"23523\", \"zipCodePlus4\": \"2249\" } }, \"accountAttributes\": { \"autopay\": { \"autoPayDiscount\": \"20.00\" } } } ], \"customerAttributes\": { \"taxExemptCode\": \"N\", \"digitalCustomerType\": \"B2C\" } }, \"cartHasOnlyAccessories\": false, \"cartHasConflicts\": false, \"conflictsAccepted\": false, \"cartHeader\": { \"winBackAccountNumber\": \"\", \"vendorId\": \"NETACE\", \"ani\": 7572158943, \"repRole\": \"POSSYSTST\", \"locationType\": \"S\", \"sourceSystem\": \"OMNI-RETAIL\", \"fullAccountNumber\": \"0726602987-1\", \"status\": \"A\", \"createTimestamp\": \"2024-07-22T10:56:24.48-04:00[US/Eastern]\", \"lastUpdateTimestamp\": \"2024-07-22T10:57:46.14-04:00[US/Eastern]\", \"cartCreator\": \"7572158943\", \"cartCreatorChannelId\": \"OMNI-RETAIL\", \"cartCreatorOrderLocationCode\": \"P332201\", \"cartCreatorSalesRepId\": \"ENC\", \"visionCustomerType\": \"PE\", \"maverickLocation\": false, \"isCoreRep\": false, \"isERTRep\": false }, \"orderDetails\": { \"totalUpgradeFee\": 0.0, \"totalDeviceDollar\": 0.0, \"totalRemainingDeviceDollar\": 0.0, \"totalUsedDeviceDollar\": 0.0, \"totalAccountLevelAccCost\": 0.0, \"totalAccountLevelAccCostWithTax\": 0.0, \"totalShippingCost\": 0.0, \"totalDiscountedShippingCost\": 0.0, \"hqUser\": false, \"returnException\": false, \"taxDetailsList\": [], \"subTotalDueTodayWithoutUpgradeFee\": 0.0, \"subTotalDueMonthlyForAALBYODEUP\": 0.0, \"shipTogetherPref\": true, \"assistanceOptedByCustomer\": false, \"locationState\": \"NC\", \"totalVerizonDollarUsed\": \"0.0\", \"isShellAccountSelected\": false, \"fullfillmentLocation\": \"1000050\", \"guestOrInactiveRefundLines\": false, \"totalDueMonthlyOnProfile\": 0.0, \"subTotalDueMonthlyOnProfile\": 0.0, \"totalMonthlyTaxesOnProfile\": 0.0, \"subTotalOtherLinesOnProfile\": 0.0, \"estimatedNextMonthChargeOnProfile\": 0.0, \"originalSubTotalDueMonthly\": 0.0, \"totalDueMonthlyAfterDiscounts\": 0.0, \"totalTaxAdjustmentAmount\": 0.0, \"totalActivationFees\": 0.0, \"fiveGHomeOrder\": false, \"totalRefundAmount\": 0.0, \"totalExchangeAmount\": 0.0, \"totalRefundTaxAmount\": 0.0, \"totalExchangeTaxAmount\": 0.0, \"digitalExchange\": false, \"remainingAmountAfterAffirmApplied\": 0.0, \"cashOptionEnabled\": false, \"affirmCreditCheckFailed\": false, \"orderType\": \"PS\", \"locationCode\": \"P332201\", \"customerType\": \"U\", \"billingSystem\": \"VE\", \"totalTaxAmount\": \"0.0\", \"spocs\": { \"notificationOptions\": { \"contactPhoneNumber\": \"4541854933\", \"primaryEmailId\": \"TVLITVTIZEVH68252@VZW.COM\" } }, \"totalDueToday\": 0.0, \"runningTotalDueToday\": 0.0, \"totalDueTodayFlag\": false, \"totalDueMonthly\": 0.0, \"subTotalDueMonthly\": 0.0, \"subTotalDueToday\": 0.0, \"subTotalMonthlyTaxes\": 0.0, \"estimatedNextMonthCharge\": 0.0, \"totalMonthlyTaxes\": 0.0, \"subTotalOtherLines\": 0.0, \"subTotalOtherLinesTaxes\": 0.0, \"instantDRCCredit\": false, \"isAttachmentCompleted\": false, \"nextMonthBillTotal\": 0.0, \"customerNotification\": { \"smsLanguage\": \"E\" }, \"orderChannelId\": \"OMNI-RETAIL\", \"orderList\": [ { \"creditApplication\": { \"creditApplicationNum\": 402936739, \"creditApprovalStatus\": \"AP\", \"creditStatusReason\": \"CA Customer Systematic Approval\", \"internationalEligibility\": true, \"securityDepositAmount\": \"0\", \"serviceClass\": \"B\", \"lineCreditClass\": \"1D\", \"creditAppEdited\": false }, \"orderActivityType\": \"EUP\", \"orderNumber\": 0, \"numOfLinesForOrderActivityType\": 0, \"preOrderNumber\": 0, \"digitalOrderId\": 0, \"managerApprovalRequired\": false }, { \"creditApplication\": { \"creditApplicationNum\": 403936739, \"creditApprovalStatus\": \"AP\", \"creditStatusReason\": \"CA Customer Systematic Approval\", \"internationalEligibility\": true, \"securityDepositAmount\": \"0\", \"lineCreditClass\": \"1D\", \"creditAppEdited\": false }, \"orderActivityType\": \"AAL_5G\", \"orderNumber\": 0, \"numOfLinesForOrderActivityType\": 0, \"preOrderNumber\": 0, \"digitalOrderId\": 0, \"managerApprovalRequired\": false } ], \"outletId\": \"000098021\", \"registerNumber\": \"51\", \"saleType\": \"P\", \"salesRepId\": \"ENC\", \"enableSplitShipment\": false, \"splitShipmentIndicator\": false, \"isSingleModConnectedDevice\": false, \"fiveGUpSellAccountLevel\": false, \"customerOnTrialPlan\": false, \"totalDownPaymentAmt\": 0.0, \"totalEdgeBuyOutAmount\": 0.0, \"expressCheckout\": false, \"isEQPandPPLOfferApplied\": false, \"cartTotalDiscounts\": { \"totalDiscount\": \"0.0\", \"barCodeOfferAppliedOnOrder\": false, \"discountDetails\": [] }, \"memberTotalDueToday\": 0.0, \"customerConsent\": \"Y\", \"totalDwosCost\": \"0.0\", \"billingState\": \"VA\", \"isTradeInOfferSelected\": false, \"isAssignMtnRequired\": false, \"fiosCapable\": false, \"fiosEligible\": false, \"quoteWithoutCredit\": false, \"uswinAuthenticationRequired\": false, \"newPreToPostInfo\": { \"newPreToPostIndicator\": \"E\", \"newPreToPostMtns\": { \"accountOwner\": \"\", \"accountMembers\": [] } }, \"totalDueTodayWithoutDiscount\": 0.0, \"subTotalDueTodayWithoutDiscount\": 0.0, \"totalPerksSavings\": \"0.0\" }, \"lineDetails\": { \"lineInfo\": [ {} ], \"numOfAccessoryAndDeviceItemsInCart\": 0, \"totalEdgeUpAmount\": 0.0, \"totalEdgeBuyOutAmount\": 0.0, \"tradeInDetail\": {}, \"totalDownPaymentAmt\": 0.0, \"numOfLinesWithDevices\": 0, \"numofApprovedLines\": 0, \"rfexPayments\": [], \"numOfLines\": 1, \"numofLinesAAL\": 1, \"numofLinesEUP\": 0, \"payments\": [], \"lineSeq\": 0, \"vlcactivePhoneCount\": 0, \"fivegOrderind\": false, \"aceOrderCreated\": false, \"serviceLinesCreated\": false, \"aceItemsModified\": false, \"clnrOrderFlag\": false, \"broadbandInd\": false, \"acctMcsSubscription\": [], \"spendingLimitAmountExceededBy\": \"0.0\", \"numofAccessories\": 0, \"subAccountNBSInfo\": [], \"subAccountNbsDetails\": [], \"bagTax\": false, \"couponDetails\": [ {} ] }, \"refundOrderDetails\": { \"orderNum\": 0, \"totalDueToday\": \"0.0\", \"subTotalDueToday\": \"0.0\", \"totalTaxAmount\": \"0.0\", \"creditApplicationNum\": 0 }, \"accountEligibility\": false, \"displayCartValidationErrors\": true }, \"warningMessages\": [], \"basicORSmartPhoneExists\": false, \"fiveGDeviceORLTEHomeExists\": false, \"cartHasAccessories\": false, \"iscartHasVZHP\": false, \"orderPlaced\": false, \"validateAppointments\": false, \"validateCart\": false, \"redesignFlow\": false, \"newCustomer\": false, \"isLocalStoreOfferEnabled\": false }";
        cart = mapper.readValue(retrieveCartString, CXPRetrieveCartDataVO.class);
        data.setRetrieveCart(cart);
        CartAddDeviceUtil.isDeviceType5G(request, data);
        retrieveCartString = "{ \"cart\": { \"customerProfile\": { \"billAccounts\": [ { \"mtns\": [ { \"mtn\": \"7572158943\", \"equipmentUpgradeEligibility\": { \"upgradeEligibilityDate\": \"03/28/2027\", \"upgradeEligible\": true, \"twoYearContract\": {} }, \"mobileInfoAttributes\": { \"smartFamilyParent\": false }, \"equipmentInfos\": [ { \"deviceInfo\": { \"modelName\": \"Samsung Galaxy S23 FE 128GB in Graphite\", \"deviceId\": \"351139212627823\", \"deviceIdType\": \"IME\", \"deviceSku\": \"SMS711UZAV\" }, \"simInfo\": { \"modelName\": \"5G STANDALONE SIM BY THALES\", \"simId\": \"89148000009897946036\", \"simSku\": \"EMBDSIM5GSA\" } } ], \"lineSharingIndicator\": \"\", \"pricePlanInfo\": { \"planId\": \"63217\", \"planAttributes\": { \"sharePlan\": false } } }, { \"mtn\": \"7575367905\", \"equipmentUpgradeEligibility\": { \"upgradeEligibilityDate\": \"02/11/2023\", \"upgradeEligible\": false, \"twoYearContract\": {} }, \"mobileInfoAttributes\": { \"smartFamilyParent\": false }, \"equipmentInfos\": [ { \"deviceInfo\": { \"modelName\": \"Verizon Internet Gateway WNC-CR200A\", \"deviceId\": \"357473870966213\", \"deviceIdType\": \"IME\", \"deviceSku\": \"WNC-CR200A\" }, \"simInfo\": { \"modelName\": \"THALES 5G SIM MULTIPLE PROFILES\", \"simId\": \"89148000009539336950\", \"simSku\": \"NI-DPSIM5G\" } } ], \"lineSharingIndicator\": \"\", \"pricePlanInfo\": { \"planId\": \"50127\", \"planAttributes\": { \"sharePlan\": false } } } ], \"fiosEligibilityCategory\": \"\", \"accountAddress\": { \"zipCode\": \"23523\", \"zipCodePlus4\": \"1301\", \"fipsCode\": \"5171057000\", \"addressLine1\": \"330 HARBOR POINTE CT APT 408\", \"addressLine2\": \"\", \"city\": \"NORFOLK\", \"state\": \"VA\", \"scrubbedAddress\": { \"streetName\": \"HARBOR POINTE\", \"streetNumber\": \"330\", \"streetType\": \"CT\", \"streetDirection\": \"\", \"apartmentNo\": \"408\", \"pobox\": \"\", \"ruralDeliveryNo\": \"\", \"ruralRouteNo\": \"\", \"city\": \"NORFOLK\", \"state\": \"VA\", \"country\": \"\", \"zipCode\": \"23523\", \"zipCodePlus4\": \"2249\" } }, \"accountAttributes\": { \"autopay\": { \"autoPayDiscount\": \"20.00\" } } } ], \"customerAttributes\": { \"taxExemptCode\": \"N\", \"digitalCustomerType\": \"B2C\" } }, \"cartHasOnlyAccessories\": false, \"cartHasConflicts\": false, \"conflictsAccepted\": false, \"cartHeader\": { \"winBackAccountNumber\": \"\", \"vendorId\": \"NETACE\", \"ani\": 7572158943, \"repRole\": \"POSSYSTST\", \"locationType\": \"S\", \"sourceSystem\": \"OMNI-RETAIL\", \"fullAccountNumber\": \"0726602987-1\", \"status\": \"A\", \"createTimestamp\": \"2024-07-22T10:56:24.48-04:00[US/Eastern]\", \"lastUpdateTimestamp\": \"2024-07-22T10:57:46.14-04:00[US/Eastern]\", \"cartCreator\": \"7572158943\", \"cartCreatorChannelId\": \"OMNI-RETAIL\", \"cartCreatorOrderLocationCode\": \"P332201\", \"cartCreatorSalesRepId\": \"ENC\", \"visionCustomerType\": \"PE\", \"maverickLocation\": false, \"isCoreRep\": false, \"isERTRep\": false }, \"orderDetails\": { \"totalUpgradeFee\": 0.0, \"totalDeviceDollar\": 0.0, \"totalRemainingDeviceDollar\": 0.0, \"totalUsedDeviceDollar\": 0.0, \"totalAccountLevelAccCost\": 0.0, \"totalAccountLevelAccCostWithTax\": 0.0, \"totalShippingCost\": 0.0, \"totalDiscountedShippingCost\": 0.0, \"hqUser\": false, \"returnException\": false, \"taxDetailsList\": [], \"subTotalDueTodayWithoutUpgradeFee\": 0.0, \"subTotalDueMonthlyForAALBYODEUP\": 0.0, \"shipTogetherPref\": true, \"assistanceOptedByCustomer\": false, \"locationState\": \"NC\", \"totalVerizonDollarUsed\": \"0.0\", \"isShellAccountSelected\": false, \"fullfillmentLocation\": \"1000050\", \"guestOrInactiveRefundLines\": false, \"totalDueMonthlyOnProfile\": 0.0, \"subTotalDueMonthlyOnProfile\": 0.0, \"totalMonthlyTaxesOnProfile\": 0.0, \"subTotalOtherLinesOnProfile\": 0.0, \"estimatedNextMonthChargeOnProfile\": 0.0, \"originalSubTotalDueMonthly\": 0.0, \"totalDueMonthlyAfterDiscounts\": 0.0, \"totalTaxAdjustmentAmount\": 0.0, \"totalActivationFees\": 0.0, \"fiveGHomeOrder\": false, \"totalRefundAmount\": 0.0, \"totalExchangeAmount\": 0.0, \"totalRefundTaxAmount\": 0.0, \"totalExchangeTaxAmount\": 0.0, \"digitalExchange\": false, \"remainingAmountAfterAffirmApplied\": 0.0, \"cashOptionEnabled\": false, \"affirmCreditCheckFailed\": false, \"orderType\": \"PS\", \"locationCode\": \"P332201\", \"customerType\": \"U\", \"billingSystem\": \"VE\", \"totalTaxAmount\": \"0.0\", \"spocs\": { \"notificationOptions\": { \"contactPhoneNumber\": \"4541854933\", \"primaryEmailId\": \"TVLITVTIZEVH68252@VZW.COM\" } }, \"totalDueToday\": 0.0, \"runningTotalDueToday\": 0.0, \"totalDueTodayFlag\": false, \"totalDueMonthly\": 0.0, \"subTotalDueMonthly\": 0.0, \"subTotalDueToday\": 0.0, \"subTotalMonthlyTaxes\": 0.0, \"estimatedNextMonthCharge\": 0.0, \"totalMonthlyTaxes\": 0.0, \"subTotalOtherLines\": 0.0, \"subTotalOtherLinesTaxes\": 0.0, \"instantDRCCredit\": false, \"isAttachmentCompleted\": false, \"nextMonthBillTotal\": 0.0, \"customerNotification\": { \"smsLanguage\": \"E\" }, \"orderChannelId\": \"OMNI-RETAIL\", \"orderList\": [ { \"creditApplication\": { \"creditApplicationNum\": 402936739, \"creditApprovalStatus\": \"AP\", \"creditStatusReason\": \"CA Customer Systematic Approval\", \"internationalEligibility\": true, \"securityDepositAmount\": \"0\", \"serviceClass\": \"B\", \"lineCreditClass\": \"1D\", \"creditAppEdited\": false }, \"orderActivityType\": \"EUP\", \"orderNumber\": 0, \"numOfLinesForOrderActivityType\": 0, \"preOrderNumber\": 0, \"digitalOrderId\": 0, \"managerApprovalRequired\": false }, { \"creditApplication\": { \"creditApplicationNum\": 403936739, \"creditApprovalStatus\": \"AP\", \"creditStatusReason\": \"CA Customer Systematic Approval\", \"internationalEligibility\": true, \"securityDepositAmount\": \"0\", \"lineCreditClass\": \"1D\", \"creditAppEdited\": false }, \"orderActivityType\": \"AAL_5G\", \"orderNumber\": 0, \"numOfLinesForOrderActivityType\": 0, \"preOrderNumber\": 0, \"digitalOrderId\": 0, \"managerApprovalRequired\": false } ], \"outletId\": \"000098021\", \"registerNumber\": \"51\", \"saleType\": \"P\", \"salesRepId\": \"ENC\", \"enableSplitShipment\": false, \"splitShipmentIndicator\": false, \"isSingleModConnectedDevice\": false, \"fiveGUpSellAccountLevel\": false, \"customerOnTrialPlan\": false, \"totalDownPaymentAmt\": 0.0, \"totalEdgeBuyOutAmount\": 0.0, \"expressCheckout\": false, \"isEQPandPPLOfferApplied\": false, \"cartTotalDiscounts\": { \"totalDiscount\": \"0.0\", \"barCodeOfferAppliedOnOrder\": false, \"discountDetails\": [] }, \"memberTotalDueToday\": 0.0, \"customerConsent\": \"Y\", \"totalDwosCost\": \"0.0\", \"billingState\": \"VA\", \"isTradeInOfferSelected\": false, \"isAssignMtnRequired\": false, \"fiosCapable\": false, \"fiosEligible\": false, \"quoteWithoutCredit\": false, \"uswinAuthenticationRequired\": false, \"newPreToPostInfo\": { \"newPreToPostIndicator\": \"E\", \"newPreToPostMtns\": { \"accountOwner\": \"\", \"accountMembers\": [] } }, \"totalDueTodayWithoutDiscount\": 0.0, \"subTotalDueTodayWithoutDiscount\": 0.0, \"totalPerksSavings\": \"0.0\" }, \"lineDetails\": { \"numOfAccessoryAndDeviceItemsInCart\": 0, \"totalEdgeUpAmount\": 0.0, \"totalEdgeBuyOutAmount\": 0.0, \"tradeInDetail\": {}, \"totalDownPaymentAmt\": 0.0, \"numOfLinesWithDevices\": 0, \"numofApprovedLines\": 0, \"rfexPayments\": [], \"numOfLines\": 1, \"numofLinesAAL\": 1, \"numofLinesEUP\": 0, \"payments\": [], \"lineSeq\": 0, \"vlcactivePhoneCount\": 0, \"fivegOrderind\": false, \"aceOrderCreated\": false, \"serviceLinesCreated\": false, \"aceItemsModified\": false, \"clnrOrderFlag\": false, \"broadbandInd\": false, \"acctMcsSubscription\": [], \"spendingLimitAmountExceededBy\": \"0.0\", \"numofAccessories\": 0, \"subAccountNBSInfo\": [], \"subAccountNbsDetails\": [], \"bagTax\": false, \"couponDetails\": [ {} ] }, \"refundOrderDetails\": { \"orderNum\": 0, \"totalDueToday\": \"0.0\", \"subTotalDueToday\": \"0.0\", \"totalTaxAmount\": \"0.0\", \"creditApplicationNum\": 0 }, \"accountEligibility\": false, \"displayCartValidationErrors\": true }, \"warningMessages\": [], \"basicORSmartPhoneExists\": false, \"fiveGDeviceORLTEHomeExists\": false, \"cartHasAccessories\": false, \"iscartHasVZHP\": false, \"orderPlaced\": false, \"validateAppointments\": false, \"validateCart\": false, \"redesignFlow\": false, \"newCustomer\": false, \"isLocalStoreOfferEnabled\": false }";
        cart = mapper.readValue(retrieveCartString, CXPRetrieveCartDataVO.class);
        data.setRetrieveCart(cart);
        CartAddDeviceUtil.isDeviceType5G(request, data);
        data.setRetrieveCart(null);
        CartAddDeviceUtil.isDeviceType5G(request, data);
        request.getData().getLines().get(0).setMtn(null);
        CartAddDeviceUtil.isDeviceType5G(request, data);

        data.getHomeSalesAddress().setCBandQualified(true);
        CartAddDeviceUtil.checkAndUpdateHomeSalesFiveGNBT( data, request);

        data.getHomeSalesAddress().setFiveGHomeQualified(true);
        data.getHomeSalesAddress().setCBandQualified(false);
        CartAddDeviceUtil.checkAndUpdateHomeSalesFiveGNBT( data, request);

        data.getHomeSalesAddress().setFiveGHomeQualified(false);
        data.getHomeSalesAddress().setCBandQualified(false);
        CartAddDeviceUtil.checkAndUpdateHomeSalesFiveGNBT( data, request);


    }
    @Test
    public void checkAndUpdateNetworkBdType1Test () throws JsonProcessingException {

        CartRedisData data = null;
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        request.setCartInfo(null);
        request.setData(null);
        FiveGAddressRedisData address = null;
        CartAddDeviceUtil.checkAndUpdateNetworkBdType(data, request,address);

        data = new CartRedisData();
        address = new FiveGAddressRedisData();
        request.setCartInfo(new DeviceCartInfo());
        request.setData(new AddDeviceData());
        request.getCartInfo().setIntendType(null);
        request.getData().setLines(null);
        data.setIsHomeSales(null);
        CartAddDeviceUtil.checkAndUpdateNetworkBdType(data, request,address);

        request.getCartInfo().setIntendType("AAL");
        String deviceRequestString ="{ \"cartInfo\": { \"clientAppName\": \"VZW-NETACE\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"cartId\": \"\", \"caseId\": \"\", \"accountNumber\": \"\", \"cartCreator\": \"400936722\", \"processingMTN\": \"newLine1\", \"processStep\": \"GridWallPDP\", \"processAction\": \"addDevice\", \"intendType\": \"NSE_5G\", \"creditAppNum\": \"400936722\" }, \"data\": { \"lines\": [ { \"depletionType\": \"O\", \"depletionLocationCode\": \"\", \"ispuFlow\": false, \"isNewLine\": false, \"mtn\": \"7576136076\", \"sim\": { \"id\": \"NI-DPSIM5G\" }, \"fiveG\": {} } ] } }";
        request = mapper.readValue(deviceRequestString, AddDeviceUIRequest.class);

        data.setIsHomeSales("true");
        data.setHomeSalesAddress(null);
        CartAddDeviceUtil.checkAndUpdateNetworkBdType(data, request,address);
        request.getCartInfo().setIntendType("AAL_5G");
        data.setHomeSalesAddress(new HomeSalesAddress());
        CartAddDeviceUtil.checkAndUpdateNetworkBdType(data, request,address);


        CXPRetrieveCartDataVO cart = new CXPRetrieveCartDataVO();
        cart.setCart(null);
        CartAddDeviceUtil.isCartHasLine(cart);
        cart.setCart(new CXPCartVO());
        cart.getCart().setLineDetails(null);
        CartAddDeviceUtil.isCartHasLine(cart);
        cart.getCart().setLineDetails(new CXPLineDetailsVO());
        cart.getCart().getLineDetails().setLineInfo(null);
        CartAddDeviceUtil.isCartHasLine(cart);
        CXPLineInfo[] lineInfo = new CXPLineInfo[0];
        cart.getCart().getLineDetails().setLineInfo(lineInfo);
        CartAddDeviceUtil.isCartHasLine(cart);
        lineInfo = new CXPLineInfo[1];
        cart.getCart().getLineDetails().setLineInfo(lineInfo);
        CartAddDeviceUtil.isCartHasLine(cart);
    }

    @Test
    public void checkAndUpdateNetworkBdType2Test () throws JsonProcessingException {

        String deviceRequestString = "{ \"cartInfo\": { \"clientAppName\": \"VZW-NETACE\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"cartId\": \"\", \"caseId\": \"\", \"accountNumber\": \"\", \"cartCreator\": \"400936722\", \"processingMTN\": \"newLine1\", \"processStep\": \"GridWallPDP\", \"processAction\": \"addDevice\", \"intendType\": \"NSE_5G\", \"creditAppNum\": \"400936722\" }, \"data\": { \"lines\": [ { \"depletionType\": \"O\", \"depletionLocationCode\": \"\", \"ispuFlow\": false, \"isNewLine\": false, \"mtn\": \"7576136076\", \"device\": { \"id\": \"22600001\", \"contractTerm\": \"MONTH_TO_MONTH\" }, \"sim\": { \"id\": \"NI-DPSIM5G\" }, \"fiveG\": {} } ] } }";
        AddDeviceUIRequest request = mapper.readValue(deviceRequestString, AddDeviceUIRequest.class);

        String retrieveCartString = "{ \"cart\": { \"customerProfile\": { \"billAccounts\": [ { \"mtns\": [ { \"mtn\": \"7572158943\", \"equipmentUpgradeEligibility\": { \"upgradeEligibilityDate\": \"03/28/2027\", \"upgradeEligible\": true, \"twoYearContract\": {} }, \"mobileInfoAttributes\": { \"smartFamilyParent\": false }, \"equipmentInfos\": [ { \"deviceInfo\": { \"modelName\": \"Samsung Galaxy S23 FE 128GB in Graphite\", \"deviceId\": \"351139212627823\", \"deviceIdType\": \"IME\", \"deviceSku\": \"SMS711UZAV\" }, \"simInfo\": { \"modelName\": \"5G STANDALONE SIM BY THALES\", \"simId\": \"89148000009897946036\", \"simSku\": \"EMBDSIM5GSA\" } } ], \"lineSharingIndicator\": \"\", \"pricePlanInfo\": { \"planId\": \"63217\", \"planAttributes\": { \"sharePlan\": false } } }, { \"mtn\": \"7575367905\", \"equipmentUpgradeEligibility\": { \"upgradeEligibilityDate\": \"02/11/2023\", \"upgradeEligible\": false, \"twoYearContract\": {} }, \"mobileInfoAttributes\": { \"smartFamilyParent\": false }, \"equipmentInfos\": [ { \"deviceInfo\": { \"modelName\": \"Verizon Internet Gateway WNC-CR200A\", \"deviceId\": \"357473870966213\", \"deviceIdType\": \"IME\", \"deviceSku\": \"WNC-CR200A\" }, \"simInfo\": { \"modelName\": \"THALES 5G SIM MULTIPLE PROFILES\", \"simId\": \"89148000009539336950\", \"simSku\": \"NI-DPSIM5G\" } } ], \"lineSharingIndicator\": \"\", \"pricePlanInfo\": { \"planId\": \"50127\", \"planAttributes\": { \"sharePlan\": false } } } ], \"fiosEligibilityCategory\": \"\", \"accountAddress\": { \"zipCode\": \"23523\", \"zipCodePlus4\": \"1301\", \"fipsCode\": \"5171057000\", \"addressLine1\": \"330 HARBOR POINTE CT APT 408\", \"addressLine2\": \"\", \"city\": \"NORFOLK\", \"state\": \"VA\", \"scrubbedAddress\": { \"streetName\": \"HARBOR POINTE\", \"streetNumber\": \"330\", \"streetType\": \"CT\", \"streetDirection\": \"\", \"apartmentNo\": \"408\", \"pobox\": \"\", \"ruralDeliveryNo\": \"\", \"ruralRouteNo\": \"\", \"city\": \"NORFOLK\", \"state\": \"VA\", \"country\": \"\", \"zipCode\": \"23523\", \"zipCodePlus4\": \"2249\" } }, \"accountAttributes\": { \"autopay\": { \"autoPayDiscount\": \"20.00\" } } } ], \"customerAttributes\": { \"taxExemptCode\": \"N\", \"digitalCustomerType\": \"B2C\" } }, \"cartHasOnlyAccessories\": false, \"cartHasConflicts\": false, \"conflictsAccepted\": false, \"cartHeader\": { \"winBackAccountNumber\": \"\", \"vendorId\": \"NETACE\", \"ani\": 7572158943, \"repRole\": \"POSSYSTST\", \"locationType\": \"S\", \"sourceSystem\": \"OMNI-RETAIL\", \"fullAccountNumber\": \"0726602987-1\", \"status\": \"A\", \"createTimestamp\": \"2024-07-22T10:56:24.48-04:00[US/Eastern]\", \"lastUpdateTimestamp\": \"2024-07-22T10:57:46.14-04:00[US/Eastern]\", \"cartCreator\": \"7572158943\", \"cartCreatorChannelId\": \"OMNI-RETAIL\", \"cartCreatorOrderLocationCode\": \"P332201\", \"cartCreatorSalesRepId\": \"ENC\", \"visionCustomerType\": \"PE\", \"maverickLocation\": false, \"isCoreRep\": false, \"isERTRep\": false }, \"orderDetails\": { \"totalUpgradeFee\": 0.0, \"totalDeviceDollar\": 0.0, \"totalRemainingDeviceDollar\": 0.0, \"totalUsedDeviceDollar\": 0.0, \"totalAccountLevelAccCost\": 0.0, \"totalAccountLevelAccCostWithTax\": 0.0, \"totalShippingCost\": 0.0, \"totalDiscountedShippingCost\": 0.0, \"hqUser\": false, \"returnException\": false, \"taxDetailsList\": [], \"subTotalDueTodayWithoutUpgradeFee\": 0.0, \"subTotalDueMonthlyForAALBYODEUP\": 0.0, \"shipTogetherPref\": true, \"assistanceOptedByCustomer\": false, \"locationState\": \"NC\", \"totalVerizonDollarUsed\": \"0.0\", \"isShellAccountSelected\": false, \"fullfillmentLocation\": \"1000050\", \"guestOrInactiveRefundLines\": false, \"totalDueMonthlyOnProfile\": 0.0, \"subTotalDueMonthlyOnProfile\": 0.0, \"totalMonthlyTaxesOnProfile\": 0.0, \"subTotalOtherLinesOnProfile\": 0.0, \"estimatedNextMonthChargeOnProfile\": 0.0, \"originalSubTotalDueMonthly\": 0.0, \"totalDueMonthlyAfterDiscounts\": 0.0, \"totalTaxAdjustmentAmount\": 0.0, \"totalActivationFees\": 0.0, \"fiveGHomeOrder\": false, \"totalRefundAmount\": 0.0, \"totalExchangeAmount\": 0.0, \"totalRefundTaxAmount\": 0.0, \"totalExchangeTaxAmount\": 0.0, \"digitalExchange\": false, \"remainingAmountAfterAffirmApplied\": 0.0, \"cashOptionEnabled\": false, \"affirmCreditCheckFailed\": false, \"orderType\": \"PS\", \"locationCode\": \"P332201\", \"customerType\": \"U\", \"billingSystem\": \"VE\", \"totalTaxAmount\": \"0.0\", \"spocs\": { \"notificationOptions\": { \"contactPhoneNumber\": \"4541854933\", \"primaryEmailId\": \"TVLITVTIZEVH68252@VZW.COM\" } }, \"totalDueToday\": 0.0, \"runningTotalDueToday\": 0.0, \"totalDueTodayFlag\": false, \"totalDueMonthly\": 0.0, \"subTotalDueMonthly\": 0.0, \"subTotalDueToday\": 0.0, \"subTotalMonthlyTaxes\": 0.0, \"estimatedNextMonthCharge\": 0.0, \"totalMonthlyTaxes\": 0.0, \"subTotalOtherLines\": 0.0, \"subTotalOtherLinesTaxes\": 0.0, \"instantDRCCredit\": false, \"isAttachmentCompleted\": false, \"nextMonthBillTotal\": 0.0, \"customerNotification\": { \"smsLanguage\": \"E\" }, \"orderChannelId\": \"OMNI-RETAIL\", \"orderList\": [ { \"creditApplication\": { \"creditApplicationNum\": 402936739, \"creditApprovalStatus\": \"AP\", \"creditStatusReason\": \"CA Customer Systematic Approval\", \"internationalEligibility\": true, \"securityDepositAmount\": \"0\", \"serviceClass\": \"B\", \"lineCreditClass\": \"1D\", \"creditAppEdited\": false }, \"orderActivityType\": \"EUP\", \"orderNumber\": 0, \"numOfLinesForOrderActivityType\": 0, \"preOrderNumber\": 0, \"digitalOrderId\": 0, \"managerApprovalRequired\": false }, { \"creditApplication\": { \"creditApplicationNum\": 403936739, \"creditApprovalStatus\": \"AP\", \"creditStatusReason\": \"CA Customer Systematic Approval\", \"internationalEligibility\": true, \"securityDepositAmount\": \"0\", \"lineCreditClass\": \"1D\", \"creditAppEdited\": false }, \"orderActivityType\": \"AAL_5G\", \"orderNumber\": 0, \"numOfLinesForOrderActivityType\": 0, \"preOrderNumber\": 0, \"digitalOrderId\": 0, \"managerApprovalRequired\": false } ], \"outletId\": \"000098021\", \"registerNumber\": \"51\", \"saleType\": \"P\", \"salesRepId\": \"ENC\", \"enableSplitShipment\": false, \"splitShipmentIndicator\": false, \"isSingleModConnectedDevice\": false, \"fiveGUpSellAccountLevel\": false, \"customerOnTrialPlan\": false, \"totalDownPaymentAmt\": 0.0, \"totalEdgeBuyOutAmount\": 0.0, \"expressCheckout\": false, \"isEQPandPPLOfferApplied\": false, \"cartTotalDiscounts\": { \"totalDiscount\": \"0.0\", \"barCodeOfferAppliedOnOrder\": false, \"discountDetails\": [] }, \"memberTotalDueToday\": 0.0, \"customerConsent\": \"Y\", \"totalDwosCost\": \"0.0\", \"billingState\": \"VA\", \"isTradeInOfferSelected\": false, \"isAssignMtnRequired\": false, \"fiosCapable\": false, \"fiosEligible\": false, \"quoteWithoutCredit\": false, \"uswinAuthenticationRequired\": false, \"newPreToPostInfo\": { \"newPreToPostIndicator\": \"E\", \"newPreToPostMtns\": { \"accountOwner\": \"\", \"accountMembers\": [] } }, \"totalDueTodayWithoutDiscount\": 0.0, \"subTotalDueTodayWithoutDiscount\": 0.0, \"totalPerksSavings\": \"0.0\" }, \"lineDetails\": { \"lineInfo\": [ { \"isCommonPDP\": false, \"isTradeInIntentSelected\": false, \"multiLineSeqNumber\": 1, \"lineActivityType\": \"AAL_5G\", \"totalDueToday\": 0.0, \"totalDueTodayWithoutTax\": 0.0, \"totalDueTodayWithoutTaxWithoutDiscount\": 0.0, \"totalDueMonthly\": 0.0, \"mobileNumber\": \"7576136076\", \"showGlobalChoiceOffer\": false, \"serviceInfo\": { \"serviceAddress\": { \"addressLine1\": \"330 HARBOR POINTE CT APT 408\", \"addressLine2\": \"\", \"zipCode\": \"23523\", \"zipCode4\": \"2249\", \"firstName\": \"DON\", \"lastName\": \"MANNING\", \"city\": \"NORFOLK\", \"state\": \"VA\" }, \"comparePlan\": false, \"primaryUserInfo\": { \"firstName\": \"DON\", \"lastName\": \"MANNING\", \"address\": { \"firmName\": \"\", \"apartmentNo\": \"408\", \"type\": \"CT\", \"streetNumber\": \"330\", \"streetName\": \"HARBOR POINTE\", \"addressLine2\": \"\", \"addressLine1\": \"330 HARBOR POINTE CT APT 408\", \"poBoxNo\": \"\", \"ruralRouteNo\": \"\", \"ruralDelNo\": \"\", \"city\": \"NORFOLK\", \"state\": \"VA\", \"zipCode\": \"23523\", \"zipCode4\": \"2249\", \"county\": \"\", \"countryCode\": \"US\", \"fipsCode\": \"5171057000\", \"firstName\": \"DON\", \"lastName\": \"MANNING\", \"emailId\": \"TVLITVTIZEVH68252@VZW.COM\", \"phoneNumber\": \"4541854933\", \"streetType\": \"CT\", \"streetDirection\": \"\" }, \"isValidAddress\": true, \"bsnsName\": \"\", \"emailId\": \"TVLITVTIZEVH68252@VZW.COM\", \"midInitials\": \"E\" }, \"mtn\": \"7576136076\", \"min\": \"5754367277\", \"isSharePlanAdded\": false, \"mea\": \"VNO\", \"isE911AddressValidated\": false, \"kidsPlanParentMtn\": false, \"mcsSubscription\": [], \"fiveGUpSell\": false, \"e911AddressSameAsServiceAddress\": false, \"unpairedGrantor\": false, \"totalAddedFeaturesPrice\": \"0.0\" }, \"itemsInfo\": [ { \"attention\": \"DON MANNING\", \"shipping\": { \"address\": { \"firmName\": \"\", \"apartmentNo\": \"408\", \"type\": \"R\", \"streetNumber\": \"330\", \"streetName\": \"HARBOR POINTE\", \"addressLine2\": \"\", \"addressLine1\": \"330 HARBOR POINTE CT APT 408\", \"poBoxNo\": \"\", \"ruralRouteNo\": \"\", \"ruralDelNo\": \"\", \"city\": \"NORFOLK\", \"state\": \"VA\", \"zipCode\": \"23523\", \"zipCode4\": \"2249\", \"county\": \"\", \"countryCode\": \"\", \"fipsCode\": \"5171057000\", \"firstName\": \"DON\", \"lastName\": \"MANNING\", \"emailId\": \"TVLITVTIZEVH68252@VZW.COM\", \"phoneNumber\": \"4541854933\", \"streetType\": \"CT\", \"streetDirection\": \"\" }, \"bsnsName\": \"\", \"cbrPhone\": \"4541854933\", \"firstName\": \"DON\", \"lastName\": \"MANNING\", \"midInitials\": \"E\", \"isUseUnVerifiedAddress\": false, \"isValidAddress\": false, \"email\": \"TVLITVTIZEVH68252@VZW.COM\", \"shipToCustomerAddress\": false }, \"fipsCode\": \"5171057000\", \"itemCount\": 0, \"itemTabSeqNum\": 0, \"isPromoSelected\": false, \"isTradeInSelected\": false } ], \"assignMTNIndicator\": \"Y\", \"mtnDetails\": { \"dummyMTNForDomain\": \"7215894301\", \"lineNumber\": \"newLine1\", \"minNumber\": \"5754367277\", \"mobileNumber\": \"7576136076\", \"assignMTNTimestamp\": \"2024-07-22T10:57:46.143777944-04:00[US/Eastern]\", \"npaNXX\": \"757613\" }, \"lineNumber\": \"newLine1\", \"fiveGToFourGDownGrade\": false, \"deviceTypeSelected\": \"5G Internet\", \"lineCreator\": \"7572158943\", \"lineRefundTotal\": 0.0, \"lineExchangeTotal\": 0.0, \"totalDueMonthlyBeforeCredit\": 0.0, \"sugAllowed\": false, \"totalDueAddOnMonthly\": 0.0, \"totalPriceOfPlanAndPerks\": \"0.0\", \"isCpe\": false, \"isLTEHomeLine\": false, \"isDevicePlanCompatible\": false, \"portinMtnAssignment\": false, \"impactedLine\": false, \"preOrBackOrder\": false, \"ispuItem\": false, \"ispuItemBYOD\": false, \"isModConnected\": false, \"modDevice\": false, \"byodCapable\": false, \"isCarLine\": false, \"buySimOnly\": false, \"broadBandInd\": false, \"ispuDownPaymentAdjstRequired\": false, \"ispuDownPaymentAmount\": 0.0, \"lineWithSkipMDN\": false, \"protectionNotRequired\": false } ], \"numOfAccessoryAndDeviceItemsInCart\": 0, \"totalEdgeUpAmount\": 0.0, \"totalEdgeBuyOutAmount\": 0.0, \"tradeInDetail\": {}, \"totalDownPaymentAmt\": 0.0, \"numOfLinesWithDevices\": 0, \"numofApprovedLines\": 0, \"rfexPayments\": [], \"numOfLines\": 1, \"numofLinesAAL\": 1, \"numofLinesEUP\": 0, \"payments\": [], \"lineSeq\": 0, \"vlcactivePhoneCount\": 0, \"fivegOrderind\": false, \"aceOrderCreated\": false, \"serviceLinesCreated\": false, \"aceItemsModified\": false, \"clnrOrderFlag\": false, \"broadbandInd\": false, \"acctMcsSubscription\": [], \"spendingLimitAmountExceededBy\": \"0.0\", \"numofAccessories\": 0, \"subAccountNBSInfo\": [], \"subAccountNbsDetails\": [], \"bagTax\": false, \"couponDetails\": [ {} ] }, \"refundOrderDetails\": { \"orderNum\": 0, \"totalDueToday\": \"0.0\", \"subTotalDueToday\": \"0.0\", \"totalTaxAmount\": \"0.0\", \"creditApplicationNum\": 0 }, \"accountEligibility\": false, \"displayCartValidationErrors\": true }, \"warningMessages\": [], \"basicORSmartPhoneExists\": false, \"fiveGDeviceORLTEHomeExists\": false, \"cartHasAccessories\": false, \"iscartHasVZHP\": false, \"orderPlaced\": false, \"validateAppointments\": false, \"validateCart\": false, \"redesignFlow\": false, \"newCustomer\": false, \"isLocalStoreOfferEnabled\": false }";
        CXPRetrieveCartDataVO cart = mapper.readValue(retrieveCartString, CXPRetrieveCartDataVO.class);

        CartRedisData data = new CartRedisData();
        data.setRepRole("CSSCREP");
        data.setRetrieveCart(cart);
        data.setIsHomeSales("true");
        FiveGAddressRedisData address = new FiveGAddressRedisData();
        address.setAddressRequest(new FiveGAddress());
        address.getAddressRequest().setFiveGHomeQualified(false);
        data.setHomeSalesAddress(new HomeSalesAddress());
        data.getHomeSalesAddress().setCBandQualified(true);
        CartAddDeviceUtil.checkAndUpdateNetworkBdType(data, request, address);

        data.getHomeSalesAddress().setCBandQualified(false);
        address.getAddressRequest().setCBandQualified(false);
        data.getHomeSalesAddress().setFiveGHomeQualified(true);
        data.getHomeSalesAddress().setCBandQualified(false);
        request.getData().getLines().get(0).getDevice().setNetworkBandwidthType("");
        CartAddDeviceUtil.checkAndUpdateNetworkBdType(data, request, address);

        address.setAddressRequest(null);
        CartAddDeviceUtil.checkAndUpdateNetworkBdType(data, request, address);
        address.setAddressRequest(new FiveGAddress());
        address.getAddressRequest().setLTEQualified(false);
        CartAddDeviceUtil.checkAndUpdateNetworkBdType(data, request, address);
        address.getAddressRequest().setLTEQualified(true);
        CartAddDeviceUtil.checkAndUpdateNetworkBdType(data, request, address);

        address.setAddressRequest(null);
        data.getHomeSalesAddress().setLTEQualified(true);
        CartAddDeviceUtil.checkAndUpdateNetworkBdType(data, request, address);
        data.getHomeSalesAddress().setLTEQualified(false);
        CartAddDeviceUtil.checkAndUpdateNetworkBdType(data, request, address);
        data.setHomeSalesAddress(null);
        CartAddDeviceUtil.checkAndUpdateNetworkBdType(data, request, address);

    }
    @Test
    public void pegaResponseEmptyTest() throws JsonMappingException, JsonProcessingException {
        CartAddDeviceUtil.pegaResponseEmptyOrNot(null);
        assertFalse(CartAddDeviceUtil.pegaResponseEmptyOrNot(null));

        AddDeviceUIResponse response = new AddDeviceUIResponse();
        response.setServiceBody(null);
        assertFalse(CartAddDeviceUtil.pegaResponseEmptyOrNot(response));

        AddDeviceServiceBody serviceBody = new AddDeviceServiceBody();
        serviceBody.setServiceResponse(null);
        response.setServiceBody(serviceBody);
        assertFalse(CartAddDeviceUtil.pegaResponseEmptyOrNot(response));

        AddDeviceServiceResponse response1 = new AddDeviceServiceResponse();
        response1.setContext(null);
        response.getServiceBody().setServiceResponse(response1);
        assertFalse(CartAddDeviceUtil.pegaResponseEmptyOrNot(response));

        AddDeviceContext context = new AddDeviceContext();
        context.setCartInfo(null);
        response.getServiceBody().getServiceResponse().setContext(context);
        assertFalse(CartAddDeviceUtil.pegaResponseEmptyOrNot(response));

    }

    }
