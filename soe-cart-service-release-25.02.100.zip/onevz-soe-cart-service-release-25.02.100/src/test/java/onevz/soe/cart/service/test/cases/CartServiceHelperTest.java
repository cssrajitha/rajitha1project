package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.cradle.vo.CradleResponse;
import onevz.aem.errorhandling.aem.model.CreditErrorContent;
import onevz.cxp.feature.util.FeatureFlag;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper2;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper3;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelperAddPlan;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper2;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.helper.*;
import onevz.soe.cart.model.common.CartServiceCartInfo;
import onevz.soe.cart.model.common.ConflictedSPOs;
import onevz.soe.cart.model.createLine.HomeSalesAddress;
import onevz.soe.cart.model.retrieveCart.CXPLineInfo;
import onevz.soe.cart.model.retrieveCart.MtnDetails;
import onevz.soe.cart.nbx.NBXFeedbackService;
import onevz.soe.cart.requests.MyOffersCXPRequest;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.cradle.CradleAllocator;
import onevz.soe.customerprofile.response.CustomerProfileResponse;
import onevz.soe.errorhandling.aem.model.AEMCreditExceptionResponse;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;


@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { CartServiceTestConfig.class })
public class CartServiceHelperTest {

    @Autowired
    private UpdateCartHelper helper;

    @MockBean
    private CartServiceCxpHelper cxpHelper;

    @MockBean
    private CartServiceCxpHelper2 cxpHelper2;

    @MockBean
    private CartServiceCXPServices cxpService;

    @MockBean
    private CartServiceBpmHelperAddPlan bpmHelperAddPlan;

    @MockBean
    FeatureFlag featureFlag;

    @MockBean
    private CartServiceBpmHelper2 bpmHelper2;

    @MockBean
    private CartServiceBpmHelper3 bpmHelper3;

    @MockBean
    private RedisHelper redisHelper;

    @MockBean
    private RedisHelper2 redisHelper2;

    @MockBean
    private RedisHelper3 redisHelper3;

    @Autowired
    private ObjectMapper mapper;

    @MockBean
    private NBXFeedbackService nbxService;

    @MockBean
    private CradleAllocator cradleAllocator;

    @Autowired
    SourceFileReaderUtil sourceFileReaderUtil;

    @MockBean
    OmniDLHelper omniDLHelper;
    @MockBean
    FeatureFlagHelper featureFlagHelper;

    @Value("${onevz.soe.cart.test.fileLocation}")
    private String testFileLocation;

    List<String> preorderWhitelistMtnsList = new ArrayList<>();

    UpdateCartHelper csh = new UpdateCartHelper("1234567890,9087654321","Smartphones,Connected Devices,Tablets");

    @Test
    public void updateUserInfoHelperTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateUserInfoUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateUserInfoUIResponse.json", testFileLocation);
        UpdateUserInfoUIRequest sampleRequest = null;
        UpdateUserInfoUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRequest = mapper.readValue(sampleRequestString, UpdateUserInfoUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, UpdateUserInfoUIResponse.class);
        Mono<UpdateUserInfoUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(cxpHelper.updateUserInfo(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateUserInfoUIResponse expectedResponse = sampleResponse;
        Mono<UpdateUserInfoUIResponse> response = helper.updateUserInfo(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp.getData())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void paperlessBillingHelperTest() throws IOException, SOEHTTPException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/PaperlessBillingUIResponse.json", testFileLocation);
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/PaperlessBillingUIRequest.json", testFileLocation);
        PaperlessBillingUIRequest sampleRequest = null;
        PaperlessBillingUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRequest = mapper.readValue(sampleRequestString, PaperlessBillingUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, PaperlessBillingUIResponse.class);
        Mono<PaperlessBillingUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(cxpHelper.paperlessBilling(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        PaperlessBillingUIResponse expectedResponse = sampleResponse;
        Mono<PaperlessBillingUIResponse> response = helper.paperlessBilling(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp.getData())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }


    @Test
    public void updateTradeinTypeHelperTest() throws IOException, SOEHTTPException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateTradeinTypeUIResponse.json", testFileLocation);
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateTradeinTypeUIRequest.json", testFileLocation);
        UpdateTradeinTypeUIRequest sampleRequest = null;
        UpdateTradeinTypeUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRequest = mapper.readValue(sampleRequestString, UpdateTradeinTypeUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, UpdateTradeinTypeUIResponse.class);
        Mono<UpdateTradeinTypeUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(cxpHelper2.updateTradeinType(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateTradeinTypeUIResponse expectedResponse = sampleResponse;
        Mono<UpdateTradeinTypeUIResponse> response = helper.updateTradeinType(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp.getData())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void addPlanforNSETest() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIResponse.json", testFileLocation);
        String sampleRetrieveCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RetrieveCartCXPResponse.json", testFileLocation);
        AddPlanUIRequest UIRequest = new AddPlanUIRequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
        AddPlanUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData3.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleResponse = mapper.readValue(sampleResponseString, AddPlanUIResponse.class);
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(omniDLHelper.upsertPlanTaggingValueToRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(bpmHelperAddPlan.addPlan(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just("false"));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(new MyOfferETRRedisData()));
        when(featureFlag.isFeatureEnabled(anyString(), anyString(), anyString(), anyBoolean())).thenReturn(Mono.just(Boolean.TRUE));
        RetrieveCartCXPResponse sampleCXPResponse = null;
        sampleCXPResponse = mapper.readValue(sampleRetrieveCartResponseString, RetrieveCartCXPResponse.class);
        Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
        AddPlanUIResponse expectedResponse = sampleResponse;
        Mono<AddPlanUIResponse> response = helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void addPlanforTYSTest() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIRequest14.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIResponse.json", testFileLocation);
        String sampleRetrieveCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RetrieveCartCXPResponse.json", testFileLocation);
        AddPlanUIRequest UIRequest = new AddPlanUIRequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
        AddPlanUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData155.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setPlanTaggingDetails(new ArrayList<>());
        sampleResponse = mapper.readValue(sampleResponseString, AddPlanUIResponse.class);
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(omniDLHelper.upsertPlanTaggingValueToRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(bpmHelperAddPlan.addPlan(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just("false"));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(new MyOfferETRRedisData()));
        when(featureFlag.isFeatureEnabled(anyString(), anyString(), anyString(), anyBoolean())).thenReturn(Mono.just(Boolean.TRUE));
        RetrieveCartCXPResponse sampleCXPResponse = null;
        sampleCXPResponse = mapper.readValue(sampleRetrieveCartResponseString, RetrieveCartCXPResponse.class);
        Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
        AddPlanUIResponse expectedResponse = sampleResponse;
        Mono<AddPlanUIResponse> response = helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void addPlanHelperTest() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIResponse.json", testFileLocation);
        String sampleRetrieveCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RetrieveCartCXPResponse.json", testFileLocation);;
        AddPlanUIRequest UIRequest = new AddPlanUIRequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
        AddPlanUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);;
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        List<PlanTaggingDetails> list= new ArrayList<>();
        PlanTaggingDetails planTaggingDetails=new PlanTaggingDetails();
        planTaggingDetails.setPath("path");
        planTaggingDetails.setGroup(9);
        planTaggingDetails.setAction("action");
        planTaggingDetails.setMtn("mtn");
        list.add(planTaggingDetails);
        sampleRedisData.setPlanTaggingDetails(list);
        sampleResponse = mapper.readValue(sampleResponseString, AddPlanUIResponse.class);
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(omniDLHelper.upsertPlanTaggingValueToRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(bpmHelperAddPlan.addPlan(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just("false"));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(new MyOfferETRRedisData()));
        when(featureFlag.isFeatureEnabled(anyString(), anyString(), anyString(), anyBoolean())).thenReturn(Mono.just(Boolean.TRUE));
        RetrieveCartCXPResponse sampleCXPResponse = null;
        sampleCXPResponse = mapper.readValue(sampleRetrieveCartResponseString, RetrieveCartCXPResponse.class);
        Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
        AddPlanUIResponse expectedResponse = sampleResponse;
        Mono<AddPlanUIResponse> response = helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void addFeatureHelperTest() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddFeaturesUIResponse.json", testFileLocation);;
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddFeaturesUIRequest.json", testFileLocation);
        AddFeaturesUIRequest sampleUIRequest = null;
        AddFeaturesUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData4.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, AddFeaturesUIResponse.class);
        AddFeaturesUIResponse expectedResponse = sampleResponse;
        when(redisHelper.getAddFeaturesRequest()).thenReturn(Mono.just(sampleUIRequest));
        when(bpmHelper2.addFeatures(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        Mono<AddFeaturesUIResponse> response = helper.addFeatures(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void pastDuesHelperTest() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/PastDuesUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/PastDuesUIRequest.json", testFileLocation);
        PastDuesUIRequest sampleUIRequest = null;
        PastDuesUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, PastDuesUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, PastDuesUIResponse.class);
        PastDuesUIResponse expectedResponse = sampleResponse;
        when(bpmHelper2.pastDues(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<PastDuesUIResponse> response = helper.pastDues(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void removeLinesHelperTest() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse.json", testFileLocation);
        RemoveLinesUIRequest sampleUIRequest = null;
        RemoveLinesUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, RemoveLinesUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, RemoveLinesUIResponse.class);
        String nbxString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackResponse.json", testFileLocation);
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        when(nbxService.nbxFeedbackCall(Mockito.any())).thenReturn(Mono.just(nbxRes));
        String bvpStr = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BVPRedisData.json", testFileLocation);
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        String validateCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse.json", testFileLocation);
        ValidateCartUIResponse validateCartResponse = mapper.readValue(validateCartResponseString, ValidateCartUIResponse.class);
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartResponse));
        when(bpmHelper2.removeLines(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(new BVPRedisData()));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just(new String()));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        RemoveLinesUIResponse expectedResponse = sampleResponse;
        Mono<RemoveLinesUIResponse> response = helper.removeLines(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void removeLinesHelperforNSETest() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        RemoveLinesUIRequest sampleUIRequest = null;
        RemoveLinesUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData5.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, RemoveLinesUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, RemoveLinesUIResponse.class);
        String nbxString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackResponse.json", testFileLocation);
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        when(nbxService.nbxFeedbackCall(Mockito.any())).thenReturn(Mono.just(nbxRes));
        String bvpStr = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BVPRedisData.json", testFileLocation);
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        String validateCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse.json", testFileLocation);
        ValidateCartUIResponse validateCartResponse = mapper.readValue(validateCartResponseString, ValidateCartUIResponse.class);
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartResponse));
        when(bpmHelper2.removeLines(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(new BVPRedisData()));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just(new String()));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        RemoveLinesUIResponse expectedResponse = sampleResponse;
        Mono<RemoveLinesUIResponse> response = helper.removeLines(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }





    @Test
    public void initiateCheckoutHelperTest() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse.json", testFileLocation);
        InitiateCheckoutUIResponse sampleResponse = null;
        InitiateCheckoutUIRequest sampleUIRequest = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        CreditErrorContent sampleCreditData = new CreditErrorContent();
        List<AEMCreditExceptionResponse> creditHold = new ArrayList<>();
        AEMCreditExceptionResponse e = new AEMCreditExceptionResponse();
        e.setCancelOrderBtnLabel("Cancel Order");
        e.setCancelOrderBtnUrl("https://www.verizon.com/sales/digital/smartphones.html");
        creditHold.add(e);
        sampleCreditData.setCreditHold(creditHold);
        when(bpmHelper2.validateOrder(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.readCreditException()).thenReturn(Mono.just(new CreditErrorContent()));
        when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(true));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        when(redisHelper2.upsertCreditCheckFailureCountIntoRedis(Mockito.anyInt(), Mockito.any())).thenReturn(Mono.just(true));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        Mono<InitiateCheckoutUIResponse> response = helper.validateOrder(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }
    @Test
    public void updateCartHelperCreditHoldTest() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse1.json", testFileLocation);
        String sampleCrediErrorString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CreditErrorContent.json", testFileLocation);

        InitiateCheckoutUIResponse sampleResponse = null;
        InitiateCheckoutUIRequest sampleUIRequest = null;
        CreditErrorContent samleCreditErrorResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        samleCreditErrorResponse = mapper.readValue(sampleCrediErrorString, CreditErrorContent.class);
        when(bpmHelper2.validateOrder(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.readCreditException()).thenReturn(Mono.just(samleCreditErrorResponse));
        when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(true));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        when(redisHelper2.upsertCreditCheckFailureCountIntoRedis(Mockito.anyInt(), Mockito.any())).thenReturn(Mono.just(true));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        Mono<InitiateCheckoutUIResponse> response = helper.validateOrder(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateCartHelperCreditHoldNegativeTest() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse1.json", testFileLocation);
        String sampleCrediErrorString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CreditErrorContent.json", testFileLocation);

        InitiateCheckoutUIResponse sampleResponse = null;
        InitiateCheckoutUIRequest sampleUIRequest = null;
        CreditErrorContent samleCreditErrorResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        samleCreditErrorResponse = mapper.readValue(sampleCrediErrorString, CreditErrorContent.class);
        when(bpmHelper2.validateOrder(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.readCreditException()).thenReturn(Mono.just(samleCreditErrorResponse));
        when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(false));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        when(redisHelper2.upsertCreditCheckFailureCountIntoRedis(Mockito.anyInt(), Mockito.any())).thenReturn(Mono.just(true));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        Mono<InitiateCheckoutUIResponse> response = helper.validateOrder(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }
    @Test
    public void updateCartHelperCreditHoldNegative2Test() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse1.json", testFileLocation);
        String sampleCrediErrorString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CreditErrorContent1.json", testFileLocation);

        InitiateCheckoutUIResponse sampleResponse = null;
        InitiateCheckoutUIRequest sampleUIRequest = null;
        CreditErrorContent samleCreditErrorResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        samleCreditErrorResponse = mapper.readValue(sampleCrediErrorString, CreditErrorContent.class);
        when(bpmHelper2.validateOrder(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.readCreditException()).thenReturn(Mono.just(samleCreditErrorResponse));
        when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(true));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        when(redisHelper2.upsertCreditCheckFailureCountIntoRedis(Mockito.anyInt(), Mockito.any())).thenReturn(Mono.just(true));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        Mono<InitiateCheckoutUIResponse> response = helper.validateOrder(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
    }
    @Test
    public void addDownPaymentHelperTest() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddDownPaymentUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DownPaymentUIRequest.json", testFileLocation);
        DownPaymentUIRequest sampleUIRequest = null;
        AddDownPaymentUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, DownPaymentUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, AddDownPaymentUIResponse.class);
        when(bpmHelper2.addDownPayment(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        AddDownPaymentUIResponse expectedResponse = sampleResponse;
        Mono<AddDownPaymentUIResponse> response = helper.addDownPayment(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();

    }

    @Test
    public void addEdgeUpHelperTest() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEdgeupUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEdgeupUIRequest.json", testFileLocation);
        UpdateEdgeupUIRequest sampleUIRequest = null;
        UpdateEdgeupUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateEdgeupUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, UpdateEdgeupUIResponse.class);
        when(bpmHelper2.addEdgeup(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateEdgeupUIResponse expectedResponse = sampleResponse;
        Mono<UpdateEdgeupUIResponse> response = helper.addEdgeup(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();

    }

    @Test
    public void addBuyoutHelperTest() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddBuyoutUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddBuyoutUIRequest.json", testFileLocation);
        AddBuyoutUIRequest sampleUIRequest = null;
        AddBuyoutUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, AddBuyoutUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, AddBuyoutUIResponse.class);
        when(bpmHelper2.addBuyout(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        AddBuyoutUIResponse expectedResponse = sampleResponse;
        Mono<AddBuyoutUIResponse> response = helper.addBuyout(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void createLineHelperTest() throws IOException {
        String requestFile = "MockCreateLineHelperTestRequest.json";
        String responseFile = "MockCreateLineHelperTestResponse.json";
        String sampleUIRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);

        CreateLineUIRequest sampleUIRequest = null;
        CreateLineUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, CreateLineUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, CreateLineUIResponse.class);
        when(bpmHelper2.createLine(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper3.getHomeSalesAddressFromRedis()).thenReturn(Mono.just(new HomeSalesAddress()));
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CradleResponse()));
        when(cradleAllocator.getDataMap()).thenReturn(Mono.just(new HashMap<>()));
        CreateLineUIResponse expectedResponse = sampleResponse;
        when(redisHelper3.getDataFromSession(Mockito.any())).thenReturn(Mono.just(new HashMap<>()));
        when(featureFlag.isFeatureEnabled(anyString(), anyString(), anyString(), anyBoolean())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<CreateLineUIResponse> response = helper.createLine(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void addE911AddressHelperTest() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/E911AddressUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/E911AddressUIRequest.json", testFileLocation);
        E911AddressUIRequest sampleUIRequest = null;
        E911AddressUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData6.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, E911AddressUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, E911AddressUIResponse.class);
        when(bpmHelper2.addE911Address(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        E911AddressUIResponse expectedResponse = sampleResponse;
        Mono<E911AddressUIResponse> response = helper.addE911Address(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void effectiveDateOverrideHelperTest() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/EffectiveDateOverrideUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/EffectiveDateOverrideUIRequest.json", testFileLocation);
        EffectiveDateOverrideUIRequest sampleUIRequest = null;
        EffectiveDateOverrideUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, EffectiveDateOverrideUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, EffectiveDateOverrideUIResponse.class);
        when(bpmHelper2.effectiveDateOverride(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        EffectiveDateOverrideUIResponse expectedResponse = sampleResponse;
        Mono<EffectiveDateOverrideUIResponse> response = helper.effectiveDateOverride(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void addServiceAddressHelperTest() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/E911AddressUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ServiceAddressUIRequest.json", testFileLocation);
        ServiceAddressUIRequest sampleUIRequest = null;
        ServiceAddressUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, ServiceAddressUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, ServiceAddressUIResponse.class);
        when(bpmHelper2.addServiceAddress(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        ServiceAddressUIResponse expectedResponse = sampleResponse;
        Mono<ServiceAddressUIResponse> response = helper.addServiceAddress(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }



    @Test
    public void updateDeviceSimIdHelperTest() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateDeviceSIMIdUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateDeviceSIMIdUIResponse.json", testFileLocation);
        UpdateDeviceSIMIdUIRequest sampleUIRequest = null;
        UpdateDeviceSIMIdUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateDeviceSIMIdUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, UpdateDeviceSIMIdUIResponse.class);
        when(bpmHelper3.updateDeviceSimId(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateDeviceSIMIdUIResponse expectedResponse = sampleResponse;
        Mono<UpdateDeviceSIMIdUIResponse> response = helper.updateDeviceSIMId(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void insCredDPHelperTest() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InstantCreditDownPaymentUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InstantCreditDownPaymentUIResponse.json", testFileLocation);
        InstantCreditDownPaymentUIResponse sampleResponse = null;
        InstantCreditDownPaymentUIRequest sampleUIRequest = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, InstantCreditDownPaymentUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, InstantCreditDownPaymentUIResponse.class);
        when(bpmHelper2.addInstantCreditDownPayment(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        InstantCreditDownPaymentUIResponse expectedResponse = sampleResponse;
        Mono<InstantCreditDownPaymentUIResponse> response = helper.addInstantCreditDownPayment(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateBarcodeHelperTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData7.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setCreditAppNum("1234567890");
        UpdateBarcodeUIRequest sampleRequest = mapper.readValue(sampleRequestString, UpdateBarcodeUIRequest.class);
        UpdateBarcodeUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateBarcodeUIResponse.class);
        Mono<UpdateBarcodeUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse1.json", testFileLocation);
        ValidateCartUIResponse sampleValidateResponse = null;
        sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(bpmHelper3.updateBarcode(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.upsertValueInRedis(Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        UpdateBarcodeUIResponse expectedResponse = sampleResponse;
        Mono<UpdateBarcodeUIResponse> response = helper.updateBarcode(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateBarcodeHelperTestForNSE() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData8.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        UpdateBarcodeUIRequest sampleRequest = mapper.readValue(sampleRequestString, UpdateBarcodeUIRequest.class);
        UpdateBarcodeUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateBarcodeUIResponse.class);
        Mono<UpdateBarcodeUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse1.json", testFileLocation);
        ValidateCartUIResponse sampleValidateResponse = null;
        sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(bpmHelper3.updateBarcode(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.upsertValueInRedis(Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        Mono<UpdateBarcodeUIResponse> response = helper.updateBarcode(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(sampleResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateBarcodeHelperForExceededPromocountNSE() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIResponse1.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData9.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        UpdateBarcodeUIRequest sampleRequest = mapper.readValue(sampleRequestString, UpdateBarcodeUIRequest.class);
        UpdateBarcodeUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateBarcodeUIResponse.class);
        Mono<UpdateBarcodeUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse1.json", testFileLocation);
        ValidateCartUIResponse sampleValidateResponse = null;
        sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(bpmHelper3.updateBarcode(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.upsertValueInRedis(Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        Mono<UpdateBarcodeUIResponse> response = helper.updateBarcode(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp.getErrors())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals("Promo Code usage exceeds maximum Count", resp.getErrors().get(0).getMessage())).expectComplete()
                .verify();
    }

    @Test
    public void updateSellerPriceNewHelperTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIRequestNew.json", testFileLocation);
        String sampleResponseString =sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIResponseNew.json", testFileLocation);
        UpdateSellerPriceUIRequestNew sampleRequest = null;
        UpdateSellerPriceUIResponseNew sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setCreditAppNum("12345678");
        sampleRequest = mapper.readValue(sampleRequestString, UpdateSellerPriceUIRequestNew.class);
        sampleRequest.setChannelId("VZW-ACSS");
        sampleResponse = mapper.readValue(sampleResponseString, UpdateSellerPriceUIResponseNew.class);
        Mono<UpdateSellerPriceUIResponseNew> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper3.updateSellerPrice(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateSellerPriceUIResponseNew expectedResponse = sampleResponse;
        Mono<UpdateSellerPriceUIResponseNew> response = helper.updateSellerPriceNew(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void addBillingAddressHelperTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BillingAddressUIRequest.json", testFileLocation);
        String sampleResponseString =sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIResponseNew.json", testFileLocation);
        BillingAddressUIRequest sampleRequest = null;
        BillingAddressUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRequest = mapper.readValue(sampleRequestString, BillingAddressUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, BillingAddressUIResponse.class);
        Mono<BillingAddressUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.addBillingAddress(sampleRequest)).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        BillingAddressUIResponse expectedResponse = sampleResponse;
        Mono<BillingAddressUIResponse> response = helper.addBillingAddress(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void resumeAndContinueHelperTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BillingAddressUIRequest.json", testFileLocation);
        String sampleResponseString =sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIResponseNew.json", testFileLocation);
        ResumeAndContinueUIRequest sampleRequest = null;
        ResumeAndContinueUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRequest = mapper.readValue(sampleRequestString, ResumeAndContinueUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, ResumeAndContinueUIResponse.class);
        Mono<ResumeAndContinueUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper3.resumeAndContinue(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        ResumeAndContinueUIResponse expectedResponse = sampleResponse;
        Mono<ResumeAndContinueUIResponse> response = helper.resumeAndContinue(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateAccountPinHelperTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AccountPinUIRequest.json", testFileLocation);
        String sampleResponseString =sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIResponseNew.json", testFileLocation);
        AccountPinUIRequest sampleRequest = null;
        AccountPinUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData10.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRequest = mapper.readValue(sampleRequestString, AccountPinUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, AccountPinUIResponse.class);
        Mono<AccountPinUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper3.updateAccountPin(sampleRequest)).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        AccountPinUIResponse expectedResponse = sampleResponse;
        Mono<AccountPinUIResponse> response = helper.updateAccountPin(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateMyOffersHelperTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/MyOffersCXPRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/MyOffersCXPResponse.json", testFileLocation);
        MyOffersCXPRequest sampleRequest = null;
        MyOffersCXPResponse sampleResponse = null;
        sampleRequest = mapper.readValue(sampleRequestString, MyOffersCXPRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, MyOffersCXPResponse.class);
        Mono<MyOffersCXPResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(cxpHelper2.updateMyOffers(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper2.getRTDOfferDataFromRedis()).thenReturn(Mono.just(new RTDRedisData()));
        when(redisHelper2.getCartIdFromRedis()).thenReturn(Mono.just(new String()));
        MyOffersCXPResponse expectedResponse = sampleResponse;
        Mono<MyOffersCXPResponse> response = helper.updateMyOffers("assisted");
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void addZipcodeHelperTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/MyOffersCXPRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddZipcodeRedisData.json", testFileLocation);
        AddZipCodeUIRequest sampleRequest = null;
        AddZipcodeRedisData sampleResponse = null;
        sampleRequest = mapper.readValue(sampleRequestString, AddZipCodeUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, AddZipcodeRedisData.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData10.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<AddZipcodeRedisData> sampleResponseMono = Mono.just(sampleResponse);
        when(cxpHelper2.addZipcode(sampleRequest)).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        AddZipcodeRedisData expectedResponse = sampleResponse;
        Mono<AddZipcodeRedisData> response = helper.addZipcode(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void getPairedDevicesHelperTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/MyOffersCXPRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddZipcodeRedisData.json", testFileLocation);
        GetPairedDevicesUIRequest sampleRequest = null;
        GetPairedDevicesUIResponse sampleResponse = null;
        sampleRequest = mapper.readValue(sampleRequestString, GetPairedDevicesUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, GetPairedDevicesUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData10.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<GetPairedDevicesUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(cxpHelper2.getPairedDevices(sampleRequest)).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        GetPairedDevicesUIResponse expectedResponse = sampleResponse;
        Mono<GetPairedDevicesUIResponse> response = helper.getPairedDevices(sampleRequest,"assisted");
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateVzccNBXInfoHelperTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/MyOffersCXPRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddZipcodeRedisData.json", testFileLocation);
        UpdateVzccNBXInfoUIRequest sampleRequest = null;
        UpdateVzccNBXInfoUIResponse sampleResponse = null;
        sampleRequest = mapper.readValue(sampleRequestString, UpdateVzccNBXInfoUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, UpdateVzccNBXInfoUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData10.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setIntendType("NSE");
        Mono<UpdateVzccNBXInfoUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(cxpHelper2.updateVzccNBXInfo(sampleRequest)).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateVzccNBXInfoUIResponse expectedResponse = sampleResponse;
        Mono<UpdateVzccNBXInfoUIResponse> response = helper.updateVzccNBXInfo(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void getCustomerInfoHelperTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/MyOffersCXPRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddZipcodeRedisData.json", testFileLocation);
        CreateCaseAndGetCustomerInfoUIRequest sampleRequest = null;
        CreateCaseAndGetCustomerInfoUIResponse sampleResponse = null;
        sampleRequest = mapper.readValue(sampleRequestString, CreateCaseAndGetCustomerInfoUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, CreateCaseAndGetCustomerInfoUIResponse.class);
        Mono<CreateCaseAndGetCustomerInfoUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(cxpHelper2.getCustomerInfo(sampleRequest," ")).thenReturn(sampleResponseMono);
        CreateCaseAndGetCustomerInfoUIResponse expectedResponse = sampleResponse;
        Mono<CreateCaseAndGetCustomerInfoUIResponse> response = helper.getCustomerInfo(sampleRequest," ");
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void populateSPOsHelperTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartServiceCartInfo.json", testFileLocation);
        String sampleResponseString =sourceFileReaderUtil.readFile("data/cartServiceHelperTest/GenericResponse.json", testFileLocation);
        CartServiceCartInfo sampleRequest = null;
        GenericResponse sampleResponse = null;
        sampleRequest = mapper.readValue(sampleRequestString, CartServiceCartInfo.class);
        sampleResponse = mapper.readValue(sampleResponseString, GenericResponse.class);
        when(redisHelper.updateSPOsIntoRedis(new ConflictedSPOs())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> response = helper.populateSPOs(sampleRequest,sampleResponse);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void populateHumWifiConflictedSFosHelperTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/MyOffersCXPRequest.json", testFileLocation);
        String sampleResponseString =sourceFileReaderUtil.readFile("data/cartServiceHelperTest/GenericResponse.json", testFileLocation);
        CartServiceCartInfo sampleRequest = null;
        GenericResponse sampleResponse = null;
        sampleRequest = mapper.readValue(sampleRequestString, CartServiceCartInfo.class);
        sampleResponse = mapper.readValue(sampleResponseString, GenericResponse.class);
        when(redisHelper.updateSPOsIntoRedis(new ConflictedSPOs())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> response = helper.populateHumWifiConflictedSFos(sampleRequest,sampleResponse);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void populateProtectionVersionHelperTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddFeaturesUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/GenericResponse.json", testFileLocation);
        AddFeaturesUIRequest sampleRequest = null;
        GenericResponse sampleResponse = null;
        sampleRequest = mapper.readValue(sampleRequestString, AddFeaturesUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, GenericResponse.class);
        when(redisHelper.updateProtectionVersionInRedis(" ")).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> response = helper.populateProtectionVersion(sampleRequest,sampleResponse);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void macAddressHelperTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/MyOffersCXPRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/MyOffersCXPResponse.json", testFileLocation);
        MacAddressUIRequest sampleRequest = null;
        MacAddressUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRequest = mapper.readValue(sampleRequestString, MacAddressUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, MacAddressUIResponse.class);
        Mono<MacAddressUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(cxpHelper2.updateMacAddress(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        MacAddressUIResponse expectedResponse = sampleResponse;
        Mono<MacAddressUIResponse> response = helper.updateMacAddress(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void assignMTNHelperTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AssignMtnUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AssignMtnUIResponse.json", testFileLocation);
        AssignMtnUIRequest sampleUIRequest = null;
        AssignMtnUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleRequestString, AssignMtnUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, AssignMtnUIResponse.class);
        Mono<AssignMtnUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.assignMtn(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CartRedisData()));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(new FiveGAddressRedisData()));
        AssignMtnUIResponse expectedResponse = sampleResponse;
        Mono<AssignMtnUIResponse> response = helper.assignMtn(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void calculateMultiLineTaxForCartHelperTest() throws IOException, SOEHTTPException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CalculateMultilineTaxUIRequest.json", testFileLocation);
        String sampleUIresponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CalculateMultilineTaxUIResponse.json", testFileLocation);
        CalculateMultilineTaxUIRequest sampleRequest = mapper.readValue(sampleUIRequestString, CalculateMultilineTaxUIRequest.class);
        CalculateMultilineTaxUIResponse sampleResponse = mapper.readValue(sampleUIresponseString, CalculateMultilineTaxUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        String rcResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RetrieveCartUIResponse.json", testFileLocation);
        RetrieveCartUIResponse rcResponse = mapper.readValue(rcResponseString, RetrieveCartUIResponse.class);
        when(cxpHelper.retrieveCart(Mockito.any())).thenReturn(Mono.just(rcResponse));
        Mono<CalculateMultilineTaxUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(cxpHelper.calculateMultiLineTaxForCart(Mockito.any())).thenReturn(sampleResponseMono);
        Mono<CalculateMultilineTaxUIResponse> respMono = helper.calculateMultiLineTaxForCart(sampleRequest);
        StepVerifier.create(respMono).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

    }

    @Test
    public void deassignMTNHelperTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DeassignMtnUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DeassignMtnUIResponse.json", testFileLocation);
        DeassignMtnUIRequest sampleRequest = null;
        DeassignMtnUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRequest = mapper.readValue(sampleRequestString, DeassignMtnUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, DeassignMtnUIResponse.class);
        Mono<DeassignMtnUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.deassignMtn(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        DeassignMtnUIResponse expectedResponse = sampleResponse;
        Mono<DeassignMtnUIResponse> response = helper.deassignMtn(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void updatePurchaseOrderHelperTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdatePurchaseOrderUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdatePurchaseOrderUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        UpdatePurchaseOrderUIRequest sampleRequest = null;
        UpdatePurchaseOrderUIResponse sampleResponse = null;
        sampleRequest = mapper.readValue(sampleRequestString, UpdatePurchaseOrderUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, UpdatePurchaseOrderUIResponse.class);
        Mono<UpdatePurchaseOrderUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(cxpHelper2.updatePurchaseOrderNo(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdatePurchaseOrderUIResponse expectedResponse = sampleResponse;
        Mono<UpdatePurchaseOrderUIResponse> response = helper.updatePurchaseOrder(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void updatePurchaseOrderDoOnErrorHelperTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdatePurchaseOrderUIRequest.json", testFileLocation);
        UpdatePurchaseOrderUIRequest sampleRequest = null;
        sampleRequest = mapper.readValue(sampleRequestString, UpdatePurchaseOrderUIRequest.class);
        Mockito.doReturn(Mono.error(Exception::new)).when(cxpHelper2).updatePurchaseOrderNo(Mockito.any());
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        StepVerifier.create(helper.updatePurchaseOrder(sampleRequest)).verifyError();
    }

    @Test
    public void add5GBulkOrderHelperTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/Add5GBulkOrderUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/Add5GBulkOrderUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Add5GBulkOrderUIResponse responseServiceMono = new Add5GBulkOrderUIResponse();
        Add5GBulkOrderUIRequest UIRequest = new Add5GBulkOrderUIRequest();
        UIRequest = mapper.readValue(sampleRequestString, Add5GBulkOrderUIRequest.class);
        responseServiceMono = mapper.readValue(sampleResponseString, Add5GBulkOrderUIResponse.class);
        Mono<Add5GBulkOrderUIResponse> sampleResponseMono = Mono.just(responseServiceMono);
        when(bpmHelper2.add5GBulkOrder(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Add5GBulkOrderUIResponse expectedResponse = responseServiceMono;
        Mono<Add5GBulkOrderUIResponse> response = helper.add5GBulkOrder(UIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void numbershareHelperTest() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NumberShareUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NumberShareUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        NumberShareUIRequest UIRequest = mapper.readValue(sampleUIRequestString, NumberShareUIRequest.class);
        NumberShareUIResponse sampleResponse = mapper.readValue(sampleResponseString, NumberShareUIResponse.class);
        when(bpmHelper2.numberShare(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        NumberShareUIResponse expectedResponse = sampleResponse;
        Mono<NumberShareUIResponse> response = helper.numberShare(UIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }



    @Test
    public void giftPurchaseHelperTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/GiftPurchaseUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/GiftPurchaseUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        GiftPurchaseUIRequest UIRequest = mapper.readValue(sampleRequestString, GiftPurchaseUIRequest.class);
        GiftPurchaseUIResponse soeResponse = mapper.readValue(sampleResponseString, GiftPurchaseUIResponse.class);
        Mono<GiftPurchaseUIResponse> sampleResponseMono = Mono.just(soeResponse);
        when(cxpHelper2.giftPurchase(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<GiftPurchaseUIResponse> response = helper.giftPurchase(UIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

    }

    @Test
    public void revokeRebatesHelperTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RevokeRebatesUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RevokeRebatesUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        RevokeRebatesUIRequest UIRequest = mapper.readValue(sampleRequestString, RevokeRebatesUIRequest.class);
        RevokeRebatesUIResponse soeResponse = mapper.readValue(sampleResponseString, RevokeRebatesUIResponse.class);
        Mono<RevokeRebatesUIResponse> sampleResponseMono = Mono.just(soeResponse);
        when(bpmHelper2.revokeRebates(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<RevokeRebatesUIResponse> response = helper.revokeRebates(UIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

    }

    @Test
    public void updatePortInLaterHelperTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/PortinLaterUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/PortinLaterUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        PortinLaterUIRequest UIRequest = mapper.readValue(sampleRequestString, PortinLaterUIRequest.class);
        PortinLaterUIResponse soeResponse = mapper.readValue(sampleResponseString, PortinLaterUIResponse.class);
        Mono<PortinLaterUIResponse> sampleResponseMono = Mono.just(soeResponse);
        when(bpmHelper2.updatePortInLater(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<PortinLaterUIResponse> response = helper.updatePortInLater(UIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void voidOrderHelperTest() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/VoidOrderUIRequest.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/VoidOrderUIResponse.json", testFileLocation);
        VoidOrderUIRequest sampleUIRequest = null;
        VoidOrderUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, VoidOrderUIRequest.class);
        sampleResponse = mapper.readValue(sampleUIResponseString, VoidOrderUIResponse.class);
        when(bpmHelper2.voidOrder(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        VoidOrderUIResponse expectedResponse = sampleResponse;
        Mono<VoidOrderUIResponse> response = helper.voidOrder(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void ispuToDfillHelperTest() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/IspuToDfillUIRequest.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RetrieveURCForCartUIResponse.json", testFileLocation);
        IspuToDfillUIRequest sampleUIRequest = null;
        IspuToDfillUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, IspuToDfillUIRequest.class);
        sampleResponse = mapper.readValue(sampleUIResponseString, IspuToDfillUIResponse.class);
        when(bpmHelper2.ispuToDfill(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        IspuToDfillUIResponse expectedResponse = sampleResponse;
        Mono<IspuToDfillUIResponse> response = helper.ispuToDfill(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void retrieveURCForCartHelperTest() throws IOException {
        String requestString = "{\"cartMtnList\":[{\"mtn\":\"4106274520\",\"deviceSku\":\"MNF23LL/A\",\"reasonCodeType\":\"\"}]}";
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RetrieveURCForCartUIResponse.json", testFileLocation);
        RetrieveURCForCartUIRequest sampleUIRequest = null;
        RetrieveURCForCartUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(requestString, RetrieveURCForCartUIRequest.class);
        sampleResponse = mapper.readValue(sampleUIResponseString, RetrieveURCForCartUIResponse.class);
        when(cxpHelper.retrieveURCForCart(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.getCartIdFromRedis()).thenReturn(Mono.just(new String("12345")));
        RetrieveURCForCartUIResponse expectedResponse = sampleResponse;
        Mono<RetrieveURCForCartUIResponse> response = helper.retrieveURCForCart(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void manualPairingHelperTest() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ManualPairingUIRequest.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RetrieveURCForCartUIResponse.json", testFileLocation);
        ManualPairingUIRequest sampleUIRequest = null;
        ManualPairingUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, ManualPairingUIRequest.class);
        sampleResponse = mapper.readValue(sampleUIResponseString, ManualPairingUIResponse.class);
        when(bpmHelper3.manualPairing(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        ManualPairingUIResponse expectedResponse = sampleResponse;
        Mono<ManualPairingUIResponse> response = helper.manualPairing(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void cancelCaseHelperTest() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CancelCaseUIRequest.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CancelCaseUIResponse.json", testFileLocation);
        CancelCaseUIRequest sampleUIRequest = null;
        CancelCaseUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        String quotePricingRedisString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/QuotePricingRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setCreditAppNum("1234");
        QuotePricingRedisData sampleQuotePricingRedisData = mapper.readValue(quotePricingRedisString, QuotePricingRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, CancelCaseUIRequest.class);
        sampleUIRequest.setChannelId("VZW-ACSS");
        sampleResponse = mapper.readValue(sampleUIResponseString, CancelCaseUIResponse.class);
        when(bpmHelper3.cancelCase(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.getQuotePricingRedisData()).thenReturn(Mono.just(sampleQuotePricingRedisData));
        CancelCaseUIResponse expectedResponse = sampleResponse;
        Mono<CancelCaseUIResponse> response = helper.cancelCase(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }
    @Test
    public void addPlanAssistedTaggingTest() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/addPlanUIRequestAssistedTagging.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanResponseAssistedTagging.json", testFileLocation);
        AddPlanUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
        AddPlanUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddPlanUIResponse.class);
        String sampleCustomerProfile = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CustomerProfileAssistedTagging.json", testFileLocation);
        CustomerProfileResponse customerProfileResponse = mapper.readValue(sampleCustomerProfile, CustomerProfileResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData28.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setCustomerProfile(customerProfileResponse);
        UIRequest.getCartInfo().setFlexV2(true);
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(omniDLHelper.upsertPlanTaggingValueToRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(bpmHelperAddPlan.addPlan(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just("true"));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("true"));
        when(featureFlag.isFeatureEnabled(anyString(), anyString(), anyString(), anyBoolean())).thenReturn(Mono.just(Boolean.TRUE));
        //when(CartConstants.ASSISTED.equalsIgnoreCase("Assisted")).thenReturn(true);
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(new MyOfferETRRedisData()));
        AddPlanUIResponse expectedResponse = sampleResponse;
        Mono<AddPlanUIResponse> response = helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
/*        doThrow(new RuntimeException("Null pointer Exception")).when(deviceHelper).updateDLDataForAssisted(any());
        Mono<AddPlanUIResponse> errorResponse = helper.addPlan(UIRequest);
        assertNotNull(errorResponse);*/

    }
    @Test
    public void removeLinesHelperforDeassignTest() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIRequest15.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        RemoveLinesUIRequest sampleUIRequest = new RemoveLinesUIRequest();
        RemoveLinesUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisDataForRemoveLines.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setMtn("8436667390");
        MtnDetails mtnDetails = new MtnDetails();
        mtnDetails.setMobileNumber("8436667390");
        sampleUIRequest.setMtn(mtnDetails.getMobileNumber());

        sampleUIRequest = mapper.readValue(sampleUIRequestString, RemoveLinesUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, RemoveLinesUIResponse.class);
        String nbxString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackResponse.json", testFileLocation);
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        when(nbxService.nbxFeedbackCall(Mockito.any())).thenReturn(Mono.just(nbxRes));
        String bvpStr = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BVPRedisData.json", testFileLocation);
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        String validateCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse.json", testFileLocation);
        ValidateCartUIResponse validateCartResponse = mapper.readValue(validateCartResponseString, ValidateCartUIResponse.class);
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartResponse));
        when(bpmHelper2.removeLines(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(new BVPRedisData()));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just(new String()));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        RemoveLinesUIResponse expectedResponse = sampleResponse;
        Mono<RemoveLinesUIResponse> response = helper.removeLines(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void deassignMTNHelperTest2() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DeassignMtnUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DeassignMtnUIResponse.json", testFileLocation);
        RemoveLinesUIRequest sampleRequest = null;
        DeassignMtnUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRequest = mapper.readValue(sampleRequestString, RemoveLinesUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, DeassignMtnUIResponse.class);
        Mono<DeassignMtnUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.deassignMtn(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        DeassignMtnUIResponse expectedResponse = sampleResponse;
        //TC1
        sampleRequest.getData().setIsDeassignEnabledonRemove("true");
        Mono<DeassignMtnUIResponse> response = helper.deassignMtnUIResponseMono(sampleRequest,sampleRedisData);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
        //TC2
        sampleRequest.getData().setIsDeassignEnabledonRemove("false");
        response = helper.deassignMtnUIResponseMono(sampleRequest,sampleRedisData);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
        //TC3
        sampleRequest.getData().setIsDeassignEnabledonRemove(null);
        response = helper.deassignMtnUIResponseMono(sampleRequest,sampleRedisData);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void deassignMTNHelperTest3() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DeassignMtnUIRequest.json",
                testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DeassignMtnUIResponse.json",
                testFileLocation);
        RemoveLinesUIRequest sampleRequest = null;
        DeassignMtnUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisDataForDeassign.json",
                testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);

        sampleRequest = mapper.readValue(sampleRequestString, RemoveLinesUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, DeassignMtnUIResponse.class);
        Mono<DeassignMtnUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.deassignMtn(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        DeassignMtnUIResponse expectedResponse = sampleResponse;
        Mono<DeassignMtnUIResponse> response = helper.deassignMtnUIResponseMono(sampleRequest,sampleRedisData);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        /*StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();*/
        //TC1
        sampleRedisData.getRetrieveCart().getCart().getLineDetails().getLineInfo()[0].getMtnDetails().setLineNumber(null);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        response = helper.deassignMtnUIResponseMono(sampleRequest,sampleRedisData);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        //TC2
        sampleRedisData.getRetrieveCart().getCart().getLineDetails().getLineInfo()[0].getMtnDetails().setMobileNumber(null);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        response = helper.deassignMtnUIResponseMono(sampleRequest,sampleRedisData);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        //TC12
        sampleRedisData.getRetrieveCart().getCart().getLineDetails().getLineInfo()[0].getMtnDetails().setMtnType("reserveMtn");
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        response = helper.deassignMtnUIResponseMono(sampleRequest,sampleRedisData);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        //TC3
        sampleRedisData.getRetrieveCart().getCart().getLineDetails().getLineInfo()[0].setMtnDetails(null);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        response = helper.deassignMtnUIResponseMono(sampleRequest,sampleRedisData);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        //TC4
        sampleRedisData.getRetrieveCart().getCart().getLineDetails().getLineInfo()[0].setAssignMTNIndicator(null);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        response = helper.deassignMtnUIResponseMono(sampleRequest,sampleRedisData);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        //TC5
        sampleRedisData.getRetrieveCart().getCart().getLineDetails().getLineInfo()[0].setAssignMTNIndicator("");
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        response = helper.deassignMtnUIResponseMono(sampleRequest,sampleRedisData);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        //TC6
        sampleRedisData.getRetrieveCart().getCart().getLineDetails().getLineInfo()[0].setAssignMTNIndicator("N");
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        response = helper.deassignMtnUIResponseMono(sampleRequest,sampleRedisData);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        //TC7
        sampleRedisData.getRetrieveCart().getCart().getLineDetails().setLineInfo(null);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        response = helper.deassignMtnUIResponseMono(sampleRequest,sampleRedisData);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        CXPLineInfo[] lineInfo = {};
        sampleRedisData.getRetrieveCart().getCart().getLineDetails().setLineInfo(lineInfo);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        response = helper.deassignMtnUIResponseMono(sampleRequest,sampleRedisData);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        //TC8
        sampleRedisData.getRetrieveCart().getCart().setLineDetails(null);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        response = helper.deassignMtnUIResponseMono(sampleRequest,sampleRedisData);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        //TC9
        sampleRedisData.getRetrieveCart().setCart(null);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        response = helper.deassignMtnUIResponseMono(sampleRequest,sampleRedisData);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        //TC10
        sampleRedisData.setRetrieveCart(null);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        response = helper.deassignMtnUIResponseMono(sampleRequest,sampleRedisData);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        //TC11
        sampleRequest.getData().getLines()[0].setMtn("8765432107");
        response = helper.deassignMtnUIResponseMono(sampleRequest,sampleRedisData);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        sampleRequest.getData().getLines()[0].setMtn(null);
        response = helper.deassignMtnUIResponseMono(sampleRequest,sampleRedisData);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

    }
    @Test
    public void getCartLineMtnMapByLineNumberTest() throws JsonProcessingException {
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisDataForRemoveLines.json",
                testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Map<String, CXPLineInfo> expectedLineMap, lineMap;
        expectedLineMap = new HashMap<>();
        expectedLineMap.put(sampleRedisData.getRetrieveCart().getCart().getLineDetails().getLineInfo()[0].getLineNumber(),
                sampleRedisData.getRetrieveCart().getCart().getLineDetails().getLineInfo()[0]);
        lineMap =  helper.getCartLineMtnMapByLineNumber(sampleRedisData.getRetrieveCart());
        assertEquals(lineMap, expectedLineMap);
        expectedLineMap.clear();
        //TC1
        sampleRedisData.getRetrieveCart().getCart().getLineDetails().getLineInfo()[0].setLineNumber(" ");
        lineMap =  helper.getCartLineMtnMapByLineNumber(sampleRedisData.getRetrieveCart());
        assertEquals(lineMap, expectedLineMap);
        sampleRedisData.getRetrieveCart().getCart().getLineDetails().getLineInfo()[0].setLineNumber("");
        lineMap =  helper.getCartLineMtnMapByLineNumber(sampleRedisData.getRetrieveCart());
        assertEquals(lineMap, expectedLineMap);
        sampleRedisData.getRetrieveCart().getCart().getLineDetails().getLineInfo()[0].setLineNumber(null);
        lineMap =  helper.getCartLineMtnMapByLineNumber(sampleRedisData.getRetrieveCart());
        assertEquals(lineMap, expectedLineMap);
        //TC2
        CXPLineInfo[] lineInfos = new CXPLineInfo[1];
        lineInfos[0]=null;
        sampleRedisData.getRetrieveCart().getCart().getLineDetails().setLineInfo(lineInfos);
        lineMap =  helper.getCartLineMtnMapByLineNumber(sampleRedisData.getRetrieveCart());
        assertEquals(lineMap, expectedLineMap);
        lineInfos = new CXPLineInfo[0];
        sampleRedisData.getRetrieveCart().getCart().getLineDetails().setLineInfo(lineInfos);
        lineMap =  helper.getCartLineMtnMapByLineNumber(sampleRedisData.getRetrieveCart());
        assertEquals(lineMap, expectedLineMap);
        sampleRedisData.getRetrieveCart().getCart().getLineDetails().setLineInfo(null);
        lineMap =  helper.getCartLineMtnMapByLineNumber(sampleRedisData.getRetrieveCart());
        assertEquals(lineMap, expectedLineMap);
        //TC3
        sampleRedisData.getRetrieveCart().getCart().setLineDetails(null);
        lineMap =  helper.getCartLineMtnMapByLineNumber(sampleRedisData.getRetrieveCart());
        assertEquals(lineMap, expectedLineMap);
        //TC4
        sampleRedisData.getRetrieveCart().setCart(null);
        lineMap =  helper.getCartLineMtnMapByLineNumber(sampleRedisData.getRetrieveCart());
        assertEquals(lineMap, expectedLineMap);
        //TC5
        sampleRedisData.setRetrieveCart(null);
        lineMap =  helper.getCartLineMtnMapByLineNumber(sampleRedisData.getRetrieveCart());
        assertEquals(lineMap, expectedLineMap);


    }

    @Test
    public void removeDualNumberFromSessionConditionalCoverage() throws JsonProcessingException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIRequest15.json", testFileLocation);
        RemoveLinesUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, RemoveLinesUIRequest.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisDataForRemoveLines.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        CartRedisData sampleRedisData1 = mapper.readValue(redisDataString, CartRedisData.class);
        //TC1
        sampleUIRequest.getData().getLines()[0].setMtn("newLine1");
        helper.removeDualNumberFromSession(sampleUIRequest, sampleRedisData);
        sampleRedisData1.getDualNumber().getSecondNumber().get(0).setSecondMtn("newLine1");
        helper.removeDualNumberFromSession(sampleUIRequest, sampleRedisData1);
        sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest.getData().getLines()[0].setMtn("newLine2");
        helper.removeDualNumberFromSession(sampleUIRequest, sampleRedisData);
        sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest.getData().getLines()[0].setMtn("9482050979");
        helper.removeDualNumberFromSession(sampleUIRequest, sampleRedisData);
        sampleRedisData1 = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData1.getDualNumber().getSecondNumber().get(0).setSecondMtn("newLine1");
        helper.removeDualNumberFromSession(sampleUIRequest, sampleRedisData1);
        //TC2
        sampleRedisData1 = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest.getData().getLines()[0].setMtn("newLine1");
        sampleRedisData1.getDualNumber().getSecondNumber().get(0).setSecondMtn(" ");
        helper.removeDualNumberFromSession(sampleUIRequest, sampleRedisData1);
        sampleRedisData1 = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData1.getDualNumber().getSecondNumber().get(0).setSecondMtn("");
        helper.removeDualNumberFromSession(sampleUIRequest, sampleRedisData1);
        sampleRedisData1 = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData1.getDualNumber().getSecondNumber().get(0).setSecondMtn(null);
        helper.removeDualNumberFromSession(sampleUIRequest, sampleRedisData1);
        //TC3
        sampleRedisData1 = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData1.getDualNumber().getSecondNumber().clear();
        helper.removeDualNumberFromSession(sampleUIRequest, sampleRedisData1);
        sampleRedisData1 = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData1.getDualNumber().setSecondNumber(null);
        helper.removeDualNumberFromSession(sampleUIRequest, sampleRedisData1);
        //TC4
        sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest.getData().getLines()[0].setMtn(" ");
        helper.removeDualNumberFromSession(sampleUIRequest, sampleRedisData);
        sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest.getData().getLines()[0].setMtn("");
        helper.removeDualNumberFromSession(sampleUIRequest, sampleRedisData);
        sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest.getData().getLines()[0].setMtn(null);
        helper.removeDualNumberFromSession(sampleUIRequest, sampleRedisData);
        //TC5
        sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest.getData().setLines(new Lines[0]);
        helper.removeDualNumberFromSession(sampleUIRequest, sampleRedisData);
        sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest.getData().setLines(null);
        helper.removeDualNumberFromSession(sampleUIRequest, sampleRedisData);
        //TC6
        sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest.setData(null);
        helper.removeDualNumberFromSession(sampleUIRequest, sampleRedisData);
        //TC7
        sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest.setData(null);
        helper.removeDualNumberFromSession(sampleUIRequest, sampleRedisData);
    }

}