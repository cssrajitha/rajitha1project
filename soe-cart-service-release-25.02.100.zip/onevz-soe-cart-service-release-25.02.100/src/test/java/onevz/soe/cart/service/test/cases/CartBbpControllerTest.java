package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import junit.framework.Assert;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.controller.CartBbpController;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.helper.*;
import onevz.soe.cart.requests.BBPRequestVO;
import onevz.soe.cart.responses.AddZipcodeRedisData;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.responses.ValidateE911AddressCXPResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.AddDeviceUIResponse;
import onevz.soe.cart.ui.responses.BbpGetProcessStepUIResponse;
import onevz.soe.cart.ui.responses.DeviceSimDetailsUIResponse;
import onevz.soe.cart.ui.responses.SalesOrderAdjustmentUIResponse;
import onevz.soe.omnidl.util.DLUtilityService;
import onevz.soe.security.TokenProcessor;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.http.server.reactive.MockServerHttpResponse;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.ResourceUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.nio.file.Files;

import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { CartServiceTestConfig.class })
public class CartBbpControllerTest {

	@MockBean
	private UpdateCartHelper cartHelper;

	@Autowired
	private CartBbpController cartController;

	@Autowired
	private ObjectMapper mapper;

	@MockBean
	private RedisHelper redisHelper;

	@MockBean
	private RedisHelper2 redisHelper2;

	@MockBean
	private DLUtilityService dlUtilityService;

	@MockBean
	private TokenProcessor tokenProcessor;
	
	@MockBean
	private CartAddDeviceHelper accDevHelper;

	@Autowired
	private CartRpsHelper cartRpsHelper;

	@MockBean
	private CartServiceCXPServices cxpService;

	@Test
	public void bbpPayloadTest() throws IOException {
		BBPPayloadUIRequest bbpPayloadUiRequest = new BBPPayloadUIRequest();
		bbpPayloadUiRequest.setIccid("89148000000835900458");
		bbpPayloadUiRequest.setImei("352898071702915");
		bbpPayloadUiRequest.setIsSmartphone(true);
		bbpPayloadUiRequest.setTechType("DEVICE4GSELF");
		bbpPayloadUiRequest.setSkipUserAgent(true);
		when(redisHelper2.upsertBBPFlowDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
		URI url = URI.create("http://localhost/bbpPayload");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = null;
		Mono<ResponseEntity<Object>> controllerResponse = cartController.bbpPayload(httpHeader, httpResponse,
				bbpPayloadUiRequest);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void bbpPayloadErrorTest() throws IOException {
		BBPPayloadUIRequest bbpPayloadUiRequest = new BBPPayloadUIRequest();
		bbpPayloadUiRequest.setIccid("89148000000835900458");
		bbpPayloadUiRequest.setImei("352898071702915");
		bbpPayloadUiRequest.setIsSmartphone(true);
		bbpPayloadUiRequest.setTechType("DEVICE4GSELF");
		bbpPayloadUiRequest.setSkipUserAgent(true);
		when(redisHelper2.upsertBBPFlowDataIntoRedis(Mockito.any())).thenReturn(Mono.just(false));
		URI url = URI.create("http://localhost/bbpPayload");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = null;
		Mono<ResponseEntity<Object>> controllerResponse = cartController.bbpPayload(httpHeader, httpResponse,
				bbpPayloadUiRequest);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void startBBPFlowTest() throws IOException {
		String sampleResponseString = "{\r\n" + "    \"uiMeta\": {\r\n" + "        \"timestamp\": 1606904076236,\r\n"
				+ "        \"cxpCorrelationId\": \"2020-12-02T10:14:36.+0000:90be2abf-a4e2-4e0e-8fcb-4edcdee0a1e6:cxp-customerprofile-se-qa-ev6v-sit4w-nscxp-756b46467b-5z5q6:nssit4\"\r\n"
				+ "    },\r\n" + "    \"uiData\": {\r\n" + "        \"deviceInfo\": {\r\n"
				+ "            \"deviceId\": \"359433083362780\",\r\n" + "            \"mfgCode\": \"APL\",\r\n"
				+ "            \"prodName\": \"APPLE WATCH S3 42 SPBLK MIL\",\r\n"
				+ "            \"prodType\": \"ConnectedDevice\",\r\n" + "            \"eqpModeCode\": \"4GE\",\r\n"
				+ "            \"eqpMode\": \"4G\",\r\n" + "            \"ems\": \"N\",\r\n"
				+ "            \"mms\": \"Y\",\r\n" + "            \"gps\": \"Y\",\r\n"
				+ "            \"ptt\": \"N\",\r\n" + "            \"globalPhone\": \"O\",\r\n"
				+ "            \"wap\": \"N/A\",\r\n" + "            \"bluetooth\": \"Y\",\r\n"
				+ "            \"brew\": \"N\",\r\n" + "            \"trustedMode\": \"N\",\r\n"
				+ "            \"csim\": \"\",\r\n" + "            \"ehrpd\": \"N\",\r\n"
				+ "            \"smsevdo\": \"N\",\r\n" + "            \"deviceCategory\": \"4G Connected Device\",\r\n"
				+ "            \"visionProdId\": \"38940\",\r\n" + "            \"preferredSim\": \"\",\r\n"
				+ "            \"backupAssistCapable\": \"N\",\r\n" + "            \"simClass4G\": \"NR\",\r\n"
				+ "            \"virtualSimSku\": \"\",\r\n" + "            \"deviceNoPay\": \"N\",\r\n"
				+ "            \"deviceLostStolen\": \"N\",\r\n" + "            \"deviceSdmLock\": \"\",\r\n"
				+ "            \"deviceLock\": \"\",\r\n" + "            \"devicePibLock\": \"\",\r\n"
				+ "            \"prepayEligibility\": \"00\",\r\n" + "            \"eligibilityDate\": \"\",\r\n"
				+ "            \"outletId\": \"\",\r\n" + "            \"dacc\": \"01032\",\r\n"
				+ "            \"deviceType\": \"4GE\",\r\n" + "            \"provTechType\": \"LTE\",\r\n"
				+ "            \"launchPackageSku\": \"MR1L2LL/A\",\r\n" + "            \"imSku\": \"MR1L2LL/A\",\r\n"
				+ "            \"deviceCapabilityInd\": \"VD\",\r\n" + "            \"nfcCapable\": \"Y\",\r\n"
				+ "            \"nfcCompatible\": \"Y\",\r\n" + "            \"pibDevice\": \"N\",\r\n"
				+ "            \"connectedDeviceInd\": null,\r\n"
				+ "            \"deviceFamilyType\": \"Connected\",\r\n"
				+ "            \"buddyUpgrdEligInd\": \"N\",\r\n" + "            \"restrictToFamilyInd\": \"Y\",\r\n"
				+ "            \"nonGeoDeviceInd\": \"\",\r\n" + "            \"m2MAllow\": \"M2MC\",\r\n"
				+ "            \"hdVoice\": \"Y\",\r\n" + "            \"alkDevice\": \"HD\",\r\n"
				+ "            \"shipDate\": \"20-DEC-2017\",\r\n" + "            \"cpo\": \"N\",\r\n"
				+ "            \"lsClientId\": \"\",\r\n" + "            \"lsCustomerId\": \"\",\r\n"
				+ "            \"lsBillAcctNumber\": \"\",\r\n" + "            \"v4B\": \"\",\r\n"
				+ "            \"icEligInd\": \"\",\r\n" + "            \"icRemDays\": \"\",\r\n"
				+ "            \"icRemSubsidyAmt\": \"\",\r\n" + "            \"e911AddrInd\": \"Y\",\r\n"
				+ "            \"euiccCapable\": \"Y\",\r\n" + "            \"numberShareCapability\": \"Y\",\r\n"
				+ "            \"wifiCalling\": \"Y\",\r\n" + "            \"vvm\": \"N\",\r\n"
				+ "            \"imei1\": \"\",\r\n" + "            \"imei2\": \"\",\r\n"
				+ "            \"osType\": \"WatchOS4\",\r\n" + "            \"postpaidRestrictStartDate\": \"\",\r\n"
				+ "            \"dsEs12Fqdn\": \"\"\r\n" + "        },\r\n" + "        \"simInfo\": {\r\n"
				+ "            \"simId\": \"89148000000751553653\",\r\n" + "            \"mfgCode\": \"GTO\",\r\n"
				+ "            \"prodName\": \"Gemalto 4FF NFC SIM - DF\",\r\n" + "            \"simGroup\": \"\",\r\n"
				+ "            \"prodType\": \"4G_4FF_SIM\",\r\n" + "            \"simFormFactor\": \"\",\r\n"
				+ "            \"simNoPay\": \"N\",\r\n" + "            \"simLostStolen\": \"N\",\r\n"
				+ "            \"simLock\": \"\",\r\n" + "            \"simPibLock\": \"\",\r\n"
				+ "            \"outletId\": \"\",\r\n" + "            \"sacc\": \"00722\",\r\n"
				+ "            \"simType\": \"4GS\",\r\n" + "            \"iccidStatus\": \"AA\",\r\n"
				+ "            \"numberLocation\": \"\",\r\n" + "            \"provTechType\": \"LTE\",\r\n"
				+ "            \"launchPackageSku\": \"DFILL4FF-NFC-A\",\r\n"
				+ "            \"imSku\": \"DFILL4FF-NFC-A\",\r\n" + "            \"nfcCapable\": \"Y\",\r\n"
				+ "            \"nfcCompatible\": \"\",\r\n" + "            \"solderedSim\": \"\",\r\n"
				+ "            \"simCapable\": \"DUAL_IMSI\",\r\n"
				+ "            \"selfActivationCapableInd\": null,\r\n" + "            \"lsClientId\": \"\",\r\n"
				+ "            \"lsCustomerId\": \"\",\r\n" + "            \"lsBillAcctNumber\": \"\",\r\n"
				+ "            \"saleRetailer\": \"\",\r\n" + "            \"simSkuType\": \"T\",\r\n"
				+ "            \"personalizedStatus\": \"\",\r\n" + "            \"personalizedTimeStamp\": \"\"\r\n"
				+ "        },\r\n" + "        \"deviceSimCompatible\": \"Y\",\r\n"
				+ "        \"deviceSimM2MPair\": \"N\",\r\n" + "        \"deviceESimCompatible\": \"\",\r\n"
				+ "        \"deviceEsimM2MPair\": \"Y\",\r\n" + "        \"esimInfo\": {\r\n"
				+ "            \"mfgCode\": \"\",\r\n" + "            \"launchPackageSku\": \"\",\r\n"
				+ "            \"prodName\": \"\",\r\n" + "            \"preferredSoftSim\": \"SOFTNASIM-MP-D\",\r\n"
				+ "            \"launchPackageSkuType\": \"\",\r\n" + "            \"pairedIccid\": \"\",\r\n"
				+ "            \"eID\": \"89049032003008882300001955592066\"\r\n" + "        }\r\n" + "    }\r\n" + "}";
		DeviceSimDetailsUIResponse response = mapper.readValue(sampleResponseString, DeviceSimDetailsUIResponse.class);
		String addDeviceStr = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1596531-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"},{\"path\":\"FeatureConflicts\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"registerNumber\":0,\"accountNumber\":\"0220561307-00002\",\"cartCreator\":\"8439410557\",\"processingMTN\":\"8439292610\"},\"cartInfo\":{\"method\":\"\",\"financeLimitExceeded\":\"false\",\"cartId\":\"9c43a538-bcd8-4c1f-b271-6eb043271223\",\"clientAppName\":\"VZW-NETACE\",\"statusCode\":\"1\",\"statusMsg\":\"Success\",\"lines\":[{\"plan\":{},\"status\":1,\"errors\":[],\"spos\":[{\"id\":\"1167\",\"actionIndicator\":\"Z\",\"success\":true,\"is5GBolt\":false}],\"sfos\":[],\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"mtn\":\"8439292610\",\"device\":{\"cartItemType\":\"\",\"quantityOnHand\":\"\",\"upgradeReasonCode\":\"\",\"id\":\"MQ722LL/A\",\"description\":\"\",\"itemPrice\":\"449.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"discounts\":\"\",\"existingDeviceId\":\"\",\"existingDeviceName\":\"iPhone&reg; 8\",\"removedFeatures\":\"\",\"fiveGToFourGDownGrade\":false},\"sim\":{\"simId\":\"\",\"id\":\"EMBD4GSIM-N\"},\"warranty\":{\"id\":\"\",\"itemPrice\":\"0.0\",\"discounts\":\"\"},\"upgradeFee\":{\"id\":\"\",\"itemPrice\":\"\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"AAL\",\"currentPlanType\":\"ALP\"}],\"expressCheckout\":false,\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false},\"processMTNList\":[{\"mtn\":\"8439292610\",\"completedprocessSteps\":[\"pastDuePage\",\"MTNSelectionPage\",\"InterimPage\",\"GridWallPDP\",\"GridWallPDP\",\"MTNSelectionPage\",\"InterimPage\",\"GridWallPDP\",\"GridWallPDP\",\"GridWallPDP\"]}]}}}}";
		AddDeviceUIResponse responseServiceMono = mapper.readValue(addDeviceStr, AddDeviceUIResponse.class);
		when(redisHelper2.upsertAccountInfoEligibleInRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
		URI url = URI.create("http://localhost/startBBPFlow");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = null;
		String bbpRequestVOString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"iccid\":\"89148000000835900342\",\"imei\":\"352898071702915\",\"isSmartphone\":true}";
		BBPRequestVO bbpRequestVO = mapper.readValue(bbpRequestVOString, BBPRequestVO.class);
		when(cartHelper.initiateBBPFlow(Mockito.any())).thenReturn(Mono.just(response));
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(responseServiceMono));
		when(redisHelper2.upsertBBPFlowDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
		when(redisHelper2.upsertAddDeviceDataIntoRedis(Mockito.any())).thenReturn(Mono.just(new CartRedisData()));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.startBBPFlow(httpHeader, httpResponse,
				bbpRequestVO);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void startBBPFlowTest1() throws IOException {
		String sampleResponseString = "{\r\n" + "    \"uiMeta\": {\r\n" + "        \"timestamp\": 1606904076236,\r\n"
				+ "        \"cxpCorrelationId\": \"2020-12-02T10:14:36.+0000:90be2abf-a4e2-4e0e-8fcb-4edcdee0a1e6:cxp-customerprofile-se-qa-ev6v-sit4w-nscxp-756b46467b-5z5q6:nssit4\"\r\n"
				+ "    },\r\n" + "    \"uiData\": {\r\n" + "        \"deviceInfo\": {\r\n"
				+ "            \"deviceId\": \"359433083362780\",\r\n" + "            \"mfgCode\": \"APL\",\r\n"
				+ "            \"prodName\": \"APPLE WATCH S3 42 SPBLK MIL\",\r\n"
				+ "            \"prodType\": \"ConnectedDevice\",\r\n" + "            \"eqpModeCode\": \"4GE\",\r\n"
				+ "            \"eqpMode\": \"4G\",\r\n" + "            \"ems\": \"N\",\r\n"
				+ "            \"mms\": \"Y\",\r\n" + "            \"gps\": \"Y\",\r\n"
				+ "            \"ptt\": \"N\",\r\n" + "            \"globalPhone\": \"O\",\r\n"
				+ "            \"wap\": \"N/A\",\r\n" + "            \"bluetooth\": \"Y\",\r\n"
				+ "            \"brew\": \"N\",\r\n" + "            \"trustedMode\": \"N\",\r\n"
				+ "            \"csim\": \"\",\r\n" + "            \"ehrpd\": \"N\",\r\n"
				+ "            \"smsevdo\": \"N\",\r\n" + "            \"deviceCategory\": \"phone\",\r\n"
				+ "            \"visionProdId\": \"38940\",\r\n" + "            \"preferredSim\": \"\",\r\n"
				+ "            \"backupAssistCapable\": \"N\",\r\n" + "            \"simClass4G\": \"NR\",\r\n"
				+ "            \"virtualSimSku\": \"\",\r\n" + "            \"deviceNoPay\": \"N\",\r\n"
				+ "            \"deviceLostStolen\": \"N\",\r\n" + "            \"deviceSdmLock\": \"\",\r\n"
				+ "            \"deviceLock\": \"\",\r\n" + "            \"devicePibLock\": \"\",\r\n"
				+ "            \"prepayEligibility\": \"00\",\r\n" + "            \"eligibilityDate\": \"\",\r\n"
				+ "            \"outletId\": \"\",\r\n" + "            \"dacc\": \"01032\",\r\n"
				+ "            \"deviceType\": \"4GE\",\r\n" + "            \"provTechType\": \"LTE\",\r\n"
				+ "            \"launchPackageSku\": \"MR1L2LL/A\",\r\n" + "            \"imSku\": \"\",\r\n"
				+ "            \"deviceCapabilityInd\": \"VD\",\r\n" + "            \"nfcCapable\": \"Y\",\r\n"
				+ "            \"nfcCompatible\": \"Y\",\r\n" + "            \"pibDevice\": \"N\",\r\n"
				+ "            \"connectedDeviceInd\": null,\r\n"
				+ "            \"deviceFamilyType\": \"Connected\",\r\n"
				+ "            \"buddyUpgrdEligInd\": \"N\",\r\n" + "            \"restrictToFamilyInd\": \"Y\",\r\n"
				+ "            \"nonGeoDeviceInd\": \"\",\r\n" + "            \"m2MAllow\": \"M2MC\",\r\n"
				+ "            \"hdVoice\": \"Y\",\r\n" + "            \"alkDevice\": \"HD\",\r\n"
				+ "            \"shipDate\": \"20-DEC-2017\",\r\n" + "            \"cpo\": \"N\",\r\n"
				+ "            \"lsClientId\": \"\",\r\n" + "            \"lsCustomerId\": \"\",\r\n"
				+ "            \"lsBillAcctNumber\": \"\",\r\n" + "            \"v4B\": \"\",\r\n"
				+ "            \"icEligInd\": \"\",\r\n" + "            \"icRemDays\": \"\",\r\n"
				+ "            \"icRemSubsidyAmt\": \"\",\r\n" + "            \"e911AddrInd\": \"Y\",\r\n"
				+ "            \"euiccCapable\": \"Y\",\r\n" + "            \"numberShareCapability\": \"Y\",\r\n"
				+ "            \"wifiCalling\": \"Y\",\r\n" + "            \"vvm\": \"N\",\r\n"
				+ "            \"imei1\": \"\",\r\n" + "            \"imei2\": \"\",\r\n"
				+ "            \"osType\": \"WatchOS4\",\r\n" + "            \"postpaidRestrictStartDate\": \"\",\r\n"
				+ "            \"dsEs12Fqdn\": \"\"\r\n" + "        },\r\n" + "        \"simInfo\": {\r\n"
				+ "            \"simId\": \"89148000000751553653\",\r\n" + "            \"mfgCode\": \"GTO\",\r\n"
				+ "            \"prodName\": \"Gemalto 4FF NFC SIM - DF\",\r\n" + "            \"simGroup\": \"\",\r\n"
				+ "            \"prodType\": \"4G_4FF_SIM\",\r\n" + "            \"simFormFactor\": \"\",\r\n"
				+ "            \"simNoPay\": \"N\",\r\n" + "            \"simLostStolen\": \"N\",\r\n"
				+ "            \"simLock\": \"\",\r\n" + "            \"simPibLock\": \"\",\r\n"
				+ "            \"outletId\": \"\",\r\n" + "            \"sacc\": \"00722\",\r\n"
				+ "            \"simType\": \"4GS\",\r\n" + "            \"iccidStatus\": \"AA\",\r\n"
				+ "            \"numberLocation\": \"\",\r\n" + "            \"provTechType\": \"LTE\",\r\n"
				+ "            \"launchPackageSku\": \"DFILL4FF-NFC-A\",\r\n"
				+ "            \"imSku\": \"DFILL4FF-NFC-A\",\r\n" + "            \"nfcCapable\": \"Y\",\r\n"
				+ "            \"nfcCompatible\": \"\",\r\n" + "            \"solderedSim\": \"\",\r\n"
				+ "            \"simCapable\": \"DUAL_IMSI\",\r\n"
				+ "            \"selfActivationCapableInd\": null,\r\n" + "            \"lsClientId\": \"\",\r\n"
				+ "            \"lsCustomerId\": \"\",\r\n" + "            \"lsBillAcctNumber\": \"\",\r\n"
				+ "            \"saleRetailer\": \"\",\r\n" + "            \"simSkuType\": \"T\",\r\n"
				+ "            \"personalizedStatus\": \"\",\r\n" + "            \"personalizedTimeStamp\": \"\"\r\n"
				+ "        },\r\n" + "        \"deviceSimCompatible\": \"Y\",\r\n"
				+ "        \"deviceSimM2MPair\": \"N\",\r\n" + "        \"deviceESimCompatible\": \"\",\r\n"
				+ "        \"deviceEsimM2MPair\": \"Y\",\r\n" + "        \"esimInfo\": {\r\n"
				+ "            \"mfgCode\": \"\",\r\n" + "            \"launchPackageSku\": \"\",\r\n"
				+ "            \"prodName\": \"\",\r\n" + "            \"preferredSoftSim\": \"SOFTNASIM-MP-D\",\r\n"
				+ "            \"launchPackageSkuType\": \"\",\r\n" + "            \"pairedIccid\": \"\",\r\n"
				+ "            \"eID\": \"89049032003008882300001955592066\"\r\n" + "        }\r\n" + "    }\r\n" + "}";
		DeviceSimDetailsUIResponse response = mapper.readValue(sampleResponseString, DeviceSimDetailsUIResponse.class);
		String addDeviceStr = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1596531-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"},{\"path\":\"FeatureConflicts\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"registerNumber\":0,\"accountNumber\":\"0220561307-00002\",\"cartCreator\":\"8439410557\",\"processingMTN\":\"8439292610\"},\"cartInfo\":{\"method\":\"\",\"financeLimitExceeded\":\"false\",\"cartId\":\"9c43a538-bcd8-4c1f-b271-6eb043271223\",\"clientAppName\":\"VZW-NETACE\",\"statusCode\":\"1\",\"statusMsg\":\"Success\",\"lines\":[{\"plan\":{},\"status\":1,\"errors\":[],\"spos\":[{\"id\":\"1167\",\"actionIndicator\":\"Z\",\"success\":true,\"is5GBolt\":false}],\"sfos\":[],\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"mtn\":\"8439292610\",\"device\":{\"cartItemType\":\"\",\"quantityOnHand\":\"\",\"upgradeReasonCode\":\"\",\"id\":\"MQ722LL/A\",\"description\":\"\",\"itemPrice\":\"449.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"discounts\":\"\",\"existingDeviceId\":\"\",\"existingDeviceName\":\"iPhone&reg; 8\",\"removedFeatures\":\"\",\"fiveGToFourGDownGrade\":false},\"sim\":{\"simId\":\"\",\"id\":\"EMBD4GSIM-N\"},\"warranty\":{\"id\":\"\",\"itemPrice\":\"0.0\",\"discounts\":\"\"},\"upgradeFee\":{\"id\":\"\",\"itemPrice\":\"\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"AAL\",\"currentPlanType\":\"ALP\"}],\"expressCheckout\":false,\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false},\"processMTNList\":[{\"mtn\":\"8439292610\",\"completedprocessSteps\":[\"pastDuePage\",\"MTNSelectionPage\",\"InterimPage\",\"GridWallPDP\",\"GridWallPDP\",\"MTNSelectionPage\",\"InterimPage\",\"GridWallPDP\",\"GridWallPDP\",\"GridWallPDP\"]}]}}}}";
		AddDeviceUIResponse responseServiceMono = mapper.readValue(addDeviceStr, AddDeviceUIResponse.class);
		when(redisHelper2.upsertAccountInfoEligibleInRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
		URI url = URI.create("http://localhost/nse/startBBPFlow");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM-BBP").build();
		ServerHttpResponse httpResponse = null;
		String bbpRequestVOString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"iccid\":\"89148000000835900342\",\"imei\":\"352898071702915\",\"isSmartphone\":true,\"imei2\":\"352898071702914\",\"isSmartphone\":true,\"devid\":\"12312412\",\"eid\":\"3124124\"}";
		BBPRequestVO bbpRequestVO = mapper.readValue(bbpRequestVOString, BBPRequestVO.class);
		when(cartHelper.initiateBBPFlow(Mockito.any())).thenReturn(Mono.just(response));
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(responseServiceMono));
		when(redisHelper2.upsertBBPFlowDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
		when(redisHelper2.upsertAddDeviceDataIntoRedis(Mockito.any())).thenReturn(Mono.just(new CartRedisData()));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.startBBPFlow(httpHeader, httpResponse,
				bbpRequestVO);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}
	
	@Test
	public void startBBPFlowGizmoTest() throws IOException {
		String sampleResponseString = "{\r\n" + "    \"uiMeta\": {\r\n" + "        \"timestamp\": 1606904076236,\r\n"
				+ "        \"cxpCorrelationId\": \"2020-12-02T10:14:36.+0000:90be2abf-a4e2-4e0e-8fcb-4edcdee0a1e6:cxp-customerprofile-se-qa-ev6v-sit4w-nscxp-756b46467b-5z5q6:nssit4\"\r\n"
				+ "    },\r\n" + "    \"uiData\": {\r\n" + "        \"deviceInfo\": {\r\n"
				+ "            \"deviceId\": \"359433083362780\",\r\n" + "            \"mfgCode\": \"APL\",\r\n"
				+ "            \"prodName\": \"APPLE WATCH S3 42 SPBLK MIL\",\r\n"
				+ "            \"prodType\": \"ConnectedDevice\",\r\n" + "            \"eqpModeCode\": \"4GE\",\r\n"
				+ "            \"eqpMode\": \"4G\",\r\n" + "            \"ems\": \"N\",\r\n"
				+ "            \"mms\": \"Y\",\r\n" + "            \"gps\": \"Y\",\r\n"
				+ "            \"ptt\": \"N\",\r\n" + "            \"globalPhone\": \"O\",\r\n"
				+ "            \"wap\": \"N/A\",\r\n" + "            \"bluetooth\": \"Y\",\r\n"
				+ "            \"brew\": \"N\",\r\n" + "            \"trustedMode\": \"N\",\r\n"
				+ "            \"csim\": \"\",\r\n" + "            \"ehrpd\": \"N\",\r\n"
				+ "            \"smsevdo\": \"N\",\r\n" + "            \"deviceCategory\": \"4G Connected Device\",\r\n"
				+ "            \"visionProdId\": \"38940\",\r\n" + "            \"preferredSim\": \"\",\r\n"
				+ "            \"backupAssistCapable\": \"N\",\r\n" + "            \"simClass4G\": \"NR\",\r\n"
				+ "            \"virtualSimSku\": \"\",\r\n" + "            \"deviceNoPay\": \"N\",\r\n"
				+ "            \"deviceLostStolen\": \"N\",\r\n" + "            \"deviceSdmLock\": \"\",\r\n"
				+ "            \"deviceLock\": \"\",\r\n" + "            \"devicePibLock\": \"\",\r\n"
				+ "            \"prepayEligibility\": \"00\",\r\n" + "            \"eligibilityDate\": \"\",\r\n"
				+ "            \"outletId\": \"\",\r\n" + "            \"dacc\": \"\",\r\n"
				+ "            \"deviceType\": \"4GE\",\r\n" + "            \"provTechType\": \"LTE\",\r\n"
				+ "            \"launchPackageSku\": \"QTAX53B\",\r\n" + "            \"imSku\": \"MR1L2LL/A\",\r\n"
				+ "            \"deviceCapabilityInd\": \"VD\",\r\n" + "            \"nfcCapable\": \"Y\",\r\n"
				+ "            \"nfcCompatible\": \"Y\",\r\n" + "            \"pibDevice\": \"N\",\r\n"
				+ "            \"connectedDeviceInd\": null,\r\n"
				+ "            \"deviceFamilyType\": \"Connected\",\r\n"
				+ "            \"buddyUpgrdEligInd\": \"N\",\r\n" + "            \"restrictToFamilyInd\": \"Y\",\r\n"
				+ "            \"nonGeoDeviceInd\": \"\",\r\n" + "            \"m2MAllow\": \"M2MC\",\r\n"
				+ "            \"hdVoice\": \"Y\",\r\n" + "            \"alkDevice\": \"HD\",\r\n"
				+ "            \"shipDate\": \"20-DEC-2017\",\r\n" + "            \"cpo\": \"N\",\r\n"
				+ "            \"lsClientId\": \"\",\r\n" + "            \"lsCustomerId\": \"\",\r\n"
				+ "            \"lsBillAcctNumber\": \"\",\r\n" + "            \"v4B\": \"\",\r\n"
				+ "            \"icEligInd\": \"\",\r\n" + "            \"icRemDays\": \"\",\r\n"
				+ "            \"icRemSubsidyAmt\": \"\",\r\n" + "            \"e911AddrInd\": \"Y\",\r\n"
				+ "            \"euiccCapable\": \"Y\",\r\n" + "            \"numberShareCapability\": \"Y\",\r\n"
				+ "            \"wifiCalling\": \"Y\",\r\n" + "            \"vvm\": \"N\",\r\n"
				+ "            \"imei1\": \"\",\r\n" + "            \"imei2\": \"\",\r\n"
				+ "            \"osType\": \"WatchOS4\",\r\n" + "            \"postpaidRestrictStartDate\": \"\",\r\n"
				+ "            \"dsEs12Fqdn\": \"\"\r\n" + "        },\r\n" + "        \"simInfo\": {\r\n"
				+ "            \"simId\": \"89148000000751553653\",\r\n" + "            \"mfgCode\": \"GTO\",\r\n"
				+ "            \"prodName\": \"Gemalto 4FF NFC SIM - DF\",\r\n" + "            \"simGroup\": \"\",\r\n"
				+ "            \"prodType\": \"4G_4FF_SIM\",\r\n" + "            \"simFormFactor\": \"\",\r\n"
				+ "            \"simNoPay\": \"N\",\r\n" + "            \"simLostStolen\": \"N\",\r\n"
				+ "            \"simLock\": \"\",\r\n" + "            \"simPibLock\": \"\",\r\n"
				+ "            \"outletId\": \"\",\r\n" + "            \"sacc\": \"00722\",\r\n"
				+ "            \"simType\": \"4GS\",\r\n" + "            \"iccidStatus\": \"AA\",\r\n"
				+ "            \"numberLocation\": \"\",\r\n" + "            \"provTechType\": \"LTE\",\r\n"
				+ "            \"launchPackageSku\": \"DFILL4FF-NFC-A\",\r\n"
				+ "            \"imSku\": \"DFILL4FF-NFC-A\",\r\n" + "            \"nfcCapable\": \"Y\",\r\n"
				+ "            \"nfcCompatible\": \"\",\r\n" + "            \"solderedSim\": \"\",\r\n"
				+ "            \"simCapable\": \"DUAL_IMSI\",\r\n"
				+ "            \"selfActivationCapableInd\": null,\r\n" + "            \"lsClientId\": \"\",\r\n"
				+ "            \"lsCustomerId\": \"\",\r\n" + "            \"lsBillAcctNumber\": \"\",\r\n"
				+ "            \"saleRetailer\": \"\",\r\n" + "            \"simSkuType\": \"T\",\r\n"
				+ "            \"personalizedStatus\": \"\",\r\n" + "            \"personalizedTimeStamp\": \"\"\r\n"
				+ "        },\r\n" + "        \"deviceSimCompatible\": \"Y\",\r\n"
				+ "        \"deviceSimM2MPair\": \"N\",\r\n" + "        \"deviceESimCompatible\": \"\",\r\n"
				+ "        \"deviceEsimM2MPair\": \"Y\",\r\n" + "        \"esimInfo\": {\r\n"
				+ "            \"mfgCode\": \"\",\r\n" + "            \"launchPackageSku\": \"\",\r\n"
				+ "            \"prodName\": \"\",\r\n" + "            \"preferredSoftSim\": \"SOFTNASIM-MP-D\",\r\n"
				+ "            \"launchPackageSkuType\": \"\",\r\n" + "            \"pairedIccid\": \"\",\r\n"
				+ "            \"eID\": \"89049032003008882300001955592066\"\r\n" + "        }\r\n" + "    }\r\n" + "}";
		DeviceSimDetailsUIResponse response = mapper.readValue(sampleResponseString, DeviceSimDetailsUIResponse.class);
		String addDeviceStr = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1596531-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"},{\"path\":\"FeatureConflicts\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"registerNumber\":0,\"accountNumber\":\"0220561307-00002\",\"cartCreator\":\"8439410557\",\"processingMTN\":\"8439292610\"},\"cartInfo\":{\"method\":\"\",\"financeLimitExceeded\":\"false\",\"cartId\":\"9c43a538-bcd8-4c1f-b271-6eb043271223\",\"clientAppName\":\"VZW-NETACE\",\"statusCode\":\"1\",\"statusMsg\":\"Success\",\"lines\":[{\"plan\":{},\"status\":1,\"errors\":[],\"spos\":[{\"id\":\"1167\",\"actionIndicator\":\"Z\",\"success\":true,\"is5GBolt\":false}],\"sfos\":[],\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"mtn\":\"8439292610\",\"device\":{\"cartItemType\":\"\",\"quantityOnHand\":\"\",\"upgradeReasonCode\":\"\",\"id\":\"MQ722LL/A\",\"description\":\"\",\"itemPrice\":\"449.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"discounts\":\"\",\"existingDeviceId\":\"\",\"existingDeviceName\":\"iPhone&reg; 8\",\"removedFeatures\":\"\",\"fiveGToFourGDownGrade\":false},\"sim\":{\"simId\":\"\",\"id\":\"EMBD4GSIM-N\"},\"warranty\":{\"id\":\"\",\"itemPrice\":\"0.0\",\"discounts\":\"\"},\"upgradeFee\":{\"id\":\"\",\"itemPrice\":\"\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"AAL\",\"currentPlanType\":\"ALP\"}],\"expressCheckout\":false,\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false},\"processMTNList\":[{\"mtn\":\"8439292610\",\"completedprocessSteps\":[\"pastDuePage\",\"MTNSelectionPage\",\"InterimPage\",\"GridWallPDP\",\"GridWallPDP\",\"MTNSelectionPage\",\"InterimPage\",\"GridWallPDP\",\"GridWallPDP\",\"GridWallPDP\"]}]}}}}";
		AddDeviceUIResponse responseServiceMono = mapper.readValue(addDeviceStr, AddDeviceUIResponse.class);
		when(redisHelper2.upsertAccountInfoEligibleInRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
		URI url = URI.create("http://localhost/startBBPFlow");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = null;
		String bbpRequestVOString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"iccid\":\"89148000000835900342\",\"imei\":\"352898071702915\",\"isSmartphone\":true}";
		BBPRequestVO bbpRequestVO = mapper.readValue(bbpRequestVOString, BBPRequestVO.class);
		when(cartHelper.initiateBBPFlow(Mockito.any())).thenReturn(Mono.just(response));
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(responseServiceMono));
		when(redisHelper2.upsertBBPFlowDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
		when(redisHelper2.upsertAddDeviceDataIntoRedis(Mockito.any())).thenReturn(Mono.just(new CartRedisData()));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.startBBPFlow(httpHeader, httpResponse,
				bbpRequestVO);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void bbpGetProcessStepTest() throws IOException {

		String sampleRequestString = "{\r\n" + "   \"cartInfo\":{\r\n"
				+ "      \"clientAppName\":\"VZW-DOTCOM-BBP\",\r\n"
				+ "  \"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\r\n" + "      \"accountNumber\":\"\",\r\n"
				+ "      \"cartCreator\":\"\",\r\n" + "      \"cartId\":\"\",\r\n" + "      \"caseId\":\"\",\r\n"
				+ "      \"processingMTN\":\"newLine1\",\r\n" + "      \"processStep\":\"NumberSelection\",\r\n"
				+ "      \"processAction\":\"ChangeLocation\"\r\n" + "   }\r\n" + "}\r\n" + "";
		BBPGetProcessStepUIRequest bbpgetprocessstepUiRequest = mapper.readValue(sampleRequestString,
				BBPGetProcessStepUIRequest.class);
		String sampleResponseString = "{\r\n" + "   \"serviceHeader\":{\r\n"
				+ "      \"clientId\":\"VZW-DOTCOM-BBP\",\r\n" + "      \"statusMsg\":\"PEGA generated message\",\r\n"
				+ "      \"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\r\n" + "      \"sessionId\":\"\",\r\n"
				+ "      \"serviceName\":\"SalesOrderPurchase\",\r\n" + "      \"userId\":\"\",\r\n"
				+ "      \"statusCode\":\"0\"\r\n" + "   },\r\n" + "   \"serviceBody\":{\r\n"
				+ "      \"serviceResponse\":{\r\n" + "         \"context\":{\r\n"
				+ "            \"caseId\":\" SOP-1583186-DEV3\",\r\n" + "            \"customerInfo\":{\r\n"
				+ "               \"accountNumber\":\"07893451230-00001\",\r\n"
				+ "               \"cartCreator\":\"2515813861\",\r\n"
				+ "               \"processingMTN\":\"2515813860\"\r\n" + "            },\r\n"
				+ "            \"processMTNList\":[\r\n" + "               {\r\n"
				+ "                  \"mtn\":\"2515813860\",\r\n" + "                  \"completedprocessSteps\":[\r\n"
				+ "                     \"Initiate\",\r\n" + "                     \"AccountPlanPage\"\r\n"
				+ "                  ]\r\n" + "               }\r\n" + "            ],\r\n"
				+ "            \"cartInfo\":{\r\n"
				+ "               \"cartId\":\"582841fa-068c-4a85-bf0c-4123eccd8b23\"\r\n" + "            },\r\n"
				+ "            \"contextInfo\":{\r\n" + "               \"processAction\":\"\",\r\n"
				+ "               \"processStep\":\"LocationDetails\",\r\n" + "               \"availablePaths\":[\r\n"
				+ "                  {\r\n" + "                     \"path\":\"LocationDetails\"\r\n"
				+ "                  }\r\n" + "               ],\r\n"
				+ "               \"callReason\":\"SalesOrderPurchase\"\r\n" + "            }\r\n" + "         }\r\n"
				+ "      }\r\n" + "   }\r\n" + "}";
		BbpGetProcessStepUIResponse bbpgetprocessstepUiResponse = mapper.readValue(sampleResponseString,
				BbpGetProcessStepUIResponse.class);
		when(cartHelper.bbpGetProcessStep(Mockito.any())).thenReturn(Mono.just(bbpgetprocessstepUiResponse));
		URI url = URI.create("http://localhost/bbpGetProcessStep");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = null;
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.bbpGetProcessStep(httpHeader,
				httpResponse, bbpgetprocessstepUiRequest);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void bbpGetProcessStepTest1() throws IOException {

		String sampleRequestString = "{\r\n" + "   \"cartInfo\":{\r\n"
				+ "      \"clientAppName\":\"VZW-DOTCOM-BBP\",\r\n"
				+ "  \"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\r\n" + "      \"accountNumber\":\"\",\r\n"
				+ "      \"cartCreator\":\"\",\r\n" + "      \"cartId\":\"\",\r\n" + "      \"caseId\":\"\",\r\n"
				+ "      \"processingMTN\":\"newLine1\",\r\n" + "      \"processStep\":\"NumberSelection\",\r\n"
				+ "      \"processAction\":\"ChangeLocation\"\r\n" + "   }\r\n" + "}\r\n" + "";
		BBPGetProcessStepUIRequest bbpgetprocessstepUiRequest = mapper.readValue(sampleRequestString,
				BBPGetProcessStepUIRequest.class);
		String sampleResponseString = "{\r\n" + "   \"serviceHeader\":{\r\n"
				+ "      \"clientId\":\"VZW-DOTCOM-BBP\",\r\n" + "      \"statusMsg\":\"PEGA generated message\",\r\n"
				+ "      \"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\r\n" + "      \"sessionId\":\"\",\r\n"
				+ "      \"serviceName\":\"SalesOrderPurchase\",\r\n" + "      \"userId\":\"\",\r\n"
				+ "      \"statusCode\":\"0\"\r\n" + "   },\r\n" + "   \"serviceBody\":{\r\n"
				+ "      \"serviceResponse\":{\r\n" + "         \"context\":{\r\n"
				+ "            \"caseId\":\" SOP-1583186-DEV3\",\r\n" + "            \"customerInfo\":{\r\n"
				+ "               \"accountNumber\":\"07893451230-00001\",\r\n"
				+ "               \"cartCreator\":\"2515813861\",\r\n"
				+ "               \"processingMTN\":\"2515813860\"\r\n" + "            },\r\n"
				+ "            \"processMTNList\":[\r\n" + "               {\r\n"
				+ "                  \"mtn\":\"2515813860\",\r\n" + "                  \"completedprocessSteps\":[\r\n"
				+ "                     \"Initiate\",\r\n" + "                     \"AccountPlanPage\"\r\n"
				+ "                  ]\r\n" + "               }\r\n" + "            ],\r\n"
				+ "            \"cartInfo\":{\r\n"
				+ "               \"cartId\":\"582841fa-068c-4a85-bf0c-4123eccd8b23\"\r\n" + "            },\r\n"
				+ "            \"contextInfo\":{\r\n" + "               \"processAction\":\"\",\r\n"
				+ "               \"processStep\":\"LocationDetails\",\r\n" + "               \"availablePaths\":[\r\n"
				+ "                  {\r\n" + "                     \"path\":\"LocationDetails\"\r\n"
				+ "                  }\r\n" + "               ],\r\n"
				+ "               \"callReason\":\"SalesOrderPurchase\"\r\n" + "            }\r\n" + "         }\r\n"
				+ "      }\r\n" + "   }\r\n" + "}";
		BbpGetProcessStepUIResponse bbpgetprocessstepUiResponse = mapper.readValue(sampleResponseString,
				BbpGetProcessStepUIResponse.class);
		when(cartHelper.bbpGetProcessStep(Mockito.any())).thenReturn(Mono.just(bbpgetprocessstepUiResponse));
		URI url = URI.create("http://localhost/nse/bbpGetProcessStep");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session","sdfdsfa34234")).build();
		ServerHttpResponse httpResponse = null;
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.bbpGetProcessStep(httpHeader,
				httpResponse, bbpgetprocessstepUiRequest);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void bbpGetProcessStepTest2() throws IOException {

		String sampleRequestString = "{\r\n" + "   \"cartInfo\":{\r\n"
				+ "      \"clientAppName\":\"VZW-DOTCOM-BBP\",\r\n"
				+ "  \"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\r\n" + "      \"accountNumber\":\"\",\r\n"
				+ "      \"cartCreator\":\"\",\r\n" + "      \"cartId\":\"\",\r\n" + "      \"caseId\":\"\",\r\n"
				+ "      \"processingMTN\":\"newLine1\",\r\n" + "      \"processStep\":\"NumberSelection\",\r\n"
				+ "      \"processAction\":\"ChangeLocation\"\r\n" + "   }\r\n" + "}\r\n" + "";
		BBPGetProcessStepUIRequest bbpgetprocessstepUiRequest = mapper.readValue(sampleRequestString,
				BBPGetProcessStepUIRequest.class);
		String sampleResponseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
		BbpGetProcessStepUIResponse bbpgetprocessstepUiResponse = mapper.readValue(sampleResponseString,
				BbpGetProcessStepUIResponse.class);
		when(cartHelper.bbpGetProcessStep(Mockito.any())).thenReturn(Mono.just(bbpgetprocessstepUiResponse));
		URI url = URI.create("http://localhost/nse/bbpGetProcessStep");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session","sdfdsfa34234")).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.bbpGetProcessStep(httpHeader,
				httpResponse, bbpgetprocessstepUiRequest);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}
	
	
	@Test
	public void bbpAddZipcodeTest() throws IOException {
		AddZipCodeUIRequest addZipcodeUiRequest = new AddZipCodeUIRequest();
		addZipcodeUiRequest.setZipCode("30329");
		when(redisHelper2.upsertBBPFlowZipCodeDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
		URI url = URI.create("http://localhost/bbpAddZipcode");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = null;
		Mono<ResponseEntity<AddZipcodeRedisData>> controllerResponse = cartController.bbpAddZipCode(httpHeader, httpResponse,
				addZipcodeUiRequest);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}
	
	@Test
	public void bbpAddZipcode_Failure_Test() throws IOException {
		AddZipCodeUIRequest addZipcodeUiRequest = new AddZipCodeUIRequest();
		addZipcodeUiRequest.setZipCode("30329");
		when(redisHelper2.upsertBBPFlowZipCodeDataIntoRedis(Mockito.any())).thenReturn(Mono.just(false));
		URI url = URI.create("http://localhost/bbpAddZipcode");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = null;
		Mono<ResponseEntity<AddZipcodeRedisData>> controllerResponse = cartController.bbpAddZipCode(httpHeader, httpResponse,
				addZipcodeUiRequest);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}
	
	@Test
	public void salesOrderAdjustmentTest() throws IOException {

		String sampleRequestString = "{\"cartInfo\":{\"creditValidationRequired\":true,\"intent\":\"SalesOrderAdjustment\",\"processStep\":\"TransactionSelectionPage\",\"processAction\":\"Flex\",\"intendType\":\"REX\",\"cartId\":\"603f0368-61cd-4df1-9864-8b6893412ad9\",\"caseId\":\"SOA-2297493-E01\",\"salesRepId\":\"ENC\",\"cartCreatorLocationCode\":\"0026301\",\"accountNumber\":\"0213129788-00001\",\"cartCreator\":\"1130201\"},\"data\":{\"lines\":{\"lineInfo\":[{\"mtnDetails\":{\"mobileNumber\":\"9086667138\",\"lineNumber\":\"9086667138\"},\"multiLineSeqNumber\":\"1\",\"items\":[{\"itemCode\":\"SMG973UZKV\",\"fmiCheckRequired\":true,\"newInUnopenBox\":false,\"cartItemType\":\"DEVICE\",\"qty\":\"1\",\"itemSeqNumber\":\"1\",\"returnType\":\"R\",\"refundType\":\"RE\",\"returnReason\":{\"returnType\":\"W\",\"primaryReasonCode\":\"70\",\"secondaryReasonCode\":\"72\",\"symptoms\":\"Test\"}}]}]},\"addressValidationRequired\":true}}";
		SalesOrderAdjustmentUIRequest salesOrderAdjustmentUiRequest = mapper.readValue(sampleRequestString,
				SalesOrderAdjustmentUIRequest.class);
		String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-RETAIL\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderAdjustment\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2021.02.11.09.37.10-282.7539943194171\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOA-2297493-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShopLandingPage\"}],\"callReason\":\"SalesOrderAdjustment\",\"processStep\":\"ShopLandingPage\"},\"customerInfo\":{\"accountNumber\":\"0213129788-00001\",\"cartCreator\":\"9086667138\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"refundOrderDetails\":{\"lines\":{\"lineInfo\":[{\"lineActivityType\":\"REX\",\"mtnDetails\":{\"lineNumber\":\"9086667138\",\"mobileNumber\":\"9086667138\"},\"multiLineSeqNumber\":\"1\",\"items\":[{}]}]}},\"cartId\":\"603f0368-61cd-4df1-9864-8b6893412ad9\",\"statusCode\":\"1\",\"statusMsg\":\"Success\",\"discountPromoTotal\":0.0,\"registerNumber\":0}}}}}";
		SalesOrderAdjustmentUIResponse salesOrderAdjustmentUiResponse = mapper.readValue(sampleResponseString,
				SalesOrderAdjustmentUIResponse.class);
		when(cartHelper.salesOrderAdjustment(Mockito.any())).thenReturn(Mono.just(salesOrderAdjustmentUiResponse));
		URI url = URI.create("http://localhost/salesOrderAdjustment");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = null;
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.salesOrderAdjustment(httpHeader,
				httpResponse, salesOrderAdjustmentUiRequest);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}
	@Test
	public void salesOrderAdjustmentTest1() throws IOException {

		String sampleRequestString = "{\"cartInfo\":{\"creditValidationRequired\":true,\"intent\":\"SalesOrderAdjustment\",\"processStep\":\"\",\"processAction\":\"Flex\",\"intendType\":\"null\",\"cartId\":\"603f0368-61cd-4df1-9864-8b6893412ad9\",\"caseId\":\"SOA-2297493-E01\",\"salesRepId\":\"ENC\",\"cartCreatorLocationCode\":\"0026301\",\"accountNumber\":\"0213129788-00001\",\"cartCreator\":\"1130201\"},\"data\":{\"lines\":{\"lineInfo\":[{\"mtnDetails\":{\"mobileNumber\":\"9086667138\",\"lineNumber\":\"9086667138\"},\"multiLineSeqNumber\":\"1\",\"items\":[{\"itemCode\":\"SMG973UZKV\",\"fmiCheckRequired\":true,\"newInUnopenBox\":false,\"cartItemType\":\"DEVICE\",\"qty\":\"1\",\"itemSeqNumber\":\"1\",\"returnType\":\"R\",\"refundType\":\"RE\",\"returnReason\":{\"returnType\":\"W\",\"primaryReasonCode\":\"70\",\"secondaryReasonCode\":\"72\",\"symptoms\":\"Test\"}}]}]},\"addressValidationRequired\":true}}";
		SalesOrderAdjustmentUIRequest salesOrderAdjustmentUiRequest = mapper.readValue(sampleRequestString,
				SalesOrderAdjustmentUIRequest.class);
		String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-RETAIL\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderAdjustment\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2021.02.11.09.37.10-282.7539943194171\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOA-2297493-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShopLandingPage\"}],\"callReason\":\"SalesOrderAdjustment\",\"processStep\":\"ShopLandingPage\"},\"customerInfo\":{\"accountNumber\":\"0213129788-00001\",\"cartCreator\":\"9086667138\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"refundOrderDetails\":{\"lines\":{\"lineInfo\":[{\"lineActivityType\":\"REX\",\"mtnDetails\":{\"lineNumber\":\"9086667138\",\"mobileNumber\":\"9086667138\"},\"multiLineSeqNumber\":\"1\",\"items\":[{}]}]}},\"cartId\":\"603f0368-61cd-4df1-9864-8b6893412ad9\",\"statusCode\":\"1\",\"statusMsg\":\"Success\",\"discountPromoTotal\":0.0,\"registerNumber\":0}}}}}";
		SalesOrderAdjustmentUIResponse salesOrderAdjustmentUiResponse = mapper.readValue(sampleResponseString,
				SalesOrderAdjustmentUIResponse.class);
		when(cartHelper.salesOrderAdjustment(Mockito.any())).thenReturn(Mono.just(salesOrderAdjustmentUiResponse));
		URI url = URI.create("http://localhost/salesOrderAdjustment");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZ-DOTCOM").build();
		ServerHttpResponse httpResponse = null;
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.salesOrderAdjustment(httpHeader,
				httpResponse, salesOrderAdjustmentUiRequest);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void validateE911AddressTest() throws IOException {

		String sampleRequestString = "{\"addressLine1\":\"140 ELGIN BLVD\",\"addressLine2\":\"\",\"state\":\"FL\",\"city\":\"DAVENPORT\",\"zipCode\":\"33897\",\"type\":\"e911\"}";
		RPSE911AddressUpdateUIRequest request = mapper.readValue(sampleRequestString, RPSE911AddressUpdateUIRequest.class);
		String cxpResponseString = "{\"data\":{\"validateAddress\":{\"e911Address\":{\"validAddress\":true,\"statusCode\":\"VALID\",\"statusDescription\":\"Address is valid\"}}},\"meta\":{\"timestamp\":\"1663669865301\",\"cxpCorrelationId\":\"2022-09-20T10:31:05.+0000:7d3fce51965eab3f:cxp-address-services-qa-ev6v-sit2w-nscxp-b8c85c498-7fff2:nssit2\"}}";
		ValidateE911AddressCXPResponse cxpResponse = mapper.readValue(cxpResponseString, ValidateE911AddressCXPResponse.class);
		URI url = URI.create("http://localhost/validateE911Address");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = null;
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.validateE911Address(httpHeader,
				httpResponse, request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void validateE911AddressTest2() throws IOException {

		String sampleRequestString = "{\"addressLine1\":\"140 ELGIN BLVD\",\"addressLine2\":\"\",\"state\":\"FL\",\"city\":\"DAVENPORT\",\"cityName\":\"DAVENPORT\",\"zipCode\":\"33897\",\"type\":\"e911\"}";
		RPSE911AddressUpdateUIRequest request = mapper.readValue(sampleRequestString, RPSE911AddressUpdateUIRequest.class);
		String cxpResponseString = "{\"data\":{\"validateAddress\":{\"e911Address\":{\"validAddress\":true,\"statusCode\":\"VALID\",\"statusDescription\":\"Address is valid\"}}},\"meta\":{\"timestamp\":\"1663669865301\",\"cxpCorrelationId\":\"2022-09-20T10:31:05.+0000:7d3fce51965eab3f:cxp-address-services-qa-ev6v-sit2w-nscxp-b8c85c498-7fff2:nssit2\"}}";
		ValidateE911AddressCXPResponse cxpResponse = mapper.readValue(cxpResponseString, ValidateE911AddressCXPResponse.class);
		URI url = URI.create("http://localhost/validateE911Address");
		when(cxpService.getValidateAddress(Mockito.any())).thenReturn(Mono.just(cxpResponse));
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = null;
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.validateE911Address(httpHeader,
				httpResponse, request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void validateE911AddressTest3() throws IOException {

		String sampleRequestString = "{\"addressLine1\":\"140 ELGIN BLVD\",\"addressLine2\":\"\",\"state\":\"FL\",\"city\":\"DAVENPORT\",\"cityName\":\"DAVENPORT\",\"zipCode\":\"33897\",\"type\":\"e911\"}";
		RPSE911AddressUpdateUIRequest request = mapper.readValue(sampleRequestString, RPSE911AddressUpdateUIRequest.class);
		String cxpResponseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
		ValidateE911AddressCXPResponse cxpResponse = mapper.readValue(cxpResponseString, ValidateE911AddressCXPResponse.class);
		URI url = URI.create("http://localhost/validateE911Address");
		when(cxpService.getValidateAddress(Mockito.any())).thenReturn(Mono.just(cxpResponse));
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.validateE911Address(httpHeader,
				httpResponse, request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

    @Test
    public void validateE911AddressTest4() throws IOException {

        String sampleRequestString = "{\"addressLine1\":\"1 VERIZON WAY\",\"addressLine2\":\"\",\"cityName\":\"BASKING RIDGE\",\"state\":\"NJ\",\"zipCode\":\"07920\",\"mtn\":null,\"orderNumber\":null,\"lineItemNumber\":null,\"channelID\":\"VZW-NUMBERLINK\"}";
        RPSE911AddressUpdateUIRequest validateE911AddressUIRequest = mapper.readValue(sampleRequestString,
                RPSE911AddressUpdateUIRequest.class);
        String sampleResponseString = "{\"errors\":[{\"namespace\":\"CartService\",\"id\":\"c100\"}]}";
        ValidateE911AddressCXPResponse cxpResponse = mapper.readValue(sampleResponseString,
                ValidateE911AddressCXPResponse.class);
        when(cxpService.getValidateAddress(Mockito.any())).thenReturn(Mono.just(cxpResponse));
        URI url = URI.create("http://localhost/validateE911Address");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.validateE911Address(httpHeader,
                httpResponse, validateE911AddressUIRequest);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }
    @Test
    public void bbpPayloadTest1() throws IOException {
        BBPPayloadUIRequest bbpPayloadUiRequest = new BBPPayloadUIRequest();
        bbpPayloadUiRequest.setIccid("89148000000835900458");
        bbpPayloadUiRequest.setImei("352898071702915");
        bbpPayloadUiRequest.setIsSmartphone(false);
        bbpPayloadUiRequest.setTechType("DEVICE4GSELF");
        bbpPayloadUiRequest.setSkipUserAgent(true);
        when(redisHelper2.upsertBBPFlowDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        URI url = URI.create("http://localhost/nse/bbpPayload");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<Object>> controllerResponse = cartController.bbpPayload(httpHeader, httpResponse,
                bbpPayloadUiRequest);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }


    @Test
    public void bbpPayloadErrorTest1() throws IOException {
        BBPPayloadUIRequest bbpPayloadUiRequest = new BBPPayloadUIRequest();
        bbpPayloadUiRequest.setImei2("352898071702915");
        bbpPayloadUiRequest.setTechType("DEVICE4GSELF");
        bbpPayloadUiRequest.setSkipUserAgent(true);
        when(redisHelper2.upsertBBPFlowDataIntoRedis(Mockito.any())).thenReturn(Mono.just(false));
        //URI url = URI.create("http://localhost/bbpPayload");
        URI url = URI.create("");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST,url).build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<Object>> controllerResponse = cartController.bbpPayload(httpHeader, httpResponse,
                bbpPayloadUiRequest);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }




    @Test
    public void startBBPFlowTest2() throws IOException {
        String sampleResponseString = "{\r\n" + "    \"uiMeta\": {\r\n" + "        \"timestamp\": 1606904076236,\r\n"
                + "        \"cxpCorrelationId\": \"2020-12-02T10:14:36.+0000:90be2abf-a4e2-4e0e-8fcb-4edcdee0a1e6:cxp-customerprofile-se-qa-ev6v-sit4w-nscxp-756b46467b-5z5q6:nssit4\"\r\n"
                + "    },\r\n" + "    \"uiData\": {\r\n" + "        \"deviceInfo\": {\r\n"
                + "            \"deviceId\": \"359433083362780\",\r\n" + "            \"mfgCode\": \"APL\",\r\n"
                + "            \"prodName\": \"APPLE WATCH S3 42 SPBLK MIL\",\r\n"
                + "            \"prodType\": \"ConnectedDevice\",\r\n" + "            \"eqpModeCode\": \"4GE\",\r\n"
                + "            \"eqpMode\": \"4G\",\r\n" + "            \"ems\": \"N\",\r\n"
                + "            \"mms\": \"Y\",\r\n" + "            \"gps\": \"Y\",\r\n"
                + "            \"ptt\": \"N\",\r\n" + "            \"globalPhone\": \"O\",\r\n"
                + "            \"wap\": \"N/A\",\r\n" + "            \"bluetooth\": \"Y\",\r\n"
                + "            \"brew\": \"N\",\r\n" + "            \"trustedMode\": \"N\",\r\n"
                + "            \"csim\": \"\",\r\n" + "            \"ehrpd\": \"N\",\r\n"
                + "            \"smsevdo\": \"N\",\r\n" + "            \"deviceCategory\": \"4G Connected Device\",\r\n"
                + "            \"visionProdId\": \"38940\",\r\n" + "            \"preferredSim\": \"\",\r\n"
                + "            \"backupAssistCapable\": \"N\",\r\n" + "            \"simClass4G\": \"NR\",\r\n"
                + "            \"virtualSimSku\": \"\",\r\n" + "            \"deviceNoPay\": \"N\",\r\n"
                + "            \"deviceLostStolen\": \"N\",\r\n" + "            \"deviceSdmLock\": \"\",\r\n"
                + "            \"deviceLock\": \"\",\r\n" + "            \"devicePibLock\": \"\",\r\n"
                + "            \"prepayEligibility\": \"00\",\r\n" + "            \"eligibilityDate\": \"\",\r\n"
                + "            \"outletId\": \"\",\r\n" + "            \"dacc\": \"01032\",\r\n"
                + "            \"deviceType\": \"4GE\",\r\n" + "            \"provTechType\": \"LTE\",\r\n"
                + "            \"launchPackageSku\": \"MR1L2LL/A\",\r\n" + "            \"imSku\": \"MR1L2LL/A\",\r\n"
                + "            \"deviceCapabilityInd\": \"VD\",\r\n" + "            \"nfcCapable\": \"Y\",\r\n"
                + "            \"nfcCompatible\": \"Y\",\r\n" + "            \"pibDevice\": \"N\",\r\n"
                + "            \"connectedDeviceInd\": null,\r\n"
                + "            \"deviceFamilyType\": \"Connected\",\r\n"
                + "            \"buddyUpgrdEligInd\": \"N\",\r\n" + "            \"restrictToFamilyInd\": \"Y\",\r\n"
                + "            \"nonGeoDeviceInd\": \"\",\r\n" + "            \"m2MAllow\": \"M2MC\",\r\n"
                + "            \"hdVoice\": \"Y\",\r\n" + "            \"alkDevice\": \"HD\",\r\n"
                + "            \"shipDate\": \"20-DEC-2017\",\r\n" + "            \"cpo\": \"N\",\r\n"
                + "            \"lsClientId\": \"\",\r\n" + "            \"lsCustomerId\": \"\",\r\n"
                + "            \"lsBillAcctNumber\": \"\",\r\n" + "            \"v4B\": \"\",\r\n"
                + "            \"icEligInd\": \"\",\r\n" + "            \"icRemDays\": \"\",\r\n"
                + "            \"icRemSubsidyAmt\": \"\",\r\n" + "            \"e911AddrInd\": \"Y\",\r\n"
                + "            \"euiccCapable\": \"Y\",\r\n" + "            \"numberShareCapability\": \"Y\",\r\n"
                + "            \"wifiCalling\": \"Y\",\r\n" + "            \"vvm\": \"N\",\r\n"
                + "            \"imei1\": \"\",\r\n" + "            \"imei2\": \"\",\r\n"
                + "            \"osType\": \"WatchOS4\",\r\n" + "            \"postpaidRestrictStartDate\": \"\",\r\n"
                + "            \"dsEs12Fqdn\": \"\"\r\n" + "        },\r\n" + "        \"simInfo\": {\r\n"
                + "            \"simId\": \"89148000000751553653\",\r\n" + "            \"mfgCode\": \"GTO\",\r\n"
                + "            \"prodName\": \"Gemalto 4FF NFC SIM - DF\",\r\n" + "            \"simGroup\": \"\",\r\n"
                + "            \"prodType\": \"4G_4FF_SIM\",\r\n" + "            \"simFormFactor\": \"\",\r\n"
                + "            \"simNoPay\": \"N\",\r\n" + "            \"simLostStolen\": \"N\",\r\n"
                + "            \"simLock\": \"\",\r\n" + "            \"simPibLock\": \"\",\r\n"
                + "            \"outletId\": \"\",\r\n" + "            \"sacc\": \"00722\",\r\n"
                + "            \"simType\": \"4GS\",\r\n" + "            \"iccidStatus\": \"AA\",\r\n"
                + "            \"numberLocation\": \"\",\r\n" + "            \"provTechType\": \"LTE\",\r\n"
                + "            \"launchPackageSku\": \"DFILL4FF-NFC-A\",\r\n"
                + "            \"imSku\": \"DFILL4FF-NFC-A\",\r\n" + "            \"nfcCapable\": \"Y\",\r\n"
                + "            \"nfcCompatible\": \"\",\r\n" + "            \"solderedSim\": \"\",\r\n"
                + "            \"simCapable\": \"DUAL_IMSI\",\r\n"
                + "            \"selfActivationCapableInd\": null,\r\n" + "            \"lsClientId\": \"\",\r\n"
                + "            \"lsCustomerId\": \"\",\r\n" + "            \"lsBillAcctNumber\": \"\",\r\n"
                + "            \"saleRetailer\": \"\",\r\n" + "            \"simSkuType\": \"T\",\r\n"
                + "            \"personalizedStatus\": \"\",\r\n" + "            \"personalizedTimeStamp\": \"\"\r\n"
                + "        },\r\n" + "        \"deviceSimCompatible\": \"Y\",\r\n"
                + "        \"deviceSimM2MPair\": \"N\",\r\n" + "        \"deviceESimCompatible\": \"\",\r\n"
                + "        \"deviceEsimM2MPair\": \"Y\",\r\n" + "        \"esimInfo\": {\r\n"
                + "            \"mfgCode\": \"\",\r\n" + "            \"launchPackageSku\": \"\",\r\n"
                + "            \"prodName\": \"\",\r\n" + "            \"preferredSoftSim\": \"SOFTNASIM-MP-D\",\r\n"
                + "            \"launchPackageSkuType\": \"\",\r\n" + "            \"pairedIccid\": \"\",\r\n"
                + "            \"eID\": \"89049032003008882300001955592066\"\r\n" + "        }\r\n" + "    }\r\n" + "}";
        DeviceSimDetailsUIResponse response = mapper.readValue(sampleResponseString, DeviceSimDetailsUIResponse.class);
        String addDeviceStr = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1596531-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"},{\"path\":\"FeatureConflicts\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"registerNumber\":0,\"accountNumber\":\"0220561307-00002\",\"cartCreator\":\"8439410557\",\"processingMTN\":\"8439292610\"},\"cartInfo\":{\"method\":\"\",\"financeLimitExceeded\":\"false\",\"cartId\":\"9c43a538-bcd8-4c1f-b271-6eb043271223\",\"clientAppName\":\"VZW-NETACE\",\"statusCode\":\"1\",\"statusMsg\":\"Success\",\"lines\":[{\"plan\":{},\"status\":1,\"errors\":[],\"spos\":[{\"id\":\"1167\",\"actionIndicator\":\"Z\",\"success\":true,\"is5GBolt\":false}],\"sfos\":[],\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"mtn\":\"8439292610\",\"device\":{\"cartItemType\":\"\",\"quantityOnHand\":\"\",\"upgradeReasonCode\":\"\",\"id\":\"MQ722LL/A\",\"description\":\"\",\"itemPrice\":\"449.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"discounts\":\"\",\"existingDeviceId\":\"\",\"existingDeviceName\":\"iPhone&reg; 8\",\"removedFeatures\":\"\",\"fiveGToFourGDownGrade\":false},\"sim\":{\"simId\":\"\",\"id\":\"EMBD4GSIM-N\"},\"warranty\":{\"id\":\"\",\"itemPrice\":\"0.0\",\"discounts\":\"\"},\"upgradeFee\":{\"id\":\"\",\"itemPrice\":\"\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"AAL\",\"currentPlanType\":\"ALP\"}],\"expressCheckout\":false,\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false},\"processMTNList\":[{\"mtn\":\"8439292610\",\"completedprocessSteps\":[\"pastDuePage\",\"MTNSelectionPage\",\"InterimPage\",\"GridWallPDP\",\"GridWallPDP\",\"MTNSelectionPage\",\"InterimPage\",\"GridWallPDP\",\"GridWallPDP\",\"GridWallPDP\"]}]}}}}";
        AddDeviceUIResponse responseServiceMono = mapper.readValue(addDeviceStr, AddDeviceUIResponse.class);
		CartRedisData cartRedisData = new CartRedisData();
		cartRedisData.setEsimFlowType(CartConstants.LOST_ICCID_PROFILE);
		cartRedisData.setPendingMdn("9392y435352");
        when(redisHelper2.upsertAccountInfoEligibleInRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(cartRedisData));
        URI url = URI.create("");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        String bbpRequestVOString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"iccid\":\"89148000000835900342\",\"imei\":\"352898071702915\"}";
        BBPRequestVO bbpRequestVO = mapper.readValue(bbpRequestVOString, BBPRequestVO.class);
        when(cartHelper.initiateBBPFlow(Mockito.any())).thenReturn(Mono.just(response));
        when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(responseServiceMono));
        when(redisHelper2.upsertBBPFlowDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.upsertAddDeviceDataIntoRedis(Mockito.any())).thenReturn(Mono.just(cartRedisData));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.startBBPFlow(httpHeader, httpResponse,
                bbpRequestVO);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void startBBPFlowTest3() throws IOException {
        String sampleResponseString = "{\r\n" + "    \"uiMeta\": {\r\n" + "        \"timestamp\": 1606904076236,\r\n"
                + "        \"cxpCorrelationId\": \"2020-12-02T10:14:36.+0000:90be2abf-a4e2-4e0e-8fcb-4edcdee0a1e6:cxp-customerprofile-se-qa-ev6v-sit4w-nscxp-756b46467b-5z5q6:nssit4\"\r\n"
                + "    },\r\n" + "    \"uiData\": {\r\n" + "        \"deviceInfo\": {\r\n"
                + "            \"deviceId\": \"359433083362780\",\r\n" + "            \"mfgCode\": \"APL\",\r\n"
                + "            \"prodName\": \"APPLE WATCH S3 42 SPBLK MIL\",\r\n"
                + "            \"prodType\": \"ConnectedDevice\",\r\n" + "            \"eqpModeCode\": \"4GE\",\r\n"
                + "            \"eqpMode\": \"4G\",\r\n" + "            \"ems\": \"N\",\r\n"
                + "            \"mms\": \"Y\",\r\n" + "            \"gps\": \"Y\",\r\n"
                + "            \"ptt\": \"N\",\r\n" + "            \"globalPhone\": \"O\",\r\n"
                + "            \"wap\": \"N/A\",\r\n" + "            \"bluetooth\": \"Y\",\r\n"
                + "            \"brew\": \"N\",\r\n" + "            \"trustedMode\": \"N\",\r\n"
                + "            \"csim\": \"\",\r\n" + "            \"ehrpd\": \"N\",\r\n"
                + "            \"smsevdo\": \"N\",\r\n" + "            \"deviceCategory\": \"4G Connected Device\",\r\n"
                + "            \"visionProdId\": \"38940\",\r\n" + "            \"preferredSim\": \"\",\r\n"
                + "            \"backupAssistCapable\": \"N\",\r\n" + "            \"simClass4G\": \"NR\",\r\n"
                + "            \"virtualSimSku\": \"\",\r\n" + "            \"deviceNoPay\": \"N\",\r\n"
                + "            \"deviceLostStolen\": \"N\",\r\n" + "            \"deviceSdmLock\": \"\",\r\n"
                + "            \"deviceLock\": \"\",\r\n" + "            \"devicePibLock\": \"\",\r\n"
                + "            \"prepayEligibility\": \"00\",\r\n" + "            \"eligibilityDate\": \"\",\r\n"
                + "            \"outletId\": \"\",\r\n" + "            \"dacc\": \"01032\",\r\n"
                + "            \"deviceType\": \"4GE\",\r\n" + "            \"provTechType\": \"LTE\",\r\n"
                + "            \"launchPackageSku\": \"MR1L2LL/A\",\r\n" + "            \"imSku\": \"MR1L2LL/A\",\r\n"
                + "            \"deviceCapabilityInd\": \"VD\",\r\n" + "            \"nfcCapable\": \"Y\",\r\n"
                + "            \"nfcCompatible\": \"Y\",\r\n" + "            \"pibDevice\": \"N\",\r\n"
                + "            \"connectedDeviceInd\": null,\r\n"
                + "            \"deviceFamilyType\": \"Connected\",\r\n"
                + "            \"buddyUpgrdEligInd\": \"N\",\r\n" + "            \"restrictToFamilyInd\": \"Y\",\r\n"
                + "            \"nonGeoDeviceInd\": \"\",\r\n" + "            \"m2MAllow\": \"M2MC\",\r\n"
                + "            \"hdVoice\": \"Y\",\r\n" + "            \"alkDevice\": \"HD\",\r\n"
                + "            \"shipDate\": \"20-DEC-2017\",\r\n" + "            \"cpo\": \"N\",\r\n"
                + "            \"lsClientId\": \"\",\r\n" + "            \"lsCustomerId\": \"\",\r\n"
                + "            \"lsBillAcctNumber\": \"\",\r\n" + "            \"v4B\": \"\",\r\n"
                + "            \"icEligInd\": \"\",\r\n" + "            \"icRemDays\": \"\",\r\n"
                + "            \"icRemSubsidyAmt\": \"\",\r\n" + "            \"e911AddrInd\": \"Y\",\r\n"
                + "            \"euiccCapable\": \"Y\",\r\n" + "            \"numberShareCapability\": \"Y\",\r\n"
                + "            \"wifiCalling\": \"Y\",\r\n" + "            \"vvm\": \"N\",\r\n"
                + "            \"imei1\": \"\",\r\n" + "            \"imei2\": \"\",\r\n"
                + "            \"osType\": \"WatchOS4\",\r\n" + "            \"postpaidRestrictStartDate\": \"\",\r\n"
                + "            \"dsEs12Fqdn\": \"\"\r\n" + "        },\r\n" + "        \"simInfo\": {\r\n"
                + "            \"simId\": \"89148000000751553653\",\r\n" + "            \"mfgCode\": \"GTO\",\r\n"
                + "            \"prodName\": \"Gemalto 4FF NFC SIM - DF\",\r\n" + "            \"simGroup\": \"\",\r\n"
                + "            \"prodType\": \"4G_4FF_SIM\",\r\n" + "            \"simFormFactor\": \"\",\r\n"
                + "            \"simNoPay\": \"N\",\r\n" + "            \"simLostStolen\": \"N\",\r\n"
                + "            \"simLock\": \"\",\r\n" + "            \"simPibLock\": \"\",\r\n"
                + "            \"outletId\": \"\",\r\n" + "            \"sacc\": \"00722\",\r\n"
                + "            \"simType\": \"4GS\",\r\n" + "            \"iccidStatus\": \"AA\",\r\n"
                + "            \"numberLocation\": \"\",\r\n" + "            \"provTechType\": \"LTE\",\r\n"
                + "            \"launchPackageSku\": \"DFILL4FF-NFC-A\",\r\n"
                + "            \"imSku\": \"DFILL4FF-NFC-A\",\r\n" + "            \"nfcCapable\": \"Y\",\r\n"
                + "            \"nfcCompatible\": \"\",\r\n" + "            \"solderedSim\": \"\",\r\n"
                + "            \"simCapable\": \"DUAL_IMSI\",\r\n"
                + "            \"selfActivationCapableInd\": null,\r\n" + "            \"lsClientId\": \"\",\r\n"
                + "            \"lsCustomerId\": \"\",\r\n" + "            \"lsBillAcctNumber\": \"\",\r\n"
                + "            \"saleRetailer\": \"\",\r\n" + "            \"simSkuType\": \"T\",\r\n"
                + "            \"personalizedStatus\": \"\",\r\n" + "            \"personalizedTimeStamp\": \"\"\r\n"
                + "        },\r\n" + "        \"deviceSimCompatible\": \"Y\",\r\n"
                + "        \"deviceSimM2MPair\": \"N\",\r\n" + "        \"deviceESimCompatible\": \"\",\r\n"
                + "        \"deviceEsimM2MPair\": \"Y\",\r\n" + "        \"esimInfo\": {\r\n"
                + "            \"mfgCode\": \"\",\r\n" + "            \"launchPackageSku\": \"\",\r\n"
                + "            \"prodName\": \"\",\r\n" + "            \"preferredSoftSim\": \"SOFTNASIM-MP-D\",\r\n"
                + "            \"launchPackageSkuType\": \"\",\r\n" + "            \"pairedIccid\": \"\",\r\n"
                + "            \"eID\": \"89049032003008882300001955592066\"\r\n" + "        }\r\n" + "    }\r\n" + "}";
        DeviceSimDetailsUIResponse response = mapper.readValue(sampleResponseString, DeviceSimDetailsUIResponse.class);
        String addDeviceStr = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1596531-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"},{\"path\":\"FeatureConflicts\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"registerNumber\":0,\"accountNumber\":\"0220561307-00002\",\"cartCreator\":\"8439410557\",\"processingMTN\":\"8439292610\"},\"cartInfo\":{\"method\":\"\",\"financeLimitExceeded\":\"false\",\"cartId\":\"9c43a538-bcd8-4c1f-b271-6eb043271223\",\"clientAppName\":\"VZW-NETACE\",\"statusCode\":\"1\",\"statusMsg\":\"Success\",\"lines\":[{\"plan\":{},\"status\":1,\"errors\":[],\"spos\":[{\"id\":\"1167\",\"actionIndicator\":\"Z\",\"success\":true,\"is5GBolt\":false}],\"sfos\":[],\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"device\":{\"cartItemType\":\"\",\"quantityOnHand\":\"\",\"upgradeReasonCode\":\"\",\"id\":\"MQ722LL/A\",\"description\":\"\",\"itemPrice\":\"449.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"discounts\":\"\",\"existingDeviceId\":\"\",\"existingDeviceName\":\"iPhone&reg; 8\",\"removedFeatures\":\"\",\"fiveGToFourGDownGrade\":false},\"sim\":{\"simId\":\"\",\"id\":\"EMBD4GSIM-N\"},\"warranty\":{\"id\":\"\",\"itemPrice\":\"0.0\",\"discounts\":\"\"},\"upgradeFee\":{\"id\":\"\",\"itemPrice\":\"\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"AAL\",\"currentPlanType\":\"ALP\"}],\"expressCheckout\":false,\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false},\"processMTNList\":[{\"mtn\":\"8439292610\",\"completedprocessSteps\":[\"pastDuePage\",\"MTNSelectionPage\",\"InterimPage\",\"GridWallPDP\",\"GridWallPDP\",\"MTNSelectionPage\",\"InterimPage\",\"GridWallPDP\",\"GridWallPDP\",\"GridWallPDP\"]}]}}}}";
        AddDeviceUIResponse responseServiceMono = mapper.readValue(addDeviceStr, AddDeviceUIResponse.class);
        when(redisHelper2.upsertAccountInfoEligibleInRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        URI url = URI.create("http://localhost/nse/startBBPFlow");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        String bbpRequestVOString = "{\"imei2\":\"352898071702915\",\"isSmartphone\":null,\"devid\":\"353326095103554\",\"eid\":\"89049032003008882300001955592066\"}";
        BBPRequestVO bbpRequestVO = mapper.readValue(bbpRequestVOString, BBPRequestVO.class);
        when(cartHelper.initiateBBPFlow(Mockito.any())).thenReturn(Mono.just(response));
        when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(responseServiceMono));
        when(redisHelper2.upsertBBPFlowDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.upsertAddDeviceDataIntoRedis(Mockito.any())).thenReturn(Mono.just(new CartRedisData()));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.startBBPFlow(httpHeader, httpResponse,
                bbpRequestVO);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void startBBPFlowTest4() throws IOException {
        String sampleResponseString = "{\r\n" + "    \"uiMeta\": {\r\n" + "        \"timestamp\": 1606904076236,\r\n"
                + "        \"cxpCorrelationId\": \"2020-12-02T10:14:36.+0000:90be2abf-a4e2-4e0e-8fcb-4edcdee0a1e6:cxp-customerprofile-se-qa-ev6v-sit4w-nscxp-756b46467b-5z5q6:nssit4\"\r\n"
                + "    },\r\n" + "    \"uiData\": {\r\n" + "        \"deviceInfo\": {\r\n"
                + "            \"deviceId\": \"359433083362780\",\r\n" + "            \"mfgCode\": \"APL\",\r\n"
                + "            \"prodName\": \"APPLE WATCH S3 42 SPBLK MIL\",\r\n"
                + "            \"prodType\": \"ConnectedDevice\",\r\n" + "            \"eqpModeCode\": \"4GE\",\r\n"
                + "            \"eqpMode\": \"4G\",\r\n" + "            \"ems\": \"N\",\r\n"
                + "            \"mms\": \"Y\",\r\n" + "            \"gps\": \"Y\",\r\n"
                + "            \"ptt\": \"N\",\r\n" + "            \"globalPhone\": \"O\",\r\n"
                + "            \"wap\": \"N/A\",\r\n" + "            \"bluetooth\": \"Y\",\r\n"
                + "            \"brew\": \"N\",\r\n" + "            \"trustedMode\": \"N\",\r\n"
                + "            \"csim\": \"\",\r\n" + "            \"ehrpd\": \"N\",\r\n"
                + "            \"smsevdo\": \"N\",\r\n" + "            \"deviceCategory\": \"4G Connected Device\",\r\n"
                + "            \"visionProdId\": \"38940\",\r\n" + "            \"preferredSim\": \"\",\r\n"
                + "            \"backupAssistCapable\": \"N\",\r\n" + "            \"simClass4G\": \"NR\",\r\n"
                + "            \"virtualSimSku\": \"\",\r\n" + "            \"deviceNoPay\": \"N\",\r\n"
                + "            \"deviceLostStolen\": \"N\",\r\n" + "            \"deviceSdmLock\": \"\",\r\n"
                + "            \"deviceLock\": \"\",\r\n" + "            \"devicePibLock\": \"\",\r\n"
                + "            \"prepayEligibility\": \"00\",\r\n" + "            \"eligibilityDate\": \"\",\r\n"
                + "            \"outletId\": \"\",\r\n" + "            \"dacc\": \"01032\",\r\n"
                + "            \"deviceType\": \"4GE\",\r\n" + "            \"provTechType\": \"LTE\",\r\n"
                + "            \"launchPackageSku\": \"MR1L2LL/A\",\r\n" + "            \"imSku\": \"MR1L2LL/A\",\r\n"
                + "            \"deviceCapabilityInd\": \"VD\",\r\n" + "            \"nfcCapable\": \"Y\",\r\n"
                + "            \"nfcCompatible\": \"Y\",\r\n" + "            \"pibDevice\": \"N\",\r\n"
                + "            \"connectedDeviceInd\": null,\r\n"
                + "            \"deviceFamilyType\": \"Connected\",\r\n"
                + "            \"buddyUpgrdEligInd\": \"N\",\r\n" + "            \"restrictToFamilyInd\": \"Y\",\r\n"
                + "            \"nonGeoDeviceInd\": \"\",\r\n" + "            \"m2MAllow\": \"M2MC\",\r\n"
                + "            \"hdVoice\": \"Y\",\r\n" + "            \"alkDevice\": \"HD\",\r\n"
                + "            \"shipDate\": \"20-DEC-2017\",\r\n" + "            \"cpo\": \"N\",\r\n"
                + "            \"lsClientId\": \"\",\r\n" + "            \"lsCustomerId\": \"\",\r\n"
                + "            \"lsBillAcctNumber\": \"\",\r\n" + "            \"v4B\": \"\",\r\n"
                + "            \"icEligInd\": \"\",\r\n" + "            \"icRemDays\": \"\",\r\n"
                + "            \"icRemSubsidyAmt\": \"\",\r\n" + "            \"e911AddrInd\": \"Y\",\r\n"
                + "            \"euiccCapable\": \"Y\",\r\n" + "            \"numberShareCapability\": \"Y\",\r\n"
                + "            \"wifiCalling\": \"Y\",\r\n" + "            \"vvm\": \"N\",\r\n"
                + "            \"imei1\": \"\",\r\n" + "            \"imei2\": \"\",\r\n"
                + "            \"osType\": \"WatchOS4\",\r\n" + "            \"postpaidRestrictStartDate\": \"\",\r\n"
                + "            \"dsEs12Fqdn\": \"\"\r\n" + "        },\r\n" + "        \"simInfo\": {\r\n"
                + "            \"simId\": \"89148000000751553653\",\r\n" + "            \"mfgCode\": \"GTO\",\r\n"
                + "            \"prodName\": \"Gemalto 4FF NFC SIM - DF\",\r\n" + "            \"simGroup\": \"\",\r\n"
                + "            \"prodType\": \"4G_4FF_SIM\",\r\n" + "            \"simFormFactor\": \"\",\r\n"
                + "            \"simNoPay\": \"N\",\r\n" + "            \"simLostStolen\": \"N\",\r\n"
                + "            \"simLock\": \"\",\r\n" + "            \"simPibLock\": \"\",\r\n"
                + "            \"outletId\": \"\",\r\n" + "            \"sacc\": \"00722\",\r\n"
                + "            \"simType\": \"4GS\",\r\n" + "            \"iccidStatus\": \"AA\",\r\n"
                + "            \"numberLocation\": \"\",\r\n" + "            \"provTechType\": \"LTE\",\r\n"
                + "            \"launchPackageSku\": \"DFILL4FF-NFC-A\",\r\n"
                + "            \"imSku\": \"DFILL4FF-NFC-A\",\r\n" + "            \"nfcCapable\": \"Y\",\r\n"
                + "            \"nfcCompatible\": \"\",\r\n" + "            \"solderedSim\": \"\",\r\n"
                + "            \"simCapable\": \"DUAL_IMSI\",\r\n"
                + "            \"selfActivationCapableInd\": null,\r\n" + "            \"lsClientId\": \"\",\r\n"
                + "            \"lsCustomerId\": \"\",\r\n" + "            \"lsBillAcctNumber\": \"\",\r\n"
                + "            \"saleRetailer\": \"\",\r\n" + "            \"simSkuType\": \"T\",\r\n"
                + "            \"personalizedStatus\": \"\",\r\n" + "            \"personalizedTimeStamp\": \"\"\r\n"
                + "        },\r\n" + "        \"deviceSimCompatible\": \"Y\",\r\n"
                + "        \"deviceSimM2MPair\": \"N\",\r\n" + "        \"deviceESimCompatible\": \"\",\r\n"
                + "        \"deviceEsimM2MPair\": \"Y\",\r\n" + "        \"esimInfo\": {\r\n"
                + "            \"mfgCode\": \"\",\r\n" + "            \"launchPackageSku\": \"\",\r\n"
                + "            \"prodName\": \"\",\r\n" + "            \"preferredSoftSim\": \"SOFTNASIM-MP-D\",\r\n"
                + "            \"launchPackageSkuType\": \"\",\r\n" + "            \"pairedIccid\": \"\",\r\n"
                + "            \"eID\": \"89049032003008882300001955592066\"\r\n" + "        }\r\n" + "    }\r\n" + "}";
        DeviceSimDetailsUIResponse response = mapper.readValue(sampleResponseString, DeviceSimDetailsUIResponse.class);
        String addDeviceStr = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1596531-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"},{\"path\":\"FeatureConflicts\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"registerNumber\":0,\"accountNumber\":\"0220561307-00002\",\"cartCreator\":\"8439410557\",\"processingMTN\":\"8439292610\"},\"cartInfo\":{\"method\":\"\",\"financeLimitExceeded\":\"false\",\"cartId\":\"9c43a538-bcd8-4c1f-b271-6eb043271223\",\"clientAppName\":\"VZW-NETACE\",\"statusCode\":\"1\",\"statusMsg\":\"Success\",\"lines\":[],\"expressCheckout\":false,\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false},\"processMTNList\":[{\"mtn\":\"8439292610\",\"completedprocessSteps\":[\"pastDuePage\",\"MTNSelectionPage\",\"InterimPage\",\"GridWallPDP\",\"GridWallPDP\",\"MTNSelectionPage\",\"InterimPage\",\"GridWallPDP\",\"GridWallPDP\",\"GridWallPDP\"]}]}}}}";
        AddDeviceUIResponse responseServiceMono = mapper.readValue(addDeviceStr, AddDeviceUIResponse.class);
        when(redisHelper2.upsertAccountInfoEligibleInRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        URI url = URI.create("http://localhost/nse/startBBPFlow");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        String bbpRequestVOString = "{\"imei2\":\"352898071702915\",\"isSmartphone\":false,\"devid\":\"353326095103554\",\"eid\":\"89049032003008882300001955592066\"}";
        BBPRequestVO bbpRequestVO = mapper.readValue(bbpRequestVOString, BBPRequestVO.class);
        when(cartHelper.initiateBBPFlow(Mockito.any())).thenReturn(Mono.just(response));
        when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(responseServiceMono));
        when(redisHelper2.upsertBBPFlowDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.upsertAddDeviceDataIntoRedis(Mockito.any())).thenReturn(Mono.just(new CartRedisData()));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.startBBPFlow(httpHeader, httpResponse,
                bbpRequestVO);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void startBBPFlowTest5() throws IOException {
        String sampleResponseString = "{\r\n" + "    \"uiMeta\": {\r\n" + "        \"timestamp\": 1606904076236,\r\n"
                + "        \"cxpCorrelationId\": \"2020-12-02T10:14:36.+0000:90be2abf-a4e2-4e0e-8fcb-4edcdee0a1e6:cxp-customerprofile-se-qa-ev6v-sit4w-nscxp-756b46467b-5z5q6:nssit4\"\r\n"
                + "    },\r\n" + "    \"uiData\": {\r\n" + "        \"deviceInfo\": {\r\n"
                + "            \"deviceId\": \"359433083362780\",\r\n" + "            \"mfgCode\": \"APL\",\r\n"
                + "            \"prodName\": \"APPLE WATCH S3 42 SPBLK MIL\",\r\n"
                + "            \"prodType\": \"ConnectedDevice\",\r\n" + "            \"eqpModeCode\": \"4GE\",\r\n"
                + "            \"eqpMode\": \"4G\",\r\n" + "            \"ems\": \"N\",\r\n"
                + "            \"mms\": \"Y\",\r\n" + "            \"gps\": \"Y\",\r\n"
                + "            \"ptt\": \"N\",\r\n" + "            \"globalPhone\": \"O\",\r\n"
                + "            \"wap\": \"N/A\",\r\n" + "            \"bluetooth\": \"Y\",\r\n"
                + "            \"brew\": \"N\",\r\n" + "            \"trustedMode\": \"N\",\r\n"
                + "            \"csim\": \"\",\r\n" + "            \"ehrpd\": \"N\",\r\n"
                + "            \"smsevdo\": \"N\",\r\n" + "            \"deviceCategory\": \"4G Connected Device\",\r\n"
                + "            \"visionProdId\": \"38940\",\r\n" + "            \"preferredSim\": \"\",\r\n"
                + "            \"backupAssistCapable\": \"N\",\r\n" + "            \"simClass4G\": \"NR\",\r\n"
                + "            \"virtualSimSku\": \"\",\r\n" + "            \"deviceNoPay\": \"N\",\r\n"
                + "            \"deviceLostStolen\": \"N\",\r\n" + "            \"deviceSdmLock\": \"\",\r\n"
                + "            \"deviceLock\": \"\",\r\n" + "            \"devicePibLock\": \"\",\r\n"
                + "            \"prepayEligibility\": \"00\",\r\n" + "            \"eligibilityDate\": \"\",\r\n"
                + "            \"outletId\": \"\",\r\n" + "            \"dacc\": \"01483\",\r\n"
                + "            \"deviceType\": \"4GE\",\r\n" + "            \"provTechType\": \"LTE\",\r\n"
                + "            \"launchPackageSku\": \"MR1L2LL/A\",\r\n" + "            \"imSku\": \"MR1L2LL/A\",\r\n"
                + "            \"deviceCapabilityInd\": \"VD\",\r\n" + "            \"nfcCapable\": \"Y\",\r\n"
                + "            \"nfcCompatible\": \"Y\",\r\n" + "            \"pibDevice\": \"N\",\r\n"
                + "            \"connectedDeviceInd\": null,\r\n"
                + "            \"deviceFamilyType\": \"Connected\",\r\n"
                + "            \"buddyUpgrdEligInd\": \"N\",\r\n" + "            \"restrictToFamilyInd\": \"Y\",\r\n"
                + "            \"nonGeoDeviceInd\": \"\",\r\n" + "            \"m2MAllow\": \"M2MC\",\r\n"
                + "            \"hdVoice\": \"Y\",\r\n" + "            \"alkDevice\": \"HD\",\r\n"
                + "            \"shipDate\": \"20-DEC-2017\",\r\n" + "            \"cpo\": \"N\",\r\n"
                + "            \"lsClientId\": \"\",\r\n" + "            \"lsCustomerId\": \"\",\r\n"
                + "            \"lsBillAcctNumber\": \"\",\r\n" + "            \"v4B\": \"\",\r\n"
                + "            \"icEligInd\": \"\",\r\n" + "            \"icRemDays\": \"\",\r\n"
                + "            \"icRemSubsidyAmt\": \"\",\r\n" + "            \"e911AddrInd\": \"Y\",\r\n"
                + "            \"euiccCapable\": \"Y\",\r\n" + "            \"numberShareCapability\": \"Y\",\r\n"
                + "            \"wifiCalling\": \"Y\",\r\n" + "            \"vvm\": \"N\",\r\n"
                + "            \"imei1\": \"\",\r\n" + "            \"imei2\": \"\",\r\n"
                + "            \"osType\": \"WatchOS4\",\r\n" + "            \"postpaidRestrictStartDate\": \"\",\r\n"
                + "            \"dsEs12Fqdn\": \"\"\r\n" + "        },\r\n" + "        \"simInfo\": {\r\n"
                + "            \"simId\": \"89148000000751553653\",\r\n" + "            \"mfgCode\": \"GTO\",\r\n"
                + "            \"prodName\": \"Gemalto 4FF NFC SIM - DF\",\r\n" + "            \"simGroup\": \"\",\r\n"
                + "            \"prodType\": \"4G_4FF_SIM\",\r\n" + "            \"simFormFactor\": \"\",\r\n"
                + "            \"simNoPay\": \"N\",\r\n" + "            \"simLostStolen\": \"N\",\r\n"
                + "            \"simLock\": \"\",\r\n" + "            \"simPibLock\": \"\",\r\n"
                + "            \"outletId\": \"\",\r\n" + "            \"sacc\": \"00722\",\r\n"
                + "            \"simType\": \"4GS\",\r\n" + "            \"iccidStatus\": \"AA\",\r\n"
                + "            \"numberLocation\": \"\",\r\n" + "            \"provTechType\": \"LTE\",\r\n"
                + "            \"launchPackageSku\": \"DFILL4FF-NFC-A\",\r\n"
                + "            \"imSku\": \"DFILL4FF-NFC-A\",\r\n" + "            \"nfcCapable\": \"Y\",\r\n"
                + "            \"nfcCompatible\": \"\",\r\n" + "            \"solderedSim\": \"\",\r\n"
                + "            \"simCapable\": \"DUAL_IMSI\",\r\n"
                + "            \"selfActivationCapableInd\": null,\r\n" + "            \"lsClientId\": \"\",\r\n"
                + "            \"lsCustomerId\": \"\",\r\n" + "            \"lsBillAcctNumber\": \"\",\r\n"
                + "            \"saleRetailer\": \"\",\r\n" + "            \"simSkuType\": \"T\",\r\n"
                + "            \"personalizedStatus\": \"\",\r\n" + "            \"personalizedTimeStamp\": \"\"\r\n"
                + "        },\r\n" + "        \"deviceSimCompatible\": \"Y\",\r\n"
                + "        \"deviceSimM2MPair\": \"N\",\r\n" + "        \"deviceESimCompatible\": \"\",\r\n"
                + "        \"deviceEsimM2MPair\": \"Y\",\r\n" + "        \"esimInfo\": {\r\n"
                + "            \"mfgCode\": \"\",\r\n" + "            \"launchPackageSku\": \"\",\r\n"
                + "            \"prodName\": \"\",\r\n" + "            \"preferredSoftSim\": \"SOFTNASIM-MP-D\",\r\n"
                + "            \"launchPackageSkuType\": \"\",\r\n" + "            \"pairedIccid\": \"\",\r\n"
                + "            \"eID\": \"89049032003008882300001955592066\"\r\n" + "        }\r\n" + "    }\r\n" + "}";
        DeviceSimDetailsUIResponse response = mapper.readValue(sampleResponseString, DeviceSimDetailsUIResponse.class);
        String addDeviceStr = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1596531-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"},{\"path\":\"FeatureConflicts\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\"},\"cartInfo\":{\"method\":\"\",\"financeLimitExceeded\":\"false\",\"cartId\":\"9c43a538-bcd8-4c1f-b271-6eb043271223\",\"clientAppName\":\"VZW-NETACE\",\"statusCode\":\"1\",\"statusMsg\":\"Success\",\"expressCheckout\":false,\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false},\"processMTNList\":[{\"mtn\":\"8439292610\",\"completedprocessSteps\":[\"pastDuePage\",\"MTNSelectionPage\",\"InterimPage\",\"GridWallPDP\",\"GridWallPDP\",\"MTNSelectionPage\",\"InterimPage\",\"GridWallPDP\",\"GridWallPDP\",\"GridWallPDP\"]}]}}}}";
        AddDeviceUIResponse responseServiceMono = mapper.readValue(addDeviceStr, AddDeviceUIResponse.class);
        when(redisHelper2.upsertAccountInfoEligibleInRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        URI url = URI.create("http://localhost/nse/startBBPFlow");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        String bbpRequestVOString = "{\"imei2\":\"352898071702915\",\"isSmartphone\":false,\"devid\":\"353326095103554\",\"eid\":\"89049032003008882300001955592066\"}";
        BBPRequestVO bbpRequestVO = mapper.readValue(bbpRequestVOString, BBPRequestVO.class);
        when(cartHelper.initiateBBPFlow(Mockito.any())).thenReturn(Mono.just(response));
        when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(responseServiceMono));
        when(redisHelper2.upsertBBPFlowDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.upsertAddDeviceDataIntoRedis(Mockito.any())).thenReturn(Mono.just(new CartRedisData()));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.startBBPFlow(httpHeader, httpResponse,
                bbpRequestVO);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void startBBPFlowTest6() throws IOException {
        String sampleResponseString = "{\r\n" + "    \"uiMeta\": {\r\n" + "        \"timestamp\": 1606904076236,\r\n"
                + "        \"cxpCorrelationId\": \"2020-12-02T10:14:36.+0000:90be2abf-a4e2-4e0e-8fcb-4edcdee0a1e6:cxp-customerprofile-se-qa-ev6v-sit4w-nscxp-756b46467b-5z5q6:nssit4\"\r\n"
                + "    },\r\n" + "    \"uiData\": {\r\n" + "        \"simInfo\": {\r\n"
                + "            \"simId\": \"89148000000751553653\",\r\n" + "            \"mfgCode\": \"GTO\",\r\n"
                + "            \"prodName\": \"Gemalto 4FF NFC SIM - DF\",\r\n" + "            \"simGroup\": \"\",\r\n"
                + "            \"prodType\": \"4G_4FF_SIM\",\r\n" + "            \"simFormFactor\": \"\",\r\n"
                + "            \"simNoPay\": \"N\",\r\n" + "            \"simLostStolen\": \"N\",\r\n"
                + "            \"simLock\": \"\",\r\n" + "            \"simPibLock\": \"\",\r\n"
                + "            \"outletId\": \"\",\r\n" + "            \"sacc\": \"00722\",\r\n"
                + "            \"simType\": \"4GS\",\r\n" + "            \"iccidStatus\": \"AA\",\r\n"
                + "            \"numberLocation\": \"\",\r\n" + "            \"provTechType\": \"LTE\",\r\n"
                + "            \"launchPackageSku\": \"DFILL4FF-NFC-A\",\r\n"
                + "            \"imSku\": \"DFILL4FF-NFC-A\",\r\n" + "            \"nfcCapable\": \"Y\",\r\n"
                + "            \"nfcCompatible\": \"\",\r\n" + "            \"solderedSim\": \"\",\r\n"
                + "            \"simCapable\": \"DUAL_IMSI\",\r\n"
                + "            \"selfActivationCapableInd\": null,\r\n" + "            \"lsClientId\": \"\",\r\n"
                + "            \"lsCustomerId\": \"\",\r\n" + "            \"lsBillAcctNumber\": \"\",\r\n"
                + "            \"saleRetailer\": \"\",\r\n" + "            \"simSkuType\": \"T\",\r\n"
                + "            \"personalizedStatus\": \"\",\r\n" + "            \"personalizedTimeStamp\": \"\"\r\n"
                + "        },\r\n" + "        \"deviceSimCompatible\": \"Y\",\r\n"
                + "        \"deviceSimM2MPair\": \"N\",\r\n" + "        \"deviceESimCompatible\": \"\",\r\n"
                + "        \"deviceEsimM2MPair\": \"Y\",\r\n" + "        \"esimInfo\": {\r\n"
                + "            \"mfgCode\": \"\",\r\n" + "            \"launchPackageSku\": \"\",\r\n"
                + "            \"prodName\": \"\",\r\n" + "            \"preferredSoftSim\": \"SOFTNASIM-MP-D\",\r\n"
                + "            \"launchPackageSkuType\": \"\",\r\n" + "            \"pairedIccid\": \"\",\r\n"
                + "            \"eID\": \"89049032003008882300001955592066\"\r\n" + "        }\r\n" + "    }\r\n" + "}";
        DeviceSimDetailsUIResponse response = mapper.readValue(sampleResponseString, DeviceSimDetailsUIResponse.class);
        String addDeviceStr = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1596531-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"},{\"path\":\"FeatureConflicts\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\"},\"processMTNList\":[{\"mtn\":\"8439292610\",\"completedprocessSteps\":[\"pastDuePage\",\"MTNSelectionPage\",\"InterimPage\",\"GridWallPDP\",\"GridWallPDP\",\"MTNSelectionPage\",\"InterimPage\",\"GridWallPDP\",\"GridWallPDP\",\"GridWallPDP\"]}]}}}}";
        AddDeviceUIResponse responseServiceMono = mapper.readValue(addDeviceStr, AddDeviceUIResponse.class);
        when(redisHelper2.upsertAccountInfoEligibleInRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        URI url = URI.create("http://localhost/nse/startBBPFlow");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        String bbpRequestVOString = "{\"imei2\":\"352898071702915\",\"isSmartphone\":false,\"devid\":\"353326095103554\",\"eid\":\"89049032003008882300001955592066\"}";
        BBPRequestVO bbpRequestVO = mapper.readValue(bbpRequestVOString, BBPRequestVO.class);
        when(cartHelper.initiateBBPFlow(Mockito.any())).thenReturn(Mono.just(response));
        when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(responseServiceMono));
        when(redisHelper2.upsertBBPFlowDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.upsertAddDeviceDataIntoRedis(Mockito.any())).thenReturn(Mono.just(new CartRedisData()));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.startBBPFlow(httpHeader, httpResponse,
                bbpRequestVO);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void startBBPFlowTest7() throws IOException {
        String sampleResponseString = "{\r\n" + "    \"uiMeta\": {\r\n" + "        \"timestamp\": 1606904076236,\r\n"
                + "        \"cxpCorrelationId\": \"2020-12-02T10:14:36.+0000:90be2abf-a4e2-4e0e-8fcb-4edcdee0a1e6:cxp-customerprofile-se-qa-ev6v-sit4w-nscxp-756b46467b-5z5q6:nssit4\"\r\n"
                + "    },\r\n" + "    \"uiData\": {\r\n" + "        \"deviceInfo\": {\r\n"
                + "            \"deviceId\": \"359433083362780\",\r\n" + "            \"mfgCode\": \"SAM\",\r\n"
                + "            \"prodName\": \"APPLE WATCH S3 42 SPBLK MIL\",\r\n"
                + "            \"prodType\": \"ConnectedDevice\",\r\n" + "            \"eqpModeCode\": \"4GE\",\r\n"
                + "            \"eqpMode\": \"4G\",\r\n" + "            \"ems\": \"N\",\r\n"
                + "            \"mms\": \"Y\",\r\n" + "            \"gps\": \"Y\",\r\n"
                + "            \"ptt\": \"N\",\r\n" + "            \"globalPhone\": \"O\",\r\n"
                + "            \"wap\": \"N/A\",\r\n" + "            \"bluetooth\": \"Y\",\r\n"
                + "            \"brew\": \"N\",\r\n" + "            \"trustedMode\": \"N\",\r\n"
                + "            \"csim\": \"\",\r\n" + "            \"ehrpd\": \"N\",\r\n"
                + "            \"smsevdo\": \"N\",\r\n" + "            \"deviceCategory\": \"4G Connected Device\",\r\n"
                + "            \"visionProdId\": \"38940\",\r\n" + "            \"preferredSim\": \"\",\r\n"
                + "            \"backupAssistCapable\": \"N\",\r\n" + "            \"simClass4G\": \"NR\",\r\n"
                + "            \"virtualSimSku\": \"\",\r\n" + "            \"deviceNoPay\": \"N\",\r\n"
                + "            \"deviceLostStolen\": \"N\",\r\n" + "            \"deviceSdmLock\": \"\",\r\n"
                + "            \"deviceLock\": \"\",\r\n" + "            \"devicePibLock\": \"\",\r\n"
                + "            \"prepayEligibility\": \"00\",\r\n" + "            \"eligibilityDate\": \"\",\r\n"
                + "            \"outletId\": \"\",\r\n" + "            \"dacc\": \"01419\",\r\n"
                + "            \"deviceType\": \"4GE\",\r\n" + "            \"provTechType\": \"LTE\",\r\n"
                + "            \"launchPackageSku\": \"MR1L2LL/A\",\r\n" + "            \"imSku\": \"MR1L2LL/A\",\r\n"
                + "            \"deviceCapabilityInd\": \"VD\",\r\n" + "            \"nfcCapable\": \"Y\",\r\n"
                + "            \"nfcCompatible\": \"Y\",\r\n" + "            \"pibDevice\": \"N\",\r\n"
                + "            \"connectedDeviceInd\": null,\r\n"
                + "            \"deviceFamilyType\": \"Connected\",\r\n"
                + "            \"buddyUpgrdEligInd\": \"N\",\r\n" + "            \"restrictToFamilyInd\": \"Y\",\r\n"
                + "            \"nonGeoDeviceInd\": \"\",\r\n" + "            \"m2MAllow\": \"M2MC\",\r\n"
                + "            \"hdVoice\": \"Y\",\r\n" + "            \"alkDevice\": \"HD\",\r\n"
                + "            \"shipDate\": \"20-DEC-2017\",\r\n" + "            \"cpo\": \"N\",\r\n"
                + "            \"lsClientId\": \"\",\r\n" + "            \"lsCustomerId\": \"\",\r\n"
                + "            \"lsBillAcctNumber\": \"\",\r\n" + "            \"v4B\": \"\",\r\n"
                + "            \"icEligInd\": \"\",\r\n" + "            \"icRemDays\": \"\",\r\n"
                + "            \"icRemSubsidyAmt\": \"\",\r\n" + "            \"e911AddrInd\": \"Y\",\r\n"
                + "            \"euiccCapable\": \"Y\",\r\n" + "            \"numberShareCapability\": \"Y\",\r\n"
                + "            \"wifiCalling\": \"Y\",\r\n" + "            \"vvm\": \"N\",\r\n"
                + "            \"imei1\": \"\",\r\n" + "            \"imei2\": \"\",\r\n"
                + "            \"osType\": \"WatchOS4\",\r\n" + "            \"postpaidRestrictStartDate\": \"\",\r\n"
                + "            \"dsEs12Fqdn\": \"\"\r\n" + "        },\r\n" + "        \"simInfo\": {\r\n"
                + "            \"simId\": \"89148000000751553653\",\r\n" + "            \"mfgCode\": \"GTO\",\r\n"
                + "            \"prodName\": \"Gemalto 4FF NFC SIM - DF\",\r\n" + "            \"simGroup\": \"\",\r\n"
                + "            \"prodType\": \"4G_4FF_SIM\",\r\n" + "            \"simFormFactor\": \"\",\r\n"
                + "            \"simNoPay\": \"N\",\r\n" + "            \"simLostStolen\": \"N\",\r\n"
                + "            \"simLock\": \"\",\r\n" + "            \"simPibLock\": \"\",\r\n"
                + "            \"outletId\": \"\",\r\n" + "            \"sacc\": \"00722\",\r\n"
                + "            \"simType\": \"4GS\",\r\n" + "            \"iccidStatus\": \"AA\",\r\n"
                + "            \"numberLocation\": \"\",\r\n" + "            \"provTechType\": \"LTE\",\r\n"
                + "            \"launchPackageSku\": \"DFILL4FF-NFC-A\",\r\n"
                + "            \"imSku\": \"DFILL4FF-NFC-A\",\r\n" + "            \"nfcCapable\": \"Y\",\r\n"
                + "            \"nfcCompatible\": \"\",\r\n" + "            \"solderedSim\": \"\",\r\n"
                + "            \"simCapable\": \"DUAL_IMSI\",\r\n"
                + "            \"selfActivationCapableInd\": null,\r\n" + "            \"lsClientId\": \"\",\r\n"
                + "            \"lsCustomerId\": \"\",\r\n" + "            \"lsBillAcctNumber\": \"\",\r\n"
                + "            \"saleRetailer\": \"\",\r\n" + "            \"simSkuType\": \"T\",\r\n"
                + "            \"personalizedStatus\": \"\",\r\n" + "            \"personalizedTimeStamp\": \"\"\r\n"
                + "        },\r\n" + "        \"deviceSimCompatible\": \"Y\",\r\n"
                + "        \"deviceSimM2MPair\": \"N\",\r\n" + "        \"deviceESimCompatible\": \"\",\r\n"
                + "        \"deviceEsimM2MPair\": \"Y\",\r\n" + "        \"esimInfo\": {\r\n"
                + "            \"mfgCode\": \"\",\r\n" + "            \"launchPackageSku\": \"\",\r\n"
                + "            \"prodName\": \"\",\r\n" + "            \"preferredSoftSim\": \"SOFTNASIM-MP-D\",\r\n"
                + "            \"launchPackageSkuType\": \"\",\r\n" + "            \"pairedIccid\": \"\",\r\n"
                + "            \"eID\": \"89049032003008882300001955592066\"\r\n" + "        }\r\n" + "    }\r\n" + "}";
        DeviceSimDetailsUIResponse response = mapper.readValue(sampleResponseString, DeviceSimDetailsUIResponse.class);
        String addDeviceStr = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\"},\"serviceBody\":{\"serviceResponse\":{}}}";
        AddDeviceUIResponse responseServiceMono = mapper.readValue(addDeviceStr, AddDeviceUIResponse.class);
        when(redisHelper2.upsertAccountInfoEligibleInRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        URI url = URI.create("http://localhost/nse/startBBPFlow");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        String bbpRequestVOString = "{\"imei2\":\"352898071702915\",\"isSmartphone\":false,\"devid\":\"353326095103554\",\"eid\":\"89049032003008882300001955592066\"}";
        BBPRequestVO bbpRequestVO = mapper.readValue(bbpRequestVOString, BBPRequestVO.class);
        when(cartHelper.initiateBBPFlow(Mockito.any())).thenReturn(Mono.just(response));
        when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(responseServiceMono));
        when(redisHelper2.upsertBBPFlowDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.upsertAddDeviceDataIntoRedis(Mockito.any())).thenReturn(Mono.just(new CartRedisData()));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.startBBPFlow(httpHeader, httpResponse,
                bbpRequestVO);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void startBBPFlowTest8() throws IOException {
        String sampleResponseString = "{\r\n" + "    \"uiMeta\": {\r\n" + "        \"timestamp\": 1606904076236,\r\n"
                + "        \"cxpCorrelationId\": \"2020-12-02T10:14:36.+0000:90be2abf-a4e2-4e0e-8fcb-4edcdee0a1e6:cxp-customerprofile-se-qa-ev6v-sit4w-nscxp-756b46467b-5z5q6:nssit4\"\r\n"
                + "    },\r\n" + "    \"uiData\": {\r\n" + "        \"deviceInfo\": {\r\n"
                + "            \"deviceId\": \"359433083362780\",\r\n" + "            \"mfgCode\": null,\r\n"
                + "            \"prodName\": \"APPLE WATCH S3 42 SPBLK MIL\",\r\n"
                + "            \"prodType\": \"ConnectedDevice\",\r\n" + "            \"eqpModeCode\": \"4GE\",\r\n"
                + "            \"eqpMode\": \"4G\",\r\n" + "            \"ems\": \"N\",\r\n"
                + "            \"mms\": \"Y\",\r\n" + "            \"gps\": \"Y\",\r\n"
                + "            \"ptt\": \"N\",\r\n" + "            \"globalPhone\": \"O\",\r\n"
                + "            \"wap\": \"N/A\",\r\n" + "            \"bluetooth\": \"Y\",\r\n"
                + "            \"brew\": \"N\",\r\n" + "            \"trustedMode\": \"N\",\r\n"
                + "            \"csim\": \"\",\r\n" + "            \"ehrpd\": \"N\",\r\n"
                + "            \"smsevdo\": \"N\",\r\n" + "            \"deviceCategory\": \"4G Connected Device\",\r\n"
                + "            \"visionProdId\": \"38940\",\r\n" + "            \"preferredSim\": \"\",\r\n"
                + "            \"backupAssistCapable\": \"N\",\r\n" + "            \"simClass4G\": \"NR\",\r\n"
                + "            \"virtualSimSku\": \"\",\r\n" + "            \"deviceNoPay\": \"N\",\r\n"
                + "            \"deviceLostStolen\": \"N\",\r\n" + "            \"deviceSdmLock\": \"\",\r\n"
                + "            \"deviceLock\": \"\",\r\n" + "            \"devicePibLock\": \"\",\r\n"
                + "            \"prepayEligibility\": \"00\",\r\n" + "            \"eligibilityDate\": \"\",\r\n"
                + "            \"outletId\": \"\",\r\n" + "            \"dacc\": \"01032\",\r\n"
                + "            \"deviceType\": \"4GE\",\r\n" + "            \"provTechType\": \"LTE\",\r\n"
                + "            \"launchPackageSku\": \"MR1L2LL/A\",\r\n" + "            \"imSku\": \"MR1L2LL/A\",\r\n"
                + "            \"deviceCapabilityInd\": \"VD\",\r\n" + "            \"nfcCapable\": \"Y\",\r\n"
                + "            \"nfcCompatible\": \"Y\",\r\n" + "            \"pibDevice\": \"N\",\r\n"
                + "            \"connectedDeviceInd\": null,\r\n"
                + "            \"deviceFamilyType\": \"Connected\",\r\n"
                + "            \"buddyUpgrdEligInd\": \"N\",\r\n" + "            \"restrictToFamilyInd\": \"Y\",\r\n"
                + "            \"nonGeoDeviceInd\": \"\",\r\n" + "            \"m2MAllow\": \"M2MC\",\r\n"
                + "            \"hdVoice\": \"Y\",\r\n" + "            \"alkDevice\": \"HD\",\r\n"
                + "            \"shipDate\": \"20-DEC-2017\",\r\n" + "            \"cpo\": \"N\",\r\n"
                + "            \"lsClientId\": \"\",\r\n" + "            \"lsCustomerId\": \"\",\r\n"
                + "            \"lsBillAcctNumber\": \"\",\r\n" + "            \"v4B\": \"\",\r\n"
                + "            \"icEligInd\": \"\",\r\n" + "            \"icRemDays\": \"\",\r\n"
                + "            \"icRemSubsidyAmt\": \"\",\r\n" + "            \"e911AddrInd\": \"Y\",\r\n"
                + "            \"euiccCapable\": \"Y\",\r\n" + "            \"numberShareCapability\": \"Y\",\r\n"
                + "            \"wifiCalling\": \"Y\",\r\n" + "            \"vvm\": \"N\",\r\n"
                + "            \"imei1\": \"\",\r\n" + "            \"imei2\": \"\",\r\n"
                + "            \"osType\": \"WatchOS4\",\r\n" + "            \"postpaidRestrictStartDate\": \"\",\r\n"
                + "            \"dsEs12Fqdn\": \"\"\r\n" + "        },\r\n" + "        \"simInfo\": {\r\n"
                + "            \"simId\": \"89148000000751553653\",\r\n" + "            \"mfgCode\": \"GTO\",\r\n"
                + "            \"prodName\": \"Gemalto 4FF NFC SIM - DF\",\r\n" + "            \"simGroup\": \"\",\r\n"
                + "            \"prodType\": \"4G_4FF_SIM\",\r\n" + "            \"simFormFactor\": \"\",\r\n"
                + "            \"simNoPay\": \"N\",\r\n" + "            \"simLostStolen\": \"N\",\r\n"
                + "            \"simLock\": \"\",\r\n" + "            \"simPibLock\": \"\",\r\n"
                + "            \"outletId\": \"\",\r\n" + "            \"sacc\": \"00722\",\r\n"
                + "            \"simType\": \"4GS\",\r\n" + "            \"iccidStatus\": \"AA\",\r\n"
                + "            \"numberLocation\": \"\",\r\n" + "            \"provTechType\": \"LTE\",\r\n"
                + "            \"launchPackageSku\": \"DFILL4FF-NFC-A\",\r\n"
                + "            \"imSku\": \"DFILL4FF-NFC-A\",\r\n" + "            \"nfcCapable\": \"Y\",\r\n"
                + "            \"nfcCompatible\": \"\",\r\n" + "            \"solderedSim\": \"\",\r\n"
                + "            \"simCapable\": \"DUAL_IMSI\",\r\n"
                + "            \"selfActivationCapableInd\": null,\r\n" + "            \"lsClientId\": \"\",\r\n"
                + "            \"lsCustomerId\": \"\",\r\n" + "            \"lsBillAcctNumber\": \"\",\r\n"
                + "            \"saleRetailer\": \"\",\r\n" + "            \"simSkuType\": \"T\",\r\n"
                + "            \"personalizedStatus\": \"\",\r\n" + "            \"personalizedTimeStamp\": \"\"\r\n"
                + "        },\r\n" + "        \"deviceSimCompatible\": \"Y\",\r\n"
                + "        \"deviceSimM2MPair\": \"N\",\r\n" + "        \"deviceESimCompatible\": \"\",\r\n"
                + "        \"deviceEsimM2MPair\": \"Y\",\r\n" + "        \"esimInfo\": {\r\n"
                + "            \"mfgCode\": \"\",\r\n" + "            \"launchPackageSku\": \"\",\r\n"
                + "            \"prodName\": \"\",\r\n" + "            \"preferredSoftSim\": \"SOFTNASIM-MP-D\",\r\n"
                + "            \"launchPackageSkuType\": \"\",\r\n" + "            \"pairedIccid\": \"\",\r\n"
                + "            \"eID\": \"89049032003008882300001955592066\"\r\n" + "        }\r\n" + "    }\r\n" + "}";
        DeviceSimDetailsUIResponse response = mapper.readValue(sampleResponseString, DeviceSimDetailsUIResponse.class);
        String addDeviceStr = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\"}}";
        AddDeviceUIResponse responseServiceMono = mapper.readValue(addDeviceStr, AddDeviceUIResponse.class);
        when(redisHelper2.upsertAccountInfoEligibleInRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        URI url = URI.create("http://localhost/nse/startBBPFlow");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        String bbpRequestVOString = "{\"imei2\":\"352898071702915\",\"isSmartphone\":false,\"devid\":\"353326095103554\",\"eid\":\"89049032003008882300001955592066\"}";
        BBPRequestVO bbpRequestVO = mapper.readValue(bbpRequestVOString, BBPRequestVO.class);
        when(cartHelper.initiateBBPFlow(Mockito.any())).thenReturn(Mono.just(response));
        when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(responseServiceMono));
        when(redisHelper2.upsertBBPFlowDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.upsertAddDeviceDataIntoRedis(Mockito.any())).thenReturn(Mono.just(new CartRedisData()));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.startBBPFlow(httpHeader, httpResponse,
                bbpRequestVO);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }


    @Test
    public void bbpAddZipcode_Failure_Test1() throws IOException {
        AddZipCodeUIRequest addZipcodeUiRequest = new AddZipCodeUIRequest();
        when(redisHelper2.upsertBBPFlowZipCodeDataIntoRedis(Mockito.any())).thenReturn(Mono.just(false));
        URI url = URI.create("http://localhost/bbpAddZipcode");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<AddZipcodeRedisData>> controllerResponse = cartController.bbpAddZipCode(httpHeader, httpResponse,
                addZipcodeUiRequest);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }
    

    @Test
    public void startBBPFlowErrorTest() throws IOException {
        String sampleResponseString = "{\"errors\":[{\"namespace\":\"CartService\",\"id\":\"c1000\"}]}";
        DeviceSimDetailsUIResponse response = mapper.readValue(sampleResponseString, DeviceSimDetailsUIResponse.class);
        String addDeviceStr = "{\"errors\":[{\"namespace\":\"CartService\",\"id\":\"c1000\"}]}";
        AddDeviceUIResponse responseServiceMono = mapper.readValue(addDeviceStr, AddDeviceUIResponse.class);
        when(redisHelper2.upsertAccountInfoEligibleInRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        URI url = URI.create("http://localhost/nse/startBBPFlow");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        String bbpRequestVOString = "{\"imei2\":\"352898071702915\",\"isSmartphone\":false,\"devid\":\"353326095103554\",\"eid\":\"89049032003008882300001955592066\"}";
        BBPRequestVO bbpRequestVO = mapper.readValue(bbpRequestVOString, BBPRequestVO.class);
        when(cartHelper.initiateBBPFlow(Mockito.any())).thenReturn(Mono.just(response));
        when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(responseServiceMono));
        when(redisHelper2.upsertBBPFlowDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.upsertAddDeviceDataIntoRedis(Mockito.any())).thenReturn(Mono.just(new CartRedisData()));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.startBBPFlow(httpHeader, httpResponse,
                bbpRequestVO);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void populateAddDeviceFlowForPhoneTest() throws IOException {
        String sampleResponseString = "{\n" +
                "\t\"cartInfo\":{\n" +
                "\t\t\"accountNumber\":\"0220561307-00002\",\n" +
                "\t\t\"cartCreator\":\"8439410557\",\n" +
                "\t\t\"globalId\":\"\",\n" +
                "\t\t\"sessionId\":\"\",\n" +
                "\t\t\"mtnFlow\":\"\",\n" +
                "\t\t\"intendType\":\"BYOD\",\n" +
                "\t\t\"processStep\":\"\",\n" +
                "\t\t\"processAction\":\"addDevice\",\n" +
                "\t\t\"clientAppName\":\"VZW-DOTCOM-BBP\",\n" +
                "\t\t\"numberShareCapable\":\"Y\",\n" +
                "\t\t\"eNineAddressIndicator\":\"True\",\n" +
                "\t\t\"deviceType\":\"PHONE\",\n" +
                "\t\t\"bbpIntent\":\"BYOD\",\n" +
                "\t\t\"triggerPricingValidation\":true\n" +
                "\t},\n" +
                "\t\"data\":{\n" +
                "\t\t\"lines\":[\n" +
                "\t\t\t{\n" +
                "\t\t\t\t\"device\":{\n" +
                "\t\t\t\t\t\"id\":\"MR1L2LL/A\",\n" +
                "\t\t\t\t\t\"deviceId\":\"359433083362780\",\n" +
                "\t\t\t\t\t\"contractTerm\":\"MONTH_TO_MONTH\"\n" +
                "\t\t\t\t},\n" +
                "\t\t\t\t\"sim\":{\n" +
                "\t\t\t\t\t\"id\":\"DFILL4FF-NFC-A\",\n" +
                "\t\t\t\t\t\"iccid\":\"89148000000751553653\",\n" +
                "\t\t\t\t\t\"isCustomerProvidedSIM\":true,\n" +
                "\t\t\t\t\t\"eSIM\":\"89049032003008882300001955592066\",\n" +
                "\t\t\t\t\t\"imei2\":\"\"\n" +
                "\t\t\t\t},\n" +
                "\t\t\t\t\"mtn\":\"\",\n" +
                "\t\t\t\t\"ispuFlow\":false,\n" +
                "\t\t\t\t\"depletionType\":\"F\",\n" +
                "\t\t\t\t\"isKeepingExistingEqProtection\":true,\n" +
                "\t\t\t\t\"depletionLocationCode\":\"\",\n" +
                "\t\t\t\t\"numbersharePairingMode\":\"STANDALONE\",\n" +
                "\t\t\t\t\"isNewLine\":true,\n" +
                "\t\t\t\t\"newLineOrAAL\":true\n" +
                "\t\t\t}\n" +
                "\t\t]\n" +
                "\t}\n" +
                "}";
        AddDeviceUIRequest response = mapper.readValue(sampleResponseString, AddDeviceUIRequest.class);
        String uiResponseString = "{\r\n" + "    \"uiMeta\": {\r\n" + "        \"timestamp\": 1606904076236,\r\n"
                + "        \"cxpCorrelationId\": \"2020-12-02T10:14:36.+0000:90be2abf-a4e2-4e0e-8fcb-4edcdee0a1e6:cxp-customerprofile-se-qa-ev6v-sit4w-nscxp-756b46467b-5z5q6:nssit4\"\r\n"
                + "    },\r\n" + "    \"uiData\": {\r\n" + "        \"deviceInfo\": {\r\n"
                + "            \"deviceId\": \"359433083362780\",\r\n" + "            \"mfgCode\": \"APL\",\r\n"
                + "            \"prodName\": \"APPLE WATCH S3 42 SPBLK MIL\",\r\n"
                + "            \"prodType\": \"ConnectedDevice\",\r\n" + "            \"eqpModeCode\": \"4GE\",\r\n"
                + "            \"eqpMode\": \"4G\",\r\n" + "            \"ems\": \"N\",\r\n"
                + "            \"mms\": \"Y\",\r\n" + "            \"gps\": \"Y\",\r\n"
                + "            \"ptt\": \"N\",\r\n" + "            \"globalPhone\": \"O\",\r\n"
                + "            \"wap\": \"N/A\",\r\n" + "            \"bluetooth\": \"Y\",\r\n"
                + "            \"brew\": \"N\",\r\n" + "            \"trustedMode\": \"N\",\r\n"
                + "            \"csim\": \"\",\r\n" + "            \"ehrpd\": \"N\",\r\n"
                + "            \"smsevdo\": \"N\",\r\n" + "            \"deviceCategory\": \"phone\",\r\n"
                + "            \"visionProdId\": \"38940\",\r\n" + "            \"preferredSim\": \"\",\r\n"
                + "            \"backupAssistCapable\": \"N\",\r\n" + "            \"simClass4G\": \"NR\",\r\n"
                + "            \"virtualSimSku\": \"\",\r\n" + "            \"deviceNoPay\": \"N\",\r\n"
                + "            \"deviceLostStolen\": \"N\",\r\n" + "            \"deviceSdmLock\": \"\",\r\n"
                + "            \"deviceLock\": \"\",\r\n" + "            \"devicePibLock\": \"\",\r\n"
                + "            \"prepayEligibility\": \"00\",\r\n" + "            \"eligibilityDate\": \"\",\r\n"
                + "            \"outletId\": \"\",\r\n" + "            \"dacc\": \"\",\r\n"
                + "            \"deviceType\": \"4GE\",\r\n" + "            \"provTechType\": \"LTE\",\r\n"
                + "            \"launchPackageSku\": \"QTAX53B\",\r\n" + "            \"imSku\": \"MR1L2LL/A\",\r\n"
                + "            \"deviceCapabilityInd\": \"VD\",\r\n" + "            \"nfcCapable\": \"Y\",\r\n"
                + "            \"nfcCompatible\": \"Y\",\r\n" + "            \"pibDevice\": \"N\",\r\n"
                + "            \"connectedDeviceInd\": null,\r\n"
                + "            \"deviceFamilyType\": \"Connected\",\r\n"
                + "            \"buddyUpgrdEligInd\": \"N\",\r\n" + "            \"restrictToFamilyInd\": \"Y\",\r\n"
                + "            \"nonGeoDeviceInd\": \"\",\r\n" + "            \"m2MAllow\": \"M2MC\",\r\n"
                + "            \"hdVoice\": \"Y\",\r\n" + "            \"alkDevice\": \"HD\",\r\n"
                + "            \"shipDate\": \"20-DEC-2017\",\r\n" + "            \"cpo\": \"N\",\r\n"
                + "            \"lsClientId\": \"\",\r\n" + "            \"lsCustomerId\": \"\",\r\n"
                + "            \"lsBillAcctNumber\": \"\",\r\n" + "            \"v4B\": \"\",\r\n"
                + "            \"icEligInd\": \"\",\r\n" + "            \"icRemDays\": \"\",\r\n"
                + "            \"icRemSubsidyAmt\": \"\",\r\n" + "            \"e911AddrInd\": \"Y\",\r\n"
                + "            \"euiccCapable\": \"Y\",\r\n" + "            \"numberShareCapability\": \"Y\",\r\n"
                + "            \"wifiCalling\": \"Y\",\r\n" + "            \"vvm\": \"N\",\r\n"
                + "            \"imei1\": \"\",\r\n" + "            \"imei2\": \"\",\r\n"
                + "            \"osType\": \"WatchOS4\",\r\n" + "            \"postpaidRestrictStartDate\": \"\",\r\n"
                + "            \"dsEs12Fqdn\": \"\"\r\n" + "        },\r\n" + "        \"simInfo\": {\r\n"
                + "            \"simId\": \"89148000000751553653\",\r\n" + "            \"mfgCode\": \"GTO\",\r\n"
                + "            \"prodName\": \"Gemalto 4FF NFC SIM - DF\",\r\n" + "            \"simGroup\": \"\",\r\n"
                + "            \"prodType\": \"4G_4FF_SIM\",\r\n" + "            \"simFormFactor\": \"\",\r\n"
                + "            \"simNoPay\": \"N\",\r\n" + "            \"simLostStolen\": \"N\",\r\n"
                + "            \"simLock\": \"\",\r\n" + "            \"simPibLock\": \"\",\r\n"
                + "            \"outletId\": \"\",\r\n" + "            \"sacc\": \"00722\",\r\n"
                + "            \"simType\": \"4GS\",\r\n" + "            \"iccidStatus\": \"AA\",\r\n"
                + "            \"numberLocation\": \"\",\r\n" + "            \"provTechType\": \"LTE\",\r\n"
                + "            \"launchPackageSku\": \"DFILL4FF-NFC-A\",\r\n"
                + "            \"imSku\": \"DFILL4FF-NFC-A\",\r\n" + "            \"nfcCapable\": \"Y\",\r\n"
                + "            \"nfcCompatible\": \"\",\r\n" + "            \"solderedSim\": \"\",\r\n"
                + "            \"simCapable\": \"DUAL_IMSI\",\r\n"
                + "            \"selfActivationCapableInd\": null,\r\n" + "            \"lsClientId\": \"\",\r\n"
                + "            \"lsCustomerId\": \"\",\r\n" + "            \"lsBillAcctNumber\": \"\",\r\n"
                + "            \"saleRetailer\": \"\",\r\n" + "            \"simSkuType\": \"T\",\r\n"
                + "            \"personalizedStatus\": \"\",\r\n" + "            \"personalizedTimeStamp\": \"\"\r\n"
                + "        },\r\n" + "        \"deviceSimCompatible\": \"Y\",\r\n"
                + "        \"deviceSimM2MPair\": \"N\",\r\n" + "        \"deviceESimCompatible\": \"\",\r\n"
                + "        \"deviceEsimM2MPair\": \"Y\",\r\n" + "        \"esimInfo\": {\r\n"
                + "            \"mfgCode\": \"\",\r\n" + "            \"launchPackageSku\": \"\",\r\n"
                + "            \"prodName\": \"\",\r\n" + "            \"preferredSoftSim\": \"SOFTNASIM-MP-D\",\r\n"
                + "            \"launchPackageSkuType\": \"\",\r\n" + "            \"pairedIccid\": \"\",\r\n"
                + "            \"eID\": \"89049032003008882300001955592066\"\r\n" + "        }\r\n" + "    }\r\n" + "}";
        DeviceSimDetailsUIResponse uiResponse = mapper.readValue(uiResponseString, DeviceSimDetailsUIResponse.class);
        CartRedisData redisData=new CartRedisData();
        redisData.setCartId("69a66ef4d7e344dfb2db299209ea8333");
        redisData.setCaseId("123");
        redisData.setAccountNumber("0213143123-00001");
        redisData.setProcessingMTN("8136958775");
        redisData.setCartCreator("8136958775");
        URI url = URI.create("http://localhost/startBBPFlow");
        String bbpRequestVOString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"iccid\":\"89148000000835900342\",\"imei\":\"352898071702915\",\"isSmartphone\":true}";
        BBPRequestVO bbpRequestVO = mapper.readValue(bbpRequestVOString, BBPRequestVO.class);
        response = cartController.populateAddDeviceflow(uiResponse, redisData,
                "http://localhost/startBBPFlow","",bbpRequestVO);
        StepVerifier.create(Mono.just(response)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void populateAddDeviceFlowForRingTest() throws IOException {
		File responseFile = ResourceUtils.getFile("src/test/resources/AddDeviceUIRequest4.json");
		String responseString = new String(Files.readAllBytes(responseFile.toPath()));
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        AddDeviceUIRequest response = mapper.readValue(responseString, AddDeviceUIRequest.class);
        String uiResponseString = "{\r\n" + "    \"uiMeta\": {\r\n" + "        \"timestamp\": 1606904076236,\r\n"
                + "        \"cxpCorrelationId\": \"2020-12-02T10:14:36.+0000:90be2abf-a4e2-4e0e-8fcb-4edcdee0a1e6:cxp-customerprofile-se-qa-ev6v-sit4w-nscxp-756b46467b-5z5q6:nssit4\"\r\n"
                + "    },\r\n" + "    \"uiData\": {\r\n" + "        \"deviceInfo\": {\r\n"
                + "            \"deviceId\": \"359433083362780\",\r\n" + "            \"mfgCode\": \"APL\",\r\n"
                + "            \"prodName\": \"APPLE WATCH S3 42 SPBLK MIL RING\",\r\n"
                + "            \"prodType\": \"ConnectedDevice\",\r\n" + "            \"eqpModeCode\": \"4GE\",\r\n"
                + "            \"eqpMode\": \"4G\",\r\n" + "            \"ems\": \"N\",\r\n"
                + "            \"mms\": \"Y\",\r\n" + "            \"gps\": \"Y\",\r\n"
                + "            \"ptt\": \"N\",\r\n" + "            \"globalPhone\": \"O\",\r\n"
                + "            \"wap\": \"N/A\",\r\n" + "            \"bluetooth\": \"Y\",\r\n"
                + "            \"brew\": \"N\",\r\n" + "            \"trustedMode\": \"N\",\r\n"
                + "            \"csim\": \"\",\r\n" + "            \"ehrpd\": \"N\",\r\n"
                + "            \"smsevdo\": \"N\",\r\n" + "            \"deviceCategory\": \"ring_device\",\r\n"
                + "            \"visionProdId\": \"38940\",\r\n" + "            \"preferredSim\": \"\",\r\n"
                + "            \"backupAssistCapable\": \"N\",\r\n" + "            \"simClass4G\": \"NR\",\r\n"
                + "            \"virtualSimSku\": \"\",\r\n" + "            \"deviceNoPay\": \"N\",\r\n"
                + "            \"deviceLostStolen\": \"N\",\r\n" + "            \"deviceSdmLock\": \"\",\r\n"
                + "            \"deviceLock\": \"\",\r\n" + "            \"devicePibLock\": \"\",\r\n"
                + "            \"prepayEligibility\": \"00\",\r\n" + "            \"eligibilityDate\": \"\",\r\n"
                + "            \"outletId\": \"\",\r\n" + "            \"dacc\": \"\",\r\n"
                + "            \"deviceType\": \"4GE\",\r\n" + "            \"provTechType\": \"LTE\",\r\n"
                + "            \"launchPackageSku\": \"4K11V90ENV\",\r\n" + "            \"imSku\": \"MR1L2LL/A\",\r\n"
                + "            \"deviceCapabilityInd\": \"VD\",\r\n" + "            \"nfcCapable\": \"Y\",\r\n"
                + "            \"nfcCompatible\": \"Y\",\r\n" + "            \"pibDevice\": \"N\",\r\n"
                + "            \"connectedDeviceInd\": null,\r\n"
                + "            \"deviceFamilyType\": \"Connected\",\r\n"
                + "            \"buddyUpgrdEligInd\": \"N\",\r\n" + "            \"restrictToFamilyInd\": \"Y\",\r\n"
                + "            \"nonGeoDeviceInd\": \"\",\r\n" + "            \"m2MAllow\": \"M2MC\",\r\n"
                + "            \"hdVoice\": \"Y\",\r\n" + "            \"alkDevice\": \"HD\",\r\n"
                + "            \"shipDate\": \"20-DEC-2017\",\r\n" + "            \"cpo\": \"N\",\r\n"
                + "            \"lsClientId\": \"\",\r\n" + "            \"lsCustomerId\": \"\",\r\n"
                + "            \"lsBillAcctNumber\": \"\",\r\n" + "            \"v4B\": \"\",\r\n"
                + "            \"icEligInd\": \"\",\r\n" + "            \"icRemDays\": \"\",\r\n"
                + "            \"icRemSubsidyAmt\": \"\",\r\n" + "            \"e911AddrInd\": \"Y\",\r\n"
                + "            \"euiccCapable\": \"Y\",\r\n" + "            \"numberShareCapability\": \"Y\",\r\n"
                + "            \"wifiCalling\": \"Y\",\r\n" + "            \"vvm\": \"N\",\r\n"
                + "            \"imei1\": \"\",\r\n" + "            \"imei2\": \"\",\r\n"
                + "            \"osType\": \"WatchOS4\",\r\n" + "            \"postpaidRestrictStartDate\": \"\",\r\n"
                + "            \"dsEs12Fqdn\": \"\"\r\n" + "        },\r\n" + "        \"simInfo\": {\r\n"
                + "            \"simId\": \"89148000000751553653\",\r\n" + "            \"mfgCode\": \"GTO\",\r\n"
                + "            \"prodName\": \"Gemalto 4FF NFC SIM - DF\",\r\n" + "            \"simGroup\": \"\",\r\n"
                + "            \"prodType\": \"4G_4FF_SIM\",\r\n" + "            \"simFormFactor\": \"\",\r\n"
                + "            \"simNoPay\": \"N\",\r\n" + "            \"simLostStolen\": \"N\",\r\n"
                + "            \"simLock\": \"\",\r\n" + "            \"simPibLock\": \"\",\r\n"
                + "            \"outletId\": \"\",\r\n" + "            \"sacc\": \"00722\",\r\n"
                + "            \"simType\": \"4GS\",\r\n" + "            \"iccidStatus\": \"AA\",\r\n"
                + "            \"numberLocation\": \"\",\r\n" + "            \"provTechType\": \"LTE\",\r\n"
                + "            \"launchPackageSku\": \"DFILL4FF-NFC-A\",\r\n"
                + "            \"imSku\": \"DFILL4FF-NFC-A\",\r\n" + "            \"nfcCapable\": \"Y\",\r\n"
                + "            \"nfcCompatible\": \"\",\r\n" + "            \"solderedSim\": \"\",\r\n"
                + "            \"simCapable\": \"DUAL_IMSI\",\r\n"
                + "            \"selfActivationCapableInd\": null,\r\n" + "            \"lsClientId\": \"\",\r\n"
                + "            \"lsCustomerId\": \"\",\r\n" + "            \"lsBillAcctNumber\": \"\",\r\n"
                + "            \"saleRetailer\": \"\",\r\n" + "            \"simSkuType\": \"T\",\r\n"
                + "            \"personalizedStatus\": \"\",\r\n" + "            \"personalizedTimeStamp\": \"\"\r\n"
                + "        },\r\n" + "        \"deviceSimCompatible\": \"Y\",\r\n"
                + "        \"deviceSimM2MPair\": \"N\",\r\n" + "        \"deviceESimCompatible\": \"\",\r\n"
                + "        \"deviceEsimM2MPair\": \"Y\",\r\n" + "        \"esimInfo\": {\r\n"
                + "            \"mfgCode\": \"\",\r\n" + "            \"launchPackageSku\": \"\",\r\n"
                + "            \"prodName\": \"\",\r\n" + "            \"preferredSoftSim\": \"SOFTNASIM-MP-D\",\r\n"
                + "            \"launchPackageSkuType\": \"\",\r\n" + "            \"pairedIccid\": \"\",\r\n"
                + "            \"eID\": \"89049032003008882300001955592066\"\r\n" + "        }\r\n" + "    }\r\n" + "}";
        DeviceSimDetailsUIResponse uiResponse = mapper.readValue(uiResponseString, DeviceSimDetailsUIResponse.class);
        CartRedisData redisData=new CartRedisData();
        redisData.setCartId("69a66ef4d7e344dfb2db299209ea8333");
        redisData.setCaseId("123");
        redisData.setAccountNumber("0213143123-00001");
        redisData.setProcessingMTN("8136958775");
        redisData.setCartCreator("8136958775");
        URI url = URI.create("http://localhost/startBBPFlow");
        String bbpRequestVOString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"iccid\":\"89148000000835900342\",\"imei\":\"352898071702915\",\"isSmartphone\":true}";
        BBPRequestVO bbpRequestVO = mapper.readValue(bbpRequestVOString, BBPRequestVO.class);
        response = cartController.populateAddDeviceflow(uiResponse, redisData,
                "http://localhost/startBBPFlow","",bbpRequestVO);
        StepVerifier.create(Mono.just(response)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }


    @Test
    public void populateAddDeviceFlowForTrackerTest() throws IOException {
		File responseFile = ResourceUtils.getFile("src/test/resources/AddDeviceUIRequest3.json");
		String responseString = new String(Files.readAllBytes(responseFile.toPath()));
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        AddDeviceUIRequest response = mapper.readValue(responseString, AddDeviceUIRequest.class);
        String uiResponseString = "{\r\n" + "    \"uiMeta\": {\r\n" + "        \"timestamp\": 1606904076236,\r\n"
                + "        \"cxpCorrelationId\": \"2020-12-02T10:14:36.+0000:90be2abf-a4e2-4e0e-8fcb-4edcdee0a1e6:cxp-customerprofile-se-qa-ev6v-sit4w-nscxp-756b46467b-5z5q6:nssit4\"\r\n"
                + "    },\r\n" + "    \"uiData\": {\r\n" + "        \"deviceInfo\": {\r\n"
                + "            \"deviceId\": \"359433083362780\",\r\n" + "            \"mfgCode\": \"APL\",\r\n"
                + "            \"prodName\": \"APPLE WATCH S3 42 SPBLK MIL\",\r\n"
                + "            \"prodType\": \"4G_LOCATOR\",\r\n" + "            \"eqpModeCode\": \"4GE\",\r\n"
                + "            \"eqpMode\": \"4G\",\r\n" + "            \"ems\": \"N\",\r\n"
                + "            \"mms\": \"Y\",\r\n" + "            \"gps\": \"Y\",\r\n"
                + "            \"ptt\": \"N\",\r\n" + "            \"globalPhone\": \"O\",\r\n"
                + "            \"wap\": \"N/A\",\r\n" + "            \"bluetooth\": \"Y\",\r\n"
                + "            \"brew\": \"N\",\r\n" + "            \"trustedMode\": \"N\",\r\n"
                + "            \"csim\": \"\",\r\n" + "            \"ehrpd\": \"N\",\r\n"
                + "            \"smsevdo\": \"N\",\r\n" + "            \"deviceCategory\": \"ring_device\",\r\n"
                + "            \"visionProdId\": \"38940\",\r\n" + "            \"preferredSim\": \"\",\r\n"
                + "            \"backupAssistCapable\": \"N\",\r\n" + "            \"simClass4G\": \"NR\",\r\n"
                + "            \"virtualSimSku\": \"\",\r\n" + "            \"deviceNoPay\": \"N\",\r\n"
                + "            \"deviceLostStolen\": \"N\",\r\n" + "            \"deviceSdmLock\": \"\",\r\n"
                + "            \"deviceLock\": \"\",\r\n" + "            \"devicePibLock\": \"\",\r\n"
                + "            \"prepayEligibility\": \"00\",\r\n" + "            \"eligibilityDate\": \"\",\r\n"
                + "            \"outletId\": \"\",\r\n" + "            \"dacc\": \"01157\",\r\n"
                + "            \"deviceType\": \"4GE\",\r\n" + "            \"provTechType\": \"LTE\",\r\n"
                + "            \"launchPackageSku\": \"4K11V90ENV\",\r\n" + "            \"imSku\": \"MR1L2LL/A\",\r\n"
                + "            \"deviceCapabilityInd\": \"VD\",\r\n" + "            \"nfcCapable\": \"Y\",\r\n"
                + "            \"nfcCompatible\": \"Y\",\r\n" + "            \"pibDevice\": \"N\",\r\n"
                + "            \"connectedDeviceInd\": null,\r\n"
                + "            \"deviceFamilyType\": \"Connected\",\r\n"
                + "            \"buddyUpgrdEligInd\": \"N\",\r\n" + "            \"restrictToFamilyInd\": \"Y\",\r\n"
                + "            \"nonGeoDeviceInd\": \"\",\r\n" + "            \"m2MAllow\": \"M2MC\",\r\n"
                + "            \"hdVoice\": \"Y\",\r\n" + "            \"alkDevice\": \"HD\",\r\n"
                + "            \"shipDate\": \"20-DEC-2017\",\r\n" + "            \"cpo\": \"N\",\r\n"
                + "            \"lsClientId\": \"\",\r\n" + "            \"lsCustomerId\": \"\",\r\n"
                + "            \"lsBillAcctNumber\": \"\",\r\n" + "            \"v4B\": \"\",\r\n"
                + "            \"icEligInd\": \"\",\r\n" + "            \"icRemDays\": \"\",\r\n"
                + "            \"icRemSubsidyAmt\": \"\",\r\n" + "            \"e911AddrInd\": \"Y\",\r\n"
                + "            \"euiccCapable\": \"Y\",\r\n" + "            \"numberShareCapability\": \"Y\",\r\n"
                + "            \"wifiCalling\": \"Y\",\r\n" + "            \"vvm\": \"N\",\r\n"
                + "            \"imei1\": \"\",\r\n" + "            \"imei2\": \"\",\r\n"
                + "            \"osType\": \"WatchOS4\",\r\n" + "            \"postpaidRestrictStartDate\": \"\",\r\n"
                + "            \"dsEs12Fqdn\": \"\"\r\n" + "        },\r\n" + "        \"simInfo\": {\r\n"
                + "            \"simId\": \"89148000000751553653\",\r\n" + "            \"mfgCode\": \"GTO\",\r\n"
                + "            \"prodName\": \"Gemalto 4FF NFC SIM - DF\",\r\n" + "            \"simGroup\": \"\",\r\n"
                + "            \"prodType\": \"4G_4FF_SIM\",\r\n" + "            \"simFormFactor\": \"\",\r\n"
                + "            \"simNoPay\": \"N\",\r\n" + "            \"simLostStolen\": \"N\",\r\n"
                + "            \"simLock\": \"\",\r\n" + "            \"simPibLock\": \"\",\r\n"
                + "            \"outletId\": \"\",\r\n" + "            \"sacc\": \"00722\",\r\n"
                + "            \"simType\": \"4GS\",\r\n" + "            \"iccidStatus\": \"AA\",\r\n"
                + "            \"numberLocation\": \"\",\r\n" + "            \"provTechType\": \"LTE\",\r\n"
                + "            \"launchPackageSku\": \"DFILL4FF-NFC-A\",\r\n"
                + "            \"imSku\": \"DFILL4FF-NFC-A\",\r\n" + "            \"nfcCapable\": \"Y\",\r\n"
                + "            \"nfcCompatible\": \"\",\r\n" + "            \"solderedSim\": \"\",\r\n"
                + "            \"simCapable\": \"DUAL_IMSI\",\r\n"
                + "            \"selfActivationCapableInd\": null,\r\n" + "            \"lsClientId\": \"\",\r\n"
                + "            \"lsCustomerId\": \"\",\r\n" + "            \"lsBillAcctNumber\": \"\",\r\n"
                + "            \"saleRetailer\": \"\",\r\n" + "            \"simSkuType\": \"T\",\r\n"
                + "            \"personalizedStatus\": \"\",\r\n" + "            \"personalizedTimeStamp\": \"\"\r\n"
                + "        },\r\n" + "        \"deviceSimCompatible\": \"Y\",\r\n"
                + "        \"deviceSimM2MPair\": \"N\",\r\n" + "        \"deviceESimCompatible\": \"\",\r\n"
                + "        \"deviceEsimM2MPair\": \"Y\",\r\n" + "        \"esimInfo\": {\r\n"
                + "            \"mfgCode\": \"\",\r\n" + "            \"launchPackageSku\": \"\",\r\n"
                + "            \"prodName\": \"\",\r\n" + "            \"preferredSoftSim\": \"SOFTNASIM-MP-D\",\r\n"
                + "            \"launchPackageSkuType\": \"\",\r\n" + "            \"pairedIccid\": \"\",\r\n"
                + "            \"eID\": \"89049032003008882300001955592066\"\r\n" + "        }\r\n" + "    }\r\n" + "}";
        DeviceSimDetailsUIResponse uiResponse = mapper.readValue(uiResponseString, DeviceSimDetailsUIResponse.class);
        CartRedisData redisData=new CartRedisData();
        redisData.setCartId("69a66ef4d7e344dfb2db299209ea8333");
        redisData.setCaseId("123");
        redisData.setAccountNumber("0213143123-00001");
        redisData.setProcessingMTN("8136958775");
        redisData.setCartCreator("8136958775");
        URI url = URI.create("http://localhost/startBBPFlow");
        String bbpRequestVOString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"iccid\":\"89148000000835900342\",\"imei\":\"352898071702915\",\"isSmartphone\":true}";
        BBPRequestVO bbpRequestVO = mapper.readValue(bbpRequestVOString, BBPRequestVO.class);
        response = cartController.populateAddDeviceflow(uiResponse, redisData,
                "http://localhost/startBBPFlow","",bbpRequestVO);
        StepVerifier.create(Mono.just(response)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void populateAddDeviceFlowForGarminTest() throws IOException {
		File responseFile = ResourceUtils.getFile("src/test/resources/AddDeviceUIRequest2.json");
		String responseString = new String(Files.readAllBytes(responseFile.toPath()));
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        AddDeviceUIRequest response = mapper.readValue(responseString, AddDeviceUIRequest.class);
        String uiResponseString = "{\r\n" + "    \"uiMeta\": {\r\n" + "        \"timestamp\": 1606904076236,\r\n"
                + "        \"cxpCorrelationId\": \"2020-12-02T10:14:36.+0000:90be2abf-a4e2-4e0e-8fcb-4edcdee0a1e6:cxp-customerprofile-se-qa-ev6v-sit4w-nscxp-756b46467b-5z5q6:nssit4\"\r\n"
                + "    },\r\n" + "    \"uiData\": {\r\n" + "        \"deviceInfo\": {\r\n"
                + "            \"deviceId\": \"359433083362780\",\r\n" + "            \"mfgCode\": \"APL\",\r\n"
                + "            \"prodName\": \"APPLE WATCH S3 42 SPBLK MIL\",\r\n"
                + "            \"prodType\": \"4G_LOCATOR\",\r\n" + "            \"eqpModeCode\": \"4GE\",\r\n"
                + "            \"eqpMode\": \"4G\",\r\n" + "            \"ems\": \"N\",\r\n"
                + "            \"mms\": \"Y\",\r\n" + "            \"gps\": \"Y\",\r\n"
                + "            \"ptt\": \"N\",\r\n" + "            \"globalPhone\": \"O\",\r\n"
                + "            \"wap\": \"N/A\",\r\n" + "            \"bluetooth\": \"Y\",\r\n"
                + "            \"brew\": \"N\",\r\n" + "            \"trustedMode\": \"N\",\r\n"
                + "            \"csim\": \"\",\r\n" + "            \"ehrpd\": \"N\",\r\n"
                + "            \"smsevdo\": \"N\",\r\n" + "            \"deviceCategory\": \"ring_device\",\r\n"
                + "            \"visionProdId\": \"38940\",\r\n" + "            \"preferredSim\": \"\",\r\n"
                + "            \"backupAssistCapable\": \"N\",\r\n" + "            \"simClass4G\": \"NR\",\r\n"
                + "            \"virtualSimSku\": \"\",\r\n" + "            \"deviceNoPay\": \"N\",\r\n"
                + "            \"deviceLostStolen\": \"N\",\r\n" + "            \"deviceSdmLock\": \"\",\r\n"
                + "            \"deviceLock\": \"\",\r\n" + "            \"devicePibLock\": \"\",\r\n"
                + "            \"prepayEligibility\": \"00\",\r\n" + "            \"eligibilityDate\": \"\",\r\n"
                + "            \"outletId\": \"\",\r\n" + "            \"dacc\": \"01245\",\r\n"
                + "            \"deviceType\": \"4GE\",\r\n" + "            \"provTechType\": \"LTE\",\r\n"
                + "            \"launchPackageSku\": \"4K11V90ENV\",\r\n" + "            \"imSku\": \"MR1L2LL/A\",\r\n"
                + "            \"deviceCapabilityInd\": \"VD\",\r\n" + "            \"nfcCapable\": \"Y\",\r\n"
                + "            \"nfcCompatible\": \"Y\",\r\n" + "            \"pibDevice\": \"N\",\r\n"
                + "            \"connectedDeviceInd\": null,\r\n"
                + "            \"deviceFamilyType\": \"Connected\",\r\n"
                + "            \"buddyUpgrdEligInd\": \"N\",\r\n" + "            \"restrictToFamilyInd\": \"Y\",\r\n"
                + "            \"nonGeoDeviceInd\": \"\",\r\n" + "            \"m2MAllow\": \"M2MC\",\r\n"
                + "            \"hdVoice\": \"Y\",\r\n" + "            \"alkDevice\": \"HD\",\r\n"
                + "            \"shipDate\": \"20-DEC-2017\",\r\n" + "            \"cpo\": \"N\",\r\n"
                + "            \"lsClientId\": \"\",\r\n" + "            \"lsCustomerId\": \"\",\r\n"
                + "            \"lsBillAcctNumber\": \"\",\r\n" + "            \"v4B\": \"\",\r\n"
                + "            \"icEligInd\": \"\",\r\n" + "            \"icRemDays\": \"\",\r\n"
                + "            \"icRemSubsidyAmt\": \"\",\r\n" + "            \"e911AddrInd\": \"Y\",\r\n"
                + "            \"euiccCapable\": \"Y\",\r\n" + "            \"numberShareCapability\": \"Y\",\r\n"
                + "            \"wifiCalling\": \"Y\",\r\n" + "            \"vvm\": \"N\",\r\n"
                + "            \"imei1\": \"\",\r\n" + "            \"imei2\": \"\",\r\n"
                + "            \"osType\": \"WatchOS4\",\r\n" + "            \"postpaidRestrictStartDate\": \"\",\r\n"
                + "            \"dsEs12Fqdn\": \"\"\r\n" + "        },\r\n" + "        \"simInfo\": {\r\n"
                + "            \"simId\": \"89148000000751553653\",\r\n" + "            \"mfgCode\": \"GTO\",\r\n"
                + "            \"prodName\": \"Gemalto 4FF NFC SIM - DF\",\r\n" + "            \"simGroup\": \"\",\r\n"
                + "            \"prodType\": \"4G_4FF_SIM\",\r\n" + "            \"simFormFactor\": \"\",\r\n"
                + "            \"simNoPay\": \"N\",\r\n" + "            \"simLostStolen\": \"N\",\r\n"
                + "            \"simLock\": \"\",\r\n" + "            \"simPibLock\": \"\",\r\n"
                + "            \"outletId\": \"\",\r\n" + "            \"sacc\": \"00722\",\r\n"
                + "            \"simType\": \"4GS\",\r\n" + "            \"iccidStatus\": \"AA\",\r\n"
                + "            \"numberLocation\": \"\",\r\n" + "            \"provTechType\": \"LTE\",\r\n"
                + "            \"launchPackageSku\": \"DFILL4FF-NFC-A\",\r\n"
                + "            \"imSku\": \"DFILL4FF-NFC-A\",\r\n" + "            \"nfcCapable\": \"Y\",\r\n"
                + "            \"nfcCompatible\": \"\",\r\n" + "            \"solderedSim\": \"\",\r\n"
                + "            \"simCapable\": \"DUAL_IMSI\",\r\n"
                + "            \"selfActivationCapableInd\": null,\r\n" + "            \"lsClientId\": \"\",\r\n"
                + "            \"lsCustomerId\": \"\",\r\n" + "            \"lsBillAcctNumber\": \"\",\r\n"
                + "            \"saleRetailer\": \"\",\r\n" + "            \"simSkuType\": \"T\",\r\n"
                + "            \"personalizedStatus\": \"\",\r\n" + "            \"personalizedTimeStamp\": \"\"\r\n"
                + "        },\r\n" + "        \"deviceSimCompatible\": \"Y\",\r\n"
                + "        \"deviceSimM2MPair\": \"N\",\r\n" + "        \"deviceESimCompatible\": \"\",\r\n"
                + "        \"deviceEsimM2MPair\": \"Y\",\r\n" + "        \"esimInfo\": {\r\n"
                + "            \"mfgCode\": \"\",\r\n" + "            \"launchPackageSku\": \"\",\r\n"
                + "            \"prodName\": \"\",\r\n" + "            \"preferredSoftSim\": \"SOFTNASIM-MP-D\",\r\n"
                + "            \"launchPackageSkuType\": \"\",\r\n" + "            \"pairedIccid\": \"\",\r\n"
                + "            \"eID\": \"89049032003008882300001955592066\"\r\n" + "        }\r\n" + "    }\r\n" + "}";
        DeviceSimDetailsUIResponse uiResponse = mapper.readValue(uiResponseString, DeviceSimDetailsUIResponse.class);
        CartRedisData redisData=new CartRedisData();
        redisData.setCartId("69a66ef4d7e344dfb2db299209ea8333");
        redisData.setCaseId("123");
        redisData.setAccountNumber("0213143123-00001");
        redisData.setProcessingMTN("8136958775");
        redisData.setCartCreator("8136958775");
        URI url = URI.create("http://localhost/startBBPFlow");
        String bbpRequestVOString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"iccid\":\"89148000000835900342\",\"imei\":\"352898071702915\",\"isSmartphone\":true}";
        BBPRequestVO bbpRequestVO = mapper.readValue(bbpRequestVOString, BBPRequestVO.class);
        response = cartController.populateAddDeviceflow(uiResponse, redisData,
                "http://localhost/startBBPFlow","",bbpRequestVO);
        StepVerifier.create(Mono.just(response)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void populateAddDeviceFlowForTabletTest() throws IOException {
		File responseFile = ResourceUtils.getFile("src/test/resources/AddDeviceUIRequest1.json");
		String responseString = new String(Files.readAllBytes(responseFile.toPath()));
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        AddDeviceUIRequest response = mapper.readValue(responseString, AddDeviceUIRequest.class);
        String uiResponseString = "{\r\n" + "    \"uiMeta\": {\r\n" + "        \"timestamp\": 1606904076236,\r\n"
                + "        \"cxpCorrelationId\": \"2020-12-02T10:14:36.+0000:90be2abf-a4e2-4e0e-8fcb-4edcdee0a1e6:cxp-customerprofile-se-qa-ev6v-sit4w-nscxp-756b46467b-5z5q6:nssit4\"\r\n"
                + "    },\r\n" + "    \"uiData\": {\r\n" + "        \"deviceInfo\": {\r\n"
                + "            \r\n" + "            \"mfgCode\": \"APL\",\r\n"
                + "            \"prodName\": \"APPLE WATCH S3 42 SPBLK MIL\",\r\n"
                + "            \"prodType\": \"4G_LOCATOR\",\r\n" + "            \"eqpModeCode\": \"4GE\",\r\n"
                + "            \"eqpMode\": \"4G\",\r\n" + "            \"ems\": \"N\",\r\n"
                + "            \"mms\": \"Y\",\r\n" + "            \"gps\": \"Y\",\r\n"
                + "            \"ptt\": \"N\",\r\n" + "            \"globalPhone\": \"O\",\r\n"
                + "            \"wap\": \"N/A\",\r\n" + "            \"bluetooth\": \"Y\",\r\n"
                + "            \"brew\": \"N\",\r\n" + "            \"trustedMode\": \"N\",\r\n"
                + "            \"csim\": \"\",\r\n" + "            \"ehrpd\": \"N\",\r\n"
                + "            \"smsevdo\": \"N\",\r\n" + "            \"deviceCategory\": \"4g tablet\",\r\n"
                + "            \"visionProdId\": \"38940\",\r\n" + "            \"preferredSim\": \"\",\r\n"
                + "            \"backupAssistCapable\": \"N\",\r\n" + "            \"simClass4G\": \"NR\",\r\n"
                + "            \"virtualSimSku\": \"\",\r\n" + "            \"deviceNoPay\": \"N\",\r\n"
                + "            \"deviceLostStolen\": \"N\",\r\n" + "            \"deviceSdmLock\": \"\",\r\n"
                + "            \"deviceLock\": \"\",\r\n" + "            \"devicePibLock\": \"\",\r\n"
                + "            \"prepayEligibility\": \"00\",\r\n" + "            \"eligibilityDate\": \"\",\r\n"
                + "            \"outletId\": \"\",\r\n" + "            \"dacc\": \"01245\",\r\n"
                + "            \"deviceType\": \"4GE\",\r\n" + "            \"provTechType\": \"LTE\",\r\n"
                + "            \"launchPackageSku\": \"4K11V90ENV\",\r\n" + "          \r\n"
                + "            \"deviceCapabilityInd\": \"VD\",\r\n" + "            \"nfcCapable\": \"Y\",\r\n"
                + "            \"nfcCompatible\": \"Y\",\r\n" + "            \"pibDevice\": \"N\",\r\n"
                + "            \"connectedDeviceInd\": null,\r\n"
                + "            \"deviceFamilyType\": \"Connected\",\r\n"
                + "            \"buddyUpgrdEligInd\": \"N\",\r\n" + "            \"restrictToFamilyInd\": \"Y\",\r\n"
                + "            \"nonGeoDeviceInd\": \"\",\r\n" + "            \"m2MAllow\": \"M2MC\",\r\n"
                + "            \"hdVoice\": \"Y\",\r\n" + "            \"alkDevice\": \"HD\",\r\n"
                + "            \"shipDate\": \"20-DEC-2017\",\r\n" + "            \"cpo\": \"N\",\r\n"
                + "            \"lsClientId\": \"\",\r\n" + "            \"lsCustomerId\": \"\",\r\n"
                + "            \"lsBillAcctNumber\": \"\",\r\n" + "            \"v4B\": \"\",\r\n"
                + "            \"icEligInd\": \"\",\r\n" + "            \"icRemDays\": \"\",\r\n"
                + "            \"icRemSubsidyAmt\": \"\",\r\n" + "            \"e911AddrInd\": \"Y\",\r\n"
                + "            \"euiccCapable\": \"Y\",\r\n" + "            \"numberShareCapability\": \"Y\",\r\n"
                + "            \"wifiCalling\": \"Y\",\r\n" + "            \"vvm\": \"N\",\r\n"
                + "            \"imei1\": \"\",\r\n" + "            \"imei2\": \"\",\r\n"
                + "            \"osType\": \"WatchOS4\",\r\n" + "            \"postpaidRestrictStartDate\": \"\",\r\n"
                + "            \"dsEs12Fqdn\": \"\"\r\n" + "        },\r\n" + "        \"simInfo\": {\r\n"
                + "            \r\n" + "            \"mfgCode\": \"GTO\",\r\n"
                + "            \"prodName\": \"Gemalto 4FF NFC SIM - DF\",\r\n" + "            \"simGroup\": \"\",\r\n"
                + "            \"prodType\": \"4G_4FF_SIM\",\r\n" + "            \"simFormFactor\": \"\",\r\n"
                + "            \"simNoPay\": \"N\",\r\n" + "            \"simLostStolen\": \"N\",\r\n"
                + "            \"simLock\": \"\",\r\n" + "            \"simPibLock\": \"\",\r\n"
                + "            \"outletId\": \"\",\r\n" + "            \"sacc\": \"00722\",\r\n"
                + "            \"simType\": \"4GS\",\r\n" + "            \"iccidStatus\": \"AA\",\r\n"
                + "            \"numberLocation\": \"\",\r\n" + "            \"provTechType\": \"LTE\",\r\n"
                + "            \"launchPackageSku\": \"DFILL4FF-NFC-A\",\r\n"
                + "            \r\n" + "            \"nfcCapable\": \"Y\",\r\n"
                + "            \"nfcCompatible\": \"\",\r\n" + "            \"solderedSim\": \"\",\r\n"
                + "            \"simCapable\": \"DUAL_IMSI\",\r\n"
                + "            \"selfActivationCapableInd\": null,\r\n" + "            \"lsClientId\": \"\",\r\n"
                + "            \"lsCustomerId\": \"\",\r\n" + "            \"lsBillAcctNumber\": \"\",\r\n"
                + "            \"saleRetailer\": \"\",\r\n" + "            \"simSkuType\": \"T\",\r\n"
                + "            \"personalizedStatus\": \"\",\r\n" + "            \"personalizedTimeStamp\": \"\"\r\n"
                + "        },\r\n" + "        \"deviceSimCompatible\": \"Y\",\r\n"
                + "        \"deviceSimM2MPair\": \"N\",\r\n" + "        \"deviceESimCompatible\": \"\",\r\n"
                + "        \"deviceEsimM2MPair\": \"Y\",\r\n" + "        \"esimInfo\": {\r\n"
                + "            \"mfgCode\": \"\",\r\n" + "            \"launchPackageSku\": \"\",\r\n"
                + "            \"prodName\": \"\",\r\n" + "            \"preferredSoftSim\": \"SOFTNASIM-MP-D\",\r\n"
                + "            \"launchPackageSkuType\": \"\",\r\n" + "            \"pairedIccid\": \"\"\r\n"
                + "                    }\r\n" + "    }\r\n" + "}";
        DeviceSimDetailsUIResponse uiResponse = mapper.readValue(uiResponseString, DeviceSimDetailsUIResponse.class);
        CartRedisData redisData=new CartRedisData();
        redisData.setCartId("69a66ef4d7e344dfb2db299209ea8333");
        redisData.setCaseId("123");
        redisData.setAccountNumber("0213143123-00001");
        redisData.setProcessingMTN("8136958775");
        redisData.setCartCreator("8136958775");
        URI url = URI.create("http://localhost/startBBPFlow");
        String bbpRequestVOString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"iccid\":\"89148000000835900342\",\"imei\":\"352898071702915\",\"isSmartphone\":true}";
        BBPRequestVO bbpRequestVO = mapper.readValue(bbpRequestVOString, BBPRequestVO.class);
        response = cartController.populateAddDeviceflow(uiResponse, redisData,
                "http://localhost/startBBPFlow","",bbpRequestVO);
        StepVerifier.create(Mono.just(response)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }
    
    @Test
	public void bbpGetProcessStepTest3() throws IOException {

		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM-BBP\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"cartId\":\"\",\"caseId\":\"\",\"processingMTN\":\"newLine1\",\"processStep\":\"AccountPlanPage\",\"processAction\":\"\"}}";
		BBPGetProcessStepUIRequest bbpgetprocessstepUiRequest = mapper.readValue(sampleRequestString, BBPGetProcessStepUIRequest.class);
		String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM-BBP\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ServiceAddress\"}],\"intent\":\"BYOD\",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ServiceAddress\",\"processAction\":\"\"},\"customerInfo\":{\"registerNumber\":0,\"pinCardPayment\":false,\"accountNumber\":\"\",\"cartCreator\":\"3098461507\",\"processingMTN\":\"newLine1\"},\"cartInfo\":{\"cartId\":\"\"}}}}}";
		BbpGetProcessStepUIResponse bbpgetprocessstepUiResponse = mapper.readValue(sampleResponseString,BbpGetProcessStepUIResponse.class);
		when(cartHelper.bbpGetProcessStep(Mockito.any())).thenReturn(Mono.just(bbpgetprocessstepUiResponse));
		URI url = URI.create("");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = null;
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.bbpGetProcessStep(httpHeader,httpResponse, bbpgetprocessstepUiRequest);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
    
    @Test
    public void populateAddDeviceFlowTest1() throws IOException {
        String sampleResponseString = "{\"cartInfo\":{\"accountNumber\":\"0220561307-00002\",\"cartCreator\":\"8439410557\",\"globalId\":\"\",\"sessionId\":\"\",\"mtnFlow\":\"\",\"intendype\":\"BYOD\",\"processStep\":\"\",\"processAction\":\"addDevice\",\"clientAppName\":\"VZW-DOCOM-BBP\",\"numberShareCapable\":\"Y\",\"eNineAddressIndicator\":\"true\",\"deviceType\":\"PHONE\",\"bbpInent\":\"BYOD\",\"triggerPricingValidaion\":true},\"data\":{\"lines\":[{\"device\":{\"id\":\"MR1L2LL/A\",\"deviceId\":\"359433083362780\",\"conractTerm\":\"MONTH_O_MONTH\"},\"sim\":{\"id\":\"DFILL4FF-NFC-A\",\"iccid\":\"89148000000751553653\",\"isCusomerProvidedSIM\":true,\"eSIM\":\"89049032003008882300001955592066\",\"imei2\":\"\"},\"mtn\":\"\",\"ispuFlow\":false,\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"depletionLocationCode\":\"\",\"numbersharePairingMode\":\"STANDALONE\",\"isNewLine\":true,\"newLineOrAAL\":true}]}}";
        AddDeviceUIRequest response = mapper.readValue(sampleResponseString, AddDeviceUIRequest.class);
        String uiResponseString = "{\"uiMeta\": {\"timestamp\": 1606904076236,\"cxpCorrelationId\": \"2020-12-02T10:14:36.+0000:90be2abf-a4e2-4e0e-8fcb-4edcdee0a1e6:cxp-customerprofile-se-qa-ev6v-sit4w-nscxp-756b46467b-5z5q6:nssit4\"},\"uiData\": {\"deviceInfo\": { \"deviceId\": \"359433083362780\",\"mfgCode\": \"APL\",\"prodName\": \"APPLE WATCH S3 42 SPBLK MIL\",\"prodType\": \"4G_LOCATOR\",\"eqpModeCode\": \"4GE\",\"eqpMode\": \"4G\",\"ems\": \"N\",\"mms\": \"Y\",\"gps\": \"Y\",\"ptt\": \"N\",\"globalPhone\": \"O\",\"wap\": \"N/A\",\"bluetooth\": \"Y\",\"brew\": \"N\",\"trustedMode\": \"N\",\"csim\": \"\",\"ehrpd\": \"N\",\"smsevdo\": \"N\",\"deviceCategory\": \"\",\"visionProdId\": \"38940\",\"preferredSim\": \"\",\"backupAssistCapable\": \"N\",\"simClass4G\": \"NR\",\"virtualSimSku\": \"\",\"deviceNoPay\": \"N\", \"deviceLostStolen\": \"N\",\"deviceSdmLock\": \"\",\"deviceLock\": \"\",\"devicePibLock\": \"\",\"prepayEligibility\": \"00\",\"eligibilityDate\": \"\",\"outletId\": \"\",\"dacc\": \"sdk.tracker.daccs\",\"deviceType\": \"4GE\",\"provTechType\": \"LTE\",\"launchPackageSku\": \"\",\"imSku\": \"MR1L2LL/A\",\"deviceCapabilityInd\": \"VD\",\"nfcCapable\": \"Y\",\"nfcCompatible\": \"Y\",\"pibDevice\": \"N\",\"connectedDeviceInd\": null,\"deviceFamilyType\": \"Connected\",\"buddyUpgrdEligInd\": \"N\",\"restrictToFamilyInd\": \"Y\",\"nonGeoDeviceInd\": \"\",\"m2MAllow\": \"M2MC\",\"hdVoice\": \"Y\",\"alkDevice\": \"HD\",\"shipDate\": \"20-DEC-2017\",\"cpo\": \"N\",\"lsClientId\": \"\",\"lsCustomerId\": \"\",\"lsBillAcctNumber\": \"\",\"v4B\": \"\",\"icEligInd\": \"\",\"icRemDays\": \"\",\"icRemSubsidyAmt\": \"\",\"e911AddrInd\": \"Y\",\"euiccCapable\": \"Y\",\"numberShareCapability\": \"Y\",\"wifiCalling\": \"Y\",\"vvm\": \"N\",\"imei1\": \"\",\"imei2\": \"\",\"osType\": \"WatchOS4\",\"postpaidRestrictStartDate\": \"\",\"dsEs12Fqdn\": \"\"},\"simInfo\": {\"simId\": \"89148000000751553653\",\"mfgCode\": \"GTO\",\"proName\": \"Gemalto 4FF NFC SIM - DF\",\"simGroup\": \"\",\"prodType\": \"4G_4FF_SIM\",\"simFormFactor\": \"\",\"simNoPay\": \"N\",\"simLostStolen\": \"N\",\"simLock\": \"\",\"simPibLock\": \"\",\"outletId\": \"\",\"sacc\": \"00722\",\"simType\": \"4GS\",\"iccidStatus\": \"AA\",\"numberLocation\": \"\",\"provTechType\": \"LTE\",\"launchPackageSku\": \"DFILL4FF-NFC-A\",\"imSku\": \"DFILL4FF-NFC-A\",\"nfcCapable\": \"Y\",\"nfcCompatible\": \"\",\"solderedSim\": \"\",\"simCapable\": \"DUAL_IMSI\",\"selfActivationCapableInd\": null,\"lsClientId\": \"\",\"lsCustomerId\": \"\",\"lsBillAcctNumber\": \"\",\"saleRetailer\": \"\",\"simSkuType\": \"T\",\"personalizedStatus\": \"\",\"personalizedTimeStamp\": \"\"},\"deviceSimCompatible\": \"Y\",\"deviceSimM2MPair\": \"N\",\"deviceESimCompatible\": \"\",\"deviceEsimM2MPair\": \"Y\",\"esimInfo\": {\"mfgCode\": \"\",\"launchPackageSku\": \"\",\"prodName\": \"\",\"preferredSoftSim\": \"SOFTNASIM-MP-D\",\"launchPackageSkuType\": \"\",\"pairedIccid\": \"\", \"eID\": \"8904903203008882300001955592066\"}}}";
        DeviceSimDetailsUIResponse uiResponse = mapper.readValue(uiResponseString, DeviceSimDetailsUIResponse.class);
        CartRedisData redisData=new CartRedisData();
        redisData.setCartId("69a66ef4d7e344dfb2db299209ea8333");
        redisData.setCaseId("123");
        redisData.setAccountNumber("0213143123-00001");
        redisData.setProcessingMTN("8136958775");
        redisData.setCartCreator("8136958775");
        URI url = URI.create("http://localhost/startBBPFlow");
        String bbpRequestVOString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"iccid\":\"89148000000835900342\",\"imei\":\"352898071702915\",\"isSmartphone\":true}";
        BBPRequestVO bbpRequestVO = mapper.readValue(bbpRequestVOString, BBPRequestVO.class);
        response = cartController.populateAddDeviceflow(uiResponse, redisData, "http://localhost/startBBPFlow","",bbpRequestVO);
        StepVerifier.create(Mono.just(response)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }
    
    @Test
    public void populateAddDeviceFlowTest2() throws IOException {
        String sampleResponseString = "{\"cartInfo\":{\"accountNumber\":\"0220561307-00002\",\"cartCreator\":\"8439410557\",\"globalId\":\"\",\"sessionId\":\"\",\"mtnFlow\":\"\",\"intendype\":\"BYOD\",\"processStep\":\"\",\"processAction\":\"addDevice\",\"clientAppName\":\"VZW-DOCOM-BBP\",\"numberShareCapable\":\"Y\",\"eNineAddressIndicator\":\"true\",\"deviceType\":\"PHONE\",\"bbpInent\":\"BYOD\",\"triggerPricingValidaion\":true},\"data\":{\"lines\":[{\"device\":{\"id\":\"MR1L2LL/A\",\"deviceId\":\"359433083362780\",\"conractTerm\":\"MONTH_O_MONTH\"},\"sim\":{\"id\":\"DFILL4FF-NFC-A\",\"iccid\":\"89148000000751553653\",\"isCusomerProvidedSIM\":true,\"eSIM\":\"89049032003008882300001955592066\",\"imei2\":\"\"},\"mtn\":\"\",\"ispuFlow\":false,\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"depletionLocationCode\":\"\",\"numbersharePairingMode\":\"STANDALONE\",\"isNewLine\":true,\"newLineOrAAL\":true}]}}";
        AddDeviceUIRequest response = mapper.readValue(sampleResponseString, AddDeviceUIRequest.class);
        String uiResponseString = "{\"uiMeta\": {\"timestamp\": 1606904076236,\"cxpCorrelationId\": \"2020-12-02T10:14:36.+0000:90be2abf-a4e2-4e0e-8fcb-4edcdee0a1e6:cxp-customerprofile-se-qa-ev6v-sit4w-nscxp-756b46467b-5z5q6:nssit4\"},\"uiData\": {\"deviceInfo\": { \"deviceId\": \"359433083362780\",\"mfgCode\": \"APL\",\"prodName\": \"\",\"prodType\": \"\",\"eqpModeCode\": \"4GE\",\"eqpMode\": \"4G\",\"ems\": \"N\",\"mms\": \"Y\",\"gps\": \"Y\",\"ptt\": \"N\",\"globalPhone\": \"O\",\"wap\": \"N/A\",\"bluetooth\": \"Y\",\"brew\": \"N\",\"trustedMode\": \"N\",\"csim\": \"\",\"ehrpd\": \"N\",\"smsevdo\": \"N\",\"deviceCategory\": \"\",\"visionProdId\": \"38940\",\"preferredSim\": \"\",\"backupAssistCapable\": \"N\",\"simClass4G\": \"NR\",\"virtualSimSku\": \"\",\"deviceNoPay\": \"N\", \"deviceLostStolen\": \"N\",\"deviceSdmLock\": \"\",\"deviceLock\": \"\",\"devicePibLock\": \"\",\"prepayEligibility\": \"00\",\"eligibilityDate\": \"\",\"outletId\": \"\",\"dacc\": \"sdk.tracker.daccs\",\"deviceType\": \"4GE\",\"provTechType\": \"LTE\",\"launchPackageSku\": \"4K3590ENV\",\"imSku\": \"MR1L2LL/A\",\"deviceCapabilityInd\": \"VD\",\"nfcCapable\": \"Y\",\"nfcCompatible\": \"Y\",\"pibDevice\": \"N\",\"connectedDeviceInd\": null,\"deviceFamilyType\": \"Connected\",\"buddyUpgrdEligInd\": \"N\",\"restrictToFamilyInd\": \"Y\",\"nonGeoDeviceInd\": \"\",\"m2MAllow\": \"M2MC\",\"hdVoice\": \"Y\",\"alkDevice\": \"HD\",\"shipDate\": \"20-DEC-2017\",\"cpo\": \"N\",\"lsClientId\": \"\",\"lsCustomerId\": \"\",\"lsBillAcctNumber\": \"\",\"v4B\": \"\",\"icEligInd\": \"\",\"icRemDays\": \"\",\"icRemSubsidyAmt\": \"\",\"e911AddrInd\": \"Y\",\"euiccCapable\": \"Y\",\"numberShareCapability\": \"Y\",\"wifiCalling\": \"Y\",\"vvm\": \"N\",\"imei1\": \"\",\"imei2\": \"\",\"osType\": \"WatchOS4\",\"postpaidRestrictStartDate\": \"\",\"dsEs12Fqdn\": \"\"},\"simInfo\": {\"simId\": \"89148000000751553653\",\"mfgCode\": \"GTO\",\"proName\": \"Gemalto 4FF NFC SIM - DF\",\"simGroup\": \"\",\"prodType\": \"4G_4FF_SIM\",\"simFormFactor\": \"\",\"simNoPay\": \"N\",\"simLostStolen\": \"N\",\"simLock\": \"\",\"simPibLock\": \"\",\"outletId\": \"\",\"sacc\": \"00722\",\"simType\": \"4GS\",\"iccidStatus\": \"AA\",\"numberLocation\": \"\",\"provTechType\": \"LTE\",\"launchPackageSku\": \"DFILL4FF-NFC-A\",\"imSku\": \"DFILL4FF-NFC-A\",\"nfcCapable\": \"Y\",\"nfcCompatible\": \"\",\"solderedSim\": \"\",\"simCapable\": \"DUAL_IMSI\",\"selfActivationCapableInd\": null,\"lsClientId\": \"\",\"lsCustomerId\": \"\",\"lsBillAcctNumber\": \"\",\"saleRetailer\": \"\",\"simSkuType\": \"T\",\"personalizedStatus\": \"\",\"personalizedTimeStamp\": \"\"},\"deviceSimCompatible\": \"Y\",\"deviceSimM2MPair\": \"N\",\"deviceESimCompatible\": \"\",\"deviceEsimM2MPair\": \"Y\",\"esimInfo\": {\"mfgCode\": \"\",\"launchPackageSku\": \"\",\"prodName\": \"\",\"preferredSoftSim\": \"SOFTNASIM-MP-D\",\"launchPackageSkuType\": \"\",\"pairedIccid\": \"\", \"eID\": \"8904903203008882300001955592066\"}}}";
        DeviceSimDetailsUIResponse uiResponse = mapper.readValue(uiResponseString, DeviceSimDetailsUIResponse.class);
        CartRedisData redisData=new CartRedisData();
        redisData.setCartId("69a66ef4d7e344dfb2db299209ea8333");
        redisData.setCaseId("123");
        redisData.setAccountNumber("0213143123-00001");
        redisData.setProcessingMTN("8136958775");
        redisData.setCartCreator("8136958775");
        URI url = URI.create("http://localhost/startBBPFlow");
        String bbpRequestVOString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"iccid\":\"89148000000835900342\",\"imei\":\"352898071702915\",\"isSmartphone\":true}";
        BBPRequestVO bbpRequestVO = mapper.readValue(bbpRequestVOString, BBPRequestVO.class);
        response = cartController.populateAddDeviceflow(uiResponse, redisData, "http://localhost/startBBPFlow","",bbpRequestVO);
        StepVerifier.create(Mono.just(response)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }
    
    @Test
    public void populateAddDeviceFlowTest3() throws IOException {
        String sampleResponseString = "{\"cartInfo\":{\"accountNumber\":\"0220561307-00002\",\"cartCreator\":\"8439410557\",\"globalId\":\"\",\"sessionId\":\"\",\"mtnFlow\":\"\",\"intendype\":\"BYOD\",\"processStep\":\"\",\"processAction\":\"addDevice\",\"clientAppName\":\"VZW-DOCOM-BBP\",\"numberShareCapable\":\"Y\",\"eNineAddressIndicator\":\"true\",\"deviceType\":\"PHONE\",\"bbpInent\":\"BYOD\",\"triggerPricingValidaion\":true},\"data\":{\"lines\":[{\"device\":{\"id\":\"MR1L2LL/A\",\"deviceId\":\"359433083362780\",\"conractTerm\":\"MONTH_O_MONTH\"},\"sim\":{\"id\":\"DFILL4FF-NFC-A\",\"iccid\":\"89148000000751553653\",\"isCusomerProvidedSIM\":true,\"eSIM\":\"89049032003008882300001955592066\",\"imei2\":\"\"},\"mtn\":\"\",\"ispuFlow\":false,\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"depletionLocationCode\":\"\",\"numbersharePairingMode\":\"STANDALONE\",\"isNewLine\":true,\"newLineOrAAL\":true}]}}";
        AddDeviceUIRequest response = mapper.readValue(sampleResponseString, AddDeviceUIRequest.class);
        String uiResponseString = "{\"uiMeta\": {\"timestamp\": 1606904076236,\"cxpCorrelationId\": \"2020-12-02T10:14:36.+0000:90be2abf-a4e2-4e0e-8fcb-4edcdee0a1e6:cxp-customerprofile-se-qa-ev6v-sit4w-nscxp-756b46467b-5z5q6:nssit4\"},\"uiData\": {\"deviceInfo\": { \"deviceId\": \"359433083362780\",\"mfgCode\": \"APL\",\"prodName\": \"\",\"prodType\": \"\",\"eqpModeCode\": \"4GE\",\"eqpMode\": \"4G\",\"ems\": \"N\",\"mms\": \"Y\",\"gps\": \"Y\",\"ptt\": \"N\",\"globalPhone\": \"O\",\"wap\": \"N/A\",\"bluetooth\": \"Y\",\"brew\": \"N\",\"trustedMode\": \"N\",\"csim\": \"\",\"ehrpd\": \"N\",\"smsevdo\": \"N\",\"deviceCategory\": \"DEVTAB\",\"visionProdId\": \"38940\",\"preferredSim\": \"\",\"backupAssistCapable\": \"N\",\"simClass4G\": \"NR\",\"virtualSimSku\": \"\",\"deviceNoPay\": \"N\", \"deviceLostStolen\": \"N\",\"deviceSdmLock\": \"\",\"deviceLock\": \"\",\"devicePibLock\": \"\",\"prepayEligibility\": \"00\",\"eligibilityDate\": \"\",\"outletId\": \"\",\"dacc\": \"sdk.tracker.daccs\",\"deviceType\": \"4GE\",\"provTechType\": \"LTE\",\"launchPackageSku\":null,\"imSku\": \"MR1L2LL/A\",\"deviceCapabilityInd\": \"VD\",\"nfcCapable\": \"Y\",\"nfcCompatible\": \"Y\",\"pibDevice\": \"N\",\"connectedDeviceInd\": null,\"deviceFamilyType\": \"Connected\",\"buddyUpgrdEligInd\": \"N\",\"restrictToFamilyInd\": \"Y\",\"nonGeoDeviceInd\": \"\",\"m2MAllow\": \"M2MC\",\"hdVoice\": \"Y\",\"alkDevice\": \"HD\",\"shipDate\": \"20-DEC-2017\",\"cpo\": \"N\",\"lsClientId\": \"\",\"lsCustomerId\": \"\",\"lsBillAcctNumber\": \"\",\"v4B\": \"\",\"icEligInd\": \"\",\"icRemDays\": \"\",\"icRemSubsidyAmt\": \"\",\"e911AddrInd\": \"Y\",\"euiccCapable\": \"Y\",\"numberShareCapability\": \"Y\",\"wifiCalling\": \"Y\",\"vvm\": \"N\",\"imei1\": \"\",\"imei2\": \"\",\"osType\": \"WatchOS4\",\"postpaidRestrictStartDate\": \"\",\"dsEs12Fqdn\": \"\"},\"simInfo\": {\"simId\": \"89148000000751553653\",\"mfgCode\": \"GTO\",\"proName\": \"Gemalto 4FF NFC SIM - DF\",\"simGroup\": \"\",\"prodType\": \"4G_4FF_SIM\",\"simFormFactor\": \"\",\"simNoPay\": \"N\",\"simLostStolen\": \"N\",\"simLock\": \"\",\"simPibLock\": \"\",\"outletId\": \"\",\"sacc\": \"00722\",\"simType\": \"4GS\",\"iccidStatus\": \"AA\",\"numberLocation\": \"\",\"provTechType\": \"LTE\",\"launchPackageSku\": \"DFILL4FF-NFC-A\",\"imSku\": \"DFILL4FF-NFC-A\",\"nfcCapable\": \"Y\",\"nfcCompatible\": \"\",\"solderedSim\": \"\",\"simCapable\": \"DUAL_IMSI\",\"selfActivationCapableInd\": null,\"lsClientId\": \"\",\"lsCustomerId\": \"\",\"lsBillAcctNumber\": \"\",\"saleRetailer\": \"\",\"simSkuType\": \"T\",\"personalizedStatus\": \"\",\"personalizedTimeStamp\": \"\"},\"deviceSimCompatible\": \"Y\",\"deviceSimM2MPair\": \"N\",\"deviceESimCompatible\": \"\",\"deviceEsimM2MPair\": \"Y\",\"esimInfo\": {\"mfgCode\": \"\",\"launchPackageSku\": \"\",\"prodName\": \"\",\"preferredSoftSim\": \"SOFTNASIM-MP-D\",\"launchPackageSkuType\": \"\",\"pairedIccid\": \"\", \"eID\": \"8904903203008882300001955592066\"}}}";
        DeviceSimDetailsUIResponse uiResponse = mapper.readValue(uiResponseString, DeviceSimDetailsUIResponse.class);
        CartRedisData redisData=new CartRedisData();
        redisData.setCartId("69a66ef4d7e344dfb2db299209ea8333");
        redisData.setCaseId("123");
        redisData.setAccountNumber("0213143123-00001");
        redisData.setProcessingMTN("8136958775");
        redisData.setCartCreator("8136958775");
        URI url = URI.create("http://localhost/startBBPFlow");
        String bbpRequestVOString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"iccid\":\"89148000000835900342\",\"imei\":\"352898071702915\",\"isSmartphone\":true}";
        BBPRequestVO bbpRequestVO = mapper.readValue(bbpRequestVOString, BBPRequestVO.class);
        response = cartController.populateAddDeviceflow(uiResponse, redisData, "http://localhost/startBBPFlow","",bbpRequestVO);
        StepVerifier.create(Mono.just(response)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }
    
    @Test
    public void populateAddDeviceFlowTest4() throws IOException {
        String sampleResponseString = "{\"cartInfo\":{\"accountNumber\":\"0220561307-00002\",\"cartCreator\":\"8439410557\",\"globalId\":\"\",\"sessionId\":\"\",\"mtnFlow\":\"\",\"intendype\":\"BYOD\",\"processStep\":\"\",\"processAction\":\"addDevice\",\"clientAppName\":\"VZW-DOCOM-BBP\",\"numberShareCapable\":\"Y\",\"eNineAddressIndicator\":\"true\",\"deviceType\":\"PHONE\",\"bbpInent\":\"BYOD\",\"triggerPricingValidaion\":true},\"data\":{\"lines\":[{\"device\":{\"id\":\"MR1L2LL/A\",\"deviceId\":\"359433083362780\",\"conractTerm\":\"MONTH_O_MONTH\"},\"sim\":{\"id\":\"DFILL4FF-NFC-A\",\"iccid\":\"89148000000751553653\",\"isCusomerProvidedSIM\":true,\"eSIM\":\"89049032003008882300001955592066\",\"imei2\":\"\"},\"mtn\":\"\",\"ispuFlow\":false,\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"depletionLocationCode\":\"\",\"numbersharePairingMode\":\"STANDALONE\",\"isNewLine\":true,\"newLineOrAAL\":true}]}}";
        AddDeviceUIRequest response = mapper.readValue(sampleResponseString, AddDeviceUIRequest.class);
        String uiResponseString = "{\"uiMeta\": {\"timestamp\": 1606904076236,\"cxpCorrelationId\": \"2020-12-02T10:14:36.+0000:90be2abf-a4e2-4e0e-8fcb-4edcdee0a1e6:cxp-customerprofile-se-qa-ev6v-sit4w-nscxp-756b46467b-5z5q6:nssit4\"},\"uiData\": {\"deviceInfo\": { \"esimFlow\":true,\"deviceId\": \"359433083362780\",\"mfgCode\": \"APL\",\"prodName\": \"\",\"prodType\": \"\",\"eqpModeCode\": \"4GE\",\"eqpMode\": \"4G\",\"ems\": \"N\",\"mms\": \"Y\",\"gps\": \"Y\",\"ptt\": \"N\",\"globalPhone\": \"O\",\"wap\": \"N/A\",\"bluetooth\": \"Y\",\"brew\": \"N\",\"trustedMode\": \"N\",\"csim\": \"\",\"ehrpd\": \"N\",\"smsevdo\": \"N\",\"deviceCategory\": \"Tablet\",\"visionProdId\": \"38940\",\"preferredSim\": \"\",\"backupAssistCapable\": \"N\",\"simClass4G\": \"NR\",\"virtualSimSku\": \"\",\"deviceNoPay\": \"N\", \"deviceLostStolen\": \"N\",\"deviceSdmLock\": \"\",\"deviceLock\": \"\",\"devicePibLock\": \"\",\"prepayEligibility\": \"00\",\"eligibilityDate\": \"\",\"outletId\": \"\",\"dacc\":null,\"deviceType\": \"4GE\",\"provTechType\": \"LTE\",\"launchPackageSku\":null,\"imSku\":null,\"deviceCapabilityInd\": \"VD\",\"nfcCapable\": \"Y\",\"nfcCompatible\": \"Y\",\"pibDevice\": \"N\",\"connectedDeviceInd\": null,\"deviceFamilyType\": \"Connected\",\"buddyUpgrdEligInd\": \"N\",\"restrictToFamilyInd\": \"Y\",\"nonGeoDeviceInd\": \"\",\"m2MAllow\": \"M2MC\",\"hdVoice\": \"Y\",\"alkDevice\": \"HD\",\"shipDate\": \"20-DEC-2017\",\"cpo\": \"N\",\"lsClientId\": \"\",\"lsCustomerId\": \"\",\"lsBillAcctNumber\": \"\",\"v4B\": \"\",\"icEligInd\": \"\",\"icRemDays\": \"\",\"icRemSubsidyAmt\": \"\",\"e911AddrInd\": \"Y\",\"euiccCapable\": \"Y\",\"numberShareCapability\": \"Y\",\"wifiCalling\": \"Y\",\"vvm\": \"N\",\"imei1\": \"\",\"imei2\": \"\",\"osType\": \"WatchOS4\",\"postpaidRestrictStartDate\": \"\",\"dsEs12Fqdn\": \"\"},\"simInfo\": {\"simId\": \"89148000000751553653\",\"mfgCode\": \"GTO\",\"proName\": \"Gemalto 4FF NFC SIM - DF\",\"simGroup\": \"\",\"prodType\": \"4G_4FF_SIM\",\"simFormFactor\": \"\",\"simNoPay\": \"N\",\"simLostStolen\": \"N\",\"simLock\": \"\",\"simPibLock\": \"\",\"outletId\": \"\",\"sacc\": \"00722\",\"simType\": \"4GS\",\"iccidStatus\": \"AA\",\"numberLocation\": \"\",\"provTechType\": \"LTE\",\"launchPackageSku\": \"DFILL4FF-NFC-A\",\"imSku\": \"DFILL4FF-NFC-A\",\"nfcCapable\": \"Y\",\"nfcCompatible\": \"\",\"solderedSim\": \"\",\"simCapable\": \"DUAL_IMSI\",\"selfActivationCapableInd\": null,\"lsClientId\": \"\",\"lsCustomerId\": \"\",\"lsBillAcctNumber\": \"\",\"saleRetailer\": \"\",\"simSkuType\": \"T\",\"personalizedStatus\": \"\",\"personalizedTimeStamp\": \"\"},\"deviceSimCompatible\": \"Y\",\"deviceSimM2MPair\": \"N\",\"deviceESimCompatible\": \"\",\"deviceEsimM2MPair\": \"Y\",\"esimInfo\": {\"mfgCode\": \"\",\"launchPackageSku\": \"\",\"prodName\": \"\",\"preferredSoftSim\": \"SOFTNASIM-MP-D\",\"launchPackageSkuType\": \"\",\"pairedIccid\": \"\", \"eID\": \"8904903203008882300001955592066\"}}}";
        DeviceSimDetailsUIResponse uiResponse = mapper.readValue(uiResponseString, DeviceSimDetailsUIResponse.class);
        CartRedisData redisData=new CartRedisData();
        redisData.setCartId("69a66ef4d7e344dfb2db299209ea8333");
        redisData.setCaseId("123");
        redisData.setAccountNumber("0213143123-00001");
        redisData.setProcessingMTN("8136958775");
        redisData.setCartCreator("8136958775");
        URI url = URI.create("http://localhost/startBBPFlow");
        String bbpRequestVOString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"iccid\":\"89148000000835900342\",\"imei\":\"352898071702915\",\"isSmartphone\":true}";
        BBPRequestVO bbpRequestVO = mapper.readValue(bbpRequestVOString, BBPRequestVO.class);
        response = cartController.populateAddDeviceflow(uiResponse, redisData, "http://localhost/startBBPFlow","",bbpRequestVO);
        StepVerifier.create(Mono.just(response)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }
    
    @Test
    public void populateAddDeviceFlowTest5() throws IOException {
        String sampleResponseString = "{\"cartInfo\":{\"accountNumber\":\"0220561307-00002\",\"cartCreator\":\"8439410557\",\"globalId\":\"\",\"sessionId\":\"\",\"mtnFlow\":\"\",\"intendype\":\"BYOD\",\"processStep\":\"\",\"processAction\":\"addDevice\",\"clientAppName\":\"VZW-DOCOM-BBP\",\"numberShareCapable\":\"Y\",\"eNineAddressIndicator\":\"true\",\"deviceType\":\"PHONE\",\"bbpInent\":\"BYOD\",\"triggerPricingValidaion\":true},\"data\":{\"lines\":[{\"device\":{\"id\":\"MR1L2LL/A\",\"deviceId\":\"359433083362780\",\"conractTerm\":\"MONTH_O_MONTH\"},\"sim\":{\"id\":\"DFILL4FF-NFC-A\",\"iccid\":\"89148000000751553653\",\"isCusomerProvidedSIM\":true,\"eSIM\":\"89049032003008882300001955592066\",\"imei2\":\"\"},\"mtn\":\"\",\"ispuFlow\":false,\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"depletionLocationCode\":\"\",\"numbersharePairingMode\":\"STANDALONE\",\"isNewLine\":true,\"newLineOrAAL\":true}]}}";
        AddDeviceUIRequest response = mapper.readValue(sampleResponseString, AddDeviceUIRequest.class);
        String uiResponseString = "{\"uiMeta\": {\"timestamp\": 1606904076236,\"cxpCorrelationId\": \"2020-12-02T10:14:36.+0000:90be2abf-a4e2-4e0e-8fcb-4edcdee0a1e6:cxp-customerprofile-se-qa-ev6v-sit4w-nscxp-756b46467b-5z5q6:nssit4\"},\"uiData\": {\"esimFlow\":true,\"deviceInfo\": { \"deviceId\": \"359433083362780\",\"mfgCode\": \"APL\",\"prodName\": \"APPLE WATCH S3 42 SPBLK MIL\",\"prodType\": \"4G_LOCATOR\",\"eqpModeCode\": \"4GE\",\"eqpMode\": \"4G\",\"ems\": \"N\",\"mms\": \"Y\",\"gps\": \"Y\",\"ptt\": \"N\",\"globalPhone\": \"O\",\"wap\": \"N/A\",\"bluetooth\": \"Y\",\"brew\": \"N\",\"trustedMode\": \"N\",\"csim\": \"\",\"ehrpd\": \"N\",\"smsevdo\": \"N\",\"deviceCategory\": \"\",\"visionProdId\": \"38940\",\"preferredSim\": \"\",\"backupAssistCapable\": \"N\",\"simClass4G\": \"NR\",\"virtualSimSku\": \"\",\"deviceNoPay\": \"N\", \"deviceLostStolen\": \"N\",\"deviceSdmLock\": \"\",\"deviceLock\": \"\",\"devicePibLock\": \"\",\"prepayEligibility\": \"00\",\"eligibilityDate\": \"\",\"outletId\": \"\",\"dacc\": \"sdk.tracker.daccs\",\"deviceType\": \"4GE\",\"provTechType\": \"LTE\",\"launchPackageSku\": \"\",\"imSku\": \"MR1L2LL/A\",\"deviceCapabilityInd\": \"VD\",\"nfcCapable\": \"Y\",\"nfcCompatible\": \"Y\",\"pibDevice\": \"N\",\"connectedDeviceInd\": null,\"deviceFamilyType\": \"Connected\",\"buddyUpgrdEligInd\": \"N\",\"restrictToFamilyInd\": \"Y\",\"nonGeoDeviceInd\": \"\",\"m2MAllow\": \"M2MC\",\"hdVoice\": \"Y\",\"alkDevice\": \"HD\",\"shipDate\": \"20-DEC-2017\",\"cpo\": \"N\",\"lsClientId\": \"\",\"lsCustomerId\": \"\",\"lsBillAcctNumber\": \"\",\"v4B\": \"\",\"icEligInd\": \"\",\"icRemDays\": \"\",\"icRemSubsidyAmt\": \"\",\"e911AddrInd\": \"Y\",\"euiccCapable\": \"Y\",\"numberShareCapability\": \"Y\",\"wifiCalling\": \"Y\",\"vvm\": \"N\",\"imei1\": \"\",\"imei2\": \"\",\"osType\": \"WatchOS4\",\"postpaidRestrictStartDate\": \"\",\"dsEs12Fqdn\": \"\"},\"simInfo\": {\"simId\": \"89148000000751553653\",\"mfgCode\": \"GTO\",\"proName\": \"Gemalto 4FF NFC SIM - DF\",\"simGroup\": \"\",\"prodType\": \"4G_4FF_SIM\",\"simFormFactor\": \"\",\"simNoPay\": \"N\",\"simLostStolen\": \"N\",\"simLock\": \"\",\"simPibLock\": \"\",\"outletId\": \"\",\"sacc\": \"00722\",\"simType\": \"4GS\",\"iccidStatus\": \"AA\",\"numberLocation\": \"\",\"provTechType\": \"LTE\",\"launchPackageSku\": \"DFILL4FF-NFC-A\",\"imSku\": \"DFILL4FF-NFC-A\",\"nfcCapable\": \"Y\",\"nfcCompatible\": \"\",\"solderedSim\": \"\",\"simCapable\": \"DUAL_IMSI\",\"selfActivationCapableInd\": null,\"lsClientId\": \"\",\"lsCustomerId\": \"\",\"lsBillAcctNumber\": \"\",\"saleRetailer\": \"\",\"simSkuType\": \"T\",\"personalizedStatus\": \"\",\"personalizedTimeStamp\": \"\"},\"deviceSimCompatible\": \"Y\",\"deviceSimM2MPair\": \"N\",\"deviceESimCompatible\": \"\",\"deviceEsimM2MPair\": \"Y\",\"esimInfo\": {\"mfgCode\": \"\",\"launchPackageSku\": \"\",\"prodName\": \"\",\"preferredSoftSim\": \"SOFTNASIM-MP-D\",\"launchPackageSkuType\": \"\",\"pairedIccid\": \"\", \"eID\": \"8904903203008882300001955592066\"}}}";
        DeviceSimDetailsUIResponse uiResponse = mapper.readValue(uiResponseString, DeviceSimDetailsUIResponse.class);
        CartRedisData redisData=new CartRedisData();
        redisData.setCartId("69a66ef4d7e344dfb2db299209ea8333");
        redisData.setCaseId("123");
        redisData.setAccountNumber("0213143123-00001");
        redisData.setProcessingMTN("8136958775");
        redisData.setCartCreator("8136958775");
        URI url = URI.create("http://localhost/startBBPFlow");
        String bbpRequestVOString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"iccid\":\"89148000000835900342\",\"imei\":\"352898071702915\",\"isSmartphone\":true}";
        BBPRequestVO bbpRequestVO = mapper.readValue(bbpRequestVOString, BBPRequestVO.class);
        response = cartController.populateAddDeviceflow(uiResponse, redisData, "http://localhost/startBBPFlow","",bbpRequestVO);
        StepVerifier.create(Mono.just(response)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }
    
    @Test
    public void populateAddDeviceFlowTest6() throws IOException {
        String sampleResponseString = "{\"cartInfo\":{\"accountNumber\":\"0220561307-00002\",\"cartCreator\":\"8439410557\",\"globalId\":\"\",\"sessionId\":\"\",\"mtnFlow\":\"\",\"intendype\":\"BYOD\",\"processStep\":\"\",\"processAction\":\"addDevice\",\"clientAppName\":\"VZW-DOCOM-BBP\",\"numberShareCapable\":\"Y\",\"eNineAddressIndicator\":\"true\",\"deviceType\":\"PHONE\",\"bbpInent\":\"BYOD\",\"triggerPricingValidaion\":true},\"data\":{\"lines\":[{\"device\":{\"id\":\"MR1L2LL/A\",\"deviceId\":\"359433083362780\",\"conractTerm\":\"MONTH_O_MONTH\"},\"sim\":{\"id\":\"DFILL4FF-NFC-A\",\"iccid\":\"89148000000751553653\",\"isCusomerProvidedSIM\":true,\"eSIM\":\"89049032003008882300001955592066\",\"imei2\":\"\"},\"mtn\":\"\",\"ispuFlow\":false,\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"depletionLocationCode\":\"\",\"numbersharePairingMode\":\"STANDALONE\",\"isNewLine\":true,\"newLineOrAAL\":true}]}}";
        AddDeviceUIRequest response = mapper.readValue(sampleResponseString, AddDeviceUIRequest.class);
        String uiResponseString = "{\"uiMeta\": {\"timestamp\": 1606904076236,\"cxpCorrelationId\": \"2020-12-02T10:14:36.+0000:90be2abf-a4e2-4e0e-8fcb-4edcdee0a1e6:cxp-customerprofile-se-qa-ev6v-sit4w-nscxp-756b46467b-5z5q6:nssit4\"},\"uiData\": {\"esimFlow\":null,\"deviceInfo\": { \"deviceId\": \"359433083362780\",\"mfgCode\": \"APL\",\"prodName\": \"APPLE WATCH S3 42 SPBLK MIL\",\"prodType\": \"4G_LOCATOR\",\"eqpModeCode\": \"4GE\",\"eqpMode\": \"4G\",\"ems\": \"N\",\"mms\": \"Y\",\"gps\": \"Y\",\"ptt\": \"N\",\"globalPhone\": \"O\",\"wap\": \"N/A\",\"bluetooth\": \"Y\",\"brew\": \"N\",\"trustedMode\": \"N\",\"csim\": \"\",\"ehrpd\": \"N\",\"smsevdo\": \"N\",\"deviceCategory\": \"\",\"visionProdId\": \"38940\",\"preferredSim\": \"\",\"backupAssistCapable\": \"N\",\"simClass4G\": \"NR\",\"virtualSimSku\": \"\",\"deviceNoPay\": \"N\", \"deviceLostStolen\": \"N\",\"deviceSdmLock\": \"\",\"deviceLock\": \"\",\"devicePibLock\": \"\",\"prepayEligibility\": \"00\",\"eligibilityDate\": \"\",\"outletId\": \"\",\"dacc\": \"sdk.tracker.daccs\",\"deviceType\": \"4GE\",\"provTechType\": \"LTE\",\"launchPackageSku\": \"\",\"imSku\": \"MR1L2LL/A\",\"deviceCapabilityInd\": \"VD\",\"nfcCapable\": \"Y\",\"nfcCompatible\": \"Y\",\"pibDevice\": \"N\",\"connectedDeviceInd\": null,\"deviceFamilyType\": \"Connected\",\"buddyUpgrdEligInd\": \"N\",\"restrictToFamilyInd\": \"Y\",\"nonGeoDeviceInd\": \"\",\"m2MAllow\": \"M2MC\",\"hdVoice\": \"Y\",\"alkDevice\": \"HD\",\"shipDate\": \"20-DEC-2017\",\"cpo\": \"N\",\"lsClientId\": \"\",\"lsCustomerId\": \"\",\"lsBillAcctNumber\": \"\",\"v4B\": \"\",\"icEligInd\": \"\",\"icRemDays\": \"\",\"icRemSubsidyAmt\": \"\",\"e911AddrInd\": \"Y\",\"euiccCapable\": \"Y\",\"numberShareCapability\": \"Y\",\"wifiCalling\": \"Y\",\"vvm\": \"N\",\"imei1\": \"\",\"imei2\": \"\",\"osType\": \"WatchOS4\",\"postpaidRestrictStartDate\": \"\",\"dsEs12Fqdn\": \"\"},\"simInfo\": {\"simId\": \"89148000000751553653\",\"mfgCode\": \"GTO\",\"proName\": \"Gemalto 4FF NFC SIM - DF\",\"simGroup\": \"\",\"prodType\": \"4G_4FF_SIM\",\"simFormFactor\": \"\",\"simNoPay\": \"N\",\"simLostStolen\": \"N\",\"simLock\": \"\",\"simPibLock\": \"\",\"outletId\": \"\",\"sacc\": \"00722\",\"simType\": \"4GS\",\"iccidStatus\": \"AA\",\"numberLocation\": \"\",\"provTechType\": \"LTE\",\"launchPackageSku\": \"DFILL4FF-NFC-A\",\"imSku\": \"DFILL4FF-NFC-A\",\"nfcCapable\": \"Y\",\"nfcCompatible\": \"\",\"solderedSim\": \"\",\"simCapable\": \"DUAL_IMSI\",\"selfActivationCapableInd\": null,\"lsClientId\": \"\",\"lsCustomerId\": \"\",\"lsBillAcctNumber\": \"\",\"saleRetailer\": \"\",\"simSkuType\": \"T\",\"personalizedStatus\": \"\",\"personalizedTimeStamp\": \"\"},\"deviceSimCompatible\": \"Y\",\"deviceSimM2MPair\": \"N\",\"deviceESimCompatible\": \"\",\"deviceEsimM2MPair\": \"Y\",\"esimInfo\": {\"mfgCode\": \"\",\"launchPackageSku\": \"\",\"prodName\": \"\",\"preferredSoftSim\": \"SOFTNASIM-MP-D\",\"launchPackageSkuType\": \"\",\"pairedIccid\": \"\", \"eID\": \"8904903203008882300001955592066\"}}}";
        DeviceSimDetailsUIResponse uiResponse = mapper.readValue(uiResponseString, DeviceSimDetailsUIResponse.class);
        CartRedisData redisData=new CartRedisData();
        redisData.setCartId("69a66ef4d7e344dfb2db299209ea8333");
        redisData.setCaseId("123");
        redisData.setAccountNumber("0213143123-00001");
        redisData.setProcessingMTN("8136958775");
        redisData.setCartCreator("8136958775");
        URI url = URI.create("http://localhost/startBBPFlow");
        String bbpRequestVOString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"iccid\":\"89148000000835900342\",\"imei\":\"352898071702915\",\"isSmartphone\":true}";
        BBPRequestVO bbpRequestVO = mapper.readValue(bbpRequestVOString, BBPRequestVO.class);
        response = cartController.populateAddDeviceflow(uiResponse, redisData, "http://localhost/startBBPFlow","",bbpRequestVO);
        StepVerifier.create(Mono.just(response)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }
    
    @Test
    public void populateAddDeviceFlowTest7() throws IOException {
        String sampleResponseString = "{\"cartInfo\":{\"accountNumber\":\"0220561307-00002\",\"cartCreator\":\"8439410557\",\"globalId\":\"\",\"sessionId\":\"\",\"mtnFlow\":\"\",\"intendype\":\"BYOD\",\"processStep\":\"\",\"processAction\":\"addDevice\",\"clientAppName\":\"VZW-DOCOM-BBP\",\"numberShareCapable\":\"Y\",\"eNineAddressIndicator\":\"true\",\"deviceType\":\"PHONE\",\"bbpInent\":\"BYOD\",\"triggerPricingValidaion\":true},\"data\":{\"lines\":[{\"device\":{\"id\":\"MR1L2LL/A\",\"deviceId\":\"359433083362780\",\"conractTerm\":\"MONTH_O_MONTH\"},\"sim\":{\"id\":\"DFILL4FF-NFC-A\",\"iccid\":\"89148000000751553653\",\"isCusomerProvidedSIM\":true,\"eSIM\":\"89049032003008882300001955592066\",\"imei2\":\"\"},\"mtn\":\"\",\"ispuFlow\":false,\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"depletionLocationCode\":\"\",\"numbersharePairingMode\":\"STANDALONE\",\"isNewLine\":true,\"newLineOrAAL\":true}]}}";
        AddDeviceUIRequest response = mapper.readValue(sampleResponseString, AddDeviceUIRequest.class);
        String uiResponseString = "{\"uiMeta\": {\"timestamp\": 1606904076236,\"cxpCorrelationId\": \"2020-12-02T10:14:36.+0000:90be2abf-a4e2-4e0e-8fcb-4edcdee0a1e6:cxp-customerprofile-se-qa-ev6v-sit4w-nscxp-756b46467b-5z5q6:nssit4\"},\"uiData\": {\"esimFlow\":false,\"deviceInfo\": { \"deviceId\": \"359433083362780\",\"mfgCode\": \"APL\",\"prodName\": \"APPLE WATCH S3 42 SPBLK MIL\",\"prodType\": \"4G_LOCATOR\",\"eqpModeCode\": \"4GE\",\"eqpMode\": \"4G\",\"ems\": \"N\",\"mms\": \"Y\",\"gps\": \"Y\",\"ptt\": \"N\",\"globalPhone\": \"O\",\"wap\": \"N/A\",\"bluetooth\": \"Y\",\"brew\": \"N\",\"trustedMode\": \"N\",\"csim\": \"\",\"ehrpd\": \"N\",\"smsevdo\": \"N\",\"deviceCategory\": \"\",\"visionProdId\": \"38940\",\"preferredSim\": \"\",\"backupAssistCapable\": \"N\",\"simClass4G\": \"NR\",\"virtualSimSku\": \"\",\"deviceNoPay\": \"N\", \"deviceLostStolen\": \"N\",\"deviceSdmLock\": \"\",\"deviceLock\": \"\",\"devicePibLock\": \"\",\"prepayEligibility\": \"00\",\"eligibilityDate\": \"\",\"outletId\": \"\",\"dacc\": \"sdk.tracker.daccs\",\"deviceType\": \"4GE\",\"provTechType\": \"LTE\",\"launchPackageSku\": \"\",\"imSku\": \"MR1L2LL/A\",\"deviceCapabilityInd\": \"VD\",\"nfcCapable\": \"Y\",\"nfcCompatible\": \"Y\",\"pibDevice\": \"N\",\"connectedDeviceInd\": null,\"deviceFamilyType\": \"Connected\",\"buddyUpgrdEligInd\": \"N\",\"restrictToFamilyInd\": \"Y\",\"nonGeoDeviceInd\": \"\",\"m2MAllow\": \"M2MC\",\"hdVoice\": \"Y\",\"alkDevice\": \"HD\",\"shipDate\": \"20-DEC-2017\",\"cpo\": \"N\",\"lsClientId\": \"\",\"lsCustomerId\": \"\",\"lsBillAcctNumber\": \"\",\"v4B\": \"\",\"icEligInd\": \"\",\"icRemDays\": \"\",\"icRemSubsidyAmt\": \"\",\"e911AddrInd\": \"Y\",\"euiccCapable\": \"Y\",\"numberShareCapability\": \"Y\",\"wifiCalling\": \"Y\",\"vvm\": \"N\",\"imei1\": \"\",\"imei2\": \"\",\"osType\": \"WatchOS4\",\"postpaidRestrictStartDate\": \"\",\"dsEs12Fqdn\": \"\"},\"simInfo\": {\"simId\": \"89148000000751553653\",\"mfgCode\": \"GTO\",\"proName\": \"Gemalto 4FF NFC SIM - DF\",\"simGroup\": \"\",\"prodType\": \"4G_4FF_SIM\",\"simFormFactor\": \"\",\"simNoPay\": \"N\",\"simLostStolen\": \"N\",\"simLock\": \"\",\"simPibLock\": \"\",\"outletId\": \"\",\"sacc\": \"00722\",\"simType\": \"4GS\",\"iccidStatus\": \"AA\",\"numberLocation\": \"\",\"provTechType\": \"LTE\",\"launchPackageSku\": \"DFILL4FF-NFC-A\",\"imSku\": \"DFILL4FF-NFC-A\",\"nfcCapable\": \"Y\",\"nfcCompatible\": \"\",\"solderedSim\": \"\",\"simCapable\": \"DUAL_IMSI\",\"selfActivationCapableInd\": null,\"lsClientId\": \"\",\"lsCustomerId\": \"\",\"lsBillAcctNumber\": \"\",\"saleRetailer\": \"\",\"simSkuType\": \"T\",\"personalizedStatus\": \"\",\"personalizedTimeStamp\": \"\"},\"deviceSimCompatible\": \"Y\",\"deviceSimM2MPair\": \"N\",\"deviceESimCompatible\": \"\",\"deviceEsimM2MPair\": \"Y\",\"esimInfo\": {\"mfgCode\": \"\",\"launchPackageSku\": \"\",\"prodName\": \"\",\"preferredSoftSim\": \"SOFTNASIM-MP-D\",\"launchPackageSkuType\": \"\",\"pairedIccid\": \"\", \"eID\": \"8904903203008882300001955592066\"}}}";
        DeviceSimDetailsUIResponse uiResponse = mapper.readValue(uiResponseString, DeviceSimDetailsUIResponse.class);
        CartRedisData redisData=new CartRedisData();
        redisData.setCartId("69a66ef4d7e344dfb2db299209ea8333");
        redisData.setCaseId("123");
        redisData.setAccountNumber("0213143123-00001");
        redisData.setProcessingMTN("8136958775");
        redisData.setCartCreator("8136958775");
        URI url = URI.create("http://localhost/startBBPFlow");
        String bbpRequestVOString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"iccid\":\"89148000000835900342\",\"imei\":\"352898071702915\",\"isSmartphone\":true}";
        BBPRequestVO bbpRequestVO = mapper.readValue(bbpRequestVOString, BBPRequestVO.class);
        response = cartController.populateAddDeviceflow(uiResponse, redisData, "http://localhost/startBBPFlow","",bbpRequestVO);
        StepVerifier.create(Mono.just(response)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }
    
    @Test
    public void populateAddDeviceFlowTest8() throws IOException {
        String sampleResponseString = "{\"cartInfo\":{\"accountNumber\":\"0220561307-00002\",\"cartCreator\":\"8439410557\",\"globalId\":\"\",\"sessionId\":\"\",\"mtnFlow\":\"\",\"intendype\":\"BYOD\",\"processStep\":\"\",\"processAction\":\"addDevice\",\"clientAppName\":\"VZW-DOCOM-BBP\",\"numberShareCapable\":\"Y\",\"eNineAddressIndicator\":\"true\",\"deviceType\":\"PHONE\",\"bbpInent\":\"BYOD\",\"triggerPricingValidaion\":true},\"data\":{\"lines\":[{\"device\":{\"id\":\"MR1L2LL/A\",\"deviceId\":\"359433083362780\",\"conractTerm\":\"MONTH_O_MONTH\"},\"sim\":{\"id\":\"DFILL4FF-NFC-A\",\"iccid\":\"89148000000751553653\",\"isCusomerProvidedSIM\":true,\"eSIM\":\"89049032003008882300001955592066\",\"imei2\":\"\"},\"mtn\":\"\",\"ispuFlow\":false,\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"depletionLocationCode\":\"\",\"numbersharePairingMode\":\"STANDALONE\",\"isNewLine\":true,\"newLineOrAAL\":true}]}}";
        AddDeviceUIRequest response = mapper.readValue(sampleResponseString, AddDeviceUIRequest.class);
        String uiResponseString = "{\"uiMeta\": {\"timestamp\": 1606904076236,\"cxpCorrelationId\": \"2020-12-02T10:14:36.+0000:90be2abf-a4e2-4e0e-8fcb-4edcdee0a1e6:cxp-customerprofile-se-qa-ev6v-sit4w-nscxp-756b46467b-5z5q6:nssit4\"},\"uiData\": {\"esimFlow\":false,\"deviceInfo\": { \"deviceId\": \"359433083362780\",\"mfgCode\": \"APL\",\"prodName\": \"APPLE WATCH S3 42 SPBLK MIL\",\"prodType\": \"4G_LOCATOR\",\"eqpModeCode\": \"4GE\",\"eqpMode\": \"4G\",\"ems\": \"N\",\"mms\": \"Y\",\"gps\": \"Y\",\"ptt\": \"N\",\"globalPhone\": \"O\",\"wap\": \"N/A\",\"bluetooth\": \"Y\",\"brew\": \"N\",\"trustedMode\": \"N\",\"csim\": \"\",\"ehrpd\": \"N\",\"smsevdo\": \"N\",\"deviceCategory\": \"\",\"visionProdId\": \"38940\",\"preferredSim\": \"\",\"backupAssistCapable\": \"N\",\"simClass4G\": \"NR\",\"virtualSimSku\": \"\",\"deviceNoPay\": \"N\", \"deviceLostStolen\": \"N\",\"deviceSdmLock\": \"\",\"deviceLock\": \"\",\"devicePibLock\": \"\",\"prepayEligibility\": \"00\",\"eligibilityDate\": \"\",\"outletId\": \"\",\"dacc\": \"sdk.tracker.daccs\",\"deviceType\": \"4GE\",\"provTechType\": \"LTE\",\"launchPackageSku\": \"\",\"imSku\": \"MR1L2LL/A\",\"deviceCapabilityInd\": \"VD\",\"nfcCapable\": \"Y\",\"nfcCompatible\": \"Y\",\"pibDevice\": \"N\",\"connectedDeviceInd\": null,\"deviceFamilyType\": \"Connected\",\"buddyUpgrdEligInd\": \"N\",\"restrictToFamilyInd\": \"Y\",\"nonGeoDeviceInd\": \"\",\"m2MAllow\": \"M2MC\",\"hdVoice\": \"Y\",\"alkDevice\": \"HD\",\"shipDate\": \"20-DEC-2017\",\"cpo\": \"N\",\"lsClientId\": \"\",\"lsCustomerId\": \"\",\"lsBillAcctNumber\": \"\",\"v4B\": \"\",\"icEligInd\": \"\",\"icRemDays\": \"\",\"icRemSubsidyAmt\": \"\",\"e911AddrInd\": \"Y\",\"euiccCapable\": \"Y\",\"numberShareCapability\": \"Y\",\"wifiCalling\": \"Y\",\"vvm\": \"N\",\"imei1\": \"\",\"imei2\": \"\",\"osType\": \"WatchOS4\",\"postpaidRestrictStartDate\": \"\",\"dsEs12Fqdn\": \"\"},\"simInfo\": null,\"deviceSimCompatible\": \"Y\",\"deviceSimM2MPair\": \"N\",\"deviceESimCompatible\": \"\",\"deviceEsimM2MPair\": \"Y\",\"esimInfo\": {\"mfgCode\": \"\",\"launchPackageSku\": \"\",\"prodName\": \"\",\"preferredSoftSim\": \"SOFTNASIM-MP-D\",\"launchPackageSkuType\": \"\",\"pairedIccid\": \"\", \"eID\": \"8904903203008882300001955592066\"}}}";
        DeviceSimDetailsUIResponse uiResponse = mapper.readValue(uiResponseString, DeviceSimDetailsUIResponse.class);
        CartRedisData redisData=new CartRedisData();
        redisData.setCartId("69a66ef4d7e344dfb2db299209ea8333");
        redisData.setCaseId("123");
        redisData.setAccountNumber("0213143123-00001");
        redisData.setProcessingMTN("8136958775");
        redisData.setCartCreator("8136958775");
        URI url = URI.create("http://localhost/startBBPFlow");
        String bbpRequestVOString = "{\"channelId\":\"VZW-DOTCOM\",\"iccid\":\"89148000000835900342\",\"imei\":\"352898071702915\",\"isSmartphone\":true}";
        BBPRequestVO bbpRequestVO = mapper.readValue(bbpRequestVOString, BBPRequestVO.class);
        response = cartController.populateAddDeviceflow(uiResponse, redisData, "http://localhost/startBBPFlow","",bbpRequestVO);
        StepVerifier.create(Mono.just(response)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }
    
    @Test(expected=NullPointerException.class)
    public void populateAddDeviceFlowTest9() throws IOException {
        String sampleResponseString = "{\"cartInfo\":{\"accountNumber\":\"0220561307-00002\",\"cartCreator\":\"8439410557\",\"globalId\":\"\",\"sessionId\":\"\",\"mtnFlow\":\"\",\"intendype\":\"BYOD\",\"processStep\":\"\",\"processAction\":\"addDevice\",\"clientAppName\":\"VZW-DOCOM-BBP\",\"numberShareCapable\":\"Y\",\"eNineAddressIndicator\":\"true\",\"deviceType\":\"PHONE\",\"bbpInent\":\"BYOD\",\"triggerPricingValidaion\":true},\"data\":{\"lines\":[{\"device\":{\"id\":\"MR1L2LL/A\",\"deviceId\":\"359433083362780\",\"conractTerm\":\"MONTH_O_MONTH\"},\"sim\":{\"id\":\"DFILL4FF-NFC-A\",\"iccid\":\"89148000000751553653\",\"isCusomerProvidedSIM\":true,\"eSIM\":\"89049032003008882300001955592066\",\"imei2\":\"\"},\"mtn\":\"\",\"ispuFlow\":false,\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"depletionLocationCode\":\"\",\"numbersharePairingMode\":\"STANDALONE\",\"isNewLine\":true,\"newLineOrAAL\":true}]}}";
        AddDeviceUIRequest response = mapper.readValue(sampleResponseString, AddDeviceUIRequest.class);
        String uiResponseString = "{\"uiMeta\": {\"timestamp\": 1606904076236,\"cxpCorrelationId\": \"2020-12-02T10:14:36.+0000:90be2abf-a4e2-4e0e-8fcb-4edcdee0a1e6:cxp-customerprofile-se-qa-ev6v-sit4w-nscxp-756b46467b-5z5q6:nssit4\"},\"uiData\": {\"esimFlow\":false,\"deviceInfo\": { \"deviceId\": \"359433083362780\",\"mfgCode\": \"APL\",\"prodName\": \"APPLE WATCH S3 42 SPBLK MIL\",\"prodType\": \"4G_LOCATOR\",\"eqpModeCode\": \"4GE\",\"eqpMode\": \"4G\",\"ems\": \"N\",\"mms\": \"Y\",\"gps\": \"Y\",\"ptt\": \"N\",\"globalPhone\": \"O\",\"wap\": \"N/A\",\"bluetooth\": \"Y\",\"brew\": \"N\",\"trustedMode\": \"N\",\"csim\": \"\",\"ehrpd\": \"N\",\"smsevdo\": \"N\",\"deviceCategory\": \"\",\"visionProdId\": \"38940\",\"preferredSim\": \"\",\"backupAssistCapable\": \"N\",\"simClass4G\": \"NR\",\"virtualSimSku\": \"\",\"deviceNoPay\": \"N\", \"deviceLostStolen\": \"N\",\"deviceSdmLock\": \"\",\"deviceLock\": \"\",\"devicePibLock\": \"\",\"prepayEligibility\": \"00\",\"eligibilityDate\": \"\",\"outletId\": \"\",\"dacc\": \"sdk.tracker.daccs\",\"deviceType\": \"4GE\",\"provTechType\": \"LTE\",\"launchPackageSku\": \"\",\"imSku\": \"MR1L2LL/A\",\"deviceCapabilityInd\": \"VD\",\"nfcCapable\": \"Y\",\"nfcCompatible\": \"Y\",\"pibDevice\": \"N\",\"connectedDeviceInd\": null,\"deviceFamilyType\": \"Connected\",\"buddyUpgrdEligInd\": \"N\",\"restrictToFamilyInd\": \"Y\",\"nonGeoDeviceInd\": \"\",\"m2MAllow\": \"M2MC\",\"hdVoice\": \"Y\",\"alkDevice\": \"HD\",\"shipDate\": \"20-DEC-2017\",\"cpo\": \"N\",\"lsClientId\": \"\",\"lsCustomerId\": \"\",\"lsBillAcctNumber\": \"\",\"v4B\": \"\",\"icEligInd\": \"\",\"icRemDays\": \"\",\"icRemSubsidyAmt\": \"\",\"e911AddrInd\": \"Y\",\"euiccCapable\": \"Y\",\"numberShareCapability\": \"Y\",\"wifiCalling\": \"Y\",\"vvm\": \"N\",\"imei1\": \"\",\"imei2\": \"\",\"osType\": \"WatchOS4\",\"postpaidRestrictStartDate\": \"\",\"dsEs12Fqdn\": \"\"},\"simInfo\": null,\"deviceSimCompatible\": \"Y\",\"deviceSimM2MPair\": \"N\",\"deviceESimCompatible\": \"\",\"deviceEsimM2MPair\": \"Y\",\"esimInfo\": {\"mfgCode\": \"\",\"launchPackageSku\": \"\",\"prodName\": \"\",\"preferredSoftSim\": \"SOFTNASIM-MP-D\",\"launchPackageSkuType\": \"\",\"pairedIccid\": \"\", \"eID\": \"8904903203008882300001955592066\"}}}";
        DeviceSimDetailsUIResponse uiResponse = mapper.readValue(uiResponseString, DeviceSimDetailsUIResponse.class);
        CartRedisData redisData=new CartRedisData();
        redisData.setCartId("69a66ef4d7e344dfb2db299209ea8333");
        redisData.setCaseId("123");
        redisData.setAccountNumber("0213143123-00001");
        redisData.setProcessingMTN("8136958775");
        redisData.setCartCreator("8136958775");
        URI url = URI.create("http://localhost/startBBPFlow");
        String bbpRequestVOString = "{\"channelId\":\"VZW-DOTCOM\",\"iccid\":\"89148000000835900342\",\"imei\":\"352898071702915\",\"isSmartphone\":true}";
        BBPRequestVO bbpRequestVO = mapper.readValue(bbpRequestVOString, BBPRequestVO.class);
        response = cartController.populateAddDeviceflow(uiResponse, null, "http://localhost/startBBPFlow","",bbpRequestVO);
		StepVerifier.create(Mono.just(response)).assertNext(resp -> Assert.assertNull(resp)).expectComplete().verify();
	}

	@Test
	public void populateAddDeviceFlowTest10() throws IOException {
		String sampleResponseString = "{\"cartInfo\":{\"accountNumber\":\"0220561307-00002\",\"cartCreator\":\"8439410557\",\"globalId\":\"\",\"sessionId\":\"\",\"mtnFlow\":\"\",\"intendype\":\"BYOD\",\"processStep\":\"\",\"processAction\":\"addDevice\",\"clientAppName\":\"VZW-DOCOM-BBP\",\"numberShareCapable\":\"Y\",\"eNineAddressIndicator\":\"true\",\"deviceType\":\"PHONE\",\"bbpInent\":\"BYOD\",\"triggerPricingValidaion\":true},\"data\":{\"lines\":[{\"device\":{\"id\":\"MR1L2LL/A\",\"deviceId\":\"359433083362780\",\"conractTerm\":\"MONTH_O_MONTH\"},\"sim\":{\"id\":\"DFILL4FF-NFC-A\",\"iccid\":\"89148000000751553653\",\"isCusomerProvidedSIM\":true,\"eSIM\":\"89049032003008882300001955592066\",\"imei2\":\"\"},\"mtn\":\"\",\"ispuFlow\":false,\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"depletionLocationCode\":\"\",\"numbersharePairingMode\":\"STANDALONE\",\"isNewLine\":true,\"newLineOrAAL\":true}]}}";
		AddDeviceUIRequest response = mapper.readValue(sampleResponseString, AddDeviceUIRequest.class);
		String uiResponseString = "{\"uiMeta\": {\"timestamp\": 1606904076236,\"cxpCorrelationId\": \"2020-12-02T10:14:36.+0000:90be2abf-a4e2-4e0e-8fcb-4edcdee0a1e6:cxp-customerprofile-se-qa-ev6v-sit4w-nscxp-756b46467b-5z5q6:nssit4\"},\"uiData\": {\"deviceInfo\": { \"deviceId\": \"359433083362780\",\"mfgCode\": \"APL\",\"prodName\": \"APPLE WATCH S3 42 SPBLK MIL\",\"prodType\": \"4G_LOCATOR\",\"eqpModeCode\": \"4GE\",\"eqpMode\": \"4G\",\"ems\": \"N\",\"mms\": \"Y\",\"gps\": \"Y\",\"ptt\": \"N\",\"globalPhone\": \"O\",\"wap\": \"N/A\",\"bluetooth\": \"Y\",\"brew\": \"N\",\"trustedMode\": \"N\",\"csim\": \"\",\"ehrpd\": \"N\",\"smsevdo\": \"N\",\"deviceCategory\": \"\",\"visionProdId\": \"38940\",\"preferredSim\": \"\",\"backupAssistCapable\": \"N\",\"simClass4G\": \"NR\",\"virtualSimSku\": \"\",\"deviceNoPay\": \"N\", \"deviceLostStolen\": \"N\",\"deviceSdmLock\": \"\",\"deviceLock\": \"\",\"devicePibLock\": \"\",\"prepayEligibility\": \"00\",\"eligibilityDate\": \"\",\"outletId\": \"\",\"dacc\": \"sdk.tracker.daccs\",\"deviceType\": \"4GE\",\"provTechType\": \"LTE\",\"launchPackageSku\": \"\",\"imSku\": \"MR1L2LL/A\",\"deviceCapabilityInd\": \"VD\",\"nfcCapable\": \"Y\",\"nfcCompatible\": \"Y\",\"pibDevice\": \"N\",\"connectedDeviceInd\": null,\"deviceFamilyType\": \"Connected\",\"buddyUpgrdEligInd\": \"N\",\"restrictToFamilyInd\": \"Y\",\"nonGeoDeviceInd\": \"\",\"m2MAllow\": \"M2MC\",\"hdVoice\": \"Y\",\"alkDevice\": \"HD\",\"shipDate\": \"20-DEC-2017\",\"cpo\": \"N\",\"lsClientId\": \"\",\"lsCustomerId\": \"\",\"lsBillAcctNumber\": \"\",\"v4B\": \"\",\"icEligInd\": \"\",\"icRemDays\": \"\",\"icRemSubsidyAmt\": \"\",\"e911AddrInd\": \"Y\",\"euiccCapable\": \"Y\",\"numberShareCapability\": \"Y\",\"wifiCalling\": \"Y\",\"vvm\": \"N\",\"imei1\": \"\",\"imei2\": \"\",\"osType\": \"WatchOS4\",\"postpaidRestrictStartDate\": \"\",\"dsEs12Fqdn\": \"\"},\"simInfo\": {\"simId\": \"89148000000751553653\",\"mfgCode\": \"GTO\",\"proName\": \"Gemalto 4FF NFC SIM - DF\",\"simGroup\": \"\",\"prodType\": \"4G_4FF_SIM\",\"simFormFactor\": \"\",\"simNoPay\": \"N\",\"simLostStolen\": \"N\",\"simLock\": \"\",\"simPibLock\": \"\",\"outletId\": \"\",\"sacc\": \"00722\",\"simType\": \"4GS\",\"iccidStatus\": \"AA\",\"numberLocation\": \"\",\"provTechType\": \"LTE\",\"launchPackageSku\": \"DFILL4FF-NFC-A\",\"imSku\": \"DFILL4FF-NFC-A\",\"nfcCapable\": \"Y\",\"nfcCompatible\": \"\",\"solderedSim\": \"\",\"simCapable\": \"DUAL_IMSI\",\"selfActivationCapableInd\": null,\"lsClientId\": \"\",\"lsCustomerId\": \"\",\"lsBillAcctNumber\": \"\",\"saleRetailer\": \"\",\"simSkuType\": \"T\",\"personalizedStatus\": \"\",\"personalizedTimeStamp\": \"\"},\"deviceSimCompatible\": \"Y\",\"deviceSimM2MPair\": \"N\",\"deviceESimCompatible\": \"\",\"deviceEsimM2MPair\": \"Y\",\"esimInfo\": {\"mfgCode\": \"\",\"launchPackageSku\": \"\",\"prodName\": \"\",\"preferredSoftSim\": \"SOFTNASIM-MP-D\",\"launchPackageSkuType\": \"\",\"pairedIccid\": \"\", \"eID\": \"8904903203008882300001955592066\"}}}";
		DeviceSimDetailsUIResponse uiResponse = mapper.readValue(uiResponseString, DeviceSimDetailsUIResponse.class);
		CartRedisData redisData=new CartRedisData();
		redisData.setCartId("69a66ef4d7e344dfb2db299209ea8333");
		redisData.setCaseId("123");
		redisData.setAccountNumber("0213143123-00001");
		redisData.setProcessingMTN("8136958775");
		redisData.setCartCreator("8136958775");
		URI url = URI.create("http://localhost/startBBPFlow");
		String bbpRequestVOString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"iccid\":\"89148000000835900342\",\"imei\":\"352898071702915\",\"isSmartphone\":true,\"esimFlowType\":\"LostICCIDProfile\"}";
		BBPRequestVO bbpRequestVO = mapper.readValue(bbpRequestVOString, BBPRequestVO.class);
		response = cartController.populateAddDeviceflow(uiResponse, redisData, "http://localhost/startBBPFlow","",bbpRequestVO);
		StepVerifier.create(Mono.just(response)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void startBBPFlowTest9() throws IOException {
		File responseFile = ResourceUtils.getFile("src/test/resources/DeviceSimDetailsUIResponse.json");
		String responseString = new String(Files.readAllBytes(responseFile.toPath()));
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		DeviceSimDetailsUIResponse response = mapper.readValue(responseString, DeviceSimDetailsUIResponse.class);
		String addDeviceStr = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM-BBP\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1596531-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"},{\"path\":\"FeatureConflicts\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"registerNumber\":0,\"accountNumber\":\"0220561307-00002\",\"cartCreator\":\"8439410557\",\"processingMTN\":\"8439292610\"},\"cartInfo\":{\"method\":\"\",\"financeLimitExceeded\":\"false\",\"cartId\":\"9c43a538-bcd8-4c1f-b271-6eb043271223\",\"clientAppName\":\"VZW-NETACE\",\"statusCode\":\"1\",\"statusMsg\":\"Success\",\"lines\":[{\"plan\":{},\"status\":1,\"errors\":[],\"spos\":[{\"id\":\"1167\",\"actionIndicator\":\"Z\",\"success\":true,\"is5GBolt\":false}],\"sfos\":[],\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"mtn\":\"8439292610\",\"device\":{\"cartItemType\":\"\",\"quantityOnHand\":\"\",\"upgradeReasonCode\":\"\",\"id\":\"MQ722LL/A\",\"description\":\"\",\"itemPrice\":\"449.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"discounts\":\"\",\"existingDeviceId\":\"\",\"existingDeviceName\":\"iPhone&reg; 8\",\"removedFeatures\":\"\",\"fiveGToFourGDownGrade\":false},\"sim\":{\"simId\":\"\",\"id\":\"EMBD4GSIM-N\"},\"warranty\":{\"id\":\"\",\"itemPrice\":\"0.0\",\"discounts\":\"\"},\"upgradeFee\":{\"id\":\"\",\"itemPrice\":\"\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"AAL\",\"currentPlanType\":\"ALP\"}],\"expressCheckout\":false,\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false},\"processMTNList\":[{\"mtn\":\"8439292610\",\"completedprocessSteps\":[\"pastDuePage\",\"MTNSelectionPage\",\"InterimPage\",\"GridWallPDP\",\"GridWallPDP\",\"MTNSelectionPage\",\"InterimPage\",\"GridWallPDP\",\"GridWallPDP\",\"GridWallPDP\"]}]}}}}";
		AddDeviceUIResponse responseServiceMono = mapper.readValue(addDeviceStr, AddDeviceUIResponse.class);
		when(redisHelper2.upsertAccountInfoEligibleInRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
		URI url = URI.create("http://localhost/startBBPFlow");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = null;
		String bbpRequestVOString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"iccid\":\"89148000000835900342\",\"imei\":\"352898071702915\",\"isConnectedCarRequired\":true}";
		BBPRequestVO bbpRequestVO = mapper.readValue(bbpRequestVOString, BBPRequestVO.class);
		when(cartHelper.initiateBBPFlow(Mockito.any())).thenReturn(Mono.just(response));
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(responseServiceMono));
		when(redisHelper2.upsertBBPFlowDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
		when(redisHelper2.upsertAddDeviceDataIntoRedis(Mockito.any())).thenReturn(Mono.just(new CartRedisData()));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.startBBPFlow(httpHeader, httpResponse,
				bbpRequestVO);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}
	@Test
	public void startBBPFlowTest10() throws IOException {
		File responseFile = ResourceUtils.getFile("src/test/resources/DeviceSimDetailsUIResponse.json");
		String responseString = new String(Files.readAllBytes(responseFile.toPath()));
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		DeviceSimDetailsUIResponse response = mapper.readValue(responseString, DeviceSimDetailsUIResponse.class);
		String addDeviceStr = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1596531-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"},{\"path\":\"FeatureConflicts\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"registerNumber\":0,\"accountNumber\":\"0220561307-00002\",\"cartCreator\":\"8439410557\",\"processingMTN\":\"8439292610\"},\"cartInfo\":{\"method\":\"\",\"financeLimitExceeded\":\"false\",\"cartId\":\"9c43a538-bcd8-4c1f-b271-6eb043271223\",\"clientAppName\":\"VZW-NETACE\",\"statusCode\":\"1\",\"statusMsg\":\"Success\",\"lines\":[{\"plan\":{},\"status\":1,\"errors\":[],\"spos\":[{\"id\":\"1167\",\"actionIndicator\":\"Z\",\"success\":true,\"is5GBolt\":false}],\"sfos\":[],\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"mtn\":\"8439292610\",\"device\":{\"cartItemType\":\"\",\"quantityOnHand\":\"\",\"upgradeReasonCode\":\"\",\"id\":\"MQ722LL/A\",\"description\":\"\",\"itemPrice\":\"449.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"discounts\":\"\",\"existingDeviceId\":\"\",\"existingDeviceName\":\"iPhone&reg; 8\",\"removedFeatures\":\"\",\"fiveGToFourGDownGrade\":false},\"sim\":{\"simId\":\"\",\"id\":\"EMBD4GSIM-N\"},\"warranty\":{\"id\":\"\",\"itemPrice\":\"0.0\",\"discounts\":\"\"},\"upgradeFee\":{\"id\":\"\",\"itemPrice\":\"\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"AAL\",\"currentPlanType\":\"ALP\"}],\"expressCheckout\":false,\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false},\"processMTNList\":[{\"mtn\":\"8439292610\",\"completedprocessSteps\":[\"pastDuePage\",\"MTNSelectionPage\",\"InterimPage\",\"GridWallPDP\",\"GridWallPDP\",\"MTNSelectionPage\",\"InterimPage\",\"GridWallPDP\",\"GridWallPDP\",\"GridWallPDP\"]}]}}}}";
		AddDeviceUIResponse responseServiceMono = mapper.readValue(addDeviceStr, AddDeviceUIResponse.class);
		CartRedisData redisData = new CartRedisData();
		redisData.setEsimType("IPAD");
		when(redisHelper2.upsertAccountInfoEligibleInRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(redisData));
		URI url = URI.create("http://localhost/startBBPFlow");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = null;
		String bbpRequestVOString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"iccid\":\"89148000000835900342\",\"imei\":\"352898071702915\",\"isSmartphone\":true}";
		BBPRequestVO bbpRequestVO = mapper.readValue(bbpRequestVOString, BBPRequestVO.class);
		when(cartHelper.initiateBBPFlow(Mockito.any())).thenReturn(Mono.just(response));
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(responseServiceMono));
		when(redisHelper2.upsertBBPFlowDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
		when(redisHelper2.upsertAddDeviceDataIntoRedis(Mockito.any())).thenReturn(Mono.just(new CartRedisData()));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.startBBPFlow(httpHeader, httpResponse,
				bbpRequestVO);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}
	@Test
	public void populateAddDeviceFlowTest11() throws IOException {
		String sampleResponseString = "{\"cartInfo\":{\"accountNumber\":\"0220561307-00002\",\"cartCreator\":\"8439410557\",\"globalId\":\"\",\"sessionId\":\"\",\"mtnFlow\":\"\",\"intendype\":\"BYOD\",\"processStep\":\"\",\"processAction\":\"addDevice\",\"clientAppName\":\"VZW-DOTCOM-BBP\",\"numberShareCapable\":\"Y\",\"eNineAddressIndicator\":\"true\",\"deviceType\":\"PHONE\",\"bbpInent\":\"BYOD\",\"triggerPricingValidaion\":true},\"data\":{\"lines\":[{\"device\":{\"id\":\"MR1L2LL/A\",\"deviceId\":\"359433083362780\",\"conractTerm\":\"MONTH_O_MONTH\"},\"sim\":{\"id\":\"DFILL4FF-NFC-A\",\"iccid\":\"89148000000751553653\",\"isCusomerProvidedSIM\":true,\"eSIM\":\"89049032003008882300001955592066\",\"imei2\":\"\"},\"mtn\":\"\",\"ispuFlow\":false,\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"depletionLocationCode\":\"\",\"numbersharePairingMode\":\"STANDALONE\",\"isNewLine\":true,\"newLineOrAAL\":true}]}}";
		AddDeviceUIRequest response = mapper.readValue(sampleResponseString, AddDeviceUIRequest.class);
		String uiResponseString = "{\"uiMeta\": {\"timestamp\": 1606904076236,\"cxpCorrelationId\": \"2020-12-02T10:14:36.+0000:90be2abf-a4e2-4e0e-8fcb-4edcdee0a1e6:cxp-customerprofile-se-qa-ev6v-sit4w-nscxp-756b46467b-5z5q6:nssit4\"},\"uiData\": {\"esimFlow\":null,\"deviceInfo\": { \"deviceId\": \"359433083362780\",\"mfgCode\": \"APL\",\"prodName\": \"APPLE WATCH S3 42 SPBLK MIL\",\"prodType\": \"4G_LOCATOR\",\"eqpModeCode\": \"4GE\",\"eqpMode\": \"4G\",\"ems\": \"N\",\"mms\": \"Y\",\"gps\": \"Y\",\"ptt\": \"N\",\"globalPhone\": \"O\",\"wap\": \"N/A\",\"bluetooth\": \"Y\",\"brew\": \"N\",\"trustedMode\": \"N\",\"csim\": \"\",\"ehrpd\": \"N\",\"smsevdo\": \"N\",\"deviceCategory\": \"\",\"visionProdId\": \"38940\",\"preferredSim\": \"\",\"backupAssistCapable\": \"N\",\"simClass4G\": \"NR\",\"virtualSimSku\": \"\",\"deviceNoPay\": \"N\", \"deviceLostStolen\": \"N\",\"deviceSdmLock\": \"\",\"deviceLock\": \"\",\"devicePibLock\": \"\",\"prepayEligibility\": \"00\",\"eligibilityDate\": \"\",\"outletId\": \"\",\"dacc\": \"sdk.tracker.daccs\",\"deviceType\": \"4GE\",\"provTechType\": \"LTE\",\"launchPackageSku\": \"\",\"imSku\": \"MR1L2LL/A\",\"deviceCapabilityInd\": \"VD\",\"nfcCapable\": \"Y\",\"nfcCompatible\": \"Y\",\"pibDevice\": \"N\",\"connectedDeviceInd\": null,\"deviceFamilyType\": \"Connected\",\"buddyUpgrdEligInd\": \"N\",\"restrictToFamilyInd\": \"Y\",\"nonGeoDeviceInd\": \"\",\"m2MAllow\": \"M2MC\",\"hdVoice\": \"Y\",\"alkDevice\": \"HD\",\"shipDate\": \"20-DEC-2017\",\"cpo\": \"N\",\"lsClientId\": \"\",\"lsCustomerId\": \"\",\"lsBillAcctNumber\": \"\",\"v4B\": \"\",\"icEligInd\": \"\",\"icRemDays\": \"\",\"icRemSubsidyAmt\": \"\",\"e911AddrInd\": \"Y\",\"euiccCapable\": \"Y\",\"numberShareCapability\": \"Y\",\"wifiCalling\": \"Y\",\"vvm\": \"N\",\"imei1\": \"\",\"imei2\": \"\",\"osType\": \"WatchOS4\",\"postpaidRestrictStartDate\": \"\",\"dsEs12Fqdn\": \"\"},\"simInfo\": {\"simId\": \"89148000000751553653\",\"mfgCode\": \"GTO\",\"proName\": \"Gemalto 4FF NFC SIM - DF\",\"simGroup\": \"\",\"prodType\": \"4G_4FF_SIM\",\"simFormFactor\": \"\",\"simNoPay\": \"N\",\"simLostStolen\": \"N\",\"simLock\": \"\",\"simPibLock\": \"\",\"outletId\": \"\",\"sacc\": \"00722\",\"simType\": \"4GS\",\"iccidStatus\": \"AA\",\"numberLocation\": \"\",\"provTechType\": \"LTE\",\"launchPackageSku\": \"DFILL4FF-NFC-A\",\"imSku\": \"DFILL4FF-NFC-A\",\"nfcCapable\": \"Y\",\"nfcCompatible\": \"\",\"solderedSim\": \"\",\"simCapable\": \"DUAL_IMSI\",\"selfActivationCapableInd\": null,\"lsClientId\": \"\",\"lsCustomerId\": \"\",\"lsBillAcctNumber\": \"\",\"saleRetailer\": \"\",\"simSkuType\": \"T\",\"personalizedStatus\": \"\",\"personalizedTimeStamp\": \"\"},\"deviceSimCompatible\": \"Y\",\"deviceSimM2MPair\": \"N\",\"deviceESimCompatible\": \"\",\"deviceEsimM2MPair\": \"Y\",\"esimInfo\": {\"mfgCode\": \"\",\"launchPackageSku\": \"\",\"prodName\": \"\",\"preferredSoftSim\": \"SOFTNASIM-MP-D\",\"launchPackageSkuType\": \"\",\"pairedIccid\": \"\", \"eID\": \"8904903203008882300001955592066\"}}}";
		DeviceSimDetailsUIResponse uiResponse = mapper.readValue(uiResponseString, DeviceSimDetailsUIResponse.class);
		CartRedisData redisData=new CartRedisData();
		redisData.setCartId("69a66ef4d7e344dfb2db299209ea8333");
		redisData.setCaseId("123");
		redisData.setAccountNumber("0213143123-00001");
		redisData.setProcessingMTN("8136958775");
		redisData.setCartCreator("8136958775");
		redisData.setEsimType("IPAD");
		URI url = URI.create("http://localhost/startBBPFlow");
		String bbpRequestVOString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"iccid\":\"89148000000835900342\",\"imei\":\"352898071702915\",\"isSmartphone\":true}";
		BBPRequestVO bbpRequestVO = mapper.readValue(bbpRequestVOString, BBPRequestVO.class);
		response = cartController.populateAddDeviceflow(uiResponse, redisData, "http://localhost/startBBPFlow","",bbpRequestVO);
		StepVerifier.create(Mono.just(response)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
}
