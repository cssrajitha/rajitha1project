package onevz.soe.cart.service.test.cases;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.helper.CartAddDeviceHelper;
import onevz.soe.cart.helper.CartAddDeviceHelper1;
import onevz.soe.cart.model.catalog.FeatureCatalogItem;
import onevz.soe.cart.model.common.Current;
import onevz.soe.cart.model.common.Plan;
import onevz.soe.cart.model.common.Vzdl;
import onevz.soe.cart.model.taxengine.request.NGDTaxEngineRequest;
import onevz.soe.cart.model.taxengine.response.NGDTaxEngineBaseResponse;
import onevz.soe.cart.model.taxengine.response.NGDTaxEngineResponseData;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.common.AddDeviceData;
import onevz.soe.cart.ui.common.CartInfo;
import onevz.soe.cart.ui.common.DeviceCartInfo;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.AddDeviceUIRequest;
import onevz.soe.customerprofile.response.CustomerProfileResponse;
import onevz.soe.utilities.serialization.JacksonMapperFactory;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { CartServiceTestConfig.class })
public class AddDeviceHelperVzdlTest {

    @Autowired
    private CartAddDeviceHelper deviceHelper;

    @InjectMocks
    private CartAddDeviceHelper1 deviceHelper1;

    @MockBean
    private CartServiceCxpHelper cxpHelper;

    @Mock
    private CartServiceCXPServices cartServiceCXPServices;


    @Test
    public void addDeviceHelperCurrentDetailsTest() throws IOException, SOEHTTPException {

        Current current=  deviceHelper.mapCurrentDetails(null,null);
        Assert.assertNull(current);

        FeatureCatalogItem item = new FeatureCatalogItem();
        Current current1=  deviceHelper.mapCurrentDetails(null,item);
        Assert.assertNotNull(current1);

        item.setPrice(19.00);
        Assert.assertNotNull(deviceHelper.mapCurrentDetails(null,item));
    }

    @Test
    public void addDeviceHelperFlexV2Test() throws IOException, SOEHTTPException {
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        deviceHelper.flexV2(request);
        DeviceCartInfo cartInfo = new DeviceCartInfo();
        request.setCartInfo(cartInfo);
        deviceHelper.flexV2(request);

        cartInfo.setFlexV2(false);
        Assert.assertFalse(deviceHelper.flexV2(request));
    }

    @Test
    public void addDeviceHelperPageDataTest() throws IOException, SOEHTTPException {

        AddDeviceUIRequest request = new AddDeviceUIRequest();
        DeviceCartInfo cartInfo = new DeviceCartInfo();
        request.setCartInfo(cartInfo);
        Vzdl vzdl = new Vzdl();
        deviceHelper.setPageData(request,vzdl);
        cartInfo.setIntendType("EUP");
        deviceHelper.setPageData(request,vzdl);
        Assert.assertNotNull(vzdl);
        Assert.assertEquals("", vzdl.getPage().getContentFragments());
    }

    @Test
    public void addDeviceMapMtnHashTest() throws IOException, SOEHTTPException {
        Current current = new Current();
        CartRedisData redisData =null;
        deviceHelper.mapMtnHash(redisData,null,current,null);

        AddDeviceUIRequest request = new AddDeviceUIRequest();
        deviceHelper.mapMtnHash(redisData,null,current,request);

        CustomerProfileResponse response = new CustomerProfileResponse();
        request.setCustomerProfileResponse(response);
        deviceHelper.mapMtnHash(redisData,null,current,request);
        Assert.assertNull(current.getLineHash());

    }

    @Test
    public void addDeviceFeatureIdTest() throws IOException, SOEHTTPException {
        Optional<Lines> requestLine = null;
        deviceHelper.fetchFeatureId(null);
        Assert.assertNull(deviceHelper.fetchFeatureId(requestLine));

    }

    @Test
    public void updateRequestWithRedis() throws IOException, SOEHTTPException {

        deviceHelper.UpdateRedisDataToRequest(null,null);

        AddDeviceUIRequest request = new AddDeviceUIRequest();
        deviceHelper.UpdateRedisDataToRequest(null,request);

        DeviceCartInfo cartInfo = new DeviceCartInfo();
        cartInfo.setFlexV2(true);
        request.setCartInfo(cartInfo);
        deviceHelper.UpdateRedisDataToRequest(null,request);

        CustomerProfileResponse response = new CustomerProfileResponse();
        CartRedisData data = new CartRedisData();
        data.setCustomerProfile(null);
        data.setFlowName(null);
        deviceHelper.UpdateRedisDataToRequest(data,request);

        data.setCustomerProfile(response);
        data.setFlowName("");
        deviceHelper.UpdateRedisDataToRequest(data,request);
        Assert.assertNotNull(data);

        data.setFlowName("EUP");
        deviceHelper.UpdateRedisDataToRequest(data,request);

    }

    @Test
    public  void deriveIntendTypeTest(){
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        DeviceCartInfo cartInfo = new DeviceCartInfo();
        deviceHelper1.mapIntendType(cartInfo, request.getData());

        cartInfo.setProcessAction("addSIM");
        deviceHelper1.mapIntendType(cartInfo, request.getData());

        cartInfo.setProcessAction("addDeviceSIM");
        cartInfo.setIntendType(CartConstants.BYOD);
        deviceHelper1.mapIntendType(cartInfo, request.getData());

        cartInfo.setIntendType(CartConstants.NSE_BYOD);
        deviceHelper1.mapIntendType(cartInfo, request.getData());

        cartInfo.setIntendType(CartConstants.EUPBYOD);
        deviceHelper1.mapIntendType(cartInfo, request.getData());

        cartInfo.setIntendType(CartConstants.NSE);
        Assert.assertNotNull( deviceHelper1.mapIntendType(cartInfo, request.getData()));

        cartInfo.setIntendType(null);
        Assert.assertNull(deviceHelper1.mapIntendType(cartInfo, request.getData()));

    }

    @Test
    public void callTaxEngineTest() throws IOException {
        NGDTaxEngineRequest ngdTaxEngineRequest = JacksonMapperFactory.defaultReader().readValue("{\"calculateTaxDetailsRequest\":{\"taxLines\":[{\"zipcode\":\"07083\",\"multiLineSeqNumber\":\"1\",\"itemsForTax\":[{\"itemSeq\":\"0\",\"itemCode\":\"MTM43LL/A\",\"groupId\":\"0000\",\"itemId\":\"000\",\"itemTypeInd\":\"D\",\"itemPrice\":\"929.99\",\"unitTaxBasedPrice\":\"929.99\",\"qty\":\"1\",\"discountAmount\":\"0.0\",\"mldSequenceNum\":\"1\"}]}]}}", NGDTaxEngineRequest.class);
        when(cartServiceCXPServices.callTaxEngineAPI(any())).thenReturn(Mono.just(JacksonMapperFactory.defaultReader().readValue("{\"data\":{\"meta\":{\"clientId\":\"SOE-cart\",\"clientTrackingId\":\"SOE-cart\",\"lineOfBusiness\":\"Consumer\",\"operation\":\"CalculateTax\",\"originatingSystem\":\"CXP_POS\",\"userId\":\"SOE-CART\",\"logId\":\"4d610436-8b2e-4e62-8751-cc8734f74fec\",\"parentServiceName\":\"taxengine\",\"serviceHostIp\":\"SOR-TAXENGINE-DOMAIN-SERVICE-C865CDD44-5NCMV\",\"serviceId\":\"sor-taxengine\",\"serviceName\":\"sor-taxengine-domain-service\",\"systemId\":\"SOR\",\"elapsedTime\":\"2(ms)\"},\"data\":{\"status\":{\"appCode\":\"1001\",\"appMessage\":\"Processed the taxengine request successfully\",\"category\":\"SUCCESS\"},\"orderTotalTax\":\"8254\",\"lineTaxDetails\":[{\"multiLineSeqNo\":\"1\",\"totalPriceForTax\":\"92999\",\"taxGrandTotal\":\"8254\",\"feeGrandTotal\":\"0\",\"taxPerItem\":[{\"itemSeqNo\":\"0\",\"chargeType\":\"P\",\"sku\":\"MTM43LL/A\",\"taxAmount\":\"8254\",\"eWasteAmount\":\"0\",\"amount911\":\"0\",\"taxDetails\":[{\"taxSeqNo\":\"1\",\"taxAmount\":\"3720\",\"taxAuthLevel\":\"3\",\"authorityId\":\"12032\",\"taxCategoryCode\":\"01\",\"taxType\":\"01\",\"taxRate\":\"40000\",\"glAccount\":\"224013\",\"taxPassType\":\"10\",\"taxDescription\":\"NY State Sales Tax\",\"taxDescShort\":\"NY State Sales Tax\",\"feeInd\":\"N\",\"taxSurcharge\":\"T\",\"taxFormulaNo\":\"1\"},{\"taxSeqNo\":\"2\",\"taxAmount\":\"4185\",\"taxAuthLevel\":\"3\",\"authorityId\":\"1707\",\"taxCategoryCode\":\"01\",\"taxType\":\"02\",\"taxRate\":\"45000\",\"glAccount\":\"224013\",\"taxPassType\":\"20\",\"taxDescription\":\"New York City Sales Tax\",\"taxDescShort\":\"NY Local Sales Tax\",\"feeInd\":\"N\",\"taxSurcharge\":\"T\",\"taxFormulaNo\":\"1\"},{\"taxSeqNo\":\"3\",\"taxAmount\":\"349\",\"taxAuthLevel\":\"3\",\"authorityId\":\"3032\",\"taxCategoryCode\":\"01\",\"taxType\":\"03\",\"taxRate\":\"3750\",\"glAccount\":\"224013\",\"taxPassType\":\"22\",\"taxDescription\":\"NY Local MCTD Sales Tax\",\"taxDescShort\":\"NY Local Sales Tax\",\"feeInd\":\"N\",\"taxSurcharge\":\"T\",\"taxFormulaNo\":\"1\"}]}]}]}}}", NGDTaxEngineBaseResponse.class)));
        Mono<NGDTaxEngineResponseData> ngdTaxEngineResponseDataMono = deviceHelper1.callTaxEngine("", ngdTaxEngineRequest);
        StepVerifier.create(ngdTaxEngineResponseDataMono).assertNext(Assert::assertNotNull).verifyComplete();

    }

    @Test
    public  void aiQuoteIntendTypeTest(){
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        DeviceCartInfo cartInfo = new DeviceCartInfo();
        //Empty cartInfo and request
        Assert.assertNull(deviceHelper1.mapIntendType(cartInfo, request.getData()));

        //Empty mtnFlow
        cartInfo.setMtnFlow("");
        deviceHelper1.mapIntendType(cartInfo, request.getData());
        cartInfo.setMtnFlow(null);
        Assert.assertNull(deviceHelper1.mapIntendType(cartInfo, request.getData()));

        //mtnFlow is AIQuote but intendType is not EUP
        cartInfo.setMtnFlow(CartConstants.AI_QUOTE);
        cartInfo.setIntendType(CartConstants.AAL);
        Assert.assertNotNull(deviceHelper1.mapIntendType(cartInfo, request.getData()));

        cartInfo.setMtnFlow(CartConstants.AI_QUOTE);
        cartInfo.setIntendType(CartConstants.EUP);
        Assert.assertNotNull(deviceHelper1.mapIntendType(cartInfo, request.getData()));

        //line exists but no plan exists
        AddDeviceData data = new AddDeviceData();
        List<Lines> lines = new ArrayList<>();
        Lines line= new Lines();
        line.setMtn("9999999999");
        lines.add(line);
        data.setLines(lines);
        request.setData(data);
        Assert.assertNotNull(deviceHelper1.mapIntendType(cartInfo, request.getData()));

        //plan exists but id doesn't exist
        lines = new ArrayList<>();
        line= new Lines();
        line.setMtn("9999999999");
        Plan plan= new Plan();
        plan.setName("Unlimited Ultimate");
        line.setPlan(plan);
        lines.add(line);
        data = new AddDeviceData();
        data.setLines(lines);
        request.setData(data);
        Assert.assertNotNull(deviceHelper1.mapIntendType(cartInfo, request.getData()));

        //plan exists and id exists and is null
        lines = new ArrayList<>();
        line= new Lines();
        line.setMtn("9999999999");
        plan= new Plan();
        plan.setName("Unlimited Ultimate");
        plan.setId("");
        line.setPlan(plan);
        lines.add(line);
        data = new AddDeviceData();
        data.setLines(lines);
        request.setData(data);
        Assert.assertNotNull(deviceHelper1.mapIntendType(cartInfo, request.getData()));

        //plan exists and id exists and not null
        lines = new ArrayList<>();
        line= new Lines();
        line.setMtn("9999999999");
        plan= new Plan();
        plan.setName("Unlimited Ultimate");
        plan.setId("123445");
        line.setPlan(plan);
        lines.add(line);
        data = new AddDeviceData();
        data.setLines(lines);
        request.setData(data);
        Assert.assertNotNull(deviceHelper1.mapIntendType(cartInfo, request.getData()));
    }


}
