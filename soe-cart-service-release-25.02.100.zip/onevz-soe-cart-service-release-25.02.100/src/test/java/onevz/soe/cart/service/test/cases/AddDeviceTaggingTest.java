package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.controller.CartUpdateOperationsController3;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper2;
import onevz.soe.cart.cxp.helper.CatalogServiceHelper;
import onevz.soe.cart.handler.PreHandleAddDevice;
import onevz.soe.cart.helper.*;

import onevz.soe.cart.responses.CatalogResponse;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.ui.requests.AddDeviceUIRequest;
import onevz.soe.cart.ui.responses.AddDeviceUIResponse;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.customerprofile.response.CustomerProfileResponse;
import onevz.soe.omnidl.util.DLUtilityService;
import onevz.soe.session.bean.SOELoginSessionBean;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.*;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.http.server.reactive.MockServerHttpResponse;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@RunWith(SpringJUnit4ClassRunner.class)
@WebFluxTest(CartUpdateOperationsController3.class)
public class AddDeviceTaggingTest {

    @Autowired
    private ObjectMapper mapper;


    @Autowired
    private CartUpdateOperationsController3 cartController3;

    @MockBean
    private RedisHelper redisHelper;

    @MockBean
    private CatalogServiceHelper catalogServiceHelper;

    @Value("${onevz.soe.cart.test.fileLocation}")
    private String testFileLocation;

    @Autowired
    SourceFileReaderUtil sourceFileReaderUtil;

    @MockBean
    private DLUtilityService dlUtilityService;
    @MockBean
    private CartAddDeviceHelper deviceHelper;

    @MockBean
    private CartServiceCxpHelper2 cartServiceCxpHelper2;

    @MockBean
    private PreHandleAddDevice preHandleAddDevice;

    @MockBean
    private RedisHelper2 redisHelper2;

    @MockBean
    private FeatureFlagHelper featureFlaghelper;
    @MockBean
    private OmniDLHelper dlHelper;
    @MockBean
    private CartAddDeviceHelper1 cartAddDeviceHelper1;
    @MockBean
    SOELoginSessionBean sessionBean;


    @Test
    public void addDeviceTaggingFlexV2Test() throws IOException {
        String requestFile = "AddDeviceUIRequestDPP.json";
        String responseFile = "AddDeviceResponseTest.json";
        String catalogResponseFeatureString = "{\"data\":{\"featureCatalogItems\":[{\"featureId\":\"81495\",\"skuDisplayName\":\"VisualVoiceMail\",\"skuId\":\"sku626678\",\"price\":0,\"asurionDeductible\":[],\"skuDisplayNameB2b\":\"VisualVoiceMail\",\"isActive\":true,\"isShowcase\":true}]}}";
        CatalogResponse catalogFeatureResponse = mapper.readValue(catalogResponseFeatureString, CatalogResponse.class);
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddDeviceUIRequest request = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        String sampleCustomerProfile = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CustomerProfileAssistedTagging.json", testFileLocation);
        CustomerProfileResponse customerProfileResponse = mapper.readValue(sampleCustomerProfile, CustomerProfileResponse.class);
        request.setCustomerProfileResponse(customerProfileResponse);
        when(deviceHelper.fetchFeatureId(any())).thenCallRealMethod();
        when(catalogServiceHelper.getCatalogDomainData(any(),any(),any(),any(),any())).thenReturn(Mono.just(catalogFeatureResponse));
        when(deviceHelper.mapMtnHash(any(),any(),any(),any())).thenCallRealMethod();
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(deviceHelper.getVzdlData(any(), any(), any(),any())).thenCallRealMethod();
        when(deviceHelper.getVzdlTxnData(any(), any(), any(),any())).thenCallRealMethod();
        when(deviceHelper.flexV2(any())).thenCallRealMethod();
        when(deviceHelper.mapCurrentDetails(any(),any())).thenCallRealMethod();
        when(cartAddDeviceHelper1.mapIntendType(any(), any())).thenCallRealMethod();
        when(deviceHelper.setPageData(any(),any())).thenCallRealMethod();
        //when(redisHelper.addFlowNameToRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(featureFlaghelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(cartServiceCxpHelper2.fetchFeatureCatalogResp(any(),any())).thenCallRealMethod();
        when(dlHelper.setFlow(any(),any())).thenReturn(Mono.just("EUP"));
        ReflectionTestUtils.setField(cartController3,"domains", List.of(".verizon.com",".verizonwireless.com"));
        URI url = URI.create("http://localhost/flexV2/add-device");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        when(featureFlaghelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {
            Assert.assertNotNull(resp);}).expectComplete().verify();
        Mockito.verify(deviceHelper, Mockito.times(1)).updateDLDataForAssisted(isNotNull());
    }

    @Test
    public void addDeviceTaggingFlexV2FalseTest() throws IOException {
        String requestFile = "AddDeviceUIRequestFRP.json";
        String responseFile = "AddDeviceResponseTest.json";
        String catalogResponseFeatureString = "{\"data\":{\"featureCatalogItems\":[{\"featureId\":\"8195\",\"skuDisplayName\":\"VisualVoiceMail\",\"skuId\":\"sku626678\",\"price\":0,\"asurionDeductible\":[],\"skuDisplayNameB2b\":\"VisualVoiceMail\",\"isActive\":true,\"isShowcase\":true}]}}";
        CatalogResponse catalogFeatureResponse = mapper.readValue(catalogResponseFeatureString, CatalogResponse.class);
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddDeviceUIRequest request = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        String sampleCustomerProfile = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CustomerProfileAssistedTagging.json", testFileLocation);
        CustomerProfileResponse customerProfileResponse = mapper.readValue(sampleCustomerProfile, CustomerProfileResponse.class);
        request.setCustomerProfileResponse(customerProfileResponse);
        when(deviceHelper.fetchFeatureId(any())).thenCallRealMethod();
        when(cartAddDeviceHelper1.mapIntendType(any(),any())).thenCallRealMethod();
        when(deviceHelper.setPageData(any(),any())).thenCallRealMethod();
        when(dlHelper.setFlow(any(),any())).thenReturn(Mono.just("EUP"));
        when(featureFlaghelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(catalogServiceHelper.getCatalogDomainData(any(),any(),any(),any(),any())).thenReturn(Mono.just(catalogFeatureResponse));
        when(deviceHelper.mapMtnHash(any(),any(),any(),any())).thenCallRealMethod();
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(deviceHelper.getVzdlData(any(), any(), any(),any())).thenCallRealMethod();
        when(deviceHelper.getVzdlTxnData(any(), any(), any(),any())).thenCallRealMethod();
        when(deviceHelper.flexV2(any())).thenCallRealMethod();
        when(deviceHelper.mapCurrentDetails(any(),any())).thenCallRealMethod();
        when(cartServiceCxpHelper2.fetchFeatureCatalogResp(any(),any())).thenCallRealMethod();
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        URI url = URI.create("http://localhost/flexV2/add-device");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        when(featureFlaghelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {
            Assert.assertNotNull(resp);}).expectComplete().verify();
        Mockito.verify(deviceHelper, Mockito.times(1)).updateDLDataForAssisted(isNotNull());

        response.setServiceBody(null);
        response.setErrors(new ArrayList<>());
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        request.getCartInfo().setFlexV2(false);
        url = URI.create("http://localhost/add-device");
        httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").header("mtn", "8437299178").build();
        httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(Assert::assertNotNull).expectComplete().verify();
        when(featureFlaghelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(false));
        controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void addDeviceTaggingFlexV2ExceptionTest() throws Exception {

        String requestFile = "AddDeviceUIRequestFRP.json";
        String responseFile = "AddDeviceResponseTest.json";
        String catalogResponseFeatureString = "{\"data\":{\"featureCatalogItems\":[{\"featureId\":\"8195\",\"skuDisplayName\":\"VisualVoiceMail\",\"skuId\":\"sku626678\",\"price\":0,\"asurionDeductible\":[],\"skuDisplayNameB2b\":\"VisualVoiceMail\",\"isActive\":true,\"isShowcase\":true}]}}";
        CatalogResponse catalogFeatureResponse = mapper.readValue(catalogResponseFeatureString, CatalogResponse.class);
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddDeviceUIRequest request = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        String sampleCustomerProfile = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CustomerProfileAssistedTagging.json", testFileLocation);
        CustomerProfileResponse customerProfileResponse = mapper.readValue(sampleCustomerProfile, CustomerProfileResponse.class);
        request.setCustomerProfileResponse(customerProfileResponse);
        when(deviceHelper.fetchFeatureId(any())).thenCallRealMethod();
        when(deviceHelper.mapMtnHash(any(),any(),any(),any())).thenCallRealMethod();
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(deviceHelper.getVzdlData(any(), any(), any(),any())).thenCallRealMethod();
        when(deviceHelper.getVzdlTxnData(any(), any(), any(),any())).thenCallRealMethod();
        when(deviceHelper.flexV2(any())).thenCallRealMethod();
        when(deviceHelper.mapCurrentDetails(any(),any())).thenCallRealMethod();
        when(featureFlaghelper.fetchAssistedTaggingFeatureFlag()).thenThrow(NullPointerException.class);
        when(cartAddDeviceHelper1.mapIntendType(any(),any())).thenCallRealMethod();
        when(deviceHelper.setPageData(any(),any())).thenCallRealMethod();
        when(dlHelper.setFlow(any(),any())).thenReturn(Mono.just("EUP"));
        when(cartServiceCxpHelper2.fetchFeatureCatalogResp(any(),any())).thenCallRealMethod();
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        URI url = URI.create("http://localhost/flexV2/add-device");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        when(featureFlaghelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {
            Assert.assertNotNull(resp);}).expectComplete().verify();

    }

    @Test
    public void addDeviceTaggingFlexV2EmptyVzdlTest() throws IOException {
        String requestFile = "AddDeviceUIRequestDPP.json";
        String responseFile = "AddDeviceResponseTest.json";
        String catalogResponseFeatureString = "{\"data\":{\"featureCatalogItems\":[{\"featureId\":\"81495\",\"skuDisplayName\":\"VisualVoiceMail\",\"skuId\":\"sku626678\",\"price\":0,\"asurionDeductible\":[],\"skuDisplayNameB2b\":\"VisualVoiceMail\",\"isActive\":true,\"isShowcase\":true}]}}";
        CatalogResponse catalogFeatureResponse = mapper.readValue(catalogResponseFeatureString, CatalogResponse.class);
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddDeviceUIRequest request = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        String sampleCustomerProfile = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CustomerProfileAssistedTagging.json", testFileLocation);
        CustomerProfileResponse customerProfileResponse = mapper.readValue(sampleCustomerProfile, CustomerProfileResponse.class);
        request.setCustomerProfileResponse(customerProfileResponse);
        when(deviceHelper.fetchFeatureId(any())).thenCallRealMethod();
        when(catalogServiceHelper.getCatalogDomainData(any(),any(),any(),any(),any())).thenReturn(Mono.just(catalogFeatureResponse));
        when(deviceHelper.mapMtnHash(any(),any(),any(),any())).thenCallRealMethod();
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(deviceHelper.getVzdlData(any(), any(), any(),any())).thenReturn(null);
        when(deviceHelper.getVzdlTxnData(any(), any(), any(),any())).thenCallRealMethod();
        when(deviceHelper.flexV2(any())).thenCallRealMethod();
        when(deviceHelper.setPageData(any(),any())).thenCallRealMethod();
        when(deviceHelper.mapCurrentDetails(any(),any())).thenCallRealMethod();
        when(cartServiceCxpHelper2.fetchFeatureCatalogResp(any(),any())).thenCallRealMethod();
        when(cartAddDeviceHelper1.mapIntendType(any(), any())).thenCallRealMethod();
        when(featureFlaghelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        URI url = URI.create("http://localhost/flexV2/add-device");
        when(redisHelper.addFlowNameToRedis(Mockito.any())).thenReturn(Mono.just(true));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        when(featureFlaghelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {
            Assert.assertNotNull(resp);}).expectComplete().verify();
    }

    @Test
    public void addDeviceTaggingFlexV2EmptyPageTest() throws IOException {
        String requestFile = "AddDeviceUIRequestDPP.json";
        String responseFile = "AddDeviceResponseTest.json";
        String catalogResponseFeatureString = "{\"data\":{\"featureCatalogItems\":[{\"featureId\":\"81495\",\"skuDisplayName\":\"VisualVoiceMail\",\"skuId\":\"sku626678\",\"price\":0,\"asurionDeductible\":[],\"skuDisplayNameB2b\":\"VisualVoiceMail\",\"isActive\":true,\"isShowcase\":true}]}}";
        CatalogResponse catalogFeatureResponse = mapper.readValue(catalogResponseFeatureString, CatalogResponse.class);
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddDeviceUIRequest request = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        String sampleCustomerProfile = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CustomerProfileAssistedTagging.json", testFileLocation);
        CustomerProfileResponse customerProfileResponse = mapper.readValue(sampleCustomerProfile, CustomerProfileResponse.class);
        request.setCustomerProfileResponse(customerProfileResponse);
        when(deviceHelper.fetchFeatureId(any())).thenCallRealMethod();
        when(catalogServiceHelper.getCatalogDomainData(any(),any(),any(),any(),any())).thenReturn(Mono.just(catalogFeatureResponse));
        when(deviceHelper.mapMtnHash(any(),any(),any(),any())).thenCallRealMethod();
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(deviceHelper.getVzdlData(any(), any(), any(),any())).thenCallRealMethod();
        when(deviceHelper.getVzdlTxnData(any(), any(), any(),any())).thenCallRealMethod();
        when(deviceHelper.flexV2(any())).thenCallRealMethod();
        when(deviceHelper.setPageData(any(),any())).thenReturn(null);
        when(deviceHelper.mapCurrentDetails(any(),any())).thenCallRealMethod();
        when(cartServiceCxpHelper2.fetchFeatureCatalogResp(any(),any())).thenCallRealMethod();
        when(cartAddDeviceHelper1.mapIntendType(any(), any())).thenCallRealMethod();
        when(featureFlaghelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        URI url = URI.create("http://localhost/flexV2/add-device");
        when(redisHelper.addFlowNameToRedis(Mockito.any())).thenReturn(Mono.just(true));
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        when(featureFlaghelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {
            Assert.assertNotNull(resp);}).expectComplete().verify();
    }

    @Test
    public void addDeviceTaggingFlexV2EmptyIntendTypeTest() throws IOException {
        String requestFile = "AddDeviceUIRequestDPP.json";
        String responseFile = "AddDeviceResponseTest.json";
        String catalogResponseFeatureString = "{\"data\":{\"featureCatalogItems\":[{\"featureId\":\"81495\",\"skuDisplayName\":\"VisualVoiceMail\",\"skuId\":\"sku626678\",\"price\":0,\"asurionDeductible\":[],\"skuDisplayNameB2b\":\"VisualVoiceMail\",\"isActive\":true,\"isShowcase\":true}]}}";
        CatalogResponse catalogFeatureResponse = mapper.readValue(catalogResponseFeatureString, CatalogResponse.class);
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddDeviceUIRequest request = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        String sampleCustomerProfile = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CustomerProfileAssistedTagging.json", testFileLocation);
        CustomerProfileResponse customerProfileResponse = mapper.readValue(sampleCustomerProfile, CustomerProfileResponse.class);
        request.setCustomerProfileResponse(customerProfileResponse);
        when(deviceHelper.fetchFeatureId(any())).thenCallRealMethod();
        when(catalogServiceHelper.getCatalogDomainData(any(),any(),any(),any(),any())).thenReturn(Mono.just(catalogFeatureResponse));
        when(deviceHelper.mapMtnHash(any(),any(),any(),any())).thenCallRealMethod();
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(deviceHelper.getVzdlData(any(), any(), any(),any())).thenCallRealMethod();
        when(deviceHelper.getVzdlTxnData(any(), any(), any(),any())).thenCallRealMethod();
        when(deviceHelper.flexV2(any())).thenCallRealMethod();
        when(deviceHelper.setPageData(any(),any())).thenReturn(null);
        when(deviceHelper.mapCurrentDetails(any(),any())).thenCallRealMethod();
        when(cartServiceCxpHelper2.fetchFeatureCatalogResp(any(),any())).thenCallRealMethod();
        when(cartAddDeviceHelper1.mapIntendType(any(), any())).thenReturn(null);
        when(featureFlaghelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        URI url = URI.create("http://localhost/flexV2/add-device");
        when(redisHelper.addFlowNameToRedis(Mockito.any())).thenReturn(Mono.just(true));
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        when(featureFlaghelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {
            Assert.assertNotNull(resp);}).expectComplete().verify();
    }

    @Test
    public void addDeviceTaggingFlexV2DisableTaggingTest() throws IOException {
        String requestFile = "AddDeviceUIRequestDPP.json";
        String responseFile = "AddDeviceResponseTest.json";
        String catalogResponseFeatureString = "{\"data\":{\"featureCatalogItems\":[{\"featureId\":\"81495\",\"skuDisplayName\":\"VisualVoiceMail\",\"skuId\":\"sku626678\",\"price\":0,\"asurionDeductible\":[],\"skuDisplayNameB2b\":\"VisualVoiceMail\",\"isActive\":true,\"isShowcase\":true}]}}";
        CatalogResponse catalogFeatureResponse = mapper.readValue(catalogResponseFeatureString, CatalogResponse.class);
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddDeviceUIRequest request = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        String sampleCustomerProfile = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CustomerProfileAssistedTagging.json", testFileLocation);
        CustomerProfileResponse customerProfileResponse = mapper.readValue(sampleCustomerProfile, CustomerProfileResponse.class);
        request.setCustomerProfileResponse(customerProfileResponse);
        when(deviceHelper.fetchFeatureId(any())).thenCallRealMethod();
        when(catalogServiceHelper.getCatalogDomainData(any(),any(),any(),any(),any())).thenReturn(Mono.just(catalogFeatureResponse));
        when(deviceHelper.mapMtnHash(any(),any(),any(),any())).thenCallRealMethod();
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(deviceHelper.getVzdlData(any(), any(), any(),any())).thenCallRealMethod();
        when(deviceHelper.getVzdlTxnData(any(), any(), any(),any())).thenCallRealMethod();
        when(deviceHelper.flexV2(any())).thenCallRealMethod();
        when(deviceHelper.setPageData(any(),any())).thenReturn(null);
        when(deviceHelper.mapCurrentDetails(any(),any())).thenCallRealMethod();
        when(cartServiceCxpHelper2.fetchFeatureCatalogResp(any(),any())).thenCallRealMethod();
        when(cartAddDeviceHelper1.mapIntendType(any(), any())).thenReturn(null);
        when(featureFlaghelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(false));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        URI url = URI.create("http://localhost/flexV2/add-device");
        when(redisHelper.addFlowNameToRedis(Mockito.any())).thenReturn(Mono.just(true));
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        when(featureFlaghelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {
            Assert.assertNotNull(resp);}).expectComplete().verify();
    }

    @Test
    public void addDeviceTaggingFlexV2NotEmptyIntendTest() throws IOException {
        String requestFile = "AddDeviceUIRequestDPP.json";
        String responseFile = "AddDeviceResponseTest.json";
        String catalogResponseFeatureString = "{\"data\":{\"featureCatalogItems\":[{\"featureId\":\"81495\",\"skuDisplayName\":\"VisualVoiceMail\",\"skuId\":\"sku626678\",\"price\":0,\"asurionDeductible\":[],\"skuDisplayNameB2b\":\"VisualVoiceMail\",\"isActive\":true,\"isShowcase\":true}]}}";
        CatalogResponse catalogFeatureResponse = mapper.readValue(catalogResponseFeatureString, CatalogResponse.class);
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddDeviceUIRequest request = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        String sampleCustomerProfile = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CustomerProfileAssistedTagging.json", testFileLocation);
        CustomerProfileResponse customerProfileResponse = mapper.readValue(sampleCustomerProfile, CustomerProfileResponse.class);
        request.setCustomerProfileResponse(customerProfileResponse);
        when(deviceHelper.fetchFeatureId(any())).thenCallRealMethod();
        when(catalogServiceHelper.getCatalogDomainData(any(),any(),any(),any(),any())).thenReturn(Mono.just(catalogFeatureResponse));
        when(deviceHelper.mapMtnHash(any(),any(),any(),any())).thenCallRealMethod();
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(deviceHelper.getVzdlData(any(), any(), any(),any())).thenCallRealMethod();
        when(deviceHelper.getVzdlTxnData(any(), any(), any(),any())).thenCallRealMethod();
        when(deviceHelper.flexV2(any())).thenCallRealMethod();
        when(deviceHelper.setPageData(any(),any())).thenReturn(null);
        when(deviceHelper.mapCurrentDetails(any(),any())).thenCallRealMethod();
        when(cartServiceCxpHelper2.fetchFeatureCatalogResp(any(),any())).thenCallRealMethod();
        when(cartAddDeviceHelper1.mapIntendType(any(), any())).thenReturn(null);
        when(featureFlaghelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        URI url = URI.create("http://localhost/add-device");
        when(redisHelper.addFlowNameToRedis(Mockito.any())).thenReturn(Mono.just(true));
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        when(featureFlaghelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {
            Assert.assertNotNull(resp);}).expectComplete().verify();
    }

    @Test
    public void addDeviceTaggingFlexV2NotTest() throws IOException {
        String requestFile = "AddDeviceUIRequestDPP.json";
        String responseFile = "AddDeviceResponseTest.json";
        String catalogResponseFeatureString = "{\"data\":{\"featureCatalogItems\":[{\"featureId\":\"81495\",\"skuDisplayName\":\"VisualVoiceMail\",\"skuId\":\"sku626678\",\"price\":0,\"asurionDeductible\":[],\"skuDisplayNameB2b\":\"VisualVoiceMail\",\"isActive\":true,\"isShowcase\":true}]}}";
        CatalogResponse catalogFeatureResponse = mapper.readValue(catalogResponseFeatureString, CatalogResponse.class);
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddDeviceUIRequest request = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        String sampleCustomerProfile = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CustomerProfileAssistedTagging.json", testFileLocation);
        CustomerProfileResponse customerProfileResponse = mapper.readValue(sampleCustomerProfile, CustomerProfileResponse.class);
        request.setCustomerProfileResponse(customerProfileResponse);
        when(deviceHelper.fetchFeatureId(any())).thenCallRealMethod();
        when(catalogServiceHelper.getCatalogDomainData(any(),any(),any(),any(),any())).thenReturn(Mono.just(catalogFeatureResponse));
        when(deviceHelper.mapMtnHash(any(),any(),any(),any())).thenCallRealMethod();
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(deviceHelper.getVzdlData(any(), any(), any(),any())).thenCallRealMethod();
        when(deviceHelper.getVzdlTxnData(any(), any(), any(),any())).thenCallRealMethod();
        when(deviceHelper.flexV2(any())).thenCallRealMethod();
        when(deviceHelper.setPageData(any(),any())).thenReturn(null);
        when(deviceHelper.mapCurrentDetails(any(),any())).thenCallRealMethod();
        when(cartServiceCxpHelper2.fetchFeatureCatalogResp(any(),any())).thenCallRealMethod();
        when(cartAddDeviceHelper1.mapIntendType(any(), any())).thenCallRealMethod();
        when(featureFlaghelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(dlHelper.setFlow(any(),any())).thenReturn(Mono.just("EUP"));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        URI url = URI.create("http://localhost/add-device");
        when(redisHelper.addFlowNameToRedis(Mockito.any())).thenReturn(Mono.just(true));
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        when(featureFlaghelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {
            Assert.assertNotNull(resp);}).expectComplete().verify();
    }

    @Test
    public void addDeviceTaggingFlexV2NotEmptyPegaRespTest() throws IOException {
        String requestFile = "AddDeviceUIRequestDPP.json";
        String responseFile = "AddDeviceResponseTest.json";
        String catalogResponseFeatureString = "{\"data\":{\"featureCatalogItems\":[{\"featureId\":\"81495\",\"skuDisplayName\":\"VisualVoiceMail\",\"skuId\":\"sku626678\",\"price\":0,\"asurionDeductible\":[],\"skuDisplayNameB2b\":\"VisualVoiceMail\",\"isActive\":true,\"isShowcase\":true}]}}";
        CatalogResponse catalogFeatureResponse = mapper.readValue(catalogResponseFeatureString, CatalogResponse.class);
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddDeviceUIRequest request = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        response.getServiceBody().getServiceResponse().getContext().setCartInfo(null);
        String sampleCustomerProfile = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CustomerProfileAssistedTagging.json", testFileLocation);
        CustomerProfileResponse customerProfileResponse = mapper.readValue(sampleCustomerProfile, CustomerProfileResponse.class);
        request.setCustomerProfileResponse(customerProfileResponse);
        when(deviceHelper.fetchFeatureId(any())).thenCallRealMethod();
        when(catalogServiceHelper.getCatalogDomainData(any(),any(),any(),any(),any())).thenReturn(Mono.just(catalogFeatureResponse));
        when(deviceHelper.mapMtnHash(any(),any(),any(),any())).thenCallRealMethod();
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(deviceHelper.getVzdlData(any(), any(), any(),any())).thenCallRealMethod();
        when(deviceHelper.getVzdlTxnData(any(), any(), any(),any())).thenCallRealMethod();
        when(deviceHelper.flexV2(any())).thenCallRealMethod();
        when(deviceHelper.setPageData(any(),any())).thenReturn(null);
        when(deviceHelper.mapCurrentDetails(any(),any())).thenCallRealMethod();
        when(cartServiceCxpHelper2.fetchFeatureCatalogResp(any(),any())).thenCallRealMethod();
        when(cartAddDeviceHelper1.mapIntendType(any(), any())).thenCallRealMethod();

        when(featureFlaghelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(dlHelper.setFlow(any(),any())).thenReturn(Mono.just("EUP"));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        URI url = URI.create("http://localhost/add-device");
        when(redisHelper.addFlowNameToRedis(Mockito.any())).thenReturn(Mono.just(true));
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        when(featureFlaghelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {
            Assert.assertNotNull(resp);}).expectComplete().verify();
    }

    @Test
    public void addDeviceTaggingFlexV2NotDisableAssistedTaggingFlagTest() throws IOException {
        String requestFile = "AddDeviceUIRequestDPP.json";
        String responseFile = "AddDeviceResponseTest.json";
        String catalogResponseFeatureString = "{\"data\":{\"featureCatalogItems\":[{\"featureId\":\"81495\",\"skuDisplayName\":\"VisualVoiceMail\",\"skuId\":\"sku626678\",\"price\":0,\"asurionDeductible\":[],\"skuDisplayNameB2b\":\"VisualVoiceMail\",\"isActive\":true,\"isShowcase\":true}]}}";
        CatalogResponse catalogFeatureResponse = mapper.readValue(catalogResponseFeatureString, CatalogResponse.class);
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddDeviceUIRequest request = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        response.getServiceBody().getServiceResponse().getContext().setCartInfo(null);
        request.getData().setEnableAssistedTagging(true);
        String sampleCustomerProfile = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CustomerProfileAssistedTagging.json", testFileLocation);
        CustomerProfileResponse customerProfileResponse = mapper.readValue(sampleCustomerProfile, CustomerProfileResponse.class);
        request.setCustomerProfileResponse(customerProfileResponse);
        when(deviceHelper.fetchFeatureId(any())).thenCallRealMethod();
        when(catalogServiceHelper.getCatalogDomainData(any(),any(),any(),any(),any())).thenReturn(Mono.just(catalogFeatureResponse));
        when(deviceHelper.mapMtnHash(any(),any(),any(),any())).thenCallRealMethod();
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(deviceHelper.getVzdlData(any(), any(), any(),any())).thenCallRealMethod();
        when(deviceHelper.getVzdlTxnData(any(), any(), any(),any())).thenCallRealMethod();
        when(deviceHelper.flexV2(any())).thenCallRealMethod();
        when(deviceHelper.setPageData(any(),any())).thenReturn(null);
        when(deviceHelper.mapCurrentDetails(any(),any())).thenCallRealMethod();
        when(cartServiceCxpHelper2.fetchFeatureCatalogResp(any(),any())).thenCallRealMethod();
        when(cartAddDeviceHelper1.mapIntendType(any(), any())).thenCallRealMethod();

        when(featureFlaghelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(dlHelper.setFlow(any(),any())).thenReturn(Mono.just("EUP"));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        URI url = URI.create("http://localhost/add-device");
        when(redisHelper.addFlowNameToRedis(Mockito.any())).thenReturn(Mono.just(true));
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        when(featureFlaghelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {
            Assert.assertNotNull(resp);}).expectComplete().verify();
    }

}
