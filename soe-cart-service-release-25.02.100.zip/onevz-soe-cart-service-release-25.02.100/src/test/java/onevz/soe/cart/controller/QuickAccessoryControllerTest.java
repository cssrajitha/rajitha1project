package onevz.soe.cart.controller;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import junit.framework.Assert;
import onevz.soe.cart.helper.AddQuickAccessoryToCartHelper;
import onevz.soe.cart.helper.SaveQuickAccessoryToCartHelper;
import onevz.soe.cart.model.addQuickAccessoryToCart.AddQuickAccessoryRequest;
import onevz.soe.cart.model.addQuickAccessoryToCart.AddQuickAccessoryResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.requests.SaveQuickAccessoryRequest;
import onevz.soe.cart.ui.responses.SaveQuickAccessoryResponse;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpMethod;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.net.URI;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = {CartServiceTestConfig.class})
public class QuickAccessoryControllerTest {

    @InjectMocks
    private QuickAccessoryController mockController;

    @Autowired
    ObjectMapper mapper;

    @Mock
    private SaveQuickAccessoryToCartHelper saveQuickAccessoryToCartHelper;

    @Mock
    AddQuickAccessoryToCartHelper addQuickAccessoryToCartHelper;

    @org.junit.jupiter.api.Test
    void addQuickAccessoryTest() {
        URI url = URI.create("http://localhost/cart");
        AddQuickAccessoryRequest request = new AddQuickAccessoryRequest();
        request.setCartId("test");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").build();
        when(addQuickAccessoryToCartHelper.addQuickAccessoryToCart(any(), any())).thenReturn(Mono.just(new AddQuickAccessoryResponse()));
        Mono<AddQuickAccessoryResponse> controllerResponse = mockController.addQuickAccessory(httpRequest, request);
        StepVerifier.create(controllerResponse).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void saveQuickAccessoryToCart() throws JsonProcessingException {
        SaveQuickAccessoryResponse response = new SaveQuickAccessoryResponse();
        when(saveQuickAccessoryToCartHelper.saveQuickAccessory(any())).thenReturn(Mono.just(response));
        String requestJson = "{\"cartId\":\"c1b16416-55f1-45b7-88cb-dc059ef4e752\",\"flowType\":\"QuickAccessory\",\"lines\":[{\"accessories\":[{\"depletionType\":\"L\",\"qty\":1,\"sorId\":\"MV7N2AM/A\"}]}]}";
        SaveQuickAccessoryRequest request = mapper.readValue(requestJson, SaveQuickAccessoryRequest.class);

        Mono<SaveQuickAccessoryResponse> serviceResp = mockController.saveQuickAccessoryToCart(request);
        StepVerifier.create(serviceResp).assertNext(Assertions::assertNotNull).expectComplete()
                .verify();
    }
    @Test
    public void saveQuickAccessoryToCartWithNoCartId() throws JsonProcessingException {
        SaveQuickAccessoryResponse response = new SaveQuickAccessoryResponse();
        when(saveQuickAccessoryToCartHelper.saveQuickAccessory(any())).thenReturn(Mono.just(response));
        String requestJson = "{\"cartId\":\"c1b16416-55f1-45b7-88cb-dc059ef4e752\",\"flowType\":\"QuickAccessory\",\"lines\":[{\"accessories\":[{\"depletionType\":\"L\",\"qty\":1,\"sorId\":\"MV7N2AM/A\"}]}]}";
        SaveQuickAccessoryRequest request = mapper.readValue(requestJson, SaveQuickAccessoryRequest.class);
        request.setCartId("");

        Mono<SaveQuickAccessoryResponse> serviceResp = mockController.saveQuickAccessoryToCart(request);
        StepVerifier.create(serviceResp).assertNext(Assertions::assertNotNull).expectComplete()
                .verify();
    }
}
