package onevz.soe.cart.service.test.cases;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.helper.RedisHelper3;
import onevz.soe.cart.model.common.Address;
import onevz.soe.cart.model.common.FiveG.BulkAddressQualificationRedisResponse;
import onevz.soe.cart.model.common.FiveG.BulkQualifiedAddressResponse;
import onevz.soe.cart.model.common.FiveG.Check5GAvailabilityRedisResponse;
import onevz.soe.cart.model.common.FiveG.FiveGLTEAddressRedis;
import onevz.soe.cart.ui.requests.AddPlanAndDeviceUIRequest;
import onevz.soe.session.bean.SOELoginSessionBean;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.util.HashMap;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(RedisHelper3.class)
public class RedisHelper3Test {


    @Autowired
    private RedisHelper3 redisHelper3;

    @MockBean
    SOELoginSessionBean sessionBean;

    @Autowired
    private ObjectMapper mapper;

    @Test
    public void getBulkQualificationAddressFromRedisTest() throws JsonProcessingException {
        String response = "{\"output\":{\"qualifiedAddressList\":[{\"qualified\":true,\"qualified4GHome\":false,\"addressLine1\":\"1 VERIZON WAY\",\"addressLine2\":\"\",\"streetNumber\":\"1\",\"streetName\":\"VERIZON\",\"streetType\":\"WAY\",\"city\":\"BASKING RIDGE\",\"state\":\"NJ\",\"zipCode\":\"07920\",\"bundleDetails\":[{\"bundleName\":\"5GHomeGeminiSelfSetup\",\"id\":\"16900001\",\"type\":\"s\"},{\"bundleName\":\"5GHomeGeminiProfSetup\",\"id\":\"16900002\",\"type\":\"p\"}],\"launchType\":\"FCL\",\"addressType\":\"SFU\",\"eventCorrelationId\":\"07920_1681281026967_333\",\"currentFloorNumber\":\"\",\"floorPlanAvailable\":false,\"uberPinEligible\":false,\"fiosQualified\":false,\"gigqualified\":false,\"hashedlocationId\":\"5cc25e41e96a2558b2b0d98029e6302fa204bdff3e4ad52c6cc0d6c264d77fe6\",\"hashedLocusId\":\"5cc25e41e96a2558b2b0d98029e6302fa204bdff3e4ad52c6cc0d6c264d77fe6\",\"subLocationId\":\"300512786823\",\"networkBandwidthType\":\"mmw\",\"moveQualified\":false,\"existingFWA\":false,\"existingMobility\":false,\"recordIdentifier\":\"8285\",\"addressValid\":\"true\",\"bulkQualAddressType\":\"BillAccount\",\"HSI\":false,\"qualifiedCBand\":false},{\"qualified\":false,\"qualified4GHome\":false,\"addressLine1\":\"429 MONTGOMERY AVE APT A302\",\"addressLine2\":\"\",\"streetNumber\":\"429\",\"streetName\":\"MONTGOMERY\",\"streetType\":\"AVE\",\"city\":\"HAVERFORD\",\"state\":\"PA\",\"zipCode\":\"19041\",\"bundleDetails\":[],\"launchType\":\"FCL\",\"addressType\":\"\",\"eventCorrelationId\":\"19041_1681281026967_613\",\"currentFloorNumber\":\"\",\"floorPlanAvailable\":false,\"uberPinEligible\":false,\"fiosQualified\":false,\"gigqualified\":false,\"hashedlocationId\":\"b6efbf37dd5504027d17c6983e54618f7601cc81a1a0400b0e3d0a2c57c7aedc\",\"hashedLocusId\":\"32305af95206f3164e97cbe15fa36d2eadd66c4c9dfb2db6d7790f2761261eaf\",\"subLocationId\":\"300009676112\",\"networkBandwidthType\":\"cbd\",\"moveQualified\":false,\"existingFWA\":false,\"existingMobility\":false,\"recordIdentifier\":\"4735\",\"addressValid\":\"true\",\"bulkQualAddressType\":\"Mtn Address\",\"cbandSku\":\"false\",\"HSI\":false,\"qualifiedCBand\":true}],\"notQualifiedAddressList\":[{\"qualified\":false,\"qualified4GHome\":false,\"addressLine1\":\"3877 BRODWAY\",\"addressLine2\":\"\",\"streetNumber\":\"\",\"streetName\":\"\",\"streetType\":\"\",\"city\":\"NEW YORK\",\"state\":\"NY\",\"zipCode\":\"10032\",\"bundleDetails\":[],\"launchType\":\"FCL\",\"addressType\":\"\",\"eventCorrelationId\":\"10032_1681281026967_118\",\"currentFloorNumber\":\"\",\"floorPlanAvailable\":false,\"uberPinEligible\":false,\"fiosQualified\":false,\"gigqualified\":false,\"hashedlocationId\":\"01701119f81f70a36edb165093572be269d7018d7e51f60225635c8cfa363fe0\",\"hashedLocusId\":\"01701119f81f70a36edb165093572be269d7018d7e51f60225635c8cfa363fe0\",\"subLocationId\":\"400206858708\",\"moveQualified\":false,\"existingFWA\":false,\"existingMobility\":false,\"recordIdentifier\":\"8963\",\"addressValid\":\"false\",\"bulkQualAddressType\":\"PersonContact\",\"HSI\":false,\"qualifiedCBand\":false}],\"billingAddress\":{\"qualified\":true,\"qualified4GHome\":false,\"addressLine1\":\"1 VERIZON WAY\",\"addressLine2\":\"\",\"streetNumber\":\"1\",\"streetName\":\"VERIZON\",\"streetType\":\"WAY\",\"city\":\"BASKING RIDGE\",\"state\":\"NJ\",\"zipCode\":\"07920\",\"bundleDetails\":[{\"bundleName\":\"5GHomeGeminiSelfSetup\",\"id\":\"16900001\",\"type\":\"s\"},{\"bundleName\":\"5GHomeGeminiProfSetup\",\"id\":\"16900002\",\"type\":\"p\"}],\"launchType\":\"FCL\",\"addressType\":\"SFU\",\"eventCorrelationId\":\"07920_1681281026967_333\",\"currentFloorNumber\":\"\",\"floorPlanAvailable\":false,\"uberPinEligible\":false,\"fiosQualified\":false,\"gigqualified\":false,\"hashedlocationId\":\"5cc25e41e96a2558b2b0d98029e6302fa204bdff3e4ad52c6cc0d6c264d77fe6\",\"hashedLocusId\":\"5cc25e41e96a2558b2b0d98029e6302fa204bdff3e4ad52c6cc0d6c264d77fe6\",\"subLocationId\":\"300512786823\",\"networkBandwidthType\":\"mmw\",\"moveQualified\":false,\"existingFWA\":false,\"existingMobility\":false,\"recordIdentifier\":\"8285\",\"addressValid\":\"true\",\"bulkQualAddressType\":\"BillAccount\",\"HSI\":false,\"qualifiedCBand\":false},\"customerInfo\":{\"emailAddress\":\"HSVPVMWIZ_QLMVH@VZW.COM\",\"phoneNumber\":\"4033363347\",\"loginMtn\":\"8137670462\"},\"errorMap\":null,\"statusCode\":\"00\",\"statusMessage\":\"Service Completed Successfully\",\"aqCaseId\":\"AQ-11746794-E01\",\"existingFWA\":false,\"existingMobility\":true}}";
        BulkAddressQualificationRedisResponse bulkAddressQualificationRedisResponse = mapper.readValue(response, BulkAddressQualificationRedisResponse.class);
        Map<String, String> sessionData = new HashMap<>();
        when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(bulkAddressQualificationRedisResponse));
        when(sessionBean.setSessionData(any(), any())).thenReturn(Mono.just(true));
        when(sessionBean.getSessionData(any())).thenReturn(Mono.just(sessionData));
        when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
        String request = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"intendType\":\"AAL_5G\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\",\"enableResume\":\"false\",\"addressRecordIdentifier\":\"8285\",\"addressInfo\":{\"addressLine1\":\"1 VERIZON WAY\",\"addressLine2\":\"\",\"city\":\"BASKING RIDGE\",\"state\":\"NJ\",\"zipCode\":\"07920\"}},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
        AddPlanAndDeviceUIRequest addPlanAndDeviceUIRequest = mapper.readValue(request, AddPlanAndDeviceUIRequest.class);
        StepVerifier.create(redisHelper3.getBulkQualificationAddressFromRedis(addPlanAndDeviceUIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        String requestRestart = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"action\":\"Restart\",\"intendType\":\"AAL_5G\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\",\"bulkQualIndicator\":\"Y\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
        AddPlanAndDeviceUIRequest addPlanAndDeviceUIRequestRestart = mapper.readValue(requestRestart, AddPlanAndDeviceUIRequest.class);
        String responseRestart = "{\"output\":{\"qualified\":true,\"qualified4GHome\":false,\"aqCaseId\":\"AQ-11824790-E01\",\"addressLine1\":\"1 VERIZON WAY\",\"streetNumber\":\"1\",\"streetName\":\"VERIZON\",\"streetType\":\"WAY\",\"city\":\"BASKING RIDGE\",\"state\":\"NJ\",\"zipCode\":\"07920\",\"bundleDetails\":[{\"bundleName\":\"5GHomeGeminiSelfSetup\",\"id\":\"16900001\",\"type\":\"s\"},{\"bundleName\":\"5GHomeGeminiProfSetup\",\"id\":\"16900002\",\"type\":\"p\"}],\"launchType\":\"FCL\",\"addressType\":\"SFU\",\"eventCorrelationId\":\"07920_1681659493775_193\",\"floorPlanAvailable\":false,\"uberPinEligible\":false,\"fiosQualified\":false,\"gigqualified\":false,\"hashedlocationId\":\"5cc25e41e96a2558b2b0d98029e6302fa204bdff3e4ad52c6cc0d6c264d77fe6\",\"hashedLocusId\":\"5cc25e41e96a2558b2b0d98029e6302fa204bdff3e4ad52c6cc0d6c264d77fe6\",\"subLocationId\":\"300512786823\",\"networkBandwidthType\":\"mmw\",\"moveQualified\":false,\"existingFWA\":false,\"existingMobility\":false,\"recordIdentifier\":\"4700\",\"addressValid\":\"true\",\"bulkQualAddressType\":\"BillAccount\",\"HSI\":false,\"qualifiedCBand\":false},\"statusCode\":\"00\",\"statusMessage\":\"Service Completed Successfully\"}";
        Check5GAvailabilityRedisResponse bulkAddressQualificationRedisResponseRestart = mapper.readValue(responseRestart, Check5GAvailabilityRedisResponse.class);
        when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(bulkAddressQualificationRedisResponseRestart));
        StepVerifier.create(redisHelper3.getBulkQualificationAddressFromRedis(addPlanAndDeviceUIRequestRestart)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        String requestResume = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"action\":\"Resume\",\"intendType\":\"AAL_5G\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\",\"bulkQualIndicator\":\"Y\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
        AddPlanAndDeviceUIRequest addPlanAndDeviceUIRequestResume = mapper.readValue(requestResume, AddPlanAndDeviceUIRequest.class);
        String responseResume = "{\"output\":{\"qualified\":true,\"qualified4GHome\":false,\"aqCaseId\":\"AQ-11824790-E01\",\"addressLine1\":\"1 VERIZON WAY\",\"streetNumber\":\"1\",\"streetName\":\"VERIZON\",\"streetType\":\"WAY\",\"city\":\"BASKING RIDGE\",\"state\":\"NJ\",\"zipCode\":\"07920\",\"bundleDetails\":[{\"bundleName\":\"5GHomeGeminiSelfSetup\",\"id\":\"16900001\",\"type\":\"s\"},{\"bundleName\":\"5GHomeGeminiProfSetup\",\"id\":\"16900002\",\"type\":\"p\"}],\"launchType\":\"FCL\",\"addressType\":\"SFU\",\"eventCorrelationId\":\"07920_1681659493775_193\",\"floorPlanAvailable\":false,\"uberPinEligible\":false,\"fiosQualified\":false,\"gigqualified\":false,\"hashedlocationId\":\"5cc25e41e96a2558b2b0d98029e6302fa204bdff3e4ad52c6cc0d6c264d77fe6\",\"hashedLocusId\":\"5cc25e41e96a2558b2b0d98029e6302fa204bdff3e4ad52c6cc0d6c264d77fe6\",\"subLocationId\":\"300512786823\",\"networkBandwidthType\":\"mmw\",\"moveQualified\":false,\"existingFWA\":false,\"existingMobility\":false,\"recordIdentifier\":\"4700\",\"addressValid\":\"true\",\"bulkQualAddressType\":\"BillAccount\",\"HSI\":false,\"qualifiedCBand\":false},\"statusCode\":\"00\",\"statusMessage\":\"Service Completed Successfully\"}";
        Check5GAvailabilityRedisResponse bulkAddressQualificationRedisResponseResume = mapper.readValue(responseResume, Check5GAvailabilityRedisResponse.class);
        when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(bulkAddressQualificationRedisResponseResume));
        StepVerifier.create(redisHelper3.getBulkQualificationAddressFromRedis(addPlanAndDeviceUIRequestResume)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        String requestUpdateInstallType = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"action\":\"updateInstallType\",\"intendType\":\"AAL_5G\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\",\"bulkQualIndicator\":\"Y\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
        AddPlanAndDeviceUIRequest addPlanAndDeviceUIRequestUpdateInstallType = mapper.readValue(requestUpdateInstallType, AddPlanAndDeviceUIRequest.class);
        String responseUpdateInstallType = "{\"output\":{\"qualified\":true,\"qualified4GHome\":false,\"aqCaseId\":\"AQ-11824790-E01\",\"addressLine1\":\"1 VERIZON WAY\",\"streetNumber\":\"1\",\"streetName\":\"VERIZON\",\"streetType\":\"WAY\",\"city\":\"BASKING RIDGE\",\"state\":\"NJ\",\"zipCode\":\"07920\",\"bundleDetails\":[{\"bundleName\":\"5GHomeGeminiSelfSetup\",\"id\":\"16900001\",\"type\":\"s\"},{\"bundleName\":\"5GHomeGeminiProfSetup\",\"id\":\"16900002\",\"type\":\"p\"}],\"launchType\":\"FCL\",\"addressType\":\"SFU\",\"eventCorrelationId\":\"07920_1681659493775_193\",\"floorPlanAvailable\":false,\"uberPinEligible\":false,\"fiosQualified\":false,\"gigqualified\":false,\"hashedlocationId\":\"5cc25e41e96a2558b2b0d98029e6302fa204bdff3e4ad52c6cc0d6c264d77fe6\",\"hashedLocusId\":\"5cc25e41e96a2558b2b0d98029e6302fa204bdff3e4ad52c6cc0d6c264d77fe6\",\"subLocationId\":\"300512786823\",\"networkBandwidthType\":\"mmw\",\"moveQualified\":false,\"existingFWA\":false,\"existingMobility\":false,\"recordIdentifier\":\"4700\",\"addressValid\":\"true\",\"bulkQualAddressType\":\"BillAccount\",\"HSI\":false,\"qualifiedCBand\":false},\"statusCode\":\"00\",\"statusMessage\":\"Service Completed Successfully\"}";
        Check5GAvailabilityRedisResponse bulkAddressQualificationRedisResponseUpdateInstallType = mapper.readValue(responseUpdateInstallType, Check5GAvailabilityRedisResponse.class);
        when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(bulkAddressQualificationRedisResponseUpdateInstallType));
        StepVerifier.create(redisHelper3.getBulkQualificationAddressFromRedis(addPlanAndDeviceUIRequestUpdateInstallType)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        Address address=new Address();
        address.setAddressLine1("");
        address.setAddressLine2("");
        address.setCity("");
        address.setState("");
        address.setZipCode("");
        addPlanAndDeviceUIRequestUpdateInstallType.getCartInfo().setAddressInfo(address);
        addPlanAndDeviceUIRequestUpdateInstallType.getCartInfo().setAddressRecordIdentifier("1234");
        BulkQualifiedAddressResponse bulkAddress=new BulkQualifiedAddressResponse();
        bulkAddress.setAddressLine1("");
        bulkAddress.setAddressLine2("");
        bulkAddress.setZipCode("");
        bulkAddress.setState("");
        bulkAddress.setCity("");
        bulkAddress.setEventCorrelationId("");
        bulkAddress.setStreetName("");
        bulkAddress.setStreetNumber("");
        bulkAddress.setStreetType("");
        bulkAddress.setRecordIdentifier("1234");
        bulkAddressQualificationRedisResponse.getOutput().getQualifiedAddressList().add(bulkAddress);
        when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(bulkAddressQualificationRedisResponse));
        StepVerifier.create(redisHelper3.getBulkQualificationAddressFromRedis(addPlanAndDeviceUIRequestUpdateInstallType)).
                assertNext(Assert::assertNotNull).expectComplete().verify();
    }

}
