package onevz.soe.cart.helper;

import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.cxp.feature.util.FeatureFlag;
import onevz.soe.cart.bpm.helper.CartServiceConfiguratorBpmHelper;
import onevz.soe.cart.bpm.service.CartServiceBPMServices;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.controller.advice.CartServiceExceptionHandler;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.model.bulkcartupdate.CreateBulkQuotePegaRequest;
import onevz.soe.cart.model.common.CartServiceServiceHeader;
import onevz.soe.cart.model.configurator.add.AddAllConfiguratorServiceBody;
import onevz.soe.cart.model.configurator.add.AddAllConfiguratorServiceResponse;
import onevz.soe.cart.responses.AddAllConfiguratorPEGAResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.requests.AddAllConfiguratorUIRequest;
import onevz.soe.cart.ui.responses.AddAllConfiguratorUIResponse;
import onevz.soe.cart.util.CartPegaRequestErrorsUtil;
import onevz.soe.exception.SOEErrorHolder;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.spring.web.filter.RequestAccessContext;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpCookie;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.ResourceUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = {CartServiceTestConfig.class})
public class CartConfiguratorHelperTest {

    @InjectMocks
    CartConfiguratorHelper cartConfiguratorHelper;
    @Mock
    CartServiceCxpHelper cxpHelper;

    @Mock
    FeatureFlag featureFlag;

    @Mock
    CradleHelper cradleHelper;

    @Mock
    CartServiceConfiguratorBpmHelper bpmHelper;
    @Mock
    CartServiceBPMServices cartServiceBPMServices;
    @Mock
    RedisHelper redisHelper;
    @Mock
    CartServiceExceptionHandler exHandler;
    @Autowired
    ObjectMapper objectMapper;
    @Mock
    SOELoginSessionBean sessionBean;

    @Before
    public void setUp() {
        RequestAccessContext.RequestAccess reqAccess = new RequestAccessContext.RequestAccess();
        reqAccess.getHeaders().add(CartConstants.CHANNEL_ID,"VZW-DOTCOM");
        RequestAccessContext.updateRequestData(reqAccess);
    }

    @Test
    public void testProcessBulkQuoteUpdate() throws IOException, SOEHTTPException {
        File file = ResourceUtils.getFile("classpath:data/addAllToCartConfigurator/request/successRequestFormatted.json");
        String expectedJson = new String(Files.readAllBytes(file.toPath()));
        AddAllConfiguratorUIRequest request = objectMapper.readValue(expectedJson, AddAllConfiguratorUIRequest.class);
        request.getData().getLines().get(0).setSelectedPromoId("123");
        AddAllConfiguratorUIResponse pegaResponse = new AddAllConfiguratorUIResponse();
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        header.setSessionId("SESSIONID");
        pegaResponse.setServiceHeader(header);
        AddAllConfiguratorServiceBody serviceBody = new AddAllConfiguratorServiceBody();
        AddAllConfiguratorServiceResponse serviceResponse = new AddAllConfiguratorServiceResponse();
        serviceBody.setServiceResponse(serviceResponse);
        pegaResponse.setServiceBody(serviceBody);
        CreateBulkQuotePegaRequest pegaRequest = new CreateBulkQuotePegaRequest();
        pegaRequest.setServiceBody(serviceBody);
        Mockito.when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
        Mockito.when(bpmHelper.addAllCartConfigurator(any())).thenReturn(Mono.just(pegaResponse));
        Mockito.when(featureFlag.isFeatureEnabled(any(),any(),any(),any())).thenReturn(Mono.just(Boolean.TRUE));
        Mockito.when(featureFlag.isFeatureEnabled(any(),any(),any(),anyBoolean())).thenReturn(Mono.just(Boolean.TRUE));
        Mockito.when(cradleHelper.isInFlowCart(any(),any())).thenReturn(Mono.just(Boolean.TRUE));
        Mockito.doNothing().when(cxpHelper).updateDLData(any(),any(),any(),any(),any(),any());
        Mockito.when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
        Mono<AddAllConfiguratorUIResponse> response = cartConfiguratorHelper.addToCartForConfigurator(request);
        StepVerifier.create(response).assertNext(Assertions::assertNotNull).expectComplete().verify();
        request.getData().getLines().get(0).setSelectedSedOfferId("sed1234");
        Mono<AddAllConfiguratorUIResponse> response2 = cartConfiguratorHelper.addToCartForConfigurator(request);
        StepVerifier.create(response2).assertNext(Assertions::assertNotNull).expectComplete().verify();
        request.getCartInfo().setIntendType("");
        Mono<AddAllConfiguratorUIResponse> response3 = cartConfiguratorHelper.addToCartForConfigurator(request);
        StepVerifier.create(response3).assertNext(Assertions::assertNotNull).expectComplete().verify();
        request.getData().getLines().get(0).setSelectedSedOfferId("");
        Mono<AddAllConfiguratorUIResponse> response4 = cartConfiguratorHelper.addToCartForConfigurator(request);
        StepVerifier.create(response4).assertNext(Assertions::assertNotNull).expectComplete().verify();
        request.getCartInfo().setIntendType(CartConstants.BYOD_LINE_ACTIVITY);
        Mono<AddAllConfiguratorUIResponse> response5 = cartConfiguratorHelper.addToCartForConfigurator(request);
        StepVerifier.create(response5).assertNext(Assertions::assertNotNull).expectComplete().verify();
        request.getCartInfo().setIntendType(CartConstants.NSE_BYOD_LINE_ACTIVITY);
        Mono<AddAllConfiguratorUIResponse> response6 = cartConfiguratorHelper.addToCartForConfigurator(request);
        StepVerifier.create(response6).assertNext(Assertions::assertNotNull).expectComplete().verify();


    }

    @Test
    public void testProcessBulkQuoteSOEHTTPExceptionUpdate() throws IOException, SOEHTTPException {
        File file = ResourceUtils.getFile("classpath:data/addAllToCartConfigurator/request/successRequestFormatted.json");
        String expectedJson = new String(Files.readAllBytes(file.toPath()));
        AddAllConfiguratorUIRequest request = objectMapper.readValue(expectedJson, AddAllConfiguratorUIRequest.class);
        AddAllConfiguratorUIResponse pegaResponse = new AddAllConfiguratorUIResponse();
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        header.setSessionId("SESSIONID");
        pegaResponse.setServiceHeader(header);
        AddAllConfiguratorServiceBody serviceBody = new AddAllConfiguratorServiceBody();
        AddAllConfiguratorServiceResponse serviceResponse = new AddAllConfiguratorServiceResponse();
        serviceBody.setServiceResponse(serviceResponse);
        pegaResponse.setServiceBody(serviceBody);
        CreateBulkQuotePegaRequest pegaRequest = new CreateBulkQuotePegaRequest();
        pegaRequest.setServiceBody(serviceBody);
        Mockito.when(featureFlag.isFeatureEnabled(any(),any(),any(),any())).thenReturn(Mono.just(Boolean.TRUE));
        Mockito.when(featureFlag.isFeatureEnabled(any(),any(),any(),anyBoolean())).thenReturn(Mono.just(Boolean.TRUE));
        Mockito.when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
        Mockito.when(bpmHelper.addAllCartConfigurator(any())).thenReturn(Mono.error(new SOEHTTPException(500, SOEErrorHolder.builder().errors(CartPegaRequestErrorsUtil.emptyCaptchaErrorresponse()).build())));
        Mockito.when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
        Mockito.when(cradleHelper.isInFlowCart(any(),any())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<AddAllConfiguratorUIResponse> response = cartConfiguratorHelper.addToCartForConfigurator(request);
        StepVerifier.create(response).assertNext(Assertions::assertNotNull).expectComplete().verify();
    }


}
