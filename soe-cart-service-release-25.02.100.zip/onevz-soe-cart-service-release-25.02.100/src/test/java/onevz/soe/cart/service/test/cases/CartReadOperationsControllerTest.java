package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.TextNode;
import onevz.cxp.feature.ConfigurationProfile;
import onevz.cxp.feature.Flag;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.constants.FeatureFlagConstants;
import onevz.soe.cart.controller.CartReadOperationsController;
import onevz.soe.cart.controller.CartReadOperationsController1;
import onevz.soe.cart.controller.CartReadOperationsController2;
import onevz.soe.cart.helper.*;
import onevz.soe.cart.model.addTrialContactInfoAndAddress.AddTrialContactInfoAndAddressUIRequest;
import onevz.soe.cart.model.addTrialContactInfoAndAddress.AddTrialContactInfoAndAddressUIResponse;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.common.Vzdl;
import onevz.soe.cart.model.deviceSimValidation.DeviceSimValidationUIResponseData;
import onevz.soe.cart.model.initiateESimActivation.InitiateESimActivationUIResponse;
import onevz.soe.cart.model.initiateESimActivation.IntiateESimActivationUIRequest;
import onevz.soe.cart.model.initiateValidateDeviceSim.InitiateValidateDeviceSimUIRequest;
import onevz.soe.cart.model.initiateValidateDeviceSim.InitiateValidateDeviceSimUIResponse;
import onevz.soe.cart.model.retrieveCart.*;
import onevz.soe.cart.model.validateCart.CXPValidateCartDataVO;
import onevz.soe.cart.requests.AbandonCartSOERequest;
import onevz.soe.cart.requests.RetrieveCartCXPRequest;
import onevz.soe.cart.requests.RetrieveCartPlanbuilderRequest;
import onevz.soe.cart.requests.ValidateCartCXPRequest;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.cart.util.CartUtil;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.exception.SOEError;
import onevz.soe.omnidl.util.DLUtilityService;
import onevz.soe.security.TokenProcessor;
import onevz.soe.security.util.ReCaptchaUtil;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.*;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.http.server.reactive.MockServerHttpResponse;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.MultiValueMapAdapter;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;
import java.io.IOException;
import java.net.URI;
import java.util.*;
import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@RunWith(SpringJUnit4ClassRunner.class)
@WebFluxTest(CartReadOperationsController.class)
public class CartReadOperationsControllerTest {

    @Autowired
    SourceFileReaderUtil sourceFileReaderUtil;
    @MockBean
    private UpdateCartHelper cartHelper;
    @MockBean
    private ReadCartHelper readCartHelper;
    @MockBean
    private ReCaptchaUtil reCaptchaUtil;
    @Autowired
    private CartReadOperationsController cartController;
    @Autowired
    private CartReadOperationsController1 cartController1;
    @Autowired
    private CartReadOperationsController2 cartController2;

    @Autowired
    private ObjectMapper mapper;
    @MockBean
    private RedisHelper redisHelper;
    @MockBean
    private RedisHelper2 redisHelper2;
    @MockBean
    private RedisHelper3 redisHelper3;
    @MockBean
    private DLUtilityService dlUtilityService;
    @MockBean
    private TokenProcessor tokenProcessor;
    @MockBean
    private CradleHelper cradleHelper;
    @Value("${onevz.soe.cart.test.fileLocation}")
    private String testFileLocation;

    @MockBean
    private CollaborationCodeHelper collaborationCodeHelper;

    @MockBean
    private RetrieveCartHelper retrieveCartHelper;
    @MockBean
    private FeatureFlagHelper featureFlagHelper;

    @MockBean
    private OmniDLHelper omniDLHelper;

    @MockBean
    CartAddDeviceHelper cartAddDeviceHelper;
    @MockBean
    private CartUtil cartUtilHelper;
    @MockBean
    private Vzdl vzdl;

    @MockBean
    HttpHeaders headers;

    @Before
    public void before(){
        Flag flag = new Flag();
        Map<String, Flag> flags = new HashMap<>();
        flags.put(FeatureFlagConstants.BYOD_PROFILE_DEVICE_VALIDATION_FEATURE_FLAGS,flag);
        Mockito.when(featureFlagHelper.fetchDigitaByodProfile(Mockito.any())).thenReturn(Mono.just(flags));
    }

    @Test
    public void initiateCbandCheckErrorTest() throws IOException {
        String requestString = "{\"flowType\":\"imsi\",\"imsi\":\"311480589646564\"}";
        String responseString = "{\"errors\": [{\"namespace\": \"cxp-customerprofile-services\",\"name\": \"VALIDATION_ERROR\",\"id\": \"3000\",\"debug_id\": \"2022-02-23T11:52:44.+0530:b0b037cb-3965-4f16-a960-ad2b9738ec9a:VIN0019ALTVTWSG:customerprofile:local\",\"message\": \"Imsi/Mtn is null or Empty\",\"category\":\"VALIDATION_ERR\",\"details\": [{\"field\": \"Imsi/Mtn\", \"value\": \"\", \"issue\": \"Imsi/Mtn is null or Empty\", \"location\": \"data\"}]}]}";
        InitiateCbandCheckUIRequest request = mapper.readValue(requestString, InitiateCbandCheckUIRequest.class);
        InitiateCbandCheckUIResponse response = mapper.readValue(responseString, InitiateCbandCheckUIResponse.class);
        URI url = URI.create("http://localhost/nse/initiateCbandCheck");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(readCartHelper.initiateCbandCheck(Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.initiateCbandCheck(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }


    @Test
    public void initiateValidateDeviceSimTest() throws IOException {
        String requestString = "{\"data\": {\"postPaidInd\": \"Y\",\"processStep\": \"\",\"processAction\": \"initiateValidateDeviceSim\",\"intendType\": \"BYOD\"}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM-BBP\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.08.30.22.03.03-723.8675611225624\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1897\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ValidateDeviceSimIdPage\"}],\"pendingOrderAccountLevel\":\"false\",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ValidateDeviceSimIdPage\",\"processAction\":\"\",\"pastDueBalance\":\"false\",\"intent\":\"BYOD\"},\"customerInfo\":{\"accountNumber\":\"0425770466-00001\",\"cartCreator\":\"7067413559\",\"processingMTN\":\"\",\"registerNumber\":0,\"deviceType\":\"\",\"existingCase\":\"\",\"lastUpdateDateTime\":\"20220830T220323.148 GMT\"},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"lcjfjjhd\",\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"customerConsent\":\"N\"},\"deviceInfo\":{\"simInfo\":{\"iccid\":\"89148000007772776981\",\"mfgCode\":\"GTO\",\"launchPackageSku\":\"VZW180000020002\",\"prodName\":\"Gemalto Test eUICC-Type S\",\"preferredSoftSim\":\"TESTeSIM-S-M2M-A\",\"launchPackageSkuType\":\"VZW180000020002\",\"pairedIccid\":\"\",\"type\":\"4GS\",\"mtn\":\"4043139197\",\"mobileNumber\":\"\",\"active\":false,\"aging\":false,\"available\":false,\"retired\":false,\"grandFathered\":false,\"status\":\"\",\"euimid\":\"\",\"imsiv\":\"\",\"imsivf\":\"\",\"iccIdStat\":\"\",\"min\":\"4042138526\",\"ispuCompatibleSIM\":\"\",\"dfillCompatibleSim\":\"DFILLSIM5G-SA-A\",\"esimid\":\"\",\"eID\":\"\"},\"deviceSimCompatible\":\"Y\",\"deviceSimM2MPair\":\"N\",\"deviceESimCompatible\":\"\",\"deviceESimM2MPair\":\"Y\",\"deviceId\":\"351998103873774\",\"color\":{\"colorId\":\"\",\"displayName\":\"\",\"description\":\"\",\"colorCssStyle\":\"\"},\"imageName\":\"\",\"imageUrlMap\":{\"defaultImage\":\"\",\"largeImage\":\"\",\"mediumImage\":\"\",\"miniImage\":\"\",\"thumbImage\":\"\"},\"skuDisplayName\":\"Lamborghini\",\"deviceSku\":\"VZW180000020002\",\"isRestrictedDevice\":\"N\",\"deviceAttributes\":{\"mfgCode\":\"ODI\",\"mfgName\":\"ODI Device\",\"prodName\":\"HARMAN INTERN - CONBOX-HIGH\",\"prodType\":\"4GCONNECTEDCARS\",\"equipModeCode\":\"4GE\",\"equipMode\":\"4G\",\"gpsIndicator\":\"Y\",\"daccCode\":\"01128\",\"deviceType\":\"4GO\",\"deviceCategory\":\"Connected Car\",\"productId\":\"46067\",\"postpaidRestrictStartDate\":\"\",\"prepayRestrictStartDate\":\"\",\"wholesaleRestrictStartDate\":\"\"},\"lostAndStolen\":{\"lostStolen\":\"N\",\"nonPay\":\"N\"},\"numbershareCapability\":\"N\",\"price\":{\"fullRetailPrice\":{\"contractText\":\"\"},\"oneYearPrice\":{\"contractText\":\"\"},\"devicePaymentPrice\":[]},\"skipSimIdFlag\":true,\"appleWatchFlag\":false,\"fmipLocked\":false,\"appleCarrieLock\":false,\"e911AddrInd\":\"N\",\"simClass4G\":\"NR\",\"makeEtniPersApi\":false,\"softMessages\":[],\"standalonePairingEligible\":true,\"deviceFamilyType\":\"Connected\",\"osType\":\"\",\"euiccCapable\":\"Y\",\"imei1\":\"\",\"imei2\":\"\",\"oemMDN\":\"4043139197\",\"brandName\":\"Lamborghini\",\"brandType\":\"CAR\",\"oemECPDID\":\"5942501\",\"oemCustomerId\":\"742402217\",\"oemBillAccountNumber\":\"3\",\"serviceId\":\"\",\"oemTrialSupportNumber\":\"\",\"oemServiceId\":\"22675\",\"oemProductBundleId\":\"259970\",\"oemStageStateActivityId\":\"20190\",\"oemSeqNum\":\"1\",\"cCARWifiState\":\"PRE_TRIAL\",\"cCarTrialflag\":\"Y\",\"cCarSecureWifiFlag\":\"N\",\"cCARMessageNumber\":\"00\"}}}},\"deviceType\":\"CONNECTED_CAR\",\"greetingName\":\"JACK\"}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"bbpImei\": \"8436667390\",\"bbpIccid\":\"89148000005148869944\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        InitiateValidateDeviceSimUIRequest request = mapper.readValue(requestString, InitiateValidateDeviceSimUIRequest.class);
        InitiateValidateDeviceSimUIResponse response = mapper.readValue(responseString, InitiateValidateDeviceSimUIResponse.class);
        URI url = URI.create("http://localhost/initiateValidateDeviceSim");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("accountNumber", "0380416061-00001").build();
        ServerHttpResponse httpResponse = null;
        when(redisHelper2.upsertValueInRedis(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(cartHelper.customerNameByMtn(Mockito.any())).thenReturn(Mono.just(response));
        when(cartHelper.initiateValidateDeviceSim(request, httpHeader, sampleRedisData)).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController1.initiateValidateDeviceSim(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void initiateValidateDeviceSimMobileSecureRoleTest() throws IOException {
        String requestString = "{\"data\": {\"postPaidInd\": \"Y\",\"processStep\": \"\",\"processAction\": \"initiateValidateDeviceSim\",\"intendType\": \"BYOD\"}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM-BBP\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.05.06.05.26.37-464.97529221856246\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4037290-C01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ValidateDeviceSimIdPage\"},{\"path\":\"ValidateDeviceSimIdPage\"}],\"pendingOrderAccountLevel\":\"false\",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"\",\"processAction\":\"\",\"pastDueBalance\":\"false\",\"intent\":\"BYOD\"},\"customerInfo\":{\"accountNumber\":\"0001213359-00001\",\"cartCreator\":\"4107035075\",\"processingMTN\":\"\",\"registerNumber\":0,\"deviceType\":\"\",\"existingCase\":\"\",\"lastUpdateDateTime\":\"20220506T052641.235 GMT\"},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"8737785a-3d9d-40b5-a813-caea12306563\",\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"customerConsent\":\"N\"}}}},\"greetingName\":\"RYAN\",\"deviceType\":\"CONNECTED_CAR\"}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"bbpImei\": \"8436667390\", \"role\": \"mobileSecure\"}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        InitiateValidateDeviceSimUIRequest request = mapper.readValue(requestString, InitiateValidateDeviceSimUIRequest.class);
        InitiateValidateDeviceSimUIResponse response = mapper.readValue(responseString, InitiateValidateDeviceSimUIResponse.class);
        URI url = URI.create("http://localhost/initiateValidateDeviceSim");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("accountNumber", "0380416061-00001").build();
        ServerHttpResponse httpResponse = null;
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(cartHelper.customerNameByMtn(Mockito.any())).thenReturn(Mono.just(response));
        when(cartHelper.initiateValidateDeviceSim(request, httpHeader, sampleRedisData)).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController1.initiateValidateDeviceSim(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void initiateValidateDeviceSimInvalidCustomerTest() throws IOException {
        String requestString = "{\"data\": {\"postPaidInd\": \"Y\",\"processStep\": \"\",\"processAction\": \"initiateValidateDeviceSim\",\"intendType\": \"BYOD\"}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM-BBP\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.05.06.05.26.37-464.97529221856246\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4037290-C01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ValidateDeviceSimIdPage\"},{\"path\":\"ValidateDeviceSimIdPage\"}],\"pendingOrderAccountLevel\":\"false\",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"\",\"processAction\":\"\",\"pastDueBalance\":\"false\",\"intent\":\"BYOD\"},\"customerInfo\":{\"accountNumber\":\"0001213359-00001\",\"cartCreator\":\"4107035075\",\"processingMTN\":\"\",\"registerNumber\":0,\"deviceType\":\"\",\"existingCase\":\"\",\"lastUpdateDateTime\":\"20220506T052641.235 GMT\"},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"8737785a-3d9d-40b5-a813-caea12306563\",\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"customerConsent\":\"N\"}}}},\"greetingName\":\"RYAN\",\"deviceType\":\"CONNECTED_CAR\"}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"bbpImei\": \"8436667390\",\"isValidCustomer\": \"false\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        InitiateValidateDeviceSimUIRequest request = mapper.readValue(requestString, InitiateValidateDeviceSimUIRequest.class);
        InitiateValidateDeviceSimUIResponse response = mapper.readValue(responseString, InitiateValidateDeviceSimUIResponse.class);
        URI url = URI.create("http://localhost/initiateValidateDeviceSim");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("accountNumber", "0380416061-00001").build();
        ServerHttpResponse httpResponse = null;
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(cartHelper.customerNameByMtn(Mockito.any())).thenReturn(Mono.just(response));
        when(cartHelper.initiateValidateDeviceSim(request, httpHeader, sampleRedisData)).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController1.initiateValidateDeviceSim(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void initiateValidateDeviceSimErrorTest() throws IOException {
        String requestString = "{\"data\":{\"postPaidInd\":null,\"processStep\":\"\",\"processAction\":\"initiateValidateDeviceSim\",\"intendType\":null}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM-BBP\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.05.06.05.26.37-464.97529221856246\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4037290-C01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ValidateDeviceSimIdPage\"},{\"path\":\"ValidateDeviceSimIdPage\"}],\"pendingOrderAccountLevel\":\"false\",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"\",\"processAction\":\"\",\"pastDueBalance\":\"false\",\"intent\":\"BYOD\"},\"customerInfo\":{\"accountNumber\":\"0001213359-00001\",\"cartCreator\":\"4107035075\",\"processingMTN\":\"\",\"registerNumber\":0,\"deviceType\":\"\",\"existingCase\":\"\",\"lastUpdateDateTime\":\"20220506T052641.235 GMT\"},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"8737785a-3d9d-40b5-a813-caea12306563\",\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"customerConsent\":\"N\"}}}},\"greetingName\":\"RYAN\",\"deviceType\":\"CONNECTED_CAR\"}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"bbpImei\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        InitiateValidateDeviceSimUIRequest request = mapper.readValue(requestString, InitiateValidateDeviceSimUIRequest.class);
        InitiateValidateDeviceSimUIResponse response = mapper.readValue(responseString, InitiateValidateDeviceSimUIResponse.class);
        URI url = URI.create("http://localhost/initiateValidateDeviceSim");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("accountNumber", "0380416061-00001").build();
        ServerHttpResponse httpResponse = null;
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(cartHelper.customerNameByMtn(Mockito.any())).thenReturn(Mono.just(response));
        when(cartHelper.initiateValidateDeviceSim(request, httpHeader, sampleRedisData)).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController1.initiateValidateDeviceSim(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void initiateValidateDeviceSimSLCustomerTest() throws IOException {
        String requestString = "{\"data\":{\"postPaidInd\":\"Y\",\"processStep\":\"\",\"processAction\":\"initiateValidateDeviceSim\",\"intendType\":\"BYOD\"}}";
        String responseString = "{\"errors\":[{\"namespace\":\"CartService\",\"id\":\"C1003\",\"name\":\"API_ERROR\"}]}";
        String redisDataString = "{ \"cartId\": \"fa49745e-0fad-473d-80c0-4faf5206fc89\", \"caseId\": \"SOP2-16734-E01\", \"accountNumber\": \"0225411179-00001\", \"mtn\": \"8327764187\", \"bbpImei\": \"352584072536367\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        InitiateValidateDeviceSimUIRequest request = mapper.readValue(requestString, InitiateValidateDeviceSimUIRequest.class);
        InitiateValidateDeviceSimUIResponse response = mapper.readValue(responseString, InitiateValidateDeviceSimUIResponse.class);
        URI url = URI.create("http://localhost/initiateValidateDeviceSim");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("accountNumber", "0380416061-00001").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(cartHelper.customerNameByMtn(Mockito.any())).thenReturn(Mono.just(response));
        when(cartHelper.initiateValidateDeviceSim(request, httpHeader, sampleRedisData)).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController1.initiateValidateDeviceSim(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        sampleRedisData.setIsValidCustomer(false);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        StepVerifier.create(cartController1.initiateValidateDeviceSim(httpHeader, httpResponse, request)).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addTrialContactInfoTest() throws IOException {
        String requestString = "{\"data\":{\"processStep\": \"ContactInfo\",\"processAction\": \"addTrailContactInfo\",\"intendType\": \"BYOD\",\"intent\" : \"BYOD\",\"itemType\": \"TRIALADDRESS\",\"isAccountInfoUpdation\":\"true\",\"trialContactInfo\": {\"firstName\":\"JAMES\",\"lastName\":\"SMITH\",\"emailId\":\"JAMES.SMITH@VERIZONWIRELESS.COM\",\"phoneNumber\":\"9492866651\"},\"trialAddress\": null}}}";
        String responseString = "{\r\n" +
                "    \"serviceHeader\": {\r\n" +
                "        \"clientId\": \"VZW-DOTCOM-BBP\",\r\n" +
                "        \"statusMsg\": \"PEGA generated message\",\r\n" +
                "        \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\r\n" +
                "        \"sessionId\": \"\",\r\n" +
                "        \"serviceName\": \"SalesOrderPurchase\",\r\n" +
                "        \"userId\": \"\",\r\n" +
                "        \"statusCode\": \"0\"\r\n" +
                "    },\r\n" +
                "    \"serviceBody\": {\r\n" +
                "        \"serviceResponse\": {\r\n" +
                "            \"context\": {\r\n" +
                "                \"caseId\": \"SOP-1583186-DEV3\",\r\n" +
                "                \"customerInfo\": {\r\n" +
                "                    \"accountNumber\": \"07893451230-00001\",\r\n" +
                "                    \"cartCreator\": \"2515813861\",\r\n" +
                "                    \"processingMTN\": \"2515813860\"\r\n" +
                "                },\r\n" +
                "                \"processMTNList\": [\r\n" +
                "                    {\r\n" +
                "                        \"mtn\": \"2515813860\",\r\n" +
                "                        \"completedprocessSteps\": [\r\n" +
                "                            \"Initiate\",\r\n" +
                "                            \"BYODeviceIDPage\",\r\n" +
                "                            \"PlanSelection\"\r\n" +
                "                        ]\r\n" +
                "                    }\r\n" +
                "                ],\r\n" +
                "                \"cartInfo\": {\r\n" +
                "                    \"effectiveDateDetails\": {\r\n" +
                "                        \"suggestedBackDate\": null,\r\n" +
                "                        \"suggestedFutureDate\": null,\r\n" +
                "                        \"currentBillCycleBeginDate\": null,\r\n" +
                "                        \"currentBillCycleEndDate\": null,\r\n" +
                "                        \"nextBillCycleBeginDate\": null,\r\n" +
                "                        \"nextBillCycleEndDate\": null,\r\n" +
                "                        \"onDemandDate\": null,\r\n" +
                "                        \"onDemandRangeInDays\": null,\r\n" +
                "                        \"selectedDate\": \"\",\r\n" +
                "                        \"onDemandOverageInd\": null,\r\n" +
                "                        \"isOnDemandAllowed\": false,\r\n" +
                "                        \"isBackDateAllowed\": false,\r\n" +
                "                        \"isFutureDateAllowed\": false,\r\n" +
                "                        \"onDemandAllowed\": false,\r\n" +
                "                        \"backDateAllowed\": false,\r\n" +
                "                        \"futureDateAllowed\": false\r\n" +
                "                    },\r\n" +
                "                    \"cartId\": \"\",\r\n" +
                "                    \"statusCode\": 1,\r\n" +
                "                    \"statusMsg\": \"Trail Info Updated Successfully\"\r\n" +
                "                },\r\n" +
                "                \"contextInfo\": {\r\n" +
                "                    \"processAction\": \"\",\r\n" +
                "                    \"callReason\": \" SalesOrderPurchase\",\r\n" +
                "                    \"processStep\": \"AccountReview\",\r\n" +
                "                    \"availablePaths\": [\r\n" +
                "                        {\r\n" +
                "                            \"path\": \"CustomerAgreement\"\r\n" +
                "                        }\r\n" +
                "                    ]\r\n" +
                "                }\r\n" +
                "            }\r\n" +
                "        }\r\n" +
                "    }\r\n" +
                "}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\"}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddTrialContactInfoAndAddressUIRequest request = mapper.readValue(requestString, AddTrialContactInfoAndAddressUIRequest.class);
        AddTrialContactInfoAndAddressUIResponse response = mapper.readValue(responseString, AddTrialContactInfoAndAddressUIResponse.class);
        URI url = URI.create("http://localhost/addTrialContactInfoAndAddress");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(readCartHelper.addTrialContactInfoAndAddress(Mockito.any(), Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController1.addTrialContactInfoAndAddress(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
        httpResponse.setStatusCode(HttpStatus.OK);
        response.setErrors(Arrays.asList(new CartError[]{new CartError()}));
        when(readCartHelper.addTrialContactInfoAndAddress(Mockito.any(), Mockito.any())).thenReturn(Mono.just(response));
        StepVerifier.create(cartController1.addTrialContactInfoAndAddress(httpHeader, httpResponse, request)).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addTrialContactInfoTest1() throws IOException {
        String requestString = "{\n" +
                "    \"data\": {\n" +
                "        \"processStep\": \"ContactInfo\",\n" +
                "        \"processAction\": \"addTrailContactInfo\",\n" +
                "        \"intendType\": \"BYOD\",\n" +
                "        \"intent\": \"BYOD\",\n" +
                "        \"itemType\": \"TRIALADDRESS\",\n" +
                "        \"isAccountInfoUpdation\": \"true\",\n" +
                "        \"trialContactInfo\": {\n" +
                "            \"firstName\": \"JAMES\",\n" +
                "            \"lastName\": \"SMITH\",\n" +
                "            \"emailId\": \"JAMES.SMITH@VERIZONWIRELESS.COM\",\n" +
                "            \"phoneNumber\": \"9492866651\"\n" +
                "        },\n" +
                "        \"trialAddress\": null\n" +
                "    }\n" +
                "}";
        String responseString = "{\"errors\":[{\"name\":\"Application Error\",\"id\":\"3259\",\"message\":\"Looks like something went wrong. Give us a call at 1.800.922.0204 and we'll help you complete your transaction.\"}]}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\"}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddTrialContactInfoAndAddressUIRequest request = mapper.readValue(requestString, AddTrialContactInfoAndAddressUIRequest.class);
        AddTrialContactInfoAndAddressUIResponse response = mapper.readValue(responseString, AddTrialContactInfoAndAddressUIResponse.class);
        URI url = URI.create("http://localhost/addTrialContactInfoAndAddress");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(readCartHelper.addTrialContactInfoAndAddress(Mockito.any(), Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController1.addTrialContactInfoAndAddress(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void addTrialContactInfoTest2() throws IOException {
        String requestString = "{\n" +
                "    \"data\": {\n" +
                "        \"processStep\": \"ContactInfo\",\n" +
                "        \"processAction\": \"addTrailContactInfo\",\n" +
                "        \"intendType\": null,\n" +
                "        \"intent\": null,\n" +
                "        \"itemType\": \"TRIALADDRESS\",\n" +
                "        \"isAccountInfoUpdation\": \"true\",\n" +
                "        \"trialContactInfo\": {\n" +
                "            \"firstName\": \"JAMES\",\n" +
                "            \"lastName\": \"SMITH\",\n" +
                "            \"emailId\": \"JAMES.SMITH@VERIZONWIRELESS.COM\",\n" +
                "            \"phoneNumber\": \"9492866651\"\n" +
                "        },\n" +
                "        \"trialAddress\": null\n" +
                "    }\n" +
                "}";
        String responseString = "{\"errors\":[{\"name\":\"Application Error\",\"id\":\"3259\",\"message\":\"Looks like something went wrong. Give us a call at 1.800.922.0204 and we'll help you complete your transaction.\"}]}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\"}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddTrialContactInfoAndAddressUIRequest request = mapper.readValue(requestString, AddTrialContactInfoAndAddressUIRequest.class);
        AddTrialContactInfoAndAddressUIResponse response = mapper.readValue(responseString, AddTrialContactInfoAndAddressUIResponse.class);
        URI url = URI.create("http://localhost/addTrialContactInfoAndAddress");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(readCartHelper.addTrialContactInfoAndAddress(Mockito.any(), Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController1.addTrialContactInfoAndAddress(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
        request.getData().setIntendType("random");
        request.getData().setIntent("random");
        request.getData().setProcessAction("random");
        request.getData().setProcessStep("random");
        httpResponse.setStatusCode(HttpStatus.OK);
        response.setErrors(null);
        when(readCartHelper.addTrialContactInfoAndAddress(Mockito.any(), Mockito.any())).thenReturn(Mono.just(response));
        httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("random", "VZW-DOTCOM").build();
        StepVerifier.create(cartController1.addTrialContactInfoAndAddress(httpHeader, httpResponse, request)).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        request.setData(null);
        StepVerifier.create(cartController1.addTrialContactInfoAndAddress(httpHeader, httpResponse, request)).expectError();
        StepVerifier.create(cartController1.addTrialContactInfoAndAddress(httpHeader, httpResponse, null)).expectError();
    }

    @Test
    public void addTrialAddressTest() throws IOException {
        String requestString = "{\"data\":{\"processStep\": \"ContactInfo\",\"processAction\": \"addTrailContactInfo\",\"intendType\": \"BYOD\",\"intent\" : \"BYOD\",\"itemType\": \"TRIALADDRESS\",\"isAccountInfoUpdation\":\"true\",\"trialAddress\": {\"addressLine1\":\"201 CENTENNIAL AVE\",\"addressLine2\":\"0795694511/4800074391\",\"zipCode\":\"08854\",\"city\":\"PISCATAWAY\",\"state\":\"NJ\"},\"trialContactInfo\": null}}}";
        String responseString = "{\r\n" +
                "    \"serviceHeader\": {\r\n" +
                "        \"clientId\": \"VZW-DOTCOM-BBP\",\r\n" +
                "        \"statusMsg\": \"PEGA generated message\",\r\n" +
                "        \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\r\n" +
                "        \"sessionId\": \"\",\r\n" +
                "        \"serviceName\": \"SalesOrderPurchase\",\r\n" +
                "        \"userId\": \"\",\r\n" +
                "        \"statusCode\": \"0\"\r\n" +
                "    },\r\n" +
                "    \"serviceBody\": {\r\n" +
                "        \"serviceResponse\": {\r\n" +
                "            \"context\": {\r\n" +
                "                \"caseId\": \"SOP-1583186-DEV3\",\r\n" +
                "                \"customerInfo\": {\r\n" +
                "                    \"accountNumber\": \"07893451230-00001\",\r\n" +
                "                    \"cartCreator\": \"2515813861\",\r\n" +
                "                    \"processingMTN\": \"2515813860\"\r\n" +
                "                },\r\n" +
                "                \"processMTNList\": [\r\n" +
                "                    {\r\n" +
                "                        \"mtn\": \"2515813860\",\r\n" +
                "                        \"completedprocessSteps\": [\r\n" +
                "                            \"Initiate\",\r\n" +
                "                            \"BYODeviceIDPage\",\r\n" +
                "                            \"PlanSelection\"\r\n" +
                "                        ]\r\n" +
                "                    }\r\n" +
                "                ],\r\n" +
                "                \"cartInfo\": {\r\n" +
                "                    \"effectiveDateDetails\": {\r\n" +
                "                        \"suggestedBackDate\": null,\r\n" +
                "                        \"suggestedFutureDate\": null,\r\n" +
                "                        \"currentBillCycleBeginDate\": null,\r\n" +
                "                        \"currentBillCycleEndDate\": null,\r\n" +
                "                        \"nextBillCycleBeginDate\": null,\r\n" +
                "                        \"nextBillCycleEndDate\": null,\r\n" +
                "                        \"onDemandDate\": null,\r\n" +
                "                        \"onDemandRangeInDays\": null,\r\n" +
                "                        \"selectedDate\": \"\",\r\n" +
                "                        \"onDemandOverageInd\": null,\r\n" +
                "                        \"isOnDemandAllowed\": false,\r\n" +
                "                        \"isBackDateAllowed\": false,\r\n" +
                "                        \"isFutureDateAllowed\": false,\r\n" +
                "                        \"onDemandAllowed\": false,\r\n" +
                "                        \"backDateAllowed\": false,\r\n" +
                "                        \"futureDateAllowed\": false\r\n" +
                "                    },\r\n" +
                "                    \"cartId\": \"\",\r\n" +
                "                    \"statusCode\": 1,\r\n" +
                "                    \"statusMsg\": \"Trail Info Updated Successfully\"\r\n" +
                "                },\r\n" +
                "                \"contextInfo\": {\r\n" +
                "                    \"processAction\": \"\",\r\n" +
                "                    \"callReason\": \" SalesOrderPurchase\",\r\n" +
                "                    \"processStep\": \"TrialAddress\",\r\n" +
                "                    \"availablePaths\": [\r\n" +
                "                        {\r\n" +
                "                            \"path\": \"TrialAddress\"\r\n" +
                "                        }\r\n" +
                "                    ]\r\n" +
                "                }\r\n" +
                "            }\r\n" +
                "        }\r\n" +
                "    }\r\n" +
                "}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddTrialContactInfoAndAddressUIRequest request = mapper.readValue(requestString, AddTrialContactInfoAndAddressUIRequest.class);
        AddTrialContactInfoAndAddressUIResponse response = mapper.readValue(responseString, AddTrialContactInfoAndAddressUIResponse.class);
        URI url = URI.create("http://localhost/addTrialContactInfoAndAddress");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(readCartHelper.addTrialContactInfoAndAddress(Mockito.any(), Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController1.addTrialContactInfoAndAddress(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void getPairedWatchesTest() throws IOException {
        String requestString = "{\"intendType\":\"NSE\",\"mtnFlow\":\"P\",\"mtn\":\"6096774455\",\"mldTrunkMtn\":\"6096774455\"}";
        String responseString = "{\"payload\":{\"numberSharePairedWatches\":[]},\"meta\":{\"timestamp\":\"1652085573096\",\"cxpCorrelationId\":\"2022-05-09T08:39:33.+0000:b79e6d47-543a-40e9-bc27-412c8f865da7:cxp-shopping-services-qa-ev6v-sit2w-nscxp-5b78847c8b-rgfbq:nssit2\"}}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        GetPairedDevicesUIRequest request = mapper.readValue(requestString, GetPairedDevicesUIRequest.class);
        GetPairedDevicesUIResponse response = mapper.readValue(responseString, GetPairedDevicesUIResponse.class);
        URI url = URI.create("http://localhost/getPairedWatches");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(cartHelper.getPairedDevices(Mockito.any(), Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.getPairedWatches(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
        response.setErrors(new CartError[]{new CartError()});
        when(cartHelper.getPairedDevices(Mockito.any(), Mockito.any())).thenReturn(Mono.just(response));
        StepVerifier.create(cartController2.getPairedWatches(httpHeader, httpResponse, request)).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void getPairedWatchesErrorTest() throws IOException {
        String requestString = "{\"intendType\":\"NSE\",\"mtnFlow\":\"P\",\"mtn\":\"6096774455\",\"mldTrunkMtn\":\"6096774455\"}";
        String responseString = "{\"errors\":[{\"name\":\"Down stream error\",\"code\":\"400\",\"id\":\"1003\",\"message\":\"Looks like something went wrong. Give us a call at 1.800.922.0204 and we'll help you complete your transaction.\"}]}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        GetPairedDevicesUIRequest request = mapper.readValue(requestString, GetPairedDevicesUIRequest.class);
        GetPairedDevicesUIResponse response = mapper.readValue(responseString, GetPairedDevicesUIResponse.class);
        URI url = URI.create("http://localhost/getPairedWatches");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        when(cartHelper.getPairedDevices(Mockito.any(), Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.getPairedWatches(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void initiateESimActivationTest() throws IOException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"esimType\":\"Ipad\",\"handOffToken\":\"\",\"imei\":\"\",\"eid\":\"\"}";
        String responseString = "{\"data\":{\"eid\":\"1234\",\"deviceId\":\"1234\",\"iccId\":\"2345\"}}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\",\"eid\": \"8436667390\",\"imei\": \"8436667390\",\"handOffToken\": \"2e839yery\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        IntiateESimActivationUIRequest request = mapper.readValue(requestString, IntiateESimActivationUIRequest.class);
        InitiateESimActivationUIResponse response = mapper.readValue(responseString, InitiateESimActivationUIResponse.class);
        URI url = URI.create("http://localhost/initiateESimActivation");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(cartHelper.initiateESimActivation(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper2.upsertInitiateESimActivation(Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.initiateESimActivation(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
        httpResponse.setStatusCode(HttpStatus.OK);
        response.setErrors(Arrays.asList(new CartError[]{new CartError()}));
        when(cartHelper.initiateESimActivation(Mockito.any())).thenReturn(Mono.just(response));
        StepVerifier.create(cartController2.initiateESimActivation(httpHeader, httpResponse, request)).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        sampleRedisData.setHandOffToken(null);
        sampleRedisData.setImei(null);
        sampleRedisData.setEid(null);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        StepVerifier.create(cartController2.initiateESimActivation(httpHeader, httpResponse, request)).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        request.setHandOffToken(null);
        StepVerifier.create(cartController2.initiateESimActivation(httpHeader, httpResponse, request)).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        request = mapper.readValue(requestString, IntiateESimActivationUIRequest.class);
        request.setImei(null);
        request.setHandOffToken("random");
        StepVerifier.create(cartController2.initiateESimActivation(httpHeader, httpResponse, request)).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        request = mapper.readValue(requestString, IntiateESimActivationUIRequest.class);
        request.setEid(null);
        StepVerifier.create(cartController2.initiateESimActivation(httpHeader, httpResponse, request)).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void deviceSimValidationTest1() throws IOException {
        String requestString = "null";
        String responseString = "{\n" +
                "    \"errors\": [\n" +
                "        {\n" +
                "            \"details\": [\n" +
                "                {\n" +
                "                    \"field\": \"RequestBody\",\n" +
                "                    \"value\": \"null/blank\",\n" +
                "                    \"issue\": \"RequestBody is/are missing.\",\n" +
                "                    \"location\": \"request\"\n" +
                "                },\n" +
                "                {\n" +
                "                    \"field\": \"Token\",\n" +
                "                    \"value\": \"null/blank\",\n" +
                "                    \"issue\": \"Token is/are missing.\",\n" +
                "                    \"location\": \"request\"\n" +
                "                }\n" +
                "            ]\n" +
                "        }\n" +
                "    ]\n" +
                "}";
        DeviceSimValidationUIRequest request = mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
        DeviceSimValidationUIResponse response = mapper.readValue(responseString, DeviceSimValidationUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimValidation");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController1.deviceSimValidation(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void deviceSimValidationTest() throws IOException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"imei\":\"352898071710272\",\"imei2\":\"\",\"iccid\":\"89148000003136518763\",\"mdn\":\"\",\"devid\":\"\",\"eid\":\"\",\"skipUserAgent\":true,\"isSmartphone\":true,\"podidentifier\":\"\",\"handofftoken\":\"\",\"billingId\":\"I\"}";
        String responseString = "{\"meta\":{\"timestamp\":\"1652136617166\",\"cxpCorrelationId\":\"2022-05-09T22:50:17.+0000:d742e580-c226-4967-9930-f66ead777ce5:cxp-customerprofile-se-qa-ev6v-sit3e-nscxp-568698f4cd-rrtp8:nssit3\"},\"data\":{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"iccid\":\"\",\"imei\":\"\",\"billingId\":\"I\",\"isSmartphone\":true,\"isEsimDevice\":false,\"flowType\":\"NSE\",\"isValidationSuccess\":true,\"isSDKDevice\":false,\"skipUserAgent\":true}}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\",\"eid\": \"8436667390\",\"bbpImei\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        DeviceSimValidationUIRequest request = mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
        DeviceSimValidationUIResponse response = mapper.readValue(responseString, DeviceSimValidationUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimValidation");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(readCartHelper.validateSecureToken(Mockito.any())).thenReturn(request);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(readCartHelper.customerByMtn(Mockito.any())).thenReturn(Mono.just(new CustomerByMtnUIResponse()));
        when(readCartHelper.deviceSimValidation(httpHeader, request)).thenReturn(Mono.just(response));
        when(redisHelper3.upsertDeviceSimValidationRequestDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController1.deviceSimValidation(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void deviceSimValidationMobileSecureRoleTest() throws IOException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"imei\":\"352898071710272\",\"imei2\":\"\",\"iccid\":\"89148000003136518763\",\"mdn\":\"\",\"devid\":\"\",\"eid\":\"\",\"skipUserAgent\":true,\"isSmartphone\":true,\"podidentifier\":\"\",\"handofftoken\":\"\",\"billingId\":\"I\"}";
        String responseString = "{\"meta\":{\"timestamp\":\"1652136617166\",\"cxpCorrelationId\":\"2022-05-09T22:50:17.+0000:d742e580-c226-4967-9930-f66ead777ce5:cxp-customerprofile-se-qa-ev6v-sit3e-nscxp-568698f4cd-rrtp8:nssit3\"},\"data\":{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"iccid\":\"\",\"imei\":\"\",\"billingId\":\"I\",\"isSmartphone\":true,\"isEsimDevice\":false,\"flowType\":\"NSE\",\"isValidationSuccess\":true,\"isSDKDevice\":false,\"skipUserAgent\":true}}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"role\": \"mobileSecure\"}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        DeviceSimValidationUIRequest request = mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
        DeviceSimValidationUIResponse response = mapper.readValue(responseString, DeviceSimValidationUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimValidation");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(readCartHelper.validateSecureToken(Mockito.any())).thenReturn(request);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(readCartHelper.customerByMtn(Mockito.any())).thenReturn(Mono.just(new CustomerByMtnUIResponse()));
        when(readCartHelper.deviceSimValidation(httpHeader, request)).thenReturn(Mono.just(response));
        when(redisHelper3.upsertDeviceSimValidationRequestDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController1.deviceSimValidation(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
        sampleRedisData.setRole(CartConstants.MOBILE_SECURE);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        StepVerifier.create(cartController1.deviceSimValidation(httpHeader, httpResponse, request)).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void deviceSimValidationMobileSecureRoleTest2() throws IOException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"imei\":\"352898071710272\",\"imei2\":\"\",\"iccid\":\"89148000003136518763\",\"mdn\":\"\",\"devid\":\"\",\"eid\":\"\",\"skipUserAgent\":true,\"isSmartphone\":true,\"podidentifier\":\"\",\"handofftoken\":\"\",\"billingId\":\"I\"}";
        String responseString = "{\"meta\":{\"timestamp\":\"1652136617166\",\"cxpCorrelationId\":\"2022-05-09T22:50:17.+0000:d742e580-c226-4967-9930-f66ead777ce5:cxp-customerprofile-se-qa-ev6v-sit3e-nscxp-568698f4cd-rrtp8:nssit3\"},\"data\":{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"iccid\":\"\",\"imei\":\"\",\"billingId\":\"I\",\"isSmartphone\":true,\"isEsimDevice\":false,\"flowType\":\"NSE\",\"isValidationSuccess\":true,\"isSDKDevice\":false,\"skipUserAgent\":true}}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"role\": \"mobileSecure\",\"esimType\": \"IPAD\"}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        DeviceSimValidationUIRequest request = mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
        DeviceSimValidationUIResponse response = mapper.readValue(responseString, DeviceSimValidationUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimValidation");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(readCartHelper.validateSecureToken(Mockito.any())).thenReturn(request);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(readCartHelper.customerByMtn(Mockito.any())).thenReturn(Mono.just(new CustomerByMtnUIResponse()));
        when(readCartHelper.deviceSimValidation(httpHeader, request)).thenReturn(Mono.just(response));
        when(redisHelper3.upsertDeviceSimValidationRequestDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController1.deviceSimValidation(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
        sampleRedisData.setRole(CartConstants.MOBILE_SECURE);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        StepVerifier.create(cartController1.deviceSimValidation(httpHeader, httpResponse, request)).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void deviceSimValidationMobileSecureRoleTest3() throws IOException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"imei\":\"352898071710272\",\"imei2\":\"\",\"iccid\":\"89148000003136518763\",\"mdn\":\"\",\"devid\":\"\",\"eid\":\"\",\"skipUserAgent\":true,\"isSmartphone\":true,\"podidentifier\":\"\",\"handofftoken\":\"\",\"billingId\":\"I\"}";
        String responseString = "{\"meta\":{\"timestamp\":\"1652136617166\",\"cxpCorrelationId\":\"2022-05-09T22:50:17.+0000:d742e580-c226-4967-9930-f66ead777ce5:cxp-customerprofile-se-qa-ev6v-sit3e-nscxp-568698f4cd-rrtp8:nssit3\"},\"data\":{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"iccid\":\"\",\"imei\":\"\",\"billingId\":\"I\",\"isSmartphone\":true,\"isEsimDevice\":false,\"flowType\":\"NSE\",\"isValidationSuccess\":true,\"isSDKDevice\":false,\"skipUserAgent\":true}}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"role\": \"mobileSecure\",\"esimType\": \"LAPTOP\"}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        DeviceSimValidationUIRequest request = mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
        DeviceSimValidationUIResponse response = mapper.readValue(responseString, DeviceSimValidationUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimValidation");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(readCartHelper.validateSecureToken(Mockito.any())).thenReturn(request);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(readCartHelper.customerByMtn(Mockito.any())).thenReturn(Mono.just(new CustomerByMtnUIResponse()));
        when(readCartHelper.deviceSimValidation(httpHeader, request)).thenReturn(Mono.just(response));
        when(redisHelper3.upsertDeviceSimValidationRequestDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController1.deviceSimValidation(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
        sampleRedisData.setRole(CartConstants.MOBILE_SECURE);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        StepVerifier.create(cartController1.deviceSimValidation(httpHeader, httpResponse, request)).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void deviceSimValidationIsValidCustomerTest() throws IOException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"imei\":\"352898071710272\",\"imei2\":\"\",\"iccid\":\"89148000003136518763\",\"mdn\":\"\",\"devid\":\"\",\"eid\":\"\",\"skipUserAgent\":true,\"isSmartphone\":true,\"podidentifier\":\"\",\"handofftoken\":\"\",\"billingId\":\"I\"}";
        String responseString = "{\"meta\":{\"timestamp\":\"1652136617166\",\"cxpCorrelationId\":\"2022-05-09T22:50:17.+0000:d742e580-c226-4967-9930-f66ead777ce5:cxp-customerprofile-se-qa-ev6v-sit3e-nscxp-568698f4cd-rrtp8:nssit3\"},\"data\":{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"iccid\":\"\",\"imei\":\"\",\"billingId\":\"I\",\"isSmartphone\":true,\"isEsimDevice\":false,\"flowType\":\"NSE\",\"isValidationSuccess\":true,\"isSDKDevice\":false,\"skipUserAgent\":true}}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"isValidCustomer\": \"false\"}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        DeviceSimValidationUIRequest request = mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
        DeviceSimValidationUIResponse response = mapper.readValue(responseString, DeviceSimValidationUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimValidation");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(readCartHelper.validateSecureToken(Mockito.any())).thenReturn(request);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(readCartHelper.customerByMtn(Mockito.any())).thenReturn(Mono.just(new CustomerByMtnUIResponse()));
        when(readCartHelper.deviceSimValidation(httpHeader, request)).thenReturn(Mono.just(response));
        when(redisHelper3.upsertDeviceSimValidationRequestDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController1.deviceSimValidation(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
        sampleRedisData.setIsValidCustomer(false);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        StepVerifier.create(cartController1.deviceSimValidation(httpHeader, httpResponse, request)).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void deviceSimValidationTest3() throws IOException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"imei\":\"352980090537603\",\"imei2\":\"\",\"iccid\":\"89148000007756782179\",\"mdn\":\"\",\"devid\":\"\",\"eid\":\"\",\"skipUserAgent\":true,\"isSmartphone\":false,\"podidentifier\":\"\",\"handofftoken\":\"\",\"billingId\":\"I\",\"token\":\"13125353\"}";
        String responseString = "{\"meta\":{\"timestamp\":\"1652136617166\",\"cxpCorrelationId\":\"2022-05-09T22:50:17.+0000:d742e580-c226-4967-9930-f66ead777ce5:cxp-customerprofile-se-qa-ev6v-sit3e-nscxp-568698f4cd-rrtp8:nssit3\"},\"data\":{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"iccid\":\"\",\"imei\":\"\",\"billingId\":\"I\",\"isSmartphone\":true,\"isEsimDevice\":false,\"flowType\":\"NSE\",\"isValidationSuccess\":true,\"isSDKDevice\":false,\"skipUserAgent\":true}}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        DeviceSimValidationUIRequest request = mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
        DeviceSimValidationUIResponse response = mapper.readValue(responseString, DeviceSimValidationUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimValidation");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(readCartHelper.validateSecureToken(Mockito.any())).thenReturn(request);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(readCartHelper.customerByMtn(Mockito.any())).thenReturn(Mono.just(new CustomerByMtnUIResponse()));
        when(readCartHelper.deviceSimValidation(httpHeader, request)).thenReturn(Mono.just(response));
        when(redisHelper3.upsertDeviceSimValidationRequestDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController1.deviceSimValidation(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void deviceSimValidationTest4() throws IOException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"imei\":\"352980090537603\",\"imei2\":\"\",\"iccid\":\"89148000007756782179\",\"mdn\":\"\",\"devid\":\"\",\"eid\":\"\",\"skipUserAgent\":true,\"isSmartphone\":false,\"podidentifier\":\"\",\"handofftoken\":\"\",\"billingId\":\"I\",\"token\":\"13125353\", \"response\":\"smartphone\"}";
        String responseString = "{\"meta\":{\"timestamp\":\"1652136617166\",\"cxpCorrelationId\":\"2022-05-09T22:50:17.+0000:d742e580-c226-4967-9930-f66ead777ce5:cxp-customerprofile-se-qa-ev6v-sit3e-nscxp-568698f4cd-rrtp8:nssit3\"},\"data\":{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"iccid\":\"\",\"imei\":\"\",\"billingId\":\"I\",\"isSmartphone\":true,\"isEsimDevice\":false,\"flowType\":\"NSE\",\"isValidationSuccess\":true,\"isSDKDevice\":false,\"skipUserAgent\":true}}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        DeviceSimValidationUIRequest request = mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
        DeviceSimValidationUIResponse response = mapper.readValue(responseString, DeviceSimValidationUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimValidation");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(readCartHelper.validateSecureToken(Mockito.any())).thenReturn(request);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(readCartHelper.customerByMtn(Mockito.any())).thenReturn(Mono.just(new CustomerByMtnUIResponse()));
        when(readCartHelper.deviceSimValidation(httpHeader, request)).thenReturn(Mono.just(response));
        when(redisHelper3.upsertDeviceSimValidationRequestDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController1.deviceSimValidation(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void deviceSimValidationTest5() throws IOException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"imei\":\"352980090537603\",\"imei2\":\"\",\"iccid\":\"\",\"mdn\":\"\",\"devid\":\"\",\"eid\":\"\",\"skipUserAgent\":true,\"isSmartphone\":false,\"podidentifier\":\"\",\"handofftoken\":\"\",\"billingId\":\"I\",\"token\":\"\", \"response\":\"smartphone\"}";
        String responseString = "{\"meta\":{\"timestamp\":\"1652136617166\",\"cxpCorrelationId\":\"2022-05-09T22:50:17.+0000:d742e580-c226-4967-9930-f66ead777ce5:cxp-customerprofile-se-qa-ev6v-sit3e-nscxp-568698f4cd-rrtp8:nssit3\"},\"data\":{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"iccid\":\"\",\"imei\":\"\",\"billingId\":\"I\",\"isSmartphone\":true,\"isEsimDevice\":false,\"flowType\":\"NSE\",\"isValidationSuccess\":true,\"isSDKDevice\":false,\"skipUserAgent\":true}}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        DeviceSimValidationUIRequest request = mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
        DeviceSimValidationUIResponse response = mapper.readValue(responseString, DeviceSimValidationUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimValidation");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(readCartHelper.validateSecureToken(Mockito.any())).thenReturn(request);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(readCartHelper.customerByMtn(Mockito.any())).thenReturn(Mono.just(new CustomerByMtnUIResponse()));
        when(readCartHelper.deviceSimValidation(httpHeader, request)).thenReturn(Mono.just(response));
        when(redisHelper3.upsertDeviceSimValidationRequestDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController1.deviceSimValidation(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void deviceSimValidationTest6() throws IOException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"imei\":\"352980090537603\",\"imei2\":\"\",\"iccid\":\"89148000007756782179\",\"mdn\":\"\",\"devid\":\"\",\"eid\":\"\",\"skipUserAgent\":true,\"isSmartphone\":false,\"billingId\":\"I\"}";
        String responseString = "{\"meta\":{\"timestamp\":\"1652136617166\",\"cxpCorrelationId\":\"2022-05-09T22:50:17.+0000:d742e580-c226-4967-9930-f66ead777ce5:cxp-customerprofile-se-qa-ev6v-sit3e-nscxp-568698f4cd-rrtp8:nssit3\"},\"data\":{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"iccid\":\"\",\"imei\":\"\",\"billingId\":\"I\",\"isSmartphone\":true,\"isEsimDevice\":false,\"flowType\":\"NSE\",\"isValidationSuccess\":true,\"isSDKDevice\":false,\"skipUserAgent\":true}}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        DeviceSimValidationUIRequest request = mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
        DeviceSimValidationUIResponse response = mapper.readValue(responseString, DeviceSimValidationUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimValidation");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(readCartHelper.validateSecureToken(Mockito.any())).thenReturn(request);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(readCartHelper.customerByMtn(Mockito.any())).thenReturn(Mono.just(new CustomerByMtnUIResponse()));
        when(readCartHelper.deviceSimValidation(httpHeader, request)).thenReturn(Mono.just(response));
        when(redisHelper3.upsertDeviceSimValidationRequestDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController1.deviceSimValidation(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void deviceSimValidationTest7() throws IOException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"imei\":\"352980090537603\",\"imei2\":\"\",\"iccid\":\"89148000007756782179\",\"mdn\":\"\",\"devid\":\"\",\"eid\":\"\",\"skipUserAgent\":true,\"isSmartphone\":false,\"billingId\":\"I\"}";
        String responseString = "{\"meta\":{\"timestamp\":\"1652136617166\",\"cxpCorrelationId\":\"2022-05-09T22:50:17.+0000:d742e580-c226-4967-9930-f66ead777ce5:cxp-customerprofile-se-qa-ev6v-sit3e-nscxp-568698f4cd-rrtp8:nssit3\"},\"data\":{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"iccid\":\"3534634\",\"imei\":\"3554666\",\"imei2\":\"464623423\",\"billingId\":\"I\",\"isSmartphone\":false,\"isEsimDevice\":false,\"flowType\":\"NSE\",\"isValidationSuccess\":true,\"isSDKDevice\":false,\"skipUserAgent\":true}}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        DeviceSimValidationUIRequest request = mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
        DeviceSimValidationUIResponse response = mapper.readValue(responseString, DeviceSimValidationUIResponse.class);
        URI url = URI.create("http://localhost/nse/deviceSimValidation");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(readCartHelper.validateSecureToken(Mockito.any())).thenReturn(request);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(readCartHelper.customerByMtn(Mockito.any())).thenReturn(Mono.just(new CustomerByMtnUIResponse()));
        when(readCartHelper.deviceSimValidation(httpHeader, request)).thenReturn(Mono.just(response));
        when(redisHelper3.upsertDeviceSimValidationRequestDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.upsertDeviceSimValidationDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController1.deviceSimValidation(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void deviceSimValidationTest8() throws IOException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"imei\":\"352980090537603\",\"imei2\":\"\",\"iccid\":\"89148000007756782179\",\"mdn\":\"\",\"devid\":\"\",\"eid\":\"\",\"skipUserAgent\":true,\"isSmartphone\":false,\"billingId\":\"I\"}";
        String responseString = "{\"meta\":{\"timestamp\":\"1652136617166\",\"cxpCorrelationId\":\"2022-05-09T22:50:17.+0000:d742e580-c226-4967-9930-f66ead777ce5:cxp-customerprofile-se-qa-ev6v-sit3e-nscxp-568698f4cd-rrtp8:nssit3\"},\"data\":{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"iccid\":\"3534634\",\"imei\":\"3554666\",\"imei2\":\"464623423\",\"billingId\":\"I\",\"isSmartphone\":false,\"isEsimDevice\":false,\"flowType\":\"NSE\",\"isValidationSuccess\":true,\"isSDKDevice\":false,\"skipUserAgent\":true}}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"9034080316\" }";
        String customerString = "{\"meta\":{\"timestamp\":1654179804631,\"cxpCorrelationId\":\"2022-06-02T14:23:24.+0000:e2413581-c6bf-4dab-9e47-b032d525a4ab:cxp-customerprofile-se-qa-ev6v-sit1e-nscxp-579d8d78d-fjzgg:nssit1\"},\"data\":{\"customerProfile\":{\"billAccounts\":[{\"accountAddress\":{\"zipCode\":\"75402\"},\"mtns\":[{\"mtn\":\"9034080316\",\"mobileInfoAttributes\":{\"accessRoles\":{\"manager\":false,\"member\":false,\"owner\":false}}},{\"mtn\":\"9035130768\",\"mobileInfoAttributes\":{\"accessRoles\":{\"manager\":false,\"member\":false,\"owner\":false}}},{\"mtn\":\"8436667390\",\"mobileInfoAttributes\":{\"accessRoles\":{\"manager\":true,\"member\":false,\"owner\":false}}}]}]}}}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        CustomerByMtnUIResponse customerByMtnUIResponse = mapper.readValue(customerString, CustomerByMtnUIResponse.class);
        DeviceSimValidationUIRequest request = mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
        DeviceSimValidationUIResponse response = mapper.readValue(responseString, DeviceSimValidationUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimValidation");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(readCartHelper.validateSecureToken(Mockito.any())).thenReturn(request);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(readCartHelper.customerByMtn(Mockito.any())).thenReturn(Mono.just(customerByMtnUIResponse));
        when(readCartHelper.deviceSimValidation(httpHeader, request)).thenReturn(Mono.just(response));
        when(redisHelper3.upsertDeviceSimValidationRequestDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.upsertDeviceSimValidationDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController1.deviceSimValidation(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void deviceSimValidationTest9() throws IOException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"imei\":\"352980090537603\",\"imei2\":\"\",\"iccid\":\"89148000007756782179\",\"mdn\":\"\",\"devid\":\"\",\"eid\":\"\",\"skipUserAgent\":true,\"isSmartphone\":false,\"billingId\":\"I\"}";
        String responseString = "{\"meta\":{\"timestamp\":\"1652136617166\",\"cxpCorrelationId\":\"2022-05-09T22:50:17.+0000:d742e580-c226-4967-9930-f66ead777ce5:cxp-customerprofile-se-qa-ev6v-sit3e-nscxp-568698f4cd-rrtp8:nssit3\"},\"data\":{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"iccid\":\"3534634\",\"imei\":\"3554666\",\"imei2\":\"464623423\",\"billingId\":\"I\",\"isSmartphone\":false,\"isEsimDevice\":false,\"flowType\":\"NSE\",\"isValidationSuccess\":true,\"isSDKDevice\":false,\"skipUserAgent\":true}}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        String customerString = "{\"meta\":{\"timestamp\":1654179804631,\"cxpCorrelationId\":\"2022-06-02T14:23:24.+0000:e2413581-c6bf-4dab-9e47-b032d525a4ab:cxp-customerprofile-se-qa-ev6v-sit1e-nscxp-579d8d78d-fjzgg:nssit1\"},\"data\":{\"customerProfile\":{\"billAccounts\":[{\"accountAddress\":{\"zipCode\":\"75402\"},\"mtns\":[{\"mtn\":\"9034080316\",\"mobileInfoAttributes\":{\"accessRoles\":{\"manager\":false,\"member\":false,\"owner\":false}}},{\"mtn\":\"9035130768\",\"mobileInfoAttributes\":{\"accessRoles\":{\"manager\":false,\"member\":false,\"owner\":false}}},{\"mtn\":\"8436667390\",\"mobileInfoAttributes\":{\"accessRoles\":{\"manager\":false,\"member\":true,\"owner\":false}}}]}]}}}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        CustomerByMtnUIResponse customerByMtnUIResponse = mapper.readValue(customerString, CustomerByMtnUIResponse.class);
        DeviceSimValidationUIRequest request = mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
        DeviceSimValidationUIResponse response = mapper.readValue(responseString, DeviceSimValidationUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimValidation");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(readCartHelper.validateSecureToken(Mockito.any())).thenReturn(request);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(readCartHelper.customerByMtn(Mockito.any())).thenReturn(Mono.just(customerByMtnUIResponse));
        when(readCartHelper.deviceSimValidation(httpHeader, request)).thenReturn(Mono.just(response));
        when(redisHelper3.upsertDeviceSimValidationRequestDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.upsertDeviceSimValidationDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController1.deviceSimValidation(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void deviceSimValidationTest10() throws IOException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"imei\":\"352980090537603\",\"imei2\":\"\",\"iccid\":\"89148000007756782179\",\"mdn\":\"\",\"devid\":\"\",\"eid\":\"\",\"skipUserAgent\":true,\"isSmartphone\":false,\"billingId\":\"I\"}";
        String responseString = "{\"meta\":{\"timestamp\":\"1652136617166\",\"cxpCorrelationId\":\"2022-05-09T22:50:17.+0000:d742e580-c226-4967-9930-f66ead777ce5:cxp-customerprofile-se-qa-ev6v-sit3e-nscxp-568698f4cd-rrtp8:nssit3\"},\"data\":{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"iccid\":\"3534634\",\"imei\":\"3554666\",\"imei2\":\"464623423\",\"billingId\":\"I\",\"isSmartphone\":false,\"isEsimDevice\":false,\"flowType\":\"NSE\",\"isValidationSuccess\":true,\"isSDKDevice\":false,\"skipUserAgent\":true}}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        String customerString = "{\"meta\":{\"timestamp\":1654179804631,\"cxpCorrelationId\":\"2022-06-02T14:23:24.+0000:e2413581-c6bf-4dab-9e47-b032d525a4ab:cxp-customerprofile-se-qa-ev6v-sit1e-nscxp-579d8d78d-fjzgg:nssit1\"},\"data\":{\"customerProfile\":{\"billAccounts\":[{\"accountAddress\":{\"zipCode\":\"75402\"},\"mtns\":[{\"mtn\":\"9034080316\",\"mobileInfoAttributes\":{\"accessRoles\":{\"manager\":false,\"member\":false,\"owner\":false}}},{\"mtn\":\"9035130768\",\"mobileInfoAttributes\":{\"accessRoles\":{\"manager\":false,\"member\":false,\"owner\":false}}},{\"mtn\":\"8436667390\",\"mobileInfoAttributes\":{\"accessRoles\":{\"manager\":false,\"member\":false,\"owner\":true}}}]}]}}}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        CustomerByMtnUIResponse customerByMtnUIResponse = mapper.readValue(customerString, CustomerByMtnUIResponse.class);
        DeviceSimValidationUIRequest request = mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
        DeviceSimValidationUIResponse response = mapper.readValue(responseString, DeviceSimValidationUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimValidation");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(readCartHelper.validateSecureToken(Mockito.any())).thenReturn(request);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(readCartHelper.customerByMtn(Mockito.any())).thenReturn(Mono.just(customerByMtnUIResponse));
        when(readCartHelper.deviceSimValidation(httpHeader, request)).thenReturn(Mono.just(response));
        when(redisHelper3.upsertDeviceSimValidationRequestDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.upsertDeviceSimValidationDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController1.deviceSimValidation(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void deviceSimValidationTest11() throws IOException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"imei\":\"352980090537603\",\"imei2\":\"\",\"iccid\":\"89148000007756782179\",\"mdn\":\"\",\"devid\":\"\",\"eid\":\"\",\"skipUserAgent\":true,\"isSmartphone\":false,\"billingId\":\"I\"}";
        String responseString = "{\"meta\":{\"timestamp\":\"1652136617166\",\"cxpCorrelationId\":\"2022-05-09T22:50:17.+0000:d742e580-c226-4967-9930-f66ead777ce5:cxp-customerprofile-se-qa-ev6v-sit3e-nscxp-568698f4cd-rrtp8:nssit3\"},\"data\":{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"iccid\":\"3534634\",\"imei\":\"3554666\",\"imei2\":\"464623423\",\"billingId\":\"I\",\"isSmartphone\":false,\"isEsimDevice\":false,\"flowType\":\"NSE\",\"isValidationSuccess\":true,\"isSDKDevice\":false,\"skipUserAgent\":true}}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        String customerString = "{\"meta\":{\"timestamp\":1654179804631,\"cxpCorrelationId\":\"2022-06-02T14:23:24.+0000:e2413581-c6bf-4dab-9e47-b032d525a4ab:cxp-customerprofile-se-qa-ev6v-sit1e-nscxp-579d8d78d-fjzgg:nssit1\"},\"data\":{\"customerProfile\":{\"billAccounts\":[{\"accountAddress\":{\"zipCode\":\"75402\"},\"mtns\":[{\"mtn\":\"9034080316\",\"mobileInfoAttributes\":{\"accessRoles\":{\"manager\":false,\"member\":false,\"owner\":false}}},{\"mtn\":\"9035130768\",\"mobileInfoAttributes\":{\"accessRoles\":{\"manager\":false,\"member\":false,\"owner\":false}}},{\"mtn\":\"8436667390\",\"mobileInfoAttributes\":{\"accessRoles\":{\"manager\":false,\"member\":false,\"owner\":false}}}]}]}}}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        CustomerByMtnUIResponse customerByMtnUIResponse = mapper.readValue(customerString, CustomerByMtnUIResponse.class);
        DeviceSimValidationUIRequest request = mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
        DeviceSimValidationUIResponse response = mapper.readValue(responseString, DeviceSimValidationUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimValidation");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(readCartHelper.validateSecureToken(Mockito.any())).thenReturn(request);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(readCartHelper.customerByMtn(Mockito.any())).thenReturn(Mono.just(customerByMtnUIResponse));
        when(readCartHelper.deviceSimValidation(httpHeader, request)).thenReturn(Mono.just(response));
        when(redisHelper3.upsertDeviceSimValidationRequestDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.upsertDeviceSimValidationDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController1.deviceSimValidation(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void deviceSimValidationErrorTest() throws IOException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"imei\":\"352898071710272\",\"imei2\":\"\",\"iccid\":\"89148000003136518763\",\"mdn\":\"\",\"devid\":\"\",\"eid\":\"\",\"skipUserAgent\":true,\"isSmartphone\":true,\"podidentifier\":\"\",\"handofftoken\":\"\",\"billingId\":\"I\"}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        DeviceSimValidationUIRequest request = mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
        DeviceSimValidationUIResponse response = mapper.readValue(responseString, DeviceSimValidationUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimValidation");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(readCartHelper.validateSecureToken(Mockito.any())).thenReturn(request);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(readCartHelper.customerByMtn(Mockito.any())).thenReturn(Mono.just(new CustomerByMtnUIResponse()));
        response.setData(new DeviceSimValidationUIResponseData());
        response.getData().setIsEsimDevice(false);
        when(readCartHelper.deviceSimValidation(httpHeader, request)).thenReturn(Mono.just(response));
        when(redisHelper3.upsertDeviceSimValidationRequestDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController1.deviceSimValidation(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void validateCartAndCheckoutNSEWithQuoteIdTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"quoteId\":\"quoteId\",\"quoteWithoutCredit\":false,\"clientAppName\":\"VZW-RPS\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"processingMTN\":\"newLine1\",\"intendType\":\"NSEBYOD\",\"processStep\":\"ShoppingCart\",\"processAction\":\"checkOut\"}}";
        String responseString = "{\"showPlanOverageFuturedateMsg\":false,\"showPlanOverageBackdateMsg\":false,\"serviceHeader\":{\"clientId\":\"VZW-RPS\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.05.11.07.33.44-87.89037876853945\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-490539481-W01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"OrderReview-Shipping-Payment-Agreement\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"OrderReview-Shipping-Payment-Agreement\"}]},\"cartInfo\":{\"cartId\":\"5354fca2-5f41-46d2-b967-dd7456546cc7\"},\"customerInfo\":{\"accountNumber\":\"0573859680-00001\",\"cartCreator\":\"4089218857\",\"processingMTN\":\"newLine1\",\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"RPSBYODLandingPage\",\"RPSPlan\",\"E911\",\"NumberSelection\",\"DeviceConfigurator\",\"ShoppingCart\"]}],\"validateOrder\":{\"orderDetails\":[{\"orderNumber\":\"4089404\",\"lineErrorList\":[],\"lineActivityType\":\"\",\"suggestedDate\":\"\",\"cpcType\":\"noCPCLines\",\"creditFailureCount\":0,\"maxCreditFailuresAllowed\":0,\"systemId\":\"\",\"creditApplicationNum\":\"526405322\",\"orderStatus\":\"FAILED\",\"shipmentAddressValidated\":true,\"userId\":\"\",\"statusMsg\":\"\",\"creditApprovalStatus\":\"HD\",\"creditStatusReason\":\"F1 Application needs validation, please call 888-483-7200\",\"securityDepositAmount\":\"0\",\"loveligibility\":false,\"statusCode\":\"\",\"showConflicts\":true}],\"cartId\":\"\",\"locationCode\":\"X473601\",\"orderType\":\"PS\",\"saleType\":\"P\",\"totalDueMonthly\":0.0,\"totalDownPaymentAmt\":0.0,\"tradeInType\":\"\",\"paymentRequired\":false,\"effectivePlanDateValid\":true,\"downpaymentRequired\":false,\"managerApproval\":false,\"prefferedPricingOptions\":false}}}},\"cartReadyForCheckout\":true}";
        InitiateCheckoutUIResponse response = mapper.readValue(responseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest request = mapper.readValue(requestString, InitiateCheckoutUIRequest.class);
        URI url = URI.create("http://localhost/validateCartAndCheckout");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.validateCartAndCheckout(Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.validateCartAndCheckout(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void validateCartAndCheckoutNSEWithQuoteId1Test() throws IOException {
        String requestString = "{\"cartInfo\":{\"quoteId\":\"quoteId\",\"quoteWithoutCredit\":true,\"clientAppName\":\"VZW-RPS\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"processingMTN\":\"newLine1\",\"intendType\":\"NSEBYOD\",\"processStep\":\"ShoppingCart\",\"processAction\":\"checkOut\"}}";
        String responseString = "{\"showPlanOverageFuturedateMsg\":false,\"showPlanOverageBackdateMsg\":false,\"serviceHeader\":{\"clientId\":\"VZW-RPS\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.05.11.07.33.44-87.89037876853945\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-490539481-W01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"OrderReview-Shipping-Payment-Agreement\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"OrderReview-Shipping-Payment-Agreement\"}]},\"cartInfo\":{\"cartId\":\"5354fca2-5f41-46d2-b967-dd7456546cc7\"},\"customerInfo\":{\"accountNumber\":\"0573859680-00001\",\"cartCreator\":\"4089218857\",\"processingMTN\":\"newLine1\",\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"RPSBYODLandingPage\",\"RPSPlan\",\"E911\",\"NumberSelection\",\"DeviceConfigurator\",\"ShoppingCart\"]}],\"validateOrder\":{\"orderDetails\":[{\"orderNumber\":\"4089404\",\"lineErrorList\":[],\"lineActivityType\":\"\",\"suggestedDate\":\"\",\"cpcType\":\"noCPCLines\",\"creditFailureCount\":0,\"maxCreditFailuresAllowed\":0,\"systemId\":\"\",\"creditApplicationNum\":\"526405322\",\"orderStatus\":\"FAILED\",\"shipmentAddressValidated\":true,\"userId\":\"\",\"statusMsg\":\"\",\"creditApprovalStatus\":\"HD\",\"creditStatusReason\":\"F1 Application needs validation, please call 888-483-7200\",\"securityDepositAmount\":\"0\",\"loveligibility\":false,\"statusCode\":\"\",\"showConflicts\":true}],\"cartId\":\"\",\"locationCode\":\"X473601\",\"orderType\":\"PS\",\"saleType\":\"P\",\"totalDueMonthly\":0.0,\"totalDownPaymentAmt\":0.0,\"tradeInType\":\"\",\"paymentRequired\":false,\"effectivePlanDateValid\":true,\"downpaymentRequired\":false,\"managerApproval\":false,\"prefferedPricingOptions\":false}}}},\"cartReadyForCheckout\":true}";
        InitiateCheckoutUIResponse response = mapper.readValue(responseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest request = mapper.readValue(requestString, InitiateCheckoutUIRequest.class);
        URI url = URI.create("http://localhost/validateCartAndCheckout");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.validateCartAndCheckout(Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.validateCartAndCheckout(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void validateCartAndCheckoutNSEWithoutQuoteIdTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"quoteWithoutCredit\":null,\"clientAppName\":\"VZW-RPS\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"processingMTN\":\"newLine1\",\"intendType\":\"NSEBYOD\",\"processStep\":\"ShoppingCart\",\"processAction\":\"checkOut\"}}";
        String responseString = "{\"showPlanOverageFuturedateMsg\":false,\"showPlanOverageBackdateMsg\":false,\"serviceHeader\":{\"clientId\":\"VZW-RPS\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.05.11.07.33.44-87.89037876853945\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-490539481-W01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"OrderReview-Shipping-Payment-Agreement\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"OrderReview-Shipping-Payment-Agreement\"}]},\"cartInfo\":{\"cartId\":\"5354fca2-5f41-46d2-b967-dd7456546cc7\"},\"customerInfo\":{\"accountNumber\":\"0573859680-00001\",\"cartCreator\":\"4089218857\",\"processingMTN\":\"newLine1\",\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"RPSBYODLandingPage\",\"RPSPlan\",\"E911\",\"NumberSelection\",\"DeviceConfigurator\",\"ShoppingCart\"]}],\"validateOrder\":{\"orderDetails\":[{\"orderNumber\":\"4089404\",\"lineErrorList\":[],\"lineActivityType\":\"\",\"suggestedDate\":\"\",\"cpcType\":\"noCPCLines\",\"creditFailureCount\":0,\"maxCreditFailuresAllowed\":0,\"systemId\":\"\",\"creditApplicationNum\":\"526405322\",\"orderStatus\":\"FAILED\",\"shipmentAddressValidated\":true,\"userId\":\"\",\"statusMsg\":\"\",\"creditApprovalStatus\":\"HD\",\"creditStatusReason\":\"F1 Application needs validation, please call 888-483-7200\",\"securityDepositAmount\":\"0\",\"loveligibility\":false,\"statusCode\":\"\",\"showConflicts\":true}],\"cartId\":\"\",\"locationCode\":\"X473601\",\"orderType\":\"PS\",\"saleType\":\"P\",\"totalDueMonthly\":0.0,\"totalDownPaymentAmt\":0.0,\"tradeInType\":\"\",\"paymentRequired\":false,\"effectivePlanDateValid\":true,\"downpaymentRequired\":false,\"managerApproval\":false,\"prefferedPricingOptions\":false}}}},\"cartReadyForCheckout\":true}";
        InitiateCheckoutUIResponse response = mapper.readValue(responseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest request = mapper.readValue(requestString, InitiateCheckoutUIRequest.class);
        URI url = URI.create("http://localhost/validateCartAndCheckout");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.validateCartAndCheckout(Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.validateCartAndCheckout(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void retrieveActivationStatusTest2ForRedis() throws IOException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"intent\":\"\",\"processStep\":\"Confirmation\",\"processAction\":\"retrieveActivationStatus\"}";
        String responseString = "{\"serviceHeader\":{},\"deviceType\":\"Laptop\"}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"bbpImei\": \"8436667390\", \"deviceType\":\"IPHONE\" }";
        RetrieveActivationStatusUIResponse response = mapper.readValue(responseString, RetrieveActivationStatusUIResponse.class);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(readCartHelper.retrieveActivationStatus(Mockito.any(), Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        RetrieveActivationStatusUIRequest request = mapper.readValue(requestString, RetrieveActivationStatusUIRequest.class);
        URI url = URI.create("http://localhost/cart/nse/retrieveActivationStatus");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(readCartHelper.retrieveActivationStatusFromCXP(Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.retrieveActivationStatus(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
        httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", CartConstants.VZW_BBP).build();
        StepVerifier.create(cartController2.retrieveActivationStatus(httpHeader, httpResponse, request)).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void removeSensitiveDataFromRetrieveCartTest() {
        RetrieveCartUIResponse response = new RetrieveCartUIResponse();
        CXPRetrieveCartDataVO data = new CXPRetrieveCartDataVO();
        data.setCartId("1234");
        CXPCartVO cart = new CXPCartVO();
        CXPLineDetailsVO cxpLineDetailsVO = new CXPLineDetailsVO();
        cxpLineDetailsVO.setCartId("1234");
        cart.setLineDetails(cxpLineDetailsVO);
        cart.setCartId("1234");
        RetrieveCartHeader retrieveCartHeader = new RetrieveCartHeader();
        retrieveCartHeader.setCartId("1234");
        retrieveCartHeader.setCaseId("2134");
        cart.setCartHeader(retrieveCartHeader);
        data.setCart(cart);
        response.setData(data);
        CartReadOperationsController.removeSensitiveDataFromRetrieveCart(response);
        org.junit.Assert.assertEquals(null, response.getData().getCartId());

        response.setData(null);
        CartReadOperationsController.removeSensitiveDataFromRetrieveCart(response);

        CartReadOperationsController.removeSensitiveDataFromRetrieveCart(null);

    }

    @Test
    public void removeSensitiveDataTest() {
        ValidateCartUIResponse response = new ValidateCartUIResponse();
        CXPValidateCartDataVO cxpValidateCartDataVO = new CXPValidateCartDataVO();
        CXPCartVO cxpCartVO = new CXPCartVO();
        cxpCartVO.setCartId("1234");
        CXPLineDetailsVO cxpLineDetailsVO = new CXPLineDetailsVO();
        cxpLineDetailsVO.setCartId("1234");
        cxpCartVO.setLineDetails(cxpLineDetailsVO);
        RetrieveCartHeader retrieveCartHeader = new RetrieveCartHeader();
        retrieveCartHeader.setCartId("1234");
        cxpCartVO.setCartHeader(retrieveCartHeader);
        cxpValidateCartDataVO.setValidateCartAndUpdate(cxpCartVO);
        response.setData(cxpValidateCartDataVO);
        CartReadOperationsController.removeSensitiveData(response);
        org.junit.Assert.assertEquals(null, response.getData().getValidateCartAndUpdate().getCartHeader().getCartId());

        response.getData().setValidateCartAndUpdate(null);
        CartReadOperationsController.removeSensitiveData(response);

        response.setData(null);
        CartReadOperationsController.removeSensitiveData(response);

        CartReadOperationsController.removeSensitiveData(null);
    }

    @Test
    public void retrieveActivationStatusTest() throws IOException {
        String requestString = "{\"channelId\":\"\",\"intent\":\"NSEBYOD\",\"processStep\":\"Confirmation\",\"processAction\":\"retrieveActivationStatus\"}";
        String responseString = "{\n" +
                "    \"errors\": [\n" +
                "        {\n" +
                "            \"name\": \"SYSTEM_ERROR\",\n" +
                "            \"id\": \"3999\",\n" +
                "            \"message\": \"System error, please try again\",\n" +
                "            \"severity\": \"High\",\n" +
                "            \"category\": \"UNKNOWN_ERR\"\n" +
                "        }\n" +
                "    ]\n" +
                "}";
        RetrieveActivationStatusUIRequest request = mapper.readValue(requestString, RetrieveActivationStatusUIRequest.class);
        RetrieveActivationStatusUIResponse response = mapper.readValue(responseString, RetrieveActivationStatusUIResponse.class);
        URI url = URI.create("http://localhost/cart/nse/retrieveActivationStatus");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(readCartHelper.retrieveActivationStatusFromCXP(Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.retrieveActivationStatus(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void retrieveActivationStatusTest2ForRedis2() throws IOException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"intent\":\"NSEBYOD\",\"processStep\":\"Confirmation\",\"processAction\":\"retrieveActivationStatus\"}";
        String responseString = "{\"serviceHeader\":{},\"deviceType\":\"Laptop\"}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"bbpImei\": \"8436667390\", \"deviceType\":\"IPHONE\" }";
        RetrieveActivationStatusUIResponse response = mapper.readValue(responseString, RetrieveActivationStatusUIResponse.class);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(readCartHelper.retrieveActivationStatus(Mockito.any(), Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        RetrieveActivationStatusUIRequest request = mapper.readValue(requestString, RetrieveActivationStatusUIRequest.class);
        URI url = URI.create("http://localhost/cart/nse/retrieveActivationStatus");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(readCartHelper.retrieveActivationStatusFromCXP(Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.retrieveActivationStatus(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void postMyLinkCookie() throws IOException {
        String responseString = "{\n" +
                "    \"meta\": {\n" +
                "        \"timestamp\": \"1652136617166\",\n" +
                "        \"cxpCorrelationId\":\"2022-05-09T22:50:17.+0000:d742e580-c226-4967-9930-f66ead777ce5:cxp-customerprofile-se-qa-ev6v-sit3e-nscxp-568698f4cd-rrtp8:nssit3\"\n" +
                "    },\n" +
                "    \"data\": {\n" +
                "        \"validSalesRepId\": \"true\",\n" +
                "        \"salesRepGivenName\": \"manish\",\n" +
                "        \"redirectUrl\": \"/sales/digital/gridwall.html\",\n" +
                "        \"repId\": \"134\",\n" +
                "        \"status\":\"pass\"\n" +
                "    }\n" +
                "\n" +
                "}";
        CustomerProfileUIResponse customerProfileUIResponse = mapper.readValue(responseString, CustomerProfileUIResponse.class);
        URI url = URI.create("http://localhost/cart/nse/myLink/validateSalesRepId/134/vzid");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        when(readCartHelper.salesRepIdProfile(Mockito.any())).thenReturn(Mono.just(customerProfileUIResponse));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.postMyLinkCookie(httpHeader,
                httpResponse, "134", "vzid");
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void validateOrderForNSETest() throws IOException {
        String requestString = "{\"cartInfo\":{\"processingMTN\":\"\",\"locationCode\":\"\",\"customerType\":\"N\",\"standaloneBYOD\":false,\"intendType\":\"NSE\",\"processStep\":\"OrderReview\",\"processAction\":\"validateOrder\",\"flowType\":\"VANITY\"}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.06.01.10.39.12-106.04065964449005\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"OrderReview\",\"processAction\":\"\",\"availablePaths\":[]},\"cartInfo\":{},\"customerInfo\":{\"customerType\":\"N\",\"originalCreditApprovalNumber\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-2b9c5523-35af-4bd3-a443-01a5e2364809\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"cradleFlowJourney\":\"AccessoryInterestialProspectBYOD\",\"mtnFlow\":\"D\",\"editFromPage\":\"\",\"globalId\":\"POE-D-2b9c5523-35af-4bd3-a443-01a5e2364809\"},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"BYODDeviceIDPage\",\"BYODSimIDPage\",\"PromoHub\",\"NewRecommendedPlanSelection\",\"DeviceConfigurator\",\"BYODDeviceIDPage\",\"BYODSimIDPage\",\"PromoHub\",\"ContactInfo\",\"EligibilityReview\",\"AssignNumbers\",\"Agreement\",\"OrderReview\"]}],\"validateOrder\":{\"orderDetails\":[{\"lineActivityType\":\"\",\"mtnDetailsList\":[{\"simIdProvided\":\"true\",\"mtn\":\"newLine1\",\"deviceIdProvided\":\"true\",\"ispuItem\":false,\"lineActivityType\":\"NSEBYOD\",\"lostORStolen\":\"false\"}],\"orderActivityType\":\"NSE\",\"cpcType\":\"noCPCLines\",\"removeble\":false,\"creditFailureCount\":0,\"maxCreditFailuresAllowed\":0,\"creditApplicationNum\":\"999999000\",\"orderStatus\":\"SUCCESS\",\"shipmentAddressValidated\":true,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CA CVAS AUTOMATIC APPROVAL\",\"securityDepositAmount\":\"0\",\"loveligibility\":false,\"showConflicts\":false,\"idialFeaturePresent\":false}],\"cartId\":\"\",\"locationCode\":\"\",\"orderType\":\"PS\",\"saleType\":\"P\",\"totalDueMonthly\":94.24,\"totalDownPaymentAmt\":0.0,\"externalProgramEligibilityCheck\":false,\"programEligibilityStatus\":\"\",\"managerApprovalForDiscount\":false,\"tradeInType\":\"\",\"readyForOrderSubmit\":false,\"errorDesc\":\"\",\"errorCode\":\"\",\"contactInfoAvailable\":true,\"creditCheckCompleted\":true,\"numberAssignmentDone\":true,\"accountPinAvailable\":true,\"shipmentMethodSelected\":false,\"paymentCompleted\":true,\"tncAccepted\":true,\"paymentRequired\":false,\"effectivePlanDateValid\":false,\"downpaymentRequired\":false,\"managerApproval\":false,\"prefferedPricingOptions\":false}}}}}";
        InitiateCheckoutUIRequest request = mapper.readValue(requestString, InitiateCheckoutUIRequest.class);
        InitiateCheckoutUIResponse response = mapper.readValue(responseString, InitiateCheckoutUIResponse.class);
        URI url = URI.create("http://localhost/nse/validateOrder");
        HttpCookie httpCookie = new HttpCookie("digital_ig_session", "bcba6c6c-afd9-4a59-b0dd-99b82fcf2ec9");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookie(httpCookie).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.validateOrder(Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.validateOrderForNSE(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }


    @Test
    public void retrieveActivationStatusTest1() throws IOException {
        String requestString = "{\"channelId\":\"\",\"intent\":\"NSEBYOD\",\"processStep\":\"Confirmation\",\"processAction\":\"retrieveActivationStatus\"}";
        String responseString = "{\n" +
                "    \"errors\": [\n" +
                "        {\n" +
                "            \"name\": \"SYSTEM_ERROR\",\n" +
                "            \"id\": \"3999\",\n" +
                "            \"message\": \"System error, please try again\",\n" +
                "            \"severity\": \"High\",\n" +
                "            \"category\": \"UNKNOWN_ERR\"\n" +
                "        }\n" +
                "    ]\n" +
                "}";
        RetrieveActivationStatusUIRequest request = mapper.readValue(requestString, RetrieveActivationStatusUIRequest.class);
        RetrieveActivationStatusUIResponse response = mapper.readValue(responseString, RetrieveActivationStatusUIResponse.class);
        URI url = URI.create("http://localhost/cart/nse/retrieveActivationStatus");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        when(readCartHelper.retrieveActivationStatusFromCXP(Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.retrieveActivationStatus(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void retrieveActivationStatusErrorTest() throws IOException {
        String requestString = "{\"channelId\":\"\",\"intent\":\"NSE\",\"processStep\":\"Confirmation\",\"processAction\":\"retrieveActivationStatus\"}";
        String responseString = "{\n" +
                "    \"errors\": [\n" +
                "        {\n" +
                "            \"name\": \"VALIDATION_ERROR\",\n" +
                "            \"id\": \"1000\",\n" +
                "            \"message\": \"Validation error with journey mapping\",\n" +
                "            \"severity\": \"High\"\n" +
                "        }\n" +
                "    ]\n" +
                "}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"bbpImei\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        RetrieveActivationStatusUIRequest request = mapper.readValue(requestString, RetrieveActivationStatusUIRequest.class);
        RetrieveActivationStatusUIResponse response = mapper.readValue(responseString, RetrieveActivationStatusUIResponse.class);

        URI url = URI.create("http://localhost/cart/nse/retrieveActivationStatus");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(readCartHelper.retrieveActivationStatus(Mockito.any(), Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.retrieveActivationStatus(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void nseAbandonCartTest() throws IOException {
        String requestString = "{ \"pageId\":\"sar\"}";
        String responseString = "{\n" +
                "    \"meta\": {\n" +
                "        \"timestamp\": \"1653973856101\",\n" +
                "        \"cxpCorrelationId\": \"2022-05-31T05:10:56.+0000:b6a15537-29e1-4015-8d03-956eeb98c60e:cxp-shopping-services-qa-ev6v-sit1e-nscxp-cccb76d45xjv7n:nssit1\"\n" +
                "    },\n" +
                "    \"data\": {\n" +
                "        \"retrieveLatestDevice\": {\n" +
                "            \"deviceInfo\": {\n" +
                "                \"deviceId\": \"\",\n" +
                "                \"deviceIdType\": \"\",\n" +
                "                \"deviceSku\": \"\",\n" +
                "                \"capacity\": \"\",\n" +
                "                \"modelName\": \"\",\n" +
                "                \"brandName\": \"\",\n" +
                "                \"operatingSystem\": \"\",\n" +
                "                \"deviceUrl\": \"\",\n" +
                "                \"simDaccCode\": \"\",\n" +
                "                \"Imei\": \"\",\n" +
                "                \"purchasedDeviceId\": \"\",\n" +
                "                \"purchasedDeviceDaccCode\": \"\"\n" +
                "            }\n" +
                "        }\n" +
                "    }\n" +
                "}";
        AbandonCartSOERequest request = mapper.readValue(requestString, AbandonCartSOERequest.class);
        RetrieveLatestDeviceCXPResponse response = mapper.readValue(responseString, RetrieveLatestDeviceCXPResponse.class);
        URI url = URI.create("http://localhost/nse/abandon-cart");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(readCartHelper.retrieveCartAbandon(Mockito.any(), Mockito.any())).thenReturn(Mono.just(response));

        Mono<RetrieveLatestDeviceCXPResponse> controllerResponse = cartController1.nseAbandonCart(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void deviceSimValidationTest2() throws IOException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"imei\":\"352898071710272\",\"imei2\":\"\",\"iccid\":\"89148000003136518763\",\"mdn\":\"\",\"devid\":\"\",\"eid\":\"\",\"skipUserAgent\":true,\"isSmartphone\":true,\"podidentifier\":\"\",\"handofftoken\":\"\",\"billingId\":\"I\"}";
        String responseString = "{\"meta\":{\"timestamp\":\"1652136617166\",\"cxpCorrelationId\":\"2022-05-09T22:50:17.+0000:d742e580-c226-4967-9930-f66ead777ce5:cxp-customerprofile-se-qa-ev6v-sit3e-nscxp-568698f4cd-rrtp8:nssit3\"},\"data\":{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"iccid\":\"\",\"imei\":\"\",\"billingId\":\"I\",\"isSmartphone\":true,\"isEsimDevice\":false,\"flowType\":\"NSE\",\"isValidationSuccess\":true,\"isSDKDevice\":false,\"skipUserAgent\":true}}";
        String redisDataString = "{\"role\": \"role\",\"isValidCustomer\": true,\"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        DeviceSimValidationUIRequest request = mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
        DeviceSimValidationUIResponse response = mapper.readValue(responseString, DeviceSimValidationUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimValidation");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(readCartHelper.validateSecureToken(Mockito.any())).thenReturn(request);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(readCartHelper.customerByMtn(Mockito.any())).thenReturn(Mono.just(new CustomerByMtnUIResponse()));
        when(readCartHelper.deviceSimValidation(httpHeader, request)).thenReturn(Mono.just(response));
        when(redisHelper3.upsertDeviceSimValidationRequestDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController1.deviceSimValidation(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void initiateValidateDeviceSimTest2() throws IOException {
        String requestString = "{\"data\": {\"postPaidInd\": \"Y\",\"processStep\": \"\",\"processAction\": \"initiateValidateDeviceSim\",\"intendType\": \"BYOD\"}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM-BBP\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.05.06.05.26.37-464.97529221856246\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4037290-C01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ValidateDeviceSimIdPage\"},{\"path\":\"ValidateDeviceSimIdPage\"}],\"pendingOrderAccountLevel\":\"false\",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"\",\"processAction\":\"\",\"pastDueBalance\":\"false\",\"intent\":\"BYOD\"},\"customerInfo\":{\"accountNumber\":\"0001213359-00001\",\"cartCreator\":\"4107035075\",\"processingMTN\":\"\",\"registerNumber\":0,\"deviceType\":\"\",\"existingCase\":\"\",\"lastUpdateDateTime\":\"20220506T052641.235 GMT\"},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"8737785a-3d9d-40b5-a813-caea12306563\",\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"customerConsent\":\"N\"}}}},\"greetingName\":\"RYAN\",\"deviceType\":\"CONNECTED_CAR\"}";
        String redisDataString = "{\"role\": \"role\",\"isValidCustomer\": true,\"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"bbpImei\": \"8436667390\",\"bbpIccid\":\"89148000005148869944\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        InitiateValidateDeviceSimUIRequest request = mapper.readValue(requestString, InitiateValidateDeviceSimUIRequest.class);
        InitiateValidateDeviceSimUIResponse response = mapper.readValue(responseString, InitiateValidateDeviceSimUIResponse.class);
        URI url = URI.create("http://localhost/initiateValidateDeviceSim");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("accountNumber", "0380416061-00001").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(redisHelper2.upsertValueInRedis(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(cartHelper.customerNameByMtn(Mockito.any())).thenReturn(Mono.just(response));
        when(cartHelper.initiateValidateDeviceSim(request, httpHeader, sampleRedisData)).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController1.initiateValidateDeviceSim(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();

        response.setErrors(null);
        when(cartHelper.customerNameByMtn(Mockito.any())).thenReturn(Mono.just(response));
        CartError CartErrorObj = new CartError();
        CartErrorObj.setMessage("Error");
        response.setErrors(Arrays.asList(new CartError[]{CartErrorObj, CartErrorObj}));
        response.setServiceBody(null);
        when(cartHelper.initiateValidateDeviceSim(request, httpHeader, sampleRedisData)).thenReturn(Mono.just(response));
        StepVerifier.create(cartController1.initiateValidateDeviceSim(httpHeader, httpResponse, request)).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();


        CartErrorObj.setMessage("Error");
        response.setErrors(Arrays.asList(new CartError[]{CartErrorObj, CartErrorObj}));
        response.setServiceBody(null);
        when(cartHelper.initiateValidateDeviceSim(request, httpHeader, sampleRedisData)).thenReturn(Mono.just(response));
    }


    @Test
    public void deviceIdValidationTest3() throws IOException {
        String requestString = "{\n" +
                "    \"cartInfo\": {\n" +
                "        \"cartCreator\": \"\",\n" +
                "        \"clientAppName\": \"VZW-ECOM\",\n" +
                "        \"cartId\": \"\",\n" +
                "        \"caseId\": \"\",\n" +
                "        \"processingMTN\": \"\",\n" +
                "        \"accountNumber\": \"\",\n" +
                "        \"intent\": \"BYOD\",\n" +
                "        \"processStep\": \"BYODDeviceIDPage\",\n" +
                "        \"processAction\": \"validateDeviceSim\"\n" +
                "    },\n" +
                "    \"data\": {\n" +
                "        \"lines\": [\n" +
                "            {\n" +
                "                \"mtn\": \"\",\n" +
                "                \"device\": {\n" +
                "                    \"id\": \"\",\n" +
                "                    \"Flowtype\": \"DEVICE\",\n" +
                "                    \"CurrentId\": \"\",\n" +
                "                    \"isCustomerProvidedEquipment\": true,\n" +
                "                    \"sku\": \"\",\n" +
                "                    \"smartIMEI\": true,\n" +
                "                    \"sorDisplayName\": \"iphone 12\",\n" +
                "                    \"skuCarrier\": \"verizon\"\n" +
                "                }\n" +
                "            }\n" +
                "        ]\n" +
                "    },\n" +
                "    \"channelId\": \"digital\"\n" +
                "}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.06.01.06.36.24-286.1457643881036\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"BYODDeviceIDPage\"}]},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-8cf14762-44f6-49c9-a30b-303dfa221760\",\"processingMTN\":\"\",\"registerNumber\":0,\"mtnFlow\":\"D\",\"globalId\":\"POE-D-8cf14762-44f6-49c9-a30b-303dfa221760\"},\"deviceInfo\":{\"simInfo\":{\"iccid\":\"\",\"mfgCode\":\"\",\"launchPackageSku\":\"\",\"prodName\":\"\",\"preferredSoftSim\":\"DFILLSIM5G-SA-A\",\"launchPackageSkuType\":\"\",\"pairedIccid\":\"\",\"type\":\"\",\"mtn\":\"\",\"mobileNumber\":\"\",\"active\":false,\"aging\":false,\"available\":false,\"retired\":false,\"grandFathered\":false,\"status\":\"\",\"euimid\":\"\",\"imsiv\":\"\",\"imsivf\":\"\",\"iccIdStat\":\"\",\"min\":\"\",\"ispuCompatibleSIM\":\"BULKSIM5G-SA-A\",\"dfillCompatibleSim\":\"DFILLSIM5G-SA-A\",\"esimid\":\"\",\"eID\":\"\"},\"deviceSimCompatible\":\"\",\"deviceSimM2MPair\":\"\",\"deviceESimCompatible\":\"\",\"deviceESimM2MPair\":\"\",\"deviceId\":\"IPHONE11-NVZW\",\"color\":{\"colorId\":\"\",\"displayName\":\"\",\"description\":\"\",\"colorCssStyle\":\"\"},\"imageName\":\"\",\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/generic_phone\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/generic_phone?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/generic_phone?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/generic_phone?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/generic_phone$device-thumb$\"},\"skuDisplayName\":\"APPLE IPHONE 11 NON VZW\",\"deviceSku\":\"IPHONE11-NVZW\",\"isRestrictedDevice\":\"\",\"deviceAttributes\":{\"mfgCode\":\"APL\",\"mfgName\":\"\",\"prodName\":\"IPHONE11 NON VZW\",\"prodType\":\"4GSmartphone-IN\",\"equipModeCode\":\"4GE\",\"equipMode\":\"4G\",\"gpsIndicator\":\"Y\",\"daccCode\":\"01358\",\"deviceType\":\"4GE\",\"deviceCategory\":\"4G Smartphone\",\"productId\":\"\",\"postpaidRestrictStartDate\":\"\",\"prepayRestrictStartDate\":\"\",\"wholesaleRestrictStartDate\":\"\"},\"lostAndStolen\":{\"lostStolen\":\"\",\"nonPay\":\"\"},\"numbershareCapability\":\"\",\"price\":{\"fullRetailPrice\":{\"contractText\":\"\"},\"oneYearPrice\":{\"contractText\":\"\"},\"devicePaymentPrice\":[]},\"skipSimIdFlag\":false,\"appleWatchFlag\":false,\"fmipLocked\":false,\"appleCarrieLock\":false,\"e911AddrInd\":\"\",\"simClass4G\":\"\",\"makeEtniPersApi\":false,\"softMessages\":[],\"standalonePairingEligible\":true,\"deviceFamilyType\":\"Phone\",\"osType\":\"Apple iOS\",\"euiccCapable\":\"\",\"imei1\":\"\",\"imei2\":\"\"}}}}}";
        DeviceIdValidationUIRequest request = mapper.readValue(requestString, DeviceIdValidationUIRequest.class);
        DeviceIdValidationUIResponse response = mapper.readValue(responseString, DeviceIdValidationUIResponse.class);
        URI url = URI.create("http://localhost/flexV2/validate-deviceSimId");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        when(readCartHelper.deviceIdValidation(Mockito.any())).thenReturn(Mono.just(response));
        Map<String, Object> secondAppvedData = new HashMap<>();
        when(redisHelper3.getDataFromSession(Mockito.any())).thenReturn(Mono.just(secondAppvedData));
        ReflectionTestUtils.setField(cartController, "enableIMEIRecaptcha", true);
        ReflectionTestUtils.setField(cartController, "skipChannelsForCaptcha", Arrays.asList("EXPRESS-STORE", "VZW-CHATBOT", "VZW-RPS", "VZW-CHATBOT-MF"));
        ReflectionTestUtils.setField(cartController, "captchaWhileListedIps", Arrays.asList("162.115.236", "137.188.108", "140.108.26.152", "38.99.101.196", "38.99.101.218", "38.99.101.219", "38.99.101.220"));
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        when(featureFlagHelper.fetchDigitalByodProfile()).thenReturn(Mono.just(configurationProfile));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.deviceIdValidation(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void deviceIdValidationTest4() throws IOException {
        String requestString = "{\n" +
                "    \"cartInfo\": {\n" +
                "        \"cartCreator\": \"\",\n" +
                "        \"clientAppName\": \"VZW-ECOM\",\n" +
                "        \"cartId\": \"\",\n" +
                "        \"caseId\": \"\",\n" +
                "        \"processingMTN\": \"\",\n" +
                "        \"accountNumber\": \"\",\n" +
                "        \"intent\": \"BYOD\",\n" +
                "        \"processStep\": \"BYODDeviceIDPage\",\n" +
                "        \"processAction\": \"validateDeviceSim\"\n" +
                "    },\n" +
                "    \"data\": {\n" +
                "        \"lines\": [\n" +
                "            {\n" +
                "                \"mtn\": \"\",\n" +
                "                \"device\": {\n" +
                "                    \"id\": \"\",\n" +
                "                    \"Flowtype\": \"DEVICE\",\n" +
                "                    \"CurrentId\": \"\",\n" +
                "                    \"isCustomerProvidedEquipment\": true,\n" +
                "                    \"sku\": \"\",\n" +
                "                    \"smartIMEI\": true,\n" +
                "                    \"sorDisplayName\": \"iphone 12\",\n" +
                "                    \"skuCarrier\": \"verizon\"\n" +
                "                }\n" +
                "            }\n" +
                "        ]\n" +
                "    },\n" +
                "    \"channelId\": \"digital\"\n" +
                "}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.06.01.06.36.24-286.1457643881036\"},\"serviceBody\":{\"serviceResponse\":{}}}";
        DeviceIdValidationUIRequest request = mapper.readValue(requestString, DeviceIdValidationUIRequest.class);
        DeviceIdValidationUIResponse response = mapper.readValue(responseString, DeviceIdValidationUIResponse.class);
        URI url = URI.create("http://localhost/validate-deviceSimId");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        when(readCartHelper.deviceIdValidation(Mockito.any())).thenReturn(Mono.just(response));
        Map<String, Object> secondAppvedData = new HashMap<>();
        when(redisHelper3.getDataFromSession(Mockito.any())).thenReturn(Mono.just(secondAppvedData));
        when(redisHelper.setByodDataToRedis(Mockito.any())).thenReturn(Mono.empty());
        ReflectionTestUtils.setField(cartController, "enableIMEIRecaptcha", true);
        ReflectionTestUtils.setField(cartController, "skipChannelsForCaptcha", Arrays.asList("EXPRESS-STORE", "VZW-CHATBOT", "VZW-RPS", "VZW-CHATBOT-MF"));
        ReflectionTestUtils.setField(cartController, "captchaWhileListedIps", Arrays.asList("162.115.236", "137.188.108", "140.108.26.152", "38.99.101.196", "38.99.101.218", "38.99.101.219", "38.99.101.220"));
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        when(featureFlagHelper.fetchDigitalByodProfile()).thenReturn(Mono.just(configurationProfile));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.deviceIdValidation(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
        request.setChannelId("OMNI-RETAIL");
        controllerResponse = cartController.deviceIdValidation(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void deviceIdValidationTest5() throws IOException {
        String requestString = "{\n" +
                "    \"cartInfo\": {\n" +
                "        \"cartCreator\": \"\",\n" +
                "        \"clientAppName\": \"VZW-ECOM\",\n" +
                "        \"cartId\": \"\",\n" +
                "        \"caseId\": \"\",\n" +
                "        \"processingMTN\": \"\",\n" +
                "        \"accountNumber\": \"\",\n" +
                "        \"intent\": \"BYOD\",\n" +
                "        \"processStep\": \"BYODDeviceIDPage\",\n" +
                "        \"processAction\": \"validateDeviceSim\"\n" +
                "    },\n" +
                "    \"data\": {\n" +
                "        \"lines\": [\n" +
                "            {\n" +
                "                \"mtn\": \"\",\n" +
                "                \"device\": {\n" +
                "                    \"id\": \"\",\n" +
                "                    \"Flowtype\": \"DEVICE\",\n" +
                "                    \"CurrentId\": \"\",\n" +
                "                    \"isCustomerProvidedEquipment\": true,\n" +
                "                    \"sku\": \"\",\n" +
                "                    \"smartIMEI\": true,\n" +
                "                    \"sorDisplayName\": \"iphone 12\",\n" +
                "                    \"skuCarrier\": \"verizon\"\n" +
                "                }\n" +
                "            }\n" +
                "        ]\n" +
                "    },\n" +
                "    \"channelId\": \"digital\"\n" +
                "}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.06.01.06.36.24-286.1457643881036\"},\"serviceBody\":{}}";
        DeviceIdValidationUIRequest request = mapper.readValue(requestString, DeviceIdValidationUIRequest.class);
        DeviceIdValidationUIResponse response = mapper.readValue(responseString, DeviceIdValidationUIResponse.class);
        URI url = URI.create("http://localhost/validate-deviceSimId");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        Map<String, Object> secondAppvedData = new HashMap<>();
        when(redisHelper3.getDataFromSession(Mockito.any())).thenReturn(Mono.just(secondAppvedData));
        when(readCartHelper.deviceIdValidation(Mockito.any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController, "enableIMEIRecaptcha", true);
        ReflectionTestUtils.setField(cartController, "skipChannelsForCaptcha", Arrays.asList("EXPRESS-STORE", "VZW-CHATBOT", "VZW-RPS", "VZW-CHATBOT-MF"));
        ReflectionTestUtils.setField(cartController, "captchaWhileListedIps", Arrays.asList("162.115.236", "137.188.108", "140.108.26.152", "38.99.101.196", "38.99.101.218", "38.99.101.219", "38.99.101.220"));
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        when(featureFlagHelper.fetchDigitalByodProfile()).thenReturn(Mono.just(configurationProfile));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.deviceIdValidation(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void deviceIdValidationTest6() throws IOException {
        String requestString = "{\n" +
                "    \"cartInfo\": {\n" +
                "        \"cartCreator\": \"\",\n" +
                "        \"clientAppName\": \"VZW-ECOM\",\n" +
                "        \"cartId\": \"\",\n" +
                "        \"caseId\": \"\",\n" +
                "        \"processingMTN\": \"\",\n" +
                "        \"accountNumber\": \"\",\n" +
                "        \"intent\": \"BYOD\",\n" +
                "        \"processStep\": \"BYODDeviceIDPage\",\n" +
                "        \"processAction\": \"validateDeviceSim\"\n" +
                "    },\n" +
                "    \"data\": {\n" +
                "        \"lines\": [\n" +
                "            {\n" +
                "                \"mtn\": \"\",\n" +
                "                \"device\": {\n" +
                "                    \"id\": \"\",\n" +
                "                    \"Flowtype\": \"DEVICE\",\n" +
                "                    \"CurrentId\": \"\",\n" +
                "                    \"isCustomerProvidedEquipment\": true,\n" +
                "                    \"sku\": \"\",\n" +
                "                    \"smartIMEI\": true,\n" +
                "                    \"sorDisplayName\": \"iphone 12\",\n" +
                "                    \"skuCarrier\": \"verizon\"\n" +
                "                }\n" +
                "            }\n" +
                "        ]\n" +
                "    },\n" +
                "    \"channelId\": \"digital\"\n" +
                "}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.06.01.06.36.24-286.1457643881036\"}}";
        DeviceIdValidationUIRequest request = mapper.readValue(requestString, DeviceIdValidationUIRequest.class);
        DeviceIdValidationUIResponse response = mapper.readValue(responseString, DeviceIdValidationUIResponse.class);
        URI url = URI.create("http://localhost/validate-deviceSimId");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        Map<String, Object> secondAppvedData = new HashMap<>();
        when(redisHelper3.getDataFromSession(Mockito.any())).thenReturn(Mono.just(secondAppvedData));
        when(readCartHelper.deviceIdValidation(Mockito.any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController, "enableIMEIRecaptcha", true);
        ReflectionTestUtils.setField(cartController, "skipChannelsForCaptcha", Arrays.asList("EXPRESS-STORE", "VZW-CHATBOT", "VZW-RPS", "VZW-CHATBOT-MF"));
        ReflectionTestUtils.setField(cartController, "captchaWhileListedIps", Arrays.asList("162.115.236", "137.188.108", "140.108.26.152", "38.99.101.196", "38.99.101.218", "38.99.101.219", "38.99.101.220"));
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        when(featureFlagHelper.fetchDigitalByodProfile()).thenReturn(Mono.just(configurationProfile));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.deviceIdValidation(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void nseRetrieveCartRequestErrorTest() throws IOException {
        String requestString = "{\"meta\":{\"client\":\"VZW-DOTCOM\",\"type\":\"NEWCUSTOMER\"},\"mtnList\":[]}";
        String responseString = "{\"data\":{\"cart\":{\"customerProfileForNSE\":{\"customerName\":{},\"contactInfo\":{\"billingAddress\":{\"e911AddressSharingOptIn\":false,\"zipCode\":\"30004\",\"zipCode4\":\"\",\"countryCode\":\"\",\"fipsCode\":\"1312101696\",\"floor\":0,\"city\":\"\",\"state\":\"\",\"addressIdNumber\":\"\",\"county\":\"\"}}},\"cartHeader\":{\"visionCustomerType\":\"PE\"},\"orderDetails\":{\"totalShippingCost\":0.0,\"totalDiscountedShippingCost\":0.0,\"taxDetailsList\":[{\"mldSequenceNum\":1,\"taxSequenceNum\":1,\"taxPassType\":\"10\",\"taxAmount\":\"52.0\",\"taxDescription\":\"GA State Sales Tax\",\"taxType\":\"01\"},{\"mldSequenceNum\":2,\"taxSequenceNum\":2,\"taxPassType\":\"22\",\"taxAmount\":\"48.75\",\"taxDescription\":\"Fulton Cnty Sales Tax\",\"taxType\":\"03\"}],\"originalSubTotalDueMonthly\":128.2,\"totalDueMonthlyAfterDiscounts\":123.33,\"customerType\":\"N\",\"billingSystem\":\"VE\",\"totalTaxAmount\":\"100.75\",\"chargeSummary\":[{\"chargeType\":\"ActivationFee\",\"amount\":35.0,\"finalPrice\":35.0}],\"totalDueToday\":100.75,\"totalDueMonthly\":128.2,\"subTotalDueMonthly\":123.33,\"subTotalDueToday\":0.0,\"enableSplitShipment\":false,\"splitShipmentIndicator\":false,\"cartReadyForCheckout\":true,\"totalDownPaymentAmt\":0.0,\"cartTotalDiscounts\":{\"totalDiscount\":\"0.0\",\"discountDetails\":[]}},\"lineDetails\":{\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"NSE\",\"totalDueToday\":100.75,\"totalDueTodayWithoutTax\":0.0,\"totalDueMonthly\":123.33,\"mobileNumber\":\"newLine1\",\"serviceInfo\":{\"pairingInfo\":{},\"planDiscount\":{\"planEligibleForAutoPayPaperLessDiscount\":true,\"eligibleAutoPayPaperlessDiscount\":\"10.0\",\"discountIncluded\":false,\"totalPlanCostIncludingLineAccessFee\":\"80.0\"},\"otherPromotions\":[],\"serviceAddress\":{\"zipCode\":\"30004\",\"zipCode4\":\"\",\"countryCode\":\"\",\"floor\":0,\"city\":\"\",\"state\":\"\",\"addressIdNumber\":\"\",\"county\":\"\"},\"primaryUserInfo\":{\"address\":{\"type\":\"\",\"city\":\"\",\"state\":\"\",\"zipCode\":\"30004\",\"zipCode4\":\"\",\"county\":\"\",\"countryCode\":\"US\"}},\"mtn\":\"newLine1\",\"newPricePlanInfo\":{\"categoryCode\":\"67\",\"pricePlanCode\":\"26872\",\"pricePlanDesc\":\"START UNLIMITED\",\"planPrice\":80.0,\"dataAllowance\":\"UNLIMITED\",\"featureText\":\"<ul style=\\\"list-style: none;\\\"><br/>\\r<li><strong>Plan features</strong></li>\\r<li>5G Nationwide<sup>1</sup></li>\\r<li>4G LTE<sup>2</sup></li></ul>\\r<ul style=\\\"list-style: none;\\\">\\r<li><strong>Plan perks</strong></li>\\r<li>Disney+ 6 months on us<sup>3</sup></li>\\r<li>Apple Music 6 months on us<sup>4</sup></li>\\r<li>discovery+ 6 months on us<sup>5</sup></li>\\r<li>Apple Arcade 6 months on us<sup>6</sup><li>\\r<li>OR Google Play Pass 6 months on us<sup>7</sup><li></ul>\\r<ul style=\\\"list-style: none;\\\">\\r<li><strong>All plans include</strong></li>\\r<li>Unlimited talk, text & data</li>\\r<li>Mexico & Canada talk, text, & data<sup>6</sup></li>\\r<li>International texting<sup>7</sup></li>\\r<li>Verizon Up rewards<sup>8</sup></li></ul>\\r<ul><small>\\r1. Requires a 5G-capable device.<br/>\\r2. Includes 480p video streaming. In times of congestion, data may be temporarily slower than other traffic.<br/>\\r3. Thereafter $7.99/mo + taxes. Ends automatically after 6 mos for NM residents.<br/>\\r4. Thereafter $9.99/mo + taxes. Ends automatically after 6 mos for NM residents.<br/>\\r5. Thereafter $6.99/mo + taxes. Ends automatically after 6 mos for NM residents.<br/>\\r6. Thereafter $4.99/mo + taxes. Ends automatically after 6 mos for NM residents.<br/>\\r7. Thereafter $4.99/mo + taxes. Ends automatically after 6 mos for NM residents.<br/>\\r8. Speeds are reduced to 2G after 0.5 GB/day. If over 50% of your usage in a 60-day period is in Mexico or Canada, use of services in those countries may be removed or limited. Includes Unlimited talk and text to Mexico and Canada from the US.<br/>\\r9. From the US to over 200 countries and territories worldwide.<br/>\\r10. Customers must enroll in Verizon Up through the My Verizon App.</small></ul>\"},\"selectedFeaturesList\":{\"featuresCount\":39,\"visFeature\":[{\"displayReceiptIndicator\":\"0\",\"visFeatureCode\":\"48526\",\"featureDesc\":\"Text Messaging Pay Per Message\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"MI\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"0\",\"visFeatureCode\":\"48553\",\"featureDesc\":\"Streamlined Billing\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"BL\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"1\",\"visFeatureCode\":\"66332\",\"featureDesc\":\"Decline Device Protection\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"Y\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"USER\",\"sfopackageGroupCode\":\"EQ\",\"protection\":true,\"callFilter\":false,\"declinedProtection\":true,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"0\",\"visFeatureCode\":\"68869\",\"featureDesc\":\"Caller ID\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"BF\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"0\",\"visFeatureCode\":\"68870\",\"featureDesc\":\"BUSY TRANSFER\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"BF\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"0\",\"visFeatureCode\":\"68871\",\"featureDesc\":\"Conference Calling\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"BF\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"0\",\"visFeatureCode\":\"68872\",\"featureDesc\":\"CALL DELIVERY\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"BF\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"0\",\"visFeatureCode\":\"68873\",\"featureDesc\":\"Call Waiting\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"BF\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"0\",\"visFeatureCode\":\"68874\",\"featureDesc\":\"No Answer / Busy Transfer\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"BF\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"0\",\"visFeatureCode\":\"68876\",\"featureDesc\":\"Call Forwarding\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"BF\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"0\",\"visFeatureCode\":\"73502\",\"featureDesc\":\"Unlimited Picture and Video Messaging\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"MP\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"0\",\"visFeatureCode\":\"73503\",\"featureDesc\":\"Unlimited TXT Messages\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"MS\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"0\",\"visFeatureCode\":\"74774\",\"featureDesc\":\"SDM REMOTE QUERY ENABLED\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"MI\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"0\",\"visFeatureCode\":\"75706\",\"featureDesc\":\"Pay Per Message\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"TP\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"0\",\"visFeatureCode\":\"75802\",\"featureDesc\":\"Dynamic-Private IP\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"TP\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"0\",\"visFeatureCode\":\"75836\",\"featureDesc\":\"4G INTERNET ACCESS\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"TP\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"0\",\"visFeatureCode\":\"75837\",\"featureDesc\":\"4G APPLICATION ACCESS\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"TP\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"0\",\"visFeatureCode\":\"77552\",\"featureDesc\":\"Block Mobile Hotspot/Pre-Provisioned Mobile Hotspot\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"VS\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"0\",\"visFeatureCode\":\"77556\",\"featureDesc\":\"4G PROVISIONING $0\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"TP\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"0\",\"visFeatureCode\":\"77568\",\"featureDesc\":\"EMAIL ACCESS PDA $0\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"TP\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"0\",\"visFeatureCode\":\"78706\",\"featureDesc\":\"ENHANCED ADDRESS BOOK\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"TP\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"0\",\"visFeatureCode\":\"78707\",\"featureDesc\":\"Video Calling\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"AC\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"0\",\"visFeatureCode\":\"78732\",\"featureDesc\":\"Basic Visual Voice Mail\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"VM\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"0\",\"visFeatureCode\":\"80148\",\"featureDesc\":\"International Messages While in US\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"MI\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"0\",\"visFeatureCode\":\"81158\",\"featureDesc\":\"HD Voice\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"AC\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"0\",\"visFeatureCode\":\"84094\",\"featureDesc\":\"International Services Enabled Lite\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"LE\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"0\",\"visFeatureCode\":\"85405\",\"featureDesc\":\"Entitlement for Unlimited\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"TP\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"0\",\"visFeatureCode\":\"85553\",\"featureDesc\":\"Verizon Cloud Eligible\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"VT\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"0\",\"visFeatureCode\":\"86189\",\"featureDesc\":\"Email and Web\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"DT\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"0\",\"visFeatureCode\":\"86192\",\"featureDesc\":\"RTR Go/Start Unlimited\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"TP\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"0\",\"visFeatureCode\":\"86195\",\"featureDesc\":\"RTR / UC Trigger Go/Start\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"TP\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"0\",\"visFeatureCode\":\"86209\",\"featureDesc\":\"Include Mexico & Canada in your domestic plan\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"DR\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"0\",\"visFeatureCode\":\"86225\",\"featureDesc\":\"AUTO CONFIGURATION $0\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"AS\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"0\",\"visFeatureCode\":\"86848\",\"featureDesc\":\"4G SERVICE ON 5G DEVICE\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"TP\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"displayReceiptIndicator\":\"0\",\"visFeatureCode\":\"86905\",\"featureDesc\":\"GSM Roaming Priority\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SFO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"sfopackageGroupCode\":\"TP\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"visFeatureCode\":\"1256\",\"featureDesc\":\"Includes Mexico & Canada with your domestic plan\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SPO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[\"MTXTPTRIG2\",\"GLOBAL\",\"MTXIPV6\",\"MUTEXGCM\",\"GB\",\"INTLDAILY\",\"MTXDITP\",\"COMGLB\"],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"visFeatureCode\":\"1692\",\"featureDesc\":\"5G Dynamic Spectrum Sharing\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SPO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[\"TP\"],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"visFeatureCode\":\"1801\",\"featureDesc\":\"Unlimited Plan Indicator\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SPO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[\"MI\"],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false},{\"visFeatureCode\":\"1958\",\"featureDesc\":\"Device Set-Up Support 60 Days\",\"addDeleteInd\":\"A\",\"currentDeviceCompatible\":false,\"customerSelected\":\"N\",\"level\":\"L\",\"type\":\"SPO\",\"featurePrice\":\"0.00\",\"source\":\"FOM\",\"protection\":false,\"callFilter\":false,\"declinedProtection\":false,\"imageUrlMap\":{},\"featureDiscounts\":[],\"categoryCodes\":[\"60DAYTRIAL\",\"MI\",\"TECHCOACH\"],\"minEligibleLines\":0,\"maxEligibleLines\":0,\"sddSetupEligible\":false}]},\"planDetails\":{\"planPrice\":80.0,\"planDiscounts\":[]},\"isSharePlanAdded\":false,\"kidsPlanParentMtn\":false,\"mcsSubscription\":[],\"unpairedGrantor\":false},\"itemsInfo\":[{\"depletionType\":\"F\",\"shipping\":{\"address\":{\"city\":\"\",\"state\":\"\",\"zipCode\":\"30004\",\"zipCode4\":\"\",\"county\":\"\",\"countryCode\":\"\",\"fipsCode\":\"1312101696\",\"emailId\":\"\"},\"isUseUnVerifiedAddress\":false,\"isValidAddress\":false},\"cartItems\":{\"cartItem\":[{\"discountAmount\":0.0,\"taxBasis\":\"F\",\"deviceDollarApplied\":0.0,\"promoHubOfferList\":{\"promoHubOfferList\":[],\"offerCount\":0},\"qrScanNeededForEsimActivation\":false,\"isPreconfigureDuringAddDevice\":false,\"deviceDisplayName\":\"NOTE20 ULTRA 5G COPPER 128GB\",\"accessoryGiftCardAmount\":0.0,\"itemPriceAfterVZDollar\":\"1299.99\",\"tradeInAmountTowardsUserDPUsed\":0.0,\"sorDeviceCategory\":\"5G Smartphone\",\"sorDeviceType\":\"5GE\",\"operatingSystem\":\"Android\",\"vendingKioskItem\":\"false\",\"tradeInAutoPull\":false,\"priceAdjustment\":false,\"priceAdjustmentQty\":0,\"newPurchasedQty\":0,\"canonicalUrl\":\"smartphones/samsung-galaxy-note-20-ultra-5g/\",\"selectedForRFEX\":false,\"selectedForPAD\":false,\"itemCode\":\"SMN986UZNV\",\"sorId\":\"SMN986UZNV\",\"skuId\":\"sku3990245\",\"cartItemType\":\"DEVICE\",\"mobileNumber\":\"newLine1\",\"description\":\"Galaxy Note20 Ultra 5G\",\"capacity\":\"128 GB\",\"qty\":1,\"deviceDueMonthly\":43.33,\"deviceDueToday\":43.42,\"bundleSeqNum\":0,\"itemPrice\":\"1299.99\",\"discountedPercentage\":0.0,\"discountedPrice\":1299.99,\"taxAmount\":100.75,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/samsung-3A14V1S2_MysticBronze\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/samsung-3A14V1S2_MysticBronze?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/samsung-3A14V1S2_MysticBronze?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/samsung-3A14V1S2_MysticBronze?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/samsung-3A14V1S2_MysticBronze?$device-thumb$\"},\"prodCode1\":\"5GD\",\"prodCode2\":\"SMT\",\"prodCode3\":\"DIG\",\"prodCode4\":\"VDS\",\"prodCode5\":\"ISL\",\"priceType\":\"VERIZON_EDGE\",\"btaEligible\":\"true\",\"depletionType\":\"F\",\"catalogPrice\":1299.99,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"color\":{\"color\":\"#9a716e\",\"colorDisplayName\":\"MYSTIC BRONZE\"},\"unitTaxBasedPrice\":1299.99,\"itemNrpPrice\":1299.99,\"itemCost\":1299.99,\"upgradeReasonCode\":\"\",\"upgradeReasonDesc\":\"Invalid Reason Code - 0yr\",\"itemPriceType\":\"R\",\"discounts\":[],\"availableReasonCode\":[],\"inventory\":{\"isAvailable\":true,\"isBackorder\":false,\"isDeliverBy\":false,\"isPreOrder\":false,\"qtyAvailable\":50943},\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":true,\"itemSeqNum\":1,\"sddEligible\":true,\"smartIMEI\":false,\"year\":0,\"sellerPrice\":\"0.0\",\"edgeDeviceCap\":\"1300\",\"productId\":\"dev13720073\",\"numberShareCapabilityInfo\":{\"sorHdVoiceInd\":true,\"isNumberShareCapable\":false,\"isNumberShareMandatory\":false},\"taxDetailsList\":[{\"taxSequenceNum\":1,\"taxPassType\":\"10\",\"taxAmount\":\"52.00\",\"taxDescription\":\"GA State Sales Tax\",\"taxType\":\"01\",\"mldSequenceNum\":1},{\"taxSequenceNum\":2,\"taxPassType\":\"22\",\"taxAmount\":\"48.75\",\"taxDescription\":\"Fulton Cnty Sales Tax\",\"taxType\":\"03\",\"mldSequenceNum\":2}],\"hasDeviceUnlockPolicy\":true,\"manufacturer\":\"Samsung\",\"iconicPhone\":false,\"ringBell\":false,\"isPreconfigureEnabled\":false,\"deviceStartDate\":\"10-18-2021 12:00:00 AM\",\"isHumDevice\":false,\"isSmartLocator\":false,\"isSecurityAlarm\":false,\"isMotoMod\":false,\"isConnectedCar\":false,\"accountLevelAccessory\":false,\"byodESimPhone\":false,\"appleCareAccessoryFlag\":false},{\"discountAmount\":0.0,\"deviceDollarApplied\":0.0,\"promoHubOfferList\":{\"promoHubOfferList\":[],\"offerCount\":0},\"qrScanNeededForEsimActivation\":false,\"isPreconfigureDuringAddDevice\":false,\"accessoryGiftCardAmount\":0.0,\"tradeInAmountTowardsUserDPUsed\":0.0,\"vendingKioskItem\":\"false\",\"tradeInAutoPull\":false,\"priceAdjustment\":false,\"priceAdjustmentQty\":0,\"newPurchasedQty\":0,\"selectedForRFEX\":false,\"selectedForPAD\":false,\"itemCode\":\"EMBDSIM5G\",\"sorId\":\"EMBDSIM5G\",\"cartItemType\":\"SIM\",\"description\":\"Virtual 4G 5G Interim SIM\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":\"0.0\",\"discountedPercentage\":0.0,\"discountedPrice\":0.0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":2,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0,\"sellerPrice\":\"0.0\",\"taxDetailsList\":[],\"iconicPhone\":false,\"ringBell\":false,\"isPreconfigureEnabled\":false,\"isHumDevice\":false,\"isSmartLocator\":false,\"isSecurityAlarm\":false,\"isMotoMod\":false,\"isConnectedCar\":false,\"accountLevelAccessory\":false,\"byodESimPhone\":false,\"appleCareAccessoryFlag\":false},{\"discountAmount\":0.0,\"deviceDollarApplied\":0.0,\"promoHubOfferList\":{\"promoHubOfferList\":[],\"offerCount\":0},\"qrScanNeededForEsimActivation\":false,\"isPreconfigureDuringAddDevice\":false,\"accessoryGiftCardAmount\":0.0,\"tradeInAmountTowardsUserDPUsed\":0.0,\"vendingKioskItem\":\"false\",\"tradeInAutoPull\":false,\"priceAdjustment\":false,\"priceAdjustmentQty\":0,\"newPurchasedQty\":0,\"selectedForRFEX\":false,\"selectedForPAD\":false,\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":\"0.0\",\"discountedPercentage\":0.0,\"discountedPrice\":0.0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":3,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0,\"sellerPrice\":\"0.0\",\"taxDetailsList\":[],\"iconicPhone\":false,\"ringBell\":false,\"isPreconfigureEnabled\":false,\"isHumDevice\":false,\"isSmartLocator\":false,\"isSecurityAlarm\":false,\"isMotoMod\":false,\"isConnectedCar\":false,\"accountLevelAccessory\":false,\"byodESimPhone\":false,\"appleCareAccessoryFlag\":false}]}}],\"installmentInfo\":{\"monthlyInstallmentBeforeDP\":43.33,\"deviceDollarDownpayment\":0.0,\"totalDppDiscount\":0.0,\"finalDppPrice\":43.33,\"installmentTerm\":30,\"downPayment\":\"0.0\",\"firstInstallment\":43.42,\"monthlyInstallment\":43.33,\"upgradeOptionCode\":\"DP\",\"percentage\":100,\"mandatoryDownPayment\":0.0,\"userSelectedDownPayment\":0.0,\"instantCreditDownPayment\":0.0,\"verizonDollarsDownpayment\":0.0},\"mtnDetails\":{\"dummyMTNForDomain\":\"9999999901\",\"lineNumber\":\"newLine1\",\"mobileNumber\":\"0000000000\"},\"lineNumber\":\"newLine1\",\"oneTimeCharges\":[{\"chargeType\":\"ActivationFee\",\"amount\":35.0,\"finalPrice\":\"35.0\"}],\"deviceTypeSelected\":\"5G Smartphone\",\"lineRefundTotal\":0.0,\"lineExchangeTotal\":0.0,\"totalDueMonthlyBeforeCredit\":123.33,\"totalDueTodayWithoutAccessory\":\"0.0\",\"isLTEHomeLine\":false,\"portinMtnAssignment\":false,\"preOrBackOrder\":false,\"ispuItem\":false,\"ispuItemBYOD\":false,\"isModConnected\":false,\"modDevice\":false,\"byodCapable\":false,\"broadBandInd\":false,\"ispuDownPaymentAdjstRequired\":false,\"ispuDownPaymentAmount\":0.0,\"protectionNotRequired\":false}],\"numOfAccessoryAndDeviceItemsInCart\":1,\"totalEdgeUpAmount\":0.0,\"totalEdgeBuyOutAmount\":0.0,\"tradeInDetail\":{},\"totalDownPaymentAmt\":0.0,\"planDiscount\":{\"planEligibleForAutoPayPaperLessDiscount\":false,\"discountIncluded\":false,\"totalPlanCostIncludingLineAccessFee\":\"0.0\"},\"payments\":[],\"lineSeq\":0,\"fivegOrderind\":false,\"isAutoPayEnrolled\":\"N\",\"isAutoPayPaperLessDiscountEligible\":\"Y\",\"isPaperLessEnrolled\":\"N\",\"totalEligibleAutoPayPaperLessDiscount\":\"10.00\",\"acctMcsSubscription\":[],\"numofAccessories\":0,\"subAccountNBSInfo\":[{\"billAccounts\":[{\"billSummary\":{\"grandTotal\":{\"newMonthCharge\":\"128.20\",\"nextMonthCharge\":\"163.29\"},\"planCharge\":{\"newMonthCharge\":\"80.00\",\"nextMonthCharge\":\"80.00\"},\"lineAccessFees\":{\"newMonthCharge\":\"0.00\",\"nextMonthCharge\":\"0.00\"},\"devicePayments\":{\"newMonthCharge\":\"43.33\",\"nextMonthCharge\":\"43.33\"},\"surcharges\":{\"newMonthCharge\":\"2.75\",\"nextMonthCharge\":\"2.75\"},\"taxesAndFees\":{\"newMonthCharge\":\"2.12\",\"nextMonthCharge\":\"2.12\"},\"totalAddOns\":{\"newMonthCharge\":\"0.00\",\"nextMonthCharge\":\"0.00\"},\"appleMusic\":{\"newMonthCharge\":\"0.00\",\"nextMonthCharge\":\"0.00\"},\"mobileProtection\":{\"newMonthCharge\":\"0.00\",\"nextMonthCharge\":\"0.00\"},\"planAccessFeeTotal\":{\"newMonthCharge\":\"80.00\",\"nextMonthCharge\":\"80.00\"},\"taxGrandTotal\":{\"newMonthCharge\":\"4.87\",\"nextMonthCharge\":\"4.87\"},\"subTotal\":{\"newMonthCharge\":\"123.33\",\"nextMonthCharge\":\"158.42\"},\"autoPayDiscount\":{\"accountTotalAutoPayDiscount\":\"10.00\",\"isCustomerEnrolledForAutopay\":false},\"dateRange\":{\"thisMonth\":\"10/25/2021-11/24/2021\",\"nextMonth\":\"11/25/2021-12/24/2021\"}},\"nbs\":{\"accountNumber\":\"999999999-99999\",\"nextBillCycleStartDate\":\"11/25/2021\",\"balancePastDue\":{\"pastDueAmount\":\"0.00\",\"paymentsReceived\":\"0\",\"previousBalance\":\"0.00\",\"balanceType\":\"Current Balance\",\"unbilledPayment\":\"0.00\",\"totUnpaidBalance\":\"0.00\",\"paymentMessage\":\"You've paid your bill amount of  $0.00. Thank you!\",\"unbilledOCC\":\"0.00\"},\"monthlyChargesInfo\":{\"accountLevelCharges\":[],\"accountLevelTotal\":{\"thisMonthCharge\":\"0.00\",\"nextMonthCharge\":\"0.00\",\"differenceBetweenThisMonthAndNextMonthCharge\":\"0.00\",\"totalOneTimeCharge\":\"0.00\",\"newMonthMrcWithNoAddOn\":\"0.00\",\"nextMonthMrcWithNoAddOn\":\"0.00\",\"nextMonthAcctLevelSurcharges\":\"0.00\",\"newMonthAcctLevelSurcharges\":\"0.00\",\"nextMonthAccountLevelTax\":\"0.00\",\"newMonthAccountLevelTax\":\"0.00\",\"chargeTotals\":[{\"itemRef\":\"Total Addons\",\"differenceBetweenThisAndNextMonthCharge\":\"0.00\",\"thisMonthCharge\":\"0.00\",\"nextMonthCharge\":\"0.00\"}]},\"mtnLevelChargeDetails\":[{\"mtn\":\"9999999901\",\"thisMonthCharge\":\"123.33\",\"nextMonthCharge\":\"158.42\",\"differenceBetweenThisMonthAndNextMonthCharge\":\"35.09\",\"thisMonthSurcharges\":\"2.75\",\"previousMonthCharge\":\"0.00\",\"nextMonthSurcharges\":\"2.75\",\"differenceBetweenThisMonthAndNextMonthSurcharges\":\"0.00\",\"thisMonthTax\":\"2.12\",\"nextMonthTax\":\"2.12\",\"differenceBetweenThisMonthAndNextMonthTax\":\"0.00\",\"chargeDetails\":[{\"thisMonthCharge\":\"80.00\",\"nextMonthCharge\":\"80.00\",\"chargeRefId\":\"26872\",\"description\":\"START UNLIMITED\",\"itemType\":[{\"accequipment\":false,\"equipment\":false,\"feature\":false,\"naf\":false,\"occ\":false,\"plan\":false,\"promo\":false,\"sfo\":false,\"spo\":false,\"addOn\":false}],\"differenceBetweenThisMonthAndNextMonthCharge\":\"0.00\",\"listPrice\":\"80.00\",\"netPrice\":\"80.00\",\"promo1Id\":\"0\",\"promo1Discount\":\"0.00\",\"promo2Id\":\"0\",\"promo2Discount\":\"0.00\",\"promo3Id\":\"0\",\"promo3Discount\":\"0.00\"},{\"thisMonthCharge\":\"43.33\",\"nextMonthCharge\":\"43.33\",\"description\":\"Device Payment\",\"itemType\":[{\"accequipment\":false,\"equipment\":false,\"feature\":false,\"naf\":false,\"occ\":false,\"plan\":false,\"promo\":false,\"sfo\":false,\"spo\":false,\"addOn\":false}],\"differenceBetweenThisMonthAndNextMonthCharge\":\"0.00\",\"listPrice\":\"43.33\",\"netPrice\":\"43.33\",\"loanNumber\":\"0\",\"nextInstallmentNumber\":\"1\",\"totalInstallmentNumber\":\"30\",\"outstandingLoanAmount\":\"1256.57\",\"loanAmount\":\"1299.99\"}],\"oneTimeChargeDetails\":[{\"thisMonthCharge\":\"0.00\",\"nextMonthCharge\":\"0.00\",\"chargeRefId\":\"0\",\"description\":\"Activation Fee\",\"itemType\":[{\"accequipment\":false,\"equipment\":false,\"feature\":false,\"naf\":false,\"occ\":false,\"plan\":false,\"promo\":false,\"sfo\":false,\"spo\":false,\"addOn\":false}],\"listPrice\":\"0.00\",\"netPrice\":\"0.00\",\"recurringIndicator\":\"N\",\"balanceDueIndicator\":\"N\"}],\"nickname\":\"\",\"suppressAdvInd\":\"N\",\"newMonthMtnMrcWithNoAddOn\":\"123.33\",\"nextMonthMtnMrcWithNoAddOn\":\"123.42\",\"newMonthGrandTotalWithTaxes\":\"128.20\",\"nextMonthGrandTotalWithTaxes\":\"163.29\",\"chargeTotals\":[{\"itemRef\":\"PPLAN\",\"differenceBetweenThisAndNextMonthCharge\":\"0.00\",\"thisMonthCharge\":\"80.00\",\"nextMonthCharge\":\"80.00\"},{\"itemRef\":\"Equipment\",\"differenceBetweenThisAndNextMonthCharge\":\"0.00\",\"thisMonthCharge\":\"43.33\",\"nextMonthCharge\":\"43.33\"}],\"mtnChangeInd\":false}],\"accountLevelOneTimeCharges\":[]},\"monthlyTotalsInfo\":{\"thisMonthCharge\":\"128.20\",\"thisMonthChargeDateRange\":\"10/25/2021-11/24/2021\",\"nextMonthCharge\":\"163.29\",\"nextMonthChargeDateRange\":\"11/25/2021-12/24/2021\",\"differenceBetweenThisMonthAndNextMonthCharge\":\"35.09\",\"previousCycleFormattedDateRange\":\"Sep 25,2021 - Oct 24,2021\"},\"surchargesInfo\":{\"thisMonthCharge\":2.75,\"nextMonthCharge\":2.75,\"differenceBetweenThisMonthAndNextMonthSurcharges\":\"0.00\"},\"taxesAndFeesInfo\":{\"thisMonthCharge\":2.12,\"nextMonthCharge\":2.12,\"differenceBetweenThisMonthAndNextMonthTax\":\"0.00\"},\"autoPayDiscount\":{\"accountTotalAutoPayDiscount\":\"10.00\",\"isCustomerEnrolledForAutopay\":false},\"barGraphDetails\":{\"invoiceCount\":\"0\",\"invoiceLastMonth\":\"0.00\",\"invoiceLastMonthCycleEnddate\":\"\",\"invoiceTwoMonthPrevious\":\"0.00\",\"invoiceTwoMonthCycleEnddate\":\"\"},\"nbsIndicators\":{\"languageIndicator\":\"E\",\"partialBillIndicator\":\"N\"}},\"billAccountNo\":\"99999\"}]}]},\"globalPromotions\":{},\"verizonUpToastMessage\":{\"toastMessages\":[],\"eligibleProducts\":[]},\"cartValidationErrors\":[{\"errorCategory\":\"Cart\",\"errorLevel\":\"Warning\",\"errorCode\":\"1001\",\"errorMessage\":\"Cart Creator is missing in CartHeader\",\"fieldPath\":\"\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Warning\",\"errorCode\":\"1005\",\"errorMessage\":\"Primary EmailID is missing in cart orderdetails\",\"fieldPath\":\"\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Warning\",\"errorCode\":\"1006\",\"errorMessage\":\"Contact PhoneNumber is missing in cart orderdetails\",\"fieldPath\":\"\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Warning\",\"errorCode\":\"1076\",\"errorMessage\":\"Select soft credit check\",\"fieldPath\":\"\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Warning\",\"errorCode\":\"1010\",\"errorMessage\":\"NPANXX Number is not assigned to AAL line in the cart\",\"fieldPath\":\"newLine1\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Warning\",\"errorCode\":\"1014\",\"errorMessage\":\"First Name is missing in shipping addresstype\",\"fieldPath\":\"newLine1\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Warning\",\"errorCode\":\"1015\",\"errorMessage\":\"Last Name is missing in shipping addresstype\",\"fieldPath\":\"newLine1\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Warning\",\"errorCode\":\"1016\",\"errorMessage\":\"Email Address is missing in shipping addresstype\",\"fieldPath\":\"newLine1\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Warning\",\"errorCode\":\"1017\",\"errorMessage\":\"Phone Number is missing in shipping addresstype\",\"fieldPath\":\"newLine1\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Warning\",\"errorCode\":\"1075\",\"errorMessage\":\"Enter personal and payment information\",\"fieldPath\":\"\"}],\"accountEligibility\":false},\"warningMessages\":[],\"redesignFlow\":false,\"orderPlaced\":false,\"validateCart\":false},\"meta\":{\"timestamp\":\"1635149369083\",\"cxpCorrelationId\":\"2021-10-25T08:09:29.+0000:5f5cd468-4bab-4d3b-b4ba-2bffbe5e879e:cxp-shopping-services-qa-ev6v-sit1e-nscxp-796bbcb799-8m6fn:nssit1\"}}";
        RetrieveCartCXPRequest request = mapper.readValue(requestString, RetrieveCartCXPRequest.class);
        RetrieveCartUIResponse response = mapper.readValue(responseString, RetrieveCartUIResponse.class);
        URI url = URI.create("http://localhost/nse/retrieve-cart");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(readCartHelper.retrieveCart(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.upsertRetrieveCartDataIntoRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper.upsertCartResponseToSession(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.nseRetrieveCart(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void retrieveCartTest5() throws IOException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"VZW-DOTCOM\",\"type\":\"CUSTOMER\"},\"data\":{\"cartId\":\"55d59c3e-26aa-4b1f-9996-525737615858\"}}";
        String responseString = "{\"data\": {\"cart\": {\"customerProfile\": {},\"cartHeader\": {\"winBackAccountNumber\": \"\",\"referralSaleRepId\": \"\",\"ecpdToken\": \"\",\"adobeId\": \"\",\"vendorId\": \"NETACE\",\"referralVendorId\": \"\",\"d2dFlag\": \"N\",\"sourceSystem\": \"OMNI-RETAIL\",\"cartId\": \"077d51dd-0511-4e87-bc34-3de25cf18ef8\",\"status\": \"A\",\"createTimestamp\": \"2021-11-16T06:52:54.935671-05:00[US/Eastern]\",\"lastUpdateTimestamp\": \"2021-11-16T06:57:23.139929-05:00[US/Eastern]\",\"cartCreator\": \"\",\"cartCreatorChannelId\": \"OMNI-RETAIL\",\"cartCreatorOrderLocationCode\": \"0026301\",\"cartCreatorSalesRepId\": \"ENC\",\"caseId\": \"SOP-4465635-E01\",\"visionCustomerType\": \"PE\",\"maverickLocation\": false,\"preConfiguredCartType\": \"BAU\",\"preConfiguredCartTypeDuringAddDevice\": \"BAU\",\"isCoreRep\": false},\"orderDetails\": {\"totalUpgradeFee\": 0.0,\"totalDeviceDollar\": 0.0,\"totalRemainingDeviceDollar\": 0.0,\"totalUsedDeviceDollar\": 0.0,\"totalAccountLevelAccCost\": 0.0,\"totalAccountLevelAccCostWithTax\": 0.0,\"totalShippingCost\": 0.0,\"totalDiscountedShippingCost\": 0.0,\"hqUser\": false,\"returnException\": false,\"taxDetailsList\": [],\"subTotalDueTodayWithoutUpgradeFee\": 0.0,\"subTotalDueMonthlyForAALBYODEUP\": 0.0,\"shipTogetherPref\": true,\"assistanceOptedByCustomer\": false,\"locationState\": \"NJ\",\"totalVerizonDollarUsed\": \"0.0\",\"isShellAccountSelected\": false,\"fullfillmentLocation\": \"1000001\",\"guestOrInactiveRefundLines\": false,\"totalDueMonthlyOnProfile\": 0.0,\"subTotalDueMonthlyOnProfile\": 0.0,\"totalMonthlyTaxesOnProfile\": 0.0,\"subTotalOtherLinesOnProfile\": 0.0,\"estimatedNextMonthChargeOnProfile\": 0.0,\"originalSubTotalDueMonthly\": 0.0,\"totalDueMonthlyAfterDiscounts\": 0.0,\"refundNotifications\": {\"notificationEmail\": \"POS@VZW.COM\",\"emailIds\": [\"POS@VZW.COM\"],\"phoneNumbers\": []},\"totalSurchargeAmount\": \"0.0\",\"orderType\": \"PS\",\"locationCode\": \"0026301\",\"customerType\": \"N\",\"billingSystem\": \"VN\",\"totalTaxAmount\": \"0.0\",\"spocs\": {\"notificationOptions\": {\"primaryEmailId\": \"POS@VZW.COM\"}},\"totalDueToday\": 0.0,\"runningTotalDueToday\": 0.0,\"totalDueTodayFlag\": true,\"totalDueMonthly\": 0.0,\"subTotalDueMonthly\": 0.0,\"subTotalDueToday\": 0.0,\"subTotalMonthlyTaxes\": 0.0,\"estimatedNextMonthCharge\": 0.0,\"totalMonthlyTaxes\": 0.0,\"subTotalOtherLines\": 0.0,\"subTotalOtherLinesTaxes\": 0.0,\"instantDRCCredit\": false,\"isAttachmentCompleted\": false,\"nextMonthBillTotal\": 0.0,\"customerNotification\": {\"smsLanguage\": \"E\"},\"orderChannelId\": \"OMNI-RETAIL\",\"orderList\": [{\"creditApplication\": {\"creditApplicationNum\": 428037738,\"creditApprovalStatus\": \"AP\",\"creditStatusReason\": \"CA CVAS AUTOMATIC APPROVAL\",\"internationalEligibility\": false,\"securityDepositAmount\": \"0\",\"serviceClass\": \"B\",\"lineCreditClass\": \"1D\"},\"orderActivityType\": \"NSE\",\"orderNumber\": 0,\"numOfLinesForOrderActivityType\": 1,\"preOrderNumber\": 0,\"managerApprovalRequired\": false}],\"outletId\": \"000000263\",\"registerNumber\": \"13\",\"saleType\": \"P\",\"salesRepId\": \"ENC\",\"enableSplitShipment\": false,\"splitShipmentIndicator\": false,\"isSingleModConnectedDevice\": false,\"fiveGUpSellAccountLevel\": false,\"customerOnTrialPlan\": false,\"totalDownPaymentAmt\": 0.0,\"totalEdgeBuyOutAmount\": 0.0,\"expressCheckout\": false,\"nbxInfo\": {\"isPreQualifiedNBX\": true,\"syfOfferId\": \"8803458027\",\"propositionMessage\": \"Thank You! You have been Pre-Approved.Sign up and receive: $100 sign up bonus and more\",\"propositionName\": \"Pre-Qualified - Transaction Flow\",\"propositionId\": \"GC_01\",\"isVZCCHolder\": false,\"isPreScreenRepresentment\":\"true\",\"sessionId\": \"8483170179439212780\"},\"isEQPandPPLOfferApplied\": false,\"cartTotalDiscounts\": {\"totalDiscount\": \"0.0\",\"discountDetails\": []},\"memberTotalDueToday\": 0.0,\"customerConsent\": \"Y\",\"totalDwosCost\": \"0.0\",\"billingState\": \"NJ\",\"isTradeInOfferSelected\": false,\"homePhone\": \"9879879879\",\"isAssignMtnRequired\": false,\"fiosCapable\": false,\"fiosEligible\": false,\"quoteWithoutCredit\": false},\"lineDetails\": {\"lineInfo\": [{\"multiLineSeqNumber\": 1,\"lineActivityType\": \"NSE_5G\",\"totalDueToday\": 0.0,\"totalDueTodayWithoutTax\": 0.0,\"totalDueMonthly\": 80.0,\"mobileNumber\": \"8627041933\",\"showGlobalChoiceOffer\": false,\"serviceInfo\": {\"otherPromotions\": [],\"primaryUserInfo\": {\"firstName\": \"POSTESTFBV\",\"lastName\": \"USEROJP\",\"address\": {\"streetNumber\": \"30\",\"streetName\": \"INDEPENDENCE\",\"addressLine1\": \"30 INDEPENDENCE BL\",\"city\": \"WARREN\",\"state\": \"NJ\",\"zipCode\": \"07059\",\"zipCode4\": \"6747\",\"county\": \"\",\"countryCode\": \"US\",\"fipsCode\": \"3403576940\",\"emailId\": \"POS@VZW.COM\",\"phoneNumber\": \"9879879879\",\"streetType\": \"BL\"},\"contactPersonPhone\": \"9879879879\",\"emailId\": \"POS@VZW.COM\"},\"cart5GAddress\": {\"type\": \"all\",\"streetNumber\": \"30\",\"streetName\": \"INDEPENDENCE\",\"addressLine2\": \"\",\"addressLine1\": \"1 VERIZON WAY  \",\"city\": \"BASKING RIDGE\",\"state\": \"NJ\",\"zipCode\": \"07920\",\"zipCode4\": \"1025\",\"countryCode\": \"\",\"emailId\": \"POS@VZW.COM\",\"phoneNumber\": \"9879879879\",\"streetType\": \"DR\",\"floor\": 0,\"eventCorrelationId\": \"07920_1637063710309_487\"},\"cart5GAppointment\": {\"installApptSelectedDate\": {\"selfInstallDate\": \"11/21/2021\"}},\"mtn\": \"8627041933\",\"min\": \"9738773139\",\"newPricePlanId\": \"39425\",\"contractTermId\": \"48\",\"newPricePlanInfo\": {\"pricePlanCategory\": \"N\",\"ratePlanType\": \"L\",\"accessFeeRange\": \"0\",\"categoryCode\": \"74\",\"contractRange\": \"-1\",\"contractDuration\": 0,\"pricePlanCode\": \"39425\",\"pricePlanDesc\": \"5G HOME INTERNET\",\"contractTermId\": \"48\",\"imageUrlMap\": {},\"planPrice\": 80.0},\"selectedFeaturesList\": {\"featuresCount\": 0,\"visFeature\": []},\"planDetails\": {\"planPrice\": 80.0,\"planDiscounts\": []},\"currentDevice\": {},\"isSharePlanAdded\": false,\"mea\": \"AOR\",\"dacc\": \"01425\",\"isE911AddressValidated\": false,\"isFreeAppleMusicLoss\": \"N\",\"newBgsa\": \"978\",\"newPlanFlag\": \"L\",\"orderDevice\": {\"lteVoraEquipInfo\": {\"lteEqpt\": {},\"lteVoraDeviceInfo\": {\"deviceType\": \"5GF\"}}},\"kidsPlanParentMtn\": false,\"mcsSubscription\": [],\"fiveGUpSell\": false,\"e911AddressSameAsServiceAddress\": false,\"unpairedGrantor\": false},\"itemsInfo\": [{\"depletionType\": \"F\",\"attention\": \"POSTESTFBV USEROJP\",\"shipping\": {\"address\": {\"type\": \"all\",\"streetNumber\": \"30\",\"streetName\": \"INDEPENDENCE\",\"addressLine2\": \"\",\"addressLine1\": \"1 VERIZON WAY  \",\"city\": \"BASKING RIDGE\",\"state\": \"NJ\",\"zipCode\": \"07920\",\"zipCode4\": \"1025\",\"county\": \"\",\"countryCode\": \"\",\"emailId\": \"POS@VZW.COM\",\"phoneNumber\": \"9879879879\",\"streetType\": \"DR\"},\"cbrPhone\": \"9879879879\",\"firstName\": \"POSTESTFBV\",\"lastName\": \"USEROJP\",\"isUseUnVerifiedAddress\": false,\"isValidAddress\": false,\"email\": \"POS@VZW.COM\"},\"fipsCode\": \"3403576940\",\"itemCount\": 1,\"itemTabSeqNum\": 0,\"cartItems\": {\"cartItem\": [{\"discountAmount\": 0.0,\"deviceDollarApplied\": 0.0,\"qrScanNeededForEsimActivation\": false,\"isPreconfigureDuringAddDevice\": false,\"accessoryGiftCardAmount\": 0.0,\"tradeInAmountTowardsUserDPUsed\": 0.0,\"sorDeviceType\": \"5GF\",\"vendingKioskItem\": \"false\",\"tradeInAutoPull\": false,\"priceAdjustment\": false,\"priceAdjustmentQty\": 0,\"newPurchasedQty\": 0,\"networkBandwidthType\": \"MMW\",\"selectedForRFEX\": false,\"selectedForPAD\": false,\"bogoItem\": false,\"itemCode\": \"LVSKIHP\",\"totalPriceWithDiscount\": 0.0,\"sorId\": \"LVSKIHP\",\"cartItemType\": \"DEVICE\",\"mobileNumber\": \"8627041933\",\"minNumber\": \"9738773139\",\"description\": \"5G Internet Gateway\",\"qty\": 1,\"bundleSeqNum\": 0,\"itemPrice\": \"0.0\",\"discountedPercentage\": 0.0,\"discountedPrice\": 0.0,\"taxAmount\": 0.0,\"imageUrlMap\": {\"defaultImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/verizon-gemini-5g-internet-gateway-gen-3-high-power-cpe-lvskihp\",\"largeImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/verizon-gemini-5g-internet-gateway-gen-3-high-power-cpe-lvskihp?$device-lg$\",\"mediumImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/verizon-gemini-5g-internet-gateway-gen-3-high-power-cpe-lvskihp?$device-med$\",\"miniImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/verizon-gemini-5g-internet-gateway-gen-3-high-power-cpe-lvskihp?$device-mini$\",\"thumbImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/verizon-gemini-5g-internet-gateway-gen-3-high-power-cpe-lvskihp?$device-thumb$\"},\"prodCode1\": \"5GD\",\"prodCode2\": \"NIC\",\"prodCode3\": \"5IR\",\"prodCode4\": \"B2B\",\"prodCode5\": \"RNT\",\"priceType\": \"MONTH_TO_MONTH\",\"btaEligible\": \"true\",\"depletionType\": \"F\",\"catalogPrice\": 0.0,\"instantCreditAmountUsed\": 0.0,\"instantCreditAmountUsedForTaxes\": 0.0,\"itemNrpPrice\": 0.0,\"itemCost\": 0.0,\"itemPriceType\": \"R\",\"discounts\": [],\"availableReasonCode\": [],\"inventory\": {\"isAvailable\": true,\"isBackorder\": false,\"isPreOrder\": false,\"qtyAvailable\": 1000},\"isCustomerProvidedSIM\": false,\"isNetworkExtender\": false,\"ispuEligible\": true,\"itemSeqNum\": 1,\"sddEligible\": true,\"smartIMEI\": false,\"year\": 0,\"sellerPrice\": \"0.0\",\"edgeDeviceCap\": \"750\",\"productId\": \"16900001\",\"taxDetailsList\": [],\"iconicPhone\": false,\"ringBell\": false,\"isPreconfigureEnabled\": false,\"isHumDevice\": false,\"isSmartLocator\": false,\"isSecurityAlarm\": false,\"isMotoMod\": false,\"isConnectedCar\": false,\"accountLevelAccessory\": false,\"byodESimPhone\": false,\"appleCareAccessoryFlag\": false},{\"discountAmount\": 0.0,\"deviceDollarApplied\": 0.0,\"qrScanNeededForEsimActivation\": false,\"isPreconfigureDuringAddDevice\": false,\"accessoryGiftCardAmount\": 0.0,\"tradeInAmountTowardsUserDPUsed\": 0.0,\"vendingKioskItem\": \"false\",\"tradeInAutoPull\": false,\"priceAdjustment\": false,\"priceAdjustmentQty\": 0,\"newPurchasedQty\": 0,\"selectedForRFEX\": false,\"selectedForPAD\": false,\"bogoItem\": false,\"itemCode\": \"NI-DPSIM\",\"totalPriceWithDiscount\": 0.0,\"sorId\": \"NI-DPSIM\",\"cartItemType\": \"SIM\",\"qty\": 1,\"bundleSeqNum\": 0,\"itemPrice\": \"0.0\",\"discountedPercentage\": 0.0,\"discountedPrice\": 0.0,\"instantCreditAmountUsed\": 0.0,\"instantCreditAmountUsedForTaxes\": 0.0,\"discounts\": [],\"availableReasonCode\": [],\"isCustomerProvidedSIM\": false,\"isNetworkExtender\": false,\"ispuEligible\": false,\"itemSeqNum\": 2,\"sddEligible\": false,\"smartIMEI\": false,\"year\": 0,\"sellerPrice\": \"0.0\",\"taxDetailsList\": [],\"iconicPhone\": false,\"ringBell\": false,\"isPreconfigureEnabled\": false,\"isHumDevice\": false,\"isSmartLocator\": false,\"isSecurityAlarm\": false,\"isMotoMod\": false,\"isConnectedCar\": false,\"accountLevelAccessory\": false,\"byodESimPhone\": false,\"appleCareAccessoryFlag\": false},{\"discountAmount\": 0.0,\"deviceDollarApplied\": 0.0,\"qrScanNeededForEsimActivation\": false,\"isPreconfigureDuringAddDevice\": false,\"accessoryGiftCardAmount\": 0.0,\"tradeInAmountTowardsUserDPUsed\": 0.0,\"vendingKioskItem\": \"false\",\"tradeInAutoPull\": false,\"priceAdjustment\": false,\"priceAdjustmentQty\": 0,\"newPurchasedQty\": 0,\"selectedForRFEX\": false,\"selectedForPAD\": false,\"bogoItem\": false,\"itemCode\": \"WAR6002\",\"totalPriceWithDiscount\": 0.0,\"sorId\": \"WAR6002\",\"cartItemType\": \"WARRANTY\",\"qty\": 1,\"bundleSeqNum\": 0,\"itemPrice\": \"0.0\",\"discountedPercentage\": 0.0,\"discountedPrice\": 0.0,\"instantCreditAmountUsed\": 0.0,\"instantCreditAmountUsedForTaxes\": 0.0,\"discounts\": [],\"availableReasonCode\": [],\"isCustomerProvidedSIM\": false,\"isNetworkExtender\": false,\"ispuEligible\": false,\"itemSeqNum\": 3,\"sddEligible\": false,\"smartIMEI\": false,\"year\": 0,\"sellerPrice\": \"0.0\",\"taxDetailsList\": [],\"iconicPhone\": false,\"ringBell\": false,\"isPreconfigureEnabled\": false,\"isHumDevice\": false,\"isSmartLocator\": false,\"isSecurityAlarm\": false,\"isMotoMod\": false,\"isConnectedCar\": false,\"accountLevelAccessory\": false,\"byodESimPhone\": false,\"appleCareAccessoryFlag\": false}]},\"depletionLocation\": \"\",\"isPromoSelected\": false,\"isTradeInSelected\": false,\"taxExemptionTypes\": \"\"}],\"assignMTNIndicator\": \"Y\",\"mtnDetails\": {\"dummyMTNForDomain\": \"9999999901\",\"lineNumber\": \"newLine1\",\"minNumber\": \"9738773139\",\"mobileNumber\": \"8627041933\",\"assignMTNTimestamp\": \"2021-11-16T06:56:26.897813-05:00[US/Eastern]\",\"npaNXX\": \"862704\"},\"securityDepositAmount\": \"0\",\"lineNumber\": \"newLine1\",\"fiveGToFourGDownGrade\": false,\"deviceTypeSelected\": \"5G Internet\",\"reasonCode\": \"PLAN_DEVICE_COMPATIBLE\",\"launchType\": \"FCL\",\"lineRefundTotal\": 0.0,\"lineExchangeTotal\": 0.0,\"totalDueMonthlyBeforeCredit\": 0.0,\"isCpe\": false,\"isLTEHomeLine\": false,\"isDevicePlanCompatible\": true,\"portinMtnAssignment\": false,\"impactedLine\": false,\"preOrBackOrder\": false,\"ispuItem\": false,\"ispuItemBYOD\": false,\"isModConnected\": false,\"modDevice\": false,\"byodCapable\": false,\"isCarLine\": false,\"buySimOnly\": false,\"broadBandInd\": false,\"ispuDownPaymentAdjstRequired\": false,\"ispuDownPaymentAmount\": 0.0,\"lineWithSkipMDN\": false,\"protectionNotRequired\": false}],\"numOfAccessoryAndDeviceItemsInCart\": 1,\"totalEdgeUpAmount\": 0.0,\"totalEdgeBuyOutAmount\": 0.0,\"tradeInDetail\": {},\"totalDownPaymentAmt\": 0.0,\"numOfLinesWithDevices\": 1,\"numofApprovedLines\": 0,\"rfexPayments\": [],\"cartId\": \"077d51dd-0511-4e87-bc34-3de25cf18ef8\",\"numOfLines\": 1,\"numofLinesAAL\": 0,\"numofLinesEUP\": 0,\"payments\": [],\"lineSeq\": 0,\"vlcactivePhoneCount\": 0,\"fivegOrderind\": true,\"aceOrderCreated\": false,\"serviceLinesCreated\": false,\"aceItemsModified\": false,\"clnrOrderFlag\": false,\"broadbandInd\": false,\"acctMcsSubscription\": [],\"spendingLimitAmountExceededBy\": \"0.0\",\"numofAccessories\": 0,\"subAccountNBSInfo\": []},\"accountEligibility\": false,\"displayCartValidationErrors\": true},\"warningMessages\": [],\"basicORSmartPhoneExists\": false,\"fiveGDeviceORLTEHomeExists\": true,\"redesignFlow\": false,\"orderPlaced\": false,\"validateCart\": false},\"meta\": {\"timestamp\": \"1637063846283\",\"cxpCorrelationId\": \"2021-11-16T11:57:26.+0000:6a3027a3-8396-4761-b3cf-c952d76ee702:cxp-shopping-services-qa-ev6v-sit2w-nscxp-6b5fc85895-6fk9d:nssit2\"}}";
        RetrieveCartCXPRequest request = mapper.readValue(requestString, RetrieveCartCXPRequest.class);
        RetrieveCartUIResponse response = mapper.readValue(responseString, RetrieveCartUIResponse.class);
        URI url = URI.create("http://localhost/retrieve-cart");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        when(readCartHelper.retrieveCart(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.upsertRetrieveCartDataIntoRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper.upsertCartResponseToSession(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.retrieveCart(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void retrieveCartTest6() throws IOException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"VZW-DOTCOM\"},\"data\":{\"cartId\":\"55d59c3e-26aa-4b1f-9996-525737615858\"}}";
        String responseString = "{\"data\": {\"warningMessages\": [],\"basicORSmartPhoneExists\": false,\"fiveGDeviceORLTEHomeExists\": true,\"redesignFlow\": false,\"orderPlaced\": false,\"validateCart\": false},\"meta\": {\"timestamp\": \"1637063846283\",\"cxpCorrelationId\": \"2021-11-16T11:57:26.+0000:6a3027a3-8396-4761-b3cf-c952d76ee702:cxp-shopping-services-qa-ev6v-sit2w-nscxp-6b5fc85895-6fk9d:nssit2\"}}";
        RetrieveCartCXPRequest request = mapper.readValue(requestString, RetrieveCartCXPRequest.class);
        RetrieveCartUIResponse response = mapper.readValue(responseString, RetrieveCartUIResponse.class);
        URI url = URI.create("http://localhost/retrieve-cart");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        when(readCartHelper.retrieveCart(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.upsertRetrieveCartDataIntoRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper.upsertCartResponseToSession(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.retrieveCart(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void validateOrderTest3() throws IOException {
        String requestString = "{\"cartInfo\":{\"processingMTN\":\"\",\"locationCode\":\"\",\"customerType\":\"N\",\"standaloneBYOD\":false,\"intendType\":\"NSE\",\"processStep\":\"OrderReview\",\"processAction\":\"validateOrder\",\"flowType\":\"VANITY\"}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.06.01.10.39.12-106.04065964449005\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"OrderReview\",\"processAction\":\"\",\"availablePaths\":[]},\"cartInfo\":{},\"customerInfo\":{\"customerType\":\"N\",\"originalCreditApprovalNumber\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-2b9c5523-35af-4bd3-a443-01a5e2364809\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"cradleFlowJourney\":\"AccessoryInterestialProspectBYOD\",\"mtnFlow\":\"D\",\"editFromPage\":\"\",\"globalId\":\"POE-D-2b9c5523-35af-4bd3-a443-01a5e2364809\"},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"BYODDeviceIDPage\",\"BYODSimIDPage\",\"PromoHub\",\"NewRecommendedPlanSelection\",\"DeviceConfigurator\",\"BYODDeviceIDPage\",\"BYODSimIDPage\",\"PromoHub\",\"ContactInfo\",\"EligibilityReview\",\"AssignNumbers\",\"Agreement\",\"OrderReview\"]}],\"validateOrder\":{\"orderDetails\":[{\"lineActivityType\":\"\",\"mtnDetailsList\":[{\"simIdProvided\":\"true\",\"mtn\":\"newLine1\",\"deviceIdProvided\":\"true\",\"ispuItem\":false,\"lineActivityType\":\"NSEBYOD\",\"lostORStolen\":\"false\"}],\"orderActivityType\":\"NSE\",\"cpcType\":\"noCPCLines\",\"removeble\":false,\"creditFailureCount\":0,\"maxCreditFailuresAllowed\":0,\"creditApplicationNum\":\"999999000\",\"orderStatus\":\"SUCCESS\",\"shipmentAddressValidated\":true,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CA CVAS AUTOMATIC APPROVAL\",\"securityDepositAmount\":\"0\",\"loveligibility\":false,\"showConflicts\":false,\"idialFeaturePresent\":false}],\"cartId\":\"\",\"locationCode\":\"\",\"orderType\":\"PS\",\"saleType\":\"P\",\"totalDueMonthly\":94.24,\"totalDownPaymentAmt\":0.0,\"externalProgramEligibilityCheck\":false,\"programEligibilityStatus\":\"\",\"managerApprovalForDiscount\":false,\"tradeInType\":\"\",\"readyForOrderSubmit\":false,\"errorDesc\":\"\",\"errorCode\":\"\",\"contactInfoAvailable\":true,\"creditCheckCompleted\":true,\"numberAssignmentDone\":true,\"accountPinAvailable\":true,\"shipmentMethodSelected\":false,\"paymentCompleted\":true,\"tncAccepted\":true,\"paymentRequired\":false,\"effectivePlanDateValid\":false,\"downpaymentRequired\":false,\"managerApproval\":false,\"prefferedPricingOptions\":false}}}}}";
        InitiateCheckoutUIRequest request = mapper.readValue(requestString, InitiateCheckoutUIRequest.class);
        InitiateCheckoutUIResponse response = mapper.readValue(responseString, InitiateCheckoutUIResponse.class);
        URI url = URI.create("http://localhost/validateOrder");
        HttpCookie httpCookie = new HttpCookie("digital_ig_session", "bcba6c6c-afd9-4a59-b0dd-99b82fcf2ec9");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-TELESALES").cookie(httpCookie).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.validateOrder(Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.validateOrder(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
        StepVerifier.create(cartController.validateOrder(httpHeader, httpResponse, request)).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void validateOrderTest4() throws IOException {
        String requestString = "{\"cartInfo\":{\"quoteId\":\"1234\",\"processingMTN\":\"\",\"locationCode\":\"\",\"customerType\":\"N\",\"standaloneBYOD\":false,\"intendType\":\"BYOD\",\"processStep\":\"OrderReview\",\"processAction\":\"validateOrder\",\"flowType\":\"VANITY\"}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.06.01.10.39.12-106.04065964449005\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"OrderReview\",\"processAction\":\"\",\"availablePaths\":[]},\"cartInfo\":{},\"customerInfo\":{\"customerType\":\"N\",\"originalCreditApprovalNumber\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-2b9c5523-35af-4bd3-a443-01a5e2364809\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"cradleFlowJourney\":\"AccessoryInterestialProspectBYOD\",\"mtnFlow\":\"D\",\"editFromPage\":\"\",\"globalId\":\"POE-D-2b9c5523-35af-4bd3-a443-01a5e2364809\"},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"BYODDeviceIDPage\",\"BYODSimIDPage\",\"PromoHub\",\"NewRecommendedPlanSelection\",\"DeviceConfigurator\",\"BYODDeviceIDPage\",\"BYODSimIDPage\",\"PromoHub\",\"ContactInfo\",\"EligibilityReview\",\"AssignNumbers\",\"Agreement\",\"OrderReview\"]}],\"validateOrder\":{\"orderDetails\":[{\"lineActivityType\":\"\",\"mtnDetailsList\":[{\"simIdProvided\":\"true\",\"mtn\":\"newLine1\",\"deviceIdProvided\":\"true\",\"ispuItem\":false,\"lineActivityType\":\"NSEBYOD\",\"lostORStolen\":\"false\"}],\"orderActivityType\":\"NSE\",\"cpcType\":\"noCPCLines\",\"removeble\":false,\"creditFailureCount\":0,\"maxCreditFailuresAllowed\":0,\"creditApplicationNum\":\"999999000\",\"orderStatus\":\"SUCCESS\",\"shipmentAddressValidated\":true,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CA CVAS AUTOMATIC APPROVAL\",\"securityDepositAmount\":\"0\",\"loveligibility\":false,\"showConflicts\":false,\"idialFeaturePresent\":false}],\"cartId\":\"\",\"locationCode\":\"\",\"orderType\":\"PS\",\"saleType\":\"P\",\"totalDueMonthly\":94.24,\"totalDownPaymentAmt\":0.0,\"externalProgramEligibilityCheck\":false,\"programEligibilityStatus\":\"\",\"managerApprovalForDiscount\":false,\"tradeInType\":\"\",\"readyForOrderSubmit\":false,\"errorDesc\":\"\",\"errorCode\":\"\",\"contactInfoAvailable\":true,\"creditCheckCompleted\":true,\"numberAssignmentDone\":true,\"accountPinAvailable\":true,\"shipmentMethodSelected\":false,\"paymentCompleted\":true,\"tncAccepted\":true,\"paymentRequired\":false,\"effectivePlanDateValid\":false,\"downpaymentRequired\":false,\"managerApproval\":false,\"prefferedPricingOptions\":false}}}}}";
        InitiateCheckoutUIRequest request = mapper.readValue(requestString, InitiateCheckoutUIRequest.class);
        InitiateCheckoutUIResponse response = mapper.readValue(responseString, InitiateCheckoutUIResponse.class);
        URI url = URI.create("http://localhost/validateOrder");
        HttpCookie httpCookie = new HttpCookie("digital_ig_session", "bcba6c6c-afd9-4a59-b0dd-99b82fcf2ec9");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookie(httpCookie).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.validateOrder(Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.validateOrder(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void validateOrderTest5() throws IOException {
        String requestString = "{\"cartInfo\":{\"processingMTN\":\"\",\"locationCode\":\"\",\"customerType\":\"N\",\"standaloneBYOD\":false,\"intendType\":\"BYOD\",\"processStep\":\"OrderReview\",\"processAction\":\"validateOrder\",\"flowType\":\"VANITY\"}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.06.01.10.39.12-106.04065964449005\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"OrderReview\",\"processAction\":\"\",\"availablePaths\":[]},\"cartInfo\":{},\"customerInfo\":{\"customerType\":\"N\",\"originalCreditApprovalNumber\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-2b9c5523-35af-4bd3-a443-01a5e2364809\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"cradleFlowJourney\":\"AccessoryInterestialProspectBYOD\",\"mtnFlow\":\"D\",\"editFromPage\":\"\",\"globalId\":\"POE-D-2b9c5523-35af-4bd3-a443-01a5e2364809\"},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"BYODDeviceIDPage\",\"BYODSimIDPage\",\"PromoHub\",\"NewRecommendedPlanSelection\",\"DeviceConfigurator\",\"BYODDeviceIDPage\",\"BYODSimIDPage\",\"PromoHub\",\"ContactInfo\",\"EligibilityReview\",\"AssignNumbers\",\"Agreement\",\"OrderReview\"]}],\"validateOrder\":{\"orderDetails\":[{\"lineActivityType\":\"\",\"mtnDetailsList\":[{\"simIdProvided\":\"true\",\"mtn\":\"newLine1\",\"deviceIdProvided\":\"true\",\"ispuItem\":false,\"lineActivityType\":\"NSEBYOD\",\"lostORStolen\":\"false\"}],\"orderActivityType\":\"NSE\",\"cpcType\":\"noCPCLines\",\"removeble\":false,\"creditFailureCount\":0,\"maxCreditFailuresAllowed\":0,\"creditApplicationNum\":\"999999000\",\"orderStatus\":\"SUCCESS\",\"shipmentAddressValidated\":true,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CA CVAS AUTOMATIC APPROVAL\",\"securityDepositAmount\":\"0\",\"loveligibility\":false,\"showConflicts\":false,\"idialFeaturePresent\":false}],\"cartId\":\"\",\"locationCode\":\"\",\"orderType\":\"PS\",\"saleType\":\"P\",\"totalDueMonthly\":94.24,\"totalDownPaymentAmt\":0.0,\"externalProgramEligibilityCheck\":false,\"programEligibilityStatus\":\"\",\"managerApprovalForDiscount\":false,\"tradeInType\":\"\",\"readyForOrderSubmit\":false,\"errorDesc\":\"\",\"errorCode\":\"\",\"contactInfoAvailable\":true,\"creditCheckCompleted\":true,\"numberAssignmentDone\":true,\"accountPinAvailable\":true,\"shipmentMethodSelected\":false,\"paymentCompleted\":true,\"tncAccepted\":true,\"paymentRequired\":false,\"effectivePlanDateValid\":false,\"downpaymentRequired\":false,\"managerApproval\":false,\"prefferedPricingOptions\":false}}}}}";
        InitiateCheckoutUIRequest request = mapper.readValue(requestString, InitiateCheckoutUIRequest.class);
        InitiateCheckoutUIResponse response = mapper.readValue(responseString, InitiateCheckoutUIResponse.class);
        URI url = URI.create("http://localhost/validateOrder");
        HttpCookie httpCookie = new HttpCookie("digital_ig_session", "bcba6c6c-afd9-4a59-b0dd-99b82fcf2ec9");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-TELESALES").cookie(httpCookie).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.validateOrder(Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.validateOrder(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void validateCartAndCheckoutTest1() throws IOException {
        String requestString = "{\"cartInfo\":{\"quoteWithoutCredit\":false,\"clientAppName\":\"VZW-RPS\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"processingMTN\":\"newLine1\",\"intendType\":\"NSEBYOD\",\"processStep\":\"ShoppingCart\",\"processAction\":\"checkOut\"}}";
        String responseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-NETACE\", \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \"SOP-20647-E01\", \"contextInfo\": { \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"OrderReview-Shipping-Payment-Agreement\", \"processAction\": \"\", \"availablePaths\": [ { \"path\": \"AvailablePaths\" } ] }, \"cartInfo\": { \"cartId\": \"cbf26bd7-035a-49a0-ba2c-e320bc46f3bf\", \"method\": \"addtoCart\" }, \"customerInfo\": { \"registerNumber\": 0, \"accountNumber\": \"0224065213-00001\", \"cartCreator\": \"2402169848\", \"processingMTN\": \"2402169848\" }, \"processMTNList\": [ { \"mtn\": \"2402169848\", \"completedprocessSteps\": [ \"MTNSelectionPage\", \"GridWallPDP\", \"ShoppingCart\" ] } ], \"validateOrder\": { \"orderDetails\": [ { \"systemId\": \"\", \"creditApplicationNum\": \"382938499\", \"orderStatus\": \"SUCCESS\", \"shipmentAddressValidated\": true, \"userId\": \"\", \"statusMsg\": \"\", \"creditApprovalStatus\": \"AP\", \"creditStatusReason\": \"CA CVAS AUTOMATIC APPROVAL\", \"securityDepositAmount\": \"0\", \"loveligibility\": false, \"statusCode\": \"\" } ], \"cartId\": \"cbf26bd7-035a-49a0-ba2c-e320bc46f3bf\", \"locationCode\": \"E247201\" } } } }, \"cartReadyForCheckout\": true }";
        InitiateCheckoutUIResponse response = mapper.readValue(responseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest request = mapper.readValue(requestString, InitiateCheckoutUIRequest.class);
        URI url = URI.create("http://localhost/validateCartAndCheckout");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.validateCartAndCheckout(Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.validateCartAndCheckout(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void validateCartAndCheckoutTest2() throws IOException {
        String requestString = "{\"cartInfo\":{\"quoteWithoutCredit\":true,\"clientAppName\":\"VZW-RPS\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"processingMTN\":\"newLine1\",\"intendType\":\"NSEBYOD\",\"processStep\":\"ShoppingCart\",\"processAction\":\"checkOut\"}}";
        String responseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-NETACE\", \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \"SOP-20647-E01\", \"contextInfo\": { \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"OrderReview-Shipping-Payment-Agreement\", \"processAction\": \"\", \"availablePaths\": [ { \"path\": \"AvailablePaths\" } ] }, \"cartInfo\": { \"cartId\": \"cbf26bd7-035a-49a0-ba2c-e320bc46f3bf\", \"method\": \"addtoCart\" }, \"customerInfo\": { \"registerNumber\": 0, \"accountNumber\": \"0224065213-00001\", \"cartCreator\": \"2402169848\", \"processingMTN\": \"2402169848\" }, \"processMTNList\": [ { \"mtn\": \"2402169848\", \"completedprocessSteps\": [ \"MTNSelectionPage\", \"GridWallPDP\", \"ShoppingCart\" ] } ], \"validateOrder\": { \"orderDetails\": [ { \"systemId\": \"\", \"creditApplicationNum\": \"382938499\", \"orderStatus\": \"SUCCESS\", \"shipmentAddressValidated\": true, \"userId\": \"\", \"statusMsg\": \"\", \"creditApprovalStatus\": \"AP\", \"creditStatusReason\": \"CA CVAS AUTOMATIC APPROVAL\", \"securityDepositAmount\": \"0\", \"loveligibility\": false, \"statusCode\": \"\" } ], \"cartId\": \"cbf26bd7-035a-49a0-ba2c-e320bc46f3bf\", \"locationCode\": \"E247201\" } } } }, \"cartReadyForCheckout\": true }";
        InitiateCheckoutUIResponse response = mapper.readValue(responseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest request = mapper.readValue(requestString, InitiateCheckoutUIRequest.class);
        URI url = URI.create("http://localhost/validateCartAndCheckout");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.validateCartAndCheckout(Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.validateCartAndCheckout(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void validateCartAndCheckoutTest3() throws IOException {
        String requestString = "{\"cartInfo\":{\"quoteId\":\"quoteId\",\"clientAppName\":\"VZW-RPS\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"processingMTN\":\"newLine1\",\"intendType\":\"NSEBYOD\",\"processStep\":\"ShoppingCart\",\"processAction\":\"checkOut\"}}";
        String responseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-NETACE\", \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \"SOP-20647-E01\", \"contextInfo\": { \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"OrderReview-Shipping-Payment-Agreement\", \"processAction\": \"\", \"availablePaths\": [ { \"path\": \"AvailablePaths\" } ] }, \"cartInfo\": { \"cartId\": \"cbf26bd7-035a-49a0-ba2c-e320bc46f3bf\", \"method\": \"addtoCart\" }, \"customerInfo\": { \"registerNumber\": 0, \"accountNumber\": \"0224065213-00001\", \"cartCreator\": \"2402169848\", \"processingMTN\": \"2402169848\" }, \"processMTNList\": [ { \"mtn\": \"2402169848\", \"completedprocessSteps\": [ \"MTNSelectionPage\", \"GridWallPDP\", \"ShoppingCart\" ] } ], \"validateOrder\": { \"orderDetails\": [ { \"systemId\": \"\", \"creditApplicationNum\": \"382938499\", \"orderStatus\": \"SUCCESS\", \"shipmentAddressValidated\": true, \"userId\": \"\", \"statusMsg\": \"\", \"creditApprovalStatus\": \"AP\", \"creditStatusReason\": \"CA CVAS AUTOMATIC APPROVAL\", \"securityDepositAmount\": \"0\", \"loveligibility\": false, \"statusCode\": \"\" } ], \"cartId\": \"cbf26bd7-035a-49a0-ba2c-e320bc46f3bf\", \"locationCode\": \"E247201\" } } } }, \"cartReadyForCheckout\": true }";
        InitiateCheckoutUIResponse response = mapper.readValue(responseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest request = mapper.readValue(requestString, InitiateCheckoutUIRequest.class);
        URI url = URI.create("http://localhost/validateCartAndCheckout");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.validateCartAndCheckout(Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.validateCartAndCheckout(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }


    @Test
    public void validateCartAndCheckoutTest4() throws IOException {
        String requestString = "{\"cartInfo\":{\"quoteId\":null,\"clientAppName\":\"VZW-RPS\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"processingMTN\":\"newLine1\",\"intendType\":\"NSEBYOD\",\"processStep\":\"ShoppingCart\",\"processAction\":\"checkOut\"}}";
        String responseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-NETACE\", \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \"SOP-20647-E01\", \"contextInfo\": { \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"OrderReview-Shipping-Payment-Agreement\", \"processAction\": \"\", \"availablePaths\": [ { \"path\": \"AvailablePaths\" } ] }, \"cartInfo\": { \"cartId\": \"cbf26bd7-035a-49a0-ba2c-e320bc46f3bf\", \"method\": \"addtoCart\" }, \"customerInfo\": { \"registerNumber\": 0, \"accountNumber\": \"0224065213-00001\", \"cartCreator\": \"2402169848\", \"processingMTN\": \"2402169848\" }, \"processMTNList\": [ { \"mtn\": \"2402169848\", \"completedprocessSteps\": [ \"MTNSelectionPage\", \"GridWallPDP\", \"ShoppingCart\" ] } ], \"validateOrder\": { \"orderDetails\": [ { \"systemId\": \"\", \"creditApplicationNum\": \"382938499\", \"orderStatus\": \"SUCCESS\", \"shipmentAddressValidated\": true, \"userId\": \"\", \"statusMsg\": \"\", \"creditApprovalStatus\": \"AP\", \"creditStatusReason\": \"CA CVAS AUTOMATIC APPROVAL\", \"securityDepositAmount\": \"0\", \"loveligibility\": false, \"statusCode\": \"\" } ], \"cartId\": \"cbf26bd7-035a-49a0-ba2c-e320bc46f3bf\", \"locationCode\": \"E247201\" } } } }, \"cartReadyForCheckout\": true }";
        InitiateCheckoutUIResponse response = mapper.readValue(responseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest request = mapper.readValue(requestString, InitiateCheckoutUIRequest.class);
        URI url = URI.create("http://localhost/validateCartAndCheckout");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.validateCartAndCheckout(Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.validateCartAndCheckout(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void validateCartAndCheckoutTest5() throws IOException {
        String requestString = "{\"cartInfo\":{\"quoteId\":\"quoteId\",\"clientAppName\":\"VZW-RPS\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"processingMTN\":\"newLine1\",\"intendType\":\"BYOD\",\"processStep\":\"ShoppingCart\",\"processAction\":\"checkOut\"}}";
        String responseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-NETACE\", \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \"SOP-20647-E01\", \"contextInfo\": { \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"OrderReview-Shipping-Payment-Agreement\", \"processAction\": \"\", \"availablePaths\": [ { \"path\": \"AvailablePaths\" } ] }, \"cartInfo\": { \"cartId\": \"cbf26bd7-035a-49a0-ba2c-e320bc46f3bf\", \"method\": \"addtoCart\" }, \"customerInfo\": { \"registerNumber\": 0, \"accountNumber\": \"0224065213-00001\", \"cartCreator\": \"2402169848\", \"processingMTN\": \"2402169848\" }, \"processMTNList\": [ { \"mtn\": \"2402169848\", \"completedprocessSteps\": [ \"MTNSelectionPage\", \"GridWallPDP\", \"ShoppingCart\" ] } ], \"validateOrder\": { \"orderDetails\": [ { \"systemId\": \"\", \"creditApplicationNum\": \"382938499\", \"orderStatus\": \"SUCCESS\", \"shipmentAddressValidated\": true, \"userId\": \"\", \"statusMsg\": \"\", \"creditApprovalStatus\": \"AP\", \"creditStatusReason\": \"CA CVAS AUTOMATIC APPROVAL\", \"securityDepositAmount\": \"0\", \"loveligibility\": false, \"statusCode\": \"\" } ], \"cartId\": \"cbf26bd7-035a-49a0-ba2c-e320bc46f3bf\", \"locationCode\": \"E247201\" } } } }, \"cartReadyForCheckout\": true }";
        InitiateCheckoutUIResponse response = mapper.readValue(responseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest request = mapper.readValue(requestString, InitiateCheckoutUIRequest.class);
        URI url = URI.create("http://localhost/validateCartAndCheckout");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.validateCartAndCheckout(Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.validateCartAndCheckout(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void validateCartTest5() throws IOException {
        String requestString = "{\"meta\":{\"type\":\"CUSTOMER\",\"user\":\"kumasa1\",\"client\":\"VZW-DOTCOM\"},\"cartId\":\"5560eeed-2ad2-4634-866b-c4986502594b\",\"channel\":\"assissted\",\"pageId\":\"landing\",\"flow\":\"upgrade\"}";
        String responseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
        List<String> rtCartCountRes = new ArrayList<>();
        rtCartCountRes.add("10");
        ValidateCartCXPRequest request = mapper.readValue(requestString, ValidateCartCXPRequest.class);
        ValidateCartUIResponse response = mapper.readValue(responseString, ValidateCartUIResponse.class);
        Map<String, String> sessionMap = new HashMap();
        sessionMap.put("z1OfferCode", "1Q23Z1SP150");
        URI url = URI.create("http://localhost/validate-cart");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(readCartHelper.validateCart(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.upsertRetrieveCartDataIntoRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper2.upsertValueInRedis(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper2.upsertDeviceCartMapInRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper.deleteProcessingMtnFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        when(redisHelper2.upsertOrderEligibilityInRedis(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper2.inFlightOrderCheck(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper2.readSoeCradleData(Mockito.any(), Mockito.any())).thenReturn(Mono.just(rtCartCountRes));
        when(redisHelper2.barCodeOfferCode()).thenReturn(Mono.just(sessionMap));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just("eup"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.validateCart(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void validateCartTest6() throws IOException {
        ReflectionTestUtils.setField(cartController, "processingMtnFlag", "true");
        String requestString = "{\"meta\":{\"user\":\"kumasa1\",\"client\":\"VZW-DOTCOM\"},\"cartId\":\"5560eeed-2ad2-4634-866b-c4986502594b\",\"channel\":\"assissted\",\"pageId\":\"landing\",\"flow\":\"upgrade\"}";
        String responseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
        List<String> rtCartCountRes = new ArrayList<>();
        rtCartCountRes.add("10");
        ValidateCartCXPRequest request = mapper.readValue(requestString, ValidateCartCXPRequest.class);
        ValidateCartUIResponse response = mapper.readValue(responseString, ValidateCartUIResponse.class);
        Map<String, String> sessionMap = new HashMap();
        sessionMap.put("z1OfferCode", "1Q23Z1SP150");
        URI url = URI.create("http://localhost/validate-cart");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(readCartHelper.validateCart(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.upsertRetrieveCartDataIntoRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper2.upsertValueInRedis(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper2.upsertDeviceCartMapInRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper.deleteProcessingMtnFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        when(redisHelper2.upsertOrderEligibilityInRedis(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper2.inFlightOrderCheck(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper2.readSoeCradleData(Mockito.any(), Mockito.any())).thenReturn(Mono.just(rtCartCountRes));
        when(redisHelper2.barCodeOfferCode()).thenReturn(Mono.just(sessionMap));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just("eup"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.validateCart(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();

        ReflectionTestUtils.setField(cartController, "processingMtnFlag", "false");
        StepVerifier.create(cartController.validateCart(httpHeader, httpResponse, request)).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void validateCartTest7() throws IOException {
        String requestString = "{\"meta\":{\"user\":\"kumasa1\",\"client\":\"VZW-DOTCOM\"},\"cartId\":\"5560eeed-2ad2-4634-866b-c4986502594b\",\"channel\":\"assissted\",\"pageId\":\"landing\",\"flow\":\"upgrade\"}";
        String responseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"numOfAccessoryAndDeviceItemsInCart\":0,\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
        List<String> rtCartCountRes = new ArrayList<>();
        rtCartCountRes.add("10");
        ValidateCartCXPRequest request = mapper.readValue(requestString, ValidateCartCXPRequest.class);
        ValidateCartUIResponse response = mapper.readValue(responseString, ValidateCartUIResponse.class);
        Map<String, String> sessionMap = new HashMap();
        sessionMap.put("z1OfferCode", "1Q23Z1SP150");
        URI url = URI.create("http://localhost/validate-cart");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(readCartHelper.validateCart(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.upsertRetrieveCartDataIntoRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper2.upsertValueInRedis(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper2.upsertDeviceCartMapInRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper.deleteProcessingMtnFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        when(redisHelper2.upsertOrderEligibilityInRedis(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper2.inFlightOrderCheck(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper2.readSoeCradleData(Mockito.any(), Mockito.any())).thenReturn(Mono.just(rtCartCountRes));
        when(redisHelper2.barCodeOfferCode()).thenReturn(Mono.just(sessionMap));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just("eup"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.validateCart(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void validateCartTest8() throws IOException {
        String requestString = "{\"meta\":{\"user\":\"kumasa1\",\"client\":\"VZW-DOTCOM\"},\"cartId\":\"5560eeed-2ad2-4634-866b-c4986502594b\",\"channel\":\"assissted\",\"pageId\":\"landing\",\"flow\":\"upgrade\"}";
        String responseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"orderDetails\":{\"customerType\":\"N\",\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[]}}}}";
        ValidateCartCXPRequest request = mapper.readValue(requestString, ValidateCartCXPRequest.class);
        ValidateCartUIResponse response = mapper.readValue(responseString, ValidateCartUIResponse.class);
        Map<String, String> sessionMap = new HashMap();
        sessionMap.put("z1OfferCode", "1Q23Z1SP150");
        URI url = URI.create("http://localhost/validate-cart");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(readCartHelper.validateCart(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.upsertRetrieveCartDataIntoRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper2.upsertValueInRedis(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper2.upsertDeviceCartMapInRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper.deleteProcessingMtnFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        when(redisHelper2.upsertOrderEligibilityInRedis(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper2.inFlightOrderCheck(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper2.barCodeOfferCode()).thenReturn(Mono.just(sessionMap));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just("eup"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.validateCart(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void validateCartErrorTest1() throws IOException {
        String requestString = "{\"meta\":{\"user\":\"kumasa1\",\"client\":\"VZW-DOTCOM\"},\"cartId\":\"5560eeed-2ad2-4634-866b-c4986502594b\",\"channel\":\"digital\",\"pageId\":\"landing\",\"flow\":\"upgrade\"}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        ValidateCartCXPRequest request = mapper.readValue(requestString, ValidateCartCXPRequest.class);
        ValidateCartUIResponse response = mapper.readValue(responseString, ValidateCartUIResponse.class);
        URI url = URI.create("http://localhost/validate-cart");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        when(readCartHelper.validateCart(Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.validateCart(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void initiateCbandCheckTest1() throws IOException {
        String requestString = "{\"flowType\":\"imsi\",\"imsi\":\"311480589646564\", \"bbflowType\":\"mmm\", \"testMDN\":\"256435\"}";
        String responseString = "{\"meta\":{\"timestamp\":\"1646038921968\",\"cxpCorrelationId\":\"2022-02-28T09:02:01.+0000:27725cc9-1c08-420e-9653-90650363a6e7:cxp-customerprofile-se-qa-ev6v-sit3e-nscxp-5c7bdbf4f4-8wt5x:nssit3\"},\"data\":{\"vmasBootUpInfo\":{\"mtn\":\"8322622598\",\"booted\":true,\"deviceReachable\":\"Y\",\"snr5G\":\"12\",\"networkType\":\"UW Mid Band\",\"setupReason\":\"NEW SETUP\",\"postMount5GSignal\":\"\"}}}";
        InitiateCbandCheckUIRequest request = mapper.readValue(requestString, InitiateCbandCheckUIRequest.class);
        InitiateCbandCheckUIResponse response = mapper.readValue(responseString, InitiateCbandCheckUIResponse.class);
        URI url = URI.create("http://localhost/nse/initiateCbandCheck");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(readCartHelper.initiateCbandCheck(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper2.upsertInitiateCbandCheckDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.initiateCbandCheck(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void deviceSimValidationTest12() throws IOException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"imei\":\"352898071710272\",\"imei2\":\"\",\"iccid\":\"89148000003136518763\",\"mdn\":\"\",\"devid\":\"\",\"eid\":\"\",\"skipUserAgent\":true,\"isSmartphone\":true,\"podidentifier\":\"\",\"handofftoken\":\"\",\"billingId\":\"I\"}";
        String responseString = "{\"meta\":{\"timestamp\":\"1652136617166\",\"cxpCorrelationId\":\"2022-05-09T22:50:17.+0000:d742e580-c226-4967-9930-f66ead777ce5:cxp-customerprofile-se-qa-ev6v-sit3e-nscxp-568698f4cd-rrtp8:nssit3\"},\"data\":{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"billingId\":\"I\",\"isSmartphone\":true,\"isEsimDevice\":false,\"flowType\":\"NSE\",\"isValidationSuccess\":true,\"isSDKDevice\":false,\"skipUserAgent\":true}}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        DeviceSimValidationUIRequest request = mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
        DeviceSimValidationUIResponse response = mapper.readValue(responseString, DeviceSimValidationUIResponse.class);
        URI url = URI.create("http://localhost/nse/deviceSimValidation");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(readCartHelper.validateSecureToken(Mockito.any())).thenReturn(request);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(readCartHelper.customerByMtn(Mockito.any())).thenReturn(Mono.just(new CustomerByMtnUIResponse()));
        when(readCartHelper.deviceSimValidation(httpHeader, request)).thenReturn(Mono.just(response));
        when(redisHelper3.upsertDeviceSimValidationRequestDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.upsertDeviceSimValidationDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController1.deviceSimValidation(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void deviceSimValidationTest13() throws IOException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"imei\":\"352898071710272\",\"imei2\":\"\",\"iccid\":\"89148000003136518763\",\"mdn\":\"\",\"devid\":\"\",\"eid\":\"\",\"skipUserAgent\":true,\"isSmartphone\":true,\"podidentifier\":\"\",\"handofftoken\":\"\",\"billingId\":\"I\"}";
        String responseString = "{\"meta\":{\"timestamp\":\"1652136617166\",\"cxpCorrelationId\":\"2022-05-09T22:50:17.+0000:d742e580-c226-4967-9930-f66ead777ce5:cxp-customerprofile-se-qa-ev6v-sit3e-nscxp-568698f4cd-rrtp8:nssit3\"},\"data\":{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"billingId\":\"I\",\"isSmartphone\":true,\"isEsimDevice\":false,\"flowType\":\"NSE\",\"isValidationSuccess\":true,\"isSDKDevice\":false,\"skipUserAgent\":true}}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        DeviceSimValidationUIRequest request = mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
        DeviceSimValidationUIResponse response = mapper.readValue(responseString, DeviceSimValidationUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimValidation");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(readCartHelper.validateSecureToken(Mockito.any())).thenReturn(request);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(readCartHelper.customerByMtn(Mockito.any())).thenReturn(Mono.just(new CustomerByMtnUIResponse()));
        when(readCartHelper.deviceSimValidation(httpHeader, request)).thenReturn(Mono.just(response));
        when(redisHelper3.upsertDeviceSimValidationRequestDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController1.deviceSimValidation(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void deviceIdValidationTest7() throws IOException {
        String requestString = "{ \"channelId\":\"OMNI-CARE\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",                \"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",                \"processingMTN\": \"\",                                \"intent\": \"5GHome\",                \"processStep\": \"GridWallPDP\",                \"processAction\": \"validateGiftBoxId\"        },        \"data\": {                \"lines\": [{                        \"mtn\": \"6159691822\",                        \"device\": {                                        \"Flowtype\": \"GIFTBOX\",                                \"isCustomerProvidedEquipment\":true,                                \"giftBox\": {                                \"id\":\"LVSKPGB\"                        }                        }                }]        }}";
        String responseString = "{\"client\": \"CXP\", \"data\": {  \"lines\": [{  \"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
        DeviceIdValidationUIRequest request = mapper.readValue(requestString, DeviceIdValidationUIRequest.class);
        DeviceIdValidationUIResponse response = mapper.readValue(responseString, DeviceIdValidationUIResponse.class);
        URI url = URI.create("http://localhost/validate-deviceSimId");
        HttpCookie httpCookie = new HttpCookie("digital_ig_session", "POE-D");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-CHATBOT").cookie(httpCookie).build();
        ServerHttpResponse httpResponse = null;
        when(reCaptchaUtil.validateVisibleCaptcha(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(readCartHelper.deviceIdValidation(Mockito.any())).thenReturn(Mono.just(response));
        Map<String, Object> secondAppvedData = new HashMap<>();
        secondAppvedData.put(CartConstants.APPROVED_SECONDCAPTCHA_REDIS_KEY, Boolean.FALSE.toString());
        when(redisHelper3.getDataFromSession(Mockito.any())).thenReturn(Mono.just(secondAppvedData));
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        when(featureFlagHelper.fetchDigitalByodProfile()).thenReturn(Mono.just(configurationProfile));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.deviceIdValidation(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void deviceIdValidationTest8() throws IOException {
        String requestString = "{ \"channelId\":\"OMNI-CARE\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",                \"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",                \"processingMTN\": \"\",                                \"intent\": \"5GHome\",                \"processStep\": \"GridWallPDP\",                \"processAction\": \"validateGiftBoxId\"        },        \"data\": {                \"lines\": [{                        \"mtn\": \"6159691822\",                        \"device\": {                                        \"Flowtype\": \"GIFTBOX\",                                \"isCustomerProvidedEquipment\":true,                                \"giftBox\": {                                \"id\":\"LVSKPGB\"                        }                        }                }]        }}";
        String responseString = "{\"client\": \"CXP\", \"data\": {  \"lines\": [{  \"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
        DeviceIdValidationUIRequest request = mapper.readValue(requestString, DeviceIdValidationUIRequest.class);
        DeviceIdValidationUIResponse response = mapper.readValue(responseString, DeviceIdValidationUIResponse.class);
        URI url = URI.create("http://localhost/validate-deviceSimId");
        HttpCookie httpCookie = new HttpCookie("digital_ig_session", "POE-D");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookie(httpCookie).build();
        ServerHttpResponse httpResponse = null;
        when(reCaptchaUtil.validateVisibleCaptcha(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(readCartHelper.deviceIdValidation(Mockito.any())).thenReturn(Mono.just(response));
        Map<String, Object> secondAppvedData = new HashMap<>();
        secondAppvedData.put(CartConstants.APPROVED_SECONDCAPTCHA_REDIS_KEY, Boolean.FALSE.toString());
        when(redisHelper3.getDataFromSession(Mockito.any())).thenReturn(Mono.just(secondAppvedData));
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        when(featureFlagHelper.fetchDigitalByodProfile()).thenReturn(Mono.just(configurationProfile));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.deviceIdValidation(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void deviceIdValidationTest9() throws IOException {
        String requestString = "{ \"channelId\":\"OMNI-CARE\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",                \"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",                \"processingMTN\": \"\",                                \"intent\": \"5GHome\",                \"processStep\": \"GridWallPDP\",                \"processAction\": \"validateGiftBoxId\"        },        \"data\": {                \"lines\": [{                        \"mtn\": \"6159691822\",                        \"device\": {                                        \"Flowtype\": \"GIFTBOX\",                                \"isCustomerProvidedEquipment\":true,                                \"giftBox\": {                                \"id\":\"LVSKPGB\"                        }                        }                }]        }}";
        String responseString = "{\"client\": \"CXP\", \"data\": {  \"lines\": [{  \"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
        DeviceIdValidationUIRequest request = mapper.readValue(requestString, DeviceIdValidationUIRequest.class);
        DeviceIdValidationUIResponse response = mapper.readValue(responseString, DeviceIdValidationUIResponse.class);
        URI url = URI.create("http://localhost/validate-deviceSimId");
        HttpCookie httpCookie = new HttpCookie("digital_ig_session", "POE-D");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookie(httpCookie).build();
        ServerHttpResponse httpResponse = null;
        when(reCaptchaUtil.validateVisibleCaptcha(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(readCartHelper.deviceIdValidation(Mockito.any())).thenReturn(Mono.just(response));
        Map<String, Object> secondAppvedData = new HashMap<>();
        //secondAppvedData.put(CartConstants.APPROVED_SECONDCAPTCHA_REDIS_KEY, Boolean.FALSE.toString());
        when(redisHelper3.getDataFromSession(Mockito.any())).thenReturn(Mono.just(secondAppvedData));
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        when(featureFlagHelper.fetchDigitalByodProfile()).thenReturn(Mono.just(configurationProfile));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.deviceIdValidation(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void deviceIdValidationTest10() throws IOException {
        String requestString = "{ \"channelId\":\"OMNI-CARE\",\"cartInfo\": {\"gRecaptchaResponse\":\"capt\", \"clientAppName\": \"VZW-NETACE\",                \"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",                \"processingMTN\": \"\",                                \"intent\": \"5GHome\",                \"processStep\": \"GridWallPDP\",                \"processAction\": \"validateGiftBoxId\"        },        \"data\": {                \"lines\": [{                        \"mtn\": \"6159691822\",                        \"device\": {                                        \"Flowtype\": \"GIFTBOX\",                                \"isCustomerProvidedEquipment\":true,                                \"giftBox\": {                                \"id\":\"LVSKPGB\"                        }                        }                }]        }}";
        String responseString = "{\"client\": \"CXP\", \"data\": {  \"lines\": [{  \"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
        DeviceIdValidationUIRequest request = mapper.readValue(requestString, DeviceIdValidationUIRequest.class);
        DeviceIdValidationUIResponse response = mapper.readValue(responseString, DeviceIdValidationUIResponse.class);
        URI url = URI.create("http://localhost/validate-deviceSimId");
        HttpCookie httpCookie = new HttpCookie("digital_ig_session", "POE-D");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookie(httpCookie).build();
        ServerHttpResponse httpResponse = null;
        when(reCaptchaUtil.validateVisibleCaptcha(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(readCartHelper.deviceIdValidation(Mockito.any())).thenReturn(Mono.just(response));
        Map<String, Object> secondAppvedData = new HashMap<>();
        //secondAppvedData.put(CartConstants.APPROVED_SECONDCAPTCHA_REDIS_KEY, Boolean.FALSE.toString());
        when(redisHelper3.getDataFromSession(Mockito.any())).thenReturn(Mono.just(secondAppvedData));
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        when(featureFlagHelper.fetchDigitalByodProfile()).thenReturn(Mono.just(configurationProfile));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.deviceIdValidation(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void test_retrieveCartPlanBuilder_success() throws JsonProcessingException {
        String requestString = "{\"meta\":{\"client\":\"CXP\"},\"data\":{\"cartId\":\"018919b6-47ae-4b9c-92d8-189cceee61dc\",\"retrieveCurrentFeatures\":true},\"lookupPasscode\":\"024233\",\"zipCode\":\"60173\"}";
        RetrieveCartPlanbuilderRequest request = mapper.readValue(requestString, RetrieveCartPlanbuilderRequest.class);
        RetrieveCartUIResponse cartUIResponse = new RetrieveCartUIResponse();
        cartUIResponse.setData(new CXPRetrieveCartDataVO());
        cartUIResponse.getData().setCart(new CXPCartVO());
        cartUIResponse.getData().getCart().setCartId("018919b6-47ae-4b9c-92d8-189cceee61dc");
        cartUIResponse.getData().getCart().setOrderDetails(new CXPOrderDetails());
        cartUIResponse.getData().getCart().setCartHeader(new RetrieveCartHeader());
        cartUIResponse.getData().getCart().getCartHeader().setFullAccountNumber("00001-213456789");
        URI url = URI.create("http://localhost/validate-deviceSimId");
        HttpCookie httpCookie = new HttpCookie("digital_ig_session", "POE-D");

        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookie(httpCookie).build();
        ServerHttpResponse httpResponse = null;
        LookupColloborationCodeResponse lookupCodeResponse = new LookupColloborationCodeResponse();
        HashMap<String, JsonNode> hashMap = new HashMap<>();
        hashMap.put("cartId", new TextNode("018919b6-47ae-4b9c-92d8-189cceee61dc"));
        lookupCodeResponse.setData(new ObjectNode(JsonNodeFactory.instance, hashMap));
        lookupCodeResponse.setData(new ObjectNode(JsonNodeFactory.instance, hashMap));
        when(collaborationCodeHelper.getDataForLookupPasscode(Mockito.anyString(), Mockito.anyString())).thenReturn(Mono.just(lookupCodeResponse));
        when(retrieveCartHelper.validateRetrieveCartRequest(Mockito.any(), Mockito.any())).thenReturn(new ErrorResponse());
        when(readCartHelper.retrieveCart(Mockito.any())).thenReturn(Mono.just(cartUIResponse));
        when(redisHelper.upsertRetrieveCartDataIntoRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper.upsertCartResponseToSession(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<?>> controllerResponse = cartController.retrieveCartPlanBuilder(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void test_retrieveCartPlanBuilder_validationError() throws JsonProcessingException {
        String requestString = "{\"meta\":{\"client\":\"CXP\"},\"data\":{\"cartId\":\"018919b6-47ae-4b9c-92d8-189cceee61dc\",\"retrieveCurrentFeatures\":true},\"lookupPasscode\":\"024233\",\"zipCode\":\"60173\"}";
        RetrieveCartPlanbuilderRequest request = mapper.readValue(requestString, RetrieveCartPlanbuilderRequest.class);
        RetrieveCartUIResponse cartUIResponse = new RetrieveCartUIResponse();
        cartUIResponse.setData(new CXPRetrieveCartDataVO());
        cartUIResponse.getData().setCart(new CXPCartVO());
        cartUIResponse.getData().getCart().setCartId("018919b6-47ae-4b9c-92d8-189cceee61dc");
        cartUIResponse.getData().getCart().setOrderDetails(new CXPOrderDetails());
        cartUIResponse.getData().getCart().setCartHeader(new RetrieveCartHeader());
        cartUIResponse.getData().getCart().getCartHeader().setFullAccountNumber("00001-213456789");
        URI url = URI.create("http://localhost/validate-deviceSimId");
        HttpCookie httpCookie = new HttpCookie("digital_ig_session", "POE-D");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookie(httpCookie).build();
        ServerHttpResponse httpResponse = null;
        LookupColloborationCodeResponse lookupCodeResponse = new LookupColloborationCodeResponse();
        HashMap<String, JsonNode> hashMap = new HashMap<>();
        hashMap.put("cartId", new TextNode("uiterwot-weiturtoretuert-32401293weirtu"));
        lookupCodeResponse.setData(new ObjectNode(JsonNodeFactory.instance, hashMap));
        when(collaborationCodeHelper.getDataForLookupPasscode(Mockito.anyString(), Mockito.anyString())).thenReturn(Mono.just(lookupCodeResponse));
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.setErrors(new ArrayList<>());
        errorResponse.getErrors().add(new CartError());
        when(retrieveCartHelper.validateRetrieveCartRequest(Mockito.any(), Mockito.any())).thenReturn(errorResponse);
        when(readCartHelper.retrieveCart(Mockito.any())).thenReturn(Mono.just(cartUIResponse));
        Mono<ResponseEntity<?>> controllerResponse = cartController.retrieveCartPlanBuilder(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void test_retrieveCartPlanBuilder_mismatch() throws JsonProcessingException {
        String requestString = "{\"meta\":{\"client\":\"CXP\"},\"data\":{\"cartId\":\"018919b6-47ae-4b9c-92d8-189cceee61dc\",\"retrieveCurrentFeatures\":true},\"lookupPasscode\":\"024233\",\"zipCode\":\"60173\"}";
        RetrieveCartPlanbuilderRequest request = mapper.readValue(requestString, RetrieveCartPlanbuilderRequest.class);
        RetrieveCartUIResponse cartUIResponse = new RetrieveCartUIResponse();
        cartUIResponse.setData(new CXPRetrieveCartDataVO());
        cartUIResponse.getData().setCart(new CXPCartVO());
        cartUIResponse.getData().getCart().setCartId("018919b6-47ae-4b9c-92d8-189cceee61dc");
        cartUIResponse.getData().getCart().setOrderDetails(new CXPOrderDetails());
        cartUIResponse.getData().getCart().setCartHeader(new RetrieveCartHeader());
        cartUIResponse.getData().getCart().getCartHeader().setFullAccountNumber("00001-213456789");
        URI url = URI.create("http://localhost/validate-deviceSimId");
        HttpCookie httpCookie = new HttpCookie("digital_ig_session", "POE-D");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookie(httpCookie).build();
        ServerHttpResponse httpResponse = null;
        LookupColloborationCodeResponse lookupCodeResponse = new LookupColloborationCodeResponse();
        HashMap<String, JsonNode> hashMap = new HashMap<>();
        hashMap.put("cartId", new TextNode("uiterwot-weiturtoretuert-32401293weirtu"));
        lookupCodeResponse.setData(new ObjectNode(JsonNodeFactory.instance, hashMap));
        when(collaborationCodeHelper.getDataForLookupPasscode(Mockito.anyString(), Mockito.anyString())).thenReturn(Mono.just(lookupCodeResponse));
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.setErrors(new ArrayList<>());
        errorResponse.getErrors().add(new CartError());
        when(retrieveCartHelper.validateRetrieveCartRequest(Mockito.any(), Mockito.any())).thenReturn(errorResponse);
        when(readCartHelper.retrieveCart(Mockito.any())).thenReturn(Mono.just(cartUIResponse));
        Mono<ResponseEntity<?>> controllerResponse = cartController.retrieveCartPlanBuilder(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void test_retrieveCartPlanBuilder_lookupCode_invalid() throws JsonProcessingException {
        String requestString = "{\"meta\":{\"client\":\"CXP\"},\"data\":{\"cartId\":\"018919b6-47ae-4b9c-92d8-189cceee61dc\",\"retrieveCurrentFeatures\":true},\"lookupPasscode\":\"024233\",\"zipCode\":\"60173\"}";
        RetrieveCartPlanbuilderRequest request = mapper.readValue(requestString, RetrieveCartPlanbuilderRequest.class);
        RetrieveCartUIResponse cartUIResponse = new RetrieveCartUIResponse();
        cartUIResponse.setData(new CXPRetrieveCartDataVO());
        cartUIResponse.getData().setCart(new CXPCartVO());
        cartUIResponse.getData().getCart().setCartId("018919b6-47ae-4b9c-92d8-189cceee61dc");
        cartUIResponse.getData().getCart().setOrderDetails(new CXPOrderDetails());
        cartUIResponse.getData().getCart().setCartHeader(new RetrieveCartHeader());
        cartUIResponse.getData().getCart().getCartHeader().setFullAccountNumber("00001-213456789");
        URI url = URI.create("http://localhost/validate-deviceSimId");
        HttpCookie httpCookie = new HttpCookie("digital_ig_session", "POE-D");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookie(httpCookie).build();
        ServerHttpResponse httpResponse = null;
        LookupColloborationCodeResponse lookupCodeResponse = new LookupColloborationCodeResponse();
        lookupCodeResponse.setData(null);
        SOEError soeError = new SOEError();
        soeError.setMessage("error message");
        lookupCodeResponse.setErrors(Arrays.asList(soeError));
        when(collaborationCodeHelper.getDataForLookupPasscode(Mockito.anyString(), Mockito.anyString())).thenReturn(Mono.just(lookupCodeResponse));
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.setErrors(new ArrayList<>());
        CartError cartError = new CartError();
        errorResponse.getErrors().add(cartError);
        when(retrieveCartHelper.validateRetrieveCartRequest(Mockito.any(), Mockito.any())).thenReturn(errorResponse);
        when(readCartHelper.retrieveCart(Mockito.any())).thenReturn(Mono.just(cartUIResponse));
        Mono<ResponseEntity<?>> controllerResponse = cartController.retrieveCartPlanBuilder(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void retrieveCart_featureFlagDisEnabled_andAssistedChannel() {
        RetrieveCartCXPRequest request=new RetrieveCartCXPRequest();
        request.setChannelId("OMNI-RETAIL");
        RetrieveCartUIResponse cartUIResponse=new RetrieveCartUIResponse();
        cartUIResponse.setData(new CXPRetrieveCartDataVO());
        cartUIResponse.getData().setCart(new CXPCartVO());
        cartUIResponse.getData().getCart().setCartId("018919b6-47ae-4b9c-92d8-189cceee61dc");
        cartUIResponse.getData().getCart().setOrderDetails(new CXPOrderDetails());
        cartUIResponse.getData().getCart().setCartHeader(new RetrieveCartHeader());
        cartUIResponse.getData().getCart().getCartHeader().setFullAccountNumber("00001-213456789");
        when(readCartHelper.retrieveCart(Mockito.any())).thenReturn(Mono.just(cartUIResponse));
        when(redisHelper.upsertRetrieveCartDataIntoRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper.upsertCartResponseToSession(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        URI url = URI.create("http://localhost/retrieve-cart");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        when(featureFlagHelper.fetchAssistedMFETaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        when(omniDLHelper.updateVzdlData(cartUIResponse)).thenReturn(vzdl);
        when(readCartHelper.updatePortLaterCraddleCall(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(cartUIResponse));

        doNothing().when(cartAddDeviceHelper).updateReadAssistedDLData(vzdl);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.retrieveCart(httpHeader, httpResponse,
                request);
                StepVerifier.create(controllerResponse).expectNextMatches(respons->respons.getStatusCode().equals(HttpStatus.OK)&&
        respons.getBody().equals(new GenericResponse()));

        StepVerifier.create(cartController.retrieveCart(httpHeader, httpResponse,
                        request)).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();

    }

    @Test
    public void retrieveCart_featureFlagEnabled_andAssistedChannel() {
        RetrieveCartCXPRequest request=new RetrieveCartCXPRequest();
        request.setChannelId("OMNI-RETAIL");
        RetrieveCartUIResponse cartUIResponse=new RetrieveCartUIResponse();
        cartUIResponse.setData(new CXPRetrieveCartDataVO());
        cartUIResponse.getData().setCart(new CXPCartVO());
        cartUIResponse.getData().getCart().setCartId("018919b6-47ae-4b9c-92d8-189cceee61dc");
        cartUIResponse.getData().getCart().setOrderDetails(new CXPOrderDetails());
        cartUIResponse.getData().getCart().setCartHeader(new RetrieveCartHeader());
        cartUIResponse.getData().getCart().getCartHeader().setFullAccountNumber("00001-213456789");
        when(readCartHelper.retrieveCart(Mockito.any())).thenReturn(Mono.just(cartUIResponse));
        when(redisHelper.upsertRetrieveCartDataIntoRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper.upsertCartResponseToSession(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        URI url = URI.create("http://localhost/retrieve-cart");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").build();
        ServerHttpResponse httpResponse = null;
        when(featureFlagHelper.fetchAssistedMFETaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        when(featureFlagHelper.fetchD2DFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        when(omniDLHelper.updateVzdlData(cartUIResponse)).thenReturn(vzdl);
        when(readCartHelper.updatePortLaterCraddleCall(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(cartUIResponse));
        doNothing().when(cartAddDeviceHelper).updateReadAssistedDLData(vzdl);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.retrieveCart(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).expectNextMatches(respons->respons.getStatusCode().equals(HttpStatus.OK)&&
                respons.getBody().equals(new GenericResponse()));

        StepVerifier.create(cartController.retrieveCart(httpHeader, httpResponse,
                        request)).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();

        when(featureFlagHelper.fetchAssistedMFETaggingFeatureFlag()).thenReturn(Mono.just(Boolean.FALSE));
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.FALSE));

        StepVerifier.create(controllerResponse).expectNextMatches(respons->respons.getStatusCode().equals(HttpStatus.OK)&&
                respons.getBody().equals(new GenericResponse()));
        StepVerifier.create(cartController.retrieveCart(httpHeader, httpResponse,
                        request)).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();

        httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-DIGITAL").build();
        StepVerifier.create(controllerResponse).expectNextMatches(respons->respons.getStatusCode().equals(HttpStatus.OK)&&
                respons.getBody().equals(new GenericResponse()));
        StepVerifier.create(cartController.retrieveCart(httpHeader, httpResponse,
                        request)).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();

        httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "").build();
        StepVerifier.create(controllerResponse).expectNextMatches(respons->respons.getStatusCode().equals(HttpStatus.OK)&&
                respons.getBody().equals(new GenericResponse()));
        StepVerifier.create(cartController.retrieveCart(httpHeader, httpResponse,
                        request)).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void retrieveCart_exceptionDuringTagging() {
        RetrieveCartCXPRequest request=new RetrieveCartCXPRequest();
        request.setChannelId("OMNI-RETAIL");
        RetrieveCartUIResponse cartUIResponse=new RetrieveCartUIResponse();
        cartUIResponse.setData(new CXPRetrieveCartDataVO());
        cartUIResponse.getData().setCart(new CXPCartVO());
        cartUIResponse.getData().getCart().setCartId("018919b6-47ae-4b9c-92d8-189cceee61dc");
        cartUIResponse.getData().getCart().setOrderDetails(new CXPOrderDetails());
        cartUIResponse.getData().getCart().setCartHeader(new RetrieveCartHeader());
        cartUIResponse.getData().getCart().getCartHeader().setFullAccountNumber("00001-213456789");
        when(readCartHelper.retrieveCart(Mockito.any())).thenReturn(Mono.just(cartUIResponse));
        when(redisHelper.upsertRetrieveCartDataIntoRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper.upsertCartResponseToSession(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        URI url = URI.create("http://localhost/retrieve-cart");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "NI-RE").build();
        ServerHttpResponse httpResponse = null;
        when(featureFlagHelper.fetchAssistedMFETaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
       when(omniDLHelper.updateVzdlData(null)).thenThrow(new RuntimeException("Error on Tagging"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.retrieveCart(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).expectNextMatches(respons->respons.getStatusCode().equals(HttpStatus.OK)&&
                respons.getBody().equals(new GenericResponse()));
        verify(cartAddDeviceHelper,never()).updateReadAssistedDLData(any(Vzdl.class));
        assertNotNull("Error on Tagging");

    }

    @Test
    public void validateCartAccMemMigrationFeatureFlagTrueTest() throws IOException {
        String requestString = "{\"meta\":{\"type\":\"CUSTOMER\",\"user\":\"kumasa1\",\"client\":\"VZW-DOTCOM\"},\"cartId\":\"5560eeed-2ad2-4634-866b-c4986502594b\",\"channel\":\"assissted\",\"pageId\":\"landing\",\"flow\":\"upgrade\"}";
        String responseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
        List<String> rtCartCountRes = new ArrayList<>();
        rtCartCountRes.add("10");
        ValidateCartCXPRequest request = mapper.readValue(requestString, ValidateCartCXPRequest.class);
        ValidateCartUIResponse response = mapper.readValue(responseString, ValidateCartUIResponse.class);
        Map<String, String> sessionMap = new HashMap();
        sessionMap.put("z1OfferCode", "1Q23Z1SP150");
        URI url = URI.create("http://localhost/validate-cart");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(readCartHelper.validateCart(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.upsertRetrieveCartDataIntoRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper2.upsertValueInRedis(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper2.upsertDeviceCartMapInRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper.deleteProcessingMtnFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        when(redisHelper2.upsertOrderEligibilityInRedis(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper2.inFlightOrderCheck(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper2.readSoeCradleData(Mockito.any(), Mockito.any())).thenReturn(Mono.just(rtCartCountRes));
        when(redisHelper2.barCodeOfferCode()).thenReturn(Mono.just(sessionMap));
        when(featureFlagHelper.snTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(featureFlagHelper.isAccMemberMigrationEnabled()).thenReturn(Mono.just(true));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just("eup"));

        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.validateCart(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();

        SpocsType spocs = new SpocsType();
        response.getData().getValidateCartAndUpdate().getOrderDetails().setSpocs(spocs);
        Mono<ResponseEntity<GenericResponse>> controllerResponse0 = cartController.validateCart(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse0).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();

        SpocsType spocs1 = new SpocsType();
        NotificationOptions notOpt1 = new NotificationOptions();
        spocs1.setNotificationOptions(notOpt1);
        response.getData().getValidateCartAndUpdate().getOrderDetails().setSpocs(spocs1);
        Mono<ResponseEntity<GenericResponse>> controllerResponse1 = cartController.validateCart(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse1).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();

        SpocsType spocs2 = new SpocsType();
        NotificationOptions notOpt2 = new NotificationOptions();
        notOpt2.setPrimaryEmailId("test.tester@gamil.com");
        spocs2.setNotificationOptions(notOpt2);
        response.getData().getValidateCartAndUpdate().getOrderDetails().setSpocs(spocs2);
        Mono<ResponseEntity<GenericResponse>> controllerResponse2 = cartController.validateCart(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse2).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void validateCartAccMemMigrationFeatureFlagFalseTest() throws IOException {
        String requestString = "{\"meta\":{\"type\":\"CUSTOMER\",\"user\":\"kumasa1\",\"client\":\"VZW-DOTCOM\"},\"cartId\":\"5560eeed-2ad2-4634-866b-c4986502594b\",\"channel\":\"assissted\",\"pageId\":\"landing\",\"flow\":\"upgrade\"}";
        String responseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
        List<String> rtCartCountRes = new ArrayList<>();
        rtCartCountRes.add("10");
        ValidateCartCXPRequest request = mapper.readValue(requestString, ValidateCartCXPRequest.class);
        ValidateCartUIResponse response = mapper.readValue(responseString, ValidateCartUIResponse.class);
        Map<String, String> sessionMap = new HashMap();
        sessionMap.put("z1OfferCode", "1Q23Z1SP150");
        URI url = URI.create("http://localhost/validate-cart");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(readCartHelper.validateCart(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.upsertRetrieveCartDataIntoRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper2.upsertValueInRedis(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper2.upsertDeviceCartMapInRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper.deleteProcessingMtnFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        when(redisHelper2.upsertOrderEligibilityInRedis(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper2.inFlightOrderCheck(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper2.readSoeCradleData(Mockito.any(), Mockito.any())).thenReturn(Mono.just(rtCartCountRes));
        when(redisHelper2.barCodeOfferCode()).thenReturn(Mono.just(sessionMap));
        when(featureFlagHelper.snTaggingFeatureFlag()).thenReturn(Mono.just(false));
        when(featureFlagHelper.isAccMemberMigrationEnabled()).thenReturn(Mono.just(false));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just("eup"));
        when(redisHelper2.upsertValueInRedis(CartConstants.SAVE_CART_EMAILID,"test.tester@mail.com")).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.validateCart(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void tstGetSessionId_withValidChannelId(){

        String sessionId1 = "";
        String cookieValue = "OMNI-RETAIL";
        ServerHttpRequest mockRequest = mock(ServerHttpRequest.class);
        headers.add(CartConstants.CHANNEL_ID,CartConstants.RETAIL);
        HttpCookie cookie = new HttpCookie(CartConstants.ASSISTED_IG_SESSION_ID,cookieValue);
        when(mockRequest.getHeaders()).thenReturn(headers);
        when(mockRequest.getCookies()).thenReturn(new MultiValueMapAdapter<>(Map.of(CartConstants.ASSISTED_IG_SESSION_ID,List.of(cookie))));
        String sessionId= cartController.getSessionId(mockRequest,sessionId1);
        org.junit.Assert.assertEquals("",sessionId);
    }
    @Test
    public void tstGetSessionId_withValid1ChannelId(){
        HttpCookie cookie = new HttpCookie(CartConstants.ASSISTED_IG_SESSION_ID,"OMNI-RETAIL");
        ServerHttpRequest mockRequest = mock(ServerHttpRequest.class);
        headers.add(CartConstants.ASSISTED_IG_SESSION_ID,"EXPRESSIONISTIC");
        when(mockRequest.getCookies()).thenReturn(new MultiValueMapAdapter<>(Map.of(CartConstants.ASSISTED_IG_SESSION_ID,List.of(cookie))));
        when(mockRequest.getHeaders()).thenReturn(headers);
        String sessionId= cartController.getSessionId(mockRequest,"OMNI-CARE");
        assertEquals("OMNI-RETAIL",sessionId);
        sessionId= cartController.getSessionId(mockRequest,"OMNI-RETAIL");
        assertEquals("OMNI-RETAIL",sessionId);
        sessionId= cartController.getSessionId(mockRequest,"OMNI-RETAIL-TAB");
        assertEquals("OMNI-RETAIL",sessionId);
        sessionId= cartController.getSessionId(mockRequest,"OMNI-TELESALES");
        assertEquals("OMNI-RETAIL",sessionId);
        sessionId= cartController.getSessionId(mockRequest,"OMNI-INDIRECT");
        assertEquals("OMNI-RETAIL",sessionId);
        sessionId= cartController.getSessionId(mockRequest,"OMNI-CARE");
        assertEquals("OMNI-RETAIL",sessionId);
        sessionId= cartController.getSessionId(mockRequest,"abc");
        assertEquals("",sessionId);


    }
    @Test
    public void tstGetSessionId_withEmptySessionId(){
        ServerHttpRequest mockRequest = mock(ServerHttpRequest.class);
        when(mockRequest.getHeaders()).thenReturn(headers);
        HttpCookie cookie = new HttpCookie(CartConstants.ASSISTED_IG_SESSION_ID,"OMNI-RETAIL");
        when(mockRequest.getCookies()).thenReturn(new MultiValueMapAdapter<>(Map.of(CartConstants.ASSISTED_IG_SESSION_ID,List.of(cookie))));
        String sessionId= cartController.getSessionId(mockRequest,"");
        assertNotNull(sessionId);
    }

    @Test
    public void setRetrieveCartFeatureFlagsInResponseTest(){
            RetrieveCartUIResponse resp = new RetrieveCartUIResponse();
            resp.setData(new CXPRetrieveCartDataVO());
            ReflectionTestUtils.invokeMethod(cartController, "setRetrieveCartFeatureFlagsInResponse", resp);
    }

    @Test
    public void setValidateCartFeatureFlagsInResponseTest(){
        ValidateCartUIResponse resp = new ValidateCartUIResponse();
        ReflectionTestUtils.invokeMethod(cartController, "setValidateCartFeatureFlagsInResponse", resp);
    }
    @Test
    public void populateSOEResponseForRetriveCartPlanbuilderTest() throws JsonProcessingException {
        String responseString = "{\"data\": {\"cart\": {\"customerProfile\": {},\"cartHeader\": {\"winBackAccountNumber\": \"\",\"referralSaleRepId\": \"\",\"ecpdToken\": \"\",\"adobeId\": \"\",\"vendorId\": \"NETACE\",\"referralVendorId\": \"\",\"d2dFlag\": \"N\",\"sourceSystem\": \"OMNI-RETAIL\",\"cartId\": \"077d51dd-0511-4e87-bc34-3de25cf18ef8\",\"status\": \"A\",\"createTimestamp\": \"2021-11-16T06:52:54.935671-05:00[US/Eastern]\",\"lastUpdateTimestamp\": \"2021-11-16T06:57:23.139929-05:00[US/Eastern]\",\"cartCreator\": \"\",\"cartCreatorChannelId\": \"OMNI-RETAIL\",\"cartCreatorOrderLocationCode\": \"0026301\",\"cartCreatorSalesRepId\": \"ENC\",\"caseId\": \"SOP-4465635-E01\",\"visionCustomerType\": \"PE\",\"maverickLocation\": false,\"preConfiguredCartType\": \"BAU\",\"preConfiguredCartTypeDuringAddDevice\": \"BAU\",\"isCoreRep\": false},\"orderDetails\": {\"totalUpgradeFee\": 0.0,\"totalDeviceDollar\": 0.0,\"totalRemainingDeviceDollar\": 0.0,\"totalUsedDeviceDollar\": 0.0,\"totalAccountLevelAccCost\": 0.0,\"totalAccountLevelAccCostWithTax\": 0.0,\"totalShippingCost\": 0.0,\"totalDiscountedShippingCost\": 0.0,\"hqUser\": false,\"returnException\": false,\"taxDetailsList\": [],\"subTotalDueTodayWithoutUpgradeFee\": 0.0,\"subTotalDueMonthlyForAALBYODEUP\": 0.0,\"shipTogetherPref\": true,\"assistanceOptedByCustomer\": false,\"locationState\": \"NJ\",\"totalVerizonDollarUsed\": \"0.0\",\"isShellAccountSelected\": false,\"fullfillmentLocation\": \"1000001\",\"guestOrInactiveRefundLines\": false,\"totalDueMonthlyOnProfile\": 0.0,\"subTotalDueMonthlyOnProfile\": 0.0,\"totalMonthlyTaxesOnProfile\": 0.0,\"subTotalOtherLinesOnProfile\": 0.0,\"estimatedNextMonthChargeOnProfile\": 0.0,\"originalSubTotalDueMonthly\": 0.0,\"totalDueMonthlyAfterDiscounts\": 0.0,\"refundNotifications\": {\"notificationEmail\": \"POS@VZW.COM\",\"emailIds\": [\"POS@VZW.COM\"],\"phoneNumbers\": []},\"totalSurchargeAmount\": \"0.0\",\"orderType\": \"PS\",\"locationCode\": \"0026301\",\"customerType\": \"N\",\"billingSystem\": \"VN\",\"totalTaxAmount\": \"0.0\",\"spocs\": {\"notificationOptions\": {\"primaryEmailId\": \"POS@VZW.COM\"}},\"totalDueToday\": 0.0,\"runningTotalDueToday\": 0.0,\"totalDueTodayFlag\": true,\"totalDueMonthly\": 0.0,\"subTotalDueMonthly\": 0.0,\"subTotalDueToday\": 0.0,\"subTotalMonthlyTaxes\": 0.0,\"estimatedNextMonthCharge\": 0.0,\"totalMonthlyTaxes\": 0.0,\"subTotalOtherLines\": 0.0,\"subTotalOtherLinesTaxes\": 0.0,\"instantDRCCredit\": false,\"isAttachmentCompleted\": false,\"nextMonthBillTotal\": 0.0,\"customerNotification\": {\"smsLanguage\": \"E\"},\"orderChannelId\": \"OMNI-RETAIL\",\"orderList\": [{\"creditApplication\": {\"creditApplicationNum\": 428037738,\"creditApprovalStatus\": \"AP\",\"creditStatusReason\": \"CA CVAS AUTOMATIC APPROVAL\",\"internationalEligibility\": false,\"securityDepositAmount\": \"0\",\"serviceClass\": \"B\",\"lineCreditClass\": \"1D\"},\"orderActivityType\": \"NSE\",\"orderNumber\": 0,\"numOfLinesForOrderActivityType\": 1,\"preOrderNumber\": 0,\"managerApprovalRequired\": false}],\"outletId\": \"000000263\",\"registerNumber\": \"13\",\"saleType\": \"P\",\"salesRepId\": \"ENC\",\"enableSplitShipment\": false,\"splitShipmentIndicator\": false,\"isSingleModConnectedDevice\": false,\"fiveGUpSellAccountLevel\": false,\"customerOnTrialPlan\": false,\"totalDownPaymentAmt\": 0.0,\"totalEdgeBuyOutAmount\": 0.0,\"expressCheckout\": false,\"nbxInfo\": {\"isPreQualifiedNBX\": true,\"syfOfferId\": \"8803458027\",\"propositionMessage\": \"Thank You! You have been Pre-Approved.Sign up and receive: $100 sign up bonus and more\",\"propositionName\": \"Pre-Qualified - Transaction Flow\",\"propositionId\": \"GC_01\",\"isVZCCHolder\": false,\"isPreScreenRepresentment\":\"true\",\"sessionId\": \"8483170179439212780\"},\"isEQPandPPLOfferApplied\": false,\"cartTotalDiscounts\": {\"totalDiscount\": \"0.0\",\"discountDetails\": []},\"memberTotalDueToday\": 0.0,\"customerConsent\": \"Y\",\"totalDwosCost\": \"0.0\",\"billingState\": \"NJ\",\"isTradeInOfferSelected\": false,\"homePhone\": \"9879879879\",\"isAssignMtnRequired\": false,\"fiosCapable\": false,\"fiosEligible\": false,\"quoteWithoutCredit\": false},\"lineDetails\": {\"lineInfo\": [{\"multiLineSeqNumber\": 1,\"lineActivityType\": \"NSE_5G\",\"totalDueToday\": 0.0,\"totalDueTodayWithoutTax\": 0.0,\"totalDueMonthly\": 80.0,\"mobileNumber\": \"8627041933\",\"showGlobalChoiceOffer\": false,\"serviceInfo\": {\"otherPromotions\": [],\"primaryUserInfo\": {\"firstName\": \"POSTESTFBV\",\"lastName\": \"USEROJP\",\"address\": {\"streetNumber\": \"30\",\"streetName\": \"INDEPENDENCE\",\"addressLine1\": \"30 INDEPENDENCE BL\",\"city\": \"WARREN\",\"state\": \"NJ\",\"zipCode\": \"07059\",\"zipCode4\": \"6747\",\"county\": \"\",\"countryCode\": \"US\",\"fipsCode\": \"3403576940\",\"emailId\": \"POS@VZW.COM\",\"phoneNumber\": \"9879879879\",\"streetType\": \"BL\"},\"contactPersonPhone\": \"9879879879\",\"emailId\": \"POS@VZW.COM\"},\"cart5GAddress\": {\"type\": \"all\",\"streetNumber\": \"30\",\"streetName\": \"INDEPENDENCE\",\"addressLine2\": \"\",\"addressLine1\": \"1 VERIZON WAY  \",\"city\": \"BASKING RIDGE\",\"state\": \"NJ\",\"zipCode\": \"07920\",\"zipCode4\": \"1025\",\"countryCode\": \"\",\"emailId\": \"POS@VZW.COM\",\"phoneNumber\": \"9879879879\",\"streetType\": \"DR\",\"floor\": 0,\"eventCorrelationId\": \"07920_1637063710309_487\"},\"cart5GAppointment\": {\"installApptSelectedDate\": {\"selfInstallDate\": \"11/21/2021\"}},\"mtn\": \"8627041933\",\"min\": \"9738773139\",\"newPricePlanId\": \"39425\",\"contractTermId\": \"48\",\"newPricePlanInfo\": {\"pricePlanCategory\": \"N\",\"ratePlanType\": \"L\",\"accessFeeRange\": \"0\",\"categoryCode\": \"74\",\"contractRange\": \"-1\",\"contractDuration\": 0,\"pricePlanCode\": \"39425\",\"pricePlanDesc\": \"5G HOME INTERNET\",\"contractTermId\": \"48\",\"imageUrlMap\": {},\"planPrice\": 80.0},\"selectedFeaturesList\": {\"featuresCount\": 0,\"visFeature\": []},\"planDetails\": {\"planPrice\": 80.0,\"planDiscounts\": []},\"currentDevice\": {},\"isSharePlanAdded\": false,\"mea\": \"AOR\",\"dacc\": \"01425\",\"isE911AddressValidated\": false,\"isFreeAppleMusicLoss\": \"N\",\"newBgsa\": \"978\",\"newPlanFlag\": \"L\",\"orderDevice\": {\"lteVoraEquipInfo\": {\"lteEqpt\": {},\"lteVoraDeviceInfo\": {\"deviceType\": \"5GF\"}}},\"kidsPlanParentMtn\": false,\"mcsSubscription\": [],\"fiveGUpSell\": false,\"e911AddressSameAsServiceAddress\": false,\"unpairedGrantor\": false},\"itemsInfo\": [{\"depletionType\": \"F\",\"attention\": \"POSTESTFBV USEROJP\",\"shipping\": {\"address\": {\"type\": \"all\",\"streetNumber\": \"30\",\"streetName\": \"INDEPENDENCE\",\"addressLine2\": \"\",\"addressLine1\": \"1 VERIZON WAY  \",\"city\": \"BASKING RIDGE\",\"state\": \"NJ\",\"zipCode\": \"07920\",\"zipCode4\": \"1025\",\"county\": \"\",\"countryCode\": \"\",\"emailId\": \"POS@VZW.COM\",\"phoneNumber\": \"9879879879\",\"streetType\": \"DR\"},\"cbrPhone\": \"9879879879\",\"firstName\": \"POSTESTFBV\",\"lastName\": \"USEROJP\",\"isUseUnVerifiedAddress\": false,\"isValidAddress\": false,\"email\": \"POS@VZW.COM\"},\"fipsCode\": \"3403576940\",\"itemCount\": 1,\"itemTabSeqNum\": 0,\"cartItems\": {\"cartItem\": [{\"discountAmount\": 0.0,\"deviceDollarApplied\": 0.0,\"qrScanNeededForEsimActivation\": false,\"isPreconfigureDuringAddDevice\": false,\"accessoryGiftCardAmount\": 0.0,\"tradeInAmountTowardsUserDPUsed\": 0.0,\"sorDeviceType\": \"5GF\",\"vendingKioskItem\": \"false\",\"tradeInAutoPull\": false,\"priceAdjustment\": false,\"priceAdjustmentQty\": 0,\"newPurchasedQty\": 0,\"networkBandwidthType\": \"MMW\",\"selectedForRFEX\": false,\"selectedForPAD\": false,\"bogoItem\": false,\"itemCode\": \"LVSKIHP\",\"totalPriceWithDiscount\": 0.0,\"sorId\": \"LVSKIHP\",\"cartItemType\": \"DEVICE\",\"mobileNumber\": \"8627041933\",\"minNumber\": \"9738773139\",\"description\": \"5G Internet Gateway\",\"qty\": 1,\"bundleSeqNum\": 0,\"itemPrice\": \"0.0\",\"discountedPercentage\": 0.0,\"discountedPrice\": 0.0,\"taxAmount\": 0.0,\"imageUrlMap\": {\"defaultImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/verizon-gemini-5g-internet-gateway-gen-3-high-power-cpe-lvskihp\",\"largeImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/verizon-gemini-5g-internet-gateway-gen-3-high-power-cpe-lvskihp?$device-lg$\",\"mediumImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/verizon-gemini-5g-internet-gateway-gen-3-high-power-cpe-lvskihp?$device-med$\",\"miniImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/verizon-gemini-5g-internet-gateway-gen-3-high-power-cpe-lvskihp?$device-mini$\",\"thumbImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/verizon-gemini-5g-internet-gateway-gen-3-high-power-cpe-lvskihp?$device-thumb$\"},\"prodCode1\": \"5GD\",\"prodCode2\": \"NIC\",\"prodCode3\": \"5IR\",\"prodCode4\": \"B2B\",\"prodCode5\": \"RNT\",\"priceType\": \"MONTH_TO_MONTH\",\"btaEligible\": \"true\",\"depletionType\": \"F\",\"catalogPrice\": 0.0,\"instantCreditAmountUsed\": 0.0,\"instantCreditAmountUsedForTaxes\": 0.0,\"itemNrpPrice\": 0.0,\"itemCost\": 0.0,\"itemPriceType\": \"R\",\"discounts\": [],\"availableReasonCode\": [],\"inventory\": {\"isAvailable\": true,\"isBackorder\": false,\"isPreOrder\": false,\"qtyAvailable\": 1000},\"isCustomerProvidedSIM\": false,\"isNetworkExtender\": false,\"ispuEligible\": true,\"itemSeqNum\": 1,\"sddEligible\": true,\"smartIMEI\": false,\"year\": 0,\"sellerPrice\": \"0.0\",\"edgeDeviceCap\": \"750\",\"productId\": \"16900001\",\"taxDetailsList\": [],\"iconicPhone\": false,\"ringBell\": false,\"isPreconfigureEnabled\": false,\"isHumDevice\": false,\"isSmartLocator\": false,\"isSecurityAlarm\": false,\"isMotoMod\": false,\"isConnectedCar\": false,\"accountLevelAccessory\": false,\"byodESimPhone\": false,\"appleCareAccessoryFlag\": false},{\"discountAmount\": 0.0,\"deviceDollarApplied\": 0.0,\"qrScanNeededForEsimActivation\": false,\"isPreconfigureDuringAddDevice\": false,\"accessoryGiftCardAmount\": 0.0,\"tradeInAmountTowardsUserDPUsed\": 0.0,\"vendingKioskItem\": \"false\",\"tradeInAutoPull\": false,\"priceAdjustment\": false,\"priceAdjustmentQty\": 0,\"newPurchasedQty\": 0,\"selectedForRFEX\": false,\"selectedForPAD\": false,\"bogoItem\": false,\"itemCode\": \"NI-DPSIM\",\"totalPriceWithDiscount\": 0.0,\"sorId\": \"NI-DPSIM\",\"cartItemType\": \"SIM\",\"qty\": 1,\"bundleSeqNum\": 0,\"itemPrice\": \"0.0\",\"discountedPercentage\": 0.0,\"discountedPrice\": 0.0,\"instantCreditAmountUsed\": 0.0,\"instantCreditAmountUsedForTaxes\": 0.0,\"discounts\": [],\"availableReasonCode\": [],\"isCustomerProvidedSIM\": false,\"isNetworkExtender\": false,\"ispuEligible\": false,\"itemSeqNum\": 2,\"sddEligible\": false,\"smartIMEI\": false,\"year\": 0,\"sellerPrice\": \"0.0\",\"taxDetailsList\": [],\"iconicPhone\": false,\"ringBell\": false,\"isPreconfigureEnabled\": false,\"isHumDevice\": false,\"isSmartLocator\": false,\"isSecurityAlarm\": false,\"isMotoMod\": false,\"isConnectedCar\": false,\"accountLevelAccessory\": false,\"byodESimPhone\": false,\"appleCareAccessoryFlag\": false},{\"discountAmount\": 0.0,\"deviceDollarApplied\": 0.0,\"qrScanNeededForEsimActivation\": false,\"isPreconfigureDuringAddDevice\": false,\"accessoryGiftCardAmount\": 0.0,\"tradeInAmountTowardsUserDPUsed\": 0.0,\"vendingKioskItem\": \"false\",\"tradeInAutoPull\": false,\"priceAdjustment\": false,\"priceAdjustmentQty\": 0,\"newPurchasedQty\": 0,\"selectedForRFEX\": false,\"selectedForPAD\": false,\"bogoItem\": false,\"itemCode\": \"WAR6002\",\"totalPriceWithDiscount\": 0.0,\"sorId\": \"WAR6002\",\"cartItemType\": \"WARRANTY\",\"qty\": 1,\"bundleSeqNum\": 0,\"itemPrice\": \"0.0\",\"discountedPercentage\": 0.0,\"discountedPrice\": 0.0,\"instantCreditAmountUsed\": 0.0,\"instantCreditAmountUsedForTaxes\": 0.0,\"discounts\": [],\"availableReasonCode\": [],\"isCustomerProvidedSIM\": false,\"isNetworkExtender\": false,\"ispuEligible\": false,\"itemSeqNum\": 3,\"sddEligible\": false,\"smartIMEI\": false,\"year\": 0,\"sellerPrice\": \"0.0\",\"taxDetailsList\": [],\"iconicPhone\": false,\"ringBell\": false,\"isPreconfigureEnabled\": false,\"isHumDevice\": false,\"isSmartLocator\": false,\"isSecurityAlarm\": false,\"isMotoMod\": false,\"isConnectedCar\": false,\"accountLevelAccessory\": false,\"byodESimPhone\": false,\"appleCareAccessoryFlag\": false}]},\"depletionLocation\": \"\",\"isPromoSelected\": false,\"isTradeInSelected\": false,\"taxExemptionTypes\": \"\"}],\"assignMTNIndicator\": \"Y\",\"mtnDetails\": {\"dummyMTNForDomain\": \"9999999901\",\"lineNumber\": \"newLine1\",\"minNumber\": \"9738773139\",\"mobileNumber\": \"8627041933\",\"assignMTNTimestamp\": \"2021-11-16T06:56:26.897813-05:00[US/Eastern]\",\"npaNXX\": \"862704\"},\"securityDepositAmount\": \"0\",\"lineNumber\": \"newLine1\",\"fiveGToFourGDownGrade\": false,\"deviceTypeSelected\": \"5G Internet\",\"reasonCode\": \"PLAN_DEVICE_COMPATIBLE\",\"launchType\": \"FCL\",\"lineRefundTotal\": 0.0,\"lineExchangeTotal\": 0.0,\"totalDueMonthlyBeforeCredit\": 0.0,\"isCpe\": false,\"isLTEHomeLine\": false,\"isDevicePlanCompatible\": true,\"portinMtnAssignment\": false,\"impactedLine\": false,\"preOrBackOrder\": false,\"ispuItem\": false,\"ispuItemBYOD\": false,\"isModConnected\": false,\"modDevice\": false,\"byodCapable\": false,\"isCarLine\": false,\"buySimOnly\": false,\"broadBandInd\": false,\"ispuDownPaymentAdjstRequired\": false,\"ispuDownPaymentAmount\": 0.0,\"lineWithSkipMDN\": false,\"protectionNotRequired\": false}],\"numOfAccessoryAndDeviceItemsInCart\": 1,\"totalEdgeUpAmount\": 0.0,\"totalEdgeBuyOutAmount\": 0.0,\"tradeInDetail\": {},\"totalDownPaymentAmt\": 0.0,\"numOfLinesWithDevices\": 1,\"numofApprovedLines\": 0,\"rfexPayments\": [],\"cartId\": \"077d51dd-0511-4e87-bc34-3de25cf18ef8\",\"numOfLines\": 1,\"numofLinesAAL\": 0,\"numofLinesEUP\": 0,\"payments\": [],\"lineSeq\": 0,\"vlcactivePhoneCount\": 0,\"fivegOrderind\": true,\"aceOrderCreated\": false,\"serviceLinesCreated\": false,\"aceItemsModified\": false,\"clnrOrderFlag\": false,\"broadbandInd\": false,\"acctMcsSubscription\": [],\"spendingLimitAmountExceededBy\": \"0.0\",\"numofAccessories\": 0,\"subAccountNBSInfo\": []},\"accountEligibility\": false,\"displayCartValidationErrors\": true},\"warningMessages\": [],\"basicORSmartPhoneExists\": false,\"fiveGDeviceORLTEHomeExists\": true,\"redesignFlow\": false,\"orderPlaced\": false,\"validateCart\": false},\"meta\": {\"timestamp\": \"1637063846283\",\"cxpCorrelationId\": \"2021-11-16T11:57:26.+0000:6a3027a3-8396-4761-b3cf-c952d76ee702:cxp-shopping-services-qa-ev6v-sit2w-nscxp-6b5fc85895-6fk9d:nssit2\"}}";
        RetrieveCartUIResponse response = mapper.readValue(responseString, RetrieveCartUIResponse.class);
        ReflectionTestUtils.invokeMethod(cartController, "populateSOEResponseForRetriveCartPlanbuilder", response);
        Assert.assertNotNull(response.getData());
    }
    @Test
    public void dataForOrderReviewHandOffPageTest() {
        URI url = URI.create("http://localhost/validateCartAndCheckout");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("accountNumber", "0380416061-00001").header("channelId","OMNI-RETAIL").build();
        ReflectionTestUtils.invokeMethod(cartController, "dataForOrderReviewHandOffPage", httpHeader);

        when(omniDLHelper.getVzdlDataForEventAndPage(any(),any())).thenReturn(new Vzdl());
        doNothing().when(cartAddDeviceHelper).updateDLDataForAssisted(any());
        ReflectionTestUtils.invokeMethod(cartController, "dataForOrderReviewHandOffPage", httpHeader);

        doThrow(RuntimeException.class).when(cartAddDeviceHelper).updateDLDataForAssisted(any());
        ReflectionTestUtils.invokeMethod(cartController, "dataForOrderReviewHandOffPage", httpHeader);
        Assert.assertNotNull(httpHeader.getHeaders());
        httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "abc").build();
        ReflectionTestUtils.invokeMethod(cartController, "dataForOrderReviewHandOffPage", httpHeader);
        Assert.assertNotNull(httpHeader);

    }
}