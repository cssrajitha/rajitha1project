package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import junit.framework.Assert;
import onevz.soe.cart.controller.CartBbpController;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.helper.*;
import onevz.soe.cart.requests.BBPRequestVO;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.responses.AddDeviceUIResponse;
import onevz.soe.cart.ui.responses.DeviceSimDetailsUIResponse;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.ResourceUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.nio.file.Files;

import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { CartServiceTestConfig.class })
public class CartBbpController2Test {

	@MockBean
	private UpdateCartHelper cartHelper;
	@Autowired
	private CartBbpController cartController;
	@Autowired
	private ObjectMapper mapper;

	@MockBean
	private RedisHelper redisHelper;

	@MockBean
	private RedisHelper2 redisHelper2;
	@MockBean
	private CartAddDeviceHelper accDevHelper;
	@MockBean
	private CartServiceCXPServices cxpService;

	//added for startBBPFlow Esim flows
	@Test
	public void startBBPFlowTest11() throws IOException {
		File responseFile = ResourceUtils.getFile("src/test/resources/DeviceSimDetailsUIResponse.json");
		String responseString = new String(Files.readAllBytes(responseFile.toPath()));
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		DeviceSimDetailsUIResponse response = mapper.readValue(responseString, DeviceSimDetailsUIResponse.class);
		response.getUiData().getDeviceInfo().setDacc("01435");
		String addDeviceStr = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1596531-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"},{\"path\":\"FeatureConflicts\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"registerNumber\":0,\"accountNumber\":\"0220561307-00002\",\"cartCreator\":\"8439410557\",\"processingMTN\":\"8439292610\"},\"cartInfo\":{\"method\":\"\",\"financeLimitExceeded\":\"false\",\"cartId\":\"9c43a538-bcd8-4c1f-b271-6eb043271223\",\"clientAppName\":\"VZW-NETACE\",\"statusCode\":\"1\",\"statusMsg\":\"Success\",\"lines\":[{\"plan\":{},\"status\":1,\"errors\":[],\"spos\":[{\"id\":\"1167\",\"actionIndicator\":\"Z\",\"success\":true,\"is5GBolt\":false}],\"sfos\":[],\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"mtn\":\"8439292610\",\"device\":{\"cartItemType\":\"\",\"quantityOnHand\":\"\",\"upgradeReasonCode\":\"\",\"id\":\"MQ722LL/A\",\"description\":\"\",\"itemPrice\":\"449.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"discounts\":\"\",\"existingDeviceId\":\"\",\"existingDeviceName\":\"iPhone&reg; 8\",\"removedFeatures\":\"\",\"fiveGToFourGDownGrade\":false},\"sim\":{\"simId\":\"\",\"id\":\"EMBD4GSIM-N\"},\"warranty\":{\"id\":\"\",\"itemPrice\":\"0.0\",\"discounts\":\"\"},\"upgradeFee\":{\"id\":\"\",\"itemPrice\":\"\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"AAL\",\"currentPlanType\":\"ALP\"}],\"expressCheckout\":false,\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false},\"processMTNList\":[{\"mtn\":\"8439292610\",\"completedprocessSteps\":[\"pastDuePage\",\"MTNSelectionPage\",\"InterimPage\",\"GridWallPDP\",\"GridWallPDP\",\"MTNSelectionPage\",\"InterimPage\",\"GridWallPDP\",\"GridWallPDP\",\"GridWallPDP\"]}]}}}}";
		AddDeviceUIResponse responseServiceMono = mapper.readValue(addDeviceStr, AddDeviceUIResponse.class);
		CartRedisData redisData = new CartRedisData();
		redisData.setEsimType("IPAD");
		when(redisHelper2.upsertAccountInfoEligibleInRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(redisData));
		URI url = URI.create("http://localhost/startBBPFlow");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = null;
		String bbpRequestVOString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"iccid\":\"89148000000835900342\",\"eid\":\"89049032006008882600043470578492\",\"imei\":\"352898071702915\",\"isSmartphone\":true}";
		BBPRequestVO bbpRequestVO = mapper.readValue(bbpRequestVOString, BBPRequestVO.class);
		when(cartHelper.initiateBBPFlow(Mockito.any())).thenReturn(Mono.just(response));
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(responseServiceMono));
		when(redisHelper2.upsertBBPFlowDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
		when(redisHelper2.upsertAddDeviceDataIntoRedis(Mockito.any())).thenReturn(Mono.just(new CartRedisData()));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.startBBPFlow(httpHeader, httpResponse,
				bbpRequestVO);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}
}
