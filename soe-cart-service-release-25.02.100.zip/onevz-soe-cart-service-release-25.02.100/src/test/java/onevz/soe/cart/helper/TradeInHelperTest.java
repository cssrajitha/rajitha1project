package onevz.soe.cart.helper;

import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.tradein.session.client.TradeinSessionDataStoreClient;
import onevz.soe.cart.bpm.service.CartServiceBPMServices;
import onevz.soe.cart.constants.TradeinConstants;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.helper.CartAddDeviceHelper;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.helper.TradeInHelper;

import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.tradeIn.AccountDevice;
import onevz.soe.cart.model.tradeIn.TradeinAccountDevicesRequest;
import onevz.soe.cart.model.tradeIn.TradeinAccountDevicesResponse;
import onevz.soe.cart.model.tradeIn.addTradeinToCart.TradeinAddToCartRequest;
import onevz.soe.cart.model.tradeIn.addTradeinToCart.TradeinAddToCartResponse;
import onevz.soe.cart.model.tradeIn.appraiseDevice.TradeinAppraisalResponse;
import onevz.soe.cart.model.tradeIn.appraiseDevice.TradeinDeviceAppraisalRequest;
import onevz.soe.cart.model.tradeIn.getTradeinQuestions.TradeinAppraisalQuestionsRequest;
import onevz.soe.cart.model.tradeIn.getTradeinQuestions.TradeinAppraisalQuestionsResponse;
import onevz.soe.cart.model.tradeIn.validateDevice.TradeinValidateDeviceData;
import onevz.soe.cart.model.tradeIn.validateDevice.TradeinValidateDeviceResponse;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.AddDeviceUIRequest;
import onevz.soe.cart.ui.responses.AddDeviceUIResponse;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.tradein.session.model.TradeinSessionData;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { CartServiceTestConfig.class })
//@WebFluxTest(TradeInHelper.class)
public class TradeInHelperTest {

    @Autowired
    private ObjectMapper mapper;

    @InjectMocks
    private TradeInHelper tradeInHelper;

    @Autowired
    SourceFileReaderUtil sourceFileReaderUtil;

    @Mock
    private CartServiceCXPServices cxpService;

    @Mock
    private CartServiceBPMServices bpmService;

    @Mock
    private RedisHelper redisHelper;

    @Mock
    private CartAddDeviceHelper deviceHelper;
    @Mock
    private TradeinSessionDataStoreClient tradeinSessionDataStoreClient;

    @Mock
    TradeinSessionData tradeinSessionData;

    private static  final String TRADEIN_HASHKEY= "tradeInKey";

    @Value("${onevz.soe.cart.test.fileLocation}")
    private String testFileLocation;
    String modelId = "116632";
    String deviceId = "353973103148186";

    @Autowired
    SOELoginSessionBean sessionBean;

    @Before
    public void setup(){
        ReflectionTestUtils.setField(tradeInHelper,"objectMapper",mapper);
    }

    @Test
    public void validateAndAddTradeTest() throws IOException {
        String requestFile = "MockAddDeviceWithPlanRequest.json";
        String responseFile = "MockAddDeviceHelperTestResponse.json";
        String aalRequestFile = "MockAddDeviceWithPlanAALRequest.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        String aalSampleRequestString = sourceFileReaderUtil.readFile(aalRequestFile, testFileLocation);
        String errorResponseString = "{ \"tradeInAdded\": true, \"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";

        AddDeviceUIResponse errResponse = mapper.readValue(errorResponseString, AddDeviceUIResponse.class);
        AddDeviceUIResponse responseServiceMono = new AddDeviceUIResponse();
        AddDeviceUIRequest UIRequest = new AddDeviceUIRequest();
        ServerHttpResponse httpResponse = Mockito.mock(ServerHttpResponse.class);
        UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        responseServiceMono = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);

        String accountDeviceErrorResponse = "{ \"errors\": [{ \"namespace\": \"cxp-customerprofile-services\", \"name\": \"DEVICE_PIBDEVICE_Y_PREPAY_ELIGIBILITY\", \"id\": \"3608\", \"debug_id\": \"2022-04-22T16:16:46.+0000:208170a9-537f-426c-ab79-ccfe1674da30:cxp-customerprofile-services-668f6d4d8c-ndr92:eksnsprode\", \"message\": \"Error\", \"category\": \"BUSINESS_ERR\" }] }";

        String accountDeviceResponseFile = "MockTradeinAccountDevicesResponse.json";
        TradeinAccountDevicesResponse tradeinAccountDevicesResponse = new TradeinAccountDevicesResponse();
        TradeinAccountDevicesRequest tradeinAccountDevicesRequest = new TradeinAccountDevicesRequest();
        String accountDeviceResponseString = sourceFileReaderUtil.readFile(accountDeviceResponseFile, testFileLocation);
        tradeinAccountDevicesResponse = mapper.readValue(accountDeviceResponseString, TradeinAccountDevicesResponse.class);

        String validateDeviceErrorResponse = "";
        String validateDeviceResponseFile = "MockTradeinValidateDeviceResponse.json";
        TradeinValidateDeviceResponse tradeinValidateDeviceResponse = new TradeinValidateDeviceResponse();
        String validateDeviceResponseString = sourceFileReaderUtil.readFile(validateDeviceResponseFile, testFileLocation);
        tradeinValidateDeviceResponse = mapper.readValue(validateDeviceResponseString, TradeinValidateDeviceResponse.class);


        String getQuestionErrorResponse = "";
        String getQuestionResponseFile = "MockTradeinAppraisalQuestionsResponse.json";
        TradeinAppraisalQuestionsRequest tradeinAppraisalQuestionsRequest = new TradeinAppraisalQuestionsRequest();
        TradeinAppraisalQuestionsResponse tradeinAppraisalQuestionsResponse = new TradeinAppraisalQuestionsResponse();
        String getQuestionResponseString = sourceFileReaderUtil.readFile(getQuestionResponseFile, testFileLocation);

        tradeinAppraisalQuestionsResponse = mapper.readValue(getQuestionResponseString, TradeinAppraisalQuestionsResponse.class);

        String appraiseErrorResponse = "";
        String appraiseResponseFile = "MockTradeinAppraisalResponse.json";
        TradeinDeviceAppraisalRequest tradeinDeviceAppraisalRequest = new TradeinDeviceAppraisalRequest();
        TradeinAppraisalResponse tradeinAppraisalResponse = new TradeinAppraisalResponse();
        String appraiseResponseString = sourceFileReaderUtil.readFile(appraiseResponseFile, testFileLocation);
        tradeinAppraisalResponse = mapper.readValue(appraiseResponseString, TradeinAppraisalResponse.class);

        String addTradeErrorResponse = "";
        String addTradeResponseFile = "MockTradeinAddToCartResponse.json";
        TradeinAddToCartRequest pegaRequest = new TradeinAddToCartRequest();
        TradeinAddToCartResponse tradeinAddToCartResponse = new TradeinAddToCartResponse();
        String addTradeResponseString = sourceFileReaderUtil.readFile(addTradeResponseFile, testFileLocation);

        tradeinAddToCartResponse = mapper.readValue(addTradeResponseString, TradeinAddToCartResponse.class);

        String redisFile = "MockAddDeviceHelperTestRedisData.json";
        String redisDataString = sourceFileReaderUtil.readFile(redisFile, testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);

        String pegaRequestFile = "MockPegaRequest.json";
        String pegaRequestFileString = sourceFileReaderUtil.readFile(pegaRequestFile, testFileLocation);
        pegaRequest = mapper.readValue(pegaRequestFileString, TradeinAddToCartRequest.class);

        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(cxpService.getAccountDevicesData(Mockito.any())).thenReturn(Mono.just(tradeinAccountDevicesResponse));
        when(cxpService.validateDevice(Mockito.any())).thenReturn(Mono.just(tradeinValidateDeviceResponse));
        when(cxpService.getAppraisalQuestionsData(Mockito.any())).thenReturn(Mono.just(tradeinAppraisalQuestionsResponse));
        when(cxpService.appraiseDevice(Mockito.any())).thenReturn(Mono.just(tradeinAppraisalResponse));
        when(bpmService.addTradeinToCart(Mockito.any())).thenReturn(Mono.just(tradeinAddToCartResponse));
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(errResponse));
        // calling controller
        Mono<AddDeviceUIResponse> response = tradeInHelper.validateAndAddTrade(UIRequest,httpResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        UIRequest = mapper.readValue(aalSampleRequestString, AddDeviceUIRequest.class);
        tradeinAccountDevicesResponse.getData().setCustomerDetails(null);
        when(cxpService.getAccountDevicesData(Mockito.any())).thenReturn(Mono.just(tradeinAccountDevicesResponse));
        Mono<AddDeviceUIResponse> tradeResponse = tradeInHelper.validateAndAddTrade(UIRequest,httpResponse);
        StepVerifier.create(tradeResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        UIRequest.getCartInfo().setCartId("12345");
        sampleRedisData.setCartId("");
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        StepVerifier.create(tradeInHelper.validateAndAddTrade(UIRequest,httpResponse)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        UIRequest.getCartInfo().setCartId(null);
        sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setCartId("");
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        StepVerifier.create(tradeInHelper.validateAndAddTrade(UIRequest,httpResponse)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        UIRequest.getCartInfo().setCartId("12345");
        sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        StepVerifier.create(tradeInHelper.validateAndAddTrade(UIRequest,httpResponse)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        responseServiceMono.setErrors(Collections.emptyList());
        when(deviceHelper.addDevice(UIRequest,httpResponse)).thenReturn(Mono.just(responseServiceMono));
        StepVerifier.create(tradeInHelper.validateAndAddTrade(UIRequest,httpResponse)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        UIRequest.getCartInfo().setIntendType("NSEBYOD");
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(responseServiceMono));
        StepVerifier.create(tradeInHelper.validateAndAddTrade(UIRequest,httpResponse)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        UIRequest.getCartInfo().setIntendType("NSE");
        sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        StepVerifier.create(tradeInHelper.validateAndAddTrade(UIRequest,httpResponse)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        responseServiceMono.setErrors(null);
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(responseServiceMono));
        StepVerifier.create(tradeInHelper.validateAndAddTrade(UIRequest,httpResponse)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

    }


    //@Ignore
    @Test
    public void validateAndAddTradeInTest() throws IOException, SOEHTTPException {
        String requestFile = "MockAddDeviceWithPlanRequest.json";
        String responseFile = "MockAddDeviceHelperTestResponse.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        String errorResponseString = "{ \"tradeInAdded\": true, \"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";

        AddDeviceUIResponse errResponse = mapper.readValue(errorResponseString, AddDeviceUIResponse.class);
        AddDeviceUIResponse responseServiceMono = new AddDeviceUIResponse();
        AddDeviceUIRequest UIRequest = new AddDeviceUIRequest();
        UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        responseServiceMono = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);

        String accountDeviceErrorResponseString = "{ \"errors\": [{ \"namespace\": \"cxp-customerprofile-services\", \"name\": \"DEVICE_PIBDEVICE_Y_PREPAY_ELIGIBILITY\", \"id\": \"3608\", \"debug_id\": \"2022-04-22T16:16:46.+0000:208170a9-537f-426c-ab79-ccfe1674da30:cxp-customerprofile-services-668f6d4d8c-ndr92:eksnsprode\", \"message\": \"Error\", \"category\": \"BUSINESS_ERR\" }] }";
        TradeinAccountDevicesResponse accountDeviceErrorResponse = mapper.readValue(accountDeviceErrorResponseString, TradeinAccountDevicesResponse.class);

        String accountDeviceResponseFile = "MockTradeinAccountDevicesResponse.json";
        TradeinAccountDevicesResponse tradeinAccountDevicesResponse = new TradeinAccountDevicesResponse();
        TradeinAccountDevicesRequest tradeinAccountDevicesRequest = new TradeinAccountDevicesRequest();
        String accountDeviceResponseString = sourceFileReaderUtil.readFile(accountDeviceResponseFile, testFileLocation);
        tradeinAccountDevicesResponse = mapper.readValue(accountDeviceResponseString, TradeinAccountDevicesResponse.class);

        String validateDeviceResponseFile = "MockTradeinValidateDeviceResponse.json";
        TradeinValidateDeviceResponse tradeinValidateDeviceResponse = new TradeinValidateDeviceResponse();
        String validateDeviceResponseString = sourceFileReaderUtil.readFile(validateDeviceResponseFile, testFileLocation);
        tradeinValidateDeviceResponse = mapper.readValue(validateDeviceResponseString, TradeinValidateDeviceResponse.class);

        String getQuestionResponseFile = "MockTradeinAppraisalQuestionsResponse.json";
        TradeinAppraisalQuestionsRequest tradeinAppraisalQuestionsRequest = new TradeinAppraisalQuestionsRequest();
        TradeinAppraisalQuestionsResponse tradeinAppraisalQuestionsResponse = new TradeinAppraisalQuestionsResponse();
        String getQuestionResponseString = sourceFileReaderUtil.readFile(getQuestionResponseFile, testFileLocation);
        tradeinAppraisalQuestionsResponse = mapper.readValue(getQuestionResponseString, TradeinAppraisalQuestionsResponse.class);

        String appraiseResponseFile = "MockTradeinAppraisalResponse.json";
        TradeinDeviceAppraisalRequest tradeinDeviceAppraisalRequest = new TradeinDeviceAppraisalRequest();
        TradeinAppraisalResponse tradeinAppraisalResponse = new TradeinAppraisalResponse();
        String appraiseResponseString = sourceFileReaderUtil.readFile(appraiseResponseFile, testFileLocation);
        tradeinAppraisalResponse = mapper.readValue(appraiseResponseString, TradeinAppraisalResponse.class);

        String addTradeResponseFile = "MockTradeinAddToCartResponse.json";
        TradeinAddToCartRequest pegaRequest = new TradeinAddToCartRequest();
        TradeinAddToCartResponse tradeinAddToCartResponse = new TradeinAddToCartResponse();
        String addTradeResponseString = sourceFileReaderUtil.readFile(addTradeResponseFile, testFileLocation);

        tradeinAddToCartResponse = mapper.readValue(addTradeResponseString, TradeinAddToCartResponse.class);

        String redisFile = "MockAddDeviceHelperTestRedisData.json";
        String redisDataString = sourceFileReaderUtil.readFile(redisFile, testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);

        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(cxpService.getAccountDevicesData(Mockito.any())).thenReturn(Mono.just(tradeinAccountDevicesResponse));
        when(cxpService.validateDevice(Mockito.any())).thenReturn(Mono.just(tradeinValidateDeviceResponse));
        when(cxpService.getAppraisalQuestionsData(Mockito.any())).thenReturn(Mono.just(tradeinAppraisalQuestionsResponse));
        when(cxpService.appraiseDevice(Mockito.any())).thenReturn(Mono.just(tradeinAppraisalResponse));

        when(bpmService.addTradeinToCart(Mockito.any())).thenReturn(Mono.just(tradeinAddToCartResponse));
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(errResponse));

        AddDeviceUIResponse expectedResponse = responseServiceMono;
        Mono<TradeinAddToCartResponse> response = tradeInHelper.validateAndAddTradeIn(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        UIRequest.getCartInfo().setIntendType("MSE");
        UIRequest.getCartInfo().setCartId(null);
        StepVerifier.create(tradeInHelper.validateAndAddTradeIn(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        sampleRedisData.setCaseId(null);
        sampleRedisData.setAccountNumber(null);
        sampleRedisData.setMtn(null);
        sampleRedisData.setCartCreator(null);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        StepVerifier.create(tradeInHelper.validateAndAddTradeIn(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));

        UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        UIRequest.getData().getLines().stream().forEach(f-> f.setCurrentDeviceID(null));
        StepVerifier.create(tradeInHelper.validateAndAddTradeIn(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp.getErrorData())).expectComplete().verify();


        UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        UIRequest.getData().setLines(Arrays.asList(new Lines(), new Lines(), new Lines()));
        StepVerifier.create(tradeInHelper.validateAndAddTradeIn(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp.getErrorData())).expectComplete().verify();

        UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        UIRequest.getData().setLines(null);
        StepVerifier.create(tradeInHelper.validateAndAddTradeIn(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp.getErrorData())).expectComplete().verify();
        UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);

        tradeinAddToCartResponse.getServiceBody().getServiceResponse().getContext().getContextInfo().setProcessStep(null);
        when(tradeInHelper.addTradeinToCart(tradeinAppraisalResponse,UIRequest,deviceId,"")).thenReturn(Mono.just(tradeinAddToCartResponse));
        StepVerifier.create(tradeInHelper.validateAndAddTradeIn(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        tradeinAddToCartResponse.getServiceBody().getServiceResponse().getContext().setContextInfo(null);
        when(tradeInHelper.addTradeinToCart(tradeinAppraisalResponse,UIRequest,deviceId,"")).thenReturn(Mono.just(tradeinAddToCartResponse));
        StepVerifier.create(tradeInHelper.validateAndAddTradeIn(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        tradeinAddToCartResponse.getServiceBody().getServiceResponse().setContext(null);
        when(tradeInHelper.addTradeinToCart(tradeinAppraisalResponse,UIRequest,deviceId,"")).thenReturn(Mono.just(tradeinAddToCartResponse));
        StepVerifier.create(tradeInHelper.validateAndAddTradeIn(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        tradeinAddToCartResponse.getServiceBody().setServiceResponse(null);
        when(tradeInHelper.addTradeinToCart(tradeinAppraisalResponse,UIRequest,deviceId,"")).thenReturn(Mono.just(tradeinAddToCartResponse));
        StepVerifier.create(tradeInHelper.validateAndAddTradeIn(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        tradeinAddToCartResponse.setServiceBody(null);
        when(tradeInHelper.addTradeinToCart(tradeinAppraisalResponse,UIRequest,deviceId,"")).thenReturn(Mono.just(tradeinAddToCartResponse));
        StepVerifier.create(tradeInHelper.validateAndAddTradeIn(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        when(tradeInHelper.addTradeinToCart(tradeinAppraisalResponse,UIRequest,deviceId,"RX")).thenReturn(null);
        StepVerifier.create(tradeInHelper.validateAndAddTradeIn(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        tradeinAppraisalResponse.setData(null);
        when(tradeInHelper.appraiseDevice(tradeinAppraisalQuestionsResponse, UIRequest, deviceId, modelId, "", tradeinValidateDeviceResponse)).thenReturn(Mono.just(tradeinAppraisalResponse));
        StepVerifier.create(tradeInHelper.validateAndAddTradeIn(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        when(tradeInHelper.appraiseDevice(tradeinAppraisalQuestionsResponse, UIRequest, deviceId, modelId, "", tradeinValidateDeviceResponse)).thenReturn(null);
        StepVerifier.create(tradeInHelper.validateAndAddTradeIn(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        tradeinAppraisalQuestionsResponse.setData(null);
        when(tradeInHelper.getQuestions(modelId, deviceId)).thenReturn(Mono.just(tradeinAppraisalQuestionsResponse));
        StepVerifier.create(tradeInHelper.validateAndAddTradeIn(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        when(tradeInHelper.getQuestions(modelId, deviceId)).thenReturn(null);
        StepVerifier.create(tradeInHelper.validateAndAddTradeIn(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        tradeinValidateDeviceResponse.setData(null);
        when(tradeInHelper.valdiateDevice(UIRequest, modelId, deviceId)).thenReturn(Mono.just(tradeinValidateDeviceResponse));
        StepVerifier.create(tradeInHelper.validateAndAddTradeIn(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        tradeinValidateDeviceResponse.setData(new TradeinValidateDeviceData());
        tradeinValidateDeviceResponse.setErrors(Arrays.asList(new CartError()));
        when(tradeInHelper.valdiateDevice(UIRequest, modelId, deviceId)).thenReturn(Mono.just(tradeinValidateDeviceResponse));
        StepVerifier.create(tradeInHelper.validateAndAddTradeIn(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        when(tradeInHelper.valdiateDevice(UIRequest, modelId, deviceId)).thenReturn(null);
        StepVerifier.create(tradeInHelper.validateAndAddTradeIn(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        tradeinAccountDevicesResponse.getData().getDeviceList().stream().forEach(f->f.setModelId(null));
        when(tradeInHelper.getAccountDevices(UIRequest)).thenReturn(Mono.just(tradeinAccountDevicesResponse));
        StepVerifier.create(tradeInHelper.validateAndAddTradeIn(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        tradeinAccountDevicesResponse.getData().setDeviceList(Collections.emptyList());
        when(tradeInHelper.getAccountDevices(UIRequest)).thenReturn(Mono.just(tradeinAccountDevicesResponse));
        StepVerifier.create(tradeInHelper.validateAndAddTradeIn(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        tradeinAccountDevicesResponse.getData().setDeviceList(null);
        when(tradeInHelper.getAccountDevices(UIRequest)).thenReturn(Mono.just(tradeinAccountDevicesResponse));
        StepVerifier.create(tradeInHelper.validateAndAddTradeIn(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        tradeinAccountDevicesResponse.getData().setDeviceList(Arrays.asList(new AccountDevice()));
        tradeinAccountDevicesResponse.setErrors(Arrays.asList(new CartError()));
        when(tradeInHelper.getAccountDevices(UIRequest)).thenReturn(Mono.just(tradeinAccountDevicesResponse));
        StepVerifier.create(tradeInHelper.validateAndAddTradeIn(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        tradeinAccountDevicesResponse.setData(null);
        tradeinAccountDevicesResponse.setErrors(null);
        when(tradeInHelper.getAccountDevices(UIRequest)).thenReturn(Mono.just(tradeinAccountDevicesResponse));
        StepVerifier.create(tradeInHelper.validateAndAddTradeIn(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        UIRequest.getData().setLines(Collections.emptyList());
        StepVerifier.create(tradeInHelper.validateAndAddTradeIn(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void getAccountDevicesTest() throws IOException{
        String accountDeviceResponseFile = "MockTradeinAccountDevicesResponse.json";
        String accountDeviceResponseString = sourceFileReaderUtil.readFile(accountDeviceResponseFile, testFileLocation);
        TradeinAccountDevicesResponse tradeinAccountDevicesResponse = mapper.readValue(accountDeviceResponseString, TradeinAccountDevicesResponse.class);
        when(cxpService.getAccountDevicesData(Mockito.any())).thenReturn(Mono.just(tradeinAccountDevicesResponse));

        String requestFile = "MockAddDeviceWithPlanRequest.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        AddDeviceUIRequest addDeviceUIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);

        Mono<TradeinAccountDevicesResponse> response = tradeInHelper.getAccountDevices(addDeviceUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void getQuestionsTest() throws IOException{
        String getQuestionResponseFile = "MockTradeinAppraisalQuestionsResponse.json";
        String getQuestionResponseString = sourceFileReaderUtil.readFile(getQuestionResponseFile, testFileLocation);
        TradeinAppraisalQuestionsResponse tradeinAppraisalQuestionsResponse = mapper.readValue(getQuestionResponseString, TradeinAppraisalQuestionsResponse.class);
        when(cxpService.getAppraisalQuestionsData(Mockito.any())).thenReturn(Mono.just(tradeinAppraisalQuestionsResponse));
        Mono<TradeinAppraisalQuestionsResponse> response = tradeInHelper.getQuestions(modelId, deviceId);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void appraiseDeviceTest() throws IOException {
        // 1st argument
        String getQuestionResponseFile = "MockTradeinAppraisalQuestionsResponse.json";
        String getQuestionResponseString = sourceFileReaderUtil.readFile(getQuestionResponseFile, testFileLocation);
        TradeinAppraisalQuestionsResponse tradeinAppraisalQuestionsResponse = mapper.readValue(getQuestionResponseString, TradeinAppraisalQuestionsResponse.class);
        // 2nd argument
        String requestFile = "MockAddDeviceWithPlanRequest.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        AddDeviceUIRequest addDeviceUIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        // last argument
        String validateDeviceResponseFile = "MockTradeinValidateDeviceResponse.json";
        TradeinValidateDeviceResponse tradeinValidateDeviceResponse = new TradeinValidateDeviceResponse();
        String validateDeviceResponseString = sourceFileReaderUtil.readFile(validateDeviceResponseFile, testFileLocation);
        tradeinValidateDeviceResponse = mapper.readValue(validateDeviceResponseString, TradeinValidateDeviceResponse.class);
        //mocking service
        String appraiseResponseFile = "MockTradeinAppraisalResponse.json";
        String appraiseResponseString = sourceFileReaderUtil.readFile(appraiseResponseFile, testFileLocation);
        TradeinAppraisalResponse tradeinAppraisalResponse = mapper.readValue(appraiseResponseString, TradeinAppraisalResponse.class);
        when(cxpService.appraiseDevice(Mockito.any())).thenReturn(Mono.just(tradeinAppraisalResponse));
        tradeinValidateDeviceResponse.getData().getDeviceValidateOutInfo().get(0).setLocked(false);
        //calling controller
        Mono<TradeinAppraisalResponse> response = tradeInHelper.appraiseDevice(tradeinAppraisalQuestionsResponse, addDeviceUIRequest, deviceId, modelId, "", tradeinValidateDeviceResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        tradeinValidateDeviceResponse.getData().getDeviceValidateOutInfo().get(0).setLocked(true);
        StepVerifier.create(tradeInHelper.appraiseDevice(tradeinAppraisalQuestionsResponse, addDeviceUIRequest, deviceId, modelId, "", tradeinValidateDeviceResponse)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        tradeinValidateDeviceResponse.getData().setDeviceValidateOutInfo(null);
        StepVerifier.create(tradeInHelper.appraiseDevice(tradeinAppraisalQuestionsResponse, addDeviceUIRequest, deviceId, modelId, "", tradeinValidateDeviceResponse)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        tradeinValidateDeviceResponse.getData().setDeviceValidateOutInfo(Collections.emptyList());
        StepVerifier.create(tradeInHelper.appraiseDevice(tradeinAppraisalQuestionsResponse, addDeviceUIRequest, deviceId, modelId, "", tradeinValidateDeviceResponse)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addTradeinToCartTest() throws IOException{
        // 1st argument
        String requestFile = "MockAddDeviceWithPlanRequest.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        AddDeviceUIRequest addDeviceUIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        addDeviceUIRequest.getCartInfo().setEditFromPage("MNC");
        // 2nd argument
        String appraiseResponseFile = "MockTradeinAppraisalResponse.json";
        String appraiseResponseString = sourceFileReaderUtil.readFile(appraiseResponseFile, testFileLocation);
        TradeinAppraisalResponse tradeinAppraisalResponse = mapper.readValue(appraiseResponseString, TradeinAppraisalResponse.class);
        System.out.println(tradeinAppraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).getTradeInStatus());
        // mocking service
        String addTradeResponseFile = "MockTradeinAddToCartResponse.json";
        String addTradeResponseString = sourceFileReaderUtil.readFile(addTradeResponseFile, testFileLocation);
        TradeinAddToCartResponse tradeinAddToCartResponse = mapper.readValue(addTradeResponseString, TradeinAddToCartResponse.class);
        when(bpmService.addTradeinToCart(Mockito.any())).thenReturn(Mono.just(tradeinAddToCartResponse));
        // calling controller
        Mono<TradeinAddToCartResponse> response = tradeInHelper.addTradeinToCart(tradeinAppraisalResponse,addDeviceUIRequest,deviceId,"");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        String nseRequestFile = "MockAddDeviceWithPlanNSERequest.json";
        String nseSampleRequestString = sourceFileReaderUtil.readFile(nseRequestFile, testFileLocation);
        AddDeviceUIRequest nseAddDeviceUIRequest = mapper.readValue(nseSampleRequestString, AddDeviceUIRequest.class);

        Mono<TradeinAddToCartResponse> nseResponse = tradeInHelper.addTradeinToCart(tradeinAppraisalResponse,nseAddDeviceUIRequest,deviceId,"");
        StepVerifier.create(nseResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        // false check case 1
        tradeinAppraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).setTradeInStatus("");
        tradeinAppraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).setTriageInfo(null);
        tradeinAppraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).setRecycleDeviceOffer(null);
        StepVerifier.create(tradeInHelper.addTradeinToCart(tradeinAppraisalResponse,addDeviceUIRequest,deviceId,"")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void valdiateDeviceTest() throws IOException {
        // 1st argument
        String requestFile = "MockAddDeviceWithPlanRequest.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        AddDeviceUIRequest addDeviceUIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        // mocking service
        String validateDeviceResponseFile = "MockTradeinValidateDeviceResponse.json";
        String validateDeviceResponseString = sourceFileReaderUtil.readFile(validateDeviceResponseFile, testFileLocation);
        TradeinValidateDeviceResponse tradeinValidateDeviceResponse = mapper.readValue(validateDeviceResponseString, TradeinValidateDeviceResponse.class);
        when(cxpService.validateDevice(Mockito.any())).thenReturn(Mono.just(tradeinValidateDeviceResponse));
        // calling controller
        Mono<TradeinValidateDeviceResponse> response = tradeInHelper.valdiateDevice(addDeviceUIRequest, modelId, deviceId);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        //AAL
        String aalRequestFile = "MockAddDeviceWithPlanAALRequest.json";
        String aalSampleRequestString = sourceFileReaderUtil.readFile(aalRequestFile, testFileLocation);
        AddDeviceUIRequest aalAddDeviceUIRequest = mapper.readValue(aalSampleRequestString, AddDeviceUIRequest.class);

        when(cxpService.validateDevice(Mockito.any())).thenReturn(Mono.just(tradeinValidateDeviceResponse));
        // calling controller
        Mono<TradeinValidateDeviceResponse> aalResponse = tradeInHelper.valdiateDevice(aalAddDeviceUIRequest, modelId, deviceId);
        StepVerifier.create(aalResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

    }

    @Test
    public  void  isNotEmptyOrNullTest() {
        String response = tradeInHelper.isNotEmptyOrNull(deviceId);
        Assert.assertEquals(response,deviceId);

        String responseEmptyCase = tradeInHelper.isNotEmptyOrNull("");
        Assert.assertEquals(responseEmptyCase,"");
    }

    @Test
    public void getDeviceIdTypeTest(){
        String response = tradeInHelper.getDeviceIdType(deviceId);
        Assert.assertEquals(response,"IME");

        String responseCaseEmpty = tradeInHelper.getDeviceIdType("");
        Assert.assertEquals(responseCaseEmpty,"");

        String responseCaseInvalid = tradeInHelper.getDeviceIdType("$$$%^&!@#");
        Assert.assertEquals(responseCaseInvalid,"");

        String responseCaseESN1 = tradeInHelper.getDeviceIdType("33800168600");
        Assert.assertEquals(responseCaseESN1,"ESN");

        String responseCaseESN2 = tradeInHelper.getDeviceIdType("15tgsdhfn60u");
        Assert.assertEquals(responseCaseESN2,"ESN");
    }

    @Test
    public void updateTradeInSessionData() {
        when(tradeinSessionDataStoreClient.upsertTradeinSessionData(TRADEIN_HASHKEY, TradeinConstants.TRADEIN_SESSION_SUBKEY, tradeinSessionData)).thenReturn(Mono.just(true));
        StepVerifier.create(tradeInHelper.updateTradeinSessionData(TRADEIN_HASHKEY, tradeinSessionData)).assertNext(resp -> Assert.assertTrue(resp)).expectComplete().verify();
    }

    @Test
    public void updateTradeInSessionData_failure() {
        when(tradeinSessionDataStoreClient.upsertTradeinSessionData(TRADEIN_HASHKEY, TradeinConstants.TRADEIN_SESSION_SUBKEY, tradeinSessionData)).thenReturn(Mono.error(new RuntimeException("Test")));
        StepVerifier.create(tradeInHelper.updateTradeinSessionData(TRADEIN_HASHKEY, tradeinSessionData)).assertNext(resp -> Assert.assertFalse(resp)).expectComplete().verify();
    }

    @Test
    public void readTradeInSessionData() {
        when(tradeinSessionDataStoreClient.readTradeinSessionData(TRADEIN_HASHKEY, TradeinConstants.TRADEIN_SESSION_SUBKEY)).thenReturn(Mono.just(tradeinSessionData));
        StepVerifier.create(tradeInHelper.readTradeinSessionData(TRADEIN_HASHKEY)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void readTradeInSessionData_failure() {
        when(tradeinSessionDataStoreClient.readTradeinSessionData(TRADEIN_HASHKEY, TradeinConstants.TRADEIN_SESSION_SUBKEY)).thenReturn(Mono.error(new RuntimeException("Test")));
        StepVerifier.create(tradeInHelper.readTradeinSessionData(TRADEIN_HASHKEY)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }
}
