package onevz.soe.cart.service.test.common;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.net.URI;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fasterxml.jackson.databind.ObjectMapper;

import onevz.soe.cart.controller.CartTYSValidationController;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.helper.UpdateCartHelper;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.requests.ReviewOrderTYSUIRequest;
import onevz.soe.cart.ui.responses.ReviewOrderTYSUIResponse;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(CartTYSValidationController.class)
public class CartTYSValidationControllerTest {
	
	@InjectMocks
	CartTYSValidationController cartTYSValidationController;
	
	@Mock
	UpdateCartHelper helper;

	@Mock
	RedisHelper redisHelper;

	@Autowired
	ObjectMapper mapper;
	
	@Test(expected=AssertionError.class)
    public void tysOrderReviewValidationTest() throws IOException {
        String requestString = "{ \"cartInfo\": { \"clientAppName\": \"VZW-NETACE\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"cartId\": \"cbf26bd7-035a-49a0-ba2c-e320bc46f3bf\", \"caseId\": \"SOP-20647-E01\", \"accountNumber\": \"0224065213-00001\", \"cartCreator\": \"2402169848\", \"processingMTN\": \"2402169848\", \"locationCode\": \"E319201\" } }";
        String responseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-NETACE\", \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \"SOP-20647-E01\", \"contextInfo\": { \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"OrderReview-Shipping-Payment-Agreement\", \"processAction\": \"\", \"availablePaths\": [ { \"path\": \"AvailablePaths\" } ] }, \"cartInfo\": { \"cartId\": \"cbf26bd7-035a-49a0-ba2c-e320bc46f3bf\", \"method\": \"addtoCart\" }, \"customerInfo\": { \"registerNumber\": 0, \"accountNumber\": \"0224065213-00001\", \"cartCreator\": \"2402169848\", \"processingMTN\": \"2402169848\" }, \"processMTNList\": [ { \"mtn\": \"2402169848\", \"completedprocessSteps\": [ \"MTNSelectionPage\", \"GridWallPDP\", \"ShoppingCart\" ] } ], \"validateOrder\": { \"orderDetails\": [ { \"systemId\": \"\", \"creditApplicationNum\": \"382938499\", \"orderStatus\": \"SUCCESS\", \"shipmentAddressValidated\": true, \"userId\": \"\", \"statusMsg\": \"\", \"creditApprovalStatus\": \"AP\", \"creditStatusReason\": \"CA CVAS AUTOMATIC APPROVAL\", \"securityDepositAmount\": \"0\", \"loveligibility\": false, \"statusCode\": \"\" } ], \"cartId\": \"cbf26bd7-035a-49a0-ba2c-e320bc46f3bf\", \"locationCode\": \"E247201\" } } } }, \"cartReadyForCheckout\": true }";
        
        ReviewOrderTYSUIResponse response = mapper.readValue(responseString, ReviewOrderTYSUIResponse.class);
        ReviewOrderTYSUIRequest request = mapper.readValue(requestString, ReviewOrderTYSUIRequest.class);
        
        URI url = URI.create("http://localhost/cart/tysOrderReview");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.empty());
        when(helper.reviewOrderTysValidation(Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartTYSValidationController.tysOrderReviewValidation(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }
	
	@Test
    public void tysOrderReviewValidationTest1() throws IOException {
        String requestString = "{ \"cartInfo\": {\"intendType\":\"TSE\", \"clientAppName\": \"VZW-NETACE\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"cartId\": \"cbf26bd7-035a-49a0-ba2c-e320bc46f3bf\", \"caseId\": \"SOP-20647-E01\", \"accountNumber\": \"0224065213-00001\", \"cartCreator\": \"2402169848\", \"processingMTN\": \"2402169848\", \"locationCode\": \"E319201\" } }";
        String responseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-NETACE\", \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \"SOP-20647-E01\", \"contextInfo\": { \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"OrderReview-Shipping-Payment-Agreement\", \"processAction\": \"\", \"availablePaths\": [ { \"path\": \"AvailablePaths\" } ] }, \"cartInfo\": { \"cartId\": \"cbf26bd7-035a-49a0-ba2c-e320bc46f3bf\", \"method\": \"addtoCart\" }, \"customerInfo\": { \"registerNumber\": 0, \"accountNumber\": \"0224065213-00001\", \"cartCreator\": \"2402169848\", \"processingMTN\": \"2402169848\" }, \"processMTNList\": [ { \"mtn\": \"2402169848\", \"completedprocessSteps\": [ \"MTNSelectionPage\", \"GridWallPDP\", \"ShoppingCart\" ] } ], \"validateOrder\": { \"orderDetails\": [ { \"systemId\": \"\", \"creditApplicationNum\": \"382938499\", \"orderStatus\": \"SUCCESS\", \"shipmentAddressValidated\": true, \"userId\": \"\", \"statusMsg\": \"\", \"creditApprovalStatus\": \"AP\", \"creditStatusReason\": \"CA CVAS AUTOMATIC APPROVAL\", \"securityDepositAmount\": \"0\", \"loveligibility\": false, \"statusCode\": \"\" } ], \"cartId\": \"cbf26bd7-035a-49a0-ba2c-e320bc46f3bf\", \"locationCode\": \"E247201\" } } } }, \"cartReadyForCheckout\": true }";
        ReviewOrderTYSUIResponse response = mapper.readValue(responseString, ReviewOrderTYSUIResponse.class);
        ReviewOrderTYSUIRequest request = mapper.readValue(requestString, ReviewOrderTYSUIRequest.class);
        URI url = URI.create("http://localhost/cart/tysOrderReview");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"userRole\":\"Account owner\",\"mtn\":\"8641146853\",\"cartCreator\":\"SOP-538499-E01\",\"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(helper.reviewOrderTysValidation(Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartTYSValidationController.tysOrderReviewValidation(httpHeader,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }
	
	@Test
    public void tysOrderReviewValidationTest2() throws IOException {
        String requestString = "{ \"cartInfo\": {\"intendType\":\"TSE\", \"clientAppName\": \"VZW-NETACE\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"cartId\": \"cbf26bd7-035a-49a0-ba2c-e320bc46f3bf\", \"caseId\": \"SOP-20647-E01\", \"accountNumber\": \"0224065213-00001\", \"cartCreator\": \"2402169848\", \"processingMTN\": \"2402169848\", \"locationCode\": \"E319201\" } }";
        String responseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-NETACE\", \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \"SOP-20647-E01\", \"contextInfo\": { \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"OrderReview-Shipping-Payment-Agreement\", \"processAction\": \"\", \"availablePaths\": [ { \"path\": \"AvailablePaths\" } ] }, \"cartInfo\": { \"cartId\": \"cbf26bd7-035a-49a0-ba2c-e320bc46f3bf\", \"method\": \"addtoCart\" }, \"customerInfo\": { \"registerNumber\": 0, \"accountNumber\": \"0224065213-00001\", \"cartCreator\": \"2402169848\", \"processingMTN\": \"2402169848\" }, \"processMTNList\": [ { \"mtn\": \"2402169848\", \"completedprocessSteps\": [ \"MTNSelectionPage\", \"GridWallPDP\", \"ShoppingCart\" ] } ], \"validateOrder\": { \"orderDetails\": [ { \"systemId\": \"\", \"creditApplicationNum\": \"382938499\", \"orderStatus\": \"SUCCESS\", \"shipmentAddressValidated\": true, \"userId\": \"\", \"statusMsg\": \"\", \"creditApprovalStatus\": \"AP\", \"creditStatusReason\": \"CA CVAS AUTOMATIC APPROVAL\", \"securityDepositAmount\": \"0\", \"loveligibility\": false, \"statusCode\": \"\" } ], \"cartId\": \"cbf26bd7-035a-49a0-ba2c-e320bc46f3bf\", \"locationCode\": \"E247201\" } } } }, \"cartReadyForCheckout\": true }";
        ReviewOrderTYSUIResponse response = mapper.readValue(responseString, ReviewOrderTYSUIResponse.class);
        ReviewOrderTYSUIRequest request = mapper.readValue(requestString, ReviewOrderTYSUIRequest.class);
        URI url = URI.create("http://localhost/cart/tysOrderReview");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        String redisDataString = "{ \"cartId\": \"\", \"userRole\":\"\",\"mtn\":\"\",\"cartCreator\":\"\",\"caseId\": \"\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(helper.reviewOrderTysValidation(Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartTYSValidationController.tysOrderReviewValidation(httpHeader,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }
	
	@Test
    public void tysOrderReviewValidationTest3() throws IOException {
        String requestString = "{ \"cartInfo\": {\"intendType\":\"NSE\", \"clientAppName\": \"VZW-NETACE\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"cartId\": \"cbf26bd7-035a-49a0-ba2c-e320bc46f3bf\", \"caseId\": \"SOP-20647-E01\", \"accountNumber\": \"0224065213-00001\", \"cartCreator\": \"2402169848\", \"processingMTN\": \"2402169848\", \"locationCode\": \"E319201\" } }";
        String responseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-NETACE\", \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \"SOP-20647-E01\", \"contextInfo\": { \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"OrderReview-Shipping-Payment-Agreement\", \"processAction\": \"\", \"availablePaths\": [ { \"path\": \"AvailablePaths\" } ] }, \"cartInfo\": { \"cartId\": \"cbf26bd7-035a-49a0-ba2c-e320bc46f3bf\", \"method\": \"addtoCart\" }, \"customerInfo\": { \"registerNumber\": 0, \"accountNumber\": \"0224065213-00001\", \"cartCreator\": \"2402169848\", \"processingMTN\": \"2402169848\" }, \"processMTNList\": [ { \"mtn\": \"2402169848\", \"completedprocessSteps\": [ \"MTNSelectionPage\", \"GridWallPDP\", \"ShoppingCart\" ] } ], \"validateOrder\": { \"orderDetails\": [ { \"systemId\": \"\", \"creditApplicationNum\": \"382938499\", \"orderStatus\": \"SUCCESS\", \"shipmentAddressValidated\": true, \"userId\": \"\", \"statusMsg\": \"\", \"creditApprovalStatus\": \"AP\", \"creditStatusReason\": \"CA CVAS AUTOMATIC APPROVAL\", \"securityDepositAmount\": \"0\", \"loveligibility\": false, \"statusCode\": \"\" } ], \"cartId\": \"cbf26bd7-035a-49a0-ba2c-e320bc46f3bf\", \"locationCode\": \"E247201\" } } } }, \"cartReadyForCheckout\": true }";
        ReviewOrderTYSUIResponse response = mapper.readValue(responseString, ReviewOrderTYSUIResponse.class);
        ReviewOrderTYSUIRequest request = mapper.readValue(requestString, ReviewOrderTYSUIRequest.class);
        URI url = URI.create("http://localhost/cart/tysOrderReview");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        String redisDataString = "{ \"cartId\": \"\", \"userRole\":\"\",\"mtn\":\"\",\"cartCreator\":\"\",\"caseId\": \"\", \"processingMTN\": \"1234567890\",  \"accountNumber\": \"\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(helper.reviewOrderTysValidation(Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartTYSValidationController.tysOrderReviewValidation(httpHeader,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }
	
	@Test
    public void tysOrderReviewValidationTest4() throws IOException {
        String requestString = "{ \"cartInfo\": {\"intendType\":null, \"clientAppName\": \"VZW-NETACE\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"cartId\": \"cbf26bd7-035a-49a0-ba2c-e320bc46f3bf\", \"caseId\": \"SOP-20647-E01\", \"accountNumber\": \"0224065213-00001\", \"cartCreator\": \"2402169848\", \"processingMTN\": \"2402169848\", \"locationCode\": \"E319201\" } }";
        String responseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-NETACE\", \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \"SOP-20647-E01\", \"contextInfo\": { \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"OrderReview-Shipping-Payment-Agreement\", \"processAction\": \"\", \"availablePaths\": [ { \"path\": \"AvailablePaths\" } ] }, \"cartInfo\": { \"cartId\": \"cbf26bd7-035a-49a0-ba2c-e320bc46f3bf\", \"method\": \"addtoCart\" }, \"customerInfo\": { \"registerNumber\": 0, \"accountNumber\": \"0224065213-00001\", \"cartCreator\": \"2402169848\", \"processingMTN\": \"2402169848\" }, \"processMTNList\": [ { \"mtn\": \"2402169848\", \"completedprocessSteps\": [ \"MTNSelectionPage\", \"GridWallPDP\", \"ShoppingCart\" ] } ], \"validateOrder\": { \"orderDetails\": [ { \"systemId\": \"\", \"creditApplicationNum\": \"382938499\", \"orderStatus\": \"SUCCESS\", \"shipmentAddressValidated\": true, \"userId\": \"\", \"statusMsg\": \"\", \"creditApprovalStatus\": \"AP\", \"creditStatusReason\": \"CA CVAS AUTOMATIC APPROVAL\", \"securityDepositAmount\": \"0\", \"loveligibility\": false, \"statusCode\": \"\" } ], \"cartId\": \"cbf26bd7-035a-49a0-ba2c-e320bc46f3bf\", \"locationCode\": \"E247201\" } } } }, \"cartReadyForCheckout\": true }";
        ReviewOrderTYSUIResponse response = mapper.readValue(responseString, ReviewOrderTYSUIResponse.class);
        ReviewOrderTYSUIRequest request = mapper.readValue(requestString, ReviewOrderTYSUIRequest.class);
        URI url = URI.create("http://localhost/cart/tysOrderReview");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        String redisDataString = "{ \"cartId\": \"\", \"userRole\":\"\",\"mtn\":\"\",\"cartCreator\":\"\",\"caseId\": \"\", \"processingMTN\": \"1234567890\", \"accountNumber\": \"\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(helper.reviewOrderTysValidation(Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartTYSValidationController.tysOrderReviewValidation(httpHeader,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }
	
	@Test
    public void tysOrderReviewValidationTest5() throws IOException {
        String requestString = "{ \"cartInfo\": {\"intendType\":\"TSE\", \"clientAppName\": \"VZW-NETACE\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"cartId\": \"cbf26bd7-035a-49a0-ba2c-e320bc46f3bf\", \"caseId\": \"SOP-20647-E01\", \"accountNumber\": \"0224065213-00001\", \"cartCreator\": \"2402169848\", \"processingMTN\": \"2402169848\", \"locationCode\": \"E319201\" } }";
        String responseString = "{\"errors\":[{\"namespace\":\"CartService\",\"details\":[{\"field\":\"cartId\",\"value\":\"null/blank\",\"issue\":\"cartId is/are missing.\",\"location\":\"request\"},{\"field\":\"caseId\",\"value\":\"null/blank\",\"issue\":\"caseId is/are missing.\",\"location\":\"request\"}],\"id\":\"701\",\"message\":\"This session has ended. Please reprocess to proceed\",\"name\":\" REQUEST VALIDATION ERROR\"}]}\n";
        ReviewOrderTYSUIResponse response = mapper.readValue(responseString, ReviewOrderTYSUIResponse.class);
        ReviewOrderTYSUIRequest request = mapper.readValue(requestString, ReviewOrderTYSUIRequest.class);
        URI url = URI.create("http://localhost/cart/tysOrderReview");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"userRole\":\"Account owner\",\"mtn\":\"8641146853\",\"cartCreator\":\"SOP-538499-E01\",\"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(helper.reviewOrderTysValidation(Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartTYSValidationController.tysOrderReviewValidation(httpHeader,httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

}
