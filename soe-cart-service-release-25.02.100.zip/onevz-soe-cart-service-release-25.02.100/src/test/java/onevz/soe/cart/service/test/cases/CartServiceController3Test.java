package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import junit.framework.Assert;
import onevz.cxp.feature.ConfigurationProfile;
import onevz.cxp.feature.Flag;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.controller.CartUpdateOperationsController;
import onevz.soe.cart.controller.CartUpdateOperationsController2;
import onevz.soe.cart.controller.CartUpdateOperationsController3;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.helper.*;
import onevz.soe.cart.model.retrieveCart.CXPRetrieveCartDataVO;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.CustomerProfileCXPResponse;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.responses.MyOfferETRRedisData;
import onevz.soe.cart.ui.common.DeviceCartInfo;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.AddDeviceUIRequest;
import onevz.soe.cart.ui.requests.AddPlanUIRequest;
import onevz.soe.cart.ui.requests.ClearCartUIRequest;
import onevz.soe.cart.ui.requests.CreateLineUIRequest;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.cart.util.CartAddDeviceUtil;
import onevz.soe.omnidl.util.DLUtilityService;
import onevz.soe.security.TokenProcessor;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.*;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.http.server.reactive.MockServerHttpResponse;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.net.URI;
import java.util.*;
import java.util.stream.Collectors;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@WebFluxTest(CartUpdateOperationsController.class)
public class CartServiceController3Test {

    @MockBean
    private UpdateCartHelper cartHelper;

    @Autowired
    private CartUpdateOperationsController cartController;

    @Autowired
    private CartUpdateOperationsController2 cartController2;

    @Autowired
    private CartUpdateOperationsController3 cartController3;

    @MockBean
    private CartServiceCxpHelper cartServiceCXPHelper;

    @Autowired
    private ObjectMapper mapper;

    @MockBean
    private RedisHelper redisHelper;
    @MockBean
    private OmniDLHelper omniDLHelper;
    @MockBean
    private FeatureFlagHelper featureFlagHelper;
    @MockBean
    private RedisHelper2 redisHelper2;

    @MockBean
    private RedisHelper3 redisHelper3;

    @MockBean
    private DLUtilityService dlUtilityService;

    @MockBean
    private TokenProcessor tokenProcessor;

    @MockBean
    private CartAddDeviceHelper devHelper;

    @MockBean
    private CartAccessoryHelper accHelper;

    @MockBean
    private TradeInHelper tradeInHelper;

    @Test
    public void getCookieValuesTestForAddDevice2() throws IOException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"AccountGrowth\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"mtnFlow\":\"G\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"AccountGrowth\",\"eupNoPromoFlow\":false,\"device\":{\"id\":\"MNDH3LL/A\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":true,\"dppMonths\":36,\"productId\":\"dev16720003\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":true}],\"rtm\":{\"url\":\"https://www.verizon.com/smartphones/apple-iphone-13-pro/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-green-2022?fmt=pjpg\",\"name\":\"iPhone 13 Pro\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://www.verizon.com/smartphones/apple-iphone-13-pro/\"}}}\t";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        URI url = URI.create("http://localhost/add-device");
        HttpCookie ecpdcookie = new HttpCookie("ecpdcookie", "cookie1:cookie2:cookie3:null");
        HttpCookie domainCookie = new HttpCookie("domainCookie", "domainCookie");
        HttpCookie RepIdCookieText = new HttpCookie("RepIdCookieText", "RepIdCookieText");
        HttpCookie AFFILIATE = new HttpCookie("AFFILIATE", "AFFILIATE");
        HttpCookie targetPricingOffer = new HttpCookie("targetPricingOffer", "true");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("targetPricingOffer", targetPricingOffer);
        bodyMap.add("ecpdcookie", ecpdcookie);
        bodyMap.add("domainCookie", domainCookie);
        bodyMap.add("RepIdCookieText", RepIdCookieText);
        bodyMap.add("AFFILIATE", AFFILIATE);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("channelId", "VZW-DOTCOM");
        httpHeaders.add("digital_ig_session", "digital_ig_session");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookies(bodyMap).headers(httpHeaders).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        cartController3.getCookieValues(httpHeader, null, request);
        assertNotNull(request.getCartInfo().getReferralSaleRepId());
    }

    @Test
    public void getCookieValuesTestForAddDevice3() throws IOException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"AccountGrowth\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"mtnFlow\":\"G\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"AccountGrowth\",\"eupNoPromoFlow\":false,\"device\":{\"id\":\"MNDH3LL/A\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":true,\"dppMonths\":36,\"productId\":\"dev16720003\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":true}],\"rtm\":{\"url\":\"https://www.verizon.com/smartphones/apple-iphone-13-pro/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-green-2022?fmt=pjpg\",\"name\":\"iPhone 13 Pro\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://www.verizon.com/smartphones/apple-iphone-13-pro/\"}}}\t";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        URI url = URI.create("http://localhost/add-device");
        HttpCookie ecpdcookie = new HttpCookie("ecpdcookie", "cookie1:cookie2:cookie3:");
        HttpCookie domainCookie = new HttpCookie("domainCookie", "domainCookie");
        HttpCookie RepIdCookieText = new HttpCookie("RepIdCookieText", "RepIdCookieText");
        HttpCookie AFFILIATE = new HttpCookie("AFFILIATE", "AFFILIATE");
        HttpCookie targetPricingOffer = new HttpCookie("targetPricingOffer", "true");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("targetPricingOffer", targetPricingOffer);
        bodyMap.add("ecpdcookie", ecpdcookie);
        bodyMap.add("domainCookie", domainCookie);
        bodyMap.add("RepIdCookieText", RepIdCookieText);
        bodyMap.add("AFFILIATE", AFFILIATE);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("channelId", "VZW-DOTCOM");
        httpHeaders.add("digital_ig_session", "digital_ig_session");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookies(bodyMap).headers(httpHeaders).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        cartController3.getCookieValues(httpHeader, null, request);
        assertNotNull(request.getCartInfo().getReferralSaleRepId());
    }

   /* @Test
    public void updateOfferDataIntoRedisTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"AccountGrowth\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"mtnFlow\":\"G\"},\"data\":{\"lines\":[{\"selectedOffers\":[{\"id\":\"001\",\"subType\":\"TRADE\",\"description\":\"trade-in\"}],\"mtn\":\"\",\"purchasePath\":\"AccountGrowth\",\"eupNoPromoFlow\":false,\"device\":{\"id\":\"MNDH3LL/A\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":true,\"dppMonths\":36,\"productId\":\"dev16720003\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":true}],\"rtm\":{\"url\":\"https://www.verizon.com/smartphones/apple-iphone-13-pro/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-green-2022?fmt=pjpg\",\"name\":\"iPhone 13 Pro\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://www.verizon.com/smartphones/apple-iphone-13-pro/\"}}}\t";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        URI url = URI.create("http://localhost/add-device");
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("channelId", "VZW-DOTCOM");
        httpHeaders.add("digital_ig_session", "digital_ig_session");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(httpHeaders).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        cartController3.updateOfferDataIntoRedis(request);
    } */

    @Test
    public void updateOfferDataIntoRedisTest1() throws IOException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"AccountGrowth\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"mtnFlow\":\"G\"},\"data\":{\"lines\":[{\"selectedOffers\":[],\"mtn\":\"\",\"purchasePath\":\"AccountGrowth\",\"eupNoPromoFlow\":false,\"device\":{\"id\":\"MNDH3LL/A\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":true,\"dppMonths\":36,\"productId\":\"dev16720003\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":true}],\"rtm\":{\"url\":\"https://www.verizon.com/smartphones/apple-iphone-13-pro/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-green-2022?fmt=pjpg\",\"name\":\"iPhone 13 Pro\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://www.verizon.com/smartphones/apple-iphone-13-pro/\"}}}\t";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        URI url = URI.create("http://localhost/addDeviceAndPlan");
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("channelId", "VZW-DOTCOM");
        httpHeaders.add("digital_ig_session", "digital_ig_session");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(httpHeaders).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        assertNotNull(cartController3.updateOfferDataIntoRedis(request));
    }

    @Test
    public void updateOfferDataIntoRedisTest2() throws IOException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"AccountGrowth\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"mtnFlow\":\"G\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"AccountGrowth\",\"eupNoPromoFlow\":false,\"device\":{\"id\":\"MNDH3LL/A\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":true,\"dppMonths\":36,\"productId\":\"dev16720003\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":true}],\"rtm\":{\"url\":\"https://www.verizon.com/smartphones/apple-iphone-13-pro/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-green-2022?fmt=pjpg\",\"name\":\"iPhone 13 Pro\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://www.verizon.com/smartphones/apple-iphone-13-pro/\"}}}\t";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        URI url = URI.create("http://localhost/addDeviceAndPlan");
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("channelId", "VZW-DOTCOM");
        httpHeaders.add("digital_ig_session", "digital_ig_session");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(httpHeaders).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        assertNotNull( cartController3.updateOfferDataIntoRedis(request));
    }

    @Test
    public void updateOfferDataIntoRedisTest3() throws IOException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"AccountGrowth\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"mtnFlow\":\"G\"},\"data\":{\"lines\":[],\"rtm\":{\"url\":\"https://www.verizon.com/smartphones/apple-iphone-13-pro/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-green-2022?fmt=pjpg\",\"name\":\"iPhone 13 Pro\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://www.verizon.com/smartphones/apple-iphone-13-pro/\"}}}\t";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        URI url = URI.create("http://localhost/addDeviceAndPlan");
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("channelId", "VZW-DOTCOM");
        httpHeaders.add("digital_ig_session", "digital_ig_session");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(httpHeaders).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        StepVerifier.create(cartController3.updateOfferDataIntoRedis(request)).assertNext(val -> assertTrue(val));
    }

    @Test
    public void updateOfferDataIntoRedisTest4() throws IOException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"AccountGrowth\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"mtnFlow\":\"G\"},\"data\":{\"rtm\":{\"url\":\"https://www.verizon.com/smartphones/apple-iphone-13-pro/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-green-2022?fmt=pjpg\",\"name\":\"iPhone 13 Pro\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://www.verizon.com/smartphones/apple-iphone-13-pro/\"}}}\t";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        URI url = URI.create("http://localhost/addDeviceAndPlan");
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("channelId", "VZW-DOTCOM");
        httpHeaders.add("digital_ig_session", "digital_ig_session");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(httpHeaders).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        StepVerifier.create(cartController3.updateOfferDataIntoRedis(request)).assertNext(val -> assertTrue(val));
    }

    @Test
    public void addDeviceWithPlanTest15() throws IOException {
        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("");
        line.setIsEdgeBuyOut(false);
        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);

        cartRedisData.setCartId("");
        cartRedisData.setCaseId("");
        cartRedisData.setLines(linesList);
        cartRedisData.setLocationCode("abcd1234");
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper2.getDeviceId()).thenReturn(Mono.just("1234"));
        when(redisHelper2.getSimId()).thenReturn(Mono.just("1234"));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        when(redisHelper2.updatePromoFirstOfferData(Mockito.any())).thenReturn(Mono.just(true));
        doNothing().when(dlUtilityService).updateDlData("eup");
        String requestString = "{ \"cartInfo\": { \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"processStep\": \"GridWallPDP\", \"processingMTN\": \"6205464780\", \"processAction\": \"addDevice\", \"intendType\": \"EUP\", \"number_share_capable\": \"Y\", \"creditAppNum\": null, \"isQuoteCart\": false, \"bogoEnabled\": \"True\", \"mtnFlow\" : \"PromoBundle\" }, \"data\": { \"lines\": [{ \"mtn\": \"6205464780\", \"lineDeviceDollar\": 0, \"upgradeReasonCode\": \"\", \"currentDeviceID\":\"359171071924399\", \"device\": { \"category\": \"Smartphones\", \"deviceId\": \"\", \"id\": \"SMG781VZBV\", \"contractTerm\": \"MONTH_TO_MONTH\", \"dppMonths\": \"\", \"isCustomerProvidedEquipment\": false }, \"sim\": { \"id\": \"EMBDSIM5G\", \"iccid\": \"\", \"isCustomerProvidedSIM\": false }, \"selectedOffers\": [], \"plan\": { \"id\": \"26907\", \"isRecommendedPlan\": false }, \"isKeepingExistingEqProtection\": \"\", \"ispuFlow\": false, \"newLineOrAAL\": false, \"isNewLine\": false, \"depletionLocationCode\": \"\", \"depletionType\": \"F\", \"sddZipCode\": \"\", \"preBackOrderDate\": \"\", \"triggerPricingValidation\": true }], \"selectedMtn\": \"\", \"totalDeviceDollar\": 0 } }";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/addDeviceAndPlan");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(cartHelper.customerProfileDigital(Mockito.anyString()))
                .thenReturn(Mono.just(new CustomerProfileCXPResponse()));
        //when(cartController3.updateOfferDataIntoRedis(request)).thenReturn(Mono.just(true));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDeviceAndPlan(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDeviceWithPlanTest16() throws IOException {
        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("");
        line.setIsEdgeBuyOut(false);
        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);

        cartRedisData.setCartId("");
        cartRedisData.setCaseId("");
        cartRedisData.setLines(linesList);
        cartRedisData.setLocationCode("abcd1234");
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper2.getDeviceId()).thenReturn(Mono.just("1234"));
        when(redisHelper2.getSimId()).thenReturn(Mono.just("1234"));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        when(redisHelper2.updatePromoFirstOfferData(Mockito.any())).thenReturn(Mono.just(true));
        doNothing().when(dlUtilityService).updateDlData("eup");
        String requestString = "{ \"cartInfo\": { \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"processStep\": \"GridWallPDP\", \"processingMTN\": \"6205464780\", \"processAction\": \"addDevice\", \"intendType\": \"EUP\", \"number_share_capable\": \"Y\", \"creditAppNum\": null, \"isQuoteCart\": false, \"bogoEnabled\": \"True\", \"mtnFlow\" : \"PromoBundle\" }, \"data\": { \"lines\": [{ \"mtn\": \"6205464780\", \"lineDeviceDollar\": 0, \"upgradeReasonCode\": \"\", \"currentDeviceID\":\"359171071924399\", \"device\": { \"category\": \"Smartphones\", \"deviceId\": \"\", \"id\": \"SMG781VZBV\", \"contractTerm\": \"MONTH_TO_MONTH\", \"dppMonths\": \"\", \"isCustomerProvidedEquipment\": false }, \"sim\": { \"id\": \"EMBDSIM5G\", \"iccid\": \"\", \"isCustomerProvidedSIM\": false },\"plan\": { \"id\": \"26907\", \"isRecommendedPlan\": false }, \"isKeepingExistingEqProtection\": \"\", \"ispuFlow\": false, \"newLineOrAAL\": false, \"isNewLine\": false, \"depletionLocationCode\": \"\", \"depletionType\": \"F\", \"sddZipCode\": \"\", \"preBackOrderDate\": \"\", \"triggerPricingValidation\": true }], \"selectedMtn\": \"\", \"totalDeviceDollar\": 0 } }";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/addDeviceAndPlan");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(cartHelper.customerProfileDigital(Mockito.anyString()))
                .thenReturn(Mono.just(new CustomerProfileCXPResponse()));
        //when(cartController3.updateOfferDataIntoRedis(request)).thenReturn(Mono.just(true));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDeviceAndPlan(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDeviceWithPlanTest17() throws IOException {
        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("");
        line.setIsEdgeBuyOut(false);
        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);

        cartRedisData.setCartId("");
        cartRedisData.setCaseId("");
        cartRedisData.setLines(linesList);
        cartRedisData.setLocationCode("abcd1234");
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper2.getDeviceId()).thenReturn(Mono.just("1234"));
        when(redisHelper2.getSimId()).thenReturn(Mono.just("1234"));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        when(redisHelper2.updatePromoFirstOfferData(Mockito.any())).thenReturn(Mono.just(true));
        doNothing().when(dlUtilityService).updateDlData("eup");
        String requestString = "{ \"cartInfo\": { \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"processStep\": \"GridWallPDP\", \"processingMTN\": \"6205464780\", \"processAction\": \"addDevice\", \"intendType\": \"EUP\", \"number_share_capable\": \"Y\", \"creditAppNum\": null, \"isQuoteCart\": false, \"bogoEnabled\": \"True\", \"mtnFlow\" : \"PromoBundle\" }, \"data\": { \"lines\": [], \"selectedMtn\": \"\", \"totalDeviceDollar\": 0 } }";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/addDeviceAndPlan");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(cartHelper.customerProfileDigital(Mockito.anyString()))
                .thenReturn(Mono.just(new CustomerProfileCXPResponse()));
        //when(cartController3.updateOfferDataIntoRedis(request)).thenReturn(Mono.just(true));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDeviceAndPlan(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDeviceWithPlanTest18() throws IOException {
        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("");
        line.setIsEdgeBuyOut(false);
        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);

        cartRedisData.setCartId("");
        cartRedisData.setCaseId("");
        cartRedisData.setLines(linesList);
        cartRedisData.setLocationCode("abcd1234");
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper2.getDeviceId()).thenReturn(Mono.just("1234"));
        when(redisHelper2.getSimId()).thenReturn(Mono.just("1234"));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        when(redisHelper2.updatePromoFirstOfferData(Mockito.any())).thenReturn(Mono.just(true));
        doNothing().when(dlUtilityService).updateDlData("eup");
        String requestString = "{ \"cartInfo\": { \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"processStep\": \"GridWallPDP\", \"processingMTN\": \"6205464780\", \"processAction\": \"addDevice\", \"intendType\": \"EUP\", \"number_share_capable\": \"Y\", \"creditAppNum\": null, \"isQuoteCart\": false, \"bogoEnabled\": \"True\", \"mtnFlow\" : \"PromoBundle\" }, \"data\": {\"selectedMtn\": \"\", \"totalDeviceDollar\": 0 } }";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/addDeviceAndPlan");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(cartHelper.customerProfileDigital(Mockito.anyString()))
                .thenReturn(Mono.just(new CustomerProfileCXPResponse()));
        //when(cartController3.updateOfferDataIntoRedis(request)).thenReturn(Mono.just(true));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDeviceAndPlan(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDeviceWithBuyoutIsPromoPDPTest() throws IOException {
        String requestString = "{ \"cartInfo\": { \"clientAppName\": \"VZW-DOTCOM\", \"cartId\": \"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\", \"caseId\": \"SOP-329-E01\", \"accountNumber\": \"0820215913-00001\", \"cartCreator\": \"6154839959\", \"processingMTN\": \"6154839959\", \"processStep\": \"MTNSelectionPage/ShoppingCart\", \"intendType\": \"EUP\", \"mtnFlow\":\"G\" }, \"data\": { \"lines\": [ { \"mtn\": \"2059376950\", \"isEdgeBuyOut\":true, \"edgeup\":{ \"deviceId\":\"353338070105553\" } } ] } }";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/addDeviceWithBuyout");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        sampleRedisData.setDeviceCartInfo(new DeviceCartInfo());
        sampleRedisData.getDeviceCartInfo().setIsPromoPDP(true);
        sampleRedisData.getDeviceCartInfo().setNoPendingOfferExists(false);
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController2,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.addDeviceWithBuyout(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDeviceWithBuyoutNoPendingOfferExistsTest() throws IOException {
        String requestString = "{ \"cartInfo\": { \"clientAppName\": \"VZW-DOTCOM\", \"cartId\": \"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\", \"caseId\": \"SOP-329-E01\", \"accountNumber\": \"0820215913-00001\", \"cartCreator\": \"6154839959\", \"processingMTN\": \"6154839959\", \"processStep\": \"MTNSelectionPage/ShoppingCart\", \"intendType\": \"EUP\", \"mtnFlow\":\"G\" }, \"data\": { \"lines\": [ { \"mtn\": \"2059376950\", \"isEdgeBuyOut\":true, \"edgeup\":{ \"deviceId\":\"353338070105553\" } } ] } }";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/addDeviceWithBuyout");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        sampleRedisData.setDeviceCartInfo(new DeviceCartInfo());
        sampleRedisData.getDeviceCartInfo().setIsPromoPDP(false);
        sampleRedisData.getDeviceCartInfo().setNoPendingOfferExists(true);
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController2,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.addDeviceWithBuyout(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDeviceWithBuyoutIsPromoPDP() throws IOException {
        String requestString = "{ \"cartInfo\": { \"clientAppName\": \"VZW-NETACE\", \"cartId\": \"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\", \"caseId\": \"SOP-329-E01\", \"accountNumber\": \"0820215913-00001\", \"cartCreator\": \"6154839959\", \"processingMTN\": \"6154839959\", \"processStep\": \"MTNSelectionPage/ShoppingCart\", \"intendType\": \"EUP\", \"mtnFlow\":\"G\" }, \"data\": { \"lines\": [ { \"mtn\": \"2059376950\", \"isEdgeBuyOut\":null, \"edgeup\":{ \"deviceId\":\"353338070105553\" } } ] } }";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        String redisDataString = "{\"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\",\"deviceCartInfo\":{\"numberShareCapable\":true,\"eNineAddrIndicator\":true} }";
        CartRedisData data=new CartRedisData();
        DeviceCartInfo data1 = new DeviceCartInfo();
        data1.setENineAddrIndicator("yes");
        data1.setNumberShareCapable("yes");
        data1.setIsPromoPDP(true);
        data1.setNoPendingOfferExists(false);
        data.setDeviceCartInfo(data1);
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/addDeviceWithBuyout");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(data));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController2,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.addDeviceWithBuyout(httpHeader,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addDeviceWithBuyoutNoPendingOfferExists() throws IOException {
        String requestString = "{ \"cartInfo\": { \"clientAppName\": \"VZW-NETACE\", \"cartId\": \"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\", \"caseId\": \"SOP-329-E01\", \"accountNumber\": \"0820215913-00001\", \"cartCreator\": \"6154839959\", \"processingMTN\": \"6154839959\", \"processStep\": \"MTNSelectionPage/ShoppingCart\", \"intendType\": \"EUP\", \"mtnFlow\":\"G\" }, \"data\": { \"lines\": [ { \"mtn\": \"2059376950\", \"isEdgeBuyOut\":null, \"edgeup\":{ \"deviceId\":\"353338070105553\" } } ] } }";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        String redisDataString = "{\"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\",\"deviceCartInfo\":{\"numberShareCapable\":true,\"eNineAddrIndicator\":true} }";
        CartRedisData data=new CartRedisData();
        DeviceCartInfo data1 = new DeviceCartInfo();
        data1.setENineAddrIndicator("yes");
        data1.setNumberShareCapable("yes");
        data1.setIsPromoPDP(false);
        data1.setNoPendingOfferExists(true);
        data.setDeviceCartInfo(data1);
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/addDeviceWithBuyout");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(data));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController2,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.addDeviceWithBuyout(httpHeader,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addPlanFeatureTest1() throws IOException {
        String requestString = "{\"cartInfo\":{\"cartCreator\":\"8163443332\",\"processingMTN\":\"8163443332\",\"processStep\":\"PlanSelection\",\"intendType\":\"AAL_5G\"},\"data\":{\"lines\":[{\"mtn\":\"2244715792\",\"plan\":{\"id\":\"50127\",\"isRecommendedPlan\":false,\"recommender\":\"\"}}],\"parentMtn\":\"\"}}";
        String responseString = "{\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-11569943-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"ShoppingCart\"}]},\"customerInfo\":{\"accountNumber\":\"0986616809-00001\",\"cartCreator\":\"8163443332\",\"processingMTN\":\"8163443332\",\"registerNumber\":0},\"cartInfo\":{\"tabletJetpackDiscountMultiLineLoss\":\"N\",\"cartItemCount\":0,\"subscriptionInfos\":[],\"spoGainReferenceDataList\":[{\"id\":\"2154\",\"name\":\"5G Home/LTE Home\",\"title\":\"Changes to home internet discount\",\"titleMobile\":\"Here's what will change with your home internet discount.\",\"shortDescription\":\"With your plan update, one or more of your lines will be eligible for up to 50% off your home internet service\",\"longDescription\":\"With your updated plan, each of the following lines will receive a discount for home internet services on your account:<br/><br/>##MDN##\"}],\"spoLossReferenceDataList\":[],\"cartId\":\"c2b88801-4221-415d-ab3d-77d921e5aa2f\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"plan\":{\"id\":\"50127\",\"price\":\"60.00\",\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"isFreeAppleMusicLoss\":\"N\",\"spos\":[{\"id\":\"983\",\"actionIndicator\":\"Z\",\"success\":true,\"description\":\"Verizon Multi-Device Additional Coverage\",\"is5GBolt\":false},{\"id\":\"983\",\"actionIndicator\":\"Z\",\"success\":true,\"description\":\"Verizon Multi-Device Additional Coverage\",\"is5GBolt\":false},{\"id\":\"1247\",\"actionIndicator\":\"Z\",\"success\":true,\"description\":\"Auto Pay / Paper-free Discount Included\",\"is5GBolt\":false},{\"id\":\"1747\",\"actionIndicator\":\"Z\",\"success\":true,\"description\":\"Disney Bundle Included with Plan\",\"is5GBolt\":false},{\"id\":\"2634\",\"actionIndicator\":\"A\",\"success\":true,\"description\":\"HOME 12 MO DISCOUNT\",\"is5GBolt\":false},{\"id\":\"732\",\"actionIndicator\":\"A\",\"success\":true,\"description\":\"CDMA-LESS ROAM TIER OVERRIDE\",\"is5GBolt\":false},{\"id\":\"1508\",\"actionIndicator\":\"A\",\"success\":true,\"description\":\"30 Day Free Setup Support\",\"is5GBolt\":false},{\"id\":\"1579\",\"actionIndicator\":\"A\",\"success\":true,\"description\":\"$10 Autopay and Paper-free Discount\",\"is5GBolt\":false},{\"id\":\"2154\",\"actionIndicator\":\"A\",\"success\":true,\"description\":\"Unlimited Plan Discount\",\"is5GBolt\":false},{\"id\":\"2161\",\"actionIndicator\":\"A\",\"success\":true,\"description\":\"Service ID Indicator 5G C-band\",\"is5GBolt\":false},{\"id\":\"2195\",\"actionIndicator\":\"A\",\"success\":true,\"description\":\"2 YEAR PRICE GUARANTEE\",\"is5GBolt\":false},{\"id\":\"2462\",\"actionIndicator\":\"A\",\"success\":true,\"description\":\"5G HOME 5G CORE\",\"is5GBolt\":false}],\"sfos\":[{\"id\":\"48526\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"Text Messaging Pay Per Message\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"48553\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"Streamlined Billing\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"54307\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"Block Messaging\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"68872\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"CALL DELIVERY\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"70421\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"Block Voice Calls - Hotline\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"78003\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"4G BLOCK DATA ROAM (M)\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"83856\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"CDMA-LESS DEVICE PROVISIONING\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"85503\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"Unlimited Data\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"86112\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"5G IPv4/IPv6 IP\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"86926\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"5G LINE OF SERVICE\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"86928\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"5G DATA TRANSPORT\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"87800\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"LTE PROVISIONING\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"88685\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"RTR PROVISIONING\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"88855\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"HSS PROVISIONING\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"88966\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"5G INTERNET ACCESS\",\"price\":\"0.00\",\"displayHumWiFi\":false},{\"id\":\"89405\",\"actionIndicator\":\"A\",\"customerAddedInd\":\"N\",\"description\":\"5G CORE TRIGGER\",\"price\":\"0.00\",\"displayHumWiFi\":false}],\"pairingInfo\":{},\"tabletJetpackDiscountLoss\":\"N\",\"tabletJetpackDiscountGain\":\"N\",\"reasonCode\":\"PLAN_DEVICE_NOT_COMPATIBLE\",\"eupNoPromoFlow\":false,\"featureMessages\":[{\"name\":\"5GCOREPROV\",\"action\":\"ADD\"}],\"mtn\":\"2244715792\",\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"currentPlanType\":\"LLP\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"disqualifiedPropositions\":[],\"qualifiedPropositions\":[],\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false},{\"pairingInfo\":{\"newPairedPhone\":\"8163443332\",\"currentPairedPhone\":\"8163443332\",\"benefitPairType\":\"ACD\"},\"eupNoPromoFlow\":false,\"mtn\":\"8163417967\",\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"isOnDemandAllowed\":true,\"isBackDateAllowed\":false,\"isFutureDateAllowed\":false,\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"01/24/2023\",\"nextBillCycleBeginDate\":\"02/24/2023\",\"onDemandDate\":\"02/20/2023\",\"onDemandRangeInDays\":\"45\"},\"autoPayEnrollmentDetails\":{\"isAutoPayEnrolled\":\"Y\",\"isPaperLessEnrolled\":\"Y\",\"isAutoPayPaperLessDiscountEligible\":\"N\"},\"planChangeWarningMessages\":[{\"warningMessage\":\"\"}],\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"discountLossIndicators\":[],\"fmiCheck\":false},\"processMTNList\":[{\"mtn\":\"8163443332\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"InterimPage\",\"MTNSelectionPage\",\"GridWallPDP\",\"PlanSelection\",\"PlanSelection\",\"PlanSelection\",\"PlanSelection\",\"PlanSelection\",\"FeaturesPDP\",\"PlanSelection\",\"FeaturesPDP\",\"PlanSelection\",\"FeaturesPDP\",\"PlanSelection\",\"PlanSelection\",\"FeaturesPDP\",\"PlanSelection\"]}]}}},\"serviceHeader\":{\"clientId\":\"OMNI-RETAIL\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.20.20.45.27-775.2106527569788\"}}";
        AddPlanUIRequest request = mapper.readValue(requestString, AddPlanUIRequest.class);
        AddPlanUIResponse response = mapper.readValue(responseString, AddPlanUIResponse.class);
        URI url = URI.create("http://localhost/flexV2/add-plan");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookie(new HttpCookie("digital_ig_session", "digital_1")).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.addPlan(any())).thenReturn(Mono.just(response));
        when(redisHelper2.updateCartOrderFlowType("cpc")).thenReturn(Mono.just(true));
        when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just("eup"));
        when(redisHelper.updateSPOsIntoRedis(any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper2.getPlanPathDetails()).thenReturn(Mono.just(new HashMap()));
        String featureResponseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-RETAIL\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.21.14.34.41-277.0007659420799\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-11010914-C01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"FeaturesPDP\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"FeaturesPDP\"}]},\"customerInfo\":{\"accountNumber\":\"0986616809-00001\",\"cartCreator\":\"8163443332\",\"processingMTN\":\"8163443332\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"2125a342-773d-49ed-bc99-4ce42ef3ac80\",\"lines\":[{\"status\":1,\"spos\":[{\"id\":\"2634\",\"conflictId\":\"\"},{\"id\":\"732\",\"conflictId\":\"\"},{\"id\":\"1508\",\"conflictId\":\"\"},{\"id\":\"1579\",\"conflictId\":\"\"},{\"id\":\"2154\",\"conflictId\":\"\"},{\"id\":\"2161\",\"conflictId\":\"\"},{\"id\":\"2195\",\"conflictId\":\"\"},{\"id\":\"2462\",\"conflictId\":\"\"}],\"sfos\":[{\"id\":\"48526\",\"conflictId\":\"\"},{\"id\":\"48553\",\"conflictId\":\"\"},{\"id\":\"54307\",\"conflictId\":\"\"},{\"id\":\"68872\",\"conflictId\":\"\"},{\"id\":\"70421\",\"conflictId\":\"\"},{\"id\":\"78003\",\"conflictId\":\"\"},{\"id\":\"83856\",\"conflictId\":\"\"},{\"id\":\"85503\",\"conflictId\":\"\"},{\"id\":\"86112\",\"conflictId\":\"\"},{\"id\":\"86926\",\"conflictId\":\"\"},{\"id\":\"86928\",\"conflictId\":\"\"},{\"id\":\"87800\",\"conflictId\":\"\"},{\"id\":\"88685\",\"conflictId\":\"\"},{\"id\":\"88855\",\"conflictId\":\"\"},{\"id\":\"88966\",\"conflictId\":\"\"},{\"id\":\"89405\",\"conflictId\":\"\"}],\"eupNoPromoFlow\":false,\"mtn\":\"2244715792\",\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"AAL_5G\",\"currentPlanType\":\"LLP\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":true,\"isPlanChangeRequiredOnMultiLines\":false,\"protectionNotRequired\":false,\"fmiCheck\":false},\"processMTNList\":[{\"mtn\":\"8163443332\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"InterimPage\",\"MTNSelectionPage\",\"GridWallPDP\",\"PlanSelection\",\"FeaturesPDP\",\"FeaturesPDP\",\"PlanSelection\",\"FeaturesPDP\"]}]}}},\"warnings\":[]}";
        String redisOfferString = "{\"lines\":[{\"mtn\":\"NewLine1\",\"offers\":[{\"complianceType\":\"SPO\",\"sku\":\"2634\",\"description\":\"Free LTE Home for 12 mos for Prem UNL\",\"compatibleIndicator\":\"Y\",\"barcodeId\":\"\",\"requiresInd\":\"\",\"propId\":\"PR_3741\",\"tradeInOffer\":\"\",\"aal\":\"Y\",\"mmtier\":\"\",\"reasonCode\":\"\",\"complianceInd\":\"Y\",\"rewardType\":\"\",\"offerCompliance\":\"Y\",\"propositionMessage\":\"Value: For a limited time only with your current mobile plan, you can get 12 months of LTE Home Internet for free! As a loyal customer, you can enjoy all the benefits of LTE Home on us for a whole year including: - Fast and reliable wireless home internet - No equipment charges - the router with a receiver is included in your plan - No annual contracts or hidden fees - One combined mobile and home bill\",\"url\":[]}]}],\"offerSourceSystem\":\"OC_PERSONALIZED\"}";
        MyOfferETRRedisData redisOffer = mapper.readValue(redisOfferString, MyOfferETRRedisData.class);
        AddFeaturesUIResponse featureResponse = mapper.readValue(featureResponseString, AddFeaturesUIResponse.class);
        when(cartHelper.addFeatures(any())).thenReturn(Mono.just(featureResponse));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(redisOffer));
        when(cartHelper.populateSPOsFor5GBolt(any(), any())).thenReturn(Mono.just(ResponseEntity.status(200).body(featureResponse)));
        when(cartHelper.populateHumWifiConflictedSFos(any(), any())).thenReturn(Mono.just(ResponseEntity.status(200).body(featureResponse)));
        when(cartHelper.populateProtectionVersion(any(), any())).thenReturn(Mono.just(ResponseEntity.status(200).body(featureResponse)));
        when(cartHelper.updateFlowNameForAssisted(any(), any())).thenReturn(Mono.just(ResponseEntity.status(200).body(featureResponse)));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addPlan(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addDeviceNSESHubProspectCartFalseTest() throws IOException {
        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("");
        line.setIsEdgeBuyOut(false);
        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);
        cartRedisData.setCartId("");
        cartRedisData.setCaseId("");
        cartRedisData.setLines(linesList);
        cartRedisData.setLocationCode("abcd1234");
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper2.getDeviceId()).thenReturn(Mono.just("1234"));
        when(redisHelper2.getSimId()).thenReturn(Mono.just("1234"));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"30004\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"MWGF2LL/A\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":36,\"productId\":\"dev12400034\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}],\"rtm\":{\"url\":\"https://vzwqa3.verizonwireless.com/smartphones/apple-iphone-11-pro-max/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/iphone-11-pro-max-space-gray?fmt=pjpg\",\"name\":\"iPhone 11 Pro Max\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://vzwqa3.verizonwireless.com/smartphones/apple-iphone-11-pro-max/\"}}}";
        String responseString = "{\"serviceHeader\": {\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\" },\"serviceBody\": {\"serviceResponse\": {\"context\": {\"Cases\": [],\"caseId\":\"SOP-329-E01\",\"contextInfo\": {\"pendingOrderAccountLevel\":\"\",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"Dummy\",\"processAction\":\"\"},\"customerInfo\": {\"lookupMTN\":\"\",\"accountNumber\":\"0820215913-00001\"}}} } }";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/cart/nse/add-device");
        HttpCookie targetPricingOffer = new HttpCookie("targetPricingOffer", "true");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("targetPricingOffer", targetPricingOffer);
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-DOTCOM").cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(cartHelper.customerProfileDigital(Mockito.anyString()))
                .thenReturn(Mono.just(new CustomerProfileCXPResponse()));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDeviceNSESHubV2HubProspectCartCookieTest() throws IOException {
        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("");
        line.setIsEdgeBuyOut(false);
        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);
        cartRedisData.setCartId("");
        cartRedisData.setCaseId("");
        cartRedisData.setLines(linesList);
        cartRedisData.setLocationCode("abcd1234");
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper2.getDeviceId()).thenReturn(Mono.just("1234"));
        when(redisHelper2.getSimId()).thenReturn(Mono.just("1234"));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"30004\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"MWGF2LL/A\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":36,\"productId\":\"dev12400034\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}],\"rtm\":{\"url\":\"https://vzwqa3.verizonwireless.com/smartphones/apple-iphone-11-pro-max/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/iphone-11-pro-max-space-gray?fmt=pjpg\",\"name\":\"iPhone 11 Pro Max\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://vzwqa3.verizonwireless.com/smartphones/apple-iphone-11-pro-max/\"}}}";
        String responseString = "{ \"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\" }, \"serviceBody\": {\"serviceResponse\": {\"context\": {\"Cases\": [],\"caseId\": \"SOP-329-E01\",\"contextInfo\": {\"availablePaths\": [{\"path\": \"NewRecommendedPlanSelection\"}],\"pendingOrderAccountLevel\": \"\",\"callReason\": \"SalesOrderPurchase\",\"processStep\": \"NewRecommendedPlanSelection\",\"processAction\": \"\",\"cradleFlowJourney\":\"SHubV2\"},\"customerInfo\": {\"lookupMTN\": \"\",\"accountNumber\": \"0820215913-00001\"}}} } }";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/cart/nse/add-device");
        HttpCookie targetPricingOffer = new HttpCookie("targetPricingOffer", "true");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("targetPricingOffer", targetPricingOffer);
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-DOTCOM").cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(cartHelper.customerProfileDigital(Mockito.anyString()))
                .thenReturn(Mono.just(new CustomerProfileCXPResponse()));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }
    @Test
    public void addDeviceEXISTINGCart1Test() throws IOException {
        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("");
        line.setIsEdgeBuyOut(false);
        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);
        cartRedisData.setCartId("");
        cartRedisData.setCaseId("");
        cartRedisData.setLines(linesList);
        cartRedisData.setLocationCode("abcd1234");
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper2.getDeviceId()).thenReturn(Mono.just("1234"));
        when(redisHelper2.getSimId()).thenReturn(Mono.just("1234"));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"AAL\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"30004\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"AAL\",\"device\":{\"id\":\"MWGF2LL/A\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":36,\"productId\":\"dev12400034\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}],\"rtm\":{\"url\":\"https://vzwqa3.verizonwireless.com/smartphones/apple-iphone-11-pro-max/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/iphone-11-pro-max-space-gray?fmt=pjpg\",\"name\":\"iPhone 11 Pro Max\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://vzwqa3.verizonwireless.com/smartphones/apple-iphone-11-pro-max/\"}}}";
        String responseString = "{ \"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\" }, \"serviceBody\": {\"serviceResponse\": {\"context\": {\"Cases\": [],\"caseId\": \"SOP-329-E01\",\"contextInfo\": {\"availablePaths\": [{\"path\": \"NewRecommendedPlanSelection\"}],\"pendingOrderAccountLevel\": \"\",\"callReason\": \"SalesOrderPurchase\",\"processStep\": \"NewRecommendedPlanSelection\",\"processAction\": \"\",\"cradleFlowJourney\":\"SHubV2\"},\"customerInfo\": {\"lookupMTN\": \"\",\"accountNumber\": \"0820215913-00001\"}}} } }";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/cart/add-device");
        HttpCookie targetPricingOffer = new HttpCookie("targetPricingOffer", "true");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("targetPricingOffer", targetPricingOffer);
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-DOTCOM").cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(cartHelper.customerProfileDigital(Mockito.anyString()))
                .thenReturn(Mono.just(new CustomerProfileCXPResponse()));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDeviceWithBuyoutTest1() throws IOException {
        String requestString = "{ \"cartInfo\": { \"clientAppName\": \"VZW-NETACE\", \"cartId\": \"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\", \"caseId\": \"SOP-329-E01\", \"accountNumber\": \"0820215913-00001\", \"cartCreator\": \"6154839959\", \"processingMTN\": \"6154839959\", \"processStep\": \"MTNSelectionPage/ShoppingCart\", \"intendType\": \"EUP\", \"mtnFlow\":\"H\" }, \"data\": { \"lines\": [ { \"mtn\": \"2059376950\", \"isEdgeBuyOut\":true, \"edgeup\":{ \"deviceId\":\"353338070105553\" } } ] } }";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/addDeviceWithBuyout");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController2,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.addDeviceWithBuyout(httpHeader,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addDeviceWithBuyoutTest2() throws IOException {
        String requestString = "{ \"cartInfo\": { \"clientAppName\": \"VZW-NETACE\", \"cartId\": \"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\", \"caseId\": \"SOP-329-E01\", \"accountNumber\": \"0820215913-00001\", \"cartCreator\": \"6154839959\", \"processingMTN\": \"6154839959\", \"processStep\": \"MTNSelectionPage/ShoppingCart\", \"intendType\": \"EUP\", \"mtnFlow\":\"G\" }, \"data\": { \"lines\": [ { \"mtn\": \"2059376950\", \"isEdgeBuyOut\":null, \"edgeup\":{ \"deviceId\":\"353338070105553\" } } ] } }";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\",\"deviceCartInfo\":{\"numberShareCapable\":true,\"eNineAddrIndicator\":true} }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/addDeviceWithBuyout");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController2,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.addDeviceWithBuyout(httpHeader,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addDeviceWithBuyoutTest3() throws IOException {
        String requestString = "{ \"cartInfo\": { \"clientAppName\": \"VZW-NETACE\", \"cartId\": \"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\", \"caseId\": \"SOP-329-E01\", \"accountNumber\": \"0820215913-00001\", \"cartCreator\": \"6154839959\", \"processingMTN\": \"6154839959\", \"processStep\": \"MTNSelectionPage/ShoppingCart\", \"intendType\": \"EUP\", \"mtnFlow\":null }, \"data\": { \"lines\": [ { \"mtn\": \"2059376950\", \"isEdgeBuyOut\":null, \"edgeup\":{ \"deviceId\":\"353338070105553\" } } ] } }";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        String redisDataString = "{\"deviceCartInfo\":{\"numberShareCapable\":\"yes\",\"eNineAddrIndicator\":\"yes\"}, \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\",\"deviceCartInfo\":{\"numberShareCapable\":true,\"eNineAddrIndicator\":true} }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/addDeviceWithBuyout");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController2,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.addDeviceWithBuyout(httpHeader,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void getCookieValuesTestForCreateLine3() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"lines\":[{\"mtn\":\"3025451823\"}]}}";
        CreateLineUIRequest request = mapper.readValue(requestString, CreateLineUIRequest.class);
        URI url = URI.create("http://localhost/new-line");
        HttpCookie ecpdcookie = new HttpCookie("ecpdcookie", "cookie1:cookie2:cookie3:null");
        HttpCookie domainCookie = new HttpCookie("domainCookie", "domainCookie");
        HttpCookie RepIdCookieText = new HttpCookie("RepIdCookieText", "RepIdCookieText");
        HttpCookie AFFILIATE = new HttpCookie("AFFILIATE", "AFFILIATE");
        HttpCookie targetPricingOffer = new HttpCookie("targetPricingOffer", "false");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("targetPricingOffer", targetPricingOffer);
        bodyMap.add("ecpdcookie", ecpdcookie);
        bodyMap.add("domainCookie", domainCookie);
        bodyMap.add("RepIdCookieText", RepIdCookieText);
        bodyMap.add("AFFILIATE", AFFILIATE);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("channelId", "VZW-DOTCOM");
        httpHeaders.add("digital_ig_session", "digital_ig_session");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookies(bodyMap).headers(httpHeaders).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        httpResponse.addCookie(ResponseCookie.from("cdlCartInfo","cdlCartInfo").build());
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandon").build());

        cartController3.getCookieValues(httpHeader, request, null);
        assertNotNull( request.getCartInfo().getEcpdProfileId());
    }

    @Test
    public void getCookieValuesTestForCreateLine4() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"lines\":[{\"mtn\":\"3025451823\"}]}}";
        CreateLineUIRequest request = mapper.readValue(requestString, CreateLineUIRequest.class);
        URI url = URI.create("http://localhost/new-line");
        HttpCookie ecpdcookie = new HttpCookie("ecpdcookie", "cookie1");
        HttpCookie domainCookie = new HttpCookie("domainCookie", "domainCookie");
        HttpCookie RepIdCookieText = new HttpCookie("RepIdCookieText", "RepIdCookieText");
        HttpCookie AFFILIATE = new HttpCookie("AFFILIATE", "AFFILIATE");
        HttpCookie targetPricingOffer = new HttpCookie("targetPricingOffer", "false");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("targetPricingOffer", targetPricingOffer);
        bodyMap.add("ecpdcookie", ecpdcookie);
        bodyMap.add("domainCookie", domainCookie);
        bodyMap.add("RepIdCookieText", RepIdCookieText);
        bodyMap.add("AFFILIATE", AFFILIATE);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("channelId", "VZW-DOTCOM");
        httpHeaders.add("digital_ig_session", "digital_ig_session");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookies(bodyMap).headers(httpHeaders).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        httpResponse.addCookie(ResponseCookie.from("cdlCartInfo","cdlCartInfo").build());
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandon").build());

        cartController3.getCookieValues(httpHeader, request, null);
        assertNotNull( request.getCartInfo().getEcpdToken());
    }

    @Test
    public void getCookieValuesTestForCreateLine5() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"lines\":[{\"mtn\":\"3025451823\"}]}}";
        CreateLineUIRequest request = mapper.readValue(requestString, CreateLineUIRequest.class);
        URI url = URI.create("http://localhost/new-line");

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("channelId", "VZW-DOTCOM");
        httpHeaders.add("digital_ig_session", "digital_ig_session");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(httpHeaders).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        httpResponse.addCookie(ResponseCookie.from("cdlCartInfo","cdlCartInfo").build());
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandon").build());

        cartController3.getCookieValues(httpHeader, request, null);
        assertNotNull( request.getCartInfo().getReferralVendorId());
    }

    @Test
    public void createLineTestTwo() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"intendType\":\"NSE\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"lines\":[{\"mtn\":\"3025451823\"}]}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-543157-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"showDevices\"},{\"path\":\"showAccessory\"},{\"path\":\"TradeIn\"},{\"path\":\"showFeatures\"},{\"path\":\"addDevice\"}]},\"customerInfo\":{\"registerNumber\":0,\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"cartInfo\":{\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\"},\"processMTNList\":[{\"mtn\":\"4235344191\",\"completedprocessSteps\":[\"\"]}]}}}}";
        CreateLineUIRequest request = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLineUIResponse response = mapper.readValue(responseString, CreateLineUIResponse.class);
        URI url = URI.create("http://localhost/new-line");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(cartHelper.createLine(any())).thenReturn(Mono.just(response));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.createLine(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
        request.getCartInfo().setIntendType("NSEBYOD");
        controllerResponse = cartController3.createLine(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
        MockServerHttpRequest httpHeader1 = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","OMNI-RETAIL").build();

        controllerResponse = cartController3.createLine(httpHeader1, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }


    @Test
    public void getCookieValuesTestForAddDevice1() throws IOException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"AccountGrowth\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"mtnFlow\":\"G\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"AccountGrowth\",\"eupNoPromoFlow\":false,\"device\":{\"id\":\"MNDH3LL/A\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":true,\"dppMonths\":36,\"productId\":\"dev16720003\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":true}],\"rtm\":{\"url\":\"https://www.verizon.com/smartphones/apple-iphone-13-pro/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-green-2022?fmt=pjpg\",\"name\":\"iPhone 13 Pro\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://www.verizon.com/smartphones/apple-iphone-13-pro/\"}}}\t";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        URI url = URI.create("http://localhost/add-device");
        HttpCookie ecpdcookie = new HttpCookie("ecpdcookie", "cookie1:cookie2:cookie3:cookie4");
        HttpCookie domainCookie = new HttpCookie("domainCookie", "domainCookie");
        HttpCookie RepIdCookieText = new HttpCookie("RepIdCookieText", "RepIdCookieText");
        HttpCookie AFFILIATE = new HttpCookie("AFFILIATE", "AFFILIATE");
        HttpCookie targetPricingOffer = new HttpCookie("targetPricingOffer", "true");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("targetPricingOffer", targetPricingOffer);
        bodyMap.add("ecpdcookie", ecpdcookie);
        bodyMap.add("domainCookie", domainCookie);
        bodyMap.add("RepIdCookieText", RepIdCookieText);
        bodyMap.add("AFFILIATE", AFFILIATE);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("channelId", "VZW-DOTCOM");
        httpHeaders.add("digital_ig_session", "digital_ig_session");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookies(bodyMap).headers(httpHeaders).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        cartController3.getCookieValues(httpHeader, null, request);
    }

    @Test
    public void addPlanTest() throws IOException {
        String requestString = "{\"channelId\":\"OMNI-RETAIL\",\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"4aa9765a-917b-4804-bcf5-75f7c2d49620\",\"caseId\":\"SOP-607536-E01\",\"accountNumber\":\"0825637535-00001\",\"cartCreator\":\"9106517716\",\"processingMTN\":\"9106517716\",\"processStep\":\"PlanSelection\",\"intendType\":\"CPC\"},\"data\":{\"lines\":[{\"mtn\":\"9106359416\",\"plan\":{\"id\":\"18045\"}}]}}";
        String responseString ="{\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \"SOP-334914702-W01\",\"contextInfo\": {\"callReason\": \"SalesOrderPurchase\",\"processStep\": \"ShoppingCart\",\"processAction\": \"\",\"availablePaths\": [{\"path\": \"ShoppingCart\"}]},\"customerInfo\": {\"accountNumber\": \"0789166749-00001\",\"cartCreator\": \"8125825035\",\"processingMTN\": \"8125825035\",\"registerNumber\": 0},\"cartInfo\": {\"tabletJetpackDiscountMultiLineLoss\": \"N\",\"cartItemCount\": 0,\"cartId\": \"ff70cbb7-096d-4580-8f9c-8206250ab95a\",\"statusMsg\": \"Success\",\"statusCode\": \"1\",\"lines\": [{\"plan\": {\"id\": \"39385\",\"price\": \"80.00\",\"isRecommendedPlan\": false},\"status\": 1,\"isFreeAppleMusicLoss\": \"N\",\"spos\": [{\"id\": \"671\",\"actionIndicator\": \"D\",\"success\": true,\"description\": \"Carryover Data\",\"is5GBolt\": false},{\"id\": \"672\",\"actionIndicator\": \"D\",\"success\": true,\"description\": \"Safety Mode\",\"is5GBolt\": false},{\"id\": \"975\",\"actionIndicator\": \"D\",\"success\": true,\"description\": \"AutoPay and Paper-Free Discount\",\"is5GBolt\": false},{\"id\": \"1708\",\"actionIndicator\": \"Z\",\"success\": true,\"description\": \"COVID IMPACTED INDICATOR\",\"is5GBolt\": false},{\"id\": \"1247\",\"actionIndicator\": \"A\",\"success\": true,\"description\": \"Auto Pay / Paper-free Discount Included\",\"is5GBolt\": false},{\"id\": \"1678\",\"actionIndicator\": \"A\",\"success\": true,\"description\": \"$10 Teachers Discount\",\"is5GBolt\": false},{\"id\": \"1747\",\"actionIndicator\": \"A\",\"success\": true,\"description\": \"Disney Bundle Included with Plan\",\"is5GBolt\": false},{\"id\": \"1802\",\"actionIndicator\": \"D\",\"success\": true,\"description\": \"Metered Plan Indicator\",\"is5GBolt\": false},{\"id\": \"1692\",\"actionIndicator\": \"Z\",\"success\": true,\"description\": \"5G Dynamic Spectrum Sharing\",\"is5GBolt\": false},{\"id\": \"732\",\"actionIndicator\": \"A\",\"success\": true,\"description\": \"CDMA-LESS ROAM TIER OVERRIDE\",\"is5GBolt\": false},{\"id\": \"1256\",\"actionIndicator\": \"A\",\"success\": true,\"description\": \"Includes Mexico & Canada with your domestic plan\",\"is5GBolt\": false},{\"id\": \"1552\",\"actionIndicator\": \"A\",\"success\": true,\"description\": \"5G Ultra Wideband Access\",\"is5GBolt\": false},{\"id\": \"1578\",\"actionIndicator\": \"A\",\"success\": true,\"description\": \"5G Ultra Wideband Trigger\",\"is5GBolt\": false},{\"id\": \"1741\",\"actionIndicator\": \"A\",\"success\": true,\"description\": \"5G Ultra Wideband Provisioning\",\"is5GBolt\": false},{\"id\": \"1801\",\"actionIndicator\": \"A\",\"success\": true,\"description\": \"Unlimited Plan Indicator\",\"is5GBolt\": false},{\"id\": \"1958\",\"actionIndicator\": \"A\",\"success\": true,\"description\": \"Device Set-Up Support 60 Days\",\"is5GBolt\": false}],\"sfos\": [{\"id\": \"48526\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Text Messaging Pay Per Message\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"48553\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Streamlined Billing\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"66332\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"Y\",\"description\": \"Decline Device Protection\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"68869\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Caller ID\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"68870\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"BUSY TRANSFER\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"68871\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Conference Calling\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"68872\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"CALL DELIVERY\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"68873\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Call Waiting\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"68874\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"No Answer / Busy Transfer\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"68876\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Call Forwarding\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"73502\",\"actionIndicator\": \"A\",\"customerAddedInd\": \"N\",\"description\": \"Unlimited Picture and Video Messaging\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"73503\",\"actionIndicator\": \"A\",\"customerAddedInd\": \"N\",\"description\": \"Unlimited Text Messages\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"74774\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"SDM REMOTE QUERY ENABLED\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"75440\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Block Web Purchases\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"75632\",\"actionIndicator\": \"D\",\"customerAddedInd\": \"N\",\"description\": \"Data Usage USA & Canada\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"75706\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Pay Per Message\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"75802\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Dynamic-Private IP\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"75836\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"4G INTERNET ACCESS\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"75837\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"4G APPLICATION ACCESS\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"76152\",\"actionIndicator\": \"D\",\"customerAddedInd\": \"N\",\"description\": \"PICTURE MESSAGE PROVISIONING\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"76404\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"4G Mobile Hotspot Provisioning\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"76600\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"SHARE NAME ID\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"77249\",\"actionIndicator\": \"D\",\"customerAddedInd\": \"N\",\"description\": \"MOBILE HOT SPOT TRIGGER $0\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"77556\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"4G PROVISIONING $0\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"77568\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"EMAIL ACCESS PDA $0\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"77581\",\"actionIndicator\": \"D\",\"customerAddedInd\": \"N\",\"description\": \"EMAIL TRIGGER ALP $0\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"77583\",\"actionIndicator\": \"D\",\"customerAddedInd\": \"N\",\"description\": \"DATA PROVISION ALP\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"77885\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Integrated Messaging\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"78706\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"ENHANCED ADDRESS BOOK\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"78707\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Video Calling\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"78734\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Premium Visual Voice Mail with Voice Mail to Text\",\"price\": \"2.99\",\"displayHumWiFi\": false},{\"id\": \"80148\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"International Messages While in US\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"81158\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"HD Voice\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"82417\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Integrated Calling\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"82419\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Access Wi-fi Calling\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"83439\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Call Filter Plus\",\"price\": \"2.99\",\"displayHumWiFi\": false},{\"id\": \"83856\",\"actionIndicator\": \"A\",\"customerAddedInd\": \"N\",\"description\": \"CDMA-LESS DEVICE PROVISIONING\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"84015\",\"actionIndicator\": \"D\",\"customerAddedInd\": \"N\",\"description\": \"Smartphone - Line Access\",\"price\": \"20.00\",\"displayHumWiFi\": false},{\"id\": \"84071\",\"actionIndicator\": \"D\",\"customerAddedInd\": \"N\",\"description\": \"RTR for Carryover Data\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"84076\",\"actionIndicator\": \"D\",\"customerAddedInd\": \"N\",\"description\": \"Provision Entitlement Services\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"84077\",\"actionIndicator\": \"D\",\"customerAddedInd\": \"N\",\"description\": \"RTR Service Trigger\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"84094\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"International Services Enabled Lite\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"85405\",\"actionIndicator\": \"A\",\"customerAddedInd\": \"N\",\"description\": \"Entitlement for Unlimited\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"85553\",\"actionIndicator\": \"A\",\"customerAddedInd\": \"N\",\"description\": \"Verizon Cloud Eligible\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"86189\",\"actionIndicator\": \"A\",\"customerAddedInd\": \"N\",\"description\": \"Email and Web\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"86198\",\"actionIndicator\": \"A\",\"customerAddedInd\": \"N\",\"description\": \"Mobile Hotspot 15GB\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"86209\",\"actionIndicator\": \"A\",\"customerAddedInd\": \"N\",\"description\": \"Include Mexico & Canada in your domestic plan\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"86225\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"AUTO CONFIGURATION $0\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"86848\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"4G SERVICE ON 5G DEVICE\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"86905\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"GSM Roaming Priority\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"87953\",\"actionIndicator\": \"A\",\"customerAddedInd\": \"N\",\"description\": \"RTR / UC Trigger Play More\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"87956\",\"actionIndicator\": \"A\",\"customerAddedInd\": \"N\",\"description\": \"RTR Play More Unlimited\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"87959\",\"actionIndicator\": \"A\",\"customerAddedInd\": \"N\",\"description\": \"Entitlement Trigger\",\"price\": \"0.00\",\"displayHumWiFi\": false}],\"pairingInfo\": {},\"featureMessages\": [{\"name\": \"VERIZON_CLOUD_DISCOUNT\",\"action\": \"ADD\"},{\"name\": \"5GUWBBOLT\",\"action\": \"ADD\"}],\"firstMonthInstallment\": 40.28,\"monthlyInstallment\": 39.99,\"tabletJetpackDiscountLoss\": \"N\",\"reasonCode\": \"PLAN_DEVICE_COMPATIBLE\",\"mtn\": \"8125825035\",\"devicePlanCompatible\": true,\"planValidationFailed\": false,\"currentPlanType\": \"LLP\",\"planQualifiedForPromotion\": false,\"fiveGUpSell\": false,\"is5GBoltEligible\": false,\"disqualifiedPropositions\": [],\"qualifiedPropositions\": [],\"fiveGPlanAdded\": true,\"editSim\": false,\"lineWithSkipMDN\": false,\"inWithVerizonOpted\": false,\"protectionNotRequired\": false}],\"expressCheckout\": false,\"effectiveDateDetails\": {\"isOnDemandAllowed\": false,\"isBackDateAllowed\": true,\"isFutureDateAllowed\": true,\"suggestedBackDate\": \"11/12/2021\",\"suggestedFutureDate\": \"12/12/2021\",\"currentBillCycleBeginDate\": \"11/12/2021\",\"nextBillCycleBeginDate\": \"12/12/2021\",\"onDemandDate\": \"\",\"onDemandRangeInDays\": \"45\"},\"autoPayEnrollmentDetails\": {\"isAutoPayEnrolled\": \"Y\",\"isPaperLessEnrolled\": \"Y\",\"isAutoPayPaperLessDiscountEligible\": \"N\"},\"planChangeWarningMessages\": [{\"warningMessageCode\": \"ECPD_DISCOUNT_NOT_CARRY_OVER_KEY\"},{\"warningMessageCode\": \"FIVEG_PLAN_CHANGE_WARNING\",\"warningMessage\": \"WARNING - This change will disconnect active voice and data sessions. Before processing, ensure that you address all concerns first. Advise the customer to power cycle their device(s) after the change to enjoy the benefits of their new plan.\"}],\"discountPromoTotal\": 0.0,\"registerNumber\": 0,\"protectionNotRequired\": false},\"processMTNList\": [{\"mtn\": \"8125825035\",\"completedprocessSteps\": [\"MTNSelectionPage\",\"GridWallPDP\",\"PlanSelection\"]}]}}},\"serviceHeader\": {\"clientId\": \"CHAT-STORE\",\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\",\"correlationId\": \"soe-cart-2021.11.12.05.37.20-328.4184785081927\"}}";
        AddPlanUIRequest request = mapper.readValue(requestString, AddPlanUIRequest.class);
        AddPlanUIResponse response = mapper.readValue(responseString, AddPlanUIResponse.class);
        URI url = URI.create("http://localhost/add-plan");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", CartConstants.RETAIL).cookie(new HttpCookie(CartConstants.ASSISTED_IG_SESSION_ID,"assisted1")).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.addPlan(any())).thenReturn(Mono.just(response));
        when(redisHelper2.updateCartOrderFlowType("cpc")).thenReturn(Mono.just(true));
        when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just("eup"));
        when(redisHelper2.getPlanPathDetails()).thenReturn(Mono.just(new HashMap()));
        when(redisHelper.updateSPOsIntoRedis(any())).thenReturn(Mono.just(Boolean.TRUE));
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addPlan(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", CartConstants.RETAIL_IPAD).cookie(new HttpCookie(CartConstants.ASSISTED_IG_SESSION_ID,"assisted1")).build();
        controllerResponse = cartController.addPlan(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", CartConstants.RETAIL_IPAD).build();
        controllerResponse = cartController.addPlan(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", CartConstants.OMNI_INDIRECT).cookie(new HttpCookie(CartConstants.ASSISTED_IG_SESSION_ID,"assisted1")).build();
        controllerResponse = cartController.addPlan(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        request.getCartInfo().setFlexV2(true);
        controllerResponse = cartController.addPlan(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(Assert::assertNotNull).expectComplete().verify();

        request.getCartInfo().setFlexV2(false);
        request.setRetrieveCart(null);
        controllerResponse = cartController.addPlan(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(Assert::assertNotNull).expectComplete().verify();

        request.setRetrieveCart(new CXPRetrieveCartDataVO());
        when(redisHelper.addFlowNameToRedis(Mockito.any())).thenReturn(Mono.just(true));
        controllerResponse = cartController.addPlan(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void clearCartQuickShopCookieTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-514162-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"GridWallPDP\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addBuyOutAmt\"},\"customerInfo\":{\"accountNumber\":\"0100007530-00001\",\"cartCreator\":\"4125102507\"},\"cartInfo\":{\"cartId\":\"8ab56dcb-4268-4ea8-99f2-99955effe2cd\",\"statusCode\":\"0\",\"statusMsg\":\"Success\"}}}}}";
        ClearCartUIRequest request = mapper.readValue(requestString, ClearCartUIRequest.class);
        ClearCartUIResponse response = mapper.readValue(responseString, ClearCartUIResponse.class);
        URI url = URI.create("http://localhost/clearCart");
        when(redisHelper.deleteAddDeviceDataFromRedis(any())).thenReturn(Mono.just(1L));
        when(redisHelper.deleteProcessingMtnFromRedis(any())).thenReturn(Mono.just(1L));
        when(cartHelper.clearCart(any())).thenReturn(Mono.just(response));
        ServerHttpRequest httpHeader1 = MockServerHttpRequest.method(HttpMethod.POST, url)
                .header("channelId","VZW-DOTCOM")
                .cookie(new HttpCookie("quickShopProspectCart","true")).build();
        ServerHttpResponse httpResponse1 = new MockServerHttpResponse();
        StepVerifier.create(cartController.clearCart(httpHeader1, httpResponse1,request)).expectError().verify();
        ServerHttpRequest httpHeader2 = MockServerHttpRequest.method(HttpMethod.POST, url)
                .header("channelId","VZW-DOTCOM").build();
        ServerHttpResponse httpResponse2 = new MockServerHttpResponse();
        StepVerifier.create(cartController.clearCart(httpHeader2, httpResponse2,request)).expectError().verify();
    }

    @Test
    public void testSetClearCartCookies() throws IOException {
        when(featureFlagHelper.isNgdProspectClearCartCookiesEnabled()).thenReturn(Boolean.TRUE);
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"NSE\"}}";
        ClearCartUIRequest request = mapper.readValue(requestString, ClearCartUIRequest.class);
        String responseString="{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-514162-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"GridWallPDP\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addBuyOutAmt\"},\"customerInfo\":{\"accountNumber\":\"0100007530-00001\",\"cartCreator\":\"4125102507\"},\"cartInfo\":{\"cartId\":\"8ab56dcb-4268-4ea8-99f2-99955effe2cd\",\"statusCode\":\"0\",\"statusMsg\":\"Success\",\"cartItemCount\":0}}}}}";
        ClearCartUIResponse clearCartUiResponse = mapper.readValue(responseString, ClearCartUIResponse.class);
        URI url = URI.create("http://localhost/clearCart");
        request.setChannelId(CartConstants.VZW_DOTCOM);
        request.getCartInfo().setIntendType(CartConstants.NSE);
        when(redisHelper.deleteAddDeviceDataFromRedis(any())).thenReturn(Mono.just(1L));
        when(redisHelper.deleteProcessingMtnFromRedis(any())).thenReturn(Mono.just(1L));
        when(cartHelper.clearCart(any())).thenReturn(Mono.just(clearCartUiResponse));

        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url)
                .header("channelId", "VZW-DOTCOM")
                .cookie(new HttpCookie("quickShopProspectCart", "true"))
                .cookie(new HttpCookie("digital_ig_session", "digital_ig_session"))
                .build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        StepVerifier.create(cartController.clearCart(httpHeader, httpResponse,request)).expectError().verify();
        when(featureFlagHelper.isNgdProspectClearCartCookiesEnabled()).thenReturn(Boolean.FALSE);
        StepVerifier.create(cartController.clearCart(httpHeader, httpResponse,request)).expectError().verify();

    }

    @Test
    public void testExtractURLWithInvalidXHostHeader() {
        ServerHttpRequest request = MockServerHttpRequest.get("http://localhost/clearCart")
                .header("X-Host", "invalid-url")
                .build();
        String url = CartUpdateOperationsController.extractURL(request);
        assertEquals("localhost", url);
    }

    @Test
    public void testSetClearCartCookiesWithCartItemCount() {
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, "http://localhost/clearCart").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        Optional<Integer> cartItemCount = Optional.of(10);

        cartController.setClearCartCookies(httpHeader, httpResponse, cartItemCount);

        List<ResponseCookie> cookies = httpResponse.getCookies().values().stream().flatMap(Collection::stream).collect(Collectors.toList());
        assertEquals(4, cookies.size());
        assertTrue(cookies.stream().anyMatch(cookie -> cookie.getName().equals(CartConstants.PROSPECT_DEVICE_COUNT) && cookie.getValue().equals("5")));
        assertTrue(cookies.stream().anyMatch(cookie -> cookie.getName().equals(CartConstants.PROSPECT_CART_AVAILABLE) && cookie.getValue().equals(CartConstants.FALSE)));
        assertTrue(cookies.stream().anyMatch(cookie -> cookie.getName().equals(CartConstants.PROSPECT_CART_ACTIVE) && cookie.getValue().equals(CartConstants.FALSE)));
    }
        @Test
    public void mergeFeatureFlagWithResponseTest1() {
        AddPlanUIResponse res = new AddPlanUIResponse();
        ResponseEntity<Object> responseEntity =
                ResponseEntity.status(HttpStatus.OK).body(res);
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        assertNotNull(cartController.mergeFeatureFlagWithResponse(Mono.zip(Mono.just(res), Mono.just(configurationProfile))));

    }

    @Test
    public void createClearCartCookiesTest() throws JsonProcessingException {
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, "http://localhost/clearCart").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        String cartItemCount = String.valueOf(0);
        String pegaResponseString="{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-514162-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"GridWallPDP\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addBuyOutAmt\"},\"customerInfo\":{\"accountNumber\":\"0100007530-00001\",\"cartCreator\":\"4125102507\"},\"cartInfo\":{\"cartId\":\"8ab56dcb-4268-4ea8-99f2-99955effe2cd\",\"statusCode\":\"0\",\"statusMsg\":\"Success\",\"cartItemCount\":0}}}}}";
        ClearCartUIResponse pegaResponse = mapper.readValue(pegaResponseString, ClearCartUIResponse.class);
        List<String> domains= List.of(".verizon.com", ".verizonwireless.com");
        CartAddDeviceUtil.createClearCartCookies(httpResponse, pegaResponse, cartItemCount, domains);
        assertFalse("response must contain cookies", httpResponse.getCookies().isEmpty());
    }
}
