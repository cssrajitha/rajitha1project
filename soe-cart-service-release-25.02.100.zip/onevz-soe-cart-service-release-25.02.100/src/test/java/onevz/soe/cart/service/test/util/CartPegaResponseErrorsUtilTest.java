package onevz.soe.cart.service.test.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.model.addTrialContactInfoAndAddress.AddTrialContactInfoAndAddressUIResponse;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.common.CartErrorDetail;
import onevz.soe.cart.model.initiateValidateDeviceSim.InitiateValidateDeviceSimUIResponse;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.requests.UpdateGiftItemUIResponse;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.cart.util.CartPegaResponseErrorsUtil;
import onevz.soe.cart.util.CartPegaResponseErrorsUtil2;
import onevz.soe.exception.SOEErrorHolder;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(CartPegaResponseErrorsUtil.class)
public class CartPegaResponseErrorsUtilTest {
	
	@Autowired
	private ObjectMapper mapper;
	
	@MockBean
	CartPegaResponseErrorsUtil util;

	@MockBean
	CartPegaResponseErrorsUtil2 util2;
	
	@Test
	public void handleClearAndContinueResponseErrorsTest() throws JsonMappingException, JsonProcessingException
	{
		String requestString = "{\"errors\":[{\"errorSpec\":null,\"detailList\":null,\"nameSpace\":\"abc\",\"id\":\"234\"}],\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		ClearAndContinueUIResponse response=mapper.readValue(requestString,ClearAndContinueUIResponse.class);
		util.handleClearAndContinueResponseErrors(response);
		response.setErrors(null);
		util.handleClearAndContinueResponseErrors(response);
		response.setErrors(Collections.emptyList());
		util.handleClearAndContinueResponseErrors(response);
	}
	
	@Test
	public void handleResumeAndContinueResponseErrorsTest() throws JsonMappingException, JsonProcessingException
	{
		String requestString = "{\"errors\":[{\"errorSpec\":null,\"detailList\":null,\"nameSpace\":\"abc\",\"id\":\"234\"}],\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		ResumeAndContinueUIResponse response=mapper.readValue(requestString,ResumeAndContinueUIResponse.class);
		util.handleResumeAndContinueResponseErrors(response);
		response.setErrors(null);
		util.handleResumeAndContinueResponseErrors(response);
		response.setErrors(Collections.emptyList());
		util.handleResumeAndContinueResponseErrors(response);
	}
	
	@Test
	public void handleAddPlanResponseErrorsTest() throws JsonMappingException, JsonProcessingException
	{
		String requestString = "{\"errors\":[{\"errorSpec\":null,\"detailList\":null,\"nameSpace\":\"abc\",\"id\":\"234\"}],\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		AddPlanUIResponse response=mapper.readValue(requestString,AddPlanUIResponse.class);
		util.handleAddPlanResponseErrors(response);
	}
	
	@Test
	public void handleUpdateSellerPriceResponseErrorsTest() throws JsonMappingException, JsonProcessingException
	{
		String requestString = "{\"errors\":[{\"errorSpec\":null,\"detailList\":null,\"nameSpace\":\"abc\",\"id\":\"234\"}],\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		UpdateSellerPriceUIResponseNew response=mapper.readValue(requestString,UpdateSellerPriceUIResponseNew.class);
		util.handleUpdateSellerPriceResponseErrors(response);
	}
	

	@Test
	public void handleManualDiscountResponseErrorsTest() throws JsonMappingException, JsonProcessingException
	{
		String requestString = "{\"errors\":[{\"errorSpec\":null,\"detailList\":null,\"nameSpace\":\"abc\",\"id\":\"234\"}],\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		ManualDiscountUIResponse response=mapper.readValue(requestString,ManualDiscountUIResponse.class);
		util.handleManualDiscountResponseErrors(response);
	}
	
	@Test
	public void handleEffectiveDateResponseErrorsTest() throws JsonMappingException, JsonProcessingException
	{
		
		String requestString = "{\"errors\":[{\"errorSpec\":null,\"detailList\":null,\"nameSpace\":\"abc\",\"id\":\"234\"}],\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		EffectiveDateUIResponse response=mapper.readValue(requestString,EffectiveDateUIResponse.class);
		util.handleEffectiveDateResponseErrors(response);
	}
	
	@Test
	public void handleCommonErrorTest() throws JsonMappingException, JsonProcessingException
	{
		
		String requestString = "{\"errors\":[{\"errorSpec\":null,\"detailList\":null,\"nameSpace\":\"abc\",\"id\":\"234\"}],\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		SOEErrorHolder response=mapper.readValue(requestString,SOEErrorHolder.class);
		util.handleCommonError(response);
	}
	
	@Test
	public void handleUpdateWFMInfoResponseErrorsTest() throws JsonMappingException, JsonProcessingException
	{
		
		String requestString = "{\"errors\":[{\"errorSpec\":null,\"detailList\":null,\"nameSpace\":\"abc\",\"id\":\"234\"}],\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		UpdateWFMInfoUIResponse response=mapper.readValue(requestString,UpdateWFMInfoUIResponse.class);
		util.handleUpdateWFMInfoResponseErrors(response);
	}
	
	@Test
	public void handleRPSE911AddressUpdateResponseErrorsTest() throws JsonMappingException, JsonProcessingException
	{
		
		String requestString = "{\"errors\":[{\"errorSpec\":null,\"detailList\":null,\"nameSpace\":\"abc\",\"id\":\"234\"}],\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		RPSE911AddressUpdateUIResponse response=mapper.readValue(requestString,RPSE911AddressUpdateUIResponse.class);
		util.handleRPSE911AddressUpdateResponseErrors(response);
	}
	
	@Test
	public void handleRPSReleasePendingOrderResponseErrorsTest() throws JsonMappingException, JsonProcessingException
	{
		
		String requestString = "{\"errors\":[{\"errorSpec\":null,\"detailList\":null,\"nameSpace\":\"abc\",\"id\":\"234\"}],\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		RPSReleasePendingOrderResponse response=mapper.readValue(requestString,RPSReleasePendingOrderResponse.class);
		util.handleRPSReleasePendingOrderResponseErrors(response);
	}
	
	@Test
	public void handleRPSE911AddressRetrieveResponseErrorsTest() throws JsonMappingException, JsonProcessingException
	{
		
		String requestString = "{\"errors\":[{\"errorSpec\":null,\"detailList\":null,\"nameSpace\":\"abc\",\"id\":\"234\"}],\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		RPSE911AddressRetrieveUIResponse response=mapper.readValue(requestString,RPSE911AddressRetrieveUIResponse.class);
		util.handleRPSE911AddressRetrieveResponseErrors(response);
	}
	
	@Test
	public void handleAccountPinResponseErrorsTest() throws JsonMappingException, JsonProcessingException
	{
		
		String requestString = "{\"errors\":[{\"errorSpec\":null,\"detailList\":null,\"nameSpace\":\"abc\",\"id\":\"234\"}],\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		AccountPinUIResponse response=mapper.readValue(requestString,AccountPinUIResponse.class);
		util2.handleAccountPinResponseErrors(response);
	}
	
	
	
	@Test
	public void handlebbpGetProcessStepErrorsTest() throws JsonMappingException, JsonProcessingException
	{
		
		String requestString = "{\"errors\":[{\"errorSpec\":null,\"detailList\":null,\"nameSpace\":\"abc\",\"id\":\"234\"}],\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		BbpGetProcessStepUIResponse response=mapper.readValue(requestString,BbpGetProcessStepUIResponse.class);
		util2.handlebbpGetProcessStepErrors(response);
	}
	
	@Test
	public void handleRemoveLockResponseErrorsTest() throws JsonMappingException, JsonProcessingException
	{
		
		String requestString = "{\"errors\":[{\"errorSpec\":null,\"detailList\":null,\"nameSpace\":\"abc\",\"id\":\"234\"}],\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		RemoveLockUIResponse response=mapper.readValue(requestString,RemoveLockUIResponse.class);
		util2.handleRemoveLockResponseErrors(response);
	}
	
	
	@Test
	public void handleRetrieveActivationStatusResponseErrorsTest() throws JsonMappingException, JsonProcessingException
	{
		
		String requestString = "{\"errors\":[{\"errorSpec\":null,\"detailList\":null,\"nameSpace\":\"abc\",\"id\":\"234\"}],\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		RetrieveActivationStatusUIResponse response=mapper.readValue(requestString,RetrieveActivationStatusUIResponse.class);
		util2.handleRetrieveActivationStatusResponseErrors(response);
	}
	
	
	@Test
	public void handleAddDeviceResponseErrorsFiveGHomeTest() throws JsonMappingException, JsonProcessingException
	{
		
		String requestString = "{\"errors\":[{\"errorSpec\":null,\"detailList\":null,\"nameSpace\":\"abc\",\"id\":\"234\"}],\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		AddPlanAndDeviceUIResponse response=mapper.readValue(requestString,AddPlanAndDeviceUIResponse.class);
		util2.handleAddDeviceResponseErrorsFiveGHome(response);
		response.setErrors(Collections.emptyList());
		util2.handleAddDeviceResponseErrorsFiveGHome(response);
		response.setErrors(null);
		util2.handleAddDeviceResponseErrorsFiveGHome(response);
	}
	
	
	
	@Test
	public void handleCommonErrorFiveGFlowTest() throws JsonMappingException, JsonProcessingException
	{
		
		String requestString = "{\"errors\":[{\"errorSpec\":null,\"detailList\":null,\"nameSpace\":\"abc\",\"id\":\"234\"}],\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		SOEErrorHolder response=mapper.readValue(requestString,SOEErrorHolder.class);
		util2.handleCommonErrorFiveGFlow(response);
		util2.handleCommonErrorFiveGFlow(null);
	}
		
	
	@Test
	public void handleGetPairedWatchesResponseErrorsTest() throws JsonMappingException, JsonProcessingException
	{
		
		String requestString = "{\"errors\":[{\"errorSpec\":null,\"detailList\":null,\"nameSpace\":\"abc\",\"id\":\"234\"}],\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		GetPairedDevicesUIResponse response=mapper.readValue(requestString,GetPairedDevicesUIResponse.class);
		util2.handleGetPairedWatchesResponseErrors(response);
	}
		
	@Test
	public void handleCrmRetrieveResponseErrorsFiveGHomeTest() throws JsonMappingException, JsonProcessingException
	{
		
		String requestString = "{\"errors\":[{\"errorSpec\":null,\"detailList\":null,\"nameSpace\":\"abc\",\"id\":\"234\"}],\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		CrmRetrieveCartUIResponse response=mapper.readValue(requestString,CrmRetrieveCartUIResponse.class);
		util2.handleCrmRetrieveResponseErrorsFiveGHome(response);
	}
	
	
	@Test
	public void handleValidateE911AddressResponseErrorsTest() throws JsonMappingException, JsonProcessingException
	{
		
		String requestString = "{\"errors\":[{\"errorSpec\":null,\"detailList\":null,\"nameSpace\":\"abc\",\"id\":\"234\"}],\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		ValidateE911AddressUIResponse response=mapper.readValue(requestString,ValidateE911AddressUIResponse.class);
		util2.handleValidateE911AddressResponseErrors(response);
	}
	
	
	@Test
	public void handleCreateCaseResponseErrorsTest() throws JsonMappingException, JsonProcessingException
	{
		
		String requestString = "{\"errors\":[{\"errorSpec\":null,\"detailList\":null,\"nameSpace\":\"abc\",\"id\":\"234\"}],\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		CreateCaseAndGetCustomerInfoUIResponse response=mapper.readValue(requestString,CreateCaseAndGetCustomerInfoUIResponse.class);
		util2.handleCreateCaseResponseErrors(response);
	}
	
	
	
	
	@Test
	public void handleGuestChoiceResponseErrorsTest() throws JsonMappingException, JsonProcessingException
	{
		
		String requestString = "{\"errors\":[{\"errorSpec\":null,\"detailList\":null,\"nameSpace\":\"abc\",\"id\":\"234\"}],\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		GuestChoiceUIResponse response=mapper.readValue(requestString,GuestChoiceUIResponse.class);
		util2.handleGuestChoiceResponseErrors(response);
	}
	
	
	@Test
	public void handleUpdateGiftItemResponseErrorsTest() throws JsonMappingException, JsonProcessingException
	{
		
		String requestString = "{\"errors\":[{\"errorSpec\":null,\"detailList\":null,\"nameSpace\":\"abc\",\"id\":\"234\"}],\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		UpdateGiftItemUIResponse response=mapper.readValue(requestString,UpdateGiftItemUIResponse.class);
		util2.handleUpdateGiftItemResponseErrors(response);
	}
	@Test
	public void handleAddReplenishmentToCartResponseErrorsTest() throws JsonMappingException, JsonProcessingException
	{
		
		String responseString="{\"errors\":[{\"namespace\":\"cxp-shopping-services\",\"name\":\"SYSTEM_ERROR\",\"id\":\"3999\",\"debug_id\":\"2022-09-21T16:04:33.+0000:ff5de96c78ce3ef4:cxp-shopping-services-qa-ev6v-sit2w-nscxp-c5758b64b-qptks:nssit2\",\"message\":\"System error, please try again\",\"severity\":\"High\",\"errorCategory\":\"UNKNW\",\"category\":\"UNKNOWN_ERR\"}]}";
		AddReplenishmentToCartUIResponse response=mapper.readValue(responseString,AddReplenishmentToCartUIResponse.class);
		util2.handleAddReplenishmentToCartResponseErrors(response);
	}
	
	@Test
	public void handleAFOResponseErrorsTest() throws JsonMappingException, JsonProcessingException
	{
		
		String requestString = "{\"errors\":[{\"errorSpec\":null,\"detailList\":null,\"nameSpace\":\"abc\",\"id\":\"234\"}],\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		AccessoryFinancingOffersUIResponse response=mapper.readValue(requestString,AccessoryFinancingOffersUIResponse.class);
		util2.handleAFOResponseErrors(response);
	}
	
	@Test
	public void handleAEMErrorTest() throws JsonMappingException, JsonProcessingException
	{
		
		String requestString = "{\"errors\":{\"errorSpec\":null,\"detailList\":null,\"nameSpace\":\"abc\",\"id\":\"234\"},\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		//SOEHTTPException response=mapper.readValue(requestString,SOEHTTPException.class);
		SOEHTTPException SOEHTTPExceptionObj = new SOEHTTPException(0, new SOEErrorHolder());
		 Mono<ResponseEntity<SOEErrorHolder>> monores=util.handleAEMError(SOEHTTPExceptionObj);

		SOEHTTPExceptionObj = new SOEHTTPException(0, (SOEErrorHolder)null);
		util.handleAEMError(SOEHTTPExceptionObj);

		util.handleAEMError(null);
	}
	@Test
	public void handleAddDeviceResponseErrorsTest() throws JsonMappingException, JsonProcessingException
	{
		String requestString = "{\"tradeInAdded\": true, \"errors\":[{\"errorSpec\":null,\"detailList\":null,\"nameSpace\":\"abc\",\"id\":\"234\"}],\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		AddDeviceUIResponse response=mapper.readValue(requestString, AddDeviceUIResponse.class);
		util.handleAddDeviceResponseErrors(response);
		response.setErrors(null);
		util.handleAddDeviceResponseErrors(response);
		response.setErrors(Collections.emptyList());
		util.handleAddDeviceResponseErrors(response);
	}
	
	@Test
	public void handleSaveCartResponseErrorsTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		SaveCartUIResponse response=mapper.readValue(requestString,SaveCartUIResponse.class);
		Assert.assertNotNull(util.handleSaveCartResponseErrors(response));
	}

	@Test
	public void handleUpdateBarCodeResponseErrorsTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		UpdateBarcodeUIResponse response=mapper.readValue(requestString,UpdateBarcodeUIResponse.class);
		Assert.assertNotNull(util.handleUpdateBarCodeResponseErrors(response));
	}

	@Test
	public void handleDeviceIdValidationResponseErrorsTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		DeviceIdValidationUIResponse response=mapper.readValue(requestString,DeviceIdValidationUIResponse.class);
		Assert.assertNotNull(util.handleDeviceIdValidationResponseErrors(response));
	}

	@Test
	public void handleAddDeviceResponseErrorsTest1() throws JsonMappingException, JsonProcessingException {
		String responseString = "{\"tradeInAdded\":null,\"errors\":null,\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
		AddDeviceUIResponse response=mapper.readValue(responseString, AddDeviceUIResponse.class);
		Assert.assertNotNull(util.handleAddDeviceResponseErrors(response));
	}

	@Test
	public void handleClearAndContinueResponseErrorsTest1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		ClearAndContinueUIResponse response=mapper.readValue(requestString,ClearAndContinueUIResponse.class);
		Assert.assertNotNull(util.handleClearAndContinueResponseErrors(response));
	}

	@Test
	public void handleResumeAndContinueResponseErrorsTest1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		ResumeAndContinueUIResponse response=mapper.readValue(requestString,ResumeAndContinueUIResponse.class);
		Assert.assertNotNull(util.handleResumeAndContinueResponseErrors(response));
	}

	@Test
	public void handleAddPlanResponseErrorsTest1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		AddPlanUIResponse response=mapper.readValue(requestString,AddPlanUIResponse.class);
		Assert.assertNotNull(util.handleAddPlanResponseErrors(response));
	}

	@Test
	public void handleUpdateDeviceSimIdResponseErrorsTest1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		UpdateDeviceSIMIdUIResponse response=mapper.readValue(requestString,UpdateDeviceSIMIdUIResponse.class);
		Assert.assertNotNull(util.handleUpdateDeviceSimIdResponseErrors(response));
	}

	@Test
	public void handlePastDuesResponseErrorsTest1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		PastDuesUIResponse response=mapper.readValue(requestString,PastDuesUIResponse.class);
		Assert.assertNotNull(util.handlePastDuesResponseErrors(response));
	}

	@Test
	public void handleRemoveBvoOffersResponseErrorsTest1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		UpdateBvoOffersUIResponse  response=mapper.readValue(requestString,UpdateBvoOffersUIResponse .class);
		Assert.assertNotNull(util.handleRemoveBvoOffersResponseErrors(response));
	}

	@Test
	public void handleUpdateSellerPriceResponseErrorsTest1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		UpdateSellerPriceUIResponseNew response=mapper.readValue(requestString,UpdateSellerPriceUIResponseNew.class);
		Assert.assertNotNull(util.handleUpdateSellerPriceResponseErrors(response));
	}

	@Test
	public void handleCreateLineResponseErrorsTest1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		CreateLineUIResponse response = mapper.readValue(requestString,CreateLineUIResponse.class);
		Assert.assertNotNull(util.handleCreateLineResponseErrors(response));
	}

	@Test
	public void handleNumberShareResponseErrorsTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		NumberShareUIResponse  response = mapper.readValue(requestString,NumberShareUIResponse.class);
		Assert.assertNotNull(util.handleNumberShareResponseErrors(response));
	}

	@Test
	public void handleServiceAddressResponseErrorsTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		ServiceAddressUIResponse   response = mapper.readValue(requestString,ServiceAddressUIResponse.class);
		Assert.assertNotNull(util.handleServiceAddressResponseErrors(response));
	}

	@Test
	public void handleBillingAddressResponseErrorsTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		BillingAddressUIResponse response = mapper.readValue(requestString,BillingAddressUIResponse.class);
		Assert.assertNotNull(util.handleBillingAddressResponseErrors(response));
	}

	@Test
	public void handleE911AddressResponseErrorsTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		E911AddressUIResponse  response = mapper.readValue(requestString,E911AddressUIResponse.class);
		Assert.assertNotNull(util.handleE911AddressResponseErrors(response));
	}

	@Test
	public void handleInstantCreditDownPaymentResponseErrorsTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		InstantCreditDownPaymentUIResponse  response = mapper.readValue(requestString,InstantCreditDownPaymentUIResponse.class);
		Assert.assertNotNull(util.handleInstantCreditDownPaymentResponseErrors(response));
	}

	@Test
	public void handleSalesRepAndLocationCodeResponseErrorsTest1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		SalesRepAndLocationCodeUIResponse   response = mapper.readValue(requestString,SalesRepAndLocationCodeUIResponse.class);
		Assert.assertNotNull(util.handleSalesRepAndLocationCodeResponseErrors(response));
	}

	@Test
	public void handleEffectiveDateOverrideResponseErrorsTest1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		EffectiveDateOverrideUIResponse    response = mapper.readValue(requestString,EffectiveDateOverrideUIResponse.class);
		Assert.assertNotNull(util.handleEffectiveDateOverrideResponseErrors(response));
	}

	@Test
	public void handleManualDiscountResponseErrorsTest1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		ManualDiscountUIResponse response=mapper.readValue(requestString,ManualDiscountUIResponse.class);
		Assert.assertNotNull(util.handleManualDiscountResponseErrors(response));
	}

	@Test
	public void handleAssignMtnResponseErrorsTest1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		AssignMtnUIResponse response = mapper.readValue(requestString,AssignMtnUIResponse.class);
		Assert.assertNotNull(util.handleAssignMtnResponseErrors(response));
	}

	@Test
	public void handleDeassignMtnResponseErrorsTest1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		DeassignMtnUIResponse  response = mapper.readValue(requestString,DeassignMtnUIResponse.class);
		Assert.assertNotNull(util.handleDeassignMtnResponseErrors(response));
	}

	@Test
	public void handleAddAdd5GBulkOrderResponseErrorsTest1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		Add5GBulkOrderUIResponse   response = mapper.readValue(requestString,Add5GBulkOrderUIResponse.class);
		Assert.assertNotNull(util.handleAddAdd5GBulkOrderResponseErrors(response));
		response.setErrors(Collections.emptyList());
		Assert.assertNotNull(util.handleAddAdd5GBulkOrderResponseErrors(response));
		response.setErrors(null);
		Assert.assertNotNull(util.handleAddAdd5GBulkOrderResponseErrors(response));
	}

	@Test
	public void handleEffectiveDateResponseErrorsTest1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		EffectiveDateUIResponse response=mapper.readValue(requestString,EffectiveDateUIResponse.class);
		Assert.assertNotNull(util.handleEffectiveDateResponseErrors(response));
	}

	@Test
	public void handleManualPairingResponseErrorsTest1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		ManualPairingUIResponse  response=mapper.readValue(requestString,ManualPairingUIResponse.class);
		Assert.assertNotNull(util.handleManualPairingResponseErrors(response));
		response.setErrors(Collections.emptyList());
		Assert.assertNotNull(util.handleManualPairingResponseErrors(response));
		response.setErrors(null);
		Assert.assertNotNull(util.handleManualPairingResponseErrors(response));
	}

	@Test
	public void handleRevokeRebatesResponseErrorsTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		RevokeRebatesUIResponse response = mapper.readValue(requestString,RevokeRebatesUIResponse.class);
		Assert.assertNotNull(util.handleRevokeRebatesResponseErrors(response));
		response.setErrors(Collections.emptyList());
		Assert.assertNotNull(util.handleRevokeRebatesResponseErrors(response));
		response.setErrors(null);
		Assert.assertNotNull(util.handleRevokeRebatesResponseErrors(response));
	}

	@Test
	public void handleVoidOrderResponseErrorsTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		VoidOrderUIResponse  response = mapper.readValue(requestString,VoidOrderUIResponse.class);
		Assert.assertNotNull(util.handleVoidOrderResponseErrors(response));
	}

	@Test
	public void handleCancelCaseResponseErrorsTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		CancelCaseUIResponse  response = mapper.readValue(requestString,CancelCaseUIResponse .class);
		Assert.assertNotNull(util.handleCancelCaseResponseErrors(response));
	}

	@Test
	public void handleActivateLaterResponseErrorsTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		ActivateLaterUIResponse  response = mapper.readValue(requestString,ActivateLaterUIResponse.class);
		Assert.assertNotNull(util.handleActivateLaterResponseErrors(response));
	}

	@Test
	public void handleUpdateTransferUpgradeResponseErrorsTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		UpdateTransferUpgradeUIResponse   response = mapper.readValue(requestString,UpdateTransferUpgradeUIResponse.class);
		Assert.assertNotNull(util.handleUpdateTransferUpgradeResponseErrors(response));
	}

	@Test
	public void handleAddNickNameResponseErrorsTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		AddNickNameUIResponse    response = mapper.readValue(requestString,AddNickNameUIResponse .class);
		Assert.assertNotNull(util.handleAddNickNameResponseErrors(response));
		response.setErrors(Collections.emptyList());
		Assert.assertNotNull(util.handleAddNickNameResponseErrors(response));
		response.setErrors(null);
		Assert.assertNotNull(util.handleAddNickNameResponseErrors(response));
	}

	@Test
	public void handleUpdateChatIdResponseErrorsTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		UpdateChatIdUIResponse   response = mapper.readValue(requestString,UpdateChatIdUIResponse  .class);
		Assert.assertNotNull(util.handleUpdateChatIdResponseErrors(response));
	}

	@Test
	public void handleClearCartResponseErrorsTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		ClearCartUIResponse  response = mapper.readValue(requestString,ClearCartUIResponse   .class);
		Assert.assertNotNull(util.handleClearCartResponseErrors(response));
	}

	@Test
	public void handleCommonErrorTest1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":[{\"errorSpec\":null,\"detailList\":null,\"nameSpace\":\"Failure\",\"id\":\"1007\",\"proactiveChatCustomMSG\":\"Netwrok issue\",\"proactiveChatIndicator\":\"yes\",\"details\":[{\"issue\":\"login issue\",\"field\":\"admin\",\"location\":\"E0987\",\"value\":\"07920\"}]}],\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		SOEErrorHolder response=mapper.readValue(requestString,SOEErrorHolder.class);
		Assert.assertNotNull(util.handleCommonError(response));
	}

	@Test
	public void handleCommonErrorTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		SOEErrorHolder response=mapper.readValue(requestString,SOEErrorHolder.class);
		try {
			Assert.assertNull(util.handleCommonError(response));
		} catch (NullPointerException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void handleCommonErrorTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":[{\"errorSpec\":null,\"detailList\":null,\"nameSpace\":\"Failure\",\"id\":\"1007\",\"proactiveChatCustomMSG\":\"Netwrok issue\",\"proactiveChatIndicator\":\"yes\",\"details\":[{\"issue\":null,\"field\":null,\"location\":null,\"value\":null}]}],\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		SOEErrorHolder response=mapper.readValue(requestString,SOEErrorHolder.class);
		Assert.assertNotNull(util.handleCommonError(response));
	}

	@Test
	public void handleUpdateWFMInfoResponseErrorsTest1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		UpdateWFMInfoUIResponse response=mapper.readValue(requestString,UpdateWFMInfoUIResponse.class);
		Assert.assertNotNull(util.handleUpdateWFMInfoResponseErrors(response));
	}

	@Test
	public void handleRPSE911AddressUpdateResponseErrorsTest1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		RPSE911AddressUpdateUIResponse response=mapper.readValue(requestString,RPSE911AddressUpdateUIResponse.class);
		Assert.assertNotNull(util.handleRPSE911AddressUpdateResponseErrors(response));
	}

	@Test
	public void handleRPSReleasePendingOrderResponseErrorsTest1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		RPSReleasePendingOrderResponse response=mapper.readValue(requestString,RPSReleasePendingOrderResponse.class);
		Assert.assertNotNull(util.handleRPSReleasePendingOrderResponseErrors(response));
	}

	@Test
	public void handleRPSE911AddressRetrieveResponseErrorsTest1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		RPSE911AddressRetrieveUIResponse response=mapper.readValue(requestString,RPSE911AddressRetrieveUIResponse.class);
		Assert.assertNotNull(util.handleRPSE911AddressRetrieveResponseErrors(response));
	}

	@Test
	public void handleAccountPinResponseErrorsTest1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		AccountPinUIResponse response=mapper.readValue(requestString,AccountPinUIResponse.class);
		Assert.assertNotNull(util2.handleAccountPinResponseErrors(response));
	}

	@Test
	public void handlebbpGetProcessStepErrorsTest1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		BbpGetProcessStepUIResponse response=mapper.readValue(requestString,BbpGetProcessStepUIResponse.class);
		Assert.assertNotNull(util2.handlebbpGetProcessStepErrors(response));
	}

	@Test
	public void handleRemoveLockResponseErrorsTest1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		RemoveLockUIResponse response=mapper.readValue(requestString,RemoveLockUIResponse.class);
		Assert.assertNotNull(util2.handleRemoveLockResponseErrors(response));
	}

	@Test
	public void handleRetrieveActivationStatusResponseErrorsTest1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		RetrieveActivationStatusUIResponse response=mapper.readValue(requestString,RetrieveActivationStatusUIResponse.class);
		Assert.assertNotNull(util2.handleRetrieveActivationStatusResponseErrors(response));
	}
	
	@Test
	public void handleAddReplenishmentToCartResponseErrorsTest1() throws JsonMappingException, JsonProcessingException {
		String responseString="{\"errors\":null}";
		AddReplenishmentToCartUIResponse response=mapper.readValue(responseString,AddReplenishmentToCartUIResponse.class);
		Assert.assertNotNull(util2.handleAddReplenishmentToCartResponseErrors(response));
	}
	
	@Test
	public void handleAFOResponseErrorsTest1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		AccessoryFinancingOffersUIResponse response=mapper.readValue(requestString,AccessoryFinancingOffersUIResponse.class);
		Assert.assertNotNull(util2.handleAFOResponseErrors(response));
	}
	
	@Test
	public void handleAddTrialContactInfoAndAddressResponseErrorsTest1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
		AddTrialContactInfoAndAddressUIResponse response=mapper.readValue(requestString,AddTrialContactInfoAndAddressUIResponse.class);
		Assert.assertNotNull(util2.handleAddTrialContactInfoAndAddressResponseErrors(response));
	}
	
	@Test
	public void handleUpdateGiftItemResponseErrorsTest1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
		UpdateGiftItemUIResponse  response=mapper.readValue(requestString,UpdateGiftItemUIResponse .class);
		Assert.assertNotNull(util2.handleUpdateGiftItemResponseErrors(response));
	}
	
	@Test
	public void handleInitiateValidateDeviceSimResponseErrorsTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":[{\"errorSpec\":null,\"detailList\":null,\"nameSpace\":\"Failure\",\"id\":\"1007\",\"proactiveChatCustomMSG\":\"Netwrok issue\",\"proactiveChatIndicator\":\"yes\",\"details\":[{\"issue\":\"login issue\",\"field\":\"admin\",\"location\":\"E0987\",\"value\":\"07920\"}]}],\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
		InitiateValidateDeviceSimUIResponse   response=mapper.readValue(requestString,InitiateValidateDeviceSimUIResponse.class);
		Assert.assertNotNull(util2.handleInitiateValidateDeviceSimResponseErrors(response));
	}
	
	@Test
	public void handleInitiateValidateDeviceSimResponseErrorsTest1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
		InitiateValidateDeviceSimUIResponse   response=mapper.readValue(requestString,InitiateValidateDeviceSimUIResponse.class);
		Assert.assertNotNull(util2.handleInitiateValidateDeviceSimResponseErrors(response));
	}
	
	@Test
	public void handleCheckExistingCartResponseErrorsTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
		CheckExistingCartUIResponse  response=mapper.readValue(requestString,CheckExistingCartUIResponse.class);
		Assert.assertNotNull(util2.handleCheckExistingCartResponseErrors(response));
	}
	
	@Test
	public void handleGuestChoiceResponseErrorsTest1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		GuestChoiceUIResponse response=mapper.readValue(requestString,GuestChoiceUIResponse.class);
		Assert.assertNotNull(util2.handleGuestChoiceResponseErrors(response));
	}
	
	@Test
	public void handleCreateCaseResponseErrorsTest1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		CreateCaseAndGetCustomerInfoUIResponse response=mapper.readValue(requestString,CreateCaseAndGetCustomerInfoUIResponse.class);
		Assert.assertNotNull(util2.handleCreateCaseResponseErrors(response));
	}
	
	@Test
	public void handleValidateE911AddressResponseErrorsTest1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		ValidateE911AddressUIResponse response=mapper.readValue(requestString,ValidateE911AddressUIResponse.class);
		Assert.assertNotNull(util2.handleValidateE911AddressResponseErrors(response));
	}
	
	@Test
	public void handleCrmRetrieveResponseErrorsFiveGHomeTest1() throws JsonMappingException, JsonProcessingException{
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		CrmRetrieveCartUIResponse response=mapper.readValue(requestString,CrmRetrieveCartUIResponse.class);
		Assert.assertNotNull(util2.handleCrmRetrieveResponseErrorsFiveGHome(response));
	}
	
	@Test
	public void handleGetPairedWatchesResponseErrorsTest1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		GetPairedDevicesUIResponse response=mapper.readValue(requestString,GetPairedDevicesUIResponse.class);
		Assert.assertNotNull(util2.handleGetPairedWatchesResponseErrors(response));
	}
	
	@Test
	public void setErrorCategoryTest() throws JsonMappingException, JsonProcessingException {
		String errCategory = "System error";
		String requestString = "{\"tradeInAdded\": true, \"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		ErrorResponse response= mapper.readValue(requestString,ErrorResponse.class);
		util.setErrorCategory(response,errCategory);
		response.setErrors(null);
		util.setErrorCategory(response,errCategory);
		response.setErrors(Collections.emptyList());
		util.setErrorCategory(response,errCategory);

		util.setErrorCategory((List<CartError>) null,errCategory);
		util.setErrorCategory(Collections.emptyList(),errCategory);
	}
	
	@Test
	public void addPlanAndDeviceResponseErrorsTest() throws JsonMappingException, JsonProcessingException {
		String responseString = "{\"errors\":null,\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"correlationId\":\"POE-D-e81378f9-d693-4234-802a-41019e24e4c3\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4346627-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\"},\"customerInfo\":{\"customerType\":\"N\",\"originalCreditApprovalNumber\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-e81378f9-d693-4234-802a-41019e24e4c3\",\"processingMTN\":\"\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"4221df0b-f63d-46f4-b59a-43edb32c8675\",\"statusMsg\":\"Save cart data updated successfully\",\"statusCode\":\"1\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"ShoppingCart\"]},{\"mtn\":\"\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"ShoppingCart\"]}]}}}}";
		AddPlanAndDeviceUIResponse  response=mapper.readValue(responseString,AddPlanAndDeviceUIResponse .class);
		Assert.assertNotNull(util2.addPlanAndDeviceResponseErrors(response));
	}
	
	@Test
	public void addPlanAndDeviceResponseErrorsTest1() throws JsonMappingException, JsonProcessingException {
		String responseString = "{\"errors\":[{\"errorSpec\":null,\"detailList\":null,\"nameSpace\":\"abc\",\"id\":\"234\"}],\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"correlationId\":\"POE-D-e81378f9-d693-4234-802a-41019e24e4c3\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4346627-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\"},\"customerInfo\":{\"customerType\":\"N\",\"originalCreditApprovalNumber\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-e81378f9-d693-4234-802a-41019e24e4c3\",\"processingMTN\":\"\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"4221df0b-f63d-46f4-b59a-43edb32c8675\",\"statusMsg\":\"Save cart data updated successfully\",\"statusCode\":\"1\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"ShoppingCart\"]},{\"mtn\":\"\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"ShoppingCart\"]}]}}}}";
		AddPlanAndDeviceUIResponse  response=mapper.readValue(responseString,AddPlanAndDeviceUIResponse .class);
		Assert.assertNotNull(util2.addPlanAndDeviceResponseErrors(response));
	}
	
	@Test
	public void handleManualDiscountResponseErrorsTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		UpdateManualDiscountUIResponse  response=mapper.readValue(requestString,UpdateManualDiscountUIResponse .class);
		Assert.assertNotNull(util2.handleManualDiscountResponseErrors(response));
	}
	
	@Test
	public void handleEffectiveDateResponseErrorsTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		UpdateEffectiveDateUIResponse  response=mapper.readValue(requestString,UpdateEffectiveDateUIResponse .class);
		Assert.assertNotNull(util2.handleEffectiveDateResponseErrors(response));
	}
	
	@Test
	public void handleCommonErrorFiveGFlowTest1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":[{\"errorSpec\":null,\"detailList\":null,\"nameSpace\":\"Failure\",\"id\":\"1004\",\"proactiveChatCustomMSG\":\"NetworkError\",\"proactiveChatIndicator\":\"yes\",\"details\":[{\"issue\":\"login issue\",\"field\":\"admin\",\"location\":\"E0987\",\"value\":\"07920\"}]}],\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		SOEErrorHolder response=mapper.readValue(requestString,SOEErrorHolder.class);
		util2.handleCommonErrorFiveGFlow(response);
	}
	
	@Test
	public void handleCommonErrorFiveGFlowTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":[{\"errorSpec\":null,\"detailList\":null,\"nameSpace\":\"Failure\",\"id\":\"1004\",\"proactiveChatCustomMSG\":\"NetworkError\",\"proactiveChatIndicator\":\"yes\",\"details\":[{\"issue\":null,\"field\":null,\"location\":null,\"value\":null}]}],\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		SOEErrorHolder response=mapper.readValue(requestString,SOEErrorHolder.class);
		util2.handleCommonErrorFiveGFlow(response);
	}

	@Test
	public void handleCrossChannelIdIssueTest() {
		CartError CartErrorObj = new CartError();
		CartErrorDetail CartErrorDetailObj = new CartErrorDetail();
		CartErrorObj.setId("1004");
		CartErrorDetailObj.setIssue("random");
		CartErrorObj.setDetailList(Arrays.asList(CartErrorDetailObj));
		CartPegaResponseErrorsUtil2.handleCrossChannelIdIssue(Arrays.asList(CartErrorObj));

		CartErrorObj.setId("random");
		CartPegaResponseErrorsUtil2.handleCrossChannelIdIssue(Arrays.asList(CartErrorObj));

		CartErrorObj.setDetailList(Collections.emptyList());
		CartPegaResponseErrorsUtil2.handleCrossChannelIdIssue(Arrays.asList(CartErrorObj));

		CartErrorObj.setDetailList(null);
		CartPegaResponseErrorsUtil2.handleCrossChannelIdIssue(Arrays.asList(CartErrorObj));

		ArrayList DetailList = new ArrayList();
		DetailList.add(null);
		CartErrorObj.setDetailList(DetailList);
		CartPegaResponseErrorsUtil2.handleCrossChannelIdIssue(Arrays.asList(CartErrorObj));

		ArrayList CartErrorObjArr = new ArrayList();
		CartErrorObjArr.add(null);
		CartPegaResponseErrorsUtil2.handleCrossChannelIdIssue(CartErrorObjArr);
		CartPegaResponseErrorsUtil2.handleCrossChannelIdIssue(Collections.emptyList());
		CartPegaResponseErrorsUtil2.handleCrossChannelIdIssue(new ArrayList<>());

	}

	@Test
	public void handleDeleteCartResponseErrorsTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"errors\":null,\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"ngdFlow\": true,\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		ClearCartUIResponse  response = mapper.readValue(requestString,ClearCartUIResponse   .class);
		Assert.assertNotNull(util.handleClearCartResponseErrors(response));
	}

}