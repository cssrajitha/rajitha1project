package onevz.soe.cart.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.helper.SetupAndGoHelper;
import onevz.soe.cart.requests.SUAGSelectionDetailsRequest;
import onevz.soe.cart.responses.SUAGSelectionDetailsUIResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = {CartServiceTestConfig.class})
public class SetupAndGoControllerTest {

    @InjectMocks
    private SetupAndGoController controller;

    @Mock
    private SetupAndGoHelper setupAndGoHelper;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    public void test_getSUAGSelection_success() throws JsonProcessingException {
        ServerHttpRequest serverHttpRequest = MockServerHttpRequest.post("http://localhost").build();
        String dummyResponse = "{\"data\":{\"suagDetails\":[{\"deviceItemCode\":\"MG6X3LL/A\",\"deviceItemDescription\":\"IPHONE 12 MINI 256 BLUE\",\"isMCESupportedDevice\":true,\"mtn\":\"9082105406\"},{\"deviceItemCode\":\"MG6X3LL/A\",\"deviceItemDescription\":\"IPHONE 12 MINI 256 BLUE\",\"isMCESupportedDevice\":false,\"mtn\":\"9082105407\"},{\"deviceItemCode\":\"MG6X3LL/A\",\"deviceItemDescription\":\"IPHONE 12 MINI 256 BLUE\",\"isMCESupportedDevice\":true,\"mtn\":\"9082105408\"}]}}";
        SUAGSelectionDetailsUIResponse responseData = objectMapper.readValue(dummyResponse, SUAGSelectionDetailsUIResponse.class);
        Mockito.when(setupAndGoHelper.getSUAGSelectionDetails()).thenReturn(Mono.just(responseData));
        SUAGSelectionDetailsRequest request = new SUAGSelectionDetailsRequest();
        Mono<SUAGSelectionDetailsUIResponse> response = controller.getSUAGDetails(serverHttpRequest,request);
        StepVerifier.create(response).assertNext(Assert::assertNotNull).verifyComplete();
    }

}
