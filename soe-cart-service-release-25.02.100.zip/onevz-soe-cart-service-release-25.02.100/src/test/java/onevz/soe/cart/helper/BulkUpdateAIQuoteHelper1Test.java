package onevz.soe.cart.helper;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.bulkcartupdate.*;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.bulkcartupdate.Line;
import onevz.soe.cart.model.retrieveCart.*;
import onevz.soe.cart.model.retrieveCart.ServiceInfo;
import onevz.soe.cart.model.tradeIn.appraiseDevice.DeviceOutInfo;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.customerprofile.model.gql.assisted.Address;
import onevz.soe.customerprofile.model.gql.assisted.*;
import onevz.soe.customerprofile.model.gql.assisted.BillAccount;
import onevz.soe.customerprofile.model.gql.assisted.PricePlanInfo;
import onevz.soe.customerprofile.response.CustomerProfileResponse;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.*;

import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@WebFluxTest(BulkUpdateAIQuoteHelper1.class)
public class BulkUpdateAIQuoteHelper1Test {

    @InjectMocks
    BulkUpdateAIQuoteHelper1 bulkUpdateHelper;


    @Test
    public void getVzdlDataForBulkUpdateTest() {
        BulkQuoteUIRequest request = new BulkQuoteUIRequest();
        BulkQuoteUIResponse response = new BulkQuoteUIResponse();
        Assert.assertNull(bulkUpdateHelper.getVzdlDataForBulkUpdate(null, null, new CartRedisData()));

        Assert.assertNull(bulkUpdateHelper.getVzdlDataForBulkUpdate(request, response, new CartRedisData()));

        request.setData(new CartData());
        bulkUpdateHelper.getVzdlDataForBulkUpdate(request, response, new CartRedisData());

        response.setServiceBody(new CreateBulkQuoteServiceBody());
        bulkUpdateHelper.getVzdlDataForBulkUpdate(request, response, new CartRedisData());

        request = new BulkQuoteUIRequest();
        bulkUpdateHelper.getVzdlDataForBulkUpdate(request, response, new CartRedisData());

        Assert.assertNotNull(request);
    }

    @Test
    public void populateVzdlDataForBulkUpdateTest() {
        BulkQuoteUIRequest request = new BulkQuoteUIRequest();
        BulkQuoteUIResponse response = new BulkQuoteUIResponse();
        CartRedisData cartRedisData = new CartRedisData();
        Assert.assertNull( bulkUpdateHelper.populateVzdlDataForBulkUpdate(request, response, new CartRedisData()));

        CreateBulkQuoteServiceBody serviceBody = new CreateBulkQuoteServiceBody();
        CreateBulkQuoteServiceResponse bulkQuoteResponse = new CreateBulkQuoteServiceResponse();
        CreateBulkQuoteContext context = new CreateBulkQuoteContext();
        CartServiceBulkCartInfo cartInfo = new CartServiceBulkCartInfo();
        context.setCartInfo(cartInfo);
        bulkQuoteResponse.setContext(context);
        serviceBody.setServiceResponse(bulkQuoteResponse);
        response.setServiceBody(serviceBody);

        CartData data = new CartData();
        request.setData(data);
        Assert.assertNull(bulkUpdateHelper.populateVzdlDataForBulkUpdate(request, response, cartRedisData));

        Line[] lines = new Line[2];
        response.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(lines);
        Assert.assertNull(bulkUpdateHelper.populateVzdlDataForBulkUpdate(request, response, cartRedisData));

        Lines[] reqLine = new Lines[2];
        request.getData().setLines(Arrays.asList(reqLine));
        Assert.assertNull(bulkUpdateHelper.populateVzdlDataForBulkUpdate(request, response, cartRedisData));

        lines[0] = new Line();
        Line line1 = new Line();
        lines[1] = line1;
        response.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(lines);
        Assert.assertNull(bulkUpdateHelper.populateVzdlDataForBulkUpdate(request, response, cartRedisData));

        Lines[] reqLine2 = new Lines[1];
        Lines lines1 = new Lines();
        lines1.setMtn("9988776655");
        Device device = new Device();
        device.setId("1");
        device.setDiscountAmount("$75");
        device.setSkuId("skuId");
        device.setSkuDisplayName("Iphone 16 Pro");
        device.setItemPrice("$1150");
        lines1.setDevice(device);
        List<Feature> featureList = new ArrayList<>();
        Feature feature = new Feature();
        feature.setId("spo1");
        featureList.add(feature);
        lines1.setAddFeatures(featureList);
        reqLine2[0] = lines1;
        CartRedisData rr = null;
        rr = new CartRedisData();
        CustomerProfileResponse customerProfileResponse = new CustomerProfileResponse();
        List<BillAccount> billAccountList = new ArrayList<>();
        BillAccount billAccount = new BillAccount();
        Mtn mtn = new Mtn();
        mtn.setMtn("9988776655");
        mtn.setMtnHashCode("12345678987654321");
        List<Mtn> mtnList = new ArrayList<>();
        mtnList.add(mtn);
        billAccount.setMtns(mtnList);
        billAccountList.add(billAccount);
        Data data1 = new Data();
        Customer customer = new Customer();
        customer.setBillAccounts(billAccountList);
        data1.setCustomer(customer);
        customerProfileResponse.setData(data1);
        rr.setCustomerProfile(customerProfileResponse);
        Address address = new Address();
        rr.getCustomerProfile().getData().getCustomer().setAddress(address);
        Line[] lines2 = new Line[1];
        Line line2 = new Line();
        line2.setMtn("9988776655");
        line2.setDevice(device);
        ConflictedSPO[] conflictedSPOS =  new ConflictedSPO[1];
        ConflictedSPO conflictedSPO = new ConflictedSPO();
        conflictedSPO.setId("spo1");
        conflictedSPO.setPrice("$150");
        conflictedSPO.setActionIndicator("A");
        conflictedSPO.setSkuId("skuId");
        conflictedSPOS[0] = conflictedSPO;
        line2.setSpos(conflictedSPOS);
        lines2[0] = line2;
        CartInfo cartInfo1 = new CartInfo();
        cartInfo1.setSessionId("Session-1");
        request.setCartInfo(cartInfo1);
        response.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(lines2);
        request.getData().setLines(Arrays.asList(reqLine2));
        Assert.assertNotNull(bulkUpdateHelper.populateVzdlDataForBulkUpdate(request, response, rr));

        request.getData().setLines(null);
        response.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(null);
        Assert.assertNull(bulkUpdateHelper.populateVzdlDataForBulkUpdate(request, response, cartRedisData));

        Assert.assertNotNull(request);
    }

    @Test
    public void populateVzdlDataForBulkUpdateTest1() {
        BulkQuoteUIRequest request = new BulkQuoteUIRequest();
        BulkQuoteUIResponse response = new BulkQuoteUIResponse();
        CartRedisData cartRedisData = new CartRedisData();
        Assert.assertNull( bulkUpdateHelper.populateVzdlDataForBulkUpdate(request, response, new CartRedisData()));

        CreateBulkQuoteServiceBody serviceBody = new CreateBulkQuoteServiceBody();
        CreateBulkQuoteServiceResponse bulkQuoteResponse = new CreateBulkQuoteServiceResponse();
        CreateBulkQuoteContext context = new CreateBulkQuoteContext();
        CartServiceBulkCartInfo cartInfo = new CartServiceBulkCartInfo();
        context.setCartInfo(cartInfo);
        bulkQuoteResponse.setContext(context);
        serviceBody.setServiceResponse(bulkQuoteResponse);
        response.setServiceBody(serviceBody);

        CartData data = new CartData();
        request.setData(data);
        Assert.assertNull(bulkUpdateHelper.populateVzdlDataForBulkUpdate(request, response, cartRedisData));

        Line[] lines = new Line[2];
        response.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(lines);
        Assert.assertNull(bulkUpdateHelper.populateVzdlDataForBulkUpdate(request, response, cartRedisData));

        Lines[] reqLine = new Lines[2];
        request.getData().setLines(Arrays.asList(reqLine));
        Assert.assertNull(bulkUpdateHelper.populateVzdlDataForBulkUpdate(request, response, cartRedisData));

        lines[0] = new Line();
        Line line1 = new Line();
        lines[1] = line1;
        response.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(lines);
        Assert.assertNull(bulkUpdateHelper.populateVzdlDataForBulkUpdate(request, response, cartRedisData));

        Lines[] reqLine2 = new Lines[1];
        Lines lines1 = new Lines();
        lines1.setMtn("9988776655");
        Device device = new Device();
        device.setId("1");
        device.setDiscountAmount("");
        device.setSkuId("");
        device.setSkuDisplayName("");
        device.setItemPrice("");
        lines1.setDevice(device);
        List<Feature> featureList = new ArrayList<>();
        Feature feature = new Feature();
        feature.setId("spo1");
        featureList.add(feature);
        lines1.setAddFeatures(featureList);
        reqLine2[0] = lines1;
        CartRedisData rr = null;
        rr = new CartRedisData();
        CustomerProfileResponse customerProfileResponse = new CustomerProfileResponse();
        List<BillAccount> billAccountList = new ArrayList<>();
        BillAccount billAccount = new BillAccount();
        Mtn mtn = new Mtn();
        mtn.setMtn("9988776655");
        mtn.setMtnHashCode("12345678987654321");
        List<Mtn> mtnList = new ArrayList<>();
        mtnList.add(mtn);
        billAccount.setMtns(mtnList);
        billAccountList.add(billAccount);
        Data data1 = new Data();
        Customer customer = new Customer();
        customer.setBillAccounts(billAccountList);
        data1.setCustomer(customer);
        customerProfileResponse.setData(data1);
        rr.setCustomerProfile(customerProfileResponse);
        Address address = new Address();
        rr.getCustomerProfile().getData().getCustomer().setAddress(address);
        Line[] lines2 = new Line[1];
        Line line2 = new Line();
        line2.setMtn("9988776655");
        line2.setDevice(device);
        ConflictedSPO[] conflictedSPOS =  new ConflictedSPO[1];
        ConflictedSPO conflictedSPO = new ConflictedSPO();
        conflictedSPO.setId("spo1");
        conflictedSPO.setPrice("0.00");
        conflictedSPO.setActionIndicator("");
        conflictedSPO.setSkuId("");
        conflictedSPOS[0] = conflictedSPO;
        line2.setSpos(conflictedSPOS);
        lines2[0] = line2;
        CartInfo cartInfo1 = new CartInfo();
        cartInfo1.setSessionId("Session-1");
        request.setCartInfo(cartInfo1);
        response.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(lines2);
        request.getData().setLines(Arrays.asList(reqLine2));
        Assert.assertNotNull(bulkUpdateHelper.populateVzdlDataForBulkUpdate(request, response, rr));

        request.getData().setLines(null);
        response.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(null);
        Assert.assertNull(bulkUpdateHelper.populateVzdlDataForBulkUpdate(request, response, cartRedisData));

        Assert.assertNotNull(request);
    }

    @Test
    public void populateVzdlDataForBulkUpdateTest2() {
        BulkQuoteUIRequest request = new BulkQuoteUIRequest();
        BulkQuoteUIResponse response = new BulkQuoteUIResponse();
        CartRedisData cartRedisData = new CartRedisData();
        Assert.assertNull((bulkUpdateHelper.populateVzdlDataForBulkUpdate(request, response, cartRedisData)));

        CreateBulkQuoteServiceBody serviceBody = new CreateBulkQuoteServiceBody();
        CreateBulkQuoteServiceResponse bulkQuoteServiceResponse = new CreateBulkQuoteServiceResponse();
        CreateBulkQuoteContext context = new CreateBulkQuoteContext();
        CartServiceBulkCartInfo cartInfo = new CartServiceBulkCartInfo();
        context.setCartInfo(cartInfo);
        bulkQuoteServiceResponse.setContext(context);
        serviceBody.setServiceResponse(bulkQuoteServiceResponse);
        response.setServiceBody(serviceBody);

        CartData data = new CartData();
        request.setData(data);
        Assert.assertNull(bulkUpdateHelper.populateVzdlDataForBulkUpdate(request, response, cartRedisData));

        response.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(null);
        Assert.assertNull(bulkUpdateHelper.populateVzdlDataForBulkUpdate(request, response, cartRedisData));

        List<onevz.soe.cart.model.bulkcartupdate.Line> lineList= new ArrayList<>();
        onevz.soe.cart.model.bulkcartupdate.Line[] lineArr= new onevz.soe.cart.model.bulkcartupdate.Line[lineList.size()];
        lineList.toArray(lineArr);
        response.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(lineArr);
        Assert.assertNull(bulkUpdateHelper.populateVzdlDataForBulkUpdate(request, response, cartRedisData));

        lineList= new ArrayList<>();
        lineList.add(new onevz.soe.cart.model.bulkcartupdate.Line());
        lineArr= new onevz.soe.cart.model.bulkcartupdate.Line[lineList.size()];
        lineList.toArray(lineArr);
        response.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(lineArr);
        Assert.assertNull(bulkUpdateHelper.populateVzdlDataForBulkUpdate(request, response, cartRedisData));

        onevz.soe.cart.model.bulkcartupdate.Line[] lines = new onevz.soe.cart.model.bulkcartupdate.Line[2];
        response.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(lines);
        Assert.assertNull(bulkUpdateHelper.populateVzdlDataForBulkUpdate(request, response, cartRedisData));

        onevz.soe.cart.model.bulkcartupdate.Lines[] linesArr= new onevz.soe.cart.model.bulkcartupdate.Lines[0];
        request.getData().setLines(Arrays.asList(linesArr));
        Assert.assertNull(bulkUpdateHelper.populateVzdlDataForBulkUpdate(request, response, cartRedisData));

        List<onevz.soe.cart.model.bulkcartupdate.Lines> linesList= new ArrayList<>();
        linesList.add(null);
        linesList.add(new onevz.soe.cart.model.bulkcartupdate.Lines());
        linesArr= new onevz.soe.cart.model.bulkcartupdate.Lines[linesList.size()];
        linesList.toArray(linesArr);
        request.getData().setLines(Arrays.asList(linesArr));
        Assert.assertNull(bulkUpdateHelper.populateVzdlDataForBulkUpdate(request, response, cartRedisData));

        onevz.soe.cart.model.bulkcartupdate.Lines[] reqLine = new onevz.soe.cart.model.bulkcartupdate.Lines[2];
        request.getData().setLines(Arrays.asList(reqLine));
        Assert.assertNull(bulkUpdateHelper.populateVzdlDataForBulkUpdate(request, response, cartRedisData));

        lines[0] = new onevz.soe.cart.model.bulkcartupdate.Line();
        onevz.soe.cart.model.bulkcartupdate.Line line1= new onevz.soe.cart.model.bulkcartupdate.Line();
        lines[1]= line1;
        response.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(lines);
        Assert.assertNull(bulkUpdateHelper.populateVzdlDataForBulkUpdate(request, response, cartRedisData));

        reqLine[0] = new onevz.soe.cart.model.bulkcartupdate.Lines();
        onevz.soe.cart.model.bulkcartupdate.Lines lines1= new onevz.soe.cart.model.bulkcartupdate.Lines();
        reqLine[1]= lines1;
        request.getData().setLines(Arrays.asList(reqLine));
        Assert.assertNotNull(bulkUpdateHelper.populateVzdlDataForBulkUpdate(request, response, cartRedisData));

        Assert.assertNotNull(request);
    }

    @Test
    public void updateUserDataTest() {
        Vzdl vzdl = new Vzdl();
        CartRedisData rr = null;
        BulkQuoteUIRequest request = new BulkQuoteUIRequest();
        bulkUpdateHelper.updateUserData(vzdl, rr, request);

        onevz.soe.cart.model.bulkcartupdate.CartInfo cartInfo = new onevz.soe.cart.model.bulkcartupdate.CartInfo();
        cartInfo.setSessionId("12345");
        request.setCartInfo(cartInfo);
        rr = new CartRedisData();
        rr.setCustomerProfile(null);
        bulkUpdateHelper.updateUserData(vzdl, rr, request);

        rr.setCustomerProfile(new CustomerProfileResponse());
        rr.getCustomerProfile().setData(null);
        bulkUpdateHelper.updateUserData(vzdl, rr, request);

        rr.getCustomerProfile().setData(new Data());
        rr.getCustomerProfile().getData().setCustomer(null);
        bulkUpdateHelper.updateUserData(vzdl, rr, request);

        rr.getCustomerProfile().getData().setCustomer(new Customer());
        rr.getCustomerProfile().getData().getCustomer().setBillAccounts(null);
        rr.getCustomerProfile().getData().getCustomer().setCustomerName(null);
        rr.getCustomerProfile().getData().getCustomer().setCustomerAttributes(null);
        rr.getCustomerProfile().getData().getCustomer().setIsSalesRepIdMismatch(null);
        rr.getCustomerProfile().getData().getCustomer().setIsComboOrderAllowed(null);
        bulkUpdateHelper.updateUserData(vzdl, rr, request);

        rr.getCustomerProfile().getData().setCustomer(new Customer());
        rr.getCustomerProfile().getData().getCustomer().setCustomerHash("");
        rr.getCustomerProfile().getData().getCustomer().setAccountNo("");
        rr.getCustomerProfile().getData().getCustomer().setBillAccounts(new ArrayList<>());
        bulkUpdateHelper.updateUserData(vzdl, rr, request);

        rr.getCustomerProfile().getData().getCustomer().setCustomerHash("123");
        rr.getCustomerProfile().getData().getCustomer().setAccountNo("1234-000");
        rr.getCustomerProfile().getData().getCustomer().setLookupMtn("678");
        Address address = new Address();
        rr.getCustomerProfile().getData().getCustomer().setAddress(address);
        bulkUpdateHelper.updateUserData(vzdl, rr, request);

        address.setZipCode("1234");
        rr.getCustomerProfile().getData().getCustomer().setAddress(address);
        BillAccount billAccount = new BillAccount();
        billAccount.setMtns(null);
        List<BillAccount> accounts = new ArrayList<>();
        accounts.add(billAccount);
        accounts.add(null);
        bulkUpdateHelper.updateUserData(vzdl, rr, request);

        BillAccount billAccount1 = new BillAccount();
        Mtn mtn = new Mtn();
        List<Mtn> mtns = new ArrayList<>();
        mtns.add(new Mtn());
        mtns.add(mtn);

        mtn.setMtn("678");
        mtn.setPricePlanInfo(new PricePlanInfo());
        mtns.add(mtn);
        Mtn mtn1 = new Mtn();
        PricePlanInfo pricePlanInfo = new PricePlanInfo();
        pricePlanInfo.setDescription("Test");
        mtn1.setMtn("123");
        mtn1.setPricePlanInfo(pricePlanInfo);
        mtns.add(mtn1);
        billAccount1.setMtns(mtns);
        accounts.add(billAccount1);
        rr.getCustomerProfile().getData().getCustomer().setBillAccounts(accounts);
        bulkUpdateHelper.updateUserData(vzdl, rr, request);
        Assert.assertNotNull(vzdl.getUser());

        rr.getCustomerProfile().getData().getCustomer().getAddress().setZipCode("");
        bulkUpdateHelper.updateUserData(vzdl, rr, request);

        rr.getCustomerProfile().getData().getCustomer().getAddress().setZipCode(null);
        bulkUpdateHelper.updateUserData(vzdl, rr, request);

        Customer customer = new Customer();
        customer.setAddress(null);
        rr.getCustomerProfile().getData().getCustomer().setAddress(null);
        bulkUpdateHelper.updateUserData(vzdl, rr, request);

        billAccount1.setMtns(null);
        accounts.add(billAccount1);
        rr.getCustomerProfile().getData().getCustomer().setBillAccounts(accounts);
        bulkUpdateHelper.updateUserData(vzdl, rr, request);

        Assert.assertNotNull(request);
    }

    @Test
    public void updatePageDataTest() {
        Vzdl vzdl = new Vzdl();
        BulkQuoteUIRequest request = new BulkQuoteUIRequest();
        bulkUpdateHelper.updatePageData(vzdl, request);

        CartInfo cartInfo = new CartInfo();
        request.setCartInfo(cartInfo);
        bulkUpdateHelper.updatePageData(vzdl, request);

        request.getCartInfo().setSessionId("");
        request.setChannelId(null);
        request.getCartInfo().setIntendType("");
        request.getCartInfo().setCaseId("");
        request.getCartInfo().setCartId("");
        bulkUpdateHelper.updatePageData(vzdl, request);
        Assert.assertNotNull(vzdl.getPage());

        request.getCartInfo().setSessionId("123456789");
        request.getCartInfo().setIntendType("NSE");
        request.getCartInfo().setCaseId("caseId");
        request.getCartInfo().setCartId("cartId");
        request.setChannelId("");
        bulkUpdateHelper.updatePageData(vzdl, request);
        Assert.assertNotNull(vzdl.getPage());

        request.setChannelId(CartConstants.RETAIL);
        bulkUpdateHelper.updatePageData(vzdl, request);

        request.setChannelId(CartConstants.RETAIL_IPAD);
        bulkUpdateHelper.updatePageData(vzdl, request);

        request.setChannelId(CartConstants.OMNI_TELESALES);
        bulkUpdateHelper.updatePageData(vzdl, request);

        Assert.assertNotNull(request);
    }

    @Test
    public void updateTxnDataTest() {
        Vzdl vzdl = new Vzdl();
        CartRedisData rr = null;
        BulkQuoteUIRequest request = new BulkQuoteUIRequest();
        Optional<CartServiceBulkCartInfo> cartInfo = Optional.empty();
        bulkUpdateHelper.updateTxnData(vzdl, rr, request, cartInfo);
        Assert.assertTrue(vzdl.getTxn().isEmpty());

        rr = new CartRedisData();
        bulkUpdateHelper.updateTxnData(vzdl, rr, request, cartInfo);

        CartServiceBulkCartInfo cartServiceCartInfo = new CartServiceBulkCartInfo();
        cartInfo = Optional.of(cartServiceCartInfo);
        request.setCartInfo(new CartInfo());
        request.getCartInfo().setIntendType(null);
        bulkUpdateHelper.updateTxnData(vzdl, rr, request, cartInfo);

        cartServiceCartInfo.setCartId("");
        cartInfo = Optional.of(cartServiceCartInfo);
        request.getCartInfo().setIntendType("");
        bulkUpdateHelper.updateTxnData(vzdl, rr, request, cartInfo);

        rr.setAutoPayEnrolled("");
        rr.setRepId("");
        rr.setLocationCode("");
        rr.setAgentRole("");
        bulkUpdateHelper.updateTxnData(vzdl, rr, request, cartInfo);

        cartServiceCartInfo.setCartId("cartId");
        cartInfo = Optional.of(cartServiceCartInfo);
        rr.setAutoPayEnrolled("123");
        rr.setAgentRole("ENC-123");
        rr.setRepId("ENC");
        rr.setLocationCode("1234");
        request.getCartInfo().setIntendType("NSE");
        bulkUpdateHelper.updateTxnData(vzdl, rr, request, cartInfo);

        Assert.assertNotNull(request);
    }

    @Test
    public void updateProductDataForBulkUpdateTest() {
        Vzdl vzdl = new Vzdl();
        CartRedisData rr = null;
        BulkQuoteUIRequest request = new BulkQuoteUIRequest();
        request.setData(new CartData());
        Optional<Lines> requestLines = Optional.empty();
        rr = new CartRedisData();
        Lines[] reqLine = new Lines[1];
        Lines lines = new Lines();
        reqLine[0] = lines;
        request.getData().setLines(Arrays.asList(reqLine));

        CartServiceBulkCartInfo cartInfo = new CartServiceBulkCartInfo();

        bulkUpdateHelper.updateProductDataForBulkUpdate(vzdl, rr, request, requestLines, Optional.empty());
        Assert.assertNotNull(vzdl.getProduct());

        rr.setCustomerProfile(new CustomerProfileResponse());
        reqLine[0] = null;
        request.getData().setLines(Arrays.asList(reqLine));
        bulkUpdateHelper.updateProductDataForBulkUpdate(vzdl, rr, request, requestLines, Optional.empty());

        Data data = new Data();
        data.setCustomer(new Customer());
        List<BillAccount> billAccounts = new ArrayList<>();
        Mtn mtn = new Mtn();
        mtn.setMtn("123");
        mtn.setPricePlanInfo(new PricePlanInfo());
        Mtn mtn1 = new Mtn();
        mtn1.setMtn("123");
        PricePlanInfo pricePlanInfo = new PricePlanInfo();
        pricePlanInfo.setDescription("");
        mtn1.setPricePlanInfo(pricePlanInfo);
        mtn1.setMtnHashCode("");
        Mtn mtn2 = new Mtn();
        mtn2.setMtn("123");
        pricePlanInfo.setDescription("123457");
        pricePlanInfo.setPlanId("097");
        mtn2.setPricePlanInfo(pricePlanInfo);
        mtn2.setMtnHashCode("aec");
        List<Mtn> mtns = new ArrayList<>();
        Mtn mtn3 = new Mtn();
        mtn3.setMtn("");
        Mtn mtn4 = new Mtn();
        mtns.add(new Mtn());
        Mtn mtn5 = new Mtn();
        mtn5.setMtn("123");
        mtn5.setMtnHashCode("");
        mtns.add(mtn);
        mtns.add(mtn1);
        mtns.add(mtn2);
        mtns.add(mtn3);
        mtns.add(mtn4);
        mtns.add(mtn5);
        BillAccount billAccount = new BillAccount();
        billAccount.setMtns(mtns);
        billAccounts.add(billAccount);
        billAccounts.add(null);
        data.getCustomer().setBillAccounts(billAccounts);
        rr.getCustomerProfile().setData(data);
        Device device = new Device();
        device.setId("1");
        device.setDiscountAmount("$75");
        device.setSku("skuId");
        device.setSkuDisplayName("Iphone 16 Pro");
        device.setItemPrice("$1200");
        reqLine = new Lines[3];
        Lines line = new Lines();
        line.setMtn("123");
        reqLine[0] = line;
        line.setPlan(new Plan());
        line.setAddFeatures(new ArrayList<>());
        line.setNewLineOrAAL(true);
        reqLine[1] = line;
        line.getPlan().setId("abc");
        line.getPlan().setPath(null);
        Feature feature = new Feature();
        List<Feature> features = new ArrayList<>();
        features.add(null);
        features.add(feature);
        feature.setId("spo1");
        features.add(feature);
        line.setAddFeatures(features);
        reqLine[2] = line;
        request.getData().setLines(Arrays.asList(reqLine));
        request.getData().getLines().get(0).setPlan(new Plan());
        request.getData().getLines().get(0).getPlan().setPath("path for the plan");
        requestLines = Optional.of(reqLine[0]);
        bulkUpdateHelper.updateProductDataForBulkUpdate(vzdl, rr, request, requestLines, Optional.empty());

        line.setPlan(new Plan());
        line.getPlan().setPropId("propId");
        line.setAddFeatures(new ArrayList<>());
        reqLine = new Lines[1];
        line.setIsNewLine(false);
        reqLine[0] = line;
        request.getData().setLines(Arrays.asList(reqLine));
        bulkUpdateHelper.updateProductDataForBulkUpdate(vzdl, rr, request, requestLines, Optional.of(cartInfo));

        line.setNewLineOrAAL(true);
        line.getPlan().setId("");
        line.getPlan().setPath("");
        line.setDevice(device);
        reqLine[0] = line;
        request.getData().setLines(Arrays.asList(reqLine));
        Line[] respLine = new Line[2];
        cartInfo.setLines(respLine);
        bulkUpdateHelper.updateProductDataForBulkUpdate(vzdl, rr, request, requestLines, Optional.of(cartInfo));

        line.getPlan().setId("abc");
        line.getPlan().setPath(null);
        reqLine[0] = line;
        request.getData().setLines(Arrays.asList(reqLine));
        Line[] lines1 = new Line[2];
        lines1[0] = null;
        Line line1 = new Line();
        lines1[1] = line1;
        respLine[0] = null;
        respLine[1] = new Line();
        cartInfo.setLines(respLine);
        bulkUpdateHelper.updateProductDataForBulkUpdate(vzdl, rr, request, requestLines, Optional.of(cartInfo));

        line.getPlan().setPath("plans page");
        reqLine[0] = line;
        request.getData().setLines(Arrays.asList(reqLine));
        bulkUpdateHelper.updateProductDataForBulkUpdate(vzdl, rr, request, requestLines, Optional.of(cartInfo));

        Line respLine1 = new Line();
        respLine1.setMtn("");
        respLine[0] = respLine1;
        respLine1.setMtn("123");
        respLine[1] = respLine1;
        cartInfo.setLines(respLine);
        bulkUpdateHelper.updateProductDataForBulkUpdate(vzdl, rr, request, requestLines, Optional.of(cartInfo));

        respLine1.setPlan(new Plan());
        respLine = new Line[1];
        respLine[0] = respLine1;
        cartInfo.setLines(respLine);
        bulkUpdateHelper.updateProductDataForBulkUpdate(vzdl, rr, request, requestLines, Optional.of(cartInfo));

        respLine1.getPlan().setId("");
        respLine[0] = respLine1;
        cartInfo.setLines(respLine);
        bulkUpdateHelper.updateProductDataForBulkUpdate(vzdl, rr, request, requestLines, Optional.of(cartInfo));

        respLine1.getPlan().setId(null);
        respLine[0] = respLine1;
        cartInfo.setLines(respLine);
        bulkUpdateHelper.updateProductDataForBulkUpdate(vzdl, rr, request, requestLines, Optional.of(cartInfo));

        respLine1.getPlan().setId("abc");
        respLine1.getPlan().setDiscountedPrice(null);
        respLine1.getPlan().setPrice("25");
        respLine[0] = respLine1;
        cartInfo.setLines(respLine);
        bulkUpdateHelper.updateProductDataForBulkUpdate(vzdl, rr, request, requestLines, Optional.of(cartInfo));

        respLine1.getPlan().setDiscountedPrice("");
        respLine1.getPlan().setPrice("0.00");
        respLine[0] = respLine1;
        cartInfo.setLines(respLine);
        bulkUpdateHelper.updateProductDataForBulkUpdate(vzdl, rr, request, requestLines, Optional.of(cartInfo));

        respLine1.getPlan().setDiscountedPrice("20");
        respLine[0] = respLine1;
        cartInfo.setLines(respLine);
        bulkUpdateHelper.updateProductDataForBulkUpdate(vzdl, rr, request, requestLines, Optional.of(cartInfo));

        respLine1.setSpos(new ConflictedSPO[1]);
        respLine[0] = respLine1;
        cartInfo.setLines(respLine);
        bulkUpdateHelper.updateProductDataForBulkUpdate(vzdl, rr, request, requestLines, Optional.of(cartInfo));

        ConflictedSPO spo = new ConflictedSPO();
        spo.setId("spo1");
        ConflictedSPO[] spos = new ConflictedSPO[4];
        spos[0] = spo;
        spo.setId("");
        spos[1] = spo;
        spo.setId(null);
        spos[2] = spo;
        spos[3] = null;
        respLine1.setSpos(spos);
        respLine[0] = respLine1;
        cartInfo.setLines(respLine);
        bulkUpdateHelper.updateProductDataForBulkUpdate(vzdl, rr, request, requestLines, Optional.of(cartInfo));

        request.getData().getLines().get(0).setDevice(null);
        bulkUpdateHelper.updateProductDataForBulkUpdate(vzdl, rr, request, requestLines, Optional.of(cartInfo));

        request.getData().getLines().get(0).getPlan().setPath("Plans page");
        bulkUpdateHelper.updateProductDataForBulkUpdate(vzdl, rr, request, requestLines, Optional.of(cartInfo));

        request.getData().getLines().get(0).setPlan(new Plan());
        request.getData().getLines().get(0).getPlan().setPath(null);
        bulkUpdateHelper.updateProductDataForBulkUpdate(vzdl, rr, request, requestLines, Optional.of(cartInfo));

        request.getData().getLines().get(0).getPlan().setPath("");
        bulkUpdateHelper.updateProductDataForBulkUpdate(vzdl, rr, request, requestLines, Optional.of(cartInfo));

        Assert.assertNotNull(request);
    }

    @Test
    public void updateProductDataForBulkUpdateTest1() {
        Vzdl vzdl = new Vzdl();
        CartRedisData rr = new CartRedisData();
        BulkQuoteUIRequest request = new BulkQuoteUIRequest();
        request.setData(new CartData());
        onevz.soe.cart.model.bulkcartupdate.Lines[] requestLine = new onevz.soe.cart.model.bulkcartupdate.Lines[1];
        onevz.soe.cart.model.bulkcartupdate.Lines lines = new onevz.soe.cart.model.bulkcartupdate.Lines();

        lines.setMtn("123");
        lines.setDevice(null);
        requestLine[0] = lines;
        request.getData().setLines(Arrays.asList(requestLine));
        bulkUpdateHelper.updateProductDataForBulkUpdate(vzdl, rr, request, Optional.of(requestLine[0]), Optional.empty());

        lines = new onevz.soe.cart.model.bulkcartupdate.Lines();
        lines.setMtn("123");
        lines.setDevice(new Device());
        lines.getDevice().setId(null);
        requestLine[0] = lines;
        request.getData().setLines(Arrays.asList(requestLine));
        bulkUpdateHelper.updateProductDataForBulkUpdate(vzdl, rr, request, Optional.of(requestLine[0]), Optional.empty());

        lines = new onevz.soe.cart.model.bulkcartupdate.Lines();
        requestLine = new onevz.soe.cart.model.bulkcartupdate.Lines[1];
        lines.setPlan(new Plan());
        lines.setAddFeatures(new ArrayList<>());
        Device device = new Device();
        device.setId("device");
        Feature feature = new Feature();
        feature.setId("feature");
        lines.setDevice(device);
        lines.getPlan().setId("plan");
        lines.getAddFeatures().add(feature);
        requestLine[0] = lines;
        request.getData().setLines(Arrays.asList(requestLine));

        Optional<CartServiceBulkCartInfo> cartInfo = Optional.empty();
        bulkUpdateHelper.updateProductDataForBulkUpdate(vzdl, rr, request, Optional.of(requestLine[0]), cartInfo);

        CartServiceBulkCartInfo cartInfo1 = new CartServiceBulkCartInfo();
        cartInfo1.setLines(null);
        bulkUpdateHelper.updateProductDataForBulkUpdate(vzdl, rr, request, Optional.of(requestLine[0]), Optional.of(cartInfo1));

        onevz.soe.cart.model.bulkcartupdate.Line[] respLine = new onevz.soe.cart.model.bulkcartupdate.Line[1];
        respLine[0] = null;
        cartInfo1.setLines(respLine);
        bulkUpdateHelper.updateProductDataForBulkUpdate(vzdl, rr, request, Optional.of(requestLine[0]), Optional.of(cartInfo1));

        lines.setMtn("123");
        requestLine[0] = lines;
        respLine = new onevz.soe.cart.model.bulkcartupdate.Line[1];
        onevz.soe.cart.model.bulkcartupdate.Line line = new onevz.soe.cart.model.bulkcartupdate.Line();
        line.setMtn("456");
        respLine[0] = line;
        cartInfo1.setLines(respLine);
        bulkUpdateHelper.updateProductDataForBulkUpdate(vzdl, rr, request, Optional.of(requestLine[0]), Optional.of(cartInfo1));

        respLine = new onevz.soe.cart.model.bulkcartupdate.Line[1];
        line = new onevz.soe.cart.model.bulkcartupdate.Line();
        line.setMtn("123");
        line.setDevice(null);
        line.setPlan(null);
        line.setSpos(null);
        respLine[0] = line;
        cartInfo1.setLines(respLine);
        bulkUpdateHelper.updateProductDataForBulkUpdate(vzdl, rr, request, Optional.of(requestLine[0]), Optional.of(cartInfo1));

        ConflictedSPO[] spoArray = new ConflictedSPO[1];
        spoArray[0] = null;
        line.setSpos(spoArray);
        bulkUpdateHelper.updateProductDataForBulkUpdate(vzdl, rr, request, Optional.of(requestLine[0]), Optional.of(cartInfo1));

        spoArray = new ConflictedSPO[1];
        ConflictedSPO spo = new ConflictedSPO();
        spo.setId(null);
        spoArray[0] = spo;
        respLine = new onevz.soe.cart.model.bulkcartupdate.Line[1];
        line = new onevz.soe.cart.model.bulkcartupdate.Line();
        line.setMtn("123");
        line.setDevice(new Device());
        line.getDevice().setId(null);
        line.setPlan(new Plan());
        line.getPlan().setId(null);
        line.setSpos(spoArray);
        respLine[0] = line;
        cartInfo1.setLines(respLine);
        bulkUpdateHelper.updateProductDataForBulkUpdate(vzdl, rr, request, Optional.of(requestLine[0]), Optional.of(cartInfo1));

        spoArray = new ConflictedSPO[1];
        spo = new ConflictedSPO();
        spo.setId("spo");
        spoArray[0] = spo;
        respLine = new onevz.soe.cart.model.bulkcartupdate.Line[1];
        line = new onevz.soe.cart.model.bulkcartupdate.Line();
        line.setMtn("123");
        line.setDevice(new Device());
        line.getDevice().setId("device1");
        line.setPlan(new Plan());
        line.getPlan().setId("plan1");
        line.setSpos(spoArray);
        respLine[0] = line;
        cartInfo1.setLines(respLine);
        bulkUpdateHelper.updateProductDataForBulkUpdate(vzdl, rr, request, Optional.of(requestLine[0]), Optional.of(cartInfo1));

        spoArray = new ConflictedSPO[1];
        spo = new ConflictedSPO();
        spo.setId("feature");
        spoArray[0] = spo;
        respLine = new onevz.soe.cart.model.bulkcartupdate.Line[1];
        line = new onevz.soe.cart.model.bulkcartupdate.Line();
        line.setMtn("123");
        line.setDevice(new Device());
        line.getDevice().setId("device");
        line.setPlan(new Plan());
        line.getPlan().setId("plan");
        line.getPlan().setName("plan name");
        line.setSpos(spoArray);
        respLine[0] = line;
        cartInfo1.setLines(respLine);
        bulkUpdateHelper.updateProductDataForBulkUpdate(vzdl, rr, request, Optional.of(requestLine[0]), Optional.of(cartInfo1));

        respLine = new onevz.soe.cart.model.bulkcartupdate.Line[1];
        line.getPlan().setName(null);
        respLine[0] = line;
        cartInfo1.setLines(respLine);
        bulkUpdateHelper.updateProductDataForBulkUpdate(vzdl, rr, request, Optional.of(requestLine[0]), Optional.of(cartInfo1));

        Assert.assertNotNull(request);
    }

    @Test
    public void updateEventTest() {
        Vzdl vzdl = new Vzdl();
        CartRedisData rr = null;
        bulkUpdateHelper.updateEvent(vzdl);

        rr = new CartRedisData();
        bulkUpdateHelper.updateEvent(vzdl);

        rr.setRetrieveCart(new CXPRetrieveCartDataVO());
        bulkUpdateHelper.updateEvent(vzdl);

        rr.getRetrieveCart().setCart(new CXPCartVO());
        bulkUpdateHelper.updateEvent(vzdl);

        rr.getRetrieveCart().getCart().setLineDetails(new CXPLineDetailsVO());
        bulkUpdateHelper.updateEvent(vzdl);

        rr.getRetrieveCart().getCart().getLineDetails().setLineInfo(null);
        rr.getRetrieveCart().getCart().getLineDetails().setNumOfAccessoryAndDeviceItemsInCart(null);
        bulkUpdateHelper.updateEvent(vzdl);

        rr.getRetrieveCart().getCart().getLineDetails().setLineInfo(new CXPLineInfo[0]);
        rr.getRetrieveCart().getCart().getLineDetails().setNumOfAccessoryAndDeviceItemsInCart(0);
        bulkUpdateHelper.updateEvent(vzdl);

        rr.getRetrieveCart().getCart().getLineDetails().setLineInfo(new CXPLineInfo[2]);
        rr.getRetrieveCart().getCart().getLineDetails().setNumOfAccessoryAndDeviceItemsInCart(2);
        bulkUpdateHelper.updateEvent(vzdl);
        Assert.assertNotNull(vzdl.getEvent().getValue());

        rr.getRetrieveCart().getCart().getLineDetails().setNumOfAccessoryAndDeviceItemsInCart(0);
        CXPLineInfo[] lineArray = new CXPLineInfo[2];
        lineArray[0] = null;
        lineArray[1] = new CXPLineInfo();
        lineArray[1].setLineActivityType(null);
        lineArray[1].setServiceInfo(null);
        rr.getRetrieveCart().getCart().getLineDetails().setLineInfo(lineArray);
        bulkUpdateHelper.updateEvent(vzdl);

        lineArray = new CXPLineInfo[1];
        lineArray[0] = new CXPLineInfo();
        lineArray[0].setLineActivityType("");
        lineArray[0].setServiceInfo(new ServiceInfo());
        rr.getRetrieveCart().getCart().getLineDetails().setLineInfo(lineArray);
        bulkUpdateHelper.updateEvent(vzdl);

        lineArray[0].setLineActivityType("ABC");
        lineArray[0].getServiceInfo().setSelectedFeaturesList(new SelectedFeaturesList());
        rr.getRetrieveCart().getCart().getLineDetails().setLineInfo(lineArray);
        bulkUpdateHelper.updateEvent(vzdl);

        lineArray[0].setLineActivityType("CPC");
        lineArray[0].getServiceInfo().getSelectedFeaturesList().setVisFeature(null);
        rr.getRetrieveCart().getCart().getLineDetails().setLineInfo(lineArray);
        bulkUpdateHelper.updateEvent(vzdl);

        lineArray[0].setLineActivityType("ABC");
        lineArray[0].getServiceInfo().getSelectedFeaturesList().setVisFeature(new ArrayList<>());
        rr.getRetrieveCart().getCart().getLineDetails().setLineInfo(lineArray);
        bulkUpdateHelper.updateEvent(vzdl);

        List<VisFeature> featureList = new ArrayList<>();
        VisFeature feature = new VisFeature();
        featureList.add(null);
        feature.setAddDeleteInd("");
        featureList.add(feature);
        lineArray[0].getServiceInfo().getSelectedFeaturesList().setVisFeature(featureList);
        rr.getRetrieveCart().getCart().getLineDetails().setLineInfo(lineArray);
        bulkUpdateHelper.updateEvent(vzdl);

        featureList = new ArrayList<>();
        feature.setAddDeleteInd(null);
        featureList.add(feature);
        lineArray[0].getServiceInfo().getSelectedFeaturesList().setVisFeature(featureList);
        rr.getRetrieveCart().getCart().getLineDetails().setLineInfo(lineArray);
        bulkUpdateHelper.updateEvent(vzdl);

        featureList = new ArrayList<>();
        feature.setAddDeleteInd("z");
        featureList.add(feature);
        lineArray[0].getServiceInfo().getSelectedFeaturesList().setVisFeature(featureList);
        rr.getRetrieveCart().getCart().getLineDetails().setLineInfo(lineArray);
        bulkUpdateHelper.updateEvent(vzdl);

        featureList = new ArrayList<>();
        feature.setAddDeleteInd("A");
        featureList.add(feature);
        lineArray[0].getServiceInfo().getSelectedFeaturesList().setVisFeature(featureList);
        rr.getRetrieveCart().getCart().getLineDetails().setLineInfo(lineArray);
        bulkUpdateHelper.updateEvent(vzdl);

        Assert.assertNotNull(vzdl.getEvent().getValue());
    }


    @Test
    public void getFlowName() {
        BulkQuoteUIResponse response = Mockito.mock(BulkQuoteUIResponse.class);
        BulkQuoteUIRequest request = Mockito.mock(BulkQuoteUIRequest.class);
        CartData data = Mockito.mock(CartData.class);
        Lines line = Mockito.mock(Lines.class);
        List<Lines> lines = Collections.singletonList(line);

        Assert.assertEquals("", bulkUpdateHelper.getFlowName(null, response));

        when(request.getData()).thenReturn(null);
        Assert.assertEquals("", bulkUpdateHelper.getFlowName(request, response));

        when(request.getData()).thenReturn(data);
        when(data.getLines()).thenReturn(null);
        Assert.assertEquals("", bulkUpdateHelper.getFlowName(request, response));


        when(data.getLines()).thenReturn(lines);
        Assert.assertEquals("", bulkUpdateHelper.getFlowName(request, response));


        Device device = Mockito.mock(Device.class);
        Plan plan = Mockito.mock(Plan.class);
        DeviceOutInfo item = Mockito.mock(DeviceOutInfo.class);
        Feature feature = Mockito.mock(Feature.class);
        Accessory accessory = Mockito.mock(Accessory.class);
        when(line.getDevice()).thenReturn(device);
        when(line.getPlan()).thenReturn(plan);
        when(line.getAddAccessories()).thenReturn(new Accessory[]{accessory});
        when(line.getAddFeatures()).thenReturn(Collections.singletonList(feature));
        when(line.getTradeInItems()).thenReturn(Collections.singletonList(item));
        when(item.getItemId()).thenReturn(null);
        when(device.getId()).thenReturn(null);
        when(plan.getId()).thenReturn(null);
        when(accessory.getId()).thenReturn(null);
        when(feature.getId()).thenReturn(null);
        Assert.assertEquals("", bulkUpdateHelper.getFlowName(request, response));

        when(response.getServiceBody()).thenReturn(null);
        Assert.assertEquals("", bulkUpdateHelper.getFlowName(request, response));

        CreateBulkQuoteServiceBody serviceBody = Mockito.mock(CreateBulkQuoteServiceBody.class);
        when(response.getServiceBody()).thenReturn(serviceBody);
        when(serviceBody.getServiceResponse()).thenReturn(null);
        Assert.assertEquals("", bulkUpdateHelper.getFlowName(request, response));

        CreateBulkQuoteServiceResponse serviceResp = Mockito.mock(CreateBulkQuoteServiceResponse.class);
        when(serviceBody.getServiceResponse()).thenReturn(serviceResp);
        when(serviceResp.getContext()).thenReturn(null);
        Assert.assertEquals("", bulkUpdateHelper.getFlowName(request, response));

        CreateBulkQuoteContext context = Mockito.mock(CreateBulkQuoteContext.class);
        when(serviceResp.getContext()).thenReturn(context);
        Assert.assertEquals("", bulkUpdateHelper.getFlowName(request, response));

        CartServiceBulkCartInfo cartInfo = Mockito.mock(CartServiceBulkCartInfo.class);
        when(context.getCartInfo()).thenReturn(cartInfo);
        Assert.assertEquals("", bulkUpdateHelper.getFlowName(request, response));

        Line line1 = Mockito.mock(Line.class);
        Line[] lines1 = new Line[]{line1};
        when(cartInfo.getLines()).thenReturn(lines1);
        when(line.getMtn()).thenReturn("testMtn");
        when(line1.getMtn()).thenReturn(null);
        Assert.assertEquals("", bulkUpdateHelper.getFlowName(request, response));

        when(line1.getMtn()).thenReturn("testMtn");
        Assert.assertEquals("", bulkUpdateHelper.getFlowName(request, response));

        SoftSKUItem upgradeFee = Mockito.mock(SoftSKUItem.class);
        when(upgradeFee.getQty()).thenReturn(0);
        when(line1.getUpgradeFee()).thenReturn(upgradeFee);
        Assert.assertEquals("", bulkUpdateHelper.getFlowName(request, response));

        when(upgradeFee.getQty()).thenReturn(1);
        Assert.assertEquals(CartConstants.FEA, bulkUpdateHelper.getFlowName(request, response));

        when(item.getItemId()).thenReturn("itemId");
        when(device.getId()).thenReturn("deviceId");
        when(plan.getId()).thenReturn("planId");
        when(accessory.getId()).thenReturn("accessoryId");
        when(feature.getId()).thenReturn("featureId");
        Assert.assertEquals("EUP|CPC|FEA|FEA|TRADEIN|NAO", bulkUpdateHelper.getFlowName(request, response));
    }

}



