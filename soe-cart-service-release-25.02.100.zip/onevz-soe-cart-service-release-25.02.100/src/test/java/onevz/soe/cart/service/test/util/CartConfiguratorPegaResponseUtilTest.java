package onevz.soe.cart.service.test.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.responses.AddAllConfiguratorPEGAResponse;
import onevz.soe.cart.ui.responses.AddAllConfiguratorUIResponse;
import onevz.soe.cart.util.CartConfiguratorPegaResponseUtil;
import onevz.soe.cart.util.CartUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@WebFluxTest(CartConfiguratorPegaResponseUtil.class)
public class CartConfiguratorPegaResponseUtilTest {
    @MockBean
    CartConfiguratorPegaResponseUtil util;
    @MockBean
    CartUtil cartUtil;
    @Autowired
    private ObjectMapper mapper;

    @Test
    public void formatUpdateAddressChangeUiResponseTest() throws JsonProcessingException {
        String pegaResponseString = "{\"serviceHeader\": {}, \"errors\": [{}]}";
        AddAllConfiguratorUIResponse soeResponse = new AddAllConfiguratorUIResponse();
        AddAllConfiguratorPEGAResponse pegaResponse = mapper.readValue(pegaResponseString, AddAllConfiguratorPEGAResponse.class);
        CartConfiguratorPegaResponseUtil.formatAddAllConfiguratorResponse(soeResponse, pegaResponse);
    }

    @Test
    public void formatUpdateAddressChangeUiResponseTestForValidResponseBody() throws JsonProcessingException {
        String pegaResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2024.07.16.18.45.03-861.925354345739\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-15256602-E01\",\"contextInfo\":{\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"\"},\"customerInfo\":{\"customerType\":\"N\",\"nocByod\":false,\"accountNumber\":\"\",\"cartCreator\":\"POE-D-82486a34-0bc6-4c23-8ca0-4961fea4562c\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-82486a34-0bc6-4c23-8ca0-4961fea4562c\",\"noc\":false,\"myvPage\":false},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"\",\"statusMsg\":\"\",\"statusCode\":\"\",\"couponCode\":\"\",\"lines\":[],\"effectiveDateDetails\":{},\"monthlyCreditAmount\":\"\",\"agreementNumber\":\"\",\"discountPromoTotal\":0.0,\"registerNumber\":0,\"cartValidationErrors\":[],\"ecpdProfileId\":\"\",\"protectionNotRequired\":false,\"fmiCheck\":false,\"lineDevices\":[],\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false,\"instantCreditAmount\":0}}}}}";
        AddAllConfiguratorUIResponse addAllConfiguratorUIResponse = new AddAllConfiguratorUIResponse();
        AddAllConfiguratorPEGAResponse addAllConfiguratorPEGAResponse = mapper.readValue(pegaResponseString, AddAllConfiguratorPEGAResponse.class);
        CartConfiguratorPegaResponseUtil.formatAddAllConfiguratorResponse(addAllConfiguratorUIResponse, addAllConfiguratorPEGAResponse);
    }
}
