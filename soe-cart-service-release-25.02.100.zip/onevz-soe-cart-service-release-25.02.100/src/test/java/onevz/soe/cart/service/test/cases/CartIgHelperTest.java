package onevz.soe.cart.service.test.cases;

import java.io.IOException;

import onevz.soe.cart.controller.CartBauToNsaRedirectionController;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.reactivestreams.Publisher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fasterxml.jackson.databind.ObjectMapper;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.helper.CartIgHelper;
import onevz.soe.cart.requests.ValidateSecureTokenRequest;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.requests.DeviceSimValidationUIRequest;
import reactor.test.StepVerifier;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = {CartServiceTestConfig.class})
@WebFluxTest(CartIgHelper.class)

public class CartIgHelperTest {
	
	@Autowired
	CartIgHelper cartIgHelper;
	
	@Autowired
	private ObjectMapper mapper;
	
	
	//Test Coverage for NSA
	@SuppressWarnings("unchecked")
	@Test
	public void validateSecureTokenHelperTest() throws IOException {
		String sampleRequestString = "{\"channelId\":\"OMNI-INDIRECT\",\"cartInfo\": {\"cartCreator\": \"7039159592\",\"clientAppName\": \"VZW-MFA\",\"cartId\": \"4b207c97-6278-4562-9e41-b6411763bcd6\",\"caseId\": \"SOP-947715-E01\",\"processingMTN\": \"\",\"accountNumber\": \"0201430224-00001\",\"intent\": \"BYOD\",\"processStep\": \"BYODLandingPage\",\"processAction\": \"validatedevicesim\"},\"data\": {\"lines\": [{\"mtn\": \"\",\"device\": {\"id\": \"353338070105553\",\"Flowtype\": \"DEVICE\",\"CurrentId\": \"\",\"isCustomerProvidedEquipment\": true,\"sku\": \"\",\"smartIMEI\": true,\"searchAttributes\": {\"postpaidRestrictStartDate\": \"2018-07-01T04:00:00.000Z\",\"prodCode\": \"LTE\",\"hdVoiceInd\": true,\"deviceType\": \"4GE\",\"dacc\": \"00854\"},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": \"\"}}}]}}";
		ValidateSecureTokenRequest validateSecureTokenRequest = null;
		validateSecureTokenRequest = mapper.readValue(sampleRequestString, ValidateSecureTokenRequest.class);
		validateSecureTokenRequest.setIntent(CartConstants.BBP_INTENT_ORDERSELFSERVICE);
		validateSecureTokenRequest.setToken("");
		
		DeviceSimValidationUIRequest sampleResponse= cartIgHelper.validateSecureToken(validateSecureTokenRequest);
		Assert.assertNotNull(sampleResponse);

	}

	@SuppressWarnings("unchecked")
	@Test
	public void validateSecureTokenHelperTest1() throws IOException {
		String sampleRequestString = "{\"channelId\":\"OMNI-INDIRECT\",\"cartInfo\": {\"cartCreator\": \"7039159592\",\"clientAppName\": \"VZW-MFA\",\"cartId\": \"4b207c97-6278-4562-9e41-b6411763bcd6\",\"caseId\": \"SOP-947715-E01\",\"processingMTN\": \"\",\"accountNumber\": \"0201430224-00001\",\"intent\": \"BYOD\",\"processStep\": \"BYODLandingPage\",\"processAction\": \"validatedevicesim\"},\"data\": {\"lines\": [{\"mtn\": \"\",\"device\": {\"id\": \"353338070105553\",\"Flowtype\": \"DEVICE\",\"CurrentId\": \"\",\"isCustomerProvidedEquipment\": true,\"sku\": \"\",\"smartIMEI\": true,\"searchAttributes\": {\"postpaidRestrictStartDate\": \"2018-07-01T04:00:00.000Z\",\"prodCode\": \"LTE\",\"hdVoiceInd\": true,\"deviceType\": \"4GE\",\"dacc\": \"00854\"},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": \"\"}}}]}}";
		ValidateSecureTokenRequest validateSecureTokenRequest = null;
		validateSecureTokenRequest = mapper.readValue(sampleRequestString, ValidateSecureTokenRequest.class);
		validateSecureTokenRequest.setIntent(CartConstants.BBP_INTENT_ORDERSELFSERVICE);
		validateSecureTokenRequest.setToken("ee6ehgj7iffeycnc");

		DeviceSimValidationUIRequest sampleResponse= cartIgHelper.validateSecureToken(validateSecureTokenRequest);
		Assert.assertNotNull(sampleResponse);

	}

}
