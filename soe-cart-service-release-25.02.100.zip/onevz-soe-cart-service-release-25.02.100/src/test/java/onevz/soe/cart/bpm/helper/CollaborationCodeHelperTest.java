package onevz.soe.cart.bpm.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import onevz.onevzsoe.peripherals.cassandra.PlanbuilderDatastoreClient;
import onevz.soe.cart.helper.CollaborationCodeHelper;
import onevz.soe.cart.responses.LookupColloborationCodeResponse;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = {CartServiceTestConfig.class})
@WebFluxTest(CollaborationCodeHelper.class)
public class CollaborationCodeHelperTest {

    @Mock
    private PlanbuilderDatastoreClient planbuilderDatastoreClient;

    @InjectMocks
    private CollaborationCodeHelper helper;

    @Autowired
    ObjectMapper objectMapper;

    @Mock
    ObjectMapper mapper;

   @Test
   public void test_getDataForLookupPasscode_success() throws JsonProcessingException {
       ObjectNode objectNode = new ObjectNode(JsonNodeFactory.instance);
       objectNode.put("cartId", "uiqwryeoruqwetoyt");
       String lres = objectMapper.writeValueAsString(objectNode);
       Mockito.when(mapper.readValue(Mockito.anyString(), Mockito.eq(JsonNode.class))).thenReturn(objectNode);
       Mockito.when(planbuilderDatastoreClient.readPlanBuilderData(Mockito.anyString(), Mockito.anyString())).thenReturn(Mono.just(lres));
       Mono<LookupColloborationCodeResponse> response = helper.getDataForLookupPasscode("60173","223243");
       StepVerifier.create(response).assertNext(Assert::assertNotNull).verifyComplete();
   }

    @Test
    public void test_getDataForLookupPasscode_NoContent() throws JsonProcessingException {

        ObjectNode objectNode = new ObjectNode(JsonNodeFactory.instance);
        objectNode.put("cartId", "uiqwryeoruqwetoyt");
        String lres = objectMapper.writeValueAsString(objectNode);
        Mockito.when(mapper.readValue(Mockito.anyString(), Mockito.eq(JsonNode.class))).thenReturn(objectNode);
        Mockito.when(planbuilderDatastoreClient.readPlanBuilderData(Mockito.anyString(), Mockito.anyString())).thenReturn(Mono.empty());
        Mono<LookupColloborationCodeResponse> response = helper.getDataForLookupPasscode("60173","223243");
        StepVerifier.create(response).assertNext(Assert::assertNotNull).verifyComplete();

    }


}
