package onevz.soe.cart.service.test.cases;

import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.*;

import onevz.soe.cart.constants.CartConstants;
import org.mockito.InjectMocks;
import onevz.soe.cart.model.catalog.CatalogSpoProduct;
import onevz.soe.cart.model.catalog.SpoCatalogItems;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.mockito.Mock;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import onevz.soe.cart.cxp.helper.CatalogServiceHelper;
import onevz.soe.cart.cxp.service.CatalogService;
import onevz.soe.cart.responses.CatalogResponse;
import onevz.soe.cart.responses.PlanCatalogResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { CartServiceTestConfig.class })
public class CatalogServiceHelperTest {

	@InjectMocks
	private CatalogServiceHelper catalogServiceHelper;

	@Autowired
	private ObjectMapper mapper;
	@Mock
	private CatalogService catalogService;

	private static final Logger logger = LoggerFactory.getLogger(CatalogServiceHelperTest.class);

	@Test
	public void getSPOsTest() throws IOException{
		Collection<String> sorIds = Arrays.asList("123", "234");
		String sampleSpoCatalogResponseString = "{\"data\":{\"spoCatalogItems\":[{\"spoId\":\"1554\",\"maxaccoffercount\":999.0,\"sorTreatmentCode\":\"FEAT\",\"skuName\":\"5G Ultra Wideband Provisioning\",\"levelCode\":\"L\",\"frequencyCode\":\"M\",\"sorMaxLineOfferCount\":1,\"parentProducts\":[{\"productId\":\"spo1200001\",\"productName\":\"TRIGGERS PROVISIONING\",\"productSorId\":\"TP\"},{\"productId\":\"spo4120002\",\"productName\":\"5G UWB BOLT ON\",\"productSorId\":\"5GUWBBOLT\"}],\"showSpoDetails\":false,\"spoCategoryCodeProducts\":[{\"productId\":\"spo1200001\",\"productName\":\"TRIGGERS PROVISIONING\",\"productSorId\":\"TP\"},{\"productId\":\"spo4120002\",\"productName\":\"5G UWB BOLT ON\",\"productSorId\":\"5GUWBBOLT\"}],\"skuDisplaySequence\":1,\"isActive\":false,\"isShowcase\":false,\"isSorRequisiteShare\":false,\"isReceiptDisplay\":false,\"isRestrictAddService\":false,\"isRestrictRemoval\":false,\"isRestrictRemovalWhenSubsidy\":false}],\"spoCategoryCodeProducts\":[{\"productId\":\"spo4120002\",\"productName\":\"5G UWB BOLT ON\",\"productSorId\":\"5GUWBBOLT\",\"displayGroup\":\"Never\",\"prodDispSequence\":1,\"spoCategoryCode\":\"5GUWBBOLT\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo1200001\",\"productName\":\"TRIGGERS PROVISIONING\",\"productSorId\":\"TP\",\"displayGroup\":\"Never\",\"prodDispSequence\":2,\"spoCategoryCode\":\"TP\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false,\"sorSubGroupClassificationCd\":\"SUBGRPFEAT\",\"sorSubGroupClassificationDesc\":\"FEATURE SUB GROUP CLASS CODE\"}]}}";
		CatalogResponse catalogSpoResponse = mapper.readValue(sampleSpoCatalogResponseString, CatalogResponse.class);
		when(catalogService.getSPOFromCatalog(Mockito.any())).thenReturn(Mono.just(catalogSpoResponse));
		ReflectionTestUtils.setField(catalogServiceHelper, "planSku", true);
		Mono<List<CatalogResponse>> response = catalogServiceHelper.getSPOs(sorIds);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(catalogService.getSPOFromCatalog(Mockito.any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(catalogServiceHelper.getSPOs(sorIds)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void getSPOsNoCatalogTest() throws IOException{
		Collection<String> sorIds = Arrays.asList("123", "234");
		String sampleSpoCatalogResponseString = "{\"data\":{\"spoCatalogItems\":[{\"spoId\":\"1554\",\"maxaccoffercount\":999.0,\"sorTreatmentCode\":\"FEAT\",\"skuName\":\"5G Ultra Wideband Provisioning\",\"levelCode\":\"L\",\"frequencyCode\":\"M\",\"sorMaxLineOfferCount\":1,\"parentProducts\":[{\"productId\":\"spo1200001\",\"productName\":\"TRIGGERS PROVISIONING\",\"productSorId\":\"TP\"},{\"productId\":\"spo4120002\",\"productName\":\"5G UWB BOLT ON\",\"productSorId\":\"5GUWBBOLT\"}],\"showSpoDetails\":false,\"spoCategoryCodeProducts\":[{\"productId\":\"spo1200001\",\"productName\":\"TRIGGERS PROVISIONING\",\"productSorId\":\"TP\"},{\"productId\":\"spo4120002\",\"productName\":\"5G UWB BOLT ON\",\"productSorId\":\"5GUWBBOLT\"}],\"skuDisplaySequence\":1}],\"spoCategoryCodeProducts\":[{\"productId\":\"spo4120002\",\"productName\":\"5G UWB BOLT ON\",\"productSorId\":\"5GUWBBOLT\",\"displayGroup\":\"Never\",\"prodDispSequence\":1,\"spoCategoryCode\":\"5GUWBBOLT\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo1200001\",\"productName\":\"TRIGGERS PROVISIONING\",\"productSorId\":\"TP\",\"displayGroup\":\"Never\",\"prodDispSequence\":2,\"spoCategoryCode\":\"TP\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false,\"sorSubGroupClassificationCd\":\"SUBGRPFEAT\",\"sorSubGroupClassificationDesc\":\"FEATURE SUB GROUP CLASS CODE\"}]}}";
		CatalogResponse catalogSpoResponse = mapper.readValue(sampleSpoCatalogResponseString, CatalogResponse.class);
		when(catalogService.getSPOFromCatalog(Mockito.any())).thenReturn(Mono.just(catalogSpoResponse));
		ReflectionTestUtils.setField(catalogServiceHelper, "planSku", true);
		Mono<List<CatalogResponse>> response = catalogServiceHelper.getSPOs(sorIds);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(catalogService.getSPOFromCatalog(Mockito.any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(catalogServiceHelper.getSPOs(sorIds)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getSPOsTrueTest() throws IOException{
		Collection<String> sorIds = Arrays.asList("123", "234");
		String sampleSpoCatalogResponseString = "{\"data\":{\"spoCatalogItems\":[{\"spoId\":\"1554\",\"maxaccoffercount\":999.0,\"sorTreatmentCode\":\"FEAT\",\"skuName\":\"5G Ultra Wideband Provisioning\",\"levelCode\":\"L\",\"frequencyCode\":\"M\",\"sorMaxLineOfferCount\":1,\"parentProducts\":[{\"productId\":\"spo1200001\",\"productName\":\"TRIGGERS PROVISIONING\",\"productSorId\":\"TP\"},{\"productId\":\"spo4120002\",\"productName\":\"5G UWB BOLT ON\",\"productSorId\":\"5GUWBBOLT\"}],\"showSpoDetails\":false,\"spoCategoryCodeProducts\":[{\"productId\":\"spo1200001\",\"productName\":\"TRIGGERS PROVISIONING\",\"productSorId\":\"TP\"},{\"productId\":\"spo4120002\",\"productName\":\"5G UWB BOLT ON\",\"productSorId\":\"5GUWBBOLT\"}],\"skuDisplaySequence\":1,\"isActive\":true,\"isShowcase\":true,\"isSorRequisiteShare\":true,\"isReceiptDisplay\":true,\"isRestrictAddService\":true,\"isRestrictRemoval\":true,\"isRestrictRemovalWhenSubsidy\":true}],\"spoCategoryCodeProducts\":[{\"productId\":\"spo4120002\",\"productName\":\"5G UWB BOLT ON\",\"productSorId\":\"5GUWBBOLT\",\"displayGroup\":\"Never\",\"prodDispSequence\":1,\"spoCategoryCode\":\"5GUWBBOLT\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo1200001\",\"productName\":\"TRIGGERS PROVISIONING\",\"productSorId\":\"TP\",\"displayGroup\":\"Never\",\"prodDispSequence\":2,\"spoCategoryCode\":\"TP\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false,\"sorSubGroupClassificationCd\":\"SUBGRPFEAT\",\"sorSubGroupClassificationDesc\":\"FEATURE SUB GROUP CLASS CODE\"}]}}";
		CatalogResponse catalogSpoResponse = mapper.readValue(sampleSpoCatalogResponseString, CatalogResponse.class);
		when(catalogService.getSPOFromCatalog(Mockito.any())).thenReturn(Mono.just(catalogSpoResponse));
		ReflectionTestUtils.setField(catalogServiceHelper, "planSku", true);
		Mono<List<CatalogResponse>> response = catalogServiceHelper.getSPOs(sorIds);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(catalogService.getSPOFromCatalog(Mockito.any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(catalogServiceHelper.getSPOs(sorIds)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getSPOsTest1() throws IOException{
		Collection<String> sorIds = Arrays.asList("123", "234");
		String sampleSpoCatalogResponseString = "{\"data\":{\"spoCatalogItems\":[{\"spoId\":\"1554\",\"maxaccoffercount\":999.0,\"sorTreatmentCode\":\"FEAT\",\"skuName\":\"5G Ultra Wideband Provisioning\",\"levelCode\":\"L\",\"frequencyCode\":\"M\",\"sorMaxLineOfferCount\":1,\"parentProducts\":[{\"productId\":\"spo1200001\",\"productName\":\"TRIGGERS PROVISIONING\",\"productSorId\":\"TP\"},{\"productId\":\"spo4120002\",\"productName\":\"5G UWB BOLT ON\",\"productSorId\":\"5GUWBBOLT\"}],\"showSpoDetails\":false,\"spoCategoryCodeProducts\":[{\"productId\":\"spo1200001\",\"productName\":\"TRIGGERS PROVISIONING\",\"productSorId\":\"TP\"},{\"productId\":\"spo4120002\",\"productName\":\"5G UWB BOLT ON\",\"productSorId\":\"5GUWBBOLT\"}],\"skuDisplaySequence\":1,\"isActive\":false,\"isShowcase\":false,\"isSorRequisiteShare\":false,\"isReceiptDisplay\":false,\"isRestrictAddService\":false,\"isRestrictRemoval\":false,\"isRestrictRemovalWhenSubsidy\":false}],\"spoCategoryCodeProducts\":[{\"productId\":\"spo4120002\",\"productName\":\"5G UWB BOLT ON\",\"productSorId\":\"5GUWBBOLT\",\"displayGroup\":\"Never\",\"prodDispSequence\":1,\"spoCategoryCode\":\"5GUWBBOLT\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo1200001\",\"productName\":\"TRIGGERS PROVISIONING\",\"productSorId\":\"TP\",\"displayGroup\":\"Never\",\"prodDispSequence\":2,\"spoCategoryCode\":\"TP\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false,\"sorSubGroupClassificationCd\":\"SUBGRPFEAT\",\"sorSubGroupClassificationDesc\":\"FEATURE SUB GROUP CLASS CODE\"}]}}";
		CatalogResponse catalogSpoResponse = mapper.readValue(sampleSpoCatalogResponseString, CatalogResponse.class);
		when(catalogService.getSPOFromCatalog(Mockito.any())).thenReturn(Mono.just(catalogSpoResponse));

		ReflectionTestUtils.setField(catalogServiceHelper, "planSku", false);
		when(catalogService.getSPO(Mockito.any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(catalogServiceHelper.getSPOs(sorIds)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(catalogService.getSPO(Mockito.any())).thenReturn(Mono.just(new CatalogResponse()));
		StepVerifier.create(catalogServiceHelper.getSPOs(sorIds)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

	}

	@Test
	public void formatSpoResponseTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"data\": {\"spoCatalogItems\": [{\"spoId\": null,\"maxaccoffercount\": \"999.0\",\"sorTreatmentCode\": null,\"skuName\": null,\"levelCode\": null,\"frequencyCode\": \"M\",\"sorMaxLineOfferCount\": \"1\",\"description\": null,\"marketingDescription\": \"desc\",\"externalSpoProductInfo\": null,\"parentProducts\": null,\"showSpoDetails\": false,\"spoCategoryCodeProducts\": [{\"productId\": \"spo1200001\",\"productName\": \"TRIGGERSPROVISIONING\",\"productSorId\": \"TP\",\"sorId\": null},{\"productId\": \"spo4120002\",\"productName\": \"5G UWB BOLT ON\",\"productSorId\": \"5GUWBBOLT\",\"sorId\": null}],\"skuDisplaySequence\": \"1\",\"isActive\": false,\"isShowcase\": false,\"isSorRequisiteShare\": false,\"isReceiptDisplay\": true,\"isRestrictAddService\": false,\"isRestrictRemoval\": false,\"isRestrictRemovalWhenSubsidy\": false,\"mobAppLongDesc\": \"\",\"shortDescription\": \"\",\"skuDisplayNameB2b\": \"\",\"skuMobAppShortDesc\": \"\",\"displayLocation\": \"\",\"ImageUrlMap\": null}],\"SpoCategoryCodeProducts\": [{\"productId\": \"spo4120002\",\"productName\": \"5G UWB BOLT ON\",\"productSorId\": \"5GUWBBOLT\",\"displayGroup\": \"Never\",\"prodDispSequence\": \"1\",\"spoCategoryCode\": \"5GUWBBOLT\",\"isActive\": false,\"isShowcase\": false,\"isMutuallyExclusive\": false,\"sorSubGroupClassificationCd\": null,\"sorSubGroupClassificationDesc\": null},{\"productId\": \"spo1200001\",\"productName\": \"TRIGGERSPROVISIONING\",\"productSorId\": \"TP\",\"displayGroup\": \"Never\",\"prodDispSequence\": \"2\",\"spoCategoryCode\": \"TP\",\"isActive\": false,\"isShowcase\": false,\"isMutuallyExclusive\": false,\"sorSubGroupClassificationCd\": \"SUBGRPFEAT\",\"sorSubGroupClassificationDesc\": \"FEATURESUBGROUPCLASSCODE\"}],\"deviceCatalogItems\": null,\"planCatalogItems\": null},\"meta\": null,\"errors\": null,\"planId\": null}";
		CatalogResponse request = mapper.readValue(requestString, CatalogResponse.class);
		CatalogResponse response = catalogServiceHelper.formatSpoResponse(request);
		Assert.assertEquals("desc", response.getData().getSpoSku().getMarketingDescription());
		request.getData().setSpoCatalogItems(Collections.emptyList());
		Assert.assertNotNull(catalogServiceHelper.formatSpoResponse(request));
		SpoCatalogItems SpoCatalogItemsObj = new SpoCatalogItems();
		SpoCatalogItemsObj.setSpoId("random");
		SpoCatalogItemsObj.setLevelCode("random");
		SpoCatalogItemsObj.setSkuName("random");
		SpoCatalogItemsObj.setIsReceiptDisplay(true);
		SpoCatalogItemsObj.setSorTreatmentCode("random");
		SpoCatalogItemsObj.setParentProducts(Arrays.asList(new CatalogSpoProduct()));
		SpoCatalogItemsObj.setMarketingDescription(null);
		SpoCatalogItemsObj.setMobAppLongDesc(null);
		SpoCatalogItemsObj.setShortDescription(null);
		SpoCatalogItemsObj.setSkuDisplayNameB2b(null);
		SpoCatalogItemsObj.setSkuMobAppShortDesc(null);
		request.getData().setSpoCatalogItems(Arrays.asList(SpoCatalogItemsObj));
		Assert.assertNotNull(catalogServiceHelper.formatSpoResponse(request));
		SpoCatalogItemsObj.setIsReceiptDisplay(false);
		request.getData().setSpoCatalogItems(Arrays.asList(SpoCatalogItemsObj));
		Assert.assertNotNull(catalogServiceHelper.formatSpoResponse(request));
		request.getData().setSpoCatalogItems(Arrays.asList());
		Assert.assertNotNull(catalogServiceHelper.formatSpoResponse(request));
	}

	@Test
	public void formatSposResponseTest() throws JsonMappingException, JsonProcessingException {
		String sampleSpoCatalogResponseString = "{\"data\":{\"spoCatalogItems\":[{\"spoId\":\"1247\",\"skuId\":\"sku2990097\",\"maxaccoffercount\":1,\"sorTreatmentCode\":\"PROMO\",\"skuName\":\"Auto Pay / Paper-free Discount Included\",\"skuDisplayNameB2b\":\"Auto Pay / Paper-free Discount Included\",\"levelCode\":\"A\",\"frequencyCode\":\"M\",\"sorMaxLineOfferCount\":1,\"sorDescription\":\"AUTOPAY/PAPERFREE DISCOUNT INCLUDED\",\"externalSpoLossInfo\":{\"id\":\"1247\",\"name\":\"Autopay\",\"title\":\"Changes to Autopay discount\",\"titleMobile\":\"Your Autopay discount will change.\",\"shortDescription\":\"Your current Autopay discount will change when you switch plans.\",\"longDescription\":\"These lines will lose their Autopay and paperless billing discounts when you switch their plans:<br/><br/>##MDN##<br/><br/>\"},\"displayLocation\":\"DISPLAY_IN_DISCOUNT_PORTAL\",\"parentProducts\":[{\"productId\":\"spo2000002\",\"productName\":\"Access Discounts\",\"productSorId\":\"ACCESSDISC\",\"displayGroup\":\"Never\",\"sorSubGroupClassificationCd\":\"SUBGRPROMO\",\"sorSubGroupClassificationDesc\":\"PROMO SUB GROUP CLASS CODE\",\"spoCategoryCode\":\"ACCESSDISC\",\"isActive\":true,\"isShowcase\":true,\"isMutuallyExclusive\":false},{\"productId\":\"spo3400002\",\"productName\":\"NOSPLANRQD\",\"productSorId\":\"NOSPLANRQD\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"NOSPLANRQD\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo2000001\",\"productName\":\"AUTO PAY\",\"productSorId\":\"AUTOPAY\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"AUTOPAY\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo2000003\",\"productName\":\"PAPERLESS BILLING\",\"productSorId\":\"PAPERFREE\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"PAPERFREE\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo6480019\",\"productName\":\"BYPGRPREQL\",\"productSorId\":\"BYPGRPREQL\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"BYPGRPREQL\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo3360003\",\"productName\":\"TIERLINE\",\"productSorId\":\"TIERLINE\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"TIERLINE\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo2000004\",\"productName\":\"Discount Promo\",\"productSorId\":\"DISCPROMO\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"DISCPROMO\",\"isActive\":true,\"isShowcase\":true,\"isMutuallyExclusive\":false}],\"showSpoDetails\":false,\"spoCategoryCodeProducts\":[{\"productId\":\"spo2000002\",\"productName\":\"Access Discounts\",\"productSorId\":\"ACCESSDISC\",\"displayGroup\":\"Never\",\"sorSubGroupClassificationCd\":\"SUBGRPROMO\",\"sorSubGroupClassificationDesc\":\"PROMO SUB GROUP CLASS CODE\",\"spoCategoryCode\":\"ACCESSDISC\",\"isActive\":true,\"isShowcase\":true,\"isMutuallyExclusive\":false},{\"productId\":\"spo3400002\",\"productName\":\"NOSPLANRQD\",\"productSorId\":\"NOSPLANRQD\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"NOSPLANRQD\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo2000001\",\"productName\":\"AUTO PAY\",\"productSorId\":\"AUTOPAY\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"AUTOPAY\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo2000003\",\"productName\":\"PAPERLESS BILLING\",\"productSorId\":\"PAPERFREE\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"PAPERFREE\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo6480019\",\"productName\":\"BYPGRPREQL\",\"productSorId\":\"BYPGRPREQL\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"BYPGRPREQL\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo3360003\",\"productName\":\"TIERLINE\",\"productSorId\":\"TIERLINE\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"TIERLINE\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo2000004\",\"productName\":\"Discount Promo\",\"productSorId\":\"DISCPROMO\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"DISCPROMO\",\"isActive\":true,\"isShowcase\":true,\"isMutuallyExclusive\":false}],\"skuDisplaySequence\":1,\"isActive\":false,\"isShowcase\":false,\"isSorRequisiteShare\":true,\"isReceiptDisplay\":false,\"isRestrictAddService\":false,\"isRestrictRemoval\":false,\"isRestrictRemovalWhenSubsidy\":false,\"isRestrictionEnabled\":false},{\"spoId\":\"1712\",\"skuId\":\"sku3920088\",\"maxaccoffercount\":10,\"sorTreatmentCode\":\"PROMO\",\"skuName\":\"AutoPay and Paper-Free Discount\",\"levelCode\":\"L\",\"frequencyCode\":\"M\",\"sorMaxLineOfferCount\":1,\"sorDescription\":\"$10 AUTOPAY AND PAPER-FREE DISC\",\"charge\":[{\"chargeId\":\"1712LACC\",\"chargeAmt\":\"-10\",\"chargeCycPerCode\":\"M\",\"chargeLevelCode\":\"L\",\"chargeType\":\"ACC\"}],\"displayLocation\":\"APPLY_TO_PLAN_ACCESS\",\"parentProducts\":[{\"productId\":\"spo2000002\",\"productName\":\"Access Discounts\",\"productSorId\":\"ACCESSDISC\",\"displayGroup\":\"Never\",\"sorSubGroupClassificationCd\":\"SUBGRPROMO\",\"sorSubGroupClassificationDesc\":\"PROMO SUB GROUP CLASS CODE\",\"spoCategoryCode\":\"ACCESSDISC\",\"isActive\":true,\"isShowcase\":true,\"isMutuallyExclusive\":false},{\"productId\":\"spo2000001\",\"productName\":\"AUTO PAY\",\"productSorId\":\"AUTOPAY\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"AUTOPAY\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo2000003\",\"productName\":\"PAPERLESS BILLING\",\"productSorId\":\"PAPERFREE\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"PAPERFREE\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo6480019\",\"productName\":\"BYPGRPREQL\",\"productSorId\":\"BYPGRPREQL\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"BYPGRPREQL\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo2000004\",\"productName\":\"Discount Promo\",\"productSorId\":\"DISCPROMO\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"DISCPROMO\",\"isActive\":true,\"isShowcase\":true,\"isMutuallyExclusive\":false}],\"showSpoDetails\":false,\"spoCategoryCodeProducts\":[{\"productId\":\"spo2000002\",\"productName\":\"Access Discounts\",\"productSorId\":\"ACCESSDISC\",\"displayGroup\":\"Never\",\"sorSubGroupClassificationCd\":\"SUBGRPROMO\",\"sorSubGroupClassificationDesc\":\"PROMO SUB GROUP CLASS CODE\",\"spoCategoryCode\":\"ACCESSDISC\",\"isActive\":true,\"isShowcase\":true,\"isMutuallyExclusive\":false},{\"productId\":\"spo2000001\",\"productName\":\"AUTO PAY\",\"productSorId\":\"AUTOPAY\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"AUTOPAY\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo2000003\",\"productName\":\"PAPERLESS BILLING\",\"productSorId\":\"PAPERFREE\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"PAPERFREE\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo6480019\",\"productName\":\"BYPGRPREQL\",\"productSorId\":\"BYPGRPREQL\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"BYPGRPREQL\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo2000004\",\"productName\":\"Discount Promo\",\"productSorId\":\"DISCPROMO\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"DISCPROMO\",\"isActive\":true,\"isShowcase\":true,\"isMutuallyExclusive\":false}],\"skuDisplaySequence\":2,\"isActive\":false,\"isShowcase\":false,\"isSorRequisiteShare\":false,\"isReceiptDisplay\":false,\"isRestrictAddService\":false,\"isRestrictRemoval\":false,\"isRestrictRemovalWhenSubsidy\":false,\"isRestrictionEnabled\":false},{\"spoId\":\"671\",\"skuId\":\"sku2050064\",\"maxaccoffercount\":1,\"skuName\":\"Carryover Data\",\"levelCode\":\"A\",\"frequencyCode\":\"M\",\"sorMaxLineOfferCount\":1,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Carry_Over_021618\"},\"sorDescription\":\"CARRYOVER DATA\",\"description\":\"<p>Your data is yours. So keep it. Carryover Data automatically carries over your unused gigs for an additional month and is included on all sizes of the new Verizon Plan.  Now you can relax knowing that what you don't use today you can use next month.</p>\",\"marketingDescription\":\"<p>Your data is yours. So keep it. Carryover Data automatically carries over your unused gigs for an additional month and is included on all sizes of the new Verizon Plan.  Now you can relax knowing that what you don't use today you can use next month.</p>9999feature_id=13255\",\"shortDescription\":\"<p>Your data is yours. So keep it. Carryover Data automatically carries over your unused gigs for an additional month to the end of the following month and is included on all sizes of the new Verizon Plan.</p> \",\"parentProducts\":[{\"productId\":\"spo1480002\",\"productName\":\"Data Services\",\"productSorId\":\"ADS\",\"displayGroup\":\"Never\",\"sorSubGroupClassificationCd\":\"SUBGRPFEAT\",\"sorSubGroupClassificationDesc\":\"FEATURE SUB GROUP CLASS CODE\",\"spoCategoryCode\":\"ADS\",\"isActive\":true,\"isShowcase\":true,\"isMutuallyExclusive\":false},{\"productId\":\"spo1360003\",\"productName\":\"DATABANK\",\"productSorId\":\"DATABANK\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"DATABANK\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false}],\"showSpoDetails\":false,\"spoCategoryCodeProducts\":[{\"productId\":\"spo1480002\",\"productName\":\"Data Services\",\"productSorId\":\"ADS\",\"displayGroup\":\"Never\",\"sorSubGroupClassificationCd\":\"SUBGRPFEAT\",\"sorSubGroupClassificationDesc\":\"FEATURE SUB GROUP CLASS CODE\",\"spoCategoryCode\":\"ADS\",\"isActive\":true,\"isShowcase\":true,\"isMutuallyExclusive\":false},{\"productId\":\"spo1360003\",\"productName\":\"DATABANK\",\"productSorId\":\"DATABANK\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"DATABANK\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false}],\"skuDisplaySequence\":3,\"isActive\":true,\"isShowcase\":true,\"isSorRequisiteShare\":true,\"isReceiptDisplay\":false,\"isRestrictAddService\":false,\"isRestrictRemoval\":false,\"isRestrictRemovalWhenSubsidy\":false,\"isRestrictionEnabled\":true},{\"spoId\":\"2509\",\"skuId\":\"sku5500022\",\"maxaccoffercount\":1,\"sorTreatmentCode\":\"FEAT\",\"skuName\":\"FUJI FAMILY ELIGIBILITY\",\"levelCode\":\"A\",\"frequencyCode\":\"M\",\"sorMaxLineOfferCount\":1,\"sorDescription\":\"FUJI FAMILY ELIGIBILITY\",\"charge\":[{\"chargeId\":\"2800009\",\"chargeAmt\":\"0\",\"chargeCycPerCode\":\"M\",\"chargeLevelCode\":\"A\",\"chargeType\":\"ACC\"}],\"parentProducts\":[{\"productId\":\"spo3720001\",\"productName\":\"DVS/SCM\",\"productSorId\":\"SCMSUB\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"SCMSUB\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo8120005\",\"productName\":\"APPLE ONE\",\"productSorId\":\"APPLEONE\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"APPLEONE\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo6480010\",\"productName\":\"BYPVREQUAL\",\"productSorId\":\"BYPVREQUAL\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"BYPVREQUAL\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo3400002\",\"productName\":\"NOSPLANRQD\",\"productSorId\":\"NOSPLANRQD\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"NOSPLANRQD\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo4040002\",\"productName\":\"BOOKING AND TAXING ALLOCATION\",\"productSorId\":\"BOOKTAX\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"BOOKTAX\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo6480019\",\"productName\":\"BYPGRPREQL\",\"productSorId\":\"BYPGRPREQL\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"BYPGRPREQL\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo2000006\",\"productName\":\"ADDITIONAL SERVICES\",\"productSorId\":\"AS\",\"displayGroup\":\"Never\",\"sorSubGroupClassificationCd\":\"SUBGRPFEAT\",\"sorSubGroupClassificationDesc\":\"FEATURE SUB GROUP CLASS CODE\",\"spoCategoryCode\":\"AS\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo4040004\",\"productName\":\"SUBSCRIPTION ELIGIBLE\",\"productSorId\":\"SUBELIG\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"SUBELIG\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo8120003\",\"productName\":\"APPLE ONE FAMILY\",\"productSorId\":\"APONEFMLY\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"APONEFMLY\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo8120001\",\"productName\":\"APPLE ONE INCLUDED ELIGIBILITY\",\"productSorId\":\"APONEINCL\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"APONEINCL\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false}],\"showSpoDetails\":false,\"spoCategoryCodeProducts\":[{\"productId\":\"spo3720001\",\"productName\":\"DVS/SCM\",\"productSorId\":\"SCMSUB\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"SCMSUB\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo8120005\",\"productName\":\"APPLE ONE\",\"productSorId\":\"APPLEONE\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"APPLEONE\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo6480010\",\"productName\":\"BYPVREQUAL\",\"productSorId\":\"BYPVREQUAL\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"BYPVREQUAL\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo3400002\",\"productName\":\"NOSPLANRQD\",\"productSorId\":\"NOSPLANRQD\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"NOSPLANRQD\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo4040002\",\"productName\":\"BOOKING AND TAXING ALLOCATION\",\"productSorId\":\"BOOKTAX\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"BOOKTAX\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo6480019\",\"productName\":\"BYPGRPREQL\",\"productSorId\":\"BYPGRPREQL\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"BYPGRPREQL\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo2000006\",\"productName\":\"ADDITIONAL SERVICES\",\"productSorId\":\"AS\",\"displayGroup\":\"Never\",\"sorSubGroupClassificationCd\":\"SUBGRPFEAT\",\"sorSubGroupClassificationDesc\":\"FEATURE SUB GROUP CLASS CODE\",\"spoCategoryCode\":\"AS\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo4040004\",\"productName\":\"SUBSCRIPTION ELIGIBLE\",\"productSorId\":\"SUBELIG\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"SUBELIG\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo8120003\",\"productName\":\"APPLE ONE FAMILY\",\"productSorId\":\"APONEFMLY\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"APONEFMLY\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo8120001\",\"productName\":\"APPLE ONE INCLUDED ELIGIBILITY\",\"productSorId\":\"APONEINCL\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"APONEINCL\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false}],\"skuDisplaySequence\":4,\"isActive\":false,\"isShowcase\":false,\"isSorRequisiteShare\":true,\"isReceiptDisplay\":false,\"isRestrictAddService\":false,\"isRestrictRemoval\":false,\"isRestrictRemovalWhenSubsidy\":false,\"isRestrictionEnabled\":false},{\"spoId\":\"2507\",\"skuId\":\"sku5500023\",\"maxaccoffercount\":1,\"sorTreatmentCode\":\"FEAT\",\"skuName\":\"FUJI SINGLE ELIGIBILITY\",\"levelCode\":\"A\",\"frequencyCode\":\"M\",\"sorMaxLineOfferCount\":1,\"sorDescription\":\"FUJI SINGLE ELIGIBILITY\",\"charge\":[{\"chargeId\":\"2800007\",\"chargeAmt\":\"0\",\"chargeCycPerCode\":\"M\",\"chargeLevelCode\":\"A\",\"chargeType\":\"ACC\"}],\"parentProducts\":[{\"productId\":\"spo3720001\",\"productName\":\"DVS/SCM\",\"productSorId\":\"SCMSUB\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"SCMSUB\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo8120005\",\"productName\":\"APPLE ONE\",\"productSorId\":\"APPLEONE\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"APPLEONE\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo6480010\",\"productName\":\"BYPVREQUAL\",\"productSorId\":\"BYPVREQUAL\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"BYPVREQUAL\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo3400002\",\"productName\":\"NOSPLANRQD\",\"productSorId\":\"NOSPLANRQD\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"NOSPLANRQD\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo4040002\",\"productName\":\"BOOKING AND TAXING ALLOCATION\",\"productSorId\":\"BOOKTAX\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"BOOKTAX\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo6480019\",\"productName\":\"BYPGRPREQL\",\"productSorId\":\"BYPGRPREQL\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"BYPGRPREQL\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo2000006\",\"productName\":\"ADDITIONAL SERVICES\",\"productSorId\":\"AS\",\"displayGroup\":\"Never\",\"sorSubGroupClassificationCd\":\"SUBGRPFEAT\",\"sorSubGroupClassificationDesc\":\"FEATURE SUB GROUP CLASS CODE\",\"spoCategoryCode\":\"AS\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo4040004\",\"productName\":\"SUBSCRIPTION ELIGIBLE\",\"productSorId\":\"SUBELIG\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"SUBELIG\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo8120001\",\"productName\":\"APPLE ONE INCLUDED ELIGIBILITY\",\"productSorId\":\"APONEINCL\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"APONEINCL\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo8120004\",\"productName\":\"APPLE ONE SINGLE\",\"productSorId\":\"APONESNGL\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"APONESNGL\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false}],\"showSpoDetails\":false,\"spoCategoryCodeProducts\":[{\"productId\":\"spo3720001\",\"productName\":\"DVS/SCM\",\"productSorId\":\"SCMSUB\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"SCMSUB\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo8120005\",\"productName\":\"APPLE ONE\",\"productSorId\":\"APPLEONE\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"APPLEONE\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo6480010\",\"productName\":\"BYPVREQUAL\",\"productSorId\":\"BYPVREQUAL\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"BYPVREQUAL\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo3400002\",\"productName\":\"NOSPLANRQD\",\"productSorId\":\"NOSPLANRQD\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"NOSPLANRQD\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo4040002\",\"productName\":\"BOOKING AND TAXING ALLOCATION\",\"productSorId\":\"BOOKTAX\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"BOOKTAX\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo6480019\",\"productName\":\"BYPGRPREQL\",\"productSorId\":\"BYPGRPREQL\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"BYPGRPREQL\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo2000006\",\"productName\":\"ADDITIONAL SERVICES\",\"productSorId\":\"AS\",\"displayGroup\":\"Never\",\"sorSubGroupClassificationCd\":\"SUBGRPFEAT\",\"sorSubGroupClassificationDesc\":\"FEATURE SUB GROUP CLASS CODE\",\"spoCategoryCode\":\"AS\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo4040004\",\"productName\":\"SUBSCRIPTION ELIGIBLE\",\"productSorId\":\"SUBELIG\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"SUBELIG\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo8120001\",\"productName\":\"APPLE ONE INCLUDED ELIGIBILITY\",\"productSorId\":\"APONEINCL\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"APONEINCL\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo8120004\",\"productName\":\"APPLE ONE SINGLE\",\"productSorId\":\"APONESNGL\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"APONESNGL\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false}],\"skuDisplaySequence\":5,\"isActive\":false,\"isShowcase\":false,\"isSorRequisiteShare\":true,\"isReceiptDisplay\":false,\"isRestrictAddService\":false,\"isRestrictRemoval\":false,\"isRestrictRemovalWhenSubsidy\":false,\"isRestrictionEnabled\":false},{\"spoId\":\"1256\",\"skuId\":\"sku3030249\",\"maxaccoffercount\":999,\"sorTreatmentCode\":\"FEAT\",\"skuName\":\"Includes Mexico & Canada with your domestic plan\",\"levelCode\":\"L\",\"frequencyCode\":\"M\",\"sorMaxLineOfferCount\":1,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/International_Travel_Data_012918\"},\"sorDescription\":\"INCLUDE CANADA/MEXICO\",\"description\":\"<p>You can stay connected while taking your domestic Talk, Text and Data allowances with you while traveling in Mexico and Canada. With this plan you can make calls within the country you are in or back to the US, Mexico or Canada. If you plan to place calls to countries other than the U.S., Mexico or Canada, please add International Long Distance by managing your international plan options while in the US. Requires a World Device.</p> <p>Visit our <a href=\\\"http://www.verizonwireless.com/b2c/tripplanner/tripplannercontroller\\\" target=\\\"_blank\\\">Trip Planner</a> for more information, such as country&ndash;specific dialing instructions, coverage maps and more.</p>\",\"externalSpoLossInfo\":{\"id\":\"1256\",\"name\":\"Call Mexico & Canada\",\"title\":\"Changes to your international calling\",\"titleMobile\":\"Here's what will change with your international calling.\",\"shortDescription\":\"If you switch, you'll no longer have Call the World.\",\"longDescription\":\"Your current plan includes Call the World, which provides 500 minutes/month, shared by all lines on your Verizon account, for calls to the 160+ countries included in the plan. If you switch plans and Call the World is removed from your account, it can't be added back.<br/><br/>You may add one of our newer international long distance plans to any line in your My Verizon App or by logging in to your account at myverizon.com.\"},\"externalSpoProductInfo\":{\"id\":\"1256\",\"name\":\"Includes Canada/Mexico\",\"levelCode\":\"L\",\"categoryName\":\"Miscellaneous\",\"groupId\":\"spo01256\",\"groupName\":\"Includes Canada/Mexico\",\"groupOrderNumber\":0,\"productOrderNumber\":0},\"charge\":[{\"chargeId\":\"1256LACC\",\"chargeAmt\":\"0\",\"chargeCycPerCode\":\"M\",\"chargeLevelCode\":\"L\",\"chargeType\":\"ACC\"}],\"shortDescription\":\"Includes Mexico & Canada with your domestic plan\",\"parentProducts\":[{\"productId\":\"spo2680006\",\"productName\":\"IPV6 ROAM TIER MUTEX\",\"productSorId\":\"MTXIPV6\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"MTXIPV6\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":true},{\"productId\":\"spo960005\",\"productName\":\"International Travel (While Outside the US)\",\"productSorId\":\"GLOBAL\",\"displayGroup\":\"Never\",\"sorSubGroupClassificationCd\":\"SUBGRPFEAT\",\"sorSubGroupClassificationDesc\":\"FEATURE SUB GROUP CLASS CODE\",\"spoCategoryCode\":\"GLOBAL\",\"isActive\":true,\"isShowcase\":true,\"isMutuallyExclusive\":false},{\"productId\":\"spo1080004\",\"productName\":\"COMMISSIONABLE GLOBAL OFFERS\",\"productSorId\":\"COMGLB\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"COMGLB\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo1520002\",\"productName\":\"DAILY INTERNATIONAL TRAVEL PLAN MUTEX\",\"productSorId\":\"MTXTPTRIG2\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"MTXTPTRIG2\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":true},{\"productId\":\"spo1000002\",\"productName\":\"International Travel (While Outside the US)_TrvlPass\",\"productSorId\":\"INTLDAILY\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"INTLDAILY\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo3120001\",\"productName\":\"MUTEX w GCM\",\"productSorId\":\"MUTEXGCM\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"MUTEXGCM\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":true},{\"productId\":\"spo1240001\",\"productName\":\"International (While Traveling Outside the US)\",\"productSorId\":\"GB\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"GB\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":true},{\"productId\":\"spo1000001\",\"productName\":\"DAILY INTERNATIONAL TRAVEL PLAN MUTEX\",\"productSorId\":\"MTXDITP\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"MTXDITP\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":true}],\"showSpoDetails\":false,\"spoCategoryCodeProducts\":[{\"productId\":\"spo2680006\",\"productName\":\"IPV6 ROAM TIER MUTEX\",\"productSorId\":\"MTXIPV6\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"MTXIPV6\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":true},{\"productId\":\"spo960005\",\"productName\":\"International Travel (While Outside the US)\",\"productSorId\":\"GLOBAL\",\"displayGroup\":\"Never\",\"sorSubGroupClassificationCd\":\"SUBGRPFEAT\",\"sorSubGroupClassificationDesc\":\"FEATURE SUB GROUP CLASS CODE\",\"spoCategoryCode\":\"GLOBAL\",\"isActive\":true,\"isShowcase\":true,\"isMutuallyExclusive\":false},{\"productId\":\"spo1080004\",\"productName\":\"COMMISSIONABLE GLOBAL OFFERS\",\"productSorId\":\"COMGLB\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"COMGLB\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo1520002\",\"productName\":\"DAILY INTERNATIONAL TRAVEL PLAN MUTEX\",\"productSorId\":\"MTXTPTRIG2\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"MTXTPTRIG2\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":true},{\"productId\":\"spo1000002\",\"productName\":\"International Travel (While Outside the US)_TrvlPass\",\"productSorId\":\"INTLDAILY\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"INTLDAILY\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo3120001\",\"productName\":\"MUTEX w GCM\",\"productSorId\":\"MUTEXGCM\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"MUTEXGCM\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":true},{\"productId\":\"spo1240001\",\"productName\":\"International (While Traveling Outside the US)\",\"productSorId\":\"GB\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"GB\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":true},{\"productId\":\"spo1000001\",\"productName\":\"DAILY INTERNATIONAL TRAVEL PLAN MUTEX\",\"productSorId\":\"MTXDITP\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"MTXDITP\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":true}],\"skuDisplaySequence\":6,\"isActive\":true,\"isShowcase\":true,\"isSorRequisiteShare\":false,\"isReceiptDisplay\":false,\"isRestrictAddService\":false,\"isRestrictRemoval\":false,\"isRestrictRemovalWhenSubsidy\":false,\"isRestrictionEnabled\":false},{\"spoId\":\"672\",\"skuId\":\"sku2060063\",\"maxaccoffercount\":1,\"skuName\":\"Safety Mode\",\"levelCode\":\"A\",\"frequencyCode\":\"M\",\"sorMaxLineOfferCount\":1,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Safety_Mode_021618\"},\"sorDescription\":\"SAFETY MODE $0\",\"description\":\"<p>We just pulled one over on overages. Choose Safety Mode and stay online even after you've used all your data. With Safety Mode enabled, you won't be charged overage. Instead, you'll keep reduced speed for basic data use like viewing a web page or checking email. To get back to full 4G LTE speed, just buy a Data Boost or switch to a plan with more data. Until you do, we have you covered.</p><p>Available for no additional charge.</p>\",\"marketingDescription\":\"<p>We just pulled one over on overages. Choose Safety Mode and stay online even after you've used all your data. With Safety Mode enabled, you won't be charged overage. Instead, you'll keep reduced speed for basic data use like viewing a web page or checking email. To get back to full 4G LTE speed, just buy a Data Boost or switch to a plan with more data. Until you do, we have you covered.</p><p>Available for no additional charge.</p>\",\"externalSpoProductInfo\":{\"id\":\"672\",\"name\":\"Safety Mode to Avoid Data Overages\",\"groupName\":\"Safety Mode to Avoid Data Overages\",\"groupOrderNumber\":0,\"productOrderNumber\":0},\"charge\":[{\"chargeId\":\"672AACC\",\"chargeAmt\":\"0\",\"chargeCycPerCode\":\"M\",\"chargeLevelCode\":\"A\",\"chargeType\":\"ACC\"}],\"shortDescription\":\"<p>With Safety Mode enabled, you won't be charged overage. Instead, you'll keep reduced speed for basic data use like viewing a web page or checking email. To get back to full 4G LTE speed, just buy a Data Boost or switch to a plan with more data. Until you do, we have you covered.</p>\",\"parentProducts\":[{\"productId\":\"spo1480002\",\"productName\":\"Data Services\",\"productSorId\":\"ADS\",\"displayGroup\":\"Never\",\"sorSubGroupClassificationCd\":\"SUBGRPFEAT\",\"sorSubGroupClassificationDesc\":\"FEATURE SUB GROUP CLASS CODE\",\"spoCategoryCode\":\"ADS\",\"isActive\":true,\"isShowcase\":true,\"isMutuallyExclusive\":false},{\"productId\":\"spo1360002\",\"productName\":\"SAFETYMODE\",\"productSorId\":\"SAFETYMODE\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"SAFETYMODE\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":true}],\"showSpoDetails\":false,\"spoCategoryCodeProducts\":[{\"productId\":\"spo1480002\",\"productName\":\"Data Services\",\"productSorId\":\"ADS\",\"displayGroup\":\"Never\",\"sorSubGroupClassificationCd\":\"SUBGRPFEAT\",\"sorSubGroupClassificationDesc\":\"FEATURE SUB GROUP CLASS CODE\",\"spoCategoryCode\":\"ADS\",\"isActive\":true,\"isShowcase\":true,\"isMutuallyExclusive\":false},{\"productId\":\"spo1360002\",\"productName\":\"SAFETYMODE\",\"productSorId\":\"SAFETYMODE\",\"displayGroup\":\"Never\",\"spoCategoryCode\":\"SAFETYMODE\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":true}],\"skuDisplaySequence\":7,\"isActive\":true,\"isShowcase\":true,\"isSorRequisiteShare\":true,\"isReceiptDisplay\":false,\"isRestrictAddService\":false,\"isRestrictRemoval\":false,\"isRestrictRemovalWhenSubsidy\":false,\"isRestrictionEnabled\":false}],\"spoCategoryCodeProducts\":[{\"productId\":\"spo2000006\",\"productName\":\"ADDITIONAL SERVICES\",\"productSorId\":\"AS\",\"displayGroup\":\"Never\",\"prodDispSequence\":1,\"sorSubGroupClassificationCd\":\"SUBGRPFEAT\",\"sorSubGroupClassificationDesc\":\"FEATURE SUB GROUP CLASS CODE\",\"spoCategoryCode\":\"AS\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo2000006\",\"productName\":\"ADDITIONAL SERVICES\",\"productSorId\":\"AS\",\"displayGroup\":\"Never\",\"prodDispSequence\":2,\"sorSubGroupClassificationCd\":\"SUBGRPFEAT\",\"sorSubGroupClassificationDesc\":\"FEATURE SUB GROUP CLASS CODE\",\"spoCategoryCode\":\"AS\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo8120005\",\"productName\":\"APPLE ONE\",\"productSorId\":\"APPLEONE\",\"displayGroup\":\"Never\",\"prodDispSequence\":3,\"spoCategoryCode\":\"APPLEONE\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo8120005\",\"productName\":\"APPLE ONE\",\"productSorId\":\"APPLEONE\",\"displayGroup\":\"Never\",\"prodDispSequence\":4,\"spoCategoryCode\":\"APPLEONE\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo8120003\",\"productName\":\"APPLE ONE FAMILY\",\"productSorId\":\"APONEFMLY\",\"displayGroup\":\"Never\",\"prodDispSequence\":5,\"spoCategoryCode\":\"APONEFMLY\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo8120001\",\"productName\":\"APPLE ONE INCLUDED ELIGIBILITY\",\"productSorId\":\"APONEINCL\",\"displayGroup\":\"Never\",\"prodDispSequence\":6,\"spoCategoryCode\":\"APONEINCL\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo8120001\",\"productName\":\"APPLE ONE INCLUDED ELIGIBILITY\",\"productSorId\":\"APONEINCL\",\"displayGroup\":\"Never\",\"prodDispSequence\":7,\"spoCategoryCode\":\"APONEINCL\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo8120004\",\"productName\":\"APPLE ONE SINGLE\",\"productSorId\":\"APONESNGL\",\"displayGroup\":\"Never\",\"prodDispSequence\":8,\"spoCategoryCode\":\"APONESNGL\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo2000001\",\"productName\":\"AUTO PAY\",\"productSorId\":\"AUTOPAY\",\"displayGroup\":\"Never\",\"prodDispSequence\":9,\"spoCategoryCode\":\"AUTOPAY\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo2000001\",\"productName\":\"AUTO PAY\",\"productSorId\":\"AUTOPAY\",\"displayGroup\":\"Never\",\"prodDispSequence\":10,\"spoCategoryCode\":\"AUTOPAY\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo2000002\",\"productName\":\"Access Discounts\",\"productSorId\":\"ACCESSDISC\",\"displayGroup\":\"Never\",\"prodDispSequence\":11,\"sorSubGroupClassificationCd\":\"SUBGRPROMO\",\"sorSubGroupClassificationDesc\":\"PROMO SUB GROUP CLASS CODE\",\"spoCategoryCode\":\"ACCESSDISC\",\"isActive\":true,\"isShowcase\":true,\"isMutuallyExclusive\":false},{\"productId\":\"spo2000002\",\"productName\":\"Access Discounts\",\"productSorId\":\"ACCESSDISC\",\"displayGroup\":\"Never\",\"prodDispSequence\":12,\"sorSubGroupClassificationCd\":\"SUBGRPROMO\",\"sorSubGroupClassificationDesc\":\"PROMO SUB GROUP CLASS CODE\",\"spoCategoryCode\":\"ACCESSDISC\",\"isActive\":true,\"isShowcase\":true,\"isMutuallyExclusive\":false},{\"productId\":\"spo4040002\",\"productName\":\"BOOKING AND TAXING ALLOCATION\",\"productSorId\":\"BOOKTAX\",\"displayGroup\":\"Never\",\"prodDispSequence\":13,\"spoCategoryCode\":\"BOOKTAX\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo4040002\",\"productName\":\"BOOKING AND TAXING ALLOCATION\",\"productSorId\":\"BOOKTAX\",\"displayGroup\":\"Never\",\"prodDispSequence\":14,\"spoCategoryCode\":\"BOOKTAX\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo6480019\",\"productName\":\"BYPGRPREQL\",\"productSorId\":\"BYPGRPREQL\",\"displayGroup\":\"Never\",\"prodDispSequence\":15,\"spoCategoryCode\":\"BYPGRPREQL\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo6480019\",\"productName\":\"BYPGRPREQL\",\"productSorId\":\"BYPGRPREQL\",\"displayGroup\":\"Never\",\"prodDispSequence\":16,\"spoCategoryCode\":\"BYPGRPREQL\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo6480019\",\"productName\":\"BYPGRPREQL\",\"productSorId\":\"BYPGRPREQL\",\"displayGroup\":\"Never\",\"prodDispSequence\":17,\"spoCategoryCode\":\"BYPGRPREQL\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo6480019\",\"productName\":\"BYPGRPREQL\",\"productSorId\":\"BYPGRPREQL\",\"displayGroup\":\"Never\",\"prodDispSequence\":18,\"spoCategoryCode\":\"BYPGRPREQL\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo6480010\",\"productName\":\"BYPVREQUAL\",\"productSorId\":\"BYPVREQUAL\",\"displayGroup\":\"Never\",\"prodDispSequence\":19,\"spoCategoryCode\":\"BYPVREQUAL\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo6480010\",\"productName\":\"BYPVREQUAL\",\"productSorId\":\"BYPVREQUAL\",\"displayGroup\":\"Never\",\"prodDispSequence\":20,\"spoCategoryCode\":\"BYPVREQUAL\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo1080004\",\"productName\":\"COMMISSIONABLE GLOBAL OFFERS\",\"productSorId\":\"COMGLB\",\"displayGroup\":\"Never\",\"prodDispSequence\":21,\"spoCategoryCode\":\"COMGLB\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo1520002\",\"productName\":\"DAILY INTERNATIONAL TRAVEL PLAN MUTEX\",\"productSorId\":\"MTXTPTRIG2\",\"displayGroup\":\"Never\",\"prodDispSequence\":22,\"spoCategoryCode\":\"MTXTPTRIG2\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":true},{\"productId\":\"spo1000001\",\"productName\":\"DAILY INTERNATIONAL TRAVEL PLAN MUTEX\",\"productSorId\":\"MTXDITP\",\"displayGroup\":\"Never\",\"prodDispSequence\":23,\"spoCategoryCode\":\"MTXDITP\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":true},{\"productId\":\"spo1360003\",\"productName\":\"DATABANK\",\"productSorId\":\"DATABANK\",\"displayGroup\":\"Never\",\"prodDispSequence\":24,\"spoCategoryCode\":\"DATABANK\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo3720001\",\"productName\":\"DVS/SCM\",\"productSorId\":\"SCMSUB\",\"displayGroup\":\"Never\",\"prodDispSequence\":25,\"spoCategoryCode\":\"SCMSUB\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo3720001\",\"productName\":\"DVS/SCM\",\"productSorId\":\"SCMSUB\",\"displayGroup\":\"Never\",\"prodDispSequence\":26,\"spoCategoryCode\":\"SCMSUB\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo1480002\",\"productName\":\"Data Services\",\"productSorId\":\"ADS\",\"displayGroup\":\"Never\",\"prodDispSequence\":27,\"sorSubGroupClassificationCd\":\"SUBGRPFEAT\",\"sorSubGroupClassificationDesc\":\"FEATURE SUB GROUP CLASS CODE\",\"spoCategoryCode\":\"ADS\",\"isActive\":true,\"isShowcase\":true,\"isMutuallyExclusive\":false},{\"productId\":\"spo1480002\",\"productName\":\"Data Services\",\"productSorId\":\"ADS\",\"displayGroup\":\"Never\",\"prodDispSequence\":28,\"sorSubGroupClassificationCd\":\"SUBGRPFEAT\",\"sorSubGroupClassificationDesc\":\"FEATURE SUB GROUP CLASS CODE\",\"spoCategoryCode\":\"ADS\",\"isActive\":true,\"isShowcase\":true,\"isMutuallyExclusive\":false},{\"productId\":\"spo2000004\",\"productName\":\"Discount Promo\",\"productSorId\":\"DISCPROMO\",\"displayGroup\":\"Never\",\"prodDispSequence\":29,\"spoCategoryCode\":\"DISCPROMO\",\"isActive\":true,\"isShowcase\":true,\"isMutuallyExclusive\":false},{\"productId\":\"spo2000004\",\"productName\":\"Discount Promo\",\"productSorId\":\"DISCPROMO\",\"displayGroup\":\"Never\",\"prodDispSequence\":30,\"spoCategoryCode\":\"DISCPROMO\",\"isActive\":true,\"isShowcase\":true,\"isMutuallyExclusive\":false},{\"productId\":\"spo2680006\",\"productName\":\"IPV6 ROAM TIER MUTEX\",\"productSorId\":\"MTXIPV6\",\"displayGroup\":\"Never\",\"prodDispSequence\":31,\"spoCategoryCode\":\"MTXIPV6\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":true},{\"productId\":\"spo1240001\",\"productName\":\"International (While Traveling Outside the US)\",\"productSorId\":\"GB\",\"displayGroup\":\"Never\",\"prodDispSequence\":32,\"spoCategoryCode\":\"GB\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":true},{\"productId\":\"spo960005\",\"productName\":\"International Travel (While Outside the US)\",\"productSorId\":\"GLOBAL\",\"displayGroup\":\"Never\",\"prodDispSequence\":33,\"sorSubGroupClassificationCd\":\"SUBGRPFEAT\",\"sorSubGroupClassificationDesc\":\"FEATURE SUB GROUP CLASS CODE\",\"spoCategoryCode\":\"GLOBAL\",\"isActive\":true,\"isShowcase\":true,\"isMutuallyExclusive\":false},{\"productId\":\"spo1000002\",\"productName\":\"International Travel (While Outside the US)_TrvlPass\",\"productSorId\":\"INTLDAILY\",\"displayGroup\":\"Never\",\"prodDispSequence\":34,\"spoCategoryCode\":\"INTLDAILY\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo3120001\",\"productName\":\"MUTEX w GCM\",\"productSorId\":\"MUTEXGCM\",\"displayGroup\":\"Never\",\"prodDispSequence\":35,\"spoCategoryCode\":\"MUTEXGCM\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":true},{\"productId\":\"spo3400002\",\"productName\":\"NOSPLANRQD\",\"productSorId\":\"NOSPLANRQD\",\"displayGroup\":\"Never\",\"prodDispSequence\":36,\"spoCategoryCode\":\"NOSPLANRQD\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo3400002\",\"productName\":\"NOSPLANRQD\",\"productSorId\":\"NOSPLANRQD\",\"displayGroup\":\"Never\",\"prodDispSequence\":37,\"spoCategoryCode\":\"NOSPLANRQD\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo3400002\",\"productName\":\"NOSPLANRQD\",\"productSorId\":\"NOSPLANRQD\",\"displayGroup\":\"Never\",\"prodDispSequence\":38,\"spoCategoryCode\":\"NOSPLANRQD\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo2000003\",\"productName\":\"PAPERLESS BILLING\",\"productSorId\":\"PAPERFREE\",\"displayGroup\":\"Never\",\"prodDispSequence\":39,\"spoCategoryCode\":\"PAPERFREE\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo2000003\",\"productName\":\"PAPERLESS BILLING\",\"productSorId\":\"PAPERFREE\",\"displayGroup\":\"Never\",\"prodDispSequence\":40,\"spoCategoryCode\":\"PAPERFREE\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo1360002\",\"productName\":\"SAFETYMODE\",\"productSorId\":\"SAFETYMODE\",\"displayGroup\":\"Never\",\"prodDispSequence\":41,\"spoCategoryCode\":\"SAFETYMODE\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":true},{\"productId\":\"spo4040004\",\"productName\":\"SUBSCRIPTION ELIGIBLE\",\"productSorId\":\"SUBELIG\",\"displayGroup\":\"Never\",\"prodDispSequence\":42,\"spoCategoryCode\":\"SUBELIG\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo4040004\",\"productName\":\"SUBSCRIPTION ELIGIBLE\",\"productSorId\":\"SUBELIG\",\"displayGroup\":\"Never\",\"prodDispSequence\":43,\"spoCategoryCode\":\"SUBELIG\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false},{\"productId\":\"spo3360003\",\"productName\":\"TIERLINE\",\"productSorId\":\"TIERLINE\",\"displayGroup\":\"Never\",\"prodDispSequence\":44,\"spoCategoryCode\":\"TIERLINE\",\"isActive\":false,\"isShowcase\":false,\"isMutuallyExclusive\":false}]}}";
		CatalogResponse request = mapper.readValue(sampleSpoCatalogResponseString, CatalogResponse.class);
		Mono<List<CatalogResponse>> response = catalogServiceHelper.formatSposResponse(Mono.just(request));
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		SpoCatalogItems SpoCatalogItemsObj = new SpoCatalogItems();
		SpoCatalogItemsObj.setSpoId(null);
		SpoCatalogItemsObj.setLevelCode(null);
		SpoCatalogItemsObj.setSkuName(null);
		SpoCatalogItemsObj.setIsReceiptDisplay(false);
		SpoCatalogItemsObj.setMobAppLongDesc("random");
		SpoCatalogItemsObj.setSkuMobAppShortDesc("random");
		SpoCatalogItemsObj.setParentProducts(null);
		request.getData().setSpoCatalogItems(Arrays.asList(SpoCatalogItemsObj));
		StepVerifier.create(catalogServiceHelper.formatSposResponse(Mono.just(request))).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		SpoCatalogItemsObj.setIsReceiptDisplay(true);
		request.getData().setSpoCatalogItems(Arrays.asList(SpoCatalogItemsObj));
		StepVerifier.create(catalogServiceHelper.formatSposResponse(Mono.just(request))).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		request.getData().setSpoCatalogItems(new ArrayList<>());
		StepVerifier.create(catalogServiceHelper.formatSposResponse(Mono.just(request))).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		request.getData().setSpoCatalogItems(null);
		StepVerifier.create(catalogServiceHelper.formatSposResponse(Mono.just(request))).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		request.setData(null);
		StepVerifier.create(catalogServiceHelper.formatSposResponse(Mono.just(request))).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(catalogServiceHelper.formatSposResponse(Mono.just(new CatalogResponse()))).expectComplete();

	}

	@Test
	public void formatSpoResponseTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"data\": {\"spoCatalogItems\": [],\"SpoCategoryCodeProducts\": [{\"productId\": \"spo4120002\",\"productName\": \"5G UWB BOLT ON\",\"productSorId\": \"5GUWBBOLT\",\"displayGroup\": \"Never\",\"prodDispSequence\": \"1\",\"spoCategoryCode\": \"5GUWBBOLT\",\"isActive\": false,\"isShowcase\": false,\"isMutuallyExclusive\": false,\"sorSubGroupClassificationCd\": null,\"sorSubGroupClassificationDesc\": null},{\"productId\": \"spo1200001\",\"productName\": \"TRIGGERSPROVISIONING\",\"productSorId\": \"TP\",\"displayGroup\": \"Never\",\"prodDispSequence\": \"2\",\"spoCategoryCode\": \"TP\",\"isActive\": false,\"isShowcase\": false,\"isMutuallyExclusive\": false,\"sorSubGroupClassificationCd\": \"SUBGRPFEAT\",\"sorSubGroupClassificationDesc\": \"FEATURESUBGROUPCLASSCODE\"}],\"deviceCatalogItems\": null,\"planCatalogItems\": null},\"meta\": null,\"errors\": null,\"planId\": null}";
		CatalogResponse request = mapper.readValue(requestString, CatalogResponse.class);
		CatalogResponse response = catalogServiceHelper.formatSpoResponse(request);
		Assert.assertNull(response.getData());
	}

	@Test
	public void formatSpoResponseTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"data\": null,\"meta\": null,\"errors\": null,\"planId\": null}";
		CatalogResponse request = mapper.readValue(requestString, CatalogResponse.class);
		CatalogResponse response = catalogServiceHelper.formatSpoResponse(request);
		Assert.assertNull(response.getData());
	}

	@Test
	public void formatSpoResponseTest4() throws JsonMappingException, JsonProcessingException {
		CatalogResponse request = null;
		CatalogResponse response = catalogServiceHelper.formatSpoResponse(request);
		Assert.assertNull(response.getData());
	}

	@Test
	public void getPlanSkuMapTest() throws JsonMappingException, JsonProcessingException {
		Collection<String> planIds = new ArrayList<String>(Arrays.asList("1234"));
		String plancatalogResponseString = "{\"data\": {\"planCatalogItems\": [{\"collectionCode\": \"collectionCode\",\"categoryCode\": \"categoryCode\"}]}}";
		PlanCatalogResponse plancatalogResponse = mapper.readValue(plancatalogResponseString, PlanCatalogResponse.class);
		Mono<PlanCatalogResponse> plancatalogResponseMono = Mono.just(plancatalogResponse);
		CatalogResponse catalogResponse = new CatalogResponse();
		Mono<CatalogResponse> catalogResponseMono = Mono.just(catalogResponse);
		when(catalogService.getPlanSkuRedesign(Mockito.any())).thenReturn(plancatalogResponseMono);
		when(catalogService.getPlanSku(Mockito.any())).thenReturn(catalogResponseMono);
		ReflectionTestUtils.setField(catalogServiceHelper, "planSku", true);
		Mono<Map<String, CatalogResponse>> response = catalogServiceHelper.getPlanSkuMap(planIds);
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals("categoryCode", resp.get("1234").getData().getPlanSku().getCategoryCode())).expectComplete().verify();
	}
	@Test
	public void getPlanSkuMapTrueTest() throws JsonMappingException, JsonProcessingException {
		Collection<String> planIds = new ArrayList<String>(Arrays.asList("1234"));
		String plancatalogResponseString = "{\"data\": {\"planCatalogItems\": [{\"collectionCode\": \"collectionCode\",\"categoryCode\": \"categoryCode\", \"isActive\": true, \"isShowcase\": true, \"isMixAndMatch2\": true, \"isMixAndMatch3\": true, \"isLineLevel\": true, \"isAccountLevel\": true, \"isPromoGifter\": true, \"isRestrictAddService\": true, \"isRestrictRemoval\": true, \"isRestrictRemovalWhenSubsidy\": true, \"isRestrictionEnabled\": true}]}}";
		PlanCatalogResponse plancatalogResponse = mapper.readValue(plancatalogResponseString, PlanCatalogResponse.class);
		Mono<PlanCatalogResponse> plancatalogResponseMono = Mono.just(plancatalogResponse);
		CatalogResponse catalogResponse = new CatalogResponse();
		Mono<CatalogResponse> catalogResponseMono = Mono.just(catalogResponse);
		when(catalogService.getPlanSkuRedesign(Mockito.any())).thenReturn(plancatalogResponseMono);
		when(catalogService.getPlanSku(Mockito.any())).thenReturn(catalogResponseMono);
		ReflectionTestUtils.setField(catalogServiceHelper, "planSku", true);
		Mono<Map<String, CatalogResponse>> response = catalogServiceHelper.getPlanSkuMap(planIds);
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals("categoryCode", resp.get("1234").getData().getPlanSku().getCategoryCode())).expectComplete().verify();
	}
	@Test
	public void getPlanSkuMapNoTest() throws JsonMappingException, JsonProcessingException {
		Collection<String> planIds = new ArrayList<String>(Arrays.asList("1234"));
		String plancatalogResponseString = "{\"data\": {\"planCatalogItems\": [{\"collectionCode\": \"collectionCode\",\"categoryCode\": \"categoryCode\"}]}}";
		PlanCatalogResponse plancatalogResponse = mapper.readValue(plancatalogResponseString, PlanCatalogResponse.class);
		Mono<PlanCatalogResponse> plancatalogResponseMono = Mono.just(plancatalogResponse);
		CatalogResponse catalogResponse = new CatalogResponse();
		Mono<CatalogResponse> catalogResponseMono = Mono.just(catalogResponse);
		when(catalogService.getPlanSkuRedesign(Mockito.any())).thenReturn(plancatalogResponseMono);
		when(catalogService.getPlanSku(Mockito.any())).thenReturn(catalogResponseMono);
		ReflectionTestUtils.setField(catalogServiceHelper, "planSku", true);
		Mono<Map<String, CatalogResponse>> response = catalogServiceHelper.getPlanSkuMap(planIds);
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals("categoryCode", resp.get("1234").getData().getPlanSku().getCategoryCode())).expectComplete().verify();
	}

	@Test
	public void getPlanSkuMapTest1() throws JsonMappingException, JsonProcessingException {
		Collection<String> planIds = new ArrayList<String>(Arrays.asList("1234"));
		String plancatalogResponseString = "{\"data\": {\"planCatalogItems\": [{\"collectionCode\": \"collectionCode\",\"categoryCode\": \"categoryCode\"}]}}";
		PlanCatalogResponse plancatalogResponse = mapper.readValue(plancatalogResponseString, PlanCatalogResponse.class);
		Mono<PlanCatalogResponse> plancatalogResponseMono = Mono.just(plancatalogResponse);
		CatalogResponse catalogResponse = new CatalogResponse();
		Mono<CatalogResponse> catalogResponseMono = Mono.just(catalogResponse);
		when(catalogService.getPlanSkuRedesign(Mockito.any())).thenReturn(plancatalogResponseMono);
		when(catalogService.getPlanSku(Mockito.any())).thenReturn(catalogResponseMono);
		ReflectionTestUtils.setField(catalogServiceHelper, "planSku", false);
		StepVerifier.create(catalogServiceHelper.getPlanSkuMap(planIds)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getCatalogDomainDataTest() {
		List<String> planIds = new ArrayList<String>(Arrays.asList("1234"));
		List<String> sorIds = new ArrayList<String>(Arrays.asList("5678"));
		List<String> accessorySkus = new ArrayList<String>(Arrays.asList("5678"));
		CatalogResponse catalogDomainRequest = new CatalogResponse();
		Mono<CatalogResponse> catalogDomainRequestMono = Mono.just(catalogDomainRequest);
		when(catalogService.getCatalogRefData(Mockito.any())).thenReturn(catalogDomainRequestMono);
		ReflectionTestUtils.setField(catalogServiceHelper, "planSku", true);
		Mono<CatalogResponse> response = catalogServiceHelper.getCatalogDomainData(planIds, sorIds, accessorySkus,null,null);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
//		when(catalogService.getCatalogRefData(Mockito.any())).thenReturn(Mono.error(Exception::new));
//		StepVerifier.create(catalogServiceHelper.getCatalogDomainData(planIds, sorIds, accessorySkus,null)).verifyError();

	}

	@Test
	public void getCatalogDomainDataTest3() {
		List<String> planIds = new ArrayList<String>(Arrays.asList("1234"));
		List<String> sorIds = new ArrayList<String>(Arrays.asList("5678"));
		List<String> accessorySkus = new ArrayList<String>(Arrays.asList("5678"));
		CatalogResponse catalogDomainRequest = new CatalogResponse();
		Mono<CatalogResponse> catalogDomainRequestMono = Mono.just(catalogDomainRequest);
		when(catalogService.getCatalogRefData(Mockito.any())).thenReturn(catalogDomainRequestMono);
		ReflectionTestUtils.setField(catalogServiceHelper, "planSku", false);
		StepVerifier.create(catalogServiceHelper.getCatalogDomainData(planIds, sorIds, accessorySkus,null,null)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

	}

	@Test
	public void getCatalogDomainDataTest4() {
		List<String> planIds = new ArrayList<String>(Arrays.asList("1234"));
		List<String> sorIds = new ArrayList<String>(Arrays.asList("5678"));
		List<String> accessorySkus = new ArrayList<String>(Arrays.asList("5678"));
		CatalogResponse catalogDomainRequest = new CatalogResponse();
		Mono<CatalogResponse> catalogDomainRequestMono = Mono.just(catalogDomainRequest);
		when(catalogService.getCatalogRefData(Mockito.any())).thenReturn(catalogDomainRequestMono);
		ReflectionTestUtils.setField(catalogServiceHelper, "planSku", true);
		StepVerifier.create(catalogServiceHelper.getCatalogDomainData(planIds, sorIds, accessorySkus,null,null)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

	}
	@Test
	public void getCatalogDomainDataTest2() {
		List<String> planIds = new ArrayList<String>();
		List<String> sorIds = new ArrayList<String>();
		List<String> accessorySkus = new ArrayList<String>(Arrays.asList("5678"));
		CatalogResponse catalogDomainRequest = new CatalogResponse();
		Mono<CatalogResponse> catalogDomainRequestMono = Mono.just(catalogDomainRequest);
		when(catalogService.getCatalogRefData(Mockito.any())).thenReturn(catalogDomainRequestMono);
		ReflectionTestUtils.setField(catalogServiceHelper, "planSku", true);
		Mono<CatalogResponse> response = catalogServiceHelper.getCatalogDomainData(planIds, sorIds, accessorySkus,null,null);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void getCatalogDomainDataTrueTest() throws JsonProcessingException {
		List<String> planIds = new ArrayList<String>();
		List<String> sorIds = new ArrayList<String>();
		List<String> accessorySkus = new ArrayList<String>(Arrays.asList("5678"));
		String responseString = "{\"data\": {\"deviceCatalogItems\": [{\"productId\":\"dev18800002\",\"productDisplayName\":\"Verizon Internet Gateway\",\"brandName\":\"Arcadyan\",\"isPhone\": true, \"isCallFilterIncluded\":true, \"isSmartPhone\":true, \"isLaptop\": true, \"isTablet\":true, \"isConnectedDevice\":true,\"isHomeSolutions\":true, \"isHomeInternet\":true, \"isBasicPhone\":true,\"isAppleSmartphone\":true,\"isEuiccCapable\":true, \"isSMSCapable\":true, \"isPrePaid\":true, \"isPostPaid\":true, \"isActive\":true,\"isShowcase\":true, \"isSupportOnly\":true, \"isAppleCareEligible\":true, \"daccId\":\"01655\",\"compatibleSimSorIds\":[\"NI-DPSIM5G\",\"BULKSIM5G-SA-MP-A\"],\"equipCode\":[\"5HC\",\"C5G\",\"WWD\",\"L5G\"],\"sorDeviceFamilyType\":\"Tablet Internet Home\",\"sorDeviceType\":\"5GE\",\"sorHdVoiceInd\":false,\"hasDeviceUnlockPolicy\":false,\"sorDeviceCategory\":\"5G Router\",\"numberShareMandatory\":false,\"numberShareCapable\":false}]}}";
		CatalogResponse catalogDomainResponse = mapper.readValue(responseString, CatalogResponse.class);
		Mono<CatalogResponse> catalogDomainRequestMono = Mono.just(catalogDomainResponse);
		when(catalogService.getCatalogRefData(Mockito.any())).thenReturn(catalogDomainRequestMono);
		ReflectionTestUtils.setField(catalogServiceHelper, "planSku", true);
		Mono<CatalogResponse> response = catalogServiceHelper.getCatalogDomainData(planIds, sorIds, accessorySkus,null,null);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getCatalogDomainDataNoTest() throws JsonProcessingException {
		List<String> planIds = new ArrayList<String>();
		List<String> sorIds = new ArrayList<String>();
		List<String> accessorySkus = new ArrayList<String>(Arrays.asList("5678"));
		List<String> featureIds = new ArrayList<>();
		String responseString = "{\"data\": {\"deviceCatalogItems\": [{\"productId\":\"dev18800002\",\"productDisplayName\":\"Verizon Internet Gateway\",\"brandName\":\"Arcadyan\",\"daccId\":\"01655\",\"compatibleSimSorIds\":[\"NI-DPSIM5G\",\"BULKSIM5G-SA-MP-A\"],\"equipCode\":[\"5HC\",\"C5G\",\"WWD\",\"L5G\"],\"sorDeviceFamilyType\":\"Tablet Internet Home\",\"sorDeviceType\":\"5GE\",\"sorHdVoiceInd\":false,\"hasDeviceUnlockPolicy\":false,\"sorDeviceCategory\":\"5G Router\",\"numberShareMandatory\":false,\"numberShareCapable\":false}]}}";
		CatalogResponse catalogDomainResponse = mapper.readValue(responseString, CatalogResponse.class);
		Mono<CatalogResponse> catalogDomainRequestMono = Mono.just(catalogDomainResponse);
		when(catalogService.getCatalogRefData(Mockito.any())).thenReturn(catalogDomainRequestMono);
		ReflectionTestUtils.setField(catalogServiceHelper, "planSku", true);
		Mono<CatalogResponse> response = catalogServiceHelper.getCatalogDomainData(planIds, sorIds, accessorySkus,featureIds,null);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getFeatureCatalogDomainDataNoTest() throws JsonProcessingException {
		List<String> planIds = new ArrayList<String>();
		List<String> sorIds = new ArrayList<String>();
		List<String> accessorySkus = new ArrayList<String>();
		List<String> featureIds = new ArrayList<>(Arrays.asList("81495"));
		String responseString = "{\"data\":{\"featureCatalogItems\":[{\"featureId\":\"81495\",\"skuDisplayName\":\"VisualVoiceMail\",\"skuId\":\"sku626678\",\"skuDisplayNameB2b\":\"VisualVoiceMail\"}]}}";
		CatalogResponse catalogDomainResponse = mapper.readValue(responseString, CatalogResponse.class);
		Mono<CatalogResponse> catalogDomainRequestMono = Mono.just(catalogDomainResponse);
		when(catalogService.getCatalogRefData(Mockito.any())).thenReturn(catalogDomainRequestMono);
		ReflectionTestUtils.setField(catalogServiceHelper, "planSku", true);
		Mono<CatalogResponse> response = catalogServiceHelper.getCatalogDomainData(planIds, sorIds, accessorySkus,featureIds,null);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void getFeatureCatalogDomainDataNullTest() throws JsonProcessingException {
		List<String> planIds = new ArrayList<String>();
		List<String> sorIds = new ArrayList<String>();
		List<String> accessorySkus = new ArrayList<String>();
		List<String> featureIds = new ArrayList<>();
		ReflectionTestUtils.setField(catalogServiceHelper, "planSku", true);
		Mono<CatalogResponse> response = catalogServiceHelper.getCatalogDomainData(planIds, sorIds, accessorySkus,featureIds,null);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void getFeatureCatalogDomainDataPlanIdTest() throws JsonProcessingException {
		List<String> planIds = new ArrayList<String>();
		planIds.add("123");
		List<String> sorIds = new ArrayList<String>();
		List<String> accessorySkus = new ArrayList<String>();
		List<String> featureIds = new ArrayList<>();
		String responseString = "{\"data\":{\"featureCatalogItems\":[{\"featureId\":\"81495\",\"skuDisplayName\":\"VisualVoiceMail\",\"skuId\":\"sku626678\",\"skuDisplayNameB2b\":\"VisualVoiceMail\"}]}}";
		CatalogResponse catalogDomainResponse = mapper.readValue(responseString, CatalogResponse.class);
		when(catalogService.getCatalogRefData(Mockito.any())).thenReturn( Mono.just(catalogDomainResponse));
		ReflectionTestUtils.setField(catalogServiceHelper, "planSku", true);
		Mono<CatalogResponse> response = catalogServiceHelper.getCatalogDomainData(planIds, sorIds, accessorySkus,featureIds,null);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void getFeatureCatalogDomainDataSorIdTest() throws JsonProcessingException {
		List<String> planIds = new ArrayList<String>();
		List<String> sorIds = new ArrayList<String>();
		sorIds.add("123");
		List<String> accessorySkus = new ArrayList<String>();
		List<String> featureIds = new ArrayList<>();
		String responseString = "{\"data\":{\"featureCatalogItems\":[{\"featureId\":\"81495\",\"skuDisplayName\":\"VisualVoiceMail\",\"skuId\":\"sku626678\",\"skuDisplayNameB2b\":\"VisualVoiceMail\"}]}}";
		CatalogResponse catalogDomainResponse = mapper.readValue(responseString, CatalogResponse.class);
		when(catalogService.getCatalogRefData(Mockito.any())).thenReturn( Mono.just(catalogDomainResponse));
		ReflectionTestUtils.setField(catalogServiceHelper, "planSku", true);
		Mono<CatalogResponse> response = catalogServiceHelper.getCatalogDomainData(planIds, sorIds, accessorySkus,featureIds,null);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void getFeatureCatalogDomainDataFeaturesIdTest() throws JsonProcessingException {
		List<String> planIds = new ArrayList<String>();
		List<String> sorIds = new ArrayList<String>();
		List<String> accessorySkus = new ArrayList<String>();
		List<String> featureIds = new ArrayList<>();
		featureIds.add("123");
		List<String> softSKuSorIds = Collections.singletonList(CartConstants.SETUPANDGO);
		String responseString = "{\"data\":{\"featureCatalogItems\":[{\"featureId\":\"81495\",\"skuDisplayName\":\"VisualVoiceMail\",\"skuId\":\"sku626678\",\"skuDisplayNameB2b\":\"VisualVoiceMail\"}]}}";
		CatalogResponse catalogDomainResponse = mapper.readValue(responseString, CatalogResponse.class);
		when(catalogService.getCatalogRefData(Mockito.any())).thenReturn( Mono.just(catalogDomainResponse));
		ReflectionTestUtils.setField(catalogServiceHelper, "planSku", true);
		Mono<CatalogResponse> response = catalogServiceHelper.getCatalogDomainData(planIds, sorIds, accessorySkus,featureIds,softSKuSorIds);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getSoftSkuCatalogResponse() {
		List<String> sorIds = Collections.singletonList(CartConstants.SETUPANDGO);
		when(catalogService.getCatalogRefData(Mockito.any())).thenReturn( Mono.just(Mockito.mock(CatalogResponse.class)));
		ReflectionTestUtils.setField(catalogServiceHelper, "planSku", true);
		Mono<CatalogResponse> response = catalogServiceHelper.getCatalogDomainData(null, null, null,null, sorIds);
		StepVerifier.create(response).assertNext(Assert::assertNotNull).expectComplete().verify();

		when(catalogService.getCatalogRefData(Mockito.any())).thenReturn( Mono.error(new RuntimeException("Failed to get catalog data")));
		catalogServiceHelper.getCatalogDomainData(null, null, null,null, sorIds);
	}
}
