package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.cradle.vo.CradleResponse;
import junit.framework.Assert;
import lombok.SneakyThrows;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.controller.CartBauToNsaRedirectionController;
import onevz.soe.cart.helper.*;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.common.CartServiceAvailablePaths;
import onevz.soe.cart.model.common.CartServiceContextInfo;
import onevz.soe.cart.requests.MvoRequest;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.responses.RPSRedisData;
import onevz.soe.cart.ui.requests.AddDeviceUIRequest;
import onevz.soe.cart.ui.requests.RPSApplePayloadUIRequest;
import onevz.soe.cart.ui.requests.SecondaryDeviceActive;
import onevz.soe.cart.ui.responses.AddDeviceUIResponse;
import onevz.soe.cart.util.CartUtil;
import onevz.soe.cradle.CradleAllocator;
import onevz.soe.omnidl.service.OmniDLService;
import onevz.soe.omnidl.util.DLUtilityService;
import onevz.soe.security.TokenProcessor;
import onevz.soe.security.model.SsoJwtDTO;
import onevz.soe.wsclient.bpm.model.response.AvailablePaths;
import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.env.Environment;
import org.springframework.http.*;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.http.server.reactive.MockServerHttpResponse;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URI;
import java.nio.charset.Charset;
import java.security.SignatureException;
import java.util.*;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;


@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(CartBauToNsaRedirectionController.class)
public class CartBauToNsaRedirectionControllerTest {

	@MockBean
	private UpdateCartHelper cartHelper;

	@MockBean
	private OmniDLService dlService;

	@Autowired
	private CartBauToNsaRedirectionController cartController;

	@Autowired
	private ObjectMapper mapper;

	@MockBean
	private RedisHelper redisHelper;

	@MockBean
	private RedisHelper2 redisHelper2;

	@MockBean
	private RedisHelper3 redisHelper3;

	@MockBean
	private DLUtilityService dlUtilityService;

	@MockBean
	private TokenProcessor tokenProcessor;

	@MockBean
	private CartAddDeviceHelper accDevHelper;

	@MockBean
	private CradleAllocator cradleAllocator;
	
	@MockBean
	private FeatureFlagHelper featureFlagHelper;

	@MockBean
	private CartUtil cartUtil;

	@Before
	public void setup() {
		Mockito.when(cartUtil.validateAccessUser(Mockito.any(), Mockito.anyString()))
				.thenReturn(Mono.just(Boolean.TRUE));
	}

	@Test
	public void addStepTest_ErrorId_4500() throws IOException, SignatureException {
		when(featureFlagHelper.fetchFiosLoginPDPPearlFFlagStatus()).thenReturn(Mono.just(true));
		String requestString = "{ \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		String responseString = "{\"errors\":[{\"namespace\":\"cxp-shopping-services\",\"id\":\"4500\",\"message\":\"Please initiate a Trial in conversion Landing Page\",\"name\":\"SHOPPING_TRIAL_CONVERSION_BUSINESS_EXCEPTION\",\"ProactiveChatCustomMSG\":\"We see you are experiencing issues with your order. Chat now to connect to a live agent for further assistance\",\"proactiveChatIndicator\":\"Y\"}]}";
		String responseString_3246 = "{\"errors\":[{\"namespace\":\"cxp-shopping-services\",\"id\":\"3246\",\"message\":\"Please initiate a Trial in conversion Landing Page\",\"name\":\"SHOPPING_TRIAL_CONVERSION_BUSINESS_EXCEPTION\",\"ProactiveChatCustomMSG\":\"We see you are experiencing issues with your order. Chat now to connect to a live agent for further assistance\",\"proactiveChatIndicator\":\"Y\"}]}";
		String responseString_3261 = "{\"errors\":[{\"namespace\":\"cxp-shopping-services\",\"id\":\"3261\",\"message\":\"Please initiate a Trial in conversion Landing Page\",\"name\":\"SHOPPING_TRIAL_CONVERSION_BUSINESS_EXCEPTION\",\"ProactiveChatCustomMSG\":\"We see you are experiencing issues with your order. Chat now to connect to a live agent for further assistance\",\"proactiveChatIndicator\":\"Y\"}]}";
		String responseString_3238 = "{\"errors\":[{\"namespace\":\"cxp-shopping-services\",\"id\":\"3238\",\"message\":\"Please initiate a Trial in conversion Landing Page\",\"name\":\"SHOPPING_TRIAL_CONVERSION_BUSINESS_EXCEPTION\",\"ProactiveChatCustomMSG\":\"We see you are experiencing issues with your order. Chat now to connect to a live agent for further assistance\",\"proactiveChatIndicator\":\"Y\"}]}";
		String responseString_Erorr_id_Empty = "{\"errors\":[{\"namespace\":\"cxp-shopping-services\",\"id\":\"\",\"message\":\"Please initiate a Trial in conversion Landing Page\",\"name\":\"SHOPPING_TRIAL_CONVERSION_BUSINESS_EXCEPTION\",\"ProactiveChatCustomMSG\":\"We see you are experiencing issues with your order. Chat now to connect to a live agent for further assistance\",\"proactiveChatIndicator\":\"Y\"}]}";
		
		
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
		URI url = URI.create("http://localhost/add-step?X-Host=verizon.com&deviceId=GA01221-US&isHumDevice=true");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).cookie(new HttpCookie("RepIdCookieText","E170K")).header("X-Host", "verizon.com").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(new SsoJwtDTO());
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(request));
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(sampleRedisData));

		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456","GA01221-US", responseString, null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of(responseString), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456","", responseString, null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of(responseString), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		request.getData().getLines().get(0).getDevice().setId("GA01221");
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any() ,Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(request));
		StepVerifier.create(controllerResponse).assertNext(Assert::assertNotNull).expectComplete().verify();
		
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(mapper.readValue(responseString_3246, AddDeviceUIResponse.class)));
		controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456","", responseString, null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of(responseString), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		request.getData().getLines().get(0).getDevice().setId("GA01221");
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any() ,Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(request));
		StepVerifier.create(controllerResponse).assertNext(Assert::assertNotNull).expectComplete().verify();
		
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(mapper.readValue(responseString_3261, AddDeviceUIResponse.class)));
		controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456","", responseString, null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of(responseString), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		request.getData().getLines().get(0).getDevice().setId("GA01221");
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any() ,Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(request));
		StepVerifier.create(controllerResponse).assertNext(Assert::assertNotNull).expectComplete().verify();
		
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(mapper.readValue(responseString_3238, AddDeviceUIResponse.class)));
		controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456","", responseString, null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of(responseString), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		request.getData().getLines().get(0).getDevice().setId("GA01221");
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any() ,Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(request));
		StepVerifier.create(controllerResponse).assertNext(Assert::assertNotNull).expectComplete().verify();
		
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(mapper.readValue(responseString_Erorr_id_Empty, AddDeviceUIResponse.class)));
		controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456","", responseString, null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of(responseString), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		request.getData().getLines().get(0).getDevice().setId("GA01221");
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any() ,Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(request));
		StepVerifier.create(controllerResponse).assertNext(Assert::assertNotNull).expectComplete().verify();
		
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(mapper.readValue(responseString_Erorr_id_Empty, AddDeviceUIResponse.class)));
		controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456","", responseString, null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of(responseString), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		request.getData().getLines().get(0).getDevice().setId("GA01221");
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any() ,Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(request));
		StepVerifier.create(controllerResponse).assertNext(Assert::assertNotNull).expectComplete().verify();
		
		when(featureFlagHelper.fetchFiosLoginPDPPearlFFlagStatus()).thenReturn(Mono.just(false));
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(mapper.readValue(responseString, AddDeviceUIResponse.class)));
		controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456","", responseString, null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of(responseString), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		request.getData().getLines().get(0).getDevice().setId("GA01221");
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any() ,Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(request));
		StepVerifier.create(controllerResponse).assertNext(Assert::assertNotNull).expectComplete().verify();
		
		String responseString_4500_diffName = "{\"errors\":[{\"namespace\":\"cxp-shopping-services\",\"id\":\"4500\",\"message\":\"Please initiate a Trial in conversion Landing Page\",\"name\":\"EXCEPTION\",\"ProactiveChatCustomMSG\":\"We see you are experiencing issues with your order. Chat now to connect to a live agent for further assistance\",\"proactiveChatIndicator\":\"Y\"}]}";
		when(featureFlagHelper.fetchMarketingHomeFFlagStatus(Mockito.anyString())).thenReturn(Mono.just(true));
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(mapper.readValue(responseString_4500_diffName, AddDeviceUIResponse.class)));
		controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456","", responseString, null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of(responseString), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		request.getData().getLines().get(0).getDevice().setId("GA01221");
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any() ,Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(request));
		StepVerifier.create(controllerResponse).assertNext(Assert::assertNotNull).expectComplete().verify();
	}

	@Test
	public void addStepTest() throws IOException, SignatureException {
		String requestString = "{ \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
		URI url = URI.create("http://localhost/add-step?X-Host=verizon.com&deviceId=GA01221-US&isHumDevice=true");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).cookie(new HttpCookie("RepIdCookieText","E170K")).header("X-Host", "verizon.com").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		when(featureFlagHelper.fetchFiosLoginPDPPearlFFlagStatus()).thenReturn(Mono.just(true));
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(new SsoJwtDTO());
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(request));
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456","GA01221-US", responseString, null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of(responseString), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456","", responseString, null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of(responseString), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		request.getData().getLines().get(0).getDevice().setId("GA01221");
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any() ,eq(httpHeader),eq(Optional.of(true)),eq(Optional.of("36")))).thenReturn(Mono.just(request));
		StepVerifier.create(controllerResponse).assertNext(Assert::assertNotNull).expectComplete().verify();

		controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456","", "VERIZON_EDGE", null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of(responseString), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		request.getData().getLines().get(0).getDevice().setId("GA01221");
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any() ,eq(httpHeader),eq(Optional.of(true)),eq(Optional.of("36")))).thenReturn(Mono.just(request));
		StepVerifier.create(controllerResponse).assertNext(Assert::assertNotNull).expectComplete().verify();

		controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456","", "", null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of(responseString), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		request.getData().getLines().get(0).getDevice().setId("GA01221");
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any() ,eq(httpHeader),eq(Optional.of(true)),eq(Optional.of("36")))).thenReturn(Mono.just(request));
		StepVerifier.create(controllerResponse).assertNext(Assert::assertNotNull).expectComplete().verify();

		controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456","", null, null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of(responseString), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		request.getData().getLines().get(0).getDevice().setId("GA01221");
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any() ,eq(httpHeader),eq(Optional.of(true)),eq(Optional.of("36")))).thenReturn(Mono.just(request));
		StepVerifier.create(controllerResponse).assertNext(Assert::assertNotNull).expectComplete().verify();
	}

	@Test
	public void addStepTest2() throws IOException, SignatureException {
		String requestString = "{ \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
		URI url = URI.create("http://localhost/add-step?deviceId=GA01221-US&isHumDevice=true");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).cookie(new HttpCookie("RepIdCookieText","E170K")).header("X-Host", "verizon.com").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(featureFlagHelper.fetchFiosLoginPDPPearlFFlagStatus()).thenReturn(Mono.just(true));
		when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(new SsoJwtDTO());
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any() ,eq(httpHeader),eq(Optional.of(true)),eq(Optional.of("36")))).thenReturn(Mono.just(request));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456", "GA01221-US", responseString, null, responseString, null, null, Optional.empty(),Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.of("true"), Optional.empty(), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(false),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(requestString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
		controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456", "GA01221-US", responseString, null, responseString, null, null, Optional.empty(),Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.of("SmartWatch"), Optional.of("true"), Optional.empty(), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(false),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(requestString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
		SsoJwtDTO ssoJwtDTO = new SsoJwtDTO();
		ssoJwtDTO.setVzwRoles("mobileSecure");
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(ssoJwtDTO);
		controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456", "GA01221-US", responseString, null, responseString, null, null, Optional.empty(),Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.of("SmartWatch"), Optional.of("true"), Optional.empty(), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(false),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(requestString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).assertNext(resp -> org.junit.Assert.assertNotNull(resp)).expectComplete().verify();
		ssoJwtDTO.setVzwRoles("accountManager");
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(ssoJwtDTO);
		controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456", "GA01221-US", responseString, null, responseString, null, null, Optional.empty(),Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.of("SmartWatch"), Optional.of("true"), Optional.empty(), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(false),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(requestString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
		controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456", "GA01221-US", responseString, null, responseString, null, null, Optional.empty(),Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.of("true"), Optional.empty(), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(false),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(requestString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void addStep_Cash_OnlyTest() throws IOException, SignatureException {
		String requestString = "{ \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		String responseString = "{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2024.07.03.17.49.04-140.1208807252081\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-14968623-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"CASHONLY_IND\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"CASHONLY_IND\",\"processAction\":\"\",\"cradleFlowJourney\":\"NEXTGEN_EC\"},\"customerInfo\":{\"nocByod\":false,\"accountNumber\":\"0281331412-00001\",\"cartCreator\":\"5082441904\",\"processingMTN\":\"\",\"registerNumber\":0,\"number_share_capable\":\"\",\"e911_addr_ind\":\"\",\"existingCase\":\"false\",\"noc\":false,\"myvPage\":false},\"cartInfo\":{\"orderRestrictions\":{\"accountLevelChangeEligibility\":[{\"isAddNewLineAllowed\":false,\"inEligibilityReasonCode\":\"CASHONLY_IND\"}]},\"cartItemCount\":0,\"cartId\":\"972a0edb-40de-4a85-9954-d83f83477428\",\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false,\"instantCreditAmount\":0},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}";
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
		URI url = URI.create("http://localhost/add-step?deviceId=GA01221-US&isHumDevice=true");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).cookie(new HttpCookie("RepIdCookieText","E170K")).header("X-Host", "verizon.com").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(new SsoJwtDTO());
		when(featureFlagHelper.fetchFiosLoginPDPPearlFFlagStatus()).thenReturn(Mono.just(true));
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any() ,eq(httpHeader),eq(Optional.of(true)),eq(Optional.of("36")))).thenReturn(Mono.just(request));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456", "GA01221-US", responseString, null, responseString, null, null, Optional.empty(),Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.of("true"), Optional.empty(), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(false),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(requestString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
		controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456", "GA01221-US", responseString, null, responseString, null, null, Optional.empty(),Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.of("SmartWatch"), Optional.of("true"), Optional.empty(), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(false),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(requestString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
		SsoJwtDTO ssoJwtDTO = new SsoJwtDTO();
		ssoJwtDTO.setVzwRoles("mobileSecure");
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(ssoJwtDTO);
		controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456", "GA01221-US", responseString, null, responseString, null, null, Optional.empty(),Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.of("SmartWatch"), Optional.of("true"), Optional.empty(), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(false),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(requestString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).assertNext(resp -> org.junit.Assert.assertNotNull(resp)).expectComplete().verify();
		ssoJwtDTO.setVzwRoles("accountManager");
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(ssoJwtDTO);
		controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456", "GA01221-US", responseString, null, responseString, null, null, Optional.empty(),Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.of("SmartWatch"), Optional.of("true"), Optional.empty(), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(false),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(requestString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
		controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456", "GA01221-US", responseString, null, responseString, null, null, Optional.empty(),Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.of("true"), Optional.empty(), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(false),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(requestString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}
	@Test
	public void addStepTest_EC() throws IOException, SignatureException {
		String requestString = "{ \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		String responseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-ECOM\", \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"Cases\": [], \"caseId\": \"SOP-329-E01\", \"contextInfo\": { \"pendingOrderAccountLevel\": \" \", \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"MTNSelectionPage\", \"processAction\": \"\", \"cradleFlowJourney\": \"NEXTGEN_EC\" }, \"customerInfo\": { \"lookupMTN\": \" \", \"accountNumber\": \"0820215913-00001\" } } } } }";
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);

		URI url = URI.create("http://localhost/add-step?deviceId=GA01221-US&isHumDevice=true");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).cookie(new HttpCookie("RepIdCookieText","E170K")).header("X-Host", "verizon.com").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(featureFlagHelper.fetchFiosLoginPDPPearlFFlagStatus()).thenReturn(Mono.just(true));
		when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(new SsoJwtDTO());
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(request));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456", "GA01221-US", responseString, null, responseString, null, null, Optional.empty(),Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.of("true"), Optional.empty(), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(false),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(false),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

//	@SneakyThrows
	@Test
	public void getNSAThrottleListNSA_AAL_Test() throws  Exception{
		URI url = URI.create("http://localhost/getNSAThrottleList");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).header("X-Host", "verizon.com").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		Map<String, String> requestMap = new HashMap<>();
		String redisDataString = "{\"mtn\":\"1234567890\",\"channel\":\"Digital\",\"custType\":\"EPP\"}";
		Map<String,Object> sampleRedisData = mapper.readValue(redisDataString, Map.class);
		String outPut = "{\"cradleFlowJourney\": \"\",\n" +
				"\t\t\"throttleList\": \"|5GHome|\"}";
		CradleResponse response = new CradleResponse();
		response.setOutPut(outPut);
		when(redisHelper3.getMTNFromRedis(Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper3.getDataFromSession(Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		when(cradleAllocator.invokeReactiveCradle(httpHeader,httpResponse,requestMap)).thenReturn(Mono.just(response));
		Mono<ResponseEntity<String>> resp=cartController.getNSAThrottleList(httpHeader,httpResponse,requestMap);
		StepVerifier.create(resp).assertNext(resp1 -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

	}
	@Test
	public void getNSAThrottleListNSA_NSE_Test() throws  Exception{
		URI url = URI.create("http://localhost/getNSAThrottleList");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).header("X-Host", "verizon.com").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		Map<String, String> requestMap = new HashMap<>();
		String redisDataString = "{\"mtn\":\"1234567890\",\"channel\":\"Digital\"}";
		Map<String,Object> sampleRedisData = mapper.readValue(redisDataString, Map.class);
		String outPut = "{\"cradleFlowJourney\": \"\",\n" +
				"\t\t\"throttleList\": \"|5GHomeP|\"}";
		CradleResponse response = new CradleResponse();
		response.setOutPut(outPut);
		when(redisHelper3.getMTNFromRedis(Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper3.getDataFromSession(Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		when(cradleAllocator.invokeReactiveCradle(httpHeader,httpResponse,requestMap)).thenReturn(Mono.just(response));
		Mono<ResponseEntity<String>> resp=cartController.getNSAThrottleList(httpHeader,httpResponse,requestMap);
		StepVerifier.create(resp).assertNext(resp1 -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

	}

	@Test
	public void getNSAThrottleListTestBAU() throws  Exception{
		URI url = URI.create("http://localhost/getNSAThrottleList");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).header("X-Host", "verizon.com").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		Map<String, String> requestMap = new HashMap<>();
		String redisDataString = "{\"mtn\":\"1234567890\",\"channel\":\"Digital\"}";
		Map<String,Object> sampleRedisData = mapper.readValue(redisDataString, Map.class);
		String outPut = "{\"cradleFlowJourney\": \"\",\n" +
				"\t\t\"throttleList\": \"|PROSPECT_PROTECTION_REDESIGN|\"}";
		CradleResponse response = new CradleResponse();
		response.setOutPut(outPut);
		when(redisHelper3.getMTNFromRedis(Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper3.getDataFromSession(Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		when(cradleAllocator.invokeReactiveCradle(httpHeader,httpResponse,requestMap)).thenReturn(Mono.just(response));
		Mono<ResponseEntity<String>> resp=cartController.getNSAThrottleList(httpHeader,httpResponse,requestMap);
		StepVerifier.create(resp).assertNext(resp1 -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

	}

	@Test
	public void addStepTest3() throws IOException, SignatureException {
		String requestString = "{ \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
		URI url = URI.create("http://localhost/add-step?X-Host=verizon.com&deviceId=GA01221-US&isHumDevice=true");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).cookie(new HttpCookie("RepIdCookieText","E170K")).header("X-Host", "verizon.com").header("channelId", "VZW-DOTCOM-TAB").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(new SsoJwtDTO());
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any() ,eq(httpHeader),eq(Optional.of(true)),eq(Optional.of("36")))).thenReturn(Mono.just(request));
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456","GA01221-US", responseString, null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of("true"), Optional.ofNullable(null),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void addStepTest4() throws IOException, SignatureException {
		String requestString = "{ \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
		URI url = URI.create("http://localhost/add-step?X-Host=verizon.com&deviceId=GA01221-US&isHumDevice=true");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).cookie(new HttpCookie("RepIdCookieText","")).header("X-Forwarded-Host", "verizon.com").cookie(new HttpCookie("channelId", "VZW-DOTCOM")).build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(new SsoJwtDTO());
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any() ,eq(httpHeader),eq(Optional.of(true)),eq(Optional.of("36")))).thenReturn(Mono.just(request));
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456","GA01221-US", responseString, null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of("true"), Optional.ofNullable(null),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("55571"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}
	@Test
	public void rpsApplePayloadTest() throws JsonMappingException, JsonProcessingException, UnsupportedEncodingException, SignatureException {
		URI url = URI.create("http://localhost/rpsApplePayload");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).header("X-Host", "verizon.com").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		String requestString = "{\"carrierPostData\":\"transaction-id=spcabcd12323&service-code=MSSU&token=MTQ4OTYwNDc0MjQ2OUBmYmM0MjFlNWVjNmY1MWJiZmMwMDhmYjY3MGYxYmI2NzVlZTY3MjZj&primary-device-mdn=8455597930&device-user-agent=Entitlement%20iOS%2F1.3&associated-subscription=2&esim-download-delay=10\",\"secondary-device-active\":{\"eid\":\"89049032005008882600031910586762\",\"display-name\":\"John's iPad\",\"device-imei\":\"356347105542208\",\"iccids\":[]},\"testScreen\":true,\"testNSA\":true,\"testreplace\":true}";
		RPSApplePayloadUIRequest request = mapper.readValue(requestString, RPSApplePayloadUIRequest.class);
		String encryptedPayloadReq = "";
		when(redisHelper2.upsertRPSFlowDataIntoRedis(Mockito.<RPSRedisData>any())).thenReturn(Mono.just(true));
		Mono<ResponseEntity<GenericResponse>> response = cartController.rpsApplePayload(httpHeader, httpResponse, request, encryptedPayloadReq);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(HttpStatus.FOUND, resp.getStatusCode())).expectComplete().verify();
	}

	@Test
	public void rpsApplePayloadErrorTest() throws JsonMappingException, JsonProcessingException, UnsupportedEncodingException, SignatureException {
		URI url = URI.create("http://localhost/rpsApplePayload");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).header("X-Host", "verizon.com").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		String requestString = "{\"carrierPostData\":\"transaction-id=spcabcd12323&service-code=MSSU&token=MTQ4OTYwNDc0MjQ2OUBmYmM0MjFlNWVjNmY1MWJiZmMwMDhmYjY3MGYxYmI2NzVlZTY3MjZj&primary-device-mdn=8455597930&device-user-agent=Entitlement%20iOS%2F1.3&associated-subscription=2&esim-download-delay=10\",\"secondary-device-active\":{\"eid\":\"89049032005008882600031910586762\",\"display-name\":\"John's iPad\",\"device-imei\":\"356347105542208\",\"iccids\":[]},\"testScreen\":true,\"testNSA\":true,\"testreplace\":true}";
		RPSApplePayloadUIRequest request = mapper.readValue(requestString, RPSApplePayloadUIRequest.class);
		String encryptedPayloadReq = "";
		when(redisHelper2.upsertRPSFlowDataIntoRedis(Mockito.<RPSRedisData>any())).thenReturn(Mono.just(false));
		Mono<ResponseEntity<GenericResponse>> response = cartController.rpsApplePayload(httpHeader, httpResponse, request, encryptedPayloadReq);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, resp.getStatusCode())).expectComplete().verify();
	}

	@Test
	public void rpsApplePayloadTest1() throws JsonMappingException, JsonProcessingException, UnsupportedEncodingException, SignatureException {
		URI url = URI.create("http://localhost/rpsApplePayload");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).header("X-Forwarded-Host", "verizon.com").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		String requestString = "{\"carrierPostData\":\"transaction-id=spcabcd12323&service-code=MSSU&token=MTQ4OTYwNDc0MjQ2OUBmYmM0MjFlNWVjNmY1MWJiZmMwMDhmYjY3MGYxYmI2NzVlZTY3MjZj&primary-device-mdn=8455597930&device-user-agent=Entitlement%20iOS%2F1.3&associated-subscription=2&esim-download-delay=10\",\"secondary-device-active\":{\"eid\":\"89049032005008882600031910586762\",\"display-name\":\"John's iPad\",\"device-imei\":\"356347105542208\",\"iccids\":[]},\"testScreen\":true,\"testNSA\":true,\"testreplace\":true}";
		RPSApplePayloadUIRequest request = mapper.readValue(requestString, RPSApplePayloadUIRequest.class);
		String encryptedPayloadReq = "";
		when(redisHelper2.upsertRPSFlowDataIntoRedis(Mockito.<RPSRedisData>any())).thenReturn(Mono.just(true));
		Mono<ResponseEntity<GenericResponse>> response = cartController.rpsApplePayload(httpHeader, httpResponse, request, encryptedPayloadReq);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(HttpStatus.FOUND, resp.getStatusCode())).expectComplete().verify();
	}

	@Test
	public void formatRPSRedisData() throws JsonMappingException, JsonProcessingException, UnsupportedEncodingException, SignatureException {
		String requestString = "{\"carrierPostData\":\"transaction-id=spcabcd12323&service-code=MSSU&token=MTQ4OTYwNDc0MjQ2OUBmYmM0MjFlNWVjNmY1MWJiZmMwMDhmYjY3MGYxYmI2NzVlZTY3MjZj&primary-device-mdn=8455597930&device-user-agent=Entitlement%20iOS%2F1.3&associated-subscription=2&esim-download-delay=10\",\"secondary-device-active\":{\"eid\":\"89049032005008882600031910586762\",\"display-name\":\"John's iPad\",\"device-imei\":\"356347105542208\",\"iccids\":[]},\"testScreen\":true,\"testNSA\":true,\"testreplace\":true}";
		RPSApplePayloadUIRequest request = mapper.readValue(requestString, RPSApplePayloadUIRequest.class);
		String encryptedPayloadReq = "payload";
		when(redisHelper2.upsertRPSFlowDataIntoRedis(Mockito.<RPSRedisData>any())).thenReturn(Mono.just(true));
		RPSRedisData response = cartController.formatRPSRedisData(request, encryptedPayloadReq);
		Assert.assertTrue(response.isTestScreen());
	}



	@Test
	public void addStepTest5() throws IOException, SignatureException {
		String requestString = "{ \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		String responseString = "{\"serviceHeader\": {\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\",\"correlationId\": \"soe-cart-2022.03.31.18.59.12-109.46873092960219\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"contextInfo\": {\"availablePaths\": [{\"path\": \"MTNSelectionPage\"},{\"path\": \"ExistingCasePage\"}],\"callReason\": \"SalesOrderPurchase\",\"processStep\": \"MTNSelectionPage\",\"processAction\": \"\"},\"customerInfo\": {\"accountNumber\": \"0524970859-00001\",\"cartCreator\": \"9859816627\",\"processingMTN\": \"\",\"registerNumber\": 0,\"existingCase\": \"\"},\"cartInfo\": {\"cartItemCount\": 0,\"discountPromoTotal\": 0.0,\"registerNumber\": 0,\"expressCheckout\": true,\"protectionNotRequired\": false,\"orderRestrictions\": {\"accountLevelChangeEligibility\": [{\"reasonCode\": \"PAST_DUE_BALANCE\"}]}},\"processMTNList\": [{\"mtn\": \"\",\"completedprocessSteps\": [\"GridWallPDP\",\"MTNSelectionPage\",\"DeviceConfigurator\",\"ShoppingCart\",\"ShoppingCart\",\"ShoppingCart\",\"GridWallPDP\",\"GridWallPDP\",\"ShoppingCart\",\"ShoppingCart\",\"GridWallPDP\",\"GridWallPDP\",\"ShoppingCart\",\"ShoppingCart\",\"ShoppingCart\",\"GridWallPDP\"]}]}}}}";
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
		URI url = URI.create("http://localhost/add-step?X-Host=verizon.com&deviceId=GA01221-US&isHumDevice=false");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).cookie(new HttpCookie("RepIdCookieText",null)).header("X-Host", "verizon.com").header("channelId", "VZW-DOTCOM-TAB").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		when(featureFlagHelper.fetchFiosLoginPDPPearlFFlagStatus()).thenReturn(Mono.just(true));
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(new SsoJwtDTO());
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any() ,eq(httpHeader),eq(Optional.of(true)),eq(Optional.of("36")))).thenReturn(Mono.just(request));
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456","GA01221-US", responseString, null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of("false"), Optional.ofNullable(null),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("55571"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void addStepTest6() throws IOException, SignatureException {
		String requestString = "{ \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		String responseString = "{\"serviceHeader\": {\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\",\"correlationId\": \"soe-cart-2022.03.31.18.59.12-109.46873092960219\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"contextInfo\": {\"availablePaths\": [{\"path\": \"MTNSelectionPage\"},{\"path\": \"ExistingCasePage\"}],\"callReason\": \"SalesOrderPurchase\",\"processStep\": \"MTNSelectionPage\",\"processAction\": \"\"},\"customerInfo\": {\"accountNumber\": \"0524970859-00001\",\"cartCreator\": \"9859816627\",\"processingMTN\": \"\",\"registerNumber\": 0,\"existingCase\": \"\"},\"cartInfo\": {\"cartItemCount\": 0,\"discountPromoTotal\": 0.0,\"registerNumber\": 0,\"protectionNotRequired\": false,\"orderRestrictions\":{\"accountLevelChangeEligibility\": [{\"reasonCode\": \"PENDING_ORDER\"}]}},\"processMTNList\": [{\"mtn\": \"\",\"completedprocessSteps\": [\"GridWallPDP\",\"MTNSelectionPage\",\"DeviceConfigurator\",\"ShoppingCart\",\"ShoppingCart\",\"ShoppingCart\",\"GridWallPDP\",\"GridWallPDP\",\"ShoppingCart\",\"ShoppingCart\",\"GridWallPDP\",\"GridWallPDP\",\"ShoppingCart\",\"ShoppingCart\",\"ShoppingCart\",\"GridWallPDP\"]}]}}}}";
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
		URI url = URI.create("http://localhost/add-step?X-Host=verizon.com&deviceId=GA01221-US&isHumDevice=false");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).cookie(new HttpCookie("RepIdCookieText","E170K")).header("X-Host", "verizon.com").header("channelId", "VZW-DOTCOM-TAB").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(new SsoJwtDTO());
		when(featureFlagHelper.fetchFiosLoginPDPPearlFFlagStatus()).thenReturn(Mono.just(true));
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any() ,eq(httpHeader),eq(Optional.of(true)),eq(Optional.of("36")))).thenReturn(Mono.just(request));
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456","GA01221-US", responseString, null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of("false"), Optional.ofNullable(null),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("55571"),Optional.of(false),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void addStepTest7() throws IOException, SignatureException {
		String requestString = "{ \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		String responseString = "{\"serviceHeader\": {\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\",\"correlationId\": \"soe-cart-2022.03.31.18.59.12-109.46873092960219\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"contextInfo\": {\"availablePaths\": [{\"path\": \"MTNSelectionPage\"},{\"path\": \"ExistingCasePage\"}],\"callReason\": \"SalesOrderPurchase\",\"processStep\": \"MTNSelectionPage\",\"processAction\": \"\"},\"customerInfo\": {\"accountNumber\": \"0524970859-00001\",\"cartCreator\": \"9859816627\",\"processingMTN\": \"\",\"registerNumber\": 0,\"existingCase\": \"existingCase\"},\"cartInfo\": {\"cartItemCount\": 0,\"discountPromoTotal\": 0.0,\"registerNumber\": 0,\"protectionNotRequired\": false,\"expressCheckout\": true,\"lines\": [{\"mtn\": \"9859816627\"}]},\"processMTNList\": [{\"mtn\": \"\",\"completedprocessSteps\": [\"GridWallPDP\",\"MTNSelectionPage\",\"DeviceConfigurator\",\"ShoppingCart\",\"ShoppingCart\",\"ShoppingCart\",\"GridWallPDP\",\"GridWallPDP\",\"ShoppingCart\",\"ShoppingCart\",\"GridWallPDP\",\"GridWallPDP\",\"ShoppingCart\",\"ShoppingCart\",\"ShoppingCart\",\"GridWallPDP\"]}]}}}}";
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
		URI url = URI.create("http://localhost/add-step?X-Host=verizon.com&deviceId=GA01221-US&isHumDevice=false");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).cookie(new HttpCookie("RepIdCookieText","E170K")).header("X-Host", "verizon.com").header("channelId", "VZW-DOTCOM-TAB").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(new SsoJwtDTO());
		when(featureFlagHelper.fetchFiosLoginPDPPearlFFlagStatus()).thenReturn(Mono.just(true));
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any() ,eq(httpHeader),eq(Optional.of(true)),eq(Optional.of("36")))).thenReturn(Mono.just(request));
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456","GA01221-US", responseString, null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of("false"), Optional.ofNullable(null),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("55571"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void addStepTest8() throws IOException, SignatureException {
		String requestString = "{ \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		String responseString = "{\"serviceHeader\": {\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\",\"correlationId\": \"soe-cart-2022.03.31.18.59.12-109.46873092960219\"},\"serviceBody\": {\"serviceResponse\": {\"context\": null}}}";
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
		URI url = URI.create("http://localhost/add-step?X-Host=verizon.com&deviceId=GA01221-US&isHumDevice=false");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).cookie(new HttpCookie("RepIdCookieText","E170K")).header("X-Host", "verizon.com").header("channelId", "VZW-DOTCOM-TAB").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(featureFlagHelper.fetchFiosLoginPDPPearlFFlagStatus()).thenReturn(Mono.just(true));
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(new SsoJwtDTO());
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any() ,eq(httpHeader),eq(Optional.of(true)),eq(Optional.of("36")))).thenReturn(Mono.just(request));
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456","GA01221-US", responseString, null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of("false"), Optional.ofNullable(null),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("55571"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void addStepErrorTest() throws IOException, SignatureException {
		String requestString = "{ \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		String responseString = "{\"errors\":null,\"serviceHeader\": {\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\",\"correlationId\": \"soe-cart-2022.03.31.18.59.12-109.46873092960219\"},\"serviceBody\": {\"serviceResponse\": {\"context\": null}}}";
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
		CartError error = new CartError();
		List<CartError> errorList = new ArrayList<CartError>();
		errorList.add(error);
		response.setErrors(errorList);
		URI url = URI.create("http://localhost/add-step?X-Host=verizon.com&deviceId=GA01221-US&isHumDevice=false");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).cookie(new HttpCookie("RepIdCookieText","E170K")).header("X-Host", "verizon.com").header("channelId", "VZW-DOTCOM-TAB").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		when(featureFlagHelper.fetchFiosLoginPDPPearlFFlagStatus()).thenReturn(Mono.just(true));
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(new SsoJwtDTO());
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any() ,eq(httpHeader),eq(Optional.of(true)),eq(Optional.of("36")))).thenReturn(Mono.just(request));
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456","GA01221-US", responseString, null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of("false"), Optional.ofNullable(null),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("55571"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void mvoNsaThrottle() throws IOException, SignatureException {
		String requestString = "{\n" +
				"\t\"offerId\": \"NS_1401\",\n" +
				"\t\"rank\": \"1234\",\n" +
				"\t\"provisionDispositionID\": \"1234\",\n" +
				"\t\"complianceCode\": \"ABCD\",\n" +
				"\t\"param1\": \"52427635\",\n" +
				"\t\"t\": \"33897\",\n" +
				"\t\"categoryType\": \"e911\",\n" +
				"\t\"myOffer\": {\n" +
				"\t\t\"serviceOffer\": {\n" +
				"\t\t\t\"t\": \"sfa\",\n" +
				"\t\t\t\"offerId\": \"4214\",\n" +
				"\t\t\t\"fulfillmentCode\": \"31241\",\n" +
				"\t\t\t\"restricted\": \"1312\",\n" +
				"\t\t\t\"accountLevel\": \"sefewrw\",\n" +
				"\t\t\t\"type\": \"AAL\",\n" +
				"\t\t\t\"deviceType\": \"aahfh\",\n" +
				"\t\t\t\"mmtier\": \"asdasf\"\n" +
				"\t\t}\n" +
				"\t},\n" +
				"\t\"wuf\": \"ssdf\",\n" +
				"\t\"requires\": \"fsafasfa\",\n" +
				"\t\"requiredTurnIn\": \"sfsf\",\n" +
				"\t\"mmtier\": \"fsdfs\",\n" +
				"\t\"bc\": \"fsdfs\",\n" +
				"\t\"restrictedOffer\": \"sdfsdf\",\n" +
				"\t\"currentPlanId\": \"adada\",\n" +
				"\t\"upgradeReason\": \"aasdsad\",\n" +
				"\t\"StartPageName\": \"adasd\",\n" +
				"\t\"currentUrl\": \"dasfaf\",\n" +
				"\t\"customerId\": \"adasfa\",\n" +
				"\t\"mtn\": \"afaf\"\n" +
				"}";
		String responseString = "{\"errors\":null,\"serviceHeader\": {\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\",\"correlationId\": \"soe-cart-2022.03.31.18.59.12-109.46873092960219\"},\"serviceBody\": {\"serviceResponse\": {\"context\": null}}}";
		MvoRequest request = mapper.readValue(requestString, MvoRequest.class);
		AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
		URI url = URI.create("http://localhost/mvoNsaThrottle?X-Host=verizon.com&deviceId=GA01221-US&isHumDevice=false");
		HttpHeaders headers = new HttpHeaders();
		headers.set("X-Host", "verizon.com");
		headers.set("channelId", "VZW-DOTCOM");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).headers(headers).build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		when(redisHelper2.upsertMvoDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.mvoNsaThrottle(httpHeader, httpResponse, request, Optional.ofNullable(null), Optional.ofNullable(null));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void mvoNsaThrottle1() throws IOException, SignatureException {
		String requestString = "{\n" +
				"\t\"offerId\": \"NS_1401\",\n" +
				"\t\"rank\": \"1234\",\n" +
				"\t\"provisionDispositionID\": \"1234\",\n" +
				"\t\"complianceCode\": \"ABCD\",\n" +
				"\t\"param1\": \"52427635\",\n" +
				"\t\"t\": \"33897\",\n" +
				"\t\"categoryType\": \"e911\",\n" +
				"\t\"myOffer\": {\n" +
				"\t\t\"serviceOffer\": {\n" +
				"\t\t\t\"t\": \"sfa\",\n" +
				"\t\t\t\"offerId\": \"4214\",\n" +
				"\t\t\t\"fulfillmentCode\": \"31241\",\n" +
				"\t\t\t\"restricted\": \"1312\",\n" +
				"\t\t\t\"accountLevel\": \"sefewrw\",\n" +
				"\t\t\t\"type\": \"EUP\",\n" +
				"\t\t\t\"deviceType\": \"aahfh\",\n" +
				"\t\t\t\"mmtier\": \"asdasf\"\n" +
				"\t\t}\n" +
				"\t},\n" +
				"\t\"wuf\": \"ssdf\",\n" +
				"\t\"requires\": \"fsafasfa\",\n" +
				"\t\"requiredTurnIn\": \"sfsf\",\n" +
				"\t\"mmtier\": \"fsdfs\",\n" +
				"\t\"bc\": \"fsdfs\",\n" +
				"\t\"restrictedOffer\": \"sdfsdf\",\n" +
				"\t\"currentPlanId\": \"adada\",\n" +
				"\t\"upgradeReason\": \"aasdsad\",\n" +
				"\t\"StartPageName\": \"adasd\",\n" +
				"\t\"currentUrl\": \"dasfaf\",\n" +
				"\t\"customerId\": \"adasfa\",\n" +
				"\t\"mtn\": \"afaf\"\n" +
				"}";
		String responseString = "{\"errors\":null,\"serviceHeader\": {\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\",\"correlationId\": \"soe-cart-2022.03.31.18.59.12-109.46873092960219\"},\"serviceBody\": {\"serviceResponse\": {\"context\": null}}}";
		MvoRequest request = mapper.readValue(requestString, MvoRequest.class);
		AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
		URI url = URI.create("http://localhost/mvoNsaThrottle?X-Host=verizon.com&deviceId=GA01221-US&isHumDevice=false");
		HttpHeaders headers = new HttpHeaders();
		headers.set("X-Host", "verizon.com");
		headers.set("channelId", "VZW-DOTCOM");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).headers(headers).build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		when(redisHelper2.upsertMvoDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.mvoNsaThrottle(httpHeader, httpResponse, request, Optional.ofNullable(null), Optional.ofNullable(null));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void mvoNsaThrottle3() throws IOException, SignatureException {
		String requestString = "{\n" +
				"\t\"offerId\": \"NS_1401\",\n" +
				"\t\"rank\": \"1234\",\n" +
				"\t\"provisionDispositionID\": \"1234\",\n" +
				"\t\"complianceCode\": \"ABCD\",\n" +
				"\t\"param1\": \"52427635\",\n" +
				"\t\"t\": \"33897\",\n" +
				"\t\"categoryType\": \"e911\",\n" +
				"\t\"myOffer\": {\n" +
				"\t\t\"serviceOffer\": {\n" +
				"\t\t\t\"t\": \"sfa\",\n" +
				"\t\t\t\"offerId\": \"4214\",\n" +
				"\t\t\t\"fulfillmentCode\": \"31241\",\n" +
				"\t\t\t\"restricted\": \"1312\",\n" +
				"\t\t\t\"accountLevel\": \"sefewrw\",\n" +
				"\t\t\t\"type\": \"ENC\",\n" +
				"\t\t\t\"deviceType\": \"aahfh\",\n" +
				"\t\t\t\"mmtier\": \"asdasf\"\n" +
				"\t\t}\n" +
				"\t},\n" +
				"\t\"wuf\": \"ssdf\",\n" +
				"\t\"requires\": \"fsafasfa\",\n" +
				"\t\"requiredTurnIn\": \"sfsf\",\n" +
				"\t\"mmtier\": \"fsdfs\",\n" +
				"\t\"bc\": \"fsdfs\",\n" +
				"\t\"restrictedOffer\": \"sdfsdf\",\n" +
				"\t\"currentPlanId\": \"adada\",\n" +
				"\t\"upgradeReason\": \"aasdsad\",\n" +
				"\t\"StartPageName\": \"adasd\",\n" +
				"\t\"currentUrl\": \"dasfaf\",\n" +
				"\t\"customerId\": \"adasfa\",\n" +
				"\t\"mtn\": \"afaf\"\n" +
				"}";
		String responseString = "{\"errors\":null,\"serviceHeader\": {\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\",\"correlationId\": \"soe-cart-2022.03.31.18.59.12-109.46873092960219\"},\"serviceBody\": {\"serviceResponse\": {\"context\": null}}}";
		MvoRequest request = mapper.readValue(requestString, MvoRequest.class);
		AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
		URI url = URI.create("http://localhost/mvoNsaThrottle?X-Host=verizon.com&deviceId=GA01221-US&isHumDevice=false");
		HttpHeaders headers = new HttpHeaders();
		headers.set("X-Host", "verizon.com");
		headers.set("channelId", "VZW-DOTCOM");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).headers(headers).build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		when(redisHelper2.upsertMvoDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.mvoNsaThrottle(httpHeader, httpResponse, request, Optional.ofNullable(null), Optional.ofNullable(null));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void mvoNsaThrottle4() throws IOException, SignatureException {
		String requestString = "{\n" +
				"\t\"offerId\": \"NS_14\",\n" +
				"\t\"rank\": \"1234\",\n" +
				"\t\"provisionDispositionID\": \"1234\",\n" +
				"\t\"complianceCode\": \"ABCD\",\n" +
				"\t\"param1\": \"52427635\",\n" +
				"\t\"t\": \"33897\",\n" +
				"\t\"categoryType\": \"e911\",\n" +
				"\t\"myOffer\": {\n" +
				"\t\t\"serviceOffer\": {\n" +
				"\t\t\t\"t\": \"sfa\",\n" +
				"\t\t\t\"offerId\": \"4214\",\n" +
				"\t\t\t\"fulfillmentCode\": \"31241\",\n" +
				"\t\t\t\"restricted\": \"1312\",\n" +
				"\t\t\t\"accountLevel\": \"sefewrw\",\n" +
				"\t\t\t\"type\": \"ENC\",\n" +
				"\t\t\t\"deviceType\": \"aahfh\",\n" +
				"\t\t\t\"mmtier\": \"asdasf\"\n" +
				"\t\t}\n" +
				"\t},\n" +
				"\t\"wuf\": \"ssdf\",\n" +
				"\t\"requires\": \"fsafasfa\",\n" +
				"\t\"requiredTurnIn\": \"sfsf\",\n" +
				"\t\"mmtier\": \"fsdfs\",\n" +
				"\t\"bc\": \"fsdfs\",\n" +
				"\t\"restrictedOffer\": \"sdfsdf\",\n" +
				"\t\"currentPlanId\": \"adada\",\n" +
				"\t\"upgradeReason\": \"aasdsad\",\n" +
				"\t\"StartPageName\": \"adasd\",\n" +
				"\t\"currentUrl\": \"dasfaf\",\n" +
				"\t\"customerId\": \"adasfa\",\n" +
				"\t\"mtn\": \"afaf\"\n" +
				"}";
		String responseString = "{\"errors\":null,\"serviceHeader\": {\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\",\"correlationId\": \"soe-cart-2022.03.31.18.59.12-109.46873092960219\"},\"serviceBody\": {\"serviceResponse\": {\"context\": null}}}";
		MvoRequest request = mapper.readValue(requestString, MvoRequest.class);
		AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
		URI url = URI.create("http://localhost/mvoNsaThrottle?X-Host=verizon.com&deviceId=GA01221-US&isHumDevice=false");
		HttpHeaders headers = new HttpHeaders();
		headers.set("X-Host", "verizon.com");
		headers.set("channelId", "VZW-DOTCOM");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).headers(headers).build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		when(redisHelper2.upsertMvoDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.mvoNsaThrottle(httpHeader, httpResponse, request, Optional.ofNullable(null), Optional.ofNullable(null));
		StepVerifier.create(controllerResponse).expectError(IllegalArgumentException.class).verify();
	}

	@Test
	public void mvoNsaThrottleTest() throws JsonMappingException, JsonProcessingException, UnsupportedEncodingException, SignatureException {
		String requestString = "{\"startPageName\": \"start\"}";
		MvoRequest request = mapper.readValue(requestString, MvoRequest.class);
		URI url = URI.create("http://localhost/mvoNsaThrottle?X-Host=verizon.com&deviceId=GA01221-US&isHumDevice=false");
		HttpHeaders headers = new HttpHeaders();
		headers.set("X-Forwarded-Host", "verizon.com");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).headers(headers).build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(null);
		when(redisHelper2.upsertMvoDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.mvoNsaThrottle(httpHeader, httpResponse, request, Optional.ofNullable(null), Optional.ofNullable(null));
		StepVerifier.create(controllerResponse).expectError(IllegalArgumentException.class).verify();
	}

	@Test
	public void mvoNsaThrottleTest2() throws JsonMappingException, JsonProcessingException, UnsupportedEncodingException, SignatureException {
		String requestString = "{\"startPageName\": \"start\",\"myOffer\": {}}";
		MvoRequest request = mapper.readValue(requestString, MvoRequest.class);
		URI url = URI.create("http://localhost/mvoNsaThrottle?X-Host=verizon.com&deviceId=GA01221-US&isHumDevice=false");
		MockServerHttpRequest headers = MockServerHttpRequest.method(HttpMethod.GET, url).header("channelId", "VZW-DOTCOM").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(new SsoJwtDTO());
		when(redisHelper2.upsertMvoDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.mvoNsaThrottle(headers, httpResponse, request, Optional.ofNullable(null), Optional.ofNullable(null));
		StepVerifier.create(controllerResponse).expectError(IllegalArgumentException.class).verify();
	}

	@Test
	public void mvoNsaThrottleTest3() throws JsonMappingException, JsonProcessingException, UnsupportedEncodingException, SignatureException {
		String requestString = "{\"startPageName\": \"start\",\"myOffer\": {\"serviceOffer\": {\"type\": \"NSE\"}}}";
		MvoRequest request = mapper.readValue(requestString, MvoRequest.class);
		URI url = URI.create("http://localhost/mvoNsaThrottle?X-Host=verizon.com&deviceId=GA01221-US&isHumDevice=false");
		MockServerHttpRequest headers = MockServerHttpRequest.method(HttpMethod.GET, url).header("channelId", "VZW-DOTCOM").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(new SsoJwtDTO());
		when(redisHelper2.upsertMvoDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.mvoNsaThrottle(headers, httpResponse, request, Optional.ofNullable(null), Optional.ofNullable(null));
		StepVerifier.create(controllerResponse).expectError(IllegalArgumentException.class).verify();
	}

	@Test
	public void mvoNsaThrottleTest4() throws JsonMappingException, JsonProcessingException, UnsupportedEncodingException, SignatureException {
		String requestString = "{\"startPageName\": \"\"}";
		MvoRequest request = mapper.readValue(requestString, MvoRequest.class);
		URI url = URI.create("http://localhost/mvoNsaThrottle?X-Host=verizon.com&deviceId=GA01221-US&isHumDevice=false");
		MockServerHttpRequest headers = MockServerHttpRequest.method(HttpMethod.GET, url).header("channelId", "VZW-DOTCOM").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(new SsoJwtDTO());
		when(redisHelper2.upsertMvoDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.mvoNsaThrottle(headers, httpResponse, request, Optional.ofNullable(null), Optional.ofNullable(null));
		StepVerifier.create(controllerResponse).expectError(IllegalArgumentException.class).verify();
	}

	@Test
	public void mvoNsaThrottleTest5() throws JsonMappingException, JsonProcessingException, UnsupportedEncodingException, SignatureException {
		String requestString = "{\"startPageName\": \"\",\"myOffer\": {\"serviceOffer\": {\"type\": \"UPG\"}}}";
		MvoRequest request = mapper.readValue(requestString, MvoRequest.class);
		URI url = URI.create("http://localhost/mvoNsaThrottle?deviceId=GA01221-US&isHumDevice=false");
		MockServerHttpRequest headers = MockServerHttpRequest.method(HttpMethod.GET, url).header("channelId", "VZW-DOTCOM").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(new SsoJwtDTO());
		when(redisHelper2.upsertMvoDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.mvoNsaThrottle(headers, httpResponse, request, Optional.ofNullable(null), Optional.ofNullable(null));
		StepVerifier.create(controllerResponse).expectError(IllegalArgumentException.class).verify();
	}

	@Test
	public void mvoNsaThrottleTest6() throws JsonMappingException, JsonProcessingException, UnsupportedEncodingException, SignatureException {
		String requestString = "{\"startPageName\": \"\",\"myOffer\": {}}";
		MvoRequest request = mapper.readValue(requestString, MvoRequest.class);
		URI url = URI.create("http://localhost/mvoNsaThrottle?deviceId=GA01221-US&isHumDevice=false");
		MockServerHttpRequest headers = MockServerHttpRequest.method(HttpMethod.GET, url).header("channelId", "VZW-DOTCOM").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(new SsoJwtDTO());
		when(redisHelper2.upsertMvoDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.mvoNsaThrottle(headers, httpResponse, request, Optional.ofNullable(null), Optional.ofNullable(null));
		StepVerifier.create(controllerResponse).expectError(IllegalArgumentException.class).verify();
	}

	@Test
	public void populateThrottlingKibanaTest() {
		Map<String, Object> map = new HashMap<>();
		cartController.populateThrottlingKibana(null);

		cartController.populateThrottlingKibana(map);

		map.put("key", "value");
		cartController.populateThrottlingKibana(map);

		map.put("key", true);
		cartController.populateThrottlingKibana(map);
	}

	@Test
	public void getNSAThrottleListTest() {
		URI url = URI.create("http://localhost/getNSAThrottleList");
		MockServerHttpRequest request = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		MockServerHttpResponse response = new MockServerHttpResponse();
		Mono<ResponseEntity<String>> monoResponse = cartController.getNSAThrottleList(request, response, null);
		StepVerifier.create(monoResponse).expectNextCount(0).verifyComplete();
	}

	@Test
	public void getNSAThrottleListTest2() throws JsonMappingException, JsonProcessingException {
		URI url = URI.create("http://localhost/getNSAThrottleList");
		MockServerHttpRequest request = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		MockServerHttpResponse response = new MockServerHttpResponse();
		Map<String, Object> map = new HashMap<>();
		Map<String, String> cradleDataMap = new HashMap<>();
		cradleDataMap.put("throttleList", null);
		when(redisHelper3.getMTNFromRedis(Mockito.any())).thenReturn(Mono.just(map));
		when(cradleAllocator.invokeReactiveCradle(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(new CradleResponse()));
		Mono<ResponseEntity<String>> monoResponse = cartController.getNSAThrottleList(request, response, cradleDataMap);
		StepVerifier.create(monoResponse).expectNextCount(0).verifyComplete();
	}

	@Test
	public void getNSAThrottleListTest3() throws JsonMappingException, JsonProcessingException {
		URI url = URI.create("http://localhost/getNSAThrottleList");
		MockServerHttpRequest request = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		MockServerHttpResponse response = new MockServerHttpResponse();
		Map<String, Object> map = new HashMap<>();
		Map<String, String> cradleDataMap = new HashMap<>();
		map.put("mtn", null);
		map.put("channel", null);
		cradleDataMap.put("throttleList", null);
		when(redisHelper3.getMTNFromRedis(Mockito.any())).thenReturn(Mono.just(map));
		when(cradleAllocator.invokeReactiveCradle(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(new CradleResponse()));
		Mono<ResponseEntity<String>> monoResponse = cartController.getNSAThrottleList(request, response, cradleDataMap);
		StepVerifier.create(monoResponse).expectNextCount(0).verifyComplete();
	}

	@Test
	public void formatRPSRedisDataTest() throws JsonMappingException, JsonProcessingException {
		RPSApplePayloadUIRequest request = new RPSApplePayloadUIRequest();
		request.setSecondaryDeviceActive(new SecondaryDeviceActive());
		RPSRedisData response = cartController.formatRPSRedisData(request, "payload");
		Assert.assertEquals("payload", response.getEncryptedPayload());
	}

	@Test
	public void formatRPSRedisDataTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"carrierPostData\": \"associated-subscription= &esim-download-delay= &primary-device-mdn= &service-code= &device-user-agent= &transaction-id= &token= \"}";
		RPSApplePayloadUIRequest request = mapper.readValue(requestString, RPSApplePayloadUIRequest.class);
		request.setSecondaryDeviceActive(new SecondaryDeviceActive());
		RPSRedisData response = cartController.formatRPSRedisData(request, "payload");
		Assert.assertEquals("payload", response.getEncryptedPayload());
	}

	@Test
	public void addStepTest9() throws JsonMappingException, JsonProcessingException, UnsupportedEncodingException, SignatureException {
		String requestString = "{ \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		String responseString = "{\"errors\": [{},{\"id\": \"3261\"},{\"id\": \"3238\"},{\"id\": \"3263\"},{\"id\": \"326\"},{\"id\": \"3246\"}],\"serviceHeader\": {\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\",\"correlationId\": \"soe-cart-2022.03.31.18.59.12-109.46873092960219\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"contextInfo\": {\"availablePaths\": [{\"path\": \"MTNSelectionPage\"},{\"path\": \"ExistingCasePage\"}],\"callReason\": \"SalesOrderPurchase\",\"processStep\": \"MTNSelectionPage\",\"processAction\": \"\"},\"customerInfo\": {\"accountNumber\": \"0524970859-00001\",\"cartCreator\": \"9859816627\",\"processingMTN\": \"\",\"registerNumber\": 0,\"existingCase\": \"existingCase\"},\"cartInfo\": {\"cartItemCount\": 0,\"discountPromoTotal\": 0.0,\"registerNumber\": 0,\"protectionNotRequired\": false,\"expressCheckout\": true,\"lines\": [{\"mtn\": \"9859816627\"}]},\"processMTNList\": [{\"mtn\": \"\",\"completedprocessSteps\": [\"GridWallPDP\",\"MTNSelectionPage\",\"DeviceConfigurator\",\"ShoppingCart\",\"ShoppingCart\",\"ShoppingCart\",\"GridWallPDP\",\"GridWallPDP\",\"ShoppingCart\",\"ShoppingCart\",\"GridWallPDP\",\"GridWallPDP\",\"ShoppingCart\",\"ShoppingCart\",\"ShoppingCart\",\"GridWallPDP\"]}]}}}}";
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
		URI url = URI.create("http://localhost/add-step?X-Host=verizon.com&deviceId=GA01221-US&isHumDevice=false");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).cookie(new HttpCookie("RepIdCookieText","E170K")).header("Accept", "application/json").cookie(new HttpCookie("channelId", "VZW-DOTCOM")).build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(featureFlagHelper.fetchFiosLoginPDPPearlFFlagStatus()).thenReturn(Mono.just(true));
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(null);
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any() ,eq(httpHeader),eq(Optional.of(true)),eq(Optional.of("36")))).thenReturn(Mono.just(request));
		when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456","GA01221-US", responseString, null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of("false"), Optional.ofNullable(null),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("55571"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(false),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).expectError(IllegalArgumentException.class).verify();
	}

	@Test
	public void addStepTest10() throws JsonMappingException, JsonProcessingException, UnsupportedEncodingException, SignatureException {
		String requestString = "{ \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\"}, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		String responseString = "{\"serviceHeader\": {\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\",\"correlationId\": \"soe-cart-2022.03.31.18.59.12-109.46873092960219\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"contextInfo\": {\"availablePaths\": [{\"path\": \"MTNSelectionPage\"},{\"path\": \"ExistingCasePage\"}],\"callReason\": \"SalesOrderPurchase\",\"processStep\": \"MTNSelectionPage\",\"processAction\": \"\"},\"customerInfo\": {\"accountNumber\": \"0524970859-00001\",\"cartCreator\": \"9859816627\",\"processingMTN\": \"\",\"registerNumber\": 0,\"existingCase\": \"existingCase\"},\"cartInfo\": {\"orderRestrictions\": {},\"cartItemCount\": 0,\"discountPromoTotal\": 0.0,\"registerNumber\": 0,\"protectionNotRequired\": false,\"expressCheckout\": true,\"processMTNList\": [{\"mtn\": \"\",\"completedprocessSteps\": [\"GridWallPDP\",\"MTNSelectionPage\",\"DeviceConfigurator\",\"ShoppingCart\",\"ShoppingCart\",\"ShoppingCart\",\"GridWallPDP\",\"GridWallPDP\",\"ShoppingCart\",\"ShoppingCart\",\"GridWallPDP\",\"GridWallPDP\",\"ShoppingCart\",\"ShoppingCart\",\"ShoppingCart\",\"GridWallPDP\"]}]}}}}}";
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
		URI url = URI.create("http://localhost/add-step?X-Host=verizon.com&deviceId=GA01221-US&isHumDevice=false");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).header("Accept", "application").header("X-Host", "jwt").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(null);
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any() ,eq(httpHeader),eq(Optional.of(true)),eq(Optional.of("36")))).thenReturn(Mono.just(request));
		when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456","GA01221-US", responseString, null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of("false"), Optional.ofNullable(null),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("55571"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).expectError(IllegalArgumentException.class).verify();
	}
	@Test
	public void addStepCradleFlowJourneyANDsetProcessSteptest() throws IOException, SignatureException
	{
		when(featureFlagHelper.fetchFiosLoginPDPPearlFFlagStatus()).thenReturn(Mono.just(true));
		String requestString = "{ \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		String responseString = "{\"serviceHeader\": {\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\",\"correlationId\": \"soe-cart-2022.03.31.18.59.12-109.46873092960219\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"contextInfo\": {\"availablePaths\": [{\"path\": \"MTNSelectionPage\"},{\"path\": \"ExistingCasePage\"}],\"callReason\": \"SalesOrderPurchase\",\"processStep\": \"MTNSelectionPage\",\"processAction\": \"\"},\"customerInfo\": {\"accountNumber\": \"0524970859-00001\",\"cartCreator\": \"9859816627\",\"processingMTN\": \"\",\"registerNumber\": 0,\"existingCase\": \"existingCase\"},\"cartInfo\": {\"orderRestrictions\": {},\"cartItemCount\": 0,\"discountPromoTotal\": 0.0,\"registerNumber\": 0,\"protectionNotRequired\": false,\"expressCheckout\": true,\"processMTNList\": [{\"mtn\": \"\",\"completedprocessSteps\": [\"GridWallPDP\",\"MTNSelectionPage\",\"DeviceConfigurator\",\"ShoppingCart\",\"ShoppingCart\",\"ShoppingCart\",\"GridWallPDP\",\"GridWallPDP\",\"ShoppingCart\",\"ShoppingCart\",\"GridWallPDP\",\"GridWallPDP\",\"ShoppingCart\",\"ShoppingCart\",\"ShoppingCart\",\"GridWallPDP\"]}]}}}}}";

		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
		response.getServiceBody().getServiceResponse().getContext().getContextInfo().setCradleFlowJourney("NEXTGEN_EC");
		response.getServiceBody().getServiceResponse().getContext().getContextInfo().setProcessStep("DEVICECONFIGURATOR");
		URI url = URI.create("http://localhost/add-step?X-Host=verizon.com&deviceId=GA01221-US&isHumDevice=true");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).cookie(new HttpCookie("RepIdCookieText","E170K")).header("X-Host", "verizon.com").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(new SsoJwtDTO());
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(request));
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(sampleRedisData));

		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456","GA01221-US", responseString, null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of(responseString), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		response.getServiceBody().getServiceResponse().getContext().getContextInfo().setProcessStep("invalid");
		Mono<ResponseEntity<GenericResponse>> controllerResponse1 = cartController.addStep(httpHeader, httpResponse, "123456","GA01221-US", responseString, null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of(responseString), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse1).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		response.getServiceBody().getServiceResponse().getContext().getContextInfo().setProcessStep("MTNSelectionPage");
		Mono<ResponseEntity<GenericResponse>> controllerResponse2 = cartController.addStep(httpHeader, httpResponse, "123456","GA01221-US", responseString, null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of(responseString), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse2).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}
		@Test
	public void addStepTest11() throws JsonMappingException, JsonProcessingException, UnsupportedEncodingException, SignatureException {
		String requestString = "{ \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\"}, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		String responseString = "{\"serviceHeader\": {\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\",\"correlationId\": \"soe-cart-2022.03.31.18.59.12-109.46873092960219\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"contextInfo\": {\"availablePaths\": [{\"path\": \"MTNSelectionPage\"},{\"path\": \"ExistingCasePage\"}],\"callReason\": \"SalesOrderPurchase\",\"processStep\": \"MTNSelectionPage\",\"processAction\": \"\"},\"customerInfo\": {\"accountNumber\": \"0524970859-00001\",\"cartCreator\": \"9859816627\",\"processingMTN\": \"\",\"registerNumber\": 0,\"existingCase\": \"existingCase\"},\"cartInfo\": {\"orderRestrictions\": {},\"cartItemCount\": 0,\"discountPromoTotal\": 0.0,\"registerNumber\": 0,\"protectionNotRequired\": false,\"expressCheckout\": true,\"processMTNList\": [{\"mtn\": \"\",\"completedprocessSteps\": [\"GridWallPDP\",\"MTNSelectionPage\",\"DeviceConfigurator\",\"ShoppingCart\",\"ShoppingCart\",\"ShoppingCart\",\"GridWallPDP\",\"GridWallPDP\",\"ShoppingCart\",\"ShoppingCart\",\"GridWallPDP\",\"GridWallPDP\",\"ShoppingCart\",\"ShoppingCart\",\"ShoppingCart\",\"GridWallPDP\"]}]}}}}}";
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
		URI url = URI.create("http://localhost/add-step?X-Host=verizon.com&deviceId=GA01221-US&isHumDevice=false");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).header("Accept", "application").header("X-Forwarded-Host", "jwt").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(null);
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any() ,eq(httpHeader),eq(Optional.of(true)),eq(Optional.of("36")))).thenReturn(Mono.just(request));
		when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456","GA01221-US", responseString, null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of("false"), Optional.ofNullable(null),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("55571"),Optional.of(false),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).expectError(IllegalArgumentException.class).verify();
	}

	

	@Test
	public void addStepTest14() throws JsonMappingException, JsonProcessingException, UnsupportedEncodingException, SignatureException {
		String requestString = "{ \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\"}, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		String responseString = "{\"serviceHeader\": {\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\",\"correlationId\": \"soe-cart-2022.03.31.18.59.12-109.46873092960219\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"contextInfo\": {},\"showAALPromoIntercept\": {},\"customerInfo\": {\"accountNumber\": \"0524970859-00001\",\"cartCreator\": \"9859816627\",\"processingMTN\": \"\",\"registerNumber\": 0,\"existingCase\": \"existingCase\"},\"cartInfo\": {\"orderRestrictions\": {\"accountLevelChangeEligibility\": [{\"reasonCode\": \"ACCOUNT\"}]},\"lines\": [{}],\"cartItemCount\": 0,\"discountPromoTotal\": 0.0,\"registerNumber\": 0,\"protectionNotRequired\": false,\"processMTNList\": [{\"mtn\": \"\",\"completedprocessSteps\": [\"GridWallPDP\",\"MTNSelectionPage\",\"DeviceConfigurator\",\"ShoppingCart\",\"ShoppingCart\",\"ShoppingCart\",\"GridWallPDP\",\"GridWallPDP\",\"ShoppingCart\",\"ShoppingCart\",\"GridWallPDP\",\"GridWallPDP\",\"ShoppingCart\",\"ShoppingCart\",\"ShoppingCart\",\"GridWallPDP\"]}]}}}}}";
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
		URI url = URI.create("http://localhost/add-step?X-Host=verizon.com&deviceId=GA01221-US&isHumDevice=false");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).cookie(new HttpCookie("RepIdCookieText","E170K")).header("Accept", "application").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		when(featureFlagHelper.fetchFiosLoginPDPPearlFFlagStatus()).thenReturn(Mono.just(true));
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(null);
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any() ,eq(httpHeader),eq(Optional.of(true)),eq(Optional.of("36")))).thenReturn(Mono.just(request));
		when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456","GA01221-US", responseString, null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of("false"), Optional.ofNullable(null),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("55571"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).expectError(IllegalArgumentException.class).verify();
	}
	
	@Test
	public void addStepTestContextInfoCheck() throws IOException, SignatureException {
		var addDeviceUIResponse = mapper.readValue("/adddevice-response-nsa.json", AddDeviceUIResponse.class);
		addDeviceUIResponse.getServiceBody().getServiceResponse().getContext().setContextInfo(null);
		var data = readJson("/cart-redis-data.json", CartRedisData.class);
		// if you can changes the request
		var request = getAddDeviceUIRequest();
		mockDataAddStep(addDeviceUIResponse, data,request);

		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addStep(getHttpRequest(), new MockServerHttpResponse(), "123456", "GA01221-US", "responseString", null, "responseString", null, null, Optional.of("responseString"), Optional.of("responseString"), Optional.of("responseString"), Optional.of("responseString"), Optional.of("responseString"), Optional.of("responseString"), Optional.of("responseString"), Optional.of("responseString"), Optional.of("responseString"), Optional.of("true"), Optional.of("false"), Optional.ofNullable(null), Optional.of("true"), Optional.of("true"), Optional.of("true"), Optional.of("true"), Optional.of("55571"), Optional.of(true), Optional.of("Y"), Optional.of(false), Optional.of(false), Optional.of(false), Optional.of("responseString"), Optional.of(false), Optional.of("1796"), Optional.of("17965"), Optional.of(true), Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse)
				.assertNext(resp -> Assert.assertEquals(HttpStatus.FOUND, resp.getStatusCode()))
				.expectComplete().verify();

	}
	
	private <T> T readJson(final String fileName,Class<T> className) throws IOException {
		String json = IOUtils.toString(Objects.requireNonNull(this.getClass().getResourceAsStream(fileName)), Charset.defaultCharset());
		return mapper.readValue(json, className);
	}
	
	private MockServerHttpRequest getHttpRequest() {
		return MockServerHttpRequest.post("http://localhost/add-step?X-Host=verizon.com&deviceId=GA01221-US&isHumDevice=false")
				.headers(getHeadersValues())
				.cookie(new HttpCookie("digital_ig_session", UUID.randomUUID().toString()))
				.cookie(new HttpCookie("channelId", "VZW-DOTCOM"))
				.build();
	}
	
	private MultiValueMap<String, String> getHeadersValues() {
		final MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
		headers.set("digital_ig_session", UUID.randomUUID().toString());
		headers.set("channelId", "CHANNEL_ID");
		return headers;
	}
	
	@Test
	@SneakyThrows
	public void addStepForBauDataTest() throws IOException, SignatureException {
		var addDeviceUIResponse = mapper.readValue("/adddevice-response-nsa.json", AddDeviceUIResponse.class);
		var data = readJson("/cart-redis-data.json", CartRedisData.class);
		// if you can changes the request
		var request = getAddDeviceUIRequest();
		mockDataAddStep(addDeviceUIResponse, data,request);
		when(featureFlagHelper.fetchFiosLoginPDPPearlFFlagStatus()).thenReturn(Mono.just(true));

		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addStep(getHttpRequest(), new MockServerHttpResponse(), "123456", "GA01221-US", "responseString", null, "responseString", null, null, Optional.of("responseString"), Optional.of("responseString"), Optional.of("responseString"), Optional.of("responseString"), Optional.of("responseString"), Optional.of("responseString"), Optional.of("responseString"), Optional.of("responseString"), Optional.of("responseString"), Optional.of("true"), Optional.of("false"), Optional.ofNullable(null), Optional.of("true"), Optional.of("true"), Optional.of("true"), Optional.of("true"), Optional.of("55571"), Optional.of(true), Optional.of("Y"), Optional.of(false), Optional.of(false), Optional.of(false), Optional.of("responseString"), Optional.of(false), Optional.of("1796"), Optional.of("17965"), Optional.of(true), Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse)
				.assertNext(resp -> Assert.assertEquals(HttpStatus.FOUND, resp.getStatusCode()))
				.expectComplete().verify();
	}
	
	private void mockDataAddStep(AddDeviceUIResponse addDeviceUIResponse, CartRedisData data, AddDeviceUIRequest request) throws UnsupportedEncodingException, SignatureException {
		URI url = URI.create("http://localhost/add-step?X-Host=verizon.com&deviceId=GA01221-US&isHumDevice=false");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).header("Accept", "application").build();
		when(accDevHelper.addDevice(Mockito.any(), Mockito.any())).thenReturn(
				Mono.just(addDeviceUIResponse)
		);
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(null);
		when(cartHelper.getRequestDetails(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), eq(httpHeader), eq(Optional.of(true)), eq(Optional.of("36")))).thenReturn(Mono.just(request));
		when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any()))
				.thenReturn(
						Mono.just(data)
				);
	}
	
	private AddDeviceUIRequest getAddDeviceUIRequest() throws JsonProcessingException {
		return mapper.readValue("/adddeviceRequest-addsep.json", AddDeviceUIRequest.class);
	}
	


	@Test
	public void addStepNullCheckTest() throws IOException, SignatureException {
		var addDeviceUIResponse = mapper.readValue("/adddevice-response-nsa.json", AddDeviceUIResponse.class);
		addDeviceUIResponse.getServiceBody().getServiceResponse().getContext().setCustomerInfo(null);
		addDeviceUIResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getOrderRestrictions().getAccountLevelChangeEligibility().get(0).setReasonCode("REASON");
		var data = readJson("/cart-redis-data.json", CartRedisData.class);
		// if you can changes the request
		var request = getAddDeviceUIRequest();
		mockDataAddStep(addDeviceUIResponse, data,request);

		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addStep(getHttpRequest(), new MockServerHttpResponse(), "123456", "GA01221-US", "responseString", null, "responseString", null, null, Optional.of("responseString"), Optional.of("responseString"), Optional.of("responseString"), Optional.of("responseString"), Optional.of("responseString"), Optional.of("responseString"), Optional.of("responseString"), Optional.of("responseString"), Optional.of("responseString"), Optional.of("true"), Optional.of("false"), Optional.ofNullable(null), Optional.of("true"), Optional.of("true"), Optional.of("true"), Optional.of("true"), Optional.of("55571"), Optional.of(true), Optional.of("Y"), Optional.of(false), Optional.of(false), Optional.of(false), Optional.of("responseString"), Optional.of(false), Optional.of("1796"), Optional.of("17965"), Optional.of(true), Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse)
				.assertNext(resp -> Assert.assertEquals(HttpStatus.FOUND, resp.getStatusCode()))
				.expectComplete().verify();
	}


	@Test
	public void addStepBauTest() throws IOException, SignatureException {
		var addDeviceUIResponse = mapper.readValue("/adddevice-response-nsa.json", AddDeviceUIResponse.class);
		addDeviceUIResponse.setServiceBody(null);
		var data = readJson("/cart-redis-data.json", CartRedisData.class);
		// if you can changes the request
		var request = getAddDeviceUIRequest();
		mockDataAddStep(addDeviceUIResponse, data,request);

		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addStep(getHttpRequest(), new MockServerHttpResponse(), "123456", "GA01221-US", "responseString", null, "responseString", null, null, Optional.of("responseString"), Optional.of("responseString"), Optional.of("responseString"), Optional.of("responseString"), Optional.of("responseString"), Optional.of("responseString"), Optional.of("responseString"), Optional.of("responseString"), Optional.of("responseString"), Optional.of("true"), Optional.of("false"), Optional.ofNullable(null), Optional.of("true"), Optional.of("true"), Optional.of("true"), Optional.of("false"), Optional.of("55571"), Optional.of(true), Optional.of("Y"), Optional.of(false), Optional.of(false), Optional.of(false), Optional.of("responseString"), Optional.of(true), Optional.of("1796"), Optional.of("17965"), Optional.of(true), Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse)
				.assertNext(resp -> Assert.assertEquals(HttpStatus.FOUND, resp.getStatusCode()))
				.expectComplete().verify();

	}

	@Test
	public void rpsApplePayloadTest2() throws JsonMappingException, JsonProcessingException, UnsupportedEncodingException, SignatureException {
		URI url = URI.create("http://localhost/rpsApplePayload");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		String requestString = "{\"encryptedPayload\": \"\",\"carrierPostData\":\"transaction-id=spcabcd12323&service-code=MSSU&token=MTQ4OTYwNDc0MjQ2OUBmYmM0MjFlNWVjNmY1MWJiZmMwMDhmYjY3MGYxYmI2NzVlZTY3MjZj&primary-device-mdn=8455597930&device-user-agent=Entitlement%20iOS%2F1.3&associated-subscription=2&esim-download-delay=10\",\"secondary-device-active\":{\"eid\":\"89049032005008882600031910586762\",\"display-name\":\"John's iPad\",\"device-imei\":\"356347105542208\",\"iccids\":[]},\"testScreen\":true,\"testNSA\":true,\"testreplace\":true}";
		RPSApplePayloadUIRequest request = mapper.readValue(requestString, RPSApplePayloadUIRequest.class);
		when(redisHelper2.upsertRPSFlowDataIntoRedis(Mockito.<RPSRedisData>any())).thenReturn(Mono.just(true));
		Mono<ResponseEntity<GenericResponse>> response = cartController.rpsApplePayload(httpHeader, httpResponse, request, "");
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(HttpStatus.FOUND, resp.getStatusCode())).expectComplete().verify();
	}

	@Test
	public void addStepIsCommonPDP() throws IOException, SignatureException {
		String requestString = "{ \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
		URI url = URI.create("http://localhost/add-step?X-Host=verizon.com&deviceId=GA01221-US&isHumDevice=true");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).cookie(new HttpCookie("RepIdCookieText","E170K")).header("X-Host", "verizon.com").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(new SsoJwtDTO());
		when(featureFlagHelper.fetchFiosLoginPDPPearlFFlagStatus()).thenReturn(Mono.just(true));
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any() ,eq(httpHeader),eq(Optional.of(true)),eq(Optional.of("36")))).thenReturn(Mono.just(request));
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456","GA01221-US", responseString, null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of(responseString), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(true),Optional.of("Y"),Optional.of(true),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void addStepIsTradeInIntentSelected() throws IOException, SignatureException {
		String requestString = "{ \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
		URI url = URI.create("http://localhost/add-step?X-Host=verizon.com&deviceId=GA01221-US&isHumDevice=true");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).cookie(new HttpCookie("RepIdCookieText","E170K")).header("X-Host", "verizon.com").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		when(featureFlagHelper.fetchFiosLoginPDPPearlFFlagStatus()).thenReturn(Mono.just(true));
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(new SsoJwtDTO());
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any() ,eq(httpHeader),eq(Optional.of(true)),eq(Optional.of("36")))).thenReturn(Mono.just(request));
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456","GA01221-US", responseString, null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of(responseString), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(true),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void addStepNextGen() throws IOException, SignatureException {
		String requestString = "{ \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		String responseString = "{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.10.30.20.27.06-446.2674999338906\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-16967837-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"MTNSelectionPage\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage\",\"processAction\":\"\",\"cradleFlowJourney\":\"NEXTGEN_EC\"},\"customerInfo\":{\"accountNumber\":\"0524980612-00001\",\"cartCreator\":\"7165238321\",\"processingMTN\":\"\",\"registerNumber\":0,\"existingCase\":\"\",\"noc\":false},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"90c0b7ef-5ae6-401c-b0d9-ae2f21fc7708\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}";
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
		URI url = URI.create("http://localhost/add-step?channelId=VZW-DOTCOM&hostName=vzwqa1.verizonwireless.com&catalogRefId=sku5811695&deviceProdId=dev20760272&deviceSorId=SMS918UZGV&contractTerm=99&dacc=&quantity=1&flow=EUP&deviceCategory=Smartphones&seoUrl=&loanTerm=36&deviceFilterType=Smartphones&zipCode=30004&noRedirect=true&netaceLocationCode=&isCommonPDP=true&depletionType=F&purchasePath=EUP&isKeepingExistingEqProtection=true&isTradeInIntentSelected=false&selectedPromoType=NOPROMO&promoIntent=NOPROMO&selectedPromoId=");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).cookie(new HttpCookie("RepIdCookieText","E170K")).header("X-Host", "verizon.com").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just(""));
		when(featureFlagHelper.fetchFiosLoginPDPPearlFFlagStatus()).thenReturn(Mono.just(true));
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(new SsoJwtDTO());
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any() ,eq(httpHeader),eq(Optional.of(true)),eq(Optional.of("36")))).thenReturn(Mono.just(request));
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456","GA01221-US", responseString, null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of(responseString), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(true),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void addStepBAU_AAL() throws IOException, SignatureException {
		String requestString = "{ \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		String responseString = "{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.11.08.21.19.51-836.2236580050272\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-928614394-W01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"PromoBundleBuilder\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PromoBundleBuilder\",\"processAction\":\"\",\"cradleFlowJourney\":\"AccessoryInterestial\"},\"customerInfo\":{\"accountNumber\":\"0326222333-00001\",\"cartCreator\":\"2132478174\",\"processingMTN\":\"\",\"registerNumber\":0,\"number_share_capable\":\"\",\"e911_addr_ind\":\"\",\"existingCase\":\"false\",\"noc\":false},\"cartInfo\":{\"financeLimitExceeded\":\"false\",\"cartItemCount\":1,\"cartId\":\"a0255f6a-c803-4fc7-9155-2533df1a54db\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"status\":1,\"firstMonthInstallment\":28.04,\"monthlyInstallment\":27.77,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"MTQQ3LL/A\",\"installmentTerm\":\"0\",\"itemPrice\":\"999.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"iPhone 15 Pro\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0,\"isNonVZDeviceSku\":false},\"sim\":{\"id\":\"UNIVESIM5G-SAB-A\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"AAL\",\"currentPlanType\":\"LLP\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"cartValidationErrors\":[{\"errorCategory\":\"Cart\",\"errorLevel\":\"Blocker\",\"errorCode\":\"1034\",\"errorMessage\":\"Cart doesn't have Protection/Declined Protection feature.\",\"fieldPath\":\"newLine1\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Warning\",\"errorCode\":\"1009\",\"errorMessage\":\"CorrelationID is missing in ServiceInfo\",\"fieldPath\":\"newLine1\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Blocker\",\"errorCode\":\"1023\",\"errorMessage\":\"New PricePlanId is not populated for AAL/BYOD line.\",\"fieldPath\":\"newLine1\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Blocker\",\"errorCode\":\"1010\",\"errorMessage\":\"NPANXX Number is not assigned to AAL line in the cart\",\"fieldPath\":\"newLine1\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Warning\",\"errorCode\":\"1090\",\"errorMessage\":\"Shipping is Required\",\"fieldPath\":\"\"}],\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}";
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
		URI url = URI.create("http://localhost/soe/digital/auth/cartservice/cart/add-step?hostName=www.verizon.com&catalogRefId=sku6004781&deviceProdId=dev21410693&deviceSorId=MTQQ3LL/A&contractTerm=99&dacc=&quantity=1&flow=AAL&deviceCategory=Smartphones&seoUrl=&loanTerm=36&deviceFilterType=Smartphones&zipCode=76137&noRedirect=true&netaceLocationCode=&isCommonPDP=true&depletionType=F&purchasePath=AAL&isKeepingExistingEqProtection=true&isTradeInIntentSelected=false&selectedPromoType=NOPROMO&promoIntent=NOPROMO&selectedPromoId=");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).cookie(new HttpCookie("RepIdCookieText","E170K")).header("X-Host", "verizon.com").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just(""));
		when(featureFlagHelper.fetchFiosLoginPDPPearlFFlagStatus()).thenReturn(Mono.just(true));
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(new SsoJwtDTO());
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any() ,eq(httpHeader),eq(Optional.of(true)),eq(Optional.of("36")))).thenReturn(Mono.just(request));
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456","GA01221-US", responseString, null, "AAL", null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of(responseString), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(true),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void addStepBAU_EUP() throws IOException, SignatureException {
		String requestString = "{ \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		String responseString = "{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.11.08.21.15.27-674.0633617761209\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-928582447-W01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"MTNSelectionPage\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage\",\"processAction\":\"\",\"cradleFlowJourney\":\"AccessoryInterestial\"},\"customerInfo\":{\"accountNumber\":\"0326222333-00001\",\"cartCreator\":\"2132478174\",\"processingMTN\":\"\",\"registerNumber\":0,\"existingCase\":\"\",\"noc\":false},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"b6a56471-1432-4ce7-8214-bb5cd4a4c6b6\",\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}";
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
		URI url = URI.create("http://localhost/soe/digital/auth/cartservice/cart/add-step?channelId=VZW-DOTCOM&hostName=www.verizon.com&catalogRefId=sku6004539&deviceProdId=dev21410693&deviceSorId=MTU13LL/A&contractTerm=99&dacc=&quantity=1&flow=EUP&deviceCategory=Smartphones&seoUrl=&loanTerm=36&deviceFilterType=Smartphones&zipCode=76137&noRedirect=true&netaceLocationCode=&isCommonPDP=true&depletionType=F&purchasePath=EUP&isKeepingExistingEqProtection=true&isTradeInIntentSelected=false&selectedPromoType=NOPROMO&promoIntent=NOPROMO&selectedPromoId=");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).cookie(new HttpCookie("RepIdCookieText","E170K")).header("X-Host", "verizon.com").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just(""));
		when(featureFlagHelper.fetchFiosLoginPDPPearlFFlagStatus()).thenReturn(Mono.just(true));
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(new SsoJwtDTO());
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any() ,eq(httpHeader),eq(Optional.of(true)),eq(Optional.of("36")))).thenReturn(Mono.just(request));
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456","GA01221-US", responseString, null, "EUP", null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of(responseString), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(true),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void addStepBAU_EmptyChannelID() throws IOException, SignatureException {
		String requestString = "{ \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		String responseString = "{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.11.08.21.15.27-674.0633617761209\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-928582447-W01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"MTNSelectionPage\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage\",\"processAction\":\"\",\"cradleFlowJourney\":\"AccessoryInterestial\"},\"customerInfo\":{\"accountNumber\":\"0326222333-00001\",\"cartCreator\":\"2132478174\",\"processingMTN\":\"\",\"registerNumber\":0,\"existingCase\":\"\",\"noc\":false},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"b6a56471-1432-4ce7-8214-bb5cd4a4c6b6\",\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}";
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
		URI url = URI.create("http://localhost/soe/digital/auth/cartservice/cart/add-step?channelId=VZW-DOTCOM&hostName=www.verizon.com&catalogRefId=sku6004539&deviceProdId=dev21410693&deviceSorId=MTU13LL/A&contractTerm=99&dacc=&quantity=1&flow=EUP&deviceCategory=Smartphones&seoUrl=&loanTerm=36&deviceFilterType=Smartphones&zipCode=76137&noRedirect=true&netaceLocationCode=&isCommonPDP=true&depletionType=F&purchasePath=EUP&isKeepingExistingEqProtection=true&isTradeInIntentSelected=false&selectedPromoType=NOPROMO&promoIntent=NOPROMO&selectedPromoId=");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).cookie(new HttpCookie("RepIdCookieText","E170K")).header("X-Host", "verizon.com").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		when(featureFlagHelper.fetchFiosLoginPDPPearlFFlagStatus()).thenReturn(Mono.just(true));
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(new SsoJwtDTO());
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any() ,eq(httpHeader),eq(Optional.of(true)),eq(Optional.of("36")))).thenReturn(Mono.just(request));
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456","GA01221-US", responseString, null, "EUP", null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of(responseString), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(true),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void addStepTest_nextgenEC_AAL_OfferInterstitial() throws IOException, SignatureException {
		String requestString = "{ \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		String responseString = "{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.10.30.19.03.48-466.47954551535145\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-16962356-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"OfferInterstitial\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"OfferInterstitial\",\"processAction\":\"\",\"cradleFlowJourney\":\"NEXTGEN_EC\"},\"customerInfo\":{\"accountNumber\":\"0680830693-00001\",\"cartCreator\":\"5862461671\",\"processingMTN\":\"\",\"registerNumber\":0,\"number_share_capable\":\"\",\"e911_addr_ind\":\"\",\"existingCase\":\"false\",\"noc\":false},\"cartInfo\":{\"financeLimitExceeded\":\"false\",\"cartItemCount\":1,\"cartId\":\"0172872e-ef2c-4b5d-bc37-5c72aa0ba9c4\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"status\":1,\"spos\":[{\"id\":\"2491\",\"actionIndicator\":\"D\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"2492\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"732\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"1692\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"1802\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"1958\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]}],\"sfos\":[{\"id\":\"48526\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"48553\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68869\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68870\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68871\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68872\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68874\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68876\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"74774\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"75632\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"75802\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"75837\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"76152\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"76404\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"77249\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"77524\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"77568\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78706\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78707\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78732\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"80148\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"81158\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"82825\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"83856\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"85553\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86225\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false}],\"firstMonthInstallment\":33.44,\"monthlyInstallment\":33.33,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"lineSubscriptionInfos\":[],\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"SMS918UZGV\",\"installmentTerm\":\"0\",\"itemPrice\":\"1199.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"Galaxy S23 Ultra\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0,\"isNonVZDeviceSku\":false},\"sim\":{\"id\":\"EMBDSIM5GSA\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"AAL\",\"currentPlanType\":\"ALP\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"cartValidationErrors\":[{\"errorCategory\":\"Cart\",\"errorLevel\":\"Blocker\",\"errorCode\":\"1034\",\"errorMessage\":\"Cart doesn't have Protection/Declined Protection feature.\",\"fieldPath\":\"newLine1\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Blocker\",\"errorCode\":\"1010\",\"errorMessage\":\"NPANXX Number is not assigned to AAL line in the cart\",\"fieldPath\":\"newLine1\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Warning\",\"errorCode\":\"1090\",\"errorMessage\":\"Shipping is Required\",\"fieldPath\":\"\"}],\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}";
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);

		URI url = URI.create("http://localhost/add-step?deviceId=GA01221-US&isHumDevice=true");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).cookie(new HttpCookie("RepIdCookieText","E170K")).header("X-Host", "verizon.com").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(featureFlagHelper.fetchFiosLoginPDPPearlFFlagStatus()).thenReturn(Mono.just(true));
		when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(new SsoJwtDTO());
		when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just(""));
		when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
		doNothing().when(dlService).buildDLData(any());
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any() ,eq(httpHeader),eq(Optional.of(true)),eq(Optional.of("36")))).thenReturn(Mono.just(request));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456", "GA01221-US", responseString, null, responseString, null, null, Optional.empty(),Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.of("true"), Optional.empty(), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(false),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

	}

	@Test
	public void addStepTest_nextgenEC_AAL_DeviceProtection() throws IOException, SignatureException {
		String requestString = "{ \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		String responseString = "{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.10.30.19.03.48-466.47954551535145\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-16962356-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"DeviceConfigurator\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"DeviceConfigurator\",\"processAction\":\"\",\"cradleFlowJourney\":\"NEXTGEN_EC\"},\"customerInfo\":{\"accountNumber\":\"0680830693-00001\",\"cartCreator\":\"5862461671\",\"processingMTN\":\"\",\"registerNumber\":0,\"number_share_capable\":\"\",\"e911_addr_ind\":\"\",\"existingCase\":\"false\",\"noc\":false},\"cartInfo\":{\"financeLimitExceeded\":\"false\",\"cartItemCount\":1,\"cartId\":\"0172872e-ef2c-4b5d-bc37-5c72aa0ba9c4\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"status\":1,\"spos\":[{\"id\":\"2491\",\"actionIndicator\":\"D\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"2492\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"732\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"1692\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"1802\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"1958\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]}],\"sfos\":[{\"id\":\"48526\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"48553\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68869\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68870\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68871\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68872\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68874\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68876\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"74774\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"75632\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"75802\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"75837\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"76152\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"76404\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"77249\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"77524\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"77568\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78706\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78707\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78732\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"80148\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"81158\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"82825\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"83856\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"85553\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86225\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false}],\"firstMonthInstallment\":33.44,\"monthlyInstallment\":33.33,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"lineSubscriptionInfos\":[],\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"SMS918UZGV\",\"installmentTerm\":\"0\",\"itemPrice\":\"1199.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"Galaxy S23 Ultra\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0,\"isNonVZDeviceSku\":false},\"sim\":{\"id\":\"EMBDSIM5GSA\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"AAL\",\"currentPlanType\":\"ALP\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"cartValidationErrors\":[{\"errorCategory\":\"Cart\",\"errorLevel\":\"Blocker\",\"errorCode\":\"1034\",\"errorMessage\":\"Cart doesn't have Protection/Declined Protection feature.\",\"fieldPath\":\"newLine1\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Blocker\",\"errorCode\":\"1010\",\"errorMessage\":\"NPANXX Number is not assigned to AAL line in the cart\",\"fieldPath\":\"newLine1\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Warning\",\"errorCode\":\"1090\",\"errorMessage\":\"Shipping is Required\",\"fieldPath\":\"\"}],\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}";
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);

		URI url = URI.create("http://localhost/add-step?deviceId=GA01221-US&isHumDevice=true");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).cookie(new HttpCookie("RepIdCookieText", "E170K")).header("X-Host", "verizon.com").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(featureFlagHelper.fetchFiosLoginPDPPearlFFlagStatus()).thenReturn(Mono.just(true));
		when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(new SsoJwtDTO());
		when(cartHelper.getRequestDetails(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any() , eq(httpHeader),eq(Optional.of(true)),eq(Optional.of("36")))).thenReturn(Mono.just(request));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456", "GA01221-US", responseString, null, responseString, null, null, Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.of("true"), Optional.empty(), Optional.of("vzwqa2.verizonwireless.com"), Optional.of("true"), Optional.of("true"), Optional.of("true"), Optional.of("true"), Optional.of("true"), Optional.of(false), Optional.of("Y"), Optional.of(false), Optional.of(false), Optional.of(false), Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void addStepTest_nextgenEC_AAL_PopularPlans() throws IOException, SignatureException {
		String requestString = "{ \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		String responseString = "{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.10.30.19.03.48-466.47954551535145\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-16962356-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"PopularPlans\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"NewRecommendedPlanSelection\",\"processAction\":\"\",\"cradleFlowJourney\":\"NEXTGEN_EC\"},\"customerInfo\":{\"accountNumber\":\"0680830693-00001\",\"cartCreator\":\"5862461671\",\"processingMTN\":\"\",\"registerNumber\":0,\"number_share_capable\":\"\",\"e911_addr_ind\":\"\",\"existingCase\":\"false\",\"noc\":false},\"cartInfo\":{\"financeLimitExceeded\":\"false\",\"cartItemCount\":1,\"cartId\":\"0172872e-ef2c-4b5d-bc37-5c72aa0ba9c4\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"status\":1,\"spos\":[{\"id\":\"2491\",\"actionIndicator\":\"D\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"2492\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"732\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"1692\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"1802\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"1958\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]}],\"sfos\":[{\"id\":\"48526\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"48553\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68869\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68870\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68871\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68872\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68874\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68876\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"74774\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"75632\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"75802\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"75837\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"76152\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"76404\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"77249\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"77524\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"77568\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78706\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78707\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78732\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"80148\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"81158\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"82825\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"83856\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"85553\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86225\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false}],\"firstMonthInstallment\":33.44,\"monthlyInstallment\":33.33,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"lineSubscriptionInfos\":[],\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"SMS918UZGV\",\"installmentTerm\":\"0\",\"itemPrice\":\"1199.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"Galaxy S23 Ultra\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0,\"isNonVZDeviceSku\":false},\"sim\":{\"id\":\"EMBDSIM5GSA\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"AAL\",\"currentPlanType\":\"ALP\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"cartValidationErrors\":[{\"errorCategory\":\"Cart\",\"errorLevel\":\"Blocker\",\"errorCode\":\"1034\",\"errorMessage\":\"Cart doesn't have Protection/Declined Protection feature.\",\"fieldPath\":\"newLine1\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Blocker\",\"errorCode\":\"1010\",\"errorMessage\":\"NPANXX Number is not assigned to AAL line in the cart\",\"fieldPath\":\"newLine1\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Warning\",\"errorCode\":\"1090\",\"errorMessage\":\"Shipping is Required\",\"fieldPath\":\"\"}],\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}";
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);

		List<AvailablePaths> availablePaths = new ArrayList<>();
		availablePaths.add(new AvailablePaths("PopularPlans"));
		response.getServiceBody().getServiceResponse().getContext().getContextInfo().setAvailablePaths(availablePaths);

		URI url = URI.create("http://localhost/add-step?deviceId=GA01221-US&isHumDevice=true");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).cookie(new HttpCookie("RepIdCookieText", "E170K")).header("X-Host", "verizon.com").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(featureFlagHelper.fetchFiosLoginPDPPearlFFlagStatus()).thenReturn(Mono.just(true));
		when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(new SsoJwtDTO());
		when(cartHelper.getRequestDetails(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(),Mockito.any() ,eq(httpHeader),eq(Optional.of(true)),eq(Optional.of("36")))).thenReturn(Mono.just(request));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456", "GA01221-US", responseString, null, responseString, null, null, Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.of("true"), Optional.empty(), Optional.of("vzwqa2.verizonwireless.com"), Optional.of("true"), Optional.of("true"), Optional.of("true"), Optional.of("true"), Optional.of("true"), Optional.of(false), Optional.of("Y"), Optional.of(false), Optional.of(false), Optional.of(false), Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void addStepTest_nextgenEC_AAL_PlanOverview() throws IOException, SignatureException {
		String requestString = "{ \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		String responseString = "{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.10.30.19.03.48-466.47954551535145\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-16962356-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"NewRecommendedPlanSelection\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"NewRecommendedPlanSelection\",\"processAction\":\"\",\"cradleFlowJourney\":\"NEXTGEN_EC\"},\"customerInfo\":{\"accountNumber\":\"0680830693-00001\",\"cartCreator\":\"5862461671\",\"processingMTN\":\"\",\"registerNumber\":0,\"number_share_capable\":\"\",\"e911_addr_ind\":\"\",\"existingCase\":\"false\",\"noc\":false},\"cartInfo\":{\"financeLimitExceeded\":\"false\",\"cartItemCount\":1,\"cartId\":\"0172872e-ef2c-4b5d-bc37-5c72aa0ba9c4\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"status\":1,\"spos\":[{\"id\":\"2491\",\"actionIndicator\":\"D\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"2492\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"732\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"1692\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"1802\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"1958\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]}],\"sfos\":[{\"id\":\"48526\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"48553\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68869\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68870\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68871\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68872\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68874\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68876\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"74774\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"75632\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"75802\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"75837\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"76152\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"76404\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"77249\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"77524\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"77568\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78706\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78707\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78732\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"80148\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"81158\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"82825\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"83856\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"85553\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86225\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false}],\"firstMonthInstallment\":33.44,\"monthlyInstallment\":33.33,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"lineSubscriptionInfos\":[],\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"SMS918UZGV\",\"installmentTerm\":\"0\",\"itemPrice\":\"1199.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"Galaxy S23 Ultra\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0,\"isNonVZDeviceSku\":false},\"sim\":{\"id\":\"EMBDSIM5GSA\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"AAL\",\"currentPlanType\":\"ALP\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"cartValidationErrors\":[{\"errorCategory\":\"Cart\",\"errorLevel\":\"Blocker\",\"errorCode\":\"1034\",\"errorMessage\":\"Cart doesn't have Protection/Declined Protection feature.\",\"fieldPath\":\"newLine1\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Blocker\",\"errorCode\":\"1010\",\"errorMessage\":\"NPANXX Number is not assigned to AAL line in the cart\",\"fieldPath\":\"newLine1\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Warning\",\"errorCode\":\"1090\",\"errorMessage\":\"Shipping is Required\",\"fieldPath\":\"\"}],\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}";
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);

		List<AvailablePaths> availablePaths = new ArrayList<>();
		availablePaths.add(new AvailablePaths("NewRecommendedPlanSelection"));
		response.getServiceBody().getServiceResponse().getContext().getContextInfo().setAvailablePaths(availablePaths);

		URI url = URI.create("http://localhost/add-step?deviceId=GA01221-US&isHumDevice=true");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).cookie(new HttpCookie("RepIdCookieText", "E170K")).header("X-Host", "verizon.com").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(featureFlagHelper.fetchFiosLoginPDPPearlFFlagStatus()).thenReturn(Mono.just(true));
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(new SsoJwtDTO());
		when(cartHelper.getRequestDetails(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any() ,Mockito.any(),Mockito.any() ,eq(httpHeader),eq(Optional.of(true)),eq(Optional.of("36")))).thenReturn(Mono.just(request));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456", "GA01221-US", responseString, null, responseString, null, null, Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.of("true"), Optional.empty(), Optional.of("vzwqa2.verizonwireless.com"), Optional.of("true"), Optional.of("true"), Optional.of("true"), Optional.of("true"), Optional.of("true"), Optional.of(false), Optional.of("Y"), Optional.of(false), Optional.of(false), Optional.of(false), Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void addStepTest_nextgenEC_AAL_PlanSelector() throws IOException, SignatureException {
		String requestString = "{ \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		String responseString = "{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.10.30.19.03.48-466.47954551535145\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-16962356-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"PlanSelectorPage\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"NewRecommendedPlanSelection\",\"processAction\":\"\",\"cradleFlowJourney\":\"NEXTGEN_EC\"},\"customerInfo\":{\"accountNumber\":\"0680830693-00001\",\"cartCreator\":\"5862461671\",\"processingMTN\":\"\",\"registerNumber\":0,\"number_share_capable\":\"\",\"e911_addr_ind\":\"\",\"existingCase\":\"false\",\"noc\":false},\"cartInfo\":{\"financeLimitExceeded\":\"false\",\"cartItemCount\":1,\"cartId\":\"0172872e-ef2c-4b5d-bc37-5c72aa0ba9c4\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"status\":1,\"spos\":[{\"id\":\"2491\",\"actionIndicator\":\"D\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"2492\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"732\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"1692\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"1802\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"1958\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]}],\"sfos\":[{\"id\":\"48526\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"48553\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68869\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68870\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68871\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68872\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68874\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68876\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"74774\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"75632\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"75802\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"75837\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"76152\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"76404\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"77249\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"77524\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"77568\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78706\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78707\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78732\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"80148\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"81158\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"82825\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"83856\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"85553\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86225\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false}],\"firstMonthInstallment\":33.44,\"monthlyInstallment\":33.33,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"lineSubscriptionInfos\":[],\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"SMS918UZGV\",\"installmentTerm\":\"0\",\"itemPrice\":\"1199.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"Galaxy S23 Ultra\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0,\"isNonVZDeviceSku\":false},\"sim\":{\"id\":\"EMBDSIM5GSA\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"AAL\",\"currentPlanType\":\"ALP\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"cartValidationErrors\":[{\"errorCategory\":\"Cart\",\"errorLevel\":\"Blocker\",\"errorCode\":\"1034\",\"errorMessage\":\"Cart doesn't have Protection/Declined Protection feature.\",\"fieldPath\":\"newLine1\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Blocker\",\"errorCode\":\"1010\",\"errorMessage\":\"NPANXX Number is not assigned to AAL line in the cart\",\"fieldPath\":\"newLine1\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Warning\",\"errorCode\":\"1090\",\"errorMessage\":\"Shipping is Required\",\"fieldPath\":\"\"}],\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}";
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);

		List<AvailablePaths> availablePaths = new ArrayList<>();
		availablePaths.add(new AvailablePaths("PlanSelectorPage"));
		response.getServiceBody().getServiceResponse().getContext().getContextInfo().setAvailablePaths(availablePaths);

		URI url = URI.create("http://localhost/add-step?deviceId=GA01221-US&isHumDevice=true");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).cookie(new HttpCookie("RepIdCookieText", "E170K")).header("X-Host", "verizon.com").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(featureFlagHelper.fetchFiosLoginPDPPearlFFlagStatus()).thenReturn(Mono.just(true));
		when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(new SsoJwtDTO());
		when(cartHelper.getRequestDetails(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any() ,Mockito.any(),Mockito.any() ,eq(httpHeader),eq(Optional.of(true)),eq(Optional.of("36")))).thenReturn(Mono.just(request));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456", "GA01221-US", responseString, null, responseString, null, null, Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.of("true"), Optional.empty(), Optional.of("vzwqa2.verizonwireless.com"), Optional.of("true"), Optional.of("true"), Optional.of("true"), Optional.of("true"), Optional.of("true"), Optional.of(false), Optional.of("Y"), Optional.of(false), Optional.of(false), Optional.of(false), Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void addStepTest_nextgenEC_AAL_CompatibleWatchPlan() throws IOException, SignatureException {
		String requestString = "{ \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		String responseString = "{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.10.30.19.03.48-466.47954551535145\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-16962356-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"CompatibleWatchPlan\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"NewRecommendedPlanSelection\",\"processAction\":\"\",\"cradleFlowJourney\":\"NEXTGEN_EC\"},\"customerInfo\":{\"accountNumber\":\"0680830693-00001\",\"cartCreator\":\"5862461671\",\"processingMTN\":\"\",\"registerNumber\":0,\"number_share_capable\":\"\",\"e911_addr_ind\":\"\",\"existingCase\":\"false\",\"noc\":false},\"cartInfo\":{\"financeLimitExceeded\":\"false\",\"cartItemCount\":1,\"cartId\":\"0172872e-ef2c-4b5d-bc37-5c72aa0ba9c4\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"status\":1,\"spos\":[{\"id\":\"2491\",\"actionIndicator\":\"D\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"2492\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"732\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"1692\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"1802\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"1958\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]}],\"sfos\":[{\"id\":\"48526\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"48553\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68869\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68870\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68871\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68872\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68874\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68876\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"74774\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"75632\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"75802\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"75837\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"76152\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"76404\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"77249\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"77524\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"77568\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78706\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78707\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78732\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"80148\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"81158\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"82825\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"83856\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"85553\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86225\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false}],\"firstMonthInstallment\":33.44,\"monthlyInstallment\":33.33,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"lineSubscriptionInfos\":[],\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"SMS918UZGV\",\"installmentTerm\":\"0\",\"itemPrice\":\"1199.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"Galaxy S23 Ultra\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0,\"isNonVZDeviceSku\":false},\"sim\":{\"id\":\"EMBDSIM5GSA\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"AAL\",\"currentPlanType\":\"ALP\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"cartValidationErrors\":[{\"errorCategory\":\"Cart\",\"errorLevel\":\"Blocker\",\"errorCode\":\"1034\",\"errorMessage\":\"Cart doesn't have Protection/Declined Protection feature.\",\"fieldPath\":\"newLine1\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Blocker\",\"errorCode\":\"1010\",\"errorMessage\":\"NPANXX Number is not assigned to AAL line in the cart\",\"fieldPath\":\"newLine1\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Warning\",\"errorCode\":\"1090\",\"errorMessage\":\"Shipping is Required\",\"fieldPath\":\"\"}],\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}";
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);

		List<AvailablePaths> availablePaths = new ArrayList<>();
		availablePaths.add(new AvailablePaths("CompatibleWatchPlan"));
		response.getServiceBody().getServiceResponse().getContext().getContextInfo().setAvailablePaths(availablePaths);

		URI url = URI.create("http://localhost/add-step?deviceId=GA01221-US&isHumDevice=true");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).cookie(new HttpCookie("RepIdCookieText", "E170K")).header("X-Host", "verizon.com").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(featureFlagHelper.fetchFiosLoginPDPPearlFFlagStatus()).thenReturn(Mono.just(true));
		when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(new SsoJwtDTO());
		when(cartHelper.getRequestDetails(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any() ,Mockito.any(),Mockito.any() ,eq(httpHeader),eq(Optional.of(true)),eq(Optional.of("36")))).thenReturn(Mono.just(request));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456", "GA01221-US", responseString, null, responseString, null, null, Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.of("true"), Optional.empty(), Optional.of("vzwqa2.verizonwireless.com"), Optional.of("true"), Optional.of("true"), Optional.of("true"), Optional.of("true"), Optional.of("true"), Optional.of(false), Optional.of("Y"), Optional.of(false), Optional.of(false), Optional.of(false), Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void addStepTest_nextgenEC_AAL_ResumeFlow() throws IOException, SignatureException {
		String requestString = "{ \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		String responseString = "{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.10.30.19.03.48-466.47954551535145\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-16962356-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"CompatibleWatchPlan\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"NewRecommendedPlanSelection\",\"processAction\":\"\",\"cradleFlowJourney\":\"NEXTGEN_EC\"},\"customerInfo\":{\"accountNumber\":\"0680830693-00001\",\"cartCreator\":\"5862461671\",\"processingMTN\":\"\",\"registerNumber\":0,\"number_share_capable\":\"\",\"e911_addr_ind\":\"\",\"existingCase\":\"false\",\"noc\":false},\"cartInfo\":{\"financeLimitExceeded\":\"false\",\"cartItemCount\":1,\"cartId\":\"0172872e-ef2c-4b5d-bc37-5c72aa0ba9c4\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}";
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);

		List<AvailablePaths> availablePaths = new ArrayList<>();
		availablePaths.add(new AvailablePaths("PopularPlans"));
		response.getServiceBody().getServiceResponse().getContext().getContextInfo().setAvailablePaths(availablePaths);

		URI url = URI.create("http://localhost/add-step?deviceId=GA01221-US&isHumDevice=true");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).cookie(new HttpCookie("RepIdCookieText", "E170K")).header("X-Host", "verizon.com").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(featureFlagHelper.fetchFiosLoginPDPPearlFFlagStatus()).thenReturn(Mono.just(true));
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(new SsoJwtDTO());
		when(cartHelper.getRequestDetails(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any() ,Mockito.any(),Mockito.any() ,eq(httpHeader),eq(Optional.of(true)),eq(Optional.of("36")))).thenReturn(Mono.just(request));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456", "GA01221-US", responseString, null, responseString, null, null, Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.of("true"), Optional.empty(), Optional.of("vzwqa2.verizonwireless.com"), Optional.of("true"), Optional.of("true"), Optional.of("true"), Optional.of("true"), Optional.of("true"), Optional.of(false), Optional.of("Y"), Optional.of(false), Optional.of(false), Optional.of(false), Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}
	@Test
	public void getNSAThrottleListNSA_RegionCode_Test() throws  Exception{
		URI url = URI.create("http://localhost/getNSAThrottleList");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).header("x-akamai-edgescape", "country_code=US,region_code=MD,city=Silver Spring,dma=511,msa=511,lat=39.0680,long=-76.9933,zip=20904,continent=NA,timezone=EST").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		Map<String, String> requestMap = new HashMap<>();
		String redisDataString = "{\"mtn\":\"1234567890\",\"channel\":\"Digital\"}";
		Map<String,Object> sampleRedisData = mapper.readValue(redisDataString, Map.class);
		String outPut = "{\"cradleFlowJourney\": \"\",\n" +
				"\t\t\"throttleList\": \"|PPP_DF_NSE|\"}";
		CradleResponse response = new CradleResponse();
		response.setOutPut(outPut);
		when(redisHelper3.getMTNFromRedis(Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper3.getDataFromSession(Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		when(cradleAllocator.invokeReactiveCradle(httpHeader,httpResponse,requestMap)).thenReturn(Mono.just(response));
		Mono<ResponseEntity<String>> resp=cartController.getNSAThrottleList(httpHeader,httpResponse,requestMap);
		StepVerifier.create(resp).assertNext(resp1 -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

	}
	@Test
	public void getNSAThrottleListNSA_NullHeaderReq_Test() throws  Exception{
		URI url = URI.create("http://localhost/getNSAThrottleList");
		MockServerHttpRequest httpHeader = null;
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		Map<String, String> requestMap = new HashMap<>();
		String redisDataString = "{\"mtn\":\"1234567890\",\"channel\":\"Digital\"}";
		Map<String,Object> sampleRedisData = mapper.readValue(redisDataString, Map.class);
		String outPut = "{\"cradleFlowJourney\": \"\",\n" +
				"\t\t\"throttleList\": \"|PPP_DF_NSE|\"}";
		CradleResponse response = new CradleResponse();
		response.setOutPut(outPut);
		when(redisHelper3.getMTNFromRedis(Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper3.getDataFromSession(Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		when(cradleAllocator.invokeReactiveCradle(httpHeader,httpResponse,requestMap)).thenReturn(Mono.just(response));
		Mono<ResponseEntity<String>> resp=cartController.getNSAThrottleList(httpHeader,httpResponse,requestMap);
		StepVerifier.create(resp).assertNext(resp1 -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

	}

	@Test
	public void getNSAThrottleListBYODESIMTOGGLE_Test() throws  Exception{
		MockServerHttpRequest httpHeader = null;
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		String outPut = "{\"cradleFlowJourney\": \"\",\n" +
				"\t\t\"throttleList\": \"|NGBYOD_C_ESIM_TGL|\"}";
		CradleResponse response = new CradleResponse();
		response.setOutPut(outPut);
		Map<String, String> requestMap = new HashMap<>();
		requestMap.put(CartConstants.PAGE_NAME_KEY,CartConstants.PAGE_NAME_NG_MAKE_AND_MODEL);
		when(redisHelper3.getMTNFromRedis(Mockito.any())).thenReturn(Mono.just(new HashMap<>()));
		when(redisHelper3.getDataFromSession(Mockito.any())).thenReturn(Mono.just(new HashMap<>()));
		when(cradleAllocator.invokeReactiveCradle(httpHeader,httpResponse,requestMap)).thenReturn(Mono.just(response));
		Mono<ResponseEntity<String>> resp=cartController.getNSAThrottleList(httpHeader,httpResponse,requestMap);
		StepVerifier.create(resp).assertNext(resp1 -> Assert.assertNotNull(resp1)).expectComplete()
				.verify();
		requestMap.put(CartConstants.PAGE_NAME_KEY,"NSEBYODNextGen");
		resp=cartController.getNSAThrottleList(httpHeader,httpResponse,requestMap);
		StepVerifier.create(resp).assertNext(resp1 -> Assert.assertNotNull(resp1)).expectComplete()
				.verify();


	}
	@Test
	public void getNSAThrottleListWithIMEIFFlagTest() throws  Exception{
		URI url = URI.create("http://localhost/getNSAThrottleList");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).header("X-Host", "verizon.com").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		Map<String, String> requestMap = new HashMap<>();
		requestMap.put("pageName", "enterDeviceIMEI");
		String redisDataString = "{\"mtn\":\"1234567890\",\"channel\":\"Digital\"}";
		Map<String,Object> sampleRedisData = mapper.readValue(redisDataString, Map.class);
		String outPut = "{\"cradleFlowJourney\": \"\",\n" +
				"\t\t\"throttleList\": \"|PROSPECT_PROTECTION_REDESIGN|\"}";
		CradleResponse response = new CradleResponse();
		response.setOutPut(outPut);
		when(redisHelper3.getMTNFromRedis(Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper3.getDataFromSession(Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		when(cradleAllocator.invokeReactiveCradle(httpHeader,httpResponse,requestMap)).thenReturn(Mono.just(response));
		Mono<ResponseEntity<String>> resp=cartController.getNSAThrottleList(httpHeader,httpResponse,requestMap);

		StepVerifier.create(resp).assertNext(resp3 -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
		when(featureFlagHelper.isBYODIMEIRangeFFlagEnabled()).thenReturn(Boolean.TRUE);
		when(featureFlagHelper.isBYODIMEIInstructionsFFlagEnabled()).thenReturn(Boolean.TRUE);
		Mono<ResponseEntity<String>> resp2=cartController.getNSAThrottleList(httpHeader,httpResponse,requestMap);
		StepVerifier.create(resp2).assertNext(resp3 -> Assert.assertNotNull(resp2)).expectComplete()
				.verify();
		requestMap.put("pageName", "WrongValue");
		Mono<ResponseEntity<String>> resp1=cartController.getNSAThrottleList(httpHeader,httpResponse,requestMap);
		StepVerifier.create(resp1).assertNext(resp3 -> Assert.assertNotNull(resp1)).expectComplete()
				.verify();
	}

	@Test
	public void getUriForPlanSelectionProgressivePlans() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {

		String nextgenBaseUrl = "https://vzwqa1.verizonwireless.com/sales/nextgen/";
		CartServiceContextInfo cartServiceContextInfo = new CartServiceContextInfo();
		CartServiceAvailablePaths cartServiceAvailablePaths = new CartServiceAvailablePaths();
		cartServiceAvailablePaths.setPath("ProgressivePlans");
		List<CartServiceAvailablePaths> cartServiceAvailablePathsList = new ArrayList<>();
		cartServiceAvailablePathsList.add(cartServiceAvailablePaths);
		cartServiceContextInfo.setCartServiceAvailablePaths(cartServiceAvailablePathsList);

		CartServiceContextInfo cartServiceContextInfo1 = new CartServiceContextInfo();
		CartServiceAvailablePaths cartServiceAvailablePaths1 = new CartServiceAvailablePaths();
		List<CartServiceAvailablePaths> cartServiceAvailablePathsList1 = new ArrayList<>();
		cartServiceAvailablePathsList.add(cartServiceAvailablePaths1);
		cartServiceContextInfo1.setCartServiceAvailablePaths(cartServiceAvailablePathsList1);
		String mtnLine = "newLine1 ";

		when(featureFlagHelper.isPlanSelectionProgressivePlansFFlagEnabled()).thenReturn(true);
		Environment env = Mockito.mock(Environment.class);
		when(env.getProperty("nextgenProgressivePlans")).thenReturn("plans/progressiveplans.html");

		Method getUriForPlanSelectionMethod = CartBauToNsaRedirectionController.class.getDeclaredMethod("getUriForPlanSelection", String.class, CartServiceContextInfo.class, String.class);
		getUriForPlanSelectionMethod.setAccessible(true);

		String getUri = (String) getUriForPlanSelectionMethod.invoke(cartController,nextgenBaseUrl, cartServiceContextInfo, mtnLine);
		String getUri1 = (String) getUriForPlanSelectionMethod.invoke(cartController,nextgenBaseUrl, cartServiceContextInfo1, mtnLine);
		org.junit.Assert.assertNotNull(getUri);
		org.junit.Assert.assertNull(getUri1);
	}

	@Test
	public void addStepTestForPendingOrder() throws IOException, SignatureException {
		String requestString = "{ \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		String responseString = "{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2024.12.06.02.52.46-445.45940254216765\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1005696638-W01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"PENDING_ORDER\"}],\"skipCheckoutCall\":false,\"unifiedNbsFlag\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PENDING_ORDER\",\"processAction\":\"\",\"cradleFlowJourney\":\"NEXTGEN_EC\"},\"customerInfo\":{\"nocByod\":false,\"accountNumber\":\"0374188350-00001\",\"cartCreator\":\"7755129003\",\"processingMTN\":\"\",\"registerNumber\":0,\"number_share_capable\":\"\",\"e911_addr_ind\":\"\",\"existingCase\":\"false\",\"noc\":false,\"myvPage\":false},\"cartInfo\":{\"orderRestrictions\":{\"accountLevelChangeEligibility\":[{\"isAddNewLineAllowed\":false,\"inEligibilityReasonCode\":\"PENDING_ORDER\"}]},\"cartItemCount\":0,\"cartId\":\"a8739374-8d1b-4310-84ac-d37ba7b3211d\",\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false,\"instantCreditAmount\":0,\"ngdFlow\":false,\"skipResumeCase\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}\n";
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
		URI url = URI.create("http://localhost/add-step?X-Host=verizon.com&deviceId=GA01221-US&isHumDevice=true");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).cookie(new HttpCookie("RepIdCookieText","E170K")).header("X-Host", "verizon.com").build();
		MockServerHttpResponse httpResponse = new MockServerHttpResponse();
		when(featureFlagHelper.fetchFiosLoginPDPPearlFFlagStatus()).thenReturn(Mono.just(true));
		when(featureFlagHelper.isPendingOrderRedirectionFFlagEnabled()).thenReturn(true);
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(new SsoJwtDTO());
		when(cartHelper.getRequestDetails(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(request));
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(sampleRedisData));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addStep(httpHeader, httpResponse, "123456","GA01221-US", responseString, null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of(responseString), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
		AddDeviceUIResponse response1 = response;
		response1.getServiceBody().getServiceResponse().getContext().getCartInfo().getOrderRestrictions().getAccountLevelChangeEligibility().get(0).setInEligibilityReasonCode("test");
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response1));
		Mono<ResponseEntity<GenericResponse>> controllerResponse1 = cartController.addStep(httpHeader, httpResponse, "123456","GA01221-US", responseString, null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of(responseString), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse1).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		AddDeviceUIResponse response2 = response;
		response2.getServiceBody().getServiceResponse().getContext().getCartInfo().getOrderRestrictions().getAccountLevelChangeEligibility().get(0).setInEligibilityReasonCode("");
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response2));
		Mono<ResponseEntity<GenericResponse>> controllerResponse2 = cartController.addStep(httpHeader, httpResponse, "123456","GA01221-US", responseString, null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of(responseString), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse2).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		AddDeviceUIResponse response3 = response;
		response3.getServiceBody().getServiceResponse().getContext().getCartInfo().getOrderRestrictions().getAccountLevelChangeEligibility().get(0).setInEligibilityReasonCode("COLLECTION_ACCOUNT");
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response2));
		Mono<ResponseEntity<GenericResponse>> controllerResponse3 = cartController.addStep(httpHeader, httpResponse, "123456","GA01221-US", responseString, null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of(responseString), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse3).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		when(featureFlagHelper.isPendingOrderRedirectionFFlagEnabled()).thenReturn(false);
		when(accDevHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response2));
		Mono<ResponseEntity<GenericResponse>> controllerResponse4 = cartController.addStep(httpHeader, httpResponse, "123456","GA01221-US", responseString, null, responseString, null, null, Optional.of(responseString), Optional.of(responseString),Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of(responseString), Optional.of("true"),Optional.of(responseString), Optional.of("vzwqa2.verizonwireless.com"),Optional.of("true"),Optional.of("true"),Optional.of("true"), Optional.of("true"),Optional.of("true"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(false),Optional.of(responseString),Optional.of(true),Optional.of("1796"),Optional.of("17965"),Optional.of(true),Optional.of("36"), Optional.of("VZW-DOTCOM"));
		StepVerifier.create(controllerResponse3).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}
}
