package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.model.addAccessory.AddAccServiceBody;
import onevz.soe.cart.model.addBuyout.AddBuyoutServiceBody;
import onevz.soe.cart.model.addDevice.AddDeviceServiceBody;
import onevz.soe.cart.model.addDownPayment.DownPaymentServiceBody;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.edgeup.UpdateEdgeupServiceBody;
import onevz.soe.cart.model.initiateCheckout.InitiateCheckoutServiceBody;
import onevz.soe.cart.model.initiateESimActivation.IntiateESimActivationUIRequest;
import onevz.soe.cart.model.initiateValidateDeviceSim.InitiateValidateDeviceSimUIRequest;
import onevz.soe.cart.model.removeLines.RemoveLinesServiceBody;
import onevz.soe.cart.model.retrieveCart.CXPRetrieveCartDataVO;
import onevz.soe.cart.model.updateSellerPrice.UpdateSellerPriceLine;
import onevz.soe.cart.model.updateUserInfo.UpdateUserInfoLine;
import onevz.soe.cart.requests.RetrieveCartCXPRequest;
import onevz.soe.cart.requests.ValidateCartCXPRequest;
import onevz.soe.cart.requests.ValidateSecureTokenRequest;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.ui.common.*;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.cart.util.CartCxpRequestErrorsUtil;
import onevz.soe.cart.util.CartCxpResponseErrorsUtil;
import onevz.soe.cart.util.CartPegaRequestErrorsUtil;
import onevz.soe.cart.util.CartPegaResponseErrorsUtil;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(CartCxpRequestErrorsUtil.class)
public class SOEErrorHandlerUtilTest {

	@Autowired
	private ObjectMapper mapper;

	@Test
	public void handleRetrieveCartRequestErrorsTest() {
		CXPRetrieveCartDataVO cxpRetrieveCartDataVO = new CXPRetrieveCartDataVO();
		cxpRetrieveCartDataVO.setCartId("09cfa680-f331-4c03-b83f-e27322882457");
		ErrorResponse errors = CartCxpRequestErrorsUtil.handleRetrieveCartRequestErrors(
				new RetrieveCartCXPRequest(new HashMap<String, String>(), cxpRetrieveCartDataVO, null, null, null, false,false,false));

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void handleValidateCartRequestErrorsTest() {
		ValidateCartCXPRequest validateCartCXPRequest = new ValidateCartCXPRequest();
		validateCartCXPRequest.setCartId("09cfa680-f331-4c03-b83f-e27322882457");
		ErrorResponse errors = CartCxpRequestErrorsUtil.handleValidateCartRequestErrors(validateCartCXPRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleUpdateUserInfoRequestErrorsTest() {
		UpdateUserInfoUIRequest updateUserInfoUIRequest = new UpdateUserInfoUIRequest();
		updateUserInfoUIRequest.setCartId("09cfa680-f331-4c03-b83f-e27322882457");
		updateUserInfoUIRequest.setIntendType("AAL");

		ErrorResponse errors = CartCxpRequestErrorsUtil.handleUpdateUserInfoRequestErrors(updateUserInfoUIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleUpdateUserInfoRequestErrorsConditionTest() {
		UpdateUserInfoUIRequest updateUserInfoUIRequest = new UpdateUserInfoUIRequest();
		updateUserInfoUIRequest.setCartId("09cfa680-f331-4c03-b83f-e27322882457");
		updateUserInfoUIRequest.setIntendType("AAL");
		UpdateUserInfoLine updateUserInfoLine = new UpdateUserInfoLine();
		updateUserInfoLine.setFirstName("TestName");
		List<UpdateUserInfoLine> lines = new ArrayList<>();
		lines.add(updateUserInfoLine);
		updateUserInfoUIRequest.setLines(lines);

		ErrorResponse errors = CartCxpRequestErrorsUtil.handleUpdateUserInfoRequestErrors(updateUserInfoUIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handlePaperlessBillingRequestErrorsTest() {
		PaperlessBillingUIRequest paperlessBillingUIRequest = new PaperlessBillingUIRequest();
		paperlessBillingUIRequest.setCartId("09cfa680-f331-4c03-b83f-e27322882457");
		paperlessBillingUIRequest.setIntendType("AAL");
		ErrorResponse errors = CartCxpRequestErrorsUtil.handlePaperlessBillingRequestErrors(paperlessBillingUIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleSaveCartRequestErrorsTest() {
		SaveCartUIRequest saveCartUIRequest = new SaveCartUIRequest();
		saveCartUIRequest.setCartInfo(new CartInfo());
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleSaveCartRequestErrors(saveCartUIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}



	@Test
	public void handleUpdateTradeinTypeRequestErrorsTest() {
		UpdateTradeinTypeUIRequest updateTradeinTypeUIRequest = new UpdateTradeinTypeUIRequest();
		updateTradeinTypeUIRequest.setCartId("09cfa680-f331-4c03-b83f-e27322882457");
		updateTradeinTypeUIRequest.setIntendType("AAL");

		ErrorResponse errors = CartCxpRequestErrorsUtil.handleUpdateTradeinTypeRequestErrors(updateTradeinTypeUIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleUpdateSellerPriceRequestErrorsTest() {
		UpdateSellerPriceUIRequest updateSellerPriceUIRequest = new UpdateSellerPriceUIRequest();
		updateSellerPriceUIRequest.setCartId("09cfa680-f331-4c03-b83f-e27322882457");
		updateSellerPriceUIRequest.setIntendType("AAL");

		ErrorResponse errors = CartCxpRequestErrorsUtil.handleUpdateSellerPriceRequestErrors(updateSellerPriceUIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleUpdateSellerPriceRequestErrorsConditionTest() {
		UpdateSellerPriceUIRequest updateSellerPriceUIRequest = new UpdateSellerPriceUIRequest();
		UpdateSellerPriceLine updateSellerPriceLine = new UpdateSellerPriceLine();
		List<UpdateSellerPriceLine> lines = new ArrayList<>();
		lines.add(updateSellerPriceLine);
		updateSellerPriceUIRequest.setCartId("09cfa680-f331-4c03-b83f-e27322882457");
		updateSellerPriceUIRequest.setIntendType("AAL");
		updateSellerPriceUIRequest.setLines(lines);

		ErrorResponse errors = CartCxpRequestErrorsUtil.handleUpdateSellerPriceRequestErrors(updateSellerPriceUIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}


	@Test
	public void handleAddDeviceRequestErrorsTest() {

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDeviceRequestErrors(
				new AddDeviceUIRequest(new DeviceCartInfo(), new AddDeviceData(),null,null, null, null, null,null,null,null,null, null,null,null,null, null,null,null,null,null,false,false));
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleInitiateCheckoutResponseExceptionsTest() {
		CartException[] cartExceptionArray = { new CartException() };

		ErrorResponse errors = CartPegaResponseErrorsUtil
				.handleInitiateCheckoutResponseErrors(new InitiateCheckoutUIResponse(cartExceptionArray,
						new CartServiceServiceHeader(), new InitiateCheckoutServiceBody(), null, null, null, null, null, null, null,null));

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleInitiateCheckoutResponseNoErrorsTest() {

		ErrorResponse errors = CartPegaResponseErrorsUtil
				.handleInitiateCheckoutResponseErrors(new InitiateCheckoutUIResponse(null,
						new CartServiceServiceHeader(), new InitiateCheckoutServiceBody(), null, null, null, null, null, null, null,null));

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleInitiateCheckoutResponseErrorsTest() {
		CartException[] cartExceptionArray = { new CartException() };
		List<CartError> errorList = new ArrayList<CartError>();
		List<CartErrorDetail> detailList = new ArrayList<>();
		CartError cartError = new CartError();
		CartErrorDetail detail = new CartErrorDetail();
		detail.setField("CartId");
		detail.setLocation("request");
		detail.setValue("null/blank");
		detail.setIssue("Cart id is missing");
		detailList.add(detail);
		cartError.setDetailList(detailList);
		errorList.add(cartError);
		ErrorResponse errors = CartPegaResponseErrorsUtil
				.handleInitiateCheckoutResponseErrors(new InitiateCheckoutUIResponse(cartExceptionArray,
						new CartServiceServiceHeader(), new InitiateCheckoutServiceBody(), null, errorList, null, null, null, null, null,null));

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleRemoveLinesRequestErrorsTest() {

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleRemoveLinesRequestErrors(

				new RemoveLinesUIRequest(new CartInfo(), new RemoveLinesData(), null, null, null,false));

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleRemoveLinesRequestCaseIdErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"467e2a19-c2cb-4d79-b042-22e75c16bb39\",\"caseId\":\"\",\"accountNumber\":\"0517953243-00001\",\"cartCreator\":\"3013513888\",\"processingMTN\":\"3013513888\"},\"data\":{\"lines\":[{\"mtn\":\"3013513888\"},{\"mtn\":\"3013513834\"}]}}";
		RemoveLinesUIRequest UIRequest = mapper.readValue(sampleRequestString, RemoveLinesUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleRemoveLinesRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleRemoveLinesRequestAccountNumberErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"467e2a19-c2cb-4d79-b042-22e75c16bb39\",\"caseId\":\"SOP-507867-E01\",\"accountNumber\":\"\",\"cartCreator\":\"3013513888\",\"processingMTN\":\"3013513888\"},\"data\":{\"lines\":[{\"mtn\":\"3013513888\"},{\"mtn\":\"3013513834\"}]}}";
		RemoveLinesUIRequest UIRequest = mapper.readValue(sampleRequestString, RemoveLinesUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleRemoveLinesRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleRemoveLinesRequestCartCreatorErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"467e2a19-c2cb-4d79-b042-22e75c16bb39\",\"caseId\":\"SOP-507867-E01\",\"accountNumber\":\"0517953243-00001\",\"cartCreator\":\"\",\"processingMTN\":\"3013513888\"},\"data\":{\"lines\":[{\"mtn\":\"3013513888\"},{\"mtn\":\"3013513834\"}]}}";
		RemoveLinesUIRequest UIRequest = mapper.readValue(sampleRequestString, RemoveLinesUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleRemoveLinesRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleRemoveLinesRequestProcessingMTNErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"467e2a19-c2cb-4d79-b042-22e75c16bb39\",\"caseId\":\"SOP-507867-E01\",\"accountNumber\":\"0517953243-00001\",\"cartCreator\":\"3013513888\",\"processingMTN\":\"\"},\"data\":{\"lines\":[{\"mtn\":\"3013513888\"},{\"mtn\":\"3013513834\"}]}}";
		RemoveLinesUIRequest UIRequest = mapper.readValue(sampleRequestString, RemoveLinesUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleRemoveLinesRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

	}

	@Test
	public void handleRemoveLinesRequestLinesErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"467e2a19-c2cb-4d79-b042-22e75c16bb39\",\"caseId\":\"SOP-507867-E01\",\"accountNumber\":\"0517953243-00001\",\"cartCreator\":\"3013513888\",\"processingMTN\":\"3013513888\"},\"data\":{\"lines\":null}}";
		RemoveLinesUIRequest UIRequest = mapper.readValue(sampleRequestString, RemoveLinesUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleRemoveLinesRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleRemoveLinesRequestLinesMTNErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"467e2a19-c2cb-4d79-b042-22e75c16bb39\",\"caseId\":\"SOP-507867-E01\",\"accountNumber\":\"0517953243-00001\",\"cartCreator\":\"3013513888\",\"processingMTN\":\"3013513888\"},\"data\":{\"lines\":[{\"mtn\":\"\"},{\"mtn\":\"\"}]}}";
		RemoveLinesUIRequest UIRequest = mapper.readValue(sampleRequestString, RemoveLinesUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleRemoveLinesRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleRemoveLinesResponseExceptionsTest() {
		CartException[] cartExceptionArray = { new CartException() };

		ErrorResponse errors = CartPegaResponseErrorsUtil.handleRemoveLinesResponseErrors(new RemoveLinesUIResponse(
				cartExceptionArray, new CartServiceServiceHeader(), new RemoveLinesServiceBody(), null, null,null));

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleRemoveLinesResponseNoErrorsTest() {

		ErrorResponse errors = CartPegaResponseErrorsUtil.handleRemoveLinesResponseErrors(
				new RemoveLinesUIResponse(null, new CartServiceServiceHeader(), new RemoveLinesServiceBody(), null,null, null));

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleRemoveLinesResponseErrorsTest() {
		CartException[] cartExceptionArray = { new CartException() };
		ErrorResponse errors = CartPegaResponseErrorsUtil.handleRemoveLinesResponseErrors(new RemoveLinesUIResponse(
				cartExceptionArray, new CartServiceServiceHeader(), new RemoveLinesServiceBody(), null,null, null));

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handlePastDuesRequestErrorsTest() {

		ErrorResponse errors = CartPegaRequestErrorsUtil.handlePastDuesRequestErrors(
				new PastDuesUIRequest(new CartInfo(), new PastDuesData(), null, null, null));

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddDeviceRequestCaseIdErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\",\"caseId\":\"\",\"accountNumber\":\"0820215913-00001\",\"cartCreator\":\"6154839959\",\"processingMTN\":\"6154839959\"},\"data\":{\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"2059376950\",\"contractTerm\":\"MONTH_TO_MONTH\",\"device\":{\"id\":\"MN382LL/A\"},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"isKeepingExistingEqProtection\":true}],\"newLineOrAAL\":false}}";
		AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDeviceRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddDeviceRequestAccountNumberErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\",\"caseId\":\"SOP-329-E01\",\"accountNumber\":\"\",\"cartCreator\":\"6154839959\",\"processingMTN\":\"6154839959\"},\"data\":{\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"2059376950\",\"contractTerm\":\"MONTH_TO_MONTH\",\"device\":{\"id\":\"MN382LL/A\"},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"isKeepingExistingEqProtection\":true}],\"newLineOrAAL\":false}}";
		AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDeviceRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddDeviceRequestCartCreatorErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\",\"caseId\":\"SOP-329-E01\",\"accountNumber\":\"0820215913-00001\",\"cartCreator\":\"\",\"processingMTN\":\"6154839959\"},\"data\":{\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"2059376950\",\"contractTerm\":\"MONTH_TO_MONTH\",\"device\":{\"id\":\"MN382LL/A\"},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"isKeepingExistingEqProtection\":true}],\"newLineOrAAL\":false}}";
		AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDeviceRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddDeviceRequestProcessingMTNErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\",\"caseId\":\"SOP-329-E01\",\"accountNumber\":\"0820215913-00001\",\"cartCreator\":\"6154839959\",\"processingMTN\":\"\"},\"data\":{\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"2059376950\",\"contractTerm\":\"MONTH_TO_MONTH\",\"device\":{\"id\":\"MN382LL/A\"},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"isKeepingExistingEqProtection\":true}],\"newLineOrAAL\":false}}";
		AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDeviceRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddDeviceRequestDepletionTypeErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\",\"caseId\":\"SOP-329-E01\",\"accountNumber\":\"0820215913-00001\",\"cartCreator\":\"6154839959\",\"processingMTN\":\"6154839959\"},\"data\":{\"depletionType\":\"\",\"lines\":[{\"mtn\":\"2059376950\",\"contractTerm\":\"MONTH_TO_MONTH\",\"device\":{\"id\":\"MN382LL/A\"},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"isKeepingExistingEqProtection\":true}],\"newLineOrAAL\":false}}";
		AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDeviceRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddDeviceRequestLinesErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\",\"caseId\":\"SOP-329-E01\",\"accountNumber\":\"0820215913-00001\",\"cartCreator\":\"6154839959\",\"processingMTN\":\"6154839959\"},\"data\":{\"depletionType\":\"F\",\"lines\":null,\"newLineOrAAL\":false}}";
		AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDeviceRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddDeviceRequestLinesMTNErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\",\"caseId\":\"SOP-329-E01\",\"accountNumber\":\"0820215913-00001\",\"cartCreator\":\"6154839959\",\"processingMTN\":\"6154839959\"},\"data\":{\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"\",\"contractTerm\":\"MONTH_TO_MONTH\",\"device\":{\"id\":\"MN382LL/A\"},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"isKeepingExistingEqProtection\":true}],\"newLineOrAAL\":false}}";
		AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDeviceRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddDeviceRequestLineContractTermErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\",\"caseId\":\"SOP-329-E01\",\"accountNumber\":\"0820215913-00001\",\"cartCreator\":\"6154839959\",\"processingMTN\":\"6154839959\"},\"data\":{\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"2059376950\",\"contractTerm\":\"\",\"device\":{\"id\":\"MN382LL/A\"},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"isKeepingExistingEqProtection\":true}],\"newLineOrAAL\":false}}";
		AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDeviceRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddDeviceRequestLineDeviceErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\",\"caseId\":\"SOP-329-E01\",\"accountNumber\":\"0820215913-00001\",\"cartCreator\":\"6154839959\",\"processingMTN\":\"6154839959\"},\"data\":{\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"2059376950\",\"contractTerm\":\"MONTH_TO_MONTH\",\"device\":{\"id\":\"EMBD4GSIM-N\"},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"isKeepingExistingEqProtection\":true}],\"newLineOrAAL\":false}}";
		AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDeviceRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddDeviceRequestLineDeviceIdErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\",\"caseId\":\"SOP-329-E01\",\"accountNumber\":\"0820215913-00001\",\"cartCreator\":\"6154839959\",\"processingMTN\":\"6154839959\"},\"data\":{\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"2059376950\",\"contractTerm\":\"MONTH_TO_MONTH\",\"device\":{\"id\":\"\"},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"isKeepingExistingEqProtection\":true}],\"newLineOrAAL\":false}}";
		AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDeviceRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddDeviceRequestLineSimErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\",\"caseId\":\"SOP-329-E01\",\"accountNumber\":\"0820215913-00001\",\"cartCreator\":\"6154839959\",\"processingMTN\":\"6154839959\"},\"data\":{\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"2059376950\",\"contractTerm\":\"MONTH_TO_MONTH\",\"device\":{\"id\":\"MN382LL/A\"},\"sim\":null,\"ispuFlow\":false,\"isKeepingExistingEqProtection\":true}],\"newLineOrAAL\":false}}";
		AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDeviceRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddDeviceRequestLineSimIdErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\",\"caseId\":\"SOP-329-E01\",\"accountNumber\":\"0820215913-00001\",\"cartCreator\":\"6154839959\",\"processingMTN\":\"6154839959\"},\"data\":{\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"2059376950\",\"contractTerm\":\"MONTH_TO_MONTH\",\"device\":{\"id\":\"MN382LL/A\"},\"sim\":{\"id\":\"\"},\"ispuFlow\":false,\"isKeepingExistingEqProtection\":true}],\"newLineOrAAL\":false}}";
		AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDeviceRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddDeviceRequestLineErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\",\"caseId\":\"SOP-329-E01\",\"accountNumber\":\"0820215913-00001\",\"cartCreator\":\"6154839959\",\"processingMTN\":\"6154839959\"},\"data\":{\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"\",\"contractTerm\":\"\",\"device\":{\"id\":\"\"},\"sim\":null,\"ispuFlow\":false,\"isKeepingExistingEqProtection\":true}],\"newLineOrAAL\":false}}";
		AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDeviceRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddAccessoriesRequestErrorsTest() {

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddAccessoriesRequestErrors(
				new AddAccessoriesUIRequest(new CartInfo(), new AddAccessoriesData(), null, null, null,null,null,null,null,null, false,null));

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddAccessoriesRequestCaseIdErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"3014674968\",\"addAccessories\":[{\"sorId\":\"CATAPDPPL\",\"qty\":\"1\",\"price\":\"24.99\"}],\"mdnFilterValue\":\"3014674968\",\"ispuFlow\":false}],\"isSoftSku\":false}}";
		AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddAccessoriesRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddAccessoriesRequestAccountNumberErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"3014674968\",\"addAccessories\":[{\"sorId\":\"CATAPDPPL\",\"qty\":\"1\",\"price\":\"24.99\"}],\"mdnFilterValue\":\"3014674968\",\"ispuFlow\":false}],\"isSoftSku\":false}}";
		AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddAccessoriesRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddAccessoriesRequestCartCreatorErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"\",\"processingMTN\":\"4235344191\"},\"data\":{\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"3014674968\",\"addAccessories\":[{\"sorId\":\"CATAPDPPL\",\"qty\":\"1\",\"price\":\"24.99\"}],\"mdnFilterValue\":\"3014674968\",\"ispuFlow\":false}],\"isSoftSku\":false}}";
		AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddAccessoriesRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddAccessoriesRequestProcessingMTNErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"\"},\"data\":{\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"3014674968\",\"addAccessories\":[{\"sorId\":\"CATAPDPPL\",\"qty\":\"1\",\"price\":\"24.99\"}],\"mdnFilterValue\":\"3014674968\",\"ispuFlow\":false}],\"isSoftSku\":false}}";
		AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddAccessoriesRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddAccessoriesRequestDepletionTypeErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"depletionType\":null,\"lines\":[{\"mtn\":\"3014674968\",\"addAccessories\":[{\"sorId\":\"CATAPDPPL\",\"qty\":\"1\",\"price\":\"24.99\"}],\"mdnFilterValue\":\"3014674968\",\"ispuFlow\":false}],\"isSoftSku\":false}}";
		AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddAccessoriesRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddAccessoriesRequestLinesErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"depletionType\":\"F\",\"lines\":null,\"isSoftSku\":false}}";
		AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddAccessoriesRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddAccessoriesRequestLineMTNErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"\",\"addAccessories\":[{\"sorId\":\"CATAPDPPL\",\"qty\":\"1\",\"price\":\"24.99\"}],\"mdnFilterValue\":\"3014674968\",\"ispuFlow\":false}],\"isSoftSku\":false}}";
		AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddAccessoriesRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddAccessoriesRequestLineDepletionLocationCodeTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"depletionType\":\"F\", \"depletionLocationCode\": \"0026301\", \"lines\":[{\"mtn\":\"\",\"addAccessories\":[{\"sorId\":\"CATAPDPPL\",\"qty\":\"1\",\"price\":\"24.99\"}],\"mdnFilterValue\":\"3014674968\",\"ispuFlow\":false}],\"isSoftSku\":false}}";
		AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddAccessoriesRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddAccessoriesRequestNoAccessoriesErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"3014674968\",\"addAccessories\":null,\"mdnFilterValue\":\"3014674968\",\"ispuFlow\":false}],\"isSoftSku\":false}}";
		AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddAccessoriesRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddAccessoriesRequestNoAccessoryErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"3014674968\",\"addAccessories\":[],\"mdnFilterValue\":\"3014674968\",\"ispuFlow\":false}],\"isSoftSku\":false}}";
		AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddAccessoriesRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddAccessoriesRequestAccessorySorIdErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"3014674968\",\"addAccessories\":[{\"sorId\":\"\",\"qty\":\"1\",\"price\":\"24.99\"}],\"mdnFilterValue\":\"3014674968\",\"ispuFlow\":false}],\"isSoftSku\":false}}";
		AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);

		CartPegaRequestErrorsUtil.handleAddAccessoriesRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void handleAddAccessoriesRequestAccessoryQuantityErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"3014674968\",\"addAccessories\":[{\"sorId\":\"CATAPDPPL\",\"qty\":\"\",\"price\":\"24.99\"}],\"mdnFilterValue\":\"3014674968\",\"ispuFlow\":false}],\"isSoftSku\":false}}";
		AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddAccessoriesRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddAccessoriesRequestAccessoryZeroQuantityErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"3014674968\",\"addAccessories\":[{\"sorId\":\"CATAPDPPL\",\"qty\":\"0\",\"price\":\"24.99\"}],\"mdnFilterValue\":\"3014674968\",\"ispuFlow\":false}],\"isSoftSku\":false}}";
		AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddAccessoriesRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddAccessoriesRequestMultipleFieldsErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"depletionType\":\"\",\"lines\":[{\"mtn\":\"null\",\"addAccessories\":[{\"sorId\":\"\",\"qty\":\"\",\"price\":\"\"}],\"mdnFilterValue\":\"3014674968\",\"ispuFlow\":false}],\"isSoftSku\":false}}";
		AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddAccessoriesRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddAccessoriesResponseExceptionsTest() {
		CartException[] cartExceptionArray = { new CartException() };
		ErrorResponse errors = CartPegaResponseErrorsUtil.handleAddAccessoriesResponseErrors(new AddAccessoriesUIResponse(
				cartExceptionArray, new CartServiceServiceHeader(), new AddAccServiceBody(), null, null));

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddAccessoriesResponseNoErrorsTest() {
		ErrorResponse errors = CartPegaResponseErrorsUtil.handleAddAccessoriesResponseErrors(
				new AddAccessoriesUIResponse(null, new CartServiceServiceHeader(), new AddAccServiceBody(), null, null));

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddAccessoriesResponseErrorsTest() {
		CartException[] cartExceptionArray = { new CartException() };
		List<CartError> errorList = getCartErrorList();
		ErrorResponse errors = CartPegaResponseErrorsUtil.handleAddAccessoriesResponseErrors(new AddAccessoriesUIResponse(
				cartExceptionArray, new CartServiceServiceHeader(), new AddAccServiceBody(), errorList, null));

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddFeaturesRequestErrorsTest() {

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddFeaturesRequestErrors(
				new AddFeaturesUIRequest(new CartInfo(), new AddFeaturesData(), null, null, null, null, null,null));

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddFeaturesRequestFeatureQuantityErrorTest() throws IOException {
		//String sampleUIRequestString = "{\"cartInfo\": {\"clientAppName\": \"VZW-NETACE/VZW-ECOM\",\"cartId\": \"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\": \"SOP-508208-E01\",\"accountNumber\": \"0420194063-00001\",\"cartCreator\": \"4235342870\",\"processingMTN\": \"4235344191\",\"intendType\": \"EUP\",\"processStep\": \"FeaturesPDP\"},\"data\": {\"lines\": [{\"mtn\": \"4345949784\",\"features\": {\"add\": [{\"id\": \"82825\",\"type\": \"SFO\",\"quantity\": 1}],\"remove\": [{\"id\": \"82825\",\"type\": \"SFO\"}]}}]}}";
		String sampleUIRequestString =
				"{\"cartInfo\": {\"clientAppName\": \"VZW-NETACE/VZW-ECOM\",\"cartId\": \"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\": \"SOP-508208-E01\",\"accountNumber\": \"0420194063-00001\",\"cartCreator\": \"4235342870\",\"processingMTN\": \"4235344191\",\"intendType\": \"EUP\",\"processStep\": \"FeaturesPDP\"},\"data\": {\"lines\": [{\"mtn\": \"4345949784\",\"features\": {\"add\": [{\"id\": \"82825\",\"type\": \"SFO\",\"quantity\": 1}],\"remove\": [{\"id\": \"82825\",\"type\": \"SFO\"}]},\"mcsSubscription\": {\"add\": [{ \"itemId\": \"307220145\", \"pricePlanId\": \"35550960\", \"price\": 5.0, \"name\": \"Digital Secure - Line\", \"description\": \"Digital Secure - Line\", \"actionIndicator\": \"A\" }]},\"remove\": [{\"id\": \"82825\",\"type\": \"SFO\"}]}], \"account\": {\"features\": {\"add\": [{\"id\": \"82825\",\"type\": \"SFO\",\"quantity\": 1}],\"remove\": [{\"id\": \"82825\",\"type\": \"SFO\"}]},\"mcsSubscription\": {\"add\": [{ \"itemId\": \"307220145\", \"pricePlanId\": \"35550960\", \"price\": 5.0, \"name\": \"Digital Secure - Line\", \"description\": \"Digital Secure - Line\", \"actionIndicator\": \"A\" }]},\"remove\": [{\"id\": \"82825\",\"type\": \"SFO\"}]}}}";
		AddFeaturesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddFeaturesRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddFeaturesResponseErrorsTest() throws JsonProcessingException {

		String sampleUiResponseString = "{\n" +
				"    \"errorData\": {\n" +
				"        \"lines\": [\n" +
				"            {\n" +
				"                \"mtn\": \"9452510149\",\n" +
				"                \"anySpoOrSfoChangeIndicator\": \"E\",\n" +
				"                \"planValidationFailed\": \"true\",\n" +
				"                \"fomSFOActivity\": {\n" +
				"                    \"fomActionSFO1\": \"89412\",\n" +
				"                    \"fomReasonCodeDescription\": \"FOM Error on this line\",\n" +
				"                    \"fomActionSFO1Desc\": \"MOBILE HOT SPOT TRIGGER $0\",\n" +
				"                    \"fomActionReasonCode\": \"P\",\n" +
				"                    \"fomActionFeature1\": \"0\",\n" +
				"                    \"fomActionSFO2\": \"77249\"\n" +
				"                }\n" +
				"            }\n" +
				"        ],\n" +
				"        \"statusCode\": \"0\"\n" +
				"    },\n" +
				"    \"errors\": [\n" +
				"        {\n" +
				"            \"id\": \"3000\",\n" +
				"            \"message\": \"Validate plan domain service returned indicator 'E' for AnySpoOrSfoChangeIndicator\",\n" +
				"            \"debug_id\": \"2023-10-13T09:16:04.+0000:c8e809915d3ca367:cxp-shopping-services-8684bd9b66-xvgxf:kubernetes\",\n" +
				"            \"name\": \"VALIDATION_ERROR\"\n" +
				"        }\n" +
				"    ]\n" +
				"}";

		AddFeaturesUIResponse uiResponse = mapper.readValue(sampleUiResponseString,AddFeaturesUIResponse.class);
		//ErrorResponse errors = CartPegaResponseErrorsUtil.handleAddFeaturesResponseErrors(new AddFeaturesUIResponse());
		ErrorResponse errors = CartPegaResponseErrorsUtil.handleAddFeaturesResponseErrors(uiResponse);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddFeaturesRequestCartCreatorErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"cartId\": \"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\": \"SOP-508208-E01\",\"accountNumber\": \"0420194063-00001\",\"cartCreator\": \"\",\"processingMTN\": \"4235344191\",\"intendType\": \"EUP\",\"processStep\": \"FeaturesPDP\"},\"data\": {\"lines\": [{\"mtn\": \"4345949784\",\"features\": {\"add\": [{\"id\": \"82825\",\"type\": \"SFO\",\"quantity\": 1}],\"remove\": [{\"id\": \"82825\",\"type\": \"SFO\",\"quantity\": 1}]}}]}}";

		AddFeaturesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddFeaturesRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddFeaturesRequestProcessingMTNErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\": {\"clientAppName\": \"VZW-NETACE/VZW-ECOM\",\"cartId\": \"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\": \"SOP-508208-E01\",\"accountNumber\": \"0420194063-00001\",\"cartCreator\": \"4235342870\",\"processingMTN\": \"\",\"intendType\": \"EUP\",\"processStep\": \"FeaturesPDP\"},\"data\": {\"lines\": [{\"mtn\": \"4345949784\",\"features\": {\"add\": [{\"id\": \"82825\",\"type\": \"SFO\",\"quantity\": 1}],\"remove\": [{\"id\": \"82825\",\"type\": \"SFO\",\"quantity\": 1}]}}]}}";

		AddFeaturesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddFeaturesRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddFeaturesRequestLinesErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\": {\"clientAppName\": \"VZW-NETACE/VZW-ECOM\",\"cartId\": \"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\": \"SOP-508208-E01\",\"accountNumber\": \"0420194063-00001\",\"cartCreator\": \"4235342870\",\"processingMTN\": \"4235344191\",\"intendType\": \"EUP\",\"processStep\": \"FeaturesPDP\"},\"data\": {\"lines\": null}}";

		AddFeaturesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddFeaturesRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddFeaturesRequestLineMTNErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\": {\"clientAppName\": \"VZW-NETACE/VZW-ECOM\",\"cartId\": \"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\": \"SOP-508208-E01\",\"accountNumber\": \"0420194063-00001\",\"cartCreator\": \"4235342870\",\"processingMTN\": \"4235344191\",\"intendType\": \"EUP\",\"processStep\": \"FeaturesPDP\"},\"data\": {\"lines\": [{\"mtn\": \"\",\"features\": {\"add\": [{\"id\": \"82825\",\"type\": \"SFO\",\"quantity\": 1}],\"remove\": [{\"id\": \"82825\",\"type\": \"SFO\",\"quantity\": 1}]}}]}}";

		AddFeaturesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddFeaturesRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleRetrieveCartResponseErrorsTest() {

		ErrorResponse errors = CartCxpResponseErrorsUtil
				.handleRetrieveCartResponseErrors(new RetrieveCartUIResponse(new CartError[] { new CartError() },
						new CartWarning[1], new CXPRetrieveCartDataVO(), new HashMap<String, String>(), null, null));

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddDeviceResponseExceptionsTest() {
		CartException[] cartExceptionArray = { new CartException() };
		ErrorResponse errors = CartPegaResponseErrorsUtil.handleAddDeviceResponseErrors(new AddDeviceUIResponse(
				cartExceptionArray, new CartServiceServiceHeader(), new AddDeviceServiceBody(), null,null, null,null,false,false,false));

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddDeviceResponseNoErrorsTest() {

		ErrorResponse errors = CartPegaResponseErrorsUtil.handleAddDeviceResponseErrors(
				new AddDeviceUIResponse(null, new CartServiceServiceHeader(), new AddDeviceServiceBody(), null,null, null,null,false,false,false));

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddDeviceResponseErrorsTest() {
		CartException[] cartExceptionArray = { new CartException() };
		List<CartError> errorList = getCartErrorList();
		ErrorResponse errors = CartPegaResponseErrorsUtil.handleAddDeviceResponseErrors(new AddDeviceUIResponse(
				cartExceptionArray, new CartServiceServiceHeader(), new AddDeviceServiceBody(), errorList,null, null,null,false,false,false));

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddPlanRequestErrorsTest() {
		Lines [] lines = new Lines[1];
		Lines line = new Lines();
		lines[0] =line;
		AddPlanData addPlanData = new AddPlanData();
		addPlanData.setLines(lines);
		ServerHttpRequest httpHeader = MockServerHttpRequest.get("http://localhost/").build();
		ErrorResponse errors = CartPegaRequestErrorsUtil
				.handleAddPlanRequestErrors(new AddPlanUIRequest(new CartInfo(), addPlanData, null, null, null, false, false,null,null,null,false,false), httpHeader);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}


	@Test
	public void handleAddPlanRequestCaseIdErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"lines\":[{\"mtn\":\"9207400273\",\"plan\":{\"sorId\":\"97928\"}}]}}";
		AddPlanUIRequest UIRequest = mapper.readValue(sampleRequestString, AddPlanUIRequest.class);
		ServerHttpRequest httpHeader = MockServerHttpRequest.get("http://localhost/").build();
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddPlanRequestErrors(UIRequest, httpHeader);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddPlanReuqestAccountNumErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"lines\":[{\"mtn\":\"9207400273\",\"plan\":{\"sorId\":\"97928\"}}]}}";
		AddPlanUIRequest UIRequest = mapper.readValue(sampleRequestString, AddPlanUIRequest.class);
		ServerHttpRequest httpHeader = MockServerHttpRequest.get("http://localhost/").build();
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddPlanRequestErrors(UIRequest, httpHeader);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddPlanRequestCartCreatorErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"processingMTN\":\"4235344191\"},\"data\":{\"lines\":[{\"mtn\":\"9207400273\",\"plan\":{\"sorId\":\"97928\"}}]}}";
		AddPlanUIRequest UIRequest = mapper.readValue(sampleRequestString, AddPlanUIRequest.class);
		ServerHttpRequest httpHeader = MockServerHttpRequest.get("http://localhost/").build();
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddPlanRequestErrors(UIRequest, httpHeader);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddPlanRequestProcessingMTNErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\"},\"data\":{\"lines\":[{\"mtn\":\"9207400273\",\"plan\":{\"sorId\":\"97928\"}}]}}";
		AddPlanUIRequest UIRequest = mapper.readValue(sampleRequestString, AddPlanUIRequest.class);

		ServerHttpRequest httpHeader = MockServerHttpRequest.get("http://localhost/").build();
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddPlanRequestErrors(UIRequest, httpHeader);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddPlanRequestLinesErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{}}";
		AddPlanUIRequest UIRequest = mapper.readValue(sampleRequestString, AddPlanUIRequest.class);
		Lines [] lines = new Lines[1];
		Lines line = new Lines();
		lines[0] =line;
		AddPlanData addPlanData = new AddPlanData();
		addPlanData.setLines(lines);
		UIRequest.setData(addPlanData);
		ServerHttpRequest httpHeader = MockServerHttpRequest.get("http://localhost/").build();
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddPlanRequestErrors(UIRequest, httpHeader);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddPlanRequestLinesMTNErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"lines\":[{\"plan\":{\"sorId\":\"97928\"}}]}}";
		AddPlanUIRequest UIRequest = mapper.readValue(sampleRequestString, AddPlanUIRequest.class);

		ServerHttpRequest httpHeader = MockServerHttpRequest.get("http://localhost/").build();
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddPlanRequestErrors(UIRequest, httpHeader);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddPlanRequestMissingPlanErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"lines\":[{\"mtn\":\"9207400273\"}]}}";
		AddPlanUIRequest UIRequest = mapper.readValue(sampleRequestString, AddPlanUIRequest.class);

		ServerHttpRequest httpHeader = MockServerHttpRequest.get("http://localhost/").build();
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddPlanRequestErrors(UIRequest, httpHeader);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddBuyoutRequestErrorsTest() {

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddBuyoutRequestErrors(
				new AddBuyoutUIRequest(new CartInfo(), new AddBuyoutData(), null, null, null));

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddBuyoutRequestCaseIdErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\"},\"data\":{\"lines\":[{\"mtn\":\"11111111111\",\"downPayment\":{\"amount\":0.0,\"percentage\":10.0}},{\"mtn\":\"222222222222\",\"downPayment\":{\"amount\":0.0,\"percentage\":10.0}}]}}";
		AddBuyoutUIRequest UIRequest = mapper.readValue(sampleRequestString, AddBuyoutUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddBuyoutRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddBuyoutRequestAccountNumberErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"\",\"cartCreator\":\"4235342870\"},\"data\":{\"lines\":[{\"mtn\":\"11111111111\",\"downPayment\":{\"amount\":0.0,\"percentage\":10.0}},{\"mtn\":\"222222222222\",\"downPayment\":{\"amount\":0.0,\"percentage\":10.0}}]}}";
		AddBuyoutUIRequest UIRequest = mapper.readValue(sampleRequestString, AddBuyoutUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddBuyoutRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddBuyoutRequestCartCreatorErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"\"},\"data\":{\"lines\":[{\"mtn\":\"11111111111\",\"downPayment\":{\"amount\":0.0,\"percentage\":10.0}},{\"mtn\":\"222222222222\",\"downPayment\":{\"amount\":0.0,\"percentage\":10.0}}]}}";
		AddBuyoutUIRequest UIRequest = mapper.readValue(sampleRequestString, AddBuyoutUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddBuyoutRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddBuyoutRequestLinesErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\"},\"data\":{\"lines\":null}}";
		AddBuyoutUIRequest UIRequest = mapper.readValue(sampleRequestString, AddBuyoutUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddBuyoutRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddBuyoutRequestLinesMTNErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"downPayment\":{\"amount\":0.0,\"percentage\":10.0}},{\"mtn\":\"222222222222\",\"downPayment\":{\"amount\":0.0,\"percentage\":10.0}}]}}";
		AddBuyoutUIRequest UIRequest = mapper.readValue(sampleRequestString, AddBuyoutUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddBuyoutRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddBuyoutResponseExceptionsTest() {
		CartException[] cartExceptionArray = { new CartException() };
		ErrorResponse errors = CartPegaResponseErrorsUtil.handleAddBuyoutResponseErrors(new AddBuyoutUIResponse(
				cartExceptionArray, new CartServiceServiceHeader(), new AddBuyoutServiceBody(), null));

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddBuyoutResponseNoErrorsTest() {

		ErrorResponse errors = CartPegaResponseErrorsUtil.handleAddBuyoutResponseErrors(
				new AddBuyoutUIResponse(null, new CartServiceServiceHeader(), new AddBuyoutServiceBody(), null));

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddBuyoutResponseErrorsTest() {
		CartException[] cartExceptionArray = { new CartException() };
		List<CartError> errorList = getCartErrorList();
		ErrorResponse errors = CartPegaResponseErrorsUtil.handleAddBuyoutResponseErrors(new AddBuyoutUIResponse(
				cartExceptionArray, new CartServiceServiceHeader(), new AddBuyoutServiceBody(), errorList));

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddDownPaymentRequestErrorsTest() {

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDownPaymentRequestErrors(
				new DownPaymentUIRequest(new CartInfo(), new DownPaymentData(), null, null, null));

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddDownPaymentRequestCaseIdErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\"},\"data\":{\"lines\":[{\"mtn\":\"11111111111\",\"downPayment\":{\"amount\":0.0,\"percentage\":10.0}},{\"mtn\":\"222222222222\",\"downPayment\":{\"amount\":0.0,\"percentage\":10.0}}]}}";
		DownPaymentUIRequest UIRequest = mapper.readValue(sampleRequestString, DownPaymentUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDownPaymentRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddDownPaymentRequestAccountNumberErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"\",\"cartCreator\":\"4235342870\"},\"data\":{\"lines\":[{\"mtn\":\"11111111111\",\"downPayment\":{\"amount\":0.0,\"percentage\":10.0}},{\"mtn\":\"222222222222\",\"downPayment\":{\"amount\":0.0,\"percentage\":10.0}}]}}";
		DownPaymentUIRequest UIRequest = mapper.readValue(sampleRequestString, DownPaymentUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDownPaymentRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddDownPaymentRequestCartCreatorErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"\"},\"data\":{\"lines\":[{\"mtn\":\"11111111111\",\"downPayment\":{\"amount\":0.0,\"percentage\":10.0}},{\"mtn\":\"222222222222\",\"downPayment\":{\"amount\":0.0,\"percentage\":10.0}}]}}";
		DownPaymentUIRequest UIRequest = mapper.readValue(sampleRequestString, DownPaymentUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDownPaymentRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddDownPaymentRequestLinesErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\"},\"data\":{\"lines\":null}}";
		AddBuyoutUIRequest UIRequest = mapper.readValue(sampleRequestString, AddBuyoutUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddBuyoutRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddDownPaymentRequestLinesMTNErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"downPayment\":{\"amount\":0.0,\"percentage\":10.0}},{\"mtn\":\"222222222222\",\"downPayment\":{\"amount\":0.0,\"percentage\":10.0}}]}}";
		DownPaymentUIRequest UIRequest = mapper.readValue(sampleRequestString, DownPaymentUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDownPaymentRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddDownPaymentRequestDownPaymentErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\"},\"data\":{\"lines\":[{\"mtn\":\"11111111111\",\"downPayment\":null},{\"mtn\":\"222222222222\",\"downPayment\":{\"amount\":0.0,\"percentage\":10.0}}]}}";
		DownPaymentUIRequest UIRequest = mapper.readValue(sampleRequestString, DownPaymentUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDownPaymentRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddDownPaymentRequestDownPaymentAmountErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\"},\"data\":{\"lines\":[{\"mtn\":\"11111111111\",\"downPayment\":{\"amount\":0.0,\"percentage\":10.0}},{\"mtn\":\"222222222222\",\"downPayment\":{\"amount\":null,\"percentage\":10.0}}]}}";
		DownPaymentUIRequest UIRequest = mapper.readValue(sampleRequestString, DownPaymentUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDownPaymentRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddDownPaymentRequestDownPaymentPercentageErrorTest() throws IOException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\"},\"data\":{\"lines\":[{\"mtn\":\"11111111111\",\"downPayment\":{\"amount\":0.0,\"percentage\":10.0}},{\"mtn\":\"222222222222\",\"downPayment\":{\"amount\":0.0,\"percentage\":null}}]}}";
		DownPaymentUIRequest UIRequest = mapper.readValue(sampleRequestString, DownPaymentUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDownPaymentRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddDownPaymentResponseExceptionsTest() {
		List<CartException> cartExceptionList = new ArrayList<CartException>();
		CartException exception = new CartException();
		cartExceptionList.add(exception);
		ErrorResponse errors = CartPegaResponseErrorsUtil.handleAddDownPaymentResponseErrors(new AddDownPaymentUIResponse(
				new CartServiceServiceHeader(), new DownPaymentServiceBody(), cartExceptionList, null));

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddDownPaymentResponseNoErrorsTest() {

		ErrorResponse errors = CartPegaResponseErrorsUtil.handleAddDownPaymentResponseErrors(
				new AddDownPaymentUIResponse(new CartServiceServiceHeader(), new DownPaymentServiceBody(), null, null));

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddDownPaymentResponseErrorsTest() {
		List<CartException> cartExceptionList = new ArrayList<>();
		CartException exception = new CartException();
		cartExceptionList.add(exception);
		List<CartError> errorList = getCartErrorList();
		ErrorResponse errors = CartPegaResponseErrorsUtil.handleAddDownPaymentResponseErrors(new AddDownPaymentUIResponse(
				new CartServiceServiceHeader(), new DownPaymentServiceBody(), cartExceptionList, errorList));

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddEdgeUpRequestErrorsTest() {

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddEdgeUpRequestErrors(
				new UpdateEdgeupUIRequest(new CartInfo(), new UpdateEdgeupData(), null, null, null));

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddEdgeUpRequestCaseIdErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"buyOutFlag\":\"Y\",\"buyOutSelected\":\"N\",\"edgeUpSelected\":\"Y\",\"FMITurnedoff\":\"Y\",\"deviceMisMatched\":\"N\"},\"data\":{\"lines\":[{\"mtn\":\"2158806687\",\"edgeup\":{\"deviceId\":\"356110090934891\",\"edgeupAmount\":140.25}}],\"effectiveDate\":\"09/26/2019\"}}";
		UpdateEdgeupUIRequest UIRequest = mapper.readValue(sampleUIRequestString, UpdateEdgeupUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddEdgeUpRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddEdgeUpRequestAccountNumberErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"buyOutFlag\":\"Y\",\"buyOutSelected\":\"N\",\"edgeUpSelected\":\"Y\",\"FMITurnedoff\":\"Y\",\"deviceMisMatched\":\"N\"},\"data\":{\"lines\":[{\"mtn\":\"2158806687\",\"edgeup\":{\"deviceId\":\"356110090934891\",\"edgeupAmount\":140.25}}],\"effectiveDate\":\"09/26/2019\"}}";
		UpdateEdgeupUIRequest UIRequest = mapper.readValue(sampleUIRequestString, UpdateEdgeupUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddEdgeUpRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddEdgeUpRequestCartCreatorErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"\",\"processingMTN\":\"4235344191\",\"buyOutFlag\":\"Y\",\"buyOutSelected\":\"N\",\"edgeUpSelected\":\"Y\",\"FMITurnedoff\":\"Y\",\"deviceMisMatched\":\"N\"},\"data\":{\"lines\":[{\"mtn\":\"2158806687\",\"edgeup\":{\"deviceId\":\"356110090934891\",\"edgeupAmount\":140.25}}],\"effectiveDate\":\"09/26/2019\"}}";
		UpdateEdgeupUIRequest UIRequest = mapper.readValue(sampleUIRequestString, UpdateEdgeupUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddEdgeUpRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddEdgeUpRequestProcessingMTNErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"\",\"buyOutFlag\":\"Y\",\"buyOutSelected\":\"N\",\"edgeUpSelected\":\"Y\",\"FMITurnedoff\":\"Y\",\"deviceMisMatched\":\"N\"},\"data\":{\"lines\":[{\"mtn\":\"2158806687\",\"edgeup\":{\"deviceId\":\"356110090934891\",\"edgeupAmount\":140.25}}],\"effectiveDate\":\"09/26/2019\"}}";
		UpdateEdgeupUIRequest UIRequest = mapper.readValue(sampleUIRequestString, UpdateEdgeupUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddEdgeUpRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddEdgeUpRequestBuyOutFlagErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"buyOutFlag\":\"\",\"buyOutSelected\":\"N\",\"edgeUpSelected\":\"Y\",\"FMITurnedoff\":\"Y\",\"deviceMisMatched\":\"N\"},\"data\":{\"lines\":[{\"mtn\":\"2158806687\",\"edgeup\":{\"deviceId\":\"356110090934891\",\"edgeupAmount\":140.25}}],\"effectiveDate\":\"09/26/2019\"}}";
		UpdateEdgeupUIRequest UIRequest = mapper.readValue(sampleUIRequestString, UpdateEdgeupUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddEdgeUpRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddEdgeUpRequestBuyOutSelectedErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"buyOutFlag\":\"Y\",\"buyOutSelected\":\"\",\"edgeUpSelected\":\"Y\",\"FMITurnedoff\":\"Y\",\"deviceMisMatched\":\"N\"},\"data\":{\"lines\":[{\"mtn\":\"2158806687\",\"edgeup\":{\"deviceId\":\"356110090934891\",\"edgeupAmount\":140.25}}],\"effectiveDate\":\"09/26/2019\"}}";
		UpdateEdgeupUIRequest UIRequest = mapper.readValue(sampleUIRequestString, UpdateEdgeupUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddEdgeUpRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddEdgeUpEdgeUpSelectedRequestErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"buyOutFlag\":\"Y\",\"buyOutSelected\":\"N\",\"edgeUpSelected\":\"\",\"FMITurnedoff\":\"Y\",\"deviceMisMatched\":\"N\"},\"data\":{\"lines\":[{\"mtn\":\"2158806687\",\"edgeup\":{\"deviceId\":\"356110090934891\",\"edgeupAmount\":140.25}}],\"effectiveDate\":\"09/26/2019\"}}";
		UpdateEdgeupUIRequest UIRequest = mapper.readValue(sampleUIRequestString, UpdateEdgeupUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddEdgeUpRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddEdgeUpRequestFmiTurnedOffErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"buyOutFlag\":\"Y\",\"buyOutSelected\":\"N\",\"edgeUpSelected\":\"Y\",\"FMITurnedoff\":\"\",\"deviceMisMatched\":\"N\"},\"data\":{\"lines\":[{\"mtn\":\"2158806687\",\"edgeup\":{\"deviceId\":\"356110090934891\",\"edgeupAmount\":140.25}}],\"effectiveDate\":\"09/26/2019\"}}";
		UpdateEdgeupUIRequest UIRequest = mapper.readValue(sampleUIRequestString, UpdateEdgeupUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddEdgeUpRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddEdgeUpRequestDeviceMismatchedErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"buyOutFlag\":\"Y\",\"buyOutSelected\":\"N\",\"edgeUpSelected\":\"Y\",\"FMITurnedoff\":\"Y\",\"deviceMisMatched\":\"\"},\"data\":{\"lines\":[{\"mtn\":\"2158806687\",\"edgeup\":{\"deviceId\":\"356110090934891\",\"edgeupAmount\":140.25}}],\"effectiveDate\":\"09/26/2019\"}}";
		UpdateEdgeupUIRequest UIRequest = mapper.readValue(sampleUIRequestString, UpdateEdgeupUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddEdgeUpRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddEdgeUpRequestLineDetailsErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"buyOutFlag\":\"Y\",\"buyOutSelected\":\"N\",\"edgeUpSelected\":\"Y\",\"FMITurnedoff\":\"Y\",\"deviceMisMatched\":\"N\"},\"data\":{\"lines\":null,\"effectiveDate\":\"09/26/2019\"}}";
		UpdateEdgeupUIRequest UIRequest = mapper.readValue(sampleUIRequestString, UpdateEdgeupUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddEdgeUpRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddEdgeUpRequestLineMTNErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"buyOutFlag\":\"Y\",\"buyOutSelected\":\"N\",\"edgeUpSelected\":\"Y\",\"FMITurnedoff\":\"Y\",\"deviceMisMatched\":\"N\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"edgeup\":{\"deviceId\":\"356110090934891\",\"edgeupAmount\":140.25}}],\"effectiveDate\":\"09/26/2019\"}}";
		UpdateEdgeupUIRequest UIRequest = mapper.readValue(sampleUIRequestString, UpdateEdgeupUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddEdgeUpRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleUpdateEdgeUpResponseExceptionsTest() {
		CartException[] cartExceptionArray = { new CartException() };

		ErrorResponse errors = CartPegaResponseErrorsUtil.handleUpdateEdgeUpResponseErrors(new UpdateEdgeupUIResponse(
				cartExceptionArray, new CartServiceServiceHeader(), new UpdateEdgeupServiceBody(), null));

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleUpdateEdgeUpResponseNoErrorsTest() {

		ErrorResponse errors = CartPegaResponseErrorsUtil.handleUpdateEdgeUpResponseErrors(
				new UpdateEdgeupUIResponse(null, new CartServiceServiceHeader(), new UpdateEdgeupServiceBody(), null));

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleUpdateEdgeUpResponseErrorsTest() {
		CartException[] cartExceptionArray = { new CartException() };
		List<CartError> errorList = getCartErrorList();
		ErrorResponse errors = CartPegaResponseErrorsUtil.handleUpdateEdgeUpResponseErrors(new UpdateEdgeupUIResponse(
				cartExceptionArray, new CartServiceServiceHeader(), new UpdateEdgeupServiceBody(), errorList));

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}


	@Test
	public void updateUserInfoResponseErrorsTest() throws IOException, SOEHTTPException {

		String sampleResponseString = "{\"meta\":{\"timestamp\":\"2019-08-05T13:27:07Z\",\"cxpCorrelationId\":\"3d5f3c15-aa3b-4a42-9245-5cb4177468e4\"},\"errors\":[],\"data\":{\"cartId\":\"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\":\"Userinformationupdatedsuccessfully.\"}}";
		UpdateUserInfoUIResponse sampleResponse = null;
		sampleResponse = mapper.readValue(sampleResponseString, UpdateUserInfoUIResponse.class);
		ErrorResponse errors = CartCxpResponseErrorsUtil.handleUpdateUserInfoResponseErrors(sampleResponse);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleE911AddressRequestMissingFieldsErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\"},\"data\":{\"lines\":[{}]}}";
		E911AddressUIRequest UIRequest = mapper.readValue(sampleUIRequestString, E911AddressUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleE911AddressRequestErrors(UIRequest);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleE911AddressRequestMissingLinesErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\"},\"data\":{\"lines\":null}}";
		E911AddressUIRequest UIRequest = mapper.readValue(sampleUIRequestString, E911AddressUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleE911AddressRequestErrors(UIRequest);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleE911AddressRequestMissingAddressErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\"},\"data\":{\"lines\":[{\"e911Address\":{}}]}}";
		E911AddressUIRequest UIRequest = mapper.readValue(sampleUIRequestString, E911AddressUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleE911AddressRequestErrors(UIRequest);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void addE911AddressResponseErrorsTest() throws IOException, SOEHTTPException {

		String sampleResponseString = "{\"meta\":{\"timestamp\":\"2019-08-05T13:27:07Z\",\"cxpCorrelationId\":\"3d5f3c15-aa3b-4a42-9245-5cb4177468e4\"},\"errors\":[],\"data\":{\"cartId\":\"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\":\"Userinformationupdatedsuccessfully.\"}}";
		E911AddressUIResponse sampleResponse = null;
		sampleResponse = mapper.readValue(sampleResponseString, E911AddressUIResponse.class);
		ErrorResponse errors = CartPegaResponseErrorsUtil.handleE911AddressResponseErrors(sampleResponse);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void addServiceAddressResponseErrorsTest() throws IOException, SOEHTTPException {

		String sampleResponseString = "{\"meta\":{\"timestamp\":\"2019-08-05T13:27:07Z\",\"cxpCorrelationId\":\"3d5f3c15-aa3b-4a42-9245-5cb4177468e4\"},\"errors\":[],\"data\":{\"cartId\":\"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\":\"Userinformationupdatedsuccessfully.\"}}";
		ServiceAddressUIResponse sampleResponse = null;
		sampleResponse = mapper.readValue(sampleResponseString, ServiceAddressUIResponse.class);
		ErrorResponse errors = CartPegaResponseErrorsUtil.handleServiceAddressResponseErrors(sampleResponse);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleServiceAddressRequestMissingFieldsErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"\",\"correlationId\":\"\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\"},\"data\":{\"lines\":[]}}";
		ServiceAddressUIRequest UIRequest = mapper.readValue(sampleUIRequestString, ServiceAddressUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleServiceAddressRequestErrors(UIRequest);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleServiceAddressRequestMissingLinesErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\"},\"data\":{\"lines\":null}}";
		ServiceAddressUIRequest UIRequest = mapper.readValue(sampleUIRequestString, ServiceAddressUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleServiceAddressRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleServiceAddressRequestMissingLineMTNErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\"},\"data\":{\"lines\":[{\"mtn\":\"\"}]}}";
		ServiceAddressUIRequest UIRequest = mapper.readValue(sampleUIRequestString, ServiceAddressUIRequest.class);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleServiceAddressRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleServiceAddressRequestMissingAddressErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"serviceAddress\":{}}]}}";
		ServiceAddressUIRequest UIRequest = mapper.readValue(sampleUIRequestString, ServiceAddressUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleServiceAddressRequestErrors(UIRequest);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleInstantCreditDownPaymentRequestMissingFieldsErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"\",\"correlationId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\"},\"data\":{\"lines\":[{\"mtn\":\"\"}]}}";
		InstantCreditDownPaymentUIRequest UIRequest = mapper.readValue(sampleUIRequestString,
				InstantCreditDownPaymentUIRequest.class);
		ErrorResponse errors = CartCxpRequestErrorsUtil.handleInstantCreditDownPaymentRequestErrors(UIRequest);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleInstantCreditDownPaymentRequestMissingLinesErrorTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\"},\"data\":{\"lines\":null}}";
		InstantCreditDownPaymentUIRequest UIRequest = mapper.readValue(sampleUIRequestString,
				InstantCreditDownPaymentUIRequest.class);
		ErrorResponse errors = CartCxpRequestErrorsUtil.handleInstantCreditDownPaymentRequestErrors(UIRequest);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	private static List<CartError> getCartErrorList() {
		List<CartError> errorList = new ArrayList<>();
		List<CartErrorDetail> detailList = new ArrayList<>();
		CartError cartError = new CartError();
		CartErrorDetail detail = new CartErrorDetail();
		detail.setField("CartId");
		detail.setLocation("request");
		detail.setValue("null/blank");
		detail.setIssue("Cart id is missing");
		detailList.add(detail);
		cartError.setDetailList(detailList);
		errorList.add(cartError);
		return errorList;
	}


	@Test
	public void handleDeviceIdValidationRequestLineErrorTest() throws IOException {
		String sampleUIRequestString = "{\"data\":{}}";
		DeviceIdValidationUIRequest UIRequest = mapper.readValue(sampleUIRequestString, DeviceIdValidationUIRequest.class);

		CartPegaRequestErrorsUtil.handleDeviceIdValidationRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void handleDeviceIdValidationRequestDeviceIdErrorTest() throws IOException {
		String sampleUIRequestString = "{        \"cartInfo\": {                \"clientAppName\": \"VZW-NETACE\",                \"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",                \"processingMTN\": \"\",                                \"intent\": \"BYOD\",                \"processStep\": \"GridWallPDP\",                \"processAction\": \"validateGiftBoxId\"        },        \"data\": {                \"lines\": [{                        \"mtn\": \"6159691822\",                        \"device\": {                                        \"Flowtype\": \"GIFTBOX\",                                \"isCustomerProvidedEquipment\":true,                                \"giftBox\": {                                \"id\":\"LVSKPGB\"                        }                        }                }]        }}";
		DeviceIdValidationUIRequest UIRequest = mapper.readValue(sampleUIRequestString, DeviceIdValidationUIRequest.class);

		CartPegaRequestErrorsUtil.handleDeviceIdValidationRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void handleUpdateDeviceSIMIdRequestDataTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"cartId\":\"d4d16f93-087c-4c93-bde0-907caed4054f\",\"intendType\":\"EUP\"},\"data\":{}}";
		UpdateDeviceSIMIdUIRequest UIRequest = mapper.readValue(sampleUIRequestString, UpdateDeviceSIMIdUIRequest.class);

		CartPegaRequestErrorsUtil.handleUpdateDeviceSimIdRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void handleUpdateDeviceSIMIdRequestDeviceTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"cartId\":\"d4d16f93-087c-4c93-bde0-907caed4054f\",\"intendType\":\"EUP\"},\"data\":{\"lines\":[{\"mtn\":\"6183811681\",\"sim\":{\"id\":\"EMBD4GSIM-N\",\"simId\":\"89148000003715813858\",\"eSIM\":\"89148000003715813858\"}}]}}";
		UpdateDeviceSIMIdUIRequest UIRequest = mapper.readValue(sampleUIRequestString, UpdateDeviceSIMIdUIRequest.class);

		CartPegaRequestErrorsUtil.handleUpdateDeviceSimIdRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void handleUpdateDeviceSIMIdRequestIdTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"cartId\":\"d4d16f93-087c-4c93-bde0-907caed4054f\",\"intendType\":\"EUP\"},\"data\":{\"lines\":[{\"mtn\":\"6183811681\",\"device\":{\"id\":\"\",\"deviceId\":\"354441080447376\"},\"sim\":{\"id\":\"EMBD4GSIM-N\",\"simId\":\"89148000003715813858\",\"eSIM\":\"89148000003715813858\"}}]}}";
		UpdateDeviceSIMIdUIRequest UIRequest = mapper.readValue(sampleUIRequestString, UpdateDeviceSIMIdUIRequest.class);

		CartPegaRequestErrorsUtil.handleUpdateDeviceSimIdRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void handleUpdateDeviceSIMIdRequestDeviceIdTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"cartId\":\"d4d16f93-087c-4c93-bde0-907caed4054f\",\"intendType\":\"EUP\"},\"data\":{\"lines\":[{\"mtn\":\"6183811681\",\"device\":{\"id\":\"\",\"deviceId\":\"\"},\"sim\":{\"id\":\"EMBD4GSIM-N\",\"simId\":\"89148000003715813858\",\"eSIM\":\"89148000003715813858\"}}]}}";
		UpdateDeviceSIMIdUIRequest UIRequest = mapper.readValue(sampleUIRequestString, UpdateDeviceSIMIdUIRequest.class);

		CartPegaRequestErrorsUtil.handleUpdateDeviceSimIdRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void handleUpdateDeviceSIMIdRequestSimTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"cartId\":\"d4d16f93-087c-4c93-bde0-907caed4054f\",\"intendType\":\"EUP\"},\"data\":{\"lines\":[{\"mtn\":\"6183811681\",\"device\":{\"id\":\"MN382LL/A\",\"deviceId\":\"354441080447376\"},\"sim\":{\"id\":\"\",\"simId\":\"89148000003715813858\",\"eSIM\":\"89148000003715813858\"}}]}}";
		UpdateDeviceSIMIdUIRequest UIRequest = mapper.readValue(sampleUIRequestString, UpdateDeviceSIMIdUIRequest.class);

		CartPegaRequestErrorsUtil.handleUpdateDeviceSimIdRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void handleUpdateDeviceSIMIdRequestSimIdTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"cartId\":\"d4d16f93-087c-4c93-bde0-907caed4054f\",\"intendType\":\"EUP\"},\"data\":{\"lines\":[{\"mtn\":\"6183811681\",\"device\":{\"id\":\"MN382LL/A\",\"deviceId\":\"354441080447376\"},\"sim\":{\"id\":\"EMBD4GSIM-N\",\"simId\":\"\",\"eSIM\":\"89148000003715813858\"}}]}}";
		UpdateDeviceSIMIdUIRequest UIRequest = mapper.readValue(sampleUIRequestString, UpdateDeviceSIMIdUIRequest.class);

		CartPegaRequestErrorsUtil.handleUpdateDeviceSimIdRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void handleUpdateDeviceSIMIdRequesteSimTest() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"cartId\":\"d4d16f93-087c-4c93-bde0-907caed4054f\",\"intendType\":\"EUP\"},\"data\":{\"lines\":[{\"mtn\":\"6183811681\",\"device\":{\"id\":\"MN382LL/A\",\"deviceId\":\"354441080447376\"},\"sim\":{\"id\":\"EMBD4GSIM-N\",\"simId\":\"89148000003715813858\",\"eSIM\":\"\"}}]}}";
		UpdateDeviceSIMIdUIRequest UIRequest = mapper.readValue(sampleUIRequestString, UpdateDeviceSIMIdUIRequest.class);

		CartPegaRequestErrorsUtil.handleUpdateDeviceSimIdRequestErrors(UIRequest);

		StepVerifier.create(Mono.just(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void updatePurchaseOrderNoResponseErrorsTest() throws IOException, SOEHTTPException {

		String sampleResponseString = "{\"data\":{\"cartId\": \"d4d16f93-087c-4c93-bde0-907caed4054f\",\"statusCode\": 1,\"statusMsg\": \"Purchase Order Number Updated successfully\"}}";
        UpdatePurchaseOrderUIResponse sampleResponse = null;
		sampleResponse = mapper.readValue(sampleResponseString, UpdatePurchaseOrderUIResponse.class);
		ErrorResponse errors = CartPegaResponseErrorsUtil.handleUpdatePurchaseOrderResponseErrors(sampleResponse);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void splitExceededAmountResponseErrorsTest() throws IOException, SOEHTTPException {

		String sampleResponseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-ECOM\", \"statusMsg\": \"PEGA generated message\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"sessionId\": \"\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"0\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \" SOP-1583186-DEV3\", \"customerInfo\": { \"accountNumber\": \"07893451230-00001\", \"cartCreator\": \"2515813861\", \"processingMTN\": \"2515813860\" }, \"processMTNList\": [{ \"mtn\": \"2515813860\", \"completedprocessSteps\": [\"MTNSelectionPage\", \"GridWallPDP\"] }, { \"mtn\": \"2515813861\", \"completedprocessSteps\": [] }], \"cartInfo\": { \"cartId\": \"a705f835-c61a-4e20-b616-0c9839202a15\", \"statusCode\": \"1\", \"statusMsg\": \"\"  }, \"contextInfo\": { \"processAction\": \"\", \"processStep\": \"DownPayment\", \"availablePaths\": [{ \"path\": \" DownPayment `\" }], \"callReason\": \" SalesOrderPurchase \" } } } } }";
		SplitExceededAmountUIResponse sampleResponse = null;
		sampleResponse = mapper.readValue(sampleResponseString, SplitExceededAmountUIResponse.class);
		ErrorResponse errors = CartPegaResponseErrorsUtil.handleSplitExceededAmountResponseErrors(sampleResponse);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateVZCCAppStatusErrorsTest() throws IOException, SOEHTTPException {

		String requestString = "{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"status\":\"\"}";
		VZCCAppStatusUIRequest request = null;
		request = mapper.readValue(requestString, VZCCAppStatusUIRequest.class);
		ErrorResponse errors = CartCxpRequestErrorsUtil.handleVZCCAppStatusRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	//test cases for VZWCS-17115
	@Test
	public void handleInitiateCbandCheckRequestErrors() {
		InitiateCbandCheckUIRequest initiateCbandCheckUIRequest = new InitiateCbandCheckUIRequest();
		initiateCbandCheckUIRequest.setFlowType("imsi");
		initiateCbandCheckUIRequest.setImsi("311480589646564");

		ErrorResponse errors = CartCxpRequestErrorsUtil.handleInitiateCbandCheckRequestErrors(initiateCbandCheckUIRequest);

		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

    @Test
    public void handleInitiateCbandCheckRequestMissingFieldErrors() {
        InitiateCbandCheckUIRequest initiateCbandCheckUIRequest = new InitiateCbandCheckUIRequest();
        initiateCbandCheckUIRequest.setFlowType("");
        initiateCbandCheckUIRequest.setImsi("");

        ErrorResponse errors = CartCxpRequestErrorsUtil.handleInitiateCbandCheckRequestErrors(initiateCbandCheckUIRequest);

        StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void handleInitiateCbandCheckRequestConditionErrors() {
        InitiateCbandCheckUIRequest initiateCbandCheckUIRequest = new InitiateCbandCheckUIRequest();
        initiateCbandCheckUIRequest.setFlowType("imei");
        initiateCbandCheckUIRequest.setImsi("311480589646564");

        ErrorResponse errors = CartCxpRequestErrorsUtil.handleInitiateCbandCheckRequestErrors(initiateCbandCheckUIRequest);

        StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
	public void handleRetrieveCartRequestErrorsTest1() {
		CXPRetrieveCartDataVO cxpRetrieveCartDataVO = new CXPRetrieveCartDataVO();
		cxpRetrieveCartDataVO.setCartId("");
		ErrorResponse errors = CartCxpRequestErrorsUtil.handleRetrieveCartRequestErrors(new RetrieveCartCXPRequest(new HashMap<String, String>(), cxpRetrieveCartDataVO, null, null, null, false ,false, false));
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

    @Test
	public void handleValidateCartRequestErrorsTest1() {
		ValidateCartCXPRequest validateCartCXPRequest = new ValidateCartCXPRequest();
		validateCartCXPRequest.setCartId("");
		ErrorResponse errors = CartCxpRequestErrorsUtil.handleValidateCartRequestErrors(validateCartCXPRequest);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

    @Test
	public void handleUpdateUserInfoRequestErrorsTest1() throws JsonMappingException, JsonProcessingException {
    	String requestString = "{\"client\": \"CXP\",\"cartId\": \"09cfa680-f331-4c03-b83f-e27322882457\",\"lines\":[{\"mtn\": \"1234567890\",\"firstName\": \"Jane\",\"lastName\": \"Doe\",\"email\":\"xyz@vzcorp.com\"}]}";
    	UpdateUserInfoUIRequest request = mapper.readValue(requestString, UpdateUserInfoUIRequest.class);
		ErrorResponse errors = CartCxpRequestErrorsUtil.handleUpdateUserInfoRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

    @Test
	public void handlePaperlessBillingRequestErrorsTest1() throws JsonMappingException, JsonProcessingException {
    	String sampleUIRequestString = "{\"client\": \"CXP\",\"cartId\": \"bea202a6-42cb-40d4-ac87-d3f1db2b3f13\",\"intendType\": \"AAL\",\"paperlessbilling\": true}";
    	PaperlessBillingUIRequest request = mapper.readValue(sampleUIRequestString, PaperlessBillingUIRequest.class);
		ErrorResponse errors = CartCxpRequestErrorsUtil.handlePaperlessBillingRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

    @Test
	public void handleUpdateTradeinTypeRequestErrorsTest1() throws JsonMappingException, JsonProcessingException {
    	String sampleUIRequestString = "{ \"client\": \"CXP\", \"cartId\": \"bea202a6-42cb-40d4-ac87-d3f1db2b3f13\", \"intendType\": \"AAL\", \"tradeInType\": \"HOME\" }";
    	UpdateTradeinTypeUIRequest UIRequest = mapper.readValue(sampleUIRequestString, UpdateTradeinTypeUIRequest.class);
    	ErrorResponse errors = CartCxpRequestErrorsUtil.handleUpdateTradeinTypeRequestErrors(UIRequest);
    	StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

    @Test
	public void handleUpdateSellerPriceRequestErrorsTest1() throws JsonMappingException, JsonProcessingException {
    	String requestString = "{\"cartId\":\"bea202a6-42cb-40d4-ac87-d3f1db2b3f13\",\"intendType\":\"AAL\",\"mtn\":\"8767656434\",\"lines\": [{\"mtn\":\"7875453322\", \"sellerPrice\": 10.00}]}";
    	UpdateSellerPriceUIRequest request = mapper.readValue(requestString, UpdateSellerPriceUIRequest.class);
		ErrorResponse errors = CartCxpRequestErrorsUtil.handleUpdateSellerPriceRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

    @Test
	public void handleInstantCreditDownPaymentRequestErrorsTest1() throws IOException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"\",\"correlationId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\"},\"data\":{\"lines\":[{\"mtn\":\"7868768679\"}]}}";
		InstantCreditDownPaymentUIRequest UIRequest = mapper.readValue(sampleUIRequestString,InstantCreditDownPaymentUIRequest.class);
		ErrorResponse errors = CartCxpRequestErrorsUtil.handleInstantCreditDownPaymentRequestErrors(UIRequest);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

    @Test
	public void handleUpdateUserInfoRequestErrorsTest2() throws JsonMappingException, JsonProcessingException {
    	String requestString = "{\"client\": \"CXP\",\"cartId\": \"09cfa680-f331-4c03-b83f-e27322882457\",\"lines\":[{\"mtn\": \"1234567890\",\"firstName\": null,\"lastName\": \"Doe\",\"email\":\"xyz@vzcorp.com\"}]}";
    	UpdateUserInfoUIRequest request = mapper.readValue(requestString, UpdateUserInfoUIRequest.class);
		ErrorResponse errors = CartCxpRequestErrorsUtil.handleUpdateUserInfoRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

    @Test
   	public void handleRetrieveURCForCartRequestErrorsTest() throws JsonMappingException, JsonProcessingException {
       	String requestString = "{\"cartId\":\"df877858-671c-445b-a553-03cbec72c8b8\",\"cartMtnList\":[{\"mtn\":\"4106274520\",\"deviceSku\":\"MNF23LL/A\",\"reasonCodeType\":\"\"}]}";
       	RetrieveURCForCartUIRequest request = mapper.readValue(requestString, RetrieveURCForCartUIRequest.class);
   		ErrorResponse errors = CartCxpRequestErrorsUtil.handleRetrieveURCForCartRequestErrors(request);
   		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
   	}

    @Test
   	public void handleRetrieveURCForCartRequestErrorsTest1() throws JsonMappingException, JsonProcessingException {
       	String requestString = "{\"cartId\":null,\"cartMtnList\":null}";
       	RetrieveURCForCartUIRequest request = mapper.readValue(requestString, RetrieveURCForCartUIRequest.class);
   		ErrorResponse errors = CartCxpRequestErrorsUtil.handleRetrieveURCForCartRequestErrors(request);
   		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
   	}

    @Test
   	public void handleMacAddressRequestErrorsTest() throws JsonMappingException, JsonProcessingException {
       	String requestString = "{\"cartId\":\"bea202a6 - 42 cb - 40 d4 - ac87 - d3f1db2b3f13\",\"intendType\":\"EUP\",\"data\":{\"cartId\":\"bea202a6-42cb-40d4-ac87-d3f1db2b3f14\",\"intendType\":\"EUP\",\"lines\":[{\"mtn\":\"5467851254\",\"macAddress\":\"FC6257934C18\"}]}}";
       	MacAddressUIRequest request = mapper.readValue(requestString, MacAddressUIRequest.class);
   		ErrorResponse errors = CartCxpRequestErrorsUtil.handleMacAddressRequestErrors(request);
   		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
   	}

    @Test
   	public void handleMacAddressRequestErrorsTest1() throws JsonMappingException, JsonProcessingException {
       	String requestString = "{\"cartId\":null,\"intendType\":\"EUP\",\"data\":{\"cartId\":\"bea202a6-42cb-40d4-ac87-d3f1db2b3f14\",\"intendType\":\"EUP\",\"lines\":null}}";
       	MacAddressUIRequest request = mapper.readValue(requestString, MacAddressUIRequest.class);
   		ErrorResponse errors = CartCxpRequestErrorsUtil.handleMacAddressRequestErrors(request);
   		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
   	}

    @Test
   	public void handleManualDiscountRequestErrorsTest() throws JsonMappingException, JsonProcessingException {
       	String requestString = "{\"cartId\":\"bea202a6 - 42 cb - 40 d4 - ac87 - d3f1db2b3f13\",\"intendType\":\"EUP\",\"action\":\"ADD\",\"data\":{\"lines\":[{\"mtn\":\"7034070577\",\"manualDiscount\":[{\"skuId\":\"UPGRADEFEE\",\"discountReasonCode\":1,\"discountPercent\":0,\"discountAmount\":\"23\"}]}]}}";
       	ManualDiscountUIRequest request = mapper.readValue(requestString, ManualDiscountUIRequest.class);
   		ErrorResponse errors = CartCxpRequestErrorsUtil.handleManualDiscountRequestErrors(request);
   		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
   	}

    @Test
   	public void handleManualDiscountRequestErrorsTest1() throws JsonMappingException, JsonProcessingException {
       	String requestString = "{\"cartId\":\"bea202a6 - 42 cb - 40 d4 - ac87 - d3f1db2b3f13\",\"intendType\":\"EUP\",\"action\":null,\"data\":{\"lines\":null}}";
       	ManualDiscountUIRequest request = mapper.readValue(requestString, ManualDiscountUIRequest.class);
   		ErrorResponse errors = CartCxpRequestErrorsUtil.handleManualDiscountRequestErrors(request);
   		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
   	}

    @Test
   	public void handleManualDiscountRequestErrorsTest2() throws JsonMappingException, JsonProcessingException {
       	String requestString = "{\"cartId\":\"bea202a6 - 42 cb - 40 d4 - ac87 - d3f1db2b3f13\",\"intendType\":\"EUP\",\"action\":\"ADD\",\"data\":{\"lines\":[{\"mtn\":\"7034070577\",\"manualDiscount\":[{\"skuId\":\"UPGRADEFEE\",\"discountReasonCode\":null,\"discountPercent\":0,\"discountAmount\":\"23\"}]}]}}";
       	ManualDiscountUIRequest request = mapper.readValue(requestString, ManualDiscountUIRequest.class);
   		ErrorResponse errors = CartCxpRequestErrorsUtil.handleManualDiscountRequestErrors(request);
   		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
   	}

    @Test
   	public void handleManualDiscountRequestErrorsTest3() throws JsonMappingException, JsonProcessingException {
       	String requestString = "{\"cartId\":\"bea202a6 - 42 cb - 40 d4 - ac87 - d3f1db2b3f13\",\"intendType\":\"EUP\",\"action\":\"REMOVE\",\"data\":{\"lines\":[{\"mtn\":\"7034070577\",\"manualDiscount\":[{\"skuId\":\"UPGRADEFEE\",\"discountReasonCode\":null,\"discountPercent\":0,\"discountAmount\":\"23\"}]}]}}";
       	ManualDiscountUIRequest request = mapper.readValue(requestString, ManualDiscountUIRequest.class);
   		ErrorResponse errors = CartCxpRequestErrorsUtil.handleManualDiscountRequestErrors(request);
   		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
   	}

    @Test
   	public void handleManualDiscountRequestErrorsTest4() throws JsonMappingException, JsonProcessingException {
       	String requestString = "{\"cartId\":\"bea202a6 - 42 cb - 40 d4 - ac87 - d3f1db2b3f13\",\"intendType\":\"EUP\",\"action\":\"REMOVE\",\"data\":{\"lines\":[{\"mtn\":null,\"manualDiscount\":null}]}}";
       	ManualDiscountUIRequest request = mapper.readValue(requestString, ManualDiscountUIRequest.class);
   		ErrorResponse errors = CartCxpRequestErrorsUtil.handleManualDiscountRequestErrors(request);
   		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
   	}

    @Test
   	public void handleCustomerByMtnListRequestErrorsTest() throws JsonMappingException, JsonProcessingException {
       	String requestString = "{\"mtnList\":[\"5089588535\"]}";
       	CustomerByMtnListUIRequest request = mapper.readValue(requestString, CustomerByMtnListUIRequest.class);
   		ErrorResponse errors = CartCxpRequestErrorsUtil.handleCustomerByMtnListRequestErrors(request);
   		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
   	}

    @Test
   	public void handleCustomerByMtnListRequestErrorsTest1() throws JsonMappingException, JsonProcessingException {
       	String requestString = "{\"mtnList\":null}";
       	CustomerByMtnListUIRequest request = mapper.readValue(requestString, CustomerByMtnListUIRequest.class);
   		ErrorResponse errors = CartCxpRequestErrorsUtil.handleCustomerByMtnListRequestErrors(request);
   		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
   	}

    @Test
	public void updateVZCCAppStatusErrorsTest1() throws IOException, SOEHTTPException {
    	String requestString = "{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"vzccStatus\":{\"applicationStatus\":null,\"feedbackStatus\":null}}";
		VZCCAppStatusUIRequest request =  mapper.readValue(requestString, VZCCAppStatusUIRequest.class);
		ErrorResponse errors = CartCxpRequestErrorsUtil.handleVZCCAppStatusRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

    @Test
   	public void updateVZCCAppStatusErrorsTest2() throws IOException, SOEHTTPException {
       	String requestString = "{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"vzccStatus\":{\"applicationStatus\":null,\"feedbackStatus\":\"A\"}}";
   		VZCCAppStatusUIRequest request =  mapper.readValue(requestString, VZCCAppStatusUIRequest.class);
   		ErrorResponse errors = CartCxpRequestErrorsUtil.handleVZCCAppStatusRequestErrors(request);
   		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
   	}

    @Test
   	public void updateVZCCAppStatusErrorsTest3() throws IOException, SOEHTTPException {
       	String requestString = "{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"vzccStatus\":{\"applicationStatus\":\"active\",\"feedbackStatus\":\"A\"}}";
   		VZCCAppStatusUIRequest request =  mapper.readValue(requestString, VZCCAppStatusUIRequest.class);
   		ErrorResponse errors = CartCxpRequestErrorsUtil.handleVZCCAppStatusRequestErrors(request);
   		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
   	}

    @Test
   	public void handleCustomerNameByMtnRequestErrorsTest1() throws IOException, SOEHTTPException {
    	String sampleUIRequestString = "{\"data\":{\"postPaidInd\":\"Y\",\"processStep\":\"\",\"processAction\":null,\"intendType\":\"BYOD\"}}";
		InitiateValidateDeviceSimUIRequest request =  mapper.readValue(sampleUIRequestString, InitiateValidateDeviceSimUIRequest.class);
   		ErrorResponse errors = CartCxpRequestErrorsUtil.handleCustomerNameByMtnRequestErrors(request);
   		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
   	}

    @Test
   	public void handleCustomerNameByMtnRequestErrorsTest2() throws IOException, SOEHTTPException {
    	String sampleUIRequestString = "{\"data\":null}";
		InitiateValidateDeviceSimUIRequest request =  mapper.readValue(sampleUIRequestString, InitiateValidateDeviceSimUIRequest.class);
   		ErrorResponse errors = CartCxpRequestErrorsUtil.handleCustomerNameByMtnRequestErrors(request);
   		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
   	}

    @Test
   	public void handleGetCustomerInfoRequestErrorsTest() throws IOException, SOEHTTPException {
    	String requestString = "{ \"channelId\": \"VZW-DOTCOM-BBP\", \"imei\": null, \"imei2\": \"\", \"intent\": null, \"processStep\": \"\", \"processAction\": \"\", \"lineAction\": null }";
        CreateCaseAndGetCustomerInfoUIRequest request =  mapper.readValue(requestString, CreateCaseAndGetCustomerInfoUIRequest.class);
   		ErrorResponse errors = CartCxpRequestErrorsUtil.handleGetCustomerInfoRequestErrors(request);
   		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
   	}

    @Test
   	public void handleUpdateVzccNBXInfoRequestErrorsTest() throws IOException, SOEHTTPException {
    	String sampleRequest = "{\"cartId\":\"576aadfe-2c79-40f3-bcf8-7c7eb86fd97b\",\"vzccStatus\":null,\"isPreQualifiedNBX\":false,\"syfOfferId\":\"\",\"promotionalSPOCode\":\"SOBTRIGGER\",\"propositionMessage\":\"Thank you for your interest! Sign up and receive: $100 sign up bonus and more\",\"propositionName\":\"Pre-Qualified - Transaction Flow\",\"propositionId\":\"GC_02\",\"isVZCCHolder\":false,\"sessionId\":\"-2884516544863823367\",\"offerIdFromSYF\":\"N\"}\t";
    	UpdateVzccNBXInfoUIRequest request =  mapper.readValue(sampleRequest, UpdateVzccNBXInfoUIRequest.class);
   		ErrorResponse errors = CartCxpRequestErrorsUtil.handleUpdateVzccNBXInfoRequestErrors(request);
   		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
   	}

    @Test
   	public void handleTokenAndRequestEmptyErrorsTest() throws IOException, SOEHTTPException {
    	String sampleRequestString = "{\"channelId\":\"OMNI-INDIRECT\",\"cartInfo\": {\"cartCreator\": \"7039159592\",\"clientAppName\": \"VZW-MFA\",\"cartId\": \"4b207c97-6278-4562-9e41-b6411763bcd6\",\"caseId\": \"SOP-947715-E01\",\"processingMTN\": \"\",\"accountNumber\": \"0201430224-00001\",\"intent\": \"BYOD\",\"processStep\": \"BYODLandingPage\",\"processAction\": \"validatedevicesim\"},\"data\": {\"lines\": [{\"mtn\": \"\",\"device\": {\"id\": \"353338070105553\",\"Flowtype\": \"DEVICE\",\"CurrentId\": \"\",\"isCustomerProvidedEquipment\": true,\"sku\": \"\",\"smartIMEI\": true,\"searchAttributes\": {\"postpaidRestrictStartDate\": \"2018-07-01T04:00:00.000Z\",\"prodCode\": \"LTE\",\"hdVoiceInd\": true,\"deviceType\": \"4GE\",\"dacc\": \"00854\"},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": \"\"}}}]}}";
    	DeviceSimValidationUIRequest  request =  mapper.readValue(sampleRequestString, DeviceSimValidationUIRequest .class);
   		ErrorResponse errors = CartCxpRequestErrorsUtil.handleTokenAndRequestEmptyErrors(request,"eyteiukjvhfSfuknjbhdd");
   		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
   	}

    @Test
   	public void handleValidateTokenRequestErrorsTest() throws IOException, SOEHTTPException {
    	String requestString = "{\"token\":null,\"intent\":null}";
    	ValidateSecureTokenRequest  request =  mapper.readValue(requestString, ValidateSecureTokenRequest .class);
   		ErrorResponse errors = CartCxpRequestErrorsUtil.handleValidateTokenRequestErrors(request,"","","");
   		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
   	}

    @Test
   	public void handleESimValidationRequestErrorsTest() throws IOException, SOEHTTPException {
    	String sampleRequestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"esimType\":\"Ipad\",\"handOffToken\":\"\",\"imei\":\"\",\"eid\":\"\"}";
        IntiateESimActivationUIRequest request =  mapper.readValue(sampleRequestString, IntiateESimActivationUIRequest.class);
   		ErrorResponse errors = CartCxpRequestErrorsUtil.handleESimValidationRequestErrors(request);
   		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
   	}

    @Test
   	public void handleESimValidationRequestErrorsTest1() throws IOException, SOEHTTPException {
    	String sampleRequestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"esimType\":\"Ipad\",\"handOffToken\":\"\",\"imei\":\"\",\"eid\":\"346745697608\"}";
        IntiateESimActivationUIRequest request =  mapper.readValue(sampleRequestString, IntiateESimActivationUIRequest.class);
   		ErrorResponse errors = CartCxpRequestErrorsUtil.handleESimValidationRequestErrors(request);
   		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
   	}

    @Test
   	public void handleESimValidationRequestErrorsTest2() throws IOException, SOEHTTPException {
    	String sampleRequestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"esimType\":\"Ipad\",\"handOffToken\":\"eru4hgj7it\",\"imei\":\"\",\"eid\":\"2353445879860\"}";
        IntiateESimActivationUIRequest request =  mapper.readValue(sampleRequestString, IntiateESimActivationUIRequest.class);
   		ErrorResponse errors = CartCxpRequestErrorsUtil.handleESimValidationRequestErrors(request);
   		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
   	}

    @Test
   	public void handleDeviceSimValidationRequestErrorsTest() throws IOException, SOEHTTPException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"imei\":\"352898071710272\",\"imei2\":\"\",\"iccid\":\"89148000003136518763\",\"mdn\":\"\",\"devid\":\"\",\"eid\":\"\",\"skipUserAgent\":true,\"isSmartphone\":true,\"podidentifier\":\"\",\"handofftoken\":\"\",\"billingId\":\"I\"}";
    	DeviceSimValidationUIRequest request =  mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
   		ErrorResponse errors = CartCxpRequestErrorsUtil.handleDeviceSimValidationRequestErrors(request);
   		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
   	}

    @Test
   	public void handleDeviceSimValidationRequestErrorsTest1() throws IOException, SOEHTTPException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"imei\":\"352898071710272\",\"imei2\":\"352898071710273\",\"iccid\":null,\"mdn\":\"\",\"devid\":\"\",\"eid\":\"\",\"skipUserAgent\":true,\"isSmartphone\":true,\"podidentifier\":\"\",\"handofftoken\":\"\",\"billingId\":null}";
    	DeviceSimValidationUIRequest request =  mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
   		ErrorResponse errors = CartCxpRequestErrorsUtil.handleDeviceSimValidationRequestErrors(request);
   		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
   	}

    @Test
   	public void handleDeviceSimValidationRequestErrorsTest2() throws IOException, SOEHTTPException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"DEVICE4GSELF\",\"imei\":\"352898071710272\",\"imei2\":\"352898071710273\",\"devid\":\"dev687054\",\"iccid\":null,\"mdn\":\"\",\"eid\":\"\",\"skipUserAgent\":true,\"isSmartphone\":true,\"podidentifier\":\"\",\"handofftoken\":\"\",\"billingId\":null}";
    	DeviceSimValidationUIRequest request =  mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
   		ErrorResponse errors = CartCxpRequestErrorsUtil.handleDeviceSimValidationRequestErrors(request);
   		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
   	}

    @Test
   	public void handleDeviceSimValidationRequestErrorsTest3() throws IOException, SOEHTTPException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"MANAGEACCOUNT\",\"imei\":\"352898071710272\",\"imei2\":\"352898071710273\",\"devid\":\"dev687054\",\"iccid\":null,\"mdn\":\"\",\"eid\":\"\",\"skipUserAgent\":true,\"isSmartphone\":true,\"podidentifier\":\"\",\"handofftoken\":\"\",\"billingId\":null}";
    	DeviceSimValidationUIRequest request =  mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
   		ErrorResponse errors = CartCxpRequestErrorsUtil.handleDeviceSimValidationRequestErrors(request);
   		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
   	}

    @Test
   	public void handleDeviceSimValidationRequestErrorsTest4() throws IOException, SOEHTTPException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"MANAGEACCOUNT\",\"imei\":\"352898071710272\",\"imei2\":\"\",\"iccid\":\"89148000003136518763\",\"mdn\":\"\",\"devid\":\"dev687054\",\"eid\":\"489865343\",\"skipUserAgent\":true,\"isSmartphone\":true,\"podidentifier\":\"\",\"handofftoken\":\"\",\"billingId\":\"I\"}";
    	DeviceSimValidationUIRequest request =  mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
   		ErrorResponse errors = CartCxpRequestErrorsUtil.handleDeviceSimValidationRequestErrors(request);
   		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
   	}

    @Test
   	public void handleDeviceSimValidationRequestErrorsTest5() throws IOException, SOEHTTPException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"MANAGEACCOUNT\",\"imei\":\"352898071710272\",\"token\":\"\",\"imei2\":\"\",\"iccid\":\"89148000003136518763\",\"mdn\":\"\",\"devid\":\"dev687054\",\"eid\":\"489865343\",\"skipUserAgent\":true,\"isSmartphone\":true,\"podidentifier\":\"\",\"handofftoken\":\"\",\"billingId\":\"\"}";
    	DeviceSimValidationUIRequest request =  mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
   		ErrorResponse errors = CartCxpRequestErrorsUtil.handleDeviceSimValidationRequestErrors(request);
   		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
   	}

    @Test
   	public void handleDeviceSimValidationRequestErrorsTest6() throws IOException, SOEHTTPException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"ACCOUNT\",\"imei\":\"352898071710272\",\"token\":\"\",\"imei2\":\"\",\"iccid\":\"\",\"mdn\":\"\",\"devid\":\"dev687054\",\"eid\":\"489865343\",\"skipUserAgent\":true,\"isSmartphone\":true,\"podidentifier\":\"\",\"handofftoken\":\"\",\"billingId\":\"\"}";
    	DeviceSimValidationUIRequest request =  mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
   		ErrorResponse errors = CartCxpRequestErrorsUtil.handleDeviceSimValidationRequestErrors(request);
   		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
   	}

    @Test
   	public void handleDeviceSimValidationRequestErrorsTest7() throws IOException, SOEHTTPException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"ACCOUNT\",\"imei\":\"\",\"token\":\"\",\"imei2\":\"\",\"iccid\":\"\",\"mdn\":\"\",\"devid\":\"dev687054\",\"eid\":\"489865343\",\"skipUserAgent\":true,\"isSmartphone\":true,\"podidentifier\":\"\",\"handofftoken\":\"\",\"billingId\":\"\"}";
    	DeviceSimValidationUIRequest request =  mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
   		ErrorResponse errors = CartCxpRequestErrorsUtil.handleDeviceSimValidationRequestErrors(request);
   		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
   	}


    @Test
   	public void handleDeviceSimValidationRequestErrorsTest8() throws IOException, SOEHTTPException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"ACCOUNT\",\"imei\":\"\",\"token\":\"\",\"imei2\":\"\",\"iccid\":\"\",\"mdn\":\"\",\"devid\":\"\",\"eid\":\"489865343\",\"skipUserAgent\":true,\"isSmartphone\":true,\"podidentifier\":\"\",\"handofftoken\":\"\",\"billingId\":\"\"}";
    	DeviceSimValidationUIRequest request =  mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
   		ErrorResponse errors = CartCxpRequestErrorsUtil.handleDeviceSimValidationRequestErrors(request);
   		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
   	}

    @Test
   	public void handleDeviceSimValidationRequestErrorsTest9() throws IOException, SOEHTTPException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"ACCOUNT\",\"imei\":\"\",\"token\":\"\",\"imei2\":\"\",\"iccid\":\"\",\"mdn\":\"\",\"devid\":\"\",\"eid\":\"\",\"skipUserAgent\":true,\"isSmartphone\":true,\"podidentifier\":\"\",\"handofftoken\":\"\",\"billingId\":\"\"}";
    	DeviceSimValidationUIRequest request =  mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
   		ErrorResponse errors = CartCxpRequestErrorsUtil.handleDeviceSimValidationRequestErrors(request);
   		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
   	}

    @Test
   	public void handleDeviceSimValidationRequestErrorsTest10() throws IOException, SOEHTTPException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"ACCOUNT\",\"imei\":\"\",\"token\":\"eytrhnfsi8yteg\",\"imei2\":\"\",\"iccid\":\"\",\"mdn\":\"\",\"devid\":\"\",\"eid\":\"\",\"skipUserAgent\":true,\"isSmartphone\":true,\"podidentifier\":\"\",\"handofftoken\":\"\",\"billingId\":\"\"}";
    	DeviceSimValidationUIRequest request =  mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
   		ErrorResponse errors = CartCxpRequestErrorsUtil.handleDeviceSimValidationRequestErrors(request);
   		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
   	}

    @Test
   	public void handleDeviceSimValidationRequestErrorsTest11() throws IOException, SOEHTTPException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"ACCOUNT\",\"imei\":\"352898071710272\",\"token\":\"eytrhnfsi8yteg\",\"imei2\":\"352898071710273\",\"iccid\":\"67876434278\",\"mdn\":\"\",\"devid\":\"\",\"eid\":\"\",\"skipUserAgent\":true,\"isSmartphone\":true,\"podidentifier\":\"\",\"handofftoken\":\"\",\"billingId\":\"\"}";
    	DeviceSimValidationUIRequest request =  mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
   		ErrorResponse errors = CartCxpRequestErrorsUtil.handleDeviceSimValidationRequestErrors(request);
   		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
   	}

    @Test
   	public void handleDeviceSimValidationRequestErrorsTest12() throws IOException, SOEHTTPException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"techType\":\"ACCOUNT\",\"imei\":\"352898071710272\",\"token\":\"eytrhnfsi8yteg\",\"imei2\":\"352898071710273\",\"iccid\":\"67876434278\",\"mdn\":\"\",\"devid\":\"\",\"eid\":\"\",\"skipUserAgent\":true,\"isSmartphone\":true,\"podidentifier\":\"\",\"handofftoken\":\"\",\"billingId\":\"I\"}";
    	DeviceSimValidationUIRequest request =  mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
   		ErrorResponse errors = CartCxpRequestErrorsUtil.handleDeviceSimValidationRequestErrors(request);
   		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
}
