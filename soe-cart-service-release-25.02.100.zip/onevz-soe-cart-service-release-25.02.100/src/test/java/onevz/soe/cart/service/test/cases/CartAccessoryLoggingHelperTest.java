package onevz.soe.cart.service.test.cases;

import java.io.IOException;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fasterxml.jackson.databind.ObjectMapper;

import onevz.soe.cart.helper.AccessoryFinancingOffersHelper;
import onevz.soe.cart.helper.CartAccessoryLoggingHelper;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.requests.AddAccessoriesUIRequest;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = {CartServiceTestConfig.class})
@WebFluxTest(AccessoryFinancingOffersHelper.class)
public class CartAccessoryLoggingHelperTest {
	
	@Autowired
	CartAccessoryLoggingHelper helper;
		
	@Autowired
	ObjectMapper mapper;
	
	@Test	
	public void logAccessoryInkibanaHelperTest() {
		try {
			String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"depletionType\":\"\",\"lines\":[{\"mtn\":\"8165504349\",\"addAccessories\":[{\"id\": \"3212345\",\"sorId\":\"\",\"qty\":\"\",\"price\":\"\"}],\"removeAccessories\": [{\"id\":\"321234567\"}],\"mdnFilterValue\":\"3014674968\",\"ispuFlow\":false}],\"isSoftSku\":false}}";
			AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
			Mono<Object> response = helper.logAccessoryInkibana(UIRequest);
			Assert.assertNotNull(response);
			//StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

	@Test
	public void logAccessoryInkibanaHelperTest1() {
		try {
			String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"depletionType\":\"\",\"lines\":[{\"mtn\":null,\"addAccessories\":[{\"id\":null,\"sorId\":\"\",\"qty\":\"\",\"price\":\"\"}],\"removeAccessories\": [{\"id\":null}],\"mdnFilterValue\":\"3014674968\",\"ispuFlow\":false}],\"isSoftSku\":false}}";
			AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
			Mono<Object> response = helper.logAccessoryInkibana(UIRequest);
			Assert.assertNotNull(response);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	@Test
	public void logAccessoryInkibanaHelperTest2() {
		try {
			String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"depletionType\":\"\",\"lines\":[{\"mtn\":null,\"addAccessories\":[],\"removeAccessories\": [],\"mdnFilterValue\":\"3014674968\",\"ispuFlow\":false}],\"isSoftSku\":false}}";
			AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
			Mono<Object> response = helper.logAccessoryInkibana(UIRequest);
			Assert.assertNotNull(response);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	@Test
	public void logAccessoryInkibanaHelperTest3() {
		try {
			String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"depletionType\":\"\",\"lines\":[{\"mtn\":null,\"addAccessories\":null,\"removeAccessories\":null,\"mdnFilterValue\":\"3014674968\",\"ispuFlow\":false}],\"isSoftSku\":false}}";
			AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
			Mono<Object> response = helper.logAccessoryInkibana(UIRequest);
			Assert.assertNotNull(response);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	@Test
	public void logAccessoryInkibanaHelperTest4() {
		try {
			String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"depletionType\":\"\",\"lines\":[],\"isSoftSku\":false}}";
			AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
			Mono<Object> response = helper.logAccessoryInkibana(UIRequest);
			Assert.assertNotNull(response);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	@Test
	public void logAccessoryInkibanaHelperTest5() {
		try {
			String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":null,\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"depletionType\":\"\",\"lines\":[],\"isSoftSku\":false}}";
			AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
			Mono<Object> response = helper.logAccessoryInkibana(UIRequest);
			Assert.assertNotNull(response);
		}catch(Exception e){
			e.printStackTrace();
		}
	}


}
