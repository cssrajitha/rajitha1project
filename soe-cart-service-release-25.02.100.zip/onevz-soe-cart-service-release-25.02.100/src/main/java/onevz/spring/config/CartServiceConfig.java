package onevz.spring.config;

import onevz.soe.datastore.annotations.EnableDatastoreClients;
import onevz.soe.security.util.RPSAES128CBCUtil;
import onevz.soe.wsclient.annotations.WsclientServiceProxy;
import onevz.soe.wsclient.bpm.BPMServices;
import onevz.wsclient.cxp.CXPServices;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.data.elasticsearch.ElasticsearchDataAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * CartService Config class.
 */
@Configuration
@EnableDatastoreClients(value = {"onevz.soe.security", "onevz.soe.session","onevz.soe.cart.datastore.client","onevz.aem.errorhandling", "onevz.soe.core.exception.datastore.client","onevz.soe.tradein.session.client"})
@WsclientServiceProxy(basePackages = { "onevz.soe.cart.bpm.service", "onevz.soe.cart.cxp.service" }, serviceMarker = {
		BPMServices.class, CXPServices.class }, proxyPerInterface = true, targetClass = "abstractBPMTarget")
@EnableAutoConfiguration(exclude={ElasticsearchDataAutoConfiguration.class})
public class CartServiceConfig {
	// Any configs required will go here


	@Bean
	public RPSAES128CBCUtil security5GUtil(@Value("${soe.5g.am.securityKey:fdVgU2SR3iEyDlrmm4K8Wg==}") String key,
										 @Value("${soe.5g.am.iterationCount:10000}") Integer am5GIterationCount,@Value("${soe.cart.aes.provider:AES/CBC/PKCS5Padding}") String provider) {
		return new RPSAES128CBCUtil(key, am5GIterationCount,provider);
	}
	
	private static final Logger logger = LoggerFactory.getLogger(CartServiceConfig.class);

}
