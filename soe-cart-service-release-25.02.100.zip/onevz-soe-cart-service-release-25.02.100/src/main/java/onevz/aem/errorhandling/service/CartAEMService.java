package onevz.aem.errorhandling.service;

import onevz.aem.request.ProspectDeviceModelMappingRequest;
import onevz.aem.response.ProspectDeviceModelMapResponse;
import onevz.soe.wsclient.aem.AEMServices;
import onevz.soe.wsclient.aem.annotations.AEM;
import onevz.soe.wsclient.http.MessageLog;
import onevz.soe.constants.HttpMethod;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

/**
 * The interface Cart aem service.
 */
@Service
@Primary
public interface CartAEMService extends AEMServices {

    /**
     * Gets prospect device model mapping sku data.
     *
     * @param request the ProspectDeviceModelMappingRequest
     * @return the device sku data
     */
    @AEM (aemRequestService = ProspectDeviceModelMappingRequest.class, aemResponseService = ProspectDeviceModelMapResponse.class, urlPostFix = "/vcg/services-v1/deviceskumodelmapping.model.json", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.GET)
    Mono<ProspectDeviceModelMapResponse> getSKUDetail(ProspectDeviceModelMappingRequest request) ;

}

