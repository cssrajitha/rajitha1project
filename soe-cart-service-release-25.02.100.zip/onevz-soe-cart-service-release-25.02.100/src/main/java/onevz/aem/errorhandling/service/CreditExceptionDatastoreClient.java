package onevz.aem.errorhandling.service;

import java.time.temporal.ChronoUnit;

import onevz.aem.errorhandling.aem.model.CreditErrorContent;
import onevz.soe.datastore.annotations.DatastoreTTL;
import onevz.soe.datastore.annotations.types.SupportedType;
import onevz.soe.datastore.core.SubKey;
import onevz.soe.datastore.redis.RedisDataType;
import onevz.soe.datastore.redis.RedisDatastoreType;
import onevz.soe.datastore.type.DatastoreClient;
import reactor.core.publisher.Mono;

@DatastoreTTL(ttl = 30, timeUnit = ChronoUnit.DAYS, supportedType = SupportedType.UPSERT)
@RedisDatastoreType(RedisDataType.HashValue)
public interface CreditExceptionDatastoreClient extends DatastoreClient {

	/**
	 * 
	 * @param topKey
	 * @param subKey
	 * @return creditErrorContent
	 */
    public Mono<CreditErrorContent> readCreditException(String topKey, @SubKey String subKey);
}

