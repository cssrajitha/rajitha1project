package onevz.onevzsoe.peripherals.cassandra;

import onevz.soe.datastore.annotations.DatastoreTTL;
import onevz.soe.datastore.core.SubKey;
import onevz.soe.datastore.redis.RedisDataType;
import onevz.soe.datastore.redis.RedisDatastoreType;
import onevz.soe.datastore.type.DatastoreClient;
import reactor.core.publisher.Mono;

import java.time.temporal.ChronoUnit;

@DatastoreTTL(ttl = 30, timeUnit = ChronoUnit.MINUTES)
@RedisDatastoreType(RedisDataType.HashValue)
public interface PlanbuilderDatastoreClient extends DatastoreClient {

    public Mono<String> readPlanBuilderData( String guid,@SubKey String collaborationQrCode) ;
}