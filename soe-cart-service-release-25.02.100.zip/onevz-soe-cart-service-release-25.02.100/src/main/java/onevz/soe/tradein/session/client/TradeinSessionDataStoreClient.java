package onevz.soe.tradein.session.client;



import onevz.soe.datastore.annotations.DatastoreDataValue;
import onevz.soe.datastore.annotations.DatastoreTTL;
import onevz.soe.datastore.core.SubKey;

import onevz.soe.datastore.redis.RedisDataType;
import onevz.soe.datastore.redis.RedisDatastoreType;
import onevz.soe.datastore.type.DatastoreClient;
import onevz.soe.tradein.session.model.TradeinSessionData;
import reactor.core.publisher.Mono;

import java.time.temporal.ChronoUnit;

@DatastoreTTL(ttl = 50, timeUnit = ChronoUnit.MINUTES)
@RedisDatastoreType(RedisDataType.HashValue)
public interface TradeinSessionDataStoreClient extends DatastoreClient {
    /**
     * Method for upsertTradeinSessionData.
     *
     * @param hashKey the hash key
     * @param field   the field
     * @param data    the data
     * @return mono mono
     */
    Mono<Boolean> upsertTradeinSessionData(String hashKey, @SubKey String field, @DatastoreDataValue TradeinSessionData data);

    /**
     * Method to read trade in session data.
     *
     * @param sessionId the cartId
     * @param field     the field
     * @return mono mono
     */
    Mono<TradeinSessionData> readTradeinSessionData(String sessionId, @SubKey String field);
}
