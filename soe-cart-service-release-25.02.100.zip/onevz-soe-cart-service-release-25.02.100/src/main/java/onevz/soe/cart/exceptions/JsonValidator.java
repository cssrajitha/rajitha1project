package onevz.soe.cart.exceptions;


import onevz.soe.cart.constants.CartConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.json.JsonSanitizer;

import onevz.soe.cart.controller.advice.CartServiceExceptionHandler;
import onevz.soe.cart.responses.AddZipcodeRedisData;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.ui.requests.RPSApplePayloadUIRequest;

@Service
public class JsonValidator {

	private static final Logger logger = LoggerFactory.getLogger(CartServiceExceptionHandler.class);
	
	@Autowired
	private ObjectMapper mapper;
	
	/**
	 * 
	 * @param resp
	 * @return string
	 */
	public String convertObjectToString(Object resp){
		String sanitizedData = null;
		try {
			if(resp!=null)
				sanitizedData = JsonSanitizer.sanitize(mapper.writeValueAsString(resp));
		} catch (JsonProcessingException e) {
			logger.info(CartConstants.RESPONSE_TO_STRING_CONVERSION_EXCEPTION);
			logger.error(CartConstants.RESPONSE_TO_STRING_CONVERSION_EXCEPTION + " {}", e);
		}
		return sanitizedData;
	}
	
	/**
	 * 
	 * @param resp
	 * @return string
	 */
	public ErrorResponse convertObjectToString(ErrorResponse resp){
		String sanitizedData = null;
		ErrorResponse errorResponse = null;
		try {
			if(resp!=null)
				sanitizedData = JsonSanitizer.sanitize(mapper.writeValueAsString(resp));
			errorResponse = mapper.readValue(sanitizedData, ErrorResponse.class);
		} catch (JsonProcessingException e) {
			logger.info(CartConstants.RESPONSE_TO_STRING_CONVERSION_EXCEPTION);
			logger.error(CartConstants.RESPONSE_TO_STRING_CONVERSION_EXCEPTION + " {}", e);
		}
		return errorResponse;
	}
	
	/**
	 * 
	 * @param resp
	 * @return string
	 */
	public AddZipcodeRedisData convertObjectToString(AddZipcodeRedisData resp){
		String sanitizedData = null;
		AddZipcodeRedisData errorResponse = null;
		try {
			if(resp!=null)
				sanitizedData = JsonSanitizer.sanitize(mapper.writeValueAsString(resp));
			errorResponse = mapper.readValue(sanitizedData, AddZipcodeRedisData.class);
		} catch (JsonProcessingException e) {
			logger.info(CartConstants.RESPONSE_TO_STRING_CONVERSION_EXCEPTION);
			logger.error(CartConstants.RESPONSE_TO_STRING_CONVERSION_EXCEPTION + " {}", e);
		}
		return errorResponse;
	}

	/**
	 *
	 * @param jsonString
	 * @return RPSApplePayloadUIRequest
	 */
	public RPSApplePayloadUIRequest convertRPSStringToObject(String jsonString)
	{
		Gson gson = new Gson();
		RPSApplePayloadUIRequest  rpsApplePayloadUIRequest= gson.fromJson(jsonString , RPSApplePayloadUIRequest.class);
		return rpsApplePayloadUIRequest;
	}
	/**
	 *
	 * @param resp
	 * @return string
	 */
	public RPSApplePayloadUIRequest sanitizeRPSApplePayloadUIRequest(RPSApplePayloadUIRequest resp){
		String sanitizedData = null;
		RPSApplePayloadUIRequest sanitizedResponse = null;
		try {
			if(resp!=null)
				sanitizedData = JsonSanitizer.sanitize(mapper.writeValueAsString(resp));
			sanitizedResponse = mapper.readValue(sanitizedData, RPSApplePayloadUIRequest.class);
		} catch (JsonProcessingException e) {
			logger.info(CartConstants.RESPONSE_TO_STRING_CONVERSION_EXCEPTION);
			logger.error(CartConstants.RESPONSE_TO_STRING_CONVERSION_EXCEPTION + " {}", e);
		}
		return sanitizedResponse;
	}
}
