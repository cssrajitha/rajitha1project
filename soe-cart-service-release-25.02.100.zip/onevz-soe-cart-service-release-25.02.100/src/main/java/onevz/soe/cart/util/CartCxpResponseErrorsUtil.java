package onevz.soe.cart.util;

import java.util.ArrayList;
import java.util.List;

import onevz.soe.cart.model.initiateValidateDeviceSim.InitiateValidateDeviceSimUIResponse;
import onevz.soe.cart.ui.responses.*;
import org.apache.commons.lang3.StringUtils;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.initiateDeviceSimActivation.InitiateDeviceSimActivationUIResponse;
import onevz.soe.cart.model.initiateESimActivation.InitiateESimActivationUIResponse;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.ui.requests.DeviceSimValidationUIRequest;
import onevz.soe.utilities.StringUtilities;

// TODO: Auto-generated Javadoc
/**
 * SOE Response Error Handler class.
 */
public class CartCxpResponseErrorsUtil {

	/**
	 * Instantiates a new cart cxp response errors util.
	 */
	private CartCxpResponseErrorsUtil() {

	}

	/**
	 * Handle retrieve cart response errors.
	 *
	 * @param response the response
	 * @return the error response
	 */
	public static ErrorResponse handleRetrieveCartResponseErrors(RetrieveCartUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();
			for (CartError cxpError : response.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * Handle validate cart response errors.
	 *
	 * @param response the response
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleValidateCartResponseErrors(ValidateCartUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			for (CartError cxpError : response.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * Handle update user info response errors.
	 *
	 * @param response the response
	 * @return the error response
	 */
	public static ErrorResponse handleUpdateUserInfoResponseErrors(UpdateUserInfoUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			for (CartError cxpError : response.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * Handle paperless billing response errors.
	 *
	 * @param response the response
	 * @return ErrorResponse
	 */
	public static ErrorResponse handlePaperlessBillingResponseErrors(PaperlessBillingUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			for (CartError cxpError : response.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * Handle update tradein type response errors.
	 *
	 * @param response the response
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleUpdateTradeinTypeResponseErrors(UpdateTradeinTypeUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			for (CartError cxpError : response.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * Handle update seller price response errors.
	 *
	 * @param response the response
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleUpdateSellerPriceResponseErrors(UpdateSellerPriceUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			for (CartError cxpError : response.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * Handle mac address response errors.
	 *
	 * @param response the response
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleMacAddressResponseErrors(MacAddressUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			for (CartError cxpError : response.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * Handle validate ISPU order order response errors.
	 *
	 * @param response the response
	 * @return the error response
	 */
	public static ErrorResponse handleValidateISPUOrderOrderResponseErrors(ValidateISPUOrderUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			for (CartError cxpError : response.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * Handle get depletion type response errors.
	 *
	 * @param response the response
	 * @return the error response
	 */
	public static ErrorResponse handleGetDepletionTypeResponseErrors(GetDepletionTypeUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			for (CartError cxpError : response.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * Handle gift purchase response errors.
	 *
	 * @param response the response
	 * @return errors
	 */
	public static ErrorResponse handleGiftPurchaseResponseErrors(GiftPurchaseUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			for (CartError cxpError : response.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * Handle check dfill inventory response errors.
	 *
	 * @param response the response
	 * @return errors
	 */
	public static ErrorResponse handleCheckDfillInventoryResponseErrors(CheckDfillInventoryUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			for (CartError cxpError : response.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * Handle get vendor id response errors.
	 *
	 * @param response the response
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleGetVendorIdResponseErrors(GetVendorIdUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null && !response.getErrors().isEmpty()) {
			errors = new ErrorResponse();

			errorList = response.getErrors();
		}
		if (errorList != null)
			errors.setErrors(errorList);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * Handle upgrade reason codes response errors.
	 *
	 * @param response the response
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleUpgradeReasonCodesResponseErrors(GetUpgradeReasonCodeUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			for (CartError cxpError : response.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * Handle update port in later response errors.
	 *
	 * @param response the response
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleUpdatePortInLaterResponseErrors(PortinLaterUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null && !response.getErrors().isEmpty()) {
			errors = new ErrorResponse();

			errorList = response.getErrors();
		}
		if (errorList != null)
			errors.setErrors(errorList);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * Handle ispu to dfill response errors.
	 *
	 * @param response the response
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleIspuToDfillResponseErrors(IspuToDfillUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			for (CartError cxpError : response.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * Handle retrieve URC for cart response errors.
	 *
	 * @param response the response
	 * @return errors
	 */
	public static ErrorResponse handleRetrieveURCForCartResponseErrors(RetrieveURCForCartUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();
			for (CartError cxpError : response.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * Handle calculate multiline tax response errors.
	 *
	 * @param response the response
	 * @return errors
	 */
	public static ErrorResponse handleCalculateMultilineTaxResponseErrors(CalculateMultilineTaxUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();
			for (CartError cxpError : response.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * Handling Exceptions.
	 *
	 * @param message the message
	 * @return the smart imei type ahead search response
	 */
	public static SmartImeiTypeAheadSearchResponse handleGenericException(String message) {
		SmartImeiTypeAheadSearchResponse errors = new SmartImeiTypeAheadSearchResponse();
		List<CartError> errorList = new ArrayList<>();
		if (StringUtilities.isNotEmptyOrNull(message)) {
			errors = new SmartImeiTypeAheadSearchResponse();
			CartError error = new CartError();
			error.setErrorMessage(message);
			errorList.add(error);
			errors.setErrors(errorList);
		}
		return errors;
	}

	/**
	 * Handle validate BYOD tool errors.
	 *
	 * @param response the response
	 * @return errors
	 */
	public static ErrorResponse handleValidateBYODToolErrors(ValidateBYODToolUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();
			for (CartError cxpError : response.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * Handle E sim details response errors.
	 *
	 * @param response the response
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleESimDetailsResponseErrors(ESimDetailsUIResponse response, String e2eRequestId) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			CartError error = new CartError();
			error.setErrorCode(String.valueOf(response.getErrors().getErrorCode()));
			error.setMessage(-1 != response.getStatusMessage().indexOf("PERS") ? StringUtils.normalizeSpace( response.getStatusMessage().replace("PERS", "Cannot get sim information") ) : StringUtils.normalizeSpace(response.getStatusMessage() ));
			error.setName(response.getErrors().getErrorMsg());
			error.setNamespace("ETNI");
			if(StringUtilities.isNotEmptyOrNull(e2eRequestId))
				error.setDebug_id(e2eRequestId);
			errorList.add(error);

			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * Handle email cart to customer response errors.
	 *
	 * @param response the response
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleEmailCartToCustomerResponseErrors(EmailCartToCustomerUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null && !response.getErrors().isEmpty()) {
			errors = new ErrorResponse();

			errorList = response.getErrors();
		}
		if (errorList != null)
			errors.setErrors(errorList);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * Handle customer by mtn list response errors.
	 *
	 * @param response the response
	 * @return errors
	 */
	public static ErrorResponse handleCustomerByMtnListResponseErrors(CustomerByMtnListUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();
			for (CartError cxpError : response.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * Handle VZCC app status response errors.
	 *
	 * @param response the response
	 * @return errors
	 */
	public static ErrorResponse handleVZCCAppStatusResponseErrors(VZCCAppStatusUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();
			for (CartError cxpError : response.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * Handle update trade in offer response errors.
	 *
	 * @param response the response
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleUpdateTradeInOfferResponseErrors(UpdateTradeInOfferUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null) {
			errors = new ErrorResponse();
			errorList = response.getErrors();
		}
		if (errorList != null)
			errors.setErrors(errorList);
		return errors == null ? new ErrorResponse() : errors;
	}

    //VZWCS-17115 change
	public static ErrorResponse handleInitiateCbandCheckResponseErrors(InitiateCbandCheckUIResponse response) {

        ErrorResponse errors = null;
        List<CartError> errorList = null;
        if (response.getErrors() != null) {
            errors = new ErrorResponse();
            errorList = response.getErrors();
        }
        if (errorList != null)
            errors.setErrors(errorList);
        return errors == null ? new ErrorResponse() : errors;
    }

	/**
	 * Handle device sim validation response errors.
	 *
	 * @param response the response
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleDeviceSimValidationResponseErrors(DeviceSimValidationUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null) {
			errors = new ErrorResponse();
			errorList = response.getErrors();
		}
		if (errorList != null)
			errors.setErrors(errorList);
		return errors == null ? new ErrorResponse() : errors;
	}
	
	/**
	 * Handle validate secure token response errors.
	 *
	 * @param response the response
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleValidateSecureTokenResponseErrors(DeviceSimValidationUIRequest response) {

		ErrorResponse errors = null;
		CartError error = new CartError();
		List<CartError> errorList = null;
		
		if (response.getResponse() != null) {
			errorList = new ArrayList<CartError>();
			error.setNamespace(CartConstants.SOE_CART_SERVICE);
			error.setId(CartConstants.MSNG_FLDS_ERR_CODE);
			error.setName(response.getResponse()+" from IG Service/Invalid Token");
			errors = new ErrorResponse();
			errorList.add(error);
			errors.setErrors(errorList);
		}
		
		return errors == null ? new ErrorResponse() : errors;
	}

    /**
     * Handle customer by mtn response errors.
     *
     * @param response the response
     * @return errors
     */
    public static ErrorResponse handleCustomerByMtnResponseErrors(CustomerByMtnUIResponse response) {

        ErrorResponse errors = null;
        List<CartError> errorList = new ArrayList<>();
        if (response.getErrors() != null) {
            errors = new ErrorResponse();
            for (CartError cxpError : response.getErrors()) {
                CartError error = cxpError;
                errorList.add(error);
            }
            errors.setErrors(errorList);
        }
        return errors == null ? new ErrorResponse() : errors;
    }

	/**
	 * Handle update vzcc NBX info response errors.
	 *
	 * @param response the response
	 * @return errors
	 */
	public static ErrorResponse handleUpdateVzccNBXInfoResponseErrors(UpdateVzccNBXInfoUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();
			for (CartError cxpError : response.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * Handle get customer info response errors.
	 *
	 * @param response the response
	 * @return errors
	 */
	public static ErrorResponse handleGetCustomerInfoResponseErrors(CreateCaseAndGetCustomerInfoUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();
			for (CartError cxpError : response.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}
	
	/**
	 * Handle initiate device sim activation errors.
	 *
	 * @param response the response
	 * @return the error response
	 */
	public static ErrorResponse handleInitiateDeviceSimActivationErrors(InitiateDeviceSimActivationUIResponse response) {
		ErrorResponse errors = null;
        List<CartError> errorList = new ArrayList<>();
        if (response.getErrors() != null) {
            errors = new ErrorResponse();
            for (CartError cxpError : response.getErrors()) {
                CartError error = cxpError;
                errorList.add(error);
            }
            errors.setErrors(errorList);
        }
        return errors == null ? new ErrorResponse() : errors;
    }
	
	public static ErrorResponse handleInitiateESimActivationErrors(InitiateESimActivationUIResponse response) {
		ErrorResponse errors = null;
        List<CartError> errorList = new ArrayList<>();
        if (response.getErrors() != null) {
            errors = new ErrorResponse();
            for (CartError cxpError : response.getErrors()) {
                CartError error = cxpError;
                errorList.add(error);
            }
            errors.setErrors(errorList);
        }
        return errors == null ? new ErrorResponse() : errors;
    }
	
	/**
     * Handle customer by mtn for Parent Lines response errors.
     *
     * @param response the response
     * @return errors
     */
    public static ErrorResponse handleCustomerByMtnForParentLinesResponseErrors(GetParentLinesUIResponse response) {

        ErrorResponse errors = null;
        List<CartError> errorList = new ArrayList<>();
        if (response.getErrors() != null) {
            errors = new ErrorResponse();
            for (CartError cxpError : response.getErrors()) {
                CartError error = cxpError;
                errorList.add(error);
            }
            errors.setErrors(errorList);
        }
        return errors == null ? new ErrorResponse() : errors;
    }

    public static ErrorResponse handleOrderConfirmationResponseErrors(OrderConfirmationUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();
			for (CartError cxpError : response.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	//VZWYN-20895 changes
	public static ErrorResponse handleCustomerNameByMtnResponseErrors(InitiateValidateDeviceSimUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null) {
			errors = new ErrorResponse();
			errorList = response.getErrors();
		}
		if (errorList != null)
			errors.setErrors(errorList);
		return errors == null ? new ErrorResponse() : errors;
	}

}