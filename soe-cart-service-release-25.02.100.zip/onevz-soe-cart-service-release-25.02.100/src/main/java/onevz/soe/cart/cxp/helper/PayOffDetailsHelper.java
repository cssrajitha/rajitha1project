package onevz.soe.cart.cxp.helper;

import onevz.soe.cart.bpm.service.CartServiceBPMServices;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.requests.AddPayOffDetailsPEGARequest;
import onevz.soe.cart.responses.AddPayOffDetailsPEGAResponse;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.AddPayOffDetailsUIRequest;
import onevz.soe.cart.ui.requests.PayOffDetailsRequest;
import onevz.soe.cart.ui.responses.AddPayOffDetailsUIResponse;
import onevz.soe.cart.ui.responses.PayOffDetailsContext;
import onevz.soe.cart.ui.responses.PayOffDetailsServiceBody;
import onevz.soe.cart.util.CartPegaRequestUtil;
import onevz.soe.cart.util.CartPegaResponseUtil;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.Arrays;
import java.util.stream.Collectors;


@Service
public class PayOffDetailsHelper {

    private static final Logger logger = LoggerFactory.getLogger(PayOffDetailsHelper.class);
    @Autowired
    private RedisHelper redisHelper;

    @Autowired
    private CartServiceBPMServices services;

    public Mono<AddPayOffDetailsUIResponse> getAddPayOffDetails(HttpHeaders headers, AddPayOffDetailsUIRequest request) {
        Mono<CartRedisData> rr = redisHelper.getDataFromRedis();
        String channelId = headers.containsKey(CartConstants.CHANNEL_ID) ? headers.getFirst(CartConstants.CHANNEL_ID) : "";

        return rr.flatMap(data-> {
            AddPayOffDetailsPEGARequest pegaRequest = prepareAddPayOffDetailsPEGARequest(request, data, channelId);
            logger.debug("AddPayOffDetails PEGA Request: {}", request);
            Mono<AddPayOffDetailsPEGAResponse> responseServiceMono = null;
            try {
                // pega call
                responseServiceMono = services.addPayOffDetails(pegaRequest);
            } catch (SOEHTTPException e) {
                logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
            }
            AddPayOffDetailsUIResponse soeResponse = new AddPayOffDetailsUIResponse();
            return responseServiceMono == null ? Mono.just(new AddPayOffDetailsUIResponse())
                    : responseServiceMono.flatMap(pegaResponse -> {
                // convert pega response to ui response
                CartPegaResponseUtil.formatAddPayOffDetailsUIResponse(soeResponse, pegaResponse);
                return Mono.just(soeResponse);
            });
        });
    }

    private AddPayOffDetailsPEGARequest prepareAddPayOffDetailsPEGARequest(AddPayOffDetailsUIRequest request, CartRedisData data, String channelId) {
        AddPayOffDetailsPEGARequest pegaRequest = new AddPayOffDetailsPEGARequest();

        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        serviceHeader = CartPegaRequestUtil.addServiceHeader(serviceHeader);

        serviceHeader.setClientId(channelId);
        pegaRequest.setServiceHeader(serviceHeader);

        PayOffDetailsServiceBody serviceBody = new PayOffDetailsServiceBody();
        PayOffDetailsRequest serviceRequest = new PayOffDetailsRequest();
        PayOffDetailsContext context = new PayOffDetailsContext();
        context.setCaseId(data.getCaseId());
        serviceBody.setServiceRequest(serviceRequest);
        CartServiceContextInfo contextInfo = getCartServiceContextInfo(request, data);
        context.setContextInfo(contextInfo);
        serviceRequest.setContext(context);

        CartServiceCustomerInfo customerInfo = getCartServiceCustomerInfo(request, data);
        context.setCustomerInfo(customerInfo);

        CartServiceCartInfo cartInfo = getCartServiceCartInfo(request, data);
        context.setCartInfo(cartInfo);

        pegaRequest.setServiceBody(serviceBody);

        return pegaRequest;
    }
    private CartServiceCartInfo getCartServiceCartInfo(AddPayOffDetailsUIRequest request, CartRedisData data) {
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setItemType(CartConstants.PAYOFF_DEVICE);
        cartInfo.setAction(CartConstants.ADD);
        cartInfo.setCartId(data.getCartId());
        cartInfo.setIntendType(StringUtilities.isNotEmptyOrNull(data.getIntendType()) ? data.getIntendType() : CartConstants.AAL);
        if(request.getData().getLines() != null) {
            Line [] lineArray = Arrays.stream(request.getData().getLines())
                    .map(lines1-> toLine(lines1))
                    .collect(Collectors.toList())
                    .toArray(Line[]::new);
            cartInfo.setLines(lineArray);
        }

        return cartInfo;
    }

    private Line toLine(Lines lines) {
        Line line = new Line();
        line.setMtn(lines.getMtn());
        line.setNewLineOrAAL(lines.getNewLineOrAAL());
        line.setPayOffDeviceInfo(lines.getPayOffDeviceInfo());
        return line;
    }
    private CartServiceCustomerInfo getCartServiceCustomerInfo(AddPayOffDetailsUIRequest request, CartRedisData data) {
        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        //customerInfo.setThrottleName();
        //customerInfo.setBucketAllocator();
        if(StringUtilities.isNotEmptyOrNull(data.getCustomerType()))
            customerInfo.setCustomerType(data.getCustomerType());
        //customerInfo.setNocByod();
        if(StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
            customerInfo.setAccountNumber(data.getAccountNumber());
        if(StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
            customerInfo.setCartCreator(data.getCartCreator());

        //customerInfo.setRegisterNumber();
        if(StringUtilities.isNotEmptyOrNull(data.getMtnFlow()))
            customerInfo.setMtnFlow(data.getMtnFlow());
        //customerInfo.setGlobalId();
        //customerInfo.setNoc();
        //customerInfo.setMyvPage();

        return customerInfo;
    }
    private CartServiceContextInfo getCartServiceContextInfo(AddPayOffDetailsUIRequest request, CartRedisData data) {
        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        //contextInfo.setSkipCheckoutCall();
        contextInfo.setCallReason(CartConstants.SALES_ORDER_PURCHASE);
        if(request.getCartInfo()!=null) {
            if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessStep()))
                contextInfo.setProcessStep(request.getCartInfo().getProcessStep());
            if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessAction()))
                contextInfo.setProcessAction(request.getCartInfo().getProcessAction());
            if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()))
                contextInfo.setIntent(request.getCartInfo().getIntendType());
        }
        contextInfo.setIntent(StringUtilities.isNotEmptyOrNull(data.getIntendType()) ? data.getIntendType() : CartConstants.AAL);

        return contextInfo;
    }
}
