package onevz.soe.cart.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import onevz.soe.cart.helper.ScanIdLookUpInfoHelper;
import onevz.soe.cart.requests.ScanIdLookUpInfoRequest;
import onevz.soe.cart.responses.ScanIdLookUpInfoResponse;
import reactor.core.publisher.Mono;

@RestController
public class ScanIdLookUpInfoController {
	@Autowired
	ScanIdLookUpInfoHelper scanIdLookUpInfoHelper;

	private static final Logger logger = LoggerFactory.getLogger(ScanIdLookUpInfoController.class);

	@PostMapping(value = "/scanid-lookup-info", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Mono<ScanIdLookUpInfoResponse> scanIdLookUpInfo(@RequestBody ScanIdLookUpInfoRequest request) {
		logger.info("scanIdLookUpInfo started with the request :: {} ", request);

		return scanIdLookUpInfoHelper.scanIdLookUp(request);
	}

}
