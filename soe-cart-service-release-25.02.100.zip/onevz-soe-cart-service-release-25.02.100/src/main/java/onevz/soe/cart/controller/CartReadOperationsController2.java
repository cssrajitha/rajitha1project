package onevz.soe.cart.controller;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.helper.*;
import onevz.soe.cart.model.initiateCbandCheck.InitiateCbandCheckResponseData;
import onevz.soe.cart.model.initiateCbandCheck.VmasBootUpInfo;
import onevz.soe.cart.model.initiateDeviceSimActivation.IntiateDeviceSimActivationUIRequest;
import onevz.soe.cart.model.initiateESimActivation.IntiateESimActivationUIRequest;
import onevz.soe.cart.requests.ESimDetailsETNIRequest;
import onevz.soe.cart.requests.InventoryStatusCheckRequest;
import onevz.soe.cart.requests.RetrieveCartCXPRequest;
import onevz.soe.cart.requests.ValidateCartCXPRequest;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.responses.InventoryStatusCheckResponse;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.InitiateCbandCheckUIResponse;
import onevz.soe.cart.util.CartCxpRequestErrorsUtil;
import onevz.soe.cart.util.CartCxpResponseErrorsUtil;
import onevz.soe.cart.util.CartPegaRequestErrorsUtil;
import onevz.soe.cart.util.CartPegaResponseErrorsUtil2;
import onevz.soe.utilities.StringUtilities;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import jakarta.validation.Valid;
import java.time.Duration;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * Cart Controller class.
 */
@RestController
@RequestMapping(value = "cart")
public class CartReadOperationsController2 {

    private static final Logger logger = LoggerFactory.getLogger(CartReadOperationsController.class);

    @Autowired
    private UpdateCartHelper helper;

    @Autowired
    private ReadCartHelper readCartHelper;

    @Autowired
    private RedisHelper redisHelper;
    @Autowired
    private RedisHelper2 redisHelper2;
    @Autowired
    private RedisHelper3 redisHelper3;

    @Value("${5g.vmas.attr.deviceReachable}")
    private String deviceReachable;
    @Value("${5g.vmas.attr.snr5G}")
    private String snr5G;
    @Value("${5g.vmas.attr.networkType}")
    private String networkType;
    @Value("${5g.vmas.attr.setupReason}")
    private String setupReason;
    @Value("${5g.vmas.attr.postMount5GSignal}")
    private String postMount5GSignal;

    @Value("${bbp.5g.isNonProd:false}")
    private boolean nonProd;

    @Value("${soe.nextgen.sendCustomerType:true}")
    private boolean sendCustomerType;




    /**
     *
     * @param binder
     */
    @InitBinder("*")
    public void initBinderByName(WebDataBinder binder) {
        binder.setDisallowedFields(new String[] { "genericHeader" });
    }

    /**
     * Initiate E sim activation.
     *
     * @param httpHeader the http header
     * @param httpResponse the http response
     * @param request the request
     * @return the mono
     */
    @PostMapping({"/initiateESimActivation", "/nse/initiateESimActivation"})
    public Mono<ResponseEntity<GenericResponse>> initiateESimActivation (ServerHttpRequest httpHeader,
                                                                         ServerHttpResponse httpResponse, @Valid @RequestBody IntiateESimActivationUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "initiateESimActivation");
        logger.debug("initiateESimActivation Request: {}", request);
        Mono<IntiateESimActivationUIRequest> eSimValidationUIRequest = settingESimActivationData(request);
        return eSimValidationUIRequest.flatMap(eSimUIRequest->{
            ErrorResponse errors = CartCxpRequestErrorsUtil.handleESimValidationRequestErrors(eSimUIRequest);
            if (errors.getErrors() != null) {
                return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
            }
            return redisHelper.getDataFromRedis().flatMap(data -> {
                logger.info("Companion phone number from Redis for initiateEsimActivation: {}",data.getCompanionPhoneNumber());
                return helper.initiateESimActivation(request).flatMap(resp -> {
                    //VZWYN-17848 change
                    if(StringUtilities.isNotEmptyOrNull(data.getCompanionPhoneNumber())){
                        logger.info("Companion phone number from Redis for initiateEsimActivation: {}",data.getCompanionPhoneNumber());
                        resp.getData().setCompanionMdn(data.getCompanionPhoneNumber());
                    }
                    return redisHelper2.upsertInitiateESimActivation(resp).flatMap(redisdata -> {
                        ErrorResponse errors2 = null;
                        if (resp.getErrors() != null) {
                            errors2 = CartCxpResponseErrorsUtil.handleInitiateESimActivationErrors(resp);
                        }

                        logger.info("Data upserted in redis: {}", redisdata);
                        return errors2 != null ? Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(errors2))
                                : Mono.just(ResponseEntity.status(HttpStatus.OK).body(resp));
                    });
                });
            });
        });
    }


    /**
     * Initiate device sim activation.
     *
     * @param httpHeader the http header
     * @param httpResponse the http response
     * @param request the request
     * @return the mono
     */
    @PostMapping({"/initiateDeviceSimActivation", "/nse/initiateDeviceSimActivation"})
    public Mono<ResponseEntity<GenericResponse>> initiateDeviceSimActivation (ServerHttpRequest httpHeader,
                                                                              ServerHttpResponse httpResponse, @Valid @RequestBody IntiateDeviceSimActivationUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "initiateDeviceSimActivation");
        logger.debug("initiateDeviceSimActivation Request: {}", request);

        return helper.initiateDeviceSimActivation(request).map(resp -> {
            ErrorResponse errors2 = null;
            if (resp.getErrors() != null) {
                errors2 = CartCxpResponseErrorsUtil.handleInitiateDeviceSimActivationErrors(resp);
            }
            //inserting data into redis
            redisHelper3.upsertInitiateDeviceSimActivationDataIntoRedis(request);
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(resp);
        });
    }


    /**
     *
     * @param httpHeader
     * @param httpResponse
     * @param request
     * @return GenericResponse
     *
     */
    @PostMapping("/createCaseAndGetCustomerInfo")
    public Mono<ResponseEntity<GenericResponse>> createCaseAndGetCustomerInfo(ServerHttpRequest httpHeader,
                                                                              ServerHttpResponse httpResponse, @Valid @RequestBody CreateCaseAndGetCustomerInfoUIRequest request) {

        System.setProperty(CartConstants.ENDPOINT, "createCaseAndGetCustomerInfo");
        logger.debug("createCaseAndGetCustomerInfo Request: {}", request);
        String accountNumber = httpHeader.getHeaders().containsKey(CartConstants.ACCOUNT_NUMBER)?
                httpHeader.getHeaders().getFirst(CartConstants.ACCOUNT_NUMBER):"";
        String customerId = accountNumber != null ? accountNumber.replaceAll("--+","-") : "";

        Mono<CreateCaseAndGetCustomerInfoUIRequest>  createCaseAndGetCustomerInfoUIRequest = settingBBPData(request);
        return createCaseAndGetCustomerInfoUIRequest.flatMap(req -> {
            ErrorResponse errors = CartCxpRequestErrorsUtil.handleGetCustomerInfoRequestErrors(req);
            if (errors.getErrors() != null)
                return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));

            //GraphQL call to get mtn based on imei
            return helper.getCustomerInfo(req, customerId).flatMap(cxpResponse -> {
                ErrorResponse errors2 = null;
                if (cxpResponse.getErrors() != null)
                    errors2 = CartCxpResponseErrorsUtil.handleGetCustomerInfoResponseErrors(cxpResponse);
                else {
                    String mtn = cxpResponse.getData().getMtn();

                    //Pega call to create case
                    return helper.createCase(request, httpHeader, mtn).flatMap(resp -> {
                        redisHelper2.upsertValueInRedis(CartConstants.CASE_ID,resp.getData().getContext().getCaseId());

                        resp.getData().setChannelId(cxpResponse.getData().getChannelId());
                        //hiding sensitive data - VZWYN-18780
                        resp.getData().setImei("");
                        resp.getData().setImei2("");
                        resp.getData().getContext().getCustomerInfo().setAccountNumber("");
                        resp.getData().getContext().setCaseId("");
                        resp.getData().setMtn(cxpResponse.getData().getMtn());
                        resp.getData().setDeviceName(cxpResponse.getData().getDeviceName());
                        resp.getData().setBillingInfo(cxpResponse.getData().getBillingInfo());
                        resp.getData().setPlanInfo(cxpResponse.getData().getPlanInfo());
                        resp.getData().getContext().getContextInfo().setOrderRestrictions(null);

                        ErrorResponse errors3 = null;
                        if (resp.getErrors() != null) {
                            errors3 = CartPegaResponseErrorsUtil2.handleCreateCaseResponseErrors(resp);
                        }
                        return errors3 != null ? Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(errors3))
                                : Mono.just(ResponseEntity.status(HttpStatus.OK).body(resp));
                    });
                }
                return errors2 != null ? Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(errors2))
                        : Mono.just(ResponseEntity.status(HttpStatus.OK).body(cxpResponse));
            });

        });
    }




    private  Mono<CreateCaseAndGetCustomerInfoUIRequest> settingBBPData(CreateCaseAndGetCustomerInfoUIRequest request){
        if (StringUtilities.isEmptyOrNull(request.getImei())) {
            //reading info from redis
            return redisHelper.getDataFromRedis().flatMap(redisData -> {
                if (StringUtilities.isNotEmptyOrNull(redisData.getBbpImei())) {
                    request.setImei(redisData.getBbpImei());
                }
                return Mono.just(request);

            });
        }
        return Mono.just(request);
    }


    /**
     *
     * @param httpHeader
     * @param httpResponse
     * @param request
     * @return ResponseEntity
     *
     */
    @PostMapping({ "/nse/getPairedWatches", "/getPairedWatches" })
    public Mono<ResponseEntity<GenericResponse>> getPairedWatches(ServerHttpRequest httpHeader,
                                                                  ServerHttpResponse httpResponse, @Valid @RequestBody GetPairedDevicesUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "getPairedWatches");
        logger.debug("getPairedWatches Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        return helper.getPairedDevices(request,channelId).map(resp -> {
            ErrorResponse errors2 = null;
            if (resp.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil2.handleGetPairedWatchesResponseErrors(resp);
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(resp);
        });
    }


    @PostMapping(path = "/nse/myLink/validateSalesRepId/{salesRepId}/{domainName}")
    public Mono<ResponseEntity<GenericResponse>> postMyLinkCookie(ServerHttpRequest httpHeader,
                                                                  ServerHttpResponse httpResponse, @PathVariable String salesRepId, @PathVariable String domainName) {

        return readCartHelper.salesRepIdProfile(salesRepId).map(resp -> {
            if (resp != null && resp.getData() != null && resp.getData().isValidSalesRepId() == true) {
                httpResponse.addCookie(ResponseCookie.from("RepIdCookieText", salesRepId).maxAge(Duration.ofDays(30))
                        .httpOnly(false).path("/").build());
                httpResponse.addCookie(ResponseCookie.from("MyLinkSalesDomain", domainName).maxAge(Duration.ofDays(30))
                        .httpOnly(false).path("/").build());
            }
            return ResponseEntity.status(HttpStatus.OK).body(resp);
        });
    }


    @PostMapping({ "/retrieveActivationStatus", "/nse/retrieveActivationStatus" })
    public Mono<ResponseEntity<GenericResponse>> retrieveActivationStatus(ServerHttpRequest httpHeader,
                                                                          ServerHttpResponse httpResponse, @Valid @RequestBody RetrieveActivationStatusUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "retrieveActivationStatus");
        logger.debug("retrieveActivationStatus Request: {}", request);

        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        if (request.getIntent().equalsIgnoreCase(CartConstants.NSE_BYOD)
                && !CartConstants.VZW_BBP.equalsIgnoreCase(channelId)) {

            return readCartHelper.retrieveActivationStatusFromCXP(channelId).map(resp -> {
                ErrorResponse errors = null;
                if (resp.getErrors() != null) {
                    errors = CartPegaResponseErrorsUtil2.handleRetrieveActivationStatusResponseErrors(resp);
                }
                return errors != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors)
                        : ResponseEntity.status(HttpStatus.OK).body(resp);
            });

        }else {
            return redisHelper.getDataFromRedis().flatMap(data -> {
                return readCartHelper.retrieveActivationStatus(httpHeader, request).map(resp -> {
                    ErrorResponse errors2 = null;
                    if (resp.getErrors() != null) {
                        errors2 = CartPegaResponseErrorsUtil2.handleRetrieveActivationStatusResponseErrors(resp);
                    }

                    if (CartConstants.VZW_BBP.equalsIgnoreCase(request.getChannelId())) {
                        resp.setDeviceType(data.getDeviceType());
                    }
                    //NSADT-145273 changes
                    if(null != data){
                        logger.info("data from redis: {}", data);
                        if(StringUtilities.isNotEmptyOrNull(data.getBrandName()))
                            resp.setBrandName(data.getBrandName());
                        if(StringUtilities.isNotEmptyOrNull(data.getCcarDeviceState()))
                            resp.setCcarDeviceState(data.getCcarDeviceState());
                        if(StringUtilities.isNotEmptyOrNull(data.getEsimType()))
                            resp.setEsimType(data.getEsimType());
                    }

                    return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                            : ResponseEntity.status(HttpStatus.OK).body(resp);
                });
            });
        }
    }


    //VZWCS-17115 changes - start
    @PostMapping({ "/nse/initiateCbandCheck"})
    public Mono<ResponseEntity<GenericResponse>> initiateCbandCheck(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse,
                                                                    @Valid @RequestBody InitiateCbandCheckUIRequest request) {
        logger.info("initiateCbandCheck UI Request: {}", request);
        //to read imsi details from redis
        Mono<InitiateCbandCheckUIRequest> initiateCbandCheckUIRequest = settingCbandCheckData(request);
        logger.info("updated initiateCbandCheck UI Request: {}", request);
        InitiateCbandCheckUIResponse response = new InitiateCbandCheckUIResponse();
        InitiateCbandCheckResponseData data = new InitiateCbandCheckResponseData();
        VmasBootUpInfo vmasBootUpInfo = new VmasBootUpInfo();
        if(StringUtilities.isNotEmptyOrNull(request.getBbflowType()) && StringUtilities.isNotEmptyOrNull(request.getTestMDN())) {
            vmasBootUpInfo.setDeviceReachable(deviceReachable);
            vmasBootUpInfo.setNetworkType(networkType);
            vmasBootUpInfo.setMtn(request.getTestMDN());
            vmasBootUpInfo.setBooted(true);
            vmasBootUpInfo.setSnr5G(snr5G);
            vmasBootUpInfo.setSetupReason(setupReason);
            data.setVmasBootUpInfo(vmasBootUpInfo);
            data.setInternetStatusCode(Arrays.asList("D"));
            if("cbd".equalsIgnoreCase(request.getBbflowType())) {
                data.setNetworkBandwidthType("CBD");
            }
            else if("mmw".equalsIgnoreCase(request.getBbflowType())) {
                data.setNetworkBandwidthType("MMW");
            }
            data.setMtnStatusCode("S");
            data.setMtnStatusReasonCode("GS");
            response.setData(data);
            return redisHelper2.upsertInitiateCbandCheckDataIntoRedis(response.getData()).flatMap(redisData -> {
                return Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));
            });
        }
        return initiateCbandCheckUIRequest.flatMap(cbandCheckRequest -> {
            ErrorResponse errors = CartCxpRequestErrorsUtil.handleInitiateCbandCheckRequestErrors(cbandCheckRequest);
            if(null != errors.getErrors()) {
                return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
            }
            return readCartHelper.initiateCbandCheck(request).flatMap(resp -> {
                logger.info("InitiateCbandCheck data to be stored in redis {}", resp.getData().getVmasBootUpInfo());
                if(((resp!=null && resp.getData()!=null && resp.getData().getVmasBootUpInfo()!=null && resp.getData().getVmasBootUpInfo().getBooted()!=null && resp.getData().getVmasBootUpInfo().getBooted().toString().equalsIgnoreCase(CartConstants.FALSE)) ||  (resp.getData().getVmasBootUpInfo().getBooted().toString().equalsIgnoreCase("true") && StringUtilities.isEmptyOrNull(resp.getData().getVmasBootUpInfo().getNetworkType()))) && (nonProd)) {
                    resp.getData().getVmasBootUpInfo().setDeviceReachable(deviceReachable);
                    resp.getData().getVmasBootUpInfo().setNetworkType(networkType);
                    resp.getData().getVmasBootUpInfo().setSnr5G(snr5G);
                    resp.getData().getVmasBootUpInfo().setSetupReason(setupReason);
                    if(StringUtilities.isNotEmptyOrNull(postMount5GSignal)) {
                        resp.getData().getVmasBootUpInfo().setPostMount5GSignal(postMount5GSignal);
                    }
                }

                return redisHelper2.upsertInitiateCbandCheckDataIntoRedis(resp.getData()).flatMap(redisData -> {
                    ErrorResponse errors1 = null;
                    if(null != resp.getErrors() && null == resp.getData()) {
                        errors1 = CartCxpResponseErrorsUtil.handleInitiateCbandCheckResponseErrors(resp);
                    }
                    logger.info("Data stored in redis {}", redisData);
                    resp.getData().setBillAccountNo("");
                    resp.getData().setCustomerId("");
                    return errors1 != null ? Mono.just(ResponseEntity.status(HttpStatus.OK).body(errors1))
                            : Mono.just(ResponseEntity.status(HttpStatus.OK).body(resp));
                });
            });
        });
    }

    /**
     *
     * @param httpHeader
     * @param httpResponse
     * @param request
     * @return response
     *
     */
    @PostMapping("/managerApprovalLines")
    public Mono<ResponseEntity<GenericResponse>> managerApprovalLines(ServerHttpRequest httpHeader,
                                                                      ServerHttpResponse httpResponse, @Valid @RequestBody RetrieveCartCXPRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "managerApprovalLines");
        logger.debug("managerApprovalLines Request: {}", request);
        return readCartHelper.managerApprovalLines(request).map(resp -> {
            ErrorResponse errors2 = null;
            if (resp.getErrors() != null) {
                errors2 = CartCxpResponseErrorsUtil.handleRetrieveCartResponseErrors(resp);
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(resp);
        });
    }

    /**
     * Email cart to customer.
     *
     * @param httpHeader   the http header
     * @param httpResponse the http response
     * @param request      the request
     * @return resp
     * @Signals that an I/O exception has occurred.
     */
    @PostMapping("/emailCartToCustomer")
    public Mono<ResponseEntity<GenericResponse>> emailCartToCustomer(ServerHttpRequest httpHeader,
                                                                     ServerHttpResponse httpResponse, @Valid @RequestBody EmailCartToCustomerUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "emailCartToCustomer");
        logger.debug("emailCartToCustomer Request: {}", request);
        return helper.emailCartToCustomer(request).map(resp -> {
            ErrorResponse errors2 = null;
            if (resp.getErrors() != null) {
                errors2 = CartCxpResponseErrorsUtil.handleEmailCartToCustomerResponseErrors(resp);
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(resp);
        });
    }

    /**
     *
     * @param httpHeader
     * @param httpResponse
     * @param request
     * @return GenericResponse
     *
     */
    @PostMapping("/customerByMtnList")
    public Mono<ResponseEntity<GenericResponse>> customerByMtnList(ServerHttpRequest httpHeader,
                                                                   ServerHttpResponse httpResponse, @Valid @RequestBody CustomerByMtnListUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "customerByMtnList");
        logger.debug("customerByMtnList Request: {}", request);
        ErrorResponse errors = CartCxpRequestErrorsUtil.handleCustomerByMtnListRequestErrors(request);
        if (errors.getErrors() != null) {
            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
        }
        return helper.customerByMtnList(request).map(resp -> {
            ErrorResponse errors2 = null;
            if (resp.getErrors() != null) {
                errors2 = CartCxpResponseErrorsUtil.handleCustomerByMtnListResponseErrors(resp);
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(resp);
        });
    }


    /**
     *
     * @param httpHeader
     * @param httpResponse
     * @param request
     * @return ResponseEntity
     *
     */
    @PostMapping({ "/eSimDetails", "/nse/eSimDetails" })
    public Mono<ResponseEntity<GenericResponse>> eSimDetails(ServerHttpRequest httpHeader,
                                                             ServerHttpResponse httpResponse, @Valid @RequestBody ESimDetailsETNIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "eSimDetails");
        logger.debug("eSimDetails Request: {}", request);
        ErrorResponse errors = CartPegaRequestErrorsUtil.handleEsimDetailsRequestValidation(request);
        if (errors.getErrors() != null) {
            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
        }
        return readCartHelper.eSimDetails(request).map(resp -> {
            ErrorResponse errors2 = null;
            if (resp.getErrors() != null) {
                String e2eRequestId = httpResponse.getHeaders().containsKey("e2eRequestId") ? httpResponse.getHeaders().getFirst("e2eRequestId") : "";
                errors2 = CartCxpResponseErrorsUtil.handleESimDetailsResponseErrors(resp, e2eRequestId);
            }

            return errors2 != null ? ResponseEntity.status(StringUtilities.isNotEmptyOrNull(errors2.getErrors().get(0).getErrorCode()) ? HttpStatus.valueOf(Integer.valueOf(errors2.getErrors().get(0).getErrorCode())) : httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(resp);
        });
    }
    /**
     *
     * @param httpHeader
     * @param httpResponse
     * @param request
     * @return ResponseEntity
     *
     */
    @PostMapping({ "/deviceCategory", "/nse/deviceCategory" })
    public Mono<ResponseEntity<GenericResponse>> deviceCategory(ServerHttpRequest httpHeader,
                                                             ServerHttpResponse httpResponse, @Valid @RequestBody ValidateCartCXPRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "deviceCategory");
        logger.debug("deviceCategory Request: {}", request);
        List<String> channelIdList = httpHeader.getHeaders().get(CartConstants.CHANNEL_ID);
        if (httpHeader.getHeaders() != null && channelIdList != null
                && channelIdList.size() > 0)
            request.setChannelId(channelIdList.get(0));

     return readCartHelper.getDeviceCategory(request).map(response-> ResponseEntity.status(HttpStatus.OK).body(response));

    }

    @PostMapping({ "/validateNextgenCartAndCheckout", "/nse/validateNextgenCartAndCheckout" })
    public Mono<ResponseEntity<GenericResponse>> validateNextgenCartAndCheckout(ServerHttpRequest httpHeader,
                                                                ServerHttpResponse httpResponse, @Valid @RequestBody ValidateCartCXPRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "validateNextgenCartAndCheckout");
        logger.debug("validateNextgenCartAndCheckout Request: {}", request);
        List<String> channelIdList = httpHeader.getHeaders().get(CartConstants.CHANNEL_ID);
        if (httpHeader.getHeaders() != null && channelIdList != null
                && channelIdList.size() > 0)
            request.setChannelId(channelIdList.get(0));
        String customerType= "";
        Map<String, String> map = new HashMap<String, String>();
        if(sendCustomerType) {
            customerType=  StringUtils.containsIgnoreCase(httpHeader.getPath().value(),CartConstants.NSE)? CartConstants.NEW_CUSTOMER:CartConstants.EMPTY_STRING;
            map.put("customerType", customerType);
        }else{
            map.put("customerType", CartConstants.N);
        }
        request.setMeta(map);


        return readCartHelper.validateNextgenCartAndCheckout(request).map(response-> ResponseEntity.status(HttpStatus.OK).body(response));

    }

    @PostMapping("/deviceInventoryStatusCheck")
    public Mono<ResponseEntity<InventoryStatusCheckResponse>> deviceInventoryStatusCheck(@RequestBody InventoryStatusCheckRequest request){
        System.setProperty(CartConstants.ENDPOINT, "deviceInventoryStatusCheck");
        logger.debug("deviceInventoryStatusCheck Request: {}", request);
        if(request.getSerialNumber()!=null){
            return readCartHelper.deviceInventoryStatusCheck(request).map(res->ResponseEntity.status(HttpStatus.OK).body(res));
        }else{
            InventoryStatusCheckResponse response = new InventoryStatusCheckResponse();
            response.setMessage("Imei Number is not provided...");
            return Mono.just(response).map(res->ResponseEntity.status(HttpStatus.BAD_REQUEST).body(res));
        }
    }



    private Mono<InitiateCbandCheckUIRequest> settingCbandCheckData(InitiateCbandCheckUIRequest request) {
        if (StringUtilities.isEmptyOrNull(request.getImsi())) {
            return redisHelper.getDataFromRedis().flatMap(redisData -> {
                logger.info("Data read from redis is: {}", redisData);
                if (StringUtilities.isNotEmptyOrNull(redisData.getImsi())) {
                    logger.info("imsi from redis is: {}", redisData.getImsi());
                    request.setImsi(redisData.getImsi());
                }
                logger.info("imsi set in request is: {}", request.getImsi());
                return Mono.just(request);
            });
        }
        return Mono.just(request);
    }

    private Mono<IntiateESimActivationUIRequest> settingESimActivationData(IntiateESimActivationUIRequest request) {
        if (StringUtilities.isEmptyOrNull(request.getEid()) && StringUtilities.isEmptyOrNull(request.getImei())
                && StringUtilities.isEmptyOrNull(request.getHandOffToken())) {
            return redisHelper.getDataFromRedis().flatMap(redisData -> {
                if (StringUtilities.isNotEmptyOrNull(redisData.getEid())) {
                    logger.info("Eid from redis for initiateESimActivation: {}",redisData.getEid());
                    request.setEid(redisData.getEid());
                }
                if (StringUtilities.isNotEmptyOrNull(redisData.getImei())) {
                    logger.info("imei from redis for initiateESimActivation: {}",redisData.getImei());
                    request.setImei(redisData.getImei());
                }
                if (StringUtilities.isNotEmptyOrNull(redisData.getHandOffToken())) {
                    logger.info("handofftoken from redis for initiateESimActivation: {}",redisData.getHandOffToken());
                    request.setHandOffToken(redisData.getHandOffToken());
                }

                return Mono.just(request);

            });
        }
        return Mono.just(request);
    }





}
