package onevz.soe.cart.helper;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.bulkcartupdate.*;
import onevz.soe.cart.model.bulkcartupdate.Lines;
import onevz.soe.cart.model.bulkcartupdate.Line;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

import static onevz.soe.cart.util.FlexV2Util.isAccountHasBillAcc;

@Service
public class BulkUpdateAIQuoteHelper1 {

    public Vzdl getVzdlDataForBulkUpdate(BulkQuoteUIRequest request, BulkQuoteUIResponse response, CartRedisData rr) {
        boolean reqDataNullCheck = request != null && request.getData() != null;
        boolean resDataNullCheck = response != null && response.getServiceBody() != null;
        Vzdl vzdl = null;
        if (resDataNullCheck && reqDataNullCheck) {
            vzdl = populateVzdlDataForBulkUpdate(request, response, rr);
        }
        return vzdl;
    }

    public Vzdl populateVzdlDataForBulkUpdate(BulkQuoteUIRequest request, BulkQuoteUIResponse response, CartRedisData rr) {
        Optional<Lines> requestLine = Optional.ofNullable(request).map(BulkQuoteUIRequest::getData).map(CartData::getLines).map(lines -> lines.size() != 0 ? lines.get(0) : null);
        Optional<CartServiceBulkCartInfo> cartInfo = Optional.ofNullable(response.getServiceBody()).map(CreateBulkQuoteServiceBody::getServiceResponse).map(CreateBulkQuoteServiceResponse::getContext).map(CreateBulkQuoteContext::getCartInfo);
        Optional<Line> responseLine = cartInfo.map(CartServiceBulkCartInfo::getLines).map(lines -> lines.length > 0 ? lines[0] : null);
        Vzdl vzdl = null;

        if (cartInfo.isPresent() && responseLine.isPresent() && requestLine.isPresent()) {
            vzdl = new Vzdl();
            updateUserData(vzdl, rr, request);
            updatePageData(vzdl, request);
            updateTxnData(vzdl, rr, request, cartInfo);
            updateProductDataForBulkUpdate(vzdl, rr,  request, requestLine, cartInfo);
            updateEvent(vzdl);
        }
        return vzdl;
    }

    public void updateUserData(Vzdl vzdl, CartRedisData rr, BulkQuoteUIRequest request) {
        if (null != rr && null != rr.getCustomerProfile() && null != rr.getCustomerProfile().getData() && null != rr.getCustomerProfile().getData().getCustomer()) {
            User user = new User();
            onevz.soe.customerprofile.model.gql.assisted.Customer customer = rr.getCustomerProfile().getData().getCustomer();
            if (StringUtilities.isNotEmptyOrNull(rr.getCustomerProfile().getData().getCustomer().getCustomerHash())) {
                user.setAccount(customer.getCustomerHash());
            }
            String accountNo = customer.getAccountNo();
            user.setAcctId_unhashed(accountNo);
            user.setCustId_unhashed(customer.getCustomerId());
            if (StringUtilities.isNotEmptyOrNull(accountNo)) {
                int dashIndex = accountNo.indexOf("-");
                user.setAccountLast2(accountNo.substring(dashIndex - 2, dashIndex));
            }
            if (null != customer.getCustomerAttributes())
                user.setCustomerType(customer.getCustomerAttributes().getCustomerType());

            if (customer.getBillAccounts() != null && !customer.getBillAccounts().isEmpty()) {
                customer.getBillAccounts().stream().filter(Objects::nonNull).forEach(billAccount -> {
                    if (billAccount.getMtns() != null) {
                        user.setNumberOfLines(String.valueOf(billAccount.getMtns().size()));
                        billAccount.getMtns().stream().filter(Objects::nonNull).forEach(mtn -> {
                            if (mtn.getMtn() != null && mtn.getMtn().equalsIgnoreCase(customer.getLookupMtn())) {
                                user.setId(mtn.getMtnHashCode());
                            }
                        });
                    }
                });
            }
            if (null != customer.getAddress() && StringUtilities.isNotEmptyOrNull(customer.getAddress().getZipCode())) {
                user.setZip(customer.getAddress().getZipCode());
            }
            user.setSession(request.getCartInfo().getSessionId());

            vzdl.setUser(user);
        }
    }

    public void updatePageData(Vzdl vzdl, BulkQuoteUIRequest request) {
        Page page = new Page();
        page.setName("ai-quote-selection-bulkUpdate");
        page.setLanguage("English");
        page.setFlowType("");
        page.setFlowName("Aiquote");
        if (StringUtilities.isNotEmptyOrNull(request.getChannelId())) {
            page.setChannel("Order");
            if (request.getChannelId().equalsIgnoreCase(CartConstants.RETAIL) || request.getChannelId().equalsIgnoreCase(CartConstants.RETAIL_IPAD))
                page.setDisplayChannel("retail");
        }
        if (null != request.getCartInfo()) {
            if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())) {
                page.setFlow(request.getCartInfo().getIntendType());
            }
            if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCaseId())) {
                page.setPegaCaseId(request.getCartInfo().getCaseId());
            }
            if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCartId())) {
                page.setCartId(request.getCartInfo().getCartId());
            }
        }
        page.setThrottle("MFE");
        vzdl.setPage(page);
    }

    public String getFlowName(BulkQuoteUIRequest request, BulkQuoteUIResponse response) {

       return Optional.ofNullable(request).map(BulkQuoteUIRequest::getData).map(CartData::getLines)
               .map(linesList -> {
                   StringBuilder flowName = new StringBuilder();
                   linesList.forEach(lines -> {
                       if(!ObjectUtils.isEmpty(lines.getDevice()) && StringUtilities.isNotEmptyOrNull(lines.getDevice().getId()))
                           appendFlowName(flowName, CartConstants.EUP);
                       if(!ObjectUtils.isEmpty(lines.getPlan()) && StringUtilities.isNotEmptyOrNull(lines.getPlan().getId()))
                           appendFlowName(flowName, CartConstants.CPC);
                       appendFlowNameForUpgradeFee(response, flowName, lines);
                       if(CollectionUtilities.isNotEmptyOrNull(lines.getAddFeatures()) && StringUtilities.isNotEmptyOrNull(lines.getAddFeatures().get(0).getId()))
                           appendFlowName(flowName, CartConstants.FEA);
                       if(CollectionUtilities.isNotEmptyOrNull(lines.getTradeInItems()) && StringUtilities.isNotEmptyOrNull(lines.getTradeInItems().get(0).getItemId()))
                           appendFlowName(flowName, CartConstants.TRADEIN);
                       if(!ObjectUtils.isEmpty(lines.getAddAccessories()) && StringUtilities.isNotEmptyOrNull(lines.getAddAccessories()[0].getId()))
                           appendFlowName(flowName, CartConstants.NAO_ACCESSORY);
                   });
                   return  flowName.toString();
        }).orElse("");
    }

    private void appendFlowNameForUpgradeFee(BulkQuoteUIResponse response, StringBuilder flowName, Lines lines) {
        Optional<CartServiceBulkCartInfo> cartServiceBulkCartInfo = Optional.ofNullable(response.getServiceBody()).map(CreateBulkQuoteServiceBody::getServiceResponse).map(CreateBulkQuoteServiceResponse::getContext).map(CreateBulkQuoteContext::getCartInfo);
        Optional<Line> isResponseLinesPresent = cartServiceBulkCartInfo.map(CartServiceBulkCartInfo::getLines).map(lines1 -> lines1.length > 0 ? lines1[0] : null);
        if( isResponseLinesPresent.isPresent()){
            Optional<Line> lines1= Arrays.stream(response.getServiceBody().getServiceResponse().getContext().getCartInfo().getLines())
                    .filter(Objects::nonNull)
                    .filter(line -> lines.getMtn().equalsIgnoreCase(line.getMtn()))
                    .findFirst();
            lines1.ifPresent(line -> {
                if(ObjectUtils.isNotEmpty(line.getUpgradeFee()) && line.getUpgradeFee().getQty()>0) {
                    appendFlowName(flowName, CartConstants.FEA);
                }
            });
        }
    }

    public void appendFlowName(StringBuilder flowName, String flowType){
        if(!StringUtils.isEmpty(flowName.toString())) {
            flowName.append("|");
        }
        flowName.append(flowType);
    }

    public void updateTxnData(Vzdl vzdl, CartRedisData rr, BulkQuoteUIRequest request, Optional<CartServiceBulkCartInfo> cartInfo) {
        Map<String, String> txn = new HashMap<>();
        if (cartInfo.isPresent()) {
            if (StringUtilities.isNotEmptyOrNull(cartInfo.get().getCartId())) {
                txn.put("cartId", cartInfo.get().getCartId());
            }
            if (StringUtilities.isNotEmptyOrNull(rr.getAutoPayEnrolled())) {
                txn.put("autoPay", rr.getAutoPayEnrolled());
            }
        }
        if (rr != null) {
            if (StringUtilities.isNotEmptyOrNull(rr.getLocationCode())) {
                txn.put("outletId", rr.getLocationCode());
            }
            if (null != request.getCartInfo() && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())) {
                txn.put("orderType", request.getCartInfo().getIntendType());
            }
            if (StringUtilities.isNotEmptyOrNull(rr.getAgentRole())) {
                txn.put("agentRole", rr.getAgentRole());
            }
        }
        vzdl.setTxn(txn);
    }

    public void updateProductDataForBulkUpdate(Vzdl vzdl, CartRedisData rr, BulkQuoteUIRequest request, Optional<Lines> requestLine, Optional<CartServiceBulkCartInfo> cartInfo) {
        Product product = new Product();
        List<Owns> ownsList = new ArrayList<>();
        List<Current> currentList = new ArrayList<>();
        List<String> requestMtnList = request.getData().getLines().stream().filter(Objects::nonNull).map(Lines::getMtn).collect(Collectors.toList());

        if (null != rr && rr.getCustomerProfile() != null && isAccountHasBillAcc(rr.getCustomerProfile())) {

            rr.getCustomerProfile().getData().getCustomer().getBillAccounts().stream().filter(Objects::nonNull).forEach(accData -> accData.getMtns().stream().filter(data -> requestMtnList.contains(data.getMtn())).forEach(matchedLine -> {
                Owns owns = new Owns();
                owns.setCategory("Plan");
                if (StringUtilities.isNotEmptyOrNull(matchedLine.getPricePlanInfo().getDescription())) {
                    owns.setName(matchedLine.getPricePlanInfo().getDescription());
                }
                if (StringUtilities.isNotEmptyOrNull(matchedLine.getPricePlanInfo().getPlanId())) {
                    owns.setId(matchedLine.getPricePlanInfo().getPlanId());
                }
                if (StringUtilities.isNotEmptyOrNull(matchedLine.getMtnHashCode())) {
                    owns.setLine(matchedLine.getMtnHashCode());
                }
                ownsList.add(owns);
            }));
        }

        if (requestLine.isPresent()) {

            Optional.ofNullable(request).map(BulkQuoteUIRequest::getData).map(CartData::getLines).ifPresent(linesList ->
                    linesList.forEach(lines -> {
                        if (null != lines.getDevice() && null != lines.getDevice().getId()) {
                            Current current = new Current();
                            current.setCategory("Device");
                            current.setId(lines.getDevice().getId());
                            current.setQty("1");
                            if (cartInfo.isPresent() && cartInfo.get().getLines() != null) {
                                Arrays.stream(cartInfo.get().getLines()).filter(line -> null != line && StringUtilities.isNotEmptyOrNull(line.getMtn()) && line.getMtn().equalsIgnoreCase(lines.getMtn()) && null != line.getDevice() && StringUtilities.isNotEmptyOrNull(line.getDevice().getId()) && line.getDevice().getId().equalsIgnoreCase(lines.getDevice().getId())).forEach(line -> {
                                    if (StringUtilities.isNotEmptyOrNull(line.getDevice().getDiscountAmount()))
                                        current.setDiscount(line.getDevice().getDiscountAmount());
                                    current.setSku(StringUtilities.isNotEmptyOrNull(line.getDevice().getSkuId()) ? line.getDevice().getSkuId() : "");
                                    current.setName(StringUtilities.isNotEmptyOrNull(line.getDevice().getSkuDisplayName()) ? line.getDevice().getSkuDisplayName() : "");
                                    current.setId(line.getDevice().getId());
                                    current.setRecurringPrice(String.valueOf(line.getMonthlyInstallment()));
                                    current.setNonRecurringPrice(StringUtilities.isNotEmptyOrNull(line.getDevice().getItemPrice()) ? line.getDevice().getItemPrice() : "");
                                });
                            }
                            currentList.add(current);
                        }

                        if(null != lines.getPlan() && null != lines.getPlan().getId()) {
                            Current current = new Current();
                            current.setCategory("Plan");
                            current.setQty("1");
                            current.setPropId(StringUtilities.isNotEmptyOrNull(lines.getPlan().getPropId()) ? lines.getPlan().getPropId() : "");
                            if (StringUtilities.isNotEmptyOrNull(lines.getPlan().getPath())) {
                                current.setPath(lines.getPlan().getPath());
                            }
                            if (cartInfo.isPresent() && cartInfo.get().getLines() != null) {
                                Arrays.stream(cartInfo.get().getLines()).filter(line -> null != line && StringUtilities.isNotEmptyOrNull(line.getMtn()) && line.getMtn().equalsIgnoreCase(lines.getMtn()) && null != line.getPlan() && StringUtilities.isNotEmptyOrNull(line.getPlan().getId()) && line.getPlan().getId().equalsIgnoreCase(lines.getPlan().getId())).forEach(line -> {
                                    if (StringUtilities.isNotEmptyOrNull(line.getPlan().getDiscountedPrice()))
                                        current.setRecurringPrice(line.getPlan().getDiscountedPrice());
                                    else
                                        current.setRecurringPrice(StringUtilities.isNotEmptyOrNull(line.getPlan().getPrice()) ? line.getPlan().getPrice() : "0.00");
                                    current.setName(StringUtilities.isNotEmptyOrNull(line.getPlan().getName()) ? line.getPlan().getName() : "");
                                    current.setId(line.getPlan().getId());
                                    current.setNonRecurringPrice("0.00");
                                });
                            }
                            currentList.add(current);
                        }

                        if (null != lines.getAddFeatures() && !lines.getAddFeatures().isEmpty()) {
                            lines.getAddFeatures().stream().filter(Objects::nonNull).forEach(feature -> {
                                Current featureCurrent = new Current();
                                featureCurrent.setCategory("Features");
                                featureCurrent.setQty("1");
                                featureCurrent.setNonRecurringPrice("0.00");
                                if (cartInfo.isPresent() && cartInfo.get().getLines() != null) {
                                    Arrays.stream(cartInfo.get().getLines()).filter(line -> null != line && StringUtilities.isNotEmptyOrNull(line.getMtn()) && line.getMtn().equalsIgnoreCase(lines.getMtn())).forEach(line -> Optional.ofNullable(line.getSpos()).ifPresent(spos -> Arrays.stream(spos).filter(spo -> null != spo && StringUtilities.isNotEmptyOrNull(spo.getId()) && StringUtilities.isNotEmptyOrNull(feature.getId()) && spo.getId().equalsIgnoreCase(feature.getId())).forEach(spo -> {
                                        featureCurrent.setId(spo.getId());
                                        featureCurrent.setSku(StringUtilities.isNotEmptyOrNull(spo.getSkuId()) ? spo.getSkuId() : "");
                                    })));
                                }
                                currentList.add(featureCurrent);
                            });
                        }

                    }));
        }
        Owns[] ownsArray = new Owns[ownsList.size()];
        Current[] currentArray = new Current[currentList.size()];
        product.setOwns(ownsList.toArray(ownsArray));
        product.setCurrent(currentList.toArray(currentArray));
        vzdl.setProduct(product);
    }

    public void updateEvent(Vzdl vzdl) {
        Event event = new Event();
        event.setValue("");
        vzdl.setEvent(event);
    }


}


