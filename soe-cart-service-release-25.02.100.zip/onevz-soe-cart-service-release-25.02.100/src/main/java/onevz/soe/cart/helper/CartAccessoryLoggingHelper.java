package onevz.soe.cart.helper;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import onevz.soe.cart.model.common.Accessory;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.AddAccessoriesUIRequest;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.utilities.StringUtilities;
import reactor.core.publisher.Mono;

@Service
public class CartAccessoryLoggingHelper {

	@Autowired
	SOELoginSessionBean sessionBean;

	private static final Logger logger = LoggerFactory.getLogger(RedisHelper.class);

	public Mono<Object> logAccessoryInkibana(AddAccessoriesUIRequest request) {

		try {
			String cartId = "";
			if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCartId()))
				cartId = request.getCartInfo().getCartId();
			StringBuilder lineListString = new StringBuilder();
			StringBuilder addAccessoryIdListString = new StringBuilder();
			StringBuilder removeAccessoryListString = new StringBuilder();
			if (request.getData().getLines().length > 0) {
				List<Lines> lineList = Arrays.asList(request.getData().getLines());
				if (lineList.size() > 0) {
					for (Lines lines : lineList) {

						if (null != lines.getMtn()) {
							lineListString.append(lines.getMtn());
						}

						if (null != lines.getAddAccessories() && lines.getAddAccessories().length > 0) {
							List<Accessory> addAccessoryList = Arrays.asList(lines.getAddAccessories());
							for (Accessory addAccessory : addAccessoryList) {
								if (null != addAccessory.getId()) {
									addAccessoryIdListString.append(addAccessory.getId());
								}

							}
						}
						if (null != lines.getRemoveAccessories() && lines.getRemoveAccessories().length > 0) {
							List<Accessory> removeAccessoryList = Arrays.asList(lines.getRemoveAccessories());
							for (Accessory removeAccessory : removeAccessoryList) {
								if (null != removeAccessory.getId()) {
									removeAccessoryListString.append(removeAccessory.getId());
								}

							}

						}

					}
				}
			}
			String loggerOutpu = "CartId :" + cartId + " " + "lineMtn :" + lineListString.toString() + " "
					+ "Accessory Added :" + addAccessoryIdListString.toString() + " " + "Accessory removed :"
					+ removeAccessoryListString.toString();
			logger.info("Cart Accessory Change : {}", loggerOutpu);
		} catch (Exception e) {
			logger.error("Error occured while writing accessory logs : {}", e.getMessage());
		}

		return Mono.empty();

	}

}
