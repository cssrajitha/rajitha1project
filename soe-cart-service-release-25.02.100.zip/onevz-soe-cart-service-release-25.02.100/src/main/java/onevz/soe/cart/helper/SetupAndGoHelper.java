package onevz.soe.cart.helper;

import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.orderConfirmation.CXPOrderConfirm5GVO;
import onevz.soe.cart.model.orderConfirmation.CXPOrderConfirmation5GDataVO;
import onevz.soe.cart.model.retrieveCart.*;
import onevz.soe.cart.responses.OrderConfirmationCXPResponse;
import onevz.soe.cart.responses.SUAGSelectionDetailsUIResponse;
import onevz.soe.utilities.StringUtilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class SetupAndGoHelper {
    private static final Logger logger = LoggerFactory.getLogger(SetupAndGoHelper.class);

    @Value("${mce.excluded.skus:[]}")
    private List<String> mceExcludedSkus;

    @Autowired
    private CartServiceCXPServices cxpServices;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private RedisHelper redisHelper;

    public Mono<SUAGSelectionDetailsUIResponse> getSUAGSelectionDetails(){
        return redisHelper.getDataFromRedis().flatMap(data -> {
            logger.info("getSUAGSelectionDetails::redisData {}", data);
            if (StringUtilities.isNotEmptyOrNull(data.getCartId())) {
                logger.info("getSUAGSelectionDetails::Invoking graphql for cartId: {}", data.getCartId());
                return cxpServices.getOrderConfirmationData(data.getCartId()).flatMap(cxpResponse -> {
                    logger.info("getSUAGSelectionDetails::Response from cxp graphql for cartId: {}, response:{}", data.getCartId(), cxpResponse);
                    SUAGSelectionDetailsUIResponse uiResponse = null;
                    if(null != cxpResponse.getData()) {
                        uiResponse = populateSetupAndGoUIResponse(cxpResponse);
                        logger.info("getSUAGSelectionDetails::created soe response {}", uiResponse);
                    } else {
                        uiResponse = new SUAGSelectionDetailsUIResponse();
                        uiResponse.setErrors(Arrays.asList(cxpResponse.getErrors()));
                        uiResponse.setData(null);
                    }
                    return Mono.just(uiResponse);
                });
            }else{
                return Mono.just(cartNotFoundInCacheErrorResposne());
            }
        });
    }

    private SUAGSelectionDetailsUIResponse cartNotFoundInCacheErrorResposne() {
        SUAGSelectionDetailsUIResponse errorResponse = new SUAGSelectionDetailsUIResponse();
        List<CartError> cartErrors = new ArrayList<>();
        CartError cartError = new CartError();
        cartError.setMessage("No cart found in cache");
        cartError.setNamespace(CartConstants.SOE_CART_SERVICE_NAME);
        cartError.setName(CartConstants.API_ERROR);
        cartErrors.add(cartError);
        errorResponse.setErrors(cartErrors);
        return errorResponse;
    }

    private SUAGSelectionDetailsUIResponse populateSetupAndGoUIResponse(OrderConfirmationCXPResponse cxpResponse){
        SUAGSelectionDetailsUIResponse response = new SUAGSelectionDetailsUIResponse();
        SUAGSelectionDetailsUIResponse.SUAGDetailsData suagDetailsData = new SUAGSelectionDetailsUIResponse.SUAGDetailsData();
        List<SUAGSelectionDetailsUIResponse.SUAGDetail> suagDetails = Optional.of(cxpResponse.getData())
                .map(CXPOrderConfirmation5GDataVO::getCart)
                .map(CXPOrderConfirm5GVO::getLineDetails)
                .map(CXPLineDetailsVO::getLineInfo)
                .map(lineInfos -> filterSUAGDevicesFromCart(lineInfos))
                .orElse(Collections.emptyList());

        suagDetailsData.setSuagDetails(suagDetails);
        response.setData(suagDetailsData);
         return response;
    }

    private List<SUAGSelectionDetailsUIResponse.SUAGDetail> filterSUAGDevicesFromCart(CXPLineInfo[] lineInfos) {
        List<SUAGSelectionDetailsUIResponse.SUAGDetail> suagDeviceDetails = new ArrayList<>();
        logger.info("populateSetupAndGoUIResponse:: has lineInfo in cart");
        Stream.of(lineInfos)
                .filter(lineInfo -> isLineEligibleForSUAG(lineInfo))
                .forEach(lineInfo -> populateSUAGDeviceDetailsForLine(lineInfo, suagDeviceDetails));
        return suagDeviceDetails;
    }

    private boolean isLineEligibleForSUAG(CXPLineInfo lineInfo) {
       return Optional.ofNullable(lineInfo)
                .map(CXPLineInfo::getItemsInfo)
                .stream()
                .flatMap(itemsInfo -> Stream.of(itemsInfo))
                .map(CXPItemInfo::getCartItems)
                .filter(Objects::nonNull)
                .map(CXPCartItemsVO::getCartItem)
                .filter(Objects::nonNull)
                .flatMap(cxpCartItems -> Stream.of(cxpCartItems))
                .filter(Objects::nonNull)
                .filter(cartItem -> CartConstants.SUG.equals(cartItem.getProdCode4()))
                .findAny()
                .isPresent();
    }

    private void  populateSUAGDeviceDetailsForLine(CXPLineInfo lineInfo, List<SUAGSelectionDetailsUIResponse.SUAGDetail> deviceDetails ) {
        List<CXPCartItem> deviceTypeCartItemList = fetchCartItemsHavingDeviceItemType(lineInfo);

        if(deviceTypeCartItemList.isEmpty()){
            //pick device from serviceInfo
            populateDeviceDetailFromServiceInfo(lineInfo, deviceDetails);
        }else{
            deviceTypeCartItemList.forEach(cartItem ->{
                logger.info("populateSetupAndGoUIResponse:: has cartItem in cart");
                SUAGSelectionDetailsUIResponse.SUAGDetail deviceDetail= new SUAGSelectionDetailsUIResponse.SUAGDetail();
                deviceDetail.setMtn(cartItem.getMobileNumber());
                populateSUAGDeviceDetails(deviceDetail,cartItem.getItemCode(),cartItem.getManufacturer(),cartItem.getDescription());
                deviceDetails.add(deviceDetail);
            });
        }
    }

    private void populateDeviceDetailFromServiceInfo(CXPLineInfo lineInfo, List<SUAGSelectionDetailsUIResponse.SUAGDetail> deviceDetails) {
        SUAGSelectionDetailsUIResponse.SUAGDetail deviceDetail = new SUAGSelectionDetailsUIResponse.SUAGDetail();
        Optional.ofNullable(lineInfo)
                .map(CXPLineInfo::getServiceInfo)
                .map(serviceInfo -> {
                    deviceDetail.setMtn(serviceInfo.getMtn());
                    return serviceInfo.getCurrentDevice();
                })
                .map(CurrentDevice::getOldLteVoraEquipInfo)
                .map(OldLteVoraEquipInfo::getLteVoraDeviceInfo)
                .map(lteVoraDeviceInfo -> {
                    logger.info("populateSetupAndGoUIResponse:: has lteVoraDeviceInfo in cart");
                    populateSUAGDeviceDetails(deviceDetail, lteVoraDeviceInfo.getDeviceSku(), lteVoraDeviceInfo.getManufacturer(), lteVoraDeviceInfo.getDescription());
                    return deviceDetail;
                }).ifPresent(deviceDetail2->{
                    deviceDetails.add(deviceDetail2);
                });
    }

    private List<CXPCartItem> fetchCartItemsHavingDeviceItemType(CXPLineInfo lineInfo) {
        return Optional.of(lineInfo)
                    .map(CXPLineInfo::getItemsInfo)
                    .filter(Objects::nonNull)
                    .stream()
                    .flatMap(itemsInfo -> Stream.of(itemsInfo))
                    .map(CXPItemInfo::getCartItems)
                    .filter(Objects::nonNull)
                    .map(CXPCartItemsVO::getCartItem)
                    .filter(Objects::nonNull)
                    .flatMap(cxpCartItems -> Stream.of(cxpCartItems))
                    .filter(cartItem -> CartConstants.DEVICE_TYPE.equals(cartItem.getCartItemType()))
                    .collect(Collectors.toList());
    }

    private void populateSUAGDeviceDetails(SUAGSelectionDetailsUIResponse.SUAGDetail suagDetail1, String deviceSku, String manufacturer, String description) {
        suagDetail1.setDeviceItemCode(deviceSku);
        suagDetail1.setMCESupportedDevice(!mceExcludedSkus.contains(deviceSku));
        suagDetail1.setManufacturer(manufacturer);
        suagDetail1.setDeviceItemDescription(description);
    }


}
