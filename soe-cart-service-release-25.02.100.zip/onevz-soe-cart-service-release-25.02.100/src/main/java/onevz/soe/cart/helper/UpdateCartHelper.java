package onevz.soe.cart.helper;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import jakarta.validation.Valid;

import onevz.cxp.feature.util.FeatureFlag;
import onevz.soe.cart.constants.FeatureFlagConstants;
import onevz.soe.cart.constants.RedisConstants;
import onevz.soe.cart.exceptions.CommonCartServiceException;
import onevz.soe.cart.gql.schema.bundlebuildercartlightweight.PromoHubOffer;
import onevz.soe.cart.model.addPromoIntent.AddPromoIntentUIRequest;
import onevz.soe.cart.model.addPromoIntent.AddPromoIntentUIResponse;
import onevz.soe.cart.model.assignMtn.AssignMtnData;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.createLine.HomeSalesAddress;
import onevz.soe.cart.model.deassignMtn.DeassignMtnData;
import onevz.soe.cart.model.mylink.MylinkReferralInfoResponse;
import onevz.soe.cart.model.retrieveCart.*;
import onevz.soe.cart.model.retrieveCart.ServiceInfo;
import onevz.soe.cart.model.session.PDMOfferData;
import onevz.soe.cart.model.tysPromos.SedOfferInfo;
import onevz.soe.cart.requests.*;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.ui.common.*;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.cart.util.*;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.vzw.cradle.util.CradleConstants;
import com.vzw.cradle.vo.CradleResponse;

import onevz.soe.cart.bpm.helper.CartServiceBpmHelper;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper2;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper3;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelperAddPlan;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper2;
import onevz.soe.cart.model.assignMtn.AssignMtnContext;
import onevz.soe.cart.model.assignMtn.AssignMtnServiceBody;
import onevz.soe.cart.model.assignMtn.AssignMtnServiceResponse;
import onevz.soe.cart.model.bvp.BVPLine;
import onevz.soe.cart.model.bvp.BestValueOffer;
import onevz.soe.cart.model.custProfile.MostRecentSalesRepCustomerDataResponse;
import onevz.soe.cart.model.initiateCheckout.InitiateCheckoutContext;
import onevz.soe.cart.model.initiateCheckout.InitiateCheckoutServiceBody;
import onevz.soe.cart.model.initiateCheckout.InitiateCheckoutServiceResponse;
import onevz.soe.cart.model.initiateCheckout.OrderDetail;
import onevz.soe.cart.model.initiateCheckout.ValidateOrder;
import onevz.soe.cart.model.initiateDeviceSimActivation.InitiateDeviceSimActivationUIResponse;
import onevz.soe.cart.model.initiateDeviceSimActivation.IntiateDeviceSimActivationUIRequest;
import onevz.soe.cart.model.initiateESimActivation.InitiateESimActivationUIResponse;
import onevz.soe.cart.model.initiateESimActivation.IntiateESimActivationUIRequest;
import onevz.soe.cart.model.initiateValidateDeviceSim.InitiateValidateDeviceSimUIRequest;
import onevz.soe.cart.model.initiateValidateDeviceSim.InitiateValidateDeviceSimUIResponse;
import onevz.soe.cart.model.quote.QuotePrices;
import onevz.soe.cart.model.resumeAndContinue.ResumeAndContinueServiceBody;
import onevz.soe.cart.model.resumeAndContinue.ResumeAndContinueServiceResponse;
import onevz.soe.cart.model.updateBarcode.UpdateBarcodeBarcodeId;
import onevz.soe.cart.model.validateCart.CartValidationError;
import onevz.soe.cart.nbx.NBXFeedbackService;
import onevz.soe.cart.omnidl.OmniBuilder;
import onevz.soe.cart.ui.common.AddDeviceData;
import onevz.soe.cart.ui.common.DeviceCartInfo;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cradle.CradleAllocator;
import onevz.soe.errorhandling.aem.model.AEMCreditExceptionResponse;
import onevz.soe.omnidl.data.OmniDLDataBuilder;
import onevz.soe.omnidl.service.OmniDLService;
import onevz.soe.omnidl.util.DLUtilityService;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.utilities.serialization.JacksonMapperFactory;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import static onevz.soe.cart.constants.CartConstants.DEVICE;
import static onevz.soe.cart.constants.CartConstants.EMPTY_STRING;

/**
 * CartService Helper class.
 */
@Service
public class UpdateCartHelper {


	@Autowired
	private DLUtilityService dlUtilityService;

	@Autowired
	private CartServiceCxpHelper cxpHelper;
	
	@Autowired
	private CartServiceCxpHelper2 cxpHelper2;

	@Autowired
	private CartServiceBpmHelper bpmHelper;
	
	@Autowired
	private CartServiceBpmHelperAddPlan bpmHelperAddPlan;
	
	@Autowired
	private CartServiceBpmHelper2 bpmHelper2;
	
	@Autowired
	private CartServiceBpmHelper3 bpmHelper3;

	@Autowired
	private ObjectMapper mapper;

	@Autowired
	private RedisHelper redisHelper;

	@Autowired
	private RedisHelper2 redisHelper2;

	@Autowired
	private RedisHelper3 redisHelper3;

	@Autowired
	SOELoginSessionBean sessionBean;

	@Autowired
	CradleAllocator cradleAllocator;

	@Autowired
	private NBXFeedbackService nbxService;

	@Autowired
	OmniDLService dlService;

    @Autowired
    private ReadCartHelper readCartHelper;

	@Autowired
	private CartRequestBuilder cartRequestBuilder;
	@Autowired
	private UpdateCartHelper1 updateCartHelper1;
	@Autowired
	private FeatureFlagHelper featureFlagHelper;
	@Value("${redirectLink}")
	private String reDirectLink;
	
	@Value("${enableSecurityForCart}")
	private boolean enableSecurityForCart;

	@Value("${soe.session.5g.creditcheckFailure.msg:test}")
	private String creditErrorForMaxAttempt;

	@Value("${orderChatStoreRestrictedAmount}")
	private String orderChatStoreRestrictedAmount;
	@Value("${soe.session.5g.creditcheckFailure.maxAttempts:5}")
	private int creditCheckMaxAttemptAllowed;

	@Value("${soe.digital.barcodeOffer}")
	private String barcodeOffer;
	@Value("${soe.digital.fwa.barcodeId}")
	private String fwaSweetnerCouponCode;

	@Value("${soe.digital.dynSWPlatformPromoType:Sweetener}")
	private String dynSWPlatformPromoType;

	@Value("${soe.digital.storeNpaNxxInCache:true}")
	private boolean storeNpaNxxInCache;

	List<String> preorderWhitelistMtnsList = new ArrayList<>();
	List<String> promoHubEnabledCategory = new ArrayList<>();

	@Value("${enableMHOffers}")
	private boolean enableMHOffers;

	@Autowired
	private CartAddDeviceHelper deviceHelper;
	
	@Autowired
	private CartAccessoryHelper accessoryHelper;
	
	@Autowired
	private CommonUtil util;
	@Autowired
	private OmniDLHelper dlHelper;
	
	private static Gson gson = new Gson();

	@Autowired
	FeatureFlag featureFlag;
	
	@Value("${soe.cart.upgradeErrorMessageForchannelIds}")
	private List<String> upgradeErrorMessageForchannelIds;
	
	@Value("${soe.cart.upgradeErrorMessage}")
	private String upgradeErrorMessage;
	
	/**
	 * 
	 * @param preorderWhitelistMtns
	 * @param promoHubEnabledCategory
	 */
	public UpdateCartHelper(@Value("${preorderWhitelistMtns}") String preorderWhitelistMtns,
							@Value("${promoHubEnabledCategory}") String promoHubEnabledCategory) {
		this.preorderWhitelistMtnsList = Arrays.asList(preorderWhitelistMtns.split(","));
		this.promoHubEnabledCategory = Arrays.asList(promoHubEnabledCategory.split(","));
	}

	private static final Logger logger = LoggerFactory.getLogger(UpdateCartHelper.class);




	/**
	 * @param request
	 * @return UpdateUserInfoUIResponse
	 */
	public Mono<UpdateUserInfoUIResponse> updateUserInfo(UpdateUserInfoUIRequest request) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			logger.debug("Calling cxp helper with redis CartID {}", data.getCartId());
			if(request.isFlexV2()) {
				cartRequestBuilder.buildUserInfoRequest(request, data);
			}
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				request.setCartId(data.getCartId());
			return cxpHelper.updateUserInfo(request);
		});
	}

	/**
	 * @param request
	 * @return PaperlessBillingUIResponse
	 */
	public Mono<PaperlessBillingUIResponse> paperlessBilling(PaperlessBillingUIRequest request) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			logger.debug(String.format(CartConstants.LOG_REDIS_ACCOUNT_NUMBER, data.getAccountNumber()));
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				request.setCartId(data.getCartId());
			return cxpHelper.paperlessBilling(request);
		});

	}

	/**
	 * @param updateBarcodeUIRequest
	 * @return UpdateBarCodeUIResponse
	 */
	public Mono<UpdateBarcodeUIResponse> updateBarcode(UpdateBarcodeUIRequest updateBarcodeUIRequest) {
		String channelType = CartUtil.getChannelType(updateBarcodeUIRequest.getChannelId());
		return redisHelper.getDataFromRedis().flatMap(data -> {
            boolean isIntendTypeNSE = (StringUtilities.isNotEmptyOrNull(updateBarcodeUIRequest.getCartInfo().getIntendType()) && updateBarcodeUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE"));
			if(updateBarcodeUIRequest != null && updateBarcodeUIRequest.getCartInfo() != null &&
					StringUtilities.isNotEmptyOrNull(updateBarcodeUIRequest.getCartInfo().getIntendType()) &&
					("NSE".equalsIgnoreCase(updateBarcodeUIRequest.getCartInfo().getIntendType()) || CartConstants.NSE_BYOD.equalsIgnoreCase(updateBarcodeUIRequest.getCartInfo().getIntendType()))){
				if(StringUtilities.isNotEmptyOrNull(data.getPromoMaxCount())){
					int promoCount = StringUtilities.safeParsingInt(data.getPromoMaxCount());
					if(promoCount > 14) {
						return populateErrorForExceedingPromoCode();
					}else{
						redisHelper2.upsertValueInRedis(CartConstants.PROMO_MAX_COUNT, String.valueOf(promoCount+1)).subscribeOn(Schedulers.parallel()).subscribe();
					}
				}else{
					redisHelper2.upsertValueInRedis(CartConstants.PROMO_MAX_COUNT, "1").subscribeOn(Schedulers.parallel()).subscribe();
				}
			}
			if(updateBarcodeUIRequest.isAutoApply()){
				if(StringUtilities.isNotEmptyOrNull(data.getZ1OfferCode())){
					UpdateBarcodeBarcodeId barCodeId = new UpdateBarcodeBarcodeId();
					barCodeId.setBarCodeId(data.getZ1OfferCode());
					List<UpdateBarcodeBarcodeId> barCodeIds = new ArrayList<UpdateBarcodeBarcodeId>();
					barCodeIds.add(barCodeId);
					updateBarcodeUIRequest.getCartInfo().setBarCodeIds(barCodeIds);
					logger.debug("Barcode updated in the request from session");
				} else {
					logger.debug("Redis data is not updated with offerCode value, check personalization pod for more details");
					return returnResponse();
				}
			}
			if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED)) {
				if(StringUtilities.isNotEmptyOrNull(updateBarcodeUIRequest.getCartInfo().getIntendType()) && updateBarcodeUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getCreditAppNum())) {
					updateBarcodeUIRequest.getCartInfo().setCreditAppNum(data.getCreditAppNum());
					updateBarcodeUIRequest.getCartInfo().setCartCreator(data.getCreditAppNum());
				}
			}
			logger.debug(String.format(CartConstants.BPM_LOG_REDIS_ACCOUNT_NUMBER, data.getAccountNumber()));
			if (!isIntendTypeNSE && StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				updateBarcodeUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				updateBarcodeUIRequest.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				updateBarcodeUIRequest.getCartInfo().setCaseId(data.getCaseId());
			if (!isIntendTypeNSE && StringUtilities.isNotEmptyOrNull(data.getMtn()))
				updateBarcodeUIRequest.getCartInfo().setCartCreator(data.getMtn());
			if(updateBarcodeUIRequest.isAutoApply()&& StringUtilities.isNotEmptyOrNull(data.getMtn())){
				updateBarcodeUIRequest.getCartInfo().setCartCreator(data.getMtn());
			}
			if (StringUtilities.isNotEmptyOrNull(data.getCustomerType()))
				updateBarcodeUIRequest.getCartInfo().setCustomerType(data.getCustomerType());;
			
			if(CartConstants.REX.equalsIgnoreCase(data.getIntendType())) {
				updateBarcodeUIRequest.getCartInfo().setIntendType(CartConstants.REX); 
			}
			updateSWBarCodeInRequest(updateBarcodeUIRequest);
			updateSWBarCodeInRequestFromNBX(updateBarcodeUIRequest,data);

			return bpmHelper3.updateBarcode(updateBarcodeUIRequest).flatMap(updateBarcodeUIResponse -> {
				if(updateBarcodeUIRequest != null && updateBarcodeUIRequest.getCartInfo() != null &&
						StringUtilities.isNotEmptyOrNull(updateBarcodeUIRequest.getCartInfo().getIntendType()) &&
						("NSE".equalsIgnoreCase(updateBarcodeUIRequest.getCartInfo().getIntendType()) || CartConstants.NSE_BYOD.equalsIgnoreCase(updateBarcodeUIRequest.getCartInfo().getIntendType()))){
					if(StringUtilities.isNotEmptyOrNull(data.getPromoValidMaxCount())){
						int promoCount = StringUtilities.safeParsingInt(data.getPromoValidMaxCount());
						if(promoCount > 9) {
							return populateErrorForExceedingPromoCode();
						}else{
							redisHelper2.upsertValueInRedis(CartConstants.PROMO_VALID_MAX_COUNT, String.valueOf(promoCount+1)).subscribeOn(Schedulers.parallel()).subscribe();
						}
					}else{
						redisHelper2.upsertValueInRedis(CartConstants.PROMO_VALID_MAX_COUNT, "1").subscribeOn(Schedulers.parallel()).subscribe();
					}
				}
				if (updateBarcodeUIResponse.getServiceBody() != null) {
					if (updateBarcodeUIResponse.getServiceBody().getServiceResponse().getContext() != null) {
						if (updateBarcodeUIResponse.getServiceBody().getServiceResponse().getContext().getCartInfo() != null) {
							CartServiceCartInfo cartInfo = updateBarcodeUIResponse.getServiceBody().getServiceResponse().getContext()
									.getCartInfo();
							if (!CartConstants.BARCODE_UNSUCCESSFUL.equalsIgnoreCase(cartInfo.getStatusMsg())
									&& StringUtilities.isNotEmptyOrNull(updateBarcodeUIRequest.getChannelId())
									&& CartConstants.DIGITAL.equalsIgnoreCase(
									CartUtil.getChannelType(updateBarcodeUIRequest.getChannelId()))
									&& !CartConstants.PROMO_HUB
									.equalsIgnoreCase(updateBarcodeUIRequest.getCartInfo().getProcessStep())) {
								ValidateCartCXPRequest validateRequest = new ValidateCartCXPRequest();
								validateRequest.setCartId(updateBarcodeUIRequest.getCartInfo().getCartId());
								validateRequest.setPageId(CartConstants.CART);
								validateRequest.setRetrieveCurrentFeatures(Boolean.FALSE);
								if (((null != updateBarcodeUIRequest.getCartInfo()
										&& StringUtilities.isNotEmptyOrNull(updateBarcodeUIRequest.getCartInfo().getCartCreator()))
										|| StringUtilities.isNotEmptyOrNull(data.getMtn()))
										&& StringUtilities.isNotEmptyOrNull(data.getVzwRoles())
										&& (data.getVzwRoles().equalsIgnoreCase(CartConstants.MOBILE_SECURE)
										|| data.getVzwRoles().equalsIgnoreCase(CartConstants.ACCOUNT_MEMBER))) {
									String mtn = null == updateBarcodeUIRequest.getCartInfo() ? ""
											: StringUtilities.isNotEmptyOrNull(updateBarcodeUIRequest.getCartInfo().getCartCreator())
											? updateBarcodeUIRequest.getCartInfo().getCartCreator()
											: StringUtilities.isNotEmptyOrNull(data.getMtn()) ? data.getMtn()
											: "";
									List<String> mtnList = new ArrayList<>();
									mtnList.add(mtn);
									validateRequest.setMtnList(mtnList);
								}
								if(sessionBean.isFWADigitalFlow() && featureFlagHelper.isSkipCartValidationOnUpdateCouponForFWA()) {
									return Mono.just(updateBarcodeUIResponse);
								} else {
									return executeCartValidation(data, updateBarcodeUIResponse, validateRequest);
								}
							}
						}

					}

				}
				return Mono.just(updateBarcodeUIResponse);
			});
		});

	}

	/**
	 * Call ValidateCart Graphql from SOE.
	 * @param data
	 * @param updateBarcodeUIResponse
	 * @param validateRequest
	 * @return
	 */

	private Mono<UpdateBarcodeUIResponse> executeCartValidation(CartRedisData data, UpdateBarcodeUIResponse updateBarcodeUIResponse, ValidateCartCXPRequest validateRequest) {
		return cxpHelper.validateCart(validateRequest, null).flatMap(validateCartResponse -> {
			if (validateCartResponse != null) {
				if (validateCartResponse.getErrors() != null)
					updateBarcodeUIResponse.setErrors(validateCartResponse.getErrors());
				else {
					if (null != validateCartResponse.getData() && null != validateCartResponse
							.getData().getValidateCartAndUpdate()) {
						CXPCartVO cart = validateCartResponse.getData()
								.getValidateCartAndUpdate();
						cart = CartUtil.calculateMemberCount(cart, validateRequest.getMtnList(),
								data.getVzwRoles());
						validateCartResponse.getData().setValidateCartAndUpdate(cart);
						readCartHelper.updateBarCodes(data, validateCartResponse);
					}
					updateBarcodeUIResponse.setValidateCartResponse(validateCartResponse);
				}
			}
			return Mono.just(updateBarcodeUIResponse);
		});
	}

	/**
	 * @param request
	 * @return UpdateTradeinTypeUIResponse
	 */
	public Mono<UpdateTradeinTypeUIResponse> updateTradeinType(UpdateTradeinTypeUIRequest request) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			logger.debug(String.format(CartConstants.LOG_REDIS_ACCOUNT_NUMBER, data.getAccountNumber()));
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				request.setCartId(data.getCartId());
			return cxpHelper2.updateTradeinType(request);
		});

	}
	
	/**
	 * @param request
	 * @return UpdateSellerPriceUIResponse
	 */
	public Mono<UpdateSellerPriceUIResponseNew> updateSellerPriceNew(UpdateSellerPriceUIRequestNew request) {
		String channelType = CartUtil.getChannelType(request.getChannelId());
		return redisHelper.getDataFromRedis().flatMap(data -> {
			logger.debug("Calling redis helper with redis account number {}", data.getAccountNumber());
			
			if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED)) {
				if((CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType()) || CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())) && StringUtilities.isNotEmptyOrNull(data.getCreditAppNum())) {
					request.getCartInfo().setCreditAppNum(data.getCreditAppNum());
					request.getCartInfo().setCartCreator(data.getCreditAppNum());
				}
			}
			if ((!CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType()) && !CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())) && StringUtilities.isNotEmptyOrNull(data.getMtn()))
				request.getCartInfo().setCartCreator(data.getMtn());
			if ((!CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType()) && !CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())) && StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				request.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				request.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				request.getCartInfo().setCaseId(data.getCaseId());		
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessingMTN()))
				request.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if ((!CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType()) && !CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())) && StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				request.getCartInfo().setCartCreator(data.getCartCreator());
			
			return bpmHelper3.updateSellerPrice(request);
			});
	}


	/**
	 * @param request
	 * @return AddPlanUIResponse
	 */
	public Mono<AddPlanUIResponse> addPlan(AddPlanUIRequest request) {
		String channelType = CartUtil.getChannelType(request.getChannelId());
		Mono<CartRedisData> rr = redisHelper.getDataFromRedis();
		Mono<String> promoHubSpokeJourneyMono = redisHelper.getPromoHubSpokeJourney();
		Mono<String> oneclickMono = redisHelper.getOneClickCheckoutFlag();		
		Mono<MyOfferETRRedisData> moEtrData = redisHelper.getMyOfferETRDataFromRedis();
		//validate feature flag and set lgpo details from session in AddDeviceUI request based on session value
		Mono<Boolean> isLGPOEnabledMono = featureFlag.isFeatureEnabled(FeatureFlagConstants.AWS_CONFIG_APP_NAME, FeatureFlagConstants.AWS_CONFIG_PROFILE, FeatureFlagConstants.FLAG_NAME_LGPO_OFFER, true);
		return Mono.zip(rr, promoHubSpokeJourneyMono, oneclickMono, moEtrData,isLGPOEnabledMono).flatMap(dataZip -> {
			CartRedisData data = dataZip.getT1();
			String promoHubSpokeJourneyFlag = dataZip.getT2();
			String oneclickFlag = dataZip.getT3();
			MyOfferETRRedisData etrData = dataZip.getT4();
			boolean lgpoEnabled = dataZip.getT5();
			if(request.getCartInfo() != null && request.getCartInfo().isFlexV2()) {
				cartRequestBuilder.buildAddPlanRequest(request, data);
			}
			if (StringUtilities.isNotEmptyOrNull(data.getFlowName())) {
				request.setFlowName(data.getFlowName());
			}
			if(null !=data.getRetrieveCart()){
				request.setRetrieveCart(data.getRetrieveCart());
			}
			if(StringUtilities.isNotEmptyOrNull(data.getDeviceType())) {
				request.getCartInfo().setDeviceType(data.getDeviceType());
			}
			if (StringUtilities.isNotEmptyOrNull(oneclickFlag) && Boolean.parseBoolean(oneclickFlag)
					&& null != request.getCartInfo().getExpressCheckout()
					&& request.getCartInfo().getExpressCheckout()) {
				request.getCartInfo().setPromoHubJourney(Boolean.TRUE);
			}
			if (StringUtilities.isNotEmptyOrNull(promoHubSpokeJourneyFlag)
					&& Boolean.parseBoolean(promoHubSpokeJourneyFlag)) {
				request.getCartInfo().setPromoHubJourney(Boolean.TRUE);
			}
			if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED)) {
				if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()) && request.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getCreditAppNum())) {
					request.getCartInfo().setCreditAppNum(data.getCreditAppNum());
					request.getCartInfo().setCartCreator(data.getCreditAppNum());
				}
			}
			if ((StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()) && !request.getCartInfo().getIntendType().toUpperCase().contains("NSE")) && StringUtilities.isNotEmptyOrNull(data.getAccountNumber())) {
				request.getCartInfo().setAccountNumber(data.getAccountNumber());
				request.setCustomerId(StringUtils.substringBefore(data.getAccountNumber(), "-"));
			}

			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				request.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				request.getCartInfo().setCaseId(data.getCaseId());
			if ((StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()) && !request.getCartInfo().getIntendType().toUpperCase().contains("NSE")) && StringUtilities.isNotEmptyOrNull(data.getMtn()))
				request.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessingMTN()))
				request.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if ((StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()) && !request.getCartInfo().getIntendType().toUpperCase().contains("NSE")) && StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				request.getCartInfo().setCartCreator(data.getCartCreator());
			if (StringUtilities.isNotEmptyOrNull(data.getRpsIntent())) {
				request.getCartInfo().setRpsIntent(data.getRpsIntent());
			}
			if (StringUtilities.isNotEmptyOrNull(data.getUserRole())) {
				request.getCartInfo().setUserRole(data.getUserRole());
			}
			if (StringUtilities.isNotEmptyOrNull(data.getLineActivityType())) {
				request.getCartInfo().setLineActivityType(data.getLineActivityType());
			}
			if (StringUtilities.isNotEmptyOrNull(data.getRelinquishAccountNumber())) {
				request.getCartInfo().setRelinquishAccountNumber(data.getRelinquishAccountNumber());
			}			
			if (StringUtilities.isNotEmptyOrNull(data.getTysLinesCount())) {
				request.getCartInfo().setTysLinesCount(data.getTysLinesCount());
			}
			if(StringUtilities.isNotEmptyOrNull(data.getFlowName())){
				request.setFlowName(data.getFlowName());
			}
			if(CollectionUtilities.isNotEmptyOrNull(data.getPlanTaggingDetails())){
				request.setPlanTaggingDetails(data.getPlanTaggingDetails());
			}
			if(CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId())) && (StringUtilities.isEmptyOrNull(request.getCartInfo().getCaseId()) || StringUtilities.isEmptyOrNull(request.getCartInfo().getCartId()))) {
				AddPlanUIResponse errorResponse = new AddPlanUIResponse();
				errorResponse.setErrors(CartPegaRequestErrorsUtil.validateCartIdAndCaseId(request.getCartInfo()));
				return Mono.just(errorResponse);
			}

			if (CollectionUtilities.isNotEmptyOrNull(etrData.getLines())) {
				etrData.getLines().stream().filter(Objects::nonNull).forEach(line -> {					
					if(request.getData().getLines() != null) {
						for (Lines requestLine : request.getData().getLines()) {
							List<BvoOffers> selectedOffersList = new ArrayList<>();
							if(StringUtilities.isNotEmptyOrNull(requestLine.getMtn()) && requestLine.getMtn().equalsIgnoreCase(line.getMtn())) {
							if (CollectionUtilities.isNotEmptyOrNull(line.getOffers())) {
								line.getOffers().stream().filter(Objects::nonNull).forEach(offer -> {
									if( StringUtilities.isNotEmptyOrNull(offer.getOfferType()) && CartConstants.TRADE.equalsIgnoreCase(offer.getOfferType())) {
										BvoOffers offers = new BvoOffers();
										offers.setId(offer.getSku());
										offers.setSubType(offer.getOfferType());
										selectedOffersList.add(offers);
									}
									if( StringUtilities.isNotEmptyOrNull(offer.getOfferType()) && CartConstants.MULTI_LINE_BOGO.equalsIgnoreCase(offer.getOfferType())) {
										BvoOffers offers = new BvoOffers();
										offers.setId(offer.getSku());
										offers.setSubType(offer.getOfferType());
										selectedOffersList.add(offers);
									}
								});
																														
							}
							}
							if(CollectionUtilities.isNotEmptyOrNull(selectedOffersList))
								requestLine.setSelectedOffers(selectedOffersList);
						}
					}
				});
					
			}

			//ACCEX-683 change
			if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()) && CartConstants.TYS_INTEND_TYPE.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
				if(CollectionUtilities.isNotEmptyOrNull(data.getPromoLines())){
					data.getPromoLines().stream().filter(Objects :: nonNull).forEach(promoLine -> {
						if(request.getData().getLines() != null) {
							for (Lines requestLine : request.getData().getLines()){
								List<SedOfferInfo> sedOfferInfoList = new ArrayList<>();
								if(StringUtilities.isNotEmptyOrNull(requestLine.getMtn()) && requestLine.getMtn().equalsIgnoreCase(promoLine.getMtn())){
									if (CollectionUtilities.isNotEmptyOrNull(promoLine.getSedOfferInfoList())){
										promoLine.getSedOfferInfoList().stream().filter(Objects::nonNull).forEach(offer -> {
											if(StringUtilities.isNotEmptyOrNull(offer.getOfferTypeCd()) && (CartConstants.SP.equalsIgnoreCase(offer.getOfferTypeCd()) || CartConstants.SR.equalsIgnoreCase(offer.getOfferTypeCd()) || CartConstants.ST.equalsIgnoreCase(offer.getOfferTypeCd()) || CartConstants.TR.equalsIgnoreCase(offer.getOfferTypeCd()) || CartConstants.BG.equalsIgnoreCase(offer.getOfferTypeCd()) || CartConstants.BM.equalsIgnoreCase(offer.getOfferTypeCd()))){
												sedOfferInfoList.add(offer);
											}
										});
									}
								}
								if(CollectionUtilities.isNotEmptyOrNull(sedOfferInfoList)){
									requestLine.setOfferInfoList(sedOfferInfoList);
								}
							}
						}
					});
				}
			}
			//LGPO changes based on feature flag
			if(lgpoEnabled) {
				setLGPORedisDataInRequest(data, request);
			}
			return bpmHelperAddPlan.addPlan(request).flatMap(bpmRes -> {
				return featureFlagHelper.fetchAssistedTaggingFeatureFlag().flatMap(taggingEnabled -> {
					try {
						if (taggingEnabled && request.getCartInfo().isFlexV2() && request.getData().getEnableAssistedTagging() != null
								&& Boolean.TRUE.equals(request.getData().getEnableAssistedTagging())) {
							Vzdl vzdl = dlHelper.getVzdlDataForAddPlan(request, bpmRes, data);
							if (vzdl != null) {
								Mono<String> flowName = Mono.just("");
								if (null != data.getRetrieveCart() && vzdl.getPage() != null) {
									flowName = dlHelper.getFlow(request, data.getRetrieveCart());
								}
								return Mono.zip(dlHelper.upsertPlanTaggingValueToRedis(request.getPlanTaggingDetails()), flowName).flatMap(vzdlTuple -> {
									if (StringUtilities.isNotEmptyOrNull(vzdlTuple.getT2()))
										vzdl.getPage().setFlow(vzdlTuple.getT2());
									logger.info("Plan tagging details upserted to redis {}", vzdlTuple.getT1());
									deviceHelper.updateDLDataForAssisted(vzdl);
									return Mono.just(bpmRes);
								});
							}
						}
						if (taggingEnabled && !request.getCartInfo().isFlexV2() && null != request.getRetrieveCart()) {
							return dlHelper.getFlow(request, request.getRetrieveCart()).flatMap(getflow -> {
								if(util.isPegaRespValid(bpmRes)){
									bpmRes.getServiceBody().getServiceResponse().getContext().getCartInfo().setFlow(getflow);
								}

								return Mono.just(bpmRes);
							});
						}
					} catch (Exception e) {
						logger.error("Error on Tagging", e);
					}
					return Mono.just(bpmRes);
				});
			});
		});
	}

	/**
	 * @param request
	 * @return AddFeaturesPEGAResponse
	 */
	public Mono<AddFeaturesUIResponse> addFeatures(AddFeaturesUIRequest request) {
		String channelType = CartUtil.getChannelType(request.getChannelId());
		Mono<CartRedisData> rr = redisHelper.getDataFromRedis();
		Mono<AddFeaturesUIRequest> fetchedData = redisHelper.getAddFeaturesRequest();
		Mono<String> promoHubSpokeJourneyMono = redisHelper.getPromoHubSpokeJourney();

		return rr.flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED)) {
				if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()) && request.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getCreditAppNum())) {
					request.getCartInfo().setCreditAppNum(data.getCreditAppNum());
					request.getCartInfo().setCartCreator(data.getCreditAppNum());
				}
			}
			if((StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType()) ||  CartConstants.UNDEFINED.equalsIgnoreCase(request.getCartInfo().getIntendType())) && StringUtilities.isNotEmptyOrNull(data.getIntendType())){
				request.getCartInfo().setIntendType(data.getIntendType());
			}
			if(StringUtilities.isNotEmptyOrNull(data.getFlowName())){
				request.setFlowName(data.getFlowName());
			}
			if (!CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType()) && StringUtilities.isNotEmptyOrNull(data.getAccountNumber())){
				request.getCartInfo().setAccountNumber(data.getAccountNumber());
				request.setCustomerId(StringUtils.substringBefore(data.getAccountNumber(), "-"));
			}
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				request.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				request.getCartInfo().setCaseId(data.getCaseId());
			if (!CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType()) && StringUtilities.isNotEmptyOrNull(data.getMtn())){
				request.getCartInfo().setCartCreator(data.getMtn());
				request.setMtn(data.getMtn());
			}
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessingMTN()))
				request.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (!CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType()) && StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				request.getCartInfo().setCartCreator(data.getCartCreator());
			if (StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				request.getCartInfo().setIsfiveGUpSellSelected(data.getIsfiveGUpSellSelected());
			if (StringUtilities.isNotEmptyOrNull(data.getRpsIntent())) {
				request.getCartInfo().setRpsIntent(data.getRpsIntent());
			}
			if (StringUtilities.isNotEmptyOrNull(data.getVzwRoles())) {
				request.getCartInfo().setAmRole(data.getVzwRoles());
			}
			if (StringUtilities.isNotEmptyOrNull(data.getUserRole())) {
				request.getCartInfo().setUserRole(data.getUserRole());
			}
			if (StringUtilities.isNotEmptyOrNull(data.getLineActivityType())) {
				request.getCartInfo().setLineActivityType(data.getLineActivityType());
			}
			
			if (StringUtilities.isNotEmptyOrNull(data.getRelinquishAccountNumber())) {
				request.getCartInfo().setRelinquishAccountNumber(data.getRelinquishAccountNumber());
			}
			
			if (StringUtilities.isNotEmptyOrNull(data.getTysLinesCount())) {
				request.getCartInfo().setTysLinesCount(data.getTysLinesCount());
			}
			//New code changes depletion type
			if (StringUtilities.isNotEmptyOrNull(data.getDepletionType())) {
				request.getCartInfo().setDepletionType(data.getDepletionType());
			}
			
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN()) && null != request.getData()
					&& null != request.getData().getLines() && request.getData().getLines().length>0
					&& StringUtilities.isEmptyOrNull(request.getData().getLines()[0].getMtn()))
				request.getData().getLines()[0].setMtn(data.getProcessingMTN());
			if(CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId())) && (StringUtilities.isEmptyOrNull(request.getCartInfo().getCaseId()) || StringUtilities.isEmptyOrNull(request.getCartInfo().getCartId()))) {
				AddFeaturesUIResponse errorResponse = new AddFeaturesUIResponse();
				errorResponse.setErrors(CartPegaRequestErrorsUtil.validateCartIdAndCaseId(request.getCartInfo()));
				return Mono.just(errorResponse);
			}
			if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getClientAppName()) && CartConstants.CHANNEL_ID_NUMBERLINK.equalsIgnoreCase(request.getCartInfo().getClientAppName()) && StringUtilities.isNotEmptyOrNull(data.getIntent())) {
					request.getCartInfo().setIntent(data.getIntent());
			}
			return Mono.zip(fetchedData, promoHubSpokeJourneyMono).flatMap(combinedData -> {
				AddFeaturesUIRequest featuresData = combinedData.getT1();
				String promoHubSpokeJourneyFlag = combinedData.getT2();
				if (StringUtilities.isNotEmptyOrNull(promoHubSpokeJourneyFlag)
						&& Boolean.parseBoolean(promoHubSpokeJourneyFlag)) {
					request.getCartInfo().setPromoHubJourney(Boolean.TRUE);
				}
				if (!isRequestDataAvailable(request) && null != featuresData.getData() && (null == request.getData()
						|| (null == request.getData().getAccount() && null == request.getData().getLines()))) {
					request.setData(featuresData.getData());
				}

				ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddFeaturesRequestErrors(request);
				if (errors != null && errors.getErrors() != null) {
					AddFeaturesUIResponse errorResponse = new AddFeaturesUIResponse();
					errorResponse.setErrors(errors.getErrors());

					return Mono.just(errorResponse);
				}

				String storeLocationState = data.getStoreLocationState();
				String customerAddressState = data.getCustomerAddressState();

				List<String> warningMessage = new ArrayList<String>();

				if (StringUtilities.isNotEmptyOrNull(storeLocationState)
						&& StringUtilities.isNotEmptyOrNull(customerAddressState)
						&& StringUtilities.isNotEmptyOrNull(data.getLineLevelDigitalSecureSubscriptionCount())) {

					int linelevelDigitalSecureSubsCount = Integer
							.valueOf(data.getLineLevelDigitalSecureSubscriptionCount());

					// Protecting Digital Secure for 3 or more lines at line level
					if (request != null && request.getData() != null && request.getData().getLines() != null) {
						for (LineFeature lineFeature : request.getData().getLines()) {
							if (CartConstants.NY.equalsIgnoreCase(storeLocationState)
									&& !CartConstants.NY.equalsIgnoreCase(customerAddressState)) {
								if (lineFeature != null && lineFeature.getMcsSubscription() != null
										&& CollectionUtilities
										.isNotEmptyOrNull(lineFeature.getMcsSubscription().getAdd())) {
									lineFeature.getMcsSubscription().getAdd().stream()
											.filter(mcsSubscription -> mcsSubscription != null
													&& mcsSubscription.getItemId() != null
													&& mcsSubscription.getItemId().equals(
													CartConstants.DIGITAL_SECURE_SUBSCRIPTION_ITEM_ID_LL)
													&& linelevelDigitalSecureSubsCount == 2)
											.forEach(mcsSubscription -> {
												warningMessage.add(
														CartConstants.PROTECTING_DIGITAL_SECURE_MORE_THAN_2_LINES_OUTSIDE_NY);
											});
								}
							}

							if (CartConstants.NY.equalsIgnoreCase(customerAddressState)) {
								if (lineFeature != null && lineFeature.getMcsSubscription() != null
										&& CollectionUtilities
										.isNotEmptyOrNull(lineFeature.getMcsSubscription().getAdd())) {
									lineFeature.getMcsSubscription().getAdd().stream()
											.filter(mcsSubscription -> mcsSubscription != null
													&& mcsSubscription.getItemId() != null
													&& mcsSubscription.getItemId().equals(
													CartConstants.DIGITAL_SECURE_SUBSCRIPTION_ITEM_ID_LL)
													&& linelevelDigitalSecureSubsCount == 2)
											.forEach(mcsSubscription -> {
												warningMessage.add(
														CartConstants.PROTECTING_DIGITAL_SECURE_MORE_THAN_2_LINES_NY_CUSTOMER);
											});
								}
							}
						}
					}
				}

				CartWarning[] warnings = new CartWarning[warningMessage.size()];
				if (CollectionUtilities.isEmptyOrNull(warningMessage)) {
					if (StringUtilities.isNotEmptyOrNull(storeLocationState)
							&& StringUtilities.isNotEmptyOrNull(customerAddressState)) {
						if (CartConstants.NY.equalsIgnoreCase(storeLocationState)
								&& !CartConstants.NY.equalsIgnoreCase(customerAddressState)) {
							if (request != null && request.getData() != null && request.getData().getLines() != null) {
								for (LineFeature lineFeature : request.getData().getLines()) {
									// line level Digital Secure Subscription
									if (lineFeature != null && lineFeature.getMcsSubscription() != null
											&& CollectionUtilities
											.isNotEmptyOrNull(lineFeature.getMcsSubscription().getAdd())) {
										lineFeature.getMcsSubscription().getAdd().stream()
												.filter(addSubscription -> addSubscription != null
														&& addSubscription.getItemId() != null
														&& addSubscription.getItemId().equals(
														CartConstants.DIGITAL_SECURE_SUBSCRIPTION_ITEM_ID_LL))
												.forEach(addSubscription -> {
													warningMessage.add(CartConstants.DIGITAL_SECURE_LL);
												});
									}
								}
							}

							if (null != request && null != request.getData() && null != request.getData().getAccount()
									&& request.getData().getAccount().getMcsSubscription() != null
									&& CollectionUtilities.isNotEmptyOrNull(
									request.getData().getAccount().getMcsSubscription().getAdd())) {

								request.getData().getAccount().getMcsSubscription().getAdd().stream()
										.forEach(mcsSubscription -> {
											if (mcsSubscription != null && mcsSubscription.getItemId() != null
													&& mcsSubscription.getItemId().equals(
													CartConstants.DIGITAL_SECURE_SUBSCRIPTION_ITEM_ID_AL)) {
												warningMessage.add(CartConstants.DIGITAL_SECURE_AL);
											}
										});
							}
						}
					}

					Mono<AddFeaturesUIResponse> addFeatRes = bpmHelper2.addFeatures(request);
					CartWarning[] warnings1 = new CartWarning[warningMessage.size()];
					return addFeatRes.flatMap(res -> {
						if (res != null) {
							if (CollectionUtilities.isNotEmptyOrNull(warningMessage)) {
								for (int i = 0; i < warningMessage.size(); i++) {
									warnings1[i] = new CartWarning();
									warnings1[i].setMessage(warningMessage.get(i));
								}
							}
							res.setWarnings(warnings1);

							// update DigitalSecure count into Redis after adding the DSsubscription
							if (data.getLineLevelDigitalSecureSubscriptionCount() != null) {
								Mono<Boolean> redisMono = redisHelper2
										.updateLinelevelDigitalSecureSubscriptionCountintoRedis(
												Integer.valueOf(data.getLineLevelDigitalSecureSubscriptionCount()) + 1);
								return redisMono.flatMap(updated -> {
									if (updated) {
										return Mono.just(res);
									}
									return Mono.just(res);
								});

							}
						}
						return Mono.just(res);
					});
				} else {
					AddFeaturesUIResponse addFeatureUIRes = new AddFeaturesUIResponse();
					if (CollectionUtilities.isNotEmptyOrNull(warningMessage)) {
						for (int i = 0; i < warningMessage.size(); i++) {
							warnings[i] = new CartWarning();
							warnings[i].setMessage(warningMessage.get(i));
						}
					}
					addFeatureUIRes.setWarnings(warnings);
					return Mono.just(addFeatureUIRes);
				}
			});
		});
	}

		private boolean isRequestDataAvailable(AddFeaturesUIRequest request) {
			return request.getVzHPfeatureforAcc()!=null && request.getVzHPfeatureforAcc()
					&& (null != request.getData() || (null != request.getData().getAccount() && null != request.getData().getLines()));
		}

	/**
	 * @param removeLinesUIRequest
	 * @return RemoveLinesUIResponse
	 */
	public Mono<RemoveLinesUIResponse> removeLines(RemoveLinesUIRequest removeLinesUIRequest) {
		String channelType = CartUtil.getChannelType(removeLinesUIRequest.getChannelId());
		Mono<CartRedisData> rr = redisHelper.getDataFromRedis();
		Mono<BVPRedisData> bvpRedisData = redisHelper.getBVPDataFromRedis();
		Mono<String> loggedInUser = redisHelper2.getLoggedInUser();
		return rr.flatMap(data -> {

			if(removeLinesUIRequest.getCartInfo() != null && removeLinesUIRequest.getCartInfo().isFlexV2()) {
				cartRequestBuilder.buildRemoveLinesRequest(removeLinesUIRequest, data);
				logger.info("Update Cart Helper : removeLines ", removeLinesUIRequest);
			}
            if(StringUtilities.isEmptyOrNull(removeLinesUIRequest.getCartInfo().getIntendType()) && StringUtilities.isNotEmptyOrNull(data.getIntendType())){
            	removeLinesUIRequest.getCartInfo().setIntendType(data.getIntendType());
            }
			if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED)) {
				if(StringUtilities.isNotEmptyOrNull(removeLinesUIRequest.getCartInfo().getIntendType()) && removeLinesUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getCreditAppNum())) {
					removeLinesUIRequest.getCartInfo().setCreditAppNum(data.getCreditAppNum());
					removeLinesUIRequest.getCartInfo().setCartCreator(data.getCreditAppNum());
				}
			}
			if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(removeLinesUIRequest.getChannelId()))
					&& CartConstants.NSE.equalsIgnoreCase(removeLinesUIRequest.getCartInfo().getIntendType())) {
				if(StringUtilities.isNotEmptyOrNull(data.getMtnFlow())) {
					removeLinesUIRequest.getCartInfo().setMtnFlow(data.getMtnFlow());
				}
			}
			if (StringUtilities.isNotEmptyOrNull(removeLinesUIRequest.getCartInfo().getIntendType()) && !removeLinesUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				removeLinesUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				removeLinesUIRequest.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				removeLinesUIRequest.getCartInfo().setCaseId(data.getCaseId());
			if (StringUtilities.isNotEmptyOrNull(removeLinesUIRequest.getCartInfo().getIntendType()) && !removeLinesUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getMtn()))
				removeLinesUIRequest.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(removeLinesUIRequest.getCartInfo().getProcessingMTN()))
				removeLinesUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (StringUtilities.isNotEmptyOrNull(removeLinesUIRequest.getCartInfo().getIntendType()) && !removeLinesUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				removeLinesUIRequest.getCartInfo().setCartCreator(data.getCartCreator());
            if(StringUtilities.isEmptyOrNull(removeLinesUIRequest.getCartInfo().getCartCreator()) && StringUtilities.isNotEmptyOrNull(data.getMtn()))
            	removeLinesUIRequest.getCartInfo().setCartCreator(data.getMtn());
			if(CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(removeLinesUIRequest.getChannelId())) && (StringUtilities.isEmptyOrNull(removeLinesUIRequest.getCartInfo().getCaseId()) || StringUtilities.isEmptyOrNull(removeLinesUIRequest.getCartInfo().getCartId()))) {
				RemoveLinesUIResponse errorResponse = new RemoveLinesUIResponse();
				errorResponse.setErrors(CartPegaRequestErrorsUtil.validateCartIdAndCaseId(removeLinesUIRequest.getCartInfo()));
				return Mono.just(errorResponse);
			}

			return bvpRedisData.flatMap(bvpData -> {
				return loggedInUser.flatMap(loggedInUserData -> {	
				List<BVPLine> bvpLines = Optional.ofNullable(bvpData.getLines()).orElse(new ArrayList<BVPLine>());
				bvpLines.stream().filter(Objects::nonNull).forEach(bvpLine -> {
					Lines[] requestLines = Optional.ofNullable(removeLinesUIRequest.getData().getLines()).orElse(new Lines[1]);
					for (Lines requestLine : requestLines) {
						if (StringUtilities.isNotEmptyOrNull(bvpLine.getMtn())
								&& StringUtilities.isNotEmptyOrNull(requestLine.getMtn())
								&& bvpLine.getMtn().equalsIgnoreCase(requestLine.getMtn())) {
							Optional.ofNullable(bvpLine).map(BVPLine::getGetBestValuePromotions)
									.ifPresent(getBestValuePromotions -> {
										getBestValuePromotions.getBestValueOffers().stream().filter(Objects::nonNull)
												.forEach(bvOffer -> {
													if (CartConstants.BVP_REJECTED
															.equalsIgnoreCase(bvOffer.getDispositionOptionId())) {
													// rtd call
														NBXFeedbackRequest nbxRequest = nbxService
																.formatNbxFeedbackRequest(bvpLine,
																		removeLinesUIRequest.getCartInfo().getAccountNumber(),loggedInUserData);
														nbxService.nbxFeedbackCall(nbxRequest)
																.subscribeOn(Schedulers.parallel()).subscribe(nbx -> {
															logger.info(
																	"NBX Request is {} & the response is {}",
																	nbxRequest, nbx);
														});
													}
												});
									});
						}
					}
				});

					if(removeLinesUIRequest.getCartInfo().isFlexV2()
							&& StringUtilities.isNotEmptyOrNull(removeLinesUIRequest.getData().getIsDeassignEnabledonRemove())
					&& CartConstants.TRUE_FLAG.equalsIgnoreCase(removeLinesUIRequest.getData().getIsDeassignEnabledonRemove())){
						return deassignMtnUIResponseMono(removeLinesUIRequest, data).flatMap(deassignResp -> {
							logger.info("Fetch Input details", deassignResp);
							return getRemoveLinesMono(removeLinesUIRequest, data);
						});
					}
					else {
						return getRemoveLinesMono(removeLinesUIRequest, data);
					}
				});

		});
		});
	}

	private Mono<RemoveLinesUIResponse> getRemoveLinesMono(RemoveLinesUIRequest removeLinesUIRequest, CartRedisData data) {
		return bpmHelper2.removeLines(removeLinesUIRequest).flatMap(removeLinesUIResponse -> {
			if ((CartConstants.DIGITAL
					.equalsIgnoreCase(CartUtil.getChannelType(removeLinesUIRequest.getChannelId()))
					&& StringUtilities.isNotEmptyOrNull(removeLinesUIRequest.getCartInfo().getProcessStep())
					&& !CartConstants.MTN_SELECTION_PAGE
					.equalsIgnoreCase(removeLinesUIRequest.getCartInfo().getProcessStep()))
					|| CartConstants.ASSISTED.equalsIgnoreCase(removeLinesUIRequest.getChannelId()))
				redisHelper.deleteAddDeviceDataFromRedis(CartConstants.ADD_DEVICE_REQUEST);

			setRequestAssistedLandingMfeTagging(removeLinesUIRequest);
			try {
				if (removeLinesUIRequest.getCartInfo().isFlexV2() && removeLinesUIRequest.getData().getEnableAssistedTagging()) {
					Vzdl vzdl = dlHelper.getVzdlDataForRemoveDevice(removeLinesUIRequest, removeLinesUIResponse, data);
					if (vzdl != null) {
						logger.info("VZDL object: {}", vzdl);
						deviceHelper.updateDLDataForAssisted(vzdl);
					}
				}
			} catch (Exception e) {
				logger.error("Error on Tagging", e);
			}
			if (CollectionUtilities.isEmptyOrNull(removeLinesUIResponse.getErrors())) {
				String intendType = removeLinesUIRequest.getCartInfo().getIntendType();
				if (StringUtilities.isEmptyOrNull(intendType) || CartConstants.EUP.equalsIgnoreCase(intendType)
						|| CartConstants.AAL.equalsIgnoreCase(intendType)
						|| CartConstants.BYOD.equalsIgnoreCase(intendType)
						|| CartConstants.NSE_BYOD.equalsIgnoreCase(intendType)
						|| CartConstants.NSE.equalsIgnoreCase(intendType)) {
					int numOfLines = removeLinesUIRequest.getData().getLines().length;
					if (StringUtilities.isNotEmptyOrNull(data.getCartCount())) {
						String cartCount = String.valueOf(Integer.parseInt(data.getCartCount()) - numOfLines);
						removeLinesUIResponse.setCartCount(cartCount);
					}
				}
			}

			if(StringUtilities.isEmptyOrNull(removeLinesUIRequest.getCartInfo().getProcessAction())
					&& removeLinesUIRequest.getCartInfo().isFlexV2() && null != data && null != data.getDualNumber()) {
				removeDualNumberFromSession(removeLinesUIRequest, data);
			}

			if (removeLinesUIResponse.getErrors() == null
					&& CartConstants.DIGITAL
					.equalsIgnoreCase(CartUtil.getChannelType(removeLinesUIRequest.getChannelId()))
					&& !CartConstants.PROMO_HUB.equalsIgnoreCase(removeLinesUIRequest.getCartInfo().getProcessStep())) {
				ValidateCartCXPRequest validateRequest = new ValidateCartCXPRequest();
				if (removeLinesUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE")) {
					Map<String, String> meta = new HashMap<>();
					meta.put("type", CartConstants.NEWCUSTOMER);
					validateRequest.setMeta(meta);
				}
				validateRequest.setCartId(removeLinesUIRequest.getCartInfo().getCartId());
				validateRequest.setPageId(CartConstants.CART);
				validateRequest.setRetrieveCurrentFeatures(Boolean.FALSE);
				if (((null != removeLinesUIRequest.getCartInfo()
						&& StringUtilities.isNotEmptyOrNull(removeLinesUIRequest.getCartInfo().getCartCreator()))
						|| StringUtilities.isNotEmptyOrNull(data.getMtn()))
						&& StringUtilities.isNotEmptyOrNull(data.getVzwRoles())
						&& (data.getVzwRoles().equalsIgnoreCase(CartConstants.MOBILE_SECURE)
						|| data.getVzwRoles().equalsIgnoreCase(CartConstants.ACCOUNT_MEMBER))) {
					String mtn = null == removeLinesUIRequest.getCartInfo() ? ""
							: StringUtilities.isNotEmptyOrNull(removeLinesUIRequest.getCartInfo().getCartCreator())
							? removeLinesUIRequest.getCartInfo().getCartCreator()
							: StringUtilities.isNotEmptyOrNull(data.getMtn()) ? data.getMtn() : "";
					List<String> mtnList = new ArrayList<>();
					mtnList.add(mtn);
					validateRequest.setMtnList(mtnList);
				}
				return cxpHelper.validateCart(validateRequest, null).flatMap(validateCartResponse -> {
					if (validateCartResponse != null) {
						if (validateCartResponse.getErrors() != null)
							removeLinesUIResponse.setErrors(validateCartResponse.getErrors());
						else {
							if (null != validateCartResponse.getData()
									&& null != validateCartResponse.getData().getValidateCartAndUpdate()) {
								CXPCartVO cart = validateCartResponse.getData().getValidateCartAndUpdate();
								cart = CartUtil.calculateMemberCount(cart, validateRequest.getMtnList(),
										data.getVzwRoles());
								validateCartResponse.getData().setValidateCartAndUpdate(cart);
							}
							removeLinesUIResponse.setValidateCartResponse(validateCartResponse);
						}
					}
					return Mono.just(removeLinesUIResponse);
				});
			}
			return Mono.just(removeLinesUIResponse);
		});
	}

	public void setRequestAssistedLandingMfeTagging(RemoveLinesUIRequest removeLinesUIRequest){
		boolean isAssistedLPMfeFFlag = featureFlagHelper.isAssistedLPMFETaggingFeatureFlag();
		if(StringUtilities.isNotEmptyOrNull(removeLinesUIRequest.getChannelId())&&CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(removeLinesUIRequest.getChannelId())) && isAssistedLPMfeFFlag){
			if(StringUtilities.isEmptyOrNull(removeLinesUIRequest.getCartInfo().getProcessAction())){
				removeLinesUIRequest.getCartInfo().setProcessAction(CartConstants.REMOVE_DEVICE);
			}

			removeLinesUIRequest.getData().setEnableAssistedTagging(true);
		}
	}
	public Mono<DeassignMtnUIResponse> deassignMtnUIResponseMono(RemoveLinesUIRequest removeLinesUIRequest,CartRedisData data) {
		DeassignMtnUIRequest deassignMtnUIRequest = new DeassignMtnUIRequest();

		String channelType = CartUtil.getChannelType(deassignMtnUIRequest.getChannelId());

		CartInfo cartInfo = new CartInfo();
		if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
			cartInfo.setAccountNumber(data.getAccountNumber());
		if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
			cartInfo.setCartId(data.getCartId());
		if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
			cartInfo.setCaseId(data.getCaseId());
		if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN()))
			cartInfo.setProcessingMTN(data.getProcessingMTN());
		cartInfo.setIntendType(data.getIntendType());
		cartInfo.setFlexV2(removeLinesUIRequest.getCartInfo().isFlexV2());
		cartInfo.setClientAppName(removeLinesUIRequest.getChannelId());
		cartInfo.setCartCreator(data.getCartCreator());
		cartInfo.setProcessStep(data.getProcessStep());
		deassignMtnUIRequest.setCartInfo(cartInfo);

		deassignMtnUIRequest.setChannelId(removeLinesUIRequest.getChannelId());
		deassignMtnUIRequest.setData(new DeassignMtnData());
		if(null != data.getRetrieveCart() && null != data.getRetrieveCart().getCart()
				&&	null != data.getRetrieveCart().getCart().getLineDetails()
				&& null != data.getRetrieveCart().getCart().getLineDetails().getLineInfo()
				&& data.getRetrieveCart().getCart().getLineDetails().getLineInfo().length>0) {
			List<Lines> lines = new ArrayList<>();

			Arrays.stream(data.getRetrieveCart().getCart().getLineDetails().getLineInfo())
					.filter(lineInfo -> null != lineInfo && StringUtilities.isNotEmptyOrNull(lineInfo.getAssignMTNIndicator()) && "Y".equalsIgnoreCase(lineInfo.getAssignMTNIndicator())
							&& null != lineInfo.getMtnDetails() && StringUtilities.isEmptyOrNull(lineInfo.getMtnDetails().getMtnType())
							&& StringUtilities.isNotEmptyOrNull(lineInfo.getMtnDetails().getLineNumber())
							&& StringUtilities.isNotEmptyOrNull(lineInfo.getMtnDetails().getMobileNumber()) && !StringUtils.isNumeric(removeLinesUIRequest.getData().getLines()[0].getMtn())
							&& lineInfo.getMtnDetails().getLineNumber().equalsIgnoreCase(removeLinesUIRequest.getData().getLines()[0].getMtn())
					).findFirst().ifPresent(deassignLine -> {
						Lines line = new Lines();
						line.setMtn(deassignLine.getMtnDetails().getMobileNumber());
						lines.add(line);
					});
			deassignMtnUIRequest.getData().setLines(lines);

		}

		return CollectionUtilities.isNotEmptyOrNull(deassignMtnUIRequest.getData().getLines()) ?
				bpmHelper2.deassignMtn(deassignMtnUIRequest) : Mono.just(new DeassignMtnUIResponse());

	}


	/**
	 *
	 * @param request
	 * @return InitiateCheckoutUIResponse
	 *
	 */
	public Mono<InitiateCheckoutUIResponse> validateOrder(InitiateCheckoutUIRequest request) {
		AtomicInteger creditFailureCount = new AtomicInteger(0);
		return redisHelper.getDataFromRedis().flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				request.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				request.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				request.getCartInfo().setCaseId(data.getCaseId());
			if (StringUtilities.isNotEmptyOrNull(data.getMtn()))
				request.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessingMTN()))
				request.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				request.getCartInfo().setCartCreator(data.getCartCreator());
			if (CartConstants.EUP_5G_REPAIR.equalsIgnoreCase(data.getIntendType())) {
				request.getCartInfo().setIntendType("EUP_5G");
			}
				return bpmHelper2.validateOrder(request).flatMap(response -> {
				if(enableMHOffers&&StringUtilities.isNotEmptyOrNull(data.getCustomerFiosPlanType())) {
					response.setCustomerFiosPlanType(data.getCustomerFiosPlanType().equalsIgnoreCase("Y") ? "gig" : data.getCustomerFiosPlanType().equalsIgnoreCase("N") ? "nonGig" : null);
				}
				return redisHelper.readCreditException().flatMap(creditContent -> {
					return redisHelper.isDigitalHomeFlow().flatMap(is5GFlow -> {
						if(is5GFlow) {
							logCustomFieldsCreditHold(response);
							if(data.getCreditCheckFailedCount() > 0) {
								creditFailureCount.set(data.getCreditCheckFailedCount());
							}
						}
						logger.info(String.format(CartConstants.LOG_CREDIT_CONTENT, creditContent.toString()));
						if (null == creditContent || (null != creditContent
								&& CollectionUtilities.isEmptyOrNull(creditContent.getCreditHold()))) {
							if(CartUtil.isDigital(request.getChannelId()) && enableSecurityForCart) {
										removeSensitiveInfoForValidateOrder(response);
									}		
							return Mono.just(response);
						}
						logger.info("Credit Data Availabe in redis for 5g");
						Optional.ofNullable(response.getServiceBody()).map(InitiateCheckoutServiceBody::getServiceResponse)
								.map(InitiateCheckoutServiceResponse::getContext).ifPresent(context -> {
							if (null != context.getContextInfo()
									&& StringUtilities.isNotEmptyOrNull(context.getContextInfo().getProcessStep())
									&& CartConstants.CONFIRMATION
									.equalsIgnoreCase(context.getContextInfo().getProcessStep())) {
								redisHelper.deleteCartIdAndCaseIdFromRedis();
							}
						});
						Optional.ofNullable(response.getServiceBody()).map(InitiateCheckoutServiceBody::getServiceResponse)
								.map(InitiateCheckoutServiceResponse::getContext)
								.map(InitiateCheckoutContext::getValidateOrder).ifPresent(validateOrder -> {
							if (StringUtilities.isNotEmptyOrNull(validateOrder.getProgramEligibilityStatus())) {
								if (validateOrder.getProgramEligibilityStatus()
										.equalsIgnoreCase(CartConstants.DP_CHANGED))
									validateOrder.setErrorMessage(CartConstants.DP_CHANGED_MSG);
								else if (validateOrder.getProgramEligibilityStatus()
										.equalsIgnoreCase(CartConstants.DP_INELIGIBLE))
									validateOrder.setErrorMessage(CartConstants.DP_INELIGIBLE_MSG);
							}
						});
						Optional.ofNullable(response.getServiceBody()).map(InitiateCheckoutServiceBody::getServiceResponse)
								.map(InitiateCheckoutServiceResponse::getContext)
								.map(InitiateCheckoutContext::getValidateOrder).map(ValidateOrder::getOrderDetails)
								.ifPresent(orderDetails -> {
									List<AEMCreditExceptionResponse> aemRespList = creditContent.getCreditHold();
									List<OrderDetail> newDetail = new ArrayList<>();
									orderDetails.stream().filter(Objects::nonNull).forEach(orderDetail -> {
										String creditStatusReason = orderDetail.getCreditStatusReason();
										if (StringUtilities.isNotEmptyOrNull(creditStatusReason)
												&& creditStatusReason.length() >= 2) {
											String reasonCode = creditStatusReason.substring(0, 2);
											aemRespList.stream().filter(Objects::nonNull).forEach(aemResp -> {
												if (aemResp.getReasonCode() != null
														&& Arrays.asList(aemResp.getReasonCode()).contains(reasonCode)) {
													if(is5GFlow) {
														populateCreditCheckAttempt(aemResp, creditFailureCount);
													}
													orderDetail.setCreditHoldContent(aemResp);
												}
											});
											util.setDefaultCreditHoldContentForFailedOrderStatus(orderDetail,aemRespList,reasonCode);
											newDetail.add(orderDetail);
										}
									});
									if(CollectionUtilities.isNotEmptyOrNull(newDetail))
										response.getServiceBody().getServiceResponse().getContext().getValidateOrder()
												.setOrderDetails(newDetail);

								});
						hideSensitiveOrderDetail(response);
						return redisHelper2.upsertCreditCheckFailureCountIntoRedis(creditFailureCount.get(), response).
								flatMap(res -> {
									if(CartUtil.isDigital(request.getChannelId()) && enableSecurityForCart) {
										removeSensitiveInfoForValidateOrder(response);
									}
									return Mono.just(response);
								});
					});
				});
			});
		});
	}

	private void logCustomFieldsCreditHold(InitiateCheckoutUIResponse response) {
		Map<String, String> creditLogData = new HashMap<>(2);
		Map<String, String> fields = new HashMap<>();
		Optional.ofNullable(response.getServiceBody()).map(InitiateCheckoutServiceBody::getServiceResponse)
				.map(InitiateCheckoutServiceResponse::getContext)
				.map(InitiateCheckoutContext::getValidateOrder).map(ValidateOrder::getOrderDetails)
				.ifPresent(orderDetails -> {
					orderDetails.stream().filter(Objects::nonNull).forEach(creditApplication -> {
						creditLogData.put("creditStatus", creditApplication.getCreditApprovalStatus());
						String statusReason = creditApplication.getCreditStatusReason();
						if(StringUtilities.isNotEmptyOrNull(statusReason)) {
							creditLogData.put("creditReason", statusReason);
							creditLogData.put("creditCode", creditApplication.getCreditApprovalStatus() + "|" +
									(statusReason.length() > 3 ? statusReason.substring(0,2) : statusReason));
						}
						try {
							fields.put("creditInfo", JacksonMapperFactory.defaultWriter().writeValueAsString(creditLogData));
						} catch (JsonProcessingException e) {
							logger.info("error during creditHold kibana fields update");
						}
					});
				});
	}

	private void hideSensitiveOrderDetail(InitiateCheckoutUIResponse response) {
		if(response != null && response.getServiceBody() != null && response.getServiceBody().getServiceResponse() != null
			&& response.getServiceBody().getServiceResponse().getContext() != null && response.getServiceBody().getServiceResponse().getContext().getCustomerInfo() != null
			&& StringUtilities.isNotEmptyOrNull(response.getServiceBody().getServiceResponse().getContext().getCustomerInfo().getCustomerType())
			&& response.getServiceBody().getServiceResponse().getContext().getCustomerInfo().getCustomerType().equalsIgnoreCase("N")
			&& response.getServiceBody().getServiceResponse().getContext().getValidateOrder() != null
			&& !response.getServiceBody().getServiceResponse().getContext().getValidateOrder().getOrderDetails().isEmpty()){
				response.getServiceBody().getServiceResponse().getContext().getValidateOrder().getOrderDetails().forEach(orderDetail -> {
					orderDetail.setDigitalOrderId(null);
					orderDetail.setOrderNumber(null);
				});
		}
	}

	private void populateCreditCheckAttempt(AEMCreditExceptionResponse aemRes, AtomicInteger sessionCount){
		int finalCreditFailureCount = sessionCount.incrementAndGet();
		logger.info(String.format(CartConstants.LOG_CREDIT_FAILED, finalCreditFailureCount));
		if(finalCreditFailureCount >= creditCheckMaxAttemptAllowed) {
			aemRes.setPrimaryBtnLabel(StringUtils.EMPTY);
			aemRes.setPrimaryBtnUrl(StringUtils.EMPTY);
			aemRes.setCancelOrderBtnLabel("Cancel");
			aemRes.setCancelOrderBtnLabel("/5g/home");
			aemRes.setContent_D_Screen_1(creditErrorForMaxAttempt);
			aemRes.setContent_M_Screen_1(creditErrorForMaxAttempt);
		}
	}

	/**
	 *
	 * @param request
	 * @return AddBuyoutUIResponse
	 *
	 */
	public Mono<AddBuyoutUIResponse> addBuyout(AddBuyoutUIRequest request) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				request.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				request.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				request.getCartInfo().setCaseId(data.getCaseId());
			if (StringUtilities.isNotEmptyOrNull(data.getMtn()))
				request.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessingMTN()))
				request.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				request.getCartInfo().setCartCreator(data.getCartCreator());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN()) && null != request.getData()
					&& null != request.getData().getLines()
					&& StringUtilities.isEmptyOrNull(request.getData().getLines()[0].getMtn()))
				request.getData().getLines()[0].setMtn(data.getProcessingMTN());
			return bpmHelper2.addBuyout(request);
		});
	}

	/**
	 *
	 * @param request
	 * @return UpdateEdgeupUIResponse
	 *
	 */
	public Mono<UpdateEdgeupUIResponse> addEdgeup(UpdateEdgeupUIRequest request) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				request.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				request.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				request.getCartInfo().setCaseId(data.getCaseId());
			if (StringUtilities.isNotEmptyOrNull(data.getMtn()))
				request.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessingMTN()))
				request.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				request.getCartInfo().setCartCreator(data.getCartCreator());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN()) && null != request.getData()
					&& null != request.getData().getLines()
					&& StringUtilities.isEmptyOrNull(request.getData().getLines()[0].getMtn()))
				request.getData().getLines()[0].setMtn(data.getProcessingMTN());
			return bpmHelper2.addEdgeup(request);

		});

	}

	/**
	 *
	 * @param request
	 * @return UpdateEdgeupUIResponse
	 *
	 */
	public Mono<UpdateEdgeupUIResponse> removeEdgeup(UpdateEdgeupUIRequest request) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				request.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				request.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				request.getCartInfo().setCaseId(data.getCaseId());
			if (StringUtilities.isNotEmptyOrNull(data.getMtn()))
				request.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessingMTN()))
				request.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				request.getCartInfo().setCartCreator(data.getCartCreator());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN()) && null != request.getData()
					&& null != request.getData().getLines()
					&& StringUtilities.isEmptyOrNull(request.getData().getLines()[0].getMtn()))
				request.getData().getLines()[0].setMtn(data.getProcessingMTN());
			return bpmHelper2.removeEdgeUp(request);
		});

	}

	public boolean checkForBYODANDPastDueFlag(PastDuesUIRequest request) {
		return CartUtil.isDigital(request.getChannelId())
				&& featureFlagHelper.isPastDueBYODFFlag()
				&& null != request.getCartInfo()
				&& null != request.getCartInfo().getIntendType()
				&& request.getCartInfo().getIntendType().equalsIgnoreCase(CartConstants.BYOD);
	}

	/**
	 *
	 * @param request
	 * @return PastDuesUIResponse
	 *
	 */
	public Mono<PastDuesUIResponse> pastDues(PastDuesUIRequest request) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				request.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				request.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				request.getCartInfo().setCaseId(data.getCaseId());
			if (StringUtilities.isNotEmptyOrNull(data.getMtn()))
				request.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessingMTN()))
				request.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				request.getCartInfo().setCartCreator(data.getCartCreator());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN()) && null != request.getData()
					&& null != request.getData().getLines()
					&& StringUtilities.isEmptyOrNull(request.getData().getLines()[0].getMtn()))
				request.getData().getLines()[0].setMtn(data.getProcessingMTN());
			if(data.getPastDueRedisData()!=null){
				PastDuesData pastDuesData = new PastDuesData();
				PastDue pastDue = new PastDue();
				pastDue.setAmount(data.getPastDueRedisData().getAmount());
				pastDuesData.setPastdue(pastDue);
				request.setData(pastDuesData);
			}
			if(checkForBYODANDPastDueFlag(request))
				return Mono.just(new PastDuesUIResponse());
			return bpmHelper2.pastDues(request);
		});
	}

	/**
	 *
	 * @param downPaymentUIRequest
	 * @return AddDownPaymentUIResponse
	 *
	 */
	public Mono<AddDownPaymentUIResponse> addDownPayment(DownPaymentUIRequest downPaymentUIRequest) {
		String channelType = CartUtil.getChannelType(downPaymentUIRequest.getChannelId());
		if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.DIGITAL)) {
			//if channel type is digital
			return addDownPaymentDigital(downPaymentUIRequest);
		}
		else {
			return redisHelper.getDataFromRedis().flatMap(data -> {
				if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED)) {
					if (StringUtilities.isNotEmptyOrNull(downPaymentUIRequest.getCartInfo().getIntendType()) && downPaymentUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getCreditAppNum())) {
						downPaymentUIRequest.getCartInfo().setCreditAppNum(data.getCreditAppNum());
						downPaymentUIRequest.getCartInfo().setCartCreator(data.getCreditAppNum());
					}
				}
				if (StringUtilities.isNotEmptyOrNull(downPaymentUIRequest.getCartInfo().getIntendType()) && !downPaymentUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
					downPaymentUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
				if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
					downPaymentUIRequest.getCartInfo().setCartId(data.getCartId());
				if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
					downPaymentUIRequest.getCartInfo().setCaseId(data.getCaseId());
				if (StringUtilities.isNotEmptyOrNull(downPaymentUIRequest.getCartInfo().getIntendType()) && !downPaymentUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getMtn()))
					downPaymentUIRequest.getCartInfo().setCartCreator(data.getMtn());
				if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
						&& StringUtilities.isEmptyOrNull(downPaymentUIRequest.getCartInfo().getProcessingMTN()))
					downPaymentUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
				if (StringUtilities.isNotEmptyOrNull(downPaymentUIRequest.getCartInfo().getIntendType()) && !downPaymentUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
					downPaymentUIRequest.getCartInfo().setCartCreator(data.getCartCreator());
				if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN()) && null != downPaymentUIRequest.getData()
						&& null != downPaymentUIRequest.getData().getLines()
						&& StringUtilities.isEmptyOrNull(downPaymentUIRequest.getData().getLines()[0].getMtn()))
					downPaymentUIRequest.getData().getLines()[0].setMtn(data.getProcessingMTN());
				return bpmHelper2.addDownPayment(downPaymentUIRequest);
			});
		}
	}

	public Mono<AddDownPaymentUIResponse> addDownPaymentDigital(DownPaymentUIRequest downPaymentUIRequest) {

		Mono<Boolean> isElvisFlagEnabledMono = featureFlag.isFeatureEnabled(FeatureFlagConstants.SOR_XCIO, FeatureFlagConstants.ELVIS_FLAG_PROFILE, FeatureFlagConstants.ELVIS_FLAG_NAME, false).doOnError(defaltRes -> Mono.just(false));

		return isElvisFlagEnabledMono.flatMap(isElvisFlagEnabled -> {
			logger.info("Elvis Feature Flag : {} ", isElvisFlagEnabled);
			//condition to check if elvis is enabled for digital
			if (BooleanUtils.isTrue(isElvisFlagEnabled)) {
				return redisHelper.getDataFromRedis().flatMap(redisVal -> {
					Optional.ofNullable(downPaymentUIRequest.getCartInfo())
							.ifPresent(cartInfo -> {
								Optional.ofNullable(redisVal.getAccountNumber())
										.filter(accountNumber -> StringUtilities.isNotEmptyOrNull(accountNumber) &&
												StringUtilities.isNotEmptyOrNull(cartInfo.getIntendType()) &&
												!cartInfo.getIntendType().toUpperCase().contains("NSE"))
										.ifPresent(cartInfo::setAccountNumber);

								Optional.ofNullable(redisVal.getCartId()).filter(StringUtilities::isNotEmptyOrNull).ifPresent(cartInfo::setCartId);
								Optional.ofNullable(redisVal.getCaseId()).filter(StringUtilities::isNotEmptyOrNull).ifPresent(cartInfo::setCaseId);
								Optional.ofNullable(redisVal.getCartCreator())
										.filter(cartCreator -> StringUtilities.isNotEmptyOrNull(cartCreator) &&
												StringUtilities.isNotEmptyOrNull(cartInfo.getIntendType()) &&
												!cartInfo.getIntendType().toUpperCase().contains("NSE"))
										.ifPresent(cartInfo::setCartCreator);
								Optional.ofNullable(redisVal.getProcessingMTN())
										.filter(processingMtn -> StringUtilities.isNotEmptyOrNull(processingMtn) &&
												StringUtilities.isEmptyOrNull(cartInfo.getProcessingMTN()))
										.ifPresent(cartInfo::setProcessingMTN);
								Optional.ofNullable(redisVal.getProcessingMTN())
										.filter(processingMtn -> StringUtilities.isNotEmptyOrNull(processingMtn) && downPaymentUIRequest.getData() != null
										&& null != downPaymentUIRequest.getData().getLines() && downPaymentUIRequest.getData().getLines()[0] != null &&
										StringUtilities.isEmptyOrNull(downPaymentUIRequest.getData().getLines()[0].getMtn()))
												.ifPresent(processingMtn -> downPaymentUIRequest.getData().getLines()[0].setMtn(processingMtn));
							});
					return bpmHelper2.addDownPayment(downPaymentUIRequest);
				});
			} else{
				AddDownPaymentUIResponse errorResponse = new AddDownPaymentUIResponse();
				CartError cartError = new CartError();
				cartError.setMessage("Not a valid call for the MTN");
				errorResponse.setErrors(Arrays.asList(cartError));
				return Mono.just(errorResponse);
			}
		});
	}
	/**
	 *
	 * @param createLineUIRequest
	 * @return CreateLineUIResponse
	 *
	 */
	public Mono<CreateLineUIResponse> createLine(CreateLineUIRequest createLineUIRequest) {
		String channelType = CartUtil.getChannelType(createLineUIRequest.getChannelId());
		Mono<CartRedisData> rr = redisHelper.getDataFromRedis();
		Mono<Boolean> isCartOperationWithUUIDEnabledMono = featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART,FeatureFlagConstants.FLAG_NAME_CART_OPERATION_WITH_UUID,true);

		return Mono.zip(rr, isCartOperationWithUUIDEnabledMono).flatMap(tuple2 -> {
			CartRedisData data = tuple2.getT1();
			boolean isCartOperationWithUUIDEnabled = tuple2.getT2();
			prepareCreateLineRequest(createLineUIRequest, channelType, data, isCartOperationWithUUIDEnabled);
			if(CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(createLineUIRequest.getChannelId())) && (StringUtilities.isEmptyOrNull(createLineUIRequest.getCartInfo().getCaseId()) || StringUtilities.isEmptyOrNull(createLineUIRequest.getCartInfo().getCartId()))) {
				CreateLineUIResponse errorResponse = new CreateLineUIResponse();
				errorResponse.setErrors(CartPegaRequestErrorsUtil.validateCartIdAndCaseId(createLineUIRequest.getCartInfo()));
				return Mono.just(errorResponse);
			}
//			skipping adding cradle call for digital BYOD flow
			if(CartUtil.isDigital(createLineUIRequest.getChannelId()) &&
				CartConstants.BYOD.equalsIgnoreCase(createLineUIRequest.getCartInfo().getIntendType())){
				logger.info("Skipping invokeCradleForPlansHub for Digital BYOD");
				return getCreateLineUIResponseMono(createLineUIRequest);
			}

			Mono<CradleResponse> respFromCradleFinal = invokeCradleForPlansHub(createLineUIRequest);
			return respFromCradleFinal.flatMap(cradleResponse-> {
				try {
					setCradleFlowJourneyForCreateLine(createLineUIRequest, cradleResponse);
				}catch (JsonProcessingException ex2) {
					logger.error("Error occurred in cradleResponse {}", ex2);
				}
				return cradleAllocator.getDataMap().flatMap(map->{
					logger.info("Cradle datamap from redis is : {}",map);
					String intendType=createLineUIRequest.getCartInfo().getIntendType();
					if(StringUtilities.isNotEmptyOrNull(intendType) && intendType.equalsIgnoreCase(CartConstants.NSE_BYOD)
							&& StringUtilities.isEmptyOrNull(createLineUIRequest.getCartInfo().getExistingCradleFlowJourney()))
						return isNgProspectFeatureFlagEnabled(map,createLineUIRequest).flatMap(isConfigEnabled->{
							if(isConfigEnabled){
								logger.info("setting cradle flow journey as NEXTGEN for nse byod flow");
								createLineUIRequest.getCartInfo().setExistingCradleFlowJourney(CartConstants.CRADLEFLOW_JOURNEY_NEXTGEN);
							}
							else{
								logger.info("setting cradle flow journey as NEXTGENBYOD for nse byod flow");
								createLineUIRequest.getCartInfo().setExistingCradleFlowJourney(CartConstants.CRADLEFLOW_JOURNEY_NEXTGEN_BYOD);
							}
							return getCreateLineUIResponseMono(createLineUIRequest);
						});
					return getCreateLineUIResponseMono(createLineUIRequest);
				});
			});
		});
	}

	private Mono<Boolean> isNgProspectFeatureFlagEnabled(Map<String, String> map, CreateLineUIRequest createLineUIRequest) {
		if(!map.isEmpty() && map.containsKey(CartConstants.THROTTLE_LIST) && StringUtilities.isNotEmptyOrNull(map.get(CartConstants.THROTTLE_LIST))){
			String throttleList=map.get(CartConstants.THROTTLE_LIST);
			if(!(throttleList.contains(CartConstants.NEXTGEN_C_BYOD_MVA_CDL_VALUE) || throttleList.contains(CartConstants.NEXTGEN_C_BYOD_CDL_VALUE)))
			{
				logger.info("setting cradle flow journey for nse byod flow");
				//work around - to be removed after testing
				createLineUIRequest.getCartInfo().setExistingCradleFlowJourney(CartConstants.CRADLEFLOW_JOURNEY_NEXTGEN);
				return featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,FeatureFlagConstants.CONFIG_PROFILE_BYOD,FeatureFlagConstants.FLAG_NAME_NG_PROSPECT_COMBO,true);
			}
		}
		return Mono.just(Boolean.FALSE);
	}

	private void setCradleFlowJourneyForCreateLine(CreateLineUIRequest createLineUIRequest, CradleResponse cradleResponse) throws JsonProcessingException {
		if (null != cradleResponse
				&& null != cradleResponse.getOutPut()) {
			logger.debug(String.format(CartConstants.LOG_CRADLE_OUTPUT, cradleResponse.getOutPut()));
			JsonNode cradleOutputJsonNode = mapper.readTree(cradleResponse.getOutPut());
			if (null != cradleOutputJsonNode && null!= cradleOutputJsonNode.get(CartConstants.CRADLE_FLOW_JOURNEY) &&
					StringUtilities.isNotEmptyOrNull(cradleOutputJsonNode.get(CartConstants.CRADLE_FLOW_JOURNEY).asText())) {
				createLineUIRequest.getCartInfo().setCradleFlowJourney(cradleOutputJsonNode
						.get(CartConstants.CRADLE_FLOW_JOURNEY)
						.asText());
			}
		}
	}

	private Mono<CreateLineUIResponse> getCreateLineUIResponseMono(CreateLineUIRequest createLineUIRequest) {
		return bpmHelper2.createLine(createLineUIRequest).flatMap(clr -> {
			return redisHelper3.getHomeSalesAddressFromRedis().flatMap(hsa -> {
				if (null != clr.getServiceBody() && null != clr.getServiceBody().getServiceResponse() && null != clr.getServiceBody().getServiceResponse().getContext()) {
					clr.getServiceBody().getServiceResponse().getContext().setHomeSalesAddress(hsa);
				}
				String[] sessionKey= {RedisConstants.HOME_SALES_ADDRESS_LIST};
				return redisHelper3.getDataFromSession(sessionKey).flatMap(hsaList -> {
					if(hsaList.get(RedisConstants.HOME_SALES_ADDRESS_LIST) != null)
					{
						List<HomeSalesAddress> homeSalesAddressList = new ArrayList<>();
						homeSalesAddressList = Arrays.asList(new Gson().fromJson((String) hsaList.get(RedisConstants.HOME_SALES_ADDRESS_LIST), HomeSalesAddress[].class));
						if (null != clr.getServiceBody() && null != clr.getServiceBody().getServiceResponse() && null != clr.getServiceBody().getServiceResponse().getContext()) {
							clr.getServiceBody().getServiceResponse().getContext().setHomeSalesAddressList(homeSalesAddressList);
						}
					}
					return Mono.just(clr);
				});
			});
		});
	}

	private void prepareCreateLineRequest(CreateLineUIRequest createLineUIRequest, String channelType, CartRedisData data, boolean isCartOperationWithUUIDEnabled) {
		if(createLineUIRequest.getCartInfo() != null && createLineUIRequest.getCartInfo().isFlexV2()) {
			cartRequestBuilder.buildCreateLineRequest(createLineUIRequest, data);
		}
		if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED)) {
			if(StringUtilities.isNotEmptyOrNull(data.getFlowName())){
				createLineUIRequest.setFlowName(data.getFlowName());
			}
			if(StringUtilities.isNotEmptyOrNull(createLineUIRequest.getCartInfo().getIntendType()) && createLineUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getCreditAppNum())) {
				createLineUIRequest.getCartInfo().setCreditAppNum(data.getCreditAppNum());
				createLineUIRequest.getCartInfo().setCartCreator(data.getCreditAppNum());
			}
		}
		if(enableMHOffers&&StringUtilities.isNotEmptyOrNull(data.getExternalID())&&StringUtilities.isNotEmptyOrNull(createLineUIRequest.getPath())&& createLineUIRequest.getPath().contains(CartConstants.NSE_NEW_LINE)){
			createLineUIRequest.setExternalId(data.getExternalID());
		}
		if(StringUtilities.isNotEmptyOrNull(data.getVzId()) && StringUtilities.isNotEmptyOrNull(createLineUIRequest.getPath()) && createLineUIRequest.getPath().contains(CartConstants.NSE_NEW_LINE)){
			createLineUIRequest.setVzId(data.getVzId());
		}
		prepareCreateLineRequest1(createLineUIRequest, data);
		prepareCreateLineRequest2(createLineUIRequest,data, isCartOperationWithUUIDEnabled);
	}

	private void prepareCreateLineRequest2(CreateLineUIRequest createLineUIRequest, CartRedisData data, boolean isCartOperationWithUUIDEnabled) {
		if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
				&& StringUtilities.isEmptyOrNull(createLineUIRequest.getCartInfo().getProcessingMTN()))
			createLineUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
		if ((StringUtilities.isNotEmptyOrNull(createLineUIRequest.getCartInfo().getIntendType()) && !createLineUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE")) && StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
			createLineUIRequest.getCartInfo().setCartCreator(data.getCartCreator());
		if (StringUtilities.isNotEmptyOrNull(data.getVzwRoles())) {
			createLineUIRequest.getCartInfo().setAmRole(data.getVzwRoles());
		}
		if (StringUtilities.isNotEmptyOrNull(data.getIsPrepayCart())) {
			logger.info("Prepay Data Availabe in redis for Transfer Post to Pre");
			createLineUIRequest.getCartInfo().setIsPrepayCart(data.getIsPrepayCart());
		}
		//Setting the appUniversalId for MVA Prospect flow
		if(isCartOperationWithUUIDEnabled
				&& createLineUIRequest.getCartInfo().getIntendType().contains(CartConstants.NSE)
				&& createLineUIRequest.getChannelId().contains(CartConstants.VZW_MFA)
				&& createLineUIRequest.getHttpRequest() != null
				&& !createLineUIRequest.getHttpRequest().getCookies().isEmpty()){
					HttpCookie uuidCookie = createLineUIRequest.getHttpRequest().getCookies().getFirst(CartConstants.UUID);
					if(uuidCookie != null && StringUtilities.isNotEmptyOrNull(uuidCookie.getValue())) {
						createLineUIRequest.setAppUniversalId(uuidCookie.getValue());
					}
		}
	}

	private void prepareCreateLineRequest1(CreateLineUIRequest createLineUIRequest, CartRedisData data) {
		if ((StringUtilities.isNotEmptyOrNull(createLineUIRequest.getCartInfo().getIntendType()) && !createLineUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE")) && StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
			createLineUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
		if(createLineUIRequest.getCartInfo() !=null && CartConstants.DVM_CONVERSION_FLOWTYPE.equals(createLineUIRequest.getCartInfo().getFlowType()) && StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
			createLineUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
		if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
			createLineUIRequest.getCartInfo().setCartId(data.getCartId());
		if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
			createLineUIRequest.getCartInfo().setCaseId(data.getCaseId());
		if ((StringUtilities.isNotEmptyOrNull(createLineUIRequest.getCartInfo().getIntendType()) && !createLineUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE")) && StringUtilities.isNotEmptyOrNull(data.getMtn()))
			createLineUIRequest.getCartInfo().setCartCreator(data.getMtn());
	}

	/**
	 *
	 * @param numberShareUIRequest
	 * @return NumberShareUIResponse
	 *
	 */
	public Mono<NumberShareUIResponse> numberShare(NumberShareUIRequest numberShareUIRequest) {
		String channelType = CartUtil.getChannelType(numberShareUIRequest.getChannelId());
		Mono<String> promoHubSpokeJourneyMono = redisHelper.getPromoHubSpokeJourney();
		return Mono.zip(redisHelper.getDataFromRedis(), promoHubSpokeJourneyMono).flatMap(dataZip -> {
			CartRedisData data = dataZip.getT1();
			String promoHubSpokeJourneyFlag = dataZip.getT2();
			logger.info(String.format(CartConstants.LOG_PROMO_FLAG, promoHubSpokeJourneyFlag));
			if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED)) {
				if(StringUtilities.isNotEmptyOrNull(numberShareUIRequest.getCartInfo().getIntendType()) && numberShareUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getCreditAppNum())) {
					numberShareUIRequest.getCartInfo().setCreditAppNum(data.getCreditAppNum());
					numberShareUIRequest.getCartInfo().setCartCreator(data.getCreditAppNum());
				}
			}
			if (StringUtilities.isNotEmptyOrNull(promoHubSpokeJourneyFlag)
					&& Boolean.parseBoolean(promoHubSpokeJourneyFlag)) {
				numberShareUIRequest.getCartInfo().setPromoHubJourney(Boolean.TRUE);
			}
			numberShareUIRequest.getCartInfo().setOneClick(Boolean.TRUE);
			if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				numberShareUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				numberShareUIRequest.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				numberShareUIRequest.getCartInfo().setCaseId(data.getCaseId());
			if (StringUtilities.isNotEmptyOrNull(data.getMtn()))
				numberShareUIRequest.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(numberShareUIRequest.getCartInfo().getProcessingMTN()))
				numberShareUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				numberShareUIRequest.getCartInfo().setCartCreator(data.getCartCreator());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN()) && null != numberShareUIRequest.getData()
					&& null != numberShareUIRequest.getData().getLines()
					&& StringUtilities.isEmptyOrNull(numberShareUIRequest.getData().getLines()[0].getMtn()))
				numberShareUIRequest.getData().getLines()[0].setMtn(data.getProcessingMTN());
			return bpmHelper2.numberShare(numberShareUIRequest);
		});
	}

	/**
	 *
	 * @param updateDeviceSIMIdUIRequest
	 * @return UpdateDeviceSIMIdUIResponse
	 *
	 */
	public Mono<UpdateDeviceSIMIdUIResponse> updateDeviceSIMId(UpdateDeviceSIMIdUIRequest updateDeviceSIMIdUIRequest) {
		String channelType = CartUtil.getChannelType(updateDeviceSIMIdUIRequest.getChannelId());
		return redisHelper.getDataFromRedis().flatMap(data -> {
			logger.debug(String.format(CartConstants.BPM_LOG_REDIS_ACCOUNT_NUMBER, data.getAccountNumber()));

			if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED)) {
				if (updateDeviceSIMIdUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE")
						&& StringUtilities.isNotEmptyOrNull(data.getCreditAppNum())) {
					updateDeviceSIMIdUIRequest.getCartInfo().setCreditAppNum(data.getCreditAppNum());
					updateDeviceSIMIdUIRequest.getCartInfo().setCartCreator(data.getCreditAppNum());
				}
			}
			if (!updateDeviceSIMIdUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				updateDeviceSIMIdUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				updateDeviceSIMIdUIRequest.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				updateDeviceSIMIdUIRequest.getCartInfo().setCaseId(data.getCaseId());
			if (!updateDeviceSIMIdUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getMtn()))
				updateDeviceSIMIdUIRequest.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(updateDeviceSIMIdUIRequest.getCartInfo().getProcessingMTN()))
				updateDeviceSIMIdUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (!updateDeviceSIMIdUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				updateDeviceSIMIdUIRequest.getCartInfo().setCartCreator(data.getCartCreator());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN()) && null != updateDeviceSIMIdUIRequest.getData()
					&& CollectionUtilities.isNotEmptyOrNull(updateDeviceSIMIdUIRequest.getData().getLines())
					&& StringUtilities.isEmptyOrNull(updateDeviceSIMIdUIRequest.getData().getLines().get(0).getMtn()))
				updateDeviceSIMIdUIRequest.getData().getLines().get(0).setMtn(data.getProcessingMTN());

			return bpmHelper3.updateDeviceSimId(updateDeviceSIMIdUIRequest);
		});

	}

	/**
	 *
	 * @param serviceAddressUIRequest
	 * @return ServiceAddressUIResponse
	 *
	 */
	public Mono<ServiceAddressUIResponse> addServiceAddress(ServiceAddressUIRequest serviceAddressUIRequest) {
		String channelType = CartUtil.getChannelType(serviceAddressUIRequest.getChannelId());
		return redisHelper.getDataFromRedis().flatMap(data -> {

			if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED)) {
				if(StringUtilities.isNotEmptyOrNull(serviceAddressUIRequest.getCartInfo().getIntendType()) && serviceAddressUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getCreditAppNum())) {
					serviceAddressUIRequest.getCartInfo().setCreditAppNum(data.getCreditAppNum());
					serviceAddressUIRequest.getCartInfo().setCartCreator(data.getCreditAppNum());
				}
			}
			if (StringUtilities.isNotEmptyOrNull(serviceAddressUIRequest.getCartInfo().getIntendType()) && !serviceAddressUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				serviceAddressUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				serviceAddressUIRequest.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getDeviceType()))
				serviceAddressUIRequest.getCartInfo().setDeviceType(data.getDeviceType());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				serviceAddressUIRequest.getCartInfo().setCaseId(data.getCaseId());
			if (StringUtilities.isNotEmptyOrNull(serviceAddressUIRequest.getCartInfo().getIntendType()) && !serviceAddressUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getMtn()))
				serviceAddressUIRequest.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(serviceAddressUIRequest.getCartInfo().getProcessingMTN()))
				serviceAddressUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (StringUtilities.isNotEmptyOrNull(serviceAddressUIRequest.getCartInfo().getIntendType()) && !serviceAddressUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				serviceAddressUIRequest.getCartInfo().setCartCreator(data.getCartCreator());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN()) && null != serviceAddressUIRequest.getData()
					&& null != serviceAddressUIRequest.getData().getLines()
					&& StringUtilities.isEmptyOrNull(serviceAddressUIRequest.getData().getLines()[0].getMtn()))
				serviceAddressUIRequest.getData().getLines()[0].setMtn(data.getProcessingMTN());
			return bpmHelper2.addServiceAddress(serviceAddressUIRequest);
		});
	}


	/**
	 *
	 * @param billingAddressUIRequest
	 * @return BillingAddressUIResponse
	 *
	 */
	public Mono<BillingAddressUIResponse> addBillingAddress(BillingAddressUIRequest billingAddressUIRequest) {
		String channelType = CartUtil.getChannelType(billingAddressUIRequest.getChannelId());
		return redisHelper.getDataFromRedis().flatMap(data -> {

			if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED)) {
				if(StringUtilities.isNotEmptyOrNull(billingAddressUIRequest.getCartInfo().getIntendType()) && billingAddressUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getCreditAppNum())) {
					billingAddressUIRequest.getCartInfo().setCreditAppNum(data.getCreditAppNum());
					billingAddressUIRequest.getCartInfo().setCartCreator(data.getCreditAppNum());
				}
			}
			if (StringUtilities.isNotEmptyOrNull(billingAddressUIRequest.getCartInfo().getIntendType()) && !billingAddressUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				billingAddressUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				billingAddressUIRequest.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getDeviceType()))
				billingAddressUIRequest.getCartInfo().setDeviceType(data.getDeviceType());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				billingAddressUIRequest.getCartInfo().setCaseId(data.getCaseId());
			if (StringUtilities.isNotEmptyOrNull(billingAddressUIRequest.getCartInfo().getIntendType()) && !billingAddressUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getMtn()))
				billingAddressUIRequest.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(billingAddressUIRequest.getCartInfo().getProcessingMTN()))
				billingAddressUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (StringUtilities.isNotEmptyOrNull(billingAddressUIRequest.getCartInfo().getIntendType()) && !billingAddressUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				billingAddressUIRequest.getCartInfo().setCartCreator(data.getCartCreator());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN()) && null != billingAddressUIRequest.getData()
					&& null != billingAddressUIRequest.getData().getLines()
					&& StringUtilities.isEmptyOrNull(billingAddressUIRequest.getData().getLines()[0].getMtn()))
				billingAddressUIRequest.getData().getLines()[0].setMtn(data.getProcessingMTN());
			return bpmHelper2.addBillingAddress(billingAddressUIRequest);
		});
	}

	/**
	 *
	 * @param e911AddressUIRequest
	 * @return E911AddressUIResponse
	 *
	 */
	public Mono<E911AddressUIResponse> addE911Address(E911AddressUIRequest e911AddressUIRequest) {
		String channelType = CartUtil.getChannelType(e911AddressUIRequest.getChannelId());
		return redisHelper.getDataFromRedis().flatMap(data -> {
            if(StringUtilities.isEmptyOrNull(e911AddressUIRequest.getCartInfo().getIntendType()) && StringUtilities.isNotEmptyOrNull(data.getIntendType())){
                e911AddressUIRequest.getCartInfo().setIntendType(data.getIntendType());
            }
			boolean isIntendTypeNSE = (StringUtilities.isNotEmptyOrNull(e911AddressUIRequest.getCartInfo().getIntendType()) && e911AddressUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE")) ? true : false;

            if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED)) {
				if(StringUtilities.isNotEmptyOrNull(e911AddressUIRequest.getCartInfo().getIntendType()) && e911AddressUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getCreditAppNum())) {
					e911AddressUIRequest.getCartInfo().setCreditAppNum(data.getCreditAppNum());
					e911AddressUIRequest.getCartInfo().setCartCreator(data.getCreditAppNum());
				}
			}
			if (!isIntendTypeNSE && StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				e911AddressUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				e911AddressUIRequest.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				e911AddressUIRequest.getCartInfo().setCaseId(data.getCaseId());
			if (!isIntendTypeNSE && StringUtilities.isNotEmptyOrNull(data.getMtn()))
				e911AddressUIRequest.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(e911AddressUIRequest.getCartInfo().getProcessingMTN()))
				e911AddressUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (!isIntendTypeNSE && StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				e911AddressUIRequest.getCartInfo().setCartCreator(data.getCartCreator());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN()) && null != e911AddressUIRequest.getData()
					&& null != e911AddressUIRequest.getData().getLines()
					&& StringUtilities.isEmptyOrNull(e911AddressUIRequest.getData().getLines()[0].getMtn()))
				e911AddressUIRequest.getData().getLines()[0].setMtn(data.getProcessingMTN());

			if (StringUtilities.isNotEmptyOrNull(data.getRpsIntent())) {
				e911AddressUIRequest.getCartInfo().setRpsIntent(data.getRpsIntent());
			}
			if(StringUtilities.isNotEmptyOrNull(e911AddressUIRequest.getCartInfo().getClientAppName()) && CartConstants.CHANNEL_ID_NUMBERLINK.equalsIgnoreCase(e911AddressUIRequest.getCartInfo().getClientAppName()) && StringUtilities.isNotEmptyOrNull(data.getIntent())) {
					e911AddressUIRequest.getCartInfo().setIntent(data.getIntent());
			}
			if (null != e911AddressUIRequest.getData().getLines()[0].getE911Address())
				logE911Address(e911AddressUIRequest.getData().getLines()[0].getE911Address());
			return bpmHelper2.addE911Address(e911AddressUIRequest);
		});
	}

	/**
	 *
	 * @param instantCreditDownPaymentUIRequest
	 * @return InstantCreditDownPaymentUIResponse
	 *
	 */
	public Mono<InstantCreditDownPaymentUIResponse> addInstantCreditDownPayment(
			InstantCreditDownPaymentUIRequest instantCreditDownPaymentUIRequest) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				instantCreditDownPaymentUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				instantCreditDownPaymentUIRequest.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				instantCreditDownPaymentUIRequest.getCartInfo().setCaseId(data.getCaseId());
			if (StringUtilities.isNotEmptyOrNull(data.getMtn()))
				instantCreditDownPaymentUIRequest.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(instantCreditDownPaymentUIRequest.getCartInfo().getProcessingMTN()))
				instantCreditDownPaymentUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				instantCreditDownPaymentUIRequest.getCartInfo().setCartCreator(data.getCartCreator());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN()) && null != instantCreditDownPaymentUIRequest.getData()
					&& null != instantCreditDownPaymentUIRequest.getData().getLines()
					&& instantCreditDownPaymentUIRequest.getData().getLines().length > 0
					&& StringUtilities.isEmptyOrNull(instantCreditDownPaymentUIRequest.getData().getLines()[0].getMtn()))
				instantCreditDownPaymentUIRequest.getData().getLines()[0].setMtn(data.getProcessingMTN());
			return bpmHelper2.addInstantCreditDownPayment(instantCreditDownPaymentUIRequest);
		});

	}

	/**
	 *
	 * @param salesRepAndLocationCodeUIRequest
	 * @return SalesRepAndLocationCodeUIResponse
	 *
	 */
	public Mono<SalesRepAndLocationCodeUIResponse> updateSalesRepAndLocationCode(
			SalesRepAndLocationCodeUIRequest salesRepAndLocationCodeUIRequest) {
		String channelType = CartUtil.getChannelType(salesRepAndLocationCodeUIRequest.getChannelId());
		return redisHelper.getDataFromRedis().flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED)) {
				if(StringUtilities.isNotEmptyOrNull(salesRepAndLocationCodeUIRequest.getCartInfo().getIntendType()) && salesRepAndLocationCodeUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getCreditAppNum())) {
					salesRepAndLocationCodeUIRequest.getCartInfo().setCreditAppNum(data.getCreditAppNum());
					salesRepAndLocationCodeUIRequest.getCartInfo().setCartCreator(data.getCreditAppNum());
				}
			}
			if (StringUtilities.isNotEmptyOrNull(salesRepAndLocationCodeUIRequest.getCartInfo().getIntendType()) && !salesRepAndLocationCodeUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				salesRepAndLocationCodeUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				salesRepAndLocationCodeUIRequest.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				salesRepAndLocationCodeUIRequest.getCartInfo().setCaseId(data.getCaseId());
			if (StringUtilities.isNotEmptyOrNull(salesRepAndLocationCodeUIRequest.getCartInfo().getIntendType()) && !salesRepAndLocationCodeUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getMtn()))
				salesRepAndLocationCodeUIRequest.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(salesRepAndLocationCodeUIRequest.getCartInfo().getProcessingMTN()))
				salesRepAndLocationCodeUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (StringUtilities.isNotEmptyOrNull(salesRepAndLocationCodeUIRequest.getCartInfo().getIntendType()) && !salesRepAndLocationCodeUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				salesRepAndLocationCodeUIRequest.getCartInfo().setCartCreator(data.getCartCreator());
			//VZWDRE-652
			if (StringUtilities.isNotEmptyOrNull(data.getIntendType()) && StringUtilities.isEmptyOrNull(salesRepAndLocationCodeUIRequest.getCartInfo().getIntendType()))
				salesRepAndLocationCodeUIRequest.getCartInfo().setIntendType(data.getIntendType());
			
			return bpmHelper3.updateSalesRepAndLocationCode(salesRepAndLocationCodeUIRequest);
		});

	}

	/**
	 *
	 * @param request
	 * @return MacAddressUIResponse
	 *
	 */
	public Mono<MacAddressUIResponse> updateMacAddress(MacAddressUIRequest request) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			logger.debug(String.format(CartConstants.LOG_REDIS_ACCOUNT_NUMBER, data.getAccountNumber()));
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				request.setCartId(data.getCartId());
			return cxpHelper2.updateMacAddress(request);
		});

	}

	/**
	 *
	 * @param effectiveDateOverrideUIRequest
	 * @return EffectiveDateOverrideUIResponse
	 *
	 */
	public Mono<EffectiveDateOverrideUIResponse> effectiveDateOverride(EffectiveDateOverrideUIRequest effectiveDateOverrideUIRequest) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				effectiveDateOverrideUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				effectiveDateOverrideUIRequest.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				effectiveDateOverrideUIRequest.getCartInfo().setCaseId(data.getCaseId());
			if (StringUtilities.isNotEmptyOrNull(data.getMtn()))
				effectiveDateOverrideUIRequest.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(effectiveDateOverrideUIRequest.getCartInfo().getProcessingMTN()))
				effectiveDateOverrideUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				effectiveDateOverrideUIRequest.getCartInfo().setCartCreator(data.getCartCreator());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN()) && null != effectiveDateOverrideUIRequest.getData()
					&& null != effectiveDateOverrideUIRequest.getData().getLines()
					&& StringUtilities.isEmptyOrNull(effectiveDateOverrideUIRequest.getData().getLines()[0].getMtn()))
				effectiveDateOverrideUIRequest.getData().getLines()[0].setMtn(data.getProcessingMTN());

			return bpmHelper2.effectiveDateOverride(effectiveDateOverrideUIRequest);
		});

	}

	/**
	 *
	 * @param assignMtnUIRequest
	 * @return AssignMtnUIResponse
	 *
	 */
	public Mono<AssignMtnUIResponse> assignMtn(AssignMtnUIRequest assignMtnUIRequest) {
		String channelType = CartUtil.getChannelType(assignMtnUIRequest.getChannelId());
		Mono<CartRedisData> rr = redisHelper.getDataFromRedis();
		Mono<String> promoHubSpokeJourneyMono = redisHelper.getPromoHubSpokeJourney();
		Mono<FiveGAddressRedisData> fiveGAddressRedisDataMono = redisHelper.getFiveGAddressFromRedis();
		return Mono.zip(rr, promoHubSpokeJourneyMono, fiveGAddressRedisDataMono).flatMap(dataZip -> {
			CartRedisData data = dataZip.getT1();
			if(validateCartIdandCaseId(data,assignMtnUIRequest)){
				return populateRedirectionError();
			}
			if(validateStoredNpaNxxInRequest(data,assignMtnUIRequest)){
				logger.error("potential assign mtn Request tampered");
				return populateInvalidAssignMtnError();
			}
			String promoHubSpokeJourneyFlag = dataZip.getT2();
			FiveGAddressRedisData fiveGAddressRedisData = dataZip.getT3();
			if(assignMtnUIRequest.getCartInfo() != null && assignMtnUIRequest.getCartInfo().isFlexV2()) {
				cartRequestBuilder.buildAssignMtnRequest(assignMtnUIRequest, data, fiveGAddressRedisData);
			}
			if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED)) {
				if(StringUtilities.isNotEmptyOrNull(assignMtnUIRequest.getCartInfo().getIntendType()) && assignMtnUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getCreditAppNum())) {
					assignMtnUIRequest.getCartInfo().setCreditAppNum(data.getCreditAppNum());
					assignMtnUIRequest.getCartInfo().setCartCreator(data.getCreditAppNum());
				}
			}
			if (StringUtilities.isNotEmptyOrNull(promoHubSpokeJourneyFlag)
					&& Boolean.parseBoolean(promoHubSpokeJourneyFlag)) {
				assignMtnUIRequest.getCartInfo().setPromoHubJourney(Boolean.TRUE);
			}
			if (!CartConstants.NSE_BYOD.equalsIgnoreCase(assignMtnUIRequest.getCartInfo().getIntendType()) && !CartConstants.NSE.equalsIgnoreCase(assignMtnUIRequest.getCartInfo().getIntendType()) && !CartConstants.NSE_5G.equalsIgnoreCase(assignMtnUIRequest.getCartInfo().getIntendType()) && StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				assignMtnUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				assignMtnUIRequest.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				assignMtnUIRequest.getCartInfo().setCaseId(data.getCaseId());
			if (!CartConstants.NSE_BYOD.equalsIgnoreCase(assignMtnUIRequest.getCartInfo().getIntendType()) && !CartConstants.NSE.equalsIgnoreCase(assignMtnUIRequest.getCartInfo().getIntendType()) && !CartConstants.NSE_5G.equalsIgnoreCase(assignMtnUIRequest.getCartInfo().getIntendType()) && StringUtilities.isNotEmptyOrNull(data.getMtn()))
				assignMtnUIRequest.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(assignMtnUIRequest.getCartInfo().getProcessingMTN()))
				assignMtnUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (!CartConstants.NSE_BYOD.equalsIgnoreCase(assignMtnUIRequest.getCartInfo().getIntendType()) && !CartConstants.NSE.equalsIgnoreCase(assignMtnUIRequest.getCartInfo().getIntendType()) && !CartConstants.NSE_5G.equalsIgnoreCase(assignMtnUIRequest.getCartInfo().getIntendType()) && StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				assignMtnUIRequest.getCartInfo().setCartCreator(data.getCartCreator());
			if (StringUtilities.isNotEmptyOrNull(data.getRpsIntent())) {
				assignMtnUIRequest.getCartInfo().setRpsIntent(data.getRpsIntent());
			}
			if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(assignMtnUIRequest.getChannelId()))
					&& StringUtilities.isNotEmptyOrNull(data.getProcessingMTN()) && null != assignMtnUIRequest.getData().getLines()
					&& StringUtilities.isEmptyOrNull(assignMtnUIRequest.getData().getLines().get(0).getMtn()))
				assignMtnUIRequest.getData().getLines().get(0).setMtn(data.getProcessingMTN());
			return bpmHelper2.assignMtn(assignMtnUIRequest).flatMap(mtnResp -> {
				if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
						&& data.getProcessingMTN().equalsIgnoreCase(assignMtnUIRequest.getData().getLines().get(0).getMtn())) {
					CartRedisData redisRequest = new CartRedisData();
					Optional.ofNullable(mtnResp.getServiceBody()).map(AssignMtnServiceBody::getServiceResponse)
							.map(AssignMtnServiceResponse::getContext).map(AssignMtnContext::getCartInfo)
							.ifPresent(cartInfo -> {
								if (cartInfo.getLines() != null && cartInfo.getLines().length > 0) {
									if (StringUtilities.isNotEmptyOrNull(cartInfo.getLines()[0].getMtn())) {
										redisRequest.setProcessingMTN(cartInfo.getLines()[0].getMtn());
										if(CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(assignMtnUIRequest.getChannelId())))
											redisHelper.upsertDataIntoRedisAsString(redisRequest, "");
									}
								}
							});
				}
				if(CartUtil.isDigital(assignMtnUIRequest.getChannelId()) && enableSecurityForCart) {
					removeSensitiveInfoForAssignMtn(mtnResp);
				}
				return Mono.just(mtnResp);
			});

		});
	}

	private boolean validateStoredNpaNxxInRequest(CartRedisData data, AssignMtnUIRequest request) {
		if(storeNpaNxxInCache && CartUtil.isDigital(request.getChannelId()) && CollectionUtilities.isNotEmptyOrNull(data.getNpanxxlist()) && List.of(CartConstants.NSE_ASSIGN_MTN_URL,CartConstants.CART_ASSIGN_MTN_URL).stream().anyMatch(url -> Optional.ofNullable(request.getPath()).map(String::toLowerCase).orElse("").contains(url))){
			return Optional.of(request).map(AssignMtnUIRequest::getData).map(AssignMtnData::getLines).filter(CollectionUtilities::isNotEmptyOrNull).map(lines -> lines.stream().noneMatch(line -> data.getNpanxxlist().contains(line.getNpaNxx()))).orElse(false);
		}
		return false;
	}

	public  Mono<AssignMtnUIResponse> populateRedirectionError() {
		AssignMtnUIResponse response =new AssignMtnUIResponse();
		response.setErrors(reDirectErrorResponse());
		return Mono.just(response);
	}

	public  Mono<AssignMtnUIResponse> populateInvalidAssignMtnError() {
		AssignMtnUIResponse response =new AssignMtnUIResponse();
		response.setErrors(invalidAssignMtnErro());
		return Mono.just(response);
	}

	private  List<CartError> invalidAssignMtnErro() {
		List<CartError> errors = new ArrayList<>();
		CartError error = new CartError();
		error.setName("VALIDATION_ERROR");
		error.setCode("");
		error.setDebug_id("");
		error.setId("899");
		error.setMessage("Please check NpaNxx");
		error.setInformation_link(reDirectLink);
		errors.add(error);
		return errors;

	}

	private  List<CartError> reDirectErrorResponse() {
		List<CartError> errors = new ArrayList<>();
		CartError error = new CartError();
		error.setName("VALIDATION_ERROR");
		error.setCode("");
		error.setDebug_id("");
		error.setId("R1001");
		error.setMessage("CartId or Case Id is not present in redis");
		error.setInformation_link(reDirectLink);
		errors.add(error);
		return errors;

	}

	public  Mono<UpdateBarcodeUIResponse> returnResponse() {
		UpdateBarcodeUIResponse response = new UpdateBarcodeUIResponse();
		CartServiceServiceHeader header = new CartServiceServiceHeader();
		header.setStatusCode("00");
		header.setStatusMsg(CartConstants.SUCCESS);
		response.setServiceHeader(header);
		return Mono.just(response);
	}

	public  Mono<UpdateBarcodeUIResponse> populateErrorForExceedingPromoCode() {
		UpdateBarcodeUIResponse response =new UpdateBarcodeUIResponse();
		response.setErrors(exceedingPromoCodeErrorResponse());
		return Mono.just(response);
	}

	private  List<CartError> exceedingPromoCodeErrorResponse() {
		List<CartError> errors = new ArrayList<>();
		CartError error = new CartError();
		error.setNamespace("onevz-soe-cart");
		error.setName("VALIDATION_ERROR");
		error.setId("R1010");
		error.setMessage("Promo Code usage exceeds maximum Count");
		errors.add(error);
		return errors;
	}

	private boolean validateCartIdandCaseId(CartRedisData rr, AssignMtnUIRequest request) {
		if(CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId())) && (StringUtilities.isEmptyOrNull(rr.getCartId()) || StringUtilities.isEmptyOrNull(rr.getCaseId())))
			return true;
		else
			return false;
	}

	/**
	 *
	 * @param deassignMtnUIRequest
	 * @return DeassignMtnUIResponse
	 *
	 */
	public Mono<DeassignMtnUIResponse> deassignMtn(DeassignMtnUIRequest deassignMtnUIRequest) {
		String channelType = CartUtil.getChannelType(deassignMtnUIRequest.getChannelId());
		return redisHelper.getDataFromRedis().flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED)) {
				if(StringUtilities.isNotEmptyOrNull(deassignMtnUIRequest.getCartInfo().getIntendType()) && deassignMtnUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getCreditAppNum())) {
					deassignMtnUIRequest.getCartInfo().setCreditAppNum(data.getCreditAppNum());
					deassignMtnUIRequest.getCartInfo().setCartCreator(data.getCreditAppNum());
				}
			}
			if (!CartConstants.NSE_BYOD.equalsIgnoreCase(deassignMtnUIRequest.getCartInfo().getIntendType()) && !CartConstants.NSE.equalsIgnoreCase(deassignMtnUIRequest.getCartInfo().getIntendType()) && !CartConstants.NSE_5G.equalsIgnoreCase(deassignMtnUIRequest.getCartInfo().getIntendType()) && StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				deassignMtnUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				deassignMtnUIRequest.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				deassignMtnUIRequest.getCartInfo().setCaseId(data.getCaseId());
			if (!CartConstants.NSE_BYOD.equalsIgnoreCase(deassignMtnUIRequest.getCartInfo().getIntendType()) && !CartConstants.NSE.equalsIgnoreCase(deassignMtnUIRequest.getCartInfo().getIntendType()) && !CartConstants.NSE_5G.equalsIgnoreCase(deassignMtnUIRequest.getCartInfo().getIntendType()) && StringUtilities.isNotEmptyOrNull(data.getMtn()))
				deassignMtnUIRequest.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(deassignMtnUIRequest.getCartInfo().getProcessingMTN()))
				deassignMtnUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (!CartConstants.NSE_BYOD.equalsIgnoreCase(deassignMtnUIRequest.getCartInfo().getIntendType()) && !CartConstants.NSE.equalsIgnoreCase(deassignMtnUIRequest.getCartInfo().getIntendType()) && !CartConstants.NSE_5G.equalsIgnoreCase(deassignMtnUIRequest.getCartInfo().getIntendType()) && StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				deassignMtnUIRequest.getCartInfo().setCartCreator(data.getCartCreator());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN()) && null != deassignMtnUIRequest.getData()
					&& CollectionUtilities.isNotEmptyOrNull(deassignMtnUIRequest.getData().getLines())
					&& StringUtilities.isEmptyOrNull(deassignMtnUIRequest.getData().getLines().get(0).getMtn()))
				deassignMtnUIRequest.getData().getLines().get(0).setMtn(data.getProcessingMTN());
			return bpmHelper2.deassignMtn(deassignMtnUIRequest);
		});
	}
	/**
	 *
	 * @param addPromoIntentUIRequest
	 * @return AddPromoIntentUIResponse
	 *
	 */
	public Mono<AddPromoIntentUIResponse> addPromoIntent(AddPromoIntentUIRequest addPromoIntentUIRequest) {
		return redisHelper.getDataFromRedis().flatMap(data -> {

			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				addPromoIntentUIRequest.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				addPromoIntentUIRequest.getCartInfo().setCaseId(data.getCaseId());
			if (StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				addPromoIntentUIRequest.getCartInfo().setCartCreator(data.getCartCreator());
			if (null != data.getCartInfo() && StringUtilities.isNotEmptyOrNull(data.getCartInfo().getGlobalId()))
				addPromoIntentUIRequest.getCartInfo().setGlobalId(data.getCartInfo().getGlobalId());
			if (StringUtilities.isNotEmptyOrNull(data.getCustomerType()))
				addPromoIntentUIRequest.getCartInfo().setCustomerType(data.getCustomerType());
			if (StringUtilities.isNotEmptyOrNull(data.getMtnFlow()))
				addPromoIntentUIRequest.getCartInfo().setMtnFlow(data.getMtnFlow());
			if (!CartConstants.NSE_BYOD.equalsIgnoreCase(addPromoIntentUIRequest.getCartInfo().getIntendType()) && !CartConstants.NSE.equalsIgnoreCase(addPromoIntentUIRequest.getCartInfo().getIntendType()) && !CartConstants.NSE_5G.equalsIgnoreCase(addPromoIntentUIRequest.getCartInfo().getIntendType()) && StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				addPromoIntentUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());

			return bpmHelper2.addPromoIntent(addPromoIntentUIRequest);
		});
	}

	/**
	 *
	 * @param request
	 * @return UpdatePurchaseOrderUIResponse
	 *
	 */
	public Mono<UpdatePurchaseOrderUIResponse> updatePurchaseOrder(UpdatePurchaseOrderUIRequest request) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			logger.debug(String.format(CartConstants.LOG_REDIS_ACCOUNT_NUMBER, data.getAccountNumber()));
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				request.setCartId(data.getCartId());
			return cxpHelper2.updatePurchaseOrderNo(request);
		});

	}

	/**
	 *
	 * @param add5GBulkOrderUIRequest
	 * @return Add5GBulkOrderUIResponse
	 *
	 */
	public Mono<Add5GBulkOrderUIResponse> add5GBulkOrder(Add5GBulkOrderUIRequest add5GBulkOrderUIRequest) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				add5GBulkOrderUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				add5GBulkOrderUIRequest.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				add5GBulkOrderUIRequest.getCartInfo().setCaseId(data.getCaseId());
			if (StringUtilities.isNotEmptyOrNull(data.getMtn()))
				add5GBulkOrderUIRequest.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(add5GBulkOrderUIRequest.getCartInfo().getProcessingMTN()))
				add5GBulkOrderUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				add5GBulkOrderUIRequest.getCartInfo().setCartCreator(data.getCartCreator());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN()) && null != add5GBulkOrderUIRequest.getData()
					&& CollectionUtilities.isNotEmptyOrNull(add5GBulkOrderUIRequest.getData().getLines())
					&& StringUtilities.isEmptyOrNull(add5GBulkOrderUIRequest.getData().getLines().get(0).getMtn()))
				add5GBulkOrderUIRequest.getData().getLines().get(0).setMtn(data.getProcessingMTN());
			return bpmHelper2.add5GBulkOrder(add5GBulkOrderUIRequest);
		});
	}



	/**
	 *
	 * @param request
	 * @return ManualDiscountUIResponse
	 *
	 */
	public Mono<GiftPurchaseUIResponse> giftPurchase(GiftPurchaseUIRequest request) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			logger.debug(String.format(CartConstants.LOG_REDIS_ACCOUNT_NUMBER, data.getAccountNumber()));
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				request.setCartId(data.getCartId());
			return cxpHelper2.giftPurchase(request);
		});

	}

	/**
	 *
	 * @param manualPairingUIRequest
	 * @return ManualPairingUIResponse
	 *
	 */
	public Mono<ManualPairingUIResponse> manualPairing(ManualPairingUIRequest manualPairingUIRequest) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				manualPairingUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				manualPairingUIRequest.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				manualPairingUIRequest.getCartInfo().setCaseId(data.getCaseId());
			if (StringUtilities.isNotEmptyOrNull(data.getMtn()))
				manualPairingUIRequest.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(manualPairingUIRequest.getCartInfo().getProcessingMTN()))
				manualPairingUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				manualPairingUIRequest.getCartInfo().setCartCreator(data.getCartCreator());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN()) && null != manualPairingUIRequest.getData()
					&& CollectionUtilities.isNotEmptyOrNull(manualPairingUIRequest.getData().getLines())
					&& StringUtilities.isEmptyOrNull(manualPairingUIRequest.getData().getLines().get(0).getMtn()))
				manualPairingUIRequest.getData().getLines().get(0).setMtn(data.getProcessingMTN());
			return bpmHelper3.manualPairing(manualPairingUIRequest);
		});

	}

	/**
	 *
	 * @param revokeRebatesUIRequest
	 * @return RevokeRebatesUIResponse
	 *
	 */
	public Mono<RevokeRebatesUIResponse> revokeRebates(RevokeRebatesUIRequest revokeRebatesUIRequest) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				revokeRebatesUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				revokeRebatesUIRequest.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				revokeRebatesUIRequest.getCartInfo().setCaseId(data.getCaseId());
			if (StringUtilities.isNotEmptyOrNull(data.getMtn()))
				revokeRebatesUIRequest.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(revokeRebatesUIRequest.getCartInfo().getProcessingMTN()))
				revokeRebatesUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				revokeRebatesUIRequest.getCartInfo().setCartCreator(data.getCartCreator());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN()) && null != revokeRebatesUIRequest.getData()
					&& CollectionUtilities.isNotEmptyOrNull(revokeRebatesUIRequest.getData().getLines())
					&& StringUtilities.isEmptyOrNull(revokeRebatesUIRequest.getData().getLines().get(0).getMtn()))
				revokeRebatesUIRequest.getData().getLines().get(0).setMtn(data.getProcessingMTN());
			return bpmHelper2.revokeRebates(revokeRebatesUIRequest);

		});

	}



	/**
	 *
	 * @param portinLaterUIRequest
	 * @return PortinLaterUIResponse
	 *
	 */
	public Mono<PortinLaterUIResponse> updatePortInLater(PortinLaterUIRequest portinLaterUIRequest) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				portinLaterUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				portinLaterUIRequest.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				portinLaterUIRequest.getCartInfo().setCaseId(data.getCaseId());
			if (StringUtilities.isNotEmptyOrNull(data.getMtn()))
				portinLaterUIRequest.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(portinLaterUIRequest.getCartInfo().getProcessingMTN()))
				portinLaterUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				portinLaterUIRequest.getCartInfo().setCartCreator(data.getCartCreator());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN()) && null != portinLaterUIRequest.getData()
					&& CollectionUtilities.isNotEmptyOrNull(portinLaterUIRequest.getData().getLines())
					&& StringUtilities.isEmptyOrNull(portinLaterUIRequest.getData().getLines().get(0).getMtn()))
				portinLaterUIRequest.getData().getLines().get(0).setMtn(data.getProcessingMTN());
			return bpmHelper2.updatePortInLater(portinLaterUIRequest);
		});

	}

	/**
	 *
	 * @param voidOrderUIRequest
	 * @return VoidOrderUIResponse
	 *
	 */
	public Mono<VoidOrderUIResponse> voidOrder(VoidOrderUIRequest voidOrderUIRequest) {
		String channelType = CartUtil.getChannelType(voidOrderUIRequest.getChannelId());
		return redisHelper.getDataFromRedis().flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED)) {
				if(StringUtilities.isNotEmptyOrNull(voidOrderUIRequest.getCartInfo().getIntendType()) && voidOrderUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getCreditAppNum())) {
					voidOrderUIRequest.getCartInfo().setCreditAppNum(data.getCreditAppNum());
					voidOrderUIRequest.getCartInfo().setCartCreator(data.getCreditAppNum());
				}
			}
			if (StringUtilities.isNotEmptyOrNull(voidOrderUIRequest.getCartInfo().getIntendType()) && !voidOrderUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				voidOrderUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				voidOrderUIRequest.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				voidOrderUIRequest.getCartInfo().setCaseId(data.getCaseId());
			if (StringUtilities.isNotEmptyOrNull(voidOrderUIRequest.getCartInfo().getIntendType()) && !voidOrderUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getMtn()))
				voidOrderUIRequest.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(voidOrderUIRequest.getCartInfo().getProcessingMTN()))
				voidOrderUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (StringUtilities.isNotEmptyOrNull(voidOrderUIRequest.getCartInfo().getIntendType()) && !voidOrderUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				voidOrderUIRequest.getCartInfo().setCartCreator(data.getCartCreator());
			return bpmHelper2.voidOrder(voidOrderUIRequest);

		});
	}

	/**
	 *
	 * @param ispuToDfillUIRequest
	 * @return IspuToDfillUIResponse
	 *
	 */
	public Mono<IspuToDfillUIResponse> ispuToDfill(IspuToDfillUIRequest ispuToDfillUIRequest) {
		String channelType = CartUtil.getChannelType(ispuToDfillUIRequest.getChannelId());
		return redisHelper.getDataFromRedis().flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED)) {
				if(StringUtilities.isNotEmptyOrNull(ispuToDfillUIRequest.getCartInfo().getIntendType()) && ispuToDfillUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getCreditAppNum())) {
					ispuToDfillUIRequest.getCartInfo().setCreditAppNum(data.getCreditAppNum());
					ispuToDfillUIRequest.getCartInfo().setCartCreator(data.getCreditAppNum());
				}
			}
			if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				ispuToDfillUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				ispuToDfillUIRequest.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				ispuToDfillUIRequest.getCartInfo().setCaseId(data.getCaseId());
			if (StringUtilities.isNotEmptyOrNull(data.getMtn()))
				ispuToDfillUIRequest.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(ispuToDfillUIRequest.getCartInfo().getProcessingMTN()))
				ispuToDfillUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				ispuToDfillUIRequest.getCartInfo().setCartCreator(data.getCartCreator());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN()) && null != ispuToDfillUIRequest.getData()
					&& CollectionUtilities.isNotEmptyOrNull(ispuToDfillUIRequest.getData().getLines())
					&& StringUtilities.isEmptyOrNull(ispuToDfillUIRequest.getData().getLines().get(0).getMtn()))
				ispuToDfillUIRequest.getData().getLines().get(0).setMtn(data.getProcessingMTN());
			return bpmHelper2.ispuToDfill(ispuToDfillUIRequest);

		});
	}

	/**
	 *
	 * @param request
	 * @return RetrieveURCForCartUIResponse
	 *
	 */
	public Mono<RetrieveURCForCartUIResponse> retrieveURCForCart(RetrieveURCForCartUIRequest request) {
		return redisHelper2.getCartIdFromRedis().flatMap(cartId -> {
			if (StringUtilities.isEmptyOrNull(request.getCartId()) && StringUtilities.isNotEmptyOrNull(cartId))
				request.setCartId(cartId);
			return cxpHelper.retrieveURCForCart(request);
		});
	}

	/**
	 *
	 * @param splitExceededAmountUIRequest
	 * @return UIResponse
	 *
	 */
	public Mono<SplitExceededAmountUIResponse> splitExceededAmount(SplitExceededAmountUIRequest splitExceededAmountUIRequest) {
		String channelType = CartUtil.getChannelType(splitExceededAmountUIRequest.getChannelId());
		return redisHelper.getDataFromRedis().flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED)) {
				if (splitExceededAmountUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE")
						&& StringUtilities.isNotEmptyOrNull(data.getCreditAppNum())) {
					splitExceededAmountUIRequest.getCartInfo().setCreditAppNum(data.getCreditAppNum());
					splitExceededAmountUIRequest.getCartInfo().setCartCreator(data.getCreditAppNum());
				}
			}
			if (!splitExceededAmountUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				splitExceededAmountUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				splitExceededAmountUIRequest.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				splitExceededAmountUIRequest.getCartInfo().setCaseId(data.getCaseId());
			if (!splitExceededAmountUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getMtn()))
				splitExceededAmountUIRequest.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(splitExceededAmountUIRequest.getCartInfo().getProcessingMTN()))
				splitExceededAmountUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (!splitExceededAmountUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				splitExceededAmountUIRequest.getCartInfo().setCartCreator(data.getCartCreator());
			return bpmHelper3.splitExceededAmount(splitExceededAmountUIRequest);
		});
	}

	/**
	 *
	 * @param cancelCaseUIRequest
	 * @return UIResponse
	 *
	 */
	public Mono<CancelCaseUIResponse> cancelCase(CancelCaseUIRequest cancelCaseUIRequest) {
		String channelType = CartUtil.getChannelType(cancelCaseUIRequest.getChannelId());
		return redisHelper.getDataFromRedis().flatMap(data -> {
			
			if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED)) {
				if (StringUtilities.isNotEmptyOrNull(cancelCaseUIRequest.getCartInfo().getIntendType()) && cancelCaseUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE")
						&& StringUtilities.isNotEmptyOrNull(data.getCreditAppNum())) {
					cancelCaseUIRequest.getCartInfo().setCreditAppNum(data.getCreditAppNum());
					cancelCaseUIRequest.getCartInfo().setCartCreator(data.getCreditAppNum());
				}
			}
			
			
			
			if ((StringUtilities.isEmptyOrNull(cancelCaseUIRequest.getCartInfo().getIntendType()) || (StringUtilities.isNotEmptyOrNull(cancelCaseUIRequest.getCartInfo().getIntendType()) && !cancelCaseUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE"))) && StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				cancelCaseUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				cancelCaseUIRequest.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				cancelCaseUIRequest.getCartInfo().setCaseId(data.getCaseId());
			if ((StringUtilities.isEmptyOrNull(cancelCaseUIRequest.getCartInfo().getIntendType()) || (StringUtilities.isNotEmptyOrNull(cancelCaseUIRequest.getCartInfo().getIntendType()) && !cancelCaseUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE"))) && StringUtilities.isNotEmptyOrNull(data.getMtn()))
				cancelCaseUIRequest.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(cancelCaseUIRequest.getCartInfo().getProcessingMTN()))
				cancelCaseUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if ((StringUtilities.isEmptyOrNull(cancelCaseUIRequest.getCartInfo().getIntendType())
					|| (StringUtilities.isNotEmptyOrNull(cancelCaseUIRequest.getCartInfo().getIntendType())
							&& !cancelCaseUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE")))
					&& StringUtilities.isEmptyOrNull(cancelCaseUIRequest.getCartInfo().getCartCreator())
					&& StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				cancelCaseUIRequest.getCartInfo().setCartCreator(data.getCartCreator());
			return bpmHelper3.cancelCase(cancelCaseUIRequest).flatMap(res -> {

				if ( null != res && res.getErrors() == null && StringUtilities.isNotEmptyOrNull(data.getCartId())) {
					Mono<QuotePricingRedisData> quoteData = redisHelper2.getQuotePricingRedisData();

					return quoteData.flatMap(quoteDataList -> {

						if (null != quoteDataList.getQuotePrices() && !quoteDataList.getQuotePrices().isEmpty()) {
							List<QuotePrices> quotePrices = quoteDataList.getQuotePrices();
							logger.info("Quote price data from redis {}", quotePrices);
							quotePrices
									.removeIf(quotePrice -> data.getCartId().equalsIgnoreCase(quotePrice.getCartId()));
							QuotePricingRedisData rr = new QuotePricingRedisData();
							rr.setQuotePrices(quotePrices);
							logger.info("Quote price data after removed for the cartId {}", rr);
							return redisHelper2.upsertQuotePriceIntoRedis(rr).flatMap(resp -> {
								return Mono.just(res);
							});
						}
						return Mono.just(res);
					});
				}
				return Mono.just(res);
			});
		});
	}
	

	/**
	 *
	 * @param request
	 * @return UIResponse
	 *
	 */
	public Mono<CalculateMultilineTaxUIResponse> calculateMultiLineTaxForCart(CalculateMultilineTaxUIRequest request) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			Mono<CalculateMultilineTaxUIResponse> UIResponse = Mono.empty();
			logger.debug(String.format(CartConstants.LOG_REDIS_ACCOUNT_NUMBER, data.getAccountNumber()));
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				request.setCartId(data.getCartId());

			UIResponse = cxpHelper.calculateMultiLineTaxForCart(request);

			return UIResponse.flatMap(resp -> {
				RetrieveCartCXPRequest taxAndDuesRequest = new RetrieveCartCXPRequest();
				CXPRetrieveCartDataVO reqData = new CXPRetrieveCartDataVO();
				reqData.setCartId(request.getCartId());
				reqData.setRetrieveCurrentFeatures(false);
				taxAndDuesRequest.setData(reqData);
				Map<String, String> meta = new HashMap<>();
				meta.put("type", "taxAndDues");
				taxAndDuesRequest.setMeta(meta);
				return cxpHelper.retrieveCart(taxAndDuesRequest).flatMap(taxAndDuesResponse -> {

					Optional.ofNullable(taxAndDuesResponse.getData()).map(CXPRetrieveCartDataVO::getCart)
							.map(CXPCartVO::getOrderDetails).ifPresent(orderDetails -> {
						Double totalDueToday = orderDetails.getTotalDueToday();
						Double totalDueMonthly = orderDetails.getTotalDueMonthly();
						Double totalTaxAmount = 0.0;
						Double orderTotalTax = 0.0;
						if (StringUtilities.isNotEmptyOrNull(orderDetails.getTotalTaxAmount()))
							totalTaxAmount = Double.parseDouble(orderDetails.getTotalTaxAmount());
						if (StringUtilities.isNotEmptyOrNull(
								resp.getData().getCalculateMultiLineTaxForCart().getOrderTotalTax()))
							orderTotalTax = Double.parseDouble(
									resp.getData().getCalculateMultiLineTaxForCart().getOrderTotalTax());
						resp.getData().getCalculateMultiLineTaxForCart()
								.setTotalDueToday(totalDueToday - totalTaxAmount + orderTotalTax);
						resp.getData().getCalculateMultiLineTaxForCart()
								.setTotalDueMonthly(totalDueMonthly - totalTaxAmount + orderTotalTax);
					});
					return Mono.just(resp);
				});

			});

		});

	}

	/**
	 *
	 * @param request
	 * @return UIResponse
	 *
	 */
	public Mono<ValidateBYODToolUIResponse> validateBYODTool(ValidateBYODToolCXPRequest request) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			return cxpHelper.validateBYODTool(request);

		});

	}

	/**
	 *
	 * @param initiateCheckoutUIRequest
	 * @return uiResponse
	 *
	 */
	public Mono<InitiateCheckoutUIResponse> validateCartAndCheckout(InitiateCheckoutUIRequest initiateCheckoutUIRequest) {
		String channelType = CartUtil.getChannelType(initiateCheckoutUIRequest.getChannelId());

			return redisHelper.getDataFromRedis().flatMap(redisData -> {
				if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED)) {
					if ( initiateCheckoutUIRequest.getCartInfo() != null && initiateCheckoutUIRequest.getCartInfo().isFlexV2()) {
						if (StringUtilities.isNotEmptyOrNull(redisData.getCustomerType()) && redisData.getCustomerType().equalsIgnoreCase("N")) {
							if (StringUtilities.isEmptyOrNull(initiateCheckoutUIRequest.getCartInfo().getIntendType())) {
								initiateCheckoutUIRequest.getCartInfo().setIntendType("NSE");
							}
						} else {
							if (StringUtilities.isNotEmptyOrNull(redisData.getAccountNumber()) && StringUtilities.isEmptyOrNull(initiateCheckoutUIRequest.getCartInfo().getAccountNumber())) {
								initiateCheckoutUIRequest.getCartInfo().setAccountNumber(redisData.getAccountNumber());
							}
							if (StringUtilities.isNotEmptyOrNull(redisData.getCartCreator()) && StringUtilities.isEmptyOrNull(initiateCheckoutUIRequest.getCartInfo().getCartCreator())) {
								initiateCheckoutUIRequest.getCartInfo().setCartCreator(redisData.getCartCreator());
							}
						}
					}
					if (StringUtilities.isNotEmptyOrNull(initiateCheckoutUIRequest.getCartInfo().getIntendType()) && initiateCheckoutUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(redisData.getCreditAppNum())) {
						initiateCheckoutUIRequest.getCartInfo().setCreditAppNum(redisData.getCreditAppNum());
						initiateCheckoutUIRequest.getCartInfo().setCartCreator(redisData.getCreditAppNum());
					}

					if (StringUtilities.isNotEmptyOrNull(redisData.getFlowName())) {
						initiateCheckoutUIRequest.getCartInfo().setFlowName(redisData.getFlowName());
					}
				}
			ValidateCartCXPRequest cartCXPRequest = new ValidateCartCXPRequest();

			if (StringUtilities.isEmptyOrNull(initiateCheckoutUIRequest.getCartInfo().getIntendType())
					&& StringUtilities.isNotEmptyOrNull(redisData.getIntendType()))
				initiateCheckoutUIRequest.getCartInfo().setIntendType(redisData.getIntendType());
			if (StringUtilities.isNotEmptyOrNull(initiateCheckoutUIRequest.getCartInfo().getIntendType()) && !initiateCheckoutUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isEmptyOrNull(initiateCheckoutUIRequest.getCartInfo().getAccountNumber())
					&& StringUtilities.isNotEmptyOrNull(redisData.getAccountNumber()))
				initiateCheckoutUIRequest.getCartInfo().setAccountNumber(redisData.getAccountNumber());
			if (StringUtilities.isEmptyOrNull(initiateCheckoutUIRequest.getCartInfo().getCartId())
					&& StringUtilities.isNotEmptyOrNull(redisData.getCartId()))
				initiateCheckoutUIRequest.getCartInfo().setCartId(redisData.getCartId());
			if (StringUtilities.isEmptyOrNull(initiateCheckoutUIRequest.getCartInfo().getCaseId())
					&& StringUtilities.isNotEmptyOrNull(redisData.getCaseId()))
				initiateCheckoutUIRequest.getCartInfo().setCaseId(redisData.getCaseId());
			if (StringUtilities.isNotEmptyOrNull(initiateCheckoutUIRequest.getCartInfo().getIntendType()) && !initiateCheckoutUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isEmptyOrNull(initiateCheckoutUIRequest.getCartInfo().getCartCreator())
					&& StringUtilities.isNotEmptyOrNull(redisData.getMtn()))
				initiateCheckoutUIRequest.getCartInfo().setCartCreator(redisData.getMtn());
			if (StringUtilities.isEmptyOrNull(initiateCheckoutUIRequest.getCartInfo().getProcessingMTN())
					&& StringUtilities.isNotEmptyOrNull(redisData.getProcessingMTN()))
				initiateCheckoutUIRequest.getCartInfo().setProcessingMTN(redisData.getProcessingMTN());
			if (StringUtilities.isNotEmptyOrNull(initiateCheckoutUIRequest.getCartInfo().getIntendType()) && !initiateCheckoutUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isEmptyOrNull(initiateCheckoutUIRequest.getCartInfo().getCartCreator())
					&& StringUtilities.isNotEmptyOrNull(redisData.getCartCreator()))
				initiateCheckoutUIRequest.getCartInfo().setCartCreator(redisData.getCartCreator());
			if (StringUtilities.isNotEmptyOrNull(redisData.getRpsIntent())) {
				initiateCheckoutUIRequest.getCartInfo().setRpsIntent(redisData.getRpsIntent());
			}
			if (StringUtilities.isEmptyOrNull(initiateCheckoutUIRequest.getCartInfo().getFlow())
					&& StringUtilities.isNotEmptyOrNull(redisData.getFlow()))
				initiateCheckoutUIRequest.getCartInfo().setFlow(redisData.getFlow());

			if(CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(initiateCheckoutUIRequest.getChannelId())) && (StringUtilities.isEmptyOrNull(initiateCheckoutUIRequest.getCartInfo().getCaseId()) || StringUtilities.isEmptyOrNull(initiateCheckoutUIRequest.getCartInfo().getCartId()))) {
				InitiateCheckoutUIResponse errorResponse = new InitiateCheckoutUIResponse();
				errorResponse.setErrors(CartPegaRequestErrorsUtil.validateCartIdAndCaseId(initiateCheckoutUIRequest.getCartInfo()));
				return Mono.just(errorResponse);
			}

			cartCXPRequest.setCartId(initiateCheckoutUIRequest.getCartInfo().getCartId());
			cartCXPRequest.setRetrieveCurrentFeatures(true);
			cartCXPRequest.setPageId("CART");
			cartCXPRequest.setIsFWASimplificationEnabled(initiateCheckoutUIRequest.getCartInfo().getIsFWASimplificationEnabled());

			if (StringUtilities.isNotEmptyOrNull(initiateCheckoutUIRequest.getCartInfo().getIntendType()) && initiateCheckoutUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE")) {
				Map<String, String> meta = new HashMap<String, String>();
				meta.put("type", CartConstants.NEW_CUSTOMER_CAMELCASE);
				cartCXPRequest.setMeta(meta);
			}
			//lineactivitytype issue fix
			if ((StringUtilities.isNotEmptyOrNull(initiateCheckoutUIRequest.getCartInfo().getFlow())
					&& initiateCheckoutUIRequest.getCartInfo().getFlow().contains("RF"))
					&& (StringUtilities.isNotEmptyOrNull(initiateCheckoutUIRequest.getCartInfo().getIntendType())
							&& initiateCheckoutUIRequest.getCartInfo().getIntendType().contains("REX"))) {
				cartCXPRequest.setFlow("RF");
			}

			//ACT211-63

			if((StringUtilities.isNotEmptyOrNull(initiateCheckoutUIRequest.getCartInfo().getSkipValidationErrorCodes()))) {
				cartCXPRequest.setSkipValidationErrorCodes(initiateCheckoutUIRequest.getCartInfo().getSkipValidationErrorCodes());
			}

			return cxpHelper.validateCart(cartCXPRequest,null).flatMap(resp -> {
				Boolean showPlanOverageFuturedateMsg = false;
				Boolean showPlanOverageBackdateMsg = false;
				Boolean showChatStoreOrderRestrictionPriceMsg = false;
				CartValidationError carterror = new CartValidationError();
				if (resp != null && resp.getErrors() == null) {
					CXPOrderDetails cxpOrderDetails = Optional
							.ofNullable(resp.getData().getValidateCartAndUpdate().getOrderDetails())
							.orElse(new CXPOrderDetails());
					if(initiateCheckoutUIRequest.getCartInfo().getCaseId().startsWith(CartConstants.SOF) && initiateCheckoutUIRequest.getChannelId()!=null && CartConstants.CHAT_STORE.equalsIgnoreCase(initiateCheckoutUIRequest.getChannelId())) {
						if (cxpOrderDetails.getSubTotalDueToday()!= null && cxpOrderDetails.getSubTotalDueToday() > Integer.parseInt(orderChatStoreRestrictedAmount)) {
							showChatStoreOrderRestrictionPriceMsg = true;
							carterror.setErrorCategory(CartConstants.CART_ERROR);
							carterror.setErrorLevel(CartConstants.BLOCKER);
							carterror.setErrorMessage(CartConstants.CHAT_STORE_ORDER_RESTRICTION_PRICE_MSG);
							cxpOrderDetails.setCartReadyForCheckout(false);
						}
					}
					if (cxpOrderDetails.getEffectiveDateDetails() != null) {
						if (cxpOrderDetails.getEffectiveDateDetails().getOnDemandOverageInd() != null
								&& cxpOrderDetails.getEffectiveDateDetails().getOnDemandAllowed() != null) {
							if ("Y".equalsIgnoreCase(cxpOrderDetails.getEffectiveDateDetails().getOnDemandOverageInd())
									&& cxpOrderDetails.getEffectiveDateDetails().getOnDemandAllowed()) {
								carterror.setErrorCategory("Cart");
								carterror.setErrorLevel("Warning");
								if (cxpOrderDetails.getEffectiveDateDetails().getBackDateAllowed() != null
										&& cxpOrderDetails.getEffectiveDateDetails().getBackDateAllowed()) {
									showPlanOverageBackdateMsg = true;
									carterror.setErrorMessage(CartConstants.PLAN_OVERAGE_BACKDATE_MSG);
								} else {
									showPlanOverageFuturedateMsg = true;
									carterror.setErrorMessage(CartConstants.PLAN_OVERAGE_FUTUREDATE_MSG);
								}
							}
						}
					}

					if (cxpOrderDetails.getCartReadyForCheckout() != null && cxpOrderDetails.getCartReadyForCheckout() && ((null != initiateCheckoutUIRequest.getCartInfo().getSkipWarnings() && initiateCheckoutUIRequest.getCartInfo().getSkipWarnings() ) || !(showPlanOverageBackdateMsg || showPlanOverageFuturedateMsg || showChatStoreOrderRestrictionPriceMsg))) {
						Boolean backdate = showPlanOverageBackdateMsg;
						Boolean futuredate = showPlanOverageFuturedateMsg;
						if(CartConstants.OMNI_CARE.equalsIgnoreCase(initiateCheckoutUIRequest.getChannelId())){
							RetrieveCartHeader cartHeader = Optional.ofNullable(resp.getData().getValidateCartAndUpdate().getCartHeader()).orElse(new RetrieveCartHeader());
							if(null != cartHeader.getIsCoreRep())
								initiateCheckoutUIRequest.getCartInfo().setIsCareRepAssisted(cartHeader.getIsCoreRep());
						}
						return bpmHelper2.validateOrder(initiateCheckoutUIRequest).flatMap(data -> {
							data.setCartReadyForCheckout(cxpOrderDetails.getCartReadyForCheckout());
							data.setShowPlanOverageBackdateMsg(backdate);
							data.setShowPlanOverageFuturedateMsg(futuredate);
							if (null != resp.getData() && null != resp.getData().getValidateCartAndUpdate()
									&& resp.getData().getValidateCartAndUpdate().getCartValidationErrors() != null) {
								List<CartValidationError> cartvalidationerror = resp.getData().getValidateCartAndUpdate()
										.getCartValidationErrors();
								if (cartvalidationerror.stream().anyMatch(p -> CartConstants.INDIRECT_TRADE_WARNING_CODE.equalsIgnoreCase(p.getErrorCode()))) {
									data.setIsIndirectTradeWarningAvailable(true);
								}
							}

                            return Mono.just(data);
                        });

					} else {
						InitiateCheckoutUIResponse newResponse = new InitiateCheckoutUIResponse();
						newResponse.setShowPlanOverageBackdateMsg(showPlanOverageBackdateMsg);
						newResponse.setShowPlanOverageFuturedateMsg(showPlanOverageFuturedateMsg);
						newResponse.setCartReadyForCheckout(cxpOrderDetails.getCartReadyForCheckout());
						if (showPlanOverageBackdateMsg || showPlanOverageFuturedateMsg || showChatStoreOrderRestrictionPriceMsg) {
							if (resp.getData().getValidateCartAndUpdate().getCartValidationErrors() != null) {
								List<CartValidationError> cartvalidationerror = resp.getData().getValidateCartAndUpdate()
										.getCartValidationErrors();
								cartvalidationerror.add(carterror);
								newResponse.setCartValidationErrors(cartvalidationerror);
							}
							else {
								List<CartValidationError> cartvalidationerror = new ArrayList<>();
								cartvalidationerror.add(carterror);
								newResponse.setCartValidationErrors(cartvalidationerror);
							}
					} else{
							// VZWYZDF-1670- Guided Promo Experience -BOGO and Trade-in ErrorCodes

							List<String> restrictedCartValidationErrors = Arrays.asList("1048", "1074", "1070", "1078",
									"1085", "1086", "1087", "1088", "1093", "1094");
							List<CartValidationError> cartValidationErrors = resp.getData().getValidateCartAndUpdate()
									.getCartValidationErrors();
							if (StringUtilities.isNotEmptyOrNull(channelType)
									&& channelType.equalsIgnoreCase(CartConstants.ASSISTED)
									&& StringUtilities.isNotEmptyOrNull(cxpOrderDetails.getCustomerType())
									&& !cxpOrderDetails.getCustomerType().equalsIgnoreCase(CartConstants.NEW_CUSTOMER)
									&& cartValidationErrors!=null
									&& cartValidationErrors.stream().anyMatch(element -> restrictedCartValidationErrors
									.contains(element.getErrorCode()))) {
								List<CartValidationError> finalCartValidationErrors = new ArrayList<>();
								finalCartValidationErrors = cartValidationErrors.stream()
										.filter(p -> ((!restrictedCartValidationErrors.contains(p.getErrorCode()))
												&& ("Blocker".equalsIgnoreCase(p.getErrorLevel()))))
										.collect(Collectors.toList());

								if (finalCartValidationErrors.isEmpty()) {
									logger.debug("finalCartValidationErrors is Empty");
									newResponse.setCartValidationErrors(cartValidationErrors);
								} else if (!finalCartValidationErrors.isEmpty()) {
									logger.debug("finalCartValidationErrors is Not Empty");
									newResponse.setCartValidationErrors(cartValidationErrors.stream()
											.filter(p -> ((!restrictedCartValidationErrors.contains(p.getErrorCode()))))
											.collect(Collectors.toList()));
								}

							} else {
								newResponse.setCartValidationErrors(cartValidationErrors);
							}
						}
						return featureFlagHelper.earlyUpgradeBlockerFeatureFlag().flatMap(earlyUpgradeFeatureFlag -> {
							if (earlyUpgradeFeatureFlag != null && earlyUpgradeFeatureFlag
									&& upgradeErrorMessageForchannelIds.contains(initiateCheckoutUIRequest.getChannelId())
									&& !newResponse.getCartValidationErrors().isEmpty()) {
								checkAndUpdateEarlyUpgradeErrorMessage(newResponse.getCartValidationErrors());
							}
							return Mono.just(newResponse);
						});

					}
				}
				else {
					InitiateCheckoutUIResponse errRes = new InitiateCheckoutUIResponse();
					errRes.setErrors(resp.getErrors());
					return Mono.just(errRes);
				}
			});

		});

	}

	/**
	 * https://onejira.verizon.com/browse/VZWYZDD-2629
	 * Update error message for early upgrade
	 */
	private void checkAndUpdateEarlyUpgradeErrorMessage(List<CartValidationError> cartValidationErrors) {
		for (CartValidationError error : cartValidationErrors) {
			if (CartConstants.EARLY_UPGRADE_BLOCKER_ERROR_CODE.equals(error.getErrorCode())
					&& CartConstants.BLOCKER_CONST.equalsIgnoreCase(error.getErrorLevel())
					&& !CartConstants.STANDALONE_TRADEIN_BLOCKER_ERROR_MESSAGE.equalsIgnoreCase(error.getErrorMessage()))
				error.setErrorMessage(upgradeErrorMessage);
		}
	}

	/**
	 *
	 * @param activateLaterUIRequest
	 * @return ActivateLaterUIResponse
	 *
	 */
	public Mono<ActivateLaterUIResponse> activateOrSetupLater(ActivateLaterUIRequest activateLaterUIRequest) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				activateLaterUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				activateLaterUIRequest.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				activateLaterUIRequest.getCartInfo().setCaseId(data.getCaseId());
			if (StringUtilities.isNotEmptyOrNull(data.getMtn()))
				activateLaterUIRequest.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(activateLaterUIRequest.getCartInfo().getProcessingMTN()))
				activateLaterUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				activateLaterUIRequest.getCartInfo().setCartCreator(data.getCartCreator());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN()) && null != activateLaterUIRequest.getData()
					&& null != activateLaterUIRequest.getData().getLines()
					&& StringUtilities.isEmptyOrNull(activateLaterUIRequest.getData().getLines()[0].getMtn()))
				activateLaterUIRequest.getData().getLines()[0].setMtn(data.getProcessingMTN());
			return bpmHelper3.activateOrSetupLater(activateLaterUIRequest);

		});
	}

	/**
	 *
	 * @param intendType
	 * @return ActivateLaterUIResponse
	 *
	 */
	public Mono<AddDeviceUIRequest> getRequestDetails(String intendType, String deviceId, String contractTerm,
			  Optional<Integer> dppMonths, Optional<String> dacc, Optional<String> depletionLocationCode,
			  Optional<String> depletionType, Optional<String> sddZipCode, Optional<String> preBackOrderDate,
			  Optional<String> preBackOrderDisplayType, Optional<String> promoIntent, Optional<String> selectedPromoId,
			  Optional<String> isHumDevice, Optional<String> e911AddressReqd, Optional<String> numbershareCapable,
			  Optional<String> deviceCategory, Optional<String> deviceFilterType, String deviceProdId, String accountNumber, String mtn,
			  Optional<String> tradeInDeviceBrand,Optional<String> tradeInDeviceModel, Optional<String> aemOfferIds,
			  Optional<String> selectedSedOfferId, Optional<Boolean> isStrategicOffer, Optional<String> restricted,
	          Optional<Boolean> isCommonPDP,Optional<Boolean> isTradeInIntentSelected,Optional<Boolean> isKeepingExistingEqProtection,
			  Optional<String> purchasePath,Optional<Boolean> fromFreePhoneQV, Optional<String> tradeinMarketingId,
			  Optional<String> mhash, ServerHttpRequest httpRequest,Optional<Boolean> isDfoSelected, Optional<String> dfoTerms) {
		
		AddDeviceUIRequest request = new AddDeviceUIRequest();
		AddDeviceTradeInInfo addDeviceTradeInInfo= new AddDeviceTradeInInfo();
		request.setCartInfo(new DeviceCartInfo());
		request.setRequestApiName("add-step");
		return redisHelper.getDataFromRedis().flatMap(data -> {
		
			if (!CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType()) && StringUtilities.isNotEmptyOrNull(data.getAccountNumber())) {
				logger.info("Account number from Redis: {}", data.getAccountNumber());
				request.getCartInfo().setAccountNumber(data.getAccountNumber());
				request.setCustomerId(data.getAccountNumber());
			} else if(!CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType()) ){
				logger.info("Data not in session Redis. Account number from SSO_JWT: {}", accountNumber);
				request.getCartInfo().setAccountNumber(accountNumber);
				request.setCustomerId(accountNumber);
			}
			if (!CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType()) &&StringUtilities.isNotEmptyOrNull(data.getCartCreator())) {
				logger.info("Cart creator from Redis: {}", data.getCartCreator());
				request.getCartInfo().setCartCreator(data.getCartCreator());
			} else if(!CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())){
				logger.info("Data not in session Redis. Cart creator from SSO_JWT: {}", mtn);
				request.getCartInfo().setCartCreator(mtn);
			}
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				request.getCartInfo().setCartId(data.getCartId());
			else
				request.getCartInfo().setCartId("");
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				request.getCartInfo().setCaseId(data.getCaseId());
			else
				request.getCartInfo().setCaseId("");
			if (StringUtilities.isNotEmptyOrNull(data.getMtn()))
				request.setMtn(data.getMtn());
			request.getCartInfo().setClientAppName(CartConstants.VZW_ECOM);
			request.getCartInfo().setCorrelationId("69a66ef4d7e344dfb2db299209ea8333");
			request.getCartInfo().setIntendType(intendType);
			request.getCartInfo().setMtnFlow("G");
			AddDeviceData addDeviceData = new AddDeviceData();
			request.setData(addDeviceData);
			Device device = new Device();
			Lines line = new Lines();
			line.setDevice(device);
			SoftSKUItem sim = new SoftSKUItem();
			line.setSim(sim);
			List<Lines> lines = new ArrayList<>();
			lines.add(line);
			request.getData().setLines(lines);
			if (StringUtilities.isNotEmptyOrNull(deviceProdId)) {
				request.getData().getLines().get(0).getDevice().setProductId(deviceProdId);
			} else {
				request.getData().getLines().get(0).getDevice().setProductId("");
			}
			request.getData().getLines().get(0).getDevice().setId(deviceId);
			request.getData().getLines().get(0).getSim().setId("EMBD4GSIM-N");
			if ("0".equalsIgnoreCase(contractTerm))
				request.getData().getLines().get(0).getDevice().setContractTerm("MONTH_TO_MONTH");
			else if ("99".equalsIgnoreCase(contractTerm) || "VERIZON_EDGE".equalsIgnoreCase(contractTerm))
				request.getData().getLines().get(0).getDevice().setContractTerm("VERIZON_EDGE");
			else
				request.getData().getLines().get(0).getDevice().setContractTerm("TWO_YEAR");
			
			if (dppMonths.isPresent())
				request.getData().getLines().get(0).getDevice().setDppMonths(dppMonths.get());
			else
				request.getData().getLines().get(0).getDevice().setDppMonths(0);
			request.getCartInfo().setProcessStep(CartConstants.GRIDWALL_PDP);
			if (CartConstants.AAL.equalsIgnoreCase(intendType)) {
				request.getData().getLines().get(0).setIsNewLine(true);
				request.getData().getLines().get(0).setNewLineOrAAL(true);
				request.getCartInfo().setProcessAction(CartConstants.ADD_DEVICE);
			} else if (CartConstants.EUP.equalsIgnoreCase(intendType)) {
				request.getData().getLines().get(0).setNewLineOrAAL(false);
				request.getCartInfo().setProcessAction("");
			}
			if(isDfoSelected.isPresent())
			{
				request.getData().getLines().get(0).getDevice().setDfoSelected(isDfoSelected.get());
			}
			if(dfoTerms.isPresent()){
				request.getData().getLines().get(0).getDevice().setDfoTerms(dfoTerms.get());
			}
			if(fromFreePhoneQV.isPresent()){
				request.getCartInfo().setFromFreePhoneQV(fromFreePhoneQV.get());
			}
			if(mhash.isPresent()){
				request.getCartInfo().setMhash(mhash.get());
			}
			if(tradeinMarketingId.isPresent()){
				List<String> offerIds=new ArrayList<>();
				String[] aemOfferId= tradeinMarketingId.get().split(",");
				for (String offerId : aemOfferId) {
					offerIds.add(offerId);
				}
				addDeviceTradeInInfo.setAemOfferIds(offerIds);
				addDeviceTradeInInfo.setTradeinMarketingId(tradeinMarketingId.get());
				request.getData().getLines().get(0).setTradeInInfo(addDeviceTradeInInfo);
			}
			if (depletionLocationCode.isPresent())
				request.getData().getLines().get(0).setIspuFlow(true);
			else
				request.getData().getLines().get(0).setIspuFlow(false);
			
			request.getData().getLines().get(0).setMtn("");
			request.getCartInfo().setProcessingMTN("");
			if (selectedPromoId.isPresent())
				request.getData().getLines().get(0).setSelectedPromoId(selectedPromoId.get());
			else
				request.getData().getLines().get(0).setSelectedPromoId("");
			if (promoIntent.isPresent() && "BOGO".equalsIgnoreCase(promoIntent.get())) {
				String selectedPromoType = "BICBOGO";
				request.getData().getLines().get(0).setSelectedPromoType(selectedPromoType);
			} else if (promoIntent.isPresent() && "TRADEIN".equalsIgnoreCase(promoIntent.get())) {
				String selectedPromoType = "TRADEIN_PROMO";
				request.getData().getLines().get(0).setSelectedPromoType(selectedPromoType);
			} else if (promoIntent.isPresent() && "BOGOHO".equalsIgnoreCase(promoIntent.get())) {
				String selectedPromoType = "BOGOHO";
				request.getData().getLines().get(0).setSelectedPromoType(selectedPromoType);
			} else if (promoIntent.isPresent() && "BMSM".equalsIgnoreCase(promoIntent.get())) {
				String selectedPromoType = "BICBMSM";
				request.getData().getLines().get(0).setSelectedPromoType(selectedPromoType);
			} else if (promoIntent.isPresent() && "BIC".equalsIgnoreCase(promoIntent.get())) {
				String selectedPromoType = "BIC";
				request.getData().getLines().get(0).setSelectedPromoType(selectedPromoType);
			} else if (promoIntent.isPresent() && "PROMO_BUNDLE".equalsIgnoreCase(promoIntent.get())) {
				String selectedPromoType = "PROMO_BUNDLE";
				request.getData().getLines().get(0).setSelectedPromoType(selectedPromoType);
			} else {
				request.getData().getLines().get(0).setSelectedPromoId("");
				request.getData().getLines().get(0).setSelectedPromoType("NOPROMO");
			}
			
			if (selectedSedOfferId.isPresent()){
				request.getData().getLines().get(0).setSelectedSedOfferId(selectedSedOfferId.get());
			}
			if(isStrategicOffer.isPresent()) {
				request.getData().getLines().get(0).setIsStrategicOffer(isStrategicOffer.get());
			}
			if(restricted.isPresent()){
				request.getData().getLines().get(0).setRestricted(restricted.get());
			}
			
			if (depletionType.isPresent())
				request.getData().getLines().get(0).setDepletionType(depletionType.get());
			else {
				if (request.getData().getLines().get(0).getIspuFlow()) {
					request.getData().getLines().get(0).setDepletionType("L");
					request.getData().getLines().get(0).setIspuFlow(true);
				} else {
					request.getData().getLines().get(0).setDepletionType("F");
					request.getData().getLines().get(0).setIspuFlow(false);
				}
			}
			if (request.getData().getLines().get(0).getDepletionType().equalsIgnoreCase("L")) {
				request.getData().getLines().get(0).setIspuFlow(true);
				if (depletionLocationCode.isPresent())
					request.getData().getLines().get(0).setDepletionLocationCode(depletionLocationCode.get());
				else
					request.getData().getLines().get(0).setDepletionLocationCode("");
			} else {
				request.getData().getLines().get(0).setDepletionLocationCode("");
				request.getData().getLines().get(0).setIspuFlow(false);
			}
			if (sddZipCode.isPresent())
				request.getData().getLines().get(0).setSddZipCode(sddZipCode.get());
			else
				request.getData().getLines().get(0).setSddZipCode("");
			request.getData().getLines().get(0).setTriggerPricingValidation(true);
			if (preBackOrderDate.isPresent())
				request.getData().getLines().get(0).setPreBackOrderDate(preBackOrderDate.get());
			else
				request.getData().getLines().get(0).setPreBackOrderDate("");
			if (preBackOrderDisplayType.isPresent())
				request.getData().getLines().get(0).setPreBackOrderDisplayType(preBackOrderDisplayType.get());
			else
				request.getData().getLines().get(0).setPreBackOrderDisplayType("");
			
			if (e911AddressReqd.isPresent() && "true".equalsIgnoreCase(e911AddressReqd.get()))
				request.getCartInfo().setENineAddrIndicator("Y");
			
			if (numbershareCapable.isPresent() && "true".equalsIgnoreCase(numbershareCapable.get()))
				request.getCartInfo().setNumberShareCapable("Y");
			if (deviceFilterType.isPresent())
				request.getData().getLines().get(0).getDevice().setCategory(deviceFilterType.get());
			else if (deviceCategory.isPresent()) {
				boolean isCategory = deviceCategory.get().indexOf("Smartphone") > -1
				|| deviceCategory.get().indexOf("smartphone") > -1;
				if (isCategory) {
					request.getData().getLines().get(0).getDevice().setCategory("Smartphones");
				}
	
			}
			if(isCommonPDP.isPresent()) {
				request.getData().getLines().get(0).setIsCommonPDP(isCommonPDP.get());
			}
			if(isTradeInIntentSelected.isPresent()) {
				request.getData().getLines().get(0).setIsTradeInIntentSelected(isTradeInIntentSelected.get());
			}
			HttpCookie salesRepIdCookie = httpRequest.getCookies().getFirst(CartConstants.COOKIE_SALESREPID);
			String salesRepId = null != httpRequest.getCookies()
					&& null != salesRepIdCookie
					? salesRepIdCookie.getValue()
					: "";
			if(StringUtils.isNotEmpty(salesRepId)){
				request.getCartInfo().setSalesRepId(salesRepId);
				request.getCartInfo().setReferralSaleRepId(salesRepId);
				request.getCartInfo().setCartCreatorSalesRepId(salesRepId);
			}
	
			if(tradeInDeviceBrand.isPresent() && tradeInDeviceModel.isPresent() && aemOfferIds.isPresent()) {
				addDeviceTradeInInfo.setDeviceBrand(tradeInDeviceBrand.get().trim());
				String replacedTradeInDeviceModel= tradeInDeviceModel.get().replace("-", " ").trim();
				addDeviceTradeInInfo.setDeviceModel(replacedTradeInDeviceModel);
				List<String> offerIds=new ArrayList<>();
				String[] aemOfferId= aemOfferIds.get().split(",");
				for (String offerId : aemOfferId) {
					offerIds.add(offerId);
				}
				addDeviceTradeInInfo.setAemOfferIds(offerIds);
				request.getData().getLines().get(0).setTradeInInfo(addDeviceTradeInInfo);				
			}
			if(purchasePath.isPresent()){
				request.getData().getLines().get(0).setPurchasePath(purchasePath.get());
			}
			if(isKeepingExistingEqProtection.isPresent()){
				request.getData().getLines().get(0).setIsKeepingExistingEqProtection(isKeepingExistingEqProtection.get());
			}
			request.getData().setClearCart(true);
			
				return Mono.just(request);
		});
}
	/**
	 *
	 * @param intendType
	 * @return ClearAndContinueUIResponse
	 *
	 */
	public void addStepFlowNameUpdate(String intendType) {
		try {
			logger.info("Inside add-step DL update");
			String flowName = intendType.toLowerCase();
			switch (flowName) {
				case CartConstants.BYOD:
					dlUtilityService.updateDlData(CartConstants.ESO);
					break;
				case CartConstants.NSE_BYOD:
					dlUtilityService.updateDlData(CartConstants.ESO);
					break;
				case CartConstants.S_AAL:
					dlUtilityService.updateDlData(flowName);
					break;
				case CartConstants.S_EUP:
					dlUtilityService.updateDlData(flowName);
					break;

			}

		} catch (Exception e) {
			logger.error(String.format("exception while calling dlUtilityService in add-step %s", e.getMessage()));
		}

	}
	public Mono<ClearAndContinueUIResponse> clearAndContinue(ClearAndContinueUIRequest request) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			Optional.of(data).map(CartRedisData::getUniversalId).filter(StringUtilities::isNotEmptyOrNull).ifPresent(request::setUniversalId);
			if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				request.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				request.getCartInfo().setCartId(data.getCartId());
			//clearAndContinue standalone accessory NSEACC implementation
			if (StringUtilities.isNotEmptyOrNull(data.getProspectCartId()))
				request.getCartInfo().setProspectCartId(data.getProspectCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getIntendType()))
				request.getCartInfo().setIntendType(data.getIntendType());
			//clearAndContinue standalone accessory NSEACC implementation
			util.formatClearAndContinueRequest(request, data);
			return bpmHelper3.clearAndContinue(request).flatMap(cscResp -> {
				return util.formatClearAndContinueUIResponse(cscResp);
			});

		});

	}

	/**
	 *
	 * @param resumeAndContinueUIRequest
	 * @return ResumeAndContinueUIResponse
	 *
	 */
	public Mono<ResumeAndContinueUIResponse> resumeAndContinue(ResumeAndContinueUIRequest resumeAndContinueUIRequest) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				resumeAndContinueUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				resumeAndContinueUIRequest.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				resumeAndContinueUIRequest.getCartInfo().setCaseId(data.getCaseId());
			if (StringUtilities.isNotEmptyOrNull(data.getMtn()))
				resumeAndContinueUIRequest.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(resumeAndContinueUIRequest.getCartInfo().getProcessingMTN()))
				resumeAndContinueUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				resumeAndContinueUIRequest.getCartInfo().setCartCreator(data.getCartCreator());
			if (StringUtilities.isEmptyOrNull(resumeAndContinueUIRequest.getCartInfo().getLocationCode())
					&& StringUtilities.isNotEmptyOrNull(data.getLocationCode()))
				resumeAndContinueUIRequest.getCartInfo().setLocationCode(data.getLocationCode());
			return bpmHelper3.resumeAndContinue(resumeAndContinueUIRequest).flatMap(rscResp -> {
				if (null != rscResp && null != rscResp.getServiceHeader() && null == rscResp.getServiceBody()) {
					List<CartError> errorList = new ArrayList<>();
					if (StringUtilities.isNotEmptyOrNull(rscResp.getServiceHeader().getStatusCode())
							&& "99".equalsIgnoreCase(rscResp.getServiceHeader().getStatusCode())) {
						String message = Optional.ofNullable(rscResp.getServiceHeader().getStatusMsg()).orElse("");
						CartError error = new CartError();
						error.setMessage(message);
						error.setNamespace(CartConstants.SOE_CART_SERVICE);
						error.setCode(CartConstants.INTERNAL_SERVER_ERROR);
						if (CollectionUtilities.isNotEmptyOrNull(rscResp.getErrors()))
							rscResp.getErrors().add(error);
						else
							errorList.add(error);
						redisHelper.deleteCartIdAndCaseIdFromRedis();
					}
					if (CollectionUtilities.isEmptyOrNull(rscResp.getErrors())) {
						rscResp.setErrors(errorList);
					}
				} else {
					Optional.ofNullable(rscResp).map(ResumeAndContinueUIResponse::getServiceBody)
							.map(ResumeAndContinueServiceBody::getServiceResponse)
							.map(ResumeAndContinueServiceResponse::getContext).ifPresent(context -> {
						String caseId = Optional.ofNullable(context.getCaseId()).orElse("");
						Boolean flag = false;
						List<CartError> errorList = new ArrayList<>();
						if (StringUtilities.isEmptyOrNull(caseId)) {
							flag = true;
							CartError error = new CartError();
							error.setMessage("PEGA did not return caseId");
							error.setNamespace(CartConstants.SOE_CART_SERVICE);
							error.setCode(CartConstants.INTERNAL_SERVER_ERROR);
							if (CollectionUtilities.isNotEmptyOrNull(rscResp.getErrors()))
								rscResp.getErrors().add(error);
							else
								errorList.add(error);
							redisHelper.deleteCartIdAndCaseIdFromRedis().subscribeOn(Schedulers.parallel());
						}
						if (null != context.getCartInfo()) {
							String cartId = Optional.ofNullable(context.getCartInfo().getCartId()).orElse("");
							if (StringUtilities.isEmptyOrNull(cartId)) {
								flag = true;
								CartError error = new CartError();
								error.setMessage("PEGA did not return cartId");
								error.setNamespace(CartConstants.SOE_CART_SERVICE);
								error.setCode(CartConstants.INTERNAL_SERVER_ERROR);
								if (CollectionUtilities.isNotEmptyOrNull(rscResp.getErrors()))
									rscResp.getErrors().add(error);
								else
									errorList.add(error);
								redisHelper.deleteCartIdAndCaseIdFromRedis().subscribeOn(Schedulers.parallel());
							}
						}
						if (CollectionUtilities.isEmptyOrNull(rscResp.getErrors()) && flag) {
							rscResp.setErrors(errorList);
						}
					});
				}
				return Mono.just(rscResp);
			});

		});

	}

	/**
	 *
	 * @param redisData
	 * @param cartId
	 * @param caseId
	 * @return soeResponse
	 */
	public Mono<AddDeviceUIResponse> addDeviceClearAndContinue(CartRedisData redisData, String cartId, String caseId, String channelId, ServerHttpResponse httpResponse,CartInfo cartInfo) {
		AddDeviceUIRequest addDeviceUIRequest = CartPegaRequestUtil6.formAddDeviceRequest(redisData, cartId, caseId, channelId, cartInfo);
		return deviceHelper.addDevice(addDeviceUIRequest,httpResponse).flatMap(pegaResponse -> {
			if (pegaResponse.getErrors() == null) {
				CartRedisData rr = new CartRedisData();
				if (addDeviceUIRequest.getCartInfo().getIntendType() != null)
					rr.setIntendType(addDeviceUIRequest.getCartInfo().getIntendType());
				if (pegaResponse.getServiceBody() != null) {
					if (pegaResponse.getServiceBody().getServiceResponse().getContext() != null) {
						rr.setCaseId(pegaResponse.getServiceBody().getServiceResponse().getContext().getCaseId());
						if (pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo() != null) {
							rr.setCartId(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()
									.getCartId());
							if (pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()
									.getLines() != null) {
								Line[] lines = pegaResponse.getServiceBody().getServiceResponse().getContext()
										.getCartInfo().getLines();
								if (null != lines && lines.length > 0
										&& StringUtilities.isNotEmptyOrNull(lines[0].getMtn())) {
									rr.setProcessingMTN(lines[0].getMtn());
								}
							}
						}
						if (pegaResponse.getServiceBody().getServiceResponse().getContext()
								.getShowAALPromoIntercept() != null)
							rr.setShowAALPromoIntercept(pegaResponse.getServiceBody().getServiceResponse().getContext()
									.getShowAALPromoIntercept());
						if (null != pegaResponse.getServiceBody().getServiceResponse().getContext().getContextInfo()) {
							rr.setProcessStep(pegaResponse.getServiceBody().getServiceResponse().getContext()
									.getContextInfo().getProcessStep());
						}
						
						if(null != pegaResponse.getServiceBody().getServiceResponse().getContext().getCustomerInfo() &&
								StringUtilities.isNotEmptyOrNull(pegaResponse.getServiceBody().getServiceResponse().getContext().getCustomerInfo().getExistingCase())) {
							rr.setExistingCase(pegaResponse.getServiceBody().getServiceResponse().getContext().getCustomerInfo().getExistingCase());
						}else {
							rr.setExistingCase(CartConstants.FALSE);
						}

					}
				}
				rr.setLines(addDeviceUIRequest.getData().getLines());
				rr.setDeviceCartInfo(addDeviceUIRequest.getCartInfo());
				return redisHelper.updateDataIntoRedisAsString(rr, DEVICE).flatMap(data -> {
					return Mono.just(pegaResponse);
				});
			}
			return Mono.just(pegaResponse);
		});

	}

	/**
	 *
	 * @param redisData
	 * @param cartId
	 * @param caseId
	 * @return soeResponse
	 */
	public Mono<AddAccessoriesUIResponse> addAccessoryClearAndContinue(CartRedisData redisData, String cartId,
																	   String caseId) {
		AddAccessoriesUIRequest addAccessoriesUIRequest = CartPegaRequestUtil6.formAddAccessoryRequest(redisData, cartId,
				caseId);
		return accessoryHelper.addAccessory(addAccessoriesUIRequest).flatMap(pegaResponse -> {
			if (pegaResponse.getErrors() == null) {
				CartRedisData rr = new CartRedisData();
				if (addAccessoriesUIRequest.getCartInfo().getIntendType() != null)
					rr.setIntendType(addAccessoriesUIRequest.getCartInfo().getIntendType());
				if (pegaResponse.getServiceBody() != null) {
					if (pegaResponse.getServiceBody().getServiceResponse().getContext() != null) {
						rr.setCaseId(pegaResponse.getServiceBody().getServiceResponse().getContext().getCaseId());
						if (pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo() != null) {
							rr.setCartId(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()
									.getCartId());
						}

					}
				}
				List<Lines> lineList = Arrays.asList(addAccessoriesUIRequest.getData().getLines());
				rr.setLines(lineList);
				rr.setAccessoryCartInfo(addAccessoriesUIRequest.getCartInfo());
				return redisHelper.updateDataIntoRedisAsString(rr, CartConstants.ACCESSORY).flatMap(data -> {
					return Mono.just(pegaResponse);
				});
			}
			return Mono.just(pegaResponse);
		});
	}

	/**
	 *
	 * @param validateOffersRequest
	 * @return UIResponse
	 *
	 */
	public Mono<ValidateOffersResponse> validateOffers(ValidateOffersRequest validateOffersRequest) {
		Mono<String> redisData = redisHelper2.getCartIdFromRedis();
		return redisData.flatMap(cartId-> {
			if(StringUtilities.isNotEmptyOrNull(cartId))
				validateOffersRequest.getData().setCartId(cartId);
			return cxpHelper2.validateOffers(validateOffersRequest)/*
															 * .flatMap(offerResp -> { return Mono.just(offerResp); })
															 */;
		});	
	}

	/**
	 *
	 * @param request
	 * @return response
	 */
	public Mono<NBXFeedbackResponse> nbxFeedbackCall(@Valid NBXFeedbackUIRequest request) {

		return redisHelper.getDataFromRedis().flatMap(data -> {
			if (request.getCartInfo() != null && StringUtilities.isEmptyOrNull(request.getCartInfo().getAccountNumber())) {
				if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
					request.getCartInfo().setAccountNumber(data.getAccountNumber());
			}
			return redisHelper.getBVPDataFromRedis().flatMap(bvpData -> {
				List<BVPLine> bvpLines = Optional.ofNullable(bvpData.getLines()).orElse(new ArrayList<BVPLine>());
				for (BVPLine bvpLine : bvpLines) {
					logger.info("bvpLines: {}", bvpLines);
					if (null != bvpLine && request.getData() != null && request.getData().getLines() != null) {
						List<Lines> requestLines = Optional.ofNullable(request.getData().getLines())
								.orElse(new ArrayList<Lines>());
						String requestContractType = "";
						for (Lines requestLine : requestLines) {
							if (null != requestLine.getDevice()
									&& StringUtilities.isNotEmptyOrNull(requestLine.getDevice().getContractTerm()))
								requestContractType = requestLine.getDevice().getContractTerm();

							if (StringUtilities.isNotEmptyOrNull(bvpLine.getMtn())
									&& StringUtilities.isNotEmptyOrNull(requestLine.getMtn()) && bvpLine.getMtn().equalsIgnoreCase(requestLine.getMtn())) {
								if (null != bvpLine.getGetBestValuePromotions() && CollectionUtilities
										.isNotEmptyOrNull(bvpLine.getGetBestValuePromotions().getBestValueOffers())) {
									List<BestValueOffer> bestValueOffer = bvpLine.getGetBestValuePromotions().getBestValueOffers();
									for (BestValueOffer bvOffer : bestValueOffer) {
										List<String> contractTypes = new ArrayList<>();
										if (null != bvOffer)
											contractTypes = Optional.ofNullable(bvOffer.getContractTypes())
													.orElse(new ArrayList<String>());
										if (contractTypes.contains(requestContractType)) {
											logger.info(
													"disposition is VIEWED & contractType in request is one of offer contractTypes. Sending feedback to RTD");
											return redisHelper2.getLoggedInUser().flatMap(userId -> {
												// rtd call
												logger.info("userId: {}", userId);

												NBXFeedbackRequest nbxRequest = nbxService.formatNbxFeedbackRequest(bvpLine,
														request.getCartInfo().getAccountNumber(), userId);

												return nbxService.nbxFeedbackCall(nbxRequest).flatMap(nbxResp -> {
													String req = "";
													String resp = "";
													try {
														req = mapper.writeValueAsString(nbxRequest);
														resp = mapper.writeValueAsString(nbxResp);
													} catch (JsonProcessingException e) {
														logger.error(CartConstants.JSON_PRCSSNG_EXCPTN_STRNG);
													}

													logger.info(
															"NBX feedback called successfully for request {} & response received {}",
															req, resp);
													return Mono.just(nbxResp);
												});

											});
										}
									}
								}
							}
						}
					}
				}
				if (request.getService() != null && request.getService().getServiceBody() != null &&
						request.getService().getServiceBody().getServiceRequest() != null &&
						request.getService().getServiceBody().getServiceRequest().getCustomerInfo() != null &&
						request.getService().getServiceBody().getServiceRequest().getCustomerInfo().getMtnFlow() != null &&
						CartConstants.PROMOBUNDLE.equalsIgnoreCase(request.getService().getServiceBody().getServiceRequest().getCustomerInfo().getMtnFlow())) {
					NBXFeedbackRequest nbxRequest = nbxService.formatNbxPromoFeedbackRequest(request,data);


					return nbxService.nbxFeedbackCall(nbxRequest).flatMap(nbxResp -> {
						String req = "";
						String resp = "";
						try {
							req = mapper.writeValueAsString(nbxRequest);
							resp = mapper.writeValueAsString(nbxResp);
						} catch (JsonProcessingException e) {
							logger.error(CartConstants.JSON_PRCSSNG_EXCPTN_STRNG);
						}

						logger.info(
								"NBX feedback called successfully for request {} & response received {}",
								req, resp);
						return Mono.just(nbxResp);
					});
				}

				logger.info("NBX VIEWED conditions not met. Returning empty response.");
				return Mono.just(new NBXFeedbackResponse());
			});

		});

	}

	/**
	 *
	 * @param updateTransferUpgradeUIRequest
	 * @return resp
	 *
	 */
	public Mono<UpdateTransferUpgradeUIResponse> addTransferUpgrade(UpdateTransferUpgradeUIRequest updateTransferUpgradeUIRequest) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				updateTransferUpgradeUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				updateTransferUpgradeUIRequest.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				updateTransferUpgradeUIRequest.getCartInfo().setCaseId(data.getCaseId());
			if (StringUtilities.isNotEmptyOrNull(data.getMtn()))
				updateTransferUpgradeUIRequest.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(updateTransferUpgradeUIRequest.getCartInfo().getProcessingMTN()))
				updateTransferUpgradeUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				updateTransferUpgradeUIRequest.getCartInfo().setCartCreator(data.getCartCreator());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN()) && null != updateTransferUpgradeUIRequest.getData()
					&& CollectionUtilities.isNotEmptyOrNull(updateTransferUpgradeUIRequest.getData().getLines())
					&& StringUtilities.isEmptyOrNull(updateTransferUpgradeUIRequest.getData().getLines().get(0).getMtn()))
				updateTransferUpgradeUIRequest.getData().getLines().get(0).setMtn(data.getProcessingMTN());
			return bpmHelper3.addTransferUpgrade(updateTransferUpgradeUIRequest);
		});
	}

	/**
	 *
	 * @param request
	 * @return
	 *
	 */
	public Mono<UpdateTransferUpgradeUIResponse> removeTransferUpgrade(UpdateTransferUpgradeUIRequest request) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				request.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				request.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				request.getCartInfo().setCaseId(data.getCaseId());
			if (StringUtilities.isNotEmptyOrNull(data.getMtn()))
				request.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessingMTN()))
				request.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				request.getCartInfo().setCartCreator(data.getCartCreator());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN()) && null != request.getData()
					&& CollectionUtilities.isNotEmptyOrNull(request.getData().getLines())
					&& StringUtilities.isEmptyOrNull(request.getData().getLines().get(0).getMtn()))
				request.getData().getLines().get(0).setMtn(data.getProcessingMTN());
			return bpmHelper3.removeTransferUpgrade(request);

		});
	}
	
	/**
	 *
	 * @param updateBvoOffersUIRequest
	 * @return
	 *
	 */
	public Mono<UpdateBvoOffersUIResponse> removeBvoOffers(UpdateBvoOffersUIRequest updateBvoOffersUIRequest) {
		Mono<BVPRedisData> bvpRedisData = redisHelper.getBVPDataFromRedis();
		Mono<CartRedisData> rr = redisHelper.getDataFromRedis();
		Mono<String> loggedInUser = redisHelper2.getLoggedInUser();
		Mono<RemoveOfferRedisData> removeOfferData = redisHelper2.getRemoveOfferDataIntoRedis();
		return rr.flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				updateBvoOffersUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				updateBvoOffersUIRequest.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				updateBvoOffersUIRequest.getCartInfo().setCaseId(data.getCaseId());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(updateBvoOffersUIRequest.getCartInfo().getProcessingMTN()))
				updateBvoOffersUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				updateBvoOffersUIRequest.getCartInfo().setCartCreator(data.getCartCreator());
			
			return bvpRedisData.flatMap(bvpData -> {
				return loggedInUser.flatMap(loggedInUserData -> {	
				List<BVPLine> bvpLines = Optional.ofNullable(bvpData.getLines()).orElse(new ArrayList<BVPLine>());
				bvpLines.stream().filter(Objects::nonNull).forEach(bvpLine -> {
					List<Lines> requestLines = Optional.ofNullable(updateBvoOffersUIRequest.getData().getLines()).orElse(new ArrayList<Lines>());
					for (Lines requestLine : requestLines) {
						if (StringUtilities.isNotEmptyOrNull(bvpLine.getMtn())
								&& StringUtilities.isNotEmptyOrNull(requestLine.getMtn())
								&& bvpLine.getMtn().equalsIgnoreCase(requestLine.getMtn())) {
							Optional.ofNullable(bvpLine).map(BVPLine::getGetBestValuePromotions)
									.ifPresent(getBestValuePromotions -> {
										getBestValuePromotions.getBestValueOffers().stream().filter(Objects::nonNull)
												.forEach(bvOffer -> {
												// rtd call
														NBXFeedbackRequest nbxRequest = nbxService
																.formatNbxFeedbackRequest(bvpLine,
																		updateBvoOffersUIRequest.getCartInfo().getAccountNumber(),loggedInUserData);
														nbxService.nbxFeedbackCall(nbxRequest)
																.subscribeOn(Schedulers.parallel()).subscribe(nbx -> {
															logger.info(
																	"NBX Request is {} & the response is {}",
																	nbxRequest, nbx);
														});
									});
									});
						}
					}
				});
				return removeOfferData.flatMap(removeOfferRedisData -> {
					
					logger.info("removeOfferRedisData {}",removeOfferRedisData);
					if(removeOfferRedisData!=null && removeOfferRedisData.getLines()!=null && updateBvoOffersUIRequest.getData().getLines() == null)
							updateBvoOffersUIRequest.getData().setLines(removeOfferRedisData.getLines());
					ErrorResponse errors = CartPegaRequestErrorsUtil.handleRemoveBvoOffersRequestErrors(updateBvoOffersUIRequest);
					if (errors != null && errors.getErrors() != null) {
						UpdateBvoOffersUIResponse errorResponse = new UpdateBvoOffersUIResponse();
						errorResponse.setErrors(errors.getErrors());
                        return Mono.just(errorResponse);
					}
				
				return bpmHelper3.removeBvoOffers(updateBvoOffersUIRequest).flatMap(removeBvoOfferResponse ->{
					return redisHelper2.deleteRemoveOfferDataFromRedis(CartConstants.REMOVEOFFERREDISDATA).flatMap(deletedData->{
					return redisHelper2.getRemoveOfferDataIntoRedis().flatMap(ss->{
						return Mono.just(removeBvoOfferResponse);
					});
					});
				});
			});
			});
			});
		});
	}

	/**
	 *
	 * @param addNickNameUIRequest
	 * @return AddNickNameUIResponse
	 *
	 */
	public Mono<AddNickNameUIResponse> addNickName(AddNickNameUIRequest addNickNameUIRequest) {
		String channelType = CartUtil.getChannelType(addNickNameUIRequest.getChannelId());
		return redisHelper.getDataFromRedis().flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED)) {
				if(StringUtilities.isNotEmptyOrNull(addNickNameUIRequest.getCartInfo().getIntendType()) && addNickNameUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getCreditAppNum())) {
					addNickNameUIRequest.getCartInfo().setCreditAppNum(data.getCreditAppNum());
					addNickNameUIRequest.getCartInfo().setCartCreator(data.getCreditAppNum());
				}
			}
			if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				addNickNameUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				addNickNameUIRequest.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				addNickNameUIRequest.getCartInfo().setCaseId(data.getCaseId());
			if (StringUtilities.isNotEmptyOrNull(data.getMtn()))
				addNickNameUIRequest.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(addNickNameUIRequest.getCartInfo().getProcessingMTN()))
				addNickNameUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				addNickNameUIRequest.getCartInfo().setCartCreator(data.getCartCreator());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN()) && null != addNickNameUIRequest.getData()
					&& CollectionUtilities.isNotEmptyOrNull(addNickNameUIRequest.getData().getLines())
					&& StringUtilities.isEmptyOrNull(addNickNameUIRequest.getData().getLines().get(0).getMtn()))
				addNickNameUIRequest.getData().getLines().get(0).setMtn(data.getProcessingMTN());
			return bpmHelper3.addNickName(addNickNameUIRequest);
		});

	}

	/**
	 * Email cart to customer.
	 *
	 * @param request the request
	 * @return EmailCartToCustomerUIResponse Signals that an I/O exception has
	 *         occurred.
	 */
	public Mono<EmailCartToCustomerUIResponse> emailCartToCustomer(EmailCartToCustomerUIRequest request) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				request.setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(request.getProcessingMTN()))
				request.setProcessingMTN(data.getProcessingMTN());
			return bpmHelper3.emailCartToCustomer(request);
		});

	}

	/**
	 *
	 * @param request
	 * @return UIResponse
	 *
	 */
	public Mono<CustomerByMtnListUIResponse> customerByMtnList(CustomerByMtnListUIRequest request) {
		return cxpHelper2.customerByMtnList(request);
	}

	/**
	 *
	 * @param request
	 * @return VZCCAppStatusUIResponse
	 *
	 */
	public Mono<VZCCAppStatusUIResponse> updateVZCCAppStatus(VZCCAppStatusUIRequest request) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				request.setCartId(data.getCartId());
			if(data.getIntendType() != null && CartConstants.NSE.equalsIgnoreCase(data.getIntendType()))
				request.setIntentType(CartConstants.NSE);
			return cxpHelper2.updateVZCCAppStatus(request);
		});
	}


	/**
	 *
	 * @param updateChatIdUIRequest
	 * @return UpdateChatIdUIResponse
	 *
	 */
	public Mono<UpdateChatIdUIResponse> updateChatId(UpdateChatIdUIRequest updateChatIdUIRequest) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(updateChatIdUIRequest.getCartInfo().getIntendType()) &&
					!updateChatIdUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				updateChatIdUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				updateChatIdUIRequest.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				updateChatIdUIRequest.getCartInfo().setCaseId(data.getCaseId());
			if (StringUtilities.isNotEmptyOrNull(data.getMtn()))
				updateChatIdUIRequest.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(updateChatIdUIRequest.getCartInfo().getProcessingMTN()))
				updateChatIdUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());

			if(StringUtilities.isNotEmptyOrNull(updateChatIdUIRequest.getCartInfo().getIntendType()) &&
					updateChatIdUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") &&
					StringUtilities.isNotEmptyOrNull(data.getCreditAppNum())) {
				updateChatIdUIRequest.getCartInfo().setCreditAppNum(data.getCreditAppNum());
				updateChatIdUIRequest.getCartInfo().setCartCreator(data.getCreditAppNum());
			}


			return bpmHelper3.updateChatId(updateChatIdUIRequest);
		});

	}

	/**
	 *
	 * @param clearCartUIRequest
	 * @return response
	 *
	 */
	public Mono<ClearCartUIResponse> clearCart(ClearCartUIRequest clearCartUIRequest) {
		Mono<CartRedisData> rr = redisHelper.getDataFromRedis();
		String channelType = CartUtil.getChannelType(clearCartUIRequest.getChannelId());
		return rr.flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED)) {
				if(StringUtilities.isNotEmptyOrNull(clearCartUIRequest.getCartInfo().getIntendType()) && clearCartUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getCreditAppNum())) {
					clearCartUIRequest.getCartInfo().setCreditAppNum(data.getCreditAppNum());
					clearCartUIRequest.getCartInfo().setCartCreator(data.getCreditAppNum());
				}
			}
			if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				clearCartUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				clearCartUIRequest.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				clearCartUIRequest.getCartInfo().setCaseId(data.getCaseId());
			if (StringUtilities.isNotEmptyOrNull(data.getMtn()))
				clearCartUIRequest.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(clearCartUIRequest.getCartInfo().getProcessingMTN()))
				clearCartUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			
			// Setting exchange shop details required for RFEX
			if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(clearCartUIRequest.getChannelId()))
					&& CartConstants.REX.equalsIgnoreCase(clearCartUIRequest.getCartInfo().getIntendType())
					&& StringUtilities.isNotEmptyOrNull(data.getRfexExchangeShopDetails())) {
				RfexExchangeShopDetails rfexExchangeShopDetails = gson.fromJson(data.getRfexExchangeShopDetails(),
						RfexExchangeShopDetails.class);
				logger.info("Shop Details available from cache {}", rfexExchangeShopDetails);
				clearCartUIRequest.setRfexExchangeShopDetails(rfexExchangeShopDetails);
			}

			return bpmHelper3.clearCart(clearCartUIRequest,data.getIsSmartphone()).flatMap(response -> {
				if(!CartPegaRequestUtil9.isXboxInClearCartRequest(clearCartUIRequest)) {
					redisHelper.deleteAddDeviceDataFromRedis(CartConstants.ADD_DEVICE_REQUEST);
				}
				return Mono.just(response);
			});
		});
	}

	/**
	 *
	 * @param updateWFMInfoUIRequest
	 * @return UpdateWFMInfoUIResponse
	 *
	 */
	public Mono<UpdateWFMInfoUIResponse> updateWFMInfo(UpdateWFMInfoUIRequest updateWFMInfoUIRequest) {
		try {
			return redisHelper.getDataFromRedis().flatMap(data -> {
				if (null != updateWFMInfoUIRequest.getCartInfo()) {
					if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
						updateWFMInfoUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
					if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
						updateWFMInfoUIRequest.getCartInfo().setCartId(data.getCartId());
					if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
						updateWFMInfoUIRequest.getCartInfo().setCaseId(data.getCaseId());
					if (StringUtilities.isNotEmptyOrNull(data.getMtn()))
						updateWFMInfoUIRequest.getCartInfo().setCartCreator(data.getMtn());
					if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
							&& StringUtilities.isEmptyOrNull(updateWFMInfoUIRequest.getCartInfo().getProcessingMTN()))
						updateWFMInfoUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
					if (StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
						updateWFMInfoUIRequest.getCartInfo().setCartCreator(data.getCartCreator());
					if (StringUtilities.isEmptyOrNull(updateWFMInfoUIRequest.getCartInfo().getCartCreator())) {
						if (null != updateWFMInfoUIRequest.getData() && null != updateWFMInfoUIRequest.getData().getWfmOrderInfo() && StringUtilities.isNotEmptyOrNull(updateWFMInfoUIRequest.getData().getWfmOrderInfo().getWfmOrderId()))
							updateWFMInfoUIRequest.getCartInfo().setCartCreator("WFM-" + updateWFMInfoUIRequest.getData().getWfmOrderInfo().getWfmOrderId());
					}
					if (StringUtilities.isNotEmptyOrNull(updateWFMInfoUIRequest.getCartInfo().getIntendType()) &&
							updateWFMInfoUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE")) {
						updateWFMInfoUIRequest.getCartInfo().setAccountNumber("");
						if (StringUtilities.isNotEmptyOrNull(data.getCreditAppNum())) {
							updateWFMInfoUIRequest.getCartInfo().setCreditAppNum(data.getCreditAppNum());
							updateWFMInfoUIRequest.getCartInfo().setCartCreator(data.getCreditAppNum());
						}
					}
				}

				return bpmHelper3.updateWFMInfo(updateWFMInfoUIRequest).flatMap(response -> {
					return redisHelper3.updateWFMFlowDataInRedis(data.getMtn(), data.getCartCreator(), (null != updateWFMInfoUIRequest.getCartInfo() && null != updateWFMInfoUIRequest.getCartInfo().getIntendType()) ? updateWFMInfoUIRequest.getCartInfo().getIntendType() : "", (null != updateWFMInfoUIRequest.getCartInfo() && null != updateWFMInfoUIRequest.getCartInfo().getCartCreator()) ? updateWFMInfoUIRequest.getCartInfo().getCartCreator() : "").flatMap(resp -> {
						return Mono.just(response);
					});
				});
			});
		} catch(Exception e) {
			logger.error("Exception in updateWFMInfo", e);
			UpdateWFMInfoUIResponse errorResponse = new UpdateWFMInfoUIResponse();
			CartError cartError = new CartError();
			cartError.setMessage("Failure in updating WFM Info : " + e.getMessage());
			errorResponse.setErrors(Arrays.asList(cartError));
			return Mono.just(errorResponse);
		}
	}

	/**
	 *
	 * @param channelId
	 * @return soeResponse
	 */
	public Mono<MyOffersCXPResponse> updateMyOffers(String channelId) {
		Mono<RTDRedisData> rtdRedisData = redisHelper2.getRTDOfferDataFromRedis();
		return rtdRedisData.flatMap(rtdData -> {
			return redisHelper2.getCartIdFromRedis().flatMap(cartId -> {
				if (StringUtilities.isEmptyOrNull(rtdData.getCartId()) && StringUtilities.isNotEmptyOrNull(cartId))
					rtdData.setCartId(cartId);
				MyOffersCXPRequest cxpRequest = CartCxpRequestUtil.formMyOffersRequest(rtdData, channelId);
				return cxpHelper2.updateMyOffers(cxpRequest).flatMap(tran -> {
					return Mono.just(tran);
				});
			});
		});
	}

	private void logE911Address(ServiceAddress address) {
		String logMsg = "";
		if (null != address.getAddress()) {
			try {
				logMsg = mapper.writeValueAsString(address.getAddress());
			} catch (JsonProcessingException e) {
				logger.error("E911Address could not be parsed: {}", e);
			}
		}
		if (StringUtilities.isNotEmptyOrNull(logMsg))
			logger.info("E911Address: {}", logMsg);
	}




	/**
	 *
	 * @param request
	 * @return UpdateTradeInOfferUIResponse
	 *
	 */
	
	public Mono<UpdateTradeInOfferUIResponse> updateTradeInOffer(UpdateTradeInOfferUIRequest request) {
		Mono<BVPRedisData> bvpRedisData = redisHelper.getBVPDataFromRedis();

		return redisHelper.getDataFromRedis().flatMap(data -> {
			logger.debug(String.format("Calling cxp helper with cartId %s", data.getCartId()));
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				request.setCartId(data.getCartId());

			return cxpHelper2.updateTradeInOffer(request).flatMap(tradeInOffer -> {

				if (null != tradeInOffer.getData()
						&& StringUtilities.isNotEmptyOrNull(tradeInOffer.getData().getStatusMsg())) {
					Boolean tradeInAccepted = CartConstants.STATUS_SUCCESS.equalsIgnoreCase(tradeInOffer.getData().getStatusMsg())
							? request.getIsTradeInOfferSelected()
							: false;

					return bvpRedisData.flatMap(bvpData -> {

						BVPRedisData rr = new BVPRedisData();
						if (null != bvpData.getLines() && !bvpData.getLines().isEmpty()) {
							List<BVPLine> line = bvpData.getLines();

							for (BVPLine lines : line) {
								if (null != lines.getGetBestValuePromotions()
										&& lines.getGetBestValuePromotions().getBestValueOffers() != null
										&& !lines.getGetBestValuePromotions().getBestValueOffers().isEmpty()) {

									for (BestValueOffer bestValueOffer : lines.getGetBestValuePromotions()
											.getBestValueOffers()) {

										if ("Trade".equalsIgnoreCase(bestValueOffer.getOfferSubType())) {

											bestValueOffer.setTradeInAccepted(tradeInAccepted);
											tradeInOffer.getData().setStatusMsg(CartConstants.STATUS_SUCCESS);
										}
									}
								}
							}
							rr.setLines(line);

							return redisHelper2.upsertBVPTradeInOFferIntoRedis(rr).flatMap(res -> {
								return Mono.just(tradeInOffer);
							});
						}

						return Mono.just(tradeInOffer);

					});

				}

				return Mono.just(tradeInOffer);
			});
		});

	}
	public Mono<DeviceSimDetailsUIResponse> initiateBBPFlow(CartRedisData data) {

		return cxpHelper2.initiateBBPFlow(data);
	}

	/**
	 *
	 * @param accountNum
	 * @return
	 */
	public Mono<CustomerProfileCXPResponse> customerProfileDigital(String accountNum){
		return cxpHelper2.customerProfileDigital(accountNum);
	}

	public void updateDLData(String sessionID,String globalId, CartServiceCustomerInfo customerInfo){
		OmniDLDataBuilder data = OmniBuilder.fromNewCustomer(sessionID, globalId, customerInfo);
		if(data!=null && data.getOmniDLData()!=null)
			logger.info(data.getOmniDLData().toString());
		dlService.buildDLData(data);
	}
	/**
	 *
	 * @param accountPinUIRequest
	 * @return AccountpinUIResponse
	 *
	 */
	public Mono<AccountPinUIResponse> updateAccountPin(AccountPinUIRequest accountPinUIRequest) {
		String channelType = CartUtil.getChannelType(accountPinUIRequest.getChannelId());
		return redisHelper.getDataFromRedis().flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED)) {
				if(StringUtilities.isNotEmptyOrNull(accountPinUIRequest.getCartInfo().getIntendType()) && accountPinUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getCreditAppNum())) {
					accountPinUIRequest.getCartInfo().setCreditAppNum(data.getCreditAppNum());
					accountPinUIRequest.getCartInfo().setCartCreator(data.getCreditAppNum());
				}
			}
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				accountPinUIRequest.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				accountPinUIRequest.getCartInfo().setCaseId(data.getCaseId());

			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(accountPinUIRequest.getCartInfo().getProcessingMTN()))
				accountPinUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				accountPinUIRequest.getCartInfo().setCartCreator(data.getCartCreator());
			return bpmHelper3.updateAccountPin(accountPinUIRequest);

		});
	}

	public Mono<SalesOrderAdjustmentUIResponse> salesOrderAdjustment(SalesOrderAdjustmentUIRequest salesOrderAdjustmentUIRequest) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber())) {
				salesOrderAdjustmentUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
			} else {
				boolean isChannelIdRetail = (StringUtilities.isNotEmptyOrNull(salesOrderAdjustmentUIRequest.getChannelId()) && salesOrderAdjustmentUIRequest.getChannelId().toUpperCase().contains("RETAIL"));
				boolean isIntendTypeRex = (StringUtilities.isNotEmptyOrNull(salesOrderAdjustmentUIRequest.getCartInfo().getIntendType()) && CartConstants.REFUND_EXCHANGE.equalsIgnoreCase(salesOrderAdjustmentUIRequest.getCartInfo().getIntendType()));
				if (isChannelIdRetail && isIntendTypeRex) {
					salesOrderAdjustmentUIRequest.getCartInfo().setAccountNumber(CartConstants.SOA_ZERO_ACCNUM);
				}
			}
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				salesOrderAdjustmentUIRequest.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				salesOrderAdjustmentUIRequest.getCartInfo().setCaseId(data.getCaseId());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(salesOrderAdjustmentUIRequest.getCartInfo().getProcessingMTN()))
				salesOrderAdjustmentUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());

			return bpmHelper3.salesOrderAdjustment(salesOrderAdjustmentUIRequest);
		});

	}

	public Mono<BbpGetProcessStepUIResponse> bbpGetProcessStep(BBPGetProcessStepUIRequest bBPGetProcessStepUIRequest) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			if(StringUtilities.isNotEmptyOrNull(data.getAccountNumber())) {
				bBPGetProcessStepUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
			}
			if(StringUtilities.isNotEmptyOrNull(data.getCartId())) {
				bBPGetProcessStepUIRequest.getCartInfo().setCartId(data.getCartId());
			}
			if(StringUtilities.isNotEmptyOrNull(data.getCaseId())) {
				bBPGetProcessStepUIRequest.getCartInfo().setCaseId(data.getCaseId());
			}
			if(StringUtilities.isNotEmptyOrNull(data.getCartCreator())){
				bBPGetProcessStepUIRequest.getCartInfo().setCartCreator(data.getCartCreator());
			}
			if(StringUtilities.isNotEmptyOrNull(data.getDeviceType())){
				bBPGetProcessStepUIRequest.getCartInfo().setDeviceType(data.getDeviceType());
			}
			return bpmHelper.bbpGetProcessStep(bBPGetProcessStepUIRequest);

		});
	}

	/**
	 *
	 * @param request
	 * @return UpdateTradeInOfferUIResponse
	 *
	 */
	public Mono<AddZipcodeRedisData> addZipcode(AddZipCodeUIRequest request) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			logger.debug("Calling cxp helper with cartId {}", data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				request.setCartId(data.getCartId());
			return cxpHelper2.addZipcode(request);
		});

	}


	public Mono<ResponseEntity<GenericResponse>> populateCustomerProfileCookieIfPresent(ServerHttpResponse httpResponse, String accountNumber, GenericResponse pegaResponse) {
		return this.customerProfileDigital(accountNumber)
				.flatMap(eCode -> {
					if (null != eCode.getData()
							&& null != eCode.getData().getMostRecentSalesRepCustomerData()) {
						MostRecentSalesRepCustomerDataResponse salesRepData = eCode.getData()
								.getMostRecentSalesRepCustomerData();
						if (StringUtilities.isNotEmptyOrNull(salesRepData.getEcode())) {
							httpResponse.addCookie(
									ResponseCookie.from("RepIdCookieText", salesRepData.getEcode())
											.maxAge(Duration.ofDays(30)).httpOnly(true).secure(true)
											.build());
							httpResponse.addCookie(
									ResponseCookie.from("MyLinkSalesDomain", "persistEcode")
											.maxAge(Duration.ofDays(30)).httpOnly(true).secure(true)
											.build());
						}
					}
					return Mono.just(
							ResponseEntity.status(httpResponse.getStatusCode()).body(pegaResponse));
				});

	}

	public Mono<ResponseEntity<GenericResponse>> populateConflictedSPOsIfPresent(AddDeviceUIRequest request, AddDeviceUIResponse pegaResponse) {
		try {
			if (isSPOPresentInCartInfo(pegaResponse)) {
				return this.populateSPOsFor5GBolt(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo(),pegaResponse);
			}
		}
		catch (Exception e){
			logger.info(CartConstants.LOG_FAIL_SPOS_REDIS);
		}
		return Mono.just(
				ResponseEntity.status(HttpStatus.OK)
						.body(pegaResponse));
	}

	@SuppressWarnings("java:S2259")
	private boolean isSPOPresentInCartInfo(AddDeviceUIResponse pegaResponse) {
		return Optional.ofNullable(pegaResponse).isPresent() &&
				Optional.ofNullable(pegaResponse.getServiceBody()).isPresent() &&
				Optional.ofNullable(pegaResponse.getServiceBody().getServiceResponse()).isPresent() &&
				Optional.ofNullable(pegaResponse.getServiceBody().getServiceResponse().getContext()).isPresent() &&
				Optional.ofNullable(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()).isPresent() &&
				Optional.ofNullable(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getLines()).isPresent() &&
				Arrays.stream(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getLines()).
						filter(line -> Objects.nonNull(line)).findFirst()
						.isPresent();
	}

	public Mono<ResponseEntity<GenericResponse>> populateSPOs(CartServiceCartInfo cartInfo, GenericResponse pegaResponse) {
		try {
			List<ConflictedSPO> spoList = new ArrayList<ConflictedSPO>();
			Arrays.stream(cartInfo.getLines()).
					filter(line -> Objects.nonNull(line) && Objects.nonNull(line.getSpos())).findFirst().ifPresent(line ->
			{
				spoList.addAll(Arrays.stream(line.getSpos()).
						filter(spo -> Objects.nonNull(spo)).collect(Collectors.toList()));
			});
			if (CollectionUtils.isNotEmpty(spoList)) {
				ConflictedSPOs conflictedSPO = new ConflictedSPOs();
				conflictedSPO.setConflictedSPOs(spoList);
				return redisHelper.updateSPOsIntoRedis(conflictedSPO)
						.flatMap(updateConflictedSpo -> {
							logger.info("Successfully Updated Conflicted SPOS in Redis");
							return Mono.just(
									ResponseEntity.status(HttpStatus.OK)
											.body(pegaResponse));
						});
			}
		}
		catch (Exception e){
			logger.info(CartConstants.LOG_FAIL_SPOS_REDIS);
		}
		return Mono.just(
				ResponseEntity.status(HttpStatus.OK)
						.body(pegaResponse));
	}

	public Mono<ResponseEntity<GenericResponse>> populateSPOsFor5GBolt(CartServiceCartInfo cartInfo, GenericResponse pegaResponse) {
		try {
			List<ConflictedSPO> spoList = new ArrayList<ConflictedSPO>();
			Arrays.stream(cartInfo.getLines()).
					filter(line -> Objects.nonNull(line) && Objects.nonNull(line.getSpos())).findFirst().ifPresent(line ->
			{
				spoList.addAll(Arrays.stream(line.getSpos()).
						filter(spo -> Objects.nonNull(spo) && Objects.nonNull(spo.getIs5GBolt()) &&
								spo.getIs5GBolt()).collect(Collectors.toList()));
			});
			if (CollectionUtils.isNotEmpty(spoList)) {
				ConflictedSPOs conflictedSPO = new ConflictedSPOs();
				conflictedSPO.setConflictedSPOs(spoList);
				return redisHelper.updateSPOsIntoRedis(conflictedSPO)
						.flatMap(updateConflictedSpo -> {
							logger.info("Successfully Updated Conflicted SPOS in Redis");
							return Mono.just(
									ResponseEntity.status(HttpStatus.OK)
											.body(pegaResponse));
						});
			}
		}
		catch (Exception e){
			logger.info(CartConstants.LOG_FAIL_SPOS_REDIS);
		}
		return Mono.just(
				ResponseEntity.status(HttpStatus.OK)
						.body(pegaResponse));
	}

	public Mono<ResponseEntity<GenericResponse>> populateHumWifiConflictedSFos(CartServiceCartInfo cartInfo, GenericResponse pegaResponse) {
		try {
			List<ConflictedSFO> sfoList = new ArrayList<ConflictedSFO>();
			Arrays.stream(cartInfo.getLines()).
					filter(line -> Objects.nonNull(line) && Objects.nonNull(line.getSfos())).findFirst().ifPresent(line ->
			{
				sfoList.addAll(Arrays.stream(line.getSfos()).
						filter(sfo -> Objects.nonNull(sfo) && Objects.nonNull(sfo.getDisplayHumWiFi())
								&& sfo.getDisplayHumWiFi()).collect(Collectors.toList()));
			});
			if (CollectionUtils.isNotEmpty(sfoList)) {
				ConflictedSFOs conflictedSFO = new ConflictedSFOs();
				conflictedSFO.setConflictedSFOs(sfoList);
				return redisHelper.updateSFOsIntoRedis(conflictedSFO)
						.flatMap(updateConflictedSpo -> {
							logger.info("Successfully Updated Conflicted SFOS for HumWifi in Redis");
							return Mono.just(ResponseEntity.status(HttpStatus.OK)
									.body(pegaResponse));
						});
			}

		} catch (Exception e) {
			logger.info("Failure in Updating SFOS in Redis");
		}
		return Mono.just(
				ResponseEntity.status(HttpStatus.OK)
						.body(pegaResponse));
	}

	public Mono<ResponseEntity<GenericResponse>> populateProtectionVersion(AddFeaturesUIRequest request, GenericResponse pegaResponse) {
		if(StringUtils.isNotEmpty(request.getCartInfo().getIntendType()) &&
				"NSE".equalsIgnoreCase(request.getCartInfo().getIntendType()) && StringUtils.isNotEmpty(request.getCartInfo().getProtectionVersion())) {
			return redisHelper.updateProtectionVersionInRedis(request.getCartInfo().getProtectionVersion())
					.flatMap(response -> {
						logger.info("Successfully Updated ProtectionVersion in Redis");
						return Mono.just(ResponseEntity.status(HttpStatus.OK)
								.body(pegaResponse));
					});
		} else {
			return Mono.just(
					ResponseEntity.status(HttpStatus.OK)
							.body(pegaResponse));
		}
	}
	public void setFlowInResponse(String flow,AddFeaturesUIResponse pegaResponse){

		boolean isResponseNotNull = null != pegaResponse.getServiceBody() && null != pegaResponse.getServiceBody().getServiceResponse()
				&& null != pegaResponse.getServiceBody().getServiceResponse().getContext()
				&& null != pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo();

		if(isResponseNotNull){
			pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setFlow(flow);
		}
	}
	public Mono<ResponseEntity<GenericResponse>> updateFlowNameForAssisted(AddFeaturesUIRequest request, AddFeaturesUIResponse pegaResponse) {
		 return featureFlagHelper.fetchAssistedTaggingFeatureFlag().flatMap(bmsmFeatureFlag -> {
			 if(bmsmFeatureFlag != null && bmsmFeatureFlag) {
				 if (StringUtilities.isNotEmptyOrNull(request.getChannelId()) &&
						 CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId())) ) {
					 try {
						 return dlHelper.setFlow(request.getFlowName(), "FEA").flatMap(response -> {
							 logger.info("Successfully Updated ProtectionVersion in Redis");
							 if(StringUtilities.isNotEmptyOrNull(response)){
								 setFlowInResponse(response, pegaResponse);
							 }

							 return Mono.just(ResponseEntity.status(HttpStatus.OK)
									 .body(pegaResponse));
						 });

					 } catch (Exception e) {
						 logger.info("Exception in updating Conflicts to session : {}", e.getMessage());
					 }
				 }
			 }
			 return Mono.just(
					 ResponseEntity.status(HttpStatus.OK)
							 .body(pegaResponse));
		 });

    }
	public Mono<ResponseEntity<GenericResponse>> populateHumWifiConflictedSFosWithCheck(AddDeviceUIRequest request, AddDeviceUIResponse pegaResponse) {
		try {
			if(isSPOPresentInCartInfo(pegaResponse)) {
				return this.populateHumWifiConflictedSFos(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo(),pegaResponse);
			}
		} catch (Exception e) {
			logger.info("Failure in Updating SFOS in Redis");
		}
		return Mono.just(
				ResponseEntity.status(HttpStatus.OK)
						.body(pegaResponse));

	}

	public Mono<UpdateManualDiscountUIResponse> addManualDiscount(UpdateManualDiscountUIRequest request) {
		String channelType = CartUtil.getChannelType(request.getChannelId());
		return redisHelper.getDataFromRedis().flatMap(data -> {
			logger.debug("Calling  helper with redis account number {}", data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED)) {
				if((CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType()) || CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())) && StringUtilities.isNotEmptyOrNull(data.getCreditAppNum())) {
					request.getCartInfo().setCreditAppNum(data.getCreditAppNum());
					request.getCartInfo().setCartCreator(data.getCreditAppNum());
				}
			}
			if (!CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType()) && !CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType()) && StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				request.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				request.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				request.getCartInfo().setCaseId(data.getCaseId());
			if (!CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType()) && !CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType()) && StringUtilities.isNotEmptyOrNull(data.getMtn()))
				request.getCartInfo().setCartCreator(data.getMtn());	
			if(CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType()) )
			{
					request.getCartInfo().setCartCreator(data.getCreditAppNum());				
			}
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessingMTN()))
				request.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			return bpmHelper.addManualdiscount(request).flatMap(response -> {
				return Mono.just(response);
			});
		});

	}
	
	public Mono<UpdateEffectiveDateUIResponse> updateEffectiveDate(UpdateEffectiveDateUIRequest updateEffectiveDateUIRequest) {
		String channelType = CartUtil.getChannelType(updateEffectiveDateUIRequest.getChannelId());
		return redisHelper.getDataFromRedis().flatMap(data -> {
			logger.debug("Calling  helper with redis account number {}", data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED)) {
				if((CartConstants.NSE_BYOD.equalsIgnoreCase(updateEffectiveDateUIRequest.getCartInfo().getIntendType()) || CartConstants.NSE.equalsIgnoreCase(updateEffectiveDateUIRequest.getCartInfo().getIntendType())) && StringUtilities.isNotEmptyOrNull(data.getCreditAppNum())) {
					updateEffectiveDateUIRequest.getCartInfo().setCreditAppNum(data.getCreditAppNum());
					updateEffectiveDateUIRequest.getCartInfo().setCartCreator(data.getCreditAppNum());
				}
			}
			if (!CartConstants.NSE_BYOD.equalsIgnoreCase(updateEffectiveDateUIRequest.getCartInfo().getIntendType()) && !CartConstants.NSE.equalsIgnoreCase(updateEffectiveDateUIRequest.getCartInfo().getIntendType()) && StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				updateEffectiveDateUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				updateEffectiveDateUIRequest.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				updateEffectiveDateUIRequest.getCartInfo().setCaseId(data.getCaseId());
			if (!CartConstants.NSE_BYOD.equalsIgnoreCase(updateEffectiveDateUIRequest.getCartInfo().getIntendType()) && !CartConstants.NSE.equalsIgnoreCase(updateEffectiveDateUIRequest.getCartInfo().getIntendType()) && StringUtilities.isNotEmptyOrNull(data.getMtn()))
				updateEffectiveDateUIRequest.getCartInfo().setCartCreator(data.getMtn());	
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(updateEffectiveDateUIRequest.getCartInfo().getProcessingMTN()))
				updateEffectiveDateUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			return bpmHelper.updateEffectiveDate(updateEffectiveDateUIRequest);
		});

	}

	public Mono<AddZipcodeRedisData> updateZipcodeToCart(String channelId, String zipCode) {
		AddZipCodeUIRequest requestZipcode = new AddZipCodeUIRequest();
		requestZipcode.setZipCode(zipCode != null ? zipCode : "");
		requestZipcode.setChannelId(channelId != null ? channelId : "");
		requestZipcode.setIntendType(CartConstants.NSE);
		return addZipcode(requestZipcode);
	}
	
	/**
	 * @param request
	 * @return
	 */
	public Mono<GetPairedDevicesUIResponse> getPairedDevices(GetPairedDevicesUIRequest request,String channelId) {

		return redisHelper.getDataFromRedis().flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(data.getCartId())) {
				request.setCartId(data.getCartId());
				return cxpHelper2.getPairedDevices(request);
			}else {
				// when no cart Id in session...
				return Mono.error(CartUtil.handleInvalidSession(channelId));
			}
		});

	}
	
	/**
	 *
	 * @param request
	 * @return UpdateVzccNBXInfoUIResponse
	 *
	 */
	public Mono<UpdateVzccNBXInfoUIResponse> updateVzccNBXInfo(UpdateVzccNBXInfoUIRequest request) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				request.setCartId(data.getCartId());
			if (data.getIntendType() != null && CartConstants.NSE.equalsIgnoreCase(data.getIntendType()))
				request.setIntentType(CartConstants.NSE);
			return cxpHelper2.updateVzccNBXInfo(request);
		});
	}

	/**
	 *
	 * @param request, customerId
	 * @return UIResponse
	 *
	 */
	public Mono<CreateCaseAndGetCustomerInfoUIResponse> getCustomerInfo(CreateCaseAndGetCustomerInfoUIRequest request, String customerId) {

		return cxpHelper2.getCustomerInfo(request, customerId);
	}

	/**
	 *
	 * @param request, httpHeader, mtn
	 * @return CreateCaseAndGetCustomerInfoUIResponse
	 *
	 */
	public Mono<CreateCaseAndGetCustomerInfoUIResponse> createCase(CreateCaseAndGetCustomerInfoUIRequest request, ServerHttpRequest httpHeader, String mtn) {

		return bpmHelper.createCase(request, httpHeader, mtn);

	}

	//VZWYN-20895 changes
	public Mono<InitiateValidateDeviceSimUIResponse> customerNameByMtn(String mtn) {
		ArrayList<String> mtnList = new ArrayList<>();
		if(mtn != null)
			mtnList.add(mtn);
		return cxpHelper2.customerNameByMtn(mtnList);
	}

	public Mono<InitiateValidateDeviceSimUIResponse> initiateValidateDeviceSim(InitiateValidateDeviceSimUIRequest request, ServerHttpRequest httpHeader, CartRedisData redisData) {

		return bpmHelper.initiateValidateDeviceSim(request, httpHeader, redisData);
	}

	/**
	 * Initiate device sim activation.
	 *
	 * @param request the request
	 * @return the mono
	 */
	public Mono<InitiateDeviceSimActivationUIResponse> initiateDeviceSimActivation(
			IntiateDeviceSimActivationUIRequest request) {

		return cxpHelper2.initiateDeviceSimActivation(request);

	}
	
	public Mono<InitiateESimActivationUIResponse> initiateESimActivation(
			IntiateESimActivationUIRequest request) {

		return cxpHelper2.initiateESimActivation(request);

	}

	
	private void removeSensitiveInfoForValidateOrder(InitiateCheckoutUIResponse resp)
	{
		if (resp != null && resp.getServiceBody() != null
				&& resp.getServiceBody().getServiceResponse() != null
				&& resp.getServiceBody().getServiceResponse().getContext() != null) {

			resp.getServiceBody().getServiceResponse().getContext().setCaseId(null);
		}
		if (resp!=null && resp.getServiceBody() != null && resp.getServiceBody().getServiceResponse().getContext().getCartInfo() != null)
			resp.getServiceBody().getServiceResponse().getContext().getCartInfo().setCartId(null);


	}

	private void removeSensitiveInfoForAssignMtn(AssignMtnUIResponse resp)
	{
		if (resp != null && resp.getServiceBody() != null
				&& resp.getServiceBody().getServiceResponse() != null
				&& resp.getServiceBody().getServiceResponse().getContext() != null) {

			resp.getServiceBody().getServiceResponse().getContext().setCaseId(null);
		}
		if (resp!=null && resp.getServiceBody() != null && resp.getServiceBody().getServiceResponse().getContext().getCartInfo() != null)
			resp.getServiceBody().getServiceResponse().getContext().getCartInfo().setCartId(null);


	}


	/**
	 *
	 * @param updateGiftItemUIRequest
	 * @return UpdateCartUIResponse
	 *
	 */
	public Mono<UpdateGiftItemUIResponse> updateGiftItem(UpdateGiftItemUIRequest updateGiftItemUIRequest) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			logger.debug(String.format(CartConstants.BPM_LOG_REDIS_ACCOUNT_NUMBER, data.getAccountNumber()));
			if (!updateGiftItemUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				updateGiftItemUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				updateGiftItemUIRequest.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				updateGiftItemUIRequest.getCartInfo().setCaseId(data.getCaseId());
			if (!updateGiftItemUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getMtn()))
				updateGiftItemUIRequest.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(updateGiftItemUIRequest.getCartInfo().getProcessingMTN()))
				updateGiftItemUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (!updateGiftItemUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				updateGiftItemUIRequest.getCartInfo().setCartCreator(data.getCartCreator());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN()) && null != updateGiftItemUIRequest.getData()
					&& CollectionUtilities.isNotEmptyOrNull(updateGiftItemUIRequest.getData().getLines())
					&& StringUtilities.isEmptyOrNull(updateGiftItemUIRequest.getData().getLines().get(0).getMtn()))
				updateGiftItemUIRequest.getData().getLines().get(0).setMtn(data.getProcessingMTN());

			return bpmHelper.updateGiftItem(updateGiftItemUIRequest);
		});

	}
	public Mono<IndirectExCustRemoveLinePEGARes> exCustremoveLines(ExCustIndirectRemoveLinesServiceUIRequest request)
	{		
		return redisHelper.getDataFromRedis().flatMap(data->
		{			
			request.getContext().setCaseId(data.getCaseId());
			request.getContext().getCustomerInfo().setAccountNumber(data.getAccountNumber());
			return bpmHelper.indirectexremoveLines(request);
		});
		
	}

	private Mono<CradleResponse> invokeCradleForPlansHub(CreateLineUIRequest request) {
		ServerHttpRequest httpRequest = null;
		ServerHttpResponse httpResponse = null;
		try {
			Map<String, String> dataMap = new HashMap<>();
			if(request!=null) {
				if (request.getCartInfo() != null) {
					if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())) {
						dataMap.put(CradleConstants.FLOW, request.getCartInfo().getIntendType());
					}
					if (CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
						dataMap.put(CartConstants.IS_PROPSECT, CartConstants.TRUE_FLAG);
					}
					if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCustomerType())) {
						dataMap.put(CartConstants.CUSTOMER_TYPE, request.getCartInfo().getCustomerType());
					}
				}
				if (StringUtilities.isNotEmptyOrNull(request.getChannelId())) {
					dataMap.put(CradleConstants.CHANNEL, request.getChannelId());
				} else {
					logger.info(String.format("Empty channel id from UI request defaulting to VZW_DOTCOM %s" , request));
					dataMap.put(CradleConstants.CHANNEL, CartConstants.VZW_DOTCOM);
				}
				if(request.getData()!=null && request.getData().getNumOfLines()!=null){
					dataMap.put(CartConstants.NUM_OF_LINES, request.getData().getNumOfLines());
				}
				dataMap.put(CradleConstants.PAGE_NAME, CartConstants.CREATE_LINE);
				dataMap.put(CartConstants.IS_PLAN_FIRST, CartConstants.TRUE_FLAG);
				httpRequest = request.getHttpRequest();
				httpResponse = request.getHttpResponse();
				setRegionCodeAndCatagory(httpRequest,dataMap);
			}
			return cradleAllocator.invokeReactiveCradle(httpRequest, httpResponse, dataMap);
		} catch (Exception ex) {
			logger.error("exception while invoking Cradle new-line",ex);
			return Mono.empty();
		}
	}

	/** The changes to set the region code into the cradele request**/
	private void setRegionCodeAndCatagory(ServerHttpRequest httpRequest, Map<String, String> dataMap) {
		String regionCode = getRegionCode(httpRequest) != null ? getRegionCode(httpRequest) : "";
		dataMap.put(CartConstants.REGION_CODE, regionCode);
	}

	/** The changes to set the region code into the cradele request from the http request headers**/
	private String getRegionCode(ServerHttpRequest serverHttpRequest) {
		HttpHeaders httpHeaders = serverHttpRequest != null ? serverHttpRequest.getHeaders() : null;
		List<String> valueList = httpHeaders != null ? httpHeaders.getOrEmpty(CartConstants.X_AKAMAI_EDGESCAPE)
				: null;
		logger.info(" x-akamai-edgescape header value : {}",
				valueList != null && !valueList.isEmpty() && valueList.get(0) != null ? valueList.get(0) : "");
		if (valueList != null && !valueList.isEmpty() && valueList.get(0) != null) {
			String value = valueList.get(0);
			Map<String, String> stringMap = Arrays.stream(value.split(",")).map(s -> s.split("=", 2))
					.collect(Collectors.toMap(array -> array[0], array -> array.length > 1 ? array[1] : ""));
			return stringMap.get(CartConstants.REGION_CODE);
		}
		return "";
	}

	public Mono<AddDeviceUIResponse> addBuyoutAndConsent(AddDeviceUIRequest addDeviceUIRequest){

		return redisHelper.getDataFromRedis().flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				addDeviceUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				addDeviceUIRequest.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				addDeviceUIRequest.getCartInfo().setCaseId(data.getCaseId());
			if (StringUtilities.isNotEmptyOrNull(data.getMtn()))
				addDeviceUIRequest.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(addDeviceUIRequest.getCartInfo().getProcessingMTN()))
				addDeviceUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				addDeviceUIRequest.getCartInfo().setCartCreator(data.getCartCreator());

			Mono<AddBuyoutUIResponse> buyOutResponse = Mono.just(new AddBuyoutUIResponse());
			Mono<UpdateConsentCxpResponse> updateConsentResponse = Mono.just(new UpdateConsentCxpResponse());
			AddDeviceUIResponse response = new AddDeviceUIResponse();

			if ("Y".equalsIgnoreCase(addDeviceUIRequest.getCartInfo().getBuyOutSelected())) {
				buyOutResponse = addBuyout(CartPegaRequestUtil9.formatBuyoutUIRequest(addDeviceUIRequest));
			}
			if (addDeviceUIRequest.getCartInfo().getCustomerConsent() != null && addDeviceUIRequest.getCartInfo().getCustomerConsent()) {
				updateConsentResponse = cxpHelper.updateCustomerConsent(addDeviceUIRequest);
			}
			return Mono.zip(buyOutResponse , updateConsentResponse).flatMap(res ->{

				if( res.getT1() != null){

					AddBuyoutUIResponse addBuyoutUIResponse = res.getT1();
					if(addBuyoutUIResponse.getErrors() != null && !addBuyoutUIResponse.getErrors().isEmpty()){
						response.setErrors(addBuyoutUIResponse.getErrors());
						return Mono.just(response);
					}else {
						if (addBuyoutUIResponse.getServiceHeader() != null
								&& CartConstants.SUCCESS.equalsIgnoreCase(addBuyoutUIResponse.getServiceHeader().getStatusMsg())
								&& "00".equalsIgnoreCase(addBuyoutUIResponse.getServiceHeader().getStatusCode())){
							response.setIsBuyOutAdded(Boolean.TRUE);
						}
					}
				}
				if( res.getT2() !=null){
					UpdateConsentCxpResponse consentResponse = res.getT2();
					if(consentResponse.getErrors() != null && !consentResponse.getErrors().isEmpty()){
						response.setErrors(consentResponse.getErrors());
						return Mono.just(response);
					}else{
						if (consentResponse.getData() != null && CartConstants.STATUS_SUCCESS.equalsIgnoreCase(consentResponse.getData().getStatusMsg())){
							response.setIsConsentUpdated(true);
						}
					}
				}
				return Mono.just(response);
			});
		});
	}
	
	
	
	
	
	
	public Mono<AddReplenishmentToCartUIResponse> addReplenishmentToCart(AddReplenishmentToCartUIRequest addReplenishmentToCartUIRequest) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			logger.debug("Calling bpm helper addReplenishmentToCart redis account number {}", data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				addReplenishmentToCartUIRequest.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				addReplenishmentToCartUIRequest.getCartInfo().setCaseId(data.getCaseId());
			if (addReplenishmentToCartUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getMtn()))
				addReplenishmentToCartUIRequest.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(addReplenishmentToCartUIRequest.getCartInfo().getProcessingMTN()))
				addReplenishmentToCartUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (addReplenishmentToCartUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getCreditAppNum()))
				addReplenishmentToCartUIRequest.getCartInfo().setCartCreator(data.getCreditAppNum());
			if (StringUtilities.isEmptyOrNull(addReplenishmentToCartUIRequest.getCartInfo().getClientAppName()) && StringUtilities.isNotEmptyOrNull(data.getCartInfo().getClientAppName()))
				addReplenishmentToCartUIRequest.getCartInfo().setClientAppName(data.getCartInfo().getClientAppName());
			if (addReplenishmentToCartUIRequest.getCartInfo().getIntendType().equalsIgnoreCase("AAL") || addReplenishmentToCartUIRequest.getCartInfo().getIntendType().equalsIgnoreCase("BYOD"))
				addReplenishmentToCartUIRequest.getCartInfo().setCartCreator(data.getCartCreator());
				addReplenishmentToCartUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
				addReplenishmentToCartUIRequest.getCartInfo().setCustomerType(data.getCustomerType());
			return bpmHelper3.addReplenishmentToCart(addReplenishmentToCartUIRequest);
		});
	}

	public Mono<ReviewOrderTYSUIResponse> reviewOrderTysValidation(@Valid ReviewOrderTYSUIRequest request) {
		return bpmHelper3.reviewOrderTys(request);
	}

	public Mono<MylinkReferralInfoResponse> validateMyLinkReferralInfo(String hashKey, String salesFlowSessionId) {
		Mono<MylinkReferralInfoResponse> responseMono = cxpHelper2.validateMyLinkReferralInfo(hashKey, salesFlowSessionId);
		return  responseMono.flatMap( res -> {
			if(Objects.nonNull(res) && Objects.nonNull(res.getData()) && CartConstants.SUCCESS.equalsIgnoreCase(res.getData().getStatus())) {
				redisHelper.getDataFromRedis().flatMap(data -> {
					if (data.getIsMyLinkAvailable() != null) {
						redisHelper.clearMyLinkDataFromRedis(CartConstants.IS_MYLINK_AVAILABLE_FLAG);
					}
					if (StringUtils.isNotEmpty(data.getMyLinkHashKey())) {
						redisHelper.clearMyLinkDataFromRedis(CartConstants.MYLINK_HASH_KEY);
					}
					return responseMono;
				});
			}
			return responseMono;
		});
	}

	private void updateSWBarCodeInRequest(UpdateBarcodeUIRequest updateBarcodeUIRequest){
		if ((updateBarcodeUIRequest.getCartInfo().isSWOfferAccepted()  && StringUtilities.isNotEmptyOrNull(barcodeOffer))
				|| (updateBarcodeUIRequest.getCartInfo().isFwaSWOfferAccepted() && StringUtilities.isNotEmptyOrNull(fwaSweetnerCouponCode))) {
			List<UpdateBarcodeBarcodeId> barCodeList = new ArrayList<>();
			UpdateBarcodeBarcodeId updateBarcodeBarcodeId = new UpdateBarcodeBarcodeId();
			updateBarcodeBarcodeId.setBarCodeId(sessionBean.isFWADigitalFlow() ? fwaSweetnerCouponCode : barcodeOffer);
			barCodeList.add(updateBarcodeBarcodeId);
			updateBarcodeUIRequest.getCartInfo().setBarCodeIds(barCodeList);
		}
	}

	public void updateSWBarCodeInRequestFromNBX(UpdateBarcodeUIRequest updateBarcodeUIRequest, CartRedisData cartRedisData) {
		if ((updateBarcodeUIRequest.getCartInfo().isDynSWOfferAccepted()) || StringUtils.isNotBlank(updateBarcodeUIRequest.getData().getNbxOfferId())) {
			List<UpdateBarcodeBarcodeId> barCodeList = new ArrayList<>();
			UpdateBarcodeBarcodeId updateBarcodeBarcodeId = new UpdateBarcodeBarcodeId();
			if(StringUtils.isNotBlank(updateBarcodeUIRequest.getData().getNbxOfferId())) {
				updateBarcodeBarcodeId.setBarCodeId(retrieveBarCodeIdFromRedis(cartRedisData, updateBarcodeUIRequest.getData().getNbxOfferId()));
			} else {
				updateBarcodeBarcodeId.setBarCodeId(cartRedisData.getSwBarCodeId());
			}
			barCodeList.add(updateBarcodeBarcodeId);
			updateBarcodeUIRequest.getCartInfo().setBarCodeIds(barCodeList);
		}
	}

	/**
	 * Retrieve BarCode Id from Redis for the speicified NBX offerId
	 * @param cartRedisData
	 * @param lookupOfferId
	 * @return
	 */
	private String retrieveBarCodeIdFromRedis(CartRedisData cartRedisData, String lookupOfferId) {
		if(null != cartRedisData.getFwaPDMOffers() && !cartRedisData.getFwaPDMOffers().isEmpty()) {
			Optional<String> couponCode = cartRedisData.getFwaPDMOffers().stream().filter(offer -> lookupOfferId.equals(offer.getOfferId())).findFirst().map(PDMOfferData::getCouponCode);
			return couponCode.isPresent() ? couponCode.get() : EMPTY_STRING;
		}
		return EMPTY_STRING;
	}

	public void nullifyBarCodeForUIAtOrderDetails(CXPCartVO cxpCartVO) {
		if (StringUtilities.isNotEmptyOrNull(barcodeOffer)
				&& cxpCartVO.getOrderDetails() != null && cxpCartVO.getOrderDetails().getBarCodes() != null
				&& cxpCartVO.getOrderDetails().getBarCodes().length > 0
				&& Arrays.asList(cxpCartVO.getOrderDetails().getBarCodes()).contains(barcodeOffer)) {
			String barcodeArray[] = ArrayUtils.removeElement(cxpCartVO.getOrderDetails().getBarCodes(), barcodeOffer);
			if (barcodeArray.length == 0) {
				cxpCartVO.getOrderDetails().setBarCodes(null);
			}else{
				cxpCartVO.getOrderDetails().setBarCodes(barcodeArray);
			}
			cxpCartVO.getOrderDetails().setIsSWOfferApplied(true);
		}
	}


	public void nullifyBarCodeForUIAtLineLevel(List<CXPItemInfo> cxpItemInfo) {
		if (StringUtilities.isNotEmptyOrNull(barcodeOffer)){
			cxpItemInfo.stream().filter(Objects::nonNull).forEach(itemsInfo -> {
				if (itemsInfo.getCartItems() != null && itemsInfo.getCartItems().getCartItem() != null
						&& itemsInfo.getCartItems().getCartItem().length > 0) {
					List<CXPCartItem> cxpCartItemList = Arrays.asList(itemsInfo.getCartItems().getCartItem());
					Optional<CXPCartItem> cartItemDeviceOpt = cxpCartItemList.stream()
							.filter(cartItem -> DEVICE.equalsIgnoreCase(cartItem.getCartItemType())).findFirst();
					if (cartItemDeviceOpt.isPresent()
							&& cartItemDeviceOpt.get().getSedOfferList() != null
							&& CollectionUtilities.isNotEmptyOrNull(cartItemDeviceOpt.get().getSedOfferList().getSedOffer())) {
						cartItemDeviceOpt.get().getSedOfferList().getSedOffer().stream().forEach(sedOffer -> {
							if (StringUtils.isNotBlank(sedOffer.getBarcodeID())
									&& sedOffer.getBarcodeID().equalsIgnoreCase(barcodeOffer)) {
								sedOffer.setBarcodeID(null);
							}
						});
					}
				}
			});
		}
	}

	public void nullifyBarCodeForIsDynOfferRebate(CXPCartVO cartVo) {
		try {
			if (StringUtils.isNotBlank(dynSWPlatformPromoType) &&
					null != cartVo.getOrderDetails() && cartVo.getOrderDetails().getBarCodes() != null) {
				List<String> rebateOffers = nullifyBarCodeForIsDynOfferRebateAtLineLevel(cartVo.getLineDetails().getLineInfo());
				if (CollectionUtilities.isNotEmptyOrNull(rebateOffers)) {
					cartVo.getOrderDetails().setIsDynSWOfferApplied(true);
					rebateOffers.stream().forEach(rebateOffer -> {
						String barcodeArray[] = ArrayUtils.removeElement(cartVo.getOrderDetails().getBarCodes(), rebateOffer);
						if (barcodeArray.length == 0) {
							cartVo.getOrderDetails().setBarCodes(null);
						}else{
							cartVo.getOrderDetails().setBarCodes(barcodeArray);
						}
					});
				}
			}
		} catch (Exception e) {
			logger.error(CartConstants.CXP_RSPNS_PRCSS_EXCPTN_STRNG + "method nullifyBarCodeForIsDynOfferRebate", e);
		}
	}

	private List<String> nullifyBarCodeForIsDynOfferRebateAtLineLevel(CXPLineInfo[] cartLineInfo) {
		List<String> rebateOffer = new ArrayList<>();
		Arrays.asList(cartLineInfo).stream().filter(Objects::nonNull).forEach(lineInfo -> {
			List<CXPItemInfo> cartItemsIfo = Arrays.asList(lineInfo.getItemsInfo());
			if (CollectionUtilities.isNotEmptyOrNull(cartItemsIfo)) {
				cartItemsIfo.stream().filter(Objects::nonNull).forEach(itemsInfo -> {
					List<CXPCartItem> cxpCartItemList = Arrays.asList(itemsInfo.getCartItems().getCartItem());
					if (itemsInfo.getCartItems() != null && CollectionUtilities.isNotEmptyOrNull(cxpCartItemList)) {
						List<CXPCartItem> cartItemDeviceList = Arrays.asList(itemsInfo.getCartItems().getCartItem()).stream()
								.filter(cartItem -> DEVICE.equalsIgnoreCase(cartItem.getCartItemType())
										&& CollectionUtilities.isNotEmptyOrNull(cartItem.getRebateOffers())).collect(Collectors.toList());
						if (CollectionUtilities.isNotEmptyOrNull(cartItemDeviceList)) {
							cartItemDeviceList.stream().forEach(cartIt -> {
								cartIt.getRebateOffers().stream().forEach(rebate -> {
									if (StringUtils.isNotBlank(rebate.getPlatformPromoType())
											&& StringUtils.isNotBlank(rebate.getBarcodeId())
											&& rebate.getPlatformPromoType().equalsIgnoreCase(dynSWPlatformPromoType)) {
										rebateOffer.add(rebate.getBarcodeId());
										rebate.setBarcodeId(null);
									}
								});
							});
						}
					}
				});
			}
		});
		return rebateOffer;
	}
	public Map<String, CXPLineInfo> getCartLineMtnMapByLineNumber(CXPRetrieveCartDataVO retrieveCart) {
		Map<String, CXPLineInfo> CartLineMapByLineNum = new HashMap<>();
		if(null != retrieveCart && null != retrieveCart.getCart() && null != retrieveCart.getCart().getLineDetails()
				&& null != retrieveCart.getCart().getLineDetails().getLineInfo()
				&& retrieveCart.getCart().getLineDetails().getLineInfo().length > 0){
			Arrays.stream(retrieveCart.getCart().getLineDetails().getLineInfo())
					.filter(lineInfo -> null != lineInfo && StringUtilities.isNotEmptyOrNull(lineInfo.getLineNumber()))
					.forEach(line -> CartLineMapByLineNum.put(line.getLineNumber(), line));
		}
		return CartLineMapByLineNum;
	}
	public void removeDualNumberFromSession(RemoveLinesUIRequest removeLinesUIRequest, CartRedisData data) {
		logger.info("Dual Number : Before Update : " + data.getDualNumber());
		final Map<String, CXPLineInfo> cartLineMap = getCartLineMtnMapByLineNumber(data.getRetrieveCart());
		List<SecondNumber> updatedDualNumber = new ArrayList<>();
		if(null != removeLinesUIRequest.getData()
				&& null!=removeLinesUIRequest.getData().getLines()
				&& removeLinesUIRequest.getData().getLines().length >0){
			Arrays.stream(removeLinesUIRequest.getData().getLines())
					.filter(lines -> null != lines && StringUtilities.isNotEmptyOrNull(lines.getMtn()))
					.forEach(line -> {
						if (CollectionUtilities.isNotEmptyOrNull(data.getDualNumber().getSecondNumber())) {
							data.getDualNumber().getSecondNumber().stream()
									.filter(secondNumber -> (null != secondNumber
											&& StringUtilities.isNotEmptyOrNull(secondNumber.getSecondMtn())))
									.forEach(secondNumber -> {
										String mtn = line.getMtn();
										if (StringUtils.isNumeric(secondNumber.getSecondMtn())
												&& !StringUtils.isNumeric(line.getMtn()) && CollectionUtilities.isNotEmptyOrNull(cartLineMap)) {
											if (null != cartLineMap.get(line.getMtn())
													&& StringUtilities.isNotEmptyOrNull(cartLineMap.get(line.getMtn()).getMobileNumber())) {
												mtn = cartLineMap.get(line.getMtn()).getMobileNumber();
											}
										}
										if (mtn.equalsIgnoreCase(secondNumber.getSecondMtn())) {
											updatedDualNumber.add(secondNumber);
										}
									});
						}
					});
		}
		if(CollectionUtilities.isNotEmptyOrNull(updatedDualNumber))
			data.getDualNumber().getSecondNumber().removeAll(updatedDualNumber);
		logger.info("Dual Number : After Update : "+data.getDualNumber());
		redisHelper2.upsertDualNumberInSession(data.getDualNumber());
	}

	public boolean isNotNFL(PromoHubOffer promoHubOffer){
		boolean isNotNFL = false;
		if(CollectionUtils.isNotEmpty(promoHubOffer.getPromoBadges())){
			Optional<PromoBadgeMessages> optionalPromo = promoHubOffer.getPromoBadges().stream().filter(promoBadgeMessages ->
					StringUtils.isNotBlank(promoBadgeMessages.getBadgeText())
							&& promoBadgeMessages.getBadgeText().toLowerCase().contains(CartConstants.NFL)).findFirst();
			if(optionalPromo.isPresent()){
				isNotNFL = true;
			}
		}
		return isNotNFL;
	}

	public void filterExistingCustomerLineDetails(RetrieveCartUIResponse response,RetrieveCartCXPRequest request){
		try{
			if (request.getData().getRepRole() != null &&
					((CartConstants.NR_ROLE_ID.equalsIgnoreCase(request.getData().getRepRole()) && CartConstants.MASTER_AGENT_ID.equals(request.getData().getCart().getOrderDetails().getMasterAgentId()))
					|| CartConstants.D2DRoleIds.contains(request.getData().getRepRole())) && response != null && response.getData() != null && response.getData().getCart() != null) {
				CXPCartVO cart = response.getData().getCart();
				if (!request.getData().isNewCustomer() && cart.getLineDetails() != null &&
						cart.getLineDetails().getLineInfo() != null && cart.getLineDetails().getLineInfo().length > 0) {
					List<CXPLineInfo> cxpLineInfo = new ArrayList<>(Arrays.asList(cart.getLineDetails().getLineInfo()));
					cxpLineInfo.removeIf(line -> line!=null &&
							StringUtilities.isNotEmptyOrNull(line.getLineActivityType()) &&  !CartConstants.INTENT_TYPE_EC.contains(line.getLineActivityType()));
					CXPLineInfo[] cxpLineInfos = cxpLineInfo.toArray(CXPLineInfo[]::new);
					cart.getLineDetails().setLineInfo(cxpLineInfos);
				}

			}
		}catch (Exception e){
			logger.error("Error on filtering lineInfo", e);
		}
	}
	public void updateTaggingPlanDetails(RetrieveCartUIResponse response,RetrieveCartCXPRequest request){
		try{
			if (null != request.getData() && request.getData().getPlanTaggingDetails() != null && CollectionUtilities.isNotEmptyOrNull(request.getData().getPlanTaggingDetails()) && response != null && response.getData() != null && response.getData().getCart() != null) {
				CXPCartVO cart = response.getData().getCart();
				if (cart.getLineDetails() != null
						&& cart.getLineDetails().getLineInfo() != null
						&& cart.getLineDetails().getLineInfo().length > 0) {
					Arrays.stream(cart.getLineDetails().getLineInfo())
							.filter(lines -> lines != null
									&& lines.getMobileNumber() != null)
							.forEach(line -> updateDetailsToCart(request, line));
				}
			}
		}catch (Exception e){
			logger.error("Error on filtering lineInfo", e);
		}
	}
	public void updateDetailsToCart(RetrieveCartCXPRequest request,CXPLineInfo line){
		request.getData().getPlanTaggingDetails().stream().filter(planDetails ->
				planDetails.getMtn() != null).forEach(planDetail -> {
			if(planDetail.getMtn().equalsIgnoreCase(line.getMobileNumber() )
					|| (line.getLineNumber() != null
					&& planDetail.getMtn().equalsIgnoreCase(line.getLineNumber()))) {

				PlanTaggingDetails details = new PlanTaggingDetails();
				if(planDetail.getAction() != null){
					details.setAction(planDetail.getAction());}
				if(planDetail.getPath() != null){
					details.setPath(planDetail.getPath());}
				if(planDetail.getGroup() != null){
					details.setGroup(planDetail.getGroup());}
				if(planDetail.getPlan() != null){
					details.setPlan(planDetail.getPlan());}
				if(CollectionUtilities.isNotEmptyOrNull(planDetail.getPerks())){
					details.setPerks(planDetail.getPerks());}

				line.setPlanTaggingDetails(details);

			}
		});
	}
	public void setLGPORedisDataInRequest(CartRedisData data, AddPlanUIRequest request) {
		if (request != null && request.getCartInfo() != null && data != null) {
			if (request.getCartInfo().getIntendType() != null) {
				if (CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())
						|| (CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType()))) {
					if (data.getIsLgpoEligibleCustomer() != null && Boolean.TRUE.equals(data.getIsLgpoEligibleCustomer())
							&& data.getLgpoSpo() != null) {
						request.getData().setIsLGPOEligible(Boolean.TRUE);
						request.getData().setLgpoSpo(data.getLgpoSpo());
					}
				}
			}
		}
	}


	public ErrorResponse prevalidateUserRequest(UpdateUserInfoUIRequest request) {
		String firstName = null;
		String emailId = null;
		ErrorResponse error = new ErrorResponse();
		try {
			if (Objects.nonNull(request) && CollectionUtilities.isNotEmptyOrNull(request.getLines())
					&& Objects.nonNull(request.getLines().get(0))
					&& StringUtilities.isNotEmptyOrNull(request.getLines().get(0).getFirstName())
					&& StringUtilities.isNotEmptyOrNull(request.getLines().get(0).getEmail())) {
				firstName = request.getLines().get(0).getFirstName();
				emailId = request.getLines().get(0).getEmail();

				// check first name is valid or not
				if (!isNameValid(firstName)) {
					logger.error("Invalid Name: {}", firstName);
					return getErrorResponse(CartConstants.NAME_VALIDATION_ERR, error);
					// check email is valid or not
				} else if (!isEmailValid(emailId)) {
					logger.error("Invalid Email address: {}", emailId);
					return getErrorResponse(CartConstants.EMAIL_ADDRESS_VALIDATION_ERR, error);
				} else {
					logger.info("User details Validation Successfully done.");
				}
			} else {
				if (Objects.nonNull(request) && CollectionUtilities.isEmptyOrNull(request.getLines())) {
					logger.info("line info can not be null in prevalidateUserRequest");
					throw new CommonCartServiceException(HttpStatus.BAD_REQUEST, "line info can not be blank");
				} else {
					logger.info("First-Name or Email can not be null in prevalidateUserRequest");
					throw new CommonCartServiceException(HttpStatus.BAD_REQUEST, CartConstants.NAME_EMAIL_NULL_VALIDATION_ERR);
				}
			}
		} catch (Exception e) {
			logger.info("Exception occured in prevalidateUserRequest: {}",e.getMessage());
			getErrorResponse(e.getMessage(), error);
        }
        return error;
	}

	/*method for custom error response population*/
	private static ErrorResponse getErrorResponse(String validationErr, ErrorResponse error) {
		List<CartError> errorList = new ArrayList<>();
		CartError crError = new CartError();
		crError.setMessage(validationErr);
		crError.setNamespace("onevz-soe-cart-services");
		crError.setName("VALIDATION_ERROR");
		crError.setId("3000");
		crError.setErrorCategory("VALIDATION_ERR");
		errorList.add(crError);
		error.setErrors(errorList);
		return error;
	}

	/*this method takes string email as input
	   used regex expression to check email format
	   return true if the entered email is of correct email format
	   else return false
	*/
	private boolean isEmailValid(String emailId) {
		logger.info("Entered into prevalidateUserRequest isEmailValid method..");

		String regex = "^[\\w.%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(emailId);
		return matcher.matches();
	}

	/*this method takes string name as input
	   used regex expression to check name contains only alphabet and a space
	   return true if the firstName contains alphabet in small or caps and a space
	   else return false
	*/
	private boolean isNameValid(String firstName) {
		logger.info("Entered into prevalidateUserRequest isNameValid method..");

		String regex = "^[a-zA-Z]+([',. -][a-zA-Z]+)*+$";
		Pattern pattern = Pattern.compile(regex);
		Matcher firstNameMatcher = pattern.matcher(firstName);
		return firstNameMatcher.matches();
	}

	public Mono<ResponseEntity<CartExceedsLimitResponse>> getCartExceedsLimitService(ServerHttpRequest httpHeader,
																					 ServerHttpResponse httpResponse,
																					 CartExceedsLimitRequest request) {

		if (null != request && null != request.getPaymentAmt() && request.getPaymentAmt().contains("$")) {
			request.setPaymentAmt(request.getPaymentAmt().replace("$", ""));
		}

		Mono<CartRedisData> rr = redisHelper.getDataFromRedis();
		return rr.flatMap(data -> {
			if (data.getAccountNumber() != null) {
				request.setAccountNumber(data.getAccountNumber());
			}
			return cxpHelper.getCartExceedsLimitCXPResponse(request).flatMap(cxpResponse ->
					Mono.just(ResponseEntity.status(Objects.requireNonNull(httpResponse.getStatusCode())).body(cxpResponse)));
		});
	}
	public boolean isthirdpartyFeaturePromo(PromoHubOffer promoHubOffer) {
		boolean isthirdpartyFeaturePromo = false;
		if(Boolean.TRUE.equals(featureFlagHelper.isPOYPEnabled()) && promoHubOffer.getPromoType() != null
				&& promoHubOffer.getPromoType().equalsIgnoreCase(CartConstants.FEATURED_PROMO)
				&& StringUtilities.isEmptyOrNull(promoHubOffer.getOfferId())){
			isthirdpartyFeaturePromo = true;
		}
		return isthirdpartyFeaturePromo;
	}

	private boolean isByodLinePresent(RetrieveCartUIResponse retrieveCartResponse) {
		if (retrieveCartResponse != null && retrieveCartResponse.getData() != null
				&& retrieveCartResponse.getData().getCart() != null && retrieveCartResponse.getData().getCart().getLineDetails() != null
				&& retrieveCartResponse.getData().getCart().getLineDetails().getLineInfo() != null) {
			return Arrays.stream(retrieveCartResponse.getData().getCart().getLineDetails().getLineInfo())
					.anyMatch(lineInfo -> null != lineInfo && StringUtils.isNotEmpty(lineInfo.getLineActivityType()) && Arrays.asList(CartConstants.NSE_BYOD, CartConstants.BYOD).contains(lineInfo.getLineActivityType().toUpperCase()));

		}
		return false;
	}


	public void checkForBYODMasking(RetrieveCartUIResponse resp) {
		if (isByodLinePresent(resp) && featureFlagHelper.isMaskingForBYODFFlag()) {
			performMaskingBYOD(resp);
		}
	}

	public void performMaskingBYOD(RetrieveCartUIResponse resp) {
		CXPLineDetailsVO cxpLineDetailsVO = getDeviceInfo(resp);
		if(null != cxpLineDetailsVO && null != cxpLineDetailsVO.getLineInfo()) {
			for (CXPLineInfo cxpLineInfo : cxpLineDetailsVO.getLineInfo()) {
				maskDeviceId(cxpLineInfo);
				maskESIM(cxpLineInfo);
			}
		}
	}

	private void maskESIM(CXPLineInfo cxpLineInfo) {
		if(cxpLineInfo != null && cxpLineInfo.getItemsInfo() != null) {
			for (CXPItemInfo itemInfo : cxpLineInfo.getItemsInfo()) {
				if (null != itemInfo && null != itemInfo.getCartItems()) {
					maskCartItemForESIM(itemInfo);
				}
			}
		}
	}

	private static void maskCartItemForESIM(CXPItemInfo itemInfo) {
		CXPCartItemsVO cxpCartItemsVO = itemInfo.getCartItems();
		if (cxpCartItemsVO.getCartItem() == null) {
			return;
		}
		for (CXPCartItem cartItem : cxpCartItemsVO.getCartItem()) {
			if (cartItem != null && cartItem.getESIM() != null) {
				cartItem.setESIM(CartUtil.maskStringField(cartItem.getESIM(), 4));
			}
		}
	}

	private void maskDeviceId(CXPLineInfo linInfo) {

		Optional.ofNullable(linInfo)
				.map(CXPLineInfo::getServiceInfo)
				.map(ServiceInfo::getOrderDevice)
				.map(OrderDevice::getLteVoraEquipInfo)
				.map(LteVoraEquipInfo::getLteVoraDeviceInfo)
				.ifPresent(deviceInfo ->{
					String deviceId = deviceInfo.getDeviceId();
					deviceInfo.setDeviceId(CartUtil.maskStringField(deviceId, 4));
				});
	}

	private CXPLineDetailsVO getDeviceInfo(RetrieveCartUIResponse resp) {
		if(resp != null
				&& resp.getData() != null
				&& resp.getData().getCart() != null
				&& resp.getData().getCart().getLineDetails() != null){
			return resp.getData().getCart().getLineDetails();
		}
		return null;
	}
}



