package onevz.soe.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.vzw.cradle.vo.CradleResponse;
import jakarta.validation.Valid;
import onevz.cxp.feature.util.FeatureFlag;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper2;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.constants.FeatureFlagConstants;
import onevz.soe.cart.controller.advice.CartServiceExceptionHandler;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper2;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.exceptions.JsonValidator;
import onevz.soe.cart.gql.schema.oneclick.BillAccounts;
import onevz.soe.cart.gql.schema.oneclick.CustomerProfileGraphQLResponse;
import onevz.soe.cart.gql.schema.oneclick.Mtn;
import onevz.soe.cart.handler.PreHandleAddDevice;
import onevz.soe.cart.model.addDevice.AddDeviceContext;
import onevz.soe.cart.model.addDevice.AddDeviceServiceBody;
import onevz.soe.cart.model.addDevice.AddDeviceServiceResponse;
import onevz.soe.cart.model.addDevice.AuthorizedUser;
import onevz.soe.cart.model.addPromoIntent.AddPromoIntent;
import onevz.soe.cart.model.bvp.BVPLine;
import onevz.soe.cart.model.catalog.FeatureCatalogItem;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.myOffer.Offer;
import onevz.soe.cart.model.myOffers.ValidateOffersData;
import onevz.soe.cart.model.oneClick.CustomerProfileData;
import onevz.soe.cart.model.updateBarcode.UpdateBarcodeBarcodeId;
import onevz.soe.cart.nbx.NBXFeedbackService;
import onevz.soe.cart.omnidl.AssistedOmniDLBuilder;
import onevz.soe.cart.requests.NBXFeedbackRequest;
import onevz.soe.cart.requests.ValidateCartCXPRequest;
import onevz.soe.cart.requests.ValidateOffersRequest;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.ui.common.*;
import onevz.soe.cart.ui.requests.AddDeviceUIRequest;
import onevz.soe.cart.ui.requests.RfexExchangeShopDetails;
import onevz.soe.cart.ui.responses.AddDeviceUIResponse;
import onevz.soe.cart.ui.responses.UpgradeBuyoutMtnData;
import onevz.soe.cart.ui.responses.ValidateCartUIResponse;
import onevz.soe.cart.util.*;
import onevz.soe.exception.SOEErrorHolder;
import onevz.soe.omnidl.service.OmniDLService;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.bpm.model.Context;
import onevz.soe.wsclient.bpm.model.ServiceBody;
import onevz.soe.wsclient.bpm.model.response.AvailablePaths;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.ZonedDateTime;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

import static onevz.soe.cart.constants.CartConstants.*;

@Service
public class CartAddDeviceHelper {

    @Autowired
    private CartServiceCxpHelper cxpHelper;

    @Autowired
    JsonValidator validator;

    @Autowired
    private OmniDLHelper omniDLHelper;

    @Autowired
    private CartServiceCxpHelper2 cxpHelper2;

    @Autowired
    private CartServiceBpmHelper2 bpmHelper;

    @Autowired
    private CartAddDeviceHelper1 cartAddDeviceHelper1;

    @Autowired
    private ObjectMapper mapper;

    @Autowired
    private RedisHelper redisHelper;

    @Autowired
    private RedisHelper2 redisHelper2;

    @Autowired
    private RedisHelper3 redisHelper3;

    @Autowired
    private NBXFeedbackService nbxService;

    @Autowired
    private CartServiceExceptionHandler exHandler;

    @Autowired
    private CartRequestBuilder cartRequestBuilder;
    @Autowired
    private FeatureFlag featureFlagUtil;
    @Value("${maxDevicesAllowedPromoHub}")
    private Integer maxDevicesAllowedPromoHub;

    @Value("${enableMHOffers}")
    private boolean enableMHOffers;

    @Value("${minimumBillAmount}")
    private String minimumBillAmount;

    @Value("${prepay.ignore.roles}")
    private List<String> ignoreRoles;

    @Value("${removeCartIdCaseId.channelIds}")
    private List<String> channelsToRemoveCaseAndCartIds;

    @Value("${caseId_CartId_Intent_Check}")
    private boolean caseIdCartIdIntentCheck;

    @Value("${prospect_flows}")
    private List<String> prospectFlows;

    @Value("${existing_customer_flows}")
    private List<String> existingCustomerFlows;

    @Value("${enableUidDomainFilter:true}")
    public boolean enableUidDomainFilter;
    @Value("${uIdEnabledDomains:verizon.com,verizonwireless.com}")
    private List<String> uIdEnabledDomains;

    @Value("${enablePlansFirstCartExistCheck:false}")
    private boolean plansFirstCartExistCheck;

    @Value("${bpm_sales_order_purchase_case_id_prefix}")
    private List<String> bpmSalesOrderPurchaseCaseIdPrefix;

    @Autowired
    OmniDLService dlService;

    @Autowired
    PreHandleAddDevice preHandleAddDevice;

    @Autowired
    private CartServiceCXPServices cxpServices;
    @Autowired
    private FeatureFlagHelper featureFlagHelper;

    private static final Logger logger = LoggerFactory.getLogger(CartAddDeviceHelper.class);

    private static final Gson gson = new Gson();


    public void setCaseIdCartIdIntentCheck(boolean caseIdCartIdIntentCheck) {
        this.caseIdCartIdIntentCheck = caseIdCartIdIntentCheck;
    }

    /**
     * @param request
     * @return AddDeviceUIResponse
     */
    @SuppressWarnings("unchecked")
    public Mono<AddDeviceUIResponse> addDevice(AddDeviceUIRequest request, ServerHttpResponse httpResponse) {
        Mono<CartRedisData> rr = redisHelper.getDataFromRedis();
        return rr.flatMap(data -> preHandleAddDevice.execute(request, data)
                .flatMap(res -> {
                    if (!res) {
                        return Mono.error(new SOEHTTPException(500, SOEErrorHolder.builder().errors(CartPegaRequestErrorsUtil.restrictMultiLineFlowError()).build()));
                    }
                    if (request.getCartInfo() != null && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                            && request.getCartInfo().getIntendType().equalsIgnoreCase(CartConstants.EUP)
                            && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getMhash())
                            && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getAccountNumber())) {
                        AddDeviceUIResponse addDeviceUIResponse = new AddDeviceUIResponse();
                        Mono<Boolean> oneclickEligibilityMono = isEligibleForOneClickCheckout(request, addDeviceUIResponse, data)
                                .doOnError(e -> logger.error("exception during one click validation", e))
                                .onErrorReturn(Boolean.FALSE);
                        return oneclickEligibilityMono.flatMap(resp -> {
                            if (resp) {
                                return Mono.just(addDeviceUIResponse);
                            }
                            return addDevice(request, data, httpResponse);
                        });
                    }
                    return addDevice(request, data, httpResponse);
                }));
    }

    Mono<Boolean> isEligibleForOneClickCheckout(AddDeviceUIRequest request, AddDeviceUIResponse addDeviceResponse, CartRedisData data) {
        Mono<CustomerProfileGraphQLResponse> customerProfileResponse = cxpServices.getCustomerProfileDigitalwihtoutRTD(request.getCartInfo().getAccountNumber());
        List<Mtn> eligibleMtn = new ArrayList<>();
        return customerProfileResponse.flatMap(custProfileRes -> {
            if (custProfileRes != null && custProfileRes.getData() != null && custProfileRes.getData().getCustomer() != null
                    && CollectionUtilities.isNotEmptyOrNull(custProfileRes.getData().getCustomer().getBillAccounts())) {
                String customerType = getCustomerType(custProfileRes);
                custProfileRes.getData().getCustomer().getBillAccounts().forEach(billAccount -> {
                    if (billAccount != null && CollectionUtilities.isNotEmptyOrNull(billAccount.getMtns())) {
                        billAccount.getMtns().stream().forEach(mtn -> {
                            if (mtn != null && request.getCartInfo() != null
                                    && StringUtilities.isNotEmptyOrNull(mtn.getMtnHashCode())
                                    && StringUtilities.isNotEmptyOrNull(mtn.getMtn())
                                    && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getMhash())
                                    && (mtn.getMtnHashCode().equalsIgnoreCase(String.valueOf(request.getCartInfo().getMhash()))
                                    || mtn.getMtn().substring(6).equalsIgnoreCase(String.valueOf(request.getCartInfo().getMhash())))) {
                                if (isEligibleCustomer(mtn, billAccount, customerType)) {
                                    eligibleMtn.add(mtn);
                                }
                            }
                        });
                    }
                });
            }
            if (CollectionUtilities.isNotEmptyOrNull(eligibleMtn) && eligibleMtn.size() > 0 && eligibleMtn.get(0) != null) {
                ValidateOffersRequest voRequest = prepareVORequest(eligibleMtn.get(0), request);
                long startTime = System.currentTimeMillis();
                return cxpHelper2.validateOffers(voRequest).flatMap(validateOffersResponse -> {
                    if (validateOffersResponse != null && validateOffersResponse.getData() != null
                            && validateOffersResponse.getData().isValidOffer() && CollectionUtilities.isNotEmptyOrNull(validateOffersResponse.getData().getEligibleMtns())
                            && validateOffersResponse.getData().getEligibleMtns().contains(eligibleMtn.get(0).getMtn())) {
                        prepareAddStepOneClickResponse(addDeviceResponse, eligibleMtn.get(0), request, validateOffersResponse);
                        return Mono.just(Boolean.TRUE);
                    }
                    return Mono.just(Boolean.FALSE);
                }).doOnError(e -> {
                    logger.error("Error while validating MyOffers from CXP ", e);
                    logger.debug("Total time for validateOffers  {} ", (System.currentTimeMillis() - startTime) / 1000);
                });
            }
            return Mono.just(Boolean.FALSE);
        });
    }


    /**
     * @param request
     * @return AddDeviceUIResponse
     */
    @SuppressWarnings("unchecked")
    public Mono<AddDeviceUIResponse> addDevice(AddDeviceUIRequest request, CartRedisData data, ServerHttpResponse httpResponse) {
        String channelType = CartUtil.getChannelType(request.getChannelId());
        Mono<CartRedisData> rr = redisHelper.getDataFromRedis();
        Mono<MyOfferRedisData> mor = redisHelper.getMyOfferDataFromRedis();
        Mono<MyOfferETRRedisData> moEtrData = redisHelper.getMyOfferETRDataFromRedis();
        Mono<String> mtnToPlanIdJsonStr = redisHelper.getMtnToPlanIdMap();
        Mono<String> oneClickCheckoutFlag = redisHelper.getOneClickCheckoutFlag();
        Mono<String> roleData = redisHelper2.getRole();
        Mono<BVPRedisData> bvpRedisData = redisHelper.getBVPDataFromRedis();
        Mono<FiveGAddressRedisData> fiveGAddress = redisHelper.getFiveGAddressFromRedis();
        Mono<List<InEligibleLinesRedisData>> ineligibleUpgLines = redisHelper.getInEligibleUpgradeLinesFromRedis();
        Mono<String> loggedInUser = redisHelper2.getLoggedInUser();
        AtomicReference<String> bogoMtn = new AtomicReference<>("");
        AtomicReference<Boolean> aal = new AtomicReference<>(false);
        AtomicReference<String> spoMtn = new AtomicReference<>("");
        AddDeviceUIResponse addDeviceUIResponse = new AddDeviceUIResponse();
        UpdateRedisDataToRequest(data, request);
        //validate feature flag and set lgpo details from session in AddDeviceUI request based on session value
        Mono<Boolean> isLGPOEnabledMono = featureFlagUtil.isFeatureEnabled(FeatureFlagConstants.AWS_CONFIG_APP_NAME, FeatureFlagConstants.AWS_CONFIG_PROFILE, FeatureFlagConstants.FLAG_NAME_LGPO_OFFER, true);
        Mono<Boolean> isCartOperationWithUUIDEnabledMono = featureFlagUtil.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL, FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART, FeatureFlagConstants.FLAG_NAME_CART_OPERATION_WITH_UUID, true);
        Mono<Boolean> flexV2_D2D = featureFlagHelper.fetchD2DFeatureFlag();
        Mono<Boolean> isElvisFlagEnabledMono = Mono.just(Boolean.FALSE);
        if (CartConstants.NSE.equals(request.getCartInfo().getIntendType()) && isDigital(channelType)) {
            //new Customer
            isElvisFlagEnabledMono = featureFlagHelper.fetchMonoElvisFeatureFlag(true);
        }else {
            isElvisFlagEnabledMono = featureFlagHelper.fetchMonoElvisFeatureFlag(false);
        }
        return Mono.zip(roleData, isCartOperationWithUUIDEnabledMono, isLGPOEnabledMono, isElvisFlagEnabledMono, flexV2_D2D).flatMap(tuple3 -> {
            String vzwRole = tuple3.getT1();
            boolean isCartOperationWithUUIDEnabled = tuple3.getT2();
            boolean isLgpoEnabled = tuple3.getT3();
            if (isLgpoEnabled) {
                setLGPORedisDataInRequest(data, request);
            }
            request.setFlexV2D2D(tuple3.getT5());
            boolean isElvisFlagEnabled = tuple3.getT4();
            logger.info("Elvis Feature Flag : {} ", isElvisFlagEnabled);
            if (!isElvisFlagEnabled && null != request.getData().getLines()) {
                request.getData().getLines().stream()
                        .filter(line -> null != line.getDevice())
                        .forEach(line -> line.getDevice().setLoanOfferId(null));
            }

            if (isDigital(channelType) && checkForAccountMemberRestriction(request, vzwRole)) {
                return Mono.error(new SOEHTTPException(500, SOEErrorHolder.builder().errors(CartPegaRequestErrorsUtil.mobileSecureConnectedSmartWatchError()).build()));
            }
            if (request.getCartInfo() != null && request.getCartInfo().isFlexV2()) {
                cartRequestBuilder.buildAddDeviceRequest(request, data);
                logger.info("Request build ", request);
            }

            //fix to update secondNumber in request from session data for both 1.0 & 2.0 flow
            if (data.getDualNumber() != null) {
                cartRequestBuilder.setDualNumberForAddDeviceRequest(request, data.getDualNumber());
            }
            if (StringUtilities.isNotEmptyOrNull(data.getFlowName())) {
                request.setFlowName(data.getFlowName());
            }
            if (null != request.getData() && CollectionUtilities.isNotEmptyOrNull(request.getData().getLines())
                    && null != request.getData().getLines().get(0).getDevice()
                    && StringUtilities.isEmptyOrNull(request.getData().getLines().get(0).getDevice().getId())
                    && StringUtilities.isNotEmptyOrNull(data.getDeviceSorId())) {
                request.getData().getLines().get(0).getDevice().setId(data.getDeviceSorId());
            } else if (null != request.getData() && null != request.getData().getLines()
                    && null != request.getData().getLines().get(0) && null != request.getData().getLines().get(0).getDevice()
                    && StringUtilities.isEmptyOrNull(request.getData().getLines().get(0).getDevice().getId())
                    && StringUtilities.isEmptyOrNull(data.getDeviceSorId())) {
                List<CartError> errors = new ArrayList<CartError>();
                CartError error = new CartError();
                error.setNamespace(CartConstants.SOE_CART_SERVICE);
                //error.setId(CartConstants.FIVEG_ADDR_MISSING);
                error.setName(CartConstants.REQUEST_VALIDATION_ERROR);
                error.setMessage(CartConstants.DEVICEID + " is/are missing.");
                errors.add(error);
                addDeviceUIResponse.setErrors(errors);
                return Mono.just(addDeviceUIResponse);
            }

            // clearing caseId & cartId for digital for non sop/soa caseId
            if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))
                    && StringUtilities.isNotEmptyOrNull(data.getCaseId()) && StringUtilities.isNotEmptyOrNull(data.getCartId())) {
                String caseId = data.getCaseId() != null ? data.getCaseId() : "";
                boolean caseIdMatched = bpmSalesOrderPurchaseCaseIdPrefix.stream().anyMatch(domain -> caseId.toUpperCase().contains(domain));
                if (!caseIdMatched) {
                    data.setCaseId(StringUtils.EMPTY);
                    data.setCartId(StringUtils.EMPTY);
                }
            }

            //Added for MVP 2 when device $$$ is greater than $500

            if ((CartConstants.OMNI_TELESALES.equalsIgnoreCase(request.getChannelId()) ||
                    CartConstants.CHAT_STORE.equalsIgnoreCase(request.getChannelId())) && CartConstants.Y.equalsIgnoreCase(data.getIsPrepayCart())) {

                if (null != request.getData() && null != request.getData().getLines()
                        && null != request.getData().getLines().get(0) && null != request.getData().getLines().get(0).getDevice() &&
                        request.getData().getLines().get(0).getDevice().getAmount() > Integer.parseInt(minimumBillAmount)) {
                    logger.info("Inside minimum bill amount condition $ :: " + Integer.valueOf(minimumBillAmount));
                    String repRole = data.getRepRole();
                    logger.info(String.format("the role value is :: %s", repRole));
                    if (!ignoreRoles.contains(repRole)) {
                        logger.info("role and  bill amount condition satisfied :: " + Integer.valueOf(minimumBillAmount));

                        AddDeviceUIResponse errorResponse = new AddDeviceUIResponse();
                        errorResponse.setErrors(CartPegaRequestErrorsUtil.handleRoleAmountRequestErrors(repRole, minimumBillAmount));
                        return Mono.just(errorResponse);
                    }
                }
            }

            if (AAL.equalsIgnoreCase(request.getCartInfo().getIntendType())
                    && (null != request.getCartInfo() && null != request.getCartInfo().getIsPrepayCart()
					&& "Y".equalsIgnoreCase(request.getCartInfo().getIsPrepayCart())))
			{
                request.getCartInfo().setCustomerType(data.getCustomerType());
                request.getCartInfo().setCreditAppNum(data.getCreditAppNum());
                data.setAccountNumber("");
            }

            Map<String, String> cartinfo = new HashMap<>();
            if (StringUtilities.isNotEmptyOrNull(data.getFiosAuthenticated())) {
                cartinfo.put("AddDevice.FiosAuthenticated", data.getFiosAuthenticated());
            } else {
                cartinfo.put("AddDevice.FiosAuthenticated", "Not Authenticated");
            }
            cartAddDeviceHelper1.logDataInfo("cartInfo", cartinfo);
            if (StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType()) && StringUtilities.isNotEmptyOrNull(data.getIntendType())) {
                request.getCartInfo().setIntendType(data.getIntendType());
            }
            //MVP2 BVQ-2663
            if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getCaseId())
                    && request.getCartInfo().getCaseId().startsWith("SOF", 0)
					&& request.getCartInfo().getOneClick()!=null && request.getCartInfo().getOneClick())
			{
                request.getCartInfo().setOneClick(request.getCartInfo().getOneClick());
            }

            boolean isIntendTypeNSE = (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()) && request.getCartInfo().getIntendType().toUpperCase().contains("NSE"));
            if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED)) {
                if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()) && request.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getCreditAppNum())) {
                    request.getCartInfo().setCreditAppNum(data.getCreditAppNum());
                    request.getCartInfo().setCartCreator(data.getCreditAppNum());
                }
            }
            if (isDigital(channelType)) {
                if (getzipCode(request)) {
                    List<CartError> errors = new ArrayList<CartError>();
                    CartError error = new CartError();
                    error.setNamespace(CartConstants.SOE_CART_SERVICE);
                    error.setName(CartConstants.REQUEST_VALIDATION_ERROR);
                    error.setMessage(CartConstants.ZIPCODE_INVALID);
                    errors.add(error);
                    addDeviceUIResponse.setErrors(errors);
                    return Mono.just(addDeviceUIResponse);
                }
            }
            if (CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))
                    && (StringUtilities.isNotEmptyOrNull(data.getVerifiedName()))) {
                String verifiedName = data.getVerifiedName();
                if (verifiedName.contains(" ")) {
                    List<String> nameList = Arrays.asList(verifiedName.split(" "));
                    if (CollectionUtilities.isNotEmptyOrNull(nameList) && nameList.size() == 2) {
                        if (null != request.getCartInfo().getAuthorizedUser()) {
                            request.getCartInfo().getAuthorizedUser().setFirstName(nameList.get(0));
                            request.getCartInfo().getAuthorizedUser().setLastName(nameList.get(1));
                        } else {

                            //else block here.
                            AuthorizedUser authUser = new AuthorizedUser();
                            authUser.setFirstName(nameList.get(0));
                            authUser.setLastName(nameList.get(1));
                            request.getCartInfo().setAuthorizedUser(authUser);
                        }
                    }
                }
            }
            if (!CartConstants.CHANNEL_ID_BBP.equalsIgnoreCase(request.getCartInfo().getClientAppName()) && CartConstants.BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
                if (StringUtilities.isEmptyOrNull(data.getDeviceId()) && CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))) {
                    request.getCartInfo().setDeviceId(data.getDeviceId());
                    logger.info("BYOD DeviceId get from Redis");//CXTDT-217608
                }
                logger.info("NSA BYOD DeviceId Set from Redis");
            }

            if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getDeviceType()) && CartConstants.CONNECTED_CAR.equalsIgnoreCase(request.getCartInfo().getDeviceType())) {
                request.getCartInfo().setDeviceId(data.getImei());
            }

            // Setting exchange shop details required for RFEX
            if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))
                    && CartConstants.REX.equalsIgnoreCase(request.getCartInfo().getIntendType())
                    && StringUtilities.isNotEmptyOrNull(data.getRfexExchangeShopDetails())) {
                RfexExchangeShopDetails rfexExchangeShopDetails = gson.fromJson(data.getRfexExchangeShopDetails(),
                        RfexExchangeShopDetails.class);
                logger.info("Shop Details available from cache {}", rfexExchangeShopDetails);
                request.setRfexExchangeShopDetails(rfexExchangeShopDetails);
            }
            //Setting the appUniversalId for MVA Prospect flow
            if (isCartOperationWithUUIDEnabled
                    && CartConstants.NSE.equals(request.getCartInfo().getIntendType())
                    && request.getChannelId().contains(CartConstants.VZW_MFA)
                    && request.getHttpRequest() != null
                    && !request.getHttpRequest().getCookies().isEmpty()
                    && request.getHttpRequest().getCookies().getFirst(CartConstants.UUID) != null) {
                HttpCookie uuidCookie = request.getHttpRequest().getCookies().getFirst(CartConstants.UUID);
                if (uuidCookie != null && StringUtilities.isNotEmptyOrNull(uuidCookie.getValue()))
                    request.setAppUniversalId(uuidCookie.getValue());
            }

            if ((!isIntendTypeNSE || (request.getCartInfo() != null && CartConstants.DVM_CONVERSION_FLOWTYPE.equals(request.getCartInfo().getFlowType()))) && StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
                request.getCartInfo().setAccountNumber(data.getAccountNumber());
            if (StringUtilities.isNotEmptyOrNull(data.getVzwRoles())) {
                request.getCartInfo().setAmRole(data.getVzwRoles());
            }
            // below condition is introduced to check prospect case Id or cart Id exists already in the session, if it exists then case Id & cart Id
            // are not carry forward to PEGA request.
            boolean caseIdCartIdExists = caseIdCartIdIntentCheck ?
                    CartUtil.hasProspectCustomerChangedLoggedIn(data, request.getChannelId(), request.getCartInfo().getIntendType(), prospectFlows, existingCustomerFlows) : false;
            boolean refundAndExchangeCaseorCartIdExists = CartUtil.hasCustomerSwitchedfromREXToPurchase(data, request.getChannelId(), request.getCartInfo().getIntendType(), existingCustomerFlows);
            logger.info("refundAndExchangeCaseorCartIdExists {} ", refundAndExchangeCaseorCartIdExists);
            //for BBp flow setting cartid and case id empty
            if (CartConstants.CHANNEL_ID_BBP.equalsIgnoreCase(request.getCartInfo().getClientAppName()) && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getDeviceType()) && !CartConstants.CONNECTED_CAR.equalsIgnoreCase(request.getCartInfo().getDeviceType())) {
                request.getCartInfo().setCartId("");
				}
			else if(StringUtilities.isEmptyOrNull(request.getCartInfo().getCartId())
                    && StringUtilities.isNotEmptyOrNull(data.getCartId()) && !caseIdCartIdExists) {
                request.getCartInfo().setCartId(data.getCartId());
            }
            if (CartConstants.CHANNEL_ID_BBP.equalsIgnoreCase(request.getCartInfo().getClientAppName()) && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getDeviceType()) && !CartConstants.CONNECTED_CAR.equalsIgnoreCase(request.getCartInfo().getDeviceType())) {
                request.getCartInfo().setCaseId("");
				}
			else if(StringUtilities.isEmptyOrNull(request.getCartInfo().getCaseId())
                    && StringUtilities.isNotEmptyOrNull(data.getCaseId()) && !caseIdCartIdExists) {
                request.getCartInfo().setCaseId(data.getCaseId());
            }

            if (plansFirstCartExistCheck && isDigital(channelType) && isIntendTypeNSE && CartConstants.P.equalsIgnoreCase(request.getCartInfo().getMtnFlow()))
                checkCartExistsOverride(request);

            if (!isIntendTypeNSE && StringUtilities.isEmptyOrNull(request.getCartInfo().getCartCreator())
                    && StringUtilities.isNotEmptyOrNull(data.getMtn()))
                request.getCartInfo().setCartCreator(data.getMtn());
            if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getMtnFlow())
                    && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessStep())
                    && !request.getCartInfo().getMtnFlow().equals("G")
                    && CartConstants.GRIDWALLPDP.equalsIgnoreCase(request.getCartInfo().getProcessStep())) {
                if (!AAL.equalsIgnoreCase(request.getCartInfo().getIntendType()) && StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
                        && StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessingMTN()))
                    request.getCartInfo().setProcessingMTN(data.getProcessingMTN());
            }
            if (isDigital(channelType)) {
                if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessingMTN()) && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getMtnFlow())
                        && "G".equalsIgnoreCase(request.getCartInfo().getMtnFlow())
                        && CartConstants.GRIDWALLPDP.equalsIgnoreCase(request.getCartInfo().getProcessStep())) {
                    request.getCartInfo().setProcessingMTN("");
                }
            }
            if (!isIntendTypeNSE && StringUtilities.isEmptyOrNull(request.getCartInfo().getCartCreator())
                    && StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
                request.getCartInfo().setCartCreator(data.getCartCreator());

            if (StringUtilities.isNotEmptyOrNull(data.getRpsIntent())) {
                request.getCartInfo().setRpsIntent(data.getRpsIntent());
            }

            if (StringUtilities.isNotEmptyOrNull(data.getBogoMtn())) {
                bogoMtn.set(data.getBogoMtn());
            }

            if (StringUtilities.isNotEmptyOrNull(data.getSpoMtn()))
                spoMtn.set(data.getSpoMtn());

            if (CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId())) && (StringUtilities.isEmptyOrNull(request.getCartInfo().getCaseId()) || StringUtilities.isEmptyOrNull(request.getCartInfo().getCartId()))) {
                AddDeviceUIResponse errorResponse = new AddDeviceUIResponse();
                errorResponse.setErrors(CartPegaRequestErrorsUtil.validateCartIdAndCaseId(request.getCartInfo()));
                return Mono.just(errorResponse);
            }

            if (enableMHOffers && StringUtilities.isNotEmptyOrNull(data.getExternalID())) {
                request.setExternalId(data.getExternalID());
            }
            if (StringUtilities.isNotEmptyOrNull(data.getVzId())) {
                request.setVzId(data.getVzId());
            }
            if (refundAndExchangeCaseorCartIdExists) {
                request.getCartInfo().setCaseId("");
                request.getCartInfo().setCartId("");
            }
            if (enableUidDomainFilter) {
                String uId = data.getUId() != null ? data.getUId() : "";
                boolean uIdMatched = uIdEnabledDomains.stream().anyMatch(domain -> uId.contains(domain));
                logger.info("UID :: {} :: uIdMatched :: {}", uId, uIdMatched);
                if (uIdMatched && StringUtilities.isNotEmptyOrNull(data.getUniversalId())) {
                    request.setUniversalId(data.getUniversalId());
                }
            } else {
                if (StringUtilities.isNotEmptyOrNull(data.getUniversalId())) {
                    request.setUniversalId(data.getUniversalId());
                }
            }
            if (data.getHighRiskMtnList() != null) {
                Map highRiskMtnList = data.getHighRiskMtnList();
                if (CartConstants.ASSISTED.equalsIgnoreCase(channelType) && !highRiskMtnList.isEmpty()) {
                    for (Lines lineData : request.getData().getLines()) {
                        if (highRiskMtnList.containsKey(lineData.getMtn()) && "EUP".equalsIgnoreCase(request.getCartInfo().getIntendType())) {
                            lineData.setHighDecileIndicator(highRiskMtnList.get(lineData.getMtn()).toString());
                        }
                    }
                }
            }

            boolean inWithVerizonOptedReq = null != request.getData().getLines() && request.getData().getLines().stream().anyMatch(line -> line.isInWithVerizonOpted());
            if (inWithVerizonOptedReq) {
                Map<String, String> inWithVerizonInfo = new HashMap<>();
                inWithVerizonInfo.put("inWithVerizonInfo", String.valueOf(inWithVerizonOptedReq));
                cartAddDeviceHelper1.logDataInfo("cartInfo", inWithVerizonInfo);
            }
            // VZWCS-16603 Changes Start
            if ("CHAT-STORE".equalsIgnoreCase(request.getChannelId())) {
                if (null != request.getCartInfo()
                        && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                        && "NSE".equalsIgnoreCase(request.getCartInfo().getIntendType())) {
                    if (request.getData().getLines().get(0).getDevice() != null && StringUtilities.isNotEmptyOrNull(
                            request.getData().getLines().get(0).getDevice().getNetworkBandwidthType())) {
                        if ("CBD".equalsIgnoreCase(
                                request.getData().getLines().get(0).getDevice().getNetworkBandwidthType())
                                || "LTE".equalsIgnoreCase(
                                request.getData().getLines().get(0).getDevice().getNetworkBandwidthType())) {
                            boolean mucFlag = false;
                            logger.info("muc flag value from redis for chatstore {}", data.getMuc());
                            if ("5GH05".equalsIgnoreCase(data.getMuc())) {
                                mucFlag = true;
                            }
                            request.getCartInfo().setFiveGMUCEligible(String.valueOf(mucFlag));
                        }
                    }
                }
            }
            //ACT54-1138 NGS - Multiline Prospect Kill Switch
            if (null != request.getData()
                    && CollectionUtilities.isNotEmptyOrNull(request.getData().getLines()) && CartConstants.NSE.equalsIgnoreCase(Optional.of(request)
                    .map(AddDeviceUIRequest::getCartInfo).map(DeviceCartInfo::getIntendType).orElse(""))) {
                for (Lines line : request.getData().getLines()) {
                    if (null != data.getIsCommonPDP()) {
                        line.setIsCommonPDP(data.getIsCommonPDP());
                        logger.info("set the isCommonPDP value in CJCM request: {}", data.getIsCommonPDP());
                    }
                }
            }

            if (isDigital(channelType) && CartUtil.isByodFlow(request.getCartInfo().getIntendType()) &&
                    request.getData().getImeiFromSession() != null && request.getData().getImeiFromSession()) {
                for (Lines line : request.getData().getLines()) {
                    if (line.getDevice() != null && line.getSim() != null && line.getDevice().getSmartIMEI() != null && !line.getDevice().getSmartIMEI()) {
                        if (data.getDeviceImeiSimDetails() != null) {
                            setByodDataFromRedis(data.getDeviceImeiSimDetails(), line.getDevice(), line.getSim());
                            if (StringUtilities.isEmptyOrNull(line.getDevice().getDeviceId()))
                                return Mono.error(new SOEHTTPException(500, SOEErrorHolder.builder().errors(CartPegaRequestErrorsUtil.emptyDeviceIdErrorResponse()).build()));
                        } else
                            return Mono.error(new SOEHTTPException(500, SOEErrorHolder.builder().errors(CartPegaRequestErrorsUtil.emptyDeviceIdErrorResponse()).build()));
                    }
                }
            }
            Mono<AddDeviceUIResponse> errorPastDue = setPastDueInRequest(request, data, channelType);
            if (errorPastDue != null) return errorPastDue;

            // VZWCS-16603 Changes End
            if (null != request.getData().getLines().get(0).getE911Address())
                CartAddDeviceUtil.logE911Address(request.getData().getLines().get(0).getE911Address());
            return redisHelper2.getEdgeBuyoutRedisData().flatMap(ebData -> {
                if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))
                        && "M".equalsIgnoreCase(request.getCartInfo().getMtnFlow())) {
                    if (null != request.getData().getLines() && !request.getData().getLines().isEmpty()) {
                        for (Lines line : request.getData().getLines()) {
                            if (null != line && StringUtilities.isNotEmptyOrNull(line.getMtn()) && null != ebData.get(line.getMtn())) {
                                CartRedisData edgeBuyoutData = mapper.convertValue(ebData.get(line.getMtn()),
                                        CartRedisData.class);

                                if (null != edgeBuyoutData.getBuyOutData()) {
                                    AddBuyoutData bData = edgeBuyoutData.getBuyOutData();
                                    if (StringUtilities.isNotEmptyOrNull(bData.getRecommDevId()))
                                        request.getData().setRecommDevId(bData.getRecommDevId());
                                    if (StringUtilities.isNotEmptyOrNull(bData.getRecommSkuId()))
                                        request.getData().setRecommSkuId(bData.getRecommSkuId());
                                    if (null != bData.getMtnSOIRecommendation())
                                        request.getData().setMtnSOIRecommendation(bData.getMtnSOIRecommendation());
                                    if (null != edgeBuyoutData.getCartInfo()) {
                                        CartInfo cartInfo = edgeBuyoutData.getCartInfo();
                                        if (StringUtilities.isNotEmptyOrNull(cartInfo.getBuyOutFlag()))
                                            request.getCartInfo().setBuyOutFlag(cartInfo.getBuyOutFlag());
                                        if (StringUtilities.isNotEmptyOrNull(cartInfo.getBuyOutSelected()))
                                            request.getCartInfo().setBuyOutSelected(cartInfo.getBuyOutSelected());
                                        if (StringUtilities.isNotEmptyOrNull(cartInfo.getEdgeUpSelected()))
                                            request.getCartInfo().setEdgeUpSelected(cartInfo.getEdgeUpSelected());
                                        line.setIsEdgeBuyOut(true);
                                    }
                                }
                                if (null != edgeBuyoutData.getEdgeUpData()) {
                                    UpdateEdgeupData eData = edgeBuyoutData.getEdgeUpData();
                                    if (StringUtilities.isNotEmptyOrNull(eData.getRecommDevId()))
                                        request.getData().setRecommDevId(eData.getRecommDevId());
                                    if (StringUtilities.isNotEmptyOrNull(eData.getRecommSkuId()))
                                        request.getData().setRecommSkuId(eData.getRecommSkuId());
                                    if (null != eData.getMtnSOIRecommendation())
                                        request.getData().setMtnSOIRecommendation(eData.getMtnSOIRecommendation());
                                    if (null != eData.getLines() && eData.getLines().length > 0) {
                                        for (Lines eLine : eData.getLines()) {
                                            if (null != eLine.getEdgeup()) {
                                                line.setEdgeup(eLine.getEdgeup());
                                                //  DOPMO-193770 - Tradein is invalid for return and upgrade. so removing tradin promo info from request to pega for edgeup scenario
                                                if (null != line && line.getSelectedPromoType() != null && line.getSelectedPromoType().equalsIgnoreCase("TRADEIN_PROMO")) {
                                                    line.setTradeInInfo(null);
                                                    line.setSelectedPromoType("NOPROMO");
                                                    line.setSelectedPromoId(null);
                                                    line.setPromoRejectionIndicator(true);
                                                }
                                            }
                                        }
                                    }
                                    if (null != edgeBuyoutData.getCartInfo()) {
                                        CartInfo cartInfo = edgeBuyoutData.getCartInfo();
                                        if (StringUtilities.isNotEmptyOrNull(cartInfo.getBuyOutFlag()))
                                            request.getCartInfo().setBuyOutFlag(cartInfo.getBuyOutFlag());
                                        if (StringUtilities.isNotEmptyOrNull(cartInfo.getBuyOutSelected()))
                                            request.getCartInfo().setBuyOutSelected(cartInfo.getBuyOutSelected());
                                        if (StringUtilities.isNotEmptyOrNull(cartInfo.getEdgeUpSelected()))
                                            request.getCartInfo().setEdgeUpSelected(cartInfo.getEdgeUpSelected());
                                        if (StringUtilities.isNotEmptyOrNull(cartInfo.getFmiTurnedOff()))
                                            request.getCartInfo().setFmiTurnedOff(cartInfo.getFmiTurnedOff());
                                        if (StringUtilities.isNotEmptyOrNull(cartInfo.getDeviceMisMatched()))
                                            request.getCartInfo().setDeviceMisMatched(cartInfo.getDeviceMisMatched());
                                        if (StringUtilities.isNotEmptyOrNull(cartInfo.getEstTradeInValue()))
                                            request.getCartInfo().setEstTradeInValue(cartInfo.getEstTradeInValue());

                                    }
                                }
                            }
                        }
                    }

                }
                return redisHelper2.getEdgeBuyoutDetails().flatMap(upgradeBuyoutDetails -> {
                    if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))
                            && EUP.equalsIgnoreCase(request.getCartInfo().getIntendType())
                            && "M".equalsIgnoreCase(request.getCartInfo().getMtnFlow()) && CollectionUtilities.isNotEmptyOrNull(upgradeBuyoutDetails)
                            && upgradeBuyoutDetails.get(request.getCartInfo().getProcessingMTN()) != null) {
                        UpgradeBuyoutMtnData upgradeBuyoutData = mapper.convertValue(upgradeBuyoutDetails.get(request.getCartInfo().getProcessingMTN()),
                                UpgradeBuyoutMtnData.class);
                        logger.info("setting the values in cartInfo");
//						request.getCartInfo().setBuyOutFlag(upgradeBuyoutData.getBuyOutFlag());
//						request.getCartInfo().setTwoYearUpgrade(upgradeBuyoutData.getTwoYearUpgrade());
//						request.getCartInfo().setMyvPage(true);
                    }
                    return fiveGAddress.flatMap(address -> {
                        if (null != request.getCartInfo()
                                && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                                && ("AAL_5G".equalsIgnoreCase(request.getCartInfo().getIntendType()) || "NSE_5G".equalsIgnoreCase(request.getCartInfo().getIntendType()))
                                && CollectionUtilities.isNotEmptyOrNull(address.getErrors())) {
                            AddDeviceUIResponse errorResponse = new AddDeviceUIResponse();
                            errorResponse.setErrors(address.getErrors());
                            return Mono.just(errorResponse);
                        }
                        if (StringUtilities.isNotEmptyOrNull(request.getChannelId())
                                && (CartConstants.OMNI_TELESALES.equalsIgnoreCase(request.getChannelId()) || request.isFlexV2D2D() &&
                                request.getChannelId().equalsIgnoreCase(CartConstants.OMNI_D2D)
                                || request.getChannelId().equalsIgnoreCase(CartConstants.D2D_IPAD))) {
                            CartAddDeviceUtil.checkAndUpdateNetworkBdType(data, request, address);
                        }
                        if (null != address.getAddressRequest()) {
                            CartAddDeviceUtil.populateFiveGAddress(request, address.getAddressRequest());
                        }
                        return mtnToPlanIdJsonStr.flatMap(mtnToPlanIdJson -> roleData.flatMap(role -> {
                            if (StringUtilities.isNotEmptyOrNull(mtnToPlanIdJson)) {
                                logger.debug(String.format("mtnToPlanIdJson is not null --> %s", mtnToPlanIdJson));
                                logger.error(String.format("mtnToPlanIdJson is not null --> %s", mtnToPlanIdJson));
                            } else {
                                logger.debug("mtnToPlanIdJson is null");
                                logger.error("mtnToPlanIdJson is null");
                            }

                            return oneClickCheckoutFlag.defaultIfEmpty(CartConstants.FALSE).flatMap(oneClickCheckout -> redisHelper2.getDeviceCartMap()
                                    .flatMap(cartmap -> {
                                        String iconicTestIntent = "";
                                        int deviceListCount = 0;
                                        boolean cartHasPCD = false;
                                        List<Lines> redisCartlines = null;
                                        if (null != cartmap) {
                                            Map<String, String> cartMapObj = (HashMap<String, String>) cartmap;
                                            deviceListCount = (StringUtilities
                                                    .isNotEmptyOrNull(cartMapObj.get("deviceCount")))
                                                    ? Integer.valueOf(cartMapObj.get("deviceCount"))
                                                    : 0;
                                            if (deviceListCount > 0) {
                                                cartHasPCD = StringUtilities.isNotEmptyOrNull(cartMapObj.get("cartHasPCD"))
                                                        && cartMapObj.get("cartHasPCD").equalsIgnoreCase("true");
                                            }
                                        }
                                        boolean preconfigure = false;
                                        if (null != request && null != request.getData()) {
                                            redisCartlines = request.getData().getLines();
                                        }
                                        if (null != redisCartlines && !redisCartlines.isEmpty()
                                                && null != redisCartlines.get(0).getDevice()
                                                && StringUtilities.isNotEmptyOrNull(
                                                redisCartlines.get(0).getDevice().getPreconfigure())
                                                && Boolean.valueOf(redisCartlines.get(0).getDevice().getPreconfigure())) {
                                            preconfigure = true;
                                        }
                                        logger.info("preconfigure from request: " + preconfigure
                                                + "cartHasPCD: " + cartHasPCD + "deviceCount: " + deviceListCount);
                                        if (cartHasPCD) {
                                            preconfigure = true;
                                        }
                                        logger.info("PCCItem {}", preconfigure);
                                        logger.info("cartHasPCD {}", cartHasPCD);
                                        logger.info("oneClickCheckout {}", oneClickCheckout);
                                        Mono<String> throttleNameMono = Mono.just("");
                                        Mono<CradleResponse> respFromCradle = Mono.just(new CradleResponse());
                                        try {

                                            if (request.getHttpRequest() != null && request.getHttpRequest().getCookies() != null
                                                    && request.getHttpRequest().getCookies().size() > 0
                                                    && request.getHttpRequest().getCookies().getFirst(CartConstants.ICONIC_TEST_INTENT) != null &&
                                                    StringUtilities.isNotEmptyOrNull(request.getHttpRequest().getCookies().getFirst(CartConstants.ICONIC_TEST_INTENT).getValue())) {
                                                iconicTestIntent = request.getHttpRequest().getCookies().getFirst(CartConstants.ICONIC_TEST_INTENT).getValue();
                                                if (StringUtils.isNotEmpty(iconicTestIntent) && request != null
                                                        && request.getCartInfo() != null) {
                                                    logger.info("iconicTestIntent authorized as {}", iconicTestIntent);
                                                    request.getCartInfo().setIconicTestIntent(iconicTestIntent);
                                                }
                                            }
                                            logger.info(String.format("Iconic Authentication Cookie : %s", iconicTestIntent));
                                            if (null != request.getCartInfo() && StringUtilities
                                                    .isNotEmptyOrNull(request.getCartInfo().getIntendType())) {
                                                String intent = request.getCartInfo().getIntendType();
                                                // intent is not the same as intendType. This code is never going to execute
                                                if (intent.equalsIgnoreCase("upgrade")) {
                                                    intent = EUP;
                                                }
                                                String cartCount = "";
                                                Boolean editDevice = false;
                                                if (null != request.getCartInfo() && null != request.getCartInfo().getEditDevice())
                                                    editDevice = request.getCartInfo().getEditDevice();
                                                if (request != null &&
                                                        request.getData() != null &&
                                                        request.getData().getLines() != null &&
                                                        request.getData().getLines().size() > 0) {
                                                    if (!editDevice) {
                                                        if (StringUtilities.isNotEmptyOrNull(data.getCartCount()))
                                                            cartCount = String.valueOf(Integer.parseInt(data.getCartCount())
                                                                    + request.getData().getLines().size());
                                                        else
                                                            cartCount = String.valueOf(request.getData().getLines().size());
												}
												else{
                                                        if (StringUtilities.isNotEmptyOrNull(data.getCartCount())) {
                                                            cartCount = data.getCartCount();
                                                        }
                                                    }
                                                }
                                                if (null != request.getCartInfo()
                                                        && null != request.getCartInfo().getExpressCheckout()
                                                        && request.getCartInfo().getExpressCheckout()
                                                        && StringUtilities.isNotEmptyOrNull(oneClickCheckout)
                                                        && Boolean.valueOf(oneClickCheckout)) {
                                                    throttleNameMono = Mono.just(CartConstants.PROMO_HUB);
                                                    if (CartConstants.NSE.equalsIgnoreCase(intent)) {
                                                        throttleNameMono = Mono.just(CartConstants.ACCESSORIES_INTERSTIAL_PROSPECT);
                                                    }
                                                    logger.info("express checkout and oneclick  {}", oneClickCheckout);
                                                } else {
                                                    if (StringUtilities.isNotEmptyOrNull(intent) &&
                                                            ("BYOD".equalsIgnoreCase(intent))
                                                            && cartAddDeviceHelper1.SetThrottleForSecondDevice(request, oneClickCheckout,
                                                            deviceListCount, intent)) {
                                                        respFromCradle = cartAddDeviceHelper1.invokeCradleForPromoHub(request,
                                                                mtnToPlanIdJson, intent, role, preconfigure, oneClickCheckout, iconicTestIntent, cartCount);
                                                    } else if (CartAddDeviceUtil.isEditDeviceOneClick(request, oneClickCheckout)) {
                                                        throttleNameMono = Mono.just(CartConstants.PROMO_HUB);
                                                        if (CartConstants.NSE.equalsIgnoreCase(intent)) {
                                                            throttleNameMono = Mono.just(CartConstants.ACCESSORIES_INTERSTIAL_PROSPECT);
                                                        }
                                                        if (StringUtils.isNotEmpty(iconicTestIntent) && request != null
                                                                && request.getCartInfo() != null) {
                                                            logger.info("iconicTestIntent authorized from cradle {}", iconicTestIntent);
                                                            request.getCartInfo().setIconicTestIntent(iconicTestIntent);
                                                        }
                                                        logger.info("edit device {}", oneClickCheckout);
                                                    } else if (CartConstants.NSE.equalsIgnoreCase(intent) || CartConstants.NSE_BYOD.equalsIgnoreCase(intent)) {
                                                        respFromCradle = cartAddDeviceHelper1.invokeCradleForPromoHub(request, mtnToPlanIdJson,
                                                                intent, role, preconfigure, oneClickCheckout, iconicTestIntent, cartCount);
                                                        logger.info("nse device {}", oneClickCheckout);
                                                    } else if (cartAddDeviceHelper1.SetThrottleForSecondDevice(request, oneClickCheckout,
                                                            deviceListCount, intent)) {
                                                        logger.info("Inside SetThrottleForSecondDevice promoHub deviceList :{},max Device Allowed :{}", deviceListCount, maxDevicesAllowedPromoHub);
                                                        respFromCradle = cartAddDeviceHelper1.invokeCradleForPromoHub(request, mtnToPlanIdJson,
                                                                intent, role, preconfigure, oneClickCheckout, iconicTestIntent, cartCount);
                                                    } else if ((deviceListCount == 0 || (EUP.equalsIgnoreCase(intent)
                                                            && deviceListCount == 1 && null != request.getCartInfo()
                                                            && StringUtilities
                                                            .isNotEmptyOrNull(request.getCartInfo().getMtnFlow())
                                                            && request.getCartInfo().getMtnFlow().equalsIgnoreCase("G")))
                                                            && CartAddDeviceUtil.AllowCradleCheck(request, intent)) {
                                                        logger.info("nse device {}", oneClickCheckout);
                                                        respFromCradle = cartAddDeviceHelper1.invokeCradleForPromoHub(request, mtnToPlanIdJson,
                                                                intent, role, preconfigure, oneClickCheckout, iconicTestIntent, cartCount);
                                                    } else if (cartAddDeviceHelper1.invokeCradleForPccThrottleList(request, iconicTestIntent)) {
                                                        logger.info(String.format("Invoking cradle for pcc throttleList %s", iconicTestIntent));
                                                        respFromCradle = cartAddDeviceHelper1.invokeCradleForPromoHub(request, mtnToPlanIdJson,
                                                                intent, role, preconfigure, oneClickCheckout, iconicTestIntent, cartCount);
                                                    }
                                                }

                                                // Added to handle shared cart clear and continue
                                                if (null != request.getData().getClearCart()
                                                        && request.getData().getClearCart() && "MTNSelectionPage"
                                                        .equalsIgnoreCase(request.getCartInfo().getProcessStep())) {
                                                    respFromCradle = cartAddDeviceHelper1.invokeCradleForPromoHub(request, mtnToPlanIdJson,
                                                            intent, role, preconfigure, oneClickCheckout, iconicTestIntent, cartCount);
                                                }

                                            }

                                        } catch (JsonProcessingException e1) {
                                            logger.error(CartConstants.JSON_PRCSSNG_EXCPTN_STRNG + e1);
                                        }
                                        Mono<String> throttleNameMonoFinal = (null != throttleNameMono) ? throttleNameMono
                                                : Mono.empty();
                                        Mono<CradleResponse> respFromCradleFinal = (null != respFromCradle) ? respFromCradle
                                                : Mono.empty();
                                        final String iconicTestIntentFinal = iconicTestIntent;
                                        return mor.flatMap(
                                                myOfferData -> respFromCradleFinal.defaultIfEmpty(new CradleResponse())
                                                        .flatMap(lCradleResponse -> throttleNameMonoFinal.defaultIfEmpty("")
                                                                .flatMap(throttleName -> {
                                                                    try {
                                                                        if (null != lCradleResponse
                                                                                && null != lCradleResponse.getOutPut()) {
                                                                            logger.debug(String.format("cradleResponse output is --> %s",
                                                                                    lCradleResponse.getOutPut()));

                                                                            JsonNode cradleOutputJsonNode = mapper
                                                                                    .readTree(lCradleResponse.getOutPut());
                                                                            if (StringUtils.isNotEmpty(iconicTestIntentFinal)) {
                                                                                cartAddDeviceHelper1.setIconicTestIntentInRequest(request, cradleOutputJsonNode, iconicTestIntentFinal);
                                                                            }

                                                                            if (null != cradleOutputJsonNode
                                                                                    && null != cradleOutputJsonNode.get(
                                                                                    CartConstants.CRADLE_FLOW_JOURNEY)) {
                                                                                String cradleFlowJourney = cradleOutputJsonNode
                                                                                        .get(CartConstants.CRADLE_FLOW_JOURNEY)
                                                                                        .asText();
                                                                                if (StringUtils.isNotBlank(cradleFlowJourney)) {
                                                                                    throttleName = cradleFlowJourney;
                                                                                }
                                                                                if (cradleFlowJourney.equalsIgnoreCase(
                                                                                        CartConstants.PRE_CONFIGURED)) {
                                                                                    request.setPreConfigured(Boolean.TRUE);
                                                                                    throttleName = CartConstants.PROMO_HUB;
                                                                                }
                                                                            }
                                                                            if (null != cradleOutputJsonNode
                                                                                    && null != cradleOutputJsonNode.get(
                                                                                    CartConstants.CDL_THROTTLE_LIST)) {
                                                                                String cdlThrottleList = cradleOutputJsonNode
                                                                                        .get(CartConstants.CDL_THROTTLE_LIST)
                                                                                        .asText();
                                                                                if (StringUtils.isNotBlank(cdlThrottleList) && null != httpResponse) {

                                                                                    httpResponse.addCookie(
                                                                                            ResponseCookie.from(CartConstants.ADD_DEVICE_CDL_THROTTLE_LIST, cdlThrottleList).path("/").httpOnly(false).build());

                                                                                }
                                                                            }

                                                                        } else {
                                                                            logger.debug("cradleResponse output is null");
                                                                        }
                                                                    } catch (Exception e) {

                                                                    }
                                                                    final String throttleNameFinal = throttleName;
                                                                    if (myOfferData.getIsMyOfferAccepted() != null
                                                                            && myOfferData.getIsMyOfferAccepted()) {
                                                                        List<Lines> newLines = request.getData().getLines()
                                                                                .stream().map(line -> {
                                                                                    line.setRtdOfferId(
                                                                                            myOfferData.getRtdOfferId());
                                                                                    line.setRestricted(
                                                                                            myOfferData.getRestricted());
                                                                                    line.setRestrictedProductType(
                                                                                            myOfferData
                                                                                                    .getRestrictedProductType());
                                                                                    return line;
                                                                                }).collect(Collectors.toList());
                                                                        request.getData().setLines(newLines);
                                                                    }
                                                                    List<UpdateBarcodeBarcodeId> barCodeIds = new ArrayList<>();
                                                                    List<BvoOffers> selectedOffersList = new ArrayList<>();
                                                                    return moEtrData.flatMap(myOfferEtrData -> {
                                                                        Boolean trade3POChoiceFlag = featureFlagHelper.trade3POChoiceOfferFFlag();
                                                                        if (!CartConstants.PROMOBUNDLE.equalsIgnoreCase(request.getCartInfo().getMtnFlow()))
                                                                            if (CollectionUtilities.isNotEmptyOrNull(
                                                                                    myOfferEtrData.getLines())) {
                                                                                myOfferEtrData.getLines().stream()
                                                                                        .filter(Objects::nonNull)
                                                                                        .forEach(line -> {
                                                                                            List<Lines> requestLines = Optional
                                                                                                    .ofNullable(
                                                                                                            request.getData()
                                                                                                                    .getLines())
                                                                                                    .orElse(new ArrayList<Lines>());
                                                                                            if (null != request.getCartInfo()
                                                                                                    && StringUtilities
                                                                                                    .isNotEmptyOrNull(
                                                                                                            request.getCartInfo()
                                                                                                                    .getIntendType())
                                                                                                    && AAL
                                                                                                    .equalsIgnoreCase(
                                                                                                            request.getCartInfo()
                                                                                                                    .getIntendType())
                                                                                                    && null != line
                                                                                                    .getOffers()) {

                                                                                                for (Offer offer : line
                                                                                                        .getOffers()) {
                                                                                                    if (StringUtilities
                                                                                                            .isNotEmptyOrNull(
                                                                                                                    offer.getAal())
                                                                                                            && "Y".equalsIgnoreCase(
                                                                                                            offer.getAal())) {
                                                                                                        aal.set(true);
                                                                                                    }
                                                                                                    if (aal.get() && CartConstants.OC_NATIONAL.equalsIgnoreCase(myOfferEtrData.getOfferSourceSystem()) &&
                                                                                                            CartConstants.EQP.equalsIgnoreCase(offer.getComplianceType())) {
                                                                                                        aal.set(false);
                                                                                                    }
                                                                                                }
                                                                                            }

                                                                                            for (Lines requestLine : requestLines) {
                                                                                                List<AddPromoIntent> promoIntentList = new ArrayList<>();
                                                                                                if (aal.get() || StringUtilities
                                                                                                        .isNotEmptyOrNull(
                                                                                                                requestLine
                                                                                                                        .getMtn())) {
                                                                                                    Boolean choiceMtnMatched = null != line.getMtn() && line.getMtn().replace(" ", "").equalsIgnoreCase(requestLine.getLineNumber());
                                                                                                    Boolean mtnMatched = StringUtilities.isNotEmptyOrNull(requestLine.getMtn()) && requestLine.getMtn().equalsIgnoreCase(line.getMtn());
                                                                                                    Boolean bogoMtnMatched = aal.get() && StringUtilities.isNotEmptyOrNull(bogoMtn.get()) && requestLine.getMtn().equalsIgnoreCase(bogoMtn.get());
                                                                                                    String restrictedProductType = StringUtilities.isNotEmptyOrNull(requestLine.getRestrictedProductType()) ?
                                                                                                            requestLine.getRestrictedProductType() : "";
                                                                                                    if (CollectionUtilities
                                                                                                            .isNotEmptyOrNull(
                                                                                                                    line.getOffers())) {
                                                                                                        line.getOffers()
                                                                                                                .stream()
                                                                                                                .filter(Objects::nonNull)
                                                                                                                .forEach(
                                                                                                                        offer -> {
                                                                                                                            if (AAL.equalsIgnoreCase(request.getCartInfo().getIntendType()) && StringUtilities.isNotEmptyOrNull(offer.getOfferSubType())
                                                                                                                                    && CartConstants.PAY_OFF_YOUR_DEVICE.equalsIgnoreCase(offer.getOfferSubType())) {

                                                                                                                                portInCheck(data, requestLine.getMtn());
                                                                                                                                BvoOffers offers = new BvoOffers();
                                                                                                                                offers.setId(offer.getSku());
                                                                                                                                offers.setSubType(offer.getOfferSubType());
                                                                                                                                selectedOffersList.add(offers);

                                                                                                                            }
                                                                                                                            if (((aal.get() && StringUtilities.isEmptyOrNull(bogoMtn.get())) || bogoMtnMatched || mtnMatched)
                                                                                                                                    && StringUtilities.isNotEmptyOrNull(offer.getOfferType()) &&
                                                                                                                                    CartConstants.MULTI_LINE_BOGO.equalsIgnoreCase(offer.getOfferType())) {
                                                                                                                                BvoOffers offers = new BvoOffers();
                                                                                                                                offers.setId(offer.getSku());
                                                                                                                                offers.setSubType(offer.getOfferType());
                                                                                                                                selectedOffersList.add(offers);
                                                                                                                            }

                                                                                                                            if (aal.get() && StringUtilities.isEmptyOrNull(bogoMtn.get()) &&
                                                                                                                                    StringUtilities.isNotEmptyOrNull(offer.getOfferType()) &&
                                                                                                                                    CartConstants.MULTI_LINE_BOGO.equalsIgnoreCase(offer.getOfferType()))
                                                                                                                                bogoMtn.set(requestLine.getMtn());
                                                                                                                            if (mtnMatched && StringUtilities.isNotEmptyOrNull(offer.getOfferType()) &&
                                                                                                                                    CartConstants.TRADE.equalsIgnoreCase(offer.getOfferType())) {
                                                                                                                                BvoOffers offers = new BvoOffers();
                                                                                                                                offers.setId(offer.getSku());
                                                                                                                                offers.setSubType(offer.getOfferType());
                                                                                                                                selectedOffersList.add(offers);
                                                                                                                            }

                                                                                                                            if (choiceMtnMatched && (request.getCartInfo().getIntendType().contains(AAL) ||
                                                                                                                                    request.getCartInfo().getIntendType().contains(BYOD))
                                                                                                                                    && StringUtilities.isNotEmptyOrNull(offer.getSku())
                                                                                                                                    && StringUtilities.isNotEmptyOrNull(offer.getIsChoiceOffer())
                                                                                                                                    && "Y".equalsIgnoreCase(offer.getIsChoiceOffer())) {
                                                                                                                                AddPromoIntent promoIntent = new AddPromoIntent();
                                                                                                                                promoIntent.setOfferId(offer.getSku());
                                                                                                                                promoIntent.setChoiceOffer(true);
                                                                                                                                if (StringUtilities.isNotEmptyOrNull(offer.getOfferSubType())) {
                                                                                                                                    promoIntent.setPromoType(offer.getOfferSubType());
                                                                                                                                }
                                                                                                                                promoIntentList.add(promoIntent);
                                                                                                                            }

                                                                                                                            if ((CartConstants.BYOD
                                                                                                                                    .equalsIgnoreCase(
                                                                                                                                            request.getCartInfo()
                                                                                                                                                    .getIntendType()) || AAL.equalsIgnoreCase(
                                                                                                                                    request.getCartInfo().getIntendType())) && aal.get() &&
                                                                                                                                    (StringUtilities.isEmptyOrNull(spoMtn.get()) ||
                                                                                                                                            requestLine.getMtn().equalsIgnoreCase(spoMtn.get()))
                                                                                                                                    && "SFO".equalsIgnoreCase(
                                                                                                                                    offer.getComplianceType())
                                                                                                                                    && StringUtilities
                                                                                                                                    .isNotEmptyOrNull(
                                                                                                                                            offer.getSku())) {
                                                                                                                                spoMtn.set(requestLine.getMtn());
                                                                                                                                Feature newFeature = new Feature();
                                                                                                                                newFeature
                                                                                                                                        .setId(offer
                                                                                                                                                .getSku());
                                                                                                                                newFeature
                                                                                                                                        .setQuantity(
                                                                                                                                                1);
                                                                                                                                newFeature
                                                                                                                                        .setType(
                                                                                                                                                "SFO");
                                                                                                                                newFeature
                                                                                                                                        .setActionIndicator(
                                                                                                                                                "A");
                                                                                                                                if (offer.getSku() != null) {
                                                                                                                                    if (CollectionUtilities
                                                                                                                                            .isNotEmptyOrNull(
                                                                                                                                                    requestLine
                                                                                                                                                            .getAddFeatures())) {
                                                                                                                                        requestLine
                                                                                                                                                .getAddFeatures()
                                                                                                                                                .add(newFeature);
                                                                                                                                    } else {
                                                                                                                                        List<Feature> newFeatureList = new ArrayList<>();
                                                                                                                                        newFeatureList.add(newFeature);
                                                                                                                                        requestLine.setAddFeatures(newFeatureList);
                                                                                                                                    }
                                                                                                                                }
																													}if(AAL.equalsIgnoreCase(request.getCartInfo().getIntendType())
                                                                                                                                    && aal.get() && (StringUtilities.isEmptyOrNull(spoMtn.get()) || requestLine.getMtn().equalsIgnoreCase(spoMtn.get()))
                                                                                                                                    && "SPO".equalsIgnoreCase(offer.getComplianceType()) && StringUtilities.isNotEmptyOrNull(offer.getSku())) {
                                                                                                                                spoMtn.set(requestLine.getMtn());
                                                                                                                                Feature newFeature = new Feature();
                                                                                                                                newFeature.setId(offer.getSku());
                                                                                                                                newFeature.setQuantity(1);
                                                                                                                                newFeature.setType("SPO");
                                                                                                                                newFeature.setActionIndicator("A");
                                                                                                                                if (CollectionUtilities
                                                                                                                                        .isNotEmptyOrNull(
                                                                                                                                                requestLine
                                                                                                                                                        .getAddFeatures())) {
                                                                                                                                    requestLine
                                                                                                                                            .getAddFeatures()
                                                                                                                                            .add(newFeature);


                                                                                                                                } else {
                                                                                                                                    List<Feature> newFeatureList = new ArrayList<>();
                                                                                                                                    newFeatureList
                                                                                                                                            .add(newFeature);
                                                                                                                                    requestLine
                                                                                                                                            .setAddFeatures(
                                                                                                                                                    newFeatureList);
                                                                                                                                }

                                                                                                                            }

                                                                                                                            if (StringUtilities
                                                                                                                                    .isNotEmptyOrNull(
                                                                                                                                            offer.getComplianceType())
                                                                                                                                    && CartConstants.EQP
                                                                                                                                    .equalsIgnoreCase(
                                                                                                                                            offer.getComplianceType())) {
                                                                                                                                requestLine
                                                                                                                                        .setRestricted(
                                                                                                                                                "Y");

                                                                                                                                if (StringUtilities
                                                                                                                                        .isNotEmptyOrNull(
                                                                                                                                                restrictedProductType)
                                                                                                                                        && !restrictedProductType
                                                                                                                                        .contains(
                                                                                                                                                offer.getComplianceType()))
                                                                                                                                    requestLine
                                                                                                                                            .setRestrictedProductType(
                                                                                                                                                    restrictedProductType
                                                                                                                                                            + "|"
                                                                                                                                                            + offer.getComplianceType());
                                                                                                                                else if (StringUtilities
                                                                                                                                        .isNotEmptyOrNull(
                                                                                                                                                restrictedProductType))
                                                                                                                                    requestLine
                                                                                                                                            .setRestrictedProductType(
                                                                                                                                                    restrictedProductType);
                                                                                                                                else
                                                                                                                                    requestLine
                                                                                                                                            .setRestrictedProductType(
                                                                                                                                                    offer.getComplianceType());
                                                                                                                            } else if (StringUtilities
                                                                                                                                    .isNotEmptyOrNull(
                                                                                                                                            offer.getRewardType())
                                                                                                                                    && CartConstants.DEVICE_DOLLARS
                                                                                                                                    .equalsIgnoreCase(
                                                                                                                                            offer.getRewardType())) {
                                                                                                                                UpdateBarcodeBarcodeId barCodeId = new UpdateBarcodeBarcodeId();
                                                                                                                                barCodeId
                                                                                                                                        .setBarCodeId(
                                                                                                                                                offer.getBarcodeId());
                                                                                                                                barCodeIds
                                                                                                                                        .add(barCodeId);
                                                                                                                            }

                                                                                                                        });
                                                                                                    }

                                                                                                }
                                                                                                //prospect offer central - Act5

                                                                                                if (null != request.getCartInfo() && null != request.getCartInfo().getIntendType() &&
                                                                                                        (CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType()) ||
                                                                                                                CartConstants.NSE_5G.equalsIgnoreCase(request.getCartInfo().getIntendType()) ||
                                                                                                                CartConstants.NSE_LTE.equalsIgnoreCase(request.getCartInfo().getIntendType()) ||
                                                                                                                CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())) &&
                                                                                                        CollectionUtilities.isNotEmptyOrNull(line.getOffers()) && StringUtilities.isNotEmptyOrNull(requestLine.getRestrictedProductType())
                                                                                                        && CartConstants.EQP.equalsIgnoreCase(requestLine.getRestrictedProductType()) &&
                                                                                                        null != line.getMultiLineSeqNumber() && null != requestLine.getMultiLineSeqNumber()
                                                                                                        && line.getMultiLineSeqNumber().equals(requestLine.getMultiLineSeqNumber())) {
                                                                                                    line.getOffers()
                                                                                                            .stream()
                                                                                                            .filter(Objects::nonNull)
                                                                                                            .forEach(
                                                                                                                    offer -> {
                                                                                                                        BvoOffers offers = new BvoOffers();
                                                                                                                        offers.setId(offer.getSku());
                                                                                                                        offers.setSubType(offer.getOfferType());
                                                                                                                        if (StringUtilities.isNotEmptyOrNull(offer.getOfferSubType()) && CartConstants.PAY_OFF_YOUR_DEVICE.equalsIgnoreCase(offer.getOfferSubType())) {
                                                                                                                            offers.setSubType(offer.getOfferSubType());
                                                                                                                        }
                                                                                                                        selectedOffersList.add(offers);

                                                                                                                        //Choice Offer Impl for prospect
                                                                                                                        if (StringUtilities.isNotEmptyOrNull(offer.getSku())
                                                                                                                                && StringUtilities.isNotEmptyOrNull(offer.getIsChoiceOffer())
                                                                                                                                && "Y".equalsIgnoreCase(offer.getIsChoiceOffer())) {
                                                                                                                            AddPromoIntent promoIntent = new AddPromoIntent();
                                                                                                                            promoIntent.setOfferId(offer.getSku());
                                                                                                                            promoIntent.setChoiceOffer(true);
                                                                                                                            if (null != trade3POChoiceFlag && trade3POChoiceFlag && StringUtilities.isNotEmptyOrNull(offer.getOfferSubType())) {
                                                                                                                                promoIntent.setPromoType(offer.getOfferSubType());
                                                                                                                            }
                                                                                                                            promoIntentList.add(promoIntent);
                                                                                                                        }
                                                                                                                    });
                                                                                                }

                                                                                                if (StringUtilities.isNotEmptyOrNull(requestLine.getMtn()) && requestLine.getMtn().equalsIgnoreCase(line.getMtn())
                                                                                                        && null != trade3POChoiceFlag && trade3POChoiceFlag && null != request.getCartInfo()
                                                                                                        && null != request.getCartInfo().getIntendType()
                                                                                                        && request.getCartInfo().getIntendType().equalsIgnoreCase(EUP)) {
                                                                                                    line.getOffers()
                                                                                                            .stream()
                                                                                                            .filter(Objects::nonNull)
                                                                                                            .forEach(
                                                                                                                    offer -> {
                                                                                                                        if (StringUtilities.isNotEmptyOrNull(offer.getSku())
                                                                                                                                && StringUtilities.isNotEmptyOrNull(offer.getIsChoiceOffer())
                                                                                                                                && "Y".equalsIgnoreCase(offer.getIsChoiceOffer())) {
                                                                                                                            AddPromoIntent promoIntent = new AddPromoIntent();
                                                                                                                            promoIntent.setOfferId(offer.getSku());
                                                                                                                            promoIntent.setChoiceOffer(true);
                                                                                                                            if (StringUtilities.isNotEmptyOrNull(offer.getOfferSubType())) {
                                                                                                                                promoIntent.setPromoType(offer.getOfferSubType());
                                                                                                                            }
                                                                                                                            promoIntentList.add(promoIntent);
                                                                                                                        }
                                                                                                                    });
                                                                                                }

                                                                                                requestLine.setSelectedOffers(selectedOffersList);
                                                                                                if (CollectionUtilities.isNotEmptyOrNull(promoIntentList)) {
                                                                                                    requestLine.setPromoIntent(promoIntentList);
                                                                                                }
                                                                                            }

                                                                                        });
                                                                            }

                                                                        return bvpRedisData.flatMap(bvpData -> {
                                                                            return loggedInUser.flatMap(loggedInUserData -> {
                                                                                List<BVPLine> bvpLines = Optional
                                                                                        .ofNullable(bvpData.getLines())
                                                                                        .orElse(new ArrayList<BVPLine>());
                                                                                if (!CartConstants.PROMOBUNDLE.equalsIgnoreCase(request.getCartInfo().getMtnFlow())) {
                                                                                    bvpLines.stream().filter(Objects::nonNull)
                                                                                            .forEach(bvpLine -> {
                                                                                                List<Lines> requestLines = Optional
                                                                                                        .ofNullable(
                                                                                                                request.getData()
                                                                                                                        .getLines())
                                                                                                        .orElse(new ArrayList<Lines>());
                                                                                                for (Lines requestLine : requestLines) {
                                                                                                    if (StringUtilities
                                                                                                            .isNotEmptyOrNull(
                                                                                                                    bvpLine.getMtn())
                                                                                                            && StringUtilities
                                                                                                            .isNotEmptyOrNull(
                                                                                                                    requestLine
                                                                                                                            .getMtn())
                                                                                                            && bvpLine.getMtn()
                                                                                                            .equalsIgnoreCase(
                                                                                                                    requestLine
                                                                                                                            .getMtn())) {
                                                                                                        Optional.ofNullable(bvpLine)
                                                                                                                .map(BVPLine::getGetBestValuePromotions)
                                                                                                                .ifPresent(
                                                                                                                        getBestValuePromotions -> {
                                                                                                                            getBestValuePromotions
                                                                                                                                    .getBestValueOffers()
                                                                                                                                    .stream()
                                                                                                                                    .filter(Objects::nonNull)
                                                                                                                                    .forEach(
                                                                                                                                            bvOffer -> {

                                                                                                                                                // rtd
                                                                                                                                                // call
                                                                                                                                                NBXFeedbackRequest nbxRequest = nbxService
                                                                                                                                                        .formatNbxFeedbackRequest(
                                                                                                                                                                bvpLine,
                                                                                                                                                                request.getCartInfo()
                                                                                                                                                                        .getAccountNumber(), loggedInUserData);
                                                                                                                                                nbxService
                                                                                                                                                        .nbxFeedbackCall(
                                                                                                                                                                nbxRequest)
                                                                                                                                                        .subscribeOn(
                                                                                                                                                                Schedulers
                                                                                                                                                                        .parallel())
                                                                                                                                                        .subscribe(
                                                                                                                                                                nbx -> {
                                                                                                                                                                    logger.info(
                                                                                                                                                                            "NBX Request is {} & the response is {}",
                                                                                                                                                                            nbxRequest,
                                                                                                                                                                            nbx);
                                                                                                                                                                });

                                                                                                                                                if (bvOffer
                                                                                                                                                        .getVerizonUpAccepted()) {
                                                                                                                                                    if (StringUtilities
                                                                                                                                                            .isNotEmptyOrNull(
                                                                                                                                                                    bvOffer.getBarcode())) {
                                                                                                                                                        UpdateBarcodeBarcodeId barCodeId = new UpdateBarcodeBarcodeId();
                                                                                                                                                        barCodeId
                                                                                                                                                                .setBarCodeId(
                                                                                                                                                                        bvOffer.getBarcode());
                                                                                                                                                        barCodeIds
                                                                                                                                                                .add(barCodeId);
                                                                                                                                                    }
                                                                                                                                                }
                                                                                                                                                if (bvOffer
                                                                                                                                                        .getMyOffer()) {
                                                                                                                                                    requestLine
                                                                                                                                                            .setRestricted(
                                                                                                                                                                    "Y");
                                                                                                                                                    requestLine
                                                                                                                                                            .setRestrictedProductType(
                                                                                                                                                                    CartConstants.EQP);
                                                                                                                                                }
                                                                                                                                                if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getBogoEnabled()) &&
                                                                                                                                                        request.getCartInfo().getBogoEnabled().equalsIgnoreCase("True")) {
                                                                                                                                                    if (StringUtilities.isNotEmptyOrNull(bvOffer.getOfferSubType())
                                                                                                                                                            && CartConstants.TRADE.equalsIgnoreCase(bvOffer.getOfferSubType())
                                                                                                                                                            && bvOffer.getTradeInAccepted() != null
                                                                                                                                                            && bvOffer.getTradeInAccepted()) {
                                                                                                                                                        BvoOffers selectedOffers = new BvoOffers();
                                                                                                                                                        selectedOffers.setId(bvOffer.getId());
                                                                                                                                                        selectedOffers.setDescription(bvOffer.getName());
                                                                                                                                                        selectedOffers.setSubType(bvOffer.getOfferSubType());
                                                                                                                                                        selectedOffersList.add(selectedOffers);
                                                                                                                                                    }
                                                                                                                                                    if (StringUtilities.isNotEmptyOrNull(bvOffer.getOfferSubType())
                                                                                                                                                            && CartConstants.MULTI_LINE_BOGO.equalsIgnoreCase(bvOffer.getOfferSubType())
                                                                                                                                                            && bvOffer.getBogoOfferAccepted() != null && bvOffer.getBogoOfferAccepted()
                                                                                                                                                    ) {
                                                                                                                                                        BvoOffers selectedOffers = new BvoOffers();
                                                                                                                                                        selectedOffers.setId(bvOffer.getId());
                                                                                                                                                        selectedOffers.setSubType(bvOffer.getOfferSubType());
                                                                                                                                                        selectedOffers.setDescription(bvOffer.getName());
                                                                                                                                                        selectedOffersList.add(selectedOffers);
                                                                                                                                                    }
                                                                                                                                                    if (StringUtilities.isNotEmptyOrNull(bvOffer.getOfferSubType())
                                                                                                                                                            && CartConstants.MULTI_LINE_BMSM.equalsIgnoreCase(bvOffer.getOfferSubType())
                                                                                                                                                            && bvOffer.getBogoOfferAccepted() != null && bvOffer.getBogoOfferAccepted()
                                                                                                                                                    ) {
                                                                                                                                                        BvoOffers selectedOffers = new BvoOffers();
                                                                                                                                                        selectedOffers.setId(bvOffer.getId());
                                                                                                                                                        selectedOffers.setSubType(bvOffer.getOfferSubType());
                                                                                                                                                        selectedOffers.setDescription(bvOffer.getName());
                                                                                                                                                        selectedOffersList.add(selectedOffers);
                                                                                                                                                    }
                                                                                                                                                }
                                                                                                                                            });
                                                                                                                        });
                                                                                                    }
                                                                                                    requestLine.setSelectedOffers(selectedOffersList);
                                                                                                }

                                                                                            });
                                                                                }
                                                                                request.getCartInfo().setBarCodeIds(barCodeIds);
                                                                                return ineligibleUpgLines.flatMap(ieuData -> {
                                                                                    List<Lines> requestLines = Optional
                                                                                            .ofNullable(request.getData()
                                                                                                    .getLines())
                                                                                            .orElse(new ArrayList<Lines>());
                                                                                    for (Lines requestLine : requestLines) {
                                                                                        if (null != ieuData
                                                                                                && ieuData.size() > 0) {
                                                                                            ieuData.forEach(ie -> {
                                                                                                if (StringUtilities
                                                                                                        .isNotEmptyOrNull(
                                                                                                                ie.getMtn())
                                                                                                        && StringUtilities
                                                                                                        .isNotEmptyOrNull(
                                                                                                                requestLine
                                                                                                                        .getMtn())
                                                                                                        && ie.getMtn()
                                                                                                        .equalsIgnoreCase(
                                                                                                                requestLine
                                                                                                                        .getMtn())) {
                                                                                                    if (StringUtilities
                                                                                                            .isEmptyOrNull(
                                                                                                                    requestLine
                                                                                                                            .getUpgradeReasonCode())
                                                                                                            && null != requestLine
                                                                                                            .getDevice()
                                                                                                            && StringUtilities
                                                                                                            .isNotEmptyOrNull(
                                                                                                                    requestLine
                                                                                                                            .getDevice()
                                                                                                                            .getContractTerm())) {
                                                                                                        if ("VERIZON_EDGE"
                                                                                                                .equalsIgnoreCase(
                                                                                                                        requestLine
                                                                                                                                .getDevice()
                                                                                                                                .getContractTerm()))
                                                                                                            requestLine
                                                                                                                    .setUpgradeReasonCode(
                                                                                                                            "MA");
                                                                                                        else if ("MONTH_TO_MONTH"
                                                                                                                .equalsIgnoreCase(
                                                                                                                        requestLine
                                                                                                                                .getDevice()
                                                                                                                                .getContractTerm()))
                                                                                                            requestLine
                                                                                                                    .setUpgradeReasonCode(
                                                                                                                            "MN");
                                                                                                        else if ("TWO_YEAR"
                                                                                                                .equalsIgnoreCase(
                                                                                                                        requestLine
                                                                                                                                .getDevice()
                                                                                                                                .getContractTerm()))
                                                                                                            requestLine
                                                                                                                    .setUpgradeReasonCode(
                                                                                                                            "M2");
                                                                                                    }
                                                                                                    if (StringUtilities
                                                                                                            .isNotEmptyOrNull(ie
                                                                                                                    .getReason())) {
                                                                                                        requestLine
                                                                                                                .setInEligibleReason(
                                                                                                                        ie.getReason());
                                                                                                    }
                                                                                                }
                                                                                            });
                                                                                        }
                                                                                    }
                                                                                    return redisHelper3.getHashCodeMtn(request).flatMap(mtnValue -> {
                                                                                        logger.info("AddDeviceHelper : MTN-Hashcode Read from Redis {}", mtnValue);

                                                                                        List<Lines> reqLines = Optional
                                                                                                .ofNullable(request.getData()
                                                                                                        .getLines())
                                                                                                .orElse(new ArrayList<Lines>());

                                                                                        for (Lines requestLine : reqLines) {

                                                                                            if (StringUtilities.isNotEmptyOrNull(mtnValue))
                                                                                                requestLine.setMtn(mtnValue);
                                                                                        }
                                                                                        try {
                                                                                            boolean isWhiteListed = false;
                                                                                            if (null != request.getCartInfo()
                                                                                                    && StringUtilities
                                                                                                    .isNotEmptyOrNull(
                                                                                                            request.getCartInfo()
                                                                                                                    .getCartCreator()))
                                                                                                isWhiteListed = cartAddDeviceHelper1.isWhiteListedMtn(
                                                                                                        request.getCartInfo()
                                                                                                                .getCartCreator());
                                                                                            logger.info("whitelisted mtn {}",
                                                                                                    isWhiteListed);
                                                                                            if (isWhiteListed
                                                                                                    && null != request.getData()
                                                                                                    && null != request.getData()
                                                                                                    .getLines()
                                                                                                    && null != request.getData()
                                                                                                    .getLines().get(0))
                                                                                                request.getData().getLines().get(0)
                                                                                                        .setQaIconicTesting(true);

                                                                                        } catch (Exception e) {
                                                                                            logger.info(
                                                                                                    "Exception in checking whiteListedMTN {}",
                                                                                                    e.getMessage());
                                                                                        }
                                                                                        //CRADLE CHANGES FOR COMBO ORDER
																				if (StringUtilities.isNotEmptyOrNull(data.getLocationCode()))
																				{
                                                                                            request.getCartInfo().setLocationCode(data.getLocationCode());
                                                                                        }
																				if (StringUtilities.isNotEmptyOrNull(data.getLoggedInUser()))
																				{
                                                                                            request.getCartInfo().setSalesRepId(data.getLoggedInUser());
                                                                                        }
                                                                                        Mono<Boolean> checkCradleResponse = cartAddDeviceHelper1.checkCradleResponseForComboOrderExistingCustomer(request);
                                                                                        return cartAddDeviceHelper1.setCradleFlagForCombo(checkCradleResponse, request).flatMap(request1 -> {
                                                                                            return cartAddDeviceHelper1.setCradleFlowJourneyForByodNextGenMVA(request1).flatMap(uiRequest -> {
                                                                                                return cartAddDeviceHelper1.updateMtnInUiRequest(uiRequest, data).flatMap(uiRequestMtnUpdate -> {
                                                                                                    Mono<AddDeviceUIResponse> UIResponse = bpmHelper
                                                                                                            .addDevice(uiRequestMtnUpdate,
                                                                                                                    throttleNameFinal)
                                                                                                            .doOnError(e -> logger.error(
                                                                                                                    CartConstants.ADD_DEVICE_METHOD_EXCEPTION,
                                                                                                                    e))
                                                                                                            .onErrorResume(
                                                                                                                    SOEHTTPException.class,
                                                                                                                    e -> {
                                                                                                                        if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))
                                                                                                                                || CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))) {
                                                                                                                            logger.error(
                                                                                                                                    CartConstants.ADD_DEVICE_METHOD_EXCEPTION,
                                                                                                                                    e.getErrorCode());

                                                                                                                            Mono<ResponseEntity<SOEErrorHolder>> errorHolder = exHandler
                                                                                                                                    .fetchAEMMessage(
                                                                                                                                            e)
                                                                                                                                    .doOnError(
                                                                                                                                            e1 -> logger
                                                                                                                                                    .error(CartConstants.ADD_DEVICE_METHOD_EXCEPTION,
                                                                                                                                                            e1))
                                                                                                                                    .onErrorResume(
                                                                                                                                            SOEHTTPException.class,
                                                                                                                                            e1 -> {
                                                                                                                                                return CartPegaResponseErrorsUtil
                                                                                                                                                        .handleAEMError(
                                                                                                                                                                e1);
                                                                                                                                            });
                                                                                                                            return errorHolder
                                                                                                                                    .flatMap(eh -> {
                                                                                                                                        SOEErrorHolder hold = eh
                                                                                                                                                .getBody();
                                                                                                                                        AddDeviceUIResponse resp = CartPegaResponseErrorsUtil
                                                                                                                                                .handleCommonError(
                                                                                                                                                        hold);
                                                                                                                                        return Mono
                                                                                                                                                .just(resp);
                                                                                                                                    });
                                                                                                                        }
                                                                                                                        return Mono.just(CartPegaResponseErrorsUtil.handleCommonError(e.getErrorHolder()));
                                                                                                                    });
                                                                                                    return UIResponse.flatMap(response -> {
                                                                                                        if (response.getErrors() == null
                                                                                                                && null != response) {
                                                                                                            if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED)) {
                                                                                                                if (CartConstants.PROMOBUNDLE.equalsIgnoreCase(request.getCartInfo().getMtnFlow()) &&
                                                                                                                        request.getCartInfo().getEditFromPage() != null
                                                                                                                        && "BundleRecommendationsPage".equalsIgnoreCase(request.getCartInfo().getEditFromPage())) {
                                                                                                                    return cxpHelper2.getNbsData(request, response);
                                                                                                                }
                                                                                                            }
                                                                                                            if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED) &&
                                                                                                                    StringUtilities.isNotEmptyOrNull(bogoMtn.get())) {
                                                                                                                try {
                                                                                                                    redisHelper3.updateBOGOMtn(bogoMtn.get()).doOnSuccess(onSuccess -> {
                                                                                                                        logger.info("BOGO Mtn is updated in redis...");
                                                                                                                    }).doOnError(error -> {
                                                                                                                        logger.info("Exception in updating BOGO Mtn to redis...");
                                                                                                                    });
                                                                                                                } catch (
                                                                                                                        Exception e) {
                                                                                                                    logger.info("Exception in updating BOGO Mtn to redis : {}", e.getMessage());
                                                                                                                }

                                                                                                            }
                                                                                                            if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED) &&
                                                                                                                    StringUtilities.isNotEmptyOrNull(spoMtn.get())) {
                                                                                                                try {
                                                                                                                    redisHelper3.updatespoMtn(spoMtn.get()).doOnSuccess(onSuccess -> {
                                                                                                                        logger.info("SPO Mtn is updated in redis...");
                                                                                                                    }).doOnError(error -> {
                                                                                                                        logger.info("Exception in updating SPO Mtn to redis...");
                                                                                                                    });
                                                                                                                } catch (
                                                                                                                        Exception e) {
                                                                                                                    logger.info("Exception in updating SPO Mtn to redis : {}", e.getMessage());
                                                                                                                }
                                                                                                            }
                                                                                                            if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED)) {
                                                                                                                try {
                                                                                                                    redisHelper3.resetConflictReviewStatus().doOnSuccess(onSuccess -> {
                                                                                                                        logger.info(" Conflicts status updated in redis...");
                                                                                                                    }).doOnError(error -> {
                                                                                                                        logger.info("Exception in updating Conflicts status in session...");
                                                                                                                    });
																									} catch (Exception e) {
                                                                                                                    logger.info("Exception in updating Conflicts to session : {}", e.getMessage());
                                                                                                                }

                                                                                                            }
                                                                                                            if (response.getServiceBody() != null
                                                                                                                    && response.getServiceBody().getServiceResponse() != null
                                                                                                                    && response.getServiceBody().getServiceResponse().getContext() != null
                                                                                                                    && response.getServiceBody().getServiceResponse().getContext().getCartInfo() != null
                                                                                                                    && response.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartId() != null
                                                                                                            ) {
                                                                                                                request.getCartInfo().setCartId(response.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartId());
                                                                                                            }
                                                                                                            //VZWYN-17835 changes
                                                                                                            if (StringUtilities.isNotEmptyOrNull(request.getChannelId())
                                                                                                                    && CartConstants.VZW_BBP.equalsIgnoreCase(request.getChannelId())
                                                                                                                    && StringUtilities.isNotEmptyOrNull(request.getData().getEsimFlowType()) &&
                                                                                                                    CartConstants.LOST_ICCID_PROFILE.equalsIgnoreCase(request.getData().getEsimFlowType())
                                                                                                                    && StringUtilities.isNotEmptyOrNull(data.getEsimType())
                                                                                                                    && (CartConstants.IPAD.equalsIgnoreCase(data.getEsimType())
                                                                                                                    || CartConstants.LAPTOP.equalsIgnoreCase(data.getEsimType()))) {
                                                                                                                ValidateCartCXPRequest validateRequest = cartAddDeviceHelper1.settingValidateCartCXPRequest(request, data);
                                                                                                                Mono<ValidateCartUIResponse> validateResponse = Mono.empty();
                                                                                                                validateResponse = cxpHelper.validateCart(validateRequest, null);
                                                                                                                return validateResponse.flatMap(validateCartResponse -> {
                                                                                                                    cartAddDeviceHelper1.settingValidateCartCXPResponse(validateCartResponse, response, validateRequest, data);

                                                                                                                    return Mono.just(response);
                                                                                                                });
                                                                                                            }

                                                                                                            if (StringUtilities
                                                                                                                    .isNotEmptyOrNull(
                                                                                                                            channelType)
                                                                                                                    && channelType
                                                                                                                    .equalsIgnoreCase(
                                                                                                                            CartConstants.DIGITAL)
                                                                                                                    && StringUtilities
                                                                                                                    .isNotEmptyOrNull(
                                                                                                                            request.getCartInfo()
                                                                                                                                    .getProcessStep())
                                                                                                                    && !CartConstants.PROMO_HUB
                                                                                                                    .equalsIgnoreCase(
                                                                                                                            request.getCartInfo()
                                                                                                                                    .getProcessStep())) {
                                                                                                                if (CartConstants.EUPBYOD
                                                                                                                        .equalsIgnoreCase(
                                                                                                                                request.getCartInfo()
                                                                                                                                        .getIntendType())
                                                                                                                        && !"VZW-RPS"
                                                                                                                        .equalsIgnoreCase(
                                                                                                                                request.getCartInfo()
                                                                                                                                        .getClientAppName())
                                                                                                                        && StringUtilities.isNotEmptyOrNull(request.getCartInfo()
                                                                                                                        .getCartId())) {
                                                                                                                    ValidateCartCXPRequest validateRequest = new ValidateCartCXPRequest();
                                                                                                                    //VZWYN-17835 changes
                                                                                                                    validateRequest = cartAddDeviceHelper1.settingValidateCartCXPRequest(request, data);

                                                                                                                    Mono<ValidateCartUIResponse> validateResponse = Mono
                                                                                                                            .empty();
                                                                                                                    validateResponse = cxpHelper
                                                                                                                            .validateCart(
                                                                                                                                    validateRequest, null);
                                                                                                                    //VZWYN-17835 changes
                                                                                                                    ValidateCartCXPRequest finalValidateRequest = validateRequest;

                                                                                                                    return validateResponse
                                                                                                                            .flatMap(
                                                                                                                                    validateCartResponse -> {
                                                                                                                                        //VZWYN-17835 changes
                                                                                                                                        cartAddDeviceHelper1.settingValidateCartCXPResponse(validateCartResponse, response, finalValidateRequest, data);
                                                                                                                                        return Mono
                                                                                                                                                .just(response);
                                                                                                                                    });
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                        if (CollectionUtilities.isEmptyOrNull(
                                                                                                                response.getErrors())) {
                                                                                                            try {
                                                                                                                if (!CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId())) && request.getData().getLines()
                                                                                                                        .size() > 0) {
                                                                                                                    String selectedPromoId = request
                                                                                                                            .getData()
                                                                                                                            .getLines().get(0)
                                                                                                                            .getSelectedPromoId();
                                                                                                                    String selectedPromoType = request
                                                                                                                            .getData()
                                                                                                                            .getLines().get(0)
                                                                                                                            .getSelectedPromoType();
                                                                                                                    String flowType = evaluteFlowType(request.getCartInfo().getIntendType());
                                                                                                                    String promosAppliedVal = "none";
                                                                                                                    String offerType = Boolean.TRUE.equals((request.getData().getLines().get(0).getIsStrategicOffer())) ? "S" : "N";
                                                                                                                    String choiceOrBau = CartConstants.IS_BAU_OFFER;
                                                                                                                    String selectedSedOfferId = request.getData().getLines().get(0).getSelectedSedOfferId();
                                                                                                                    if (StringUtilities
                                                                                                                            .isNotEmptyOrNull(
                                                                                                                                    selectedPromoId)
                                                                                                                            && StringUtilities
                                                                                                                            .isNotEmptyOrNull(
                                                                                                                                    selectedPromoType)) {
                                                                                                                        if (StringUtilities.isNotEmptyOrNull(selectedSedOfferId) && StringUtilities.isNotEmptyOrNull(flowType)) {
                                                                                                                            promosAppliedVal = selectedPromoType + "-" + selectedPromoId + "-" + offerType + "-" + choiceOrBau + "-" + flowType + "-" + selectedSedOfferId;
                                                                                                                        } else if (StringUtilities.isNotEmptyOrNull(selectedSedOfferId)) {
                                                                                                                            promosAppliedVal = selectedPromoType + "-" + selectedPromoId + "-" + offerType + "-" + choiceOrBau + "-" + selectedSedOfferId;
                                                                                                                        } else if (StringUtilities.isNotEmptyOrNull(flowType)) {
                                                                                                                            promosAppliedVal = selectedPromoType + "-" + selectedPromoId + "-" + offerType + "-" + choiceOrBau + "-" + flowType;
                                                                                                                        } else {
                                                                                                                            promosAppliedVal = selectedPromoType + "-" + selectedPromoId + "-" + offerType + "-" + choiceOrBau;
                                                                                                                        }
                                                                                                                    }
                                                                                                                    cxpHelper.updateDLData(null,
                                                                                                                            null,
                                                                                                                            "promosApplied",
                                                                                                                            promosAppliedVal, null, null);
                                                                                                                }
                                                                                                                String processStep = "";
                                                                                                                String cartOrderFlowType = "";
                                                                                                                String reqIntendType = "";
                                                                                                                Boolean editDevice = false;

                                                                                                                if (null != response
                                                                                                                        .getServiceBody()
                                                                                                                        && null != response
                                                                                                                        .getServiceBody()
                                                                                                                        .getServiceResponse()
                                                                                                                        && null != response
                                                                                                                        .getServiceBody()
                                                                                                                        .getServiceResponse()
                                                                                                                        .getContext()
                                                                                                                        && null != response
                                                                                                                        .getServiceBody()
                                                                                                                        .getServiceResponse()
                                                                                                                        .getContext()
                                                                                                                        .getContextInfo())
                                                                                                                    processStep = response
                                                                                                                            .getServiceBody()
                                                                                                                            .getServiceResponse()
                                                                                                                            .getContext()
                                                                                                                            .getContextInfo()
                                                                                                                            .getProcessStep();
                                                                                                                String processStepForCheckout = processStep;
                                                                                                                if (StringUtilities
                                                                                                                        .isEmptyOrNull(request
                                                                                                                                .getCartInfo()
                                                                                                                                .getIntendType()))
                                                                                                                    reqIntendType = CartConstants.EUP;
                                                                                                                else
                                                                                                                    reqIntendType = request
                                                                                                                            .getCartInfo()
                                                                                                                            .getIntendType();

                                                                                                                if (null != request
                                                                                                                        .getCartInfo()
                                                                                                                        .getEditDevice())
                                                                                                                    editDevice = request
                                                                                                                            .getCartInfo()
                                                                                                                            .getEditDevice();

                                                                                                                if (StringUtilities
                                                                                                                        .isEmptyOrNull(request
                                                                                                                                .getCartInfo()
                                                                                                                                .getProcessingMTN())
                                                                                                                        && reqIntendType
                                                                                                                        .equalsIgnoreCase(
                                                                                                                                CartConstants.EUP))
                                                                                                                    editDevice = true;
                                                                                                                if (!reqIntendType.equalsIgnoreCase(CartConstants.ACCOUNT_GROWTH)) {
                                                                                                                    String redisCartOrderFlowType = data.getCartOrderFlowType() != null && CartConstants.NONE.equalsIgnoreCase(data.getCartOrderFlowType()) ? StringUtils.EMPTY : data.getCartOrderFlowType();
                                                                                                                    cartOrderFlowType = OrderFlowTypeUtil.calculateCartOrderFlowType(
                                                                                                                            redisCartOrderFlowType,
                                                                                                                            processStep,
                                                                                                                            reqIntendType);
                                                                                                                }
                                                                                                                logger.info(String.format("cartOrderFlowType type: %s", cartOrderFlowType));

                                                                                                                if (!editDevice) {
                                                                                                                    Mono<Boolean> orderTypeRedisData = redisHelper2
                                                                                                                            .updateCartOrderFlowType(
                                                                                                                                    cartOrderFlowType);
                                                                                                                    return orderTypeRedisData
                                                                                                                            .flatMap(
                                                                                                                                    orderTypeData -> {

                                                                                                                                        if (request
                                                                                                                                                .getData()
                                                                                                                                                .getLines()
                                                                                                                                                .size() > 0) {

                                                                                                                                            String cartCount = "";
                                                                                                                                            if (StringUtilities
                                                                                                                                                    .isNotEmptyOrNull(
                                                                                                                                                            data.getCartCount()))
                                                                                                                                                cartCount = String
                                                                                                                                                        .valueOf(
                                                                                                                                                                Integer.parseInt(
                                                                                                                                                                        data.getCartCount())
                                                                                                                                                                        + request
                                                                                                                                                                        .getData()
                                                                                                                                                                        .getLines()
                                                                                                                                                                        .size());
                                                                                                                                            else
                                                                                                                                                cartCount = "1";
                                                                                                                                            Mono<Boolean> redisDeviceCount = redisHelper2
                                                                                                                                                    .updateDeviceCartCount(
                                                                                                                                                            cartCount, Boolean.FALSE);
                                                                                                                                            Mono<Boolean> localBby = redisHelper2.updateBByOrderDetails(request,data);
//																																as per PRODDEF-23628, user.numberOfLines is mtn count of user, not cart item
//																																cxpHelper.updateDLData(null,
//																																		null,
//																																		CartConstants.NUMBER_OF_LINES,
//																																		cartCount, null, null);
                                                                                                                                            return Mono.zip(redisDeviceCount,localBby)
                                                                                                                                                    .flatMap(
                                                                                                                                                            redisCount -> {
                                                                                                                                                                if (CartConstants.PROMO_HUB.equalsIgnoreCase(processStepForCheckout) ||
                                                                                                                                                                        CartConstants.ACCESSORIES_INTERSTIAL.equalsIgnoreCase(processStepForCheckout)) {
                                                                                                                                                                    return redisHelper
                                                                                                                                                                            .upsertOneClickCheckoutFlag(
                                                                                                                                                                                    "true")
                                                                                                                                                                            .flatMap(
                                                                                                                                                                                    flag -> {
                                                                                                                                                                                        logger.info(
                                                                                                                                                                                                "Updating OneClickCheckoutFlag to true as part of addDevice ");
                                                                                                                                                                                        return Mono
                                                                                                                                                                                                .just(response);
                                                                                                                                                                                    });
                                                                                                                                                                }
                                                                                                                                                                return Mono
                                                                                                                                                                        .just(response);
                                                                                                                                                            });

                                                                                                                                        }

                                                                                                                                        return Mono
                                                                                                                                                .just(response);
                                                                                                                                    });
                                                                                                                }
                                                                                                                if (CartConstants.PROMO_HUB.equalsIgnoreCase(processStep)
                                                                                                                        || CartConstants.ACCESSORIES_INTERSTIAL.equalsIgnoreCase(processStep)) {
                                                                                                                    return redisHelper
                                                                                                                            .upsertOneClickCheckoutFlag(
                                                                                                                                    "true")
                                                                                                                            .flatMap(flag -> {
                                                                                                                                logger.info(
                                                                                                                                        "Updating OneClickCheckoutFlag to true as part of edit addDevice ");
                                                                                                                                return Mono
                                                                                                                                        .just(response);
                                                                                                                            });
                                                                                                                }
																								} catch (Exception e) {
                                                                                                                logger.error(
                                                                                                                        "exception while setting cartCount and cartOrderFlowType", e);
                                                                                                            }
                                                                                                        }
                                                                                                        return Mono.just(response);
                                                                                                    });
                                                                                                });
                                                                                            });
                                                                                        });
                                                                                    });
                                                                                });
																}); });
                                                                    });
                                                                })));
                                    }));

                        }));
                    });
                });
            });
        });
    }

    private boolean portInCheck(CartRedisData data, String requestMtn) {
        if (data != null && data.getRetrieveCart() != null && data.getRetrieveCart().getCart() != null &&
                data.getRetrieveCart().getCart().getLineDetails() != null &&
                data.getRetrieveCart().getCart().getLineDetails().getLineInfo() != null
                && ArrayUtils.isNotEmpty(data.getRetrieveCart().getCart().getLineDetails().getLineInfo())) {

            return Arrays.stream(data.getRetrieveCart().getCart().getLineDetails().getLineInfo()).anyMatch(line ->
                    line != null && StringUtilities.isNotEmptyOrNull(line.getMobileNumber()) && line.getMobileNumber().equalsIgnoreCase(requestMtn)
                            && line.getPortinMtnAssignment() != null && line.getPortinMtnAssignment());

        }
        return false;
    }

    public boolean getzipCode(AddDeviceUIRequest request) {
        return request != null && request.getCartInfo() != null && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getZipCode()) && request.getCartInfo().getZipCode().length() > 5;
    }

    public boolean isDigital(String channelType) {
        return StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.CHANNEL_DIGITAL);
    }

    public String evaluteFlowType(String lineInfoFlowType) {
        if (StringUtilities.isNotEmptyOrNull(lineInfoFlowType)) {
            switch (lineInfoFlowType) {
                case CartConstants.BYOD_LINE_ACTIVITY:
                    return "ESO";
                case CartConstants.EUP_BYOD_LINE_ACTIVITY:
                    return "ESO";
                case CartConstants.NSE_BYOD_LINE_ACTIVITY:
                    return "NSO";
                default:
                    return lineInfoFlowType;
            }
        }
        return "";
    }

    public Vzdl getVzdlData(AddDeviceUIRequest request, AddDeviceUIResponse response, CartRedisData rr, FeatureCatalogItem featureCatalogItem) {
        boolean reqDataNullCheck = request != null && request.getData() != null;
        boolean resDataNullCheck = response != null && response.getServiceBody() != null;
        Vzdl vzdl = null;
        if (resDataNullCheck && reqDataNullCheck) {
            vzdl = getVzdlTxnData(request, response, rr, featureCatalogItem);
            if (flexV2(request)) {
                if (vzdl == null) {
                    vzdl = new Vzdl();
                }
                Event event = new Event();
                event.setValue("event278");
                Engagement engagement = new Engagement();
                engagement.setIntent("Order");
                vzdl.setEvent(event);
                vzdl.setEngagement(engagement);
                setPageData(request, vzdl);
            }
        }
        return vzdl;
    }

    public Vzdl getVzdlTxnData(AddDeviceUIRequest request, AddDeviceUIResponse response, CartRedisData rr, FeatureCatalogItem featureCatalogItem) {
        Optional<CartServiceCartInfo> cartInfo = Optional.ofNullable(response.getServiceBody()).map(AddDeviceServiceBody::getServiceResponse).map(AddDeviceServiceResponse::getContext).map(AddDeviceContext::getCartInfo);
        Optional<Line> responseLine = cartInfo.map(CartServiceCartInfo::getLines).map(lines -> lines.length > 0 ? lines[0] : null);
        Optional<Lines> requestLine = Optional.ofNullable(request).map(AddDeviceUIRequest::getData).map(AddDeviceData::getLines).map(lines -> !lines.isEmpty() ? lines.get(0) : null);
        Map<String, String> txn;
        Product product;
        Vzdl vzdl = null;
        if (cartInfo.isPresent() && responseLine.isPresent() && responseLine.get().getDevice() != null && requestLine.isPresent() && requestLine.get().getDevice() != null) {
            vzdl = new Vzdl();
            txn = new HashMap<>();
            txn.put("recurringPrice", String.valueOf(cartInfo.get().getTotalDueMonthly()));
            txn.put("cartId", cartInfo.get().getCartId());
            if (rr != null && rr.getDeviceCartInfo() != null) {
                txn.put("agent", rr.getDeviceCartInfo().getSalesRepId());
                txn.put("outletId", rr.getDeviceCartInfo().getLocationCode());
                txn.put("orderType", rr.getDeviceCartInfo().getIntendType());
            }
            product = new Product();
            Owns owns = new Owns();
            List<Current> currentList = new ArrayList<>();
            if (flexV2(request)) {
                Current current = new Current();
                current.setCategory("Device");
                current.setName(responseLine.get().getDevice().getSkuDisplayName());
                current.setId(responseLine.get().getDevice().getId());
                current.setSku(responseLine.get().getDevice().getSkuId());
                current.setQty("1");
                String mtnHash = null;
                mapMtnHash(rr, requestLine, current, request);
                txn.put("orderType", "");
                if (current.getLineHash() != null) {
                    mtnHash = current.getLineHash();
                }
                if (StringUtilities.isNotEmptyOrNull(requestLine.get().getDevice().getContractTerm())) {
                    if ("VERIZON_EDGE".equalsIgnoreCase(requestLine.get().getDevice().getContractTerm())) {
                        txn.put("recurringCharges", String.valueOf(responseLine.get().getMonthlyInstallment()));
                        current.setRecurringPrice(String.valueOf(responseLine.get().getMonthlyInstallment()));
                        current.setNonRecurringPrice("0.0");
					}
					else {
                        txn.put("nonRecurringCharges", String.valueOf(responseLine.get().getDevice().getItemPrice()));
                        current.setNonRecurringPrice(String.valueOf(responseLine.get().getDevice().getItemPrice()));
                        current.setRecurringPrice("0.0");
                    }
                }
                currentList.add(current);
                Current currentFeature = mapCurrentDetails(responseLine, featureCatalogItem);
                if (currentFeature != null) {
                    currentFeature.setLineHash(mtnHash);
                    currentList.add(currentFeature);
                }
                Current[] currentsArray = new Current[currentList.size()];
                product.setCurrent(currentList.toArray(currentsArray));
			}
			else{
                owns.setCategory(requestLine.get().getDevice().getCategory());
                owns.setLine(responseLine.get().getMtn());
                owns.setName(responseLine.get().getDevice().getExistingDeviceName());
                owns.setId(responseLine.get().getDevice().getId());
                owns.setRecurringPrice(String.valueOf(responseLine.get().getMonthlyInstallment()));
                List<Owns> ownsList = new ArrayList<>();
                ownsList.add(owns);
                Owns[] ownsArray = new Owns[ownsList.size()];
                product.setOwns(ownsList.toArray(ownsArray));
            }
            vzdl.setTxn(txn);
            vzdl.setProduct(product);
        }
        return vzdl;
    }

    public void updateDLDataForAssisted(Vzdl vzdl) {
        var dlData = AssistedOmniDLBuilder.AssistedOmniBuilderService.fromCartService(vzdl);
        dlService.buildDLData(dlData);
    }

    public void updateReadAssistedDLData(Vzdl vzdl) {
        var dlData = AssistedOmniDLBuilder.AssistedOmniBuilderService.fromOrderConfirmationPage(vzdl);
        dlService.buildDLData(dlData);
    }

    private void checkCartExistsOverride(AddDeviceUIRequest request) {
        var cartInfoOptional = Optional.of(request).map(AddDeviceUIRequest::getCartInfo);
        cartInfoOptional.ifPresent(cartInfo -> {
            if (StringUtilities.isEmptyOrNull(cartInfo.getCartId()) && StringUtilities.isEmptyOrNull(cartInfo.getCaseId())) {
                cartInfo.setMtnFlow(CartConstants.MTN_FLOW_D);
                cartInfo.setProcessingMTN("");
                var linesOptional = Optional.of(request).map(AddDeviceUIRequest::getData).map(AddDeviceData::getLines)
                        .filter(CollectionUtilities::isNotEmptyOrNull);
                linesOptional.ifPresent(lines -> lines.stream().findFirst().ifPresent(lines1 -> lines1.setMtn("")));
            }
        });
    }

    public boolean checkForAccountMemberRestriction(AddDeviceUIRequest request, String vzwRole) {
        Optional<Lines> reqLine = Optional.ofNullable(request).map(AddDeviceUIRequest::getData).map(AddDeviceData::getLines).map(lines -> !lines.isEmpty() ? lines.get(0) : null);
        return StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()) && existingCustomerFlows.contains(request.getCartInfo().getIntendType()) &&
                StringUtilities.isNotEmptyOrNull(vzwRole) && CartConstants.ACCOUNT_MEMBER_ROLES.contains(vzwRole) && reqLine.isPresent() && CartConstants.SMARTWATCH.equalsIgnoreCase(reqLine.get().getDevice().getCategory());
    }

    public void removeCaseAndCartIdResponse(ServiceBody serviceBody, String channel) {
        if (channelsToRemoveCaseAndCartIds.contains(channel) && serviceBody != null
                && serviceBody.getServiceResponse() != null && serviceBody.getServiceResponse().getContext() != null) {
            logger.info("Removing case & cartId from response");
            Context context = serviceBody.getServiceResponse().getContext();
            context.setCaseId(null);
            if (context.getCartInfo() != null) {
                context.getCartInfo().setCartId(null);
            }
        }
    }


    public void setByodDataFromRedis(DeviceImeiSimDetails deviceImeiSimDetails, Device device, SoftSKUItem sim) {
        device.setDeviceId(deviceImeiSimDetails.getDeviceId());
        if(null!=device.getByodESimPhone() && device.getByodESimPhone()) {
            sim.setESIM(deviceImeiSimDetails.getEID());
            if(!deviceImeiSimDetails.isEsimOnly() && null!=device.getImei2()){
                device.setDeviceId(deviceImeiSimDetails.getImei2());
            }
        }
        sim.setIccid(deviceImeiSimDetails.getIccid());
        if (sim.getIsCustomerProvidedSIM() != null && sim.getIsCustomerProvidedSIM())
            sim.setIccid(deviceImeiSimDetails.getIccid());
    }

    public String fetchFeatureId(Optional<Lines> requestLine) {
        if (requestLine != null && requestLine.isPresent() && CollectionUtilities.isNotEmptyOrNull(requestLine.get().getAddFeatures())) {
            String featureId = requestLine.get().getAddFeatures().stream()
                    .filter(Objects::nonNull)
                    .filter(obj -> obj != null && StringUtilities.isNotEmptyOrNull(obj.getId()) && "A".equalsIgnoreCase(obj.getActionIndicator()))
                    .map(Feature::getId)
                    .findFirst().orElse(null);
            return featureId;
        }
        return null;
    }



    public String mapMtnHash(CartRedisData redisData, Optional<Lines> requestLine, Current current, AddDeviceUIRequest request) {

        if (request != null && request.getCustomerProfileResponse() != null && FlexV2Util.isAccountHasBillAcc(request.getCustomerProfileResponse())) {
            request.getCustomerProfileResponse().getData().getCustomer().getBillAccounts().stream()
                    .filter(objs -> objs != null && CollectionUtilities.isNotEmptyOrNull(objs.getMtns()))
                    .forEach(accData -> accData.getMtns().stream().filter(cusData -> requestLine.isPresent() && requestLine.get().getMtn() != null && requestLine.get().getMtn().contains(cusData.getMtn()))
                            .forEach(matchedLine -> {
                                if (null != matchedLine.getMtnHashCode()) {
                                    current.setLineHash(matchedLine.getMtnHashCode());
								}}));
        }

        return null;
    }

    public Current mapCurrentDetails(Optional<Line> responseLine, FeatureCatalogItem catalogItem) {
        if (catalogItem != null) {
            Current current = new Current();
            if (catalogItem.getPrice() != null) {
                current.setRecurringPrice(String.valueOf(catalogItem.getPrice()));
            }
            current.setCategory("Features");
            current.setQty("1");
            current.setName(catalogItem.getSkuDisplayName());
            current.setId(catalogItem.getFeatureId());
            current.setSku(catalogItem.getSkuId());
            current.setQty("1");
            return current;
        }

        return null;
    }

    public boolean flexV2(AddDeviceUIRequest request) {
        return request.getCartInfo() != null && request.getCartInfo().isFlexV2();
    }

    public Vzdl setPageData(AddDeviceUIRequest request, Vzdl vzdl) {
        Page page = new Page();
        page.setName("product-detail");
        page.setThrottle("MFE");
        page.setContentFragments("");
        vzdl.setPage(page);
        return vzdl;
    }

    public void UpdateRedisDataToRequest(CartRedisData data, AddDeviceUIRequest request) {
        if (request != null && flexV2(request)) {
            if (data != null) {
                if (data.getCustomerProfile() != null) {
                    request.setCustomerProfileResponse(data.getCustomerProfile());
                }
                if (StringUtilities.isNotEmptyOrNull(data.getFlowName())) {
                    request.setFlowName(data.getFlowName());
                }
            }
        }
    }

    public String getCustomerType(CustomerProfileGraphQLResponse response) {
        String customerType = null;
        if (response != null && response.getData() != null && response.getData().getCustomer() != null
                && response.getData().getCustomer().getCustomerAttributes() != null
                && StringUtilities.isNotEmptyOrNull(response.getData().getCustomer().getCustomerAttributes().getCustomerType())) {
            return response.getData().getCustomer().getCustomerAttributes().getCustomerType();
        }
        logger.info("CustomerType:: {}", customerType);
        return customerType;
    }

    private CustomerProfileData setCustomerProfileData(Mtn mtn, BillAccounts billAccount, String customerType) {
        CustomerProfileData custProfileData = new CustomerProfileData();
        if (mtn.getPricePlanInfo() != null)
            custProfileData.setPlanId(mtn.getPricePlanInfo().getPlanId());
        if (mtn.getEquipmentUpgradeEligibility() != null)
            custProfileData.setUpgradeEligible(mtn.getEquipmentUpgradeEligibility().getUpgradeEligible());
        if (mtn.getMtnStatus() != null)
            custProfileData.setIsActive(mtn.getMtnStatus().isActive());
        if (CollectionUtilities.isNotEmptyOrNull(mtn.getInstallmentLoanSummary())) {
            mtn.getInstallmentLoanSummary().forEach(loanSummary -> {
                custProfileData.setHasActiveLoan(loanSummary.getHasActiveLoan());
            });
        }
        if (mtn.getLineLevelChangeEligibility() != null) {
            custProfileData.setPendingOrderDetailDigital(mtn.getLineLevelChangeEligibility().getPendingOrderDetail());
        }
        if (billAccount.getPaymentInfo() != null) {
            custProfileData.setIsBalancePastDue(billAccount.getPaymentInfo().getIsBalancePastDue());
        }
        if (StringUtilities.isNotEmptyOrNull(customerType)) {
            custProfileData.setCustomerType(customerType);
        }
        if (CollectionUtilities.isNotEmptyOrNull(mtn.getEquipmentInfos())) {
            mtn.getEquipmentInfos().forEach(equipmentInfo -> {
                if (equipmentInfo != null && equipmentInfo.getDeviceInfo() != null) {
                    custProfileData.setDisplayName(equipmentInfo.getDeviceInfo().getDisplayName());
                    custProfileData.setDeviceSku(equipmentInfo.getDeviceInfo().getDeviceSku());
                }
            });
        }
        logger.info("custProfileData:: {}", custProfileData);
        return custProfileData;
    }

    public boolean checkUpgradeEligibility(CustomerProfileData profileData, String customerType) {
        if ((profileData.getCustomerType().equalsIgnoreCase("ME")
                || profileData.getCustomerType().equalsIgnoreCase("PE"))
                && profileData.getUpgradeEligible()
                && profileData.getIsActive()
                && !profileData.getHasActiveLoan()
                && profileData.getPendingOrderDetailDigital() == null
                && !profileData.getIsBalancePastDue()) {
            logger.info("addStep UpgradeEligibility: true");
            return true;
        } else {
            logger.info("addStep UpgradeEligibility: false");
            return false;
        }
    }

    public boolean containsValue(String input, String compareValue) {
        return StringUtilities.isNotEmptyOrNull(input) ? Arrays.asList(input.split(CartConstants.COMMA)).contains(compareValue) : false;
    }

    private boolean isEligibleCustomer(Mtn mtn, BillAccounts billAccount, String customerType) {
        if (mtn != null) {
            CustomerProfileData customerProfileData = setCustomerProfileData(mtn, billAccount, customerType);
            return checkUpgradeEligibility(customerProfileData, customerType);
        }
        return false;
    }

    public static String getCurrentDateAndTimeWithZone(final String datePattern, final String timeZoneId) {
        final DateFormat dateFormat = new SimpleDateFormat(datePattern);
        dateFormat.setTimeZone(TimeZone.getTimeZone(timeZoneId));
        return dateFormat.format(Date.from(ZonedDateTime.now().toInstant()));
    }

    public void prepareAddStepOneClickResponse(AddDeviceUIResponse response, Mtn mtn, AddDeviceUIRequest request,
                                               ValidateOffersResponse validateOffersResponse) {
        AddDeviceServiceBody addDeviceServiceBody = new AddDeviceServiceBody();
        AddDeviceServiceResponse addDeviceServiceResponse = new AddDeviceServiceResponse();
        AddDeviceContext addDeviceContext = new AddDeviceContext();
        CartServiceCustomerInfo cartServiceCustomerInfo = new CartServiceCustomerInfo();
        cartServiceCustomerInfo.setIsOneClickEligible(Boolean.TRUE);
        cartServiceCustomerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        cartServiceCustomerInfo.setMtn(mtn.getMtn());
        cartServiceCustomerInfo.setProcessingMTN(mtn.getMtn());
        cartServiceCustomerInfo.setCartCreator(mtn.getMtn());
        cartServiceCustomerInfo.setLastActiveChannelID(request.getChannelId());
        cartServiceCustomerInfo.setLastUpdateDateTime(getCurrentDateAndTimeWithZone("yyyy-MM-dd HH:mm:ss z", "UTC"));
        addDeviceContext.setCustomerInfo(cartServiceCustomerInfo);

        CartServiceCartInfo cartServiceCartInfo = new CartServiceCartInfo();
        if (!ObjectUtils.isEmpty(request.getData().getLines())) {
            Line[] lineArray = new Line[request.getData().getLines().size()];
            int i = 0;
            for (Lines lines : request.getData().getLines()) {
                Line line = new Line();
                line.setCustomerProvidedMtn(lines.getCustomerProvidedMtn());
                line.setAccountOwner(lines.getAccountOwner());
                line.setStandAlone(lines.getStandAlone());
                line.setLineWithSkipMDN(true);
                line.setInWithVerizonOpted(lines.isInWithVerizonOpted());
                line.setNewLineOrAAL(lines.getNewLineOrAAL());
                line.setAddAccessories(lines.getAddAccessories());
                line.setRemoveAccessories(lines.getRemoveAccessories());
                line.setAddFeatures(lines.getAddFeatures());
                line.setRemoveFeatures(lines.getRemoveFeatures());
                line.setDeviceTypeSelected(lines.getDeviceTypeSelected());
                line.setIspuFlow(lines.getIspuFlow());
                line.setPlan(lines.getPlan());
                line.setAmount(lines.getAmount());
                line.setDevice(lines.getDevice());
                line.setCurrentPlanType(lines.getCurrentPlanType());
                line.setLineActivityType(lines.getLineActivityType());

                line.setSelectedPromoId(lines.getSelectedPromoId());
                line.setSelectedSedOfferId(lines.getSelectedSedOfferId());
                line.setSelectedPromoType(lines.getSelectedPromoType());
                line.setIsTradeInIntentSelected(lines.getIsTradeInIntentSelected());
                line.setIsCommonPDP(lines.getIsCommonPDP());
                if (validateOffersResponse.getData().getStrategicOfferDetails() != null) {
                    if (StringUtilities.isNotEmptyOrNull(validateOffersResponse.getData().getStrategicOfferDetails().getRestricted())) {
                        line.setRestricted(validateOffersResponse.getData().getStrategicOfferDetails().getRestricted());
                    }
                    if (StringUtilities.isNotEmptyOrNull(validateOffersResponse.getData().getStrategicOfferDetails().getReqCompliance())) {
                        line.setRestrictedProductType(validateOffersResponse.getData().getStrategicOfferDetails().getReqCompliance());
                    }
                }
                line.setIsStrategicOffer(lines.getIsStrategicOffer());
                line.setPurchasePath(lines.getPurchasePath());
                line.setDepletionType(lines.getDepletionType());
                line.setSim(lines.getSim());
                line.setIsKeepingExistingEqProtection(lines.getIsKeepingExistingEqProtection());
                line.setNewLineOrAAL(lines.getNewLineOrAAL());
                line.setDevice(lines.getDevice());
                line.getDevice().setQty(1);
                line.setSkipPromoChoiceOffer(lines.isSkipPromoChoiceOffer());
                lineArray[i] = line;
                i++;
            }
            cartServiceCartInfo.setLines(lineArray);
        }


        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        contextInfo.setProcessStep(CartConstants.ONE_CLICK_UPGRADE);
        contextInfo.setCradleFlowJourney(CartConstants.ONE_CLICK_UPGRADE);
        contextInfo.setCradleFlowJourney(CartConstants.NEXTGEN_EC);
        List<AvailablePaths> availablePaths = new ArrayList<>();
        AvailablePaths availablePath = new AvailablePaths();
        availablePath.setPath(CartConstants.ONE_CLICK_UPGRADE);
        availablePaths.add(availablePath);
        contextInfo.setAvailablePaths(availablePaths);
        addDeviceContext.setContextInfo(contextInfo);

        addDeviceContext.setCartInfo(cartServiceCartInfo);
        addDeviceServiceResponse.setContext(addDeviceContext);
        addDeviceServiceBody.setServiceResponse(addDeviceServiceResponse);
        response.setServiceBody(addDeviceServiceBody);
    }

    public ValidateOffersRequest prepareVORequest(Mtn mtn, AddDeviceUIRequest request) {
        ValidateOffersRequest voRequest = new ValidateOffersRequest();
        ValidateOffersData voReqData = new ValidateOffersData();
        voReqData.setPageId(CartConstants.PAGEID_LANDING);
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getAccountNumber())) {
            voReqData.setAccountNumber(request.getCartInfo().getAccountNumber());
        }
        if (StringUtilities.isNotEmptyOrNull(mtn.getMtn())) {
            voReqData.setMtn(mtn.getMtn());
        }
        if (request != null && request.getData() != null && CollectionUtilities.isNotEmptyOrNull(request.getData().getLines())
                && request.getData().getLines().get(0) != null) {
            if (StringUtilities.isNotEmptyOrNull(request.getData().getLines().get(0).getSelectedSedOfferId())) {
                voReqData.setSelectedOfferId(request.getData().getLines().get(0).getSelectedSedOfferId());

            }
            if (request.getData().getLines().get(0).getDevice() != null && StringUtilities.isNotEmptyOrNull(request.getData().getLines().get(0).getDevice().getId())) {
                voReqData.setBuyDeviceSorId(request.getData().getLines().get(0).getDevice().getId());
            }
        }
        voReqData.setStrategicOfferEnabled(Boolean.TRUE);
        voRequest.setData(voReqData);
        return voRequest;
    }

    public void setLGPORedisDataInRequest(CartRedisData data, AddDeviceUIRequest request) {
        if (request != null && request.getCartInfo() != null && data != null) {
            if (request.getCartInfo().getIntendType() != null) {
                if (CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())
                        || (CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType()))) {
                    if (data.getIsLgpoEligibleCustomer() != null && Boolean.TRUE.equals(data.getIsLgpoEligibleCustomer())
                            && data.getLgpoSpo() != null) {
                        request.getData().setIsLGPOEligible(Boolean.TRUE);
                    }
                }
            }
        }
    }

    public Mono<ResponseEntity<GenericResponse>> dfoToDppCart(ServerHttpRequest httpHeader,
                                                              ServerHttpResponse httpResponse,
                                                              @Valid AddDeviceUIRequest request) throws SOEHTTPException {

        return bpmHelper.callPegaDfoToDppCart(request).flatMap(pegaResponse ->
                Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(pegaResponse)));

    }
    private Mono<AddDeviceUIResponse> setPastDueInRequest(AddDeviceUIRequest request, CartRedisData data, String channelType) {
        if(isDigital(channelType) && featureFlagHelper.isPastDueBYODFFlag()
                && CartConstants.BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType()) && null!= data.getPastDueRedisData()){
            if(null!= data.getPastDueRedisData().getAmount()) {
                if ("Y".equalsIgnoreCase(data.getPastDueRedisData().getPastDueAccepted())) {
                    request.getCartInfo().setPastDueAccepted(data.getPastDueRedisData().getPastDueAccepted());
                } else {
                    return Mono.error(new SOEHTTPException(500, SOEErrorHolder.builder().errors(CartPegaRequestErrorsUtil.pastDueNotAccepted()).build()));
                }
                request.getCartInfo().setPastdue(new PastDue(data.getPastDueRedisData().getAmount()));
            }
        }
        return null;
    }
}



