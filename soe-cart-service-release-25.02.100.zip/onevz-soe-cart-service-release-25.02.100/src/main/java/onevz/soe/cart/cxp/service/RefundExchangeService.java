/*package onevz.soe.cart.cxp.service;

import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Service;

import onevz.soe.cart.model.refundExchange.CustomerInform;
import onevz.soe.cart.requests.UpdateUserSessionRequest;
import onevz.soe.cart.responses.UpdateUserSessionResponse;
import reactor.core.publisher.Mono;

@Service
public interface RefundExchangeService {

	
	public Mono<UpdateUserSessionResponse> updateUserSession(UpdateUserSessionRequest request, ServerHttpResponse httpResponse, Mono<CustomerInform> customerInform);
}
*/
