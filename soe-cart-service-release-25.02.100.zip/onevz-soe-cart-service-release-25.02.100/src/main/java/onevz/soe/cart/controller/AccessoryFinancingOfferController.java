/**
 * 
 */
package onevz.soe.cart.controller;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.exceptions.JsonValidator;
import onevz.soe.cart.helper.AccessoryFinancingOffersHelper;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.ui.requests.AccessoryFinancingOffersUIRequest;
import onevz.soe.cart.ui.requests.AffirmFinancingUIRequest;
import onevz.soe.cart.ui.responses.AffirmFinancingUIResponse;
import onevz.soe.cart.util.CartPegaRequestErrorsUtil;
import onevz.soe.cart.util.CartPegaResponseErrorsUtil2;
import onevz.soe.utilities.CollectionUtilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import jakarta.validation.Valid;
import java.util.ArrayList;
import java.util.List;

/**
 *
 */
@RestController
@RequestMapping(value = "cart")
public class AccessoryFinancingOfferController {

	private static final Logger logger = LoggerFactory.getLogger(AccessoryFinancingOfferController.class);

	@Autowired
	JsonValidator validator;

	@Autowired
	AccessoryFinancingOffersHelper accessoryFinancingOffersHelper;

	/**
	 *
	 * @param binder
	 */
	@InitBinder("*")
	public void initBinderByName(WebDataBinder binder) {
		binder.setDisallowedFields(new String[] { "genericHeader" });
	}

	@PostMapping({ "/updateAFOInfo", "/nse/updateAFOInfo" })
	public Mono<ResponseEntity<GenericResponse>> accessoryFinancingOffers(ServerHttpRequest httpHeader,
			ServerHttpResponse httpResponse, @Valid @RequestBody AccessoryFinancingOffersUIRequest request) {

		System.setProperty(CartConstants.ENDPOINT, "updateAFOInfo");
		logger.debug("updateAFOInfo: {}", request);
		String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
				? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
				: "";

		request.setChannelId(channelId);
		request.getCartInfo().setItemType("ACCESSORY-FINANCING-OFFER-INFO");
		request.getCartInfo().setProcessAction("updateAccessoryFinancingInfo");

		ErrorResponse errorResponse = CartPegaRequestErrorsUtil.handleCheckExistingCartRequestErrors(request);

		if (CollectionUtilities.isNotEmptyOrNull(errorResponse.getErrors())) {
			ErrorResponse errors = validator.convertObjectToString(errorResponse);
			if (null != errors) {
				return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
			}
		}

		return accessoryFinancingOffersHelper.updateAccessoryFinancingOffers(request).flatMap(pegaResponse -> {

			ErrorResponse errors2 = null;
			if (pegaResponse.getErrors() != null && !httpResponse.getStatusCode().is2xxSuccessful()) {
				errors2 = CartPegaResponseErrorsUtil2.handleAFOResponseErrors(pegaResponse);
				return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(errors2));
			} else {
				if (null != pegaResponse.getServiceBody()
						&& null != pegaResponse.getServiceBody().getServiceResponse()) {
					if (null != pegaResponse.getServiceBody().getServiceResponse().getContext()
							&& null != pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()) {
						return Mono.just(ResponseEntity.status(HttpStatus.OK).body(pegaResponse));
					}
				}

			}
			return Mono.just(ResponseEntity.status(HttpStatus.OK).body(pegaResponse));
		});
	}
	
	@PostMapping({ "/updateAffirmStatus", "/nse/updateAffirmStatus" })
	public Mono<ResponseEntity<GenericResponse>> updateAffirmStatus(ServerHttpRequest httpHeader,
			ServerHttpResponse httpResponse, @Valid @RequestBody AffirmFinancingUIRequest request) {

		System.setProperty(CartConstants.ENDPOINT, "updateAffirmStatus");
		logger.debug("updateAffirmStatus: {}", request);
		String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
				? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
				: "";

		request.setChannelId(channelId);

		ErrorResponse errorResponse = CartPegaRequestErrorsUtil.handleCheckExistingCartRequestErrors(request);

		if (CollectionUtilities.isNotEmptyOrNull(errorResponse.getErrors())) {
			ErrorResponse errors = validator.convertObjectToString(errorResponse);
			if (null != errors) {
				return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
			}
		}

		return accessoryFinancingOffersHelper.updateAffirmFinancingStatus(request).flatMap(response -> {

			ErrorResponse errors2 = null;
			if (response.getErrors() != null && !httpResponse.getStatusCode().is2xxSuccessful()) {
				errors2 = handleAffirmPegaResponseErrors(response);
				return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(errors2));
			} else {
				if (null != response.getServiceBody() && null != response.getServiceBody().getServiceResponse()
						&& null != response.getServiceBody().getServiceResponse().getContext()
						&& null != response.getServiceBody().getServiceResponse().getContext().getCartInfo()) {
					return Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));
				}

			}
			return Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));
		});
	}

	/**
	 * 
	 * @param response
	 * @return
	 */
	private ErrorResponse handleAffirmPegaResponseErrors(AffirmFinancingUIResponse response) {
		ErrorResponse errors = new ErrorResponse();
		List<CartError> errorList = new ArrayList<>();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			errorList = response.getErrors();
		}
		if (errorList != null)
			errors.setErrors(errorList);
		return errors;
	}

}
