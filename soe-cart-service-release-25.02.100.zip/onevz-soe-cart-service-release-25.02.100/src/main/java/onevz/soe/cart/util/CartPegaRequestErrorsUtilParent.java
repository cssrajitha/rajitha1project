package onevz.soe.cart.util;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.deviceIdValidation.DeviceIdValidationLine;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.ui.common.CartInfo;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import org.springframework.beans.factory.annotation.Value;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class CartPegaRequestErrorsUtilParent {

    
    protected static CartErrorDetail generateDeviceAmountError(String inputValue, String role, String minimumBillAmount) {
        CartErrorDetail detail = new CartErrorDetail();
        detail.setField(inputValue);
        detail.setIssue(inputValue + " doesn't allowed greater than $" + minimumBillAmount + " for role " + role);
        detail.setLocation(CartConstants.REQUEST);
        detail.setValue("incorrect");
        return detail;
    }


    protected static CartErrorDetail generateMtnFlowError() {
        CartErrorDetail detail = new CartErrorDetail();
        detail.setField("mtnFlow");
        detail.setIssue("mtnFlow is missing or incorrect.");
        detail.setLocation(CartConstants.REQUEST);
        detail.setValue("null/blank or incorrect");

        return detail;
    }

    protected static CartErrorDetail generateQuantityError() {
        CartErrorDetail detail = new CartErrorDetail();
        detail.setField("qty");
        detail.setIssue("qty (quantity) should be non null and greater than zero");
        detail.setLocation(CartConstants.REQUEST);
        detail.setValue("null/Zero/negative");

        return detail;
    }

    protected static CartErrorDetail generateTaxSkuQuantityError() {
        CartErrorDetail detail = new CartErrorDetail();
        detail.setField("qty");
        detail.setIssue("Quantity for "+ CartConstants.TAX_SOFT_SKU + " SKU can only be 1.");
        detail.setLocation(CartConstants.REQUEST);
        detail.setValue("non-unity");

        return detail;
    }

    protected static CartErrorDetail generateInvalidInputError(String inputValue, String value,String issue,String location) {
        CartErrorDetail detail = new CartErrorDetail();
        detail.setField(inputValue);
        detail.setIssue(issue);
        detail.setLocation(location);
        detail.setValue(value);

        return detail;
    }

    protected static Boolean onlyDigits(String str)
    {
        String regex = "[0-9]+";
        Pattern p = Pattern.compile(regex);
        if (str == null) {
            return false;
        }
        Matcher m = p.matcher(str);
        return m.matches();
    }

    protected static List<CartErrorDetail> validateIntendType(List<CartErrorDetail> errorList, String intendType,
                                                            String channelId) {

        if (CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(channelId))
                && StringUtilities.isEmptyOrNull(intendType)) {
            errorList.add(generateMissingError(CartConstants.INTEND_TYPE));
        }
        return errorList;
    }

    protected static CartErrorDetail generateMissingError(String inputValue) {
        CartErrorDetail detail = new CartErrorDetail();
        detail.setField(inputValue);
        if(StringUtilities.isNotEmptyOrNull(inputValue) && inputValue.equalsIgnoreCase(CartConstants.CART_ID) || inputValue.equalsIgnoreCase(CartConstants.CASE_ID))
        {
            detail.setIssue(CartConstants.CART_CASE_ID_MISSING_ERRORMSG);
        }
        else {
            detail.setIssue(inputValue + " is/are missing.");
        }
        detail.setLocation(CartConstants.REQUEST);
        detail.setValue("null/blank");

        return detail;
    }

    protected static List<CartErrorDetail> validateMtn(List<CartErrorDetail> errorList, int index, String mtn) {
        if (StringUtilities.isNotEmptyOrNull(mtn)) {
            Pattern pattern = Pattern.compile("[a-zA-Z0-9]*");
            Matcher matcher = pattern.matcher(mtn);
            if (!matcher.matches()) {
                CartErrorDetail detail = new CartErrorDetail();
                detail.setField("mtn");
                detail.setIssue("Invalid mtn");
                detail.setLocation(CartConstants.REQUEST_DATA_LINES + index + "]/mtn");
                detail.setValue(mtn);
                errorList.add(detail);
            }
        }
        return errorList;
    }

    public static List<CartErrorDetail> validateProcessingMtn(List<CartErrorDetail> errorList, String mtn) {
        if (StringUtilities.isNotEmptyOrNull(mtn)) {
            Pattern pattern = Pattern.compile("[a-zA-Z0-9]*");
            Matcher matcher = pattern.matcher(mtn);
            if (!matcher.matches()) {
                CartErrorDetail detail = new CartErrorDetail();
                detail.setField("mtn");
                detail.setIssue("Invalid mtn");
                detail.setLocation("request/cartInfo/ProcessingMTN");
                detail.setValue(mtn);
                errorList.add(detail);
            }
        }
        return errorList;
    }

    protected static List<CartErrorDetail> validateProductId(List<CartErrorDetail> errorList, int index, String productId) {
        if (StringUtilities.isNotEmptyOrNull(productId) && !productId.matches("^[a-zA-Z0-9\\s]+$")) {
            CartErrorDetail detail = new CartErrorDetail();
            detail.setField(CartConstants.PRODUCT_ID);
            detail.setIssue(CartConstants.INVALID_PRODUCT_ID);
            detail.setLocation(CartConstants.REQUEST_DATA_LINES + index + "]/device/productId");
            detail.setValue(productId);
            errorList.add(detail);
        }
        return errorList;
    }

    protected static List<CartErrorDetail> validateNpaNxx(List<CartErrorDetail> errorList, int index, String npaNxx) {
        if (!npaNxx.matches("\\d+")) {
            CartErrorDetail detail = new CartErrorDetail();
            detail.setField(CartConstants.NPANXX);
            detail.setIssue(CartConstants.INVALID_NPANXX);
            detail.setLocation(CartConstants.REQUEST_DATA_LINES + index + "]/npaNxx");
            detail.setValue(npaNxx);
            errorList.add(detail);
        }
        return errorList;
    }

    protected static List<CartErrorDetail> validateClearCartHeaders(List<CartErrorDetail> errorList, CartInfo cartInfo) {

        if (StringUtilities.isEmptyOrNull(cartInfo.getProcessStep())) {
            errorList.add(generateMissingError(CartConstants.PROCESS_STEP));
        }
        if (StringUtilities.isEmptyOrNull(cartInfo.getIntendType())) {
            errorList.add(generateMissingError(CartConstants.INTEND_TYPE));
        }
        return errorList;
    }

    protected static List<CartErrorDetail>  handleErrorDetails(List<CartErrorDetail> errorDetails, Lines[] lines) {

        if (lines == null) {
            errorDetails.add(generateMissingError(CartConstants.LINE_DETAILS));
        } else {
            int index = 0;
            for (Lines line : lines) {
                errorDetails = handleMtnErrorDetails(errorDetails,line,index);
                index++;
            }
        }
        return errorDetails;
    }

    protected static void handleOfferDataRequest(List<Lines> lines, List<CartErrorDetail> errorDetails) {
        int index = 0;
        for (Lines line : lines) {
            errorDetails = handleMtnErrorDetails(errorDetails,line,index);
            if (CollectionUtilities.isEmptyOrNull(line.getRemoveOffers()))  {
                errorDetails.add(generateMissingError(CartConstants.REMOVE_OFFERS_DETAILS));
            }else if( line.getRemoveOffers()!=null) {
                List<BvoOffers> removeOffers = line.getRemoveOffers();
                for (BvoOffers removeOffer : removeOffers) {
                    if (StringUtilities.isEmptyOrNull(removeOffer.getId())) {
                        errorDetails.add(generateMissingError(CartConstants.ID));
                    }
                }
            }
            index++;
        }
    }

    protected static ErrorResponse handleValidateMtnError(List<Lines> lines, List<CartErrorDetail> errorDetails) {

        if (lines == null) {
            errorDetails.add(generateMissingError(CartConstants.LINE_DETAILS));
        } else {
            int index = 0;
            for (Lines line : lines) {
                if (StringUtilities.isEmptyOrNull(line.getMtn())) {
                    errorDetails.add(generateMissingError(CartConstants.MTN));
                } else {
                    errorDetails = validateMtn(errorDetails, index, line.getMtn());
                }
                index++;
            }
        }

        ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
        return errors == null ? new ErrorResponse() : errors;
    }

    protected static  List<CartErrorDetail>  handleMtnErrorDetails(List<CartErrorDetail> errorDetails, Lines line, int index) {

        if (StringUtilities.isEmptyOrNull(line.getMtn())) {
            errorDetails.add(generateMissingError(CartConstants.MTN));
        } else {
            errorDetails = validateMtn(errorDetails, index, line.getMtn());
        }
        return errorDetails;
    }

    protected static List<CartError> settingCartError(List<CartErrorDetail> errorDetails, String errorMsg) {

        CartError error = new CartError();
        error.setNamespace(CartConstants.SOE_CART_SERVICE);
        error.setName(CartConstants.VALIDATION_ERROR);
        error.setId(CartConstants.MSNG_FLDS_ERR_CODE);
        error.setMessage(errorMsg);

        List<CartError> errorList = null;
        if (!errorDetails.isEmpty()) {
            errorList = new ArrayList<>();
            error.setDetailList(errorDetails);
            errorList.add(error);
        }

        return errorList == null ? new ArrayList<CartError>() : errorList;
    }

    protected static CartErrorDetail generateValidationError(String inputValue) {
        CartErrorDetail detail = new CartErrorDetail();
        detail.setField(inputValue);
        if("ispuFlow".equalsIgnoreCase(inputValue))
            detail.setIssue("Local orders cannot be processed in Telesales. depletionType L and ispuFlow false is not a valid combination.");
        else
            detail.setIssue(inputValue + " is/are invalid.");
        detail.setLocation(CartConstants.REQUEST);
        detail.setValue("invalid");

        return detail;
    }

    protected static List<CartErrorDetail> validateSubscriptions(List<CartErrorDetail> errorList,
                                                               List<McsSubscription> list) {

        for (McsSubscription subscription : list) {
            if (subscription == null) {
                errorList.add(generateMissingError(CartConstants.SUBSCRIPTION));
            } else {
                if (StringUtilities.isEmptyOrNull(subscription.getItemId())) {
                    if (StringUtilities.isEmptyOrNull(subscription.getCatId())) {
                        errorList.add(generateMissingError(CartConstants.SUBSCRIPTION_ITEMID_OR_CATID));
                    }
                }
                if (StringUtilities.isEmptyOrNull(subscription.getPricePlanId())) {
                    errorList.add(generateMissingError(CartConstants.SUBSCRIPTION_PRICEPLANID));
                }
                if (subscription.getPrice() == null) {
                    errorList.add(generateMissingError(CartConstants.SUBSCRIPTION_PRICE));
                }
                if (StringUtilities.isEmptyOrNull(subscription.getName())) {
                    errorList.add(generateMissingError(CartConstants.SUBSCRIPTION_NAME));
                }
                if (StringUtilities.isEmptyOrNull(subscription.getDescription())) {
                    errorList.add(generateMissingError(CartConstants.SUBSCRIPTION_DESCRIPTION));
                }
            }
        }
        return errorList;
    }

    protected static List<CartErrorDetail> validateAccessories(List<CartErrorDetail> errorList, Accessory[] accessories) {

        for (Accessory accessory : accessories) {
            if (accessory == null) {
                errorList.add(generateMissingError(CartConstants.ACCESSORIES));
            } else {
                if (StringUtilities.isEmptyOrNull(accessory.getId())
                        && StringUtilities.isEmptyOrNull(accessory.getCustomBundleId())) {
                    errorList.add(generateMissingError(CartConstants.ACCESSORY_ID));
                }
                if (StringUtilities.isEmptyOrNull(accessory.getQty()) || ("0").equals(accessory.getQty())
                        || Integer.valueOf(accessory.getQty()) < 0) {
                    errorList.add(generateQuantityError());
                } else if (StringUtilities.isNotEmptyOrNull(accessory.getId()) && CartConstants.TAX_SOFT_SKU.equalsIgnoreCase(accessory.getId())
                        && Integer.valueOf(accessory.getQty()) != 1) {
                    errorList.add(generateTaxSkuQuantityError());
                }
            }
        }
        return errorList;
    }

    protected static List<CartErrorDetail> validateDownPayment(List<CartErrorDetail> errorList, Lines line, String channelType) {

        if (!CartConstants.DIGITAL.equalsIgnoreCase(channelType) && StringUtilities.isEmptyOrNull(line.getMtn()))
                errorList.add(generateMissingError(CartConstants.MTN));
        if (line.getDownPayment() == null) {
            errorList.add(generateMissingError("downpayment"));
        } else {
            if (!CartConstants.DIGITAL.equalsIgnoreCase(channelType) && line.getDownPayment().getUserSelectedAmount() == null && line.getDownPayment().getAmount() == null) {
                errorList.add(generateMissingError(CartConstants.AMOUNT));
            }
            if (!CartConstants.DIGITAL.equalsIgnoreCase(channelType) && line.getDownPayment().getPercentage() == null) {
                errorList.add(generateMissingError("percentage"));
            }
        }
        return errorList;
    }

    protected static List<CartErrorDetail> validateCartId(List<CartErrorDetail> errorList, String cartId) {

        if (StringUtilities.isEmptyOrNull(cartId)) {
            errorList.add(generateMissingError(CartConstants.CART_ID));
        }

        return errorList;
    }


    protected static List<CartErrorDetail> validateDeviceId(List<CartErrorDetail> errorDetails,
                                                          List<DeviceIdValidationLine> lines, String intent, String processStep) {
        for (DeviceIdValidationLine line : lines) {
            if (line.getDevice() == null) {
                errorDetails.add(generateMissingError(CartConstants.DEVICE));
            } else {
                Device device = line.getDevice();
                validateDevice(errorDetails, intent, processStep, line, device);
            }
        }
        return errorDetails;

    }

    private static void validateDevice(List<CartErrorDetail> errorDetails, String intent, String processStep, DeviceIdValidationLine line, Device device) {
        if (CartConstants.BYOD.equalsIgnoreCase(intent) && device.getIsCustomerProvidedEquipment() == null) {
            errorDetails.add(generateMissingError("isCustomerProvidedEquipment"));
        }
        if (StringUtilities.isEmptyOrNull(device.getFlowtype())) {
            errorDetails.add(generateMissingError("Flowtype"));
        } else validateDeviceIdAndSimDetails(errorDetails, processStep, line, device);

        if (device.getSim() != null && device.getSim().getIsCustomerProvidedSIM() == null) {
            errorDetails.add(generateMissingError("isCustomerProvidedSIM"));
        }
    }

    private static void validateDeviceIdAndSimDetails(List<CartErrorDetail> errorDetails, String processStep, DeviceIdValidationLine line, Device device) {
        if (device.getSmartIMEI() == null || !device.getSmartIMEI()) {
            if (CartConstants.DEVICE.equalsIgnoreCase(device.getFlowtype())
                    && StringUtilities.isEmptyOrNull(device.getId())) {
                emptyDeviceId(errorDetails, processStep, line, device);
            } else if (CartConstants.SIM.equalsIgnoreCase(device.getFlowtype()) && device.getSim() != null
                    && StringUtilities.isEmptyOrNull(device.getSim().getId())) {
                errorDetails.add(generateMissingError(CartConstants.SIMID));
            }
        }
    }

    private static void emptyDeviceId(List<CartErrorDetail> errorDetails, String processStep, DeviceIdValidationLine line, Device device) {
        if (processStep.equalsIgnoreCase("NSEBYODLanding")) {
            if (StringUtilities.isEmptyOrNull(line.getDevice().getToken())) {
                errorDetails.add(generateMissingError(CartConstants.DEVICEID));
            }
        } else if(!Boolean.TRUE.equals(device.isPairedImeiDetailsEmpty())) {
            errorDetails.add(generateMissingError(CartConstants.DEVICEID));
        }
    }

    protected static List<CartErrorDetail> validateAddDevice(List<CartErrorDetail> errorList, Lines line,
                                                           String intendType, Boolean newLineOrByod, int index) {

        if (line.getIsEdgeBuyOut() == null && line.getEdgeup() == null) {
            if (StringUtilities.isEmptyOrNull(line.getDepletionType())) {
                errorList.add(generateMissingError("depletionType"));
            }
            if (line.getIspuFlow() != null && line.getIspuFlow()
                    && StringUtilities.isEmptyOrNull(line.getDepletionLocationCode())) {
                errorList.add(generateMissingError("depletionLocationCode"));
            }

            if (line.getDevice() == null && line.getSim() != null && CartConstants.EUPBYOD.equalsIgnoreCase(intendType)
                    && StringUtilities.isEmptyOrNull(line.getSim().getId())) {
                errorList.add(generateMissingError(CartConstants.SIMID));
            }
            if (line.getDevice() != null && StringUtilities.isEmptyOrNull(line.getDevice().getContractTerm())) {
                errorList.add(generateMissingError("contractTerm"));
            }
            if (line.getDevice() == null && line.getSim() == null && !isSecondNumberFlow(line)) {
                errorList.add(generateMissingError("Both device & sim"));
            }
          /*  if (line.getDevice() != null && StringUtilities.isEmptyOrNull(line.getDevice().getId())
                    && StringUtilities.isEmptyOrNull(line.getDevice().getDeviceId())) {
                errorList.add(generateMissingError(CartConstants.DEVICEID));
            }*/
            if (line.getSim() != null && !CartConstants.BYOD.equalsIgnoreCase(intendType)
                    && StringUtilities.isEmptyOrNull(line.getSim().getId())) {
                errorList.add(generateMissingError(CartConstants.SIMID));
            }
        } else if (line.getEdgeup() != null) {
            if (StringUtilities.isEmptyOrNull(line.getEdgeup().getDeviceId()))
                errorList.add(generateMissingError("edgeup.deviceId"));
        }

        return errorList;
    }

    protected static List<CartErrorDetail> validateLineFeatureAction(List<CartErrorDetail> errorList,
                                                                   FeatureAction reqFeatureAction) {
        if (reqFeatureAction.getAdd() == null && reqFeatureAction.getRemove() == null) {
            errorList.add(generateMissingError(CartConstants.FEATURES_AND_SUBSCRIPTIONS));
        } else {
            if (null != reqFeatureAction.getAdd())
                errorList = validateFeatures(errorList, reqFeatureAction.getAdd());
            if (null != reqFeatureAction.getRemove())
                errorList = validateFeatures(errorList, reqFeatureAction.getRemove());
        }
        return errorList;
    }

    protected static List<CartErrorDetail> validateFeatures(List<CartErrorDetail> errorList, List<Feature> list) {

        for (Feature feature : list) {
            if (feature == null) {
                errorList.add(generateMissingError(CartConstants.FEATURES));
            } else {
                if (StringUtilities.isEmptyOrNull(feature.getId())) {
                    errorList.add(generateMissingError(CartConstants.FEATURE_ID));
                }

            }
        }
        return errorList;
    }

    protected static List<CartErrorDetail> validateZipCode(String fieldName, String inputValue, List<CartErrorDetail> errorList) {
        if (!inputValue.matches("^[a-zA-Z0-9\\s]+$")) {
            CartErrorDetail detail = new CartErrorDetail();
            detail.setField(fieldName);
            detail.setIssue(fieldName + " is invalid");
            detail.setLocation(CartConstants.REQUEST+"/data");
            detail.setValue(inputValue);
            errorList.add(detail);
        }
        return errorList;
    }

    private static boolean isSecondNumberFlow(Lines line){
        return line.getSecondNumber()!=null && line.getSecondNumber().getIsSecondNumber()!=null && line.getSecondNumber().getIsSecondNumber();
    }
}
