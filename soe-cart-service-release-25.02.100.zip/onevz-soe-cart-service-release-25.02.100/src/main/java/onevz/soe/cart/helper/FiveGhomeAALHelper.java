package onevz.soe.cart.helper;


import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.constants.FeatureFlagConstants;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.gql.CurrentProfileSPO;
import onevz.soe.cart.gql.requests.ACPInfoGQL;
import onevz.soe.cart.gql.schema.LineLevelOffers;
import onevz.soe.cart.gql.schema.MobileInfoCustomerProfile;
import onevz.soe.cart.gql.schema.newCustomer.CustomerProfileForNSE;
import onevz.soe.cart.model.common.FiveG.FiveGLTEAddressRedis;
import onevz.soe.cart.model.retrieveCart.*;
import onevz.soe.cart.model.retrieveCart.fiveG.AMRegisterationDetails;
import onevz.soe.cart.model.retrieveCart.fiveG.CXPDueItemsList;
import onevz.soe.cart.model.retrieveCart.fiveG.CXPDueTaxesList;
import onevz.soe.cart.model.retrieveCart.fiveG.CXPOrderDetailsView;
import onevz.soe.cart.requests.GetCartDetailsRequest;
import onevz.soe.cart.requests.RetrieveCartCXPRequest;
import onevz.soe.cart.responses.ACPInfoDetails;
import onevz.soe.cart.responses.GetCartDetailsUIResponse;
import onevz.soe.cart.responses.ValidateCartCXPResponse;
import onevz.soe.cart.util.CommonUtil;
import onevz.soe.cart.util.CommonUtil2;
import onevz.soe.security.util.RPSAES128CBCUtil;
import onevz.soe.utilities.StringUtilities;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

import static onevz.soe.cart.util.CommonUtil.populateOrderDetailsView;

@Service
public class FiveGhomeAALHelper {
    @Autowired
    CartServiceCxpHelper cxpHelper;
    @Autowired
    CommonUtil commonUtil;
    @Autowired
    CommonUtil2 commonUtil2;

    @Autowired
    private EncryptDecryptHelper encryptDecryptHelper;
    @Autowired
    private RedisHelper3 redisHelper3;
    @Value("${soe.5g.promoKey.wireless:wireless-offer}")
    private String wirelessPromoKey;
    @Value("${soe.5g.promoKey.autoPay:auto-pay-and-paper-free-billing}")
    private String autoPayPromoKey;
    @Autowired
    private RPSAES128CBCUtil security5GUtil;
    @Autowired
    private FiveGhomeCommonHelper fiveGhomeCommonHelper;
    @Autowired
    private FiveGhomeNSEHelper fiveGhomeNSEHelper;
    @Autowired
    RedisHelper redisHelper;

    @Autowired
    FeatureFlagHelper featureFlagHelper;
    @Value("${soe.5g.switch.cartRedesignKillSwitch:false}")
    private boolean cartRedesignKillSwitch;

    private static final Logger logger = LoggerFactory.getLogger(FiveGhomeCommonHelper.class);

    public Mono<ResponseEntity<GetCartDetailsUIResponse>> get5GValidateCart(GetCartDetailsRequest request, ServerHttpResponse httpResponse) {
        return redisHelper3.getCartDataFromRedisForFiveGFlow().flatMap(data -> {
            String logginMtn=  commonUtil.getOpenIgTokens().get(CartConstants.LOOKUP_MTN);
            boolean sroFwafflag= featureFlagHelper.getFeatureFlagWithAccNumThrottle(FeatureFlagConstants.AWS_CONFIG_APP_NAME,FeatureFlagConstants.CONFIGURATOR_SRO_CFG, FeatureFlagConstants.SRO_FWA_RetrieveCart_FFlag,"",logginMtn);
            request.getFeatureFlags().put(FeatureFlagConstants.SRO_FWA_RetrieveCart_FFlag,sroFwafflag);
        	if(null != data.getIsSequentialComboOrder()){
				request.setIsSequentialComboOrder(data.getIsSequentialComboOrder());
			}
            RetrieveCartCXPRequest cxpRequest = new RetrieveCartCXPRequest();
            commonUtil.formatCxpRequest(request, cxpRequest, data);
            logger.debug("Calling cxp helper for vaidateCart with cartId {}", data.getCartId());
            boolean redesignFlow = request.getData().isRedesignFlow() || Boolean.parseBoolean(data.getRedesignFlow()) || StringUtilities.isNotEmptyOrNull(data.getNetworkBandwidthType());
            return cxpHelper.retrieve5GValidateCart(cxpRequest, data.getIntentType(), StringUtilities.isNotEmptyOrNull(data.getCompletedCartId())).flatMap(cxpResponse -> {
                if(null != cxpResponse.getErrors()) {
                    GetCartDetailsUIResponse errResp = new GetCartDetailsUIResponse();
                    errResp.setErrors(cxpResponse.getErrors());
                    return Mono.just(ResponseEntity.status(HttpStatus.OK).body(errResp));
                }
                else {
                    return redisHelper.getDataFromRedis().flatMap(cartRedisData -> {
                        Map<String, Boolean> featureFlags = new HashMap<>(2);
                        return featureFlagHelper.fetchUnifiedNBSFeatureFlag(cartRedisData).flatMap(unifiedNBSFFlag -> {
                            featureFlags.put("unifiedNbsFFlag", unifiedNBSFFlag);
                            return fiveGhomeCommonHelper.upsertFwaSafeTechSessionId(data.getSafeTechSessionId()).flatMap(value -> {
                                logger.info("FWA_SAFETECH_SESSIONID : " + value);
                                return Mono.just(ResponseEntity.status(HttpStatus.OK).body(transformCXPValidateCartResponseToSOE(request, cxpResponse, redesignFlow, data, featureFlags)));
                            });
                        });
                    });
                }
            });
        });

    }

    public void updateLqDataInCrmAALRedis(ValidateCartCXPResponse cxpResponse) {
        Map<String, String> requestMap = new HashMap<>();
        try {
            CXPLineDetailsVO lineDetails = cxpResponse.getData().getValidateCartAndUpdate().getLineDetails();
            CXPOrderDetails orderDetails = cxpResponse.getData().getValidateCartAndUpdate().getOrderDetails();
            commonUtil.formatRequestMap(lineDetails, orderDetails, requestMap);
        } catch (Exception e) {
            logger.info("Exception in lqInfo in CRM-ResumeCart/ intendType to redis : {}", e.getMessage());
        }
    }

    private GetCartDetailsUIResponse transformCXPValidateCartResponseToSOE(GetCartDetailsRequest request, ValidateCartCXPResponse cxpResponse, boolean redesignFlow, FiveGLTEAddressRedis redisVal, Map<String, Boolean> featureFlags) {
        // due monthly items order should be : device(5g/Lte router), 5g/lte plan, yttv, protection and discounts(loyalty,autopay/ecpd.. etc)
        Map<String, String> planDetails = new HashMap<>();
        GetCartDetailsUIResponse response=new GetCartDetailsUIResponse();
        response.setFeatureFlags(featureFlags);
        response.getFeatureFlags().putAll(request.getFeatureFlags());

        AtomicBoolean isEupFlow= new AtomicBoolean(false);
        if (null != cxpResponse && null != cxpResponse.getData() && null != cxpResponse.getData().getValidateCartAndUpdate()) {
            boolean isLoggedIn = false;
            isLoggedIn = setIsLoggedIn(cxpResponse, response, isLoggedIn);
            CXPCartVO cart = cxpResponse.getData().getValidateCartAndUpdate();
            CustomerProfileForNSE customerProfileForNSE = cart.getCustomerProfileForNSE();
            boolean isNSEFlow = !isLoggedIn;
            CXPOrderDetailsView orderDetailsView = new CXPOrderDetailsView();
            AMRegisterationDetails amRegisterationDetails = new AMRegisterationDetails();
            CXPOrderDetails cxpOrderDetails1 = cxpResponse.getData().getValidateCartAndUpdate().getOrderDetails();
            List<OrderList> list = cxpResponse.getData().getValidateCartAndUpdate().getOrderDetails().getOrderList();
            orderDetailsView.setEligible5GHomeBundle(cxpOrderDetails1.getEligible5GHomeBundle());
            populateBackOrderDetails(cxpResponse,orderDetailsView);
            CommonUtil.formatOrderDetailsView(orderDetailsView, cxpOrderDetails1);
            setDigitalTypeForLoggedIn(cxpResponse, isLoggedIn, response);
            List<CXPDueTaxesList> dueTodayTaxes = new ArrayList<>();
            List<CXPDueTaxesList> dueMonthlyTaxes = new ArrayList<>();
            CXPDueTaxesList todayTaxes = new CXPDueTaxesList();
            CXPDueTaxesList monthlyTaxes = new CXPDueTaxesList();
            List<CXPPaymentsVO> payments = new ArrayList<>();
            List<CXPShippingVO> shippingDetails = new ArrayList<>();
            todayTaxes.setDueAmount(cxpOrderDetails1.getTotalTaxAmount());
            monthlyTaxes.setDueAmount(String.valueOf(cxpOrderDetails1.getTotalMonthlyTaxes()));
            dueTodayTaxes.add(todayTaxes);
            dueMonthlyTaxes.add(monthlyTaxes);
            List<CXPDueItemsList> dueTodayList = new ArrayList<>();
            List<CXPDueItemsList> dueMonthlyList = new ArrayList<>();
            List<String> hiddenPromoList = new ArrayList<>();
            LineLevelOffers lineLevelOffers = new LineLevelOffers();
            CXPLineDetailsVO lineDetails = cxpResponse.getData().getValidateCartAndUpdate().getLineDetails();
            String lineActivityType="";
            populateCartDetails(request, cxpResponse, redisVal, lineDetails, cxpOrderDetails1, cart, isLoggedIn, hiddenPromoList, response, orderDetailsView);
            CXPLineInfo[] lineInfo;
            populateOrderDetailsView(lineDetails, orderDetailsView);
            if (null != lineDetails && null != lineDetails.getLineInfo()) {

                lineInfo = Arrays.stream(lineDetails.getLineInfo()).filter(lineInf -> (lineInf.getLineNumber() != null && !CartConstants.FEA.equalsIgnoreCase(lineInf.getLineActivityType())) || (lineInf.getMtnDetails() != null && (CartConstants.FEA.equalsIgnoreCase(lineInf.getLineActivityType()) || CartConstants.ACC.equalsIgnoreCase(lineInf.getLineActivityType())))).sorted(Comparator.comparing(CXPLineInfo::getLineNumber)).collect(Collectors.toList()).toArray(new CXPLineInfo[lineDetails.getNumOfLines()]);
                Arrays.stream(lineInfo).filter(Objects::nonNull).forEach(lineInfo1 -> {
                    CXPDueItemsList dueMonthlyPlanItems;
                    fiveGhomeCommonHelper.populateCartDetails(isEupFlow, lineInfo1,shippingDetails,orderDetailsView,dueMonthlyList,dueTodayList);
                    if (null != lineInfo1 && null != lineInfo1.getServiceInfo()) {
                        int featuresCount = 0;
                        List<String> promoList = getPromoList(request);
                        SelectedFeaturesList selectedFeaturesList = lineInfo1.getServiceInfo().getSelectedFeaturesList();
                        featuresCount = featuresCountExtraction(selectedFeaturesList, featuresCount);
                        List<CurrentProfileSPO> currentProfileSPOList = new ArrayList<>();
                        List<MobileInfoCustomerProfile> lstMtn = new ArrayList<>();
                        currentProfileSPOList = populateCurrentProfileSPOList(lineInfo1, cxpOrderDetails1, cart, lstMtn, currentProfileSPOList);
                        orderDetailsView.setVerizonCloudUnlimitedIncluded(lineInfo1.getServiceInfo().getHasVerizonCloudUnlimitedIncluded());

                        setDueMonthlyPlans(cxpResponse, redesignFlow, lineInfo1, cxpOrderDetails1, planDetails, orderDetailsView, dueMonthlyList, list);
                        logger.info("Adding Dummy Perks to soe DueMonthly List");
                        mapDummyPerkToDueMonthlyList(dueMonthlyList, lineInfo1,cxpOrderDetails1);
                        logger.info("Adding Dummy Perks to DueMonthly List -- completed");
                        fiveGhomeCommonHelper.populateAutoPayPromo(autoPayPromoKey,selectedFeaturesList,featuresCount,hiddenPromoList);
                        commonUtil.formatResponse(selectedFeaturesList, featuresCount, promoList, lineInfo1, response);
                        fiveGhomeCommonHelper.populateAEMRegistrationDetails(lineInfo1,response,isNSEFlow,amRegisterationDetails);
                        fiveGhomeCommonHelper.populateAppointmentDetails(lineInfo1,response);
                        fiveGhomeCommonHelper.setWhwBasicDetails(lineInfo1.getLineActivityType(),cxpOrderDetails1,lineInfo1,dueTodayList);
                        fiveGhomeCommonHelper.populateAccessoryOffers(lineInfo1,cxpOrderDetails1,lineInfo1.getLineActivityType(),currentProfileSPOList,dueTodayList);
                    }
                });
                populateComboOrders(request, customerProfileForNSE, response);
                fiveGhomeCommonHelper.callToPopulateDiscounts(cxpOrderDetails1,lineDetails,lineInfo,dueMonthlyList,redesignFlow,cxpResponse.getData().getValidateCartAndUpdate().getEcpdProfile() , isLoggedIn);
                fiveGhomeCommonHelper.populateAccessoryDetails(lineInfo,dueTodayList);
            }
            fiveGhomeNSEHelper.calculateDueMonthly(dueMonthlyList,cxpOrderDetails1,orderDetailsView,isLoggedIn);
            populatePaymentValues(lineDetails, payments);

            fiveGhomeCommonHelper.populateEUPDetails(isEupFlow,response,lineDetails);
            response.setCartValidationErrors(cxpResponse.getData().getValidateCartAndUpdate().getCartValidationErrors());
            commonUtil.formatGetCartDetailsUIResponse(request, dueMonthlyTaxes, shippingDetails, dueTodayList, dueMonthlyList, dueTodayTaxes, payments, amRegisterationDetails, isNSEFlow, orderDetailsView, hiddenPromoList, response);
            //ONly for Order Confirmation page
            populateUnplacedOrderPlanDetails(request, response, planDetails);

            populateAcpInfoDetails(cxpResponse, response);
        }
        return response;
    }

    private void populateUnplacedOrderPlanDetails(GetCartDetailsRequest request, GetCartDetailsUIResponse response, Map<String, String> planDetails) {
        if(request.getData() != null && !request.getData().isOrderPlaced()) {
            commonUtil.populatePlanDetailsInKibana(response, planDetails);
        }
    }

    private static int featuresCountExtraction(SelectedFeaturesList selectedFeaturesList, int featuresCount) {
        if(selectedFeaturesList != null) {
            featuresCount = selectedFeaturesList.getFeaturesCount();
        }
        return featuresCount;
    }

    private static void populatePaymentValues(CXPLineDetailsVO lineDetails, List<CXPPaymentsVO> payments) {
        if (null != lineDetails && null != lineDetails.getPayments()) {
            lineDetails.getPayments().stream()
                    .forEach(cxpPaymentsVO -> payments.add(cxpPaymentsVO));
        }
    }

    private void populateComboOrders(GetCartDetailsRequest request, CustomerProfileForNSE customerProfileForNSE, GetCartDetailsUIResponse response) {
        if (null != request.getIsSequentialComboOrder()
                && ("true".equalsIgnoreCase(request.getIsSequentialComboOrder()))) {
            fiveGhomeCommonHelper.populateComboForRetriveCallDetails(customerProfileForNSE, response);
        }
    }

    private void populateAcpInfoDetails(ValidateCartCXPResponse cxpResponse, GetCartDetailsUIResponse response) {
        if (cxpResponse.getData().getValidateCartAndUpdate().getAcpInfo() != null){
            ACPInfoGQL acpInfo = cxpResponse.getData().getValidateCartAndUpdate().getAcpInfo();
            commonUtil2.generateACPInfoKibanaLogs(acpInfo);
            if (acpInfo.getCustomerInfo() != null){
                if (response.getPrimaryUserInfo() != null ){
                    if ((StringUtilities.isEmptyOrNull(response.getPrimaryUserInfo().getFirstName()) ||
                            StringUtilities.isEmptyOrNull(response.getPrimaryUserInfo().getLastName()))
                            && acpInfo.getCustomerInfo().getContactInfo() != null){
                        response.getPrimaryUserInfo().setFirstName(acpInfo.getCustomerInfo().getContactInfo().getFirstName());
                        response.getPrimaryUserInfo().setLastName(acpInfo.getCustomerInfo().getContactInfo().getLastName());
                    }
                    response.getPrimaryUserInfo().setSsn(acpInfo.getCustomerInfo().getSsn());
                    response.getPrimaryUserInfo().setDob(acpInfo.getCustomerInfo().getDateOfBirth());
                }
            }
            ACPInfoDetails infoDetails = new ACPInfoDetails();
            infoDetails.setEnrollmentNumber(acpInfo.getEnrollmentNumber());
            infoDetails.setNladSubscriberId(acpInfo.getNladSubscriberId());
            infoDetails.setBenefit(acpInfo.getBenefit());
            response.setAcpInfoDetails(infoDetails);
        }
    }

    private static boolean setIsLoggedIn(ValidateCartCXPResponse cxpResponse, GetCartDetailsUIResponse response, boolean isLoggedIn) {
        if (cxpResponse.getData().getValidateCartAndUpdate().getCartHeader() != null) {
            response.setCartHeader(cxpResponse.getData().getValidateCartAndUpdate().getCartHeader());
            isLoggedIn = StringUtils.isNotBlank(cxpResponse.getData().getValidateCartAndUpdate().getCartHeader().getFullAccountNumber());
            response.getCartHeader().setCaseId(null);
            if(StringUtilities.isNotEmptyOrNull(response.getCartHeader().getCartId()))
            {
                response.getCartHeader().setCartExist("Y");
            }
            else
            {
                response.getCartHeader().setCartExist("N");
            }
            response.getCartHeader().setCartId(null);
        }
        return isLoggedIn;
    }

    private void populateCartDetails(GetCartDetailsRequest request, ValidateCartCXPResponse cxpResponse, FiveGLTEAddressRedis redisVal, CXPLineDetailsVO lineDetails, CXPOrderDetails cxpOrderDetails1, CXPCartVO cart, boolean isLoggedIn, List<String> hiddenPromoList, GetCartDetailsUIResponse response, CXPOrderDetailsView orderDetailsView) {
        String lineActivityType;
        LineLevelOffers lineLevelOffers;
        if(lineDetails != null && lineDetails.getLineInfo() != null && cxpOrderDetails1.getFlowType() != null && CartConstants.FLOW_TYPE_WHW.equalsIgnoreCase(cxpOrderDetails1.getFlowType())) {
            lineActivityType = Arrays.stream(cxpResponse.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()).map(CXPLineInfo::getLineActivityType).collect(Collectors.joining());
        }
        if (cart != null && cart.getCustomerProfile() != null && cart.getCustomerProfile().getBillAccounts() != null && cart.getCustomerProfile().getBillAccounts().get(0).getAccountOffers() != null && cart.getCustomerProfile().getBillAccounts().get(0).getAccountOffers().getLineLevelOffers() != null){
            lineLevelOffers = cart.getCustomerProfile().getBillAccounts().get(0).getAccountOffers().getLineLevelOffers();
        }
        CXPLineInfo[] lineInfo = null;
        if (isLoggedIn) {
            hiddenPromoList.add(wirelessPromoKey);
        }
        if(featureFlagHelper.isFWAUnifiedNBSEnabled() && request.getData().isFetchUnifiedNbsData()){
            response.setUnifiedNbsData(encryptDecryptHelper.getUnifiedNbsData(request.getIgSession(), redisVal));
        }

        if(StringUtilities.isNotEmptyOrNull(redisVal.getSafeTechSessionId())) {
            orderDetailsView.setSafeTechSessionId(redisVal.getSafeTechSessionId());
        }
    }

    private void setDigitalTypeForLoggedIn(ValidateCartCXPResponse cxpResponse, boolean isLoggedIn, GetCartDetailsUIResponse response) {
        if(isLoggedIn) {
            response.getCartHeader().setDigitalCustomerType(fiveGhomeCommonHelper.getDigitalCustomerTypeFromCart(cxpResponse.getData().getValidateCartAndUpdate().getCustomerProfile()));
        }
    }

    private static List<String> getPromoList(GetCartDetailsRequest request) {
        return request.getData() != null ? request.getData().getAvailableSpoCategoryFilters() : null;
    }

    private static List<CurrentProfileSPO> populateCurrentProfileSPOList(CXPLineInfo lineInfo1, CXPOrderDetails cxpOrderDetails1, CXPCartVO cart, List<MobileInfoCustomerProfile> lstMtn, List<CurrentProfileSPO> currentProfileSPOList) {
        if(lineInfo1.getLineActivityType() != null && CartConstants.ACC.equalsIgnoreCase(lineInfo1.getLineActivityType()) && cxpOrderDetails1 != null && cxpOrderDetails1.getFlowType() != null && CartConstants.FLOW_TYPE_WHW.equalsIgnoreCase(cxpOrderDetails1.getFlowType())) {
            String mtn = "";
            if (null != lineInfo1.getServiceInfo().getMtn()) {
                mtn = lineInfo1.getServiceInfo().getMtn();
            }
            if(cart != null && cart.getCustomerProfile() != null && cart.getCustomerProfile().getBillAccounts() != null && cart.getCustomerProfile().getBillAccounts().size() > 0 && cart.getCustomerProfile().getBillAccounts().get(0).getMtns() != null){
                lstMtn = cart.getCustomerProfile().getBillAccounts().get(0).getMtns();
            }
            for (MobileInfoCustomerProfile cxpMtn : lstMtn) {
                currentProfileSPOList = getCurrentProfileSPOS(cxpMtn, mtn, currentProfileSPOList);
            }
        }
        return currentProfileSPOList;
    }

    private void setDueMonthlyPlans(ValidateCartCXPResponse cxpResponse, boolean redesignFlow, CXPLineInfo lineInfo1, CXPOrderDetails cxpOrderDetails1, Map<String, String> planDetails, CXPOrderDetailsView orderDetailsView, List<CXPDueItemsList> dueMonthlyList, List<OrderList> list) {
        CXPDueItemsList dueMonthlyPlanItems;
        if (null != lineInfo1.getServiceInfo().getPlanDetails() && !fiveGhomeCommonHelper.isWHWFlowType(cxpOrderDetails1, lineInfo1.getLineActivityType())) {
                dueMonthlyPlanItems = new CXPDueItemsList();
                dueMonthlyPlanItems.setActualAmount(String.valueOf(lineInfo1.getServiceInfo().getPlanDetails().getPlanPrice()));
                dueMonthlyPlanItems.setTotalAmountWithDiscount(String.valueOf(lineInfo1.getServiceInfo().getPlanDetails().getPlanPrice()));
                if (cartRedesignKillSwitch)
                    //apply autopay, loyalty & ecpd discount to plan price
                    fiveGhomeCommonHelper.applyPlanDiscountsOnPlan(redesignFlow, lineInfo1, cxpResponse.getData().getValidateCartAndUpdate().getEcpdProfile(), dueMonthlyPlanItems);
                fiveGhomeCommonHelper.populateOverDetailsView(lineInfo1.getLineActivityType(), dueMonthlyPlanItems, lineInfo1, planDetails, orderDetailsView, dueMonthlyList);
                fiveGhomeCommonHelper.populateSecurityDeposit(list, orderDetailsView);
            }
    }

    private static List<CurrentProfileSPO> getCurrentProfileSPOS(MobileInfoCustomerProfile cxpMtn, String mtn, List<CurrentProfileSPO> currentProfileSPOList) {
        if (null != cxpMtn.getMtn() && StringUtilities.isNotEmptyOrNull(mtn) && cxpMtn.getMtn().equalsIgnoreCase(mtn)) {
            currentProfileSPOList = cxpMtn.getCurrentSpo();
        }
        return currentProfileSPOList;
    }

    private void mapDummyPerkToDueMonthlyList(List<CXPDueItemsList> dueMonthlyList, CXPLineInfo lineInfo1, CXPOrderDetails cxpOrderDetails1) {
        if(null != lineInfo1.getServiceInfo().getPlanPerks() && !fiveGhomeCommonHelper.isWHWFlowType(cxpOrderDetails1,lineInfo1.getLineActivityType())) {
            List<PlanPerks> planPerksList = lineInfo1.getServiceInfo().getPlanPerks();
            try {
                for (PlanPerks perk : planPerksList) {
                    CXPDueItemsList dueMonthlyPerkItems = new CXPDueItemsList();
                    dueMonthlyPerkItems.setActualAmount(String.valueOf(perk.getPerkOriginalPrice()));
                    dueMonthlyPerkItems.setTotalAmountWithDiscount(String.valueOf(perk.getFeaturePrice()));
                    dueMonthlyPerkItems.setName(perk.getFeatureDesc());
                    dueMonthlyPerkItems.setProductId(perk.getVisFeatureCode());
                    dueMonthlyPerkItems.setItemType("PERK");
                    dueMonthlyPerkItems.setDiscountsAndPromotions(perk.getDiscountsAndPromotions());
                    dueMonthlyList.add(dueMonthlyPerkItems);
                }
            }
            catch(Exception e){
                logger.error("Error occured while mapping perks to due monthly list {0}",e);
            }
        }
    }


    private void populateBackOrderDetails(ValidateCartCXPResponse cxpResponse, CXPOrderDetailsView orderDetailsView) {
        if(cxpResponse.getData().getValidateCartAndUpdate().getLineDetails() != null &&
                cxpResponse.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo() != null){
            Optional<CXPLineInfo> optionalValue = Arrays.stream(cxpResponse.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()).filter(lineInfo -> lineInfo.getPreOrderInServiceDate() != null).findAny();
            if(optionalValue.isPresent()){
                orderDetailsView.setPreOrderInServiceDate(optionalValue.get().getPreOrderInServiceDate());
            }
        }
    }


}
