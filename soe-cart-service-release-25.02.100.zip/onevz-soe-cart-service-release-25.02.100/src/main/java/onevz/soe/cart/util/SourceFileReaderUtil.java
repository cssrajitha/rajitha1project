package onevz.soe.cart.util;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import onevz.soe.cart.constants.ProjectLocation;

/**
 * 
 * @author PANDSI9
 *
 */
@Service
public class SourceFileReaderUtil {

    private static final Logger logger = LoggerFactory.getLogger(SourceFileReaderUtil.class);

    /**
     * 
     * @param fileName
     * @param location
     * @return
     */
    public String readFile (String fileName, String location) {
        String responseString = "";
        String emptyResponse = "{ \"status\": \"\", \"payload\": \"\", \"errors\": []}";
        try {

            if(location.equalsIgnoreCase(ProjectLocation.LOCAL.toString())) {
                ClassPathResource resource = new ClassPathResource(fileName);
                File file = resource.getFile();
                responseString = FileUtils.readFileToString(file, StandardCharsets.UTF_8);
            }else {
                String relativePath = "/src/test/resources/" + fileName;
                responseString = new String(Files.readAllBytes(Paths.get(relativePath)));
            }
        }catch (IOException ex) {
            responseString = emptyResponse;
            logger.error("Error occurred while processing :: cart-service reading-utility " + ex);
        }
        return responseString;
    }
}
