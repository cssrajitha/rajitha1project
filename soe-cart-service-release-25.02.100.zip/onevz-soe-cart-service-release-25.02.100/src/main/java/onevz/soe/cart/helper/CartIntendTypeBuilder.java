package onevz.soe.cart.helper;

/*import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.json.JsonSanitizer;
import onevz.soe.cart.constants.CartConstants;*/
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.model.flexVtwo.RequestData;
import onevz.soe.cart.model.flexVtwo.SessionResponse;

import onevz.soe.cart.model.retrieveCart.CXPLineInfo;
import onevz.soe.cart.ui.common.CartInfo;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.util.FlexV2Util;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.*;
import java.util.stream.Collectors;

import static onevz.soe.cart.util.FlexV2Util.intendTypePreferenceMap;
import static onevz.soe.cart.util.FlexV2Util.intendTypePreferenceMapCart;

/*import static onevz.soe.cart.constants.CartConstants.CUSTOMER_TYPE;
import onevz.soe.customerprofile.response.CustomerProfileGraphQLAssistedResponse;
import onevz.soe.cart.responses.RetrieveCartCXPResponse;
import onevz.soe.utilities.serialization.JacksonMapperFactory;
import onevz.soe.session.bean.SOELoginSessionBean;
import reactor.core.publisher.Mono;*/


@Service
public class CartIntendTypeBuilder {


    @Autowired
    private RedisHelper redisHelper;

    @Autowired
    private CartServiceCXPServices cxpService;
/*    @Autowired
    SOELoginSessionBean sessionBean;
    private String sessionKeys = "customerType,retrieveCartResponse,customerProfile";*/

    private static final Logger logger = LoggerFactory.getLogger(CartIntendTypeBuilder.class);

    public enum CartActions {

        ADD_DEVICE {
            @Override
            public String getIntendType(List<Lines> lines, SessionResponse sessionResponse) {
                return new CartIntendTypeBuilder().getAddDeviceIntendType(lines,sessionResponse);
            }
        },
        REMOVE_LINES {
            @Override
            public String getIntendType(List<Lines> lines, SessionResponse sessionResponse) {
                return new CartIntendTypeBuilder().getRemoveLinesIntendType(lines,sessionResponse);
            }
        },
        VALIDATE_DEVICE_SIMID {
            @Override
            public String getIntendType(List<Lines> lines, SessionResponse sessionResponse) {
                return new CartIntendTypeBuilder().getValidateDeviceSimIdIntendType(lines,sessionResponse);
            }
        },
        ADD_PLAN {
            @Override
            public String getIntendType(List<Lines> lines, SessionResponse sessionResponse) {
                return new CartIntendTypeBuilder().getAddPlanIntendType(lines,sessionResponse);
            }
        },
        NEW_LINE {
            @Override
            public String getIntendType(List<Lines> lines, SessionResponse sessionResponse) {
                return new CartIntendTypeBuilder().getNewLineIntendType(lines,sessionResponse);
            }
        },
        ASSIGN_MTN {
            @Override
            public String getIntendType(List<Lines> lines, SessionResponse sessionResponse) {
                return new CartIntendTypeBuilder().getAssignMtnIntendType(lines,sessionResponse);
            }
        },

        ADD_ACCESSORY {
            @Override
            public String getIntendType(List<Lines> lines, SessionResponse sessionResponse) {
                return new CartIntendTypeBuilder().getAddAccessoryIntendType(lines,sessionResponse);
            }
        };
    /*
     NEW_LINE {

            @Override
            public String getIntendType(Lines[] lines, SessionResponse sessionResponse) {
                return new FlexV2RequestBuilder().getNewLineIntendType(lines, sessionResponse);
            }
        },
        ADD_FEATURES {
            @Override
            public String getIntendType(Lines[] lines, SessionResponse sessionResponse) {
                return getAddFeaturesIntendType(lines, sessionResponse);
            }
         };*/
        public abstract String getIntendType( List<Lines> lines, SessionResponse sessionResponse);
    }

    public String getRemoveLinesIntendType(List<Lines> lines,SessionResponse sessionResponse) {
        RequestData data = new RequestData();

        generateRemoveLinesIntendType(lines, data, sessionResponse);
        return data.getIntendType();
    }
    public String getAddDeviceIntendType(List<Lines> lines,SessionResponse sessionResponse) {
        RequestData data = new RequestData();

        generateAddDeviceIntendType(lines, data, sessionResponse);
        return data.getIntendType();
    }
    public String getValidateDeviceSimIdIntendType(List<Lines> lines,SessionResponse sessionResponse) {
        RequestData data = new RequestData();

        generateValidateDeviceSimIdIntendType(lines, data, sessionResponse);
        return data.getIntendType();
    }
    public String getAddPlanIntendType(List<Lines> lines,SessionResponse sessionResponse) {
        RequestData data = new RequestData();

        updateCustPlansIntendType(sessionResponse, data);
        return data.getIntendType();
    }

    public String getNewLineIntendType(List<Lines> lines,SessionResponse sessionResponse) {
        RequestData data = new RequestData();

        generateNewLineIntendType(lines, data, sessionResponse);
        return data.getIntendType();
    }

    public String getAssignMtnIntendType(List<Lines> lines,SessionResponse sessionResponse) {
        RequestData data = new RequestData();

        generateAssignMtnIntendType(lines, data, sessionResponse);
        return data.getIntendType();
    }

    public String getAddAccessoryIntendType(List<Lines> lines,SessionResponse sessionResponse) {
        RequestData data = new RequestData();

        generateAddAccessoryIntendType(lines, data, sessionResponse);
        return data.getIntendType();
    }

    public void generateRemoveLinesIntendType(List<Lines> lines, RequestData data,SessionResponse sessionResponse){

        if(StringUtilities.isNotEmptyOrNull(sessionResponse.getCustomerType()) && "N".equalsIgnoreCase(sessionResponse.getCustomerType()))
            data.setIntendType("NSE");
         else if (FlexV2Util.isCartHasRequestMtn(sessionResponse,data, lines) && !FlexV2Util.isAccountHasRequestMtn(sessionResponse,data, lines))
                data.setIntendType("AAL");
         else if (StringUtilities.isEmptyOrNull(data.getIntendType()))
                data.setIntendType("EUP");

        logger.info("Method - generateRemoveLinesIntendType : value {}",data);
    }
    public void generateAddDeviceIntendType(List<Lines> lines, RequestData data,SessionResponse sessionResponse ) {
        List<String> aalIntendList = Arrays.asList("AAL", "BYOD");

        if(StringUtilities.isNotEmptyOrNull(sessionResponse.getCustomerType()) && "N".equalsIgnoreCase(sessionResponse.getCustomerType())){

            if(FlexV2Util.isBYODFlow(lines))
                data.setIntendType("NSEBYOD");
            else data.setIntendType("NSE");
        }
        else {
            if (FlexV2Util.isBYODFlow(lines)) {
                if (sessionResponse.getFlow() != null && CartConstants.REFUND_EXC.equalsIgnoreCase(sessionResponse.getFlow())) {
                    data.setIntendType(CartConstants.EXCBYOD);}
                else if(FlexV2Util.isAccountHasRequestMtn(sessionResponse, data, lines)) {
                    data.setIntendType("EUPBYOD");
                }else{ data.setIntendType("BYOD");}
            } else if (sessionResponse.getFlow() != null && CartConstants.REFUND_EXC.equalsIgnoreCase(sessionResponse.getFlow()))
                data.setIntendType(CartConstants.EXCHANGE);
            else if (FlexV2Util.isCartHasRequestMtn(sessionResponse,data, lines) && StringUtilities.isNotEmptyOrNull(data.getCartMatchLineActivityType()) && aalIntendList.contains(data.getCartMatchLineActivityType()))
                data.setIntendType("AAL");
            else if (StringUtilities.isEmptyOrNull(data.getIntendType()))
                data.setIntendType("EUP");
        }
        logger.info("Method - generateAddDeviceIntendType : value {}",data);
    }
    public void generateValidateDeviceSimIdIntendType(List<Lines> lines, RequestData data,SessionResponse sessionResponse) {
        if (StringUtilities.isNotEmptyOrNull(sessionResponse.getCustomerType()) && "N".equalsIgnoreCase(sessionResponse.getCustomerType())) {

            if (FlexV2Util.isBYODFlow(lines))
                data.setIntendType("NSEBYOD");
            else data.setIntendType("NSE");
        } else {
            if (FlexV2Util.isBYODFlow(lines)) {
                data.setIntendType("BYOD");
            } else if (FlexV2Util.isCartHasRequestMtn(sessionResponse, data, lines) && StringUtilities.isNotEmptyOrNull(data.getCartMatchLineActivityType()) && data.getCartMatchLineActivityType().equalsIgnoreCase("AAL"))
                data.setIntendType("AAL");
            else if (StringUtilities.isEmptyOrNull(data.getIntendType()))
                data.setIntendType("EUP");
        }
    }
    public void generateNewLineIntendType(List<Lines> lines, RequestData data,SessionResponse sessionResponse) {
        String customerType = StringUtilities.isNotEmptyOrNull(sessionResponse.getCustomerType()) ? sessionResponse.getCustomerType() : "";

        if(customerType != null && "N".equalsIgnoreCase(customerType)){
            data.setIntendType(CartConstants.NSE);
        }else{
            if(FlexV2Util.is5GDevice(lines)){
                data.setIntendType(CartConstants.AAL_5G);
            }else{
                data.setIntendType(CartConstants.AAL);
            }
        }
    }

    public void generateAssignMtnIntendType(List<Lines> lines, RequestData data,SessionResponse sessionResponse) {
        String customerType = StringUtilities.isNotEmptyOrNull(sessionResponse.getCustomerType()) ? sessionResponse.getCustomerType() : "";
        if(sessionResponse.getRetrieveCart() != null && sessionResponse.getRetrieveCart().getCart() != null
                && sessionResponse.getRetrieveCart().getCart().getLineDetails() != null
                && sessionResponse.getRetrieveCart().getCart().getLineDetails().getLineInfo() != null
                && CollectionUtilities.isNotEmptyOrNull(Arrays.asList(sessionResponse.getRetrieveCart().getCart().getLineDetails().getLineInfo()))
                && FlexV2Util.is5GDeviceAssignMtn(sessionResponse.getRetrieveCart().getCart().getLineDetails().getLineInfo())){
            if((StringUtilities.isNotEmptyOrNull(sessionResponse.getIsHomeSales()) && sessionResponse.getIsHomeSales().equalsIgnoreCase("true"))
                    && (CartConstants.RETAIL.equalsIgnoreCase(sessionResponse.getChannelId()) || CartConstants.OMNI_D2D.equalsIgnoreCase(sessionResponse.getChannelId()))){
                if(sessionResponse.getHomeSalesAddress() != null && sessionResponse.getHomeSalesAddress().isLTEQualified()){
                    if("N".equalsIgnoreCase(customerType))
                        data.setIntendType(CartConstants.NSE_LTE);
                    else
                        data.setIntendType(CartConstants.AAL_LTE);
                }
                else{
                    if("N".equalsIgnoreCase(customerType))
                        data.setIntendType(CartConstants.NSE_5G);
                    else
                        data.setIntendType(CartConstants.AAL_5G);
                }
            }
            else{
                if(sessionResponse.getFiveGAddressRedisData() != null && sessionResponse.getFiveGAddressRedisData().getAddressRequest() != null
                    && sessionResponse.getFiveGAddressRedisData().getAddressRequest().isLTEQualified()){
                    if("N".equalsIgnoreCase(customerType))
                        data.setIntendType(CartConstants.NSE_LTE);
                    else
                        data.setIntendType(CartConstants.AAL_LTE);
                }
                else{
                    if("N".equalsIgnoreCase(customerType))
                        data.setIntendType(CartConstants.NSE_5G);
                    else
                        data.setIntendType(CartConstants.AAL_5G);
                }
            }
        }else{
            if("N".equalsIgnoreCase(customerType))
                data.setIntendType(CartConstants.NSE);
            else
                data.setIntendType(CartConstants.AAL);
        }
    }

    /**
     *
     * @param sessionResponse
     * @param data
     * Preference IntendtType - To derive intendType based on the lineActivityType from cart.
     * default intendType - CPC
     */
    public void updateCustPlansIntendType(SessionResponse sessionResponse,RequestData data){
        List<CXPLineInfo> lineInfo = new ArrayList<>();
        if (sessionResponse.getRetrieveCart() != null && FlexV2Util.isCartHasLine(sessionResponse.getRetrieveCart())) {
            lineInfo = Arrays.asList(sessionResponse.getRetrieveCart().getCart().getLineDetails().getLineInfo());

            List<String> lineActTypeListFromCart = lineInfo.stream().filter(lineInfoObj -> lineInfoObj.getLineActivityType() != null).distinct().map(CXPLineInfo::getLineActivityType).collect(Collectors.toList());

            Optional<Map.Entry<String, Integer>> optionalMap = intendTypePreferenceMap.entrySet().stream()
                    .filter(e -> lineActTypeListFromCart.contains(e.getKey()))
                    .sorted(Map.Entry.comparingByValue())
                    .collect(Collectors.toMap(
                            Map.Entry::getKey,
                            Map.Entry::getValue,
                            (e1, e2) -> e1, LinkedHashMap::new)).entrySet().stream().filter(Objects::nonNull).findFirst();

            optionalMap.ifPresent(obj -> {
                data.setIntendType(obj.getKey());
            });
        }
        if (sessionResponse.getFlow() != null && CartConstants.REFUND_EXC.equalsIgnoreCase(sessionResponse.getFlow())) {
            data.setIntendType(CartConstants.REFUND_EXCHANGE);
        }
        if(StringUtilities.isEmptyOrNull(data.getIntendType())) {
            if (StringUtilities.isNotEmptyOrNull(sessionResponse.getCustomerType()) && "N".equalsIgnoreCase(sessionResponse.getCustomerType())) {
                data.setIntendType("NSE");
            }
            else {
                data.setIntendType("CPC");
            }
        }
    }

    public void updateSaveCartIntendType(SessionResponse sessionResponse, CartInfo cartInfo){
        List<CXPLineInfo> lineInfo = new ArrayList<>();

        if (sessionResponse.getRetrieveCart() != null && FlexV2Util.isCartHasLine(sessionResponse.getRetrieveCart())) {
            lineInfo = Arrays.asList(sessionResponse.getRetrieveCart().getCart().getLineDetails().getLineInfo());

            List<String> lineActTypeListFromCart = lineInfo.stream().filter(lineInfoObj -> lineInfoObj.getLineActivityType() != null).distinct().map(CXPLineInfo::getLineActivityType).toList();

            Optional<Map.Entry<String, Integer>> optionalMap = intendTypePreferenceMapCart.entrySet().stream()
                    .filter(e -> lineActTypeListFromCart.contains(e.getKey()))
                    .sorted(Map.Entry.comparingByValue())
                    .collect(Collectors.toMap(
                            Map.Entry::getKey,
                            Map.Entry::getValue,
                            (e1, e2) -> e1, LinkedHashMap::new)).entrySet().stream().filter(Objects::nonNull).findFirst();

            optionalMap.ifPresent(obj ->
                    cartInfo.setIntendType(obj.getKey())
            );
        }
        if (sessionResponse.getFlow() != null && CartConstants.REFUND_EXC.equalsIgnoreCase(sessionResponse.getFlow())) {
            cartInfo.setIntendType(CartConstants.REFUND_EXCHANGE);
        }

        if(StringUtilities.isEmptyOrNull(cartInfo.getIntendType())) {
            if (StringUtilities.isNotEmptyOrNull(sessionResponse.getCustomerType()) && CartConstants.NEW_CUSTOMER.equalsIgnoreCase(sessionResponse.getCustomerType())) {
                cartInfo.setIntendType(CartConstants.NSE);
            }else {
                cartInfo.setIntendType("");
            }
        }
    }

    public void generateAddAccessoryIntendType(List<Lines> lines, RequestData data,SessionResponse sessionResponse){

        if(StringUtilities.isNotEmptyOrNull(sessionResponse.getCustomerType()) && "N".equalsIgnoreCase(sessionResponse.getCustomerType()))
            data.setIntendType("NSE");
        else if (sessionResponse.getFlow() != null && CartConstants.REFUND_EXC.equalsIgnoreCase(sessionResponse.getFlow()))
            data.setIntendType(CartConstants.REFUND_EXCHANGE);
        else if (FlexV2Util.isCartHasRequestMtn(sessionResponse,data, lines) && !FlexV2Util.isAccountHasRequestMtn(sessionResponse,data, lines))
            data.setIntendType("AAL");
        else if (data.getCartMatchLineActivityType() != null && "ACC".equalsIgnoreCase(data.getCartMatchLineActivityType()))
            data.setIntendType("ACC");
        else
            data.setIntendType("EUP");
    }

/*
    public String getAddPlanIntendType(Lines[] line, SessionResponse sessionResponse) {
        RequestData data = new RequestData();

        List<Lines> lines = Arrays.asList(line);
        new FlexV2RequestBuilder().generateAddPlanIntendType(lines, data, sessionResponse);
        return data.getIntendType();
    }
    public void generateAddPlanIntendType(List<Lines> lines, RequestData data, SessionResponse sessionResponse) {

        String customerType =null;
        if(sessionResponse.getRetrieveCart() != null)
            customerType = getCustomerTypeFromCart(sessionResponse.getRetrieveCart());
        if(*/
/*null != sessionResponse && *//*
StringUtilities.isNotEmptyOrNull(customerType) && "N".equalsIgnoreCase(customerType))
            data.setIntendType("NSE");
        else {
            if (!isCartHasRequestMtn(sessionResponse, data, lines)
                    || (data.getCartMatchLineActivityType() != null && "CPC".equalsIgnoreCase(data.getCartMatchLineActivityType()))
                    || (data.getCartMatchLineActivityType() != null && "FEA".equalsIgnoreCase(data.getCartMatchLineActivityType()))
                    || (data.getCartMatchLineActivityType() != null && "ACC".equalsIgnoreCase(data.getCartMatchLineActivityType()))) {
                data.setIntendType("CPC");
            } else if (StringUtilities.isNotEmptyOrNull(data.getCartMatchLineActivityType()) && data.getCartMatchLineActivityType().equalsIgnoreCase("AAL"))
                data.setIntendType("AAL");
            else if (StringUtilities.isEmptyOrNull(data.getIntendType()))
                data.setIntendType("EUP");
        }
    }


    */
/* ---------- Feature------------*//*

    public static String getAddFeaturesIntendType(Lines[] line, SessionResponse sessionResponse) {
        RequestData data = new RequestData();

        List<Lines> lines = Arrays.asList(line);
        new FlexV2RequestBuilder().generateAddFeaturesIntendTye(lines, data, sessionResponse);
        return data.getIntendType();
    }
    public void generateAddFeaturesIntendTye(List<Lines> lines, RequestData data,SessionResponse sessionResponse) {

            if(StringUtilities.isNotEmptyOrNull(sessionResponse.getCustomerType()) && "N".equalsIgnoreCase(sessionResponse.getCustomerType()))
                data.setIntendType("NSE");
            else {
                buildExistCustAddFeaIntendType(sessionResponse, data, lines);
            }
    }
    public void buildExistCustAddFeaIntendType(SessionResponse sessionResponse,RequestData data,List<Lines> lines){

        if (!isCartHasRequestMtn(sessionResponse, data, lines) || (data.getCartMatchLineActivityType() != null && "FEA".equalsIgnoreCase(data.getCartMatchLineActivityType()))) {
            data.setIntendType("FEA");
        } else {
            if (StringUtilities.isNotEmptyOrNull(data.getCartMatchLineActivityType()) && data.getCartMatchLineActivityType().equalsIgnoreCase("AAL"))
                data.setIntendType("AAL");
            else if(StringUtilities.isNotEmptyOrNull(data.getCartMatchLineActivityType()) && data.getCartMatchLineActivityType().equalsIgnoreCase("CPC"))
                data.setIntendType("CPC");
            else if (StringUtilities.isEmptyOrNull(data.getIntendType()))
                data.setIntendType("EUP");
        }
    }

/*    public String getCustomerTypeFromCart(CXPRetrieveCartDataVO cart){
        if(cart != null && cart.getCart() != null && cart.getCart().getOrderDetails() != null && cart.getCart().getOrderDetails().getCustomerType() != null)
            return cart.getCart().getOrderDetails().getCustomerType();

        return "";
    }*/

  /*  public String getNewLineIntendType(Lines[] line,SessionResponse sessionResponse) {
        RequestData data = new RequestData();

        List<Lines> lines = Arrays.asList(line);

        new FlexV2RequestBuilder().generateNewLineIntendTye(lines, data, sessionResponse);
        return data.getIntendType();
    }

    public void generateNewLineIntendTye(List<Lines> lines, RequestData data,SessionResponse sessionResponse) {

            String customerType = StringUtilities.isNotEmptyOrNull(sessionResponse.getCustomerType()) ? sessionResponse.getCustomerType() : "";

            if (CollectionUtilities.isNotEmptyOrNull(lines)) {
                lines.forEach(line -> {
                    if (StringUtilities.isNotEmptyOrNull(line.getDeviceTypeSelected()) && !"5G Internet".equalsIgnoreCase(line.getDeviceTypeSelected())) {
                        if (customerType != null && "N".equalsIgnoreCase(customerType)) {
                            data.setIntendType("NSE");
                        } else data.setIntendType("AAL");
                    }
                });
            }
    }
*/
 /*   public List<String> retrieveSessionKeys() {
        String[] array = sessionKeys.split(",");
        return new ArrayList<>(Arrays.asList(array));
    }

    public Mono<SessionResponse> updateDetailsFromRedis() {
        List<String> sessionKeysL = retrieveSessionKeys();
        logger.debug("Session Keys : {}", sessionKeysL);
        return sessionBean.getSessionData(sessionKeysL)
                .onErrorReturn(new HashMap<>())
                .defaultIfEmpty(new HashMap<>())
                .flatMap(data -> {
                    SessionResponse sessionResponse = new SessionResponse();
                    if (data != null)
                        copyDetails(sessionResponse, data);
                    logger.info("Request data updated from redis : {}", sessionResponse);
                    return Mono.just(sessionResponse);
                });
    }

    public void copyDetails(SessionResponse sessionResponse, Map<Object, Object> data) {
        if (data == null || data.isEmpty()) {
            return;
        }
        if (data.containsKey(CartConstants.PREPAY_CUSTOMER_TYPE))
            sessionResponse.setCustomerType((String) data.get(CUSTOMER_TYPE));

        if (data.containsKey(CartConstants.RETRIEVE_CART_RESPONSE)) {
            try {
                if (data.get(CartConstants.RETRIEVE_CART_RESPONSE) != null) {
                    sessionResponse.setRetrieveCart(JacksonMapperFactory.readerForType(CXPRetrieveCartDataVO.class).readValue(JsonSanitizer.sanitize((String) data.get(CartConstants.RETRIEVE_CART_RESPONSE))));
                }
            } catch (JsonProcessingException e) {
                logger.error("retrieve cart in session response {}", e.getMessage());
            }
        }
        if (data.containsKey(CartConstants.CUSTOMER_PROFILE)) {
            try {
                if (data.get(CartConstants.CUSTOMER_PROFILE) != null) {
                    sessionResponse.setCustomerProfile(JacksonMapperFactory.readerForType(CustomerProfileResponse.class).readValue(JsonSanitizer.sanitize((String) data.get(CartConstants.CUSTOMER_PROFILE))));
                }
            } catch (JsonProcessingException e) {
                logger.error("customer profile in session response {}", e.getMessage());
            }
        }
    }
 */

/*
    Mono <Boolean> updateCartAndProfileResponse(SessionResponse sessionResponse){
        logger.info("updateCartAndProfileResponse IN- sessionResponse: {}", sessionResponse);

        Mono<RetrieveCartCXPResponse> retrieveCartMono= retrieveCart(sessionResponse);
        Mono<CustomerProfileGraphQLAssistedResponse> customerProfileMono =  getCustomerProfile(sessionResponse);

        return Mono.zip(retrieveCartMono, customerProfileMono).flatMap(tuple2 ->{
            if(tuple2.getT1() != null && tuple2.getT1().getData() != null)
                sessionResponse.setRetrieveCart(tuple2.getT1().getData());

            if(tuple2.getT2() != null && tuple2.getT2().getData() != null) {
                CustomerProfileResponse customerProfileResponse = new CustomerProfileResponse();
                customerProfileResponse.setData(tuple2.getT2().getData());
                sessionResponse.setCustomerProfile(customerProfileResponse);
            }
            logger.info("updateCartAndProfileResponse OUT- sessionResponse: {}", sessionResponse);
            return Mono.just(true);
        });
    }
    public Mono<CustomerProfileGraphQLAssistedResponse> getCustomerProfile(SessionResponse sessionResponse){
        logger.info("getCustomerProfile IN- sessionResponse: {}", sessionResponse);

        if((sessionResponse.getCustomerProfile() != null) ||
                (StringUtilities.isNotEmptyOrNull(sessionResponse.getCustomerType()) && "N".equalsIgnoreCase(sessionResponse.getCustomerType())))
            return Mono.just(new CustomerProfileGraphQLAssistedResponse());

        else {
            if (StringUtilities.isNotEmptyOrNull(sessionResponse.getAccountNumber()))
                return cxpService.getCustomerProfileAssisted(sessionResponse.getAccountNumber());
        }
        return  Mono.just(new CustomerProfileGraphQLAssistedResponse());
    }
    public Mono<RetrieveCartCXPResponse> retrieveCart(SessionResponse sessionResponse){
        logger.info("retrieveCart IN- sessionResponse: {}", sessionResponse);
        if(sessionResponse != null && sessionResponse.getRetrieveCart() != null)
            return Mono.just(new RetrieveCartCXPResponse());

        if(null != sessionResponse && sessionResponse.getRetrieveCart() == null && StringUtilities.isNotEmptyOrNull(sessionResponse.getCartId())){
            List <String> mtnList = new ArrayList<String>();
            return cxpService.retrieveCart(sessionResponse.getCartId(), false, mtnList);
        }
        return Mono.just(new RetrieveCartCXPResponse());
    }
*/

}
