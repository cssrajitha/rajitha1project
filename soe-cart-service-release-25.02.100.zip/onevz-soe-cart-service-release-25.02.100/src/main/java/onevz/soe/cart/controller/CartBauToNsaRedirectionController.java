package onevz.soe.cart.controller;

import java.io.UnsupportedEncodingException;
import java.security.SignatureException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import jakarta.validation.Valid;

import onevz.soe.cart.helper.*;
import onevz.soe.cart.omnidl.OmniBuilder;
import onevz.soe.cart.util.CartUtil;
import onevz.soe.omnidl.service.OmniDLService;
import onevz.soe.wsclient.bpm.model.response.AvailablePaths;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.*;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.cradle.util.CradleConstants;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.exceptions.JsonValidator;
import onevz.soe.cart.model.common.AccountLevelChangeEligibility;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.common.CartServiceCartInfo;
import onevz.soe.cart.model.common.CartServiceContextInfo;
import onevz.soe.cart.model.common.Line;
import onevz.soe.cart.model.mvo.ServiceOffer;
import onevz.soe.cart.requests.MvoRequest;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.responses.RPSFlowRedisData;
import onevz.soe.cart.responses.RPSRedisData;
import onevz.soe.cart.ui.common.CarrierPostData;
import onevz.soe.cart.ui.requests.RPSApplePayloadUIRequest;
import onevz.soe.cart.ui.requests.SecondaryDeviceActive;
import onevz.soe.cart.ui.responses.AddDeviceUIResponse;
import onevz.soe.cart.util.CartPegaRequestErrorsUtil;
import onevz.soe.cart.util.CartPegaResponseErrorsUtil;
import onevz.soe.cradle.CradleAllocator;
import onevz.soe.cradle.constant.Constants;
import onevz.soe.logging.util.LoggerUtil;
import onevz.soe.omnidl.util.DLUtilityService;
import onevz.soe.security.TokenProcessor;
import onevz.soe.security.model.SsoJwtDTO;
import onevz.soe.security.util.AESUtil;
import onevz.soe.security.util.RPSAES128CBCUtil;
import onevz.soe.session.constants.SessionConstants;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.utilities.serialization.JacksonMapperFactory;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

/**
 * Cart Controller class.
 */
//NSADT-53978 removing CrossOrigin annotation in every service
//@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping(value = "cart")
public class CartBauToNsaRedirectionController {

	private static final Logger logger = LoggerFactory.getLogger(CartBauToNsaRedirectionController.class);

	@Autowired
	private OmniDLService dlService;

	@Autowired
	private UpdateCartHelper helper;

	@Autowired
	private RedisHelper redisHelper;

	@Autowired
	private RedisHelper2 redisHelper2;

	@Autowired
	private RedisHelper3 redisHelper3;

	@Autowired
	private CartAddDeviceHelper accDevHelper;

	@Autowired
	private Environment env;

	@Value("${processingMtnFlag}")
	private String processingMtnFlag;

	@Value("${orderRestrictionCodes}")
	private String orderRestrictionCodes;

	@Autowired
	private TokenProcessor tokenProcessor;

	@Autowired
	private DLUtilityService dlUtilityService;
	
	@Autowired
	private CartRpsHelper rpsHelper;

	@Autowired
	JsonValidator validator;


	@Value("${rpsAESKey}")
	private String rpsAESKey;

	@Value("${rpsAMaesKey}")
	private String rpsAMaesKey;

	@Value("${rpsAESIterationCount}")
	private Integer rpsIterationCount;

	@Value("${soe.cart.aes.provider:AES/CBC/PKCS5Padding}")
	private String provider;

	@Value("${rpsHostName}")
	private String rpsHostName;

	@Value("${rpsEnableSPCToken}")
	private Boolean rpsEnableSPCToken;
	
	@Autowired
	private CradleAllocator cradleAllocator;
	
	@Autowired
	private FeatureFlagHelper featureFlagHelper;
	
	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private CartUtil cartUtil;

	/**
	 *
	 * @param binder
	 */
	@InitBinder("*")
	public void initBinderByName(WebDataBinder binder) {
		binder.setDisallowedFields(new String[] { "genericHeader" });
	}

	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param intendType
	 * @return ResponseEntity
	 * @throws SignatureException
	 * @throws UnsupportedEncodingException
	 *
	 *
	 */
	@SuppressWarnings({"java:S3776"})
	@GetMapping("/add-step")
	public Mono<ResponseEntity<GenericResponse>> addStep(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse,
			@RequestParam("deviceProdId") String deviceProdId, @RequestParam("deviceSorId") String deviceId,
			@RequestParam("contractTerm") String contractTerm, @RequestParam("dacc") Optional<String> dacc,
			@RequestParam("flow") String intendType, @RequestParam("loanTerm") Optional<Integer> dppMonths,
			@RequestParam("netaceLocationCode") Optional<String> depletionLocationCode,
			@RequestParam("depletionType") Optional<String> depletionType,
			@RequestParam("sddOnSelectedAtPdp") Optional<String> sddZipCode,
			@RequestParam("preBackOrderDate") Optional<String> preBackOrderDate,
			@RequestParam("preBackOrderDisplayType") Optional<String> preBackOrderDisplayType,
			@RequestParam("promoIntent") Optional<String> promoIntent,
			@RequestParam("selectedPromoId") Optional<String> selectedPromoId,
			@RequestParam("e911AddressReqd") Optional<String> e911AddressReqd,
			@RequestParam("numbershareCapable") Optional<String> numbershareCapable,
			@RequestParam("deviceCategory") Optional<String> deviceCategory,
			@RequestParam("deviceFilterType") Optional<String> deviceFilterType,
			@RequestParam("isHumDevice") Optional<String> isHumDevice,
			@RequestParam("hostName") Optional<String> hostName,
			@RequestParam("tradeInDeviceBrand") Optional<String> tradeInDeviceBrand,
			@RequestParam("tradeInDeviceModal") Optional<String> tradeInDeviceModel,
			@RequestParam("aemOfferIds") Optional<String> aemOfferIds,
			@RequestParam("noRedirect") Optional<String> noRedirect,
			@RequestParam("selectedSedOfferId") Optional<String> selectedSedOfferId,
		 	@RequestParam("isStrategicOffer") Optional<Boolean> isStrategicOffer,
			@RequestParam("restricted") Optional<String> restricted,
			@RequestParam("isCommonPDP") Optional<Boolean> isCommonPDP,
			@RequestParam("isTradeInIntentSelected") Optional<Boolean> isTradeInIntentSelected,
			@RequestParam("isKeepingExistingEqProtection") Optional<Boolean> isKeepingExistingEqProtection,
			@RequestParam("purchasePath") Optional<String> purchasePath,
			@RequestParam("fromFreePhoneQV") Optional<Boolean> fromFreePhoneQV,
		 	@RequestParam("tradeinMarketingId") Optional<String> tradeinMarketingId,
		 	@RequestParam("mhash") Optional<String> mhash,
            @RequestParam("isDfoSelected") Optional<Boolean> isDfoSelected,
			@RequestParam("dfoTerms") Optional<String> dfoTerms,
			@RequestParam("channelId") Optional<String> channelIdReq)
			throws UnsupportedEncodingException, SignatureException {
		System.setProperty(CartConstants.ENDPOINT, "add-step");
		String sso_jwt = httpHeader.getHeaders().getFirst(CartConstants.SSO_JWT_LOWERCASE) != null
				? httpHeader.getHeaders().getFirst(CartConstants.SSO_JWT_LOWERCASE)
				: httpHeader.getHeaders().getFirst(CartConstants.SSO_JWT_PASCALCASE) != null ? httpHeader.getHeaders().getFirst(CartConstants.SSO_JWT_PASCALCASE)
						: httpHeader.getHeaders().getFirst(CartConstants.SSO_JWT_UPPERCASE) != null
								? httpHeader.getHeaders().getFirst(CartConstants.SSO_JWT_UPPERCASE)
								: "";
		String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
				? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
				: "";

		if (StringUtilities.isEmptyOrNull(channelId) && httpHeader.getCookies().containsKey(CartConstants.CHANNEL_ID)) {
			HttpCookie cookiesChannelId = httpHeader.getCookies().getFirst(CartConstants.CHANNEL_ID);
			channelId = cookiesChannelId != null ? cookiesChannelId.getValue() : "";
			logger.info("ChannelId from Cookie : {}", channelId);
		} else if (StringUtilities.isEmptyOrNull(channelId) && channelIdReq.isPresent()) {
			channelId = channelIdReq.get();
			logger.info("ChannelId from Query Param : {}", channelId);
		} else if (StringUtilities.isEmptyOrNull(channelId)) {
			channelId = CartConstants.VZW_DOTCOM;
			logger.info("ChannelId from constant : {}", channelId);
		}

		if ("VZW-DOTCOM-TAB".equalsIgnoreCase(channelId)) {
			logger.info("Updating channelId to VZW-DOTCOM");
			httpResponse.getHeaders().add(CartConstants.CHANNEL_ID, CartConstants.VZW_DOTCOM);
		}
		SsoJwtDTO jwt = new SsoJwtDTO();
		jwt.setVzwAccountNumber("");
		jwt.setMobile("");
		SsoJwtDTO JwtDto = tokenProcessor.decodeSSOJWTToken(sso_jwt) != null ? tokenProcessor.decodeSSOJWTToken(sso_jwt)
				: jwt;

		HttpStatus httpStatus = ("true".equalsIgnoreCase(noRedirect.orElse(CartConstants.FALSE)) && httpHeader.getHeaders().containsKey("Accept")
				&& MediaType.APPLICATION_JSON_VALUE.equalsIgnoreCase(httpHeader.getHeaders().getFirst("Accept"))) ? HttpStatus.OK : HttpStatus.FOUND;
		return cartUtil.validateAccessUser(JwtDto, channelId)
				.flatMap(flag ->
			 helper
				.getRequestDetails(intendType, deviceId, contractTerm, dppMonths, dacc, depletionLocationCode,
						depletionType, sddZipCode, preBackOrderDate, preBackOrderDisplayType, promoIntent,
						selectedPromoId, isHumDevice, e911AddressReqd, numbershareCapable, deviceCategory,
						deviceFilterType, deviceProdId, JwtDto.getVzwAccountNumber(), JwtDto.getMobile(),
						tradeInDeviceBrand, tradeInDeviceModel,aemOfferIds,selectedSedOfferId,isStrategicOffer,
						restricted,isCommonPDP,isTradeInIntentSelected,isKeepingExistingEqProtection,purchasePath,fromFreePhoneQV,
						tradeinMarketingId, mhash, httpHeader,isDfoSelected,dfoTerms))
				.flatMap(request -> {
					logger.debug("add-step Request: {}", request);
					Map<String, String> hMap = new HashMap<String, String>();
					Map<String, String> nextgenMap = new HashMap<String, String>();

					String regex = "verizon.com|verizonwireless.com|vzwqa1.verizonwireless.com|vzwqa2.verizonwireless.com|vzwqa3.verizonwireless.com|vzwqa4.verizonwireless.com|vzwqa5.verizonwireless.com|vzwqa6.verizonwireless.com|vzwqa7.verizonwireless.com|vzwqa8.verizonwireless.com";
					Pattern verizonPattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
					// origin host going to verizon.com x-forwarded-host is verizonwireless x-host
					// is verizon
					String url = formatUrl(hostName, verizonPattern, httpHeader);

					logger.debug(CartConstants.DIGITAL_URL + ": {}", url);
					String baseUrl = CartConstants.HTTPS + "://" + url + "/sales/digital/";
					String nextgenBaseUrl = CartConstants.HTTPS + "://" + url + "/sales/nextgen/";
					logger.debug("baseurl: {}", baseUrl);
					hMap.put("ONECLICKCHECKOUT", baseUrl + env.getProperty("expressCheckout") + "?" + CartConstants.FLOW + "=" + intendType);
					hMap.put("PROMOHUB",
							baseUrl + env.getProperty("expressCheckout") + "?promoEnable=MULTI&flow=" + intendType);
					hMap.put("CHECKOUT", baseUrl + env.getProperty("checkout") + "?" + CartConstants.FLOW + "=" + intendType);
					hMap.put("PASTDUE", baseUrl + env.getProperty("pastDue"));
					hMap.put("PASTDUEBALANCE", baseUrl + env.getProperty("pastDue"));
					hMap.put("DPPSUMMARY", baseUrl + env.getProperty("dppSummary") + "?mtnFlow=G&flow=" + intendType);
					hMap.put("TWOYEARUPGRADE",
							baseUrl + env.getProperty("twoYearUpgrade") + "?mtnFlow=G&flow=" + intendType);
					hMap.put("DEVICECONFIGURATOR", baseUrl + env.getProperty("protection") + "?" + CartConstants.FLOW + "=" + intendType);
					hMap.put("SHOPPINGCART", baseUrl + env.getProperty("cart") + "?" + CartConstants.FLOW + "=" + intendType);
					hMap.put("NUMBERSHAREACTIVATION",
							baseUrl + env.getProperty("numbershare") + "?" + CartConstants.SOR_ID + "=" + deviceId + "&" + CartConstants.FLOW + "=" + intendType);
					hMap.put("HUMCONFIG",
							baseUrl + env.getProperty("humConfig") + "?" + CartConstants.SOR_ID + "=" + deviceId + "&" + CartConstants.FLOW + "=" + intendType);
					hMap.put("MTNSelectionPage",
							baseUrl + env.getProperty("mdnSelection") + "?mtnFlow=G" + "&" + CartConstants.FLOW + "=" + intendType);
					hMap.put("CCOD_DETAILS", baseUrl + env.getProperty("creditCheck") + "?" + CartConstants.FLOW + "=" + intendType);
					hMap.put("CCOD", baseUrl + env.getProperty("creditCheck") + "?" + CartConstants.FLOW + "=" + intendType);
					hMap.put("PendingOrder", baseUrl + env.getProperty("pendingOrder") + "?" + CartConstants.FLOW + "=" + intendType);
					hMap.put("AccessoryInterestial", baseUrl + env.getProperty("accessoryInterestial"));
					//Adding missing URL found as part of PRODDEF-31264 -- START
					hMap.put("CASHONLY_IND", baseUrl + env.getProperty("cashOnlyInd"));
					//END
					hMap.put("MyOfferAALPromoIntercept", baseUrl + env.getProperty("myOfferAALPromoIntercept"));
					hMap.put("PromoBundleBuilder", baseUrl + env.getProperty("promobundlebuilder"));
					nextgenMap.put("MTNSelectionPage",
							nextgenBaseUrl + env.getProperty("nextgenMdnSelection") + "?mtnFlow=G" + "&" + CartConstants.FLOW + "=" + intendType);
					nextgenMap.put("PASTDUE", nextgenBaseUrl + env.getProperty("nextgenPastDue"));
					nextgenMap.put("COLLECTIONS_IND", nextgenBaseUrl + env.getProperty("nextgenCollectionInd"));
					//Adding missing URL found as part of PRODDEF-31264 -- START
					nextgenMap.put("CONCESSION_ACCOUNT", nextgenBaseUrl + env.getProperty("nextgenConcessionInd"));
					nextgenMap.put("CASHONLY_IND", nextgenBaseUrl + env.getProperty("nextgenCashOnlyInd"));
					nextgenMap.put("FRAUD_INDICATOR_X", nextgenBaseUrl + env.getProperty("nextgenFraudXInd"));
					nextgenMap.put("FRAUD_INDICATOR_Y", nextgenBaseUrl + env.getProperty("nextgenFraudYInd"));
					nextgenMap.put("FRAUD_INDICATOR_S", nextgenBaseUrl + env.getProperty("nextgenFraudSInd"));
					nextgenMap.put("FRAUD_INDICATOR_Z", nextgenBaseUrl + env.getProperty("nextgenFraudZInd"));
					nextgenMap.put("FRAUD_INDICATOR_V", nextgenBaseUrl + env.getProperty("nextgenFraudVInd"));
					nextgenMap.put("ACCT_LINE_LIMIT", nextgenBaseUrl + env.getProperty("nextgenThresholdInd"));
					nextgenMap.put("OVERTHRESHOLD_IND", nextgenBaseUrl + env.getProperty("nextgenThresholdInd"));
					nextgenMap.put("DEVICE_CAP", nextgenBaseUrl + env.getProperty("nextgenThresholdInd"));
					//END
					nextgenMap.put("PAST_DUE_BALANCE", nextgenBaseUrl + env.getProperty("nextgenPastDue"));
					nextgenMap.put("PASTDUEBALANCE", nextgenBaseUrl + env.getProperty("nextgenPastDue"));
					nextgenMap.put("PENDINGORDER", nextgenBaseUrl + env.getProperty("nextgenPendingOrder"));
					nextgenMap.put("OFFERINTERSTITIAL", nextgenBaseUrl + env.getProperty("nextgenOfferInterstitial") + "?" + CartConstants.LINE + "=");
					nextgenMap.put("DEVICECONFIGURATOR", nextgenBaseUrl + env.getProperty("nextgenProtection") + "?" + CartConstants.MTN + "=");
					nextgenMap.put("ASSIGNNUMBERS", nextgenBaseUrl + env.getProperty("nextgenNumberselection") + "?" + CartConstants.MTN + "=");
					nextgenMap.put("NUMBERSHAREACTIVATION", nextgenBaseUrl + env.getProperty("nextgenNumbershare") + "?" + CartConstants.MTN + "=");
					nextgenMap.put("ONECLICK", nextgenBaseUrl + env.getProperty("oneclick"));
					System.setProperty(CartConstants.REDIRECT_URI, nextgenBaseUrl + CartConstants.GENERIC_ERROR_ADD_STEP_REDIRECT_URL
							+ "?" + CartConstants.PAGE_NAME_KEY + "=" + CartConstants.CART_FOR_URL);
					if (isHumDevice.isPresent() && "true".equalsIgnoreCase(isHumDevice.get())) {
						String humUrl = baseUrl + env.getProperty("humConfig") + "?" + CartConstants.SOR_ID + "=" + deviceId + "&" + CartConstants.FLOW + "="
								+ intendType;
						logger.debug("humUrl: {}", humUrl);
						Matcher humMatcher = verizonPattern.matcher(humUrl);
						if (humMatcher.find()) {
							httpResponse.getHeaders().add(CartConstants.LOCATION, removeCarriageReturnAndLineFeedCharacters(humUrl));
						} else {
							throw new IllegalArgumentException();
						}
						logger.debug("humUrl location: {}", httpResponse.getHeaders().get(CartConstants.LOCATION));
						return Mono.just(ResponseEntity.status(httpStatus).body(new GenericResponse()));
					}

					if(deviceCategory.isPresent() && CartConstants.SMARTWATCH.equalsIgnoreCase(deviceCategory.get()) && StringUtilities.isNotEmptyOrNull(JwtDto.getVzwRoles())
							&& CartConstants.ACCOUNT_MEMBER_ROLES.contains(JwtDto.getVzwRoles())){
						String errorUrl = baseUrl + env.getProperty(CartConstants.PAUSE_RESUME_ERROR);
						Matcher errorMatcher = verizonPattern.matcher(errorUrl);
						if (errorMatcher.find()) {
							httpResponse.getHeaders().add(CartConstants.LOCATION, removeCarriageReturnAndLineFeedCharacters(errorUrl));
							httpResponse.setStatusCode(httpStatus);
							System.setProperty(CartConstants.REDIRECT_URI, errorUrl);
						} else {
							throw new IllegalArgumentException();
						}
						return Mono.just(ResponseEntity.status(httpStatus).body(new GenericResponse()));
					}
					Mono<Boolean> fFlagMono = featureFlagHelper.fetchFiosLoginPDPPearlFFlagStatus();
					Mono<AddDeviceUIResponse> addDeviceRespMono = accDevHelper.addDevice(request,httpResponse);
					return Mono.zip(fFlagMono, addDeviceRespMono).map(zipResp -> {
						Boolean fFlag = zipResp.getT1();
						AddDeviceUIResponse resp = zipResp.getT2();
						String processingMtn = request.getMtn();
						Boolean expressCheckout = Boolean.FALSE;
						ErrorResponse errors2 = null;
						if (resp.getErrors() != null) {
							errors2 = CartPegaResponseErrorsUtil.handleAddDeviceResponseErrors(resp);
							String errorUrl = nextgenBaseUrl + CartConstants.GENERIC_ERROR_ADD_STEP_REDIRECT_URL
									+ "?" + CartConstants.PAGE_NAME_KEY + "=" + CartConstants.CART_FOR_URL;
							for (CartError error : errors2.getErrors()) {
								if (StringUtilities.isNotEmptyOrNull(error.getId())
										&& CartConstants.FLORIDA_RINGBELL_EXCEPTION.equalsIgnoreCase(error.getId())) {
									errorUrl = errorUrl + "?" + CartConstants.TYPE + "=" + error.getId();
								} else if (StringUtilities.isNotEmptyOrNull(error.getId())
										&& (CartConstants.EPP_RESTRICTIONS.equalsIgnoreCase(error.getId()) || CartConstants.EPP_RESTRICTIONS2.equalsIgnoreCase(error.getId()))) {
									errorUrl = errorUrl + "?" + CartConstants.TYPE + "=" + error.getId();
								} else if (StringUtilities.isNotEmptyOrNull(error.getId())
										&& CartConstants.ACCOUNT_CAP_EXCEEDED.equalsIgnoreCase(error.getId())) {
									errorUrl = errorUrl + "?" + CartConstants.TYPE + "=" + error.getId();
								} else if (fFlag && StringUtilities.isNotEmptyOrNull(error.getId())
										&& CartConstants.SHOPPING_TRIAL_CONVERSION_BUSINESS_EXCEPTION_ID.equals(error.getId()) && CartConstants.SHOPPING_TRIAL_CONVERSION_BUSINESS_EXCEPTION.equalsIgnoreCase(error.getName())) {
									errorUrl = nextgenBaseUrl + CartConstants.DVM_ERROR_URL + "?" + "name="+ CartConstants.SHOPPING_TRIAL_CONVERSION_BUSINESS_EXCEPTION +"&"+CartConstants.LINE_ACTIVITY_TYPE+"="+intendType;
									logger.error("addStep() redirecting to dvm error page: "+errorUrl);
								}
							}
							Matcher errorMatcher = verizonPattern.matcher(errorUrl);
							if (errorMatcher.find()) {
								httpResponse.getHeaders().add(CartConstants.LOCATION, removeCarriageReturnAndLineFeedCharacters(errorUrl));
								httpResponse.setStatusCode(httpStatus);
								System.setProperty(CartConstants.REDIRECT_URI, errorUrl);
								logger.debug(CartConstants.REDIRECT_URI_LOWERCASE + ": {}", httpResponse.getHeaders().get(CartConstants.LOCATION));
							} else {
								throw new IllegalArgumentException();
							}
						} else {
							logger.info(
									"addDevice returned success from Pega, proceeding with write to redis. fn= add-step");
							helper.addStepFlowNameUpdate(intendType);
							updateECSubFlowForNextgenSales(resp, intendType);
							CartRedisData rr = new CartRedisData();
							if (request.getCartInfo().getIntendType() != null)
								rr.setIntendType(request.getCartInfo().getIntendType());
							if (resp.getServiceBody() != null) {
								if (resp.getServiceBody().getServiceResponse().getContext() != null) {
									rr.setCaseId(resp.getServiceBody().getServiceResponse().getContext().getCaseId());
									if (resp.getServiceBody().getServiceResponse().getContext().getCartInfo() != null) {
										CartServiceCartInfo cartInfo = resp.getServiceBody().getServiceResponse()
												.getContext().getCartInfo();
										if (null != cartInfo.getOrderRestrictions()
												&& CollectionUtilities.isNotEmptyOrNull(cartInfo.getOrderRestrictions()
														.getAccountLevelChangeEligibility())) {
											for (AccountLevelChangeEligibility change : cartInfo.getOrderRestrictions()
													.getAccountLevelChangeEligibility()) {
												if (StringUtilities.isNotEmptyOrNull(change.getReasonCode())
														&& orderRestrictionCodes.contains(change.getReasonCode())) {
													String errorUrl = "";
													if(StringUtilities.isNotEmptyOrNull(change.getReasonCode())
															&& CartConstants.PAST_DUE_BALANCE.equalsIgnoreCase(change.getReasonCode())) {
														errorUrl = baseUrl + CartConstants.PASTDUEBALANCE;
													} else {
														errorUrl = nextgenBaseUrl + CartConstants.GENERIC_ERROR_ADD_STEP_REDIRECT_URL
																+ "?" + CartConstants.PAGE_NAME_KEY + "=" + CartConstants.CART_FOR_URL;
													}
													return getGenericResponse(httpResponse, httpStatus, verizonPattern, resp, errorUrl);
												}
												if (featureFlagHelper.isPendingOrderRedirectionFFlagEnabled()){
													if (StringUtilities.isNotEmptyOrNull(change.getInEligibilityReasonCode())
															&& orderRestrictionCodes.contains(change.getInEligibilityReasonCode())) {
														String errorUrl = "";
														if(CartConstants.PENDINGORDER.equalsIgnoreCase(change.getInEligibilityReasonCode())) {
															errorUrl = baseUrl + CartConstants.PENDING_ORDER_URl
																	+ "?" + CartConstants.TYPE + "=" + change.getInEligibilityReasonCode();
														} else {
															errorUrl = nextgenBaseUrl + CartConstants.GENERIC_ERROR_ADD_STEP_REDIRECT_URL
																	+ "?" + CartConstants.PAGE_NAME_KEY + "=" + CartConstants.CART_FOR_URL;
														}
														return getGenericResponse(httpResponse, httpStatus, verizonPattern, resp, errorUrl);
													}
												}
											}
										}
										rr.setCartId(resp.getServiceBody().getServiceResponse().getContext()
												.getCartInfo().getCartId());
									}
									if (resp.getServiceBody().getServiceResponse().getContext().getCartInfo() != null) {
										Line[] respLines = resp.getServiceBody().getServiceResponse().getContext()
												.getCartInfo().getLines();

										if (null != respLines && respLines.length > 0
												&& StringUtilities.isNotEmptyOrNull(respLines[0].getMtn())) {
											rr.setProcessingMTN(respLines[0].getMtn());
										}
										if (null != resp.getServiceBody().getServiceResponse().getContext()
												.getCartInfo().getExpressCheckout()) {
											expressCheckout = resp.getServiceBody().getServiceResponse().getContext()
													.getCartInfo().getExpressCheckout();
										}
									}
									setExistingCaseFlag(resp, rr);

									if (StringUtilities.isNotEmptyOrNull(deviceId))
										rr.setDeviceSorIdForRecommendations(deviceId);
									else if (CollectionUtilities.isNotEmptyOrNull(request.getData().getLines())
											&& null != request.getData().getLines().get(0).getDevice() && StringUtilities
											.isNotEmptyOrNull(request.getData().getLines().get(0).getDevice().getId()))
									rr.setDeviceSorIdForRecommendations(request.getData().getLines().get(0).getDevice().getId());

									if (resp.getServiceBody().getServiceResponse().getContext()
											.getShowAALPromoIntercept() != null)
										rr.setShowAALPromoIntercept(resp.getServiceBody().getServiceResponse()
												.getContext().getShowAALPromoIntercept());
									if (resp.getServiceBody().getServiceResponse().getContext()
											.getContextInfo() != null) {
										CartServiceContextInfo contextInfo = resp.getServiceBody().getServiceResponse()
												.getContext().getContextInfo();
										if (contextInfo.getProcessStep() != null) {
											String getUri = "";
											if (StringUtilities.isNotEmptyOrNull(rr.getProcessingMTN()))
												hMap.put("PortIn",
														baseUrl + env.getProperty("portIn") + "?mtn="
																+ rr.getProcessingMTN() + "&expresscheckout="
																+ expressCheckout);
											else
												hMap.put("PortIn", baseUrl + env.getProperty("portIn") + "?mtn="
														+ processingMtn + "&expresscheckout=" + expressCheckout);
											if(CartConstants.NEXTGEN_EC.equalsIgnoreCase(contextInfo.getCradleFlowJourney())){
												getUri = nextgenMap.entrySet().stream().filter(
																map -> contextInfo.getProcessStep().equalsIgnoreCase(map.getKey()))
														.map(map -> map.getValue()).collect(Collectors.joining());
												String mtnLine = "";
												if(!orderRestrictionCodes.contains(contextInfo.getProcessStep()) &&
														StringUtils.equalsIgnoreCase("AAL",request.getCartInfo().getIntendType())){
													mtnLine = "newLine1"; // default setting to newLine1 for AAL flow
												}
												if (resp.getServiceBody().getServiceResponse().getContext().getCartInfo() != null &&
														resp.getServiceBody().getServiceResponse().getContext().getCartInfo().getLines() != null) {
													Line[] lines = resp.getServiceBody().getServiceResponse().getContext().getCartInfo().getLines();
													if (lines.length > 0 && StringUtilities.isNotEmptyOrNull(lines[0].getMtn())) {
														mtnLine = lines[0].getMtn();
													}
												}
												if (!contextInfo.getProcessStep().equalsIgnoreCase("MTNSelectionPage")) {
													// updating the URL with mtn line number
													getUri = getUri + mtnLine;
													if ((contextInfo.getProcessStep().equalsIgnoreCase("NEWRECOMMENDEDPLANSELECTION"))
															&& contextInfo.getCartServiceAvailablePaths() != null) {
														getUri = getUriForPlanSelection(nextgenBaseUrl, contextInfo, mtnLine);
													}
													if (contextInfo.getProcessStep().equalsIgnoreCase("DEVICECONFIGURATOR")){
														getUri = getUri + "&isMultiline=false";
													}
												}
											}else{
											getUri = hMap.entrySet().stream().filter(
													map -> contextInfo.getProcessStep().equalsIgnoreCase(map.getKey()))
													.map(map -> map.getValue()).collect(Collectors.joining());
											}
											if (StringUtilities.isEmptyOrNull(getUri))
												getUri = nextgenBaseUrl + CartConstants.GENERIC_ERROR_ADD_STEP_REDIRECT_URL
														+ "?" + CartConstants.PAGE_NAME_KEY + "=" + CartConstants.CART_FOR_URL;
											Matcher getUriMatcher = verizonPattern.matcher(getUri);
											if (getUriMatcher.find()) {
												httpResponse.getHeaders().add(CartConstants.LOCATION, removeCarriageReturnAndLineFeedCharacters(getUri));
												httpResponse.setStatusCode(httpStatus);
											} else {
												throw new IllegalArgumentException();
											}
										}
									}

								} else {
									String errorUrl = nextgenBaseUrl + CartConstants.GENERIC_ERROR_ADD_STEP_REDIRECT_URL
											+ "?" + CartConstants.PAGE_NAME_KEY + "=" + CartConstants.CART_FOR_URL;
									Matcher errorMatcher = verizonPattern.matcher(errorUrl);
									if (errorMatcher.find()) {
										httpResponse.getHeaders().add(CartConstants.LOCATION, removeCarriageReturnAndLineFeedCharacters(errorUrl));
										System.setProperty(CartConstants.REDIRECT_URI, errorUrl);
										logger.debug( CartConstants.REDIRECT_URI_LOWERCASE + ": {}", httpResponse.getHeaders().get(CartConstants.LOCATION));
									} else {
										throw new IllegalArgumentException();
									}
								}
							}
							httpResponse.getHeaders().add(CartConstants.CHANNEL_ID, CartConstants.VZW_DOTCOM);
							rr.setLines(request.getData().getLines());
							rr.setDeviceCartInfo(request.getCartInfo());
							if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getAccountNumber()))
								rr.setAccountNumber(request.getCartInfo().getAccountNumber());
							if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCartCreator()))
								rr.setCartCreator(request.getCartInfo().getCartCreator());

							if (StringUtilities.isNotEmptyOrNull(deviceProdId))
								rr.setDeviceProdId(deviceProdId);
							if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessingMTN()))
								rr.setProcessingMTN(request.getCartInfo().getProcessingMTN());
							if (CollectionUtilities.isNotEmptyOrNull(request.getData().getLines())
									&& null != request.getData().getLines().get(0).getDevice() && StringUtilities
											.isNotEmptyOrNull(request.getData().getLines().get(0).getDevice().getId()))
								rr.setDeviceSorId(request.getData().getLines().get(0).getDevice().getId());

							redisHelper.upsertDataIntoRedisAsString(rr, CartConstants.DEVICE)
									.subscribeOn(Schedulers.parallel()).subscribe(redisData -> {
										logger.info("add-step data upserted: cartId {} and caseId {}",
												redisData.getCartId(), redisData.getCaseId());
										try {
											logger.info("Inside DL update");
											if (intendType != null) {
												if (CartConstants.BYOD.equalsIgnoreCase(intendType)
														|| CartConstants.NSE_BYOD.equalsIgnoreCase(intendType))
													dlUtilityService.updateDlData(CartConstants.ESO);
												else {
													if ((CartConstants.S_AAL.equalsIgnoreCase(intendType) ||
															CartConstants.S_EUP.equalsIgnoreCase(intendType))) {
														dlUtilityService.updateDlData(intendType);
													}
												}
											}
										}

										catch (Exception e) {
											logger.error("exception while calling dlUtilityService in add-step");
										}
									}

									);
						}
						return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
								: ResponseEntity.status(httpStatus).body(resp);
					});
				});
	}

	private String getUriForPlanSelection(String nextgenBaseUrl, CartServiceContextInfo contextInfo, String mtnLine) {
		String getUri = null;
		List<String> availablePaths = contextInfo.getCartServiceAvailablePaths().stream().map(AvailablePaths::getPath).collect(Collectors.toList());
		if (availablePaths.contains("PopularPlans")) {
			getUri = nextgenBaseUrl + env.getProperty("nextgenPopularPlan") + "?" + CartConstants.SELECTED_MTN + "=" + mtnLine;
		}
		if (availablePaths.contains("PlanSelectorPage")) {
			getUri = nextgenBaseUrl + env.getProperty("nextgenPlanSelector") + "?" + CartConstants.LINE + "=" + mtnLine;
		}
		if (availablePaths.contains("CompatibleWatchPlan")) {
			getUri = nextgenBaseUrl + env.getProperty("nextgenCompatibleWatchPlan");
		}
		if (availablePaths.contains("NewRecommendedPlanSelection")) {
			getUri = nextgenBaseUrl + env.getProperty("nextgenPlanOverview");
		}
		if (featureFlagHelper.isPlanSelectionProgressivePlansFFlagEnabled() && availablePaths.contains("ProgressivePlans")) {
			StringBuilder uriBuilder = new StringBuilder(nextgenBaseUrl);
			uriBuilder.append(env.getProperty("nextgenProgressivePlans"))
					.append("?")
					.append(CartConstants.SELECTED_MTN)
					.append("=")
					.append(mtnLine);
			getUri = uriBuilder.toString();
		}
		return getUri;
	}

	private void setExistingCaseFlag(AddDeviceUIResponse resp, CartRedisData rr) {
		if(null!= resp.getServiceBody().getServiceResponse().getContext().getContextInfo() &&
				null != resp.getServiceBody().getServiceResponse().getContext().getCustomerInfo()) {
			if(StringUtilities.isNotEmptyOrNull(resp.getServiceBody().getServiceResponse().getContext().getCustomerInfo().getExistingCase())){
				rr.setExistingCase(resp.getServiceBody().getServiceResponse().getContext().getCustomerInfo().getExistingCase());
			}else {
				rr.setExistingCase(CartConstants.FALSE);
			}
		}else {
			rr.setExistingCase(CartConstants.FALSE);
		}
	}

	private ResponseEntity<GenericResponse> getGenericResponse(ServerHttpResponse httpResponse,
																	   HttpStatus httpStatus, Pattern verizonPattern,
																	   AddDeviceUIResponse resp, String errorUrl) {
		Matcher errorMatcher = verizonPattern.matcher(errorUrl);
		if (errorMatcher.find()) {
			httpResponse.getHeaders().add(CartConstants.LOCATION, removeCarriageReturnAndLineFeedCharacters(errorUrl));
			httpResponse.setStatusCode(httpStatus);
			System.setProperty(CartConstants.REDIRECT_URI, errorUrl);
			logger.debug(CartConstants.REDIRECT_URI_LOWERCASE + ": {}",
					httpResponse.getHeaders().get(CartConstants.LOCATION));
			return ResponseEntity.status(httpStatus).body(resp);
		} else {
			throw new IllegalArgumentException();
		}
	}

	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @param isHumDevice
	 * @param hostName
	 * @return genericResponse
	 * @throws UnsupportedEncodingException
	 * @throws SignatureException
	 */
	@PostMapping("/mvoNsaThrottle")
	public Mono<ResponseEntity<GenericResponse>> mvoNsaThrottle(ServerHttpRequest httpHeader,
			ServerHttpResponse httpResponse, @Valid @RequestBody MvoRequest request,
			@RequestParam("isHumDevice") Optional<String> isHumDevice,
			@RequestParam("hostName") Optional<String> hostName)
			throws UnsupportedEncodingException, SignatureException {
		System.setProperty(CartConstants.ENDPOINT, "mvoNsaThrottle");
		String sso_jwt = httpHeader.getHeaders().getFirst(CartConstants.SSO_JWT_LOWERCASE) != null
				? httpHeader.getHeaders().getFirst(CartConstants.SSO_JWT_LOWERCASE)
				: httpHeader.getHeaders().getFirst(CartConstants.SSO_JWT_PASCALCASE) != null ? httpHeader.getHeaders().getFirst(CartConstants.SSO_JWT_PASCALCASE)
						: httpHeader.getHeaders().getFirst(CartConstants.SSO_JWT_UPPERCASE) != null
								? httpHeader.getHeaders().getFirst(CartConstants.SSO_JWT_UPPERCASE)
								: "";
		String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
				? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
				: "";
		if (channelId.equalsIgnoreCase("VZW-DOTCOM-TAB")) {
			logger.info("Updating channelId to VZW-DOTCOM");
			httpHeader.getHeaders().remove(CartConstants.CHANNEL_ID);
			httpHeader.getHeaders().add(CartConstants.CHANNEL_ID, CartConstants.VZW_DOTCOM);
		}
		SsoJwtDTO jwt = new SsoJwtDTO();
		jwt.setVzwAccountNumber("");
		jwt.setMobile("");
		SsoJwtDTO JwtDto = tokenProcessor.decodeSSOJWTToken(sso_jwt) != null ? tokenProcessor.decodeSSOJWTToken(sso_jwt)
				: jwt;

		logger.debug("mvoNsaThrottle Request: {}", request);
		Map<String, String> hMap = new HashMap<String, String>();

		String regex = "verizon.com|verizonwireless.com|vzwqa1.verizonwireless.com|vzwqa2.verizonwireless.com|vzwqa3.verizonwireless.com|vzwqa4.verizonwireless.com|vzwqa5.verizonwireless.com|vzwqa6.verizonwireless.com|vzwqa7.verizonwireless.com|vzwqa8.verizonwireless.com";
		Pattern verizonPattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
		// origin host going to verizon.com x-forwarded-host is verizonwireless x-host
		// is verizon
		String url = formatUrl(hostName, verizonPattern, httpHeader);

		String startPageName = StringUtilities.isNotEmptyOrNull(request.getStartPageName()) ? request.getStartPageName()
				: "";
		String flow = "EUP";
		if (StringUtilities.isEmptyOrNull(startPageName) && null != request.getMyOffer()
				&& null != request.getMyOffer().getServiceOffer()) {
			ServiceOffer serviceOffer = request.getMyOffer().getServiceOffer();
			if ("AAL".equalsIgnoreCase(serviceOffer.getType())) {
				startPageName = "AAL_OFFER";
				flow = "AAL";
			} else if ("EUP".equalsIgnoreCase(serviceOffer.getType()) || "UPG".equalsIgnoreCase(serviceOffer.getType()))
				startPageName = "EUP_OFFER";
			else
				startPageName = "ENC_MTN";
		}
		Map<String, String> offerIdDeviceTypeMapping = new HashMap<String, String>();
		offerIdDeviceTypeMapping.put("NS_1399", CartConstants.SMARTWATCHES);
		offerIdDeviceTypeMapping.put("NS_1400", CartConstants.SMARTWATCHES);
		offerIdDeviceTypeMapping.put("PR_1406", "BASICPHONES");
		offerIdDeviceTypeMapping.put("NS_1401", CartConstants.TABLETS);
		offerIdDeviceTypeMapping.put("NS_1402", CartConstants.TABLETS);
		offerIdDeviceTypeMapping.put("NS_1404", CartConstants.TABLETS);
		offerIdDeviceTypeMapping.put("NS_1403", "CONNECTEDDEVICES");

		logger.debug( CartConstants.DIGITAL_URL + ": {}", url);
		String baseUrl = CartConstants.HTTPS + "://" + url;
		logger.debug("baseurl: {}", baseUrl);

		hMap.put("SMARTPHONES", baseUrl + env.getProperty("mvoSmartphones"));
		hMap.put(CartConstants.SMARTWATCHES, baseUrl + env.getProperty("mvoSmartWatches"));
		hMap.put("CONNECTEDDEVICES", baseUrl + env.getProperty("mvoConnectedDevices"));
		hMap.put("BASICPHONES", baseUrl + env.getProperty("mvoBasicPhones"));
		hMap.put(CartConstants.TABLETS, baseUrl + env.getProperty("mvoTablets"));
		hMap.put("MTNSelectionPage", baseUrl + env.getProperty("mvoMdnSelection") + "?mtnFlow=M" + "&customerId="
				+ JwtDto.getVzwAccountNumber() + "&mtn=" + JwtDto.getMobile() + "&" + CartConstants.FLOW + "=" + flow);

		return redisHelper2.upsertMvoDataIntoRedis(request).flatMap(resp -> {
			if (StringUtilities.isEmptyOrNull(request.getOfferId())) {
				request.setOfferId("");
			}
			String getUri = hMap.entrySet().stream().filter(map -> "SMARTPHONES".equalsIgnoreCase(map.getKey()))
					.map(map -> map.getValue()).collect(Collectors.joining());
			getUri = hMap.entrySet().stream()
					.filter(map -> offerIdDeviceTypeMapping.entrySet().stream()
							.filter(tmap -> request.getOfferId().equalsIgnoreCase(tmap.getKey()))
							.map(tmap -> tmap.getValue()).collect(Collectors.joining()).equalsIgnoreCase(map.getKey()))
					.map(map -> map.getValue()).collect(Collectors.joining());
			Matcher getUriMatcher = verizonPattern.matcher(getUri);
			if (getUriMatcher.find()) {
				httpResponse.getHeaders().add(CartConstants.LOCATION, removeCarriageReturnAndLineFeedCharacters(getUri));
				httpResponse.setStatusCode(HttpStatus.FOUND);
			} else {
				throw new IllegalArgumentException();
			}

			GenericResponse genResp = new GenericResponse();
			genResp.setGenericHeader(CartConstants.STATUS_SUCCESS);
			return Mono.just(ResponseEntity.status(HttpStatus.FOUND).body(genResp));
		});

	}

	@PostMapping("/rpsApplePayload")
	public Mono<ResponseEntity<GenericResponse>> rpsApplePayload(ServerHttpRequest httpHeader,
														ServerHttpResponse httpResponse, @Valid @RequestBody RPSApplePayloadUIRequest request,
														@RequestParam(required = false) String encryptedPayloadReq) throws UnsupportedEncodingException, SignatureException {

		System.setProperty(CartConstants.ENDPOINT, "rpsApplePayload");
		logger.debug("rpsApplePayload Request: {}", request);
		//Start Redirection part
		String encryptedPayload = null;
		String url = "";
		String baseUrl = "";
		String errorUrl = "";

            SsoJwtDTO jwt = new SsoJwtDTO();
            jwt.setVzwAccountNumber("");
            jwt.setMobile("");
            String regex = CartConstants.HOST_NAMES_REGEX;
            Pattern verizonPattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
            // origin host going to verizon.com x-forwarded-host is verizonwireless x-host

		encryptedPayload = StringUtilities.isNotEmptyOrNull(request.getEncryptedPayload()) ? request.getEncryptedPayload() : encryptedPayloadReq;
			List<String> xhost = httpHeader.getHeaders().get("X-Host");
			List<String> xForwardhost = httpHeader.getHeaders().get("X-Forwarded-Host");
            if (httpHeader.getHeaders() != null && xhost != null && xhost.size() > 0) {
                Matcher verizonMatcher = verizonPattern.matcher(xhost.toString()
                        .replaceAll("\\[", "").replaceAll("\\]", "").replaceAll("\"", ""));
                if (verizonMatcher.find()) {
                    url = xhost.toString().replaceAll("\\[", "").replaceAll("\\]", "")
                            .replaceAll("\"", "");
                } else {
                    throw new IllegalArgumentException();
                }

            } else if (httpHeader.getHeaders() != null && xForwardhost != null && xForwardhost.size() > 0) {
                Matcher verizonMatcher = verizonPattern.matcher(xForwardhost.toString()
                        .replaceAll("\\[", "").replaceAll("\\]", "").replaceAll("\"", ""));
                if (verizonMatcher.find()) {
                    url = xForwardhost.toString().replaceAll("\\[", "")
                            .replaceAll("\\]", "").replaceAll("\"", "");
                } else {
                    throw new IllegalArgumentException();
                }

            } else {
                url = rpsHostName;

            }
		//Decrypt Logic
		String encryptedMDN = null;
		CarrierPostData carrierPostData = null;
		if (StringUtilities.isNotEmptyOrNull(encryptedPayload)) {
			AESUtil aesUtil = new AESUtil();
			RPSAES128CBCUtil rpsaes128CBCUtil = new RPSAES128CBCUtil(rpsAMaesKey, rpsIterationCount,provider);
			String rpsPayload = aesUtil.rpsDecrypt(request.getEncryptedPayload(), rpsAESKey);
			carrierPostData = rpsHelper.getCarrierPostData(request);
			encryptedMDN = rpsaes128CBCUtil.RPSAES128CBCEncrypt(carrierPostData.getPrimaryDeviceMTN());
			request = validator.convertRPSStringToObject(rpsPayload);
			request.setEncryptedPayload(encryptedPayload);
		} else {
			carrierPostData = rpsHelper.getCarrierPostData(request);
		}
		String flowPairingMode = null;
		boolean standalone = false;

		if (StringUtilities.isNotEmptyOrNull(carrierPostData.getAssociatedSubscriprion())) {
			if (CartConstants.RPS_FLOW_ASSOCIATED_SUBSCRIPTION_TWO
					.equalsIgnoreCase(carrierPostData.getAssociatedSubscriprion())) {
				flowPairingMode = CartConstants.RPS_FLOW_STANDALONE;
				standalone = true;
			} else {
				flowPairingMode = CartConstants.RPS_FLOW_NUMBERSHARE;
			}
		}
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleRPSApplePayloadUIRequestErrors(request, encryptedPayloadReq);
            baseUrl = CartConstants.HTTPS + "://";
            logger.debug( CartConstants.DIGITAL_URL + ": {}", url);
            baseUrl = baseUrl + url + "/sales/digital/rpsplans.html?deviceImei=" + request.getSecondaryDeviceActive().getDeviceImei()
                    + "&standalone=" + standalone + "&pairingMode=" + flowPairingMode + "&phoneMtn=" + carrierPostData.getPrimaryDeviceMTN()
                    + "&rpsParams=" + encryptedPayload + "&realm=vzw&IDToken1=" + encryptedMDN + "&userNameOnly=true&rememberUserName=N" +
                    "&clientId=apple-watch&rememberUserNameCheckBoxExists=N";
            errorUrl = CartConstants.HTTPS + "://" + url + "/sales/digital/rpserror.html?rpsError=true";
            if (errors.getErrors() != null) {
                baseUrl = errorUrl;
            }
            
            Matcher getUriMatcher = verizonPattern.matcher(baseUrl);
            if (getUriMatcher.find()) {
                httpResponse.getHeaders().add(CartConstants.LOCATION, removeCarriageReturnAndLineFeedCharacters( baseUrl));
                httpResponse.setStatusCode(HttpStatus.FOUND);
            } else {
                throw new IllegalArgumentException();
            }

		RPSRedisData rr = formatRPSRedisData(request,encryptedPayload);
		Mono<Boolean> rpsFlowRedisData = redisHelper2.upsertRPSFlowDataIntoRedis(rr);
		return rpsFlowRedisData.flatMap(data -> {
			if (data) {
				logger.debug(httpResponse.getHeaders().get(CartConstants.LOCATION).get(0));
				GenericResponse genResp = new GenericResponse();
				genResp.setGenericHeader(CartConstants.STATUS_SUCCESS);
				return Mono.just(ResponseEntity.status(HttpStatus.FOUND).body(genResp));
			} else {
				return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new RPSFlowRedisData()));
			}
		});
	}

	public RPSRedisData formatRPSRedisData(RPSApplePayloadUIRequest request,String encryptedPayloadReq){
		RPSRedisData rpsRedisData = new RPSRedisData();
		if(StringUtilities.isNotEmptyOrNull(encryptedPayloadReq)){
			rpsRedisData.setEncryptedPayload(encryptedPayloadReq);
		}
		SecondaryDeviceActive secondaryDeviceActive = new SecondaryDeviceActive();
		rpsRedisData.setCarrierPostData(rpsHelper.getCarrierPostData(request));
		secondaryDeviceActive.setDeviceImei(request.getSecondaryDeviceActive().getDeviceImei());
		secondaryDeviceActive.setDisplayName(request.getSecondaryDeviceActive().getDisplayName());
		secondaryDeviceActive.setEid(request.getSecondaryDeviceActive().getEid());
		secondaryDeviceActive.setIccids(request.getSecondaryDeviceActive().getIccids());
		rpsRedisData.setSecondaryDeviceActive(secondaryDeviceActive);
		rpsRedisData.setTestScreen(request.isTestScreen());
		return rpsRedisData;
	}
	
	@PostMapping(path = { "getNSAThrottleList",
			"nse/getNSAThrottleList" }, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Mono<ResponseEntity<String>> getNSAThrottleList(ServerHttpRequest request, ServerHttpResponse response,
																 @RequestBody Map<String, String> cradleDataMap) {

		String[] sessionKeys = { SessionConstants.MTN_KEY, CartConstants.CHANNEL };
		if (null != cradleDataMap) {
			return redisHelper3.getMTNFromRedis(sessionKeys).flatMap(dataMap -> {
				
				if (dataMap.containsKey(SessionConstants.MTN_KEY) && null != dataMap.get(SessionConstants.MTN_KEY)) {
					cradleDataMap.put(CradleConstants.MTN, (String) dataMap.get(SessionConstants.MTN_KEY));
				}
				if (!isPageNameNGMakeAndModel(cradleDataMap) && dataMap.containsKey(CartConstants.CHANNEL) && null != dataMap.get(CartConstants.CHANNEL)) {
					logger.debug("channel from Session : {}", (String) dataMap.get(CartConstants.CHANNEL));
					cradleDataMap.put(CartConstants.CHANNEL, (String) dataMap.get(CartConstants.CHANNEL));
				}
				if(dataMap.containsKey(CartConstants.CUST_TYPE) && CartConstants.CUST_TYPE_EPP.equalsIgnoreCase(dataMap.get(CartConstants.CUST_TYPE).toString())){
					cradleDataMap.put("unifiedCustType", CartConstants.VISION_CUSTTYPE_ME);
				}
				setRegionCodeAndCatagory(request, cradleDataMap);
				Map<String, Object> finalMap = new HashMap<>();
				logger.info("cradle data map request: {}", cradleDataMap);
				return cradleAllocator.invokeReactiveCradle(request, response, cradleDataMap).flatMap(cradleResponse -> {
					try {
						JsonNode cradleOutputJsonNode = objectMapper.readTree(cradleResponse.getOutPut());
						logger.info(String.format("Value of cradleOutputJsonNode - %s" , cradleOutputJsonNode));
						if (null != cradleOutputJsonNode && null != cradleOutputJsonNode.get(Constants.THROTTLE_LIST)) {
							String throttleList = cradleOutputJsonNode.get(Constants.THROTTLE_LIST).asText();
							logger.debug("throttleList from Session : {}", throttleList);
							finalMap.put(Constants.THROTTLE_LIST, throttleList);
							String cradleFlowJourney = cradleOutputJsonNode.get(Constants.CRADLE_FLOW_JOURNEY).asText();
							finalMap.put(Constants.CRADLE_FLOW_JOURNEY, cradleFlowJourney);
							setBYODImeiFFToMap(cradleDataMap, finalMap);
							String resp;
							resp = objectMapper.writeValueAsString(finalMap);
                            populateThrottlingKibana(finalMap);
							if (StringUtilities.isEmptyOrNull(resp)) {
								return Mono.empty();
							}
							return Mono.justOrEmpty(ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(resp));
						}
					} catch (Exception e) {
						logger.error("Failed to retrieve throttle list", e);
						return Mono.empty();
					}
					return Mono.justOrEmpty(ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body("ThrottleList is Empty"));

				});
			}).switchIfEmpty(Mono.defer(() -> {
				return Mono.empty();
			})).onErrorResume(err -> {
				return Mono.empty();
			});
		}
		return Mono.empty();
	}

	private boolean isPageNameNGMakeAndModel(Map<String, String> cradleDataMap) {
		return cradleDataMap.getOrDefault(CartConstants.PAGE_NAME_KEY,CartConstants.EMPTY_STRING).equalsIgnoreCase(CartConstants.PAGE_NAME_NG_MAKE_AND_MODEL);
	}

	public void populateThrottlingKibana(Map<String, Object> resp) {

        try {
            Map<String, String> logDetailsMap = new HashMap<String, String>();
            Map<String, String> cradleMap = new HashMap<String, String>();
            if (null != resp && resp.size() > 0 && null != resp.get(CartConstants.THROTTLE_LIST)) {
                if ((Arrays.asList(new String[]{"|5GHomeP|", "|5GHome|"}).contains(resp.get(CartConstants.THROTTLE_LIST)))) {
                    logDetailsMap.put("flow", "NSA");
                    if (resp.get(CartConstants.THROTTLE_LIST) instanceof String && resp.get(CartConstants.THROTTLE_LIST).toString().equalsIgnoreCase("|5GHomeP|")) {
                        logDetailsMap.put("cradleResponse", "NSE"); }
                        else {
                        logDetailsMap.put("cradleResponse", "AAL");
                    }

                } else {
					logDetailsMap.put("flow", "BAU");
				}
            }

            cradleMap.put("cradle", JacksonMapperFactory.defaultWriter().writeValueAsString(logDetailsMap));
            LoggerUtil.addCustomPersistField(cradleMap);
        } catch (Exception e) {logger.info("Error occurred while populating kibana logs: populateThrottlingKibana method");}

    }

    private String formatUrl(Optional<String> hostName, Pattern verizonPattern, ServerHttpRequest httpHeader) {
    	String url = "";
    	String forwardedHost = "X-Forwarded-Host";
    	String host = "X-Host";
    	if (null != env.getProperty("readHostFromQueryParams")
				&& Boolean.parseBoolean(env.getProperty("readHostFromQueryParams"))
				&& hostName.isPresent()) {
			Matcher verizonMatcher = verizonPattern.matcher(hostName.get());
			if (verizonMatcher.find()) {
				url = hostName.get();
			} else {
				throw new IllegalArgumentException();
			}
		} else if (httpHeader.getHeaders().get(host)  != null) {
			List<String> headerHost = httpHeader.getHeaders().get(host);
			Matcher verizonMatcher = verizonPattern.matcher(Objects.requireNonNull(headerHost).toString()
					.replaceAll("\\[", "").replaceAll("\\]", "").replaceAll("\"", ""));
			if (verizonMatcher.find()) {
				url = headerHost.toString().replace("[", "")
						.replaceAll("\\]", "").replaceAll("\"", "");
			} else {
				throw new IllegalArgumentException();
			}
		} else if ( httpHeader.getHeaders().get(forwardedHost) != null) {
			List<String> headerForwardedHost = httpHeader.getHeaders().get(forwardedHost);
			Matcher verizonMatcher = verizonPattern.matcher(Objects.requireNonNull(headerForwardedHost)
					.toString().replaceAll("\\[", "").replaceAll("\\]", "").replaceAll("\"", ""));
			if (verizonMatcher.find()) {
				url = headerForwardedHost.toString().replace("[", "")
						.replaceAll("\\]", "").replaceAll("\"", "");
			} else {
				throw new IllegalArgumentException();
			}
		} else {
			url = httpHeader.getURI().getHost() + ":8080";
		}

		return url;
	}

	private String removeCarriageReturnAndLineFeedCharacters( String inputString){
		if( StringUtilities.isNotEmptyOrNull(inputString))
			return StringUtils.normalizeSpace(inputString.replaceAll("\\r", "").replaceAll("\\n", "").replace(";", ""));
		else
			throw new IllegalArgumentException();
	}

	public void updateECSubFlowForNextgenSales(AddDeviceUIResponse resp, String intendType) {
		try {
		if (resp != null && null != resp.getServiceBody() &&
				null != resp.getServiceBody().getServiceResponse() && null != resp.getServiceBody().getServiceResponse().getContext() &&
				null != resp.getServiceBody().getServiceResponse().getContext().getContextInfo() &&
				null != resp.getServiceBody().getServiceResponse().getContext().getContextInfo().getCradleFlowJourney()) {
			String cradleFlowJourney = resp.getServiceBody().getServiceResponse().getContext().getContextInfo().getCradleFlowJourney();
			logger.info("Update subflow in tagging for nextgen:: cradlflowjourney -> {}", cradleFlowJourney);
			if (CartConstants.NEXTGEN_EC.equalsIgnoreCase(cradleFlowJourney)) {
				dlUtilityService.upsertVZPageSubFLow(CartConstants.NEXTGEN_EC, true, "").subscribeOn(Schedulers.parallel()).subscribe();
				dlService.buildDLData(OmniBuilder.buildAddStepUserData());
			} else if ((CartConstants.AAL.equalsIgnoreCase(intendType) || CartConstants.EUP.equalsIgnoreCase(intendType))
					&& !CartConstants.NEXTGEN_EC.equalsIgnoreCase(cradleFlowJourney)) {
				dlUtilityService.upsertVZPageSubFLow(CartConstants.NEXTGEN_EC_C, true, "").subscribeOn(Schedulers.parallel()).subscribe();
			}
		}
		} catch (Exception e) {
				logger.error("exception while calling updateECSubFlowForNextgenSales in add-step");
			}
		}
	private void setRegionCodeAndCatagory(ServerHttpRequest httpRequest, Map<String, String> cradleDataMap) {
		String regionCode = getRegionCode(httpRequest) != null ? getRegionCode(httpRequest) : "";
		cradleDataMap.put(CartConstants.REGION_CODE, regionCode);
	}

	private String getRegionCode(ServerHttpRequest serverHttpRequest) {
		HttpHeaders httpHeaders = serverHttpRequest != null ? serverHttpRequest.getHeaders() : null;
		List<String> valueList = httpHeaders != null ? httpHeaders.getOrEmpty(CartConstants.X_AKAMAI_EDGESCAPE)
				: null;
		logger.info(" x-akamai-edgescape header value : {}",
				valueList != null && !valueList.isEmpty() && valueList.get(0) != null ? valueList.get(0) : "");
		if (valueList != null && !valueList.isEmpty() && valueList.get(0) != null) {
			String value = valueList.get(0);
			Map<String, String> stringMap = Arrays.stream(value.split(",")).map(s -> s.split("=", 2))
					.collect(Collectors.toMap(array -> array[0], array -> array.length > 1 ? array[1] : ""));
			return stringMap.get(CartConstants.REGION_CODE);
		}
		return "";
	}
	private void setBYODImeiFFToMap(Map<String, String> cradleDataMap, Map<String, Object> finalMap) {
		if(CartConstants.PAGENAME_ENTERDEVICEIMEI.equalsIgnoreCase(cradleDataMap.get(CartConstants.PAGE_NAME_KEY))) {
			if (featureFlagHelper.isBYODIMEIRangeFFlagEnabled()) {
				finalMap.put(CartConstants.ENABLE_IMEI_PAGE_ENHANCEMENTS, Boolean.TRUE);
			}
			if(featureFlagHelper.isBYODIMEIInstructionsFFlagEnabled()){
				finalMap.put(CartConstants.ENABLE_IMEI_INSTRUCTIONS, Boolean.TRUE);
			}
		}
	}

}
