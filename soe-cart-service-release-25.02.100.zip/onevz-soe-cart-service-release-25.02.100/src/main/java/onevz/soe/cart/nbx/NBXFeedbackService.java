package onevz.soe.cart.nbx;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.ui.requests.NBXFeedbackUIRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import onevz.soe.cart.bpm.service.CartServiceBPMServices;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.bvp.BVPLine;
import onevz.soe.cart.model.bvp.BestValueOffer;
import onevz.soe.cart.model.bvp.GetBestValuePromotions;
import onevz.soe.cart.model.nbx.DynamicAttributes;
import onevz.soe.cart.model.nbx.NBXContextInfo;
import onevz.soe.cart.model.nbx.NBXCustomerInfo;
import onevz.soe.cart.model.nbx.NBXCustomerResponse;
import onevz.soe.cart.model.nbx.NBXResponse;
import onevz.soe.cart.model.nbx.NBXService;
import onevz.soe.cart.model.nbx.NBXServiceBody;
import onevz.soe.cart.model.nbx.NBXServiceHeader;
import onevz.soe.cart.model.nbx.NBXServiceRequest;
import onevz.soe.cart.requests.NBXFeedbackRequest;
import onevz.soe.cart.responses.NBXFeedbackResponse;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import reactor.core.publisher.Mono;

@Service
public class NBXFeedbackService {

	private static final Logger logger = LoggerFactory.getLogger(NBXFeedbackService.class);

	@Autowired
	private CartServiceBPMServices bpmService;

	/**
	 * 
	 * @param request
	 * @return nbxResponse
	 */
	public Mono<NBXFeedbackResponse> nbxFeedbackCall(NBXFeedbackRequest request) {

		Mono<NBXFeedbackResponse> rtdResponse = Mono.empty();
		try {
			// pega call
			rtdResponse = bpmService.nbxFeedbackCall(request);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		return rtdResponse.flatMap(response -> {
			return Mono.just(response);
		});

	}

	/**
	 * 
	 * @param bvpLine
	 * @param accountNo
	 * @return nbxRequest
	 */
	public NBXFeedbackRequest formatNbxFeedbackRequest(BVPLine bvpLine, String accountNo,String loggedInUser) {
		GetBestValuePromotions bvpData = bvpLine.getGetBestValuePromotions();
		NBXFeedbackRequest feedbackRequest = new NBXFeedbackRequest();
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss zzz");
		df.setTimeZone(TimeZone.getTimeZone("GMT"));
		Date date = new Date();
		String timestamp =df.format(date);
		NBXService service = new NBXService();
		NBXServiceHeader serviceHeader = new NBXServiceHeader();
		serviceHeader.setClientId(bvpData.getClientId());
		serviceHeader.setClientSessionId(bvpData.getClientSessionId());
		serviceHeader.setClientTransactionId(bvpData.getClientTransactionId());
		serviceHeader.setTimestamp(timestamp);
		serviceHeader.setServiceName("NBX");
		service.setServiceHeader(serviceHeader);
		NBXServiceBody serviceBody = new NBXServiceBody();
		NBXServiceRequest serviceRequest = new NBXServiceRequest();
		NBXCustomerInfo customerInfo = new NBXCustomerInfo();
		customerInfo.setMtn(bvpLine.getMtn());
		customerInfo.setAccountNo(accountNo);
		serviceRequest.setCustomerInfo(customerInfo);
		NBXContextInfo contextInfo = new NBXContextInfo();
		contextInfo.setSessionId(bvpData.getSessionId());
		contextInfo.setCallReason("Recommendation");
		contextInfo.setCategory("Offers");
		contextInfo.setRtdSessionID(bvpData.getRtdSessionId());
		contextInfo.setSubServiceName("CaptureResponse");
		contextInfo.setAgentID(loggedInUser);
		serviceRequest.setContextInfo(contextInfo);
		NBXCustomerResponse customerResponse = new NBXCustomerResponse();
		List<NBXResponse> responseList = new ArrayList<>();
		List<NBXResponse> externalResponseList = new ArrayList<>();
		for (BestValueOffer bvo : bvpData.getBestValueOffers()) {
			NBXResponse response = new NBXResponse();
			if (bvo.getMyOffer() && StringUtilities.isNotEmptyOrNull(bvpData.getRtdRank()))
				response.setRank(bvpData.getRtdRank());
			else
				response.setRank(bvo.getRank());
			response.setPropositionId(bvo.getId());
			String endPoint = System.getProperty(CartConstants.ENDPOINT);
			if (StringUtilities.isNotEmptyOrNull(bvo.getDispositionOptionId()))
				response.setDispositionOptionId(bvo.getDispositionOptionId());
			else if ("add-device".equalsIgnoreCase(endPoint))
				response.setDispositionOptionId(CartConstants.BVP_ACCEPTED);
			else if ("remove-lines".equalsIgnoreCase(endPoint))
				response.setDispositionOptionId(CartConstants.BVP_REJECTED);
			else if ("removeOffers".equalsIgnoreCase(endPoint))
				response.setDispositionOptionId(CartConstants.BVP_REJECTED);
			else
				response.setDispositionOptionId(CartConstants.BVP_VIEW);
			response.setSoiEngagementId(bvpData.getSoiEngagementId());
			response.setTimeStamp(timestamp);
			List<DynamicAttributes> dynamicAttrList = new ArrayList<>();
			DynamicAttributes dynamicAttr = new DynamicAttributes();
			dynamicAttr.setAttrId("isRtdOffer");
			if (bvo.getMyOffer())
				dynamicAttr.setValue("Y");
			else
				dynamicAttr.setValue("N");
			dynamicAttrList.add(dynamicAttr);
			response.setDynamicAttrList(dynamicAttrList);
			externalResponseList.add(response);
		}
		for (BestValueOffer bvo : bvpData.getBestValueOffers()) {
			NBXResponse response = new NBXResponse();
			if (bvo.getMyOffer() && StringUtilities.isNotEmptyOrNull(bvo.getRtdRank()))
				response.setRank(bvo.getRtdRank());
			else
				response.setRank(bvo.getRank());
			response.setPropositionId(bvpData.getPropositionId());
			String endPoint = System.getProperty(CartConstants.ENDPOINT);
			if ("add-device".equalsIgnoreCase(endPoint)) {
				response.setDispositionOptionId(CartConstants.BVP_ACCEPTED);
				System.setProperty("bvoAccepted", "true");
			} else if ("remove-lines".equalsIgnoreCase(endPoint)) {
				response.setDispositionOptionId(CartConstants.BVP_REJECTED);
				System.setProperty("bvoRejected", "true");
			} else {
				response.setDispositionOptionId(CartConstants.BVP_VIEW);
				System.setProperty("bvoViewed", "true");
			}
			response.setSoiEngagementId(bvpData.getSoiEngagementId());
			response.setTimeStamp(timestamp);
			List<DynamicAttributes> dynamicAttrList = new ArrayList<>();
			DynamicAttributes dynamicAttr = new DynamicAttributes();
			if (StringUtilities.isNotEmptyOrNull(bvo.getDeviceSku())) {
				dynamicAttr.setAttrId("skuId");
				dynamicAttr.setValue(bvo.getDeviceSku());
			}
			if (StringUtilities.isNotEmptyOrNull(bvo.getId())) {
				dynamicAttr.setAttrId("Offer");
				dynamicAttr.setValue(bvo.getId());
			}
			dynamicAttrList.add(dynamicAttr);
			response.setDynamicAttrList(dynamicAttrList);
			responseList.add(response);
		}
		customerResponse.setResponseList(responseList);
		customerResponse.setExternalResponseList(externalResponseList);
		serviceRequest.setCustomerResponse(customerResponse);
		serviceBody.setServiceRequest(serviceRequest);
		service.setServiceBody(serviceBody);
		feedbackRequest.setService(service);
		return feedbackRequest;
	}

	/**
	 *
	 * @param request
	 * @return nbxRequest
	 */
	public NBXFeedbackRequest formatNbxPromoFeedbackRequest(NBXFeedbackUIRequest request, CartRedisData data) {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss zzz");
		df.setTimeZone(TimeZone.getTimeZone("GMT"));
		Date date = new Date();
		String timestamp =df.format(date);
		NBXFeedbackRequest feedbackRequest= new NBXFeedbackRequest();

		NBXService service = new NBXService();

		NBXCustomerInfo customerInfo = request.getService().getServiceBody().getServiceRequest().getCustomerInfo();

		if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
			customerInfo.setAccountNo(data.getAccountNumber());

		if (StringUtilities.isNotEmptyOrNull(data.getMtn()))
			customerInfo.setMtn(data.getMtn());


		if (request.getService() != null  && request.getService().getServiceBody() != null &&
				request.getService().getServiceBody().getServiceRequest() !=null &&
				request.getService().getServiceBody().getServiceRequest().getCustomerResponse() != null) {

			if (request.getService().getServiceBody().getServiceRequest().getCustomerResponse().getResponseList() != null &&
					request.getService().getServiceBody().getServiceRequest().getCustomerResponse().getResponseList().size() > 0) {
				for (NBXResponse responseListObj : request.getService().getServiceBody().getServiceRequest().getCustomerResponse().getResponseList()) {
					responseListObj.setTimeStamp(timestamp);
				}
			}
			if (request.getService().getServiceBody().getServiceRequest().getCustomerResponse().getExternalResponseList() != null &&
					request.getService().getServiceBody().getServiceRequest().getCustomerResponse().getExternalResponseList().size() > 0) {
				for (NBXResponse ExternalResponseListObj : request.getService().getServiceBody().getServiceRequest().getCustomerResponse().getExternalResponseList()) {
					ExternalResponseListObj.setTimeStamp(timestamp);
				}
			}

			if(request.getService().getServiceHeader() != null){
				request.getService().getServiceHeader().setTimestamp(timestamp);
			}

			service.setServiceBody(request.getService().getServiceBody());
			service.setServiceHeader(request.getService().getServiceHeader());
			feedbackRequest.setService(service);

		}
		return feedbackRequest;

	}


}
