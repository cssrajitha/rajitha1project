package onevz.soe.cart.helper;

import onevz.soe.cart.bpm.service.CartServiceBPMServices;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.model.addAccessory.AccessoryAction;
import onevz.soe.cart.model.addAccessory.AddAccContext;
import onevz.soe.cart.model.addAccessory.AddAccServiceBody;
import onevz.soe.cart.model.addAccessory.AddAccServiceRequest;
import onevz.soe.cart.model.addQuickAccessoryToCart.AddQuickAccessoryRequest;
import onevz.soe.cart.model.addQuickAccessoryToCart.AddQuickAccessoryResponse;
import onevz.soe.cart.model.addQuickAccessoryToCart.AddQuickAccessoryResponseData;
import onevz.soe.cart.model.common.Accessory;
import onevz.soe.cart.model.common.CartServiceCartInfo;
import onevz.soe.cart.model.common.CartServiceContextInfo;
import onevz.soe.cart.model.common.CartServiceCustomerInfo;
import onevz.soe.cart.model.common.CartServiceServiceHeader;
import onevz.soe.cart.model.common.Line;
import onevz.soe.cart.requests.AddAccessoryPEGARequest;
import onevz.soe.cart.requests.FWACreateCartRequest;
import onevz.soe.cart.requests.FwaDeviceContext;
import onevz.soe.cart.requests.FwaDeviceContextInfo;
import onevz.soe.cart.requests.FwaDeviceCustomerInfo;
import onevz.soe.cart.requests.FwaServiceBody;
import onevz.soe.cart.requests.FwaServiceRequest;
import onevz.soe.cart.responses.FWACreateCartResponse;
import onevz.soe.cart.util.RetrieveCustomerDataUtil;
import onevz.soe.datastore.model.CustomerData;
import onevz.soe.exception.SOEException;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.bpm.model.ServiceHeader;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static onevz.soe.cart.constants.CartConstants.ORD_LOC_SESSION_KEY;
import static onevz.soe.cart.constants.CartConstants.POS_ROLE_SESSION_KEY;
import static onevz.soe.cart.constants.CartConstants.SALES_REP_SESSION_KEY;
import static onevz.soe.cart.util.RetrieveCartErrorsUtil.getDefaultErrorsList;

@Service
public class AddQuickAccessoryToCartHelper {

    @Autowired
    SOELoginSessionBean soeLoginSessionBean;

    @Autowired
    RetrieveCustomerDataUtil retrieveCustomerDataUtil;

    @Autowired
    CartServiceBPMServices cartServiceBPMServices;

    @Autowired
    CartServiceCXPServices cartServiceCXPServices;

    private static final Logger logger = LoggerFactory.getLogger(AddQuickAccessoryToCartHelper.class);

    public Mono<AddQuickAccessoryResponse> addQuickAccessoryToCart(String channelId, AddQuickAccessoryRequest request) {

        Mono<Map> sessionDataResp = soeLoginSessionBean.getUserSessionData(List.of(SALES_REP_SESSION_KEY, ORD_LOC_SESSION_KEY, POS_ROLE_SESSION_KEY)).switchIfEmpty(Mono.just(new HashMap<>())).flatMap(Mono::just).onErrorResume(err -> Mono.just(new HashMap<>()));
        Mono<CustomerData> customerDataResp = retrieveCustomerDataUtil.getCustomerDataFromSession(request.getCartId());
        AddQuickAccessoryResponse response = new AddQuickAccessoryResponse();
        AddQuickAccessoryResponseData responseData = new AddQuickAccessoryResponseData();

        return Mono.zip(sessionDataResp, customerDataResp)
           .flatMap(monoResponses -> {
               Map sessionData = monoResponses.getT1();
               CustomerData customerData = monoResponses.getT2();
               customerData.setLookUpMtn(StringUtilities.isEmptyOrNull(customerData.getLookUpMtn()) ? "9999999999" : customerData.getLookUpMtn());
               customerData.setAccountNumber(StringUtilities.isEmptyOrNull(customerData.getAccountNumber()) ? "" : customerData.getAccountNumber());

               FWACreateCartRequest createCasePegaRequest = populateCjcmCreateCartRequest(channelId, customerData, sessionData, request);

               return cartServiceBPMServices.createCart(createCasePegaRequest)
                    .flatMap(createCaseResp -> {
                        if(Optional.ofNullable(createCaseResp.getServiceBody()).isPresent()
                                && Optional.ofNullable(createCaseResp.getServiceBody().getServiceResponse()).isPresent()
                                && Optional.ofNullable(createCaseResp.getServiceBody().getServiceResponse().getContext()).isPresent()
                                && Optional.ofNullable(createCaseResp.getServiceBody().getServiceResponse().getContext().getCartInfo()).isPresent()) {
                            try {
                                return getAddQuickAccessoryResponseMono(channelId, createCaseResp, customerData, responseData, response);
                            } catch (SOEHTTPException e) {
                                logger.error("Exception while adding accessory {}", e.getMessage());
                            }
                        }
                        response.setData(responseData);
                        return Mono.just(response);
                    });
           }).onErrorResume(error -> {
                responseData.setErrors((error instanceof SOEException) ?((SOEException)error).soeError.getErrors()
                        : getDefaultErrorsList(error.getMessage(), "CXP-ERROR"));
                response.setData(responseData);
                return Mono.just(response);
           });
    }

    private Mono<AddQuickAccessoryResponse> getAddQuickAccessoryResponseMono(String channelId, FWACreateCartResponse createCaseResp, CustomerData customerData, AddQuickAccessoryResponseData responseData, AddQuickAccessoryResponse response) throws SOEHTTPException {
        if(StringUtilities.isNotEmptyOrNull(createCaseResp.getServiceBody().getServiceResponse().getContext().getCaseId())
                && StringUtilities.isNotEmptyOrNull(createCaseResp.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartId())) {
            String caseId = createCaseResp.getServiceBody().getServiceResponse().getContext().getCaseId();
            String cartId = createCaseResp.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartId();
            AddAccessoryPEGARequest addAccessoryPegaRequest = populateCjcmAddAccessoryRequest(channelId, customerData, caseId, cartId);
            responseData.setCartId(cartId);
            return cartServiceBPMServices.addAccessory(addAccessoryPegaRequest)
                .flatMap(addAccessoryResp -> cartServiceCXPServices.validateCart(cartId, null, null, null, false, null, null, false)
                    .flatMap(validCartResp -> {
                        responseData.setStatus(1);
                        response.setData(responseData);
                        return Mono.just(response);
                    })
                ).onErrorResume(error -> {
                    responseData.setErrors((error instanceof SOEException) ?((SOEException)error).soeError.getErrors()
                            : getDefaultErrorsList(error.getMessage(), "CXP-ERROR"));
                    response.setData(responseData);
                    return Mono.just(response);
                });
        }
        response.setData(responseData);
        return Mono.just(response);
    }

    private FWACreateCartRequest populateCjcmCreateCartRequest(String channelId, CustomerData customerData, Map sessionData, AddQuickAccessoryRequest request) {
        FWACreateCartRequest createCasePegaRequest = new FWACreateCartRequest();
        ServiceHeader serviceHeader = new ServiceHeader();
        serviceHeader.setClientId(channelId);
        serviceHeader.setServiceName("SalesOrderPurchase");
        serviceHeader.setStatusMsg("PEGA generated message");
        createCasePegaRequest.setServiceHeader(serviceHeader);
        FwaServiceBody serviceBody = new FwaServiceBody();
        FwaServiceRequest serviceRequest = new FwaServiceRequest();
        FwaDeviceContext context = new FwaDeviceContext();
        context.setCartInfo(new CartServiceCartInfo());
        FwaDeviceContextInfo contextInfo = new FwaDeviceContextInfo();
        contextInfo.setCallReason("SalesOrderPurchase");
        contextInfo.setIntent("Accessory");
        context.setContextInfo(contextInfo);
        FwaDeviceCustomerInfo customerInfo = new FwaDeviceCustomerInfo();
        customerInfo.setAccountNumber(customerData.getAccountNumber());
        customerInfo.setCartCreator(customerData.getLookUpMtn());
        customerInfo.setProcessingMTN(customerData.getLookUpMtn());
        customerInfo.setCartCreatorOrderLocationCode(Optional.ofNullable(sessionData.get(ORD_LOC_SESSION_KEY)).isPresent() ? sessionData.get(ORD_LOC_SESSION_KEY).toString() : "");
        customerInfo.setCartCreatorSalesRepId(Optional.ofNullable(sessionData.get(SALES_REP_SESSION_KEY)).isPresent() ? sessionData.get(SALES_REP_SESSION_KEY).toString() : "");
        //new customer flow
        if(StringUtilities.isEmptyOrNull(customerData.getLookUpMtn())
                || StringUtilities.isEmptyOrNull(customerData.getAccountNumber())) {
            customerInfo.setFlowType(request.getFlowType());
            customerInfo.setCustomerType("N");
        }
        context.setCustomerInfo(customerInfo);
        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        createCasePegaRequest.setServiceBody(serviceBody);

        return createCasePegaRequest;
    }

    private AddAccessoryPEGARequest populateCjcmAddAccessoryRequest(String channelId, CustomerData customerData, String caseId, String cartId) {
        AddAccessoryPEGARequest addAccessoryPegaRequest = new AddAccessoryPEGARequest();
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        serviceHeader.setClientId(channelId);
        serviceHeader.setServiceName("SalesOrderPurchase");
        serviceHeader.setStatusMsg("PEGA generated message");
        addAccessoryPegaRequest.setServiceHeader(serviceHeader);

        AddAccServiceBody serviceBody = new AddAccServiceBody();
        AddAccServiceRequest serviceRequest = new AddAccServiceRequest();
        AddAccContext context = new AddAccContext();
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setAction("UPDATE");
        cartInfo.setCartId(cartId);
        cartInfo.setIntendType("ACC");
        cartInfo.setItemType("ACCESSORY");
        Line[] lines = populateLines(customerData);
        cartInfo.setLines(lines);
        context.setCartInfo(cartInfo);
        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(customerData.getAccountNumber());
        customerInfo.setCartCreator(customerData.getLookUpMtn());
        customerInfo.setProcessingMTN(customerData.getLookUpMtn());
        context.setCustomerInfo(customerInfo);
        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        contextInfo.setCallReason("SalesOrderPurchase");
        contextInfo.setIntent("Accessory");
        contextInfo.setProcessAction("addAccessory");
        contextInfo.setProcessStep("ShoppingCart");
        context.setContextInfo(contextInfo);
        context.setCaseId(caseId);
        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        addAccessoryPegaRequest.setServiceBody(serviceBody);
        return addAccessoryPegaRequest;
    }

    private static Line[] populateLines(CustomerData customerData) {
        if(Optional.ofNullable(customerData.getQuickAccessoryDetails()).isPresent()
                && CollectionUtilities.isNotEmptyOrNull(customerData.getQuickAccessoryDetails().getLines())) {
            return customerData.getQuickAccessoryDetails().getLines().stream()
                    .map(accessoryLine -> {
                        Line line = new Line();
                        if(Optional.ofNullable(accessoryLine).isPresent()
                                && CollectionUtilities.isNotEmptyOrNull(accessoryLine.getAccessories())) {
                            AccessoryAction accessoryAction = new AccessoryAction();
                            Accessory[] accessories = accessoryLine.getAccessories().stream().map(
                                    selectedAccessory -> {
                                        Accessory accessory = new Accessory();
                                        accessory.setDepeletionType(selectedAccessory.getDepletionType());
                                        accessory.setId(selectedAccessory.getSorId());
                                        accessory.setQty(String.valueOf(selectedAccessory.getQty()));
                                        return accessory;
                                    }).toArray(Accessory[]::new);
                            accessoryAction.setAdd(accessories);
                            line.setAccessories(accessoryAction);
                            line.setMtn(customerData.getLookUpMtn());
                        }
                        return line;
                    }).toArray(Line[]::new);
        }
        return emptyLines(customerData.getLookUpMtn());
    }

    private static Line[] emptyLines(String mtn) {
        Line[] lines = new Line[1];
        Line line = new Line();
        AccessoryAction accessoryAction = new AccessoryAction();
        accessoryAction.setAdd(new Accessory[1]);
        line.setAccessories(accessoryAction);
        line.setMtn(mtn);
        lines[0]=line;
        return lines;
    }
}
