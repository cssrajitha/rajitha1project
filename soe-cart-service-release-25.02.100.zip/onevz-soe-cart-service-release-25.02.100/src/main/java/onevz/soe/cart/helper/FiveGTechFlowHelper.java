package onevz.soe.cart.helper;

import onevz.soe.cart.bpm.helper.CartServiceBpmHelper;
import onevz.soe.cart.controller.advice.CartServiceExceptionHandler;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.initiatecart.InitiateCartUIResponse;
import onevz.soe.cart.ui.requests.AddPlanAndDeviceUIRequest;
import onevz.soe.cart.ui.responses.AddPlanAndDeviceUIResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;


@Service
public class FiveGTechFlowHelper {

	@Autowired
	CartServiceCxpHelper cxpHelper;

	@Autowired
	private RedisHelper3 redisHelper3;
	@Autowired
	CartServiceBpmHelper bpmHelper;
	@Autowired
	private CartServiceExceptionHandler exHandler;



	private static final Logger logger = LoggerFactory.getLogger(FiveGTechFlowHelper.class);

	public Mono<AddPlanAndDeviceUIResponse> cpcUpdateCart(AddPlanAndDeviceUIRequest request) {
		return redisHelper3.fetchTechnicianDataFromRedis().flatMap(techFlowRedisData -> {
			return bpmHelper.cpcUpdateCart(techFlowRedisData);
		});
	}

	public Mono<AddPlanAndDeviceUIResponse> cpcSubmitPlan(AddPlanAndDeviceUIRequest request) {
		return redisHelper3.fetchTechnicianDataFromRedis().flatMap(techFlowRedisData -> {
			return bpmHelper.cpcSubmitPlan(techFlowRedisData);
		});
	}

	public Mono<InitiateCartUIResponse> cpcInititateCart(AddPlanAndDeviceUIRequest request) {

		return redisHelper3.fetchProfileInfoFromRedis().flatMap(customerInfo -> {
			return bpmHelper.cpcInitiateCart(customerInfo, request);
		});
	}
}
