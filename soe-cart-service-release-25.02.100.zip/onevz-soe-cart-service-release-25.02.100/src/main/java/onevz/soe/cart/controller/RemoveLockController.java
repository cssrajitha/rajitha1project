package onevz.soe.cart.controller;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.helper.RemoveLockHelper;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.ui.requests.RemoveLockRequest;
import onevz.soe.cart.util.CartPegaResponseErrorsUtil2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;


//NSADT-53978 removing CrossOrigin annotation in every service
//@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping(value = "cart")
public class RemoveLockController {
	
	@Autowired
	private RemoveLockHelper removeLockerHelper;
	/**
	 * 
	 * @param binder
	 */
	@InitBinder("*")
	public void initBinderByName(WebDataBinder binder) {
		binder.setDisallowedFields(new String[] { "genericHeader" });
	}

	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @return
	 */
	@PostMapping("/removeLock")
	public Mono<ResponseEntity<GenericResponse>> saveCart(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse){

		System.setProperty(CartConstants.ENDPOINT, "removeLock");
		RemoveLockRequest removeLockRequest= new RemoveLockRequest();
		String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
				? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
				: "";
		removeLockRequest.setChannelId(channelId);

		return removeLockerHelper.updateRemoveLock(removeLockRequest).map(resp -> {
			ErrorResponse errors2 = null;
			if (resp.getErrors() != null) {
				errors2 = CartPegaResponseErrorsUtil2.handleRemoveLockResponseErrors(resp);
			}
			return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
					: ResponseEntity.status(HttpStatus.OK).body(resp);

		});
	}

}
