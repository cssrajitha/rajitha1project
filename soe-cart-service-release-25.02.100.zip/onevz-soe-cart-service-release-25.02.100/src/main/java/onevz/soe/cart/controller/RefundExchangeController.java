package onevz.soe.cart.controller;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.helper.RedisHelper2;
import onevz.soe.cart.requests.UpdateUserSessionRequest;
import onevz.soe.cart.responses.UpdateUserSessionResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping(value = "cart")
public class RefundExchangeController {

	@Autowired
	private RedisHelper2 redisHelper2;

	 /**
		 * 
		 * @param binder
		 */
	 @InitBinder("*")
	 public void initBinderByName(WebDataBinder binder) {
		 binder.setDisallowedFields(new String[] { "genericHeader" });
	 }
			  
	@PostMapping("/updateUserSession")
	public Mono<UpdateUserSessionResponse> updateUserSession(ServerHttpRequest httpRequest,
			ServerHttpResponse httpResponse, @RequestBody UpdateUserSessionRequest request) {

		 Map<String,String> sessionData = new HashMap<String,String>();
		 sessionData.put(CartConstants.INTENDTYPE, CartConstants.REX);
		 sessionData.put(CartConstants.INTENTTYPE, CartConstants.REX);
		 sessionData.put(CartConstants.FLOW, CartConstants.REFUND_EXC);
		 sessionData.put(CartConstants.CASEID, request.getData().getCaseId());
		 sessionData.put(CartConstants.CARTID, request.getData().getCartId());
		 sessionData.put(CartConstants.CART_CREATOR, request.getData().getCartCreator());
		 redisHelper2.upsertDataInRedis(sessionData);
		 UpdateUserSessionResponse resp = new UpdateUserSessionResponse();
		 resp.setMessage("redis upsert done successfully");
		 return Mono.just(resp);

	 }

}