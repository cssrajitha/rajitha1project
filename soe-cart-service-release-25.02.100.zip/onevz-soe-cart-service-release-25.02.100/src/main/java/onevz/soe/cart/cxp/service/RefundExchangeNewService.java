/*package onevz.soe.cart.cxp.service;

import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.time.Duration;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseCookie;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Service;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
//import onevz.soe.cart.cxp.service.RefundExchangeService;
import onevz.soe.cart.model.refundExchange.CustomerInform;
import onevz.soe.cart.model.refundExchange.QuickViewGQLRequest;
import onevz.soe.cart.requests.UpdateUserSessionRequest;
import onevz.soe.cart.responses.UpdateUserSessionResponse;
import onevz.soe.session.client.model.QuickViewDetails;
import reactor.core.publisher.Mono;

@Service
public class RefundExchangeNewService {

	@Autowired
	CartServiceCXPServices cartServiceCXPServices;

	private static final String PRIVATEKEY = "MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAN2e6nfot+2l3ZRySfCNFZyvaYx4Hik2jPxFiztO6RXCObgVNINrHS79xy0n0iakFvm2TlkhNNcqyoYYZ53TKlLU/wQTgrWDqbMRr1EyiPKsi4LJvk0qnz629FIp9u4oQ2d9XgP0hitwI0HfBYy7fp968VLK5wjGmyyaLjl4A9KdAgMBAAECgYEAtxc1//BMG9J/F8e/3DLCmxqz6W/HAydlHHlbyJitqeM3CiTCqJvSlWLlrSGL1Y6UyKJbYfk0DVr1zAjXeaTd/dz9NBemk30zvENyNYBtfT4bww+21FFcpOHl79I/07ZOgjcmPD4LKwTpX+0H3LxUVuQ3LA7TCNsdVF7qMo517IUCQQDzpvGid3Mo381BoWD/mnkxnk2JzKyKDSR+KkluS9CN9GLuR0txO0rzuhM5uzswfOLrFgLbukyO01vwvNoDLwhzAkEA6NolHS+TdED4ksxR/pN1NmaGHAsCJVbchU6MbC3jkDBxUuRDmgFCGrvC5ty9CI9AStCe1YdIOq7KgmKUrcfErwJAERF91eLGR3O+Hj3e3KkGmmo7hk63O4iGKOxvbnGTL46SK50E9O6xZnd/h0jNca0d/FfzZU8cs9islSW1pAl0bwJBAKg+npx0+M0B+NlQylnwP7vb3kC674T9Ov8TH0E28vsHFYq4JeRLznC0hAH9MpTRtLmZ/Xn5coX8L5SAGD9sXT8CQEKCr05YsAkHvWgi5cXHJj3sN3HFKtMiyPEhVaXf1tg1ihQo4ifoaGwycTwkCyXkM4h/HSociAFrQfWhKFT6+VY=";
	private static final String domain = "vzwcorp.com";
	private static final String path = "/";

	public Mono<UpdateUserSessionResponse> updateUserSession(UpdateUserSessionRequest request,
			ServerHttpResponse httpResponse, Mono<CustomerInform> customerInform) {

		Mono<Object> claims = populateClaims(customerInform);
		return generateJWT(claims, httpResponse);
	}

	public Mono<Object> populateClaims(Mono<CustomerInform> customerInformMono) {

		Map<String, Object> claims = new HashMap<>();
		return customerInformMono.flatMap(customerInform -> {
			claims.put("ORDERLOC", customerInform.getORDERLOC());
			claims.put("repId", customerInform.getRepId());
			claims.put(CartConstants.LOGGEDINUSER, customerInform.getLoggedInUser());
			claims.put("HOMELOC", customerInform.getHOMELOC());
			claims.put("channel", customerInform.getChannel());
			claims.put("regNo", customerInform.getRegNo());
			claims.put("mtn", customerInform.getMtn());

			populateFromCustomerInfo(customerInform, claims);
			return Mono.just(claims);
		});
	}

	private void populateFromCustomerInfo(CustomerInform customerInform, Map<String, Object> claims) {
		if(null != customerInform) {
		QuickViewGQLRequest custQuickViewDetails = customerInform.getQuickView();
		QuickViewDetails quickView = new QuickViewDetails();
		quickView.setPastDue("0.0");
		quickView.setDpEligibility("Not Verified"); 
		if(null != custQuickViewDetails)
			quickView.setEligibleLineCount(custQuickViewDetails.getEligibleLineCount());
		quickView.setPendingOrderCount("0");
		quickView.setBtaAmount("0");
		claims.put(CartConstants.ACCOUNT_NUMBER, customerInform.getAccountNumber());
		claims.put("quickView", quickView);
		}
	}

	private Mono<UpdateUserSessionResponse> generateJWT(Mono<Object> claimsMono, ServerHttpResponse httpResponse) {

		return claimsMono.flatMap(claims -> {
			Map<String, Object> claimMap = new HashMap<String, Object>();
			claimMap.putAll((Map<? extends String, ? extends Object>) claims);
			String jwt = "";
			UpdateUserSessionResponse updateUserSessionResponse = null;
			try {
				PrivateKey pk = KeyFactory.getInstance("RSA")
						.generatePrivate(new PKCS8EncodedKeySpec(java.util.Base64.getDecoder().decode(PRIVATEKEY)));
				jwt = Jwts.builder().setClaims(claimMap).setIssuedAt(new Date()).signWith(SignatureAlgorithm.RS256, pk)
						.compact();
			} catch (InvalidKeySpecException | NoSuchAlgorithmException e1) {
				updateUserSessionResponse = new UpdateUserSessionResponse();
				updateUserSessionResponse.setMessage("encryption failed");
				return Mono.just(updateUserSessionResponse);
			}
			String envDomain = domain;
			String soeguisubkey = UUID.randomUUID().toString();
			/*
			 * Cookie cookie1 = new Cookie("soeguisubkey", soeguisubkey);
			 * cookie1.setPath(path); cookie1.setMaxAge(-1); cookie1.setSecure(true);
			 * cookie1.setDomain(envDomain);
			 * 
			 * Cookie cookie2 = new Cookie("soeguivalue", jwt); cookie2.setPath(path);
			 * cookie2.setMaxAge(-1); cookie2.setSecure(true); cookie2.setDomain(envDomain);
			 */

			/*httpResponse.addCookie(ResponseCookie.from("soeguisubkey", soeguisubkey).domain(envDomain).path(path).maxAge(Duration.ofDays(30))
					.httpOnly(true).secure(true).build());
			httpResponse.addCookie(ResponseCookie.from("soeguivalue", jwt).domain(envDomain).path(path).maxAge(Duration.ofDays(30)).httpOnly(true)
					.secure(true).build());
			updateUserSessionResponse = new UpdateUserSessionResponse();

			updateUserSessionResponse.setMessage("encryption success");
			updateUserSessionResponse.setSoeguivalue(jwt);
			updateUserSessionResponse.setSoeguisubkey(soeguisubkey);
			return Mono.just(updateUserSessionResponse);
		});

	}

	
}*/
