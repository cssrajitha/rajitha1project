package onevz.soe.cart.controller;

import onevz.soe.cart.helper.SetupAndGoHelper;
import onevz.soe.cart.requests.SUAGSelectionDetailsRequest;
import onevz.soe.cart.responses.SUAGSelectionDetailsUIResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;


@RestController
public class SetupAndGoController {

    @Autowired
    private SetupAndGoHelper setupAndGoHelper;

    @PostMapping(value= "/getSUAGSelectionDetails", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<SUAGSelectionDetailsUIResponse> getSUAGDetails(ServerHttpRequest serverHttpRequest, @RequestBody  SUAGSelectionDetailsRequest request){
        return setupAndGoHelper.getSUAGSelectionDetails();
    }
}
