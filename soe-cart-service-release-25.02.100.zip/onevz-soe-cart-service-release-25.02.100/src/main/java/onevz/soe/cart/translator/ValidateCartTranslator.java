package onevz.soe.cart.translator;

import onevz.soe.cart.gql.schema.Shipping;
import onevz.soe.cart.gql.schema.ShippingAddress;
import onevz.soe.cart.model.common.Address;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.retrieveCart.*;
import onevz.soe.cart.model.retrieveCart.ServiceInfo;
import onevz.soe.cart.model.validateCart.CartValidationError;
import onevz.soe.cart.ui.responses.v2.*;
import onevz.soe.cart.ui.responses.v2.CXPCartVO;
import onevz.soe.cart.ui.responses.v2.LineDetails;
import onevz.soe.cart.ui.responses.v2.VisFeatures;
import onevz.soe.orderprocess.model.checkoutdetails.PendingItems;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.util.ObjectUtils;

import java.util.*;


import static onevz.soe.cart.constants.CartConstants.*;


public class ValidateCartTranslator {
    private static final Logger logger = LoggerFactory.getLogger(ValidateCartTranslator.class);
    public static final List<String> listOfErrorCodes = List.of("1026", "1023","1024");

    public static final String DEVICE_SELECTION_STRING= "1026";
    public static ValidateCartUIResponse translateValidateCartUIResponse(onevz.soe.cart.ui.responses.ValidateCartUIResponse response) {
        ValidateCartUIResponse validateCartUIResponse = new ValidateCartUIResponse();
        if (CollectionUtilities.isNotEmptyOrNull(response.getErrors())) {
            List<CartError> errors = response.getErrors();
            validateCartUIResponse.setErrors(errors);
            return validateCartUIResponse;
        }
        validateCartUIResponse = new ValidateCartTranslator().getValidateCartUIResponse(response);
        setPendingActionsDataBasedOnCartErrors(response);
        setPendingAction(validateCartUIResponse,response);
        return validateCartUIResponse;
    }

    private static void setPendingActionsDataBasedOnCartErrors(onevz.soe.cart.ui.responses.ValidateCartUIResponse response) {
        if(null!=response && null!=response.getData() && null!=response.getData().getValidateCartAndUpdate()){
            Map<String, List<PendingItems>> pendingsteps = new HashMap<>();
            Map<String, List<PendingItems>> cxpPendingsteps=new HashMap<>();
            if(CollectionUtilities.isNotEmptyOrNull(response.getData().getValidateCartAndUpdate().getCartValidationErrors())){
                List<PendingItems> pendingItems=new ArrayList<>();
                response.getData().getValidateCartAndUpdate().getCartValidationErrors().stream().forEach(eachRecord->{

                    if(BLOCKER_CONST.equalsIgnoreCase(eachRecord.getErrorLevel()) && listOfErrorCodes.contains(eachRecord.getErrorCode())){
                        PendingItems pendingItem=new PendingItems();
                        setPendingItemsWithData(eachRecord,pendingItem);
                        pendingItems.add(pendingItem);
                        Arrays.asList(eachRecord.getFieldPath().split(",")).stream().forEach(eachFieldPath->{
                            List<PendingItems> cxpPendingtItems=new ArrayList<>();
                            PendingItems cxpPendingItem=new PendingItems();
                            setPendingItemsWithData(eachRecord,cxpPendingItem);
                            cxpPendingtItems.add(cxpPendingItem);
                            cxpPendingsteps.put(eachFieldPath,cxpPendingtItems);
                        });
                        response.getData().setCxpPendingsteps(cxpPendingsteps);
                    }
                });
                pendingsteps.put("sortedSteps",pendingItems);
                response.getData().setPendingsteps(pendingsteps);
            }
        }
    }

    private static void setPendingItemsWithData(CartValidationError eachRecord, PendingItems cxpPendingItem) {
        if(DEVICE_SELECTION_STRING.equalsIgnoreCase(eachRecord.getErrorCode())){
            cxpPendingItem.setStep(DEVICE_SELECTION_STEP);
            cxpPendingItem.setId(DEVICE_SELECTION_STEP);
        }else{
            cxpPendingItem.setStep(PLAN_SELECTION);
            cxpPendingItem.setId(PLAN_SELECTION);
        }
        cxpPendingItem.setErrorLevel(BLOCKER_CONST);
    }

    private static void setPendingAction(ValidateCartUIResponse validateCartUIResponse, onevz.soe.cart.ui.responses.ValidateCartUIResponse cxpResp) {
        try {
            if (validateCartUIResponse.getData().getValidateCartAndUpdate() !=null && validateCartUIResponse.getData().getValidateCartAndUpdate().getLineDetails() !=null
                    && CollectionUtils.isNotEmpty(validateCartUIResponse.getData().getValidateCartAndUpdate().getLineDetails().getNseLines())) {
                var noOfLines = validateCartUIResponse.getData().getValidateCartAndUpdate().getLineDetails().getNseLines();
                if (noOfLines.size() <= 1) {
                    return;
                }
            } else {
                return;
            }
            if (cxpResp.getData() != null && CollectionUtilities.isNotEmptyOrNull(cxpResp.getData().getPendingsteps()) && CollectionUtilities.isNotEmptyOrNull(validateCartUIResponse.getData().getValidateCartAndUpdate().getLineDetails().getNseLines())) {
                Boolean anyDeviceAbsent = false;
                Boolean anyPlanAbsent = false;
                Boolean anyPlanAbsentWithOutDeviceOnCart = false;
                if (cxpResp.getData().getPendingsteps().containsKey(SORTED_STEPS)) {
                    for (PendingItems ps : cxpResp.getData().getPendingsteps().get(SORTED_STEPS)) {
                        if ((DEVICE_SELECTION_STEP).equalsIgnoreCase(ps.getStep()))
                            anyDeviceAbsent = true;
                        if ((PLAN_SELECTION).equalsIgnoreCase(ps.getStep()))
                            anyPlanAbsent = true;
                        if (anyDeviceAbsent && anyPlanAbsent)
                            anyPlanAbsentWithOutDeviceOnCart = true;
                    }
                }
                if (anyDeviceAbsent && CollectionUtilities.isNotEmptyOrNull(cxpResp.getData().getCxpPendingsteps())) {
                    setLineLevelPendingAction(validateCartUIResponse,cxpResp,anyPlanAbsentWithOutDeviceOnCart,anyPlanAbsent);
                }
            }
        } catch(Exception e) {
            logger.error("Error on PlanFirst Logic", e);
        }
    }

    private static void setLineLevelPendingAction(ValidateCartUIResponse validateCartUIResponse,
                                                  onevz.soe.cart.ui.responses.ValidateCartUIResponse cxpResp,
                                                  Boolean anyPlanAbsentWithOutDeviceOnCart, Boolean anyPlanAbsent) {
        String actionLine = null;
        for (String line : validateCartUIResponse.getData().getValidateCartAndUpdate().getLineDetails().getNseLines()) {
            List<PendingItems> entry = cxpResp.getData().getCxpPendingsteps().get(line);
            // #TODO What if we can have device pending paritially + plan pending partially ? is it possible , what is the experience for this
            for (PendingItems ps : entry) {
                // If any plan is pending without devcie on cart mean This is plan first flow. any thought here?
                if (Boolean.TRUE.equals(anyPlanAbsentWithOutDeviceOnCart) && (PLAN_SELECTION).equalsIgnoreCase(ps.getStep())) {
                    validateCartUIResponse.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo().get(line).setLineLevelPendingAction(PLAN_SELECTION);
                    // If all plans are present , then plan first flow is completed without device, then go for device, any thought here?
                } else if (!Boolean.TRUE.equals(anyPlanAbsent)  && (DEVICE_SELECTION_STEP).equalsIgnoreCase(ps.getStep())) {
                    if (StringUtils.isEmpty(actionLine)) {
                        actionLine = line;
                        validateCartUIResponse.getData().getValidateCartAndUpdate().getLineDetails().setNextCustomerActionLine(actionLine);
                    }
                    validateCartUIResponse.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo().get(line).setLineLevelPendingAction(DEVICE_SELECTION_STEP);
                }
            }
        }
    }

    private ValidateCartUIResponse getValidateCartUIResponse(onevz.soe.cart.ui.responses.ValidateCartUIResponse response) {
        ValidateCartUIResponse validateCartUIResponse = new ValidateCartUIResponse();
        CXPValidateCartDataVO data = new CXPValidateCartDataVO();
        if (null != response) {
            CXPCartVO validateCartAndUpdate = new CXPCartVO();
            validateCartUIResponse.setMeta(response.getMeta());
            validateCartUIResponse.setErrors(response.getErrors());
            onevz.soe.cart.model.validateCart.CXPValidateCartDataVO responseData = response.getData();
            if (null != responseData && null != responseData.getValidateCartAndUpdate()) {
                validateCartAndUpdate.setCustomerProfileForNSE(responseData.getValidateCartAndUpdate().getCustomerProfileForNSE());
                validateCartAndUpdate.setCartHeader(responseData.getValidateCartAndUpdate().getCartHeader());
                validateCartAndUpdate.setOrderDetails(responseData.getValidateCartAndUpdate().getOrderDetails());
                validateCartAndUpdate.setGlobalPromotions(responseData.getValidateCartAndUpdate().getGlobalPromotions());
                validateCartAndUpdate.setVerizonUpToastMessage(responseData.getValidateCartAndUpdate().getVerizonUpToastMessage());
                validateCartAndUpdate.setCartValidationErrors(responseData.getValidateCartAndUpdate().getCartValidationErrors());
                validateCartAndUpdate.setAccountEligibility(responseData.getValidateCartAndUpdate().getAccountEligibility());
                validateCartAndUpdate.setLineDetails(getLineDetails(responseData.getValidateCartAndUpdate().getLineDetails(), responseData.getValidateCartAndUpdate().getOrderDetails()));
                validateCartAndUpdate.setCartFlags(setCartFlag(response, responseData.getValidateCartAndUpdate()));
                validateCartAndUpdate.setCartHasOnlyAccessories(responseData.getValidateCartAndUpdate().isCartHasOnlyAccessories());
                validateCartAndUpdate.setEcpdProfile(getECPDProfile(responseData.getValidateCartAndUpdate()));
                if(responseData.getValidateCartAndUpdate().getAcpInfo() != null ){ // adding acp node for ACT60-228
                    validateCartAndUpdate.setAcpInfo(responseData.getValidateCartAndUpdate().getAcpInfo());
                }



                data.setValidateCartAndUpdate(validateCartAndUpdate);
                validateCartUIResponse.setData(data);
            }
        }
        return validateCartUIResponse;
    }

    private EcpdProfileInfo getECPDProfile(onevz.soe.cart.model.retrieveCart.CXPCartVO validateCartAndUpdate ) {

        EcpdProfileInfo ecpdProfile = null;

        if(Objects.nonNull(validateCartAndUpdate) && Objects.nonNull(validateCartAndUpdate.getEcpdProfile())) {
            ecpdProfile = new EcpdProfileInfo();
            ecpdProfile.setProfileId(validateCartAndUpdate.getEcpdProfile().getProfileId());
            ecpdProfile.setAccessDiscount(validateCartAndUpdate.getEcpdProfile().getAccessDiscount());
            ecpdProfile.setProfileName(validateCartAndUpdate.getEcpdProfile().getProfileName());
            ecpdProfile.setProfileCenter(validateCartAndUpdate.getEcpdProfile().getProfileCenter());
            ecpdProfile.setBlanketApprovalNumber(validateCartAndUpdate.getEcpdProfile().getBlanketApprovalNumber());
            ecpdProfile.setEcpdLiabilityTypeCode(validateCartAndUpdate.getEcpdProfile().getEcpdLiabilityTypeCode());
            ecpdProfile.setCustFacingAccDiscount(validateCartAndUpdate.getEcpdProfile().getCustFacingAccDiscount());
        }
       return ecpdProfile;
    }

    private CartFlags setCartFlag(onevz.soe.cart.ui.responses.ValidateCartUIResponse response, onevz.soe.cart.model.retrieveCart.CXPCartVO validateCartAndUpdate) {

        CXPLineDetailsVO lineDetails = validateCartAndUpdate.getLineDetails();
        CartFlags cartFlags = new CartFlags();
        if (lineDetails != null) {
            if (null != lineDetails.getNumofLinesEUP() && lineDetails.getNumofLinesEUP() > 0 &&
                    null != lineDetails.getNumofLinesAAL() && lineDetails.getNumofLinesAAL() > 0) {
                cartFlags.setComboCart(true);
            }

            CXPLineInfo[] lineInfoCxp = lineDetails.getLineInfo();
            List<CXPLineInfo> lineInfo = Arrays.asList(lineInfoCxp);
            if (lineInfo != null && !lineInfo.isEmpty()) {
                for (CXPLineInfo cartLineInfo : lineInfo) {
                    String lineActivityType = cartLineInfo.getLineActivityType();
                    switch (lineActivityType) {
                        case NSEACC_INTEND:
                            cartFlags.setGuestCheckout(true);
                            break;
                        case NSE:
                            cartFlags.setProspectCart(true);
                            break;
                        case ACC:
                            cartFlags.setStandaloneAccCart(true);
                            break;
                        default:break;

                    }
                }
                if (lineInfo.get(0).getServiceInfo() != null && lineInfo.get(0).getServiceInfo().getSelectedFeaturesList() != null) {
                    List<VisFeature> visFeatures =
                            lineInfo.get(0).getServiceInfo().getSelectedFeaturesList().getVisFeature();
                    List<String> verizonProtectMDCodeList = Arrays.asList(VERIZON_PROTECT_MD_CODE_1, VERIZON_PROTECT_MD_CODE_2, VERIZON_PROTECT_MD_CODE_3);
                    if (null != visFeatures) {
                        for (VisFeature visFeature : visFeatures) {
                            String visFeatureCode = visFeature.getVisFeatureCode();
                            if (verizonProtectMDCodeList.contains(visFeatureCode)) {
                                cartFlags.setVerizonProtectMDInCart(true);
                                break;
                            }
                        }
                    }

                }
            }
        }
        return cartFlags;
    }

    private LineDetails getLineDetails(CXPLineDetailsVO cxpLineDetails, CXPOrderDetails orderDetails) {
        LineDetails lineDetails = new LineDetails();
        if (null != cxpLineDetails) {
            lineDetails.setNumOfLinesWithDevices(null != cxpLineDetails.getNumOfLinesWithDevices() ? cxpLineDetails.getNumOfLinesWithDevices() : 0);
            lineDetails.setNumOfLines(null != cxpLineDetails.getNumOfLines() ? cxpLineDetails.getNumOfLines() : 0);
            lineDetails.setSubAccountNBSInfo(cxpLineDetails.getSubAccountNBSInfo());
            lineDetails.setNumofLinesAAL(null != cxpLineDetails.getNumofLinesAAL() ? cxpLineDetails.getNumofLinesAAL() : 0);
            lineDetails.setNumofLinesEUP(null != cxpLineDetails.getNumofLinesEUP() ? cxpLineDetails.getNumofLinesEUP() : 0);
            lineDetails.setNumOfAccessoryAndDeviceItemsInCart(null != cxpLineDetails.getNumOfAccessoryAndDeviceItemsInCart() ? cxpLineDetails.getNumOfAccessoryAndDeviceItemsInCart() : 0);
            lineDetails.setLineSeq(null != cxpLineDetails.getLineSeq() ? cxpLineDetails.getLineSeq() : 0);
            lineDetails.setVlcactivePhoneCount(null != cxpLineDetails.getVlcactivePhoneCount() ? cxpLineDetails.getVlcactivePhoneCount() : 0);
            lineDetails.setFivegOrderind(null != cxpLineDetails.getFivegOrderind() ? cxpLineDetails.getFivegOrderind() : Boolean.FALSE);
            lineDetails.setServiceLinesCreated(null != cxpLineDetails.getServiceLinesCreated() ? cxpLineDetails.getServiceLinesCreated() : Boolean.FALSE);
            lineDetails.setAceOrderCreated(null != cxpLineDetails.getAceOrderCreated() ? cxpLineDetails.getAceOrderCreated() : Boolean.FALSE);
            lineDetails.setAceItemsModified(null != cxpLineDetails.getAceItemsModified() ? cxpLineDetails.getAceItemsModified() : Boolean.FALSE);
            lineDetails.setClnrOrderFlag(null != cxpLineDetails.getClnrOrderFlag() ? cxpLineDetails.getClnrOrderFlag() : Boolean.FALSE);
            lineDetails.setBroadbandInd(null != cxpLineDetails.getBroadbandInd() ? cxpLineDetails.getBroadbandInd() : Boolean.FALSE);
            lineDetails.setStandaloneAccessory(null != cxpLineDetails.getStandaloneAccessory() ? cxpLineDetails.getStandaloneAccessory() : null);
            activateLines(lineDetails, cxpLineDetails.getLineInfo());
            setLinesWith(lineDetails, cxpLineDetails);
            lineDetails.setAllLines(getAllLines(cxpLineDetails.getLineInfo()));
            lineDetails.setLineInfo(getLineinfo(cxpLineDetails.getLineInfo(), orderDetails));
            lineDetails.setTradeInDetail(cxpLineDetails.getTradeInDetail());
            lineDetails.setCouponDetails(cxpLineDetails.getCouponDetails());
            lineDetails.setAcctMcsSubscription(cxpLineDetails.getAcctMcsSubscription());
            lineDetails.setSubTotalDueMonthlyWithAutoPayDisc(cxpLineDetails.getSubTotalDueMonthlyWithAutoPayDisc());
        }

        return lineDetails;
    }

    private List<String> getAllLines(CXPLineInfo[] lineInfo) {
        List<String> list = new ArrayList<>();
        if (ArrayUtils.isNotEmpty(lineInfo)) {
            for (CXPLineInfo cLineInfo : lineInfo) {
                if (!FEA.equalsIgnoreCase(cLineInfo.getLineActivityType())) {
                    list.add(cLineInfo.getMobileNumber());
                } else if (FEA.equalsIgnoreCase(cLineInfo.getLineActivityType()) && isVHDPAccessory(cLineInfo)) {
                    list.add(cLineInfo.getMobileNumber());
                }
            }
        }
        return list;
    }

    /**
     * This method will return true if accessory item in cart and line activity as FEA.
     *
     * @param cLineInfo
     * @return boolean
     */
    private boolean isVHDPAccessory(CXPLineInfo cLineInfo) {
        if (isItemPresent(cLineInfo, CART_ITEM_CODE_ACCESSORIES)) {
            return true;
        }
        return false;
    }

    /**
     * Thiis method will check if provided item code is present in cart item list.
     *
     * @param cLineInfo
     * @param cartItemCodeAccessories
     * @return boolean
     */

    private boolean isItemPresent(final CXPLineInfo cLineInfo, final String cartItemCodeAccessories) {
        if (ArrayUtils.isNotEmpty(cLineInfo.getItemsInfo())) {
            for (CXPItemInfo itemsInfo : cLineInfo.getItemsInfo()) {
                if (itemsInfo != null
                        && itemsInfo.getCartItems() != null
                        && ArrayUtils.isNotEmpty(itemsInfo.getCartItems().getCartItem())) {
                    return Arrays.asList(itemsInfo.getCartItems().getCartItem()).stream().
                            filter(cartItem -> cartItem != null && cartItemCodeAccessories.equalsIgnoreCase(cartItem
                                    .getCartItemType())).findAny().isPresent();
                }
            }
        }
        return false;
    }

    private void setLinesWith(LineDetails lineDetails, CXPLineDetailsVO cxpLineDetails) {
        List<String> deviceList = null;
        List<String> accessoryList = null;
        String mobileNumber = null;
        boolean lineHasAccessory = false;
        if (ArrayUtils.isNotEmpty(cxpLineDetails.getLineInfo())) {
            for (CXPLineInfo cartLineInfo : cxpLineDetails.getLineInfo()) {
                if (cartLineInfo == null || null == cartLineInfo.getItemsInfo() || ArrayUtils.isEmpty(cartLineInfo.getItemsInfo()))
                    continue;
                CXPItemInfo[] itemsInfo = cartLineInfo.getItemsInfo();
                if (ArrayUtils.isNotEmpty(itemsInfo)) {
                    for (CXPItemInfo itemsInfos : itemsInfo) {
                        CXPCartItemsVO cartItems = itemsInfos.getCartItems();
                        if (cartItems != null && ArrayUtils.isNotEmpty(cartItems.getCartItem())) {
                            for (CXPCartItem cartItem : cartItems.getCartItem()) {
                                if (CART_ITEM_TYPE_DEVICE.equals(cartItem.getCartItemType())) {
                                    deviceList = lineDetails.getDeviceLines();
                                    if (deviceList == null) {
                                        deviceList = new ArrayList<String>();
                                    }
                                    mobileNumber = cartItem.getMobileNumber();
                                    deviceList.add(cartItem.getMobileNumber());
                                    lineDetails.setDeviceLines(deviceList);
                                } else if (CART_ITEM_TYPE_ACCESSORY.equals(cartItem.getCartItemType()) && !cartItem.getAppleCareAccessoryFlag()) {
                                    lineHasAccessory = true;
                                }
                            }
                            if (lineHasAccessory) {
                                if (lineDetails.getLinesWithAcc() == null) {
                                    lineDetails.setLinesWithAcc(new ArrayList<String>());
                                }
                                mobileNumber = mobileNumber != null ? mobileNumber : cartLineInfo.getMobileNumber();
                                lineDetails.getLinesWithAcc().add(mobileNumber);
                                lineHasAccessory = false;
                            }
                            mobileNumber = null;
                        }
                    }
                }
            }
        }
    }

    private void activateLines(LineDetails lineDetails, CXPLineInfo[] lineInfo) {
        List<Object> eupLines = new ArrayList<>();
        List<String> aalLines = new ArrayList<>();
        List<String> nseLines = new ArrayList<>();
        List<Object> byodLines = new ArrayList<>();
        List<Object> byodEUPLines = new ArrayList<>();
        if (ArrayUtils.isNotEmpty(lineInfo)) {
            for (CXPLineInfo cartLineInfo : lineInfo) {
                switch (cartLineInfo.getLineActivityType()) {
                    case LINE_ACTIVITY_TYPE_EUP_LINES:
                        eupLines.add(cartLineInfo.getMobileNumber());
                        lineDetails.setEupLines(eupLines);
                        break;
                    case LINE_ACTIVITY_TYPE_AAL_LINES:
                        aalLines.add(cartLineInfo.getMobileNumber());
                        lineDetails.setAalLines(aalLines);
                        break;
                    case LINE_ACTIVITY_TYPE_NSE_LINES:
                        nseLines.add(cartLineInfo.getMobileNumber());
                        lineDetails.setNseLines(nseLines);
                        break;
                    case LINE_ACTIVITY_TYPE_BYOD_LINES:
                        byodLines.add(cartLineInfo.getMobileNumber());
                        lineDetails.setByodLines(byodLines);
                        break;
                    case LINE_ACTIVITY_TYPE_BYOD_LINES_LOGIN:
                        byodLines.add(cartLineInfo.getMobileNumber());
                        lineDetails.setByodLines(byodLines);
                        break;
                    case LINE_ACTIVITY_TYPE_BYOD_EUP_LINES:
                        byodEUPLines.add(cartLineInfo.getMobileNumber());
                        lineDetails.setByodEUPLines(byodEUPLines);
                        break;
                    default:break;
                }
            }
        }

    }

    private Map<String, CxpCartLineInfo> getLineinfo(CXPLineInfo[] lineInfo, CXPOrderDetails orderDetails) {
        Map<String, CxpCartLineInfo> line1List = new HashMap<>();
        if (ArrayUtils.isNotEmpty(lineInfo)) {
            List<CXPLineInfo> cxpLineInfos = Arrays.asList(lineInfo);
            cxpLineInfos.forEach(cxpLineInfo -> {
                CxpCartLineInfo line1 = new CxpCartLineInfo();
                line1.setIsCommonPDP(null != cxpLineInfo.getIsCommonPDP() ? cxpLineInfo.getIsCommonPDP() : Boolean.FALSE);
                line1.setIsTradeInIntentSelected(null != cxpLineInfo.getIsTradeInIntentSelected() ? cxpLineInfo.getIsTradeInIntentSelected() : Boolean.FALSE);
                line1.setMultiLineSeqNumber(null != cxpLineInfo.getMultiLineSeqNumber() ? cxpLineInfo.getMultiLineSeqNumber() : 0);
                line1.setLineActivityType(null != cxpLineInfo.getLineActivityType() ? cxpLineInfo.getLineActivityType() : "");
                line1.setMobileNumber(null != cxpLineInfo.getMobileNumber() ? cxpLineInfo.getMobileNumber() : "");
                line1.setLineRefundTotal(cxpLineInfo.getLineRefundTotal());
                line1.setLineExchangeTotal(cxpLineInfo.getLineExchangeTotal());
                line1.setCpe(null != cxpLineInfo.getIsCpe() ? cxpLineInfo.getIsCpe() : Boolean.FALSE);
                line1.setTotalDueToday(null != cxpLineInfo.getTotalDueToday() ? cxpLineInfo.getTotalDueToday() : 0.0);
                line1.setTotalDueTodayWithoutTax(null != cxpLineInfo.getTotalDueTodayWithoutTax() ? cxpLineInfo.getTotalDueTodayWithoutTax() : 0.0);
                line1.setTotalDueMonthly(null != cxpLineInfo.getTotalDueMonthly() ? cxpLineInfo.getTotalDueMonthly() : 0.0);
                line1.setServiceInfo(cxpLineInfo.getServiceInfo());
                setItems(line1, cxpLineInfo.getItemsInfo(), orderDetails, cxpLineInfo);
                line1.setInstallmentInfo(cxpLineInfo.getInstallmentInfo());
                line1.setInstallmentContractDetail(cxpLineInfo.getInstallmentContractDetail());
                line1.setMtnDetails(cxpLineInfo.getMtnDetails());
                line1.setBundleAccessoryInfo(cxpLineInfo.getBundleAccessoryInfo());
                line1.setVisFeatures(getVisFeatureFiltered(cxpLineInfo.getServiceInfo(), 1));
                line1.setAccountLevelProtection(getVisFeatureFiltered(cxpLineInfo.getServiceInfo(), 2));
                line1.setVerizonHomeProtect(getVisFeatureFiltered(cxpLineInfo.getServiceInfo(), 3));
                line1.setVerizonHomeDeviceAdvisor(getVisFeatureFiltered(cxpLineInfo.getServiceInfo(), 4));
                line1.setShipping(getShipping(cxpLineInfo));
                line1.setLineNumber(null != cxpLineInfo.getLineNumber() ? cxpLineInfo.getLineNumber() : "");
                line1.setDeviceTypeSelected(null != cxpLineInfo.getDeviceTypeSelected() ? cxpLineInfo.getDeviceTypeSelected() : "");
                line1.setReasonCode(null != cxpLineInfo.getReasonCode() ? cxpLineInfo.getReasonCode() : "");
                line1.setDevicePlanCompatible(null != cxpLineInfo.getIsDevicePlanCompatible() ? cxpLineInfo.getIsDevicePlanCompatible() : Boolean.FALSE);
                line1.setCarLine(null != cxpLineInfo.getIsCarLine() ? cxpLineInfo.getIsCarLine() : Boolean.FALSE);
                line1.setShowGlobalChoiceOffer(null != cxpLineInfo.getShowGlobalChoiceOffer() ? cxpLineInfo.getShowGlobalChoiceOffer() : Boolean.FALSE);
                line1.setBuyOutDetail(cxpLineInfo.getBuyOutDetail());
                line1.setEdgeUpDetail(cxpLineInfo.getEdgeUpDetail());
                line1.setOneTimeCharges((ArrayList)cxpLineInfo.getOneTimeCharges());
                line1.setPromoIntent(cxpLineInfo.getPromoIntent());
                line1.setDeviceCategoryName(cxpLineInfo.getDeviceCategoryName());
                line1.setTotalItemMonthlyDiscountedPrice(cxpLineInfo.getTotalItemMonthlyDiscountedPrice());
                line1.setTotalPriceOfPlanAndPerks(cxpLineInfo.getTotalPriceOfPlanAndPerks());
                line1.setTotalPlanPerksWithAutopay(cxpLineInfo.getTotalPlanPerksWithAutopay());
                line1.setPreOrBackOrder(cxpLineInfo.getPreOrBackOrder());
                line1.setSecondNumber(cxpLineInfo.getSecondNumber());
                if(cxpLineInfo.getServiceInfo() != null && cxpLineInfo.getServiceInfo().getPlanDiscount() != null
                        && cxpLineInfo.getServiceInfo().getPlanDiscount().getEligibleAutoPayPaperlessDiscount() != null
                        && cxpLineInfo.getServiceInfo().getPlanDiscount().getTotalPlanCostIncludingLineAccessFee() != null) {
                    line1.setTotalPlanPriceWithAutopay(String.valueOf((Double.valueOf(cxpLineInfo.getServiceInfo().getPlanDiscount().getTotalPlanCostIncludingLineAccessFee())
                            - Double.valueOf(cxpLineInfo.getServiceInfo().getPlanDiscount().getEligibleAutoPayPaperlessDiscount()))));
                }
                if(StringUtilities.isNotEmptyOrNull(cxpLineInfo.getTotalPriceOfPerksAndProtection())) {
                    line1.setTotalPriceOfPerksAndProtection(cxpLineInfo.getTotalPriceOfPerksAndProtection());
                }
                line1List.put(cxpLineInfo.getMobileNumber(), line1);
            });
        }
        return line1List;

    }

    private Shipping getShipping(CXPLineInfo cxpLineInfo) {
        Shipping shipping = new Shipping();

        if (null!=cxpLineInfo && ArrayUtils.isNotEmpty(cxpLineInfo.getItemsInfo())) {
            List<CXPItemInfo> cxpItemsInfo = Arrays.asList(cxpLineInfo.getItemsInfo());
            CXPShippingVO cxpShipping = cxpItemsInfo.get(0).getShipping();
            if (cxpShipping != null) {
                shipping.setShippingCost(cxpShipping.getShippingCost());
                shipping.setIsValidAddress(cxpShipping.getIsValidAddress());
                shipping.setIsUseUnVerifiedAddress(cxpShipping.getIsUseUnVerifiedAddress());
                shipping.setAddress(getAddress(cxpShipping.getAddress()));
                shipping.getAddress().setFipsCode(cxpShipping.getAddress() != null
                        ? cxpShipping.getAddress().getFipsCode() : "");
            }
        }
        return shipping;
    }

    private ShippingAddress getAddress(Address cxpAddress) {
        ShippingAddress address = new ShippingAddress();
        if (cxpAddress != null) {
            BeanUtils.copyProperties(cxpAddress, address);
        }

        return address;
    }

    private VisFeatures getVisFeatureFiltered(ServiceInfo serviceInfo, int outputType) {
        VisFeatures visFeatures = new VisFeatures();
        if (serviceInfo != null) {
            SelectedFeaturesList selectedFeaturesList = serviceInfo.getSelectedFeaturesList();
            if (null != selectedFeaturesList && null != selectedFeaturesList.getVisFeature()) {
                for (VisFeature cxpVisFeatures :
                        selectedFeaturesList.getVisFeature()) {
                    VisFeature protection = new VisFeature();
                    BeanUtils.copyProperties(cxpVisFeatures, protection);
                    if (outputType == 2 && ("A".equalsIgnoreCase(cxpVisFeatures.getAddDeleteInd()) ||
                            "Z".equalsIgnoreCase(cxpVisFeatures.getAddDeleteInd()))
                            && "SPO".equalsIgnoreCase(cxpVisFeatures.getType()) && cxpVisFeatures.getProtection()) {
                        visFeatures.setProtection(protection);
                    } else if (outputType == 1
                            && ("A".equalsIgnoreCase(cxpVisFeatures.getAddDeleteInd()) || "Z".equalsIgnoreCase(cxpVisFeatures.getAddDeleteInd()))
                            && ("USER".equalsIgnoreCase(cxpVisFeatures.getSource())
                            || "EXISTING".equalsIgnoreCase(cxpVisFeatures.getSource())
                            || "FOM".equalsIgnoreCase(cxpVisFeatures.getSource()))
                            && "L".equalsIgnoreCase(cxpVisFeatures.getLevel())
                            && cxpVisFeatures.getProtection()) {
                        visFeatures.setProtection(protection);
                    } else if (outputType == 3 && "A".equalsIgnoreCase(cxpVisFeatures.getAddDeleteInd())
                            && "SPO".equalsIgnoreCase(cxpVisFeatures.getType()) && ("1614".equalsIgnoreCase(cxpVisFeatures.getVisFeatureCode())
                            || (cxpVisFeatures.isHomeProtect() && cxpVisFeatures.getCategoryCodes().stream().anyMatch(str -> str.equalsIgnoreCase(VZHP))))) {
                        visFeatures.setProtection(protection);
                    } else if (outputType == 4 && "A".equalsIgnoreCase(cxpVisFeatures.getAddDeleteInd())
                            && "SPO".equalsIgnoreCase(cxpVisFeatures.getType()) && "1965".equalsIgnoreCase(cxpVisFeatures.getVisFeatureCode())) {
                        visFeatures.setProtection(protection);
                    }

                    if ("A".equalsIgnoreCase(cxpVisFeatures.getAddDeleteInd())
                            && "Y".equalsIgnoreCase(cxpVisFeatures.getCustomerSelected()) && (cxpVisFeatures.getCallFilter() != null
                            && cxpVisFeatures.getCallFilter())) {
                        visFeatures.setCallFilter(protection);
                    }
                }
            }
        }
        return visFeatures;
    }

    private void setItems(CxpCartLineInfo line1, CXPItemInfo[] itemsInfo, CXPOrderDetails orderDetails, CXPLineInfo lineInfo) {

        if (ArrayUtils.isNotEmpty(itemsInfo)) {
            List<CXPItemInfo> cxpItemsInfos = Arrays.asList(itemsInfo);
            cxpItemsInfos.forEach(cxpItemsInfo -> {
                CXPCartItemsVO cartItems = cxpItemsInfo.getCartItems();
                if (cartItems == null) return;
                List<CXPCartItem> cartItemList = Arrays.asList(cartItems.getCartItem());
                if (CollectionUtilities.isNotEmptyOrNull(cartItemList)) {
                    for (CXPCartItem cxpCartItem : cartItemList) {
                        switch (cxpCartItem.getCartItemType()) {
                            case CART_ITEM_CODE_DEVICE:
                                line1.setDeviceItem(cxpCartItem);
                                break;
                            case CART_ITEM_CODE_SIM:
                                line1.setSimItem(cxpCartItem);
                                break;
                            case CART_ITEM_CODE_WARRANTY:
                                line1.setWarrantyItem(cxpCartItem);
                                break;
                            case CART_ITEM_CODE_SHIPPING:
                                line1.setShippingItem(cxpCartItem);
                                break;
                            case CART_ITEM_CODE_ACCESSORIES:
                                if(cxpCartItem.getBundleAccessorySku() != null) {
                                    break;
                                } else if(cxpCartItem.getAppleCareAccessoryFlag()) {
                                    line1.setAppleCare(cxpCartItem);
                                    break;
                                }
                                if (line1.getAccessories() == null) {
                                    List<CXPCartItem> accessoriesItemList = new ArrayList<>();
                                    if(NSE_5G.equalsIgnoreCase(lineInfo.getLineActivityType()) && HELPER_ACCESSORY.equalsIgnoreCase(cxpCartItem.getCartItemType())
                                            && ZERO_ITEM_PRICE.equalsIgnoreCase(cxpCartItem.getItemPrice())) {
                                        accessoriesItemList.remove(cxpCartItem);
                                    } else {
                                        accessoriesItemList.add(cxpCartItem);
                                    }
                                    line1.setAccessories(accessoriesItemList);
                                } else {
                                    line1.getAccessories().add(cxpCartItem);
                                }
                                break;
                            case CART_ITEM_CODE_UPGRADE_FEE:
                                Map<String, Object> upgradeFee = new HashMap<>();
                                if (orderDetails != null) {
                                    orderDetails.setTotalUpgradeFee(null != orderDetails.getTotalUpgradeFee() ? orderDetails.getTotalUpgradeFee() : 0.0 + cxpCartItem.getTotalPriceWithDiscount());
                                    upgradeFee.put("totalPriceWithDiscount", cxpCartItem.getTotalPriceWithDiscount());
                                    upgradeFee.put("itemPrice", cxpCartItem.getItemPrice());
                                    line1.setUpgradeItem(upgradeFee);
                                }
                                break;
                            default:break;
                        }
                    }
                }
            });
        }
    }


}
