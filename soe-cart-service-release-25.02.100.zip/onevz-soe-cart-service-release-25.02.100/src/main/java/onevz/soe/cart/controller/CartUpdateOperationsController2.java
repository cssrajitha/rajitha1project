package onevz.soe.cart.controller;

import static java.util.Comparator.comparing;
import static java.util.stream.Collectors.collectingAndThen;
import static java.util.stream.Collectors.toCollection;

import jakarta.annotation.PostConstruct;
import onevz.cxp.feature.ConfigurationProfile;
import onevz.cxp.feature.Flag;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.exceptions.JsonValidator;
import onevz.soe.cart.helper.*;
import onevz.soe.cart.model.addPromoIntent.AddPromoIntentUIResponse;
import onevz.soe.cart.model.common.CartError;
import org.springframework.beans.BeanUtils;
import onevz.soe.cart.model.addPromoIntent.AddPromoIntent;
import onevz.soe.cart.model.addPromoIntent.AddPromoIntentUIRequest;
import onevz.soe.cart.model.common.SecondNumber;
import onevz.soe.cart.model.edgeup.EdgeUp;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.CalculateMultilineTaxUIResponse;
import onevz.soe.cart.ui.responses.SwitchFulfillmentUIRes;
import onevz.soe.cart.ui.responses.UpdateWFMInfoUIResponse;
import onevz.soe.cart.util.*;
import onevz.soe.spring.web.filter.RequestAccessContext;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import jakarta.validation.Valid;
import reactor.util.function.Tuple2;

import java.time.Duration;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@RestController
@RequestMapping(value = "cart")
public class CartUpdateOperationsController2 {

    private static final Logger logger = LoggerFactory.getLogger(CartUpdateOperationsController.class);
    @Autowired
    private RedisHelper redisHelper;
    @Autowired
    private RedisHelper2 redisHelper2;
    @Autowired
    JsonValidator validator;
    @Autowired
    private UpdateCartHelper helper;
    @Autowired
    private CartAddDeviceHelper deviceHelper;
    @Autowired
    private CartServiceCxpHelper cartSvcCXPHelper;
    @Autowired
    private CommonUtil util;

    @Autowired
    private FeatureFlagHelper featureFlagHelper;

    @Value("#{'${sessionCreation.domains:.verizon.com}'.split(',')}")
    private List<String> domains;

    @InitBinder("*")
    public void initBinderByName(WebDataBinder binder) {
        binder.setDisallowedFields(new String[] { "genericHeader" });
    }

    @PostMapping("/addDeviceWithBuyout")
    public Mono<ResponseEntity<GenericResponse>> addDeviceWithBuyout(ServerHttpRequest httpHeader,
                                                                     ServerHttpResponse httpResponse, @Valid @RequestBody AddDeviceUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "addDeviceWithBuyout");
        logger.debug("add-device with buyout Request: {}", request);

        return featureFlagHelper.isTradeInPromoCheckFflagEnabled().flatMap(tradeinpromoflag -> {
            if (request.getCartInfo().getMtnFlow() != null && (("G").equalsIgnoreCase(request.getCartInfo().getMtnFlow()) ||
                    (request.getCartInfo().isMyvPage() && ("M").equalsIgnoreCase(request.getCartInfo().getMtnFlow())))){
                return redisHelper.getDataFromRedisAsString().flatMap(data -> {
                    List<String> mtns = new ArrayList<>();
                    List<Boolean> isEdgeBuyoutFlagList = new ArrayList<>();
                    List<SecondNumber> secondNumberList=new ArrayList<>();
                    for (Lines line : request.getData().getLines()) {
                        mtns.add(line.getMtn());
                        if (line.getIsEdgeBuyOut() != null)
                            isEdgeBuyoutFlagList.add(line.getIsEdgeBuyOut());
                        if(line.getSecondNumber()!=null)
                            secondNumberList.add(line.getSecondNumber());
                    }
                List<Lines> newLines;
                if(tradeinpromoflag){
                    Map<String,Lines> requestlinesMap = request.getData().getLines().stream().collect(Collectors.toMap(Lines::getMtn, Function.identity()));
                    newLines = mtns.stream().flatMap(mtn ->{
                        List<Lines> datalines = Optional.ofNullable(data.getLines())
                                .orElse(request.getData().getLines());
                        return  datalines.stream().map(line -> {
                            line.setMtn(mtn);
                            Lines requestLine = requestlinesMap.get(line.getMtn());
                            if (null != requestLine && null != requestLine.getTradeInPromoSelected()) {
                                line.setTradeInPromoSelected(requestLine.getTradeInPromoSelected());
                            }
                            return line;
                        });
                    }).collect(collectingAndThen(toCollection(() -> new TreeSet<>(comparing(Lines::getMtn))), ArrayList::new));
                }
                else {
                    newLines = mtns.stream().flatMap(mtn -> Optional.ofNullable(data.getLines())
                            .orElse(request.getData().getLines()).stream().map(line -> {
                                line.setMtn(mtn);
                                return line;
                            })).collect(collectingAndThen(toCollection(() -> new TreeSet<>(comparing(Lines::getMtn))), ArrayList::new));
                }

                List<Lines> newLines1 = isEdgeBuyoutFlagList.stream()
                            .flatMap(isEdgeBuyout -> newLines.stream().map(line -> {
                                line.setIsEdgeBuyOut(isEdgeBuyout);
                                line.setPurchasePath(request.getCartInfo().getIntendType());
                                line.setSecondNumber(null);
                                return line;
                            })).collect(Collectors.toList());
                    if(CollectionUtilities.isNotEmptyOrNull(secondNumberList)) {
                        List<Lines> secondNumberLineList=new ArrayList<>();
                        secondNumberList.forEach(secondNumber -> {
                            newLines1.stream().filter(newLine -> newLine!=null && secondNumber!=null && secondNumber.getIsSecondNumber()!=null && secondNumber.getIsSecondNumber() && newLine.getMtn()!=null && secondNumber.getPrimaryMtn()!=null && newLine.getMtn().equalsIgnoreCase(secondNumber.getPrimaryMtn()))
                                    .forEach(line -> {
                                        Lines secondNumLine = new Lines();
                                        BeanUtils.copyProperties(line, secondNumLine);
                                        secondNumLine.setMtn(secondNumber.getSecondMtn());
                                        secondNumLine.setPurchasePath(CartConstants.EUPBYOD);
                                        secondNumLine.setSecondNumber(secondNumber);
                                        secondNumLine.setIsEdgeBuyOut(null);
                                        secondNumberLineList.add(secondNumLine);
                                    });

                        });

                        newLines1.addAll(secondNumberLineList.stream().collect(collectingAndThen(toCollection(() -> new TreeSet<>(comparing(Lines::getMtn))),
                                ArrayList::new)));
                    }
                    request.getData().setLines(newLines1);
                    return handleError(httpHeader, httpResponse, request, data);
                });
            } else {
                ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDeviceMtnFlow(request.getCartInfo().getMtnFlow());

                return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
            }
        });
    }

    @PostMapping("/addDeviceWithEdgeup")
    public Mono<ResponseEntity<GenericResponse>> addDeviceWithEdgeup(ServerHttpRequest httpHeader,
                                                                     ServerHttpResponse httpResponse, @Valid @RequestBody AddDeviceUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "addDeviceWithEdgeup");
        logger.debug("add-device with buyout Request: {}", request);
        return featureFlagHelper.isTradeInPromoCheckFflagEnabled().flatMap(tradeinpromoflag -> {
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        if (request.getCartInfo().getMtnFlow() != null && (("G").equalsIgnoreCase(request.getCartInfo().getMtnFlow()) ||
                (request.getCartInfo().isMyvPage() && ("M").equalsIgnoreCase(request.getCartInfo().getMtnFlow())))){
            return redisHelper.getDataFromRedisAsString().flatMap(data -> {
                List<String> mtns = new ArrayList<>();
                List<Boolean> isEdgeBuyoutFlagList = new ArrayList<>();
                List<EdgeUp> edgeUpList = new ArrayList<>();
                List<SecondNumber> secondNumberList=new ArrayList<>();
                List<String> secondNumberMTNList = new ArrayList<>();
                for (Lines line : request.getData().getLines()) {
                    mtns.add(line.getMtn());
                    if (line.getIsEdgeBuyOut() != null)
                        isEdgeBuyoutFlagList.add(line.getIsEdgeBuyOut());
                    if (line.getEdgeup() != null)
                        edgeUpList.add(line.getEdgeup());
                    if (line.getSecondNumber() != null) {
                        secondNumberList.add(line.getSecondNumber());
                        if (!StringUtils.isEmpty(line.getSecondNumber().getSecondMtn()))
                            secondNumberMTNList.add(line.getSecondNumber().getSecondMtn());
                    }
                }
                List<Lines> newLines = mtns.stream().flatMap(mtn -> Optional.ofNullable(data.getLines())
                        .map(lines -> {
                            // Strictly primary & secondary MDN Scenario : Filter out the secondary MDN Lines , do not touch blank MDN Lines
                            if (lines.size() < 2)
                                return lines;

                            return lines.stream().filter(line -> (StringUtils.isEmpty(line.getMtn()) || !secondNumberMTNList.contains(line.getMtn()))).collect(Collectors.toList());
                        })
                        .orElse(request.getData().getLines()).stream()
                        .map(line -> {
                            line.setMtn(mtn);
                            //  DOPMO-193770 - Tradein is invalid for return and upgrade. so removing tradin promo info from request to pega for edgeup scenario
                            if (null != line && line.getSelectedPromoType() != null && line.getSelectedPromoType().equalsIgnoreCase("TRADEIN_PROMO") && CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId))) {
                                line.setTradeInInfo(null);
                                line.setSelectedPromoType("NOPROMO");
                                line.setSelectedPromoId(null);
                                line.setPromoRejectionIndicator(true);
                            }
                            return line;
                        })).collect(collectingAndThen(toCollection(() -> new TreeSet<>(comparing(Lines::getMtn))), ArrayList::new));
                Map<String,Lines> requestlinesMap = request.getData().getLines().stream().collect(Collectors.toMap(Lines::getMtn, Function.identity()));
                List<Lines> newLines1 = edgeUpList.stream().flatMap(edgeup -> newLines.stream().map(line -> {
                    line.setEdgeup(edgeup);
                    line.setPurchasePath(request.getCartInfo().getIntendType());
                    Lines requestLine = requestlinesMap.get(line.getMtn());
                    if(null!=requestLine && null !=requestLine.getTradeInPromoSelected() && tradeinpromoflag )
                    {
                        line.setTradeInPromoSelected(requestLine.getTradeInPromoSelected());
                    }
                    return line;
                })).collect(Collectors.toList());
                if(CollectionUtilities.isNotEmptyOrNull(secondNumberList)) {
                    List<Lines> secondNumberLineList=new ArrayList<>();
                    secondNumberList.forEach(secondNumber -> {
                        newLines1.stream().filter(newLine -> newLine!=null && secondNumber!=null && secondNumber.getIsSecondNumber()!=null && secondNumber.getIsSecondNumber() && newLine.getMtn()!=null && secondNumber.getPrimaryMtn()!=null && newLine.getMtn().equalsIgnoreCase(secondNumber.getPrimaryMtn()))
                                .forEach(line -> {
                                    Lines secondNumLine = new Lines();
                                    BeanUtils.copyProperties(line, secondNumLine);
                                    secondNumLine.setMtn(secondNumber.getSecondMtn());
                                    secondNumLine.setPurchasePath(CartConstants.EUPBYOD);
                                    secondNumLine.setSecondNumber(secondNumber);
                                    secondNumLine.setEdgeup(null);
                                    secondNumberLineList.add(secondNumLine);
                                });

                    });
                    newLines1.addAll(secondNumberLineList.stream().collect(collectingAndThen(toCollection(() -> new TreeSet<>(comparing(Lines::getMtn))), ArrayList::new)));
                }
                request.getData().setLines(newLines1);
                return handleError(httpHeader, httpResponse, request, data);
            });
        } else {
            ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDeviceMtnFlow(request.getCartInfo().getMtnFlow());
            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
        }
    });
    }

    private Mono<ResponseEntity<GenericResponse>> handleError(ServerHttpRequest httpHeader,
                                                              ServerHttpResponse httpResponse, AddDeviceUIRequest request, CartRedisData data) {
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        if (null != data.getDeviceCartInfo() && null != data.getDeviceCartInfo().getNumberShareCapable()) {
            request.getCartInfo().setNumberShareCapable(data.getDeviceCartInfo().getNumberShareCapable());
        }
        if (null != data.getDeviceCartInfo() && null != data.getDeviceCartInfo().getENineAddrIndicator()) {
            request.getCartInfo().setENineAddrIndicator(data.getDeviceCartInfo().getENineAddrIndicator());
        }
        ErrorResponse errorResponse = CartPegaRequestErrorsUtil.handleAddDeviceRequestErrors(request);
        if (CollectionUtilities.isNotEmptyOrNull(errorResponse.getErrors())) {
            ErrorResponse errors = validator.convertObjectToString(errorResponse);
            if (null != errors) {
                return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
            }
        }
        if(data.getDeviceCartInfo() != null && request.getCartInfo() != null){
            if(data.getDeviceCartInfo().getIsPromoPDP() != null && Boolean.TRUE.equals(data.getDeviceCartInfo().getIsPromoPDP())){
                request.getCartInfo().setIsPromoPDP(data.getDeviceCartInfo().getIsPromoPDP());
            }
            if(data.getDeviceCartInfo().getNoPendingOfferExists() != null && Boolean.TRUE.equals(data.getDeviceCartInfo().getNoPendingOfferExists())){
                request.getCartInfo().setNoPendingOfferExists(data.getDeviceCartInfo().getNoPendingOfferExists());
            }
        }
        if(data.getDeviceCartInfo() != null && data.getDeviceCartInfo().getIsPromoPDP() != null
                && Boolean.TRUE.equals(data.getDeviceCartInfo().getIsPromoPDP()) && request.getCartInfo() != null){
            request.getCartInfo().setIsPromoPDP(data.getDeviceCartInfo().getIsPromoPDP());
        }
        if(data.getDeviceCartInfo() != null && data.getDeviceCartInfo().getNoPendingOfferExists() != null
                && Boolean.TRUE.equals(data.getDeviceCartInfo().getNoPendingOfferExists()) && request.getCartInfo() != null){
            request.getCartInfo().setNoPendingOfferExists(data.getDeviceCartInfo().getNoPendingOfferExists());
        }
        request.setChannelId(channelId);
        request.setHttpRequest(httpHeader);
        request.setHttpResponse(httpResponse);
        return deviceHelper.addDevice(request,httpResponse).map(pegaResponse -> {
            ErrorResponse errors2 = null;
            if (pegaResponse.getErrors() != null && !httpResponse.getStatusCode().is2xxSuccessful()) {
                errors2 = CartPegaResponseErrorsUtil.handleAddDeviceResponseErrors(pegaResponse);
            }
            else {
                CartAddDeviceUtil.createCookieCartCount(httpResponse,pegaResponse, CartConstants.EXISTING_CART_COUNT,domains);
            }
            //clearing out the upgrade buyout mtn cache details when pegaResponse is successful
            if (Objects.isNull(pegaResponse.getErrors())) {
                redisHelper2.deleteSessionDataKeyFromRedis(CartConstants.UPGRADE_BUYOUT_MTN_DETAILS);
            }

            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(pegaResponse);
        });
    }

    @PostMapping({"/switch-fulfillment"})
    public Mono<ResponseEntity<GenericResponse>> switchFulfillment(ServerHttpRequest httpHeader,
                                                                   ServerHttpResponse httpResponse,@Valid @RequestBody ExCustIndirectRemoveLinesServiceUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, httpHeader.getPath().value());
        logger.debug("exCustAddLines Request: {}", request);

        ErrorResponse errorResponse = CartPegaRequestErrorsUtil.indirectCustRequestErrors(request);
        if (CollectionUtilities.isNotEmptyOrNull(errorResponse.getErrors())) {
            ErrorResponse errors = validator.convertObjectToString(errorResponse);
            if (null != errors) {
                return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
            }
        }

        return helper.exCustremoveLines(request).flatMap(pegaResponse-> {
            SwitchFulfillmentUIRes switchFulfillmentUIRes=new  SwitchFulfillmentUIRes();
            switchFulfillmentUIRes.setServiceHeader(pegaResponse.getServiceHeader());
            switchFulfillmentUIRes.setServiceBody(pegaResponse.getServiceBody());
            switchFulfillmentUIRes.setExceptions(pegaResponse.getExceptions());

            return pegaResponse.getExceptions() != null ? Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(switchFulfillmentUIRes))
                    : Mono.just(ResponseEntity.status(HttpStatus.OK).body(switchFulfillmentUIRes));
        });
    }


    /**
     *
     * @param httpHeader
     * @param httpResponse
     * @param request
     * @return ResponseEntity
     *
     */
    @PostMapping("/update-giftItem")
    public Mono<ResponseEntity<GenericResponse>> updateGiftItem(ServerHttpRequest httpHeader,
                                                                ServerHttpResponse httpResponse, @Valid @RequestBody UpdateGiftItemUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "update-giftItem");
        logger.debug("update-giftItem Request: {}", request);
        String channelId = getChannelIdFromHeader(httpHeader);
        request.setChannelId(channelId);
        ErrorResponse errors = CartPegaRequestErrorsUtil.handleUpdateGiftItemRequestErrors(request);
        if (errors.getErrors() != null)
            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));

        logger.debug("update-giftItem Request: {}", request);
        return helper.updateGiftItem(request).map(pegaResponse -> {
            ErrorResponse errors2 = null;
            if (pegaResponse.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil2.handleUpdateGiftItemResponseErrors(pegaResponse);
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(pegaResponse);
        });

    }


    @PostMapping(value = { "/updateVzccNBXInfo", "/nse/updateVzccNBXInfo" })
    public Mono<ResponseEntity<GenericResponse>> updateVzccNBXInfo(ServerHttpRequest httpHeader,
                                                                   ServerHttpResponse httpResponse, @Valid @RequestBody UpdateVzccNBXInfoUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "updateVzccNBXInfo");
        logger.debug("updateVzccNBXInfo Request: {}", request);

        ErrorResponse errors = CartCxpRequestErrorsUtil.handleUpdateVzccNBXInfoRequestErrors(request);
        if (errors.getErrors() != null) {
            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
        }
        return helper.updateVzccNBXInfo(request).map(resp -> {
            ErrorResponse errors2 = null;
            if (resp.getErrors() != null) {
                errors2 = CartCxpResponseErrorsUtil.handleUpdateVzccNBXInfoResponseErrors(resp);
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(resp);
        });
    }


    @PostMapping("/updateEffectiveDate")
    public Mono<ResponseEntity<GenericResponse>> updateEffectiveDate(ServerHttpRequest httpHeader,
                                                                     ServerHttpResponse httpResponse, @Valid @RequestBody UpdateEffectiveDateUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "effectiveDate");
        logger.debug("effectiveDate Request: {}", request);
        return helper.updateEffectiveDate(request).map(resp -> {
            ErrorResponse errors2 = null;
            if (resp.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil2.handleEffectiveDateResponseErrors(resp);
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(resp);
        });
    }

    @PostMapping("/updateManualDiscount")
    public Mono<ResponseEntity<GenericResponse>> addManualDiscount(ServerHttpRequest httpHeader,
                                                                   ServerHttpResponse httpResponse, @Valid @RequestBody UpdateManualDiscountUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "updateManualDiscount");
        logger.debug("updateManualDiscount Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);
        ErrorResponse errors = CartPegaRequestErrorsUtil.handleManualDiscountRequestErrors(request);
        if (errors.getErrors() != null)
            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
        return helper.addManualDiscount(request).map(resp -> {
            ErrorResponse errors2 = null;
            if (resp.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil2.handleManualDiscountResponseErrors(resp);
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(resp);
        });
    }

    @PostMapping(path = "/myLinkAgent/indirect/{agentSSOId}/{agentOutletID}")
    public Mono<ResponseEntity<GenericResponse>> postMyLinkAgentSSOCookies(ServerHttpRequest httpHeader,
                                                                           ServerHttpResponse httpResponse, @PathVariable String agentSSOId, @PathVariable String agentOutletID) {
        logger.debug("postMyLinkAgentSSOCookies Request : {}", agentSSOId);
        if (httpHeader != null && httpHeader.getCookies() != null) {
            MultiValueMap<String, HttpCookie> cookie = httpHeader.getCookies();
            if(httpResponse != null && httpResponse.getCookies() != null) {
                if (cookie.get(CartConstants.MYLINK_COOKIE_MY_LINK_AGENT_SITE_ID) != null) {
                    httpResponse.getCookies().remove(CartConstants.MYLINK_COOKIE_MY_LINK_AGENT_SITE_ID);
                }
                if (cookie.get(CartConstants.MYLINK_COOKIE_MY_LINK_AGENT_OUTLET_ID) != null) {
                    httpResponse.getCookies().remove(CartConstants.MYLINK_COOKIE_MY_LINK_AGENT_OUTLET_ID);
                }
            }
        }
        if(null != httpResponse) {
            httpResponse.addCookie(
                    ResponseCookie.from(CartConstants.MYLINK_COOKIE_REP_ID_COOKIE_TEXT, agentSSOId)
                            .maxAge(Duration.ofDays(30)).path("/").httpOnly(false)
                            .build());
            httpResponse.addCookie(
                    ResponseCookie.from(CartConstants.MYLINK_COOKIE_MY_LINK_AGENT_OUTLET_ID, agentOutletID)
                            .maxAge(Duration.ofDays(30)).path("/").httpOnly(false)
                            .build());
        }
        GenericResponse genResp = new GenericResponse();
        genResp.setGenericHeader(CartConstants.STATUS_SUCCESS);
        return Mono.just(ResponseEntity.status(HttpStatus.OK).body(genResp));
    }

    @PostMapping(path = "/myLinkAgent/indirect/{agentSiteId}")
    public Mono<ResponseEntity<GenericResponse>> postMyLinkAgentCookies(ServerHttpRequest httpHeader,
                                                                        ServerHttpResponse httpResponse, @PathVariable String agentSiteId) {
        logger.debug("postMyLinkAgentCookies Request : {}", agentSiteId);
        Map<String, String> agentOutletIdMap = new HashMap<>();
        agentOutletIdMap.put("RUSSELL", "000130855");
        agentOutletIdMap.put("GOWRLS", "000128268");
        agentOutletIdMap.put("CSKNX", "000128257");
        agentOutletIdMap.put("ABCPHONES", "000128253");
        agentOutletIdMap.put("ATIWRLS", "000100151");
        agentOutletIdMap.put("MOOREHEAD", "000100013");
        agentOutletIdMap.put("RWIRELESS", "000107954");
        agentOutletIdMap.put("UNITED", "0001001638");
        agentOutletIdMap.put("MOBILEDEST", "000107356");
        agentOutletIdMap.put("WIRELESSPLUS", "000SC4421");
        agentOutletIdMap.put("CELLULARONLY", "0067800GP");
        agentOutletIdMap.put("WIRELESSWORLD", "000104804");
        agentOutletIdMap.put("BEMOBILE", "0047965GP");
        agentOutletIdMap.put("CELLULARPLUS", "000NW4981");
        agentOutletIdMap.put("KMOBILE", "000107849");
        agentOutletIdMap.put("WALTHAM", "000100028");
        agentOutletIdMap.put("TEAM", "000107520");
        agentOutletIdMap.put("MOBILEGEN", "000107564");

        if (httpHeader != null && httpHeader.getCookies() != null) {
            MultiValueMap<String, HttpCookie> cookie = httpHeader.getCookies();
            if(httpResponse != null && httpResponse.getCookies() != null) {
                if (cookie.get(CartConstants.MYLINK_COOKIE_REP_ID_COOKIE_TEXT) != null) {
                    httpResponse.getCookies().remove(CartConstants.MYLINK_COOKIE_REP_ID_COOKIE_TEXT);
                }
            }
        }

        if (!StringUtils.isEmpty(agentOutletIdMap.get(agentSiteId)) && null != httpResponse) {
            httpResponse.addCookie(
                    ResponseCookie.from(CartConstants.MYLINK_COOKIE_MY_LINK_AGENT_SITE_ID, agentSiteId)
                            .maxAge(Duration.ofDays(30)).path("/").httpOnly(false)
                            .build());
            httpResponse.addCookie(
                    ResponseCookie.from("MyLinkSalesDomain", "VanityFlow")
                            .maxAge(Duration.ofDays(30)).path("/").httpOnly(false)
                            .build());
            httpResponse.addCookie(
                    ResponseCookie.from(CartConstants.MYLINK_COOKIE_MY_LINK_AGENT_OUTLET_ID, agentOutletIdMap.get(agentSiteId))
                            .maxAge(Duration.ofDays(30)).path("/").httpOnly(false)
                            .build());
        }
        GenericResponse genResp = new GenericResponse();
        genResp.setGenericHeader(CartConstants.STATUS_SUCCESS);
        return Mono.just(ResponseEntity.status(HttpStatus.OK).body(genResp));
    }

    @PostMapping("/removeOffers")
    public Mono<ResponseEntity<GenericResponse>> removeBvoOffers(ServerHttpRequest httpHeader,
                                                                 ServerHttpResponse httpResponse, @Valid @RequestBody UpdateBvoOffersUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "removeOffers");
        logger.debug("removeOffers Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);

        return helper.removeBvoOffers(request).map(pegaResponse -> {
            ErrorResponse errors2 = null;
            if (pegaResponse.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil.handleRemoveBvoOffersResponseErrors(pegaResponse);
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(pegaResponse);
        });
    }


    @PostMapping("/nse/updateAccountPin")
    public Mono<ResponseEntity<GenericResponse>> updateAccountpin(ServerHttpRequest httpHeader,
                                                                  ServerHttpResponse httpResponse, @Valid @RequestBody AccountPinUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "updateAccountPin");
        logger.debug("updateAccountPin Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);
        ErrorResponse errors = CartPegaRequestErrorsUtil.handleAccountPinRequestErrors(request);
        if (errors.getErrors() != null)
            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));


        String sessionId = "";
        HttpCookie cookieDigitIgSession = httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION);
        if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId))
                || CartConstants.EXPRESS_STORE.equalsIgnoreCase(CartUtil.getChannelType(channelId)))
            sessionId = null != cookieDigitIgSession
                    ? cookieDigitIgSession.getValue()
                    : "";

        if (StringUtilities.isNotEmptyOrNull((sessionId))) {
            request.getCartInfo().setSessionId(sessionId);
        }
        return helper.updateAccountPin(request).map(pegaResponse -> {
            ErrorResponse errors2 = null;
            if (pegaResponse.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil2.handleAccountPinResponseErrors(pegaResponse);
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(pegaResponse);
        });
    }

    @PostMapping("/updateTradeInOffer")
    public Mono<ResponseEntity<GenericResponse>> updateTradeInOffer(ServerHttpRequest httpHeader,
                                                                    ServerHttpResponse httpResponse, @Valid @RequestBody UpdateTradeInOfferUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "UpdateTradeInOffer");
        logger.debug("update-cart Request: {}", request);
        List<String> channelIdList = httpHeader.getHeaders().get(CartConstants.CHANNEL_ID);
        if (httpHeader.getHeaders() != null && channelIdList != null
                && !channelIdList.isEmpty())
            request.setChannelId(channelIdList.get(0));

        return helper.updateTradeInOffer(request).map(cxpResponse -> {
            ErrorResponse errors2 = null;
            if (cxpResponse.getErrors() != null) {
                errors2 = CartCxpResponseErrorsUtil.handleUpdateTradeInOfferResponseErrors(cxpResponse);
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(cxpResponse);
        });

    }

    @PostMapping("/updateWFMInfo")
    public Mono<ResponseEntity<GenericResponse>> updateWFMInfo(ServerHttpRequest httpHeader,
                                                               ServerHttpResponse httpResponse, @Valid @RequestBody UpdateWFMInfoUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "updateWFMInfo");
        logger.debug("updateWFMInfo Request: {}", request);
        logger.info("updateWFMInfo Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);
        ErrorResponse errors = CartPegaRequestErrorsUtil.handleUpdateWFMInfoRequestErrors(request);
        if (errors.getErrors() != null)
            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
        try {
            Mono<UpdateWFMInfoUIResponse> response = helper.updateWFMInfo(request);
            logger.info("updateWFMInfo response: {}", response);
            return response.map(pegaResponse -> {
                ErrorResponse errors2 = null;
                if (pegaResponse.getErrors() != null) {
                    errors2 = CartPegaResponseErrorsUtil.handleUpdateWFMInfoResponseErrors(pegaResponse);
                }
                return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                        : ResponseEntity.status(HttpStatus.OK).body(pegaResponse);
            });
        } catch (Exception e) {
            logger.error("Failed to update WFM Info :", e);
            StackTraceElement[] elements = e.getStackTrace();
            if(elements!=null && elements.length>0 && elements[0]!=null)
                logger.error("exception fileName: " + elements[0].getFileName() + ", lineNumber : " + elements[0].getLineNumber());
            return Mono.empty();
        }
    }

    @PostMapping(value = {"/updateChatId", "/nse/updateChatId"})
    public Mono<ResponseEntity<GenericResponse>> updateChatId(ServerHttpRequest httpHeader,
                                                              ServerHttpResponse httpResponse, @Valid @RequestBody UpdateChatIdUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "updateChatId");
        logger.debug("updateChatId Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);
        ErrorResponse errors = CartPegaRequestErrorsUtil.handleUpdateChatIdRequestErrors(request);
        if (errors.getErrors() != null) {
            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
        }
        return helper.updateChatId(request).flatMap(resp -> {
            ErrorResponse errors2 = null;
            if (resp.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil.handleUpdateChatIdResponseErrors(resp);
                return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(errors2));
            } else {
                if (StringUtilities.isNotEmptyOrNull(request.getChatId())) {
                    return redisHelper2.updateChatId(request.getChatId()).flatMap(data -> {
                        return Mono.just(ResponseEntity.status(HttpStatus.OK).body(resp));
                    });
                }
            }
            return Mono.just(ResponseEntity.status(HttpStatus.OK).body(resp));
        });
    }

    @PostMapping(value = { "/vzccFeedbackStatus", "/nse/vzccFeedbackStatus" })
    public Mono<ResponseEntity<GenericResponse>> updateVZCCAppStatus(ServerHttpRequest httpHeader,
                                                                     ServerHttpResponse httpResponse, @Valid @RequestBody VZCCAppStatusUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "vzccFeedbackStatus");
        logger.debug("vzccFeedbackStatus Request: {}", request);

        ErrorResponse errors = CartCxpRequestErrorsUtil.handleVZCCAppStatusRequestErrors(request);
        if (errors.getErrors() != null) {
            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
        }
        return helper.updateVZCCAppStatus(request).map(resp -> {
            ErrorResponse errors2 = null;
            if (resp.getErrors() != null) {
                errors2 = CartCxpResponseErrorsUtil.handleVZCCAppStatusResponseErrors(resp);
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(resp);
        });
    }

    @PostMapping({ "/addZipcode", "/nse/addZipcode" })
    public Mono<ResponseEntity<AddZipcodeRedisData>> bbpAddZipCode(ServerHttpRequest httpHeader,
                                                                   ServerHttpResponse httpResponse, @Valid @RequestBody AddZipCodeUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "bbpAddZipcode");
        String flowPath = String.valueOf(httpHeader.getPath());

        AddZipcodeRedisData rr = new AddZipcodeRedisData();
        if (StringUtilities.isNotEmptyOrNull(flowPath)) {
            if (flowPath.contains("nse")) {
                return helper.addZipcode(request).map(data -> {
                    rr.setZipCode(request.getZipCode());
                    rr.setStatus(CartConstants.STATUS_SUCCESS);
                    redisHelper2.upsertBBPFlowZipCodeDataIntoRedis(rr);
                    return ResponseEntity.status(HttpStatus.OK).body(data);
                });
            }
        }
        return util.formatZipcodeRedisData(request, rr);
    }

    private String getChannelIdFromHeader(ServerHttpRequest httpHeader) {
        return httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID) ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID) : "";
    }

    private String getSessionId(ServerHttpRequest httpHeader, String channelId) {
        String sessionId = "";
        HttpCookie cookieDigitIgSession = httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION);
        if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId))
                || CartConstants.EXPRESS_STORE.equalsIgnoreCase(CartUtil.getChannelType(channelId)))
            sessionId = null != cookieDigitIgSession ? cookieDigitIgSession.getValue() : "";
        return sessionId;
    }

    @PostMapping({ "/addNickName", "/nse/addNickName" })
    public Mono<ResponseEntity<GenericResponse>> addNickName(ServerHttpRequest httpHeader,
                                                             ServerHttpResponse httpResponse, @Valid @RequestBody AddNickNameUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "addNickName");
        logger.debug("addNickName Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);
        String sessionId = "";
        HttpCookie cookieDigitIgSession = httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION);
        if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId)))
            sessionId = null != cookieDigitIgSession
                    ? cookieDigitIgSession.getValue()
                    : "";
        request.getCartInfo().setSessionId(sessionId);
        return helper.addNickName(request).map(resp -> {
            ErrorResponse errors2 = null;
            if (resp.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil.handleAddNickNameResponseErrors(resp);
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(resp);
        });
    }

    @PostMapping("/removeTransferUpgrade")
    public Mono<ResponseEntity<GenericResponse>> removeTransferUpgrade(ServerHttpRequest httpHeader,
                                                                       ServerHttpResponse httpResponse, @Valid @RequestBody UpdateTransferUpgradeUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "removeTransferUpgrade");
        logger.debug("removeTransferUpgrade Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);

        ErrorResponse errorResponse = CartPegaRequestErrorsUtil.handleRemoveTransferUpgradeRequestErrors(request);
        if (CollectionUtilities.isNotEmptyOrNull(errorResponse.getErrors())) {
            ErrorResponse errors = validator.convertObjectToString(errorResponse);
            if (null != errors) {
                return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
            }
        }
        return helper.removeTransferUpgrade(request).map(pegaResponse -> {
            ErrorResponse errors2 = null;
            if (pegaResponse.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil.handleUpdateTransferUpgradeResponseErrors(pegaResponse);
            } else {
                List<String> keys = new ArrayList<>();
                keys.add(CartConstants.DONOR_MTN);
                keys.add(CartConstants.RECIPIENT_MTN);
                redisHelper.deleteAlternateUpgradeDataIntoRedis(keys).subscribeOn(Schedulers.parallel())
                        .subscribe(deleted -> {
                            logger.debug("transferUpgrade data deleted from Redis {}", deleted);
                        });
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(pegaResponse);
        });
    }

    @PostMapping("/addTransferUpgrade")
    public Mono<ResponseEntity<GenericResponse>> addTransferUpgrade(ServerHttpRequest httpHeader,
                                                                    ServerHttpResponse httpResponse, @Valid @RequestBody UpdateTransferUpgradeUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "addTransferUpgrade");
        logger.debug("addTransferUpgrade Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);
        ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddTransferUpgradeRequestErrors(request);
        if (errors.getErrors() != null)
            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
        return helper.addTransferUpgrade(request).flatMap(pegaResponse -> {
            ErrorResponse errors2 = null;
            if (pegaResponse.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil.handleUpdateTransferUpgradeResponseErrors(pegaResponse);
                return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(errors2));
            } else {
                Map<String, String> requestMap = new HashMap<>();
                requestMap.put(CartConstants.DONOR_MTN, request.getData().getLines().get(0).getDonorMtn());
                requestMap.put(CartConstants.RECIPIENT_MTN, request.getData().getLines().get(0).getMtn());
                redisHelper.upsertAlternateUpgradeDataIntoRedis(requestMap).subscribeOn(Schedulers.parallel())
                        .subscribe(upserted -> {
                            logger.debug("inEligibleUpgrade data upserted in Redis {}", upserted);
                        });
            }
            return Mono.just(ResponseEntity.status(HttpStatus.OK).body(pegaResponse));
        });
    }

    @PostMapping("/activateOrSetupLater")
    public Mono<ResponseEntity<GenericResponse>> activateOrSetupLater(ServerHttpRequest httpHeader,
                                                                      ServerHttpResponse httpResponse, @Valid @RequestBody ActivateLaterUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "activateOrSetupLater");
        logger.debug("activateLater Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);
        return helper.activateOrSetupLater(request).map(pegaResponse -> {
            ErrorResponse errors2 = null;
            if (pegaResponse.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil.handleActivateLaterResponseErrors(pegaResponse);
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(pegaResponse);
        });
    }

    @PostMapping({ "/calculateMultiLineTaxForCart", "/nse/calculateMultiLineTaxForCart" })
    public Mono<ResponseEntity<GenericResponse>> calculateMultiLineTaxForCart(ServerHttpRequest httpHeader,
                                                                              ServerHttpResponse httpResponse, @Valid @RequestBody CalculateMultilineTaxUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "calculateMultilineTaxForCart");
        logger.debug("calculateMultiLineTaxForCart Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        String flowPath = String.valueOf(httpHeader.getPath());
        if (flowPath != null && !flowPath.isEmpty() && flowPath.contains("nse") &&
                CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId)) &&
                request != null && request.getZipCode() != null) {
            Mono<CalculateMultilineTaxUIResponse> data = helper.calculateMultiLineTaxForCart(request);
            return data.flatMap(response -> {
                ErrorResponse errors2 = null;
                if (response.getErrors() != null) {
                    errors2 = CartCxpResponseErrorsUtil.handleCalculateMultilineTaxResponseErrors(response);
                    return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(errors2));
                }
                if (response != null && response.getData() != null && response.getData().getCalculateMultiLineTaxForCart() != null
                        && response.getData().getCalculateMultiLineTaxForCart().getZipCodeDetails() != null &&
                        response.getData().getCalculateMultiLineTaxForCart().getZipCodeDetails().getNumberOfCitiesFound() != null
                        && response.getData().getCalculateMultiLineTaxForCart().getZipCodeDetails().getNumberOfCitiesFound() > 0) {
                    Mono<AddZipcodeRedisData> zipCodeData = helper.updateZipcodeToCart(channelId, request.getZipCode() != null ? request.getZipCode() : "");
                    return zipCodeData.flatMap(resp -> Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
                }
                return Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));
            });
        }
        return helper.calculateMultiLineTaxForCart(request).map(resp -> {
            ErrorResponse errors2 = null;
            if (resp.getErrors() != null) {
                errors2 = CartCxpResponseErrorsUtil.handleCalculateMultilineTaxResponseErrors(resp);
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(resp);
        });
    }

    @PostMapping({"/cancelCase","/flexV2/cancelCase"})
    public Mono<ResponseEntity<GenericResponse>> cancelCase(ServerHttpRequest httpHeader,
                                                            ServerHttpResponse httpResponse, @Valid @RequestBody CancelCaseUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "cancelCase");
        logger.debug("cancelCase Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);

        if(StringUtilities.isNotEmptyOrNull(httpHeader.getURI().getPath())){
            String path= httpHeader.getURI().getPath();
            if(path.contains("flexV2")){
                request.getCartInfo().setFlexV2(true);
            }
        }
        String channelType = CartUtil.getChannelType(request.getChannelId());
        return redisHelper.getDataFromRedis().flatMap(data-> {
            if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED) && request.getCartInfo().isFlexV2()) {
                if (StringUtilities.isNotEmptyOrNull(data.getCustomerType()) && data.getCustomerType().equalsIgnoreCase("N") && StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType())) {
                    request.getCartInfo().setIntendType("NSE");
                }
            }

        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()) && request.getCartInfo().getIntendType().toUpperCase().contains("NSE")) {
            logger.info("Canceling the case for new customer");
        } else {
            logger.info("Canceling the case for existing customer");
        }
        return helper.cancelCase(request).flatMap(resp -> {
            ErrorResponse errors2 = null;
            if (resp.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil.handleCancelCaseResponseErrors(resp);
                return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(errors2));
            } else {
                return redisHelper.deleteCartIdAndCaseIdFromRedis().flatMap(deleteData -> {
                    return Mono.just(ResponseEntity.status(HttpStatus.OK).body(resp));
                });
            }
        });
        });
    }

    @PostMapping("/splitExceededAmount")
    public Mono<ResponseEntity<GenericResponse>> splitExceededAmount(ServerHttpRequest httpHeader,
                                                                     ServerHttpResponse httpResponse, @Valid @RequestBody SplitExceededAmountUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "splitExceededAmount");
        logger.debug("splitExceededAmount Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);
        return helper.splitExceededAmount(request).map(resp -> {
            ErrorResponse errors2 = null;
            if (resp.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil.handleSplitExceededAmountResponseErrors(resp);
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(resp);
        });
    }

    @PostMapping("/manual-pairing")
    public Mono<ResponseEntity<GenericResponse>> manualPairing(ServerHttpRequest httpHeader,
                                                               ServerHttpResponse httpResponse, @Valid @RequestBody ManualPairingUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "manual-pairing");
        logger.debug("ManualPairing Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);
        return helper.manualPairing(request).map(resp -> {
            ErrorResponse errors2 = null;
            if (resp.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil.handleManualPairingResponseErrors(resp);
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(resp);
        });
    }

    @PostMapping("/voidOrder")
    public Mono<ResponseEntity<GenericResponse>> voidOrder(ServerHttpRequest httpHeader,
                                                           ServerHttpResponse httpResponse, @Valid @RequestBody VoidOrderUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "voidOrder");
        logger.debug("assign-mtn Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);
        return helper.voidOrder(request).map(resp -> {
            ErrorResponse errors2 = null;
            if (resp.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil.handleVoidOrderResponseErrors(resp);
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(resp);
        });
    }

    @PostMapping({ "/ispuToDfill", "/nse/ispuToDfill" })
    public Mono<ResponseEntity<GenericResponse>> ispuToDfill(ServerHttpRequest httpHeader,
                                                             ServerHttpResponse httpResponse, @Valid @RequestBody IspuToDfillUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "ispuToDfill");
        logger.debug("assign-mtn Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);
        String sessionId = "";
        HttpCookie cookieDigitIgSession = httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION);
        if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId))
                || CartConstants.EXPRESS_STORE.equalsIgnoreCase(CartUtil.getChannelType(channelId)))
            sessionId = null != cookieDigitIgSession
                    ? cookieDigitIgSession.getValue()
                    : "";

        request.getCartInfo().setSessionId(sessionId);
        return helper.ispuToDfill(request).map(resp -> {
            ErrorResponse errors2 = null;
            if (resp.getErrors() != null) {
                errors2 = CartCxpResponseErrorsUtil.handleIspuToDfillResponseErrors(resp);
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(resp);
        });
    }

    @PostMapping("/portInLater")
    public Mono<ResponseEntity<GenericResponse>> updatePortInLater(ServerHttpRequest httpHeader,
                                                                   ServerHttpResponse httpResponse, @Valid @RequestBody PortinLaterUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "portInLater");
        logger.debug("updatePortInLater Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);
        return helper.updatePortInLater(request).map(resp -> {
            ErrorResponse errors2 = null;
            if (resp.getErrors() != null) {
                errors2 = CartCxpResponseErrorsUtil.handleUpdatePortInLaterResponseErrors(resp);
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(resp);

        });
    }

    @PostMapping("/revokeRebates")
    public Mono<ResponseEntity<GenericResponse>> revokeRebates(ServerHttpRequest httpHeader,
                                                               ServerHttpResponse httpResponse, @Valid @RequestBody RevokeRebatesUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "revokeRebates");
        logger.debug("revokeRebates Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);
        return helper.revokeRebates(request).map(resp -> {
            ErrorResponse errors2 = null;
            if (resp.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil.handleRevokeRebatesResponseErrors(resp);
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(resp);
        });
    }

    @PostMapping("/enroll-giftPurchase")
    public Mono<ResponseEntity<GenericResponse>> giftPurchase(ServerHttpRequest httpHeader,
                                                              ServerHttpResponse httpResponse, @Valid @RequestBody GiftPurchaseUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "enroll-giftPurchase");
        logger.debug("enroll-giftPurchase Request: {}", request);
        return helper.giftPurchase(request).map(resp -> {
            ErrorResponse errors2 = null;
            if (resp.getErrors() != null) {
                errors2 = CartCxpResponseErrorsUtil.handleGiftPurchaseResponseErrors(resp);
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(resp);
        });
    }

    @PostMapping("/add-fiveGBulkOrder")
    public Mono<ResponseEntity<GenericResponse>> add5GBulkOrder(ServerHttpRequest httpHeader,
                                                                ServerHttpResponse httpResponse, @Valid @RequestBody Add5GBulkOrderUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "add-fiveGBulkOrder");
        logger.debug("add-fiveGBulkOrder Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);
        ErrorResponse errors = CartPegaRequestErrorsUtil.handleAdd5GBulkOrderRequestErrors(request);
        if (errors.getErrors() != null)
            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
        return helper.add5GBulkOrder(request).map(pegaResponse -> {
            ErrorResponse errors2 = null;
            if (pegaResponse.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil.handleAddAdd5GBulkOrderResponseErrors(pegaResponse);
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(pegaResponse);

        });

    }

    @PostMapping("/updatePurchaseOrder")
    public Mono<ResponseEntity<GenericResponse>> updatePurchaseOrder(ServerHttpRequest httpHeader,
                                                                     ServerHttpResponse httpResponse, @Valid @RequestBody UpdatePurchaseOrderUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "updatePurchaseOrder");
        logger.debug("update-cart Request: {}", request);
        return helper.updatePurchaseOrder(request).map(pegaResponse -> {
            ErrorResponse errors2 = null;
            if (pegaResponse.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil.handleUpdatePurchaseOrderResponseErrors(pegaResponse);
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(pegaResponse);
        });

    }

    @PostMapping({ "/deassign-mtn", "/nse/deassign-mtn" })
    public Mono<ResponseEntity<GenericResponse>> deassignMtn(ServerHttpRequest httpHeader,
                                                             ServerHttpResponse httpResponse, @Valid @RequestBody DeassignMtnUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "deassign-mtn");
        logger.debug("deassign-mtn Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);
        String sessionId = "";
        HttpCookie cookieDigitIgSession = httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION);
        if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId))
                || CartConstants.EXPRESS_STORE.equalsIgnoreCase(CartUtil.getChannelType(channelId)))
            sessionId = null != cookieDigitIgSession
                    ? cookieDigitIgSession.getValue()
                    : "";

        request.getCartInfo().setSessionId(sessionId);

        ErrorResponse errorResponse = CartPegaRequestErrorsUtil.handleDeassignMtnRequestErrors(request);
        if (CollectionUtilities.isNotEmptyOrNull(errorResponse.getErrors())) {
            ErrorResponse errors = validator.convertObjectToString(errorResponse);
            if (null != errors) {
                return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
            }
        }
        return helper.deassignMtn(request).map(resp -> {
            ErrorResponse errors2 = null;
            if (resp.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil.handleDeassignMtnResponseErrors(resp);
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(resp);
        });
    }
    @PostMapping({ "/addPromoIntent", "/nse/addPromoIntent" })
    public Mono<ResponseEntity<GenericResponse>> addPromoIntent(ServerHttpRequest httpHeader,
                                                                ServerHttpResponse httpResponse, @Valid @RequestBody AddPromoIntentUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "addPromoIntent");
        logger.debug("addPromoIntent Request: {}", request);
        String channelId=RequestAccessContext.getRequestHeader(CartConstants.CHANNEL_ID);
        request.setChannelId(channelId);
        String sessionId = "";
        HttpCookie cookieDigitIgSession = httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION);
        if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId)))
            sessionId = null != cookieDigitIgSession  ? cookieDigitIgSession.getValue()  : "";

        request.getCartInfo().setSessionId(sessionId);

        ErrorResponse errorResponse = CartPegaRequestErrorsUtil.handleAddPromoIntentRequestErrors(request);
        if (CollectionUtilities.isNotEmptyOrNull(errorResponse.getErrors())) {
            ErrorResponse errors = validator.convertObjectToString(errorResponse);
            if (null != errors) {
                return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
            }
        }
        return featureFlagHelper.mergeFeatureFlagWithResponse(Mono.zip(helper.addPromoIntent(request),featureFlagHelper.fetchDigitalPerformanceCfgProfile())).map(resp -> {
            ErrorResponse errors2 = null;
            if (resp.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil.handleAddPromoIntentUIResponseErrors(resp);
            } else {
                addPromoIntentTagging(request);
                hideSensitiveInfo(resp);
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(resp);
        });
    }

    private void hideSensitiveInfo(onevz.soe.cart.model.addPromoIntent.AddPromoIntentUIResponse resp){
        if(null != resp && null != resp.getServiceBody()
                && null != resp.getServiceBody().getServiceResponse()
                && null !=resp.getServiceBody().getServiceResponse().getContext()
                && null != resp.getServiceBody().getServiceResponse().getContext().getCartInfo())  {
            resp.getServiceBody().getServiceResponse().getContext().setCaseId(null);
            resp.getServiceBody().getServiceResponse().getContext().getCartInfo().setCartId(null);
        }
    }
    @PostMapping( "/addReplenishmentOnlyToCart")
    public Mono<ResponseEntity<GenericResponse>> addReplenishmenttoCart(ServerHttpRequest httpHeader,
                                                                        ServerHttpResponse httpResponse, @Valid @RequestBody AddReplenishmentToCartUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "addReplenishmentOnlyToCart");
        logger.debug("addReplenishmentOnlyToCart Request: {}", request);

        ErrorResponse errorResponse = CartPegaRequestErrorsUtil.handleAddReplenishmenttoCartRequestErrors(request);
        if (CollectionUtilities.isNotEmptyOrNull(errorResponse.getErrors())) {
            ErrorResponse errors = validator.convertObjectToString(errorResponse);
            if (null != errors) {
                return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
            }
        }
        String channelId = getChannelIdFromHeader(httpHeader);
        request.setChannelId(channelId);
        String sessionId = getSessionId(httpHeader, channelId);
        request.getCartInfo().setSessionId(sessionId);
        return helper.addReplenishmentToCart(request).map(resp -> {
            if (CollectionUtilities.isEmptyOrNull(resp.getErrors())) {
                return ResponseEntity.status(HttpStatus.OK).body(resp);
            } else {
                ErrorResponse errors2 = CartPegaResponseErrorsUtil2.handleAddReplenishmentToCartResponseErrors(resp);
                return ResponseEntity.status(httpResponse.getStatusCode()).body(errors2);
            }
        });
    }

    @PostMapping("/effectiveDateOverride")
    public Mono<ResponseEntity<GenericResponse>> effectiveDateOverride(ServerHttpRequest httpHeader,
                                                                       ServerHttpResponse httpResponse, @Valid @RequestBody EffectiveDateOverrideUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "effectiveDateOverride");
        logger.debug("EffectiveDateOverride Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);
        ErrorResponse errors = CartPegaRequestErrorsUtil.handleEffectiveDateOverrideRequestErrors(request);
        if (errors.getErrors() != null)
            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
        return helper.effectiveDateOverride(request).map(resp -> {
            ErrorResponse errors2 = null;
            if (resp.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil.handleEffectiveDateOverrideResponseErrors(resp);
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(resp);
        });
    }

    private void addPromoIntentTagging(AddPromoIntentUIRequest request){
        if(request != null && request.getData() != null && request.getData().getLines() != null && request.getData().getLines().length > 0){
            StringBuilder promosAppliedVal = new StringBuilder();
            getPromosAppliedValue(request, promosAppliedVal);
            if(StringUtilities.isNotEmptyOrNull(promosAppliedVal.toString())){
                cartSvcCXPHelper.updateDLData(null,null,"promosApplied",promosAppliedVal.toString(), null, null);
            }
        }
    }

    private void getPromosAppliedValue(AddPromoIntentUIRequest request, StringBuilder promosAppliedVal) {
        Arrays.stream(request.getData().getLines()).forEach(line -> {
            if(line.getPromoIntent() != null && line.getPromoIntent().length > 0){
                Arrays.stream(line.getPromoIntent()).forEach(addPromoIntent -> {
                    String selectedPromoType = getPromoType(addPromoIntent);
                    String selectedPromoId = getPromotionId(addPromoIntent);
                    String flowType = getFlowType(request);
                    Boolean choiceOffer = addPromoIntent.getChoiceOffer();
                    String sedOfferId = addPromoIntent.getOfferId();
                    String offerType = addPromoIntent.isStrategicOffer() ? CartConstants.STRATEGIC_OFFER : CartConstants.NATIONAL_OFFER;
                    if (StringUtilities.isNotEmptyOrNull(selectedPromoType)) {
                        mapPromos(selectedPromoType,selectedPromoId,sedOfferId,offerType,flowType,promosAppliedVal,choiceOffer);
                    }
                });
            }
        });
    }

    private String getPromoType(AddPromoIntent addPromoIntent) {
        if(StringUtilities.isNotEmptyOrNull(addPromoIntent.getPromoType())){
            return addPromoIntent.getPromoType();
        }
        return "";
    }

    private String getPromotionId(AddPromoIntent addPromoIntent) {
        if(StringUtilities.isNotEmptyOrNull(addPromoIntent.getPromotionId())){
            return addPromoIntent.getPromotionId();
        }
        return "";
    }

    private String getFlowType(AddPromoIntentUIRequest request){
        if (request.getCartInfo() != null && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())){
            return evaluteFlowType(request.getCartInfo().getIntendType());
        }
        return "";
    }

    private String evaluteFlowType(String lineInfoFlowType) {
        if(StringUtilities.isNotEmptyOrNull(lineInfoFlowType)){
            switch (lineInfoFlowType) {
                case CartConstants.BYOD_LINE_ACTIVITY:
                    return "ESO";
                case CartConstants.EUP_BYOD_LINE_ACTIVITY:
                    return "ESO";
                case CartConstants.NSE_BYOD_LINE_ACTIVITY:
                    return "NSO";
                default:
                    return lineInfoFlowType;
            }
        }
        return "";
    }

    private void mapPromos(String promoType, String promotionId, String sedOfferId,  String offerType, String flowType, StringBuilder promos,Boolean choiceOffer){
        String choiceOrBauOffer = (choiceOffer != null && choiceOffer) ? CartConstants.IS_CHOICE_OFFER : CartConstants.IS_BAU_OFFER;
        if(StringUtilities.isNotEmptyOrNull(promotionId) && StringUtilities.isNotEmptyOrNull(sedOfferId)){
            if (StringUtilities.isNotEmptyOrNull(flowType)) {
                promos.append(promoType).append("-").append(promotionId).append("-").append(offerType).append("-").append(choiceOrBauOffer).append("-").append(flowType).append("-").append(sedOfferId).append("|");
            } else {
                promos.append(promoType).append("-").append(promotionId).append("-").append(offerType).append("-").append(choiceOrBauOffer).append("-").append(sedOfferId).append("|");
            }
        } else if(StringUtilities.isNotEmptyOrNull(sedOfferId)) {
            if (StringUtilities.isNotEmptyOrNull(flowType)) {
                promos.append(promoType).append("-").append(offerType).append("-").append(choiceOrBauOffer).append("-").append(flowType).append("-").append(sedOfferId).append("|");
            } else {
                promos.append(promoType).append("-").append(offerType).append("-").append(choiceOrBauOffer).append("-").append(sedOfferId).append("|");
            }
        } else if(StringUtilities.isNotEmptyOrNull(promotionId)){
            if (StringUtilities.isNotEmptyOrNull(flowType)) {
                promos.append(promoType).append("-").append(promotionId).append("-").append(offerType).append("-").append(choiceOrBauOffer).append("-").append(flowType).append("|");
            } else {
                promos.append(promoType).append("-").append(promotionId).append("-").append(offerType).append("-").append(choiceOrBauOffer).append("|");
            }
        }
    }
}