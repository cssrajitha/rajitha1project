package onevz.soe.cart.util;

import java.util.ArrayList;
import java.util.List;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.common.CartErrorDetail;
import onevz.soe.cart.model.initiateESimActivation.IntiateESimActivationUIRequest;
import onevz.soe.cart.model.initiateValidateDeviceSim.InitiateValidateDeviceSimUIRequest;
import onevz.soe.cart.model.manualDiscount.ManualDiscount;
import onevz.soe.cart.model.manualDiscount.ManualDiscountLine;
import onevz.soe.cart.model.updateSellerPrice.UpdateSellerPriceLine;
import onevz.soe.cart.model.updateUserInfo.UpdateUserInfoLine;
import onevz.soe.cart.requests.RetrieveCartCXPRequest;
import onevz.soe.cart.requests.ValidateCartCXPRequest;
import onevz.soe.cart.requests.ValidateSecureTokenRequest;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import org.apache.commons.collections4.ListUtils;
import org.apache.commons.lang3.ArrayUtils;

/**
 * SOE Request Error Handler class.
 */
public class CartCxpRequestErrorsUtil {

	private CartCxpRequestErrorsUtil() {

	}

	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleRetrieveCartRequestErrors(RetrieveCartCXPRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();

		errorDetails = validateCartId(errorDetails, request.getData().getCartId());

		ErrorResponse errors = generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleRetrieveURCForCartRequestErrors(RetrieveURCForCartUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (null == request.getCartMtnList()) {
			errorDetails.add(generateMissingError(CartConstants.CART_MTN_LIST));
		}

		//errorDetails = validateCartId(errorDetails, request.getCartId());

		ErrorResponse errors = generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleValidateCartRequestErrors(ValidateCartCXPRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();

		errorDetails = validateCartId(errorDetails, request.getCartId());

		ErrorResponse errors = generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleUpdateUserInfoRequestErrors(UpdateUserInfoUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();
		errorDetails = validateCartId(errorDetails, request.getCartId());
		errorDetails = validateIntendType(errorDetails, request.getIntendType(), CartConstants.ASSISTED);
		if (request.getLines() == null) {
			errorDetails.add(generateMissingError(CartConstants.LINE_DETAILS));
		} else {
			List<UpdateUserInfoLine> lines = request.getLines();
			for (UpdateUserInfoLine line : lines) {
				errorDetails = validateUpdateUserInfo(errorDetails, line);
			}
		}

		ErrorResponse errors = generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handlePaperlessBillingRequestErrors(PaperlessBillingUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();
		errorDetails = validateCartId(errorDetails, request.getCartId());
		errorDetails = validateIntendType(errorDetails, request.getIntendType(), CartConstants.ASSISTED);
		if (StringUtilities.isEmptyOrNull(String.valueOf(request.getPaperlessbilling()))) {
			errorDetails.add(generateMissingError(CartConstants.PAPERLESSBILLING));
		}

		ErrorResponse errors = generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleUpdateTradeinTypeRequestErrors(UpdateTradeinTypeUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();
		errorDetails = validateCartId(errorDetails, request.getCartId());
		errorDetails = validateIntendType(errorDetails, request.getIntendType(), CartConstants.ASSISTED);
		if (StringUtilities.isEmptyOrNull(request.getTradeInType())) {
			errorDetails.add(generateMissingError(CartConstants.TRADEINTYPE));
		}

		ErrorResponse errors = generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleUpdateSellerPriceRequestErrors(UpdateSellerPriceUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();
		errorDetails = validateCartId(errorDetails, request.getCartId());
		errorDetails = validateIntendType(errorDetails, request.getIntendType(), CartConstants.ASSISTED);
		if (request.getLines() == null) {
			errorDetails.add(generateMissingError(CartConstants.LINE_DETAILS));
		} else {
			List<UpdateSellerPriceLine> lines = request.getLines();
			for (UpdateSellerPriceLine line : lines) {
				if (StringUtilities.isEmptyOrNull(line.getMtn()))
					errorDetails.add(generateMissingError(CartConstants.MTN));
				if (StringUtilities.isEmptyOrNull(String.valueOf(line.getSellerPrice())))
					errorDetails.add(generateMissingError(CartConstants.SELLERPRICE));
			}
		}
		ErrorResponse errors = generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleInstantCreditDownPaymentRequestErrors(InstantCreditDownPaymentUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (ArrayUtils.isEmpty(request.getData().getLines())) {
			errorDetails.add(generateMissingError(CartConstants.LINE_DETAILS));
		} else {
			Lines[] lines = request.getData().getLines();
			for (Lines line : lines) {
				if (null != line && StringUtilities.isEmptyOrNull(line.getMtn())) {
					errorDetails.add(generateMissingError(CartConstants.MTN));
				}
			}
		}

		ErrorResponse errors = generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleMacAddressRequestErrors(MacAddressUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (StringUtilities.isEmptyOrNull(request.getCartId())) {
			errorDetails.add(generateMissingError(CartConstants.CART_ID));
		}
		if (ListUtils.emptyIfNull(request.getData().getLines()).isEmpty()) {
			errorDetails.add(generateMissingError(CartConstants.LINE_DETAILS));
		}

		ErrorResponse errors = generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleManualDiscountRequestErrors(ManualDiscountUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();

		errorDetails = validateCartId(errorDetails, request.getCartId());
		errorDetails = validateIntendType(errorDetails, request.getIntendType(), CartConstants.ASSISTED);
		if (StringUtilities.isEmptyOrNull(request.getAction())) {
			errorDetails.add(generateMissingError(CartConstants.ACTION));
		}
		if (request.getData().getLines() == null) {
			errorDetails.add(generateMissingError(CartConstants.LINE_DETAILS));
		} else {
			for (ManualDiscountLine mdLine : request.getData().getLines()) {
				if (StringUtilities.isEmptyOrNull(mdLine.getMtn())) {
					errorDetails.add(generateMissingError(CartConstants.MTN));
				}
				if (mdLine.getManualDiscount() == null) {
					errorDetails.add(generateMissingError(CartConstants.MANUAL_DISCOUNT));
				} else {
					for (ManualDiscount manDisc : mdLine.getManualDiscount()) {
						if ("ADD".equalsIgnoreCase(request.getAction())) {
							if (StringUtilities.isEmptyOrNull(manDisc.getDiscountReasonCode())) {
								errorDetails.add(generateMissingError(CartConstants.DISCOUNT_REASON_CODE));
							}
						}
					}
				}
			}

		}

		ErrorResponse errors = generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	private static List<CartErrorDetail> validateUpdateUserInfo(List<CartErrorDetail> errorList,
			UpdateUserInfoLine line) {

		if (StringUtilities.isEmptyOrNull(line.getMtn())) {
			errorList.add(generateMissingError(CartConstants.MTN));
		}
		if (StringUtilities.isEmptyOrNull(line.getFirstName())) {
			errorList.add(generateMissingError("firstName"));
		}
		if (StringUtilities.isEmptyOrNull(line.getLastName())) {
			errorList.add(generateMissingError("lastName"));
		}
		if (StringUtilities.isEmptyOrNull(line.getEmail())) {
			errorList.add(generateMissingError("email"));
		}
		return errorList;
	}

	public static List<CartErrorDetail> validateCartId(List<CartErrorDetail> errorList, String cartId) {

		if (StringUtilities.isEmptyOrNull(cartId)) {
			errorList.add(generateMissingError(CartConstants.CART_ID));
		}

		return errorList;
	}

	public static List<CartErrorDetail> validateIntendType(List<CartErrorDetail> errorList, String intendType,
			String channelId) {

		if (CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(channelId))
				&& StringUtilities.isEmptyOrNull(intendType)) {
			errorList.add(generateMissingError(CartConstants.INTEND_TYPE));
		}
		return errorList;
	}

	public static CartErrorDetail generateMissingError(String inputValue) {
		CartErrorDetail detail = new CartErrorDetail();
		detail.setField(inputValue);
		detail.setIssue(inputValue + " is/are missing.");
		detail.setLocation("request");
		detail.setValue("null/blank");

		return detail;
	}

	public static ErrorResponse generateErrorResponse(List<CartErrorDetail> errorDetails) {
		ErrorResponse errors = null;

		CartError error = new CartError();
		error.setNamespace(CartConstants.SOE_CART_SERVICE);
		error.setName(CartConstants.VALIDATION_ERROR);
		error.setId(CartConstants.MSNG_FLDS_ERR_CODE);

		List<CartError> errorList = new ArrayList<>();
		if (!errorDetails.isEmpty()) {
			error.setDetailList(errorDetails);
			errorList.add(error);
			errors = new ErrorResponse();
			errors.setErrors(errorList);
		}
		return errors;
	}

	/**
	 * 
	 * @param request
	 * @return errorResp
	 */
	public static ErrorResponse handleCustomerByMtnListRequestErrors(CustomerByMtnListUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (CollectionUtilities.isEmptyOrNull(request.getMtnList())) {
			errorDetails.add(generateMissingError(CartConstants.MTN_LIST));
		}

		ErrorResponse errors = generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param request
	 * @return errorResp
	 */
	public static ErrorResponse handleVZCCAppStatusRequestErrors(VZCCAppStatusUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (request.getVzccStatus() != null) {
			if (StringUtilities.isEmptyOrNull(request.getVzccStatus().getApplicationStatus())
					&& StringUtilities.isEmptyOrNull(request.getVzccStatus().getFeedbackStatus()))
				errorDetails.add(generateMissingError("status"));
		}

		ErrorResponse errors = generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	//VZWCS-17115 change
	public static ErrorResponse handleInitiateCbandCheckRequestErrors(InitiateCbandCheckUIRequest request){
		List<CartErrorDetail> errorDetails = new ArrayList<>();
		if(null != request){
			if(StringUtilities.isEmptyOrNull(request.getFlowType())) {
				errorDetails.add(generateMissingError("flowType"));
			}
			if(StringUtilities.isEmptyOrNull(request.getImsi())) {
				errorDetails.add(generateMissingError("imsi"));
			}
			//checking for imsi flowtype
			if(StringUtilities.isNotEmptyOrNull(request.getFlowType())){
				errorDetails = validateFlowType(errorDetails,request.getFlowType());
			}
		}
		ErrorResponse errors = generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	private static List<CartErrorDetail> validateFlowType(List<CartErrorDetail> errorList, String flowType) {

		CartErrorDetail errorDetail = new CartErrorDetail();
		if (StringUtilities.isNotEmptyOrNull(flowType) && !CartConstants.IMSI.equalsIgnoreCase(flowType)) {
			errorDetail.setField("flowType");
			errorDetail.setIssue("flowType is/are invalid.");
			errorDetail.setLocation("request");
			errorDetail.setValue("invalid");

			errorList.add(errorDetail);
		}

		return errorList;
	}
	/**
	 *
	 * @param request
	 * @return errorResp
	 */
	public static ErrorResponse handleDeviceSimValidationRequestErrors(DeviceSimValidationUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();
		if(!request.getTechType().equalsIgnoreCase(CartConstants.MANAGE_ACCOUNT) && StringUtilities.isEmptyOrNull(request.getImei2())&& StringUtilities.isEmptyOrNull(request.getDevid())) {
			if (StringUtilities.isEmptyOrNull(request.getImei()) || StringUtilities.isEmptyOrNull(request.getIccid()) || StringUtilities.isEmptyOrNull(request.getBillingId())) {
				if(StringUtilities.isEmptyOrNull(request.getImei()) && StringUtilities.isEmptyOrNull(request.getEid()))
					errorDetails.add(generateMissingError("Imei"));
				if(StringUtilities.isEmptyOrNull(request.getIccid()) && StringUtilities.isEmptyOrNull(request.getEid()))
					errorDetails.add(generateMissingError(CartConstants.ICC_ID) );
				if(StringUtilities.isEmptyOrNull(request.getBillingId())&& StringUtilities.isEmptyOrNull(request.getEid()))
					errorDetails.add(generateMissingError("BillingId"));
			}
		}
		if(!request.getTechType().equalsIgnoreCase(CartConstants.MANAGE_ACCOUNT) && StringUtilities.isNotEmptyOrNull(request.getImei()) && StringUtilities.isNotEmptyOrNull(request.getImei2())) {
			if (StringUtilities.isEmptyOrNull(request.getImei()) || StringUtilities.isEmptyOrNull(request.getIccid()) || StringUtilities.isEmptyOrNull(request.getBillingId())) {
				if(StringUtilities.isEmptyOrNull(request.getImei()))
					errorDetails.add(generateMissingError("Imei"));
				if(StringUtilities.isEmptyOrNull(request.getIccid()))
					errorDetails.add(generateMissingError(CartConstants.ICC_ID));
				if(StringUtilities.isEmptyOrNull(request.getBillingId()))
					errorDetails.add(generateMissingError("BillingId"));
			}
		}
		if(!request.getTechType().equalsIgnoreCase(CartConstants.MANAGE_ACCOUNT) && StringUtilities.isEmptyOrNull(request.getImei()) && StringUtilities.isEmptyOrNull(request.getDevid()) && StringUtilities.isEmptyOrNull(request.getToken()) && StringUtilities.isEmptyOrNull(request.getImei2())) {
			if (StringUtilities.isEmptyOrNull(request.getImei())) {
				errorDetails.add(generateMissingError("Imei"));
			}
			if (StringUtilities.isEmptyOrNull(request.getImei2())) {
				errorDetails.add(generateMissingError("Imei2"));
			}
			if (StringUtilities.isEmptyOrNull(request.getImei2()) && StringUtilities.isEmptyOrNull(request.getDevid())) {
				errorDetails.add(generateMissingError("devid"));
			}
		}
		
		if(StringUtilities.isEmptyOrNull(request.getToken()) && StringUtilities.isEmptyOrNull(request.getImei2()) && StringUtilities.isEmptyOrNull(request.getBillingId())&&StringUtilities.isEmptyOrNull(request.getIccid())&&StringUtilities.isEmptyOrNull(request.getImei()) && StringUtilities.isEmptyOrNull(request.getDevid()) && StringUtilities.isEmptyOrNull(request.getEid())) {
			errorDetails.add(generateMissingError(CartConstants.TOKEN));
		}
		
		//TechType: MANAGEACCOUNT has only Esim flow and it requires iccid and eid
		if(StringUtilities.isNotEmptyOrNull(request.getTechType())) {
			if(request.getTechType().equalsIgnoreCase(CartConstants.MANAGE_ACCOUNT)) {
				if(StringUtilities.isEmptyOrNull(request.getIccid()))
					errorDetails.add(generateMissingError(CartConstants.ICC_ID));
				if(StringUtilities.isEmptyOrNull(request.getEid()))
					errorDetails.add(generateMissingError("Eid"));
			}
			
		}
		ErrorResponse errors = generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	public static ErrorResponse handleESimValidationRequestErrors(IntiateESimActivationUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();
		if(StringUtilities.isEmptyOrNull(request.getEid())&& StringUtilities.isEmptyOrNull(request.getHandOffToken())
				&& StringUtilities.isEmptyOrNull(request.getImei())) {
			    errorDetails.add(generateMissingError("Eid"));				
				errorDetails.add(generateMissingError("Imei") );				
				errorDetails.add(generateMissingError("HandOffToken"));
			}
		
		
		ErrorResponse errors = generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}
	
	
	/**
	 *
	 * @param request
	 * @return errorResp
	 */
	public static ErrorResponse handleValidateTokenRequestErrors(ValidateSecureTokenRequest validateSecureTokenRequest, String igServiceValidateSecureTokenUrl,String username,String password) {
		List<CartErrorDetail> errorDetails = new ArrayList<>();
			if (StringUtilities.isEmptyOrNull(validateSecureTokenRequest.getToken()))
				errorDetails.add(generateMissingError(CartConstants.TOKEN));
			if (StringUtilities.isEmptyOrNull(validateSecureTokenRequest.getIntent()))
				errorDetails.add(generateMissingError("Intent"));
			if (StringUtilities.isEmptyOrNull(igServiceValidateSecureTokenUrl))
				errorDetails.add(generateMissingError("IG.PROSPECT.JWT.validateSecureToken.URL from application.properties File"));
			if (StringUtilities.isEmptyOrNull(username))
				errorDetails.add(generateMissingError("IG.prospect.validateSecureTokenUsername from application.properties File"));
			if (StringUtilities.isEmptyOrNull(password))
				errorDetails.add(generateMissingError("IG.prospect.validateSecureTokenPassword from application.properties File"));
			

		ErrorResponse errors = formatError(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}
	
	/**
	 *
	 * @param request
	 * @return errorResp
	 */
	public static ErrorResponse handleTokenAndRequestEmptyErrors(DeviceSimValidationUIRequest request, String Token) {
		List<CartErrorDetail> errorDetails = new ArrayList<>();
			if (request==null)
				errorDetails.add(generateMissingError("RequestBody"));
			if (StringUtilities.isEmptyOrNull(Token))
				errorDetails.add(generateMissingError(CartConstants.TOKEN));
			
			ErrorResponse errors = formatError(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param request
	 * @return errorResp
	 */
	public static ErrorResponse handleUpdateVzccNBXInfoRequestErrors(UpdateVzccNBXInfoUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (request.getVzccStatus() != null) {
			if (StringUtilities.isEmptyOrNull(request.getVzccStatus().getApplicationStatus())
					&& StringUtilities.isEmptyOrNull(request.getVzccStatus().getFeedbackStatus()))
				errorDetails.add(generateMissingError("status"));
		}

		ErrorResponse errors = generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param request
	 * @return errorResp
	 */
	public static ErrorResponse handleGetCustomerInfoRequestErrors(CreateCaseAndGetCustomerInfoUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (request == null)
			errorDetails.add(generateMissingError("Request"));
		else {
			if (StringUtilities.isEmptyOrNull(request.getImei()))
				errorDetails.add(generateMissingError("imei1"));
			if (StringUtilities.isEmptyOrNull(request.getLineAction()))
				errorDetails.add(generateMissingError("line action"));
			if (StringUtilities.isEmptyOrNull(request.getIntent()))
				errorDetails.add(generateMissingError("intent"));
		}
		ErrorResponse errors = generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	//VZWYN-20895 changes
	public static ErrorResponse handleCustomerNameByMtnRequestErrors(InitiateValidateDeviceSimUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (request == null || request.getData() == null)
			errorDetails.add(generateMissingError("Request"));
		else {
			if (request.getData().getPostPaidInd() == null)
				errorDetails.add(generateMissingError("postPaidInd"));
			if (StringUtilities.isEmptyOrNull(request.getData().getIntendType()))
				errorDetails.add(generateMissingError(CartConstants.INTEND_TYPE));
			if (StringUtilities.isEmptyOrNull(request.getData().getProcessAction()))
				errorDetails.add(generateMissingError("processAction"));
		}
		ErrorResponse errors = generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	private static ErrorResponse formatError(List<CartErrorDetail> errorDetails) {
		ErrorResponse errors = generateErrorResponse(errorDetails);
		CartError error = new CartError();
		List<CartError> errorList = new ArrayList<>();
		if (!errorDetails.isEmpty()) {
			error.setDetailList(errorDetails);
			errorList.add(error);
			errors = new ErrorResponse();
			errors.setErrors(errorList);
		}
		return errors;
	}
}
