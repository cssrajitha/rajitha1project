package onevz.soe.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.cradle.util.CradleConstants;
import com.vzw.cradle.vo.CradleResponse;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper2;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.controller.advice.CartServiceExceptionHandler;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.handler.PreHandleAddDevice;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.common.Device;
import onevz.soe.cart.model.edgeup.EdgeUp;
import onevz.soe.cart.model.retrieveCart.CXPCartVO;
import onevz.soe.cart.model.taxengine.request.NGDCalculateTaxDetailsMeta;
import onevz.soe.cart.model.taxengine.request.NGDCalculateTaxDetailsRequest;
import onevz.soe.cart.model.taxengine.request.NGDTaxEngineRequest;
import onevz.soe.cart.model.taxengine.request.NGDTaxLinesRequest;
import onevz.soe.cart.model.taxengine.response.NGDTaxEngineBaseData;
import onevz.soe.cart.model.taxengine.response.NGDTaxEngineBaseResponse;
import onevz.soe.cart.model.taxengine.response.NGDTaxEngineResponseData;
import onevz.soe.cart.model.validateCart.CartValidationError;
import onevz.soe.cart.omnidl.OmniBuilder;
import onevz.soe.cart.requests.ValidateCartCXPRequest;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.ui.common.AddDeviceData;
import onevz.soe.cart.ui.common.CartInfo;
import onevz.soe.cart.ui.common.DeviceCartInfo;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.AddDeviceUIRequest;
import onevz.soe.cart.ui.responses.AddDeviceUIResponse;
import onevz.soe.cart.ui.responses.ValidateCartUIResponse;
import onevz.soe.cart.util.*;
import onevz.soe.cradle.CradleAllocator;
import onevz.soe.exception.SOEErrorHolder;
import onevz.soe.logging.util.LoggerUtil;
import onevz.soe.omnidl.service.OmniDLService;
import onevz.soe.omnidl.util.DLUtilityService;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.utilities.serialization.JacksonMapperFactory;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;

import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.text.DecimalFormat;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static com.vzw.cradle.util.CradleConstants.CHANNEL;
import static com.vzw.cradle.util.CradleConstants.FLOW;
import static java.util.Objects.nonNull;
import static onevz.soe.cart.constants.CartConstants.QUICK_C_VIEW;

@Service
public class CartAddDeviceHelper1 {

    private static final Logger logger = LoggerFactory.getLogger(CartAddDeviceHelper1.class);

    private static DecimalFormat df2 = new DecimalFormat("#.00");


    @Value("${maxDevicesAllowedPromoHub}")
    private Integer maxDevicesAllowedPromoHub;

    @Value("#{'${preorderWhitelistMtns}'.split(',')}")
    List<String> preorderWhitelistMtnsList = new ArrayList<>();

    @Value("#{'${promoHubEnabledCategory}'.split(',')}")
    List<String> promoHubEnabledCategory = new ArrayList<>();

    @Autowired
    CradleAllocator cradleAllocator;

    @Autowired
    DLUtilityService dlUtilityService;

    @Autowired
    private CartServiceCXPServices cxpService;

    @Autowired
    private OmniDLService dlService;


    @Autowired
    private CartServiceCxpHelper cxpHelper;

    @Autowired
    CartAddDeviceHelper cartAddDeviceHelper;

    @Autowired
    private CartServiceExceptionHandler exHandler;

    @Autowired
    private CartServiceBpmHelper2 bpmHelper;

    @Autowired
    private RedisHelper2 redisHelper2;

    @Autowired
    private CartRequestBuilder cartRequestBuilder;

    @Autowired
    private RedisHelper redisHelper;

    @Autowired
    private FeatureFlagHelper featureFlagHelper;

	@Autowired
	private ObjectMapper mapper;

    @Autowired
    PreHandleAddDevice preHandleAddDevice;
    @Value("${device_categories_for_nextgen_byod_mva}")
    private List<String> deviceCategoriesForNextGenByodMva;

    private static final String DEVICE_STEP_ERROR_CODE="1026";
    private static final List<String> NEXTGEN_CRADLE_FLOW_JOURNEY_LIST= List.of(CartConstants.NEXT_GEN, CartConstants.NEXTGEN_PF);
    private static final List<String> NEXTGEN_PLAN_FIRST_ELIGIBLE_INTENT= List.of(CartConstants.NSE, CartConstants.NSE_BYOD);
    public boolean invokeCradleForPccThrottleList(AddDeviceUIRequest request, String iconicTestIntent) {
        return StringUtils.isNotEmpty(iconicTestIntent) && request.getData() != null && request.getData().getLines() != null
                && !request.getData().getLines().isEmpty() && request.getData().getLines().get(0) != null
                && request.getData().getLines().get(0).getDevice() != null
                && StringUtilities.isEmptyOrNull(request.getData().getLines().get(0).getDevice().getCategory());
    }

    public boolean SetThrottleForSecondDevice(AddDeviceUIRequest request, String oneClickCheckout, int deviceListCount,
                                               String intent) {
        return deviceListCount < maxDevicesAllowedPromoHub && StringUtilities.isNotEmptyOrNull(oneClickCheckout)
                && Boolean.valueOf(oneClickCheckout) && CartAddDeviceUtil.AllowCradleCheck(request, intent);
    }

    /**
     *
     * @param request
     * @return categoryEnabled
     */
    public boolean isCategoryEnabledForExpressCheckout(AddDeviceUIRequest request) {
        boolean categoryEnabled = false;
        logger.info("promoHubEnabledCategoryNEW" + promoHubEnabledCategory);
        if ((promoHubEnabledCategory != null && request.getData().getLines().get(0) != null
                && promoHubEnabledCategory.contains(request.getData().getLines().get(0).getDevice().getCategory()))
                || (null != request.getCartInfo().getReqfrompromopdp() && request.getCartInfo().getReqfrompromopdp())) {
            categoryEnabled = true;
        }
        return categoryEnabled;
    }

    public boolean isWhiteListedMtn(String cartCreator) {
        if (null != preorderWhitelistMtnsList) {
            Optional<String> mtnOptional = preorderWhitelistMtnsList.stream().filter(mtn ->
                    mtn.equalsIgnoreCase(cartCreator)).findFirst();
            return mtnOptional.isPresent() && StringUtilities.isNotEmptyOrNull(mtnOptional.get());
        }
        return false;
    }

    public Mono<CradleResponse> invokeCradleForPromoHub(AddDeviceUIRequest request, String mtnToPlanIdJson,
                                                         String intent, String role, boolean preConfigure, String oneclickcheckout, String iconicTestIntent,String deviceListCount) throws JsonProcessingException {

        ServerHttpRequest httpRequest = null;
        ServerHttpResponse httpResponse = null;
        try {
            Map<String, String> mtnToPlanIdMap = StringUtils.isNotBlank(mtnToPlanIdJson)
                    ? ((JacksonMapperFactory.readerForType(Map.class).readValue(mtnToPlanIdJson)))
                    : null;

            Map<String, String> dataMap = new HashMap<String, String>();
            dataMap.put(FLOW, intent);
            if (null != mtnToPlanIdMap && null != mtnToPlanIdMap.get(request.getCartInfo().getProcessingMTN())) {
                dataMap.put(CartConstants.PLAN_SOR_ID, mtnToPlanIdMap.get(request.getCartInfo().getProcessingMTN()));
            }
            if(CartConstants.PROMO_HUB.equals(request.getCartInfo().getProcessStep()) &&
                    CartConstants.ADD_DEVICE.equals(request.getCartInfo().getProcessAction())){
                dataMap.put(CartConstants.WISHLIST_FLOW, "true");
            } else {
                dataMap.put(CartConstants.WISHLIST_FLOW, CartConstants.FALSE);
            }
            if(CartConstants.PROMO_HUB.equals(request.getCartInfo().getProcessStep()) &&
                    CartConstants.ADD_DEVICE_SIM.equals(request.getCartInfo().getProcessAction())){
                dataMap.put(CartConstants.BYOD_FLOW_CHECKOUT, "true");
            } else {
                dataMap.put(CartConstants.BYOD_FLOW_CHECKOUT, CartConstants.FALSE);
            }
            if (null != request.getData() && null != request.getData().getLines()
                    && !request.getData().getLines().isEmpty()) {
                if (null != request.getData().getLines().get(0).getDevice()) {
                    if (StringUtilities
                            .isNotEmptyOrNull(request.getData().getLines().get(0).getDevice().getDeviceId())) {
                        dataMap.put(CartConstants.DEVICE_SOR_ID,
                                request.getData().getLines().get(0).getDevice().getDeviceId());
                    } else if (StringUtilities
                            .isNotEmptyOrNull(request.getData().getLines().get(0).getDevice().getId())) {
                        dataMap.put(CartConstants.DEVICE_SOR_ID,
                                request.getData().getLines().get(0).getDevice().getId());
                    }
                    if (StringUtilities
                            .isNotEmptyOrNull(request.getData().getLines().get(0).getDevice().getCategory())) {
                        dataMap.put(CartConstants.DEVICE_CATEGORY_NAME,
                                request.getData().getLines().get(0).getDevice().getCategory());
                    }
                    if (StringUtilities
                            .isNotEmptyOrNull(request.getData().getLines().get(0).getDevice().getProductId())) {
                        dataMap.put(CartConstants.DEVICE_PRODUCT_ID,
                                request.getData().getLines().get(0).getDevice().getProductId());
                    }
                    String selectedPromotype = request.getData().getLines().get(0).getSelectedPromoType();
                    String selectedPromoId = request.getData().getLines().get(0).getSelectedPromoId();
                    if(CartConstants.NSE.equalsIgnoreCase(intent) || CartConstants.NSE_BYOD.equalsIgnoreCase(intent)){
                        dataMap.put(CartConstants.IS_PROPSECT, "true");
                        dataMap.put(CartConstants.IS_PLAN_FIRST, CartConstants.FALSE);

                        if(null != request.getHttpRequest() && null != request.getHttpRequest().getCookies()) {
                            HttpCookie cdlThrottleListCookie = request.getHttpRequest().getCookies().getFirst(CartConstants.CDL_THROTTLE_LIST);
                            if(null != cdlThrottleListCookie) {
                                String cdlThrottleList = cdlThrottleListCookie.getValue();
                                if (StringUtilities.isNotEmptyOrNull(cdlThrottleList) &&
                                        (cdlThrottleList.contains(CartConstants.NSA_REDIRECT_TH_PROSPECT_GW_PDP_NSA_ADD_TO_CART_ENABLE_PLAN) || cdlThrottleList.contains(CartConstants.NSA_PLAN_FIRST_CL))) {
                                    dataMap.put(CartConstants.IS_PLAN_FIRST, CartConstants.TRUE_FLAG);
                                }
                            }
                        }
                        if (StringUtilities.isNotEmptyOrNull(selectedPromotype)) {
                            dataMap.put(CartConstants.PROMO_TYPE, selectedPromotype);
                        }
                        dataMap.put(CartConstants.MULTI_LINE, CartConstants.FALSE);
                        if(StringUtilities.isNotEmptyOrNull(deviceListCount)){
                            dataMap.put(CartConstants.DEVICE_COUNT,deviceListCount);
                        }
                        if(CartConstants.TRUE_FLAG.equalsIgnoreCase(oneclickcheckout)) {
                            dataMap.put(CartConstants.MULTI_LINE, oneclickcheckout);
                        }
                    }
                    else if(CartConstants.BYOD.equalsIgnoreCase(intent)){
                        dataMap.put(CartConstants.IS_PROPSECT,CartConstants.FALSE);
                    }
                    if (StringUtilities.isNotEmptyOrNull(selectedPromotype)) {
                        if (selectedPromotype.equalsIgnoreCase("NOPROMO")
                                || StringUtilities.isNotEmptyOrNull(selectedPromoId)) {
                            dataMap.put("promo", "true");
                        }
                    }
                }
            }
            if (StringUtilities.isNotEmptyOrNull(role)) {
                dataMap.put(CartConstants.ROLE, role);
            }
            if(StringUtilities.isNotEmptyOrNull(request.getChannelId())) {
                dataMap.put(CHANNEL, request.getChannelId());
            }else{
                logger.info(String.format("Empty channel id from UI request defaulting to VZW_DOTCOM %s",request));
                dataMap.put(CHANNEL, CartConstants.VZW_DOTCOM);
            }
            dataMap.put(CradleConstants.PAGE_NAME, "addDevice");
            if (preConfigure) {
                dataMap.put(CartConstants.PRE_CONFIGURE, "true");
            } else {
                dataMap.put(CartConstants.PRE_CONFIGURE, CartConstants.FALSE);
            }
            httpRequest = request.getHttpRequest();
            httpResponse = request.getHttpResponse();

            if(StringUtils.isNotEmpty(iconicTestIntent)) {
                setPccDataMap(request, httpRequest, dataMap, iconicTestIntent);
            }

            return cradleAllocator.invokeReactiveCradle(httpRequest, httpResponse, dataMap);

        } catch (Exception ex) {
            logger.error("exception while invoking Cradle Add Device",ex);
            return Mono.empty();
        }
    }

    public void logDataInfo(String logInfoDataVal, Map<String, String> logInfo){
        Map<String, String> fields = new HashMap<>();
        try {
            fields.put(logInfoDataVal, JacksonMapperFactory.defaultWriter().writeValueAsString(logInfo));
            LoggerUtil.addCustomPersistField(fields);
        } catch (JsonProcessingException e) {
            logger.error("Error when logging the custom fields : {} ", e);
        }
    }

    public void setIconicTestIntentInRequest(AddDeviceUIRequest request, JsonNode cradleOutputJsonNode, String iconicTestIntentFinal) {
        try {
            if (null != cradleOutputJsonNode
                    && null != cradleOutputJsonNode.get(CartConstants.THROTTLE_LIST)) {
                String throttleList = cradleOutputJsonNode.get(CartConstants.THROTTLE_LIST).asText();
                logger.info(String.format("Value of throttleList --- %s " , throttleList));
                if (StringUtilities.isNotEmptyOrNull(throttleList)) {
                    List<String> finalThrottleList = Arrays.asList(throttleList.split("\\|"));
                    if (finalThrottleList.contains(iconicTestIntentFinal)) {
                        logger.info("iconicTestIntent authorized from cradle {}", iconicTestIntentFinal);
                        request.getCartInfo().setIconicTestIntent(iconicTestIntentFinal);
                    }
                }
            }
        } catch(Exception e){
            logger.info("Exception in setting iconicTestIntent in request : {} " , e.getMessage());
        }
    }

    private void setPccDataMap(AddDeviceUIRequest request, ServerHttpRequest httpRequest, Map<String, String> dataMap,
                               String iconicTestIntent) {
        try {
            String mtn = "";
            if (request.getCartInfo() != null && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCartCreator())) {
                mtn = request.getCartInfo().getCartCreator();
            }

            String ipAddress = "";
            if (httpRequest != null && httpRequest.getHeaders() != null && !httpRequest.getHeaders().isEmpty()) {
                ipAddress = httpRequest.getHeaders().containsKey(CartConstants.ORIGINATING_CLIENT_IP)
                        ? httpRequest.getHeaders().getFirst(CartConstants.ORIGINATING_CLIENT_IP) : "";
            }

            if (request.getCartInfo() != null && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                    && request.getCartInfo().getIntendType().equalsIgnoreCase(CartConstants.NSE)) {
                dataMap.put(CartConstants.IS_PROSPECT, "true");
            } else {
                dataMap.put(CartConstants.IS_PROSPECT, CartConstants.FALSE);
                dataMap.put(CartConstants.MTN, mtn);
            }

            dataMap.put(CartConstants.CLIENT_IP, ipAddress);
            dataMap.put(CartConstants.ICONIC_TEST_INTENT, iconicTestIntent);
        } catch(Exception e) {
            logger.info("Exception in setting pcc datamap : {} " , e.getMessage());
        }
    }

    //VZWYN-17835 changes
    public ValidateCartCXPRequest settingValidateCartCXPRequest(AddDeviceUIRequest request, CartRedisData data) {
        ValidateCartCXPRequest validateRequest = new ValidateCartCXPRequest();
        if(null!= request) {
            if (null != request.getCartInfo() && null != request.getCartInfo().getCartId())
                validateRequest.setCartId(request.getCartInfo().getCartId());
            validateRequest.setRetrieveCurrentFeatures(true);
            if (StringUtilities.isNotEmptyOrNull(request.getChannelId())
                    && request.getChannelId().equalsIgnoreCase(CartConstants.DIGITAL)
                    && ((null != request.getCartInfo()
                    && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCartCreator()))
                    || StringUtilities.isNotEmptyOrNull(data.getMtn()))
                    && StringUtilities.isNotEmptyOrNull(data.getVzwRoles())
                    && (data.getVzwRoles().equalsIgnoreCase(CartConstants.MOBILE_SECURE)
                    || data.getVzwRoles().equalsIgnoreCase(CartConstants.ACCOUNT_MEMBER))) {
                String mtn = null == request.getCartInfo() ? ""
                        : StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCartCreator())
                        ? request.getCartInfo().getCartCreator()
                        : StringUtilities.isNotEmptyOrNull(data.getMtn())
                        ? data.getMtn()
                        : "";
                List<String> mtnList = new ArrayList<>();
                mtnList.add(mtn);
                validateRequest.setMtnList(mtnList);
            }
        }
        validateRequest.setRetrieveCurrentFeatures(true);
        setValidateCartCXPRequest(request,data, validateRequest);
        return validateRequest;
    }

    public ValidateCartCXPRequest setValidateCartCXPRequest(AddDeviceUIRequest request, CartRedisData data, ValidateCartCXPRequest validateRequest){
        if (request!=null && StringUtilities.isNotEmptyOrNull(request.getChannelId())
                && request.getChannelId().equalsIgnoreCase(CartConstants.DIGITAL)
                && ((null != request.getCartInfo()
                && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCartCreator()))
                || StringUtilities.isNotEmptyOrNull(data.getMtn()))
                && StringUtilities.isNotEmptyOrNull(data.getVzwRoles())
                && (data.getVzwRoles().equalsIgnoreCase(CartConstants.MOBILE_SECURE)
                || data.getVzwRoles().equalsIgnoreCase(CartConstants.ACCOUNT_MEMBER))) {
            String mtn = null == request.getCartInfo() ? ""
                    : StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCartCreator())
                    ? request.getCartInfo().getCartCreator()
                    : StringUtilities.isNotEmptyOrNull(data.getMtn())
                    ? data.getMtn()
                    : "";
            List<String> mtnList = new ArrayList<>();
            mtnList.add(mtn);
            validateRequest.setMtnList(mtnList);
        }
        return validateRequest;
    }

    public void settingValidateCartCXPResponse(ValidateCartUIResponse validateCartResponse, AddDeviceUIResponse response,
                                               ValidateCartCXPRequest validateRequest, CartRedisData data) {
        if (validateCartResponse != null) {
            if (validateCartResponse.getErrors() != null)
                response.setErrors(validateCartResponse.getErrors());
            else {
                if (null != validateCartResponse.getData()
                        && null != validateCartResponse.getData().getValidateCartAndUpdate()) {
                    CXPCartVO cart = validateCartResponse.getData().getValidateCartAndUpdate();
                    cart = CartUtil.calculateMemberCount(cart, validateRequest.getMtnList(), data.getVzwRoles());
                    validateCartResponse.getData().setValidateCartAndUpdate(cart);
                }
                response.setValidateCartResponse(validateCartResponse);
            }
        }
    }

    public Mono<Boolean> updateSubFlowInTaggingForNextgen(String cdlThrotteList, AddDeviceUIResponse pegaResponse, AddDeviceUIRequest request){
        try{
            return dlUtilityService.getSubFlowVal().flatMap(subFlow -> {
                List<String> subFlowList = getSubFlowList(subFlow);
                return updateSubFlowInTaggingForNextgenBYOD(pegaResponse, request, subFlowList)
                        .flatMap(updated -> updateSubFlowForNextgenSales(pegaResponse, request))
                        .flatMap(updated2 -> updateSubFlowInTaggingForQuickView(cdlThrotteList,request))
                        .flatMap(updated3 -> updateSubFlowForVVC(request));
            });
        }catch(Exception e){
            logger.error("Exception at updateSubFlowInTaggingForNova",e);
            return Mono.just(Boolean.TRUE);
        }

    }

    public Mono<Boolean> updateSubFlowInTaggingForQuickView(String cdlThrottleList, AddDeviceUIRequest request){
        try{
            return dlUtilityService.getSubFlowVal().flatMap(subFlow -> {
                List<String> subFlowList = getSubFlowList(subFlow);
                return updateSubFlowInTaggingForQuickView(cdlThrottleList, request, subFlowList);
            });
        }catch(Exception e){
            logger.error("Exception at updateSubFlowInTaggingForQuickView",e);
            return Mono.just(Boolean.TRUE);
        }

    }

    public Mono<Boolean> updateSubFlowForVVC(AddDeviceUIRequest request) {

        if (Objects.nonNull(request.getData()) && !request.getData().getLines().isEmpty()) {
            boolean isDfoSelected = request.getData().getLines().stream()
                    .map(lines -> Optional.ofNullable(lines.getDevice()))
                    .filter(Optional::isPresent)
                    .map(Optional::get)
                    .anyMatch(Device::isDfoSelected);

            return isDfoSelected
                    ? dlUtilityService.upsertVZPageSubFLow(CartConstants.VVC, true, "")
                    : Mono.just(Boolean.TRUE);
        }
        return Mono.just(Boolean.TRUE);

    }

    public Mono<Boolean> updateSubFlowForNextgenSales(AddDeviceUIResponse pegaResponse, AddDeviceUIRequest request) {
        if(validatePegaResponse(pegaResponse)) {
            try{
                return dlUtilityService.getSubFlowVal().flatMap(subFlow -> {
                    List<String> subFlowList = getSubFlowList(subFlow);
                    String cradleFlowJourney = pegaResponse.getServiceBody().getServiceResponse().getContext().getContextInfo().getCradleFlowJourney();
                    logger.info("Update subflow in tagging for nextgen:: cradlflowjourney -> {}", cradleFlowJourney);
                    String nextGenSubFlow = getNextGenSubFlowValue(request, subFlowList, cradleFlowJourney);
                    if(StringUtils.isNotEmpty(nextGenSubFlow))
                        return dlUtilityService.upsertVZPageSubFLow(nextGenSubFlow, true, "");
                    else
                        return Mono.just(Boolean.TRUE);
                });
            }catch(Exception e){
                logger.error("Exception at updateSubFlowForNextgenSales",e);
                return Mono.just(Boolean.TRUE);
            }

        }
        return Mono.just(Boolean.TRUE);
    }

    private String getNextGenSubFlowValue(AddDeviceUIRequest request, List<String> subFlowList, String cradleFlowJourney) {
        String nextGenSubFlow = "";
        if (subFlowList.contains(CartConstants.NXT_GEN) && !CartConstants.NEXT_GEN.equalsIgnoreCase(cradleFlowJourney)
                && !request.getCartInfo().getIntendType().equalsIgnoreCase("NSEBYOD"))
            nextGenSubFlow = CartConstants.NEXTGEN_BAU;
        else if (CartConstants.NEXT_GEN.equalsIgnoreCase(cradleFlowJourney))
            nextGenSubFlow = CartConstants.NXT_GEN;
        else if (subFlowList.contains(CartConstants.NEXTGEN_EC)&& !CartConstants.NEXTGEN_EC.equalsIgnoreCase(cradleFlowJourney)
                && !subFlowList.contains(CartConstants.NEXTGEN_EC_BAU) )
            nextGenSubFlow = CartConstants.NEXTGEN_EC_BAU;
        else if (CartConstants.NEXTGEN_EC.equalsIgnoreCase(cradleFlowJourney)){
            nextGenSubFlow = CartConstants.NEXTGEN_EC;
            if(isHumCategoryDevice(request)){
                dlService.buildDLData(OmniBuilder.buildAddStepUserData());
            }
        }

        else if((request != null && request.getCartInfo() != null &&
                (CartConstants.AAL.equalsIgnoreCase(request.getCartInfo().getIntendType()) || CartConstants.EUP.equalsIgnoreCase(request.getCartInfo().getIntendType())))
                && !subFlowList.contains(CartConstants.NEXTGEN_EC) && !CartConstants.NEXTGEN_EC.equalsIgnoreCase(cradleFlowJourney)){
            nextGenSubFlow = CartConstants.NEXTGEN_EC_C;
        }
        return nextGenSubFlow;
    }

    private boolean isHumCategoryDevice(AddDeviceUIRequest request) {
        return request.getData() != null && !CollectionUtils.isEmpty(request.getData().getLines())
                && request.getData().getLines().get(0).getDevice() != null && CartConstants.HUM_CATEGORY.equalsIgnoreCase(request.getData().getLines().get(0).getDevice().getCategory());
    }

    private List<String> getSubFlowList(String subFlow) {
        List<String> subFlowList = new ArrayList<>();
        if (StringUtilities.isNotEmptyOrNull(subFlow)) {
            subFlowList = new ArrayList<>(Arrays.asList(subFlow.split(Pattern.quote("|"))));
        }
        return subFlowList;
    }
    public Mono<Boolean> updateSubFlowInTaggingForNextgenBYOD(AddDeviceUIResponse pegaResponse, AddDeviceUIRequest request, List<String> subFlowList){
        try{
            List<String> finalSubFlowList = new ArrayList();
            if(subFlowList.contains(CartConstants.NXT_GEN_BYOD) && !subFlowList.contains(CartConstants.NXT_GEN_BYOD_BAU)
                    && request.getData() != null && StringUtilities.isNotEmptyOrNull(request.getData().getSubFlow())
                    && request.getData().getSubFlow().equalsIgnoreCase(CartConstants.NXT_GEN_BYOD_BAU)){
                logger.info("CartAddDeviceHelper1 :: Inside updateSubFlowInTaggingForNextgenBYOD " + CartConstants.NXT_GEN_BYOD_BAU);
                finalSubFlowList.add(CartConstants.NXT_GEN_BYOD_BAU);
            }
            if ((CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())
                    || CartConstants.BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType()))
                    && !subFlowList.contains(CartConstants.NXT_GEN_BYOD) && !subFlowList.contains(CartConstants.NXT_GEN_BYOD_BAU)
                    && request.getData() != null) {
                if(StringUtilities.isEmptyOrNull(request.getData().getSubFlow())
                        || !CartConstants.NXT_GEN_BYOD_BAU.equalsIgnoreCase(request.getData().getSubFlow())) {
                    logger.info("CartAddDeviceHelper1 :: Inside updateSubFlowInTaggingForNextgenBYOD " + CartConstants.NXT_GEN_BYOD);
                    finalSubFlowList.add(CartConstants.NXT_GEN_BYOD);
                }
                else if(CartConstants.NXT_GEN_BYOD_BAU.equalsIgnoreCase(request.getData().getSubFlow())) {
                    logger.info("CartAddDeviceHelper1 :: Inside updateSubFlowInTaggingForNextgenBYOD " + CartConstants.NXT_GEN_BYOD_BAU);
                    finalSubFlowList.add(CartConstants.NXT_GEN_BYOD_BAU);
                }
            }

            return updateSubFlowNameInVzdl(request, finalSubFlowList);
        }
        catch(Exception e){
            logger.error("Exception at updateSubFlowInTaggingForNextGenBYOD",e);
            return Mono.just(Boolean.TRUE);
        }

    }

    public Mono<Boolean> updateSubFlowInTaggingForQuickView(String cdlThrottleList, AddDeviceUIRequest request, List<String> subFlowList){
        try{
            logger.info("CDL Throttle List {}", cdlThrottleList);
            List<String> finalSubFlowList = new ArrayList<>();
            if(cdlThrottleList.contains(CartConstants.QUICK_VIEW)){
                    if(request.getCartInfo().isFromFreePhoneQV() && !subFlowList.contains(CartConstants.QUICK_VIEW)){
                        finalSubFlowList.add(CartConstants.QUICK_VIEW);
                        logger.info(CartConstants.CART_ADD_DEVICE_HELPER1_FOR_QUICKVIEW,CartConstants.QUICK_VIEW);
                    } else if(!request.getCartInfo().isFromFreePhoneQV() && !subFlowList.contains(QUICK_C_VIEW)){
                        finalSubFlowList.add(CartConstants.QUICK_C_VIEW);
                        logger.info(CartConstants.CART_ADD_DEVICE_HELPER1_FOR_QUICKVIEW,CartConstants.QUICK_C_VIEW);
                    }
            } else if(cdlThrottleList.contains(CartConstants.QUICK_C_VIEW)){
                if(!subFlowList.contains(QUICK_C_VIEW)){
                    finalSubFlowList.add(CartConstants.QUICK_C_VIEW);
                }
                logger.info(CartConstants.CART_ADD_DEVICE_HELPER1_FOR_QUICKVIEW,CartConstants.QUICK_C_VIEW);
            }

            // join all the values of finalSubFlowList by | and set it in "subFlow" in vzPage map
        String finalSubFlow = (String) ((List) finalSubFlowList).stream().collect(Collectors.joining("|"));
        if (StringUtilities.isNotEmptyOrNull(finalSubFlow)) {

            logger.info("CartAddDeviceHelper1 :: final subflow is :{} ", finalSubFlow);

            dlUtilityService.upsertVZPageSubFLow(finalSubFlow, false, CartConstants.SUB_FLOW).subscribeOn(Schedulers.parallel())
                    .subscribe();
          //  return Mono.just(Boolean.TRUE);
        }
        }
        catch(Exception exception){
            logger.error("Exception at updateSubFlowInTaggingForQuickView",exception);
            return Mono.just(Boolean.TRUE);
        }
        return Mono.just(Boolean.TRUE);
    }
    private Mono<Boolean> updateSubFlowNameInVzdl(AddDeviceUIRequest addDeviceUIRequest , List<String> finalSubFlowList) {
        logger.info("CartUpdateOperationsController :: Inside updateSubFlowNameInVzdl");
        String finalSubFlow = "";
        try {
            // determine actual sub flow type based on byodEsimPhone, smartIMEI whether user has selected esim, psim or esimltr.
            // Check if this subflow doesn't already exist in finalSubFlowList, then add it
            if (CartConstants.NSE_BYOD.equalsIgnoreCase(addDeviceUIRequest.getCartInfo().getIntendType())
                    || CartConstants.BYOD.equalsIgnoreCase(addDeviceUIRequest.getCartInfo().getIntendType())) {
                if (StringUtilities.isNotEmptyOrNull(addDeviceUIRequest.getData().getSubFlow())
                        && addDeviceUIRequest.getData().getSubFlow().contains(CartConstants.INSTANT_SUBFLOW)
                        && !finalSubFlowList.contains(CartConstants.INSTANT_SUBFLOW))
                    finalSubFlowList.add(CartConstants.INSTANT_SUBFLOW);
                String subFlow = determineSubFlowBasedOnUserSelection(addDeviceUIRequest);
                logger.info("OmniDlBuilder :: subFlow based on user's selection is :{} ", subFlow);
                if (StringUtilities.isNotEmptyOrNull(subFlow) && !finalSubFlowList.contains(subFlow))
                    finalSubFlowList.add(subFlow);

                // join all the values of finalSubFlowList by | and set it in "subFlow" in vzPage map
                finalSubFlow = finalSubFlowList.stream().collect(Collectors.joining("|"));
                logger.info("OmniDlBuilder :: final subflow is :{} ", finalSubFlow);
                dlUtilityService.upsertVZPageSubFLow(finalSubFlow, false, CartConstants.SUB_FLOW).subscribeOn(Schedulers.parallel())
                        .subscribe();
            }else if(addDeviceUIRequest.getData()!=null && addDeviceUIRequest.getData().getIsByodRecFlow()!=null && Boolean.TRUE.equals(addDeviceUIRequest.getData().getIsByodRecFlow())){
                String subFlow = CartConstants.NSE.equalsIgnoreCase(addDeviceUIRequest.getCartInfo().getIntendType()) ? CartConstants.BYOD_NSE : CartConstants.BYOD_AAL;
                logger.info("CartAddDeviceHelper1 :: Inside updateSubFlowInTaggingForBYODRecommendations :: {}" ,subFlow);
                finalSubFlowList.add(subFlow);
                finalSubFlow = finalSubFlowList.stream().collect(Collectors.joining("|"));
                logger.info("OmniDlBuilder :: final subflow is :{} ", finalSubFlow);
                dlUtilityService.upsertVZPageSubFLow(finalSubFlow, false, CartConstants.SUB_FLOW).subscribeOn(Schedulers.parallel())
                        .subscribe();
            }
            return Mono.just(Boolean.TRUE);
        } catch (Exception e) {
            logger.error("Exception while calling dlService in addDevice to update subFlow value in redis", e);
            return Mono.just(Boolean.FALSE);
        }
    }

    private String determineSubFlowBasedOnUserSelection(AddDeviceUIRequest addDeviceUIRequest) {
        if (addDeviceUIRequest.getData().getLines().get(0) != null && addDeviceUIRequest.getData().getLines().get(0).getDevice().getByodESimPhone() != null &&
                addDeviceUIRequest.getData().getLines().get(0).getDevice().getByodESimPhone()) {
            if (addDeviceUIRequest.getData().getLines().get(0).getDevice().getSmartIMEI() != null &&
                    addDeviceUIRequest.getData().getLines().get(0).getDevice().getSmartIMEI())
                return CartConstants.ESIM_INSTANT_ACTIVATION_SUBFLOW;
            return CartConstants.ESIM_LATER_ACTIVATION_SUBFLOW;
        }
        return CartConstants.PSIM_SUBFLOW;
    }
    public Mono<AddDeviceUIRequest> updateMtnInUiRequest(AddDeviceUIRequest request,CartRedisData data){
        if(null!=data && StringUtilities.isNotEmptyOrNull(data.getCartId())
                && null != request.getData()
                && CollectionUtilities.isNotEmptyOrNull(request.getData().getLines())
                && null != request.getData().getLines().get(0)
                && StringUtilities.isEmptyOrNull(request.getData().getLines().get(0).getMtn())
                && NEXTGEN_PLAN_FIRST_ELIGIBLE_INTENT.contains(Optional.of(request)
                .map(AddDeviceUIRequest::getCartInfo).map(DeviceCartInfo::getIntendType).orElse(""))
                && StringUtils.isNotEmpty(data.getCradleFlowJourney())
                && NEXTGEN_CRADLE_FLOW_JOURNEY_LIST.contains(data.getCradleFlowJourney())){

            return cxpService.retrieveCart(data.getCartId(),false,null).flatMap(retrieveCartCXPResponse->{
                if(null!=retrieveCartCXPResponse
                        && null!=retrieveCartCXPResponse.getData()
                        && null!=retrieveCartCXPResponse.getData().getCart()
                        && CollectionUtilities.isNotEmptyOrNull(retrieveCartCXPResponse.getData().getCart().getCartValidationErrors())){
                    CartValidationError cartValidationError=retrieveCartCXPResponse.getData().getCart().getCartValidationErrors().stream().filter(eachLine->CartConstants.BLOCKER.equalsIgnoreCase(eachLine.getErrorLevel())
                            && DEVICE_STEP_ERROR_CODE.equalsIgnoreCase(eachLine.getErrorCode())).findFirst().orElse(null);
                    if(null!=cartValidationError) {
                        String mtn=Arrays.asList(cartValidationError.getFieldPath().split(",")).get(0);
                        request.getData().getLines().get(0).setMtn(mtn);
                        request.getCartInfo().setProcessingMTN(mtn);
                    }
                }
                return Mono.just(request);
            });
        } else if(null!=data && CartConstants.EUP_5G.equalsIgnoreCase(Optional.of(request)
                .map(AddDeviceUIRequest::getCartInfo).map(DeviceCartInfo::getIntendType).orElse(""))
                && featureFlagHelper.isRouterUpgradeFlagEnabled()) {
            if (StringUtilities.isNotEmptyOrNull(data.getMtn()))
                request.setMtn(data.getMtn());
            if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN()))
                request.getCartInfo().setProcessingMTN(data.getProcessingMTN());
            if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
                request.getCartInfo().setCaseId(data.getCaseId());
            if (StringUtilities.isNotEmptyOrNull(data.getIsReturnRequired())) {
                request.getCartInfo().setIsReturnRequired(data.getIsReturnRequired());
            }
        }
        return Mono.just(request);
    }
        public Mono<AddDeviceUIRequest> setCradleFlowJourneyForByodNextGenMVA(AddDeviceUIRequest request){
            if(request.getCartInfo().getIntendType().equalsIgnoreCase(CartConstants.NSE_BYOD) && request.getChannelId().contains("MFA") && isCategoryEnabledForByodNextGen(request) && Boolean.TRUE.equals(request.getData().getNextGenByodMvaFlow())){
                logger.info("Fetching cradle data map from redis");
                return cradleAllocator.getDataMap().flatMap(map->{
                    logger.info("Cradle data map from redis is : {}",map);
                    if(!map.isEmpty() && map.containsKey(CartConstants.THROTTLE_LIST) && StringUtilities.isNotEmptyOrNull(map.get(CartConstants.THROTTLE_LIST))) {
                        String throttleList=map.get(CartConstants.THROTTLE_LIST);
                        if (!throttleList.contains(CartConstants.NEXTGEN_C_BYOD_MVA_CDL_VALUE)) {
                            logger.info("Setting cradleFlowJourney as NEXTGEN for nse byod mva flow");
                            request.getCartInfo().setCradleFlowJourney(CartConstants.NEXT_GEN);
                        }
                    }
                    return Mono.just(request);
                });
            }
            return Mono.just(request);
        }

        private boolean isCategoryEnabledForByodNextGen(AddDeviceUIRequest request) {
            return request.getData()!=null && !CollectionUtils.isEmpty(request.getData().getLines())
                    && request.getData().getLines().get(0).getDevice()!=null && deviceCategoriesForNextGenByodMva.contains(request.getData().getLines().get(0).getDevice().getCategory())? Boolean.TRUE:Boolean.FALSE;
        }

    public Mono<CradleResponse> invokeCradleForComboExistingCustomer(AddDeviceUIRequest request) {
        ServerHttpRequest httpRequest = null;
        ServerHttpResponse httpResponse = null;
        Map<String, String> dataMap = new HashMap<String, String>();
        String mtn = Optional.ofNullable(request.getData().getLines().get(0).getMtn()).orElse("");
        dataMap.put(CHANNEL, request.getChannelId());
        dataMap.put(CradleConstants.PAGE_NAME, "ComboOrderAllowedForExistingCustomer");
        dataMap.put(CradleConstants.MTN, mtn);
        dataMap.put(CradleConstants.LOCATION_CODE,request.getCartInfo().getLocationCode());
        dataMap.put("uswin",request.getCartInfo().getSalesRepId());
        httpRequest = request.getHttpRequest();
        httpResponse = request.getHttpResponse();
        return cradleAllocator.invokeReactiveCradle(httpRequest, httpResponse, dataMap);
    }

    public Mono<Boolean> checkCradleResponseForComboOrderExistingCustomer(AddDeviceUIRequest request) {
        Mono<CradleResponse> cradleResp = Mono.just(new CradleResponse());
        cradleResp = invokeCradleForComboExistingCustomer(request);
        return cradleResp.flatMap(cradleResponse -> {
            String throttleList = processCradleResponse(cradleResponse);
            logger.info("Cradle Response for combo order: "+throttleList);
            if(throttleList.contains("|ComboOrderD2D|") && (request.getChannelId().equalsIgnoreCase(CartConstants.OMNI_D2D)
                    || request.getChannelId().equalsIgnoreCase(CartConstants.D2D_IPAD))){
                request.getCartInfo().setIsComboOrderAllowed(Boolean.TRUE);
                return Mono.just(Boolean.TRUE);
            }
            if(throttleList.contains("|ComboOrderRetail|") && (request.getChannelId().equalsIgnoreCase(CartConstants.RETAIL)
                    || request.getChannelId().equalsIgnoreCase(CartConstants.RETAIL_IPAD))){
                request.getCartInfo().setIsComboOrderAllowed(Boolean.TRUE);
                return Mono.just(Boolean.TRUE);
            }
            if(throttleList.contains("|ComboOrderTelesales|") &&
                    request.getChannelId().equalsIgnoreCase(CartConstants.OMNI_TELESALES)){
                request.getCartInfo().setIsComboOrderAllowed(Boolean.TRUE);
                return Mono.just(Boolean.TRUE);
            }
            if(throttleList.contains("|ComboOrderCare|") &&
                    request.getChannelId().equalsIgnoreCase(CartConstants.OMNI_CARE)){
                request.getCartInfo().setIsComboOrderAllowed(Boolean.TRUE);
                return Mono.just(Boolean.TRUE);
            }
            if(throttleList.contains("|ComboOrderChatStore|") &&
                    request.getChannelId().equalsIgnoreCase(CartConstants.CHAT_STORE)){
                request.getCartInfo().setIsComboOrderAllowed(Boolean.TRUE);
                return Mono.just(Boolean.TRUE);
            }
            if(throttleList.contains("|ComboOrderIndirect|") &&
                    (request.getChannelId().equalsIgnoreCase(CartConstants.OMNI_INDIRECT) ||
                            request.getChannelId().equalsIgnoreCase(CartConstants.OMNI_INDIRECT_TAB))){
                request.getCartInfo().setIsComboOrderAllowed(Boolean.TRUE);
                return Mono.just(Boolean.TRUE);
            }
            return Mono.just(Boolean.FALSE);
        });
    }

    private String processCradleResponse(CradleResponse cradleResponse) {
        String throttleList="";
        if (null != cradleResponse && null != cradleResponse.getOutPut()) {
            logger.info("cradleResponse output is --> " + cradleResponse.getOutPut());
           // ObjectMapper mapper = new ObjectMapper();
            try {
                JsonNode cradleOutputJsonNode = mapper.readTree(cradleResponse.getOutPut());
                if (null != cradleOutputJsonNode && null != cradleOutputJsonNode.get(CartConstants.THROTTLE_LIST)) {
                    throttleList = cradleOutputJsonNode.get(CartConstants.THROTTLE_LIST).asText();
                    logger.info("Value of throttleList ---" + throttleList);
                }
            } catch (Exception ex) {
                logger.error(CartConstants.JSON_PRCSSNG_EXCPTN_STRNG + ex);
            }
        }else{
            logger.info("cradleResponse output is --> null");
        }
        return throttleList;
    }

    public Mono<AddDeviceUIRequest> setCradleFlagForCombo(Mono<Boolean> cradleResponse ,AddDeviceUIRequest request){
        if(request.getCartInfo().getIntendType().equalsIgnoreCase(CartConstants.AAL_5G)
                || request.getCartInfo().getIntendType().equalsIgnoreCase(CartConstants.AAL_LTE)
                || request.getCartInfo().getIntendType().equalsIgnoreCase(CartConstants.AAL)
                || request.getCartInfo().getIntendType().equalsIgnoreCase(CartConstants.EUP)
                || request.getCartInfo().getIntendType().equalsIgnoreCase(CartConstants.BYOD)
                || request.getCartInfo().getIntendType().equalsIgnoreCase(CartConstants.EUPBYOD)
                || request.getCartInfo().getIntendType().equalsIgnoreCase(CartConstants.AAL_BYOD) ){
            return cradleResponse.flatMap(flag->{
                Boolean isComboOrderAllowed = flag;
                if(isComboOrderAllowed)
                {
                    request.getCartInfo().setIsComboOrderAllowed(true);
                }
                else {
                    request.getCartInfo().setIsComboOrderAllowed(false);
                }
                return Mono.just(request);
            });
        }
        return Mono.just(request);
    }
    private boolean validatePegaResponse(AddDeviceUIResponse pegaResponse) {
        if(null != pegaResponse.getServiceBody() &&
                null != pegaResponse.getServiceBody().getServiceResponse() && null != pegaResponse.getServiceBody().getServiceResponse().getContext() &&
                null != pegaResponse.getServiceBody().getServiceResponse().getContext().getContextInfo()) {
            return true;
        }
        return false;
    }

    public Mono<AddDeviceUIResponse> addUpgradeDetails(AddDeviceUIRequest request, ServerHttpResponse httpResponse) {
        Mono<CartRedisData> rr = redisHelper.getDataFromRedis();
        return rr.flatMap(data -> preHandleAddDevice.execute(request, data)
                .flatMap(res -> {
                    if (!res) {
                        return Mono.error(new SOEHTTPException(500, SOEErrorHolder.builder().errors(CartPegaRequestErrorsUtil.restrictMultiLineFlowError()).build()));
                    }
                    return addUpgradeDetails(request, data,httpResponse);
                }));
    }

    @SuppressWarnings("squid:S3776")
    public Mono<AddDeviceUIResponse> addUpgradeDetails(AddDeviceUIRequest request, CartRedisData data, ServerHttpResponse httpResponse) {
        String channelType = CartUtil.getChannelType(request.getChannelId());
        Mono<String> roleData = redisHelper2.getRole();
        AddDeviceUIResponse addDeviceUIResponse = new AddDeviceUIResponse();
        
        return Mono.zip(roleData, redisHelper2.getEdgeBuyoutRedisData()).flatMap(tuple -> {
        	String vzwRole = tuple.getT1();
        	HashMap ebData = tuple.getT2();//ONEAPP-9763 changes
            if (cartAddDeviceHelper.isDigital(channelType) && cartAddDeviceHelper.checkForAccountMemberRestriction(request, vzwRole)) {
                return Mono.error(new SOEHTTPException(500, SOEErrorHolder.builder().errors(CartPegaRequestErrorsUtil.mobileSecureConnectedSmartWatchError()).build()));
            }
            if (request.getCartInfo() != null && request.getCartInfo().isFlexV2()) {
                cartRequestBuilder.buildAddDeviceRequest(request, data);
                logger.info("Request build ", request);
            }

            if (null != request.getData() && null != request.getData().getLines()
                    && null != request.getData().getLines().get(0) && null != request.getData().getLines().get(0).getDevice()
                    && StringUtilities.isEmptyOrNull(request.getData().getLines().get(0).getDevice().getId())
                    && StringUtilities.isEmptyOrNull(data.getDeviceSorId())) {
                List<CartError> errors = new ArrayList<CartError>();
                CartError error = new CartError();
                error.setNamespace(CartConstants.SOE_CART_SERVICE);
                error.setName(CartConstants.REQUEST_VALIDATION_ERROR);
                error.setMessage(CartConstants.DEVICEID + " is/are missing.");
                errors.add(error);
                addDeviceUIResponse.setErrors(errors);
                return Mono.just(addDeviceUIResponse);
            }

            if (cartAddDeviceHelper.isDigital(channelType)) {
                if (cartAddDeviceHelper.getzipCode(request)) {
                    List<CartError> errors = new ArrayList<CartError>();
                    CartError error = new CartError();
                    error.setNamespace(CartConstants.SOE_CART_SERVICE);
                    error.setName(CartConstants.REQUEST_VALIDATION_ERROR);
                    error.setMessage(CartConstants.ZIPCODE_INVALID);
                    errors.add(error);
                    addDeviceUIResponse.setErrors(errors);
                    return Mono.just(addDeviceUIResponse);
                }
            }

            if(StringUtilities.isEmptyOrNull(request.getCartInfo().getAccountNumber()) && StringUtilities.isNotEmptyOrNull(data.getAccountNumber())){
                request.getCartInfo().setAccountNumber(data.getAccountNumber());
            }
            if(StringUtilities.isEmptyOrNull(request.getCartInfo().getCartCreator()) && StringUtilities.isNotEmptyOrNull(data.getCartCreator())){
                request.getCartInfo().setCartCreator(data.getCartCreator());
            }
            if(StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessingMTN()) && StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())){
                request.getCartInfo().setProcessingMTN(data.getProcessingMTN());
            }
            if(StringUtilities.isEmptyOrNull(request.getCartInfo().getMtnFlow()) && StringUtilities.isNotEmptyOrNull(data.getMtnFlow())){
                request.getCartInfo().setMtnFlow(data.getMtnFlow());
            }
            if (StringUtilities.isNotEmptyOrNull(data.getVzwRoles())) {
                request.getCartInfo().setAmRole(data.getVzwRoles());
            }
            if (request.getCartInfo().getIsComboOrderAllowed() == null && StringUtilities.isNotEmptyOrNull(data.getIsComboOrderAllowed())) {
                if(data.getIsComboOrderAllowed().equalsIgnoreCase(Boolean.TRUE.toString())){
                    request.getCartInfo().setIsComboOrderAllowed(true);
                } else {
                    request.getCartInfo().setIsComboOrderAllowed(false);
                }
            }
            if (StringUtilities.isEmptyOrNull(request.getCartInfo().getCartId()) && StringUtilities.isNotEmptyOrNull(data.getCartId())) {
                request.getCartInfo().setCartId(data.getCartId());
            }
            if (StringUtilities.isEmptyOrNull(request.getCartInfo().getCaseId()) && StringUtilities.isNotEmptyOrNull(data.getCaseId())) {
                request.getCartInfo().setCaseId(data.getCaseId());
            }
            if (StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType()) && StringUtilities.isNotEmptyOrNull(data.getIntendType())) {
                request.getCartInfo().setIntendType(data.getIntendType());
            }
            if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getCaseId())
                    && request.getCartInfo().getCaseId().startsWith("SOF", 0)
                    && request.getCartInfo().getOneClick() != null && request.getCartInfo().getOneClick()) {
                request.getCartInfo().setOneClick(request.getCartInfo().getOneClick());
            }
            if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getDeviceType()) && CartConstants.CONNECTED_CAR.equalsIgnoreCase(request.getCartInfo().getDeviceType())) {
                request.getCartInfo().setDeviceId(data.getImei());
            }
            if (StringUtilities.isNotEmptyOrNull(data.getVzId())) {
                request.setVzId(data.getVzId());
            }
            if (null != request.getData() && CollectionUtilities.isNotEmptyOrNull(request.getData().getLines())) {
                for (Lines line : request.getData().getLines()) {
                if(featureFlagHelper.isSafeCheckForBuyOutFFlag()) {
                    if (checkBuyOutFlag(request)) {
                        //ONEAPP-9763 changes start
                        Optional.ofNullable(line)
                                .map(l -> l.getMtn())
                                .filter(mtn -> !ObjectUtils.isEmpty(ebData.get(mtn)))
                                .map(mtn -> {
                                    logger.info("Finding CartRedisData for mtn :: {}", mtn);
                                    CartRedisData edgeBuyoutData = mapper.convertValue(ebData.get(mtn),
                                            CartRedisData.class);
                                    logger.info("Found CartRedisData for mtn :: {} is {}", mtn, edgeBuyoutData);
                                    return edgeBuyoutData;
                                })
                                .filter(edgeBuyoutData -> Objects.nonNull(edgeBuyoutData.getCartInfo()))
                                .ifPresent(edgeBuyoutData -> {
                                    CartInfo cartInfo = edgeBuyoutData.getCartInfo();
                                    logger.info("Setting IsEdgeBuyOut true for mtn :: {}", line.getMtn());
                                    line.setIsEdgeBuyOut(true);
                                    request.getCartInfo().setBuyOutFlag(cartInfo.getBuyOutFlag());

                                    Optional.ofNullable(line.getEdgeup())
                                            .or(() -> Optional.of(new EdgeUp()))
                                            .ifPresent(edgeup -> {
                                                if (StringUtilities.isNotEmptyOrNull(edgeup.getDeviceId()) && nonNull(edgeBuyoutData.getEdgeUpData())) {
                                                    String deviceId = Optional.ofNullable(edgeBuyoutData.getEdgeUpData().getLines())
                                                            .flatMap(lines -> Arrays.stream(lines).filter(l -> line.getMtn().equals(l.getMtn())).findAny())
                                                            .map(Lines::getEdgeup).map(EdgeUp::getDeviceId).orElse("");
                                                    edgeup.setDeviceId(deviceId);
                                                }
                                                line.setEdgeup(edgeup);
                                            });
                                });
                        //ONEAPP-9763 changes ends
                    }
                } else {
                    //ONEAPP-9763 changes start
                    Optional.ofNullable(line)
                            .map(l -> l.getMtn())
                            .filter(mtn -> !ObjectUtils.isEmpty(ebData.get(mtn)))
                            .map(mtn ->  {
                                logger.info("Finding CartRedisData for mtn :: {}", mtn);
                                CartRedisData edgeBuyoutData = mapper.convertValue(ebData.get(mtn),
                                        CartRedisData.class);
                                logger.info("Found CartRedisData for mtn :: {} is {}", mtn, edgeBuyoutData);
                                return edgeBuyoutData;
                            })
                            .map(edgeBuyoutData -> edgeBuyoutData.getCartInfo())
                            .ifPresent(cartInfo -> {
                                logger.info("Setting IsEdgeBuyOut true for mtn :: {}", line.getMtn());
                                line.setIsEdgeBuyOut(true);
                                request.getCartInfo().setBuyOutFlag(cartInfo.getBuyOutFlag());
                            });
                    //ONEAPP-9763 changes ends
                }
                	
                    if (null != data.getIsCommonPDP()) {
                        line.setIsCommonPDP(data.getIsCommonPDP());
                        logger.info("set the isCommonPDP value in CJCM request: {}", data.getIsCommonPDP());
                    }
                }
            }
            if(StringUtilities.isNotEmptyOrNull(data.getExistingCase()) && data.getExistingCase().equalsIgnoreCase(CartConstants.TRUE_FLAG)){
                request.getCartInfo().setCartId("");
                request.getCartInfo().setCaseId("");
            }
            setRestrictedFromRedisToRequest(data, request);

            Mono<AddDeviceUIResponse> UIResponse = bpmHelper.addUpgradeDetails(request)
                    .doOnError(e -> logger.error(
                            CartConstants.ADD_UPGRADE_DETAILS_METHOD_EXCEPTION,
                            e))
                    .onErrorResume(
                            SOEHTTPException.class,
                            e -> {
                                if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))) {
                                    logger.error(CartConstants.ADD_DEVICE_METHOD_EXCEPTION,e.getErrorCode());

                                    Mono<ResponseEntity<SOEErrorHolder>> errorHolder = exHandler
                                            .fetchAEMMessage(e)
                                            .doOnError(e1 -> logger.error(CartConstants.ADD_DEVICE_METHOD_EXCEPTION,e1))
                                            .onErrorResume(SOEHTTPException.class, e1 -> { return CartPegaResponseErrorsUtil.handleAEMError(e1);
                                                    });
                                    return errorHolder
                                            .flatMap(eh -> {SOEErrorHolder hold = eh.getBody();
                                                AddDeviceUIResponse resp = CartPegaResponseErrorsUtil
                                                        .handleCommonError(hold);
                                                return Mono.just(resp);
                                            });
                                }
                                return Mono.just(CartPegaResponseErrorsUtil.handleCommonError(e.getErrorHolder()));
                            });
            return UIResponse.flatMap(response -> {
                if (response != null && CollectionUtilities.isEmptyOrNull(
                        response.getErrors())) {
                    try {
                        if (response.getServiceBody() != null
                                && response.getServiceBody().getServiceResponse() != null
                                && response.getServiceBody().getServiceResponse().getContext() != null
                                && response.getServiceBody().getServiceResponse().getContext().getCartInfo() != null
                                && response.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartId() != null ) {
                            request.getCartInfo().setCartId(response.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartId());
                        }
                        if (request.getData().getLines()
                                .size() > 0) {
                            String selectedPromoId = request.getData().getLines().get(0).getSelectedPromoId();
                            String selectedPromoType = request.getData().getLines().get(0).getSelectedPromoType();
                            String flowType = cartAddDeviceHelper.evaluteFlowType(request.getCartInfo().getIntendType());
                            String promosAppliedVal = "none";
                            String offerType = (request.getData().getLines().get(0).getIsStrategicOffer()) ? "S" : "N";
                            String choiceOrBau = CartConstants.IS_BAU_OFFER;
                            String selectedSedOfferId = request.getData().getLines().get(0).getSelectedSedOfferId();
                            if (StringUtilities
                                    .isNotEmptyOrNull(
                                            selectedPromoId)
                                    && StringUtilities
                                    .isNotEmptyOrNull(
                                            selectedPromoType)) {
                                if (StringUtilities.isNotEmptyOrNull(selectedSedOfferId) && StringUtilities.isNotEmptyOrNull(flowType)) {
                                    promosAppliedVal = selectedPromoType + "-" + selectedPromoId + "-" + offerType + "-" + choiceOrBau + "-" + flowType + "-" + selectedSedOfferId;
                                } else if (StringUtilities.isNotEmptyOrNull(selectedSedOfferId)) {
                                    promosAppliedVal = selectedPromoType + "-" + selectedPromoId + "-" + offerType + "-" + choiceOrBau + "-" + selectedSedOfferId;
                                } else if (StringUtilities.isNotEmptyOrNull(flowType)) {
                                    promosAppliedVal = selectedPromoType + "-" + selectedPromoId + "-" + offerType + "-" + choiceOrBau + "-" + flowType;
                                } else {
                                    promosAppliedVal = selectedPromoType + "-" + selectedPromoId + "-" + offerType + "-" + choiceOrBau;
                                }
                            }
                            cxpHelper.updateDLData(null,
                                    null,
                                    "promosApplied",
                                    promosAppliedVal, null, null);
                        }
                    } catch (Exception e) {
                        logger.error(
                                "exception while setting cartCount and cartOrderFlowType");
                    }
                }
                return Mono.just(response);
            });
        });
    }

    public void setRestrictedFromRedisToRequest(CartRedisData data, AddDeviceUIRequest request){
        if(data != null && data.getDeviceLines() != null && data.getDeviceLines().size() > 0 && data.getDeviceLines().get(0) != null &&
                StringUtilities.isNotEmptyOrNull(data.getDeviceLines().get(0).getRestricted())){
            if(request.getData() != null && request.getData().getLines() != null && request.getData().getLines().size() > 0
                    && request.getData().getLines().get(0) != null && StringUtilities.isEmptyOrNull(request.getData().getLines().get(0).getRestricted())){
                request.getData().getLines().get(0).setRestricted(data.getDeviceLines().get(0).getRestricted());
            }

        }
    }

    public boolean checkBuyOutFlag(AddDeviceUIRequest request) {
        return StringUtilities.isEmptyOrNull(request.getCartInfo().getBuyOutFlag())
                || !CartConstants.Y.equalsIgnoreCase(request.getCartInfo().getBuyOutFlag());
    }

    public String mapIntendType(DeviceCartInfo cartInfo, AddDeviceData data) {
        if(StringUtilities.isNotEmptyOrNull(cartInfo.getProcessAction()) && "addSIM".equalsIgnoreCase(cartInfo.getProcessAction())){
            return "dc";
        } else if (StringUtilities.isNotEmptyOrNull(cartInfo.getIntendType())) {
            String intendType = cartInfo.getIntendType();
            if(CartConstants.BYOD.equalsIgnoreCase(intendType)){
                return CartConstants.AALBYOD;
            } else if (CartConstants.EUPBYOD.equalsIgnoreCase(intendType)) {
                return CartConstants.ESO_EUPBYOD;
            } else if (CartConstants.NSE_BYOD.equalsIgnoreCase(intendType)) {
                return  CartConstants.NSO_NSEBYOD;
            } else if (StringUtilities.isNotEmptyOrNull(cartInfo.getMtnFlow()) && cartInfo.getMtnFlow().equalsIgnoreCase(CartConstants.AI_QUOTE)
                    && CartConstants.EUP.equalsIgnoreCase(intendType) && data!=null && data.getLines()!= null && data.getLines().get(0) !=null && data.getLines().get(0).getPlan()!=null && data.getLines().get(0).getPlan().getId()!=null) {
                return CartConstants.EUP_CPC;
            }
            else {
                return intendType;
            }
        }
        return null;
    }

    public Mono<NGDTaxEngineResponseData> callTaxEngine(String fipsCode, NGDTaxEngineRequest uiRequest) {
        NGDTaxEngineRequest sorRequest = mapToTaxSORRequest(fipsCode, uiRequest);
        logger.info("Mapped sorRequest -> {} ", sorRequest);
        return cxpService.callTaxEngineAPI(sorRequest).map(uteResp -> {
                    Optional.of(uteResp).map(NGDTaxEngineBaseResponse::getData).map(NGDTaxEngineBaseData::getData)
                            .ifPresent(ngdTaxEngineResponseData -> {
                                logger.info("ngdUTe response status -> {}", ngdTaxEngineResponseData.getStatus());
                                Optional.of(ngdTaxEngineResponseData).filter(respData -> CollectionUtilities.isNotEmptyOrNull(respData.getStatus())).filter(respData -> "SUCCESS".equalsIgnoreCase((String)respData.getStatus().get("category"))).ifPresent(respDate -> respDate.setStatus(null));
                            });
                    return uteResp;
                })
                .map(NGDTaxEngineBaseResponse::getData)
                .map(NGDTaxEngineBaseData::getData)
                .map(this::roundOffTax);

    }

    private NGDTaxEngineResponseData roundOffTax(NGDTaxEngineResponseData ngdTaxEngineResponseData) {
        Optional.ofNullable(ngdTaxEngineResponseData)
                .ifPresent(ngdTaxengineResp -> {
                    ngdTaxengineResp.setOrderTotalTax(Optional.ofNullable(ngdTaxEngineResponseData.getOrderTotalTax()).map(this::formatToDecimalTwoDigitNumber).orElse("0.0"));
                    Optional.ofNullable(ngdTaxengineResp.getLineTaxDetails())
                            .filter(CollectionUtilities::isNotEmptyOrNull)
                            .ifPresent(taxLines -> taxLines.forEach(taxLine -> {
                                taxLine.setTotalPriceForTax(Optional.ofNullable(taxLine.getTotalPriceForTax()).map(this::formatToDecimalTwoDigitNumber).orElse("0.0"));
                                taxLine.setTaxGrandTotal(Optional.ofNullable(taxLine.getTaxGrandTotal()).map(this::formatToDecimalTwoDigitNumber).orElse("0.0"));
                                Optional.ofNullable(taxLine.getTaxPerItem()).filter(CollectionUtilities::isNotEmptyOrNull)
                                        .ifPresent(taxPerItems -> taxPerItems.forEach(taxPerItem -> taxPerItem.setTaxAmount(Optional.ofNullable(taxPerItem.getTaxAmount()).map(this::formatToDecimalTwoDigitNumber).orElse("0.0"))));

                            }));
                });
        return ngdTaxEngineResponseData;
    }

    private String formatToDecimalTwoDigitNumber(String inputTax) {
        return String.valueOf(df2.format(CartCxpResponseUtil.round(Double.parseDouble(inputTax)) / 100));
    }



    private NGDTaxEngineRequest mapToTaxSORRequest(String fipsCode, NGDTaxEngineRequest uiRequest) {
        NGDTaxEngineRequest ngdTaxEngineRequest = new NGDTaxEngineRequest();
        NGDCalculateTaxDetailsMeta meta = new NGDCalculateTaxDetailsMeta();
        meta.setClientId(CartConstants.CXP_AGGREGATE);
        meta.setClientTrackingId(CartConstants.CXP_AGGREGATE);
        meta.setLineOfBusiness("Consumer");
        meta.setOperation("CalculateTax");
        meta.setOriginatingSystem("CXP_POS");
        meta.setUserId(CartConstants.CXP_AGGREGATE);
        ngdTaxEngineRequest.setMeta(meta);
        NGDCalculateTaxDetailsRequest calculateTaxDetailsRequest = new NGDCalculateTaxDetailsRequest();
        Optional.of(uiRequest).map(NGDTaxEngineRequest::getCalculateTaxDetailsRequest).map(NGDCalculateTaxDetailsRequest::getTaxLines)
                .filter(CollectionUtilities::isNotEmptyOrNull)
                .map(uiTaxes -> uiTaxes.stream().map(taxLineRequest ->{
                            NGDTaxLinesRequest ngdSORTaxLines = new NGDTaxLinesRequest();
                            ngdSORTaxLines.setMultiLineSeqNumber(taxLineRequest.getMultiLineSeqNumber());
                            ngdSORTaxLines.setFipsCode(fipsCode);
                            ngdSORTaxLines.setItemsForTax(taxLineRequest.getItemsForTax());
                            return ngdSORTaxLines;
                        }).collect(Collectors.toList())
                ).ifPresent(calculateTaxDetailsRequest::setTaxLines);
        ngdTaxEngineRequest.setCalculateTaxDetailsRequest(calculateTaxDetailsRequest);
        return ngdTaxEngineRequest;
    }

    public Mono<Boolean> updateSubFlowForOneClickExpressUpgrade(AddDeviceUIRequest request){
        try{
            return dlUtilityService.getSubFlowVal().flatMap(subFlow -> {
                List<String> subFlowList = getSubFlowList(subFlow);
                return updateSubFlowForOneClickUpgrade(request, subFlowList);
            });
        }catch(Exception e){
            logger.error("Exception at updateSubFlowInTaggingForNova",e);
            return Mono.just(Boolean.TRUE);
        }

    }

    public Mono<Boolean> updateSubFlowForOneClickUpgrade(AddDeviceUIRequest request, List<String> subFlowList){
        try{
            List<String> finalSubFlowList = new ArrayList<>();
            if(request != null && request.getData() != null && CollectionUtilities.isNotEmptyOrNull(request.getData().getLines())) {
                request.getData().getLines().forEach(line -> {
                    if (StringUtilities.isNotEmptyOrNull(line.getSelectedPromoType())) {
                        boolean isPlanChangeReq = line.getPlan() != null && StringUtilities.isNotEmptyOrNull(line.getPlan().getId()) ? true : false;
                        boolean isEdgeBuyOut = Boolean.TRUE.equals(line.getIsEdgeBuyOut());
                        this.updateFinalSubFlow(finalSubFlowList, subFlowList, line.getSelectedPromoType(), isPlanChangeReq, isEdgeBuyOut, request);
                    }
                    String finalSubFlow = finalSubFlowList.stream().collect(Collectors.joining("|"));
                    logger.info("CartAddDeviceHelper1 :: final subflow is :{} ", finalSubFlow);
                    dlUtilityService.upsertVZPageSubFLow(finalSubFlow, false, CartConstants.SUB_FLOW).subscribeOn(Schedulers.parallel())
                            .subscribe();
                });
            }
            return Mono.just(Boolean.TRUE);
        }
        catch(Exception e){
            logger.error("Exception at updateSubFlowForOneClickUpgrade",e);
            return Mono.just(Boolean.TRUE);
        }
    }

    /**
     *  Prepare the tag and add in final flow list.
     * @param finalSubFlowList
     * @param subFlowList
     * @param SelectedPromoType
     * @param isPlanChangeReq
     * @param isEdgeBuyOut
     * @param request
     */
    public void updateFinalSubFlow(List<String> finalSubFlowList,List<String> subFlowList,String SelectedPromoType, boolean isPlanChangeReq, boolean isEdgeBuyOut, AddDeviceUIRequest request){
        String entryPoint = request.getData().getEntryPoint();
        logger.info("updateFinalSubFlow isEdgeBuyOut is {}, entryPoint is {}, SelectedPromoType {}", isEdgeBuyOut, entryPoint, SelectedPromoType);
        String oneClickUSubFlowTag = this.prepareSubFlowIClickU(SelectedPromoType, isPlanChangeReq, isEdgeBuyOut, entryPoint);
        this.addSubFlowTag(finalSubFlowList, subFlowList, Collections.singletonList(oneClickUSubFlowTag));
        //one click bau tagging 1clk_t, 1clk_c
        if(featureFlagHelper.isOneclkTaggingFFlagEnabled()) {
            this.addSubFlowTag(finalSubFlowList, subFlowList, this.prepareSubFlowIClick(request));
        }
    }

    private void addSubFlowTag(List<String> finalSubFlowList,List<String> subFlowList, List<String> subFlowTags) {
        Optional.ofNullable(subFlowTags)
                .ifPresent(tags ->
                        tags.stream().filter(tag -> !subFlowList.contains(tag))
                            .forEach(finalSubFlowList::add)
                );
    }

    private String prepareSubFlowIClickU(String selectedPromoType, boolean isPlanChangeReq, boolean isEdgeBuyOut, String entryPoint) {
        StringJoiner joiner = new StringJoiner(CartConstants.EMPTY_STRING);
        joiner.add(CartConstants.ONECLICK_UPG_TAG);

        if (selectedPromoType.equalsIgnoreCase(CartConstants.PROMOTYPE_TRADEIN)) {
            joiner.add(CartConstants.TRADEIN_TAG);
        } else if (selectedPromoType.equalsIgnoreCase(CartConstants.PROMOTYPE_BIC)) {
            joiner.add(CartConstants.BIC_TAG);
        }
        if (isPlanChangeReq) {
            joiner.add(CartConstants.PLAN_CHANGE_TAG);
        }
        if (isEdgeBuyOut) {
            joiner.add(CartConstants.BUYOUT_TAG);
        }
        if (!ObjectUtils.isEmpty(entryPoint)) {
            joiner.add(CartConstants.DELIMETER_HYPHEN)
                    .add(entryPoint);
        }

        String tag = joiner.toString();

        logger.info("prepareSubFlowIClickU subFlow tag :: {}", tag);

        return tag;
    }

    private List<String> prepareSubFlowIClick(AddDeviceUIRequest request) {
        StringJoiner joiner = new StringJoiner(CartConstants.EMPTY_STRING);
        joiner.add(CartConstants.ONECLICK_TAG);
        List<String> tags = new ArrayList<>();
       Optional.ofNullable(request)
                .filter(r -> Objects.nonNull(r.getCartInfo()))
                .filter(r -> Objects.nonNull(r.getCartInfo().getProcessAction()))
                .ifPresent(r -> {
                    if(CartConstants.ADD_DEVICE_WITH_TRADE_IN.equalsIgnoreCase(r.getCartInfo().getProcessAction())) {
                        joiner.add(CartConstants.UNDERSCORE_C);
                    } else if(CartConstants.EXPRESS_UPGRADE.equalsIgnoreCase(r.getCartInfo().getProcessAction())) {
                        joiner.add(CartConstants.UNDERSCORE_T);
                    }
                    tags.add(joiner.toString());
                });

        Optional.ofNullable(request)
                .filter(r -> Objects.nonNull(r.getData()))
                .map(AddDeviceUIRequest::getData)
                .filter(d -> Objects.nonNull(d.getEntryFlow()))
                .map(AddDeviceData::getEntryFlow)
                .ifPresent(tags::add);

        logger.info("prepareSubFlowIClick subFlow tag :: {}", tags);

        return tags;
    }
}