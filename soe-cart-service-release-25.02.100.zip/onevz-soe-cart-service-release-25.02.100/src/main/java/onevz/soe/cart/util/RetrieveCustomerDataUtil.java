package onevz.soe.cart.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.datastore.client.StoreCustomerDatastoreClient;
import onevz.soe.datastore.model.CustomerData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import static onevz.soe.cart.constants.CartConstants.ACCOUNT_OWNER_REDIS_KEY;

@Component
public class RetrieveCustomerDataUtil {
    @Autowired
    private StoreCustomerDatastoreClient customerDatastoreClient;

    @Autowired
    private ObjectMapper mapper;

    private static final Logger logger = LoggerFactory.getLogger(RetrieveCustomerDataUtil.class);

    public Mono<CustomerData> getCustomerDataFromSession (String cartId) {
        Mono<String> customerDataMono = customerDatastoreClient.readStoreCustomerData(cartId, ACCOUNT_OWNER_REDIS_KEY);
        return customerDataMono
                .flatMap(data -> {
                    try {
                        CustomerData customerData = mapper.readValue(data, CustomerData.class);
                        return Mono.just(customerData);
                    } catch (JsonProcessingException e) {
                        logger.error(e.toString());
                        return Mono.just(new CustomerData());
                    }
                }).onErrorResume(err -> Mono.just(new CustomerData()));
    }
}
