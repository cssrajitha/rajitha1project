package onevz.soe.cart.bpm.service;

import onevz.soe.cart.initiatecart.CpcFeatureRequest;
import onevz.soe.cart.initiatecart.CpcFeatureResponse;
import onevz.soe.cart.model.AccessoryFinancingOffers.AccessoryFinancingOffersPegaRequest;
import onevz.soe.cart.model.AccessoryFinancingOffers.AccessoryFinancingOffersPegaResponse;
import onevz.soe.cart.model.addPromoIntent.AddPromoIntentPEGARequest;
import onevz.soe.cart.model.addPromoIntent.AddPromoIntentPEGAResponse;
import onevz.soe.cart.model.affirmfinancing.AffirmFinancingPegaRequest;
import onevz.soe.cart.model.affirmfinancing.AffirmFinancingPegaResponse;
import onevz.soe.cart.model.createCase2.CreateCaseNewCustomerPEGARequest;
import onevz.soe.cart.model.createCase2.CreateCaseNewCustomerPEGAResponse;
import onevz.soe.cart.model.tradeIn.addTradeinToCart.TradeinAddToCartRequest;
import onevz.soe.cart.model.tradeIn.addTradeinToCart.TradeinAddToCartResponse;
import onevz.soe.cart.requests.*;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.tys.reviewOrder.ReviewOrderPegaRequest;
import onevz.soe.cart.tys.reviewOrder.ReviewOrderPegaResponse;
import onevz.soe.cart.ui.responses.CrmRetrieveCartPegaResponse;
import onevz.soe.wsclient.bpm.BPMServices;
import onevz.soe.wsclient.bpm.BPMType;
import onevz.soe.wsclient.bpm.annotations.BPM;
import onevz.soe.wsclient.bpm.model.response.BPMServiceResponse;
import onevz.soe.wsclient.http.MessageLog;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import onevz.soe.constants.HttpMethod;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;
import onevz.soe.cart.model.bulkcartupdate.CreateBulkQuotePegaRequest;
import onevz.soe.cart.model.bulkcartupdate.CreateBulkQuotePegaResponse;

/**
 * CartService BPM Services interface.
 */
@Primary
@Service
public interface CartServiceBPMServices extends BPMServices{

	/**
	 *
	 * @param request
	 * @return AddPromoIntentPEGARequest
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = AddPromoIntentPEGARequest.class, bpmResponseService = AddPromoIntentPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
	Mono<AddPromoIntentPEGAResponse> addPromoIntent(AddPromoIntentPEGARequest request) throws SOEHTTPException;
	/**
	 * 
	 * @param request
	 * @return AddDevicePEGAResponse
	 * @throws SOEHTTPException
	 */

	@BPM(bpmRequestService = AddDevicePEGARequest.class, bpmResponseService = AddDevicePEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<AddDevicePEGAResponse> addDevice(AddDevicePEGARequest request) throws SOEHTTPException;

	@BPM(bpmRequestService = AddDevicePEGARequest.class, bpmResponseService = AddDevicePEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
	Mono<AddDevicePEGAResponse> addUpgradeDetails(AddDevicePEGARequest request) throws SOEHTTPException;


	/**
	 *
	 * @param request
	 * @return AddAllConfiguratorPEGAResponse
	 * @throws SOEHTTPException
	 */

	@BPM(bpmRequestService = AddAllConfiguratorPEGARequest.class, bpmResponseService = AddAllConfiguratorPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
	Mono<AddAllConfiguratorPEGAResponse> addAllConfigurator(AddAllConfiguratorPEGARequest request) throws SOEHTTPException;

	/**
	 * 
	 * @param request
	 * @return AddDevicePEGAResponse
	 * @throws SOEHTTPException
	 */

	@BPM(bpmRequestService = AddDevicePEGARequest.class, bpmResponseService = AddDevicePEGAResponse.class, urlPostFix = "/AcctGrowth/V1/SOA", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<AddDevicePEGAResponse> addDeviceRFEX(AddDevicePEGARequest request) throws SOEHTTPException;

	/**
	 * 
	 * @param request
	 * @return AddAccessoriesPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = AddAccessoryPEGARequest.class, bpmResponseService = AddAccessoriesPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<AddAccessoriesPEGAResponse> addAccessory(AddAccessoryPEGARequest request) throws SOEHTTPException;

	/**
	 * 
	 * @param request
	 * @return AddAccessoriesPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = AddAccessoryPEGARequest.class, bpmResponseService = AddAccessoriesPEGAResponse.class, urlPostFix = "/AcctGrowth/V1/SOA", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<AddAccessoriesPEGAResponse> addAccessoryRFEX(AddAccessoryPEGARequest request) throws SOEHTTPException;

	/**
	 * 
	 * @param request
	 * @return EffectiveDateOverridePEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = EffectiveDateOverridePEGARequest.class, bpmResponseService = EffectiveDateOverridePEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<EffectiveDateOverridePEGAResponse> effectiveDateOverride(EffectiveDateOverridePEGARequest request) throws SOEHTTPException;

	/**
	 * 
	 * @param request
	 * @return RemoveLinesPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = RemoveLinesPEGARequest.class, bpmResponseService = RemoveLinesPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<RemoveLinesPEGAResponse> removeLines(RemoveLinesPEGARequest request) throws SOEHTTPException;

	/**
	 *
	 * @param request
	 * @return RemoveHomePhonePegaResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = RemoveHomePhonePegaRequest.class, bpmResponseService = RemoveHomePhonePegaResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<RemoveHomePhonePegaResponse> removeLine(RemoveHomePhonePegaRequest request) throws SOEHTTPException;

	/**
	 * 
	 * @param request
	 * @return InitiateCheckoutPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = InitiateCheckoutPEGARequest.class, bpmResponseService = InitiateCheckoutPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<InitiateCheckoutPEGAResponse> validateOrder(InitiateCheckoutPEGARequest request)
			throws SOEHTTPException;
	
	/**
	 * 
	 * @param request
	 * @return InitiateCheckoutPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = InitiateCheckoutPEGARequest.class, bpmResponseService = InitiateCheckoutPEGAResponse.class, urlPostFix = "/AcctGrowth/V1/SOA", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<InitiateCheckoutPEGAResponse> validateOrderRFEX(InitiateCheckoutPEGARequest request)
			throws SOEHTTPException;

	/**
	 * 
	 * @param request
	 * @return PastDuesPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = PastDuesPEGARequest.class, bpmResponseService = PastDuesPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<PastDuesPEGAResponse> pastDues(PastDuesPEGARequest request) throws SOEHTTPException;

	/**
	 * 
	 * @param request
	 * @return AddFeaturesPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = AddFeaturesPEGARequest.class, bpmResponseService = AddFeaturesPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<AddFeaturesPEGAResponse> addFeatures(AddFeaturesPEGARequest request) throws SOEHTTPException;

	/**
	 *
	 * @param request
	 * @return AddFeaturesPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = AddFeaturesPEGARequest.class, bpmResponseService = AddFeaturesPEGAResponse.class, urlPostFix = "/VZCMAcctGrowth/V2/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<AddFeaturesPEGAResponse> numberLinkAddFeatures(AddFeaturesPEGARequest request) throws SOEHTTPException;

	/**
	 * 
	 * @param request
	 * @return AddDownPaymentPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = AddDownPaymentPEGARequest.class, bpmResponseService = AddDownPaymentPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<AddDownPaymentPEGAResponse> addDownPayment(AddDownPaymentPEGARequest request) throws SOEHTTPException;

	/**
	 * 
	 * @param request
	 * @return UpdateEdgeupPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = UpdateEdgeupPEGARequest.class, bpmResponseService = UpdateEdgeupPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<UpdateEdgeupPEGAResponse> addEdgeUp(UpdateEdgeupPEGARequest request) throws SOEHTTPException;

	/**
	 * 
	 * @param request
	 * @return UpdateEdgeupPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = UpdateEdgeupPEGARequest.class, bpmResponseService = UpdateEdgeupPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<UpdateEdgeupPEGAResponse> removeEdgeUp(UpdateEdgeupPEGARequest request) throws SOEHTTPException;

	/**
	 * 
	 * @param request
	 * @return AddBuyoutPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = AddBuyoutPEGARequest.class, bpmResponseService = AddBuyoutPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<AddBuyoutPEGAResponse> addBuyout(AddBuyoutPEGARequest request) throws SOEHTTPException;

	/**
	 * 
	 * @param pegaRequest
	 * @return AddPlanPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = AddPlanPEGARequest.class, bpmResponseService = AddPlanPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<AddPlanPEGAResponse> addPlan(AddPlanPEGARequest pegaRequest) throws SOEHTTPException;

	/**
	 * 
	 * @param pegaRequest
	 * @return CreateLinePEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = CreateLinePEGARequest.class, bpmResponseService = CreateLinePEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<CreateLinePEGAResponse> createLine(CreateLinePEGARequest pegaRequest) throws SOEHTTPException;

	/**
	 * 
	 * @param pegaRequest
	 * @return NumberSharePEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = NumberSharePEGARequest.class, bpmResponseService = NumberSharePEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<NumberSharePEGAResponse> numberShare(NumberSharePEGARequest pegaRequest) throws SOEHTTPException;

	/**
	 *
	 * @param pegaRequest
	 * @return ServiceAddressPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = ServiceAddressPEGARequest.class, bpmResponseService = ServiceAddressPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<ServiceAddressPEGAResponse> addServiceAddress(ServiceAddressPEGARequest pegaRequest)
			throws SOEHTTPException;

	/**
	 *
	 * @param pegaRequest
	 * @return ServiceAddressPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = BillingAddressPEGARequest.class, bpmResponseService = BillingAddressPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<BillingAddressPEGAResponse> addBillingAddress(BillingAddressPEGARequest pegaRequest)
			throws SOEHTTPException;

	/**
	 *
	 * @param pegaRequest
	 * @return E911AddressPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = E911AddressPEGARequest.class, bpmResponseService = E911AddressPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<E911AddressPEGAResponse> addE911Address(E911AddressPEGARequest pegaRequest) throws SOEHTTPException;

	/**
	 *
	 * @param pegaRequest
	 * @return E911AddressPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = E911AddressPEGARequest.class, bpmResponseService = E911AddressPEGAResponse.class, urlPostFix = "/VZCMAcctGrowth/V2/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<E911AddressPEGAResponse> numberLinkAddE911Address(E911AddressPEGARequest pegaRequest) throws SOEHTTPException;

	/**
	 *
	 * @param pegaRequest
	 * @return InstantCreditDownPaymentPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = InstantCreditDownPaymentPEGARequest.class, bpmResponseService = InstantCreditDownPaymentPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<InstantCreditDownPaymentPEGAResponse> addInstantCreditDownPayment(
            InstantCreditDownPaymentPEGARequest pegaRequest) throws SOEHTTPException;

	/**
	 * 
	 * @param pegarequest
	 * @return AssignMtnPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = AssignMtnPEGARequest.class, bpmResponseService = AssignMtnPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<AssignMtnPEGAResponse> assignMtn(AssignMtnPEGARequest pegarequest) throws SOEHTTPException;

	/**
	 * 
	 * @param pegarequest
	 * @return DeassignMtnPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = DeassignMtnPEGARequest.class, bpmResponseService = DeassignMtnPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<DeassignMtnPEGAResponse> deassignMtn(DeassignMtnPEGARequest pegarequest) throws SOEHTTPException;

	/**
	 * 
	 * @param request
	 * @return SaveCartPEGAResponse
	 * @throws SOEHTTPException
	 */

	@BPM(bpmRequestService = SaveCartPEGARequest.class, bpmResponseService = SaveCartPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<SaveCartPEGAResponse> saveCart(SaveCartPEGARequest request) throws SOEHTTPException;

	/**
	 * 
	 * @param request
	 * @return SaveCartPEGAResponse
	 * @throws SOEHTTPException
	 */

	@BPM(bpmRequestService = SaveCartPEGARequest.class, bpmResponseService = SaveCartPEGAResponse.class, urlPostFix = "/AcctGrowth/V1/SOA", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<SaveCartPEGAResponse> saveCartRFEX(SaveCartPEGARequest request) throws SOEHTTPException;

	/**
	 * 
	 * @param request
	 * @return Add5GBulkOrderPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = Add5GBulkOrderPEGARequest.class, bpmResponseService = Add5GBulkOrderPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<Add5GBulkOrderPEGAResponse> add5GBulkOrder(Add5GBulkOrderPEGARequest request) throws SOEHTTPException;

	/**
	 * 
	 * @param request
	 * @return RevokeRebatesPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = RevokeRebatesPEGARequest.class, bpmResponseService = RevokeRebatesPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<RevokeRebatesPEGAResponse> revokeRebates(RevokeRebatesPEGARequest request) throws SOEHTTPException;

	/**
	 * 
	 * @param request
	 * @return PortinLaterPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = PortinLaterPEGARequest.class, bpmResponseService = PortinLaterPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<PortinLaterPEGAResponse> updatePortInLater(PortinLaterPEGARequest request) throws SOEHTTPException;

	/**
	 * 
	 * @param request
	 * @return VoidOrderPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = VoidOrderPEGARequest.class, bpmResponseService = VoidOrderPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<VoidOrderPEGAResponse> voidOrder(VoidOrderPEGARequest request) throws SOEHTTPException;

	/**
	 * 
	 * @param request
	 * @return IspuToDfillPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = IspuToDfillPEGARequest.class, bpmResponseService = IspuToDfillPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<IspuToDfillPEGAResponse> ispuToDfill(IspuToDfillPEGARequest request) throws SOEHTTPException;

	/**
	 * 
	 * @param request
	 * @return ManualPairingPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = ManualPairingPEGARequest.class, bpmResponseService = ManualPairingPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<ManualPairingPEGAResponse> manualPairing(ManualPairingPEGARequest request) throws SOEHTTPException;

	/**
	 * 
	 * @param request
	 * @return SalesRepAndLocationCodePEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = SalesRepAndLocationCodePEGARequest.class, bpmResponseService = SalesRepAndLocationCodePEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<SalesRepAndLocationCodePEGAResponse> updateSalesRepAndLocationCode(
            SalesRepAndLocationCodePEGARequest request) throws SOEHTTPException;

	/**
	 * 
	 * @param request
	 * @return SplitExceededAmountPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = SplitExceededAmountPEGARequest.class, bpmResponseService = SplitExceededAmountPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<SplitExceededAmountPEGAResponse> splitExceededAmount(SplitExceededAmountPEGARequest request)
			throws SOEHTTPException;

	/**
	 *
	 * @param request
	 * @return CancelCasePEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = CancelCasePEGARequest.class, bpmResponseService = CancelCasePEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<CancelCasePEGAResponse> cancelCase(CancelCasePEGARequest request) throws SOEHTTPException;

	/**
	 *
	 * @param request
	 * @return CancelCasePEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = DeviceIdValidationPEGARequest.class, bpmResponseService = DeviceIdValidationPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<DeviceIdValidationPEGAResponse> validateDeviceId(DeviceIdValidationPEGARequest request) throws SOEHTTPException;
	
	/**
	 * 
	 * @param request
	 * @return ActivateLaterPEGAResponse
	 * @throws SOEHTTPException
	 */

	@BPM(bpmRequestService = ActivateLaterPEGARequest.class, bpmResponseService = ActivateLaterPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<ActivateLaterPEGAResponse> activateOrSetupLater(ActivateLaterPEGARequest request) throws SOEHTTPException;

	/**
	 * 
	 * @param request
	 * @return ClearAndContinuePegaResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = ClearAndContinuePegaRequest.class, bpmResponseService = ClearAndContinuePegaResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<ClearAndContinuePegaResponse> clearAndContinue(ClearAndContinuePegaRequest request) throws SOEHTTPException;

	/**
	 *
	 * @param request
	 * @return ResumeAndContinuePegaResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = ResumeAndContinuePegaRequest.class, bpmResponseService = ResumeAndContinuePegaResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<ResumeAndContinuePegaResponse> resumeAndContinue(ResumeAndContinuePegaRequest request) throws SOEHTTPException;


	/**
	 *
	 * @param request
	 * @return UpdateDeviceSIMIdPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = UpdateDeviceSIMIdPEGARequest.class, bpmResponseService = UpdateDeviceSIMIdPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<UpdateDeviceSIMIdPEGAResponse> updateDeviceSimId(UpdateDeviceSIMIdPEGARequest request) throws SOEHTTPException;

	/**
	 * 
	 * @param request
	 * @return resp
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = UpdateTransferUpgradePEGARequest.class, bpmResponseService = UpdateTransferUpgradePEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<UpdateTransferUpgradePEGAResponse> addTransferUpgrade(UpdateTransferUpgradePEGARequest request) throws SOEHTTPException;
	
	/**
	 * 
	 * @param request
	 * @return resp
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = UpdateTransferUpgradePEGARequest.class, bpmResponseService = UpdateTransferUpgradePEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<UpdateTransferUpgradePEGAResponse> removeTransferUpgrade(UpdateTransferUpgradePEGARequest request) throws SOEHTTPException;
	
	/**
	 * 
	 * @param request
	 * @return AddNickNamePEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = AddNickNamePEGARequest.class, bpmResponseService = AddNickNamePEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<AddNickNamePEGAResponse> addNickName(AddNickNamePEGARequest request) throws SOEHTTPException;

/**
	 * 
	 * @param request
	 * @return UpdateBarCodePEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = UpdateBarCodePEGARequest.class, bpmResponseService = UpdateBarCodePEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<UpdateBarCodePEGAResponse> updateBarcode(UpdateBarCodePEGARequest request) throws SOEHTTPException;
	
	/**
	 * 
	 * @param request
	 * @return UpdateBarCodePEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = NBXFeedbackRequest.class, bpmResponseService = NBXFeedbackResponse.class, urlPostFix = "/Decisioning/NBX", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST, type=BPMType.RTD_OFFERS)
    Mono<NBXFeedbackResponse> nbxFeedbackCall(NBXFeedbackRequest request) throws SOEHTTPException;

	/**
	 *
	 * @param request
	 * @return UpdateChatIdPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = UpdateChatIdPEGARequest.class, bpmResponseService = UpdateChatIdPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<UpdateChatIdPEGAResponse> updateChatId(UpdateChatIdPEGARequest request) throws SOEHTTPException;

	/**
	 * 
	 * @param request
	 * @return GetCasePEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = GetCasePEGARequest.class, bpmResponseService = GetCasePEGAResponse.class, urlPostFix = "/AcctGrowth/V1/getCases", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<GetCasePEGAResponse> getCase(GetCasePEGARequest request) throws SOEHTTPException;

	/**
	 * 
	 * @param request
	 * @return ClearCartPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = ClearCartPEGARequest.class, bpmResponseService = ClearCartPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<ClearCartPEGAResponse> clearCart(ClearCartPEGARequest request) throws SOEHTTPException;

	/**
	 *
	 * @param request
	 * @return NGDDeleteCartPegaResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = DeleteCartPegaRequest.class, bpmResponseService = DeleteCartPegaResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
	Mono<DeleteCartPegaResponse> ngdDeleteCart(DeleteCartPegaRequest request) throws SOEHTTPException;

	/**
	 *
	 * @param request
	 * @return UpdateWFMInfoPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = UpdateWFMInfoPEGARequest.class, bpmResponseService = UpdateWFMInfoPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<UpdateWFMInfoPEGAResponse> updateWFMInfo(UpdateWFMInfoPEGARequest request) throws SOEHTTPException;

	@BPM(bpmRequestService = AccountPinPEGARequest.class, bpmResponseService = AccountPinPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<AccountPinPEGAResponse> updateAccountPin(AccountPinPEGARequest request) throws SOEHTTPException;
	
	/**
	 *
	 * @param request
	 * @return SalesOrderAdjustmentPEGARequest
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = SalesOrderAdjustmentPEGARequest.class, bpmResponseService = SalesOrderAdjustmentPEGAResponse.class, urlPostFix = "/AcctGrowth/V1/SOA", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<SalesOrderAdjustmentPEGAResponse> salesOrderAdjustment(SalesOrderAdjustmentPEGARequest request) throws SOEHTTPException;
	
	/**
	 * Bbp get process step.
	 *
	 * @param request the request
	 * @return the mono
	 * @throws SOEHTTPException the SOEHTTP exception
	 */
	@BPM(bpmRequestService = BBPGetProcessStepPEGARequest.class, bpmResponseService = BbpGetProcessStepPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<BbpGetProcessStepPEGAResponse> bbpGetProcessStep(BBPGetProcessStepPEGARequest request) throws SOEHTTPException;

	/**
	 *
	 * @param request
	 * @return RemoveLockPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = RemoveLockPEGARequest.class, bpmResponseService = RemoveLockPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<RemoveLockPEGAResponse> removeLock(RemoveLockPEGARequest request) throws SOEHTTPException;

	/**
	 *
	 * @param request
	 * @return RetrieveActivationStatusPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = RetrieveActivationStatusPEGARequest.class, bpmResponseService = RetrieveActivationStatusPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<RetrieveActivationStatusPEGAResponse> retrieveActivationStatus(
            RetrieveActivationStatusPEGARequest request) throws SOEHTTPException;

	/**
	 *
	 * @param request
	 * @return AddPlanAndDevicePEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = AddPlanAndDevicePEGARequest.class, bpmResponseService = AddPlanAndDevicePEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<AddPlanAndDevicePEGAResponse> addPlanAndDevice(AddPlanAndDevicePEGARequest request) throws SOEHTTPException;

	/**
	 *
	 * @param request
	 * @return AddPlanAndDevicePEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = AddPlanAndDevicePEGARequest.class, bpmResponseService = AddPlanAndDevicePEGAResponse.class, urlPostFix = "/VZCMAcctGrowth/V2/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
	public Mono<AddPlanAndDevicePEGAResponse> moversUpdateCart(AddPlanAndDevicePEGARequest request) throws SOEHTTPException;
	/**
	 *
	 * @param request
	 * @return AddPlanAndDevicePEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = AddMoveDatesPegaRequest.class, bpmResponseService = AddMoveDatesPegaResponse.class, urlPostFix = "/VZCMAcctGrowth/V2/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
	public Mono<AddMoveDatesPegaResponse> addMoversDate(AddMoveDatesPegaRequest request) throws SOEHTTPException;

    @BPM(bpmRequestService = MoversUpdatePlanPegaRequest.class, bpmResponseService = MoversUpdatePlanPegaResponse.class, urlPostFix = "/VZCMAcctGrowth/V2/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    public Mono<MoversUpdatePlanPegaResponse> updateCustomerMoverPlan(MoversUpdatePlanPegaRequest request) throws SOEHTTPException;
	/**
	 *
	 * @param request
	 * @return UpdateCartWithDatePegaResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = CartWithDatePegaRequest.class, bpmResponseService = CartWithDatePegaResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<CartWithDatePegaResponse> updateCartWithDate(CartWithDatePegaRequest request) throws SOEHTTPException;

	/**
	 *
	 * @param request
	 * @return AddPlanAndDevicePEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = UpdateSellerPricePEGARequest.class, bpmResponseService = UpdateSellerPricePEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<UpdateSellerPricePEGAResponse> updateSellerPrice(UpdateSellerPricePEGARequest request) throws SOEHTTPException;

	/*
	 * 
	 * @param request
	 * @return resp
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = UpdateBvoOffersPEGARequest.class, bpmResponseService = UpdateBvoOffersPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<UpdateBvoOffersPEGAResponse> removeOffer(UpdateBvoOffersPEGARequest request) throws SOEHTTPException;
	
	/*
	 * 
	 * @param request
	 * @return resp
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = ManualDiscountPEGARequest.class, bpmResponseService = ManualDiscountPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<ManualDiscountPEGAResponse> addManualdiscount(ManualDiscountPEGARequest request) throws SOEHTTPException;
	
	/*
	 * 
	 * @param request
	 * @return resp
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = EffectiveDatePEGARequest.class, bpmResponseService = EffectiveDatePEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<EffectiveDatePEGAResponse> updateEffectiveDate(EffectiveDatePEGARequest request) throws SOEHTTPException;

	/***
	 *
	 * @param request
	 * @return
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = AddPlanAndDevicePEGARequest.class, bpmResponseService = AddPlanAndDevicePEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<AddPlanAndDevicePEGAResponse> saveCartWithEmail(AddPlanAndDevicePEGARequest request) throws SOEHTTPException;

	/***
	 *
	 * @param request
	 * @return
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = AddPlanAndDevicePEGARequest.class, bpmResponseService = CrmRetrieveCartPegaResponse.class, urlPostFix = "/AcctGrowth/V1/getCases", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<CrmRetrieveCartPegaResponse> crmRetrieveCart(AddPlanAndDevicePEGARequest request) throws SOEHTTPException;

	/**
	 *
	 * @param pegaRequest
	 * @return CreateCasePEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = CreateCasePEGARequest.class, bpmResponseService = CreateCasePEGAResponse.class, urlPostFix = "/VZCMAccountMaintainace/V2/AcctMaintAndComms", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<CreateCasePEGAResponse> createCase(CreateCasePEGARequest pegaRequest) throws SOEHTTPException;

	@BPM(bpmRequestService = InitiateValidateDeviceSimPEGARequest.class, bpmResponseService = InitiateValidateDeviceSimPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<InitiateValidateDeviceSimPEGAResponse> initiateValidateDeviceSim(InitiateValidateDeviceSimPEGARequest pegaRequest) throws SOEHTTPException;

	/**
	 *
	 * @param request
	 * @return GuestChoicePEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = GuestChoicePEGARequest.class, bpmResponseService = GuestChoicePEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<GuestChoicePEGAResponse> guestChoice(GuestChoicePEGARequest request) throws SOEHTTPException;
	
	/**
	 *
	 * @param request
	 * @return GuestChoicePEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = CheckExistingCartPEGARequest.class, bpmResponseService = CheckExistingCartPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<CheckExistingCartPEGAResponse> checkExistingCart(CheckExistingCartPEGARequest request) throws SOEHTTPException;

	/**
	 *
	 * @param request
	 * @return UpdateGiftItemPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = UpdateGiftItemPEGARequest.class, bpmResponseService = UpdateGiftItemPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<UpdateGiftItemPEGAResponse> updateGiftItem(UpdateGiftItemPEGARequest request) throws SOEHTTPException;
	
	/**
	 * 
	 * @param request
	 * @return AddAccessoriesPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = AccessoryFinancingOffersPegaRequest.class, bpmResponseService = AccessoryFinancingOffersPegaResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<AccessoryFinancingOffersPegaResponse> updateAccessoryFinancingOffers(AccessoryFinancingOffersPegaRequest request) throws SOEHTTPException;

	
	@BPM(bpmRequestService = IndirectExCustRemoveLinePEGAReq.class, bpmResponseService = IndirectExCustRemoveLinePEGARes.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<IndirectExCustRemoveLinePEGARes> exCustRemoveLine(IndirectExCustRemoveLinePEGAReq request) throws SOEHTTPException;

	@BPM(bpmRequestService = TradeinAddToCartRequest.class, bpmResponseService = TradeinAddToCartResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
	Mono<TradeinAddToCartResponse> addTradeinToCart(TradeinAddToCartRequest request);

	/**
	 *
	 * @param pegaRequest
	 * @return InitiateAddressChangePEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = InitiateAddressChangePEGARequest.class, bpmResponseService = InitiateAddressChangePEGAResponse.class, urlPostFix = "/VZCMAccountMaintainace/V2/AcctMaintAndComms", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<InitiateAddressChangePEGAResponse> initiateAddressChange(InitiateAddressChangePEGARequest pegaRequest) throws SOEHTTPException;

	@BPM(bpmRequestService = AddTrialContactInfoAndAddressPEGARequest.class, bpmResponseService = AddTrialContactInfoAndAddressPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<AddTrialContactInfoAndAddressPEGAResponse> addTrialContactInfoAndAddress(AddTrialContactInfoAndAddressPEGARequest request) throws SOEHTTPException;

	/**
	 *
	 * @param pegaRequest
	 * @return InitiateAddressChangePEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = UpdateAddressChangePEGARequest.class, bpmResponseService = UpdateAddressChangePEGAResponse.class, urlPostFix = "/VZCMAccountMaintainace/V2/AcctMaintAndComms", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<UpdateAddressChangePEGAResponse> updateAddressChange(UpdateAddressChangePEGARequest pegaRequest) throws SOEHTTPException;

    /**
     *
     * @param request
     * @return AddPlanAndDevicePEGAResponse
     * @throws SOEHTTPException
     */
    @BPM(bpmRequestService = AddPlanAndDevicePEGARequest.class, bpmResponseService = AddPlanAndDevicePEGAResponse.class, urlPostFix = "/CPC/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<AddPlanAndDevicePEGAResponse> cpcUpdateCart(AddPlanAndDevicePEGARequest request) throws SOEHTTPException;

	/**
	 *
	 * @param request
	 * @return AddPlanAndDevicePEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = AddPlanAndDevicePEGARequest.class, bpmResponseService = AddPlanAndDevicePEGAResponse.class, urlPostFix = "/CPC/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<AddPlanAndDevicePEGAResponse> cpcSubmitPlan(AddPlanAndDevicePEGARequest request) throws SOEHTTPException;

	/**
	 *
	 * @param request
	 * @return BpmResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = CpcFeatureRequest.class, bpmResponseService = CpcFeatureResponse.class, urlPostFix = "/CPC/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
	Mono<CpcFeatureResponse> cpcCreateCart(CpcFeatureRequest request) throws SOEHTTPException;



	/**
	 *
	 * @param request
	 * @return BpmResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = AddFeaturesPEGARequest.class, bpmResponseService = AddFeaturesPEGAResponse.class, urlPostFix = "/CPC/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
	Mono<AddFeaturesPEGAResponse> cpcAddFeature(AddFeaturesPEGARequest request) throws SOEHTTPException;

	
	/**
	 * 
	 * @param request
	 * @return
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = AffirmFinancingPegaRequest.class, bpmResponseService = AffirmFinancingPegaResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<AffirmFinancingPegaResponse> updateAffirmStatus(AffirmFinancingPegaRequest request) throws SOEHTTPException;
	
	
	@BPM(bpmRequestService = AddReplenishmentToCartPEGARequest.class, bpmResponseService = AddReplenishmentToCartPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<AddReplenishmentToCartPEGAResponse> addReplenishmenttoCart(AddReplenishmentToCartPEGARequest pegarequest) throws SOEHTTPException;

	//AutoPay
	@BPM(bpmRequestService = AutoPayPegaRequest.class, bpmResponseService = AutoPayPegaResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<AutoPayPegaResponse> autoPayFlow(AutoPayPegaRequest pegarequest) throws SOEHTTPException;
	
	/**
	 * 
	 * @param request
	 * @return
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = ReviewOrderPegaRequest.class, bpmResponseService = ReviewOrderPegaResponse.class, urlPostFix = "/VZCMAccountMaintainace/V2/AcctMaintAndComms", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<ReviewOrderPegaResponse> reviewOrderTYS(ReviewOrderPegaRequest request)
			throws SOEHTTPException;
	
	/**
	 * 
	 * @param request
	 * @return
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = AddFeaturesPEGARequest.class, bpmResponseService = AddFeaturesPEGAResponse.class, urlPostFix = "/VZCMAccountMaintainace/V2/AcctMaintAndComms", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<AddFeaturesPEGAResponse> addFeaturesTYS(AddFeaturesPEGARequest request) throws SOEHTTPException;

	/**
	 * 
	 * @param pegaRequest
	 * @return
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = AddPlanPEGARequest.class, bpmResponseService = AddPlanPEGAResponse.class, urlPostFix = "/VZCMAccountMaintainace/V2/AcctMaintAndComms", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<AddPlanPEGAResponse> addPlanTYS(AddPlanPEGARequest pegaRequest) throws SOEHTTPException;

	@BPM(bpmRequestService = AddTruckRollCartRequest.class, bpmResponseService = AddTruckRollCartBPMResponse.class, urlPostFix = "/VZCMAcctGrowth/V2/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
    Mono<AddTruckRollCartBPMResponse> addTruckRollCart(AddTruckRollCartRequest request) throws SOEHTTPException;

	@BPM(bpmRequestService = AddTruckRollCartRequest.class, bpmResponseService = AddTruckRollCartBPMResponse.class, urlPostFix = "/VZCMAcctGrowth/V2/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
	Mono<AddTruckRollCartBPMResponse> updateTruckRollCart(AddTruckRollCartRequest bpmrequest) throws SOEHTTPException;

    @BPM(bpmRequestService = AddZipcodePEGARequest.class, bpmResponseService = AddZipcodePEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
	Mono<AddZipcodePEGAResponse> addZipcodePEGA(AddZipcodePEGARequest request) throws SOEHTTPException;

	@BPM(bpmRequestService = CreateCartAndLinePEGARequest.class, bpmResponseService = CreateCartAndLinePEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
	Mono<CreateCartAndLinePEGAResponse> createCartAndLine(CreateCartAndLinePEGARequest request) throws SOEHTTPException;
	
	 @BPM(bpmRequestService = CommonCartPEGARequest.class, bpmResponseService = CommonCartPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
	 Mono<CommonCartPEGAResponse> buildLine(CommonCartPEGARequest request) throws SOEHTTPException;
	 
	 @BPM(bpmRequestService = CommonCartPEGARequest.class, bpmResponseService = CommonCartPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
	 Mono<CommonCartPEGAResponse> deleteCart(CommonCartPEGARequest request) throws SOEHTTPException;

	 @BPM(bpmRequestService = ResumeCaseBPMRequest.class, bpmResponseService = ResumeCaseBPMResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
	 Mono<ResumeCaseBPMResponse> resumeCase(ResumeCaseBPMRequest request) throws SOEHTTPException;

	@BPM(bpmRequestService = CreateCaseNewCustomerPEGARequest.class, bpmResponseService = CreateCaseNewCustomerPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
	Mono<CreateCaseNewCustomerPEGAResponse> createCasePlanBuilder(CreateCaseNewCustomerPEGARequest pegaRequest) throws SOEHTTPException;

	@BPM(bpmRequestService = CreateBulkQuotePegaRequest.class, bpmResponseService = CreateBulkQuotePegaResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
	Mono<CreateBulkQuotePegaResponse> createBulkQuote(CreateBulkQuotePegaRequest pegaRequest) throws SOEHTTPException;

	@BPM(bpmRequestService = UpdateAccountOwnerPEGARequest.class, bpmResponseService = UpdateAccountOwnerPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
	Mono<UpdateAccountOwnerPEGAResponse> updateAccountOwner(UpdateAccountOwnerPEGARequest request) throws SOEHTTPException;

	/**
	 *
	 * @param request
	 * @return AddPayOffDetailsPEGAResponse
	 * @throws SOEHTTPException
	 */
	@BPM(bpmRequestService = AddPayOffDetailsPEGARequest.class, bpmResponseService = AddPayOffDetailsPEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
	Mono<AddPayOffDetailsPEGAResponse> addPayOffDetails(AddPayOffDetailsPEGARequest request) throws SOEHTTPException;

	@BPM(bpmRequestService = AddDevicePEGARequest.class, bpmResponseService = AddDevicePEGAResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
	Mono<AddDevicePEGAResponse> dfoToDppCartPegaService(AddDevicePEGARequest request) throws SOEHTTPException;

	@BPM(bpmRequestService = FWACreateCartRequest.class, bpmResponseService = FWACreateCartResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
	Mono<FWACreateCartResponse> createCart(FWACreateCartRequest pegaRequest);

	@BPM(bpmRequestService = FWAUpdateCartRequest.class, bpmResponseService = FWAUpdateCartResponse.class, urlPostFix = "/Upgrade/V1/AcctGrowth", messageLog = MessageLog.REQUEST_AND_RESPONSE, method = HttpMethod.POST)
	Mono<FWAUpdateCartResponse> updateCart(FWAUpdateCartRequest pegaRequest);

}
