package onevz.soe.cart.helper;

import static onevz.soe.cart.constants.CartConstants.AAL;
import static onevz.soe.cart.constants.CartConstants.AAL_5G;
import static onevz.soe.cart.constants.CartConstants.TECH_CBD_INTENT;
import static onevz.soe.cart.util.CommonUtil.populateDueTodayItems;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;


import onevz.soe.cart.gql.CurrentProfileSPO;

import onevz.cxp.feature.util.FeatureFlag;
import onevz.soe.cart.constants.FeatureFlagConstants;

import onevz.soe.cart.gql.schema.CartItem;
import onevz.soe.cart.gql.schema.LineInfo;
import onevz.soe.cart.gql.schema.LineLevelOffers;
import onevz.soe.cart.model.retrieveCart.fiveG.AMRegisterationDetails;
import onevz.soe.cart.model.retrieveCart.fiveG.CXPDueItemsList;
import onevz.soe.cart.model.retrieveCart.fiveG.CXPOrderDetailsView;
import onevz.soe.cart.model.retrieveCart.fiveG.EUPDetails;
import onevz.soe.cart.model.retrieveCart.fiveG.Promotions;
import onevz.soe.orderprocess.model.checkoutdetails.DiscountsAndPromotions;

import com.datastax.oss.driver.shaded.guava.common.util.concurrent.AtomicDouble;
import onevz.soe.cart.gql.requests.CustomerByIdBillAccounts;
import onevz.soe.cart.gql.requests.CustomerByIdGQLRequest;
import onevz.soe.cart.gql.requests.CustomerByIdMtnsGQLRequest;
import onevz.soe.cart.gql.response.CustomerByIdGQLResponse;
import onevz.soe.cart.gql.schema.CustomerProfile;
import onevz.soe.cart.model.retrieveCart.*;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.util.*;
import onevz.soe.session.bean.SOELoginSessionBean;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.commons.text.WordUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.fasterxml.jackson.core.JsonProcessingException;

import onevz.soe.cart.bpm.helper.CartServiceBpmHelper;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper3;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.controller.advice.CartServiceExceptionHandler;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.gql.schema.newCustomer.CustomerProfileForNSE;
import onevz.soe.cart.model.addDevice.AddPlanDeviceCartInfo;
import onevz.soe.cart.model.addTruckRoll.AddTruckRollCartResponseContext;
import onevz.soe.cart.model.common.FiveG.Device;
import onevz.soe.cart.model.common.FiveG.FiveGLTEAddressRedis;
import onevz.soe.cart.model.common.FiveG.Line;
import onevz.soe.cart.model.orderConfirmation.CXPOrderConfirmation5GDataVO;
import onevz.soe.cart.model.reviewOrderInsipico.InspicioTermsAndConditions;
import onevz.soe.cart.requests.CheckoutDetailsRequest;
import onevz.soe.cart.requests.GetCartDetailsRequest;
import onevz.soe.cart.requests.GetOrderDetailsGQLRequest;
import onevz.soe.cart.ui.common.CartInfo;
import onevz.soe.cart.ui.common.DeviceCartInfo;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.AddPlanAndDeviceUIRequest;
import onevz.soe.cart.ui.requests.AddTruckRollCartUIRequest;
import onevz.soe.cart.ui.requests.FWAUpdateCouponUIRequest;
import onevz.soe.cart.ui.requests.SaveCartWithEmailUIRequest;
import onevz.soe.cart.ui.requests.TechCBandData;
import onevz.soe.cart.ui.responses.AddPlanAndDeviceUIResponse;
import onevz.soe.cart.ui.responses.CrmRetrieveCartUIResponse;
import onevz.soe.cart.ui.responses.OrderConfirmationUIResponse;
import onevz.soe.cradle.CradleAllocator;
import onevz.soe.security.util.RPSAES128CBCUtil;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import onevz.spring.config.CartServiceConfig;
import reactor.core.publisher.Mono;


@Service
public class FiveGhomeCommonHelper {

	@Autowired
	CartServiceCxpHelper cxpHelper;
	@Autowired
	CommonUtil commonUtil;

	@Autowired
	SOELoginSessionBean sessionBean;

	@Autowired
	private RedisHelper redisHelper;
	@Autowired
	private RedisHelper3 redisHelper3;
	@Value("${maxDevicesAllowedPromoHub}")
	private Integer maxDevicesAllowedPromoHub;
	@Autowired
	private CartServiceBpmHelper bpmHelper;

	@Autowired
	private CartServiceBpmHelper3 bpmHelper3;
	@Autowired
	private RedisHelper2 redisHelper2;

	@Autowired
	private CartServiceExceptionHandler exHandler;
	@Autowired
	CradleAllocator cradleAllocator;
	@Autowired
	CartServiceConfig cartServiceConfig;
    @Autowired
    FeatureFlag featureFlag;
    
    @Autowired
    FeatureFlagHelper featureFlagHelper;
	@Value("${soe.5g.promoKey.wireless:wireless-offer}")
	private String wirelessPromoKey;
	@Value("${soe.5g.promoKey.disney:discovery--promotion}")
	private String disneyPromoKey;
	@Value("${soe.5g.promoKey.autoPay:auto-pay-and-paper-free-billing}")
	private String autoPayPromoKey;
	@Value("${soe.5g.spoId.disney:1640}")
	private String disneySPOId;
	@Value("${soe.5g.spoId.whwbasic:3239}")
	private String whwSPOId;
	@Value("${soe.5g.spoId.whwplus:3240}")
	private String whwplusSPOId;
	@Value("#{'${soe.5g.visible.spoCategoryCodes}'.split(',')}")
	private List<String> visiblePrepaySPOCategoryCodes;
	@Value("${soe.digital.fwaFlowNameIdentifiers:_5G,_LTE}")
	private List<String> fwaFlowNameIdentifiers;
	@Autowired
	private RPSAES128CBCUtil security5GUtil;
	@Value("${soe.digital.fwaSPOCategoryCodes:FWADISCNT}")
	private List<String> fwaSPOCategoryCodes;
	@Value("${soe.digital.fwaSPOCouponCategories:VISBLPREPD,REMKG}")
	private List<String> fwaSPOCouponCategories;
	@Value("${soe.digital.fwaAccountSPOCategories:DAW01}")
	private List<String> fwaAccountSPOCategories;
	private static final Logger logger = LoggerFactory.getLogger(FiveGhomeCommonHelper.class);
	@Value("${soe.5g.switch.cartRedesignKillSwitch:false}")
	private boolean cartRedesignKillSwitch;

	@Value("${soe.digital.fwa.barcodeId}")
	private String fwaSweetnerCouponCode;

	@Value("${soe.digital.fwa.enableShippingAddressUpdate:false}")
	private boolean enableShippingAddressUpdate;
	@Value("${accessoriesQuantity:0}")
	private int quantity;

	@Value("${fwaSkipValidationProcessActions:updateinstalltype,complete,gotoagreements,gotoshippingoptions,gotoinstalltype,gotopayment,gotoappointment}")
	private List<String> fwaSkipValidationProcessActions;

	/**
	 *
	 * @param techRedisData
	 * @return
	 */
	public Mono<Object> createTechnicianCBandCart(TechFlowRedisData techRedisData) {
		logger.debug("Entering into Method createTechnicianCBandCart in FiveGHomeController...");
		if(StringUtils.isAnyBlank(techRedisData.getMtn(),techRedisData.getCBandSku())) {
			//Handle Error and send back
			logger.error("NO Eligible CBand Info Avaialble IN Redis...!! ");
		}
		/*request.s*/
		return Mono.empty();
	}

	/**
	 *
	 * @param couponRequest
	 * @return AddPlanAndDeviceUIResponse
	 */
	public Mono<AddPlanAndDeviceUIResponse> validateAndUpdateCouponToCart(FWAUpdateCouponUIRequest couponRequest) {
		return redisHelper.getDataFromRedis().flatMap(redisData -> {
			if(StringUtils.isBlank(redisData.getCartId()) || StringUtils.isBlank(redisData.getCaseId())) {
				AddPlanAndDeviceUIResponse errorResponse = new AddPlanAndDeviceUIResponse();
				errorResponse.setErrors(CartPegaRequestErrorsUtil.validateCartIdAndCaseId5G(couponRequest.getCartInfo()));
				return Mono.just(errorResponse);
			}
			if (StringUtilities.isNotEmptyOrNull(redisData.getAccountNumber()))
				couponRequest.getCartInfo().setAccountNumber(redisData.getAccountNumber());
			couponRequest.getCartInfo().setProcessingMTN(redisData.getProcessingMTN());
			couponRequest.getCartInfo().setSessionId(redisData.getSessionId());
			couponRequest.getCartInfo().setCartId(redisData.getCartId());
			couponRequest.getCartInfo().setCaseId(redisData.getCaseId());
			couponRequest.getCartInfo().setCartCreator(redisData.getCartCreator());
			return bpmHelper.validateAndApplyFWACouponCode(couponRequest);

		});
	}

	/**
	 * addPlan And Device
	 * @param request
	 * @return
	 */
	public Mono<AddPlanAndDeviceUIResponse> addPlanAndDevice(AddPlanAndDeviceUIRequest request) {
		Mono<CartRedisData> rr = redisHelper.getDataFromRedis();
		Mono<FiveGLTEAddressRedis> fiveGAddress = redisHelper3.getFiveGAddressFromRedisFromFiveGFlow();
		Mono<FiveGLTEAddressRedis> bulQualAddress = redisHelper3.getBulkQualificationAddressFromRedis(request);
		Mono<TechFlowRedisData> tCData = redisHelper3.fetchTechnicianDataFromRedis();
		return tCData.flatMap(tcRedisData -> {
			return rr.flatMap(data -> {
				if(data.getMarket() != null && data.getPreOrderInServiceDate() != null){
					request.setMarket(data.getMarket());
					request.setPreOrderInServiceDate(data.getPreOrderInServiceDate());
					request.setTransactionType(CartConstants.TRANSACTION_TYPE_PREORDER);
				}
				String sessionId= data.getSessionId();/*MVP2*/
				if(TECH_CBD_INTENT.equalsIgnoreCase(data.getIntendType())){
					request.getCartInfo().setIntendType(AAL_5G);
					request.getCartInfo().setTransactionType(CartConstants.CBAND_TECHNICIAN);
					TechCBandData techData = new TechCBandData();
					techData.setFiveGPlan(data.getPlanSize());// read plansize form redis and set that plan size in fiveGplan
					techData.setOrderNum(tcRedisData.getVpmOrderNum());
					techData.setLocationCode(tcRedisData.getVpmLocationCode());
					techData.setSalesRepId(tcRedisData.getRepId());
					techData.setOutletId(tcRedisData.getOutletId());
					request.setCBandData(techData);
				}
				request.getCartInfo().setSessionId(sessionId);
				if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
					request.getCartInfo().setAccountNumber(data.getAccountNumber());
				if (StringUtilities.isNotEmptyOrNull(data.getVzwRoles())) {
					request.getCartInfo().setAmRole(data.getVzwRoles());
				}

				if (CartConstants.ORDER_NOW.equalsIgnoreCase(request.getCartInfo().getProcessStep()) && CartConstants.DEVICE_AND_PLAN.equalsIgnoreCase(request.getCartInfo().getProcessAction()))
					request.getCartInfo().setProcessingMTN("newLine1");
				// for homePhone
				if(CartConstants.HELPER_ACCESSORIES.equalsIgnoreCase(request.getCartInfo().getProcessStep()) && CartConstants.DEVICE_AND_PLAN.equalsIgnoreCase(request.getCartInfo().getProcessAction())) {
					request.getCartInfo().setProcessingMTN("newLine2");
				}

				String intendType = request.getCartInfo().getIntendType();

				if(StringUtilities.isEmptyOrNull(request.getCartInfo().getCartCreator())
						&& StringUtilities.isNotEmptyOrNull(data.getMtn())
						&& !CartConstants.NSE.equalsIgnoreCase(intendType)
						&& !CartConstants.NSE_5G.equalsIgnoreCase(intendType))
					request.getCartInfo().setCartCreator(data.getMtn());
				if(StringUtilities.isEmptyOrNull(request.getCartInfo().getCartCreator())
						&& StringUtilities.isEmptyOrNull(data.getCartCreator())
						&& CartConstants.NSE_5G.equalsIgnoreCase(request.getCartInfo().getIntendType()))
					request.getCartInfo().setCartCreator(data.getSessionId());
				//set only for cBand_Technician flow
				if("cBand_Technician".equalsIgnoreCase(request.getCartInfo().getTransactionType()))
					request.setMtn(data.getMtn());

				if("cBand_Technician".equalsIgnoreCase(request.getCartInfo().getTransactionType()) && StringUtilities.isNotEmptyOrNull(tcRedisData.getCBandAuthMTN())) {
					request.getCartInfo().setCartCreator(tcRedisData.getCBandAuthMTN());
				}

				if(request.getCartInfo() != null && request.getCartInfo().getFlowType() != null &&
						!( CartConstants.FLOW_TYPE_WHW.equalsIgnoreCase(request.getCartInfo().getFlowType())) &&
						StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessStep())
						|| StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessAction()) ) {
					AddPlanAndDeviceUIResponse errorResponse = new AddPlanAndDeviceUIResponse();
					errorResponse.setErrors(CartPegaRequestErrorsUtil.validateProcessStepProcessAction5G(request.getCartInfo()));
					return Mono.just(errorResponse);
				}
				if(!CartConstants.ORDER_NOW.equalsIgnoreCase(request.getCartInfo().getProcessStep())) {
					request.getCartInfo().setCartId(data.getCartId());
					request.getCartInfo().setCaseId(data.getCaseId());
				}
				if(!CartConstants.ORDER_NOW.equalsIgnoreCase(request.getCartInfo().getProcessStep())
						&& (StringUtilities.isEmptyOrNull(request.getCartInfo().getCaseId())
						|| StringUtilities.isEmptyOrNull(request.getCartInfo().getCartId()))) {
					if(!CartConstants.FLOW_TYPE_WHW.equalsIgnoreCase(request.getCartInfo().getFlowType())){
					AddPlanAndDeviceUIResponse errorResponse = new AddPlanAndDeviceUIResponse();
					errorResponse.setErrors(CartPegaRequestErrorsUtil.validateCartIdAndCaseId5G(request.getCartInfo()));
					return Mono.just(errorResponse);}
				} else if (CartConstants.ORDER_NOW.equalsIgnoreCase(request.getCartInfo().getProcessStep())) {
					request.getCartInfo().setCartId("");
					request.getCartInfo().setCaseId("");
					request.getCartInfo().setUpdateShippingAddress(enableShippingAddressUpdate);
				}
				if(CartConstants.ORDER_NOW.equalsIgnoreCase(request.getCartInfo().getProcessStep()) && ("Resume".equalsIgnoreCase(request.getCartInfo().getAction()) ||/*MVP2*/
						"Restart".equalsIgnoreCase(request.getCartInfo().getAction()) ||/*MVP2*/ CartConstants.INTENT_EUP_LTE.equalsIgnoreCase(request.getCartInfo().getIntendType()))){
					request.getCartInfo().setCartId(data.getCartId());
					request.getCartInfo().setCaseId(data.getCaseId());
				}

				//Joint transaction flow to set Mobility CartId and CaseId and upsert jointCombo flag
				if (null != request && request.getCartInfo() != null && CartConstants.ORDER_NOW.equalsIgnoreCase(request.getCartInfo().getProcessStep())
						&& CartConstants.DEVICE_AND_PLAN.equalsIgnoreCase(request.getCartInfo().getProcessAction())
						&& CartConstants.YES.equalsIgnoreCase(request.getCartInfo().getJointCombo())) {
					request.getCartInfo().setCartId(data.getJointTransactionMobileCartId());
					request.getCartInfo().setCaseId(data.getJointTransactionMobileCaseId());
					request.getCartInfo().setFlowType(CartConstants.JOINT_COMBO);
				}

				if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getPriceType())) {
					request.getCartInfo().setCartId(data.getCartId());
					request.getCartInfo().setCaseId(data.getCaseId());
				}
				if(StringUtilities.isEmptyOrNull(request.getCartInfo().getCartCreator())
						|| StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessingMTN()) && !("Complete").equalsIgnoreCase(request.getCartInfo().getProcessAction()) ) {
					AddPlanAndDeviceUIResponse errorResponse = new AddPlanAndDeviceUIResponse();
					errorResponse.setErrors(CartPegaRequestErrorsUtil.validateProcessMtnCartCreator5G(request.getCartInfo()));
					return Mono.just(errorResponse);
				}
					return Mono.zip(fiveGAddress, bulQualAddress).flatMap(tuple -> {
						FiveGLTEAddressRedis address = tuple.getT1();
						FiveGLTEAddressRedis bulkQualAddress = tuple.getT2();
						if(bulkQualAddress != null && bulkQualAddress.getAddressLine1() != null){
							logger.info("Assigning the bulk qualification address to fiveg address for updateCart");
							address = bulkQualAddress;
						}
						if (address.getAddressLine1() == null && null != request.getCartInfo() && request.getCartInfo().getLqInfo()!=null && request.getCartInfo().getLqInfo().getAddressLine1()!=null)
						{
							try{
								commonUtil.populatingUIrequestToRedisAddress(request,address);
								Map<String, String> sessionData = new HashMap<>();
								commonUtil.populatingUIRequestToSessionData(request,sessionData);
								CartAddDeviceUtil.populateFiveGAddressFiveGHomeFlow(request, address, data);
							}
							catch (Exception e)
							{
								logger.info("Error occurred while populating FiveGaddress" + e);
							}
						}
						if (CollectionUtilities.isNotEmptyOrNull(address.getErrors())
								&& null != request.getCartInfo()
								&& StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
								&& ("AAL_5G".equalsIgnoreCase(request.getCartInfo().getIntendType())
								|| "NSE_5G".equalsIgnoreCase(request.getCartInfo().getIntendType())
								|| "AAL_LTE".equalsIgnoreCase(request.getCartInfo().getIntendType() )
								|| "NSE_LTE".equalsIgnoreCase(request.getCartInfo().getIntendType()))
								&& !(CartConstants.HELPER_ACCESSORIES.equalsIgnoreCase(request.getCartInfo().getProcessStep()) && CartConstants.DEVICE_AND_PLAN.equalsIgnoreCase(request.getCartInfo().getProcessAction()))
								&& !fwaSkipValidationProcessActions.contains(request.getCartInfo().getProcessAction().toLowerCase())

								&& ! "Resume".equalsIgnoreCase(request.getCartInfo().getAction())
								&& request.getCartInfo().getLqInfo()==null
						) {
							AddPlanAndDeviceUIResponse errorResponse = new AddPlanAndDeviceUIResponse();
							errorResponse.setErrors(address.getErrors());
							return Mono.just(errorResponse);

						}
						if(StringUtilities.isNotEmptyOrNull(address.getCrmResumeCartFlow()))
							request.getCartInfo().setCrmResumeCartFlow(address.getCrmResumeCartFlow());

						if(StringUtilities.isNotEmptyOrNull(address.getNetworkBandwidthType())) {
							request.getCartInfo().setNetworkBandwidthType(address.getNetworkBandwidthType());
						}
						if(StringUtilities.isNotEmptyOrNull(address.getAqCaseId())){
							request.getCartInfo().setAqCaseId(address.getAqCaseId());
						}
						if ((request.getCartInfo().getLqInfo()==null) &&
								(null != address.getAddressLine1() || CartConstants.INTENT_EUP_LTE.equalsIgnoreCase(request.getCartInfo().getIntendType())))
						{
							CartAddDeviceUtil.populateFiveGAddressFiveGHomeFlow(request, address, data);
						}
						if(StringUtilities.isNotEmptyOrNull(address.getIsD2DFlow()) && Boolean.valueOf(address.getIsD2DFlow())) {
							request.getCartInfo().setD2dFlag("Y");
							request.getCartInfo().setSalesRepId(address.getD2dPosAgentID());
						} else {
							request.getCartInfo().setD2dFlag("N");
						}
						//for MUC offer
						if(!intendType.contains(AAL) && StringUtilities.isNotEmptyOrNull(address.getFiveGMUCEligible()) && Boolean.valueOf(address.getFiveGMUCEligible()) && StringUtilities.isEmptyOrNull(request.getCartInfo().getFiveGMUCEligible()))
							request.getCartInfo().setFiveGMUCEligible(address.getFiveGMUCEligible());
						if(intendType.contains(AAL))
							request.getCartInfo().setFiveGMUCEligible("");
						if(StringUtilities.isNotEmptyOrNull(address.getCartCreatorOrderLocationCode())) {
							request.getCartInfo().setCartCreatorOrderLocationCode(address.getCartCreatorOrderLocationCode().toUpperCase());
						}
						if(StringUtilities.isNotEmptyOrNull(address.getOutletId()) && StringUtilities.isNotEmptyOrNull(address.getVendorId())) {
							request.getCartInfo().setOutletId(address.getOutletId());
							request.getCartInfo().setReferralVendorId(address.getVendorId());
							request.getCartInfo().setFlowType("5G_DIGITAL_PARTNERS");
						}
						// sequential combo flow
						if (null != request && request.getCartInfo() != null && request.getCartInfo().getIsSequentialComboOrder() != null && request.getCartInfo().getIsSequentialComboOrder()) {
						   request.getCartInfo().setFlowType("FWA_DIGITAL_SEQUENTIAL_COMBO");
						   request.getCartInfo().setCartId("");
						   request.getCartInfo().setMobilityCartId(data.getMobilityCartId());
						   request.getCartInfo().setMobilityOrderNo(data.getMobilityOrderNo());
						   request.getCartInfo().setMobilityLocationCode(data.getMobilityLocationCode());
						   request.getCartInfo().setMobilityCreditApplicationNum(data.getMobilityCreditApplicationNum());
						   Map<String, String> sessionData = new HashMap<>();
						   sessionData.put(CartConstants.COMBO_ORDER_FLAG,"true");
						   redisHelper2.upsertDataInRedis(sessionData);
						}



						/*MVP2-NSE*/
						if(!(StringUtilities.isNotEmptyOrNull(address.getOutletId()) && StringUtilities.isNotEmptyOrNull(address.getVendorId())) && (CartConstants.NSE_5G.equalsIgnoreCase(intendType) || CartConstants.NSE_LTE.equalsIgnoreCase(intendType))){
							request.getCartInfo().setZipCode(address.getZipCode());
						}
						if(null != data && StringUtilities.isNotEmptyOrNull(data.getCartId())) {
						} else if (null != request && null != request.getCartInfo()
								&& StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCartId())) {
						}
							Mono<Boolean> redisUpdate = populateCustomerDetailsToSession(data);
						Mono<AddPlanAndDeviceUIResponse> UIResponse = bpmHelper
								.addPlanAndDevice(request);
						return Mono.zip(redisUpdate, UIResponse).flatMap(zippedResponse -> {
								AddPlanAndDeviceUIResponse response = zippedResponse.getT2();
								if (response.getErrors() == null
										&& null != response  && response.getServiceBody() != null
										&& response.getServiceBody().getServiceResponse() != null
										&& response.getServiceBody().getServiceResponse().getContext() != null
										&& response.getServiceBody().getServiceResponse().getContext().getCartInfo() != null
										&& response.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartId() != null
								){
									request.getCartInfo().setCartId(response.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartId());
								}
							return Mono.just(response);
						});
					});
			});
		});
	}

	/**
	 * Call customer Graphql to pull customerId Hash & MDN Hash from customer
	 * @param data
	 * @return
	 */
	private Mono<Boolean> populateCustomerDetailsToSession(CartRedisData data) {
		if(data.getAccountNumber()!=null && data.getFwaCustomerIdHash()==null && data.getFwaCustomerMdnHash()==null) {
			return cxpHelper.getCustomerProfileAddress(data.getAccountNumber()).flatMap(custCxpResponse -> {
				Optional<CustomerByIdGQLRequest> customerByIdGQLRequest = Optional.of(custCxpResponse).map(CustomerProfileByIdCXPResponse::getData).map(CustomerByIdGQLResponse::getCustomer);
				if (customerByIdGQLRequest.isPresent()) {
					Map<String, String> sessionData = new HashMap<>();
					CustomerByIdGQLRequest custProfile = customerByIdGQLRequest.get();
					if (StringUtilities.isNotEmptyOrNull(custProfile.getCustomerHash())) {
						sessionData.put("fwaCustomerMdnHash", custProfile.getCustomerHash());
					}
					sessionData.put("fwaAccountType", "Postpaid");
					if (custProfile.getBillAccounts() != null && !custProfile.getBillAccounts().isEmpty()) {
						for (CustomerByIdBillAccounts billAccount : custProfile.getBillAccounts()) {
							if (billAccount != null && billAccount.getMtns() != null) {
								for (CustomerByIdMtnsGQLRequest mtn : billAccount.getMtns()) {
									if (mtn.getMtn() != null && mtn.getMtn().equalsIgnoreCase(data.getMtn())) {
										sessionData.put("fwaCustomerIdHash", mtn.getMtnHashCode());
									}
								}
							}
						}
					}
					redisHelper2.upsertDataInRedis(sessionData);
				}
				return Mono.just(Boolean.TRUE);
			});
		}else if(data.getMtn()==null && data.getFwaAccountType() == null){
			Map<String, String> sessionData = new HashMap<String, String>();
			sessionData.put("fwaAccountType", "Unauthenticated/new customer");
			redisHelper2.upsertDataInRedis(sessionData);
		}
		return Mono.just(Boolean.FALSE);
	}

	/**
	 * transform 5G Cart Data to BAU
	 * @param cartInfo
	 * @return
	 */

	public DeviceCartInfo transform5GCartDatatoBAU(AddPlanDeviceCartInfo cartInfo) {
		DeviceCartInfo deviceCartInfo = new DeviceCartInfo();
		deviceCartInfo.setAccountNumber(cartInfo.getAccountNumber());
		deviceCartInfo.setAccountType(cartInfo.getAccountType());
		deviceCartInfo.setAmRole(cartInfo.getAmRole());
		deviceCartInfo.setCartCreator(cartInfo.getCartCreator());
		deviceCartInfo.setCartId(cartInfo.getCartId());
		deviceCartInfo.setCaseId(cartInfo.getCaseId());
		deviceCartInfo.setDeviceType(cartInfo.getDeviceType());
		deviceCartInfo.setIntendType(cartInfo.getIntendType());
		deviceCartInfo.setProcessAction(cartInfo.getProcessAction());
		deviceCartInfo.setProcessStep(cartInfo.getProcessStep());
		deviceCartInfo.setProcessingMTN(cartInfo.getProcessingMTN());

		return deviceCartInfo;
	}

	/**
	 *
	 * @param lines
	 * @return lines
	 */
	public List<Lines> transform5GLinesDatatoBAU(List<Line> lines) {
		List<Lines> bauLines = new ArrayList<>();
		Lines lineDetails = null;
		for(Line line: lines) {
			lineDetails = new Lines();
			lineDetails.setMtn(line.getMtn());
			lineDetails.setIspuFlow(line.getIspuFlow());
			lineDetails.setRestrictedProductType(line.getRestrictedProductType());
			lineDetails.setRestricted(line.getRestricted());
			lineDetails.setDepletionLocationCode(line.getDepletionLocationCode());
			Device device = line.getDevice();
			onevz.soe.cart.model.common.Device deviceDetails = new onevz.soe.cart.model.common.Device();
			if(null != device && StringUtils.isNotBlank(device.getDppMonths())) {
				deviceDetails.setDppMonths(Integer.valueOf(device.getDppMonths()));
			}
			if (null != device) {
				deviceDetails.setContractTerm(device.getContractTerm());
				deviceDetails.setId(device.getId());
				deviceDetails.setQty(device.getQty());
			}
			lineDetails.setDevice(deviceDetails);
			lineDetails.setSelectedPromoType(line.getSelectedPromoType());
			lineDetails.setDepletionType(line.getDepletionType());
			lineDetails.setBillingAddress(line.getBillingAddress());
			lineDetails.setFiveG(line.getFiveG());
			lineDetails.setSim(line.getSim());
			lineDetails.setE911Address(line.getE911Address());
			bauLines.add(lineDetails);
		}

		return bauLines;
	}

	/*MVP2*/

	/***
	 *
	 * @param request
	 * @return
	 */
	public Mono<AddPlanAndDeviceUIResponse> saveCartWithEmail(SaveCartWithEmailUIRequest request){
	    if(null == request.getCartInfo()) {
            request.setCartInfo(new CartInfo());
        }
		request.getCartInfo().setIntendType(request.getIntendType());
		return redisHelper.getDataFromRedis().flatMap(data -> {

			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				request.getCartInfo().setCartId(data.getCartId());
			else if (StringUtilities.isEmptyOrNull(request.getCartInfo().getCartId())) {
				return Mono.just(new AddPlanAndDeviceUIResponse()); /*error say cart id is missing*/
			}
			/*set teh email id*, *set customer type as N in pegarequtil*/
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				request.getCartInfo().setCaseId(data.getCaseId());

			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessingMTN()))
				request.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			request.getCartInfo().setGlobalId(request.getCartInfo().getCartCreator());
			return  bpmHelper.saveCartWithEmail(request);

		});
	}

	/***
	 *MVP2 crm retreive cart from email
	 * @param cartId
	 * @param emailId
	 * @param httpHeader
	 * @return
	 */
	public Mono<CrmRetrieveCartUIResponse> crmRetrieveCart(String cartId, String emailId,String customerType,String accountNumber, ServerHttpRequest httpHeader){
		String sessionId = httpHeader.getHeaders().getFirst(CartConstants.DIGITAL_IG_SESSION);
		return bpmHelper.crmRetrieveCart(cartId,sessionId,emailId,customerType,accountNumber);
	}
	/***
	 *
	 * @param httpHeader
	 * @param request
	 */
	public void populateCartCreator(ServerHttpRequest httpHeader, @RequestBody AddPlanAndDeviceUIRequest request) {
		if(CartConstants.NSE_5G.equalsIgnoreCase(request.getCartInfo().getIntendType()) ||
				CartConstants.NSE_LTE.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
			String cartCreator = httpHeader.getHeaders().getFirst(CartConstants.DIGITAL_IG_SESSION);
			request.getCartInfo().setCartCreator(cartCreator);
			logger.info("setting cart creator as {}",cartCreator);
		}
	}

	/***
	 *
	 * @param httpHeader
	 * @param request
	 */
	public void populateCartCreator(ServerHttpRequest httpHeader, @RequestBody SaveCartWithEmailUIRequest request) {
		CartInfo cartInfo = new CartInfo();
		if(CartConstants.NSE_5G.equalsIgnoreCase(request.getIntendType()) ||
			CartConstants.NSE_LTE.equalsIgnoreCase(request.getIntendType()))
			cartInfo.setCartCreator(httpHeader.getHeaders().getFirst(CartConstants.DIGITAL_IG_SESSION));
			request.setCartInfo(cartInfo);
	}

	/**
	 *
	 * @param request
	 * @param httpResponse
	 * @return
	 */
	public Mono<ResponseEntity<GenericResponse>> swapOrderConfirmation(GetCartDetailsRequest request, ServerHttpResponse httpResponse) {

		CXPOrderConfirmation5GDataVO cxpOrderConfirmData = new CXPOrderConfirmation5GDataVO();
		if (null != request && null != request.getMeta().get(CartConstants.CART_ID)) {
			cxpOrderConfirmData.setCartId(request.getMeta().get(CartConstants.CART_ID));
		}
		if(null != request)
			logger.debug("Calling cxp helper for Swap with cartId {}", request.getMeta().get(CartConstants.CART_ID));
		return redisHelper3.fetchTechFlowAuditDetails().flatMap(redisData -> {
			return cxpHelper.swapOrderConfirmation(cxpOrderConfirmData, redisData).flatMap(cxpResponse -> {
				ErrorResponse errors2 = null;
				if (cxpResponse.getErrors() != null) {
					errors2 = CartCxpResponseErrorsUtil.handleOrderConfirmationResponseErrors(cxpResponse);
					if (null != errors2.getErrors() && null != errors2.getErrors().get(0)
							&& null != errors2.getErrors().get(0).getNamespace()
							&& errors2.getErrors().get(0).getNamespace().equalsIgnoreCase(CartConstants.SOE_CART_SERVICE)
							&& null != errors2.getErrors().get(0).getCode()
							&& errors2.getErrors().get(0).getCode().equalsIgnoreCase("400")) {
						httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
					}

					return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(errors2));
				}
				return Mono.just(ResponseEntity.status(HttpStatus.OK).body(transformSwapOrderCXPResponseToSOE(cxpResponse)));
			});
		});
	}

	/**
	 *
	 * @param cxpResponse
	 * @return GetCartDetailsUIResponse
	 */
	private GetCartDetailsUIResponse transformSwapOrderCXPResponseToSOE(OrderConfirmationUIResponse cxpResponse) {
		GetCartDetailsUIResponse response = new GetCartDetailsUIResponse();
		if (null != cxpResponse && null != cxpResponse.getData() && null != cxpResponse.getData().getCart()) {
			if (cxpResponse.getData().getCart().getCartHeader() != null) {
				response.setCartHeader(cxpResponse.getData().getCart().getCartHeader());
			}
			CXPOrderDetailsView orderDetailsView = new CXPOrderDetailsView();
			CXPOrderDetails cxpOrderDetails = cxpResponse.getData().getCart().getOrderDetails();
			if (null != cxpOrderDetails) {
				orderDetailsView.setLocationCode(cxpOrderDetails.getLocationCode());
				orderDetailsView.setOrderType(cxpOrderDetails.getOrderType());
			}
			if (null != cxpOrderDetails.getOrderList() && !cxpOrderDetails.getOrderList().isEmpty()) {
				Optional<OrderList> orderLst = cxpOrderDetails.getOrderList().stream().findFirst();
				if (orderLst.isPresent()) {
					orderDetailsView.setOrderNumber(String.valueOf(orderLst.get().getOrderNumber()));
				}
			}
			CXPLineDetailsVO lineDetails = cxpResponse.getData().getCart().getLineDetails();
			if (null != lineDetails && null != lineDetails.getNumOfLines()) {
				orderDetailsView.setNumOfLines(String.valueOf(lineDetails.getNumOfLines()));
			}
			if (null != lineDetails && null != lineDetails.getLineInfo()) {
				PrimaryUserInfo userInfo = new PrimaryUserInfo();
				for(CXPLineInfo CXPlineInfo : lineDetails.getLineInfo()){
					if (null != CXPlineInfo.getServiceInfo()
							&& null != CXPlineInfo.getServiceInfo().getPrimaryUserInfo()
							&& null != CXPlineInfo.getServiceInfo().getPrimaryUserInfo().getEmailId()) {
						userInfo.setEmailId(CXPlineInfo.getServiceInfo().getPrimaryUserInfo().getEmailId());
					}
				}
				response.setPrimaryUserInfo(userInfo);
			}
			response.setOrderDetailsView(orderDetailsView);
		}
		return response;
	}

	/**
	 *
	 * @param request
	 * @return AddPlanAndDeviceUIResponse
	 */
	public Mono<AddPlanAndDeviceUIResponse> upgradePlanAndDevice(AddPlanAndDeviceUIRequest request) {

		Mono<CustomerProfileAddressResponse> customerProfileAddress = redisHelper3.fetchCustomerAddressFromRedis();
		return redisHelper.getDataFromRedis().flatMap(redisData -> {
			return customerProfileAddress.flatMap(profileAddress -> {
				if (null != profileAddress.getData() && null != profileAddress.getData().getCustomerByMtn().getAddress()) {
					FiveGLTEAddressRedis addressRedis = profileAddress.getData().getCustomerByMtn().getAddress();
					CartAddDeviceUtil.populateSwapFiveGAddressFlow(request,addressRedis);
					request.getCartInfo().setAccountNumber(profileAddress.getAccountNo());
					if (CartConstants.EUP_5G_REPAIR.equalsIgnoreCase(profileAddress.getIntentType())) {
						request.getCartInfo().setIntendType("EUP_5G");
						request.getCartInfo().setTransactionType("repairGen2ToGen3");

					}
					if(StringUtils.isBlank(request.getCartInfo().getCartCreator())){
						request.getCartInfo().setCartCreator(redisData.getMtn());
					}
				}
				Mono<AddPlanAndDeviceUIResponse> UIResponse = Mono.empty();

				UIResponse = bpmHelper.addPlanAndDevice(request)

						.doOnError(e -> logger.error("Exception occur in upgrade-add-device method and error={}", e))

						.onErrorResume(SOEHTTPException.class, e -> {

							return Mono.just(CartPegaResponseErrorsUtil2.handleCommonErrorFiveGFlow(e.getErrorHolder()));
						});
				return UIResponse.flatMap(response -> {
					return Mono.just(response);
				});
			});
		});

	}

	/**
	 *
	 * @param checkoutRequest
	 * @return InspicioTermsAndConditions
	 */
	public Mono<InspicioTermsAndConditions> getAgreementDetails(CheckoutDetailsRequest checkoutRequest) {
		return cxpHelper.getAgreementDetails(checkoutRequest).flatMap(agreementDetailsResponse -> {
			InspicioTermsAndConditions response = new InspicioTermsAndConditions();
			if(CollectionUtilities.isEmptyOrNull(agreementDetailsResponse.getErrors())) {
				agreementDetailsResponse.getData().getCustomerAgreement().getAgreementList().forEach(agreement -> {
					if("customerAgreement".equalsIgnoreCase(agreement.getAgreementType())){
						response.setAgreementText(agreement.getAgreementText());
						response.setAgreementTextHeader("Customer Agreement");
					}
					if("5GTerms".equalsIgnoreCase(agreement.getAgreementType())){
						response.setTermsAndConditions5G(agreement.getAgreementText());
						response.setTermsAndConditions5GHeader("Verizon 5G Home Internet Terms of Service");
					}
					response.setDeviceName("#DEVICE_NAME#");
				});
			}
			return Mono.just(response);
		});
	}

	/**
	 *
	 * @param itemsInfo1
	 * @param lineInfo1
	 * @param orderDetailsView
	 * @param dueMonthlyList
	 * @param dueTodayList
	 */
	public void populateDPPPricingCartDetails(CXPCartItem itemsInfo1, CXPLineInfo lineInfo1, CXPOrderDetailsView orderDetailsView, List<CXPDueItemsList> dueMonthlyList, List<CXPDueItemsList> dueTodayList) {
		{

			CXPDueItemsList dueMonthlyItems = new CXPDueItemsList();
			dueMonthlyItems.setItemType(itemsInfo1.getCartItemType());
			dueMonthlyItems.setName(itemsInfo1.getDescription());
			dueMonthlyItems.setSorId(itemsInfo1.getSorId());
			dueMonthlyItems.setProductId(itemsInfo1.getProductId());
			dueMonthlyItems.setDiscountApplied(String.valueOf(itemsInfo1.getDiscountAmount()));
			dueMonthlyItems.setQuantity(String.valueOf(itemsInfo1.getQty()));
			if(null != lineInfo1.getInstallmentInfo()) {
				dueMonthlyItems.setActualAmount(String.valueOf(lineInfo1.getInstallmentInfo().getMonthlyInstallment()));
			}
			dueMonthlyItems.setTotalAmountWithDiscount(String.valueOf(itemsInfo1.getDeviceDueMonthly()));
			// apply SBD offer if present
			if (null != lineInfo1.getServiceInfo().getSbdOffer() && lineInfo1.getServiceInfo().getSbdOffer().size() > 0) {
				lineInfo1.getServiceInfo().getSbdOffer().stream().filter(Objects::nonNull).findFirst().ifPresent(sbdOffer -> {
					dueMonthlyItems.setDiscountApplied(String.valueOf(sbdOffer.getItemMonthlyDiscount()));
					dueMonthlyItems.setActualAmount(String.valueOf(sbdOffer.getItemMonthlyRetailPrice()));
					dueMonthlyItems.setTotalAmountWithDiscount(String.valueOf(sbdOffer.getItemMonthlyDiscountedPrice()));
					dueMonthlyItems.setSbdOfferAmount(String.valueOf(sbdOffer.getItemMonthlyDiscount()));
				});
			}

			dueMonthlyItems.setNpaNXX(itemsInfo1.getMobileNumber());
			if (null != itemsInfo1.getDepletionType()
					&& CartConstants.DEVICE.equalsIgnoreCase(itemsInfo1.getCartItemType())
					&& !CartConstants.HOME_SOLUTIONS.equalsIgnoreCase(lineInfo1.getDeviceTypeSelected())) {
				if ("O".equalsIgnoreCase(itemsInfo1.getDepletionType())) {
					dueMonthlyItems.setInstallationType(CartConstants.PROF_SETUP);
				} else if ("F".equalsIgnoreCase(itemsInfo1.getDepletionType()) || "L".equalsIgnoreCase(itemsInfo1.getDepletionType())) {
					dueMonthlyItems.setInstallationType(CartConstants.SELF_SETUP);
				}
				if (StringUtilities.isNotEmptyOrNull(lineInfo1.getLineActivityType())) {
					String lineActivityType = lineInfo1.getLineActivityType();
					if (lineInfo1.isLteHomeLine()) {
						orderDetailsView.setIsLTEHomeLine("true");
						orderDetailsView.setPriceTypeSelected(CartConstants.LTE_DPP_PRICETYPE);
					}
					orderDetailsView.setLineActivityType(lineActivityType);
				}
				if (StringUtils.isBlank(orderDetailsView.getInstallType())) {
					orderDetailsView.setInstallType(dueMonthlyItems.getInstallationType());
				}
				if (null != itemsInfo1.getInventory()) {
					dueMonthlyItems.setIsBackorder(String.valueOf(itemsInfo1.getInventory().getIsBackorder()));
					dueMonthlyItems.setPreBackDate(itemsInfo1.getPreBackDate() != null ? itemsInfo1.getPreBackDate() : StringUtils.EMPTY);
                    if(itemsInfo1.getInventory().getIsBackorder() != null && itemsInfo1.getInventory().getIsDeliverBy() != null) {
                        if (itemsInfo1.getInventory().getIsBackorder() && itemsInfo1.getInventory().getIsDeliverBy()) {
                            dueMonthlyItems.setIsDeliverBy(CartConstants.TRUE_FLAG);
                        } else {
                            dueMonthlyItems.setIsDeliverBy(CartConstants.FALSE);
                        }
                    }
                    if(itemsInfo1.getInventory().getIsBackorder() != null && itemsInfo1.getInventory().getIsShipBy() != null) {
                        if (itemsInfo1.getInventory().getIsBackorder() &&
								itemsInfo1.getInventory().getIsShipBy()) {
                            dueMonthlyItems.setIsShipBy(CartConstants.TRUE_FLAG);
                        } else {
                            dueMonthlyItems.setIsShipBy(CartConstants.FALSE);
                        }
                    }
				}
				dueMonthlyItems.setNetworkBandwidthType(itemsInfo1.getNetworkBandwidthType());
				orderDetailsView.setNetworkBandwidthType(itemsInfo1.getNetworkBandwidthType());
			}
			if (CartConstants.DEVICE.equalsIgnoreCase(itemsInfo1.getCartItemType())) {
				dueMonthlyItems.setLineNumber(lineInfo1.getLineNumber());
			}
			dueMonthlyItems.setTaxAmount(String.valueOf(itemsInfo1.getTaxAmount()));
			try {
				if (CartConstants.DEVICE.equalsIgnoreCase(itemsInfo1.getCartItemType())
						&& !CartConstants.HOME_SOLUTIONS.equalsIgnoreCase(lineInfo1.getDeviceTypeSelected()) && ("CBD".equalsIgnoreCase(dueMonthlyItems.getNetworkBandwidthType()) || "LTE".equalsIgnoreCase(dueMonthlyItems.getNetworkBandwidthType()))
						&& null != dueMonthlyItems.getDiscountApplied() && Double.valueOf(dueMonthlyItems.getActualAmount()).equals(Double.valueOf(dueMonthlyItems.getDiscountApplied()))) {
					dueMonthlyItems.setFullPriceDiscount("true");
				}
			} catch (Exception e) {
				logger.info(CartConstants.HELPER_DISCOUNT_EXCEPTION);
			}
			dueMonthlyList.add(dueMonthlyItems);
			CXPDueItemsList dueTodayLteItem = new CXPDueItemsList();
			BeanUtils.copyProperties(dueMonthlyItems, dueTodayLteItem);
			//downpayment Scenario
			if (null != lineInfo1.getInstallmentInfo()
					&& StringUtilities.isNotEmptyOrNull(lineInfo1.getInstallmentInfo().getDownPayment())
					&& Double.valueOf(lineInfo1.getInstallmentInfo().getDownPayment()) > 0) {

				dueTodayLteItem.setTotalAmountWithDiscount(String.valueOf(lineInfo1.getInstallmentInfo().getDownPayment()));
				orderDetailsView.setDownPaymentAmount(String.valueOf(lineInfo1.getInstallmentInfo().getDownPayment()));
			}
			dueTodayList.add(dueTodayLteItem);
		}
	}

	/**
	 *
	 * @param itemsInfo1
	 * @param lineInfo1
	 * @param orderDetailsView
	 * @param dueMonthlyList
	 * @param dueTodayList
	 */
	public void populateDeviceDueTodayCartDetails(CXPCartItem itemsInfo1, CXPLineInfo lineInfo1, CXPOrderDetailsView orderDetailsView, List<CXPDueItemsList> dueMonthlyList, List<CXPDueItemsList> dueTodayList) {
		CXPDueItemsList dueTodayItems = populateDueTodayItems(itemsInfo1);
		validateFWASweetnerDealInOrder( orderDetailsView,  itemsInfo1);
		// install type will be only for DEVICE(Router) item
		if (CartConstants.DEVICE.equalsIgnoreCase(itemsInfo1.getCartItemType())
				&& !CartConstants.HOME_SOLUTIONS.equalsIgnoreCase(lineInfo1.getDeviceTypeSelected())) {
			if (null != itemsInfo1.getDepletionType()) {
				if ("O".equalsIgnoreCase(itemsInfo1.getDepletionType())) {
					dueTodayItems.setInstallationType(CartConstants.PROF_SETUP);
				} else if ("F".equalsIgnoreCase(itemsInfo1.getDepletionType()) || "L".equalsIgnoreCase(itemsInfo1.getDepletionType())) {
					dueTodayItems.setInstallationType(CartConstants.SELF_SETUP);
				}
			}
			if (StringUtilities.isNotEmptyOrNull(lineInfo1.getLineActivityType())) {
				String lineActivityType = lineInfo1.getLineActivityType();
				if (lineInfo1.isLteHomeLine()) {
					orderDetailsView.setIsLTEHomeLine("true");
					orderDetailsView.setPriceTypeSelected(CartConstants.LTE_FRP_PRICETYPE);
				}
				orderDetailsView.setLineActivityType(lineActivityType);
			}
			if (StringUtils.isBlank(orderDetailsView.getInstallType())) {
				orderDetailsView.setInstallType(dueTodayItems.getInstallationType());
			}
			dueTodayItems.setMultiLineSeqNumber(lineInfo1.getMultiLineSeqNumber());
			// BackOrdering Changes
			if (null != itemsInfo1.getInventory()) {
				dueTodayItems.setIsBackorder(String.valueOf(itemsInfo1.getInventory().getIsBackorder()));
				dueTodayItems.setPreBackDate(itemsInfo1.getPreBackDate() != null ? itemsInfo1.getPreBackDate() : StringUtils.EMPTY);
				if(itemsInfo1.getInventory().getIsDeliverBy() != null && itemsInfo1.getInventory().getIsBackorder() != null) {
					if (itemsInfo1.getInventory().getIsBackorder() && itemsInfo1.getInventory().getIsDeliverBy()) {
						dueTodayItems.setIsDeliverBy(CartConstants.TRUE_FLAG);
					} else {
						dueTodayItems.setIsDeliverBy(CartConstants.FALSE);
					}
				}
				if(itemsInfo1.getInventory().getIsShipBy() != null && itemsInfo1.getInventory().getIsBackorder() != null) {
					if (itemsInfo1.getInventory().getIsBackorder() && itemsInfo1.getInventory().getIsShipBy()) {
						dueTodayItems.setIsShipBy(CartConstants.TRUE_FLAG);
					} else {
						dueTodayItems.setIsShipBy(CartConstants.FALSE);
					}
				}
			}
			dueTodayItems.setNetworkBandwidthType(itemsInfo1.getNetworkBandwidthType());
			orderDetailsView.setNetworkBandwidthType(itemsInfo1.getNetworkBandwidthType());

		} else if (CartConstants.DEVICE.equalsIgnoreCase(itemsInfo1.getCartItemType()) // populate npanxx for HomePhone
				&& CartConstants.HOME_SOLUTIONS.equalsIgnoreCase(lineInfo1.getDeviceTypeSelected())) {
			if (null != lineInfo1.getMtnDetails()) {
				dueTodayItems.setNpaNXX(lineInfo1.getMtnDetails().getNpaNXX());
			}
			dueTodayItems.setIsHomePhone(true);
			dueTodayItems.setMultiLineSeqNumber(lineInfo1.getMultiLineSeqNumber());
		}
		dueTodayItems.setTaxAmount(String.valueOf(itemsInfo1.getTaxAmount()));
		if (CartConstants.DEVICE.equalsIgnoreCase(itemsInfo1.getCartItemType())) {
			dueTodayItems.setLineNumber(lineInfo1.getLineNumber());
		}
		try {
			if (CartConstants.DEVICE.equalsIgnoreCase(itemsInfo1.getCartItemType())
					&& !CartConstants.HOME_SOLUTIONS.equalsIgnoreCase(lineInfo1.getDeviceTypeSelected()) && ("CBD".equalsIgnoreCase(dueTodayItems.getNetworkBandwidthType()) || "LTE".equalsIgnoreCase(dueTodayItems.getNetworkBandwidthType()))
					&& null != dueTodayItems.getDiscountApplied() && Double.valueOf(dueTodayItems.getActualAmount()).equals(Double.valueOf(dueTodayItems.getDiscountApplied()))) {
				dueTodayItems.setFullPriceDiscount("true");
			}
		} catch (Exception e) {
			logger.info(CartConstants.HELPER_DISCOUNT_EXCEPTION);
		}
		dueTodayList.add(dueTodayItems);
	}

	/**
	 *
	 * @param redesignFlow
	 * @param lineInfo1
	 * @param ecpdProfile
	 * @param dueMonthlyPlanItems
	 */
	public void applyPlanDiscountsOnPlan(boolean redesignFlow, CXPLineInfo lineInfo1, EcpdProfileInfo ecpdProfile, CXPDueItemsList dueMonthlyPlanItems) {

		// apply AutoPay
		if (redesignFlow && null != lineInfo1.getServiceInfo().getSelectedFeaturesList() && lineInfo1.getServiceInfo().getSelectedFeaturesList().getFeaturesCount() > 1) {
			lineInfo1.getServiceInfo().getSelectedFeaturesList().getVisFeature().stream().filter(Objects::nonNull).filter(visFeature ->
					"SPO".equalsIgnoreCase(visFeature.getType()) && "L".equalsIgnoreCase(visFeature.getLevel()) &&
							visFeature.getCategoryCodes().contains(CartConstants.DISC_PROMO) && visFeature.getCategoryCodes().contains(CartConstants.PAPER_FREE)
							&& visFeature.getCategoryCodes().contains(CartConstants.AUTOPAY)).findFirst().ifPresent(visFeature -> {
				dueMonthlyPlanItems.setTotalAmountWithDiscount(String.valueOf(Double.parseDouble(dueMonthlyPlanItems.getTotalAmountWithDiscount()) + Double.parseDouble(visFeature.getFeaturePrice())));
			});
		}
		// apply loyalty discount for plan price other than homepHone plan
		if (!CartConstants.HOME_SOLUTIONS.equalsIgnoreCase(lineInfo1.getDeviceTypeSelected()) && null != lineInfo1.getServiceInfo().getSelectedFeaturesList() && lineInfo1.getServiceInfo().getSelectedFeaturesList().getFeaturesCount() > 1) {
			lineInfo1.getServiceInfo().getSelectedFeaturesList().getVisFeature().stream().filter(Objects::nonNull).filter(visFeature -> visFeature.getCategoryCodes() != null).filter(visFeature ->
					visFeature.getCategoryCodes().stream().anyMatch(str -> str.equalsIgnoreCase(CartConstants.FIVEG_LOYALTY) ||
							str.equalsIgnoreCase(CartConstants.LTE_LOYALTY) || str.equalsIgnoreCase(CartConstants.FIVEG_BUNDLE) || str.equalsIgnoreCase(CartConstants.VISBLPREPD)) &&
							!visFeature.getCategoryCodes().stream().anyMatch(str ->  str.equalsIgnoreCase(CartConstants.DAW01) )).forEach(visFeature ->
					dueMonthlyPlanItems.setTotalAmountWithDiscount(String.valueOf((Double.parseDouble(dueMonthlyPlanItems.getTotalAmountWithDiscount())) + Double.parseDouble(visFeature.getFeaturePrice())))

			);
		}
		//apply ecpd discount
		if (null != lineInfo1.getServiceInfo() && null != lineInfo1.getServiceInfo().getPlanDetails()
				&& null != lineInfo1.getServiceInfo().getPlanDetails().getPlanPromotions()
				&& null != lineInfo1.getServiceInfo().getPlanDetails().getPlanPromotions().getPromos()
				&& null != ecpdProfile
				&& lineInfo1.getServiceInfo().getPlanDetails().getPlanPromotions().getPromos().size() > 0) {
			lineInfo1.getServiceInfo().getPlanDetails().getPlanPromotions().getPromos().stream().filter(planPromos -> null != planPromos && !CartConstants.HUNDRED.equalsIgnoreCase(planPromos.getPercentageOff())).findFirst().ifPresent(planPromos -> {
				if (null != planPromos.getAmountOff()) {
					dueMonthlyPlanItems.setTotalAmountWithDiscount(String.valueOf(Double.parseDouble(dueMonthlyPlanItems.getTotalAmountWithDiscount()) - Double.parseDouble(planPromos.getAmountOff())));
				}

			});

		}

		// apply Visible or Prepaid offer
		if (null != lineInfo1.getServiceInfo().getSelectedFeaturesList() && lineInfo1.getServiceInfo().getSelectedFeaturesList().getFeaturesCount() > 1) {
			lineInfo1.getServiceInfo().getSelectedFeaturesList().getVisFeature().stream().filter(Objects::nonNull).filter(visFeature ->
					visFeature.getCategoryCodes().stream().anyMatch(str -> str.equalsIgnoreCase("5GHOMEDISC"))).findFirst().ifPresent(visFeature -> {
				dueMonthlyPlanItems.setTotalAmountWithDiscount(String.valueOf((Double.parseDouble(dueMonthlyPlanItems.getTotalAmountWithDiscount())) + Double.parseDouble(visFeature.getFeaturePrice())));
			});
		}

		// apply FWA Discount
		if (null != lineInfo1.getServiceInfo().getSelectedFeaturesList() && lineInfo1.getServiceInfo().getSelectedFeaturesList().getFeaturesCount() > 1) {
			lineInfo1.getServiceInfo().getSelectedFeaturesList().getVisFeature().stream().filter(Objects::nonNull).filter(visFeature ->
					visFeature.getCategoryCodes().stream().anyMatch(str -> str.equalsIgnoreCase("REMKG"))).findFirst().ifPresent(visFeature -> {
				dueMonthlyPlanItems.setTotalAmountWithDiscount(String.valueOf((Double.parseDouble(dueMonthlyPlanItems.getTotalAmountWithDiscount())) + Double.parseDouble(visFeature.getFeaturePrice())));
			});
		}

	}

	/**
	 *
	 * @param redesignFlow
	 * @param lineInfo1
	 * @param dueMonthlyList
	 * @param ecpdProfile
	 */
	public void populateDiscounts(boolean redesignFlow, CXPLineInfo lineInfo1, List<CXPDueItemsList> dueMonthlyList, EcpdProfileInfo ecpdProfile) {

		if(!cartRedesignKillSwitch) {
			populateDiscountsSPO(redesignFlow, lineInfo1, dueMonthlyList, ecpdProfile);
		}
		else {
			populateAutopayDiscount(redesignFlow, lineInfo1, dueMonthlyList);
			populateLoyaltyAndVisibleDiscount(redesignFlow, lineInfo1, dueMonthlyList);
			populateEcpdDiscount(redesignFlow, lineInfo1, dueMonthlyList, ecpdProfile, new AtomicDouble());
		}
	}

	private AtomicDouble populatePlanPromotionsFromSPO(List<CXPDueItemsList> dueMonthlyList, AtomicDouble discountAmount, VisFeature vf) {
		CXPDueItemsList cxpDueItemsList =  new CXPDueItemsList();
		if(vf.getCategoryCodes().contains(CartConstants.FIVEG_AUTOPAY)) {
			cxpDueItemsList.setName("Auto Pay & Paper-free billing");
		} else {
			cxpDueItemsList.setName(WordUtils.capitalizeFully(StringUtilities.isNotEmptyOrNull(vf.getFeatureBillDesc()) ? vf.getFeatureBillDesc() : vf.getFeatureDesc()));
		}
		double discountPrice =  Double.parseDouble(StringUtilities.isNotEmptyOrNull(vf.getFeaturePrice())?vf.getFeaturePrice():"0.0");
		cxpDueItemsList.setTotalAmountWithDiscount(String.valueOf(Math.abs(discountPrice)));
		cxpDueItemsList.setActualAmount(String.valueOf(Math.abs(discountPrice)));
		cxpDueItemsList.setProductId(vf.getVisFeatureCode());
		boolean isCouponSPO = !Collections.disjoint(vf.getCategoryCodes(), fwaSPOCouponCategories);
		boolean isAccountSPO = !Collections.disjoint(vf.getCategoryCodes(), fwaAccountSPOCategories);
		if(isCouponSPO || !isAccountSPO) {
			cxpDueItemsList.setCouponDiscount(isCouponSPO);
			cxpDueItemsList.setItemType(isCouponSPO ? CartConstants.COUPON_DISCOUNT : CartConstants.HELPER_DISCOUNT);
			discountAmount.getAndAdd(Double.parseDouble(vf.getFeaturePrice()));
		} else {
			cxpDueItemsList.setItemType(CartConstants.ACCOUNT_DISCOUNT);
			cxpDueItemsList.setAccountDiscount(true);
		}
		Boolean emberDiscountFlag=featureFlagHelper.emberDiscountFeatureFlag();
		if(emberDiscountFlag!=null && emberDiscountFlag && CartConstants.MH_DISCOUNT_VIZ_FEATURE.equalsIgnoreCase(vf.getFeatureDesc()))
			dueMonthlyList.add(1,cxpDueItemsList);
		else
			dueMonthlyList.add(cxpDueItemsList);
		return discountAmount;
	}
	private boolean isFWADiscountSPO(VisFeature visionFeature) {
		return  "SPO".equalsIgnoreCase(visionFeature.getType())
				&& ("L".equalsIgnoreCase(visionFeature.getLevel()) || "A".equalsIgnoreCase(visionFeature.getLevel()))
				&& "A".equalsIgnoreCase(visionFeature.getAddDeleteInd())
				&& !org.springframework.util.CollectionUtils.isEmpty(visionFeature.getCategoryCodes())
				&& !Collections.disjoint(fwaSPOCategoryCodes, visionFeature.getCategoryCodes());
	}

	public void populateDiscountsSPO(boolean redesignFlow, CXPLineInfo lineInfo1, List<CXPDueItemsList> dueMonthlyList, EcpdProfileInfo ecpdProfile) {

		if(null != lineInfo1.getServiceInfo()){
			ServiceInfo serviceInfo = lineInfo1.getServiceInfo();
			AtomicDouble discountAmount = new AtomicDouble(0.0);
			if(serviceInfo.getNewPricePlanInfo() != null && serviceInfo.getNewPricePlanInfo().getPlanPrice() != null)
				discountAmount.set(serviceInfo.getNewPricePlanInfo().getPlanPrice());
			populateEcpdDiscount(redesignFlow,lineInfo1, dueMonthlyList, ecpdProfile, discountAmount);
			if (null != serviceInfo.getSelectedFeaturesList() && serviceInfo.getSelectedFeaturesList().getFeaturesCount() > 0) {
				serviceInfo.getSelectedFeaturesList().getVisFeature().stream().filter(this::isFWADiscountSPO).forEach(vf ->
						populatePlanPromotionsFromSPO(dueMonthlyList, discountAmount, vf));
			}
			dueMonthlyList.stream().filter(cxpDueItemsList -> "PLAN".equalsIgnoreCase(cxpDueItemsList.getItemType()) && null!= cxpDueItemsList.getProductId() && cxpDueItemsList.getProductId().equalsIgnoreCase(serviceInfo.getNewPricePlanId())).findFirst().ifPresent(cxpDueItemsList -> {
				cxpDueItemsList.setTotalAmountWithDiscount(discountAmount.toString());
			});
		}
	}
	/**
	 * @param redesignFlow
	 * @param lineInfo1
	 * @param dueMonthlyList
	 * @param ecpdProfile
	 * @param discountAmount
	 */
	private void populateEcpdDiscount(boolean redesignFlow, CXPLineInfo lineInfo1, List<CXPDueItemsList> dueMonthlyList, EcpdProfileInfo ecpdProfile, AtomicDouble discountAmount) {
		if (redesignFlow && !CartConstants.HOME_SOLUTIONS.equalsIgnoreCase(lineInfo1.getDeviceTypeSelected()) && null != lineInfo1.getServiceInfo() && null != lineInfo1.getServiceInfo().getPlanDetails()
				&& null != lineInfo1.getServiceInfo().getPlanDetails().getPlanPromotions()
				&& null != lineInfo1.getServiceInfo().getPlanDetails().getPlanPromotions().getPromos()
				&& null != ecpdProfile
				&& lineInfo1.getServiceInfo().getPlanDetails().getPlanPromotions().getPromos().size() > 0) {
			lineInfo1.getServiceInfo().getPlanDetails().getPlanPromotions().getPromos().stream().filter(planPromos -> null != planPromos && !CartConstants.HUNDRED.equalsIgnoreCase(planPromos.getPercentageOff())).findFirst().ifPresent(planPromos -> {
				if (null != planPromos.getAmountOff()) {
					CXPDueItemsList ecpdDiscount = new CXPDueItemsList();
					ecpdDiscount.setItemType(CartConstants.HELPER_DISCOUNT);
					ecpdDiscount.setName(((int) Double.parseDouble(planPromos.getPercentageOff())) + "% " + "Employee Discount");
					ecpdDiscount.setActualAmount(String.valueOf(Double.parseDouble(planPromos.getAmountOff())));
					ecpdDiscount.setTotalAmountWithDiscount(String.valueOf(Double.parseDouble(planPromos.getAmountOff())));
					if(!cartRedesignKillSwitch)
						discountAmount.getAndSet(discountAmount.doubleValue() - Double.parseDouble(lineInfo1.getServiceInfo().getPlanDetails().getPlanPromotions().getTotalDiscount()));
					dueMonthlyList.add(ecpdDiscount);
				}

			});

		}
	}

	/**
	 *
	 * @param redesignFlow
	 * @param lineInfo1
	 * @param dueMonthlyList
	 */
	private void populateLoyaltyAndVisibleDiscount(boolean redesignFlow, CXPLineInfo lineInfo1, List<CXPDueItemsList> dueMonthlyList) {
		if (redesignFlow
				&& !CartConstants.HOME_SOLUTIONS.equalsIgnoreCase(lineInfo1.getDeviceTypeSelected())
				&& null != lineInfo1.getServiceInfo().getSelectedFeaturesList()
				&& lineInfo1.getServiceInfo().getSelectedFeaturesList().getFeaturesCount() > 1) {
			lineInfo1.getServiceInfo().getSelectedFeaturesList().getVisFeature().stream().filter(Objects::nonNull).filter(visFeature -> visFeature.getCategoryCodes() != null).filter(visFeature ->
					visFeature.getCategoryCodes().stream().anyMatch(str -> str.equalsIgnoreCase(CartConstants.FIVEG_LOYALTY) ||
							str.equalsIgnoreCase(CartConstants.LTE_LOYALTY) || str.equalsIgnoreCase(CartConstants.DAW01) || str.equalsIgnoreCase(CartConstants.FIVEG_BUNDLE) || str.equalsIgnoreCase(CartConstants.VISBLPREPD) || str.equalsIgnoreCase(CartConstants.REMKG))).forEach(visFeature -> {
				CXPDueItemsList loyaltyDiscount = new CXPDueItemsList();
				loyaltyDiscount.setItemType(CartConstants.HELPER_DISCOUNT);
				boolean isWillow = commonUtil.isWillowIds(dueMonthlyList);
				if (isWillow) {
					loyaltyDiscount.setName(WordUtils.capitalizeFully(visFeature.getFeatureDesc()));
				} else{
					loyaltyDiscount.setName("Verizon Wireless Loyalty Discount");
				if (visFeature.getFeatureDesc().toLowerCase().contains("UNLIMITED PLAN".toLowerCase()))
					loyaltyDiscount.setName("Verizon Wireless Unlimited Discount");
				}
				 if(visFeature.getCategoryCodes().contains("VISBLPREPD")) {
					populateCouponDiscountName(visFeature, loyaltyDiscount);
				}
				try {
				if(StringUtilities.isNotEmptyOrNull(visFeature.getFeatureDesc()) && visFeature.getCategoryCodes().contains(CartConstants.DAW01)) {
						loyaltyDiscount.setItemType("ACCOUNTPROMO");
						loyaltyDiscount.setName(visFeature.getFeatureDesc().substring(0, 1).toUpperCase() +
								visFeature.getFeatureDesc().substring(1, 9).toLowerCase() +
								visFeature.getFeatureDesc().substring(9, 10).toUpperCase() + visFeature.getFeatureDesc().substring(10).toLowerCase());
					}
				}
				catch (Exception e)
					{
						logger.info("Exception in formatting discount"+e.getMessage());
					}
				if(visFeature.getCategoryCodes().contains(CartConstants.REMKG)) {
					loyaltyDiscount.setName(WordUtils.capitalizeFully(visFeature.getFeatureDesc()));
					loyaltyDiscount.setCouponDiscount(true);
				}
				loyaltyDiscount.setActualAmount(visFeature.getFeaturePrice());
				loyaltyDiscount.setTotalAmountWithDiscount(visFeature.getFeaturePrice());
				dueMonthlyList.add(loyaltyDiscount);

			});
		}
	}

	/**
	 *
	 * @param visFeature
	 * @param loyaltyDiscount
	 */
	private void populateCouponDiscountName(VisFeature visFeature, CXPDueItemsList loyaltyDiscount) {
		StringBuilder sb = new StringBuilder();
		if(StringUtilities.isNotEmptyOrNull(visFeature.getFeatureBillDesc())) {
			String featureDesc = visFeature.getFeatureBillDesc().toLowerCase();
			String[] wordsList = featureDesc.split("\\s");
			Arrays.stream(wordsList).forEach(s -> {
				if(s.contains("+") &&  s.split("\\+").length > 1) {
					String[] wordsWithChar = s.split("\\+");
					String s2 = wordsWithChar[1].substring(0, 1).toUpperCase() + wordsWithChar[1].substring(1);
					s= wordsWithChar[0] +"+"+ s2;
				}
				sb.append(s.substring(0,1).toUpperCase() + s.substring(1) + " ");
			});
		}
		loyaltyDiscount.setName(sb.toString().trim());
		loyaltyDiscount.setCouponDiscount(true);
	}

	/**
	 *
	 * @param redesignFlow
	 * @param lineInfo1
	 * @param dueMonthlyList
	 */
	private void populateAutopayDiscount(boolean redesignFlow, CXPLineInfo lineInfo1, List<CXPDueItemsList> dueMonthlyList) {
		if (null != lineInfo1.getServiceInfo().getSelectedFeaturesList() && lineInfo1.getServiceInfo().getSelectedFeaturesList().getFeaturesCount() > 1) {
			lineInfo1.getServiceInfo().getSelectedFeaturesList().getVisFeature().stream().filter(Objects::nonNull).filter(visFeature ->
					"SPO".equalsIgnoreCase(visFeature.getType()) && "L".equalsIgnoreCase(visFeature.getLevel()) &&
							visFeature.getCategoryCodes().contains(CartConstants.DISC_PROMO) && visFeature.getCategoryCodes().contains(CartConstants.PAPER_FREE)
							&& visFeature.getCategoryCodes().contains(CartConstants.AUTOPAY)).findFirst().ifPresent(visFeature -> {
				CXPDueItemsList autopayDiscount = new CXPDueItemsList();
				autopayDiscount.setItemType(CartConstants.HELPER_DISCOUNT);
				autopayDiscount.setName("Autopay discount");
				if (redesignFlow) {
					autopayDiscount.setName("Auto Pay & Paper-free billing");
				}
				autopayDiscount.setActualAmount(visFeature.getFeaturePrice());
				autopayDiscount.setTotalAmountWithDiscount(visFeature.getFeaturePrice());
				dueMonthlyList.add(autopayDiscount);
			});
		}
	}

	/**
	 *
	 * @param dueMonthlyPlanItems
	 * @param lineInfo1
	 * @param planDetails
	 * @param orderDetailsView
	 * @param dueMonthlyList
	 */
	//resolving duplication
	public void populateOverDetailsView(String lineActivityType, CXPDueItemsList dueMonthlyPlanItems, CXPLineInfo lineInfo1,Map<String, String> planDetails,CXPOrderDetailsView orderDetailsView, List<CXPDueItemsList> dueMonthlyList) {
		dueMonthlyPlanItems.setProductId(lineInfo1.getServiceInfo().getNewPricePlanId());
		if (null != lineInfo1.getServiceInfo().getNewPricePlanInfo()) {
			dueMonthlyPlanItems.setName(lineInfo1.getServiceInfo().getNewPricePlanInfo().getPricePlanDisplayName());
		}
		if (CartConstants.HOME_SOLUTIONS.equalsIgnoreCase(lineInfo1.getDeviceTypeSelected())) {
			dueMonthlyPlanItems.setIsHomePhone(true);
		} else {
			planDetails.put("selectedPlan",lineInfo1.getServiceInfo().getNewPricePlanId());
		}
		orderDetailsView.setLaunchType(lineInfo1.getLaunchType());
		dueMonthlyPlanItems.setItemType(CartConstants.ITEMTYPE_PLAN);
		dueMonthlyList.add(dueMonthlyPlanItems);

		if(StringUtils.isNotBlank(lineInfo1.getSecurityDepositAmount()) && !"0".equals(lineInfo1.getSecurityDepositAmount())) {
			orderDetailsView.setSecurityDeposit(lineInfo1.getSecurityDepositAmount());
			orderDetailsView.setSecurityDepositNeed(String.valueOf(true));
		}
	}
	public void populateCartDetails(AtomicBoolean isEupFlow, CXPLineInfo lineInfo1, List<CXPShippingVO> shippingDetails, CXPOrderDetailsView orderDetailsView, List<CXPDueItemsList> dueMonthlyList, List<CXPDueItemsList> dueTodayList) {

		if("EUP".equalsIgnoreCase(lineInfo1.getLineActivityType())) {
			isEupFlow.set(true);
		}
		Arrays.stream(lineInfo1.getItemsInfo()).filter(Objects::nonNull).forEach(itemsInfo -> {
			if (shippingDetails.isEmpty() && itemsInfo.getShipping() != null) {
				shippingDetails.add(itemsInfo.getShipping());
			}
			Optional.ofNullable(itemsInfo).map(CXPItemInfo::getCartItems).ifPresent(cartItems -> {
				Arrays.stream(cartItems.getCartItem()).filter(Objects::nonNull).forEach(itemsInfo1 -> {
					if (CartConstants.MONTH_TO_MONTH.equalsIgnoreCase(itemsInfo1.getPriceType())
							&& CartConstants.DEVICE_TYPE.equalsIgnoreCase(itemsInfo1.getCartItemType()) && StringUtilities.isNotEmptyOrNull(itemsInfo1.getProductId())) {
						populateDeviceDueTodayCartDetails(itemsInfo1,lineInfo1,orderDetailsView,dueMonthlyList,dueTodayList);

					} else if ("VERIZON_EDGE".equalsIgnoreCase(itemsInfo1.getPriceType())
							&& CartConstants.DEVICE_TYPE.equalsIgnoreCase(itemsInfo1.getCartItemType()) && StringUtilities.isNotEmptyOrNull(itemsInfo1.getProductId())) {
						populateDPPPricingCartDetails(itemsInfo1,lineInfo1,orderDetailsView,dueMonthlyList,dueTodayList);
					}
				});

			});
		});
	}

	/**
	 *
	 * @param lineDetails
	 * @param lineInfo
	 * @param dueMonthlyList
	 * @param redesignFlow
	 * @param ecpdProfile
	 * @return
	 */
	public CXPLineInfo[] callToPopulateDiscounts(CXPOrderDetails cxpOrderDetails1,CXPLineDetailsVO lineDetails, CXPLineInfo[] lineInfo, List<CXPDueItemsList> dueMonthlyList, boolean redesignFlow, EcpdProfileInfo ecpdProfile, boolean isLoggedIn) {
		if (null != lineDetails && null != lineDetails.getLineInfo()) {
			CXPLineInfo[] sortedLineInfo = Arrays.stream(lineDetails.getLineInfo()).filter(lineInf -> (lineInf.getLineNumber() != null && !"FEA".equalsIgnoreCase(lineInf.getLineActivityType())) || (lineInf.getMtnDetails() != null && CartConstants.FEA.equalsIgnoreCase(lineInf.getLineActivityType()))).sorted(Comparator.comparing(CXPLineInfo::getLineNumber)).collect(Collectors.toList()).toArray(new CXPLineInfo[lineDetails.getNumOfLines()]);
			Arrays.stream(sortedLineInfo).filter(Objects::nonNull).forEach(lineInfo1 -> {
				// subscription items
                commonUtil.formatDueMonthlyList(lineInfo1.getLineActivityType(),cxpOrderDetails1,lineDetails, dueMonthlyList, lineInfo1);
				// add discounts loyalty,autopay,edpc etc.., to UI response
				populateDiscounts(redesignFlow,lineInfo1,dueMonthlyList,ecpdProfile);
			});
		}
		return lineInfo;
	}

	public void setPlanPerks(CXPLineInfo[] lineInfo) {
		logger.debug("Inside CartCxpResponseUtil1.setBayouPlanPerks");
		try {
			for (CXPLineInfo line :lineInfo) {
				if (line.getServiceInfo() != null && line.getServiceInfo().getSelectedFeaturesList() != null
						&& CollectionUtilities.isNotEmptyOrNull(line.getServiceInfo().getSelectedFeaturesList().getVisFeature())) {
					List<PlanPerks> planPerksList = line.getServiceInfo().getSelectedFeaturesList().getVisFeature().stream()
							.filter(visFeatures -> CartConstants.FLOWS_LIST.contains(visFeatures.getSource()))
							.filter(visFeatures ->  CollectionUtilities.isNotEmptyOrNull(visFeatures.getCategoryCodes()) && visFeatures.getCategoryCodes().contains(CartConstants.BYOPERK))
							.filter(visFeatures -> "A".equalsIgnoreCase(visFeatures.getAddDeleteInd()) || "Z".equalsIgnoreCase(visFeatures.getAddDeleteInd()))
							.map(visFeature -> createPlanPerk(visFeature, line.getServiceInfo().getOtherPromotions()))
							.sorted(Comparator.comparing(PlanPerks::getRank,Comparator.nullsLast((l1, l2) -> {
								if (l1 == 0) return 1;
								if (l2 == 0) return -1;
								return l1 - l2;
							})))
							.collect(Collectors.toList());
					line.getServiceInfo().setPlanPerks(planPerksList);
				}
			}
		}catch (Exception npe) {
			logger.error("setBayouPlanPerks is null");
		}
	}

	private PlanPerks createPlanPerk(VisFeature bayouVisFeatures, OtherPromotions[] otherPromotions){
		PlanPerks planPerks = new PlanPerks();
		planPerks.setLevel(bayouVisFeatures.getLevel());
		planPerks.setFeatureDesc(bayouVisFeatures.getFeatureDesc());
		planPerks.setType(bayouVisFeatures.getType());
		planPerks.setVisFeatureCode(bayouVisFeatures.getVisFeatureCode());
		planPerks.setFeaturePrice(bayouVisFeatures.getFeaturePrice());
		planPerks.setPerkOriginalPrice(bayouVisFeatures.getPerkOriginalPrice());
		planPerks.setRank(bayouVisFeatures.getRank());

		if (otherPromotions != null && otherPromotions.length > 0) {
			List.of(otherPromotions).stream().forEach(otherPromo -> {
				if (bayouVisFeatures.getVisFeatureCode().equalsIgnoreCase(otherPromo.getElementId())) {
					DiscountsAndPromotions discountsAndPromotions = new DiscountsAndPromotions();
					discountsAndPromotions.setFinalPrice(otherPromo.getFinalPrice());
					discountsAndPromotions.setActualPrice(otherPromo.getActualPrice());
					discountsAndPromotions.setPromos(otherPromo.getPromos());
					planPerks.setDiscountsAndPromotions(discountsAndPromotions);
				}
			});
		}
		return planPerks;
	}


	/**
	 *
	 * @param addTruckRollCartUIResponse
	 * @return
	 */
	public Mono<OrderReviewDetailsResponse> orderReviewDetails(AddTruckRollCartUIResponse addTruckRollCartUIResponse) {
		logger.info("Calling orderReviewDetails() for FiveGhomeCommonHelper");
		GetOrderDetailsGQLRequest gqlRequest = getOrderDetailsGQLRequest(addTruckRollCartUIResponse);
		Mono<OrderReviewDetailsResponse> resp = null;
		resp = cxpHelper.getOrderReviewDetails(gqlRequest);
		return resp;
	}

	/**
	 *
	 * @param addTruckRollCartUIResponse
	 * @return
	 */
	public GetOrderDetailsGQLRequest getOrderDetailsGQLRequest(AddTruckRollCartUIResponse addTruckRollCartUIResponse) {
		logger.info("In getOrderDetailsGQLRequest of FiveGhomeCommonHelper");
		GetOrderDetailsGQLRequest gqlReq = new GetOrderDetailsGQLRequest();
		Optional.ofNullable(addTruckRollCartUIResponse).map(AddTruckRollCartUIResponse::getServiceBody).map(AddTruckRollCartUIResponseServiceBody::getServiceResponse)
				.map(AddTruckRollCartServiceResponse::getContext).map(AddTruckRollCartResponseContext::getCartInfo).filter(Objects::nonNull).ifPresent(addTruckRollCartResponseContextCartInfo -> {
					gqlReq.setCartId(addTruckRollCartResponseContextCartInfo.getCartId());
				});
		return gqlReq;
	}

	/**
	 *
	 * @param addTruckRollCartUIRequest
	 * @param request
	 * @return
	 * @throws JsonProcessingException
	 */
	public Mono<AddTruckRollCartUIResponse> addTruckRollCart(AddTruckRollCartUIRequest addTruckRollCartUIRequest, ServerHttpRequest request) throws JsonProcessingException {
			return bpmHelper3.addTruckRollCart(addTruckRollCartUIRequest, request);
	}

	/**
	 *
	 * @param updateTruckRollCartUIRequest
	 * @param request
	 * @return
	 * @throws JsonProcessingException
	 */
	public Mono<AddTruckRollCartUIResponse> updateTruckRollCart(AddTruckRollCartUIRequest updateTruckRollCartUIRequest, ServerHttpRequest request) throws JsonProcessingException {
		return bpmHelper3.updateTruckRollCart(updateTruckRollCartUIRequest, request);

	}

	/**
	 *
	 * @param intendType
	 */
	public void updateIntendTypeInredis(String intendType) {
		try {
			redisHelper3.setIntendTypeInRedis(intendType)
					.doOnSuccess(onSuccess -> logger.info("intendType is updated in redis..."))
					.doOnError(error -> logger.info("Exception in updating intendType  to redis..."));
		} catch (Exception e) {
			logger.info("Exception in updating intendType to redis : {}", e.getMessage());
		}
	}

	/**
	 *
	 * @param lineInfo1
	 * @param response
	 */
	public void populateAppointmentDetails(CXPLineInfo lineInfo1, GetCartDetailsUIResponse response) {
		if (null != lineInfo1.getServiceInfo().getCart5GAppointment()) {
			onevz.soe.cart.model.retrieveCart.Cart5GAppointment cart5GAppointment = lineInfo1.getServiceInfo().getCart5GAppointment();
			onevz.soe.cart.model.retrieveCart.fiveG.Cart5GAppointment cart5Gappointment = new onevz.soe.cart.model.retrieveCart.fiveG.Cart5GAppointment();
			if (null != cart5GAppointment.getInstallApptSelectedDate()) {
				InstallApptSelectedDate installApptSelectedDate = cart5GAppointment.getInstallApptSelectedDate();
				populateProfInstallDates(installApptSelectedDate,cart5Gappointment);
				populateSelfInstallDates(installApptSelectedDate,cart5Gappointment);

			}

			response.setCart5GAppointment(cart5Gappointment);
		}
		if (null != lineInfo1.getServiceInfo().getCart5GAddress()) {
			response.setCart5GAddress(lineInfo1.getServiceInfo().getCart5GAddress());
		}
		populatePromotions(lineInfo1, response);
	}

	private void populatePromotions(CXPLineInfo lineInfo1, GetCartDetailsUIResponse response) {
		boolean fwaFlag = featureFlag.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_ASSISTED,
				FeatureFlagConstants.OFFERS_CFG_PROFILE, FeatureFlagConstants.FWA_CHOICE_OFFER_FFLAG, false);
		if (fwaFlag && null != lineInfo1.getMtnDetails() && null != lineInfo1.getMtnDetails().getLineNumber()) {
			List<Promotions> promotions = response.getPromotions() != null ? response.getPromotions() : new ArrayList<>();
			Promotions promotion = new Promotions();
			promotion.setMtn(lineInfo1.getMtnDetails().getLineNumber());
			if(null != lineInfo1.getPromoIntent())
				promotion.setPromoIntent(lineInfo1.getPromoIntent());
			if(null != lineInfo1.getServiceInfo()){
				if(CollectionUtilities.isNotEmptyOrNull(lineInfo1.getServiceInfo().getSbdOffer())){
					promotion.setSbdOffer(lineInfo1.getServiceInfo().getSbdOffer());
				}
				if(null != lineInfo1.getServiceInfo().getThirdPartyOffer()){
					promotion.setThirdPartyOffer(lineInfo1.getServiceInfo().getThirdPartyOffer());
				}
			}
			promotions.add(promotion);
			response.setPromotions(promotions);
		}
	}

	/**
	 *
	 * @param installApptSelectedDate
	 * @param cart5Gappointment
	 */
	private void populateSelfInstallDates(InstallApptSelectedDate installApptSelectedDate, onevz.soe.cart.model.retrieveCart.fiveG.Cart5GAppointment cart5Gappointment) {
		if (null != installApptSelectedDate.getSelfInstallDate()) {
			try {
				Date installDate = new SimpleDateFormat(CartConstants.CXP_DATE_FORMAT).parse(installApptSelectedDate.getSelfInstallDate());
				DateFormat dateFormat = new SimpleDateFormat(CartConstants.SOE_DATE_FORMAT);
				cart5Gappointment.setSelfInstallDate(dateFormat.format(installDate));

			} catch (ParseException e) {
				logger.error(e.getMessage());
			}
		}
	}

	/**
	 *
	 * @param installApptSelectedDate
	 * @param cart5Gappointment
	 */
	private void populateProfInstallDates(InstallApptSelectedDate installApptSelectedDate, onevz.soe.cart.model.retrieveCart.fiveG.Cart5GAppointment cart5Gappointment) {
		if (null != installApptSelectedDate.getAvailableDate()) {
			try {
				Date installDate = new SimpleDateFormat(CartConstants.CXP_DATE_FORMAT).parse(installApptSelectedDate.getAvailableDate());
				DateFormat dateFormat = new SimpleDateFormat(CartConstants.SOE_DATE_FORMAT);
				cart5Gappointment.setProfInstallDate(dateFormat.format(installDate));

				Date slotStartTime = new SimpleDateFormat("HHMM").parse(installApptSelectedDate.getSlotStartTime());
				DateFormat timeFormat = new SimpleDateFormat("hh:mm aa");
				cart5Gappointment.setSlotStartTime(timeFormat.format(slotStartTime));
				cart5Gappointment.setSlotEndTime(timeFormat.format(DateUtils.addHours(slotStartTime, Integer.parseInt(installApptSelectedDate.getSlotLength()))));

			} catch (ParseException e) {
				logger.error(e.getMessage());
			}
		}
	}

	/**
	 * populate AEM Registration Details
	 * @param lineInfo1
	 * @param response
	 * @param isNSEFlow
	 * @param amRegisterationDetails
	 */
	public void populateAEMRegistrationDetails(CXPLineInfo lineInfo1, GetCartDetailsUIResponse response, boolean isNSEFlow, AMRegisterationDetails amRegisterationDetails) {
	if (null != lineInfo1.getServiceInfo().getPrimaryUserInfo()) {
		response.setPrimaryUserInfo(lineInfo1.getServiceInfo().getPrimaryUserInfo());
		if (isNSEFlow && StringUtils.isNotBlank(lineInfo1.getServiceInfo()
				.getPrimaryUserInfo().getEmailId()))
			amRegisterationDetails.setEmailId(security5GUtil.RPSAES128CBCEncrypt(lineInfo1.getServiceInfo().getPrimaryUserInfo().getEmailId()));
	}
	}

	/**
	 * customerProfileForNSE details for combo
	 * @param customerProfileForNSE
	 * @param response
	 *
	 */

	public void populateComboForRetriveCallDetails(CustomerProfileForNSE customerProfileForNSE,
			GetCartDetailsUIResponse response) {
		if (null != customerProfileForNSE) {
			response.setCustomerProfileForNSE(customerProfileForNSE);
		}
	}


	/**
	 * populate Security Deposit
	 * @param list
	 * @param orderDetailsView
	 */
	public void populateSecurityDeposit(List<OrderList> list, CXPOrderDetailsView orderDetailsView) {
		/* VZWDHM-471 fwaSecurityDepositAmount - either we get it from cxp or not we will send it UI as empty */
		if(null != list && !list.isEmpty()) {
			for (OrderList lt : list) {
				if (lt.getCreditApplication() != null && StringUtils.isNotBlank(lt.getCreditApplication().getFwaSecurityDepositAmount())) {
					orderDetailsView.setFwaSecurityDepositAmount(lt.getCreditApplication().getFwaSecurityDepositAmount());
				} else {
					orderDetailsView.setFwaSecurityDepositAmount("");
				}
			}
		}
	}

	/**
	 * populate EUP Details
	 * @param isEupFlow
	 * @param response
	 * @param lineDetails
	 */
	public void populateEUPDetails(AtomicBoolean isEupFlow, GetCartDetailsUIResponse response, CXPLineDetailsVO lineDetails) {
		if(isEupFlow.get()) {
			Arrays.stream(lineDetails.getLineInfo()).filter(Objects::nonNull).findFirst().ifPresent(lineInfo1 -> {
				EUPDetails eupDetails = new EUPDetails();
				eupDetails.setEquipmentUpgradeTitle("Equipment Upgrade");
				eupDetails.setMtnTitle("MTN");
				eupDetails.setEquipmentUpgradeValue(lineInfo1.getMobileNumber());
				response.setEupDetails(eupDetails);
			});
		}
	}

	/**
	 * populate AutoPay Promo
	 * @param autoPayPromoKey
	 * @param selectedFeaturesList
	 * @param featuresCount
	 * @param hiddenPromoList
	 */
	public void populateAutoPayPromo(String autoPayPromoKey, SelectedFeaturesList selectedFeaturesList, int featuresCount, List<String> hiddenPromoList) {
		if (!hiddenPromoList.contains(autoPayPromoKey) && null != selectedFeaturesList && featuresCount > 1) {
			VisFeature visFeature1 = selectedFeaturesList.getVisFeature().stream().filter(Objects::nonNull).filter(visFeature ->
					"SPO".equalsIgnoreCase(visFeature.getType()) && "L".equalsIgnoreCase(visFeature.getLevel())
							&& visFeature.getCategoryCodes().contains("AUTOPAY")).findFirst().orElse(null);
			if (visFeature1 != null) {
				hiddenPromoList.add(autoPayPromoKey);
			}
		}
	}

	/**
	 * populate Accessory Details
	 * @param lineInfo
	 * @param dueTodayList
	 */
	public void populateAccessoryDetails(CXPLineInfo[] lineInfo, List<CXPDueItemsList> dueTodayList) {
		AtomicBoolean isTanglewoodDevice = new AtomicBoolean(false);
		isTanglewoodDevice.set(dueTodayList.stream().filter(Objects::nonNull).anyMatch(cxpDueItemsList -> "DEVICE".equalsIgnoreCase(cxpDueItemsList.getItemType()) && "tgw".equalsIgnoreCase(cxpDueItemsList.getNetworkBandwidthType())));
		Arrays.stream(lineInfo).filter(Objects::nonNull).forEach(lineInfo1 -> {
			Arrays.stream(lineInfo1.getItemsInfo()).filter(Objects::nonNull).forEach(itemsInfo -> {
				Optional.ofNullable(itemsInfo).map(CXPItemInfo::getCartItems).ifPresent(cartItems -> {
					Arrays.stream(cartItems.getCartItem()).filter(Objects::nonNull).filter(cartItem -> {
								boolean isAccessory = "ACCESSORY".equalsIgnoreCase(cartItem.getCartItemType());
								boolean bundleIdValid = StringUtilities.isNotEmptyOrNull(cartItem.getBundleProductId());
								return !(isAccessory && bundleIdValid && !isTanglewoodDevice.get()) && (isAccessory && (!bundleIdValid || isTanglewoodDevice.get()));
							})
							.forEach(itemsInfo1 -> {
								dueTodayList.add(commonUtil.formatDueTodayItems(itemsInfo1, lineInfo1));
							});
				});
			});
		});
	}
	public void setWhwBasicDetails(String lineActivityType, CXPOrderDetails cxpOrderDetails1,CXPLineInfo lineInfo, List<CXPDueItemsList> dueTodayList) {
			if (lineInfo.getServiceInfo() != null && lineInfo.getServiceInfo().getSelectedFeaturesList() != null && lineInfo.getServiceInfo().getSelectedFeaturesList().getFeaturesCount() > 1 && !isWHWFlowType(cxpOrderDetails1,lineActivityType)) {
				lineInfo.getServiceInfo().getSelectedFeaturesList().getVisFeature().stream().filter(Objects::nonNull).filter(visFeature ->
						"A".equalsIgnoreCase(visFeature.getAddDeleteInd()) && "FOM".equalsIgnoreCase(visFeature.getSource())
								&& visFeature.getCategoryCodes().stream().anyMatch(str -> str.equalsIgnoreCase(CartConstants.ITEMTYPE_WHWBASIC))).findFirst().ifPresent(visFeature -> {
					CXPDueItemsList whwbasicItem = new CXPDueItemsList();
					whwbasicItem.setItemType(CartConstants.ITEMTYPE_WHWBASIC);
					whwbasicItem.setProductId(visFeature.getVisFeatureCode());
					whwbasicItem.setActualAmount(visFeature.getFeaturePrice());
					whwbasicItem.setTotalAmountWithDiscount(visFeature.getFeatureDiscPrice());
					whwbasicItem.setName(visFeature.getFeatureDesc());
					whwbasicItem.setQuantity(String.valueOf(visFeature.getQuantity()));
					if(visFeature.getAttributeNameValue()!=null && visFeature.getAttributeNameValue().getNameValue() != null) {
						whwbasicItem.setAdditionalAttributes(visFeature.getAttributeNameValue().getNameValue());
					}
					dueTodayList.add(whwbasicItem);
				});
			}else if (lineInfo.getServiceInfo() != null && lineInfo.getServiceInfo().getSelectedFeaturesList() != null && lineInfo.getServiceInfo().getSelectedFeaturesList().getFeaturesCount() > 1 && isWHWFlowType(cxpOrderDetails1,lineActivityType)) {
			lineInfo.getServiceInfo().getSelectedFeaturesList().getVisFeature().stream().filter(Objects::nonNull).filter(visFeature ->
					"A".equalsIgnoreCase(visFeature.getAddDeleteInd()) && visFeature.getCategoryCodes().stream().anyMatch(str -> str.equalsIgnoreCase(CartConstants.ITEMTYPE_WHWBASIC))).findFirst().ifPresent(visFeature -> {
				CXPDueItemsList whwbasicItem = new CXPDueItemsList();
				whwbasicItem.setItemType(CartConstants.ITEMTYPE_WHWBASIC);
				whwbasicItem.setProductId(visFeature.getVisFeatureCode());
				whwbasicItem.setActualAmount(visFeature.getFeaturePrice());
				whwbasicItem.setTotalAmountWithDiscount(visFeature.getFeatureDiscPrice());
				whwbasicItem.setName(visFeature.getFeatureDesc());
				if(visFeature.getAttributeNameValue() != null && visFeature.getAttributeNameValue().getNameValue() != null && visFeature.getAttributeNameValue().getNameValue().get(0).getProductAttributeValue() != null && visFeature.getAttributeNameValue().getNameValue().size() >0){
					whwbasicItem.setQuantity(visFeature.getAttributeNameValue().getNameValue().get(0).getProductAttributeValue());
				}
				if(visFeature.getAttributeNameValue()!=null && visFeature.getAttributeNameValue().getNameValue() != null) {
					whwbasicItem.setAdditionalAttributes(visFeature.getAttributeNameValue().getNameValue());
				}
				dueTodayList.add(whwbasicItem);
			});
		}
	}
	//Add WHW offer deatils for Accessory redemption
	public void populateAccessoryOffers(CXPLineInfo lineInfo, CXPOrderDetails cxpOrderDetails1, String lineActivityType, List<CurrentProfileSPO> currentProfileSPOList, List<CXPDueItemsList> dueTodayList ) {
		if(currentProfileSPOList != null
				&& CartConstants.ACC.equalsIgnoreCase(lineActivityType)
				&& cxpOrderDetails1 != null && cxpOrderDetails1.getFlowType() != null && CartConstants.FLOW_TYPE_WHW.equalsIgnoreCase(cxpOrderDetails1.getFlowType())) {
			currentProfileSPOList.stream().filter(Objects::nonNull).filter(spoOffer -> spoOffer.getSpoId().equals(whwSPOId) || spoOffer.getSpoId().equals(whwplusSPOId)).findFirst().ifPresent(spoOffer -> {
				CXPDueItemsList whwOfferDetails = new CXPDueItemsList();
				if(spoOffer.getSpoId().equals(whwSPOId)){
					whwOfferDetails.setItemType(CartConstants.ITEMTYPE_WHWBASIC);
				}
				if(spoOffer.getSpoId().equals(whwplusSPOId)){
					whwOfferDetails.setItemType(CartConstants.ITEMTYPE_WHWPLUS);
				}
				whwOfferDetails.setProductId(spoOffer.getSpoId());
				whwOfferDetails.setActualAmount(spoOffer.getPrice());
				whwOfferDetails.setTotalAmountWithDiscount(spoOffer.getFinalPrice());
				whwOfferDetails.setQuantity(String.valueOf(getAccessoryQunatity(lineInfo)));
				dueTodayList.add(whwOfferDetails);
			});
		}
	}
	// find Quantity for redemption
	public int getAccessoryQunatity(CXPLineInfo lineInfo){
		quantity =0;
		if(lineInfo != null) {
			Arrays.stream(lineInfo.getItemsInfo()).filter(Objects::nonNull).forEach(itemsInfo -> {
					Optional.ofNullable(itemsInfo).map(CXPItemInfo::getCartItems).ifPresent(cartItems -> {
						Arrays.stream(cartItems.getCartItem()).filter(Objects::nonNull).filter(cartItem -> {

							boolean accessoryItem = CartConstants.ACCESSORY_SORID.equalsIgnoreCase(cartItem.getSorId()) &&
									CartConstants.ITEMTYPE_ACCESSORY.equalsIgnoreCase(cartItem.getCartItemType());
							return (accessoryItem);
						}).forEach(itemInfo -> {
							if (itemInfo.getQty() != null)
								quantity = itemInfo.getQty();
						});
					});
				});
		}
		return quantity;
	}
	public boolean isWHWFlowType(CXPOrderDetails cxpOrderDetails1, String lineActivityType){
		if(cxpOrderDetails1.getFlowType() != null && CartConstants.FLOW_TYPE_WHW.equalsIgnoreCase(cxpOrderDetails1.getFlowType())
				&& StringUtilities.isNotEmptyOrNull(lineActivityType) && CartConstants.FEA.equalsIgnoreCase(lineActivityType)){
			return true;
		}
		return false;
	}

	public boolean isWWMFlowType(CXPOrderDetails cxpOrderDetails1, String lineActivityType){
			if (cxpOrderDetails1.getFlowType() != null
					&& CartConstants.FLOW_TYPE_FWA_UPGRADE.equalsIgnoreCase(cxpOrderDetails1.getFlowType())
					&& StringUtilities.isNotEmptyOrNull(lineActivityType)
					&& CartConstants.EUP_5G.equalsIgnoreCase(lineActivityType)
			) {
				return true;
			}
			return false;
	}

	/**
	 * Populate a field in orderDetailsview if Order contains any of the FWASweetner offers.
	 * @param orderDetailsView
	 * @param itemsInfo1
	 */
	public void validateFWASweetnerDealInOrder(CXPOrderDetailsView orderDetailsView, CXPCartItem itemsInfo1) {

		if(itemsInfo1.getRebateOffers()!= null && CollectionUtilities.isNotEmptyOrNull(itemsInfo1.getRebateOffers())) {
			itemsInfo1.getRebateOffers().forEach(rebateData -> {
				if( StringUtils.isNotBlank(rebateData.getPlatformPromoType()) && rebateData.getPlatformPromoType().equalsIgnoreCase(CartConstants.PLATFORM_TYPE) && StringUtils.isNotBlank(rebateData.getBarcodeId())){
					orderDetailsView.setFwaSWOfferApplied(true);
				}
			});
		}

	}


	/**
	 *
	 * @param rData
	 * @return
	 */
	public Mono<String> upsertFwaSafeTechSessionId(String rData) {
		if(StringUtilities.isEmptyOrNull(rData)) {
			String randomAlphanumericValue = UUID.randomUUID().toString().replaceAll("-", "").substring(0, 24);;
			//adding condition for WHW scenario for Defect PRODDEF-30765
			String safeTechSessionIdKeyName = sessionBean.isFWADigitalFlow()?CartConstants.FWA_SAFE_TECH_SESSION_ID_KEY:CartConstants.SAFETECH_SESSION_ID;
			return sessionBean.setSessionData(safeTechSessionIdKeyName, randomAlphanumericValue).flatMap(data->{
				return Mono.just(randomAlphanumericValue);
			});
		}
		return Mono.just("");
	}



	/**
	 *isFWAFlow
	 * @param flowNameHeader
	 * @return
	 */
	public boolean isFWAFlow(String flowNameHeader) {
		if (StringUtilities.isNotEmptyOrNull(flowNameHeader)) {
			return fwaFlowNameIdentifiers.stream().anyMatch(flowNameHeader::contains);
		}
		return false;
	}

	public String getDigitalCustomerTypeFromCart(CustomerProfile customerProfile) {
		if(customerProfile != null && customerProfile.getCustomerAttributes() !=null) {
			return customerProfile.getCustomerAttributes().getDigitalCustomerType();
		}
		return StringUtils.EMPTY;
	}
}
