package onevz.soe.cart.helper;


import onevz.soe.cart.model.flexVtwo.SessionResponse;
import onevz.soe.cart.model.retrieveCart.CXPCartItem;
import onevz.soe.cart.model.retrieveCart.CXPLineInfo;
import onevz.soe.cart.model.saveCart.AddressInfo;
import onevz.soe.cart.model.saveCart.CartDetails;
import onevz.soe.cart.model.saveCart.UpdateLead;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.ui.common.CartInfo;
import onevz.soe.cart.util.FlexV2Util;
import onevz.soe.customerprofile.model.gql.assisted.Address;
import onevz.soe.customerprofile.model.gql.assisted.Customer;
import onevz.soe.customerprofile.model.gql.assisted.CustomerName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import onevz.soe.cart.bpm.helper.CartServiceBpmHelper;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper2;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper3;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.ui.requests.SaveCartForLaterUIRequest;
import onevz.soe.cart.ui.requests.SaveCartUIRequest;
import onevz.soe.cart.ui.responses.SaveCartUIResponse;
import onevz.soe.cart.util.CartUtil;
import onevz.soe.cradle.CradleAllocator;
import onevz.soe.omnidl.service.OmniDLService;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.utilities.StringUtilities;
import org.springframework.util.ObjectUtils;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


@Service
public class SaveCartHelper {

	@Autowired
	CartServiceCxpHelper cxpHelper;

	@Autowired
	Environment env;

	@Autowired
	private CartServiceBpmHelper bpmHelper;
	
	@Autowired
	private CartServiceBpmHelper2 bpmHelper2;
	
	@Autowired
	private CartServiceBpmHelper3 bpmHelper3;

	@Autowired
	private RedisHelper redisHelper;

	@Autowired
	SOELoginSessionBean sessionBean;

	@Autowired
	CradleAllocator cradleAllocator;

    @Autowired
    OmniDLService dlService;

	@Autowired
	CartIntendTypeBuilder cartIntendTypeBuilder;

	@Value("${viewQrCode:true}")
	private boolean viewQrCode;

	@Value("${compareQuotePdfEnabled:true}")
	private boolean compareQuotePdfEnabled;

	@Value("${quoteLowerBillEnabled:true}")
	private boolean quoteLowerBillEnabled;

	private static final Logger logger = LoggerFactory.getLogger(SaveCartHelper.class);

	/**
	 * @param request
	 * @return SaveCartUIResponse
	 */
	public Mono<SaveCartUIResponse> saveCart(SaveCartUIRequest request) {
		String channelType = CartUtil.getChannelType(request.getChannelId());
		return redisHelper.getDataFromRedis().flatMap(data -> {
			boolean isFlexv2= request.getCartInfo().isFlexV2();
			if (!CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType()) && !CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType()) && StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				request.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				request.getCartInfo().setCartId(data.getCartId());

			if (isFlexv2)
				populateFlexv2RequestFields(request, data);

			if(CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())){
				if(StringUtilities.isNotEmptyOrNull(data.getMtnFlow())){
					request.getCartInfo().setMtnFlow(data.getMtnFlow());
				}
			}
			else if (StringUtilities.isEmptyOrNull(request.getCartInfo().getCartId())) {
				return Mono.just(new SaveCartUIResponse());
			}
			if (null!= request.getEnforceData() && StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.DIGITAL) && null != env.getProperty("passSafeTechSessionIdToPega")
					&& Boolean.parseBoolean(env.getProperty("passSafeTechSessionIdToPega")) && StringUtilities.isNotEmptyOrNull(data.getSafeTechSessionId())) {
					request.setSafeTechSessionId(data.getSafeTechSessionId());
			}
			if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED) && (CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType()) || CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())) && StringUtilities.isNotEmptyOrNull(data.getCreditAppNum())) {
					request.getCartInfo().setCreditAppNum(data.getCreditAppNum());
					request.getCartInfo().setCartCreator(data.getCreditAppNum());
			}

			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				request.getCartInfo().setCaseId(data.getCaseId());
			if (!CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType()) && !CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType()) && StringUtilities.isNotEmptyOrNull(data.getMtn()))
				request.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessingMTN()))
				request.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (!CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType()) && !CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType()) && StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				request.getCartInfo().setCartCreator(data.getCartCreator());
			if (null != data.getIsDirectApply()) {
				request.getCartInfo().setIsDirectApply(data.getIsDirectApply());
			}
			if (StringUtilities.isNotEmptyOrNull(data.getRepId())) {
				request.getCartInfo().setRepId(data.getRepId());
			}
			if (StringUtilities.isNotEmptyOrNull(data.getStoreName())) {
				request.getCartInfo().setStoreName(data.getStoreName());
			}
			if (StringUtilities.isNotEmptyOrNull(data.getLoggedInUser())) {
				request.getCartInfo().setLoggedInUser(data.getLoggedInUser());
			}

			if(request.getData() != null && request.getData().getCompareQuotePdfEnabled() == null) {
				request.getData().setCompareQuotePdfEnabled(compareQuotePdfEnabled);
			}

			if(request.getData() != null && request.getData().getQuoteLowerBillEnabled() == null) {
				request.getData().setQuoteLowerBillEnabled(quoteLowerBillEnabled);
			}

			if(request.getData() != null && request.getData().getViewQrCode() == null) {
				request.getData().setViewQrCode(viewQrCode);
			}
			if(StringUtilities.isEmptyOrNull(request.getCartInfo().getSaveCartEmailId()) && StringUtilities.isNotEmptyOrNull(data.getSaveCartEmailId())){
				request.getCartInfo().setSaveCartEmailId(data.getSaveCartEmailId());
			}
			if(data.getQuotePricingValues() != null && data.getQuotePricingValues().getQuotePrices() != null
					&& data.getQuotePricingValues().getQuotePrices().size() > 1 && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getSaveCartEmailId())
					&& CartConstants.NSE.equals(request.getCartInfo().getIntendType())) {

				Flux<SaveCartUIResponse> saveCartResponseFlux = Flux.fromIterable(data.getQuotePricingValues().getQuotePrices()).flatMap(quotePrice -> {
					logger.info("savecart for Quotes/sharedcart");
					request.getCartInfo().setCartId(quotePrice.getCartId());
					request.getCartInfo().setCaseId(quotePrice.getCaseId());
					request.getCartInfo().setQuoteId(quotePrice.getQuoteId());
					return bpmHelper2.saveCart(request);
				});
				return saveCartResponseFlux.collectList().flatMap(saveCartUIResponseList ->
					Mono.just(saveCartUIResponseList.get(saveCartUIResponseList.size()-1))
				);
			} else {
				logger.info("savecart for sharedcart");
				return bpmHelper2.saveCart(request);
			}
		});
	}

	/**
	 * @param request
	 * @return SaveCartUIResponse
	 */
	public Mono<SaveCartUIResponse> saveCartForLater(SaveCartForLaterUIRequest request) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				request.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				request.getCartInfo().setCartId(data.getCartId());
			else if (StringUtilities.isEmptyOrNull(request.getCartInfo().getCartId())) {
				return Mono.just(new SaveCartUIResponse());
			}
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				request.getCartInfo().setCaseId(data.getCaseId());
			if (StringUtilities.isNotEmptyOrNull(data.getMtn()))
				request.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessingMTN()))
				request.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				request.getCartInfo().setCartCreator(data.getCartCreator());
			if (StringUtilities.isNotEmptyOrNull(data.getIntendType())) {
				request.getCartInfo().setIntendType(data.getIntendType());
			}
			return bpmHelper3.saveCartForLater(request);
		});
	}

	private void populateFlexv2RequestFields(SaveCartUIRequest request, CartRedisData data) {
		if(StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType()))
		{
				SessionResponse sessionResponse = new SessionResponse();
				FlexV2Util.updateSessionResponseData(data, sessionResponse);

				CartInfo cartInfo = request.getCartInfo();
				cartIntendTypeBuilder.updateSaveCartIntendType(sessionResponse, cartInfo);

		}
		if(null!= data.getCustomerProfile()&& null!= data.getCustomerProfile().getData()
				&& null!= data.getCustomerProfile().getData().getCustomer()) {
			populateCustomerDetails(request, data);
		}
		populateUpdateLead(request, data);
	}

	private void populateUpdateLead(SaveCartUIRequest request, CartRedisData data) {
		if (null!= request.getData() && null!= request.getData().getUpdateLead()) {
			UpdateLead updLead = request.getData().getUpdateLead();

			populateOtherUpdLead(request, data, updLead);
			if (ObjectUtils.isEmpty(updLead.getCartDetails())) {
				populateCartDetails(request, data);
			}
			populateLeadType(request, updLead);
		}
	}

	private void populateOtherUpdLead(SaveCartUIRequest request, CartRedisData data, UpdateLead updLead) {
		if (StringUtilities.isEmptyOrNull(updLead.getStoreId()) &&
				StringUtilities.isNotEmptyOrNull(data.getLocationCode())) {
			updLead.setStoreId(data.getLocationCode());
		}
		if (StringUtilities.isEmptyOrNull(updLead.getEventCategory()) && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())) {
			updLead.setEventCategory(request.getCartInfo().getIntendType());
		}
		if(StringUtilities.isEmptyOrNull(updLead.getLeadOwner()) && StringUtilities.isNotEmptyOrNull(data.getLoggedInUser()))
			updLead.setLeadOwner(data.getLoggedInUser());

		if(StringUtilities.isEmptyOrNull(updLead.getECode()) && StringUtilities.isNotEmptyOrNull(data.getRepId())) {
			updLead.setECode(data.getRepId());
		}
	}

	private void populateLeadType(SaveCartUIRequest request, UpdateLead updLead) {
		if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()) &&
				StringUtilities.isEmptyOrNull(updLead.getLeadType())){
			if(request.getCartInfo().getIntendType().equalsIgnoreCase(CartConstants.NSE))
				updLead.setLeadType(CartConstants.PROSPECT_CART);
			else
				updLead.setLeadType(CartConstants.CUSTOMER_CART);
		}
	}
	private void populateCustomerDetails(SaveCartUIRequest request, CartRedisData data) {
		Customer customer = data.getCustomerProfile().getData().getCustomer();

		if (null != customer.getCustomerName() && StringUtilities.isEmptyOrNull(request.getData().getCustomerName())) {
			CustomerName custName = customer.getCustomerName();
			String firstName = null!=custName.getFirstName()?custName.getFirstName() + " " :"";
			String lastName = null!=custName.getLastName()?custName.getLastName():"";
			request.getData().setCustomerName(firstName.concat(lastName));
		}
		if(null!=customer.getAddress()){
			Address cartAddress = customer.getAddress();
			populateAddress(request, cartAddress);
			if(StringUtilities.isEmptyOrNull(request.getData().getZipCode()) && null!=cartAddress.getZipCode()) {
				request.getData().setZipCode(cartAddress.getZipCode());
			}
		}
	}

	private void populateAddress(SaveCartUIRequest request, Address cartAddress) {
		if(null!= request.getData().getUpdateLead() && ObjectUtils.isEmpty(request.getData().getUpdateLead().getAddressInfo())) {
			AddressInfo addressInfo = new AddressInfo();
			addressInfo.setState(null!= cartAddress.getState()? cartAddress.getState():"");
			addressInfo.setCity(null!= cartAddress.getCity()? cartAddress.getCity():"");
			addressInfo.setAddressLine1(null!= cartAddress.getAddressLine1()? cartAddress.getAddressLine1():"");
			addressInfo.setAddressLine2(null!= cartAddress.getAddressLine2()? cartAddress.getAddressLine2():"");
			request.getData().getUpdateLead().setAddressInfo(addressInfo);
		}
	}

	private void populateCartDetails(SaveCartUIRequest request, CartRedisData data) {

		if(null!=(data.getRetrieveCart()) && FlexV2Util.isCartHasLine(data.getRetrieveCart()))
		{
			List<CartDetails> finalCartDetails= new ArrayList<>();
			Arrays.stream(data.getRetrieveCart().getCart().getLineDetails().getLineInfo()).forEach(item -> {
				String mtn =(null!=item.getMtnDetails() && null != item.getMtnDetails().getMobileNumber()) ? item.getMtnDetails().getMobileNumber() : "";
				String planCode;
				if(null!=item.getServiceInfo() && null!=item.getServiceInfo().getNewPricePlanInfo())
				{
					planCode = (null != item.getServiceInfo().getNewPricePlanInfo().getPricePlanCode())?
							item.getServiceInfo().getNewPricePlanInfo().getPricePlanCode() : "";
				} else {
					planCode = "";
				}
				List<CartDetails> temp = new ArrayList<>();
				getSessionCartDetails(data, item, temp, planCode, mtn, finalCartDetails);
			});
			request.getData().getUpdateLead().setCartDetails(finalCartDetails);
		}

	}

	private void getSessionCartDetails(CartRedisData data, CXPLineInfo item, List<CartDetails> temp, String planCode, String mtn, List<CartDetails> finalCartDetails) {
		if (null != item.getItemsInfo()) {
			Arrays.stream(item.getItemsInfo()).forEach(itemdetails -> {
				if (null != itemdetails.getCartItems() && null != itemdetails.getCartItems().getCartItem()) {
					Arrays.stream(itemdetails.getCartItems().getCartItem())
							.filter(itemType->(CartConstants.DEVICE.equalsIgnoreCase(itemType.getCartItemType()) ||
									CartConstants.ACCESSORY.equalsIgnoreCase(itemType.getCartItemType()))&& temp.isEmpty()).forEach(cartItem ->
									populateRequestCartDetails(data, item, temp, planCode, mtn, finalCartDetails, cartItem)
							);
				}
			});
		}
	}

	private void populateRequestCartDetails(CartRedisData data, CXPLineInfo item, List<CartDetails> temp, String planCode, String mtn, List<CartDetails> finalCartDetails, CXPCartItem cartItem) {

		CartDetails cartDetails = new CartDetails();
		cartDetails.setDisplayName(cartItem.getDeviceDisplayName());
		cartDetails.setSorId(cartItem.getSorId());
		cartDetails.setLineActivityType(item.getLineActivityType());
		cartDetails.setProductId(null != cartItem.getProductId() ? cartItem.getProductId() : "");
		cartDetails.setGeneratedChannel(data.getRetrieveCart().getCart().getCartHeader().getSourceSystem());
		cartDetails.setReqPlanCode(planCode);
		cartDetails.setMtn(mtn);
		temp.add(cartDetails);
		finalCartDetails.add(cartDetails);

	}

}
