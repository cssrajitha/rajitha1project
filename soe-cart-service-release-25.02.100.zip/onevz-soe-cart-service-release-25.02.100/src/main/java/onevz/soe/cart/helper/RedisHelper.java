package onevz.soe.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.json.JsonSanitizer;
import onevz.aem.errorhandling.aem.model.CreditErrorContent;
import onevz.aem.errorhandling.service.CreditExceptionDatastoreClient;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.initiatecart.CpcFeatureResponse;
import onevz.soe.cart.model.addressQualificationSession.AddressValidationRespToSessionData;
import onevz.soe.cart.model.common.ConflictedSFOs;
import onevz.soe.cart.model.common.ConflictedSPOs;
import onevz.soe.cart.model.common.DeviceImeiSimDetails;
import onevz.soe.cart.model.createLine.HomeSalesAddress;
import onevz.soe.cart.model.deviceIdValidation.DeviceInfo;
import onevz.soe.cart.model.deviceIdValidation.SimInfo;
import onevz.soe.cart.model.session.PDMOfferData;
import onevz.soe.cart.model.tysPromos.PromoLine;
import onevz.soe.cart.model.retrieveCart.CXPRetrieveCartDataVO;
import onevz.soe.cart.requests.DualNumberRedisInfo;
import onevz.soe.cart.requests.RetrieveCartCXPRequest;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.ui.requests.AddFeaturesUIRequest;
import onevz.soe.cart.ui.requests.PlanTaggingDetails;
import onevz.soe.cart.util.CartPegaRequestErrorsUtil;
import onevz.soe.cart.util.CartUtil;
import onevz.soe.constants.SOEConstants;
import onevz.soe.customerprofile.response.CustomerProfileResponse;
import onevz.soe.fraud.client.SOEMtnExpireClient;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.session.constants.SessionConstants;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.utilities.serialization.JacksonMapperFactory;
import onevz.soe.wsclient.bpm.model.Context;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.io.IOException;
import java.util.*;

import static onevz.soe.cart.util.CartUtil.isFlexV2;

@Service
public class RedisHelper {

	public static final String ERROR_PARSING_JSON_TO_OBJECT = "Error parsing JSON to Object: {}";
	public static final String DATA_UPSERTED_INTO_REDIS_APP_NAME_CART_SERVICE = "Data upserted into Redis: {} | AppName: CartService";
	public static final String READING_RESTRICTED_PRODUCT_TYPE_REQUEST = "Reading restricted product type request:";
	public static final String UNABLE_TO_DELETE_FROM_REDIS = " Unable to delete from Redis {}";

	@Autowired
	CreditExceptionDatastoreClient creditDatastoreClient;

	@Autowired
	SOELoginSessionBean sessionBean;
	@Autowired
	private ObjectMapper mapper;

	@Value("${soe.digital.home.intendTypeKeys:intendType}")
	private List<String> homeIntendTypeKeys;
	@Value("${soe.digital.home.intendTypeValues:AAL_5G,AAL_LTE,NSE_5G,NSE_LTE,EUP_5G_REPAIR,AAL_CBD_TECH}")
	private List<String> homeIntendTypeValues;

	@Autowired
	SOEMtnExpireClient soeMtnExpireClient;

	@Autowired
	private RedisHelper2 redisHelper2;

	@Autowired
	private RedisHelper3 redisHelper3;

	private static final Logger logger = LoggerFactory.getLogger(RedisHelper.class);
	private static final String TOP_KEY = "credit-error";
	private static final String SUB_KEY = "credit-subkey";
	private static final String SUB_KEY_5G = "credit-5g-subkey";

	/**
	 *
	 * @return rr
	 */
	public Mono<CartRedisData> getDataFromRedis() {
		CartRedisData rr = new CartRedisData();
		return sessionBean
				.getSessionData(Arrays.asList(new String[] { SessionConstants.MTN_KEY,
						SessionConstants.ACCOUNT_NUMBER_KEY, CartConstants.CART_ID, CartConstants.CASE_ID,
						CartConstants.PROCESSING_MTN, CartConstants.CART_CREATOR, CartConstants.FIVEG_UPSELL,
						CartConstants.ADD_DEVICE_REQUEST, CartConstants.ADD_ACCESSORY_REQUEST,
						CartConstants.RESTRICTED_PRODUCT_TYPE, CartConstants.MTN_FLOW, CartConstants.CART_COUNT,
						CartConstants.CART_ORDER_FLOW_TYPE, CartConstants.LOCATION_CODE, CartConstants.VZW_ROLES,
						CartConstants.RPS_INTENT, CartConstants.INTEND_TYPE, CartConstants.STORE_LOCATION_STATE,
						CartConstants.BILLING_STATE, CartConstants.CUSTOMER_ADDRESS_STATE,
						CartConstants.LINELEVEL_DIGITALSECURE_SUBSCRIPTION_COUNT,
						CartConstants.BBP_ICCID,CartConstants.BBP_IMEI,CartConstants.IS_SMARTPHONE ,
						CartConstants.CREDIT_APP_NUM,CartConstants.DEVICETYPE_BBP,CartConstants.BBP_IMEI2,CartConstants.DEVID,CartConstants.EID,CartConstants.IS_PRE_QUALIFIED_NBX,
						CartConstants.COMPLETED_CARTID_CONST,CartConstants.COMPLETED_CASEID_CONST,CartConstants.INTENT_TOKEN_RESPONSE,CartConstants.VERIFIED_NAME,
						CartConstants.Z1_OFFER_CODE,CartConstants.SW_COUPON_CODE,CartConstants.DIGITAL_IG_SESSION,CartConstants.DEVICEID,CartConstants.SUCCESS_URL,CartConstants.VZPH_REMOVED,
						CartConstants.AUTO_PAY_ENROLLED,CartConstants.EXTERNALID,CartConstants.PROMO_MAX_COUNT, CartConstants.PROMO_VALID_MAX_COUNT,CartConstants.SAFETECH_SESSION_ID , CartConstants.IS_DIRECT_APPLY, CartConstants.REP_ID, CartConstants.STORE_NAME, CartConstants.LOGGEDINUSER,CartConstants.PROSPECT_CARTID,CartConstants.INTENT_TYPE
						,CartConstants.BOGO_MTN,CartConstants.PLAN_SIZE,CartConstants.IMEI,CartConstants.MUC,
						CartConstants.RFEX_EXCHANGE_SHOP_DETAILS,CartConstants.INTENT_REDIS,CartConstants.MARKET,CartConstants.PREORDERINSERVICEDATE,CartConstants.VZID,CartConstants.SPO_MTN,CartConstants.FIOS_AUTHENTICATED,CartConstants.EVENTCORRELATIONID,CartConstants.IS_VALID_CUSTOMER,CartConstants.ROLE,CartConstants.IS_PREPAY_CART,SessionConstants.UNIVERSALID,SessionConstants.UID,
						CartConstants.COMBO_MOBILITY_CART_ID,CartConstants.COMBO_MOBILITY_ORDER_ID,CartConstants.COMBO_MOBILITY_LOCATION_CODE,CartConstants.COMBO_MOBILITY_CREDITAPP_NUM,
						CartConstants.USER_ROLE,CartConstants.LINE_ACTIVITY_TYPE,
						CartConstants.REP_ROLE,CartConstants.PENDING_ICCID,CartConstants.ESIMTYPE,CartConstants.ESIMFLOWTYPE,CartConstants.PENDING_MDN,
						CartConstants.RELINQUISH_ACCOUNT_NUMBER,CartConstants.TYS_LINES_COUNT, CartConstants.PREPAY_CUSTOMER_TYPE,CartConstants.FLOW,CartConstants.COMPANION_PHONE_NUMBER,CartConstants.BRAND_NAME,CartConstants.CCAR_WIFI_STATE,CartConstants.QUOTE_PRICING,CartConstants.LOCATION_SUB_TYPE,CartConstants.SOR_ID,CartConstants.IS_COMMON_PDP,CartConstants.SELECTED_LINE_PROMOLIST,CartConstants.LANDING_MTN_HASHCODE,CartConstants.PLAN_SELECTION_PATH,
						CartConstants.IS_MYLINK_AVAILABLE_FLAG, CartConstants.MYLINK_HASH_KEY, CartConstants.RECOMMENDATIONS_DEVICE_SOR_ID, CartConstants.RECOMMENDATIONS_ACCESSORY_SOR_ID,CartConstants.CUSTOMER_PROFILE,CartConstants.RETRIEVE_CART_RESPONSE,CartConstants.CRADLE_FLOW_JOURNEY,
						CartConstants.REASON_FOR_VISIT,CartConstants.IS_HOME_SALES,CartConstants.HOME_SALES_ADDRESS,CartConstants.ISCOMBOORDERALLOWED,CartConstants.ADDRESS_QUALIFICATION_BY_MTN,CartConstants.FWA_CUSTOMERID_HASH,CartConstants.FWA_CUSTOMERMTN_HASH,CartConstants.FWA_ACCOUNTTYPE,CartConstants.LV_SOFTSKU,
						CartConstants.JOINT_TRANSACTION_MOBILE_CART_ID,CartConstants.JOINT_TRANSACTION_MOBILE_CASE_ID,CartConstants.HIGH_RISK_MTN_LIST,CartConstants.DUAL_NUMBER,CartConstants.BYOD_IMEI_DETAILS,CartConstants.FLOW_NAME, CartConstants.EXISTING_CASE,CartConstants.RETAIL_SCAN_AND_GO_DEPLETION_LOCATION_CODE, CartConstants.PDM_OFFER_RECOMMENDATIONS,CartConstants.RETAIL_TANGLEWOOD_SELECTED,CartConstants.PLAN_TAGGING_DETAILS,CartConstants.SAVE_CART_EMAILID,
						CartConstants.NPANXX_LIST,CartConstants.LGPO_ELIGIBLE_CUSTOMER,CartConstants.LGPO_SPO,CartConstants.IMSI,CartConstants.ICCID, CartConstants.RETURN_INDICATOR,CartConstants.UPC,CartConstants.PRICE_ID,CartConstants.REAL_AGENT_CODE,CartConstants.MAID,CartConstants.PAST_DUE}))
				.onErrorReturn(new HashMap<Object, Object>()).defaultIfEmpty(new HashMap<Object, Object>())
				.flatMap(data -> {
					Optional.ofNullable((String) data.get(CartConstants.NPANXX_LIST)).filter(StringUtilities::isNotEmptyOrNull).ifPresent(npaNxxStr -> {
						try {
							List<String> npaNxxList = JacksonMapperFactory.defaultReader().readValue(npaNxxStr, List.class);
							rr.setNpanxxlist(npaNxxList);
						} catch (IOException e) {
							logger.error(ERROR_PARSING_JSON_TO_OBJECT, e);
						}

					});
					if(data.containsKey(CartConstants.SW_COUPON_CODE))
						rr.setSwBarCodeId((String)data.get(CartConstants.SW_COUPON_CODE));
					if (data.containsKey(data.get(CartConstants.FWA_CUSTOMERID_HASH)))
						rr.setFwaCustomerIdHash((String)data.get(CartConstants.FWA_CUSTOMERID_HASH));
					if(data.containsKey(CartConstants.EXISTING_CASE))
						rr.setExistingCase((String)data.get(CartConstants.EXISTING_CASE));
					if(data.containsKey(CartConstants.SAVE_CART_EMAILID)){
						rr.setSaveCartEmailId((String)data.get(CartConstants.SAVE_CART_EMAILID));
					}
					if (data.containsKey(CartConstants.FWA_CUSTOMERMTN_HASH))
						rr.setFwaCustomerMdnHash((String)data.get(CartConstants.FWA_CUSTOMERMTN_HASH));
					if (data.containsKey(CartConstants.FWA_ACCOUNTTYPE))
						rr.setFwaAccountType((String)data.get(CartConstants.FWA_ACCOUNTTYPE));
					if (data.containsKey(CartConstants.CRADLE_FLOW_JOURNEY))
						rr.setCradleFlowJourney((String)data.get(CartConstants.CRADLE_FLOW_JOURNEY));
					if (data.containsKey(CartConstants.REP_ROLE))
						rr.setRepRole((String)data.get(CartConstants.REP_ROLE));
					if (data.containsKey(CartConstants.ESIMFLOWTYPE))
						rr.setEsimFlowType((String)data.get(CartConstants.ESIMFLOWTYPE));
					if (data.containsKey(CartConstants.PENDING_MDN))
						rr.setPendingMdn((String)data.get(CartConstants.PENDING_MDN));
					if (data.containsKey(CartConstants.IMEI)
							&& StringUtilities.isNotEmptyOrNull((String) data.get(CartConstants.IMEI))){
						rr.setImei((String) data.get(CartConstants.IMEI));
                        rr.setBbpImei((String) data.get(CartConstants.IMEI));
						logger.info("AFTER getDataFromRedis IMEI: {}",rr.getImei());
					}
					if (data.containsKey(CartConstants.ICCID)
							&& StringUtilities.isNotEmptyOrNull((String) data.get(CartConstants.ICCID))){
						rr.setIccid((String) data.get(CartConstants.ICCID));
						rr.setBbpIccid((String) data.get(CartConstants.ICCID));
						logger.info("AFTER getDataFromRedis ICCID: {}",rr.getIccid());
					}

					if (data.containsKey(CartConstants.Z1_OFFER_CODE))
						rr.setZ1OfferCode((String) data.get(CartConstants.Z1_OFFER_CODE));
					if (data.containsKey(CartConstants.ROLE))
						rr.setRole((String) data.get(CartConstants.ROLE));
					if (data.containsKey(CartConstants.IS_VALID_CUSTOMER) && data.get(CartConstants.IS_VALID_CUSTOMER) != null)
						rr.setIsValidCustomer(Boolean.valueOf((String) data.get(CartConstants.IS_VALID_CUSTOMER)));
					if (data.containsKey(CartConstants.SAFETECH_SESSION_ID))
						rr.setSafeTechSessionId((String) data.get(CartConstants.SAFETECH_SESSION_ID));
					if (data.containsKey(CartConstants.VZPH_REMOVED) && data.get(CartConstants.VZPH_REMOVED) != null)
						rr.setVzphRemoved((String) data.get(CartConstants.VZPH_REMOVED));
					if (data.containsKey(CartConstants.COMPLETED_CARTID_CONST) && data.get(CartConstants.COMPLETED_CARTID_CONST) != null) {
						rr.setCompletedCartId((String) data.get(CartConstants.COMPLETED_CARTID_CONST));
					}
					if (data.containsKey(CartConstants.COMPLETED_CASEID_CONST) && data.get(CartConstants.COMPLETED_CASEID_CONST) != null) {
						rr.setCompletedCaseId((String) data.get(CartConstants.COMPLETED_CASEID_CONST));
					}
					if(data.containsKey(CartConstants.VERIFIED_NAME))
						rr.setVerifiedName((String) data.get(CartConstants.VERIFIED_NAME));
					if (data.containsKey(SessionConstants.ACCOUNT_NUMBER_KEY) && data.get(SessionConstants.ACCOUNT_NUMBER_KEY) != null) {
						logger.info("reading accountNumber value from redis:..{}", data.get(SessionConstants.ACCOUNT_NUMBER_KEY));
						rr.setAccountNumber((String) data.get(SessionConstants.ACCOUNT_NUMBER_KEY));
					}
					if(data.containsKey(CartConstants.RETAIL_TANGLEWOOD_SELECTED))
						rr.setTanglewoodSelected((String)data.get(CartConstants.RETAIL_TANGLEWOOD_SELECTED));
					if (data.containsKey(SessionConstants.MTN_KEY))
						rr.setMtn((String) data.get(SessionConstants.MTN_KEY));
					if (data.containsKey(CartConstants.CART_ID))
						rr.setCartId((String) data.get(CartConstants.CART_ID));
					if (data.containsKey(CartConstants.RPS_INTENT))
						rr.setRpsIntent((String) data.get(CartConstants.RPS_INTENT));
					if (data.containsKey(CartConstants.CASE_ID))
						rr.setCaseId((String) data.get(CartConstants.CASE_ID));
					if (data.containsKey(CartConstants.PROCESSING_MTN))
						rr.setProcessingMTN((String) data.get(CartConstants.PROCESSING_MTN));
					if (data.containsKey(CartConstants.INTEND_TYPE))
						rr.setIntendType((String) data.get(CartConstants.INTEND_TYPE));
					if (data.containsKey(CartConstants.FIOS_AUTHENTICATED))
						rr.setFiosAuthenticated((String) data.get(CartConstants.FIOS_AUTHENTICATED));
					if (data.containsKey(CartConstants.INTENT_TYPE))
						rr.setIntendType((String) data.get(CartConstants.INTENT_TYPE));
					if (data.containsKey(CartConstants.CART_CREATOR)
							&& StringUtilities.isNotEmptyOrNull((String) data.get(CartConstants.CART_CREATOR)))
						rr.setCartCreator((String) data.get(CartConstants.CART_CREATOR));
					else if (data.containsKey(SessionConstants.MTN_KEY))
						rr.setCartCreator((String) data.get(SessionConstants.MTN_KEY));

					if (data.containsKey(CartConstants.FIVEG_UPSELL))
						rr.setIsfiveGUpSellSelected(Boolean.valueOf((String) data.get(CartConstants.FIVEG_UPSELL)));
					if(data.containsKey(CartConstants.CREDIT_APP_NUM))
						rr.setCreditAppNum((String)data.get(CartConstants.CREDIT_APP_NUM));
					if(data.containsKey(CartConstants.PREPAY_CUSTOMER_TYPE))
						rr.setCustomerType((String)data.get(CartConstants.PREPAY_CUSTOMER_TYPE));
					if(data.containsKey(CartConstants.AUTO_PAY_ENROLLED)) {
						logger.info("reading autoPayEnrolled value from redis:..{}", data.get(CartConstants.AUTO_PAY_ENROLLED));
						rr.setAutoPayEnrolled((String) data.get(CartConstants.AUTO_PAY_ENROLLED));					
					}
					if (data.containsKey(CartConstants.COMBO_MOBILITY_CART_ID)) {
						rr.setMobilityCartId((String) data.get(CartConstants.COMBO_MOBILITY_CART_ID));
					}
					if (data.containsKey(CartConstants.COMBO_MOBILITY_LOCATION_CODE)) {
						rr.setMobilityLocationCode((String) data.get(CartConstants.COMBO_MOBILITY_LOCATION_CODE));
					}
					if (data.containsKey(CartConstants.COMBO_MOBILITY_ORDER_ID)) {
						rr.setMobilityOrderNo((String) data.get(CartConstants.COMBO_MOBILITY_ORDER_ID));
					}
					if (data.containsKey(CartConstants.COMBO_MOBILITY_CREDITAPP_NUM)) {
						rr.setMobilityCreditApplicationNum((String) data.get(CartConstants.COMBO_MOBILITY_CREDITAPP_NUM));
					}
					if(data.containsKey(CartConstants.RETAIL_SCAN_AND_GO_DEPLETION_LOCATION_CODE)){
						rr.setRetailScanAndGoDepletionLocationCode((String) data.get(CartConstants.RETAIL_SCAN_AND_GO_DEPLETION_LOCATION_CODE));
					}
					populateBestBuyData(rr, data);
					//Joint Transaction
					if (data.containsKey(CartConstants.JOINT_TRANSACTION_MOBILE_CART_ID)) {
						rr.setJointTransactionMobileCartId((String) data.get(CartConstants.JOINT_TRANSACTION_MOBILE_CART_ID));
					}
					if (data.containsKey(CartConstants.JOINT_TRANSACTION_MOBILE_CASE_ID)) {
						rr.setJointTransactionMobileCaseId((String) data.get(CartConstants.JOINT_TRANSACTION_MOBILE_CASE_ID));
					}

					//NSADT-145273 changes
					if (data.containsKey(CartConstants.BRAND_NAME)
							&& StringUtilities.isNotEmptyOrNull((String) data.get(CartConstants.BRAND_NAME))
							&& !"null".equalsIgnoreCase((String) data.get(CartConstants.BRAND_NAME))){
						rr.setBrandName((String) data.get(CartConstants.BRAND_NAME));
					}
					if (data.containsKey(CartConstants.CCAR_WIFI_STATE)
							&& StringUtilities.isNotEmptyOrNull((String) data.get(CartConstants.CCAR_WIFI_STATE))
							&& !"null".equalsIgnoreCase((String) data.get(CartConstants.CCAR_WIFI_STATE))){
						rr.setCcarDeviceState((String) data.get(CartConstants.CCAR_WIFI_STATE));
					}
					if (data.containsKey(CartConstants.ADD_DEVICE_REQUEST)
							&& StringUtilities.isNotEmptyOrNull((String) data.get(CartConstants.ADD_DEVICE_REQUEST))) {

						String stringData = (String) data.get(CartConstants.ADD_DEVICE_REQUEST);
						CartRedisData addDeviceRequest = new CartRedisData();
						try {
							addDeviceRequest = mapper.readValue(stringData, CartRedisData.class);
							if (data.containsKey(CartConstants.RESTRICTED_PRODUCT_TYPE) && StringUtilities
									.isNotEmptyOrNull((String) data.get(CartConstants.RESTRICTED_PRODUCT_TYPE))
									&& CollectionUtilities.isNotEmptyOrNull(addDeviceRequest.getLines()))
								addDeviceRequest.getLines().get(0).setRestrictedProductType(
										(String) data.get(CartConstants.RESTRICTED_PRODUCT_TYPE));
						} catch (JsonProcessingException e) {
							logger.error(ERROR_PARSING_JSON_TO_OBJECT, e);
						}
						if (CollectionUtilities.isNotEmptyOrNull(addDeviceRequest.getLines()))
							rr.setDeviceLines(addDeviceRequest.getLines());
					}
					if (data.containsKey(CartConstants.ADD_ACCESSORY_REQUEST) && StringUtilities
							.isNotEmptyOrNull((String) data.get(CartConstants.ADD_ACCESSORY_REQUEST))) {

						String stringData = (String) data.get(CartConstants.ADD_ACCESSORY_REQUEST);
						CartRedisData addAccessoryRequest = new CartRedisData();
						try {
							addAccessoryRequest = mapper.readValue(stringData, CartRedisData.class);
							if (data.containsKey(CartConstants.RESTRICTED_PRODUCT_TYPE) && StringUtilities
									.isNotEmptyOrNull((String) data.get(CartConstants.RESTRICTED_PRODUCT_TYPE)))
								addAccessoryRequest.getLines().get(0).setRestrictedProductType(
										(String) data.get(CartConstants.RESTRICTED_PRODUCT_TYPE));
						} catch (JsonProcessingException e) {
							logger.error(ERROR_PARSING_JSON_TO_OBJECT, e);
						}
						if (CollectionUtilities.isNotEmptyOrNull(addAccessoryRequest.getLines()))
							rr.setAccessoryLines(addAccessoryRequest.getLines());
					}
					if (data.containsKey(CartConstants.ADDRESS_QUALIFICATION_BY_MTN) && StringUtilities
							.isNotEmptyOrNull((String) data.get(CartConstants.ADDRESS_QUALIFICATION_BY_MTN))) {
						String addressQualificationVal = (String) data.get(CartConstants.ADDRESS_QUALIFICATION_BY_MTN);
						if (Optional.ofNullable(addressQualificationVal).isPresent()) {
							try {
								rr.setAddressQualificationSessionData(mapper.readValue(addressQualificationVal, AddressValidationRespToSessionData.class));
							} catch (JsonProcessingException e) {
								logger.error(ERROR_PARSING_JSON_TO_OBJECT, e);
							}
						}
					}
					if(data.containsKey(CartConstants.PDM_OFFER_RECOMMENDATIONS)
							&& StringUtilities.isNotEmptyOrNull((String) data.get(CartConstants.PDM_OFFER_RECOMMENDATIONS))) {
						String pdmOfferString = (String) data.get(CartConstants.PDM_OFFER_RECOMMENDATIONS);
						try {
							List<PDMOfferData> fwaOffers = mapper.readValue(pdmOfferString, new TypeReference<List<PDMOfferData>>() {});
							rr.setFwaPDMOffers(fwaOffers);
						} catch (JsonProcessingException e) {
							logger.error(ERROR_PARSING_JSON_TO_OBJECT, e);
						}
					}
					//ACT141-1628
					if (data.containsKey(CartConstants.LV_SOFTSKU))
						rr.setLvSoftSku((String) data.get(CartConstants.LV_SOFTSKU));
					if (data.containsKey(CartConstants.MTN_FLOW))
						rr.setMtnFlow((String) data.get(CartConstants.MTN_FLOW));
					if (data.containsKey(CartConstants.PENDING_ICCID))
						rr.setPendingIccid((String) data.get(CartConstants.PENDING_ICCID));
					if (data.containsKey(CartConstants.ESIMTYPE))
						rr.setEsimType((String) data.get(CartConstants.ESIMTYPE));
					if (data.containsKey(CartConstants.CART_COUNT))
						rr.setCartCount((String) data.get(CartConstants.CART_COUNT));
					if (data.containsKey(CartConstants.CART_ORDER_FLOW_TYPE))
						rr.setCartOrderFlowType((String) data.get(CartConstants.CART_ORDER_FLOW_TYPE));
					if (data.containsKey(CartConstants.LOCATION_CODE))
						rr.setLocationCode((String) data.get(CartConstants.LOCATION_CODE));
					if (data.containsKey(CartConstants.VZW_ROLES))
						rr.setVzwRoles((String) data.get(CartConstants.VZW_ROLES));
					if (data.containsKey(CartConstants.STORE_LOCATION_STATE))
						rr.setStoreLocationState((String) data.get(CartConstants.STORE_LOCATION_STATE));
					if (data.containsKey(CartConstants.BILLING_STATE))
						rr.setBillingState((String) data.get(CartConstants.BILLING_STATE));
					if (data.containsKey(CartConstants.CUSTOMER_ADDRESS_STATE))
						rr.setCustomerAddressState((String) data.get(CartConstants.CUSTOMER_ADDRESS_STATE));
					if (data.containsKey(CartConstants.LINELEVEL_DIGITALSECURE_SUBSCRIPTION_COUNT))
						rr.setLineLevelDigitalSecureSubscriptionCount(
								(String) data.get(CartConstants.LINELEVEL_DIGITALSECURE_SUBSCRIPTION_COUNT));
					if (data.containsKey(CartConstants.BBP_IMEI)
							&& StringUtilities.isNotEmptyOrNull((String) data.get(CartConstants.BBP_IMEI))) {
                        rr.setBbpImei((String) data.get(CartConstants.BBP_IMEI));
                        logger.info("getDataFromRedis bbpimei: {}", rr.getBbpImei());
                    }
					if (data.containsKey(CartConstants.BBP_ICCID)
							&& StringUtilities.isNotEmptyOrNull((String) data.get(CartConstants.BBP_ICCID))) {
                        rr.setBbpIccid((String) data.get(CartConstants.BBP_ICCID));
                        logger.info("getDataFromRedis bbpiccid: {}", rr.getBbpIccid());
                    }
					if (data.containsKey(CartConstants.DEVICETYPE_BBP))
						rr.setDeviceType((String) data.get(CartConstants.DEVICETYPE_BBP));
					if (data.containsKey(CartConstants.IS_SMARTPHONE))
						rr.setIsSmartphone(Boolean.valueOf((String) data.get(CartConstants.IS_SMARTPHONE)));
					if (data.containsKey(CartConstants.BBP_IMEI2))
						rr.setBbpImei2((String) data.get(CartConstants.BBP_IMEI2));
					if (data.containsKey(CartConstants.DEVID))
						rr.setDevid((String) data.get(CartConstants.DEVID));
					if (data.containsKey(CartConstants.EID)
							&& StringUtilities.isNotEmptyOrNull((String) data.get(CartConstants.EID)))
						rr.setEid((String) data.get(CartConstants.EID));
					if(data.containsKey(CartConstants.IS_PRE_QUALIFIED_NBX)) {
						rr.setIsPreQualifiedNBX((String) data.get(CartConstants.IS_PRE_QUALIFIED_NBX));					
					}
					if(data.containsKey(CartConstants.CREDIT_CHECK_FAILURE_COUNTER)) {
						rr.setCreditCheckFailedCount(Integer.parseInt((String) data.get(CartConstants.CREDIT_CHECK_FAILURE_COUNTER)));
					}
					if (data.containsKey(CartConstants.DEVICEID))
						rr.setDeviceId((String) data.get(CartConstants.DEVICEID));
					if (data.containsKey(CartConstants.SUCCESS_URL))
						rr.setSuccessUrl((String) data.get(CartConstants.SUCCESS_URL));
					if (data.containsKey(CartConstants.EXTERNALID))						
						rr.setExternalID((String) data.get(CartConstants.EXTERNALID));
					if (data.containsKey(CartConstants.VZID))
						rr.setVzId((String) data.get(CartConstants.VZID));
					if (data.containsKey(SessionConstants.UNIVERSALID))
						rr.setUniversalId((String) data.get(SessionConstants.UNIVERSALID));
					if (data.containsKey(SessionConstants.UID))
						rr.setUId((String) data.get(SessionConstants.UID));
					if (data.containsKey(CartConstants.PROMO_MAX_COUNT))
						rr.setPromoMaxCount((String) data.get(CartConstants.PROMO_MAX_COUNT));
					if (data.containsKey(CartConstants.PROMO_VALID_MAX_COUNT))
						rr.setPromoValidMaxCount((String) data.get(CartConstants.PROMO_VALID_MAX_COUNT));
					if (data.containsKey(CartConstants.IS_DIRECT_APPLY)) {
						rr.setIsDirectApply(Boolean.valueOf((String) data.get(CartConstants.IS_DIRECT_APPLY)));
					}
					if (data.containsKey(CartConstants.REP_ID)) {
						rr.setRepId((String) data.get(CartConstants.REP_ID));
					}
					if (data.containsKey(CartConstants.STORE_NAME)) {
						rr.setStoreName((String) data.get(CartConstants.STORE_NAME));
					}
					if (data.containsKey(CartConstants.LOGGEDINUSER)) {
						rr.setLoggedInUser((String) data.get(CartConstants.LOGGEDINUSER));
					}
					if (data.containsKey(CartConstants.MUC)) {
						rr.setMuc((String) data.get(CartConstants.MUC));
					}
					
					if (data.containsKey(CartConstants.USER_ROLE)) {
						rr.setUserRole((String) data.get(CartConstants.USER_ROLE));
					}
					if (data.containsKey(CartConstants.LINE_ACTIVITY_TYPE)) {
						rr.setLineActivityType((String) data.get(CartConstants.LINE_ACTIVITY_TYPE));
					}
					
					if (data.containsKey(CartConstants.RELINQUISH_ACCOUNT_NUMBER)) {
						rr.setRelinquishAccountNumber((String) data.get(CartConstants.RELINQUISH_ACCOUNT_NUMBER));
					}
					
					if (data.containsKey(CartConstants.TYS_LINES_COUNT)) {
						rr.setTysLinesCount((String) data.get(CartConstants.TYS_LINES_COUNT));
					}

					// Setting exchange shop details for add-accessories for RFEX Flow
					if(data.containsKey(CartConstants.RFEX_EXCHANGE_SHOP_DETAILS)){
						logger.info("Exchange Shop Details for Rfex flow: {}", (String) data.get(CartConstants.RFEX_EXCHANGE_SHOP_DETAILS));
					    rr.setRfexExchangeShopDetails((String) data.get(CartConstants.RFEX_EXCHANGE_SHOP_DETAILS));
					}

                    //VZWCS-17115 change
                    if (data.containsKey(CartConstants.IMSI)
                            && StringUtilities.isNotEmptyOrNull((String) data.get(CartConstants.IMSI))){
						rr.setImsi((String) data.get(CartConstants.IMSI));
						logger.info("After getDataFromRedis IMSI: {}", rr.getImsi());
					}

					//clearAndContinue standalone accessory NSEACC implementation
					if(data.containsKey(CartConstants.PROSPECT_CARTID)) {
						rr.setProspectCartId((String)data.get(CartConstants.PROSPECT_CARTID));
					}
					if(data.containsKey(CartConstants.PLAN_SIZE)) {
						rr.setPlanSize((String)data.get(CartConstants.PLAN_SIZE));
					}
					if (data.containsKey(CartConstants.MARKET))
						rr.setMarket((String) data.get(CartConstants.MARKET));
					if (data.containsKey(CartConstants.PREORDERINSERVICEDATE))
						rr.setPreOrderInServiceDate((String) data.get(CartConstants.PREORDERINSERVICEDATE));
					if(data.containsKey(CartConstants.EVENTCORRELATIONID)){
						rr.setEventCorrelationId((String) data.get(CartConstants.EVENTCORRELATIONID));
					}
					if (data.containsKey(CartConstants.IS_PREPAY_CART)) {
                        rr.setIsPrepayCart((String) data.get(CartConstants.IS_PREPAY_CART));
                        logger.info("getDataFromRedis IS_PREPAY_CART: {}", rr.getIsPrepayCart());
                    }
					if (data.containsKey(CartConstants.IS_COMMON_PDP) && data.get(CartConstants.IS_COMMON_PDP) != null)
						rr.setIsCommonPDP(Boolean.valueOf((String) data.get(CartConstants.IS_COMMON_PDP)));

					//clearAndContinue standalone accessory NSEACC implementation
					if (data.containsKey(CartConstants.INTENT_TOKEN_RESPONSE) && StringUtilities.isNotEmptyOrNull((String) data.get(CartConstants.INTENT_TOKEN_RESPONSE))) {
						try {
							String intentTokenResponse = (String) data.get(CartConstants.INTENT_TOKEN_RESPONSE);
							Map response = mapper.readValue(intentTokenResponse, HashMap.class);
							if (response.containsKey(CartConstants.EID)
									&& StringUtilities.isNotEmptyOrNull((String) response.get(CartConstants.EID))
									&& !"null".equalsIgnoreCase((String) response.get(CartConstants.EID)))
								rr.setEid((String) response.get(CartConstants.EID));
							if (response.containsKey(CartConstants.ICCID)
									&& StringUtilities.isNotEmptyOrNull((String) response.get(CartConstants.ICCID))
									&& !"null".equalsIgnoreCase((String) response.get(CartConstants.ICCID))) {
								rr.setIccid((String) response.get(CartConstants.ICCID));
								rr.setBbpIccid((String) response.get(CartConstants.ICCID));
							}
							if (response.containsKey(CartConstants.DEVID)
									&& StringUtilities.isNotEmptyOrNull((String) response.get(CartConstants.DEVID))
									&& !"null".equalsIgnoreCase((String) response.get(CartConstants.DEVID))) {
								rr.setDevid((String) response.get(CartConstants.DEVID));
							}
							if (response.containsKey(CartConstants.HAND_OFF_TOKEN)
									&& StringUtilities.isNotEmptyOrNull((String) response.get(CartConstants.HAND_OFF_TOKEN))
									&& !"null".equalsIgnoreCase((String) response.get(CartConstants.HAND_OFF_TOKEN))) {
								rr.setHandOffToken((String) response.get(CartConstants.HAND_OFF_TOKEN));
							}
							if (response.containsKey(CartConstants.IMEI2)
									&& StringUtilities.isNotEmptyOrNull((String) response.get(CartConstants.IMEI2))
									&& !"null".equalsIgnoreCase((String) response.get(CartConstants.IMEI2))) {
								rr.setImei2((String) response.get(CartConstants.IMEI2));
								rr.setBbpImei2((String) response.get(CartConstants.IMEI2));
							}
							if (response.containsKey(CartConstants.IMEI)
									&& StringUtilities.isNotEmptyOrNull((String) response.get(CartConstants.IMEI))
									&& !"null".equalsIgnoreCase((String) response.get(CartConstants.IMEI))) {
								rr.setImei((String) response.get(CartConstants.IMEI));
								rr.setBbpImei((String) response.get(CartConstants.IMEI));
							}
                            //VZWCS-17115 change
                            if (response.containsKey(CartConstants.IMSI)
                                    && StringUtilities.isNotEmptyOrNull((String) response.get(CartConstants.IMSI))
                                    && !"null".equalsIgnoreCase((String) response.get(CartConstants.IMSI))){
                                rr.setImsi((String) response.get(CartConstants.IMSI));
                            }
							//VZWYN-17848 change
							if (response.containsKey(CartConstants.COMPANION_PHONE_NUMBER)
									&& StringUtilities.isNotEmptyOrNull((String) response.get(CartConstants.COMPANION_PHONE_NUMBER))
									&& !"null".equalsIgnoreCase((String) response.get(CartConstants.COMPANION_PHONE_NUMBER))) {
								rr.setCompanionPhoneNumber((String) response.get(CartConstants.COMPANION_PHONE_NUMBER));
							}
							if(null != response && response.containsKey(CartConstants.GIG)
									&& StringUtils.isNotBlank((String) response.get(CartConstants.GIG))){
								logger.info("fiosCrossSellCustBanner: {}", true);
								rr.setCustomerFiosPlanType((String) response.get(CartConstants.GIG));
							}
							if(null != response && response.containsKey(CartConstants.INTENT_REDIS)
									&& StringUtilities.isNotEmptyOrNull((String) response.get(CartConstants.INTENT_REDIS))){
								logger.info("intent: {}", response.get(CartConstants.INTENT_REDIS));
							    rr.setIntent((String) response.get(CartConstants.INTENT_REDIS));
							}
						}

				catch (JsonProcessingException e) {
					logger.error(ERROR_PARSING_JSON_TO_OBJECT, e);
						}
					}
					if(data.containsKey(CartConstants.DIGITAL_IG_SESSION)) {/*MVP2*/
						rr.setSessionId((String) data.get(CartConstants.DIGITAL_IG_SESSION));
					}
					if(data.containsKey(CartConstants.BOGO_MTN)) {
						rr.setBogoMtn((String)data.get(CartConstants.BOGO_MTN));
					}
					if(data.containsKey(CartConstants.SPO_MTN)) {
						rr.setSpoMtn((String)data.get(CartConstants.SPO_MTN));
					}
					if(data.containsKey(CartConstants.PREPAY_CUSTOMER_TYPE) && data.get(CartConstants.PREPAY_CUSTOMER_TYPE) != null ) {
						logger.info("Setting customer type to redis for existing customer post to per flow  "+data.containsKey(CartConstants.PREPAY_CUSTOMER_TYPE));
						rr.setCustomerType((String)data.get(CartConstants.PREPAY_CUSTOMER_TYPE));
					}
					if (data.containsKey(CartConstants.INTENT_REDIS) && data.get(CartConstants.INTENT_REDIS) != null && ("nlg".equalsIgnoreCase((String)data.get(CartConstants.INTENT_REDIS))|| "nla".equalsIgnoreCase((String)data.get(CartConstants.INTENT_REDIS)))) {
						rr.setIntent((String) data.get(CartConstants.INTENT_REDIS));
					}
					if(data.containsKey(CartConstants.LOCATION_SUB_TYPE)) {
						rr.setLocationSubType((String)data.get(CartConstants.LOCATION_SUB_TYPE));
					}
					if (data.containsKey(CartConstants.FLOW))
						rr.setFlow((String) data.get(CartConstants.FLOW));

					if(data.containsKey(CartConstants.SOR_ID)) {
						rr.setDeviceSorId((String)data.get(CartConstants.SOR_ID));
					}
					try {
						logger.info("Data read from session: {}", mapper.writeValueAsString(rr));
					} catch (JsonProcessingException e) {
						logger.error(CartConstants.JSON_PRCSSNG_EXCPTN_STRNG + "{}", e);
					}
					try {
						if(data.containsKey(CartConstants.QUOTE_PRICING) && data.get(CartConstants.QUOTE_PRICING) != null) {
							rr.setQuotePricingValues(mapper.readValue(data.get(CartConstants.QUOTE_PRICING).toString(), QuotePricingRedisData.class));
						}
					} catch (JsonProcessingException e) {
						logger.error(ERROR_PARSING_JSON_TO_OBJECT, e);
					}
					//ACCEX-683 change
					if(data.containsKey(CartConstants.SELECTED_LINE_PROMOLIST)
							&& data.get(CartConstants.SELECTED_LINE_PROMOLIST) != null){
						List<PromoLine> promoLines = null;
						String selectedLines = (String) data.get(CartConstants.SELECTED_LINE_PROMOLIST);
						try{
							promoLines = mapper.readValue(selectedLines, new TypeReference<List<PromoLine>>() {
							});
						}catch(Exception e) {
							logger.info("Promo Exception {}", e);
						}
						rr.setPromoLines(promoLines);
					}
					rr.setPlanSelectionPath(getPlanPathDetails((String)data.get(CartConstants.PLAN_SELECTION_PATH))); // 1174
					rr.setLandingMtnHashCode(getLandingMtnHashCode((String)data.get(CartConstants.LANDING_MTN_HASHCODE))); // 1174

					if(data.containsKey(CartConstants.IS_MYLINK_AVAILABLE_FLAG)) {
						rr.setIsMyLinkAvailable(Boolean.valueOf(String.valueOf(data.get(CartConstants.IS_MYLINK_AVAILABLE_FLAG))));
					}
					if(data.containsKey(CartConstants.MYLINK_HASH_KEY)) {
						rr.setMyLinkHashKey(String.valueOf(data.get(CartConstants.MYLINK_HASH_KEY)));
					}

					if (data.containsKey(CartConstants.RECOMMENDATIONS_DEVICE_SOR_ID)) {
						rr.setDeviceSorIdForRecommendations((String) data.get(CartConstants.RECOMMENDATIONS_DEVICE_SOR_ID));
					}

					if (data.containsKey(CartConstants.RECOMMENDATIONS_ACCESSORY_SOR_ID)) {
						rr.setAccessorySorIdForRecommendations((String) data.get(CartConstants.RECOMMENDATIONS_ACCESSORY_SOR_ID));
					}

					if (data.containsKey(CartConstants.REASON_FOR_VISIT)) {
						rr.setReasonForVisit((String) data.get(CartConstants.REASON_FOR_VISIT));
					}

					if (data.containsKey(CartConstants.IS_HOME_SALES)) {
						rr.setIsHomeSales((String) data.get(CartConstants.IS_HOME_SALES));
					}

					if (data.containsKey(CartConstants.ISCOMBOORDERALLOWED)) {
						rr.setIsComboOrderAllowed((String) data.get(CartConstants.ISCOMBOORDERALLOWED));
					}

					if (data.containsKey(CartConstants.HOME_SALES_ADDRESS)) {
						Gson gson = new Gson();
						HomeSalesAddress homeSalesAddress = gson.fromJson((String)
								data.get(CartConstants.HOME_SALES_ADDRESS), HomeSalesAddress.class);
						rr.setHomeSalesAddress(homeSalesAddress);
					}

					if (data.containsKey(CartConstants.RETRIEVE_CART_RESPONSE)) {
						try {
							if (data.get(CartConstants.RETRIEVE_CART_RESPONSE) != null) {
								rr.setRetrieveCart(JacksonMapperFactory.readerForType(CXPRetrieveCartDataVO.class).readValue(JsonSanitizer.sanitize((String) data.get(CartConstants.RETRIEVE_CART_RESPONSE))));
							}
						} catch (JsonProcessingException e) {
							logger.error("retrieve cart in session response {}", e.getMessage());
						}
					}
					if (data.containsKey(CartConstants.CUSTOMER_PROFILE)) {
						try {
							if (data.get(CartConstants.CUSTOMER_PROFILE) != null) {
								rr.setCustomerProfile(JacksonMapperFactory.readerForType(CustomerProfileResponse.class).readValue(JsonSanitizer.sanitize((String) data.get(CartConstants.CUSTOMER_PROFILE))));
							}
						} catch (JsonProcessingException e) {
							logger.error("customer profile in session response {}", e.getMessage());
						}
					}

					if (data.containsKey(CartConstants.BYOD_IMEI_DETAILS) && StringUtilities
							.isNotEmptyOrNull((String) data.get(CartConstants.BYOD_IMEI_DETAILS))) {

						String byodImeiDetails = (String) data.get(CartConstants.BYOD_IMEI_DETAILS);
						try {
							rr.setDeviceImeiSimDetails(mapper.readValue(byodImeiDetails, DeviceImeiSimDetails.class));
						} catch (JsonProcessingException e) {
							logger.error(ERROR_PARSING_JSON_TO_OBJECT, e);
						}
					}

					if (data.containsKey(CartConstants.HIGH_RISK_MTN_LIST) && data.get(CartConstants.HIGH_RISK_MTN_LIST) != null) {
						try {
							rr.setHighRiskMtnList(mapper.readValue(data.get(CartConstants.HIGH_RISK_MTN_LIST).toString(),new TypeReference<HashMap<String,Object>>() {}));
						} catch (JsonProcessingException e) {
							logger.error("highRiskMtnList in session response {}", e.getMessage());
						}
					}
					if (data.containsKey(CartConstants.DUAL_NUMBER)) {
						try {
							Gson gson = new Gson();
							DualNumber dualNumber = gson.fromJson((String) data.get(CartConstants.DUAL_NUMBER), DualNumber.class);
							rr.setDualNumber(dualNumber);
						}catch(Exception e){
							logger.info("Error while trying to parse dual number JSON {}", e);
						}
					}
					if (data.containsKey(CartConstants.FLOW_NAME) && StringUtilities.isNotEmptyOrNull((String) data.get(CartConstants.FLOW_NAME))) {
						rr.setFlowName((String) data.get(CartConstants.FLOW_NAME));
					}
					if (data.containsKey(CartConstants.PLAN_TAGGING_DETAILS) && StringUtilities.isNotEmptyOrNull((String) data.get(CartConstants.PLAN_TAGGING_DETAILS))) {
						List<PlanTaggingDetails> planTaggingDetails = new ArrayList<>();
						try {
							String planTaggingString = (String) data.get(CartConstants.PLAN_TAGGING_DETAILS);
							planTaggingDetails = mapper.readValue(planTaggingString, new TypeReference<List<PlanTaggingDetails>>() {
							});
						} catch (Exception e) {
							logger.error("Exception in plan tagging details node:{} ", e);
						}
						rr.setPlanTaggingDetails(planTaggingDetails);
					}
					//lgpo changes
					if (data.containsKey(CartConstants.LGPO_ELIGIBLE_CUSTOMER) && data.get(CartConstants.LGPO_ELIGIBLE_CUSTOMER) != null) {
						rr.setIsLgpoEligibleCustomer(Boolean.valueOf((String) data.get(CartConstants.LGPO_ELIGIBLE_CUSTOMER)));
					}
					if (data.containsKey(CartConstants.LGPO_SPO) && StringUtilities.isNotEmptyOrNull((String) data.get(CartConstants.LGPO_SPO))) {
						rr.setLgpoSpo((String) data.get(CartConstants.LGPO_SPO));
					}
					if(data.containsKey(CartConstants.RETURN_INDICATOR) && StringUtilities.isNotEmptyOrNull((String) data.get(CartConstants.RETURN_INDICATOR))) {
						rr.setIsReturnRequired((String) data.get(CartConstants.RETURN_INDICATOR));
					}
					setPastDueInRedisData(data, rr);
					return Mono.just(rr);
				});
	}

	private void setPastDueInRedisData(Map data, CartRedisData rr) {
		if (data.containsKey(CartConstants.PAST_DUE) && StringUtilities
				.isNotEmptyOrNull((String) data.get(CartConstants.PAST_DUE))) {

			String pastdueData = (String) data.get(CartConstants.PAST_DUE);
			try {
				rr.setPastDueRedisData(mapper.readValue(pastdueData, PastDueRedisData.class));
			} catch (JsonProcessingException e) {
				logger.error(ERROR_PARSING_JSON_TO_OBJECT, e);
			}
		}
	}

	private void populateBestBuyData(CartRedisData rr, Map<Object,Object> data) {
		if (data.containsKey(CartConstants.UPC)) {
			rr.setUpc((String) data.get(CartConstants.UPC));
		}
		if (data.containsKey(CartConstants.PRICE_ID)) {
			rr.setPriceId((String) data.get(CartConstants.PRICE_ID));
		}
		if(data.containsKey(CartConstants.MAID)) {
			rr.setMaid((String) data.get(CartConstants.MAID));
		}
	}

	public Mono<Map> getRequiredDataFromRedis(List<String> paramList){
		if(!paramList.isEmpty())
			return sessionBean.getSessionData(paramList);
		return Mono.empty();
	}

	/**
	 *
	 * @param request
	 * @return rr
	 */
	public Mono<CartRedisData> upsertDataIntoRedisAsString(CartRedisData request, String itemType) {

		Map requestMap = new HashMap<String, String>();
		String requestString = "";
		String aalPromoInterceptString = "";
		redisHelper3.settingDataIntoRedisAsString(requestMap,request,aalPromoInterceptString,itemType,requestString,true);
		requestMap.put(CartConstants.CART_ID, request.getCartId());
		requestMap.put(CartConstants.PROCESSING_MTN, request.getProcessingMTN());
		requestMap.put(CartConstants.INTEND_TYPE, request.getIntendType());
		requestMap.put(CartConstants.INTENT_TYPE, request.getIntendType());
		requestMap.put(CartConstants.CASE_ID, request.getCaseId());
		requestMap.put(CartConstants.AAL_PROMO_INTERCEPT, aalPromoInterceptString);
		requestMap.put(CartConstants.DEVICE_PROD_ID, request.getDeviceProdId());
		requestMap.put(CartConstants.ITEM_TYPE, itemType);
		if(StringUtilities.isNotEmptyOrNull(request.getExistingCase()))
			requestMap.put(CartConstants.EXISTING_CASE, request.getExistingCase());
		if (CartConstants.DEVICE.equalsIgnoreCase(itemType))
			requestMap.put(CartConstants.ACCOUNT_INFO_VALIDATE, CartConstants.FALSE);

		if (StringUtils.isNotBlank(request.getRpsIntent()))
			requestMap.put(CartConstants.RPS_INTENT, request.getRpsIntent());
		try {
			logger.info(
					DATA_UPSERTED_INTO_REDIS_APP_NAME_CART_SERVICE,mapper.writeValueAsString(request));
		} catch (JsonProcessingException e) {
			logger.error(CartConstants.JSON_PRCSSNG_EXCPTN_STRNG + "{}", e);
		}
		sessionBean.setSessionData(requestMap).subscribe();
		return Mono.just(request);

	}

	/**
	 *
	 * @param request
	 * @return Boolean
	 */
	public Mono<Boolean> upsertRetrieveCartDataIntoRedis(RetrieveCartRedisData request) {
		return sessionBean.setSessionData(CartConstants.RETRIEVECART_DATA, request);
	}

	/**
	 *
	 * @param
	 * @return Boolean
	 */
	public Mono<Boolean> saveComboFlagToRedis(String comboFflag) {
		return sessionBean.setSessionData(CartConstants.COMBO_ORDER_FLAG, comboFflag);
	}


	/**
	 *
	 * @param request
	 * @return Boolean
	 */
	public Mono<Boolean> updateDataIntoRedisAsString(CartRedisData request, String itemType) {

		Map requestMap = new HashMap<String, String>();
		String requestString = "";
		String aalPromoInterceptString = "";
		requestMap.put(CartConstants.APP_NAME, CartConstants.SOE_CART_SERVICE_NAME);
		redisHelper3.settingDataIntoRedisAsString(requestMap,request,aalPromoInterceptString,itemType,requestString,false);
		requestMap.put(CartConstants.CART_ID, request.getCartId());
		String ecpdId = request.getEcpdId();
		if (StringUtilities.isNotEmptyOrNull(ecpdId))
			requestMap.put(CartConstants.ECPD_PROFILE_ID, ecpdId);
		requestMap.put(CartConstants.PROCESSING_MTN, request.getProcessingMTN());
		requestMap.put(CartConstants.INTEND_TYPE, request.getIntendType());
		requestMap.put(CartConstants.INTENT_TYPE, request.getIntendType());
		requestMap.put(CartConstants.CASE_ID, request.getCaseId());
		requestMap.put(CartConstants.AAL_PROMO_INTERCEPT, aalPromoInterceptString);
		requestMap.put(CartConstants.DEVICE_PROD_ID, request.getDeviceProdId());
		requestMap.put(CartConstants.ITEM_TYPE, itemType);
		requestMap.put(CartConstants.CRADLE_FLOW_JOURNEY,request.getCradleFlowJourney());
		if(StringUtilities.isNotEmptyOrNull(request.getCartOrderFlowType()))
			requestMap.put(CartConstants.CART_ORDER_FLOW_TYPE,request.getCartOrderFlowType());
		//for setting  jointTransactionMobileCartId and jointTransactionMobileCaseId into redis
		if(StringUtilities.isNotEmptyOrNull(request.getCartId()))
			requestMap.put(CartConstants.JOINT_TRANSACTION_MOBILE_CART_ID, request.getCartId());
		if(StringUtilities.isNotEmptyOrNull(request.getCaseId()))
			requestMap.put(CartConstants.JOINT_TRANSACTION_MOBILE_CASE_ID, request.getCaseId());

		if(CollectionUtilities.isNotEmptyOrNull(request.getLines())
				&& null!=request.getLines().get(0) && null != request.getLines().get(0).getIsCommonPDP()) {
			requestMap.put(CartConstants.IS_COMMON_PDP,String.valueOf(request.getLines().get(0).getIsCommonPDP()));
		}
		if(StringUtilities.isNotEmptyOrNull(request.getDeviceSorIdForRecommendations())) {
			requestMap.put(CartConstants.RECOMMENDATIONS_DEVICE_SOR_ID, request.getDeviceSorIdForRecommendations());
		}
		if(StringUtilities.isNotEmptyOrNull(request.getAccessorySorIdForRecommendations())) {
			requestMap.put(CartConstants.RECOMMENDATIONS_ACCESSORY_SOR_ID, request.getAccessorySorIdForRecommendations());
		}

		/**if(CollectionUtilities.isNotEmptyOrNull(request.getLines())
				&&null!=request.getLines().get(0)
				&&null!=request.getLines().get(0).getIsCommonPDP()) {
			requestMap.put(CartConstants.IS_COMMON_PDP,String.valueOf(request.getLines().get(0).getIsCommonPDP()));
		} */

		if (StringUtilities.isNotEmptyOrNull(request.getProcessingMTN()))
			requestMap.put(CartConstants.PROCESSING_MTN, request.getProcessingMTN());
		if (CartConstants.DEVICE.equalsIgnoreCase(itemType))
			requestMap.put(CartConstants.ACCOUNT_INFO_VALIDATE, CartConstants.FALSE);
		if(StringUtilities.isNotEmptyOrNull(request.getExistingCase()))
			requestMap.put(CartConstants.EXISTING_CASE, request.getExistingCase());

		if(StringUtilities.isNotEmptyOrNull(request.getIconicTestIntent()))
			requestMap.put(CartConstants.ICONIC_TEST_INTENT_FROM_CRADLE, request.getIconicTestIntent());
		if(StringUtilities.isNotEmptyOrNull(request.getOneClickCheckout()) && CartConstants.FALSE.equals(request.getOneClickCheckout()))
			requestMap.put(CartConstants.ONE_CLICK_CHECKOUT, request.getOneClickCheckout());
		if(StringUtilities.isNotEmptyOrNull(request.getIntendType()) && CartConstants.NSEACC.equalsIgnoreCase(request.getIntendType()))
			requestMap.put("prospectCartId", request.getCartId());
		if(StringUtilities.isNotEmptyOrNull(request.getDeviceCount()))
			requestMap.put(CartConstants.DEVICE_COUNT, request.getDeviceCount());
		if(StringUtilities.isNotEmptyOrNull(request.getFiosAuthenticated()) && CartConstants.AUTHENTICATED.equalsIgnoreCase(request.getFiosAuthenticated())) {
			requestMap.put(CartConstants.FIOS_AUTHENTICATED, CartConstants.AUTHENTICATED);
		}
		logger.info("updateDataIntoRedisAsString in RedisHelper : request map getting saved in redis is{}" ,requestMap);
		return redisHelper3.settingReturnSessionData(requestMap,request);
	}

	/**
	 * 
	 * @param request
	 * @return Boolean
	 */
	public Mono<Boolean> updateSPOsIntoRedis(ConflictedSPOs request) {
		return sessionBean.setSessionData(CartConstants.CONFLICTED_SPOS, request).onErrorResume(onError -> {
			logger.error(" Unable to update Hum Wifi value into Redis {0}", onError);
			return  Mono.just(false);
		}).flatMap(response -> {
			try {
				logger.info(DATA_UPSERTED_INTO_REDIS_APP_NAME_CART_SERVICE,mapper.writeValueAsString(request));
			} catch (JsonProcessingException e) {
				logger.error(CartConstants.JSON_PRCSSNG_EXCPTN_STRNG + "{}", e);
			}
			return Mono.just(response);
		});
	}

	/**
	 *
	 * @param request
	 * @return Boolean
	 */
	public Mono<Boolean> updateSFOsIntoRedis(ConflictedSFOs request) {
		return sessionBean.setSessionData(CartConstants.HUM_WIFI, request).onErrorResume(onError -> {
			logger.error(" Unable to update Hum Wifi value into Redis {0}", onError);
			return  Mono.just(false);
		}).flatMap(response -> {
			try {
				logger.info(String.format(CartConstants.REDIS_DATA_LOG_CONTENT,mapper.writeValueAsString(request)));
			} catch (JsonProcessingException e) {
				logger.error(CartConstants.JSON_PRCSSNG_EXCPTN_STRNG + "{}", e);
			}
			return Mono.just(response);
		});
	}

	/**
	 *
	 * @param protectionVersion
	 * @return Boolean
	 */
	public Mono<Boolean> updateProtectionVersionInRedis(String protectionVersion) {
		return sessionBean.setSessionData(CartConstants.PROTECTION_VERSION, protectionVersion).onErrorResume(onError -> {
			logger.error(" Unable to update protectionVersion into Redis {0}", onError);
			return Mono.just(false);
		}).flatMap(response -> {
			logger.info(String.format(CartConstants.REDIS_DATA_LOG_CONTENT,protectionVersion));
			return Mono.just(response);
		});
	}

	/**
	 * 
	 * @param request
	 * @return boolean
	 */
	public Mono<Boolean> updateCartIdAndCaseIdIntoRedis(CartRedisData request) {
		Map<String, String> requestMap = new HashMap<>();
		requestMap.put(CartConstants.CART_ID, request.getCartId());
		requestMap.put(CartConstants.CASE_ID, request.getCaseId());
		requestMap.put(CartConstants.CART_CREATOR, request.getCartCreator());
		requestMap.put(CartConstants.CRADLE_FLOW_JOURNEY,request.getCradleFlowJourney());
		if(StringUtilities.isNotEmptyOrNull(request.getTanglewoodSelected()))
			requestMap.put(CartConstants.RETAIL_TANGLEWOOD_SELECTED,request.getTanglewoodSelected());
		String ecpdId = request.getEcpdId();
		if (StringUtilities.isNotEmptyOrNull(ecpdId))
			requestMap.put(CartConstants.ECPD_PROFILE_ID, ecpdId);
		if(StringUtilities.isNotEmptyOrNull(request.getExistingCase()))
			requestMap.put(CartConstants.EXISTING_CASE, request.getExistingCase());
		if(StringUtilities.isNotEmptyOrNull(request.getOneClickCheckout()))
			requestMap.put(CartConstants.ONE_CLICK_CHECKOUT, request.getOneClickCheckout());
		if(StringUtilities.isNotEmptyOrNull(request.getIntendType())){
			requestMap.put(CartConstants.INTENDTYPE, request.getIntendType());
			requestMap.put(CartConstants.INTENT_TYPE, request.getIntendType());
		}
		if(StringUtilities.isNotEmptyOrNull(request.getDeviceCount()))
			requestMap.put(CartConstants.DEVICE_COUNT, request.getDeviceCount());
		if(null != request.getDualNumber()){
			GsonBuilder gsonBuilder = new GsonBuilder();
			Gson gsonObject = gsonBuilder.create();
			requestMap.put(CartConstants.DUAL_NUMBER, gsonObject.toJson(request.getDualNumber()));
		}
		if(StringUtilities.isNotEmptyOrNull(request.getFiosAuthenticated()) && CartConstants.AUTHENTICATED.equalsIgnoreCase(request.getFiosAuthenticated())) {
			requestMap.put(CartConstants.FIOS_AUTHENTICATED, CartConstants.AUTHENTICATED);
		}
		logger.info("updateCartIdAndCaseIdIntoRedis :: session data map is : {}",requestMap);
		return sessionBean.setSessionData(requestMap);
	}

	/**
	 *
	 * @return CartRedisData
	 */
	public Mono<CartRedisData> getDataFromRedisAsString() {
		return sessionBean.getSessionData(CartConstants.ADD_DEVICE_REQUEST, CartRedisData.class)
				.onErrorReturn(new CartRedisData()).defaultIfEmpty(new CartRedisData()).flatMap(data -> {
					logger.info("Reading add-device request");
					return Mono.just(data);
				});
	}

	/**
	 *
	 * @return MyOfferRedisData
	 */
	public Mono<MyOfferRedisData> getMyOfferDataFromRedis() {
		return sessionBean.getSessionData(CartConstants.MYOFFER_DATA, MyOfferRedisData.class)
				.onErrorReturn(new MyOfferRedisData()).defaultIfEmpty(new MyOfferRedisData()).flatMap(data -> {
					logger.info("Reading myOffer request: {}", data);
					return Mono.just(data);
				});
	}
	
	/**
	 * 
	 * @return data
	 */
	public Mono<MyOfferETRRedisData> getMyOfferETRDataFromRedis() {
		return sessionBean.getSessionData(CartConstants.MYOFFER_ETR_DATA, MyOfferETRRedisData.class)
				.onErrorReturn(new MyOfferETRRedisData()).defaultIfEmpty(new MyOfferETRRedisData()).flatMap(data -> {
					logger.info("Reading myOfferETRData request: {}", data);
					return Mono.just(data);
				});
	}

	/**
	 *
	 * @return String
	 */
	public Mono<String> getItemTypeFromRedis() {
		return sessionBean.getSessionData(CartConstants.ITEM_TYPE, String.class).onErrorReturn("").defaultIfEmpty("")
				.flatMap(data -> {
					logger.info("Reading item type request: {} " , data);
					return Mono.just(data);
				});
	}

	/**
	 *
	 * @return CartRedisData
	 */
	public Mono<CartRedisData> getAccessoryDataFromRedisAsString() {
		return sessionBean.getSessionData(CartConstants.ADD_ACCESSORY_REQUEST, CartRedisData.class)
				.onErrorReturn(new CartRedisData()).defaultIfEmpty(new CartRedisData()).flatMap(data -> {
					logger.info("Reading add-accessories request: {}", data);
					return Mono.just(data);
				});
	}

	/**
	 * 
	 * @return AddFeaturesUIRequest
	 */
	public Mono<AddFeaturesUIRequest> getAddFeaturesRequest() {
		return sessionBean.getSessionData(CartConstants.ADD_FEATURES_REQUEST, AddFeaturesUIRequest.class)
				.onErrorReturn(new AddFeaturesUIRequest()).defaultIfEmpty(new AddFeaturesUIRequest()).flatMap(data -> {
					logger.info("Reading Add Features Request: {}", data);
					return Mono.just(data);
				});
	}

	/**
	 *
	 * @return String
	 */
	public Mono<String> getMtnToPlanIdMap() {
		return sessionBean.getSessionData(CartConstants.MTN_TO_PLANID_MAP, String.class).onErrorReturn("")
				.defaultIfEmpty("").flatMap(data -> {
					logger.info(READING_RESTRICTED_PRODUCT_TYPE_REQUEST + "{} " , data);
					return Mono.just(data);
				});
	}

	/**
	 * 
	 * @return data
	 */
	public Mono<BVPRedisData> getBVPDataFromRedis() {
		return sessionBean.getSessionData(CartConstants.DEVICE_BEST_VALUE_OFFER_DATA, BVPRedisData.class)
				.onErrorReturn(new BVPRedisData()).defaultIfEmpty(new BVPRedisData()).flatMap(data -> {
					logger.info("Reading bvpData request: {}", data);
					return Mono.just(data);
				});
	}

	/**
	 * return Mono boolean whether
	 */
	public Mono<Boolean> isDigitalHomeFlow() {
		logger.info("homeIntendTypeKeys values: {}" , homeIntendTypeKeys);
		return sessionBean.getSessionData(homeIntendTypeKeys).flatMap(data->
				Mono.just(SOEConstants.DIGITAL.equals(sessionBean.getChannelType()) && !Collections.disjoint(data.values(), homeIntendTypeValues))
		).onErrorResume(e->{
			logger.error("Error occured while checking redis ",e);
			return Mono.just(Boolean.FALSE);
		}).switchIfEmpty(Mono.defer(()->{
			logger.warn("isDigitalHomeFlow session is empty ");
			return Mono.just(Boolean.FALSE);
		}));
	}

	/**
	 * 
	 * @param requestKey
	 * @return long
	 */
	public Mono<Long> deleteAddDeviceDataFromRedis(String requestKey) {
		List<String> keys = new ArrayList<>();
		keys.add(requestKey);
		return sessionBean.deleteSessionData(keys).doOnError(onError -> {
			logger.error(UNABLE_TO_DELETE_FROM_REDIS, onError);
		});
	}

	/**
	 *
	 * @param keys
	 * @return long
	 */
	public Mono<Long> deleteSessionDataFromRedis(List<String> keys) {

		return sessionBean.deleteSessionData(keys).doOnError(onError -> {
			logger.error(UNABLE_TO_DELETE_FROM_REDIS, onError);
		});
	}

	/**
	 * 
	 * @param requestKey
	 * @return long
	 */
	public Mono<Long> deleteProcessingMtnFromRedis(String requestKey) {
		List<String> keys = new ArrayList<>();
		keys.add(requestKey);
		return sessionBean.deleteSessionData(keys).doOnError(onError -> {
			logger.error(UNABLE_TO_DELETE_FROM_REDIS, onError);
		});
	}
	
	/**
	 * 
	 * @return resp
	 */
	public Mono<List<InEligibleLinesRedisData>> getInEligibleUpgradeLinesFromRedis() {
		return sessionBean.getSessionData(CartConstants.INELIGIBLE_UPGRADE_LINES, String.class)
				.onErrorReturn("").defaultIfEmpty("")
				.flatMap(data -> {
					logger.info("Reading InEligibleUpgradeLines from Redis");
					List<InEligibleLinesRedisData> resp = new ArrayList<>();
					try {
						if(StringUtilities.isNotEmptyOrNull(data)) {
							resp = mapper.readValue(data, new TypeReference<List<InEligibleLinesRedisData>>(){});
						}
					} catch (JsonProcessingException e) {
						logger.error(CartConstants.JSON_PRCSSNG_EXCPTN_STRNG, e);
					}
					return Mono.just(resp);
				});
	}

	/**
	 * 
	 * @param request
	 * @return Boolean
	 */

	public Mono<Boolean> upsertAlternateUpgradeDataIntoRedis(Map request) {
		return sessionBean.setSessionData(request);
	}

	/**
	 * 
	 * @param keys
	 * @return long
	 */
	public Mono<Long> deleteAlternateUpgradeDataIntoRedis(List<String> keys) {
		return sessionBean.deleteSessionData(keys).doOnError(onError -> {
			logger.error(UNABLE_TO_DELETE_FROM_REDIS,onError);
		});
	}

	/**
	 *
	 * @return String
	 */
	public Mono<String> getOneClickCheckoutFlag() {
		return sessionBean.getSessionData(CartConstants.ONE_CLICK_CHECKOUT, String.class).onErrorReturn("")
				.defaultIfEmpty("").flatMap(data -> {
					logger.info(READING_RESTRICTED_PRODUCT_TYPE_REQUEST + " " + data);
					return Mono.just(data);
				});
	}

	/**
	 *
	 * @return String
	 */
	public Mono<String> getPromoHubSpokeJourney() {
		return sessionBean.getSessionData(CartConstants.PROMOHUB_SPOKE_JOURNEY, String.class).onErrorReturn("")
				.defaultIfEmpty("").flatMap(data -> {
					logger.info(String.format("Reading getPromoHubSpokeJourney Flag: %s", data));
					return Mono.just(data);
				});
	}

	/**
	 * 
	 * @param hexplanOfferInfo
	 * @return status
	 */
	public Mono<Boolean> upsertAddPlanUIRequestIntoRedisforHexUnlimitedPlanOffer(Map<String, String> hexplanOfferInfo) {
		return sessionBean.setSessionData(CartConstants.MYOFFER_HEXPLAN_INFO, hexplanOfferInfo).doOnError(onError -> {
			logger.error(" Unable to update Hex plan Offer map value into Redis {}",onError);
		}).doOnSuccess(onSuccess -> {
			logger.info(" Updated data successfully into Redis");
		}).onErrorReturn(Boolean.FALSE).defaultIfEmpty(Boolean.TRUE).flatMap(response -> {
			return Mono.just(true);
		});
	}

	/**
	 * 
	 * @param keys
	 * @return long
	 */
	public Mono<Long> deleteHexPlanOfferInfoIntoRedis(List<String> keys) {
		return sessionBean.deleteSessionData(keys).doOnError(onError -> {
			logger.error(UNABLE_TO_DELETE_FROM_REDIS,onError);
		});
	}

	/**
	 * 
	 * @param val
	 * @return status
	 */
	public Mono<Boolean> upsertOneClickCheckoutFlag(String val) {
		return sessionBean.setSessionData(CartConstants.ONE_CLICK_CHECKOUT, val).doOnError(onError -> {
			logger.error(" Unable to set oneClickCheckoutFlag as false",onError);
		}).doOnSuccess(onSuccess -> {
			logger.info(" Updated oneClickCheckoutFlag successfully into Redis");
		}).onErrorReturn(Boolean.FALSE).defaultIfEmpty(Boolean.TRUE).flatMap(response -> {
			return Mono.just(true);
		});
	}

	/**
	 * 
	 * @return long
	 */
	public Mono<Long> deleteCartIdAndCaseIdFromRedis() {
		List<String> keys = new ArrayList<>();
		keys.add(CartConstants.CART_ID);
		keys.add(CartConstants.CASE_ID);
		return sessionBean.deleteSessionData(keys).doOnError(onError -> {
			logger.error(UNABLE_TO_DELETE_FROM_REDIS, onError);
		});
	}
	
	/**
	 * 
	 * @return long
	 */
	public Mono<Long> deleteCartIdAndCaseIdAndExistingCaseFromRedis() {
		List<String> keys = new ArrayList<>();
		keys.add(CartConstants.EXISTING_CASE);
		keys.add(CartConstants.CART_ID);
		keys.add(CartConstants.CASE_ID);
		return sessionBean.deleteSessionData(keys).doOnError(onError -> {
			logger.error(UNABLE_TO_DELETE_FROM_REDIS, onError);
		});
	}

	/**
	 * 
	 * @return creditErrorContent
	 */
	public Mono<CreditErrorContent> readCreditException() {
		return isDigitalHomeFlow().flatMap(isHomeFlow -> {
			logger.info(String.format("isHomeFlow value: %s", isHomeFlow));
			String subKey = isHomeFlow ? SUB_KEY_5G : SUB_KEY;
			logger.info(String.format("Subkey to read credit exception data: %s", subKey));
			return creditDatastoreClient.readCreditException(TOP_KEY, subKey)
					.doOnError(onError -> {
						logger.error(" Unable to read creditData from Redis {}",onError);
					}).doOnSuccess(onSuccess -> logger.info(" got Data from Redis"))
					.onErrorReturn(new CreditErrorContent()).defaultIfEmpty(new CreditErrorContent());
		}).doOnError(onError-> logger.error("Unable to Validate Home Flow")).defaultIfEmpty(new CreditErrorContent());
	}


	/**
	 * 
	 * @return data
	 */
	public Mono<FiveGAddressRedisData> getFiveGAddressFromRedis() {
		return sessionBean.getSessionData(CartConstants.FIVEG_ADDRESS, FiveGAddressRedisData.class)
				.onErrorReturn(CartPegaRequestErrorsUtil.handleFiveAddressErrors())
				.defaultIfEmpty(CartPegaRequestErrorsUtil.handleFiveAddressErrors()).flatMap(data -> {
					try {
						logger.info("Reading FiveGAddressRedisData {}", mapper.writeValueAsString(data));
					} catch (JsonProcessingException e) {
						logger.error(CartConstants.JSON_PRCSSNG_EXCPTN_STRNG + "{}", e);
					}
					if (null == data.getAddressRequest())
						data = CartPegaRequestErrorsUtil.handleFiveAddressErrors();
					return Mono.just(data);
				});
	}
	public Mono<Boolean> upsertCartResponseToSession(CXPRetrieveCartDataVO cartResponse, RetrieveCartCXPRequest request) {
		//if (String.valueOf(httpHeader.getURI()) != null && isFlexV2(String.valueOf(httpHeader.getURI()))) {
		if(StringUtilities.isNotEmptyOrNull(request.getChannelId()) && CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))){
			return sessionBean.setSessionData(CartConstants.RETRIEVE_CART_RESPONSE, cartResponse).doOnError(onError -> {
				logger.error(" upsert Cart Response To Session FAILED", onError);
			}).doOnSuccess(onSuccess -> {
				logger.info(" upsert Cart Response To Session");
			}).onErrorReturn(Boolean.FALSE).defaultIfEmpty(Boolean.TRUE).flatMap(response -> {
				return Mono.just(true);
			});
		}
		return Mono.just(false);
	}
	public boolean indirectChannel(String channelId) {
		return (CartConstants.OMNI_INDIRECT.equalsIgnoreCase(channelId) || CartConstants.OMNI_INDIRECT_TAB.equalsIgnoreCase(channelId));
	}
	private Map<String,String> getLandingMtnHashCode(String landingMtnHashCode) { // 1174 - start
		logger.info("inside getLandingMtnHashCode : {}",landingMtnHashCode);
		Map<String, String> landingMtnHashCodeMap = Collections.emptyMap();
		if (StringUtilities.isEmptyOrNull(landingMtnHashCode)) return landingMtnHashCodeMap;
		try {
			landingMtnHashCodeMap = mapper.readValue(landingMtnHashCode,Map.class);
		} catch (JsonProcessingException e) {
			logger.error("Exception in getLandingMtnHashCode:",e);
		}
		return landingMtnHashCodeMap;
	}


	private Map<String,Map<String,String>> getPlanPathDetails(String planPathDetails){
		logger.info("getPlanPathDetails data : {}",planPathDetails);
		Map<String,Map<String,String>> planPathDetailsMap= Collections.EMPTY_MAP;
		if(StringUtils.isEmpty(planPathDetails)) return planPathDetailsMap;
		try {
			planPathDetailsMap = JacksonMapperFactory.defaultReader().forType(Map.class).readValue(planPathDetails);
		} catch (JsonProcessingException e) {
			logger.error("Exception in getPlanPathDetails:",e);
		}
		return planPathDetailsMap;
	} // 1174 - end

	public Mono<Long> clearMyLinkDataFromRedis(String key) {
		return sessionBean.deleteSessionData(Arrays.asList(key))
				.doOnError(onError -> logger.error(UNABLE_TO_DELETE_FROM_REDIS, onError));
	}

	public Mono<Void> setByodDataToRedis(DeviceInfo deviceInfo){
		DeviceImeiSimDetails deviceImeiSimDetails = new DeviceImeiSimDetails();
		deviceImeiSimDetails.setImei1(deviceInfo.getImei1());
		deviceImeiSimDetails.setImei2(deviceInfo.getImei2());
		SimInfo simInfo = deviceInfo.getSimInfo();
		if(simInfo!=null) {
			deviceImeiSimDetails.setIccid(simInfo.getIccid());
			deviceImeiSimDetails.setEID(simInfo.getEID());
		}
		if(StringUtilities.isNotEmptyOrNull(deviceInfo.getDeviceId()))
			deviceImeiSimDetails.setDeviceId(deviceInfo.getDeviceId());
		if(Boolean.TRUE.equals(deviceInfo.getESIMOnly())){
			deviceImeiSimDetails.setEsimOnly(deviceInfo.getESIMOnly());
		}
		sessionBean.setSessionData(CartConstants.BYOD_IMEI_DETAILS,deviceImeiSimDetails).subscribeOn(Schedulers.parallel()).subscribe();
		return Mono.empty();
	}

	public Mono<Boolean> addFlowNameToRedis(String flowName) {
		return sessionBean.setSessionData(CartConstants.FLOW_NAME, flowName);
	}

	public Mono<Boolean> saveFeatureInitiateCartInfo(CpcFeatureResponse response) {
		Map<String, String> requestMap = new HashMap<>();
		if(null!=response && null!=response.getServiceBody() &&
				null!=response.getServiceBody().getServiceResponse()
				&& null!=response.getServiceBody().getServiceResponse().getContext()){
			Context context=response.getServiceBody().getServiceResponse().getContext();
			if(null!=context.getCaseId()){
				requestMap.put(SessionConstants.FWA_CASE_ID,context.getCaseId());
			}
			if(null!=context.getCartInfo() && null!=context.getCartInfo().getCartId()){
				requestMap.put(SessionConstants.FWA_CART_ID,context.getCartInfo().getCartId());
			}

		}
		logger.info("updateCartIdAndCaseIdIntoRedis :: session data map is : {}",requestMap);
		return sessionBean.setSessionData(requestMap).subscribeOn(Schedulers.parallel());

	}

	public Mono<Long> deletDualNumberDetailsFromRedis(DualNumberRedisInfo dualNumberInfo) {
		List<String> keys = new ArrayList<>();
		keys.add(CartConstants.DUAL_NUMBER);
		if (dualNumberInfo != null && dualNumberInfo.getIsDualNumberFlow() != null &&
				Boolean.TRUE.equals(dualNumberInfo.getIsDualNumberFlow())) {
			return sessionBean.deleteSessionData(keys).doOnError(onError -> {
				logger.error(UNABLE_TO_DELETE_FROM_REDIS, onError);
			});
		}
		return null;
	}
	/**
	 *Get Cart And CaseId From Redis
	 * @return CartRedisData Mono
	 */

	public Mono<CartRedisData> getCartAndCaseIdFromRedis() {
		CartRedisData rr = new CartRedisData();
		return sessionBean
				.getSessionData(Arrays.asList(new String[] { CartConstants.CART_ID, CartConstants.CASE_ID}))
				.onErrorReturn(new HashMap<Object, Object>()).defaultIfEmpty(new HashMap<Object, Object>())
				.flatMap(data -> {
					if (data.containsKey(CartConstants.CART_ID))
						rr.setCartId((String) data.get(CartConstants.CART_ID));
					if (data.containsKey(CartConstants.CASE_ID))
						rr.setCaseId((String) data.get(CartConstants.CASE_ID));
					return Mono.just(rr);
				});
	}
	public Mono<Boolean> updateCartIdAndCaseIdIntoRedisForNGD(CartRedisData request) {
		Map<String, String> requestMap = new HashMap<>();
		requestMap.put(CartConstants.CART_ID, request.getCartId());
		requestMap.put(CartConstants.CASE_ID, request.getCaseId());
		logger.info("updateCartIdAndCaseIdIntoRedisForNGD in RedisHelper : request map getting saved in redis is{}" ,requestMap);
		return sessionBean.setSessionData(requestMap)
				.doOnError(error -> logger.info("Redis upsert failed: " +error))
				.doOnSuccess(success -> logger.info("Redis upsert successful: "));
	}

	public Mono<Boolean> addPlanTaggingDetailsToRedis(String taggingDetails) {
		return sessionBean.setSessionData(CartConstants.PLAN_TAGGING_DETAILS, taggingDetails);
	}

}

