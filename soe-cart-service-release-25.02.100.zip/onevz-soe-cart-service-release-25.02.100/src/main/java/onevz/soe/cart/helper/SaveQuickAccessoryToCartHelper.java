package onevz.soe.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.ui.requests.SaveQuickAccessoryRequest;
import onevz.soe.cart.ui.responses.SaveQuickAccessoryResponse;
import onevz.soe.cart.ui.responses.SaveQuickAccessoryResponse.SaveQuickAccessoryResponseData;
import onevz.soe.datastore.client.StoreCustomerDatastoreClient;
import onevz.soe.datastore.model.CustomerData;
import onevz.soe.datastore.model.QuickAccessoryDetails;
import onevz.soe.datastore.model.QuickAccessoryDetails.AccessoryLine;
import onevz.soe.datastore.model.QuickAccessoryDetails.Accessories;
import onevz.soe.exception.ErrorType;
import onevz.soe.exception.SOEError;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Service
@Slf4j
public class SaveQuickAccessoryToCartHelper {

    @Autowired
    private StoreCustomerDatastoreClient customerDatastoreClient;
    @Autowired
    private ObjectMapper objectMapper;

    private static final Logger log = LoggerFactory.getLogger(SaveQuickAccessoryToCartHelper.class);

    public Mono<SaveQuickAccessoryResponse> saveQuickAccessory(SaveQuickAccessoryRequest request) {
        SaveQuickAccessoryResponse response = new SaveQuickAccessoryResponse();
        SaveQuickAccessoryResponseData responseData = new SaveQuickAccessoryResponseData();
        Mono<String> customerDataMono = customerDatastoreClient.readStoreCustomerData(request.getCartId(), CartConstants.ACCOUNT_OWNER_REDIS_KEY);

        return customerDataMono.flatMap(data -> {
            try {
                CustomerData customerData = objectMapper.readValue(data, CustomerData.class);

                if (StringUtilities.isNotEmptyOrNull(request.getFlowType())
                        && CollectionUtilities.isNotEmptyOrNull(request.getLines())) {

                    var updatedCustomerData = updateCustomerData(request, customerData);

                    upsertCustomerData(request.getCartId(), updatedCustomerData);

                    responseData.setStatus(1);
                    responseData.setCartId(request.getCartId());
                    response.setData(responseData);
                    return Mono.just(response);
                }

            } catch (JsonProcessingException e) {
                log.error("Error processing data: {}", data);
                var soeError = constructSOEError(ErrorType.SYSTEM_ERROR, "500", "Customer Data not found from Cassandra");
                response.setErrors(Collections.singletonList(soeError));
                return Mono.just(response);
            }
            responseData.setStatus(-1);
            response.setData(responseData);
            return Mono.just(response);
        }).onErrorResume(Mono::error);
    }

    public CustomerData updateCustomerData(SaveQuickAccessoryRequest request, CustomerData customerData) {
        QuickAccessoryDetails quickAccessoryDetails = new QuickAccessoryDetails();
        List<AccessoryLine> accessoryLineList = new ArrayList<>();
        List<Accessories> accessoriesList = new ArrayList<>();

        request.getLines().stream().forEach(line -> {
            if (CollectionUtilities.isNotEmptyOrNull(line.getAccessories())) {
                line.getAccessories().stream().forEach(acc -> {
                    var accessory = new Accessories();
                    accessory.setDepletionType(acc.getDepletionType());
                    accessory.setQty(acc.getQty());
                    accessory.setSorId(acc.getSorId());
                    accessoriesList.add(accessory);
                });
                var accessoryLine = new AccessoryLine();
                accessoryLine.setAccessories(accessoriesList);
                accessoryLineList.add(accessoryLine);
                quickAccessoryDetails.setLines(accessoryLineList);
            }
        });
        quickAccessoryDetails.setFlowType(request.getFlowType());
        customerData.setQuickAccessoryDetails(quickAccessoryDetails);
        return customerData;
    }

    public SOEError constructSOEError(ErrorType type, String code, String message) {
        SOEError error = new SOEError();
        error.setMessage(message);
        error.setType(type.name());
        error.setId(code);
        return error;
    }
    private void upsertCustomerData(String uuid, CustomerData customerData) throws JsonProcessingException {
        String customerDataString = objectMapper.writeValueAsString(customerData);
        Mono<Boolean> booleanMono = customerDatastoreClient.upsertStoreCustomerData(uuid, CartConstants.ACCOUNT_OWNER_REDIS_KEY, customerDataString);
        log.info("Upserted Data into Customer Data store client for the cartId: {}", uuid);
        booleanMono.subscribe();
    }
}
