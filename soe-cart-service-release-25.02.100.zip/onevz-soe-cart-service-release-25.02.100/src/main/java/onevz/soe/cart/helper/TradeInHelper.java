package onevz.soe.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.tradein.session.client.TradeinSessionDataStoreClient;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper;
import onevz.soe.cart.bpm.service.CartServiceBPMServices;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.constants.TradeinConstants;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;

import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.common.CartServiceContextInfo;
import onevz.soe.cart.model.common.CartServiceCustomerInfo;
import onevz.soe.cart.model.common.CartServiceServiceHeader;
import onevz.soe.cart.model.tradeIn.*;
import onevz.soe.cart.model.tradeIn.addTradeinToCart.*;
import onevz.soe.cart.model.tradeIn.appraiseDevice.*;
import onevz.soe.cart.model.tradeIn.getTradeinQuestions.AppraisalQuestions;
import onevz.soe.cart.model.tradeIn.getTradeinQuestions.GetQuestionsData;
import onevz.soe.cart.model.tradeIn.getTradeinQuestions.TradeinAppraisalQuestionsRequest;
import onevz.soe.cart.model.tradeIn.getTradeinQuestions.TradeinAppraisalQuestionsResponse;
import onevz.soe.cart.model.tradeIn.validateDevice.TradeinValidateDeviceRequest;
import onevz.soe.cart.model.tradeIn.validateDevice.TradeinValidateDeviceRequestData;
import onevz.soe.cart.model.tradeIn.validateDevice.TradeinValidateDeviceResponse;
import onevz.soe.cart.ui.requests.AddDeviceUIRequest;
import onevz.soe.cart.ui.responses.AddDeviceUIResponse;
import onevz.soe.cart.util.CartUtil;

import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.tradein.session.model.TradeinSessionData;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
public class TradeInHelper {

    @Autowired
    CartServiceCxpHelper cxpHelper;

    @Autowired
    CartServiceBpmHelper bpmHelper;

    @Autowired
    private RedisHelper redisHelper;

    @Autowired
    SOELoginSessionBean sessionBean;

    @Autowired
    private CartServiceCXPServices cxpService;

    @Autowired
    private CartServiceBPMServices bpmService;
    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private CartAddDeviceHelper deviceHelper;

    @Autowired
    private TradeinSessionDataStoreClient tradeinSessionDataStoreClient;


    private static final Logger logger = LoggerFactory.getLogger(TradeInHelper.class);

    public Mono<AddDeviceUIResponse> validateAndAddTrade(AddDeviceUIRequest request,ServerHttpResponse httpResponse){

        return validateAndAddTradeIn(request).flatMap(tradeRes ->{

            if(tradeRes != null && tradeRes.getServiceBody() !=null && tradeRes.getServiceBody().getServiceResponse() != null &&
                    tradeRes.getServiceBody().getServiceResponse().getContext()!=null &&
                    tradeRes.getServiceBody().getServiceResponse().getContext().getContextInfo() !=null &&
                    tradeRes.getServiceBody().getServiceResponse().getContext().getContextInfo().getProcessStep() != null){

                    return deviceHelper.addDevice(request,httpResponse).flatMap(res -> {
                        if(res.getErrors() != null && !res.getErrors().isEmpty())
                            res.setTradeInAdded(true);

                        return Mono.just(res);
                    });
            }
            AddDeviceUIResponse errRes = new AddDeviceUIResponse();
            List <CartError> err =  new ArrayList<CartError>();
            errRes.setErrors(tradeRes.getErrorData());
            return Mono.just(errRes);

        });
    }
    /**
     * @param request
     * @return validateAndAddTradeIn
     */
    public Mono<TradeinAddToCartResponse> validateAndAddTradeIn(AddDeviceUIRequest request) {
        String channelType = CartUtil.getChannelType(request.getChannelId());
        return redisHelper.getDataFromRedis().flatMap(data -> {
            if (!CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType()) && !CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType()) && StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
                request.getCartInfo().setAccountNumber(data.getAccountNumber());
            if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
                request.getCartInfo().setCartId(data.getCartId());

            else if (StringUtilities.isEmptyOrNull(request.getCartInfo().getCartId())) {
                return Mono.just(new TradeinAddToCartResponse());
            }

            if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
                request.getCartInfo().setCaseId(data.getCaseId());
            if (!CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType()) && !CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType()) && StringUtilities.isNotEmptyOrNull(data.getMtn()))
                request.getCartInfo().setCartCreator(data.getMtn());

            if (!CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType()) && !CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType()) && StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
                request.getCartInfo().setCartCreator(data.getCartCreator());

            if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()) && request.getCartInfo().getIntendType().toUpperCase().contains("NSE") && StringUtilities.isNotEmptyOrNull(data.getCreditAppNum())) {
                request.getCartInfo().setCreditAppNum(data.getCreditAppNum());
                request.getCartInfo().setCartCreator(data.getCreditAppNum());
            }

            String tradeInDeviceId = "";
            if(request.getData().getLines() != null && request.getData().getLines().size() > 0){
                tradeInDeviceId = StringUtilities.isNotEmptyOrNull(request.getData().getLines().get(0).getCurrentDeviceID())
                        ? request.getData().getLines().get(0).getCurrentDeviceID() : "";

            }

            //Account device
            Mono<TradeinAccountDevicesResponse> accountDevicesResponseMono = getAccountDevices(request);

            String finalTradeInDeviceId = tradeInDeviceId;
            return accountDevicesResponseMono.flatMap(accountDevice ->{

                try {
                    logger.info("Get Tradein Account Devices: {}", objectMapper.writeValueAsString(accountDevice));
                } catch (JsonProcessingException e) {
                    logger.info(CartConstants.JSON_PARSING_EXCEPTION + ": {}",e);
                }

                if(accountDevice.getErrors() == null && accountDevice.getData() != null
                        && accountDevice.getData().getDeviceList() !=null && accountDevice.getData().getDeviceList().size() > 0) {
                    List<AccountDevice> deviceList = accountDevice.getData().getDeviceList();
                    //DeviceId
                    List<AccountDevice> deviceObj = deviceList.stream()
                            .filter(device -> device.getDeviceId().equalsIgnoreCase(finalTradeInDeviceId))
                            .collect(Collectors.toList());

                    if(CollectionUtilities.isEmptyOrNull(deviceObj) && !"EUP".equalsIgnoreCase(request.getCartInfo().getIntendType())){
                        if(request.getData() != null && request.getData().getTradeInDetails() != null) {
                            AccountDevice accountDeviceObj = new AccountDevice();
                            accountDeviceObj.setModelId(StringUtilities.isNotEmptyOrNull(request.getData().getTradeInDetails().getModelId())?request.getData().getTradeInDetails().getModelId():"");
                            deviceObj.add(accountDeviceObj);
                        }

                    }
                    String emailId = "";
                    if(accountDevice.getData() != null && accountDevice.getData().getCustomerDetails() != null)
                     emailId = StringUtilities.isNotEmptyOrNull(accountDevice.getData().getCustomerDetails().getEmailAddress())?accountDevice.getData().getCustomerDetails().getEmailAddress(): "";
                    //getQuestions
                    if(!"EUP".equalsIgnoreCase(request.getCartInfo().getIntendType()) && StringUtilities.isEmptyOrNull(emailId))
                            emailId = StringUtilities.isNotEmptyOrNull(request.getData().getTradeInDetails().getEmailId()) ? request.getData().getTradeInDetails().getEmailId() : "";

                        if (deviceObj != null && deviceObj.size() > 0 && StringUtilities.isNotEmptyOrNull(deviceObj.get(0).getModelId())) {
                            String finalEmailId = emailId;
                        return valdiateDevice(request, deviceObj.get(0).getModelId(), finalTradeInDeviceId).flatMap(validatedDevice -> {

                            if (validatedDevice != null && validatedDevice.getData() != null && validatedDevice.getErrors() == null) {

                                try {
                                    logger.info("Validate TradeIn Device : {}", objectMapper.writeValueAsString(validatedDevice));
                                } catch (JsonProcessingException e) {
                                    logger.info(CartConstants.JSON_PARSING_EXCEPTION + ": {}",e);
                                }

                            return getQuestions(deviceObj.get(0).getModelId(), finalTradeInDeviceId).flatMap(questionsObj -> {

                                try {
                                    logger.info("Get Questions for Trade Device: {}", objectMapper.writeValueAsString(questionsObj));
                                } catch (JsonProcessingException e) {
                                    logger.info(CartConstants.JSON_PARSING_EXCEPTION + ": {}",e);
                                }
                                if (questionsObj != null && questionsObj.getData() != null) {

                                    Mono<TradeinAppraisalResponse> tradeinAppraisalResponseMono = appraiseDevice(questionsObj, request, finalTradeInDeviceId, deviceObj.get(0).getModelId(), finalEmailId, validatedDevice);

                                    return tradeinAppraisalResponseMono.flatMap(appraiseResponse -> {

                                        try {
                                            logger.info("Appraise Device response for Trade Device: {}", objectMapper.writeValueAsString(appraiseResponse));
                                        } catch (JsonProcessingException e) {
                                            logger.info(CartConstants.JSON_PARSING_EXCEPTION + ": {}",e);
                                        }

                                        if (appraiseResponse != null && appraiseResponse.getData() != null) {
                                            Mono<TradeinAddToCartResponse> addTradeInResponseMono = null;
                                            try {
                                                addTradeInResponseMono = addTradeinToCart(appraiseResponse, request, finalTradeInDeviceId, data.getLocationSubType());
                                            } catch (JsonProcessingException e) {
                                                logger.info( CartConstants.JSON_PARSING_EXCEPTION + ": {}",e);
                                            }

                                            return addTradeInResponseMono.flatMap(tradeinResp -> {

                                                try {
                                                    logger.info("Add Tradein to Cart Response: {}", objectMapper.writeValueAsString(tradeinResp));
                                                } catch (JsonProcessingException e) {
                                                    logger.info( CartConstants.JSON_PARSING_EXCEPTION + ": {}",e);
                                                }

                                                if (tradeinResp != null && tradeinResp.getServiceBody() != null && tradeinResp.getServiceBody().getServiceResponse() != null
                                                        && tradeinResp.getServiceBody().getServiceResponse().getContext() != null
                                                        && tradeinResp.getServiceBody().getServiceResponse().getContext().getContextInfo() != null
                                                        && tradeinResp.getServiceBody().getServiceResponse().getContext().getContextInfo().getProcessStep() != null)
                                                    return Mono.just(tradeinResp);
                                                else {
                                                    TradeinAddToCartResponse errResponse = new TradeinAddToCartResponse();
                                                    errResponse.setErrorData(tradeinResp.getErrorData());
                                                    return Mono.just(errResponse);
                                                }
                                            });
                                        } else {
                                            TradeinAddToCartResponse errResponse = new TradeinAddToCartResponse();
                                            errResponse.setErrorData(appraiseResponse.getErrors());
                                            return Mono.just(errResponse);
                                        }
                                    });
                                } else {
                                    TradeinAddToCartResponse errResponse = new TradeinAddToCartResponse();
                                    errResponse.setErrorData(questionsObj.getErrors());
                                    return Mono.just(errResponse);
                                }
                            });

                        }else {
                                TradeinAddToCartResponse errResponse = new TradeinAddToCartResponse();
                                errResponse.setErrorData(validatedDevice.getErrors());
                                return Mono.just(errResponse);
                            }


                    });
                }else{
                        TradeinAddToCartResponse errResponse = new TradeinAddToCartResponse();
                        List<CartError> Error= new ArrayList<CartError>();
                        CartError err = new CartError();
                        err.setNamespace("cxp-tradeIn");
                        err.setMessage("No modelId Returned from CXP");
                        Error.add(err);
                        errResponse.setErrorData(Error);
                        return Mono.just(errResponse);

                }

                }else {
                    TradeinAddToCartResponse errResponse = new TradeinAddToCartResponse();
                    errResponse.setErrorData(accountDevice.getErrors());
                    return Mono.just(errResponse);
                }

            });

        });
    }

    public Mono<TradeinAccountDevicesResponse> getAccountDevices(AddDeviceUIRequest request){

        logger.info("getAccountDevices [In]: {}", request);
        if (request.getCartInfo().getIntendType() != null && "NSE".equalsIgnoreCase(request.getCartInfo().getIntendType())){
            TradeinAccountDevicesResponse tradeinAccountDevicesResponse = new TradeinAccountDevicesResponse();
            TradeinAccountDevicesData accData = new TradeinAccountDevicesData();
            List <AccountDevice> devicesList= new ArrayList<>();
            AccountDevice accountDevice = new AccountDevice();
            accountDevice.setDeviceId("");
            if(request.getData().getTradeInDetails() != null)
                accountDevice.setModelId( request.getData().getTradeInDetails().getModelId() != null ?  request.getData().getTradeInDetails().getModelId() : "");

            devicesList.add(accountDevice);
            accData.setDeviceList(devicesList);
            tradeinAccountDevicesResponse.setData(accData);
            return Mono.just(tradeinAccountDevicesResponse);
        }


        AccountDeviceCXPRequest data = new AccountDeviceCXPRequest();
            data.setAccountNo(request.getCartInfo().getAccountNumber());
            data.setCartId(request.getCartInfo().getCartId());

        TradeinAccountDevicesRequest tradeinAccountDevicesRequest = new TradeinAccountDevicesRequest();
        tradeinAccountDevicesRequest.setData(data);
        logger.info("getAccountDevices cxpRequest : {}", tradeinAccountDevicesRequest.toString());
        return cxpService.getAccountDevicesData(tradeinAccountDevicesRequest);

    }

    public  Mono<TradeinAppraisalQuestionsResponse>  getQuestions(String modelId, String tradeInDeviceId){

        TradeinAppraisalQuestionsRequest tradeinAppraisalQuestionsRequest = new TradeinAppraisalQuestionsRequest();
        GetQuestionsData data = new GetQuestionsData();
        data.setDeviceId(tradeInDeviceId);
        data.setModelId(modelId);

        //DeviceId

        tradeinAppraisalQuestionsRequest.setData(data);

        logger.info("Get Questions cxpRequest : {}", tradeinAppraisalQuestionsRequest.toString());
        Mono<TradeinAppraisalQuestionsResponse> appraisalQuestions = cxpService.getAppraisalQuestionsData(tradeinAppraisalQuestionsRequest);
        return appraisalQuestions;
    }

    public Mono<TradeinAppraisalResponse> appraiseDevice(TradeinAppraisalQuestionsResponse tradeinAppraisalQuestionsResponse,AddDeviceUIRequest request, String deviceId, String modelId, String emailId ,TradeinValidateDeviceResponse validatedDevice){

        TriageInfo triageInfo = new TriageInfo();
        //check
        triageInfo.setTriageCount(String.valueOf(tradeinAppraisalQuestionsResponse.getData().getAppraisalView().getAppraisalQuestions().size()));

        List <Triage> triage = new ArrayList<Triage>();

        List<AppraisalQuestions> appraisalQuestions = tradeinAppraisalQuestionsResponse.getData().getAppraisalView().getAppraisalQuestions();


    for(AppraisalQuestions questionObj : appraisalQuestions){
        Triage triageObj = new Triage();

        triageObj.setTriageQuestionId(questionObj.getQuestionId());
        triageObj.setQuestionText(questionObj.getLabel());
        triageObj.setActivationLockCheck(questionObj.getActivationLockCheck());
        if (!"7".equalsIgnoreCase(questionObj.getQuestionId())){

            triageObj.setTriageAnswer("YES");
        }
        if("7".equalsIgnoreCase(questionObj.getQuestionId())) {
            if(validatedDevice.getData().getDeviceValidateOutInfo() != null && validatedDevice.getData().getDeviceValidateOutInfo().size() > 0)
                triageObj.setTriageAnswer(validatedDevice.getData().getDeviceValidateOutInfo().get(0).isLocked() ? "NO" : "YES");
        }


        triage.add(triageObj);
    }
        triageInfo.setTriage(triage);

        DeviceInInfo deviceInInfoObj = new DeviceInInfo();
        deviceInInfoObj.setDeviceId(deviceId);
        deviceInInfoObj.setItemId(modelId);
        deviceInInfoObj.setDeviceCondition("GOOD");
        deviceInInfoObj.setTriageInfo(triageInfo);
        deviceInInfoObj.setDummyDevice(false);

        List <DeviceInInfo> deviceInInfo = new ArrayList<DeviceInInfo>();
        deviceInInfo.add(deviceInInfoObj);

        RecycleDeviceInput recycleDeviceInList = new RecycleDeviceInput();
        recycleDeviceInList.setDeviceInInfo(deviceInInfo);
        recycleDeviceInList.setRecycleDeviceInCount("1");
        recycleDeviceInList.setLineSeqNum("1");

        TradeinAppraisalRequestData data = new TradeinAppraisalRequestData();
        data.setRecycleDeviceInList(recycleDeviceInList);
        data.setCartId(request.getCartInfo().getCartId());
        data.setChannelId(request.getChannelId());
        data.setAccountNumber(request.getCartInfo().getAccountNumber());
        data.setAccountNo(request.getCartInfo().getAccountNumber());
        data.setCartCreator(request.getCartInfo().getCartCreator());
        data.setCaseId(request.getCartInfo().getCaseId());
        data.setTrdCartId(request.getCartInfo().getCartId());
        data.setTradeDeviceMDN(request.getData().getLines().get(0).getMtn());

        data.setEmailAddress(emailId);

        TradeinDeviceAppraisalRequest tradeinDeviceAppraisalRequest = new TradeinDeviceAppraisalRequest();
        tradeinDeviceAppraisalRequest.setData(data);
        logger.info("Appraise device cxpRequest : {}", tradeinDeviceAppraisalRequest.toString());
    return cxpService.appraiseDevice(tradeinDeviceAppraisalRequest);

    }

    public Mono<TradeinAddToCartResponse>  addTradeinToCart(TradeinAppraisalResponse appraisalResponse, AddDeviceUIRequest request, String deviceId, String locationSubType) throws JsonProcessingException {
        TradeinAddToCartRequest pegaRequest = new TradeinAddToCartRequest();
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        serviceHeader.setClientId("VZW-NETACE");
        serviceHeader.setServiceName("SalesOrderPurchase");

        TradeinAddToCartServiceBody serviceBody =  new TradeinAddToCartServiceBody();

        AddTradeinServiceRequest serviceRequest = new AddTradeinServiceRequest();

        AddTradeinContext context = new AddTradeinContext();

        context.setCaseId(request.getCartInfo().getCaseId());

        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        contextInfo.setCallReason("SalesOrderPurchase");
        contextInfo.setProcessStep("BundleRecommendationsPage");

        contextInfo.setProcessAction("addTradeIn");
        contextInfo.setIntent("EUP".equalsIgnoreCase(request.getCartInfo().getIntendType()) ? "Upgrade" : request.getCartInfo().getIntendType());
        if("NSE".equalsIgnoreCase(request.getCartInfo().getIntendType()))
            contextInfo.setIntent("Upgrade");
        context.setContextInfo(contextInfo);

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
        customerInfo.setProcessingMTN(request.getData().getLines().get(0).getMtn());
        customerInfo.setMtnFlow(CartConstants.PROMOBUNDLE);
        if("NSE".equalsIgnoreCase(request.getCartInfo().getIntendType())){
            customerInfo.setCustomerType("N");
            customerInfo.setOriginalCreditApprovalNumber(isNotEmptyOrNull(request.getCartInfo().getCreditAppNum()));
        }
        if (request.getCartInfo().getEditFromPage() != null)
            customerInfo.setEditFromPage(request.getCartInfo().getEditFromPage());

        TradeinCartInfo cartInfo = new TradeinCartInfo();
        cartInfo.setCartId(request.getCartInfo().getCartId());
        cartInfo.setItemType("TRADEIN");
        cartInfo.setIntendType(request.getCartInfo().getIntendType());
        cartInfo.setAction("UPDATE");
        cartInfo.setInstantCreditEligible(appraisalResponse.getData().isInstantCreditEligible());
        cartInfo.setInstantCreditAmount(appraisalResponse.getData().getInstantCreditValue());
        cartInfo.setShowICPage(appraisalResponse.getData().isShowICPage());
        cartInfo.setDeviceId(isNotEmptyOrNull(deviceId));
        cartInfo.setCurrentDeviceId(isNotEmptyOrNull(deviceId));
        cartInfo.setInstantBIC(isNotEmptyOrNull(appraisalResponse.getData().getInstantBIC()));
        if(StringUtilities.isNotEmptyOrNull(locationSubType) && "RX".equalsIgnoreCase(locationSubType)) {
        	cartInfo.setTradeinShipType("Home");
        }else {
        	cartInfo.setTradeinShipType("Store");
        }



        DeviceOutInfo tradeInItem = new DeviceOutInfo();
        tradeInItem.setRecycleSeqNum(isNotEmptyOrNull(appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).getRecycleSeqNum()));
        tradeInItem.setImgUrl(isNotEmptyOrNull(appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).getImgUrl()));
        tradeInItem.setLineSeqNum(isNotEmptyOrNull(appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).getLineSeqNum()));
        tradeInItem.setRecycleDeviceSku(isNotEmptyOrNull(appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).getRecycleDeviceSku()));
        tradeInItem.setItemId(isNotEmptyOrNull(appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).getItemId()));
        tradeInItem.setOrganicPrice(isNotEmptyOrNull(appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).getOrganicPrice()));
        tradeInItem.setComputedPrice(isNotEmptyOrNull(appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).getComputedPrice()));
        tradeInItem.setAppliedPrice(isNotEmptyOrNull(appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).getAppliedPrice()));
        tradeInItem.setPromoValue(isNotEmptyOrNull(appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).getPromoValue()));
        tradeInItem.setDeductionOnOrganic(isNotEmptyOrNull(appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).getDeductionOnOrganic()));
        tradeInItem.setDeductionOnPromo(isNotEmptyOrNull(appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).getDeductionOnPromo()));
        tradeInItem.setEquipMake(isNotEmptyOrNull(appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).getEquipMake()));
        tradeInItem.setEquipModel(isNotEmptyOrNull(appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).getEquipModel()));
        tradeInItem.setEquipCategory(isNotEmptyOrNull(appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).getEquipCategory()));
        tradeInItem.setEquipCarrier(isNotEmptyOrNull(appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).getEquipCarrier()));
        tradeInItem.setSubmissionId(isNotEmptyOrNull(appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).getSubmissionId()));
        tradeInItem.setDeviceCategory(isNotEmptyOrNull(appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).getDeviceCategory()));
        tradeInItem.setProdCode1(isNotEmptyOrNull(appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).getProdCode1()));
        tradeInItem.setProdCode2(isNotEmptyOrNull(appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).getProdCode2()));
        tradeInItem.setDeviceId(isNotEmptyOrNull(appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).getDeviceId()));
        tradeInItem.setDeviceIdType(isNotEmptyOrNull(appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).getDeviceIdType()));
        tradeInItem.setDeviceCondition(isNotEmptyOrNull(appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).getDeviceCondition()));
        tradeInItem.setColor(isNotEmptyOrNull(appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).getColor()));
        tradeInItem.setSize(isNotEmptyOrNull(appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).getSize()));
        tradeInItem.setCreditType(isNotEmptyOrNull(appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).getCreditType()));
        tradeInItem.setBuyoutDevice(appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).isBuyoutDevice());
        tradeInItem.setTradeInStatus(isNotEmptyOrNull(appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).getTradeInStatus()));
        if(StringUtilities.isEmptyOrNull(tradeInItem.getTradeInStatus()))
            tradeInItem.setTradeInStatus("Complete");


        tradeInItem.setCurrentTradedDevice(appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).isCurrentTradedDevice());
        tradeInItem.setEmailAddress(isNotEmptyOrNull(appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).getEmailAddress()));
        if("NSE".equalsIgnoreCase(request.getCartInfo().getIntendType()) && request.getData().getTradeInDetails() != null &&
                request.getData().getTradeInDetails().getEmailId() != null)
            tradeInItem.setEmailAddress(request.getData().getTradeInDetails().getEmailId());
        tradeInItem.setTradeDeviceMDN(isNotEmptyOrNull(appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).getTradeDeviceMDN()));
        tradeInItem.setPromoHubItem(appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).isPromoHubItem());
        tradeInItem.setFmiLocked(appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).isFmiLocked());
        tradeInItem.setDummyDevice(appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).isDummyDevice());

        if(appraisalResponse.getData() != null && appraisalResponse.getData().getRecycleDeviceOutList() != null &&
                appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo() != null &&
                appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().size() > 0 ) {

            if( appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).getRecycleDeviceOffer() != null)
                tradeInItem.setRecycleDeviceOffer(appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).getRecycleDeviceOffer());

            if( appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).getTriageInfo() != null){
                tradeInItem.setTriageInfo(appraisalResponse.getData().getRecycleDeviceOutList().getDeviceOutInfo().get(0).getTriageInfo());

            }

        }

        TriageInfo triageInfo = new TriageInfo();
        List <DeviceOutInfo> tradeInItems = new ArrayList<DeviceOutInfo>();

        tradeInItems.add(tradeInItem);


        Lines line = new Lines();
        line.setMtn("EUP".equalsIgnoreCase(request.getCartInfo().getIntendType()) ? isNotEmptyOrNull(request.getData().getLines().get(0).getMtn()) : "");

        line.setCurrentDeviceId(isNotEmptyOrNull(deviceId));
        line.setTradeInItems(tradeInItems);

        List <Lines> lines = new ArrayList<Lines>();
        lines.add(line);

        cartInfo.setLines(lines);

        context.setCustomerInfo(customerInfo);
        context.setCartInfo(cartInfo);

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);
        pegaRequest.setServiceHeader(serviceHeader);

        logger.info("Add Trade in pega request : {}", pegaRequest.toString());

        Mono<TradeinAddToCartResponse> addTradeinResponseMono =  bpmService.addTradeinToCart(pegaRequest);

        return addTradeinResponseMono;
    }

    public Mono<TradeinValidateDeviceResponse> valdiateDevice(AddDeviceUIRequest request, String modelId, String deviceId){
        TradeinValidateDeviceRequest cxpRequest = new TradeinValidateDeviceRequest();
        TradeinValidateDeviceRequestData data = new TradeinValidateDeviceRequestData();
        List <onevz.soe.cart.model.tradeIn.validateDevice.DeviceInInfo> deviceValidateInInfo = new ArrayList<onevz.soe.cart.model.tradeIn.validateDevice.DeviceInInfo>();
        onevz.soe.cart.model.tradeIn.validateDevice.DeviceInInfo deviceValidateReq = new onevz.soe.cart.model.tradeIn.validateDevice.DeviceInInfo();
        deviceValidateReq.setRecycleSeqNum("1");
        deviceValidateReq.setEquipCarrier("EUP".equalsIgnoreCase(request.getCartInfo().getIntendType())?"Verizon" :
                StringUtilities.isNotEmptyOrNull(request.getData().getTradeInDetails().getCarrier()) ? request.getData().getTradeInDetails().getCarrier() : "");
        deviceValidateReq.setDeviceId(deviceId);
        deviceValidateReq.setItemId(modelId);
        deviceValidateReq.setDeviceIdType(getDeviceIdType(deviceId));
        //always false for EquipCarrier: Verizon
        deviceValidateReq.setSkipDMDCall("Verizon".equalsIgnoreCase(deviceValidateReq.getEquipCarrier()) ? false : true);

        deviceValidateInInfo.add(deviceValidateReq);
        data.setCartId(request.getCartInfo().getCartId());
        data.setDeviceInCount("1");
        data.setDeviceValidateInInfo(deviceValidateInInfo);
        cxpRequest.setData(data);

        Mono<TradeinValidateDeviceResponse> responseMono = cxpService.validateDevice(cxpRequest);

        return responseMono;
    }
    public String isNotEmptyOrNull(String input){
        String value ="";
        return value = StringUtilities.isNotEmptyOrNull(input) ? input : "";
    }
    static Pattern esnPattern = Pattern.compile("^([a-f0-9]{8})$|^([0-9]{11})$|^([a-z0-9]{12})$", Pattern.CASE_INSENSITIVE);
    static Pattern macPattern = Pattern.compile("^([a-z0-9]{12})$", Pattern.CASE_INSENSITIVE);
    static Pattern imePattern = Pattern.compile("^([a-f9]{1}[a-f0-9]{13})$|^([0-9]{14,16})$", Pattern.CASE_INSENSITIVE);

    public String getDeviceIdType(String deviceId) {
        return esnPattern.matcher(deviceId).matches() || macPattern.matcher(deviceId).matches() ? "ESN"
                : (imePattern.matcher(deviceId).matches() ? "IME" : "");
    }
    /**
     * Update tradein session data mono.
     *
     * @param hashKey the hash key
     * @param data    the data
     * @return mono mono
     */
    public Mono<Boolean> updateTradeinSessionData(String hashKey, TradeinSessionData data) {
        String subKey = TradeinConstants.TRADEIN_SESSION_SUBKEY;
        return tradeinSessionDataStoreClient.upsertTradeinSessionData(hashKey, subKey, data)
                .onErrorResume(a -> {
                    logger.error("Error occurred while session update", a);
                    return Mono.just(Boolean.FALSE);
                }).defaultIfEmpty(Boolean.FALSE)
                .doOnSuccess(e-> logger.info("Tradein session data was deleted successfully"));

    }
    /**
     * Read tradein session data mono.
     *
     * @param hashKey the hash key
     * @return mono mono
     */
    public Mono<TradeinSessionData> readTradeinSessionData(String hashKey) {
        String subKey = TradeinConstants.TRADEIN_SESSION_SUBKEY;
        return tradeinSessionDataStoreClient.readTradeinSessionData(hashKey, subKey)
                .onErrorResume(a -> {
                    logger.error("Error occurred while fetching tradeinSessionData", a);
                    return Mono.just(new TradeinSessionData());
                }).defaultIfEmpty(new TradeinSessionData())
                .doOnSuccess(e-> logger.info("Fetched tradeinSessionData successfully"));
    }

}
