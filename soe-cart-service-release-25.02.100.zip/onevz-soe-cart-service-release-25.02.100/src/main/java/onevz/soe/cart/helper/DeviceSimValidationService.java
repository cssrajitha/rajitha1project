package onevz.soe.cart.helper;

import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.requests.*;
import onevz.soe.cart.responses.DeviceResponse;
import onevz.soe.cart.responses.DeviceResponseHeader;
import onevz.soe.cart.responses.DeviceResponsesList;
import onevz.soe.cart.responses.ProductInquiryEPSResponse;
import onevz.soe.cart.ui.requests.ProductInquiryUIRequest;
import onevz.soe.cart.ui.responses.ProductInquiryUIResponse;
import onevz.soe.utilities.StringUtilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;

@Service
public class DeviceSimValidationService {

    private static final Logger logger = LoggerFactory.getLogger(DeviceSimValidationService.class);
    @Autowired
    CartServiceCXPServices cartServiceCXPServices;

    public Mono<ProductInquiryUIResponse> processDeviceProductInquiry(ProductInquiryUIRequest request, String channel){
        logger.info("Entering into ProcessDeviceProductInquiry service");
        ProductInquiryEPSRequest epsRequest = null;
        ProductInquiryUIResponse response = new ProductInquiryUIResponse();
        if(request != null){
            epsRequest =  convertUIRequestToEPS(request,channel);
        }
        Mono<ProductInquiryEPSResponse> epsResponse = cartServiceCXPServices.getDeviceProductInquiry(epsRequest);
        return epsResponse.flatMap(data -> {
            DeviceResponseHeader responseHeader = new DeviceResponseHeader();
            if(data != null && data.getResponses() != null && !data.getResponses().isEmpty()){
                List<DeviceResponsesList> deviceResponseList = new ArrayList<DeviceResponsesList>();
                DeviceResponse deviceResponse = new DeviceResponse();
                deviceResponseList = data.getResponses();
                for (DeviceResponsesList list : deviceResponseList){
                    deviceResponse = list.getResponse();
                    responseHeader = deviceResponse.getResponseHeader();
                }
            }
            if(responseHeader.getReturnCode()!=null && responseHeader.getReturnMessage() !=null) {
                response.setReturnCode(responseHeader.getReturnCode());
                response.setReturnMessage(responseHeader.getReturnMessage());

            }
            return Mono.just(response);
        });
    }

    private ProductInquiryEPSRequest convertUIRequestToEPS(ProductInquiryUIRequest request, String channel) {
        logger.info("Converting ProductInquiryUIRequest to ProductInquiryEPSRequest");
        ProductInquiryEPSRequest epsRequest = new ProductInquiryEPSRequest();
        DeviceServiceHeader serviceHeader = new DeviceServiceHeader();
        serviceHeader.setClientId(channel);
        serviceHeader.setOperation("AvailableClassOfServices");
        serviceHeader.setServiceName("PRODUCTINQUIRY");
        epsRequest.setServiceHeader(serviceHeader);
        List<EPSDeviceRequestList> epsRequestList = new ArrayList<EPSDeviceRequestList>();
        EPSDeviceRequestList epsDeviceRequestList = new EPSDeviceRequestList();
        epsDeviceRequestList.setSequenceNumber("1");
        EPSDeviceRequest epsDeviceRequest = new EPSDeviceRequest();
        EPSDeviceDetails epsDeviceDetails = new EPSDeviceDetails();
        epsDeviceRequest.setAccountRole("Owner");
        if(StringUtilities.isNotEmptyOrNull(request.getDeviceId()))
        {
            epsDeviceDetails.setDeviceId(request.getDeviceId());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getIccId()))
        {
            epsDeviceDetails.setIccId(request.getIccId());
        }
        epsDeviceRequest.setDeviceDetails(epsDeviceDetails);
        epsDeviceRequest.setIncludeCurrentProducts("Y");
        epsDeviceRequest.setIncludeGrandFatheredProducts("N");
        epsDeviceRequest.setLineNumber("1");
        epsDeviceRequestList.setRequest(epsDeviceRequest);
        epsRequestList.add(epsDeviceRequestList);
        epsRequest.setRequests(epsRequestList);;
        return epsRequest;
    }
}
