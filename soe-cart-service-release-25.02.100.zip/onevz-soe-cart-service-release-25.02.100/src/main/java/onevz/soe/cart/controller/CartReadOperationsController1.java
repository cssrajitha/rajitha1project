package onevz.soe.cart.controller;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.constants.FeatureFlagConstants;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.exceptions.JsonValidator;
import onevz.soe.cart.gql.schema.bundlebuildercartlightweight.PromoHubOffer;
import onevz.soe.cart.gql.schema.customerByMtn.BillAccountForCustomerProfile;
import onevz.soe.cart.gql.schema.customerByMtn.MtnsListForCustomerProfile;
import onevz.soe.cart.helper.*;
import onevz.soe.cart.model.addTrialContactInfoAndAddress.AddTrialContactInfoAndAddressUIRequest;
import onevz.soe.cart.model.bundleBuilderCart.BundleBuilderCXPCartDataVO;
import onevz.soe.cart.model.bundleBuilderCart.BundleBuilderCXPCartItem;
import onevz.soe.cart.model.bundleBuilderCart.BundleBuilderCXPCartVO;
import onevz.soe.cart.model.checkExistingCart.CheckExistingCartContext;
import onevz.soe.cart.model.checkExistingCart.CheckExistingCartServiceBody;
import onevz.soe.cart.model.checkExistingCart.CheckExistingCartServiceResponse;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.deviceSimValidation.CustomerReqType;
import onevz.soe.cart.model.deviceSimValidation.DeviceSimValidationEquipmentInfos;
import onevz.soe.cart.model.deviceSimValidation.DeviceSimValidationUIResponseData;
import onevz.soe.cart.model.initiateValidateDeviceSim.InitiateValidateDeviceSimUIRequest;
import onevz.soe.cart.requests.AbandonCartSOERequest;
import onevz.soe.cart.requests.BundleBuilderRequest;
import onevz.soe.cart.requests.ValidateSecureTokenRequest;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.ui.requests.CheckExistingCartUIRequest;
import onevz.soe.cart.ui.requests.DeviceSimValidationUIRequest;
import onevz.soe.cart.ui.requests.GetParentLinesUIRequest;
import onevz.soe.cart.ui.requests.GuestChoiceUIRequest;
import onevz.soe.cart.ui.responses.CheckExistingCartUIResponse;
import onevz.soe.cart.ui.responses.CustomerByMtnUIResponse;
import onevz.soe.cart.ui.responses.DeviceSimValidationUIResponse;
import onevz.soe.cart.ui.responses.v2.FlagDetails;
import onevz.soe.cart.util.*;
import onevz.soe.exception.SOEException;
import onevz.soe.orderprocess.translator.BundleBuilderResponse;
import onevz.soe.orderprocess.translator.model.CartLW;
import onevz.soe.orderprocess.translator.model.DataLW;
import onevz.soe.orderprocess.translator.model.LineDetailsLW;
import onevz.soe.orderprocess.translator.model.NewLineLW;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.bpm.model.request.ContextInfo;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import java.time.Duration;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import onevz.cxp.feature.ConfigurationProfile;
import onevz.cxp.feature.Flag;
import reactor.util.function.Tuple3;
import reactor.util.function.Tuple4;
import reactor.util.function.Tuple6;

import static onevz.soe.cart.constants.CartConstants.PROMOTION_ID_START_WITH_PROMO;

/**
 * Cart Controller class.
 */
@RestController
@RequestMapping(value = "cart")
public class CartReadOperationsController1 {
    
    
    private static final Logger logger = LoggerFactory.getLogger(CartReadOperationsController1.class);

    @Autowired
    private UpdateCartHelper helper;

    @Autowired
    private CartServiceCxpHelper cartSvcCXPHelper;

    @Autowired
    private ReadCartHelper readCartHelper;

    @Autowired
    private RedisHelper redisHelper;
    @Autowired
    private RedisHelper2 redisHelper2;
    @Autowired
    private RedisHelper3 redisHelper3;

    @Autowired
    private Environment environment;

    @Autowired
    JsonValidator validator;

    @Autowired
    FeatureFlagHelper featureFlagHelper;

    @Value("${soe.bbp.byou.whitelistedIMEIS:}")
    public List<String> whitelistedIMEIS;

    @Value("#{'${soe.cart.promochoice.pdpOffersTypeList:}'.split(',')}")
    private List<String> promoChoiceOfferTypeList;

    @Value("${soe.cart.promoChoiceEnabled:false}")
    private boolean promoChoiceEnabled;

    @Value("#{'${sessionCreation.domains:.verizon.com}'.split(',')}")
    private List<String> domains;


    /**
     *
     * @param binder
     */
    @InitBinder("*")
    public void initBinderByName(WebDataBinder binder) {
        binder.setDisallowedFields(new String[] { "genericHeader" });
    }



    /**
     *
     * @param httpHeader
     * @param httpResponse
     * @param request
     * @return ResponseEntity
     *
     */
    @PostMapping(value = {"/promoBundleBuilder-cart", "/nse/promoBundleBuilder-cart"})
    public Mono<GenericResponse> bundleBuilderCart(ServerHttpRequest httpHeader,
                                                   ServerHttpResponse httpResponse, @Valid @RequestBody BundleBuilderRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "promoBundleBuilder-cart");
        logger.debug("promoBundleBuilder-cart Request: {}", request);
        logger.info("Inside promoBundleBuilder-cart api");

        return redisHelper.getDataFromRedis().flatMap(redisData -> {
            if(StringUtilities.isNotEmptyOrNull(redisData.getCartId())) {
                request.setCartId(redisData.getCartId());
                if(httpHeader.getHeaders() != null) {
                    List<String> channelIdList = httpHeader.getHeaders().get(CartConstants.CHANNEL_ID);
                    if (CollectionUtilities.isNotEmptyOrNull(channelIdList)){
                        request.setChannelId(channelIdList.get(0));
                    }
                }
                if(StringUtilities.isNotEmptyOrNull(redisData.getAccountNumber())){
                    request.setAccountNumber(redisData.getAccountNumber());
                }
                if(StringUtilities.isNotEmptyOrNull(redisData.getMtn())){
                    request.setMtn(redisData.getMtn());
                }
                if( StringUtilities.isEmptyOrNull(request.getProcessingMtn()) && StringUtilities.isNotEmptyOrNull(redisData.getProcessingMTN())){
                    request.setProcessingMtn(redisData.getProcessingMTN());
                }
                Mono<BundleBuilderResponse> promoBundleBuilder = readCartHelper.bundleBuilderCart(request).flatMap(respObj -> {
                    removeSensitiveDataForPromoBuilder(request, respObj);
                    Optional<String> productName = Optional.empty();
                    if (respObj != null && respObj.getData() != null &&
                            respObj.getData().getPromoBundleBuilderCart() != null) {
                        try {
                            cartSvcCXPHelper.updateDLData(null, null, "PromoBundleBuilder", null, respObj, null);
                            productName = readCartHelper.getProductNameByMTN(request.getProcessingMtn(), respObj.getData().getPromoBundleBuilderCart());
                        } catch (Exception e) {
                            logger.error(CartConstants.RETRIEVE_OMNIDL_EXCEPTION, e);
                        }
                    }
                    BundleBuilderResponse bundleBuilderResponse = BundleBuilderDetailsTranslator.translateBundleBuilderDetails(respObj);
                    productName.ifPresent(s -> bundleBuilderResponse.getData().getCart()
                            .getLineDetails().setCurrentLineTradeInProductName(s));
                    return mergeFeatureFlagWithResponse(Mono.zip(Mono.just(bundleBuilderResponse),
                    		featureFlagHelper.fetchDigitalPerformanceCfgProfile(),
                            featureFlagHelper.fetchDigitalPromosCfgProfile(Arrays.asList(FeatureFlagConstants.DIGITAL_PROMOS_CFG_LIST.split(CartConstants.COMMA))),
                            featureFlagHelper.fetchDigitalUpgradeCfgProfile(Arrays.asList(FeatureFlagConstants.PROMO_INTENT_MAP_LIST.split(CartConstants.COMMA))),
                            featureFlagHelper.fetchMarketingCfgProfile(Arrays.asList(FeatureFlagConstants.APPLE_ONE_CFG_LIST.split(CartConstants.COMMA))),
                            featureFlagHelper.fetchMarketingChoiceCfrProfile(Arrays.asList(FeatureFlagConstants.BYOD_CFG_LIST.split(CartConstants.COMMA))))).onErrorReturn(bundleBuilderResponse);
                });
                return filterPromoChoiceOffers(promoBundleBuilder,request)
                        .flatMap(resp -> {
                            return readCartHelper.upgradeAutoTradeInFlow(resp, httpHeader, httpResponse, request);
                        });
            }else{
                ErrorResponse errors5 = new ErrorResponse();
                CartError error = new CartError();
                List<CartError> errorList = null;
                errorList = new ArrayList<CartError>();
                error.setNamespace(CartConstants.SOE_CART_SERVICE);
                error.setMessage(CartConstants.CART_ID_MISSING);
                error.setName(CartConstants.API_ERROR);
                error.setId(CartConstants.CART_ID_MISSING_CODE);
                errorList.add(error);
                errors5.setErrors(errorList);
                return Mono.just(errors5);
            }
        }).onErrorResume(err -> {
            ErrorResponse errors5 = new ErrorResponse();
            SOEException exception = (SOEException) err;
            List<CartError> errors = new ArrayList<>();
            if(null != exception.getErrorHolder() && null != exception.getErrorHolder().getErrors()){
                exception.getErrorHolder().getErrors().forEach(cartError -> {
                    CartError error = new CartError();
                    error.setMessage(cartError.getMessage());
                    error.setId(cartError.getId());
                    error.setNamespace(cartError.getNamespace());
                    error.setName(cartError.getName());
                    error.setDebug_id(cartError.getDebug_id());
                    errors.add(error);
                });
            }
            errors5.setErrors(errors);
            return Mono.just(errors5);
        });
    }
    private Mono<BundleBuilderResponse> filterPromoChoiceOffers(Mono<BundleBuilderResponse> promoBundleBuilder, BundleBuilderRequest request) {
        return promoBundleBuilder
                .flatMap(bundleBuilderResponse -> {
                    if(request.isPromoChoiceOffer() && !CartConstants.NOPROMO.equalsIgnoreCase(request.getSelectedOfferId())) {
                        Optional.ofNullable(bundleBuilderResponse.getData())
                                .map(DataLW::getCart)
                                .map(CartLW::getLineDetails)
                                .map(LineDetailsLW::getLineInfo)
                                .ifPresent(mapLines -> Optional.ofNullable(mapLines)
                                        .orElse(Collections.emptyMap())
                                        .entrySet()
                                        .stream()
                                        .filter(Objects::nonNull)
                                        .forEach(newLineLWEntry -> Optional.ofNullable(newLineLWEntry.getValue())
                                                .map(NewLineLW::getDeviceItem)
                                                .map(BundleBuilderCXPCartItem::getPromoHubOfferList)
                                                .ifPresent(promoHubOfferNode -> {
                                                    List<PromoHubOffer> promoHubOfferList = promoHubOfferNode.getPromoHubOfferList();
                                                    if (CollectionUtils.isNotEmpty(promoHubOfferList)) {
                                                        filterPdpPromoChoiceOffers(promoHubOfferList, request);
                                                        promoHubOfferNode.setOfferCount(promoHubOfferList.size());
                                                    }
                                                })));
                    }
                        return Mono.just(bundleBuilderResponse);
                });
    }


    private Predicate<PromoHubOffer> isPromoChoiceOffer() {
        return data -> Optional.ofNullable(data.getPromoBadges())
                .orElse(Collections.emptyList())
                .stream()
                .filter(Objects::nonNull)
                .anyMatch(promoBadgeMessages -> BooleanUtils.isTrue(promoBadgeMessages.getChoiceOffer()));
    }
    private void filterPdpPromoChoiceOffers(@NotNull List<PromoHubOffer> promoHubOfferList, BundleBuilderRequest request) {
        String selectedOfferId = request.getSelectedOfferId();
        if(promoChoiceEnabled) {
            String filterPromoChoiceList = promoHubOfferList
                    .stream()
                    .filter(Objects::nonNull)
                    .filter(promoHubOffer -> StringUtils.isNotBlank(promoHubOffer.getOfferId()))
                    .map(promoHubOffer -> isPromoChoiceOffer().test(promoHubOffer) ? promoHubOffer.getOfferId() : "NA")
                    .filter(promoHubOfferId -> !promoHubOfferId.equals(selectedOfferId) && !StringUtils.equalsAnyIgnoreCase(promoHubOfferId, "NA"))
                    .filter(StringUtils::isNoneBlank)
                    .collect(Collectors.joining(","));
            logger.info("CartReadOperationsController1:: filterPdpPromoChoiceOffers OffersIdExcludes {}", filterPromoChoiceList);
            if(StringUtils.isNotBlank(selectedOfferId)) {
                promoHubOfferList
                        .removeIf(promoHubOffer -> StringUtils.equalsAnyIgnoreCase(promoHubOffer.getOfferId(), filterPromoChoiceList.split(",")));
            }
        } else {
            Set<String> excludePromoTypeList = promoChoiceOfferTypeList
                    .stream()
                    .filter(data -> !data.equalsIgnoreCase(request.getSelectedOfferType()))
                    .collect(Collectors.toSet());
            logger.info("CartReadOperationsController1:: filterPdpPromoChoiceOffers promoChoiceOfferTypeList {}", excludePromoTypeList);
            if (StringUtils.isNotBlank(selectedOfferId)) {
                promoHubOfferList
                        .removeIf(
                                promoHubOffer -> selectOfferId(selectedOfferId).test(promoHubOffer)
                                                && (StringUtils.isNotBlank(promoHubOffer.getPromoType())
                                                && !helper.isNotNFL(promoHubOffer)
                                                && !helper.isthirdpartyFeaturePromo(promoHubOffer)
                                                && excludePromoTypeList.contains(promoHubOffer.getPromoType()))
                        );
                setSelectedOfferBackToPromoHub(promoHubOfferList, selectedOfferId);
            }
    }
    }

    /**
     *  Added promoOfferId If it matches with ui selectedId.
     * @param promoHubOfferList List<{@link PromoHubOffer}
     * @param selectedOfferId String selectedOfferId
     */
    private  void setSelectedOfferBackToPromoHub(List<PromoHubOffer> promoHubOfferList, String selectedOfferId) {
        promoHubOfferList.stream()
                .filter(Objects::nonNull)
                .filter(data -> (StringUtils.startsWith(selectedOfferId,PROMOTION_ID_START_WITH_PROMO) && selectedOfferId.equals(data.getPromotionId()))
                        || StringUtils.equals(selectedOfferId, data.getOfferId()))
                .forEach(data -> {
                    data.setSelectedOfferId(StringUtils.startsWith(selectedOfferId,PROMOTION_ID_START_WITH_PROMO) ? data.getPromotionId(): data.getOfferId());
                });
    }

    /**
     *  Predicate For SelectedOfferId Which Comes Form UI.
     * @param selectedOfferId String selectedOfferId
     * @return True if is not matches which ui selectedId with promotionId or OfferId.
     */
    private  Predicate<PromoHubOffer> selectOfferId(String selectedOfferId){
        return data -> StringUtils.isNotBlank(data.getOfferId()) && !StringUtils.equals(selectedOfferId,data.getOfferId())
                || StringUtils.isNotBlank(data.getPromotionId()) && !StringUtils.equals(selectedOfferId,data.getPromotionId());
    }

    private void removeSensitiveDataForPromoBuilder(BundleBuilderRequest request, BundleBuilderCXPResponseData respObj) {
        if(CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))){
            Optional<BundleBuilderCXPCartVO> bundleBuilderCXPCartVoOptional = Optional.of(respObj).map(BundleBuilderCXPResponseData::getData).map(BundleBuilderCXPCartDataVO::getPromoBundleBuilderCart);
            bundleBuilderCXPCartVoOptional.ifPresent(promoBundleBuilderCart -> promoBundleBuilderCart.setCartId(null));
            bundleBuilderCXPCartVoOptional.map(BundleBuilderCXPCartVO::getCartHeader).ifPresent(bundleCartHeader -> {
                bundleCartHeader.setCartId(null);
                bundleCartHeader.setFullAccountNumber(null);
                bundleCartHeader.setCaseId(null);
            });
        }
    }

    /**
     *
     * @param httpHeader
     * @param httpResponse
     * @param request
     * @return ResponseEntity
     *
     */
    @PostMapping({ "/nse/abandon-cart" })
    public Mono<RetrieveLatestDeviceCXPResponse> nseAbandonCart(ServerHttpRequest httpHeader,
                                                                ServerHttpResponse httpResponse, @Valid @RequestBody AbandonCartSOERequest request) {
        return readCartHelper.retrieveCartAbandon(httpResponse,request);
    }

    /**
     *
     * @param httpHeader
     * @param httpResponse
     * @param request
     * @return ResponseEntity
     */
    @PostMapping({ "/nse/abandonCartNextGen" })
    public Mono<RetrieveNextGenCXPResponse> abandonCartNextGen(ServerHttpRequest httpHeader,
                                                               ServerHttpResponse httpResponse, @Valid @RequestBody AbandonCartSOERequest request) {
        return readCartHelper.retrieveNextGenCartAbandon(httpResponse,request, httpHeader);
    }

    /**
     *
     * @param httpHeader
     * @param httpResponse
     * @param request
     * @return ResponseEntity
     */

    @PostMapping("/check-existingCart")
    public Mono<ResponseEntity<GenericResponse>> checkExistingCartSignIn(ServerHttpRequest httpHeader,
                                                                         ServerHttpResponse httpResponse, @Valid @RequestBody CheckExistingCartUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "guest-choice");
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);
        logger.debug("check-existingCart Request: {}", request);
        ErrorResponse errors = CartPegaRequestErrorsUtil.handleCheckExistingCartRequestErrors(request);
        if (errors.getErrors() != null) {
            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
        }
        return readCartHelper.checkExistingCartFromPega(request).flatMap(resp -> {
            logger.info("Pega response {}", resp);
            ErrorResponse errors1 = null;
            if (resp.getErrors() != null) {
                errors1 = CartPegaResponseErrorsUtil2.handleCheckExistingCartResponseErrors(resp);
                return  Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(errors1));
            }else {
                String processStep = Optional.ofNullable(resp)
                        .map(CheckExistingCartUIResponse::getServiceBody)
                        .map(CheckExistingCartServiceBody::getServiceResponse)
                        .map(CheckExistingCartServiceResponse::getContext)
                        .map(CheckExistingCartContext::getContextInfo).map(ContextInfo::getProcessStep).orElse(null);
                if(StringUtilities.isNotEmptyOrNull(processStep) && (processStep.equalsIgnoreCase(CartConstants.ORDER_REVIEW_SHIPMENT_PAYMENT_AGREEMENT)
                        || processStep.equalsIgnoreCase(CartConstants.ACCESSORIES_INTERSTIAL))){
                    redisHelper2.deleteSessionDataKeyFromRedis(CartConstants.PROSPECT_CARTID);
                }
                Mono<Boolean> redisCartIdFlag= redisHelper2.upsertValueInRedis("cartId",resp.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartId());
                return redisCartIdFlag.flatMap(redisFlag -> {
                    logger.info(String.format("Upsert cartId into redis %s", redisFlag));
                    if(redisFlag) {
                        Mono<Boolean> redisCaseIdFlag= redisHelper2.upsertValueInRedis(CartConstants.CASE_ID,resp.getServiceBody().getServiceResponse().getContext().getCaseId());
                        return redisCaseIdFlag.flatMap(redisFlagCaseId->{
                            logger.info(String.format("Upsert caseId into redis %s", redisFlagCaseId));
                            Mono<Boolean> redisIntendTypeFlag= redisHelper2.upsertValueInRedis(CartConstants.INTEND_TYPE,"ACC");
                            return redisIntendTypeFlag.flatMap(redisFlagIntendType->{
                                logger.info(String.format("Upsert intendtype into redis %s", redisFlagIntendType));
                                Mono<Boolean> redisIntentTypeFlag= redisHelper2.upsertValueInRedis("intentType","ACC");
                                return redisIntentTypeFlag.flatMap(redisFlagIntentType->{
                                    logger.info(String.format("Upsert intenttype into redis %s", redisFlagIntentType));
                                    boolean isHubProspectCartCookieDomainIssueFFlagEnabled= featureFlagHelper.isHubProspectCartCookieDomainIssueFFlagEnabled();
                                    CartUtil.addHubProspectCartCookieToResponse(httpResponse, isHubProspectCartCookieDomainIssueFFlagEnabled, CartConstants.FALSE, domains);
                                    return Mono.just(ResponseEntity.status(HttpStatus.OK).body(resp));
                                });
                            });
                        });
                    }
                    return Mono.just(ResponseEntity.status(HttpStatus.OK).body(resp));
                });
            }

        });
    }


    //VZWYN-17463 changes
    @PostMapping("/addTrialContactInfoAndAddress")
    public Mono<ResponseEntity<GenericResponse>> addTrialContactInfoAndAddress(ServerHttpRequest httpHeader,
                                                                               ServerHttpResponse httpResponse, @Valid @RequestBody AddTrialContactInfoAndAddressUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "addTrialContactInfoAndAddress");
        logger.debug("AddTrialContactInfoAndAddress UI Request: {}", request);
        // Read the channelId from header
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        if(StringUtilities.isNotEmptyOrNull(channelId) && request!=null && request.getData()!=null) {
            request.getData().setChannelId(channelId);
        }
        return redisHelper.getDataFromRedis().flatMap(redisData-> {
            ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddTrialContactInfoAndAddressRequestErrors(request);
            if (errors.getErrors() != null) {
                return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
            }
            return readCartHelper.addTrialContactInfoAndAddress(request, redisData).map(resp -> {
                ErrorResponse errors2 = null;
                if (resp.getErrors() != null) {
                    errors2 = CartPegaResponseErrorsUtil2.handleAddTrialContactInfoAndAddressResponseErrors(resp);
                }
                return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                        : ResponseEntity.status(HttpStatus.OK).body(resp);
            });
        });
    }


    //VZWYN-20895 changes
    @PostMapping("/initiateValidateDeviceSim")
    public Mono<ResponseEntity<GenericResponse>> initiateValidateDeviceSim(ServerHttpRequest httpHeader,
                                                                           ServerHttpResponse httpResponse, @Valid @RequestBody InitiateValidateDeviceSimUIRequest request) {


        System.setProperty(CartConstants.ENDPOINT, "initiateValidateDeviceSim");
        logger.info("initiateValidateDeviceSim Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID) ?
                httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID) : "";

        ErrorResponse errors = CartCxpRequestErrorsUtil.handleCustomerNameByMtnRequestErrors(request);
        if (errors.getErrors() != null)
            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));

        return redisHelper.getDataFromRedis().flatMap(redisData -> {
            logger.info("getDataFromRedis: {}", redisData);
            logger.info("imsi from redis: {}", redisData.getImsi());
            logger.info("imei from redis: {}", redisData.getBbpImei());
            //resolving duplication
            if(StringUtilities.isNotEmptyOrNull(redisData.getRole()) && redisData.getRole().equalsIgnoreCase(CartConstants.MOBILE_SECURE))
                return Mono.just(ResponseEntity.status(HttpStatus.OK).body(settingErrorData(CartConstants.MOBILESECUREERRORCODE)));
            //resolving duplication
            if(redisData.getIsValidCustomer()!=null && !redisData.getIsValidCustomer())
                return Mono.just(ResponseEntity.status(HttpStatus.OK).body(settingErrorData(CartConstants.ISVALIDCUSTOMERERRORCODE)));
            return helper.customerNameByMtn(redisData.getMtn()).flatMap(cxpResponse -> {
                logger.info("customerNameByMtn final response: {}", cxpResponse);

                ErrorResponse errors2 = null;
                if (cxpResponse.getErrors() != null)
                    errors2 = CartCxpResponseErrorsUtil.handleCustomerNameByMtnResponseErrors(cxpResponse);
                else {
                    String greetingName = cxpResponse.getGreetingName();
                    String imei = redisData.getBbpImei();
                    logger.info("greetingName: {}", greetingName);

                    return helper.initiateValidateDeviceSim(request, httpHeader, redisData).flatMap(resp -> {
                        logger.info("initiateValidateDeviceSim UI response: {}", resp);


                        resp.setGreetingName(greetingName);
                        resp.setDeviceType(CartConstants.CONNECTED_CAR);

                        ErrorResponse errors3 = null;
                        if (resp.getErrors() != null) {
                            errors3 = CartPegaResponseErrorsUtil2.handleInitiateValidateDeviceSimResponseErrors(resp);
                        }
                        //hiding sensitive data
                        if(null != resp && null != resp.getServiceBody() && null != resp.getServiceBody().getServiceResponse() && null != resp.getServiceBody().getServiceResponse().getContext() && null != resp.getServiceBody().getServiceResponse().getContext().getCartInfo() && null != resp.getServiceBody().getServiceResponse().getContext().getDeviceInfo()){
                            if(StringUtilities.isNotEmptyOrNull(resp.getServiceBody().getServiceResponse().getContext().getCaseId()) && StringUtilities.isNotEmptyOrNull(resp.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartId()) && StringUtilities.isNotEmptyOrNull(resp.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getCCarSecureWifiFlag())
                                    && StringUtilities.isNotEmptyOrNull(resp.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getCCarTrialflag()) && StringUtilities.isNotEmptyOrNull(resp.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getCCARWifiState())){
                                Mono<Boolean> redisCartIdFlag= redisHelper2.upsertValueInRedis("cartId",resp.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartId());
                                return redisCartIdFlag.flatMap(redisFlag -> {
                                    logger.info("Upsert cartId into redis {}", redisFlag);
                                    resp.getServiceBody().getServiceResponse().getContext().getCartInfo().setCartId("");
                                    Mono<Boolean> redisCaseIdFlag = redisHelper2.upsertValueInRedis(CartConstants.CASE_ID, resp.getServiceBody().getServiceResponse().getContext().getCaseId());
                                    return redisCaseIdFlag.flatMap(redisFlagCaseId -> {
                                        logger.info("Upsert caseId into redis {}", redisFlagCaseId);
                                        resp.getServiceBody().getServiceResponse().getContext().setCaseId("");
                                        Mono<Boolean> redisDeviceTypeFlag = redisHelper2.upsertValueInRedis("bbpDeviceType", resp.getDeviceType());
                                        return redisDeviceTypeFlag.flatMap(redisDeviceType -> {
                                            logger.info("Upsert deviceType into redis {}", redisDeviceType);
                                            Mono<Boolean> rediscCarWifiStateFlag = redisHelper2.upsertValueInRedis("ccarWifiState", resp.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getCCARWifiState());
                                            return rediscCarWifiStateFlag.flatMap(rediscCarWifiState -> {
                                                logger.info("Upsert ccarWifiState into redis {}", resp.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getCCARWifiState());
                                                Mono<Boolean> rediscCarTrialFlag = redisHelper2.upsertValueInRedis("ccarTrialFlag", resp.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getCCarTrialflag());
                                                return rediscCarTrialFlag.flatMap(rediscCarTrialNode -> {
                                                    logger.info("Upsert rediscCarTrialNode into redis {}", resp.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getCCarTrialflag());
                                                    Mono<Boolean> rediscCarSecureWifiFlag = redisHelper2.upsertValueInRedis("ccarSecureWifiFlag", resp.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getCCarSecureWifiFlag());
                                                    return rediscCarSecureWifiFlag.flatMap(rediscCarSecureWifiNode -> {
                                                        logger.info("Upsert rediscCarSecureWifiNode into redis {}", resp.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getCCarSecureWifiFlag());
                                                        //NSADT-145273 changes
                                                        Mono<Boolean> redisBrandNameFlag = redisHelper2.upsertValueInRedis(CartConstants.BRAND_NAME, resp.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getBrandName());
                                                        return redisBrandNameFlag.flatMap(brandNameFlag -> {
                                                            logger.info("upsert brandName into redis success {}", brandNameFlag);
                                                            logger.info("Upsert brandName into redis value {}", resp.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getBrandName());
                                                            logger.info("initiateValidateDeviceSim final UI response: {}", resp);
                                                            return Mono.just(ResponseEntity.status(HttpStatus.OK).body(resp));
                                                        });
                                                    });
                                                });
                                            });
                                        });
                                    });
                                });
                            }
                        }

                        return errors3 != null ? Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(errors3))
                                : Mono.just(ResponseEntity.status(HttpStatus.OK).body(resp));
                    });
                }
                return errors2 != null ? Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(errors2))
                        : Mono.just(ResponseEntity.status(HttpStatus.OK).body(cxpResponse));
            });
        });
    }



    /**
     * @param httpHeader the http header
     * @param httpResponse the http response
     * @param request the request
     * @return the mono
     */

    @PostMapping("/getParentLines")
    public Mono<ResponseEntity<GenericResponse>> getParentLines (ServerHttpRequest httpHeader,
                                                                 ServerHttpResponse httpResponse, @Valid @RequestBody GetParentLinesUIRequest request) {
        logger.info("Inside the api");
        System.setProperty(CartConstants.ENDPOINT, "getParentLines");
        logger.debug("getParentLines Request: {}", request);
        String mtn = null;
        if(request!=null){
            mtn = httpHeader.getHeaders().getFirst("mtn");
        }
        return readCartHelper.customerByMtnForParentLines(mtn).flatMap(customerData -> {
            if (customerData.getErrors() != null || customerData.getData() == null) {
                ErrorResponse errors = null;
                errors = CartCxpResponseErrorsUtil.handleCustomerByMtnForParentLinesResponseErrors(customerData);
                return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
            }
            return Mono.just(ResponseEntity.status(HttpStatus.OK).body(customerData));
        });
    }


    /**
     *
     * @param httpHeader
     * @param httpResponse
     * @param request
     * @return ResponseEntity
     *
     */
    @PostMapping("/nse/guest-choice")
    public Mono<ResponseEntity<GenericResponse>> guestChoiceFromCart(ServerHttpRequest httpHeader,
                                                                     ServerHttpResponse httpResponse, @Valid @RequestBody GuestChoiceUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "guest-choice");
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);
        String sessionId = "";
        HttpCookie cookieDigitIgSesssion = httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION);
        if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId))
                || CartConstants.EXPRESS_STORE.equalsIgnoreCase(CartUtil.getChannelType(channelId)))
            sessionId = null != cookieDigitIgSesssion
                    ? cookieDigitIgSesssion.getValue()
                    : "";
        if (StringUtilities.isNotEmptyOrNull((sessionId))) {
            request.getCartInfo().setCartCreator(sessionId);
            request.getCartInfo().setGlobalId(sessionId);
        }
        logger.debug("guest-choice Request: {}", request);
        ErrorResponse errors = CartPegaRequestErrorsUtil.handleGuestChoiceRequestErrors(request);
        if (errors.getErrors() != null) {
            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
        }
        return readCartHelper.guestChoiceFromPega(request).map(resp -> {
            ErrorResponse errors2 = null;
            if (resp.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil2.handleGuestChoiceResponseErrors(resp);
            }
            if(resp!=null && resp.getServiceBody()!=null && resp.getServiceBody().getServiceResponse()!=null && resp.getServiceBody().getServiceResponse().getContext()!=null) {
                resp.getServiceBody().getServiceResponse().getContext().setCaseId(null);
                if(resp.getServiceBody().getServiceResponse().getContext().getCartInfo()!=null) {
                    resp.getServiceBody().getServiceResponse().getContext().getCartInfo().setCartId(null);
                }
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(resp);
        });
    }

    //VZWCS-17115 changes - end

    @PostMapping({ "/deviceSimValidation", "/nse/deviceSimValidation" })
    public Mono<ResponseEntity<GenericResponse>> deviceSimValidation(ServerHttpRequest httpHeader,
                                                                     ServerHttpResponse httpResponse,
                                                                     @Valid @RequestBody(required = false) DeviceSimValidationUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "deviceSimValidation");
        logger.debug("deviceId-simIdValidation Request: {}", request);

        if (null == request && StringUtilities.isEmptyOrNull(httpHeader.getQueryParams().getFirst(CartConstants.RPS_FLOW_TOKEN))) {
            ErrorResponse errors4 = CartCxpRequestErrorsUtil.handleTokenAndRequestEmptyErrors(request,
                    httpHeader.getQueryParams().getFirst(CartConstants.RPS_FLOW_TOKEN));
            if (errors4.getErrors() != null)
                return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors4));
        }

        ValidateSecureTokenRequest validateSecureTokenRequest = new ValidateSecureTokenRequest();
        validateSecureTokenRequest.setIntent(CartConstants.BBP_INTENT_ORDERSELFSERVICE);
        validateSecureTokenRequest.setToken("");
        if (StringUtilities.isNotEmptyOrNull(httpHeader.getQueryParams().getFirst(CartConstants.RPS_FLOW_TOKEN))) {
            validateSecureTokenRequest.setToken(httpHeader.getQueryParams().getFirst(CartConstants.RPS_FLOW_TOKEN));
        } else {
            if (null != request && StringUtilities.isNotEmptyOrNull(request.getToken())) {
                validateSecureTokenRequest.setToken(request.getToken());
            }
        }

        if (StringUtilities.isNotEmptyOrNull(httpHeader.getQueryParams().getFirst(CartConstants.RPS_FLOW_TOKEN))
                || ( null != request && StringUtilities.isNotEmptyOrNull(request.getToken()))) {

            logger.debug("ValidateSecureTokenRequest Request: {}", validateSecureTokenRequest);

            ErrorResponse errors1 = CartCxpRequestErrorsUtil.handleValidateTokenRequestErrors(
                    validateSecureTokenRequest, environment.getProperty("IG.PROSPECT.JWT.validateSecureToken.URL"),
                    environment.getProperty("IG.prospect.validateSecureTokenUsername"),
                    environment.getProperty("IG.prospect.validateSecureTokenPassword"));
            if (errors1.getErrors() != null)
                return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors1));

            // IG Call for validateSecureToken Service
            request = readCartHelper.validateSecureToken(validateSecureTokenRequest);

            ErrorResponse errors3 = null;
            if (request.getResponse() != null) {
                errors3 = CartCxpResponseErrorsUtil.handleValidateSecureTokenResponseErrors(request);
                errors3 = validator.convertObjectToString(errors3);
                return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors3));
            }
        }
        Mono<DeviceSimValidationUIRequest> deviceSimValidationUIRequest = settingData(request);
        return deviceSimValidationUIRequest.flatMap(deviceSimRequest -> {
            ErrorResponse errors = CartCxpRequestErrorsUtil.handleDeviceSimValidationRequestErrors(deviceSimRequest);
            if (errors.getErrors() != null)
                if (errors.getErrors() != null)
                    return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
            return redisHelper.getDataFromRedis().flatMap(data -> {
                logger.info("deviceSimValidation getDataFromRedis {}", data);
                logger.info("Companion phone number from Redis: {}",data.getCompanionPhoneNumber());
                String flowPath1 = String.valueOf(httpHeader.getPath());
                //resolving duplication
                if(StringUtilities.isNotEmptyOrNull(data.getRole()) && data.getRole().equalsIgnoreCase(CartConstants.MOBILE_SECURE) && StringUtilities.isNotEmptyOrNull(data.getEsimType()) && !CartConstants.IPAD.equalsIgnoreCase(data.getEsimType()))
                    return Mono.just(ResponseEntity.status(HttpStatus.OK).body(settingErrorData(CartConstants.MOBILESECUREERRORCODE)));
                //resolving duplication
                if(data.getIsValidCustomer()!=null && !data.getIsValidCustomer())
                    return Mono.just(ResponseEntity.status(HttpStatus.OK).body(settingErrorData(CartConstants.ISVALIDCUSTOMERERRORCODE)));
                String imeiForWhitelistCheck=StringUtilities.isNotEmptyOrNull(data.getBbpImei())?data.getBbpImei():data.getImei();
                addingCookiesForWhitelistingIMEIs(imeiForWhitelistCheck, httpResponse);

                CustomerByMtnUIResponse response = new CustomerByMtnUIResponse();
                Mono<CustomerByMtnUIResponse> custData = Mono.just(response) ;
                if(!flowPath1.contains("/nse/deviceSimValidation")) {
                    CustomerReqType reqType = new CustomerReqType();
                    if(StringUtilities.isNotEmptyOrNull(data.getBbpImei()) && StringUtilities.isNotEmptyOrNull(data.getEid())){
                        reqType.setDeviceId(data.getBbpImei());
                    }
                    if(StringUtilities.isNotEmptyOrNull(data.getImei()) && StringUtilities.isNotEmptyOrNull(data.getEid())){
                        reqType.setDeviceId(data.getImei());
                    }
                    if(StringUtilities.isNotEmptyOrNull(data.getMtn())){
                        reqType.setLookupMtn(data.getMtn());
                    }

                    custData = readCartHelper.customerByMtn(reqType);
                }
                return	custData.flatMap(customerData -> {
                    if (customerData.getErrors() != null) {
                        ErrorResponse errors5 = null;
                        errors5 = CartCxpResponseErrorsUtil.handleCustomerByMtnResponseErrors(customerData);
                        return Mono.just(ResponseEntity.status(HttpStatus.OK).body(errors5));
                    }
                    String esimFlowType =CartConstants.IPAD.equalsIgnoreCase(data.getEsimType()) || CartConstants.LAPTOP.equalsIgnoreCase(data.getEsimType())? CartConstants.ACTIVATION: "";
                    String pendingMdn = "";
                    String activationCode = "";
                    String profileState = "";
                    String esimIccid = "";

                    List<MtnsListForCustomerProfile> mtnList = new ArrayList<>();
                    if(customerData!=null && customerData.getData()!=null && customerData.getData().getCustomerProfile()!=null && CollectionUtilities.isNotEmptyOrNull(customerData.getData().getCustomerProfile().getBillAccounts())){
                        BillAccountForCustomerProfile billAccount = customerData.getData().getCustomerProfile().getBillAccounts().get(0);
                        if(CollectionUtilities.isNotEmptyOrNull(billAccount.getMtns())){
                            mtnList = billAccount.getMtns().stream().filter(mtnsList -> mtnsList.getHasActiveAndPendingDevice()!=null && mtnsList.getHasActiveAndPendingDevice()).collect(Collectors.toList());
                            if(CollectionUtilities.isNotEmptyOrNull(mtnList)  && StringUtilities.isNotEmptyOrNull(mtnList.get(0).getMtn())){
                                pendingMdn =	mtnList.get(0).getMtn();

                                if( mtnList.get(0).getActiveAndPendingDeviceInfo()!=null && StringUtilities.isNotEmptyOrNull(mtnList.get(0).getActiveAndPendingDeviceInfo().getOrderNo()) && !"0".equalsIgnoreCase(mtnList.get(0).getActiveAndPendingDeviceInfo().getOrderNo())){
                                    esimFlowType = CartConstants.PENDING_ORDER;
                                }
                                else if( mtnList.get(0).getActiveAndPendingDeviceInfo()!=null && StringUtilities.isNotEmptyOrNull(mtnList.get(0).getActiveAndPendingDeviceInfo().getOrderNo()) && "0".equalsIgnoreCase(mtnList.get(0).getActiveAndPendingDeviceInfo().getOrderNo())){
                                    if(StringUtilities.isNotEmptyOrNull(data.getPendingIccid()) && StringUtilities.isNotEmptyOrNull(data.getEsimType()) && data.getEsimType().equalsIgnoreCase("IPAD") ) {
                                        esimFlowType = CartConstants.ALREADY_ACTIVATED;
                                    }
                                    else if(StringUtilities.isEmptyOrNull(data.getPendingIccid()) ){
                                        esimFlowType = CartConstants.LOST_ICCID_PROFILE;
                                    }
                                }
                                if(CollectionUtilities.isNotEmptyOrNull(mtnList.get(0).getEquipmentInfos())){
                                    List<DeviceSimValidationEquipmentInfos> equimentInfosList = mtnList.get(0).getEquipmentInfos().stream().filter(equipInfo ->
                                            equipInfo!=null && equipInfo.getSimInfo()!=null && equipInfo.getSimInfo().getQSimInfo()!=null && StringUtilities.isNotEmptyOrNull(equipInfo.getSimInfo().getQSimInfo().getProfileState()) && CartConstants.PROFILE_STATE_C0.equalsIgnoreCase(equipInfo.getSimInfo().getQSimInfo().getProfileState())
                                    ).collect(Collectors.toList());
                                    activationCode = CollectionUtilities.isNotEmptyOrNull(equimentInfosList) && equimentInfosList.get(0).getSimInfo()!=null && StringUtilities.isNotEmptyOrNull(equimentInfosList.get(0).getSimInfo().getQSimInfo().getActivationCode())?equimentInfosList.get(0).getSimInfo().getQSimInfo().getActivationCode():"";
                                    esimIccid =  CollectionUtilities.isNotEmptyOrNull(equimentInfosList) && equimentInfosList.get(0).getSimInfo()!=null && StringUtilities.isNotEmptyOrNull(equimentInfosList.get(0).getSimInfo().getSimId())?equimentInfosList.get(0).getSimInfo().getSimId(): "";
                                    profileState = CollectionUtilities.isNotEmptyOrNull(equimentInfosList) && equimentInfosList.get(0).getSimInfo()!=null && StringUtilities.isNotEmptyOrNull(equimentInfosList.get(0).getSimInfo().getQSimInfo().getProfileState())?equimentInfosList.get(0).getSimInfo().getQSimInfo().getProfileState(): "";

                                }
                            }
                        }
                    }
                    DeviceSimValidationUIResponse deviceSimValidationUIResponse = new DeviceSimValidationUIResponse();
                    Mono<DeviceSimValidationUIResponse> deviceSimResp = Mono.just(deviceSimValidationUIResponse) ;
                    if(CartConstants.ACTIVATION.equalsIgnoreCase(esimFlowType) || StringUtilities.isEmptyOrNull(esimFlowType)) {
                        deviceSimResp = readCartHelper.deviceSimValidation(httpHeader, deviceSimRequest);
                    }

                    String finalEsimFlowType = esimFlowType;
                    String finalActivationCode = activationCode;
                    String finalProfileState = profileState;
                    String finalEsimIccid = esimIccid;
                    String finalPendingMdn = pendingMdn;

                    return deviceSimResp.flatMap(resp -> {
                        DeviceSimValidationUIResponseData responseData = new DeviceSimValidationUIResponseData();
                        ErrorResponse errors2 = null;
                        if (resp.getErrors() != null && resp.getData() == null) {
                            errors2 = CartCxpResponseErrorsUtil.handleDeviceSimValidationResponseErrors(resp);
                        }

                        if(resp == null || resp.getData() == null ){
                            responseData.setBbpDefaultZipcodeForTabletFlow(environment.getProperty(CartConstants.BBP_DEFAULT_ZIPCODEFORTABLETFLOW));
                            resp.setData(responseData);
                        }
                        if (Boolean.FALSE.equals(resp.getData().getIsSmartphone())) {
                            resp.getData().setBbpDefaultZipcodeForTabletFlow(
                                    environment.getProperty(CartConstants.BBP_DEFAULT_ZIPCODEFORTABLETFLOW));
                        }
                        String flowPath = String.valueOf(httpHeader.getPath());
                        if (StringUtilities.isNotEmptyOrNull(flowPath)) {
                            if (flowPath.contains("/nse/deviceSimValidation")) {
                                if(resp == null || resp.getData() == null ){
                                    responseData.setBbpDefaultZipcodeForTabletFlow(environment.getProperty(CartConstants.BBP_DEFAULT_ZIPCODEFORTABLETFLOW));
                                    resp.setData(responseData);
                                }
                                else if (Boolean.FALSE.equals(resp.getData().getIsSmartphone())) {
                                    resp.getData().setBbpDefaultZipcodeForTabletFlow(
                                            environment.getProperty(CartConstants.BBP_DEFAULT_ZIPCODEFORTABLETFLOW));
                                }
                                //VZWYN-17848 change
                                if(StringUtilities.isNotEmptyOrNull(data.getCompanionPhoneNumber())){
                                    logger.info("Companion phone number from Redis for nse/deviceSimValidation: {}",data.getCompanionPhoneNumber());
                                    resp.getData().setCompanionMdn(data.getCompanionPhoneNumber());
                                }
                                //NSADT-145443 changes
                                if(StringUtilities.isNotEmptyOrNull(data.getEsimType())){
                                    logger.info("esimType from Redis for nse/deviceSimValidation: {}",data.getEsimType());
                                    resp.getData().setESimType(data.getEsimType());
                                }
                                logger.info("new cust-deviceSimValidation data to be stored in redis {}", resp.getData());
                                return redisHelper2
                                        .upsertDeviceSimValidationDataIntoRedis(resp.getData()).flatMap(redisInsert ->{
                                            //hiding sensitive info - VZWYN-18780
                                            if (StringUtilities.isNotEmptyOrNull(resp.getData().getImei())) {
                                                resp.getData().setImei("");
                                            }
                                            if (StringUtilities.isEmptyOrNull(resp.getData().getImei())) {
                                                if (StringUtilities.isNotEmptyOrNull(resp.getData().getImei2())) {
                                                    resp.getData().setImei2("");
                                                }
                                            }
                                            if (StringUtilities.isNotEmptyOrNull(resp.getData().getIccid())) {
                                                resp.getData().setIccid("");
                                            }
                                            return Mono.just(ResponseEntity.status(HttpStatus.OK).body(resp));
                                        });
                            } else if (flowPath.contains("/deviceSimValidation")) {
                                logger.info("existing customer deviceSimValidation getDataFromRedis {}", data);
                                // List<CustomerByMtn> customerByMtnList =
                                if (customerData.getErrors() != null || customerData.getData() == null) {
                                    ErrorResponse errors5 = null;
                                    errors5 = CartCxpResponseErrorsUtil.handleCustomerByMtnResponseErrors(customerData);
                                    return Mono.just(ResponseEntity.status(HttpStatus.OK).body(errors5));
                                }
                                if(resp == null || resp.getData() == null ){
                                    responseData.setBbpDefaultZipcodeForTabletFlow(environment.getProperty(CartConstants.BBP_DEFAULT_ZIPCODEFORTABLETFLOW));
                                    resp.setData(responseData);
                                }

                                int index = -1;
                                List<MtnsListForCustomerProfile> list = new ArrayList<>();
                                if (customerData != null && customerData.getData() != null
                                        && customerData.getData().getCustomerProfile() != null
                                        && customerData.getData().getCustomerProfile().getBillAccounts() != null
                                        && customerData.getData().getCustomerProfile().getBillAccounts().get(0)
                                        .getMtns() != null) {
                                    list = customerData.getData().getCustomerProfile().getBillAccounts().get(0).getMtns();
                                }
                                for (int i = 0; i < list.size(); i++) {
                                    if (list.get(i).getMtn().equalsIgnoreCase(data.getMtn())) {
                                        String accessRole = "";
                                        index = i;
                                        if (customerData.getData().getCustomerProfile().getBillAccounts().get(0).getMtns()
                                                .get(index).getMobileInfoAttributes().getAccessRoles().isManager()) {
                                            accessRole = "ACCOUNT_MANAGER";
                                        } else if (customerData.getData().getCustomerProfile().getBillAccounts().get(0)
                                                .getMtns().get(index).getMobileInfoAttributes().getAccessRoles()
                                                .isMember()) {
                                            accessRole = "ACCOUNT_MEMBER";
                                        } else if (customerData.getData().getCustomerProfile().getBillAccounts().get(0)
                                                .getMtns().get(index).getMobileInfoAttributes().getAccessRoles()
                                                .isOwner()) {
                                            accessRole = "ACCOUNT_OWNER";
                                        } else {
                                            accessRole = "DEFAULT";
                                        }
                                        resp.getData().setAccessRole(accessRole);
                                        break;
                                    }
                                }
                                String customerDefaultZipcode = customerData.getData().getCustomerProfile()
                                        .getBillAccounts().get(0).getAccountAddress().getZipCode();
                                if (resp.getData().getIsSmartphone()!=null && Boolean.FALSE.equals(resp.getData().getIsSmartphone())) {
                                    resp.getData().setBbpDefaultZipcodeForTabletFlow(customerDefaultZipcode);
                                }
                                resp.getData().setActivationCode(finalActivationCode);
                                resp.getData().setEsimFlowType(finalEsimFlowType);
                                resp.getData().setProfileState(finalProfileState);
                                resp.getData().setEsimIccid(finalEsimIccid);
                                resp.getData().setPendingMdn(finalPendingMdn);
                                resp.getData().setFlowType(CartConstants.EXISTING_CUSTOMER);
                                if(null != data && StringUtilities.isNotEmptyOrNull(data.getEsimType())){
                                    resp.getData().setESimType(data.getEsimType());
                                }
                                logger.info("existing-deviceSimValidation before upserting into redis {}", resp.getData());

                                return redisHelper2.upsertDeviceSimValidationDataIntoRedis(resp.getData()).flatMap(redisInsert -> {
                                    if(StringUtilities.isNotEmptyOrNull(resp.getData().getPendingMdn())){
                                        resp.getData().setPendingMdn("");
                                    }
                                    //hiding sensitive info - VZWYN-18780
                                    if (StringUtilities.isNotEmptyOrNull(resp.getData().getImei())) {
                                        resp.getData().setImei("");
                                    }
                                    if (StringUtilities.isEmptyOrNull(resp.getData().getImei())) {
                                        if (StringUtilities.isNotEmptyOrNull(resp.getData().getImei2())) {
                                            resp.getData().setImei2("");
                                        }
                                    }
                                    if (StringUtilities.isNotEmptyOrNull(resp.getData().getIccid())) {
                                        resp.getData().setIccid("");
                                    }
                                    return Mono.just(ResponseEntity.status(HttpStatus.OK).body(resp));
                                });
                            }
                            return Mono.just(ResponseEntity.status(HttpStatus.OK).body(resp));
                        }
                        return errors2 != null ? Mono.just(ResponseEntity.status(HttpStatus.OK).body(errors2))
                                : Mono.just(ResponseEntity.status(HttpStatus.OK).body(resp));
                    });
                });

            });
        });
    }


    private ErrorResponse settingErrorData(String idValue) {
        ErrorResponse errors5 = new ErrorResponse();
        CartError error = new CartError();
        List<CartError> errorList = null;
        errorList = new ArrayList<CartError>();
        error.setNamespace(CartConstants.SOE_CART_SERVICE);
        error.setId(idValue);
        error.setName(CartConstants.API_ERROR);
        errorList.add(error);
        errors5.setErrors(errorList);
        return errors5;
    }


    private Mono<DeviceSimValidationUIRequest> settingData(DeviceSimValidationUIRequest request) {
        if (null != request && StringUtilities.isEmptyOrNull(request.getIccid()) && StringUtilities.isEmptyOrNull(request.getImei())
                && StringUtilities.isEmptyOrNull(request.getEid())
                && StringUtilities.isEmptyOrNull(request.getImei2())) {
            return redisHelper.getDataFromRedis().flatMap(redisData -> {
                if (StringUtilities.isNotEmptyOrNull(redisData.getIccid())) {
                    logger.info("iccid from Redis for deviceSimValidation: {}",redisData.getIccid());
                    request.setIccid(redisData.getIccid());
                }
                if (StringUtilities.isNotEmptyOrNull(redisData.getImei())) {
                    logger.info("imei from Redis for deviceSimValidation: {}",redisData.getImei());
                    request.setImei(redisData.getImei());
                }
                if (StringUtilities.isNotEmptyOrNull(redisData.getEid())) {
                    logger.info("eid from  Redis for deviceSimValidation: {}",redisData.getEid());
                    request.setEid(redisData.getEid());
                }
                if (StringUtilities.isNotEmptyOrNull(redisData.getImei2())) {
                    logger.info("imei2 from Redis for deviceSimValidation: {}",redisData.getImei2());
                    request.setImei2(redisData.getImei2());
                }
                if (StringUtilities.isNotEmptyOrNull(redisData.getDevid())) {
                    logger.info("devid from Redis for deviceSimValidation: {}",redisData.getDevid());
                    request.setDevid(redisData.getDevid());
                }
                return Mono.just(request);

            });
        }
        else {
            return redisHelper3.upsertDeviceSimValidationRequestDataIntoRedis(request).flatMap(redisdata->{
                logger.info("Data upserted in redis is: {}", redisdata);
                return Mono.just(request);
            });
        }
    }

    public void addingCookiesForWhitelistingIMEIs(String imei, ServerHttpResponse httpResponse) {
        logger.info("calling the method addingCookiesForWhitelistingIMEIs");
        if (StringUtilities.isNotEmptyOrNull(imei) && whitelistedIMEIS.contains(imei)) {
            logger.info("check for whitelistedIMEIS from config obj ::  ", whitelistedIMEIS);
            httpResponse.addCookie(ResponseCookie.from(CartConstants.DARK_TESTING_BYOU, CartConstants.TRUE_FLAG)
                    .path("/").httpOnly(false).maxAge(Duration.ofHours(1)).build());
        }
    }
    private Mono<BundleBuilderResponse> mergeFeatureFlagWithResponse(Mono<Tuple6<BundleBuilderResponse, ConfigurationProfile,
                Map<String, Flag>,Map<String, Flag>, Map<String, Flag>, Map<String, Flag>>> zip) {
    return zip.flatMap(tuples -> {
        var bundleBuilderResponse = tuples.getT1();
        Map<String, FlagDetails> featureConfigurationProfileData = new HashMap<>();
        featureFlagHelper.addDigitalPerformanceFeatureFlag(tuples.getT2(),featureConfigurationProfileData);
        featureFlagHelper.addDigitalPromoFeatureFlag(tuples.getT3(),featureConfigurationProfileData);
        featureFlagHelper.addDigitalPromoFeatureFlag(tuples.getT4(),featureConfigurationProfileData);
        featureFlagHelper.addDigitalPromoFeatureFlag(tuples.getT5(),featureConfigurationProfileData);
        featureFlagHelper.addDigitalPromoFeatureFlag(tuples.getT6(),featureConfigurationProfileData);
        bundleBuilderResponse.getData().setFeatureConfigurationProfileData(featureConfigurationProfileData);
        return Mono.just(bundleBuilderResponse);
    });
    }
}
