package onevz.soe.cart.util;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import onevz.soe.cart.model.retrieveActivationStatus.*;
import onevz.soe.cart.requests.DeviceSimDetailsCxpRequest;
import onevz.soe.cart.responses.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.gql.response.GetPairedDeviceInfoGQLResponse;
import onevz.soe.cart.gql.schema.getCustomerInfo.CbrNos;
import onevz.soe.cart.gql.schema.getCustomerInfo.EquipmentInfo;
import onevz.soe.cart.gql.schema.getCustomerInfo.Mtn;
import onevz.soe.cart.gql.schema.getPairedDevices.CartItem;
import onevz.soe.cart.gql.schema.getPairedDevices.ItemsInfo;
import onevz.soe.cart.gql.schema.getPairedDevices.LineInfo;
import onevz.soe.cart.model.SalesRepDetails;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.deviceIdValidation.DeviceIdValidationContext;
import onevz.soe.cart.model.deviceIdValidation.DeviceIdValidationServiceBody;
import onevz.soe.cart.model.deviceIdValidation.DeviceIdValidationServiceResponse;
import onevz.soe.cart.model.getCustomerInfo.AccountAddress;
import onevz.soe.cart.model.getCustomerInfo.BillingInfo;
import onevz.soe.cart.model.getCustomerInfo.GraphqlData;
import onevz.soe.cart.model.getCustomerInfo.PricePlanInfo;
import onevz.soe.cart.model.getPairedDevices.NumberSharePairedWatches;
import onevz.soe.cart.model.getPairedDevices.PayLoad;
import onevz.soe.cart.model.initiateDeviceSimActivation.InitiateDeviceSimActivationUIResponse;
import onevz.soe.cart.model.initiateESimActivation.InitiateESimActivationUIResponse;
import onevz.soe.cart.model.retrieveCart.CXPCartItem;
import onevz.soe.cart.model.retrieveCart.CXPCartItemsVO;
import onevz.soe.cart.model.retrieveCart.CXPCartVO;
import onevz.soe.cart.model.retrieveCart.CXPItemInfo;
import onevz.soe.cart.model.retrieveCart.CXPLineDetailsVO;
import onevz.soe.cart.model.retrieveCart.CXPLineInfo;
import onevz.soe.cart.model.retrieveCart.CXPRetrieveCartDataVO;
import onevz.soe.cart.ui.requests.CreateCaseAndGetCustomerInfoUIRequest;
import onevz.soe.cart.ui.requests.GetPairedDevicesUIRequest;
import onevz.soe.cart.ui.responses.CreateCaseAndGetCustomerInfoUIResponse;
import onevz.soe.cart.ui.responses.CustomerByMtnListUIResponse;
import onevz.soe.cart.ui.responses.CustomerByMtnUIResponse;
import onevz.soe.cart.ui.responses.CustomerProfileUIResponse;
import onevz.soe.cart.ui.responses.DeviceIdValidationUIResponse;
import onevz.soe.cart.ui.responses.DeviceSimDetailsUIResponse;
import onevz.soe.cart.ui.responses.GetPairedDevicesUIResponse;
import onevz.soe.cart.ui.responses.GetParentLinesUIResponse;
import onevz.soe.cart.ui.responses.GiftPurchaseUIResponse;
import onevz.soe.cart.ui.responses.InitiateCbandCheckUIResponse;
import onevz.soe.cart.ui.responses.MacAddressUIResponse;
import onevz.soe.cart.ui.responses.PaperlessBillingUIResponse;
import onevz.soe.cart.ui.responses.RPSE911AddressRetrieveUIResponse;
import onevz.soe.cart.ui.responses.RPSE911AddressUpdateStatus;
import onevz.soe.cart.ui.responses.RPSE911AddressUpdateUIResponse;
import onevz.soe.cart.ui.responses.RPSReleasePendingOrderResponse;
import onevz.soe.cart.ui.responses.RetrieveActivationStatusUIResponse;
import onevz.soe.cart.ui.responses.RetrieveCartUIResponse;
import onevz.soe.cart.ui.responses.UpdatePurchaseOrderUIResponse;
import onevz.soe.cart.ui.responses.UpdateTradeInOfferUIResponse;
import onevz.soe.cart.ui.responses.UpdateTradeinTypeUIResponse;
import onevz.soe.cart.ui.responses.UpdateUserInfoUIResponse;
import onevz.soe.cart.ui.responses.UpdateVzccNBXInfoUIResponse;
import onevz.soe.cart.ui.responses.VZCCAppStatusUIResponse;
import onevz.soe.cart.ui.responses.ValidateE911AddressUIResponse;
import onevz.soe.logging.util.LoggerUtil;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.utilities.serialization.JacksonMapperFactory;
import reactor.core.publisher.Mono;

/**
 * Response Formatter Helper class.
 */
public class CartCxpResponseUtil {
	
	private static final Logger logger = LoggerFactory.getLogger(CartCxpResponseUtil.class);

	private CartCxpResponseUtil() {

	}

	/**
	 * 
	 * @param cxpResponse
	 * @param soeResponse
	 */
	public static void formatUpdateUserInfoResponse(UpdateUserInfoCXPResponse cxpResponse,
			UpdateUserInfoUIResponse soeResponse) {
		if (cxpResponse.getData() != null)
			soeResponse.setData(cxpResponse.getData());
		if (cxpResponse.getErrors() != null && !cxpResponse.getErrors().isEmpty())
			soeResponse.setErrors(cxpResponse.getErrors());
		if (cxpResponse.getMeta() != null)
			soeResponse.setMeta(cxpResponse.getMeta());
	}

	public static double round(double value) {
		BigDecimal bigDecimal = new BigDecimal(Double.toString(value));
		bigDecimal = bigDecimal.setScale(2, RoundingMode.HALF_EVEN);
		return bigDecimal.doubleValue();
	}

	/**
	 * 
	 * @param cxpResponse
	 * @param soeResponse
	 */
	public static void formatPaperlessBillingResponse(PaperlessBillingCXPResponse cxpResponse,
			PaperlessBillingUIResponse soeResponse) {
		if (cxpResponse.getData() != null)
			soeResponse.setData(cxpResponse.getData());
		if (cxpResponse.getErrors() != null && !cxpResponse.getErrors().isEmpty())
			soeResponse.setErrors(cxpResponse.getErrors());
		if (cxpResponse.getMeta() != null)
			soeResponse.setMeta(cxpResponse.getMeta());
	}

	/**
	 * 
	 * @param cxpResponse
	 * @param soeResponse
	 */
	public static void formatUpdateTradeinTypeResponse(UpdateTradeinTypeCXPResponse cxpResponse,
			UpdateTradeinTypeUIResponse soeResponse) {
		if (cxpResponse.getData() != null)
			soeResponse.setData(cxpResponse.getData());
		if (cxpResponse.getErrors() != null && !cxpResponse.getErrors().isEmpty())
			soeResponse.setErrors(cxpResponse.getErrors());
		if (cxpResponse.getMeta() != null)
			soeResponse.setMeta(cxpResponse.getMeta());
	}

	/**
	 *
	 * @param retrieveCartResponse
	 * @param graphqlType
	 */
	public static RetrieveCartCXPResponse formatResponseCartItemType(RetrieveCartCXPResponse retrieveCartResponse,
			String graphqlType) {

		CXPLineInfo[] lineInfoItem = retrieveCartResponse.getData().getCart().getLineDetails().getLineInfo();

		RetrieveCartCXPResponse cartResponse = new RetrieveCartCXPResponse();
		CXPRetrieveCartDataVO cartData = new CXPRetrieveCartDataVO();
		CXPCartVO cart = new CXPCartVO();
		CXPLineDetailsVO lineDetails = new CXPLineDetailsVO();
		List<CXPLineInfo> lineInfoList = new ArrayList<>();

		for (CXPLineInfo lineInfoMem : lineInfoItem) {
			CXPLineInfo lineInfo = new CXPLineInfo();
			CXPItemInfo cxpItemsInfo = null;
			CXPCartItem[] cartItemArray;
			if (lineInfoMem.getItemsInfo() != null)
				cxpItemsInfo = lineInfoMem.getItemsInfo()[0];
			if (cxpItemsInfo == null) {
				return emptyResponse();
			} else {
				List<CXPCartItem> cartItemList = new ArrayList<>();
				CXPItemInfo[] itemInfoList = new CXPItemInfo[1];
				CXPItemInfo itemInfo = new CXPItemInfo();
				CXPCartItemsVO cartItems = new CXPCartItemsVO();

				if (cxpItemsInfo.getCartItems() != null && cxpItemsInfo.getCartItems().getCartItem() != null) {

					cartItemArray = cxpItemsInfo.getCartItems().getCartItem();
					for (CXPCartItem item : cartItemArray) {
						CXPCartItem cartItem = new CXPCartItem();

						if (!(CartConstants.NUMBER_SHARE.equalsIgnoreCase(graphqlType))
								|| (CartConstants.NUMBER_SHARE.equalsIgnoreCase(graphqlType) && null != item.getNumberShareEligible()
										&& (item.getNumberShareEligible()))
										&& "DEVICE".equalsIgnoreCase(item.getCartItemType())
								|| "SIM".equalsIgnoreCase(item.getCartItemType())) {
							{

								cartItem.setCartItemType(item.getCartItemType());
								if ("deviceDetails".equalsIgnoreCase(graphqlType)) {
									cartItem.setDeviceId(item.getDeviceId());
									cartItem.setSimId(item.getSimId());
									cartItem.setIsCustomerProvidedSIM(item.getIsCustomerProvidedSIM());
								}
								if (CartConstants.NUMBER_SHARE.equalsIgnoreCase(graphqlType)) {
									cartItem.setSmartIMEI(item.getSmartIMEI());
								}
								cartItem.setSimId(item.getSimId());
								cartItem.setSorId(item.getSorId());
								cartItem.setDescription(item.getDescription());
								cartItem.setDepletionType(item.getDepletionType());
								cartItem.setColor(item.getColor());
								cartItem.setImageUrlMap(item.getImageUrlMap());
								cartItemList.add(cartItem);

							}
						}
					}

				}

				CXPCartItem[] cartItemsArray = new CXPCartItem[cartItemList.size()];
				cartItemList.toArray(cartItemsArray);
				cartItems.setCartItem(cartItemsArray);
				itemInfo.setCartItems(cartItems);
				itemInfoList[0] = itemInfo;
				lineInfo.setItemsInfo(itemInfoList);
				lineInfo.setMobileNumber(lineInfoMem.getMobileNumber());
				if (CartConstants.NUMBER_SHARE.equalsIgnoreCase(graphqlType)) {
					lineInfo.setNumbershareInfo(lineInfoMem.getNumbershareInfo());
				}
				if ("deviceDetails".equalsIgnoreCase(graphqlType)) {
					lineInfo.setIsCpe(lineInfoMem.getIsCpe());
				}
				lineInfo.setServiceInfo(lineInfoMem.getServiceInfo());
				lineInfo.setAccountOwner(lineInfoMem.getAccountOwner());
			}
			lineInfoList.add(lineInfo);
		}
		CXPLineInfo[] lineArr = new CXPLineInfo[lineInfoList.size()];
		lineInfoList.toArray(lineArr);
		lineDetails.setLineInfo(lineArr);
		cart.setLineDetails(lineDetails);
		cartData.setCart(cart);
		cartResponse.setData(cartData);
		return cartResponse;
	}

	/**
	 *
	 * @param retrieveCartResponse
	 */
	public static RetrieveCartCXPResponse getDeviceCount(RetrieveCartCXPResponse retrieveCartResponse) {

		int deviceCount = 0;
		String cartId = "";
		RetrieveCartCXPResponse cartResponse = new RetrieveCartCXPResponse();
		CXPRetrieveCartDataVO cartData = new CXPRetrieveCartDataVO();
		CXPCartVO cart = new CXPCartVO();

		if (null != retrieveCartResponse.getData()) {
			if (null != retrieveCartResponse.getData().getCart()) {
				cartId = retrieveCartResponse.getData().getCart().getCartId();
				if (null != retrieveCartResponse.getData().getCart().getLineDetails()) {
					if (null != retrieveCartResponse.getData().getCart().getLineDetails().getLineInfo()) {
						CXPLineInfo[] lineInfoItem = retrieveCartResponse.getData().getCart().getLineDetails()
								.getLineInfo();
						for (CXPLineInfo lineInfoMem : lineInfoItem) {
							CXPItemInfo cxpItemsInfo = null;
							CXPCartItem[] cartItemArray;
							if (lineInfoMem.getItemsInfo() != null)
								cxpItemsInfo = lineInfoMem.getItemsInfo()[0];
							if (cxpItemsInfo == null) {
								return emptyResponse();
							} else {
								if (cxpItemsInfo.getCartItems() != null
										&& cxpItemsInfo.getCartItems().getCartItem() != null) {
									cartItemArray = cxpItemsInfo.getCartItems().getCartItem();
									for (CXPCartItem item : cartItemArray) {
										if ("DEVICE".equalsIgnoreCase(item.getCartItemType()))
											deviceCount++;
									}
								}
							}
						}
					}
				}
			}
		}
		cart.setCartId(cartId);
		cartData.setCart(cart);
		cartData.setDeviceCountInCart(deviceCount);
		cartResponse.setData(cartData);
		return cartResponse;
	}


	/**
	 *
	 * @param cxpResponse
	 * @param soeResponse
	 */
	public static void formatMacAddressResponse(MacAddressCXPResponse cxpResponse, MacAddressUIResponse soeResponse) {
		if (cxpResponse.getData() != null)
			soeResponse.setData(cxpResponse.getData());
		if (cxpResponse.getErrors() != null && !cxpResponse.getErrors().isEmpty())
			soeResponse.setErrors(cxpResponse.getErrors());
		if (cxpResponse.getMeta() != null)
			soeResponse.setMeta(cxpResponse.getMeta());
	}

	/**
	 * 
	 * @param cxpResponse
	 * @param soeResponse
	 */
	public static void formatUpdatePurchaseOrderResponse(UpdatePurchaseOrderCXPResponse cxpResponse,
			UpdatePurchaseOrderUIResponse soeResponse) {
		if (cxpResponse.getData() != null)
			soeResponse.setData(cxpResponse.getData());
		if (cxpResponse.getErrors() != null && cxpResponse.getErrors().isEmpty())
			soeResponse.setErrors(cxpResponse.getErrors());
		if (cxpResponse.getMeta() != null)
			soeResponse.setMeta(cxpResponse.getMeta());
	}

	/**
	 * 
	 * @param cxpResponse
	 * @param soeResponse
	 */
	public static void formatGiftPurchaseResponse(GiftPurchaseCXPResponse cxpResponse,
			GiftPurchaseUIResponse soeResponse) {
		if (cxpResponse.getData() != null)
			soeResponse.setData(cxpResponse.getData());
		if (cxpResponse.getErrors() != null && !cxpResponse.getErrors().isEmpty())
			soeResponse.setErrors(cxpResponse.getErrors());
		if (cxpResponse.getMeta() != null)
			soeResponse.setMeta(cxpResponse.getMeta());
	}

	/**
	 * 
	 * @param soeResponse
	 * @param cxpResponse
	 */
	public static void formatCustomerByMtnListResponse(CustomerByMtnListUIResponse soeResponse,
			CustomerByMtnListCXPResponse cxpResponse) {

		if (cxpResponse.getErrors() != null)
			soeResponse.setErrors(cxpResponse.getErrors());
		if (cxpResponse.getMeta() != null)
			soeResponse.setMeta(cxpResponse.getMeta());
		if (cxpResponse.getData() != null) {
			soeResponse.setData(cxpResponse.getData());
		}
	}

	/**
	 *
	 * @param soeResponse
	 * @param cxpResponse
	 */
	public static void formatVZCCAppStatusResponse(VZCCAppStatusUIResponse soeResponse,
			VZCCAppStatusCXPResponse cxpResponse) {

		if (cxpResponse.getErrors() != null)
			soeResponse.setErrors(cxpResponse.getErrors());
		if (cxpResponse.getMeta() != null)
			soeResponse.setMeta(cxpResponse.getMeta());
		if (cxpResponse.getData() != null) {
			soeResponse.setData(cxpResponse.getData());
		}
	}

	/**
	 * 
	 * @return uiResponse
	 */
	public static Mono<RetrieveCartUIResponse> formatRetrieveCartEmptyErrorResponse() {
		RetrieveCartUIResponse retrieveCartUIresponse = new RetrieveCartUIResponse();
		CartError cartError = new CartError();
		cartError.setNamespace(CartConstants.SOE_CART_SERVICE);
		cartError.setName(CartConstants.REQUEST_VALIDATION_ERROR);
		cartError.setCode("400");
		cartError.setMessage("CartId missing in request");
		CartError[] cartErrorArr = new CartError[1];
		cartErrorArr[0] = cartError;
		retrieveCartUIresponse.setErrors(cartErrorArr);
		return Mono.just(retrieveCartUIresponse);
	}
	/**
	 *
	 * @return uiResponse
	 */
	public static Mono<RetrieveCartUIResponse> formatRetrieveCartEmptyFiveGErrorResponse(boolean orderPlaced) {
		RetrieveCartUIResponse retrieveCartUIresponse = new RetrieveCartUIResponse();
		CartError cartError = new CartError();
		cartError.setNamespace(CartConstants.SOE_CART_SERVICE);
		cartError.setName(CartConstants.REQUEST_VALIDATION_ERROR);
		cartError.setCode("400");
		if(orderPlaced) {
			cartError.setId("0605");
			cartError.setMessage("Order is already Placed.");
		} else {
			cartError.setId("06");
			cartError.setMessage("CartId is not present in redis");
		}
		CartError[] cartErrorArr = new CartError[1];
		cartErrorArr[0] = cartError;
		retrieveCartUIresponse.setErrors(cartErrorArr);
		return Mono.just(retrieveCartUIresponse);
	}
	/**
	 *
	 * @param cxpResponse
	 * @param soeResponse
	 */
	public static void formatUpdateRPSE911AddressResponse(RPSE911AddressCXPResponse cxpResponse,
			RPSE911AddressUpdateUIResponse soeResponse) {
		RPSE911AddressData status = new RPSE911AddressData();
		status.setStatus(cxpResponse.getData().getStatus());
		soeResponse.setData(status);
	}

	/**
	 *
	 * @param cxpResponse
	 * @param soeResponse
	 */
	public static void formatReleasePendingOrderResponse(RPSReleasePendingOrderCXPResponse cxpResponse,
			RPSReleasePendingOrderResponse soeResponse) {
		if (cxpResponse.getStatus() != null)
			soeResponse.getStatus().setMessage(cxpResponse.getStatus());
		soeResponse.getStatus().setCode("200");
		if (cxpResponse.getErrors() != null && !cxpResponse.getErrors().isEmpty())
			soeResponse.setErrors(cxpResponse.getErrors());

	}

	/**
	 *
	 * @param cxpResponse
	 * @param soeResponse
	 */
	public static void formatRetrieveRPSE911AddressResponse(RPSE911AddressCXPResponse cxpResponse,
			RPSE911AddressRetrieveUIResponse soeResponse) {
		if (cxpResponse.getErrors() != null && !cxpResponse.getErrors().isEmpty())
			soeResponse.setErrors(cxpResponse.getErrors());
		RPSE911AddressUpdateStatus statusObj = new RPSE911AddressUpdateStatus();
		soeResponse.setData(cxpResponse.getData());
		statusObj.setMessage(cxpResponse.getStatus());
		statusObj.setCode("200");
		soeResponse.setStatus(statusObj);
	}

	/**
	 * 
	 * @param cxpResponse
	 * @param soeResponse
	 */
	public static void formatUpdateTradeInOfferResponse(UpdateTradeInOfferCXPResponse cxpResponse,
			UpdateTradeInOfferUIResponse soeResponse) {
		if (cxpResponse.getData() != null)
			soeResponse.setData(cxpResponse.getData());
		if (cxpResponse.getErrors() != null && cxpResponse.getErrors().isEmpty())
			soeResponse.setErrors(cxpResponse.getErrors());
		if (cxpResponse.getMeta() != null)
			soeResponse.setMeta(cxpResponse.getMeta());
	}

	/**
	 * 
	 * @param cxpResponse
	 * @param uiResponse
	 */
	public static void formatDeviceSimDetailsResponse(DeviceSimDetailsCxpResponse cxpResponse,
			DeviceSimDetailsUIResponse uiResponse, DeviceSimDetailsCxpRequest request) {
		if (cxpResponse.getErrors() != null && !cxpResponse.getErrors().isEmpty()) {
			uiResponse.setErrors(cxpResponse.getErrors());
		}
		if (cxpResponse.getData() != null)
			uiResponse.setUiData(cxpResponse.getData());
		if(request!=null && request.getData()!=null && request.getData().getEsimFlow()!=null){
			uiResponse.getUiData().setEsimFlow(request.getData().getEsimFlow());
		}

		if (cxpResponse.getMeta() != null)
			uiResponse.setUiMeta(cxpResponse.getMeta());

	}

	public static void formatDeviceValidationResponse(DeviceIdValidationCXPResponse cxpResponse,
			DeviceIdValidationUIResponse soeResponse) {
		
		if (cxpResponse.getErrors() != null && !cxpResponse.getErrors().isEmpty()) {
			soeResponse.setErrors(cxpResponse.getErrors());
		}
		
		if(cxpResponse.getData() != null)
			if(cxpResponse.getData().getDeviceInfo() != null) {
				DeviceIdValidationServiceBody serviceBody = new DeviceIdValidationServiceBody();
				DeviceIdValidationServiceResponse serviceResponse = new DeviceIdValidationServiceResponse();
				DeviceIdValidationContext context = new DeviceIdValidationContext();
				context.setDeviceInfo(cxpResponse.getData().getDeviceInfo());
				serviceResponse.setContext(context);
				serviceBody.setServiceResponse(serviceResponse);
				soeResponse.setServiceBody(serviceBody);
				
			}
	}

	/**
	 *
	 * @param cxpResponse
	 * @param soeResponse
	 */
	public static void formatAddZipcodeResponse(AddZipcodeCXPResponse cxpResponse,
												AddZipcodeRedisData soeResponse) {
		if (cxpResponse.getData() != null)
			soeResponse.setZipCode (cxpResponse.getData().getZipCode());
			soeResponse.setStatus(cxpResponse.getData().getStatusMsg());
		if (cxpResponse.getErrors() != null && cxpResponse.getErrors().isEmpty())
			soeResponse.setErrors(cxpResponse.getErrors());
		if (cxpResponse.getMeta() != null)
			soeResponse.setMeta(cxpResponse.getMeta());
	}

	public static void formatInitiateCbandCheckResponse(InitiateCbandCheckCXPResponse cxpResponse,
														InitiateCbandCheckUIResponse soeResponse) {

		if (null != cxpResponse.getData() ) {
			soeResponse.setData(cxpResponse.getData());
		}

		if (null != cxpResponse.getErrors()) {
			soeResponse.setErrors(cxpResponse.getErrors());
		}
		if (null != cxpResponse.getMeta()) {
			soeResponse.setMeta(cxpResponse.getMeta());
		}

	}

    /**
     *
     * @param soeResponse
     * @param cxpResponse
     */
    public static void formatCustomerByMtnResponse(CustomerByMtnUIResponse soeResponse,
                                                   CustomerByMtnCXPResponse cxpResponse) {

        if (cxpResponse.getErrors() != null)
            soeResponse.setErrors(cxpResponse.getErrors());
        if (cxpResponse.getMeta() != null)
            soeResponse.setMeta(cxpResponse.getMeta());
        if (cxpResponse.getData() != null) {
            soeResponse.setData(cxpResponse.getData());
        }
    }

	public static void formatCustomerProfileResponse(CustomerProfileCXPResponse response, CustomerProfileUIResponse uiResponse, String repId) {
    	if(response!=null && response.getData()!=null){
			SalesRepDetails data = new SalesRepDetails();
			Map<String, Object> dataMap = new HashMap<>();
			data.setRepId(repId);
    		if(response.getData().getMostRecentSalesRepCustomerData()!=null) {
    			String name = response.getData().getMostRecentSalesRepCustomerData().getSalesRepEmpName();
				data.setValidSalesRepId(response.getData().getMostRecentSalesRepCustomerData().isValidSalesRepId());
				data.setSalesRepGivenName(name!=null? name:"");
				data.setStatus(CartConstants.STATUS_SUCCESS);
			}
			uiResponse.setData(data);
    		if(response.getMeta()!=null && response.getMeta().size()>0)
				dataMap.putAll(response.getMeta());
			uiResponse.setMeta(dataMap);
		}
	}
	 /**
		 * 
		 * @param soeResponse
		 * @param cxpResponse
		 */
		
		public static void formatGetPairedWatchesResponse(GetPairedDevicesUIResponse soeResponse,
				GetPairedDeviceInfoGQLResponse cxpResponse,GetPairedDevicesUIRequest request) {
			PayLoad payload = new PayLoad();
			if (cxpResponse.getWarnings() != null)
				soeResponse.setWarnings(cxpResponse.getWarnings());
			if (cxpResponse.getErrors() != null)
				soeResponse.setErrors(cxpResponse.getErrors());
			if(cxpResponse.getMeta() != null)
				soeResponse.setMeta(cxpResponse.getMeta());
		
				List<NumberSharePairedWatches> numberSharePairedWatches = new ArrayList<>();
				if (cxpResponse.getData() != null && cxpResponse.getData().getCart() != null
						&& cxpResponse.getData().getCart().getLineDetails() != null
						&& cxpResponse.getData().getCart().getLineDetails().getLineInfo() != null) {

					LineInfo[] lineInfo = cxpResponse.getData().getCart().getLineDetails().getLineInfo();
					formatePairedDeviceServiceAndItemInfo(numberSharePairedWatches, lineInfo,request);
					payload.setNumberSharePairedWatches(numberSharePairedWatches);

				}

				soeResponse.setPayload(payload);
			

		}

		private static void formatePairedDeviceServiceAndItemInfo(List<NumberSharePairedWatches> numberSharePairedWatches,
				LineInfo[] lineInfo,GetPairedDevicesUIRequest request) {

			for (LineInfo lineInfoItem : lineInfo) {
				NumberSharePairedWatches numberSharePairedWatch = new NumberSharePairedWatches();
				if (lineInfoItem.getServiceInfo() != null
						&& (lineInfoItem.getServiceInfo().getMldTrunkMTN() != null
						&& request.getMtn().equalsIgnoreCase(lineInfoItem.getServiceInfo().getMldTrunkMTN())
						|| "G".equalsIgnoreCase(lineInfoItem.getServiceInfo().getNumberShareInd()))) {
					numberSharePairedWatch.setMtn(lineInfoItem.getServiceInfo().getMtn());
					numberSharePairedWatch.setMldTrunkMtn(lineInfoItem.getServiceInfo().getMldTrunkMTN());
					formatPairedDevicesItemInfo(lineInfoItem, numberSharePairedWatch);
					numberSharePairedWatches.add(numberSharePairedWatch);

				}

			}
		}

		private static void formatPairedDevicesItemInfo(LineInfo lineInfoItem,
				NumberSharePairedWatches numberSharePairedWatch) {
			ItemsInfo cxpItemsInfo;
			CartItem[] cartItemArray;
			
			if (lineInfoItem.getItemsInfo() != null) {
				cxpItemsInfo = lineInfoItem.getItemsInfo()[0];

				if (cxpItemsInfo.getCartItems() != null && cxpItemsInfo.getCartItems().getCartItem() != null) {
					cartItemArray = cxpItemsInfo.getCartItems().getCartItem();
					for (CartItem item : cartItemArray) {

						if (StringUtilities.isNotEmptyOrNull(item.getDeviceDisplayName()))
							numberSharePairedWatch.setDisplayName(item.getDeviceDisplayName());
                        if ( item.getImageUrlMap() != null && StringUtilities.isNotEmptyOrNull(item.getImageUrlMap().getThumbImage()))
                            numberSharePairedWatch.setImageUrl(item.getImageUrlMap().getThumbImage());
                    }
				}
			}
		}
		
	/**
	 *
	 * @param soeResponse
	 * @param cxpResponse
	 */
	public static void formatVzccNBXInfoResponse(UpdateVzccNBXInfoUIResponse soeResponse,
			UpdateVzccNBXInfoCXPResponse cxpResponse) {

		if (cxpResponse.getErrors() != null)
			soeResponse.setErrors(cxpResponse.getErrors());
		if (cxpResponse.getMeta() != null)
			soeResponse.setMeta(cxpResponse.getMeta());
		if (cxpResponse.getData() != null) {
			soeResponse.setData(cxpResponse.getData());
		}
	}				

	/**
	 *
	 * @param cxpResponse
	 * @param soeResponse
	 */
	public static void formatValidateE911AddressResponse(ValidateE911AddressCXPResponse cxpResponse,
														 ValidateE911AddressUIResponse soeResponse) { // 2155.1
		if(cxpResponse.getErrors()!=null){
			soeResponse.setErrors(cxpResponse.getErrors());
		}
		if(cxpResponse.getWarnings()!=null){
			soeResponse.setWarnings(cxpResponse.getWarnings());
		}
		if(cxpResponse.getData()!=null) {
			soeResponse.setValidateAddress(cxpResponse.getData());
		}
	}
	
	/**
	 * 
	 * @param soeResponse
	 * @param retrieveActivationCXPResponse
	 */
	public static void formatRetrieveActivationStatusResponse(RetrieveActivationStatusUIResponse soeResponse,
			RetrieveActivationStatusCXPResponse retrieveActivationCXPResponse, String channelId) {
		 List<OrderActivationStatusCXPInfo> orderActivationStatusInfo = new ArrayList<>();
		 orderActivationStatusInfo= retrieveActivationCXPResponse.getData().getOrderActivationStatusInfo();
		 if( orderActivationStatusInfo != null && CollectionUtilities.isNotEmptyOrNull(orderActivationStatusInfo)){
			 RetrieveActivationStatusServiceBody retrieveActivationStatusServiceBody=new RetrieveActivationStatusServiceBody();
			 RetrieveActivationStatusResponse retrieveActivationStatusResponse= new RetrieveActivationStatusResponse();
			 RetrieveActivationStatusContext retrieveActivationStatusContext=new RetrieveActivationStatusContext();
			 OrderActivationStatusInfo orderActivationStatusInfoNode = new OrderActivationStatusInfo();
			 soeResponse.setServiceBody(retrieveActivationStatusServiceBody);
			 soeResponse.getServiceBody().setServiceResponse(retrieveActivationStatusResponse);
			 soeResponse.getServiceBody().getServiceResponse().setContext(retrieveActivationStatusContext);
			 soeResponse.getServiceBody().getServiceResponse().getContext().setOrderActivationStatusInfo(orderActivationStatusInfoNode);
			 soeResponse.getServiceBody().getServiceResponse().getContext().getOrderActivationStatusInfo().setOrderActivationStatusInfo(orderActivationStatusInfo);
			 if (orderActivationStatusInfo.get(0).getActivationInfoList() != null
							&& CollectionUtilities.isNotEmptyOrNull(orderActivationStatusInfo.get(0).getActivationInfoList())
						    && orderActivationStatusInfo.get(0).getActivationInfoList().get(0).getOdaActivationCode() != null) {
						try {
							//setting activationinfolist detail
							String[] activationCodeArray = orderActivationStatusInfo.get(0).getActivationInfoList().get(0).getOdaActivationCode().split("\\$");
							soeResponse.getServiceBody().getServiceResponse().getContext().getOrderActivationStatusInfo().getOrderActivationStatusInfo().get(0).getActivationInfoList().get(0).setAddress(activationCodeArray[1]);
							soeResponse.getServiceBody().getServiceResponse().getContext().getOrderActivationStatusInfo().getOrderActivationStatusInfo().get(0).getActivationInfoList().get(0).setMatchingID(activationCodeArray[2]);
							if(channelId.equalsIgnoreCase("VZW-MFA-ANDROID")) {
								 soeResponse.getServiceBody().getServiceResponse().getContext().getOrderActivationStatusInfo().getOrderActivationStatusInfo().get(0).getActivationInfoList().get(0)
								 .setActivationCode(orderActivationStatusInfo.get(0).getActivationInfoList().get(0).getOdaActivationCode());
							}else {
								 soeResponse.getServiceBody().getServiceResponse().getContext().getOrderActivationStatusInfo().getOrderActivationStatusInfo().get(0).getActivationInfoList().get(0)
								 .setActivationCode(activationCodeArray[0]);	
							}
							
							//logging orderinfo
							Map<String, String> fields = new HashMap<>();
							Map<String,String> orderinfo = new HashMap<>();
							orderinfo.put("eSim", "true");
							fields.put("orderinfo", JacksonMapperFactory.defaultWriter().writeValueAsString(orderinfo));
							LoggerUtil.addCustomPersistField(fields);
						} catch (JsonProcessingException e) {
							logger.error(String.format("Error in orderinfo logging at formatRetrieveActivationStatusResponse : %s" , e.getMessage()));
						}catch(Exception ex){
							logger.error(String.format("Error in formatRetrieveActivationStatusResponse : %s", ex.getMessage() ));
						}
						
					}
		 }
	}

    /**
     *
     * @param soeResponse
     * @param cxpResponse
     */
    public static void formatGetCustomerInfoResponse(CreateCaseAndGetCustomerInfoUIResponse soeResponse,
                                                     GetCustomerInfoCXPResponse cxpResponse, CreateCaseAndGetCustomerInfoUIRequest uiRequest) {

        if (cxpResponse.getErrors() != null)
            soeResponse.setErrors(cxpResponse.getErrors());
        if (cxpResponse.getData() != null) {
            GraphqlData data = new GraphqlData();
            BillingInfo billingInfo = new BillingInfo();
            PricePlanInfo planInfo = new PricePlanInfo();
            AccountAddress address = new AccountAddress();

            data.setChannelId(uiRequest.getChannelId());
            data.setImei(uiRequest.getImei());
            data.setImei2(uiRequest.getImei2());

            //Logic to get the MTN for IMEi matching with deviceId
            int mtnIndex = -1;
            for (Mtn mtn : cxpResponse.getData().getCustomer().getBillAccounts().get(0).getMtns()) {
                for (EquipmentInfo ei : mtn.getEquipmentInfos()) {
                    if (uiRequest.getImei().equalsIgnoreCase(ei.getDeviceInfo().getDeviceId())) {
                        String customerMtn = mtn.getMtn();
                        data.setMtn(customerMtn);
                        mtnIndex = cxpResponse.getData().getCustomer().getBillAccounts().get(0).getMtns().indexOf(mtn);
                    }

                }
            }
            data.setDeviceName(cxpResponse.getData().getCustomer().getBillAccounts().get(0).getMtns().get(mtnIndex).getEquipmentInfos().get(0).getDeviceInfo().getModelName());

            //if no matching MTN found, send error to UI
            CartError error = new CartError();
            CartError[] errors = new CartError[1];
            if (mtnIndex == -1) {
                error.setMessage("System error, please try again ");
                error.setNamespace(CartConstants.SOE_CART_SERVICE);
                errors[0] = error;
                soeResponse.setData(null);
                soeResponse.setErrors(errors);
            }

            else {
                billingInfo.setFirstName(cxpResponse.getData().getCustomer().getBillAccounts().get(0).getMtns()
                        .get(mtnIndex).getPrimaryUser().getFirstName());
                billingInfo.setLastName(cxpResponse.getData().getCustomer().getBillAccounts().get(0).getMtns()
                        .get(mtnIndex).getPrimaryUser().getLastName());

                address.setEmail(cxpResponse.getData().getCustomer().getEmail());

                for (CbrNos cbr : cxpResponse.getData().getCustomer().getCustomerCbrInfo().getCbrNos()) {
                    if (cbr.getType() != null && cbr.getType().equalsIgnoreCase("H")) {
                        address.setPhoneNumber(cbr.getPhoneNumber());
                        break;
                    }
                    
                }

                address.setAddressLine1(cxpResponse.getData().getCustomer().getBillAccounts().get(0).getAccountAddress().getAddressLine1());
                address.setAddressLine2(cxpResponse.getData().getCustomer().getBillAccounts().get(0).getAccountAddress().getAddressLine2());
                address.setCity(cxpResponse.getData().getCustomer().getBillAccounts().get(0).getAccountAddress().getCity());
                address.setCountryCode(cxpResponse.getData().getCustomer().getBillAccounts().get(0).getAccountAddress().getCountryCode());
                address.setCounty(cxpResponse.getData().getCustomer().getBillAccounts().get(0).getAccountAddress().getCounty());
                address.setState(cxpResponse.getData().getCustomer().getBillAccounts().get(0).getAccountAddress().getState());
                address.setZipCode(cxpResponse.getData().getCustomer().getBillAccounts().get(0).getAccountAddress().getZipCode());

                soeResponse.setData(data);
                soeResponse.getData().setBillingInfo(billingInfo);
                soeResponse.getData().getBillingInfo().setAddress(address);

                //SDK - Disconnect flow
                if (!StringUtilities.isEmptyOrNull(uiRequest.getLineAction()) &&
                        uiRequest.getLineAction().equalsIgnoreCase("DISCONNECT")) {
                    planInfo.setPlanName(cxpResponse.getData().getCustomer().getBillAccounts().get(0).getMtns().get(mtnIndex).getPricePlanInfo().getDescription());
                    planInfo.setPlanPrice(cxpResponse.getData().getCustomer().getBillAccounts().get(0).getMtns().get(mtnIndex).getPricePlanInfo().getChargeAmount());
                    planInfo.setPlanId(cxpResponse.getData().getCustomer().getBillAccounts().get(0).getMtns().get(mtnIndex).getPricePlanInfo().getPlanId());
                    soeResponse.getData().setPlanInfo(planInfo);
                }
            }
        }
    }
  	/**
	 * Format initiate device sim activation response.
	 *
	 * @param cxpResponse the cxp response
	 * @param soeResponse the soe response
	 */
	public static void formatInitiateDeviceSimActivationResponse(InitiateDeviceSimActivationCxpResponse cxpResponse,
			InitiateDeviceSimActivationUIResponse soeResponse) {
		if (cxpResponse.getErrors() != null) {
			soeResponse.setErrors(cxpResponse.getErrors());
		}
		if (cxpResponse.getMeta() != null) {
			soeResponse.setMeta(cxpResponse.getMeta());
		}
		if (cxpResponse.getData() != null) {
			soeResponse.setData(cxpResponse.getData());
		}
	}
	
	/**
	 * Format initiate E sim activation response.
	 *
	 * @param cxpResponse the cxp response
	 * @param soeResponse the soe response
	 */
	public static void formatInitiateESimActivationResponse(InitiateESimActivationCXPResponse cxpResponse,
			InitiateESimActivationUIResponse soeResponse) {
		if (cxpResponse.getErrors() != null) {
			soeResponse.setErrors(cxpResponse.getErrors());
		}
		if (cxpResponse.getMeta() != null) {
			soeResponse.setMeta(cxpResponse.getMeta());
		}
		if (cxpResponse.getData() != null) {
			soeResponse.setData(cxpResponse.getData());
			soeResponse.setEsimType(CartConstants.IPAD);
		}
	}
	
	
	/**
    *
    * @param soeResponse
    * @param cxpResponse
    */
   public static void formatCustomerByMtnParentLinesResponse(GetParentLinesUIResponse soeResponse,
		   GetParentLinesCXPResponse cxpResponse) {

       if (cxpResponse.getErrors() != null)
           soeResponse.setErrors(cxpResponse.getErrors());
       if (cxpResponse.getMeta() != null)
           soeResponse.setMeta(cxpResponse.getMeta());
       if (cxpResponse.getData() != null) {
           soeResponse.setData(cxpResponse.getData());
       }
   }

	public static Mono<ValidateCartCXPResponse> formatRetrieveCartEmptyErrorResponsefiveGFlow(boolean orderPlaced) {
		ValidateCartCXPResponse retrieveCartUIresponse = new ValidateCartCXPResponse();
		CartError cartError = new CartError();
		cartError.setNamespace(CartConstants.SOE_CART_SERVICE);
		cartError.setName(CartConstants.REQUEST_VALIDATION_ERROR);
		cartError.setCode("400");
		if(orderPlaced) {
			cartError.setId("0605");
			cartError.setMessage("Order is already Placed.");
		} else {
			cartError.setId("06");
			cartError.setMessage("CartId is not present in redis");
		}
		List<CartError> cartErrorArr = new ArrayList<>();
		cartErrorArr.add(cartError);
		retrieveCartUIresponse.setErrors(cartErrorArr);
		return Mono.just(retrieveCartUIresponse);
	}

	//set device categoty flags based on catalog res
	public static void setDeviceCategoryFlags(CatalogResponse domainCatalogRes, RetrieveCartUIResponse soeResponse) {
		try {
			if(domainCatalogRes != null && domainCatalogRes.getData() != null 
								&& CollectionUtilities.isNotEmptyOrNull(domainCatalogRes.getData().getDeviceCatalogItems())
								&& soeResponse != null && soeResponse.getData() != null ) {
					domainCatalogRes.getData().getDeviceCatalogItems().stream().forEach( deviceCatalog ->{
						if(deviceCatalog.getIsSmartPhone() || deviceCatalog.getIsBasicPhone()) {
							soeResponse.getData().setBasicORSmartPhoneExists(Boolean.TRUE);
						}
						if(deviceCatalog.getIsHomeInternet()) {
							soeResponse.getData().setFiveGDeviceORLTEHomeExists(Boolean.TRUE);
						}
							
					});
				}
		}catch(Exception e) {
  			logger.error(String.format("Exception while setDeviceCategoryFlags:... %s ",e.getMessage()));
  		}
	}

	public static void setAccessoryProtectionFlags(CatalogResponse domainCatalogRes,RetrieveCartUIResponse soeResponse) {
		if(domainCatalogRes != null && domainCatalogRes.getData() != null
				&& CollectionUtilities.isNotEmptyOrNull(domainCatalogRes.getData().getAccessoryCatalogItems())
				&& soeResponse != null && soeResponse.getData() != null ) {

			domainCatalogRes.getData().getAccessoryCatalogItems().stream().forEach( accessoryCatalogItem -> {
				if(CollectionUtilities.isNotEmptyOrNull(accessoryCatalogItem.getSkus())) {
					accessoryCatalogItem.getSkus().stream().forEach( accessorySku -> {
						if(accessorySku != null && accessorySku.getProdCode2() != null && accessorySku.getProdCode2().equalsIgnoreCase("SMA")){
							soeResponse.getData().getCart().getCartHeader().setIsVzPhEligible(Boolean.TRUE);
						}
					});
				}

			});
		}
	}

	private static RetrieveCartCXPResponse emptyResponse() {
		RetrieveCartCXPResponse emptyResp = new RetrieveCartCXPResponse();
		CartError error = new CartError();
		error.setMessage("Empty Cart");
		error.setNamespace("Cart Service");
		CartError[] errors = { error };
		emptyResp.setErrors(errors);
		return emptyResp;
	}

		public static RetrieveCartCXPResponse emptyCartError(){
            RetrieveCartCXPResponse emptyResp = new RetrieveCartCXPResponse();
            CartError error = new CartError();
            error.setMessage("Empty Cart");
            error.setNamespace("Cart Service");
            CartError[] errors = { error };
            emptyResp.setErrors(errors);
            return emptyResp;
        }
}
