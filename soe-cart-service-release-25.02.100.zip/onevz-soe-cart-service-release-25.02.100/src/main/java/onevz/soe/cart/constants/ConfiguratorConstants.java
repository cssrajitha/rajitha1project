package onevz.soe.cart.constants;

/**
 * Configurator Constants class .
 */
public class ConfiguratorConstants {
    public static final String NGD_CONFIGURATOR = "Configurator";
    public static final String ADD_TO_CART_FROM_CONFIGURATOR = "AddAll";
    public static final String CONFIGURATOR_ITEM_TYPE = "DEVICES-AND-SERVICES";
    public static final String ADD_ALL_CONFIGURATOR_METHOD_EXCEPTION = "Exception in addToCartForConfigurator method and error={}";
    public static final String BAU = "BAU";
    public static final String STRING_ZERO = "0";
    public static final String DATE_FORMAT_YYYY_MM_DD_HH_MM_SS = "yyyy.MM.dd.HH.mm.ss";
    public static final String OTHER_EQUIP_CARRIER="Other";


}
