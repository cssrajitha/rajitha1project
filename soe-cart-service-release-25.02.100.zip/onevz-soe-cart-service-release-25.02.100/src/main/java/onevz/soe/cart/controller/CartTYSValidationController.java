package onevz.soe.cart.controller;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.helper.UpdateCartHelper;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.ui.common.CartInfo;
import onevz.soe.cart.ui.requests.ReviewOrderTYSUIRequest;
import onevz.soe.cart.util.CartPegaResponseErrorsUtil2;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import jakarta.validation.Valid;


/**
 * Cart Controller class.
 */
@RestController
@RequestMapping(value = "cart")
public class CartTYSValidationController {
	
	private static final Logger logger = LoggerFactory.getLogger(CartTYSValidationController.class);
	
	@Autowired
	private UpdateCartHelper helper;
	
	@Autowired
	private RedisHelper redisHelper;
	
	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return ResponseEntity
	 *
	 */
	@PostMapping({ "/validateTYSOrderAndReview", })
	public Mono<ResponseEntity<GenericResponse>> tysOrderReviewValidation(ServerHttpRequest httpHeader,
			ServerHttpResponse httpResponse, @Valid @RequestBody ReviewOrderTYSUIRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "validateCartAndCheckout");
		logger.debug("validateCartAndCheckout Request: {}", request);
		String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
				? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
				: "";
		request.setChannelId(channelId);
		
		request.setCartInfo(new CartInfo());
		//Reading cartId, caseID from session
		return redisHelper.getDataFromRedis().flatMap(data ->{
								if(null != data){ 
									populateRequestData(request, data);
								}
						
								return helper.reviewOrderTysValidation(request).map(resp -> {
									ErrorResponse errors2 = null;
									if (resp.getErrors() != null) {
										errors2 = CartPegaResponseErrorsUtil2.handlReviewOrderTysResponseErrors(resp);
									}
									return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
											: ResponseEntity.status(HttpStatus.OK).body(resp);
								});
			
			
			});
	}

	private void populateRequestData(ReviewOrderTYSUIRequest request, CartRedisData data) {
			request.getCartInfo().setAccountNumber(data.getAccountNumber());
			request.setCustomerId(StringUtils.substringBefore(data.getAccountNumber(), "-"));
			request.getCartInfo().setCartId(data.getCartId());
			request.getCartInfo().setCaseId(data.getCaseId());
			request.getCartInfo().setCartCreator(data.getMtn());
			request.setMtn(data.getMtn());
			request.getCartInfo().setCartCreator(data.getCartCreator());
			request.getCartInfo().setUserRole(data.getUserRole());
			request.getCartInfo().setLineActivityType(data.getLineActivityType());
	}

}
