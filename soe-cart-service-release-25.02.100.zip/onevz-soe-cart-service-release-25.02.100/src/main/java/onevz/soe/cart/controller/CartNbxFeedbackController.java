package onevz.soe.cart.controller;

import jakarta.validation.Valid;

import onevz.soe.cart.constants.CartConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import onevz.soe.cart.helper.UpdateCartHelper;
import onevz.soe.cart.responses.NBXFeedbackResponse;
import onevz.soe.cart.ui.requests.NBXFeedbackUIRequest;
import reactor.core.publisher.Mono;

/**
 * Cart Controller class.
 */
//NSADT-53978 removing CrossOrigin annotation in every service
//@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping(value = "cart")
public class CartNbxFeedbackController {

	private static final Logger logger = LoggerFactory.getLogger(CartNbxFeedbackController.class);

	@Autowired
	private UpdateCartHelper helper;

	/**
	 * 
	 * @param binder
	 */
	@InitBinder("*")
	public void initBinderByName(WebDataBinder binder) {
		binder.setDisallowedFields(new String[] { "genericHeader" });
	}

	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return response
	 *
	 */
	@PostMapping("/nbxFeedback")
	public Mono<ResponseEntity<NBXFeedbackResponse>> nbxFeedback(ServerHttpRequest httpHeader,
			ServerHttpResponse httpResponse, @Valid @RequestBody NBXFeedbackUIRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "nbxFeedback");
		logger.debug("nbxFeedback Request: {}", request);
		return helper.nbxFeedbackCall(request).map(resp -> ResponseEntity.status(HttpStatus.OK).body(resp));
	}

}
