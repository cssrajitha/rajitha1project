package onevz.soe.cart.util;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.addFiveGBulkOrder.Add5GBulkOrderContext;
import onevz.soe.cart.model.addFiveGBulkOrder.Add5GBulkOrderServiceBody;
import onevz.soe.cart.model.addFiveGBulkOrder.Add5GBulkOrderServiceRequest;
import onevz.soe.cart.model.addPromoIntent.*;
import onevz.soe.cart.model.assignMtn.AssignMtnContext;
import onevz.soe.cart.model.assignMtn.AssignMtnServiceBody;
import onevz.soe.cart.model.assignMtn.AssignMtnServiceRequest;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.deassignMtn.DeassignMtnContext;
import onevz.soe.cart.model.deassignMtn.DeassignMtnServiceBody;
import onevz.soe.cart.model.deassignMtn.DeassignMtnServiceRequest;
import onevz.soe.cart.model.ispuToDfill.IspuToDfillContext;
import onevz.soe.cart.model.ispuToDfill.IspuToDfillServiceBody;
import onevz.soe.cart.model.ispuToDfill.IspuToDfillServiceRequest;
import onevz.soe.cart.model.manualPairing.ManualPairingContext;
import onevz.soe.cart.model.manualPairing.ManualPairingLine;
import onevz.soe.cart.model.manualPairing.ManualPairingServiceBody;
import onevz.soe.cart.model.manualPairing.ManualPairingServiceRequest;
import onevz.soe.cart.model.portinLater.PortinLaterContext;
import onevz.soe.cart.model.portinLater.PortinLaterLine;
import onevz.soe.cart.model.portinLater.PortinLaterServiceBody;
import onevz.soe.cart.model.portinLater.PortinLaterServiceRequest;
import onevz.soe.cart.model.retrieveCart.TradeInItem;
import onevz.soe.cart.model.retrieveCart.Triage;
import onevz.soe.cart.model.retrieveCart.TriageInfo;
import onevz.soe.cart.model.revokeRebate.RevokeRebatesContext;
import onevz.soe.cart.model.revokeRebate.RevokeRebatesServiceBody;
import onevz.soe.cart.model.revokeRebate.RevokeRebatesServiceRequest;
import onevz.soe.cart.model.splitExceededAmount.SplitExceededAmountContext;
import onevz.soe.cart.model.splitExceededAmount.SplitExceededAmountServiceBody;
import onevz.soe.cart.model.splitExceededAmount.SplitExceededAmountServiceRequest;
import onevz.soe.cart.model.updateDeviceSimId.UpdateDeviceSIMIdContext;
import onevz.soe.cart.model.updateDeviceSimId.UpdateDeviceSIMIdServiceBody;
import onevz.soe.cart.model.updateDeviceSimId.UpdateDeviceSIMIdServiceRequest;
import onevz.soe.cart.model.updateDeviceSimId.UpdateDeviceSimIdLine;
import onevz.soe.cart.model.voidOrder.VoidOrderContext;
import onevz.soe.cart.model.voidOrder.VoidOrderServiceBody;
import onevz.soe.cart.model.voidOrder.VoidOrderServiceRequest;
import onevz.soe.cart.requests.*;
import onevz.soe.cart.ui.common.CartInfo;
import onevz.soe.cart.ui.common.CreateLineData;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.spring.web.filter.RequestAccessContext;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import java.util.*;

import static onevz.soe.cart.constants.CartConstants.SALES_ORDER_PURCHASE;

public class CartPegaRequestUtil5 {

    private static final Logger logger = LoggerFactory.getLogger(CartPegaRequestUtil5.class);
    @Value("${enableCradleForProspect:true}")
    private static boolean enableCradleForProspect;
    @Value("${enableCradleForExistingCustomer:true}")
    private static boolean enableCradleForExistingCustomer;
    /**
     *
     * @param uiRequest
     * @param pegaRequest
     * @return UpdateDeviceSIMIdPEGARequest
     */
    public static UpdateDeviceSIMIdPEGARequest formatUpdateDeviceSimIdRequest(UpdateDeviceSIMIdUIRequest uiRequest,
                                                                              UpdateDeviceSIMIdPEGARequest pegaRequest) {
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(uiRequest.getChannelId());
        pegaRequest.setServiceHeader(serviceHeader);

        UpdateDeviceSIMIdServiceBody serviceBody = new UpdateDeviceSIMIdServiceBody();
        UpdateDeviceSIMIdServiceRequest serviceRequest = new UpdateDeviceSIMIdServiceRequest();
        UpdateDeviceSIMIdContext context = new UpdateDeviceSIMIdContext();

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(uiRequest.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(uiRequest.getCartInfo().getCartCreator());
        customerInfo.setProcessingMTN(uiRequest.getCartInfo().getProcessingMTN());
        context.setCustomerInfo(customerInfo);

        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(uiRequest.getCartInfo().getCartId());
        cartInfo.setAction(CartConstants.UPDATE);
        cartInfo.setItemType("DEVICESIMID");

        if (!StringUtilities.isEmptyOrNull(uiRequest.getCartInfo().getIntendType()))
            cartInfo.setIntendType(uiRequest.getCartInfo().getIntendType());
        else
            cartInfo.setIntendType(CartConstants.EUP);

        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.ADD_DEVICE_SIM,
                uiRequest.getCartInfo().getClientAppName());

        if (!StringUtilities.isEmptyOrNull(uiRequest.getCartInfo().getIntendType())) {
            if((CartConstants.REX).equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())) {
                contextInfo.setIntent(CartConstants.SALES_ORDER_ADJUSTMENT);
                contextInfo.setCallReason(CartConstants.SALES_ORDER_ADJUSTMENT);
                serviceHeader.setServiceName(CartConstants.SALES_ORDER_ADJUSTMENT);
                cartInfo.setIntendType(CartConstants.REX);
            }
        }


        if (!StringUtilities.isEmptyOrNull(uiRequest.getCartInfo().getProcessStep())) {
            contextInfo.setProcessStep(uiRequest.getCartInfo().getProcessStep());
        } else {
            contextInfo.setProcessStep(CartConstants.VALIDATE_DEVICE_SIM_ID_PAGE);
        }
        if (uiRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE") || CartConstants.NEW_CUSTOMER.equalsIgnoreCase(uiRequest.getCartInfo().getCustomerType())){
            CartPegaRequestUtil7.newCustomerOverride(contextInfo, customerInfo, uiRequest.getCartInfo(), uiRequest.getChannelId());
        }


        //MVP2-GR
        if(uiRequest.getCartInfo()!=null && uiRequest.getCartInfo().getCaseId()!=null && uiRequest.getCartInfo().getCaseId().startsWith("SOF")){

            logger.info("SalesOrderFlex Prepay update device and sim Request before PEGA call setting Call Reason");
            contextInfo.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }

        context.setContextInfo(contextInfo);

        List<Line> lines = new ArrayList<>();
        for (UpdateDeviceSimIdLine reqLine : uiRequest.getData().getLines()) {
            Line newLine = new Line();
            newLine.setMtn(reqLine.getMtn());
            newLine.setDevice(reqLine.getDevice());
            newLine.setSim(reqLine.getSim());

            lines.add(newLine);
        }

        Line[] lineArr = new Line[lines.size()];
        lines.toArray(lineArr);

        cartInfo.setLines(lineArr);
        context.setCartInfo(cartInfo);
        context.setCaseId(uiRequest.getCartInfo().getCaseId());

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);

        return pegaRequest;
    }

    /**
     *
     * @param uiRequest2
     * @param pegaRequest2
     * @return AssignMtnPEGARequest
     */
    public static AssignMtnPEGARequest formatAssignMtnRequest(AssignMtnUIRequest uiRequest2,
                                                              AssignMtnPEGARequest pegaRequest2) {
        String preToPostMigrationCookie = RequestAccessContext.obtainCookie(Arrays.asList(CartConstants.PREPAID_TO_POSTPAID_MIGRATION));
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        serviceHeader = CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(uiRequest2.getChannelId());
        pegaRequest2.setServiceHeader(serviceHeader);

        AssignMtnServiceBody serviceBody2 = new AssignMtnServiceBody();

        AssignMtnServiceRequest serviceRequest2 = new AssignMtnServiceRequest();

        AssignMtnContext context2 = new AssignMtnContext();

        CartServiceContextInfo contextInfo2 = new CartServiceContextInfo();
        contextInfo2 = CartPegaRequestUtil.addContextInfo(contextInfo2, CartConstants.ASSIGN_MTN, uiRequest2.getCartInfo().getClientAppName());
        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(uiRequest2.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(uiRequest2.getCartInfo().getCartCreator());
        customerInfo.setProcessingMTN(uiRequest2.getCartInfo().getProcessingMTN());
        if (null != uiRequest2.getCartInfo().getPromoHubJourney() && uiRequest2.getCartInfo().getPromoHubJourney()) {
            if (CartConstants.NSE.equalsIgnoreCase(uiRequest2.getCartInfo().getIntendType())
                    || CartConstants.NSE_BYOD.equalsIgnoreCase(uiRequest2.getCartInfo().getIntendType())){
                if(enableCradleForProspect) {
                    customerInfo.setCradleFlowJourney(CartConstants.ACCESSORIES_INTERSTIAL_PROSPECT);
                }
            }else{
                if(enableCradleForExistingCustomer){
                    customerInfo.setCradleFlowJourney(CartConstants.PROMO_HUB);
                }
            }
        }
        if (CartConstants.NSE_BYOD.equalsIgnoreCase(uiRequest2.getCartInfo().getIntendType())
                || CartConstants.NSE.equalsIgnoreCase(uiRequest2.getCartInfo().getIntendType()) || CartConstants.NSE_5G.equalsIgnoreCase(uiRequest2.getCartInfo().getIntendType()) || CartConstants.NSE_LTE.equalsIgnoreCase(uiRequest2.getCartInfo().getIntendType())) {
            CartPegaRequestUtil7.newCustomerOverride(contextInfo2, customerInfo, uiRequest2.getCartInfo(), uiRequest2.getChannelId());
        }
        context2.setCustomerInfo(customerInfo);

        CartServiceCartInfo cartInfo2 = new CartServiceCartInfo();
        cartInfo2.setCartId(uiRequest2.getCartInfo().getCartId());
        cartInfo2.setClientAppName(uiRequest2.getCartInfo().getClientAppName());
        cartInfo2.setAction(CartConstants.UPDATE);
        cartInfo2.setItemType("ASSIGNMTN");
        if (uiRequest2 != null && uiRequest2.getCartInfo() != null && StringUtilities.isNotEmptyOrNull(uiRequest2.getCartInfo().getIntendType())
                && CartConstants.NSE.equalsIgnoreCase(uiRequest2.getCartInfo().getIntendType()) && uiRequest2.getData() != null) {
            if(uiRequest2.getData().getPaperLessBilling() != null)
                cartInfo2.setPaperLessBilling(uiRequest2.getData().getPaperLessBilling());
            if(uiRequest2.getData().getReceiveSpecialOfferUpdates() != null)
                cartInfo2.setReceiveSpecialOfferUpdates(uiRequest2.getData().getReceiveSpecialOfferUpdates());
        }
        if (!StringUtilities.isEmptyOrNull(uiRequest2.getCartInfo().getIntendType()))
            cartInfo2.setIntendType(uiRequest2.getCartInfo().getIntendType());
        else
            cartInfo2.setIntendType(CartConstants.AAL);

        if(Boolean.TRUE.equals(uiRequest2.isNgdFlow()))
            cartInfo2.setNgdFlow(true);

        context2.setCartInfo(cartInfo2);

        if (!StringUtilities.isEmptyOrNull(uiRequest2.getCartInfo().getProcessStep())) {
            contextInfo2.setProcessStep(uiRequest2.getCartInfo().getProcessStep());
        } else {
            contextInfo2.setProcessStep(CartConstants.INTERIM_PAGE);
        }
        if (!StringUtilities.isEmptyOrNull(uiRequest2.getCartInfo().getIntendType()))
        {
            if((CartConstants.NSE).equalsIgnoreCase(uiRequest2.getCartInfo().getIntendType())){
                contextInfo2.setIntent(CartConstants.NSE);
            }
            else if((CartConstants.NSE_5G).equalsIgnoreCase(uiRequest2.getCartInfo().getIntendType())){
                contextInfo2.setIntent(CartConstants.NSE_5G);
            }
            else if((CartConstants.AAL_5G).equalsIgnoreCase(uiRequest2.getCartInfo().getIntendType())){
                contextInfo2.setIntent(CartConstants.AAL_5G);
            }
            else if((CartConstants.NSE_LTE).equalsIgnoreCase(uiRequest2.getCartInfo().getIntendType())){
                contextInfo2.setIntent(CartConstants.NSE_LTE);
            }
            else if((CartConstants.AAL_LTE).equalsIgnoreCase(uiRequest2.getCartInfo().getIntendType())){
                contextInfo2.setIntent(CartConstants.AAL_LTE);
            }
        }
        else
            contextInfo2.setIntent(CartConstants.AAL);

        if (StringUtilities.isNotEmptyOrNull(uiRequest2.getCartInfo().getRpsIntent())) {
            contextInfo2.setIntent(uiRequest2.getCartInfo().getRpsIntent());
        }
        if (!StringUtilities.isEmptyOrNull(uiRequest2.getCartInfo().getProcessAction())) {
            contextInfo2.setProcessAction(uiRequest2.getCartInfo().getProcessAction());
        }

        //MVP2-GR
        if(uiRequest2.getCartInfo()!=null && uiRequest2.getCartInfo().getCaseId()!=null && uiRequest2.getCartInfo().getCaseId().startsWith("SOF")){

            logger.info("SalesOrderFlex Prepay assign mtn Request before PEGA call setting Call Reason");
            contextInfo2.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }

        context2.setContextInfo(contextInfo2);

        List<Line> lines2 = new ArrayList<>();
        for (Lines reqLine : uiRequest2.getData().getLines()) {

            Line newLine2 = new Line();
            newLine2.setMtn(reqLine.getMtn());
            newLine2.setNpaNxx(reqLine.getNpaNxx());
            newLine2.setUserSelectedMTN(reqLine.getUserSelectedMTN());
            newLine2.setMinNumber(reqLine.getMinNumber());
            if(StringUtilities.isNotEmptyOrNull(reqLine.getMeaCode()))
                newLine2.setMea(reqLine.getMeaCode());
            if(StringUtilities.isNotEmptyOrNull(reqLine.getAccountOwner())) {
                newLine2.setAccountOwner(reqLine.getAccountOwner());
                logger.info("accountOwner");
            }
            if (StringUtilities.isNotEmptyOrNull(preToPostMigrationCookie)) {
                MtnDetails mtnDetails = new MtnDetails();
                mtnDetails.setMtnType(CartConstants.MTN_TYPE_PREPAY_TO_POSTPAY);
                newLine2.setMtnDetails(mtnDetails);
                if (StringUtilities.isNotEmptyOrNull(reqLine.getMobileNumber()))
                    newLine2.setMobileNumber(reqLine.getMobileNumber());
            }
            lines2.add(newLine2);
        }
        Line[] lineArr = new Line[lines2.size()];
        lines2.toArray(lineArr);

        cartInfo2.setLines(lineArr);

        context2.setCartInfo(cartInfo2);
        context2.setCaseId(uiRequest2.getCartInfo().getCaseId());

        serviceRequest2.setContext(context2);
        serviceBody2.setServiceRequest(serviceRequest2);
        pegaRequest2.setServiceBody(serviceBody2);
        return pegaRequest2;
    }

    /**
     *
     * @param uiRequest
     * @param pegaRequest
     * @return DeassignMtnCXPRequest
     */
    public static DeassignMtnPEGARequest formatDeassignMtnRequest(DeassignMtnUIRequest uiRequest,
                                                                  DeassignMtnPEGARequest pegaRequest) {
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(uiRequest.getChannelId());
        pegaRequest.setServiceHeader(serviceHeader);

        DeassignMtnServiceBody serviceBody = new DeassignMtnServiceBody();

        DeassignMtnServiceRequest serviceRequest = new DeassignMtnServiceRequest();

        DeassignMtnContext context = new DeassignMtnContext();
        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.DEASSIGN_MTN,
                uiRequest.getCartInfo().getClientAppName());
        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(uiRequest.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(uiRequest.getCartInfo().getCartCreator());
        customerInfo.setProcessingMTN(uiRequest.getCartInfo().getProcessingMTN());
        if (CartConstants.NSE_BYOD.equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())
                || CartConstants.NSE.equalsIgnoreCase(uiRequest.getCartInfo().getIntendType()) || CartConstants.NSE_5G.equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())) {
            CartPegaRequestUtil7.newCustomerOverride(contextInfo, customerInfo, uiRequest.getCartInfo(), uiRequest.getChannelId());
        }
        context.setCustomerInfo(customerInfo);

        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(uiRequest.getCartInfo().getCartId());
        cartInfo.setClientAppName(uiRequest.getCartInfo().getClientAppName());
        cartInfo.setAction(CartConstants.UPDATE);
        cartInfo.setItemType("DEASSIGNMTN");
        if (!StringUtilities.isEmptyOrNull(uiRequest.getCartInfo().getIntendType()))
            cartInfo.setIntendType(uiRequest.getCartInfo().getIntendType());
        else
            cartInfo.setIntendType(CartConstants.AAL);

        context.setCartInfo(cartInfo);

        if (!StringUtilities.isEmptyOrNull(uiRequest.getCartInfo().getProcessStep())) {
            contextInfo.setProcessStep(uiRequest.getCartInfo().getProcessStep());
        } else {
            contextInfo.setProcessStep(CartConstants.INTERIM_PAGE);
        }
        if (!StringUtilities.isEmptyOrNull(uiRequest.getCartInfo().getIntendType())
                && ((CartConstants.NSE).equalsIgnoreCase(uiRequest.getCartInfo().getIntendType()))) {
            contextInfo.setIntent(CartConstants.NSE);
        }
        context.setContextInfo(contextInfo);

        List<Line> lines = new ArrayList<>();
        for (Lines reqLine : uiRequest.getData().getLines()) {

            Line newLine = new Line();
            newLine.setMtn(reqLine.getMtn());
            lines.add(newLine);
        }
        Line[] lineArr = new Line[lines.size()];
        lines.toArray(lineArr);

        cartInfo.setLines(lineArr);

        context.setCaseId(uiRequest.getCartInfo().getCaseId());
        context.setCartInfo(cartInfo);

        //MVP2-GR
        if(uiRequest.getCartInfo()!=null && uiRequest.getCartInfo().getCaseId()!=null && uiRequest.getCartInfo().getCaseId().startsWith("SOF")){

            logger.info("SalesOrderFlex Prepay deassign mtn Request before PEGA call setting Call Reason");
            contextInfo.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);
        return pegaRequest;
    }

    /**
     *
     * @param pegaRequest
     * @param request
     * @return Add5GBulkOrderPEGARequest
     */
    public static Add5GBulkOrderPEGARequest formatAdd5GBulkOrderRequest(Add5GBulkOrderPEGARequest pegaRequest,
                                                                        Add5GBulkOrderUIRequest request) {

        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        serviceHeader = CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(request.getChannelId());
        pegaRequest.setServiceHeader(serviceHeader);

        Add5GBulkOrderServiceBody serviceBody = new Add5GBulkOrderServiceBody();
        Add5GBulkOrderServiceRequest serviceRequest = new Add5GBulkOrderServiceRequest();
        Add5GBulkOrderContext context = new Add5GBulkOrderContext();

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
        customerInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());

        context.setCustomerInfo(customerInfo);

        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(request.getCartInfo().getCartId());
        cartInfo.setClientAppName(request.getCartInfo().getClientAppName());
        cartInfo.setAction(CartConstants.UPDATE);
        cartInfo.setItemType(CartConstants.FIVEGBULK);

        cartInfo.setIntendType(CartConstants.AAL_5G);

        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        contextInfo = CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.FIVEGBULK, request.getCartInfo().getClientAppName());
        if (null != request.getCartInfo().getProcessStep() && "".equals(request.getCartInfo().getProcessStep()))
            contextInfo.setProcessStep(request.getCartInfo().getProcessStep());
        else
            // change this
            contextInfo.setProcessStep("");

        cartInfo.setAccount(request.getData().getAccount());
        List<Line> lines = new ArrayList<>();

        for (Lines reqLine : request.getData().getLines()) {
            Line newLine = new Line();
            if (reqLine.getMtn() != null)
                newLine.setMtn(reqLine.getMtn());
            if (reqLine.getContractTerm() != null)
                newLine.setContractTerm(reqLine.getContractTerm());
            if (reqLine.getDevice() != null) {
                newLine.setDevice(reqLine.getDevice());
                newLine.getDevice().setQty(1);
            }
            if (reqLine.getE911Address() != null)
                newLine.setE911Address(reqLine.getE911Address());
            if (reqLine.getSim() != null)
                newLine.setSim(reqLine.getSim());
            if (reqLine.getAddFeatures() != null || reqLine.getRemoveFeatures() != null) {
                FeatureAction action = new FeatureAction();
                if (reqLine.getAddFeatures() != null)
                    action.setAdd(reqLine.getAddFeatures());
                if (reqLine.getRemoveFeatures() != null)
                    action.setRemove(reqLine.getRemoveFeatures());
                newLine.setFeatures(action);
            }
            if (reqLine.getAddAccessories() != null)
                newLine.setAddAccessories(reqLine.getAddAccessories());
            if (reqLine.getRemoveAccessories() != null)
                newLine.setRemoveAccessories(reqLine.getRemoveAccessories());
            if (reqLine.getIspuFlow() != null)
                newLine.setIspuFlow(reqLine.getIspuFlow());
            if (reqLine.getSddZipCode() != null)
                newLine.setSddZipCode(reqLine.getSddZipCode());
            if (reqLine.getDepletionType() != null)
                newLine.setDepletionType(reqLine.getDepletionType());
            if (reqLine.getDepletionLocationCode() != null)
                newLine.setDepletionLocationCode(CartUtil.removeSpecialCharacters(reqLine.getDepletionLocationCode(), request.getChannelId()));
            else
                newLine.setDepletionLocationCode("");
            lines.add(newLine);
        }
        Line[] lineArr = new Line[lines.size()];
        lines.toArray(lineArr);

        cartInfo.setLines(lineArr);

        context.setContextInfo(contextInfo);
        context.setCartInfo(cartInfo);
        context.setCaseId(request.getCartInfo().getCaseId());

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);

        return pegaRequest;
    }

    /**
     *
     * @param createLineReq
     * @param uiRequest
     * @return pegaRequest
     */
    public static CreateLineUIRequest formCreateLineReq(CreateLineUIRequest createLineReq,
                                                        AddDeviceUIRequest uiRequest) {
        CartInfo cartInfo = new CartInfo();
        cartInfo.setClientAppName(uiRequest.getCartInfo().getClientAppName());
        cartInfo.setCartId(uiRequest.getCartInfo().getCartId());
        cartInfo.setCaseId(uiRequest.getCartInfo().getCaseId());
        cartInfo.setAccountNumber(uiRequest.getCartInfo().getAccountNumber());
        cartInfo.setCartCreator(uiRequest.getCartInfo().getCartCreator());
        cartInfo.setIntendType(uiRequest.getCartInfo().getIntendType());
        createLineReq.setCartInfo(cartInfo);
        createLineReq.getCartInfo().setProcessStep("MTNSelectionPage");
        createLineReq.getCartInfo().setProcessingMTN("");
        // createLineReq
        for (Lines line : uiRequest.getData().getLines())
            line.setMtn("");
        createLineReq.setData(new CreateLineData());
        createLineReq.getData().setLines(uiRequest.getData().getLines());
        return createLineReq;
    }

    /**
     *
     * @param pegaRequest2
     * @param request2
     * @return pegaRequest2
     */
    public static ManualPairingPEGARequest formatManualPairingRequest(ManualPairingPEGARequest pegaRequest2,
                                                                      ManualPairingUIRequest request2) {

        CartServiceServiceHeader serviceHeader2 = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader2);
        serviceHeader2.setClientId(request2.getChannelId());

        ManualPairingServiceBody serviceBody2 = new ManualPairingServiceBody();
        ManualPairingServiceRequest serviceRequest2 = new ManualPairingServiceRequest();

        ManualPairingContext context2 = new ManualPairingContext();

        CartServiceCustomerInfo customerInfo2 = new CartServiceCustomerInfo();
        customerInfo2.setAccountNumber(request2.getCartInfo().getAccountNumber());
        customerInfo2.setCartCreator(request2.getCartInfo().getCartCreator());

        CartServiceCartInfo cartInfo2 = new CartServiceCartInfo();
        cartInfo2.setCartId(request2.getCartInfo().getCartId());
        cartInfo2.setItemType(CartConstants.MANUAL_PAIRING);
        cartInfo2.setAction(CartConstants.UPDATE);
        if (!StringUtilities.isEmptyOrNull(request2.getCartInfo().getIntendType()))
            cartInfo2.setIntendType(request2.getCartInfo().getIntendType());
        else
            cartInfo2.setIntendType(CartConstants.EUP);

        CartServiceContextInfo contextInfo2 = new CartServiceContextInfo();

        List<Line> lines2 = new ArrayList<>();
        CartPegaRequestUtil.addContextInfo(contextInfo2, CartConstants.UPDATE_MANUAL_PAIRING,
                request2.getCartInfo().getClientAppName());

        if (request2.getData().getLines() != null) {
            for (ManualPairingLine reqLine : request2.getData().getLines()) {
                Line newLine2 = new Line();
                newLine2.setMtn(reqLine.getMtn());
                newLine2.setPairedPhone(reqLine.getPairedPhone());
                newLine2.setBenefitPairType(reqLine.getBenefitPairType());

                lines2.add(newLine2);
            }
            Line[] lineArr = new Line[lines2.size()];
            lines2.toArray(lineArr);

            cartInfo2.setLines(lineArr);
        }

        if (!StringUtilities.isEmptyOrNull(request2.getCartInfo().getProcessStep())) {
            contextInfo2.setProcessStep(request2.getCartInfo().getProcessStep());
        }

        context2.setCaseId(request2.getCartInfo().getCaseId());
        context2.setCustomerInfo(customerInfo2);
        context2.setCartInfo(cartInfo2);

        //MVP2-GR
        if(request2.getCartInfo()!=null && request2.getCartInfo().getCaseId()!=null && request2.getCartInfo().getCaseId().startsWith("SOF")){

            logger.info("SalesOrderFlex Prepay manual pairing Request before PEGA call setting Call Reason");
            contextInfo2.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader2.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }

        context2.setContextInfo(contextInfo2);

        serviceRequest2.setContext(context2);
        serviceBody2.setServiceRequest(serviceRequest2);

        pegaRequest2.setServiceBody(serviceBody2);
        pegaRequest2.setServiceHeader(serviceHeader2);

        return pegaRequest2;

    }

    /**
     * @param pegaRequest
     * @param request
     * @return RevokeRebatesPEGARequest
     */

    public static RevokeRebatesPEGARequest formatRevokeRebatesRequest(RevokeRebatesPEGARequest pegaRequest,
                                                                      RevokeRebatesUIRequest request) {

        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(request.getChannelId());
        pegaRequest.setServiceHeader(serviceHeader);

        RevokeRebatesServiceBody serviceBody = new RevokeRebatesServiceBody();
        RevokeRebatesServiceRequest serviceRequest = new RevokeRebatesServiceRequest();
        RevokeRebatesContext context = new RevokeRebatesContext();

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
        customerInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());
        context.setCustomerInfo(customerInfo);

        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(request.getCartInfo().getCartId());
        cartInfo.setClientAppName(request.getCartInfo().getClientAppName());
        cartInfo.setAction(CartConstants.UPDATE);
        cartInfo.setItemType(CartConstants.REVOKE_REBATES);
        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType()))
            cartInfo.setIntendType(request.getCartInfo().getIntendType());
        else
            cartInfo.setIntendType(CartConstants.EUP);

        List<Line> lines = new ArrayList<>();

        for (Lines reqLine : request.getData().getLines()) {
            Line newLine = new Line();
            if (reqLine.getMtn() != null)
                newLine.setMtn(reqLine.getMtn());
            if (reqLine.getRebateUpdate() != null)
                newLine.setRebateUpdate(reqLine.getRebateUpdate());
            lines.add(newLine);
        }
        Line[] lineArr = new Line[lines.size()];
        lines.toArray(lineArr);

        cartInfo.setLines(lineArr);

        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.REVOKE_REBATES,
                request.getCartInfo().getClientAppName());
        context.setCartInfo(cartInfo);
        context.setCaseId(request.getCartInfo().getCaseId());
        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessStep())) {
            contextInfo.setProcessStep(request.getCartInfo().getProcessStep());
        } else {
            contextInfo.setProcessStep("OrderReview-Shipping");
        }
        if (cartInfo.getIntendType().equals(CartConstants.AAL))
            contextInfo.setIntent(CartConstants.AAL);
        context.setContextInfo(contextInfo);

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);

        return pegaRequest;
    }

    /**
     * @param pegaRequest3
     * @param request
     * @return PortinLaterPEGARequest
     */
    public static PortinLaterPEGARequest formatUpdatePortInLaterRequest(PortinLaterPEGARequest pegaRequest3,
                                                                        PortinLaterUIRequest request) {

        CartServiceServiceHeader serviceHeader3 = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader3);
        serviceHeader3.setClientId(request.getChannelId());

        PortinLaterServiceBody serviceBody3 = new PortinLaterServiceBody();
        PortinLaterServiceRequest serviceRequest3 = new PortinLaterServiceRequest();

        PortinLaterContext context3 = new PortinLaterContext();

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
        customerInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());

        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(request.getCartInfo().getCartId());
        cartInfo.setItemType(CartConstants.PORTIN_LATER);
        cartInfo.setIntendType(request.getCartInfo().getIntendType());
        cartInfo.setAction(CartConstants.UPDATE);

        CartServiceContextInfo contextInfo3 = new CartServiceContextInfo();

        List<Line> lines = new ArrayList<>();
        CartPegaRequestUtil.addContextInfo(contextInfo3, CartConstants.UPDATE_PORTIN_LATER,
                request.getCartInfo().getClientAppName());

        if (request.getData().getLines() != null) {
            for (PortinLaterLine reqLine : request.getData().getLines()) {
                Line newLine = new Line();
                newLine.setMtn(reqLine.getMtn());
                newLine.setPortInLater(reqLine.getPortInLater());

                lines.add(newLine);
            }
            Line[] lineArr = new Line[lines.size()];
            lines.toArray(lineArr);

            cartInfo.setLines(lineArr);
        }

        contextInfo3.setCallReason(CartConstants.SALES_ORDER_PURCHASE);
        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessStep()))
            contextInfo3.setProcessStep(request.getCartInfo().getProcessStep());

        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType())
                && CartConstants.BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())) {

            contextInfo3.setIntent(CartConstants.BYOD);

        }
        context3.setCaseId(request.getCartInfo().getCaseId());
        context3.setCustomerInfo(customerInfo);
        context3.setCartInfo(cartInfo);

        //MVP2-GR
        if(request.getCartInfo()!=null && request.getCartInfo().getCaseId()!=null && request.getCartInfo().getCaseId().startsWith("SOF")){

            logger.info("SalesOrderFlex Prepay update port in later Request before PEGA call setting Call Reason");
            contextInfo3.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader3.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }

        context3.setContextInfo(contextInfo3);

        serviceRequest3.setContext(context3);
        serviceBody3.setServiceRequest(serviceRequest3);

        pegaRequest3.setServiceHeader(serviceHeader3);
        pegaRequest3.setServiceBody(serviceBody3);

        return pegaRequest3;
    }

    /**
     *
     * @param uiRequest
     * @param pegaRequest
     * @return VoidOrderPEGARequest
     */
    public static VoidOrderPEGARequest formatVoidOrderRequest(VoidOrderUIRequest uiRequest,
                                                              VoidOrderPEGARequest pegaRequest) {
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        serviceHeader = CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(uiRequest.getChannelId());
        pegaRequest.setServiceHeader(serviceHeader);

        VoidOrderServiceBody serviceBody = new VoidOrderServiceBody();

        VoidOrderServiceRequest serviceRequest = new VoidOrderServiceRequest();

        VoidOrderContext context = new VoidOrderContext();

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(uiRequest.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(uiRequest.getCartInfo().getCartCreator());
        customerInfo.setProcessingMTN(uiRequest.getCartInfo().getProcessingMTN());
        if (CartConstants.NSE_BYOD.equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())
                || CartConstants.NSE.equalsIgnoreCase(uiRequest.getCartInfo().getIntendType()) || CartConstants.NSE_5G.equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())) {
            customerInfo.setAccountNumber("");
            customerInfo.setCustomerType(CartConstants.NEW_CUSTOMER);
            if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getCreditAppNum()))
                customerInfo.setOriginalCreditApprovalNumber(uiRequest.getCartInfo().getCreditAppNum());
            if (CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(uiRequest.getChannelId()))
                    && StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getCreditAppNum()))
                customerInfo.setCartCreator(uiRequest.getCartInfo().getCreditAppNum());
        }
        context.setCustomerInfo(customerInfo);

        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(uiRequest.getCartInfo().getCartId());
        cartInfo.setClientAppName(uiRequest.getCartInfo().getClientAppName());
        context.setCartInfo(cartInfo);

        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        contextInfo = CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.VOID_ORDER, uiRequest.getCartInfo().getClientAppName());
        if (!StringUtilities.isEmptyOrNull(uiRequest.getCartInfo().getProcessStep())) {
            contextInfo.setProcessStep(uiRequest.getCartInfo().getProcessStep());
        } else {
            contextInfo.setProcessStep(CartConstants.ORDER_REVIEW_SHIPPING);
        }
        if (CartConstants.NSE_BYOD.equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())
                || CartConstants.NSE.equalsIgnoreCase(uiRequest.getCartInfo().getIntendType()) || CartConstants.NSE_5G.equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())) {
            contextInfo.setIntent(uiRequest.getCartInfo().getIntendType());
        }

        //defect-fix
        if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getIntendType()) &&
                uiRequest.getCartInfo().getIntendType().equalsIgnoreCase(CartConstants.REFUND_EXCHANGE)) {
            contextInfo.setIntent(CartConstants.REX);
            contextInfo.setCallReason(CartConstants.SALES_ORDER_ADJUSTMENT);
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_ADJUSTMENT);
        }

        //MVP2-GR
        if(uiRequest.getCartInfo()!=null && uiRequest.getCartInfo().getCaseId()!=null && uiRequest.getCartInfo().getCaseId().startsWith("SOF")){

            logger.info("SalesOrderFlex Prepay void order Request before PEGA call setting Call Reason");
            contextInfo.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }

        context.setContextInfo(contextInfo);

        context.setCaseId(uiRequest.getCartInfo().getCaseId());
        context.setCartInfo(cartInfo);

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);
        return pegaRequest;
    }

    /**
     *
     * @param uiRequest
     * @param pegaRequest
     * @return IspuToDfillPEGARequest
     */
    public static IspuToDfillPEGARequest formatIspuToDfillRequest(IspuToDfillUIRequest uiRequest,
                                                                  IspuToDfillPEGARequest pegaRequest) {
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(uiRequest.getChannelId());
        pegaRequest.setServiceHeader(serviceHeader);

        IspuToDfillServiceBody serviceBody = new IspuToDfillServiceBody();

        IspuToDfillServiceRequest serviceRequest = new IspuToDfillServiceRequest();

        IspuToDfillContext context1 = new IspuToDfillContext();

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(uiRequest.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(uiRequest.getCartInfo().getCartCreator());
        customerInfo.setProcessingMTN(uiRequest.getCartInfo().getProcessingMTN());

        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(uiRequest.getCartInfo().getCartId());
        cartInfo.setClientAppName(uiRequest.getCartInfo().getClientAppName());
        cartInfo.setAction(CartConstants.UPDATE);
        cartInfo.setItemType("ISPU-TO-DFILL");
        if (!StringUtilities.isEmptyOrNull(uiRequest.getCartInfo().getIntendType()))
            cartInfo.setIntendType(uiRequest.getCartInfo().getIntendType());
        else
            cartInfo.setIntendType(CartConstants.EUP);

        context1.setCartInfo(cartInfo);

        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.ISPU_TO_DFILL,
                uiRequest.getCartInfo().getClientAppName());
        if (!StringUtilities.isEmptyOrNull(uiRequest.getCartInfo().getProcessStep())) {
            contextInfo.setProcessStep(uiRequest.getCartInfo().getProcessStep());
        } else {
            contextInfo.setProcessStep(CartConstants.GRIDWALLPDP);
        }
        context1.setContextInfo(contextInfo);

        List<Line> lines1 = new ArrayList<>();
        for (Lines reqLine1 : uiRequest.getData().getLines()) {

            Line newLine1 = new Line();
            newLine1.setMtn(reqLine1.getMtn());
            lines1.add(newLine1);
        }
        Line[] lineArr1 = new Line[lines1.size()];
        lines1.toArray(lineArr1);

        cartInfo.setLines(lineArr1);

        context1.setCaseId(uiRequest.getCartInfo().getCaseId());
        context1.setCartInfo(cartInfo);
        if (CartConstants.NSE_BYOD.equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())
                || CartConstants.NSE.equalsIgnoreCase(uiRequest.getCartInfo().getIntendType()) || CartConstants.NSE_5G.equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())) {
            if (StringUtilities.isEmptyOrNull(uiRequest.getCartInfo().getAccountNumber()))
                customerInfo.setAccountNumber("");
            if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getGlobalId()))
                customerInfo.setGlobalId(uiRequest.getCartInfo().getGlobalId());
            if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getCartCreator()))
                customerInfo.setCartCreator(uiRequest.getCartInfo().getCartCreator());
            if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getSessionId())) {
                if (StringUtilities.isEmptyOrNull(uiRequest.getCartInfo().getGlobalId()))
                    customerInfo.setGlobalId(uiRequest.getCartInfo().getSessionId());
                if (StringUtilities.isEmptyOrNull(uiRequest.getCartInfo().getCartCreator()))
                    customerInfo.setCartCreator(uiRequest.getCartInfo().getSessionId());
            }

            if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getAccountType()))
                customerInfo.setAccountType(uiRequest.getCartInfo().getAccountType());

            if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getCustomerType()))
                customerInfo.setCustomerType(uiRequest.getCartInfo().getCustomerType());
            else
                customerInfo.setCustomerType(CartConstants.NEW_CUSTOMER);
            if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getMtnFlow()))
                customerInfo.setMtnFlow(uiRequest.getCartInfo().getMtnFlow());

            if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getCreditAppNum())) {
                customerInfo.setCartCreator(uiRequest.getCartInfo().getCreditAppNum());
                customerInfo.setOriginalCreditApprovalNumber(uiRequest.getCartInfo().getCreditAppNum());
            }

        }
        context1.setCustomerInfo(customerInfo);
        serviceRequest.setContext(context1);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);
        return pegaRequest;
    }

    /**
     *
     * @param uiRequest1
     * @param pegaRequest1
     * @return SaveCartPegaRequest
     */
    public static SplitExceededAmountPEGARequest formatSplitExceededAmountRequest(
            SplitExceededAmountPEGARequest pegaRequest1, SplitExceededAmountUIRequest uiRequest1) {
        CartServiceServiceHeader serviceHeader1 = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader1);
        serviceHeader1.setClientId(uiRequest1.getChannelId());
        pegaRequest1.setServiceHeader(serviceHeader1);

        SplitExceededAmountServiceBody serviceBody = new SplitExceededAmountServiceBody();
        SplitExceededAmountServiceRequest serviceRequest = new SplitExceededAmountServiceRequest();
        SplitExceededAmountContext context1 = new SplitExceededAmountContext();

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(uiRequest1.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(uiRequest1.getCartInfo().getCartCreator());
        customerInfo.setProcessingMTN(uiRequest1.getCartInfo().getProcessingMTN());
        context1.setCustomerInfo(customerInfo);

        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(uiRequest1.getCartInfo().getCartId());
        cartInfo.setItemType("SPLITEXCEEDEDAMOUNT");
        if (!StringUtilities.isEmptyOrNull(uiRequest1.getCartInfo().getIntendType()))
            cartInfo.setIntendType(uiRequest1.getCartInfo().getIntendType());
        else
            cartInfo.setIntendType(CartConstants.AAL);

        context1.setCartInfo(cartInfo);
        // ContextInfo needs to be updated upon receiving PEGA contracts
        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.SPLIT_EXCEEDED_AMOUNT,
                uiRequest1.getCartInfo().getClientAppName());
        if (!StringUtilities.isEmptyOrNull(uiRequest1.getCartInfo().getProcessStep())) {
            contextInfo.setProcessStep(uiRequest1.getCartInfo().getProcessStep());
        } else {
            contextInfo.setProcessStep(CartConstants.SHOPPING_CART);
        }
        if (CartConstants.AAL.equalsIgnoreCase(cartInfo.getIntendType())) {
            contextInfo.setIntent(CartConstants.AAL);
        }
        if (uiRequest1.getCartInfo().getIntendType().toUpperCase().contains("NSE")
                || CartConstants.NEW_CUSTOMER.equalsIgnoreCase(uiRequest1.getCartInfo().getCustomerType()) ) {
            CartPegaRequestUtil7.newCustomerOverride(contextInfo, customerInfo, uiRequest1.getCartInfo(), uiRequest1.getChannelId());
        }

        //MVP2-GR
        if(uiRequest1.getCartInfo()!=null && uiRequest1.getCartInfo().getCaseId()!=null && uiRequest1.getCartInfo().getCaseId().startsWith("SOF")){

            logger.info("SalesOrderFlex Prepay split exceeded amount Request before PEGA call setting Call Reason");
            contextInfo.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader1.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }

        context1.setContextInfo(contextInfo);

        context1.setCaseId(uiRequest1.getCartInfo().getCaseId());
        context1.setCartInfo(cartInfo);

        serviceRequest.setContext(context1);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest1.setServiceBody(serviceBody);
        return pegaRequest1;

    }
    /**
     *
     * @param uiRequest
     * @param pegaRequest
     * @return AddPromoIntentPEGARequest
     */
    public static AddPromoIntentPEGARequest formatAddPromoIntentRequest(AddPromoIntentUIRequest uiRequest,
                                                                        AddPromoIntentPEGARequest pegaRequest,boolean enableUpgradeSkipTradeFlow) {
        /* service header*/
        boolean upgradeSkipTradein = false;
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(uiRequest.getChannelId());
        pegaRequest.setServiceHeader(serviceHeader);

        /* service body*/
        AddPromoIntentServiceBody serviceBody = new AddPromoIntentServiceBody();
        AddPromoIntentServiceRequest serviceRequest = new AddPromoIntentServiceRequest();
        AddPromoIntentContext context = new AddPromoIntentContext();
        CartServiceContextInfo contextInfo = new CartServiceContextInfo();

        contextInfo.setCallReason(SALES_ORDER_PURCHASE);
        contextInfo.setProcessAction(null != uiRequest.getCartInfo().getProcessAction() ? uiRequest.getCartInfo().getProcessAction() : CartConstants.ADD_PROMO_INTENT);
        boolean autoSkipTradin = false;
        if (!StringUtilities.isEmptyOrNull(uiRequest.getCartInfo().getIntendType())&&CartConstants.EUP.equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())) {
            contextInfo.setIntent(CartConstants.UPGRADE);
            if(uiRequest.getData() != null && uiRequest.getData().isAutoAddTradeInEnable()) {
                autoSkipTradin = uiRequest.getData().isAutoAddTradeInEnable();
            }
            if(enableUpgradeSkipTradeFlow && autoSkipTradin) {
                upgradeSkipTradein = checkIfUpgradeSkipTradein(uiRequest);
            }
        }else if (!StringUtilities.isEmptyOrNull(uiRequest.getCartInfo().getIntendType())&&CartConstants.AAL.equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())) {
            contextInfo.setIntent(CartConstants.AAL);
        }else if (!StringUtilities.isEmptyOrNull(uiRequest.getCartInfo().getIntendType())
                && (CartConstants.NSE).equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())) {
            contextInfo.setIntent(CartConstants.NSE);
        }
        logger.info("autoSkipTradeIn enableUpgradeSkipTradeFlow={},autoSkipTradin={}, upgradeSkipTradein={}", enableUpgradeSkipTradeFlow,autoSkipTradin, upgradeSkipTradein);
        if (!StringUtilities.isEmptyOrNull(uiRequest.getCartInfo().getProcessStep())) {
            contextInfo.setProcessStep(uiRequest.getCartInfo().getProcessStep());
        } else {
            contextInfo.setProcessStep(CartConstants.OFFER_INTERSTITIAL);
        }


        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(uiRequest.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(uiRequest.getCartInfo().getCartCreator());
        customerInfo.setProcessingMTN(uiRequest.getCartInfo().getProcessingMTN());
        customerInfo.setGlobalId(uiRequest.getCartInfo().getGlobalId());
        customerInfo.setCustomerType(uiRequest.getCartInfo().getCustomerType());
        customerInfo.setMtnFlow(uiRequest.getCartInfo().getMtnFlow());
        if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getIntendType()) && uiRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE")) {
            CartPegaRequestUtil7.newCustomerOverride(contextInfo, customerInfo, uiRequest.getCartInfo(), uiRequest.getChannelId());
        }

        CartServiceCartInfo cartInfo = new CartServiceCartInfo();

        cartInfo.setCartId(uiRequest.getCartInfo().getCartId());
        cartInfo.setItemType(upgradeSkipTradein ? CartConstants.PROMO_TRADE : CartConstants.PROMO);
        cartInfo.setTradeInShippingType(upgradeSkipTradein ? CartConstants.TRADEIN_SHIPPING_TYPE: "");
        cartInfo.setAction(upgradeSkipTradein ? CartConstants.UPDATE :  CartConstants.ADD);
        if (!StringUtilities.isEmptyOrNull(uiRequest.getCartInfo().getIntendType()))
            cartInfo.setIntendType(uiRequest.getCartInfo().getIntendType());
        else
            cartInfo.setIntendType(CartConstants.NSE);

        cartInfo.setLines(uiRequest.getData().getLines());
        context.setCartInfo(cartInfo);
        context.setCustomerInfo(customerInfo);

        context.setContextInfo(contextInfo);

        context.setCaseId(uiRequest.getCartInfo().getCaseId());

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);
        return pegaRequest;
    }

    public static boolean checkIfUpgradeSkipTradein(AddPromoIntentUIRequest uiRequest) {
        boolean upgradeSkipTradein;
        upgradeSkipTradein = Optional.of(uiRequest).map(AddPromoIntentUIRequest::getData).map(AddPromoIntentData::getLines)
                .map(lines -> Arrays.stream(lines).map(Line::getPromoIntent).anyMatch(promos -> Arrays.stream(promos).map(AddPromoIntent::getPromoType).filter(StringUtilities::isNotEmptyOrNull)
                        .map(String::toLowerCase)
                        .anyMatch(promoType -> promoType.contains("trade")))).orElse(Boolean.FALSE);
        if (upgradeSkipTradein) {
            formatUpgradeSkipTradeIn(uiRequest);
        }
        return upgradeSkipTradein;
    }

    private static void formatUpgradeSkipTradeIn(AddPromoIntentUIRequest uiRequest) {
        Arrays.asList(uiRequest.getData().getLines()).forEach(line -> {
            Optional<AddDeviceTradeInInfo> addDeviceTradeInInfo = Optional.of(line).map(Line::getTradeInInfo);
            boolean isValidTradeInPromo = addDeviceTradeInInfo.map(AddDeviceTradeInInfo::getAemOfferIds).filter(CollectionUtilities::isNotEmptyOrNull).isPresent() ||
                    addDeviceTradeInInfo.map(AddDeviceTradeInInfo::getTradeinMarketingId).filter(StringUtilities::isNotEmptyOrNull).isPresent();
            if(!isValidTradeInPromo){
                line.setTradeInInfo(null);
            }
            List<TradeInItem> tradeInItemList = new ArrayList<>();
            TradeInItem tradeInItem = new TradeInItem();
            tradeInItem.setLineSeqNum("1");
            tradeInItem.setRecycleSeqNum("1");
            if (StringUtilities.isNotEmptyOrNull(line.getMtn())) {
                tradeInItem.setTradeDeviceMDN(line.getMtn());
            } else if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getCartCreator())) {
                tradeInItem.setTradeDeviceMDN(uiRequest.getCartInfo().getCartCreator());
            }
            tradeInItem.setEquipCarrier(CartConstants.EQUIP_CARRIER);
            tradeInItem.setDeviceCondition(CartConstants.DEVICE_CONDITION);

            TriageInfo triageInfo = new TriageInfo();
            triageInfo.setTriageCount("4");

            Triage triage1 = new Triage();
            triage1.setTriageAnswer(CartConstants.TRIAGE_ANSWER);
            triage1.setTriageQuestionId(CartConstants.TRIAGE_QUES_IND_2);
            triage1.setQuestionText(CartConstants.QUESTION_TEXT_2);

            Triage triage0 = new Triage();
            triage0.setTriageAnswer(CartConstants.TRIAGE_ANSWER);
            triage0.setTriageQuestionId(CartConstants.TRIAGE_QUES_IND_1);
            triage0.setQuestionText(CartConstants.QUESTION_TEXT_1);

            Triage triage2 = new Triage();
            triage2.setTriageAnswer(CartConstants.TRIAGE_ANSWER);
            triage2.setTriageQuestionId(CartConstants.TRIAGE_QUES_IND_5);
            triage2.setQuestionText(CartConstants.QUESTION_TEXT_5);

            if (line.getIsBatteryDamaged() != null && line.getIsBatteryDamaged()) {
                tradeInItem.setDeviceCondition(CartConstants.DEVICE_CONDITION_BAD);
                triage2.setTriageAnswer(CartConstants.TRIAGE_ANSWER_NO);
            }

            Triage triage3 = new Triage();
            triage3.setTriageAnswer(CartConstants.TRIAGE_ANSWER);
            triage3.setTriageQuestionId(CartConstants.TRIAGE_QUES_IND_7);
            triage3.setQuestionText(CartConstants.QUESTION_TEXT_7);

            Triage[] triages = new Triage[4];
            triages[0] = triage0;
            triages[1] = triage1;
            triages[2] = triage2;
            triages[3] = triage3;
            triageInfo.setTriage(triages);
            tradeInItem.setTriageInfo(triageInfo);
            tradeInItemList.add(tradeInItem);
            line.setTradeInItems(tradeInItemList);
        });
    }


}
