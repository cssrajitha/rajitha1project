package onevz.soe.cart.cxp.helper;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import onevz.soe.cart.model.catalog.*;
import org.apache.commons.lang3.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import onevz.soe.cart.cxp.service.CatalogService;
import onevz.soe.cart.model.getSPO.SpoCatalogRequest;
import onevz.soe.cart.requests.GetSpoRequest;
import onevz.soe.cart.responses.CatalogResponse;
import onevz.soe.utilities.CollectionUtilities;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Component
public class CatalogServiceHelper {
	private static final Logger logger = LoggerFactory.getLogger(CatalogServiceHelper.class);

	@Autowired
	private CatalogService catalogService;
	
	@Value("${planSku}")
	private boolean planSku;

	/**
	 *
	 * @param sorIds
	 * @return
	 */
	public Mono<List<CatalogResponse>> getSPOs(Collection<String> sorIds) {
		return Flux.fromIterable(sorIds).flatMap(sorId -> {
			if(planSku) {
				GetSpoRequest getSpoRequest = new GetSpoRequest();
				SpoCatalogRequest spoCatalogRequest = new SpoCatalogRequest();
				List<String> sorIdList = new ArrayList<String>();
				sorIdList.add(sorId);
				spoCatalogRequest.setSpoIds(sorIdList);
				getSpoRequest.setSpoCatalogRequest(spoCatalogRequest);
				
				return catalogService.getSPOFromCatalog(getSpoRequest).doOnError(e -> {
					logger.error(e.getMessage());
				}).doOnSuccess(obj -> {
					formatSpoResponse(obj);
					logger.info(obj.toString());
				}).onErrorReturn(new CatalogResponse());
				
			}
			return catalogService.getSPO(sorId).doOnError(e -> {
				logger.error(e.getMessage());
			}).doOnSuccess(obj -> {
				logger.info(obj.toString());
			}).onErrorReturn(new CatalogResponse());
		}).collectList();
	}
	
	public CatalogResponse formatSpoResponse(CatalogResponse obj) {

		CatalogResponse catalogResponse = new CatalogResponse();

		CatalogData data = new CatalogData();
		CatalogSpoSku spoSku = new CatalogSpoSku();

		if (obj != null && obj.getData() != null
				&& CollectionUtilities.isNotEmptyOrNull(obj.getData().getSpoCatalogItems())
				&& obj.getData().getSpoCatalogItems().size() > 0) {
			List<SpoCatalogItems> spoList = obj.getData().getSpoCatalogItems();

			for (SpoCatalogItems spoDetail : spoList) {
				if (spoDetail.getSpoId() != null)
					spoSku.setSorId(spoDetail.getSpoId());

				if (spoDetail.getLevelCode() != null)
					spoSku.setLevelCode(spoDetail.getLevelCode());

				if (spoDetail.getSkuName() != null)
					spoSku.setSkuName(spoDetail.getSkuName());

				spoSku.setReceiptDispInd(spoDetail.getIsReceiptDisplay() ? 1 : 0);

				spoSku.setIsActive(spoDetail.getIsActive());
				spoSku.setIsShowcase(spoDetail.getIsShowcase());

				if (spoDetail.getMarketingDescription() != null)
					spoSku.setMarketingDescription(spoDetail.getMarketingDescription());

				if (spoDetail.getMobAppLongDesc() != null)
					spoSku.setMobAppLongDesc(spoDetail.getMobAppLongDesc());
				if (spoDetail.getShortDescription() != null)
					spoSku.setShortDescription(spoDetail.getShortDescription());
				if (spoDetail.getSkuDisplayNameB2b() != null)
					spoSku.setSkuDisplayNameB2b(spoDetail.getSkuDisplayNameB2b());
				if (spoDetail.getSkuMobAppShortDesc() != null)
					spoSku.setSkuMobAppShortDesc(spoDetail.getSkuMobAppShortDesc());
				if (spoDetail.getSorTreatmentCode() != null)
					spoSku.setSorTreatmentCode(spoDetail.getSorTreatmentCode());
				if (spoDetail.getDisplayLocation() != null)
					spoSku.setDisplayLocation(spoDetail.getDisplayLocation());
				if (spoDetail.getParentProducts() != null)
					spoSku.setParentProductDetails(spoDetail.getParentProducts());
			}

			data.setSpoSku(spoSku);
			catalogResponse.setData(data);
		}

		return catalogResponse;
	}

	/**
	 * Method to format the catalogRespMono response and return the Mono of List of catalogspo
	 *
	 * @param catalogRespMono
	 * @return
	 */
	public Mono<List<CatalogResponse>> formatSposResponse(Mono<CatalogResponse> catalogRespMono) {
		List<CatalogResponse> catalogResponseList = new ArrayList<>();
		return catalogRespMono.map(catalogResp -> {
			if (catalogResp != null && catalogResp.getData() != null
					&& CollectionUtilities.isNotEmptyOrNull(catalogResp.getData().getSpoCatalogItems())
					&& catalogResp.getData().getSpoCatalogItems().size() > 0) {
				List<SpoCatalogItems> spoList = catalogResp.getData().getSpoCatalogItems();

				for (SpoCatalogItems spoDetail : spoList) {
					CatalogResponse catalogResponse = new CatalogResponse();
					CatalogData data = new CatalogData();
					CatalogSpoSku catalogSpoSku = new CatalogSpoSku();
					if (spoDetail.getSpoId() != null)
						catalogSpoSku.setSorId(spoDetail.getSpoId());
					if (spoDetail.getLevelCode() != null)
						catalogSpoSku.setLevelCode(spoDetail.getLevelCode());
					if (spoDetail.getSkuName() != null)
						catalogSpoSku.setSkuName(spoDetail.getSkuName());

					catalogSpoSku.setReceiptDispInd(spoDetail.getIsReceiptDisplay() ? 1 : 0);
					catalogSpoSku.setIsActive(spoDetail.getIsActive());
					catalogSpoSku.setIsShowcase(spoDetail.getIsShowcase());

					if (spoDetail.getMarketingDescription() != null)
						catalogSpoSku.setMarketingDescription(spoDetail.getMarketingDescription());
					if (spoDetail.getMobAppLongDesc() != null)
						catalogSpoSku.setMobAppLongDesc(spoDetail.getMobAppLongDesc());
					if (spoDetail.getShortDescription() != null)
						catalogSpoSku.setShortDescription(spoDetail.getShortDescription());
					if (spoDetail.getSkuDisplayNameB2b() != null)
						catalogSpoSku.setSkuDisplayNameB2b(spoDetail.getSkuDisplayNameB2b());
					if (spoDetail.getSkuMobAppShortDesc() != null)
						catalogSpoSku.setSkuMobAppShortDesc(spoDetail.getSkuMobAppShortDesc());
					if (spoDetail.getSorTreatmentCode() != null)
						catalogSpoSku.setSorTreatmentCode(spoDetail.getSorTreatmentCode());
					if (spoDetail.getDisplayLocation() != null)
						catalogSpoSku.setDisplayLocation(spoDetail.getDisplayLocation());
					if (spoDetail.getParentProducts() != null)
						catalogSpoSku.setParentProductDetails(spoDetail.getParentProducts());

					data.setSpoSku(catalogSpoSku);
					catalogResponse.setData(data);
					catalogResponseList.add(catalogResponse);
				}
			}
			return catalogResponseList;
		});
	}

	/**
	 * Method to get plan sku map for list of plan ids
	 * 
	 * @param planIds
	 * @return
	 */
	public Mono<Map<String, CatalogResponse>> getPlanSkuMap(Collection<String> planIds) {		
		if(planSku) {
			return Flux.fromIterable(planIds).flatMap(planId -> {
				PlanCatalogRequest request =new PlanCatalogRequest();
				PlanCatalog planCatalogRequest = new PlanCatalog();
				request.setPlanCatalogRequest(planCatalogRequest);
				List<String> planIdList = new ArrayList<>();
				planIdList.add(planId);				
				request.getPlanCatalogRequest().setPlanIds(planIdList);
				return catalogService.getPlanSkuRedesign(request).flatMap(catalogResponse -> {
					CatalogPlanSku planSku = new CatalogPlanSku();
					planSku.setCategoryCode(catalogResponse.getData().getPlanCatalogItems().get(0).getCategoryCode());
					planSku.setCollectionCode(catalogResponse.getData().getPlanCatalogItems().get(0).getCollectionCode());
					CatalogResponse response = new CatalogResponse();
					CatalogData data = new CatalogData();
					if (null != catalogResponse && null != catalogResponse.getData() && CollectionUtilities.isNotEmptyOrNull(catalogResponse.getData().getPlanCatalogItems()))
						data.setPlanCatalogItems(catalogResponse.getData().getPlanCatalogItems());
					response.setData(data);
					response.getData().setPlanSku(planSku);
					return Mono.zip(Mono.just(planId), Mono.just(response));
				});
			}).collectMap(entity -> entity.getT1(), entity -> entity.getT2());
		}
		return Flux.fromIterable(planIds).flatMap(planId -> {
			String plan = planId;
			
			return catalogService.getPlanSku(planId).flatMap(catalogResponse -> {
				return Mono.zip(Mono.just(plan), Mono.just(catalogResponse));
			});
		}).collectMap(entity -> entity.getT1(), entity -> entity.getT2());
	}
	
	public Mono<CatalogResponse> getCatalogDomainData(List<String> planIds,List<String> sorIds, List<String> accessorySorIds, List<String> featureIds, List<String> softSkuSorIds) {
		if(planSku) {
			CatalogDomainRequest catalogDomainRequest = new CatalogDomainRequest ();

			if(CollectionUtilities.isNotEmptyOrNull(planIds)){
					PlanCatalog planCatalogRequest = new PlanCatalog();
					planCatalogRequest.setPlanIds(planIds);
					catalogDomainRequest.setPlanCatalogRequest(planCatalogRequest);
			}
			
			if(CollectionUtilities.isNotEmptyOrNull(sorIds)){
				DeviceCatalogRquest deviceCatalogRequest= new DeviceCatalogRquest ();
				deviceCatalogRequest.setChannelFlow("POSTPAID");
				deviceCatalogRequest.setSorIds(sorIds);
				catalogDomainRequest.setDeviceCatalogRequest(deviceCatalogRequest);
			}
			
			if(CollectionUtilities.isNotEmptyOrNull(accessorySorIds)) {
				AccessoryCatalogRequest accessoryCatalogRequest = new AccessoryCatalogRequest();
				accessoryCatalogRequest.setSorIds(accessorySorIds);
				catalogDomainRequest.setAccessoryCatalogRequest(accessoryCatalogRequest);
			}

			if(CollectionUtilities.isNotEmptyOrNull(featureIds)){
				FeatureCatalogRequest featureCatalogRequest = new FeatureCatalogRequest();
				featureCatalogRequest.setFeatureIds(featureIds);
				catalogDomainRequest.setFeatureCatalogRequest(featureCatalogRequest);
			}
			if(CollectionUtilities.isNotEmptyOrNull(softSkuSorIds)){
				SoftSkuRequest softSkuRequest = new SoftSkuRequest();
				softSkuRequest.setSorIds(softSkuSorIds);
				catalogDomainRequest.setSoftSkuRequest(softSkuRequest);
			}
			long startTimeCXPDomaincatalog =  System.currentTimeMillis();
			if(null !=catalogDomainRequest.getFeatureCatalogRequest() || null !=catalogDomainRequest.getAccessoryCatalogRequest() ||
					null!= catalogDomainRequest.getDeviceCatalogRequest() || null !=catalogDomainRequest.getPlanCatalogRequest() || null != catalogDomainRequest.getSoftSkuRequest()){
				return catalogService.getCatalogRefData(catalogDomainRequest)
						.doOnError(e -> {
							logger.error(e.getMessage());
						}).doOnSuccess(obj -> {
							logger.info("Total time for Domain CatalogRefData api call  {} ", (System.currentTimeMillis() - startTimeCXPDomaincatalog) / 1000);
							logger.debug(obj.toString());
						});
			}
		}
		return Mono.just(new CatalogResponse());
	}
}
