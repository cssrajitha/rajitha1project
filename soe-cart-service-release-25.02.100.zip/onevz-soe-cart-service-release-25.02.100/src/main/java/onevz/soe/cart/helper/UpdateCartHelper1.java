package onevz.soe.cart.helper;

import onevz.soe.cart.bpm.helper.CartServiceBpmHelper3;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.clearAndContinue.ClearAndContinueContext;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.ui.requests.ClearAndContinueUIRequest;
import onevz.soe.cart.ui.requests.DeleteCartUIRequest;
import onevz.soe.cart.ui.responses.DeleteCartUIResponse;
import onevz.soe.omnidl.util.DLUtilityService;
import onevz.soe.utilities.StringUtilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

@Service
public class UpdateCartHelper1 {

    @Autowired
    private RedisHelper redisHelper;

    @Autowired
    private CartServiceBpmHelper3 bpmHelper3;

    @Autowired
    private DLUtilityService dlUtilityService;

    private static final Logger logger = LoggerFactory.getLogger(UpdateCartHelper1.class);



    /**
     *
     * @param deleteCartUIRequest
     * @return response
     *
     */
    public Mono<DeleteCartUIResponse> ngdDeleteCart(DeleteCartUIRequest deleteCartUIRequest) {

        Mono<CartRedisData> rr = redisHelper.getDataFromRedis();
        return rr.flatMap(data -> {
            logger.debug("Redis Data : {}" , data);
            if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber())) {
                deleteCartUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
            }
            if (StringUtilities.isNotEmptyOrNull(data.getCartId())) {
                deleteCartUIRequest.getCartInfo().setCartId(data.getCartId());
            }
            if (StringUtilities.isNotEmptyOrNull(data.getCaseId())) {
                deleteCartUIRequest.getCartInfo().setCaseId(data.getCaseId());
            }
            if (StringUtilities.isNotEmptyOrNull(data.getMtn())) {
                deleteCartUIRequest.getCartInfo().setCartCreator(data.getMtn());
            }
            if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
                    && StringUtilities.isEmptyOrNull(deleteCartUIRequest.getCartInfo().getProcessingMTN())) {
                deleteCartUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
            }
            return bpmHelper3.ngdDeleteCart(deleteCartUIRequest,data.getIsSmartphone());

        });
    }

    public void updateSubflowForByod(ClearAndContinueUIRequest request, ClearAndContinueContext context) {
        String subFlowValue = CartConstants.NXT_GEN_BYOD_BAU;
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIsBYODSession()) &&
            CartConstants.TRUE_FLAG.equals(request.getCartInfo().getIsBYODSession())  &&
            context.getContextInfo()!=null && StringUtilities.isNotEmptyOrNull(context.getContextInfo().getCradleFlowJourney()) &&
            context.getContextInfo().getCradleFlowJourney().contains(CartConstants.NEXTGEN_EC))
            subFlowValue = CartConstants.NXT_GEN_BYOD;
        dlUtilityService.upsertVZPageSubFLow(subFlowValue, true, "").subscribeOn(Schedulers.parallel()).subscribe();
    }
}
