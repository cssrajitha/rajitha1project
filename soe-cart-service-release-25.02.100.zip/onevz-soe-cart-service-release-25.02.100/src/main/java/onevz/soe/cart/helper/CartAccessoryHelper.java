package onevz.soe.cart.helper;

import static com.vzw.cradle.util.CradleConstants.CHANNEL;
import static com.vzw.cradle.util.CradleConstants.FLOW;
import static com.vzw.cradle.util.CradleConstants.PAGE_NAME;
import static onevz.soe.cart.constants.CartConstants.ACC;
import static onevz.soe.cart.constants.CartConstants.MTN;
import static onevz.soe.cart.constants.CartConstants.ROLE;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import onevz.cxp.feature.util.FeatureFlag;
import onevz.soe.cart.constants.FeatureFlagConstants;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpCookie;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.vzw.cradle.vo.CradleResponse;

import onevz.soe.cart.bpm.helper.CartServiceBpmHelper;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper2;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.model.myOffer.Offer;
import onevz.soe.cart.model.retrieveCart.CXPCartVO;
import onevz.soe.cart.requests.ValidateCartCXPRequest;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.MyOfferETRRedisData;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.AddAccessoriesUIRequest;
import onevz.soe.cart.ui.requests.AddDeviceUIRequest;
import onevz.soe.cart.ui.requests.RfexExchangeShopDetails;
import onevz.soe.cart.ui.responses.AddAccessoriesUIResponse;
import onevz.soe.cart.util.CartPegaRequestErrorsUtil;
import onevz.soe.cart.util.CartUtil;
import onevz.soe.cradle.CradleAllocator;
import onevz.soe.omnidl.service.OmniDLService;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

@Service
public class CartAccessoryHelper {

	@Value("${prospect_flows}")
	private List<String> prospectFlows;
	@Value("${caseId_CartId_Intent_Check}")
	private boolean caseIdCartIdIntentCheck;
	@Value("${existing_customer_flows}")
	private List<String> existingCustomerFlows;

	@Value("${enableUidDomainFilter:true}")
	public  boolean enableUidDomainFilter;
	@Value("${uIdEnabledDomains:verizon.com,verizonwireless.com}")
	private  List<String> uIdEnabledDomains;

	@Value("${bpm_sales_order_purchase_case_id_prefix}")
	private List<String> bpmSalesOrderPurchaseCaseIdPrefix;

	@Value("${enableDepletionLocationCodeFromRedis}")
	private boolean enableDepletionLocationCodeFromRedis;

	@Autowired
	CartServiceCxpHelper cxpHelper;

	@Autowired
	private CartServiceBpmHelper bpmHelper;

	@Autowired
	private CartServiceBpmHelper2 bpmHelper2;

	@Autowired
	private ObjectMapper mapper;

	@Autowired
	private RedisHelper redisHelper;

	@Autowired
	private RedisHelper2 redisHelper2;

	@Autowired
	SOELoginSessionBean sessionBean;

	@Autowired
	CradleAllocator cradleAllocator;

	@Autowired
	OmniDLService dlService;
	@Autowired
	FeatureFlag featureFlagUtil;
	@Value("${maxDevicesAllowedPromoHub}")
	private Integer maxDevicesAllowedPromoHub;

	@Autowired
	private FiveGhomeCommonHelper fiveGhomeCommonHelper;

	@Autowired
	private CartRequestBuilder cartRequestBuilder;

	private static Gson gson = new Gson();

	private static final Logger logger = LoggerFactory.getLogger(CartAccessoryHelper.class);

	/**
	 * 
	 * @param request
	 * @return categoryEnabled
	 */
	public boolean isCategoryEnabledForExpressCheckout(AddDeviceUIRequest request) {
		boolean categoryEnabled = false;
		List<String> promoHubEnabledCategory = new ArrayList<>();
		logger.info("promoHubEnabledCategoryNEW" + promoHubEnabledCategory);
		if ((promoHubEnabledCategory != null && request.getData().getLines().get(0) != null
				&& promoHubEnabledCategory.contains(request.getData().getLines().get(0).getDevice().getCategory()))
				|| (null != request.getCartInfo().getReqfrompromopdp() && request.getCartInfo().getReqfrompromopdp())) {
			categoryEnabled = true;
		}
		return categoryEnabled;
	}

	/**
	 *
	 * @param orderFlowType
	 * @param processStep
	 * @param intendType
	 * @return cartOrderFlowType
	 */
	public String calculateCartOrderFlowType(String orderFlowType, String processStep, String intendType) {
		String cartOrderFlowType = "";
		String redisFlowType = "";
		String expressFlow = "";
		String currentVal = "";
		if (CartConstants.NSE_BYOD.equalsIgnoreCase(intendType))
			intendType=CartConstants.NSO;
		else if(CartConstants.BYOD.equalsIgnoreCase(intendType))
			intendType=CartConstants.ESO;
		if (StringUtilities.isNotEmptyOrNull(orderFlowType))
			redisFlowType = orderFlowType;
		if (StringUtilities.isNotEmptyOrNull(processStep) && CartConstants.PROMO_HUB.equalsIgnoreCase(processStep))
			expressFlow = CartConstants.EXPRESS;
		currentVal = expressFlow + intendType.toLowerCase();
		if (StringUtilities.isEmptyOrNull(redisFlowType))
			cartOrderFlowType = currentVal;
		else if (!(redisFlowType.contains(CartConstants.EXPRESS)) && !(currentVal.contains(CartConstants.EXPRESS))) {
			if (!(redisFlowType.contains(currentVal)))
				cartOrderFlowType = redisFlowType + " w/" + currentVal;
			else
				cartOrderFlowType = redisFlowType;
		} else if (!(redisFlowType.contains(CartConstants.EXPRESS)) && (currentVal.contains(CartConstants.EXPRESS))) {
			String tempStr = currentVal.replace(CartConstants.EXPRESS, "");
			if (!(redisFlowType.contains(tempStr)))
				cartOrderFlowType = CartConstants.EXPRESS + redisFlowType + " w/" + tempStr;
			else
				cartOrderFlowType = CartConstants.EXPRESS + redisFlowType;
		} else if ((redisFlowType.contains(CartConstants.EXPRESS)) && !(currentVal.contains(CartConstants.EXPRESS))) {
			String tempStr = redisFlowType.replace(CartConstants.EXPRESS, "");
			if (redisFlowType.contains(currentVal))
				cartOrderFlowType = tempStr.contains(CartConstants.NSE.toLowerCase()) ? redisFlowType : tempStr;
			else
				cartOrderFlowType = tempStr.contains(CartConstants.NSE.toLowerCase()) ? redisFlowType : tempStr + " w/" + currentVal;
		} else if ((redisFlowType.contains(CartConstants.EXPRESS)) && (currentVal.contains(CartConstants.EXPRESS))) {
			String tempStr = currentVal.replace(CartConstants.EXPRESS, "");
			if (!(redisFlowType.contains(tempStr)))
				cartOrderFlowType = redisFlowType + " w/" + tempStr;
			else
				cartOrderFlowType = redisFlowType;
		}
		return cartOrderFlowType;
	}

	/**
	 * 
	 * @param cartOrderFlowType
	 * @return flowType
	 */
	public String getFlowTypeValue(String cartOrderFlowType) {
		String flowType = "";
		if (StringUtilities.isNotEmptyOrNull(cartOrderFlowType)) {
			String[] flowTypeArr = cartOrderFlowType.split(" w/");
			flowType = flowTypeArr[0];
		}
		return flowType;
	}

	/**
	 * @param request
	 * @return AddAccessoriesUIResponse
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Mono<AddAccessoriesUIResponse> addAccessory(AddAccessoriesUIRequest request) {
		String channelType = CartUtil.getChannelType(request.getChannelId());
		Mono<CartRedisData> rr = redisHelper.getDataFromRedis();
		Mono<MyOfferETRRedisData> moEtrData = redisHelper.getMyOfferETRDataFromRedis();
		Mono<String> oneClickCheckoutFlag = redisHelper.getOneClickCheckoutFlag();
		Mono<String> roleData = redisHelper2.getRole();
		Mono<Boolean> isCartOperationWithUUIDEnabledMono = featureFlagUtil.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART,FeatureFlagConstants.FLAG_NAME_CART_OPERATION_WITH_UUID,true);


		return Mono.zip(rr,isCartOperationWithUUIDEnabledMono).flatMap(tuple2 -> {
			CartRedisData data = tuple2.getT1();
			boolean isCartOperationWithUUIDEnabled = tuple2.getT2();

			if (request.getCartInfo().isFlexV2()&& StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType())) {
				cartRequestBuilder.buildAddAccessoryRequest(request, data);
			}
			if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED)) {
				if (request.getCartInfo().getIntendType().toUpperCase().contains("NSE")
						&& StringUtilities.isNotEmptyOrNull(data.getCreditAppNum())) {
					request.getCartInfo().setCreditAppNum(data.getCreditAppNum());
					request.getCartInfo().setCartCreator(data.getCreditAppNum());
				}
			}
			if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))
					&& StringUtilities.isNotEmptyOrNull(data.getCaseId()) && StringUtilities.isNotEmptyOrNull(data.getCartId())) {
				String caseId = data.getCaseId() != null ? data.getCaseId() : "";
				boolean caseIdMatched = bpmSalesOrderPurchaseCaseIdPrefix.stream().anyMatch(domain -> caseId.toUpperCase().contains(domain));
				if (!caseIdMatched || "WHW_Redemption".equalsIgnoreCase(request.getCartInfo().getFlowType())){
					data.setCaseId(StringUtils.EMPTY);
					data.setCartId(StringUtils.EMPTY);
				}
			}
			if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))
					&& CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
				if(StringUtilities.isNotEmptyOrNull(data.getMtnFlow())) {
					request.getCartInfo().setMtnFlow(data.getMtnFlow());
				}
			}

			// below condition is introduced to check prospect case Id or cart Id exists already in the session, if it exists then case Id & cart Id
			// are not carry forward to PEGA request.
			boolean prospectCaseIdCartIdExists = caseIdCartIdIntentCheck ?
					CartUtil.hasProspectCustomerChangedLoggedIn(data,request.getChannelId(),request.getCartInfo().getIntendType(),prospectFlows,existingCustomerFlows) : false;
			logger.info("prospectCaseIdCartIdExists {} ",prospectCaseIdCartIdExists);
			boolean refundAndExchangeCaseorCartIdExists = CartUtil.hasCustomerSwitchedfromREXToPurchase(data, request.getChannelId(), request.getCartInfo().getIntendType(), existingCustomerFlows);
			logger.info("refundAndExchangeCaseorCartIdExists {} ",refundAndExchangeCaseorCartIdExists);

			// Setting exchange shop details required for RFEX
			if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))
					&& CartConstants.REX.equalsIgnoreCase(request.getCartInfo().getIntendType())
				    && StringUtilities.isNotEmptyOrNull(data.getRfexExchangeShopDetails())) {
					RfexExchangeShopDetails rfexExchangeShopDetails = gson.fromJson(data.getRfexExchangeShopDetails(), RfexExchangeShopDetails.class);
					logger.info("Shop Details available from cache {}", rfexExchangeShopDetails);
					request.setRfexExchangeShopDetails(rfexExchangeShopDetails);
			}

			if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))
					&& StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType())
					&& StringUtilities.isNotEmptyOrNull(data.getIntendType()))
				request.getCartInfo().setIntendType(data.getIntendType());
			if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()) && !request.getCartInfo().getIntendType().toUpperCase().contains("NSE")
					&& StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				request.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getVzwRoles())) {
				request.getCartInfo().setAmRole(data.getVzwRoles());
			}
			if(StringUtilities.isNotEmptyOrNull(data.getFlowName())){
				request.setFlowName(data.getFlowName());
			}
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()) && !prospectCaseIdCartIdExists)
				request.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()) && !prospectCaseIdCartIdExists)
				request.getCartInfo().setCaseId(data.getCaseId());
			if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()) && !request.getCartInfo().getIntendType().toUpperCase().contains("NSE")
					&& StringUtilities.isNotEmptyOrNull(data.getMtn()))
				request.getCartInfo().setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessingMTN()))
				request.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()) && !request.getCartInfo().getIntendType().toUpperCase().contains("NSE")
					&& StringUtilities.isNotEmptyOrNull(data.getCartCreator())) {
				request.getCartInfo().setCartCreator(data.getCartCreator());
				if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
						&& ACC.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
					Lines[] lines = Optional.ofNullable(request.getData().getLines()).orElse(new Lines[1]);
					for (Lines line : lines) {
						if (StringUtilities.isEmptyOrNull(line.getMtn()))
							line.setMtn(data.getCartCreator());

						if(isScanAndGoAccessoriesEnabled(request)){
							if (null != line.getRemoveAccessories()
									&& null == line.getDepletionLocationCode()
									&& null != data.getRetailScanAndGoDepletionLocationCode()) {
								line.setDepletionLocationCode(data.getRetailScanAndGoDepletionLocationCode());
							}
							else if (null != line.getAddAccessories()
									&& null != line.getDepletionLocationCode()){
								redisHelper2.upsertValueInRedis(CartConstants.RETAIL_SCAN_AND_GO_DEPLETION_LOCATION_CODE, line.getDepletionLocationCode())
										.subscribeOn(Schedulers.parallel())
										.subscribe(upserted -> {
											logger.info("Depletion location code upserted in Redis {}", upserted);
										});
							}
						}
						}
					}
				}

			// PRODDEF-16899
			if(refundAndExchangeCaseorCartIdExists){
				request.getCartInfo().setCartId(null);
				request.getCartInfo().setCaseId(null);
			}

			if(enableUidDomainFilter) {
				String uId = data.getUId() != null ? data.getUId() : "";
				boolean uIdMatched = uIdEnabledDomains.stream().anyMatch(domain -> uId.contains(domain));
				logger.info("UID :: {} :: uIdMatched :: {}", uId, uIdMatched);
				if (uIdMatched) {
					if (StringUtilities.isNotEmptyOrNull(data.getUniversalId()))
						request.setUniversalId(data.getUniversalId());
				}
			}else {
				if (StringUtilities.isNotEmptyOrNull(data.getUniversalId()))
					request.setUniversalId(data.getUniversalId());
			}

			//Setting the appUniversalId for MVA Prospect flow
			if(isCartOperationWithUUIDEnabled
					&& CartConstants.NSEACC.equals(request.getCartInfo().getIntendType())
					&& request.getChannelId().contains(CartConstants.VZW_MFA)
					&& request.getHttpRequest() != null
					&& !request.getHttpRequest().getCookies().isEmpty()
					&& request.getHttpRequest().getCookies().getFirst(CartConstants.UUID) != null){
						HttpCookie uuidCookie = request.getHttpRequest().getCookies().getFirst(CartConstants.UUID);
						if(uuidCookie != null && StringUtilities.isNotEmptyOrNull(uuidCookie.getValue())) {
							request.setAppUniversalId(uuidCookie.getValue());
						}
			}


			if (CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))
					&& (StringUtilities.isEmptyOrNull(request.getCartInfo().getCaseId())
							|| StringUtilities.isEmptyOrNull(request.getCartInfo().getCartId()))) {
				AddAccessoriesUIResponse errorResponse = new AddAccessoriesUIResponse();
				errorResponse.setErrors(CartPegaRequestErrorsUtil.validateCartIdAndCaseId(request.getCartInfo()));
				return Mono.just(errorResponse);
			}

			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN()) && null != request.getCartInfo()
					&& StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
					&& !ACC.equalsIgnoreCase(request.getCartInfo().getIntendType()) && null != request.getData()
					&& null != request.getData().getLines()
					&& StringUtilities.isEmptyOrNull(request.getData().getLines()[0].getMtn()))
				request.getData().getLines()[0].setMtn(data.getProcessingMTN());
			String cartIdFinal = request.getCartInfo().getCartId();
			return oneClickCheckoutFlag.defaultIfEmpty(CartConstants.FALSE)
					.flatMap(oneClickCheckout -> cxpHelper.getAccessoryCartMap(cartIdFinal)
							.defaultIfEmpty(new HashMap()).flatMap(cartmap -> roleData.flatMap(role -> {
								int accessoryListCount = 0;
								int deviceListCount = 0;
								String intendType = "";
								String intent = "";
								String mtnToCradle=null!=data.getCartCreator()?data.getCartCreator():null!=data.getProcessingMTN()?data.getProcessingMTN():"";
								if (null != cartmap) {
									Map<String, String> cartMapObj = (HashMap<String, String>) cartmap;
									accessoryListCount = (StringUtilities
											.isNotEmptyOrNull(cartMapObj.get("accessoryCount")))
													? Integer.valueOf(cartMapObj.get("accessoryCount"))
													: 0;
									deviceListCount = (StringUtilities.isNotEmptyOrNull(cartMapObj.get("deviceCount")))
											? Integer.valueOf(cartMapObj.get("deviceCount"))
											: 0;

								}
								intendType = request.getCartInfo().getIntendType();
								intent = request.getCartInfo().getIntent();
								Mono<String> throttleNameMono = Mono.just("");
								Mono<CradleResponse> cradleResponse = Mono.empty();
								try {
									if(!(CartUtil.isDigital(request.getChannelId())&& fiveGhomeCommonHelper.isFWAFlow(request.getCartInfo().getIntendType()))) {
										if (StringUtilities.isNotEmptyOrNull(oneClickCheckout)
												&& Boolean.valueOf(oneClickCheckout)
												&& request.getCartInfo().getEditAccessory() != null
												&& request.getCartInfo().getEditAccessory()
												&& request.getCartInfo().getExpressflowForAcc() != null
												&& request.getCartInfo().getExpressflowForAcc()
												&& StringUtilities.isNotEmptyOrNull(intent)
												&& intent.equalsIgnoreCase(CartConstants.STANDALONEACCESSORY)) {
											throttleNameMono = Mono.just(CartConstants.ONE_CLICK_CHECKOUT_FOR_ACCESSORY);
											logger.info("Accessory Edit case Scenario:{}", CartConstants.ONE_CLICK_CHECKOUT_FOR_ACCESSORY);
										} else if (StringUtilities.isNotEmptyOrNull(oneClickCheckout)
												&& Boolean.valueOf(oneClickCheckout) && null != request.getCartInfo()
												&& StringUtilities
												.isNotEmptyOrNull(request.getCartInfo().getProcessAction())
												&& ("addAccessoryRecommendations"
												.equalsIgnoreCase(request.getCartInfo().getProcessAction())
												&& CartConstants.PROMO_HUB.equalsIgnoreCase(
												request.getCartInfo().getProcessStep()))) {

											throttleNameMono = Mono.just(CartConstants.ONE_CLICK_CHECKOUT_FOR_ACCESSORY);
											logger.info("Add Accessory Scenario from ExpressCheckout Recommendations:{}", CartConstants.ONE_CLICK_CHECKOUT_FOR_ACCESSORY);
										} else if (StringUtilities.isNotEmptyOrNull(oneClickCheckout)
												&& Boolean.valueOf(oneClickCheckout) && deviceListCount >= 1
												&& null != request.getCartInfo()
												&& StringUtilities
												.isNotEmptyOrNull(request.getCartInfo().getProcessAction())
												&& (CartConstants.ADD_ACCESSORY
												.equalsIgnoreCase(request.getCartInfo().getProcessAction())
												|| CartConstants.ADD_ACCESSORY_AND_CHECKOUT.equalsIgnoreCase(
												request.getCartInfo().getProcessAction()))) {
											request.getCartInfo()
													.setProcessAction(CartConstants.ADD_ACCESSORY_AND_CHECKOUT);
											logger.info("Add Accessory Scenario calling Cradle when devices present ");
											cradleResponse = invokeCradleForAccessoryPromoHub(request, intendType, role,
													accessoryListCount, mtnToCradle, false);
										} else if (StringUtilities.isNotEmptyOrNull(intendType)
												&& null != request.getCartInfo().getExpressflowForAcc()
												&& StringUtilities.isNotEmptyOrNull(intent)
												&& intent.equalsIgnoreCase(CartConstants.STANDALONEACCESSORY)) {
											logger.info("Add Accessory Scenario calling Cradle for rest of scenarios ");
											cradleResponse = invokeCradleForAccessoryPromoHub(request, intendType, role,
													accessoryListCount, mtnToCradle, true);
										}
									}
								} catch (Exception e) {
									logger.error(CartConstants.JSON_PRCSSNG_EXCPTN_STRNG + e);
								}

								Mono<CradleResponse> cradleResponseFinal = (null != cradleResponse) ? cradleResponse
										: Mono.empty();
								Mono<String> throttleNameMonoFinal = (null != throttleNameMono) ? throttleNameMono
										: Mono.empty();
								return moEtrData.flatMap(myOfferEtrData -> {
									if (CollectionUtilities.isNotEmptyOrNull(myOfferEtrData.getLines())) {
										myOfferEtrData.getLines().stream().filter(Objects::nonNull).forEach(line -> {
											Lines[] requestLines = Optional.ofNullable(request.getData().getLines())
													.orElse(new Lines[1]);

											Boolean aal = false;
											if (null != request.getCartInfo()
													&& StringUtilities
															.isNotEmptyOrNull(request.getCartInfo().getIntendType())
													&& CartConstants.AAL
															.equalsIgnoreCase(request.getCartInfo().getIntendType())
													&& null != line.getOffers()) {
												for (Offer offer : line.getOffers()) {
													if (StringUtilities.isNotEmptyOrNull(offer.getAal())
															&& "Y".equalsIgnoreCase(offer.getAal())) {
														aal = true;
													}
												}
											}
											for (Lines requestLine : requestLines) {
												if (aal || StringUtilities.isNotEmptyOrNull(requestLine.getMtn())) {
													String restrictedProductType = StringUtilities.isNotEmptyOrNull(requestLine.getRestrictedProductType()) ? requestLine.getRestrictedProductType() : "";
													if (CollectionUtilities.isNotEmptyOrNull(line.getOffers())) {
														line.getOffers().stream().filter(Objects::nonNull)
																.forEach(offer -> {
																	if (StringUtilities
																			.isNotEmptyOrNull(offer.getComplianceType())
																			&& ACC.equalsIgnoreCase(
																					offer.getComplianceType())) {
																		requestLine.setRestricted("Y");
																		// append logic will go here
																		if (StringUtilities
																				.isNotEmptyOrNull(restrictedProductType)
																				&& !restrictedProductType.contains(
																						offer.getComplianceType()))
																			requestLine.setRestrictedProductType(
																					restrictedProductType + "|" + offer
																							.getComplianceType());
																		else if (StringUtilities.isNotEmptyOrNull(
																				restrictedProductType))
																			requestLine.setRestrictedProductType(
																					restrictedProductType);
																		else
																			requestLine.setRestrictedProductType(
																					offer.getComplianceType());
																	} else if (StringUtilities
																			.isNotEmptyOrNull(offer.getRewardType())
																			&& CartConstants.ACCESSORY.equalsIgnoreCase(
																					offer.getRewardType())) {
																		requestLine.setBarCodeId(offer.getBarcodeId());
																	}

																});
													}
												}
											}
										});
									}
									return cradleResponseFinal.defaultIfEmpty(new CradleResponse()).flatMap(crdResp -> {
										return throttleNameMonoFinal.defaultIfEmpty("").flatMap(throttleName -> {
											logger.info("CradleResponse : {}", crdResp.toString());
											JsonNode cradleOutputJsonNode = null;
											if (null != crdResp) {
												try {
													if (null != crdResp.getOutPut())
														cradleOutputJsonNode = mapper.readTree(crdResp.getOutPut());

													if (null != cradleOutputJsonNode && null != cradleOutputJsonNode
															.get(CartConstants.CRADLE_FLOW_JOURNEY)) {
														String cradleFlowJourney = cradleOutputJsonNode
																.get(CartConstants.CRADLE_FLOW_JOURNEY).asText();
														throttleName = "";
														if (cradleFlowJourney
																.equalsIgnoreCase("OneClickCheckoutForAccessory")) {

															throttleName = CartConstants.ONE_CLICK_CHECKOUT_FOR_ACCESSORY;
														} else if (StringUtilities
																.isNotEmptyOrNull(cradleFlowJourney)) {
															throttleName = cradleFlowJourney;
														}
													}
													logger.info("Throttle Name: {}", throttleName);
												} catch (JsonProcessingException e) {
													logger.error(
															"Exception occurred while processing json response from cradle : {}",
															e.getMessage());
												}
											} 

											Mono<AddAccessoriesUIResponse> val = bpmHelper2.addAccessory(request,
													throttleName);
											return val.flatMap(addAccessoriesUIResponse -> {
												String processStep = "";
												String cartOrderFlowType = "";
												if (CartConstants.STANDALONEACCESSORY
														.equalsIgnoreCase(request.getCartInfo().getIntent())) {
													if (null != addAccessoriesUIResponse.getServiceBody()
															&& null != addAccessoriesUIResponse.getServiceBody().getServiceResponse()
															&& null != addAccessoriesUIResponse.getServiceBody().getServiceResponse()
																	.getContext()
															&& null != addAccessoriesUIResponse.getServiceBody().getServiceResponse()
																	.getContext().getContextInfo())
														processStep = addAccessoriesUIResponse.getServiceBody().getServiceResponse()
																.getContext().getContextInfo().getProcessStep();
													cartOrderFlowType = calculateCartOrderFlowType(
															data.getCartOrderFlowType(), processStep,
															CartConstants.NAO);
													logger.info("Redis CartOrderFlowType in accessory: {}", data.getCartOrderFlowType());
													logger.info("CartOrderFlowType in accessory: {}", cartOrderFlowType);
												}
												Mono<Boolean> orderTypeRedisData = redisHelper2
														.updateCartOrderFlowType(cartOrderFlowType);
												return orderTypeRedisData.flatMap(orderTypeData -> {

													if (addAccessoriesUIResponse.getErrors() == null && CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))
															&& (null == request.getCartInfo()
															|| (request.getData() != null && request.getData().getValidateCart()!=null && request.getData().getValidateCart())
															|| !(CartConstants.PROMO_HUB.equalsIgnoreCase(request.getCartInfo().getProcessStep())
															|| CartConstants.ACCESSORIES_INTERSTIAL.equalsIgnoreCase(request.getCartInfo().getProcessStep())))) {

														ValidateCartCXPRequest validateRequest = new ValidateCartCXPRequest();
														validateRequest.setCartId(request.getCartInfo().getCartId());
														validateRequest.setPageId(CartConstants.PROMO_HUB);
														validateRequest.setRetrieveCurrentFeatures(Boolean.FALSE);
														if (request.getCartInfo().getIntendType().contains("NSE")) {
															Map<String, String> meta = new HashMap<>();
															meta.put("type", CartConstants.NEWCUSTOMER);
															validateRequest.setMeta(meta);
														}
														if (((null != request.getCartInfo()
																&& StringUtilities.isNotEmptyOrNull(
																		request.getCartInfo().getCartCreator()))
																|| StringUtilities.isNotEmptyOrNull(data.getMtn()))
																&& StringUtilities.isNotEmptyOrNull(data.getVzwRoles())
																&& (data.getVzwRoles()
																		.equalsIgnoreCase(CartConstants.MOBILE_SECURE)
																		|| data.getVzwRoles().equalsIgnoreCase(
																				CartConstants.ACCOUNT_MEMBER))) {
															String mtn = null == request.getCartInfo() ? ""
																	: StringUtilities.isNotEmptyOrNull(
																			request.getCartInfo().getCartCreator())
																					? request.getCartInfo()
																							.getCartCreator()
																					: StringUtilities.isNotEmptyOrNull(
																							data.getMtn())
																									? data.getMtn()
																									: "";

															List<String> mtnList = new ArrayList<>();
															mtnList.add(mtn);
															validateRequest.setMtnList(mtnList);
														}
														return redisHelper.isDigitalHomeFlow().flatMap(isFiveGFlow -> {
															if (!isFiveGFlow && StringUtilities
																	.isNotEmptyOrNull(validateRequest.getCartId()) && !request.isSkipSVC()) {
																return cxpHelper.validateCart(validateRequest,null)
																		.flatMap(validateCartResponse -> {
																			if (validateCartResponse != null) {
																				if (validateCartResponse
																						.getErrors() != null)
																					addAccessoriesUIResponse.setErrors(validateCartResponse
																							.getErrors());
																				else {
																					if (null != validateCartResponse
																							.getData()
																							&& null != validateCartResponse
																							.getData()
																							.getValidateCartAndUpdate()) {
																						CXPCartVO cart = validateCartResponse
																								.getData()
																								.getValidateCartAndUpdate();
																						cart = CartUtil
																								.calculateMemberCount(cart,
																										validateRequest
																												.getMtnList(),
																										data.getVzwRoles());
																						validateCartResponse.getData()
																								.setValidateCartAndUpdate(
																										cart);
																					}
																					addAccessoriesUIResponse.setValidateCartResponse(
																							validateCartResponse);
																				}
																			}

																			return Mono.just(addAccessoriesUIResponse);
																		});
															}
															return Mono.just(addAccessoriesUIResponse);
														});

													}
													return Mono.just(addAccessoriesUIResponse);
												});
											});
										});
									});
								});
							})));
		});
	}


	private Mono<CradleResponse> invokeCradleForAccessoryPromoHub(AddAccessoriesUIRequest request, String intendType,
																  String role, Integer accessoryListCount, String mtnToCradle, Boolean isStandAloneAccessories) {
		ServerHttpRequest httpRequest = null;
		ServerHttpResponse httpResponse = null;
		Map<String, String> dataMap = new HashMap<>();
		try {
			dataMap.put(FLOW, intendType);
			dataMap.put(MTN, mtnToCradle);

			if (null != request.getData() && null != request.getData().getLines()
					&& null != request.getData().getLines()[0].getAddAccessories()
					&& null != request.getData().getLines()[0].getAddAccessories()[0].getId())
				dataMap.put(CartConstants.ACCESSORY_SOR_ID,
						request.getData().getLines()[0].getAddAccessories()[0].getId());

			if (null != request.getData() && null != request.getData().getLines()
					&& null != request.getData().getLines()[0].getAddAccessories()
					&& null != request.getData().getLines()[0].getAddAccessories()[0].getCategory())
				dataMap.put(CartConstants.ACCESSORY_CATEGORY_NAME,
						request.getData().getLines()[0].getAddAccessories()[0].getCategory());

			if (null != request.getData() && null != request.getData().getLines()
					&& null != request.getData().getLines()[0].getAddAccessories()
					&& null != request.getData().getLines()[0].getAddAccessories()[0].getProductId())
				dataMap.put(CartConstants.ACCESSORY_PRODUCT_ID,
						request.getData().getLines()[0].getAddAccessories()[0].getProductId());

			if (null != request.getCartInfo() && null != request.getCartInfo().getExpressflowForAcc()
					&& request.getCartInfo().getExpressflowForAcc())
				dataMap.put(CartConstants.EXPRESS_FLOW_FOR_ACCESSORY, "true");
			else
				dataMap.put(CartConstants.EXPRESS_FLOW_FOR_ACCESSORY, CartConstants.FALSE);

			if(isStandAloneAccessories) {
				dataMap.put(CartConstants.EXPRESS_FLOW_FOR_ACCESSORY, "true");
			}
			dataMap.put(CartConstants.ACCESSORY_COUNT_LIST, accessoryListCount.toString());

			if (StringUtilities.isNotEmptyOrNull(role))
				dataMap.put(ROLE, role);

			dataMap.put(CHANNEL, "NSA");
			dataMap.put(PAGE_NAME, "addAccessory");

			httpRequest = request.getHttpRequest();
			httpResponse = request.getHttpResponse();
			Mono<CradleResponse> crd = cradleAllocator.invokeReactiveCradle(httpRequest, httpResponse, dataMap);
			return crd.flatMap(t -> {
				logger.info("Cradle response after allocator call {}", crd);
				return Mono.just(t);
			});
		} catch (Exception e) {
			logger.info("Exception in invoking Cradle for addAccessory");
			return Mono.empty();
		}
	}

	public boolean isScanAndGoAccessoriesEnabled(AddAccessoriesUIRequest uiRequest){
		return enableDepletionLocationCodeFromRedis
				&& null != uiRequest
				&& null != uiRequest.getCartInfo()
				&& StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getFlowType())
				&& CartConstants.SCAN_AND_GO.equalsIgnoreCase(uiRequest.getCartInfo().getFlowType());
	}

	public boolean isPegaResponseValid(AddAccessoriesUIResponse pegaResponse){
		return pegaResponse != null && pegaResponse.getServiceBody() != null
				&& pegaResponse.getServiceBody().getServiceResponse() != null
				&& pegaResponse.getServiceBody().getServiceResponse().getContext() != null
				&& pegaResponse.getServiceBody().getServiceResponse().getContext().getContextInfo() != null;
	}
}
