package onevz.soe.cart.helper;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import onevz.soe.cart.bpm.helper.RemoveHomePhoneServiceBpmHelper;
import onevz.soe.cart.model.common.FieldValidationException;
import onevz.soe.cart.responses.RemoveHomePhonePegaResponse;
import onevz.soe.cart.ui.requests.RemoveHomePhoneUIRequest;
import onevz.soe.utilities.StringUtilities;
import reactor.core.publisher.Mono;


@Service
public class RemoveHomePhoneHelper {

    private static final Logger logger = LoggerFactory.getLogger(RemoveHomePhoneHelper.class);

    @Autowired
    RemoveHomePhoneServiceBpmHelper removeHomePhoneServiceBpmHelper;

    /**
     * 
     * @param removeHomePhoneUIRequest
     * @return removeHomePhonePegaResponse
     * @throws IOException
     */
    public Mono<RemoveHomePhonePegaResponse> removeHomePhone(RemoveHomePhoneUIRequest removeHomePhoneUIRequest)throws IOException {

        logger.info("Calling removeHomePhone() for RemoveHomePhoneServiceBpmHelper");
        return removeHomePhoneServiceBpmHelper.removeHomePhone(removeHomePhoneUIRequest);
    }

    public FieldValidationException validateUiRequest(RemoveHomePhoneUIRequest request) {
        String errorMessage = getErrorMessage(request);
        if (!errorMessage.isEmpty()) {
            FieldValidationException error = new FieldValidationException();
            error.setNameSpace("CartService");
            error.setCode("400");
            error.setName("Request Validation Error");
            error.setMessage(errorMessage);
            return error;
        }
        return null;
    }

    private String getErrorMessage(RemoveHomePhoneUIRequest request) {
        if (StringUtilities.isEmptyOrNull(request.getCartInfo().getClientAppName())) {
            return "ClientAppName is empty nor null";
        }
        if (StringUtilities.isEmptyOrNull(request.getCartInfo().getHomePhoneMTN())) {
            return "HomePhoneMTN is empty nor null";
        }
        if (StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType())) {
            return "IntendType is empty nor null";
        }
        if (StringUtilities.isEmptyOrNull(request.getCartInfo().getAction())) {
            return "Action is empty nor null";
        }
        return "";
    }
}
