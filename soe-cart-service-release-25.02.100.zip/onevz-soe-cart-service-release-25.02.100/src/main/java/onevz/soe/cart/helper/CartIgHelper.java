package onevz.soe.cart.helper;

import java.util.Base64;

import onevz.soe.cart.util.CartCxpResponseUtil1;
import org.slf4j.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import onevz.soe.cart.requests.ValidateSecureTokenRequest;
import onevz.soe.cart.responses.ValidateSecureTokenResponse;
import onevz.soe.cart.ui.requests.DeviceSimValidationUIRequest;
import onevz.soe.cart.util.CartCxpResponseUtil;
import onevz.soe.utilities.StringUtilities;

@Service
public class CartIgHelper {
	
	@Autowired
	private Environment environment;
	
	
	private static final Logger logger = LoggerFactory.getLogger(CartIgHelper.class);
	
	public DeviceSimValidationUIRequest validateSecureToken(ValidateSecureTokenRequest validateSecureTokenRequest) {
		
		 // request url
	    String url = environment.getProperty("IG.PROSPECT.JWT.validateSecureToken.URL");

	    // create auth credentials
	    String authStr = environment.getProperty("IG.prospect.validateSecureTokenUsername")+":"+environment.getProperty("IG.prospect.validateSecureTokenPassword");
	    String base64Creds = Base64.getEncoder().encodeToString(authStr.getBytes());

	    // create headers
	    HttpHeaders headers = new HttpHeaders();
	    headers.add("Authorization", "Basic " + base64Creds);
	    headers.setContentType(MediaType.APPLICATION_JSON);

	    logger.debug("ValidateSecureTokenRequest Request: {}", validateSecureTokenRequest);
	    // create request
	    HttpEntity<ValidateSecureTokenRequest> request = new HttpEntity<ValidateSecureTokenRequest>(validateSecureTokenRequest,headers);

	    // IG Call to ValidateSecureToken service
	    ResponseEntity<ValidateSecureTokenResponse> response = new RestTemplate().exchange(url, HttpMethod.POST, request, ValidateSecureTokenResponse.class);

	    // get JSON response
	    ValidateSecureTokenResponse validateSecureTokenResponse = response.getBody();
	    DeviceSimValidationUIRequest deviceSimValidationUIRequest = new DeviceSimValidationUIRequest();
	    CartCxpResponseUtil1.formatValidateSecureTokenResponse(validateSecureTokenResponse, deviceSimValidationUIRequest);
	    if(StringUtilities.isNotEmptyOrNull(validateSecureTokenRequest.getToken())) {
			deviceSimValidationUIRequest.setToken(validateSecureTokenRequest.getToken());
		}
		return deviceSimValidationUIRequest;
				
	}

}
