package onevz.soe.cart.omnidl;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.common.CartServiceCustomerInfo;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.ui.requests.AddDeviceUIRequest;
import onevz.soe.cart.ui.responses.AddDeviceUIResponse;
import onevz.soe.cart.ui.responses.AddPlanUIResponse;

public class OmniBuilder {

	public static OmniDLBuilder fromCart(RetrieveCartCXPResponse retrieveCartResponse,
										 ValidateCartCXPResponse validateCartResponse, String methodType, String promosAppliedVal,
										 BundleBuilderCXPResponseData bundleBuilderCXPResponse, CartRedisData data) {
		OmniDLBuilder builder = new OmniDLBuilder();
		// Make sure to actually build the data
		if("promosApplied".equalsIgnoreCase(methodType))
			builder.buildPromoCartObject(retrieveCartResponse, validateCartResponse, methodType, promosAppliedVal);
//		as per PRODDEF-23628, user.numberOfLines is mtn count of user, not cart item
//		else if(CartConstants.NUMBER_OF_LINES.equalsIgnoreCase(methodType))
//			builder.buildUserCartCount(retrieveCartResponse, validateCartResponse, methodType, promosAppliedVal);
		else if(CartConstants.CREATE_LINE.equalsIgnoreCase(methodType))
			builder.buildPlansFirstPageData(promosAppliedVal);
		else if(CartConstants.PROMO_BUNDLE_BUILDER.equalsIgnoreCase(methodType))
			builder.buildCartObject(retrieveCartResponse, validateCartResponse, methodType, "",bundleBuilderCXPResponse,data);
		else
			builder.buildCartObject(retrieveCartResponse, validateCartResponse, methodType, "",null,data);
		return builder;
	}

	public static OmniDLBuilder fromCart5g(RetrieveCartCXPResponse retrieveCartResponse,
										 ValidateCartCXPResponse validateCartResponse, String methodType,String promosAppliedVal, CartRedisData data) {
		OmniDLBuilder builder = new OmniDLBuilder();
		// Make sure to actually build the data
		if("promosApplied".equalsIgnoreCase(methodType))
			builder.buildPromoCartObject(retrieveCartResponse, validateCartResponse, methodType, promosAppliedVal);
		else
			builder.buildCartObject(retrieveCartResponse, validateCartResponse, methodType, "fiveG",null,data);
		return builder;
	}

    public static OmniDLBuilder fromNewCustomer(String sessionID, String globalId, CartServiceCustomerInfo customerInfo){
        OmniDLBuilder builder = new OmniDLBuilder();
        builder.buildNewCustVzDl(sessionID, globalId, customerInfo);
        return builder;
    }

	public static OmniDLBuilder buildBBPData(AddDeviceUIResponse response) {
		OmniDLBuilder builder = new OmniDLBuilder();
		builder.buildOmnidlForBBP(response);
		return builder;
	}

	public static OmniDLBuilder buildAddStepUserData() {
		OmniDLBuilder builder = new OmniDLBuilder();
		builder.buildOmnidlForAddStepUserData();
		return builder;
	}

	public static OmniDLBuilder buildBBPAddPlanData(AddPlanUIResponse addPlanUIResponse) {
		OmniDLBuilder builder = new OmniDLBuilder();
		builder.buildOmnidlForBBPAddPlan(addPlanUIResponse);
		return builder;
	}

	public static OmniDLBuilder buildAddDeviceDataForQuickShopFlow(AddDeviceUIResponse addDeviceUIResponse) {
		OmniDLBuilder builder = new OmniDLBuilder();
		builder.buildQuickShopData(addDeviceUIResponse);
		return builder;
	}

	public static OmniDLBuilder fromOrderConfirm5g(OrderConfirmationCXPResponse orderConfirmationResponse,
												   ValidateCartCXPResponse validateCartResponse, String methodType, String promosAppliedVal) {
		OmniDLBuilder builder = new OmniDLBuilder();
		// Make sure to actually build the data
		builder.buildOrderConfirm5GObject(orderConfirmationResponse, validateCartResponse, methodType, "fiveG");
		return builder;
	}

	/**
	 * Taking the addDeviceUIRequest and exisistingSubflow as parameters and updating the data to Vzdl
	 * @param addDeviceUIRequest
	 * @param existingSubFlow
	 * @return
	 */
	public static OmniDLBuilder updateSubFlowNameInVzdl(AddDeviceUIRequest addDeviceUIRequest,String existingSubFlow){
		OmniDLBuilder builder = new OmniDLBuilder();
		builder.updateSubFlowNameInVzdl(addDeviceUIRequest,existingSubFlow);
		return builder;
	}

	public static OmniDLBuilder updateEventData() {
		OmniDLBuilder builder = new OmniDLBuilder();
		builder.updateEventDataForVzDL();
		return builder;
	}
}
