package onevz.soe.cart.controller;


import onevz.soe.cart.helper.UpdateCreditAppFraudStatusHelper;
import onevz.soe.cart.ui.requests.UpdateCreditAppFraudStatusRequest;
import onevz.soe.cart.ui.responses.UpdateCreditAppFraudStatusMainResponse;
import onevz.soe.exception.SOEError;
import onevz.soe.utilities.StringUtilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;

@RestController
public class UpdateCreditAppController {
    private static final Logger logger = LoggerFactory.getLogger(UpdateCreditAppController.class);

    @Autowired
    private UpdateCreditAppFraudStatusHelper updateCreditAppFraudStatusHelper;

    @PostMapping(value = {"/update-creditapp-fraud-status", "/nse/update-creditapp-fraud-status"} , consumes = MediaType.APPLICATION_JSON_VALUE , produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<UpdateCreditAppFraudStatusMainResponse> updateCreditAppFraudStatus(@RequestBody UpdateCreditAppFraudStatusRequest request){
        logger.info("UpdateCreditAppController :updateCreditAPpFraudStatus request {}",request);
        UpdateCreditAppFraudStatusMainResponse response=new UpdateCreditAppFraudStatusMainResponse();
        List<SOEError> errorList=new ArrayList<>();
        SOEError error=new SOEError();
        if(StringUtilities.isEmptyOrNull(request.getCcaAppNum())){
            error.setMessage("ccaAppNum cannot be empty/Null");
            errorList.add(error);
            response.setErrors(errorList);
            return Mono.just(response);
        }
        return updateCreditAppFraudStatusHelper.updateCreditAppFraudStatus(request);
    }
}
