package onevz.soe.cart.helper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import onevz.soe.cart.bpm.helper.CartServiceBpmHelper;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper3;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.ui.requests.AccessoryFinancingOffersUIRequest;
import onevz.soe.cart.ui.requests.AffirmFinancingUIRequest;
import onevz.soe.cart.ui.responses.AccessoryFinancingOffersUIResponse;
import onevz.soe.cart.ui.responses.AffirmFinancingUIResponse;
import onevz.soe.cart.util.CartPegaRequestErrorsUtil;
import onevz.soe.cart.util.CartUtil;
import onevz.soe.utilities.StringUtilities;
import reactor.core.publisher.Mono;

@Service
public class AccessoryFinancingOffersHelper {

	@Autowired
	private RedisHelper redisHelper;

	@Autowired
	private CartServiceBpmHelper bpmHelper;
	
	@Autowired
	private CartServiceBpmHelper3 bpmHelper3;

	public Mono<AccessoryFinancingOffersUIResponse> updateAccessoryFinancingOffers(
			AccessoryFinancingOffersUIRequest accessoryFinancingOffersUIRequest) {
		String channelType = CartUtil.getChannelType(accessoryFinancingOffersUIRequest.getChannelId());
		Mono<CartRedisData> redisData = redisHelper.getDataFromRedis();

		return redisData.flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED)) {
				if (accessoryFinancingOffersUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE")
						&& StringUtilities.isNotEmptyOrNull(data.getCreditAppNum())) {
					accessoryFinancingOffersUIRequest.getCartInfo().setCreditAppNum(data.getCreditAppNum());
					accessoryFinancingOffersUIRequest.getCartInfo().setCartCreator(data.getCreditAppNum());
				}

				if (StringUtilities.isNotEmptyOrNull(data.getCartId())) {
					accessoryFinancingOffersUIRequest.getCartInfo().setCartId(data.getCartId());
				}

				if (StringUtilities.isNotEmptyOrNull(data.getCaseId())) {
					accessoryFinancingOffersUIRequest.getCartInfo().setCaseId(data.getCaseId());
				}

				if ((StringUtilities.isNotEmptyOrNull(accessoryFinancingOffersUIRequest.getCartInfo().getIntendType())
						&& !accessoryFinancingOffersUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE")
						&& StringUtilities.isNotEmptyOrNull(data.getMtn()))) {
					accessoryFinancingOffersUIRequest.getCartInfo().setCartCreator(data.getMtn());
				}

				if ((StringUtilities.isNotEmptyOrNull(accessoryFinancingOffersUIRequest.getCartInfo().getIntendType())
						&& !accessoryFinancingOffersUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE"))
						&& StringUtilities.isNotEmptyOrNull(data.getAccountNumber())) {
					accessoryFinancingOffersUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
				}

				if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
						&& StringUtilities.isEmptyOrNull(accessoryFinancingOffersUIRequest.getCartInfo().getProcessingMTN())) {
					accessoryFinancingOffersUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
				}

				String intent = getIntent(accessoryFinancingOffersUIRequest.getCartInfo().getIntendType());
				if (StringUtilities.isNotEmptyOrNull(intent)) {
					accessoryFinancingOffersUIRequest.getCartInfo().setIntent(intent);
				}

				if (CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(accessoryFinancingOffersUIRequest.getChannelId()))
						&& (StringUtilities.isEmptyOrNull(accessoryFinancingOffersUIRequest.getCartInfo().getCaseId())
								|| StringUtilities.isEmptyOrNull(accessoryFinancingOffersUIRequest.getCartInfo().getCartId()))) {
					AccessoryFinancingOffersUIResponse errorResponse = new AccessoryFinancingOffersUIResponse();
					errorResponse.setErrors(CartPegaRequestErrorsUtil.validateCartIdAndCaseId(accessoryFinancingOffersUIRequest.getCartInfo()));
					return Mono.just(errorResponse);
				}

			}
			return bpmHelper.updateAccessoryFinancingOffers(accessoryFinancingOffersUIRequest);
		});
	}

	/**
	 * 
	 * @param intendType
	 * @return
	 */
	public String getIntent(String intendType) {
		String intent = "";
		switch (intendType) {
		case CartConstants.BYOD:
		case CartConstants.EUPBYOD:
			intent = CartConstants.BYOD;
			break;
		case CartConstants.AAL:
			intent = CartConstants.AAL;
			break;
		case CartConstants.EUP:
			intent = CartConstants.UPGRADE;
			break;
		case CartConstants.AAL_5G:
		case CartConstants.NSE_5G:
			intent = CartConstants.FIVEG_HOME;
			break;
		case CartConstants.DEO:
			intent = CartConstants.DEO;
			break;
		case CartConstants.NSE:
			intent = CartConstants.NSE;
			break;
		case CartConstants.ADD_ACCESSORY:
			intent = CartConstants.ACCESSORY_C;
			break;
		case CartConstants.NSE_BYOD:
			intent = CartConstants.NSE_BYOD;
			break;
		case CartConstants.NSE_LTE:
			intent = CartConstants.NSE_LTE;
			break;
		case CartConstants.AAL_LTE:
			intent = CartConstants.AAL_LTE;
			break;
		}
		return intent;
	}

	public Mono<AffirmFinancingUIResponse> updateAffirmFinancingStatus(AffirmFinancingUIRequest affirmFinancingUIRequest) {
		String channelType = CartUtil.getChannelType(affirmFinancingUIRequest.getChannelId());
		Mono<CartRedisData> redisData = redisHelper.getDataFromRedis();

		return redisData.flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED)) {
				if (affirmFinancingUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE")
						&& StringUtilities.isNotEmptyOrNull(data.getCreditAppNum())) {
					affirmFinancingUIRequest.getCartInfo().setCreditAppNum(data.getCreditAppNum());
					affirmFinancingUIRequest.getCartInfo().setCartCreator(data.getCreditAppNum());
				}

				if (StringUtilities.isNotEmptyOrNull(data.getCartId())) {
					affirmFinancingUIRequest.getCartInfo().setCartId(data.getCartId());
				}

				if (StringUtilities.isNotEmptyOrNull(data.getCaseId())) {
					affirmFinancingUIRequest.getCartInfo().setCaseId(data.getCaseId());
				}

				if ((StringUtilities.isNotEmptyOrNull(affirmFinancingUIRequest.getCartInfo().getIntendType())
						&& !affirmFinancingUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE")
						&& StringUtilities.isNotEmptyOrNull(data.getMtn()))) {
					affirmFinancingUIRequest.getCartInfo().setCartCreator(data.getMtn());
				}

				if ((StringUtilities.isNotEmptyOrNull(affirmFinancingUIRequest.getCartInfo().getIntendType())
						&& !affirmFinancingUIRequest.getCartInfo().getIntendType().toUpperCase().contains("NSE"))
						&& StringUtilities.isNotEmptyOrNull(data.getAccountNumber())) {
					affirmFinancingUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
				}

				if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())) {
					affirmFinancingUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
				}

				String intent = getIntent(affirmFinancingUIRequest.getCartInfo().getIntendType());
				if (StringUtilities.isNotEmptyOrNull(intent)) {
					affirmFinancingUIRequest.getCartInfo().setIntent(intent);
				}

				if (CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(affirmFinancingUIRequest.getChannelId()))
						&& (StringUtilities.isEmptyOrNull(affirmFinancingUIRequest.getCartInfo().getCaseId())
								|| StringUtilities.isEmptyOrNull(affirmFinancingUIRequest.getCartInfo().getCartId()))) {
					AffirmFinancingUIResponse errorResponse = new AffirmFinancingUIResponse();
					errorResponse.setErrors(CartPegaRequestErrorsUtil.validateCartIdAndCaseId(affirmFinancingUIRequest.getCartInfo()));
					return Mono.just(errorResponse);
				}

			}
			return bpmHelper3.updateAffirmFinancingStatus(affirmFinancingUIRequest);
		});
		
	}
}
