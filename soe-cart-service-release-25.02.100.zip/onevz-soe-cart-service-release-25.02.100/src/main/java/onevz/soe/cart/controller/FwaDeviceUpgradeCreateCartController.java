package onevz.soe.cart.controller;

import onevz.cxp.feature.util.FeatureFlag;
import onevz.soe.cart.helper.FwaDeviceUpgradeHelper;
import onevz.soe.cart.helper.RedisHelper2;
import onevz.soe.cart.requests.DeviceExchangeRequest;
import onevz.soe.cart.responses.DeviceExchangeResponse;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.bpm.model.response.Error;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;

import static onevz.soe.cart.constants.CartConstants.ACCOUNT_NUMBER;
import static onevz.soe.cart.constants.FeatureFlagConstants.*;

@RestController
public class FwaDeviceUpgradeCreateCartController {
    @Autowired
    FeatureFlag featureFlag;

    @Autowired
    private FwaDeviceUpgradeHelper deviceUpgradeHelper;

    @Autowired
    private RedisHelper2 redisHelper;


    @PostMapping("/fwaDeviceUpgradeCreateCart")
    public Mono<DeviceExchangeResponse> fwaDeviceExchange(ServerHttpRequest headers, @RequestBody DeviceExchangeRequest request) {
        request.setAccountNumber(null != headers.getHeaders().getFirst(ACCOUNT_NUMBER) ? headers.getHeaders().getFirst(ACCOUNT_NUMBER) : "");
        Mono<Boolean> titanUpgradeFFlag = featureFlag.isFeatureEnabled(APPLICATION_NAME_ASSISTED,FWA_UPGRADE_PROFILE_FLAG,FWA_UPGRADE_NAME_FFLAG,Boolean.FALSE);
        Mono<DeviceExchangeRequest> redisData = redisHelper.fetchRedisData(request);
        return Mono.zip(titanUpgradeFFlag,redisData).flatMap(data -> {
            if(data.getT1()){
                DeviceExchangeResponse response = new DeviceExchangeResponse();
                validateRequest(data.getT2(),response);
                if(CollectionUtilities.isEmptyOrNull(response.getErrors())){
                    return deviceUpgradeHelper.getDeviceUpgradeDetails(data.getT2());
                }
                return Mono.just(response);
            }
            return Mono.just(new DeviceExchangeResponse());
        });
    }

    private void validateRequest(DeviceExchangeRequest request, DeviceExchangeResponse response) {
         if(StringUtilities.isEmptyOrNull(request.getNetworkBandWidthType())
                 || StringUtilities.isEmptyOrNull(request.getMtn())
                 || StringUtilities.isEmptyOrNull(request.getAccountNumber())){
             List<Error> errorList = new ArrayList<>();
             Error errors = new Error();
             errors.setErrorCode("1000");
             errors.setNamespace("onevz-soe-browse-service");
             errors.setName("VALIDATION_ERROR");
             errors.setMessage("Redis Data is empty ");
             errorList.add(errors);
             response.setErrors(errorList);
         }
    }
}
