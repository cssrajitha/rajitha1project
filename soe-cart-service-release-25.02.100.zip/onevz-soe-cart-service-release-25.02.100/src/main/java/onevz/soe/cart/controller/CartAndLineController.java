package onevz.soe.cart.controller;

import onevz.soe.cart.bpm.helper.CartAndLineBpmHelper;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.requests.CreateCaseUIRequest;
import onevz.soe.cart.responses.CreateCaseUIResponse;
import onevz.soe.cart.ui.requests.CommonCartUIRequest;
import onevz.soe.cart.ui.requests.ResumeCaseUIRequest;
import onevz.soe.cart.ui.responses.CartAndLineUIResponse;
import onevz.soe.cart.ui.responses.CommonCartUIResponse;
import onevz.soe.cart.ui.responses.ResumeCaseUIResponse;
import onevz.soe.session.constants.SessionBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseCookie;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping(value = "cart")
public class CartAndLineController {

    @Autowired
    CartAndLineBpmHelper cartAndLineBpmHelper;

    private static final Logger logger = LoggerFactory.getLogger(CartAndLineController.class);

    @InitBinder("*")
    public void initBinderByName(WebDataBinder binder) {
        binder.setDisallowedFields(new String[] { "genericHeader" });
    }

    @PostMapping(value = {"/nse/createCartAndLine"} , consumes = MediaType.APPLICATION_JSON_VALUE , produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<CartAndLineUIResponse> createCartAndLine(ServerHttpRequest serverHttpRequest, ServerHttpResponse serverHttpResponse,
                                                         @RequestBody CommonCartUIRequest request){
        String clientIdHeader = serverHttpRequest.getHeaders().containsKey(CartConstants.CLIENT_ID)
                ? serverHttpRequest.getHeaders().getFirst(CartConstants.CLIENT_ID)
                : "";

        Mono<CartAndLineUIResponse> response = cartAndLineBpmHelper.createCartAndLine(request, clientIdHeader);
        return response.flatMap(resp -> {
            if(null != request.getData() && null != request.getData().getIsCookieRequired() && request.getData().getIsCookieRequired()) {
                logger.info("setting the cookie from the code for .vzcorp.com domain");
                SessionBuilder.SessionLookup lookup = SessionBuilder.withContext().fromAll();
                String sessionId = lookup.obtainSessionId();
                ResponseCookie cookie = ResponseCookie.from(CartConstants.ASSISTED_IG_SESSION_ID, sessionId).secure(true).httpOnly(false).domain(".vzwcorp.com").build();
                serverHttpResponse.addCookie(cookie);
            }
            return Mono.just(resp);
        });
    }

    @PostMapping(value = {"/nse/buildLine"} , consumes = MediaType.APPLICATION_JSON_VALUE , produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<CommonCartUIResponse> buildLine(ServerHttpRequest serverHttpRequest,@RequestBody CommonCartUIRequest request){
        String clientIdHeader = serverHttpRequest.getHeaders().containsKey(CartConstants.CLIENT_ID)
                ? serverHttpRequest.getHeaders().getFirst(CartConstants.CLIENT_ID) : "";
        return cartAndLineBpmHelper.buildLine(request, clientIdHeader);
    }

    @PostMapping(value = {"/nse/deleteCart"} , consumes = MediaType.APPLICATION_JSON_VALUE , produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<CommonCartUIResponse> deleteCart(ServerHttpRequest serverHttpRequest,@RequestBody CommonCartUIRequest request){
        String clientIdHeader = serverHttpRequest.getHeaders().containsKey(CartConstants.CLIENT_ID)
                ? serverHttpRequest.getHeaders().getFirst(CartConstants.CLIENT_ID) : "";
        return cartAndLineBpmHelper.deleteCart(request, clientIdHeader);
    }

    @PostMapping(value = {"/resumeCase", "/nse/resumeCase"} , consumes = MediaType.APPLICATION_JSON_VALUE , produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<ResumeCaseUIResponse> resumeCase(ServerHttpRequest serverHttpRequest, @RequestBody ResumeCaseUIRequest request){
        String clientIdHeader = serverHttpRequest.getHeaders().containsKey(CartConstants.CLIENT_ID)
                ? serverHttpRequest.getHeaders().getFirst(CartConstants.CLIENT_ID) : "";
        return cartAndLineBpmHelper.resumeCase(request, clientIdHeader);
    }

    @PostMapping(value = {"/createCase", "/nse/createCase"} , consumes = MediaType.APPLICATION_JSON_VALUE , produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<CreateCaseUIResponse> createCase(ServerHttpRequest serverHttpRequest, @RequestBody CreateCaseUIRequest request){
        String clientIdHeader = serverHttpRequest.getHeaders().containsKey(CartConstants.CLIENT_ID)
                ? serverHttpRequest.getHeaders().getFirst(CartConstants.CLIENT_ID) : "";
        return cartAndLineBpmHelper.createCase(request, clientIdHeader);
    }


}
