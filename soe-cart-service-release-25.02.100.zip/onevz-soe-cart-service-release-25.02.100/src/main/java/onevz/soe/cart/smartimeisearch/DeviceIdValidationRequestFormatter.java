package onevz.soe.cart.smartimeisearch;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.deviceIdValidation.*;
import onevz.soe.cart.requests.DeviceIdValidationPEGARequest;
import org.apache.commons.lang3.StringUtils;
import onevz.soe.cart.ui.requests.DeviceIdValidationUIRequest;
import onevz.soe.cart.util.CartPegaRequestUtil;
import onevz.soe.cart.util.CartUtil;
import onevz.soe.cart.util.CommonUtil;
import onevz.soe.utilities.StringUtilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Configurable
public class DeviceIdValidationRequestFormatter {

    private static final Logger logger = LoggerFactory.getLogger(DeviceIdValidationRequestFormatter.class);

    @Autowired
	private CommonUtil util;

    @Autowired
    CartServiceCxpHelper cxpHelper;

    @Value("${enableDeviceIdChecksumGenerator}")
	private boolean enableDeviceIdChecksumGenerator;


    /**
     *
     * @param request
     * @param pegaRequest
     * @return DeviceIdValidationPEGARequest
     */
    public DeviceIdValidationPEGARequest formatDeviceIdValidationRequest(DeviceIdValidationUIRequest request,
                                                                        DeviceIdValidationPEGARequest pegaRequest, SearchAttributes attributes) {

        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        serviceHeader = CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(request.getChannelId());
        boolean isExistCustPrepayFlow = false;
        
       
        DeviceIdValidationServiceBody serviceBody = new DeviceIdValidationServiceBody();
        DeviceIdValidationServiceRequest serviceRequest = new DeviceIdValidationServiceRequest();

        DeviceIdValidationContext context = new DeviceIdValidationContext();

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(request.getCartInfo().getCartCreator());

        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(request.getCartInfo().getCartId());

        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        contextInfo = CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.DEVICEID_VALIDATION,
                request.getCartInfo().getClientAppName());
        //setIntent
        contextInfo.setIntent(request.getCartInfo().getIntent());
		if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntent()) && request.getCartInfo().getIntent().equalsIgnoreCase(CartConstants.REFUND_EXCHANGE)) {
			contextInfo.setCallReason(CartConstants.SALES_ORDER_ADJUSTMENT);
			serviceHeader.setServiceName(CartConstants.SALES_ORDER_ADJUSTMENT);
			contextInfo.setIntent(CartConstants.SALES_ORDER_ADJUSTMENT);
		}


        //MVP2
        if(request.getCartInfo()!=null && request.getCartInfo().getCaseId()!=null &&
                request.getCartInfo().getCaseId().startsWith(CartConstants.SOF)){
            isExistCustPrepayFlow= true;
            contextInfo.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }
        //MVP2 BVQ-2663
        if(!StringUtilities.isEmptyOrNull(request.getCartInfo().getCaseId())
                && request.getCartInfo().getCaseId().startsWith("SOF", 0)
                && request.getCartInfo().getOneClick()!=null && request.getCartInfo().getOneClick() == Boolean.TRUE)
        {
            cartInfo.setOneClick(request.getCartInfo().getOneClick());
        }
        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessStep()))
            contextInfo.setProcessStep(request.getCartInfo().getProcessStep());
        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessAction()))
            contextInfo.setProcessAction(request.getCartInfo().getProcessAction());

        context.setLines(new ArrayList<>());
        if(request.getData().getLines() != null){
            DeviceIdValidationLine line = request.getData().getLines().get(0);
            DeviceIdValidationLine pegaLine = new DeviceIdValidationLine();
            if(line.getMtn() != null)
                pegaLine.setMtn(line.getMtn());
            if(line.getDevice() != null){
            	Device device = util.formatDevice(line, new Device());
                if(line.getDevice().getSku() != null) {
                    device.setSku(line.getDevice().getSku());
                    SearchAttributes searchAttributes = new SearchAttributes();
                    searchAttributes.setSku(line.getDevice().getSku());
                    searchAttributes.setProdCode("");
                    searchAttributes.setHdVoiceInd("");
                    searchAttributes.setDeviceType("");
                    searchAttributes.setDacc("");
                    device.setSearchAttributes(searchAttributes);
                }
                if(line.getDevice().getSim() != null)
                    device.setSim(line.getDevice().getSim());
                if(line.getDevice().getGiftbox() != null)
                    device.setGiftbox(line.getDevice().getGiftbox());

                if (line.getDevice().getSmartIMEI() != null) {
                    device.setSmartIMEI(line.getDevice().getSmartIMEI());
                    if(line.getDevice().getSmartIMEI()) {
                    	/*
						 * change for skipping the elastic serach call for setting the device sku in
						 * case of care channel. https://onejira.verizon.com/browse/VZWYN-15574
						 */  
                    	if(request.getChannelId().equalsIgnoreCase(CartConstants.OMNI_CARE) && (line.getDevice() != null) && !StringUtilities.isEmptyOrNull(line.getDevice().getSku()))
                            device.setSku(line.getDevice().getSku());
                        else if(!StringUtilities.isEmptyOrNull(line.getDevice().getSkuCarrier()) &&
                                !StringUtilities.isEmptyOrNull(line.getDevice().getSorDisplayName())){
                            logger.info("DeviceIdValidationRequestFormatter :: setting search attributes :{}",attributes);
                            device.setSearchAttributes(attributes);
                            device.setSku(attributes.getSku());
                        }
                    }
                }
                
                device.setSkipImei1Call(request.isSkipImei1Call());
                pegaLine.setDevice(device);
            }
            List<DeviceIdValidationLine> lineList = new ArrayList<>();
            lineList.add(pegaLine);
            context.setLines(lineList);
        }
        if (null!= request.getCartInfo() && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLocationCode())) {
            customerInfo.setLocationCode(request.getCartInfo().getLocationCode());
        }

        if (CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())
				|| CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())
				|| CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntent())
				|| CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntent())
				||((CartConstants.AAL.equalsIgnoreCase(request.getCartInfo().getIntent())
				|| CartConstants.AAL.equalsIgnoreCase(request.getCartInfo().getIntendType())
				|| CartConstants.BYOD.equalsIgnoreCase(request.getCartInfo().getIntent())
				|| CartConstants.BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())) &&(isExistCustPrepayFlow))) {
            if (StringUtilities.isEmptyOrNull(request.getCartInfo().getAccountNumber()) || CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId())))
                customerInfo.setAccountNumber("");
            if (StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessingMTN()))
                customerInfo.setProcessingMTN("");

            if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getSessionId())) {
                if (StringUtilities.isEmptyOrNull(request.getCartInfo().getGlobalId()))
                    customerInfo.setGlobalId(request.getCartInfo().getSessionId());
                if (StringUtilities.isEmptyOrNull(request.getCartInfo().getCartCreator()))
                    customerInfo.setCartCreator(request.getCartInfo().getSessionId());
            }
            if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCustomerType()))
                customerInfo.setCustomerType(request.getCartInfo().getCustomerType());
            else
                customerInfo.setCustomerType(CartConstants.NEW_CUSTOMER);
            if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getMtnFlow()))
                customerInfo.setMtnFlow(request.getCartInfo().getMtnFlow());

            if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCreditAppNum())) {
            	customerInfo.setCartCreator(request.getCartInfo().getCreditAppNum());
            	customerInfo.setOriginalCreditApprovalNumber(request.getCartInfo().getCreditAppNum());
            }
            
            if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCartCreator())) {
            	customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
            } else if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCreditAppNum())) {
            	customerInfo.setCartCreator(request.getCartInfo().getCreditAppNum());
            }
			
			if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLocationCode())) {
                customerInfo.setLocationCode(request.getCartInfo().getLocationCode());
            }
            
            if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())) {
            	cartInfo.setIntendType(request.getCartInfo().getIntendType());
            	contextInfo.setIntent(request.getCartInfo().getIntendType());            
            	} else if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntent())) {
            		cartInfo.setIntendType(request.getCartInfo().getIntent());
                	contextInfo.setIntent(request.getCartInfo().getIntent()); 
            }
        }
        
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())) {
        	cartInfo.setIntendType(request.getCartInfo().getIntendType());
        	contextInfo.setIntent(request.getCartInfo().getIntendType());            
        	} else if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntent())) {
        		cartInfo.setIntendType(request.getCartInfo().getIntent());
            	contextInfo.setIntent(request.getCartInfo().getIntent()); 
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntent()) && request.getCartInfo().getIntent().equalsIgnoreCase(CartConstants.REFUND_EXCHANGE))
            contextInfo.setIntent(request.getCartInfo().getIntent());
        context.setAction(
				StringUtilities.isNotEmptyOrNull(request.getCartInfo().getAction()) ? request.getCartInfo().getAction()
						: "");
        context.setCaseId(request.getCartInfo().getCaseId());
        // DVM conversion flow changes
        if(CartPegaRequestUtil.isDvmConversionFlagExists()) {
        	customerInfo.setCustomerType(CartConstants.NEW_CUSTOMER);
        }
        setFWARetailExchangeCallReason(request, contextInfo, serviceHeader);

        context.setCustomerInfo(customerInfo);
        context.setCartInfo(cartInfo);
        context.setContextInfo(contextInfo);

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);

        pegaRequest.setServiceHeader(serviceHeader);
        pegaRequest.setServiceBody(serviceBody);

        return pegaRequest;

    }

    private void setFWARetailExchangeCallReason(DeviceIdValidationUIRequest request, CartServiceContextInfo contextInfo, CartServiceServiceHeader serviceHeader) {
        if(StringUtils.isNotBlank(request.getCartInfo().getIntent())
                && CartConstants.FIVEG_HOME_RETAIL_RFEX.equalsIgnoreCase(request.getCartInfo().getIntent())){
            contextInfo.setCallReason(CartConstants.SALES_ORDER_ADJUSTMENT);
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_ADJUSTMENT);
        }
    }

    /**
     * @param standalone
     * @param deviceImei
     * @param pegaRequest
     * @return
     */
    public DeviceIdValidationPEGARequest initiateRPSFlow( boolean standalone, String deviceImei, String accNumber, String cartCreator,
                                                         DeviceIdValidationPEGARequest pegaRequest) {

        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        serviceHeader = CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId("VZW-RPS");

        DeviceIdValidationServiceBody serviceBody = new DeviceIdValidationServiceBody();
        DeviceIdValidationServiceRequest serviceRequest = new DeviceIdValidationServiceRequest();

        DeviceIdValidationContext context = new DeviceIdValidationContext();

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(accNumber);
        customerInfo.setCartCreator(cartCreator);
        customerInfo.setMtnFlow("M");

        CartServiceCartInfo cartInfo = new CartServiceCartInfo();


        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        contextInfo.setCallReason(CartConstants.SALES_ORDER_PURCHASE);

        contextInfo.setProcessStep("");
        contextInfo.setProcessAction("Login");

        if (standalone) {
            contextInfo.setIntent("BYOD-RPS-SA");
        } else {
            contextInfo.setIntent("BYOD-RPS-NS");
        }

        DeviceIdValidationLine pegaLine = new DeviceIdValidationLine();
        Device device = new Device();
        device.setId(deviceImei);
        device.setFlowtype("DEVICE");
        device.setSmartIMEI(false);
        device.setIsCustomerProvidedEquipment(true);

        SoftSKUItem simSku = new SoftSKUItem();

        simSku.setId("");
        simSku.setCurrentId("");
        simSku.setIsCustomerProvidedSIM(true);

        device.setSim(simSku);

        pegaLine.setDevice(device);

        List<DeviceIdValidationLine> lineList = new ArrayList<>();
        lineList.add(pegaLine);
        context.setLines(lineList);


        context.setCustomerInfo(customerInfo);
        context.setCartInfo(cartInfo);
        context.setContextInfo(contextInfo);

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);

        pegaRequest.setServiceHeader(serviceHeader);
        pegaRequest.setServiceBody(serviceBody);

        return pegaRequest;

    }
}
