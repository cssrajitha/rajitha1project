package onevz.soe.cart.helper;

import com.datastax.oss.driver.shaded.guava.common.util.concurrent.AtomicDouble;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.constants.FeatureFlagConstants;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.gql.CurrentProfileSPO;
import onevz.soe.cart.gql.requests.ACPInfoGQL;
import onevz.soe.cart.gql.schema.LineLevelOffers;
import onevz.soe.cart.gql.schema.MobileInfoCustomerProfile;
import onevz.soe.cart.gql.schema.newCustomer.CustomerProfileForNSE;
import onevz.soe.cart.model.common.FiveG.FiveGLTEAddressRedis;
import onevz.soe.cart.model.retrieveCart.*;
import onevz.soe.cart.model.retrieveCart.fiveG.AMRegisterationDetails;
import onevz.soe.cart.model.retrieveCart.fiveG.CXPDueItemsList;
import onevz.soe.cart.model.retrieveCart.fiveG.CXPDueTaxesList;
import onevz.soe.cart.model.retrieveCart.fiveG.CXPOrderDetailsView;
import onevz.soe.cart.requests.GetCartDetailsRequest;
import onevz.soe.cart.requests.RetrieveCartCXPRequest;
import onevz.soe.cart.responses.ACPInfoDetails;
import onevz.soe.cart.responses.GetCartDetailsUIResponse;
import onevz.soe.cart.responses.RetrieveCartRedisData;
import onevz.soe.cart.ui.responses.RetrieveCartUIResponse;
import onevz.soe.cart.util.CommonUtil;
import onevz.soe.cart.util.CommonUtil2;
import onevz.soe.logging.util.LoggerUtil;
import onevz.soe.security.util.RPSAES128CBCUtil;
import onevz.soe.utilities.StringUtilities;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.text.DecimalFormat;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static onevz.soe.cart.util.CommonUtil.*;

@Service

public class FiveGhomeNSEHelper {

    @Autowired
    private RedisHelper redisHelper;
    @Autowired
    private RedisHelper3 redisHelper3;
    @Autowired
    CartServiceCxpHelper cxpHelper;
    @Autowired
    CommonUtil commonUtil;
    @Autowired
    CommonUtil2 commonUtil2;
    @Autowired
    private RPSAES128CBCUtil security5GUtil;
    @Autowired
    private FiveGhomeCommonHelper fiveGhomeCommonHelper;
    @Autowired
    private FiveGhomeAALHelper fiveGhomeAALHelper;
    @Autowired
    private EncryptDecryptHelper encryptDecryptHelper;

    @Autowired
    FeatureFlagHelper featureFlagHelper;


    @Value("${soe.5g.promoKey.wireless:wireless-offer}")
    private String wirelessPromoKey;
    @Value("${soe.5g.switch.cartRedesignKillSwitch:false}")
    private boolean cartRedesignKillSwitch;
    @Value("${soe.5g.promoKey.autoPay:auto-pay-and-paper-free-billing}")
    private String autoPayPromoKey;
    @Value("#{'${soe.digital.fwa.excludeItemTypesFromDueMonthlyCalculation:}'.split(',')}")
    private List<String> excludeItemTypesFromDueMonthly;



    private static final Logger logger = LoggerFactory.getLogger(FiveGhomeNSEHelper.class);

    /**
     * @param request
     * @return RetrieveCartUIResponse
     */

    public Mono<ResponseEntity<GetCartDetailsUIResponse>> get5GCart(GetCartDetailsRequest request) {

        return redisHelper3.getCartDataFromRedisForFiveGFlow().flatMap(data -> {

            String logginMtn=  commonUtil.getOpenIgTokens().get(CartConstants.LOOKUP_MTN);
            boolean sroFwafflag= featureFlagHelper.getFeatureFlagWithAccNumThrottle(FeatureFlagConstants.AWS_CONFIG_APP_NAME,FeatureFlagConstants.CONFIGURATOR_SRO_CFG, FeatureFlagConstants.SRO_FWA_RetrieveCart_FFlag,"",logginMtn);
            request.getFeatureFlags().put(FeatureFlagConstants.SRO_FWA_RetrieveCart_FFlag,sroFwafflag);
        	if(null != data.getIsSequentialComboOrder()){
				request.setIsSequentialComboOrder(data.getIsSequentialComboOrder());
			}
            RetrieveCartCXPRequest cxpRequest = new RetrieveCartCXPRequest();
            commonUtil.formatCxpRequest(request, cxpRequest, data);
            logger.debug("Calling cxp helper with cartId {}", data.getCartId());
            boolean redesignFlow = request.getData().isRedesignFlow() || Boolean.valueOf(data.getRedesignFlow()) || StringUtilities.isNotEmptyOrNull(data.getNetworkBandwidthType());
            return cxpHelper.retrieve5GCart(cxpRequest, StringUtilities.isNotEmptyOrNull(data.getCompletedCartId())).flatMap(cxpResponse -> {
                if(null != cxpResponse.getErrors()) {
                    GetCartDetailsUIResponse errResp = new GetCartDetailsUIResponse();
                    errResp.setErrors(Arrays.asList(cxpResponse.getErrors()));
                    return Mono.just(ResponseEntity.status(HttpStatus.OK).body(errResp));
                }
                Mono<FiveGLTEAddressRedis> redisData = redisHelper3.getCartDataFromRedisForFiveGFlow();
                Mono<Boolean> emberFFlagMap=featureFlagHelper.emberDiscountFeatureFlagMono();
                return Mono.zip(redisData,emberFFlagMap).flatMap(zippedResp -> {
                	FiveGLTEAddressRedis redisVal=zippedResp.getT1();
                    return fiveGhomeCommonHelper.upsertFwaSafeTechSessionId(redisVal.getSafeTechSessionId()).flatMap(value->{
                        logger.info("FWA_SAFETECH_SESSIONID : "+value);
                        if(cxpResponse.getData()!=null && cxpResponse.getData().getCart()!=null && request.getData().isOrderPlaced()) {
                            commonUtil2.generateOrderInfoKibanaLogs(cxpResponse.getData().getCart());
                        } else {
                            commonUtil2.generateCartInfoKibanaLogs(cxpResponse.getData().getCart());
                        }
                        // update lq data in crm flow
                        updateLQdataInredis(redisVal, cxpResponse);
                        updateDataToRedis(cxpResponse);
                        if (request.getData().isRedesignFlow())
                            updateRedesignFlagInredis();
                        AtomicReference<String> tagUrl = new AtomicReference<>();
                        if(request.getData().isOrderPlaced() && request.getAffiliate() != null){
                            Mono<String> responseMono = cxpHelper.getCJMTagUrl(request,redisVal);
                            return responseMono.flatMap(response ->{
                                tagUrl.set(response);
                                return Mono.just(ResponseEntity.status(HttpStatus.OK).body(transformCXPResponseToSOE(request, cxpResponse, redesignFlow, tagUrl.get(),redisVal)));
                            });
                        }
                        return Mono.just(ResponseEntity.status(HttpStatus.OK).body(transformCXPResponseToSOE(request, cxpResponse, redesignFlow, tagUrl.get(),redisVal)));
                    });
                });
            }).onErrorResume(throwable -> {
            	return commonUtil.responseOnError(throwable);
            });
        });
    }

    private void updateLQdataInredis(FiveGLTEAddressRedis redisVal, RetrieveCartUIResponse cxpResponse){
        try {
            if(StringUtilities.isNotEmptyOrNull(redisVal.getCrmResumeCartFlow())&& Boolean.valueOf(redisVal.getCrmResumeCartFlow())&&StringUtilities.isEmptyOrNull(redisVal.getAddressLine1())){
                updateLqDataInCrmRedis(cxpResponse);
            }
        } catch (Exception e) {
            LoggerUtil.logOnError(r -> logger.error("Error occurred while updating intendType", e));
        }
    }
    public void updateLqDataInCrmRedis(RetrieveCartUIResponse cxpResponse) {
        Map<String, String> requestMap = new HashMap<>();
        try {
            CXPLineDetailsVO lineDetails = cxpResponse.getData().getCart().getLineDetails();
            CXPOrderDetails orderDetails = cxpResponse.getData().getCart().getOrderDetails();
            commonUtil.formatRequestMap(lineDetails, orderDetails, requestMap);
        } catch (Exception e) {
            logger.info("Exception in lqInfo in CRM-ResumeCart/ intendType to redis {}", e.getMessage());
        }
    }
    private void updateDataToRedis(RetrieveCartUIResponse cxpResponse) {

        RetrieveCartRedisData rr = new RetrieveCartRedisData();
        rr.setData(populateLineRedisData(cxpResponse));
        try {
            redisHelper.upsertRetrieveCartDataIntoRedis(rr);
        } catch(Exception e) {
            logger.info("Exception in updating 5g cart response to redis {}" , e.getMessage());
        }
    }
    public void updateRedesignFlagInredis(){
        try {
            redisHelper3.setRedesignFlaginRedis().doOnSuccess(onSuccess -> {
                logger.info("redesign Flow flag updated in redis...");
            }).doOnError(error ->{
                logger.info("Exception in updating redesign flag to redis...");
            });
        }catch (Exception e) {
            logger.info("Exception in updating redesign flag to redis {}" , e.getMessage());
        }

    }
    private GetCartDetailsUIResponse transformCXPResponseToSOE(GetCartDetailsRequest request, RetrieveCartUIResponse cxpResponse, boolean redesignFlow, String tagUrl, FiveGLTEAddressRedis redisVal) {
        // due monthly items order should be : device(5g/Lte router), 5g/lte plan, yttv, protection and discounts(loyalty,autopay/ecpd.. etc)
        Map<String, String> planDetails = new HashMap<>();
        GetCartDetailsUIResponse response=new GetCartDetailsUIResponse();
        AtomicBoolean isEupFlow= new AtomicBoolean(false);
        response.setFeatureFlags(request.getFeatureFlags());
        if (null != cxpResponse && null != cxpResponse.getData() && null != cxpResponse.getData().getCart()) {
            boolean isLoggedIn = false;
            if (cxpResponse.getData().getCart().getCartHeader() != null) {
                response.setCartHeader(cxpResponse.getData().getCart().getCartHeader());
                isLoggedIn = StringUtils.isNotBlank(cxpResponse.getData().getCart().getCartHeader().getFullAccountNumber());
                response.getCartHeader().setCaseId(null);
                if(StringUtilities.isNotEmptyOrNull(response.getCartHeader().getCartId()))
                {
                  response.getCartHeader().setCartExist("Y");
                }
                else
                {
                    response.getCartHeader().setCartExist("N");
                }
                response.getCartHeader().setCartId(null);
            }
            boolean isNSEFlow = !isLoggedIn;
            CXPOrderDetailsView orderDetailsView = populateCXPOrderDetailsView(cxpResponse);
            AMRegisterationDetails amRegisterationDetails = new AMRegisterationDetails();
            CXPOrderDetails cxpOrderDetails1 = cxpResponse.getData().getCart().getOrderDetails();
            List<OrderList> list = cxpResponse.getData().getCart().getOrderDetails().getOrderList();
            orderDetailsView.setEligible5GHomeBundle(cxpOrderDetails1.getEligible5GHomeBundle());
            List<CXPDueTaxesList> dueTodayTaxes = new ArrayList<>();
            List<CXPDueTaxesList> dueMonthlyTaxes = new ArrayList<>();
            CXPDueTaxesList todayTaxes = new CXPDueTaxesList();
            CXPDueTaxesList monthlyTaxes = new CXPDueTaxesList();
            List<CXPPaymentsVO> payments = new ArrayList<>();
            List<CXPShippingVO> shippingDetails = new ArrayList<>();
            todayTaxes.setDueAmount(cxpOrderDetails1.getTotalTaxAmount());
            monthlyTaxes.setDueAmount(String.valueOf(cxpOrderDetails1.getTotalMonthlyTaxes()));
            dueTodayTaxes.add(todayTaxes);
            dueMonthlyTaxes.add(monthlyTaxes);
            List<CXPDueItemsList> dueTodayList = new ArrayList<>();
            List<CXPDueItemsList> dueMonthlyList = new ArrayList<>();
            List<String> hiddenPromoList = new ArrayList<>();
            CXPLineDetailsVO lineDetails = cxpResponse.getData().getCart().getLineDetails();
            String lineActivityType="";
            if(lineDetails != null && lineDetails.getLineInfo() != null && cxpOrderDetails1.getFlowType() != null && CartConstants.FLOW_TYPE_WHW.equalsIgnoreCase(cxpOrderDetails1.getFlowType())) {
                lineActivityType = Arrays.stream(cxpResponse.getData().getCart().getLineDetails().getLineInfo()).map(CXPLineInfo::getLineActivityType).collect(Collectors.joining());
            }
            CXPCartVO cart = cxpResponse.getData().getCart();
            CustomerProfileForNSE customerProfileForNSE = cart.getCustomerProfileForNSE();
            // VZWDHM-4015 : added lineLineOffers

            CXPLineInfo[] lineInfo = null;
            if (isLoggedIn) {
                hiddenPromoList.add(wirelessPromoKey);
            }
            if(StringUtilities.isNotEmptyOrNull(tagUrl)){
                orderDetailsView.setCjmTagUrl(tagUrl);
            }
            if(StringUtilities.isNotEmptyOrNull(redisVal.getSafeTechSessionId()))
                orderDetailsView.setSafeTechSessionId(redisVal.getSafeTechSessionId());
            populateOrderDetailsView(lineDetails, orderDetailsView);
            if(isLoggedIn) {
                response.getCartHeader().setDigitalCustomerType(fiveGhomeCommonHelper.getDigitalCustomerTypeFromCart(cxpResponse.getData().getCart().getCustomerProfile()));
            }
            if(featureFlagHelper.isFWAUnifiedNBSEnabled() && request.getData().isFetchUnifiedNbsData()){
                response.setUnifiedNbsData(encryptDecryptHelper.getUnifiedNbsData(request.getIgSession(),redisVal));
            }

            if (null != lineDetails && null != lineDetails.getLineInfo()) {
                Optional<CXPLineInfo> optionalValue = Arrays.stream(cxpResponse.getData().getCart().getLineDetails().getLineInfo()).filter(line -> line.getPreOrderInServiceDate() != null).findAny();
                if(optionalValue.isPresent()){
                    orderDetailsView.setPreOrderInServiceDate(optionalValue.get().getPreOrderInServiceDate());
                }
                lineInfo = Arrays.stream(lineDetails.getLineInfo()).filter(lineInf -> (lineInf.getLineNumber() != null && !CartConstants.FEA.equalsIgnoreCase(lineInf.getLineActivityType())) || (lineInf.getMtnDetails() != null && (CartConstants.FEA.equalsIgnoreCase(lineInf.getLineActivityType()) || CartConstants.ACC.equalsIgnoreCase(lineInf.getLineActivityType())))).sorted(Comparator.comparing(CXPLineInfo::getLineNumber)).collect(Collectors.toList()).toArray(new CXPLineInfo[lineDetails.getNumOfLines()]);
                Arrays.stream(lineInfo).filter(Objects::nonNull).forEach(lineInfo1 -> {
                    CXPDueItemsList dueMonthlyPlanItems;
                    //populate device details
                    fiveGhomeCommonHelper.populateCartDetails(isEupFlow, lineInfo1,shippingDetails,orderDetailsView,dueMonthlyList,dueTodayList);
                    if (null != lineInfo1 && null != lineInfo1.getServiceInfo()) {
                        SelectedFeaturesList selectedFeaturesList = lineInfo1.getServiceInfo().getSelectedFeaturesList();
                        List<CurrentProfileSPO> currentProfileSPOList = new ArrayList<>();
                        List<MobileInfoCustomerProfile> lstMtn = new ArrayList<>();
                        if(lineInfo1.getLineActivityType() != null && CartConstants.ACC.equalsIgnoreCase(lineInfo1.getLineActivityType()) && cxpOrderDetails1 != null && cxpOrderDetails1.getFlowType() != null && CartConstants.FLOW_TYPE_WHW.equalsIgnoreCase(cxpOrderDetails1.getFlowType())) {
                            String mtn = "";
                            if (null != lineInfo1.getServiceInfo().getMtn()) {
                                mtn = lineInfo1.getServiceInfo().getMtn();
                            }
                            if(cart != null && cart.getCustomerProfile() != null && cart.getCustomerProfile().getBillAccounts() != null && cart.getCustomerProfile().getBillAccounts().size() > 0 && cart.getCustomerProfile().getBillAccounts().get(0).getMtns() != null){
                                lstMtn = cart.getCustomerProfile().getBillAccounts().get(0).getMtns();
                            }
                            for (MobileInfoCustomerProfile cxpMtn : lstMtn) {
                                if (null != cxpMtn.getMtn() && StringUtilities.isNotEmptyOrNull(mtn) && cxpMtn.getMtn().equalsIgnoreCase(mtn)) {
                                    currentProfileSPOList = cxpMtn.getCurrentSpo();
                                }
                            }
                        }
                        int featuresCount = 0;
                        if(selectedFeaturesList != null){
                            featuresCount = selectedFeaturesList.getFeaturesCount();
                        }
                        List<String> promoList = request.getData() != null ? request.getData().getAvailableSpoCategoryFilters() : null;
                        orderDetailsView.setVerizonCloudUnlimitedIncluded(lineInfo1.getServiceInfo().getHasVerizonCloudUnlimitedIncluded());
                        if (null != lineInfo1.getServiceInfo().getPlanDetails() && (!fiveGhomeCommonHelper.isWHWFlowType(cxpOrderDetails1,lineInfo1.getLineActivityType())
                        && !fiveGhomeCommonHelper.isWWMFlowType(cxpOrderDetails1,lineInfo1.getLineActivityType()))) {
                                dueMonthlyPlanItems = new CXPDueItemsList();
                                dueMonthlyPlanItems.setActualAmount(String.valueOf(lineInfo1.getServiceInfo().getPlanDetails().getPlanPrice()));
                                dueMonthlyPlanItems.setTotalAmountWithDiscount(String.valueOf(lineInfo1.getServiceInfo().getPlanDetails().getPlanPrice()));
                                if (cartRedesignKillSwitch)
                                    //apply autopay, loyalty & ecpd discount to plan price
                                    fiveGhomeCommonHelper.applyPlanDiscountsOnPlan(redesignFlow, lineInfo1, cxpResponse.getData().getCart().getEcpdProfile(), dueMonthlyPlanItems);
                                //populate plan item
                                fiveGhomeCommonHelper.populateOverDetailsView(lineInfo1.getLineActivityType(), dueMonthlyPlanItems, lineInfo1, planDetails, orderDetailsView, dueMonthlyList);
                                fiveGhomeCommonHelper.populateSecurityDeposit(list, orderDetailsView);
                        }

                        logger.info("Adding Dummy Perks to soe DueMonthly List");
                        mapDummyPerkToDueMonthlyList(dueMonthlyList, lineInfo1,cxpOrderDetails1);
                        logger.info("Adding Dummy Perks to DueMonthly List -- completed");

                        fiveGhomeCommonHelper.populateAutoPayPromo(autoPayPromoKey,selectedFeaturesList,featuresCount,hiddenPromoList);
                        fiveGhomeCommonHelper.populateAEMRegistrationDetails(lineInfo1,response,isNSEFlow,amRegisterationDetails);

                        commonUtil.formatResponse(selectedFeaturesList, featuresCount, promoList, lineInfo1, response);
                        fiveGhomeCommonHelper.populateAppointmentDetails(lineInfo1,response);
                        fiveGhomeCommonHelper.setWhwBasicDetails(lineInfo1.getLineActivityType(),cxpOrderDetails1,lineInfo1,dueTodayList);
                        fiveGhomeCommonHelper.populateAccessoryOffers(lineInfo1,cxpOrderDetails1,lineInfo1.getLineActivityType(),currentProfileSPOList,dueTodayList);
                    }
                });
				if (null != request.getIsSequentialComboOrder()
						&& ("true".equalsIgnoreCase(request.getIsSequentialComboOrder()))) {
					fiveGhomeCommonHelper.populateComboForRetriveCallDetails(customerProfileForNSE, response);
				}
                fiveGhomeCommonHelper.callToPopulateDiscounts(cxpOrderDetails1,lineDetails,lineInfo,dueMonthlyList,redesignFlow,cxpResponse.getData().getCart().getEcpdProfile(), isLoggedIn);
                fiveGhomeCommonHelper.populateAccessoryDetails(lineInfo,dueTodayList);
            }

            if (null != lineDetails && null != lineDetails.getPayments()) {
                lineDetails.getPayments().stream().filter(Objects::nonNull).filter(cxpPaymentsVO -> StringUtils.isNotEmpty(cxpPaymentsVO.getPaymentType()))
                        .forEach(cxpPaymentsVO -> payments.add(cxpPaymentsVO));
            }

            fiveGhomeCommonHelper.populateEUPDetails(isEupFlow,response,lineDetails);
            calculateDueMonthly(dueMonthlyList,cxpOrderDetails1,orderDetailsView,isLoggedIn);
            commonUtil.formatGetCartDetailsUIResponse(request, dueMonthlyTaxes, shippingDetails, dueTodayList, dueMonthlyList, dueTodayTaxes, payments, amRegisterationDetails, isNSEFlow, orderDetailsView, hiddenPromoList, response);
            // Only for order Confirmation Page
            if(request.getData() != null && !request.getData().isOrderPlaced())
                commonUtil.populatePlanDetailsInKibana(response,planDetails);

            if (cxpResponse.getData().getCart().getAcpInfo() != null){
                ACPInfoGQL acpInfo = cxpResponse.getData().getCart().getAcpInfo();
                commonUtil2.generateACPInfoKibanaLogs(acpInfo);
                if (acpInfo.getCustomerInfo() != null){
                    if (response.getPrimaryUserInfo() != null ){
                        if ((StringUtilities.isEmptyOrNull(response.getPrimaryUserInfo().getFirstName()) ||
                                StringUtilities.isEmptyOrNull(response.getPrimaryUserInfo().getLastName()))
                                && acpInfo.getCustomerInfo().getContactInfo() != null){
                            response.getPrimaryUserInfo().setFirstName(acpInfo.getCustomerInfo().getContactInfo().getFirstName());
                            response.getPrimaryUserInfo().setLastName(acpInfo.getCustomerInfo().getContactInfo().getLastName());
                        }
                        response.getPrimaryUserInfo().setSsn(acpInfo.getCustomerInfo().getSsn());
                        response.getPrimaryUserInfo().setDob(acpInfo.getCustomerInfo().getDateOfBirth());
                    }
                }
                ACPInfoDetails infoDetails = new ACPInfoDetails();
                infoDetails.setEnrollmentNumber(acpInfo.getEnrollmentNumber());
                infoDetails.setNladSubscriberId(acpInfo.getNladSubscriberId());
                infoDetails.setBenefit(acpInfo.getBenefit());
                response.setAcpInfoDetails(infoDetails);
            }

            populateAutoPayDetail(lineDetails, response);
        }
        return response;
    }

    private void populateAutoPayDetail(CXPLineDetailsVO lineDetails, GetCartDetailsUIResponse response) {
        if (null != lineDetails) {
            response.setIsAutoPayEnrolled(lineDetails.getIsAutoPayEnrolled());
        }
    }

    private void mapDummyPerkToDueMonthlyList(List<CXPDueItemsList> dueMonthlyList, CXPLineInfo lineInfo1, CXPOrderDetails cxpOrderDetails1) {
        if(null != lineInfo1.getServiceInfo().getPlanPerks() && !fiveGhomeCommonHelper.isWHWFlowType(cxpOrderDetails1,lineInfo1.getLineActivityType())) {
            List<PlanPerks> planPerksList = lineInfo1.getServiceInfo().getPlanPerks();
            try {
                for (PlanPerks perk : planPerksList) {
                    CXPDueItemsList dueMonthlyPerkItems = new CXPDueItemsList();
                    dueMonthlyPerkItems.setActualAmount(String.valueOf(perk.getPerkOriginalPrice()));
                    dueMonthlyPerkItems.setTotalAmountWithDiscount(String.valueOf(perk.getFeaturePrice()));
                    dueMonthlyPerkItems.setName(perk.getFeatureDesc());
                    dueMonthlyPerkItems.setProductId(perk.getVisFeatureCode());
                    dueMonthlyPerkItems.setItemType("PERK");
                    dueMonthlyPerkItems.setDiscountsAndPromotions(perk.getDiscountsAndPromotions());
                    dueMonthlyList.add(dueMonthlyPerkItems);
                }
            }
            catch(Exception e){
                logger.error("Error occured while mapping perks to due monthly list {0}",e);
            }
        }
    }

    public void calculateDueMonthly(List<CXPDueItemsList> dueMonthlyList, CXPOrderDetails cxpOrderDetails1, CXPOrderDetailsView orderDetailsView,boolean isLoggedIn) {
        // calculate Due Monthly
        AtomicDouble totalDueMonthly = new AtomicDouble(0.0);
        DecimalFormat doubleFormattingTo2Decimal = new DecimalFormat("0.00");
        Predicate<CXPDueItemsList> isItemApplicableForDueMonthly = (dueMonthlyItem) -> (StringUtilities.isNotEmptyOrNull(dueMonthlyItem.getItemType(), dueMonthlyItem.getTotalAmountWithDiscount())
                && ((isLoggedIn && (!(Boolean.TRUE.equals(dueMonthlyItem.getIsHomePhone())|| excludeItemTypesFromDueMonthly.contains(dueMonthlyItem.getItemType())) || dueMonthlyItem.isAccountDiscount()))
                || ((!isLoggedIn || orderHasProSetUp(orderDetailsView))
                    && (!dueMonthlyItem.getItemType().endsWith(CartConstants.HELPER_DISCOUNT)) || dueMonthlyItem.isAccountDiscount()))
        );
        dueMonthlyList.stream().filter(isItemApplicableForDueMonthly).forEach(dueMonthlyItem -> {
            totalDueMonthly.set(!dueMonthlyItem.isAccountDiscount() ? totalDueMonthly.addAndGet(Double.parseDouble(dueMonthlyItem.getTotalAmountWithDiscount())) : totalDueMonthly.addAndGet(-Double.parseDouble(dueMonthlyItem.getTotalAmountWithDiscount())));
        });
        totalDueMonthly.addAndGet(cxpOrderDetails1.getTotalMonthlyTaxes());
        totalDueMonthly.set(Double.valueOf(doubleFormattingTo2Decimal.format(totalDueMonthly)));
        orderDetailsView.setDueMonthlyAmount(String.valueOf(totalDueMonthly));
    }

    /**
     * Returns true if the order has professional set up.
     * @return
     */
    private boolean orderHasProSetUp(CXPOrderDetailsView orderDetailsView) {
        return CartConstants.PROF_SETUP.equalsIgnoreCase(orderDetailsView.getInstallType());
    }

}
