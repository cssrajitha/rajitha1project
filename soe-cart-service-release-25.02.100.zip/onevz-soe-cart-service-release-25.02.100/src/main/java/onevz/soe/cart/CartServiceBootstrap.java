package onevz.soe.cart;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import onevz.soe.core.annotations.SOEBootApplication;
import onevz.soe.datastore.annotations.EnableDatastoreClients;
import org.springframework.boot.SpringApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.FilterType;

/**
 * CartService Bootstrap class.
 */
@SOEBootApplication
@ComponentScan(basePackages = { "onevz.spring.config", "onevzw.soe.core.config", "onevz.soe.cart", "onevz.soe.session","onevz.aem.errorhandling",
		 "onevz.soe.wsclient.bpm", "onevz.soe.spring.web.filter", "onevz.wsclient.cxp", "onevz.soe.security","onevz.soe.cradle.client","onevz.soe.refundexchange","onevz.cxp.feature" })
@EnableDatastoreClients(value = {"onevz.soe.cradle", "onevz.soe.core.exception.datastore.client", "onevz.onevzsoe.peripherals.cassandra"})
@OpenAPIDefinition(info = @Info(title = "Cart Service", version = "22.09.100", description = "Documentation For SOE Cart Service"))
public class CartServiceBootstrap {

	/**
	 * 
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(CartServiceBootstrap.class, args);
		
	}
}
