package onevz.soe.cart.util;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.initiatecart.CpcFeatureRequest;
import onevz.soe.cart.model.addAccessory.AccessoryAction;
import onevz.soe.cart.model.addDevice.*;
import onevz.soe.cart.model.addPromoIntent.AddPromoIntent;
import onevz.soe.cart.model.addreplenishment.AddReplenishMentContext;
import onevz.soe.cart.model.addreplenishment.AddReplenishMentServiceBody;
import onevz.soe.cart.model.addreplenishment.AddReplenishMentServiceRequest;
import onevz.soe.cart.model.affirmfinancing.AffirmFinancingPegaRequest;
import onevz.soe.cart.model.affirmfinancing.AffirmFinancingServiceBody;
import onevz.soe.cart.model.affirmfinancing.AffirmFinancingServiceContext;
import onevz.soe.cart.model.affirmfinancing.AffirmFinancingServiceRequest;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.common.FiveG.*;
import onevz.soe.cart.model.common.FiveG.CartServiceCartInfo;
import onevz.soe.cart.model.common.FiveG.CartServiceContextInfo;
import onevz.soe.cart.model.common.FiveG.CartServiceCustomerInfo;
import onevz.soe.cart.model.common.Line;
import onevz.soe.cart.model.edgeup.EdgeUp;
import onevz.soe.cart.model.edgeup.UpdateEdgeupContext;
import onevz.soe.cart.model.edgeup.UpdateEdgeupServiceBody;
import onevz.soe.cart.model.edgeup.UpdateEdgeupServiceRequest;
import onevz.soe.cart.model.retrieveCart.TradeInDetail;
import onevz.soe.cart.model.retrieveCart.TradeInItem;
import onevz.soe.cart.model.retrieveCart.Triage;
import onevz.soe.cart.model.retrieveCart.TriageInfo;
import onevz.soe.cart.model.salesRepAndLocationCode.SalesRepAndLocationCodeContext;
import onevz.soe.cart.model.salesRepAndLocationCode.SalesRepAndLocationCodeServiceBody;
import onevz.soe.cart.model.salesRepAndLocationCode.SalesRepAndLocationCodeServiceRequest;
import onevz.soe.cart.model.updateE911Address.*;
import onevz.soe.cart.requests.*;
import onevz.soe.cart.responses.TechFlowRedisData;
import onevz.soe.cart.tys.reviewOrder.ReviewOrderContext;
import onevz.soe.cart.tys.reviewOrder.ReviewOrderPegaRequest;
import onevz.soe.cart.tys.reviewOrder.ReviewOrderServiceBody;
import onevz.soe.cart.tys.reviewOrder.ReviewOrderServiceRequest;
import onevz.soe.cart.ui.common.AddBuyoutData;
import onevz.soe.cart.ui.common.CartInfo;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.orderprocess.model.checkoutdetails.AffirmFinancingOfferInfo;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.bpm.model.Context;
import onevz.soe.wsclient.bpm.model.CustomerInfo;
import onevz.soe.wsclient.bpm.model.ServiceBody;
import onevz.soe.wsclient.bpm.model.request.Add;
import onevz.soe.wsclient.bpm.model.request.ContextInfo;
import onevz.soe.wsclient.bpm.model.request.ServiceRequest;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.ObjectUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class CartPegaRequestUtil9 {
    private static final Logger logger = LoggerFactory.getLogger(CartPegaRequestUtil9.class);

    @Value("${enableCradleForExistingCustomer:true}")
    private static boolean enableCradleForExistingCustomer;
    /*
     * https://onejira.verizon.com/browse/VZWYN-20438
     */

    /**
     * Calculates and returns IMEI checksum based on the Luhn algorithm for data
     * integrity
     *
     * @param deviceId
     * @return
     */
    public static int calculateIMEIChecksum(String deviceId) {
        deviceId = deviceId.substring(0, 14);
        int checksum = 0;
        char[] deviceIdArray = deviceId.toCharArray();
        for (int i = 0; i < deviceIdArray.length; i++) {
            int num = deviceIdArray[i];
            switch (num) {// get decimal value of hex
                case 48:
                    num = 0;
                    break;
                case 49:
                    num = 1;
                    break;
                case 50:
                    num = 2;
                    break;
                case 51:
                    num = 3;
                    break;
                case 52:
                    num = 4;
                    break;
                case 53:
                    num = 5;
                    break;
                case 54:
                    num = 6;
                    break;
                case 55:
                    num = 7;
                    break;
                case 56:
                    num = 8;
                    break;
                case 57:
                    num = 9;
                    break;
            }
            if (i != 0 && i % 2 != 0) {
                // double every other digit in IMEI, then add the digits together.
                num = num * 2;
                num = num / 10 + num % 10;
                checksum += num;
            } else {
                checksum += num;
            }
        }
        checksum = checksum % 10;
        if (checksum > 0)
            checksum = 10 - checksum;

        return checksum;
    }

    /**
     * @param accountNumber
     * @param mtn
     * @channelId
     * @param pegaRequest
     * @return InitiateAddressChangePEGARequest
     */
    public static InitiateAddressChangePEGARequest formatInitiateAddressChangePEGARequest(String accountNumber, String mtn, String channelId,
                                                                                          InitiateAddressChangePEGARequest pegaRequest) {

        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(channelId);
        serviceHeader.setServiceName(CartConstants.PROFILE_UPDATE);
        serviceHeader.setCallReason(CartConstants.ACC_MGMT);
        serviceHeader.setUserId(CartConstants.FLOW_TYPE_NUMBERLINK1);
        serviceHeader.setTransactionPod(CartConstants.PROFILE);
        pegaRequest.setServiceHeader(serviceHeader);

        UpdateE911AddressServiceBody serviceBody = new UpdateE911AddressServiceBody();
        UpdateE911AddressServiceRequest serviceRequest = new UpdateE911AddressServiceRequest();
        UpdateAddressContext context = new UpdateAddressContext();
        UpdateE911AddressContextInfo contextInfo = new UpdateE911AddressContextInfo();

        UpdateE911AddressCustomerInfo customerInfo = new UpdateE911AddressCustomerInfo();
        customerInfo.setAccountNumber(accountNumber);
        customerInfo.setMtn(mtn);

        context.setCustomerInfo(customerInfo);

        contextInfo.setIntent(CartConstants.ADDRESS_CHANGE);
        contextInfo.setProcessAction(CartConstants.EDIT);

        context.setContextInfo(contextInfo);
        context.setCaseId("");

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);

        return pegaRequest;

    }

    /**
     * @param caseId
     * @param accountNumber
     * @param request
     * @param pegaRequest
     * @channelId
     * @return InitiateAddressChangePEGARequest
     */
    public static UpdateAddressChangePEGARequest formatUpdateAddressChangePEGARequest(String caseId, String accountNumber, String amRole,
                                                                                      RPSE911AddressUpdateUIRequest request, UpdateAddressChangePEGARequest pegaRequest) {

        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(request.getChannelId());
        serviceHeader.setServiceName(CartConstants.PROFILE_UPDATE);
        serviceHeader.setCallReason(CartConstants.ACC_MGMT);
        serviceHeader.setUserId(CartConstants.FLOW_TYPE_NUMBERLINK1);
        serviceHeader.setTransactionPod(CartConstants.PROFILE);
        pegaRequest.setServiceHeader(serviceHeader);

        UpdateE911AddressServiceBody serviceBody = new UpdateE911AddressServiceBody();
        UpdateE911AddressServiceRequest serviceRequest = new UpdateE911AddressServiceRequest();
        UpdateAddressContext context = new UpdateAddressContext();
        UpdateE911AddressContextInfo contextInfo = new UpdateE911AddressContextInfo();
        List<AccountUpdates> accountUpdates = new ArrayList<AccountUpdates>();
        AccountUpdates accountUpdate = new AccountUpdates();
        UpdateDetails updateDetails = new UpdateDetails();
        E911AddressUpdate e911AddressUpdate = new E911AddressUpdate();

        e911AddressUpdate.setAddressLine1(request.getAddressLine1());
        e911AddressUpdate.setAddressLine2(request.getAddressLine2());
        e911AddressUpdate.setCity(request.getCityName());
        e911AddressUpdate.setCityName(request.getCityName());
        e911AddressUpdate.setCountryCode(request.getCountryCode());
        e911AddressUpdate.setState(request.getState());
        e911AddressUpdate.setDeviceId(request.getDeviceId());
        e911AddressUpdate.setStreetName(request.getStreetName());
        e911AddressUpdate.setStreetNumber(request.getStreetNumber());
        e911AddressUpdate.setStreetType(request.getStreetType());
        e911AddressUpdate.setZipCode(request.getZipCode());
        e911AddressUpdate.setStreetDirection(StringUtilities.isNotEmptyOrNull(request.getStreetDirection())?request.getStreetDirection():"");
        e911AddressUpdate.setApartmentNo(StringUtilities.isNotEmptyOrNull(request.getApartmentNo())?request.getApartmentNo():"");

        updateDetails.setE911Address(e911AddressUpdate);
        if(request.getMtn()!=null) {
            updateDetails.setMtn(request.getMtn().get(0));
        }
        updateDetails.setFlowType(CartConstants.FLOW_TYPE_NUMBERLINK1);
        accountUpdate.setUpdateDetails(updateDetails);
        accountUpdate.setUpdateType(CartConstants.E911ADDRESSCHANGE);
        accountUpdates.add(accountUpdate);
        UpdateE911AddressCustomerInfo customerInfo = new UpdateE911AddressCustomerInfo();
        customerInfo.setAccountNumber(accountNumber);
        customerInfo.setAmRole(amRole);
        if(request.getMtn()!=null) {
            customerInfo.setMtn(request.getMtn().get(0));
        }
        if(StringUtilities.isNotEmptyOrNull(accountNumber)) {
            customerInfo.setCustomerId(accountNumber.split("-")[0]);
        }

        contextInfo.setIntent(CartConstants.E911ADDRESSCHANGE);
        contextInfo.setProcessAction(CartConstants.SAVE);
        contextInfo.setProcessStep(CartConstants.UPDATE_TRANSACTION);
        contextInfo.setCallReason(CartConstants.ACC_MGMT);

        context.setContextInfo(contextInfo);
        context.setCaseId(caseId);
        context.setCustomerInfo(customerInfo);
        context.setAccountUpdates(accountUpdates);

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);

        return pegaRequest;

    }
    public static AddPlanAndDevicePEGARequest formatCpcUpdateCartRequest(AddPlanAndDevicePEGARequest pegaRequest, TechFlowRedisData redisData) {
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        serviceHeader.setClientId(CartConstants.VZW_DOTCOM);
        serviceHeader.setServiceName(CartConstants.CPC);
        pegaRequest.setServiceHeader(serviceHeader);
        AddPlanAndDeviceServiceBody serviceBody = new AddPlanAndDeviceServiceBody();
        AddPlanAndDeviceServiceRequest serviceRequest = new AddPlanAndDeviceServiceRequest();
        AddPlanAndDeviceContext context=new AddPlanAndDeviceContext();

        onevz.soe.cart.model.common.FiveG.CartServiceContextInfo contextInfo = new onevz.soe.cart.model.common.FiveG.CartServiceContextInfo();
        contextInfo.setCallReason(CartConstants.CPC);
        contextInfo.setFlowInitiator(CartConstants.CPC_FLOW_INITIATOR);
        contextInfo.setTransactionType(CartConstants.CPC_TRANSACTION_TYPE);

        onevz.soe.cart.model.common.FiveG.CartServiceCustomerInfo customerInfo = new onevz.soe.cart.model.common.FiveG.CartServiceCustomerInfo();
        customerInfo.setCartCreator(redisData.getMtn());
        customerInfo.setAccountNumber(redisData.getAccountNumber());
        String custId = StringUtils.isNotBlank(redisData.getAccountNumber()) ? StringUtils.substringBefore(redisData.getAccountNumber(), "-") : "";
        customerInfo.setCustomerId(custId);
        FiveGMtnInfo mtnInfo = new FiveGMtnInfo();
        FiveGActiveMtnList activeMtnList = new FiveGActiveMtnList();
        List<FiveGActiveMTN> activeMtnLst = new ArrayList<>(1);
        FiveGActiveMTN activeMtn = new FiveGActiveMTN();
        activeMtn.setIsRecommendedPlan(true);
        activeMtn.setMtn(redisData.getMtn());
        activeMtn.setNewPlanId(redisData.getNewPlanId());
        activeMtn.setNetworkBandwidthType(CartConstants.NETWORK_TYPE_CBD);
        activeMtn.setOriginalOrderNumber(redisData.getVpmOrderNum());
        activeMtn.setOriginalLocationCode(redisData.getVpmLocationCode());
        activeMtn.setRecommender(CartConstants.RECOMMENDER_PEGA);
        activeMtn.setRecommendedPlan(true);
        activeMtn.setOrderType(redisData.getCpcOrderType());
        activeMtnLst.add(activeMtn);
        activeMtnList.setActiveMTN(activeMtnLst);
        mtnInfo.setActiveMTNList(activeMtnList);
        customerInfo.setFiveGMtnInfo(mtnInfo);

        context.setContextInfo(contextInfo);
        context.setCustomerInfo(customerInfo);
        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);

        return pegaRequest;
    }

    public static AddPlanAndDevicePEGARequest formatCpcSubmitPlanRequest(AddPlanAndDevicePEGARequest pegaRequest, TechFlowRedisData redisData) {
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        serviceHeader.setClientId(CartConstants.VZW_DOTCOM);
        serviceHeader.setServiceName(CartConstants.CPC);
        pegaRequest.setServiceHeader(serviceHeader);
        AddPlanAndDeviceServiceBody serviceBody = new AddPlanAndDeviceServiceBody();
        AddPlanAndDeviceServiceRequest serviceRequest = new AddPlanAndDeviceServiceRequest();
        AddPlanAndDeviceContext context=new AddPlanAndDeviceContext();

        onevz.soe.cart.model.common.FiveG.CartServiceContextInfo contextInfo = new onevz.soe.cart.model.common.FiveG.CartServiceContextInfo();
        contextInfo.setCallReason(CartConstants.CPC);
        contextInfo.setProcessStep(CartConstants.CPC_PROVISION_PLAN_PROCESSSTEP);

        onevz.soe.cart.model.common.FiveG.CartServiceCustomerInfo customerInfo = new onevz.soe.cart.model.common.FiveG.CartServiceCustomerInfo();
        customerInfo.setCartCreator(redisData.getMtn());
        customerInfo.setAccountNumber(redisData.getAccountNumber());
        customerInfo.setEmailSuppressIndicator("Y".equalsIgnoreCase(redisData.getBasicToBasicCpc()));
        List<FiveGMtnAndNetwork> mtnAndNetwork= new ArrayList<>();
        FiveGMtnAndNetwork mtnNetwork = new FiveGMtnAndNetwork();
        mtnNetwork.setMtn(redisData.getMtn());
        mtnNetwork.setNetworkBandwidthType(CartConstants.NETWORK_TYPE_CBD);
        mtnNetwork.setPrevNetworkBandwidthType(CartConstants.NETWORK_TYPE_MMW);
        mtnAndNetwork.add(mtnNetwork);
        customerInfo.setMtnAndNetwork(mtnAndNetwork);
        onevz.soe.cart.model.common.FiveG.CartServiceCartInfo cartInfo = new onevz.soe.cart.model.common.FiveG.CartServiceCartInfo();
        cartInfo.setCartId(redisData.getCartId());
        FiveGCustomerResponseInfo customerResponseInfo = new FiveGCustomerResponseInfo();
        FiveGCustResponseList custResponse = new FiveGCustResponseList();
        List<FiveGCustResponseList> custResponseList = new ArrayList<>();


        custResponse.setAccountLevel(false);
        custResponse.setMtn(redisData.getMtn());
        custResponse.setPageContext(CartConstants.CPC_PAGE_CONTEXT);
        List<FiveGDynamicStrList> dynamicStrList = new ArrayList<>();
        FiveGDynamicStrList strList = new FiveGDynamicStrList();
        strList.setStrId(CartConstants.CPC_PLAN_SUBMIT_STR_ID);
        strList.setValue(redisData.getNewPlanId());
        dynamicStrList.add(strList);
        custResponse.setDynamicStrList(dynamicStrList);
        custResponseList.add(custResponse);
        customerResponseInfo.setResponseList(custResponseList);
        context.setCustomerResponseInfo(customerResponseInfo);
        context.setCaseId(redisData.getCaseId());
        context.setContextInfo(contextInfo);
        context.setCustomerInfo(customerInfo);
        context.setCartInfo(cartInfo);
        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);

        return pegaRequest;
    }

    public static void formatCpcCartRequest(CpcFeatureRequest pegaRequest, CustomerInfo redisData, AddPlanAndDeviceUIRequest request) {
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        if(StringUtilities.isNotEmptyOrNull(request.getChannelId()))
            serviceHeader.setClientId(request.getChannelId());
        serviceHeader.setServiceName(CartConstants.CPC);
        //e2e id
        pegaRequest.setServiceHeader(serviceHeader);
        ServiceBody serviceBody = new ServiceBody();
        ServiceRequest serviceRequest = new ServiceRequest();
        Context context=new Context();

        onevz.soe.cart.model.common.FiveG.CartServiceContextInfo contextInfo = new onevz.soe.cart.model.common.FiveG.CartServiceContextInfo();
        contextInfo.setCallReason(CartConstants.CPC);
        contextInfo.setProcessStep("");

        CustomerInfo customerInfo = new CustomerInfo();
        customerInfo.setCartCreator(redisData.getCartCreator());
        customerInfo.setAccountNumber(redisData.getAccountNumber());

        context.setContextInfo(contextInfo);
        context.setCustomerInfo(customerInfo);
        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);

    }
    public static AddBuyoutUIRequest formatBuyoutUIRequest(AddDeviceUIRequest request){

        AddBuyoutUIRequest uiRequest = new AddBuyoutUIRequest();
        CartInfo cartInfo = new CartInfo();
        AddBuyoutData data = new AddBuyoutData();

        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessingMTN()))
            cartInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());

        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getBuyOutSelected())){
            cartInfo.setBuyOutFlag("Y");
            cartInfo.setBuyOutSelected("Y");
            cartInfo.setEdgeUpSelected("N");
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getMtnFlow()))
            cartInfo.setMtnFlow(request.getCartInfo().getMtnFlow());

        if(request.getCartInfo().getCustomerConsent() != null && request.getCartInfo().getCustomerConsent())
            cartInfo.setCustomerConsent("Y");

        if(request.getData() != null && request.getData().getLines() != null && request.getData().getLines().size() > 0){

            Lines[] lines =  new Lines[1];
            Lines buyOutLine = new Lines();
            if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessingMTN())) {
                buyOutLine.setMtn(request.getCartInfo().getProcessingMTN());
            }else{
                buyOutLine.setMtn(request.getData().getLines().get(0).getMtn());
            }

            lines[0] = buyOutLine;
            data.setLines(lines);
        }

        uiRequest.setCartInfo(cartInfo);
        uiRequest.setData(data);

        return uiRequest;

    }

    /**
     * added for CXTDT-309983
     * @param request
     * @return
     */
    public static boolean isXboxInClearCartRequest(ClearCartUIRequest request) {
        return null != request.getCartInfo()
                && CartConstants.SUBSCRIPTION_TYPE_GAMINGCONSOLE.equals(request.getCartInfo().getSubscriptionType())
                && CartConstants.PROCESS_STEP_DPP_SUMMARY.equals(request.getCartInfo().getProcessStep());
    }

    public static AffirmFinancingPegaRequest formatAffirmPegaRequest(AffirmFinancingUIRequest uiRequest,
                                                                     AffirmFinancingPegaRequest pegaRequest) {

        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader);
        if (StringUtilities.isNotEmptyOrNull(uiRequest.getChannelId())) {
            serviceHeader.setClientId(uiRequest.getChannelId());
        }

        pegaRequest.setServiceHeader(serviceHeader);

        AffirmFinancingServiceBody serviceBody = new AffirmFinancingServiceBody();
        AffirmFinancingServiceRequest serviceRequest = new AffirmFinancingServiceRequest();
        AffirmFinancingServiceContext context = new AffirmFinancingServiceContext();

        onevz.soe.cart.model.common.CartServiceCustomerInfo customerInfo = new onevz.soe.cart.model.common.CartServiceCustomerInfo();
        if(StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getAccountNumber())) {
            customerInfo.setAccountNumber(uiRequest.getCartInfo().getAccountNumber());
        }
        if(StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getCartCreator())) {
            customerInfo.setCartCreator(uiRequest.getCartInfo().getCartCreator());
        }
        if(StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getProcessingMTN())) {
            customerInfo.setProcessingMTN(uiRequest.getCartInfo().getProcessingMTN());
        }


        onevz.soe.cart.model.common.CartServiceCartInfo cartInfo = new onevz.soe.cart.model.common.CartServiceCartInfo();
        if(StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getCartId())) {
            cartInfo.setCartId(uiRequest.getCartInfo().getCartId());
        }
        cartInfo.setItemType(CartConstants.AFFIRM_FINANCING_OFFER_INFO);
        if(StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getIntendType())) {
            cartInfo.setIntendType(uiRequest.getCartInfo().getIntendType());
        }
        if(StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getAction())) {
            cartInfo.setAction(uiRequest.getCartInfo().getAction());
        }

        AffirmFinancingOfferInfo affirmInfo = new AffirmFinancingOfferInfo();
        affirmInfo.setOfferRejected(uiRequest.isOfferRejected());
        affirmInfo.setOfferAccepted(uiRequest.isOfferAccepted());
        cartInfo.setAffirmFinancingOfferInfo(affirmInfo);

        onevz.soe.cart.model.common.CartServiceContextInfo contextInfo = new onevz.soe.cart.model.common.CartServiceContextInfo();
        contextInfo.setCallReason(CartConstants.SALES_ORDER_PURCHASE);
        if(StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getProcessStep())) {
            contextInfo.setProcessStep(uiRequest.getCartInfo().getProcessStep());
        }
        if(StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getProcessAction())) {
            contextInfo.setProcessAction(uiRequest.getCartInfo().getProcessAction());
        }
        if(StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getIntent())) {
            contextInfo.setIntent(uiRequest.getCartInfo().getIntent());
        }

        if(StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getCaseId())) {
            context.setCaseId(uiRequest.getCartInfo().getCaseId());
        }

        context.setCustomerInfo(customerInfo);
        context.setCartInfo(cartInfo);
        context.setContextInfo(contextInfo);
        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);
        return pegaRequest;
    }

    public static AddReplenishmentToCartPEGARequest formatAddReplenishmentRequest(AddReplenishmentToCartUIRequest uiRequest, AddReplenishmentToCartPEGARequest pegaRequest) {
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(uiRequest.getChannelId());
        serviceHeader.setServiceName(CartConstants.SALES_ORDER_FLEX);
        pegaRequest.setServiceHeader(serviceHeader);

        AddReplenishMentServiceBody serviceBody = new AddReplenishMentServiceBody();

        AddReplenishMentServiceRequest serviceRequest = new AddReplenishMentServiceRequest();

        AddReplenishMentContext context = new AddReplenishMentContext();

        onevz.soe.cart.model.common.CartServiceContextInfo contextInfo = new onevz.soe.cart.model.common.CartServiceContextInfo();
        contextInfo.setCallReason(CartConstants.SALES_ORDER_FLEX);

        contextInfo.setIntent("NSE");
        contextInfo.setSkipCheckoutCall(false);
        onevz.soe.cart.model.common.CartServiceCustomerInfo customerInfo = new onevz.soe.cart.model.common.CartServiceCustomerInfo();
        customerInfo.setAccountNumber(uiRequest.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(uiRequest.getCartInfo().getCartCreator());
        customerInfo.setCustomerType(uiRequest.getCartInfo().getCustomerType());
        customerInfo.setProcessingMTN(uiRequest.getCartInfo().getProcessingMTN());
        customerInfo.setRegisterNumber(0);
        context.setCustomerInfo(customerInfo);

        onevz.soe.cart.model.common.CartServiceCartInfo cartInfo = new onevz.soe.cart.model.common.CartServiceCartInfo();
        cartInfo.setCartId(uiRequest.getCartInfo().getCartId());
        if(!StringUtilities.isEmptyOrNull(uiRequest.getCartInfo().getProcessStep()) &&	uiRequest.getCartInfo().getProcessStep().equalsIgnoreCase("removeReplenishment"))
        {
            contextInfo.setProcessStep("AddReplenishment");
            contextInfo.setProcessAction("removeReplenishment");
            cartInfo.setAction(CartConstants.REMOVE);
        }
        if(!StringUtilities.isEmptyOrNull(uiRequest.getCartInfo().getProcessStep()) &&	uiRequest.getCartInfo().getProcessStep().equalsIgnoreCase("addReplenishment"))
        {
            contextInfo.setProcessStep("AddReplenishment");
            contextInfo.setProcessAction("addReplenishment");
            cartInfo.setAction(CartConstants.ADD);
        }
        cartInfo.setItemType(CartConstants.REPLENISHMENT);
        if (!StringUtilities.isEmptyOrNull(uiRequest.getCartInfo().getIntendType()))
            cartInfo.setIntendType(uiRequest.getCartInfo().getIntendType());
        else
            cartInfo.setIntendType(CartConstants.AAL);
        if(null!=uiRequest.getCartInfo() && null!=uiRequest.getCartInfo().getCartId())
            cartInfo.setCartId(uiRequest.getCartInfo().getCartId());

        cartInfo.setItemType(CartConstants.REPLENISHMENT);
        context.setCartInfo(cartInfo);

        if (!StringUtilities.isEmptyOrNull(uiRequest.getCartInfo().getIntendType()))
        {
            if((CartConstants.NSE).equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())){
                contextInfo.setIntent(CartConstants.NSE);
            }
            else if((CartConstants.NSE_5G).equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())){
                contextInfo.setIntent(CartConstants.NSE_5G);
            }
            else if((CartConstants.AAL_5G).equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())){
                contextInfo.setIntent(CartConstants.AAL_5G);
            }
            else if((CartConstants.NSE_LTE).equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())){
                contextInfo.setIntent(CartConstants.NSE_LTE);
            }
            else if((CartConstants.AAL_LTE).equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())){
                contextInfo.setIntent(CartConstants.AAL_LTE);
            }
            else if((CartConstants.AAL).equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())){
                contextInfo.setIntent(CartConstants.AAL);
            }
            else if((CartConstants.BYOD).equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())){
                contextInfo.setIntent(CartConstants.BYOD);
            }
        }
        else
            contextInfo.setIntent(CartConstants.AAL);

        if (!StringUtilities.isEmptyOrNull(uiRequest.getCartInfo().getProcessAction())) {
            contextInfo.setProcessAction(uiRequest.getCartInfo().getProcessAction());
        }
        context.setContextInfo(contextInfo);

        List<onevz.soe.cart.model.common.Line> lines = new ArrayList<>();
        for (Lines reqLine : uiRequest.getData().getLines()) {
            onevz.soe.cart.model.common.Line newLine = new onevz.soe.cart.model.common.Line();
            newLine.setMtn(reqLine.getMtn());
            if(StringUtilities.isNotEmptyOrNull(reqLine.getReplenishmentAmount()))
                newLine.setReplenishmentAmount(reqLine.getReplenishmentAmount());
            newLine.setIsActivateWithoutReplenish(reqLine.getIsActivateWithoutReplenish());
            lines.add(newLine);
        }
        onevz.soe.cart.model.common.Line[] lineArr = new onevz.soe.cart.model.common.Line[lines.size()];
        lines.toArray(lineArr);
        cartInfo.setLines(lineArr);
        context.setCaseId(uiRequest.getCartInfo().getCaseId());
        context.setCartInfo(cartInfo);
        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);
        return pegaRequest;

    }

    /**
     * @param pegaRequest
     * @param request
     * @return ReviewOrderPegaRequest
     */
    public static ReviewOrderPegaRequest formatOrderReviewRequest(ReviewOrderPegaRequest pegaRequest,
                                                                  ReviewOrderTYSUIRequest request) {

        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader);

        if(request.getCartInfo() !=null&& request.getCartInfo().getLineActivityType() !=null
                &&  request.getCartInfo().getLineActivityType().equalsIgnoreCase("TSE")) {
            serviceHeader.setServiceName(CartConstants.TYS_UPDATE);
        }

        serviceHeader.setClientId(request.getChannelId());

        pegaRequest.setServiceHeader(serviceHeader);

        ReviewOrderServiceBody serviceBody = new ReviewOrderServiceBody();
        ReviewOrderServiceRequest serviceRequest = new ReviewOrderServiceRequest();
        ReviewOrderContext context = new ReviewOrderContext();

        onevz.soe.cart.model.common.CartServiceCustomerInfo customerInfo = new onevz.soe.cart.model.common.CartServiceCustomerInfo();
        customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
        customerInfo.setMtn(request.getCartInfo().getCartCreator());
        customerInfo.setCustomerId(request.getCustomerId());
        customerInfo.setUserRole(request.getCartInfo().getUserRole());

        onevz.soe.cart.model.common.CartServiceContextInfo contextInfo = new onevz.soe.cart.model.common.CartServiceContextInfo();
        CartPegaRequestUtil2.addContextInfoReviewOrderTYS(contextInfo);

        context.setCustomerInfo(customerInfo);

        onevz.soe.cart.model.common.CartServiceCartInfo cartInfo = new onevz.soe.cart.model.common.CartServiceCartInfo();
        cartInfo.setCartId(request.getCartInfo().getCartId());
        cartInfo.setClientAppName(request.getCartInfo().getClientAppName());
        cartInfo.setIntendType("TSE");
        cartInfo.setCartCreator(request.getCartInfo().getCartCreator());

        context.setCartInfo(cartInfo);

        context.setCaseId(request.getCartInfo().getCaseId());

        context.setContextInfo(contextInfo);
        
        context.setIsRetrieveInstallmentRequired("true");

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);

        return pegaRequest;
    }

    /**
     * @param pegaRequest
     * @param request
     * @return SalesRepAndLocationCodePEGARequest
     */
    public static SalesRepAndLocationCodePEGARequest formatUpdateSalesRepAndLocationCodeRequest(
            SalesRepAndLocationCodePEGARequest pegaRequest, SalesRepAndLocationCodeUIRequest request) {

        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(request.getChannelId());

        SalesRepAndLocationCodeServiceBody serviceBody = new SalesRepAndLocationCodeServiceBody();
        SalesRepAndLocationCodeServiceRequest serviceRequest = new SalesRepAndLocationCodeServiceRequest();

        SalesRepAndLocationCodeContext context = new SalesRepAndLocationCodeContext();

        onevz.soe.cart.model.common.CartServiceCustomerInfo customerInfo = new onevz.soe.cart.model.common.CartServiceCustomerInfo();
        customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(request.getCartInfo().getCartCreator());

        onevz.soe.cart.model.common.CartServiceCartInfo cartInfo = new onevz.soe.cart.model.common.CartServiceCartInfo();
        cartInfo.setCartId(request.getCartInfo().getCartId());
        cartInfo.setItemType(CartConstants.SALES_REP_AND_LOCATION_CODE);
        if (CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())
                || CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType()))
            cartInfo.setIntendType(request.getCartInfo().getIntendType());
        else
            cartInfo.setIntendType(CartConstants.AAL);
        cartInfo.setAction(CartConstants.UPDATE);
        if (!StringUtilities.isEmptyOrNull(request.getData().getOrderLocationCode()))
            cartInfo.setOrderLocationCode(request.getData().getOrderLocationCode());
        if (!StringUtilities.isEmptyOrNull(request.getData().getSalesRepId()))
            cartInfo.setSalesRepId(request.getData().getSalesRepId());

        cartInfo.setRegisterNumber(request.getData().getRegisterNumber());

        onevz.soe.cart.model.common.CartServiceContextInfo contextInfo = new onevz.soe.cart.model.common.CartServiceContextInfo();
        CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.UPDATE_SALES_REP,
                request.getCartInfo().getClientAppName());

        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessStep()))
            contextInfo.setProcessStep(request.getCartInfo().getProcessStep());

        if (CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())
                || CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
            CartPegaRequestUtil7.newCustomerOverride(contextInfo, customerInfo, request.getCartInfo(), request.getChannelId());
        }

        //VZWDRE-652
        if (CartConstants.REX.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_ADJUSTMENT);
            cartInfo.setIntendType(CartConstants.REX);
            contextInfo.setCallReason(CartConstants.SALES_ORDER_ADJUSTMENT);
            contextInfo.setIntent(CartConstants.REX);
        }
        
        context.setCaseId(request.getCartInfo().getCaseId());
        context.setCartInfo(cartInfo);
        context.setCustomerInfo(customerInfo);

        //MVP2
        if(request.getCartInfo()!=null && request.getCartInfo().getCaseId()!=null && request.getCartInfo().getCaseId().startsWith("SOF")){

            logger.info("SalesOrderFlex Prepay update salesRep and location code  Request before PEGA call setting Call Reason");
            contextInfo.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_FLEX);
            if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()) &&
                    CartConstants.AAL.equalsIgnoreCase(request.getCartInfo().getIntendType())
                    || CartConstants.BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())){

                contextInfo.setIntent(request.getCartInfo().getIntendType());
                cartInfo.setIntendType(request.getCartInfo().getIntendType());

            }
        }

        context.setContextInfo(contextInfo);

        serviceBody.setServiceRequest(serviceRequest);
        serviceRequest.setContext(context);

        pegaRequest.setServiceBody(serviceBody);
        pegaRequest.setServiceHeader(serviceHeader);

        return pegaRequest;
    }

    /**
     * @param pegaRequest
     * @param request
     * @return UpdateEdgeupPEGARequest
     */
    public static UpdateEdgeupPEGARequest formatUpdateEdgeupRequest(UpdateEdgeupPEGARequest pegaRequest,
                                                                    UpdateEdgeupUIRequest request) {

        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(request.getChannelId());
        pegaRequest.setServiceHeader(serviceHeader);

        UpdateEdgeupServiceBody serviceBody = new UpdateEdgeupServiceBody();
        UpdateEdgeupContext context = new UpdateEdgeupContext();
        UpdateEdgeupServiceRequest serviceRequest = new UpdateEdgeupServiceRequest();

        onevz.soe.cart.model.common.CartServiceCustomerInfo customerInfo = new onevz.soe.cart.model.common.CartServiceCustomerInfo();
        customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        customerInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());
        customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
        customerInfo.setBuyOutFlag(request.getCartInfo().getBuyOutFlag());
        customerInfo.setBuyOutSelected(request.getCartInfo().getBuyOutSelected());
        customerInfo.setEdgeUpSelected(request.getCartInfo().getEdgeUpSelected());
        customerInfo.setFmiTurnedOff(request.getCartInfo().getFmiTurnedOff());
        customerInfo.setDeviceMisMatched(request.getCartInfo().getDeviceMisMatched());
        customerInfo.setEstTradeInValue(request.getCartInfo().getEstTradeInValue());
        if (request.getCartInfo().getMtnFlow() != null)
            customerInfo.setMtnFlow(request.getCartInfo().getMtnFlow());
        if (StringUtilities.isNotEmptyOrNull(request.getData().getRecommDevId()))
            customerInfo.setRecommDevId(request.getData().getRecommDevId());
        if (StringUtilities.isNotEmptyOrNull(request.getData().getRecommSkuId()))
            customerInfo.setRecommSkuId(request.getData().getRecommSkuId());
        if (null != request.getData().getMtnSOIRecommendation())
            customerInfo.setMtnSOIRecommendation(request.getData().getMtnSOIRecommendation());
        context.setCustomerInfo(customerInfo);

        onevz.soe.cart.model.common.CartServiceCartInfo cartInfo = new onevz.soe.cart.model.common.CartServiceCartInfo();
        cartInfo.setAction(CartConstants.UPDATE);
        cartInfo.setCartId(request.getCartInfo().getCartId());
        cartInfo.setItemType("EDGEUP");
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()))
            cartInfo.setIntendType(request.getCartInfo().getIntendType());
        else
            cartInfo.setIntendType(CartConstants.EUP);
        List<onevz.soe.cart.model.common.Line> lines = new ArrayList<>();
        for (Lines reqLine : request.getData().getLines()) {
            onevz.soe.cart.model.common.Line newLine = new onevz.soe.cart.model.common.Line();
            newLine.setMtn(reqLine.getMtn());
            newLine.setEdgeup(new EdgeUp());
            if (StringUtilities.isNotEmptyOrNull(reqLine.getEdgeup().getDeviceId()))
                newLine.getEdgeup().setDeviceId(reqLine.getEdgeup().getDeviceId());
            if (StringUtilities.isNotEmptyOrNull(reqLine.getEdgeup().getDeviceMismatch()))
                newLine.getEdgeup().setDeviceMismatch(reqLine.getEdgeup().getDeviceMismatch());
            if (StringUtilities.isNotEmptyOrNull(reqLine.getUpgradeReasonCode()))
                newLine.setUpgradeReasonCode(reqLine.getUpgradeReasonCode());
            lines.add(newLine);
        }
        onevz.soe.cart.model.common.Line[] lineArr = new onevz.soe.cart.model.common.Line[lines.size()];
        lines.toArray(lineArr);

        if (StringUtilities.isNotEmptyOrNull(request.getData().getUpgradeReasonCode())) {
            cartInfo.setUpgradeReasonCode(request.getData().getUpgradeReasonCode());
        }

        cartInfo.setLines(lineArr);

        cartInfo.setEffectiveDate(request.getData().getEffectiveDate());
        context.setCartInfo(cartInfo);
        context.setCaseId(request.getCartInfo().getCaseId());

        onevz.soe.cart.model.common.CartServiceContextInfo contextInfo = new onevz.soe.cart.model.common.CartServiceContextInfo();
        CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.ADD_EDGEUP_AMT,
                request.getCartInfo().getClientAppName());
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessStep())) {
            contextInfo.setProcessStep(request.getCartInfo().getProcessStep());
        } else {
            contextInfo.setProcessStep(CartConstants.SHOPPING_CART);
        }
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessAction()))
            contextInfo.setProcessAction(request.getCartInfo().getProcessAction());

        if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))){
            contextInfo.setProcessAction("");
        }
        context.setContextInfo(contextInfo);

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);
        return pegaRequest;
    }

    public static AddDevicePEGARequest formatAddUpgradeDetailsRequest(AddDevicePEGARequest pegaRequest,
                                                                      AddDeviceUIRequest request, Boolean trade3POChoiceFlag, Boolean bauUpgradePdpTradeInFFlag) {

        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        serviceHeader = CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(request.getChannelId());
        pegaRequest.setServiceHeader(serviceHeader);

        AddDeviceServiceBody serviceBody = new AddDeviceServiceBody();
        AddDeviceServiceRequest serviceRequest = new AddDeviceServiceRequest();
        AddDeviceContext context = new AddDeviceContext();
        List<AddPromoIntent> addPromoIntent= new ArrayList<>();

        //Mapping Context Info
        onevz.soe.cart.model.common.CartServiceContextInfo contextInfo = new onevz.soe.cart.model.common.CartServiceContextInfo();
        String processAction = StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessAction()) ? request.getCartInfo().getProcessAction() : "ExpressUpgrade";
        contextInfo = CartPegaRequestUtil.addContextInfo(contextInfo, processAction , request.getCartInfo().getClientAppName());
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessStep())) {
            contextInfo.setProcessStep(request.getCartInfo().getProcessStep());
        } else {
            contextInfo.setProcessStep(CartConstants.GRIDWALLPDP);
        }
        contextInfo.setSkipCheckoutCall(false);

        //Mapping Customer Info
        onevz.soe.cart.model.common.CartServiceCustomerInfo customerInfo = new onevz.soe.cart.model.common.CartServiceCustomerInfo();
        customerInfo = formatAddUpgradeDetailRequestMapCustomerInfo(request, customerInfo);

        //Mapping Cart Info
        onevz.soe.cart.model.common.CartServiceCartInfo cartInfo = new onevz.soe.cart.model.common.CartServiceCartInfo();
        cartInfo = formatAddUpgradeDetailRequestMapCartInfo(request, cartInfo, bauUpgradePdpTradeInFFlag, contextInfo);

        //Map Lines Info inside the CartInfo
        List<onevz.soe.cart.model.common.Line> lines = new ArrayList<>();

        for (Lines reqLine : request.getData().getLines()) {
            onevz.soe.cart.model.common.Line newLine = new onevz.soe.cart.model.common.Line();

            if(reqLine.getExpressUpgradeFeatures()!=null ) {
                setFeatures(reqLine, newLine);
            }

            if(StringUtilities.isNotEmptyOrNull(reqLine.getTradeInShippingType())){
                cartInfo.setTradeInShippingType(reqLine.getTradeInShippingType());
            }

            if(reqLine.getPlan() != null && StringUtilities.isNotEmptyOrNull(reqLine.getPlan().getId())){
                newLine.setPlan(reqLine.getPlan());
            }
            if(reqLine.getEdgeup() != null){
                newLine.setEdgeup(reqLine.getEdgeup());
            }

            if (StringUtilities.isNotEmptyOrNull(reqLine.getMtn())) {
                newLine.setMtn(reqLine.getMtn());
            } else if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessingMTN())){
                newLine.setMtn(request.getCartInfo().getProcessingMTN());
            } else if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCartCreator())){
                newLine.setMtn(request.getCartInfo().getCartCreator());
            }
            //ONEAPP-9763
            if(Boolean.TRUE.equals(reqLine.getIsEdgeBuyOut())) {
            	logger.info("Setting IsEdgeBuyOut inside newLine to BPM, value is  :: {}", reqLine.getIsEdgeBuyOut());
            	 newLine.setIsEdgeBuyOut(reqLine.getIsEdgeBuyOut());
            }

            //ONEAPP-11967
            if (Boolean.TRUE.equals(trade3POChoiceFlag) && CollectionUtilities.isNotEmptyOrNull(reqLine.getPromoIntent())) {
                reqLine.getPromoIntent()
                        .stream()
                        .filter(Objects::nonNull)
                        .forEach(promo -> {
                            AddPromoIntent promoIntent = new AddPromoIntent();
                            promoIntent.setPromotionId(promo.getPromotionId());
                            promoIntent.setOfferId(promo.getOfferId());
                            promoIntent.setPromoType(promo.getPromoType());
                            promoIntent.setChoiceOffer(promo.getChoiceOffer());
                            addPromoIntent.add(promoIntent);
                        });
                AddPromoIntent[] promoArr = new AddPromoIntent[addPromoIntent.size()];
                newLine.setPromoIntent(addPromoIntent.toArray(promoArr));
            }
            //newLine.setCurrentDeviceId(""); //TODO
            if (reqLine.getIsTradeInIntentSelected() != null && Boolean.TRUE.equals(reqLine.getIsTradeInIntentSelected())) {
                newLine.setIsTradeInIntentSelected(true);
            } else {
                newLine.setIsTradeInIntentSelected(false);
            }
            if(StringUtilities.isNotEmptyOrNull(reqLine.getSelectedSedOfferId())){
                newLine.setSelectedSedOfferId(reqLine.getSelectedSedOfferId());
            }
            if(StringUtilities.isNotEmptyOrNull(reqLine.getSelectedPromoId())){
                newLine.setSelectedPromoId(reqLine.getSelectedPromoId());
            }
            if (reqLine.isLineWithSkipMDN()){
                newLine.setLineWithSkipMDN(true);
            } else {
                newLine.setLineWithSkipMDN(false);
            }
            if(reqLine.getIspuFlow() != null && reqLine.getIspuFlow()){
                newLine.setIspuFlow(true);
            } else {
                newLine.setIspuFlow(false);
            }
            if(StringUtilities.isNotEmptyOrNull(reqLine.getSelectedPromoType())){
                newLine.setSelectedPromoType(reqLine.getSelectedPromoType());
            }
            if (null == reqLine.getQaIconicTesting() || !reqLine.getQaIconicTesting())
                newLine.setQaIconicTesting(false);
            else
                newLine.setQaIconicTesting(true);
            if (reqLine.getIsStrategicOffer() != null) {
                newLine.setIsStrategicOffer(reqLine.getIsStrategicOffer());
            }
            if (reqLine.getDepletionType() != null) {
                newLine.setDepletionType(reqLine.getDepletionType());
            }
            if (StringUtilities.isNotEmptyOrNull(reqLine.getPurchasePath())) {
                newLine.setPurchasePath(reqLine.getPurchasePath());
            }
            if(StringUtilities.isNotEmptyOrNull(reqLine.getEstimatedReadyByDate())) {
                newLine.setEstimatedReadyByDate(reqLine.getEstimatedReadyByDate());
            }
            if (reqLine.getSim() != null) {
                newLine.setSim(reqLine.getSim());
            }
            if(null!=reqLine.getIsKeepingExistingEqProtection()){
                newLine.setIsKeepingExistingEqProtection(reqLine.getIsKeepingExistingEqProtection());
            }
            if (CollectionUtilities.isNotEmptyOrNull(reqLine.getSelectedOffers())) {
                newLine.setSelectedOffers(reqLine.getSelectedOffers());
            }
            if(reqLine.getEditSim() != null && reqLine.getEditSim()){
                newLine.setEditSim(reqLine.getEditSim());
            } else {
                newLine.setEditSim(false);
            }
            newLine.setNewLineOrAAL(false);
            if(null!=reqLine.getTradeInInfo() && null!=reqLine.getTradeInInfo().getDeviceBrand() &&
                    null!=reqLine.getTradeInInfo().getDeviceModel()) {
                boolean isValidTradeInPromoReq = (CollectionUtilities.isNotEmptyOrNull(reqLine.getTradeInInfo().getAemOfferIds()) ||
                        (StringUtils.isNotBlank(reqLine.getTradeInInfo().getTradeinMarketingId())));
                if(isValidTradeInPromoReq) {
                    newLine.setTradeInInfo(reqLine.getTradeInInfo());
                }
            }
            if(reqLine.isEupNoPromoFlow()) {
                newLine.setEupNoPromoFlow(true);
            } else{
                newLine.setEupNoPromoFlow(false);
            }
            newLine.setSkipPromoChoiceOffer(reqLine.isSkipPromoChoiceOffer());

            newLine.setIsCommonPDP(true);

            if (reqLine.getDepletionLocationCode() != null) {
                newLine.setDepletionLocationCode(CartUtil.removeSpecialCharacters(reqLine.getDepletionLocationCode(), request.getChannelId()));
            } else {
                newLine.setDepletionLocationCode("");
            }
            if (reqLine.getRestricted() != null) {
                newLine.setRestricted(reqLine.getRestricted());
            }
            if(StringUtilities.isNotEmptyOrNull(reqLine.getRestrictedProductType())){
                newLine.setRestrictedProductType(reqLine.getRestrictedProductType());
            } else if(StringUtilities.isEmptyOrNull(newLine.getRestrictedProductType()) && StringUtilities.isNotEmptyOrNull(newLine.getRestricted())
                    && newLine.getRestricted().equalsIgnoreCase(CartConstants.Y)){
                newLine.setRestrictedProductType(CartConstants.EQP);
            }
            if (reqLine.isInWithVerizonOpted()) {
                newLine.setInWithVerizonOpted(CartConstants.TRUE);
            }
            if (reqLine.getPromoRejectionIndicator() != null) {
                newLine.setPromoRejectionIndicator(reqLine.getPromoRejectionIndicator());
            }
            if (reqLine.getDevice() != null) {
                newLine.setDevice(reqLine.getDevice());
                newLine.getDevice().setQty(1);
            }

            if(reqLine.getIsTradeInIntentSelected() != null && reqLine.getIsTradeInIntentSelected()) {
                List<TradeInItem> tradeInItemList = new ArrayList<TradeInItem>();
                TradeInItem tradeInItem = new TradeInItem();
                tradeInItem.setLineSeqNum("1");
                tradeInItem.setRecycleSeqNum("1");
                if (StringUtilities.isNotEmptyOrNull(reqLine.getMtn())) {
                    tradeInItem.setTradeDeviceMDN(reqLine.getMtn());
                } else if (StringUtilities.isNotEmptyOrNull(newLine.getMtn())) {
                    tradeInItem.setTradeDeviceMDN(newLine.getMtn());
                }
                if (StringUtilities.isNotEmptyOrNull(reqLine.getTradeDeviceId()) && StringUtilities.isNotEmptyOrNull(reqLine.getTradeRecycleDeviceSku())) {
                    tradeInItem.setDeviceId(reqLine.getTradeDeviceId());
                    tradeInItem.setRecycleDeviceSku(reqLine.getTradeRecycleDeviceSku());
                    tradeInItem.setTradeDeviceMDN(null);
                }
                tradeInItem.setEquipCarrier(CartConstants.EQUIP_CARRIER);
                tradeInItem.setDeviceCondition(CartConstants.DEVICE_CONDITION);

                TriageInfo triageInfo = new TriageInfo();
                triageInfo.setTriageCount("4");

                Triage triage0 = new Triage();
                triage0.setTriageAnswer(CartConstants.TRIAGE_ANSWER);
                triage0.setTriageQuestionId(CartConstants.TRIAGE_QUES_IND_1);
                triage0.setQuestionText(CartConstants.QUESTION_TEXT_1);

                Triage triage1 = new Triage();
                triage1.setTriageAnswer(CartConstants.TRIAGE_ANSWER);
                triage1.setTriageQuestionId(CartConstants.TRIAGE_QUES_IND_2);
                triage1.setQuestionText(CartConstants.QUESTION_TEXT_2);

                Triage triage2 = new Triage();
                triage2.setTriageAnswer(CartConstants.TRIAGE_ANSWER);
                triage2.setTriageQuestionId(CartConstants.TRIAGE_QUES_IND_5);
                triage2.setQuestionText(CartConstants.QUESTION_TEXT_5);

                if (reqLine.getIsBatteryDamaged() != null && reqLine.getIsBatteryDamaged()) {
                    tradeInItem.setDeviceCondition(CartConstants.DEVICE_CONDITION_BAD);
                    triage2.setTriageAnswer(CartConstants.TRIAGE_ANSWER_NO);

                }

                Triage triage3 = new Triage();
                triage3.setTriageAnswer(CartConstants.TRIAGE_ANSWER);
                triage3.setTriageQuestionId(CartConstants.TRIAGE_QUES_IND_7);
                triage3.setQuestionText(CartConstants.QUESTION_TEXT_7);

                Triage[] triages = new Triage[4];
                triages[0] = triage0;
                triages[1] = triage1;
                triages[2] = triage2;
                triages[3] = triage3;
                triageInfo.setTriage(triages);
                tradeInItem.setTriageInfo(triageInfo);
                tradeInItemList.add(tradeInItem);
                newLine.setTradeInItems(tradeInItemList);

                cartInfo.setTradeinShipType(CartConstants.TRADEIN_SHIP_TYPE);
            }

            if(reqLine.getSecondNumber() != null) {
                newLine.setSecondNumber(reqLine.getSecondNumber());
            }
            lines.add(newLine);
        }
        onevz.soe.cart.model.common.Line[] lineArr = new onevz.soe.cart.model.common.Line[lines.size()];
        lines.toArray(lineArr);
        cartInfo.setLines(lineArr);
        context.setCustomerInfo(customerInfo);
        context.setContextInfo(contextInfo);
        context.setCartInfo(cartInfo);
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCaseId())) {
            context.setCaseId(request.getCartInfo().getCaseId());
        }
        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);
        return pegaRequest;
    }

    private static void setFeatures(Lines reqLine, Line newLine) {
        FeatureAction featureAction = new FeatureAction();
        List<Feature> add = new ArrayList<>();
        for(Add addFeatures: reqLine.getExpressUpgradeFeatures().getAdd()) {
            Feature feature = new Feature();
            feature.setQuantity(Integer.parseInt(addFeatures.getQuantity()));
            feature.setActionIndicator(addFeatures.getActionIndicator());
            feature.setId(addFeatures.getId());
            feature.setType(addFeatures.getType());
            add.add(feature);
        }
        featureAction.setAdd(add);
        newLine.setFeatures(featureAction);

    }

    public static UpdateAccountOwnerPEGARequest formatUpdateAccountOwnerPegaRequest(UpdateAccountOwnerUIRequest request,String channelId){
        UpdateAccountOwnerPEGARequest updateAccountOwnerPEGARequest = new UpdateAccountOwnerPEGARequest();
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        serviceHeader = CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(channelId);
        updateAccountOwnerPEGARequest.setServiceHeader(serviceHeader);
        UpdateAccountOwnerPEGARequest.UpdateAccountOwnerServiceBody serviceBody = new UpdateAccountOwnerPEGARequest.UpdateAccountOwnerServiceBody();
        UpdateAccountOwnerPEGARequest.UpdateAccountOwnerServiceRequest serviceRequest = new UpdateAccountOwnerPEGARequest.UpdateAccountOwnerServiceRequest();
        UpdateAccountOwnerPEGARequest.UpdateAccountOwnerContext context = new UpdateAccountOwnerPEGARequest.UpdateAccountOwnerContext();
        UpdateAccountOwnerPEGARequest.UpdateAccountOwnerCustomerInfo customerInfo = new UpdateAccountOwnerPEGARequest.UpdateAccountOwnerCustomerInfo();
        UpdateAccountOwnerPEGARequest.UpdateAccountOwnerCartInfo cartInfo = new UpdateAccountOwnerPEGARequest.UpdateAccountOwnerCartInfo();
        ContextInfo contextInfo = new ContextInfo();
        context.setCaseId(request.getCartInfo().getCaseId());
        customerInfo.setAccountNumber("");
        customerInfo.setCartCreator(request.getCartInfo().getCreditAppNum());
        customerInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());
        customerInfo.setCustomerType(CartConstants.NEW_CUSTOMER);
        customerInfo.setOriginalCreditApprovalNumber(request.getCartInfo().getCreditAppNum());
        cartInfo.setCartId(request.getCartInfo().getCartId());
        cartInfo.setIntendType(request.getCartInfo().getIntendType());
        cartInfo.setItemType(CartConstants.USERINFO);
        cartInfo.setAction(CartConstants.UPDATE);
        cartInfo.setLines(request.getData().getLines());
        contextInfo.setCallReason(CartConstants.SALES_ORDER_PURCHASE);
        contextInfo.setIntent(request.getCartInfo().getIntendType());
        contextInfo.setProcessStep(CartConstants.INTERIM_PAGE);
        contextInfo.setProcessAction(CartConstants.UPDATE_USER_INFO);
        context.setCartInfo(cartInfo);
        context.setCustomerInfo(customerInfo);
        context.setContextInfo(contextInfo);
        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        updateAccountOwnerPEGARequest.setServiceBody(serviceBody);
        return updateAccountOwnerPEGARequest;
    }
    private static onevz.soe.cart.model.common.CartServiceCustomerInfo formatAddUpgradeDetailRequestMapCustomerInfo(  AddDeviceUIRequest request, onevz.soe.cart.model.common.CartServiceCustomerInfo customerInfo){
        customerInfo.setThrottleName("");  //Default Value
        customerInfo.setBucketAllocator("");  //Default Value
        customerInfo.setENineAddrIndicator(Boolean.FALSE.toString());  //Default Value
        customerInfo.setEditDevice(false);  //Default Value
        customerInfo.setRegisterNumber(0);  //Default Value
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getAccountNumber())) {
            customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        }
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCartCreator())) {
            customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
        }
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessingMTN())) {
            customerInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());
        } else if (StringUtilities.isNotEmptyOrNull(customerInfo.getCartCreator())) {
            customerInfo.setProcessingMTN(customerInfo.getCartCreator());
        }
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getMtnFlow())) {
            customerInfo.setMtnFlow(request.getCartInfo().getMtnFlow());
        }

        //ONEAPP-9763 changes
        if(!ObjectUtils.isEmpty(request.getCartInfo().getBuyOutFlag())) {
            logger.info("Setting BuyOutFlag inside customer info, value is  :: {}", request.getCartInfo().getBuyOutFlag());
            customerInfo.setBuyOutFlag(request.getCartInfo().getBuyOutFlag());
        }

        if(request.getCartInfo().getIsTradeInSelected() != null && request.getCartInfo().getIsTradeInSelected()){
            customerInfo.setIsTradeInSelected(true);
        } else if(request.getData() != null && request.getData().getLines() != null && CollectionUtilities.isNotEmptyOrNull(request.getData().getLines())
                && request.getData().getLines().get(0) != null && request.getData().getLines().get(0).getIsTradeInIntentSelected() != null
                && request.getData().getLines().get(0).getIsTradeInIntentSelected().equals(Boolean.TRUE)) {
            customerInfo.setIsTradeInSelected(true);
        } else {
            customerInfo.setIsTradeInSelected(false);
        }
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getAmRole())) {
            customerInfo.setAmRole(request.getCartInfo().getAmRole());
        }
        if (null != request.getData().getLines().get(0).getDevice()) {
            if (request.getData().getLines().get(0).getDevice().getProductId() != null)
                customerInfo.setProductId(request.getData().getLines().get(0).getDevice().getProductId());
            if (request.getData().getLines().get(0).getDevice().getCategory() != null)
                customerInfo.setCategoryName(request.getData().getLines().get(0).getDevice().getCategory());
        }
        if(request.getCartInfo().getIsPromoPDP() != null && request.getCartInfo().getIsPromoPDP()){
            customerInfo.setIsPromoPDP(true);
        } else {
            customerInfo.setIsPromoPDP(false);
        }
        if(request.getCartInfo().getNoPendingOfferExists() != null && request.getCartInfo().getNoPendingOfferExists()){
            customerInfo.setNoPendingOfferExists(true);
        } else {
            customerInfo.setNoPendingOfferExists(false);
        }
        customerInfo.setNoc(false); //Default Value
        customerInfo.setMyvPage(true); //Default Value
        if(StringUtilities.isNotEmptyOrNull(customerInfo.getBuyOutFlag()) && CartConstants.Y.equalsIgnoreCase(customerInfo.getBuyOutFlag())){
            customerInfo.setMyvPage(false);
        }
        setAmNextGenEnabled(request, customerInfo);
        return customerInfo;
    }

    private static onevz.soe.cart.model.common.CartServiceCartInfo formatAddUpgradeDetailRequestMapCartInfo(AddDeviceUIRequest request, onevz.soe.cart.model.common.CartServiceCartInfo cartInfo,
                                                                                                            Boolean bauUpgradePdpTradeInFFlag, onevz.soe.cart.model.common.CartServiceContextInfo contextInfo){

        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCartId())){
            cartInfo.setCartId(request.getCartInfo().getCartId());
        }
        if (StringUtilities.isEmptyOrNull(cartInfo.getClientAppName())) {
            cartInfo.setClientAppName(request.getChannelId());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessAction()) && request.getCartInfo().getProcessAction().equalsIgnoreCase(CartConstants.EXPRESS_UPGRADE)){
            cartInfo.setItemType(CartConstants.EUP_ITEM_TYPE);
        } else if(StringUtilities.isNotEmptyOrNull(contextInfo.getProcessAction()) && contextInfo.getProcessAction().equalsIgnoreCase(CartConstants.EXPRESS_UPGRADE)){
            cartInfo.setItemType(CartConstants.EUP_ITEM_TYPE);
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())){
            cartInfo.setIntendType(request.getCartInfo().getIntendType());
        }
        if (bauUpgradePdpTradeInFFlag && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessAction()) && request.getCartInfo().getProcessAction().equalsIgnoreCase(CartConstants.ADD_DEVICE_WITH_TRADE_IN)) {
            cartInfo.setItemType(CartConstants.EUP_ITEM_TYPE);
            if(request.getCartInfo().getSkipResumeCase() && StringUtilities.isEmptyOrNull(request.getCartInfo().getCaseId()) && StringUtilities.isEmptyOrNull(request.getCartInfo().getCartId())) {
                cartInfo.setSkipResumeCase(true);
            }
        }
        cartInfo.setAction(CartConstants.UPDATE); //Default Value
        cartInfo.setTriggerPricingValidation(true);
        cartInfo.setDiscountPromoTotal(0.0);    //Default Value
        cartInfo.setRegisterNumber(0);  //Default Value
        cartInfo.setFmiCheck(false);    //Default Value
        if (request.getCartInfo().getIsComboOrderAllowed() != null && request.getCartInfo().getIsComboOrderAllowed()) {
            cartInfo.setIsComboOrderAllowed(request.getCartInfo().getIsComboOrderAllowed());
        } else {
            cartInfo.setIsComboOrderAllowed(false);
        }
        if(request.getCartInfo().isFlexV2()){
            cartInfo.setFlexV2(request.getCartInfo().isFlexV2()); //Default Value
        }
        if(request.getCartInfo().isPrepaidToPostpaidMigration()){
            cartInfo.setPrepaidToPostpaidMigration(request.getCartInfo().isPrepaidToPostpaidMigration()); //TODO
        }
        cartInfo.setProtectionNotRequired(false); //Default Value
        cartInfo.setTradeInShippingType(CartConstants.TRADEIN_SHIPPING_TYPE);
        //cartInfo.setTradeinShipType(CartConstants.TRADEIN_SHIP_TYPE);

        return cartInfo;
    }

    private static void setAmNextGenEnabled(AddDeviceUIRequest request, onevz.soe.cart.model.common.CartServiceCustomerInfo customerInfo) {
        if (CartConstants.ACCOUNT_MEMBER_ROLES.contains(request.getCartInfo().getAmRole())) {
            if (null != request.getCartInfo().getIsLineLevelPlanAccount())
                customerInfo.setIsLineLevelPlanAccount(request.getCartInfo().getIsLineLevelPlanAccount());
            customerInfo.setAmNextGenEnabled(request.getCartInfo().getAmNextGenEnabled());
        }
    }
}
