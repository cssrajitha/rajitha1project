package onevz.soe.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.constants.RedisConstants;
import onevz.soe.cart.model.common.Address;
import onevz.soe.cart.model.common.FiveG.*;
import onevz.soe.cart.model.createLine.HomeSalesAddress;
import onevz.soe.cart.model.initiateDeviceSimActivation.IntiateDeviceSimActivationUIRequest;
import onevz.soe.cart.model.retrieveCart.CXPCartVO;
import onevz.soe.cart.model.retrieveCart.CXPOrderDetails;
import onevz.soe.cart.model.retrieveCart.CXPRetrieveCartDataVO;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.RetrieveCartUIResponse;
import onevz.soe.cart.util.CartPegaRequestErrorsUtil;
import onevz.soe.cart.util.CartPegaResponseErrorsUtil;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.session.constants.SessionConstants;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.utilities.serialization.JacksonMapperFactory;
import onevz.soe.wsclient.bpm.model.CustomerInfo;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.util.*;

import static onevz.soe.cart.constants.CartConstants.*;

@Service
public class RedisHelper3 {

    @Autowired
    SOELoginSessionBean sessionBean;
    @Autowired
    private ObjectMapper mapper;

    @Value("${digital.tech.sessionKeys:VPMLocationCode,VPMOrderNumber,accountNumber,cBandRepId,cBandSku,cBandOutletId,fiveGPlan}")
    String[] techSessionKeys;
    @Value("${soe.gatekeeper.fwaRedisKeys:false}")
    private boolean fwaRedisKeysEnabled;


    private static final Logger logger = LoggerFactory.getLogger(RedisHelper2.class);
    public static final String ERROR_PARSING_JSON_TO_OBJECT = "Error parsing JSON to Object: {}";
    /**
     * getPsimSKUFromRedis
     * @return String
     */
    public Mono<String> getPsimSKUFromRedis() {
        return sessionBean.getSessionData(CartConstants.PSIM_SKU, String.class).onErrorReturn("")
                .defaultIfEmpty("").flatMap(data -> {
                    logger.info(String.format("Reading Psim sku: %s " , data));
                    return Mono.just(data);
                });
    }

    /**
     * getDeviceSorDisplayNameFromRedis
     * @return String
     */
    public Mono<String> getDeviceSorDisplayNameFromRedis() {
        return sessionBean.getSessionData(CartConstants.BYOD_DEVICE_SOR_DISPLAYNAME, String.class).onErrorReturn("")
                .defaultIfEmpty("").flatMap(data -> {
                    logger.info(String.format("Reading byod sor display name: %s " , data));
                    return Mono.just(data);
                });
    }

    /**
     * updateByodDeviceDetailRedis
     *
     * @param esimSKU
     * @param psimSKU
     * @param sorDisplayName
     * @return Boolean
     */
    public Mono<Boolean> updateByodDeviceDetailRedis(String esimSKU, String psimSKU, String sorDisplayName){
        Map<String, String> requestMap = new HashMap<String, String>();
        requestMap.put(CartConstants.ESIM_SKU, esimSKU);
        requestMap.put(CartConstants.PSIM_SKU, psimSKU);
        requestMap.put(CartConstants.BYOD_DEVICE_SOR_DISPLAYNAME, sorDisplayName);
        requestMap.put(CartConstants.BYOD_ESIM_FLOW, "true");

        logger.info(String.format("updateSKU data into Redis : %s, %s, %s" , esimSKU, psimSKU,sorDisplayName ));
        return sessionBean.setSessionData(requestMap)
                .doOnError(error -> logger.info(" Redis upsert of ByodDeviceDetail failed : " + error))
                .doOnSuccess(success -> logger.info("Redis upsert of ByodDeviceDetail successful "));

    }

    /** Read the FWA qualified address from Redis
     *
     * @return fiveGLTEAddress
     */
    public Mono<FiveGLTEAddressRedis> getFiveGAddressFromRedisFromFiveGFlow() {
        return sessionBean.getSessionData(Arrays.asList(new String[] {CartConstants.FIVEG_HOME_QUALIFIED,CartConstants.LTE_HOME_QUALIFIED,
                CartConstants.LAUNCH_TYPE,CartConstants.ADDRESS_TYPE,
                CartConstants.INSTALL_TYPE,CartConstants.EVENTCORRELATIONID,CartConstants.ADDRESSLINE1,CartConstants.ADDRESSLINE2,
                CartConstants.CITY,CartConstants.STATE,CartConstants.ZIPCODE,CartConstants.LATITUDE,CartConstants.LONGITUDE,
                CartConstants.FLOOR_NUMBER,CartConstants.BUILDING_ID,CartConstants.LTEHOMESKU,CartConstants.BUNDLEID,CartConstants.BUNDLENAME,CartConstants.BUNDLE_TYPE,
                CartConstants.FIPS_CODE,CartConstants.EMAIL_ADDRESS,CartConstants.CBR,CartConstants.D2D_LOCATION_CODE,	CartConstants.IS_D2D_FLOW,
                CartConstants.MUC_ELIGIBLE_FLAG, CartConstants.OUTLET_ID, CartConstants.VENDOR_ID, CartConstants.NETWORK_BANDWIDTH_TYPE, CartConstants.CBAND_SKU,CartConstants.AQ_CASE_ID,CartConstants.CRM_RESUME_CART_FLOW,CartConstants.STREET_NAME,CartConstants.STREET_NUBMER,CartConstants.STREET_TYPE,CartConstants.STREET_DIRECTION,FWA_QUAL_ADDRESS_ID, FWA_QUAL_ADDRESS_LOCATION_ID}))
                .onErrorReturn(new HashMap<Object, Object>()).defaultIfEmpty(new HashMap<Object, Object>())
                .flatMap(data -> {
                    FiveGLTEAddressRedis address = new FiveGLTEAddressRedis();
                    if(data.containsKey(CartConstants.ADDRESSLINE1) && null != data.get(CartConstants.ADDRESSLINE1)) {
                        address.setAddressLine1(((String)data.get(CartConstants.ADDRESSLINE1)).trim());
                    } else {
                        address = CartPegaRequestErrorsUtil.handleFiveAddressErrors5GFlow(address);
                        return Mono.just(address);
                    }
                    updateAdressDataFromRedis(address,data);
                    updateSecondaryDetailsFromRedis(address,data);
                    updateBundleDetailsFromRedis(address,data);

                    return Mono.just(address);
                });
    }

    public Mono<FiveGLTEAddressRedis> getBulkQualificationAddressFromRedis(AddPlanAndDeviceUIRequest request){
        FiveGLTEAddressRedis address = new FiveGLTEAddressRedis();
        if ((request.getCartInfo().getIntendType().contains("AAL") && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getAddressRecordIdentifier()))) {
            return sessionBean.getSessionData(CartConstants.BULK_QUALIFICATION_QUALIFIED_ADDRESS_LIST, BulkAddressQualificationRedisResponse.class)
                    .onErrorReturn(new BulkAddressQualificationRedisResponse())
                    .defaultIfEmpty(new BulkAddressQualificationRedisResponse())
                    .flatMap(addressList -> {
                        BulkQualifiedAddressResponse addressResponse = null;
                        if (addressList.getOutput() != null && addressList.getOutput().getQualifiedAddressList() != null && !addressList.getOutput().getQualifiedAddressList().isEmpty()) {
                            logger.info("Bulk qualification address is present in redis");
                            List<BulkQualifiedAddressResponse> bulkAddressList = addressList.getOutput().getQualifiedAddressList();
                            String recordIdentifierFromRequest = request.getCartInfo().getAddressRecordIdentifier();
                            Optional<BulkQualifiedAddressResponse> addressResponseOptional = bulkAddressList.stream().filter(addr -> addr.getRecordIdentifier().equalsIgnoreCase(recordIdentifierFromRequest))
                                    .findFirst();
                            if (addressResponseOptional.isPresent()) {
                                addressResponse = addressResponseOptional.get();
                                logger.info("Bulk qualification selected address {}", addressResponse);
                            }
                            Address addressFromRequest = request.getCartInfo().getAddressInfo();
                            if (addressResponse != null && addressFromRequest.getAddressLine1().equalsIgnoreCase(addressResponse.getAddressLine1()) && addressFromRequest.getAddressLine2().equalsIgnoreCase(
                                    addressResponse.getAddressLine2()) && addressFromRequest.getCity().equalsIgnoreCase(addressResponse.getCity()) &&
                                    addressFromRequest.getState().equalsIgnoreCase(addressResponse.getState()) && addressFromRequest.getZipCode().equalsIgnoreCase(
                                    addressResponse.getZipCode())) {
                                logger.info("Bulk qualification address from redis is same as the address from request");
                                addressResponse.setAqCaseId(addressList.getOutput().getAqCaseId());
                                upsertAddressDataFromRedisForBulkQual(addressResponse, address);
                                upsertSecondaryAddressDetailsFromRedis(addressResponse, address);
                                updateBundleDetailsFromRedisForBulkQual(addressResponse, address);
                            }
                        }
                        Check5GAvailabilityRedisResponse check5GAvailabilityRedisResponse = new Check5GAvailabilityRedisResponse();
                        check5GAvailabilityRedisResponse.setOutput(addressResponse);
                        check5GAvailabilityRedisResponse.setStatusCode("00");
                        check5GAvailabilityRedisResponse.setStatusMessage("Service Completed Successfully");
                        return sessionBean.setSessionData("checkFiveGAvailResponse", check5GAvailabilityRedisResponse).flatMap(data -> Mono.just(address));
                    });
        } else if (("Resume".equalsIgnoreCase(request.getCartInfo().getAction()) || "Restart".equalsIgnoreCase(request.getCartInfo().getAction()) ||
                "updateInstallType".equalsIgnoreCase(request.getCartInfo().getProcessAction())) &&
                "Y".equalsIgnoreCase(request.getCartInfo().getBulkQualIndicator())) {
            return sessionBean.getSessionData("checkFiveGAvailResponse", Check5GAvailabilityRedisResponse.class).flatMap(fiveGResponse -> {
                BulkQualifiedAddressResponse bulkQualifiedAddressResponse = fiveGResponse.getOutput();
                upsertAddressDataFromRedisForBulkQual(bulkQualifiedAddressResponse, address);
                upsertSecondaryAddressDetailsFromRedis(bulkQualifiedAddressResponse, address);
                updateBundleDetailsFromRedisForBulkQual(bulkQualifiedAddressResponse, address);
                return Mono.just(address);
            });
        }
        return Mono.just(address);
    }

    private void updateBundleDetailsFromRedisForBulkQual(BulkQualifiedAddressResponse addressResponse, FiveGLTEAddressRedis address) {
        if(addressResponse.getBundleDetails() != null && addressResponse.getBundleDetails().length > 0) {
            BundleDetails bundleDetails = null;
            List<BundleDetails> bundleList = new ArrayList<>();
            for(int i=0; i < addressResponse.getBundleDetails().length; i++) {
                bundleDetails = new BundleDetails();
                bundleDetails.setId(addressResponse.getBundleDetails()[i].getId());
                bundleDetails.setBundleName(addressResponse.getBundleDetails()[i].getBundleName());
                bundleList.add(bundleDetails);
            }
            address.setBundleList(bundleList);
        }
    }

    private void upsertSecondaryAddressDetailsFromRedis(BulkQualifiedAddressResponse addressResponse, FiveGLTEAddressRedis address) {
        if(null != addressResponse.getLaunchType())
            address.setLaunchType(addressResponse.getLaunchType());
        if(null != addressResponse.getLTEHomeSku())
            address.setLTEHomeSku(addressResponse.getLTEHomeSku());
        if(null != addressResponse.getQualified4GHome())
            address.setLTEHomeQualified(addressResponse.getQualified4GHome().toString());
        if(null != addressResponse.getQualified())
            address.setFiveGHomeQualified(addressResponse.getQualified().toString());
        if(null!= addressResponse.getNetworkBandwidthType())
            address.setNetworkBandwidthType(addressResponse.getNetworkBandwidthType().toUpperCase());
        if(null!= addressResponse.getCBandSku())
            address.setLTEHomeSku(addressResponse.getCBandSku());
        if(null != addressResponse.getAqCaseId())
            address.setAqCaseId(addressResponse.getAqCaseId());
    }

    public void upsertAddressDataFromRedisForBulkQual(BulkQualifiedAddressResponse addressResponse, FiveGLTEAddressRedis address) {
        Map<String, String> sessionData = new HashMap<>();
        if(StringUtils.isNotEmpty(addressResponse.getEventCorrelationId()))
            address.setEventCorrelationId(addressResponse.getEventCorrelationId());
        if(StringUtils.isNotEmpty(addressResponse.getAddressLine1())){
            address.setAddressLine1(addressResponse.getAddressLine1());
            sessionData.put(ADDRESSLINE1,addressResponse.getAddressLine1());
        }
        if(null != addressResponse.getAddressLine2()) {
            address.setAddressLine2(addressResponse.getAddressLine2());
            sessionData.put(ADDRESSLINE2, addressResponse.getAddressLine2());
        }
        if(StringUtils.isNotEmpty(addressResponse.getCity())){
            address.setCity(addressResponse.getCity());
            sessionData.put(CITY, addressResponse.getCity());
        }
        if(StringUtils.isNotEmpty(addressResponse.getState())){
            address.setState(addressResponse.getState());
            sessionData.put(STATE, addressResponse.getState());
        }
        if(StringUtils.isNotEmpty(addressResponse.getZipCode())){
            address.setZipCode(addressResponse.getZipCode());
            sessionData.put(ZIPCODE, addressResponse.getZipCode());
        }
        if(StringUtils.isNotEmpty(addressResponse.getStreetName()))
            address.setStreetName(addressResponse.getStreetName());
        if(StringUtils.isNotEmpty(addressResponse.getStreetNumber()))
            address.setStreetNumber(addressResponse.getStreetNumber());
        if(StringUtils.isNotEmpty(addressResponse.getStreetType()))
            address.setStreetType(addressResponse.getStreetType());

        if(sessionData.containsKey(ADDRESSLINE1))
            sessionBean.setSessionData(sessionData).subscribeOn(Schedulers.parallel());
    }

    /**
     *
     * @return fiveGLTEAddress
     */
    public Mono<FiveGLTEAddressRedis> getCartDataFromRedisForFiveGFlow() {
        return sessionBean.getSessionData(Arrays.asList(new String[] {CartConstants.COMBO_ORDER_FLAG, CartConstants.CHANNEL_ID,CartConstants.COMPLETED_CARTID_CONST,CartConstants.CART_ID,CartConstants.IS_REDESIGN_FLOW,CartConstants.INTENTTYPE,CartConstants.CRM_RESUME_CART_FLOW,CartConstants.ADDRESSLINE1,CartConstants.SAFETECH_SESSION_ID}))
                .onErrorReturn(new HashMap<Object, Object>()).defaultIfEmpty(new HashMap<Object, Object>())
                .flatMap(data -> {
                    FiveGLTEAddressRedis address = new FiveGLTEAddressRedis();
                    
                    if(data.containsKey(CartConstants.COMBO_ORDER_FLAG) && null != data.get(CartConstants.COMBO_ORDER_FLAG))
                        address.setIsSequentialComboOrder((data.get(CartConstants.COMBO_ORDER_FLAG)).toString());
                    if(data.containsKey(CartConstants.CHANNEL_ID) && null != data.get(CartConstants.CHANNEL_ID))
                        address.setChannelId((data.get(CartConstants.CHANNEL_ID)).toString());
                    if(data.containsKey(CartConstants.CART_ID) && null != data.get(CartConstants.CART_ID))
                        address.setCartId((data.get(CartConstants.CART_ID)).toString());
                    if(data.containsKey(CartConstants.COMPLETED_CARTID_CONST) && null != data.get(CartConstants.COMPLETED_CARTID_CONST))
                        address.setCompletedCartId((data.get(CartConstants.COMPLETED_CARTID_CONST)).toString());
                    if(data.containsKey(CartConstants.INTENTTYPE) && null != data.get(CartConstants.INTENTTYPE))
                        address.setIntentType((data.get(CartConstants.INTENTTYPE)).toString());
                    if(data.containsKey(CartConstants.IS_REDESIGN_FLOW) && null != data.get(CartConstants.IS_REDESIGN_FLOW))
                        address.setRedesignFlow((data.get(CartConstants.IS_REDESIGN_FLOW)).toString());
                    else
                        address.setRedesignFlow(CartConstants.FALSE);
                    if(data.containsKey(CartConstants.NETWORK_BANDWIDTH_TYPE) && null != data.get(CartConstants.NETWORK_BANDWIDTH_TYPE))
                        address.setNetworkBandwidthType((data.get(CartConstants.NETWORK_BANDWIDTH_TYPE)).toString());
                    if(data.containsKey(CartConstants.CRM_RESUME_CART_FLOW) && null != data.get(CartConstants.CRM_RESUME_CART_FLOW))
                        address.setCrmResumeCartFlow((data.get(CartConstants.CRM_RESUME_CART_FLOW)).toString());
                    if(data.containsKey(CartConstants.ADDRESSLINE1) && null != data.get(CartConstants.ADDRESSLINE1))
                        address.setAddressLine1((data.get(CartConstants.ADDRESSLINE1)).toString());
                    if(data.containsKey(CartConstants.SAFETECH_SESSION_ID) && null != data.get(CartConstants.SAFETECH_SESSION_ID))
                        address.setSafeTechSessionId((data.get(CartConstants.SAFETECH_SESSION_ID)).toString());
                    return Mono.just(address);
                });
    }

    private void updateBundleDetailsFromRedis(FiveGLTEAddressRedis address, Map data) {
        if(data.containsKey(CartConstants.BUNDLEID) && data.containsKey(CartConstants.BUNDLENAME)
                && null != data.get(CartConstants.BUNDLEID) && null != data.get(CartConstants.BUNDLENAME)
                && !("NA".equalsIgnoreCase(data.get(CartConstants.BUNDLENAME).toString())
                || "NA".equalsIgnoreCase(data.get(CartConstants.BUNDLEID).toString()))) {
            String bundleId = (data.get(CartConstants.BUNDLEID)).toString();
            String[] bundleIds = bundleId.split(",");
            String bundleName = data.get(CartConstants.BUNDLENAME).toString();
            String[] bundleNames = bundleName.split(",");
            List<BundleDetails> bundleList = new ArrayList<>();
            BundleDetails bundleDetails = null;
            for(int i=0; i < bundleIds.length; i++) {
                bundleDetails = new BundleDetails();
                bundleDetails.setId(bundleIds[i]);
                bundleDetails.setBundleName(bundleNames[i]);
                if(StringUtilities.isNotEmptyOrNull(address.getNetworkBandwidthType()) && (address.getNetworkBandwidthType().equalsIgnoreCase(CartConstants.NETWORK_TYPE_CBD)) && data.containsKey(CartConstants.CBAND_SKU) && null != data.get(CartConstants.CBAND_SKU)) {
                   String cbandSku = data.get(CartConstants.CBAND_SKU).toString();
                   bundleDetails.setSkuId(cbandSku);
                }
                bundleList.add(bundleDetails);
            }
            address.setBundleList(bundleList);
        }
    }

    private void updateSecondaryDetailsFromRedis(FiveGLTEAddressRedis address, Map data) {

        if(data.containsKey(CartConstants.LAUNCH_TYPE) && null != data.get(CartConstants.LAUNCH_TYPE))
            address.setLaunchType((data.get(CartConstants.LAUNCH_TYPE)).toString());
        if(data.containsKey(CartConstants.LTEHOMESKU) && null != data.get(CartConstants.LTEHOMESKU))
            address.setLTEHomeSku((data.get(CartConstants.LTEHOMESKU)).toString());
        if(data.containsKey(CartConstants.LTE_HOME_QUALIFIED) && null != data.get(CartConstants.LTE_HOME_QUALIFIED))
            address.setLTEHomeQualified((data.get(CartConstants.LTE_HOME_QUALIFIED)).toString());
        if(data.containsKey(CartConstants.FIVEG_HOME_QUALIFIED) && null != data.get(CartConstants.FIVEG_HOME_QUALIFIED))
            address.setFiveGHomeQualified((data.get(CartConstants.FIVEG_HOME_QUALIFIED)).toString());
        if(data.containsKey(CartConstants.EMAIL_ADDRESS) && null!=data.get(CartConstants.EMAIL_ADDRESS))/*MVP2*/
            address.setEmailAddress(data.get(CartConstants.EMAIL_ADDRESS).toString());
        if(data.containsKey(CartConstants.CBR)&& null!=data.get(CartConstants.CBR))/*MVP2*/
            address.setCbr(data.get(CartConstants.CBR).toString());
        if(data.containsKey(CartConstants.D2D_LOCATION_CODE)&& null !=data.get(CartConstants.D2D_LOCATION_CODE))
            address.setCartCreatorOrderLocationCode(data.get(CartConstants.D2D_LOCATION_CODE).toString());
        if(data.containsKey(CartConstants.OUTLET_ID)&& null !=data.get(CartConstants.OUTLET_ID))
            address.setOutletId(data.get(CartConstants.OUTLET_ID).toString());
        if(data.containsKey(CartConstants.VENDOR_ID)&& null !=data.get(CartConstants.VENDOR_ID))
            address.setVendorId(data.get(CartConstants.VENDOR_ID).toString());
        if(data.containsKey(CartConstants.IS_D2D_FLOW)&& null !=data.get(CartConstants.IS_D2D_FLOW))
            address.setIsD2DFlow(data.get(CartConstants.IS_D2D_FLOW).toString());
        if(data.containsKey(CartConstants.D2D_POS_AGENTID)&& null !=data.get(CartConstants.D2D_POS_AGENTID))
            address.setD2dPosAgentID(data.get(CartConstants.D2D_POS_AGENTID).toString());
        if(data.containsKey(CartConstants.MUC_ELIGIBLE_FLAG)&& null !=data.get(CartConstants.MUC_ELIGIBLE_FLAG))
            address.setFiveGMUCEligible(data.get(CartConstants.MUC_ELIGIBLE_FLAG).toString());
        if(data.containsKey(CartConstants.NETWORK_BANDWIDTH_TYPE) && null!= data.get(CartConstants.NETWORK_BANDWIDTH_TYPE))
            address.setNetworkBandwidthType(data.get(CartConstants.NETWORK_BANDWIDTH_TYPE).toString().toUpperCase());
        if(data.containsKey(CartConstants.CBAND_SKU) && null!= data.get(CartConstants.CBAND_SKU))
            address.setLTEHomeSku(data.get(CartConstants.CBAND_SKU).toString());
        if(data.containsKey(CartConstants.CRM_RESUME_CART_FLOW) && null!= data.get(CartConstants.CRM_RESUME_CART_FLOW))
            address.setCrmResumeCartFlow(data.get(CartConstants.CRM_RESUME_CART_FLOW).toString());
    }

    private void updateAdressDataFromRedis(FiveGLTEAddressRedis address, Map data) {
        if(data.containsKey(CartConstants.EVENTCORRELATIONID) && null != data.get(CartConstants.EVENTCORRELATIONID))
            address.setEventCorrelationId((data.get(CartConstants.EVENTCORRELATIONID)).toString());
        if(data.containsKey(CartConstants.ADDRESSLINE2) && null != data.get(CartConstants.ADDRESSLINE2))
            address.setAddressLine2((data.get(CartConstants.ADDRESSLINE2)).toString());
        if(data.containsKey(CartConstants.CITY) && null != data.get(CartConstants.CITY))
            address.setCity((data.get(CartConstants.CITY)).toString());
        if(data.containsKey(CartConstants.STATE) && null != data.get(CartConstants.STATE))
            address.setState((data.get(CartConstants.STATE)).toString());
        if(data.containsKey(CartConstants.ZIPCODE) && null != data.get(CartConstants.ZIPCODE))
            address.setZipCode((data.get(CartConstants.ZIPCODE)).toString());
        if(data.containsKey(CartConstants.LATITUDE) && null != data.get(CartConstants.LATITUDE))
            address.setLatitude((data.get(CartConstants.LATITUDE)).toString());
        if(data.containsKey(CartConstants.LONGITUDE) && null != data.get(CartConstants.LONGITUDE))
            address.setLongitude((data.get(CartConstants.LONGITUDE)).toString());
        if(data.containsKey(CartConstants.FLOOR_NUMBER) && null != data.get(CartConstants.FLOOR_NUMBER))
            address.setFloor(Integer.parseInt((data.get(CartConstants.FLOOR_NUMBER)).toString()));
        if(data.containsKey(CartConstants.BUILDING_ID) && null != data.get(CartConstants.BUILDING_ID))
            address.setBuildingId((data.get(CartConstants.BUILDING_ID)).toString());
        if(data.containsKey(CartConstants.FIPS_CODE) && null != data.get(CartConstants.FIPS_CODE))
            address.setFipsCode((data.get(CartConstants.FIPS_CODE)).toString());
        if(data.containsKey(CartConstants.AQ_CASE_ID) && null != data.get(CartConstants.AQ_CASE_ID))
            address.setAqCaseId((data.get(CartConstants.AQ_CASE_ID)).toString());
        if(data.containsKey(CartConstants.STREET_NAME) && null != data.get(CartConstants.STREET_NAME))
            address.setStreetName((data.get(CartConstants.STREET_NAME)).toString());
        if(data.containsKey(CartConstants.STREET_NUBMER) && null != data.get(CartConstants.STREET_NUBMER))
            address.setStreetNumber((data.get(CartConstants.STREET_NUBMER)).toString());
        if(data.containsKey(CartConstants.STREET_TYPE) && null != data.get(CartConstants.STREET_TYPE))
            address.setStreetType((data.get(CartConstants.STREET_TYPE)).toString());
        if(data.containsKey(CartConstants.STREET_DIRECTION) && null != data.get(CartConstants.STREET_DIRECTION))
            address.setStreetDirection((data.get(CartConstants.STREET_DIRECTION)).toString());
        if(data.containsKey(FWA_QUAL_ADDRESS_ID) && null != data.get(FWA_QUAL_ADDRESS_ID))
            address.setAddressId(data.get(FWA_QUAL_ADDRESS_ID).toString());
        if(data.containsKey(FWA_QUAL_ADDRESS_LOCATION_ID) && null != data.get(FWA_QUAL_ADDRESS_LOCATION_ID))
            address.setLocationId(data.get(FWA_QUAL_ADDRESS_LOCATION_ID).toString());
    }

    /**
     *
     * @param request
     * @param itemType
     * @return fiveGOrderNowData
     */
    public Mono<Boolean> updateFiveGOrderNowDataIntoRedisAsString(CartRedisData request, String itemType) {

        Map<String, String> requestMap = new HashMap<>();
        String requestString = "";
        String aalPromoInterceptString = "";
        requestMap.put(CartConstants.APP_NAME, CartConstants.SOE_CART_SERVICE_NAME);
        settingDataIntoRedisAsString(requestMap,request,aalPromoInterceptString,itemType,requestString,false);
        updateRequestMap(request,requestMap, itemType, aalPromoInterceptString);
        return settingReturnSessionData(requestMap,request);
    }

    /**
     *
     * @param request
     * @return updateCrmResumeData
     */
    public Mono<Boolean> updateCrmResumeDataIntoRedisAsString(CrmResumeCartUIRequest request) {

        Map<String, String> requestMap = new HashMap<>();
        requestMap.put(CartConstants.APP_NAME, CartConstants.SOE_CART_SERVICE_NAME);
        updateRedisRequestMap5G(request,requestMap);
        return settingReturnSessionData(requestMap,request);
    }

    private void updateRedisRequestMap5G(CrmResumeCartUIRequest request, Map requestMap) {
        boolean fwaFlow = fwaRedisKeysEnabled && sessionBean.isFWADigitalFlow();
        String cartIdKey = fwaFlow ? SessionConstants.FWA_CART_ID : SessionConstants.CART_ID;
        String caseIdKey = fwaFlow ? SessionConstants.FWA_CASE_ID : SessionConstants.CASE_ID;
        String intendTypeKey = fwaFlow ? SessionConstants.FWA_INTEND_TYPE : SessionConstants.INTEND_TYPE;

        requestMap.put(CartConstants.PROCESSING_MTN, request.getProcessingMTN());
        requestMap.put(CartConstants.CART_ORDER_FLOW_TYPE, request.getIntendType());
        requestMap.put(ACCOUNT_NUMBER, request.getAccountNumber());
        requestMap.put(CartConstants.CART_CREATOR, request.getCartCreator());
        requestMap.put(CartConstants.PROCESS_STEP, request.getProcessStep());
        requestMap.put(CartConstants.CRM_RESUME_CART_FLOW, "true");
        requestMap.put(cartIdKey, request.getCartId());
        requestMap.put(intendTypeKey, request.getIntendType());
        requestMap.put(caseIdKey, request.getCaseId());
        // add LQ data
        if(null != request.getLqData()) {
            requestMap.put(CartConstants.NETWORK_BANDWIDTH_TYPE, request.getLqData().getNetworkBandwidthType());
            if(null != request.getLqData().getEligible5GHomeBundle() && request.getLqData().getEligible5GHomeBundle().size() >0) {
                List<String> bundleName=new ArrayList<>();
                List<String> bundleId=new ArrayList<>();
                request.getLqData().getEligible5GHomeBundle().stream().filter(Objects::nonNull).forEach(eligible5GHomeBundle -> {
                    bundleName.add(eligible5GHomeBundle.getBundleName());
                    bundleId.add(eligible5GHomeBundle.getId());
                });
                String bundleNames=String.join(",",bundleName);
                String bundleIds=String.join(",",bundleId);
                requestMap.put(CartConstants.BUNDLENAME, bundleNames);
                requestMap.put(CartConstants.BUNDLEID, bundleIds);
            }
            if( null != request.getLqData().getCart5GAddress()) {
                Address cart5GAddress = request.getLqData().getCart5GAddress();
                requestMap.put(CartConstants.ADDRESSLINE1, cart5GAddress.getAddressLine1());
                requestMap.put(CartConstants.ADDRESSLINE2, cart5GAddress.getAddressLine2());
                requestMap.put(CartConstants.CITY, cart5GAddress.getCity());
                requestMap.put(CartConstants.STATE, cart5GAddress.getState());
                requestMap.put(CartConstants.ZIPCODE, cart5GAddress.getZipCode());
                requestMap.put(CartConstants.LATITUDE, cart5GAddress.getLatitude());
                requestMap.put(CartConstants.LONGITUDE, cart5GAddress.getLongitude());
                if(null != cart5GAddress.getFloor())
                    requestMap.put(CartConstants.FLOOR_NUMBER, cart5GAddress.getFloor().toString());
                requestMap.put(CartConstants.BUILDING_ID, cart5GAddress.getBuildingId());
            }
        }

        if (StringUtilities.isNotEmptyOrNull(request.getProcessingMTN()))
            requestMap.put(CartConstants.PROCESSING_MTN, request.getProcessingMTN());
    }

    private void updateRequestMap(CartRedisData request, Map requestMap, String itemType, String aalPromoInterceptString) {
        String ecpdId = request.getEcpdId();
        String intendType=request.getIntendType();
        if (StringUtilities.isNotEmptyOrNull(ecpdId))
            requestMap.put(CartConstants.ECPD_PROFILE_ID, ecpdId);
        requestMap.put(CartConstants.PROCESSING_MTN, request.getProcessingMTN());
        if("repairGen2ToGen3".equalsIgnoreCase(request.getTransactionType()))
        {
            intendType=CartConstants.EUP_5G_REPAIR;
        }
        if("cBand_Technician".equalsIgnoreCase(request.getTransactionType()))
        {
            intendType=CartConstants.TECH_CBD_INTENT;
        }
        boolean fwaFlow = fwaRedisKeysEnabled && sessionBean.isFWADigitalFlow();
        String cartIdKey = fwaFlow ? SessionConstants.FWA_CART_ID : SessionConstants.CART_ID;
        String caseIdKey = fwaFlow ? SessionConstants.FWA_CASE_ID : SessionConstants.CASE_ID;
        String intendTypeKey = fwaFlow ? SessionConstants.FWA_INTEND_TYPE : SessionConstants.INTEND_TYPE;

        requestMap.put(cartIdKey, request.getCartId());
        requestMap.put(intendTypeKey, intendType);
        requestMap.put(caseIdKey, request.getCaseId());
        requestMap.put(CartConstants.CART_ORDER_FLOW_TYPE, request.getIntendType());
        requestMap.put(CartConstants.AAL_PROMO_INTERCEPT, aalPromoInterceptString);
        requestMap.put(CartConstants.DEVICE_PROD_ID, request.getDeviceProdId());
        requestMap.put(CartConstants.ITEM_TYPE, itemType);
        requestMap.put(ACCOUNT_NUMBER, request.getAccountNumber());
        requestMap.put(CartConstants.CART_CREATOR, request.getCartCreator());
        requestMap.put(CartConstants.PROCESS_STEP, request.getProcessStep());
        requestMap.put(CartConstants.COVID_QUES_ANSWERED, request.getCovidQuestionareAnswered());
        if (StringUtilities.isNotEmptyOrNull(request.getProcessingMTN()))
            requestMap.put(CartConstants.PROCESSING_MTN, request.getProcessingMTN());
        if (CartConstants.DEVICE.equalsIgnoreCase(itemType))
            requestMap.put(CartConstants.ACCOUNT_INFO_VALIDATE, CartConstants.FALSE);
        if (StringUtilities.isNotEmptyOrNull(request.getMidnight()) && request.getMidnight().equalsIgnoreCase("Y"))
            requestMap.put("fwaMidnight",request.getMidnight());
    }

    /**
     * Upsert BBP data into redis browser for Initiate device sim activation
     *
     * @param request the request
     * @return the mono
     */
    public Mono<Boolean> upsertInitiateDeviceSimActivationDataIntoRedis(IntiateDeviceSimActivationUIRequest request) {
        Map<String, String> requestMap = new HashMap<>();

        if (StringUtilities.isNotEmptyOrNull(request.getIccid())) {
            requestMap.put(CartConstants.BBP_ICCID, request.getIccid());
        }
        if (StringUtilities.isNotEmptyOrNull(request.getImei())) {
            requestMap.put(CartConstants.BBP_IMEI, request.getImei());
        }

        return sessionBean.setSessionData(requestMap).flatMap(data -> {
            return Mono.just(data);
        });
    }

    /**
     *
     * @param request
     * @return deviceSimValidationRequest
     */
    public Mono<Boolean> upsertDeviceSimValidationRequestDataIntoRedis(DeviceSimValidationUIRequest request) {
        Map<String, String> requestMap = new HashMap<>();
        String isSmartPhone = "";
        if (request != null) {
            if(request.getIsSmartphone()!=null)
                isSmartPhone = String.valueOf(request.getIsSmartphone());
            if(StringUtilities.isNotEmptyOrNull(request.getIccid()))
                requestMap.put(CartConstants.BBP_ICCID, request.getIccid());
            if(StringUtilities.isNotEmptyOrNull(request.getImei()))
                requestMap.put(CartConstants.BBP_IMEI, request.getImei());
            if(StringUtilities.isNotEmptyOrNull(isSmartPhone))
                requestMap.put(CartConstants.IS_SMARTPHONE, isSmartPhone);
            if(StringUtilities.isNotEmptyOrNull(request.getImei2()))
                requestMap.put(CartConstants.BBP_IMEI2, request.getImei2());
            if(StringUtilities.isNotEmptyOrNull(request.getDevid()))
                requestMap.put(CartConstants.DEVID, request.getDevid());
            if(StringUtilities.isNotEmptyOrNull(request.getEid()))
                requestMap.put(CartConstants.EID, request.getEid());

        }

        logger.info("requestmap of devicesimvalidation req into redis: {}", requestMap);
        return sessionBean.setSessionData(requestMap).flatMap(data -> {
            return Mono.just(data);
        }).doOnSuccess(data -> {
            logger.info("Data insertion in redis is :{}", data);
        }).doOnError(onError->{
            logger.info("Error occured due to :{}", onError);
        });
    }

    /**
     *
     * @return data
     */
    public Mono<HomeSalesAddress> getHomeSalesAddressFromRedis() {
        return sessionBean.getSessionData(RedisConstants.HOME_SALES_ADDRESS, HomeSalesAddress.class)
                .onErrorReturn(new HomeSalesAddress()).defaultIfEmpty(new HomeSalesAddress()).flatMap(data -> {
                    logger.info("Reading HomeSalesAddress: {}", data);
                    return Mono.just(data);
                });
    }

    /**
     *
     * @param sessionKeys
     * @return hashMap
     */
    public Mono<Map<String, Object>> getDataFromSession(String[] sessionKeys) {
        return sessionBean.getSessionData(Arrays.asList(sessionKeys)).onErrorReturn(new HashMap<>())
                .defaultIfEmpty(new HashMap<>()).flatMap(data -> {
                    logger.info("Retrieved SessionData from Redis, data = {}", data);
                    Map<String, Object> dataMap = new HashMap<>();
                    for (String sessionKey : sessionKeys) {
                        if (data.containsKey(sessionKey) && data.get(sessionKey) != null) {
                            dataMap.put(sessionKey, data.get(sessionKey).toString());
                        }
                    }
                    return Mono.just(dataMap);

                }).switchIfEmpty(Mono.defer(() -> Mono.just(new HashMap<>())));
    }

    /**
     *
     * @return boolean
     */
    public Mono<Boolean> setRedesignFlaginRedis() {
        Map<String, String> requestMap = new HashMap<>();
        requestMap.put("redesignFlow","true");
        logger.info(String.format("update redesign flag in Redis as true... %s", true));
        return sessionBean.setSessionData(requestMap).flatMap(resp -> {return Mono.just(Boolean.TRUE);});
    }
    /**
     *
     * @return String
     */
    public Mono<String> getFlowTypeFromRedis() {
        return sessionBean.getSessionData(RedisConstants.FLOW_TYPE, String.class).onErrorReturn("").defaultIfEmpty("")
                .flatMap(data -> {
                    logger.info(String.format("Reading flowType request: %s" , data));
                    return Mono.just(data);
                });
    }

    public Mono<String> getAIQuoteFlagFromRedis() {
        return sessionBean.getSessionData(RedisConstants.AI_QUOTE_FLAG, String.class).onErrorReturn("").defaultIfEmpty("")
                .flatMap(data -> {
                    logger.info(String.format("Reading aiQuote flag request: %s" , data));
                    return Mono.just(data);
                });
    }

    /**
     *
     * @return customerProfileAddress
     */
    public Mono<CustomerProfileAddressResponse> fetchCustomerAddressFromRedis() {

        return sessionBean
                .getSessionData(Arrays.asList(
                        new String[]{CartConstants.EUP_5G_CUSTOMER_PROFILE_ADDRESS, CartConstants.BUNDLEID, CartConstants.BUNDLENAME, ACCOUNT_NUMBER,CartConstants.INTENT_TYPE}))
                .onErrorReturn(new HashMap<Object, Object>()).defaultIfEmpty(new HashMap<Object, Object>())
                .flatMap(data -> {
                    CustomerProfileAddressResponse respData = new CustomerProfileAddressResponse();
                    BundleDetails bundleDetails = new BundleDetails();
                    if (data.containsKey(CartConstants.EUP_5G_CUSTOMER_PROFILE_ADDRESS)
                            && StringUtilities.isNotEmptyOrNull((String) data.get(CartConstants.EUP_5G_CUSTOMER_PROFILE_ADDRESS))) {
                        String customerAddress = (String) data.get(CartConstants.EUP_5G_CUSTOMER_PROFILE_ADDRESS);
                        try {
                            respData = mapper.readValue(customerAddress, CustomerProfileAddressResponse.class);
                            if (data.containsKey(CartConstants.BUNDLEID)
                                    && StringUtilities.isNotEmptyOrNull((String) data.get(CartConstants.BUNDLEID))) {
                                bundleDetails.setId((String) data.get(CartConstants.BUNDLEID));
                            }
                            if (data.containsKey(CartConstants.BUNDLENAME)
                                    && StringUtilities.isNotEmptyOrNull((String) data.get(CartConstants.BUNDLENAME))) {
                                bundleDetails.setBundleName((String) data.get(CartConstants.BUNDLENAME));
                            }
                            if (data.containsKey(ACCOUNT_NUMBER)
                                    && StringUtilities.isNotEmptyOrNull((String) data.get(ACCOUNT_NUMBER))) {
                                respData.setAccountNo((String) data.get(ACCOUNT_NUMBER));
                            }

                            if (data.containsKey(CartConstants.INTENT_TYPE)
                                    && StringUtilities.isNotEmptyOrNull((String) data.get(CartConstants.INTENT_TYPE))) {
                                respData.setIntentType((String) data.get(CartConstants.INTENT_TYPE));
                            }
                            respData.getData().getCustomerByMtn().getAddress().setBundleList(Arrays.asList(bundleDetails));
                        } catch (JsonProcessingException e) {
                            logger.error(ERROR_PARSING_JSON_TO_OBJECT, e);
                        }
                    }
                    return Mono.just(respData);
                });
    }

    /**
     *
     * @param intendType
     * @return boolean
     */
    public Mono<Boolean> setIntendTypeInRedis(String intendType) {
        Map<String, String> requestMap = new HashMap<>();
        requestMap.put(CartConstants.INTEND_TYPE, intendType);
        logger.info("update intendType in Redis...");
        sessionBean.setSessionData(requestMap).subscribe();
        return Mono.empty();
    }

    /**
     *
     * @param mtn
     * @return void
     */
    public Mono<Void> updateBOGOMtn(String mtn)
    {
        Map<String, String> requestMap = new HashMap<>();
        requestMap.put(CartConstants.BOGO_MTN, mtn);
        logger.info("update BOGO mtn in Redis...");
        sessionBean.setSessionData(requestMap).subscribe();
        return Mono.empty();
    }

    /**
     *
     * @return techFlowRedisData
     */
    public Mono<TechFlowRedisData> fetchTechnicianDataFromRedis() {
        TechFlowRedisData tRedisData = new TechFlowRedisData();
        List<String> techkeys = Arrays.asList(techSessionKeys);
        List<String> redisSessionKeys = new ArrayList<>(techkeys);
        redisSessionKeys.add(CartConstants.CUSTOMER_EMAILID);
        redisSessionKeys.add(CartConstants.CPC_ORDER_TYPE);
        redisSessionKeys.add(CartConstants.CPC_PLAN_ID);
        redisSessionKeys.add(CartConstants.CART_ID);
        redisSessionKeys.add(CartConstants.CASE_ID);
        redisSessionKeys.add(CartConstants.CPC_BASIC_TO_BASIC);
        return sessionBean.getSessionData(redisSessionKeys)
                .onErrorReturn(new HashMap<Object, Object>()).defaultIfEmpty(new HashMap<Object, Object>())
                .flatMap(data -> {
                    if(data.containsKey(CartConstants.VPM_LOCATION_CODE) && null != data.get(CartConstants.VPM_LOCATION_CODE)) {
                        tRedisData.setVpmLocationCode(String.valueOf(data.get(CartConstants.VPM_LOCATION_CODE)));
                    }
                    if(data.containsKey(CartConstants.VPM_ORDER_NUMBER) && null != data.get(CartConstants.VPM_ORDER_NUMBER)) {
                        tRedisData.setVpmOrderNum(String.valueOf(data.get(CartConstants.VPM_ORDER_NUMBER)));
                    }
                    if(data.containsKey(CartConstants.VPM_AUD) && null != data.get(CartConstants.VPM_AUD)) {
                        tRedisData.setAud(String.valueOf(data.get(CartConstants.VPM_AUD)));
                    }
                    if(data.containsKey(CartConstants.VPM_EXP) && null != data.get(CartConstants.VPM_EXP)) {
                        tRedisData.setExp(String.valueOf(data.get(CartConstants.VPM_EXP)));
                    }
                    if(data.containsKey(CartConstants.VPM_IAT) && null != data.get(CartConstants.VPM_IAT)) {
                        tRedisData.setIat(String.valueOf(data.get(CartConstants.VPM_IAT)));
                    }
                    if(data.containsKey(CartConstants.INTENT_TYPE) && null != data.get(CartConstants.INTENT_TYPE)) {
                        tRedisData.setIntentType(String.valueOf(data.get(CartConstants.INTENT_TYPE)));
                    }
                    if(data.containsKey(CartConstants.VPM_ISS) && null != data.get(CartConstants.VPM_ISS)) {
                        tRedisData.setIss(String.valueOf(data.get(CartConstants.VPM_ISS)));
                    }
                    if(data.containsKey(MTN) && null != data.get(MTN)) {
                        tRedisData.setMtn(String.valueOf(data.get(MTN)));
                    }
                    if(data.containsKey(CartConstants.VPM_SALES_ID) && null != data.get(CartConstants.VPM_SALES_ID)) {
                        tRedisData.setSalesId(String.valueOf(data.get(CartConstants.VPM_SALES_ID)));
                    }
                    if(data.containsKey(CartConstants.VPM_SUB) && null != data.get(CartConstants.VPM_SUB)) {
                        tRedisData.setSub(String.valueOf(data.get(CartConstants.VPM_SUB)));
                    }
                    if(data.containsKey(CartConstants.CBAND_SKU) && null != data.get(CartConstants.CBAND_SKU)) {
                        tRedisData.setCBandSku(String.valueOf(data.get(CartConstants.CBAND_SKU)));
                    }
                    if(data.containsKey(CartConstants.CBAND_REP_ID) && null != data.get(CartConstants.CBAND_REP_ID)) {
                        tRedisData.setRepId(String.valueOf(data.get(CartConstants.CBAND_REP_ID)));
                    }
                    if(data.containsKey(CartConstants.CBAND_OUTLET_ID) && null != data.get(CartConstants.CBAND_OUTLET_ID)) {
                        tRedisData.setOutletId(String.valueOf(data.get(CartConstants.CBAND_OUTLET_ID)));
                    }
                    if(data.containsKey(CartConstants.FIVEG_PLAN) && null != data.get(CartConstants.FIVEG_PLAN)) {
                        tRedisData.setFiveGPlan(String.valueOf(data.get(CartConstants.FIVEG_PLAN)));
                    }
                    if(data.containsKey(CartConstants.CBAND_AUTH_MTN) && null != data.get(CartConstants.CBAND_AUTH_MTN)) {
                        tRedisData.setCBandAuthMTN(String.valueOf(data.get(CartConstants.CBAND_AUTH_MTN)));
                    }
                    if(data.containsKey(CartConstants.EUP_5G_ACCOUNT_NUMBER) && null != data.get(CartConstants.EUP_5G_ACCOUNT_NUMBER)) {
                        tRedisData.setAccountNumber(String.valueOf(data.get(CartConstants.EUP_5G_ACCOUNT_NUMBER)));
                    } else if(data.containsKey(ACCOUNT_NUMBER) && null != data.get(ACCOUNT_NUMBER)) {
                        tRedisData.setAccountNumber(String.valueOf(data.get(ACCOUNT_NUMBER)));
                    }
                    if(data.containsKey(CartConstants.CUSTOMER_EMAILID) && null != data.get(CartConstants.CUSTOMER_EMAILID)) {
                        tRedisData.setCbandAuthEmailId(String.valueOf(data.get(CartConstants.CUSTOMER_EMAILID)));
                    }
                    if(data.containsKey(CartConstants.CPC_ORDER_TYPE) && null != data.get(CartConstants.CPC_ORDER_TYPE)) {
                        tRedisData.setCpcOrderType(String.valueOf(data.get(CartConstants.CPC_ORDER_TYPE)));
                    }
                    if(data.containsKey(CartConstants.CPC_PLAN_ID) && null != data.get(CartConstants.CPC_PLAN_ID)) {
                        tRedisData.setNewPlanId(String.valueOf(data.get(CartConstants.CPC_PLAN_ID)));
                    }
                    if(data.containsKey(CartConstants.CART_ID) && null != data.get(CartConstants.CART_ID)) {
                        tRedisData.setCartId(String.valueOf(data.get(CartConstants.CART_ID)));
                    }
                    if(data.containsKey(CartConstants.CASE_ID) && null != data.get(CartConstants.CASE_ID)) {
                        tRedisData.setCaseId(String.valueOf(data.get(CartConstants.CASE_ID)));
                    }
                    if(data.containsKey(CartConstants.CPC_BASIC_TO_BASIC) && null != data.get(CartConstants.CPC_BASIC_TO_BASIC)) {
                        tRedisData.setBasicToBasicCpc(String.valueOf(data.get(CartConstants.CPC_BASIC_TO_BASIC)));
                    }

                    return Mono.just(tRedisData);
                });
    }

    /**
     *
     * @param request
     * @return String
     */
    public Mono<String> getHashCodeMtn(AddDeviceUIRequest request) {

        return sessionBean.getSessionData(CartConstants.MTN_HASHCODE_MAPPING, Map.class).onErrorReturn(new HashMap<String,String>())
                .defaultIfEmpty(new HashMap<String,String>()).flatMap(data -> {
                    logger.info("MTN- Hashcode Read from Redis {}", data);

                    String[] mtnValue = new String[1];
                    mtnValue[0]= "";

                    if(request.getData() != null && StringUtilities.isNotEmptyOrNull(request.getData().getSelectedMtn())) {
                        if (data.containsValue(request.getData().getSelectedMtn())) {
                            data.forEach((key, value) -> {
                                if (value.toString().equalsIgnoreCase(request.getData().getSelectedMtn())) {
                                    mtnValue[0] = key.toString();
                                    logger.info("MTN-Hashcode Read from Redis {}", mtnValue);
                                }
                            });
                        }
                    }
                    return Mono.just(mtnValue[0]);
                });
    }

    /**
     *
     * @param crmRequest
     * @return String
     */
    public Mono<String> getAccountNumberFromRedis(CrmResumeCartUIRequest crmRequest) {
        if(StringUtilities.isEmptyOrNull(crmRequest.getCustomerType())){
            return sessionBean.getSessionData(ACCOUNT_NUMBER, String.class)
                    .onErrorReturn("").defaultIfEmpty("").flatMap(data -> {
                        logger.info("Reading AccountNumber from Redis");
                        return Mono.just(data);
                    });
        }
        return Mono.just("");
    }

    /**
     *
     * @param requestMap
     * @return Boolean
     */
    public Mono<Boolean> upsertCRMDataIntoRedisAsString(Map requestMap) {
        sessionBean.setSessionData(requestMap).subscribe();
        return Mono.empty();
    }


    /**
     *
     * @param soeResponse
     * @return Boolean
     */
    public Mono<Boolean> upsertCartCreator(RetrieveCartUIResponse soeResponse) {

        Map<String, String> requestMap = new HashMap<>();
        requestMap.put(CartConstants.APP_NAME, CartConstants.SOE_CART_SERVICE_NAME);
        Optional.ofNullable(soeResponse.getData()).map(CXPRetrieveCartDataVO::getCart).map(CXPCartVO::getOrderDetails).map(CXPOrderDetails::getWfmOrderInfo)
                .ifPresent(wfmOrderInfo -> {
                    if(null != wfmOrderInfo) {
                        requestMap.put(RedisConstants.IS_WFM_FLOW, "Y");
                        Optional.ofNullable(soeResponse.getData()).map(CXPRetrieveCartDataVO::getCart).map(CXPCartVO::getCartHeader)
                                .ifPresent(cartHeader -> {
                                    if (StringUtilities.isNotEmptyOrNull(cartHeader.getCartCreator())) {
                                        requestMap.put(CartConstants.CART_CREATOR, cartHeader.getCartCreator());
                                        requestMap.put(MTN, cartHeader.getCartCreator());
                                    }
                                });
                    }
                });
        Optional.ofNullable(soeResponse.getData()).map(CXPRetrieveCartDataVO::getCart).map(CXPCartVO::getCartHeader)
                .ifPresent(cartHeader -> {
                    if(null != cartHeader && StringUtilities.isNotEmptyOrNull(cartHeader.getLocationSubType()) && "GN".equalsIgnoreCase(cartHeader.getLocationSubType())) {
                        if (StringUtilities.isNotEmptyOrNull(cartHeader.getMaid())) {
                            requestMap.put(MAID, cartHeader.getMaid());
                        }
                    }
                });
        return sessionBean.setSessionData(requestMap).doOnError(onError -> {
            logger.error(" Unable to update request map value into Redis {}", onError);
        }).doOnSuccess(onSuccess -> {
            logger.info("Successfully updated Cart Redis Data: {}", onSuccess);
        }).flatMap(response -> {
            try {
                logger.info("CartCreator upserted into Redis: {} | AppName: CartService",mapper.writeValueAsString(requestMap));
            } catch (JsonProcessingException e) {
                logger.error(CartConstants.JSON_PRCSSNG_EXCPTN_STRNG + "{}", e);
            }
            return Mono.just(response);
        });
    }

    /**
     *
     * @param referenceMtn1
     * @param referenceMtn2
     * @param cartCreator
     * @return Boolean
     */
    public Mono<Boolean> updateWFMFlowDataInRedis(String referenceMtn1, String referenceMtn2, String referenceIntendType, String cartCreator) {
        Map<String, String> requestMap = new HashMap<>();
        if (StringUtilities.isNotEmptyOrNull(referenceIntendType) &&
                referenceIntendType.toUpperCase().contains("NSE")) {
            requestMap.put(ACCOUNT_NUMBER, "");
        }
        if(StringUtilities.isEmptyOrNull(referenceMtn1) && StringUtilities.isEmptyOrNull(referenceMtn2))
            requestMap.put(CartConstants.CART_CREATOR, cartCreator);
        if(requestMap.isEmpty())
            return Mono.just(Boolean.TRUE);
        return sessionBean.setSessionData(requestMap).doOnError(onError -> {
            logger.error("updateWFMFlowDataInRedis: Unable to update request map value into Redis {}", onError);
        }).doOnSuccess(onSuccess -> {
            logger.info("updateWFMFlowDataInRedis: Successfully updated Cart Redis Data: {}", onSuccess);
        }).flatMap(data -> {
            try {
                logger.info("CartCreator upserted into Redis: {} | updateWFMFlowDataInRedis",mapper.writeValueAsString(requestMap));
            } catch (JsonProcessingException e) {
                logger.error(CartConstants.JSON_PRCSSNG_EXCPTN_STRNG + "{}", e);
            }
            return Mono.just(data);
        });
    }

    /**
     *
     * @param cartCreator
     * @return Boolean
     */
    public Mono<Boolean> updateCartCreatorInRedis(String cartCreator) {
        Map<String, String> requestMap = new HashMap<>();
        requestMap.put(CartConstants.CART_CREATOR, cartCreator);
        return sessionBean.setSessionData(requestMap).flatMap(data -> {
            return Mono.just(data);
        });
    }

    /**
     * return Mono boolean
     */
    public Mono<Boolean> isWFMFlow() {
        return sessionBean.getSessionData(RedisConstants.IS_WFM_FLOW, String.class).onErrorReturn("").defaultIfEmpty("")
                .flatMap(data -> {
                    logger.info("Reading isWFMFlow request- value: {} ",data);
                    if("Y".equalsIgnoreCase(data))
                        return Mono.just(Boolean.TRUE);
                    else
                        return Mono.just(Boolean.FALSE);
                });
    }
    public Mono<Map<String, Object>> getMTNFromRedis(String[] sessionKeys) {
        return sessionBean.getSessionData(Arrays.asList(new String[]{MTN,CUST_TYPE})).onErrorReturn(new HashMap<>())
                .defaultIfEmpty(new HashMap<>()).flatMap(data -> {
                    logger.info("Retrieved MTN from Redis, data = {}", data);
                    Map<String, Object> dataMap = new HashMap<>();
                    if(data.containsKey(MTN) && null != data.get(MTN)){
                        dataMap.put("mtn",data.get(MTN).toString());
                    }
                    logger.info("data from cache: {}", data);
                    Optional.ofNullable(data).filter(d -> d.containsKey(CUST_TYPE) && null != data.get(CUST_TYPE)).ifPresent(d -> dataMap.put(CUST_TYPE, data.get(CUST_TYPE).toString()));
                    return Mono.just(dataMap);

                }).switchIfEmpty(Mono.defer(() -> Mono.just(new HashMap<>())));
    }

    public Mono<Void> updatespoMtn(String mtn)
    {
        Map<String, String> requestMap = new HashMap<>();
        requestMap.put(CartConstants.SPO_MTN, mtn);
        logger.info("update SPO mtn in Redis...");
        sessionBean.setSessionData(requestMap).subscribe();
        return Mono.empty();
    }

    public Mono<Void> upsertCRSP(String crsp)
    {
        Map<String, String> requestMap = new HashMap<>();
        requestMap.put(CartConstants.CRSP, crsp);
        logger.info("upsert crsp data into Redis");
        sessionBean.setSessionData(requestMap)
                .doOnError(error -> logger.error("CRSP::Redis upsert failed : {}", error))
                .doOnSuccess(msg -> logger.info("CRSP::Redis upsert successful : {}", msg))
                .subscribeOn(Schedulers.parallel())
                .subscribe();
        return Mono.empty();
    }

    public Mono<TechFlowRedisData> fetchTechFlowAuditDetails() {
        TechFlowRedisData tRedisData = new TechFlowRedisData();
        List<String> redisSessionKeys = Arrays.asList(CartConstants.TECHFLOW_SERVICE_ADDRESS, CartConstants.FIVEG_PLAN,CartConstants.VPM_ORDER_NUMBER,CartConstants.VPM_LOCATION_CODE,CartConstants.INTENTTYPE);
        return sessionBean.getSessionData(redisSessionKeys)
                .onErrorReturn(new HashMap<Object, Object>()).defaultIfEmpty(new HashMap<Object, Object>())
                .flatMap(data -> {
                    if(data.containsKey(CartConstants.TECHFLOW_SERVICE_ADDRESS) && null != data.get(CartConstants.TECHFLOW_SERVICE_ADDRESS)) {
                        tRedisData.setServiceAddress(String.valueOf(data.get(CartConstants.TECHFLOW_SERVICE_ADDRESS)));
                    }
                    if(data.containsKey(CartConstants.FIVEG_PLAN) && null != data.get(CartConstants.FIVEG_PLAN)) {
                        tRedisData.setFiveGPlan(String.valueOf(data.get(CartConstants.FIVEG_PLAN)));
                    }
                    if(data.containsKey(CartConstants.VPM_ORDER_NUMBER) && null != data.get(CartConstants.VPM_ORDER_NUMBER)) {
                        tRedisData.setVpmOrderNum(String.valueOf(data.get(CartConstants.VPM_ORDER_NUMBER)));
                    }
                    if(data.containsKey(CartConstants.VPM_LOCATION_CODE) && null != data.get(CartConstants.VPM_LOCATION_CODE)) {
                        tRedisData.setVpmLocationCode(String.valueOf(data.get(CartConstants.VPM_LOCATION_CODE)));
                    }
                    if(data.containsKey(CartConstants.INTENTTYPE) && null != data.get(CartConstants.INTENTTYPE)) {
                        tRedisData.setIntentType(String.valueOf(data.get(CartConstants.INTENTTYPE)));
                    }
                    return Mono.just(tRedisData);
                });
    }

    public Mono<MoversRedisData> fiveGRedisMoversData() {
        MoversRedisData redisData=new MoversRedisData();
        List<String> redisSessionKeys = Arrays.asList(CartConstants.CASE_ID,CartConstants.CART_ID,
                CartConstants.MOVERS_MTN,CartConstants.MOVERS_PROCESSSTEP,CartConstants.NETWORK_BANDWIDTH_TYPE,CartConstants.PREV_NETWORK_BANDWIDTH_TYPE,CartConstants.AQ_CASE_ID, ACCOUNT_NUMBER,CartConstants.MOVERS_ACC_INFO_KEY,CartConstants.COMPLETED_CARTID_CONST, CartConstants.CRSP,CartConstants.SAFETECH_SESSION_ID, CartConstants.FINAL_PLAN_PRICE);
        return sessionBean.getSessionData(redisSessionKeys)
                .onErrorReturn(new HashMap<Object, Object>()).defaultIfEmpty(new HashMap<Object, Object>())
                .flatMap(data -> {
                    getRedisExtraParams(data,redisData);

                    if(data.containsKey(CartConstants.NETWORK_BANDWIDTH_TYPE) && null!=data.get(CartConstants.NETWORK_BANDWIDTH_TYPE))
                    {
                        redisData.setNetworkBandwidthType(data.get(CartConstants.NETWORK_BANDWIDTH_TYPE).toString().toUpperCase());
                    }
                    if(data.containsKey(ACCOUNT_NUMBER) && null!=data.get(ACCOUNT_NUMBER))
                    {
                        redisData.setAccountNumber((String) data.get(ACCOUNT_NUMBER));
                    }
                    if(data.containsKey(CartConstants.MOVERS_MTN) && null!=data.get(CartConstants.MOVERS_MTN))
                    {
                        redisData.setMoversMtn((String) data.get(CartConstants.MOVERS_MTN));
                    }
                    if(data.containsKey(CartConstants.FWA_SAFE_TECH_SESSION_ID_KEY) && null!=data.get(CartConstants.FWA_SAFE_TECH_SESSION_ID_KEY))
                    {
                        redisData.setSafeTechSessionId((String) data.get(CartConstants.FWA_SAFE_TECH_SESSION_ID_KEY));
                    }
                    if(data.containsKey(CartConstants.MOVERS_ACC_INFO_KEY) && null!=data.get(CartConstants.MOVERS_ACC_INFO_KEY))
                    {
                        try {
                            redisData.setMoversFWALinesInfo(mapper.readValue(data.get(CartConstants.MOVERS_ACC_INFO_KEY).toString(), Map.class));
                        } catch (JsonProcessingException e) {
                            logger.info("exception while processing moversFWALinesInfo redis key");
                        }
                    }
                    if(data.containsKey(CartConstants.CRSP) && null!=data.get(CartConstants.CRSP))
                    {
                        redisData.setCrsp((String) data.get(CartConstants.CRSP));
                    }
                    if(data.containsKey(CartConstants.FINAL_PLAN_PRICE) && null!=data.get(CartConstants.FINAL_PLAN_PRICE))
                    {
                        try {
                            redisData.setFinalPlanPrice(mapper.readValue(data.get(CartConstants.FINAL_PLAN_PRICE).toString(), Map.class));
                        } catch (JsonProcessingException e) {
                            logger.info("exception while processing finalPlanPrice redis key");
                        }
                    }
                    return Mono.just(redisData);
                });
    }

    public void getRedisExtraParams(Map<Object,Object> data, MoversRedisData redisData){
        if(data.containsKey(CartConstants.CART_ID) && null!=data.get(CartConstants.CART_ID))
        {
            redisData.setCartId((String) data.get(CartConstants.CART_ID));
        }
        if(data.containsKey(CartConstants.COMPLETED_CARTID_CONST) && null!=data.get(CartConstants.COMPLETED_CARTID_CONST))
        {
            redisData.setCompletedCartId((String) data.get(CartConstants.COMPLETED_CARTID_CONST));
        }
        if(data.containsKey(CartConstants.CASE_ID) && null!=data.get(CartConstants.CASE_ID))
        {
            redisData.setCaseId((String) data.get(CartConstants.CASE_ID));
        }
        if(data.containsKey(CartConstants.MOVERS_MTN) && null!=data.get(CartConstants.MOVERS_MTN))
        {
            redisData.setMoversMtn((String) data.get(CartConstants.MOVERS_MTN));
        }
        if(data.containsKey(CartConstants.MOVERS_PROCESSSTEP) && null!=data.get(CartConstants.MOVERS_PROCESSSTEP))
        {
            redisData.setMoverNextProcessStep((String) data.get(CartConstants.MOVERS_PROCESSSTEP));
        }
        if(data.containsKey(CartConstants.PREV_NETWORK_BANDWIDTH_TYPE) && null!=data.get(CartConstants.PREV_NETWORK_BANDWIDTH_TYPE))
        {
            redisData.setPrevNetworkBandwidthType((String) data.get(CartConstants.PREV_NETWORK_BANDWIDTH_TYPE));
        }
        if(data.containsKey(CartConstants.AQ_CASE_ID) && null!=data.get(CartConstants.AQ_CASE_ID))
        {
            redisData.setAqCaseId((String) data.get(CartConstants.AQ_CASE_ID));
        }

    }

    public Mono<Map> getFiveGAddressFromRedisForMovers(){
        return sessionBean.getSessionData(Arrays.asList(new String[]{CartConstants.MOVERS_ADDRES_QUAL_RESPONSE,CartConstants.MOVERS_MTN,CartConstants.NETWORK_BANDWIDTH_TYPE,CartConstants.PREV_NETWORK_BANDWIDTH_TYPE,CartConstants.AQ_CASE_ID, ACCOUNT_NUMBER}))
                .onErrorReturn(new HashMap<Object, Object>()).defaultIfEmpty(new HashMap<Object, Object>());

    }
    public MoversQualPegaResponse getMoversQualPegaResponse(Map data) throws JsonProcessingException {
        return mapper.readValue(data.get(CartConstants.MOVERS_ADDRES_QUAL_RESPONSE).toString(),MoversQualPegaResponse.class);
    }
    protected String settingDataIntoRedisAsString(Map requestMap, CartRedisData request,String aalPromoInterceptString, String itemType, String requestString, boolean isUpsertDataIntoRedisAsString) {

        if (!isUpsertDataIntoRedisAsString && CollectionUtilities.isNotEmptyOrNull(request.getLines()))
            requestMap.put(CartConstants.PROMOHUB_SPOKE_JOURNEY, request.getSpokeJourney());
        if (CollectionUtilities.isNotEmptyOrNull(request.getLines())) {
            if (StringUtilities.isNotEmptyOrNull(request.getLines().get(0).getRestrictedProductType()))
                requestMap.put(CartConstants.RESTRICTED_PRODUCT_TYPE,
                        request.getLines().get(0).getRestrictedProductType());
        }
        try {
            requestString = mapper.writeValueAsString(request);
            String aalPromoInterceptString1;
            if (null != request.getShowAALPromoIntercept())
                aalPromoInterceptString1 = mapper.writeValueAsString(request.getShowAALPromoIntercept());
        } catch (JsonProcessingException e) {
            logger.error("Error parsing JSON: {}", e);
        }
        if (CartConstants.DEVICE.equalsIgnoreCase(itemType)) {
            requestMap.put(CartConstants.ADD_DEVICE_REQUEST, requestString);
            if (null != request.getDeviceCartInfo()
                    && StringUtilities.isNotEmptyOrNull(request.getDeviceCartInfo().getMtnFlow()))
                requestMap.put(CartConstants.MTN_FLOW, request.getDeviceCartInfo().getMtnFlow());
            if (StringUtilities.isNotEmptyOrNull(request.getDeviceSorIdForRecommendations())) {
                requestMap.put(CartConstants.RECOMMENDATIONS_DEVICE_SOR_ID, request.getDeviceSorIdForRecommendations());
            }
            //upsertDataIntoRedisAsString
            if (isUpsertDataIntoRedisAsString && StringUtilities.isNotEmptyOrNull(request.getDeviceSorId()))
                requestMap.put(CartConstants.DEVICE_SOR_ID, request.getDeviceSorId());
        } else if (CartConstants.ACCESSORY.equalsIgnoreCase(itemType)) {
            requestMap.put(CartConstants.ADD_ACCESSORY_REQUEST, requestString);
            if (StringUtilities.isNotEmptyOrNull(request.getAccessorySorIdForRecommendations())) {
                requestMap.put(CartConstants.RECOMMENDATIONS_ACCESSORY_SOR_ID, request.getAccessorySorIdForRecommendations());
            }
        }
        return aalPromoInterceptString;
    }

    protected Mono<Boolean> settingReturnSessionData(Map requestMap, Object request) {
        return sessionBean.setSessionData(requestMap).doOnError(onError -> {
            logger.error(" Unable to update request map value into Redis {}", onError);
        }).doOnSuccess(onSuccess -> {
            logger.info("Successfully updated Cart Redis Data: {}", onSuccess);
        }).flatMap(response -> {
            try {
                logger.info(String.format(CartConstants.REDIS_DATA_LOG_CONTENT,mapper.writeValueAsString(request)));
            } catch (JsonProcessingException e) {
                logger.error(CartConstants.JSON_PRCSSNG_EXCPTN_STRNG + "{}", e);
            }
            return Mono.just(response);
        });
    }

    public Mono<Boolean> updatePastDueDataInRedis(PastDueRedisData pastDueRedisData) {
        return sessionBean.setSessionData(CartConstants.PAST_DUE, pastDueRedisData).
                doOnError(onError -> {
                    logger.error(" Unable to set Redis key" + CartConstants.PAST_DUE);
                }).doOnSuccess(onSuccess -> {
            logger.info(" Updated Redis key " + CartConstants.PAST_DUE);
        }).onErrorReturn(Boolean.FALSE).defaultIfEmpty(Boolean.TRUE).flatMap(data -> {
            logger.info("Response: {}" , data);
            return Mono.just(data);
        });
    }
    public Mono<UpdateDetailsToRedisResponse> updateConflictStatusToRedis(UpdateConflictStatusRequest request) {
        if (null != request) {
            UpdateDetailsToRedisResponse responseData = new UpdateDetailsToRedisResponse();

            return sessionBean.setSessionData(CartConstants.CONFLICTS_ACCEPTED_KEY, request.isConflictsAccepted()).doOnError(onError -> {
                logger.error("Update conflictsAccepted To Session FAILED", onError);
            }).doOnSuccess(onSuccess -> {
                responseData.setStatus("0");
                logger.info("Add conflictsAccepted To Session Success");
            }).onErrorReturn(Boolean.FALSE).defaultIfEmpty(Boolean.TRUE).flatMap(response -> {
                ErrorResponse errors2;

                if (!response) {
                    errors2 = CartPegaResponseErrorsUtil.handleUpdateDetailsToSessionErrors(false);
                    responseData.setErrorResponse(errors2);
                } else {
                    responseData.setMessage("Success");
                    responseData.setStatus("0");
                }
                return Mono.just(responseData);
            });
        }
        return Mono.just(new UpdateDetailsToRedisResponse());
    }
    public Mono<Boolean>getConflictsStatusFromSession(){
        return sessionBean.getSessionData(CartConstants.CONFLICTS_ACCEPTED_KEY, Boolean.class)
                .onErrorReturn(false).defaultIfEmpty(false).flatMap(data -> {
                    logger.info("Reading conflictsAccepted: {}", data);
                    return Mono.just(data);
                });
    }
    public Mono<Void> resetConflictReviewStatus()
    {
        logger.info("update conflictsAccepted in Session...");
        sessionBean.setSessionData(CartConstants.CONFLICTS_ACCEPTED_KEY, false).subscribe();
        return Mono.empty();
    }

    public Mono<Boolean> updateConflictStatus(){

        return sessionBean.setSessionData(CartConstants.CONFLICTS_ACCEPTED_KEY, false)
                .onErrorReturn(false).defaultIfEmpty(false).flatMap(data -> {
                    logger.info(String.format("Reading conflictsAccepted: {} --> %s" , data));
                    return Mono.just(data);
                });
    }

    public Mono<UpdateDetailsToRedisResponse> addPlanAndPerksToRedis(AddPlanUIRequest request) {
        if (Optional.ofNullable(request.getData()).isPresent()) {
            UpdateDetailsToRedisResponse responseData = new UpdateDetailsToRedisResponse();
            return sessionBean.setSessionData(CartConstants.ADD_PLAN_REQUEST_KEY, request.getData()).doOnError(onError -> {
                logger.error("Update Add Plan Request To Session FAILED", onError);
            }).doOnSuccess(onSuccess -> {
                responseData.setStatus("0");
                logger.info("Add Plan Request Response To Session");
            }).onErrorReturn(Boolean.FALSE).defaultIfEmpty(Boolean.TRUE).flatMap(response -> {
                ErrorResponse errors2 = null;

                if (!response) {
                    errors2 = CartPegaResponseErrorsUtil.handleUpdateDetailsToSessionErrors(false);
                    responseData.setErrorResponse(errors2);
                } else {
                    responseData.setMessage("Success");
                    responseData.setStatus("0");
                }
                return Mono.just(responseData);
            });

        }
        return Mono.just(new UpdateDetailsToRedisResponse());
    }

    public Mono<String> getMtnData(String key,String mtnData){
        return sessionBean.getSessionData(key, Map.class).onErrorReturn(new HashMap<String, String>())
                .defaultIfEmpty(new HashMap<String, String>()).flatMap(data -> {
                    logger.info(String.format("Reading mtn data: %s " , data));
                    return Mono.just(String.valueOf(data.get(mtnData)));
                });
    }


    public Mono<CustomerInfo> fetchProfileInfoFromRedis() {

        CustomerInfo customerInfo =new CustomerInfo();
        return sessionBean.getSessionData(Arrays.asList(ACCOUNT_NUMBER,MTN)).onErrorReturn(new HashMap<String, String>())
                .defaultIfEmpty(new HashMap<String, String>()).flatMap( data -> {
                    if (data.containsKey(ACCOUNT_NUMBER)) {
                        customerInfo.setAccountNumber((String) data.get(ACCOUNT_NUMBER));
                    }
                    if (data.containsKey(MTN)) {
                        customerInfo.setCartCreator((String) data.get(MTN));
                    }
                    return Mono.just(customerInfo);
                });
    }
    public Mono<CartRedisData> getDataFromRedis() {
        CartRedisData rr = new CartRedisData();
        return sessionBean
                .getSessionData(Arrays.asList(new String[]{CartConstants.PLAN_SELECTION_PATH}))
                .onErrorReturn(new HashMap<Object, Object>()).defaultIfEmpty(new HashMap<Object, Object>())
                .flatMap(data -> {
                    if(data.containsKey(CartConstants.PLAN_SELECTION_PATH) && null != data.get(CartConstants.PLAN_SELECTION_PATH)
                            && StringUtils.isNotEmpty((String)data.get(CartConstants.PLAN_SELECTION_PATH)))
                        rr.setPlanSelectionPath(getPlanPathDetails((String)data.get(CartConstants.PLAN_SELECTION_PATH)));
                    return Mono.just(rr);
                });
    }

    private Map<String,Map<String,String>> getPlanPathDetails(String planPathDetails){
        logger.info("getPlanPathDetails data : {}",planPathDetails);
        Map<String,Map<String,String>> planPathDetailsMap= Collections.EMPTY_MAP;
        try {
            planPathDetailsMap = JacksonMapperFactory.defaultReader().forType(Map.class).readValue(planPathDetails);
        } catch (JsonProcessingException e) {
            logger.error("Exception in getPlanPathDetails:",e);
        }
        return planPathDetailsMap;
    }
}
