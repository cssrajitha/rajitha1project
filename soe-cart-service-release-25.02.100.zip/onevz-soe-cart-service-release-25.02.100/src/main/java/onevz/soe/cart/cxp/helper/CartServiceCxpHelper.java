package onevz.soe.cart.cxp.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.cxp.service.CatalogService;
import onevz.soe.cart.cxp.service.OrderProcessCXPServices;
import onevz.soe.cart.gql.requests.ACPCustomerInfoGQL;
import onevz.soe.cart.gql.requests.ACPInfoGQL;
import onevz.soe.cart.gql.schema.newCustomer.BillingAddress;
import onevz.soe.cart.gql.schema.newCustomer.ContactInfo;
import onevz.soe.cart.gql.schema.newCustomer.CustomerProfileForNSE;
import onevz.soe.cart.helper.FeatureFlagHelper;
import onevz.soe.cart.helper.FiveGhomeCommonHelper;
import onevz.soe.cart.helper.RedisHelper2;
import onevz.soe.cart.helper.RedisHelper3;
import onevz.soe.cart.model.common.FiveG.FiveGLTEAddressRedis;
import onevz.soe.cart.model.common.SmartImeiTypeAheadDetails;
import onevz.soe.cart.model.elasticsearch.Brands;
import onevz.soe.cart.model.elasticsearch.DeviceAndCarrier;
import onevz.soe.cart.model.elasticsearch.TypeAheadData;
import onevz.soe.cart.model.orderConfirmation.CXPOrderConfirmation5GDataVO;
import onevz.soe.cart.model.retrieveCart.*;
import onevz.soe.cart.model.validateCart.CXPValidateCartDataVO;
import onevz.soe.cart.omnidl.OmniBuilder;
import onevz.soe.cart.requests.*;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.smartimeisearch.constants.SmartImeiSearchConstants;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.cart.util.*;
import onevz.soe.logging.util.LoggerUtil;
import onevz.soe.omnidl.service.OmniDLService;
import onevz.soe.omnidl.util.DLUtilityService;
import onevz.soe.spring.web.filter.RequestAccessContext;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.utilities.serialization.JacksonMapperFactory;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.util.Lists;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

/**
 * CartService Cxp Helper class.
 */
@Service
public class CartServiceCxpHelper {

	private static final Logger logger = LoggerFactory.getLogger(CartServiceCxpHelper.class);

	@Value("${onevz.soe.accountlanding.gqlPromoBundleBuilderOptmizationEnabled:true}")
	private boolean gqlPromoBundleBuilderOptmizationEnabled;

	@Autowired
	private CartServiceCXPServices cxpService;
	@Autowired
	private OrderProcessCXPServices orderCxpService;

	@Autowired
	private CatalogService catalogService;

	@Autowired
	OmniDLService dlService;

	@Autowired
	private DLUtilityService dlUtilityService;

	@Autowired
	private RedisHelper2 redisHelper2;

	@Autowired
	private RedisHelper3 redisHelper3;

	@Autowired
	private CatalogServiceHelper catalogServiceHelper;
	@Autowired
	private ObjectMapper mapper;
	
	@Autowired
    private CommonUtil util;

	@Autowired
	private FiveGhomeCommonHelper fiveGhomeCommonHelper;


	@Value("${enableOptimisedDigitalRetrieveCart}")
	private boolean enableOptimisedDigitalRetrieveCart;

	@Value("${smart.imei.empty.carrier.altname:OTHER}")
	private String SMART_IMEI_EMPTY_CARRIER_ALT_NAME;

	@Value("${smart.imei.typeahead.merge.enabled:Y}")
	private String SMART_IMEI_TYPEAHEAD_MERGE_ENABLED;

	@Value("${smart.imei.empty.carrier.device.enabled:Y}")
	private String EMPTY_CARRIER_DEVICES_FOR_SMART_IMEI_ENABLED;
	
	@Value("${smart.imei.supress.carriers:other}")
	private String SMART_IMEI_SUPPRESS_CARRIERS;
	
	@Value("${enableESimDevicesWithoutSuffix:false}")
	private boolean enableESimDevicesWithoutSuffix;
	
	@Value("#{'${smart.imei.typeahead.simOutKeywords:}'.split(',')}")
	private List<String> simOutWordList;

	@Value("${LOCAL_STORE_OFFER_CAT_CODES:VBMOFFER6,DISCPROMO}")
	private String localStoreOfferCatCodes;
	
	@Value("#{'${unlimitedPlanCategoryCodes:}'.split(',')}")
	private List<String> unlimitedPlansCatCodes;

	@Value("${byod.brands.smartphones:Apple}")
	private List<String> smartPhonesBrands;
	@Value("${byod.brands.tablets:Apple}")
	private List<String> tabletsBrands;

	@Value("#{'${NO_PROMO_DQ_REASON_CODES:}'.split(',')}")
	private List<String> noPromoDQreasonCodesList;

	@Autowired
	FeatureFlagHelper featureFlag;


	/**
	 *
	 * @param request
	 * @return RetrieveCartUIResponse
	 *
	 */
	public Mono<RetrieveCartUIResponse> retrieveCart(RetrieveCartCXPRequest request) {

		// check for empty cart id in request before cxp call
		if (StringUtilities.isEmptyOrNull(request.getData().getCartId()))
			return CartCxpResponseUtil.formatRetrieveCartEmptyErrorResponse();
		formatRequest(request);
		// substitute the qurey param & form graphql query
		String graphqlType = request.getMeta().get("type");

		Mono<RetrieveCartCXPResponse> responseServiceMono;
		// call to cxp graphql endpoint
		if (StringUtilities.isNotEmptyOrNull(graphqlType) && CartConstants.NEWCUSTOMER.equalsIgnoreCase(graphqlType)) {
			responseServiceMono = cxpService.retrieveCartNewCustomer(request.getData().getCartId(),
					request.getData().getRetrieveCurrentFeatures(), request.getData().getMtnList());
		} else if (StringUtilities.isNotEmptyOrNull(graphqlType) && "billingAddress".equalsIgnoreCase(graphqlType))
			responseServiceMono = cxpService.billingAddress(request.getData().getCartId(),
					request.getData().getRetrieveCurrentFeatures(), request.getData().getMtnList());
		else if (StringUtilities.isNotEmptyOrNull(graphqlType) && "numberShare".equalsIgnoreCase(graphqlType))
			responseServiceMono = cxpService.numberShare(request.getData().getCartId(),
					request.getData().getRetrieveCurrentFeatures(), request.getData().getMtnList());
		else if (StringUtilities.isNotEmptyOrNull(graphqlType) && "e911Address".equalsIgnoreCase(graphqlType))
			responseServiceMono = cxpService.cartE911Address(request.getData().getCartId(),
					request.getData().getRetrieveCurrentFeatures(), request.getData().getMtnList());
		else if (StringUtilities.isNotEmptyOrNull(graphqlType) && "deviceDetails".equalsIgnoreCase(graphqlType))
			responseServiceMono = cxpService.deviceDetails(request.getData().getCartId(),
					request.getData().getRetrieveCurrentFeatures(), request.getData().getMtnList());
		else if (StringUtilities.isNotEmptyOrNull(graphqlType) && "shippingInfo".equalsIgnoreCase(graphqlType))
			responseServiceMono = cxpService.shippingInfo(request.getData().getCartId(),
					request.getData().getRetrieveCurrentFeatures(), request.getData().getMtnList());
		else if (StringUtilities.isNotEmptyOrNull(graphqlType) && "agreementInfo".equalsIgnoreCase(graphqlType))
			responseServiceMono = cxpService.agreementInfo(request.getData().getCartId(),
					request.getData().getRetrieveCurrentFeatures(), request.getData().getMtnList());
		else if (StringUtilities.isNotEmptyOrNull(graphqlType) && "effectiveDateDetails".equalsIgnoreCase(graphqlType))
			responseServiceMono = cxpService.effectiveDateDetails(request.getData().getCartId(),
					request.getData().getRetrieveCurrentFeatures(), request.getData().getMtnList());
		else if (StringUtilities.isNotEmptyOrNull(graphqlType) && "cartItems".equalsIgnoreCase(graphqlType))
			responseServiceMono = cxpService.cartItems(request.getData().getCartId(),
					request.getData().getRetrieveCurrentFeatures(), request.getData().getMtnList());
		else if (StringUtilities.isNotEmptyOrNull(graphqlType)
				&& "deviceItemsCountInCart".equalsIgnoreCase(graphqlType))
			responseServiceMono = cxpService.deviceCountInCart(request.getData().getCartId(),
					request.getData().getRetrieveCurrentFeatures(), request.getData().getMtnList());
		else if (StringUtilities.isNotEmptyOrNull(graphqlType) && "taxAndDues".equalsIgnoreCase(graphqlType))
			responseServiceMono = cxpService.taxAndDues(request.getData().getCartId(),
					request.getData().getRetrieveCurrentFeatures(), request.getData().getMtnList());
		else if (isDigitalOptimsedRetrieveCart(request, graphqlType))
			responseServiceMono = cxpService.retrieveCartDigital(request.getData().getCartId(),
					request.getData().getRetrieveCurrentFeatures(), request.getData().getMtnList());
		else if (isNewNumberPortInRetrieveCart(request, graphqlType))
			responseServiceMono = cxpService.retrieveCartNewNumberPortIn(request.getData().getCartId(),
					request.getData().getRetrieveCurrentFeatures(), request.getData().getMtnList());
		else
			responseServiceMono = cxpService.retrieveCart(request.getData().getCartId(),
					request.getData().getRetrieveCurrentFeatures(), request.getData().getMtnList());
		RetrieveCartUIResponse soeResponse = new RetrieveCartUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(cartResponse -> {
			if ("deviceDetails".equalsIgnoreCase(graphqlType) || "numberShare".equalsIgnoreCase(graphqlType)) {
				cartResponse = CartCxpResponseUtil.formatResponseCartItemType(cartResponse, graphqlType);
			}
			if ("deviceItemsCountInCart".equalsIgnoreCase(graphqlType)) {
				cartResponse = CartCxpResponseUtil.getDeviceCount(cartResponse);
			}
			boolean bmsmFlag = featureFlag.bmsmFeatureFlag(cartResponse);
			// convert cxpResponse into soeResponse
			CartCxpResponseUtil1.formatRetrieveCartResponse(soeResponse, cartResponse, request.isUnifiedNbsFlag(), bmsmFlag);
			if(soeResponse.getData() != null && soeResponse.getData().getCart() != null
					&& soeResponse.getData().getCart().getLineDetails() != null) {
				soeResponse.getData().getCart().getLineDetails().setEnableLineInfoFFlag(featureFlag.isLineInfoFeatureFlag());
				if(ArrayUtils.isNotEmpty(soeResponse.getData().getCart().getLineDetails().getLineInfo())){
					performMaskingForBYOD(soeResponse.getData().getCart());
				}
			}
			if ("cartItems".equalsIgnoreCase(graphqlType)) {
				Optional.ofNullable(soeResponse).map(RetrieveCartUIResponse::getData)
						.map(CXPRetrieveCartDataVO::getCart).map(CXPCartVO::getLineDetails).ifPresent(lineDetails -> {
							Arrays.stream(lineDetails.getLineInfo()).filter(Objects::nonNull).forEach(lineInfo -> {
								Arrays.stream(lineInfo.getItemsInfo()).filter(Objects::nonNull).forEach(itemsInfo -> {
									Optional.ofNullable(itemsInfo).map(CXPItemInfo::getCartItems)
											.ifPresent(cartItems -> {
												Arrays.stream(cartItems.getCartItem()).filter(Objects::nonNull)
														.forEach(cartItem -> {
															if (CartConstants.DEVICE
																	.equalsIgnoreCase(cartItem.getCartItemType()))
																soeResponse.getData().setCartHasItems(true);

														});
											});
								});
							});
						});
			}

			if (StringUtilities.isEmptyOrNull(graphqlType) && null != cartResponse.getData()) {
				try {
					updateDLData(cartResponse, null, "Retrieve", null, null,null);
				} catch (Exception e) {
					logger.error(CartConstants.RETRIEVE_OMNIDL_EXCEPTION, e);
				}
			}

			// set banner messages for CDE plan changes
			if (soeResponse.getData() != null && soeResponse.getData().getCart() != null
					&& soeResponse.getData().getCart().getLineDetails() != null
					&& soeResponse.getData().getCart().getLineDetails().getLineInfo() != null) {

				Set<String> planIds = new HashSet<>();
				List<String> deviceSorIds = new ArrayList<>();
				List<String> accessorySkuIds = new ArrayList<>();

				List<CXPLineInfo> cxpLineinfoList = Arrays
						.asList(soeResponse.getData().getCart().getLineDetails().getLineInfo());
				if (CollectionUtilities.isNotEmptyOrNull(cxpLineinfoList)) {
					cxpLineinfoList.stream().filter(cxpLineinfo -> cxpLineinfo != null
									&& cxpLineinfo.getServiceInfo() != null
									&& StringUtilities.isNotEmptyOrNull(cxpLineinfo.getServiceInfo().getOldPricePlanId())
									&& StringUtilities.isNotEmptyOrNull(cxpLineinfo.getServiceInfo().getNewPricePlanId()))
							.forEach(cxpLineInfo -> {
								planIds.add(cxpLineInfo.getServiceInfo().getOldPricePlanId());
								planIds.add(cxpLineInfo.getServiceInfo().getNewPricePlanId());
							});

					cxpLineinfoList.stream().filter(cxpLineinfo1 -> cxpLineinfo1 != null).forEach(cxpLineinfo1 -> {
						if (cxpLineinfo1.getItemsInfo() != null) {
							Arrays.stream(cxpLineinfo1.getItemsInfo()).filter(Objects::nonNull).forEach(itemsInfo -> {
								Optional.ofNullable(itemsInfo).map(CXPItemInfo::getCartItems).ifPresent(cartItems -> {
									Arrays.stream(cartItems.getCartItem()).filter(Objects::nonNull)
											.forEach(cartItem -> {
												if (CartConstants.DEVICE.equalsIgnoreCase(cartItem.getCartItemType())) {
													deviceSorIds.add(cartItem.getSorId());
													// This checks if the Upgrade Reason Code is not in the list and sets flag isBYODBICDQedForURC to drop BYOD BIC rpomo.
													if (!StringUtilities.isEmptyOrNull(cartItem.getUpgradeReasonCode()) && !noPromoDQreasonCodesList.contains(cartItem.getUpgradeReasonCode())) {
														cxpLineinfo1.setIsBYODBICDQedForURC(true);
													}
												}

												if (CartConstants.ACCESSORY.equalsIgnoreCase(cartItem.getCartItemType())) {
													if (cartItem.getTotalPriceWithDiscount() >= 65) {
														accessorySkuIds.add(cartItem.getSorId());
													}
													soeResponse.getData().setCartHasAccessories(true);
												}

											});
								});
							});
						}

						//TMP-4672
						if (cxpLineinfo1.getServiceInfo() != null
								&& cxpLineinfo1.getServiceInfo().getSelectedFeaturesList() != null
								&& CollectionUtilities.isNotEmptyOrNull(cxpLineinfo1.getServiceInfo().getSelectedFeaturesList().getVisFeature())) {
							soeResponse.getData().setIscartHasVZHP(cxpLineinfo1.getServiceInfo()
									.getSelectedFeaturesList().getVisFeature().stream()
									.anyMatch(visFeature -> visFeature != null && visFeature.getVisFeatureCode() != null
											&& CartConstants.VZHP_FEATUREID.equalsIgnoreCase(visFeature.getVisFeatureCode())));
						}


					});
				}


				Arrays.asList(soeResponse.getData().getCart().getLineDetails().getLineInfo()).stream().forEach(soeLineInfo -> {
					if (soeLineInfo.getServiceInfo() != null && soeLineInfo.getServiceInfo().getPricePlanInfo() != null && soeLineInfo.getServiceInfo().getNewPricePlanInfo() != null
							&& unlimitedPlansCatCodes.contains(soeLineInfo.getServiceInfo().getPricePlanInfo().getCategoryCode())
							&& unlimitedPlansCatCodes.contains(soeLineInfo.getServiceInfo().getNewPricePlanInfo().getCategoryCode())) {
						soeLineInfo.getServiceInfo().setComparePlan(Boolean.TRUE);
					}
				});

				// check if the account is eligible for local store offers
				checkForLocalStoreOffers(request, soeResponse, cxpLineinfoList);

				List<String> catalogReqPlanIds = planIds.stream().collect(Collectors.toList());
				// making domain api call
				return catalogServiceHelper.getCatalogDomainData(catalogReqPlanIds, deviceSorIds, accessorySkuIds, null, null)
						.flatMap(domainCatalogRes -> {
							CartCxpResponseUtil1.setWarningMessageonCDEPlanchange(domainCatalogRes, request,
									soeResponse);
							CartCxpResponseUtil.setDeviceCategoryFlags(domainCatalogRes, soeResponse);
							CartCxpResponseUtil.setAccessoryProtectionFlags(domainCatalogRes, soeResponse);
							return redisHelper3.upsertCartCreator(soeResponse).flatMap(da -> getRetrieveCartUIResponseMono(soeResponse,request));

						});
			}
			return Mono.just(soeResponse);
		});

	}

	private Mono<RetrieveCartUIResponse> getRetrieveCartUIResponseMono(RetrieveCartUIResponse soeResponse, RetrieveCartCXPRequest request) {

		soeResponse.getData().setUpc(StringUtilities.isNotEmptyOrNull(request.getData().getUpc())?request.getData().getUpc():"");
		soeResponse.getData().setPriceId(StringUtilities.isNotEmptyOrNull(request.getData().getPriceId())?request.getData().getPriceId():"");

			if (null != request.getData() && "GN".equalsIgnoreCase(request.getData().getLocationSubtype()) && "BBX".equalsIgnoreCase(request.getData().getMaid())) {
				RetrieveGlobalLocationDetailsCxpRequest locationReq = new RetrieveGlobalLocationDetailsCxpRequest();
				locationReq.setLocationCode(request.getData().getLocationCode());
				return cxpService.retrieveGlobalLocationDetails(locationReq).flatMap(res -> {
					if (res.getData() != null && res.getData().getLocationCodeLookup() != null && res.getData().getLocationCodeLookup().getResponse() != null
							&& res.getData().getLocationCodeLookup().getResponse().getRealAgentCode() != null) {
						return redisHelper2.upsertrealAgentCodeSession(res.getData().getLocationCodeLookup().getResponse().getRealAgentCode()).flatMap(booleanres -> {
							soeResponse.getData().setRealAgentCode(res.getData().getLocationCodeLookup().getResponse().getRealAgentCode());
							return Mono.just(soeResponse);

						});
					}
					return Mono.just(soeResponse);
				});
			}
			return Mono.just(soeResponse);
	}

	/* calling customerProfile to get hashedMDN and hashedId to store the readDl response */
	public Mono<CustomerProfileByIdCXPResponse> getCustomerProfileAddress(String customerId) {
		return cxpService.getCustomerProfileAddress(customerId).flatMap(custProfile-> {
			return Mono.just(custProfile);
		});
	}

	/*
		Changes to check if the account is eligible for local store offer and set the relevant flag/text.
		UI can use the text to display appropriate messages related to local store offer.
	 */
	private void checkForLocalStoreOffers(RetrieveCartCXPRequest request, RetrieveCartUIResponse soeResponse, List<CXPLineInfo> cxpLineinfoList) {
		try {
			if (request != null && request.getData() != null && request.getData().isLocalStoreOfferEnabled() && cxpLineinfoList != null &&
					!cxpLineinfoList.isEmpty()) {
				long countOfSmartphones = cxpLineinfoList.stream().filter(lineInfo ->
						lineInfo != null && lineInfo.getDeviceTypeSelected() != null && checkCategoryCodeForPhones(lineInfo)
								&& lineInfo.getServiceInfo() != null && lineInfo.getServiceInfo().getNewPricePlanInfo() != null
								&& checkEligiblePlanIdForLocalStoreOffer(request, lineInfo.getServiceInfo().getNewPricePlanId())
								&& (CartConstants.NSE.equalsIgnoreCase(lineInfo.getLineActivityType()) || CartConstants.NSE_BYOD.equalsIgnoreCase(lineInfo.getLineActivityType()))
				).count();

				if (countOfSmartphones > 0 && countOfSmartphones < 4) {
					soeResponse.getData().getCart().getLineDetails().setLocalStoreOfferState("OfferEligible");
					cxpLineinfoList.stream().forEach(lineInfo -> {
						if (lineInfo != null && lineInfo.getServiceInfo() != null && checkCategoryCodeForPhones(lineInfo)
								&& lineInfo.getServiceInfo().getSelectedFeaturesList() != null &&
								!lineInfo.getServiceInfo().getSelectedFeaturesList().getVisFeature().isEmpty()) {
							lineInfo.getServiceInfo().getSelectedFeaturesList().getVisFeature().stream().forEach(feature -> {
								if (feature != null && feature.getCategoryCodes() != null &&
										checkCategoryCodesForLocalStoreOffers(feature.getCategoryCodes())) {
									if (CartConstants.ADD_IND.equalsIgnoreCase(feature.getAddDeleteInd())) {
										soeResponse.getData().getCart().getLineDetails().setLocalStoreOfferState("OfferApplied");
									} else if (CartConstants.DROP_IND.equalsIgnoreCase(feature.getAddDeleteInd())) {
										soeResponse.getData().getCart().getLineDetails().setLocalStoreOfferState("InEligibleAndRemove");
									}
								}
							});
						}
					});
				} else {
					soeResponse.getData().getCart().getLineDetails().setLocalStoreOfferState("InEligible");
				}

			}
		} catch(Exception e) {
			logger.error("error while checking if the account is eligible for local store offer : {}" , e.getMessage());
		}

	}

	/*
		Check if each line has a smartphone or basic phone based on sorCategoryCode in cartItems.
	 */
	private Boolean checkCategoryCodeForPhones(CXPLineInfo lineInfo) {
		Boolean isEligibleCatCode = false;

		if(lineInfo.getItemsInfo() != null && lineInfo.getItemsInfo()[0] != null && lineInfo.getItemsInfo()[0].getCartItems() != null
				&& lineInfo.getItemsInfo()[0].getCartItems().getCartItem() != null && lineInfo.getItemsInfo()[0].getCartItems().getCartItem().length > 0) {
			Optional<CXPCartItem> isPhoneDevicePresent = Arrays.stream(lineInfo.getItemsInfo()[0].getCartItems().getCartItem()).filter(cartItem ->
					cartItem != null && CartConstants.DEVICE_TYPE.equalsIgnoreCase(cartItem.getCartItemType()) &&
							StringUtilities.isNotEmptyOrNull(cartItem.getSorDeviceCategory()) &&
							(cartItem.getSorDeviceCategory().toUpperCase().contains(CartConstants.DEVICE_TYPE_SMARTPHONE) ||
									(cartItem.getSorDeviceCategory().toUpperCase().contains(CartConstants.DEVICE_TYPE_FEATUREPHONE) ||
											(cartItem.getSorDeviceCategory().toUpperCase().contains(CartConstants.DEVICE_TYPE_BASICPHONE))))
			).findFirst();
			if(isPhoneDevicePresent.isPresent()) {
				isEligibleCatCode = true;
			}
		}

		if(lineInfo.getDeviceTypeSelected().toLowerCase().contains(CartConstants.SMARTPHONES)
				|| lineInfo.getDeviceTypeSelected().toLowerCase().contains(CartConstants.BASICPHONE)) {
			isEligibleCatCode = true;
		}

		return isEligibleCatCode;
	}

	/*
		check if each smartphone line's planId is eligible for local store offer.
	 */
	private Boolean checkEligiblePlanIdForLocalStoreOffer(RetrieveCartCXPRequest request, String planId) {
		Boolean isPlanIdEligibleForLocalStoreOffer = false;
		String eligiblePlanIds = request.getData().getEligiblePlanIdsForLocalStoreOffer();
		String[] planIds = eligiblePlanIds.split(",");
		if(planIds != null) {
			Optional<String> filterPlanId = Arrays.stream(planIds).filter(elgPlanId ->
					StringUtilities.isNotEmptyOrNull(elgPlanId) && StringUtilities.isNotEmptyOrNull(planId) && elgPlanId.equalsIgnoreCase(planId)).findFirst();
			if(filterPlanId.isPresent()) {
				isPlanIdEligibleForLocalStoreOffer = true;
			}
		}
		return isPlanIdEligibleForLocalStoreOffer;
	}

	private Boolean checkCategoryCodesForLocalStoreOffers(List<String> spoCatCodes) {
		Boolean isLocalStoreSPO = false;
		String[] catCodes = localStoreOfferCatCodes.split(",");
		if(CollectionUtilities.isNotEmptyOrNull(spoCatCodes) && spoCatCodes.containsAll(Arrays.asList(catCodes))) {
			isLocalStoreSPO = true;
		};
		return isLocalStoreSPO;
	}

	/**
	 *
	 * @param cartId
	 * @return RetrieveCartUIResponse
	 *
	 */
	public Mono<Integer> getDeviceCartCount(String cartId) {
		try {
			if (StringUtilities.isNotEmptyOrNull(cartId)) {
				return cxpService.deviceCountInCart(cartId, false, null).flatMap(cartResponse -> {
					cartResponse = CartCxpResponseUtil.getDeviceCount(cartResponse);
					if (null != cartResponse && null != cartResponse.getData()
							&& null != cartResponse.getData().getDeviceCountInCart()) {
						return Mono.just(cartResponse.getData().getDeviceCountInCart());
					} else {
						return Mono.just(0);
					}
				});
			} else {
				return Mono.just(0);
			}
		} catch (Exception e) {
			logger.error(CartConstants.CXP_RSPNS_PRCSS_EXCPTN_STRNG, e);
			return Mono.just(0);
		}
	}

	/**
	 *
	 * @param cartId
	 * @return RetrieveCartUIResponse
	 *
	 */
	public Mono<Map<String, String>> getAccessoryCartMap(String cartId) {
		try {
			if (StringUtilities.isNotEmptyOrNull(cartId)) {
				return cxpService.cartItems(cartId, false, null).flatMap(cartResponse -> {
					Map<String, String> cartmap = CartCxpResponseUtil1.getAccessoryCartObj(cartResponse);
					if (null != cartmap) {
						return Mono.just(cartmap);
					}
					return Mono.empty();
				});
			} else {
				return Mono.empty();
			}
		} catch (Exception e) {
			logger.error(CartConstants.CXP_RSPNS_PRCSS_EXCPTN_STRNG, e);
			return Mono.empty();
		}
	}

	/**
	 *
	 * @param cartId
	 * @return RetrieveCartUIResponse
	 *
	 */
	public Mono<Map<String, String>> getDeviceCartMap(String cartId) {
		try {
			if (StringUtilities.isNotEmptyOrNull(cartId)) {
				return cxpService.deviceCountInCart(cartId, false, null).flatMap(cartResponse -> {
					Map<String, String> cartmap = CartCxpResponseUtil1.getDeviceCartObj(cartResponse);
					if (null != cartmap) {
						return Mono.just(cartmap);
					}
					return Mono.empty();
				});
			} else {
				return Mono.empty();
			}
		} catch (Exception e) {
			logger.error(CartConstants.CXP_RSPNS_PRCSS_EXCPTN_STRNG, e);
			return Mono.empty();
		}
	}

	/**
	 *
	 * @param request
	 * @return RetrieveCartUIResponse
	 *
	 */
	public Mono<ValidateCartUIResponse> validateCart(ValidateCartCXPRequest request,CartRedisData data) {

		String graphqlType = "";
		// substitute the qurey param & form graphql query
		if (request.getMeta() != null && request.getMeta().containsKey("type"))
			graphqlType = request.getMeta().get("type");

		if (request.getRetrieveCurrentFeatures() == null)
			request.setRetrieveCurrentFeatures(false);

		// call to cxp graphql endpoint
		Mono<ValidateCartCXPResponse> responseServiceMono = Mono.empty();
		if (StringUtilities.isNotEmptyOrNull(graphqlType) && CartConstants.NEW_CUSTOMER_CAMELCASE.equalsIgnoreCase(graphqlType)) {
			responseServiceMono = cxpService.validateCartNewCustomer(request.getCartId(), request.getChannel(),
					request.getPageId(), request.getFlow(), request.getRetrieveCurrentFeatures(), request.getMtnList(),
					CartConstants.NEW_CUSTOMER,request.getIsFWASimplificationEnabled());
		} else if (StringUtilities.isNotEmptyOrNull(graphqlType) && CartConstants.RETRIEVE_MINI_CART_CAMELCASE.equalsIgnoreCase(graphqlType)) {
			responseServiceMono = cxpService.retrieveValidateMiniCart(request.getCartId(), request.getChannel(),
					request.getPageId(), request.getFlow(), request.getRetrieveCurrentFeatures(), request.getMtnList(),
					CartConstants.NEW_CUSTOMER);
		} else {
			responseServiceMono = cxpService.validateCart(request.getCartId(), request.getChannel(),
					request.getPageId(), request.getFlow(), request.getRetrieveCurrentFeatures(), request.getMtnList(), request.getSkipValidationErrorCodes(),request.getIsFWASimplificationEnabled());
		}
		ValidateCartUIResponse soeResponse = new ValidateCartUIResponse();
		String finalGraphqlType = graphqlType;
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(cartResponse -> {
			// convert cxpResponse into soeResponse
			CartCxpResponseUtil1.formatValidateCartResponse(soeResponse, cartResponse);
			if (null != cartResponse.getData()) {
				getConfirmationKibanaLogsCartDataFromCXP(soeResponse);
				try {
					updateDLData(null, cartResponse, "Validate", null, null,data);
				} catch (Exception e) {
					logger.error("Validate OmniDL Exception", e);
				}
			}
			if(null!=soeResponse && null!=soeResponse.getData() && null!=soeResponse.getData().getValidateCartAndUpdate()){
				performMaskingForBYOD(soeResponse.getData().getValidateCartAndUpdate());
			}
			//Inserting ACPInfo into Redis if available for prospect customer
			if(StringUtilities.isNotEmptyOrNull(finalGraphqlType) && CartConstants.NEW_CUSTOMER_CAMELCASE.equalsIgnoreCase(finalGraphqlType)) {

				Optional<CXPCartVO> validateCartAndUpdateOpt = Optional.of(soeResponse)
						.map(ValidateCartUIResponse::getData).map(CXPValidateCartDataVO::getValidateCartAndUpdate);

                validateCartAndUpdateOpt.ifPresent(cxpCartVO -> extractAndSaveSessionData(request, cxpCartVO));
			}
			return redisHelper2.getCartOrderFlowType().flatMap(redisFlowType -> {
				if (redisFlowType != null && CartConstants.NEW_CUSTOMER_CAMELCASE.equalsIgnoreCase(finalGraphqlType)
						&& redisFlowType.contains(CartConstants.NSE.toLowerCase())) {
					Map<String, String> deviceCartMap = updateDeviceCartMapInRedis(soeResponse);
					return redisHelper2.upsertDeviceCartMapInRedis(deviceCartMap).flatMap(cartMap -> {
						return Mono.just(soeResponse);
					});
				} else {
					String cartOrderFlowType = calculateOrderFlowTypeFromValidate(redisFlowType, soeResponse,
							finalGraphqlType);
					return redisHelper2.updateCartOrderFlowType(cartOrderFlowType).flatMap(orderTypeData -> {
						Map<String, String> deviceCartMap = updateDeviceCartMapInRedis(soeResponse);
						return redisHelper2.upsertDeviceCartMapInRedis(deviceCartMap).flatMap(cartMap -> {
							return Mono.just(soeResponse);
						});
					});
				}
			});

		});

	}

	private void extractAndSaveSessionData(ValidateCartCXPRequest request, CXPCartVO validateCartAndUpdate) {
		Map<String, String> sessionData = new HashMap<>();

		Optional.of(validateCartAndUpdate).map(CXPCartVO::getOrderDetails).map(CXPOrderDetails::getIsComboOrder)
				.ifPresent(isComboOrder -> {
			logger.info("Upserting combo order flag into redis...");
			sessionData.put(CartConstants.IS_JT_COMBO_ORDER, (String) isComboOrder);
		});

		if (request.isEnableFcc()) {
			String nseCustomerAddressInfo = upsertNseCustomerInfoInRedis(validateCartAndUpdate);
			//Upserting the nse customer address data into the redis...
			sessionData.put(CartConstants.NSE_CUSTOMER_ADDRESS, nseCustomerAddressInfo);
		}

		Optional<ACPInfoGQL> acpInfoGQL = Optional.ofNullable(validateCartAndUpdate.getAcpInfo());
		if (acpInfoGQL.isPresent() && acpInfoGQL.map(ACPInfoGQL::getBenefit).isPresent()
				&& acpInfoGQL.map(ACPInfoGQL::getCustomerInfo).map(ACPCustomerInfoGQL::getContactInfo).isPresent()) {
			try {
				String acpInfoString = mapper.writeValueAsString(acpInfoGQL.get());
				//Upserting the acp data into the redis...
				sessionData.put(CartConstants.ACP_INFO, acpInfoString);

			} catch (JsonProcessingException e) {
				logger.error("Error occurred while json processing : "+e);
			}
		}

		logger.info("upserting acp data info & customer info into redis ::" + sessionData);
		redisHelper2.upsertDataInRedis(sessionData);
	}

	/**
	 * Method to upsert the nse customer address in redis
	 *
	 * @param cxpCartVO
	 */
	private String upsertNseCustomerInfoInRedis(CXPCartVO cxpCartVO) {
		String nseCustomerAddressInfo = StringUtils.EMPTY;
		Optional<BillingAddress> billingAddressOpt = Optional.of(cxpCartVO).map(CXPCartVO::getCustomerProfileForNSE)
				.map(CustomerProfileForNSE::getContactInfo).map(ContactInfo::getBillingAddress);
		if(billingAddressOpt.isPresent() && billingAddressOpt.map(BillingAddress::getAddressLine1).isPresent()
				&& billingAddressOpt.map(BillingAddress::getCity).isPresent()
				&& billingAddressOpt.map(BillingAddress::getState).isPresent()
				&& billingAddressOpt.map(BillingAddress::getZipCode).isPresent()) {
			try {
				nseCustomerAddressInfo = mapper.writeValueAsString(billingAddressOpt.get().toString());

			} catch (JsonProcessingException e) {
				logger.error("Error occurred while Json processing: " + e);
			}
		}
		/*if (null != soeResponse.getData() &&
				null != soeResponse.getData().getValidateCartAndUpdate() &&
				null != soeResponse.getData().getValidateCartAndUpdate().getCustomerProfileForNSE() &&
				null != soeResponse.getData().getValidateCartAndUpdate().getCustomerProfileForNSE().getContactInfo() &&
				null != soeResponse.getData().getValidateCartAndUpdate().getCustomerProfileForNSE().getContactInfo().getBillingAddress() &&
				null != soeResponse.getData().getValidateCartAndUpdate().getCustomerProfileForNSE().getContactInfo().getBillingAddress().getAddressLine1() &&
				null != soeResponse.getData().getValidateCartAndUpdate().getCustomerProfileForNSE().getContactInfo().getBillingAddress().getCity() &&
				null != soeResponse.getData().getValidateCartAndUpdate().getCustomerProfileForNSE().getContactInfo().getBillingAddress().getState() &&
				null != soeResponse.getData().getValidateCartAndUpdate().getCustomerProfileForNSE().getContactInfo().getBillingAddress().getZipCode()) {
			try {
				nseCustomerAddressInfo = mapper.writeValueAsString(soeResponse.getData().getValidateCartAndUpdate().getCustomerProfileForNSE().getContactInfo().getBillingAddress());

			} catch (JsonProcessingException e) {
				logger.error("Error occurred while Json processing: "+e);
			}
		}*/
		return nseCustomerAddressInfo;
	}

	private String calculateOrderFlowTypeFromValidate(String redisFlowType, ValidateCartUIResponse soeResponse,
													  String customerType) {
		String cartOrderFlowType = "";
		try {
			CXPLineDetailsVO lineDetails = new CXPLineDetailsVO();
			if (soeResponse.getErrors() == null) {
				if (null != soeResponse.getData() && null != soeResponse.getData().getValidateCartAndUpdate())
					lineDetails = soeResponse.getData().getValidateCartAndUpdate().getLineDetails();
				if (null != lineDetails) {
					CXPLineInfo[] lineInfoItem = lineDetails.getLineInfo();
					for (CXPLineInfo lineInfo : lineInfoItem) {
						String lineActivityType = lineInfo.getLineActivityType();
						if (StringUtilities.isNotEmptyOrNull(lineActivityType)) {
							String intendType = "";
							if (CartConstants.EUP.equalsIgnoreCase(lineActivityType)
									|| CartConstants.AAL.equalsIgnoreCase(lineActivityType)
									|| (CartConstants.CPC.equalsIgnoreCase(lineActivityType)
									&& !CartConstants.NEW_CUSTOMER_CAMELCASE.equalsIgnoreCase(customerType))
									|| CartConstants.NSE.equalsIgnoreCase(lineActivityType))
								intendType = lineActivityType.toLowerCase();
							else if (CartConstants.NSE_BYOD.equalsIgnoreCase(lineActivityType))
								intendType = CartConstants.NSO;
							else if(CartConstants.BYOD.equalsIgnoreCase(lineActivityType))
								intendType = CartConstants.ESO;
							else if (CartConstants.ACC.equalsIgnoreCase(lineActivityType))
								intendType = CartConstants.NAO;
							if ("".equalsIgnoreCase(cartOrderFlowType))
								cartOrderFlowType = intendType;
							else if (!cartOrderFlowType.contains(intendType))
								cartOrderFlowType = cartOrderFlowType + " w/" + intendType;
							if (CartConstants.EUP.equalsIgnoreCase(lineActivityType)
									|| CartConstants.AAL.equalsIgnoreCase(lineActivityType)
									|| CartConstants.BYOD.equalsIgnoreCase(lineActivityType)) {
								if (null != lineInfo.getServiceInfo()
										&& ((null != lineInfo.getServiceInfo().getSelectedALPShareList()
										&& null != lineInfo.getServiceInfo().getSelectedALPShareList()
										.getNewAlpShareInfo()
										&& lineInfo.getServiceInfo().getSelectedALPShareList()
										.getNewAlpShareInfo().length > 0)
										|| null != lineInfo.getServiceInfo().getNewPricePlanInfo())) {
									if (!cartOrderFlowType.contains(CartConstants.CPC.toLowerCase()))
										cartOrderFlowType = cartOrderFlowType + " w/" + CartConstants.CPC.toLowerCase();
								}
							}
						}
					}
				}
				if (StringUtilities.isNotEmptyOrNull(cartOrderFlowType)) {
					if (redisFlowType.contains(CartConstants.EXPRESS))
						cartOrderFlowType = CartConstants.EXPRESS + cartOrderFlowType;
					if (redisFlowType.contains(CartConstants.STANDALONE))
						cartOrderFlowType = cartOrderFlowType + " w/" + CartConstants.STANDALONE;
				}
			}
		} catch (Exception e) {
			logger.error("exception calculating cartOrderFlowType in ValidateCart");
		}
		if (StringUtilities.isEmptyOrNull(cartOrderFlowType))
			cartOrderFlowType = "none";
		return cartOrderFlowType;
	}

	/**
	 *
	 * @param uiRequest
	 * @return UpdateUserInfoUIResponse
	 */
	public Mono<UpdateUserInfoUIResponse> updateUserInfo(UpdateUserInfoUIRequest uiRequest) {

		UpdateUserInfoCXPRequest cxpRequest = new UpdateUserInfoCXPRequest();

		// convert uiRequest to cxpRequest
		cxpRequest = CartCxpRequestUtil.formatUpdateUserInfoRequest(uiRequest, cxpRequest);
		// call to cxp service
		Mono<UpdateUserInfoCXPResponse> cxpResponseMono = cxpService.updateUserInfo(cxpRequest);

		UpdateUserInfoUIResponse soeResponse = new UpdateUserInfoUIResponse();

		return cxpResponseMono == null ? Mono.just(soeResponse) : cxpResponseMono.flatMap(cxpResponse -> {
			// convert cxpResponse to uiResponse
			CartCxpResponseUtil.formatUpdateUserInfoResponse(cxpResponse, soeResponse);
			return Mono.just(soeResponse);
		});
	}

	/**
	 *
	 * @param uiRequest
	 * @return PaperlessBillingUIResponse
	 */
	public Mono<PaperlessBillingUIResponse> paperlessBilling(PaperlessBillingUIRequest uiRequest) {

		PaperlessBillingCXPRequest cxpRequest = new PaperlessBillingCXPRequest();

		// convert uiRequest to cxpRequest
		cxpRequest = CartCxpRequestUtil.formatPaperlessBillingRequest(uiRequest, cxpRequest);
		// call to cxp service
		Mono<PaperlessBillingCXPResponse> cxpResponseMono = cxpService.paperlessBilling(cxpRequest);

		PaperlessBillingUIResponse soeResponse = new PaperlessBillingUIResponse();
		return cxpResponseMono == null ? Mono.just(soeResponse) : cxpResponseMono.flatMap(cxpResponse -> {
			// convert cxpResponse to uiResponse
			CartCxpResponseUtil.formatPaperlessBillingResponse(cxpResponse, soeResponse);
			return Mono.just(soeResponse);
		});
	}

	// Sajan
	/**
	 *
	 * @param uiRequest
	 * @return PaperlessBillingUIResponse
	 */

	public Mono<SmartImeiTypeAheadSearchResponse> getSmartImeiTypeAheadResponse(SmartImeiTypeAheadSearchRequest uiRequest) {
		SmartImeiTypeAheadCXPRequest cxpRequest = new SmartImeiTypeAheadCXPRequest();
		cxpRequest = CartCxpRequestUtil.formatSmartImeiTypeAheadRequest(uiRequest, cxpRequest);
		Mono<SmartImeiTypeAheadCXPResponse> cxpResponse = catalogService.smartImeiTypeAhead(cxpRequest);
		return cxpResponse == null ? Mono.just(new SmartImeiTypeAheadSearchResponse()):cxpResponse.flatMap(resp -> {
			return convertCXPResponseToUiResponse(resp, uiRequest);
		});
	}

	public Mono<SmartImeiDevicesResponse> getSmartImeiDevices(String sorDisplayName, String skuCarrier) {
		logger.info("CartServiceCxpHelper :: getSmartImeiDevice :: smart imei devices from catalog is enabled, calling catalog domain");
		SmartImeiDevicesCXPRequest cxpRequest = new SmartImeiDevicesCXPRequest();
		cxpRequest = formatSmartImeiDeviceRequest(sorDisplayName, skuCarrier, cxpRequest);
		return catalogService.smartImeiDevice(cxpRequest);
	}

	private SmartImeiDevicesCXPRequest formatSmartImeiDeviceRequest(String sorDisplayName, String skuCarrier, SmartImeiDevicesCXPRequest cxpRequest) {
		cxpRequest.setSmartImeiDeviceRequest(new SmartImeiDeviceRequest());
		cxpRequest.getSmartImeiDeviceRequest().setSmartImeiDevices(List.of(new SmartImeiDevices(sorDisplayName, skuCarrier)));
		return cxpRequest;
	}

	public Mono<SmartImeiTypeAheadSearchResponse> convertCXPResponseToUiResponse(SmartImeiTypeAheadCXPResponse resp,
																 SmartImeiTypeAheadSearchRequest uiRequest) {
		List<TypeAheadData> typeAheadDataList = new ArrayList<>();
		SmartImeiTypeAheadSearchResponse response = new SmartImeiTypeAheadSearchResponse();
		String deviceCategory = uiRequest.getDeviceCategory();
		List<String> modelNames = null;
		modelNames = util.splitMakeOrModel(uiRequest.getModel());
		List<SmartImeiTypeAheadDetails> typeAheadResults= resp.getData().getSmartImeiTypeAheadDetails();
		typeAheadResults.sort(Comparator.comparing(SmartImeiTypeAheadDetails::getModelName));
		for(SmartImeiTypeAheadDetails smartImeiTypeAheadDetail:typeAheadResults ) {
			TypeAheadData typeAheadDataObjectUI = new TypeAheadData();
			typeAheadDataObjectUI.setCarrier(smartImeiTypeAheadDetail.getCarrier());
			typeAheadDataObjectUI.setMake_typeahead(smartImeiTypeAheadDetail.getMakeTypeahead());
			typeAheadDataObjectUI.setModel_name_typeahead(smartImeiTypeAheadDetail.getModelName());
			typeAheadDataObjectUI.setEuiccCapable(smartImeiTypeAheadDetail.isEuiccCapable());
			typeAheadDataObjectUI.setEsimOnly(smartImeiTypeAheadDetail.getIsEsimOnly());
			if (SmartImeiSearchConstants.ENABLED_FLAG.equals(SMART_IMEI_TYPEAHEAD_MERGE_ENABLED)) {
				
				addModifiedNameToDevices(typeAheadDataObjectUI);
				typeAheadDataObjectUI=filterResultsByKeyWordInMakeOrModel(typeAheadDataObjectUI, modelNames);
				if(typeAheadDataObjectUI!=null && deviceCategory!=null)
					typeAheadDataList.add(typeAheadDataObjectUI);
				
			} else {
					typeAheadDataList.add(typeAheadDataObjectUI);
				}

			}
			if (SmartImeiSearchConstants.ENABLED_FLAG.equals(SMART_IMEI_TYPEAHEAD_MERGE_ENABLED)) {
				typeAheadDataList = groupDeviceAndCarrier(typeAheadDataList);
			}
			response.setData(typeAheadDataList);
			return Mono.just(response);
	}

	/**
	 * Filter the device returned from Response.
	 * @param typeAheadDataObjectUI
	 * @param keys
	 */
	private TypeAheadData filterResultsByKeyWordInMakeOrModel(TypeAheadData typeAheadDataObjectUI, List<String> keys) {
		String make=typeAheadDataObjectUI.getMake_typeahead();
		String model=typeAheadDataObjectUI.getModel_name_typeahead();
		simOutWordList=simOutWordList.stream().filter(word->!StringUtilities.isEmptyOrNull(word)).collect(Collectors.toList());
		if(null!=simOutWordList && !simOutWordList.isEmpty()) {
			for(String simOutWord:simOutWordList) {
				if(StringUtils.containsIgnoreCase(model, simOutWord))
					return null;
			}
		}
		if(CollectionUtilities.isNotEmptyOrNull(keys)) {
			for(String key : keys) {
				if(StringUtilities.isNotEmptyOrNull(key) &&
						((StringUtilities.isNotEmptyOrNull(make) && !make.toLowerCase().contains(key.toLowerCase())) &&
								(StringUtilities.isNotEmptyOrNull(model) && !model.toLowerCase().contains(key.toLowerCase())))){
					return null;
				}
			}
			return typeAheadDataObjectUI;
		}
		return null;

	}

	/**
	 *
	 * @param typeAheadDataList
	 */
	private List<TypeAheadData> groupDeviceAndCarrier(List<TypeAheadData> typeAheadDataList) {
		List<TypeAheadData> deviceMergeList = new ArrayList<>();
		Map<String, List<DeviceAndCarrier>> deviceAndCarrierMap = Collections
				.synchronizedMap(new TreeMap<>(String.CASE_INSENSITIVE_ORDER));
		Map<String, String> makeMap = new HashMap<>();
		Map<String,Boolean> euiccCapableMap=new HashMap<>();
		Map<String,Boolean> esimOnlyMap =new HashMap<>();
		Map<String,Boolean> euiccMapToOverrideFlag=new HashMap<>();
		Map<String, Set<String>> uniqueCarrierMap = Collections
				.synchronizedMap(new TreeMap<>(String.CASE_INSENSITIVE_ORDER));
		typeAheadDataList.forEach(device -> {
				List<DeviceAndCarrier> deviceAndCarrierObjectList = new ArrayList<>();
				if (deviceAndCarrierMap.containsKey(device.getModifiedName())) {
					deviceAndCarrierObjectList.addAll(deviceAndCarrierMap.get(device.getModifiedName()));
				}
			if (device.getCarrier() != null && !device.getCarrier().isEmpty()) {
				device.getCarrier().forEach(carrier -> {
					if (!SMART_IMEI_SUPPRESS_CARRIERS.contains(carrier.toLowerCase())) {
						// Below logic added to display unique carrier
						Set<String> uniqueCarriers = uniqueCarrierMap.get(device.getModifiedName());
						if (uniqueCarriers == null) {
							uniqueCarriers = new HashSet<>();
						}
						boolean unique=Boolean.FALSE;
						if(StringUtils.containsIgnoreCase(device.getModel_name_typeahead(), CartConstants.ESIM_INDICATOR) || StringUtils.containsIgnoreCase(device.getModel_name_typeahead(), CartConstants.ESIM_MODEL_NAME) || StringUtils.containsIgnoreCase(device.getModel_name_typeahead(), CartConstants.ESIM_INDICATOR_2)) {
							unique=Boolean.FALSE;
						}
						else {
						 unique= uniqueCarriers.add(carrier);
						}
						if (unique) {
							uniqueCarrierMap.put(device.getModifiedName(), uniqueCarriers);
							DeviceAndCarrier deviceAndCarrier = new DeviceAndCarrier();
							deviceAndCarrier.setCarrierName(carrier);
							deviceAndCarrier.setDeviceName(device.getModel_name_typeahead());
							deviceAndCarrierObjectList.add(deviceAndCarrier);
						}
					}
				});
			}
				
				 if(euiccMapToOverrideFlag.containsKey(device.getModifiedName()) && !euiccMapToOverrideFlag.get(device.getModifiedName()) && device.isEuiccCapable()) {
				    	euiccMapToOverrideFlag.put(device.getModifiedName(), device.isEuiccCapable());
				  }
				 else if(euiccMapToOverrideFlag.containsKey(device.getModifiedName()) && euiccMapToOverrideFlag.get(device.getModifiedName()) && !device.isEuiccCapable()) {
					 device.setEuiccCapable(euiccMapToOverrideFlag.get(device.getModifiedName()));
				 }
				 else {
					 euiccMapToOverrideFlag.put(device.getModifiedName(), device.isEuiccCapable());
				 }
				deviceAndCarrierMap.put(device.getModifiedName(),deviceAndCarrierObjectList);
				makeMap.put(device.getModifiedName(), device.getMake_typeahead());
				euiccCapableMap.put(device.getModifiedName(), device.isEuiccCapable());
				if(!esimOnlyMap.containsKey(device.getModifiedName()) && device.getEsimOnly()!=null)
			    	esimOnlyMap.put(device.getModifiedName(),device.getEsimOnly());
		});
		deviceAndCarrierMap.forEach((key, value) -> {
			if (StringUtils.isNotBlank(key)) {
				TypeAheadData deviceMerge = util.formatDeviceMerge(key, value, makeMap, euiccCapableMap, uniqueCarrierMap,esimOnlyMap);
				deviceMergeList.add(deviceMerge);
			}

		});
		return deviceMergeList;
	}

	/**
	 *
	 * @param request
	 * @return soeResponse
	 *
	 */
	public Mono<RetrieveURCForCartUIResponse> retrieveURCForCart(RetrieveURCForCartUIRequest request) {

		Mono<RetrieveURCForCartCXPResponse> responseServiceMono = cxpService.retrieveURCForCart(request);

		RetrieveURCForCartUIResponse soeResponse = new RetrieveURCForCartUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(cartResponse -> {

			// convert cxpResponse into soeResponse
			CartCxpResponseUtil1.formatRetrieveURCForCartResponse(soeResponse, cartResponse);
			return Mono.just(soeResponse);
		});

	}

	/**
	 *
	 * @param request
	 * @return soeResponse
	 *
	 */
	public Mono<CalculateMultilineTaxUIResponse> calculateMultiLineTaxForCart(CalculateMultilineTaxUIRequest request) {

		Mono<CalculateMultilineTaxCXPResponse> responseServiceMono = cxpService.calculateMultiLineTaxForCart(request);

		CalculateMultilineTaxUIResponse soeResponse = new CalculateMultilineTaxUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(cartResponse -> {

			// convert cxpResponse into soeResponse
			CartCxpResponseUtil1.formatCalculateMultilineTaxResponse(soeResponse, cartResponse);
			return Mono.just(soeResponse);
		});

	}

	/**
	 *
	 * @param request
	 * @return soeResponse
	 *
	 */
	public Mono<ValidateBYODToolUIResponse> validateBYODTool(ValidateBYODToolCXPRequest request) {

		Mono<ValidateBYODToolCXPResponse> responseServiceMono = cxpService.validateBYODTool(request.getDeviceId());

		ValidateBYODToolUIResponse soeResponse = new ValidateBYODToolUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(cartResponse -> {

			// convert cxpResponse into soeResponse
			CartCxpResponseUtil1.formatValidateBYODTool(soeResponse, cartResponse);
			return Mono.just(soeResponse);
		});

	}

	/**
	 *
	 * @param request
	 * @return soeResponse
	 *
	 */
	public Mono<ESimDetailsUIResponse> eSimDetails(ESimDetailsETNIRequest request) {

		Mono<ESimDetailsETNIResponse> responseServiceMono = cxpService.eSimDetails(request)
				.doOnError(e -> logger.error("Exception occur in eSimDetails method and error={0}", e))
				.onErrorResume(SOEHTTPException.class, e -> {

					try {
						return Mono.just(mapper.readValue(e.getMessage(), ESimDetailsETNIResponse.class));
					} catch (JsonProcessingException e1) {
						return Mono.just(new ESimDetailsETNIResponse());
					}
				});

		ESimDetailsUIResponse soeResponse = new ESimDetailsUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(cartResponse -> {

			// convert cxpResponse into soeResponse
			CartCxpResponseUtil1.formatESimDetails(soeResponse, cartResponse);
			return Mono.just(soeResponse);
		});

	}

	/**
	 *
	 * @param retrieveCartResponse
	 * @param validateCartResponse
	 * @param methodType
	 * @param promosAppliedVal
	 */
	public void updateDLData(RetrieveCartCXPResponse retrieveCartResponse, ValidateCartCXPResponse validateCartResponse,
							 String methodType, String promosAppliedVal, BundleBuilderCXPResponseData bundleBuilderCXPResponse,CartRedisData data) {
		dlService.buildDLData(
				OmniBuilder.fromCart(retrieveCartResponse, validateCartResponse, methodType, promosAppliedVal, bundleBuilderCXPResponse,data));
	}

	private boolean isDigitalOptimsedRetrieveCart(RetrieveCartCXPRequest request, String graphqlType) {
		return enableOptimisedDigitalRetrieveCart
				&& CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))
				&& StringUtilities.isNotEmptyOrNull(graphqlType) && "optimised".equalsIgnoreCase(graphqlType);
	}
	
	private boolean isNewNumberPortInRetrieveCart(RetrieveCartCXPRequest request, String graphqlType) {
		return CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))
				&& StringUtilities.isNotEmptyOrNull(graphqlType) && CartConstants.PORT_IN.equalsIgnoreCase(graphqlType);
	}

	public Mono<OrderConfirmationUIResponse> swapOrderConfirmation(CXPOrderConfirmation5GDataVO request, TechFlowRedisData redisData) {
		// check for empty cart id in request before cxp call
		return redisHelper2.getCartIdFromRedis().flatMap(cartId -> {
			if (StringUtils.isEmpty(cartId)) {
				cartId = request.getCartId();
			}
			if (StringUtils.isEmpty(cartId)) {
				return CartCxpResponseUtil1.formatOrderConfirmationErrorResponse();
			} else {
				return cxpService.getOrderConfirmationData(cartId).flatMap(cxpCartResponse -> {
					if (null != cxpCartResponse.getData()) {
						try {
							populateOrderConfirmDLData(cxpCartResponse, null, "OrderConfirm5G", null);
							util.populateKibanaFieldsForTechFlows(cxpCartResponse,redisData);
						} catch (Exception e) {
							logger.error("OrderConfirm5G OmniDL Exception", e);
						}
					}
					return CartCxpResponseUtil1.formatOrderConfirmationResponse(cxpCartResponse);
				}).onErrorResume(cxpError -> {
					if (cxpError instanceof SOEHTTPException) {
						SOEHTTPException soeExp = (SOEHTTPException) cxpError;
						if (soeExp.getErrorHolder() != null) {
							if (CollectionUtilities.isNotEmptyOrNull(soeExp.getErrorHolder().getErrors())) {
								return CartCxpResponseUtil1
										.formatOrderConfirmationUIErrorResponse(soeExp.getErrorHolder().getErrors());
							}
						}
					}
					return Mono.empty();
				});
			}
		});
	}

	public void populateOrderConfirmDLData(OrderConfirmationCXPResponse orderConfirmationResponse,
										   ValidateCartCXPResponse validateCartResponse, String methodType, String promosAppliedVal) {
		dlService.buildDLData(OmniBuilder.fromOrderConfirm5g(orderConfirmationResponse, validateCartResponse,
				methodType, promosAppliedVal));
	}

	/**
	 * Add Modified Name
	 *
	 * @param devices
	 */
	private void addModifiedNameToDevices(TypeAheadData devices) {
		String name = devices.getModel_name_typeahead();
		name = util.getModifiedName(name);

		List<String> stopWordList = util.getStopWords();
		devices.setModifiedName(name);
		stopWordList.forEach(stopWord -> {
			devices.setModifiedName(StringUtils.replaceIgnoreCase(devices.getModifiedName(), stopWord, "").trim());
		});
	}

	public Mono<AgreementDetailsResponse> getAgreementDetails(CheckoutDetailsRequest checkoutRequest) {
		AgreementDetailsCXPRequest cxpReq = AgreementDetailsCXPRequest.builder()
				.data(AgreementDetailsData.builder().cartId(checkoutRequest.getCartId())
						.customerAgreements(checkoutRequest.isCustomerAgreements())
						.promoHub(checkoutRequest.isExpressCheckout())
						.installmentContracts(checkoutRequest.isInstallmentContracts()).build())
				.meta(Meta.builder().client(checkoutRequest.getClient()).build()).build();
		AgreementDetailsResponse detailsResp = new AgreementDetailsResponse();
		try {
			Mono<AgreementDetailsCXPResponse> cxpRes = orderCxpService.getAgreementDetails(cxpReq);

			return Optional.ofNullable(cxpRes).orElse(Mono.empty()).flatMap(data -> {

				detailsResp.setData(
						AgreementDetailsResponseData.builder().customerAgreement(data.getData().getCustomerAgreement())
								.installment(data.getData().getInstallment()).build());

				return Mono.just(detailsResp);
			});
		}catch (SOEHTTPException e) {

		}
		return Mono.just(detailsResp);
	}
	/**
	 *
	 * @param request
	 * @return UpdateUserInfoUIResponse
	 */

	public Mono<UpdateConsentCxpResponse> updateCustomerConsent(AddDeviceUIRequest request) {

		UpdateConsentCxpRequest cxpRequest = new UpdateConsentCxpRequest();
		// convert uiRequest to cxpRequest
		cxpRequest = CartCxpRequestUtil.formatUpdateCusetomerConsentRequest(request, cxpRequest);
		// call to cxp service
		return cxpService.updateCustomerConsent(cxpRequest);


	}
	
	public Mono<OrderReviewDetailsResponse> getOrderReviewDetails(GetOrderDetailsGQLRequest getOrderDetailsGQLRequest)
	{
		Mono<OrderReviewDetailsResponse> orderReviewDetailsResponse= null;
		try {
			orderReviewDetailsResponse = cxpService.getOrderReviewDetails(getOrderDetailsGQLRequest.getCartId(),Boolean.FALSE);
		} catch (SOEHTTPException e) {
			LoggerUtil.logOnError(r -> logger.error("OrderReviewDetails_GQL_Service_FAILED", e));
		}

		return null != orderReviewDetailsResponse ? orderReviewDetailsResponse.flatMap(data -> {
			if (data != null) {
				if (data.getData() == null  && data.getErrors() == null) {
					return Mono.just(data);
				}
			}
			return Mono.just(data);
		}): Mono.empty();
	}
	
	/**
	 *
	 * @param cartResponse
	 */
	public void getConfirmationKibanaLogsCartDataFromCXP(ValidateCartUIResponse cartResponse) {
		long startTime=System.currentTimeMillis();
		Map<String, String> fields = new HashMap<>();
		Map<String, String> cartinfo = new HashMap<>();
		List<String> accessoriesNames = new ArrayList<>();
		List<String> bundleNames = new ArrayList<>();
		List<String> deviceNames = new ArrayList<>();
		List<String> deviceBrands = new ArrayList<>();
		List<String> skuIds = new ArrayList<>();
		List<String> oldPlanDetails = new ArrayList<>();
		List<String> newPlanDetails = new ArrayList<>();
		List<String> monthlyAmount = new ArrayList<>();
		List<String> promoCodes = new ArrayList<>();
		List<String> lineActivityType = new ArrayList<>();
		Boolean emptyCartIndicator = Boolean.FALSE;
		try {

			CXPLineDetailsVO ld = Optional.ofNullable(cartResponse).map(ValidateCartUIResponse::getData)
					.map(CXPValidateCartDataVO::getValidateCartAndUpdate).map(CXPCartVO::getLineDetails)
					.orElse(new CXPLineDetailsVO());
			if (null != ld.getNumOfAccessoryAndDeviceItemsInCart() && 0 == ld.getNumOfAccessoryAndDeviceItemsInCart())
				emptyCartIndicator = Boolean.TRUE;
			Optional.ofNullable(cartResponse).map(ValidateCartUIResponse::getData)
					.map(CXPValidateCartDataVO::getValidateCartAndUpdate).map(CXPCartVO::getLineDetails)
					.ifPresent(lineDetails -> {
						cartinfo.put("accessoriesCount", String.valueOf(lineDetails.getNumofAccessories()));
						cartinfo.put("noOfDevices",
								String.valueOf(lineDetails.getNumOfAccessoryAndDeviceItemsInCart()));
						Arrays.stream(lineDetails.getLineInfo()).filter(Objects::nonNull).forEach(lineInfo -> {
							if (StringUtilities.isNotEmptyOrNull(lineInfo.getLineActivityType())) {
								lineActivityType.add(lineInfo.getLineActivityType());
							}
							monthlyAmount.add(String.valueOf(lineInfo.getTotalDueMonthly()));
							if (lineInfo.getServiceInfo() != null
									&& lineInfo.getServiceInfo().getSelectedFeaturesList() != null
									&& lineInfo.getServiceInfo().getSelectedFeaturesList().getVisFeature() != null
									&& !lineInfo.getServiceInfo().getSelectedFeaturesList().getVisFeature().isEmpty()) {
								List<VisFeature> visFeatures = lineInfo.getServiceInfo().getSelectedFeaturesList()
										.getVisFeature();
								for (VisFeature visFeature : visFeatures) {
									if (Boolean.TRUE.equals(visFeature.getProtection())) {
										cartinfo.put("mobileProtectionPlan", visFeature.getFeatureDesc());
									}
								}
							}
							if (lineInfo.getServiceInfo() != null
									&& lineInfo.getServiceInfo().getPricePlanInfo() != null
									&& lineInfo.getServiceInfo().getPricePlanInfo().getPricePlanDesc() != null
									&& lineInfo.getServiceInfo().getPricePlanInfo().getPricePlanCode() != null) {
								oldPlanDetails.add(lineInfo.getServiceInfo().getPricePlanInfo().getPricePlanDesc() + "-"
										+ lineInfo.getServiceInfo().getPricePlanInfo().getPricePlanCode());
							}
							if (lineInfo.getServiceInfo() != null
									&& lineInfo.getServiceInfo().getNewPricePlanInfo() != null
									&& lineInfo.getServiceInfo().getNewPricePlanInfo().getPricePlanDesc() != null
									&& lineInfo.getServiceInfo().getNewPricePlanInfo().getPricePlanCode() != null) {

								newPlanDetails.add(lineInfo.getServiceInfo().getNewPricePlanInfo().getPricePlanDesc()
										+ "-" + lineInfo.getServiceInfo().getNewPricePlanInfo().getPricePlanCode());
							}
							if (lineInfo.getBundleAccessoryInfo() != null
									&& !lineInfo.getBundleAccessoryInfo().isEmpty()) {
								List<BundleAccessory> bundleAccessories = lineInfo.getBundleAccessoryInfo();
								cartinfo.put("bundleCount", String.valueOf(lineInfo.getBundleAccessoryInfo().size()));
								for (BundleAccessory bundleAccessory : bundleAccessories) {
									bundleNames.add(bundleAccessory.getDisplayName());
								}
							}
							if(lineInfo.getItemsInfo()!=null){
								Arrays.stream(lineInfo.getItemsInfo()).filter(Objects::nonNull).forEach(itemsInfo -> {
									Optional.ofNullable(itemsInfo).map(CXPItemInfo::getCartItems).ifPresent(cartItems -> {
										Arrays.stream(cartItems.getCartItem()).filter(Objects::nonNull)
												.forEach(cartItem -> {

													if (cartItem.getCartItemType() != null
															&& "DEVICE".equalsIgnoreCase(cartItem.getCartItemType())) {
														deviceNames.add(cartItem.getDescription());
														deviceBrands.add(cartItem.getManufacturer());
														skuIds.add(cartItem.getSorId());
													}
													if (cartItem.getCartItemType() != null
															&& "ACCESSORY".equalsIgnoreCase(cartItem.getCartItemType())) {
														accessoriesNames.add(cartItem.getDescription());
													}

												});
									});

								});
							}
						});
					});
			Optional.ofNullable(cartResponse).map(ValidateCartUIResponse::getData)
					.map(CXPValidateCartDataVO::getValidateCartAndUpdate).map(CXPCartVO::getGlobalPromotions)
					.ifPresent(globalPromotions -> {
						List<PromoDetails> promoDetails = globalPromotions.getPromoDetails();
						if(promoDetails != null ) {
							for (PromoDetails promoDetail : promoDetails) {
								if (promoDetail.getPromotionId() != null) {
									promoCodes.add(promoDetail.getPromotionId());
								}
							}
						}
					});
			logCartTotalDiscountsInKibana(cartResponse,cartinfo);
			String intendType = String.join("-", lineActivityType);
			cartinfo.put("pageName", "Cart");
			cartinfo.put("flowNames", intendType);
			cartinfo.put("accessoriesNames", String.valueOf(accessoriesNames));
			cartinfo.put("bundleNames", String.valueOf(bundleNames));
			cartinfo.put("deviceNames", String.valueOf(deviceNames));
			cartinfo.put("deviceBrands", String.valueOf(deviceBrands));
			cartinfo.put("skuIds", String.valueOf(skuIds));
			cartinfo.put("oldPlanDetails", String.valueOf(oldPlanDetails));
			cartinfo.put("newPlanDetails", String.valueOf(newPlanDetails));
			cartinfo.put("monthlyAmount", String.valueOf(monthlyAmount));
			cartinfo.put("promoCodes", String.valueOf(promoCodes));
			cartinfo.put("emptycartindicator", String.valueOf(emptyCartIndicator));
			fields.put("cartInfo", JacksonMapperFactory.defaultWriter().writeValueAsString(cartinfo));
			if (StringUtilities.isNotEmptyOrNull(System.getProperty("bvoAccepted")))
				fields.put("BVO.accepted", System.getProperty("bvoAccepted"));
			if (StringUtilities.isNotEmptyOrNull(System.getProperty("bvoRejected")))
				fields.put("BVO.rejected", System.getProperty("bvoRejected"));
			if (StringUtilities.isNotEmptyOrNull(System.getProperty("bvoViewed")))
				fields.put("BVO.viewed", System.getProperty("bvoViewed"));
			LoggerUtil.addCustomPersistField(fields);
			long endTime=System.currentTimeMillis();
			logger.debug("Total time taken in logging cartInfo in kibana {} " ,(endTime-startTime));
		} catch (Exception e) {
			logger.error("Exception while logging Cart details for custom logs", e);
		}
	}
	
	public Map<String, String> updateDeviceCartMapInRedis(ValidateCartUIResponse resp) {
		Map<String, String> sessionData = new HashMap<>();
		AtomicInteger deviceCount = new AtomicInteger();
		AtomicReference<String> cartHasPCD = new AtomicReference<>(CartConstants.FALSE);
		try {
			Optional.ofNullable(resp.getData()).map(CXPValidateCartDataVO::getValidateCartAndUpdate)
					.map(CXPCartVO::getLineDetails).map(CXPLineDetailsVO::getLineInfo).ifPresent(cxpLineInfos -> {
						Arrays.stream(cxpLineInfos).filter(Objects::nonNull).filter(lineInfo -> lineInfo.getItemsInfo()!=null).forEach(cxpLineInfo -> {
							Arrays.stream(cxpLineInfo.getItemsInfo()).filter(Objects::nonNull).forEach(cxpItemInfo -> {
								Optional.ofNullable(cxpItemInfo.getCartItems()).filter(Objects::nonNull).map(CXPCartItemsVO::getCartItem)
										.ifPresent(cxpCartItems -> {
											Arrays.stream(cxpCartItems).filter(Objects::nonNull)
													.forEach(cxpCartItem -> {
														if (StringUtilities
																.isNotEmptyOrNull(cxpCartItem.getCartItemType())
																&& "DEVICE".equalsIgnoreCase(
																cxpCartItem.getCartItemType())) {
															deviceCount.getAndIncrement();
														}
														if (!(cartHasPCD.get().equalsIgnoreCase("true"))
																&& null != cxpCartItem.getIsPreconfigureEnabled()
																&& Boolean.TRUE.equals(cxpCartItem.getIsPreconfigureEnabled())) {
															cartHasPCD.set("true");
														}
													});
										});
							});
						});
					});
		} catch (Exception e) {
			logger.info("Error while getting devicecount from validate cart response {0}" , e);
		}
		sessionData.put(CartConstants.DEVICE_COUNT, deviceCount.toString());
		sessionData.put(CartConstants.CART_HAS_PCD, cartHasPCD.toString());
		return sessionData;
	}
	
	public Mono<ValidateCartCXPResponse> retrieve5GValidateCart(RetrieveCartCXPRequest request, String intentType, boolean orderPlaced) {

		// check for empty cart id in request before cxp call
		if (StringUtilities.isEmptyOrNull(request.getData().getCartId()))
			return CartCxpResponseUtil.formatRetrieveCartEmptyErrorResponsefiveGFlow(orderPlaced);
		formatRequest(request);
		// substitute the qurey param & form graphql query
		String graphqlType = request.getMeta().get("type");

		Mono<ValidateCartCXPResponse> responseServiceMono;
		if (null != intentType && intentType.contains("NSE")) {
			responseServiceMono = cxpService.retrieveNSE5GValidateCart(request.getData().getCartId(), true, "CART",
					false, request.getData().isValidateAppointments(),CartConstants.NEW_CUSTOMER);
		} else {
			//Flag to Avoid NBS call in retrieveCart
			responseServiceMono = cxpService.retrieve5GValidateCart(request.getData().getCartId(), true, "CART", false,request.getData().isValidateAppointments(),
					false);
		}
		ValidateCartCXPResponse soeResponse = new ValidateCartCXPResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(cartResponse -> {
			if (StringUtilities.isEmptyOrNull(graphqlType) && null != cartResponse.getData()) {
				try {
					if(null != cartResponse.getData().getValidateCartAndUpdate() && null !=cartResponse.getData().getValidateCartAndUpdate().getLineDetails()
					&& null != cartResponse.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo())
						fiveGhomeCommonHelper.setPlanPerks(cartResponse.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo());
					return redisHelper3.getDataFromRedis().flatMap(redisData -> {
					updateDLData5g(null, cartResponse, "Validate", null, redisData);
						return Mono.just(cartResponse);
					});
				} catch (Exception e) {
					logger.error(CartConstants.RETRIEVE_OMNIDL_EXCEPTION, e);
				}
			}
			return Mono.just(cartResponse);
		});
	}
	
	/**
	 *
	 * @param request
	 * @return RetrieveCartUIResponse
	 *
	 */
	public Mono<RetrieveCartUIResponse> retrieve5GCart(RetrieveCartCXPRequest request, boolean orderPlaced) {

		// check for empty cart id in request before cxp call
		if (StringUtilities.isEmptyOrNull(request.getData().getCartId()))
			return CartCxpResponseUtil.formatRetrieveCartEmptyFiveGErrorResponse(orderPlaced);
		if (null == request.getMeta() || !request.getMeta().containsKey("type")) {
			Map<String, String> meta = new HashMap<>();
			meta.put("type", "");
			request.setMeta(meta);
		}

		// substitute the qurey param & form graphql query
		String graphqlType = request.getMeta().get("type");

		if (request.getData().getRetrieveCurrentFeatures() == null)
			request.getData().setRetrieveCurrentFeatures(false);

		Mono<RetrieveCartCXPResponse> responseServiceMono;

		responseServiceMono = cxpService.retrieve5GCart(request.getData().getCartId(),
				request.getData().getRetrieveCurrentFeatures(), request.getData().getMtnList());
		RetrieveCartUIResponse soeResponse = new RetrieveCartUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(cartResponse -> {
			// convert cxpResponse into soeResponse
			CartCxpResponseUtil1.formatRetrieveCartResponse(soeResponse, cartResponse, false, false);
			if (StringUtilities.isEmptyOrNull(graphqlType) && null != cartResponse.getData()) {
				try {
					return redisHelper3.getDataFromRedis().flatMap(redisData -> {
					updateDLData5g(cartResponse, null, "Retrieve", null, redisData);
						return Mono.just(soeResponse);
					});
				} catch (Exception e) {
					logger.error(CartConstants.RETRIEVE_OMNIDL_EXCEPTION, e);
				}
			}
			return Mono.just(soeResponse);
		});
	}

	public Mono<String> getCJMTagUrl(GetCartDetailsRequest request, FiveGLTEAddressRedis data){
		Mono<FWAOrderConfirmationCXPResponse> retrieveCJMTagResponseMono = cxpService.getCJMTagUrl(data.getCompletedCartId(),CartConstants.DEVICETYPE, request.getCjevent(),request.getAffiliate());
		return retrieveCJMTagResponseMono == null ? Mono.empty() : retrieveCJMTagResponseMono.flatMap(tagResponse -> {
			Optional<FWAOrderConfirmationCXPResponse> optionalTagResponse =  Optional.ofNullable(tagResponse);
			String tagUrl = optionalTagResponse.map(FWAOrderConfirmationCXPResponse::getData).map(OrderConfirmationCXPData::getGetConfirmationPage).map(FWAConfirmationPageInfo::getCjmTagUrl).orElse("");
			return Mono.just(tagUrl);
		}).onErrorResume(cxpError -> {
			LoggerUtil.logOnError(r -> logger.error("getCJMTagUrl_GQL_Call_FAILED", cxpError));
			return Mono.just("");
		});
	}

	private static void formatRequest(RetrieveCartCXPRequest request) {
		if (null == request.getMeta() || !request.getMeta().containsKey("type")) {
			Map<String, String> meta = new HashMap<>();
			meta.put("type", "");
			request.setMeta(meta);
		}
		if (request.getData().getRetrieveCurrentFeatures() == null)
			request.getData().setRetrieveCurrentFeatures(false);
	}
	
	public void updateDLData5g(RetrieveCartCXPResponse retrieveCartResponse,
			   ValidateCartCXPResponse validateCartResponse, String methodType, String promosAppliedVal, CartRedisData data) {
		dlService.buildDLData(
				OmniBuilder.fromCart5g(retrieveCartResponse, validateCartResponse, methodType, promosAppliedVal, data));
	}

	/**
	 * @param request
	 * @return RetrieveCartUIResponse
	 */
	public Mono<BundleBuilderCXPResponseData> bundleBuilderCart(BundleBuilderRequest request) {

        ArrayList<String> namespaces = new ArrayList<>();
        
		if (!gqlPromoBundleBuilderOptmizationEnabled) {
			namespaces.add("gql-attribute-optimized");
		}
		var uiSelectedOffer = StringUtils.isNotBlank(request.getSelectedOfferId()) ? request.getSelectedOfferId() : StringUtils.EMPTY;
		return featureFlag.isWinbackOfferFlagEnabled().flatMap(value -> {
			var selectedOfferId = StringUtils.EMPTY;
			if(Boolean.TRUE.equals(value)) {
				 selectedOfferId = request.isPromoChoiceOffer() &&
						(CartConstants.NOPROMO.equalsIgnoreCase(uiSelectedOffer) || (!request.isStrategicOfferEnabled() && !request.isWinBackOfferSelected()))
						? StringUtils.EMPTY :  uiSelectedOffer;
			} else {
				 selectedOfferId = request.isPromoChoiceOffer() &&
						(CartConstants.NOPROMO.equalsIgnoreCase(uiSelectedOffer) || !request.isStrategicOfferEnabled())
						? StringUtils.EMPTY :  uiSelectedOffer;
			}
			return cxpService.bundleBuilderCart(request.getCartId(), request.getPageId(), request.isCachedOffer(), selectedOfferId, request.isStrategicOfferEnabled(), request.getAccountNumber(), request.getMtn(),request.getOfferFilters(),CartConstants.DISABLE_OMP,request.getProcessingMtn(),namespaces);
		});

	}

	private void logCartTotalDiscountsInKibana(ValidateCartUIResponse cartResponse,Map<String,String> cartinfo){
		List<String> promoTypes = new ArrayList<>();
		List<String> discountAmtDetails = new ArrayList<>();
		List<String> discountNameDetails = new ArrayList<>();
		Optional.ofNullable(cartResponse).map(ValidateCartUIResponse::getData)
				.map(CXPValidateCartDataVO::getValidateCartAndUpdate).map(CXPCartVO::getOrderDetails)
				.ifPresent(orderDetails -> {
					DiscountSummary discountSummary = orderDetails.getCartTotalDiscounts();
					if(discountSummary != null ) {
						cartinfo.put(CartConstants.TOTAL_CART_DISCOUNT,discountSummary.getTotalDiscount());
						List<DiscountSummaryDetails> discountSummaryDetails = discountSummary.getDiscountDetails();
						if(CollectionUtilities.isNotEmptyOrNull(discountSummaryDetails)) {
							discountSummaryDetails.forEach(discountItems -> {
								if (CollectionUtilities.isNotEmptyOrNull(discountItems.getDiscountItems())) {
									discountItems.getDiscountItems().forEach(discountItem -> {
										promoTypes.add(discountItem.getPromoType());
										discountAmtDetails.add(discountItem.getOfferAmount());
										discountNameDetails.add(discountItem.getDiscountName());
									});
								}
							});
						}
					}
				});
		cartinfo.put(CartConstants.CART_PROMO_TYPE,String.valueOf(promoTypes));
		cartinfo.put(CartConstants.CART_DISC_AMT,String.valueOf(discountAmtDetails));
		cartinfo.put(CartConstants.CART_DISC_NAMES,String.valueOf(discountNameDetails));
	}

	public void appendDlVZPageSubflow(String subflow) {
		dlUtilityService.upsertVZPageSubFLow(subflow, true, "").subscribeOn(Schedulers.parallel())
				.subscribe();
		logger.debug("added {} subflow in vzPageDl",subflow);
	}

	public Mono<Brands> getBrands(GetBrandsRequest request) {
		List<String> brandsFromProperties=new ArrayList<>();
		if(Objects.nonNull(request) && StringUtilities.isNotEmptyOrNull(request.getDeviceCategory())) {
			try {
				switch (request.getDeviceCategory().toLowerCase()) {
					case CartConstants.SMARTPHONES:
					case CartConstants.SMARTPHONE_SINGULAR:
						brandsFromProperties = smartPhonesBrands;
						break;
					case CartConstants.TABLETS_LOWERCASE:
					case CartConstants.TABLETS_SINGULAR:
						brandsFromProperties = tabletsBrands;
						break;
					default:
						return getBrandsMono(request.getDeviceCategory(), brandsFromProperties);
				}
				return getBrandsMono(request.getDeviceCategory(), brandsFromProperties);
			}
			catch(Exception e){
				logger.error("CartServiceCxphelper :: getBrands :: Exception occurred : {}" , e);
				return Mono.just(new Brands());
			}
		}
		brandsFromProperties = smartPhonesBrands;
		return getBrandsMono(CartConstants.SMARTPHONES, brandsFromProperties);
	}

	private Mono<Brands> getBrandsMono(String deviceCategory, List<String> brandsFromProperties) {
		Brands brands=new Brands();
		return getSmartImeiTypeAheadResponseFromCatalog(deviceCategory).flatMap(brandsFromCatalog -> {
			logger.info("CartServiceCxphelper :: getBrandsMono :: brands from properties : {}" , brandsFromProperties);
			if (Objects.nonNull(brandsFromCatalog) && CollectionUtilities.isNotEmptyOrNull(brandsFromCatalog.getBrands())
					&& CollectionUtilities.isNotEmptyOrNull(brandsFromProperties)) {
				List<String> finalBrands=new ArrayList<>();
				finalBrands.addAll(brandsFromProperties);
				brandsFromCatalog.getBrands().removeAll(brandsFromProperties);
				finalBrands.addAll(brandsFromCatalog.getBrands());
				brands.setBrands(finalBrands);
				return Mono.just(brands);
			}
			return Mono.just(brandsFromCatalog);
		});
	}

	public Mono<Brands> getSmartImeiTypeAheadResponseFromCatalog(String deviceCategory) {
		SmartImeiTypeAheadCXPRequest cxpRequest = CartCxpRequestUtil.createSmartImeiTypeAheadRequest(deviceCategory);
		Brands brands = new Brands();
		Set<String> uniqueListOfBrands = new TreeSet<String>();
		return catalogService.smartImeiTypeAhead(cxpRequest).flatMap(resp->{
			if (Objects.nonNull(resp) && Objects.nonNull(resp.getData().getSmartImeiTypeAheadDetails())) {
				for (SmartImeiTypeAheadDetails smartImeiTypeAheadDetail:resp.getData().getSmartImeiTypeAheadDetails()) {
					if (Objects.nonNull(smartImeiTypeAheadDetail) && StringUtilities.isNotEmptyOrNull(smartImeiTypeAheadDetail.getMakeTypeahead())) {
						uniqueListOfBrands.add(smartImeiTypeAheadDetail.getMakeTypeahead());
					}
				}
				if(CollectionUtilities.isNotEmptyOrNull(uniqueListOfBrands)) {
					brands.setBrands(Lists.newArrayList(uniqueListOfBrands));
				}
			}
			logger.info("CartServiceCxphelper :: getSmartImeiTypeAheadResponseFromCatalog :: brands from catalog : {}" , brands);
			 return Mono.just(brands);
		});
	}
	public Mono<EidSimDetailsUIResponse > EidSimDetail(ESimDetailsETNIRequest request) {
		Mono<SimEidDetailsETNIResponse> responseServiceMono = cxpService.simEidDetails(request)
				.doOnError(e -> logger.error("Exception occur in eSimDetails method and error={0}", e))
				.onErrorResume(SOEHTTPException.class, e -> {
					try {
						return Mono.just(mapper.readValue(e.getMessage(), SimEidDetailsETNIResponse.class));
					} catch (JsonProcessingException e1) {
						logger.error("Exception occur in catch  eSimDetails method and error={0}", e1);
						return Mono.just(new SimEidDetailsETNIResponse());
					}
				});
		EidSimDetailsUIResponse soeResponse = new EidSimDetailsUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(cartResponse -> {
			// convert cxpResponse into soeResponse
			CartCxpResponseUtil1.formatEidSimDetails(soeResponse,cartResponse);
			return Mono.just(soeResponse);
		});
	}

	@SuppressWarnings({"java:S3776"})
	public void performMaskingForBYOD(CXPCartVO cart){
		String channelId = RequestAccessContext.getRequestHeader(CartConstants.CHANNEL_ID);
		if(Boolean.TRUE.equals(featureFlag.isMaskingForBYODFFlag()) && StringUtilities.isNotEmptyOrNull(channelId)
				&& CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId))
				&& null!=cart.getLineDetails() && ArrayUtils.isNotEmpty(cart.getLineDetails().getLineInfo())){
			Arrays.stream(cart.getLineDetails().getLineInfo()).forEach(lineInfo -> {
				if(null!=lineInfo && null!=lineInfo.getItemsInfo()){
					Arrays.stream(lineInfo.getItemsInfo()).forEach(itemInfo -> {
						if(null!=itemInfo && null!=itemInfo.getCartItems() && null!=itemInfo.getCartItems().getCartItem()){
							Arrays.stream(itemInfo.getCartItems().getCartItem()).forEach(cartItem -> {
								if(null!=cartItem) {
									if (StringUtilities.isNotEmptyOrNull(cartItem.getDeviceId())) {
										cartItem.setDeviceId(CartUtil.maskStringField(cartItem.getDeviceId(), 4));
									}
									if (StringUtilities.isNotEmptyOrNull(cartItem.getESIM())) {
										cartItem.setESIM(CartUtil.maskStringField(cartItem.getESIM(), 4));
									}
								}
							});
						}
					});
				}
			});
		}

	}


	public Mono<CartExceedsLimitResponse> getCartExceedsLimitCXPResponse(CartExceedsLimitRequest cartExceedsLimitRequest){
		return cxpService.getCartExceedsLimitCXPResponse(cartExceedsLimitRequest);
	}
}
