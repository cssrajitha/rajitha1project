package onevz.soe.cart.util;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.activateLater.ActivateLaterContext;
import onevz.soe.cart.model.activateLater.ActivateLaterServiceBody;
import onevz.soe.cart.model.activateLater.ActivateLaterServiceRequest;
import onevz.soe.cart.model.addNickName.AddNickNameContext;
import onevz.soe.cart.model.addNickName.AddNickNameLine;
import onevz.soe.cart.model.addNickName.AddNickNameServiceBody;
import onevz.soe.cart.model.addNickName.AddNickNameServiceRequest;
import onevz.soe.cart.model.cancelCase.CancelCaseContext;
import onevz.soe.cart.model.cancelCase.CancelCaseServiceBody;
import onevz.soe.cart.model.cancelCase.CancelCaseServiceRequest;
import onevz.soe.cart.model.clearAndContinue.ClearAndContinueContext;
import onevz.soe.cart.model.clearAndContinue.ClearAndContinueServiceBody;
import onevz.soe.cart.model.clearAndContinue.ClearAndContinueServiceRequest;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.getCase.*;
import onevz.soe.cart.model.myOffer.MyOfferLine;
import onevz.soe.cart.model.myOffers.CompatiableOffer;
import onevz.soe.cart.model.resumeAndContinue.ResumeAndContinueContext;
import onevz.soe.cart.model.resumeAndContinue.ResumeAndContinueServiceBody;
import onevz.soe.cart.model.resumeAndContinue.ResumeAndContinueServiceRequest;
import onevz.soe.cart.model.saveCart.SaveCartContext;
import onevz.soe.cart.model.saveCart.SaveCartServiceBody;
import onevz.soe.cart.model.saveCart.SaveCartServiceRequest;
import onevz.soe.cart.model.transferUpgrade.UpdateTransferUpgradeContext;
import onevz.soe.cart.model.transferUpgrade.UpdateTransferUpgradeServiceBody;
import onevz.soe.cart.model.transferUpgrade.UpdateTransferUpgradeServiceRequest;
import onevz.soe.cart.model.updateChatId.UpdateChatIdContext;
import onevz.soe.cart.model.updateChatId.UpdateChatIdServiceBody;
import onevz.soe.cart.model.updateChatId.UpdateChatIdServiceRequest;
import onevz.soe.cart.requests.*;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.MyOfferETRRedisData;
import onevz.soe.cart.ui.common.*;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class CartPegaRequestUtil6 {
    private static final Logger logger = LoggerFactory.getLogger(CartPegaRequestUtil6.class);
    /**
     *
     * @param uiRequest
     * @param pegaRequest
     * @return CancelCasePEGARequest
     */
    public static CancelCasePEGARequest formatCancelCaseRequest(CancelCasePEGARequest pegaRequest,
                                                                CancelCaseUIRequest uiRequest) {

        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(uiRequest.getChannelId());
        pegaRequest.setServiceHeader(serviceHeader);

        CancelCaseServiceBody serviceBody = new CancelCaseServiceBody();
        CancelCaseServiceRequest serviceRequest = new CancelCaseServiceRequest();
        CancelCaseContext context = new CancelCaseContext();

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(uiRequest.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(uiRequest.getCartInfo().getCartCreator());
        customerInfo.setProcessingMTN(uiRequest.getCartInfo().getProcessingMTN());



        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(uiRequest.getCartInfo().getCartId());
        cartInfo.setItemType("CARTSTATUS");
        if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getIntendType()))
            cartInfo.setIntendType(uiRequest.getCartInfo().getIntendType());
        else
            cartInfo.setIntendType(CartConstants.EUP);
        if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getStatus()))
            cartInfo.setStatus(uiRequest.getCartInfo().getStatus());
        else
            cartInfo.setStatus(CartConstants.INACTIVE);
        cartInfo.setAction(CartConstants.UPDATE);
        context.setCartInfo(cartInfo);

        // ContextInfo needs to be updated upon receiving PEGA contracts
        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.CANCEL, uiRequest.getCartInfo().getClientAppName());
        if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getProcessStep())) {
            contextInfo.setProcessStep(uiRequest.getCartInfo().getProcessStep());
        } else {
            contextInfo.setProcessStep(CartConstants.EXIT_PAGE);
        }
        if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getIntendType())
                && CartConstants.AAL.equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())) {
            contextInfo.setIntent(CartConstants.AAL);
        } else {
            contextInfo.setIntent(CartConstants.UPGRADE);
        }

        if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getIntendType()) &&
                uiRequest.getCartInfo().getIntendType().equalsIgnoreCase(CartConstants.REFUND_EXCHANGE)) {
            contextInfo.setIntent(CartConstants.REX);
            contextInfo.setCallReason(CartConstants.SALES_ORDER_ADJUSTMENT);
            contextInfo.setProcessAction("");
            contextInfo.setProcessStep("cancel");
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_ADJUSTMENT);
            if(CartConstants.DIGITAL_CLIENT_APP.contains(uiRequest.getChannelId())) {
                contextInfo.setProcessStep(StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getProcessStep()) ? uiRequest.getCartInfo().getProcessStep() : "Order-Review");
                contextInfo.setProcessAction(StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getProcessAction()) ? uiRequest.getCartInfo().getProcessAction() : "cancel");
            }
        }
        if (CartConstants.NSE_BYOD.equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())
                || CartConstants.NSE.equalsIgnoreCase(uiRequest.getCartInfo().getIntendType()) || CartConstants.NSE_5G.equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())) {
            CartPegaRequestUtil7.newCustomerOverride(contextInfo, customerInfo, uiRequest.getCartInfo(), uiRequest.getChannelId());
        }
        else if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getIntendType()) &&
                uiRequest.getCartInfo().getIntendType().equalsIgnoreCase(CartConstants.CLNR_FLOW)) {
            contextInfo.setIntent(CartConstants.CLNR_FLOW);
            contextInfo.setCallReason(CartConstants.SALES_ORDER_ADJUSTMENT);
            contextInfo.setProcessAction("Cancel");
            contextInfo.setProcessStep("Cancel");
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_ADJUSTMENT);
        }
        context.setCustomerInfo(customerInfo);

        //MVP2-GR
        if(uiRequest.getCartInfo()!=null && uiRequest.getCartInfo().getCaseId()!=null && uiRequest.getCartInfo().getCaseId().startsWith("SOF")){

            logger.info("SalesOrderFlex Prepay cancel case Request before PEGA call setting Call Reason");
            contextInfo.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }

        context.setContextInfo(contextInfo);
        context.setCaseId(uiRequest.getCartInfo().getCaseId());

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);
        return pegaRequest;

    }

    /**
     * @param pegaRequest
     * @param request
     * @return AddPlanPEGARequest
     */
    public static ActivateLaterPEGARequest formatActivateLaterRequest(ActivateLaterPEGARequest pegaRequest,
                                                                      ActivateLaterUIRequest request) {

        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        serviceHeader = CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(request.getChannelId());
        pegaRequest.setServiceHeader(serviceHeader);

        ActivateLaterServiceBody serviceBody = new ActivateLaterServiceBody();
        ActivateLaterServiceRequest serviceRequest = new ActivateLaterServiceRequest();
        ActivateLaterContext context = new ActivateLaterContext();

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
        customerInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());
        context.setCustomerInfo(customerInfo);

        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(request.getCartInfo().getCartId());
        cartInfo.setClientAppName(request.getCartInfo().getClientAppName());
        cartInfo.setItemType(CartConstants.ACTIVATE_LATER);
        cartInfo.setAction(CartConstants.UPDATE);
        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType()))
            cartInfo.setIntendType(request.getCartInfo().getIntendType());
        else
            cartInfo.setIntendType(CartConstants.EUP);
        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        contextInfo = CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.ACTIVATE_LATER,
                request.getCartInfo().getClientAppName());

        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                && CartConstants.AAL.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
            contextInfo.setIntent(CartConstants.AAL);
        } else {
            contextInfo.setIntent(CartConstants.UPGRADE);
        }
        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessAction()))
            contextInfo.setProcessAction(request.getCartInfo().getProcessAction());
        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessStep())) {
            contextInfo.setProcessStep(request.getCartInfo().getProcessStep());
        } else {
            contextInfo.setProcessStep(CartConstants.ORDER_REVIEW_SHIPPING);
        }

        List<Line> lines = new ArrayList<>();

        for (Lines reqLine : request.getData().getLines()) {
            Line newLine = new Line();
            if (reqLine.getMtn() != null)
                newLine.setMtn(reqLine.getMtn());
            if (reqLine.getActivateLater() != null)
                newLine.setActivateLater(reqLine.getActivateLater());
            if (reqLine.getSetUpLater() != null)
                newLine.setSetUpLater(reqLine.getSetUpLater());
            lines.add(newLine);
        }
        Line[] lineArr = new Line[lines.size()];
        lines.toArray(lineArr);

        cartInfo.setLines(lineArr);

        //MVP2-GR
        if(request.getCartInfo()!=null && request.getCartInfo().getCaseId()!=null && request.getCartInfo().getCaseId().startsWith("SOF")){

            logger.info("SalesOrderFlex Prepay activate later Request before PEGA call setting Call Reason");
            contextInfo.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }

        context.setCartInfo(cartInfo);
        context.setContextInfo(contextInfo);
        context.setCaseId(request.getCartInfo().getCaseId());

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);

        return pegaRequest;

    }

    /**
     *
     * @param pegaRequest
     * @param uiRequest
     * @return pegaRequest
     */
    public static ClearAndContinuePegaRequest formatClearAndContinueRequest(ClearAndContinuePegaRequest pegaRequest,
                                                                            ClearAndContinueUIRequest uiRequest) {
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();

        ClearAndContinueServiceBody serviceBody = new ClearAndContinueServiceBody();
        ClearAndContinueServiceRequest serviceRequest = new ClearAndContinueServiceRequest();
        ClearAndContinueContext context = new ClearAndContinueContext();
        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        CartServiceContextInfo contextInfo = new CartServiceContextInfo();

        settingCustomerInfo(serviceHeader,customerInfo,context,uiRequest);

        cartInfo.setCartId("");
        cartInfo.setFromFreePhoneQV(uiRequest.getCartInfo().isFromFreePhoneQV());

        //clearAndContinue standalone accessory NSEACC implementation
        if(StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getProspectCartId())) {
            cartInfo.setProspectCartId(uiRequest.getCartInfo().getProspectCartId());
        }
        if(StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getCartId()) && StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getIntendType())&& CartConstants.NSEACC.equalsIgnoreCase(uiRequest.getCartInfo().getIntendType()))
        {
            cartInfo.setCartId(uiRequest.getCartInfo().getCartId());
        }
        //clearAndContinue standalone accessory NSEACC implementation
        Optional<String> processStepOptional= Optional.ofNullable(uiRequest.getCartInfo().getProcessStep());
        contextInfo.setProcessStep(processStepOptional.isPresent() ? uiRequest.getCartInfo().getProcessStep() : CartConstants.MTN_SELECTION_PAGE);
        contextInfo.setCallReason(CartConstants.SALES_ORDER_PURCHASE);
        contextInfo.setAction("Restart");

        context.setCustomerInfo(customerInfo);

        //MVP2-GR
        if(uiRequest.getCartInfo()!=null && uiRequest.getCartInfo().getCaseId()!=null && uiRequest.getCartInfo().getCaseId().startsWith("SOF")){

            logger.info("SalesOrderFlex Prepay clear and continue Request before PEGA call setting Call Reason");
            contextInfo.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }

        context.setContextInfo(contextInfo);
        context.setCartInfo(cartInfo);
        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);
        pegaRequest.setServiceHeader(serviceHeader);
        return pegaRequest;
    }

    /**
     *
     * @param pegaRequest
     * @param uiRequest
     * @return pegaRequest
     */
    public static ClearAndContinuePegaRequest formatClearandResumeRequest(ClearAndContinuePegaRequest pegaRequest,
                                                                          ClearAndContinueUIRequest uiRequest) {
        CartServiceServiceHeader serviceHeader1 = new CartServiceServiceHeader();

        ClearAndContinueServiceBody serviceBody1 = new ClearAndContinueServiceBody();
        ClearAndContinueServiceRequest serviceRequest1 = new ClearAndContinueServiceRequest();
        ClearAndContinueContext context1 = new ClearAndContinueContext();
        CartServiceCustomerInfo customerInfo1 = new CartServiceCustomerInfo();
        CartServiceCartInfo cartInfo1 = new CartServiceCartInfo();
        CartServiceContextInfo contextInfo1 = new CartServiceContextInfo();

        settingCustomerInfo(serviceHeader1,customerInfo1,context1,uiRequest);


        cartInfo1.setIntendType(uiRequest.getCartInfo().getIntendType());
        cartInfo1.setCartId(uiRequest.getCartInfo().getCartId());

        //clearAndContinue standalone accessory NSEACC implementation
        if(StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getProspectCartId())) {
            cartInfo1.setProspectCartId(uiRequest.getCartInfo().getProspectCartId());
        }
        //clearAndContinue standalone accessory NSEACC implementation
        contextInfo1.setProcessStep(CartConstants.MTN_SELECTION_PAGE);
        contextInfo1.setCallReason(CartConstants.SALES_ORDER_PURCHASE);
        if(CartConstants.AAL.equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())) {
            contextInfo1.setProcessAction(CartConstants.RESTART_AND_ADD_DEVICE);
            contextInfo1.setIntent(CartConstants.AAL);
        }else if(CartConstants.ACC.equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())){
            contextInfo1.setIntent(CartConstants.STANDALONEACCESSORY);
        }

        context1.setCustomerInfo(customerInfo1);

        //MVP2-GR
        if(uiRequest.getCartInfo()!=null && uiRequest.getCartInfo().getCaseId()!=null && uiRequest.getCartInfo().getCaseId().startsWith("SOF")){

            logger.info("SalesOrderFlex Prepay clear and resume Request before PEGA call setting Call Reason");
            contextInfo1.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader1.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }

        context1.setContextInfo(contextInfo1);
        context1.setCartInfo(cartInfo1);
        serviceRequest1.setContext(context1);
        serviceBody1.setServiceRequest(serviceRequest1);
        pegaRequest.setServiceBody(serviceBody1);
        pegaRequest.setServiceHeader(serviceHeader1);
        return pegaRequest;
    }

      public static void settingCustomerInfo(CartServiceServiceHeader serviceHeader,CartServiceCustomerInfo customerInfo,
                                       ClearAndContinueContext context,ClearAndContinueUIRequest uiRequest){

          CartPegaRequestUtil.addServiceHeader(serviceHeader);

          serviceHeader.setClientId(uiRequest.getChannelId());
          context.setCaseId(uiRequest.getCartInfo().getCaseId());
          customerInfo.setAccountNumber(uiRequest.getCartInfo().getAccountNumber());
          customerInfo.setUniversalId(uiRequest.getUniversalId());
          customerInfo.setCartCreator(uiRequest.getCartInfo().getCartCreator());
          customerInfo.setProcessingMTN(uiRequest.getCartInfo().getProcessingMTN());
          customerInfo.setCartCreatorOrderLocationCode(uiRequest.getCartInfo().getLocationCode());
        if( StringUtilities.isNotEmptyOrNull(uiRequest.getChannelId()) &&
                CartConstants.DIGITAL_CLIENT_APP.contains(uiRequest.getChannelId())) {
            customerInfo.setAmRole(uiRequest.getCartInfo().getAmRole());
        }
          if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getSalesRepId()))
              customerInfo.setCartCreatorSalesRepId(uiRequest.getCartInfo().getSalesRepId());
          if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getFlowType()))
              customerInfo.setFlowType(uiRequest.getCartInfo().getFlowType());

//        sending BYOD flag., for BYOD flow
          if(StringUtilities.isNotEmptyOrNull(uiRequest.getChannelId()) &&
                  CartConstants.DIGITAL_CLIENT_APP.contains(uiRequest.getChannelId())) {
            customerInfo.setIsBYODSession(uiRequest.getCartInfo().getIsBYODSession());
          }
      }

    /**
     *
     * @param pegaRequest
     * @param uiRequest1
     * @return pegaRequest
     */
    public static ResumeAndContinuePegaRequest formatResumeAndContinueRequest(ResumeAndContinuePegaRequest pegaRequest,
                                                                              ResumeAndContinueUIRequest uiRequest1) {
        CartServiceServiceHeader serviceHeader2 = new CartServiceServiceHeader();

        ResumeAndContinueServiceBody serviceBody2 = new ResumeAndContinueServiceBody();
        ResumeAndContinueServiceRequest serviceRequest2 = new ResumeAndContinueServiceRequest();
        ResumeAndContinueContext context2 = new ResumeAndContinueContext();
        CartServiceCustomerInfo customerInfo2 = new CartServiceCustomerInfo();
        CartServiceCartInfo cartInfo2 = new CartServiceCartInfo();
        CartServiceContextInfo contextInfo2 = new CartServiceContextInfo();

        CartPegaRequestUtil.addServiceHeader(serviceHeader2);

        serviceHeader2.setClientId(uiRequest1.getChannelId());
        context2.setCaseId(uiRequest1.getCartInfo().getCaseId());
        customerInfo2.setAccountNumber(uiRequest1.getCartInfo().getAccountNumber());
        customerInfo2.setCartCreator(uiRequest1.getCartInfo().getCartCreator());
        customerInfo2.setProcessingMTN(uiRequest1.getCartInfo().getProcessingMTN());
        customerInfo2.setCartCreatorOrderLocationCode(uiRequest1.getCartInfo().getLocationCode());
        if (StringUtilities.isNotEmptyOrNull(uiRequest1.getCartInfo().getSalesRepId()))
            customerInfo2.setCartCreatorSalesRepId(uiRequest1.getCartInfo().getSalesRepId());
        if (StringUtilities.isNotEmptyOrNull(uiRequest1.getCartInfo().getFlowType()))
            customerInfo2.setFlowType(uiRequest1.getCartInfo().getFlowType());
        cartInfo2.setCartId(uiRequest1.getCartInfo().getCartId());
        cartInfo2.setItemType("RESUME");
        cartInfo2.setAction(CartConstants.UPDATE);
        contextInfo2.setProcessStep(CartConstants.MTN_SELECTION_PAGE);
        contextInfo2.setCallReason(CartConstants.SALES_ORDER_PURCHASE);
        contextInfo2.setAction(CartConstants.RESUME);

        context2.setCustomerInfo(customerInfo2);

        //MVP2-GR
        if(uiRequest1.getCartInfo()!=null && uiRequest1.getCartInfo().getCaseId()!=null && uiRequest1.getCartInfo().getCaseId().startsWith("SOF")){

            logger.info("SalesOrderFlex Prepay resume and continue Request before PEGA call setting Call Reason");
            contextInfo2.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader2.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }

        context2.setContextInfo(contextInfo2);
        context2.setCartInfo(cartInfo2);
        serviceRequest2.setContext(context2);
        serviceBody2.setServiceRequest(serviceRequest2);
        pegaRequest.setServiceBody(serviceBody2);
        pegaRequest.setServiceHeader(serviceHeader2);
        return pegaRequest;
    }

    /**
     *
     * @param applyOfferRequest
     * @param planOffers
     * @return uiRequest
     */
    public static AddPlanUIRequest buildAddPlanRequest(ApplyOfferRequest applyOfferRequest,
                                                       CompatiableOffer planOffers) {
        AddPlanUIRequest request = new AddPlanUIRequest();

        CartInfo cartInfo = new CartInfo();
        cartInfo.setClientAppName(applyOfferRequest.getCartInfo().getClientAppName());
        cartInfo.setCartId(applyOfferRequest.getCartInfo().getCartId());
        cartInfo.setCaseId(applyOfferRequest.getCartInfo().getCaseId());
        cartInfo.setAccountNumber(applyOfferRequest.getCartInfo().getAccountNumber());
        cartInfo.setCartCreator(applyOfferRequest.getCartInfo().getCartCreator());
        cartInfo.setProcessingMTN(applyOfferRequest.getCartInfo().getProcessingMTN());
        cartInfo.setProcessStep(CartConstants.PLAN_SELECTION);
        cartInfo.setIntendType(CartConstants.CPC);
        request.setCartInfo(cartInfo);

        AddPlanData addPlanData = new AddPlanData();

        List<Lines> lines = new ArrayList<Lines>();

        planOffers.getCompatiableofferLines().stream().forEach(offerLine -> {
            Lines line = new Lines();
            line.setMtn(offerLine.getMtn());
            Plan plan = new Plan();
            offerLine.getOffers().stream().forEach(offerPlan -> {
                plan.setId(offerPlan.getSku());
            });
            line.setPlan(plan);
            lines.add(line);
        });
        addPlanData.setLines(lines.stream().toArray(Lines[]::new));
        request.setData(addPlanData);

        return request;

    }

    /**
     *
     * @param applyOfferRequest
     * @param featureOffers
     * @return uiRequest
     */
    public static AddFeaturesUIRequest buildAddFeaturesRequest(ApplyOfferRequest applyOfferRequest,
                                                               CompatiableOffer featureOffers) {
        AddFeaturesUIRequest request = new AddFeaturesUIRequest();

        CartInfo cartInfo = new CartInfo();
        cartInfo.setClientAppName(applyOfferRequest.getCartInfo().getClientAppName());
        cartInfo.setCartId(applyOfferRequest.getCartInfo().getCartId());
        cartInfo.setCaseId(applyOfferRequest.getCartInfo().getCaseId());
        cartInfo.setAccountNumber(applyOfferRequest.getCartInfo().getAccountNumber());
        cartInfo.setProcessingMTN(applyOfferRequest.getCartInfo().getProcessingMTN());
        cartInfo.setCartCreator(applyOfferRequest.getCartInfo().getCartCreator());
        cartInfo.setIntendType(CartConstants.EUP);
        cartInfo.setProcessStep(CartConstants.FEATURES_PDP);
        request.setCartInfo(cartInfo);

        AddFeaturesData addFeaturesdata = new AddFeaturesData();
        List<LineFeature> lines = new ArrayList<LineFeature>();

        featureOffers.getCompatiableofferLines().stream().forEach(offerLine -> {
            LineFeature line = new LineFeature();
            line.setMtn(offerLine.getMtn());
            FeatureAction featureAction = new FeatureAction();
            List<Feature> featureList = new ArrayList<Feature>();
            offerLine.getOffers().stream().forEach(offerFeature -> {
                Feature feature = new Feature();
                feature.setId(offerFeature.getSku());
                feature.setActionIndicator("A");
                feature.setType(offerFeature.getComplianceType());
                feature.setQuantity(1);
                if (CollectionUtilities.isNotEmptyOrNull(offerFeature.getMtnList())) {
                    List<Mtns> mtns = new ArrayList<Mtns>();
                    offerFeature.getMtnList().stream().forEach(mtn -> {
                        Mtns mtnObj = new Mtns();
                        mtnObj.setMtn(mtn);
                        mtns.add(mtnObj);
                    });
                    feature.setMtns(mtns);
                }
                featureList.add(feature);
            });

            featureAction.setAdd(featureList);
            line.setFeatures(featureAction);
            lines.add(line);
        });

        addFeaturesdata.setLines(lines.stream().toArray(LineFeature[]::new));
        request.setData(addFeaturesdata);

        return request;
    }

    /**
     *
     * @param redisData
     * @param cartId
     * @param caseId
     * @return uiRequest
     */
    public static AddAccessoriesUIRequest formAddAccessoryRequest(CartRedisData redisData, String cartId,
                                                                  String caseId) {
        AddAccessoriesUIRequest addAccessoryUIRequest = new AddAccessoriesUIRequest();
        AddAccessoriesData addAccessoryData = new AddAccessoriesData();

        redisData.setCartId(cartId);
        redisData.setCaseId(caseId);
        addAccessoryUIRequest.setCartInfo(redisData.getAccessoryCartInfo());

        Lines[] linesArr = new Lines[redisData.getLines().size()];
        addAccessoryData.setLines((redisData.getLines()).toArray(linesArr));
        if (StringUtilities.isNotEmptyOrNull(redisData.getDepletionType()))
            addAccessoryData.setDepletionType(redisData.getDepletionType());
        addAccessoryUIRequest.setData(addAccessoryData);

        return addAccessoryUIRequest;
    }

    /**
     *
     * @param redisData
     * @param cartId
     * @param caseId
     * @return uiRequest
     */
    public static AddDeviceUIRequest formAddDeviceRequest(CartRedisData redisData, String cartId, String caseId, String channelId, CartInfo cartInfo) {
        AddDeviceUIRequest addDeviceUIRequest = new AddDeviceUIRequest();
        AddDeviceData addDeviceData = new AddDeviceData();

        redisData.getDeviceCartInfo().setCartId(cartId);
        redisData.getDeviceCartInfo().setCaseId(caseId);
        addDeviceUIRequest.setCartInfo(redisData.getDeviceCartInfo());
        if(addDeviceUIRequest.getCartInfo() != null && cartInfo != null && cartInfo.getPastdue() != null){
            addDeviceUIRequest.getCartInfo().setPastdue(cartInfo.getPastdue());
            addDeviceUIRequest.getCartInfo().setPastDueAccepted(cartInfo.getPastDueAccepted());
        }

        addDeviceData.setLines(redisData.getLines());
        addDeviceUIRequest.setData(addDeviceData);

        addDeviceUIRequest.setChannelId(channelId);
        return addDeviceUIRequest;
    }

    /**
     *
     * @param pegaRequest
     * @param request
     * @return resp
     */
    public static UpdateTransferUpgradePEGARequest formatAddTransferUpgradeRequest(
            UpdateTransferUpgradePEGARequest pegaRequest, UpdateTransferUpgradeUIRequest request) {
        CartServiceServiceHeader serviceHeader1 = new CartServiceServiceHeader();
        UpdateTransferUpgradeServiceBody serviceBody1 = new UpdateTransferUpgradeServiceBody();
        UpdateTransferUpgradeServiceRequest serviceRequest1 = new UpdateTransferUpgradeServiceRequest();
        UpdateTransferUpgradeContext context1 = new UpdateTransferUpgradeContext();
        CartServiceCustomerInfo customerInfo1 = new CartServiceCustomerInfo();
        CartServiceCartInfo cartInfo1 = new CartServiceCartInfo();
        settingCustomerAndCartInfo(serviceHeader1,pegaRequest
                , request,customerInfo1,cartInfo1,
                context1);
        cartInfo1.setAction(CartConstants.UPDATE);
        cartInfo1.setItemType(CartConstants.ALTERNATEUPGRADE);
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()))
            cartInfo1.setIntendType(request.getCartInfo().getIntendType());
        else
            cartInfo1.setIntendType(CartConstants.EUP);
        List<Line> lines = new ArrayList<>();
        for (Lines reqLine : request.getData().getLines()) {
            Line newLine = new Line();
            newLine.setMtn(reqLine.getMtn());
            newLine.setDonorMtn(reqLine.getDonorMtn());
            lines.add(newLine);
        }
        Line[] lineArr = new Line[lines.size()];
        lines.toArray(lineArr);

        cartInfo1.setLines(lineArr);

        context1.setCartInfo(cartInfo1);
        context1.setCaseId(request.getCartInfo().getCaseId());

        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.TRANSFER_UPGRADE,
                request.getCartInfo().getClientAppName());
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessStep()))
            contextInfo.setProcessStep(request.getCartInfo().getProcessStep());
        else
            contextInfo.setProcessStep(CartConstants.TRANSFER_UPGRADE);
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessAction()))
            contextInfo.setProcessAction(request.getCartInfo().getProcessAction());
        else
            contextInfo.setProcessAction(CartConstants.COMPLETE_TRANSFER);

        //MVP2-GR
        if(request.getCartInfo()!=null && request.getCartInfo().getCaseId()!=null && request.getCartInfo().getCaseId().startsWith("SOF")){

            logger.info("SalesOrderFlex Prepay add trasnfer upgrade Request before PEGA call setting Call Reason");
            contextInfo.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader1.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }

        context1.setContextInfo(contextInfo);

        serviceRequest1.setContext(context1);
        serviceBody1.setServiceRequest(serviceRequest1);
        pegaRequest.setServiceBody(serviceBody1);

        return pegaRequest;

    }

    /**
     *
     * @param pegaRequest
     * @param request
     * @return UpdateTransferUpgradePEGARequest
     */
    public static UpdateTransferUpgradePEGARequest formatRemoveTransferUpgradeRequest(
            UpdateTransferUpgradePEGARequest pegaRequest, UpdateTransferUpgradeUIRequest request) {
        CartServiceServiceHeader serviceHeader3 = new CartServiceServiceHeader();
        UpdateTransferUpgradeServiceBody serviceBody3 = new UpdateTransferUpgradeServiceBody();
        UpdateTransferUpgradeServiceRequest serviceRequest3 = new UpdateTransferUpgradeServiceRequest();
        UpdateTransferUpgradeContext context3 = new UpdateTransferUpgradeContext();
        CartServiceCustomerInfo customerInfo3 = new CartServiceCustomerInfo();
        CartServiceCartInfo cartInfo3 = new CartServiceCartInfo();
        settingCustomerAndCartInfo(serviceHeader3,pegaRequest
                , request,customerInfo3,cartInfo3,
                context3);
        cartInfo3.setAction(CartConstants.REMOVE);
        cartInfo3.setItemType(CartConstants.ALTERNATEUPGRADE);
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()))
            cartInfo3.setIntendType(request.getCartInfo().getIntendType());
        else
            cartInfo3.setIntendType(CartConstants.EUP);
        List<Line> lines = new ArrayList<>();
        for (Lines reqLine : request.getData().getLines()) {
            Line newLine = new Line();
            newLine.setMtn(reqLine.getMtn());
            lines.add(newLine);
        }
        Line[] lineArr = new Line[lines.size()];
        lines.toArray(lineArr);

        cartInfo3.setLines(lineArr);

        context3.setCartInfo(cartInfo3);
        context3.setCaseId(request.getCartInfo().getCaseId());

        CartServiceContextInfo contextInfo3 = new CartServiceContextInfo();
        CartPegaRequestUtil.addContextInfo(contextInfo3, CartConstants.TRANSFER_UPGRADE,
                request.getCartInfo().getClientAppName());
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessStep()))
            contextInfo3.setProcessStep(request.getCartInfo().getProcessStep());
        else
            contextInfo3.setProcessStep(CartConstants.MTN_SELECTION_PAGE);
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessAction()))
            contextInfo3.setProcessAction(request.getCartInfo().getProcessAction());
        else
            contextInfo3.setProcessAction(CartConstants.CANCEL_TRANSFER_UPGRADE);
        context3.setContextInfo(contextInfo3);

        //MVP2-GR
        if(request.getCartInfo()!=null && request.getCartInfo().getCaseId()!=null && request.getCartInfo().getCaseId().startsWith("SOF")){

            logger.info("SalesOrderFlex Prepay remove and  trasnfer upgrade Request before PEGA call setting Call Reason");
            contextInfo3.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader3.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }

        serviceRequest3.setContext(context3);
        serviceBody3.setServiceRequest(serviceRequest3);
        pegaRequest.setServiceBody(serviceBody3);

        return pegaRequest;
    }


    public static void settingCustomerAndCartInfo(CartServiceServiceHeader serviceHeader,UpdateTransferUpgradePEGARequest pegaRequest
            , UpdateTransferUpgradeUIRequest request,CartServiceCustomerInfo customerInfo,CartServiceCartInfo cartInfo,
                                                  UpdateTransferUpgradeContext context){

        CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(request.getChannelId());
        pegaRequest.setServiceHeader(serviceHeader);

        customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
        customerInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());
        context.setCustomerInfo(customerInfo);

        cartInfo.setCartId(request.getCartInfo().getCartId());
    }
    /**
     * @param pegaRequest
     * @param request
     * @return AddNickNamePEGARequest
     */
    public static AddNickNamePEGARequest formatAddNickNameRequest(AddNickNamePEGARequest pegaRequest,
                                                                  AddNickNameUIRequest request) {

        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(request.getChannelId());

        AddNickNameServiceBody serviceBody = new AddNickNameServiceBody();
        AddNickNameServiceRequest serviceRequest = new AddNickNameServiceRequest();
        AddNickNameContext context = new AddNickNameContext();

        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
        customerInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());
        if (CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())
                || CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
            CartPegaRequestUtil7.newCustomerOverride(contextInfo, customerInfo, request.getCartInfo(), request.getChannelId());
        }

        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(request.getCartInfo().getCartId());
        if (CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())
                || CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
            cartInfo.setItemType(CartConstants.USERCONTACTINFO);
        } else {

            cartInfo.setItemType(CartConstants.ORDER_INFORMATION);
        }
        cartInfo.setIntendType(request.getCartInfo().getIntendType());
        cartInfo.setAction(CartConstants.UPDATE);

        List<Line> lines = new ArrayList<>();
        CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.ADD_NICK_NAME,
                request.getCartInfo().getClientAppName());

        if (request.getData().getLines() != null) {
            for (AddNickNameLine reqLine : request.getData().getLines()) {
                Line newLine = new Line();
                newLine.setMtn(reqLine.getMtn());
                newLine.setNickName(reqLine.getNickName());

                lines.add(newLine);
            }
            Line[] lineArr = new Line[lines.size()];
            lines.toArray(lineArr);

            cartInfo.setLines(lineArr);
        }

        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessStep()))
            contextInfo.setProcessStep(request.getCartInfo().getProcessStep());

        context.setCaseId(request.getCartInfo().getCaseId());
        context.setCustomerInfo(customerInfo);
        context.setCartInfo(cartInfo);
        context.setContextInfo(contextInfo);

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);

        pegaRequest.setServiceHeader(serviceHeader);
        pegaRequest.setServiceBody(serviceBody);

        return pegaRequest;
    }

    /**
     *
     * @param removeLinesUIrequest
     * @return uiRequest
     */
    public static RemoveLinesUIRequest formatRemoveLinesUIRequest(RemoveLinesUIRequest removeLinesUIrequest) {

        removeLinesUIrequest.getCartInfo().setProcessAction(CartConstants.REMOVE_ITEM);
        removeLinesUIrequest.getCartInfo().setProcessStep(CartConstants.SHOPPING_CART);

        return removeLinesUIrequest;
    }

    /**
     * @param pegaRequest
     * @param request
     * @return UpdateChatIdPEGARequest
     */
    public static UpdateChatIdPEGARequest formatUpdateChatIdRequest(UpdateChatIdPEGARequest pegaRequest,
                                                                    UpdateChatIdUIRequest request) {

        CartServiceServiceHeader serviceHeader2 = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader2);
        serviceHeader2.setClientId(request.getChannelId());

        UpdateChatIdServiceBody serviceBody2 = new UpdateChatIdServiceBody();
        UpdateChatIdServiceRequest serviceRequest2 = new UpdateChatIdServiceRequest();

        UpdateChatIdContext context2 = new UpdateChatIdContext();

        CartServiceCustomerInfo customerInfo2 = new CartServiceCustomerInfo();
        customerInfo2.setAccountNumber(request.getCartInfo().getAccountNumber());
        customerInfo2.setCartCreator(request.getCartInfo().getCartCreator());
        customerInfo2.setProcessingMTN(request.getCartInfo().getProcessingMTN());

        CartServiceCartInfo cartInfo2 = new CartServiceCartInfo();
        cartInfo2.setCartId(request.getCartInfo().getCartId());
        cartInfo2.setItemType(CartConstants.CHAT_ID);
        cartInfo2.setAction(CartConstants.UPDATE);
        cartInfo2.setChatId(request.getChatId());
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()))
            cartInfo2.setIntendType(request.getCartInfo().getIntendType());
        else
            cartInfo2.setIntendType(CartConstants.EUP);

        CartServiceContextInfo contextInfo2 = new CartServiceContextInfo();
        contextInfo2.setCallReason(CartConstants.SALES_ORDER_PURCHASE);
        contextInfo2.setIntent(CartConstants.UPGRADE);
        contextInfo2.setProcessStep(CartConstants.SHOPPING_CART);
        contextInfo2.setProcessAction(CartConstants.ADD_CHAT_ID);
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                && ((CartConstants.NSE).equalsIgnoreCase(request.getCartInfo().getIntendType()))) {
            contextInfo2.setIntent(CartConstants.NSE);
        }

        if (CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())
                || CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())
                || CartConstants.NSE_5G.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
            CartPegaRequestUtil7.newCustomerOverride(contextInfo2, customerInfo2, request.getCartInfo(), request.getChannelId());
        }

        context2.setCaseId(request.getCartInfo().getCaseId());
        context2.setCustomerInfo(customerInfo2);
        context2.setCartInfo(cartInfo2);

        //MVP2-GR
        if(request.getCartInfo()!=null && request.getCartInfo().getCaseId()!=null && request.getCartInfo().getCaseId().startsWith("SOF")){
            logger.info("SalesOrderFlex Prepay update chat id Request before PEGA call setting Call Reason");
            contextInfo2.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader2.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }

        context2.setContextInfo(contextInfo2);
        serviceRequest2.setContext(context2);
        serviceBody2.setServiceRequest(serviceRequest2);

        pegaRequest.setServiceHeader(serviceHeader2);
        pegaRequest.setServiceBody(serviceBody2);

        return pegaRequest;
    }

    /**
     * @param pegaRequest
     * @param request
     * @return GetCaseRequest
     */
    public static GetCasePEGARequest formatGetCaseRequest(GetCasePEGARequest pegaRequest, GetCaseRequest request) {

        GetCaseServiceHeader serviceHeader = new GetCaseServiceHeader();
        serviceHeader.setClientId(request.getClientId());
        serviceHeader.setServiceName("GetCases");
        if(StringUtilities.isNotEmptyOrNull(request.getQuoteId()))
            serviceHeader.setServiceName("GetCasesByQuoteID");

        GetCaseServiceBody serviceBody = new GetCaseServiceBody();
        GetCaseServiceRequest serviceRequest = new GetCaseServiceRequest();

        GetCaseContext context = new GetCaseContext();

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(request.getAccountNumber());
        customerInfo.setCartCreator(request.getCartCreator());
        customerInfo.setQuoteId(request.getQuoteId());

        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        contextInfo.setCallReason(CartConstants.SALES_ORDER_PURCHASE);

        context.setCustomerInfo(customerInfo);
        context.setContextInfo(contextInfo);

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);

        pegaRequest.setServiceHeader(serviceHeader);
        pegaRequest.setServiceBody(serviceBody);

        return pegaRequest;
    }

    /**
     *
     * @param uiRequest1
     * @param pegaRequest
     * @return SaveCartPegaRequest
     */
    public static SaveCartPEGARequest formatSaveCartForLaterRequest(SaveCartPEGARequest pegaRequest,
                                                                    SaveCartForLaterUIRequest uiRequest1) {
        CartServiceServiceHeader serviceHeader1 = new CartServiceServiceHeader();
        CartServiceContextInfo contextInfo1 = new CartServiceContextInfo();
        serviceHeader1 = CartPegaRequestUtil.addServiceHeader(serviceHeader1);
        serviceHeader1.setClientId(uiRequest1.getChannelId());
        pegaRequest.setServiceHeader(serviceHeader1);

        SaveCartServiceBody serviceBody1 = new SaveCartServiceBody();
        SaveCartServiceRequest serviceRequest1 = new SaveCartServiceRequest();
        SaveCartContext context1 = new SaveCartContext();

        CartServiceCustomerInfo customerInfo1 = new CartServiceCustomerInfo();
        customerInfo1.setAccountNumber(uiRequest1.getCartInfo().getAccountNumber());
        customerInfo1.setCartCreator(uiRequest1.getCartInfo().getCartCreator());
        customerInfo1.setProcessingMTN(uiRequest1.getCartInfo().getProcessingMTN());

        if (StringUtilities.isNotEmptyOrNull(uiRequest1.getCartInfo().getProcessStep())
                && uiRequest1.getCartInfo().getProcessStep().equalsIgnoreCase(CartConstants.PROMO_HUB))
            customerInfo1.setCradleFlowJourney(CartConstants.PROMO_HUB);

        context1.setCustomerInfo(customerInfo1);

        CartServiceCartInfo cartInfo1 = new CartServiceCartInfo();
        cartInfo1.setCartId(uiRequest1.getCartInfo().getCartId());
        cartInfo1.setItemType(CartConstants.SAVE_CART.toUpperCase());

        if (StringUtilities.isNotEmptyOrNull(uiRequest1.getCartInfo().getItemType()))
            cartInfo1.setItemType(uiRequest1.getCartInfo().getItemType());

        if (StringUtilities.isNotEmptyOrNull(uiRequest1.getCartInfo().getGlobalId()))
            customerInfo1.setGlobalId(uiRequest1.getCartInfo().getGlobalId());

        if (StringUtilities.isNotEmptyOrNull(uiRequest1.getCartInfo().getProcessAction())
                && uiRequest1.getCartInfo().getProcessAction().equalsIgnoreCase(CartConstants.SAVE_FOR_LATER)) {
            cartInfo1.setAction("ADD");
            contextInfo1 = CartPegaRequestUtil.addContextInfo(contextInfo1, CartConstants.SAVE_FOR_LATER,
                    uiRequest1.getCartInfo().getClientAppName());
        } else if (StringUtilities.isNotEmptyOrNull(uiRequest1.getCartInfo().getProcessAction())
                && uiRequest1.getCartInfo().getProcessAction().equalsIgnoreCase(CartConstants.DELETE_SAVE_FOR_LATER)) {
            cartInfo1.setAction("DELETE");
            contextInfo1 = CartPegaRequestUtil.addContextInfo(contextInfo1, CartConstants.DELETE_SAVE_FOR_LATER,
                    uiRequest1.getCartInfo().getClientAppName());
        } else if (StringUtilities.isNotEmptyOrNull(uiRequest1.getCartInfo().getProcessAction())
                && uiRequest1.getCartInfo().getProcessAction().equalsIgnoreCase(CartConstants.REMOVE_SAVE_FOR_LATER)) {
            cartInfo1.setAction("REMOVE");
            contextInfo1 = CartPegaRequestUtil.addContextInfo(contextInfo1, CartConstants.REMOVE_SAVE_FOR_LATER,
                    uiRequest1.getCartInfo().getClientAppName());
        }
        if (StringUtilities.isNotEmptyOrNull(uiRequest1.getCartInfo().getIntendType()))
            cartInfo1.setIntendType(uiRequest1.getCartInfo().getIntendType());
        else
            cartInfo1.setIntendType(CartConstants.AAL);
        if (StringUtilities.isNotEmptyOrNull(uiRequest1.getCartInfo().getSaveCartEmailId()))
            cartInfo1.setSaveCartEmailId(uiRequest1.getCartInfo().getSaveCartEmailId());

        if (CollectionUtilities.isNotEmptyOrNull(uiRequest1.getData().getLines())) {
            List<Line> lines = new ArrayList<>();

            for (Lines reqLine : uiRequest1.getData().getLines()) {
                Line newLine = new Line();
                if (reqLine.getMtn() != null)
                    newLine.setMtn(reqLine.getMtn());
                lines.add(newLine);
            }
            Line[] lineArr = new Line[lines.size()];
            lines.toArray(lineArr);

            cartInfo1.setLines(lineArr);
        }
        context1.setCartInfo(cartInfo1);
        if (!StringUtilities.isEmptyOrNull(uiRequest1.getCartInfo().getProcessStep())) {
            contextInfo1.setProcessStep(uiRequest1.getCartInfo().getProcessStep());
        } else {
            contextInfo1.setProcessStep(CartConstants.PROMO_HUB);
        }
        //MVP2-GR
        if(uiRequest1.getCartInfo()!=null && uiRequest1.getCartInfo().getCaseId()!=null && uiRequest1.getCartInfo().getCaseId().startsWith("SOF")){
            logger.info("SalesOrderFlex Prepay save cart for later Request before PEGA call setting Call Reason");
            contextInfo1.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader1.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }
        context1.setContextInfo(contextInfo1);
        context1.setCaseId(uiRequest1.getCartInfo().getCaseId());
        context1.setCartInfo(cartInfo1);
        serviceRequest1.setContext(context1);
        serviceBody1.setServiceRequest(serviceRequest1);
        pegaRequest.setServiceBody(serviceBody1);
        return pegaRequest;
    }

    public static AddFeaturesUIRequest buildAddFeaturesOfferRequest(AddPlanUIRequest planRequest,
                                                                    MyOfferETRRedisData offerLines) {
        AddFeaturesUIRequest request = new AddFeaturesUIRequest();

        CartInfo cartInfo = new CartInfo();
        cartInfo.setClientAppName(planRequest.getCartInfo().getClientAppName());
        cartInfo.setCartId(planRequest.getCartInfo().getCartId());
        cartInfo.setCaseId(planRequest.getCartInfo().getCaseId());
        cartInfo.setAccountNumber(planRequest.getCartInfo().getAccountNumber());
        cartInfo.setProcessingMTN(planRequest.getCartInfo().getProcessingMTN());
        cartInfo.setCartCreator(planRequest.getCartInfo().getCartCreator());
        cartInfo.setIntendType(planRequest.getCartInfo().getIntendType());
        cartInfo.setProcessStep(CartConstants.FEATURES_PDP);
        request.setCartInfo(cartInfo);

        AddFeaturesData addFeaturesdata = new AddFeaturesData();
        List<LineFeature> lines = new ArrayList<LineFeature>();
        if(null != offerLines && CollectionUtilities.isNotEmptyOrNull(offerLines.getLines())) {
            offerLines.getLines().stream()
                    .filter(ofrLine -> (null != ofrLine && CollectionUtilities.isNotEmptyOrNull(ofrLine.getOffers())))
                    .forEach(offerLine -> {
                LineFeature line = new LineFeature();
                line.setMtn(planRequest.getMtn());
                FeatureAction featureAction = new FeatureAction();
                List<Feature> featureList = new ArrayList<Feature>();

                offerLine.getOffers().stream()
                        .filter(offer -> null != offer && StringUtilities.isNotEmptyOrNull(offer.getSku())
                        && StringUtilities.isNotEmptyOrNull(offer.getOfferCompliance()) && "SPO".equalsIgnoreCase(offer.getComplianceType())
                        && StringUtilities.isNotEmptyOrNull(offer.getAal()) && ("Y".equalsIgnoreCase(offer.getAal())))
                        .forEach(offerFeature -> {
                    Feature feature = new Feature();
                    feature.setId(offerFeature.getSku());
                    feature.setActionIndicator("A");
                    feature.setType(offerFeature.getComplianceType());
                    feature.setQuantity(1);
                    String mtn = "";
                    for(Lines planLine : planRequest.getData().getLines()){
                        if(StringUtilities.isNotEmptyOrNull(planLine.getMtn())){
                        mtn = planLine.getMtn();
                        break;}
                    }
                    if(StringUtilities.isNotEmptyOrNull(mtn)) {
                            List<Mtns> mtns = new ArrayList<Mtns>();
                            Mtns mtnObj = new Mtns();
                            mtnObj.setMtn(mtn);
                            mtns.add(mtnObj);
                            feature.setMtns(mtns);
                            line.setMtn(mtn);
                            featureList.add(feature);
                        }
                });
                if(CollectionUtilities.isNotEmptyOrNull(featureList)) {
                    featureAction.setAdd(featureList);
                    line.setFeatures(featureAction);
                    lines.add(line);
                }
            });
        }
        if(CollectionUtilities.isNotEmptyOrNull(lines)) {
            addFeaturesdata.setLines(lines.stream().toArray(LineFeature[]::new));
            request.setData(addFeaturesdata);
        }
        logger.info("Add Feature Request : {}", request);
        return request;
    }
}
