package onevz.soe.cart.bpm.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.validation.Valid;
import onevz.cxp.feature.ConfigurationProfile;
import onevz.cxp.feature.Flag;
import onevz.cxp.feature.util.FeatureFlag;
import onevz.soe.cart.bpm.service.CartServiceBPMServices;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.constants.FeatureFlagConstants;
import onevz.soe.cart.helper.FeatureFlagHelper;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.helper.RedisHelper2;
import onevz.soe.cart.model.addAccessory.AddAccContext;
import onevz.soe.cart.model.addAccessory.AddAccServiceBody;
import onevz.soe.cart.model.addAccessory.AddAccServiceRequest;
import onevz.soe.cart.model.addPromoIntent.AddPromoIntentPEGARequest;
import onevz.soe.cart.model.addPromoIntent.AddPromoIntentPEGAResponse;
import onevz.soe.cart.model.addPromoIntent.AddPromoIntentUIRequest;
import onevz.soe.cart.model.addPromoIntent.AddPromoIntentUIResponse;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.requests.*;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.cart.ui.responses.v2.FlagDetails;
import onevz.soe.cart.util.*;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.bind.DefaultValue;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;
import reactor.util.function.Tuple2;

import java.util.Optional;
import java.util.stream.Collectors;
import onevz.soe.wsclient.bpm.model.request.BPMServiceRequest;

import reactor.util.function.Tuple5;
import reactor.util.function.Tuple6;

@Service
public class CartServiceBpmHelper2 {

	private static final Logger logger = LoggerFactory.getLogger(CartServiceBpmHelper2.class);

	@Autowired
	private CartServiceBPMServices services;
	@Autowired
	private FeatureFlagHelper featureFlagHelper;

	@Autowired
	private RedisHelper redisHelper;

	@Autowired
	FeatureFlag featureFlag;

	@Autowired
	private RedisHelper2 redisHelper2;

	@Value("${planSku}")
	private boolean planSku;

	@Value("${enableSecurityForCart}")
	private boolean enableSecurityForCart;

	@Autowired
	SOELoginSessionBean soeLoginSessionBean;

	@Autowired
	ObjectMapper objectMapper;

	@Value("${onevz.soe.cart.acc.enableCradleFlowJourney:true}")
	public boolean enableCradleFlowJourney;

	@Value("${soe.cart.enableUpgradeSkipTradeFlow:true}")
	private boolean enableUpgradeSkipTradeFlow;

	/**
	 *
	 * @param uiRequest
	 * @return AddDeviceUIResponse
	 * 
	 */
	public Mono<AddDeviceUIResponse> addDevice(AddDeviceUIRequest uiRequest) {
		return addDevice(uiRequest, null);
	}

	/**
	 * 
	 * @param uiRequest
	 * @param throttleName
	 * @return uiResponse
	 * 
	 */
	public Mono<AddDeviceUIResponse> addDevice(AddDeviceUIRequest uiRequest, String throttleName) {

		AddDevicePEGARequest request = new AddDevicePEGARequest();

		logger.info("AddDevice UI Request After Session Call: {}", uiRequest);
		// convert uiRequest to pega request
		Mono<Flag> preToPostActFeeFFlagMono = featureFlag.getFeatureFlag(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
				FeatureFlagConstants.PRE_TO_POST_CFG_PROFILE_NAME, FeatureFlagConstants.FLAG_NAME_ACTIVATION_FEE_WAIVER_FFAG);
		Mono<Tuple6<String, Boolean,Boolean, Boolean, Flag, Boolean>> zippedMono = Mono.zip(redisHelper2.getLVSoftsku(), featureFlagHelper.isRouterFlagEnabled(),featureFlagHelper.isTradeInPromoCheckFflagEnabled(), featureFlagHelper.isSkipResumeCaseFFlagEnabled(), preToPostActFeeFFlagMono, featureFlagHelper.isFlexV2ValidationEnabled());
		return zippedMono.flatMap(updated-> {
			String LVsku=updated.getT1();
			Boolean westWorldRouterFlag= updated.getT2();
			Boolean isTradeInPromoCheckFlag = updated.getT3();
			Boolean skipResumeCaseFFlag = updated.getT4();
			Flag preToPostActivationFeeFFlag = updated.getT5();
			uiRequest.setFlexV2ValidationFLag(updated.getT6());
			Accessory accessory = new Accessory();

			if (StringUtilities.isNotEmptyOrNull(LVsku)) {
				accessory.setId(LVsku);
				accessory.setQty("1");
				accessory.setIsSoftSku(true);
				Accessory[] listAccessory = {accessory};

				if (null != uiRequest && null != uiRequest.getData() && null != uiRequest.getData().getLines()) {
					for (Lines reqLines : uiRequest.getData().getLines()) {
						if (null != reqLines.getDepletionType() && !reqLines.getDepletionType().equalsIgnoreCase(CartConstants.O)) {
									reqLines.setAddAccessories(listAccessory);
								}
							}
				}
						}

			if (null != uiRequest && null != uiRequest.getCartInfo()
					&& CartConstants.ACCOUNT_MEMBER_ROLES.contains(uiRequest.getCartInfo().getAmRole())) {
				boolean amNextGenEnabled = featureFlagHelper.getFeatureFlagWithAccNumThrottle(FeatureFlagConstants.APPLICATION_NAME_DIGITAL, FeatureFlagConstants.DIGITAL_UPG_CFG_PROFILE_NAME, FeatureFlagConstants.ENABLE_AM_NEXTGEN_FFLAG, uiRequest.getCartInfo().getAccountNumber(), uiRequest.getCartInfo().getCartCreator());
				uiRequest.getCartInfo().setAmNextGenEnabled(amNextGenEnabled);
			}

			CartPegaRequestUtil4.formatAddDeviceRequest(request, uiRequest, throttleName, westWorldRouterFlag, isTradeInPromoCheckFlag, skipResumeCaseFFlag, preToPostActivationFeeFFlag);

			if(CartUtil.isDigital(uiRequest.getChannelId()) && null!=uiRequest.getCartInfo() && null!=uiRequest.getData()
					&& StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getIntendType())
					&& validatePegaReq(request) && StringUtilities.isNotEmptyOrNull(uiRequest.getData().getByodMtn())){
				CartPegaRequestUtil4.addByodMtnToAddDevicePegaReq(uiRequest.getCartInfo().getIntendType(), request.getServiceBody().getServiceRequest().getContext().getCartInfo(), uiRequest.getData().getByodMtn(),
						featureFlagHelper.isDeviceFirstEnableForProspectBYODFFlag(), featureFlagHelper.isDeviceFirstEnableForExistingBYODFFlag());
			}

			logger.debug("AddDevice PEGA Request: {}", request);
			Mono<String> loggedInUser = redisHelper2.getLoggedInUser();
			return loggedInUser.flatMap(data -> {
				if (StringUtilities.isNotEmptyOrNull(data))
					request.getServiceHeader().setUserId(data);
				Mono<AddDevicePEGAResponse> responseServiceMono = null;
				try {
					// pega call
					if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getIntendType())
							&& ((CartConstants.REFUND_EXCHANGE).equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())
							|| (CartConstants.CONTRACT_CHANGE).equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())
							|| (CartConstants.EXCHANGE).equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())
							|| (CartConstants.EXCBYOD).equalsIgnoreCase(uiRequest.getCartInfo().getIntendType()))) {
						responseServiceMono = services.addDeviceRFEX(request);
					} else {
						responseServiceMono = services.addDevice(request);
					}

					responseServiceMono = services.addDevice(request);
				} catch (SOEHTTPException e) {
					logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
				}
				AddDeviceUIResponse soeResponse = new AddDeviceUIResponse();
				return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
					// convert pega response to ui response
					CartPegaResponseUtil.formatAddDeviceResponse(soeResponse, pegaResponse);
					return Mono.just(soeResponse);
				});
			});
		});
	}

	/**
	 * 
	 * @param uiRequest
	 * @param throttleName
	 * @return AddAccessoriesUIResponse
	 * 
	 */
	public Mono<AddAccessoriesUIResponse> addAccessory(AddAccessoriesUIRequest uiRequest,
			@DefaultValue("") String throttleName) {

		logger.debug("Inside CartServiceBpmHelper --> addAccessory");
		AddAccessoryPEGARequest request = new AddAccessoryPEGARequest();

		// convert ui request to pega request
		CartPegaRequestUtil3.formatAddAccessoriesRequest(request, uiRequest, throttleName, enableCradleFlowJourney);
		removeFwaCradleFlowJourneyValue(request);

		logger.debug("AddAccessories PEGA Request: {}", request);
		Mono<AddAccessoriesPEGAResponse> responseServiceMono = null;

		try {
			// pega call
			if(StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getIntendType()) &&
			   uiRequest.getCartInfo().getIntendType().equalsIgnoreCase(CartConstants.REFUND_EXCHANGE))
				 responseServiceMono = services.addAccessoryRFEX(request);
			else
				 responseServiceMono = services.addAccessory(request);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		AddAccessoriesUIResponse soeResponse = new AddAccessoriesUIResponse();
		return responseServiceMono == null ? Mono.just(new AddAccessoriesUIResponse())
				: responseServiceMono.flatMap(pegaResponse -> {

					// convert pega response to ui response
					CartPegaResponseUtil.formatAddAccessoriesResponse(soeResponse, pegaResponse);
					return Mono.just(soeResponse);
				});
	}

	// fix CXTDT-473719: removing cradleFlowJourney for FWA flow
	private void removeFwaCradleFlowJourneyValue(AddAccessoryPEGARequest request) {
		if (soeLoginSessionBean.isFWADigitalFlow()){
			Optional.ofNullable(request).map(AddAccessoryPEGARequest::getServiceBody)
							.map(AddAccServiceBody::getServiceRequest)
									.map(AddAccServiceRequest::getContext)
											.map(AddAccContext::getCustomerInfo).ifPresent(customerInfo -> {
												customerInfo.setCradleFlowJourney("");
											});
		}
	}

	/**
	 * 
	 * @param request
	 * @return RemoveLinesUIResponse
	 * 
	 */
	public Mono<RemoveLinesUIResponse> removeLines(RemoveLinesUIRequest request) {
           logger.debug("Inside CartServiceBpmHelper --> removeLines");
           RemoveLinesPEGARequest pegaRequest = new RemoveLinesPEGARequest();

           // convert ui request to pega request
           pegaRequest = CartPegaRequestUtil2.formatRemoveLinesRequest(pegaRequest, request);
           Mono<RemoveLinesPEGAResponse> responseServiceMono = null;
           logger.info(String.format("RemoveLines intendType: %s " , request.getCartInfo().getIntendType()));
           try {
               // pega call
               responseServiceMono = services.removeLines(pegaRequest);
           } catch (SOEHTTPException e) {
               logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
           }
           RemoveLinesUIResponse soeResponse = new RemoveLinesUIResponse();
           return responseServiceMono == null ? Mono.just(new RemoveLinesUIResponse())
                   : responseServiceMono.flatMap(pegaResponse -> {

               // convert pega response to ui response
               CartPegaResponseUtil.formatRemoveLinesResponse(soeResponse, pegaResponse);
               return Mono.just(soeResponse);
           });
	}


	/**
	 * 
	 * @param uiRequest
	 * @return PastDuesUIResponse
	 */
	public Mono<PastDuesUIResponse> pastDues(PastDuesUIRequest uiRequest) {
		logger.debug("Inside CartServiceBpmHelper --> PastDues");

		PastDuesPEGARequest pegaRequest = new PastDuesPEGARequest();

		// convert ui request to pega request
		CartPegaRequestUtil2.formatPastDuesRequest(pegaRequest, uiRequest);
		logger.debug("PastDues PEGA Request: {}", pegaRequest);
		Mono<PastDuesPEGAResponse> pastDuesResponse = null;

		try {
			// pega call
			pastDuesResponse = services.pastDues(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}

		PastDuesUIResponse soeResponse = new PastDuesUIResponse();
		return pastDuesResponse == null ? Mono.just(new PastDuesUIResponse())
				: pastDuesResponse.flatMap(pegaResponse -> {
					CartPegaResponseUtil.formatPastDuesResponse(soeResponse, pegaResponse);
					return Mono.just(soeResponse);
				});
	}

	/**
	 * 
	 * @param uiRequest
	 * @return AddFeaturesPEGAResponse
	 */
	/**
	 *
	 * @param uiRequest
	 * @return AddFeaturesPEGAResponse
	 */
	public Mono<AddFeaturesUIResponse> addFeatures(AddFeaturesUIRequest uiRequest) {
		logger.debug("Inside CartServiceBpmHelper --> addRemoveFeature");
		Mono<Boolean> isFIveGFlows = redisHelper.isDigitalHomeFlow();
		Mono<Flag> featureFlagMono1 = featureFlag.getFeatureFlag(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
				FeatureFlagConstants.PRE_TO_POST_CFG_PROFILE_NAME, FeatureFlagConstants.FLAG_NAME_ACTIVATION_FEE_WAIVER_FFAG);

		return Mono.zip(isFIveGFlows, featureFlagMono1).flatMap(tuple2 -> {
			Boolean isFIveGFlow = tuple2.getT1();
			Flag preToPostActivationFeeFFlag= tuple2.getT2();
			// convert ui request to pega request for add-feature
			AddFeaturesPEGARequest pegaRequest = new AddFeaturesPEGARequest();
			pegaRequest = CartPegaRequestUtil3.formatAddFeaturesRequest(pegaRequest, uiRequest, preToPostActivationFeeFFlag);
			if (isFIveGFlow) {
				// set intent as AAL_5G only for homeProtect in 5g flow
				if(null != uiRequest.getData() && null != uiRequest.getData().getAccount()
						&& null != uiRequest.getData().getAccount().getFeatures()
						&& (null != uiRequest.getData().getAccount().getFeatures().getAdd())
						&& uiRequest.getData().getAccount().getFeatures().getAdd().size() >0 ) {
					if("SPO".equalsIgnoreCase(uiRequest.getData().getAccount().getFeatures().getAdd().get(0).getType())) {
						pegaRequest.getServiceBody().getServiceRequest().getContext().getContextInfo()
								.setIntent(uiRequest.getCartInfo().getIntendType());
					}
				} else if(null != uiRequest.getData() && null != uiRequest.getData().getAccount()
						&& null != uiRequest.getData().getAccount().getFeatures()
						&& (null != uiRequest.getData().getAccount().getFeatures().getRemove() )
						&& uiRequest.getData().getAccount().getFeatures().getRemove().size() >0 ) {
					if("SPO".equalsIgnoreCase(uiRequest.getData().getAccount().getFeatures().getRemove().get(0).getType())) {
						pegaRequest.getServiceBody().getServiceRequest().getContext().getContextInfo()
								.setIntent(uiRequest.getCartInfo().getIntendType());
					}
				}
				else if(null != uiRequest.getCartInfo() && StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getIntendType())
						&& null != uiRequest.getData().getLines() && null != uiRequest.getData().getLines()[0].getFeatures()) {
					if (null != uiRequest.getData().getLines()[0].getFeatures().getAdd()
							&& null != uiRequest.getData().getLines()[0].getFeatures().getAdd().get(0).getType()
							&& "SPO".equalsIgnoreCase(uiRequest.getData().getLines()[0].getFeatures().getAdd().get(0).getType())) {
						pegaRequest.getServiceBody().getServiceRequest().getContext().getContextInfo()
						.setIntent(uiRequest.getCartInfo().getIntendType());
					} else if (null != uiRequest.getData().getLines()[0].getFeatures().getRemove()
							&& null != uiRequest.getData().getLines()[0].getFeatures().getRemove().get(0).getType()
							&& "SPO".equalsIgnoreCase(uiRequest.getData().getLines()[0].getFeatures().getRemove().get(0).getType())) {
						pegaRequest.getServiceBody().getServiceRequest().getContext().getContextInfo()
								.setIntent(uiRequest.getCartInfo().getIntendType());
					}
				}
			}

			//for digital refund exchange changes
			if(CartConstants.REX.equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())){
				pegaRequest.getServiceHeader().setServiceName("SalesOrderAdjustment");
				pegaRequest.getServiceBody().getServiceRequest().getContext().getContextInfo().setCallReason("SalesOrderAdjustment");
				pegaRequest.getServiceBody().getServiceRequest().getContext().getContextInfo().setIntent(CartConstants.REX);
			}

			logger.debug("AddFeatures PEGA Request : {}", null != pegaRequest ? pegaRequest.toString() : null);
			Mono<AddFeaturesPEGAResponse> responseServiceMono = null;
			try {
				// pega call
				if(StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getClientAppName()) && CartConstants.CHANNEL_ID_NUMBERLINK.equalsIgnoreCase(uiRequest.getCartInfo().getClientAppName())) {
					responseServiceMono = services.numberLinkAddFeatures(pegaRequest);
				}else if(uiRequest.getCartInfo() != null && StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getLineActivityType())
						   && uiRequest.getCartInfo().getLineActivityType().equalsIgnoreCase("TSE")){
					responseServiceMono= services.addFeaturesTYS(pegaRequest);
				}else if(CartPegaRequestUtil3.isFeatureOrSPOUpdateOnly(uiRequest)){
					responseServiceMono= services.cpcAddFeature(pegaRequest);
				}
				else {
					responseServiceMono= services.addFeatures(pegaRequest);
				}
			} catch (SOEHTTPException e) {
				logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
			}
			AddFeaturesUIResponse soeResponse = new AddFeaturesUIResponse();
			return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
				CartPegaResponseUtil.formatAddFeaturesResponse(soeResponse, pegaResponse);
				return Mono.just(soeResponse);
			});
		});
	}

	/**
	 * 
	 * @param request
	 * @return InitiateCheckoutUIResponse
	 */
	public Mono<InitiateCheckoutUIResponse> validateOrder(InitiateCheckoutUIRequest request) {
		return redisHelper.isDigitalHomeFlow().flatMap(isDigitalHomeFlow -> {
			Mono<InitiateCheckoutPEGAResponse> responseServiceMono = null;
			InitiateCheckoutPEGARequest pegaRequest = new InitiateCheckoutPEGARequest();
			// convert ui request to pega request
			pegaRequest = CartPegaRequestUtil2.formatInitiateCheckoutRequest(pegaRequest, request);
			if(isDigitalHomeFlow) {
				pegaRequest.getServiceBody().getServiceRequest().getContext().getContextInfo().setProcessAction("ValidateOrder");
				if(!"cBand_Technician".equalsIgnoreCase(pegaRequest.getServiceBody().getServiceRequest().getContext().getContextInfo().getTransactionType()))
					pegaRequest.getServiceBody().getServiceRequest().getContext().getContextInfo().setIntent(request.getCartInfo().getIntendType());

			}
			if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntent())
					&& ((CartConstants.WHW_INTENT).equalsIgnoreCase(request.getCartInfo().getIntent()))) {
				pegaRequest.getServiceBody().getServiceRequest().getContext().getContextInfo().setIntent(request.getCartInfo().getIntent());

			}
			logger.debug("InitiateCheckout PEGA Request: {}", pegaRequest);
			try {
				// pega call
				if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
				&& ((CartConstants.REFUND_EXCHANGE).equalsIgnoreCase(request.getCartInfo().getIntendType()))) {
					responseServiceMono = services.validateOrderRFEX(pegaRequest);
				} else {
					responseServiceMono = services.validateOrder(pegaRequest);
				}
				
			} catch (SOEHTTPException e) {
				logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
			}
			
			InitiateCheckoutUIResponse soeResponse = new InitiateCheckoutUIResponse();
			return responseServiceMono == null ? Mono.just(new InitiateCheckoutUIResponse())
					: responseServiceMono.flatMap(pegaResponse -> {
				CartPegaResponseUtil.formatInitiateCheckoutResponse(soeResponse, pegaResponse);
				String channelType = CartUtil.getChannelType(request.getChannelId());
				if (request != null && request.getCartInfo() != null
						&& request.getCartInfo().getIntendType() != null
						&& (CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())
						|| CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())
						|| CartConstants.NSEACC.equalsIgnoreCase(request.getCartInfo().getIntendType()))
						&& StringUtils.isNotEmpty(channelType)
						&& CartConstants.CHANNEL_DIGITAL.equalsIgnoreCase(channelType) && soeResponse != null
						&& soeResponse.getServiceBody() != null
						&& soeResponse.getServiceBody().getServiceResponse() != null
						&& soeResponse.getServiceHeader() != null
						&& soeResponse.getServiceBody().getServiceResponse().getContext() != null) {
					soeResponse.getServiceHeader().setClientId(null);
					soeResponse.getServiceBody().getServiceResponse().getContext().setCaseId(null);
					soeResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setCartId(null);
					if(soeResponse.getServiceBody().getServiceResponse().getContext().getValidateOrder() != null) {
						Boolean readyForCheckout = soeResponse.getServiceBody().getServiceResponse().getContext()
							.getValidateOrder().getReadyForOrderSubmit();
						if (readyForCheckout != null && readyForCheckout) {
							redisHelper2
									.upsertValueInRedis(CartConstants.VALIDATE_ORDER_KEY, readyForCheckout.toString())
									.subscribeOn(Schedulers.parallel()).subscribe(upserted -> {
								logger.debug("readyForCheckout data upserted in Redis {}", upserted);
							});
						}
					}

					
				}
				removeSensitiveDataForCheckOutCart(soeResponse, channelType);
				return Mono.just(soeResponse);
			});
		});
	}

	public void removeSensitiveDataForCheckOutCart(InitiateCheckoutUIResponse resp, String channelType) {
		if (resp != null
				&& resp.getServiceBody() != null
				&& resp.getServiceBody().getServiceResponse() != null
				&& resp.getServiceBody().getServiceResponse().getContext() != null
				&& resp.getServiceBody().getServiceResponse().getContext().getCaseId() != null
				&& resp.getServiceBody().getServiceResponse().getContext().getCartInfo() != null
				&& resp.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartId() != null
				&& StringUtilities.isNotEmptyOrNull(channelType)
				&& CartConstants.CHANNEL_ASSISTED.equalsIgnoreCase(channelType)) {

			resp.getServiceBody().getServiceResponse().getContext().setCaseId(CartConstants.EMPTY_STRING);
			resp.getServiceBody().getServiceResponse().getContext().getCartInfo().setCartId(CartConstants.EMPTY_STRING);

		}
	}
	/**
	 * 
	 * @param uiRequest
	 * @return AddBuyoutUIResponse s
	 */
	public Mono<AddBuyoutUIResponse> addBuyout(AddBuyoutUIRequest uiRequest) {
		logger.debug("Inside CartServiceBpmHelper --> addBuyout");
		AddBuyoutPEGARequest pegaRequest = new AddBuyoutPEGARequest();

		// convert ui request to pega request
		pegaRequest = CartPegaRequestUtil2.formatAddBuyoutRequest(pegaRequest, uiRequest);

		logger.debug("AddBuyout PEGA Request: {}", pegaRequest);
		if(pegaRequest.getServiceBody()!=null && pegaRequest.getServiceBody().getServiceRequest()!=null &&
		pegaRequest.getServiceBody().getServiceRequest().getContext()!=null &&
		pegaRequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo()!=null) {
			logger.info(String.format("CradleFlowJourney in pega request : %s " , pegaRequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCradleFlowJourney()));
		}
		Mono<AddBuyoutPEGAResponse> responseServiceMono = null;

		try {
			// pega call
			responseServiceMono = services.addBuyout(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		AddBuyoutUIResponse soeResponse = new AddBuyoutUIResponse();
		return responseServiceMono == null ? Mono.just(new AddBuyoutUIResponse())
				: responseServiceMono.flatMap(pegaResponse -> {

					CartPegaResponseUtil.formatAddBuyoutResponse(soeResponse, pegaResponse);
					return Mono.just(soeResponse);
				});
	}

	/**
	 * 
	 * @param uiRequest
	 * @return UpdateEdgeupUIResponse
	 * 
	 */
	public Mono<UpdateEdgeupUIResponse> addEdgeup(UpdateEdgeupUIRequest uiRequest) {
		logger.debug("Inside CartServiceBpmHelper --> addEdgeup");
		UpdateEdgeupPEGARequest pegaRequest = new UpdateEdgeupPEGARequest();

		// convert ui request to pega request
		pegaRequest = CartPegaRequestUtil9.formatUpdateEdgeupRequest(pegaRequest, uiRequest);

		logger.debug("UpdateEdgeup PEGA Request: {}", pegaRequest);
		Mono<UpdateEdgeupPEGAResponse> responseServiceMono = null;

		try {
			// pega call
			responseServiceMono = services.addEdgeUp(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		UpdateEdgeupUIResponse soeResponse = new UpdateEdgeupUIResponse();
		return responseServiceMono == null ? Mono.just(new UpdateEdgeupUIResponse())
				: responseServiceMono.flatMap(pegaResponse -> {

					CartPegaResponseUtil.formatUpdateEdgeUpResponse(soeResponse, pegaResponse);
					return Mono.just(soeResponse);
				});
	}

	/**
	 * 
	 * @param uiRequest
	 * @return UpdateEdgeupUIResponse
	 * 
	 */
	public Mono<UpdateEdgeupUIResponse> removeEdgeUp(UpdateEdgeupUIRequest uiRequest) {
		logger.debug("Inside CartServiceBpmHelper --> removeEdgeup");
		UpdateEdgeupPEGARequest pegaRequest = new UpdateEdgeupPEGARequest();

		// convert ui request to pega request
		pegaRequest = CartPegaRequestUtil2.formatRemoveEdgeUpRequest(pegaRequest, uiRequest);

		logger.debug("UpdateEdgeup PEGA Request: {}", pegaRequest);
		Mono<UpdateEdgeupPEGAResponse> responseServiceMono = null;

		try {
			// pega call
			responseServiceMono = services.removeEdgeUp(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		UpdateEdgeupUIResponse soeResponse = new UpdateEdgeupUIResponse();
		return responseServiceMono == null ? Mono.just(new UpdateEdgeupUIResponse())
				: responseServiceMono.flatMap(pegaResponse -> {

					CartPegaResponseUtil.formatUpdateEdgeUpResponse(soeResponse, pegaResponse);
					return Mono.just(soeResponse);
				});
	}

	/**
	 *
	 * @param request
	 * @return AddDownPaymentUIResponse @
	 */
	public Mono<AddDownPaymentUIResponse> addDownPayment(DownPaymentUIRequest request) {

		logger.debug("Inside CartServiceBpmHelper --> addDownPayment");
		AddDownPaymentPEGARequest pegaRequest = new AddDownPaymentPEGARequest();

		// convert ui request to pega request
		CartPegaRequestUtil2.formatAddDownPaymentRequest(pegaRequest, request);
		logger.debug("AddDownPayment PEGA Request: {}", pegaRequest);
		Mono<AddDownPaymentPEGAResponse> addDownPaymentResponse = null;
		try {
			// pega call
			addDownPaymentResponse = services.addDownPayment(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		AddDownPaymentUIResponse soeResponse = new AddDownPaymentUIResponse();
		return addDownPaymentResponse == null ? Mono.just(new AddDownPaymentUIResponse())
				: addDownPaymentResponse.flatMap(pegaResponse -> {

					CartPegaResponseUtil.formatAddDownPaymentResponse(soeResponse, pegaResponse);
					return Mono.just(soeResponse);
				});

	}

	/**
	 *
	 * @param request
	 * @return CreateLineUIResponse @
	 */
	public Mono<CreateLineUIResponse> createLine(CreateLineUIRequest request) {

		logger.debug("Inside CartServiceBpmHelper --> CreateLine");
		CreateLinePEGARequest pegaRequest = new CreateLinePEGARequest();

		// convert ui request to pega request
		CartPegaRequestUtil3.formatCreateLineRequest(pegaRequest, request);

		if(CartUtil.isDigital(request.getChannelId()) && null!=request.getCartInfo()
				&& StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
				&& validatePegaReq(pegaRequest) && CollectionUtilities.isNotEmptyOrNull(request.getData().getByodLineDetails())){
			CartPegaRequestUtil3.addByodLineDetailsToPegaReq(request.getCartInfo().getIntendType(), pegaRequest.getServiceBody().getServiceRequest().getContext().getCartInfo(), request.getData().getByodLineDetails(),
					featureFlagHelper.isDeviceFirstEnableForProspectBYODFFlag(), featureFlagHelper.isDeviceFirstEnableForExistingBYODFFlag());
		}
		logger.debug("CreateLine PEGA Request: {}", pegaRequest);
		Mono<CreateLinePEGAResponse> createLineResponse = null;
		try {
			// pega call
			createLineResponse = services.createLine(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		CreateLineUIResponse soeResponse = new CreateLineUIResponse();
		return createLineResponse == null ? Mono.just(new CreateLineUIResponse())
				: createLineResponse.flatMap(pegaResponse -> {

					CartPegaResponseUtil.formatCreateLineResponse(soeResponse, pegaResponse);
					return Mono.just(soeResponse);
				});

	}
	
	/**
	 *
	 * @param request
	 * @return NumberShareUIResponse @
	 */
	public Mono<NumberShareUIResponse> numberShare(NumberShareUIRequest request) {

		logger.debug("Inside CartServiceBpmHelper --> NumberShare");
		NumberSharePEGARequest pegaRequest = new NumberSharePEGARequest();

		// convert ui request to pega request
		CartPegaRequestUtil3.formatNumberShareRequest(pegaRequest, request);
		logger.debug("NumberShare PEGA Request: {}", pegaRequest);
		Mono<NumberSharePEGAResponse> numberShareResponse = null;
		try {
			// pega call
			numberShareResponse = services.numberShare(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		NumberShareUIResponse soeResponse = new NumberShareUIResponse();
		return numberShareResponse == null ? Mono.just(new NumberShareUIResponse())
				: numberShareResponse.flatMap(pegaResponse -> {

					CartPegaResponseUtil.formatNumberShareResponse(soeResponse, pegaResponse);
					return Mono.just(soeResponse);
				});

	}

	/**
	 *
	 * @param request
	 * @return ServiceAddressUIResponse @
	 */
	public Mono<ServiceAddressUIResponse> addServiceAddress(ServiceAddressUIRequest request) {

		logger.debug("Inside CartServiceBpmHelper --> serviceAddress");
		ServiceAddressPEGARequest pegaRequest = new ServiceAddressPEGARequest();

		// convert ui request to pega request
		CartPegaRequestUtil3.formatServiceAddressRequest(pegaRequest, request);
		logger.debug("serviceAddress PEGA Request: {}", pegaRequest);
		Mono<ServiceAddressPEGAResponse> serviceAddressResponse = null;
		try {
			// pega call
			serviceAddressResponse = services.addServiceAddress(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		ServiceAddressUIResponse soeResponse = new ServiceAddressUIResponse();
		return serviceAddressResponse == null ? Mono.just(new ServiceAddressUIResponse())
				: serviceAddressResponse.flatMap(pegaResponse -> {

					CartPegaResponseUtil.formatServiceAddressResponse(soeResponse, pegaResponse);
					return Mono.just(soeResponse);
				});
	}

	/**
	 *
	 * @param request
	 * @return BillingAddressUIResponse @
	 */
	public Mono<BillingAddressUIResponse> addBillingAddress(BillingAddressUIRequest request) {

		logger.debug("Inside CartServiceBpmHelper --> serviceAddress");
		BillingAddressPEGARequest pegaRequest = new BillingAddressPEGARequest();

		// convert ui request to pega request
		CartPegaRequestUtil4.formatBillingAddressRequest(pegaRequest, request);
		logger.debug("serviceAddress PEGA Request: {}", pegaRequest);
		Mono<BillingAddressPEGAResponse> billingAddressResponse = null;
		try {
			// pega call
			billingAddressResponse = services.addBillingAddress(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		BillingAddressUIResponse soeResponse = new BillingAddressUIResponse();
		return billingAddressResponse == null ? Mono.just(new BillingAddressUIResponse())
				: billingAddressResponse.flatMap(pegaResponse -> {

					CartPegaResponseUtil.formatBillingAddressResponse(soeResponse, pegaResponse);
					return Mono.just(soeResponse);
				});
	}

	/**
	 *
	 * @param request
	 * @return E911AddressUIResponse @
	 */
	public Mono<E911AddressUIResponse> addE911Address(E911AddressUIRequest request) {

		logger.debug("Inside CartServiceBpmHelper --> E911Address");
		E911AddressPEGARequest pegaRequest = new E911AddressPEGARequest();

		// convert ui request to pega request
		CartPegaRequestUtil4.formatE911AddressRequest(pegaRequest, request);
		logger.debug("E911Address PEGA Request: {}", pegaRequest);
		Mono<E911AddressPEGAResponse> e911AddressResponse = null;
		try {
			// pega call
			if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getClientAppName()) && CartConstants.CHANNEL_ID_NUMBERLINK.equalsIgnoreCase(request.getCartInfo().getClientAppName())) {
				e911AddressResponse = services.numberLinkAddE911Address(pegaRequest);
			}else {
				e911AddressResponse= services.addE911Address(pegaRequest);
			}
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		E911AddressUIResponse soeResponse = new E911AddressUIResponse();
		return e911AddressResponse == null ? Mono.just(new E911AddressUIResponse())
				: e911AddressResponse.flatMap(pegaResponse -> {

					CartPegaResponseUtil.formatE911AddressResponse(soeResponse, pegaResponse);
					return Mono.just(soeResponse);
				});
	}

	/**
	 *
	 * @param request
	 * @return EffectiveDateOverrideUIResponse @
	 */
	public Mono<EffectiveDateOverrideUIResponse> effectiveDateOverride(EffectiveDateOverrideUIRequest request) {

		logger.debug("Inside CartServiceBpmHelper --> EffectiveDateOverride");
		EffectiveDateOverridePEGARequest pegaRequest = new EffectiveDateOverridePEGARequest();

		// convert ui request to pega request
		CartPegaRequestUtil3.formatEffectiveDateOverrideRequest(request, pegaRequest);
		logger.debug("EffectiveDateOverride PEGA Request: {}", pegaRequest);
		Mono<EffectiveDateOverridePEGAResponse> effectiveDateOverrideResponse = null;
		try {
			// pega call
			effectiveDateOverrideResponse = services.effectiveDateOverride(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		EffectiveDateOverrideUIResponse soeResponse = new EffectiveDateOverrideUIResponse();
		return effectiveDateOverrideResponse == null ? Mono.just(new EffectiveDateOverrideUIResponse())
				: effectiveDateOverrideResponse.flatMap(pegaResponse -> {

					CartPegaResponseUtil.formatEffectiveDateOverrideResponse(pegaResponse, soeResponse);
					return Mono.just(soeResponse);
				});
	}

	/**
	 *
	 * @param request
	 * @return InstantCreditDownPaymentUIResponse @
	 */
	public Mono<InstantCreditDownPaymentUIResponse> addInstantCreditDownPayment(
			InstantCreditDownPaymentUIRequest request) {

		logger.debug("Inside CartServiceBpmHelper --> InstantCreditDownPayment");
		InstantCreditDownPaymentPEGARequest pegaRequest = new InstantCreditDownPaymentPEGARequest();

		// convert ui request to pega request
		CartPegaRequestUtil4.formatInstantCreditDownPaymenRequest(pegaRequest, request);
		logger.debug("InstantCreditDownPayment PEGA Request: {}", pegaRequest);
		Mono<InstantCreditDownPaymentPEGAResponse> instantCreditDownPaymentResponse = null;
		try {
			// pega call
			instantCreditDownPaymentResponse = services.addInstantCreditDownPayment(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		InstantCreditDownPaymentUIResponse soeResponse = new InstantCreditDownPaymentUIResponse();
		return instantCreditDownPaymentResponse == null ? Mono.just(new InstantCreditDownPaymentUIResponse())
				: instantCreditDownPaymentResponse.flatMap(pegaResponse -> {

					CartPegaResponseUtil.formatInstantCreditDownPaymentResponse(soeResponse, pegaResponse);
					return Mono.just(soeResponse);
				});
	}

	/**
	 * 
	 * @param uiRequest
	 * @return AssignMtnUIResponse @
	 */
	public Mono<AssignMtnUIResponse> assignMtn(AssignMtnUIRequest uiRequest) {

		AssignMtnPEGARequest request = new AssignMtnPEGARequest();

		// convert uiRequest to pega request
		CartPegaRequestUtil5.formatAssignMtnRequest(uiRequest, request);
		mergeFeatureFlagWithResponse(Mono.zip(Mono.just(request),featureFlagHelper.fetchDigitalPerformanceCfgProfile()));
		logger.debug("AssignMtn PEGA Request: {}", request);
		return featureFlagHelper.fetchDigitalPegaPredictivePrefetchFFlag().flatMap(featureFlag-> {
			if (featureFlag) {
				request.getServiceBody().getServiceRequest().getContext().getContextInfo().setPredictivePrefetchEnabled(uiRequest.isPredictivePrefetchEnabled() ? CartConstants.ON : CartConstants.OFF);
			}
			Mono<AssignMtnPEGAResponse> responseServiceMono = null;
			try {
				// pega call
				responseServiceMono = services.assignMtn(request);
			} catch (SOEHTTPException e) {
				logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
			}
			AssignMtnUIResponse soeResponse = new AssignMtnUIResponse();
			return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
				// convert pega response to ui response
				CartPegaResponseUtil.formatAssignMtnResponse(pegaResponse, soeResponse, uiRequest);
				return Mono.just(soeResponse);
			});
		});
	}

	private Mono<AssignMtnPEGARequest> mergeFeatureFlagWithResponse(Mono<Tuple2<AssignMtnPEGARequest, ConfigurationProfile>> zip) {
		return zip.flatMap(tuples -> {
			var assignMtnPEGARequest = tuples.getT1();
			Optional.ofNullable(tuples.getT2())
					.map(ConfigurationProfile::getFlags)
					.ifPresent(listOfFeatureFlags -> {
						var mapOfFeatureFlags = listOfFeatureFlags
								.stream()
								.collect(Collectors.toMap(Flag::getName, flag -> featureFlagHelper.mapValueToFlagDetails().apply(flag),(oldEntry, newEntry) -> newEntry));
						if(mapOfFeatureFlags.containsKey("pegaPredictivePrefetchFFlag")){
							FlagDetails flag=mapOfFeatureFlags.get("pegaPredictivePrefetchFFlag");
							if(flag.isEnabled()){
								assignMtnPEGARequest.getServiceBody().getServiceRequest().getContext().getContextInfo().setPredictivePrefetchEnabled(CartConstants.ON);
							}else{
								assignMtnPEGARequest.getServiceBody().getServiceRequest().getContext().getContextInfo().setPredictivePrefetchEnabled(CartConstants.OFF);
							}
						}
					});
			return Mono.just(assignMtnPEGARequest);
		});
	}

	/**
	 * 
	 * @param uiRequest
	 * @return DeassignMtnUIResponse @
	 */
	public Mono<DeassignMtnUIResponse> deassignMtn(DeassignMtnUIRequest uiRequest) {

		DeassignMtnPEGARequest request = new DeassignMtnPEGARequest();

		// convert uiRequest to pega request
		CartPegaRequestUtil5.formatDeassignMtnRequest(uiRequest, request);
		logger.debug("DeassignMtn PEGA Request: {}", request);
		Mono<DeassignMtnPEGAResponse> responseServiceMono = null;
		try {
			// pega call
			responseServiceMono = services.deassignMtn(request);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		DeassignMtnUIResponse soeResponse = new DeassignMtnUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
			// convert pega response to ui response
			CartPegaResponseUtil.formatDeassignMtnResponse(pegaResponse, soeResponse);
			return Mono.just(soeResponse);
		});
	}

	/**
	 * 
	 * @param uiRequest
	 * @return SaveCartUIResponse
	 * @throws JsonProcessingException
	 */
	public Mono<SaveCartUIResponse> saveCart(SaveCartUIRequest uiRequest) {

		SaveCartPEGARequest request = new SaveCartPEGARequest();

		// convert uiRequest to pega request
		CartPegaRequestUtil.formatSaveCartRequest(request, uiRequest);
		logger.debug("SaveCart PEGA Request: {}", request);
		Mono<SaveCartPEGAResponse> responseServiceMono = null;
		try {
			// pega call
			if(StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getIntendType()) &&
				uiRequest.getCartInfo().getIntendType().equalsIgnoreCase(CartConstants.REFUND_EXCHANGE))
				responseServiceMono = services.saveCartRFEX(request);
			else
				responseServiceMono = services.saveCart(request);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		SaveCartUIResponse soeResponse = new SaveCartUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
			// convert pega response to ui response
			CartPegaResponseUtil.formatSaveCartResponse(soeResponse, pegaResponse);
			if(CartUtil.isDigital(uiRequest.getChannelId()) && enableSecurityForCart) {
				removeSensitiveInfoForSaveCartUI(soeResponse);
			}
			return Mono.just(soeResponse);
		});
	}

	/**
	 * 
	 * @param uiRequest
	 * @return AddDeviceUIResponse @
	 */
	public Mono<Add5GBulkOrderUIResponse> add5GBulkOrder(Add5GBulkOrderUIRequest uiRequest) {

		Add5GBulkOrderPEGARequest request = new Add5GBulkOrderPEGARequest();

		// convert uiRequest to pega request
		CartPegaRequestUtil5.formatAdd5GBulkOrderRequest(request, uiRequest);
		logger.debug("AddDevice PEGA Request: {}", request);
		Mono<Add5GBulkOrderPEGAResponse> responseServiceMono = null;
		try {
			// pega call
			responseServiceMono = services.add5GBulkOrder(request);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		Add5GBulkOrderUIResponse soeResponse = new Add5GBulkOrderUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
			// convert pega response to ui response
			CartPegaResponseUtil.formatAdd5GBulkOrderResponse(soeResponse, pegaResponse);
			return Mono.just(soeResponse);
		});
	}

	/**
	 * 
	 * @param uiRequest
	 * @return RevokeRebatesUIResponse @
	 */
	public Mono<RevokeRebatesUIResponse> revokeRebates(RevokeRebatesUIRequest uiRequest) {

		RevokeRebatesPEGARequest request = new RevokeRebatesPEGARequest();

		// convert uiRequest to pega request
		CartPegaRequestUtil5.formatRevokeRebatesRequest(request, uiRequest);
		logger.debug("RevokeRebates PEGA Request: {}", request);
		Mono<RevokeRebatesPEGAResponse> responseServiceMono = null;
		try {
			// pega call
			responseServiceMono = services.revokeRebates(request);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		RevokeRebatesUIResponse soeResponse = new RevokeRebatesUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
			// convert pega response to ui response
			CartPegaResponseUtil.formatRevokeRebatesResponse(soeResponse, pegaResponse);
			return Mono.just(soeResponse);
		});
	}

	/**
	 * 
	 * @param uiRequest
	 * @return PortinLaterUIResponse @
	 */
	public Mono<PortinLaterUIResponse> updatePortInLater(PortinLaterUIRequest uiRequest) {

		PortinLaterPEGARequest request = new PortinLaterPEGARequest();

		// convert uiRequest to pega request
		CartPegaRequestUtil5.formatUpdatePortInLaterRequest(request, uiRequest);
		logger.debug("UpdatePortInLater PEGA Request: {}", request);

		Mono<PortinLaterPEGAResponse> responseServiceMono = null;
		try {
			// pega call
			responseServiceMono = services.updatePortInLater(request);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		PortinLaterUIResponse soeResponse = new PortinLaterUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
			// convert pega response to ui response
			CartPegaResponseUtil.formatUpdatePortInLaterResponse(soeResponse, pegaResponse);
			return Mono.just(soeResponse);
		});
	}

	/**
	 * 
	 * @param uiRequest
	 * @return VoidOrderUIResponse @
	 */
	public Mono<VoidOrderUIResponse> voidOrder(VoidOrderUIRequest uiRequest) {

		VoidOrderPEGARequest request = new VoidOrderPEGARequest();

		// convert uiRequest to pega request
		CartPegaRequestUtil5.formatVoidOrderRequest(uiRequest, request);
		logger.debug("voidOrder PEGA Request: {}", request);
		Mono<VoidOrderPEGAResponse> responseServiceMono = null;
		try {
			// pega call
			responseServiceMono = services.voidOrder(request);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		VoidOrderUIResponse soeResponse = new VoidOrderUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
			// convert pega response to ui response
			CartPegaResponseUtil.formatVoidOrderResponse(pegaResponse, soeResponse);
			return Mono.just(soeResponse);
		});
	}

	/**
	 * 
	 * @param uiRequest
	 * @return IspuToDfillUIResponse @
	 */
	public Mono<IspuToDfillUIResponse> ispuToDfill(IspuToDfillUIRequest uiRequest) {

		IspuToDfillPEGARequest request = new IspuToDfillPEGARequest();

		// convert uiRequest to pega request
		CartPegaRequestUtil5.formatIspuToDfillRequest(uiRequest, request);
		logger.debug("ispuToDfill PEGA Request: {}", request);
		Mono<IspuToDfillPEGAResponse> responseServiceMono = null;
		try {
			// pega call
			responseServiceMono = services.ispuToDfill(request);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		IspuToDfillUIResponse soeResponse = new IspuToDfillUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
			// convert pega response to ui response
			CartPegaResponseUtil.formatIspuToDfillResponse(pegaResponse, soeResponse);
			return Mono.just(soeResponse);
		});
	}
	
	/**
	 *
	 * @param resp
	 */
	public static void removeSensitiveInfoForSaveCartUI(SaveCartUIResponse resp) {
		if (null != resp && resp.getServiceBody() != null
				&& resp.getServiceBody().getServiceResponse() != null
				&& resp.getServiceBody().getServiceResponse().getContext() != null) {
			resp.getServiceBody().getServiceResponse().getContext().setCaseId(null);
		}
		if (null != resp && resp.getServiceBody() != null && resp.getServiceBody().getServiceResponse().getContext().getCartInfo() != null)
			resp.getServiceBody().getServiceResponse().getContext().getCartInfo().setCartId(null);
	}

	/**
	 *
	 * @param uiRequest
	 * @return DeassignMtnUIResponse @
	 */
	public Mono<AddPromoIntentUIResponse> addPromoIntent(AddPromoIntentUIRequest uiRequest) {

		AddPromoIntentPEGARequest request = new AddPromoIntentPEGARequest();

		// convert uiRequest to pega request
		CartPegaRequestUtil5.formatAddPromoIntentRequest(uiRequest, request,enableUpgradeSkipTradeFlow);
		return featureFlagHelper.fetchDigitalPegaPredictivePrefetchFFlag().flatMap(featureFlag-> {
			if (featureFlag) {
				request.getServiceBody().getServiceRequest().getContext().getContextInfo().setPredictivePrefetchEnabled(uiRequest.isPredictivePrefetchEnabled() ? CartConstants.ON : CartConstants.OFF);
			}
			logger.debug("addPromoIntent PEGA Request: {}", request);
			Mono<AddPromoIntentPEGAResponse> responseServiceMono = null;
			try {
				// pega call
				responseServiceMono = services.addPromoIntent(request);
			} catch (SOEHTTPException e) {
				logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
			}

			AddPromoIntentUIResponse soeResponse = new AddPromoIntentUIResponse();
			return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
				// convert pega response to ui response
				CartPegaResponseUtil.formatAddPromoIntentResponse(pegaResponse, soeResponse);
				return Mono.just(soeResponse);
			});
		});
	}

	public Mono<AddDeviceUIResponse> addUpgradeDetails(AddDeviceUIRequest uiRequest) {
		AddDevicePEGARequest request = new AddDevicePEGARequest();
		logger.info("AddDevice UI Request After Session Call: {}", uiRequest);
		Mono<String> sku = redisHelper2.getLVSoftsku();
		Mono<Boolean> bauUpgradePdpTradeInFFlagMono = featureFlagHelper.isBauUpgPdpTradeinFFlagEnabled();

		if (null != uiRequest && null != uiRequest.getCartInfo()
				&& CartConstants.ACCOUNT_MEMBER_ROLES.contains(uiRequest.getCartInfo().getAmRole())) {
			boolean amNextGenEnabled = featureFlagHelper.getFeatureFlagWithAccNumThrottle(FeatureFlagConstants.APPLICATION_NAME_DIGITAL, FeatureFlagConstants.DIGITAL_UPG_CFG_PROFILE_NAME, FeatureFlagConstants.ENABLE_AM_NEXTGEN_FFLAG, uiRequest.getCartInfo().getAccountNumber(), uiRequest.getCartInfo().getCartCreator());
			uiRequest.getCartInfo().setAmNextGenEnabled(amNextGenEnabled);
		}

		return Mono.zip(sku,bauUpgradePdpTradeInFFlagMono).flatMap(tuple2 -> {
			String LVsku = tuple2.getT1();
			Boolean bauUpgradePdpTradeInFFlag = tuple2.getT2();
			Boolean trade3POChoiceFlag = featureFlagHelper.trade3POChoiceOfferFFlag();
			CartPegaRequestUtil9.formatAddUpgradeDetailsRequest(request, uiRequest, trade3POChoiceFlag, bauUpgradePdpTradeInFFlag);
			logger.debug("AddDevice PEGA Request: {}", request);
			Mono<String> loggedInUser = redisHelper2.getLoggedInUser();
			return loggedInUser.flatMap(data -> {
				if (StringUtilities.isNotEmptyOrNull(data)) {
					request.getServiceHeader().setUserId(data);
				}
				Mono<AddDevicePEGAResponse> responseServiceMono = null;
				try {
					responseServiceMono = services.addUpgradeDetails(request);
				} catch (SOEHTTPException e) {
					logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
				}
				AddDeviceUIResponse soeResponse = new AddDeviceUIResponse();
				return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
					// convert pega response to ui response
					CartPegaResponseUtil.formatAddUpgradeDetailsResponse(soeResponse, pegaResponse);
					return Mono.just(soeResponse);
				});
			});
		});
	}

	public Mono<AddDeviceUIResponse> callPegaDfoToDppCart(@Valid AddDeviceUIRequest uiRequest) throws SOEHTTPException {

		AddDevicePEGARequest pegaRequest = new AddDevicePEGARequest();
		logger.info("dfoToDppCart UI Request After Session Call: {}", uiRequest);
		// convert uiRequest to pega request
		CartPegaRequestUtil4.formatDfoToDppCartRequest(pegaRequest, uiRequest);
		logger.debug("dfoToDppCart PEGA Request: {}", pegaRequest);
		Mono<AddDevicePEGAResponse> responseServiceMono = null;
		responseServiceMono = services.dfoToDppCartPegaService(pegaRequest);

		AddDeviceUIResponse uiResponse = new AddDeviceUIResponse();

		return responseServiceMono == null ? Mono.just(uiResponse) : responseServiceMono.flatMap(pegaResponse -> {
			// convert pega response to ui response
			CartPegaResponseUtil.formatAddDeviceResponse(uiResponse, pegaResponse);
			return Mono.just(uiResponse);
		});

	}
	public boolean validatePegaReq(BPMServiceRequest pegaRequest){
		return null!=pegaRequest.getServiceBody() && null!=pegaRequest.getServiceBody().getServiceRequest() && null!=pegaRequest.getServiceBody().getServiceRequest().getContext() && null!=pegaRequest.getServiceBody().getServiceRequest().getContext().getCartInfo();
	}
}
