package onevz.soe.cart.util;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.gql.schema.bundlebuildercartlightweight.OrderDetailsLW;
import onevz.soe.cart.model.bundleBuilderCart.*;
import onevz.soe.cart.responses.BundleBuilderCXPResponseData;
import onevz.soe.orderprocess.translator.model.*;
import org.apache.commons.collections4.CollectionUtils;
import onevz.soe.orderprocess.translator.*;

import java.util.*;


public class BundleBuilderDetailsTranslator {

    public static final String CART_ITEM_CODE_DEVICE = "DEVICE";

    public static BundleBuilderResponse translateBundleBuilderDetails(BundleBuilderCXPResponseData cxpResp) {
        BundleBuilderResponse bundleBuilderResponse=  new BundleBuilderDetailsTranslator().getBundleBuilderResponse(cxpResp);
        return bundleBuilderResponse;
    }

    private BundleBuilderResponse getBundleBuilderResponse(BundleBuilderCXPResponseData cxpResp) {
        BundleBuilderResponse response = new BundleBuilderResponse();
        BundleBuilderCXPCartDataVO cxpData = cxpResp.getData();
        DataLW data = new DataLW();
        if(cxpData != null){
            if(cxpData.getPromoBundleBuilderCart()!= null){
                data.setCart(getBundleBuilderCart(cxpData.getPromoBundleBuilderCart()));
            }
            response.setData(data);
        }
        return response;
    }

    private onevz.soe.orderprocess.translator.model.CartLW getBundleBuilderCart(BundleBuilderCXPCartVO cxpCart) {
        onevz.soe.orderprocess.translator.model.CartLW cart = new onevz.soe.orderprocess.translator.model.CartLW();
        cart.setCartHeader(getCartHeaderLW(cxpCart.getCartHeader()));
        cart.setLineDetails(getLineDetailsLW(cxpCart.getLineDetails()));
        if(null != cxpCart.getOrderDetails()) {
        	cart.setOrderDetails(getOrderDetailsLW(cxpCart.getOrderDetails()));
        }
        return cart;
    }
    
    private onevz.soe.orderprocess.translator.model.OrderDetailsLW getOrderDetailsLW(OrderDetailsLW orderDetails) {
    	onevz.soe.orderprocess.translator.model.OrderDetailsLW orderDetailsLW = new onevz.soe.orderprocess.translator.model.OrderDetailsLW();
    	orderDetailsLW.setFlowType(orderDetails.getFlowType());
    	return orderDetailsLW;
    }
    
    private onevz.soe.orderprocess.translator.model.CartHeaderLW getCartHeaderLW(BundleBuilderCartHeader cxpCartHeader) {
        onevz.soe.orderprocess.translator.model.CartHeaderLW cartHeaderLW = new onevz.soe.orderprocess.translator.model.CartHeaderLW();
        cartHeaderLW.setCartId(cxpCartHeader.getCartId());
        cartHeaderLW.setCartCreator(cxpCartHeader.getCartCreator());
        cartHeaderLW.setCartCreatorChannelId(cxpCartHeader.getCartCreatorChannelId());
        cartHeaderLW.setCartCreatorSalesRepId(cxpCartHeader.getCartCreatorSalesRepId());
        cartHeaderLW.setPreConfiguredCartType(cxpCartHeader.getPreConfiguredCartType());
        cartHeaderLW.setFullAccountNumber(cxpCartHeader.getFullAccountNumber());
        cartHeaderLW.setSourceSystem(cxpCartHeader.getSourceSystem());
        cartHeaderLW.setVendorId(cxpCartHeader.getVendorId());
        cartHeaderLW.setVisionCustomerType(cxpCartHeader.getVisionCustomerType());
        cartHeaderLW.setPreConfiguredCartTypeDuringAddDevice(cxpCartHeader.getPreConfiguredCartTypeDuringAddDevice());
        cartHeaderLW.setCaseId(cxpCartHeader.getCaseId());
        return cartHeaderLW;
    }

    private onevz.soe.orderprocess.translator.model.LineDetailsLW getLineDetailsLW(BundleBuilderCXPLineDetailsVO cxpLineDetails) {
        onevz.soe.orderprocess.translator.model.LineDetailsLW lineDetailsLW = new onevz.soe.orderprocess.translator.model.LineDetailsLW();
        if (cxpLineDetails != null) {
            lineDetailsLW.setNumOfLines(cxpLineDetails.getNumOfLines());
            lineDetailsLW.setNumofLinesAAL(cxpLineDetails.getNumofLinesAAL());
            lineDetailsLW.setNumofLinesEUP(cxpLineDetails.getNumofLinesEUP());
            activateLines(lineDetailsLW, Arrays.asList(cxpLineDetails.getLineInfo()));
            lineDetailsLW.setAllLines(getAllLines(Arrays.asList(cxpLineDetails.getLineInfo())));
            lineDetailsLW.setLineInfo(getLineinfoLW(Arrays.asList(cxpLineDetails.getLineInfo())));
            lineDetailsLW.setTradeInDetail(cxpLineDetails.getTradeInDetail());
        }
        return lineDetailsLW;
    }

    private List<String> getAllLines(List<BundleBuilderCXPLineInfo> lineInfo) {
        List<String> list = new ArrayList<>();
        if(lineInfo != null && !lineInfo.isEmpty()){
            for(BundleBuilderCXPLineInfo cLineInfo : lineInfo){
                if (!(CartConstants.ACC.equalsIgnoreCase(cLineInfo.getLineActivityType())
                        || CartConstants.FEA.equalsIgnoreCase(cLineInfo.getLineActivityType())
                        || CartConstants.CPC.equalsIgnoreCase(cLineInfo.getLineActivityType()))
                        && cLineInfo.getItemsInfo() != null && cLineInfo.getItemsInfo().length > 0) {
                    list.add(cLineInfo.getMobileNumber());
                }
            }
        }
        return list;
    }

    private void activateLines(onevz.soe.orderprocess.translator.model.LineDetailsLW lineDetails, List<BundleBuilderCXPLineInfo> lineInfo) {
        List<Object> eupLines = new ArrayList<>();
        List<String> aalLines = new ArrayList<>();
        List<String> nseLines = new ArrayList<>();
        if(null != lineInfo){
            for(BundleBuilderCXPLineInfo cartLineInfo : lineInfo) {
                if (cartLineInfo.getItemsInfo() != null && cartLineInfo.getItemsInfo().length > 0) {
                    switch (cartLineInfo.getLineActivityType()) {
                        case CartConstants.EUP:
                            eupLines.add(cartLineInfo.getMobileNumber());
                            lineDetails.setEupLines(eupLines);
                            break;
                        case CartConstants.AAL:
                            aalLines.add(cartLineInfo.getMobileNumber());
                            lineDetails.setAalLines(aalLines);
                            break;
                        case CartConstants.NSE:
                            nseLines.add(cartLineInfo.getMobileNumber());
                            lineDetails.setNseLines(nseLines);
                            break;
                        default:
                            break;
                    }
                }
            }
        }

    }

    private Map<String, NewLineLW>  getLineinfoLW(List<BundleBuilderCXPLineInfo> cxpLineInfos) {
        Map<String, NewLineLW> line1List = new HashMap<String, NewLineLW>();
        if (CollectionUtils.isNotEmpty(cxpLineInfos)) {
            cxpLineInfos.forEach(cxpLineInfo->{
                if(!(CartConstants.ACC.equalsIgnoreCase(cxpLineInfo.getLineActivityType())
                        || CartConstants.FEA.equalsIgnoreCase(cxpLineInfo.getLineActivityType())
                        || CartConstants.CPC.equalsIgnoreCase(cxpLineInfo.getLineActivityType()))
                        && cxpLineInfo.getItemsInfo() != null && cxpLineInfo.getItemsInfo().length > 0) {
                    NewLineLW lineLW = new NewLineLW();
                    lineLW.setMultiLineSeqNumber(cxpLineInfo.getMultiLineSeqNumber());
                    lineLW.setLineActivityType(cxpLineInfo.getLineActivityType());
                    lineLW.setMobileNumber(cxpLineInfo.getMobileNumber());
                    lineLW.setServiceInfo(getServiceinfoLW(cxpLineInfo.getServiceInfo()));
                    setItemsInfoLW(lineLW, Arrays.asList(cxpLineInfo.getItemsInfo()));
                    lineLW.setMtnDetails(getMtnDetailsLW(cxpLineInfo.getMtnDetails()));
                    lineLW.setInstallmentInfo(cxpLineInfo.getInstallmentInfo());
                    lineLW.setLineNumber(cxpLineInfo.getLineNumber());
                    lineLW.setIsCartVisitedItem(cxpLineInfo.getIsCartVisitedItem());
                    lineLW.setPromoType(cxpLineInfo.getPromoType());
                    lineLW.setPromotionID(cxpLineInfo.getPromotionID());
                    lineLW.setTradeInIntentSelected(cxpLineInfo.isTradeInIntentSelected());
                    lineLW.setNbxSessionId(cxpLineInfo.getNbxSessionId());
                    line1List.put(cxpLineInfo.getMobileNumber(), lineLW);
                }
            });
        }
        return line1List;
    }

    private onevz.soe.orderprocess.model.checkoutdetails.MtnDetails getMtnDetailsLW(onevz.soe.cart.model.retrieveCart.MtnDetails cxpMtnDetails) {
        onevz.soe.orderprocess.model.checkoutdetails.MtnDetails mtnDetails = new onevz.soe.orderprocess.model.checkoutdetails.MtnDetails();
        if (cxpMtnDetails != null) {
            mtnDetails.setMobileNumber(cxpMtnDetails.getMobileNumber());
            mtnDetails.setLineNumber(cxpMtnDetails.getLineNumber());
            mtnDetails.setDummyMTNForDomain(cxpMtnDetails.getDummyMTNForDomain());
        }
        return mtnDetails;
    }

    private ServiceInfoLW getServiceinfoLW(BundleBuilderServiceInfo cxpServiceInfo) {
        ServiceInfoLW serviceInfoLW = new ServiceInfoLW();
        if (cxpServiceInfo != null) {
            serviceInfoLW.setMtn(cxpServiceInfo.getMtn());
            serviceInfoLW.setSbdOffer(cxpServiceInfo.getSbdOffer());
        }
        return serviceInfoLW;
    }

    private void setItemsInfoLW(NewLineLW lineLW, List<BundleBuilderCXPItemInfo> cxpItemsInfos) {
        if (cxpItemsInfos != null) {
            cxpItemsInfos.forEach(cxpItemsInfo -> {
                BundleBuilderCXPCartItemsVO cartItems = cxpItemsInfo.getCartItems();
                if(cartItems == null) return;
                BundleBuilderCXPCartItem[] cartItemList = cartItems.getCartItem();
                if (cartItemList != null) {
                    for (BundleBuilderCXPCartItem cartItem : cartItemList) {
                        switch (cartItem.getCartItemType()) {
                            case CART_ITEM_CODE_DEVICE:
                                lineLW.setDeviceItem(cartItem);
                                break;
                            default:
                                break;
                        }
                    }
                }
            });
        }
    }

}