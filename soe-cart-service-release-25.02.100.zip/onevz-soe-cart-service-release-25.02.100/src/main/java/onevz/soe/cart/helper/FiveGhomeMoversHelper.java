package onevz.soe.cart.helper;


import onevz.soe.cart.bpm.helper.CartServiceBpmHelper;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper3;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.cxp.helper.FiveGHomeCartCxpHelper;
import onevz.soe.cart.model.addAccessory.AccessoryAction;
import onevz.soe.cart.model.addDevice.*;
import onevz.soe.cart.model.common.Accessory;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.common.CartServiceServiceHeader;
import onevz.soe.cart.model.common.FiveG.MoversInfo;
import onevz.soe.cart.model.common.FiveG.*;
import onevz.soe.cart.model.common.Plan;
import onevz.soe.cart.model.retrieveCart.*;
import onevz.soe.cart.model.retrieveCart.fiveG.CXPOrderDetailsView;
import onevz.soe.cart.model.retrieveCart.fiveG.FiveGMoversServiceInfo;
import onevz.soe.cart.requests.*;
import onevz.soe.cart.responses.AddPlanAndDevicePEGAResponse;
import onevz.soe.cart.responses.FiveGHomeMoversUIResponse;
import onevz.soe.cart.responses.RetrieveCartCXPResponse;
import onevz.soe.cart.ui.requests.AddPlanAndDeviceUIRequest;
import onevz.soe.cart.ui.responses.AddMoveDatesUIResponse;
import onevz.soe.cart.ui.responses.MoversUpdatePlanResponse;
import onevz.soe.cart.util.CartPegaRequestUtil7;
import onevz.soe.cart.util.CartUtil;
import onevz.soe.cart.util.CommonUtil;
import onevz.soe.orderprocess.request.ScheduleAppointmentRequest;
import onevz.soe.session.constants.SessionConstants;
import onevz.soe.utilities.StringUtilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpCookie;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import reactor.core.publisher.Mono;
import onevz.soe.cart.model.common.Propositions;
import onevz.soe.cart.model.common.FeatureMessages;

import jakarta.validation.Valid;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.stream.Collectors;

import static onevz.soe.cart.constants.CartConstants.*;


@Service
public class FiveGhomeMoversHelper {

    @Autowired
    FiveGHomeCartCxpHelper cxpHelper;
    @Autowired
    CommonUtil commonUtil;
    @Autowired
    private RedisHelper2 redisHelper2;
    @Autowired
    private RedisHelper3 redisHelper3;
    @Autowired
    private CartServiceBpmHelper3 bpmHelper3;

    @Autowired
    private CartServiceBpmHelper bpmHelper;

    @Autowired
    private EncryptDecryptHelper encryptDecryptHelper;

    @Autowired
    FeatureFlagHelper featureFlagHelper;

    @Autowired
    private FiveGhomeCommonHelper fiveGhomeCommonHelper;
    @Value("${soe.5g.whw.promoId:20996}")
    private String whwPromoId;


    private static final Logger logger = LoggerFactory.getLogger(FiveGhomeMoversHelper.class);

    public Mono<FiveGHomeMoversUIResponse> getMoversCart(String cartId, MoversRedisData redisData, GetCartDetailsRequest requestData, ServerHttpRequest httpRequest) {
        if (StringUtilities.isEmptyOrNull(cartId)) {
            FiveGHomeMoversUIResponse response = new FiveGHomeMoversUIResponse();
            List<CartError> errors = new ArrayList<>();
            CartError error = new CartError();
            error.setMessage("CartId is Empty.");
            errors.add(error);
            response.setErrors(errors);
        }
        @Valid RetrieveCartCXPRequest request = new RetrieveCartCXPRequest();
        CXPRetrieveCartDataVO data = new CXPRetrieveCartDataVO();
        data.setCartId(cartId);
        request.setData(data);
        return cxpHelper.retrieve5GMoversCart(request).flatMap(retrieveCartCXPResponse -> {
            return formatCxpResponseToUIResponse(retrieveCartCXPResponse, redisData, requestData, httpRequest);
        });

    }

    private Mono<FiveGHomeMoversUIResponse> formatCxpResponseToUIResponse(RetrieveCartCXPResponse retrieveCartCXPResponse, MoversRedisData redisData, GetCartDetailsRequest requestData, ServerHttpRequest httpRequest) {
        FiveGHomeMoversUIResponse response = new FiveGHomeMoversUIResponse();
        if (null != retrieveCartCXPResponse.getErrors()) {
            response.setErrors(Arrays.asList(retrieveCartCXPResponse.getErrors()));
            return Mono.just(response);
        }
        FiveGMoversServiceInfo moversServiceInfo = new FiveGMoversServiceInfo();
        Optional.ofNullable(retrieveCartCXPResponse).map(RetrieveCartCXPResponse::getData).map(CXPRetrieveCartDataVO::getCart)
                .map(CXPCartVO::getLineDetails).map(CXPLineDetailsVO::getLineInfo).filter(Objects::nonNull).ifPresent(cxpLineInfos -> {
                    Arrays.stream(cxpLineInfos).filter(Objects::nonNull).findFirst().map(CXPLineInfo::getServiceInfo).ifPresent(serviceInfo -> {
                        moversServiceInfo.setCart5GAddress(serviceInfo.getCart5GAddress());
                        processServiceInfoAndUpdateDates(serviceInfo, moversServiceInfo);
                        processServiceInfoAndUpdateDisplayName(serviceInfo, moversServiceInfo);
                        processServiceInfoAndUpdateImageUrl(serviceInfo, moversServiceInfo);
                        moversServiceInfo.setImportantAccountChanges(serviceInfo.getFeatureMessages());
                        moversServiceInfo.setOldPlanId(serviceInfo.getOldPricePlanId());
                        moversServiceInfo.setNewPlanId(serviceInfo.getNewPricePlanId());
                        processServiceInfoAndUpdateCustomerName(serviceInfo, moversServiceInfo);
                    });
                    Arrays.stream(cxpLineInfos).filter(Objects::nonNull).findFirst().ifPresent(lineInfo -> {
                        processLineInfoAndUpdateInstallationType(lineInfo, moversServiceInfo);
                        processLineInfoAndUpdatePropositions(lineInfo, moversServiceInfo, redisData.getCrsp());
                    });
                });
        Optional.ofNullable(retrieveCartCXPResponse).map(RetrieveCartCXPResponse::getData).map(CXPRetrieveCartDataVO::getCart)
                .map(CXPCartVO::getOrderDetails).filter(Objects::nonNull).filter(cxpOrderDetails -> null != cxpOrderDetails.getOrderList()).ifPresent(cxpOrderDetails -> {
                    cxpOrderDetails.getOrderList().stream().filter(Objects::nonNull).findFirst().ifPresent(orderList -> {
                        CXPOrderDetailsView orderDetailsView = new CXPOrderDetailsView();
                        orderDetailsView.setOrderType(cxpOrderDetails.getOrderType());
                        orderDetailsView.setOrderNumber(String.valueOf(orderList.getOrderNumber()));
                        orderDetailsView.setLocationCode(cxpOrderDetails.getLocationCode());
                        moversServiceInfo.setOrderDetailsView(orderDetailsView);
                    });
                });
        processRedisDataAndUpdateDiscountPrice(redisData, moversServiceInfo);
        if (StringUtilities.isEmptyOrNull(moversServiceInfo.getPlanName())) {
            Map<String, String> moversFWALinesInfo = redisData.getMoversFWALinesInfo();
            String lineInfo = null != moversFWALinesInfo ? moversFWALinesInfo.get(redisData.getMoversMtn()) : "";
            String[] lineArr = StringUtilities.isNotEmptyOrNull(lineInfo) ? lineInfo.split(",") : new String[0];
            moversServiceInfo.setPlanName(lineArr.length > 0 ? lineArr[0] : "");
        }
        getUnifiedNbsDataAndUpdateResponse(redisData, requestData, httpRequest, moversServiceInfo);
        response.setMoveServiceInfo(moversServiceInfo);
        if (StringUtilities.isEmptyOrNull((redisData.getSafeTechSessionId()))) {
            return fiveGhomeCommonHelper.upsertFwaSafeTechSessionId(redisData.getSafeTechSessionId()).flatMap(data -> {
                response.getMoveServiceInfo().getOrderDetailsView().setSafeTechSessionId(data);
                return Mono.just(response);
            });
        } else {
            response.getMoveServiceInfo().getOrderDetailsView().setSafeTechSessionId(redisData.getSafeTechSessionId());
        }

        return Mono.just(response);

    }

    private void getUnifiedNbsDataAndUpdateResponse(MoversRedisData redisData, GetCartDetailsRequest requestData, ServerHttpRequest httpRequest, FiveGMoversServiceInfo moversServiceInfo) {
        if (featureFlagHelper.isMoversUnifiedNBSEnabled() && requestData != null && requestData.getData() != null && requestData.getData().isFetchUnifiedNbsData()) {
            String channelId = Optional.ofNullable(httpRequest.getHeaders()).map(httpHeaders -> httpHeaders.getFirst(CartConstants.CHANNEL_ID)).orElse("");
            String igSessionKey = CartUtil.isDigital(channelId) ? CartConstants.DIGITAL_IG_SESSION : CartConstants.ASSISTED_IG_SESSION_ID;
            String igSession = null != httpRequest.getCookies().getFirst(igSessionKey) ? Objects.requireNonNullElse(httpRequest.getCookies().getFirst(igSessionKey), new HttpCookie(igSessionKey, "")).getValue() : "";
            moversServiceInfo.setUnifiedNbsData(encryptDecryptHelper.getUnifiedNbsMoversData(igSession, redisData));
        }
    }

    private void processRedisDataAndUpdateDiscountPrice(MoversRedisData redisData, FiveGMoversServiceInfo moversServiceInfo) {
        String planId = moversServiceInfo.getNewPlanId();
        Optional.ofNullable(redisData)
                .map(MoversRedisData::getFinalPlanPrice)
                .map(prices -> prices.get(planId))
                .ifPresent(finalPrice -> {
                    logger.info("Setting discounted price for plan ID {}: {}", planId, finalPrice);
                    moversServiceInfo.setDiscountedPrice(finalPrice);
                });
        if (redisData != null && redisData.getFinalPlanPrice() != null && !redisData.getFinalPlanPrice().containsKey(planId)) {
            logger.info("Plan ID {} not found in finalPlanPrice or finalPlanPrice is null", planId);
        }
    }

    private void processServiceInfoAndUpdateImageUrl(ServiceInfo serviceInfo, FiveGMoversServiceInfo moversServiceInfo) {
        Optional.ofNullable(serviceInfo.getCurrentDevice())
                .map(CurrentDevice::getOldLteVoraEquipInfo).filter(Objects::nonNull)
                .map(OldLteVoraEquipInfo::getLteVoraDeviceInfo).filter(Objects::nonNull).map(LteVoraDeviceInfo::getImageUrlMap)
                .ifPresent(moversServiceInfo::setImageUrlMap);
    }

    private void processServiceInfoAndUpdateDisplayName(ServiceInfo serviceInfo, FiveGMoversServiceInfo moversServiceInfo) {
        Optional.ofNullable(serviceInfo.getNewPricePlanInfo())
                .filter(pricePlanInfo -> StringUtilities.isNotEmptyOrNull(pricePlanInfo.getPricePlanDisplayName()))
                .ifPresent(pricePlan -> moversServiceInfo.setPlanName(pricePlan.getPricePlanDisplayName()));
    }

    private void processServiceInfoAndUpdateCustomerName(ServiceInfo serviceInfo, FiveGMoversServiceInfo moversServiceInfo) {
        Optional.ofNullable(serviceInfo.getPrimaryUserInfo())
                .ifPresent(primaryUserInfo -> {
                    moversServiceInfo.setFirstName(primaryUserInfo.getFirstName());
                    moversServiceInfo.setLastName(primaryUserInfo.getLastName());
                });
    }

    private void processServiceInfoAndUpdateDates(ServiceInfo serviceInfo, FiveGMoversServiceInfo moversServiceInfo) {
        Optional.ofNullable(serviceInfo.getMoversInfo())
                .filter(moversInfo -> StringUtilities.isNotEmptyOrNull(moversInfo.getMoveInDate()) && StringUtilities.isNotEmptyOrNull(moversInfo.getMoveOutDate()))
                .ifPresent(moversInfo -> {
                    moversServiceInfo.setMoveInDate(formatMoversDate(moversInfo.getMoveInDate()));
                    moversServiceInfo.setMoveOutDate(formatMoversDate(moversInfo.getMoveOutDate()));
                });
    }

    private void processLineInfoAndUpdateInstallationType(CXPLineInfo lineInfo, FiveGMoversServiceInfo moversServiceInfo) {
        try {
            if (ObjectUtils.isEmpty(lineInfo.getItemsInfo())) {
                return;
            }
            for (CXPItemInfo itemInfo : lineInfo.getItemsInfo()) {
                if (!ObjectUtils.isEmpty(itemInfo.getCartItems()) && !ObjectUtils.isEmpty(itemInfo.getCartItems().getCartItem())) {
                    for (CXPCartItem cartItem : itemInfo.getCartItems().getCartItem()) {
                        if (MOVERS_SELF.equalsIgnoreCase(cartItem.getSorId())) {
                            moversServiceInfo.setInstallationType(MOVERS_SELF_SETUP);
                        }
                        if (MOVERS_PRO.equalsIgnoreCase(cartItem.getSorId())) {
                            moversServiceInfo.setInstallationType(PROF_SETUP);
                        }
                    }
                }
            }
        } catch (Exception e) {
            logger.error("Error occurred while processing line info for installation type: " + e);
        }
    }

    private void processLineInfoAndUpdatePropositions(CXPLineInfo line, FiveGMoversServiceInfo moversServiceInfo, String crsp) {
        try {
            boolean downgradeProcessed = false;
            if (line.getDisqualifiedPropositions() != null &&
                    line.getDisqualifiedPropositions().length > 0) {
                List<Propositions> disQualifiedPropositionsList = Arrays.stream(line.getDisqualifiedPropositions()).filter
                        (resp -> (CartConstants.ACTION_D.equalsIgnoreCase(resp.getActionCode()) && (CartConstants.EXTENDER.equalsIgnoreCase(resp.getRewardType())
                                && (CartConstants.REDEEMED.equalsIgnoreCase(resp.getWhwRedemptionStatus()))))).collect(Collectors.toList());
                if (disQualifiedPropositionsList != null && disQualifiedPropositionsList.size() > 0) {
                    processAndSetFeatureMessages(moversServiceInfo, CartConstants.DOWNGRADE);
                    downgradeProcessed = true;
                }
            }

            if (!downgradeProcessed && line.getServiceInfo() != null && line.getServiceInfo().getOtherPromotions() != null
                    && line.getServiceInfo().getOtherPromotions().length > 0) {
                for (OtherPromotions promotion : line.getServiceInfo().getOtherPromotions()) {
                    if (promotion.getPromos() != null && promotion.getPromos().length > 0) {
                        // Check if a valid promo triggers a downgrade
                        boolean validPromoFound = processPromos(promotion.getPromos(), moversServiceInfo);
                        // Break the loop if a valid promo is found and processed
                        if (validPromoFound) {
                            break;
                        }
                    }
                }
            }

            if (line.getQualifiedPropositions() != null &&
                    line.getQualifiedPropositions().length > 0) {
                List<Propositions> qualifiedPropositionsList = Arrays.stream(line.getQualifiedPropositions()).filter
                        (resp -> (CartConstants.ACTION_A.equalsIgnoreCase(resp.getActionCode()) && (CartConstants.EXTENDER.equalsIgnoreCase(resp.getRewardType())
                                && (StringUtilities.isNotEmptyOrNull(crsp) && CartConstants.N.equalsIgnoreCase(crsp))))).collect(Collectors.toList());
                if (qualifiedPropositionsList != null && qualifiedPropositionsList.size() > 0) {
                    processAndSetFeatureMessages(moversServiceInfo, CartConstants.UPGRADE);
                }
            }
        } catch (Exception e) {
            logger.error("Error occurred while processing line info for installation type: " + e);
        }
    }

    private boolean processPromos(Promos[] promos, FiveGMoversServiceInfo moversServiceInfo) {
        if (promos != null && promos.length > 0) {
            for (Promos promo : promos) {
                if (promo != null && whwPromoId.equalsIgnoreCase(promo.getId())
                        && CartConstants.promoEnd.equalsIgnoreCase(promo.getDiscountActionCd())) {
                    processAndSetFeatureMessages(moversServiceInfo, CartConstants.DOWNGRADE);
                    return true;
                }
            }
        }
        return false;
    }

    private static void processAndSetFeatureMessages(FiveGMoversServiceInfo moversServiceInfo, String action) {
        FeatureMessages featureMessages = new FeatureMessages();
        featureMessages.setName(CartConstants.WHOLE_HOME_WIFI);
        featureMessages.setAction(action);
        List<FeatureMessages> featureMessagesList = moversServiceInfo.getImportantAccountChanges();
        if (!ObjectUtils.isEmpty(featureMessagesList) && featureMessagesList.size() > 0) {
            featureMessagesList.add(featureMessages);
        } else {
            List<FeatureMessages> newfeatureMessagesList = new ArrayList<>();
            newfeatureMessagesList.add(featureMessages);
            moversServiceInfo.setImportantAccountChanges(newfeatureMessagesList);
        }
    }

    private String formatMoversDate(String moveDate) {
        DateTimeFormatter format = DateTimeFormatter.ofPattern("MM/dd/yyyy");
        LocalDate localDate = LocalDate.parse(moveDate, format);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy", Locale.ENGLISH);
        return localDate.format(formatter);
    }

    private boolean validateMoversDate(String moveInDate, String moveOutDate, String timeZone) {
        try {
            DateTimeFormatter dateTime = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            dateTime.parse(moveInDate);
            dateTime.parse(moveOutDate);
            String[] inDate = moveInDate.split("/");
            String[] outDate = moveOutDate.split("/");
            LocalDate in = LocalDate.of(Integer.parseInt(inDate[2]), Integer.parseInt(inDate[0]), Integer.parseInt(inDate[1]));
            LocalDate out = LocalDate.of(Integer.parseInt(outDate[2]), Integer.parseInt(outDate[0]), Integer.parseInt(outDate[1]));
            ZoneId zoneId = ZoneId.of("US/Eastern");
            if (StringUtilities.isNotEmptyOrNull(timeZone)) {
                if ("PDT".equalsIgnoreCase(timeZone) || "PST".equalsIgnoreCase(timeZone))
                    zoneId = ZoneId.of("US/Pacific");
                else if ("CDT".equalsIgnoreCase(timeZone) || "CST".equalsIgnoreCase(timeZone))
                    zoneId = ZoneId.of("US/Central");
                else if ("MDT".equalsIgnoreCase(timeZone) || "MST".equalsIgnoreCase(timeZone))
                    zoneId = ZoneId.of("US/Mountain");
            }
            if (out.isBefore(LocalDate.now(zoneId)) || in.isBefore(out)) {
                return true;
            }
        } catch (DateTimeParseException e) {
            logger.info("Exception in Date format : {}" , e.getMessage());
            return true;
        }
        return false;
    }

    private AddMoveDatesUIResponse formatMoversDateError(AddMoveDatesUIResponse response) {
        List<CartError> errors = new ArrayList<>();
        CartError cartError = new CartError();
        cartError.setNamespace(CartConstants.SOE_CART_SERVICE);
        cartError.setMessage(CartConstants.INVALID_MOVE_DATE);
        cartError.setName(CartConstants.API_ERROR);
        errors.add(cartError);
        response.setErrors(errors);
        return response;
    }

    public Mono<AddMoveDatesUIResponse> addCustomerMoveDates(ServerHttpRequest httpHeader, MoveDatesRequest request) {
        Mono<MoversRedisData> redisData = redisHelper3.fiveGRedisMoversData();
        AddMoveDatesPegaRequest pegaRequest = new AddMoveDatesPegaRequest();
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        AddPlanAndDeviceServiceBody serviceBody = new AddPlanAndDeviceServiceBody();
        AddPlanAndDeviceServiceRequest serviceRequest = new AddPlanAndDeviceServiceRequest();
        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        AddPlanAndDeviceContext context = new AddPlanAndDeviceContext();
        MoversInfo moversInfo = new MoversInfo();
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        ScheduleAppointmentRequest scheduleAppointmentRequest = new ScheduleAppointmentRequest();
        AddMoveDatesUIResponse response = new AddMoveDatesUIResponse();
        if (validateMoversDate(request.getCartInfo().getMoveInDate(), request.getCartInfo().getMoveOutDate(), request.getCartInfo().getTimeZone())) {
            return Mono.just(formatMoversDateError(response));
        }
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        return redisData.flatMap(data -> {
            serviceHeader.setServiceName("Movers");
            serviceHeader.setClientId(channelId);
            serviceHeader.setStatusMsg(CartConstants.BPM_PEGA_GENERATED_MESSAGE);
            pegaRequest.setServiceHeader(serviceHeader);
            context.setCaseId(data.getCaseId());
            contextInfo.setCallReason("FiveGMovers");
            contextInfo.setIntent("MOV_5G");
            contextInfo.setProcessAction("UpdateDate");
            contextInfo.setProcessStep(data.getMoverNextProcessStep());
            context.setContextInfo(contextInfo);
            customerInfo.setCartCreator(data.getMoversMtn());
            customerInfo.setProcessingMTN(data.getMoversMtn());
            customerInfo.setAccountNumber(data.getAccountNumber());
            cartInfo.setCartId(data.getCartId());
            moversInfo.setMoveInDate(request.getCartInfo().getMoveInDate());
            moversInfo.setMoveOutDate(request.getCartInfo().getMoveOutDate());
            cartInfo.setMoversInfo(moversInfo);
            cartInfo.setItemType("SCHEDULE5GAPPT");
            scheduleAppointmentRequest.setCartId(data.getCartId());
            scheduleAppointmentRequest.setCartLineMtn(data.getMoversMtn());
            cartInfo.setScheduleAppointmentRequest(scheduleAppointmentRequest);
            context.setCartInfo(cartInfo);
            context.setCustomerInfo(customerInfo);
            serviceRequest.setContext(context);
            serviceBody.setServiceRequest(serviceRequest);
            pegaRequest.setServiceBody(serviceBody);
            return bpmHelper.addCustomerMoveDates(pegaRequest);
        });
    }

    public Mono<AddPlanAndDevicePEGAResponse> addMoversPlanAndDevice(MoversCartRequest request, AddPlanAndDeviceUIRequest addPlanAndDeviceRequest) {
        Mono<FiveGLTEAddressRedis> moversQualPegaResponse = redisHelper3.getFiveGAddressFromRedisFromFiveGFlow();
        return moversQualPegaResponse.flatMap(fiveGData -> {
            Map<String, String> redisData = new HashMap<>();
            AddPlanDeviceData data = new AddPlanDeviceData();
            Line line = new Line();
            List<Line> list = new ArrayList();
            addPlanAndDeviceRequest.setCartInfo(request.getCartInfo());
            AddPlanAndDevicePEGARequest pegaRequest = new AddPlanAndDevicePEGARequest();
            Mono<MoversRedisData> moversRedisDataMono = redisHelper3.fiveGRedisMoversData();
            return moversRedisDataMono.flatMap(moversRedisData -> {
                addPlanAndDeviceRequest.setData(data);
                line.setInstallType(CartConstants.MOVERS_INSTALL_TYPE);
                line.setIsNewLine(false);
                line.setDepletionType(CartConstants.MOVERS_DEPLETION_TYPE);
                line.setNewLineOrAAL(false);
                line.setMtn(moversRedisData.getMoversMtn());
                line.setNetworkBandwidthType(moversRedisData.getNetworkBandwidthType());
                line.setPrevNetworkBandwidthType(moversRedisData.getPrevNetworkBandwidthType());
                addPlanAndDeviceRequest.getCartInfo().setAqCaseId(moversRedisData.getAqCaseId());
                addPlanAndDeviceRequest.getCartInfo().setAccountNumber(moversRedisData.getAccountNumber());
                FiveG fiveG = new FiveG();
                FiveGAddress fiveGAdd = new FiveGAddress();
                fiveGAdd.setAddressLine1(fiveGData.getAddressLine1());
                fiveGAdd.setAddressLine2(fiveGData.getAddressLine2());
                fiveGAdd.setCity(fiveGData.getCity());
                fiveGAdd.setState(fiveGData.getState());
                fiveGAdd.setZipCode(fiveGData.getZipCode());
                fiveGAdd.setLatitude(fiveGData.getLatitude());
                fiveGAdd.setLongitude(fiveGData.getLongitude());
                fiveGAdd.setFloor(String.valueOf(fiveGData.getFloor()));
                fiveGAdd.setFipsCode(fiveGData.getFipsCode());
                fiveGAdd.setBuildingId(fiveGData.getBuildingId());
                fiveGAdd.setStreetName(fiveGData.getStreetName());
                fiveGAdd.setStreetNumber(fiveGData.getStreetNumber());
                fiveGAdd.setStreetType(fiveGData.getStreetType());
                fiveGAdd.setEmailId(fiveGData.getEmailAddress());
                fiveGAdd.setPhoneNumber(fiveGData.getCbr());
                fiveGAdd.setEventCorrelationId(fiveGData.getEventCorrelationId());
                fiveG.setAddress(fiveGAdd);
                line.setFiveG(fiveG);
                AccessoryAction accessoryAction = new AccessoryAction();
                Accessory accessory = new Accessory();
                accessory.setIsSoftSku(true);
                accessory.setCashOptionEnabled(false);
                accessory.setAccountLevelAccessory(false);
                accessory.setQty(CartConstants.MOVERS_QTY);
                accessory.setId(CartConstants.MOVERS_ID);
                accessory.setScannedItem(false);
                Accessory[] accessorylist = {accessory};
                accessoryAction.setAdd(accessorylist);
                line.setAccessories(accessoryAction);
                list.add(line);
                data.setLines(list);
                addPlanAndDeviceRequest.setData(data);
                boolean isMovOmniReqEnabled = featureFlagHelper.isMoversOmniCartReqEnabled();
                AddPlanAndDevicePEGARequest pegaRequest1 = CartPegaRequestUtil7.formatMoversPegaRequest(pegaRequest, addPlanAndDeviceRequest, isMovOmniReqEnabled);
                return bpmHelper3.addMoversPlanAndDevice(pegaRequest1).flatMap(pegaRes -> {
                    Optional.ofNullable(pegaRes).map(AddPlanAndDevicePEGAResponse::getServiceBody)
                            .map(AddPlanAndDeviceServiceBody::getServiceResponse)
                            .map(AddPlanAndDeviceServiceResponse::getContext)
                            .filter(Objects::nonNull)
                            .filter(addPlanAndDeviceContext -> addPlanAndDeviceContext.getCartInfo() != null)
                            .ifPresent(addPlanAndDeviceContext -> {
                                if(isMovOmniReqEnabled && StringUtilities.isNotEmptyOrNull(addPlanAndDeviceRequest.getChannelId()) && addPlanAndDeviceRequest.getChannelId().contains(OMNI)){
                                    redisData.put(SessionConstants.CASE_ID, addPlanAndDeviceContext.getCaseId());
                                    redisData.put(SessionConstants.CART_ID, addPlanAndDeviceContext.getCartInfo().getCartId());
                                } else {
                                    redisData.put(SessionConstants.FWA_CASE_ID, addPlanAndDeviceContext.getCaseId());
                                    redisData.put(SessionConstants.FWA_CART_ID, addPlanAndDeviceContext.getCartInfo().getCartId());
                                }
                                redisData.put(SessionConstants.FWA_INTEND_TYPE, request.getCartInfo().getIntendType());
                                Optional.ofNullable(addPlanAndDeviceContext).map(AddPlanAndDeviceContext::getContextInfo).filter(Objects::nonNull)
                                        .ifPresent(cartServiceContextInfo -> {
                                            redisData.put(CartConstants.MOVERS_PROCESSSTEP, cartServiceContextInfo.getProcessStep());
                                        });
                                redisHelper2.upsertDataInRedis(redisData).subscribe();
                            });

                    return Mono.just(pegaRes);
                });
            });
        });
    }


    public Mono<MoversUpdatePlanResponse> updateCustomerMoverPlan(MoversUpdatePlanRequest request, ServerHttpRequest httpHeader) {
        Mono<MoversRedisData> redisData = redisHelper3.fiveGRedisMoversData();
        MoversUpdatePlanPegaRequest pegaRequest = new MoversUpdatePlanPegaRequest();
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        AddPlanAndDeviceServiceBody serviceBody = new AddPlanAndDeviceServiceBody();
        AddPlanAndDeviceServiceRequest serviceRequest = new AddPlanAndDeviceServiceRequest();
        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        AddPlanAndDeviceContext context = new AddPlanAndDeviceContext();
        MoversInfo moversInfo = new MoversInfo();
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        ScheduleAppointmentRequest scheduleAppointmentRequest = new ScheduleAppointmentRequest();

        String channelId = httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID);
        return redisData.flatMap(data -> {
            setCartServiceHeader(serviceHeader, channelId, CartConstants.MOVERS_SERVICE_NAME, CartConstants.BPM_PEGA_GENERATED_MESSAGE);
            pegaRequest.setServiceHeader(serviceHeader);
            context.setCaseId(data.getCaseId());
            setCartServiceContext(contextInfo, CartConstants.MOVERS_CALLREASON, CartConstants.MOVERS_INTENT,
                    CartConstants.MOVERS_PROCESS_UPDATE_PLAN, CartConstants.PLAN_SELECTION);
            context.setContextInfo(contextInfo);
            setCustomerInfo(customerInfo, data.getMoversMtn(), data.getMoversMtn(), data.getAccountNumber());
            cartInfo.setCartId(data.getCartId());

            if (request.getCartInfo().getMoveInDate() != null) {
                moversInfo.setMoveInDate(request.getCartInfo().getMoveInDate());
            }

            if (request.getCartInfo().getMoveOutDate() != null) {
                moversInfo.setMoveOutDate(request.getCartInfo().getMoveOutDate());
            }

            cartInfo.setItemType(CartConstants.ITEMTYPE_PLAN);
            cartInfo.setIntendType(CartConstants.CPC_NAME);
            Line line = new Line();
            line.setMtn(data.getMoversMtn());
            if (request.getCurrentPlanId() != null) {
                line.setCurrentPlanId(request.getCurrentPlanId());
            }

            Plan plan = new Plan();
            if (request.getNewPlanId() != null) {
                plan.setId(request.getNewPlanId());
            }

            if (request.getNetworkBandwidthType() != null) {
                plan.setNetworkBandwidthType(request.getNetworkBandwidthType());
            }
            line.setPlan(plan);
            Line[] lines = new Line[1];
            lines[0] = line;
            cartInfo.setLines(lines);

            if (request.getEffectiveDate() != null) {
                cartInfo.setEffectiveDate(request.getEffectiveDate());
            }

            cartInfo.setCheckAutoPayDiscountEligible(CartConstants.YES);
            scheduleAppointmentRequest.setCartId(data.getCartId());
            scheduleAppointmentRequest.setCartLineMtn(data.getMoversMtn());
            cartInfo.setScheduleAppointmentRequest(scheduleAppointmentRequest);
            context.setCartInfo(cartInfo);
            context.setCustomerInfo(customerInfo);
            serviceRequest.setContext(context);
            serviceBody.setServiceRequest(serviceRequest);
            pegaRequest.setServiceBody(serviceBody);
            return bpmHelper.updateCustomerMoverPlan(pegaRequest).flatMap(pegaRes -> {
                Optional.ofNullable(pegaRes)
                        .map(MoversUpdatePlanResponse::getServiceBody)
                        .map(AddPlanAndDeviceServiceBody::getServiceResponse)
                        .map(AddPlanAndDeviceServiceResponse::getContext)
                        .filter(addPlanAndDeviceContext -> !ObjectUtils.isEmpty(addPlanAndDeviceContext) &&
                                !ObjectUtils.isEmpty(addPlanAndDeviceContext.getCartInfo()))
                        .ifPresent(addPlanAndDeviceContext -> {
                            Optional.ofNullable(addPlanAndDeviceContext.getCartInfo().getLines())
                                    .filter(carInfoLine -> carInfoLine.length > 0 && carInfoLine[0] != null)
                                    .map(carInfoLine -> carInfoLine[0].getCrsp())
                                    .ifPresent(crsp -> redisHelper3.upsertCRSP(crsp).subscribe());
                        });
                return Mono.just(pegaRes);
            });
        });
    }

    private static void setCustomerInfo(CartServiceCustomerInfo customerInfo, String cartCreator, String moversMtn,
                                        String accountNumber) {
        customerInfo.setCartCreator(cartCreator);
        customerInfo.setProcessingMTN(moversMtn);
        customerInfo.setAccountNumber(accountNumber);
    }

    private static void setCartServiceContext(CartServiceContextInfo contextInfo, String moversCallReason, String moversIntent,
                                              String moversProcessUpdatePlan, String planSelection) {
        contextInfo.setCallReason(moversCallReason);
        contextInfo.setIntent(moversIntent);
        contextInfo.setProcessAction(moversProcessUpdatePlan);
        contextInfo.setProcessStep(planSelection);
    }

    private static void setCartServiceHeader(CartServiceServiceHeader serviceHeader, String channelId,
                                             String moversServiceName, String pegaGeneratedMessage) {
        serviceHeader.setServiceName(moversServiceName);
        serviceHeader.setClientId(channelId);
        serviceHeader.setStatusMsg(pegaGeneratedMessage);
    }

}
