package onevz.soe.cart.util;


import com.fasterxml.jackson.core.JsonProcessingException;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.constants.FeatureFlagConstants;
import onevz.soe.cart.exceptions.JsonValidator;
import onevz.soe.cart.helper.FiveGhomeCommonHelper;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.helper.RedisHelper2;
import onevz.soe.cart.helper.RedisHelper3;
import onevz.soe.cart.model.clearAndContinue.ClearAndContinueContext;
import onevz.soe.cart.model.clearAndContinue.ClearAndContinueServiceBody;
import onevz.soe.cart.model.clearAndContinue.ClearAndContinueServiceResponse;
import onevz.soe.cart.model.common.Address;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.common.Device;
import onevz.soe.cart.model.common.FiveG.BundleDetails;
import onevz.soe.cart.model.common.FiveG.FiveGLTEAddressRedis;
import onevz.soe.cart.model.common.Line;
import onevz.soe.cart.model.deviceIdValidation.DeviceIdValidationLine;
import onevz.soe.cart.model.elasticsearch.DeviceAndCarrier;
import onevz.soe.cart.model.elasticsearch.TypeAheadData;
import onevz.soe.cart.model.initiateCheckout.OrderDetail;
import onevz.soe.cart.model.orderConfirmation.CXPOrderConfirm5GVO;
import onevz.soe.cart.model.orderConfirmation.CXPOrderConfirmation5GDataVO;
import onevz.soe.cart.model.retrieveCart.*;
import onevz.soe.cart.model.retrieveCart.fiveG.AMRegisterationDetails;
import onevz.soe.cart.model.retrieveCart.fiveG.CXPDueItemsList;
import onevz.soe.cart.model.retrieveCart.fiveG.CXPDueTaxesList;
import onevz.soe.cart.model.retrieveCart.fiveG.CXPOrderDetailsView;
import onevz.soe.cart.requests.GetCartDetailsRequest;
import onevz.soe.cart.requests.RetrieveCartCXPRequest;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.ui.requests.AddDeviceUIRequest;
import onevz.soe.cart.ui.requests.AddPlanAndDeviceUIRequest;
import onevz.soe.cart.ui.requests.AddZipCodeUIRequest;
import onevz.soe.cart.ui.requests.ClearAndContinueUIRequest;
import onevz.soe.cart.ui.responses.AddDeviceUIResponse;
import onevz.soe.cart.ui.responses.AddPlanUIResponse;
import onevz.soe.cart.ui.responses.ClearAndContinueUIResponse;
import onevz.soe.cart.ui.responses.RetrieveCartUIResponse;
import onevz.soe.errorhandling.aem.model.AEMCreditExceptionResponse;
import onevz.soe.logging.util.LoggerUtil;
import onevz.soe.security.TokenProcessor;
import onevz.soe.security.model.SsoJwtDTO;
import onevz.soe.security.util.RPSAES128CBCUtil;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.spring.web.filter.RequestAccessContext;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.utilities.serialization.JacksonMapperFactory;
import onevz.soe.wsclient.bpm.model.response.Error;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.util.Lists;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.text.DecimalFormat;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static onevz.soe.cart.constants.CartConstants.LAUNCH_TYPE;
import static onevz.soe.cart.constants.CartConstants.NETWORK_BANDWIDTH_TYPE;
import static onevz.soe.cart.constants.FeatureFlagConstants.APPLICATION_NAME_DIGITAL;

@Service
public class CommonUtil {

    @Autowired
    SOELoginSessionBean sessionBean;
    @Autowired
    FiveGhomeCommonHelper commonHelper;
    private static final Logger logger = LoggerFactory.getLogger(CommonUtil.class);
    private static String homeIntendTypeValues;
    @Value("${soe.digital.home.intendTypeValues}")
    public void setHomeIntendTypeValues(String name){
        CommonUtil.homeIntendTypeValues = name;
    }
    @Value("${smart.imei.typeahead.stopwords}")
	private String SMART_IMEI_TYPEAHEAD_STOP_WORDS;

	@Value("${smart.imei.supress.carriers:other}")
	private String SMART_IMEI_SUPPRESS_CARRIERS;
	
	@Value("${soe.5g.promoKey.autoPay:auto-pay-and-paper-free-billing}")
    private String autoPayPromoKey;
	
	@Autowired
    private RedisHelper redisHelper;

    @Autowired
    private RedisHelper2 redisHelper2;

    @Autowired
    private RedisHelper3 redisHelper3;
	
	@Autowired
    private RPSAES128CBCUtil security5GUtil;
	
	@Autowired
	JsonValidator validator;

    @Autowired
    @Value("#{'${soe.willowPlanId}'.split(',')}")
    private List<String> willowIds;

    @Autowired
    TokenProcessor tokenProcessor;



    public void populatePlanDetailsInKibana(GetCartDetailsUIResponse response, Map<String, String> planDetails) {
        try {
            Map<String, String> fields = new HashMap<>();
            if (null != response && null != response.getOrderDetailsView())
                planDetails.put("networkBandWidthType", response.getOrderDetailsView().getNetworkBandwidthType());
            fields.put("plansinfo", JacksonMapperFactory.defaultWriter().writeValueAsString(planDetails));
            LoggerUtil.addCustomPersistField(fields);
        }catch (Exception e) {
            logger.info("Error occurred while populating kibana logs: populatePlanDetailsInKibana method");
        }
    }
    public void populatingUIrequestToRedisAddress(AddPlanAndDeviceUIRequest request, FiveGLTEAddressRedis address)
    {
        address.setAddressLine1(request.getCartInfo().getLqInfo().getAddressLine1());
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getAqCaseId()))
        {
            address.setAqCaseId(request.getCartInfo().getLqInfo().getAqCaseId());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getCity()))
        {
            address.setCity(request.getCartInfo().getLqInfo().getCity());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getNetworkBandwidthType()))
        {
            address.setNetworkBandwidthType(request.getCartInfo().getLqInfo().getNetworkBandwidthType());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getEventCorrelationId()))
        {
            address.setEventCorrelationId(request.getCartInfo().getLqInfo().getEventCorrelationId());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getFipsCode()))
        {
            address.setFipsCode(request.getCartInfo().getLqInfo().getFipsCode());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getZipCode()))
        {
            address.setZipCode(request.getCartInfo().getLqInfo().getZipCode());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getLaunchType()))
        {
            address.setLaunchType(request.getCartInfo().getLqInfo().getLaunchType());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getState()))
        {
            address.setState(request.getCartInfo().getLqInfo().getState());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getStreetName()))
        {
            address.setStreetName(request.getCartInfo().getLqInfo().getStreetName());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getStreetNumber()))
        {
            address.setStreetNumber(request.getCartInfo().getLqInfo().getStreetNumber());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getStreetType()))
        {
            address.setStreetType(request.getCartInfo().getLqInfo().getStreetType());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getFiveGHomeQualified()))
        {
            address.setFiveGHomeQualified(request.getCartInfo().getLqInfo().getFiveGHomeQualified());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getAddressLine2()))
        {
            address.setAddressLine2(request.getCartInfo().getLqInfo().getAddressLine2());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getLTEHomeQualified()))
        {
            address.setLTEHomeQualified(request.getCartInfo().getLqInfo().getLTEHomeQualified());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getLTEHomeSku()))
        {
            address.setLTEHomeSku(request.getCartInfo().getLqInfo().getLTEHomeSku());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getLatitude()))
        {
            address.setLatitude(request.getCartInfo().getLqInfo().getLatitude());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getLongitude()))
        {
            address.setLongitude(request.getCartInfo().getLqInfo().getLongitude());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getOutletId()))
        {
            address.setOutletId(request.getCartInfo().getLqInfo().getOutletId());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getVendorId()))
        {
            address.setVendorId(request.getCartInfo().getLqInfo().getVendorId());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getCartCreatorOrderLocationCode()))
        {
            address.setCartCreatorOrderLocationCode(request.getCartInfo().getLqInfo().getCartCreatorOrderLocationCode());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getCbr()))
        {
            address.setCbr(request.getCartInfo().getLqInfo().getCbr());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getBuildingId()))
        {
            address.setBuildingId(request.getCartInfo().getLqInfo().getBuildingId());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getCrmResumeCartFlow()))
        {
            address.setCrmResumeCartFlow(request.getCartInfo().getLqInfo().getCrmResumeCartFlow());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getIsD2DFlow()))
        {
            address.setIsD2DFlow(request.getCartInfo().getLqInfo().getIsD2DFlow());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getFiveGMUCEligible()))
        {
            address.setFiveGMUCEligible(request.getCartInfo().getLqInfo().getFiveGMUCEligible());
        }
        if(request.getCartInfo().getLqInfo().getFloor()!=null)
        {
            address.setFloor(request.getCartInfo().getLqInfo().getFloor());
        }
        List<BundleDetails> UIBundleList;
        if(request.getCartInfo().getLqInfo().getBundleList()!=null) {
            UIBundleList = request.getCartInfo().getLqInfo().getBundleList();
            List<BundleDetails> redisBundleList = new ArrayList<>();

            for (int i = 0; i < UIBundleList.size(); i++) {
                BundleDetails bundle = new BundleDetails();
                if(request.getCartInfo().getLqInfo().getBundleList().get(i).getBundleName()!=null
                        && request.getCartInfo().getLqInfo().getBundleList().get(i).getId()!=null) {
                    bundle.setBundleName(request.getCartInfo().getLqInfo().getBundleList().get(i).getBundleName());
                    redisBundleList.add(bundle);
                    address.setBundleList(redisBundleList);
                    bundle.setId(request.getCartInfo().getLqInfo().getBundleList().get(i).getId());
                }
            }
        }
    }
    public void populatingUIRequestToSessionData(AddPlanAndDeviceUIRequest request, Map<String, String> sessionData)
    {
        sessionData.put(CartConstants.ADDRESSLINE1,request.getCartInfo().getLqInfo().getAddressLine1());
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getAqCaseId()))
        {
            sessionData.put(CartConstants.AQ_CASE_ID,request.getCartInfo().getLqInfo().getAqCaseId());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getNetworkBandwidthType()))
        {
            sessionData.put(CartConstants.NETWORK_BANDWIDTH_TYPE,request.getCartInfo().getLqInfo().getNetworkBandwidthType());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getNetworkBandwidthType())
                && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getLTEHomeSku())
                && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getLTEHomeQualified())
                && request.getCartInfo().getLqInfo().getNetworkBandwidthType().equalsIgnoreCase("CBD"))
        {
            sessionData.put(CartConstants.CBAND_SKU,request.getCartInfo().getLqInfo().getLTEHomeSku());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getCity()))
        {
            sessionData.put(CartConstants.CITY,request.getCartInfo().getLqInfo().getCity());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getEventCorrelationId()))
        {
            sessionData.put(CartConstants.EVENTCORRELATIONID,request.getCartInfo().getLqInfo().getEventCorrelationId());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getFipsCode()))
        {
            sessionData.put(CartConstants.FIPS_CODE,request.getCartInfo().getLqInfo().getFipsCode());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getZipCode()))
        {
            sessionData.put(CartConstants.ZIPCODE,request.getCartInfo().getLqInfo().getZipCode());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getLaunchType()))
        {
            sessionData.put(CartConstants.LAUNCH_TYPE,request.getCartInfo().getLqInfo().getLaunchType());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getState()))
        {
            sessionData.put(CartConstants.STATE,request.getCartInfo().getLqInfo().getState());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getStreetName()))
        {
            sessionData.put(CartConstants.STREET_NAME,request.getCartInfo().getLqInfo().getStreetName());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getStreetNumber()))
        {
            sessionData.put(CartConstants.STREET_NUBMER,request.getCartInfo().getLqInfo().getStreetNumber());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getStreetType()))
        {
            sessionData.put(CartConstants.STREET_TYPE,request.getCartInfo().getLqInfo().getStreetType());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getFiveGHomeQualified()))
        {
            sessionData.put(CartConstants.FIVEG_HOME_QUALIFIED,request.getCartInfo().getLqInfo().getFiveGHomeQualified());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getAddressLine2()))
        {
            sessionData.put(CartConstants.ADDRESSLINE2,request.getCartInfo().getLqInfo().getAddressLine2());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getLTEHomeQualified()))
        {
            sessionData.put(CartConstants.LTE_HOME_QUALIFIED,request.getCartInfo().getLqInfo().getLTEHomeQualified());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getLTEHomeSku()))
        {
            sessionData.put(CartConstants.LTEHOMESKU,request.getCartInfo().getLqInfo().getLTEHomeSku());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getLatitude()))
        {
            sessionData.put(CartConstants.LATITUDE,request.getCartInfo().getLqInfo().getLatitude());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getLongitude()))
        {
            sessionData.put(CartConstants.LONGITUDE,request.getCartInfo().getLqInfo().getLongitude());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getOutletId()))
        {
            sessionData.put(CartConstants.OUTLET_ID,request.getCartInfo().getLqInfo().getOutletId());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getVendorId()))
        {
            sessionData.put(CartConstants.VENDOR_ID,request.getCartInfo().getLqInfo().getVendorId());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getCartCreatorOrderLocationCode()))
        {
            sessionData.put(CartConstants.D2D_LOCATION_CODE,request.getCartInfo().getLqInfo().getCartCreatorOrderLocationCode());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getCbr()))
        {
            sessionData.put(CartConstants.CBR,request.getCartInfo().getLqInfo().getCbr());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getBuildingId()))
        {
            sessionData.put(CartConstants.BUILDING_ID,request.getCartInfo().getLqInfo().getBuildingId());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getCrmResumeCartFlow()))
        {
            sessionData.put(CartConstants.CRM_RESUME_CART_FLOW,request.getCartInfo().getLqInfo().getCrmResumeCartFlow());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getIsD2DFlow()))
        {
            sessionData.put(CartConstants.IS_D2D_FLOW,request.getCartInfo().getLqInfo().getIsD2DFlow());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLqInfo().getFiveGMUCEligible()))
        {
            sessionData.put(CartConstants.MUC_ELIGIBLE_FLAG,request.getCartInfo().getLqInfo().getFiveGMUCEligible());
        }
        if(request.getCartInfo().getLqInfo().getFloor()!=null)
        {
            sessionData.put(CartConstants.FLOOR_NUMBER,String.valueOf(request.getCartInfo().getLqInfo().getFloor()));
        }
        if(request.getCartInfo().getLqInfo().getBundleList()!=null) {
            List<String> bundleIdsList = request.getCartInfo().getLqInfo().getBundleList().stream().map(bundleId -> bundleId.getId()).distinct().collect(Collectors.toList());
            String bundleIds = String.join(",", bundleIdsList);
            sessionData.put(CartConstants.BUNDLEID, bundleIds);
            List<String> bundleNamesList = request.getCartInfo().getLqInfo().getBundleList().stream().map(bundleName -> bundleName.getBundleName()).distinct().collect(Collectors.toList());
            String bundleNames = String.join(",", bundleNamesList);
            if(bundleNames != null && bundleNames.contains("Gemini")){
                sessionData.put(CartConstants.BUNDLE_TYPE, "Gemini");
            }else if(bundleNames != null && bundleNames.contains("Luna")){
                sessionData.put(CartConstants.BUNDLE_TYPE, "Luna");
            }else{
                sessionData.put(CartConstants.BUNDLE_TYPE, "LTE");
            }
            sessionData.put(CartConstants.BUNDLENAME, bundleNames);
        }
        sessionBean.setSessionData(sessionData).subscribe();

    }
    
    public List<Error> formatError(SOEHTTPException exception, List<Error> errors) {
    	exception.getErrorHolder().getErrors().forEach(soeError -> {
            Error error = new Error();
            error.setMessage(soeError.getMessage());
            error.setId(soeError.getId());
            error.setNamespace(soeError.getNamespace());
            error.setName(soeError.getName());
            error.setDebug_id(soeError.getDebug_id());
            errors.add(error);
        });
    	return errors;
    }
    
    /**
	 * @param makeOrModel
	 * @return List<String>
	 */
	public List<String> splitMakeOrModel(String makeOrModel) {
		List<String> modelNames = null;
		if (makeOrModel.split(" ").length == 2) {
			if (Character.isDigit(makeOrModel.charAt(makeOrModel.length() - 1))
					|| makeOrModel.split(" ")[1].length() == 2) {
				modelNames = Arrays.asList(makeOrModel);
			}else {
				modelNames = Arrays.asList(makeOrModel.split(" "));
			}
		} else {
			modelNames = Arrays.asList(makeOrModel.split(" "));
		}
		return modelNames;
	}
	
	public TypeAheadData formatDeviceMerge(String key, List<DeviceAndCarrier> value, Map<String,String> makeMap, Map<String,Boolean> euiccCapableMap, Map<String,Set<String>> uniqueCarrierMap, Map<String,Boolean> esimOnlyMap) {
		TypeAheadData deviceMerge = new TypeAheadData();
        deviceMerge.setModifiedName(key);
        deviceMerge.setModel_name_typeahead(key);
        deviceMerge.setDeviceAndCarrier(value);
        deviceMerge.setMake_typeahead(makeMap.get(key));
        deviceMerge.setEuiccCapable(euiccCapableMap.get(key));
        if(esimOnlyMap!=null && !esimOnlyMap.isEmpty() && esimOnlyMap.get(key)!=null)
            deviceMerge.setEsimOnly(esimOnlyMap.get(key));
        else
            deviceMerge.setEsimOnly(Boolean.FALSE);
        List<String> carrierList = Lists.newArrayList(uniqueCarrierMap.get(key));
        if(CollectionUtilities.isNotEmptyOrNull(carrierList) && carrierList.size() > 1) { // do the sorting only when the size is greater than one
        	Collections.sort(carrierList, Collections.reverseOrder());
        }
        deviceMerge.setCarrier(carrierList);
        return deviceMerge;
	}
	
	public Device formatDevice(DeviceIdValidationLine line, Device device) {
		if (line.getDevice().getId() != null)
			device.setId(line.getDevice().getId());
		if (line.getDevice().getFlowtype() != null)
			device.setFlowtype(line.getDevice().getFlowtype());
		if (line.getDevice().getCurrentId() != null)
			device.setCurrentId(line.getDevice().getCurrentId());
		if (line.getDevice().getIsCustomerProvidedEquipment() != null)
			device.setIsCustomerProvidedEquipment(line.getDevice().getIsCustomerProvidedEquipment());
		return device;
	}
	
	/**
	 * Get Stop words List
	 *
	 * @return
	 */
	public List<String> getStopWords() {
		List<String> stopWordList = new ArrayList<>();
		if (StringUtilities.isNotEmptyOrNull(SMART_IMEI_TYPEAHEAD_STOP_WORDS)) {
			String stopWordData = SMART_IMEI_TYPEAHEAD_STOP_WORDS;
			String[] stopWordSplit = stopWordData.split(",");
			stopWordList.addAll(Arrays.asList(stopWordSplit));
		}
		return stopWordList;
	}
	
	public String getModifiedName(String name) {
		String[] searchModelNames = new String[] { CartConstants.SAMSUNG, CartConstants.MOTOROLA, CartConstants.SONY,
				CartConstants.IPHONE };
		if (StringUtils.containsAny(name, searchModelNames)) {
			if (name.contains(CartConstants.IPHONE)) {
				name = name.replaceAll(CartConstants.IPHONE, CartConstants.IPHONE_DEVICENAME);
			} else if (name.contains(CartConstants.SAMSUNG)) {
				name = name.replaceAll(CartConstants.SAMSUNG, CartConstants.SAMSUNG_DEVICENAME);
			} else if (name.contains(CartConstants.MOTOROLA)) {
				name = name.replaceAll(CartConstants.MOTOROLA, CartConstants.MOTOROLA_DEVICENAME);
			} else if (name.contains(CartConstants.SONY)) {
				name = name.replaceAll(CartConstants.SONY, CartConstants.SONY_DEVICENAME);
			}
		}
		return name;
	}

    public static CXPDueItemsList populateDueTodayItems(CXPCartItem itemsInfo1) {
        CXPDueItemsList dueTodayItems = new CXPDueItemsList();
        ImageUrlMap imageUrlMap=new ImageUrlMap();
        dueTodayItems.setItemType(itemsInfo1.getCartItemType());
        dueTodayItems.setName(itemsInfo1.getDescription());
        dueTodayItems.setSorId(itemsInfo1.getSorId());
        dueTodayItems.setProductId(itemsInfo1.getProductId());
        dueTodayItems.setDiscountApplied(String.valueOf(itemsInfo1.getDiscountAmount()));
        dueTodayItems.setQuantity(String.valueOf(itemsInfo1.getQty()));
        dueTodayItems.setActualAmount(itemsInfo1.getItemPrice());
        dueTodayItems.setTotalAmountWithDiscount(String.valueOf(itemsInfo1.getDiscountedPrice()));
        if(itemsInfo1.getImageUrlMap()!=null && itemsInfo1.getImageUrlMap().getMediumImage()!=null) {
            imageUrlMap.setMediumImage(itemsInfo1.getImageUrlMap().getMediumImage());
        }
        if(itemsInfo1.getImageUrlMap()!=null && itemsInfo1.getImageUrlMap().getDefaultImage()!=null) {
            imageUrlMap.setDefaultImage(itemsInfo1.getImageUrlMap().getDefaultImage());
        }
        if(itemsInfo1.getImageUrlMap()!=null && itemsInfo1.getImageUrlMap().getMiniImage()!=null) {
            imageUrlMap.setMiniImage(itemsInfo1.getImageUrlMap().getMiniImage());
        }
        if(itemsInfo1.getImageUrlMap()!=null && itemsInfo1.getImageUrlMap().getLargeImage()!=null) {
            imageUrlMap.setLargeImage(itemsInfo1.getImageUrlMap().getLargeImage());
        }
        if(itemsInfo1.getImageUrlMap()!=null && itemsInfo1.getImageUrlMap().getThumbImage()!=null) {
            imageUrlMap.setThumbImage(itemsInfo1.getImageUrlMap().getThumbImage());
        }
        if(imageUrlMap!=null) {
            dueTodayItems.setImageUrlMap(imageUrlMap);
        }
        return dueTodayItems;
    }

    public static List<LineRedisData> populateLineRedisData(RetrieveCartUIResponse cxpResponse) {
        List<LineRedisData> data = new ArrayList<LineRedisData>();
        Optional.ofNullable(cxpResponse.getData()).map(CXPRetrieveCartDataVO::getCart).map(CXPCartVO::getLineDetails)
                .ifPresent(lineDetails -> {
                    LineRedisData lineData = new LineRedisData();
                    lineData.setNumOfLines(String.valueOf(lineDetails.getNumOfLines()));
                    lineData.setNumOfLinesAAL(String.valueOf(lineDetails.getNumofLinesAAL()));
                    lineData.setNumOfLinesEUP(String.valueOf(lineDetails.getNumofLinesEUP()));
                    Arrays.stream(lineDetails.getLineInfo()).filter(Objects::nonNull).forEach(lineInfo -> {
                        ServiceInfo serviceInfo = Optional.ofNullable(lineInfo.getServiceInfo())
                                .orElse(new ServiceInfo());

                        lineData.setMtn(serviceInfo.getMtn());
                        lineData.setSelectedALPShareList(serviceInfo.getSelectedALPShareList());
                        data.add(lineData);
                    });
                });
        return data;
    }

    public static CXPOrderDetailsView populateCXPOrderDetailsView(RetrieveCartUIResponse cxpResponse) {
        CXPOrderDetailsView orderDetailsView = new CXPOrderDetailsView();
        CXPOrderDetails cxpOrderDetails1 = cxpResponse.getData().getCart().getOrderDetails();
        orderDetailsView.setDueMonthlyAmount(String.valueOf(cxpOrderDetails1.getTotalDueMonthly()));
        formatOrderDetailsView(orderDetailsView, cxpOrderDetails1);
        return orderDetailsView;
    }

    public static CXPOrderDetailsView populateOrderDetailsView(CXPLineDetailsVO lineDetails, CXPOrderDetailsView orderDetailsView) {
        if (null != lineDetails && null != lineDetails.getNumOfLines()) {
            orderDetailsView.setNumOfLines(String.valueOf(lineDetails.getNumOfLines()));
        }
        if (null != lineDetails && null != lineDetails.getSubAccountNBSInfo()) {
            lineDetails.getSubAccountNBSInfo().stream().filter(Objects::nonNull).findFirst().ifPresent(nbsInfo -> {
                nbsInfo.getBillAccounts().stream().filter(Objects::nonNull).findFirst().ifPresent(billAccount -> {
                    if (null != billAccount.getNbs() && null != billAccount.getNbs().getAutoPayDiscount()) {
                        orderDetailsView.setIsCustomerEnrolledForAutopay(String.valueOf(billAccount.getNbs().getAutoPayDiscount().getIsCustomerEnrolledForAutopay()));
                        orderDetailsView.setAccountTotalAutoPayDiscount(billAccount.getNbs().getAutoPayDiscount().getAccountTotalAutoPayDiscount());
                    }
                });
            });
        }
        return orderDetailsView;
    }
    public void populateKibanaFieldsForTechFlows(OrderConfirmationCXPResponse cxpResponse, TechFlowRedisData redisData) {
        Map<String, String> orderInfo = new HashMap<>();
        Map<String, String> fields = new HashMap<>();
        populateTechFlowRedisData(redisData,orderInfo);
        populateTechFlowOrderDetails(cxpResponse,orderInfo);
        populateTechFlowServiceDetails(cxpResponse,orderInfo);


        try {
            fields.put("orderinfo", JacksonMapperFactory.defaultWriter().writeValueAsString(orderInfo));
            LoggerUtil.addCustomPersistField(fields);
        } catch (JsonProcessingException e) {
            logger.info("Error During populateKibanaFieldsForTechFlows {}", e.getMessage());
        }


    }

    private void populateTechFlowServiceDetails(OrderConfirmationCXPResponse cxpResponse,Map<String, String> orderInfo) {
        Optional.ofNullable(cxpResponse)
                .map(OrderConfirmationCXPResponse::getData)
                .map(CXPOrderConfirmation5GDataVO::getCart)
                .map(CXPOrderConfirm5GVO::getLineDetails)
                .map(CXPLineDetailsVO::getLineInfo).filter(Objects::nonNull).ifPresent(cxpLineInfos -> {
            Arrays.stream(cxpLineInfos).findFirst().ifPresent(lineInfo -> {
                Optional.ofNullable(lineInfo)
                        .map(CXPLineInfo::getServiceInfo)
                        .map(ServiceInfo::getPrimaryUserInfo).filter(Objects::nonNull).ifPresent(primaryUserInfo -> {
                    orderInfo.put("emailId",primaryUserInfo.getEmailId());
                });
                Optional.ofNullable(lineInfo)
                        .map(CXPLineInfo::getServiceInfo)
                        .map(ServiceInfo::getCart5GAddress).filter(Objects::nonNull).ifPresent(address -> {
                    String serviceAddress = address.getAddressLine1() + (StringUtilities.isNotEmptyOrNull(address.getAddressLine2()) ? (address.getAddressLine2() + " "): (" " ))+ address.getCity() + " " + address.getState() + " " + address.getZipCode();
                    orderInfo.put("serviceAddress", serviceAddress);
                });
                Optional.ofNullable(lineInfo)
                        .map(CXPLineInfo::getServiceInfo)
                        .map(ServiceInfo::getNewPricePlanInfo).ifPresent(pricePlanInfo -> {
                    orderInfo.put("newPlanId", String.valueOf(pricePlanInfo.getPlanPrice()));
                    orderInfo.put("upgradedOrderMtn", lineInfo.getMobileNumber());
                });
                Optional.ofNullable(lineInfo)
                        .map(CXPLineInfo::getItemsInfo).filter(Objects::nonNull).ifPresent(cxpItemInfos -> {
                    Arrays.stream(cxpItemInfos).filter(Objects::nonNull).findFirst()
                            .map(CXPItemInfo::getCartItems)
                            .map(CXPCartItemsVO::getCartItem).filter(Objects::nonNull).ifPresent(cxpCartItems -> {
                        Arrays.stream(cxpCartItems).filter(cartItem -> CartConstants.DEVICE_TYPE.equalsIgnoreCase(cartItem.getCartItemType())).findFirst().ifPresent(cartItem -> {
                            orderInfo.put("deviceSkus", cartItem.getSorId());
                        });
                    });
                });
            });

        });
    }

    private void populateTechFlowOrderDetails(OrderConfirmationCXPResponse cxpResponse,Map<String, String> orderInfo) {
        Optional.ofNullable(cxpResponse)
                .map(OrderConfirmationCXPResponse::getData)
                .map(CXPOrderConfirmation5GDataVO::getCart)
                .map(CXPOrderConfirm5GVO::getOrderDetails).filter(Objects::nonNull).ifPresent(cxpOrderDetails -> {
            orderInfo.put("salesRepId",cxpOrderDetails.getSalesRepId());
            orderInfo.put("newOrderLocationCode",cxpOrderDetails.getLocationCode());
            orderInfo.put("techFlow","Y");
            orderInfo.put("orderStatus", "DSO_COMPLETED");
            Optional.ofNullable(cxpOrderDetails.getOrderList()).filter(Objects::nonNull).ifPresent(orderLists -> {
                orderLists.stream().filter(Objects::nonNull).findFirst().ifPresent(orderList -> {
                    orderInfo.put("newOrderNumber", String.valueOf(orderList.getOrderNumber()));
                });
            });
        });
        Optional.ofNullable(cxpResponse)
                .map(OrderConfirmationCXPResponse::getData)
                .map(CXPOrderConfirmation5GDataVO::getCart)
                .map(CXPOrderConfirm5GVO::getCartHeader).filter(Objects::nonNull).ifPresent(retrieveCartHeader -> {
            orderInfo.put(CartConstants.CART_ID,retrieveCartHeader.getCartId());
            orderInfo.put(CartConstants.CASE_ID,retrieveCartHeader.getCaseId());

        });
    }

    private void populateTechFlowRedisData(TechFlowRedisData redisData,Map<String, String> orderInfo) {
        if(null != redisData) {
            orderInfo.put("serviceAddress", redisData.getServiceAddress());
            orderInfo.put("failedOrderNumber", redisData.getVpmOrderNum());
            orderInfo.put("failedOrderLocationCode", redisData.getVpmLocationCode());
            orderInfo.put("currentPlanId", redisData.getFiveGPlan());
            if("AAL_CPC_CBD_TECH".equalsIgnoreCase(redisData.getIntentType()) || "AAL_CBD_TECH".equalsIgnoreCase(redisData.getIntentType())) {
                orderInfo.put("networkBandwidthType", "CBD");
            }
        }
    }
    
    public void formatCxpRequest(GetCartDetailsRequest request, RetrieveCartCXPRequest cxpRequest, FiveGLTEAddressRedis data) {
    	cxpRequest.setChannelId(data.getChannelId());
        CXPRetrieveCartDataVO cxpData = new CXPRetrieveCartDataVO();
        if(StringUtilities.isNotEmptyOrNull(data.getCartId()) && ! request.getData().isOrderPlaced()) {
            cxpData.setCartId(data.getCartId());
        }
        else if(StringUtilities.isNotEmptyOrNull(data.getCompletedCartId()) && request.getData().isOrderPlaced()) {
            cxpData.setCartId(data.getCompletedCartId());
        }
        else if(null != request && null != request.getData() && StringUtilities.isNotEmptyOrNull(request.getData().getCartId())) {
            cxpData.setCartId(request.getData().getCartId());
        }
       if(null != request && null != request.getData() && request.getData().isValidateAppointments()) {
            cxpData.setValidateAppointments(request.getData().isValidateAppointments());
        }
        cxpRequest.setData(cxpData);
        cxpRequest.setMeta(new HashMap<>());
    }
    
    public Mono<ResponseEntity<GetCartDetailsUIResponse>> responseOnError(Throwable throwable) {
    	GetCartDetailsUIResponse uiResponse =  new GetCartDetailsUIResponse();
        List<CartError> errors = new ArrayList<>();
        try {
            SOEHTTPException exception = (SOEHTTPException) throwable;
            exception.getErrorHolder().getErrors().forEach(soeError -> {
                CartError error = new CartError();
                error.setMessage(soeError.getMessage());
                error.setId(soeError.getId());
                error.setNamespace(soeError.getNamespace());
                error.setName(soeError.getName());
                error.setDebug_id(soeError.getDebug_id());
                errors.add(error);
            });
        }catch(Exception e) {
            logger.error("Exception on 5g validate-cart cxp api", throwable);
        }
        uiResponse.setErrors(setErrorCategory(errors,CartConstants.ERRCAT_CXP));
        return Mono.just(ResponseEntity.status(200).body(uiResponse));
    }
    public static List<CartError> setErrorCategory(List<CartError> errors ,String errCategory){
        if(null != errors && !errors.isEmpty())
            errors.get(0).setErrorCategory(errCategory);
        return errors;
    }
    
    public void formatRequestMap(CXPLineDetailsVO lineDetails, CXPOrderDetails orderDetails, Map<String, String> requestMap) {
		if(null != orderDetails.getEligible5GHomeBundle() && orderDetails.getEligible5GHomeBundle().size() >0) {
            List<String> bundleName=new ArrayList<>();
            List<String> bundleId=new ArrayList<>();
            orderDetails.getEligible5GHomeBundle().stream().filter(Objects::nonNull).forEach(eligible5GHomeBundle -> {
                bundleName.add(eligible5GHomeBundle.getBundleName());
                bundleId.add(eligible5GHomeBundle.getId());
            });
            String bundleNames=String.join(",",bundleName);
            String bundleIds=String.join(",",bundleId);
            requestMap.put(CartConstants.BUNDLENAME, bundleNames);
            requestMap.put(CartConstants.BUNDLEID, bundleIds);
        }
        if (null != lineDetails && null != lineDetails.getLineInfo()) {
            Arrays.stream(lineDetails.getLineInfo()).filter(Objects::nonNull).findFirst().ifPresent(lineInfo1 -> {
                Arrays.stream(lineInfo1.getItemsInfo()).filter(Objects::nonNull).forEach(cxpItemInfo -> {
                    Optional.ofNullable(cxpItemInfo).map(CXPItemInfo::getCartItems).ifPresent(cxpCartItemsVO -> {
                        Arrays.stream(cxpCartItemsVO.getCartItem()).filter(Objects::nonNull).forEach(cxpCartItem -> {
                            if (CartConstants.DEVICE_TYPE.equalsIgnoreCase(cxpCartItem.getCartItemType()) && StringUtilities.isNotEmptyOrNull(cxpCartItem.getNetworkBandwidthType())) {
                                requestMap.put(NETWORK_BANDWIDTH_TYPE, cxpCartItem.getNetworkBandwidthType());
                                if ("MMW".equalsIgnoreCase(cxpCartItem.getNetworkBandwidthType())) {
                                    requestMap.put(LAUNCH_TYPE, "FCL");
                                }
                            }
                        });
                    });
                });
                if (lineInfo1.getServiceInfo()!=null && null != lineInfo1.getServiceInfo().getCart5GAddress()) {
                    Address cart5GAddress = lineInfo1.getServiceInfo().getCart5GAddress();
                    requestMap.put(CartConstants.ADDRESSLINE1, cart5GAddress.getAddressLine1());
                    requestMap.put(CartConstants.ADDRESSLINE2, cart5GAddress.getAddressLine2());
                    requestMap.put(CartConstants.CITY, cart5GAddress.getCity());
                    requestMap.put(CartConstants.STATE, cart5GAddress.getState());
                    requestMap.put(CartConstants.ZIPCODE, cart5GAddress.getZipCode());
                    requestMap.put(CartConstants.LATITUDE, cart5GAddress.getLatitude());
                    requestMap.put(CartConstants.LONGITUDE, cart5GAddress.getLongitude());
                    try{
                        if (null != cart5GAddress.getFloor())
                            requestMap.put(CartConstants.FLOOR_NUMBER, cart5GAddress.getFloor().toString());
                    }
                    catch (Exception e){
                        logger.info("Error in setting floor number");
                    }
                    requestMap.put(CartConstants.BUILDING_ID, cart5GAddress.getBuildingId());
                }
            });
            redisHelper3.upsertCRMDataIntoRedisAsString(requestMap);
        }
	}
	
	public static void formatOrderDetailsView(CXPOrderDetailsView orderDetailsView, CXPOrderDetails cxpOrderDetails1) {
		orderDetailsView.setDueTodayAmount(String.valueOf(cxpOrderDetails1.getTotalDueToday()));
        orderDetailsView.setLocationCode(cxpOrderDetails1.getLocationCode());
        orderDetailsView.setTotalShippingCost(String.valueOf(cxpOrderDetails1.getTotalShippingCost()));
        orderDetailsView.setTotalDiscountedShippingCost(String.valueOf(cxpOrderDetails1.getTotalDiscountedShippingCost()));
        orderDetailsView.setOrderType(cxpOrderDetails1.getOrderType());
        if (null != cxpOrderDetails1 && null != cxpOrderDetails1.getCartTotalDiscounts()) {
            orderDetailsView.setCartTotalDiscounts(cxpOrderDetails1.getCartTotalDiscounts());
        }
        if (null != cxpOrderDetails1.getOrderList() && !cxpOrderDetails1.getOrderList().isEmpty()) {
            Optional<OrderList> orderLst = cxpOrderDetails1.getOrderList().stream().filter(orderList -> (homeIntendTypeValues.contains(orderList.getOrderActivityType()) || "ACC".equalsIgnoreCase(orderList.getOrderActivityType()))).findFirst();
            if (orderLst.isPresent()) {
                orderDetailsView.setOrderActivityType(orderLst.get().getOrderActivityType());
                orderDetailsView.setOrderNumber(String.valueOf(orderLst.get().getOrderNumber()));
            }
        }
	}
	
	public void formatResponse(SelectedFeaturesList selectedFeaturesList, int featuresCount, List<String> promoList, CXPLineInfo lineInfo1, GetCartDetailsUIResponse response) {
        if (null != selectedFeaturesList && featuresCount > 1 && promoList != null && promoList.size() > 0) {
            VisFeature visFeature = selectedFeaturesList.getVisFeature().stream().filter(Objects::nonNull).filter(visfeature ->
                    CartConstants.ADD_IND.equalsIgnoreCase(visfeature.getAddDeleteInd()) && CartConstants.USER.equalsIgnoreCase(visfeature.getSource())
                            && "SPO".equalsIgnoreCase(visfeature.getType()) && CartConstants.YES.equalsIgnoreCase(visfeature.getCustomerSelected())
                            && visfeature.getCategoryCodes().stream().anyMatch(code -> promoList.contains(code))).findFirst().orElse(null);
            SelectedVisFeature selectedVisFeature = new SelectedVisFeature();
            if (visFeature != null) {
                selectedVisFeature.setVisFeatureCode(visFeature.getVisFeatureCode());
                selectedVisFeature.setFeatureDesc(visFeature.getFeatureDesc());
                selectedVisFeature.setCategoryCodes(visFeature.getCategoryCodes());
            } else {
                selectedVisFeature.setFeatureDesc(lineInfo1.getServiceInfo().getSelectedPromoBundle());
            }
            response.setSelectedVisFeature(selectedVisFeature);
        }
	}
	
	public void formatDueMonthlyList(String lineActivityType,CXPOrderDetails cxpOrderDetails1,CXPLineDetailsVO lineDetails, List<CXPDueItemsList> dueMonthlyList, CXPLineInfo lineInfo1) {
		if (null != lineDetails && null != lineDetails.getAcctMcsSubscription()) {
            lineDetails.getAcctMcsSubscription().stream().filter(Objects::nonNull).forEach(mcsSubscription -> {
                CXPDueItemsList dueMonthlySubscriptionItems = new CXPDueItemsList();
                dueMonthlySubscriptionItems.setName(mcsSubscription.getName());
                dueMonthlySubscriptionItems.setItemType(CartConstants.ITEMTYPE_SUBSCRIPTION);
                dueMonthlySubscriptionItems.setProductId(mcsSubscription.getItemId());
                dueMonthlySubscriptionItems.setActualAmount(String.valueOf(mcsSubscription.getPrice()));
                dueMonthlySubscriptionItems.setTotalAmountWithDiscount(String.valueOf(mcsSubscription.getPrice()));
                dueMonthlySubscriptionItems.setPricePlanId(mcsSubscription.getPricePlanId());
                dueMonthlyList.add(dueMonthlySubscriptionItems);
            });
        }
        // protection items
        List<String> itemTypes = new ArrayList<>();
        List<String> dueMonthlyProductIds = new ArrayList<>();
        for(CXPDueItemsList dueMonthlyList1:  dueMonthlyList) {
            itemTypes.add(dueMonthlyList1.getItemType());
            dueMonthlyProductIds.add(dueMonthlyList1.getProductId());
        }
        if (null != lineInfo1.getServiceInfo().getSelectedFeaturesList() && lineInfo1.getServiceInfo().getSelectedFeaturesList().getFeaturesCount() > 1) {
            lineInfo1.getServiceInfo().getSelectedFeaturesList().getVisFeature().stream().filter(Objects::nonNull).filter(visFeature ->
                    "A".equalsIgnoreCase(visFeature.getAddDeleteInd()) && "User".equalsIgnoreCase(visFeature.getSource())
                            && visFeature.getCategoryCodes().stream().anyMatch(str -> str.equalsIgnoreCase("VZHP"))).findFirst().ifPresent(visFeature -> {
                if(!itemTypes.contains(CartConstants.ITEMTYPE_PROTECTION)
                        && null != visFeature.getVisFeatureCode()
                        &&  !dueMonthlyProductIds.contains(visFeature.getVisFeatureCode())) {
                    CXPDueItemsList protectionItem = new CXPDueItemsList();
                    protectionItem.setItemType(CartConstants.ITEMTYPE_PROTECTION);
                    protectionItem.setProductId(visFeature.getVisFeatureCode());
                    protectionItem.setActualAmount(visFeature.getFeaturePrice());
                    protectionItem.setName(visFeature.getFeatureDesc());
                    if (visFeature.getFeatureDiscounts() != null && visFeature.getFeatureDiscounts().size() < 1) {
                        protectionItem.setTotalAmountWithDiscount(visFeature.getFeaturePrice()); // when there is no discount
                    }
                    dueMonthlyList.add(protectionItem);
                }
            });
        }
        // WHWPlus items
        if (lineInfo1.getServiceInfo() != null && lineInfo1.getServiceInfo().getSelectedFeaturesList() != null && lineInfo1.getServiceInfo().getSelectedFeaturesList().getFeaturesCount() > 1) {
                lineInfo1.getServiceInfo().getSelectedFeaturesList().getVisFeature().stream().filter(Objects::nonNull).filter(visFeature ->
                        "A".equalsIgnoreCase(visFeature.getAddDeleteInd()) && "User".equalsIgnoreCase(visFeature.getSource())
                                && visFeature.getCategoryCodes().stream().anyMatch(str -> str.equalsIgnoreCase(CartConstants.ITEMTYPE_WHWPLUS))).findFirst().ifPresent(visFeature -> {
                    CXPDueItemsList whwplusItem = new CXPDueItemsList();
                    whwplusItem.setItemType(CartConstants.ITEMTYPE_WHWPLUS);
                    whwplusItem.setProductId(visFeature.getVisFeatureCode());
                    whwplusItem.setActualAmount(visFeature.getFeaturePrice());
                    whwplusItem.setName(visFeature.getFeatureDesc());
                    if(visFeature.getQuantity() > 0){
                        whwplusItem.setQuantity(String.valueOf(visFeature.getQuantity()));
                    }
                    if(CartConstants.FEA.equalsIgnoreCase(lineActivityType) && CartConstants.FLOW_TYPE_WHW.equalsIgnoreCase(cxpOrderDetails1.getFlowType())){
                        whwplusItem.setQuantity(String.valueOf(commonHelper.getAccessoryQunatity(lineInfo1)));
                    }
                    if (visFeature.getFeatureDiscounts() != null && visFeature.getFeatureDiscounts().size() > 0) {
                        whwplusItem.setTotalAmountWithDiscount(visFeature.getFeatureDiscPrice()); // when there is discount
                    }
                    if(visFeature.getAttributeNameValue()!=null && visFeature.getAttributeNameValue().getNameValue() != null) {
                        whwplusItem.setAdditionalAttributes(visFeature.getAttributeNameValue().getNameValue());
                    }
                    dueMonthlyList.add(whwplusItem);
                });
            }
        }
	
	public CXPDueItemsList formatDueTodayItems(CXPCartItem itemsInfo1,CXPLineInfo lineInfo1) {
        CXPDueItemsList dueTodayItems = new CXPDueItemsList();
        ImageUrlMap imageUrlMap=new ImageUrlMap();
        DecimalFormat df = new DecimalFormat("#.##");
        dueTodayItems.setItemType(itemsInfo1.getCartItemType());
        dueTodayItems.setName(itemsInfo1.getDescription());
        dueTodayItems.setSorId(itemsInfo1.getSorId());
        dueTodayItems.setGiftCard("GIF".equalsIgnoreCase(itemsInfo1.getProdCode2()) && "CRD".equalsIgnoreCase(itemsInfo1.getProdCode1()));
        if(itemsInfo1.getImageUrlMap()!=null && itemsInfo1.getImageUrlMap().getMiniImage()!=null) {
            imageUrlMap.setMiniImage(itemsInfo1.getImageUrlMap().getMiniImage());
        }
        if(itemsInfo1.getImageUrlMap()!=null && itemsInfo1.getImageUrlMap().getMediumImage()!=null) {
            imageUrlMap.setMediumImage(itemsInfo1.getImageUrlMap().getMediumImage());
        }
        if(itemsInfo1.getImageUrlMap()!=null && itemsInfo1.getImageUrlMap().getThumbImage()!=null) {
            imageUrlMap.setThumbImage(itemsInfo1.getImageUrlMap().getThumbImage());
        }
        if(itemsInfo1.getImageUrlMap()!=null && itemsInfo1.getImageUrlMap().getLargeImage()!=null) {
            imageUrlMap.setLargeImage(itemsInfo1.getImageUrlMap().getLargeImage());
        }
        if(itemsInfo1.getImageUrlMap()!=null && itemsInfo1.getImageUrlMap().getDefaultImage()!=null) {
            imageUrlMap.setDefaultImage(itemsInfo1.getImageUrlMap().getDefaultImage());
        }
        if(imageUrlMap!=null) {
            dueTodayItems.setImageUrlMap(imageUrlMap);
        }
        dueTodayItems.setProductId(itemsInfo1.getProductId());
        dueTodayItems.setBundleProductId(itemsInfo1.getBundleProductId());
        dueTodayItems.setDiscountApplied(String.valueOf(itemsInfo1.getDiscountAmount()));
        dueTodayItems.setQuantity(String.valueOf(itemsInfo1.getQty()));
        dueTodayItems.setActualAmount(df.format((itemsInfo1.getItemNrpPrice()) * (itemsInfo1.getQty())));
        AtomicReference<Double> discountAmount = new AtomicReference<>(0.0);
        if(null != itemsInfo1.getSedOfferList() && null != itemsInfo1.getSedOfferList().getSedOffer() && itemsInfo1.getSedOfferList().getSedOffer().size() >0){
            itemsInfo1.getSedOfferList().getSedOffer().stream().filter(Objects::nonNull).findFirst().ifPresent(posCartSEDOfferType -> {
                if(null != posCartSEDOfferType.getDiscAmt())
                    discountAmount.set(Double.parseDouble(posCartSEDOfferType.getDiscAmt()));
                dueTodayItems.setDiscountApplied(posCartSEDOfferType.getDiscAmt());
            });
        }
        Double calc = ((itemsInfo1.getItemNrpPrice()) * (itemsInfo1.getQty())) - discountAmount.get();
        String price = df.format(calc);
        dueTodayItems.setTotalAmountWithDiscount(price);
        // install type will be only for DEVICE(Router) item
        dueTodayItems.setTaxAmount(String.valueOf(itemsInfo1.getTaxAmount()));
        if (CartConstants.DEVICE.equalsIgnoreCase(itemsInfo1.getCartItemType())) {
            dueTodayItems.setLineNumber(lineInfo1.getLineNumber());
        }
        return dueTodayItems;
	}
	
	public void formatGetCartDetailsUIResponse(GetCartDetailsRequest request, List<CXPDueTaxesList> dueMonthlyTaxes, List<CXPShippingVO> shippingDetails, List<CXPDueItemsList> dueTodayList, List<CXPDueItemsList> dueMonthlyList, List<CXPDueTaxesList> dueTodayTaxes, List<CXPPaymentsVO> payments, AMRegisterationDetails amRegisterationDetails , boolean isNSEFlow, CXPOrderDetailsView orderDetailsView, List<String> hiddenPromoList, GetCartDetailsUIResponse response) {
		if (request.getData().isOrderPlaced() && isNSEFlow && StringUtils.isNoneBlank(orderDetailsView.getOrderNumber(), orderDetailsView.getLocationCode())) {
            amRegisterationDetails.setOrderNumber(security5GUtil.RPSAES128CBCEncrypt(orderDetailsView.getOrderNumber()));
            amRegisterationDetails.setLocationCode(security5GUtil.RPSAES128CBCEncrypt(orderDetailsView.getLocationCode()));
        }
        if(!hiddenPromoList.isEmpty())
            orderDetailsView.setHiddenPromos(hiddenPromoList);
        orderDetailsView.setIsWillow(isWillowIds(dueMonthlyList));
        response.setDueTodayList(dueTodayList);
        response.setDueMonthlyList(dueMonthlyList);
        response.setPayments(payments);
        response.setDueTodayTaxes(dueTodayTaxes);
        response.setDueMonthlyTaxes(dueMonthlyTaxes);
        response.setShippingDetails(shippingDetails);
        response.setOrderDetailsView(orderDetailsView);
        response.setRegistrationDetails(amRegisterationDetails);
	}
	
	public CartRedisData formatCartRedisData(CartRedisData rr, ClearAndContinueContext context) {
		String caseId = context.getCaseId();
        String cartId = context.getCartInfo().getCartId();
        if(StringUtilities.isEmptyOrNull(context.getCustomerInfo().getExistingCase())) {
            rr.setExistingCase(CartConstants.FALSE);
        }else {
            rr.setExistingCase(context.getCustomerInfo().getExistingCase());
        }
        rr.setCartId(cartId);
        rr.setCaseId(caseId);
        return rr;
	}
	
	public void formatClearAndContinueRequest(ClearAndContinueUIRequest request, CartRedisData data) {
		if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
            request.getCartInfo().setCaseId(data.getCaseId());
        if (StringUtilities.isNotEmptyOrNull(data.getMtn()))
            request.getCartInfo().setCartCreator(data.getMtn());
        if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
                && StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessingMTN()))
            request.getCartInfo().setProcessingMTN(data.getProcessingMTN());
        if (StringUtilities.isNotEmptyOrNull(data.getCartCreator())
                && StringUtilities.isEmptyOrNull(request.getCartInfo().getCartCreator()))
            request.getCartInfo().setCartCreator(data.getCartCreator());
        if (StringUtilities.isEmptyOrNull(request.getCartInfo().getLocationCode())
                && StringUtilities.isNotEmptyOrNull(data.getLocationCode()))
            request.getCartInfo().setLocationCode(data.getLocationCode());
        if (StringUtilities.isEmptyOrNull(request.getCartInfo().getAmRole())
                && StringUtilities.isNotEmptyOrNull(data.getVzwRoles()))
            request.getCartInfo().setAmRole(data.getVzwRoles());

	}
	
	public Mono<ClearAndContinueUIResponse> formatClearAndContinueUIResponse(ClearAndContinueUIResponse cscResp) {
		if (null != cscResp && null != cscResp.getServiceHeader() && null == cscResp.getServiceBody()) {
            List<CartError> errorList = new ArrayList<>();
            if (StringUtilities.isNotEmptyOrNull(cscResp.getServiceHeader().getStatusCode())
                    && "99".equalsIgnoreCase(cscResp.getServiceHeader().getStatusCode())) {
            	String message = Optional.ofNullable(cscResp.getServiceHeader().getStatusMsg()).orElse("");
                CartError error = new CartError();
                error.setMessage(message);
                error.setNamespace(CartConstants.SOE_CART_SERVICE);
                error.setCode(CartConstants.INTERNAL_SERVER_ERROR);
                if (CollectionUtilities.isNotEmptyOrNull(cscResp.getErrors()))
                    cscResp.getErrors().add(error);
                else
                    errorList.add(error);
                redisHelper.deleteCartIdAndCaseIdAndExistingCaseFromRedis();
            }
            if (CollectionUtilities.isEmptyOrNull(cscResp.getErrors())) {
                cscResp.setErrors(errorList);
            }
        } else {
            Optional.ofNullable(cscResp).map(ClearAndContinueUIResponse::getServiceBody)
                    .map(ClearAndContinueServiceBody::getServiceResponse)
                    .map(ClearAndContinueServiceResponse::getContext).ifPresent(context -> {
                String caseId = Optional.ofNullable(context.getCaseId()).orElse("");
                Boolean flag = false;
                List<CartError> errorList = new ArrayList<>();
                if (StringUtilities.isEmptyOrNull(caseId)) {
                    settingErrorData(flag, cscResp, errorList);//resolving duplication
                }
                if (null != context.getCartInfo()) {
                    String cartId = Optional.ofNullable(context.getCartInfo().getCartId()).orElse("");
                    if (StringUtilities.isEmptyOrNull(cartId)) {
                        settingErrorData(flag, cscResp, errorList);//resolving duplication
                    }
                }
                if (CollectionUtilities.isEmptyOrNull(cscResp.getErrors()) && flag) {
                    cscResp.setErrors(errorList);
                }
            });
        }
        return Mono.just(cscResp);
	}
	
	public Mono<ResponseEntity<AddZipcodeRedisData>> formatZipcodeRedisData(AddZipCodeUIRequest request, AddZipcodeRedisData rr) {
		if (StringUtilities.isNotEmptyOrNull(request.getZipCode())) {
			rr.setZipCode(request.getZipCode());
			rr.setStatus(CartConstants.STATUS_SUCCESS);
		}
		Mono<Boolean> rpsFlowRedisData = redisHelper2.upsertBBPFlowZipCodeDataIntoRedis(rr);
		return rpsFlowRedisData.flatMap(data -> {
			if (data) {
				AddZipcodeRedisData res = validator.convertObjectToString(rr);
				return Mono.just(ResponseEntity.status(HttpStatus.OK).body(res));
			} else {
				return Mono
						.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new AddZipcodeRedisData()));
			}
		});
	}
	
	public void formatRedisData(CartRedisData rr, AddDeviceUIResponse addDevicePegaResponse, AddDeviceUIRequest addDeviceUIRequest) {
		rr.setCaseId(addDevicePegaResponse.getServiceBody().getServiceResponse().getContext()
				.getCaseId());
		if (addDevicePegaResponse.getServiceBody().getServiceResponse().getContext()
				.getCartInfo() != null) {
			rr.setCartId(addDevicePegaResponse.getServiceBody().getServiceResponse()
					.getContext().getCartInfo().getCartId());
		}
		if (addDevicePegaResponse.getServiceBody().getServiceResponse().getContext()
				.getCartInfo() != null) {
			Line[] respLines = addDevicePegaResponse.getServiceBody().getServiceResponse()
					.getContext().getCartInfo().getLines();

			if (null != respLines && respLines.length > 0
					&& StringUtilities.isNotEmptyOrNull(respLines[0].getMtn())) {
				rr.setProcessingMTN(respLines[0].getMtn());
			}
		}
		rr.setIntendType(addDeviceUIRequest.getCartInfo().getIntendType());
		rr.setLines(addDeviceUIRequest.getData().getLines());
		rr.setDeviceCartInfo(addDeviceUIRequest.getCartInfo());
	}

    //resolving duplication
    private void settingErrorData(Boolean flag,ClearAndContinueUIResponse cscResp, List<CartError>  errorList) {
        CartError error = new CartError();
        error.setMessage("PEGA did not return cartId");
        error.setNamespace(CartConstants.SOE_CART_SERVICE);
        error.setCode(CartConstants.INTERNAL_SERVER_ERROR);
        if (CollectionUtilities.isNotEmptyOrNull(cscResp.getErrors()))
            cscResp.getErrors().add(error);
        else
            errorList.add(error);
        redisHelper.deleteCartIdAndCaseIdAndExistingCaseFromRedis().subscribeOn(Schedulers.parallel());
    }
    /**
     *
     * @param dueMonthlyList
     * @return
     */
    public boolean isWillowIds(List<CXPDueItemsList> dueMonthlyList) {
        if (!dueMonthlyList.isEmpty()) {
            return dueMonthlyList.stream()
                    .anyMatch(prd ->"PLAN".
                            equalsIgnoreCase(prd.getItemType())
                            &&!willowIds.isEmpty()
                            && willowIds.contains(prd.getProductId()));
        }
        return false;
    }

    public void setDefaultCreditHoldContentForFailedOrderStatus(OrderDetail orderDetail, List<AEMCreditExceptionResponse> aemRespList, String reasonCode){
        if(CartConstants.ORDER_STATUS_FAILED.equalsIgnoreCase(orderDetail.getOrderStatus()) && null == orderDetail.getCreditHoldContent()){
            logger.info("Order status failed reasonCode missing in credit Hold Content - {} and replacing with "+CartConstants.DEFAULT_CREDIT_HOLD_REASON_CODE,reasonCode);
            aemRespList.stream().filter(Objects::nonNull)
                    .filter(aemResp -> null != aemResp.getReasonCode())
                    .filter(aemResp -> ArrayUtils.contains(aemResp.getReasonCode(), CartConstants.DEFAULT_CREDIT_HOLD_REASON_CODE))
                    .findFirst()
                    .ifPresent(orderDetail::setCreditHoldContent);
        }
    }

    public boolean isPegaRespValid(AddPlanUIResponse bpmRes) {
        return (bpmRes != null && bpmRes.getServiceBody() != null && bpmRes.getServiceBody().getServiceResponse() != null
                && bpmRes.getServiceBody().getServiceResponse().getContext() != null && bpmRes.getServiceBody().getServiceResponse().getContext().getCartInfo() != null);
    }

    public static String removeHostPrefix(String hostname) {
        return Optional.ofNullable(hostname).map(host->{
           int hostPrefix = host.indexOf(".");
           return (hostPrefix!=-1)?hostname.substring(hostPrefix):host;
        }).orElse("");
    }

    public static String validateAndExtractURL(List<String> xHost) {
        String url = "";
        String regex = CartConstants.HOST_NAMES_REGEX;
        Pattern verizonPattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
        if (xHost != null && !xHost.isEmpty()) {
            Matcher verizonMatcher = verizonPattern.matcher(Objects.requireNonNull(xHost).toString()
                    .replace("[", "").replace("]", "").replace("\"", ""));
            if (verizonMatcher.find()) {
                url = xHost.toString().replace("[", "")
                        .replace("]", "").replace("\"", "");
            } else {
                throw new IllegalArgumentException();
            }
        }
        return url;
    }

    public Map<String, String> getOpenIgTokens() {
        Map<String, String> returnMap = new HashMap<>();
        try {
            String sso_jwt = RequestAccessContext.getRequestHeader("sso_jwt");
            SsoJwtDTO decodedJwt = tokenProcessor.decodeSSOJWTToken(sso_jwt);
            returnMap.put(CartConstants.ACCOUNT_NUMBER, decodedJwt.getVzwAccountNumber());
            returnMap.put(CartConstants.LOOKUP_MTN, decodedJwt.getMobile());
            // Read required information from sso jwt
        } catch (Exception e) {
            logger.error("Unable to get sso_jwt token ", e);
        }
        return returnMap;
    }
}