package onevz.soe.cart.constants;

public class TradeinConstants {
    /**
     * The constant TRADEIN_SESSION_SUBKEY.
     */

    public static final String TRADEIN_SESSION_SUBKEY = "TRADEIN_SESSION";
    public static final String TRADEIN_SOE_SERVICE = "TradeinService";
    public static final String VALIDATION_ERROR = "REQUEST VALIDATION ERROR";
    public static final String ERR_GENERIC_MSG = "Looks like something went wrong. Please try again later.";

    public static final String ERR_GENERIC_ID = "1024";
    public static final String COMPLETE = "Complete";
    public static final String APPRAISED = "Appraised";

}
