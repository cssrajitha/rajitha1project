package onevz.soe.cart.helper;

import onevz.cxp.feature.util.FeatureFlag;
import onevz.soe.cart.bpm.helper.CartServiceConfiguratorBpmHelper;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.constants.ConfiguratorConstants;
import onevz.soe.cart.constants.FeatureFlagConstants;
import onevz.soe.cart.controller.advice.CartServiceExceptionHandler;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.model.configurator.add.AddAllConfiguratorContext;
import onevz.soe.cart.model.configurator.add.AddAllConfiguratorServiceBody;
import onevz.soe.cart.model.configurator.add.AddAllConfiguratorServiceResponse;
import onevz.soe.cart.ui.requests.AddAllConfiguratorUIRequest;
import onevz.soe.cart.ui.responses.AddAllConfiguratorUIResponse;
import onevz.soe.cart.util.CartConfiguratorPegaResponseErrorsUtil;
import onevz.soe.cart.util.CartPegaResponseErrorsUtil;
import onevz.soe.cart.util.CartUtil;
import onevz.soe.exception.SOEErrorHolder;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.*;

@Service
public class CartConfiguratorHelper {
    private static final Logger logger = LoggerFactory.getLogger(CartConfiguratorHelper.class);
    @Autowired
    CartServiceConfiguratorBpmHelper bpmHelper;

    @Autowired
    private FeatureFlag featureFlag;

    @Autowired
    private CartServiceCxpHelper cxpHelper;
    @Autowired
    RedisHelper redisHelper;
    @Autowired
    CradleHelper cradleHelper;
    @Autowired
    CartServiceExceptionHandler exHandler;

    public Mono<AddAllConfiguratorUIResponse> addToCartForConfigurator(AddAllConfiguratorUIRequest request) {
        Mono<Boolean> isCartOperationWithUUIDEnabledMono = featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,FeatureFlagConstants.STREAM_LINE_NEXTG_CONFIG_P,FeatureFlagConstants.NGD_CONFIG_TAGGING,false);
        return bpmHelper.addAllCartConfigurator(request).zipWith(isCartOperationWithUUIDEnabledMono)
                .map(tuple2 -> {
                    logger.info("addToCartForConfigurator tuple2.getT2 {}",tuple2.getT2());
                    if (Boolean.TRUE.equals(tuple2.getT2()) && CollectionUtilities.isEmptyOrNull(
                            tuple2.getT1().getErrors())) {
                        if (request.getData().getLines()
                                .size() > 0) {
                            String selectedPromoId = request.getData().getLines().get(0).getSelectedPromoId();
                            String selectedPromoType = request.getData().getLines().get(0).getSelectedPromoType();
                            String flowType = evaluteFlowType(request.getCartInfo().getIntendType());
                            String promosAppliedVal = "none";
                            String selectedSedOfferId = request.getData().getLines().get(0).getSelectedSedOfferId();
                            if (StringUtilities
                                    .isNotEmptyOrNull(
                                            selectedPromoId)
                                    && StringUtilities
                                    .isNotEmptyOrNull(
                                            selectedPromoType)) {
                                StringBuilder selectedPromoBuilder = new StringBuilder(selectedPromoType + "-" + selectedPromoId) ;
                                Optional.ofNullable(flowType).filter(StringUtilities::isNotEmptyOrNull).ifPresent( flowTypeStr -> selectedPromoBuilder.append("-"+flowTypeStr));
                                Optional.ofNullable(selectedSedOfferId).filter(StringUtilities::isNotEmptyOrNull).ifPresent( selectedSedStr -> selectedPromoBuilder.append("-"+selectedSedStr));
                                promosAppliedVal = selectedPromoBuilder.toString();
                            }
                            cxpHelper.updateDLData(null,
                                    null,
                                    "promosApplied",
                                    promosAppliedVal, null, null);
                        }
                    }
                    return tuple2.getT1();
                }).zipWith(cradleHelper.isInFlowCart(request.getHttpRequest(),request.getHttpResponse()))
                .map(tuples -> setInflowCartInAddToCartConfiguratorResponse(tuples.getT1(),tuples.getT2()))
                .doOnError(e -> logger.error(ConfiguratorConstants.ADD_ALL_CONFIGURATOR_METHOD_EXCEPTION, e)).onErrorResume(SOEHTTPException.class, e -> {
            if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))) {

                logger.error(ConfiguratorConstants.ADD_ALL_CONFIGURATOR_METHOD_EXCEPTION, e.getErrorCode());
                Mono<ResponseEntity<SOEErrorHolder>> errorHolder = exHandler.fetchAEMMessage(e).doOnError(e1 -> logger.error(ConfiguratorConstants.ADD_ALL_CONFIGURATOR_METHOD_EXCEPTION, e1)).onErrorResume(SOEHTTPException.class, CartPegaResponseErrorsUtil::handleAEMError);
                return errorHolder.flatMap(eh -> {
                    SOEErrorHolder hold = eh.getBody();
                    AddAllConfiguratorUIResponse resp = CartConfiguratorPegaResponseErrorsUtil.handleCommonError(hold);
                    return Mono.just(resp);
                });
            }
            return Mono.just(CartConfiguratorPegaResponseErrorsUtil.handleCommonError(e.getErrorHolder()));
        });
    }

    private AddAllConfiguratorUIResponse setInflowCartInAddToCartConfiguratorResponse(AddAllConfiguratorUIResponse response, Boolean inFlowCart) {
        Optional.of(response).map(AddAllConfiguratorUIResponse::getServiceBody).map(AddAllConfiguratorServiceBody::getServiceResponse).map(AddAllConfiguratorServiceResponse::getContext).map(AddAllConfiguratorContext::getCartInfo)
                .ifPresent(cartServiceConfiguratorCartInfo -> cartServiceConfiguratorCartInfo.setInFlowCart(inFlowCart));
        return response;
    }


    private String evaluteFlowType(String lineInfoFlowType) {
        if(StringUtilities.isNotEmptyOrNull(lineInfoFlowType)){
            return switch (lineInfoFlowType) {
                case CartConstants.BYOD_LINE_ACTIVITY, CartConstants.EUP_BYOD_LINE_ACTIVITY -> "ESO";
                case CartConstants.NSE_BYOD_LINE_ACTIVITY -> "NSO";
                default -> lineInfoFlowType;
            };
        }
        return "";
    }
}


