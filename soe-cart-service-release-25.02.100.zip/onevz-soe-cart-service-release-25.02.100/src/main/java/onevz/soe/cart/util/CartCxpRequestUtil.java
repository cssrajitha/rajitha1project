package onevz.soe.cart.util;

import java.util.*;

import onevz.soe.cart.model.common.Address;
import onevz.soe.cart.model.customerConsent.UpdateConsentData;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.checkDfillInventory.CheckDfillInventoryData;
import onevz.soe.cart.model.deviceSimValidation.Esim;
import onevz.soe.cart.model.deviceSimValidation.Psim;
import onevz.soe.cart.model.giftPurchase.GiftPurchaseData;
import onevz.soe.cart.model.initiateDeviceSimActivation.IntiateDeviceSimActivationUIRequest;
import onevz.soe.cart.model.initiateESimActivation.IntiateESimActivationUIRequest;
import onevz.soe.cart.model.macAddress.MacAddressData;
import onevz.soe.cart.model.myOffer.MyOfferLine;
import onevz.soe.cart.model.myOffer.Offer;
import onevz.soe.cart.model.myOffers.Meta;
import onevz.soe.cart.model.myOffers.MyOffersData;
import onevz.soe.cart.model.myOffers.MyOffersLine;
import onevz.soe.cart.model.myOffers.Offers;
import onevz.soe.cart.model.myOffers.RTDOfferDetails;
import onevz.soe.cart.model.myOffers.SelectedOffer;
import onevz.soe.cart.model.myOffers.ValidateOffersData;
import onevz.soe.cart.model.nbs.NbsData;
import onevz.soe.cart.model.numberlinkE911Address.AddressRequest;
import onevz.soe.cart.model.paperlessBilling.PaperlessBillingData;
import onevz.soe.cart.model.updatePurchaseOrder.UpdatePurchaseOrderData;
import onevz.soe.cart.model.updatePurchaseOrder.UpdatePurchaseOrderNumber;
import onevz.soe.cart.model.updateTradeInOffer.UpdateTradeInOfferData;
import onevz.soe.cart.model.updateTradeinType.UpdateTradeinTypeData;
import onevz.soe.cart.model.updateUserInfo.UpdateUserInfoData;
import onevz.soe.cart.model.updateVzccNBXInfo.UpdateVzccNBXInfoData;
import onevz.soe.cart.model.vzccAppStatus.VZCCAppStatusData;
import onevz.soe.cart.requests.*;
import onevz.soe.cart.responses.MyOfferETRRedisData;
import onevz.soe.cart.responses.RTDRedisData;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.cart.constants.CartConstants;

/**
 * Request Format Helper class.
 */
public class CartCxpRequestUtil {
	
	@Value("${smartImeiTypeAheadNoOfRecords:150}")
	private static int smartImeiTypeAheadNoOfRecords;

	private CartCxpRequestUtil() {
	}

	/**
	 *
	 * @param uiRequest
	 * @param cxpRequest
	 * @return UpdateUserInfoCXPRequest
	 */
	public static UpdateUserInfoCXPRequest formatUpdateUserInfoRequest(UpdateUserInfoUIRequest uiRequest,
			UpdateUserInfoCXPRequest cxpRequest) {
		cxpRequest.setMeta(new HashMap<>());
		cxpRequest.getMeta().put(CartConstants.CLIENT, CartConstants.CXP);
		cxpRequest.setData(new UpdateUserInfoData());
		UpdateUserInfoData data = new UpdateUserInfoData();
		data.setAction(CartConstants.UPDATE);
		data.setIntendType(uiRequest.getIntendType());
		data.setItemType("USERINFO");
		data.setCartId(uiRequest.getCartId());
		data.setLines(uiRequest.getLines());
		cxpRequest.setData(data);
		return cxpRequest;
	}

	/**
	 *
	 * @param uiRequest
	 * @param cxpRequest
	 * @return PaperlessBillingCXPRequest
	 */
	public static PaperlessBillingCXPRequest formatPaperlessBillingRequest(PaperlessBillingUIRequest uiRequest,
			PaperlessBillingCXPRequest cxpRequest) {
		cxpRequest.setMeta(new HashMap<>());
		cxpRequest.getMeta().put(CartConstants.CLIENT, CartConstants.CXP);
		cxpRequest.setData(new PaperlessBillingData());
		PaperlessBillingData data = new PaperlessBillingData();
		data.setAction(CartConstants.UPDATE);
		data.setIntendType(uiRequest.getIntendType());
		data.setItemType("PAPERLESS");
		data.setCartId(uiRequest.getCartId());
		data.setPaperlessbilling(uiRequest.getPaperlessbilling());
		data.setLines(uiRequest.getLines());
		cxpRequest.setData(data);
		return cxpRequest;
	}

	/**
	 *
	 * @param uiRequest
	 * @param cxpRequest
	 * @return UpdateTradeinTypeCXPRequest
	 */
	public static UpdateTradeinTypeCXPRequest formatUpdateTradeinTypeRequest(UpdateTradeinTypeUIRequest uiRequest,
			UpdateTradeinTypeCXPRequest cxpRequest) {
		cxpRequest.setMeta(new HashMap<>());
		cxpRequest.getMeta().put(CartConstants.CLIENT, CartConstants.CXP);
		cxpRequest.setData(new UpdateTradeinTypeData());
		UpdateTradeinTypeData data = new UpdateTradeinTypeData();
		data.setAction(CartConstants.UPDATE);
		data.setTradeInType(uiRequest.getTradeInType());
		data.setIntendType(uiRequest.getIntendType());
		data.setItemType("TRADEINTYPE");
		data.setCartId(uiRequest.getCartId());
		data.setLines(uiRequest.getLines());
		// VZWYZDD-1542
		if (StringUtilities.isNotEmptyOrNull(uiRequest.getTradeInShippingType()))
			data.setTradeInShippingType(uiRequest.getTradeInShippingType());
		if (StringUtilities.isNotEmptyOrNull(uiRequest.getPreferredStoreAddress()))
			data.setPreferredStoreAddress(uiRequest.getPreferredStoreAddress());
		if (StringUtilities.isNotEmptyOrNull(uiRequest.getPreferredStoreId()))
			data.setPreferredStoreId(uiRequest.getPreferredStoreId());
		cxpRequest.setData(data);
		return cxpRequest;
	}

	/**
	 *
	 * @param uiRequest
	 * @param cxpRequest
	 * @return MacAddressCXPRequest
	 */
	public static MacAddressCXPRequest formatMacAddressRequest(MacAddressUIRequest uiRequest,
			MacAddressCXPRequest cxpRequest) {
		cxpRequest.setMeta(new HashMap<>());
		cxpRequest.getMeta().put(CartConstants.CLIENT, CartConstants.CXP);
		cxpRequest.setData(new MacAddressData());
		MacAddressData data = new MacAddressData();
		data.setItemType("MACADDRESS");
		data.setAction(CartConstants.UPDATE);
		data.setCartId(uiRequest.getCartId());
		data.setIntendType(uiRequest.getIntendType());
		data.setLines(uiRequest.getData().getLines());
		cxpRequest.setData(data);
		return cxpRequest;
	}

	/**
	 * 
	 * @param uiRequest
	 * @param cxpRequest
	 * @return
	 */
	public static UpdatePurchaseOrderCXPRequest formatUpdatePurchaseOrderRequest(UpdatePurchaseOrderUIRequest uiRequest,
			UpdatePurchaseOrderCXPRequest cxpRequest) {
		cxpRequest.setMeta(new HashMap<>());
		cxpRequest.getMeta().put(CartConstants.CLIENT, CartConstants.CXP);
		cxpRequest.setData(new UpdatePurchaseOrderData());
		UpdatePurchaseOrderData data = new UpdatePurchaseOrderData();
		data.setItemType("PURCHASEORDERNUMBER");
		data.setAction(CartConstants.UPDATE);
		data.setCartId(uiRequest.getCartId());
		data.setIntendType(uiRequest.getIntendType());
		UpdatePurchaseOrderNumber updatePurchaseOrderNumber = new UpdatePurchaseOrderNumber();
		updatePurchaseOrderNumber.setPurchaseOrderNumber(uiRequest.getPurchaseOrderNumber());
		data.setUpdatePurchaseOrderNumber(updatePurchaseOrderNumber);
		cxpRequest.setData(data);
		return cxpRequest;
	}

	/**
	 *
	 * @param uiRequest
	 * @param cxpRequest
	 * @return cxpRequest
	 */
	public static GiftPurchaseCXPRequest formatGiftPurchaseRequest(GiftPurchaseUIRequest uiRequest,
			GiftPurchaseCXPRequest cxpRequest) {
		cxpRequest.setMeta(new HashMap<>());
		cxpRequest.getMeta().put(CartConstants.CLIENT, CartConstants.CXP);
		cxpRequest.setData(new GiftPurchaseData());
		GiftPurchaseData data = new GiftPurchaseData();
		data.setItemType("GIFTPURCHASE");
		data.setAction(CartConstants.UPDATE);
		data.setCartId(uiRequest.getCartId());
		data.setIntendType(uiRequest.getIntendType());
		data.setGiftPurchaseFlag(uiRequest.getGiftPurchaseFlag());
		cxpRequest.setData(data);
		return cxpRequest;
	}

	/**
	 *
	 * @param uiRequest
	 * @param cxpRequest
	 * @return cxpRequest
	 */
	public static CheckDfillInventoryCXPRequest formatCheckDfillInventoryRequest(CheckDfillInventoryUIRequest uiRequest,
			CheckDfillInventoryCXPRequest cxpRequest) {
		cxpRequest.setMeta(new HashMap<>());
		cxpRequest.getMeta().put(CartConstants.CLIENT, CartConstants.CXP);
		cxpRequest.setData(new CheckDfillInventoryData());
		CheckDfillInventoryData data = new CheckDfillInventoryData();
		data.setCartId(uiRequest.getCartId());
		data.setItemType("CHECK-DFILL-INVENTORY");
		if (StringUtilities.isNotEmptyOrNull(uiRequest.getIntendType()))
			data.setIntendType(uiRequest.getIntendType());
		else
			data.setIntendType("EUP");
		data.setAction("UPDATE");
		cxpRequest.setData(data);
		return cxpRequest;
	}

	/**
	 *
	 * @param uiRequest
	 * @param cxpRequest
	 * @return cxpRequest
	 */
	public static GetUpgradeReasonCodeCXPRequest formatGetUpgradeReasonCodesRequest(
			GetUpgradeReasonCodeUIRequest uiRequest, GetUpgradeReasonCodeCXPRequest cxpRequest) {
		cxpRequest.setMeta(new HashMap<>());
		if (uiRequest.getClient() != null)
			cxpRequest.getMeta().put(CartConstants.CLIENT, uiRequest.getClient());
		if (uiRequest.getUser() != null)
			cxpRequest.getMeta().put(CartConstants.USER, uiRequest.getUser());
		cxpRequest.setData(uiRequest.getData());
		return cxpRequest;
	}

	/**
	 * 
	 * @param applyOfferRequest
	 * @param myOfferData
	 * @return
	 */
	public static ValidateOffersRequest buildCXPValidateOfferRequest(ApplyOfferRequest applyOfferRequest,
			MyOfferETRRedisData myOfferData) {

		ValidateOffersRequest validateOffersRequest = new ValidateOffersRequest();
		Meta meta = new Meta();
		meta.setClient("CXP");
		validateOffersRequest.setMeta(meta);
		ValidateOffersData data = new ValidateOffersData();
		data.setCartId(applyOfferRequest.getCartInfo().getCartId());

		List<MyOfferLine> offerLines = myOfferData.getLines();
		List<SelectedOffer> selectedOffers = new ArrayList<>();
		for (MyOfferLine offerLine : offerLines) {
			if (offerLine.getOffers() != null) {
				List<Offers> offersList = new ArrayList<>();
				List<Offer> offers = offerLine.getOffers();
				for (Offer offer : offers) {
					if (StringUtilities.isNotEmptyOrNull(offer.getSku()) && offer.getSku().contains(",")) {
						List.of(offer.getSku().split(",")).stream().forEach(sku -> {
							offersList.add(applyOffer(offer, sku));
						});
					} else {
						offersList.add(applyOffer(offer, offer.getSku()));
					}
				}
				SelectedOffer selectedOffer = new SelectedOffer();
				selectedOffer.setOffers(offersList);
				selectedOffer.setMtn(offerLine.getMtn());
				selectedOffers.add(selectedOffer);
			}
		}
		data.setSelectedOffers(selectedOffers);
		validateOffersRequest.setData(data);
		return validateOffersRequest;
	}

	/**
	 *
	 * @param uiRequest
	 * @param cxpRequest
	 * @return VZCCAppStatusCXPRequest
	 */
	public static VZCCAppStatusCXPRequest formatVZCCAppStatusRequest(VZCCAppStatusUIRequest uiRequest,
			VZCCAppStatusCXPRequest cxpRequest) {
		cxpRequest.setMeta(new HashMap<>());
		cxpRequest.getMeta().put(CartConstants.CLIENT, CartConstants.CXP);
		cxpRequest.setData(new VZCCAppStatusData());
		VZCCAppStatusData data = new VZCCAppStatusData();
		data.setAction(CartConstants.UPDATE);
		if(CartConstants.NSE.equalsIgnoreCase(uiRequest.getIntentType())) {
			data.setIntendType(CartConstants.NSE);
		} else {
			data.setIntendType(CartConstants.EUP);
		}
		data.setItemType("VZCCSTATUS");
		data.setCartId(uiRequest.getCartId());
		setVzccFeedbackStatus(uiRequest);
		data.setVzccStatus(uiRequest.getVzccStatus());
		data.setCallingPage(uiRequest.getCallingPage());
		cxpRequest.setData(data);
		return cxpRequest;
	}

	private static void setVzccFeedbackStatus(VZCCAppStatusUIRequest uiRequest) {
		if(uiRequest.getVzccStatus()!=null && uiRequest.getVzccStatus().getFeedbackStatus()!=null) {
			String feedBackStatus = uiRequest.getVzccStatus().getFeedbackStatus();
			if ((feedBackStatus.equalsIgnoreCase(CartConstants.SE_APLICO) || feedBackStatus.equalsIgnoreCase(CartConstants.APPLIED))) {
				uiRequest.getVzccStatus().setFeedbackStatus(CartConstants.APPLIED);
			} else {
				uiRequest.getVzccStatus().setFeedbackStatus(CartConstants.DECLINED);
			}
		}
	}

	/**
	 * 
	 * @param rtdData
	 * @param channelId
	 * @return myOffersRequest
	 */
	public static MyOffersCXPRequest formMyOffersRequest(RTDRedisData rtdData, String channelId) {

		MyOffersCXPRequest myOffersRequest = new MyOffersCXPRequest();
		Map<String, String> meta = new HashMap<>();
		meta.put("client", channelId);
		myOffersRequest.setMeta(meta);
		MyOffersData data = new MyOffersData();
		if (StringUtilities.isNotEmptyOrNull(rtdData.getCartId()))
			data.setCartId(rtdData.getCartId());
		data.setItemType(CartConstants.MYOFFERS);
		data.setAction(CartConstants.UPDATE);
		if (StringUtilities.isNotEmptyOrNull(rtdData.getIntendType()))
			data.setIntendType(rtdData.getIntendType());
		else
			data.setIntendType(CartConstants.EUP);
		List<MyOffersLine> lineList = new ArrayList<>();

		if (StringUtilities.isNotEmptyOrNull(rtdData.getMtn())) {

			if (null != rtdData.getOffers() && null != rtdData.getOffers().get(rtdData.getMtn())) {
				List<RTDOfferDetails> offerDetails = rtdData.getOffers().get(rtdData.getMtn());
				for (RTDOfferDetails offerDetail : offerDetails) {
					MyOffersLine line = new MyOffersLine();
					if (StringUtilities.isNotEmptyOrNull(rtdData.getIntendType()))
						line.setLineActivityType(rtdData.getIntendType());
					line.setMtn(rtdData.getMtn());
					if (StringUtilities.isNotEmptyOrNull(offerDetail.getComplianceType()))
						line.setRestrictedProductType(offerDetail.getComplianceType());
					if (null != offerDetail.getComplianceSkus() && null != offerDetail.getComplianceSkus().get("Y"))
						line.setRestricted("Y");
					lineList.add(line);
				}
			}
		}
		data.setLines(lineList);
		myOffersRequest.setData(data);

		return myOffersRequest;
	}

	/**
	 *
	 * @param uiRequest
	 * @param cxpRequest
	 * @return UpdateUserInfoCXPRequest
	 */
	public static RPSE911AddressUpdateCXPRequest formatUpdateRPSE911AddressRequest(
			RPSE911AddressUpdateUIRequest uiRequest, RPSE911AddressUpdateCXPRequest cxpRequest) {
		RPSE911AddressData e911AddressData = new RPSE911AddressData();
		RPSE911AddressUpdateCXPData rpse911AddressUpdateCXPData = new RPSE911AddressUpdateCXPData();
		e911AddressData.setAddressLine1(uiRequest.getAddressLine1());
		e911AddressData.setAddressLine2(uiRequest.getAddressLine2());
		e911AddressData.setStreetNumber(uiRequest.getStreetNumber());
		e911AddressData.setStreetName(uiRequest.getStreetName());
		e911AddressData.setCityName(uiRequest.getCityName());
		e911AddressData.setCity(uiRequest.getCityName());
		e911AddressData.setState(uiRequest.getState());
		e911AddressData.setStreetType(uiRequest.getStreetType());
		e911AddressData.setStreetDirection(uiRequest.getStreetDirection());
		e911AddressData.setCountryCode(uiRequest.getCountryCode());
		e911AddressData.setApartmentNo(uiRequest.getApartmentNo());
		if( uiRequest.getChannelId().equalsIgnoreCase(CartConstants.CHANNEL_ID_NUMBERLINK) && StringUtilities.isNotEmptyOrNull(uiRequest.getDeviceId())) {
			e911AddressData.setDeviceId(uiRequest.getDeviceId());
			rpse911AddressUpdateCXPData.setFlowType(CartConstants.FLOW_TYPE_NUMBERLINK1);
		}
		rpse911AddressUpdateCXPData.setMtn(uiRequest.getMtn());
		e911AddressData.setZipCode(uiRequest.getZipCode());
		e911AddressData.setCountryCode("US");
		rpse911AddressUpdateCXPData.setLineItemNumber(uiRequest.getLineItemNumber());
		rpse911AddressUpdateCXPData.setOrderNumber(uiRequest.getOrderNumber());
		rpse911AddressUpdateCXPData.setE911Address(e911AddressData);
		cxpRequest.setData(rpse911AddressUpdateCXPData);

		return cxpRequest;
	}

	/**
	 *
	 * @param uiRequest
	 * @param cxpRequest
	 * @return RPSReleasePendingOrderRequestCXPRequest
	 */
	public static RPSReleasePendingOrderRequestCXPRequest formatReleasePendingOrderRequest(
			RPSReleasePendingOrderUIRequest uiRequest, RPSReleasePendingOrderRequestCXPRequest cxpRequest) {

		LineItemInfo lineItemInfo = new LineItemInfo();
		lineItemInfo.setLineItemNumber(uiRequest.getLineItemInfoList().get(0).getLineItemNumber());
		lineItemInfo.setLineItemTimeStamp(uiRequest.getLineItemInfoList().get(0).getLineItemTimeStamp());
		lineItemInfo.setOrderNumber(uiRequest.getLineItemInfoList().get(0).getOrderNumber());
		List<LineItemInfo> lineItemInfos = new ArrayList<>();
		lineItemInfos.add(lineItemInfo);
		cxpRequest.getData().setLineItemInfoList(lineItemInfos);
		return cxpRequest;
	}

	/**
	 *
	 * @param uiRequest
	 * @param cxpRequest
	 * @return RPSE911AddressRetrieveCxpRequest
	 */
	public static RPSE911AddressRetrieveCxpRequest formatRetrieveRPSE911AddressRequest(
			RPSE911AddressRetrieveUIRequest uiRequest, RPSE911AddressRetrieveCxpRequest cxpRequest) {
		RPSE911AddressMTNs data = new RPSE911AddressMTNs();
		if( uiRequest.getChannelID().equalsIgnoreCase(CartConstants.CHANNEL_ID_NUMBERLINK)) {
           if(StringUtilities.isNotEmptyOrNull(uiRequest.getDeviceId())) {
			   data.setDeviceList(Arrays.asList(uiRequest.getDeviceId()));
			   data.setFlowType(CartConstants.FLOW_TYPE_NUMBERLINK_MODIFY);
		   }else{
			   data.setFlowType(CartConstants.FLOW_TYPE_NUMBERLINK);
		   }
			data.setNumberLinkMtn(uiRequest.getMtn().get(0));
		}
		else {
			data.setMtn(uiRequest.getMtn());
		}
		cxpRequest.setData(data);


		return cxpRequest;
	}

	/**
	 * 
	 * @param uiRequest
	 * @param cxpRequest
	 * @return cxpRequest
	 */
	public static UpdateTradeInOfferCXPRequest formatUpdateTradeInOfferRequest(UpdateTradeInOfferUIRequest uiRequest,
			UpdateTradeInOfferCXPRequest cxpRequest) {

		cxpRequest.setMeta(new HashMap<>());
		cxpRequest.getMeta().put(CartConstants.CLIENT, uiRequest.getChannelId());
		cxpRequest.setData(new UpdateTradeInOfferData());
		UpdateTradeInOfferData data = new UpdateTradeInOfferData();
		data.setItemType("TRADEIN");
		data.setAction(CartConstants.STATUS_UPDATE);
		data.setIsTradeInOfferSelected(uiRequest.getIsTradeInOfferSelected());
		data.setCartId(uiRequest.getCartId());
		data.setIntendType("EUP");
		cxpRequest.setData(data);
		return cxpRequest;
	}

	/**
	 *
	 * @param uiRequest
	 * @param cxpRequest
	 * @return cxpRequest
	 */
	public static AddZipcodeCXPRequest formatAddZipcodeRequest(AddZipCodeUIRequest uiRequest,
																	   AddZipcodeCXPRequest cxpRequest) {

		cxpRequest.setMeta(new HashMap<>());
		cxpRequest.getMeta().put(CartConstants.CLIENT, uiRequest.getChannelId());
		cxpRequest.setData(new AddZipcodeCxpData());
		AddZipcodeCxpData data = new AddZipcodeCxpData();
		data.setItemType(uiRequest.getItemType()!=null?uiRequest.getItemType(): "USERCONTACTINFO");
		data.setAction(CartConstants.UPDATE);
		data.setZipCode(uiRequest.getZipCode());
		data.setCartId(uiRequest.getCartId());
		data.setIntendType(uiRequest.getIntendType());
		cxpRequest.setData(data);
		return cxpRequest;
	}
	
	/**
	 *
	 * @param uiRequest
	 * @param cxpRequest
	 * @return cxpRequest
	 */
	public static DeviceSimValidationCXPRequest formatDeviceSimValidationRequest(DeviceSimValidationUIRequest uiRequest,
			DeviceSimValidationCXPRequest cxpRequest) {
		DeviceSimValidationRequestData cxpRequestData = new DeviceSimValidationRequestData();
		if (StringUtilities.isNotEmptyOrNull(uiRequest.getEid()) || StringUtilities.isNotEmptyOrNull(uiRequest.getImei2()) ||(uiRequest.getTechType().equalsIgnoreCase(CartConstants.MANAGE_ACCOUNT) && StringUtilities.isNotEmptyOrNull(uiRequest.getImei()) && StringUtilities.isNotEmptyOrNull(uiRequest.getIccid()) && StringUtilities.isNotEmptyOrNull(uiRequest.getBillingId()))) {
			if (StringUtilities.isNotEmptyOrNull(uiRequest.getImei2()) || StringUtilities.isNotEmptyOrNull(uiRequest.getImei()) || StringUtilities.isNotEmptyOrNull(uiRequest.getDevid())) {
				
				Esim esim = new Esim();
				cxpRequestData.setFlowType("esim");
				if (StringUtilities.isNotEmptyOrNull(uiRequest.getImei2()))
					esim.setDeviceId(uiRequest.getImei2());
				if(StringUtilities.isEmptyOrNull(esim.getDeviceId()) && StringUtilities.isNotEmptyOrNull(uiRequest.getImei())){
					esim.setDeviceId(uiRequest.getImei());
				}
				if(StringUtilities.isEmptyOrNull(esim.getDeviceId()) && StringUtilities.isNotEmptyOrNull(uiRequest.getDevid())){
					esim.setDeviceId(uiRequest.getDevid());
				}
				if (StringUtilities.isNotEmptyOrNull(uiRequest.getIccid())) {
					esim.setSimId(uiRequest.getIccid());
				}
				if (StringUtilities.isNotEmptyOrNull(uiRequest.getTechType())) {
					esim.setTechType(uiRequest.getTechType());
				}
				if (StringUtilities.isNotEmptyOrNull(uiRequest.getEid()))
					esim.setEId(uiRequest.getEid());
				
				if(StringUtilities.isNotEmptyOrNull(uiRequest.getImei()) && StringUtilities.isNotEmptyOrNull(uiRequest.getEid())) {
					esim.setEsimType(CartConstants.IPAD);
				}
				if(StringUtilities.isNotEmptyOrNull(uiRequest.getDevid()) && StringUtilities.isNotEmptyOrNull(uiRequest.getEid())) {
					esim.setEsimType(CartConstants.LAPTOP);
				}
				if(StringUtilities.isNotEmptyOrNull(uiRequest.getImei2())) {
					esim.setEsimType(CartConstants.SMARTPHONE);
				}

				cxpRequestData.setESim(esim);
			}
		}
		
		if ((StringUtilities.isNotEmptyOrNull(uiRequest.getImei()) || StringUtilities.isNotEmptyOrNull(uiRequest.getDevid()))
				&& StringUtilities.isEmptyOrNull(uiRequest.getEid())) {
			// TechType: MANAGEACCOUNT has only Esim flow
			if (!uiRequest.getTechType().equalsIgnoreCase(CartConstants.MANAGE_ACCOUNT)) {
				cxpRequestData.setFlowType("psim");
				Psim psim = new Psim();
				if (StringUtilities.isNotEmptyOrNull(uiRequest.getImei())) {
					psim.setDeviceId(uiRequest.getImei());
				}
				else if(StringUtilities.isNotEmptyOrNull(uiRequest.getDevid())){
					psim.setDeviceId(uiRequest.getDevid());
				}
				if (StringUtilities.isNotEmptyOrNull(uiRequest.getIccid()))
					psim.setSimId(uiRequest.getIccid());
				if (StringUtilities.isNotEmptyOrNull(uiRequest.getBillingId()))
					psim.setBillingId(uiRequest.getBillingId());
				cxpRequestData.setPSim(psim);

			}
		}
			
		cxpRequest.setData(cxpRequestData);
		return cxpRequest;
	}

	//VZWCS-17115 changes
	public static InitiateCbandCheckCXPRequest formatInitiateCbandCheckRequest(InitiateCbandCheckUIRequest uiRequest,
                                                                               InitiateCbandCheckCXPRequest cxpRequest) {

		InitiateCbandCheckRequestData cxpRequestData = new InitiateCbandCheckRequestData();

		if (StringUtilities.isNotEmptyOrNull(uiRequest.getImsi())) {
			cxpRequestData.setImsi(uiRequest.getImsi());
		}

		if (uiRequest.getPendingInstallScenario()!=null) {
			cxpRequestData.setPendingInstallScenario(uiRequest.getPendingInstallScenario());
		}
		
		cxpRequest.setData(cxpRequestData);
		return cxpRequest;
	}
	/**
	 *
	 * @param uiRequest
	 * @param cxpRequest
	 * @return VZCCAppStatusCXPRequest
	 */
	public static UpdateVzccNBXInfoCXPRequest formatVzccNBXInfoRequest(UpdateVzccNBXInfoUIRequest uiRequest,
			UpdateVzccNBXInfoCXPRequest cxpRequest) {
		cxpRequest.setMeta(new HashMap<>());
		cxpRequest.getMeta().put(CartConstants.CLIENT, CartConstants.CXP);
		cxpRequest.setData(new UpdateVzccNBXInfoData());
		UpdateVzccNBXInfoData data = new UpdateVzccNBXInfoData();
		data.setAction(CartConstants.UPDATE);
		if (CartConstants.NSE.equalsIgnoreCase(uiRequest.getIntentType())) {
			data.setIntendType(CartConstants.NSE);
		} else {
			data.setIntendType(CartConstants.EUP);
		}
		data.setItemType("NBXINFO");
		data.setCartId(uiRequest.getCartId());
		data.setVzccStatus(uiRequest.getVzccStatus());
		data.setCallingPage(uiRequest.getCallingPage());

		data.setIsPreQualifiedNBX(uiRequest.getIsPreQualifiedNBX());
		data.setIsVZCCHolder(uiRequest.getIsVZCCHolder());

		if (StringUtilities.isNotEmptyOrNull(uiRequest.getOfferIdFromSYF()))
			data.setOfferIdFromSYF(uiRequest.getOfferIdFromSYF());

		if (StringUtilities.isNotEmptyOrNull(uiRequest.getPromotionalSPOCode()))
			data.setPromotionalSPOCode(uiRequest.getPromotionalSPOCode());

		if (StringUtilities.isNotEmptyOrNull(uiRequest.getPropositionId()))
			data.setPropositionId(uiRequest.getPropositionId());

		if (StringUtilities.isNotEmptyOrNull(uiRequest.getPropositionMessage()))
			data.setPropositionMessage(uiRequest.getPropositionMessage());

		if (StringUtilities.isNotEmptyOrNull(uiRequest.getPropositionName()))
			data.setPropositionName(uiRequest.getPropositionName());

		if (StringUtilities.isNotEmptyOrNull(uiRequest.getSessionId()))
			data.setSessionId(uiRequest.getSessionId());

		if (StringUtilities.isNotEmptyOrNull(uiRequest.getSyfOfferId()))
			data.setSyfOfferId(uiRequest.getSyfOfferId());

		cxpRequest.setData(data);
		return cxpRequest;
	}

	/**
	 *
	 * @param uiRequest
	 * @param cxpRequest
	 * @return AddressRequest cxpRequest
	 */
	public static AddressRequest formatValidateE911AddressRequest(
			RPSE911AddressUpdateUIRequest uiRequest, AddressRequest cxpRequest) {

		cxpRequest.setAddressLine1(uiRequest.getAddressLine1());
		cxpRequest.setAddressLine2(uiRequest.getAddressLine2());
		cxpRequest.setCity(uiRequest.getCityName());
		cxpRequest.setState(uiRequest.getState());
		cxpRequest.setZipCode(uiRequest.getZipCode());
		cxpRequest.setZipCodePlus4("");

		return cxpRequest;
	}
	
	/**
	 * Format initiate device sim activation CXP request.
	 *
	 * @param uiRequest the ui request
	 * @param cxpRequest the cxp request
	 * @return AddressRequest cxpRequest
	 */
	public static IntiateDeviceSimActivationCXPRequest formatInitiateDeviceSimActivationCXPRequest(
			IntiateDeviceSimActivationUIRequest uiRequest, IntiateDeviceSimActivationCXPRequest cxpRequest) {

		IntiateDevicePsim psim = new IntiateDevicePsim();
		IntiateDeviceSimActivationRequestData data = new IntiateDeviceSimActivationRequestData();

		data.setFlowType("psim");
		if (StringUtilities.isNotEmptyOrNull(uiRequest.getImei())) {
			psim.setDeviceId(uiRequest.getImei());
		}
		data.setPSim(psim);
		cxpRequest.setData(data);

		return cxpRequest;
	}
	
	public static InitiateESimActivationCXPRequest formatInitiateESimActivationCXPRequest(
			IntiateESimActivationUIRequest uiRequest, InitiateESimActivationCXPRequest cxpRequest) {

		InitiateDeviceEsim esim = new InitiateDeviceEsim();
		InitiateESimActivationRequestData data = new InitiateESimActivationRequestData();

		data.setFlowType("esim");
		if (StringUtilities.isNotEmptyOrNull(uiRequest.getImei())) {
			esim.setDeviceId(uiRequest.getImei());
		}
		if (StringUtilities.isNotEmptyOrNull(uiRequest.getEid())) {
			esim.setEid(uiRequest.getEid());
		}
		
		if (StringUtilities.isNotEmptyOrNull(uiRequest.getHandOffToken())) {
			esim.setHandOffToken(uiRequest.getHandOffToken());
		}
		
		data.setEsim(esim);;
		cxpRequest.setData(data);

		return cxpRequest;
	}
	

	/**
	 *
	 * @param uiRequest
	 * @param cxpRequest
	 * @return cxpRequest
	 */
	public static DeviceSimValidationCXPRequest formatDeviceSimValidationWIthEidRequest(DeviceSimValidationUIRequest uiRequest,
																						DeviceSimValidationCXPRequest cxpRequest) {
		DeviceSimValidationRequestData cxpRequestData = new DeviceSimValidationRequestData();
		Esim esim = new Esim();
		cxpRequestData.setFlowType("esim");
		if (StringUtilities.isNotEmptyOrNull(uiRequest.getDevid()))
			esim.setDeviceId(uiRequest.getDevid());
		if (StringUtilities.isNotEmptyOrNull(uiRequest.getEid()))
			esim.setEId(uiRequest.getEid());

		esim.setEsimType("WATCH");

		cxpRequestData.setESim(esim);
		cxpRequest.setData(cxpRequestData);
		return cxpRequest;
	}
	//Sajan
	/**
	 *
	 * @param uiRequest
	 * @param cxpRequest
	 * @return cxpRequest
	 */
	public static SmartImeiTypeAheadCXPRequest formatSmartImeiTypeAheadRequest(
			SmartImeiTypeAheadSearchRequest uiRequest, SmartImeiTypeAheadCXPRequest cxpRequest) {
		cxpRequest.setSmartImeiTypeAheadRequest(new SmartImeiTypeAheadRequest());
		cxpRequest.getSmartImeiTypeAheadRequest().setDeviceCategory(uiRequest.getDeviceCategory());
		cxpRequest.getSmartImeiTypeAheadRequest().setMakeOrModel(uiRequest.getModel());
		cxpRequest.getSmartImeiTypeAheadRequest().setNoOfRecords(smartImeiTypeAheadNoOfRecords);
		return cxpRequest;
	}
	/**
	 *
	 * @param uiRequest
	 * @param cxpRequest
	 * @return cxpRequest
	 */
	public static UpdateConsentCxpRequest formatUpdateCusetomerConsentRequest(AddDeviceUIRequest uiRequest,
																			  UpdateConsentCxpRequest cxpRequest) {

		cxpRequest.setData(new UpdateConsentData());

		UpdateConsentData data = new UpdateConsentData();
		if(StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getIntendType()))
			data.setIntendType(uiRequest.getCartInfo().getIntendType());

		data.setItemType("CONSENT");

		if(StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getCartId()))
			data.setCartId(uiRequest.getCartInfo().getCartId());

		if(uiRequest.getCartInfo().getCustomerConsent())
			data.setCustomerConsent("Y");

		cxpRequest.setData(data);
		return cxpRequest;

	}

	public static NbsDataCXPRequest formatNbsDataRequest(AddDeviceUIRequest uiRequest,
			NbsDataCXPRequest nbxCxpRequest) {

		String[] accInfo = new String[2];
		NbsData data = new NbsData();
		if (uiRequest.getCartInfo().getAccountNumber()!= null ) {
			 accInfo = uiRequest.getCartInfo().getAccountNumber().split("-");
			data.setCustomerId(accInfo[0].substring(0, 10));
			data.setBillAccountNum(accInfo[1]);
		}
		if( StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getCartId()))
			data.setCartId(uiRequest.getCartInfo().getCartId());
			nbxCxpRequest.setData(data);

		return nbxCxpRequest;
	}

	public static Offers applyOffer(Offer offer, String sku) {
		Offers offerObj = new Offers();
		if (null != offer) {
			offerObj.setComplianceType(offer.getComplianceType());
			if (StringUtilities.isNotEmptyOrNull(offer.getMmtier()))
				offerObj.setMmtier(offer.getMmtier());
			else
				offerObj.setSku(sku);
		}
		return offerObj;
	}

	public static SmartImeiTypeAheadCXPRequest createSmartImeiTypeAheadRequest(String deviceCategory) {
		SmartImeiTypeAheadCXPRequest cxpRequest = new SmartImeiTypeAheadCXPRequest();
		cxpRequest.setSmartImeiTypeAheadRequest(new SmartImeiTypeAheadRequest());
		cxpRequest.getSmartImeiTypeAheadRequest().setDeviceCategory(deviceCategory);
		cxpRequest.getSmartImeiTypeAheadRequest().setMakeOrModel(StringUtils.EMPTY);
		return cxpRequest;
	}

	public static boolean validateEmptyAddress(Address address) {
		return address.getAddressLine1() !=null && address.getState() !=null && address.getCity() !=null && address.getZipCode() !=null;
	}

}
