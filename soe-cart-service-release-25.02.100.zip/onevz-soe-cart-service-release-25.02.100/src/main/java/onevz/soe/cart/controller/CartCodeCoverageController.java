package onevz.soe.cart.controller;

import onevz.soe.utilities.CodeCoverageUtil;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;

@RestController
public class CartCodeCoverageController {
	/**
	 * 
	 * @return resource
	 * @throws IOException
	 */
	@GetMapping(value = "/getITCoverage", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public ResponseEntity<Resource> getITCoverage() throws IOException {
		HttpHeaders header = new HttpHeaders();

		header.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=jacoco-coverage.exec");
		header.add("Cache-Control", "no-cache, no-store, must-revalidate");
		header.add("Pragma", "no-cache");
		header.add("Expires", "0");

		ByteArrayResource resource = new ByteArrayResource(
				CodeCoverageUtil.generateCoverageUsingByteStream("localhost", 3000));

		return ResponseEntity.ok().headers(header).contentType(MediaType.parseMediaType("application/octet-stream"))
				.body(resource);
	}
}
