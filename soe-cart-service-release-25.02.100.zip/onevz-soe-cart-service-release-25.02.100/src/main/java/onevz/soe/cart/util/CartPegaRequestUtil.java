package onevz.soe.cart.util;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.saveCart.*;
import onevz.soe.cart.model.updateBarcode.UpdateBarCodeContext;
import onevz.soe.cart.model.updateBarcode.UpdateBarCodeServiceBody;
import onevz.soe.cart.model.updateBarcode.UpdateBarCodeServiceRequest;
import onevz.soe.cart.requests.SaveCartPEGARequest;
import onevz.soe.cart.requests.UpdateBarCodePEGARequest;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.BBPGetProcessStepUIRequest;
import onevz.soe.cart.ui.requests.SaveCartUIRequest;
import onevz.soe.cart.ui.requests.UpdateBarcodeUIRequest;
import onevz.soe.constants.SOEConstants;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import onevz.soe.spring.web.filter.RequestAccessContext;

import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.function.Consumer;

/**
 * Request Format Helper class.
 */
public class CartPegaRequestUtil {

	private CartPegaRequestUtil() {
	}
	private static final Logger logger = LoggerFactory.getLogger(CartPegaRequestUtil.class);

	@Value("${enableCradleForProspect:true}")
	private static boolean enableCradleForProspect;

	@Value("${enableCradleForExistingCustomer:true}")
	private static boolean enableCradleForExistingCustomer;
	
	/**
	 * @param serviceHeader
	 * @return CartServiceServiceHeader
	 */
	public static CartServiceServiceHeader addServiceHeader(CartServiceServiceHeader serviceHeader) {
		serviceHeader.setClientId("VZW-NETACE");
		serviceHeader.setSessionId("");
		serviceHeader.setStatusMsg(CartConstants.BPM_PEGA_GENERATED_MESSAGE);
		serviceHeader.setServiceName(CartConstants.SALES_ORDER_PURCHASE);
		SecureRandom random = new SecureRandom();
		byte[] bytes = new byte[20];
		random.nextBytes(bytes);
		serviceHeader.setCorrelationId("soe-cart-" + new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date())
				+ "-" + String.valueOf(1000 * random.nextDouble()));
		serviceHeader.setUserId("");
		serviceHeader.setStatusCode("0");
		return serviceHeader;
	}


	/**
	 * Adds the service header for process step.
	 *
	 * @param serviceHeader the service header
	 * @param request       the request
	 * @return the cart service service header
	 */
	public static CartServiceServiceHeader addServiceHeaderForProcessStep(CartServiceServiceHeader serviceHeader,
			BBPGetProcessStepUIRequest request) {
		serviceHeader.setClientId(CartConstants.CHANNEL_ID_BBP);
		serviceHeader.setStatusMsg(CartConstants.BPM_PEGA_GENERATED_MESSAGE);
		serviceHeader.setCorrelationId(request.getCartInfo().getCorrelationId());
		serviceHeader.setSessionId("");
		serviceHeader.setServiceName(CartConstants.SALES_ORDER_PURCHASE);
		serviceHeader.setUserId("");
		serviceHeader.setStatusCode("0");
		return serviceHeader;
	}


	/**
	 * @param contextInfo
	 * @param operationType
	 * @param clientAppName
	 * @return CartServiceContextInfo
	 */
	public static CartServiceContextInfo addContextInfo(CartServiceContextInfo contextInfo, String operationType,
														String clientAppName) {
		contextInfo.setCallReason(CartConstants.SALES_ORDER_PURCHASE);
		contextInfo.setIntent(CartConstants.UPGRADE);
		clientAppName = StringUtilities.isNotEmptyOrNull(clientAppName) ? clientAppName : "";

		// Define a mapping of operation types to process actions
		Map<String, Consumer<CartServiceContextInfo>> operationMapping = new HashMap<>();
		operationMapping.put(CartConstants.ADD_DEVICE_WITH_TRADE_IN, info -> info.setProcessAction(CartConstants.ADD_DEVICE_WITH_TRADE_IN));
		operationMapping.put(CartConstants.EXPRESS_UPGRADE, info -> info.setProcessAction(CartConstants.EXPRESS_UPGRADE));
		operationMapping.put(CartConstants.BUILD_LINE, info -> {
			info.setProcessAction(CartConstants.BUILD_LINE);
			info.setIntent(CartConstants.NSE);
		});
		operationMapping.put(CartConstants.ADD_DEVICE, info -> info.setProcessAction(CartConstants.ADD_DEVICE));
		operationMapping.put(CartConstants.REMOVE_LINES, info -> info.setProcessAction(CartConstants.REMOVE_ITEM));
		operationMapping.put(CartConstants.REMOVE_ACCESSORY, info -> info.setProcessAction(CartConstants.REMOVE_ACCESSORY));
		operationMapping.put(CartConstants.ADD_ACCESSORY, info -> {
			info.setIntent(CartConstants.ACCESSORY_C);
			info.setProcessAction(CartConstants.ADD_ACCESSORY);
		});
		operationMapping.put(CartConstants.ADD_FEATURES, info -> info.setProcessAction(CartConstants.ADD_FEATURES));
		operationMapping.put(CartConstants.MAY_BE_LATER, info -> info.setProcessAction(CartConstants.MAY_BE_LATER));
		operationMapping.put(CartConstants.REMOVE_OFFER, info -> info.setProcessAction(CartConstants.REMOVE_OFFER));
		operationMapping.put(CartConstants.RESUME_CASE, info -> {
			info.setAction(CartConstants.RESUME);
			info.setIntent("Sales Order Purchase");
			info.setProcessStep(CartConstants.MTN_SELECTION_PAGE);
		});
		operationMapping.put(CartConstants.ADD_SELLER_PRICE, info -> info.setProcessAction(CartConstants.ADD_SELLER_PRICE));
		operationMapping.put(CartConstants.REMOVE_FEATURE, info -> info.setProcessAction(CartConstants.REMOVE_FEATURE));
		operationMapping.put(CartConstants.ADD_PLAN, info -> info.setProcessAction(CartConstants.ADD_PLAN));
		operationMapping.put(CartConstants.ADD_PLAN_AND_FEATURE, info -> info.setProcessAction(CartConstants.ADD_PLAN_AND_FEATURE));
		operationMapping.put(CartConstants.INITIATE_CHECKOUT, info -> info.setProcessAction(CartConstants.PROCEED_TO_ORDER));
		operationMapping.put(CartConstants.ADD_BUYOUT_AMT, info -> info.setProcessAction(CartConstants.ADD_BUYOUT_AMT));
		operationMapping.put(CartConstants.ADD_EDGEUP_AMT, info -> info.setProcessAction(CartConstants.ADD_EDGEUP_AMT));
		operationMapping.put(CartConstants.ADD_DOWNPAYMENT, info -> info.setProcessAction(CartConstants.ADD_DOWNPAYMENT));
		operationMapping.put(CartConstants.PAST_DUE, info -> info.setProcessAction(""));
		operationMapping.put(CartConstants.CREATE_LINE, info -> {
			info.setIntent(CartConstants.AAL);
			info.setProcessAction(CartConstants.CREATE_LINE);
		});
		operationMapping.put(CartConstants.CREATE_CART_AND_LINE, info -> {
			info.setIntent(CartConstants.NSE);
			info.setProcessAction(CartConstants.CREATE_LINE);
		});
		operationMapping.put(CartConstants.CREATE_CASE, info -> info.setIntent(CartConstants.ACCOUNT_GROWTH));
		operationMapping.put(CartConstants.ADD_NUMBERSHARE, info -> info.setProcessAction(CartConstants.ADD_NUMBERSHARE));
		operationMapping.put(CartConstants.ADD_SERVICE_ADDRESS, info -> info.setProcessAction("updateServiceAddress"));
		operationMapping.put(CartConstants.ADD_E911_ADDRESS, info -> info.setProcessAction(CartConstants.ADD_E911_ADDRESS));
		operationMapping.put(CartConstants.ADD_BARCODE_OFFER, info -> info.setProcessAction(CartConstants.ADD_BARCODE_OFFER));
		operationMapping.put(CartConstants.UPDATE_DEVICESIMID, info -> info.setProcessAction(CartConstants.UPDATE_DEVICESIMID));
		operationMapping.put(CartConstants.ASSIGN_MTN, info -> info.setProcessAction(CartConstants.ASSIGN_NUMBERS));
		operationMapping.put(CartConstants.DEASSIGN_MTN, info -> info.setProcessAction(CartConstants.DEASSIGN_NUMBERS));
		operationMapping.put(CartConstants.FIVEGBULK, info -> info.setProcessAction(CartConstants.FIVEGBULK));
		operationMapping.put(CartConstants.REVOKE_REBATES, info -> info.setProcessAction("revokeRebates"));
		operationMapping.put(CartConstants.UPDATE_PORTIN_LATER, info -> info.setProcessAction(CartConstants.UPDATE_PORTIN_LATER));
		operationMapping.put(CartConstants.VOID_ORDER, info -> info.setProcessAction(CartConstants.CANCEL_ISPU));
		operationMapping.put(CartConstants.ISPU_TO_DFILL, info -> info.setProcessAction(CartConstants.ISPU_TO_DFILL));
		operationMapping.put(CartConstants.UPDATE_MANUAL_PAIRING, info -> info.setProcessAction(CartConstants.UPDATE_MANUAL_PAIRING));
		operationMapping.put(CartConstants.UPDATE_SALES_REP, info -> info.setProcessAction(CartConstants.UPDATE_SALES_REP));
		operationMapping.put(CartConstants.SPLIT_EXCEEDED_AMOUNT, info -> info.setProcessAction(CartConstants.SPLIT_EXCEEDED_AMOUNT));
		operationMapping.put(CartConstants.CANCEL, info -> info.setProcessAction(CartConstants.CANCEL));
		operationMapping.put(CartConstants.ADD_IC_DOWNPAYMENT, info -> info.setProcessAction(CartConstants.ADD_ALLOCATION_AMOUNT));
		operationMapping.put(CartConstants.SAVE_CART, info -> info.setProcessAction(CartConstants.SAVE_CART));
		operationMapping.put(CartConstants.SAVE_CART_AND_QUOTES, info -> info.setProcessAction(CartConstants.SAVE_CART_AND_QUOTES));
		operationMapping.put(CartConstants.ACTIVATE_LATER, info -> info.setProcessAction(CartConstants.SETUP_LATER));
		operationMapping.put(CartConstants.ADD_DEVICE_SIM, info -> info.setProcessAction(CartConstants.ADD_DEVICE_SIM));
		operationMapping.put(CartConstants.CANCEL_EDGE_UP, info -> info.setProcessAction(operationType));
		operationMapping.put(CartConstants.ADD_NICK_NAME, info -> info.setProcessAction(CartConstants.ADD_NICK_NAME));
		operationMapping.put(CartConstants.SAVE_FOR_LATER, info -> info.setProcessAction(CartConstants.SAVE_FOR_LATER));
		operationMapping.put(CartConstants.DELETE_SAVE_FOR_LATER, info -> info.setProcessAction(CartConstants.DELETE_SAVE_FOR_LATER));
		operationMapping.put(CartConstants.REMOVE_SAVE_FOR_LATER, info -> info.setProcessAction(CartConstants.REMOVE_SAVE_FOR_LATER));
		operationMapping.put(CartConstants.EFFECTIVE_DATE_UPDATE, info -> info.setProcessAction(CartConstants.EFFECTIVE_DATE_UPDATE));
		operationMapping.put(CartConstants.ADD_FEATURES_AND_ACCESSORY, info -> info.setProcessAction(CartConstants.ADD_FEATURES_AND_ACCESSORY));
		operationMapping.put(CartConstants.ADD_ZIPCODE, info -> info.setProcessAction(CartConstants.ADD_ZIPCODE));
		operationMapping.put(CartConstants.DEVICES_AND_SERVICES_ITEM, info -> info.setProcessAction(CartConstants.DEVICES_AND_SERVICES_PROCESS_ACTION));
		String finalClientAppName = clientAppName;
		operationMapping.put(CartConstants.CLEAR_CART, info -> {
			if (CartConstants.CHANNEL_ID_BBP.equalsIgnoreCase(finalClientAppName)) {
				info.setProcessAction(CartConstants.CLEAR);
			} else {
				info.setProcessAction(CartConstants.CLEAR_ALL);
			}
		});

		// Apply the operation mapping based on the operation type
		operationMapping.getOrDefault(operationType, info -> info.setProcessAction("")).accept(contextInfo);

		return contextInfo;
	}


	/**
	 *
	 * @param uiRequest
	 * @param pegaRequest
	 * @return SaveCartPegaRequest
	 */
	public static SaveCartPEGARequest formatSaveCartRequest(SaveCartPEGARequest pegaRequest,
			SaveCartUIRequest uiRequest) {
		String channelType = CartUtil.getChannelType(uiRequest.getChannelId());
		CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
		serviceHeader = addServiceHeader(serviceHeader);
		serviceHeader.setClientId(uiRequest.getChannelId());
		pegaRequest.setServiceHeader(serviceHeader);

		SaveCartServiceBody serviceBody = new SaveCartServiceBody();
		SaveCartContext context = new SaveCartContext();
		SaveCartServiceRequest serviceRequest = new SaveCartServiceRequest();

		CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
		customerInfo.setAccountNumber(uiRequest.getCartInfo().getAccountNumber());
		customerInfo.setCartCreator(uiRequest.getCartInfo().getCartCreator());
		customerInfo.setProcessingMTN(uiRequest.getCartInfo().getProcessingMTN());
		customerInfo.setGlobalId(uiRequest.getCartInfo().getGlobalId());
		customerInfo.setQuoteWithoutCredit(uiRequest.getCartInfo().getQuoteWithoutCredit());
		customerInfo.setAccountType(uiRequest.getCartInfo().getAccountType());
		if(null != uiRequest.getCartInfo().getRegisterNumber()){
			customerInfo.setRegisterNumber(uiRequest.getCartInfo().getRegisterNumber());
		}

		if (null != uiRequest.getData() && StringUtilities.isNotEmptyOrNull(uiRequest.getData().getEmail())) {
		    customerInfo.setEmail(uiRequest.getData().getEmail());
		}
		
		if (null != uiRequest.getData() && StringUtilities.isNotEmptyOrNull(uiRequest.getData().getCustomerName())) {
		    customerInfo.setCustomerName(uiRequest.getData().getCustomerName());
		}
		if (StringUtilities.isNotEmptyOrNull(uiRequest.getSafeTechSessionId())) {
			customerInfo.setSafeTechSessionId(uiRequest.getSafeTechSessionId());
		}

		if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getProcessStep())
				&& uiRequest.getCartInfo().getProcessStep().equalsIgnoreCase(CartConstants.PROMO_HUB)) {
			if (CartConstants.NSE.equalsIgnoreCase(uiRequest.getCartInfo().getIntendType()) || CartConstants.NSE_BYOD.equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())){
				if(enableCradleForProspect) {
					customerInfo.setCradleFlowJourney(CartConstants.ACCESSORIES_INTERSTIAL_PROSPECT);
				}
				if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getMtnFlow())){
					customerInfo.setMtnFlow(uiRequest.getCartInfo().getMtnFlow());
				}
			}
			else {
				if(enableCradleForExistingCustomer){
					customerInfo.setCradleFlowJourney(CartConstants.PROMO_HUB);
				}
			}
		}
		if (null != uiRequest.getCartInfo().getScheduleOrder())
			customerInfo.setScheduleOrder(uiRequest.getCartInfo().getScheduleOrder());

		CartServiceCartInfo cartInfo = new CartServiceCartInfo();
		cartInfo.setCartId(uiRequest.getCartInfo().getCartId());
		cartInfo.setZipCode(uiRequest.getCartInfo().getZipCode());
		cartInfo.setItemType(CartConstants.SAVE_CART.toUpperCase());
		cartInfo.setTransactionType(Optional.ofNullable(uiRequest.getCartInfo().getTransactionType()).orElse(""));
		if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getIntendType()))
			cartInfo.setIntendType(uiRequest.getCartInfo().getIntendType());
		else
			cartInfo.setIntendType(CartConstants.AAL);
		if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getSaveCartEmailId()))
			cartInfo.setSaveCartEmailId(uiRequest.getCartInfo().getSaveCartEmailId());

		if(null != uiRequest.getData() && Boolean.TRUE.equals(uiRequest.getData().getCreateLead())
				&& StringUtilities.isEmptyOrNull(uiRequest.getCartInfo().getQuoteId())) {
			cartInfo.setCreateLead(uiRequest.getData().getCreateLead());
			cartInfo.setUpdateLead(uiRequest.getData().getUpdateLead());
			
			if (null != cartInfo.getUpdateLead()) {
				
				cartInfo.getUpdateLead().setSource(CartConstants.HUMAN);
				if (null != uiRequest.getCartInfo()) {
				
					if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getStoreName())) {
						cartInfo.getUpdateLead().setStoreName(uiRequest.getCartInfo().getStoreName());
					}
					
					if (null != uiRequest.getData() 
							&& null != uiRequest.getData().getUpdateLead() 
							&& StringUtilities.isNotEmptyOrNull(uiRequest.getData().getUpdateLead().getLeadOwner())) {
						cartInfo.getUpdateLead().setRepId(uiRequest.getData().getUpdateLead().getLeadOwner());
						cartInfo.getUpdateLead().setLeadOwner(uiRequest.getData().getUpdateLead().getLeadOwner());
					} else if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getLoggedInUser())) {
						cartInfo.getUpdateLead().setRepId(uiRequest.getCartInfo().getLoggedInUser());
						cartInfo.getUpdateLead().setLeadOwner(uiRequest.getCartInfo().getLoggedInUser());
					}
			   }
				if (null != uiRequest.getData().getUpdateLead() && null != uiRequest.getData().getUpdateLead().getIsMobileNumber()) {
				       cartInfo.getUpdateLead().setIsMobileNumber(uiRequest.getData().getUpdateLead().getIsMobileNumber());
				} else {
					   cartInfo.getUpdateLead().setIsMobileNumber(Boolean.FALSE);
				}
				
				if (null != uiRequest.getData().getUpdateLead() && StringUtilities.isNotEmptyOrNull(uiRequest.getData().getUpdateLead().getLeadOwnerName())) {
					cartInfo.getUpdateLead().setLeadOwnerName(uiRequest.getData().getUpdateLead().getLeadOwnerName());
				}
				
				if (null != uiRequest.getData().getUpdateLead() && null != uiRequest.getData().getUpdateLead().getCartDetails()) {
				       cartInfo.getUpdateLead().setCartDetails(uiRequest.getData().getUpdateLead().getCartDetails());
				}

				if (null != uiRequest.getData().getUpdateLead() && null != uiRequest.getData().getUpdateLead().getAddressInfo()) {
					   
					AddressInfo addressInfo = new AddressInfo();
					   
					   if (StringUtilities.isNotEmptyOrNull(uiRequest.getData().getUpdateLead().getAddressInfo().getState())) {
						   addressInfo.setState(uiRequest.getData().getUpdateLead().getAddressInfo().getState());
					   }
					   
					   if (StringUtilities.isNotEmptyOrNull(uiRequest.getData().getUpdateLead().getAddressInfo().getCity())) {
						   addressInfo.setCity(uiRequest.getData().getUpdateLead().getAddressInfo().getCity());
					   }
					   
					   if (StringUtilities.isNotEmptyOrNull(uiRequest.getData().getUpdateLead().getAddressInfo().getAddressLine1())) {
						   addressInfo.setAddressLine1(uiRequest.getData().getUpdateLead().getAddressInfo().getAddressLine1());
					   }
					   
					   if (StringUtilities.isNotEmptyOrNull(uiRequest.getData().getUpdateLead().getAddressInfo().getAddressLine2())) {
						   addressInfo.setAddressLine2(uiRequest.getData().getUpdateLead().getAddressInfo().getAddressLine2());
					   }
					   
				       cartInfo.getUpdateLead().setAddressInfo(addressInfo);
				}
				
				if (null != uiRequest.getData().getUpdateLead()
						&& null != uiRequest.getData().getUpdateLead().getECode()) {
					cartInfo.getUpdateLead().setECode(uiRequest.getData().getUpdateLead().getECode());
				} else if (null != uiRequest.getCartInfo()
						&& StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getRepId())) {
					cartInfo.getUpdateLead().setECode(uiRequest.getCartInfo().getRepId());
				}
			}
		}
				
		context.setCartInfo(cartInfo);

		CartServiceContextInfo contextInfo = new CartServiceContextInfo();
		
		if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getProcessAction())) {
		     contextInfo = addContextInfo(contextInfo, uiRequest.getCartInfo().getProcessAction(), uiRequest.getCartInfo().getClientAppName());
		} else {
			 contextInfo = addContextInfo(contextInfo, CartConstants.SAVE_CART, uiRequest.getCartInfo().getClientAppName());
		}
			
		if (!StringUtilities.isEmptyOrNull(uiRequest.getCartInfo().getProcessStep())) {
			contextInfo.setProcessStep(uiRequest.getCartInfo().getProcessStep());
		} else {
			contextInfo.setProcessStep(CartConstants.ORDERREVIEW_SHIPPING);
		}

		if (CartConstants.NSE_BYOD.equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())
				|| CartConstants.NSE.equalsIgnoreCase(uiRequest.getCartInfo().getIntendType()) || CartConstants.NSE_5G.equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())) {
			CartPegaRequestUtil7.newCustomerOverride(contextInfo, customerInfo, uiRequest.getCartInfo(), uiRequest.getChannelId());
		}

		if (CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(uiRequest.getChannelId()))
				&& StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getCreditAppNum())){
			customerInfo.setGlobalId(uiRequest.getGlobalId());
		}
		// Add customerEmail while save cart
		if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getEmailId()))
			cartInfo.setSaveCartEmailId(uiRequest.getCartInfo().getEmailId());

		if (null != uiRequest.getCartInfo().getExpressCheckout() && uiRequest.getCartInfo().getExpressCheckout()) {
				if(enableCradleForExistingCustomer){
					customerInfo.setCradleFlowJourney(CartConstants.PROMO_HUB);
				}
		}
		
		if (null!= uiRequest.getCartInfo().getCartSavedByCustomer())
			cartInfo.setCartSavedByCustomer(uiRequest.getCartInfo().getCartSavedByCustomer());

		if (StringUtilities.isNotEmptyOrNull(channelType) && CartConstants.ASSISTED.equalsIgnoreCase(channelType)) {
			if(CartConstants.CHAT_STORE.equalsIgnoreCase(uiRequest.getChannelId()) || CartConstants.OMNI_TELESALES.equalsIgnoreCase(uiRequest.getChannelId()) || CartConstants.OMNI_CARE.equalsIgnoreCase(uiRequest.getChannelId()))
				cartInfo.setExplicit_lock(false);
		}

		if(CartConstants.PLAN_BUILDER.equals(uiRequest.getCartInfo().getFlowType())){
			if(StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getIntent())){
				contextInfo.setIntent(uiRequest.getCartInfo().getIntent());
			}
			if(StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getProcessStep())){
				contextInfo.setProcessStep(uiRequest.getCartInfo().getProcessStep());
			}
			customerInfo.setFlowType(uiRequest.getCartInfo().getFlowType());
			customerInfo.setMtnFlow(uiRequest.getCartInfo().getMtnFlow());
		}
		
		if (null != uiRequest.getCartInfo() && StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getQuoteId())) {
		       cartInfo.setQuoteId(uiRequest.getCartInfo().getQuoteId());
		}

		if (null != uiRequest.getCartInfo() && StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getQuoteId())) {
			cartInfo.setSuppressEmail(Boolean.TRUE);
		}
		
		if (null != uiRequest.getCartInfo() && null != uiRequest.getCartInfo().getIsDirectApply()) {
			   cartInfo.setVzCardEligible(uiRequest.getCartInfo().getIsDirectApply());
		}
		
		if (null != uiRequest.getData() && StringUtilities.isNotEmptyOrNull(uiRequest.getData().getZipCode())) {
		       cartInfo.setZipCode(uiRequest.getData().getZipCode());
		}
		
		//defect-fix
		if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getIntendType()) &&
				uiRequest.getCartInfo().getIntendType().equalsIgnoreCase(CartConstants.REFUND_EXCHANGE)) {
			contextInfo.setIntent(CartConstants.REFUND_EXCHANGE);
			contextInfo.setCallReason(CartConstants.SALES_ORDER_ADJUSTMENT);
			serviceHeader.setServiceName(CartConstants.SALES_ORDER_ADJUSTMENT);
		}
		//VZWYZDF-584
		
		if(null != uiRequest.getData() && null != uiRequest.getData().getCompareQuotePdfEnabled())
			cartInfo.setCompareQuotePdfEnabled(uiRequest.getData().getCompareQuotePdfEnabled());
		if(null != uiRequest.getData() && null != uiRequest.getData().getQuoteLowerBillEnabled())
			cartInfo.setQuoteLowerBillEnabled(uiRequest.getData().getQuoteLowerBillEnabled());
		
		if(null != uiRequest.getData() && null != uiRequest.getData().getViewQrCode())
			cartInfo.setViewQrCode(uiRequest.getData().getViewQrCode());

		if (uiRequest.getEnforceData() != null) {
			onevz.soe.cart.model.saveCart.EnforceData enforceData = new onevz.soe.cart.model.saveCart.EnforceData();
			DeviceFingerPrint fingerprint = new DeviceFingerPrint();
			HttpHeaderData headerData = new HttpHeaderData();
			HttpHeaders httpHeaders = uiRequest.getHttpRequest().getHeaders();
			if (httpHeaders.get("Accept") != null) {
				headerData.setAccept(Objects.requireNonNull(httpHeaders.get("Accept")).toString());
			}
			if (httpHeaders.get("Accept-Encoding") != null) {
				headerData.setAcceptEncoding(Objects.requireNonNull(httpHeaders.get("Accept-Encoding")).toString());
			}
			if (httpHeaders.get("Accept-Language") != null) {
				headerData.setAcceptLanguage(Objects.requireNonNull(httpHeaders.get("Accept-Language")).toString());
			}
			if (httpHeaders.get("Connection") != null) {
				headerData.setConnection(Objects.requireNonNull(httpHeaders.get("Connection")).toString());
			} else {
				headerData.setConnection("keep-alive");
			}
			if (httpHeaders.get("Host") != null) {
				headerData.setHost(Objects.requireNonNull(httpHeaders.get("Host")).toString());
			}
			if (httpHeaders.get("Referer") != null) {
				headerData.setReferer(Objects.requireNonNull(httpHeaders.get("Referer")).toString());
			}
			fingerprint.setHttpRequestHeaders(headerData);

			fingerprint.setScreenResolution(uiRequest.getEnforceData().getScreenResolution());
			fingerprint.setTouchSupport(uiRequest.getEnforceData().getTouchSupport());
			fingerprint.setListOfInstalledFonts("");
			fingerprint.setListOfMimeTypes(uiRequest.getEnforceData().getListOfMimeTypes());
			fingerprint.setCookieStatus(uiRequest.getEnforceData().getCookieStatus());
			enforceData.setDeviceFingerPrint(fingerprint);
			enforceData.setVzOrderId("");
			enforceData.setVzSessionId("");
			enforceData.setVisitorId(uiRequest.getEnforceData().getVisitorId());
			enforceData.setOrderStartTime("");
			enforceData.setOrderEndTime("");
			enforceData.setShareCartIndicator("");
			context.setEnforceData(enforceData);
		}


		context.setCustomerInfo(customerInfo);
		context.setContextInfo(contextInfo);

		context.setCaseId(uiRequest.getCartInfo().getCaseId());
		context.setCartInfo(cartInfo);

		serviceRequest.setContext(context);
		serviceBody.setServiceRequest(serviceRequest);
		pegaRequest.setServiceBody(serviceBody);
		return pegaRequest;

	}

	/**
	 *
	 * @param pegaRequest
	 * @param request
	 * @param throttleName
	 * @return pegaRequest
	 */
	public static UpdateBarCodePEGARequest formatUpdateBarCodeRequest(UpdateBarCodePEGARequest pegaRequest,
			UpdateBarcodeUIRequest request, String throttleName) {

		CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
		serviceHeader = addServiceHeader(serviceHeader);
		serviceHeader.setClientId(request.getChannelId());
		if(CartConstants.REX.equalsIgnoreCase(request.getCartInfo().getIntendType()))
			serviceHeader.setServiceName(CartConstants.SALES_ORDER_ADJUSTMENT);
		pegaRequest.setServiceHeader(serviceHeader);

		UpdateBarCodeServiceBody serviceBody = new UpdateBarCodeServiceBody();
		UpdateBarCodeServiceRequest serviceRequest = new UpdateBarCodeServiceRequest();
		UpdateBarCodeContext context = new UpdateBarCodeContext();

		CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
		customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
		customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
		customerInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());
		customerInfo.setCustomerType(request.getCartInfo().getCustomerType());
		//GTSFN-4415 add promo code cart creator,globalid implentation for NSEACC standalone accessory
		if(CartConstants.NSEACC.equalsIgnoreCase(request.getCartInfo().getIntendType())) 
		  customerInfo.setGlobalId(request.getCartInfo().getGlobalId());
		//GTSFN-4415 add promo code cart creator,globalid implentation for NSEACC standalone accessory
		if (StringUtilities.isNotEmptyOrNull(request.getExpressCheckout())
				&& Boolean.parseBoolean(request.getExpressCheckout())) {
				if(enableCradleForExistingCustomer){
					customerInfo.setCradleFlowJourney(CartConstants.PROMO_HUB);
				}
		}

		CartServiceCartInfo cartInfo = new CartServiceCartInfo();
		cartInfo.setCartId(request.getCartInfo().getCartId());
		cartInfo.setClientAppName(request.getCartInfo().getClientAppName());
		cartInfo.setAction(CartConstants.UPDATE);

		cartInfo.setItemType("BARCODE");

		if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType()))
			cartInfo.setIntendType(request.getCartInfo().getIntendType());
		else
			cartInfo.setIntendType(CartConstants.EUP);

		if (request.getCartInfo().getBarCodeIds()!=null)
			cartInfo.setBarCodeIds(request.getCartInfo().getBarCodeIds());

		if (StringUtilities.isNotEmptyOrNull(request.getData().getIncludeExpiryBarcodeStatus()))
			cartInfo.setIncludeExpiryBarcodeStatus(request.getData().getIncludeExpiryBarcodeStatus());
		else
			cartInfo.setIncludeExpiryBarcodeStatus("N");

		CartServiceContextInfo contextInfo = new CartServiceContextInfo();
		contextInfo = addContextInfo(contextInfo, CartConstants.UPDATE_BARCODE,
				request.getCartInfo().getClientAppName());
		if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessStep()))
			contextInfo.setProcessStep(request.getCartInfo().getProcessStep());
		else
			contextInfo.setProcessStep(CartConstants.SHOPPING_CART);

		contextInfo.setProcessAction(CartConstants.ADD_BARCODE_OFFER);

		// 
		if(CartConstants.REX.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
					contextInfo.setCallReason(CartConstants.SALES_ORDER_ADJUSTMENT);
					contextInfo.setIntent(CartConstants.REX);
				}
		if (CollectionUtilities.isNotEmptyOrNull(request.getData().getLines())) {
			List<Line> lines = new ArrayList<>();

			for (Lines reqLine : request.getData().getLines()) {
				Line newLine = new Line();
				if (reqLine.getMtn() != null)
					newLine.setMtn(reqLine.getMtn());
				lines.add(newLine);
			}
			Line[] lineArr = new Line[lines.size()];
			lines.toArray(lineArr);

			cartInfo.setLines(lineArr);
		}

		if (StringUtilities.isNotEmptyOrNull(throttleName)) {
			customerInfo.setThrottleName(throttleName);
			customerInfo.setCradleFlowJourney(CartConstants.PROMO_HUB);
		}
		if (CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())
				|| CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType()) || CartConstants.NSEACC.equalsIgnoreCase(request.getCartInfo().getIntendType()) ) {
			CartPegaRequestUtil7.newCustomerOverride(contextInfo, customerInfo, request.getCartInfo(), request.getChannelId());
		}
		context.setCustomerInfo(customerInfo);
		//MVP2
		if(request.getCartInfo()!=null && request.getCartInfo().getCaseId()!=null && request.getCartInfo().getCaseId().startsWith("SOF")){
			logger.info("SalesOrderFlex Prepay update Barcode Request before PEGA call setting Call Reason");
			context.setCaseId(request.getCartInfo().getCaseId());
			contextInfo.setCallReason(CartConstants.SALES_ORDER_FLEX);
			serviceHeader.setServiceName(CartConstants.SALES_ORDER_FLEX);
			if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())) {
				contextInfo.setIntent(request.getCartInfo().getIntendType());
				cartInfo.setIntendType(request.getCartInfo().getIntendType());
			}
		}
		
		context.setCartInfo(cartInfo);
		context.setContextInfo(contextInfo);
		context.setCaseId(request.getCartInfo().getCaseId());
		context.setCartInfo(cartInfo);
		serviceRequest.setContext(context);
		serviceBody.setServiceRequest(serviceRequest);
		pegaRequest.setServiceBody(serviceBody);
		return pegaRequest;
	}
	
	/**
	 * Method to check trial customer flow
	 * 
	 * @param flowType
	 * @return
	 */
	public static boolean isTrialCustomerFlow(String flowType) {
		return (StringUtilities.isNotEmptyOrNull(flowType) && CartConstants.FLOW_TYPE_DVM.equals(flowType));
		
	}
	
	/**
	 * Method to check browser cookie if DVM conversion flag true
	 * 
	 * @return
	 */
	public static boolean isDvmConversionFlagExists() {
		String dvmConversion = "";
		boolean dvmConversionFlag = false;
		try {
			dvmConversion = RequestAccessContext.obtainCookie(Arrays.asList(CartConstants.DVM_CONVERSION_COOKIE));
			logger.info("DVM conversion cookie value is {} ", dvmConversion);
			dvmConversionFlag = (StringUtilities.isNotEmptyOrNull(dvmConversion) && Boolean.parseBoolean(dvmConversion));
		} catch(Exception e) {
			logger.error("Requestcontext getcookie throwing an error in dvm",e);
		}		
		logger.info("dvmConversionFlag {} : ", dvmConversionFlag);
		return dvmConversionFlag;
	}
	
	/**
	 * Method to fetch comvzid from Header
	 * 
	 * @return
	 */
	public static String fetchComVzIdFromHeader() {
		String vzId = "";
		if (StringUtilities.isNotEmptyOrNull(RequestAccessContext.getRequestHeader(CartConstants.COM_VZ_ID))) {
		    vzId = RequestAccessContext.getRequestHeader(CartConstants.COM_VZ_ID);
		} else {
		    vzId = RequestAccessContext.getRequestHeader(SOEConstants.VZID_HEADERNAME);
		}
		logger.info("comvzid/vztid from Header is {}", vzId);
		return vzId;

	}
	
}
