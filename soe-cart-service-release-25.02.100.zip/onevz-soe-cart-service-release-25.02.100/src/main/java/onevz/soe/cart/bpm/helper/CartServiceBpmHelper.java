package onevz.soe.cart.bpm.helper;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.bpm.service.CartServiceBPMServices;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.initiatecart.CpcFeatureRequest;
import onevz.soe.cart.initiatecart.CpcFeatureResponse;
import onevz.soe.cart.initiatecart.InitiateCartUIResponse;
import onevz.soe.cart.model.AccessoryFinancingOffers.AccessoryFinancingOffersPegaRequest;
import onevz.soe.cart.model.AccessoryFinancingOffers.AccessoryFinancingOffersPegaResponse;
import onevz.soe.cart.model.addTrialContactInfoAndAddress.AddTrialContactInfoAndAddressUIRequest;
import onevz.soe.cart.model.addTrialContactInfoAndAddress.AddTrialContactInfoAndAddressUIResponse;
import onevz.soe.cart.model.autoPay.AutoPayCartInfo;
import onevz.soe.cart.model.autoPay.AutoPayContext;
import onevz.soe.cart.model.autoPay.PaymentInfo;
import onevz.soe.cart.model.common.Address;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.common.CartServiceServiceHeader;
import onevz.soe.cart.model.indirectRemoveLine.ExContext;
import onevz.soe.cart.model.indirectRemoveLine.ExContextInfo;
import onevz.soe.cart.model.indirectRemoveLine.IndirectRemoveLineServiceBody;
import onevz.soe.cart.model.indirectRemoveLine.IndirectRemoveLinesServiceRequest;
import onevz.soe.cart.model.initiateValidateDeviceSim.InitiateValidateDeviceSimUIRequest;
import onevz.soe.cart.model.initiateValidateDeviceSim.InitiateValidateDeviceSimUIResponse;
import onevz.soe.cart.requests.*;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.cart.util.*;
import onevz.soe.orderprocess.model.checkoutdetails.CreditCardPayment;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.bpm.model.CustomerInfo;
import onevz.soe.wsclient.bpm.model.ServiceBody;
import onevz.soe.wsclient.bpm.model.ServiceHeader;
import onevz.soe.wsclient.bpm.model.request.ContextInfo;
import onevz.soe.wsclient.bpm.model.request.ServiceRequest;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import jakarta.validation.Valid;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

@Service
public class CartServiceBpmHelper {

	private static final Logger logger = LoggerFactory.getLogger(CartServiceBpmHelper.class);


	@Autowired
	private CartServiceBPMServices services;

	@Autowired
	private RedisHelper redisHelper;

	@Autowired
	private ObjectMapper mapper;

	@Value("${planSku}")
	private boolean planSku;

	@Autowired
	SOELoginSessionBean soeLoginSessionBean;

	/**
	 * Bbp get process step.
	 *
	 * @param uiRequest the ui request
	 * @return the mono
	 */
	public Mono<BbpGetProcessStepUIResponse> bbpGetProcessStep(BBPGetProcessStepUIRequest uiRequest) {

		logger.debug("Inside CartServiceBpmHelper --> bbpGetProcessStep");

		BBPGetProcessStepPEGARequest pegaRequest = new BBPGetProcessStepPEGARequest();

		// convert ui request to pega request
		pegaRequest = CartPegaRequestUtil7.formatbbpGetProcessStepRequest(pegaRequest, uiRequest);
		logger.debug("BBPGetProcessStep PEGA Request: {}", pegaRequest);
		Mono<BbpGetProcessStepPEGAResponse> responseServiceMono = null;

		try {
			// pega call
			responseServiceMono = services.bbpGetProcessStep(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}

		BbpGetProcessStepUIResponse soeResponse = new BbpGetProcessStepUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {

			CartPegaResponseUtil.formatProcessStepResponse(soeResponse, pegaResponse);

			return Mono.just(soeResponse);
		});
	}

	/**
	 *
	 * @param removeLockRequest
	 * @return
	 */
	public Mono<RemoveLockUIResponse> removeLock(RemoveLockRequest removeLockRequest) {

		RemoveLockPEGARequest pegaRequest = new RemoveLockPEGARequest();
		pegaRequest = CartPegaRequestUtil7.formatRemoveLockRequest(pegaRequest, removeLockRequest);

		Mono<RemoveLockPEGAResponse> responseServiceMono = null;
		try {
			responseServiceMono = services.removeLock(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		RemoveLockUIResponse soeResponse = new RemoveLockUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {

			CartPegaResponseUtil1.formatRemoveLockResponse(soeResponse, pegaResponse);

			return Mono.just(soeResponse);
		});
	}

	/**
	 *
	 * @param uiRequest
	 * @return
	 * @throws JsonProcessingException
	 */

	public Mono<RetrieveActivationStatusUIResponse> retrieveActivationStatus(
			RetrieveActivationStatusUIRequest uiRequest) {
		logger.info("Inside CartServiceBpmHelper --> retrieveActivationStatus");
		RetrieveActivationStatusPEGARequest request = new RetrieveActivationStatusPEGARequest();

		// convert ui request to pega request
		CartPegaRequestUtil7.formatRetrieveActivationStatusRequest(request, uiRequest);

		logger.info("retrieveActivationStatus PEGA Request: {}", request);
		Mono<RetrieveActivationStatusPEGAResponse> responseServiceMono = null;

		try { // pega call responseServiceMono =
			logger.info("Before calling PEGA");
			String pegaRequest = mapper.writeValueAsString(request);
			logger.info("Pega Request is: {}", pegaRequest);
			responseServiceMono = services.retrieveActivationStatus(request);
		} catch (JsonProcessingException je) {
			logger.error("Error is", je);
		} catch (SOEHTTPException se) {
			logger.info("After calling PEGA");
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, se);
		}
		RetrieveActivationStatusUIResponse soeResponse = new RetrieveActivationStatusUIResponse();
		return responseServiceMono == null ? Mono.just(new RetrieveActivationStatusUIResponse())
				: responseServiceMono.flatMap(pegaResponse -> {

			// convert pega response to ui response
			CartPegaResponseUtil.formatRetrieveActivationStatusResponse(soeResponse, pegaResponse);
			return Mono.just(soeResponse);
		});
	}

	/**
	 *
	 * @param pegaRequest
	 * @return addMoversResp
	 */
	public Mono<AddMoveDatesUIResponse> addCustomerMoveDates(AddMoveDatesPegaRequest pegaRequest) {
		Mono<AddMoveDatesPegaResponse> responseServiceMono = null;
		AddMoveDatesUIResponse soeResponse=new AddMoveDatesUIResponse();
		try {
			responseServiceMono = services.addMoversDate(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.EXCEPTION_OCCURRED + ": {}", e);

		}
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
			logger.info("response Pega for Move Now : {}", pegaResponse.getServiceBody());
			CartPegaResponseUtil1.formatMoveDatesResponse(soeResponse, pegaResponse);
			return Mono.just(soeResponse);
		}).onErrorResume(err -> {
			logger.info("Error while calling Pega for Move Now : {}", err.getMessage());
			SOEHTTPException exception = (SOEHTTPException) err;
			List<CartError> errors = new ArrayList<>();
			exception.getErrorHolder().getErrors().forEach(soeError -> {
				CartError error = new CartError();
				error.setMessage(soeError.getMessage());
				error.setId(soeError.getId());
				error.setNamespace(soeError.getNamespace());
				error.setName(soeError.getName());
				error.setDebug_id(soeError.getDebug_id());
				errors.add(error);
			});

			soeResponse.setErrors(errors);
			return Mono.just(soeResponse);
		});
	}

	public Mono<MoversUpdatePlanResponse> updateCustomerMoverPlan(MoversUpdatePlanPegaRequest pegaRequest) {
		Mono<MoversUpdatePlanPegaResponse> responseServiceMono = null;
		MoversUpdatePlanResponse soeResponse=new MoversUpdatePlanResponse();
		try {
			responseServiceMono = services.updateCustomerMoverPlan(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.EXCEPTION_OCCURRED + ": {}", e);
		}
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
			logger.info("response Pega for update plan : {}", pegaResponse.getServiceBody());
			CartPegaResponseUtil1.formatUpdatePlanResponse(soeResponse, pegaResponse);
			return Mono.just(soeResponse);
		}).onErrorResume(err -> {
			logger.error("Error while calling Pega for update plan : {}", err.getMessage());
			SOEHTTPException exception = (SOEHTTPException) err;
			List<CartError> errors = new ArrayList<>();
			exception.getErrorHolder().getErrors().forEach(soeError -> {
				CartError error = new CartError();
				error.setMessage(soeError.getMessage());
				error.setId(soeError.getId());
				error.setNamespace(soeError.getNamespace());
				error.setName(soeError.getName());
				error.setDebug_id(soeError.getDebug_id());
				errors.add(error);
			});
			soeResponse.setErrors(errors);
			return Mono.just(soeResponse);
		});

	}

	/**
	 *
	 * @param addPlanAndDeviceRequest
	 * @return addPlanAndDeviceResp
	 */
	public Mono<AddPlanAndDeviceUIResponse> addPlanAndDevice(AddPlanAndDeviceUIRequest addPlanAndDeviceRequest) {

		AddPlanAndDevicePEGARequest pegaRequest = new AddPlanAndDevicePEGARequest();
		pegaRequest = CartPegaRequestUtil8.formatAddPlanAndDeviceRequest(pegaRequest, addPlanAndDeviceRequest);

		Mono<AddPlanAndDevicePEGAResponse> responseServiceMono = null;
		AddPlanAndDeviceUIResponse soeResponse = new AddPlanAndDeviceUIResponse();

		try {
			responseServiceMono = services.addPlanAndDevice(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.EXCEPTION_OCCURRED + ": {}", e);
		}
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
			logger.info("response Pega for Order Now : {}", pegaResponse.getServiceBody());
			CartPegaResponseUtil1.formataddPlanAndDeviceResponse(soeResponse, pegaResponse);

			return Mono.just(soeResponse);
		}).onErrorResume(err -> {
			logger.info("Error while calling Pega for Order Now : {}", err.getMessage());
			SOEHTTPException exception = (SOEHTTPException) err;
			List<CartError> errors = new ArrayList<>();
			exception.getErrorHolder().getErrors().forEach(soeError -> {
				CartError error = new CartError();
				error.setMessage(soeError.getMessage());
				error.setId(soeError.getId());
				error.setNamespace(soeError.getNamespace());
				error.setName(soeError.getName());
				error.setDebug_id(soeError.getDebug_id());
				errors.add(error);
			});
			soeResponse.setErrors(errors);
			return Mono.just(soeResponse);
		});
	}
	/**
	 *
	 * @param redisData
	 * @return soeResponse
	 */
	public Mono<AddPlanAndDeviceUIResponse> cpcUpdateCart(TechFlowRedisData redisData) {
		AddPlanAndDevicePEGARequest pegaRequest = new AddPlanAndDevicePEGARequest();
		CartPegaRequestUtil9.formatCpcUpdateCartRequest(pegaRequest, redisData);
		Mono<AddPlanAndDevicePEGAResponse> responseServiceMono = null;
		AddPlanAndDeviceUIResponse soeResponse = new AddPlanAndDeviceUIResponse();
		try {
			responseServiceMono = services.cpcUpdateCart(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error( CartConstants.EXCEPTION_OCCURRED + ": {}", e);

		}
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
			logger.info(CartConstants.RESPONSE_PEGA_CPC, pegaResponse.getServiceBody());
			CartPegaResponseUtil1.formataddPlanAndDeviceResponse(soeResponse, pegaResponse);
			return Mono.just(soeResponse);
		}).onErrorResume(err -> {
			logger.info(CartConstants.ERROR_PEGA_CPC, err.getMessage());
			SOEHTTPException exception = (SOEHTTPException) err;
			List<CartError> errors = new ArrayList<>();
			exception.getErrorHolder().getErrors().forEach(soeError -> {
				CartError error = new CartError();
				error.setMessage(soeError.getMessage());
				error.setId(soeError.getId());
				error.setNamespace(soeError.getNamespace());
				error.setName(soeError.getName());
				error.setDebug_id(soeError.getDebug_id());
				errors.add(error);
			});

			soeResponse.setErrors(errors);
			return Mono.just(soeResponse);
		});

	}

	/**
	 *
	 * @param redisData
	 * @return soeResponse
	 */
	public Mono<AddPlanAndDeviceUIResponse> cpcSubmitPlan(TechFlowRedisData redisData) {
		AddPlanAndDevicePEGARequest pegaRequest = new AddPlanAndDevicePEGARequest();
		CartPegaRequestUtil9.formatCpcSubmitPlanRequest(pegaRequest, redisData);
		Mono<AddPlanAndDevicePEGAResponse> responseServiceMono = null;
		AddPlanAndDeviceUIResponse soeResponse = new AddPlanAndDeviceUIResponse();
		try {
			responseServiceMono = services.cpcSubmitPlan(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error( CartConstants.EXCEPTION_OCCURRED + ": {}", e);

		}
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
			logger.info(CartConstants.RESPONSE_PEGA_CPC, pegaResponse.getServiceBody());
			CartPegaResponseUtil1.formataddPlanAndDeviceResponse(soeResponse, pegaResponse);
			return Mono.just(soeResponse);
		}).onErrorResume(err -> {
			logger.info(CartConstants.ERROR_PEGA_CPC, err.getMessage());
			SOEHTTPException exception = (SOEHTTPException) err;
			List<CartError> errors = new ArrayList<>();
			exception.getErrorHolder().getErrors().forEach(soeError -> {
				CartError error = new CartError();
				error.setMessage(soeError.getMessage());
				error.setId(soeError.getId());
				error.setNamespace(soeError.getNamespace());
				error.setName(soeError.getName());
				error.setDebug_id(soeError.getDebug_id());
				errors.add(error);
			});

			soeResponse.setErrors(errors);
			return Mono.just(soeResponse);
		});

	}

	/**
	 *
	 * @param customerInfo
	 * @return
	 */
	public Mono<InitiateCartUIResponse>cpcInitiateCart (CustomerInfo customerInfo, AddPlanAndDeviceUIRequest request) {
		CpcFeatureRequest pegaRequest = new CpcFeatureRequest();
		CartPegaRequestUtil9.formatCpcCartRequest(pegaRequest, customerInfo, request);
		Mono<CpcFeatureResponse> responseServiceMono = Mono.empty();
		InitiateCartUIResponse soeResponse = new InitiateCartUIResponse();
		try {
			responseServiceMono = services.cpcCreateCart(pegaRequest);
		} catch (Exception e) {
			logger.error( CartConstants.EXCEPTION_OCCURRED + ": {}", e);
		}
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
			logger.info(CartConstants.RESPONSE_PEGA_CPC, pegaResponse.getServiceBody());
			return redisHelper.saveFeatureInitiateCartInfo(pegaResponse)
					.then(Mono.fromRunnable(() -> CartPegaResponseUtil1.formatInitiateCartPegaResponse(pegaResponse, soeResponse)))
					.thenReturn(soeResponse);
		}).onErrorResume(err -> {
			logger.info(CartConstants.ERROR_PEGA_CPC, err.getMessage());
			SOEHTTPException exception = (SOEHTTPException) err;
			List<CartError> errors = new ArrayList<>();
			exception.getErrorHolder().getErrors().forEach(soeError -> {
				CartError error = new CartError();
				error.setMessage(soeError.getMessage());
				error.setId(soeError.getId());
				error.setNamespace(soeError.getNamespace());
				error.setName(soeError.getName());
				error.setDebug_id(soeError.getDebug_id());
				errors.add(error);

			});
			soeResponse.setErrors(errors);
            return Mono.just(soeResponse);
        });
	}

	/**
	 *
	 * @param uiRequest
	 * @return updateManualDiscountResp
	 */
	public Mono<UpdateManualDiscountUIResponse> addManualdiscount(UpdateManualDiscountUIRequest uiRequest) {

		ManualDiscountPEGARequest request = new ManualDiscountPEGARequest();

		logger.info("ManualDiscount UI Request After Session Call: {}", uiRequest);
		// convert uiRequest to pega request
		CartPegaRequestUtil8.formatManualDiscountRequest(request, uiRequest);
		logger.debug("ManualDiscount PEGA Request: {}", request);
		Mono<ManualDiscountPEGAResponse> responseServiceMono = null;
		try {
			// pega call
			responseServiceMono = services.addManualdiscount(request);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		UpdateManualDiscountUIResponse soeResponse = new UpdateManualDiscountUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
			// convert pega response to ui response
			CartPegaResponseUtil1.formatManualDiscountResponse(soeResponse, pegaResponse);
			return Mono.just(soeResponse);
		});
	}

	/**
	 *
	 * @param uiRequest
	 * @return updateEffectiveDateRes
	 */
	public Mono<UpdateEffectiveDateUIResponse> updateEffectiveDate(UpdateEffectiveDateUIRequest uiRequest) {

		EffectiveDatePEGARequest request = new EffectiveDatePEGARequest();

		logger.info("EffectiveDate UI Request After Session Call: {}", uiRequest);
		// convert uiRequest to pega request
		CartPegaRequestUtil8.formatEffectiveDateRequest(request, uiRequest);
		logger.debug("EffectiveDate PEGA Request: {}", request);
		Mono<EffectiveDatePEGAResponse> responseServiceMono = null;
		try {
			// pega call
			responseServiceMono = services.updateEffectiveDate(request);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		UpdateEffectiveDateUIResponse soeResponse = new UpdateEffectiveDateUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
			// convert pega response to ui response
			CartPegaResponseUtil1.formatEffectiveDateResponse(soeResponse, pegaResponse);
			return Mono.just(soeResponse);
		});
	}

	//VZWYN-20895 changes
	public Mono<InitiateValidateDeviceSimUIResponse> initiateValidateDeviceSim(InitiateValidateDeviceSimUIRequest uiRequest, ServerHttpRequest httpHeader, CartRedisData redisData) {

		logger.debug("Inside CartServiceBpmHelper --> initiateValidateDeviceSim");

		InitiateValidateDeviceSimPEGARequest pegaRequest = new InitiateValidateDeviceSimPEGARequest();

		// convert ui request to pega request
		pegaRequest = CartPegaRequestUtil8.formatInitiateValidateDeviceSimRequest(pegaRequest, uiRequest, httpHeader, redisData);
		logger.debug("Initiate Validate Device Sim PEGA Request: {}", pegaRequest);
		Mono<InitiateValidateDeviceSimPEGAResponse> responseServiceMono = null;

		try {
			// pega call
			responseServiceMono = services.initiateValidateDeviceSim(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}

		InitiateValidateDeviceSimUIResponse soeResponse = new InitiateValidateDeviceSimUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {

			logger.info("initiateValidateDeviceSim Pega response: {}", pegaResponse);

			CartPegaResponseUtil1.formatInitiateValidateDeviceSimResponse(soeResponse, pegaResponse);

			return Mono.just(soeResponse);
		});
	}

	/***
	 *
	 * @param uiRequest
	 * @return
	 */
	public Mono<AddPlanAndDeviceUIResponse> saveCartWithEmail(SaveCartWithEmailUIRequest uiRequest){
		AddPlanAndDevicePEGARequest pegaRequest = new AddPlanAndDevicePEGARequest();

		logger.info("SaveCartWithEmailUIRequest UI Request After Session Call: {}", uiRequest);
		// convert uiRequest to pega request

		CartPegaRequestUtil8.formatSaveCartWithEmailRequest(pegaRequest, uiRequest);
		try {
			ObjectMapper obmapper = new ObjectMapper();
			obmapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
			String pegaRequest1 = obmapper.writeValueAsString(pegaRequest);
			logger.info(pegaRequest1);
		}catch(Exception e){
			logger.error("Error is ",e);
		}
		logger.debug("SaveCartWithEmail PEGA Request: {}", pegaRequest);
		Mono<AddPlanAndDevicePEGAResponse> responseServiceMono = null;
		try {
			// pega call
			responseServiceMono = services.saveCartWithEmail(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		AddPlanAndDeviceUIResponse soeResponse = new AddPlanAndDeviceUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
			// convert pega response to ui response
			CartPegaResponseUtil1.formataddPlanAndDeviceResponse(soeResponse, pegaResponse);
			return Mono.just(soeResponse);
		});

	}

	/***
	 *
	 * @param cartId
	 * @param sessionId
	 * @return
	 */
	public Mono<CrmRetrieveCartUIResponse> crmRetrieveCart (String cartId,String sessionId,String emailId,String customerType,String accountNumber){
		AddPlanAndDevicePEGARequest pegaRequest = new AddPlanAndDevicePEGARequest();

		logger.info("crmRetrieveCart UI Request cart ID: {}", cartId);
		// convert uiRequest to pega request
		CartPegaRequestUtil8.formatCrmRetrieveCartRequest(pegaRequest, cartId,sessionId,emailId,customerType,accountNumber);
		logger.info("crmRetrieveCart PEGA Request: {}", pegaRequest);

		Mono<CrmRetrieveCartPegaResponse> responseServiceMono = null;
		try {
			// pega call
			responseServiceMono = services.crmRetrieveCart(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		CrmRetrieveCartUIResponse soeResponse = new CrmRetrieveCartUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
			// convert pega response to ui response
			CartPegaResponseUtil1.formataddPlanAndDeviceFromCRMResponse(soeResponse, pegaResponse);
			return Mono.just(soeResponse);
		});

	}

	/**
	 *
	 * @param uiRequest
	 * @return CreateCaseAndGetCustomerInfoUIResponse @
	 */
	public Mono<CreateCaseAndGetCustomerInfoUIResponse> createCase(CreateCaseAndGetCustomerInfoUIRequest uiRequest, ServerHttpRequest httpHeader,  String mtn) {

		logger.debug("Inside CartServiceBpmHelper --> createCase");

		CreateCasePEGARequest pegaRequest = new CreateCasePEGARequest();

		// convert ui request to pega request
		pegaRequest = CartPegaRequestUtil8.formatCreateCaseRequest(pegaRequest, uiRequest, httpHeader);
		logger.debug("Create Case PEGA Request: {}", pegaRequest);
		Mono<CreateCasePEGAResponse> responseServiceMono = null;

		try {
			// pega call
			responseServiceMono = services.createCase(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}

		CreateCaseAndGetCustomerInfoUIResponse soeResponse = new CreateCaseAndGetCustomerInfoUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {

			CartPegaResponseUtil1.formatCreateCaseResponse(soeResponse, pegaResponse, mtn);

			return Mono.just(soeResponse);
		});
	}

	/**
	 *
	 * @param uiRequest
	 * @return GuestChoiceUIResponse
	 * @throws JsonProcessingException
	 */
	public Mono<GuestChoiceUIResponse> guestChoice(GuestChoiceUIRequest uiRequest) {

		GuestChoicePEGARequest request = new GuestChoicePEGARequest();

		// convert uiRequest to pega request
		CartPegaRequestUtil8.formatGuestChoiceRequest(uiRequest, request);
		logger.debug("GuestChoice PEGA Request: {}", request);
		Mono<GuestChoicePEGAResponse> responseServiceMono = null;
		try {
			// pega call
			responseServiceMono = services.guestChoice(request);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		GuestChoiceUIResponse soeResponse = new GuestChoiceUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
			// convert pega response to ui response
			CartPegaResponseUtil1.formatGuestChoiceResponse(pegaResponse, soeResponse);
			return Mono.just(soeResponse);
		});
	}

	/**
	 *
	 * @param uiRequest
	 * @return GuestChoiceUIResponse
	 * @throws JsonProcessingException
	 */

	public Mono<CheckExistingCartUIResponse> checkExistingCart(CheckExistingCartUIRequest uiRequest) {
		CheckExistingCartPEGARequest request = new CheckExistingCartPEGARequest();
		// convert uiRequest to pega request
		CartPegaRequestUtil8.formatCheckExistingCartPegaRequest(uiRequest, request);
		logger.debug("CheckExistingCart PEGA Request: {}", request);
		Mono<CheckExistingCartPEGAResponse> responseServiceMono = null;
		try {
			// pega call
			responseServiceMono = services.checkExistingCart(request);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		CheckExistingCartUIResponse soeResponse = new CheckExistingCartUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
			// convert pega response to ui response
			CartPegaResponseUtil1.formatCheckExistingCartPegaResponse(pegaResponse, soeResponse);
			return Mono.just(soeResponse);
		});
	}

	/**
	 *
	 * @param uiRequest
	 * @return UpdateCartUIResponse
	 */
	public Mono<UpdateGiftItemUIResponse> updateGiftItem(UpdateGiftItemUIRequest uiRequest) {

		UpdateGiftItemPEGARequest pegaRequest = new UpdateGiftItemPEGARequest();

		// convert uiRequest to pegaRequest
		pegaRequest = CartPegaRequestUtil8.formatUpdateGiftItemRequest(pegaRequest, uiRequest);
		logger.debug("updateGiftItem PEGA Request: {}", pegaRequest);
		Mono<UpdateGiftItemPEGAResponse> responseServiceMono = null;
		try {
			// pega call
			responseServiceMono = services.updateGiftItem(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}

		UpdateGiftItemUIResponse soeResponse = new UpdateGiftItemUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
			// convert pegaResponse to uiResponse
			CartPegaResponseUtil1.formatUpdateGiftItemResponse(pegaResponse, soeResponse);
			return Mono.just(soeResponse);
		});
	}


	//VZWYN-17463 changes
	public Mono<AddTrialContactInfoAndAddressUIResponse> addTrialContactInfoAndAddress(AddTrialContactInfoAndAddressUIRequest uiRequest, CartRedisData redisData) {
		AddTrialContactInfoAndAddressPEGARequest request = new AddTrialContactInfoAndAddressPEGARequest();
		// convert uiRequest to pega request
		CartPegaRequestUtil8.formatAddTrialContactInfoAndAddressPegaRequest(uiRequest, request, redisData);
		logger.debug("addTrialContactInfoAndAddress PEGA Request: {}", request);
		Mono<AddTrialContactInfoAndAddressPEGAResponse> responseServiceMono = null;
		try {
			// pega call
			responseServiceMono = services.addTrialContactInfoAndAddress(request);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		AddTrialContactInfoAndAddressUIResponse soeResponse = new AddTrialContactInfoAndAddressUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
			// convert pega response to ui response
			CartPegaResponseUtil1.formatAddTrialContactInfoAndAddressPegaResponse(pegaResponse, soeResponse);
			return Mono.just(soeResponse);
		});
	}



	/**
	 *
	 * @param resp
	 */
	public static void removeSensitiveInfoForAssignMTN(AssignMtnUIResponse resp) {
		if (null != resp && resp.getServiceBody() != null
				&& resp.getServiceBody().getServiceResponse() != null
				&& resp.getServiceBody().getServiceResponse().getContext() != null) {

			resp.getServiceBody().getServiceResponse().getContext().setCaseId(null);
		}
		if (null != resp && resp.getServiceBody() != null && resp.getServiceBody().getServiceResponse().getContext().getCartInfo() != null)
			resp.getServiceBody().getServiceResponse().getContext().getCartInfo().setCartId(null);

	}

	/**
	 *
	 * @param resp
	 */
	public static void removeSensitiveInfoForValidateOrder(InitiateCheckoutUIResponse resp) {
		if (null != resp && resp.getServiceBody() != null
				&& resp.getServiceBody().getServiceResponse() != null
				&& resp.getServiceBody().getServiceResponse().getContext() != null) {

			resp.getServiceBody().getServiceResponse().getContext().setCaseId(null);
		}
		if (null != resp && resp.getServiceBody() != null && resp.getServiceBody().getServiceResponse().getContext().getCartInfo() != null)
			resp.getServiceBody().getServiceResponse().getContext().getCartInfo().setCartId(null);

	}

	/**
	 *
	 * @param uiRequest
	 * @return
	 */
	public Mono<AccessoryFinancingOffersUIResponse> updateAccessoryFinancingOffers(
			AccessoryFinancingOffersUIRequest uiRequest) {

		logger.debug("Inside CartServiceBpmHelper --> updateAccessoryFinancingOffers");
		AccessoryFinancingOffersPegaRequest request = new AccessoryFinancingOffersPegaRequest();

		// convert ui request to pega request
		CartPegaRequestUtil8.formatAFOPegaRequest(uiRequest, request);

		logger.debug("updateAccessoryFinancingOffers PEGA Request: {}", request);
		Mono<AccessoryFinancingOffersPegaResponse> responseServiceMono = null;

		try {
			responseServiceMono = services.updateAccessoryFinancingOffers(request);
		} catch (SOEHTTPException e) {
			logger.error("Inside CartServiceBpmHelper --> updateAccessoryFinancingOffers :: ", e);
		}

		AccessoryFinancingOffersUIResponse soeResponse = new AccessoryFinancingOffersUIResponse();
		return responseServiceMono == null ? Mono.just(new AccessoryFinancingOffersUIResponse())
				: responseServiceMono.flatMap(pegaResponse -> {
			// convert pega response to ui response
			CartPegaResponseUtil1.formatAccessoryFinancingOffersResponse(soeResponse, pegaResponse);
			return Mono.just(soeResponse);
		});
	}

	/**
	 *
	 * @param request
	 * @return indirectExCustRemoveLinePegaRes
	 */
	public Mono<IndirectExCustRemoveLinePEGARes> indirectexremoveLines(ExCustIndirectRemoveLinesServiceUIRequest request) {

		IndirectExCustRemoveLinePEGAReq indirectExCustRemoveLinePEGAReq=new IndirectExCustRemoveLinePEGAReq();


		CartServiceServiceHeader serviceHeader=new CartServiceServiceHeader ();
		indirectExCustRemoveLinePEGAReq.setServiceHeader(serviceHeader);
		indirectExCustRemoveLinePEGAReq = CartPegaRequestUtil8.formatIndirectCustRemoveLinesRequest(indirectExCustRemoveLinePEGAReq, request);
		IndirectRemoveLineServiceBody serviceBody=new IndirectRemoveLineServiceBody();
		IndirectRemoveLinesServiceRequest serviceRequest=new IndirectRemoveLinesServiceRequest();
		if(request.getContext().getContextInfo().getIntent().equalsIgnoreCase(CartConstants.REX) ||
				request.getContext().getCartInfo().getIntendType().equalsIgnoreCase(CartConstants.REX))
		{
			ExContext exContext = request.getContext();
			ExContextInfo exContextInfo = request.getContext().getContextInfo();
			exContextInfo.setCallReason(CartConstants.SALES_ORDER_ADJUSTMENT);
			exContext.setContextInfo(exContextInfo);
			serviceRequest.setContext(exContext);

		}
		else {
			serviceRequest.setContext(request.getContext());
		}
		serviceBody.setServiceRequest(serviceRequest);
		indirectExCustRemoveLinePEGAReq.setServiceBody(serviceBody);
		Mono<IndirectExCustRemoveLinePEGARes> indirectExCustRemoveLinePEGARes=null;
		try
		{
			indirectExCustRemoveLinePEGARes = services.exCustRemoveLine(indirectExCustRemoveLinePEGAReq);
		}
		catch (SOEHTTPException e)
		{
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		return indirectExCustRemoveLinePEGARes;

	}

	/**
	 *
	 * @param caseId
	 * @param accNumber
	 * @param amRole
	 * @param request
	 * @return
	 */
	public Mono<RPSE911AddressUpdateUIResponse> updateAddressChange(String caseId, String accNumber, String amRole,
																	RPSE911AddressUpdateUIRequest request) {
		UpdateAddressChangePEGARequest pegaRequest = new UpdateAddressChangePEGARequest();
		// format pega request
		pegaRequest = CartPegaRequestUtil9.formatUpdateAddressChangePEGARequest(caseId, accNumber,amRole, request, pegaRequest);
		logger.debug("UpdateAddressChange PEGA Request: {}", pegaRequest);
		Mono<UpdateAddressChangePEGAResponse> responseServiceMono = null;
		RPSE911AddressUpdateUIResponse soeResponse = new RPSE911AddressUpdateUIResponse();

		try {
			// pega call
			responseServiceMono = services.updateAddressChange(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}

		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
			// convert cjcmResponse to uiResponse
			CartPegaResponseUtil1.formatUpdateAddressChangeUiResponse(pegaResponse, soeResponse);

			redisHelper.getDataFromRedis().flatMap(data -> {
				if (StringUtilities.isNotEmptyOrNull(data.getSuccessUrl())) {
					soeResponse.getData().setSuccessUrl(data.getSuccessUrl());
				}
				return Mono.just(soeResponse);
			});

			return Mono.just(soeResponse);
		});
	}
	/**
	 *
	 * @param accNumber
	 * @param mtn
	 * @param channelId
	 * @return
	 */
	public Mono<InitiateAddressChangePEGAResponse> initiateAddressChange(String accNumber, String mtn,
																		 String channelId) { // 2785-start
		InitiateAddressChangePEGARequest request = new InitiateAddressChangePEGARequest();
		// format pega request
		request = CartPegaRequestUtil9.formatInitiateAddressChangePEGARequest(accNumber, mtn, channelId, request);
		logger.debug("InitiateAddressChange PEGA Request: {}", request);
		Mono<InitiateAddressChangePEGAResponse> responseServiceMono = null;
		try {
			// pega call
			responseServiceMono = services.initiateAddressChange(request);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		return responseServiceMono;
	}

	public Mono<AddPlanAndDeviceUIResponse> validateAndApplyFWACouponCode(@Valid FWAUpdateCouponUIRequest uiRequest) {
		logger.debug("Inside CartServiceBpmHelper -->  validateAndApplyFWACouponCode");
		AddPlanAndDevicePEGARequest pegaRequest =  new AddPlanAndDevicePEGARequest();
		CartPegaRequestUtil7.formatValidateAndApplyCouponRequest(pegaRequest, uiRequest);
		logger.debug("updateAffirmFinancingStatus PEGA Request: {}", pegaRequest);
		Mono<AddPlanAndDevicePEGAResponse> pegaResponseMono =  null;
		try {
			pegaResponseMono = services.addPlanAndDevice(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error("Inside CartServiceBpmHelper --> updateAffirmFinancingStatus :: ", e);
		}
		AddPlanAndDeviceUIResponse soeResponse = new AddPlanAndDeviceUIResponse();
		return pegaResponseMono == null ? Mono.just(new AddPlanAndDeviceUIResponse())
				: pegaResponseMono.flatMap(pegaResponse -> {
			// convert pega response to ui response
			CartPegaResponseUtil1.formataddPlanAndDeviceResponse(soeResponse, pegaResponse);
			return Mono.just(soeResponse);
		}).onErrorResume(throwable -> {
			logger.info("Error while calling Pega for validateAndApplyFWACouponCode : {}", throwable.getMessage());
			SOEHTTPException exception = (SOEHTTPException) throwable;
			List<CartError> errors = new ArrayList<>();
			exception.getErrorHolder().getErrors().forEach(cxpError -> {
				CartError error = new CartError();
				error.setMessage(cxpError.getMessage());
				error.setId(cxpError.getId());
				error.setNamespace(cxpError.getNamespace());
				error.setName(cxpError.getName());
				error.setDebug_id(cxpError.getDebug_id());
				errors.add(error);
			});
			soeResponse.setErrors(errors);
			return Mono.just(soeResponse);
		});

	}
	public Mono<AutoPayPegaResponse> autoPayFlow(AutoPayUIRequest request, String channelId)
	{
		Mono<AutoPayPegaResponse> autoPayUIRes=null;

		try
		{

			final List<String> redisKey = Arrays.asList( CartConstants.LOCATION_CODE,"processingMTN", "cartCreator","mtn", CartConstants.ACCOUNT_NUMBER, CartConstants.LOGGEDINUSER, "repId", CartConstants.CASE_ID, CartConstants.INTEND_TYPE );
			HashMap<Object, Object> res1 = new HashMap<>();
			autoPayUIRes= soeLoginSessionBean.getSessionData(redisKey).onErrorReturn(res1).defaultIfEmpty(res1).flatMap(res ->
			{

				AutoPayPegaRequest autoPayPegaRequest=new AutoPayPegaRequest();
				Mono<AutoPayPegaResponse> autoPayPegaResponse=Mono.just(new AutoPayPegaResponse());
				ServiceHeader serviceHeader=new ServiceHeader();

				ContextInfo contextInfo=new ContextInfo();
				CustomerInfo customerInfo = new CustomerInfo();
				AutoPayCartInfo cartInfo=new AutoPayCartInfo();

				serviceHeader.setClientId(channelId);
				serviceHeader.setStatusMsg("payment-soe generated message");
				String caseId= res.getOrDefault(CartConstants.CASE_ID,"").toString();
				if( caseId.startsWith("SOF") && StringUtilities.isNotEmptyOrNull(caseId) )
				{

					logger.info("SalesOrderFlex Prepay accountLandingService createRequestForBPM service before PEGA call setting Call Reason");
					serviceHeader.setServiceName("SalesOrderFlex");
					contextInfo.setCallReason("SalesOrderFlex");
				}
				serviceHeader.setUserId(res.getOrDefault(CartConstants.LOGGEDINUSER,"").toString());
				serviceHeader.setStatusCode("0");
				serviceHeader.setSessionId("");
				serviceHeader.setCorrelationId("");


				contextInfo.setProcessStep("Payment-Agreement");
				contextInfo.setProcessAction("AutoPay");
				contextInfo.setIntent(res.getOrDefault(CartConstants.INTEND_TYPE, "").toString());
				customerInfo.setAccountNumber((res.get(CartConstants.ACCOUNT_NUMBER)!=null) ? res.get(CartConstants.ACCOUNT_NUMBER).toString(): "");
				customerInfo.setRegisterNumber(0);
				customerInfo.setProcessingMTN((res.get("mtn")!=null) ? res.get("mtn").toString(): "");
				cartInfo.setCartId(request.cartId);

				ContactDetails contactDetails=new ContactDetails();
				Address address=new Address();
				address.setApartmentNo("");
				address.setZipCode(request.getAddress().getZipCode());
				address.setZipCode4(request.getAddress().getZipCode4());
				address.setCountry(request.getAddress().getCountry());
				address.setStreetNumber("");
				address.setCity(request.getAddress().getCity());
				address.setAddressLine1(request.getAddress().getAddressLine1());
				address.setAddressLine2("");
				address.setState(request.getAddress().getState());

				contactDetails.setAddress(address);
				contactDetails.setFirstName(request.getFullName());
				contactDetails.setLastName("");
				contactDetails.setContactNumber(request.getContactPhoneNumber());

				cartInfo.setContactDetails(contactDetails);

				PaymentInfo paymentInfo=new PaymentInfo();
				paymentInfo.setPaymentAmount(request.getPaymentAmount());

				CreditCardPayment creditCardPayment=new CreditCardPayment();
				creditCardPayment.setCardAddressZip("");
				creditCardPayment.setTokenizedValue("");
				creditCardPayment.setEncryptedCardData2("");
				creditCardPayment.setCardExpDate(request.getCardExpirationDate());
				creditCardPayment.setCardNumber(request.getCreditCardNumber());
				creditCardPayment.setEncryptType("");
				creditCardPayment.setEncryptedCardData(request.getCreditCardNumber());
				creditCardPayment.setCardType(request.getCardType());

				PaymentData paymentData=new PaymentData();
				paymentData.setCreditCardPayment(creditCardPayment);

				paymentInfo.setPaymentData(paymentData);


				AutoPayContext context=new AutoPayContext();
				context.setCaseId(caseId);
				context.setContextInfo(contextInfo);
				context.setCustomerInfo(customerInfo);
				context.setCartInfo(cartInfo);
				context.setPaymentInfo(paymentInfo);
				context.setLocationCode(res.getOrDefault(CartConstants.LOCATION_CODE,"").toString());
				ServiceRequest serviceRequest=new ServiceRequest();
				serviceRequest.setContext(context);

				ServiceBody serviceBody=new ServiceBody();
				serviceBody.setServiceRequest(serviceRequest);

				autoPayPegaRequest.setServiceHeader(serviceHeader);
				autoPayPegaRequest.setServiceBody(serviceBody);

				try
				{
					autoPayPegaResponse = services.autoPayFlow(autoPayPegaRequest);
				} catch (Exception e)
				{
					logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
				}
				return autoPayPegaResponse;
			});
		} catch(Exception e)
		{
			logger.error(String.format("Exception : %s",e));
		}
		return autoPayUIRes;
	}

}
