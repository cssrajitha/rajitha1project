package onevz.soe.cart.cxp.helper;

import onevz.aem.errorhandling.service.CartAEMService;
import onevz.aem.request.ProspectDeviceModelMappingRequest;
import onevz.aem.response.DeviceModelMap;
import onevz.aem.response.ESim;
import onevz.aem.response.PSim;
import onevz.cxp.feature.Flag;
import onevz.cxp.feature.util.FeatureFlag;
import onevz.soe.cart.constants.FeatureFlagConstants;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.gql.response.GetPairedDeviceInfoGQLResponse;
import onevz.soe.cart.helper.FeatureFlagHelper;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.helper.RedisHelper2;
import onevz.soe.cart.helper.RedisHelper3;
import onevz.soe.cart.model.catalog.FeatureCatalogItem;
import onevz.soe.cart.model.common.Device;
import onevz.soe.cart.model.custProfile.SalesRepCustomer;
import onevz.soe.cart.model.deviceIdValidation.DeviceIdValidationData;
import onevz.soe.cart.model.deviceIdValidation.DeviceIdValidationLine;
import onevz.soe.cart.model.deviceIdValidation.SearchAttributes;
import onevz.soe.cart.model.deviceIdValidation.WireLineAccountInformation;
import onevz.soe.cart.model.deviceSimValidation.CustomerReqType;
import onevz.soe.cart.model.initiateCbandCheck.FixedWirelessOrders;
import onevz.soe.cart.model.initiateDeviceSimActivation.InitiateDeviceSimActivationUIResponse;
import onevz.soe.cart.model.initiateDeviceSimActivation.IntiateDeviceSimActivationUIRequest;
import onevz.soe.cart.model.initiateESimActivation.InitiateESimActivationUIResponse;
import onevz.soe.cart.model.initiateESimActivation.IntiateESimActivationUIRequest;
import onevz.soe.cart.model.initiateValidateDeviceSim.CustomerRequestType;
import onevz.soe.cart.model.initiateValidateDeviceSim.InitiateValidateDeviceSimUIResponse;
import onevz.soe.cart.model.mylink.MylinkReferralInfoRequest;
import onevz.soe.cart.model.mylink.MylinkReferralInfoResponse;
import onevz.soe.cart.model.numberlinkE911Address.AddressRequest;
import onevz.soe.cart.requests.DeviceIdValidationMeta;
import onevz.soe.cart.requests.*;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.smartimeisearch.DeviceIdValidationRequestFormatter;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.cart.util.*;
import onevz.soe.exception.SOEErrorHolder;
import onevz.soe.omnidl.service.OmniDLService;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.*;
import java.util.stream.Collectors;

import static onevz.soe.cart.constants.CartConstants.LTE;
import static onevz.soe.cart.constants.CartConstants.REASON_CODE_MS;

/**
 * CartService Cxp Helper class.
 */
@Service
public class CartServiceCxpHelper2 {

	private static final Logger logger = LoggerFactory.getLogger(CartServiceCxpHelper.class);
	private static final String MYLINK = "MYLINK";

	@Autowired
	private CartServiceCXPServices cxpService;

	@Autowired
	private CartAEMService cartAEMService;

	@Autowired
	OmniDLService dlService;

	@Autowired
	private DeviceIdValidationRequestFormatter formatter;

	@Autowired
	private RedisHelper redisHelper;

	@Autowired
	private RedisHelper2 redisHelper2;

	@Autowired
	private RedisHelper3 redisHelper3;

	@Autowired
	private Environment environment;
	
	@Autowired
    private CommonUtil util;

	@Value("${enableOptimisedDigitalRetrieveCart}")
	private boolean enableOptimisedDigitalRetrieveCart;

	@Value("${smart.imei.empty.carrier.altname:OTHER}")
	private String SMART_IMEI_EMPTY_CARRIER_ALT_NAME;

	@Value("${smart.imei.typeahead.merge.enabled:Y}")
	private String SMART_IMEI_TYPEAHEAD_MERGE_ENABLED;

	@Value("${smart.imei.empty.carrier.device.enabled:Y}")
	private String EMPTY_CARRIER_DEVICES_FOR_SMART_IMEI_ENABLED;
	
	@Value("${smart.imei.supress.carriers:other}")
	private String SMART_IMEI_SUPPRESS_CARRIERS;
	
	@Value("${enableESimDevicesWithoutSuffix:false}")
	private boolean enableESimDevicesWithoutSuffix;
	
	@Value("#{'${smart.imei.typeahead.simOutKeywords:}'.split(',')}")
	private List<String> simOutWordList;

	@Autowired
    FeatureFlag featureFlag;
	
	@Autowired
	FeatureFlagHelper featureFlagHelper;

	/**
	 *
	 * @param uiRequest
	 * @return soeResponse
	 *
	 */
	public Mono<VZCCAppStatusUIResponse> updateVZCCAppStatus(VZCCAppStatusUIRequest uiRequest) {
		VZCCAppStatusCXPRequest cxpRequest = new VZCCAppStatusCXPRequest();

		// convert uiRequest to cxpRequest
		cxpRequest = CartCxpRequestUtil.formatVZCCAppStatusRequest(uiRequest, cxpRequest);
		Mono<VZCCAppStatusCXPResponse> responseServiceMono = cxpService.updateVZCCAppStatus(cxpRequest);

		VZCCAppStatusUIResponse soeResponse = new VZCCAppStatusUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(cartResponse -> {

			// convert cxpResponse into soeResponse
			CartCxpResponseUtil.formatVZCCAppStatusResponse(soeResponse, cartResponse);
			return Mono.just(soeResponse);
		});
	}

	//VZWYN-20895 changes
	public Mono<InitiateValidateDeviceSimUIResponse> customerNameByMtn(ArrayList<String> mtnList) {
		String[] mtnArray = new String[mtnList.size()];
		mtnArray = mtnList.toArray(mtnArray);
		CustomerRequestType customerRequestType = new CustomerRequestType();
		customerRequestType.setMtnList(mtnArray);
		logger.info("GQL request: {}", customerRequestType);
		Mono<CustomerNameByMtnCXPResponse> responseServiceMono = cxpService
				.customerNameByMtn(customerRequestType);

		InitiateValidateDeviceSimUIResponse soeResponse = new InitiateValidateDeviceSimUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(cartResponse -> {

			logger.info("customerNameByMtn CXP response: {}", cartResponse);
			// convert cxpResponse into soeResponse
			CartCxpResponseUtil1.formatCustomerNameByMtnResponse(soeResponse, cartResponse);
			return Mono.just(soeResponse);
		});

	}

	/**
	 *
	 * @param uiRequest
	 * @return soeResponse
	 */
	public Mono<MyOffersCXPResponse> updateMyOffers(MyOffersCXPRequest uiRequest) {

		return cxpService.updateMyOffers(uiRequest);
	}

	/**
	 *
	 * @param uiRequest
	 * @return UpdateUserInfoUIResponse
	 */
	public Mono<RPSE911AddressUpdateUIResponse> updateRPSE911Address(RPSE911AddressUpdateUIRequest uiRequest) {

		RPSE911AddressUpdateCXPRequest cxpRequest = new RPSE911AddressUpdateCXPRequest();

		// convert uiRequest to cxpRequest
		cxpRequest = CartCxpRequestUtil.formatUpdateRPSE911AddressRequest(uiRequest, cxpRequest);
		// call to cxp service
		Mono<RPSE911AddressCXPResponse> cxpResponseMono = cxpService.updateAccountE911Address(cxpRequest);

		RPSE911AddressUpdateUIResponse soeResponse = new RPSE911AddressUpdateUIResponse();

		return cxpResponseMono == null ? Mono.just(soeResponse) : cxpResponseMono.flatMap(cxpResponse -> {
			// convert cxpResponse to uiResponse
			CartCxpResponseUtil.formatUpdateRPSE911AddressResponse(cxpResponse, soeResponse);
			// update successUrl for numberlink in case of success response from cxp
			if (uiRequest.getChannelId().equalsIgnoreCase(CartConstants.CHANNEL_ID_NUMBERLINK)
					&& "SUCCESS".equalsIgnoreCase(cxpResponse.getData().getStatus())) {
				redisHelper.getDataFromRedis().flatMap(data -> {
					if (StringUtilities.isNotEmptyOrNull(data.getSuccessUrl())) {
						soeResponse.getData().setSuccessUrl(data.getSuccessUrl());
					}
					return Mono.just(soeResponse);
				});
			}
			return Mono.just(soeResponse);
		});
	}

	/**
	 *
	 * @param uiRequest
	 * @return RPSReleasePendingOrderResponse
	 */
	public Mono<RPSReleasePendingOrderResponse> releaseRPSPendingOrder(RPSReleasePendingOrderUIRequest uiRequest) {
		RPSReleasePendingOrderRequestCXPRequest cxpRequest = new RPSReleasePendingOrderRequestCXPRequest();
		// convert uiRequest to cxpRequest
		cxpRequest = CartCxpRequestUtil.formatReleasePendingOrderRequest(uiRequest, cxpRequest);
		// call to cxp service
		Mono<RPSReleasePendingOrderCXPResponse> cxpResponseMono = cxpService.releaseRPSPendingOrder(cxpRequest);
		RPSReleasePendingOrderResponse soeResponse = new RPSReleasePendingOrderResponse();
		return cxpResponseMono == null ? Mono.just(soeResponse) : cxpResponseMono.flatMap(cxpResponse -> {
			// convert cxpResponse to uiResponse
			CartCxpResponseUtil.formatReleasePendingOrderResponse(cxpResponse, soeResponse);
			return Mono.just(soeResponse);
		});
	}

	/**
	 *
	 * @param uiRequest
	 * @return RPSE911AddressRetrieveUIResponse
	 */
	public Mono<RPSE911AddressRetrieveUIResponse> retrieveRPSE911Address(RPSE911AddressRetrieveUIRequest uiRequest) {

		RPSE911AddressRetrieveCxpRequest cxpRequest = new RPSE911AddressRetrieveCxpRequest();
		cxpRequest = CartCxpRequestUtil.formatRetrieveRPSE911AddressRequest(uiRequest, cxpRequest);
		if (uiRequest.getChannelID().equalsIgnoreCase(CartConstants.CHANNEL_ID_NUMBERLINK)) {
			Mono<NLinlk911AddressCXPResponse> cxpResponseMono = cxpService.retrieveNLinkE911Address(cxpRequest);
			RPSE911AddressRetrieveUIResponse soeResponse = new RPSE911AddressRetrieveUIResponse();
			return cxpResponseMono == null ? Mono.just(soeResponse) : cxpResponseMono.flatMap(cxpResponse -> {
				// convert cxpResponse to uiResponse
				CartCxpResponseUtil1.formatRetrieveNLinkE911AddressResponse(cxpResponse, soeResponse);
				return Mono.just(soeResponse);
			});
		} else {
			Mono<RPSE911AddressCXPResponse> cxpResponseMono = cxpService.retrieveRPSE911Address(cxpRequest);
			RPSE911AddressRetrieveUIResponse soeResponse = new RPSE911AddressRetrieveUIResponse();
			return cxpResponseMono == null ? Mono.just(soeResponse) : cxpResponseMono.flatMap(cxpResponse -> {
				// convert cxpResponse to uiResponse
				CartCxpResponseUtil.formatRetrieveRPSE911AddressResponse(cxpResponse, soeResponse);
				return Mono.just(soeResponse);
			});
		}

	}

	/**
	 *
	 * @param uiRequest
	 * @return UpdateTradeInOfferUIResponse
	 */
	public Mono<UpdateTradeInOfferUIResponse> updateTradeInOffer(UpdateTradeInOfferUIRequest uiRequest) {

		UpdateTradeInOfferCXPRequest cxpRequest = new UpdateTradeInOfferCXPRequest();

		// convert uiRequest to cxpRequest
		cxpRequest = CartCxpRequestUtil.formatUpdateTradeInOfferRequest(uiRequest, cxpRequest);

		// call to cxp service
		Mono<UpdateTradeInOfferCXPResponse> cxpResponseMono = cxpService.updateTradeInOffer(cxpRequest);

		UpdateTradeInOfferUIResponse soeResponse = new UpdateTradeInOfferUIResponse();
		return cxpResponseMono == null ? Mono.just(soeResponse) : cxpResponseMono.flatMap(cxpResponse -> {
			// convert cxpResponse to uiResponse
			CartCxpResponseUtil.formatUpdateTradeInOfferResponse(cxpResponse, soeResponse);
			return Mono.just(soeResponse);
		});
	}

	public Mono<DeviceSimDetailsUIResponse> initiateBBPFlow(CartRedisData data) {
		DeviceSimDetailsCxpRequest request = new DeviceSimDetailsCxpRequest();
		DeviceSimDetailsData deviceSimDetailsData = new DeviceSimDetailsData();
		deviceSimDetailsData
				.setDeviceId(StringUtilities.isNotEmptyOrNull(data.getBbpImei2()) ? data.getBbpImei2() : "");
		deviceSimDetailsData.setEsimFlow(StringUtilities.isNotEmptyOrNull(data.getBbpImei2()));
		if (StringUtilities.isEmptyOrNull(deviceSimDetailsData.getDeviceId())
				&& StringUtilities.isNotEmptyOrNull(data.getDevid())) {
			deviceSimDetailsData.setDeviceId(StringUtilities.isNotEmptyOrNull(data.getDevid()) ? data.getDevid() : "");
			deviceSimDetailsData.setEsimFlow(StringUtilities.isNotEmptyOrNull(data.getEid()));
		} else if (StringUtilities.isNotEmptyOrNull(data.getBbpImei())) {
			deviceSimDetailsData
					.setDeviceId(StringUtilities.isNotEmptyOrNull(data.getBbpImei()) ? data.getBbpImei() : "");
			deviceSimDetailsData.setEsimFlow(StringUtilities.isNotEmptyOrNull(data.getEid()));
		} else if (StringUtilities.isNotEmptyOrNull(data.getImei())) {
			deviceSimDetailsData.setDeviceId(StringUtilities.isNotEmptyOrNull(data.getImei()) ? data.getImei() : "");
			deviceSimDetailsData.setEsimFlow(StringUtilities.isNotEmptyOrNull(data.getEid()));
		}

		deviceSimDetailsData.setSimId(StringUtilities.isNotEmptyOrNull(data.getBbpIccid()) ? data.getBbpIccid() : "");
		request.setData(deviceSimDetailsData);
		logger.info("DeviceSimDetailsCxpRequest: {}", request);
		Mono<DeviceSimDetailsCxpResponse> responseServiceMono = null;
		responseServiceMono = cxpService.deviceSimDetails(request);
		DeviceSimDetailsUIResponse soeResponse = new DeviceSimDetailsUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(cxpResponse -> {
			logger.info("DeviceSimDetailsCxpResponse: {}", cxpResponse);
			// convert cxp response to ui response
			CartCxpResponseUtil.formatDeviceSimDetailsResponse(cxpResponse, soeResponse,request);
			return Mono.just(soeResponse);
		});
	}

	public Mono<CustomerProfileCXPResponse> customerProfileDigital(String accountNum) {

		SalesRepCustomer salesRepCustomer = new SalesRepCustomer();
		salesRepCustomer.setCustomerAccount(accountNum);
		return cxpService.customerProfileDigital(salesRepCustomer);
	}
/*
	it will generate the CXP aggregate request for deviceIdValidation
 */
	public Mono<DeviceIdValidationUIResponse> deviceIdValidation(DeviceIdValidationUIRequest uiRequest, SearchAttributes attr) {
		DeviceValidationCXPRequest cxpRequest = new DeviceValidationCXPRequest();
		DeviceIdValidationLine cxpLine = new DeviceIdValidationLine();
		DeviceIdValidationData data = new DeviceIdValidationData();
		DeviceIdValidationMeta meta = new DeviceIdValidationMeta();
		List<DeviceIdValidationLine> lineList = new ArrayList<>();
		data.setLines(new ArrayList<>());
		Device device = new Device();
		String imei = null;
		Boolean readSKUFromAEM = false;

//ACT-198 added wireline data for CXP call- VCGD-3089 story
		if (uiRequest.getData() != null) {
			data.setFlowName(uiRequest.getData().getFlowName());
			data.setAddress(uiRequest.getData().getAddress());
			data.setZip(uiRequest.getData().getZip());
			
			if (uiRequest.getData().getLines() != null) {
				DeviceIdValidationLine line = uiRequest.getData().getLines().get(0);
				// ACT-198 changes for VCDG-4229
				if(null != line.getWireLineAccountInformation()) {
					setCxpWirelineAccountInformation(line.getWireLineAccountInformation(), cxpLine);
				}
				data.setAccountNumber(line.getWireLineAccountInformation()!=null?line.getWireLineAccountInformation().getVztAccountNo():"");
				if (line.getDevice() != null) {

					device = util.formatDevice(line, device);
					if (line.getDevice().getSku() != null)
						device.setSku(line.getDevice().getSku());
					if (line.getDevice().getSim() != null)
						device.setSim(line.getDevice().getSim());
					if (line.getDevice().getGiftbox() != null)
						device.setGiftbox(line.getDevice().getGiftbox());

					if (line.getDevice().getSmartIMEI() != null) {
						device.setSmartIMEI(line.getDevice().getSmartIMEI());
						if (line.getDevice().getSmartIMEI()) {
							if (uiRequest.getChannelId().equalsIgnoreCase(CartConstants.OMNI_CARE))
								device.setSku(line.getDevice().getSku());
							else if (!StringUtilities.isEmptyOrNull(line.getDevice().getSkuCarrier())
									&& !StringUtilities.isEmptyOrNull(line.getDevice().getSorDisplayName())
									&& ((line.getEsimFlow() == null)
									|| (line.getEsimFlow() != null && !line.getEsimFlow()))) {
								logger.info("CartServiceCxpHelper2 :: setting search attributes :{}",attr);
								device.setSearchAttributes(attr);
								device.setSku(attr.getSku());

								}
							// GTSFN-7863 and GTSFN-7865 - read SKU from AEM and send to cxp customer
							// profile graphql call
							else if (line.getEsimFlow() != null && line.getEsimFlow()) { // if esim is true, it is MFAPP
								// NSE BYOD call
								readSKUFromAEM = true;
							}
						} else {
							if (line.getDevice().getToken() != null) {
								if (line.getDevice().getId() == null || line.getDevice().getId().isEmpty()) {
									imei = new String(Base64.getDecoder().decode(line.getDevice().getToken()));
									device.setId(imei);
								} else
									device.setId(line.getDevice().getId());
							} else if (line.getDevice().getId() != null)
								device.setId(line.getDevice().getId());
						}
					}
					cxpLine.setDevice(device);
				}

				lineList.add(cxpLine);
			}
			data.setLines(lineList);
		}
		data.setAction(StringUtils.isNotBlank(uiRequest.getCartInfo().getAction()) ? uiRequest.getCartInfo().getAction(): "");
		cxpRequest.setData(data);

		if (uiRequest.getChannelId() != null) {
			meta.setClient(uiRequest.getChannelId());
		}
		cxpRequest.setMeta(meta);

		if (readSKUFromAEM) {// BYOD ESIM FLOW
			return setSkuForCxpCall(uiRequest, cxpRequest, attr);
		} else {
			return cxpDeviceValidationCall(cxpRequest);
		}
	}

	private Mono<DeviceIdValidationUIResponse> setSkuForCxpCall(DeviceIdValidationUIRequest uiRequest,
																DeviceValidationCXPRequest cxpRequest, SearchAttributes attr) {
		try {
			if (uiRequest.getData().getLines().get(0).getEditSim() != null
					&& uiRequest.getData().getLines().get(0).getEditSim()) {// BYOD edit sim flow
				if (uiRequest.getData().getLines().get(0).getDevice().getSimSelected() != null && uiRequest.getData()
						.getLines().get(0).getDevice().getSimSelected().equalsIgnoreCase(CartConstants.ESIM)) {
					return readEsimSkuFromRedisAndCallCxp(cxpRequest);
				} else if (uiRequest.getData().getLines().get(0).getDevice().getSimSelected() != null
						&& uiRequest.getData().getLines().get(0).getDevice().getSimSelected()
						.equalsIgnoreCase(CartConstants.PSIM)) {
					return readPsimSkuFromRedisAndCallCxp(cxpRequest,attr);
				} else { // sim selected is not esim/psim - cxp call without sku
					return cxpDeviceValidationCall(cxpRequest);
				}
			} else if (uiRequest.getData().getLines().get(0).getDevice().getIdentifier() != null) { // options.html
				// loading flow
				ProspectDeviceModelMappingRequest request = ProspectDeviceModelMappingRequest.builder().build();
				return cartAEMService.getSKUDetail(request).flatMap(apiResponse -> {
					Optional<DeviceModelMap> deviceModelMapObject = apiResponse
							.getDeviceModelMap().stream()
							.filter(deviceModelMap -> deviceModelKeyPredicate(deviceModelMap,
									uiRequest.getData().getLines().get(0).getDevice().getIdentifier()))
							.findFirst();
					return readSkuFromAemAndCallCXP(deviceModelMapObject, uiRequest, cxpRequest);
				});
			} else { // identifier, edit sim value not found in ui request - cxp call without sku
				return cxpDeviceValidationCall(cxpRequest);
			}
		} catch (Exception e) {
			logger.error("Exception occured in BYOD ESIM setSkuForCxpCall", e);
			return cxpDeviceValidationCall(cxpRequest);
		}
	}

	/**
	 * readEsimSkuFromRedisAndCallCxp
	 *
	 * @param cxpRequest
	 *
	 * @return DeviceIdValidationUIResponse
	 */
	private Mono<DeviceIdValidationUIResponse> readEsimSkuFromRedisAndCallCxp(DeviceValidationCXPRequest cxpRequest) {
		return redisHelper2.getEsimSKUFromRedis().flatMap(esimSKU -> {
			cxpRequest.getData().getLines().get(0).getDevice().setSku(esimSKU);
			SearchAttributes searchAttributes = new SearchAttributes();
			searchAttributes.setSku(esimSKU);
			cxpRequest.getData().getLines().get(0).getDevice().setSearchAttributes(searchAttributes);
			logger.info("BYOD ESIM CXP Request : deviceIdValidation with Redis esimSKU {}", cxpRequest);
			return cxpDeviceValidationCall(cxpRequest);
		});
	}

	/**
	 * readPsimSkuFromRedisAndCallCxp
	 *
	 * @param cxpRequest
	 *
	 * @return DeviceIdValidationUIResponse
	 */
	private Mono<DeviceIdValidationUIResponse> readPsimSkuFromRedisAndCallCxp(DeviceValidationCXPRequest cxpRequest,SearchAttributes attr) {
		return redisHelper3.getPsimSKUFromRedis().flatMap(psimSKU -> {
			if (StringUtils.isNotBlank(psimSKU)) {
				cxpRequest.getData().getLines().get(0).getDevice().setSku(psimSKU);
				SearchAttributes searchAttributes = new SearchAttributes();
				searchAttributes.setSku(psimSKU);
				cxpRequest.getData().getLines().get(0).getDevice().setSearchAttributes(searchAttributes);
				logger.info("BYOD ESIM CXP Request : deviceIdValidation with Redis psimSKU {}", cxpRequest);
			} else {
				return redisHelper3.getDeviceSorDisplayNameFromRedis().flatMap(sorDisplayName -> {
					SearchAttributes searchAttributes;
					logger.info("CartServiceCxpHelper2 :: setting search attributes :{}", attr);
						searchAttributes = attr;
					if (searchAttributes != null && searchAttributes.getSku() != null) {
						cxpRequest.getData().getLines().get(0).getDevice().setSku(searchAttributes.getSku());
						cxpRequest.getData().getLines().get(0).getDevice().setSearchAttributes(searchAttributes);
						logger.info("BYOD ESIM CXP Request : deviceIdValidation with elastic search psimSKU {}",
								cxpRequest);
					}
					return cxpDeviceValidationCall(cxpRequest);
				});
			}
			return cxpDeviceValidationCall(cxpRequest);
		});
	}

	/**
	 * readSkuFromAemAndCallCXP
	 *
	 * @param deviceModelMapObject
	 * @param uiRequest
	 * @param cxpRequest
	 * @return DeviceIdValidationUIResponse
	 */
	private Mono<DeviceIdValidationUIResponse> readSkuFromAemAndCallCXP(Optional<DeviceModelMap> deviceModelMapObject,
																		DeviceIdValidationUIRequest uiRequest, DeviceValidationCXPRequest cxpRequest) {
		String sku = null;
		String esimSku = null;
		String psimSku = null;
		String skuCarrier = null;
		String sorDisplayName = null;
		try {
			if (uiRequest.getData() != null && uiRequest.getData().getLines() != null
					&& CollectionUtilities.isNotEmptyOrNull(uiRequest.getData().getLines())
					&& uiRequest.getData().getLines().get(0).getDevice() != null
					&& uiRequest.getData().getLines().get(0).getDevice().getSkuCarrier() != null) {
				skuCarrier = uiRequest.getData().getLines().get(0).getDevice().getSkuCarrier();
			}
			logger.info("get esim & psim sku from devicemodelmap with skuCarrier: {}",skuCarrier);
			if (deviceModelMapObject.isPresent() && skuCarrier != null) {
				ESim esim = deviceModelMapObject.get().getESim();
				PSim psim = deviceModelMapObject.get().getPSim();
				if (skuCarrier.equalsIgnoreCase(CartConstants.VERIZON)) {
					sorDisplayName = deviceModelMapObject.get().getModel();
					esimSku = esim!=null?esim.getVERIZON():StringUtils.EMPTY;
					psimSku = psim!=null?psim.getVERIZON():StringUtils.EMPTY;
				} else if (skuCarrier.equalsIgnoreCase(CartConstants.ATT)) {
					esimSku = esim!=null?esim.getATT():StringUtils.EMPTY;
					psimSku = psim!=null?psim.getATT():StringUtils.EMPTY;
				} else if (skuCarrier.equalsIgnoreCase(CartConstants.SPRINT)) {
					esimSku = esim!=null?esim.getSPRINT():StringUtils.EMPTY;
					psimSku = psim!=null?psim.getSPRINT():StringUtils.EMPTY;
				} else if (skuCarrier.equalsIgnoreCase(CartConstants.TMOBILE)) {
					esimSku = esim!=null?esim.getTMobile():StringUtils.EMPTY;
					psimSku = psim!=null?psim.getTMobile():StringUtils.EMPTY;
				} else {
					esimSku = esim!=null?esim.getOther():StringUtils.EMPTY;
					psimSku = psim!=null?psim.getOther():StringUtils.EMPTY;
				}
				if(StringUtils.isBlank(psimSku) && !skuCarrier.equalsIgnoreCase(CartConstants.OTHER)) {
					psimSku = psim!=null?psim.getOther():StringUtils.EMPTY;
				}
				if(StringUtils.isBlank(esimSku) && !skuCarrier.equalsIgnoreCase(CartConstants.OTHER)) {
					esimSku = esim!=null?esim.getOther():StringUtils.EMPTY;
				}
				sku = esimSku;
			}
			if (StringUtils.isBlank(sorDisplayName) && deviceModelMapObject.isPresent()) {
				sorDisplayName = deviceModelMapObject.get().getModel_NonVZ();
			}
			if (StringUtilities.isEmptyOrNull(sorDisplayName) && deviceModelMapObject.isPresent()
					&& StringUtilities.isNotEmptyOrNull(deviceModelMapObject.get().getKey())) {
				if (deviceModelMapObject.get().getKey().contains("(")) {
					sorDisplayName = (deviceModelMapObject.get().getKey().split("\\(")[0]).trim();
				}
			}

			// if sku is not available in device model mapping file, returning the error from SOE - PRODDEF-18782
			if(StringUtilities.isEmptyOrNull(sku)){
				logger.info("Sku not found in device model mapping");
				return Mono.error(new SOEHTTPException(500, SOEErrorHolder.builder().errors(CartPegaRequestErrorsUtil.skuNotAvailableInModelMappingErorrResponse()).build()));
			}

			cxpRequest.getData().getLines().get(0).getDevice().setSku(sku);
			SearchAttributes searchAttributes = new SearchAttributes();
			searchAttributes.setSku(sku);
			cxpRequest.getData().getLines().get(0).getDevice().setSearchAttributes(searchAttributes);

			logger.info("BYOD ESIM CXP Request : deviceIdValidation with AEM esim sku {}", cxpRequest);

			return redisHelper3.updateByodDeviceDetailRedis(esimSku, psimSku, sorDisplayName).flatMap(redisInsert -> {
				return cxpDeviceValidationCall(cxpRequest);
			});

		} catch (Exception e) {
			logger.error("Error during readSkuFromAemAndCallCXP : {}", e.getMessage());
			return cxpDeviceValidationCall(cxpRequest);
		}
	}

	/**
	 * deviceModelKeyPredicate, The deviceModelKeyPredicate
	 *
	 * @param deviceModelMap
	 * @param identifierKey
	 * @return boolean
	 */
	private boolean deviceModelKeyPredicate(DeviceModelMap deviceModelMap, String identifierKey) {
		if (deviceModelMap != null && deviceModelMap.getKey() != null
				&& deviceModelMap.getKey().equalsIgnoreCase(identifierKey)) {
			logger.info("returning devicemodel map for identifier : {}, modelMap:{}", identifierKey, deviceModelMap);
			return true;
		}
		return false;
	}

	/**
	 * cxpDeviceValidationCall, The cxp DeviceValidationCall
	 *
	 * @param cxpRequest
	 * @return DeviceIdValidationUIResponse
	 */
	private Mono<DeviceIdValidationUIResponse> cxpDeviceValidationCall(DeviceValidationCXPRequest cxpRequest) {
		DeviceIdValidationUIResponse soeResponse = new DeviceIdValidationUIResponse();
		logger.info("BYOD ESIM CXP Request : cxpDeviceValidationCall Method :{}", cxpRequest);
		Mono<DeviceIdValidationCXPResponse> cxpResponse = cxpService.deviceValidation(cxpRequest);


		return cxpResponse == null ? Mono.just(soeResponse) : cxpResponse.flatMap(response -> {
			logger.info("cxpResponse:{}", response);
			CartCxpResponseUtil.formatDeviceValidationResponse(response, soeResponse);
			return Mono.just(soeResponse);
		});
	}

	/**
	 *
	 * @param uiRequest
	 * @return UpdateTradeInOfferUIResponse
	 */
	public Mono<AddZipcodeRedisData> addZipcode(AddZipCodeUIRequest uiRequest) {

		AddZipcodeCXPRequest cxpRequest = new AddZipcodeCXPRequest();

		// convert uiRequest to cxpRequest
		cxpRequest = CartCxpRequestUtil.formatAddZipcodeRequest(uiRequest, cxpRequest);

		// call to cxp service
		Mono<AddZipcodeCXPResponse> cxpResponseMono = cxpService.addZipcodeToCart(cxpRequest);

		AddZipcodeRedisData soeResponse = new AddZipcodeRedisData();
		return cxpResponseMono == null ? Mono.just(soeResponse) : cxpResponseMono.flatMap(cxpResponse -> {
			// convert cxpResponse to uiResponse
			CartCxpResponseUtil.formatAddZipcodeResponse(cxpResponse, soeResponse);
			return Mono.just(soeResponse);
		});
	}

	/**
	 *
	 * @param uiRequest
	 * @return DeviceSimValidationUIResponse
	 */
	public Mono<DeviceSimValidationUIResponse> deviceSimValidation(ServerHttpRequest httpHeader,
																   DeviceSimValidationUIRequest uiRequest) {

		return redisHelper.getDataFromRedis().flatMap(cartRedisData -> {
			DeviceSimValidationCXPRequest cxpRequest = new DeviceSimValidationCXPRequest();
			String loggedInMtn = cartRedisData.getMtn();
			logger.info("loggedInMtn: {}", loggedInMtn);

			String flowPathName = String.valueOf(httpHeader.getPath());
			// convert uiRequest to cxpRequest
			cxpRequest = CartCxpRequestUtil.formatDeviceSimValidationRequest(uiRequest, cxpRequest);

			String flowType = cxpRequest.getData().getFlowType();
			logger.info("flowType: {}", flowType);

			if (StringUtilities.isNotEmptyOrNull(flowPathName)) {
				if (flowType.equalsIgnoreCase("esim")) {
					cxpRequest.getData().getESim().setBillingId(uiRequest.getBillingId());
					if (!flowPathName.contains("/nse/deviceSimValidation")) {
						logger.info("Set LoggedIn Mtn: {}", loggedInMtn);

						cxpRequest.getData().getESim().setMtn(loggedInMtn);
					}
				}
			}

			logger.info("DeviceSimValidationUIRequest request: {}", cxpRequest);

			// call to cxp service
			Mono<DeviceSimValidationCXPResponse> cxpResponseMono = cxpService.deviceSimValidation(cxpRequest);

			DeviceSimValidationUIResponse soeResponse = new DeviceSimValidationUIResponse();
			return cxpResponseMono == null ? Mono.just(soeResponse) : cxpResponseMono.flatMap(cxpResponse -> {
				// convert cxpResponse to uiResponse
				CartCxpResponseUtil1.formatDeviceSimValidationResponse(httpHeader, uiRequest, cxpResponse, soeResponse);
				String flowPath = String.valueOf(httpHeader.getPath());
				if (StringUtilities.isNotEmptyOrNull(flowPath) && flowPath.contains("/nse/deviceSimValidation")
						&& StringUtilities.isNotEmptyOrNull(uiRequest.getImei2())
						&& StringUtilities.isNotEmptyOrNull(cxpResponse.getData().getEsimInfo().getEId())
						&& StringUtilities.isNotEmptyOrNull(
						cxpResponse.getData().getDeviceInfo().getDeviceAttributes().getDeviceCategory())
						&& cxpResponse.getData().getDeviceInfo().getDeviceAttributes().getDeviceCategory()
						.contains("Smartphone")) {
					soeResponse.getData().setESimType(CartConstants.SMARTPHONE);
					soeResponse.getData().setIsEsimDevice(CartConstants.TRUE);
				}
				if (StringUtilities
						.isNotEmptyOrNull(cxpResponse.getData().getDeviceInfo().getDeviceAttributes().getDaccCode())) {
					if (environment.getProperty(CartConstants.ESIM_IPAD_DACCS)
							.contains(cxpResponse.getData().getDeviceInfo().getDeviceAttributes().getDaccCode()) ||
							(cxpResponse.getData().getDeviceInfo().getDeviceAttributes().getDeviceCategory().equalsIgnoreCase(CartConstants.DEVICETYPE_5GTABLET) ||
									cxpResponse.getData().getDeviceInfo().getDeviceAttributes().getDeviceCategory().equalsIgnoreCase(CartConstants.DEVICETYPE_4GTABLET))
									&& cxpResponse.getData().getDeviceInfo().getEuiccCapable().equalsIgnoreCase(CartConstants.Y)){
						soeResponse.getData().setESimType(CartConstants.IPAD);
						soeResponse.getData().setIsEsimDevice(CartConstants.TRUE);
					}
					if (environment.getProperty(CartConstants.ESIM_LAPTOP_DACCS)
							.contains(cxpResponse.getData().getDeviceInfo().getDeviceAttributes().getDaccCode())||
							(cxpResponse.getData().getDeviceInfo().getDeviceAttributes().getDeviceCategory().equalsIgnoreCase(CartConstants.DEVICETYPE_5GLAPTOP) ||
									cxpResponse.getData().getDeviceInfo().getDeviceAttributes().getDeviceCategory().equalsIgnoreCase(CartConstants.DEVICETYPE_4GLAPTOP))
									&& cxpResponse.getData().getDeviceInfo().getEuiccCapable().equalsIgnoreCase(CartConstants.Y)) {
						soeResponse.getData().setESimType(CartConstants.LAPTOP);
						soeResponse.getData().setIsEsimDevice(CartConstants.TRUE);
					}

					if (environment.getProperty(CartConstants.SDK_RING_DACCS)
							.contains(cxpResponse.getData().getDeviceInfo().getDeviceAttributes().getDaccCode())) {
						soeResponse.getData().setIsSDKDevice(CartConstants.TRUE);
						soeResponse.getData().setSdkDeviceType(CartConstants.RING);
					}

					if (environment.getProperty(CartConstants.SDK_GARMIN_DACCS)
							.contains(cxpResponse.getData().getDeviceInfo().getDeviceAttributes().getDaccCode())) {
						soeResponse.getData().setIsSDKDevice(CartConstants.TRUE);
						soeResponse.getData().setSdkDeviceType(CartConstants.GARMIN);
					}

					if (environment.getProperty(CartConstants.SDK_TRACKER_DACCS)
							.contains(cxpResponse.getData().getDeviceInfo().getDeviceAttributes().getDaccCode())) {
						soeResponse.getData().setIsSDKDevice(CartConstants.TRUE);
						soeResponse.getData().setSdkDeviceType(CartConstants.TRACKER);
					}

				}
				return Mono.just(soeResponse);
			});
		});
	}

	// VZWCS-17115 change
	public Mono<InitiateCbandCheckUIResponse> initiateCbandCheck(InitiateCbandCheckUIRequest uiRequest) {

		InitiateCbandCheckCXPRequest cxpRequest = new InitiateCbandCheckCXPRequest();
		String flowType = uiRequest.getFlowType();
		logger.info("flowType: {}", flowType);

		// convert uiRequest to cxpRequest
		cxpRequest = CartCxpRequestUtil.formatInitiateCbandCheckRequest(uiRequest, cxpRequest);
		logger.info("InitiateCbandCheckCXPRequest: {}", cxpRequest);

		// call to cxp service
		Mono<InitiateCbandCheckCXPResponse> cxpResponseMono = cxpService.initiateCbandCheck(cxpRequest);

		InitiateCbandCheckUIResponse soeResponse = new InitiateCbandCheckUIResponse();
		return cxpResponseMono == null ? Mono.just(soeResponse) : cxpResponseMono.flatMap(cxpResponse -> {
			logger.info("InitiateCbandCheckCXPResponse: {}", cxpResponse);

			if (cxpResponse.getData() != null && cxpResponse.getData().getFixedWirelessOrders() != null &&
					cxpResponse.getData().getFixedWirelessOrders().size() > 0) {
				List<FixedWirelessOrders> list = cxpResponse.getData().getFixedWirelessOrders().stream()
						.filter(check -> StringUtilities.isNotEmptyOrNull(check.getDigitalOrderType()) && StringUtilities.isNotEmptyOrNull(check.getLaunchType()))
						.filter(res -> (((StringUtilities.isNotEmptyOrNull(cxpResponse.getData().getMtnStatusReasonCode()) &&
								cxpResponse.getData().getMtnStatusReasonCode().equalsIgnoreCase(REASON_CODE_MS) &&
								res.getDigitalOrderType().equalsIgnoreCase(LTE)) || res.getDigitalOrderType().equalsIgnoreCase(CartConstants.LTE_MOV)) &&
								res.getLaunchType().equalsIgnoreCase(CartConstants.LAUNCHTYPE_4GH)) || ((res.getDigitalOrderType().equalsIgnoreCase(CartConstants.CBD_MOV) || res.getDigitalOrderType().equalsIgnoreCase(CartConstants.CBD) ) &&
								res.getLaunchType().equalsIgnoreCase(CartConstants.LAUNCHTYPE_FCL)))
						.collect(Collectors.toList());

				if (list != null && list.size() > 1) {
					Comparator<FixedWirelessOrders> comparator = Comparator.comparing(FixedWirelessOrders::getOrderDate);
					FixedWirelessOrders fixedWirelessOrders = list.stream().max(comparator).get();
					cxpResponse.getData().setFixedWirelessOrders(List.of(fixedWirelessOrders));
				} else {
					cxpResponse.getData().setFixedWirelessOrders(list);
				}
			}

			// convert cxpResponse to uiResponse
			CartCxpResponseUtil.formatInitiateCbandCheckResponse(cxpResponse, soeResponse);
			logger.info("InitiateCbandCheckCXPResponse after formatting: {}", soeResponse);
			return Mono.just(soeResponse);
		});
	}

	/**
	 *
	 * @param reqType
	 * @return CustomerByMtnUIResponse
	 *
	 */
	public Mono<CustomerByMtnUIResponse> customerByMtn(CustomerReqType reqType) {

		CustomerByMtnCXPResponse cxpResponse = new CustomerByMtnCXPResponse();
		Mono<CustomerByMtnCXPResponse> responseServiceMono = Mono.just(cxpResponse);


		if(StringUtilities.isNotEmptyOrNull(reqType.getDeviceId())) {
			responseServiceMono = cxpService.customerProfile(reqType);
		}
		else {
			responseServiceMono = cxpService.customerByMtn(reqType);
		}

		CustomerByMtnUIResponse soeResponse = new CustomerByMtnUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(cartResponse -> {

			// convert cxpResponse into soeResponse
			CartCxpResponseUtil.formatCustomerByMtnResponse(soeResponse, cartResponse);
			return Mono.just(soeResponse);
		}).onErrorResume(failResp -> {
			if (failResp instanceof SOEHTTPException) {
				SOEHTTPException soeExp = (SOEHTTPException) failResp;
				soeExp.getErrorCode();
				if (soeExp.getErrorHolder() != null) {
					List<onevz.soe.cart.model.common.CartError> errors = new ArrayList<>();
					if (CollectionUtilities.isNotEmptyOrNull(soeExp.getErrorHolder().getErrors())) {
						soeExp.getErrorHolder().getErrors().forEach(soeErr -> {
							onevz.soe.cart.model.common.CartError cartErr = new onevz.soe.cart.model.common.CartError();
							BeanUtils.copyProperties(soeErr, cartErr);
							errors.add(cartErr);
						});
					}
					soeResponse.setErrors(errors);
				}
			}
			logger.info("msg: {0}", failResp);

			return Mono.just(soeResponse);
		});

	}
	
	/**
	 *
	 * @param validateOffersRequest
	 * @return ValidateOffersResponse
	 */
	public Mono<ValidateOffersResponse> validateOffers(ValidateOffersRequest validateOffersRequest) {
		return cxpService.validateOffers(validateOffersRequest).flatMap(data -> {
			return Mono.just(data);
		});
	}

	/**
	 *
	 * @param request
	 * @return CustomerByMtnListUIResponse
	 *
	 */
	public Mono<CustomerByMtnListUIResponse> customerByMtnList(CustomerByMtnListUIRequest request) {
		String[] mtnArray = new String[request.getMtnList().size()];
		Mono<CustomerByMtnListCXPResponse> responseServiceMono = cxpService
				.customerByMtnList(request.getMtnList().toArray(mtnArray));

		CustomerByMtnListUIResponse soeResponse = new CustomerByMtnListUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(cartResponse -> {

			// convert cxpResponse into soeResponse
			CartCxpResponseUtil.formatCustomerByMtnListResponse(soeResponse, cartResponse);
			return Mono.just(soeResponse);
		});
	}
	
	/*
	 * @param mtn
	 *
	 * @return GetParentLinesUIResponse
	 *
	 */
	public Mono<GetParentLinesUIResponse> customerByMtnForParentLines(String mtn) {

		Mono<GetParentLinesCXPResponse> responseServiceMono = cxpService.customerByMtnForParentLines(mtn);

		GetParentLinesUIResponse soeResponse = new GetParentLinesUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(cartResponse -> {

			// convert cxpResponse into soeResponse
			CartCxpResponseUtil.formatCustomerByMtnParentLinesResponse(soeResponse, cartResponse);
			return Mono.just(soeResponse);
		}).onErrorResume(failResp -> {
			if (failResp instanceof SOEHTTPException) {
				SOEHTTPException soeExp = (SOEHTTPException) failResp;
				soeExp.getErrorCode();
				if (soeExp.getErrorHolder() != null) {
					List<onevz.soe.cart.model.common.CartError> errors = new ArrayList<>();
					if (CollectionUtilities.isNotEmptyOrNull(soeExp.getErrorHolder().getErrors())) {
						soeExp.getErrorHolder().getErrors().forEach(soeErr -> {
							onevz.soe.cart.model.common.CartError cartErr = new onevz.soe.cart.model.common.CartError();
							BeanUtils.copyProperties(soeErr, cartErr);
							errors.add(cartErr);
						});
					}
					soeResponse.setErrors(errors);
				}
			}
			logger.info("msg: {0}", failResp);

			return Mono.just(soeResponse);
		});

	}

	public Mono<CustomerProfileUIResponse> salesRepIdProfile(String repId) {

		SalesRepCustomer salesRepCustomer = new SalesRepCustomer();
		salesRepCustomer.setSalesRepId(repId);

		CustomerProfileUIResponse uiResponse = new CustomerProfileUIResponse();
		Mono<CustomerProfileCXPResponse> responseMono = cxpService.salesRepIdProfile(salesRepCustomer);
		return responseMono == null ? Mono.just(uiResponse) : responseMono.flatMap(response -> {

			// convert cxpResponse into soeResponse
			CartCxpResponseUtil.formatCustomerProfileResponse(response, uiResponse, repId);
			return Mono.just(uiResponse);
		});
	}

	/**
	 *
	 * @param request
	 * @return soeResponse
	 *
	 */
	public Mono<GetPairedDevicesUIResponse> getPairedDevices(GetPairedDevicesUIRequest request) {

		Mono<GetPairedDeviceInfoGQLResponse> responseServiceMono = cxpService.getPairedDevices(request.getCartId());
		GetPairedDevicesUIResponse soeResponse = new GetPairedDevicesUIResponse();

		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(cartResponse -> {
			logger.info(CartConstants.CXP_RESPONSE + ": {}", cartResponse);
			// convert cxpResponse into
			CartCxpResponseUtil.formatGetPairedWatchesResponse(soeResponse, cartResponse, request);
			return Mono.just(soeResponse);
		});

	}

	/**
	 *
	 * @param uiRequest
	 * @return soeResponse
	 *
	 */
	public Mono<UpdateVzccNBXInfoUIResponse> updateVzccNBXInfo(UpdateVzccNBXInfoUIRequest uiRequest) {
		UpdateVzccNBXInfoCXPRequest cxpRequest = new UpdateVzccNBXInfoCXPRequest();

		// convert uiRequest to cxpRequest
		cxpRequest = CartCxpRequestUtil.formatVzccNBXInfoRequest(uiRequest, cxpRequest);
		logger.info("nbxInfo {}" , cxpRequest);
		Mono<UpdateVzccNBXInfoCXPResponse> responseServiceMono = cxpService.updateVzccNBXInfo(cxpRequest);

		UpdateVzccNBXInfoUIResponse soeResponse = new UpdateVzccNBXInfoUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(cartResponse -> {

			// convert cxpResponse into soeResponse
			CartCxpResponseUtil.formatVzccNBXInfoResponse(soeResponse, cartResponse);
			return Mono.just(soeResponse);
		});
	}

	/**
	 *
	 * @param uiRequest
	 * @return ValidateE911AddressUIResponse
	 */
	public Mono<ValidateE911AddressUIResponse> validateE911Address(RPSE911AddressUpdateUIRequest uiRequest) { // 2155.1

		AddressRequest cxpRequest = new AddressRequest();

		// convert uiRequest to cxpRequest
		cxpRequest = CartCxpRequestUtil.formatValidateE911AddressRequest(uiRequest, cxpRequest);
		// call to cxp service
		Mono<ValidateE911AddressCXPResponse> cxpResponseMono = cxpService.getValidateAddress(cxpRequest);

		ValidateE911AddressUIResponse soeResponse = new ValidateE911AddressUIResponse();

		return cxpResponseMono == null ? Mono.just(soeResponse) : cxpResponseMono.flatMap(cxpResponse -> {
			// convert cxpResponse to uiResponse
			CartCxpResponseUtil.formatValidateE911AddressResponse(cxpResponse, soeResponse);

			return Mono.just(soeResponse);
		});
	}

	/**
	 *
	 * @param request
	 * @return CreateCaseAndGetCustomerInfoUIResponse
	 *
	 */
	public Mono<CreateCaseAndGetCustomerInfoUIResponse> getCustomerInfo(CreateCaseAndGetCustomerInfoUIRequest request,
																		String customerId) {

		Mono<GetCustomerInfoCXPResponse> responseServiceMono = cxpService.getCustomerInfo(customerId);

		CreateCaseAndGetCustomerInfoUIResponse soeResponse = new CreateCaseAndGetCustomerInfoUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(cartResponse -> {

			// convert cxpResponse into soeResponse
			CartCxpResponseUtil.formatGetCustomerInfoResponse(soeResponse, cartResponse, request);
			return Mono.just(soeResponse);
		});

	}

	/**
	 * Initiate device sim activation.
	 *
	 * @param uiRequest the ui request
	 * @return soeResponse
	 */
	public Mono<InitiateDeviceSimActivationUIResponse> initiateDeviceSimActivation(
			IntiateDeviceSimActivationUIRequest uiRequest) {
		IntiateDeviceSimActivationCXPRequest cxpRequest = new IntiateDeviceSimActivationCXPRequest();
		cxpRequest = CartCxpRequestUtil.formatInitiateDeviceSimActivationCXPRequest(uiRequest, cxpRequest);
		logger.info("cxpRequest : {}", cxpRequest);
		Mono<InitiateDeviceSimActivationCxpResponse> responseServiceMono = cxpService
				.initiateDeviceSimActivation(cxpRequest);
		InitiateDeviceSimActivationUIResponse soeResponse = new InitiateDeviceSimActivationUIResponse();

		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(cartResponse -> {
			logger.info(CartConstants.CXP_RESPONSE + ": {}", cartResponse);
			// convert cxpResponse into
			CartCxpResponseUtil.formatInitiateDeviceSimActivationResponse(cartResponse, soeResponse);
			return Mono.just(soeResponse);
		});
	}

	public Mono<InitiateESimActivationUIResponse> initiateESimActivation(IntiateESimActivationUIRequest uiRequest) {
		InitiateESimActivationCXPRequest cxpRequest = new InitiateESimActivationCXPRequest();
		cxpRequest = CartCxpRequestUtil.formatInitiateESimActivationCXPRequest(uiRequest, cxpRequest);
		logger.info("cxpRequest : {}", cxpRequest);
		Mono<InitiateESimActivationCXPResponse> responseServiceMono = cxpService.initiateESimActivation(cxpRequest);
		InitiateESimActivationUIResponse soeResponse = new InitiateESimActivationUIResponse();

		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(cartResponse -> {
			logger.info( CartConstants.CXP_RESPONSE + ": {}", cartResponse);
			// convert cxpResponse into
			CartCxpResponseUtil.formatInitiateESimActivationResponse(cartResponse, soeResponse);
			return Mono.just(soeResponse);
		});
	}
	
	/**
	 *
	 * @param uiRequest
	 * @return MacAddressUIResponse
	 */
	public Mono<MacAddressUIResponse> updateMacAddress(MacAddressUIRequest uiRequest) {

		MacAddressCXPRequest cxpRequest = new MacAddressCXPRequest();

		// convert uiRequest to cxpRequest
		cxpRequest = CartCxpRequestUtil.formatMacAddressRequest(uiRequest, cxpRequest);

		// call to cxp service
		Mono<MacAddressCXPResponse> cxpResponseMono = cxpService.updateMacAddress(cxpRequest);

		MacAddressUIResponse soeResponse = new MacAddressUIResponse();
		return cxpResponseMono == null ? Mono.just(soeResponse) : cxpResponseMono.flatMap(cxpResponse -> {
			// convert cxpResponse to uiResponse
			CartCxpResponseUtil.formatMacAddressResponse(cxpResponse, soeResponse);
			return Mono.just(soeResponse);
		});
	}

	/**
	 *
	 * @param uiRequest
	 * @return UpdatePurchaseOrderUIResponse
	 */
	public Mono<UpdatePurchaseOrderUIResponse> updatePurchaseOrderNo(UpdatePurchaseOrderUIRequest uiRequest) {

		UpdatePurchaseOrderCXPRequest cxpRequest = new UpdatePurchaseOrderCXPRequest();

		// convert uiRequest to cxpRequest
		cxpRequest = CartCxpRequestUtil.formatUpdatePurchaseOrderRequest(uiRequest, cxpRequest);

		// call to cxp service
		Mono<UpdatePurchaseOrderCXPResponse> cxpResponseMono = cxpService.updatePurchaseOrderNo(cxpRequest);

		UpdatePurchaseOrderUIResponse soeResponse = new UpdatePurchaseOrderUIResponse();
		return cxpResponseMono == null ? Mono.just(soeResponse) : cxpResponseMono.flatMap(cxpResponse -> {
			// convert cxpResponse to uiResponse
			CartCxpResponseUtil.formatUpdatePurchaseOrderResponse(cxpResponse, soeResponse);
			return Mono.just(soeResponse);
		});
	}

	/**
	 *
	 * @param uiRequest
	 * @return GiftPurchaseUIResponse
	 */
	public Mono<GiftPurchaseUIResponse> giftPurchase(GiftPurchaseUIRequest uiRequest) {

		GiftPurchaseCXPRequest cxpRequest = new GiftPurchaseCXPRequest();

		// convert uiRequest to cxpRequest
		cxpRequest = CartCxpRequestUtil.formatGiftPurchaseRequest(uiRequest, cxpRequest);

		// call to cxp service
		Mono<GiftPurchaseCXPResponse> cxpResponseMono = cxpService.giftPurchase(cxpRequest);

		GiftPurchaseUIResponse soeResponse = new GiftPurchaseUIResponse();
		return cxpResponseMono == null ? Mono.just(soeResponse) : cxpResponseMono.flatMap(cxpResponse -> {
			// convert cxpResponse to uiResponse
			CartCxpResponseUtil.formatGiftPurchaseResponse(cxpResponse, soeResponse);
			return Mono.just(soeResponse);
		});
	}
	
	
	/**
	 *
	 * @param uiRequest
	 * @return AddDeviceUIResponse
	 */
	public Mono<AddDeviceUIResponse> getNbsData(AddDeviceUIRequest uiRequest, AddDeviceUIResponse pegaResp) {
//AddDeviceUIResponse
		NbsDataCXPRequest nbxCxpRequest = new NbsDataCXPRequest();

		// convert uiRequest to cxpRequest
		nbxCxpRequest = CartCxpRequestUtil.formatNbsDataRequest(uiRequest, nbxCxpRequest);
		logger.info("cxp request for getNbsData : {}", nbxCxpRequest);
		 Mono<NbsDataCXPResponse> cxpResponseMono = cxpService.nbsData(nbxCxpRequest);
		logger.info("cxp response for getNbsData : {}", cxpResponseMono);
		return cxpResponseMono == null ? Mono.just(pegaResp) : cxpResponseMono.flatMap(nbxCxpRes -> {
			// convert cxpResponse to uiResponse
			CartCxpResponseUtil1.formatNbsDataResponse(nbxCxpRes, pegaResp);
			return Mono.just(pegaResp);
		});

	}
	
	/**
	 *
	 * @param uiRequest
	 * @return UpdateTradeinTypeUIResponse
	 */
	public Mono<UpdateTradeinTypeUIResponse> updateTradeinType(UpdateTradeinTypeUIRequest uiRequest) {

		UpdateTradeinTypeCXPRequest cxpRequest = new UpdateTradeinTypeCXPRequest();

		// convert uiRequest to cxpRequest
		cxpRequest = CartCxpRequestUtil.formatUpdateTradeinTypeRequest(uiRequest, cxpRequest);

		// call to cxp service
		Mono<UpdateTradeinTypeCXPResponse> cxpResponseMono = cxpService.updateTradeinType(cxpRequest);

		UpdateTradeinTypeUIResponse soeResponse = new UpdateTradeinTypeUIResponse();
		return cxpResponseMono == null ? Mono.just(soeResponse) : cxpResponseMono.flatMap(cxpResponse -> {
			// convert cxpResponse to uiResponse
			CartCxpResponseUtil.formatUpdateTradeinTypeResponse(cxpResponse, soeResponse);
			return Mono.just(soeResponse);
		});
	}

	/**
	 *
	 * @param uiRequest
	 * @return CheckDfillInventoryUIResponse
	 */
	public Mono<CheckDfillInventoryUIResponse> checkDfillInventory(CheckDfillInventoryUIRequest uiRequest) {

		CheckDfillInventoryCXPRequest cxpRequest = new CheckDfillInventoryCXPRequest();

		// convert uiRequest to cxpRequest
		cxpRequest = CartCxpRequestUtil.formatCheckDfillInventoryRequest(uiRequest, cxpRequest);

		// call to cxp service
		Mono<CheckDfillInventoryCXPResponse> cxpResponseMono = cxpService.checkDfillInventory(cxpRequest);

		CheckDfillInventoryUIResponse soeResponse = new CheckDfillInventoryUIResponse();
		return cxpResponseMono == null ? Mono.just(soeResponse) : cxpResponseMono.flatMap(cxpResponse -> {
			// convert cxpResponse to uiResponse
			CartCxpResponseUtil1.formatCheckDfillInventoryResponse(cxpResponse, soeResponse);
			return Mono.just(soeResponse);
		});
	}

	/**
	 *
	 * @param uiRequest
	 * @return GetUpgradeReasonCodeUIResponse
	 */
	public Mono<GetUpgradeReasonCodeUIResponse> getUpgradeReasonCodes(GetUpgradeReasonCodeUIRequest uiRequest) {

		GetUpgradeReasonCodeCXPRequest cxpRequest = new GetUpgradeReasonCodeCXPRequest();

		// convert uiRequest to cxpRequest
		cxpRequest = CartCxpRequestUtil.formatGetUpgradeReasonCodesRequest(uiRequest, cxpRequest);

		// call to cxp service
		Mono<GetUpgradeReasonCodeCXPResponse> cxpResponseMono = cxpService.getUpgradeReasonCodes(cxpRequest);

		GetUpgradeReasonCodeUIResponse soeResponse = new GetUpgradeReasonCodeUIResponse();
		return cxpResponseMono == null ? Mono.just(soeResponse) : cxpResponseMono.flatMap(cxpResponse -> {
			// convert cxpResponse to uiResponse
			CartCxpResponseUtil1.formatGetUpgradeReasonCodesResponse(cxpResponse, soeResponse);
			return Mono.just(soeResponse);
		});
	}

	/**
	 * Method to hit CXP with hashkey
	 * @param hashKey
	 * @param salesFlowSessionId
	 * @return status
	 */
	public Mono<MylinkReferralInfoResponse> validateMyLinkReferralInfo(String hashKey, String salesFlowSessionId) {
		MylinkReferralInfoRequest cxpRequest = new MylinkReferralInfoRequest();
		cxpRequest.setHashKey(hashKey);
		cxpRequest.setPartyInteractionType(MYLINK);
		cxpRequest.setSalesFlowSessionId(salesFlowSessionId);

		Mono<MylinkReferralInfoResponse> cxpResponse = cxpService.validateMyLinkReferralInfo(cxpRequest);
		return cxpResponse == null ? Mono.just(new MylinkReferralInfoResponse()) : cxpResponse;
	}

	public FeatureCatalogItem fetchFeatureCatalogResp(String featureId, CatalogResponse catalogResp) {

		if(catalogResp!=null && catalogResp.getData()!=null && CollectionUtilities.isNotEmptyOrNull(catalogResp.getData().getFeatureCatalogItems())){
			return catalogResp.getData().getFeatureCatalogItems().stream()
					.filter(obj-> obj!=null && StringUtilities.isNotEmptyOrNull(obj.getFeatureId()) && obj
							.getFeatureId().equalsIgnoreCase(featureId))
					.findAny()
					.orElse(null);
		}
		return null;
	}
	
	/**
	 * Method to set wirelineAccountInformation in CXP request as per feature flag
	 * 
	 * @param uiWirelineAccInfo
	 * @param cxpLine
	 */
	private void setCxpWirelineAccountInformation(WireLineAccountInformation uiWirelineAccInfo,
			DeviceIdValidationLine cxpLine) {
		cxpLine.setWireLineAccountInformation(uiWirelineAccInfo);
		try {

			logger.info("Setting Cxp wirelineAccountInformation based on featureFlag: {}");
			//featureFlagHelper.isTrialHashFflagEnabled().subscribe(featureFlag -> {
				String networkTrialHash = uiWirelineAccInfo.getNetworkTrialHash();
				logger.info("networkTrialHash condt: {}", StringUtils.isNotBlank(networkTrialHash));
				if (StringUtils.isNotBlank(networkTrialHash)) {
					logger.info("inside networkTrialHash: {}", networkTrialHash);
					String trialMtn = new String(Base64.getDecoder().decode(networkTrialHash.trim())).replace("\n", "");
					logger.info("decoded trialMtn: {}", trialMtn);
					if (StringUtilities.isNotEmptyOrNull(trialMtn) && StringUtilities.isNotEmptyOrNull(trialMtn.split(",")[0])) {
						cxpLine.getWireLineAccountInformation().setNetworkTrialMtn(trialMtn.split(",")[0]);
					}
				}
				logger.info("cxpLine: {}", cxpLine);
			//});
		} catch (Exception e) {
			logger.info("exception with setting CXP wirelineAccountInformation", e);
		}
	}	

}
