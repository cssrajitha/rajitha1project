package onevz.soe.cart.constants;

public class FeatureFlagConstants {

    public static final String INFLOW_CART_FLAG ="inFlowCartFFlag";

    public static final String APPLICATION_NAME_DIGITAL = "Digital";
    public static final String CONFIG_PROFILE_MVA_PROSPECT_CART="MVAProspectCart";
    public static final String FLAG_NAME_CART_OPERATION_WITH_UUID="cartOperationWithUUID";
	public static final String CONFIG_PROFILE_BYOD="byod";
	public static final String FLAG_NAME_NG_PROSPECT_COMBO="ngProspectComboEnabled";
    public static final String APPLICATION_NAME_FWA_DIFITAL="FWA-Digital";
    public static final String CONFIG_PROFILE_FWA_ADDONS= "FWAAddons";
    public static final String FLAG_NAME_FWA_WHWSPO_MODE_FFAG = "whwSpoModeFFlag";
    public static final String FLAG_NAME_SET_ACNEXTGEN_FOR_MVA = "acNextGenCookieForMVAFFlag";
    public static final String STREAM_LINE_NEXTG_CONFIG_P = "StreamlinedSalesNextgen";
    public static final String NGD_CONFIG_TAGGING = "ngdConfiguratorTagginFFlag";
    public static final String APPLICATION_NAME_ASSISTED = "Assisted-Sales";
    public static final String OFFERS_CFG_PROFILE = "OffersCfgProfile";
    public static final String TRADE_3PO_CHOICE_OFFER_FLAG = "trade3POChoiceOfferFFlag";
    public static final String PROFILE_ACCOUNTLANDING = "AccountLanding";
    public static final String FLEXV2_D2D_FLAG = "flexV2D2DExistingLinesFilterFFlag";
    public static final String AWS_CONFIG_PROFILE = "sales";
    public static final String AWS_CONFIG_APP_NAME = "Marketing-Home";
    public static final String CHOICE_OFFER_CFG_PROFILE = "ChoiceOffersCfgProfile";
    public static final String SN_AWS_CONFIG_PROFILE = "SecondNumber";
    public static final String SECOND_NUMBER_TAGGING_FLAG = "secondNumberTaggingFFlag";
    public static final String AWS_FLAG_BMSM_OFFER = "bmsmBonusOfferFFlag";
    public static final String FLEXV2_ASSISTED_TAGGING = "assistedTaggingFFlag";
    public static final String PROFILE_FRAMEWORK = "Framework";
    public static final String DIGITAL_UPG_CFG_PROFILE_NAME = "DigitalUpgradeCfgProfile";
    public static final String ENABLE_ACC_MEM_MIGRATION="enableAccMemberMigration";
    public static final String BAU_UPG_FLAG="bauUpgradeFFlag";
    public static final String DIGITAL_PERFORMANCE_CFG_PROFILE = "DigitalPerformanceCfgProfile";
    public static final String FLAG_NAME_LGPO_OFFER = "lgpoOfferNewApproachFFlag";
    public static final String ROUTER_UPGRADE_CFG_PROFILE = "RouterUpgradesCfgProfile";
    public static final String ROUTER_UPGRADE_FF_FLAG = "routerUpgradeFFlag";
    public static final String APPLICATION_NAME_MARKETING_HOME = "Marketing-Home";
    public static final String CONFIG_PROFILE_SALES = "sales";
    public static final String FWA_CHOICE_OFFER_FFLAG = "fwaChoiceOfferFFlag";
    public static final String EXISTING_NETWORK_TRIAL_VALIDATION_FFLAG = "existingNetworkTrialValidationFFlag";
    public static final String EXISTING_TRIAL_HASH_VALIDATION_FFLAG = "existingTrialHashValidationFFlag";
    public static final String PERFORMANCE_OPTIMIZATION_FFLAG = "performanceOptimizationFFlag";
    public static final String DIGITAL_OFFER_CFG_PROFILE = "DigitalPromosCfgProfile";
    public static final String ENABLE_WINBACK_OFFER_FFLAG = "enableWinBackOfferFFlag";
    public static final String TRADE_IN_PROMOCCheckFFlag ="tradeInPromoCheckFFlag";
    public static final String TRADE_IN_MarketValueFFlag ="tradeInMarketValueFFlag";

    public static final String APPLICATION_NAME_FWA_DIGITAL = "FWA-Digital";
    public static final String MOV_PROFILE_CONFIG = "MoversCfgProfile";
    public static final String FEATURE_FLAG_MOV_UNIFIED_NBS = "moversUnifiedNbsFFlag";

    public static final String FEATURE_FLAG_MOV_OMNI_CART_REQ = "moversCreateCartReqOmniFFlag";
    public static final String ENHANCEMENTTRIAGE_PROFILE_CONFIG = "EnhancementstriagingCfgProfile";
    public static final String FEATURE_FLAG_FWA_UNIFIED_NBS = "fwaUnifiedNbsFFlag";
    public static final String EMBER_CONFIG_PROFILE_NAME = "EmberCfgProfile";
    public static final String EMBER_DISCOUNT_F_FLAG = "emberDiscountFFlag";



    public static final String PEGA_PRDEDECTIVE_PREFETCHF_FLAG = "pegaPredictivePrefetchFFlag";
    public static final String DIGITAL_MINI_CART_CFG_PROFILE = "MiniCartCfgProfile";
    
    public static final String EARLY_UPGRADE_BLOCKERF_FLAG = "earlyUpgradeAndTradeAtHomeBlockerFFlag";
    public static final String PROFILE_TRADEIN = "TradeIn";

    public static final String FIOS_LOGIN_PDP_PEARL_FFLAG = "fiosLoginPDPPearlFFlag";
    public static final String PEARL_CFG_PROFILE = "PearlCfgProfile";
    public static final String ALWAYS_ON_STICKEY_ORDER_SUMMARY_FLAG = "alwaysOnStickyOrderSummaryFFlag";
    public static final String ALWAYS_ON_PRICING_AlIGNMENT_FLAG= "alwaysOnPricingAlignmentFFlag";
    public static final String HOLIDAY_RETURN_POLICY_NSE_FLAG= "holidayReturnPolicyNSEFFlag";

    public static final  String ASSISTED_MFE_TAGGING_FFLAG ="assistedMfeTaggingFFlag";
    public static final String DIGITAL_PROMOS_CFG_PROFILE = "DigitalPromosCfgProfile";
    public static final String DIGITAL_PROMOS_CFG_LIST
            = "addNationalBICOfferInAddPromoIntentAPIFFlag,bogoBTOfferInterstitialFFlag,pearlPromoBundlerFFlag,bmsmIspuFilterByLocationFFlag";
    public static final String DIGITAL_PROMOS_CFG_LIST_FOR_VALIDATE_CART = "saveTheSaleFFlag,cartCloserLastItemFFlag";
    public static final String APPLE_ONE_CFG_LIST = "appleAvailableOffersFFlag";
    public static final String BYOD_CFG_LIST = "byodDigitalChoiceOfferFFlag";
    public static final String PROMO_INTENT_MAP_LIST="promoIntentMapFFlag,bauUpgradePdpTradeinFFlag";
    public static final String SWIFT_CFG_PROFILE = "SwiftCfgProfile";
    public static final String ENABLE_LINEINFO_FFLAG = "enableLineInfoFFlag";
    public static final String NGD_PLANS_TRADEIN_FLOW = "ngdTradeInFFlag";
    public static final String NGD_CLEAR_CART_NSE_FFLAG = "ngdProspectClearCookiesFFlag";

    public static String SOR_XCIO = "SOR-XCIO";
    public static String ELVIS_FLAG_PROFILE = "ElvisCfgProfile";
    public static String ELVIS_FLAG_NAME = "elvisFFlag";
    public static final String CONFIGURATOR = "ConfiguratorCfgProfile";
    public static final String NGD_ABANDONCART_FFLAG = "ngdAbandonedCartFFlag";
    public static final String ENABLE_AM_NEXTGEN_FFLAG = "enableAMNextGenFFlag";
    public static final String ENABLE_MASKING_BYOD = "enableMaskingBYODFFlag";

    public static final String RFEX_ELIGIBILITY_FOR_DFO_FFLAG = "rfexEligibilityForDfoFFlag";

    public static final String WIRELESS_CART_DESIGN_FFLAG= "wirelessCartDesignFFlag";

    public static final String FLAG_NAME_ACTIVATION_FEE_WAIVER_FFAG = "preToPostWaiveActivationFeeFFlag";
    public static final String PRE_TO_POST_CFG_PROFILE_NAME = "PreToPostCfgProfile";

    public static final String BYOD_PROFILE_FEATURE_FLAGS= "enableSaveCartForBYODFFlag";
    public static final String CONFIG_PROFILE_QUICKSHOP_PDP="QuickShopCfgProfile";
    public static final String FLAG_NAME_FOR_QUICKSHOP_TRADEIN="quickShopTradeInFlowFFlag";
    public static final String BYOD_PROFILE_DEVICE_VALIDATION_FEATURE_FLAGS= "enableMVAPromptForEsimBYODFFlag";
    public static final String ENABLE_DEVICEFIRST_PROSPECT = "enableDeviceFirstBYODFFlag";
    public static final String ENABLE_DEVICEFIRST_EXISTING = "enableDeviceFirstForExistingFFlag";
    public static final String UNLIMITEDCOUD_PERK_POSFALAG="unlimitedCloudPerkPosFFlag";
    public static final String SKIP_RESUME_CASE_FFLAG = "skipResumeCaseFFlag";
    public static final String POYP_OFFER_FFLAG = "pOYPOfferFFlag";
    public static final String BYOD_IMEI_RANGE_FFLAG = "enableBYODIMEIRangeFFlag";
    public static final String SKIP_VALIDATE_CART_FFLAG ="skipValidateCartFWAFFlag";
    public static final String DUPLICATE_WARNING_CODE_FIX_FFALAG = "duplicateWarningCodeFixFFlag";
    public static final String AIQUOTE_TAGGING_ENABLED = "aiQuoteTaggingFFlag";
    public static final String BULKUPDATE_AIQUOTE_TAGGING_ENABLED = "bulkUpdateAIQuoteTaggingFFlag";
    public static final String BAU_UPGRADE_PDP_TRADEIN_FFLAG = "bauUpgradePdpTradeinFFlag";
    public static final String PROFILE_QUOTECFG = "QuoteCfgProfile";
    public static final String ASSISTED_LANDING_MFE_TAGGING_FFLAG = "assistedLandingMfeTaggingFFlag";
    public static final String PLAN_SELECTION_PROGRESSIVE_PLANS_FFLAG = "planSelectionProgressivePlansFFlag";
    public static final String DIGITAL_PLANS_CFG_FILE = "DigitalPlansCfgProfile";
    public static final String PROSPECT = "PROSPECT";
    public static final String ENABLE_IMEI_INSTRUCTIONS_FFLAG="enableIMEIInstructionsForOtherDevicesBYODFFlag";
    public static final String ACCOUNT_MANAGEMENT_CX = "AccountManagementCX";
    public static final String PENDING_ORDER_REDIRECTION_FFLAG = "pendingOrderRedirectionFFlag";
    public static final String FWA_UPGRADE_PROFILE_FLAG = "DeviceUpgradeCfgProfile";
    public  static  final  String FWA_UPGRADE_NAME_FFLAG = "fwaTitanUpgradeFFlag";
    public static final String UNIFIEDNBS_CONFIG_PROFILE = "UnifiedNbs";
    public static final String FULLBLOWNNBS_THROTTLING = "fullBlownMfeNbsDigitalFFlag";
    public static final String PAST_DUE_BYOD_FLAG = "enablePastDueBYODFFlag";
    public static final String SAFE_CHECK_FOR_BUYOUT_FFLAG = "safeCheckForBuyOutFFlag";
    public static final String ONECLIK_TAGGING_FFLAG = "oneClickTaggingFFlag";
    public static final String CONFIGURATOR_SRO_CFG = "SroCfgProfile";
    public static final String SRO_FWA_RetrieveCart_FFlag = "sroFWARetrieveCartFFlag";

    public static final String OPP_CONFIGURATOR_FFLAG = "oppConfiguratorFFlag";
    public static final String DIGITAL_PDP_CFG_PROFILE = "digitalPDPCfgProfile";
    public static final String HUB_PROSPECT_CART_COOKIE_DOMAIN_ISSUE_FFLAG = "hubProspectCartCookieDomainIssueFFlag";
    public static final String FLEX_MFE_VALIDATION = "flexMfeValidation";
}
