package onevz.soe.cart.bpm.helper;

import onevz.soe.cart.bpm.service.CartServiceBPMServices;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.requests.AddZipcodePEGARequest;
import onevz.soe.cart.requests.UpdateAccountOwnerPEGARequest;
import onevz.soe.cart.requests.UpdateAccountOwnerPEGAResponse;
import onevz.soe.cart.responses.AddZipcodePEGAResponse;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.ui.requests.AddZipCodeUIRequest;
import onevz.soe.cart.ui.requests.UpdateAccountOwnerUIRequest;
import onevz.soe.cart.ui.responses.BBPAddZipcodeResponse;
import onevz.soe.cart.util.CartPegaRequestUtil4;
import onevz.soe.cart.util.CartPegaRequestUtil9;
import onevz.soe.cart.util.CartPegaResponseUtil;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
public class CartServiceBpmHelper4 {

	private static final Logger logger = LoggerFactory.getLogger(CartServiceBpmHelper4.class);

	@Autowired
	private CartServiceBPMServices services;
	@Autowired
	private RedisHelper redisHelper;

	/**
	 *
	 * @param uiRequest
	 * @return uiResponse
	 *To fetch the process step from PEGA -BBP specific	 */
	public Mono<BBPAddZipcodeResponse> addZipcodeThroughPEGA(AddZipCodeUIRequest uiRequest) {

		AddZipcodePEGARequest request = new AddZipcodePEGARequest();
		BBPAddZipcodeResponse soeResponse = new BBPAddZipcodeResponse();
		Mono<CartRedisData> rr = redisHelper.getDataFromRedis();

		return rr.flatMap(data -> {
			if (uiRequest.getCartInfo().getIntendType().toUpperCase().equalsIgnoreCase("BYOD")) {
				if (StringUtilities.isEmptyOrNull(uiRequest.getCartInfo().getCartCreator())) {
					uiRequest.getCartInfo().setCartCreator(data.getCartCreator());
				} else {
					uiRequest.getCartInfo().setCartCreator(data.getMtn());
				}
				if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber())
						&& StringUtilities.isEmptyOrNull(uiRequest.getCartInfo().getAccountNumber()))
					uiRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
				if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
						&& StringUtilities.isEmptyOrNull(uiRequest.getCartInfo().getProcessingMTN()))
					uiRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			}
			if (uiRequest.getCartInfo().getIntendType().toUpperCase().equalsIgnoreCase(CartConstants.NSE_BYOD)) {
				uiRequest.getCartInfo().setProcessingMTN("newLine1");
			}
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				uiRequest.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				uiRequest.getCartInfo().setCaseId(data.getCaseId());
			logger.info("AddZipcode UI Request After Session Call: {}", uiRequest);
			CartPegaRequestUtil4.formatAddZipcodeRequest(request, uiRequest);
			logger.debug("AddZipcode PEGA Request: {}", request);
			Mono<AddZipcodePEGAResponse> responseServiceMono = null;
			try {
				responseServiceMono = services.addZipcodePEGA(request);
			} catch (SOEHTTPException e) {
				logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
			}
			return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
				CartPegaResponseUtil.formatAddZipcodeResponse(soeResponse, pegaResponse);
				return Mono.just(soeResponse);
			});
		});
	}
	public Mono<UpdateAccountOwnerPEGAResponse> updateAccountOwner(UpdateAccountOwnerUIRequest request,String channelId){
		Mono<CartRedisData> sessionData = redisHelper.getDataFromRedis();
				return sessionData.flatMap(data -> {
					if(request.getCartInfo()!=null) {
						if (StringUtilities.isNotEmptyOrNull(data.getCartId())) {
							request.getCartInfo().setCartId(data.getCartId());
						}
						if (StringUtilities.isEmptyOrNull(request.getCartInfo().getCartCreator()) && !StringUtilities.isEmptyOrNull(data.getCartCreator())) {
							request.getCartInfo().setCartCreator(data.getCartCreator());
						}
						if (StringUtilities.isEmptyOrNull(request.getCartInfo().getCreditAppNum()) && !StringUtilities.isEmptyOrNull(data.getCreditAppNum())) {
							request.getCartInfo().setCreditAppNum(data.getCreditAppNum());
						}
						if (StringUtilities.isNotEmptyOrNull(data.getCaseId())) {
							request.getCartInfo().setCaseId(data.getCaseId());
						}
						if (StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessingMTN()) && !StringUtilities.isEmptyOrNull(data.getProcessingMTN())) {
							request.getCartInfo().setProcessingMTN(data.getProcessingMTN());
						}

						UpdateAccountOwnerPEGARequest updateAccountOwnerPEGARequest = CartPegaRequestUtil9.formatUpdateAccountOwnerPegaRequest(request, channelId);
						try {
							return services.updateAccountOwner(updateAccountOwnerPEGARequest);
						} catch (SOEHTTPException e) {
							logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
						}
					}
					return Mono.just(new UpdateAccountOwnerPEGAResponse());

		});

	}
}
