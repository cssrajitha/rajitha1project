package onevz.soe.cart.controller;

import jakarta.validation.Valid;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.helper.UpdateCartHelper;
import onevz.soe.cart.requests.CartExceedsLimitRequest;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.ui.responses.CartExceedsLimitResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping(value = "cart")
public class CartExceedsVVCLimitController {

    @Autowired
    UpdateCartHelper helper;

    private static final Logger logger = LoggerFactory.getLogger(CartExceedsVVCLimitController.class);

    @PostMapping("/getCartExceedsLimit")
    public Mono<ResponseEntity<CartExceedsLimitResponse>> getCartExceedsLimitData(ServerHttpRequest httpHeader,
                                                                                  ServerHttpResponse httpResponse, @Valid @RequestBody CartExceedsLimitRequest request) {
        logger.debug("getCartExceedsLimit Request: {}", request);
        logger.info("Inside retrieve-cart api");
        return helper.getCartExceedsLimitService(httpHeader, httpResponse, request);
    }
}
