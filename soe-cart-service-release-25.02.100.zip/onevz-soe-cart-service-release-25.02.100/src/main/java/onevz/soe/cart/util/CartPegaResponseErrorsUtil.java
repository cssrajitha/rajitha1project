package onevz.soe.cart.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.model.addPromoIntent.AddPromoIntentUIResponse;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.common.ErrorData;
import onevz.soe.cart.model.updateBarcode.UpdateBarCodeContext;
import onevz.soe.cart.model.updateBarcode.UpdateBarCodeServiceBody;
import onevz.soe.cart.model.updateBarcode.UpdateBarCodeServiceResponse;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.ui.responses.BBPAddZipcodeResponse;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.exception.SOEErrorHolder;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * SOE Response Error Handler class.
 */
public class CartPegaResponseErrorsUtil {
	
	ObjectMapper mapper = new ObjectMapper();

	private CartPegaResponseErrorsUtil() {

	}

	/**
	 * 
	 * @param saveCartUIResponse
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleSaveCartResponseErrors(SaveCartUIResponse saveCartUIResponse) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (saveCartUIResponse.getErrors() != null) {
			errors = new ErrorResponse();

			for (CartError cxpError : saveCartUIResponse.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			CartPegaResponseErrorsUtil2.handleCrossChannelIdIssue(errorList);
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * 
	 * @param updateBarcodeUIResponse
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleUpdateBarCodeResponseErrors(UpdateBarcodeUIResponse updateBarcodeUIResponse) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (updateBarcodeUIResponse.getErrors() != null) {
			errors = new ErrorResponse();

			for (CartError cxpError : updateBarcodeUIResponse.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			CartPegaResponseErrorsUtil2.handleCrossChannelIdIssue(errorList);
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * 
	 * @param response
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleDeviceIdValidationResponseErrors(DeviceIdValidationUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			for (CartError cxpError : response.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * 
	 * @param response
	 * @return
	 */
	public static ErrorResponse handleAddDeviceResponseErrors(AddDeviceUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null && !response.getErrors().isEmpty()) {
			errors = new ErrorResponse();
			errorList = response.getErrors();
			CartPegaResponseErrorsUtil2.handleCrossChannelIdIssue(errorList);
		}
		if (errorList != null)
			errors.setErrors(errorList);
		if (response.getTradeInAdded() != null && errors != null)
			errors.setTradeInAdded(response.getTradeInAdded());
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * 
	 * @param response
	 * @return
	 */
	public static ErrorResponse handleClearAndContinueResponseErrors(ClearAndContinueUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null && !response.getErrors().isEmpty()) {
			errors = new ErrorResponse();

			errorList = response.getErrors();
		}
		if (errorList != null)
			errors.setErrors(errorList);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param response
	 * @return
	 */
	public static ErrorResponse handleResumeAndContinueResponseErrors(ResumeAndContinueUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null && !response.getErrors().isEmpty()) {
			errors = new ErrorResponse();

			errorList = response.getErrors();
		}
		if (errorList != null)
			errors.setErrors(errorList);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * 
	 * @param response
	 * @return
	 */
	public static ErrorResponse handleAddAccessoriesResponseErrors(AddAccessoriesUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null) {
			errors = new ErrorResponse();
			errorList = response.getErrors();
			CartPegaResponseErrorsUtil2.handleCrossChannelIdIssue(errorList);
		}
		if (errorList != null)
			errors.setErrors(errorList);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * 
	 * @param response
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleAddFeaturesResponseErrors(AddFeaturesUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		ErrorData errorData = new ErrorData();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();
			errorList = response.getErrors();
			CartPegaResponseErrorsUtil2.handleCrossChannelIdIssue(errorList);
		}
		if(response.getErrorData() !=null && errors!=null){
			errorData = response.getErrorData();
			errors.setErrorData(errorData);
		}
		if (errorList != null)
			errors.setErrors(errorList);
		return errors == null ? new ErrorResponse() : errors;
	}
	public static void setErrorCategory(ErrorResponse response,String errCategory){
		if(null != response.getErrors() && !response.getErrors().isEmpty())
			response.getErrors().get(0).setErrorCategory(errCategory);
	}
	public static void setErrorCategory(List<CartError> errors,String errCategory){
		if(null != errors && !errors.isEmpty())
			errors.get(0).setErrorCategory(errCategory);
	}
	/**
	 * 
	 * @param response
	 * @return
	 */
	public static ErrorResponse handleAddPlanResponseErrors(AddPlanUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null) {
			errors = new ErrorResponse();
			errorList = response.getErrors();
			CartPegaResponseErrorsUtil2.handleCrossChannelIdIssue(errorList);
		}
		if (errorList != null)
			errors.setErrors(errorList);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * 
	 * @param response
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleUpdateDeviceSimIdResponseErrors(UpdateDeviceSIMIdUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			errorList = response.getErrors();
		}
		if (errorList != null)
			errors.setErrors(errorList);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * 
	 * @param response
	 * @return
	 */
	public static ErrorResponse handlePastDuesResponseErrors(PastDuesUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			errorList = response.getErrors();
		}
		if (errorList != null)
			errors.setErrors(errorList);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * 
	 * @param response
	 * @return
	 */
	public static ErrorResponse handleRemoveLinesResponseErrors(RemoveLinesUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null) {
			errors = new ErrorResponse();
			errorList = response.getErrors();
			CartPegaResponseErrorsUtil2.handleCrossChannelIdIssue(errorList);
		}
		if (errorList != null) {
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * 
	 * @param response
	 * @return
	 */
	public static ErrorResponse handleAddBuyoutResponseErrors(AddBuyoutUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			errorList = response.getErrors();
		}
		if (errorList != null)
			errors.setErrors(errorList);

		return errors == null ? new ErrorResponse() : errors;
	}
	
	/**
	 * 
	 * @param response
	 * @return errorResp
	 */
	public static ErrorResponse handleRemoveBvoOffersResponseErrors(UpdateBvoOffersUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			errorList = response.getErrors();
		}
		if (errorList != null)
			errors.setErrors(errorList);

		return errors == null ? new ErrorResponse() : errors;
	}
	
	/**
	 * 
	 * @param response
	 * @return errorResp
	 */
	public static ErrorResponse handleUpdateSellerPriceResponseErrors(UpdateSellerPriceUIResponseNew response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			errorList = response.getErrors();
		}
		if (errorList != null)
			errors.setErrors(errorList);

		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * 
	 * @param response
	 * @return
	 */
	public static ErrorResponse handleUpdateEdgeUpResponseErrors(UpdateEdgeupUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			errorList = response.getErrors();
		}
		if (errorList != null)
			errors.setErrors(errorList);

		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * 
	 * @param response
	 * @return
	 */
	public static ErrorResponse handleInitiateCheckoutResponseErrors(InitiateCheckoutUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null) {
			errors = new ErrorResponse();
			errorList = response.getErrors();
			CartPegaResponseErrorsUtil2.handleCrossChannelIdIssue(errorList);
		}
		if (errorList != null)
			errors.setErrors(errorList);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * 
	 * @param response
	 * @return
	 */
	public static ErrorResponse handleAddDownPaymentResponseErrors(AddDownPaymentUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null) {
			errors = new ErrorResponse();
			errorList = response.getErrors();
			CartPegaResponseErrorsUtil2.handleCrossChannelIdIssue(errorList);
		}
		if (errorList != null)
			errors.setErrors(errorList);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * 
	 * @param response
	 * @return
	 */
	public static ErrorResponse handleCreateLineResponseErrors(CreateLineUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null) {
			errors = new ErrorResponse();
			errorList = response.getErrors();
			CartPegaResponseErrorsUtil2.handleCrossChannelIdIssue(errorList);
		}
		if (errorList != null)
			errors.setErrors(errorList);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * 
	 * @param response
	 * @return
	 */
	public static ErrorResponse handleNumberShareResponseErrors(NumberShareUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			errorList = response.getErrors();
		}
		if (errorList != null)
			errors.setErrors(errorList);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param response
	 * @return
	 */
	public static ErrorResponse handleServiceAddressResponseErrors(ServiceAddressUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			errorList = response.getErrors();
		}
		if (errorList != null)
			errors.setErrors(errorList);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param response
	 * @return
	 */
	public static ErrorResponse handleBillingAddressResponseErrors(BillingAddressUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			errorList = response.getErrors();
		}
		if (errorList != null)
			errors.setErrors(errorList);
		return errors == null ? new ErrorResponse() : errors;
	}


	/**
	 *
	 * @param response
	 * @return
	 */
	public static ErrorResponse handleE911AddressResponseErrors(E911AddressUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			errorList = response.getErrors();
		}
		if (errorList != null)
			errors.setErrors(errorList);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param response
	 * @return
	 */
	public static ErrorResponse handleInstantCreditDownPaymentResponseErrors(
			InstantCreditDownPaymentUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			errorList = response.getErrors();
		}
		if (errorList != null)
			errors.setErrors(errorList);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param response
	 * @return
	 */
	public static ErrorResponse handleSalesRepAndLocationCodeResponseErrors(
			SalesRepAndLocationCodeUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			for (CartError cxpError : response.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param response
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleEffectiveDateOverrideResponseErrors(EffectiveDateOverrideUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			for (CartError cxpError : response.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param response
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleManualDiscountResponseErrors(ManualDiscountUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			for (CartError cxpError : response.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param response
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleAssignMtnResponseErrors(AssignMtnUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			for (CartError cxpError : response.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param response
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleDeassignMtnResponseErrors(DeassignMtnUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			for (CartError cxpError : response.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * 
	 * @param response
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleUpdatePurchaseOrderResponseErrors(UpdatePurchaseOrderUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			errorList = response.getErrors();
		}
		if (errorList != null)
			errors.setErrors(errorList);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * 
	 * @param response
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleAddAdd5GBulkOrderResponseErrors(Add5GBulkOrderUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null && !response.getErrors().isEmpty()) {
			errors = new ErrorResponse();

			errorList = response.getErrors();
		}
		if (errorList != null)
			errors.setErrors(errorList);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * 
	 * @param response
	 * @return errors
	 */
	public static ErrorResponse handleEffectiveDateResponseErrors(EffectiveDateUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			for (CartError cxpError : response.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * 
	 * @param response
	 * @return errors
	 */
	public static ErrorResponse handleManualPairingResponseErrors(ManualPairingUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null && !response.getErrors().isEmpty()) {
			errors = new ErrorResponse();

			errorList = response.getErrors();
		}
		if (errorList != null)
			errors.setErrors(errorList);
		return errors == null ? new ErrorResponse() : errors;

	}

	/**
	 * 
	 * @param response
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleRevokeRebatesResponseErrors(RevokeRebatesUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null && !response.getErrors().isEmpty()) {
			errors = new ErrorResponse();

			errorList = response.getErrors();
		}
		if (errorList != null)
			errors.setErrors(errorList);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param response
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleVoidOrderResponseErrors(VoidOrderUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			for (CartError cxpError : response.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * 
	 * @param response
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleSplitExceededAmountResponseErrors(SplitExceededAmountUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			for (CartError cxpError : response.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param response
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleCancelCaseResponseErrors(CancelCaseUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			for (CartError cxpError : response.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * 
	 * @param response
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleActivateLaterResponseErrors(ActivateLaterUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			for (CartError cxpError : response.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * 
	 * @param response
	 * @return errorResp
	 */
	public static ErrorResponse handleUpdateTransferUpgradeResponseErrors(UpdateTransferUpgradeUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			errorList = response.getErrors();
		}
		if (errorList != null)
			errors.setErrors(errorList);

		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * 
	 * @param response
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleAddNickNameResponseErrors(AddNickNameUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null && !response.getErrors().isEmpty()) {
			errors = new ErrorResponse();

			errorList = response.getErrors();
		}
		if (errorList != null)
			errors.setErrors(errorList);
		return errors == null ? new ErrorResponse() : errors;
	}

	public static ErrorResponse handleUpdateDetailsToSessionErrors(boolean data) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (!data) {
			errors = new ErrorResponse();
			CartError cartError = new CartError();
			cartError.setErrorCode("500");
			cartError.setErrorMessage("Session Update Failed");
			errorList.add(cartError);
		}
		if (errors!=null)
			errors.setErrors(errorList);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param updateChatIdUIResponse
	 * @return errors
	 */
	public static ErrorResponse handleUpdateChatIdResponseErrors(UpdateChatIdUIResponse updateChatIdUIResponse) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (updateChatIdUIResponse.getErrors() != null) {
			errors = new ErrorResponse();
			for (CartError cxpError : updateChatIdUIResponse.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			CartPegaResponseErrorsUtil2.handleCrossChannelIdIssue(errorList);
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * 
	 * @param response
	 * @return errors
	 */
	public static ErrorResponse handleClearCartResponseErrors(ClearCartUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null) {

			errors = new ErrorResponse();

			errorList = response.getErrors();
		}
		if (errorList != null) {
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/*
	 * @param response
	 * 
	 * @return
	 */
	public static AddDeviceUIResponse handleCommonError(SOEErrorHolder soeError) {

		AddDeviceUIResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (null != soeError) {
			errors = new AddDeviceUIResponse();
			CartPegaResponseErrorsUtil2.formatErrorList(soeError, errorList);
			errors.setErrors(errorList);
		}
		return errors == null ? new AddDeviceUIResponse() : errors;
	}

	/*
	 * @param response
	 * 
	 * @return
	 */
	public static Mono<ResponseEntity<SOEErrorHolder>> handleAEMError(SOEHTTPException soeError) {

		SOEErrorHolder errors = null;
		if (null != soeError) {
			if (null != soeError.getErrorHolder())
				errors = soeError.getErrorHolder();
			else
				errors = new SOEErrorHolder();
		}
		return errors == null
				? Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new SOEErrorHolder()))
				: Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errors));
	}

	/**
	 *
	 * @param response
	 * @return errors
	 */
	public static ErrorResponse handleUpdateWFMInfoResponseErrors(UpdateWFMInfoUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null) {
			errors = new ErrorResponse();
			errorList = response.getErrors();
		}
		if (errorList != null) {
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param response
	 * @return
	 */
	public static ErrorResponse handleRPSE911AddressUpdateResponseErrors(RPSE911AddressUpdateUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			errorList = response.getErrors();
		}
		if (errorList != null)
			errors.setErrors(errorList);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param response
	 * @return
	 */
	public static ErrorResponse handleRPSReleasePendingOrderResponseErrors(RPSReleasePendingOrderResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			errorList = response.getErrors();
		}
		if (errorList != null)
			errors.setErrors(errorList);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param response
	 * @return
	 */
	public static ErrorResponse handleRPSE911AddressRetrieveResponseErrors(RPSE911AddressRetrieveUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			errorList = response.getErrors();
		}
		if (errorList != null)
			errors.setErrors(errorList);
		return errors == null ? new ErrorResponse() : errors;
	}
	/**
	 *
	 * @param response
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleAddPromoIntentUIResponseErrors(AddPromoIntentUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = new ArrayList<>();
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			for (CartError cxpError : response.getErrors()) {
				CartError error = cxpError;
				errorList.add(error);
			}
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}
		public static ErrorResponse handleAddZipcodeResponseErrors(BBPAddZipcodeResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null) {
			errors = new ErrorResponse();

			errorList = response.getErrors();
		}
		if (errorList != null)
			errors.setErrors(errorList);
		return errors == null ? new ErrorResponse() : errors;
	}

	public static ErrorResponse populatePegaErrorForEmptyResponse() {
		ErrorResponse errors = new ErrorResponse();
		List<CartError> errorList = new ArrayList<CartError>();
		CartError cartError = new CartError();

		cartError.setNamespace("CXP_Pega_BPM");
		cartError.setName("VALIDATION_ERROR");
		cartError.setDebug_id("");
		cartError.setId("");
		cartError.setMessage("Empty Response");
		errorList.add(cartError);
		errors.setErrors(errorList);
		return errors;
	}

	public static ErrorResponse populateResponseErrorForProductInquiry(String returnMessage, String returnCode) {
		ErrorResponse errors = new ErrorResponse();
		List<CartError> errorList = new ArrayList<CartError>();
		CartError cartError = new CartError();

		cartError.setNamespace("/ejav-eps-nsa/nssit1/productmgmt/multilineProductInquiry");
		cartError.setName("VALIDATION_ERROR");
		cartError.setDebug_id("");
		cartError.setId(returnCode);
		cartError.setMessage(returnMessage);
		errorList.add(cartError);
		errors.setErrors(errorList);
		return errors;
	}


	public static void hideSensitiveInfoInResponse(UpdateBarcodeUIResponse resp) {
		 Optional<UpdateBarCodeContext> updateBarCodeContext = Optional.of(resp).map(UpdateBarcodeUIResponse::getServiceBody).map(UpdateBarCodeServiceBody::getServiceResponse)
				.map(UpdateBarCodeServiceResponse::getContext);
		updateBarCodeContext.map(UpdateBarCodeContext::getCartInfo).ifPresent(cartInfo -> cartInfo.setCartId(null));
		updateBarCodeContext.ifPresent(context -> context.setCaseId(null));
	}

	public static ErrorResponse handleDeleteCartResponseErrors(DeleteCartUIResponse response) {

		ErrorResponse errors = null;
		List<CartError> errorList = null;
		if (response.getErrors() != null) {

			errors = new ErrorResponse();

			errorList = response.getErrors();
		}
		if (errorList != null) {
			errors.setErrors(errorList);
		}
		return errors == null ? new ErrorResponse() : errors;
	}
}
