package onevz.soe.cart.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

/**
 * 
 * @author PANDSI9
 *
 */
public class CommonCartServiceException extends ResponseStatusException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 * @param status
	 * @param message
	 */
	public CommonCartServiceException(HttpStatus status,String message) {
		super(status, message);
	}


}
