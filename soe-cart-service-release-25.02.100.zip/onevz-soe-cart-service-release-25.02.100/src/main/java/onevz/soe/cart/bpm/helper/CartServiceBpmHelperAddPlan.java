package onevz.soe.cart.bpm.helper;

import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.cxp.feature.Flag;
import onevz.cxp.feature.util.FeatureFlag;
import onevz.soe.cart.bpm.service.CartServiceBPMServices;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.constants.FeatureFlagConstants;
import onevz.soe.cart.cxp.helper.CatalogServiceHelper;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.gql.schema.SubscriptionInfo;
import onevz.soe.cart.helper.FeatureFlagHelper;
import onevz.soe.cart.helper.RedisHelper2;
import onevz.soe.cart.helper.RedisHelper3;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.retrieveCustomer.BillAccount;
import onevz.soe.cart.model.retrieveCustomer.MobileInfo;
import onevz.soe.cart.requests.AddPlanPEGARequest;
import onevz.soe.cart.responses.AddPlanPEGAResponse;
import onevz.soe.cart.responses.CatalogResponse;
import onevz.soe.cart.responses.RetrieveCustomerCXPResponse;
import onevz.soe.cart.ui.requests.AddPlanUIRequest;
import onevz.soe.cart.ui.responses.AddPlanUIResponse;
import onevz.soe.cart.util.CartPegaRequestUtil2;
import onevz.soe.cart.util.CartPegaResponseUtil;
import onevz.soe.cart.util.CartUtil;
import onevz.soe.cart.util.PlanChangeWarningUtil;
import onevz.soe.customerprofile.model.gql.assisted.PerkSPOInfo;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * CartService Bpm Helper class.
 */
@Service
public class CartServiceBpmHelperAddPlan {

	private static final Logger logger = LoggerFactory.getLogger(CartServiceBpmHelperAddPlan.class);

	@Autowired
	private CartServiceBPMServices services;

	@Autowired
	private CatalogServiceHelper catalogServiceHelper;

	@Autowired
	private CartServiceCXPServices cxpServices;

	@Autowired
	private RedisHelper3 redisHelper3;

	@Autowired
	private RedisHelper2 redisHelper2;
	
	@Autowired
	private CartServiceBpmHelperAddPlanHelper addPlanHelper;

	@Value("${planSku}")
	private boolean planSku;

	@Value("${enableSecurityForCart}")
	private boolean enableSecurityForCart;

	@Autowired
	SOELoginSessionBean soeLoginSessionBean;

	@Autowired
	ObjectMapper objectMapper;

	@Autowired
	FeatureFlag featureFlag;

	@Autowired
	FeatureFlagHelper featureFlagHelper;

	/**
	 * 
	 * @param uiRequest
	 * @return AddPlanUIResponse
	 * 
	 */
	public Mono<AddPlanUIResponse> addPlan(AddPlanUIRequest uiRequest) {

		logger.debug("Inside CartServiceBpmHelper --> addPlan");
		Mono<Boolean> featureFlagMono = featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_FWA_DIFITAL,
				FeatureFlagConstants.CONFIG_PROFILE_FWA_ADDONS, FeatureFlagConstants.FLAG_NAME_FWA_WHWSPO_MODE_FFAG, true);
		Mono<Boolean> featureFlagMono2 = featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_ASSISTED,
				FeatureFlagConstants.OFFERS_CFG_PROFILE, FeatureFlagConstants.FWA_CHOICE_OFFER_FFLAG, false);
		Mono<Flag> featureFlagMono3 = featureFlag.getFeatureFlag(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
				FeatureFlagConstants.PRE_TO_POST_CFG_PROFILE_NAME, FeatureFlagConstants.FLAG_NAME_ACTIVATION_FEE_WAIVER_FFAG);
		//FFlag for OPP OPPConfiguator
		boolean oppConfiguratorFlag = featureFlagHelper.getFeatureFlagWithAccNumThrottle(FeatureFlagConstants.APPLICATION_NAME_DIGITAL, FeatureFlagConstants.DIGITAL_UPG_CFG_PROFILE_NAME, FeatureFlagConstants.OPP_CONFIGURATOR_FFLAG, uiRequest.getCartInfo().getAccountNumber(), uiRequest.getCartInfo().getCartCreator());

		return Mono.zip(featureFlagMono,featureFlagMono2,featureFlagMono3).flatMap(tuple3 ->{

			AddPlanPEGARequest request = new AddPlanPEGARequest();

			// convert ui request to pega request
			CartPegaRequestUtil2.formatAddPlanRequest(request, uiRequest, tuple3.getT1(), tuple3.getT2(), tuple3.getT3(),oppConfiguratorFlag);

			return featureFlagHelper.fetchDigitalPegaPredictivePrefetchFFlag().flatMap(featureFlag -> {
				if (featureFlag) {
					//2775-PRFX
					request.getServiceBody().getServiceRequest().getContext().getContextInfo().setPredictivePrefetchEnabled(uiRequest.isPredictivePrefetchEnabled() ? CartConstants.ON : CartConstants.OFF);
				}

				Mono<AddPlanPEGAResponse> addPlanResponse = null;

				try {
					// pega call for add plan
					if (uiRequest.getCartInfo() != null && StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getLineActivityType())
							&& uiRequest.getCartInfo().getLineActivityType().equalsIgnoreCase("TSE")) {
						addPlanResponse = services.addPlanTYS(request);
					} else {
						addPlanResponse = services.addPlan(request);
					}
				} catch (SOEHTTPException e) {
					logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
				}

				AddPlanUIResponse soeResponse = new AddPlanUIResponse();

				if (redisHelper2.isPendingCancelFlow(uiRequest)) {
					return pendingCancelFlow(uiRequest, soeResponse, addPlanResponse);
				} else {
					return addPlanResponse == null ? Mono.just(new AddPlanUIResponse()) : addPlanResponse.flatMap(pegaResponse -> {
						CartPegaResponseUtil.formatAddPlanResponse(soeResponse, pegaResponse);
						String channelType = CartUtil.getChannelType(uiRequest.getChannelId());
						if (StringUtils.isNotEmpty(channelType) && CartConstants.CHANNEL_ASSISTED.equalsIgnoreCase(channelType)) {
							return updatePlanChangeWarningMessages(soeResponse, channelType, uiRequest);
						} else {
							return addPlanHelper.updateFeatureChangeDetails(soeResponse, channelType);
						}
					});
				}
			});
		});
	}

	public Mono<AddPlanUIResponse> pendingCancelFlow(AddPlanUIRequest uiRequest, AddPlanUIResponse soeResponse, Mono<AddPlanPEGAResponse> addPlanResponse) {
		logger.info("Inside pendingCancelFlow");
		Mono<PerkSPOInfo> rr = redisHelper2.readPerkSPOInfo();
		Mono<AddPlanUIRequest> addPlanUIRequestMono= Mono.just(uiRequest);
		Mono<AddPlanUIResponse> addPlanUIResponseMono = addPlanResponse == null ? Mono.just(new AddPlanUIResponse()) : addPlanResponse.flatMap(pegaResponse -> {
			CartPegaResponseUtil.formatAddPlanResponse(soeResponse, pegaResponse);
			String channelType = CartUtil.getChannelType(uiRequest.getChannelId());
			if (StringUtils.isNotEmpty(channelType) && CartConstants.CHANNEL_ASSISTED.equalsIgnoreCase(channelType)) {
				return updatePlanChangeWarningMessages(soeResponse, channelType, uiRequest);
			} else {
				return addPlanHelper.updateFeatureChangeDetails(soeResponse, channelType);
			}
		});
		Mono<Boolean> updateRedis = redisHelper2.updatePerkSpoInfoInRedis(addPlanUIRequestMono,rr);
		return Mono.zip(addPlanUIResponseMono,updateRedis).flatMap(data->{
			if(data.getT2())
				logger.info("Redis updated for perkInfo");
			else
				logger.error("Error occurred while updating the perkInfo into the redis");
			return Mono.just(data.getT1());
		});
	}


	/**
	 * This method is responsible for adding all plan warning messages during plan
	 * change.
	 * 
	 * @param addPlanResponse - add plan response
	 * @return - add plan response
	 */
	private Mono<AddPlanUIResponse> updatePlanChangeWarningMessages(AddPlanUIResponse addPlanResponse,
			String channelType,AddPlanUIRequest uiRequest) {
		logger.debug("Inside CartServiceBpmHelper --> updatePlanChangeWarningMessages");

		if (checkIfResponseEmpty(addPlanResponse)) {
			logger.debug(
					"Inside CartServiceBpmHelper --> updatePlanChangeWarningMessages --> AddPlanUIResponse is empty");
			return Mono.just(addPlanResponse);
		}
		Mono<String> flowType = redisHelper3.getFlowTypeFromRedis();
		Mono<String> aiQuoteFlagFromRedis = redisHelper3.getAIQuoteFlagFromRedis();
		Mono<Boolean> aiQuoteTaggingFeatureFlag = featureFlagHelper.fetchAiQuoteTaggingFeatureFlag();
		return Mono.zip(flowType,aiQuoteFlagFromRedis, aiQuoteTaggingFeatureFlag).flatMap(z3 -> {
			if (!"winBack".equalsIgnoreCase(z3.getT1()) || checkIfAiQuote(z3.getT2(), z3.getT3()) ) {
				Mono<RetrieveCustomerCXPResponse> customerResponseMono = Objects
						.nonNull(addPlanResponse.getServiceBody().getServiceResponse().getContext().getCustomerInfo())
						&& StringUtils.isNotEmpty(addPlanResponse.getServiceBody().getServiceResponse().getContext()
								.getCustomerInfo().getAccountNumber())
										? cxpServices.retrieveCustomer(addPlanResponse.getServiceBody().getServiceResponse()
												.getContext().getCustomerInfo().getAccountNumber())
										: Mono.just(new RetrieveCustomerCXPResponse());
				return customerResponseMono.flatMap(customerResponse -> {

					Mono<List<CatalogResponse>> droppedSpoCatalogListMono = getDroppedSpoCatalogList(addPlanResponse);
					Mono<Map<String, CatalogResponse>> allPlanCatalogMapMono = getAllPlanCatalogMap(customerResponse,
							addPlanResponse);

					return mergeDroppedSpoAndCatalogResponse(droppedSpoCatalogListMono, allPlanCatalogMapMono, customerResponse, addPlanResponse, channelType, uiRequest);
				});
			}
			return Mono.just(addPlanResponse);
		});
	}

	private boolean checkIfResponseEmpty(AddPlanUIResponse addPlanResponse) {
		return Objects.isNull(addPlanResponse) || Objects.isNull(addPlanResponse.getServiceBody())
				|| Objects.isNull(addPlanResponse.getServiceBody().getServiceResponse())
				|| Objects.isNull(addPlanResponse.getServiceBody().getServiceResponse().getContext())
				|| Objects.isNull(addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo())
				|| ArrayUtils.isEmpty(
				addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getLines());
	}

	private boolean checkIfAiQuote(String aiQuoteFlagFromRedis, Boolean aiQuoteTaggingFeatureFlag){
		return  aiQuoteTaggingFeatureFlag &&  StringUtils.equalsIgnoreCase(aiQuoteFlagFromRedis,"true");
	}
	private Mono<AddPlanUIResponse>  mergeDroppedSpoAndCatalogResponse(Mono<List<CatalogResponse>> droppedSpoCatalogListMono, Mono<Map<String, CatalogResponse>> allPlanCatalogMapMono, RetrieveCustomerCXPResponse customerResponse, AddPlanUIResponse addPlanResponse, String channelType, AddPlanUIRequest uiRequest){
		return Mono.zip(droppedSpoCatalogListMono, allPlanCatalogMapMono).flatMap(tuple -> {
			List<CatalogResponse> droppedSpocatalogResponses = tuple.getT1();
			Map<String, CatalogResponse> allPlanCatalogMap = tuple.getT2();
			Map<String, List<String>> planInfoMap = new HashMap<>();
			if (null != customerResponse && null != customerResponse.getData()
					&& null != customerResponse.getData().getCustomer() && CollectionUtilities
					.isNotEmptyOrNull(customerResponse.getData().getCustomer().getBillAccounts()))
				planInfoMap = getPlanInfoMap(
						customerResponse.getData().getCustomer().getBillAccounts().get(0), addPlanResponse);
			// Set 5G UWB loss warning message
			set5GUWBLossWarningMessage(planInfoMap, addPlanResponse);
			// Set enforce kids plan warning message
			setEnforceKidsPlanWarningMessage(allPlanCatalogMap, planInfoMap, addPlanResponse);
			// Set verify kids promo loss warning message
			setVerifyKidsPromoLossMessage(allPlanCatalogMap, planInfoMap, addPlanResponse);

			setCloudStorageDroppedWarningMessage(addPlanResponse, allPlanCatalogMap);
			setDisneyLossWarningMessage(addPlanResponse, droppedSpocatalogResponses);
			setPairedPhoneDiscountWarningMessage(addPlanResponse);
			setDisneyDropWarningMessage(addPlanResponse);
			setAppleMusicDropWarningMessage(addPlanResponse, getCustomerAddressState(customerResponse));
			setEcpdDiscountWarningMessage(addPlanResponse, customerResponse, allPlanCatalogMap);
			addPlanHelper.setPromotionWarningMessage(addPlanResponse, channelType);
			// To set EBB Warning messages: PSTGRO-6578
			setEmergencyBroadBandDiscountLossMessage(addPlanResponse, channelType);
			//To set ACB warning messages - PSTGRO-8728, 8797
			setAcbDiscountWarningMessage(addPlanResponse, channelType);

			getPlanDetailsFromCatalogResponse(addPlanResponse, allPlanCatalogMap, uiRequest);
			//VZWCS-16190
			if (CartConstants.ASSISTED.equalsIgnoreCase(channelType))
				PlanChangeWarningUtil.setFiveGPlanChangeWarning(
						addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo(), uiRequest.getChannelId());

			return Mono.just(addPlanResponse);
		});

	}

	private boolean _2TBcloudFeatureExists(Line line) {
		return line.getSfos() !=null && Arrays.stream(line.getSfos()).filter ( sfo -> sfo != null && sfo.getId() != null
				&& CartConstants._2TB_CLOUD_FEATURES.contains(sfo.getId())
				&& sfo.getActionIndicator().equalsIgnoreCase("Z")).findAny().isPresent();
	}

	private boolean _2TBPerkNotAdd(Line line) {
		return line.getSpos() !=null && Arrays.stream(line.getSpos()).filter (spo -> spo != null && spo.getId() != null
				&& CartConstants.TB_PERK_SPO.equalsIgnoreCase(spo.getId())
				&& spo.getActionIndicator().equalsIgnoreCase("A")).findAny().isPresent();
	}

	private boolean isbyuPlan(Line line, Map<String, CatalogResponse> allPlanCatalogMap) {
		if(line.getPlan() != null && line.getPlan().getId() !=null) {
			CatalogResponse cxpcatalogRes = allPlanCatalogMap.get(line.getPlan().getId());
			if(cxpcatalogRes != null && cxpcatalogRes.getData() !=null && cxpcatalogRes.getData().getPlanSku() != null
					&& cxpcatalogRes.getData().getPlanSku().getCategoryCode() != null
					&& cxpcatalogRes.getData().getPlanSku().getCategoryCode().equalsIgnoreCase("92")){
				return Boolean.TRUE;
			}
		}
		return Boolean.FALSE;
	}
	
	/**
	 *
	 * @param addPlanResponse
	 * @param channelType
	 *          To set EBB Warning messages: PSTGRO-6578
	 */
	private void setEmergencyBroadBandDiscountLossMessage(AddPlanUIResponse addPlanResponse, String channelType) {
		logger.debug("Inside CartServiceBpmHelper --> setEmergencyBroadBandDiscountLossMessage");
		// check for cloud feature drop
		Optional<Line> ebbDroppedLine = Arrays
				.stream(addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getLines())
				.filter(line -> Objects.nonNull(line) && ArrayUtils.isNotEmpty(line.getSpos())
						&& (isSpoExist(line.getSpos(), CartConstants.EMERGENCY_BROADBAND_DISCOUNT_SPO_1946, "D") || isSpoExist(line.getSpos(), CartConstants.EMERGENCY_BROADBAND_DISCOUNT_SPO_1945, "D")))
				.findAny();
		if (ebbDroppedLine.isPresent()) {
			logger.debug("Setting EBB_DISCOUNT_KEY in addplan response");
			Arrays
					.stream(addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getLines())
					.filter(line -> Objects.nonNull(line) && CollectionUtilities.isNotEmptyOrNull(line.getDisqualifiedPropositions()))
					.forEach(line -> {
						StringBuffer warningMessage = new StringBuffer();
						if (line.getDisqualifiedPropositions().size() > 0)
							warningMessage.append(CartConstants.EBB_WARNING_COMBO);
						else
							warningMessage.append(CartConstants.EBB_WARNING_NONCOMBO);
						addEBBWarningMessageToResponse(CartConstants.EBB_DISCOUNT_KEY, warningMessage.toString(), addPlanResponse,
								channelType, line.getMtn());
					});

		}

	}
	
	// PSTGRO-8728, 8797 story changes - To set ACB warning messages
	private void setAcbDiscountWarningMessage(AddPlanUIResponse addPlanResponse, String channelType) {
		StringBuffer warningMessage = new StringBuffer();	
		if (null != addPlanResponse && null != addPlanResponse.getServiceBody()
				&& null != addPlanResponse.getServiceBody().getServiceResponse()
				&& null != addPlanResponse.getServiceBody().getServiceResponse().getContext()
				&& null != addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()
				&& CollectionUtilities.isNotEmptyOrNull(addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getDiscountLossIndicators())) {				
			if (addPlanHelper.getAcbDiscountLossIndicator(addPlanResponse)) {
				warningMessage.append(
						"By switching plans, you'll lose your discount. You are currently receiving the Affordable Connectivity Program discount. By switching plans, you will lose that discount.");
			} 
			if (getAcbStateDiscountLossIndicator(addPlanResponse)) {
				warningMessage.append(
						"You are currently receiving a Federal level Affordable Connectivity Program discount and you are currently receiving a temporary state level Affordable Connectivity Program discount. By switching plans, you will lose these discounts.");
			}
		}
		if(warningMessage.length()>0)
			addACBWarningMessageToResponse(warningMessage.toString(), addPlanResponse, channelType);
	}

	private boolean getAcbStateDiscountLossIndicator(AddPlanUIResponse addPlanResponse) {

		return addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getDiscountLossIndicators().stream()
				.filter(discountLossIndicators -> null != discountLossIndicators.getDiscountIndicator()
						&& discountLossIndicators.getDiscountIndicator().equalsIgnoreCase("ACBSTATE_DISCOUNT"))
				.findAny().isPresent();

	}
	private void addACBWarningMessageToResponse(String message, AddPlanUIResponse addPlanResponse,String channelType) {
		logger.debug("Inside CartServiceBpmHelper --> addACBWarningMessageToResponse");
		CartServiceCartInfo cartInfo = new CartServiceCartInfo();
		if (null != addPlanResponse && null != addPlanResponse.getServiceBody()
				&& null != addPlanResponse.getServiceBody().getServiceResponse()
				&& null != addPlanResponse.getServiceBody().getServiceResponse().getContext()
				&& null != addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo())
			cartInfo = addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo();
		if (StringUtils.isNotEmpty(channelType) && CartConstants.CHANNEL_ASSISTED.equalsIgnoreCase(channelType)) {
			List<PlanChangeWarningMessage> planChangeWarningMessages = CollectionUtilities
					.isNotEmptyOrNull(cartInfo.getPlanChangeWarningMessages()) ? cartInfo.getPlanChangeWarningMessages()
							: new ArrayList<>();
			PlanChangeWarningMessage planChangeWarningMessage = new PlanChangeWarningMessage();
			planChangeWarningMessage.setWarningMessage(message);
			planChangeWarningMessages.add(planChangeWarningMessage);
			cartInfo.setPlanChangeWarningMessages(planChangeWarningMessages);

		}
	}

	/**
	 *
	 * @param key
	 * @param message
	 * @param addPlanResponse
	 * @param channelType     To set EBB Warning messages: PSTGRO-6578
	 */
	private void addEBBWarningMessageToResponse(String key, String message, AddPlanUIResponse addPlanResponse,
												String channelType, String mtn) {
		logger.debug("Inside CartServiceBpmHelper --> addEBBWarningMessageToResponse");
		CartServiceCartInfo cartInfo = addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo();
		if (StringUtils.isNotEmpty(channelType) && CartConstants.CHANNEL_ASSISTED.equalsIgnoreCase(channelType)) {
			List<PlanChangeWarningMessage> planChangeWarningMessages = CollectionUtilities
					.isNotEmptyOrNull(cartInfo.getPlanChangeWarningMessages()) ? cartInfo.getPlanChangeWarningMessages()
					: new ArrayList<>();
			PlanChangeWarningMessage planChangeWarningMessage = new PlanChangeWarningMessage();
			planChangeWarningMessage.setMessageKey(key);
			planChangeWarningMessage.setWarningMessage(message);
			planChangeWarningMessage.setMtn(mtn);
			planChangeWarningMessages.add(planChangeWarningMessage);
			cartInfo.setPlanChangeWarningMessages(planChangeWarningMessages);
		} else {
			List<FeatureChangeDetail> featureChangeDetails = CollectionUtilities.isNotEmptyOrNull(
					cartInfo.getFeatureChangeDetails()) ? cartInfo.getFeatureChangeDetails() : new ArrayList<>();
			FeatureChangeDetail featureChangeDetail = new FeatureChangeDetail();
			featureChangeDetails.add(featureChangeDetail);
			cartInfo.setFeatureChangeDetails(featureChangeDetails);
		}
	}

	/**
	 * Sets the warning message for the ecpd discount which is not carried over.
	 *
	 * @param addPlanResponse  - add plan response
	 * @param customerResponse - customer response
	 * @param planCatalogMap   - map containing plan id and catalog response
	 */
	private void setEcpdDiscountWarningMessage(AddPlanUIResponse addPlanResponse,
											   RetrieveCustomerCXPResponse customerResponse, Map<String, CatalogResponse> planCatalogMap) {
		logger.debug("Inside CartServiceBpmHelper --> setEcpdDiscountWarningMessage");
		String ecpdProfileId = getEcpdProfileId(customerResponse);
		// check for ecpd kids discount not carry over
		if (MapUtils.isNotEmpty(planCatalogMap) && StringUtils.isNotEmpty(ecpdProfileId)) {
			Arrays
					.stream(addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getLines())
					.filter(line -> Objects.nonNull(line) && StringUtils.isNotEmpty(line.getMtn())
							&& isEcpdKidsDiscountNotCarryOver(getSelectedPlanId(line),
							getExistingPlanId(customerResponse, line.getMtn()), ecpdProfileId,
							planCatalogMap)).forEach(line -> setPlanChangeWarningMessage(CartConstants.ECPD_KIDS_DISCOUNT_NOT_CARRY_OVER_KEY, addPlanResponse, line.getMtn()));
			logger.debug("Setting ECPD_KIDS_DISCOUNT_NOT_CARRY_OVER_KEY in addplan response");

			Arrays
					.stream(addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getLines())
					.filter(line -> Objects.nonNull(line) && StringUtils.isNotEmpty(line.getMtn())
							&& isEcpdDiscountNotCarryOver(getSelectedPlanId(line),
							getExistingPlanId(customerResponse, line.getMtn()), ecpdProfileId,
							planCatalogMap)).forEach(line -> setPlanChangeWarningMessage(CartConstants.ECPD_DISCOUNT_NOT_CARRY_OVER_KEY, addPlanResponse, line.getMtn()));
			logger.debug("Setting ECPD_DISCOUNT_NOT_CARRY_OVER_KEY in addplan response");
		}
	}

	/**
	 * Sets the warning message if the cloude storage is dropped.
	 *
	 * @param addPlanResponse   - add plan response
	 * @param allPlanCatalogMap
	 */
	private void setCloudStorageDroppedWarningMessage(AddPlanUIResponse addPlanResponse, Map<String, CatalogResponse> allPlanCatalogMap) {
		logger.debug("Inside CartServiceBpmHelper --> setCloudStorageDroppedWarningMessage");
		// check for cloud feature drop
		StringBuilder featuresMessageCode = new StringBuilder();
		Boolean unlimitedcloudPerkPosFlag = featureFlag.isFeatureFlagEnabled(FeatureFlagConstants.AWS_CONFIG_APP_NAME,
				FeatureFlagConstants.SWIFT_CFG_PROFILE, FeatureFlagConstants.UNLIMITEDCOUD_PERK_POSFALAG, false);
		boolean duplicateFeatureCodeFixFFlag = featureFlag.isFeatureFlagEnabled(FeatureFlagConstants.AWS_CONFIG_APP_NAME,
				FeatureFlagConstants.SWIFT_CFG_PROFILE, FeatureFlagConstants.DUPLICATE_WARNING_CODE_FIX_FFALAG, false);
		Arrays
				.stream(addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getLines())
				.filter(line -> Objects.nonNull(line) && Objects.nonNull(line.getPlan())
						&& StringUtils.isNotEmpty(line.getPlan().getId()) && CollectionUtilities.isNotEmptyOrNull(line.getFeatureMessages()))
				.forEach(line -> {
					StringBuilder featureMessageCode = featuresMessageCode;
					if (duplicateFeatureCodeFixFFlag) {
						featureMessageCode = new StringBuilder();
					}

					setCloudFeatureMessages(line, featureMessageCode, unlimitedcloudPerkPosFlag);

					if(isbyuPlan(line, allPlanCatalogMap) && _2TBcloudFeatureExists(line) && !_2TBPerkNotAdd(line)){
						featureMessageCode.append("VERIZON_CLOUD_DISCOUNT_DROP_SUSTAIN_2TB");
					}

					if(StringUtilities.isNotEmptyOrNull(featureMessageCode.toString())) {
						setPlanChangeWarningMessage(featureMessageCode.toString() , addPlanResponse,line.getMtn());
					}
				});
	}

	private void setCloudFeatureMessages(Line line, StringBuilder featureMessageCode, Boolean unlimitedcloudPerkPosFlag) {
		line.getFeatureMessages().stream().filter(Objects::nonNull)
				.forEach(featureMessage-> {

					setVerizonCloudDiscountFeatureMessage(featureMessage, featureMessageCode, unlimitedcloudPerkPosFlag);

					setByoCloudAddFeatureMessage(featureMessage, featureMessageCode);

					setByoCloudDropFeatureMessage(featureMessage, featureMessageCode);

					setByocldUnliFeatureMessage(featureMessage, featureMessageCode);

				});
	}

	private static void setByocldUnliFeatureMessage(FeatureMessages featureMessage, StringBuilder featureMessageCode) {
		if (featureMessage.getName() != null && featureMessage.getName().equalsIgnoreCase("BYOCLDUNLI")) {
			featureMessageCode.append("_").append(featureMessage.getName()).append("_").append(featureMessage.getAction());
		}
	}

	private static void setByoCloudDropFeatureMessage(FeatureMessages featureMessage, StringBuilder featureMessageCode) {
		if (featureMessage.getName() != null && featureMessage.getName().equalsIgnoreCase("BYOCLOUD")
				&& featureMessage.getAction().equalsIgnoreCase("DROP")) {
			featureMessageCode.append(featureMessage.getName()).append("_").append(featureMessage.getAction());
		}
	}

	private void setByoCloudAddFeatureMessage(FeatureMessages featureMessage, StringBuilder featureMessageCode) {
		if (featureMessage.getName() != null && featureMessage.getName().equalsIgnoreCase("BYOCLOUD")
				&& featureMessage.getAction().equalsIgnoreCase("ADD")) {
			featureMessageCode.append("_").append(featureMessage.getName()).append("_").append(featureMessage.getAction());
		}
	}

	private static void setVerizonCloudDiscountFeatureMessage(FeatureMessages featureMessage, StringBuilder featureMessageCode,Boolean unlimitedcloudPerkPosFlag) {

		if (featureMessage.getName() != null && (featureMessage.getName().equalsIgnoreCase("VERIZON_CLOUD_DISCOUNT_LEGACY")
				|| featureMessage.getName().equalsIgnoreCase("VERIZON_CLOUD_DISCOUNT") || (unlimitedcloudPerkPosFlag && featureMessage.getName().equalsIgnoreCase("VERIZON_CLOUD_DISCOUNT_INCL")))) {
			featureMessageCode.append(featureMessage.getName()).append("_").append(featureMessage.getAction());
			if (CollectionUtilities.isNotEmptyOrNull(featureMessage.getFields())) {
				featureMessage.getFields().forEach(field -> {
					if(field.getName() !=null && field.getName().equalsIgnoreCase("CLOUD")) {
						featureMessageCode.append("_").append(field.getName()).append("_").append(field.getValue());
					}
				});
			}
		}
	}

	/**
	 * Sets the warning message for the loss of the paired phone discount.
	 * 
	 * @param addPlanResponse - add plan response
	 */
	private void setPairedPhoneDiscountWarningMessage(AddPlanUIResponse addPlanResponse) {
		logger.debug("Inside CartServiceBpmHelper --> setPairedPhoneDiscountWarningMessage");
		// check for lines with 50% discount loss for the paired phones
		List<String> currentPairedPhoneList = Arrays
				.stream(addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getLines())
				.filter(line -> Objects.nonNull(line) && Objects.nonNull(line.getPairingInfo())
						&& Objects.nonNull(line.getPairingInfo().getCurrentPairedPhone()))
				.map(line -> line.getPairingInfo().getCurrentPairedPhone()).distinct().collect(Collectors.toList());
		List<String> newPairedPhoneList = Arrays
				.stream(addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getLines())
				.filter(line -> Objects.nonNull(line) && Objects.nonNull(line.getPairingInfo())
						&& Objects.nonNull(line.getPairingInfo().getNewPairedPhone()))
				.map(line -> line.getPairingInfo().getCurrentPairedPhone()).distinct().collect(Collectors.toList());
		if (CollectionUtils.isNotEmpty(currentPairedPhoneList)
				&& (CollectionUtils.isNotEmpty(currentPairedPhoneList) && CollectionUtils.isEmpty(newPairedPhoneList))
				|| (CollectionUtils.isNotEmpty(currentPairedPhoneList) && CollectionUtils.isNotEmpty(newPairedPhoneList)))
			currentPairedPhoneList.stream()
					.filter(mtn -> StringUtils.isNotEmpty(mtn) && !newPairedPhoneList.contains(mtn)).forEach(mtn -> {
						setPlanChangeWarningMessage(CartConstants.MPP_PAIRED_PHONE_DISCOUNT_KEY, addPlanResponse, mtn);
					});
		logger.debug("Setting MPP_PAIRED_PHONE_DISCOUNT_KEY in addplan response");
	}

	/**
	 * Sets the warning message for if the apple music is dropped.
	 * 
	 * @param addPlanResponse      - add plan response
	 * @param customerAddressState - billing state
	 */
	private void setAppleMusicDropWarningMessage(AddPlanUIResponse addPlanResponse, String customerAddressState) {
		logger.debug("Inside CartServiceBpmHelper --> setAppleMusicDropWarningMessage");

		Arrays
				.stream(addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getLines())
				.filter(line -> Objects.nonNull(line) && ArrayUtils.isNotEmpty(line.getSpos())
						&& isSpoExist(line.getSpos(), CartConstants.APPLE_MUSIC_INCLUDED_SPO, "D"))
				.filter(line -> Objects.nonNull(line) && ArrayUtils.isNotEmpty(line.getSfos())
						&& isSpoExist(line.getSpos(), CartConstants.APPLE_MUSIC_SUBSCRIPTION_SPO, "Z"))
				.forEach(line->{
					if(Objects.nonNull(customerAddressState)&& StringUtils.isNotEmpty(customerAddressState.trim())) {
						if (customerAddressState.equalsIgnoreCase(CartConstants.NEW_MEXICO)) {
							logger.debug("Setting APPLE_MUSIC_NEW_MEXICO_BILLING_KEY in addplan response");
							setPlanChangeWarningMessage(CartConstants.APPLE_MUSIC_NEW_MEXICO_BILLING_KEY, addPlanResponse,line.getMtn());
						} else {
							logger.debug("Setting APPLE_MUSIC_BILLING_KEY in addplan response");
							setPlanChangeWarningMessage(CartConstants.APPLE_MUSIC_BILLING_KEY, addPlanResponse,line.getMtn());
						}
					}
				});
	}
	/**
	 * Sets the warning message for if the disney bundle is dropped.
	 *
	 * @param addPlanResponse      - add plan response
	 */
	private void setDisneyDropWarningMessage(AddPlanUIResponse addPlanResponse) {
		logger.debug("Inside CartServiceBpmHelper --> setDisneyDropWarningMessage");
		if (null != addPlanResponse && null != addPlanResponse.getServiceBody()
				&& null != addPlanResponse.getServiceBody().getServiceResponse()
				&& null != addPlanResponse.getServiceBody().getServiceResponse().getContext()
				&& null != addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()
				&& CollectionUtilities.isNotEmptyOrNull(addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getSubscriptionInfos())) {
			List<SubscriptionInfo> subscriptionInfoList = addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getSubscriptionInfos();
			for (SubscriptionInfo subscriptionInfo : subscriptionInfoList) {
				if ((StringUtilities.isNotEmptyOrNull(subscriptionInfo.getName())
						&& ("DISNEYHARDBUNDLE".equalsIgnoreCase(subscriptionInfo.getName())
						|| "DISNEY".equalsIgnoreCase(subscriptionInfo.getName())
						|| "DISNEY-INCL-NOT-ENROLL".equalsIgnoreCase(subscriptionInfo.getName())) )
						&& StringUtilities.isNotEmptyOrNull(subscriptionInfo.getNextAction()) && "CANCEL".equalsIgnoreCase(subscriptionInfo.getNextAction())
						&& StringUtilities.isNotEmptyOrNull(subscriptionInfo.getNextActionReason()) && "BAYOU".equalsIgnoreCase(subscriptionInfo.getNextActionReason())) {

					logger.debug("Setting DISNEY_BUNDLE_DROP_KEY in addplan response");
					setPlanChangeWarningMessage(CartConstants.DISNEY_BUNDLE_DROP_KEY, addPlanResponse, "");
				}
			}
		}
	}
	/**
	 * Returns the selected plan id for the mtn
	 * 
	 * @param line - line
	 * @return String selected plan id
	 */
	private String getSelectedPlanId(Line line) {
		logger.debug("Inside CartServiceBpmHelper --> getSelectedPlanId");
		return Objects.nonNull(line) && Objects.nonNull(line.getPlan())
				&& StringUtils.isNotEmpty(line.getPlan().getId()) ? line.getPlan().getId() : "";
	}

	/**
	 * Returns the existing plan id for the mtn
	 * 
	 * @param customerResponse - customer response
	 * @param mtn              - mtn
	 * @return String existing plan id
	 */
	private String getExistingPlanId(RetrieveCustomerCXPResponse customerResponse, String mtn) {
		logger.debug("Inside CartServiceBpmHelper --> getExistingPlanId");
		String existingPlanId = "";
		if (Objects.nonNull(customerResponse) && Objects.nonNull(customerResponse.getData())
				&& Objects.nonNull(customerResponse.getData().getCustomer())
				&& CollectionUtils.isNotEmpty(customerResponse.getData().getCustomer().getBillAccounts())) {
			Optional<MobileInfo> mobileInfoOptional = customerResponse.getData().getCustomer().getBillAccounts()
					.stream()
					.filter(billAccount -> billAccount != null && CollectionUtils.isNotEmpty(billAccount.getMtns()))
					.map(billAccount -> billAccount.getMtns()).flatMap(mobileInfos -> mobileInfos.stream())
					.filter(mobileInfo -> Objects.nonNull(mobileInfo) && Objects.nonNull(mobileInfo.getPricePlanInfo())
							&& StringUtils.isNotEmpty(mobileInfo.getPricePlanInfo().getPlanId())
							&& StringUtils.isNotEmpty(mobileInfo.getMtn()) && mobileInfo.getMtn().equalsIgnoreCase(mtn))
					.findAny();
			if (mobileInfoOptional.isPresent()) {
				existingPlanId = mobileInfoOptional.get().getPricePlanInfo().getPlanId();
			}
		}
		return existingPlanId;
	}

	/**
	 * Returns the billing state from the cart response
	 * 
	 * @param customerResponse - customer response
	 * @return String - billing state
	 */
	private String getCustomerAddressState(RetrieveCustomerCXPResponse customerResponse) {
		logger.debug("Inside CartServiceBpmHelper --> getCustomerAddressState");
		return Objects.nonNull(customerResponse) && Objects.nonNull(customerResponse.getData())
				&& Objects.nonNull(customerResponse.getData().getCustomer())
				&& customerResponse.getData().getCustomer().getAddress() != null
				&& customerResponse.getData().getCustomer().getAddress().getState() != null
						? customerResponse.getData().getCustomer().getAddress().getState()
						: "";
	}

	/**
	 * Returns the ecpd profile id
	 * 
	 * @param customerResponse - customer response
	 * @return String - ecpd profile id
	 */
	private String getEcpdProfileId(RetrieveCustomerCXPResponse customerResponse) {
		logger.debug("Inside CartServiceBpmHelper --> getEcpdProfileId");
		return Objects.nonNull(customerResponse) && Objects.nonNull(customerResponse.getData())
				&& Objects.nonNull(customerResponse.getData().getCustomer())
				&& Objects.nonNull(customerResponse.getData().getCustomer().getEcpdProfile())
				&& StringUtils.isNotEmpty(customerResponse.getData().getCustomer().getEcpdProfile().getProfileId())
						? customerResponse.getData().getCustomer().getEcpdProfile().getProfileId()
						: "";
	}

	/**
	 * Checks if the plan carries over the ecpd kids discount or not
	 * 
	 * @param selectedPlanId - selected plan id
	 * @param existingPlanId - existing plan id
	 * @param ecpdProfileId  - ecpd profile id
	 * @param planCatalogMap - map for the plan id and catalog response
	 * @return boolean
	 */
	private boolean isEcpdKidsDiscountNotCarryOver(String selectedPlanId, String existingPlanId, String ecpdProfileId,
			Map<String, CatalogResponse> planCatalogMap) {
		logger.debug("Inside CartServiceBpmHelper --> isEcpdKidsDiscountNotCarryOver");
		CatalogResponse catalogResponse = planCatalogMap.get(selectedPlanId);

		if (StringUtils.isNotEmpty(selectedPlanId) && StringUtils.isNotEmpty(existingPlanId)
				&& !existingPlanId.equalsIgnoreCase(selectedPlanId) && Objects.nonNull(catalogResponse)) {
			if (StringUtils.isNotEmpty(ecpdProfileId) && Objects.nonNull(catalogResponse.getData())
					&& Objects.nonNull(catalogResponse.getData().getPlanSku())
					&& StringUtils.isNotEmpty(catalogResponse.getData().getPlanSku().getCategoryCode())
					&& StringUtils.isNotEmpty(catalogResponse.getData().getPlanSku().getCollectionCode())) {
				// check for ecpd kids discount not carry over
				if (!ecpdProfileId.equalsIgnoreCase(CartConstants.ECPD_ID_MILITARY)
						&& !ecpdProfileId.equalsIgnoreCase(CartConstants.ECPD_ID_FIRST_RESPONDER)
						&& !ecpdProfileId.equalsIgnoreCase(CartConstants.ECPD_ID_EMPLOYEE)
						&& CartConstants.HEX_CATEGORY
								.equalsIgnoreCase(catalogResponse.getData().getPlanSku().getCategoryCode())
						&& catalogResponse.getData().getPlanSku().getCollectionCode()
								.equalsIgnoreCase(CartConstants.KIDS_PLAN_SOR_COLLECTION_CODE)) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Checks if the plan carries over the ecpd discount or not
	 * 
	 * @param selectedPlanId - selected plan id
	 * @param existingPlanId - existing plan id
	 * @param ecpdProfileId  - ecpd profile id
	 * @param planCatalogMap - map for the plan id and catalog response
	 * @return boolean
	 */
	private boolean isEcpdDiscountNotCarryOver(String selectedPlanId, String existingPlanId, String ecpdProfileId,
			Map<String, CatalogResponse> planCatalogMap) {
		logger.debug("Inside CartServiceBpmHelper --> isEcpdDiscountNotCarryOver");
		CatalogResponse catalogResponse = planCatalogMap.get(selectedPlanId);

		if (StringUtils.isNotEmpty(selectedPlanId) && StringUtils.isNotEmpty(existingPlanId)
				&& !existingPlanId.equalsIgnoreCase(selectedPlanId) && Objects.nonNull(catalogResponse)) {
			if (StringUtils.isNotEmpty(ecpdProfileId) && Objects.nonNull(catalogResponse.getData())
					&& Objects.nonNull(catalogResponse.getData().getPlanSku())
					&& StringUtils.isNotEmpty(catalogResponse.getData().getPlanSku().getCategoryCode())
					&& StringUtils.isNotEmpty(catalogResponse.getData().getPlanSku().getCollectionCode())) {
				// check for ecpd discount not carry over
				if (!ecpdProfileId.equalsIgnoreCase(CartConstants.ECPD_ID_MILITARY)
						&& !ecpdProfileId.equalsIgnoreCase(CartConstants.ECPD_ID_EMPLOYEE)
						&& CartConstants.HEX_CATEGORY
								.equalsIgnoreCase(catalogResponse.getData().getPlanSku().getCategoryCode())
						&& !catalogResponse.getData().getPlanSku().getCollectionCode()
								.equalsIgnoreCase(CartConstants.KIDS_PLAN_SOR_COLLECTION_CODE)) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * This method updates the plan warning message key in add plan reponse
	 * 
	 * @param msgkey          - message key
	 * @param addPlanResponse - add plan response
	 */
	private void setPlanChangeWarningMessage(String msgkey, AddPlanUIResponse addPlanResponse, String mtn) {
		logger.debug("Inside CartServiceBpmHelper --> setPlanChangeWarningMessage");
		CartServiceCartInfo cartInfo = addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo();
		PlanChangeWarningMessage message = new PlanChangeWarningMessage(msgkey,mtn);
		if (cartInfo.getPlanChangeWarningMessages() == null) {
			List<PlanChangeWarningMessage> warningMessages = new ArrayList<>();
			warningMessages.add(message);
			cartInfo.setPlanChangeWarningMessages(warningMessages);
		} else {
//			if (cartInfo.getPlanChangeWarningMessages().stream()
//					.filter(msg -> msgkey.equalsIgnoreCase(msg.getMessageKey())).count() == 0) {
//				cartInfo.getPlanChangeWarningMessages().add(message);
//			}
			List<PlanChangeWarningMessage> warningMessage=cartInfo.getPlanChangeWarningMessages();
			warningMessage.add(message);
			cartInfo.setPlanChangeWarningMessages(warningMessage);
		}
	}

	/**
	 * Set 5G UMB loss warning message
	 * 
	 * @param planInfoMap
	 * @param addPlanResponse - add plan response
	 */
	private void set5GUWBLossWarningMessage(Map<String, List<String>> planInfoMap, AddPlanUIResponse addPlanResponse) {
		logger.debug("Inside CartServiceBpmHelper --> set5GUWBLossWarningMessage");
		Line[] lines = addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getLines();
		List<String> planList = new ArrayList<>();
		for (Line line : lines) {
			String mtn = "";
			if (StringUtilities.isNotEmptyOrNull(line.getMtn()))
				mtn = line.getMtn();
			if (planInfoMap.containsKey(mtn))
				planList = getPlanDetailsForMtn(mtn, planInfoMap);
			if (CollectionUtilities.isNotEmptyOrNull(planList) && planList.size() > 1
					&& StringUtilities.isNotEmptyOrNull(planList.get(0))
					&& StringUtilities.isNotEmptyOrNull(planList.get(1))
					&& CartConstants.MPP_LOSS_MSG_FOR_START_PLANS.contains(planList.get(0))
					&& CartConstants.MPP_LOSS_MSG_SELECTED_PLAN.equalsIgnoreCase(planList.get(1))) {
				logger.debug("set _5G_UWB_LOSS_KEY --> " + CartConstants.FIVE_G_UWB_LOSS_KEY);
				setPlanChangeWarningMessage(CartConstants.FIVE_G_UWB_LOSS_KEY, addPlanResponse,mtn);
				break;
			}
		}
	}

	private List<String> getPlanDetailsForMtn(String mtn, Map<String, List<String>> planInfoMap) {
		List<String> planMap = new ArrayList<>();
		Optional<Map.Entry<String, List<String>>> planMapOptional = planInfoMap.entrySet().stream()
				.filter(e -> null!= e && StringUtilities.isNotEmptyOrNull(e.getKey()) && e.getKey().equals(mtn)).findAny();
		if(planMapOptional.isPresent()) {			
			planMap = planMapOptional.get().getValue();
		}
		return planMap;
	}

	/**
	 * Method checks whether account is enrolled in auto pay
	 * 
	 * @param addPlanResponse - add plan response
	 * @return - True/Flase
	 */
	private boolean isAccountEnrolledInAutoPay(AddPlanUIResponse addPlanResponse) {
		logger.debug("Inside CartServiceBpmHelper --> isAccountEnrolledInAutoPay");
		AutoPayEnrollmentDetails autoPayEnrollmentDetails = addPlanResponse.getServiceBody().getServiceResponse()
				.getContext().getCartInfo().getAutoPayEnrollmentDetails();
		if (autoPayEnrollmentDetails != null
				&& StringUtilities.isNotEmptyOrNull(autoPayEnrollmentDetails.getIsAutoPayEnrolled())
				&& "Y".equalsIgnoreCase(autoPayEnrollmentDetails.getIsAutoPayEnrolled())) {
			logger.debug("isAccountEnrolledInAutoPay --> " + Boolean.TRUE);
			return Boolean.TRUE;
		}
		logger.debug("isAccountEnrolledInAutoPay --> " + Boolean.FALSE);
		return Boolean.FALSE;
	}

	/**
	 * Method to return existing lines
	 * 
	 * @param planInfoMap
	 * @return existing lines only
	 */
	private Map<String, List<String>> getExistingLines(Map<String, List<String>> planInfoMap) {
		return planInfoMap.entrySet().stream()
				.filter(entry -> StringUtilities.isNotEmptyOrNull(entry.getValue().get(0)))
				.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
	}

	/**
	 * Method to return upgraded lines
	 * 
	 * @param planInfoMap
	 * @return existing lines only
	 */
	private Map<String, List<String>> getUpgradedLines(Map<String, List<String>> planInfoMap) {
		return planInfoMap.entrySet().stream()
				.filter(entry -> StringUtilities.isNotEmptyOrNull(entry.getValue().get(0))
						&& entry.getValue().size() > 1 && StringUtilities.isNotEmptyOrNull(entry.getValue().get(1)))
				.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
	}

	/**
	 * Method to return new lines
	 * 
	 * @param planInfoMap
	 * @return new lines only
	 */
	private Map<String, List<String>> getAALLines(Map<String, List<String>> planInfoMap) {
		return planInfoMap.entrySet().stream().filter(entry -> StringUtilities.isEmptyOrNull(entry.getValue().get(0)))
				.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
	}

	/**
	 * Set enforce kids plan warning message
	 * 
	 * @param allPlanCatalogMap
	 * @param planInfoMap
	 * @param addPlanResponse   - add plan response
	 */
	private void setEnforceKidsPlanWarningMessage(Map<String, CatalogResponse> allPlanCatalogMap,
			Map<String, List<String>> planInfoMap, AddPlanUIResponse addPlanResponse) {
		logger.debug("Inside CartServiceBpmHelper --> setEnforceKidsPlanWarningMessage");

		for (Map.Entry<String, List<String>> entry : planInfoMap.entrySet()) {
			String mtn=entry.getKey();
			String existingPlanId = entry.getValue().get(0);
			String selectedPlanId = "";
			if (entry.getValue().size() > 1)
				selectedPlanId = entry.getValue().get(1);
			if (StringUtilities.isNotEmptyOrNull(existingPlanId) && StringUtilities.isNotEmptyOrNull(selectedPlanId)
					&& allPlanCatalogMap.containsKey(existingPlanId) && allPlanCatalogMap.containsKey(selectedPlanId)
					&& allPlanCatalogMap.get(existingPlanId) != null
					&& allPlanCatalogMap.get(existingPlanId).getData() != null
					&& allPlanCatalogMap.get(existingPlanId).getData().getPlanSku() != null
					&& CartConstants.HEX_PLAN_SOR_CATEGORY_CODE.equalsIgnoreCase(
							allPlanCatalogMap.get(existingPlanId).getData().getPlanSku().getCategoryCode())
					&& allPlanCatalogMap.get(selectedPlanId) != null
					&& allPlanCatalogMap.get(selectedPlanId).getData() != null
					&& allPlanCatalogMap.get(selectedPlanId).getData().getPlanSku() != null
					&& CartConstants.KIDS_PLAN_SOR_COLLECTION_CODE.equalsIgnoreCase(
							allPlanCatalogMap.get(selectedPlanId).getData().getPlanSku().getCollectionCode())) {
				logger.debug("set ENFORCE_KIDS_PLAN_KEY --> " + CartConstants.ENFORCE_KIDS_PLAN_KEY);
				setPlanChangeWarningMessage(CartConstants.ENFORCE_KIDS_PLAN_KEY, addPlanResponse, mtn);
				break;
			}
		}
	}

	/**
	 * Set verify kids promo loss message
	 * 
	 * @param allPlanCatalogMap
	 * @param planInfoMap
	 * @param addPlanResponse   - add plan response
	 */
	private void setVerifyKidsPromoLossMessage(Map<String, CatalogResponse> allPlanCatalogMap,
			Map<String, List<String>> planInfoMap, AddPlanUIResponse addPlanResponse) {
		logger.debug("Inside CartServiceBpmHelper --> setVerifyKidsPromoLossMessage");
		long hexPlancount = 0;
		long kidsPlancount = 0;
		long hexPlanALLCount = 0;
		long kidsPlanChangedCount = 0;
		Map<String, List<String>> existingLinesMap = getExistingLines(planInfoMap);
		Map<String, List<String>> upgradedLinesMap = getUpgradedLines(planInfoMap);
		Map<String, List<String>> aalLinesMap = getAALLines(planInfoMap);
		Map<String, List<CatalogResponse>> planRefExisting = CollectionUtilities.isNotEmptyOrNull(existingLinesMap)
				? getPlanReferenceDataMap(existingLinesMap, allPlanCatalogMap)
				: null;
		Map<String, List<CatalogResponse>> planRefUpgraded = CollectionUtilities.isNotEmptyOrNull(upgradedLinesMap)
				? getPlanReferenceDataMap(upgradedLinesMap, allPlanCatalogMap)
				: null;
		Map<String, List<CatalogResponse>> planRefAAL = CollectionUtilities.isNotEmptyOrNull(aalLinesMap)
				? getPlanReferenceDataMap(aalLinesMap, allPlanCatalogMap)
				: null;

		if (planRefExisting != null) {
			hexPlancount = CollectionUtilities
					.isNotEmptyOrNull(planRefExisting)
							? planRefExisting.entrySet().stream()
									.filter(entry -> CartConstants.HEX_PLAN_SOR_CATEGORY_CODE
											.equalsIgnoreCase(getPlanCategoryCode(entry)))
									.count()
							: 0;
			kidsPlancount = CollectionUtilities.isNotEmptyOrNull(planRefExisting) ? planRefExisting.entrySet().stream()
					.filter(entry -> CartConstants.KIDS_PLAN_SOR_COLLECTION_CODE
							.equalsIgnoreCase(null != entry.getValue().get(0)
									? entry.getValue().get(0).getData().getPlanSku().getCollectionCode()
									: ""))
					.count() : 0;
		}
		if (planRefUpgraded != null) {
			kidsPlanChangedCount = CollectionUtilities.isNotEmptyOrNull(planRefUpgraded) ? planRefUpgraded.entrySet()
					.stream()
					.filter(entry -> CartConstants.KIDS_PLAN_SOR_COLLECTION_CODE
							.equalsIgnoreCase(entry.getValue().get(0).getData().getPlanSku().getCollectionCode())
							&& entry.getValue().size() > 1
							&& !CartConstants.KIDS_PLAN_SOR_COLLECTION_CODE
									.equalsIgnoreCase(null != entry.getValue().get(1)
											? entry.getValue().get(1).getData().getPlanSku().getCollectionCode()
											: ""))
					.count() : 0;
		}
		if (planRefAAL != null) {
			hexPlanALLCount = CollectionUtilities.isNotEmptyOrNull(planRefAAL) ? planRefAAL.entrySet().stream()
					.filter(entry -> entry.getValue().size() > 1 && CartConstants.HEX_PLAN_SOR_CATEGORY_CODE
							.equalsIgnoreCase(null != entry.getValue().get(1)
									? entry.getValue().get(1).getData().getPlanSku().getCategoryCode()
									: ""))
					.count() : 0;
		}

		if (CollectionUtilities.isNotEmptyOrNull(existingLinesMap) && hexPlancount == 4
				&& !isAccountEnrolledInAutoPay(addPlanResponse) && kidsPlancount != 0) {
			if (kidsPlanChangedCount > 0 || CollectionUtilities.isEmptyOrNull(aalLinesMap) && hexPlanALLCount > 0) {
				logger.debug("set JUST_KIDS_PROMO_LOSS_KEY --> " + CartConstants.JUST_KIDS_PROMO_LOSS_KEY);
				setPlanChangeWarningMessage(CartConstants.JUST_KIDS_PROMO_LOSS_KEY, addPlanResponse,"");
			}

		}
	}
	
	/**
	 * Returns the plan catalog map
	 * 
	 * @param addPlanResponse - add plan response
	 * @return Map containing plan id and catalog response
	 */
	private Mono<List<CatalogResponse>> getDroppedSpoCatalogList(AddPlanUIResponse addPlanResponse) {
		logger.debug("Inside CartServiceBpmHelper --> getDroppedSpoCatalogList");

		List<String> droppedSpoIdList = Arrays
				.stream(addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getLines())
				.filter(line -> Objects.nonNull(line) && ArrayUtils.isNotEmpty(line.getSpos()))
				.map(line -> line.getSpos()).flatMap(spos -> Arrays.stream(spos)).collect(Collectors.toList()).stream()
				.filter(spo -> StringUtils.isNotEmpty(spo.getActionIndicator())
						&& spo.getActionIndicator().equalsIgnoreCase("D") && StringUtils.isNotEmpty(spo.getId()))
				.map(spo -> spo.getId()).collect(Collectors.toList()).stream().distinct().collect(Collectors.toList());

		if (CollectionUtils.isNotEmpty(droppedSpoIdList)) {
			return catalogServiceHelper.getSPOs(droppedSpoIdList);
		}

		return Mono.just(new ArrayList<>());
	}

	/**
	 * get plan collection code for existing lines
	 * 
	 * @param entry
	 * @return
	 */
	private String getPlanCategoryCode(Map.Entry<String, List<CatalogResponse>> entry) {
		if (entry.getValue().size() > 1) {
			if (entry.getValue().get(1) == null) {
				if (entry.getValue().get(0) == null) {
					return "";
				} else {
					return entry.getValue().get(0).getData().getPlanSku().getCategoryCode();
				}
			}
			return entry.getValue().get(1).getData().getPlanSku().getCategoryCode();
		}
		return "";
	}

	/**
	 * Method to construct plan map for all lines
	 * 
	 * @param billAccount
	 * @param addPlanResponse
	 * @return plan map
	 */
	private Map<String, List<String>> getPlanInfoMap(BillAccount billAccount, AddPlanUIResponse addPlanResponse) {
		logger.debug("Inside CartServiceBpmHelper --> getPlanInfoMap");
		Map<String, List<String>> planMap = new HashMap<>();
		// get plan details for existing lines
		billAccount.getMtns().stream().forEach(mobileInfo -> {
			if (null != mobileInfo.getMtnStatus()
					&& StringUtilities.isEmptyOrNull(mobileInfo.getMtnStatus().getIsActive())
					|| Boolean.parseBoolean(mobileInfo.getMtnStatus().getIsActive())) {
				List<String> planList = new ArrayList<>();
				Line checkPlanChangedLine = getCPCLine(mobileInfo.getMtn(), addPlanResponse);
				if (checkPlanChangedLine == null) {
					if (null != mobileInfo.getPricePlanInfo())
						planList.add(null != mobileInfo.getPricePlanInfo().getPlanId()
								? mobileInfo.getPricePlanInfo().getPlanId()
								: ""); // add existing plan
					planList.add(""); // no plan change so this is empty
				} else {
					if (null != mobileInfo.getPricePlanInfo())
						planList.add(null != mobileInfo.getPricePlanInfo().getPlanId()
								? mobileInfo.getPricePlanInfo().getPlanId()
								: "");
					planList.add(checkPlanChangedLine.getPlan().getId());
				}
				planMap.put(mobileInfo.getMtn(), planList);
			}
		});
		// get plan details for new lines
		Line[] lines = addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getLines();
		Arrays.stream(lines).forEach(line -> {
			List<String> planList = new ArrayList<>();
			if (isNewLine(line.getMtn(), billAccount)) {
				planList.add(""); // No existing plan id for new line
				if (null != line.getPlan())
					planList.add(null != line.getPlan().getId() ? line.getPlan().getId() : ""); // New line has new plan
																								// id
				planMap.put(line.getMtn(), planList);
			}
		});
		return planMap;
	}

	/**
	 * Get plan changed line from account
	 * 
	 * @param mtn
	 * @param addPlanResponse
	 * @return Line object
	 */
	private Line getCPCLine(String mtn, AddPlanUIResponse addPlanResponse) {
		Line[] lines = addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getLines();
		return Arrays.stream(lines).filter(line -> mtn.equalsIgnoreCase(line.getMtn()) && line.getPlan() != null)
				.findFirst().orElse(null);
	}

	/**
	 * Check if this is a new line
	 * 
	 * @param mtn
	 * @param billAccount
	 * @return Boolean
	 */
	private boolean isNewLine(String mtn, BillAccount billAccount) {
		return billAccount != null && CollectionUtilities.isNotEmptyOrNull(billAccount.getMtns()) &&
						billAccount.getMtns().stream().noneMatch(mobileInfo -> mobileInfo != null && StringUtilities.isNotEmptyOrNull(mtn) && mtn.equalsIgnoreCase(mobileInfo.getMtn()));
	}

	/**
	 * Method to get reference data for list of feature ids
	 * 
	 * @param linePlansMap
	 * @param allPlanCatalogMap
	 * @return allPlanCatalogMap
	 */
	public Map<String, List<CatalogResponse>> getPlanReferenceDataMap(Map<String, List<String>> linePlansMap,
			Map<String, CatalogResponse> allPlanCatalogMap) {
		logger.debug("Inside CartServiceBpmHelper --> getPlanReferenceDataMap");
		Map<String, List<CatalogResponse>> refMap = new HashMap<>();
		for (Map.Entry<String, List<String>> entry : linePlansMap.entrySet()) {
			List<CatalogResponse> planData = new ArrayList<>();
			if (allPlanCatalogMap.containsKey(entry.getValue().get(0))) {
				planData.add(allPlanCatalogMap.get(entry.getValue().get(0)));
			} else {
				planData.add(null);
			}
			if (entry.getValue().size() > 1) {
				if (allPlanCatalogMap.containsKey(entry.getValue().get(1))) {
					planData.add(allPlanCatalogMap.get(entry.getValue().get(1)));
				} else {
					planData.add(null);
				}
			}
			refMap.put(entry.getKey(), planData);
		}
		return refMap;
	}

	/**
	 * Returns the plan catalog map
	 * 
	 * @param customerResponse - customer response
	 * @param addPlanResponse  - add plan response
	 * @return Map containing plan id and catalog response
	 */
	private Mono<Map<String, CatalogResponse>> getAllPlanCatalogMap(RetrieveCustomerCXPResponse customerResponse,
			AddPlanUIResponse addPlanResponse) {
		logger.debug("Inside CartServiceBpmHelper --> getAllPlanCatalogMap");

		List<String> selectedPlanIdList = Arrays
				.stream(addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getLines())
				.filter(line -> Objects.nonNull(line) && Objects.nonNull(line.getPlan())
						&& StringUtils.isNotEmpty(line.getPlan().getId()))
				.map(line -> line.getPlan().getId()).distinct().collect(Collectors.toList());

		List<String> existingPlanIdList = null;

		if (Objects.nonNull(customerResponse) && Objects.nonNull(customerResponse.getData())
				&& Objects.nonNull(customerResponse.getData().getCustomer())
				&& CollectionUtils.isNotEmpty(customerResponse.getData().getCustomer().getBillAccounts())) {

			existingPlanIdList = customerResponse.getData().getCustomer().getBillAccounts().stream()
					.filter(billAccount -> CollectionUtils.isNotEmpty(billAccount.getMtns()))
					.map(billAccount -> billAccount.getMtns()).flatMap(mobileInfos -> mobileInfos.stream())
					.filter(mobileInfo -> Objects.nonNull(mobileInfo) && Objects.nonNull(mobileInfo.getPricePlanInfo())
							&& StringUtils.isNotEmpty(mobileInfo.getPricePlanInfo().getPlanId()))
					.map(mobileInfo -> mobileInfo.getPricePlanInfo().getPlanId()).distinct()
					.collect(Collectors.toList());
		}

		if (CollectionUtils.isNotEmpty(selectedPlanIdList) && CollectionUtils.isNotEmpty(existingPlanIdList)) {
			List<String> planIds = Stream.concat(selectedPlanIdList.stream(), existingPlanIdList.stream())
					.collect(Collectors.toList());
			return catalogServiceHelper.getPlanSkuMap(planIds);
		} else if (CollectionUtils.isNotEmpty(selectedPlanIdList)) {
			return catalogServiceHelper.getPlanSkuMap(selectedPlanIdList);
		} else if (CollectionUtils.isNotEmpty(existingPlanIdList)) {
			return catalogServiceHelper.getPlanSkuMap(existingPlanIdList);
		}

		return Mono.just(new HashMap<>());
	}

	/**
	 * Sets the warning message if the disney+ is dropped.
	 * 
	 * @param addPlanResponse  - add plan response
	 * @param catalogResponses - catalog response list
	 */
	private void setDisneyLossWarningMessage(AddPlanUIResponse addPlanResponse,
			List<CatalogResponse> catalogResponses) {
		logger.debug("Inside CartServiceBpmHelper --> setDisneyLossWarningMessage");
		if (CollectionUtils.isNotEmpty(catalogResponses)) {
			if (catalogResponses.stream()
					.filter(catalogResponse -> Objects.nonNull(catalogResponse.getData())
							&& Objects.nonNull(catalogResponse.getData().getSpoSku())
							&& CollectionUtils
									.isNotEmpty(catalogResponse.getData().getSpoSku().getParentProductDetails()))
					.map(catalogResponse -> catalogResponse.getData().getSpoSku().getParentProductDetails())
					.filter(Objects::nonNull).flatMap(spoProducts -> spoProducts.stream().filter(Objects::nonNull))
					.anyMatch(spoProduct -> spoProduct != null && StringUtils.isNotEmpty(spoProduct.getSorId())
							&& spoProduct.getSorId().equalsIgnoreCase(CartConstants.VZ_VIDEO))) {
				logger.debug("Setting DISNEY_PLUS_DROPPED_KEY in addplan response");
				setPlanChangeWarningMessage(CartConstants.DISNEY_PLUS_DROPPED_KEY, addPlanResponse,"");
			}
		}
	}

	/**
	 * Checks if specific spo exist
	 * 
	 * @param spos            conflicted spos list
	 * @param spoId
	 * @param actionIndicator
	 * @return boolean
	 */
	private boolean isSpoExist(ConflictedSPO[] spos, String spoId, String actionIndicator) {
		logger.debug("Inside CartServiceBpmHelper --> isSpoExist");
		if (ArrayUtils.isNotEmpty(spos) && Arrays.stream(spos)
				.anyMatch(spo -> StringUtils.isNotEmpty(spo.getId()) && StringUtils.isNotEmpty(spo.getActionIndicator())
						&& spo.getId().equalsIgnoreCase(spoId)
						&& spo.getActionIndicator().equalsIgnoreCase(actionIndicator))) {
			return true;
		}
		return false;
	}

	public void getPlanDetailsFromCatalogResponse(AddPlanUIResponse addPlanUIResponse, Map<String, CatalogResponse> allPlanCatalogMap, AddPlanUIRequest request) {
		if (request != null && request.getCartInfo() != null && request.getCartInfo().isFlexV2() && request.getData() != null && Boolean.TRUE.equals(request.getData().getEnableAssistedTagging())) {
			Arrays.stream(addPlanUIResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getLines()).filter(line -> null != line && null != line.getPlan() && StringUtilities.isNotEmptyOrNull(line.getPlan().getId()) && CollectionUtilities.isNotEmptyOrNull(allPlanCatalogMap) && allPlanCatalogMap.containsKey(line.getPlan().getId())).forEach(line -> {
				CatalogResponse catalogResponse = allPlanCatalogMap.get(line.getPlan().getId());
				if (catalogResponse != null && null != catalogResponse.getData() && CollectionUtilities.isNotEmptyOrNull(catalogResponse.getData().getPlanCatalogItems())) {
					catalogResponse.getData().getPlanCatalogItems().stream().filter(planCatalog -> null != planCatalog && StringUtilities.isNotEmptyOrNull(planCatalog.getId()) && planCatalog.getId().equalsIgnoreCase(line.getPlan().getId())).forEach(planCatalogItems -> {
						line.getPlan().setName(StringUtilities.isNotEmptyOrNull(planCatalogItems.getDescription())?planCatalogItems.getDescription():"");
						line.getPlan().setProductId(StringUtilities.isNotEmptyOrNull(planCatalogItems.getProductId())?planCatalogItems.getProductId():"");
					});
				}
			});
		}
	}

}
