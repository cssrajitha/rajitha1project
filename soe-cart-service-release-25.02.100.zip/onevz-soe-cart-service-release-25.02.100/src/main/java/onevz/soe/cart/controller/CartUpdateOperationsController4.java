package onevz.soe.cart.controller;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

import onevz.cxp.feature.ConfigurationProfile;
import onevz.soe.cart.controller.CartUpdateOperationsController.*;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper4;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.exceptions.JsonValidator;
import onevz.cxp.feature.ConfigurationProfile;
import onevz.cxp.feature.Flag;
import reactor.util.function.Tuple2;
import onevz.soe.cart.helper.*;
import onevz.soe.cart.model.addDevice.AddDeviceContext;
import onevz.soe.cart.model.addDevice.AddDeviceServiceBody;
import onevz.soe.cart.model.addDevice.AddDeviceServiceResponse;
import onevz.soe.cart.model.calculateTaxData.LineTaxDetail;
import onevz.soe.cart.model.calculateTaxData.TaxLinesResponses;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.common.Line;
import onevz.soe.cart.model.common.TaxPerItem;
import onevz.soe.cart.model.fipscode.RetrieveFipsCode;
import onevz.soe.cart.model.fipscode.RetrieveFipsCodeByZipCode;
import onevz.soe.cart.model.fipscode.RetrieveFipsCodeData;
import onevz.soe.cart.model.fipscode.RetrieveFipsResponse;
import onevz.soe.cart.model.mylink.MylinkError;
import onevz.soe.cart.model.mylink.MylinkReferralInfoResponse;
import onevz.soe.cart.model.mylink.MylinkReferralInfoUIRequest;
import onevz.soe.cart.model.removeLines.RemoveLinesContext;
import onevz.soe.cart.model.removeLines.RemoveLinesServiceBody;
import onevz.soe.cart.model.removeLines.RemoveLinesServiceResponse;
import onevz.soe.cart.model.retrieveCart.CXPCartVO;
import onevz.soe.cart.model.taxengine.request.NGDCalculateTaxDetailsRequest;
import onevz.soe.cart.model.taxengine.request.NGDTaxEngineRequest;
import onevz.soe.cart.model.taxengine.request.NGDTaxLinesRequest;
import onevz.soe.cart.model.taxengine.response.NGDTaxEngineBaseResponse;
import onevz.soe.cart.model.taxengine.response.NGDTaxEngineResponseData;
import onevz.soe.cart.model.validateCart.CXPValidateCartDataVO;
import onevz.soe.cart.requests.UpdateAccountOwnerPEGAResponse;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.AddDeviceUIResponse;
import onevz.soe.cart.ui.responses.RemoveLinesUIResponse;
import onevz.soe.cart.ui.responses.TaxDetailsForConfiguratorUIResponse;
import onevz.soe.cart.ui.responses.ValidateCartUIResponse;
import onevz.soe.cart.util.CartPegaRequestErrorsUtil;
import onevz.soe.cart.util.CartPegaResponseErrorsUtil;
import onevz.soe.cart.util.CartUtil;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import jakarta.validation.Valid;

import static onevz.soe.cart.constants.CartConstants.EXISTING_CART_COUNT;

@RestController
@RequestMapping(value = "cart")
public class CartUpdateOperationsController4 {

    private static final Logger logger = LoggerFactory.getLogger(CartUpdateOperationsController4.class);
    @Autowired
    CartServiceBpmHelper4 cartServiceBpmHelper4;

    @Autowired
    UpdateCartHelper updateCartHelper4;

    @Autowired
    JsonValidator validator;

    @Autowired
    RedisHelper3 redisHelper3;

    @Autowired
    private CartAddDeviceHelper1 deviceHelper;

    @Autowired
    private RedisHelper redisHelper;
    @Autowired
    private CartServiceCXPServices cxpService;

    @Autowired
    private FeatureFlagHelper featureFlagHelper;

    @InitBinder("*")
    public void initBinderByName(WebDataBinder binder) {
        binder.setDisallowedFields(new String[] { "genericHeader" });
    }

    @PostMapping({"/addZipcodeThroughPega", "/nse/addZipcodeThroughPega"})
    public Mono<ResponseEntity<GenericResponse>> addZipcodeThroughPega(ServerHttpRequest httpHeader,
                                                                       ServerHttpResponse httpResponse, @Valid @RequestBody AddZipCodeUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, httpHeader.getPath().value());
        logger.debug("addZipcodeThroughPega Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);
        String sessionId = "";
        HttpCookie cookieDigitIgSession = httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION);
        if (CartConstants.CHANNEL_ID_BBP.equalsIgnoreCase(CartUtil.getChannelType(channelId)) || CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId)))
            sessionId = null != cookieDigitIgSession
                    ? cookieDigitIgSession.getValue()
                    : "";

        request.getCartInfo().setSessionId(sessionId);
        String digitalIgSession="";
        if ((CartConstants.CHANNEL_ID_BBP.equalsIgnoreCase(CartUtil.getChannelType(channelId)) || CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId)))
                && CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
            digitalIgSession = httpHeader.getHeaders().getFirst(CartConstants.DIGITAL_IG_SESSION);
            logger.info("##sessionId## BBP: {}", digitalIgSession);
            request.getCartInfo().setCartCreator(digitalIgSession);
            request.getCartInfo().setGlobalId(digitalIgSession);
        }
        return cartServiceBpmHelper4.addZipcodeThroughPEGA(request).flatMap(pegaResponse -> {
                    ErrorResponse errors2 = null;
                    if (pegaResponse.getErrors() != null && !httpResponse.getStatusCode().is2xxSuccessful()) {
                        errors2 = CartPegaResponseErrorsUtil.handleAddZipcodeResponseErrors(pegaResponse);
                        return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(errors2));
                    }
            return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(pegaResponse));

        });
        }

        @PostMapping({"/myLink/validateMyLinkReferralInfo", "/nse/myLink/validateMyLinkReferralInfo"})
        public Mono<MylinkReferralInfoResponse> validateMyLinkReferralInfo(ServerHttpRequest httpHeader,
                                                                           ServerHttpResponse httpResponse, @RequestBody MylinkReferralInfoUIRequest request) {
            System.setProperty(CartConstants.ENDPOINT, httpHeader.getPath().value());
            String flowPath = String.valueOf(httpHeader.getPath());
            String hashKey = request.getData() != null ? request.getData().getHashKey() : "";
            if (StringUtils.isEmpty(hashKey)) {
                logger.info("Hashkey is empty. Unable to proceed further");
                MylinkReferralInfoResponse errResponse = new MylinkReferralInfoResponse();
                List<MylinkError> errors = new ArrayList<>();
                MylinkError error = new MylinkError();
                error.setMessage("Hashkey is empty. Unable to proceed further");
                errors.add(error);
                errResponse.setErrors(errors);
                return Mono.just(errResponse);
            }
            HttpCookie cookieDigitIgSession = httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION);
            String salesFlowSessionId = null != cookieDigitIgSession ? cookieDigitIgSession.getValue() : "";
            return updateCartHelper4.validateMyLinkReferralInfo(hashKey, salesFlowSessionId).flatMap(response -> {
                if(StringUtilities.isNotEmptyOrNull(flowPath) && flowPath.contains("nse")
                        && Objects.nonNull(response.getData()) && "SUCCESS".equalsIgnoreCase(response.getData().getStatus())) {
                    httpResponse.addCookie(
                            ResponseCookie.from(CartConstants.MYLINK_HASH_KEY, hashKey)
                                    .maxAge(Duration.ofDays(7))
                                    .path("/").httpOnly(false)
                                    .build());
                }
                return Mono.just(response);
            });
        }
    @PostMapping({"/updateConflictStatus"})
    public Mono<ResponseEntity<GenericResponse>> updateConflictStatus(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse,
                                                                        @RequestBody UpdateConflictStatusRequest request) {

        return redisHelper3.updateConflictStatusToRedis(request).flatMap(resp -> Mono.just(ResponseEntity.status(HttpStatus.OK).body(resp)));
    }

    @PostMapping({"/addPlanAndPerksToSession"})
    public Mono<ResponseEntity<GenericResponse>> addPlanAndPerksToRedis(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse,
                                                                        @RequestBody AddPlanUIRequest request) {

        ErrorResponse errorResponse = CartPegaRequestErrorsUtil.handleAddPlanRequestErrors(request,httpHeader);
        if (CollectionUtilities.isNotEmptyOrNull(errorResponse.getErrors())) {
            ErrorResponse errors = validator.convertObjectToString(errorResponse);
            if (null != errors) {
                return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
            }
        }
        return redisHelper3.addPlanAndPerksToRedis(request).flatMap(resp -> Mono.just(ResponseEntity.status(HttpStatus.OK).body(resp)));
    }

    @PostMapping({"/addUpgradeDetails"})
    public Mono<ResponseEntity<GenericResponse>> addUpgradeDetails(ServerHttpRequest httpHeader,
                                                                   ServerHttpResponse httpResponse, @Valid @RequestBody AddDeviceUIRequest request) {
        ErrorResponse errors = settingErrorResponse(httpHeader, request, "addUpgradeDetails");
        if (null != errors){
            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
        }
        String sessionId = "";
        String channelType = CartUtil.getChannelType(request.getChannelId());
        HttpCookie cookieDigitIgSession = httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION);

        if (CartConstants.DIGITAL.equalsIgnoreCase(channelType)) {
            sessionId = null != cookieDigitIgSession ? cookieDigitIgSession.getValue() : "";
        }
        getCookieValues(httpHeader, null, request);

        request.getCartInfo().setSessionId(sessionId);
        request.setHttpRequest(httpHeader);
        request.setHttpResponse(httpResponse);

        return deviceHelper.addUpgradeDetails(request,httpResponse).flatMap(pegaResponse -> {
            ErrorResponse errors2 = null;
            if (pegaResponse.getErrors() != null && !httpResponse.getStatusCode().is2xxSuccessful()) {
                errors2 = CartPegaResponseErrorsUtil.handleAddDeviceResponseErrors(pegaResponse);
                return Mono.just(ResponseEntity.status(processHttpStatusForPega((HttpStatus) httpResponse.getStatusCode())).body(errors2));
            } else {
                CartRedisData rr = new CartRedisData();
                if(CartConstants.ACCOUNT_GROWTH.equalsIgnoreCase(request.getCartInfo().getIntendType())){
                    request.getCartInfo().setIntendType(CartConstants.EUP);
                }
                List<Lines> cartLines= request.getData().getLines();
                if (cartLines != null) {
                    for (Lines cartLine : cartLines) {
                        if(CartConstants.ACCOUNT_GROWTH.equalsIgnoreCase(cartLine.getPurchasePath())){
                            cartLine.setPurchasePath(CartConstants.EUP);
                        }
                    }
                }
                if (request.getCartInfo().getIntendType() != null)
                    rr.setIntendType(request.getCartInfo().getIntendType());

                if (request.getData().getLines().get(0).getDevice() != null && StringUtilities.isNotEmptyOrNull(request.getData().getLines().get(0).getDevice().getId())) {
                    rr.setDeviceSorIdForRecommendations(request.getData().getLines().get(0).getDevice().getId());
                }

                if (pegaResponse.getServiceBody() != null) {
                    if (!CartConstants.ASSISTED.equalsIgnoreCase(channelType)
                            && pegaResponse.getServiceBody().getServiceResponse().getContext() != null) {
                        rr.setCaseId(pegaResponse.getServiceBody().getServiceResponse().getContext().getCaseId());
                        if (!CartConstants.ASSISTED.equalsIgnoreCase(channelType) && pegaResponse.getServiceBody()
                                .getServiceResponse().getContext().getCartInfo() != null) {
                            rr.setCartId(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()
                                    .getCartId());
                            if(StringUtilities.isNotEmptyOrNull(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()
                                    .getEcpdProfileId())) {
                                rr.setEcpdId(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()
                                        .getEcpdProfileId());
                            }
                            if (pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()
                                    .getLines() != null) {
                                Line[] lines = pegaResponse.getServiceBody().getServiceResponse().getContext()
                                        .getCartInfo().getLines();

                                if (null != lines && lines.length > 0
                                        && StringUtilities.isNotEmptyOrNull(lines[0].getMtn())) {
                                    rr.setProcessingMTN(lines[0].getMtn());
                                }

                                if (null != lines && lines.length > 0 && lines[0].getDevice() != null
                                        && StringUtilities.isNotEmptyOrNull(lines[0].getDevice().getId())) {
                                    rr.setDeviceSorIdForRecommendations(lines[0].getDevice().getId());
                                }
                            }
                        }
                        if (pegaResponse.getServiceBody().getServiceResponse().getContext()
                                .getShowAALPromoIntercept() != null)
                            rr.setShowAALPromoIntercept(pegaResponse.getServiceBody().getServiceResponse().getContext()
                                    .getShowAALPromoIntercept());
                        if (null != pegaResponse.getServiceBody().getServiceResponse().getContext().getContextInfo()) {
                            rr.setProcessStep(pegaResponse.getServiceBody().getServiceResponse().getContext()
                                    .getContextInfo().getProcessStep());
                            rr.setCradleFlowJourney(pegaResponse.getServiceBody().getServiceResponse().getContext().getContextInfo().getCradleFlowJourney());

                        }

                        if(null!= pegaResponse.getServiceBody().getServiceResponse().getContext().getContextInfo() &&
                                null != pegaResponse.getServiceBody().getServiceResponse().getContext().getCustomerInfo()) {
                            if(StringUtilities.isNotEmptyOrNull(pegaResponse.getServiceBody().getServiceResponse().getContext().getCustomerInfo().getExistingCase())){
                                rr.setExistingCase(pegaResponse.getServiceBody().getServiceResponse().getContext().getCustomerInfo().getExistingCase());
                            }else {
                                rr.setExistingCase(CartConstants.FALSE);
                            }
                        }
                    }
                }
                rr.setLines(request.getData().getLines());
                rr.setDeviceCartInfo(request.getCartInfo());
                rr.setSpokeJourney(CartConstants.FALSE);
                if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessingMTN()))
                    rr.setProcessingMTN(request.getCartInfo().getProcessingMTN());

                rr.setIconicTestIntent(request.getCartInfo().getIconicTestIntent());
                if (pegaResponse != null && pegaResponse.getServiceBody() != null
                        && pegaResponse.getServiceBody().getServiceResponse() != null
                        && pegaResponse.getServiceBody().getServiceResponse().getContext() != null
                        && pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo() != null) {
                    rr.setDeviceCount(String.valueOf(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartItemCount()));
                }
                addCartCountCookie(pegaResponse,httpResponse,EXISTING_CART_COUNT);

                if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId())))
                    return redisHelper.updateDataIntoRedisAsString(rr, CartConstants.DEVICE).flatMap(redisData ->
                            deviceHelper.updateSubFlowForOneClickExpressUpgrade(request).flatMap(subflow -> {
                                if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))
                                        && httpResponse.getStatusCode().equals(HttpStatus.PARTIAL_CONTENT)) {
                                    for (CartError errorResp : pegaResponse.getErrors()) {
                                        if ("3226".equals(errorResp.getId())) {
                                            httpResponse.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR);
                                        }
                                    }
                                }
                                /* NSADT-72401 : F&S - NSA NC - Sensitive Info Disclosure - Case id, ClientID and Client */
                                removeSensitiveInfo(request, pegaResponse);
                                return mergeFeatureFlagWithResponse(Mono.zip(Mono.just(pegaResponse),featureFlagHelper.fetchDigitalUpgradeCfgProfile()));
                            }));
                return mergeFeatureFlagWithResponse(Mono.zip(Mono.just(pegaResponse),featureFlagHelper.fetchDigitalUpgradeCfgProfile()));
            }
        });
    }

    private Mono<ResponseEntity<GenericResponse>> mergeFeatureFlagWithResponse(Mono<Tuple2< AddDeviceUIResponse , ConfigurationProfile>> zip) {
        return zip.flatMap(tuples -> {
            var addDeviceUIResponse = tuples.getT1();
            Optional.ofNullable(tuples.getT2())
                    .map(ConfigurationProfile::getFlags)
                    .ifPresent(listOfFeatureFlags -> {
                        var mapOfFeatureFlags = listOfFeatureFlags
                                .stream()
                                .collect(Collectors.toMap(Flag::getName, flag -> featureFlagHelper.mapValueToFlagDetails().apply(flag), (oldEntry, newEntry) -> newEntry));
                        addDeviceUIResponse.setFeatureConfigurationProfileData(mapOfFeatureFlags);
                    });
            return Mono.just(ResponseEntity.ok(addDeviceUIResponse));
        });
    }

    public void addCartCountCookie(AddDeviceUIResponse pegaResponse,ServerHttpResponse httpResponse, String name ){
        Optional.ofNullable(pegaResponse.getServiceBody())
                .map(AddDeviceServiceBody::getServiceResponse)
                .map(AddDeviceServiceResponse::getContext)
                .map(AddDeviceContext::getCartInfo)
                .ifPresent(cartInfo -> httpResponse.addCookie(createCartCountCookie(name, String.valueOf(cartInfo.getCartItemCount()))));
    }
    private ResponseCookie createCartCountCookie(String name, String value) {
        return ResponseCookie.from(name, value)
                .path("/")
                .httpOnly(false)
                .build();
    }

    private void removeSensitiveInfo(AddDeviceUIRequest request, AddDeviceUIResponse pegaResponse) {
        if (pegaResponse != null && pegaResponse.getServiceBody() != null
                && CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))
                && pegaResponse.getServiceBody().getServiceResponse() != null
                && pegaResponse.getServiceBody().getServiceResponse().getContext() != null) {

            pegaResponse.getServiceBody().getServiceResponse().getContext().setCaseId(null);
            Optional.of(pegaResponse.getServiceBody().getServiceResponse().getContext()).map(AddDeviceContext::getCustomerInfo).ifPresent(customerInfo -> customerInfo.setAccountNumber(null));
            Optional<CXPCartVO> cxpCartVOOptional = Optional.of(pegaResponse).map(AddDeviceUIResponse::getValidateCartResponse).map(ValidateCartUIResponse::getData).map(CXPValidateCartDataVO::getValidateCartAndUpdate);
            cxpCartVOOptional.map(CXPCartVO::getCartHeader).ifPresent(cartHeader -> {
                cartHeader.setCartId(null);
                cartHeader.setFullAccountNumber(null);
            });
            if (pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo() != null)
                pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setCartId(null);
            if (pegaResponse.getServiceHeader() != null)
                pegaResponse.getServiceHeader().setClientId(null);
        }
    }

    private ErrorResponse settingErrorResponse(ServerHttpRequest httpHeader, AddDeviceUIRequest request, String methodName) {
        System.setProperty(CartConstants.ENDPOINT, methodName);
        logger.debug(methodName+" Request: {}", request);
        formatHttpHeader(httpHeader, request);
        ErrorResponse errorResponse = CartPegaRequestErrorsUtil.handleAddUpgradeDetailsRequestErrors(request);
        if (CollectionUtilities.isNotEmptyOrNull(errorResponse.getErrors())) {
            ErrorResponse errors = validator.convertObjectToString(errorResponse);
            if (null != errors) {
                return errors;
            }
        }
        return null;
    }

    private void formatHttpHeader(ServerHttpRequest httpHeader, AddDeviceUIRequest request) {
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);
        String path = String.valueOf(httpHeader.getPath());
        if(StringUtilities.isNotEmptyOrNull(path)) {
            logger.info("Path is: {}",path);
            request.setPath(path);
        }
    }

    public void getCookieValues(ServerHttpRequest httpHeader, CreateLineUIRequest createLineRequest,
                                AddDeviceUIRequest addDeviceRequest) {
        HttpCookie cookieCpdToken = httpHeader.getCookies().getFirst(CartConstants.COOKIE_ECPD_TOKEN);
        String ecpdToken = null != httpHeader.getCookies()
                && null != cookieCpdToken
                ? cookieCpdToken.getValue()
                : "";
        String ecpdProfileId =null;
        HttpCookie cookieCpdDomain = httpHeader.getCookies().getFirst(CartConstants.COOKIE_ECPD_DOMAIN);
        String ecpdDomainCookie = null != httpHeader.getCookies()
                && null != cookieCpdDomain
                ? cookieCpdDomain.getValue()
                : "";
        HttpCookie salesRepIdCookie = httpHeader.getCookies().getFirst(CartConstants.COOKIE_SALESREPID);
        String salesRepId = null != httpHeader.getCookies()
                && null != salesRepIdCookie
                ? salesRepIdCookie.getValue()
                : "";
        HttpCookie referralVendorIdCookie = httpHeader.getCookies().getFirst(CartConstants.COOKIE_REFERRAL_VENDOR);
        String referralVendorId = null != httpHeader.getCookies()
                && null != referralVendorIdCookie
                ? referralVendorIdCookie.getValue()
                : "";
        HttpCookie targetPricingOfferCookie = httpHeader.getCookies().getFirst(CartConstants.COOKIE_TARGET_PRICING_OFFER);
        Boolean targetPricingOffer = null != targetPricingOfferCookie
                && Boolean.parseBoolean(targetPricingOfferCookie.getValue());
        if (!StringUtils.isEmpty(ecpdToken)) {
            String[] values = ecpdToken.split(":");
            if (null != values
                    && values.length >= 4) {
                ecpdToken =values[3];
                if (StringUtils.isEmpty(ecpdToken)
                        || (!StringUtils.isEmpty(ecpdToken)
                        && "NULL".equalsIgnoreCase(ecpdToken)) ) {
                    ecpdProfileId = values[0];
                    ecpdToken = null;
                }
            }
        }

        addDeviceRequest.getCartInfo().setReferralSaleRepId(salesRepId);
        addDeviceRequest.getCartInfo().setCartCreatorSalesRepId(salesRepId);
        if(!StringUtils.isEmpty(ecpdToken))	{
            addDeviceRequest.getCartInfo().setEcpdToken(ecpdToken);
        }
        if(!StringUtils.isEmpty(ecpdProfileId)) {
            addDeviceRequest.getCartInfo().setEcpdProfileId(ecpdProfileId);
        }
        addDeviceRequest.getCartInfo().setRylEcpdUrl(ecpdDomainCookie);
        addDeviceRequest.getCartInfo().setReferralVendorId(referralVendorId);
    }

    public HttpStatus processHttpStatusForPega(HttpStatus statusCode)
    {
        if(statusCode!=null && statusCode.equals(HttpStatus.NOT_FOUND))
        {
            statusCode = HttpStatus.OK;
        }
        return statusCode;
    }

    @PostMapping({"/update-account-owner"})
    public Mono<UpdateAccountOwnerPEGAResponse> updateAccountOwner(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse,
                                                                   @RequestBody UpdateAccountOwnerUIRequest request) {

        String channelId = httpHeader != null && httpHeader.getHeaders() != null
                && httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        return cartServiceBpmHelper4.updateAccountOwner(request,channelId);
    }
    @PostMapping({"/nse/getTaxDetailsForConfigurator"})
    public Mono<NGDTaxEngineResponseData> getTaxDetailsForConfigurator(@Valid @RequestBody NGDTaxEngineRequest request){
        final String zipcode = Optional.ofNullable(request).map(NGDTaxEngineRequest::getCalculateTaxDetailsRequest).map(NGDCalculateTaxDetailsRequest::getTaxLines)
                .filter(CollectionUtilities::isNotEmptyOrNull).map(taxLines -> taxLines.get(0)).map(NGDTaxLinesRequest::getZipcode).filter(StringUtils::isNumeric).orElse("");
        if(StringUtilities.isNotEmptyOrNull(zipcode)){
            Map<String,String> reqMap = new HashMap<>();
            reqMap.put("zipcode",zipcode);
            reqMap.put("traffic","LIVE");
            return cxpService.retrieveFipsCode(reqMap).flatMap(resp -> deviceHelper.callTaxEngine(Optional.of(resp).map(RetrieveFipsCode::getData).map(RetrieveFipsCodeData::getRetrieveFipsCodeByZipCode).map(RetrieveFipsCodeByZipCode::getResponse)
                    .map(RetrieveFipsResponse::getFipsCode).filter(StringUtilities::isNotEmptyOrNull).orElse(""),request));
        }
        NGDTaxEngineResponseData errorResp = new NGDTaxEngineResponseData();
        errorResp.setStatus(Map.of("error","Zipcode is invalid"));
        return Mono.just(errorResp);
    }


}

