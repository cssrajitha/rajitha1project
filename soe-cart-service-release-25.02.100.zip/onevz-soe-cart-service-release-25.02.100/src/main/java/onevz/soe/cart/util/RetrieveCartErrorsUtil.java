package onevz.soe.cart.util;

import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.exception.SOEError;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class RetrieveCartErrorsUtil {
    public static ErrorResponse handleRetrieveCartRequestErrors(ErrorResponse validationResponse) {
        ErrorResponse errors = null;
        List<CartError> errorList = new ArrayList<>();
        if (validationResponse.getErrors() != null) {
            errors = new ErrorResponse();
            for (CartError cxpError : validationResponse.getErrors()) {
                CartError error = cxpError;
                errorList.add(error);
            }
            errors.setErrors(errorList);
        }
        return errors == null ? new ErrorResponse() : errors;
    }

    public static List<SOEError> getDefaultErrorsList(String errorMessage, String errorName){
        SOEError soeError = new SOEError();
        soeError.setMessage(errorMessage);
        soeError.setName(errorName);
        return Arrays.asList(soeError);
    }
}