package onevz.soe.cart.helper;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jakarta.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import onevz.soe.cart.bpm.helper.CartServiceBpmHelper;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper3;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper2;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.requests.DeviceSimValidationCXPRequest;
import onevz.soe.cart.responses.DeviceSimValidationCXPResponse;
import onevz.soe.cart.responses.InitiateAddressChangePEGAResponse;
import onevz.soe.cart.responses.RPSRedisData;
import onevz.soe.cart.ui.common.CarrierPostData;
import onevz.soe.cart.ui.common.CompanionDevice;
import onevz.soe.cart.ui.requests.DeviceSimValidationUIRequest;
import onevz.soe.cart.ui.requests.RPSApplePayloadUIRequest;
import onevz.soe.cart.ui.requests.RPSE911AddressRetrieveUIRequest;
import onevz.soe.cart.ui.requests.RPSE911AddressUpdateUIRequest;
import onevz.soe.cart.ui.requests.RPSReleasePendingOrderUIRequest;
import onevz.soe.cart.ui.requests.SecondaryDeviceActive;
import onevz.soe.cart.ui.responses.DeviceIdValidationUIResponse;
import onevz.soe.cart.ui.responses.RPSE911AddressRetrieveUIResponse;
import onevz.soe.cart.ui.responses.RPSE911AddressUpdateUIResponse;
import onevz.soe.cart.ui.responses.RPSReleasePendingOrderResponse;
import onevz.soe.cart.ui.responses.ValidateE911AddressUIResponse;
import onevz.soe.cart.util.CartCxpRequestUtil;
import onevz.soe.cradle.CradleAllocator;
import onevz.soe.omnidl.service.OmniDLService;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.spring.web.RequestDataBuilder;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.bpm.model.response.Error;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import reactor.core.publisher.Mono;

@Service
public class CartRpsHelper {

	@Autowired
	private CartServiceCxpHelper2 cxpHelper;

	@Autowired
	private CartServiceBpmHelper bpmHelper;
	
	@Autowired
	private CartServiceBpmHelper3 bpmHelper3;

	@Autowired
	private RedisHelper redisHelper;

	@Autowired
	SOELoginSessionBean sessionBean;

	@Autowired
	CradleAllocator cradleAllocator;

    @Autowired
    OmniDLService dlService;

	@Autowired
	private CartServiceCXPServices cxpService;

	private static final Logger logger = LoggerFactory.getLogger(CartRpsHelper.class);
	
	/**
	 * @param request
	 * @return UpdateUserInfoUIResponse
	 */
	public Mono<RPSE911AddressUpdateUIResponse> updateRPSE911Address(RPSE911AddressUpdateUIRequest request) {

		return redisHelper.getDataFromRedis().flatMap(data -> {
			logger.debug("Calling cxp helper with redis account number {}", data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getMtn()) && null==request.getMtn())
				request.setMtn(Arrays.asList(data.getMtn()));
			if(request.getChannelId().equalsIgnoreCase(CartConstants.CHANNEL_ID_NUMBERLINK) && StringUtilities.isNotEmptyOrNull(data.getDeviceId())) {
				request.setDeviceId(data.getDeviceId());
			}
			return cxpHelper.updateRPSE911Address(request);
		});
	}

	/**
	 * @param request
	 * @return UpdateUserInfoUIResponse
	 */
	public Mono<RPSReleasePendingOrderResponse> releaseRPSPendingOrder(RPSReleasePendingOrderUIRequest request) {

		return cxpHelper.releaseRPSPendingOrder(request);
	}

	/**
	 * @param request
	 * @return RPSE911AddressRetrieveUIResponse
	 */
	public Mono<RPSE911AddressRetrieveUIResponse> retrieveRPSE911Address(RPSE911AddressRetrieveUIRequest request) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			logger.debug("Calling cxp helper with redis account number {}", data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getMtn()))
				request.setMtn(Arrays.asList(data.getMtn()));
			if(request.getChannelID().equalsIgnoreCase(CartConstants.CHANNEL_ID_NUMBERLINK) && StringUtilities.isNotEmptyOrNull(data.getDeviceId())) {
				request.setDeviceId(data.getDeviceId());
			}
			return cxpHelper.retrieveRPSE911Address(request);
		});

	}
	
	/**
	 *
	 * @param standalone
	 * @param deviceImei
	 * @return
	 */
	public Mono<DeviceIdValidationUIResponse> initiateRPSFlow(boolean standalone, String deviceImei) {
		return redisHelper.getDataFromRedis().flatMap(data -> {

			String accNumber = "";
			if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber())) {
				accNumber = data.getAccountNumber();
			}
			String cartCreator = "";
			if (StringUtilities.isNotEmptyOrNull(data.getCartCreator())) {
				cartCreator = data.getCartCreator();
			}

			return bpmHelper3.initiateRPSFlow(standalone, deviceImei, accNumber, cartCreator);
		});

	}
	/**
	 * @param request
	 * @return ValidateE911AddressUIResponse
	 */
	public Mono<ValidateE911AddressUIResponse> validateE911Address(RPSE911AddressUpdateUIRequest request) { // 2155.1
		return cxpHelper.validateE911Address(request);
	}

	public Mono<DeviceSimValidationCXPResponse> deviceSimValidationWithEid(DeviceIdValidationUIResponse deviceIdValidationUIResponse, DeviceSimValidationUIRequest uiRequest) {
		DeviceSimValidationCXPRequest cxpRequest = new DeviceSimValidationCXPRequest();
		Mono<DeviceSimValidationCXPResponse> deviceSimValidationCXPResponseMono = null;
		boolean eidFlag = false;
		if (null != deviceIdValidationUIResponse.getServiceBody() && null != deviceIdValidationUIResponse.getServiceBody().getServiceResponse()
				&& null != deviceIdValidationUIResponse.getServiceBody().getServiceResponse().getContext()
				&& null != deviceIdValidationUIResponse.getServiceBody().getServiceResponse().getContext().getDeviceInfo()) {
			if (null == deviceIdValidationUIResponse.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getSimInfo()
					|| StringUtilities.isEmptyOrNull(deviceIdValidationUIResponse.getServiceBody().getServiceResponse().getContext()
					.getDeviceInfo().getSimInfo().getEID())) {

				logger.info("EID or SIMInfo Missing ");
				// convert uiRequest to cxpRequest
				cxpRequest = CartCxpRequestUtil.formatDeviceSimValidationWIthEidRequest(uiRequest, cxpRequest);
				String flowType = cxpRequest.getData().getFlowType();
				logger.info("flowType: {}", flowType);
				logger.info("DeviceSimValidationWithEidUIRequest request: {}", cxpRequest);
				// call to cxp service
				deviceSimValidationCXPResponseMono =  cxpService.deviceSimValidation(cxpRequest);
				eidFlag = true;
			}
		}
		if(eidFlag) {
			return deviceSimValidationCXPResponseMono;
		}
		else{
			logger.info("EID Exisits in SimInfo");
			return Mono.just(new DeviceSimValidationCXPResponse());
		}
	}

	public CarrierPostData getCarrierPostData(RPSApplePayloadUIRequest rpsApplePayloadUIRequest) {
		CarrierPostData carrierPostData = new CarrierPostData();
		if (rpsApplePayloadUIRequest != null
				&& StringUtilities.isNotEmptyOrNull(rpsApplePayloadUIRequest.getCarrierPostData())) {
			String[] carrierPostDatas = rpsApplePayloadUIRequest.getCarrierPostData().split("&");
			Map<String, String> carriedPostDataMap = new HashMap<>();
			if (carrierPostDatas != null && carrierPostDatas.length > 0) {
				for (String carrierData : carrierPostDatas) {
					carriedPostDataMap.put(carrierData.split("=")[0], carrierData.split("=")[1]);
				}
				carrierPostData.setAssociatedSubscriprion(StringUtilities
						.isNotEmptyOrNull(carriedPostDataMap.get(CartConstants.RPS_FLOW_ASSOCIATED_SUBSCRIPTION))
						? carriedPostDataMap.get(CartConstants.RPS_FLOW_ASSOCIATED_SUBSCRIPTION)
						: "");
				carrierPostData.setEsimDownloadDelay(StringUtilities
						.isNotEmptyOrNull(carriedPostDataMap.get(CartConstants.RPS_FLOW_ESIM_DOWNLOAD_DELAY))
						? carriedPostDataMap.get(CartConstants.RPS_FLOW_ESIM_DOWNLOAD_DELAY)
						: "");
				carrierPostData.setPrimaryDeviceMTN(StringUtilities
						.isNotEmptyOrNull(carriedPostDataMap.get(CartConstants.RPS_FLOW_PRIMARY_DEVICE_MDN))
						? carriedPostDataMap.get(CartConstants.RPS_FLOW_PRIMARY_DEVICE_MDN)
						: "");
				carrierPostData.setServiceCode(
						StringUtilities.isNotEmptyOrNull(carriedPostDataMap.get(CartConstants.RPS_FLOW_SERVICE_CODE))
								? carriedPostDataMap.get(CartConstants.RPS_FLOW_SERVICE_CODE)
								: "");
				carrierPostData.setDeviceUserAgent(StringUtilities
						.isNotEmptyOrNull(carriedPostDataMap.get(CartConstants.RPS_FLOW_DEVICE_USER_AGENT))
						? carriedPostDataMap.get(CartConstants.RPS_FLOW_DEVICE_USER_AGENT)
						: "");
				carrierPostData
						.setToken(StringUtilities.isNotEmptyOrNull(carriedPostDataMap.get(CartConstants.RPS_FLOW_TOKEN))
								? carriedPostDataMap.get(CartConstants.RPS_FLOW_TOKEN)
								: "");
				carrierPostData.setTransactionId(
						StringUtilities.isNotEmptyOrNull(carriedPostDataMap.get(CartConstants.RPS_FLOW_TRANSACTION_ID))
								? carriedPostDataMap.get(CartConstants.RPS_FLOW_TRANSACTION_ID)
								: "");
			}
		}
		return carrierPostData;
	}

	public RPSRedisData formatRPSRedisData(RPSApplePayloadUIRequest request, String encryptedPayloadReq){
		RPSRedisData rpsRedisData = new RPSRedisData();
		if(StringUtilities.isNotEmptyOrNull(encryptedPayloadReq)){
			rpsRedisData.setEncryptedPayload(encryptedPayloadReq);
		}
		if(null!=request) {
			SecondaryDeviceActive secondaryDeviceActive = new SecondaryDeviceActive();
			rpsRedisData.setCarrierPostData(getCarrierPostData(request));
			if(request.getSecondaryDeviceActive()!=null) {
				if (StringUtilities.isNotEmptyOrNull(request.getSecondaryDeviceActive().getDeviceImei()))
					secondaryDeviceActive.setDeviceImei(request.getSecondaryDeviceActive().getDeviceImei());
				if (StringUtilities.isNotEmptyOrNull(request.getSecondaryDeviceActive().getDisplayName()))
					secondaryDeviceActive.setDisplayName(request.getSecondaryDeviceActive().getDisplayName());
				if (StringUtilities.isNotEmptyOrNull(request.getSecondaryDeviceActive().getEid()))
					secondaryDeviceActive.setEid(request.getSecondaryDeviceActive().getEid());
				if (StringUtilities.isNotEmptyOrNull(request.getSecondaryDeviceActive().getIccids()))
					secondaryDeviceActive.setIccids(request.getSecondaryDeviceActive().getIccids());
				rpsRedisData.setSecondaryDeviceActive(secondaryDeviceActive);
			}
			CompanionDevice companionDevice = new CompanionDevice();
			if (request.getCompanionDevice() != null) {
				if (StringUtilities.isNotEmptyOrNull(request.getCompanionDevice().getImei()))
					companionDevice.setImei(request.getCompanionDevice().getImei());
				if (StringUtilities.isNotEmptyOrNull(request.getCompanionDevice().getEid()))
					companionDevice.setEid(request.getCompanionDevice().getEid());
				if (StringUtilities.isNotEmptyOrNull(request.getCompanionDevice().getDeviceModel()))
					companionDevice.setDeviceModel(request.getCompanionDevice().getDeviceModel());
				if (StringUtilities.isNotEmptyOrNull(request.getCompanionDevice().getDeviceOEM()))
					companionDevice.setDeviceOEM(request.getCompanionDevice().getDeviceOEM());
				rpsRedisData.setCompanionDevice(companionDevice);
			}
			rpsRedisData.setTestScreen(request.isTestScreen());
		}
		
		return rpsRedisData;
	}
	public Mono<Boolean> updateProspectSessionDataForNumberlink() {

		try {
			String digitalSessionId = RequestDataBuilder.withContext().fromAll().getValue(CartConstants.DIGITAL_IG_SESSION);
			String subkey = "DIGITAL_SUBKEY";
			List<String> prospectSessionKeys = new ArrayList<String>();
			prospectSessionKeys.add(CartConstants.DEVICEID);
			Map<String, String> numbeLinkSessionMap = new HashMap<String, String>();
			return sessionBean.getProspectSessionData(digitalSessionId, subkey, prospectSessionKeys).defaultIfEmpty(numbeLinkSessionMap).flatMap(allRedisValues -> {
				if (null != allRedisValues) {
					if (allRedisValues.containsKey(CartConstants.DEVICEID) && StringUtilities.isNotEmptyOrNull((String) allRedisValues.get(CartConstants.DEVICEID))) {
						numbeLinkSessionMap.put(CartConstants.DEVICEID, (String) allRedisValues.get(CartConstants.DEVICEID));
					}
					logger.debug("numbeLinkSessionMap before upserting into redis : {}", numbeLinkSessionMap);
					return sessionBean.setSessionData(numbeLinkSessionMap).onErrorReturn(true).flatMap(data -> Mono.just(true));
				}
				return Mono.just(true);
			});

		} catch (Exception e) {
			logger.info(e.getMessage());
			return Mono.just(true);
		}
	}
	/**
	 *
	 * @param channelId
	 * @return
	 */
	public Mono<InitiateAddressChangePEGAResponse> initiateAddressChange(String channelId) {

		return redisHelper.getDataFromRedis().flatMap(data -> {
			String accNumber = "";
			if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber())) {
				accNumber = data.getAccountNumber();
			}
			String mtn = "";
			if (StringUtilities.isNotEmptyOrNull(data.getMtn())) {
				mtn = data.getMtn();
			}

			return bpmHelper.initiateAddressChange(accNumber, mtn, channelId).onErrorResume(throwable -> {
				InitiateAddressChangePEGAResponse errorResp = new InitiateAddressChangePEGAResponse();
				try {
					SOEHTTPException exception = (SOEHTTPException) throwable;
					exception.getErrorHolder().getErrors().forEach(soeError -> {
						CartError error = new CartError();
						error.setMessage(soeError.getMessage());
						error.setId(soeError.getId());
						error.setNamespace(soeError.getNamespace());
						error.setName(soeError.getName());
						error.setDebug_id(soeError.getDebug_id());
						errorResp.setErrors((List<Error>)error);
					});
				} catch (Exception e) {
					logger.debug("Exception on initiateAddressChange cjcm api");
				}
				return Mono.just(errorResp);
			});
		});

	}
	/**
	 *
	 *
	 * @param request
	 * @param caseId
	 * @return
	 */
	public Mono<RPSE911AddressUpdateUIResponse> updateAddressChange(@Valid RPSE911AddressUpdateUIRequest request, String caseId) {

		return redisHelper.getDataFromRedis().flatMap(data -> {
			String deviceId = "";
			if (StringUtilities.isNotEmptyOrNull(data.getDeviceId())) {
				deviceId = data.getDeviceId();
			}
			request.setDeviceId(deviceId);
			String mtn = "";
			if (StringUtilities.isNotEmptyOrNull(data.getMtn())) {
				mtn = data.getMtn();
			}
			request.setMtn(Arrays.asList(mtn));

			String accountNumber = "";

			if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber())) {
				accountNumber = data.getAccountNumber();
			}
			String amRole = "";

			if (StringUtilities.isNotEmptyOrNull(data.getVzwRoles())) {
				amRole = data.getVzwRoles();
			}

			return bpmHelper.updateAddressChange(caseId, accountNumber, amRole,request);
		});

	}

}
