//package onevz.soe.cart.controller;
//
//import onevz.soe.cart.constants.CartConstants;
//import onevz.soe.cart.helper.FiveGHomeHelper;
//import onevz.soe.cart.requests.GetCartDetailsRequest;
//import onevz.soe.cart.responses.ErrorResponse;
//import onevz.soe.cart.responses.GenericResponse;
//import onevz.soe.cart.ui.requests.AddPlanAndDeviceUIRequest;
//import onevz.soe.cart.util.CartPegaResponseErrorsUtil;
//import onevz.soe.cart.util.CartUtil;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.http.server.reactive.ServerHttpRequest;
//import org.springframework.http.server.reactive.ServerHttpResponse;
//import org.springframework.web.bind.WebDataBinder;
//import org.springframework.web.bind.annotation.*;
//import reactor.core.publisher.Mono;
//
//import jakarta.validation.Valid;
//
///**
// * Cart Controller class.
// */
//@CrossOrigin(origins = "*", allowedHeaders = "*")
//@RestController
//@RequestMapping(value = "cart/5g")
//public class FiveGCartDetailsController {
//
//	private static final Logger logger = LoggerFactory.getLogger(FiveGCartDetailsController.class);
//
//	@Autowired
//	private FiveGHomeHelper fiveGHomeHelper;
//
//	/**
//	 *
//	 * @param binder
//	 */
//	@InitBinder("*")
//	public void initBinderByName(WebDataBinder binder) {
//		binder.setDisallowedFields(new String[] { "genericHeader" });
//	}
//
//	/**
//	 *
//	 * @param httpHeader
//	 * @param httpResponse
//	 * @param request
//	 * @return ResponseEntity
//	 *
//	 */
//	@PostMapping("/retrieve-cart")
//	public Mono<ResponseEntity<GenericResponse>> retrieveFiveGCart(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse,
//                                                                   @Valid @RequestBody GetCartDetailsRequest request) {
////		System.setProperty(CartConstants.ENDPOINT, "save-cart");
//		logger.debug("retrieve Cart Request: {}", request);
//		String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
//				? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
//				: "";
//		request.setChannelId(channelId);
//		String sessionId = "";
//		// add condition for expressStore
//		if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId))
//				|| CartConstants.EXPRESS_STORE.equalsIgnoreCase(CartUtil.getChannelType(channelId)))
//			sessionId = null != httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION)
//					? httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION).getValue()
//					: "";
//
////		request.getCartInfo().setSessionId(sessionId);
//		return fiveGHomeHelper.get5GCart(request).map(resp -> {
//			return ResponseEntity.status(HttpStatus.OK).body(resp);
//
//		});
//
//	}
//
//	@PostMapping({ "/add-plan-and-device", "/nsa/add-plan-and-device" })
//	public Mono<ResponseEntity<GenericResponse>> addPlanAndDevice(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse,
//																  @Valid @RequestBody AddPlanAndDeviceUIRequest request) {
////    System.setProperty(CartConstants.ENDPOINT, "save-cart");
//		logger.debug("Add plan and device request Request: {}", request);
//		String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
//				? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
//				: "";
//		request.setChannelId(channelId);
//		String sessionId = "";
//		// add condition for expressStore
//		if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId))
//				|| CartConstants.EXPRESS_STORE.equalsIgnoreCase(CartUtil.getChannelType(channelId)))
//			sessionId = null != httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION)
//					? httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION).getValue()
//					: "";
//
////    request.getCartInfo().setSessionId(sessionId);
//
//		return fiveGHomeHelper.addPlanAndDevice(request).map(resp -> {
//			ErrorResponse errors2 = null;
//			if (resp.getErrors() != null) {
//				errors2 = CartPegaResponseErrorsUtil.addPlanAndDeviceResponseErrors(resp);
//			}
//			return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
//					: ResponseEntity.status(HttpStatus.OK).body(resp);
//
//		});
//
//	}
//
//}
