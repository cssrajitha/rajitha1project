package onevz.soe.cart.helper;

import java.util.ArrayList;
import java.util.List;

import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import onevz.soe.cart.requests.ScanIdLookUpInfoRequest;
import onevz.soe.cart.responses.ScanIdLookUpInfoResponse;
import onevz.soe.cart.responses.ScanIdLookUpInfoResponseData;
import onevz.soe.exception.SOEError;
import onevz.soe.utilities.StringUtilities;
import reactor.core.publisher.Mono;

@Component
public class ScanIdLookUpInfoHelper {

	private static final Logger logger = LoggerFactory.getLogger(ScanIdLookUpInfoHelper.class);

	@Autowired
	private CartServiceCXPServices cxpServices;

	public Mono<ScanIdLookUpInfoResponse> scanIdLookUp(ScanIdLookUpInfoRequest request) {
		List<SOEError> errorList = new ArrayList<>();
		ScanIdLookUpInfoResponse response = new ScanIdLookUpInfoResponse();
		ScanIdLookUpInfoResponseData responseData = new ScanIdLookUpInfoResponseData();

		if (StringUtilities.isNotEmptyOrNull(request.getGemaltoSessionid())) {
			return cxpServices.scanIdLookupInfo(request).flatMap(resp -> {
				logger.info("ScanIdLookUpInfoHelper: scanIdLookUp CXP response :: {}", resp);
				if (resp != null) {
					if (resp.getErrors() != null && !resp.getErrors().isEmpty()) {
						SOEError soeError = new SOEError();
						soeError.setMessage(resp.getErrors().get(0).getMessage());
						errorList.add(soeError);
						response.setErrors(errorList);
						responseData.setStatus(-1);
						response.setData(responseData);
					} else if (resp.getData() != null) {
						responseData.setScanIdLookupInfoVo(resp.getData());
						response.setData(responseData);
						response.getData().setStatus(1);
					}
				}
				return Mono.just(response);
			}).onErrorResume(error -> {
				logger.error("ScanIdLookUpInfoHelper: scanIdLookUp CXP response failed with error :: {}", error);
				SOEError soeError = new SOEError();
				soeError.setMessage(error.getMessage());
				errorList.add(soeError);
				response.setErrors(errorList);
				responseData.setStatus(-1);
				response.setData(responseData);
				return Mono.just(response);
			});
		} else {
			SOEError error = new SOEError();
			error.setName("Bad Request");
			error.setId("1000");
			error.setMessage("GemaltoSessionId is empty");
			errorList.add(error);
			response.setErrors(errorList);
			responseData.setStatus(-1);
			response.setData(responseData);
			return Mono.just(response);
		}

	}

}
