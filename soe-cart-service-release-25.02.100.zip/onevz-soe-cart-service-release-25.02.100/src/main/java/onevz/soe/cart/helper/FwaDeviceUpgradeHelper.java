package onevz.soe.cart.helper;

import onevz.soe.cart.bpm.service.CartServiceBPMServices;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.cxp.service.CatalogService;
import onevz.soe.cart.model.addDevice.AddDeviceContext;
import onevz.soe.cart.model.addDevice.AddDeviceServiceRequest;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.requests.*;
import onevz.soe.cart.responses.DeviceExchangeResponse;
import onevz.soe.cart.responses.DualSkuResponse;
import onevz.soe.cart.responses.FWACreateCartResponse;
import onevz.soe.cart.responses.InitiateCheckoutResponse;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.bpm.model.ServiceHeader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.Map;


@Service
public class FwaDeviceUpgradeHelper {
    private static final Logger logger = LoggerFactory.getLogger(FwaDeviceUpgradeHelper.class);
    @Autowired
    private CartServiceBPMServices bpmServices;

    @Autowired
    CartServiceCXPServices cxpServices;

    @Autowired
    CatalogService catalogServices;

    @Autowired
    RedisHelper2 redisHelper;



    public Mono<DeviceExchangeResponse> getDeviceUpgradeDetails(DeviceExchangeRequest request){
        FWACreateCartRequest createCartBpmRequest = formatCreateCartRequest(request);
        Mono<FWACreateCartResponse> createCartBpmResponse = bpmServices.createCart(createCartBpmRequest);
        DualSkuRequest domainRequest = formatDualSkuRequest(request);
        Mono<DualSkuResponse> domainResponse = catalogServices.getPreferredSkuDetails(domainRequest)
                .onErrorResume(res -> Mono.just(new DualSkuResponse()));
        DeviceExchangeResponse soeResponse = new DeviceExchangeResponse();
        return Mono.zip(createCartBpmResponse,domainResponse).flatMap(tuple ->{
            FWACreateCartResponse createCartResponse = tuple.getT1();
            DualSkuResponse dualSkuResponse = tuple.getT2();
            if(CollectionUtilities.isNotEmptyOrNull(createCartResponse.getErrors())) {
                soeResponse.setErrors(createCartResponse.getErrors());
                return Mono.just(soeResponse);
            }
            return invokeUpdateCart(dualSkuResponse,request,soeResponse,createCartResponse);
        });
    }

    private FWACreateCartRequest formatCreateCartRequest(DeviceExchangeRequest request){
        FWACreateCartRequest bpmRequest = new FWACreateCartRequest();
        FwaServiceBody serviceBody = new FwaServiceBody();
        ServiceHeader headers = new ServiceHeader();
        headers.setClientId(CartConstants.VZW_DOTCOM);
        headers.setStatusMsg(CartConstants.BPM_PEGA_GENERATED_MESSAGE);
        headers.setServiceName(CartConstants.BPM_SALES_ORDER_PURCHASE);
        FwaServiceRequest serviceRequest = new FwaServiceRequest();
        FwaDeviceContext context = new FwaDeviceContext();
        FwaDeviceContextInfo contextInfo = new FwaDeviceContextInfo();
        FwaDeviceCustomerInfo customerInfo = new FwaDeviceCustomerInfo();
        FwaDeviceCartInfo cartInfo = new FwaDeviceCartInfo();
        if(null!=request){
            contextInfo.setIntent(StringUtilities.isNotEmptyOrNull(request.getIntent()) ? request.getIntent() : "");
            customerInfo.setAccountNumber(StringUtilities.isNotEmptyOrNull(request.getAccountNumber()) ? request.getAccountNumber() : "");
            customerInfo.setCartCreator(StringUtilities.isNotEmptyOrNull(request.getMtn()) ? request.getMtn() : "");
            customerInfo.setProcessingMTN(StringUtilities.isNotEmptyOrNull(request.getMtn()) ? request.getMtn() : "");
            cartInfo.setNetworkBandWidthType(StringUtilities.isNotEmptyOrNull(request.getNetworkBandWidthType()) ? request.getNetworkBandWidthType() : "");
            cartInfo.setIntendType(StringUtilities.isNotEmptyOrNull(request.getIntent()) ? request.getIntent() : "");
        }
        contextInfo.setCallReason(CartConstants.BPM_SALES_ORDER_PURCHASE);
        contextInfo.setProcessAction(CartConstants.UPGRADE_NOW);
        contextInfo.setProcessStep(CartConstants.INITIATE);
        customerInfo.setRegisterNumber(0);
        customerInfo.setThrottleName(CartConstants.HOMESAFETY_TRIAL_WITHOUT_MTNS);
        customerInfo.setBucketAllocator(CartConstants.BAU);
        customerInfo.setD2dFlag("N");
        customerInfo.setFlowType(CartConstants.FIVEG_EXCHANGE);
        cartInfo.setCartItemCount(0);
        cartInfo.setOrderType("RF");
        cartInfo.setUpdateShippingAddress(true);
        FwaRefundOrderDetails refundOrderDetails = new FwaRefundOrderDetails();
        refundOrderDetails.setCustomerType("U");
        refundOrderDetails.setSaleType("P");
        cartInfo.setRefundOrderDetails(refundOrderDetails);
        cartInfo.setRegisterNumber(0);
        cartInfo.setDiscountPromoTotal(0);
        cartInfo.setClientAppName(CartConstants.VZW_DOTCOM);
        cartInfo.setItemType(CartConstants.FWA_DEVICE);
        cartInfo.setAction(CartConstants.UPGRADE_NOW);
        context.setCustomerInfo(customerInfo);
        context.setContextInfo(contextInfo);
        context.setCartInfo(cartInfo);
        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        bpmRequest.setServiceBody(serviceBody);
        bpmRequest.setServiceHeader(headers);
        return bpmRequest;
    }

    private DualSkuRequest formatDualSkuRequest(DeviceExchangeRequest soeRequest){
        DualSkuRequest request = new DualSkuRequest();
        CatalogRequest requestData = new CatalogRequest();
        requestData.setCurrentSku(CartConstants.TITAN_SKU);
        requestData.setMultiSku("true");
        requestData.setChannelFlow("ALL");
        if(null != soeRequest && StringUtilities.isNotEmptyOrNull(soeRequest.getNetworkBandWidthType())){
            requestData.setNetworkBandWidthType(soeRequest.getNetworkBandWidthType());
        }
        request.setDeviceCatalogRequest(requestData);
        return request;
    }

    public Mono<DeviceExchangeResponse> invokeUpdateCart(DualSkuResponse dualSkuResponse,DeviceExchangeRequest request,DeviceExchangeResponse soeResponse,FWACreateCartResponse createCartResponse){
        FWAUpdateCartRequest bpmRequest = new FWAUpdateCartRequest();
        ServiceHeader headers = new ServiceHeader();
        setHeaders(headers);
        FwaUpdateCartServiceBody serviceBody = new FwaUpdateCartServiceBody();
        AddDeviceServiceRequest serviceRequest = new AddDeviceServiceRequest();
        AddDeviceContext context = new AddDeviceContext();
        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        formatCustomerInfo(customerInfo,request);
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        formatCartInfo(cartInfo,request,dualSkuResponse,createCartResponse);
        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        setContextInfoData(contextInfo,request);
        if(!ObjectUtils.isEmpty(createCartResponse.getServiceBody())
                && !ObjectUtils.isEmpty(createCartResponse.getServiceBody().getServiceResponse())
                && !ObjectUtils.isEmpty(createCartResponse.getServiceBody().getServiceResponse().getContext())
                && null!=createCartResponse.getServiceBody().getServiceResponse().getContext().getCaseId()){
            context.setCaseId(createCartResponse.getServiceBody().getServiceResponse().getContext().getCaseId());
        }
        context.setCartInfo(cartInfo);
        context.setContextInfo(contextInfo);
        context.setCustomerInfo(customerInfo);
        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        bpmRequest.setServiceHeader(headers);
        bpmRequest.setServiceBody(serviceBody);
        return bpmServices.updateCart(bpmRequest).flatMap(updateCartResponse -> {
            soeResponse.setServiceHeader(updateCartResponse.getServiceHeader());
            soeResponse.setServiceBody(updateCartResponse.getServiceBody());
            soeResponse.setErrors(updateCartResponse.getErrors());
            return invokeInitiateCheckoutRequest(soeResponse);
        });
    }

    private void setContextInfoData(CartServiceContextInfo contextInfo, DeviceExchangeRequest request) {
        contextInfo.setCallReason(CartConstants.BPM_SALES_ORDER_PURCHASE);
        if(!ObjectUtils.isEmpty(request) && StringUtilities.isNotEmptyOrNull(request.getIntent())){
            contextInfo.setIntent(request.getIntent());
        }
        contextInfo.setProcessAction(CartConstants.ADD_DEVICE);
        contextInfo.setProcessStep(CartConstants.GRIDWALL_PDP);
        contextInfo.setTransactionType(CartConstants.FIVEG_EXCHANGE_UPG);
    }

    private void setHeaders(ServiceHeader headers) {
        headers.setClientId(CartConstants.VZW_DOTCOM);
        headers.setStatusMsg(CartConstants.BPM_PEGA_GENERATED_MESSAGE);
        headers.setServiceName(CartConstants.BPM_SALES_ORDER_PURCHASE);
        headers.setStatusCode("0");
    }

    public Mono<DeviceExchangeResponse>invokeInitiateCheckoutRequest(DeviceExchangeResponse soeResponse){
        InitiateCheckoutRequest cxpRequest = new InitiateCheckoutRequest();
        InitiateCheckoutMeta metaData = new InitiateCheckoutMeta();
        InitiateCheckoutData data = new InitiateCheckoutData();
        Map<String, String> sessionData = new HashMap<>();
        metaData.setClientId(CartConstants.VZW_DOTCOM);
        if(!ObjectUtils.isEmpty(soeResponse)
                && !ObjectUtils.isEmpty(soeResponse.getServiceBody())
                && !ObjectUtils.isEmpty(soeResponse.getServiceBody().getServiceResponse())
                && !ObjectUtils.isEmpty(soeResponse.getServiceBody().getServiceResponse().getContext())
                && !ObjectUtils.isEmpty(soeResponse.getServiceBody().getServiceResponse().getContext().getCartInfo())
                && null!=soeResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartId()){
            data.setCartId(soeResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartId());
            sessionData.put(CartConstants.CARTID,soeResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartId());
            redisHelper.upsertDataIntoSession(sessionData);
        }
        cxpRequest.setData(data);
        cxpRequest.setMeta(metaData);
        return cxpServices.initiateCheckout(cxpRequest).onErrorReturn(new InitiateCheckoutResponse()).flatMap(res -> Mono.just(soeResponse));
    }

    private void formatCartInfo(CartServiceCartInfo cartInfo, DeviceExchangeRequest request, DualSkuResponse dualSkuResponse, FWACreateCartResponse createCartResponse) {
        Line lineInfo = new Line();
        Line[] lines = new Line[1];
        lineInfo.setDepletionType("F");
        lineInfo.setIspuFlow(false);
        lineInfo.setEupNoPromoFlow(false);
        lineInfo.setNewLineOrAAL(true);
        lineInfo.setLineDeviceDollar(0.0);
        Device deviceInfo = new Device();
        if(null!=dualSkuResponse.getData()
                && StringUtilities.isNotEmptyOrNull(dualSkuResponse.getData().getTitanPreferredSku())){
            deviceInfo.setId(dualSkuResponse.getData().getTitanPreferredSku());
        }
        deviceInfo.setContractTerm(CartConstants.FIVEG_CONTRACT_TERM);
        deviceInfo.setQty(1);
        deviceInfo.setAmount(0.0);
        if(null!=request){
            deviceInfo.setNetworkBandwidthType(StringUtilities.isNotEmptyOrNull(request.getNetworkBandWidthType()) ? request.getNetworkBandWidthType() : "");
            lineInfo.setMtn(StringUtilities.isNotEmptyOrNull(request.getMtn()) ? request.getMtn() : "");
            cartInfo.setIntendType(CartConstants.FWA_UPGRADE_INTENDTYPE);
        }
        if(!ObjectUtils.isEmpty(createCartResponse.getServiceBody())
                && !ObjectUtils.isEmpty(createCartResponse.getServiceBody().getServiceResponse())
                && !ObjectUtils.isEmpty(createCartResponse.getServiceBody().getServiceResponse().getContext())
                && !ObjectUtils.isEmpty(createCartResponse.getServiceBody().getServiceResponse().getContext().getCartInfo())
                && null!=createCartResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartId()){
            cartInfo.setCartId(createCartResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartId());
        }
        cartInfo.setItemType(CartConstants.FWA_DEVICE);
        cartInfo.setAction("UPDATE");
        cartInfo.setClientAppName(CartConstants.VZW_DOTCOM);
        lineInfo.setDevice(deviceInfo);
        lines[0] = lineInfo;
        cartInfo.setLines(lines);
    }

    private void formatCustomerInfo(CartServiceCustomerInfo customerInfo, DeviceExchangeRequest request) {
        if(null!=request){
            customerInfo.setAccountNumber(StringUtilities.isNotEmptyOrNull(request.getAccountNumber()) ? request.getAccountNumber() : "");
            customerInfo.setCartCreator(StringUtilities.isNotEmptyOrNull(request.getMtn()) ? request.getMtn() : "");
            customerInfo.setProcessingMTN(StringUtilities.isNotEmptyOrNull(request.getMtn()) ? request.getMtn() : "");
        }
        customerInfo.setRegisterNumber(0);
        customerInfo.setENineAddrIndicator("false");
        customerInfo.setFlowType(CartConstants.FIVEG_EXCHANGE);
    }
}
