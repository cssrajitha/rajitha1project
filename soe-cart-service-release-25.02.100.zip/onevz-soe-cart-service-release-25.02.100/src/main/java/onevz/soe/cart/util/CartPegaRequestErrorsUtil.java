package onevz.soe.cart.util;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.addDevice.AddPlanDeviceCartInfo;
import onevz.soe.cart.model.addPromoIntent.AddPromoIntentUIRequest;
import onevz.soe.cart.model.addTrialContactInfoAndAddress.AddTrialContactInfoAndAddressUIRequest;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.common.FiveG.FiveGLTEAddressRedis;
import onevz.soe.cart.model.manualDiscount.ManualDiscount;
import onevz.soe.cart.model.myOffer.MyOfferLine;
import onevz.soe.cart.model.retrieveDpp.RetrieveDppRequest;
import onevz.soe.cart.model.salesOrderAdjustment.Items;
import onevz.soe.cart.model.salesOrderAdjustment.LineInfo;
import onevz.soe.cart.model.updateDeviceSimId.UpdateDeviceSimIdLine;
import onevz.soe.cart.model.updateSellerPrice.UpdateSellerPriceLine;
import onevz.soe.cart.requests.ESimDetailsETNIRequest;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.responses.FiveGAddressRedisData;
import onevz.soe.cart.responses.MyOfferETRRedisData;
import onevz.soe.cart.responses.RemoveOfferRedisData;
import onevz.soe.cart.ui.common.CartInfo;
import onevz.soe.cart.ui.common.DeviceCartInfo;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.channels.SOEChannels;
import onevz.soe.exception.SOEError;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import org.apache.commons.collections4.ListUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.server.reactive.ServerHttpRequest;

import java.util.ArrayList;
import java.util.List;

/**
 * SOE Request Error Handler class.
 */
public class CartPegaRequestErrorsUtil extends CartPegaRequestErrorsUtilParent{
	private CartPegaRequestErrorsUtil() {
	}
    private static final Logger logger = LoggerFactory.getLogger(CartPegaRequestErrorsUtil.class);

	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleSaveCartRequestErrors(SaveCartUIRequest request) {
		List<CartErrorDetail> errorDetails = new ArrayList<>();
		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	public static ErrorResponse handleDeviceIdValidationRequestErrors(DeviceIdValidationUIRequest request) {
		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (request.getData() == null) {
			errorDetails.add(generateMissingError(CartConstants.DATA));
		} else {
			if (request.getData().getLines() == null)
				errorDetails.add(generateMissingError(CartConstants.LINE_DETAILS));
			else if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntent()))
				validateDeviceId(errorDetails, request.getData().getLines(), request.getCartInfo().getIntent(),
						request.getCartInfo().getProcessStep());
			else
				validateDeviceId(errorDetails, request.getData().getLines(), "",
						request.getCartInfo().getProcessStep());
		}

		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	public static ErrorResponse handleUpdateChatIdRequestErrors(UpdateChatIdUIRequest request) {
		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (StringUtilities.isEmptyOrNull(request.getChatId())) {
			errorDetails.add(generateMissingError(CartConstants.CHAT_ID_FIELD));
		}
		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	public static ErrorResponse handleUpdateWFMInfoRequestErrors(UpdateWFMInfoUIRequest request) {
		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (StringUtilities.isEmptyOrNull(request.getCartInfo().getIntent())) {
			errorDetails.add(generateMissingError(CartConstants.INTENT));
		}
		if (request.getData() != null) {
			if (request.getData().getWfmOrderInfo() == null) {
				errorDetails.add(generateMissingError(CartConstants.WFM_ORDER_INFO));
			}
		}

		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	public static ErrorResponse handleAddDeviceRequestErrors(AddDeviceUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();
		String intendType = request.getCartInfo().getIntendType();
		Boolean newLineOrByod = false;
		if ((StringUtilities.isEmptyOrNull(request.getCartInfo().getCaseId())
				&& StringUtilities.isEmptyOrNull(request.getCartInfo().getCartId()))
				|| CartConstants.AAL.equalsIgnoreCase(intendType) || CartConstants.BYOD.equalsIgnoreCase(intendType)) {
			newLineOrByod = true;
		}
		//fix: CXTDT-502432 - validation for processingMTN field
		if (StringUtilities.isNotEmptyOrNull(request.getChannelId()) &&
				CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId())) &&
				StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessingMTN())) {
			errorDetails = validateProcessingMtn(errorDetails, request.getCartInfo().getProcessingMTN());
		}
		if (request.getData().getLines() == null) {
			errorDetails.add(generateMissingError(CartConstants.LINE_DETAILS));
		} else {

			int index = 1;
			for (Lines line : request.getData().getLines()) {
				errorDetails = validateMtn(errorDetails, index - 1, line.getMtn());
				if(line.getDevice() != null && StringUtilities.isNotEmptyOrNull(request.getChannelId()) &&
						SOEChannels.findByChannelName(request.getChannelId()).getChannelType().equals(CartConstants.DIGITAL_CHANNEL)){
					errorDetails = validateProductId(errorDetails, index - 1, line.getDevice().getProductId());
				}
				if("OMNI-TELESALES".equalsIgnoreCase(request.getChannelId())) 
					if(Boolean.TRUE.equals("L".equalsIgnoreCase(line.getDepletionType()) && null != line.getIspuFlow() && !line.getIspuFlow() &&
							null != request.getCartInfo().getIsPrepayCart()) && !request.getCartInfo().getIsPrepayCart().equalsIgnoreCase(CartConstants.Y))
						errorDetails.add(generateValidationError("ispuFlow"));
				if (request.getCartInfo().getProcessStep() != null
						&& !("E911".equalsIgnoreCase(request.getCartInfo().getProcessStep())))
					if (StringUtilities.isEmptyOrNull(request.getCartInfo().getCartId())
							&& StringUtilities.isEmptyOrNull(request.getCartInfo().getCaseId()))
						errorDetails = validateAddDevice(errorDetails, line, intendType, newLineOrByod, index);
					else if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCaseId())
							&& StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCartId()))
						errorDetails = validateAddDevice(errorDetails, line, intendType, newLineOrByod, index);
				index++;
			}
		}

		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	public static ErrorResponse handleClearAndContinueRequestErrors(String action) {
		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (CartConstants.ITEM_TYPE.equalsIgnoreCase(action))
			errorDetails.add(generateMissingError("itemType from Redis"));
		else if (CartConstants.DEVICE_ACCESSORY.equalsIgnoreCase(action))
			errorDetails.add(generateMissingError("Device/Accessory"));

		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	public static ErrorResponse handleAddDeviceMtnFlow(String mtnFlow) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();
		if (StringUtilities.isEmptyOrNull(mtnFlow) || !("G").equalsIgnoreCase(mtnFlow)) {
			errorDetails.add(generateMtnFlowError());
		}

		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	public static ErrorResponse handleAddFeaturesRequestErrors(AddFeaturesUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();
		if (StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessStep())) {
			errorDetails.add(generateMissingError(CartConstants.PROCESS_STEP));
		}

		if (request.getData().getLines() == null && request.getData().getAccount() == null) {
			errorDetails.add(generateMissingError(CartConstants.FEATURES_REQUIRED));
		} else {
			if (request.getData().getLines() != null) {
				LineFeature[] lines = request.getData().getLines();
				int index = 0;
				for (LineFeature line : lines) {
					if (StringUtilities.isEmptyOrNull(line.getMtn())) {
						errorDetails.add(generateMissingError(CartConstants.MTN));
					} else {
						errorDetails = validateMtn(errorDetails, index, line.getMtn());
					}
					if (line.getFeatures() == null && line.getMcsSubscription() == null) {
						errorDetails.add(generateMissingError(CartConstants.FEATURES_AND_SUBSCRIPTIONS));
					} else {
						if (line.getFeatures() != null)
							errorDetails = validateLineFeatureAction(errorDetails, line.getFeatures());
						if (null != line.getMcsSubscription()) {
							if (null != line.getMcsSubscription().getAdd())
								errorDetails = validateSubscriptions(errorDetails, line.getMcsSubscription().getAdd());
							if (null != line.getMcsSubscription().getRemove())
								errorDetails = validateSubscriptions(errorDetails,
										line.getMcsSubscription().getRemove());
						}
					}
					index++;
				}
			}
			if (request.getData().getAccount() != null) {
				Account account = request.getData().getAccount();
				if (account.getFeatures() == null && account.getMcsSubscription() == null) {
					errorDetails.add(generateMissingError(CartConstants.FEATURES_AND_SUBSCRIPTIONS));
				} else {
					if (account.getFeatures() != null) {
						errorDetails = validateLineFeatureAction(errorDetails, account.getFeatures());
					}
					if (null != account.getMcsSubscription()) {
						if (null != account.getMcsSubscription().getAdd())
							errorDetails = validateSubscriptions(errorDetails, account.getMcsSubscription().getAdd());
						if (null != account.getMcsSubscription().getRemove())
							errorDetails = validateSubscriptions(errorDetails,
									account.getMcsSubscription().getRemove());
					}
				}

			}

		}

		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}


	public static ErrorResponse handleAddAccessoriesRequestErrors(AddAccessoriesUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (StringUtilities.isNotEmptyOrNull(request.getData().getZipCode())) {
			validateZipCode("zipCode",request.getData().getZipCode(), errorDetails);
		}
		if (StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessStep())) {
			errorDetails.add(generateMissingError(CartConstants.PROCESS_STEP));
		}
		if (request.getCartInfo().getProcessAction() == null) {
			errorDetails.add(generateMissingError(CartConstants.PROCESS_ACTION));
		}
		if (!request.getCartInfo().isFlexV2()) {
			errorDetails = validateIntendType(errorDetails, request.getCartInfo().getIntendType(), request.getChannelId());
		}

		if (request.getData().getLines() == null) {
			errorDetails.add(generateMissingError(CartConstants.LINE_DETAILS));
		} else {
			Lines[] lines = request.getData().getLines();
			int index = 0;
			for (Lines line : lines) {
				errorDetails = validateMtn(errorDetails, index, line.getMtn());
				if("OMNI-TELESALES".equalsIgnoreCase(request.getChannelId())) {
					if((StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCaseId())
							&& request.getCartInfo().getCaseId().startsWith("SOF"))) {
						logger.info("Skipping ErrorCheck For Prepay Flow");
					}
					else
					{
						if ("L".equalsIgnoreCase(request.getData().getDepletionType())
								&& null != line.getIspuFlow()
								&& !line.getIspuFlow()) {
							errorDetails.add(generateValidationError("ispuFlow"));
						}
					}
				}
				if(null != line.getIspuFlow() && line.getIspuFlow()) {
					if(StringUtilities.isEmptyOrNull(line.getDepletionLocationCode()))
							errorDetails.add(generateMissingError("deletionLocationCode"));
						}
				if (line.getAddAccessories() == null && line.getRemoveAccessories() == null) {
					errorDetails.add(generateMissingError(CartConstants.ACCESSORIES));
				} else {
					if (null != line.getAddAccessories())
						errorDetails = validateAccessories(errorDetails, line.getAddAccessories());
					if (null != line.getRemoveAccessories())
						errorDetails = validateAccessories(errorDetails, line.getRemoveAccessories());
				}
				if (line.getAddAccessories() != null && request.getCartInfo() != null
						&& "GAMINGCONSOLE".equalsIgnoreCase(request.getCartInfo().getSubscriptionType())
						&& "L".equalsIgnoreCase(request.getData().getDepletionType()) &&  null != line.getIspuFlow()
						&& !line.getIspuFlow()) {
					for (Accessory addAccessory : line.getAddAccessories()) {
						if (StringUtilities.isEmptyOrNull(addAccessory.getSerialNumber())) {
							errorDetails.add(generateMissingError(CartConstants.SERIAL_NUMBER));
						}
					}
				}
				
				//Xbox Exchange changes for Retail Channel
				if (StringUtils.isNotEmpty(request.getChannelId()) && request.getChannelId().contains(CartConstants.RETAIL) && line.getAddAccessories() != null && request.getCartInfo() != null
						&& request.getCartInfo().getSubscriptionType() !=null && "GAMINGCONSOLE".equalsIgnoreCase(request.getCartInfo().getSubscriptionType())
						&& request.getCartInfo().getIntendType().equalsIgnoreCase("REX")) {

							errorDetails.add(xboxExchangeNotAllowedForRetailError(request.getCartInfo().getSubscriptionType()));
				}
				
				index++;
			}
		}

		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleRemoveLinesRequestErrors(RemoveLinesUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();
		errorDetails = handleErrorDetails(errorDetails,  request.getData().getLines());
		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleAddBuyoutRequestErrors(AddBuyoutUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (StringUtilities.isEmptyOrNull(request.getCartInfo().getBuyOutFlag())) {
			errorDetails.add(generateMissingError(CartConstants.BUY_OUT_FLAG));
		}
		if (StringUtilities.isEmptyOrNull(request.getCartInfo().getBuyOutSelected())) {
			errorDetails.add(generateMissingError(CartConstants.BUY_OUT_SELECTED));
		}
		if (StringUtilities.isEmptyOrNull(request.getCartInfo().getEdgeUpSelected())) {
			errorDetails.add(generateMissingError(CartConstants.EDGE_UP_SELECTED));
		}
		errorDetails = handleErrorDetails(errorDetails,request.getData().getLines());
		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}
	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleAddEdgeUpRequestErrors(UpdateEdgeupUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (StringUtilities.isEmptyOrNull(request.getCartInfo().getBuyOutFlag())) {
			errorDetails.add(generateMissingError(CartConstants.BUY_OUT_FLAG));
		}
		if (StringUtilities.isEmptyOrNull(request.getCartInfo().getBuyOutSelected())) {
			errorDetails.add(generateMissingError(CartConstants.BUY_OUT_SELECTED));
		}
		if (StringUtilities.isEmptyOrNull(request.getCartInfo().getEdgeUpSelected())) {
			errorDetails.add(generateMissingError(CartConstants.EDGE_UP_SELECTED));
		}
		if (StringUtilities.isEmptyOrNull(request.getCartInfo().getFmiTurnedOff())) {
			errorDetails.add(generateMissingError("fmiTurnedOff"));
		}
		if (StringUtilities.isEmptyOrNull(request.getCartInfo().getDeviceMisMatched())) {
			errorDetails.add(generateMissingError("deviceMisMatched"));
		}
		if (ArrayUtils.isEmpty(request.getData().getLines())) {
			errorDetails.add(generateMissingError(CartConstants.LINE_DETAILS));
		} else {
			Lines[] lines = request.getData().getLines();
			int index = 0;
			for (Lines line : lines) {
				errorDetails = handleMtnErrorDetails(errorDetails,line,index);	
				if (line.getEdgeup() == null) {
					errorDetails.add(generateMissingError(CartConstants.EDGEUP));
				}
				index++;
			}
		}

		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleRemoveEdgeUpRequestErrors(UpdateEdgeupUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();
		errorDetails = handleErrorDetails(errorDetails,request.getData().getLines());
		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * 
	 * @param request
	 * @return errorResp
	 */
	public static ErrorResponse handleRemoveBvoOffersRequestErrors(UpdateBvoOffersUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();
		
		if (request.getData().getLines() == null)
			errorDetails.add(generateMissingError(CartConstants.LINE_DETAILS));
		else
			handleOfferDataRequest(request.getData().getLines(), errorDetails);
		
		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		
		return errors == null ? new ErrorResponse() : errors;
	}
	
	/**
	 * 
	 * @param request
	 * @return errorResp
	 */
	public static ErrorResponse handleUpsertRemoveOfferDataRequestErrors(RemoveOfferRedisData request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();
		
		if (ListUtils.emptyIfNull(request.getLines()).isEmpty())
			errorDetails.add(generateMissingError(CartConstants.LINE_DETAILS));
		else
			handleOfferDataRequest(request.getLines(), errorDetails);
		
		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		
		return errors == null ? new ErrorResponse() : errors;
	}
		
	/**
	 * 
	 * @param request
	 * @return errorResp
	 */
	public static ErrorResponse handleUpdateSellerPriceRequestErrors(UpdateSellerPriceUIRequestNew request) {
		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (request.getData().getLines() == null) {
			errorDetails.add(generateMissingError(CartConstants.LINE_DETAILS));
		} else {
			List<UpdateSellerPriceLine> lines = request.getData().getLines();
			int index = 0;
			for (UpdateSellerPriceLine line : lines) {
				if (StringUtilities.isEmptyOrNull(line.getMtn())) {
					errorDetails.add(generateMissingError(CartConstants.MTN));
				} else {
					errorDetails = validateMtn(errorDetails, index, line.getMtn());
				}
				if (StringUtilities.isEmptyOrNull(String.valueOf(line.getSellerPrice())))
					errorDetails.add(generateMissingError(CartConstants.SELLERPRICE));
				index++;
			}
		}

		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleAddPlanRequestErrors(AddPlanUIRequest request, ServerHttpRequest httpHeader) {
		boolean isAddPlansAndPerksPath = httpHeader.getPath() != null && httpHeader.getPath().value().contains("/addPlanAndPerks");
		List<CartErrorDetail> errorDetails = new ArrayList<>();

			Lines[] lines = request.getData().getLines();
			int index = 0;
			for (Lines line : lines) {
				if (StringUtilities.isEmptyOrNull(line.getMtn())) {
					errorDetails.add(generateMissingError(CartConstants.MTN));
				} else {
					errorDetails = validateMtn(errorDetails, index, line.getMtn());
				}

				if(isAddPlansAndPerksPath){
					logger.debug("Skip Plan field validations for UI and Perks add...");
				}else{
					if (line.getPlan() == null) {
						errorDetails.add(generateMissingError(CartConstants.PLAN));
					}
				}
				index++;
			}
		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleUpdateDeviceSimIdRequestErrors(UpdateDeviceSIMIdUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (request.getData().getLines() == null) {
			errorDetails.add(generateMissingError(CartConstants.LINE_DETAILS));
		} else {
			List<UpdateDeviceSimIdLine> lines = request.getData().getLines();
			for (UpdateDeviceSimIdLine line : lines) {
				if (StringUtilities.isEmptyOrNull(line.getMtn())) {
					errorDetails.add(generateMissingError(CartConstants.MTN));
				}
				if (line.getDevice() == null) {
					errorDetails.add(generateMissingError(CartConstants.DEVICE));
				} else {
					Device device = line.getDevice();
					if (StringUtilities.isEmptyOrNull(device.getId())) {
						errorDetails.add(generateMissingError(CartConstants.ID));
					}
					if (StringUtilities.isEmptyOrNull(device.getDeviceId())) {
						errorDetails.add(generateMissingError(CartConstants.DEVICEID));
					}
				}
				if (line.getSim() == null) {
					errorDetails.add(generateMissingError(CartConstants.SIM));
				} else {
					SoftSKUItem sim = line.getSim();
					if (StringUtilities.isEmptyOrNull(sim.getId())) {
						errorDetails.add(generateMissingError(CartConstants.ID));
					}
				}
			}
		}

		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handlePastDuesRequestErrors(PastDuesUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (request.getData().getPastdue() == null
				|| StringUtilities.isEmptyOrNull(request.getData().getPastdue().getAmount())) {
			errorDetails.add(generateMissingError(CartConstants.PASTDUE));
		}

		if (request.getData().getEffectiveDate() == null) {
			errorDetails.add(generateMissingError(CartConstants.EFFECTIVE_DATE));
		}

		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleInitiateCheckoutRequestErrors(InitiateCheckoutUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();

		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleAddDownPaymentRequestErrors(DownPaymentUIRequest request) {

		String channelType = CartUtil.getChannelType(request.getChannelId());
		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (!CartConstants.DIGITAL.equalsIgnoreCase(channelType)) {
			errorDetails = validateCartId(errorDetails, request.getCartInfo().getCartId());
			if (StringUtilities.isEmptyOrNull(request.getCartInfo().getCaseId())) {
				errorDetails.add(generateMissingError(CartConstants.CASE_ID));
			}
			if (!CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())
					&& !CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())
					&& StringUtilities.isEmptyOrNull(request.getCartInfo().getAccountNumber())) {
				errorDetails.add(generateMissingError(CartConstants.ACCOUNT_NUMBER));
			}
		}
		if (ArrayUtils.isEmpty(request.getData().getLines())) {
			errorDetails.add(generateMissingError(CartConstants.LINE_DETAILS));
		} else {
			Lines[] lines = request.getData().getLines();
			for (Lines line : lines) {
				errorDetails = validateDownPayment(errorDetails, line, channelType);
			}
		}

		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleCreateLineRequestErrors(CreateLineUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (ListUtils.emptyIfNull(request.getData().getLines()).isEmpty()) {
			errorDetails.add(generateMissingError(CartConstants.LINE_DETAILS));
		}
		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleNumberShareRequestErrors(NumberShareUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (ArrayUtils.isEmpty(request.getData().getLines())) {
			errorDetails.add(generateMissingError(CartConstants.LINE_DETAILS));
		}
		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleServiceAddressRequestErrors(ServiceAddressUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (ArrayUtils.isEmpty(request.getData().getLines())) {
			errorDetails.add(generateMissingError(CartConstants.LINE_DETAILS));
		} else {
			Lines[] lines = request.getData().getLines();
			for (Lines line : lines) {
				if (StringUtilities.isEmptyOrNull(line.getMtn())) {
					errorDetails.add(generateMissingError(CartConstants.MTN));
				}
				if (line.getServiceAddress() == null) {
					errorDetails.add(generateMissingError("serviceAddress object"));
				} else if (line.getServiceAddress().getAddress() == null) {
					errorDetails.add(generateMissingError(CartConstants.ADDRESS_OBJECT));
				}
			}
		}

		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}
	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleBillingAddressRequestErrors(BillingAddressUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (ArrayUtils.isEmpty(request.getData().getLines())) {
			errorDetails.add(generateMissingError(CartConstants.LINE_DETAILS));
		} else {
			Lines[] lines = request.getData().getLines();
			for (Lines line : lines) {
				if (StringUtilities.isEmptyOrNull(line.getMtn())) {
					errorDetails.add(generateMissingError(CartConstants.MTN));
				}
				if (line.getBillingAddress() == null) {
					errorDetails.add(generateMissingError("billingAddress object"));
				} else if (line.getBillingAddress().getAddress() == null) {
					errorDetails.add(generateMissingError(CartConstants.ADDRESS_OBJECT));
				}
			}
		}

		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleE911AddressRequestErrors(E911AddressUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (ArrayUtils.isEmpty(request.getData().getLines())) {
			errorDetails.add(generateMissingError(CartConstants.LINE_DETAILS));
		} else {
			Lines[] lines = request.getData().getLines();
			for (Lines line : lines) {
				if (line.getE911Address() == null) {
					errorDetails.add(generateMissingError("E911Address object"));
				} else if (line.getE911Address().getAddress() == null) {
					errorDetails.add(generateMissingError(CartConstants.ADDRESS_OBJECT));
				}
			}
		}

		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleInstantCreditDownPaymentRequestErrors(InstantCreditDownPaymentUIRequest request) {
		return CartCxpRequestErrorsUtil.handleInstantCreditDownPaymentRequestErrors(request);
	}

	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleSalesRepAndLocationCodeRequestErrors(SalesRepAndLocationCodeUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (StringUtilities.isEmptyOrNull(request.getCartInfo().getCartId())) {
			errorDetails.add(generateMissingError(CartConstants.CART_ID));
		}
		if (StringUtilities.isEmptyOrNull(request.getData().getSalesRepId())) {
			errorDetails.add(generateMissingError("salesRepId"));
		}

		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleEffectiveDateOverrideRequestErrors(EffectiveDateOverrideUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (ArrayUtils.isEmpty(request.getData().getLines())) {
			errorDetails.add(generateMissingError(CartConstants.LINE_DETAILS));
		}

		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;

	}

	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleAssignMtnRequestErrors(AssignMtnUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();
		if (StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessStep())) {
			errorDetails.add(generateMissingError(CartConstants.PROCESS_STEP));
		}
		if (ListUtils.emptyIfNull(request.getData().getLines()).isEmpty()) {
			errorDetails.add(generateMissingError(CartConstants.LINES));
		} else {
			if (request.getData().getLines() != null) {
				int index = 0;
				List<Lines> lines = request.getData().getLines();
				for (Lines line : lines) {
					if (StringUtilities.isNotEmptyOrNull(line.getMtn())) {
						errorDetails = validateMtn(errorDetails, index, line.getMtn());
					}
					if (StringUtilities.isEmptyOrNull(line.getNpaNxx())) {
						errorDetails.add(generateMissingError(CartConstants.NPANXX));
					} else {
						errorDetails = validateNpaNxx(errorDetails, index, line.getNpaNxx());
					}
					index++;
				}
			}
		}

		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleDeassignMtnRequestErrors(DeassignMtnUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();
		if (StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessStep())) {
			errorDetails.add(generateMissingError(CartConstants.PROCESS_STEP));
		}
		return handleValidateMtnError(request.getData().getLines(), errorDetails);
	}

	public static List<CartError> handleRoleAmountRequestErrors(String role, String minimumBillAmount) {
		List<CartErrorDetail> errorDetails = new ArrayList<>();
		errorDetails.add(generateDeviceAmountError("Amount", role, minimumBillAmount));
		return  settingCartError(errorDetails,CartConstants.SESSION_ENDED_REPROCESS);
	}

	public static ErrorResponse handleUpdatePurchaseOrderRequestErrors(UpdatePurchaseOrderUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();
		if (StringUtilities.isEmptyOrNull(request.getCartId())) {
			errorDetails.add(generateMissingError(CartConstants.CART_ID));
		}

		if (StringUtilities.isEmptyOrNull(request.getIntendType())) {
			errorDetails.add(generateMissingError(CartConstants.INTEND_TYPE));
		}
		if (StringUtilities.isEmptyOrNull(request.getPurchaseOrderNumber())) {
			errorDetails.add(generateMissingError("purchaseOrderNumber"));
		}
		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleAdd5GBulkOrderRequestErrors(Add5GBulkOrderUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();
		Boolean newLineOrByod = false;

		if (request.getData().getLines() == null) {
			errorDetails.add(generateMissingError(CartConstants.LINE_DETAILS));
		} else {
			List<Lines> lines = request.getData().getLines();
			String intendType = request.getCartInfo().getIntendType();
			int index = 1;
			for (Lines line : lines) {
				if (!("E911".equalsIgnoreCase(request.getCartInfo().getProcessStep())))
					errorDetails = validateAddDevice(errorDetails, line, intendType, newLineOrByod, index);
				index++;
			}
		}

		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	public static ErrorResponse handleApplyMyOfferRequestErrors(ApplyOfferRequest request,
			MyOfferETRRedisData myOfferData) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();
		if (myOfferData == null || myOfferData.getLines() == null) {
			errorDetails.add(generateMissingError(CartConstants.LINE_DETAILS));
		} else {

			List<MyOfferLine> offerLine = myOfferData.getLines();
			for (MyOfferLine line : offerLine) {
				if (StringUtilities.isEmptyOrNull(line.getMtn())) {
					errorDetails.add(generateMissingError(CartConstants.MTN));
				}
				if (CollectionUtilities.isEmptyOrNull(line.getOffers())) {
					errorDetails.add(generateMissingError(CartConstants.MYOFFER));
				}

			}

		}

		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * 
	 * @param request
	 * @return errorResp
	 */
	public static ErrorResponse handleAddTransferUpgradeRequestErrors(UpdateTransferUpgradeUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (request.getData().getLines() == null) {
			errorDetails.add(generateMissingError(CartConstants.LINE_DETAILS));
		} else {
			List<Lines> lines = request.getData().getLines();
			for (Lines line : lines) {
				if (StringUtilities.isEmptyOrNull(line.getMtn())) {
					errorDetails.add(generateMissingError(CartConstants.MTN));
				}
				if (StringUtilities.isEmptyOrNull(line.getDonorMtn())) {
					errorDetails.add(generateMissingError(CartConstants.DONOR_MTN));
				}
			}
		}

		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 * 
	 * @param request
	 * @return errorResp
	 */
	public static ErrorResponse handleRemoveTransferUpgradeRequestErrors(UpdateTransferUpgradeUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();
		return handleValidateMtnError(request.getData().getLines(), errorDetails);
	}

	/**
	 *
	 * @return errorResp
	 */
	public static CartError handleDeviceSimIdErrors() {

		CartError error = new CartError();
		error.setNamespace(CartConstants.SOE_CART_SERVICE);

		CartErrorDetail detail = new CartErrorDetail();
		detail.setField("deviceId/simId");
		detail.setIssue("deviceId/simId has/have been tampered.");
		detail.setLocation(CartConstants.REQUEST);
		detail.setValue("Mismatch");

		List<CartErrorDetail> errorDetails = new ArrayList<>();
		errorDetails.add(detail);
		error.setDetailList(errorDetails);

		return error;
	}

	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleClearCartRequestErrors(ClearCartUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();

		errorDetails = validateClearCartHeaders(errorDetails, request.getCartInfo());

		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	public static ErrorResponse handleDeleteCartRequestErrors(DeleteCartUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();

		errorDetails = validateClearCartHeaders(errorDetails, request.getCartInfo());

		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/*
	 * @param response
	 * 
	 * @return
	 */
	public static FiveGAddressRedisData handleFiveAddressErrors() {

		FiveGAddressRedisData errors = new FiveGAddressRedisData();
		List<CartError> errorList = new ArrayList<>();

		CartError error = new CartError();
		error.setNamespace(CartConstants.SOE_CART_SERVICE);
		error.setId(CartConstants.FIVEG_ADDR_MISSING);
		error.setName(CartConstants.REQUEST_VALIDATION_ERROR);
		error.setMessage("FiveG qualified address is not available. Please select one.");
		errorList.add(error);
		errors.setErrors(errorList);
		return errors;
	}

	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleRPSE911AddressUpdateRequestErrors(RPSE911AddressUpdateUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (request.getAddressLine1() == null) {
			errorDetails.add(generateMissingError("addressLine1"));
		}
		if (request.getCityName() == null) {
			errorDetails.add(generateMissingError("CityName"));
		}
		if (request.getState() == null) {
			errorDetails.add(generateMissingError("state"));
		}
		if (request.getZipCode() == null) {
			errorDetails.add(generateMissingError("zipCode"));
		}
		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleRPSReleasePendingOrderRequestErrors(RPSReleasePendingOrderUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (request.getLineItemInfoList() != null && request.getLineItemInfoList().get(0).getOrderNumber() == null) {
			errorDetails.add(generateMissingError("orderNumber"));
		}
		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleSalesOrderAdjustmentRequestErrors(SalesOrderAdjustmentUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessStep())) {
			errorDetails.add(generateMissingError(CartConstants.PROCESS_STEP));
		}
		if (request.getCartInfo().getIntendType() == null) {
			errorDetails.add(generateMissingError(CartConstants.INTEND_TYPE));
		}
		errorDetails = validateIntendType(errorDetails, request.getCartInfo().getIntendType(), request.getChannelId());

		if (request.getRefundOrderdetails().getLines() == null) {
			errorDetails.add(generateMissingError(CartConstants.LINE_DETAILS));
		} else {
			if (request.getRefundOrderdetails().getLines().getLineInfo() == null)
				errorDetails.add(generateMissingError(CartConstants.LINE_DETAILS));
			else {
				LineInfo[] lineInfo = request.getRefundOrderdetails().getLines().getLineInfo();

				for (LineInfo line : lineInfo) {
					if (line.getItems() == null) {
						errorDetails.add(generateMissingError(CartConstants.ITEM_DETAILS));
					} else {
						Items[] items = line.getItems();
						for (Items item : items) {
							if (item.getItemCode() == null)
								errorDetails.add(generateMissingError(CartConstants.ITEM_CODE));
							if (item.getCartItemType() == null)
								errorDetails.add(generateMissingError(CartConstants.ITEM_TYPE));
							if (item.getQty() == null)
								errorDetails.add(generateMissingError(CartConstants.QTY));
							if (item.getRefundType() == null)
								errorDetails.add(generateMissingError(CartConstants.REFUND_TYPE));
						}

					}
				}
			}
		}

		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param cartInfo
	 * @return ErrorResponse
	 */
	public static List<CartError> validateCartIdAndCaseId(CartInfo cartInfo) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();
		if (StringUtilities.isEmptyOrNull(cartInfo.getCartId())) {
			errorDetails.add(generateMissingError(CartConstants.CART_ID));
		}
		if (StringUtilities.isEmptyOrNull(cartInfo.getCaseId())) {
			errorDetails.add(generateMissingError(CartConstants.CASE_ID));
		}
		return  settingCartError(errorDetails,CartConstants.SESSION_ENDED_REPROCESS);
	}
	
	/**
	 *
	 * @param cartInfo
	 * @return ErrorResponse
	 */
	public static List<CartError> validateCartIdAndCaseId(DeviceCartInfo cartInfo) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();
		if (StringUtilities.isEmptyOrNull(cartInfo.getCartId())) {
			errorDetails.add(generateMissingError(CartConstants.CART_ID));
		}
		if (StringUtilities.isEmptyOrNull(cartInfo.getCaseId())) {
			errorDetails.add(generateMissingError(CartConstants.CASE_ID));
		}
		return  settingCartError(errorDetails,CartConstants.SESSION_ENDED_REPROCESS);
	}

	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleRPSApplePayloadUIRequestErrors(RPSApplePayloadUIRequest request,String encryptedPayloadReq) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();
		if(null != request) {
			if (request.getCarrierPostData() == null) {
					errorDetails.add(generateMissingError("carrierPostData"));
				}
				if (request.getSecondaryDeviceActive() == null) {
					errorDetails.add(generateMissingError("secondaryDeviceActive"));
					if (request.getSecondaryDeviceActive().getDeviceImei() == null) {
						errorDetails.add(generateMissingError("deviceImei"));
					}
				}
			}
		else{
			errorDetails.add(generateMissingError("RPSApplePayloadUIRequest"));
		}
		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	public static ErrorResponse handleAccountPinRequestErrors(AccountPinUIRequest request) {


		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (request.getCartInfo() == null) {
			errorDetails.add(generateMissingError("CartInfo"));
		}
		if (request.getCartInfo() != null && (request.getCartInfo().getAccountPin()== null || StringUtilities.isEmptyOrNull(request.getCartInfo().getAccountPin()))) {
			errorDetails.add(generateMissingError("accountPin"));
		}

		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;

	}

	public static List<CartError> validateCartIdAndCaseId5G(AddPlanDeviceCartInfo cartInfo) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();
		if (StringUtilities.isEmptyOrNull(cartInfo.getCartId())) {
			errorDetails.add(generateMissingError(CartConstants.CART_ID));
		}
		if (StringUtilities.isEmptyOrNull(cartInfo.getCaseId())) {
			errorDetails.add(generateMissingError(CartConstants.CASE_ID));
		}
		return  settingCartError(errorDetails,CartConstants.SESSION_ENDED_REPROCESS);
	}
	public static List<CartError> validateProcessMtnCartCreator5G(AddPlanDeviceCartInfo cartInfo) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();
		if (StringUtilities.isEmptyOrNull(cartInfo.getCartCreator())) {
			errorDetails.add(generateMissingError(CartConstants.CART_CREATOR));
		}
		if (StringUtilities.isEmptyOrNull(cartInfo.getProcessingMTN())) {
			errorDetails.add(generateMissingError(CartConstants.PROCESSING_MTN));
		}
		return  settingCartError(errorDetails,CartConstants.SESSION_ENDED_REPROCESS);
	}
	public static List<CartError> validateIntentType5G(AddPlanDeviceCartInfo cartInfo) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();
		if (StringUtilities.isEmptyOrNull(cartInfo.getIntendType())) {
			errorDetails.add(generateMissingError(CartConstants.INTENDTYPE));
		}
		return  settingCartError(errorDetails,CartConstants.SESSION_ENDED_REPROCESS);
	}
	public static List<CartError> validateProcessStepProcessAction5G(AddPlanDeviceCartInfo cartInfo) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();
		if (StringUtilities.isEmptyOrNull(cartInfo.getProcessStep())) {
			errorDetails.add(generateMissingError(CartConstants.PROCESS_STEP));
		}
		if (StringUtilities.isEmptyOrNull(cartInfo.getProcessAction())) {
			errorDetails.add(generateMissingError(CartConstants.PROCESS_ACTION));
		}
		return  settingCartError(errorDetails,CartConstants.SESSION_ENDED_REPROCESS);
	}

	public static FiveGLTEAddressRedis handleFiveAddressErrors5GFlow(FiveGLTEAddressRedis address) {

		List<CartError> errorList = new ArrayList<>();
		CartError error = new CartError();
		error.setNamespace(CartConstants.SOE_CART_SERVICE);
		error.setId(CartConstants.FIVEG_ADDR_MISSING);
		error.setName(CartConstants.REQUEST_VALIDATION_ERROR);
		error.setMessage("FiveG qualified address is not available. Please select one.");
		errorList.add(error);
		address.setErrors(errorList);
		return address;
	}
	
	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleManualDiscountRequestErrors(UpdateManualDiscountUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();

		
		errorDetails = validateIntendType(errorDetails, request.getCartInfo().getIntendType(), CartConstants.ASSISTED);
		if (StringUtilities.isEmptyOrNull(request.getCartInfo().getAction())) {
			errorDetails.add(generateMissingError(CartConstants.ACTION));
		}
		if (request.getData().getLines() == null) {
			errorDetails.add(generateMissingError(CartConstants.LINE_DETAILS));
		} else {
			for (Lines mdLine : request.getData().getLines()) {
				if (StringUtilities.isEmptyOrNull(mdLine.getMtn())) {
					errorDetails.add(generateMissingError(CartConstants.MTN));
				}
				if (mdLine.getManualDiscount() == null) {
					errorDetails.add(generateMissingError(CartConstants.MANUAL_DISCOUNT));
				} else {
					for (ManualDiscount manDisc : mdLine.getManualDiscount()) {
						
						if ("ADD".equalsIgnoreCase(request.getCartInfo().getAction())) {
							if (StringUtilities.isEmptyOrNull(manDisc.getDiscountReasonCode())) {
								errorDetails.add(generateMissingError(CartConstants.DISCOUNT_REASON_CODE));
							}
						}
					}
				}
			}

		}

		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}
	
	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleGuestChoiceRequestErrors(GuestChoiceUIRequest request) {
		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (request.getCartInfo().getIntent() == null) {
			errorDetails.add(CartCxpRequestErrorsUtil.generateMissingError(CartConstants.INTENT));
		} 
		if (request.getCartInfo().getIntendType() == null) {
			errorDetails.add(CartCxpRequestErrorsUtil.generateMissingError(CartConstants.INTENDTYPE));
		}
		if (request.getCartInfo().getProcessStep() == null) {
			errorDetails.add(CartCxpRequestErrorsUtil.generateMissingError(CartConstants.PROCESS_STEP));
		}
		if (request.getCartInfo().getProcessAction() == null) {
			errorDetails.add(CartCxpRequestErrorsUtil.generateMissingError(CartConstants.PROCESS_ACTION));
		}

		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}
	
	/*
	 * @param request
	 * 
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleCheckExistingCartRequestErrors(CheckExistingCartUIRequest request) {
		List<CartErrorDetail> errorDetails = new ArrayList<>();
		if (request.getCartInfo().getIntent() == null) {
			errorDetails.add(CartCxpRequestErrorsUtil.generateMissingError(CartConstants.INTENT));
		}
		if (request.getCartInfo().getIntendType() == null) {
			errorDetails.add(CartCxpRequestErrorsUtil.generateMissingError(CartConstants.INTENDTYPE));
		}
		if (request.getCartInfo().getProcessStep() == null) {
			errorDetails.add(CartCxpRequestErrorsUtil.generateMissingError(CartConstants.PROCESS_STEP));
		}
		if (request.getCartInfo().getProcessAction() == null) {
			errorDetails.add(CartCxpRequestErrorsUtil.generateMissingError(CartConstants.PROCESS_ACTION));
		}
		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleUpdateGiftItemRequestErrors(UpdateGiftItemUIRequest request) {
		List<CartErrorDetail> errorDetails = new ArrayList<>();
		if (ListUtils.emptyIfNull(request.getData().getLines()).isEmpty()) {
			errorDetails.add(generateMissingError(CartConstants.LINE_DETAILS));
		}
		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}


	//VZWYN-17463 changes
	public static ErrorResponse handleAddTrialContactInfoAndAddressRequestErrors(AddTrialContactInfoAndAddressUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (request.getData().getIntent() == null) {
			errorDetails.add(generateMissingError(CartConstants.INTENT));
		}
		if (request.getData().getIntendType() == null) {
			errorDetails.add(generateMissingError(CartConstants.INTENDTYPE));
		}
		if (request.getData().getProcessStep() == null) {
			errorDetails.add(generateMissingError(CartConstants.PROCESS_STEP));
		}
		if (request.getData().getProcessAction() == null) {
			errorDetails.add(generateMissingError(CartConstants.PROCESS_ACTION));
		}
		if (request.getData().getItemType() == null) {
			errorDetails.add(generateMissingError(CartConstants.ITEM_TYPE));
		}

		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	public static ErrorResponse handleCheckExistingCartRequestErrors(AccessoryFinancingOffersUIRequest accessoryFinancingOffersUIRequest) {
List<CartErrorDetail> errorDetails = new ArrayList<>();
		
		if (StringUtilities.isEmptyOrNull(accessoryFinancingOffersUIRequest.getCartInfo().getIntendType())) {
			errorDetails.add(CartCxpRequestErrorsUtil.generateMissingError(CartConstants.INTENDTYPE));
		}
		if (StringUtilities.isEmptyOrNull(accessoryFinancingOffersUIRequest.getCartInfo().getProcessStep())) {
			errorDetails.add(CartCxpRequestErrorsUtil.generateMissingError(CartConstants.PROCESS_STEP));
		}
		if (StringUtilities.isEmptyOrNull(accessoryFinancingOffersUIRequest.getCartInfo().getProcessAction())) {
			errorDetails.add(CartCxpRequestErrorsUtil.generateMissingError(CartConstants.PROCESS_ACTION));
		}
		if (StringUtilities.isEmptyOrNull(accessoryFinancingOffersUIRequest.getCartInfo().getAction())) {
			errorDetails.add(CartCxpRequestErrorsUtil.generateMissingError(CartConstants.ACTION));
		}
		
		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}
	public static ErrorResponse indirectCustRequestErrors(ExCustIndirectRemoveLinesServiceUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();
		
		if (StringUtilities.isEmptyOrNull(request.getContext().getCustomerInfo().getProcessingMTN()) && !request.getContext().getCartInfo().getIntendType().equalsIgnoreCase(CartConstants.NSE)) {
			errorDetails.add(generateMissingError(CartConstants.PROCESSING_MTN));
		}
		if (StringUtilities.isEmptyOrNull(request.getContext().getCustomerInfo().getCartCreator())) {
			errorDetails.add(generateMissingError(CartConstants.CART_CREATOR));
		}
		
		if (StringUtilities.isEmptyOrNull(request.getContext().getCartInfo().getCartId())) {
			errorDetails.add(generateMissingError(CartConstants.CARTID));
		} 
		if (StringUtilities.isEmptyOrNull(request.getContext().getCartInfo().getItemType())) {
			errorDetails.add(generateMissingError(CartConstants.ITEM_TYPE));
		}
		if (StringUtilities.isEmptyOrNull(request.getContext().getCartInfo().getIntendType())) {
			errorDetails.add(generateMissingError(CartConstants.INTENT_TYPE));
		}		
		
		
		if (StringUtilities.isEmptyOrNull(request.getContext().getContextInfo().getProcessStep())) {
			errorDetails.add(generateMissingError(CartConstants.PROCESS_STEP));
		}
		if (StringUtilities.isEmptyOrNull(request.getContext().getContextInfo().getProcessAction())) {
			errorDetails.add(generateMissingError(CartConstants.PROCESS_ACTION));
		}		
		

		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}


	public static ErrorResponse handleEsimDetailsRequestValidation(ESimDetailsETNIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (StringUtilities.isEmptyOrNull(request.getEid())) {
			errorDetails.add(generateMissingError(CartConstants.EID));
		} else if(request.getEid().length() != 32 || onlyDigits(request.getEid()) == Boolean.FALSE){
			String issue = CartConstants.EID + " is invalid. "+CartConstants.EID+" must be numeric and of length 32 digits.";
			String location = CartConstants.REQUEST;
			errorDetails.add(generateInvalidInputError(CartConstants.EID, request.getEid(),issue,location));
		}
		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}
	
	public static ErrorResponse handleWhitelistMtnError() {
		ErrorResponse errors = null;
		CartError error = new CartError();
		error.setNamespace(CartConstants.SOE_CART_SERVICE);
		error.setName(CartConstants.VALIDATION_ERROR);
		error.setId(CartConstants.XBOX_MTN_NOT_WHITELIST_ERROR_ID);
		error.setMessage("MTN is not whitelisted. Xbox cannot be added to cart");
		List<CartError> errorList = new ArrayList<>();
		errorList.add(error);
		errors = new ErrorResponse();
		errors.setErrors(errorList);
		return errors;
	}

	public static List<SOEError> emptyCaptchaErrorresponse() {
		SOEError error = new SOEError();
		error.setNamespace(CartConstants.SOE_CART_SERVICE);
		error.setName(CartConstants.VALIDATION_ERROR);
		error.setId(CartConstants.VALIDATION_ERROR_ID);
		List<SOEError> errorList = new ArrayList<>();
		errorList.add(error);
		return errorList;
	}

	public static List<SOEError> skuNotAvailableInModelMappingErorrResponse() {
		SOEError error = new SOEError();
		error.setNamespace(CartConstants.SOE_CART_SERVICE);
		error.setName(CartConstants.SKU_NOT_AVAILABLE_ERROR);
		error.setId(CartConstants.SKU_NOT_AVAILABLE_ERROR_ID);
		List<SOEError> errorList = new ArrayList<>();
		errorList.add(error);
		return errorList;
	}

	public static ErrorResponse handleCheckExistingCartRequestErrors(AffirmFinancingUIRequest affirmFinancingUIRequest) {
		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (StringUtilities.isEmptyOrNull(affirmFinancingUIRequest.getCartInfo().getIntendType())) {
			errorDetails.add(CartCxpRequestErrorsUtil.generateMissingError(CartConstants.INTENDTYPE));
		}
		if (StringUtilities.isEmptyOrNull(affirmFinancingUIRequest.getCartInfo().getProcessStep())) {
			errorDetails.add(CartCxpRequestErrorsUtil.generateMissingError(CartConstants.PROCESS_STEP));
		}
		if (StringUtilities.isEmptyOrNull(affirmFinancingUIRequest.getCartInfo().getProcessAction())) {
			errorDetails.add(CartCxpRequestErrorsUtil.generateMissingError(CartConstants.PROCESS_ACTION));
		}
		if (StringUtilities.isEmptyOrNull(affirmFinancingUIRequest.getCartInfo().getAction())) {
			errorDetails.add(CartCxpRequestErrorsUtil.generateMissingError(CartConstants.ACTION));
		}

		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	public static ErrorResponse handleAddReplenishmenttoCartRequestErrors(AddReplenishmentToCartUIRequest request) {
		List<CartErrorDetail> errorDetails = new ArrayList<>();
		if (ListUtils.emptyIfNull(request.getData().getLines()).isEmpty()) {
			errorDetails.add(generateMissingError(CartConstants.LINES));
		} else {
			if (request.getData().getLines() != null) {
				int index = 0;
				List<Lines> lines = request.getData().getLines();
				for (Lines line : lines) {
					if (StringUtilities.isNotEmptyOrNull(line.getMtn())) {
						errorDetails = validateMtn(errorDetails, index, line.getMtn());
					}
					if (StringUtilities.isEmptyOrNull(line.getReplenishmentAmount())) {
						errorDetails.add(generateMissingError(CartConstants.REPLENISHMENT_AMOUNT));
					}
					index++;
				}
			}
		}

		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	public static ErrorResponse handleSoeServiceValidationErrors(String methodName,String errorMsg,String field,String value){
		ErrorResponse errResp =  new ErrorResponse();
		List<CartErrorDetail> detailsLst = new ArrayList<>();
		CartErrorDetail errorDetail = generateInvalidInputError(field,value,errorMsg,methodName);
		detailsLst.add(errorDetail);
		List<CartError> soeErrLst = settingCartError(detailsLst,errorMsg);
		errResp.setErrors(soeErrLst);
		return errResp;
	}
	
	public static CartErrorDetail xboxExchangeNotAllowedForRetailError(String inputValue)
	{
		CartErrorDetail detail = new CartErrorDetail();
		detail.setField(inputValue);
		detail.setIssue(inputValue + " not allowed for exchange in retail");
		detail.setLocation(CartConstants.REQUEST);
		detail.setValue("incorrect");

		return detail;
	}

	public static ErrorResponse validateDisconnectEligibilityCheckUiRequest(DisconnectEligibilityCheckUiRequest request) {
		if(request.getMtn()==null || request.getMtn().length<1){
			return handleSoeServiceValidationErrors("isMtnEligibleForDisconnect","mtn  is missing in the request.","mtn","");
		}
		else if(StringUtilities.isEmptyOrNull(request.getLocationCode())){
			return handleSoeServiceValidationErrors("isMtnEligibleForDisconnect","locationCode  is missing in the request.","locationCode",request.getLocationCode());
		}
		else{
			return new ErrorResponse();
		}
	}
	/**
	 *
	 * @param request
	 * @return ErrorResponse
	 */
	public static ErrorResponse handleAddPromoIntentRequestErrors(AddPromoIntentUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();
		if (StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessStep())) {
			errorDetails.add(generateMissingError(CartConstants.PROCESS_STEP));
		}
		return handleValidateMtnError(request.getData().getLines(), errorDetails);
	}
	protected static ErrorResponse handleValidateMtnError(Line[] lines, List<CartErrorDetail> errorDetails) {

		if (lines == null) {
			errorDetails.add(generateMissingError(CartConstants.LINE_DETAILS));
		} else {
			int index = 0;
			for (Line line : lines) {
				if (StringUtilities.isEmptyOrNull(line.getMtn())) {
					errorDetails.add(generateMissingError(CartConstants.MTN));
				} else {
					errorDetails = validateMtn(errorDetails, index, line.getMtn());
				}
				index++;
			}
		}

		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	public static List<SOEError> mobileSecureConnectedSmartWatchError() {
		SOEError error = new SOEError();
		error.setNamespace(CartConstants.SOE_CART_SERVICE);
		error.setName(CartConstants.VALIDATION_ERR);
		error.setId(CartConstants.VALIDATION_ERROR_3993);
		List<SOEError> errorList = new ArrayList<>();
		errorList.add(error);
		return errorList;
	}

	public static List<SOEError> restrictMultiLineFlowError() {
		SOEError error = new SOEError();
		error.setNamespace(CartConstants.SOE_CART_SERVICE);
		error.setName(CartConstants.RESTRICT_MULTILINE);
		error.setId(CartConstants.RESTRICT_MULTILINE_ERROR_ID);
		List<SOEError> errorList = new ArrayList<>();
		errorList.add(error);
		return errorList;
	}

	public static ErrorResponse handleAddUpgradeDetailsRequestErrors(AddDeviceUIRequest request) {

		List<CartErrorDetail> errorDetails = new ArrayList<>();
		String intendType = request.getCartInfo().getIntendType();
		String processAction = request.getCartInfo().getProcessAction();
		Boolean newLineOrByod = false;
		if ((StringUtilities.isEmptyOrNull(request.getCartInfo().getCaseId())
				&& StringUtilities.isEmptyOrNull(request.getCartInfo().getCartId()))
				|| CartConstants.AAL.equalsIgnoreCase(intendType) || CartConstants.BYOD.equalsIgnoreCase(intendType)) {
			newLineOrByod = true;
		}

		if (StringUtilities.isNotEmptyOrNull(processAction) && (!CartConstants.ADD_UPGRADE_DETAILS_PROCESS_ACTION.contains(processAction)) ) {
			errorDetails.add(generateValidationError(processAction));
		} else if (request.getData().getLines() == null) {
			errorDetails.add(generateMissingError(CartConstants.LINE_DETAILS));
		} else {
			errorDetails = updateAddUpgradeDetailsError( errorDetails, request, newLineOrByod, intendType);
		}
		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	public static List<SOEError> emptyDeviceIdErrorResponse() {
		SOEError error = new SOEError();
		error.setNamespace(CartConstants.SOE_CART_SERVICE);
		error.setName(CartConstants.VALIDATION_ERROR);
		error.setId(CartConstants.VALIDATION_ERROR_DEVICE_ID);
		List<SOEError> errorList = new ArrayList<>();
		errorList.add(error);
		return errorList;
	}

	public static ErrorResponse handleAddPayOffDetailsRequestErrors(AddPayOffDetailsUIRequest request) {
		List<CartErrorDetail> errorDetails = new ArrayList<>();

		if (StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessStep())) {
			errorDetails.add(CartCxpRequestErrorsUtil.generateMissingError(CartConstants.PROCESS_STEP));
		}
		if (StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessAction())) {
			errorDetails.add(CartCxpRequestErrorsUtil.generateMissingError(CartConstants.PROCESS_ACTION));
		}

		if (ArrayUtils.isEmpty(request.getData().getLines())) {
			errorDetails.add(generateMissingError(CartConstants.LINES));
		} else {
			if (request.getData().getLines() != null) {
				int index = 0;
				Lines[] lines = request.getData().getLines();
				for (Lines line : lines) {
					if (StringUtilities.isNotEmptyOrNull(line.getMtn())) {
						errorDetails = validateMtn(errorDetails, index, line.getMtn());
					}
					if (line.getPayOffDeviceInfo() == null) {
						errorDetails.add(generateMissingError(CartConstants.PAYOFF_DEVICE_INFO_NODE));
					}
					index++;
				}
			}
		}

		ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
		return errors == null ? new ErrorResponse() : errors;
	}

	private static List<CartErrorDetail> updateAddUpgradeDetailsError(List<CartErrorDetail> errorDetails, AddDeviceUIRequest request, Boolean newLineOrByod, String intendType){
		int index = 1;
		for (Lines line : request.getData().getLines()) {
			errorDetails = validateMtn(errorDetails, index - 1, line.getMtn());
			if(line.getDevice() != null && StringUtilities.isNotEmptyOrNull(request.getChannelId()) &&
					SOEChannels.findByChannelName(request.getChannelId()).getChannelType().equals(CartConstants.DIGITAL_CHANNEL)){
				errorDetails = validateProductId(errorDetails, index - 1, line.getDevice().getProductId());
			}
			if (request.getCartInfo().getProcessStep() != null
					&& !("E911".equalsIgnoreCase(request.getCartInfo().getProcessStep())))
				if (StringUtilities.isEmptyOrNull(request.getCartInfo().getCartId())
						&& StringUtilities.isEmptyOrNull(request.getCartInfo().getCaseId()))
					errorDetails = validateAddDevice(errorDetails, line, intendType, newLineOrByod, index);
				else if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCaseId())
						&& StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCartId()))
					errorDetails = validateAddDevice(errorDetails, line, intendType, newLineOrByod, index);
			index++;
		}
		return errorDetails;
	}
	public static ErrorResponse validateRetrieveDpp(RetrieveDppRequest request) {
		if (null == request.getData()) {
			return handleSoeServiceValidationErrors("retrieveDpp", "Data  is missing in the request.", "data", "");
		}
		if (StringUtilities.isEmptyOrNull(request.getData().getMtn())) {
			return handleSoeServiceValidationErrors("retrieveDpp", "mtn  is missing in the request.", "mtn", "");
		} else {
			return new ErrorResponse();
		}
	}
	public static List<SOEError> pastDueNotAccepted() {
		SOEError error = new SOEError();
		error.setNamespace(CartConstants.SOE_CART_SERVICE);
		error.setName(CartConstants.VALIDATION_ERROR);
		error.setId(CartConstants.VALIDATION_ERROR_PASTDUE_ACCEPTED);
		List<SOEError> errorList = new ArrayList<>();
		errorList.add(error);
		return errorList;
	}
}
