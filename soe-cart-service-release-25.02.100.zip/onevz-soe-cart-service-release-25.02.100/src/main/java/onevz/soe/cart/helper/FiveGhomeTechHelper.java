package onevz.soe.cart.helper;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.model.retrieveCart.CXPItemInfo;
import onevz.soe.cart.model.retrieveCart.CXPLineDetailsVO;
import onevz.soe.cart.model.retrieveCart.CXPLineInfo;
import onevz.soe.cart.model.retrieveCart.CXPOrderDetails;
import onevz.soe.cart.model.retrieveCart.CXPRetrieveCartDataVO;
import onevz.soe.cart.model.retrieveCart.fiveG.CXPDueItemsList;
import onevz.soe.cart.model.retrieveCart.fiveG.CXPDueTaxesList;
import onevz.soe.cart.model.retrieveCart.fiveG.CXPOrderDetailsView;
import onevz.soe.cart.model.reviewOrderInsipico.InspicioResponseItem;
import onevz.soe.cart.model.reviewOrderInsipico.InspicioResponseOrderInfo;
import onevz.soe.cart.model.reviewOrderInsipico.TaxSurchargeGovFeesVO;
import onevz.soe.cart.requests.GetCartDetailsRequest;
import onevz.soe.cart.requests.RetrieveCartCXPRequest;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.responses.GetCartDetailsUIResponse;
import onevz.soe.cart.responses.RetrieveCartRedisData;
import onevz.soe.cart.ui.responses.RetrieveCartUIResponse;
import onevz.soe.cart.util.CartCxpResponseErrorsUtil;
import static onevz.soe.cart.util.CommonUtil.populateCXPOrderDetailsView;
import static onevz.soe.cart.util.CommonUtil.populateDueTodayItems;
import static onevz.soe.cart.util.CommonUtil.populateLineRedisData;
import static onevz.soe.cart.util.CommonUtil.populateOrderDetailsView;
import onevz.soe.utilities.StringUtilities;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
public class FiveGhomeTechHelper {

    @Autowired
    CartServiceCxpHelper cxpHelper;

    @Autowired
    private RedisHelper redisHelper;

    private static final Logger logger = LoggerFactory.getLogger(FiveGhomeTechHelper.class);

    public Mono<ResponseEntity<GenericResponse>> getSwap5GCart(GetCartDetailsRequest request, ServerHttpResponse httpResponse) {

        return redisHelper.getDataFromRedis().flatMap(data -> {
            RetrieveCartCXPRequest cxpRequest = new RetrieveCartCXPRequest();
            cxpRequest.setChannelId(data.getChannelId());
            CXPRetrieveCartDataVO cxpData = new CXPRetrieveCartDataVO();
            if(null != request && null != request.getData() && StringUtilities.isNotEmptyOrNull(request.getData().getCartId())) {
                cxpData.setCartId(request.getData().getCartId());
            } else if(StringUtilities.isNotEmptyOrNull(data.getCartId())) {
                cxpData.setCartId(data.getCartId());
            }
            cxpRequest.setData(cxpData);
            cxpRequest.setMeta(new HashMap<>());
            logger.debug("Calling cxp helper for Swap with cartId {}", data.getCartId());
            return cxpHelper.retrieve5GCart(cxpRequest, false).flatMap(cxpResponse -> {
                ErrorResponse errors2 = null;
                if (cxpResponse.getErrors() != null) {
                    errors2 = CartCxpResponseErrorsUtil.handleRetrieveCartResponseErrors(cxpResponse);
                    if (null != errors2.getErrors() && null != errors2.getErrors().get(0)
                            && null != errors2.getErrors().get(0).getNamespace()
                            && errors2.getErrors().get(0).getNamespace().equalsIgnoreCase(CartConstants.SOE_CART_SERVICE)) {

                        if (null != errors2.getErrors().get(0).getCode()
                                && errors2.getErrors().get(0).getCode().equalsIgnoreCase("400")) {
                            httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
                        }
                    }
                    return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(errors2));
                }
                updateDataToRedis(cxpResponse, request);
                return Mono.just(ResponseEntity.status(HttpStatus.OK).body(transformSwapCXPResponseToSOE(request, cxpResponse)));
            });
        });
    }


    private void updateDataToRedis(RetrieveCartUIResponse cxpResponse, GetCartDetailsRequest request) {

        RetrieveCartRedisData rr = new RetrieveCartRedisData();
        rr.setData(populateLineRedisData(cxpResponse));
        try {
            redisHelper.upsertRetrieveCartDataIntoRedis(rr);
        } catch(Exception e) {
            logger.info("Exception in updating 5g cart response to redis" , e.getMessage());
        }
    }

    public GetCartDetailsUIResponse transformSwapCXPResponseToSOE(GetCartDetailsRequest request, RetrieveCartUIResponse cxpResponse) {
        GetCartDetailsUIResponse response=new GetCartDetailsUIResponse();
        if (null != cxpResponse && null != cxpResponse.getData() && null != cxpResponse.getData().getCart()) {
            if (cxpResponse.getData().getCart().getCartHeader() != null) {
                response.setCartHeader(cxpResponse.getData().getCart().getCartHeader());
            }
            CXPOrderDetailsView orderDetailsView = populateCXPOrderDetailsView(cxpResponse);
            CXPOrderDetails cxpOrderDetails1 = cxpResponse.getData().getCart().getOrderDetails();
            List<CXPDueTaxesList> dueTodayTaxes = new ArrayList<>();
            CXPDueTaxesList todayTaxes = new CXPDueTaxesList();
            todayTaxes.setDueAmount(cxpOrderDetails1.getTotalTaxAmount());
            dueTodayTaxes.add(todayTaxes);
            List<CXPDueItemsList> dueTodayList = new ArrayList<>();
            CXPLineDetailsVO lineDetails = cxpResponse.getData().getCart().getLineDetails();
            CXPLineInfo[] lineInfo = null;
            populateOrderDetailsView(lineDetails, orderDetailsView);
            if (null != lineDetails && null != lineDetails.getLineInfo()) {
                lineInfo = lineDetails.getLineInfo();
                Arrays.stream(lineInfo).filter(Objects::nonNull).forEach(lineInfo1 -> {
                    Arrays.stream(lineInfo1.getItemsInfo()).filter(Objects::nonNull).forEach(itemsInfo -> {
                        Optional.ofNullable(itemsInfo).map(CXPItemInfo::getCartItems).ifPresent(cartItems -> {
                            Arrays.stream(cartItems.getCartItem()).filter(Objects::nonNull).forEach(itemsInfo1 -> {
                                if ("MONTH_TO_MONTH".equalsIgnoreCase(itemsInfo1.getPriceType())
                                        && CartConstants.DEVICE.equalsIgnoreCase(itemsInfo1.getCartItemType()) && StringUtilities.isNotEmptyOrNull(itemsInfo1.getProductId())) {
                                    CXPDueItemsList dueTodayItems = populateDueTodayItems(itemsInfo1);
                                    // install type will be only for DEVICE(Router) item
                                    if (CartConstants.DEVICE.equalsIgnoreCase(itemsInfo1.getCartItemType())
                                            && !CartConstants.HOME_SOLUTIONS.equalsIgnoreCase(lineInfo1.getDeviceTypeSelected())) {
                                        if (null != itemsInfo1.getDepletionType()) {
                                            if ("O".equalsIgnoreCase(itemsInfo1.getDepletionType())) {
                                                dueTodayItems.setInstallationType(CartConstants.PROF_SETUP);
                                            } else if ("F".equalsIgnoreCase(itemsInfo1.getDepletionType()) || "L".equalsIgnoreCase(itemsInfo1.getDepletionType())) {
                                                dueTodayItems.setInstallationType(CartConstants.SELF_SETUP);
                                            }
                                        }
                                        if (StringUtils.isBlank(orderDetailsView.getInstallType())) {
                                            orderDetailsView.setInstallType(dueTodayItems.getInstallationType());
                                        }
                                        dueTodayItems.setMultiLineSeqNumber(lineInfo1.getMultiLineSeqNumber());
                                        // BackOrdering Changes
                                        if (null != itemsInfo1.getInventory()) {
                                            dueTodayItems.setIsBackorder(String.valueOf(itemsInfo1.getInventory().getIsBackorder()));
                                            dueTodayItems.setPreBackDate(itemsInfo1.getPreBackDate() != null ? itemsInfo1.getPreBackDate() : StringUtils.EMPTY);
                                        }
                                    } else if (CartConstants.DEVICE.equalsIgnoreCase(itemsInfo1.getCartItemType()) // populate npanxx for HomePhone
                                            && CartConstants.HOME_SOLUTIONS.equalsIgnoreCase(lineInfo1.getDeviceTypeSelected())) {
                                        if (null != lineInfo1.getMtnDetails()) {
                                            dueTodayItems.setNpaNXX(lineInfo1.getMtnDetails().getNpaNXX());
                                        }
                                        dueTodayItems.setIsHomePhone(true);
                                        dueTodayItems.setMultiLineSeqNumber(lineInfo1.getMultiLineSeqNumber());
                                    }
                                    dueTodayItems.setTaxAmount(String.valueOf(itemsInfo1.getTaxAmount()));
                                    if (CartConstants.DEVICE.equalsIgnoreCase(itemsInfo1.getCartItemType())) {
                                        dueTodayItems.setLineNumber(lineInfo1.getLineNumber());
                                    }
                                    dueTodayList.add(dueTodayItems);
                                }
                            });
                        });
                    });
                });
            }
            if (null != lineDetails && null != lineDetails.getLineInfo()) {
                Arrays.stream(lineDetails.getLineInfo()).filter(Objects::nonNull).findFirst().ifPresent(lineInfo1 -> {
                    if(StringUtils.isNotBlank(lineInfo1.getSecurityDepositAmount()) && !"0".equals(lineInfo1.getSecurityDepositAmount())) {
                        orderDetailsView.setSecurityDeposit(lineInfo1.getSecurityDepositAmount());
                        orderDetailsView.setSecurityDepositNeed(String.valueOf(true));
                    }
                });
            }
            response.setDueTodayList(dueTodayList);
            response.setDueTodayTaxes(dueTodayTaxes);
            response.setOrderDetailsView(orderDetailsView);
        }
        return response;
    }


    public Mono<InspicioResponseOrderInfo> getTechCbandCart5GCart(RetrieveCartCXPRequest request, ServerHttpResponse httpResponse) {
        InspicioResponseOrderInfo response = new InspicioResponseOrderInfo();
        return cxpHelper.retrieve5GValidateCart(request, "AAL_CBD_TECH", false).flatMap(cxpResponse -> {
            TaxSurchargeGovFeesVO taxSurchargeGovFeesVO = new TaxSurchargeGovFeesVO();
            CXPOrderDetails orderDetails = cxpResponse.getData().getValidateCartAndUpdate().getOrderDetails();
            if(null != orderDetails){
                response.setTotalDueToday(String.valueOf(orderDetails.getTotalDueToday()));
                taxSurchargeGovFeesVO.setDueMonthlyAmount("Included for 5G Home Internet.*");
                taxSurchargeGovFeesVO.setDueToday(orderDetails.getTotalTaxAmount());
            }
            if (null != cxpResponse.getData().getValidateCartAndUpdate() && null != cxpResponse.getData().getValidateCartAndUpdate().getLineDetails()) {
                Arrays.stream(cxpResponse.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()).filter(Objects::nonNull).findFirst().ifPresent(lineInfo1 -> {
                    if(null != lineInfo1.getServiceInfo() && null != lineInfo1.getServiceInfo().getPlanDetails() && null != lineInfo1.getServiceInfo().getPlanDetails().getPlanPrice()){
                        response.setTotalDueMonthly((String.valueOf(lineInfo1.getServiceInfo().getPlanDetails().getPlanPrice())));
                    }

                    // apply AutoPay
                    if (null != lineInfo1.getServiceInfo().getSelectedFeaturesList() && lineInfo1.getServiceInfo().getSelectedFeaturesList().getFeaturesCount() > 1) {
                        lineInfo1.getServiceInfo().getSelectedFeaturesList().getVisFeature().stream().filter(Objects::nonNull).filter(visFeature ->
                                "SPO".equalsIgnoreCase(visFeature.getType()) && "L".equalsIgnoreCase(visFeature.getLevel()) &&
                                        visFeature.getCategoryCodes().contains(CartConstants.DISC_PROMO) && visFeature.getCategoryCodes().contains(CartConstants.PAPER_FREE)
                                        && visFeature.getCategoryCodes().contains(CartConstants.AUTOPAY)).findFirst().ifPresent(visFeature -> {
                            response.setTotalDueMonthly((String.valueOf((Double.parseDouble(response.getTotalDueMonthly()) + Double.parseDouble(visFeature.getFeaturePrice())))));
                        });
                    }
                    // apply loyalty discount for plan price other than homepHone plan
                    if (!CartConstants.HOME_SOLUTIONS.equalsIgnoreCase(lineInfo1.getDeviceTypeSelected()) && null != lineInfo1.getServiceInfo().getSelectedFeaturesList() && lineInfo1.getServiceInfo().getSelectedFeaturesList().getFeaturesCount() > 1) {
                        lineInfo1.getServiceInfo().getSelectedFeaturesList().getVisFeature().stream().filter(Objects::nonNull).filter(visFeature -> visFeature.getCategoryCodes() != null).filter(visFeature ->
                                visFeature.getCategoryCodes().stream().anyMatch(str -> str.equalsIgnoreCase(CartConstants.FIVEG_LOYALTY) ||
                                        str.equalsIgnoreCase(CartConstants.LTE_LOYALTY) || str.equalsIgnoreCase(CartConstants.FIVEG_BUNDLE))).forEach(visFeature ->
                                response.setTotalDueMonthly((String.valueOf((Double.parseDouble(response.getTotalDueMonthly()) + Double.parseDouble(visFeature.getFeaturePrice())))))

                        );
                    }
                    //apply ecpd discount
                    if (null != lineInfo1.getServiceInfo() && null != lineInfo1.getServiceInfo().getPlanDetails()
                            && null != lineInfo1.getServiceInfo().getPlanDetails().getPlanPromotions()
                            && null != lineInfo1.getServiceInfo().getPlanDetails().getPlanPromotions().getPromos()
                            && null != cxpResponse.getData().getValidateCartAndUpdate().getEcpdProfile()
                            && lineInfo1.getServiceInfo().getPlanDetails().getPlanPromotions().getPromos().size() > 0) {
                        lineInfo1.getServiceInfo().getPlanDetails().getPlanPromotions().getPromos().stream().filter(planPromos -> null != planPromos && !CartConstants.HUNDRED.equalsIgnoreCase(planPromos.getPercentageOff())).findFirst().ifPresent(planPromos -> {
                            if (null != planPromos.getAmountOff()) {
                                response.setTotalDueMonthly((String.valueOf(Double.parseDouble(response.getTotalDueMonthly()) - Double.parseDouble(planPromos.getAmountOff()))));
                            }
                        });
                    }
                });
            }
            CXPLineDetailsVO lineDetails = cxpResponse.getData().getValidateCartAndUpdate().getLineDetails();
            if(null != lineDetails && null != lineDetails.getLineInfo()){
                Arrays.stream(lineDetails.getLineInfo()).filter(Objects::nonNull).forEach(lineInfo -> {
                    List<InspicioResponseItem> itemList = new ArrayList<>(2);
                    Arrays.stream(lineInfo.getItemsInfo()).filter(Objects::nonNull).forEach(cxpItemInfo -> {
                        if(null != cxpItemInfo && null != cxpItemInfo.getCartItems()) {
                            Arrays.stream(cxpItemInfo.getCartItems().getCartItem()).filter(Objects::nonNull).forEach(cartItem -> {
                                if(CartConstants.DEVICE_TYPE.equalsIgnoreCase(cartItem.getCartItemType())) {
                                    InspicioResponseItem deviceItem = new InspicioResponseItem();
                                    deviceItem.setName(cartItem.getDescription());
                                    deviceItem.setItemType(cartItem.getCartItemType());
                                    deviceItem.setSorId(cartItem.getSorId());
                                    deviceItem.setProductId(cartItem.getProductId());
                                    deviceItem.setShowMonthlyPricing(true);
                                    deviceItem.setShowTodayPricing(true);
                                    deviceItem.setThumbnailImageURL("#THUMBNAIL_IMAGE_URL#");
                                    if (null != cartItem.getDepletionType()) {
                                        if ("O".equalsIgnoreCase(cartItem.getDepletionType())) {
                                            deviceItem.setInstallationType(CartConstants.PROF_SETUP);
                                        } else if ("F".equalsIgnoreCase(cartItem.getDepletionType()) || "L".equalsIgnoreCase(cartItem.getDepletionType())) {
                                            deviceItem.setInstallationType(CartConstants.SELF_SETUP);
                                        }
                                    }
                                    deviceItem.setDisplayDueTodaySection(true);
                                    deviceItem.setDueToday(String.valueOf(cartItem.getDiscountedPrice()));
                                    deviceItem.setDueMonthly("0.0");
                                    itemList.add(deviceItem);
                                }
                            });
                        }
                    });
                    InspicioResponseItem planItem = new InspicioResponseItem();
                    if (null != lineInfo && null != lineInfo.getServiceInfo()) {
                        planItem.setProductId(lineInfo.getServiceInfo().getNewPricePlanId());
                        if (null != lineInfo.getServiceInfo().getNewPricePlanInfo()) {
                            planItem.setName(lineInfo.getServiceInfo().getNewPricePlanInfo().getPricePlanDesc());
                        }
                    }
                    planItem.setItemType("PLAN");
                    planItem.setShowTodayPricing(true);
                    planItem.setShowMonthlyPricing(true);
                    planItem.setShowBroadBandInfo(true);
                    planItem.setDueMonthly(response.getTotalDueMonthly());
                    planItem.setDueToday("0.0");
                    planItem.setDisplayDueMonthlySection(true);
                    planItem.setModalContent("#MODAL_CONTENT#");
                    itemList.add(planItem);
                    response.setItems(itemList);
                });
            }
            response.setShowMonthlyPricing(true);
            taxSurchargeGovFeesVO.setShowTodayAmount(true);
            response.setTaxesSurchargesGovtFees(taxSurchargeGovFeesVO);
            return Mono.just(response);
        });
    }
}
