package onevz.soe.cart.bpm.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.bpm.service.CartServiceBPMServices;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.casemgmt.*;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.commonCart.CommonCartPegaContext;
import onevz.soe.cart.model.commonCart.CommonCartPegaServiceBody;
import onevz.soe.cart.model.commonCart.CommonCartPegaServiceRequest;
import onevz.soe.cart.model.createCartAndLine.CreateCartAndLineContext;
import onevz.soe.cart.model.createCartAndLine.CreateCartAndLineServiceBody;
import onevz.soe.cart.model.createCartAndLine.CreateCartAndLineServiceRequest;
import onevz.soe.cart.model.createCase2.*;
import onevz.soe.cart.requests.CommonCartPEGARequest;
import onevz.soe.cart.requests.CreateCartAndLinePEGARequest;
import onevz.soe.cart.requests.CreateCaseUIRequest;
import onevz.soe.cart.requests.ResumeCaseBPMRequest;
import onevz.soe.cart.responses.CommonCartPEGAResponse;
import onevz.soe.cart.responses.CreateCartAndLinePEGAResponse;
import onevz.soe.cart.responses.CreateCaseUIResponse;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.CommonCartUIRequest;
import onevz.soe.cart.ui.requests.ResumeCaseUIRequest;
import onevz.soe.cart.ui.responses.CartAndLineUIResponse;
import onevz.soe.cart.ui.responses.CommonCartUIResponse;
import onevz.soe.cart.ui.responses.ResumeCaseUIResponse;
import onevz.soe.cart.util.CartPegaRequestUtil;
import onevz.soe.exception.ErrorType;
import onevz.soe.exception.SOEException;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.bpm.model.response.Error;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import reactor.core.publisher.Mono;

import java.util.Arrays;
import java.util.UUID;


@Service
public class CartAndLineBpmHelper {

    private static final Logger logger = LoggerFactory.getLogger(CartAndLineBpmHelper.class);

    @Autowired
    private CartServiceBPMServices services;

    @Autowired
    ObjectMapper objectMapper;

    public Mono<CartAndLineUIResponse> createCartAndLine(CommonCartUIRequest request , String clientId){

        CreateCartAndLinePEGARequest pegaRequest = new CreateCartAndLinePEGARequest();

        CartServiceServiceHeader serviceHeader = getCartServiceServiceHeader(clientId);
        CreateCartAndLineServiceBody pegaServiceBody = getCreateCartAndLineServiceBody(request);

        pegaRequest.setServiceBody(pegaServiceBody);
        pegaRequest.setServiceHeader(serviceHeader);

        Mono<CreateCartAndLinePEGAResponse> responseMono = null;
        try {
            String pegaStrReq = objectMapper.writeValueAsString(pegaRequest);
            logger.info("PEGA request for createCartAndLine request is: {} ", pegaStrReq);
             responseMono = services.createCartAndLine(pegaRequest);
        } catch (SOEHTTPException | JsonProcessingException e) {
            logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG,e);
        }

        return  responseMono == null ? getDefaultErrorResponseForCreateLine() : responseMono.onErrorResume(error ->{
            logger.error("error returned by pega call for createCartAndLine",error);
            return Mono.error(error);
        }).flatMap(response -> {
            logger.info(CartConstants.PEGA_RESPONSE_RECEIVED_MESSAGE+ response);
            CartAndLineUIResponse uiResponse = new CartAndLineUIResponse();
            uiResponse.setServiceHeader(response.getServiceHeader());
            uiResponse.setServiceBody(response.getServiceBody());
            uiResponse.setErrors(response.getErrors());
            return Mono.just(uiResponse);
        });
    }

    public Mono<CommonCartUIResponse> buildLine(CommonCartUIRequest request, String clientId) {

        CommonCartPEGARequest pegaRequest = new CommonCartPEGARequest();

        CartServiceServiceHeader serviceHeader = getCartServiceServiceHeader(clientId);
        CommonCartPegaServiceBody serviceBody = getCommonCartPegaServiceBody(request, CartConstants.BUILD_LINE);

        if (CartConstants.PLAN_BUILDER.equals(request.getCartInfo().getFlowType())) {
            serviceBody.getBuildServiceRequest().getContext().getBuildContextInfo().setProcessStep(CartConstants.SHOPPING_CART);
        }

        pegaRequest.setServiceHeader(serviceHeader);
        pegaRequest.setServiceBody(serviceBody);

        Mono<CommonCartPEGAResponse> responseMono = null;
        try {
            logger.info("PEGA request for buildLine request is: {} ", objectMapper.writeValueAsString(pegaRequest));
            responseMono = services.buildLine(pegaRequest);
        } catch (SOEHTTPException | JsonProcessingException e) {
            logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG,e);
        }

        return responseMono == null ? getDefaultErrorResponseForBuildLine() : responseMono.onErrorResume(error -> {
            logger.error("error returned by pega call for BuildLine", error);
            return Mono.error(error);
        }).flatMap(response -> {
            logger.info(CartConstants.PEGA_RESPONSE_RECEIVED_MESSAGE+ response);
            CommonCartUIResponse uiResponse = new CommonCartUIResponse();
            uiResponse.setServiceHeader(response.getServiceHeader());
            uiResponse.setServiceBody(response.getServiceBody());
            uiResponse.setErrors(response.getErrors());
            return Mono.just(uiResponse);
        });
    }


    public Mono<CommonCartUIResponse> deleteCart(CommonCartUIRequest request, String clientId) {

        CommonCartPEGARequest pegaRequest = new CommonCartPEGARequest();

        CartServiceServiceHeader serviceHeader = getCartServiceServiceHeader(clientId);
        CommonCartPegaServiceBody serviceBody = getCommonCartPegaServiceBody(request, CartConstants.CANCEL);

        if (CartConstants.PLAN_BUILDER.equals(request.getCartInfo().getFlowType())) {
            serviceBody.getBuildServiceRequest().getContext().getBuildContextInfo().setProcessStep(CartConstants.EXIT_PAGE);
            serviceBody.getBuildServiceRequest().getContext().getBuildContextInfo().setIntent(CartConstants.NSE);
        }

        pegaRequest.setServiceHeader(serviceHeader);
        pegaRequest.setServiceBody(serviceBody);

        pegaRequest.setServiceBody(serviceBody);

        Mono<CommonCartPEGAResponse> responseMono = null;

        try {
            logger.info("PEGA request for deleteCart request is: {} ", objectMapper.writeValueAsString(pegaRequest));
            responseMono = services.deleteCart(pegaRequest);
        } catch (SOEHTTPException | JsonProcessingException e) {
            logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG,e);
        }

        return responseMono == null ? getDefaultErrorResponseForBuildLine() : responseMono.onErrorResume(error -> {
            logger.error("error returned by pega call for deleteCart", error);
            return Mono.error(error);
        }).flatMap(response -> {
            logger.info(CartConstants.PEGA_RESPONSE_RECEIVED_MESSAGE+ response);
            CommonCartUIResponse uiResponse = new CommonCartUIResponse();
            uiResponse.setServiceHeader(response.getServiceHeader());
            uiResponse.setServiceBody(response.getServiceBody());
            uiResponse.setErrors(response.getErrors());
            return Mono.just(uiResponse);
        });
    }

    private CartServiceContextInfo getCartServiceContextInfoForCreateCartAndLine(CommonCartUIRequest request) {
        CartServiceContextInfo contextInfo = new CartServiceContextInfo();

        if(CartConstants.PLAN_BUILDER.equals(request.getCartInfo().getFlowType())){
            CartPegaRequestUtil.addContextInfo(contextInfo , CartConstants.CREATE_CART_AND_LINE, request.getCartInfo().getClientAppName());
            if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntent())){
                contextInfo.setIntent(request.getCartInfo().getIntent());
            }
            contextInfo.setProcessStep(
                    StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessStep()) ? CartConstants.LINESELECTION : request.getCartInfo().getProcessStep());

        }
        return contextInfo;
    }

    private CartServiceServiceHeader getCartServiceServiceHeader(String clientId) {
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader);
        if(StringUtilities.isEmptyOrNull(clientId)){
            serviceHeader.setClientId(CartConstants.RETAIL_IPAD);
        }else{
            serviceHeader.setClientId(clientId);
        }
        return serviceHeader;
    }

    private CreateCartAndLineServiceBody getCreateCartAndLineServiceBody(CommonCartUIRequest request) {

        CreateCartAndLineServiceBody pegaServiceBody = new CreateCartAndLineServiceBody();
        CreateCartAndLineServiceRequest pegaServiceRequest = new CreateCartAndLineServiceRequest();
        CreateCartAndLineContext serviceContext = new CreateCartAndLineContext();

        CartServiceContextInfo contextInfo = getCartServiceContextInfoForCreateCartAndLine(request);
        CartServiceCartInfo serviceCartInfo = buildPegaCartInfo(request);
        CartServiceCustomerInfo serviceCustomerInfo = buildPegaCustomerInfo(request);

        if(CartConstants.LINESELECTION.equalsIgnoreCase(request.getCartInfo().getProcessStep())) {
            String uuid = UUID.randomUUID().toString();
            serviceCustomerInfo.setCartCreator(uuid);
            serviceCustomerInfo.setGlobalId(uuid);
        }

        serviceContext.setCaseId(request.getCartInfo().getCaseId());
        serviceContext.setCartInfo(serviceCartInfo);
        serviceContext.setCustomerInfo(serviceCustomerInfo);
        serviceContext.setContextInfo(contextInfo);

        pegaServiceRequest.setContext(serviceContext);
        pegaServiceBody.setServiceRequest(pegaServiceRequest);

        return pegaServiceBody;
    }

    private CartServiceCustomerInfo buildPegaCustomerInfo(CommonCartUIRequest request) {
        CartServiceCustomerInfo serviceCustomerInfo = new CartServiceCustomerInfo();
        serviceCustomerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        serviceCustomerInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());
        if(null != request.getCartInfo().getRegisterNumber())
            serviceCustomerInfo.setRegisterNumber(request.getCartInfo().getRegisterNumber());
        serviceCustomerInfo.setCartCreator(request.getCartInfo().getCartCreator());
        serviceCustomerInfo.setGlobalId(request.getCartInfo().getGlobalId());
        serviceCustomerInfo.setFlowType(StringUtilities.isEmptyOrNull(request.getCartInfo().getFlowType())? CartConstants.PLAN_BUILDER : request.getCartInfo().getFlowType());
        serviceCustomerInfo.setMtnFlow(StringUtilities.isEmptyOrNull(request.getCartInfo().getMtnFlow())? CartConstants.P : request.getCartInfo().getMtnFlow());
        serviceCustomerInfo.setAccountType(request.getCartInfo().getAccountType());
        serviceCustomerInfo.setCartCreatorOrderLocationCode(request.getCartInfo().getCartCreatorOrderLocationCode());
        serviceCustomerInfo.setCartCreatorSalesRepId(request.getCartInfo().getCartCreatorSalesRepId());
        serviceCustomerInfo.setSalesRepUswin(request.getCartInfo().getSalesRepUswin());
        serviceCustomerInfo.setQuoteWithoutCredit(request.getCartInfo().getQuoteWithoutCredit());
        serviceCustomerInfo.setCustomerType(request.getCartInfo().getCustomerType());

        return serviceCustomerInfo;
    }

    private CartServiceCartInfo buildPegaCartInfo(CommonCartUIRequest request) {

        CartServiceCartInfo serviceCartInfo = new CartServiceCartInfo();
        serviceCartInfo.setCartId(request.getCartInfo().getCartId());
        serviceCartInfo.setIntendType(
                StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType()) ? CartConstants.NSE : request.getCartInfo().getIntendType());
        serviceCartInfo.setItemType(
                StringUtilities.isEmptyOrNull(request.getCartInfo().getItemType()) ? "": request.getCartInfo().getItemType());

        serviceCartInfo.setZipCode(
                StringUtilities.isEmptyOrNull(request.getCartInfo().getZipCode()) ? "":request.getCartInfo().getZipCode());

        if(!ObjectUtils.isEmpty(request.getData().getLines())){
            Line[] lineArray = new Line[request.getData().getLines().length];
            int i=0;
           for( Lines lines: request.getData().getLines()){
               Line line = new Line();
               line.setMtn(lines.getMtn());
               line.setCustomerProvidedMtn(lines.getCustomerProvidedMtn());
               line.setAccountOwner(lines.getAccountOwner());
               line.setStandAlone(lines.getStandAlone());
               line.setLineWithSkipMDN(true);
               line.setInWithVerizonOpted(lines.isInWithVerizonOpted());
               line.setNewLineOrAAL(lines.getNewLineOrAAL());
               line.setAddAccessories(lines.getAddAccessories());
               line.setRemoveAccessories(lines.getRemoveAccessories());
               line.setAddFeatures(lines.getAddFeatures());
               line.setRemoveFeatures(lines.getRemoveFeatures());
               line.setDeviceTypeSelected(lines.getDeviceTypeSelected());
               line.setIspuFlow(lines.getIspuFlow());
               line.setPlan(lines.getPlan());
               line.setAmount(lines.getAmount());
               line.setDevice(lines.getDevice());
               line.setCurrentPlanType(lines.getCurrentPlanType());
               line.setLineActivityType(lines.getLineActivityType());

               lineArray[i] = line;
               i++;
           }
            serviceCartInfo.setLines(lineArray);
        }
        return serviceCartInfo;
    }


    private Mono<CartAndLineUIResponse> getDefaultErrorResponseForCreateLine(){

        Error error = createError(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG,
                CartConstants.SOE_CART_SERVICE_NAME,
                CartConstants.ERRCAT_CJCM,
                CartConstants.API_ERROR);

        CartAndLineUIResponse uiDefaultErroResponse = new CartAndLineUIResponse();
        uiDefaultErroResponse.setErrors(Arrays.asList(error));

        return Mono.just(uiDefaultErroResponse);
    }

    private Error createError(String message, String namespace, String errorCategory, String errorType){
        Error error = new Error();
        error.setMessage(message);
        error.setNamespace(namespace);
        error.setErrorCategory(errorCategory);
        error.setName(errorType);
        return error;
    }
    
    private Mono<CommonCartUIResponse> getDefaultErrorResponseForBuildLine(){

        Error error = createError(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG,
                CartConstants.SOE_CART_SERVICE_NAME,
                CartConstants.ERRCAT_CJCM,
                CartConstants.API_ERROR);

        CommonCartUIResponse uiDefaultErroResponse = new CommonCartUIResponse();
        uiDefaultErroResponse.setErrors(Arrays.asList(error));

        return Mono.just(uiDefaultErroResponse);
    }

    private CommonCartPegaServiceBody getCommonCartPegaServiceBody(CommonCartUIRequest request, String operationType) {

        CommonCartPegaServiceBody serviceBody = new CommonCartPegaServiceBody();
        CommonCartPegaServiceRequest serviceRequest = new CommonCartPegaServiceRequest();
        CommonCartPegaContext context = new CommonCartPegaContext();

        CartServiceCustomerInfo customerInfo = buildPegaCustomerInfo(request);
        CartServiceCartInfo cartInfo = buildPegaCartInfo(request);
        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        CartPegaRequestUtil.addContextInfo(contextInfo, operationType, "");

        context.setCaseId(request.getCartInfo().getCaseId());
        context.setCustomerInfo(customerInfo);
        context.setBuildCartInfo(cartInfo);
        context.setBuildContextInfo(contextInfo);

        serviceRequest.setContext(context);
        serviceBody.setBuildServiceRequest(serviceRequest);

        return serviceBody;

    }

    public Mono<ResumeCaseUIResponse> resumeCase(ResumeCaseUIRequest request, String clientId){

        CartServiceServiceHeader serviceHeader = getCartServiceServiceHeader(clientId);
        CaseMgmtCustomerInfo customerInfo = populateResumeCaseCustomerInfo(request);
        CaseMgmtCartInfo cartInfo = populateResumeCaseCartInfo(request);

        CartServiceContextInfo serviceContextInfo = new CartServiceContextInfo();
        CartPegaRequestUtil.addContextInfo(serviceContextInfo, CartConstants.RESUME_CASE, "");
        CaseMgmtContextInfo contextInfo = getCaseMgmtContextInfo(serviceContextInfo);

        CaseMgmtContext context = new CaseMgmtContext();
        context.setCaseId(request.getCartInfo().getCaseId());
        context.setCartInfo(cartInfo);
        context.setCustomerInfo(customerInfo);
        context.setContextInfo(contextInfo);

        CaseMgmtServiceRequest serviceRequest = new CaseMgmtServiceRequest();
        serviceRequest.setContext(context);

        CaseMgmtServiceBody serviceBody = new CaseMgmtServiceBody();
        serviceBody.setServiceRequest(serviceRequest);

        ResumeCaseBPMRequest pegaRequest = new ResumeCaseBPMRequest();
        pegaRequest.setServiceBody(serviceBody);
        pegaRequest.setServiceHeader(serviceHeader);
        try{
            logger.info("PEGA request for resumeCase request is: {} ", objectMapper.writeValueAsString(pegaRequest));
            return services.resumeCase(pegaRequest).onErrorResume(Mono::error).flatMap(pegaResponse -> {
                logger.info("PEGA response for resumeCase request is: {} ", pegaResponse);
                ResumeCaseUIResponse  response = new ResumeCaseUIResponse();
                response.setServiceBody(pegaResponse.getServiceBody());
                response.setServiceHeader(pegaResponse.getServiceHeader());
                response.setErrors(null);
                return Mono.just(response);
            });
        }catch(JsonProcessingException exception){
            ResumeCaseUIResponse  response = new ResumeCaseUIResponse();
            response.setErrors(Arrays.asList(createError(CartConstants.JSON_PRCSSNG_EXCPTN_STRNG, CartConstants.SOE_CART_SERVICE_NAME, CartConstants.ERRCAT_APP,CartConstants.API_ERROR)));
            return Mono.just(response);
        }catch(SOEException exception){
            ResumeCaseUIResponse  response = new ResumeCaseUIResponse();
            response.setErrors(Arrays.asList(createError(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, CartConstants.SOE_CART_SERVICE_NAME,CartConstants.ERRCAT_CJCM,CartConstants.API_ERROR)));
            return Mono.just(response);
        }
    }

    private CaseMgmtContextInfo getCaseMgmtContextInfo(CartServiceContextInfo serviceContextInfo) {
        CaseMgmtContextInfo contextInfo = new CaseMgmtContextInfo();
        contextInfo.setCallReason(serviceContextInfo.getCallReason());
        contextInfo.setProcessStep(serviceContextInfo.getProcessStep());
        contextInfo.setProcessAction(serviceContextInfo.getProcessAction());
        contextInfo.setAction(serviceContextInfo.getAction());
        contextInfo.setIntent(serviceContextInfo.getIntent());
        return contextInfo;
    }

    private CaseMgmtCartInfo populateResumeCaseCartInfo(ResumeCaseUIRequest request) {
        CaseMgmtCartInfo cartInfo = new CaseMgmtCartInfo();
        cartInfo.setCartId(request.getCartInfo().getCartId());
        cartInfo.setAction(request.getCartInfo().getAction());
        cartInfo.setItemType(request.getCartInfo().getItemType());
        cartInfo.setIntendType(request.getCartInfo().getIntendType());
        cartInfo.setZipCode(request.getCartInfo().getZipCode());
        cartInfo.setSalesRepUswin(request.getCartInfo().getSalesRepUswin());
        cartInfo.setSalesRepId(request.getCartInfo().getSalesRepId());
        cartInfo.setClientAppName(request.getCartInfo().getClientAppName());
        cartInfo.setOrderLocationCode(request.getCartInfo().getLocationCode());
        cartInfo.setProspectCartId(request.getCartInfo().getProspectCartId());
        cartInfo.setQuoteId(request.getCartInfo().getQuoteId());
        if(null != request.getCartInfo().getRegisterNumber()){
            cartInfo.setRegisterNumber(request.getCartInfo().getRegisterNumber());
        }
        return cartInfo;
    }

    private CaseMgmtCustomerInfo populateResumeCaseCustomerInfo(ResumeCaseUIRequest request) {
        CaseMgmtCustomerInfo customerInfo = new CaseMgmtCustomerInfo();
        customerInfo.setChatId(request.getCartInfo().getChatId());
        customerInfo.setCustomerType(request.getCartInfo().getCustomerType());
        customerInfo.setEmailId(request.getCartInfo().getEmailId());
        customerInfo.setGlobalId(request.getCartInfo().getGlobalId());
        customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
        customerInfo.setFlowType(request.getCartInfo().getFlowType());
        customerInfo.setMtnFlow(request.getCartInfo().getMtnFlow());
        customerInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());
        customerInfo.setCartCreatorOrderLocationCode(request.getCartInfo().getCartCreatorOrderLocationCode());
        customerInfo.setSalesRepUswin(request.getCartInfo().getSalesRepUswin());
        customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        if(null != request.getCartInfo().getQuoteWithoutCredit()) customerInfo.setQuoteWithoutCredit(request.getCartInfo().getQuoteWithoutCredit());

        //from data
        if(null != request.getData().getNoc()) customerInfo.setNoc(request.getData().getNoc());
        if(null != request.getData().getStandAloneTradein()) customerInfo.setStandAloneTradein(request.getData().getStandAloneTradein());
        if(null != request.getData().getSkipMissedProfileEmailValidation()) customerInfo.setSkipMissedProfileEmailValidation(request.getData().getSkipMissedProfileEmailValidation());
        if(null != request.getData().getOriginalCreditApprovalNumber()) customerInfo.setOriginalCreditApprovalNumber(request.getData().getOriginalCreditApprovalNumber());
        if(null != request.getData().getErtrep()) customerInfo.setERTRep(request.getData().getErtrep());
        return customerInfo;
    }

    public Mono<CreateCaseUIResponse> createCase(CreateCaseUIRequest request, String clientId){
        CreateCaseNewCustomerPEGARequest pegaRequest = new CreateCaseNewCustomerPEGARequest();
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(clientId);
        pegaRequest.setServiceHeader(serviceHeader);

        CreateCaseNewCustomerContext context = new CreateCaseNewCustomerContext();
        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.CREATE_CASE, "");
        context.setContextInfo(contextInfo);
        context.setCustomerInfo(populateCreateCaseCustomerInfo(request));
        context.setCartInfo(populateCreateCaseCartInfo(request));
        context.setCaseId("");

        CreateCaseNewCustomerServiceRequest serviceRequest = new CreateCaseNewCustomerServiceRequest();
        serviceRequest.setContext(context);

        CreateCaseNewCustomerServiceBody serviceBody = new CreateCaseNewCustomerServiceBody();
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);
        pegaRequest.setServiceHeader(serviceHeader);
        try {
            String reqStr = objectMapper.writeValueAsString(pegaRequest);
            logger.info("PEGA request: {}",reqStr);
            return services.createCasePlanBuilder(pegaRequest).flatMap(pegaResponse -> {
                CreateCaseUIResponse response = new CreateCaseUIResponse();
                response.setServiceHeader(pegaResponse.getServiceHeader());
                response.setServiceBody(pegaResponse.getServiceBody());
                response.setErrors(null);
                return Mono.just(response);
            });
        } catch (SOEHTTPException | JsonProcessingException e) {
            logger.error("Error occured while calling CJCM createCase", e);
            CreateCaseUIResponse response = new CreateCaseUIResponse();
            response.setErrors(Arrays.asList(createError("Error occured",CartConstants.SOE_CART_SERVICE, CartConstants.ERRCAT_CJCM, ErrorType.API_ERROR.name())));
            return Mono.just(response);
        }

    }

    private CreateCaseNewServiceCustomerInfo populateCreateCaseCustomerInfo(CreateCaseUIRequest request) {
        CreateCaseNewServiceCustomerInfo customerInfo = new CreateCaseNewServiceCustomerInfo();
        customerInfo.setChatId(request.getCartInfo().getChatId());
        customerInfo.setCustomerType(request.getCartInfo().getCustomerType());
        customerInfo.setEmailId(request.getCartInfo().getEmailId());
        customerInfo.setGlobalId(request.getCartInfo().getGlobalId());
        customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
        customerInfo.setFlowType(request.getCartInfo().getFlowType());
        customerInfo.setMtnFlow(request.getCartInfo().getMtnFlow());
        customerInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());
        customerInfo.setCartCreatorOrderLocationCode(request.getCartInfo().getCartCreatorOrderLocationCode());
        customerInfo.setCartCreatorSalesRepId(request.getCartInfo().getCartCreatorSalesRepId());
        customerInfo.setSalesRepUswin(request.getCartInfo().getSalesRepUswin());
        customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        customerInfo.setBucketAllocator(request.getCartInfo().getBucketAllocator());
        customerInfo.setIsEQPandPPLOfferApplied(request.getCartInfo().getIsEQPandPPLOfferApplied());
        if(null != request.getCartInfo().getQuoteWithoutCredit()) customerInfo.setQuoteWithoutCredit(request.getCartInfo().getQuoteWithoutCredit());

        //from data
        customerInfo.setThrottleName(request.getData().getThrottleName());
        customerInfo.setAni(request.getData().getAni());
        customerInfo.setRepRole(request.getData().getRepRole());
        customerInfo.setCancelQuoteCases((null != request.getData().getCancelQuoteCases()) ? request.getData().getCancelQuoteCases(): false);
        customerInfo.setIsERTRep((null != request.getData().getIsERTRep()) ? request.getData().getIsERTRep() : false);
        if(null != request.getData().getFromMyvPage()) customerInfo.setFromMyvPage(request.getData().getFromMyvPage());
        if(null != request.getCartInfo().getRegisterNumber()){
            customerInfo.setRegisterNumber(request.getCartInfo().getRegisterNumber());
        }
        return customerInfo;
    }

    private CartServiceCartInfo populateCreateCaseCartInfo(CreateCaseUIRequest request) {
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(request.getCartInfo().getCartId());
        cartInfo.setAction(request.getCartInfo().getAction());
        cartInfo.setItemType(request.getCartInfo().getItemType());
        cartInfo.setIntendType(request.getCartInfo().getIntendType());
        cartInfo.setZipCode(request.getCartInfo().getZipCode());
        cartInfo.setSalesRepId(request.getCartInfo().getSalesRepId());
        cartInfo.setClientAppName(request.getCartInfo().getClientAppName());
        cartInfo.setOrderLocationCode(request.getCartInfo().getLocationCode());
        cartInfo.setProspectCartId(request.getCartInfo().getProspectCartId());
        cartInfo.setQuoteId(request.getCartInfo().getQuoteId());
        if(null != request.getCartInfo().getRegisterNumber()){
            cartInfo.setRegisterNumber(request.getCartInfo().getRegisterNumber());
        }

        if(!ObjectUtils.isEmpty(request.getData().getLines())){
            Line[] lineArray = new Line[request.getData().getLines().length];
            int i=0;
            for( Lines lines: request.getData().getLines()){
                Line line = new Line();
                line.setMtn(lines.getMtn());
                line.setCustomerProvidedMtn(lines.getCustomerProvidedMtn());
                line.setAccountOwner(lines.getAccountOwner());
                line.setStandAlone(lines.getStandAlone());
                line.setLineWithSkipMDN(true);
                line.setInWithVerizonOpted(lines.isInWithVerizonOpted());
                line.setNewLineOrAAL(lines.getNewLineOrAAL());
                line.setAddAccessories(lines.getAddAccessories());
                line.setRemoveAccessories(lines.getRemoveAccessories());
                line.setAddFeatures(lines.getAddFeatures());
                line.setRemoveFeatures(lines.getRemoveFeatures());
                line.setDeviceTypeSelected(lines.getDeviceTypeSelected());
                line.setIspuFlow(lines.getIspuFlow());
                line.setPlan(lines.getPlan());
                line.setAmount(lines.getAmount());
                line.setDevice(lines.getDevice());
                line.setCurrentPlanType(lines.getCurrentPlanType());
                line.setLineActivityType(lines.getLineActivityType());

                lineArray[i] = line;
                i++;
            }
            cartInfo.setLines(lineArray);
        }
        return cartInfo;
    }

}
