package onevz.soe.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.common.DeviceUpgradeData;
import onevz.soe.cart.model.common.SecondNumber;
import onevz.soe.cart.model.createLine.CreateLineContext;
import onevz.soe.cart.model.deviceSimValidation.DeviceSimValidationUIResponseData;
import onevz.soe.cart.model.initiateCbandCheck.InitiateCbandCheckResponseData;
import onevz.soe.cart.model.initiateESimActivation.InitiateESimActivationUIResponse;
import onevz.soe.cart.model.retrieveCart.CXPCartVO;
import onevz.soe.cart.model.retrieveCart.CXPLineDetailsVO;
import onevz.soe.cart.model.retrieveCart.CXPLineInfo;
import onevz.soe.cart.model.validateCart.CXPValidateCartDataVO;
import onevz.soe.cart.requests.DeviceExchangeRequest;
import onevz.soe.cart.requests.MvoRequest;
import onevz.soe.cart.requests.ValidateCartCXPRequest;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.ui.requests.AddDeviceUIRequest;
import onevz.soe.cart.ui.requests.AddPlanUIRequest;
import onevz.soe.cart.ui.requests.CreateLineUIRequest;
import onevz.soe.cart.ui.responses.InitiateCheckoutUIResponse;
import onevz.soe.cart.ui.responses.ValidateCartUIResponse;
import onevz.soe.cradle.client.SOECradleDatastoreClient;
import onevz.soe.customerprofile.model.gql.assisted.PerkDetail;
import onevz.soe.customerprofile.model.gql.assisted.PerkDetailInfo;
import onevz.soe.customerprofile.model.gql.assisted.PerkSPOInfo;
import onevz.soe.fraud.client.SOEMtnExpireClient;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.session.client.model.AccountInfoEligible;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

@Service
public class RedisHelper2 {

    @Autowired
    SOELoginSessionBean sessionBean;
    @Autowired
    private ObjectMapper mapper;

    @Autowired
    RedisHelper redisHelper;

    @Autowired
    private SOECradleDatastoreClient soeCradleDatastoreClient;


    @Autowired
    SOEMtnExpireClient soeMtnExpireClient;

    @Value("${soe.gatekeeper.fwaRedisKeys:false}")
    private boolean fwaRedisKeysEnabled;

    private static final Logger logger = LoggerFactory.getLogger(RedisHelper2.class);

    public static final String ERROR_PARSING_JSON_TO_OBJECT = "Error parsing JSON to Object: {}";
    public static final String READING_RESTRICTED_PRODUCT_TYPE_REQUEST = "Reading restricted product type request:";
    public static final String UNABLE_TO_DELETE_FROM_REDIS = " Unable to delete from Redis {}";
    public static final String ACCOUNT_INFO_ELIGIBLE = "accountInfoEligible";

    public static final String DUAL_NUMBER = "dualNumber";

    public static final String DEVICE_UPGRADE_DETAILS = "deviceUpgradeDetails";

    /**
     *
     * @param request
     * @return Boolean
     */
    public Mono<Boolean> upsertFiveGAddressIntoRedis(FiveGAddressRedisData request) {
        return sessionBean.setSessionData(CartConstants.FIVEG_ADDRESS, request);
    }

    /**
     *
     * @param cartCount
     * @return boolean
     */
    public Mono<Boolean> updateDeviceCartCount(String cartCount, Boolean updateDeviceCount) {
        Map<String, String> requestMap = new HashMap<>();
        requestMap.put(CartConstants.CART_COUNT, cartCount);
        if(updateDeviceCount)
        {
            requestMap.put(CartConstants.DEVICE_COUNT, cartCount);
        }

        return sessionBean.setSessionData(requestMap);
    }
    public Mono<Boolean>updateBByOrderDetails(AddDeviceUIRequest request,CartRedisData data) {
        Map<String, String> requestMap = new HashMap<>();

        if (null!=data && null != data.getLocationSubType() &&("GN".equalsIgnoreCase(data.getLocationSubType()))
                &&null != data.getMaid() && ("BBX".equalsIgnoreCase(data.getMaid()))){
            requestMap.put(CartConstants.LOCATION_CODE, StringUtilities.isNotEmptyOrNull(request.getCartInfo().getOrderLocation())?request.getCartInfo().getOrderLocation():"");
            requestMap.put(CartConstants.MASTER_AGENT_IDS,StringUtilities.isNotEmptyOrNull(request.getCartInfo().getMasterAgentId())?request.getCartInfo().getMasterAgentId():"");
            requestMap.put(CartConstants.UPC,StringUtilities.isNotEmptyOrNull(request.getData().getLines().get(0).getDevice().getUpc())?request.getData().getLines().get(0).getDevice().getUpc():"");
            requestMap.put(CartConstants.PRICE_ID,StringUtilities.isNotEmptyOrNull(request.getData().getLines().get(0).getDevice().getPriceId())?request.getData().getLines().get(0).getDevice().getPriceId():"");
            requestMap.put(CartConstants.OUTLET_ID,StringUtilities.isNotEmptyOrNull(request.getCartInfo().getOutletId())?request.getCartInfo().getOutletId():"");

        }
        return sessionBean.setSessionData(requestMap);
    }

    /**
     *
     * @param flowType
     * @return boolean
     */
    public Mono<Boolean> updateCartOrderFlowType(String flowType) {
        Map<String, String> requestMap = new HashMap<>();
        if (StringUtilities.isNotEmptyOrNull(flowType)) {
            requestMap.put(CartConstants.CART_ORDER_FLOW_TYPE, flowType);
            return sessionBean.setSessionData(requestMap).switchIfEmpty(Mono.defer(()-> {
                // CXTDT-579391
                return Mono.just(false);
            }));
        } else {
            return Mono.just(false);
        }
    }


    /**
     *
     * @return String
     */
    public Mono<String> getCartOrderFlowType() {
        return sessionBean.getSessionData(CartConstants.CART_ORDER_FLOW_TYPE, String.class).onErrorReturn("")
                .defaultIfEmpty("").flatMap(data -> {
                    logger.info(String.format("Reading CartOrderFlowType: %s " , data));
                    return Mono.just(data);
                });
    }

    /**
     *
     * @param deviceId
     * @return boolean
     */
    public Mono<Boolean> updateDeviceId(String deviceId) {
        Map<String, String> requestMap = new HashMap<>();
        requestMap.put(CartConstants.DEVICEID, deviceId);
        return sessionBean.setSessionData(requestMap);
    }

    /**
     *
     * @return String
     */
    public Mono<String> getDeviceId() {
        return sessionBean.getSessionData(CartConstants.DEVICEID, String.class).onErrorReturn("").defaultIfEmpty("")
                .flatMap(data -> {
                    logger.info(String.format("Reading deviceId: %s " , data));
                    return Mono.just(data);
                });
    }

    /**
     *
     * @param simId
     * @return boolean
     */
    public Mono<Boolean> updateSimId(String simId) {
        Map<String, String> requestMap = new HashMap<>();
        requestMap.put(CartConstants.SIMID, simId);
        return sessionBean.setSessionData(requestMap);
    }

    /**
     *
     * @return String
     */
    public Mono<String> getSimId() {
        return sessionBean.getSessionData(CartConstants.SIMID, String.class).onErrorReturn("").defaultIfEmpty("")
                .flatMap(data -> {
                    logger.info(String.format("Reading SimId: %s " , data));
                    return Mono.just(data);
                });
    }

    /**
     *
     * @return String
     */
    public Mono<String> getLoggedInUser() {
        return sessionBean.getSessionData(CartConstants.LOGGEDINUSER, String.class).onErrorReturn("").defaultIfEmpty("")
                .flatMap(data -> {
                    logger.info(String.format("Reading loggedInUser: %s" , data));
                    return Mono.just(data);
                });
    }
    public Mono<String> getLVSoftsku(){
        return sessionBean.getSessionData("LVSoftsku", String.class).onErrorReturn("").defaultIfEmpty("")
                .flatMap(data ->{
                    logger.info(String.format("Reading LVSoftsku: %s", data));
                    return Mono.just(data);
                });
    }
    /**
     *
     * @return String
     */
    public Mono<String> getRole() {
        return sessionBean.getSessionData(CartConstants.VZW_ROLES, String.class).onErrorReturn("").defaultIfEmpty("")
                .flatMap(data -> {
                    logger.info(READING_RESTRICTED_PRODUCT_TYPE_REQUEST + " " + data);
                    return Mono.just(data);
                });
    }

    /**
     * @param count
     * @return boolean
     */
    public Mono<Boolean> updateLinelevelDigitalSecureSubscriptionCountintoRedis(int count) {
        return sessionBean
                .setSessionData(CartConstants.LINELEVEL_DIGITALSECURE_SUBSCRIPTION_COUNT, String.valueOf(count))
                .doOnError(onError -> {
                    logger.error(" Unable to line level Digita Secure subscription COunt value into Redis {}",onError);
                }).doOnSuccess(onSuccess -> {
                    logger.info(" Updated lineleveldigitalSecure subscription count successfully into Redis");
                }).onErrorReturn(Boolean.FALSE).defaultIfEmpty(Boolean.TRUE).flatMap(response -> {
                    return Mono.just(true);
                });
    }

    /**
     *
     * @param chatId
     * @return boolean
     */
    public Mono<Boolean> updateChatId(String chatId) {
        Map<String, String> requestMap = new HashMap<>();
        requestMap.put(CartConstants.CHAT_ID_FIELD, chatId);
        return sessionBean.setSessionData(requestMap);
    }

    /**
     *
     * @param accountInfoEligible
     * @param cartId
     * @param caseId
     * @return data
     */
    public Mono<Boolean> upsertAccountInfoEligibleInRedis(AccountInfoEligible accountInfoEligible, String cartId,
                                                          String caseId) {

        Map<String, String> requestMap = new HashMap<>();
        String requestString = "";
        try {
            requestString = mapper.writeValueAsString(accountInfoEligible);
        } catch (JsonProcessingException e) {
            logger.error("upsertAccountInfoEligibleInRedis- Exception: {}", e);
        }
        requestMap.put(CartConstants.CART_ID, cartId);
        requestMap.put(CartConstants.CASE_ID, caseId);
        requestMap.put(ACCOUNT_INFO_ELIGIBLE, requestString);
        return sessionBean.setSessionData(requestMap).flatMap(data -> {
            return Mono.just(data);
        });

    }

    /**
     *
     * @param request
     * @return rr
     */
    public Mono<CartRedisData> upsertAddDeviceDataIntoRedis(CartRedisData request) {

        Map<String, String> requestMap = new HashMap<>();

        requestMap.put(CartConstants.CART_ID, request.getCartId());
        requestMap.put(CartConstants.PROCESSING_MTN, request.getProcessingMTN());
        requestMap.put(CartConstants.INTEND_TYPE, request.getIntendType());
        requestMap.put(CartConstants.INTENT_TYPE, request.getIntendType());
        requestMap.put(CartConstants.CASE_ID, request.getCaseId());
        requestMap.put(CartConstants.IS_APPLEDEVICE, String.valueOf(request.getIsAppleDevice()));
        if(StringUtilities.isNotEmptyOrNull(request.getDeviceType())) {
            requestMap.put(CartConstants.DEVICETYPE_BBP, request.getDeviceType());
        }
        if (StringUtils.isNotBlank(request.getRpsIntent()))
            requestMap.put(CartConstants.RPS_INTENT, request.getRpsIntent());
        return sessionBean.setSessionData(requestMap).flatMap(data -> {
            return Mono.just(request);
        });

    }

    /**
     *
     * @param request
     * @return rr
     */
    public Mono<Boolean> upsertRPSFlowDataIntoRedis(RPSFlowRedisData request) {
        Map<String, String> requestMap = new HashMap<>();

        requestMap.put(CartConstants.RPS_FLOW_PAIRING_MODE, request.getRpsFlowPairingMode());
        requestMap.put(CartConstants.RPS_FLOW_IMEI, request.getRpsFlowIMEI());
        requestMap.put(CartConstants.RPS_FLOW_PHONE_MTN, request.getRpsFlowPhoneMtn());

        return sessionBean.setSessionData(requestMap).flatMap(data -> {
            return Mono.just(data);
        });
    }

    /**
     *
     * @return data
     */
    public Mono<RTDRedisData> getRTDOfferDataFromRedis() {

        return sessionBean
                .getSessionData(Arrays.asList(
                        new String[] { CartConstants.CART_ID, CartConstants.INTEND_TYPE, CartConstants.RTD_KEY }))
                .onErrorReturn(new HashMap<Object, Object>()).defaultIfEmpty(new HashMap<Object, Object>())
                .flatMap(data -> {
                    RTDRedisData rtdData = new RTDRedisData();
                    logger.info("Reading RTD_JSON");
                    if (data.containsKey(CartConstants.RTD_KEY)
                            && StringUtilities.isNotEmptyOrNull((String) data.get(CartConstants.RTD_KEY))) {

                        String stringData = (String) data.get(CartConstants.RTD_KEY);
                        try {
                            rtdData = mapper.readValue(stringData, RTDRedisData.class);
                        } catch (JsonProcessingException e) {
                            logger.error(ERROR_PARSING_JSON_TO_OBJECT, e);
                        }
                    }
                    if (data.containsKey(CartConstants.CART_ID))
                        rtdData.setCartId((String) data.get(CartConstants.CART_ID));
                    if (data.containsKey(CartConstants.INTEND_TYPE))
                        rtdData.setIntendType((String) data.get(CartConstants.INTEND_TYPE));
                    return Mono.just(rtdData);
                });
    }

    /**
     *
     * @param request
     * @return Boolean
     */
    public Mono<Boolean> upsertRTDRedisDataIntoRedis(RTDRedisData request) {
        return sessionBean.setSessionData(CartConstants.RTD_KEY, request);
    }


    public Mono<Boolean> updatePromoFirstOfferData(MyOfferETRRedisData myOfferETRRedisData) {
        return sessionBean.setSessionData(CartConstants.PROMO_FIRST_OFFER, myOfferETRRedisData).
                doOnError(onError -> {
                    logger.error(String.format(CartConstants.REDIS_KEY_FAIL_LOG , CartConstants.PROMO_FIRST_OFFER));
                }).doOnSuccess(onSuccess -> {
            logger.info(String.format(CartConstants.REDIS_KEY_UPDATE_LOG , CartConstants.PROMO_FIRST_OFFER));
        }).onErrorReturn(Boolean.FALSE).defaultIfEmpty(Boolean.TRUE).flatMap(data -> {
            logger.info("Response: {}" , data);
            return Mono.just(data);
        });
    }
    /**
     *
     * @param request
     * @return Boolean
     */
    public Mono<Boolean> upsertRemoveOfferDataIntoRedis(RemoveOfferRedisData request) {
        return sessionBean.setSessionData(CartConstants.REMOVEOFFERREDISDATA, request).
                doOnError(onError -> {
                    logger.error(String.format(CartConstants.REDIS_KEY_FAIL_LOG,  CartConstants.REMOVEOFFERREDISDATA));
                }).doOnSuccess(onSuccess -> {
            logger.info(String.format(CartConstants.REDIS_KEY_UPDATE_LOG, CartConstants.REMOVEOFFERREDISDATA));
        }).onErrorReturn(Boolean.FALSE).defaultIfEmpty(Boolean.TRUE).flatMap(data -> {
            logger.info("Response: {}" , data);
            return Mono.just(data);
        });
    }

    /**
     *
     * @return data
     */
    public Mono<RemoveOfferRedisData> getRemoveOfferDataIntoRedis() {
        return sessionBean.getSessionData(CartConstants.REMOVEOFFERREDISDATA, RemoveOfferRedisData.class)
                .onErrorReturn(new RemoveOfferRedisData()).defaultIfEmpty(new RemoveOfferRedisData()).flatMap(data -> {
                    logger.info("REMOVE OFFER Request Read from Redis {}",data);
                    return Mono.just(data);
                });
    }


    /**
     *
     * @param requestKey
     * @return long
     */
    public Mono<Long> deleteRemoveOfferDataFromRedis(String requestKey) {
        List<String> keys = new ArrayList<>();
        keys.add(requestKey);
        return sessionBean.deleteSessionData(keys).doOnError(onError -> {
            logger.error(UNABLE_TO_DELETE_FROM_REDIS, onError);
        }).doOnSuccess(onSuccess -> {
            logger.info(" deleted Redis key " + CartConstants.REMOVEOFFERREDISDATA);
        });
    }

    /**
     *
     * @param key
     * @param val
     * @return boolean
     */
    public Mono<Boolean> upsertValueInRedis(String key, String val) {
        Map requestMap = new HashMap<String, String>();
        requestMap.put(key, val);
        return sessionBean.setSessionData(requestMap).doOnError(onError -> {
            logger.error(String.format(CartConstants.REDIS_KEY_FAIL_LOG, key));
        }).doOnSuccess(onSuccess -> {
            logger.info(String.format(CartConstants.REDIS_KEY_UPDATE_LOG, key));
        }).onErrorReturn(Boolean.FALSE).defaultIfEmpty(Boolean.TRUE);
    }

    /**
     *
     * @param request
     * @return boolean
     */
    public Mono<Boolean> upsertEdgeBuyoutDataIntoRedis(String mtn, CartRedisData request) {
        Map<String, CartRedisData> requestMap = new HashMap<>();
        requestMap.put(mtn, request);
        return sessionBean.setSessionData(CartConstants.EDGE_BUYOUT_KEY, requestMap).doOnError(onError -> {
            logger.error(String.format(CartConstants.REDIS_KEY_FAIL_LOG, CartConstants.EDGE_BUYOUT_KEY));
        }).doOnSuccess(onSuccess -> {
            logger.info(String.format(CartConstants.REDIS_KEY_UPDATE_LOG, CartConstants.EDGE_BUYOUT_KEY));
        }).onErrorReturn(Boolean.FALSE).defaultIfEmpty(Boolean.TRUE);
    }

    /**
     *
     * @return long
     */
    public Mono<Long> deleteEdgeBuyoutDataFromRedis() {
        List<String> keys = new ArrayList<>();
        keys.add(CartConstants.EDGE_BUYOUT_KEY);
        return sessionBean.deleteSessionData(keys).doOnError(onError -> {
            logger.error(UNABLE_TO_DELETE_FROM_REDIS, onError);
        });
    }

    /**
     *
     * @return data
     */
    public Mono<HashMap> getEdgeBuyoutRedisData() {
        return sessionBean.getSessionData(CartConstants.EDGE_BUYOUT_KEY, HashMap.class).onErrorReturn(new HashMap<>())
                .defaultIfEmpty(new HashMap<>()).flatMap(data -> {
                    logger.info("EdgeBuyout Request Read from Redis");
                    return Mono.just(data);
                });
    }

    /**
     *
     * Upsert BVO offer data into redis.
     * @param request
     * @return the boolean
     */
    public Mono<Boolean> upsertBVPTradeInOFferIntoRedis(BVPRedisData request) {

        return sessionBean.setSessionData(CartConstants.DEVICE_BEST_VALUE_OFFER_DATA, request);

    }

    /**
     * Upsert BBP flow data into redis.
     *
     * @param request the request
     * @return the mono
     */
    public Mono<Boolean> upsertBBPFlowDataIntoRedis(BBPFlowRedisData request) {
        Map<String, String> requestMap = new HashMap();
        Map<String, Boolean> reqMap = new HashMap();

        String isSmartPhone = String.valueOf(request.getIsSmartphone());
        String isEsimDevice = String.valueOf(request.getIsEsimDevice());

        requestMap.put(CartConstants.BBP_ICCID, request.getBbpiccid());
        requestMap.put(CartConstants.BBP_IMEI, request.getBbpimei());
        requestMap.put(CartConstants.IS_SMARTPHONE,isSmartPhone);
        requestMap.put(CartConstants.BBP_IMEI2, request.getBbpimei2());
        requestMap.put(CartConstants.IS_ESIMDEVICE, isEsimDevice);
        requestMap.put(CartConstants.DEVID, request.getDevid());
        requestMap.put(CartConstants.EID, request.getEid());

        return sessionBean.setSessionData(requestMap).flatMap(data -> {
            return Mono.just(data);
        });


    }

    /**
     *
     * @param request
     * @return upsertInitiateEsimActivation
     */
    public Mono<Boolean> upsertInitiateESimActivation (InitiateESimActivationUIResponse request) {
        Map<String, String> requestMap = new HashMap<>();
        if (null != request && null != request.getData()) {
            requestMap.put(CartConstants.ESIMTYPE, request.getEsimType());
            if (StringUtilities.isNotEmptyOrNull(request.getData().getEid())) {
                requestMap.put(CartConstants.EID, request.getData().getEid());
                logger.info("upsertInitiateEsimActivation()- eid stored {}", request.getData().getEid());
            }
            if (StringUtilities.isNotEmptyOrNull(request.getData().getDeviceId())) {
                requestMap.put(CartConstants.BBP_IMEI, request.getData().getDeviceId());
                requestMap.put(CartConstants.IMEI, request.getData().getDeviceId());
                logger.info("upsertInitiateEsimActivation()- imei stored {}", request.getData().getDeviceId());
            }
            if (StringUtilities.isNotEmptyOrNull(request.getData().getIccId())) {
                requestMap.put(CartConstants.PENDING_ICCID, request.getData().getIccId());
                logger.info("upsertInitiateEsimActivation()- iccid stored {}", request.getData().getIccId());
            }
        }
        logger.info("upsertInitiateEsimActivation()-full requestMap for redis: {}", requestMap);
        return sessionBean.setSessionData(requestMap).flatMap(data -> {
            return Mono.just(data);
        }).doOnSuccess(data -> {
            logger.info("Data insertion in redis is :{}", data);
        }).doOnError(onError->{
            logger.info("Error occured due to :{}", onError);
        });
    }
    /**
     * Upsert BBP flow zip code data into redis.
     *
     * @param request the request
     * @return the mono
     */
    public Mono<Boolean> upsertBBPFlowZipCodeDataIntoRedis(AddZipcodeRedisData request) {
        Map<String, String> requestMap = new HashMap<>();

        requestMap.put(CartConstants.BBP_ZIPCODE, request.getZipCode());
        return	sessionBean.setSessionData(requestMap).flatMap(data -> {
            return Mono.just(data);
        });
    }

    /**
     *
     * @param channelId
     * @param response
     * @return boolean
     */
    public Mono<Boolean> upsertOrderEligibilityInRedis(String channelId, ValidateCartUIResponse response) {
        return redisHelper.isDigitalHomeFlow().flatMap(isFIveGFlow -> {
            if(isFIveGFlow) {
                //TODO need to calculate accountElibile based on redis getAccountInfoEligible VO
                final Boolean checkIfAnyLineIsEupOrByod = checkIfAnyLinesAreEUPOrBYOD(response);
                logger.info("checkIfAnyLineIsEupOrByod - {} ", checkIfAnyLineIsEupOrByod);
                String accountInfoValidate = fwaRedisKeysEnabled ? "fwaAccountInfoValidate": "accountInfoValidate";
                return !checkIfAnyLineIsEupOrByod ? sessionBean.setSessionData(accountInfoValidate, Boolean.TRUE) : sessionBean.setSessionData(accountInfoValidate, Boolean.FALSE);
            } else {
                return Mono.just(Boolean.FALSE);
            }
        });
    }

    /**
     *
     * @param response
     * @return boolean
     */
    public Mono<Boolean> inFlightOrderCheck(ValidateCartUIResponse response) {
        return redisHelper.isDigitalHomeFlow().flatMap(isFiveGFlow -> {
            if(isFiveGFlow) {
                String inflighOrderKey = fwaRedisKeysEnabled? CartConstants.FWA_IN_FLIGHT_ORDER: CartConstants.IN_FLIGHT_ORDER;
                String fullAccountNumber = response.getData().getValidateCartAndUpdate().getCartHeader().getFullAccountNumber();
                final List<String> eupLines = pullUpgradeLinesFromResponse(response);
                AtomicBoolean isFlightOrder = new AtomicBoolean(Boolean.FALSE);
                if(CollectionUtils.isEmpty(eupLines)) {
                    return upsertValueInRedis(inflighOrderKey, isFlightOrder.toString());
                }
                return soeMtnExpireClient.multiReadSessionValues(fullAccountNumber, eupLines).flatMap(upgLines -> {
                    if(upgLines.stream().anyMatch(Objects::nonNull)) {
                        isFlightOrder.set(Boolean.TRUE);
                    }
                    return upsertValueInRedis(inflighOrderKey, isFlightOrder.toString());
                }).switchIfEmpty(Mono.just(Boolean.FALSE)).flatMap(value ->{
                    return upsertValueInRedis(inflighOrderKey, isFlightOrder.toString());
                });

            }
            return  Mono.just(Boolean.FALSE);
        });

    }

    private List<String> pullUpgradeLinesFromResponse(ValidateCartUIResponse response) {
        Optional<CXPLineInfo[]> cxpLineInfos = Optional.ofNullable(response.getData()).map(CXPValidateCartDataVO::getValidateCartAndUpdate)
                .map(CXPCartVO::getLineDetails).filter(Objects::nonNull).map(CXPLineDetailsVO::getLineInfo).filter(ArrayUtils::isNotEmpty);
        if(cxpLineInfos.isPresent()) {
            List<String> upgradeLines = Arrays.stream(cxpLineInfos.get()).filter(lineInfo -> lineInfo.getLineActivityType().equalsIgnoreCase("EUP"))
                    .map(CXPLineInfo::getLineNumber).collect(Collectors.toList());
            return  CollectionUtils.isNotEmpty(upgradeLines) ? upgradeLines : null;
        }
        return null;
    }

    /**
     *
     * @param respObj
     * @return boolean
     */
    public Boolean checkIfAnyLinesAreEUPOrBYOD(ValidateCartUIResponse respObj) {
        final Optional<Boolean> isEupOrByod = Optional.ofNullable(respObj.getData()).map(CXPValidateCartDataVO::getValidateCartAndUpdate)
                .map(CXPCartVO::getLineDetails).filter(Objects::nonNull).map(CXPLineDetailsVO::getLineInfo).filter(ArrayUtils::isNotEmpty).map(lineInfos -> Arrays.stream(lineInfos).anyMatch(lineInfo ->
                        "EUP".equalsIgnoreCase(lineInfo.getLineActivityType()) ||
                                "BYOD".equalsIgnoreCase(lineInfo.getLineActivityType())));
        if(isEupOrByod.isPresent() && isEupOrByod.get().equals(false)){
            return isEupOrByod.get();
        }
        return Boolean.FALSE;
    }

    /**
     *
     * @param accountInfoEligible
     * @return boolean
     */
    public Mono<Boolean> upsertAccountInfoEligibleInRedis(AccountInfoEligible accountInfoEligible) {

        Map<String, String> requestMap = new HashMap<>();
        String requestString = "";
        try {
            requestString = mapper.writeValueAsString(accountInfoEligible);
        } catch (JsonProcessingException e) {
            logger.error("upsertAccountInfoEligibleInRedis- Exception: {}", e);
        }
        requestMap.put(CartConstants.ACCOUNT_INFO_ELIGIBLE, requestString);
        return sessionBean.setSessionData(requestMap).flatMap(data -> {
            return Mono.just(data);
        });

    }

    /**
     *
     * @return Mono<RPSFlowRedisData>
     */
    public Mono<RPSFlowRedisData> getRPSDataFromRedis() {

        return sessionBean
                .getSessionData(Arrays.asList(
                        new String[] { CartConstants.RPS_FLOW_PAIRING_MODE, CartConstants.RPS_FLOW_PHONE_MTN, CartConstants.RPS_FLOW_IMEI }))
                .onErrorReturn(new HashMap<Object, Object>()).defaultIfEmpty(new HashMap<Object, Object>())
                .flatMap(data -> {
                    RPSFlowRedisData rpsData = new RPSFlowRedisData();
                    logger.info("Reading RPS_JSON");

                    if (data.containsKey(CartConstants.RPS_FLOW_PAIRING_MODE))
                        rpsData.setRpsFlowPairingMode((String) data.get(CartConstants.RPS_FLOW_PAIRING_MODE));
                    if (data.containsKey(CartConstants.RPS_FLOW_PHONE_MTN))
                        rpsData.setRpsFlowPhoneMtn((String) data.get(CartConstants.RPS_FLOW_PHONE_MTN));
                    if (data.containsKey(CartConstants.RPS_FLOW_IMEI))
                        rpsData.setRpsFlowIMEI((String) data.get(CartConstants.RPS_FLOW_IMEI));
                    return Mono.just(rpsData);
                });
    }


    /**
     *
     * @param request
     * @return Boolean
     */
    public Mono<Boolean> upsertMvoDataIntoRedis(MvoRequest request) {
        return sessionBean.setSessionData("mvoData", request);
    }
    /**
     *
     * @return mono
     */
    public Mono<AccountInfoEligible> getAccountInfoEligibleFlagFromRedis() {
        return sessionBean.getSessionData(CartConstants.ACCOUNT_INFO_ELIGIBLE, AccountInfoEligible.class)
                .onErrorReturn(new AccountInfoEligible()).defaultIfEmpty(new AccountInfoEligible()).flatMap(data -> {
                    logger.info("Reading getAccountInfoEligibleFlagFromRedis");
                    return Mono.just(data);
                });

    }

    /**
     * Upsert BBP data into redis for Device Sim Validation.
     *
     * @param request the request
     * @return the mono
     */
    public Mono<Boolean> upsertDeviceSimValidationDataIntoRedis(DeviceSimValidationUIResponseData request) {
        Map<String, String> requestMap = new HashMap<>();

        String isSmartPhone = String.valueOf(request.getIsSmartphone());
        String isEsimDevice = String.valueOf(request.getIsEsimDevice());
        String isSDKDevice = String.valueOf(request.getIsSDKDevice());
        String IsValidationSuccess = String.valueOf(request.getIsValidationSuccess());


        if (StringUtilities.isNotEmptyOrNull(request.getIccid())) {
            requestMap.put(CartConstants.BBP_ICCID, request.getIccid());
            logger.info("upsert()- iccid stored {}", request.getIccid());
        }
        if (StringUtilities.isNotEmptyOrNull(request.getImei())) {
            requestMap.put(CartConstants.BBP_IMEI, request.getImei());
            logger.info("upsert() - imei stored {}", request.getImei());
        }
        if (StringUtilities.isNotEmptyOrNull(isSmartPhone)) {
            requestMap.put(CartConstants.IS_SMARTPHONE, isSmartPhone);
        }
        if (StringUtilities.isNotEmptyOrNull(request.getImei2())) {
            requestMap.put(CartConstants.BBP_IMEI2, request.getImei2());
        }

        if(StringUtilities.isNotEmptyOrNull(isEsimDevice)) {
            requestMap.put(CartConstants.IS_ESIMDEVICE, isEsimDevice);
        }
        if(StringUtilities.isNotEmptyOrNull(request.getFlowType())) {
            requestMap.put(CartConstants.BBP_FLOWTYPE, request.getFlowType());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getBbpDefaultZipcodeForTabletFlow())) {
            requestMap.put(CartConstants.BBP_DEFAULT_ZIPCODE_FOR_TABLETFLOW, request.getBbpDefaultZipcodeForTabletFlow());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getFirstName())) {
            requestMap.put(CartConstants.BBP_SDKDEVICE_FIRSTNAME, request.getFirstName());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getLastName())) {
            requestMap.put(CartConstants.BBP_SDKDEVICE_LASTNAME, request.getLastName());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getPhoneNumber())) {
            requestMap.put(CartConstants.BBP_SDKDEVICE_PHONENUMBER, request.getPhoneNumber());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getEmail())) {
            requestMap.put(CartConstants.BBP_SDKDEVICE_EMAIL, request.getEmail());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getZipcode())) {
            requestMap.put(CartConstants.BBP_SDKDEVICE_ZIPCODE, request.getZipcode());
        }
        if(StringUtilities.isNotEmptyOrNull(IsValidationSuccess)) {
            requestMap.put(CartConstants.BBP_DEVICESIMVALIDATION_FLAG, IsValidationSuccess);
        }
        if(StringUtilities.isNotEmptyOrNull(isSDKDevice)) {
            requestMap.put(CartConstants.IS_SDKDEVICE, isSDKDevice);
        }
        if(StringUtilities.isNotEmptyOrNull(request.getESimType())) {
            requestMap.put(CartConstants.ESIMTYPE, request.getESimType());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getEsimFlowType())) {
            requestMap.put(CartConstants.ESIMFLOWTYPE, request.getEsimFlowType());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getPendingMdn())) {
            requestMap.put(CartConstants.PENDING_MDN, request.getPendingMdn());
        }
        logger.info("upsert()-full requestMap for redis {}", requestMap);
        return sessionBean.setSessionData(requestMap).flatMap(data -> {
            return Mono.just(data);
        });


    }

    //VZWCS-17115 changes
    /**
     *
     * @param request
     * @return boolean
     */
    public Mono<Boolean> upsertInitiateCbandCheckDataIntoRedis(InitiateCbandCheckResponseData request) {
        Map<String, String> requestMap = new HashMap<>();

        if (StringUtilities.isNotEmptyOrNull(request.getVmasBootUpInfo().getDeviceReachable())) {
            requestMap.put(CartConstants.DEVICE_REACHABLE, request.getVmasBootUpInfo().getDeviceReachable());
        }
        if (StringUtilities.isNotEmptyOrNull(request.getVmasBootUpInfo().getMtn())) {
            requestMap.put(CartConstants.CASE_MTN, request.getVmasBootUpInfo().getMtn());
        }
        if (StringUtilities.isNotEmptyOrNull(request.getVmasBootUpInfo().getSnr5G())) {
            requestMap.put(CartConstants.SNR_5G, request.getVmasBootUpInfo().getSnr5G());
        }
        if (StringUtilities.isNotEmptyOrNull(request.getVmasBootUpInfo().getNetworkType())) {
            requestMap.put(CartConstants.NETWORK_TYPE, request.getVmasBootUpInfo().getNetworkType());
        }
        if (StringUtilities.isNotEmptyOrNull(request.getVmasBootUpInfo().getSetupReason())) {
            requestMap.put(CartConstants.SETUP_REASON, request.getVmasBootUpInfo().getSetupReason());
        }
        if (StringUtilities.isNotEmptyOrNull(request.getVmasBootUpInfo().getPostMount5GSignal())) {
            requestMap.put(CartConstants.POST_MOUNT_5G_SIGNAL, request.getVmasBootUpInfo().getPostMount5GSignal());
        }
        if (StringUtilities.isNotEmptyOrNull(request.getCustomerId())) {
            requestMap.put(CartConstants.CUSTOMER_ID, request.getCustomerId());
        }
        if (StringUtilities.isNotEmptyOrNull(request.getBillAccountNo())) {
            requestMap.put(CartConstants.BILL_ACCOUNT_NO, request.getBillAccountNo());
        }

        logger.info("upsertInitiateCbandCheckData()-requestMap for redis {}", requestMap);
        return sessionBean.setSessionData(requestMap).flatMap(data -> {
            return Mono.just(data);
        }).doOnSuccess(data -> {
            logger.info("Data insertion in redis is :{}", data);
        });

    }

    /**
     *
     * @param count
     * @return Boolean
     */
    public Mono<Boolean> upsertCreditCheckFailureCountIntoRedis(int count, InitiateCheckoutUIResponse response) {
        Map requestMap = new HashMap<String, String>();
        if(count > 0) {
            requestMap.put(CartConstants.CREDIT_CHECK_FAILURE_COUNTER, String.valueOf(count));
            if (count >= 5)
                requestMap.put(CartConstants.CREDIT_CHECK_FAILURE_RESPONSE, response);
            return sessionBean.setSessionData(requestMap);
        } else {
            return Mono.just(false);
        }
    }

    /**
     *
     * @param request
     * @param rpsFlowRedisData
     * @return cartRedisData
     */
    public Mono<CartRedisData> upsertAddDeviceDataIntoRedis(CartRedisData request, RPSFlowRedisData rpsFlowRedisData) {

        Map<String, String> requestMap = new HashMap<>();

        requestMap.put(CartConstants.CART_ID, request.getCartId());
        requestMap.put(CartConstants.PROCESSING_MTN, request.getProcessingMTN());
        requestMap.put(CartConstants.INTEND_TYPE, request.getIntendType());
        requestMap.put(CartConstants.INTENT_TYPE, request.getIntendType());
        requestMap.put(CartConstants.CASE_ID, request.getCaseId());
        requestMap.put(CartConstants.IS_APPLEDEVICE, String.valueOf(request.getIsAppleDevice()));

        requestMap.put(CartConstants.RPS_FLOW_PAIRING_MODE, rpsFlowRedisData.getRpsFlowPairingMode());
        requestMap.put(CartConstants.RPS_FLOW_IMEI, rpsFlowRedisData.getRpsFlowIMEI());
        requestMap.put(CartConstants.RPS_USER_FLOW, rpsFlowRedisData.getRpsUserFlow());
        requestMap.put(CartConstants.RPS_OS_TYPE, rpsFlowRedisData.getRpsOsType());
        requestMap.put(CartConstants.RPS_DEVICE_MFG, rpsFlowRedisData.getRpsDeviceMfg());

        if (StringUtils.isNotBlank(request.getRpsIntent()))
            requestMap.put(CartConstants.RPS_INTENT, request.getRpsIntent());
        return sessionBean.setSessionData(requestMap).flatMap(data -> {
            return Mono.just(request);
        });

    }

    /**
     *
     * @param rpsRedisData
     * @return boolean
     */
    public Mono<Boolean> upsertRPSFlowDataIntoRedis(RPSRedisData rpsRedisData) {
        Map<String, String> requestMap = new HashMap<>();
        String requestString = "";
        try {
            requestString = mapper.writeValueAsString(rpsRedisData);
        } catch (JsonProcessingException e) {
            logger.error("upsertRPSFlowDataIntoRedis Exception: {}", e);
        }
        requestMap.put("rpsRedisData", requestString);
        return sessionBean.setSessionData(requestMap).flatMap(data -> {
            return Mono.just(data);
        });
    }

    /**
     *
     * @return CartRedisData
     */
    public Mono<RPSRedisData> getRPSDataFromRedisAsString() {
        return sessionBean.getSessionData("rpsRedisData", RPSRedisData.class)
                .onErrorReturn(new RPSRedisData()).defaultIfEmpty(new RPSRedisData()).flatMap(data -> {
                    logger.info("Reading RPS Redis Data request");
                    return Mono.just(data);
                });
    }

    /**
     *
     * @return QuotePricingRedisData
     */
    public Mono<QuotePricingRedisData> getQuotePricingRedisData() {
        return sessionBean.getSessionData(CartConstants.QUOTE_PRICING, QuotePricingRedisData.class)
                .onErrorReturn(new QuotePricingRedisData()).defaultIfEmpty(new QuotePricingRedisData())
                .flatMap(data -> {
                    logger.info("Reading Quote Pricing Values");
                    return Mono.just(data);
                });
    }

    /**
     *
     * Quote Price value data into redis.
     *
     * @param request
     * @return the boolean
     */
    public Mono<Boolean> upsertQuotePriceIntoRedis(QuotePricingRedisData request) {

        return sessionBean.setSessionData(CartConstants.QUOTE_PRICING, request);

    }

    /**
     *
     * @return data
     */
    public Mono<String> getCartIdFromRedis() {
        return sessionBean.getSessionData(CartConstants.CART_ID, String.class)
                .onErrorReturn("").defaultIfEmpty("").flatMap(data -> {
                    logger.info("Reading cartId from Redis");
                    return Mono.just(data);
                });
    }

    /**
     *
     * @param sessionData
     * @return void
     */
    @SuppressWarnings("unchecked")
    public Mono<Void> upsertDataInRedis(Map sessionData)
    {
        logger.info("Upserting data into Redis : " + sessionData);
        sessionBean.setSessionData(sessionData)
                .doOnError(error -> logger.error("RFEX::Redis upsert failed : {}", error))
                .doOnSuccess(msg -> logger.info("RFEX::Redis upsert successful : {}", msg))
                .subscribeOn(Schedulers.parallel())
                .subscribe();
        return Mono.empty();
    }

    /**
     *
     * @param visionCustType
     * @return void
     */
    public Mono<Void> upsertNewCustFlowRedis(String visionCustType) {
        String custType = "";
        if (visionCustType.equalsIgnoreCase(CartConstants.VISION_CUSTTYPE_PE)) {
            custType = CartConstants.CUST_TYPE_B2C;
        } else if (visionCustType.equalsIgnoreCase(CartConstants.VISION_CUSTTYPE_BE)) {
            custType = CartConstants.CUST_TYPE_B2E;
        } else if (visionCustType.equalsIgnoreCase(CartConstants.VISION_CUSTTYPE_ME)) {
            custType = CartConstants.CUST_TYPE_EPP;
        }
        Map<String, String> sessionDetails = new HashMap<>();
        if (!custType.isEmpty()) {
            sessionDetails.put(CartConstants.CUST_TYPE, custType);
            logger.info("Upserting data into Redis : {}", sessionDetails);
            sessionBean.setSessionData(sessionDetails).doOnError(error -> logger.error("Redis upsert failed : {}", error))
                    .doOnSuccess(msg -> logger.info("Redis upsert successful : {}", msg)).subscribeOn(Schedulers.parallel())
                    .subscribe();
            return Mono.empty();
        }
        return Mono.empty();
    }

    /**
     *
     * @return deviceCartMap
     */
    public Mono<Map> getDeviceCartMap() {
        return sessionBean.getSessionData(Arrays.asList(CartConstants.DEVICE_COUNT, CartConstants.CART_HAS_PCD))
                .onErrorReturn(new HashMap<>())
                .defaultIfEmpty(new HashMap<>());
    }

    /**
     *
     * @param sessionData
     * @return upsertInd
     */
    public Mono<Boolean> upsertDeviceCartMapInRedis(Map sessionData)
    {
        logger.info(String.format("upsertDeviceCartMapInRedis data into Redis : %s" , sessionData));
        if(!sessionData.isEmpty()) {
            return sessionBean.setSessionData(sessionData)
                    .doOnError(error -> logger.info(" Redis upsert failed : " + error))
                    .doOnSuccess(success -> logger.info("Redis upsert successful : "));
        }
        return Mono.just(false);
    }

    //GTSFN-7863 and GTSFN-7865 - Read / set sku to/from redis

    /**
     * getEsimSKUFromRedis
     * @return String
     */
    public Mono<String> getEsimSKUFromRedis() {
        return sessionBean.getSessionData(CartConstants.ESIM_SKU, String.class).onErrorReturn("")
                .defaultIfEmpty("").flatMap(data -> {
                    logger.info(String.format("Reading Esim sku: %s " , data));
                    return Mono.just(data);
                });
    }

    /**
     *
     * @param requestKey
     * @return long
     */
    public Mono<Void> deleteSessionDataKeyFromRedis(String requestKey) {
        List<String> keys = new ArrayList<>();
        keys.add(requestKey);
        sessionBean.deleteSessionData(keys).doOnError(onError -> {
            logger.error(UNABLE_TO_DELETE_FROM_REDIS, onError);
        }).doOnSuccess(onSuccess -> {
            logger.info(" deleted Redis key : {} " , requestKey);
        }).subscribeOn(Schedulers.parallel()).subscribe();
        return Mono.empty();
    }

    /**
     * @param planDetails
     * @return boolean
     */
    public Mono<Void> updatePlanPathInRedis(Map<String, Map<String, String>> planDetails) {
        sessionBean.setSessionData(CartConstants.PLAN_SELECTION_PATH, planDetails)
                .doOnError(onError -> logger.error(String.format(CartConstants.REDIS_KEY_FAIL_LOG, CartConstants.PLAN_SELECTION_PATH)))
                .doOnSuccess(onSuccess -> logger.info(String.format(CartConstants.REDIS_KEY_UPDATE_LOG, CartConstants.PLAN_SELECTION_PATH)))
                .onErrorReturn(Boolean.FALSE).defaultIfEmpty(Boolean.TRUE).subscribeOn(Schedulers.parallel()).subscribe();
        return Mono.empty();
    }

    public Mono<Map> getPlanPathDetails() {
        return sessionBean.getSessionData(CartConstants.PLAN_SELECTION_PATH, String.class)
                .onErrorReturn("")
                .defaultIfEmpty("")
                .flatMap(data -> {
                    logger.info(String.format("Reading PlanDetails: %s " , data));
                    // create TypeReference of type HashMap<String, String>
                    TypeReference<HashMap> typeRef = new TypeReference<HashMap>() {};

                    // deserialize studentString into Map<String, String>
                    try {
                        Map dataMap = mapper.readValue(data, typeRef);
                    return Mono.just(dataMap);
                    } catch (JsonProcessingException e) {
                        return Mono.just(new HashMap());
                    }
                });
    }

    public Mono<PerkSPOInfo> readPerkSPOInfo() {
        logger.info("Inside readPerkSPOInfo");
        return sessionBean.getSessionData(CartConstants.PERK_SPO_INFO, String.class)
                .onErrorReturn("")
                .defaultIfEmpty("")
                .flatMap(data -> {
                    PerkSPOInfo perkSPOInfo = new PerkSPOInfo();
                    try {
                        if (StringUtilities.isNotEmptyOrNull(data)) {
                            Gson gson = new Gson();
                            perkSPOInfo = gson.fromJson(data, PerkSPOInfo.class);
                        }
                        logger.info("redis perkSPOInfo data..".concat(mapper.writeValueAsString(data)));
                    } catch (Exception e) {
                        logger.info("unable to get redis plans response data got from session {}".concat(data));
                    }
                    return Mono.just(perkSPOInfo);
                });
    }

    public Mono<Boolean> updatePerkSpoInfoInRedis(Mono<AddPlanUIRequest> uiRequestMono, Mono<PerkSPOInfo> perkSpoInfoMono) {
        logger.info("Inside updatePerkSpoInfoInRedis");
        return Mono.zip(uiRequestMono, perkSpoInfoMono).flatMap(data -> {
            AddPlanUIRequest request = data.getT1();
            PerkSPOInfo perkSpoInfo = data.getT2();
            PerkSPOInfo perkSPOInfoNew = new PerkSPOInfo();
            Set<String> mtns = new HashSet<>();
            GsonBuilder gsonBuilder = new GsonBuilder();
            Gson gsonObject = gsonBuilder.create();
            Map<String, String> requestMap = new HashMap<>();
            if (CollectionUtilities.isNotEmptyOrNull(perkSpoInfo.getPerkDetailInfo())) {
                List<PerkDetailInfo> perkDetailInfoListNew = new ArrayList<>();
                perkSpoInfo.getPerkDetailInfo().stream().filter(x -> StringUtilities.isNotEmptyOrNull(x.getMtn())).forEach(perkDetailInfo -> {
                    PerkDetailInfo perkDetailInfoNew = new PerkDetailInfo();
                    Arrays.stream(request.getData().getLines()).filter(x -> StringUtilities.isNotEmptyOrNull(x.getMtn())
                            && CollectionUtilities.isNotEmptyOrNull(x.getAddFeatures())
                            && x.getMtn().equals(perkDetailInfo.getMtn())).forEach(line -> {
                        mtns.add(perkDetailInfo.getMtn());
                        perkDetailInfoNew.setMtn(perkDetailInfo.getMtn());
                        List<PerkDetail> perkDetailListNew = new ArrayList<>();
                        Set<String> spos = new HashSet<>();
                        perkDetailInfo.getPerkDetail().stream().filter(x -> null != x && StringUtilities.isNotEmptyOrNull(x.getSpoId()))
                                .forEach(perkDetail -> {
                                    line.getAddFeatures().stream().filter(x -> null != x &&
                                            StringUtilities.isNotEmptyOrNull(perkDetail.getSpoId())
                                            && perkDetail.getSpoId().equals(x.getId())).forEach(spo -> {
                                        spos.add(spo.getId());
                                        if (!spo.getActionIndicator().equals("Z") && StringUtilities.isNotEmptyOrNull(perkDetail.getStatus())
                                                && (!perkDetail.getStatus().equals(CartConstants.PENDING_CANCEL_RESUME) &&
                                                !perkDetail.getStatus().equals(CartConstants.PENDING_CANCEL))) {
                                            perkDetailListNew.add(perkDetail);
                                        }
                                    });
                                });
                        if (CollectionUtilities.isNotEmptyOrNull(spos)) {                            //add spos that have not changed the status
                            perkDetailInfo.getPerkDetail().stream().filter(x -> null != x
                                    && StringUtilities.isNotEmptyOrNull(x.getSpoId()) && !spos.contains(x.getSpoId())).forEach(perkDetailListNew::add);
                        }
                        perkDetailInfoNew.setPerkDetail(perkDetailListNew);
                        perkDetailInfoListNew.add(perkDetailInfoNew);
                    });
                });
                if (CollectionUtilities.isNotEmptyOrNull(mtns)) {
                    perkSpoInfo.getPerkDetailInfo().stream().filter(x -> null != x &&
                            StringUtilities.isNotEmptyOrNull(x.getMtn()) && !mtns.contains(x.getMtn())).forEach(perkDetailInfoListNew::add);
                }
                perkSPOInfoNew.setPerkDetailInfo(perkDetailInfoListNew);
            }
            logger.info("New perkInfo to be updated in redis ".concat(perkSpoInfo.toString()));
            requestMap.put(CartConstants.PERK_SPO_INFO, gsonObject.toJson(perkSPOInfoNew));
            return upsertDeviceCartMapInRedis(requestMap);
        });
    }

    public boolean isPendingCancelFlow(AddPlanUIRequest uiRequest){
        logger.info("Inside isPendingCancelFlow");
        long count=0;
        if(null!=uiRequest && null !=uiRequest.getData() && null!=uiRequest.getData().getLines() && uiRequest.getData().getLines().length>=1) {
            count=Arrays.stream(uiRequest.getData().getLines()).filter(line->CollectionUtilities.isNotEmptyOrNull(line.getAddFeatures())
                    && line.getAddFeatures().stream().filter(Objects::nonNull).anyMatch(spo -> null!=spo.getActionIndicator()
                    && spo.getActionIndicator().equalsIgnoreCase("Z")
                    && StringUtilities.isNotEmptyOrNull(spo.getPendingCancelCaseID()))).count();
        }
        boolean isPendingCancelCase= count>0;
        logger.info("isPendingCancelFlow ",isPendingCancelCase);
        return count>0;
    }

    public Mono<List<String>> readSoeCradleData(ValidateCartCXPRequest request, ValidateCartUIResponse resp) {
        if(request!=null && request.getRtCartCount()!=null && request.getRtCartCount()) {
            List<String> deviceList = new ArrayList<>();
            getDeviceListForRtCartCount(resp, deviceList);
            if(CollectionUtilities.isNotEmptyOrNull(deviceList)) {
                return soeCradleDatastoreClient.multiReadSessionValues(CartConstants.PDM_REDIS_KEY, CartConstants.RT_CART_COUNT, deviceList)
                        .switchIfEmpty(Mono.defer(() -> Mono.just(new ArrayList<>())))
                        .doOnError(throwable -> logger.error(String.format("UNABLE_TO_READ_RT_CART_COUNT", throwable.getMessage())))
                        .onErrorReturn(new ArrayList<>());
            }
        }
        return Mono.just(new ArrayList<>());
    }
    private void getDeviceListForRtCartCount(ValidateCartUIResponse respObj, List<String> deviceList) {
        if (respObj.getData().getValidateCartAndUpdate().getLineDetails()!= null
                && respObj.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()!=null) {
            Arrays.stream(respObj.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()).forEach(line -> {
                if (line.getItemsInfo() != null)
                    Arrays.stream(line.getItemsInfo()).forEach(item -> {
                        if (item.getCartItems().getCartItem() != null)
                            Arrays.stream(item.getCartItems().getCartItem()).forEach(cartItem -> {
                                if(StringUtilities.isNotEmptyOrNull(cartItem.getProductId())) {
                                    deviceList.add(cartItem.getProductId());
                                }
                            });
                    });
            });
        }
    }

    public Mono<Map> barCodeOfferCode()
    {
        String[] keys  = {"z1OfferCode"};
        return sessionBean.getSessionData(Arrays.asList(keys)).doOnError(throwable -> {
            logger.error(String.format(CartConstants.UNABLE_TO_READ_FROM_REDIS_FOR_SESSION,Arrays.asList(keys),throwable.getMessage()));
        }).defaultIfEmpty(new HashMap<>()).flatMap(data->{
            return Mono.just(data);
        });
    }

    public Mono<HashMap> getEdgeBuyoutDetails() {
        return sessionBean.getSessionData(CartConstants.UPGRADE_BUYOUT_MTN_DETAILS, HashMap.class).onErrorReturn(new HashMap<>())
                .defaultIfEmpty(new HashMap<>()).flatMap(data -> {
                    logger.info("Upgrade and Buyout mtn Details Read from Redis {} ", data);
                    return Mono.just(data);
                });
    }

    public DualNumber upsertDualNumToRedis(CreateLineUIRequest request, CreateLineContext context) {
        List<SecondNumber> secondNumbers = new ArrayList<>();
        if (Boolean.TRUE.equals(null != request && null != request.getData())) {
            if (CollectionUtilities.isNotEmptyOrNull(request.getData().getLines())) {
                request.getData().getLines().stream().filter(line -> null != line && null != line.getIsSecondNumber() && line.getIsSecondNumber() && StringUtilities.isNotEmptyOrNull(line.getPrimaryMtn())).forEach(line -> {
                    SecondNumber secondNumber = new SecondNumber();
                    secondNumber.setPrimaryMtn(line.getPrimaryMtn());
                    secondNumber.setIsSecondNumber(line.getIsSecondNumber());
                    if (null != context && null != context.getCartInfo() && CollectionUtilities.isNotEmptyOrNull(context.getCartInfo().getLineNumbers())) {
                        int index = request.getData().getLines().indexOf(line);
                        if (null != context.getCartInfo().getLineNumbers().get(index))
                            secondNumber.setSecondMtn(context.getCartInfo().getLineNumbers().get(index));
                    }
                    secondNumbers.add(secondNumber);
                });
            }

            if (request.getData().getDualNumber() != null && CollectionUtilities.isNotEmptyOrNull(request.getData().getDualNumber().getSecondNumber())) {
                secondNumbers.addAll(request.getData().getDualNumber().getSecondNumber());
            }
        }
        DualNumber dualNumber = new DualNumber();
        dualNumber.setSecondNumber(secondNumbers);
        return dualNumber;
    }

    public void upsertDualNumberInSession(DualNumber dualNumber) {
        sessionBean.setSessionData(DUAL_NUMBER, dualNumber)
                .doOnError(error -> logger.error("Cassandra upsert failed : {0}", error))
                .doOnSuccess(msg -> logger.info("Cassandra upsert successful :{} ", msg))
                .subscribeOn(Schedulers.parallel())
                .subscribe();
    }
    public Mono<Boolean> upsertrealAgentCodeSession(String realAgentCode) {
        return sessionBean.setSessionData(CartConstants.REAL_AGENT_CODE, realAgentCode)
                .doOnError(error -> logger.error("Cassandra upsert failed : {0}", error))
                .doOnSuccess(msg -> logger.info("Cassandra upsert successful :{} ", msg));
    }

    public Mono<DeviceExchangeRequest> fetchRedisData(DeviceExchangeRequest request) {
        return sessionBean.getSessionData(DEVICE_UPGRADE_DETAILS,DeviceUpgradeData.class).onErrorReturn(new DeviceUpgradeData()).defaultIfEmpty(new DeviceUpgradeData()).flatMap(data -> {
                    if (null != data && null != data.getMtn()) {
                        request.setMtn(data.getMtn().getMtn());
                        request.setNetworkBandWidthType(data.getMtn().getNetworkBandwidthType());
                    }
            logger.info("deviceUpgradeDetails fetched from Redis : ", request);
            return Mono.just(request);
        });
    }

    public void upsertDataIntoSession(Map<String, String> sessionData) {
        if (sessionData != null && !sessionData.isEmpty()) {
            logger.info("Triggering upsert operation");
            sessionBean.setSessionData(sessionData)
                    .doOnError(error -> logger.error("Redis upsert failed!", error))
                    .subscribeOn(Schedulers.parallel())
                    .subscribe();
        }
    }

}
