package onevz.soe.cart.util;

import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.configurator.add.AddAllConfiguratorServiceBody;
import onevz.soe.cart.responses.AddAllConfiguratorPEGAResponse;
import onevz.soe.cart.ui.responses.AddAllConfiguratorUIResponse;
import onevz.soe.utilities.CollectionUtilities;

import java.util.List;

/**
 * The Class Cart configurator pega response util.
 */
public class CartConfiguratorPegaResponseUtil {
    private CartConfiguratorPegaResponseUtil() {

    }

    /**
     * Format add all configurator response.
     *
     * @param uiResponse   the ui response
     * @param pegaResponse the pega response
     */
    public static void formatAddAllConfiguratorResponse(AddAllConfiguratorUIResponse uiResponse, AddAllConfiguratorPEGAResponse pegaResponse) {
        if (pegaResponse.getServiceHeader() != null) uiResponse.setServiceHeader(pegaResponse.getServiceHeader());

        if (CollectionUtilities.isNotEmptyOrNull(pegaResponse.getErrors())) {
            List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
            uiResponse.setErrors(cartError);
        }

        if (pegaResponse.getServiceBody() != null) {
            AddAllConfiguratorServiceBody serviceBody = pegaResponse.getServiceBody();
            uiResponse.setServiceBody(serviceBody);
        }
    }
}
