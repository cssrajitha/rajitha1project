package onevz.soe.cart.util;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.utilities.StringUtilities;

public class OrderFlowTypeUtil {

	/**
	 * 
	 * @param orderFlowType
	 * @param processStep
	 * @param intendType
	 * @return cartOrderFlowType
	 */
	public static String calculateCartOrderFlowType(String orderFlowType, String processStep, String intendType) {
		var cartOrderFlowType = "";
		var redisFlowType = "";
		var expressFlow = "";
		var currentVal = "";
		if (CartConstants.NSE_BYOD.equalsIgnoreCase(intendType))
			intendType=CartConstants.NSO;
		else if(CartConstants.BYOD.equalsIgnoreCase(intendType))
			intendType=CartConstants.ESO;
		if (StringUtilities.isNotEmptyOrNull(orderFlowType))
			redisFlowType = orderFlowType;
		if (StringUtilities.isNotEmptyOrNull(processStep) && (CartConstants.PROMO_HUB.equalsIgnoreCase(processStep) ||
				(CartConstants.NSE.equalsIgnoreCase(intendType) && CartConstants.ACCESSORIES_INTERSTIAL.equalsIgnoreCase(processStep))))
			expressFlow = CartConstants.EXPRESS;
		currentVal = expressFlow + intendType.toLowerCase();
		if (StringUtilities.isEmptyOrNull(redisFlowType))
			cartOrderFlowType = currentVal;
		else if (!(redisFlowType.contains(CartConstants.EXPRESS)) && !(currentVal.contains(CartConstants.EXPRESS))) {
			if (!(redisFlowType.contains(currentVal)))
				cartOrderFlowType = redisFlowType + " w/" + currentVal;
			else
				cartOrderFlowType = redisFlowType;
		} else if (!(redisFlowType.contains(CartConstants.EXPRESS)) && (currentVal.contains(CartConstants.EXPRESS))) {
			String tempStr = currentVal.replace(CartConstants.EXPRESS, "");
			if (!(redisFlowType.contains(tempStr)))
				cartOrderFlowType = CartConstants.EXPRESS + redisFlowType + " w/" + tempStr;
			else
				cartOrderFlowType = CartConstants.EXPRESS + redisFlowType;
		} else if ((redisFlowType.contains(CartConstants.EXPRESS)) && !(currentVal.contains(CartConstants.EXPRESS))) {
			String tempStr = redisFlowType.replace(CartConstants.EXPRESS, "");
			if (redisFlowType.contains(currentVal))
				cartOrderFlowType = tempStr;
			else
				cartOrderFlowType = tempStr + " w/" + currentVal;
		} else if ((redisFlowType.contains(CartConstants.EXPRESS)) && (currentVal.contains(CartConstants.EXPRESS))) {
			String tempStr = currentVal.replace(CartConstants.EXPRESS, "");
			if (!(redisFlowType.contains(tempStr)))
				cartOrderFlowType = redisFlowType + " w/" + tempStr;
			else
				cartOrderFlowType = redisFlowType;
		}
		return cartOrderFlowType;
	}

	/**
	 * 
	 * @param cartOrderFlowType
	 * @return flowType
	 */
	public static String getFlowTypeValue(String cartOrderFlowType) {
		String flowType = "";
		if (StringUtilities.isNotEmptyOrNull(cartOrderFlowType)) {
			String[] flowTypeArr = cartOrderFlowType.split(" w/");
			flowType = flowTypeArr[0];
		}
		return flowType;
	}

}
