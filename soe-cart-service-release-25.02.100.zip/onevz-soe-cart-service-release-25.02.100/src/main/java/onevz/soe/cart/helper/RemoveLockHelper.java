package onevz.soe.cart.helper;


import onevz.soe.cart.bpm.helper.CartServiceBpmHelper;
import onevz.soe.cart.ui.responses.RemoveLockUIResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import onevz.soe.cart.ui.requests.RemoveLockRequest;

import onevz.soe.utilities.StringUtilities;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
public class RemoveLockHelper {
	
	private static final Logger logger = LoggerFactory.getLogger(RemoveLockHelper.class); 
	
	@Autowired
	private RedisHelper redisHelper;
	
	@Autowired
	private CartServiceBpmHelper removeLockBpmHelper;

	/**
	 *
	 * @param removeLockRequest
	 * @return RemoveLockUIResponse
	 */
	public Mono<RemoveLockUIResponse> updateRemoveLock(RemoveLockRequest removeLockRequest) {

		return redisHelper.getDataFromRedis().flatMap(data -> {
			logger.info("accountNumber from redis {}" ,data.getAccountNumber());

			if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				removeLockRequest.setAccountNumber(data.getAccountNumber());


			return removeLockBpmHelper.removeLock(removeLockRequest);
			
		});
		
		
	}

}
