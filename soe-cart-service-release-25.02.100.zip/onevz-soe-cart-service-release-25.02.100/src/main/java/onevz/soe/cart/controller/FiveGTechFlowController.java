package onevz.soe.cart.controller;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.helper.FiveGTechFlowHelper;
import onevz.soe.cart.helper.RedisHelper3;
import onevz.soe.cart.initiatecart.InitiateCartUIResponse;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.ui.requests.AddPlanAndDeviceUIRequest;
import onevz.soe.cart.util.CartPegaResponseErrorsUtil2;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


/**
 * Cart Controller class.
 */
@RestController
@RequestMapping(value = "cart")
public class FiveGTechFlowController {

    private static final Logger logger = LoggerFactory.getLogger(FiveGTechFlowController.class);

    @Autowired
    private FiveGTechFlowHelper fiveGTechFlowHelper;

    @Autowired
    private RedisHelper3 redisHelper3;


    @PostMapping(path = {"/5g/tech/cpcUpdateCart"})
    public Mono<ResponseEntity<GenericResponse>> cpcUpdateCart(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse,
                                                               @RequestBody AddPlanAndDeviceUIRequest request) {
        logger.debug("retrieve Cart Request: {}", request);
        return fiveGTechFlowHelper.cpcUpdateCart(request).flatMap(addPlanAndDeviceUIResponse -> {
            ErrorResponse errors2 = null;
            if (addPlanAndDeviceUIResponse.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil2.handleAddDeviceResponseErrorsFiveGHome(addPlanAndDeviceUIResponse);
                return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errors2));
            }
            CartRedisData redisData = new CartRedisData();
            if(null != addPlanAndDeviceUIResponse.getServiceBody() && null != addPlanAndDeviceUIResponse.getServiceBody().getServiceResponse()
                    && null != addPlanAndDeviceUIResponse.getServiceBody().getServiceResponse().getContext()){
                if(null != addPlanAndDeviceUIResponse.getServiceBody().getServiceResponse().getContext().getCartInfo())
                    redisData.setCartId(addPlanAndDeviceUIResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartId());
                redisData.setCaseId(addPlanAndDeviceUIResponse.getServiceBody().getServiceResponse().getContext().getCaseId());

            }
            return redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(redisData, "").flatMap(data -> {
                return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(addPlanAndDeviceUIResponse));
            });

        });

    }

    @PostMapping(path = "/5g/tech/cpcSubmit-plan")
    public Mono<ResponseEntity<GenericResponse>> cpcProvisionPlan(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse,
                                                               @RequestBody AddPlanAndDeviceUIRequest request) {
        return fiveGTechFlowHelper.cpcSubmitPlan(request).flatMap(addPlanAndDeviceUIResponse -> {
            ErrorResponse errors2 = null;
            if (addPlanAndDeviceUIResponse.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil2.handleAddDeviceResponseErrorsFiveGHome(addPlanAndDeviceUIResponse);
                return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errors2));
            }
            return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(addPlanAndDeviceUIResponse));

        });

    }

    /**
     * @param httpHeader
     * @param httpResponse
     * @return
     */
    @PostMapping(path = "/5g/initiateFeature-cart")
    public Mono<ResponseEntity<InitiateCartUIResponse>> cpcCreateCart(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse, @RequestBody AddPlanAndDeviceUIRequest request) {
        if(httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID) && Objects.nonNull(request))
                request.setChannelId(httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID));
        return fiveGTechFlowHelper.cpcInititateCart(request).flatMap(addPlanAndDeviceUIResponse ->
                Mono.just(ResponseEntity.status(HttpStatus.OK).body(addPlanAndDeviceUIResponse))).onErrorResume(e->{
            InitiateCartUIResponse res=new InitiateCartUIResponse();
            logger.info(CartConstants.ERROR_MSG, e.getMessage());
            SOEHTTPException exception = (SOEHTTPException) e;
            List<CartError> errors = new ArrayList<>();
            exception.getErrorHolder().getErrors().forEach(soeError -> {
                CartError error = new CartError();
                error.setMessage(soeError.getMessage());
                error.setId(soeError.getId());
                error.setNamespace(soeError.getNamespace());
                error.setName(soeError.getName());
                error.setDebug_id(soeError.getDebug_id());
                errors.add(error);
            });
            res.setErrors(errors);
            return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(res));
        });
    }
}