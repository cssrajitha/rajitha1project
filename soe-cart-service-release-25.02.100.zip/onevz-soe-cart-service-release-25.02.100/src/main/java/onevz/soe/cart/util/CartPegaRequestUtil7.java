package onevz.soe.cart.util;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.accountPin.AccountPinContext;
import onevz.soe.cart.model.accountPin.AccountpinServiceBody;
import onevz.soe.cart.model.accountPin.AccountpinServiceRequest;
import onevz.soe.cart.model.addDevice.AddPlanAndDeviceContext;
import onevz.soe.cart.model.addDevice.AddPlanAndDeviceServiceBody;
import onevz.soe.cart.model.addDevice.AddPlanAndDeviceServiceRequest;
import onevz.soe.cart.model.bbpgetProcessStep.*;
import onevz.soe.cart.model.clearCart.ClearCartContext;
import onevz.soe.cart.model.clearCart.ClearCartServiceBody;
import onevz.soe.cart.model.clearCart.ClearCartServiceRequest;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.deleteCart.DeleteCartContext;
import onevz.soe.cart.model.deleteCart.DeleteCartServiceBody;
import onevz.soe.cart.model.deleteCart.DeleteCartServiceRequest;
import onevz.soe.cart.model.removeLock.RemoveLockContext;
import onevz.soe.cart.model.removeLock.RemoveLockServiceBody;
import onevz.soe.cart.model.removeLock.RemoveLockServiceRequest;
import onevz.soe.cart.model.retrieveActivationStatus.RetrieveActivationStatusContext;
import onevz.soe.cart.model.retrieveActivationStatus.RetrieveActivationStatusRequest;
import onevz.soe.cart.model.retrieveActivationStatus.RetrieveActivationStatusServiceBody;
import onevz.soe.cart.model.salesOrderAdjustment.*;
import onevz.soe.cart.model.updateBvoOffers.UpdateBvoOffersContext;
import onevz.soe.cart.model.updateBvoOffers.UpdateBvoOffersServiceBody;
import onevz.soe.cart.model.updateBvoOffers.UpdateBvoOffersServiceRequest;
import onevz.soe.cart.model.updateSellerPrice.UpdateSellerPriceContext;
import onevz.soe.cart.model.updateSellerPrice.UpdateSellerPriceLine;
import onevz.soe.cart.model.updateSellerPrice.UpdateSellerPriceServiceBody;
import onevz.soe.cart.model.updateSellerPrice.UpdateSellerPriceServiceRequest;
import onevz.soe.cart.model.updateWFMInfo.UpdateWFMInfoContext;
import onevz.soe.cart.model.updateWFMInfo.UpdateWFMInfoServiceBody;
import onevz.soe.cart.model.updateWFMInfo.UpdateWFMInfoServiceRequest;
import onevz.soe.cart.requests.*;
import onevz.soe.cart.ui.common.CartInfo;
import onevz.soe.cart.ui.common.DeviceCartInfo;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.utilities.StringUtilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CartPegaRequestUtil7 {
    private static final Logger logger = LoggerFactory.getLogger(CartPegaRequestUtil7.class);
    @Value("${enableCradleForProspect:true}")
    private static boolean enableCradleForProspect;
    @Value("${enableCradleForExistingCustomer:true}")
    private static boolean enableCradleForExistingCustomer;

    /**
     * @param pegaRequest
     * @param request
     * @return ClearCartPEGARequest
     */
    public static ClearCartPEGARequest formatClearCartRequest(ClearCartPEGARequest pegaRequest,
                                                              ClearCartUIRequest request, Boolean isSmartPhone) {

        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        serviceHeader = CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(request.getChannelId());
        pegaRequest.setServiceHeader(serviceHeader);

        // Setting serviceName in serviceHeader for digital Exchange RFEX flow
        if (CartUtil.isDigital(request.getChannelId())
                && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                && CartConstants.REX.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_ADJUSTMENT);
        }


        ClearCartServiceBody serviceBody = new ClearCartServiceBody();
        ClearCartServiceRequest serviceRequest = new ClearCartServiceRequest();
        ClearCartContext context = new ClearCartContext();

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
        customerInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());

        customerInfo.setIsSmartphone(isSmartPhone);

        if (request.getCartInfo().getExpressCheckout() != null && request.getCartInfo().getExpressCheckout()) {
            if(CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType()) || CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())){
                if(enableCradleForProspect) {
                    customerInfo.setCradleFlowJourney(CartConstants.ACCESSORIES_INTERSTIAL_PROSPECT);
                }
            }
            else {
                if(enableCradleForExistingCustomer){
                    customerInfo.setCradleFlowJourney(CartConstants.PROMO_HUB);
                }
            }
        }
        if(null != request.getCartInfo()
                && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getFlowType())
                && CartConstants.SCAN_AND_GO.equalsIgnoreCase(request.getCartInfo().getFlowType())){
            customerInfo.setFlowType(request.getCartInfo().getFlowType());
        }
        context.setCustomerInfo(customerInfo);

        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(request.getCartInfo().getCartId());
        cartInfo.setClientAppName(request.getCartInfo().getClientAppName());
        cartInfo.setAction(CartConstants.UPDATE);
        cartInfo.setItemType(CartConstants.CLEAR_CART);
        CartServiceContextInfo contextInfo = new CartServiceContextInfo();

        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessAction()) && request.getCartInfo().getProcessAction().equals("ClearAllOnAffirmFailure")) {
            contextInfo.setProcessAction(request.getCartInfo().getProcessAction());
            contextInfo.setCallReason(CartConstants.SALES_ORDER_PURCHASE);
        } else {
            contextInfo = CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.CLEAR_CART,
                    request.getCartInfo().getClientAppName());
        }
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())) {
            cartInfo.setIntendType(request.getCartInfo().getIntendType());
            if (CartConstants.ACC.equalsIgnoreCase(request.getCartInfo().getIntendType()) || CartConstants.NSEACC.equalsIgnoreCase(request.getCartInfo().getIntendType()))
                contextInfo.setIntent(CartConstants.STANDALONEACCESSORY);
            else
                contextInfo.setIntent(request.getCartInfo().getIntendType());
        } else {
            cartInfo.setIntendType(CartConstants.EUP);
            contextInfo.setIntent(CartConstants.EUP);
        }
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessStep())) {
            contextInfo.setProcessStep(request.getCartInfo().getProcessStep());
        } else {
            contextInfo.setProcessStep(CartConstants.SHOPPING_CART);
        }

        if (CartConstants.ACC.equalsIgnoreCase(request.getCartInfo().getIntendType()) && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntent())
                && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getFlowType())
                && CartConstants.SCAN_AND_GO.equalsIgnoreCase(request.getCartInfo().getFlowType())) {
            contextInfo.setIntent(request.getCartInfo().getIntent());
        }

        if (CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())
                || CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType()) || CartConstants.NSEACC.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
            newCustomerOverride(contextInfo, customerInfo, request.getCartInfo(), request.getChannelId());
        }

        // Setting serviceName in serviceHeader for digital Exchange RFEX flow
        if (CartUtil.isDigital(request.getChannelId())
                && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                && CartConstants.REX.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
            contextInfo.setCallReason(CartConstants.SALES_ORDER_ADJUSTMENT);
            contextInfo.setProcessAction(CartConstants.REMOVE_ITEM);
            cartInfo.setAction(CartConstants.REMOVE);
            cartInfo.setItemType(CartConstants.CLEAR_ITEMS);

            if (null != request.getRfexExchangeShopDetails()
                    && StringUtilities.isNotEmptyOrNull(request.getRfexExchangeShopDetails().getMtn())) {

                context.getCustomerInfo().setProcessingMTN(request.getRfexExchangeShopDetails().getMtn());
                logger.info("ClearCart processingMTN set for Digital RFEX flow: {}",
                        context.getCustomerInfo().getProcessingMTN());
                if (null != request.getData() && null != request.getData().getLines()) {
                    for (Line cartInfoLine : request.getData().getLines()) {
                        Line cartline = cartInfoLine;
                        logger.info("Line Mtn set for Digital RFEX flow: {}",
                                request.getRfexExchangeShopDetails().getMtn());
                        cartline.setMtn(request.getRfexExchangeShopDetails().getMtn());
                        logger.info("CartInfo Line Mtn set to : {} for Digital RFEX flow", cartline.getMtn());
                        cartInfo.setLines(new Line[] { cartline });
                    }
                }

            }

        }

        //MVP2-GR
        if(request.getCartInfo()!=null && request.getCartInfo().getCaseId()!=null && request.getCartInfo().getCaseId().startsWith("SOF")){

            logger.info("SalesOrderFlex Prepay clear cart Request before PEGA call setting Call Reason");
            contextInfo.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }

        context.setContextInfo(contextInfo);
        context.setCartInfo(cartInfo);
        context.setCaseId(request.getCartInfo().getCaseId());

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);

        return pegaRequest;
    }

    /**
     * @param pegaRequest
     * @param request
     * @return UpdateWFMInfoPEGARequest
     */
    public static UpdateWFMInfoPEGARequest formatUpdateWFMInfoRequest(UpdateWFMInfoPEGARequest pegaRequest,
                                                                      UpdateWFMInfoUIRequest request) {

        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(request.getChannelId());
        pegaRequest.setServiceHeader(serviceHeader);

        UpdateWFMInfoServiceBody serviceBody = new UpdateWFMInfoServiceBody();
        UpdateWFMInfoServiceRequest serviceRequest = new UpdateWFMInfoServiceRequest();
        UpdateWFMInfoContext context = new UpdateWFMInfoContext();

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
        customerInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());


        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(request.getCartInfo().getCartId());
        cartInfo.setClientAppName(request.getCartInfo().getClientAppName());
        cartInfo.setAction(CartConstants.UPDATE);
        cartInfo.setItemType(CartConstants.WFM_ORDER_INFO);
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())) {
            cartInfo.setIntendType(request.getCartInfo().getIntendType());
        } else {
            cartInfo.setIntendType(CartConstants.EUP);
        }
        cartInfo.setWfmOrderInfo(request.getData().getWfmOrderInfo());

        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        contextInfo.setProcessAction(CartConstants.UPDATE_WFM);
        contextInfo.setCallReason(CartConstants.SALES_ORDER_PURCHASE);
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntent()))
            contextInfo.setIntent(request.getCartInfo().getIntent());
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessStep())) {
            contextInfo.setProcessStep(request.getCartInfo().getProcessStep());
        } else {
            contextInfo.setProcessStep(CartConstants.READ_ORDER_PAGE);
        }
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()) && request.getCartInfo().getIntendType().toUpperCase().contains("NSE")) {
            newCustomerOverride(contextInfo, customerInfo, request.getCartInfo(), request.getChannelId());
        }

        context.setCustomerInfo(customerInfo);
        context.setContextInfo(contextInfo);
        context.setCartInfo(cartInfo);
        context.setCaseId(request.getCartInfo().getCaseId());

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);
        return pegaRequest;

    }

    /**
     * @param pegaRequest2
     * @param request2
     * @return AddPlanPEGARequest
     */
    public static AccountPinPEGARequest formatAccountPinRequest(AccountPinPEGARequest pegaRequest2,
                                                                AccountPinUIRequest request2) {

        CartServiceServiceHeader serviceHeader2 = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader2);
        serviceHeader2.setClientId(request2.getChannelId());
        pegaRequest2.setServiceHeader(serviceHeader2);

        AccountpinServiceBody serviceBody2 = new AccountpinServiceBody();
        AccountpinServiceRequest serviceRequest2 = new AccountpinServiceRequest();
        AccountPinContext context2 = new AccountPinContext();

        CartServiceCustomerInfo customerInfo2 = new CartServiceCustomerInfo();
        if (StringUtilities.isNotEmptyOrNull(request2.getCartInfo().getGlobalId()))
            customerInfo2.setGlobalId(request2.getCartInfo().getGlobalId());
        if (StringUtilities.isNotEmptyOrNull(request2.getCartInfo().getCartCreator()))
            customerInfo2.setCartCreator(request2.getCartInfo().getCartCreator());
        if (StringUtilities.isNotEmptyOrNull(request2.getCartInfo().getSessionId())) {
            if (StringUtilities.isEmptyOrNull(request2.getCartInfo().getGlobalId()))
                customerInfo2.setGlobalId(request2.getCartInfo().getSessionId());
            if (StringUtilities.isEmptyOrNull(request2.getCartInfo().getCartCreator()))
                customerInfo2.setCartCreator(request2.getCartInfo().getSessionId());
        }

        if (StringUtilities.isNotEmptyOrNull(request2.getCartInfo().getCustomerType()))
            customerInfo2.setCustomerType(request2.getCartInfo().getCustomerType());
        else
            customerInfo2.setCustomerType(CartConstants.NEW_CUSTOMER);
        if (StringUtilities.isNotEmptyOrNull(request2.getCartInfo().getMtnFlow()))
            customerInfo2.setMtnFlow(request2.getCartInfo().getMtnFlow());

        if (StringUtilities.isNotEmptyOrNull(request2.getCartInfo().getCreditAppNum()))
            customerInfo2.setOriginalCreditApprovalNumber(request2.getCartInfo().getCreditAppNum());
        if (StringUtilities.isNotEmptyOrNull(request2.getData().getCradleFlowJourney()))
            customerInfo2.setCradleFlowJourney(request2.getData().getCradleFlowJourney());
        if (StringUtilities.isNotEmptyOrNull(request2.getData().getBucketAllocator()))
            customerInfo2.setBucketAllocator(request2.getData().getBucketAllocator());
        if (StringUtilities.isNotEmptyOrNull(request2.getData().getThrottleList()))
            customerInfo2.setThrottleList(request2.getData().getThrottleList());

        context2.setCustomerInfo(customerInfo2);

        CartServiceCartInfo cartInfo2 = new CartServiceCartInfo();
        cartInfo2.setCartId(request2.getCartInfo().getCartId());
        cartInfo2.setItemType(request2.getCartInfo().getItemType());
        cartInfo2.setAction(request2.getCartInfo().getAction());
        cartInfo2.setIntendType(request2.getCartInfo().getIntendType());
        cartInfo2.setAccountPin(request2.getCartInfo().getAccountPin());
        context2.setCartInfo(cartInfo2);

        CartServiceContextInfo contextInfo2 = new CartServiceContextInfo();
        contextInfo2.setCallReason(CartConstants.SALES_ORDER_PURCHASE);
        contextInfo2.setIntent(request2.getCartInfo().getIntendType());
        contextInfo2.setProcessAction(request2.getCartInfo().getProcessAction());
        contextInfo2.setProcessStep(request2.getCartInfo().getProcessStep());
        context2.setContextInfo(contextInfo2);
        context2.setCartInfo(cartInfo2);
        context2.setCaseId(request2.getCartInfo().getCaseId());

        //MVP2-GR
        if(request2.getCartInfo()!=null && request2.getCartInfo().getCaseId()!=null && request2.getCartInfo().getCaseId().startsWith("SOF")){

            logger.info("SalesOrderFlex Prepay account pin Request before PEGA call setting Call Reason");
            contextInfo2.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader2.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }
     // Changes to update callreason, flow type, service name for Customer trial flow
        if(CartPegaRequestUtil.isTrialCustomerFlow(request2.getCartInfo().getFlowType())) {
        	pegaRequest2.getServiceHeader().setServiceName(CartConstants.SERVICE_NAME_TRIAL);
        	context2.getCustomerInfo().setFlowType(CartConstants.FLOW_TYPE_DVM);
        	contextInfo2.setCallReason(CartConstants.TRIAL_CALLREASON);
        }
        serviceRequest2.setContext(context2);
        serviceBody2.setServiceRequest(serviceRequest2);
        pegaRequest2.setServiceBody(serviceBody2);

        return pegaRequest2;

    }

    /**
     * @param pegaRequest
     * @param request
     * @return SalesOrderAdjustmentPEGARequest
     */
    public static SalesOrderAdjustmentPEGARequest formatSalesOrderAdjustmentRequest(
            SalesOrderAdjustmentPEGARequest pegaRequest, SalesOrderAdjustmentUIRequest request) {

        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(request.getChannelId());
        serviceHeader.setServiceName(CartConstants.SALES_ORDER_ADJUSTMENT);

        SalesOrderAdjustmentServiceBody serviceBody = new SalesOrderAdjustmentServiceBody();
        SalesOrderAdjustmentServiceRequest serviceRequest = new SalesOrderAdjustmentServiceRequest();
        SalesOrderAdjustmentContext context = new SalesOrderAdjustmentContext();

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        customerInfo.setSalesRepID(request.getCartInfo().getSalesRepId());
        customerInfo.setCartCreatorLocationCode(request.getCartInfo().getCartCreatorLocationCode());
        customerInfo.setCartCreator(request.getCartInfo().getCartCreator());

        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(request.getCartInfo().getCartId());
        cartInfo.setAction(CartConstants.UPDATE);

        //FMI Manager, Refresh Changes starts
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getItemType())) {
            if(request.getCartInfo().getItemType().equals(CartConstants.FMI_CHECK)) {
                cartInfo.setItemType("FMICheck");
            }else if(request.getCartInfo().getItemType().equals(CartConstants.FMI_OVERRIDE)) {
                cartInfo.setItemType("FMI-OVERRIDE");
                if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getParentMtn())) {
                    cartInfo.setParentMtn(request.getCartInfo().getParentMtn());
                }
                if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getManagerId())) {
                    cartInfo.setManagerId(request.getCartInfo().getManagerId());
                }
                if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getPassword())) {
                    cartInfo.setPassword(request.getCartInfo().getPassword());
                }
                if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getComments())) {
                    cartInfo.setComments(request.getCartInfo().getComments());
                }
            }else {
                cartInfo.setItemType(request.getCartInfo().getItemType());
            }
        }else {
            cartInfo.setItemType("RFEX");
        }

        cartInfo.setAddressValidationRequired(request.getRefundOrderdetails().getAddressValidationRequired());
        cartInfo.setCreditValidationRequired(request.getCartInfo().getCreditValidationRequired());
        cartInfo.setIsDisconnectedSelected(request.getRefundOrderdetails().getIsDisconnectedSelected());
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCheckAutoPayDiscountEligible())) {
            cartInfo.setCheckAutoPayDiscountEligible(request.getCartInfo().getCheckAutoPayDiscountEligible());
        }

        // NSADT-159132
        SalesOrderAdjustmentOrderDetails details = request.getRefundOrderdetails();
        LineInfo[] lineinfo = details.getLines().getLineInfo();
        for (LineInfo info : lineinfo) {
            Items[] items = info.getItems();
            for (Items item : items) {
                ReturnReason reason = item.getReturnReason();
                String updatedSymptom = reason.getSymptoms().replaceAll("[^a-zA-Z0-9\\s.]","");
                reason.setSymptoms(updatedSymptom);
            }
        }
        cartInfo.setRefundOrderDetails(details);
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()))
            cartInfo.setIntendType(request.getCartInfo().getIntendType());
        else
            cartInfo.setIntendType(CartConstants.REFUND_EXCHANGE);

        CartServiceContextInfo contextInfo = new CartServiceContextInfo();

        contextInfo.setCallReason(CartConstants.SALES_ORDER_ADJUSTMENT);
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntent()))
            contextInfo.setIntent(request.getCartInfo().getIntent());
        else
            contextInfo.setIntent(CartConstants.REFUND_EXCHANGE);

        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessStep()) && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getItemType())) {
            if(request.getCartInfo().getItemType().equals(CartConstants.FMI_CHECK) ||
                    request.getCartInfo().getItemType().equals(CartConstants.FMI_OVERRIDE)){
                contextInfo.setProcessStep("ManagerApproval");
            }
        }else {
            contextInfo.setProcessStep(request.getCartInfo().getProcessStep());
        }

        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessAction()) && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getItemType())) {
            if(request.getCartInfo().getItemType().equals(CartConstants.FMI_CHECK)) {
                contextInfo.setProcessAction("Refresh");
            }else if(request.getCartInfo().getItemType().equals(CartConstants.FMI_OVERRIDE)) {
                contextInfo.setProcessAction("FMIOverride");
            }
        }else {
            if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessAction())) {
                contextInfo.setProcessAction(request.getCartInfo().getProcessAction());
            }else {
                contextInfo.setProcessAction(CartConstants.FLEX);
            }
        }

        //FMI Manager, Refresh Changes ends

        context.setCaseId(request.getCartInfo().getCaseId());
        context.setCustomerInfo(customerInfo);
        context.setCartInfo(cartInfo);

        //MVP2-GR
        if(request.getCartInfo()!=null && request.getCartInfo().getCaseId()!=null && request.getCartInfo().getCaseId().startsWith("SOF")){

            logger.info("SalesOrderFlex Prepay sales order adjustment Request before PEGA call setting Call Reason");
            contextInfo.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }

        context.setContextInfo(contextInfo);

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);

        pegaRequest.setServiceHeader(serviceHeader);
        pegaRequest.setServiceBody(serviceBody);

        return pegaRequest;
    }

    /**
     *
     * @param pegaRequest
     * @param request
     * @return pegaRequest
     */
    public static BBPGetProcessStepPEGARequest formatbbpGetProcessStepRequest(BBPGetProcessStepPEGARequest pegaRequest,
                                                                              BBPGetProcessStepUIRequest request) {

        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeaderForProcessStep(serviceHeader, request);
        pegaRequest.setServiceHeader(serviceHeader);

        GetProcessStepServiceBody serviceBody = new GetProcessStepServiceBody();
        ProcessStepServiceRequest serviceRequest = new ProcessStepServiceRequest();
        ProcessStepContext context = new ProcessStepContext();

        context.setCaseId(request.getCartInfo().getCaseId());

        ProcessStepCustomerInfo customerInfo = new ProcessStepCustomerInfo();
        customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
        customerInfo.setGlobalId(request.getCartInfo().getCartCreator());
        customerInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getDeviceType())) {
            customerInfo.setDeviceType(request.getCartInfo().getDeviceType());
        }
        context.setCustomerInfo(customerInfo);

        ProcessStepCartInfo cartInfo = new ProcessStepCartInfo();
        cartInfo.setCartId(request.getCartInfo().getCartId());

        context.setCartInfo(cartInfo);

        ProcessStepContextInfo contextInfo = new ProcessStepContextInfo();
        contextInfo.setCallReason(CartConstants.SALES_ORDER_PURCHASE);
        contextInfo.setIntent("BYOD");
        if (CartConstants.NEW_CUSTOMER.equalsIgnoreCase(request.getCartInfo().getCustomerType())){
            contextInfo.setIntent(CartConstants.NSE_BYOD);
            customerInfo.setCustomerType(request.getCartInfo().getCustomerType());
        }
        contextInfo.setProcessAction(request.getCartInfo().getProcessAction());
        contextInfo.setProcessStep(request.getCartInfo().getProcessStep());

        //MVP2-GR
        if(request.getCartInfo()!=null && request.getCartInfo().getCaseId()!=null && request.getCartInfo().getCaseId().startsWith("SOF")){

            logger.info("SalesOrderFlex format bbp Request before PEGA call setting Call Reason");
            contextInfo.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }

        context.setContextInfo(contextInfo);

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);

        return pegaRequest;

    }

    protected static void newCustomerOverride(CartServiceContextInfo contextInfo, CartServiceCustomerInfo customerInfo,
                                            CartInfo cartInfo, String channelId) {
        if (StringUtilities.isEmptyOrNull(cartInfo.getAccountNumber()))
            customerInfo.setAccountNumber("");
        if (StringUtilities.isNotEmptyOrNull(cartInfo.getGlobalId()))
            customerInfo.setGlobalId(cartInfo.getGlobalId());
        if (StringUtilities.isNotEmptyOrNull(cartInfo.getCartCreator()))
            customerInfo.setCartCreator(cartInfo.getCartCreator());
        if (StringUtilities.isNotEmptyOrNull(cartInfo.getSessionId())) {
            if (StringUtilities.isEmptyOrNull(cartInfo.getGlobalId()))
                customerInfo.setGlobalId(cartInfo.getSessionId());
            if (StringUtilities.isEmptyOrNull(cartInfo.getCartCreator()))
                customerInfo.setCartCreator(cartInfo.getSessionId());
        }

        if (StringUtilities.isNotEmptyOrNull(cartInfo.getAccountType()))
            customerInfo.setAccountType(cartInfo.getAccountType());

        if (StringUtilities.isNotEmptyOrNull(cartInfo.getCustomerType()))
            customerInfo.setCustomerType(cartInfo.getCustomerType());
        else
            customerInfo.setCustomerType(CartConstants.NEW_CUSTOMER);
        if (StringUtilities.isNotEmptyOrNull(cartInfo.getMtnFlow()))
            customerInfo.setMtnFlow(cartInfo.getMtnFlow());

        if (StringUtilities.isNotEmptyOrNull(cartInfo.getCreditAppNum())) {
            customerInfo.setCartCreator(cartInfo.getCreditAppNum());
            customerInfo.setOriginalCreditApprovalNumber(cartInfo.getCreditAppNum());
        }
        if (StringUtilities.isNotEmptyOrNull(cartInfo.getEditFromPage()))
            customerInfo.setEditFromPage(cartInfo.getEditFromPage());
        if (StringUtilities.isNotEmptyOrNull(cartInfo.getCreditAppNum()))
            customerInfo.setOriginalCreditApprovalNumber(cartInfo.getCreditAppNum());
        if (CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(channelId))
                && StringUtilities.isNotEmptyOrNull(cartInfo.getCreditAppNum())) {
            if (cartInfo.getCreditAppNum().matches(CartConstants.EMAIL_ID_REGEX)) {
                customerInfo.setCartCreator(cartInfo.getCreditAppNum());
                customerInfo.setOriginalCreditApprovalNumber("");
            } else {
                customerInfo.setOriginalCreditApprovalNumber(cartInfo.getCreditAppNum());
                customerInfo.setCartCreator(cartInfo.getCreditAppNum());
            }
        }
        if (StringUtilities.isEmptyOrNull(cartInfo.getAmRole()))
            customerInfo.setAmRole(cartInfo.getAmRole());
        if (StringUtilities.isNotEmptyOrNull(cartInfo.getBucketAllocator()))
            customerInfo.setBucketAllocator(cartInfo.getBucketAllocator());
        if (StringUtilities.isNotEmptyOrNull(cartInfo.getThrottleList()))
            customerInfo.setThrottleList(cartInfo.getThrottleList());
        if (null != cartInfo.getStandaloneBYOD())
            customerInfo.setStandaloneBYOD(cartInfo.getStandaloneBYOD());
        if (null != cartInfo.getIsEQPandPPLOfferApplied())
            customerInfo.setIsEQPandPPLOfferApplied(cartInfo.getIsEQPandPPLOfferApplied());
        if (StringUtilities.isNotEmptyOrNull(cartInfo.getChatId()))
            customerInfo.setChatId(cartInfo.getChatId());
        if (StringUtilities.isEmptyOrNull(cartInfo.getFlowType()))
            customerInfo.setFlowType(cartInfo.getFlowType());
        if (StringUtilities.isNotEmptyOrNull(cartInfo.getSalesRepUswin()))
            customerInfo.setSalesRepUswin(cartInfo.getSalesRepUswin());
        if (null != cartInfo.getRegisterNumber())
            customerInfo.setRegisterNumber(cartInfo.getRegisterNumber());
        if (StringUtilities.isNotEmptyOrNull(cartInfo.getCartCreatorSalesRepId()))
            customerInfo.setCartCreatorSalesRepId(cartInfo.getCartCreatorSalesRepId());
        if (StringUtilities.isNotEmptyOrNull(cartInfo.getCartCreatorOrderLocationCode()))
            customerInfo.setCartCreatorOrderLocationCode(cartInfo.getCartCreatorOrderLocationCode());
        if (StringUtilities.isNotEmptyOrNull(cartInfo.getReferralVendorId()))
            customerInfo.setReferralVendorId(cartInfo.getReferralVendorId());
        if (StringUtilities.isNotEmptyOrNull(cartInfo.getEcpdToken()))
            customerInfo.setEcpdToken(cartInfo.getEcpdToken());
        if (StringUtilities.isNotEmptyOrNull(cartInfo.getRylEcpdUrl()))
            customerInfo.setRylEcpdUrl(cartInfo.getRylEcpdUrl());
        if (StringUtilities.isNotEmptyOrNull(cartInfo.getReferralSaleRepId()))
            customerInfo.setReferralSaleRepId(cartInfo.getReferralSaleRepId());
        if(CartConstants.NSEACC.equalsIgnoreCase(cartInfo.getIntendType()))
            contextInfo.setIntent(CartConstants.STANDALONEACCESSORY);
        else
            contextInfo.setIntent(cartInfo.getIntendType());
        if(CartConstants.NSE_5G.contentEquals(cartInfo.getIntendType()))
            contextInfo.setIntent(CartConstants.FIVEG_HOME);
    }

    protected static void newCustomerOverride(CartServiceContextInfo contextInfo3, CartServiceCustomerInfo customerInfo3,
                                            DeviceCartInfo cartInfo3, String channelId3) {
        if (StringUtilities.isEmptyOrNull(cartInfo3.getAccountNumber()))
            customerInfo3.setAccountNumber("");
        if (StringUtilities.isNotEmptyOrNull(cartInfo3.getGlobalId()))
            customerInfo3.setGlobalId(cartInfo3.getGlobalId());
        if (StringUtilities.isNotEmptyOrNull(cartInfo3.getCartCreator()))
            customerInfo3.setCartCreator(cartInfo3.getCartCreator());
        if (StringUtilities.isNotEmptyOrNull(cartInfo3.getSessionId())) {
            if (StringUtilities.isEmptyOrNull(cartInfo3.getGlobalId()))
                customerInfo3.setGlobalId(cartInfo3.getSessionId());
            if (StringUtilities.isEmptyOrNull(cartInfo3.getCartCreator()))
                customerInfo3.setCartCreator(cartInfo3.getSessionId());
        }

        if (StringUtilities.isNotEmptyOrNull(cartInfo3.getAccountType()))
            customerInfo3.setAccountType(cartInfo3.getAccountType());

        if (StringUtilities.isNotEmptyOrNull(cartInfo3.getCustomerType()))
            customerInfo3.setCustomerType(cartInfo3.getCustomerType());
        else
            customerInfo3.setCustomerType(CartConstants.NEW_CUSTOMER);
        if (StringUtilities.isNotEmptyOrNull(cartInfo3.getMtnFlow()))
            customerInfo3.setMtnFlow(cartInfo3.getMtnFlow());

        if (StringUtilities.isNotEmptyOrNull(cartInfo3.getCreditAppNum())) {
            customerInfo3.setCartCreator(cartInfo3.getCreditAppNum());
            customerInfo3.setOriginalCreditApprovalNumber(cartInfo3.getCreditAppNum());
        }
        if (StringUtilities.isNotEmptyOrNull(cartInfo3.getCreditAppNum()))
            customerInfo3.setOriginalCreditApprovalNumber(cartInfo3.getCreditAppNum());
        if (CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(channelId3))
                && StringUtilities.isNotEmptyOrNull(cartInfo3.getCreditAppNum()))
            customerInfo3.setCartCreator(cartInfo3.getCreditAppNum());
        if (StringUtilities.isEmptyOrNull(cartInfo3.getAmRole()))
            customerInfo3.setAmRole(cartInfo3.getAmRole());
        if (StringUtilities.isNotEmptyOrNull(cartInfo3.getReferralVendorId()))
            customerInfo3.setReferralVendorId(cartInfo3.getReferralVendorId());
        if (StringUtilities.isNotEmptyOrNull(cartInfo3.getEcpdToken()))
            customerInfo3.setEcpdToken(cartInfo3.getEcpdToken());
        if (StringUtilities.isNotEmptyOrNull(cartInfo3.getEcpdProfileId()))
            customerInfo3.setEcpdProfileId(cartInfo3.getEcpdProfileId());
        if (StringUtilities.isNotEmptyOrNull(cartInfo3.getRylEcpdUrl()))
            customerInfo3.setRylEcpdUrl(cartInfo3.getRylEcpdUrl());
        if (StringUtilities.isNotEmptyOrNull(cartInfo3.getReferralSaleRepId()))
            customerInfo3.setReferralSaleRepId(cartInfo3.getReferralSaleRepId());
        if (StringUtilities.isNotEmptyOrNull(cartInfo3.getCartCreatorSalesRepId()))
            customerInfo3.setCartCreatorSalesRepId(cartInfo3.getCartCreatorSalesRepId());
        if(CartConstants.NSE_5G.contentEquals(cartInfo3.getIntendType()))
            contextInfo3.setIntent(CartConstants.FIVEG_HOME);
        else
            contextInfo3.setIntent(cartInfo3.getIntendType());
    }

    public static RemoveLockPEGARequest formatRemoveLockRequest(RemoveLockPEGARequest pegaRequest,
                                                                RemoveLockRequest removeLockRequest) {
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(removeLockRequest.getChannelId());
        pegaRequest.setServiceHeader(serviceHeader);
        RemoveLockServiceBody serviceBody = new RemoveLockServiceBody();
        RemoveLockServiceRequest serviceRequest= new RemoveLockServiceRequest();
        RemoveLockContext context= new  RemoveLockContext();

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(removeLockRequest.getAccountNumber());

        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        contextInfo.setIntent(CartConstants.UPGRADE);
        contextInfo.setProcessAction("RemoveLock");
        contextInfo.setCallReason(CartConstants.SALES_ORDER_PURCHASE);
        contextInfo.setProcessStep("");

        context.setCustomerInfo(customerInfo);
        context.setContextInfo(contextInfo);

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);

        return pegaRequest;

    }

    /**
     * @param pegaRequest3
     * @param request3
     * @return RetrieveActivationStatusPEGARequest
     */

    public static RetrieveActivationStatusPEGARequest formatRetrieveActivationStatusRequest(
            RetrieveActivationStatusPEGARequest pegaRequest3, RetrieveActivationStatusUIRequest request3) {

        CartServiceServiceHeader serviceHeader3 = new CartServiceServiceHeader();
        serviceHeader3 = CartPegaRequestUtil.addServiceHeader(serviceHeader3);
        serviceHeader3.setClientId(request3.getChannelId());
        pegaRequest3.setServiceHeader(serviceHeader3);

        RetrieveActivationStatusServiceBody serviceBody3 = new RetrieveActivationStatusServiceBody();
        RetrieveActivationStatusRequest serviceRequest3 = new RetrieveActivationStatusRequest();
        RetrieveActivationStatusContext context3 = new RetrieveActivationStatusContext();

        CartServiceCustomerInfo customerInfo3 = new CartServiceCustomerInfo();
        if(null != request3.getLastRetry())
            customerInfo3.setLastRetry(request3.getLastRetry());
        if (StringUtilities.isNotEmptyOrNull(request3.getCartInfo().getGlobalId()))
            customerInfo3.setGlobalId(request3.getCartInfo().getGlobalId());
        if (StringUtilities.isNotEmptyOrNull(request3.getCartInfo().getCartCreator()))
            customerInfo3.setCartCreator(request3.getCartInfo().getCartCreator());
        if (StringUtilities.isNotEmptyOrNull(request3.getCartInfo().getSessionId())) {
            if (StringUtilities.isEmptyOrNull(request3.getCartInfo().getGlobalId()))
                customerInfo3.setGlobalId(request3.getCartInfo().getSessionId());
            if (StringUtilities.isEmptyOrNull(request3.getCartInfo().getCartCreator()))
                customerInfo3.setCartCreator(request3.getCartInfo().getSessionId());
        }
        if (StringUtilities.isNotEmptyOrNull(request3.getCartInfo().getAccountNumber()))
            customerInfo3.setAccountNumber(request3.getCartInfo().getAccountNumber());
        if (StringUtilities.isNotEmptyOrNull(request3.getCartInfo().getProcessingMTN()))
            customerInfo3.setProcessingMTN(request3.getCartInfo().getProcessingMTN());
        if(request3.getCartInfo().getIntendType().equalsIgnoreCase(CartConstants.NSE_BYOD))
            customerInfo3.setCustomerType(CartConstants.NEW_CUSTOMER);
        if (StringUtilities.isNotEmptyOrNull(request3.getCartInfo().getMtnFlow()))
            customerInfo3.setMtnFlow(request3.getCartInfo().getMtnFlow());

        if (StringUtilities.isNotEmptyOrNull(request3.getCartInfo().getCreditAppNum()))
            customerInfo3.setOriginalCreditApprovalNumber(request3.getCartInfo().getCreditAppNum());

        CartServiceCartInfo cartInfo3 = new CartServiceCartInfo();
        cartInfo3.setCartId(request3.getCartInfo().getCartId());

        CartServiceContextInfo contextInfo3 = new CartServiceContextInfo();
        contextInfo3.setCallReason(CartConstants.SALES_ORDER_PURCHASE);
        contextInfo3.setIntent(request3.getCartInfo().getIntendType());
        contextInfo3.setProcessAction(request3.getCartInfo().getProcessAction());
        contextInfo3.setProcessStep(request3.getCartInfo().getProcessStep());

        if (CartConstants.NSE_BYOD.equalsIgnoreCase(request3.getCartInfo().getIntendType())
                || CartConstants.NSE.equalsIgnoreCase(request3.getCartInfo().getIntendType())
                || CartConstants.NSE_5G.equalsIgnoreCase(request3.getCartInfo().getIntendType())) {
            newCustomerOverride(contextInfo3, customerInfo3, request3.getCartInfo(), request3.getChannelId());
        }

        context3.setCartInfo(cartInfo3);
        context3.setCustomerInfo(customerInfo3);
        context3.setContextInfo(contextInfo3);
        context3.setCartInfo(cartInfo3);
        context3.setCaseId(request3.getCartInfo().getCaseId());

        //MVP2-GR
        if(request3.getCartInfo()!=null && request3.getCartInfo().getCaseId()!=null && request3.getCartInfo().getCaseId().startsWith("SOF")){

            logger.info("SalesOrderFlex Prepay retrieve  activation status Request before PEGA call setting Call Reason");
            contextInfo3.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader3.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }
        serviceRequest3.setContext(context3);
        serviceBody3.setServiceRequest(serviceRequest3);
        pegaRequest3.setServiceBody(serviceBody3);
        return pegaRequest3;

    }

    /**
     *
     * @param pegaRequest
     * @param request
     * @return UpdateBvoOffersPEGARequest
     */
    public static UpdateBvoOffersPEGARequest formatRemoveBvoOffersRequest(
            UpdateBvoOffersPEGARequest pegaRequest, UpdateBvoOffersUIRequest request) {
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader);
        pegaRequest.setServiceHeader(serviceHeader);

        UpdateBvoOffersServiceBody serviceBody = new UpdateBvoOffersServiceBody();
        UpdateBvoOffersServiceRequest serviceRequest = new UpdateBvoOffersServiceRequest();
        UpdateBvoOffersContext context = new UpdateBvoOffersContext();

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
        customerInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());
        context.setCustomerInfo(customerInfo);

        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(request.getCartInfo().getCartId());
        cartInfo.setAction(CartConstants.REMOVE);
        cartInfo.setItemType("OFFER");
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()))
            cartInfo.setIntendType(request.getCartInfo().getIntendType());
        else
            cartInfo.setIntendType(CartConstants.EUP);
        List<Line> lines = new ArrayList<>();

        for (Lines reqLine : request.getData().getLines()) {
            Line newLine = new Line();
            newLine.setMtn(reqLine.getMtn());
            newLine.setRemoveOffers(reqLine.getRemoveOffers());
            lines.add(newLine);
        }
        Line[] lineArr = new Line[lines.size()];
        lines.toArray(lineArr);

        cartInfo.setLines(lineArr);

        context.setCartInfo(cartInfo);
        context.setCaseId(request.getCartInfo().getCaseId());

        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.REMOVE_OFFER,
                request.getCartInfo().getClientAppName());
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessStep()))
            contextInfo.setProcessStep(request.getCartInfo().getProcessStep());
        else
            contextInfo.setProcessStep(CartConstants.SHOPPING_CART);
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                && !"EUP".equalsIgnoreCase(request.getCartInfo().getIntendType()))
            contextInfo.setIntent(request.getCartInfo().getIntendType());
        else
            contextInfo.setIntent(CartConstants.UPGRADE);
        context.setContextInfo(contextInfo);

        //MVP2-GR
        if(request.getCartInfo()!=null && request.getCartInfo().getCaseId()!=null && request.getCartInfo().getCaseId().startsWith("SOF")){

            logger.info("SalesOrderFlex Prepay remove bvo offers Request before PEGA call setting Call Reason");
            contextInfo.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }
        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);
        return pegaRequest;
    }

    /**
     *
     * @param pegaRequest
     * @param request
     * @return UpdateBvoOffersPEGARequest
     */
    public static UpdateSellerPricePEGARequest formatUpdateSellerPriceRequest(
            UpdateSellerPricePEGARequest pegaRequest, UpdateSellerPriceUIRequestNew request) {
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader);
        //RFEX changes for indirect channel
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                && CartConstants.REX.equalsIgnoreCase(request.getCartInfo().getIntendType())
                && request.getChannelId()!=null && (CartConstants.OMNI_INDIRECT.equalsIgnoreCase(request.getChannelId())
                || CartConstants.OMNI_INDIRECT_TAB.equalsIgnoreCase(request.getChannelId()))){
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_ADJUSTMENT);
        }
        pegaRequest.setServiceHeader(serviceHeader);

        UpdateSellerPriceServiceBody serviceBody = new UpdateSellerPriceServiceBody();
        UpdateSellerPriceServiceRequest serviceRequest = new UpdateSellerPriceServiceRequest();
        UpdateSellerPriceContext context = new UpdateSellerPriceContext();

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
        customerInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());
        context.setCustomerInfo(customerInfo);

        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(request.getCartInfo().getCartId());
        cartInfo.setAction(CartConstants.UPDATE);
        cartInfo.setItemType("SELLERPRICE");
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()))
            cartInfo.setIntendType(request.getCartInfo().getIntendType());
        else
            cartInfo.setIntendType(CartConstants.EUP);
        List<Line> lines = new ArrayList<>();
        for (UpdateSellerPriceLine reqLine : request.getData().getLines()) {
            Line newLine = new Line();
            newLine.setMtn(reqLine.getMtn());
            newLine.setSellerPrice(reqLine.getSellerPrice());
            lines.add(newLine);
        }
        Line[] lineArr = new Line[lines.size()];
        lines.toArray(lineArr);

        cartInfo.setLines(lineArr);

        context.setCartInfo(cartInfo);
        context.setCaseId(request.getCartInfo().getCaseId());

        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.ADD_SELLER_PRICE,
                request.getCartInfo().getClientAppName());
        //RFEX changes for indirect channel
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                && CartConstants.REX.equalsIgnoreCase(request.getCartInfo().getIntendType())
                && request.getChannelId()!=null && (CartConstants.OMNI_INDIRECT.equalsIgnoreCase(request.getChannelId())
                || CartConstants.OMNI_INDIRECT_TAB.equalsIgnoreCase(request.getChannelId()))) {
            contextInfo.setProcessStep(CartConstants.DOWNPAYMENT);
            contextInfo.setCallReason(CartConstants.SALES_ORDER_ADJUSTMENT);
        }
        else if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessStep())) {
            contextInfo.setProcessStep(request.getCartInfo().getProcessStep());
        }
        else {
            contextInfo.setProcessStep(CartConstants.SHOPPING_CART);
        }
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                && !"EUP".equalsIgnoreCase(request.getCartInfo().getIntendType()))
            contextInfo.setIntent(request.getCartInfo().getIntendType());
        else
            contextInfo.setIntent(CartConstants.UPGRADE);
        context.setContextInfo(contextInfo);
        if (CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())
                || CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
            newCustomerOverride(contextInfo, customerInfo, request.getCartInfo(), request.getChannelId());
        }
        //MVP2-GR
        if(request.getCartInfo()!=null && request.getCartInfo().getCaseId()!=null && request.getCartInfo().getCaseId().startsWith("SOF")){

            logger.info("SalesOrderFlex Prepay update seller price Request before PEGA call setting Call Reason");
            contextInfo.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }
        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);
        return pegaRequest;
    }

    public static AddPlanAndDevicePEGARequest formatValidateAndApplyCouponRequest(AddPlanAndDevicePEGARequest pegaRequest, FWAUpdateCouponUIRequest uiRequest) {
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        serviceHeader.setClientId(uiRequest.getCartInfo().getClientAppName());
        serviceHeader.setStatusMsg(CartConstants.BPM_PEGA_GENERATED_MESSAGE);
        serviceHeader.setServiceName(CartConstants.BPM_SALES_ORDER_PURCHASE);
        serviceHeader.setUserId("");
        serviceHeader.setSessionId(uiRequest.getCartInfo().getSessionId());
        serviceHeader.setCorrelationId(uiRequest.getCartInfo().getCorrelationId());
        pegaRequest.setServiceHeader(serviceHeader);
        AddPlanAndDeviceServiceBody serviceBody = new AddPlanAndDeviceServiceBody();
        AddPlanAndDeviceServiceRequest serviceRequest = new AddPlanAndDeviceServiceRequest();
        AddPlanAndDeviceContext context=new AddPlanAndDeviceContext();
        context.setCaseId(uiRequest.getCartInfo().getCaseId());

        onevz.soe.cart.model.common.FiveG.CartServiceCartInfo cartInfo = new onevz.soe.cart.model.common.FiveG.CartServiceCartInfo();
        cartInfo.setCartId(uiRequest.getCartInfo().getCartId());
        cartInfo.setClientAppName(uiRequest.getCartInfo().getClientAppName());
        cartInfo.setItemType("OFFERCODE");
        cartInfo.setAction(CartConstants.UPDATE);
        
        if (uiRequest.getData().getCouponCode().startsWith("DAW01")) {
            cartInfo.setPromoType("DAW01");
        } else {
            cartInfo.setPromoType("VISIBLE_PREPAID_FWA_COUPON");
        }
        
        cartInfo.setIntendType(uiRequest.getCartInfo().getIntendType());
        cartInfo.setRedemptionCode(uiRequest.getData().getCouponCode());
        cartInfo.setCartId(uiRequest.getCartInfo().getCartId());
        context.setCartInfo(cartInfo);

        onevz.soe.cart.model.common.FiveG.CartServiceCustomerInfo customerInfo = new onevz.soe.cart.model.common.FiveG.CartServiceCustomerInfo();
        customerInfo.setThrottleName(CartConstants.FIVEG_THROTTLE_NAME);
        customerInfo.setAccountNumber(uiRequest.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(uiRequest.getCartInfo().getCartCreator());
        customerInfo.setProcessingMTN(uiRequest.getCartInfo().getProcessingMTN());
        context.setCustomerInfo(customerInfo);

        onevz.soe.cart.model.common.FiveG.CartServiceContextInfo contextInfo = new onevz.soe.cart.model.common.FiveG.CartServiceContextInfo();
        contextInfo.setCallReason(CartConstants.SALES_ORDER_PURCHASE);
        contextInfo.setProcessAction(uiRequest.getCartInfo().getProcessAction());
        contextInfo.setProcessStep(uiRequest.getCartInfo().getProcessStep());
        contextInfo.setAction(uiRequest.getCartInfo().getAction());
        contextInfo.setIntent(uiRequest.getCartInfo().getIntendType());
        context.setContextInfo(contextInfo);
        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);
        return pegaRequest;
    }
    public static AddPlanAndDevicePEGARequest formatMoversPegaRequest(AddPlanAndDevicePEGARequest pegaRequest,
                                                                      AddPlanAndDeviceUIRequest addPlanAndDeviceRequest, boolean isMovOmniReqEnabled) {
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        if(StringUtilities.isNotEmptyOrNull(addPlanAndDeviceRequest.getChannelId())) {
            serviceHeader.setClientId(addPlanAndDeviceRequest.getChannelId());
        }
        serviceHeader.setStatusMsg(CartConstants.BPM_PEGA_GENERATED_MESSAGE);
        serviceHeader.setServiceName(CartConstants.MOVERS_SERVICE_NAME);
        serviceHeader.setUserId("");
        pegaRequest.setServiceHeader(serviceHeader);
        AddPlanAndDeviceServiceBody serviceBody = new AddPlanAndDeviceServiceBody();
        AddPlanAndDeviceServiceRequest serviceRequest = new AddPlanAndDeviceServiceRequest();
        AddPlanAndDeviceContext context=new AddPlanAndDeviceContext();
        onevz.soe.cart.model.common.FiveG.CartServiceContextInfo contextInfo = new onevz.soe.cart.model.common.FiveG.CartServiceContextInfo();
        onevz.soe.cart.model.common.FiveG.CartServiceCustomerInfo customerInfo = new onevz.soe.cart.model.common.FiveG.CartServiceCustomerInfo();
        onevz.soe.cart.model.common.FiveG.CartServiceCartInfo cartInfo = new onevz.soe.cart.model.common.FiveG.CartServiceCartInfo();
        contextInfo.setCallReason(CartConstants.MOVERS_CALLREASON);
        contextInfo.setProcessStep(CartConstants.MOVERS_NEXT_PROCESSSTEP);
        contextInfo.setProcessAction(CartConstants.MOVERS_PROCESSACTION);
        contextInfo.setTransactionType(CartConstants.MOVERS_TRANSACTIONTYPE);
        contextInfo.setIntent(CartConstants.MOVERS_INTENT);
        customerInfo.setFlowType(CartConstants.MOVERS_FLOWTYPE);
        customerInfo.setD2dFlag("N");
        customerInfo.setAccountNumber(addPlanAndDeviceRequest.getCartInfo().getAccountNumber());
        customerInfo.setPlanChangeRequired(addPlanAndDeviceRequest.getCartInfo().getPlanChangeRequired());
        if(addPlanAndDeviceRequest.getData()!=null &&
                addPlanAndDeviceRequest.getData().getLines()!=null &&
                !addPlanAndDeviceRequest.getData().getLines().isEmpty()) {
            String moversMtn = addPlanAndDeviceRequest.getData().getLines().get(0).getMtn();
            customerInfo.setCartCreator(moversMtn);
            customerInfo.setProcessingMTN(moversMtn);
            cartInfo.setCartCreator(moversMtn);
            if(addPlanAndDeviceRequest.getData().getLines().get(0).getFiveG()!=null
                    && addPlanAndDeviceRequest.getData().getLines().get(0).getFiveG().getAddress()!=null)
                cartInfo.setZipCode(addPlanAndDeviceRequest.getData().getLines().get(0).getFiveG().getAddress().getZipCode());
        }

        if(isMovOmniReqEnabled && CartConstants.RETAIL.equalsIgnoreCase(addPlanAndDeviceRequest.getChannelId()) &&
                addPlanAndDeviceRequest.getCartInfo() != null) {
            customerInfo.setCartCreatorSalesRepId(addPlanAndDeviceRequest.getCartInfo().getCartCreatorSalesRepId());
            customerInfo.setCartCreatorOrderLocationCode(addPlanAndDeviceRequest.getCartInfo().getCartCreatorOrderLocationCode());
            customerInfo.setSalesRepUswin(addPlanAndDeviceRequest.getCartInfo().getSalesRepUswin());
        }

        cartInfo.setItemType(CartConstants.MOVERS_ITEMTYPE);
        cartInfo.setIntendType(CartConstants.ACC);
        cartInfo.setAction(CartConstants.UPDATE);
        cartInfo.setClientAppName(addPlanAndDeviceRequest.getChannelId());
        cartInfo.setLines(addPlanAndDeviceRequest.getData().getLines().toArray(new onevz.soe.cart.model.common.FiveG.Line[0]));
        context.setCartInfo(cartInfo);
        context.setContextInfo(contextInfo);
        context.setCustomerInfo(customerInfo);
        context.setAqCaseId(addPlanAndDeviceRequest.getCartInfo().getAqCaseId());
        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);
        return pegaRequest;
    }

    /**
     * @param pegaRequest
     * @param request
     * @return ClearCartPEGARequest
     */
    public static DeleteCartPegaRequest ngdCreateDeleteCartPegaRequest(DeleteCartPegaRequest pegaRequest,
                                                                           DeleteCartUIRequest request, Boolean isSmartPhone) {

        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        serviceHeader = CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(request.getChannelId());
        pegaRequest.setServiceHeader(serviceHeader);

        DeleteCartServiceBody serviceBody = new DeleteCartServiceBody();
        DeleteCartServiceRequest serviceRequest = new DeleteCartServiceRequest();
        DeleteCartContext context = new DeleteCartContext();

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessingMTN())) {
            customerInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());
        }
        else{
            customerInfo.setProcessingMTN("");
        }
        customerInfo.setIsSmartphone(isSmartPhone);

        context.setCustomerInfo(customerInfo);

        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(request.getCartInfo().getCartId());
        cartInfo.setClientAppName(request.getCartInfo().getClientAppName());
        cartInfo.setAction(CartConstants.RESTART);
        cartInfo.setNgdFlow(request.isNgdFlow());
        cartInfo.setIntendType(CartConstants.NSE);

        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        contextInfo.setProcessStep(CartConstants.CONFIGURATOR);
        contextInfo.setIntent(CartConstants.NSE);
        contextInfo.setProcessAction(CartConstants.DELETE_CART);
        contextInfo.setCallReason(CartConstants.SALES_ORDER_PURCHASE);

        newCustomerOverride(contextInfo, customerInfo, request.getCartInfo(), request.getChannelId());

        context.setContextInfo(contextInfo);
        context.setCartInfo(cartInfo);
        context.setCaseId(request.getCartInfo().getCaseId());

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);

        return pegaRequest;
    }


}
