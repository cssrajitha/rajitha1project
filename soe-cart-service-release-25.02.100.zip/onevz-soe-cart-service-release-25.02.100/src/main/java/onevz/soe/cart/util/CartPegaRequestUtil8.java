package onevz.soe.cart.util;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.AccessoryFinancingOffers.AFOContext;
import onevz.soe.cart.model.AccessoryFinancingOffers.AFOServiceBody;
import onevz.soe.cart.model.AccessoryFinancingOffers.AFOServiceRequest;
import onevz.soe.cart.model.AccessoryFinancingOffers.AccessoryFinancingOffersPegaRequest;
import onevz.soe.cart.model.addAccessory.AccessoryAction;
import onevz.soe.cart.model.addDevice.AddPlanAndDeviceContext;
import onevz.soe.cart.model.addDevice.AddPlanAndDeviceServiceBody;
import onevz.soe.cart.model.addDevice.AddPlanAndDeviceServiceRequest;
import onevz.soe.cart.model.addTrialContactInfoAndAddress.*;
import onevz.soe.cart.model.checkExistingCart.CheckExistingCartContext;
import onevz.soe.cart.model.checkExistingCart.CheckExistingCartServiceBody;
import onevz.soe.cart.model.checkExistingCart.CheckExistingCartServiceRequest;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.common.FiveG.Order;
import onevz.soe.cart.model.createCase.*;
import onevz.soe.cart.model.deviceIdValidation.SearchAttributes;
import onevz.soe.cart.model.guestChoice.GuestChoiceContext;
import onevz.soe.cart.model.guestChoice.GuestChoiceServiceBody;
import onevz.soe.cart.model.guestChoice.GuestChoiceServiceRequest;
import onevz.soe.cart.model.initiateValidateDeviceSim.*;
import onevz.soe.cart.model.manualDiscount.ManualDiscountContext;
import onevz.soe.cart.model.manualDiscount.ManualDiscountServiceBody;
import onevz.soe.cart.model.manualDiscount.ManualDiscountServiceRequest;
import onevz.soe.cart.model.updateEffectiveDate.EffectiveDateContext;
import onevz.soe.cart.model.updateEffectiveDate.EffectiveDateServiceBody;
import onevz.soe.cart.model.updateEffectiveDate.EffectiveDateServiceRequest;
import onevz.soe.cart.model.updateGiftItem.UpdateGiftItemContext;
import onevz.soe.cart.model.updateGiftItem.UpdateGiftItemServiceBody;
import onevz.soe.cart.model.updateGiftItem.UpdateGiftItemServiceRequest;
import onevz.soe.cart.requests.*;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.bpm.model.AccessoryFinancingOfferInfo;
import onevz.soe.wsclient.bpm.model.Context;
import onevz.soe.wsclient.bpm.model.request.ContextInfo;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.server.reactive.ServerHttpRequest;

import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.*;

import static onevz.soe.cart.constants.CartConstants.TRANSACTION_TYPE_WIFIBACKUP;

public class CartPegaRequestUtil8 {
    private static final Logger logger = LoggerFactory.getLogger(CartPegaRequestUtil8.class);
    @Value("${enableCradleForExistingCustomer:true}")
    private static boolean enableCradleForExistingCustomer;


    public static AddPlanAndDevicePEGARequest formatAddPlanAndDeviceRequest(AddPlanAndDevicePEGARequest pegaRequest,
                                                                            AddPlanAndDeviceUIRequest addPlanAndDeviceRequest) {
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        serviceHeader.setClientId(addPlanAndDeviceRequest.getChannelId());
        serviceHeader.setStatusMsg(CartConstants.BPM_PEGA_GENERATED_MESSAGE);
        serviceHeader.setServiceName(CartConstants.BPM_SALES_ORDER_PURCHASE);
        serviceHeader.setUserId("");
        serviceHeader.setCorrelationId(addPlanAndDeviceRequest.getCartInfo().getCorrelationId());
        pegaRequest.setServiceHeader(serviceHeader);
        AddPlanAndDeviceServiceBody serviceBody = new AddPlanAndDeviceServiceBody();
        AddPlanAndDeviceServiceRequest serviceRequest = new AddPlanAndDeviceServiceRequest();
        AddPlanAndDeviceContext context=new AddPlanAndDeviceContext();
        onevz.soe.cart.model.common.FiveG.CartServiceCartInfo cartInfo = new onevz.soe.cart.model.common.FiveG.CartServiceCartInfo();
        cartInfo.setCartId(addPlanAndDeviceRequest.getCartInfo().getCartId());
        cartInfo.setClientAppName(addPlanAndDeviceRequest.getCartInfo().getClientAppName());
        cartInfo.setItemType("DEVICE");
        /*MVP2A*/
        if (CartConstants.EUP_5G.equalsIgnoreCase(addPlanAndDeviceRequest.getCartInfo().getIntendType())) {
            cartInfo.setAction("upgradeNow");
            cartInfo.setTransactionType(CartConstants.REPAIRGEN2TOGEN3);
        } else {
            cartInfo.setAction(CartConstants.UPDATE);
        }

        /*MVP2*/
        if("orderNow".equalsIgnoreCase(addPlanAndDeviceRequest.getCartInfo().getProcessStep()) && CartConstants.RESUME.equalsIgnoreCase(addPlanAndDeviceRequest.getCartInfo().getAction())){
            cartInfo.setItemType("RESUME");
        }
        cartInfo.setUpdateShippingAddress(addPlanAndDeviceRequest.getCartInfo().isUpdateShippingAddress());
        cartInfo.setIntendType(addPlanAndDeviceRequest.getCartInfo().getIntendType());
        if(StringUtilities.isNotEmptyOrNull(addPlanAndDeviceRequest.getCartInfo().getFiveGMUCEligible()))
            cartInfo.setFiveGMUCEligible(addPlanAndDeviceRequest.getCartInfo().getFiveGMUCEligible());

        /*MVP2-NSE*/
        if(StringUtils.isNotEmpty(addPlanAndDeviceRequest.getCartInfo().getZipCode())){
            cartInfo.setZipCode(addPlanAndDeviceRequest.getCartInfo().getZipCode());
        }
        onevz.soe.cart.model.common.FiveG.CartServiceCustomerInfo customerInfo = new onevz.soe.cart.model.common.FiveG.CartServiceCustomerInfo();
        //Tech CBand Changes
        if(CartConstants.CBAND_TECHNICIAN.equalsIgnoreCase(addPlanAndDeviceRequest.getCartInfo().getTransactionType())) {
            customerInfo.setCartCreatorSalesRepId(addPlanAndDeviceRequest.getCBandData().getSalesRepId());
            cartInfo.setOutletId(addPlanAndDeviceRequest.getCBandData().getOutletId());
            cartInfo.setTransactionType(CartConstants.CBAND_TECHNICIAN);
            List<Order> prevOrders =  new ArrayList<>(1);
            Order prevOrder = new Order();
            prevOrder.setOrderNumber(addPlanAndDeviceRequest.getCBandData().getOrderNum());
            prevOrder.setLocationCode(addPlanAndDeviceRequest.getCBandData().getLocationCode());
            prevOrder.setMtn(addPlanAndDeviceRequest.getMtn());
            prevOrders.add(prevOrder);
            Order[] prevOrderPega = new Order[1];
            cartInfo.setOrderList(prevOrders.toArray(prevOrderPega));
        }
        if (addPlanAndDeviceRequest.getData() != null
                && addPlanAndDeviceRequest.getData().getLines() != null) {
            List<onevz.soe.cart.model.common.FiveG.Line> lines = addPlanAndDeviceRequest.getData().getLines();
            if (null != lines && lines.size() > 0) {
                if (CartConstants.CBAND_TECHNICIAN.equalsIgnoreCase(addPlanAndDeviceRequest.getCartInfo().getTransactionType())) {
                    onevz.soe.cart.model.common.FiveG.Line[] lines1 = new onevz.soe.cart.model.common.FiveG.Line[lines.size()];
                    lines.forEach(line -> {
                        line.getDevice().setDefaultPlanType(addPlanAndDeviceRequest.getCBandData().getFiveGPlan());
                    });
                    lines.toArray(lines1);
                    cartInfo.setLines(lines1);
                } else {
                    onevz.soe.cart.model.common.FiveG.Line[] lines1 = new onevz.soe.cart.model.common.FiveG.Line[lines.size()];
                    lines.forEach(line -> {
                        if (null != addPlanAndDeviceRequest && addPlanAndDeviceRequest.getCartInfo() != null && CartConstants.ORDER_NOW.equalsIgnoreCase(addPlanAndDeviceRequest.getCartInfo().getProcessStep())
                                && CartConstants.DEVICE_AND_PLAN.equalsIgnoreCase(addPlanAndDeviceRequest.getCartInfo().getProcessAction())
                                && null != addPlanAndDeviceRequest.getCartInfo().getJointCombo() && addPlanAndDeviceRequest.getCartInfo().getJointCombo().equalsIgnoreCase("Y"))
                            line.setMtn("");
                    });
                    lines.toArray(lines1);
                    cartInfo.setLines(lines1);

                }
                if (addPlanAndDeviceRequest.getPreOrderInServiceDate() != null && addPlanAndDeviceRequest.getMarket() != null) {
                    Arrays.stream(cartInfo.getLines()).forEach(line -> {
                        line.getFiveG().setMarket(addPlanAndDeviceRequest.getMarket());
                        line.getFiveG().setPreOrderInServiceDate(addPlanAndDeviceRequest.getPreOrderInServiceDate());
                    });
                }
            }
        }
        
     // sequential combo flow
        if (null != addPlanAndDeviceRequest && null != addPlanAndDeviceRequest.getCartInfo() && null != addPlanAndDeviceRequest.getCartInfo().getIsSequentialComboOrder() && addPlanAndDeviceRequest.getCartInfo().getIsSequentialComboOrder()) {
            cartInfo.setIsSequentialComboOrder(true);
            onevz.soe.cart.model.common.FiveG.FwaComboOrderDetails[] FwaComboOrderDetailsList = new onevz.soe.cart.model.common.FiveG.FwaComboOrderDetails[1];
            onevz.soe.cart.model.common.FiveG.FwaComboOrderDetails fwaComboOrderDetails = new onevz.soe.cart.model.common.FiveG.FwaComboOrderDetails();
            fwaComboOrderDetails.setMobilityCartId(addPlanAndDeviceRequest.getCartInfo().getMobilityCartId());
            fwaComboOrderDetails.setMobilityOrderNo(addPlanAndDeviceRequest.getCartInfo().getMobilityOrderNo());
            fwaComboOrderDetails.setMobilityLocationCode(addPlanAndDeviceRequest.getCartInfo().getMobilityLocationCode());
            fwaComboOrderDetails.setMobilityCreditApplicationNum(addPlanAndDeviceRequest.getCartInfo().getMobilityCreditApplicationNum());
            FwaComboOrderDetailsList[0] = fwaComboOrderDetails;
            cartInfo.setFwaComboOrderDetails(FwaComboOrderDetailsList);
        }

        onevz.soe.cart.model.common.FiveG.CartServiceContextInfo contextInfo = new onevz.soe.cart.model.common.FiveG.CartServiceContextInfo();
        
        if (CartConstants.EUP_5G.equalsIgnoreCase(addPlanAndDeviceRequest.getCartInfo().getIntendType())) {
            customerInfo.setProcessingMTN(addPlanAndDeviceRequest.getCartInfo().getCartCreator());
            customerInfo.setD2dFlag("N");
        } else if (CartConstants.ORDER_NOW.equalsIgnoreCase(addPlanAndDeviceRequest.getCartInfo().getProcessStep()) && CartConstants.DEVICE_AND_PLAN.equalsIgnoreCase(addPlanAndDeviceRequest.getCartInfo().getProcessAction())
            && addPlanAndDeviceRequest.getCartInfo().getJointCombo() != null && addPlanAndDeviceRequest.getCartInfo().getJointCombo().equalsIgnoreCase("Y")) {
                //Joint transaction flow to set ProcessMtn
            customerInfo.setProcessingMTN("");
        } else {
            customerInfo.setProcessingMTN(addPlanAndDeviceRequest.getCartInfo().getProcessingMTN());
        }
        customerInfo.setAccountNumber(addPlanAndDeviceRequest.getCartInfo().getAccountNumber());
        customerInfo.setRegisterNumber(addPlanAndDeviceRequest.getCartInfo().getRegisterNumber());
        customerInfo.setThrottleName(CartConstants.FIVEG_THROTTLE_NAME);
        customerInfo.setCartCreator(addPlanAndDeviceRequest.getCartInfo().getCartCreator());
        customerInfo.setD2dFlag(addPlanAndDeviceRequest.getCartInfo().getD2dFlag());
        customerInfo.setSalesRepID(addPlanAndDeviceRequest.getCartInfo().getSalesRepId());
        customerInfo.setCartCreatorOrderLocationCode(addPlanAndDeviceRequest.getCartInfo().getCartCreatorOrderLocationCode());
        customerInfo.setFwaReferralLocationCode(addPlanAndDeviceRequest.getCartInfo().getCartCreatorOrderLocationCode());
        customerInfo.setFwaReferralVendorId(addPlanAndDeviceRequest.getCartInfo().getReferralVendorId());
        customerInfo.setFwaReferralOutletId(addPlanAndDeviceRequest.getCartInfo().getOutletId());
        customerInfo.setFlowType(addPlanAndDeviceRequest.getCartInfo().getFlowType());
        if(StringUtilities.isNotEmptyOrNull(addPlanAndDeviceRequest.getCartInfo().getRylEcpdUrl())
                && StringUtilities.isNotEmptyOrNull(addPlanAndDeviceRequest.getCartInfo().getEcpdToken())) {
            customerInfo.setRylEcpdUrl(addPlanAndDeviceRequest.getCartInfo().getRylEcpdUrl());
            customerInfo.setEcpdToken(addPlanAndDeviceRequest.getCartInfo().getEcpdToken());
        }
        if(addPlanAndDeviceRequest.getData() != null && addPlanAndDeviceRequest.getData().getEligible5GHomeBundle() != null) {
            cartInfo.setEligible5GHomeBundle(addPlanAndDeviceRequest.getData().getEligible5GHomeBundle());
        }
        if(addPlanAndDeviceRequest.getData() != null && addPlanAndDeviceRequest.getData().getLines()!=null && addPlanAndDeviceRequest.getData().getLines().size()>0){
            addPlanAndDeviceRequest.getData().getLines().stream().filter(Objects::nonNull).findFirst().ifPresent(line -> {
                if(null != line.getE911Address()) {
                    customerInfo.setENineAddrIndicator("true");
                    customerInfo.setHomePhone(true);
                }
            });
        }

        context.setCaseId(addPlanAndDeviceRequest.getCartInfo().getCaseId());
        context.setAqCaseId(addPlanAndDeviceRequest.getCartInfo().getAqCaseId());
        context.setCartInfo(cartInfo);
        contextInfo.setCallReason(CartConstants.SALES_ORDER_PURCHASE);
        if (addPlanAndDeviceRequest.getCartInfo() != null && addPlanAndDeviceRequest.getCartInfo().getProcessAction() != null){
            contextInfo.setProcessAction(addPlanAndDeviceRequest.getCartInfo().getProcessAction());
        }
        /*MVP2*/
        if("orderNow".equalsIgnoreCase(addPlanAndDeviceRequest.getCartInfo().getProcessStep()) && CartConstants.RESUME.equalsIgnoreCase(addPlanAndDeviceRequest.getCartInfo().getAction())){
            contextInfo.setProcessAction("");
        }
        contextInfo.setAction(addPlanAndDeviceRequest.getCartInfo().getAction());
        contextInfo.setIntent(addPlanAndDeviceRequest.getCartInfo().getIntendType());
        if(addPlanAndDeviceRequest.getTransactionType() != null){
            contextInfo.setTransactionType(addPlanAndDeviceRequest.getTransactionType());
        }else{
            contextInfo.setTransactionType(addPlanAndDeviceRequest.getCartInfo().getTransactionType());
        }
        if (CartConstants.EUP_5G.equalsIgnoreCase(addPlanAndDeviceRequest.getCartInfo().getIntendType())) {
            contextInfo.setTransactionType(CartConstants.REPAIRGEN2TOGEN3);
        }
        if(CartConstants.EUP_5G.equalsIgnoreCase(addPlanAndDeviceRequest.getCartInfo().getIntendType()) &&
                CartConstants.LTE_CBD_TRANSACTIONTYPE.equalsIgnoreCase(addPlanAndDeviceRequest.getCartInfo().getTransactionType())){
            contextInfo.setTransactionType(addPlanAndDeviceRequest.getCartInfo().getTransactionType());
            cartInfo.setAction(CartConstants.UPDATE);
            cartInfo.setUpgradeReasonCode("UN");
            cartInfo.setTransactionType(addPlanAndDeviceRequest.getCartInfo().getTransactionType());
            cartInfo.setOutletId(addPlanAndDeviceRequest.getCBandData().getOutletId());
            customerInfo.setProcessingMTN(addPlanAndDeviceRequest.getCartInfo().getProcessingMTN());
        }
        contextInfo.setProcessStep(addPlanAndDeviceRequest.getCartInfo().getProcessStep());
        context.setContextInfo(contextInfo);

        if(CartConstants.NSE_5G.equalsIgnoreCase(cartInfo.getIntendType()) || CartConstants.NSE_LTE.equalsIgnoreCase(cartInfo.getIntendType())){
            customerInfo.setCustomerType("N");
            customerInfo.setGlobalId(addPlanAndDeviceRequest.getCartInfo().getCartCreator());
            customerInfo.setEmailId(addPlanAndDeviceRequest.getEmailAddress());
            customerInfo.setCbr(addPlanAndDeviceRequest.getCbr());
        }
        if(addPlanAndDeviceRequest.getCartInfo() != null
                && addPlanAndDeviceRequest.getCartInfo().getFlowType() != null
                && CartConstants.FLOW_TYPE_WHW.equalsIgnoreCase(addPlanAndDeviceRequest.getCartInfo().getFlowType()) ){
            customerInfo.setCartCreator(addPlanAndDeviceRequest.getCartInfo().getProcessingMTN());
            contextInfo.setIntent(addPlanAndDeviceRequest.getCartInfo().getIntent());
            contextInfo.setProcessAction("");
            context.setContextInfo(contextInfo);
        }
        //MVP2-GR
        if(addPlanAndDeviceRequest.getCartInfo()!=null && addPlanAndDeviceRequest.getCartInfo().getCaseId()!=null &&
                addPlanAndDeviceRequest.getCartInfo().getCaseId().startsWith("SOF")){

            logger.info("SalesOrderFlex Prepay add plan and device Request before PEGA call setting Call Reason");
            contextInfo.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }
        //WifiBackup Changes
            getWifiBackupTransactionType(cartInfo,addPlanAndDeviceRequest);

        context.setCustomerInfo(customerInfo);
        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);
        return pegaRequest;

    }
    public static void getWifiBackupTransactionType(onevz.soe.cart.model.common.FiveG.CartServiceCartInfo cartInfo, AddPlanAndDeviceUIRequest addPlanAndDeviceRequest){
        if(addPlanAndDeviceRequest.getCartInfo().getTransactionType()!= null &&
                TRANSACTION_TYPE_WIFIBACKUP.equalsIgnoreCase(addPlanAndDeviceRequest.getCartInfo().getTransactionType())){
            cartInfo.setTransactionType(TRANSACTION_TYPE_WIFIBACKUP);
        }
    }
    public static ManualDiscountPEGARequest formatManualDiscountRequest(ManualDiscountPEGARequest pegaRequest2,
                                                                        UpdateManualDiscountUIRequest uiRequest2) {

        CartServiceServiceHeader serviceHeader2 = new CartServiceServiceHeader();
        serviceHeader2 = CartPegaRequestUtil.addServiceHeader(serviceHeader2);
        serviceHeader2.setClientId(uiRequest2.getChannelId());
        serviceHeader2.setServiceName(CartConstants.SALES_ORDER_PURCHASE);

        pegaRequest2.setServiceHeader(serviceHeader2);

        ManualDiscountServiceBody serviceBody2 = new ManualDiscountServiceBody();
        ManualDiscountServiceRequest serviceRequest2 = new ManualDiscountServiceRequest();
        ManualDiscountContext context2 = new ManualDiscountContext();

        CartServiceCustomerInfo customerInfo2 = new CartServiceCustomerInfo();
        customerInfo2.setAccountNumber(uiRequest2.getCartInfo().getAccountNumber());
        customerInfo2.setCartCreator(uiRequest2.getCartInfo().getCartCreator());
        customerInfo2.setProcessingMTN(uiRequest2.getCartInfo().getProcessingMTN());
        if(CartConstants.NSE.equalsIgnoreCase(uiRequest2.getCartInfo().getIntendType()) )
            customerInfo2.setOriginalCreditApprovalNumber(uiRequest2.getCartInfo().getCartCreator());



        CartServiceCartInfo cartInfo2 = new CartServiceCartInfo();
        cartInfo2.setCartId(uiRequest2.getCartInfo().getCartId());
        cartInfo2.setItemType("MANUALDISCOUNT");
        if (StringUtilities.isNotEmptyOrNull(uiRequest2.getCartInfo().getIntendType()))
            cartInfo2.setIntendType(uiRequest2.getCartInfo().getIntendType());
        if (StringUtilities.isNotEmptyOrNull(uiRequest2.getCartInfo().getAction()))
            cartInfo2.setAction(uiRequest2.getCartInfo().getAction());


        CartServiceContextInfo contextInfo2 = new CartServiceContextInfo();

        if (CartConstants.NSE_BYOD.equalsIgnoreCase(uiRequest2.getCartInfo().getIntendType())
                || CartConstants.NSE.equalsIgnoreCase(uiRequest2.getCartInfo().getIntendType())) {
            CartPegaRequestUtil7.newCustomerOverride(contextInfo2, customerInfo2, uiRequest2.getCartInfo(), uiRequest2.getChannelId());
        }
        if (StringUtilities.isNotEmptyOrNull(uiRequest2.getCartInfo().getIntendType())) {
            if ("EUP".equalsIgnoreCase(uiRequest2.getCartInfo().getIntendType()))
                contextInfo2.setIntent(CartConstants.UPGRADE);
            else
                contextInfo2.setIntent(uiRequest2.getCartInfo().getIntendType());
        }
        if (StringUtilities.isNotEmptyOrNull(uiRequest2.getCartInfo().getProcessStep()))
            contextInfo2.setProcessStep(uiRequest2.getCartInfo().getProcessStep());

        contextInfo2.setProcessAction(CartConstants.ADD_MANUAL_DISCOUNT);
        contextInfo2.setCallReason(CartConstants.SALES_ORDER_PURCHASE);

        if (StringUtilities.isNotEmptyOrNull(uiRequest2.getCartInfo().getIntendType()) && uiRequest2.getCartInfo().getIntendType().equalsIgnoreCase(CartConstants.REFUND_EXCHANGE)) {
            contextInfo2.setIntent(CartConstants.REX);
            contextInfo2.setCallReason(CartConstants.SALES_ORDER_ADJUSTMENT);
            serviceHeader2.setServiceName(CartConstants.SALES_ORDER_ADJUSTMENT);
        }

        List<Line> lines = new ArrayList<>();

        for (Lines reqLine : uiRequest2.getData().getLines()) {
            Line newLine2 = new Line();
            if (reqLine.getMtn() != null)
                newLine2.setMtn(reqLine.getMtn());
            if(reqLine.getManualDiscount() != null)
                newLine2.setManualDiscount(reqLine.getManualDiscount());

            lines.add(newLine2);
        }
        Line[] lineArr = new Line[lines.size()];
        lines.toArray(lineArr);

        cartInfo2.setLines(lineArr);

        context2.setCustomerInfo(customerInfo2);

        context2.setContextInfo(contextInfo2);
        context2.setCartInfo(cartInfo2);
        context2.setCaseId(uiRequest2.getCartInfo().getCaseId());

        //MVP2-GR
        if(uiRequest2.getCartInfo()!=null && uiRequest2.getCartInfo().getCaseId()!=null && uiRequest2.getCartInfo().getCaseId().startsWith("SOF")){

            logger.info("SalesOrderFlex Prepay add manual discount Request before PEGA call setting Call Reason");
            contextInfo2.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader2.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }

        serviceRequest2.setContext(context2);
        serviceBody2.setServiceRequest(serviceRequest2);
        pegaRequest2.setServiceBody(serviceBody2);

        return pegaRequest2;
    }

    public static EffectiveDatePEGARequest formatEffectiveDateRequest(EffectiveDatePEGARequest pegaRequest,
                                                                      UpdateEffectiveDateUIRequest uiRequest) {

        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(uiRequest.getChannelId());
        serviceHeader.setServiceName(CartConstants.SALES_ORDER_PURCHASE);

        pegaRequest.setServiceHeader(serviceHeader);

        EffectiveDateServiceBody serviceBody = new EffectiveDateServiceBody();
        EffectiveDateServiceRequest serviceRequest = new EffectiveDateServiceRequest();
        EffectiveDateContext context = new EffectiveDateContext();

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(uiRequest.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(uiRequest.getCartInfo().getCartCreator());
        customerInfo.setProcessingMTN(uiRequest.getCartInfo().getProcessingMTN());
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(uiRequest.getCartInfo().getCartId());
        cartInfo.setItemType("EFFECTIVEDATE");
        if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getIntendType()))
            cartInfo.setIntendType(uiRequest.getCartInfo().getIntendType());
        if(StringUtilities.isNotEmptyOrNull(uiRequest.getEffectiveDate()))
            cartInfo.setEffectiveDate(uiRequest.getEffectiveDate());


        CartServiceContextInfo contextInfo = new CartServiceContextInfo();

        if (CartConstants.NSE_BYOD.equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())
                || CartConstants.NSE.equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())) {
            CartPegaRequestUtil7.newCustomerOverride(contextInfo, customerInfo, uiRequest.getCartInfo(), uiRequest.getChannelId());
        }


        if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getIntendType())) {
            if ("EUP".equalsIgnoreCase(uiRequest.getCartInfo().getIntendType()))
                contextInfo.setIntent(CartConstants.UPGRADE);
            else
                contextInfo.setIntent(uiRequest.getCartInfo().getIntendType());
        }

        if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getProcessStep()))
            contextInfo.setProcessStep(uiRequest.getCartInfo().getProcessStep());

        contextInfo.setProcessAction(CartConstants.ADD_EFFECTIVE_DATE);

        contextInfo.setCallReason(CartConstants.SALES_ORDER_PURCHASE);


        context.setCustomerInfo(customerInfo);
        context.setContextInfo(contextInfo);
        context.setCartInfo(cartInfo);
        context.setCaseId(uiRequest.getCartInfo().getCaseId());

        //MVP2-GR
        if(uiRequest.getCartInfo()!=null && uiRequest.getCartInfo().getCaseId()!=null && uiRequest.getCartInfo().getCaseId().startsWith("SOF")){

            logger.info("SalesOrderFlex Prepay effective date  Request before PEGA call setting Call Reason");
            contextInfo.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);

        return pegaRequest;
    }
    /*MVP2*/
    public static AddPlanAndDevicePEGARequest formatSaveCartWithEmailRequest(AddPlanAndDevicePEGARequest pegaRequest,
                                                                             SaveCartWithEmailUIRequest addPlanAndDeviceRequest) {

        // TODO: move all constants to CartConstants file
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        serviceHeader.setStatusMsg(CartConstants.BPM_PEGA_GENERATED_MESSAGE);
        serviceHeader.setServiceName(CartConstants.BPM_SALES_ORDER_PURCHASE);
        serviceHeader.setUserId("");
        serviceHeader.setCorrelationId(addPlanAndDeviceRequest.getCartInfo().getGlobalId());
        pegaRequest.setServiceHeader(serviceHeader);
        AddPlanAndDeviceServiceBody serviceBody = new AddPlanAndDeviceServiceBody();
        AddPlanAndDeviceServiceRequest serviceRequest = new AddPlanAndDeviceServiceRequest();
        Context context = new Context();
        onevz.soe.cart.model.common.FiveG.CartServiceCartInfo cartInfo = new onevz.soe.cart.model.common.FiveG.CartServiceCartInfo();
        cartInfo.setCartId(addPlanAndDeviceRequest.getCartInfo().getCartId());
        cartInfo.setClientAppName(addPlanAndDeviceRequest.getCartInfo().getClientAppName());

        cartInfo.setItemType(CartConstants.SAVE_CART.toUpperCase());
        cartInfo.setIntendType(addPlanAndDeviceRequest.getCartInfo().getIntendType());
        cartInfo.setSaveCartEmailId(addPlanAndDeviceRequest.getEmailId());
        cartInfo.setCartSavedByCustomer(true);

        onevz.soe.cart.model.common.FiveG.CartServiceCustomerInfo customerInfo = new onevz.soe.cart.model.common.FiveG.CartServiceCustomerInfo();
        customerInfo.setAccountNumber(addPlanAndDeviceRequest.getCartInfo().getAccountNumber());
        customerInfo.setProcessingMTN(addPlanAndDeviceRequest.getCartInfo().getProcessingMTN());
        customerInfo.setRegisterNumber(0);
        customerInfo.setThrottleName("|HOMESAFETY_TRIAL_WITHOUT_MTNS|TEC_DEFAULT|PROSPECT_PDP_REDESIGN|NSA_REDIRECT_TH_PROSPECT_GW_PDP|A_BAU_C_ccessoryInterestialProspect|");
        customerInfo.setCartCreator(addPlanAndDeviceRequest.getCartInfo().getCartCreator());

        context.setCaseId(addPlanAndDeviceRequest.getCartInfo().getCaseId());
        context.setCartInfo(cartInfo);
        ContextInfo contextInfo = new ContextInfo();
        contextInfo.setCallReason(CartConstants.SALES_ORDER_PURCHASE);
        contextInfo.setProcessAction("saveCartEmailId");
        contextInfo.setAction("");
        contextInfo.setIntent(addPlanAndDeviceRequest.getCartInfo().getIntendType());
        contextInfo.setProcessStep("ShoppingCart");
        context.setContextInfo(contextInfo);
        if(CartConstants.NSE_5G.equalsIgnoreCase(cartInfo.getIntendType()) || CartConstants.NSE_LTE.equalsIgnoreCase(cartInfo.getIntendType())){
            customerInfo.setCustomerType("N");/*MVP2 add a condn and set only if action is not resume*/
            customerInfo.setGlobalId(addPlanAndDeviceRequest.getCartInfo().getCartCreator());

        }

        context.setCustomerInfo(customerInfo);

        //MVP2-GR
        if(addPlanAndDeviceRequest.getCartInfo()!=null && addPlanAndDeviceRequest.getCartInfo().getCaseId()!=null &&
                addPlanAndDeviceRequest.getCartInfo().getCaseId().startsWith("SOF")){

            logger.info("SalesOrderFlex Prepay save cart with email  Request before PEGA call setting Call Reason");
            contextInfo.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);
        return pegaRequest;

    }


    //VZWYN-20895 changes
    public static InitiateValidateDeviceSimPEGARequest formatInitiateValidateDeviceSimRequest(InitiateValidateDeviceSimPEGARequest pegaRequest,
                                                                                              InitiateValidateDeviceSimUIRequest request, ServerHttpRequest httpHeader, CartRedisData redisData) {


        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader);
        if(httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID))
            serviceHeader.setClientId(httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID));
        pegaRequest.setServiceHeader(serviceHeader);

        InitiateValidateDeviceSimServiceBody serviceBody = new InitiateValidateDeviceSimServiceBody();
        InitiateValidateDeviceSimServiceRequest serviceRequest = new InitiateValidateDeviceSimServiceRequest();
        InitiateValidateDeviceSimContext context = new InitiateValidateDeviceSimContext();
        CartServiceContextInfo contextInfo = new CartServiceContextInfo();

        InitiateValidateDeviceSimCustomerInfo customerInfo = new InitiateValidateDeviceSimCustomerInfo();
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId("");
        //VZWYN-22202 - changes for displaying existing CCAR lines
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID) ?
                httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID) : "";
        if(StringUtilities.isNotEmptyOrNull(channelId) && CartConstants.CHANNEL_ID_BBP.equalsIgnoreCase(channelId) && null != request.getData().getIsConnectedCarRequired())
            cartInfo.setIsConnectedCarRequired(request.getData().getIsConnectedCarRequired());
        context.setCartInfo(cartInfo);

        if (httpHeader.getHeaders().containsKey(CartConstants.ACCOUNT_NUMBER)) {
            String acc = httpHeader.getHeaders().getFirst(CartConstants.ACCOUNT_NUMBER);
            assert acc != null;
            String accountNumber = acc.replaceAll("--+","-");
            customerInfo.setAccountNumber(accountNumber);
        }
        if (httpHeader.getHeaders().containsKey("mtn"))
            customerInfo.setCartCreator(httpHeader.getHeaders().getFirst("mtn"));

        customerInfo.setThrottleName("|");
        customerInfo.setBucketAllocator("BAU");
        context.setCustomerInfo(customerInfo);

        contextInfo.setCallReason(CartConstants.SALES_ORDER_PURCHASE);
        contextInfo.setIntent(request.getData().getIntendType());
        contextInfo.setProcessAction(request.getData().getProcessAction());
        contextInfo.setProcessStep(request.getData().getProcessStep());

        context.setContextInfo(contextInfo);

        Line[] lines = new Line[1];
        lines[0] = new Line();
        Device device = new Device();
        if(null != redisData && StringUtilities.isNotEmptyOrNull(redisData.getImei())){
            device.setId(redisData.getImei());
        }
        device.setFlowtype(CartConstants.DEVICE_TYPE);
        device.setIsCustomerProvidedEquipment(true);
        device.setSmartIMEI(false);
        SearchAttributes searchAttributes = new SearchAttributes();
        searchAttributes.setPostPaidInd(request.getData().getPostPaidInd());
        device.setSearchAttributes(searchAttributes);
        SoftSKUItem sim = new SoftSKUItem();
        sim.setIsCustomerProvidedSIM(false);
        if(null != redisData && StringUtilities.isNotEmptyOrNull(redisData.getIccid())){
            sim.setId(redisData.getIccid());
        }
        device.setSim(sim);
        if(httpHeader.getHeaders().containsKey("mtn")) {
            lines[0].setMtn(httpHeader.getHeaders().getFirst("mtn"));
        }
        lines[0].setDevice(device);
        context.setLines(lines);

        context.setCaseId("");
        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);

        return pegaRequest;

    }

    /***
     *
     * @param pegaRequest
     * @param cartId
     * @param sessionId
     * @param emailId
     * @param customerType
     */
    public static void formatCrmRetrieveCartRequest(AddPlanAndDevicePEGARequest pegaRequest,String cartId,String sessionId,String emailId,
                                                    String customerType,String accountNumber){
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        serviceHeader.setStatusMsg(CartConstants.BPM_PEGA_GENERATED_MESSAGE);
        serviceHeader.setServiceName("GetCases");
        serviceHeader.setUserId("");
        pegaRequest.setServiceHeader(serviceHeader);

        AddPlanAndDeviceServiceBody serviceBody = new AddPlanAndDeviceServiceBody();
        AddPlanAndDeviceServiceRequest serviceRequest = new AddPlanAndDeviceServiceRequest();
        Context context = new Context();
        onevz.soe.cart.model.common.FiveG.CartServiceCustomerInfo customerInfo = new onevz.soe.cart.model.common.FiveG.CartServiceCustomerInfo();

        customerInfo.setCartId(cartId);
        customerInfo.setCustomerType(customerType);
        customerInfo.setAccountNumber(accountNumber);
        customerInfo.setGlobalId(sessionId);
        customerInfo.setCartCreator(sessionId);
        customerInfo.setEmailId(emailId);
        context.setCustomerInfo(customerInfo);

        ContextInfo contextInfo = new ContextInfo();
        contextInfo.setCallReason(CartConstants.SALES_ORDER_PURCHASE);
        contextInfo.setProcessAction("retrieveCartInfo");
        context.setContextInfo(contextInfo);

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);

    }
    /**
     * @param pegaRequest
     * @param request
     * @return CreateCasePEGARequest
     */
    public static CreateCasePEGARequest formatCreateCaseRequest(CreateCasePEGARequest pegaRequest,
                                                                CreateCaseAndGetCustomerInfoUIRequest request, ServerHttpRequest httpHeader) {

        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(request.getChannelId());
        serviceHeader.setServiceName("SuspendReconnect");
        pegaRequest.setServiceHeader(serviceHeader);

        CreateCaseServiceBody serviceBody = new CreateCaseServiceBody();
        CreateCaseServiceRequest serviceRequest = new CreateCaseServiceRequest();
        CreateCaseContext context = new CreateCaseContext();
        CreateCaseContextInfo contextInfo = new CreateCaseContextInfo();

        CreateCaseCustomerInfo customerInfo = new CreateCaseCustomerInfo();
        if (httpHeader.getHeaders().containsKey(CartConstants.ACCOUNT_NUMBER)) {
            String acc = httpHeader.getHeaders().getFirst(CartConstants.ACCOUNT_NUMBER);
            assert acc != null;
            String accountNumber = acc.replaceAll("--+","-");
            customerInfo.setAccountNumber(accountNumber);
        }
        if (httpHeader.getHeaders().containsKey("mtn"))
            customerInfo.setMtn(httpHeader.getHeaders().getFirst("mtn"));

        context.setCustomerInfo(customerInfo);

        contextInfo.setCallReason("OnlineDisconnect");
        contextInfo.setIntent(request.getIntent());
        contextInfo.setProcessAction(request.getProcessAction());
        contextInfo.setProcessStep(request.getProcessStep());

        context.setContextInfo(contextInfo);

        context.setCaseId("");

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);

        return pegaRequest;

    }

    /**
     * @param pegaRequest
     * @param uiRequest
     */
    public static void formatGuestChoiceRequest(GuestChoiceUIRequest uiRequest, GuestChoicePEGARequest pegaRequest) {

        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(uiRequest.getChannelId());
        GuestChoiceServiceBody serviceBody = new GuestChoiceServiceBody();
        GuestChoiceServiceRequest serviceRequest = new GuestChoiceServiceRequest();
        GuestChoiceContext context = new GuestChoiceContext();
        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getCaseId()))
            context.setCaseId(uiRequest.getCartInfo().getCaseId());
        if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getAccountNumber()))
            customerInfo.setAccountNumber(uiRequest.getCartInfo().getAccountNumber());
        if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getCartCreator()))
            customerInfo.setCartCreator(uiRequest.getCartInfo().getCartCreator());
        if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getProcessingMTN()))
            customerInfo.setProcessingMTN(uiRequest.getCartInfo().getProcessingMTN());
        if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getGlobalId()))
            customerInfo.setGlobalId(uiRequest.getCartInfo().getGlobalId());
        customerInfo.setOriginalCreditApprovalNumber("");
        if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getCustomerType()))
            customerInfo.setCustomerType(uiRequest.getCartInfo().getCustomerType());
        customerInfo.setEditFromPage("");
        customerInfo.setStandaloneBYOD(false);
        if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getIntendType())
                && CartConstants.NSEACC.equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())
                && StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getIntent())
                && CartConstants.STANDALONEACCESSORY.equalsIgnoreCase(uiRequest.getCartInfo().getIntent())) {
            customerInfo.setStandaloneAccessory(true);
        }
        customerInfo.setBucketAllocator("BAU");
        customerInfo.setThrottleList("|SPLIT_FULFILLMENT|");
        customerInfo.setCradleFlowJourney("");
        customerInfo.setSiteId("");
        customerInfo.setLocationCode("");
        customerInfo.setCartCreatorSalesRepId("");
        if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getFlowType()))
            customerInfo.setFlowType(uiRequest.getCartInfo().getFlowType());
        context.setCustomerInfo(customerInfo);
        if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getCartId()))
            cartInfo.setCartId(uiRequest.getCartInfo().getCartId());
        context.setCartInfo(cartInfo);
        contextInfo.setCallReason(CartConstants.SALES_ORDER_PURCHASE);
        if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getIntent()))
            contextInfo.setIntent(uiRequest.getCartInfo().getIntent());
        if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getProcessAction()))
            contextInfo.setProcessAction(uiRequest.getCartInfo().getProcessAction());
        if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getProcessStep()))
            contextInfo.setProcessStep(uiRequest.getCartInfo().getProcessStep());
        context.setContextInfo(contextInfo);
        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceHeader(serviceHeader);
        pegaRequest.setServiceBody(serviceBody);
    }

    public static void formatCheckExistingCartPegaRequest(CheckExistingCartUIRequest uiRequest,
                                                          CheckExistingCartPEGARequest pegaRequest) {
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(uiRequest.getChannelId());
        CheckExistingCartServiceBody serviceBody = new CheckExistingCartServiceBody();
        CheckExistingCartServiceRequest serviceRequest = new CheckExistingCartServiceRequest();
        CheckExistingCartContext context = new CheckExistingCartContext();
        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getAccountNumber()))
            customerInfo.setAccountNumber(uiRequest.getCartInfo().getAccountNumber());
        if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getCartCreator()))
            customerInfo.setCartCreator(uiRequest.getCartInfo().getCartCreator());
        if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getAmRole()))
            customerInfo.setAmRole(uiRequest.getCartInfo().getAmRole());
        customerInfo.setCradleFlowJourney(uiRequest.getCartInfo().getCradleFlowJourney());
        context.setCustomerInfo(customerInfo);
        if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getProspectCartId()))
            cartInfo.setProspectCartId(uiRequest.getCartInfo().getProspectCartId());
        cartInfo.setAction(CartConstants.UPDATE);
        cartInfo.setItemType(CartConstants.ACCESSORY);
        if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getIntendType()))
            cartInfo.setIntendType(uiRequest.getCartInfo().getIntendType());
        context.setCartInfo(cartInfo);
        contextInfo.setCallReason(CartConstants.SALES_ORDER_PURCHASE);
        if(CartConstants.NSEACC.equalsIgnoreCase(uiRequest.getCartInfo().getIntendType()))
            contextInfo.setIntent(CartConstants.STANDALONEACCESSORY);
        if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getProcessAction()))
            contextInfo.setProcessAction(uiRequest.getCartInfo().getProcessAction());
        if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getProcessStep()))
            contextInfo.setProcessStep(uiRequest.getCartInfo().getProcessStep());
        context.setContextInfo(contextInfo);
        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceHeader(serviceHeader);
        pegaRequest.setServiceBody(serviceBody);

    }

    /**
     * @param pegaRequest4
     * @param request4
     * @return UpdateGiftItemPEGARequest
     */
    public static UpdateGiftItemPEGARequest formatUpdateGiftItemRequest(UpdateGiftItemPEGARequest pegaRequest4,
                                                                        UpdateGiftItemUIRequest request4) {

        CartServiceServiceHeader serviceHeader4 = new CartServiceServiceHeader();
        serviceHeader4 = CartPegaRequestUtil.addServiceHeader(serviceHeader4);
        serviceHeader4.setClientId(request4.getChannelId());
        pegaRequest4.setServiceHeader(serviceHeader4);

        UpdateGiftItemServiceBody serviceBody4 = new UpdateGiftItemServiceBody();
        UpdateGiftItemServiceRequest serviceRequest4 = new UpdateGiftItemServiceRequest();
        UpdateGiftItemContext context4 = new UpdateGiftItemContext();

        CartServiceCustomerInfo customerInfo4 = new CartServiceCustomerInfo();
        customerInfo4.setAccountNumber(request4.getCartInfo().getAccountNumber());
        customerInfo4.setCartCreator(request4.getCartInfo().getCartCreator());
        customerInfo4.setProcessingMTN(request4.getCartInfo().getProcessingMTN());
        if (StringUtilities.isNotEmptyOrNull(request4.getCartInfo().getProcessStep())
                && request4.getCartInfo().getProcessStep().equalsIgnoreCase(CartConstants.PROMO_HUB)) {
            if(enableCradleForExistingCustomer){
                customerInfo4.setCradleFlowJourney(CartConstants.PROMO_HUB);
            }
        }
        CartServiceContextInfo contextInfo4 = new CartServiceContextInfo();
        contextInfo4.setCallReason(CartConstants.SALES_ORDER_PURCHASE);
        contextInfo4.setIntent(CartConstants.UPGRADE);
        if (StringUtilities.isNotEmptyOrNull(request4.getCartInfo().getProcessAction()))
            contextInfo4.setProcessAction(request4.getCartInfo().getProcessAction());
        if (StringUtilities.isNotEmptyOrNull(request4.getCartInfo().getProcessStep()))
            contextInfo4.setProcessStep(request4.getCartInfo().getProcessStep());

        CartServiceCartInfo cartInfo4 = new CartServiceCartInfo();
        cartInfo4.setCartId(request4.getCartInfo().getCartId());
        cartInfo4.setAction(CartConstants.UPDATE);
        if (request4.getCartInfo().getItemType() != null)
            cartInfo4.setItemType(request4.getCartInfo().getItemType());
        else
            cartInfo4.setItemType(CartConstants.GIFTITEM);
        List<Line> lines = new ArrayList<>();

        for (Lines reqLine : request4.getData().getLines()) {
            Line newLine4 = new Line();
            if (reqLine.getMtn() != null)
                newLine4.setMtn(reqLine.getMtn());
            if (reqLine.getDevice() != null)
                newLine4.setDevice(reqLine.getDevice());
            if (reqLine.getSim() != null)
                newLine4.setSim(reqLine.getSim());
            if (reqLine.getAddAccessories() != null) {
                newLine4.setAccessories(new AccessoryAction());
                newLine4.getAccessories().setAdd(reqLine.getAddAccessories());
            }
            lines.add(newLine4);
        }
        Line[] lineArr = new Line[lines.size()];
        lines.toArray(lineArr);

        cartInfo4.setLines(lineArr);
        if (StringUtilities.isEmptyOrNull(cartInfo4.getClientAppName()))
            cartInfo4.setClientAppName(request4.getChannelId());

        context4.setCustomerInfo(customerInfo4);
        context4.setContextInfo(contextInfo4);
        context4.setCartInfo(cartInfo4);
        context4.setCaseId(request4.getCartInfo().getCaseId());

        //MVP2-GR
        if(request4.getCartInfo()!=null && request4.getCartInfo().getCaseId()!=null && request4.getCartInfo().getCaseId().startsWith("SOF")){

            logger.info("SalesOrderFlex Prepay update gift item  Request before PEGA call setting Call Reason");
            contextInfo4.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader4.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }

        serviceRequest4.setContext(context4);
        serviceBody4.setServiceRequest(serviceRequest4);
        pegaRequest4.setServiceBody(serviceBody4);

        return pegaRequest4;
    }



    //VZWYN-17463 changes
    public static void formatAddTrialContactInfoAndAddressPegaRequest(AddTrialContactInfoAndAddressUIRequest uiRequest,
                                                                      AddTrialContactInfoAndAddressPEGARequest pegaRequest, CartRedisData redisData) {
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        serviceHeader = CartPegaRequestUtil.addServiceHeader(serviceHeader);
        if(StringUtilities.isNotEmptyOrNull(uiRequest.getData().getChannelId()))
            serviceHeader.setClientId(uiRequest.getData().getChannelId());

        AddTrialContactInfoAndAddressServiceBody serviceBody = new AddTrialContactInfoAndAddressServiceBody();
        AddTrialContactInfoAndAddressServiceRequest serviceRequest = new AddTrialContactInfoAndAddressServiceRequest();
        AddTrialContactInfoAndAddressContext context = new AddTrialContactInfoAndAddressContext();
        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        AddTrialContactInfoAndAddressCartInfo cartInfo = new AddTrialContactInfoAndAddressCartInfo();

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        if (StringUtilities.isNotEmptyOrNull(redisData.getAccountNumber()))
            customerInfo.setAccountNumber(redisData.getAccountNumber());
        if (StringUtilities.isNotEmptyOrNull(redisData.getCartCreator()))
            customerInfo.setCartCreator(redisData.getCartCreator());
        if (StringUtilities.isNotEmptyOrNull(redisData.getProcessingMTN()))
            customerInfo.setProcessingMTN(redisData.getProcessingMTN());
        context.setCustomerInfo(customerInfo);

        if (StringUtilities.isNotEmptyOrNull(redisData.getCartId()))
            cartInfo.setCartId(redisData.getCartId());
        cartInfo.setAction(CartConstants.UPDATE);
        cartInfo.setItemType(CartConstants.TRIAL_ADDRESS);
        if (StringUtilities.isNotEmptyOrNull(uiRequest.getData().getIntendType()))
            cartInfo.setIntendType(uiRequest.getData().getIntendType());
        cartInfo.setIsAccountInfoUpdation(uiRequest.getData().getIsAccountInfoUpdation());
        //setting lines
        AddTrialContactInfoAndAddressLine[] lines = new AddTrialContactInfoAndAddressLine[1];
        lines[0] = new AddTrialContactInfoAndAddressLine();
        lines[0].setMtn("newLine1");
        TrialAddress trialAddress = new TrialAddress();
        Address address = new Address();
        if(uiRequest.getData().getIsAccountInfoUpdation()){
            if(null != uiRequest.getData().getTrialContactInfo()){
                TrialContactInfo trialContactInfo = uiRequest.getData().getTrialContactInfo();
                if(StringUtilities.isNotEmptyOrNull(trialContactInfo.getFirstName()))
                    address.setFirstName(trialContactInfo.getFirstName());
                if(StringUtilities.isNotEmptyOrNull(trialContactInfo.getLastName()))
                    address.setLastName(trialContactInfo.getLastName());
                if(StringUtilities.isNotEmptyOrNull(trialContactInfo.getEmailId()))
                    address.setEmailId(trialContactInfo.getEmailId());
                if(StringUtilities.isNotEmptyOrNull(trialContactInfo.getPhoneNumber()))
                    address.setPhoneNumber(trialContactInfo.getPhoneNumber());
                trialAddress.setAddress(address);
                lines[0].setTrialAddress(trialAddress);
            }
        } else if(!uiRequest.getData().getIsAccountInfoUpdation()){
            if(null != uiRequest.getData().getTrialAddress()){
                if(StringUtilities.isNotEmptyOrNull(uiRequest.getData().getTrialAddress().getAddressLine1()))
                    address.setAddressLine1(uiRequest.getData().getTrialAddress().getAddressLine1());
                if(StringUtilities.isNotEmptyOrNull(uiRequest.getData().getTrialAddress().getAddressLine2()))
                    address.setAddressLine2(uiRequest.getData().getTrialAddress().getAddressLine2());
                if(StringUtilities.isNotEmptyOrNull(uiRequest.getData().getTrialAddress().getZipCode()))
                    address.setZipCode(uiRequest.getData().getTrialAddress().getZipCode());
                if(StringUtilities.isNotEmptyOrNull(uiRequest.getData().getTrialAddress().getCity()))
                    address.setCity(uiRequest.getData().getTrialAddress().getCity());
                if(StringUtilities.isNotEmptyOrNull(uiRequest.getData().getTrialAddress().getState()))
                    address.setState(uiRequest.getData().getTrialAddress().getState());
                trialAddress.setAddress(address);
                lines[0].setTrialAddress(trialAddress);
            }
        }
        cartInfo.setLines(lines);
        context.setCartInfo(cartInfo);

        contextInfo.setCallReason(CartConstants.SALES_ORDER_PURCHASE);
        if(StringUtilities.isNotEmptyOrNull(uiRequest.getData().getIntent()))
            contextInfo.setIntent(uiRequest.getData().getIntent());
        if (StringUtilities.isNotEmptyOrNull(uiRequest.getData().getProcessAction()))
            contextInfo.setProcessAction(uiRequest.getData().getProcessAction());
        if (StringUtilities.isNotEmptyOrNull(uiRequest.getData().getProcessStep()))
            contextInfo.setProcessStep(uiRequest.getData().getProcessStep());
        context.setContextInfo(contextInfo);

        if(StringUtilities.isNotEmptyOrNull(redisData.getCaseId()))
            context.setCaseId(redisData.getCaseId());
        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);

        pegaRequest.setServiceHeader(serviceHeader);
        pegaRequest.setServiceBody(serviceBody);

    }



    public static AccessoryFinancingOffersPegaRequest formatAFOPegaRequest(AccessoryFinancingOffersUIRequest uiRequest,
                                                                           AccessoryFinancingOffersPegaRequest pegaRequest) {

        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader);
        if (StringUtilities.isNotEmptyOrNull(uiRequest.getChannelId())) {
            serviceHeader.setClientId(uiRequest.getChannelId());
        }

        pegaRequest.setServiceHeader(serviceHeader);

        AFOServiceBody serviceBody = new AFOServiceBody();
        AFOServiceRequest serviceRequest = new AFOServiceRequest();
        AFOContext context = new AFOContext();

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        if(StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getAccountNumber())) {
            customerInfo.setAccountNumber(uiRequest.getCartInfo().getAccountNumber());
        }
        if(StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getCartCreator())) {
            customerInfo.setCartCreator(uiRequest.getCartInfo().getCartCreator());
        }
        if(StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getProcessingMTN())) {
            customerInfo.setProcessingMTN(uiRequest.getCartInfo().getProcessingMTN());
        }


        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        if(StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getCartId())) {
            cartInfo.setCartId(uiRequest.getCartInfo().getCartId());
        }
        if(StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getItemType())) {
            cartInfo.setItemType(uiRequest.getCartInfo().getItemType());
        }
        if(StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getIntendType())) {
            cartInfo.setIntendType(uiRequest.getCartInfo().getIntendType());
        }
        if(StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getAction())) {
            cartInfo.setAction(uiRequest.getCartInfo().getAction());
        }

        AccessoryFinancingOfferInfo afoInfo = new AccessoryFinancingOfferInfo();
        afoInfo.setDisclosureAgreementSent(uiRequest.isDisclosureAgreementSent());
        afoInfo.setOfferAccepted(uiRequest.isOfferAccepted());
        cartInfo.setAccessoryFinancingOfferInfo(afoInfo);

        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        contextInfo.setCallReason(CartConstants.SALES_ORDER_PURCHASE);
        if(StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getIntent())) {
            contextInfo.setIntent(uiRequest.getCartInfo().getIntent());
        }
        if(StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getProcessStep())) {
            contextInfo.setProcessStep(uiRequest.getCartInfo().getProcessStep());
        }
        if(StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getProcessAction())) {
            contextInfo.setProcessAction(uiRequest.getCartInfo().getProcessAction());
        }

        if(StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getCaseId())) {
            context.setCaseId(uiRequest.getCartInfo().getCaseId());
        }

        context.setCustomerInfo(customerInfo);
        context.setCartInfo(cartInfo);
        context.setContextInfo(contextInfo);
        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);
        return pegaRequest;
    }
    public static IndirectExCustRemoveLinePEGAReq formatIndirectCustRemoveLinesRequest(IndirectExCustRemoveLinePEGAReq pegaRequest,
                                                                                       ExCustIndirectRemoveLinesServiceUIRequest request) {
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        indirectCustAddServiceHeader(serviceHeader);
        if(request.getContext().getContextInfo().getIntent().equalsIgnoreCase(CartConstants.REX) ||
                request.getContext().getCartInfo().getIntendType().equalsIgnoreCase(CartConstants.REX))
        {
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_ADJUSTMENT);
        }
        pegaRequest.setServiceHeader(serviceHeader);
        return pegaRequest;

    }
    public static CartServiceServiceHeader indirectCustAddServiceHeader(CartServiceServiceHeader serviceHeader) {
        serviceHeader.setClientId("OMNI-INDIRECT");
        serviceHeader.setStatusMsg(CartConstants.BPM_PEGA_GENERATED_MESSAGE);
        serviceHeader.setSessionId("");
        serviceHeader.setServiceName(CartConstants.SALES_ORDER_PURCHASE);
        SecureRandom random = new SecureRandom();
        byte[] bytes = new byte[20];
        random.nextBytes(bytes);
        serviceHeader.setCorrelationId("soe-cart-" + new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date())
                + "-" + String.valueOf(1000 * random.nextDouble()));
        serviceHeader.setUserId("");
        serviceHeader.setStatusCode("0");
        return serviceHeader;
    }
    /*
     * https://onejira.verizon.com/browse/VZWYN-20438
     *  below is the logic to generate
     * the checksum for the device id in request if lenth >=15
     */
    /**
     * Takes 16 digit IMEI and creates device ID with checksum The checksum is
     * calculated with the first 14 digits. the checksum and blank space is then
     * added to create new 16 digit ID with checksum
     *
     * @param deviceId
     * @return
     */
    public static String calculateIMEIDeviceIdChecksum(String deviceId) {
        return deviceId.substring(0, 14).concat(String.valueOf(CartPegaRequestUtil9.calculateIMEIChecksum(deviceId)));
    }
}
