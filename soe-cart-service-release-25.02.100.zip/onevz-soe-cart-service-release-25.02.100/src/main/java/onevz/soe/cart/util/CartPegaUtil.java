package onevz.soe.cart.util;

import org.springframework.http.HttpStatus;

public class CartPegaUtil {
    /**
     * Process http status for pega http status.
     *
     * @param statusCode the status code
     * @return the http status
     */
    public static HttpStatus processHttpStatusForPega(HttpStatus statusCode) {
        if (statusCode != null && statusCode.equals(HttpStatus.NOT_FOUND)) {
            statusCode = HttpStatus.OK;
        }
        return statusCode;
    }
}
