package onevz.soe.cart.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.addAccessory.AccessoryAction;
import onevz.soe.cart.model.bulkcartupdate.*;
import onevz.soe.cart.model.bulkcartupdate.Line;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.tradeIn.appraiseDevice.DeviceOutInfo;
import onevz.soe.cart.model.tradeIn.appraiseDevice.RecycleDeviceOffer;
import onevz.soe.cart.model.tradeIn.appraiseDevice.TriageInfo;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import org.apache.commons.lang3.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;


import java.util.*;

public class BulkQuoteUpdatePegaRequestUtil {
    private static final Logger logger = LoggerFactory.getLogger(BulkQuoteUpdatePegaRequestUtil.class);

    public static final String AI_QUOTE = "AIQuote";
    @Value("${enableCradleForExistingCustomer:true}")
    private static boolean enableCradleForExistingCustomer;

    @Value("${enableCradleForProspect:true}")
    private static boolean enableCradleForProspect;

    @Value("${onevz.soe.cart.acc.enableCradleFlowJourney:true}")
    private static boolean enableCradleFlowJourney;

    private BulkQuoteUpdatePegaRequestUtil(){
    }

    public static CreateBulkQuotePegaRequest formatBulkPegaRequest(CreateBulkQuotePegaRequest pegaRequest, BulkQuoteUIRequest request, Map<String, String> data) {
        CreateBulkQuoteServiceBody serviceBody = new CreateBulkQuoteServiceBody();
        CreateBulkQuoteServiceRequest serviceRequest = new CreateBulkQuoteServiceRequest();

        CreateBulkQuoteContext context = new CreateBulkQuoteContext();
        formatContextForPegaRequest(context, request, data);

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);
        return pegaRequest;
    }

    private static void formatContextForPegaRequest(CreateBulkQuoteContext context, BulkQuoteUIRequest request, Map<String, String> data) {
        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        CartServiceBulkCartInfo cartInfo = new CartServiceBulkCartInfo();
        if(request.getCartInfo()!=null){
            context.setCaseId(Optional.ofNullable(request.getCartInfo().getCaseId()).orElse(""));

            // customerInfo for pega
            formatCustomerInfoForPegaRequest(customerInfo, request);

            // cartInfo for pega
            formatCartInfoForPegaRequest(cartInfo, request,data);
        }
        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        formatContextInfoForPegaRequest(contextInfo, cartInfo, request);

//        TODO: check if cartInfo or cartData should be passed to PEGA. Check add-device for reference.
        context.setCartData(cartInfo);
        context.setCartInfo(cartInfo);
        context.setCustomerInfo(customerInfo);
        context.setContextInfo(contextInfo);
    }

    private static void formatCartInfoForPegaRequest(CartServiceBulkCartInfo cartInfo, BulkQuoteUIRequest request, Map<String, String> data) {
        cartInfo.setCartId(Optional.ofNullable(request.getCartInfo().getCartId()).orElse(""));
        cartInfo.setAction(CartConstants.UPDATE);
        cartInfo.setItemType(CartConstants.DEVICES_AND_SERVICES_ITEM);

        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())) {
            cartInfo.setIntendType(request.getCartInfo().getIntendType());
        } else
            cartInfo.setIntendType(CartConstants.EUP);

        if (StringUtilities.isEmptyOrNull(request.getCartInfo().getClientAppName()))
            cartInfo.setClientAppName(request.getChannelId());

        if (request.getData().getParentMtn() != null)
            cartInfo.setParentMtn(request.getData().getParentMtn());

        cartInfo.setEffectiveDate(Optional.ofNullable(request.getData().getEffectiveDate()).orElse(""));

        // adding pastdue to cartInfo
        mapPastDue(request, cartInfo);

        // populate tradein data
        List<DeviceOutInfo> tradeInItems = new ArrayList<>();
        populateTradeInInfoForLines(cartInfo,tradeInItems,request);

        // populate line data
        onevz.soe.cart.model.bulkcartupdate.Line[] lineArrForBulkUpdate = populateLinesFromUiBulkRequestToPegaObject(cartInfo, request, tradeInItems,data);
        logger.info("Lines to be set into pega request is {}", lineArrForBulkUpdate);
        cartInfo.setLines(lineArrForBulkUpdate);
    }

    private static void mapPastDue(BulkQuoteUIRequest request, CartServiceBulkCartInfo cartInfo) {
        if(request!=null
                && request.getData()!=null
                && request.getData().getPastdue()!=null){
            cartInfo.setPastdue(request.getData().getPastdue());
        }
    }

    public static void populateTradeInInfoForLines(CartServiceBulkCartInfo cartInfo, List<DeviceOutInfo> tradeInItems, BulkQuoteUIRequest request) {
        String tradeInDeviceId = "";
        if(request.getData() != null
                && CollectionUtilities.isNotEmptyOrNull(request.getData().getLines())){
            if(request.getData().getLines().get(0)!=null){
                tradeInDeviceId = Optional.ofNullable(request.getData().getLines().get(0).getCurrentDeviceID()).orElse("");
            }
            request.getData().getLines().stream().forEach(lines -> {
                if(CollectionUtilities.isNotEmptyOrNull(lines.getTradeInItems())){
                    lines.getTradeInItems().stream().forEach(tradeinData ->{
                        DeviceOutInfo tradeInItem = new DeviceOutInfo();
                        tradeInItem.setPreferredStoreAddress(Optional.ofNullable(request.getData().getPreferredStoreAddress()).orElse(""));
                        tradeInItem.setPreferredStoreId(Optional.ofNullable(request.getData().getPreferredStoreId()).orElse(""));
                        mapTradeInData(tradeInItem, tradeinData);
                        tradeInItems.add(tradeInItem);
                    });
                }
            });
        }
        cartInfo.setDeviceId(tradeInDeviceId);
        cartInfo.setCurrentDeviceId(tradeInDeviceId);
        if(request.getData()!=null){
            cartInfo.setTradeinShipType(Optional.ofNullable(request.getData().getTradeinShipType()).orElse(""));
            cartInfo.setTradeInShippingType(Optional.ofNullable(request.getData().getTradeInShippingType()).orElse(""));
        }
    }

    private static void mapTradeInData(DeviceOutInfo tradeInItem, DeviceOutInfo tradeinData) {
        tradeInItem.setRecycleSeqNum(Optional.ofNullable(tradeinData.getRecycleSeqNum()).orElse(""));
        tradeInItem.setLineSeqNum(Optional.ofNullable(tradeinData.getLineSeqNum()).orElse(""));
        tradeInItem.setRecycleDeviceSku(Optional.ofNullable(tradeinData.getRecycleDeviceSku()).orElse(""));
        tradeInItem.setTradeDeviceMDN(Optional.ofNullable(tradeinData.getTradeDeviceMDN()).orElse(""));
        tradeInItem.setItemId(Optional.ofNullable(tradeinData.getItemId()).orElse(""));
        tradeInItem.setOrganicPrice(Optional.ofNullable(tradeinData.getOrganicPrice()).orElse(""));
        tradeInItem.setComputedPrice(Optional.ofNullable(tradeinData.getComputedPrice()).orElse(""));
        tradeInItem.setAppliedPrice(Optional.ofNullable(tradeinData.getAppliedPrice()).orElse(""));
        tradeInItem.setPromoValue(Optional.ofNullable(tradeinData.getPromoValue()).orElse(""));
        tradeInItem.setDeductionOnOrganic(Optional.ofNullable(tradeinData.getDeductionOnOrganic()).orElse(""));
        tradeInItem.setDeductionOnPromo(Optional.ofNullable(tradeinData.getDeductionOnPromo()).orElse(""));
        tradeInItem.setEquipMake(Optional.ofNullable(tradeinData.getEquipMake()).orElse(""));
        tradeInItem.setEquipModel(Optional.ofNullable(tradeinData.getEquipModel()).orElse(""));
        tradeInItem.setEquipCategory(Optional.ofNullable(tradeinData.getEquipCategory()).orElse(""));
        tradeInItem.setEquipCarrier(Optional.ofNullable(tradeinData.getEquipCarrier()).orElse(""));
        tradeInItem.setColor(Optional.ofNullable(tradeinData.getColor()).orElse(""));
        tradeInItem.setSize(Optional.ofNullable(tradeinData.getSize()).orElse(""));
        tradeInItem.setSubmissionId(Optional.ofNullable(tradeinData.getSubmissionId()).orElse(""));
        tradeInItem.setDeviceCategory(Optional.ofNullable(tradeinData.getDeviceCategory()).orElse(""));
        tradeInItem.setBuyoutDevice(Optional.ofNullable(tradeinData.isBuyoutDevice()).orElse(false));
        tradeInItem.setImgUrl(Optional.ofNullable(tradeinData.getImgUrl()).orElse(""));
        tradeInItem.setProdCode1(Optional.ofNullable(tradeinData.getProdCode1()).orElse(""));
        tradeInItem.setProdCode2(Optional.ofNullable(tradeinData.getProdCode2()).orElse(""));
        tradeInItem.setDeviceId(Optional.ofNullable(tradeinData.getDeviceId()).orElse(""));
        tradeInItem.setDeviceIdType(Optional.ofNullable(tradeinData.getDeviceIdType()).orElse(""));
        tradeInItem.setDeviceCondition(Optional.ofNullable(tradeinData.getDeviceCondition()).orElse("GOOD"));
        tradeInItem.setCreditType(Optional.ofNullable(tradeinData.getCreditType()).orElse(""));
        tradeInItem.setEmailAddress(Optional.ofNullable(tradeinData.getEmailAddress()).orElse(""));
        tradeInItem.setTradeInStatus(Optional.ofNullable(tradeinData.getTradeInStatus()).orElse("COMPLETE"));
        tradeInItem.setTriageInfo(Optional.ofNullable(tradeinData.getTriageInfo()).orElse(new TriageInfo()));
        tradeInItem.setRecycleDeviceOffer(Optional.ofNullable(tradeinData.getRecycleDeviceOffer()).orElse(new RecycleDeviceOffer()));
        tradeInItem.setFmiLocked(false);
    }

    public static void formatCustomerInfoForPegaRequest(CartServiceCustomerInfo customerInfo, BulkQuoteUIRequest request) {
        customerInfo.setAccountNumber(Optional.ofNullable(request.getCartInfo().getAccountNumber()).orElse(""));
        customerInfo.setMtnFlow(Optional.ofNullable(request.getCartInfo().getMtnFlow()).orElse(""));
        customerInfo.setProcessingMTN(Optional.ofNullable(request.getCartInfo().getProcessingMTN()).orElse(""));
        customerInfo.setEditDeviceConfiguratorClick(Optional.ofNullable(request.getCartInfo().getEditDeviceConfiguratorClick()).orElse(false));
        customerInfo.setIsSmartLocator(Optional.ofNullable(request.getCartInfo().getIsSmartLocator()).orElse(false));
        customerInfo.setBuyOutFlag(Optional.ofNullable(request.getCartInfo().getBuyOutFlag()).orElse(""));
        customerInfo.setBuyOutSelected(Optional.ofNullable(request.getCartInfo().getBuyOutSelected()).orElse(""));
        customerInfo.setEdgeUpSelected(Optional.ofNullable(request.getCartInfo().getEdgeUpSelected()).orElse(""));
        customerInfo.setOriginalCreditApprovalNumber(Optional.ofNullable(request.getCartInfo().getCreditAppNum()).orElse(""));
        customerInfo.setAccountLevelProtection(Optional.ofNullable(request.getCartInfo().getAccountLevelProtection()).orElse(false));

        if (request.getData()!=null
                && CollectionUtilities.isNotEmptyOrNull(request.getData().getLines())
                && request.getData().getLines().get(0)!=null
                && ObjectUtils.isNotEmpty(request.getData().getLines().get(0).getDevice())) {
            if (request.getData().getLines().get(0).getDevice().getProductId() != null)
                customerInfo.setProductId(request.getData().getLines().get(0).getDevice().getProductId());
            if (request.getData().getLines().get(0).getDevice().getCategory() != null)
                customerInfo.setCategoryName(request.getData().getLines().get(0).getDevice().getCategory());
        }

        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCartCreator())){
            customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
        } else if (CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))
                && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCreditAppNum()))
            customerInfo.setCartCreator(request.getCartInfo().getCreditAppNum());

        if (!enableCradleForProspect &&
                (CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())
                        || CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType()))) {
            customerInfo.setCradleFlowJourney("");
        }
    }

    public static void formatContextInfoForPegaRequest(CartServiceContextInfo contextInfo, CartServiceBulkCartInfo cartInfo, BulkQuoteUIRequest request) {
        contextInfo = CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.DEVICES_AND_SERVICES_ITEM, request.getCartInfo().getClientAppName());
        contextInfo.setProcessStep(Optional.ofNullable(request.getCartInfo().getProcessStep()).orElse(AI_QUOTE));

        contextInfo.setProcessAction(Optional.ofNullable(request.getCartInfo().getProcessAction()).orElse(CartConstants.DEVICES_AND_SERVICES_PROCESS_ACTION));

        if (StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessAction())
                && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())) {
            if (CartConstants.AAL.equalsIgnoreCase(request.getCartInfo().getIntendType()))
                contextInfo.setIntent(CartConstants.AAL);
            else if (CartConstants.EUP.equalsIgnoreCase(request.getCartInfo().getIntendType()))
                contextInfo.setIntent(CartConstants.UPGRADE);
        }

        if (CartConstants.BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
            contextInfo.setIntent(CartConstants.BYOD);
        }

        if ((CartConstants.AAL).equalsIgnoreCase(cartInfo.getIntendType()))
            contextInfo.setIntent(CartConstants.AAL);

        if ((CartConstants.NSE).equalsIgnoreCase(cartInfo.getIntendType())) {
            if (StringUtilities.isNotEmptyOrNull(request.getChannelId()) && CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId())))
                contextInfo.setIntent(CartConstants.INLINE_CPC);
            else
                contextInfo.setIntent(CartConstants.NSE);
        }
    }

    public static onevz.soe.cart.model.bulkcartupdate.Line[] populateLinesFromUiBulkRequestToPegaObject(CartServiceBulkCartInfo cartInfo, BulkQuoteUIRequest request, List<DeviceOutInfo> tradeInItems, Map<String, String> data){
        List<onevz.soe.cart.model.bulkcartupdate.Line> lineList = new ArrayList<>();
        ObjectMapper objectMapper = new ObjectMapper();
        cartInfo.setItemType(CartConstants.DEVICES_AND_SERVICES_ITEM);
        if(request.getCartInfo() != null)
            cartInfo.setNumberShareCapable(Optional.ofNullable(request.getCartInfo().getNumberShareCapable()).orElse(""));
        if(request.getData()!=null
                && CollectionUtilities.isNotEmptyOrNull(request.getData().getLines())){
            for (onevz.soe.cart.model.bulkcartupdate.Lines reqLine : request.getData().getLines()) {
                onevz.soe.cart.model.bulkcartupdate.Line newLine = new onevz.soe.cart.model.bulkcartupdate.Line();

                newLine.setMtn(Optional.ofNullable(reqLine.getMtn()).orElse(""));
                newLine.setMdnFilterValue(Optional.ofNullable(reqLine.getMdnFilterValue()).orElse(""));
                newLine.setDepletionType(Optional.ofNullable(reqLine.getDepletionType()).orElse(""));
                newLine.setIsKeepingExistingEqProtection(Optional.ofNullable(reqLine.getIsKeepingExistingEqProtection()).orElse(false));
                newLine.setTriggerPricingValidation(Optional.ofNullable(reqLine.getTriggerPricingValidation()).orElse(false));
                newLine.setAmount(Optional.ofNullable(reqLine.getAmount()).orElse(0.0));
                newLine.setRtdOfferId(Optional.ofNullable(reqLine.getRtdOfferId()).orElse(""));

                if(null != reqLine.getDepletionLocationCode())
                    newLine.setDepletionLocationCode(CartUtil.removeSpecialCharacters(reqLine.getDepletionLocationCode(), request.getChannelId()));
                else
                    newLine.setDepletionLocationCode("");

                newLine.setIspuFlow(Optional.ofNullable(reqLine.getIspuFlow()).orElse(false));

                // device
                if(reqLine.getDevice()!=null) {
                    newLine.setDevice(reqLine.getDevice());
                }
                //device category is ConnectedDevices then E911 address
                if(reqLine.getDevice() != null && reqLine.getDevice().getCategory() != null && reqLine.getDevice().getCategory().equalsIgnoreCase(CartConstants.DEVICE_CATEGORY_SMARTWATCH)){
                    if (data.containsKey(CartConstants.QUOTE_E911_ADDR) && StringUtilities.isNotEmptyOrNull(data.get(CartConstants.QUOTE_E911_ADDR))) {
                        logger.info("Reading address node from session {}", data.get(CartConstants.QUOTE_E911_ADDR));
                        try {
                            Address address = objectMapper.readValue(data.get(CartConstants.QUOTE_E911_ADDR), Address.class);
                            ServiceAddress serviceAddress = new ServiceAddress();
                            serviceAddress.setAddress(address);
                            newLine.setE911Address(serviceAddress);
                        } catch (JsonProcessingException e) {
                            logger.error("Error in reading value",e);
                        }
                    }
                }
                newLine.setTrunkMtn(Optional.ofNullable(reqLine.getTrunkMtn()).orElse(""));
                newLine.setNumbersharePairingMode(Optional.ofNullable(reqLine.getNumbersharePairingMode()).orElse(""));
                //cartInfo new node
                // sim
                if (reqLine.getSim() != null)
                    newLine.setSim(reqLine.getSim());

                // tradeInItems
                if(CollectionUtilities.isNotEmptyOrNull(tradeInItems)){
                    newLine.setCurrentDeviceId(Optional.ofNullable(tradeInItems.get(0).getDeviceId()).orElse(""));
                }
                newLine.setTradeInItems(tradeInItems);

                // features
                addFeaturesToBulkCartLine(newLine, reqLine, cartInfo);

                // accessories
                addAccessoriesToBulkCartLine(newLine, reqLine);

               // plan
                addPlanToBulkCartLine(newLine, reqLine);

                lineList.add(newLine);
            }
        }
        onevz.soe.cart.model.bulkcartupdate.Line[] lineArr = new onevz.soe.cart.model.bulkcartupdate.Line[lineList.size()];
        lineList.toArray(lineArr);
        return lineArr;
    }

    private static void addAccessoriesToBulkCartLine(onevz.soe.cart.model.bulkcartupdate.Line newLine, onevz.soe.cart.model.bulkcartupdate.Lines reqLine) {
        AccessoryAction accessoryAction = new AccessoryAction();
        Accessory[] accessories = new Accessory[3];
        accessoryAction.setAdd(accessories);
        newLine.setAccessories(accessoryAction);

        if (reqLine.getAddAccessories() != null) {
            for (Accessory addAccessory : reqLine.getAddAccessories()) {
                addAccessory.setQty(Optional.ofNullable(addAccessory.getQty()).orElse(""));
                addAccessory.setId(Optional.ofNullable(addAccessory.getId().toUpperCase()).orElse(""));
                addAccessory.setIsSoftSku(Optional.ofNullable(addAccessory.getIsSoftSku()).orElse(false));
                addAccessory.setAccountLevelAccessory(Optional.ofNullable(addAccessory.isAccountLevelAccessory()).orElse(false));
                addAccessory.setSerialNumber(Optional.ofNullable(addAccessory.getSerialNumber()).orElse(""));
            }
            newLine.getAccessories().setAdd(reqLine.getAddAccessories());
        }
    }

    private static void addPlanToBulkCartLine(onevz.soe.cart.model.bulkcartupdate.Line newLine, onevz.soe.cart.model.bulkcartupdate.Lines reqLine) {
        if (reqLine.getPlan() != null) {
            newLine.setPlan(reqLine.getPlan());
            mapPlanForSFO(reqLine, newLine);
            mapPlanForSPO(reqLine, newLine);
        }
    }

    public static void mapPlanForSFO(Lines reqLine, Line newLine) {
        if(null != reqLine.getPlan().getSFO()) {
            FeatureAction features = new FeatureAction();
            List<Feature> featuresList = new ArrayList<>();
            Feature feature = new Feature();
            reqLine.getPlan().getSFO().forEach(action->{
                if(action.getActionindicator().equals("A") && action.getBundlename() != null)
                    newLine.setSelectedPromoBundle(action.getBundlename().toUpperCase());
                if(action.getActionindicator()!=null && !action.getBundlename().equalsIgnoreCase(CartConstants.ENTERTAINMENT)) {
                    feature.setQuantity(1);
                    feature.setActionIndicator(action.getActionindicator());
                    feature.setId(action.getId());
                    feature.setType(CartConstants.SPO);
                    if(action.getActionindicator().equals("A")){
                        featuresList.add(feature);
                        features.setAdd(featuresList);
                    }else if(action.getActionindicator().equals("D")){
                        featuresList.add(feature);
                        features.setRemove(featuresList);
                    }
                }
                newLine.setFeatures(features);
            });
        }
    }

    public static void mapPlanForSPO(Lines reqLine, Line newLine) {
        if(CollectionUtilities.isNotEmptyOrNull(reqLine.getPlan().getPlanPromoSpo())){
            FeatureAction features = new FeatureAction();
            reqLine.getPlan().getPlanPromoSpo().forEach( promoSpo ->{
                List<Feature> featuresList = new ArrayList<>();
                Feature feature = new Feature();
                if(promoSpo !=null && promoSpo.getAction().equalsIgnoreCase(CartConstants.ADD)){
                    feature.setQuantity(1);
                    feature.setActionIndicator("A");
                    feature.setId(promoSpo.getSpoId());
                    feature.setType(CartConstants.SPO);
                    featuresList.add(feature);
                    features.setAdd(featuresList);
                } else if(promoSpo !=null && promoSpo.getAction().equalsIgnoreCase(CartConstants.REMOVE)){
                    feature.setQuantity(1);
                    feature.setId(promoSpo.getSpoId());
                    feature.setType(CartConstants.SPO);
                    featuresList.add(feature);
                    features.setRemove(featuresList);
                }
                newLine.setFeatures(features);
            });
        }
    }

    public static void addFeaturesToBulkCartLine(onevz.soe.cart.model.bulkcartupdate.Line newLine, onevz.soe.cart.model.bulkcartupdate.Lines reqLine, CartServiceBulkCartInfo cartInfo) {
        FeatureAction action = new FeatureAction();
        if (CollectionUtilities.isNotEmptyOrNull(reqLine.getAddFeatures())){
            action.setAdd(reqLine.getAddFeatures());
        }
        if (CollectionUtilities.isNotEmptyOrNull(reqLine.getRemoveFeatures())){
            action.setRemove(reqLine.getRemoveFeatures());
        }
        newLine.setFeatures(action);
        cartInfo.setTriggerPricingValidation(true);
    }



}
