package onevz.soe.cart.controller;

import jakarta.validation.Valid;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.exceptions.JsonValidator;
import onevz.soe.cart.helper.CartConfiguratorHelper;
import onevz.soe.cart.helper.FeatureFlagHelper;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.model.configurator.add.AddAllConfiguratorContext;
import onevz.soe.cart.model.configurator.add.AddAllConfiguratorServiceBody;
import onevz.soe.cart.model.configurator.add.AddAllConfiguratorServiceResponse;
import onevz.soe.cart.model.retrieveCart.CXPCartVO;
import onevz.soe.cart.model.validateCart.CXPValidateCartDataVO;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.AddAllConfiguratorUIRequest;
import onevz.soe.cart.ui.responses.AddAllConfiguratorUIResponse;
import onevz.soe.cart.ui.responses.ValidateCartUIResponse;
import onevz.soe.cart.util.*;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.Base64;
import java.util.Optional;

/**
 * The Class Configurator cart update operation controller.
 */
@RestController
@RequestMapping(value = "cart")
public class ConfiguratorCartUpdateOperationController {
    private static final Logger logger = LoggerFactory.getLogger(ConfiguratorCartUpdateOperationController.class);
    @Autowired
    CartConfiguratorHelper cartConfiguratorHelper;
    @Autowired
    JsonValidator validator;
    @Autowired
    private RedisHelper redisHelper;
    @Autowired
    private FeatureFlagHelper featureFlagHelper;
    @Value("${maxDurationForCookie:14}")
    private String maxDurationForCookie;

    private static void setSessionIDCookies(AddAllConfiguratorUIRequest addAllConfiguratorUIRequest, MultiValueMap<String, HttpCookie> cookiesMap, String channelType) {
        /*setting sessionId & GlobalID Cookies start*/
        Optional<HttpCookie> cookieDigitIgSession = Optional.ofNullable(cookiesMap.getFirst(CartConstants.DIGITAL_IG_SESSION));
        if (CartConstants.DIGITAL.equalsIgnoreCase(channelType)) {
            String sessionId = CartConstants.EMPTY_STRING;
            if (cookieDigitIgSession.isPresent()) {
                sessionId = cookieDigitIgSession.get().getValue();
            }
            // Updating cartCreator and globalId with sessionId for New customer flow NSA
            if (CartConstants.NSE.equals(addAllConfiguratorUIRequest.getCartInfo().getIntendType())) {
                addAllConfiguratorUIRequest.getCartInfo().setCartCreator(sessionId);
                addAllConfiguratorUIRequest.getCartInfo().setGlobalId(sessionId);
            }
            if (StringUtilities.isNotEmptyOrNull(CartPegaRequestUtil.fetchComVzIdFromHeader())) {
                addAllConfiguratorUIRequest.setVzId(CartPegaRequestUtil.fetchComVzIdFromHeader());
            }
            addAllConfiguratorUIRequest.getCartInfo().setSessionId(sessionId);
        }
        /*setting sessionId & GlobalID end*/
    }

    private Mono<Boolean> setAcNextGenCookie(ServerHttpResponse httpResponse, AddAllConfiguratorUIRequest addAllConfiguratorUIRequest, String cartId) {
        return featureFlagHelper.isNgdAbandonCartFFlag().flatMap(isNgdAbandonCartFFlag -> {
            logger.info("isNgdAbandonCartFFlag = {}", isNgdAbandonCartFFlag);
            if (isNgdAbandonCartFFlag) {
                try {
                    if(CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(addAllConfiguratorUIRequest.getChannelId())) && "NSE".equals(addAllConfiguratorUIRequest.getCartInfo().getIntendType())
                            && StringUtilities.isNotEmptyOrNull(cartId)) {
                        byte[] bytes = cartId.getBytes("UTF-8");
                        String encodedCartId = Base64.getEncoder().encodeToString(bytes);
                        logger.info("maximum duration for cookie: {}", maxDurationForCookie);
                        httpResponse.addCookie(ResponseCookie.from(CartConstants.AC_NEXTGEN, encodedCartId)
                                .path("/").httpOnly(false).secure(true).maxAge(Duration.ofDays(Long.parseLong(maxDurationForCookie))).build());
                        logger.info("acNextGen Cookie added: {}", encodedCartId);
                        return Mono.just(Boolean.TRUE);
                    }
                } catch (Exception e) {
                    logger.error("Exception while setting acNextGen cookie", e);
                }
            }
            return Mono.just(Boolean.TRUE);
        });
    }

    /**
     * Add to cart for configurator mono.
     *
     * @param httpHeader                  the http header
     * @param httpResponse                the http response
     * @param addAllConfiguratorUIRequest the add all configurator ui request
     * @return the mono
     */
    @PostMapping({"/addToCartForConfigurator", "/nse/addToCartForConfigurator"})
    public Mono<ResponseEntity<GenericResponse>> addToCartForConfigurator(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse, @Valid @RequestBody AddAllConfiguratorUIRequest addAllConfiguratorUIRequest) {
        /*Validating UI request start*/
        ErrorResponse errors = validateConfiguratorAddAllUIRequest(httpHeader, addAllConfiguratorUIRequest);
        if (null != errors) {
            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
        }
        /*Validating UI request end*/
        populateAddAllConfiguratorUIRequest(httpHeader, addAllConfiguratorUIRequest, httpResponse);
        CartRedisData cartRedisData = new CartRedisData();
        Mono<CartRedisData> redisData = redisHelper.getCartAndCaseIdFromRedis();

        return redisData.flatMap(redisDataObj -> {
            if (StringUtilities.isNotEmptyOrNull(redisDataObj.getCaseId()))
                addAllConfiguratorUIRequest.getCartInfo().setCaseId(redisDataObj.getCaseId());
            if (StringUtilities.isNotEmptyOrNull(redisDataObj.getCartId()))
                addAllConfiguratorUIRequest.getCartInfo().setCartId(redisDataObj.getCartId());
            return cartConfiguratorHelper.addToCartForConfigurator(addAllConfiguratorUIRequest).flatMap(pegaResponse -> {
                ErrorResponse errors2;
                if (pegaResponse.getErrors() != null && httpResponse.getStatusCode() != null) {
                    errors2 = CartConfiguratorPegaResponseErrorsUtil.handleAddAllConfiguratorResponseErrors(pegaResponse);
                    return Mono.just(ResponseEntity.status(CartPegaUtil.processHttpStatusForPega((HttpStatus) httpResponse.getStatusCode())).body(errors2));
                } else {
                    Lines lineData = addAllConfiguratorUIRequest.getData().getLines().stream().findFirst().orElse(null);
                    if (lineData != null) {
                        String flowPath = String.valueOf(httpHeader.getPath());
                        logger.info("addToCartForConfigurator flowPath  {} ", flowPath);
                        if (flowPath != null && flowPath.contains("/nse/addToCartForConfigurator")) {
                            addCartCountCookie(pegaResponse, httpResponse);
                            addDeviceCountCookie(pegaResponse, httpResponse);
                        }
                    }
                    if (pegaResponse.getServiceBody().getServiceResponse().getContext() != null)
                        cartRedisData.setCaseId(pegaResponse.getServiceBody().getServiceResponse().getContext().getCaseId());
                    if (pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo() != null)
                        cartRedisData.setCartId(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartId());
                    removeSensitiveInfo(addAllConfiguratorUIRequest, pegaResponse);
                    return redisHelper.updateCartIdAndCaseIdIntoRedisForNGD(cartRedisData).flatMap(
                                    redisFlagCaseId->{
                                        return setAcNextGenCookie(httpResponse, addAllConfiguratorUIRequest, cartRedisData.getCartId()).flatMap(isNgdAbandonCartFFlag->{
                                            return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(pegaResponse));
                                        });
                                    });
                        }
                    });
        });
    }

    public void addCartCountCookie(AddAllConfiguratorUIResponse pegaResponse, ServerHttpResponse httpResponse) {
        Optional.ofNullable(pegaResponse.getServiceBody()).map(AddAllConfiguratorServiceBody::getServiceResponse).map(AddAllConfiguratorServiceResponse::getContext).map(AddAllConfiguratorContext::getCartInfo).ifPresent(cartInfo -> {
            httpResponse.addCookie(createCartCountCookie(String.valueOf(cartInfo.getCartItemCount())));
            httpResponse.addCookie(createCartAvailableCookie());
        });

    }

    private ResponseCookie createCartCountCookie(String value) {
        logger.info("Prospect cart count  {} ", value);
        return ResponseCookie.from(CartConstants.PROSPECT_CART_COUNT, value).path("/").httpOnly(false).build();
    }

    private ResponseCookie createCartAvailableCookie() {
        return ResponseCookie.from(CartConstants.PROSPECT_CART_AVAILABLE, CartConstants.TRUE_FLAG).path("/").httpOnly(false).build();
    }
    public void addDeviceCountCookie(AddAllConfiguratorUIResponse pegaResponse,ServerHttpResponse httpResponse) {
        if (pegaResponse != null && pegaResponse.getServiceBody() != null
                && pegaResponse.getServiceBody().getServiceResponse() != null
                && pegaResponse.getServiceBody().getServiceResponse().getContext() != null
                && pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo() != null
                && pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getLineDevices() != null) {
            httpResponse.addCookie(createDeviceCountCookie(String.valueOf(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getLineDevices().length)));
        }
    }

    private ResponseCookie createDeviceCountCookie(String value) {
        logger.info("Prospect device count  {} ", value);
        return ResponseCookie.from(CartConstants.PROSPECT_DEVICE_COUNT, value).path("/").httpOnly(false).build();
    }

    private ErrorResponse validateConfiguratorAddAllUIRequest(ServerHttpRequest httpHeader, AddAllConfiguratorUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "addToCartForConfigurator");
        formatHttpHeader(httpHeader, request);
        ErrorResponse errorResponse = CartConfiguratorPegaRequestErrorsUtil.handleAddAllConfiguratorRequestErrors(request);
        if (CollectionUtilities.isNotEmptyOrNull(errorResponse.getErrors())) {
            return validator.convertObjectToString(errorResponse);
        }
        return null;
    }

    private void formatHttpHeader(ServerHttpRequest httpHeader, AddAllConfiguratorUIRequest request) {
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID) ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID) : "";
        request.setChannelId(channelId);
        String path = String.valueOf(httpHeader.getPath());
        if (StringUtilities.isNotEmptyOrNull(path)) {
            request.setPath(path);
        }
    }

    /**
     * Gets cookie values.
     *
     * @param httpHeader                  the http header
     * @param addAllConfiguratorUIRequest the add all configurator ui request
     * @param httpResponse                the http response
     */
    public void populateAddAllConfiguratorUIRequest(ServerHttpRequest httpHeader, AddAllConfiguratorUIRequest addAllConfiguratorUIRequest, ServerHttpResponse httpResponse) {
        String channelType = CartUtil.getChannelType(addAllConfiguratorUIRequest.getChannelId());
        MultiValueMap<String, HttpCookie> cookiesMap = httpHeader.getCookies();
        setSessionIDCookies(addAllConfiguratorUIRequest, cookiesMap, channelType);

        addAllConfiguratorUIRequest.setHttpRequest(httpHeader);
        addAllConfiguratorUIRequest.setHttpResponse(httpResponse);

    }

    public void removeSensitiveInfo(AddAllConfiguratorUIRequest request, AddAllConfiguratorUIResponse pegaResponse) {
        if (pegaResponse != null && pegaResponse.getServiceBody() != null && CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId())) && pegaResponse.getServiceBody().getServiceResponse() != null && pegaResponse.getServiceBody().getServiceResponse().getContext() != null) {

            pegaResponse.getServiceBody().getServiceResponse().getContext().setCaseId(null);
            Optional<CXPCartVO> cxpCartVOOptional = Optional.of(pegaResponse).map(AddAllConfiguratorUIResponse::getValidateCartResponse).map(ValidateCartUIResponse::getData).map(CXPValidateCartDataVO::getValidateCartAndUpdate);
            cxpCartVOOptional.map(CXPCartVO::getCartHeader).ifPresent(cartHeader -> {
                cartHeader.setCartId(null);
                cartHeader.setFullAccountNumber(null);
            });
            if (pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo() != null)
                pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setCartId(null);
        }
    }
}
