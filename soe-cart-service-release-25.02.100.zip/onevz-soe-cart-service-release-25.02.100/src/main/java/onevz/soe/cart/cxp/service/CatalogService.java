package onevz.soe.cart.cxp.service;

import onevz.soe.cart.model.catalog.*;
import onevz.soe.cart.requests.DualSkuRequest;
import onevz.soe.cart.requests.GetSpoRequest;
import onevz.soe.cart.requests.SmartImeiDevicesCXPRequest;
import onevz.soe.cart.requests.SmartImeiTypeAheadCXPRequest;
import onevz.soe.cart.responses.*;
import onevz.wsclient.cxp.CXPServices;
import onevz.wsclient.cxp.annotations.CXPGraphQL;
import onevz.wsclient.cxp.annotations.CXPJson;
import onevz.wsclient.cxp.annotations.GQLQueryName;
import onevz.wsclient.cxp.annotations.GQLQueryValue;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMethod;
import reactor.core.publisher.Mono;

/**
 * The Interface CatalogService.
 */
@Component
public interface CatalogService extends CXPServices {
	
	/**
	 * 
	 * @param sorId
	 * @return
	 */
	@CXPGraphQL(useNewImpl = true, component = "catalog-addons", urlPostFix = "/catalog/graphql", clientIdOverride = "PLAN-GLOBAL")
	@GQLQueryName(requestClass = CatalogSpoSku.class, value = "spoSku")
	public Mono<CatalogResponse> getSPO(@GQLQueryValue(value = "sorId") String sorId);
	
	/**
	 * 
	 * @param productId
	 * @return
	 */
	@CXPGraphQL(useNewImpl = true, component = "catalog-addons", urlPostFix = "/catalog/graphql", clientIdOverride = "PLAN-GLOBAL")
	@GQLQueryName(requestClass = CatalogSpoProduct.class, value = "spoProduct")
	public Mono<CatalogResponse> getSpoProduct(@GQLQueryValue(value = "productId") String productId);

	/**
	 *
	 * @param planId
	 * @return
	 */
	@CXPGraphQL(useNewImpl = true, component = "catalog-addons", urlPostFix = "/catalog/graphql", clientIdOverride = "PLAN-GLOBAL")
	@GQLQueryName(requestClass = CatalogPlanSku.class, value = "planSku")
	public Mono<CatalogResponse> getPlanSku(@GQLQueryValue(value = "planId") String planId);

	
	
	@CXPJson(component = "catalog-addons", urlPostFix = "/catalog/catalogRefData", isDomainCall = true)
	public Mono<PlanCatalogResponse> getPlanSkuRedesign(PlanCatalogRequest planCatalogRequest);
	
	@CXPJson(component = "catalog-addons", urlPostFix = "/catalog/catalogRefData", isDomainCall = true)
	public Mono<CatalogResponse> getSPOFromCatalog(GetSpoRequest spoCatalogRequest);
	
	@CXPJson(component = "catalog-addons", urlPostFix = "/catalog/catalogRefData", isDomainCall = true)
	public Mono<CatalogResponse> getCatalogRefData(CatalogDomainRequest catalogDomainRequest);

	// Sajan
	/**
	 * 
	 * @param request
	 * @return SmartImeiTypeAheadCXPResponse
	 */
	@CXPJson(component = "catalog-addons", urlPostFix = "/catalog/catalogRefData", isDomainCall = true)
	public Mono<SmartImeiTypeAheadCXPResponse> smartImeiTypeAhead(SmartImeiTypeAheadCXPRequest request);	

	@CXPJson(component = "catalog-addons", urlPostFix = "/catalog/catalogRefData", isDomainCall = true)
	public Mono<SmartImeiDevicesResponse> smartImeiDevice(SmartImeiDevicesCXPRequest request);

	@CXPJson(component = "catalog", urlPostFix = "/catalog/catalogRefData", methodType = RequestMethod.POST, isDomainCall = true, domainName = "CXP")
	public Mono<DualSkuResponse> getPreferredSkuDetails(DualSkuRequest request);

}
