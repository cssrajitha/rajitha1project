package onevz.soe.cart.util;

import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.ui.responses.AddAllConfiguratorUIResponse;
import onevz.soe.exception.SOEErrorHolder;

import java.util.ArrayList;
import java.util.List;

/**
 * The Class Cart configurator pega response errors util.
 */
public class CartConfiguratorPegaResponseErrorsUtil {
    private CartConfiguratorPegaResponseErrorsUtil() {

    }

    /**
     * Handle common error add all configurator ui response.
     *
     * @param soeError the soe error
     * @return the add all configurator ui response
     */
    public static AddAllConfiguratorUIResponse handleCommonError(SOEErrorHolder soeError) {

        AddAllConfiguratorUIResponse errors = null;
        List<CartError> errorList = new ArrayList<>();
        if (null != soeError) {
            errors = new AddAllConfiguratorUIResponse();
            CartPegaResponseErrorsUtil2.formatErrorList(soeError, errorList);
            errors.setErrors(errorList);
        }
        return errors == null ? new AddAllConfiguratorUIResponse() : errors;
    }

    /**
     * Handle add all configurator response errors error response.
     *
     * @param response the response
     * @return the error response
     */
    public static ErrorResponse handleAddAllConfiguratorResponseErrors(AddAllConfiguratorUIResponse response) {
        ErrorResponse errors = null;
        List<CartError> errorList = new ArrayList<>();
        if (response.getErrors() != null) {
            errors = new ErrorResponse();

            for (CartError cxpError : response.getErrors()) {
                CartError error = cxpError;
                errorList.add(error);
            }
            CartPegaResponseErrorsUtil2.handleCrossChannelIdIssue(errorList);
            errors.setErrors(errorList);
        }
        return errors == null ? new ErrorResponse() : errors;
    }
}
