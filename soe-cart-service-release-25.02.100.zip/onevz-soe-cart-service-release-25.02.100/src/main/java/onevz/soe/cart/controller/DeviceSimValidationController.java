package onevz.soe.cart.controller;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.helper.DeviceSimValidationService;
import onevz.soe.cart.model.deviceIdValidation.DeviceIdValidationLine;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.ui.requests.DeviceIdValidationUIRequest;
import onevz.soe.cart.ui.requests.ProductInquiryUIRequest;
import onevz.soe.cart.ui.responses.DeviceIdValidationUIResponse;
import onevz.soe.cart.ui.responses.ProductInquiryUIResponse;
import onevz.soe.cart.util.CartPegaResponseErrorsUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import jakarta.validation.Valid;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping(value = "cart")
public class DeviceSimValidationController {

    private static final Logger logger = LoggerFactory.getLogger(DeviceSimValidationController.class);

    @Autowired
    CartReadOperationsController cartReadOperationsController;
    @Autowired
    DeviceSimValidationService deviceSimValidationService;

    public Mono<ProductInquiryUIResponse> deviceIdValidation(ServerHttpRequest httpHeader,
                                                             ProductInquiryUIRequest uiRequest){
        logger.info("Entering into deviceIdValidation call");
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        return  deviceSimValidationService.processDeviceProductInquiry(uiRequest, channelId);
    }

    @PostMapping(value = {"/validateDeviceSimTransfer"})
    public Mono<ResponseEntity<GenericResponse>> combinedValidation(ServerHttpRequest httpHeader,
                                                                    ServerHttpResponse httpResponse,
                                                                    @Valid @RequestBody DeviceIdValidationUIRequest uiRequest){
        System.setProperty(CartConstants.ENDPOINT, "validateDeviceSimTransfer");
        logger.info("Entering into validateDeviceSimTransfer controller");
        Mono<ResponseEntity<GenericResponse>> pegaResponse = cartReadOperationsController.deviceIdValidation(httpHeader,httpResponse,uiRequest);
        return pegaResponse.flatMap(resp-> {
            ErrorResponse errors = null;
            Mono<ProductInquiryUIResponse> epsCallResponse = null;
            if (resp.getBody() != null){
                DeviceIdValidationUIResponse uiResponse = (DeviceIdValidationUIResponse) resp.getBody();
                if (uiResponse.getErrors() != null && uiResponse.getServiceBody() == null) {
                    httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
                    errors = CartPegaResponseErrorsUtil.handleDeviceIdValidationResponseErrors(uiResponse);
                    return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(errors));
                }
                if (uiResponse.getErrors() == null && uiResponse != null && uiResponse.getServiceBody() != null
                        && uiResponse.getServiceBody().getServiceResponse() != null
                        && uiResponse.getServiceBody().getServiceResponse().getContext() != null) {
                    ProductInquiryUIRequest productInquiryUIRequest = convertUIRequesttoProductInquiryRequest(uiRequest);
                    epsCallResponse = deviceIdValidation(httpHeader, productInquiryUIRequest);
                    return epsCallResponse.flatMap(epsRes -> {
                        ErrorResponse errorRes = null;
                        if (epsRes != null && !epsRes.getReturnCode().equalsIgnoreCase("000")) {
                            errorRes = CartPegaResponseErrorsUtil.populateResponseErrorForProductInquiry(epsRes.getReturnMessage(),
                                    epsRes.getReturnCode());
                            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorRes));
                        } else {
                            return Mono.just(ResponseEntity.status(HttpStatus.OK).body(epsRes));
                        }
                    });
                }
            }
            ErrorResponse errResponse = null;
            errResponse = CartPegaResponseErrorsUtil.populatePegaErrorForEmptyResponse();
            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errResponse));
        });
    }

    private ProductInquiryUIRequest convertUIRequesttoProductInquiryRequest(DeviceIdValidationUIRequest uiRequest) {
        logger.info("Converting DeviceIdValidationUIRequest to ProductInquiryUIRequest");
        ProductInquiryUIRequest productInquiryUIRequest = new ProductInquiryUIRequest();
        if(uiRequest !=null && uiRequest.getData() != null && uiRequest.getData().getLines() != null){
            List<DeviceIdValidationLine> lines = new ArrayList<DeviceIdValidationLine>();
            lines = uiRequest.getData().getLines();
            for (DeviceIdValidationLine line : lines){
                if(line !=null && line.getDevice() !=null && line.getDevice().getId() != null && line.getDevice().getSim() !=null
                        && line.getDevice().getSim().getId() !=null)   {
                    productInquiryUIRequest.setDeviceId(line.getDevice().getId());
                    productInquiryUIRequest.setIccId(line.getDevice().getSim().getId());
                }
            }
        }

        return productInquiryUIRequest;
    }
}
