package onevz.soe.cart.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.json.JsonSanitizer;
import onevz.cxp.feature.ConfigurationProfile;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.exceptions.JsonValidator;
import onevz.soe.cart.helper.*;
import onevz.soe.cart.model.addE911Address.AlternateAddress;
import onevz.soe.cart.model.addE911Address.E911AddressContext;
import onevz.soe.cart.model.addE911Address.E911AddressServiceBody;
import onevz.soe.cart.model.addE911Address.E911AddressServiceResponse;
import onevz.soe.cart.model.addFeature.AddFeaturesContext;
import onevz.soe.cart.model.addServiceAddress.ServiceAddressServiceBody;
import onevz.soe.cart.model.addServiceAddress.ServiceAddressServiceResponse;
import onevz.soe.cart.model.clearAndContinue.ClearAndContinueContext;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.myOffer.MyOfferLine;
import onevz.soe.cart.model.myOffer.Offer;
import onevz.soe.cart.model.myOffers.CompatiableOffer;
import onevz.soe.cart.model.myOffers.Offers;
import onevz.soe.cart.model.myOffers.ResponseData;
import onevz.soe.cart.model.myOffers.SelectedOffer;
import onevz.soe.cart.model.removeLines.RemoveLinesContext;
import onevz.soe.cart.model.removeLines.RemoveLinesServiceBody;
import onevz.soe.cart.model.removeLines.RemoveLinesServiceResponse;
import onevz.soe.cart.model.resumeAndContinue.ResumeAndContinueContext;
import onevz.soe.cart.model.updateBarcode.UpdateBarCodeContext;
import onevz.soe.cart.model.validateCart.CXPValidateCartDataVO;
import onevz.soe.cart.omnidl.OmniBuilder;
import onevz.soe.cart.ui.requests.GetBrandsRequest;
import onevz.soe.cart.requests.ValidateOffersRequest;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.ui.common.AddE911AddressData;
import onevz.soe.cart.ui.common.CartInfo;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.cart.ui.responses.v2.FlagDetails;
import onevz.soe.cart.util.*;
import onevz.soe.exception.SOEValidationException;
import onevz.soe.omnidl.service.OmniDLService;
import onevz.soe.omnidl.util.DLUtilityService;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import jakarta.validation.Valid;
import reactor.util.function.Tuple2;

import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;

import onevz.cxp.feature.*;

import static onevz.soe.cart.constants.CartConstants.*;
import static onevz.soe.cart.util.CartAddDeviceUtil.createClearCartCookies;


/**
 * Cart Controller class.
 */
//NSADT-53978 removing CrossOrigin annotation in every service.
//@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping(value = "cart")
public class CartUpdateOperationsController {

	private static final Logger logger = LoggerFactory.getLogger(CartUpdateOperationsController.class);
	private static final String FLOW_NAME = "flowName";

	@Autowired
	private UpdateCartHelper helper;

	@Autowired
	private CartServiceCxpHelper cxpHelper;

	@Autowired
	private CartResumeController cartResumeController;

	@Autowired
	private ObjectMapper mapper;

	@Autowired
	private RedisHelper redisHelper;

	@Autowired
	private RedisHelper2 redisHelper2;

	@Autowired
	private RedisHelper3 redisHelper3;

	@Autowired
	private DLUtilityService dlUtilityService;

	@Autowired
	JsonValidator validator;

	@Autowired
	private CartAddDeviceHelper addDeviceHelper;
	@Autowired
	private OmniDLHelperForAIQuote dlHelper;
	@Autowired
	private OmniDLHelper omniDlHelper;

	@Autowired
	private UpdateCartHelper1 helper1;

	@Autowired
	private FeatureFlagHelper featureFlagHelper;

	@Value("${enableClearAndAddItem:false}")
	private boolean enableClearAndAddItem;

	@Value("${soe.cartservice.enablePartialSuccessCall:true}")
	private boolean enablePartialSuccessCall;

	private final List<String> prospectHubCartCookieTrueList  = Arrays.asList(CartConstants.ACCESSORIES_INTERSTIAL,CartConstants.PROMO_HUB,
			CartConstants.PROMO_BUNDLE_BUILDER,CartConstants.PLAN_PROMO_RECOMMENDATION);

	public boolean isEnableClearAndAddItem() {
		return enableClearAndAddItem;
	}

	public void setEnableClearAndAddItem(boolean enableClearAndAddItem) {
		this.enableClearAndAddItem = enableClearAndAddItem;
	}


	@Autowired
	private OmniDLService dlService;

	@Value("${disableOzzieDiscount}")
	private boolean disableOzzieDiscount;

	@Value("#{'${sessionCreation.domains:.verizon.com}'.split(',')}")
	private List<String> domains;

	/**
	 * 
	 * @param binder
	 */
	@InitBinder("*")
	public void initBinderByName(WebDataBinder binder) {
		binder.setDisallowedFields(new String[] { "genericHeader" });
	}

	/**
	 * 
	 * @param uiRequest
	 * @return ResponseEntity
	 */
	@PostMapping(value = { "/smartimei-typeahead", "/nse/smartimei-typeahead" })
	public Mono<ResponseEntity<GenericResponse>> typeAhead(
			@Valid @RequestBody SmartImeiTypeAheadSearchRequest uiRequest) {
		return cxpHelper.getSmartImeiTypeAheadResponse(uiRequest).map(res->ResponseEntity.status(HttpStatus.OK).body(res));
	}

	/**
	 *
	 * @param request
	 * @return ResponseEntity
	 */
	@PostMapping(value = "/getbrands")
	public Mono<ResponseEntity<GenericResponse>> getBrands(@RequestBody(required = false)GetBrandsRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "getBrands");
		logger.debug("getBrands Request: {}", request);
		return cxpHelper.getBrands(request).map(resp -> ResponseEntity.status(HttpStatus.OK).body(resp));
	}

	/**
	 * 
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return ResponseEntity
	 * 
	 */
	@PostMapping({"/userInfo", "/flexV2/userInfo"})
	public Mono<ResponseEntity<GenericResponse>> updateUserInfo(ServerHttpRequest httpHeader,
			ServerHttpResponse httpResponse, @Valid @RequestBody UpdateUserInfoUIRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "userInfo");
		logger.debug("updateUserInfo Request: {}", request);

		ErrorResponse prevalidateRequest = helper.prevalidateUserRequest(request);
		if(Objects.nonNull(prevalidateRequest) && CollectionUtilities.isNotEmptyOrNull(prevalidateRequest.getErrors()))
			return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(prevalidateRequest));

		if (StringUtilities.isNotEmptyOrNull(String.valueOf(httpHeader.getURI())) && CartUtil.isFlexV2(String.valueOf(httpHeader.getURI()))) {
			request.setFlexV2(true);
		}
		return helper.updateUserInfo(request).map(resp -> {
			ErrorResponse errors2 = null;
			if (resp.getErrors() != null) {
				errors2 = CartCxpResponseErrorsUtil.handleUpdateUserInfoResponseErrors(resp);
			}
			return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
					: ResponseEntity.status(HttpStatus.OK).body(resp);

		});
	}

	/**
	 * 
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return ResponseEntity
	 * 
	 */
	@PostMapping("/enroll-paperlessBilling")
	public Mono<ResponseEntity<GenericResponse>> enrollPaperlessBilling(ServerHttpRequest httpHeader,
			ServerHttpResponse httpResponse, @Valid @RequestBody PaperlessBillingUIRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "enroll-paperlessBilling");
		logger.debug("paperless Billing Request: {}", request);
		return helper.paperlessBilling(request).map(resp -> {
			ErrorResponse errors2 = null;
			if (resp.getErrors() != null) {
				errors2 = CartCxpResponseErrorsUtil.handlePaperlessBillingResponseErrors(resp);
			}
			return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
					: ResponseEntity.status(HttpStatus.OK).body(resp);

		});
	}
	/**
	 * 
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return ResponseEntity
	 * 
	 */
	@PostMapping("/tradeinType")
	public Mono<ResponseEntity<GenericResponse>> updateTradeinType(ServerHttpRequest httpHeader,
			ServerHttpResponse httpResponse, @Valid @RequestBody UpdateTradeinTypeUIRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "tradeinType");
		logger.debug("updateTradeinType Request: {}", request);
		return helper.updateTradeinType(request).map(resp -> {
			ErrorResponse errors2 = null;
			if (resp.getErrors() != null) {
				errors2 = CartCxpResponseErrorsUtil.handleUpdateTradeinTypeResponseErrors(resp);
			}
			return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
					: ResponseEntity.status(HttpStatus.OK).body(resp);

		});
	}
	@PostMapping("/updateSellerPrice")
	public Mono<ResponseEntity<GenericResponse>> updateSellerPriceNew(ServerHttpRequest httpHeader,
			ServerHttpResponse httpResponse, @Valid @RequestBody UpdateSellerPriceUIRequestNew request) {
	
		System.setProperty(CartConstants.ENDPOINT, "sellerPrice");
		logger.debug("updateSellerPrice Request: {}", request);
		String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
				? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
				: "";
		request.setChannelId(channelId);
		ErrorResponse errorResponse = CartPegaRequestErrorsUtil.handleUpdateSellerPriceRequestErrors(request);
		if (CollectionUtilities.isNotEmptyOrNull(errorResponse.getErrors())) {
			ErrorResponse errors = validator.convertObjectToString(errorResponse);
			if (null != errors) {
				return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
			}
		}
		return helper.updateSellerPriceNew(request).map(pegaResponse -> {
			ErrorResponse errors2 = null;
			if (pegaResponse.getErrors() != null) {
				errors2 = CartPegaResponseErrorsUtil.handleUpdateSellerPriceResponseErrors(pegaResponse);
			}
			return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
					: ResponseEntity.status(HttpStatus.OK).body(pegaResponse);
		});
	}
	//moved few methods to new file

	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @return ResponseEntity
	 *
	 */
	@PostMapping("/clearAndContinue")
	public Mono<ResponseEntity<GenericResponse>> clearAndContinue(ServerHttpRequest httpHeader,
			ServerHttpResponse httpResponse, @RequestBody ClearAndContinueUIRequest request) {
		return handleClearAndAdd().flatMap(res-> {
			if (res) {
				return cartResumeController.clearAndResume(httpHeader, httpResponse, request);
			} else {
				System.setProperty(CartConstants.ENDPOINT, "clearAndContinue");
				logger.debug("clear and continue Request: {}", request);
				String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
						? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
						: "";
				//ACT53-811, cookie to indicate add-device flow starts from quick view section of FreePhones GQ
				// this indicator is sent to CJCM
				HttpCookie fromFreePhoneQVCookie = httpHeader.getCookies().containsKey(CartConstants.FROM_FREE_PHONES_QV)?
						httpHeader.getCookies().getFirst(CartConstants.FROM_FREE_PHONES_QV) : null;
				String fromFreePhonesQV = "";
				if(fromFreePhoneQVCookie != null){
					fromFreePhonesQV = fromFreePhoneQVCookie.getValue();
					if(StringUtils.isNotBlank(fromFreePhonesQV)){
						request.getCartInfo().setFromFreePhoneQV(Boolean.parseBoolean(fromFreePhonesQV));
					}
				}

				request.setChannelId(channelId);
				return helper.clearAndContinue(request).flatMap(clearAndContinueResponse -> {
					ErrorResponse errors2 = null;
					if (clearAndContinueResponse.getErrors() != null) {
						errors2 = CartPegaResponseErrorsUtil.handleClearAndContinueResponseErrors(clearAndContinueResponse);
						return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(errors2));
					} else {
						if(request != null && request.getCartInfo() != null && request.getCartInfo().getInWithVerizonOpted() !=null && request.getCartInfo().getInWithVerizonOpted()
								&& StringUtils.equalsIgnoreCase(CartConstants.BYOD, request.getCartInfo().getRecommendationSelection())) {
							dlUtilityService.upsertVZPageSubFLow(CartConstants.BYOD_ADR, true, "").subscribeOn(Schedulers.parallel()).subscribe();
						}
						CartRedisData rr = new CartRedisData();
						ClearAndContinueContext context = new ClearAndContinueContext();
						if (null != clearAndContinueResponse.getServiceBody()
								&& null != clearAndContinueResponse.getServiceBody().getServiceResponse()
								&& null != clearAndContinueResponse.getServiceBody().getServiceResponse().getContext()) {
							context = clearAndContinueResponse.getServiceBody().getServiceResponse().getContext();
							rr.setCaseId(context.getCaseId());
							if(context.getCartInfo()!=null) {
								rr.setCartId(context.getCartInfo().getCartId());
							}
							if(context.getCustomerInfo() != null) {
								if (StringUtilities.isEmptyOrNull(context.getCustomerInfo().getExistingCase())) {
									rr.setExistingCase(CartConstants.FALSE);
								} else {
									rr.setExistingCase(context.getCustomerInfo().getExistingCase());
								}
							}
//							updating subFlow for BYOD existing customer
							helper1.updateSubflowForByod(request,context);
							addDeviceHelper.removeCaseAndCartIdResponse(clearAndContinueResponse.getServiceBody(),channelId);
						}
						//ACT53-811 Cookie is deleted as it in no longer necessary
						if(request.getCartInfo().isFromFreePhoneQV()){
							httpResponse.addCookie(ResponseCookie.from(CartConstants.FROM_FREE_PHONES_QV,
									"").path("/").httpOnly(false).secure(true).maxAge(Duration.ofDays(0)).build());
						}
						CartAddDeviceUtil.createCookieCartCountClearAndContinue(httpResponse, clearAndContinueResponse, EXISTING_CART_COUNT,domains);
						rr.setChannelId(channelId);
						String prospectCartId = Optional.ofNullable(request).map(ClearAndContinueUIRequest::getCartInfo).map(CartInfo::getProspectCartId).orElse(null);
						if(StringUtilities.isNotEmptyOrNull(prospectCartId))
							redisHelper2.deleteSessionDataKeyFromRedis(CartConstants.PROSPECT_CARTID);
						return callToUpdateCartIdAndCaseIdIntoRedis(httpResponse, rr, request.getCartInfo(),clearAndContinueResponse, false);
					}
				});
			}
		});
	}

	private Mono<Boolean> handleClearAndAdd() {
		if(!enableClearAndAddItem)
			return Mono.just(false);
		return redisHelper.getItemTypeFromRedis().flatMap(actionType -> {
			Mono<CartRedisData> commonRedisData = null;
			if(CartConstants.DEVICE.equalsIgnoreCase(actionType)) {
				commonRedisData = redisHelper.getDataFromRedisAsString();
			}else{
				commonRedisData = redisHelper.getAccessoryDataFromRedisAsString();
			}
			return commonRedisData.flatMap(redisData -> {
				if (null != redisData.getDeviceCartInfo()
						|| null != redisData.getAccessoryCartInfo()) {
					String intendType = null;
					if (CartConstants.DEVICE.equalsIgnoreCase(actionType)) {
						intendType = redisData.getDeviceCartInfo().getIntendType();
					} else if (CartConstants.ACCESSORY.equalsIgnoreCase(actionType)) {
						intendType = redisData.getAccessoryCartInfo().getIntendType();
					}

					if (StringUtilities.isNotEmptyOrNull(intendType)
							&& (CartConstants.AAL.equalsIgnoreCase(intendType)
							|| CartConstants.ACC.equalsIgnoreCase(intendType))) {
						if (CartConstants.DEVICE.equalsIgnoreCase(actionType))
							return Mono.just(true);
						else
							return Mono.just(false);
					}
					else
					{
						return Mono.just(false);
					}
				}
				return Mono.just(false);
			});
		});
	}

	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @return ResponseEntity
	 *
	 */
	@PostMapping("/resumeAndContinue")
	public Mono<ResponseEntity<GenericResponse>> resumeAndContinue(ServerHttpRequest httpHeader,
																  ServerHttpResponse httpResponse, @RequestBody ResumeAndContinueUIRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "resumeAndContinue");
		logger.debug("resume and continue Request: {}", request);
		String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
				? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
				: "";
		request.setChannelId(channelId);
		return helper.resumeAndContinue(request).flatMap(resumeAndContinue -> {
			ErrorResponse errors2 = null;
			if (resumeAndContinue.getErrors() != null) {
				errors2 = CartPegaResponseErrorsUtil.handleResumeAndContinueResponseErrors(resumeAndContinue);
				return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(errors2));
			} else {
				CartRedisData rr = new CartRedisData();
				ResumeAndContinueContext context = new ResumeAndContinueContext();
				if (null != resumeAndContinue.getServiceBody()
						&& null != resumeAndContinue.getServiceBody().getServiceResponse()
						&& null != resumeAndContinue.getServiceBody().getServiceResponse().getContext())
					context = resumeAndContinue.getServiceBody().getServiceResponse().getContext();
				String caseId = context.getCaseId();
				String cartId = context.getCartInfo().getCartId();
				rr.setCartId(cartId);
				rr.setCaseId(caseId);
				return callToUpdateCartIdAndCaseIdIntoRedis(httpResponse, rr, request.getCartInfo(),resumeAndContinue, false);
			}
		});
	}

	/**
	 * 
	 * @param httpHeader
	 * @param httpResponse
	 * @param applyOfferRequest
	 * @return validateOfferResponse
	 */
	@PostMapping("/applyMyOffers")
	public Mono<ResponseEntity<ValidateOffersResponse>> applyMyOffers(ServerHttpRequest httpHeader,
			ServerHttpResponse httpResponse, @Valid @RequestBody ApplyOfferRequest applyOfferRequest) {
		System.setProperty(CartConstants.ENDPOINT, "applyMyOffers");
		ValidateOffersResponse defaultResponse = new ValidateOffersResponse();
		defaultResponse.setStatusMessage("No offers applied!");
		Mono<ValidateOffersResponse> returnResponse = Mono.just(defaultResponse);
		ValidateOffersResponse vor = new ValidateOffersResponse();
		vor.setData(new ResponseData());
		if (null != applyOfferRequest.getCartInfo() && null != applyOfferRequest.getCartInfo().getIsEquipmentOffer()
				&& applyOfferRequest.getCartInfo().getIsEquipmentOffer()) {
			returnResponse = updateMyOffers(httpHeader, httpResponse, applyOfferRequest).flatMap(eqpResp -> {
				if (null != eqpResp && null != eqpResp.getBody()) {
					MyOffersCXPResponse myOffersResponse = eqpResp.getBody();
					if (null != myOffersResponse && CollectionUtilities.isEmptyOrNull(myOffersResponse.getErrors())) {
						vor.getData().setEquipmentOfferUpdated(true);
						logger.info("Equipment MyOffer added successfully.");
					}
				}

				return Mono.just(vor);
			});
			returnResponse.subscribeOn(Schedulers.parallel()).subscribe(ret -> {
				logger.info("EQUIPMENT offer applied");
			});
		}
		Map<String,String> redisOfferMap = new HashMap<>();
		// Read Accepted from Redis
		returnResponse = redisHelper.getMyOfferETRDataFromRedis().flatMap(myOfferData -> {
			try {
				logger.info("MyOffer Data from Redis : {}", mapper.writeValueAsString(myOfferData));
			} catch (JsonProcessingException e1) {
				logger.error(CartConstants.JSON_PRCSSNG_EXCPTN_STRNG + "{}", e1);
			}
			Mono<ValidateOffersResponse> returnResponse2 = Mono.just(defaultResponse);
			ErrorResponse errors = CartPegaRequestErrorsUtil.handleApplyMyOfferRequestErrors(applyOfferRequest,
					myOfferData);
			if (errors.getErrors() != null)
				return Mono
						.error(new SOEValidationException("request", null, "Invalid Request for applyMyOffers", "700"));
			else if (!myOfferData.getLines().isEmpty()) {
				Boolean containsOnlyEFO = Boolean.TRUE;
				List<MyOfferLine> updatedLineList = new ArrayList<>();
				
				for (MyOfferLine etrMyOfferLines : myOfferData.getLines()) {
					MyOfferLine updatedEtrMyOfferLines = new MyOfferLine();
					List<Offer> updatedEtrMyOffer = new ArrayList<>();
					for (Offer etrMyOffer : etrMyOfferLines.getOffers()) {
						boolean isAALoffer = false;
						if (!"EFO".equalsIgnoreCase(etrMyOffer.getComplianceType())) {
							updatedEtrMyOfferLines.setMtn(etrMyOfferLines.getMtn());
							updatedEtrMyOffer.add(etrMyOffer);
							containsOnlyEFO = false;

							isAALoffer = "Y".equalsIgnoreCase(etrMyOffer.getAal()) && StringUtilities.isEmptyOrNull(etrMyOffer.getReasonCode());
							if(!isAALoffer) {
								redisOfferMap.put(etrMyOffer.getSku(), etrMyOffer.getDescription());
							}

						}
					}
					if(!updatedEtrMyOffer.isEmpty()){
						updatedEtrMyOfferLines.setOffers(updatedEtrMyOffer);
						updatedLineList.add(updatedEtrMyOfferLines);
					}
				}
				myOfferData.setLines(updatedLineList);

				if (containsOnlyEFO) {
					return Mono.just(defaultResponse);
				}
			}

			long startTime = System.currentTimeMillis();
			ValidateOffersRequest validateOffersRequest = CartCxpRequestUtil
					.buildCXPValidateOfferRequest(applyOfferRequest, myOfferData);
			if(StringUtilities.isEmptyOrNull(validateOffersRequest.getData().getCartId()))
				return Mono.just(defaultResponse);

			Mono<ValidateOffersResponse> cxpResponse = helper.validateOffers(validateOffersRequest).doOnError(e -> {
				logger.error("Error while validating MyOffers from CXP ", e);
				logger.debug("Total time for validateOffers  {} ", (System.currentTimeMillis() - startTime) / 1000);
			}).onErrorResume(e->{
				ValidateOffersResponse failureResponse = new ValidateOffersResponse();
				failureResponse.setStatusMessage("Sorry the offer cannot be applied right now as the validate offers API failed");
				return Mono.just(failureResponse);
			}).doOnSuccess(s -> logger.info("Total time for validateOffers call  {} ",
					(System.currentTimeMillis() - startTime) / 1000));

			returnResponse2 = cxpResponse.flatMap(validateOffersRes -> {
				String offerData = "";
				if(null != validateOffersRes && null != validateOffersRes.getData()	
						&& !validateOffersRes.getData().isValidOffer()){
					if(null != validateOffersRequest && null != validateOffersRequest.getData()
							&& CollectionUtilities.isNotEmptyOrNull(validateOffersRequest.getData().getSelectedOffers())) {
						for(SelectedOffer offData : validateOffersRequest.getData().getSelectedOffers()) {
							for(Offers off : offData.getOffers()){
								if(CollectionUtilities.isNotEmptyOrNull(redisOfferMap)
									&& StringUtilities.isNotEmptyOrNull(redisOfferMap.get(off.getSku()))) {
									offerData = StringUtilities.isNotEmptyOrNull(offerData) ? offerData +"/"+redisOfferMap.get(off.getSku()) : redisOfferMap.get(off.getSku());
								}
							}
						}
					}
					if(StringUtilities.isEmptyOrNull(offerData) && CollectionUtilities.isNotEmptyOrNull(redisOfferMap))
					{
						offerData ="My";
					}	
					String msg = StringUtilities.isNotEmptyOrNull(offerData) ? "Accepted "+ offerData +" Offer, is not applied" : "";
					defaultResponse.setStatusMessage(msg);
				}
				
				Mono<ValidateOffersResponse> returnResponse3 = Mono.just(defaultResponse);
				if (null != validateOffersRes && null != validateOffersRes.getData()
						&& null != validateOffersRes.getData().getCompatiableOffers()) {
					validateOffersRes.getData().setValidOffer(true);
					List<CompatiableOffer> compatiableOffers = validateOffersRes.getData().getCompatiableOffers();
					Optional<CompatiableOffer> featureOffer = compatiableOffers.stream()
							.filter(compatiableOffer -> (null != compatiableOffer.getOfferType()
									&& compatiableOffer.getOfferType().equalsIgnoreCase("Feature")))
							.findAny();
					Optional<CompatiableOffer> planOffer = compatiableOffers.stream()
							.filter(compatiableOffer -> (null != compatiableOffer.getOfferType()
									&& compatiableOffer.getOfferType().equalsIgnoreCase("Plan")))
							.findAny();

					if (planOffer.isPresent()) {
						// hex Plan Offer exists so to store the value in session
						returnResponse3 =  returnResponse3.flatMap(plans->{
							if (CollectionUtilities.isNotEmptyOrNull(planOffer.get().getNonPhoneMtnList())) {
								Map<String, String> hexplanInfoMap = new HashMap<>();

								planOffer.get().getCompatiableofferLines().stream().forEach(compOffer -> {
									compOffer.getOffers().stream().forEach(offrline -> {
										hexplanInfoMap.put(compOffer.getMtn(), offrline.getSku());
									});
								});
								return redisHelper
										.upsertAddPlanUIRequestIntoRedisforHexUnlimitedPlanOffer(hexplanInfoMap)
										.flatMap(flag -> {
											if (flag) {
												validateOffersRes.getData().setShowHexPlanWarning(true);
											}
											logger.info("PLAN offer applied");
											return Mono.just(validateOffersRes);
										});
							} else {
								AddPlanUIRequest request = CartPegaRequestUtil6.buildAddPlanRequest(applyOfferRequest,
										planOffer.get());
								return addPlan(httpHeader, httpResponse, request).flatMap(addPlanRes -> {
									if (null != addPlanRes && null != addPlanRes.getBody()) {
										AddPlanUIResponse addPlanUIResponse = (AddPlanUIResponse) addPlanRes.getBody();
										if (null != addPlanUIResponse
												&& CollectionUtilities.isEmptyOrNull(addPlanUIResponse.getErrors())) {
											validateOffersRes.getData().setPlanOfferUpdated(true);
											logger.info("Plan MyOffer added successfully.");
										}
									}
									logger.info("PLAN offer applied");
									return Mono.just(validateOffersRes);
								});
								
							}
						});
					}
					if (featureOffer.isPresent()) {
						AddFeaturesUIRequest request = CartPegaRequestUtil6.buildAddFeaturesRequest(applyOfferRequest,
								featureOffer.get());
						return returnResponse3.flatMap(feature->{
							return addFeatures(httpHeader, httpResponse, request).flatMap(addFeaRes -> {
								if (null != addFeaRes && null != addFeaRes.getBody()) {
									AddFeaturesUIResponse addFeaturesUIResponse = (AddFeaturesUIResponse) addFeaRes
											.getBody();
									if (null != addFeaturesUIResponse
											&& CollectionUtilities.isEmptyOrNull(addFeaturesUIResponse.getErrors())) {
										validateOffersRes.getData().setFeatureOfferUpdated(true);
										logger.info("Feature MyOffer added successfully.");
									}
								}
								logger.info("FEATURE offer applied.");
								return Mono.just(validateOffersRes);
							});
						});
					}
				}

				return returnResponse3;
			});
			returnResponse2.subscribeOn(Schedulers.parallel()).subscribe(ret -> {
				logger.info("EQP/PLAN/FEATURES offer applied");
			});
			return returnResponse2;
		});
		return returnResponse.flatMap(rr -> {
			return Mono.just(ResponseEntity.status(HttpStatus.OK).body(rr));
		});
	}

	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return ResponseEntity
	 *
	 */
	@PostMapping({ "/add-plan", "/nse/add-plan","/5g/add-plan","/nse/5g/add-plan","/addPlanAndPerks","/nse/addPlanAndPerks","flexV2/addPlanAndPerks","flexV2/nse/addPlanAndPerks" })
	public Mono<ResponseEntity<GenericResponse>> addPlan(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse,
			@Valid @RequestBody AddPlanUIRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "add-plan");
		logger.debug("add-plan Request: {}", request);

		ErrorResponse errorResponse = CartPegaRequestErrorsUtil.handleAddPlanRequestErrors(request,httpHeader);
		if (CollectionUtilities.isNotEmptyOrNull(errorResponse.getErrors())) {
			ErrorResponse errors = validator.convertObjectToString(errorResponse);
			if (null != errors) {
				return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
			}
		}

		String channelId = getChannelId(httpHeader);
		request.setChannelId(channelId);
		String sessionId = getSessionId(httpHeader, channelId);
		request.getCartInfo().setSessionId(sessionId);
		if (StringUtilities.isNotEmptyOrNull(String.valueOf(httpHeader.getURI())) && CartUtil.isFlexV2(String.valueOf(httpHeader.getURI()))) {
			request.getCartInfo().setFlexV2(true);
		}
		Mono<AddPlanUIResponse> pegaResp = helper.addPlan(request);
		return mergeFeatureFlagWithResponse(Mono.zip(pegaResp,featureFlagHelper.fetchDigitalPerformanceCfgProfile())).flatMap(pegaResponse -> {
			try {
				if(request.getCartInfo()!=null && !request.getCartInfo().isFlexV2()) {
					dlService.buildDLData(OmniBuilder.buildBBPAddPlanData(pegaResponse));
				}
			} catch (Exception e) {
				logger.error("Exception while calling dlUtility in addPlan", e);
			}
			ErrorResponse errors2 = null;
			if (pegaResponse.getErrors() != null && !httpResponse.getStatusCode().is2xxSuccessful()) {
				errors2 = CartPegaResponseErrorsUtil.handleAddPlanResponseErrors(pegaResponse);
				if(org.apache.commons.lang3.StringUtils.isNotBlank(request.getChannelId()) && CartConstants.DIGITAL_DDOT_MOB_TAB_CHANNELS.contains(channelId))
					CartPegaResponseErrorsUtil.setErrorCategory(errors2,CartConstants.ERRCAT_CJCM);
				return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(errors2));
			} else {
				String addedPlans = "";
				Map<String, Map<String, String>> byouPlanSelection=new HashMap<>();
				for(Lines line: request.getData().getLines()) {
					if(null != line.getPlan() && StringUtilities.isNotEmptyOrNull(line.getPlan().getId())) {
						if(StringUtilities.isEmptyOrNull(addedPlans)) {
							addedPlans = line.getPlan().getId();
						} else {
							addedPlans = addedPlans + ", " + line.getPlan().getId();
						}
					}
					// byouPlanSelection
					if (StringUtilities.isNotEmptyOrNull(line.getPath())) {
						if (CollectionUtilities.isEmptyOrNull(byouPlanSelection.get(line.getMtn())))
							byouPlanSelection.put(line.getMtn(), new HashMap<>());
						if (StringUtilities.isNotEmptyOrNull(line.getAction()))
							byouPlanSelection.get(line.getMtn()).put("action", line.getAction());
						if (StringUtilities.isNotEmptyOrNull(line.getPath()))
							byouPlanSelection.get(line.getMtn()).put("path", line.getPath());
					}
				}
				if(StringUtilities.isNotEmptyOrNull(addedPlans))
					logger.info("Plan(s) added: {}", addedPlans);

				/* NSADT-72401 : F&S - NSA NC - Sensitive Info Disclosure - Case id, ClientID and Client */
				if (pegaResponse != null && pegaResponse.getServiceBody() != null
						&& CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))
						&& pegaResponse.getServiceBody().getServiceResponse() != null
						&& pegaResponse.getServiceBody().getServiceResponse().getContext() != null) {

					pegaResponse.getServiceBody().getServiceResponse().getContext().setCaseId(null);
					if (pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo() != null)
						pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setCartId(null);
					//hiding sensitive info for BBP channel - VZWYN-18780
					CartPegaResponseUtil.formatResponseForBBPChannel(pegaResponse.getServiceHeader(),pegaResponse.getServiceBody().getServiceResponse());
					if(pegaResponse.getServiceHeader() != null)
						pegaResponse.getServiceHeader().setClientId(null);
				}
				if (null != pegaResponse.getServiceBody()) {
					if (null != pegaResponse.getServiceBody().getServiceResponse()) {
						if (null != pegaResponse.getServiceBody().getServiceResponse().getContext()) {
							if (null != pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()) {
								CartServiceCartInfo cartInfo = pegaResponse.getServiceBody().getServiceResponse()
										.getContext().getCartInfo();
								if (null != cartInfo.getLines() && cartInfo.getLines().length >= 1) {


									//WHW upgrade and downgrade changes

									Line line = cartInfo.getLines()[0];
									line.setFeature("");
									if (line.getDisqualifiedPropositions() != null &&
											line.getDisqualifiedPropositions().size() > 0) {
										List<Propositions> disQualifiedPropositionsList = line.getDisqualifiedPropositions().stream().filter
												(resp -> (CartConstants.ACTION_D.equalsIgnoreCase(resp.getActionCode()) && (CartConstants.EXTENDER.equalsIgnoreCase(resp.getRewardType())
														&& (CartConstants.REDEEMED.equalsIgnoreCase(resp.getWhwRedemptionStatus()))))).collect(Collectors.toList());
										if (disQualifiedPropositionsList != null && disQualifiedPropositionsList.size() > 0) {
											line.setFeature("downgrade");
										}

									}

									if (line.getQualifiedPropositions() != null &&
											line.getQualifiedPropositions().size() > 0) {
										List<Propositions> QualifiedPropositionsList = line.getQualifiedPropositions().stream().filter
												(resp -> (CartConstants.ACTION_A.equalsIgnoreCase(resp.getActionCode()) && (CartConstants.EXTENDER.equalsIgnoreCase(resp.getRewardType())
														&& (CartConstants.N.equalsIgnoreCase(line.getCrsp()))))).collect(Collectors.toList());
										if (QualifiedPropositionsList != null && QualifiedPropositionsList.size() > 0) {
											line.setFeature("upgrade");
										}
									}


									Mono<Boolean> updateConflictStatus = Mono.just(false);
									if (StringUtilities.isNotEmptyOrNull(request.getChannelId()) &&
											CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))) {
										try {
											// handled this in helper method for Assisted tagging
//											if (!request.getCartInfo().isFlexV2() && null != request.getRetrieveCart())
//												pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setFlow(omniDlHelper.getFlow(request, request.getRetrieveCart()));
											updateConflictStatus = redisHelper3.updateConflictStatus().doOnSuccess(onSuccess -> {
												logger.info(" Conflicts status updated in redis...");
											}).doOnError(error -> {
												logger.info("Exception in updating Conflicts status in session...");
											});
										} catch (Exception e) {
											logger.info("Exception in updating Conflicts to session : {}", e.getMessage());
										}
									}
									Mono<String> orderFlowType = redisHelper2.getCartOrderFlowType();
										Mono<Map> bayouPlanSelectionDetails = redisHelper2.getPlanPathDetails();
										Map requestMap = new HashMap();
									Mono<ResponseEntity<GenericResponse>> addPlanResponse = Mono.zip(orderFlowType, bayouPlanSelectionDetails, updateConflictStatus).flatMap(data -> {
										try {
											logger.info(String.format("cart conflicts updated --> %s" , data.getT3()));
											Map<String, Map<String, String>> bayouPlanRedis=new HashMap<>();
											if (CollectionUtilities.isNotEmptyOrNull(data.getT2())) {
												bayouPlanRedis.putAll(data.getT2());
											}
											if (CollectionUtilities.isNotEmptyOrNull(byouPlanSelection)) {
												bayouPlanRedis.putAll(byouPlanSelection);
											}
											if (CollectionUtilities.isNotEmptyOrNull(bayouPlanRedis)) {
												requestMap.put(CartConstants.PLAN_SELECTION_PATH, mapper.writeValueAsString(bayouPlanRedis));
											}
											//Reporting for perk to add plan
											if(StringUtilities.isNotEmptyOrNull(request.getData().getIsPerksSelectedFromVT()) && CartConstants.VT_PERK_SELECTED.equalsIgnoreCase(request.getData().getIsPerksSelectedFromVT())) {
												requestMap.put(CartConstants.VT_PERKS_STATUS, CartConstants.VT_PERK_SUBMIT);
											}
											if(request!=null && request.getCartInfo()!=null && request.getCartInfo().getIntendType()!=null
													&& (!CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType()) &&
													!CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType()))) {
											String processStep = "";
											if (StringUtilities.isNotEmptyOrNull(data.getT1())
													&& data.getT1().contains(CartConstants.EXPRESS))
												processStep = CartConstants.PROMO_HUB;
											String cartOrderFlowType ="";
											if(!CartConstants.AAL.equalsIgnoreCase(Optional.ofNullable(request.getCartInfo()).map(CartInfo::getIntendType).orElse(""))){
												cartOrderFlowType = OrderFlowTypeUtil.calculateCartOrderFlowType(data.getT1(),
														processStep, CartConstants.CPC);
											}else{
												cartOrderFlowType = data.getT1();
											}
											requestMap.put(CartConstants.CART_ORDER_FLOW_TYPE, cartOrderFlowType);
											return redisHelper2.upsertDeviceCartMapInRedis(requestMap)
													.flatMap(orderTypeData -> helper.populateSPOs(cartInfo, pegaResponse).
															flatMap(response -> helper.populateHumWifiConflictedSFos(cartInfo, pegaResponse)).
															flatMap(res ->Mono.just(ResponseEntity.status(HttpStatus.OK).body(pegaResponse))));
											}else{
												return redisHelper2.upsertDeviceCartMapInRedis(requestMap)
														.flatMap(orderTypeData -> helper.populateSPOs(cartInfo, pegaResponse).
														flatMap(response -> helper.populateHumWifiConflictedSFos(cartInfo, pegaResponse)).
														flatMap(res -> Mono.just(ResponseEntity.status(HttpStatus.OK).body(pegaResponse))));
											}
						} catch (Exception e) {
											logger.error("Exception  in add plan while inserting in redis", e);
										}
										return Mono.just(ResponseEntity.status(HttpStatus.OK).body(pegaResponse));
									});
									Mono<Boolean> taggingEnabled = featureFlagHelper.fetchAiQuoteTaggingFeatureFlag();
									return taggingEnabled.flatMap(flag ->{
										addVZDLDataForPlanAndPerks(httpHeader, request, channelId, pegaResponse ,flag);
										return update5GSPOFeature(request, addPlanResponse, httpHeader, httpResponse);
									}).onErrorResume(error-> {
										addVZDLDataForPlanAndPerks(httpHeader, request, channelId, pegaResponse ,false);
										return update5GSPOFeature(request, addPlanResponse, httpHeader, httpResponse);
									});

								}
							}

						}
					}
				}
				if(org.apache.commons.lang3.StringUtils.isNotBlank(request.getChannelId()) && CartConstants.DIGITAL_DDOT_MOB_TAB_CHANNELS.contains(channelId))
					CartPegaResponseErrorsUtil.setErrorCategory(pegaResponse.getErrors(),CartConstants.ERRCAT_CJCM);
				return Mono.just(ResponseEntity.status(HttpStatus.OK).body(pegaResponse));
			}
		});
	}

	public  Mono<AddPlanUIResponse> mergeFeatureFlagWithResponse(Mono<Tuple2<AddPlanUIResponse, ConfigurationProfile>> zip) {
		return zip.flatMap(tuples -> {
					AddPlanUIResponse response = tuples.getT1();
					ConfigurationProfile configurationProfile = tuples.getT2();

					if (configurationProfile != null) {
						Map<String, FlagDetails> featureFlags = configurationProfile.getFlags()
								.stream()
								.collect(Collectors.toMap(Flag::getName, flag -> featureFlagHelper.mapValueToFlagDetails().apply(flag),(oldEntry, newEntry) -> newEntry));

						if ( response != null ) {
							response.setFeatureConfigurationProfileData(featureFlags);
						}
					}
					return Mono.just(response);
				}).doOnError(throwable -> logger.error(String.format("Error fetching configuration profile:", throwable.getMessage())));
	}


	private void addVZDLDataForPlanAndPerks(ServerHttpRequest httpHeader, AddPlanUIRequest request, String channelId, AddPlanUIResponse pegaResponse , Boolean aiQuoteTaggingEnabledFFlag) {
		if (CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(channelId))){
			String flowNameHeader = httpHeader.getHeaders().containsKey(FLOW_NAME)? httpHeader.getHeaders().getFirst(FLOW_NAME):"";
			if(flowNameHeader!=null && flowNameHeader.equalsIgnoreCase(CartConstants.AI_QUOTE)){
				try {
					Vzdl vzdl = dlHelper.getVzdlDataForAddPlanAndPerks(request, pegaResponse, aiQuoteTaggingEnabledFFlag);
					if (vzdl != null) {
						logger.info("VZDL object: {}",vzdl);
						addDeviceHelper.updateDLDataForAssisted(vzdl);
					}
				}catch (Exception e){
					logger.error("Error on Tagging", e);
				}
			}
		}
	}

	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return ResponseEntity
	 *
	 */
	@PostMapping({ "/add-features", "/nse/add-features", "/5g/add-features", "/nse/5g/add-features"})
	public Mono<ResponseEntity<GenericResponse>> addFeatures(ServerHttpRequest httpHeader,
			ServerHttpResponse httpResponse, @Valid @RequestBody AddFeaturesUIRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "add-features");
		logger.debug("add-features Request: {}", request);
		String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
				? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
				: "";
		request.setChannelId(channelId);
		String sessionId = "";
		HttpCookie cookieDigitIgSession = httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION);
		if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId))
				|| CartConstants.EXPRESS_STORE.equalsIgnoreCase(CartUtil.getChannelType(channelId)))
			sessionId = null != cookieDigitIgSession
					? cookieDigitIgSession.getValue()
					: "";

		request.getCartInfo().setSessionId(sessionId);
		return mergeFeatureFlagWithAddFeaturesResponse(Mono.zip(helper.addFeatures(request),featureFlagHelper.fetchDigitalPerformanceCfgProfile())).flatMap(pegaResponse -> {
			ErrorResponse errors2 = null;
			if (pegaResponse.getErrors() != null) {
				errors2 = CartPegaResponseErrorsUtil.handleAddFeaturesResponseErrors(pegaResponse);
				if(org.apache.commons.lang3.StringUtils.isNotBlank(request.getChannelId()) && CartConstants.DIGITAL_DDOT_MOB_TAB_CHANNELS.contains(channelId))
					CartPegaResponseErrorsUtil.setErrorCategory(errors2,CartConstants.ERRCAT_CJCM);
				return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(errors2));
			} else {

				/* NSADT-72401 : F&S - NSA NC - Sensitive Info Disclosure - Case id, ClientID and Client */
				if (pegaResponse != null && pegaResponse.getServiceBody() != null
						&& CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))
						&& pegaResponse.getServiceBody().getServiceResponse() != null
						&& pegaResponse.getServiceBody().getServiceResponse().getContext() != null) {

					pegaResponse.getServiceBody().getServiceResponse().getContext().setCaseId(null);
					Optional.of(pegaResponse.getServiceBody().getServiceResponse().getContext()).map(AddFeaturesContext::getCustomerInfo).ifPresent(customerInfo -> customerInfo.setAccountNumber(null));
					if (pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo() != null)
						pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setCartId(null);
					if (pegaResponse.getServiceHeader() != null)
						pegaResponse.getServiceHeader().setClientId(null);
				}
				if (null != pegaResponse.getServiceBody()) {
					if (null != pegaResponse.getServiceBody().getServiceResponse()) {
						if (null != pegaResponse.getServiceBody().getServiceResponse().getContext()) {
							if (null != pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()) {
								CartServiceCartInfo cartInfo = pegaResponse.getServiceBody().getServiceResponse().getContext()
										.getCartInfo();

								if (null != cartInfo.getLines() && cartInfo.getLines().length >= 1) {
									if (StringUtilities.isNotEmptyOrNull(request.getChannelId()) &&
											CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId())) ) {
										try {
											//cartInfo.setFlow(omniDlHelper.setFlow(request.getFlowName(), "FEA"));
											redisHelper3.resetConflictReviewStatus().doOnSuccess(onSuccess -> {
												logger.info(" Conflicts status updated in redis...");
											}).doOnError(error -> logger.info("Exception in updating Conflicts status in session..."));
										} catch (Exception e) {
											logger.info("Exception in updating Conflicts to session : {}", e.getMessage());
										}
									}
									addVZDLDataForFeatures(httpHeader, request, channelId, pegaResponse);
									return helper.populateSPOsFor5GBolt(cartInfo, pegaResponse).
											flatMap(response -> helper.populateHumWifiConflictedSFos(cartInfo, pegaResponse)).
											flatMap(r -> helper.populateProtectionVersion(request, pegaResponse)).
											flatMap(r -> helper.updateFlowNameForAssisted(request, pegaResponse)).
											flatMap(res -> Mono.just(ResponseEntity.status(HttpStatus.OK).body(pegaResponse)));
								} else
									return helper.populateProtectionVersion(request, pegaResponse);
							}
						}
					}
				}
			}
			return helper.populateProtectionVersion(request, pegaResponse);
		});
	}

	public  Mono<AddFeaturesUIResponse> mergeFeatureFlagWithAddFeaturesResponse(Mono<Tuple2<AddFeaturesUIResponse, ConfigurationProfile>> zip) {
		return zip.flatMap(tuples -> {
			AddFeaturesUIResponse response = tuples.getT1();
			Optional.ofNullable(tuples.getT2())
					.map(ConfigurationProfile::getFlags)
					.ifPresent(listOfFeatureFlags -> {
						var mapOfFeatureFlags = listOfFeatureFlags
								.stream()
								.collect(Collectors.toMap(Flag::getName, flag -> featureFlagHelper.mapValueToFlagDetails().apply(flag),(oldEntry, newEntry) -> newEntry));
						if( response != null) {
							response.setFeatureConfigurationProfileData(mapOfFeatureFlags);
						}
					});
			return Mono.just(response);
		}).doOnError(throwable -> logger.error(String.format("Error fetching configuration profile:", throwable.getMessage())));
	}

	private void addVZDLDataForFeatures(ServerHttpRequest httpHeader, AddFeaturesUIRequest request, String channelId, AddFeaturesUIResponse pegaResponse) {
		if (CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(channelId))){
			String flowNameHeader = httpHeader.getHeaders().containsKey(FLOW_NAME)? httpHeader.getHeaders().getFirst(FLOW_NAME):"";
			String refererHeader = httpHeader.getHeaders().containsKey("Referer")? httpHeader.getHeaders().getFirst("Referer"):"";

			if((flowNameHeader!=null && flowNameHeader.equalsIgnoreCase(CartConstants.AI_QUOTE))||
					(refererHeader!=null && refererHeader.contains("aiquote.html"))){
				try {
					Vzdl vzdl = dlHelper.getVzdlDataForAddFeatures(request, pegaResponse);
					if (vzdl != null) {
						logger.info("VZDL object: {}",vzdl);
						addDeviceHelper.updateDLDataForAssisted(vzdl);
					}
				}catch (Exception e){
					logger.error("Error on Tagging", e);
				}
			}
		}
	}

	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return ResponseEntity
	 *
	 */
	@PostMapping(value = { "/remove-lines", "/nse/remove-lines", "/5g/remove-lines", "/nse/5g/remove-lines", "flexV2/remove-lines", "flexV2/nse/remove-lines", "/nse/remove-device-line"},
			consumes = MediaType.APPLICATION_JSON_VALUE , produces = MediaType.APPLICATION_JSON_VALUE )
	public Mono<ResponseEntity<GenericResponse>> removeLines(ServerHttpRequest httpHeader,
			ServerHttpResponse httpResponse, @Valid @RequestBody RemoveLinesUIRequest request) {
		System.setProperty(CartConstants.ENDPOINT, httpHeader.getPath().value());
		logger.info("remove-lines api endPoint={}, Request={}", httpHeader.getPath().value(), request);

		ErrorResponse errorResponse = CartPegaRequestErrorsUtil.handleRemoveLinesRequestErrors(request);
		if (CollectionUtilities.isNotEmptyOrNull(errorResponse.getErrors())) {
			ErrorResponse errors = validator.convertObjectToString(errorResponse);
			if (null != errors) {
				return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
			}
		}
		if(request.getCartInfo() == null){
			CartInfo cartInfo = new CartInfo();
			request.setCartInfo(cartInfo);
		}
		String channelId = getChannelId(httpHeader);
		request.setChannelId(channelId);
		String sessionId = getSessionId(httpHeader, channelId);
		request.getCartInfo().setSessionId(sessionId);
		String channelType = CartUtil.getChannelType(request.getChannelId());

		if(StringUtilities.isNotEmptyOrNull(String.valueOf(httpHeader.getURI())) && CartUtil.isFlexV2(String.valueOf(httpHeader.getURI()))) {
			request.getCartInfo().setFlexV2(true);
		}
		return helper.removeLines(request).flatMap(pegaResponse -> {
			ErrorResponse errors2 = null;
			if (pegaResponse.getErrors() != null) {
				errors2 = CartPegaResponseErrorsUtil.handleRemoveLinesResponseErrors(pegaResponse);
				return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(errors2));
			} else {
				boolean redisUpdate = true;
				if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId))) {
					removeCartIdCaseIdLoggedUser(pegaResponse);
				}
				if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId)) &&
						null!=request.getCartInfo().getMtnFlow() && request.getCartInfo().getMtnFlow().equalsIgnoreCase("G")) {
						redisUpdate = false;
				}
				if (redisUpdate) {
					redisHelper.deleteAddDeviceDataFromRedis(CartConstants.ADD_DEVICE_REQUEST)
							.subscribeOn(Schedulers.parallel()).subscribe(removedata -> {
								logger.info("addDeviceRequest deleted from Redis {}", removedata);
							});
					redisHelper.deleteProcessingMtnFromRedis(CartConstants.PROCESSING_MTN)
							.subscribeOn(Schedulers.parallel()).subscribe(removeProcessingMtn -> {
								logger.info("ProcessingMtn deleted from Redis {}", removeProcessingMtn);
							});
					redisHelper2.deleteEdgeBuyoutDataFromRedis().subscribeOn(Schedulers.parallel()).subscribe(ed -> {
						logger.info("Deleted EdgeBuyout request from Redis {}", ed);
					});
				}
				/*Add No of Item in cart into cookie*/
				if(CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))
						&& pegaResponse.getValidateCartResponse() != null && pegaResponse.getValidateCartResponse().getData() != null
						&& pegaResponse.getValidateCartResponse().getData().getValidateCartAndUpdate() != null
						&& pegaResponse.getValidateCartResponse().getData().getValidateCartAndUpdate().getLineDetails() != null) {

					logger.info("Add the no devices or accessories in the cart into Cookies.");
					httpResponse.addCookie(ResponseCookie.from(CartConstants.PROSPECT_CART_COUNT,
									String.valueOf(pegaResponse.getValidateCartResponse().getData().getValidateCartAndUpdate().
											getLineDetails().getNumOfAccessoryAndDeviceItemsInCart()))
									.path("/").httpOnly(false).build());
				}

				setCartCountInRemoveLineResp(pegaResponse);
				addCartCountCookie(pegaResponse, httpResponse, EXISTING_CART_COUNT);
				populateRemoveLineCookies(httpHeader, httpResponse, request, pegaResponse);
				if (StringUtilities.isNotEmptyOrNull(pegaResponse.getCartCount())) {
					return redisHelper2.updateDeviceCartCount(pegaResponse.getCartCount(), Boolean.TRUE).flatMap(data -> {
						return redisHelper2.getCartOrderFlowType().flatMap(cartOrderFlowType -> {
							try {
								dlUtilityService.updateDlData(cartOrderFlowType);
							} catch (Exception e) {
								logger.error("Exception while calling dlUtility in removeLines", e);
							}
							String mtnFlow = "";

							if (null != request.getCartInfo().getMtnFlow())
								mtnFlow = request.getCartInfo().getMtnFlow();
							if ((("G").equalsIgnoreCase(mtnFlow)) && (StringUtilities.isNotEmptyOrNull(channelType)
									&& channelType.equalsIgnoreCase(CartConstants.DIGITAL))) {
								return redisHelper2.getRole().flatMap(role -> {
									if (role.equalsIgnoreCase(CartConstants.ACCOUNT_MEMBER)
											|| role.equalsIgnoreCase(CartConstants.MOBILE_SECURE)) {
										return redisHelper.getItemTypeFromRedis().flatMap(actionType -> {
											if (StringUtilities.isNotEmptyOrNull(actionType)
													&& CartConstants.ACCESSORY.equalsIgnoreCase(actionType)) {
												Mono<CartRedisData> fetchedRedisData = redisHelper
														.getAccessoryDataFromRedisAsString();
												return fetchedRedisData.flatMap(redisData -> {
													if (null != redisData.getAccessoryCartInfo()) {
														String intendType = null;
														if (null != pegaResponse.getServiceBody()
																&& null != pegaResponse.getServiceBody()
																		.getServiceResponse()
																&& null != pegaResponse.getServiceBody()
																		.getServiceResponse().getContext()) {
															intendType = redisData.getAccessoryCartInfo()
																	.getIntendType();
															String caseId = pegaResponse.getServiceBody()
																	.getServiceResponse().getContext().getCaseId();
															String cartId = pegaResponse.getServiceBody()
																	.getServiceResponse().getContext().getCartInfo()
																	.getCartId();
															removeCartIdCaseid(pegaResponse);
															if (intendType.equalsIgnoreCase(CartConstants.ACC))
																return helper.addAccessoryClearAndContinue(redisData,
																		cartId, caseId).flatMap(accPegaResponse -> {
																			ErrorResponse error = null;
																			if (accPegaResponse.getErrors() != null) {
																				error = CartPegaResponseErrorsUtil
																						.handleAddAccessoriesResponseErrors(
																								accPegaResponse);
																				return Mono.just(ResponseEntity
																						.status(httpResponse
																								.getStatusCode())
																						.body(error));
																			} else {
																				return Mono.just(ResponseEntity
																						.status(HttpStatus.OK)
																						.body(accPegaResponse));
																			}
																		});
														}
													}
													return Mono.just(
															ResponseEntity.status(HttpStatus.OK).body(pegaResponse));
												});
											}
											if (StringUtilities.isNotEmptyOrNull(actionType)
													&& CartConstants.DEVICE.equalsIgnoreCase(actionType)) {
												Mono<CartRedisData> fetchedRedisData = redisHelper
														.getDataFromRedisAsString();
												return fetchedRedisData.flatMap(redisData -> {
													if (null != redisData.getDeviceCartInfo()) {
														String intendType = "";
														String caseId = "";
														String cartId = "";
														if (null != pegaResponse.getServiceBody()
																&& null != pegaResponse.getServiceBody()
																		.getServiceResponse()
																&& null != pegaResponse.getServiceBody()
																		.getServiceResponse().getContext()) {
															intendType = redisData.getDeviceCartInfo().getIntendType();

															if (StringUtilities.isNotEmptyOrNull(
																	pegaResponse.getServiceBody().getServiceResponse()
																			.getContext().getCaseId()))
																caseId = pegaResponse.getServiceBody()
																		.getServiceResponse().getContext().getCaseId();
															if (StringUtilities.isNotEmptyOrNull(
																	pegaResponse.getServiceBody().getServiceResponse()
																			.getContext().getCartInfo().getCartId()))
																cartId = pegaResponse.getServiceBody()
																		.getServiceResponse().getContext().getCartInfo()
																		.getCartId();
															removeCartIdCaseid(pegaResponse);
															if (CartConstants.AAL.equalsIgnoreCase(intendType))
																return helper.addDeviceClearAndContinue(redisData,
																		cartId, caseId, channelId,httpResponse, null).flatMap(devicePegaResponse -> {
																			ErrorResponse error = null;
																			if (devicePegaResponse
																					.getErrors() != null) {
																				error = CartPegaResponseErrorsUtil
																						.handleAddDeviceResponseErrors(
																								devicePegaResponse);
																				return Mono.just(ResponseEntity
																						.status(httpResponse
																								.getStatusCode())
																						.body(error));
																			} else {
																				return Mono.just(ResponseEntity
																						.status(HttpStatus.OK)
																						.body(devicePegaResponse));
																			}
																		});
														}
													}
													removeCartIdCaseid(pegaResponse);
													return Mono.just(
															ResponseEntity.status(HttpStatus.OK).body(pegaResponse));
												});
											}
											removeCartIdCaseid(pegaResponse);
											return Mono.just(ResponseEntity.status(HttpStatus.OK).body(pegaResponse));
										});
									}
									removeCartIdCaseid(pegaResponse);
									return Mono.just(ResponseEntity.status(HttpStatus.OK).body(pegaResponse));
								});
							}
							removeCartIdCaseid(pegaResponse);
							return Mono.just(ResponseEntity.status(HttpStatus.OK).body(pegaResponse));
						});
					});
				}
				removeCartIdCaseid(pegaResponse);
				return Mono.just(ResponseEntity.status(HttpStatus.OK).body(pegaResponse));
			}
		});
	}

	public void populateRemoveLineCookies(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse, RemoveLinesUIRequest request, RemoveLinesUIResponse pegaResponse) {
		boolean ngdProspectClearCartEnabled = isNgdProspectClearCartEnabled();
		logger.info("NGD clear cart cookies enabled for remove lines {}", ngdProspectClearCartEnabled);
		if (ngdProspectClearCartEnabled && request.getCartInfo().getIntendType().equalsIgnoreCase(NSE) &&
				pegaResponse != null) {
			Integer cartItemCount = Optional.ofNullable(pegaResponse.getServiceBody())
					.map(RemoveLinesServiceBody::getServiceResponse)
					.map(RemoveLinesServiceResponse::getContext)
					.map(RemoveLinesContext::getCartInfo).map(CartServiceCartInfo::getCartItemCount).orElse(0);
			if (cartItemCount == 0) {
				setClearCartCookies(httpHeader, httpResponse, Optional.of(0));
			}
		}
	}

	private void removeCartIdCaseIdLoggedUser(RemoveLinesUIResponse pegaResponse) {
		Optional.of(pegaResponse).map(RemoveLinesUIResponse::getServiceHeader).ifPresent(header -> header.setClientId(null));
		Optional.of(pegaResponse).map(RemoveLinesUIResponse::getServiceBody).map(RemoveLinesServiceBody::getServiceResponse).map(RemoveLinesServiceResponse::getContext).ifPresent(context -> {
			context.setCaseId(null);
			Optional.of(context).map(RemoveLinesContext::getCartInfo).ifPresent(cartInfo -> cartInfo.setCartId(null));
		});
		Optional.of(pegaResponse).map(RemoveLinesUIResponse::getValidateCartResponse).map(ValidateCartUIResponse::getData).map(CXPValidateCartDataVO::getValidateCartAndUpdate).ifPresent(validateCartAndUpdate -> validateCartAndUpdate.setCartId(null));
	}

	public void addCartCountCookie(RemoveLinesUIResponse pegaResponse,ServerHttpResponse httpResponse, String name ){
		Optional.ofNullable(pegaResponse.getServiceBody())
				.map(RemoveLinesServiceBody::getServiceResponse)
				.map(RemoveLinesServiceResponse::getContext)
				.map(RemoveLinesContext::getCartInfo)
				.ifPresent(cartInfo -> httpResponse.addCookie(createCartCountCookie(name, String.valueOf(cartInfo.getCartItemCount()))));
	}
	private ResponseCookie createCartCountCookie(String name, String value) {
		return ResponseCookie.from(name, value)
				.path("/")
				.httpOnly(false)
				.build();
	}
	private void setCartCountInRemoveLineResp(RemoveLinesUIResponse pegaResponse) {
		if(pegaResponse.getServiceBody()!=null && pegaResponse.getServiceBody().getServiceResponse()!=null && pegaResponse.getServiceBody().getServiceResponse().getContext()!=null && pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()!=null)
			pegaResponse.setCartCount(String.valueOf(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartItemCount()));
	}

	private void removeCartIdCaseid(RemoveLinesUIResponse pegaResponse){
		if(pegaResponse != null && pegaResponse.getServiceBody() != null && pegaResponse.getServiceBody().getServiceResponse() != null &&
					pegaResponse.getServiceBody().getServiceResponse().getContext() != null &&
					pegaResponse.getServiceBody().getServiceResponse().getContext().getCustomerInfo() != null &&
					StringUtilities.isNotEmptyOrNull(pegaResponse.getServiceBody().getServiceResponse().getContext().getCustomerInfo().getCustomerType()) &&
					pegaResponse.getServiceBody().getServiceResponse().getContext().getCustomerInfo().getCustomerType().equalsIgnoreCase("N")){
			if(pegaResponse.getServiceHeader() != null){
				pegaResponse.getServiceHeader().setClientId(null);
			}
			pegaResponse.getServiceBody().getServiceResponse().getContext().setCaseId(null);
			if (pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo() != null) {
				pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setCartId(null);
			}
			if (pegaResponse.getValidateCartResponse() != null && pegaResponse.getValidateCartResponse().getData() != null &&
					pegaResponse.getValidateCartResponse().getData().getValidateCartAndUpdate() != null) {
				pegaResponse.getValidateCartResponse().getData().getValidateCartAndUpdate().setCartId(null);
			}
		}
	}


	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return ResponseEntity
	 *
	 */
	@PostMapping({ "/service-address", "/nse/service-address" })
	public Mono<ResponseEntity<GenericResponse>> addServiceAddress(ServerHttpRequest httpHeader,
			ServerHttpResponse httpResponse, @Valid @RequestBody ServiceAddressUIRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "service-address");
		logger.debug("serviceAddress Request: {}", request);
		String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
				? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
				: "";
		request.setChannelId(channelId);
		String sessionId = "";
		HttpCookie cookieDigitIgSession = httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION);
		if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId))
				|| CartConstants.EXPRESS_STORE.equalsIgnoreCase(CartUtil.getChannelType(channelId)))
			sessionId = null != cookieDigitIgSession
					? cookieDigitIgSession.getValue()
					: "";

		request.getCartInfo().setSessionId(sessionId);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleServiceAddressRequestErrors(request);
		if (errors.getErrors() != null)
			return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
		return helper.addServiceAddress(request).map(pegaResponse -> {
			ErrorResponse errors2 = null;
			if (pegaResponse.getErrors() != null) {
				errors2 = CartPegaResponseErrorsUtil.handleServiceAddressResponseErrors(pegaResponse);
			}
			if(CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId))){
				Optional.ofNullable(pegaResponse.getServiceBody()).map(ServiceAddressServiceBody::getServiceResponse).map(ServiceAddressServiceResponse::getContext)
								.ifPresent(context -> {
									context.setCaseId(null);
									Optional.ofNullable(context.getCartInfo()).ifPresent(cartInfo-> cartInfo.setCartId(null));
								});
			}
			return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
					: ResponseEntity.status(HttpStatus.OK).body(pegaResponse);
		});
	}

	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return ResponseEntity
	 *
	 */
	@PostMapping({ "/e911-address", "/nse/e911-address" })
	public Mono<ResponseEntity<GenericResponse>> addE911Address(ServerHttpRequest httpHeader,
			ServerHttpResponse httpResponse, @Valid @RequestBody E911AddressUIRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "e911-address");
		logger.debug("E911Address Request: {}", request);
		String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
				? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
				: "";
		request.setChannelId(channelId);
		String sessionId = "";
		HttpCookie cookieDigitIgSession = httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION);
		if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId))
				|| CartConstants.EXPRESS_STORE.equalsIgnoreCase(CartUtil.getChannelType(channelId)))
			sessionId = null != cookieDigitIgSession
					? cookieDigitIgSession.getValue()
					: "";

		request.getCartInfo().setSessionId(sessionId);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleE911AddressRequestErrors(request);
		if (errors.getErrors() != null)
			return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
		return helper.addE911Address(request).flatMap(bpmResp -> checkIfPartialSuccessAddress(request,bpmResp)).map(pegaResponse -> {
			ErrorResponse errors2 = null;

			if (pegaResponse.getErrors() != null && !httpResponse.getStatusCode().is2xxSuccessful()) {
				errors2 = CartPegaResponseErrorsUtil.handleE911AddressResponseErrors(pegaResponse);
			}
			return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
					: ResponseEntity.status(HttpStatus.OK).body(pegaResponse);
		});
	}


	public Mono<E911AddressUIResponse> checkIfPartialSuccessAddress(E911AddressUIRequest request, E911AddressUIResponse bpmResponse) {
		logger.info("enablePartialSuccessCall -> {}",String.valueOf(enablePartialSuccessCall));
		if(enablePartialSuccessCall && CartConstants.PARTIAL_SUCCESS.equalsIgnoreCase(Optional.ofNullable(bpmResponse).map(E911AddressUIResponse::getServiceHeader).map(CartServiceServiceHeader::getStatusMsg).orElse(""))
				&& !CartConstants.CHANNEL_ID_NUMBERLINK.equalsIgnoreCase(Optional.of(request).map(E911AddressUIRequest::getCartInfo).map(CartInfo::getClientAppName).orElse(""))){
			logger.info("Partial sucess scenario");
			final Optional<List<AlternateAddress>> optionalAlternateAddresses = Optional.of(bpmResponse).map(E911AddressUIResponse::getServiceBody).map(E911AddressServiceBody::getServiceResponse).map(E911AddressServiceResponse::getContext).map(E911AddressContext::getCartInfo).map(CartServiceCartInfo::getAlternateAddress)
					.filter(CollectionUtilities::isNotEmptyOrNull);
			if(optionalAlternateAddresses.isPresent()){
				final AlternateAddress alternateAddress = optionalAlternateAddresses.get().stream().findFirst().orElse(new AlternateAddress());
				final E911AddressUIRequest e911AddressPEGAAltRequest = preparePartialSucessPegaRequest(request, alternateAddress);
				return helper.addE911Address(e911AddressPEGAAltRequest);
			}
		}
		return Mono.just(bpmResponse);
	}

	public E911AddressUIRequest preparePartialSucessPegaRequest(E911AddressUIRequest pegaRequest, AlternateAddress alternateAddress) {
		logger.info("alternateAddress -> {}",alternateAddress);
		Optional.of(pegaRequest).map(E911AddressUIRequest::getData).map(AddE911AddressData::getLines).filter(Objects::nonNull).map(Arrays::asList).filter(CollectionUtilities::isNotEmptyOrNull)
				.ifPresent(lines-> lines.stream().map(Lines::getE911Address).filter(Objects::nonNull)
						.filter(e911Element -> null != e911Element.getAddress()).forEach(e911Element ->{
							e911Element.setSkipAddressValidation("Y");
							e911Element.getAddress().setStreetNumber(alternateAddress.getStreetNumber());
							e911Element.getAddress().setStreetName(alternateAddress.getStreetName());
							e911Element.getAddress().setCity(alternateAddress.getCity());
							e911Element.getAddress().setState(alternateAddress.getState());
							e911Element.getAddress().setZipCode(alternateAddress.getZipCode());
							e911Element.getAddress().setCountry(alternateAddress.getCountry());
							e911Element.getAddress().setApartmentNo(alternateAddress.getApartmentNo());
						}));
		return pegaRequest;
	}

	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return ResponseEntity
	 *
	 */
	@PostMapping("/instant-credit-downPayment")
	public Mono<ResponseEntity<GenericResponse>> addInstantCreditDownPayment(ServerHttpRequest httpHeader,
			ServerHttpResponse httpResponse, @Valid @RequestBody InstantCreditDownPaymentUIRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "nstant-credit-downpayment");
		logger.debug("InstantCreditDownPayments Request: {}", request);
		String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
				? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
				: "";
		request.setChannelId(channelId);
		ErrorResponse errors = CartCxpRequestErrorsUtil.handleInstantCreditDownPaymentRequestErrors(request);
		if (errors.getErrors() != null)
			return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
		return helper.addInstantCreditDownPayment(request).map(pegaResponse -> {
			ErrorResponse errors2 = null;
			if (pegaResponse.getErrors() != null) {
				errors2 = CartPegaResponseErrorsUtil.handleInstantCreditDownPaymentResponseErrors(pegaResponse);
			}
			return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
					: ResponseEntity.status(HttpStatus.OK).body(pegaResponse);
		});
	}

	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return ResponseEntity
	 *
	 */
	@PostMapping("/salesRep")
	public Mono<ResponseEntity<GenericResponse>> updateSalesRepAndLocationCode(ServerHttpRequest httpHeader,
			ServerHttpResponse httpResponse, @Valid @RequestBody SalesRepAndLocationCodeUIRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "salesRep");
		logger.debug("SalesRepAndLocationCode Request: {}", request);
		String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
				? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
				: "";
		request.setChannelId(channelId);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleSalesRepAndLocationCodeRequestErrors(request);
		if (errors.getErrors() != null)
			return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
		return helper.updateSalesRepAndLocationCode(request).map(resp -> {
			ErrorResponse errors2 = null;
			if (resp.getErrors() != null) {
				errors2 = CartPegaResponseErrorsUtil.handleSalesRepAndLocationCodeResponseErrors(resp);
			}
			return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
					: ResponseEntity.status(HttpStatus.OK).body(resp);

		});
	}

	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return ResponseEntity
	 *
	 */
	@PostMapping({ "/updateBarcode", "/nse/updateBarcode","/nse/5g/updateBarcode","/5g/updateBarcode" })
	public Mono<ResponseEntity<GenericResponse>> updateBarcode(ServerHttpRequest httpHeader,
			ServerHttpResponse httpResponse, @Valid @RequestBody UpdateBarcodeUIRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "updateBarcode");
		logger.debug("updateBarcode Request: {}", request);
		String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
				? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
				: "";
		request.setChannelId(channelId);
		String sessionId = "";
		HttpCookie cookieDigitIgSession = httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION);
		if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId))
				|| CartConstants.EXPRESS_STORE.equalsIgnoreCase(CartUtil.getChannelType(channelId)))
			sessionId = null != cookieDigitIgSession
					? cookieDigitIgSession.getValue()
					: "";

		request.getCartInfo().setSessionId(sessionId);
		//GTSFN-4415 add promo code cart creator,globalid implentation for NSEACC standalone accessory
				String digitalIgSession="";
				if ((CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId))
						|| CartConstants.EXPRESS_STORE.equalsIgnoreCase(CartUtil.getChannelType(channelId)))
						&& (CartConstants.NSEACC.equalsIgnoreCase(request.getCartInfo().getIntendType())
						||CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())
						||CartConstants.NSE_5G.equalsIgnoreCase(request.getCartInfo().getIntendType())
						||CartConstants.NSE_LTE.equalsIgnoreCase(request.getCartInfo().getIntendType()))) {
					digitalIgSession = httpHeader.getHeaders().getFirst(CartConstants.DIGITAL_IG_SESSION);
					logger.info("##sessionId## express store: {}", digitalIgSession);
					request.getCartInfo().setCartCreator(digitalIgSession);
					request.getCartInfo().setGlobalId(digitalIgSession);
				}
		//GTSFN-4415 add promo code cart creator,globalid implentation for NSEACC standalone accessory
		return helper.updateBarcode(request).map(resp -> {
			ErrorResponse errors2 = null;
			if (resp.getErrors() != null) {
				errors2 = CartPegaResponseErrorsUtil.handleUpdateBarCodeResponseErrors(resp);
			}
			if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId))){
				CartPegaResponseErrorsUtil.hideSensitiveInfoInResponse(resp);
			}

			// adding subflow for RAFR
			boolean isNSE=false;
			if (httpHeader!=null && httpHeader.getURI()!=null && httpHeader.getURI().getPath()!=null && httpHeader.getURI().getPath().contains(CartConstants.NSE_UPDATE_BARCODE)){
				isNSE=true;
			}
			if (isNSE && resp!=null && resp.getServiceBody()!=null && resp.getServiceBody().getServiceResponse()!=null && resp.getServiceBody().getServiceResponse().getContext()!=null){
				UpdateBarCodeContext context = resp.getServiceBody().getServiceResponse().getContext();
				if (context != null && context.getCartInfo() != null && StringUtilities.isNotEmptyOrNull(context.getCartInfo().getCouponCode())
						&& context.getCartInfo().getCouponCode().startsWith(CartConstants.RAFR_PREFIX)) {
					logger.debug("adding {} subflow in vzPageDl", CartConstants.RAFR_SUBFLOW);
					cxpHelper.appendDlVZPageSubflow(CartConstants.RAFR_SUBFLOW);
				}
			}

			return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
					: ResponseEntity.status(HttpStatus.OK).body(resp);

		});
	}

	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return ResponseEntity
	 *
	 */
	@PostMapping("/mac-address")
	public Mono<ResponseEntity<GenericResponse>> updateMacAddress(ServerHttpRequest httpHeader,
			ServerHttpResponse httpResponse, @Valid @RequestBody MacAddressUIRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "mac-address");
		logger.debug("mac-address Request: {}", request);
		ErrorResponse errors = CartCxpRequestErrorsUtil.handleMacAddressRequestErrors(request);
		if (errors.getErrors() != null)
			return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
		return helper.updateMacAddress(request).map(resp -> {
			ErrorResponse errors2 = null;
			if (resp.getErrors() != null) {
				errors2 = CartCxpResponseErrorsUtil.handleMacAddressResponseErrors(resp);
			}
			return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
					: ResponseEntity.status(HttpStatus.OK).body(resp);
		});
	}


	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return ResponseEntity
	 *
	 */
	@PostMapping({ "/assign-mtn", "/flexV2/assign-mtn", "/nse/assign-mtn", "/nse/5g/assign-mtn" , "/5g/assign-mtn","/5g/cbd/assign-mtn"  })
	public Mono<ResponseEntity<GenericResponse>> assignMtn(ServerHttpRequest httpHeader,
			ServerHttpResponse httpResponse, @Valid @RequestBody AssignMtnUIRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "assign-mtn");
		logger.debug("assign-mtn Request: {}", request);

		ErrorResponse errorResponse = CartPegaRequestErrorsUtil.handleAssignMtnRequestErrors(request);
		if (CollectionUtilities.isNotEmptyOrNull(errorResponse.getErrors())) {
			ErrorResponse errors = validator.convertObjectToString(errorResponse);
			if (null != errors) {
				return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
			}
		}
		String channelId = getChannelId(httpHeader);
		request.setChannelId(channelId);
		request.setPath(httpHeader.getURI().getPath());
		String sessionId = getSessionId(httpHeader, channelId);
		request.getCartInfo().setSessionId(sessionId);
		if (StringUtilities.isNotEmptyOrNull(String.valueOf(httpHeader.getURI())) && CartUtil.isFlexV2(String.valueOf(httpHeader.getURI()))) {
			request.getCartInfo().setFlexV2(true);
		}

		String ngdHeaderKey = httpHeader.getHeaders().getFirst(CartConstants.NGD_HEADER_KEY);
		if(StringUtilities.isNotEmptyOrNull(ngdHeaderKey) && StringUtils.equalsIgnoreCase(ngdHeaderKey, "true")){
			request.setNgdFlow(true);
		}


		return helper.assignMtn(request).map(resp -> {
			if (CollectionUtilities.isEmptyOrNull(resp.getErrors())) {
				return ResponseEntity.status(HttpStatus.OK).body(resp);
			} else {
				ErrorResponse errors2 = CartPegaResponseErrorsUtil.handleAssignMtnResponseErrors(resp);
				if(org.apache.commons.lang3.StringUtils.isNotBlank(request.getChannelId()) && CartConstants.DIGITAL_DDOT_MOB_TAB_CHANNELS.contains(channelId))
					CartPegaResponseErrorsUtil.setErrorCategory(errors2,CartConstants.ERRCAT_APP);
				return ResponseEntity.status(httpResponse.getStatusCode()).body(errors2);
			}
		});
	}


	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return ResponseEntity
	 *
	 */
	@PostMapping(value = { "/clearCart", "/nse/clearCart" })
	public Mono<ResponseEntity<GenericResponse>> clearCart(ServerHttpRequest httpHeader,
			ServerHttpResponse httpResponse, @Valid @RequestBody ClearCartUIRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "clearCart");
		logger.debug("clearCart Request: {}", request);
		String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
				? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
				: "";
		request.setChannelId(channelId);
		// New Customer Transaction Prospect - clear cart change
		String sessionId = "";
		HttpCookie cookieDigitIgSession = httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION);
		if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId))
				|| CartConstants.EXPRESS_STORE.equalsIgnoreCase(CartUtil.getChannelType(channelId)))
			sessionId = null != cookieDigitIgSession
					? cookieDigitIgSession.getValue()
					: "";

		if (StringUtilities.isNotEmptyOrNull((sessionId))) {
			request.getCartInfo().setSessionId(sessionId);
		}
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleClearCartRequestErrors(request);
		if (errors.getErrors() != null)
			return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));

		Mono<ClearCartUIResponse> response = helper.clearCart(request);

		return response.flatMap(pegaResponse -> {
			ErrorResponse errors2 = null;
			if (pegaResponse.getErrors() != null) {
				errors2 = CartPegaResponseErrorsUtil.handleClearCartResponseErrors(pegaResponse);
				return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(errors2));
			} else {
				logger.info("Remove acNextGen cookie when lineDetails is empty");
				httpResponse.addCookie(ResponseCookie.from(CartConstants.AC_NEXTGEN, null)
						.path("/").httpOnly(false).maxAge(0).build());
				/* NSADT-72401 : F&S - NSA NC - Sensitive Info Disclosure - Case id, ClientID and Client */
				if (pegaResponse != null && pegaResponse.getServiceBody() != null
						&& CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))
						&& pegaResponse.getServiceBody().getServiceResponse() != null
						&& pegaResponse.getServiceBody().getServiceResponse().getContext() != null) {

					pegaResponse.getServiceBody().getServiceResponse().getContext().setCaseId(null);
					if (pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo() != null) {
						pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setCartId(null);
						/*Add item count into cookie*/
						httpResponse.addCookie(ResponseCookie.from(CartConstants.PROSPECT_CART_COUNT,
								String.valueOf(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartItemCount()))
								.path("/").httpOnly(false).build());
						// PRODDEF-216 fix
						createClearCartCookies(httpResponse,pegaResponse,EXISTING_CART_COUNT,domains);  // PRODDEF-18958  set the gnCartCount cookie life till the browser is closed

						// PRODDEF-36324
						Optional<Integer> cartItemCount = Optional.ofNullable(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartItemCount());
						addCartCountCookie(httpResponse, EXISTING_CART_COUNT, cartItemCount, httpHeader);
						addCartCountCookie(httpResponse, PROSPECT_CART_COUNT, cartItemCount, httpHeader);
						populateClearCartCookies(httpHeader, httpResponse, cartItemCount);

						httpResponse.addCookie(ResponseCookie.from(CartConstants.ACID, "")
								.path("/").httpOnly(true).secure(true).maxAge(Duration.ofDays(0)).build());
						boolean isHubProspectCartCookieDomainIssueFFlagEnabled = featureFlagHelper.isHubProspectCartCookieDomainIssueFFlagEnabled();
						CartUtil.addHubProspectCartCookieToResponse(httpResponse, isHubProspectCartCookieDomainIssueFFlagEnabled, CartConstants.FALSE, domains);
						if(null != httpHeader.getCookies() && null != httpHeader.getCookies().get(CartConstants.QUICK_SHOP_PROSPECT_CART)) {
							httpResponse.addCookie(ResponseCookie.from(CartConstants.QUICK_SHOP_PROSPECT_CART, "")
									.maxAge(0).path("/").httpOnly(false).build());
						}
						pegaResponse.setCartCount(String.valueOf(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartItemCount()));
					}
					if(pegaResponse.getServiceHeader() != null)
						pegaResponse.getServiceHeader().setClientId(null);
				}
				boolean xboxInClearCartRequest = CartPegaRequestUtil9.isXboxInClearCartRequest(request);
				Mono<Long> redisData = xboxInClearCartRequest ? Mono.just(0L) : redisHelper.deleteAddDeviceDataFromRedis(CartConstants.ADD_DEVICE_REQUEST);
				return redisData.flatMap(removedata -> {

						if (StringUtilities.isNotEmptyOrNull(pegaResponse.getCartCount())) {
							Mono<Boolean> updatedCount = redisHelper2.updateDeviceCartCount(pegaResponse.getCartCount(), Boolean.TRUE);
							return updatedCount.flatMap(updateddata -> {
								return Mono.just(ResponseEntity.status(HttpStatus.OK).body(pegaResponse));
							});
						}
						return Mono.just(ResponseEntity.status(HttpStatus.OK).body(pegaResponse));

				});
			}
		});
	}

	public void populateClearCartCookies(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse, Optional<Integer> cartItemCount) {
		boolean ngdProspectClearCartEnabled = isNgdProspectClearCartEnabled();
		logger.info("NGD clear cart cookies enabled for clear cart {}", ngdProspectClearCartEnabled);
		if (ngdProspectClearCartEnabled) {
			setClearCartCookies(httpHeader, httpResponse, cartItemCount);
		}
	}

	private boolean isNgdProspectClearCartEnabled() {
		return featureFlagHelper.isNgdProspectClearCartCookiesEnabled();
	}

	public static String extractURL(ServerHttpRequest httpHeader) {
		String url = CommonUtil.validateAndExtractURL(httpHeader.getHeaders().get("X-Host"));
		if (StringUtilities.isEmptyOrNull(url)) url = httpHeader.getURI().getHost();
		return url;
	}

	public void setClearCartCookies(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse, Optional<Integer> cartItemCount) {
		httpResponse.addCookie(ResponseCookie.from(CartConstants.PROSPECT_DEVICE_COUNT,
						String.valueOf(cartItemCount))
				.path("/").httpOnly(false).build());
		addCartCountCookie(httpResponse, PROSPECT_DEVICE_COUNT, cartItemCount, httpHeader);
		addCartCountCookie(httpResponse, PROSPECT_CART_COUNT, cartItemCount, httpHeader);
		httpResponse.addCookie(ResponseCookie.from(PROSPECT_CART_AVAILABLE,
				CartConstants.FALSE).path("/").httpOnly(false).build());
		httpResponse.addCookie(ResponseCookie.from(CartConstants.ACC_IN_CART,CartConstants.FALSE)
				.path("/").httpOnly(false).maxAge(-1).build());
		httpResponse.addCookie(ResponseCookie.from(PROSPECT_CART_ACTIVE,
				CartConstants.FALSE).path("/").httpOnly(false).build());
	}

	public void addCartCountCookie(ServerHttpResponse httpResponse, String cartType, Optional<Integer> cartItemCount,ServerHttpRequest httpHeader) {
		ResponseCookie.ResponseCookieBuilder cookieBuilder;
		if (cartItemCount.isPresent()) {
			cookieBuilder = ResponseCookie.from(cartType, String.valueOf(cartItemCount.get()));
		} else {
			cookieBuilder = ResponseCookie.from(cartType, "0");
		}
		cookieBuilder.path("/");
		cookieBuilder.domain(CommonUtil.removeHostPrefix(httpHeader.getURI().getHost()));
		cookieBuilder.httpOnly(false);
		httpResponse.addCookie(cookieBuilder.build());
	}

	/**
	 * 
	 * @param httpHeader
	 * @param httpResponse
	 * @param applyOfferRequest
	 * @return cxpResponse
	 */
	@PostMapping("/applyEquipmentOffers")
	public Mono<ResponseEntity<MyOffersCXPResponse>> updateMyOffers(ServerHttpRequest httpHeader,
			ServerHttpResponse httpResponse, @Valid @RequestBody ApplyOfferRequest applyOfferRequest) {
		System.setProperty(CartConstants.ENDPOINT, "applyEquipmentOffers");
		logger.debug("applyEquipmentOffers Request: {}", applyOfferRequest);
		String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
				? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
				: "";
		if (null != applyOfferRequest.getCartInfo() && null != applyOfferRequest.getCartInfo().getIsEquipmentOffer())
			return helper.updateMyOffers(channelId).flatMap(cxpResponse -> {
				if (cxpResponse.getErrors() != null) {
					return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(cxpResponse));
				} else {
					return Mono.just(ResponseEntity.status(HttpStatus.OK).body(cxpResponse));
				}

			});
		else
			return Mono.just(ResponseEntity.status(HttpStatus.OK).body(new MyOffersCXPResponse()));
	}
	private Mono<ResponseEntity<GenericResponse>> handleAccessory(CartRedisData redisData, CartRedisData data, ServerHttpResponse httpResponse) {
		return helper.addAccessoryClearAndContinue(redisData, data.getCartId(), data.getCaseId()).flatMap(pegaResponse -> {
			ErrorResponse errors = null;
			if (pegaResponse.getErrors() != null && !httpResponse.getStatusCode().is2xxSuccessful()) {
				errors = CartPegaResponseErrorsUtil.handleAddAccessoriesResponseErrors(pegaResponse);		
				return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(errors));
			} else {
				addDeviceHelper.removeCaseAndCartIdResponse(pegaResponse.getServiceBody(),data.getChannelId());
				return Mono.just(ResponseEntity.status(HttpStatus.OK).body(pegaResponse));
			}
		});
	}
	private Mono<ResponseEntity<GenericResponse>> handleDevice(CartRedisData redisData, CartRedisData data, ServerHttpResponse httpResponse,CartInfo cartInfo) {
		return helper.addDeviceClearAndContinue(redisData, data.getCartId(), data.getCaseId(), data.getChannelId(),httpResponse, cartInfo).flatMap(pegaResponse -> {
			ErrorResponse errors = null;
			if (pegaResponse.getErrors() != null && !httpResponse.getStatusCode().is2xxSuccessful()) {
				errors = CartPegaResponseErrorsUtil.handleAddDeviceResponseErrors(pegaResponse);
				return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(errors));
			} else {
				addDeviceHelper.removeCaseAndCartIdResponse(pegaResponse.getServiceBody(),data.getChannelId());
				return Mono.just(ResponseEntity.status(HttpStatus.OK).body(pegaResponse));
			}
		});
	}
	private String fetchIntendType(CartRedisData redisData, String actionType) {
		String intendType = null;
		if (CartConstants.DEVICE.equalsIgnoreCase(actionType)) {
			intendType = redisData.getDeviceCartInfo().getIntendType();
		} else if (CartConstants.ACCESSORY.equalsIgnoreCase(actionType)) {
			intendType = redisData.getAccessoryCartInfo().getIntendType();
		}
		return intendType;
	}
	private String getChannelId(ServerHttpRequest httpHeader) {
		return httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID) ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID) : "";
	}
	private String getSessionId(ServerHttpRequest httpHeader, String channelId) {
		String sessionId = "";
		HttpCookie cookieDigitIgSession = httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION);
		if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId))
				|| CartConstants.EXPRESS_STORE.equalsIgnoreCase(CartUtil.getChannelType(channelId)))
			sessionId = null != cookieDigitIgSession ? cookieDigitIgSession.getValue() : "";
		HttpCookie cookieAssistedSession = httpHeader.getCookies().getFirst(CartConstants.ASSISTED_IG_SESSION_ID);
		if (StringUtilities.isEmptyOrNull(sessionId) && (CartConstants.RETAIL.equalsIgnoreCase(channelId) || CartConstants.RETAIL_IPAD.equalsIgnoreCase(channelId)))
			sessionId = null != cookieAssistedSession ? cookieAssistedSession.getValue() : "";
		return sessionId;
	}
	public  Mono<ResponseEntity<GenericResponse>>  callToUpdateCartIdAndCaseIdIntoRedis(ServerHttpResponse httpResponse, CartRedisData rr, CartInfo cartInfo, Object responseBody, boolean isclearAndResume) {
		logger.info("Inside callToUpdateCartIdAndCaseIdIntoRedis :: isCallingFromCartResumeController : {}",isclearAndResume);
		return redisHelper.updateCartIdAndCaseIdIntoRedis(rr).flatMap(cartCaseData -> {
			String mtnFlowObj = cartInfo.getMtnFlow();
			String mtnFlow = "";
			if (null != mtnFlowObj)
				mtnFlow = mtnFlowObj;
			if (("").equalsIgnoreCase(mtnFlow) || ("G").equalsIgnoreCase(mtnFlow)) {
				return redisHelper.getItemTypeFromRedis().flatMap(actionType -> {
					if (StringUtilities.isNotEmptyOrNull(actionType) && !CartConstants.SECOND_NUMBER_PAGE.equalsIgnoreCase(cartInfo.getProcessStep())) {
						Mono<CartRedisData> fetchedRedisData = null;
						if (CartConstants.DEVICE.equalsIgnoreCase(actionType))
							fetchedRedisData = redisHelper.getDataFromRedisAsString();
						else if (CartConstants.ACCESSORY.equalsIgnoreCase(actionType))
							fetchedRedisData = redisHelper.getAccessoryDataFromRedisAsString();
						return fetchedRedisData.flatMap(redisData -> {
							if (null != redisData.getDeviceCartInfo() || null != redisData.getAccessoryCartInfo()) {
								if (isclearAndResume) {
									return Mono.just(ResponseEntity.status(HttpStatus.OK).body(getGenericResponse(responseBody)));
								} else {
									String intendType = fetchIntendType(redisData, actionType);
									if (StringUtilities.isNotEmptyOrNull(intendType) && (CartConstants.AAL.equalsIgnoreCase(intendType) || CartConstants.ACC.equalsIgnoreCase(intendType))) {
										if (CartConstants.DEVICE.equalsIgnoreCase(actionType)) {
											return handleDevice(redisData, rr, httpResponse, cartInfo);
										} else if (CartConstants.ACCESSORY.equalsIgnoreCase(actionType)) {
											return handleAccessory(redisData, rr, httpResponse);
										}
									}
									return Mono.just(ResponseEntity.status(HttpStatus.OK).body(getGenericResponse(responseBody)));
								}

							} else {
								ErrorResponse errors = CartPegaRequestErrorsUtil.handleClearAndContinueRequestErrors(CartConstants.DEVICE_ACCESSORY);
								return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
							}
						});
					} else {
						logger.info("mtnFlow is G in the request from UI & itemType in Redis is empty: either session expired or UI sent it wrongly for MTN first flow.");
						return Mono.just(ResponseEntity.status(HttpStatus.OK).body(getGenericResponse(responseBody)));
					}
				});
			}

			return Mono.just(ResponseEntity.status(HttpStatus.OK).body(getGenericResponse(responseBody)));
		});
	}
	GenericResponse getGenericResponse(Object response){
		String sanitizedData = "";
		GenericResponse  sanitizedReponseData = new ClearAndContinueUIResponse();
		logger.info("Converting response object to generic response");
		try {
			sanitizedData = JsonSanitizer.sanitize(mapper.writeValueAsString(response));
			sanitizedReponseData = mapper.readValue(sanitizedData, ClearAndContinueUIResponse.class);
		} catch (JsonProcessingException e) {
			logger.error("Exception occur during converting/reconvert response to String/Object", e);
		}
		return sanitizedReponseData;
	}

	private Mono<ResponseEntity<GenericResponse>> update5GSPOFeature(AddPlanUIRequest planUIRequest, Mono<ResponseEntity<GenericResponse>> addPlanResponse,
									ServerHttpRequest httpHeader, ServerHttpResponse httpResponse){
		if(!disableOzzieDiscount && null != planUIRequest
				&& StringUtilities.isNotEmptyOrNull(planUIRequest.getChannelId())
				&& CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(planUIRequest.getChannelId()))
				&& null != planUIRequest.getCartInfo()
				&& StringUtilities.isNotEmptyOrNull(planUIRequest.getCartInfo().getIntendType())
				&& (("AAL_5G".equalsIgnoreCase(planUIRequest.getCartInfo().getIntendType()))
				|| ("AAL_LTE".equalsIgnoreCase(planUIRequest.getCartInfo().getIntendType())))) {
			Mono<MyOfferETRRedisData> moEtrData = redisHelper.getMyOfferETRDataFromRedis();
			if(null != moEtrData){
				return moEtrData.flatMap(offerLines -> {
						AddFeaturesUIRequest featureRequest = CartPegaRequestUtil6.buildAddFeaturesOfferRequest(planUIRequest, offerLines);
						if(null == featureRequest || (null != featureRequest && null == featureRequest.getData())
								|| (null != featureRequest && null != featureRequest.getData() && null == featureRequest.getData().getLines())
								|| (null !=  featureRequest && null != featureRequest.getData() && null != featureRequest.getData().getLines()
							&& featureRequest.getData().getLines().length <= 0) ){
							logger.info("Bad Add Feature Request found");
							return addPlanResponse;
						}
						return addFeatures(httpHeader, httpResponse, featureRequest).flatMap(feature -> {
								return addPlanResponse;
						});
				});
			}
		}
		return addPlanResponse;
	}

    @PostMapping(value = {  "/nse/ngd/deleteCart" })
    public Mono<ResponseEntity<GenericResponse>> ngdDeleteCart(ServerHttpRequest httpHeader,
                                                           ServerHttpResponse httpResponse, @Valid @RequestBody DeleteCartUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "delete cart");
        logger.debug(" Inside deleteCart endpoint, Request: {}", request);

        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);

        String sessionId = "";
        HttpCookie cookieDigitIgSession = httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION);
        if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId))) {
			sessionId = null != cookieDigitIgSession
					? cookieDigitIgSession.getValue()
					: "";
		}
        if (StringUtilities.isNotEmptyOrNull((sessionId))) {
            request.getCartInfo().setSessionId(sessionId);
        }

        ErrorResponse errors = CartPegaRequestErrorsUtil.handleDeleteCartRequestErrors(request);
        if (errors.getErrors() != null)
            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));

        Mono<DeleteCartUIResponse> response = helper1.ngdDeleteCart(request);

        return response.flatMap(pegaResponse -> {
            ErrorResponse errors2 = null;
            if (pegaResponse.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil.handleDeleteCartResponseErrors(pegaResponse);
                return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(errors2));
            } else {
                /* NSADT-72401 : F&S - NSA NC - Sensitive Info Disclosure - Case id, ClientID and Client */
                if (pegaResponse != null && pegaResponse.getServiceBody() != null
                        && CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))
                        && pegaResponse.getServiceBody().getServiceResponse() != null
                        && pegaResponse.getServiceBody().getServiceResponse().getContext() != null) {

                    pegaResponse.getServiceBody().getServiceResponse().getContext().setCaseId(null);
                    if (pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo() != null) {
                        pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setCartId("");
                        /*Add item count into cookie*/
                        httpResponse.addCookie(ResponseCookie.from(CartConstants.PROSPECT_CART_COUNT,
                                        String.valueOf(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartItemCount()))
                                .path("/").httpOnly(false).build());
                        httpResponse.addCookie(ResponseCookie.from(EXISTING_CART_COUNT,
                                        String.valueOf(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartItemCount()))
                                .path("/").httpOnly(false).maxAge(-1).build());  // PRODDEF-18958  set the gnCartCount cookie life till the browser is closed
                        httpResponse.addCookie(ResponseCookie.from(CartConstants.ACID, "")
                                .path("/").httpOnly(true).secure(true).maxAge(Duration.ofDays(0)).build());
						boolean isHubProspectCartCookieDomainIssueFFlagEnabled= featureFlagHelper.isHubProspectCartCookieDomainIssueFFlagEnabled();
						CartUtil.addHubProspectCartCookieToResponse(httpResponse, isHubProspectCartCookieDomainIssueFFlagEnabled, CartConstants.FALSE, domains);
                        if(null != httpHeader.getCookies() && null != httpHeader.getCookies().get(CartConstants.QUICK_SHOP_PROSPECT_CART)) {
                            httpResponse.addCookie(ResponseCookie.from(CartConstants.QUICK_SHOP_PROSPECT_CART, "")
                                    .maxAge(0).path("/").httpOnly(false).build());
                        }
                    }
                    if(pegaResponse.getServiceHeader() != null)
                        pegaResponse.getServiceHeader().setClientId(null);
                }
                Mono<Long> redisData = redisHelper.deleteAddDeviceDataFromRedis(CartConstants.ADD_DEVICE_REQUEST);
                return redisData.flatMap(removedata -> {
                    if (StringUtilities.isNotEmptyOrNull(pegaResponse.getCartCount())) {
                        Mono<Boolean> updatedCount = redisHelper2.updateDeviceCartCount(pegaResponse.getCartCount(), Boolean.TRUE);
                        return updatedCount.flatMap(updateddata -> {
                            return Mono.just(ResponseEntity.status(HttpStatus.OK).body(pegaResponse));
                        });
                    }
                    return Mono.just(ResponseEntity.status(HttpStatus.OK).body(pegaResponse));

                });
            }
        });
    }
}
