package onevz.soe.cart.bpm.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.bpm.service.CartServiceBPMServices;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.helper.FeatureFlagHelper;
import onevz.soe.cart.helper.RedisHelper2;
import onevz.soe.cart.helper.RedisHelper3;
import onevz.soe.cart.model.addTruckRoll.*;
import onevz.soe.cart.model.affirmfinancing.AffirmFinancingPegaRequest;
import onevz.soe.cart.model.affirmfinancing.AffirmFinancingPegaResponse;
import onevz.soe.cart.model.deviceIdValidation.SearchAttributes;
import onevz.soe.cart.model.emailToCart.EmailCartToCustomerData;
import onevz.soe.cart.model.getCase.GetCaseRequest;
import onevz.soe.cart.model.getCase.GetCaseResponse;
import onevz.soe.cart.model.myOffers.MetaResponse;
import onevz.soe.cart.model.salesOrderAdjustment.LineDetails;
import onevz.soe.cart.model.salesOrderAdjustment.LineInfo;
import onevz.soe.cart.requests.*;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.smartimeisearch.DeviceIdValidationRequestFormatter;
import onevz.soe.cart.tys.reviewOrder.ReviewOrderPegaRequest;
import onevz.soe.cart.tys.reviewOrder.ReviewOrderPegaResponse;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.cart.util.*;
import onevz.soe.orderprocess.request.ApptInfo;
import onevz.soe.orderprocess.request.InstallApptSelectedDate;
import onevz.soe.orderprocess.request.ScheduleAppointmentRequest;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.bpm.model.ServiceHeader;
import onevz.soe.wsclient.bpm.model.response.Error;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import jakarta.validation.Valid;
import java.util.*;
import java.util.concurrent.ExecutionException;

@Service
public class CartServiceBpmHelper3 {

	private static final Logger logger = LoggerFactory.getLogger(CartServiceBpmHelper3.class);

	@Autowired
	private DeviceIdValidationRequestFormatter formatter;

	@Autowired
	FeatureFlagHelper featureFlagHelper;

	@Autowired
	private CartServiceBPMServices services;

	@Autowired
	private RedisHelper2 redisHelper2;

	@Autowired
	private RedisHelper3 redisHelper3;
	@Autowired
	private ObjectMapper mapper;

	@Value("${planSku}")
	private boolean planSku;

	@Value("${enableSecurityForCart}")
	private boolean enableSecurityForCart;

	@Autowired
	SOELoginSessionBean soeLoginSessionBean;
	
	/**
	 * 
	 * @param uiRequest
	 * @return SalesRepAndLocationCodeUIResponse @
	 */
	public Mono<SalesRepAndLocationCodeUIResponse> updateSalesRepAndLocationCode(
			SalesRepAndLocationCodeUIRequest uiRequest) {

		SalesRepAndLocationCodePEGARequest request = new SalesRepAndLocationCodePEGARequest();

		// convert uiRequest to pega request
		CartPegaRequestUtil9.formatUpdateSalesRepAndLocationCodeRequest(request, uiRequest);
		logger.debug("UpdateSalesRepAndLocationCode PEGA Request: {}", request);

		Mono<SalesRepAndLocationCodePEGAResponse> responseServiceMono = null;
		try {
			// pega call
			responseServiceMono = services.updateSalesRepAndLocationCode(request);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		SalesRepAndLocationCodeUIResponse soeResponse = new SalesRepAndLocationCodeUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
			// convert pega response to ui response
			CartPegaResponseUtil1.formatUpdateSalesRepAndLocationCodeResponse(soeResponse, pegaResponse);
			return Mono.just(soeResponse);
		});
	}

	/**
	 * 
	 * @param uiRequest
	 * @return SplitExceededAmountUIResponse
	 * @throws JsonProcessingException
	 */
	public Mono<SplitExceededAmountUIResponse> splitExceededAmount(SplitExceededAmountUIRequest uiRequest) {

		SplitExceededAmountPEGARequest request = new SplitExceededAmountPEGARequest();

		// convert uiRequest to pega request
		CartPegaRequestUtil5.formatSplitExceededAmountRequest(request, uiRequest);
		logger.debug("splitExceededAmount PEGA Request: {}", request);
		Mono<SplitExceededAmountPEGAResponse> responseServiceMono = null;
		try {
			// pega call
			responseServiceMono = services.splitExceededAmount(request);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		SplitExceededAmountUIResponse soeResponse = new SplitExceededAmountUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
			// convert pega response to ui response
			CartPegaResponseUtil1.formatSplitExceededAmountResponse(soeResponse, pegaResponse);
			return Mono.just(soeResponse);
		});
	}

	/**
	 * 
	 * @param uiRequest
	 * @return ManualPairingUIResponse @
	 */
	public Mono<ManualPairingUIResponse> manualPairing(ManualPairingUIRequest uiRequest) {

		ManualPairingPEGARequest request = new ManualPairingPEGARequest();

		// convert uiRequest to pega request
		CartPegaRequestUtil5.formatManualPairingRequest(request, uiRequest);
		logger.debug("ManualPairing PEGA Request: {}", request);

		Mono<ManualPairingPEGAResponse> responseServiceMono = null;
		try {
			// pega call
			responseServiceMono = services.manualPairing(request);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		ManualPairingUIResponse soeResponse = new ManualPairingUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
			// convert pega response to ui response
			CartPegaResponseUtil.formatManualPairingResponse(soeResponse, pegaResponse);
			return Mono.just(soeResponse);
		});
	}
	
	/**
	 *
	 * @param uiRequest
	 * @return CancelCaseUIResponse
	 * @throws JsonProcessingException
	 */
	public Mono<CancelCaseUIResponse> cancelCase(CancelCaseUIRequest uiRequest) {

		CancelCasePEGARequest request = new CancelCasePEGARequest();

		// convert uiRequest to pega request
		CartPegaRequestUtil6.formatCancelCaseRequest(request, uiRequest);
		logger.debug("CancelCase PEGA Request: {}", request);
		Mono<CancelCasePEGAResponse> responseServiceMono = null;
		try {
			// pega call
			responseServiceMono = services.cancelCase(request);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		CancelCaseUIResponse soeResponse = new CancelCaseUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
			// convert pega response to ui response
			CartPegaResponseUtil1.formatCancelCaseResponse(soeResponse, pegaResponse);
			return Mono.just(soeResponse);
		});
	}

	/**
	 *
	 * @param uiRequest
	 * @return DeviceIdValidationUIResponse
	 * @throws JsonProcessingException
	 */
	public Mono<DeviceIdValidationUIResponse> deviceIdValidation(DeviceIdValidationUIRequest uiRequest, SearchAttributes searchAttributes) {

		DeviceIdValidationPEGARequest request = new DeviceIdValidationPEGARequest();

		// convert uiRequest to pega request
		request = formatter.formatDeviceIdValidationRequest(uiRequest, request, searchAttributes);
		logger.debug("DeviceIdValidation PEGA Request: {}", request);
		Mono<DeviceIdValidationPEGAResponse> responseServiceMono = null;
		try {
			// pega call
			responseServiceMono = services.validateDeviceId(request);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		DeviceIdValidationUIResponse soeResponse = new DeviceIdValidationUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
			// convert pega response to ui response
			CartPegaResponseUtil1.formatDeviceIdValidationResponse(pegaResponse, soeResponse);

			if(soeResponse != null && soeResponse.getErrors() == null){//CXTDT-217608
				if(soeResponse.getServiceBody() != null &&
						soeResponse.getServiceBody().getServiceResponse() != null &&
						soeResponse.getServiceBody().getServiceResponse().getContext() != null &&
						soeResponse.getServiceBody().getServiceResponse().getContext().getDeviceInfo() != null &&
						soeResponse.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getDeviceId() != null) {
					redisHelper2.updateDeviceId(soeResponse.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getDeviceId());
					logger.info("NSA BYOD updateDeviceId to Redis");
					if(soeResponse.getServiceBody().getServiceResponse().getContext().getCustomerInfo() != null &&
							StringUtils.isNotEmpty(soeResponse.getServiceBody().getServiceResponse().getContext().getCustomerInfo().getAccountNumber())) {
						soeResponse.getServiceBody().getServiceResponse().getContext().getCustomerInfo().setAccountNumber("");
					}
				}
			}

			return Mono.just(soeResponse);
		});
	}

	/**
	 * 
	 * @param uiRequest
	 * @return ActivateLaterUIResponse @
	 */
	public Mono<ActivateLaterUIResponse> activateOrSetupLater(ActivateLaterUIRequest uiRequest) {

		logger.debug("Inside CartServiceBpmHelper --> activateOrSetupLater");

		ActivateLaterPEGARequest pegaRequest = new ActivateLaterPEGARequest();

		// convert ui request to pega request
		pegaRequest = CartPegaRequestUtil6.formatActivateLaterRequest(pegaRequest, uiRequest);
		logger.debug("activateOrSetupLater PEGA Request: {}", pegaRequest);
		Mono<ActivateLaterPEGAResponse> responseServiceMono = null;

		try {
			// pega call
			responseServiceMono = services.activateOrSetupLater(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}

		ActivateLaterUIResponse soeResponse = new ActivateLaterUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {

			CartPegaResponseUtil1.formatActivateLaterResponse(soeResponse, pegaResponse);

			return Mono.just(soeResponse);
		});
	}

	/**
	 * 
	 * @param uiRequest
	 * @return ClearAndContinueUIResponse @
	 */
	public Mono<ClearAndContinueUIResponse> clearAndContinue(ClearAndContinueUIRequest uiRequest) {

		ClearAndContinuePegaRequest pegaRequest = new ClearAndContinuePegaRequest();

		CartPegaRequestUtil6.formatClearAndContinueRequest(pegaRequest, uiRequest);
		logger.debug("ClearAndContinue PEGA Request: {}", pegaRequest);
		Mono<ClearAndContinuePegaResponse> responseServiceMono = null;
		try {
			// pega call
			responseServiceMono = services.clearAndContinue(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		ClearAndContinueUIResponse soeResponse = new ClearAndContinueUIResponse();

		return responseServiceMono == null ? Mono.just(new ClearAndContinueUIResponse())
				: responseServiceMono.flatMap(pegaResponse -> {

					// convert pega response to ui response
					CartPegaResponseUtil1.formatClearAndContinueResponse(soeResponse, pegaResponse);
					return Mono.just(soeResponse);
				});
	}

	/**
	 *
	 * @param uiRequest
	 * @return ClearAndContinueUIResponse @
	 */
	public Mono<ClearAndContinueUIResponse> clearAndResume(ClearAndContinueUIRequest uiRequest) {

		ClearAndContinuePegaRequest pegaRequest = new ClearAndContinuePegaRequest();

		CartPegaRequestUtil6.formatClearandResumeRequest(pegaRequest, uiRequest);
		updateRequestForBYODPastDueFlag(pegaRequest, uiRequest);
		logger.debug("ClearAndResume PEGA Request: {}", pegaRequest);
		Mono<ClearAndContinuePegaResponse> responseServiceMono = null;
		try {
			// pega call
			responseServiceMono = services.clearAndContinue(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		ClearAndContinueUIResponse soeResponse = new ClearAndContinueUIResponse();

		return responseServiceMono == null ? Mono.just(new ClearAndContinueUIResponse())
				: responseServiceMono.flatMap(pegaResponse -> {

			// convert pega response to ui response
			CartPegaResponseUtil1.formatClearAndContinueResponse(soeResponse, pegaResponse);
			return Mono.just(soeResponse);
		});
	}

	private void updateRequestForBYODPastDueFlag(ClearAndContinuePegaRequest pegaRequest, ClearAndContinueUIRequest uiRequest) {
		if(isRequestForBYODPastDueFlag(uiRequest)
		&& checkNullForPegaRequest(pegaRequest)){
			pegaRequest.getServiceBody().getServiceRequest()
					.getContext().getCartInfo()
					.setPastDuePresent(uiRequest.getCartInfo().isPastDuePresent());
		}
	}

	private boolean checkNullForPegaRequest(ClearAndContinuePegaRequest pegaRequest) {
		if(pegaRequest != null
				&& pegaRequest.getServiceBody() != null
				&& pegaRequest.getServiceBody().getServiceRequest() != null
				&& pegaRequest.getServiceBody().getServiceRequest().getContext() != null
				&& pegaRequest.getServiceBody().getServiceRequest().getContext().getCartInfo() != null){
			return true;
		}
		return false;
	}

	private boolean isRequestForBYODPastDueFlag(ClearAndContinueUIRequest uiRequest) {
		if(uiRequest != null
				&& uiRequest.getCartInfo() != null
				&& CartConstants.BYOD.equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())
				&& featureFlagHelper.isPastDueBYODFFlag()){
			return true;
		}
		return false;
	}

	/**
	 *
	 * @param uiRequest
	 * @return ResumeAndContinueUIResponse
	 */
	public Mono<ResumeAndContinueUIResponse> resumeAndContinue(ResumeAndContinueUIRequest uiRequest) {

		ResumeAndContinuePegaRequest pegaRequest = new ResumeAndContinuePegaRequest();

		CartPegaRequestUtil6.formatResumeAndContinueRequest(pegaRequest, uiRequest);
		logger.debug("ResumeAndContinue PEGA Request: {}", pegaRequest);
		Mono<ResumeAndContinuePegaResponse> responseServiceMono = null;
		try {
			// pega call
			responseServiceMono = services.resumeAndContinue(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		ResumeAndContinueUIResponse soeResponse = new ResumeAndContinueUIResponse();

		return responseServiceMono == null ? Mono.just(new ResumeAndContinueUIResponse())
				: responseServiceMono.flatMap(pegaResponse -> {

					// convert pega response to ui response
					CartPegaResponseUtil.formatResumeAndContinueResponse(soeResponse, pegaResponse);
					return Mono.just(soeResponse);
				});
	}

	/**
	 *
	 * @param uiRequest
	 * @return UpdateDeviceSIMIdUIResponse
	 */
	public Mono<UpdateDeviceSIMIdUIResponse> updateDeviceSimId(UpdateDeviceSIMIdUIRequest uiRequest) {

		UpdateDeviceSIMIdPEGARequest pegaRequest = new UpdateDeviceSIMIdPEGARequest();

		// convert uiRequest to pegaRequest
		pegaRequest = CartPegaRequestUtil5.formatUpdateDeviceSimIdRequest(uiRequest, pegaRequest);

		logger.debug("UpdateDeviceSimId PEGA Request: {}", pegaRequest);

		Mono<UpdateDeviceSIMIdPEGAResponse> responseServiceMono = null;
		try {
			// pega call
			responseServiceMono = services.updateDeviceSimId(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}

		UpdateDeviceSIMIdUIResponse soeResponse = new UpdateDeviceSIMIdUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
			// convert pegaResponse to uiResponse
			CartPegaResponseUtil.formatUpdateDeviceSimIdResponse(pegaResponse, soeResponse);
			return Mono.just(soeResponse);
		});
	}

	/**
	 * 
	 * @param uiRequest
	 * @return resp @
	 */
	public Mono<UpdateTransferUpgradeUIResponse> addTransferUpgrade(UpdateTransferUpgradeUIRequest uiRequest) {
		logger.debug("Inside CartServiceBpmHelper --> addBuyout");
		UpdateTransferUpgradePEGARequest pegaRequest = new UpdateTransferUpgradePEGARequest();

		// convert ui request to pega request
		pegaRequest = CartPegaRequestUtil6.formatAddTransferUpgradeRequest(pegaRequest, uiRequest);

		logger.debug("addTransferUpgrade PEGA Request: {}", pegaRequest);
		Mono<UpdateTransferUpgradePEGAResponse> responseServiceMono = null;

		try {
			// pega call
			responseServiceMono = services.addTransferUpgrade(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		UpdateTransferUpgradeUIResponse soeResponse = new UpdateTransferUpgradeUIResponse();
		return responseServiceMono == null ? Mono.just(new UpdateTransferUpgradeUIResponse())
				: responseServiceMono.flatMap(pegaResponse -> {

					CartPegaResponseUtil1.formatUpdateTransferUpgradeResponse(soeResponse, pegaResponse);
					return Mono.just(soeResponse);
				});
	}

	/**
	 * 
	 * @param uiRequest
	 * @return resp @
	 */
	public Mono<UpdateTransferUpgradeUIResponse> removeTransferUpgrade(UpdateTransferUpgradeUIRequest uiRequest) {
		logger.debug("Inside CartServiceBpmHelper --> addBuyout");
		UpdateTransferUpgradePEGARequest pegaRequest = new UpdateTransferUpgradePEGARequest();

		// convert ui request to pega request
		pegaRequest = CartPegaRequestUtil6.formatRemoveTransferUpgradeRequest(pegaRequest, uiRequest);

		logger.debug("removeTransferUpgrade PEGA Request: {}", pegaRequest);
		Mono<UpdateTransferUpgradePEGAResponse> responseServiceMono = null;

		try {
			// pega call
			responseServiceMono = services.removeTransferUpgrade(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		UpdateTransferUpgradeUIResponse soeResponse = new UpdateTransferUpgradeUIResponse();
		return responseServiceMono == null ? Mono.just(new UpdateTransferUpgradeUIResponse())
				: responseServiceMono.flatMap(pegaResponse -> {

					CartPegaResponseUtil1.formatUpdateTransferUpgradeResponse(soeResponse, pegaResponse);
					return Mono.just(soeResponse);
				});
	}

	/**
	 * 
	 * @param uiRequest
	 * @return AddNickNameUIResponse @
	 */
	public Mono<AddNickNameUIResponse> addNickName(AddNickNameUIRequest uiRequest) {

		AddNickNamePEGARequest request = new AddNickNamePEGARequest();

		// convert uiRequest to pega request
		CartPegaRequestUtil6.formatAddNickNameRequest(request, uiRequest);
		logger.debug("AddNickName PEGA Request: {}", request);

		Mono<AddNickNamePEGAResponse> responseServiceMono = null;
		try {
			// pega call
			responseServiceMono = services.addNickName(request);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		AddNickNameUIResponse soeResponse = new AddNickNameUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
			// convert pega response to ui response
			CartPegaResponseUtil1.formatAddNickNameResponse(soeResponse, pegaResponse);
			return Mono.just(soeResponse);
		});
	}

	/**
	 * 
	 * @param uiRequest
	 * @return resp @
	 */
	public Mono<UpdateBvoOffersUIResponse> removeBvoOffers(UpdateBvoOffersUIRequest uiRequest) {
		logger.debug("Inside CartServiceBpmHelper --> removeBvoOffers");
		UpdateBvoOffersPEGARequest pegaRequest = new UpdateBvoOffersPEGARequest();

		// convert ui request to pega request
		pegaRequest = CartPegaRequestUtil7.formatRemoveBvoOffersRequest(pegaRequest, uiRequest);

		logger.debug("removeBvoOffers PEGA Request: {}", pegaRequest);
		Mono<UpdateBvoOffersPEGAResponse> responseServiceMono = null;

		try {
			// pega call
			responseServiceMono = services.removeOffer(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		UpdateBvoOffersUIResponse soeResponse = new UpdateBvoOffersUIResponse();
		return responseServiceMono == null ? Mono.just(new UpdateBvoOffersUIResponse())
				: responseServiceMono.flatMap(pegaResponse -> {

					CartPegaResponseUtil.formatRemoveBvoOffersResponse(soeResponse, pegaResponse);
					return Mono.just(soeResponse);
				});
	}
	
	/**
	 * 
	 * @param uiRequest
	 * @return resp @
	 */
	public Mono<UpdateSellerPriceUIResponseNew> updateSellerPrice(UpdateSellerPriceUIRequestNew uiRequest) {
	
		logger.debug("Inside CartServiceBpmHelper --> updateSellerPrice");
		UpdateSellerPricePEGARequest pegaRequest = new UpdateSellerPricePEGARequest();

		// convert ui request to pega request
		pegaRequest = CartPegaRequestUtil7.formatUpdateSellerPriceRequest(pegaRequest, uiRequest);

		logger.debug("updateSellerPrice PEGA Request: {}", pegaRequest);
		Mono<UpdateSellerPricePEGAResponse> responseServiceMono = null;

		try {
			// pega call
			responseServiceMono = services.updateSellerPrice(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		UpdateSellerPriceUIResponseNew soeResponse = new UpdateSellerPriceUIResponseNew();
		return responseServiceMono == null ? Mono.just(new UpdateSellerPriceUIResponseNew())
				: responseServiceMono.flatMap(pegaResponse -> {

					CartPegaResponseUtil.formatUpdateSellerPriceResponse(soeResponse, pegaResponse);
					return Mono.just(soeResponse);
				});
	}

	/**
	 * Email cart to customer.
	 *
	 * @param uiRequest the ui request
	 * @return the mono @ Signals that an I/O exception has occurred.
	 */
	public Mono<EmailCartToCustomerUIResponse> emailCartToCustomer(EmailCartToCustomerUIRequest uiRequest) {

		EmailCartToCustomerUIResponse soeResponse = EmailCartToCustomerUIResponse.builder()
				.meta(MetaResponse.builder().timestamp("2019-08-05T18:05:00Z")
						.cxpCorrelationId("8c5fa64a-9811-4eb8-85cd-b5939cae298b").build())
				.data(EmailCartToCustomerData.builder().cartId("bea202a6-42cb-40d4-ac87-d3f1db2b3f13").statusCode("1")
						.statusMsg(CartConstants.STATUS_SUCCESS).build())
				.build();
		return Mono.just(soeResponse);

	}

	/**
	 * 
	 * @param uiRequest
	 * @return UpdateBarcodeUIResponse @
	 */
	public Mono<UpdateBarcodeUIResponse> updateBarcode(UpdateBarcodeUIRequest uiRequest) {

		logger.debug("Inside CartServiceBpmHelper --> updateBarcode");
		UpdateBarCodePEGARequest request = new UpdateBarCodePEGARequest();

		// convert ui request to pega request
		CartPegaRequestUtil.formatUpdateBarCodeRequest(request, uiRequest, "");
		if(soeLoginSessionBean.isFWADigitalFlow()) {
			if (request.getServiceBody().getServiceRequest() != null && request.getServiceBody().getServiceRequest().getContext() != null && request.getServiceBody().getServiceRequest().getContext().getContextInfo() != null){
				if (uiRequest.getCartInfo() != null && uiRequest.getCartInfo().getIntendType() != null) {
					request.getServiceBody().getServiceRequest().getContext().getContextInfo().setIntent(uiRequest.getCartInfo().getIntendType());
				}
		}
		}
		logger.debug("updateBarcode PEGA Request: {}", request);
		Mono<UpdateBarCodePEGAResponse> responseServiceMono = null;

		try {
			// pega call
			responseServiceMono = services.updateBarcode(request);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		UpdateBarcodeUIResponse soeResponse = new UpdateBarcodeUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {

			// convert pega response to ui response
			CartPegaResponseUtil1.formatUpdateBarCodeResponse(soeResponse, pegaResponse);
			return Mono.just(soeResponse);
		});
	}

	/**
	 *
	 * @param standalone
	 * @param deviceImei
	 * @param accNumber
	 * @param cartCreator
	 * @return
	 */
	public Mono<DeviceIdValidationUIResponse> initiateRPSFlow(boolean standalone, String deviceImei, String accNumber,
			String cartCreator) {

		DeviceIdValidationPEGARequest request = new DeviceIdValidationPEGARequest();

		// convert uiRequest to pega request
		request = formatter.initiateRPSFlow(standalone, deviceImei, accNumber, cartCreator, request);
		logger.debug("DeviceIdValidation PEGA Request: {}", request);
		Mono<DeviceIdValidationPEGAResponse> responseServiceMono = null;
		try {
			// pega call
			responseServiceMono = services.validateDeviceId(request);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		DeviceIdValidationUIResponse soeResponse = new DeviceIdValidationUIResponse();

		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
			// convert pega response to ui response
			CartPegaResponseUtil1.formatDeviceIdValidationResponse(pegaResponse, soeResponse);
			return Mono.just(soeResponse);
		});
	}

	/**
	 *
	 * @param uiRequest
	 * @return UpdateChatIdUIResponse @
	 */
	public Mono<UpdateChatIdUIResponse> updateChatId(UpdateChatIdUIRequest uiRequest) {

		logger.debug("Inside CartServiceBpmHelper --> updateChatId");
		UpdateChatIdPEGARequest request = new UpdateChatIdPEGARequest();

		// convert ui request to pega request
		CartPegaRequestUtil6.formatUpdateChatIdRequest(request, uiRequest);

		logger.debug("updateChatId PEGA Request: {}", request);
		Mono<UpdateChatIdPEGAResponse> responseServiceMono = null;

		try {
			// pega call
			responseServiceMono = services.updateChatId(request);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		UpdateChatIdUIResponse soeResponse = new UpdateChatIdUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {

			// convert pega response to ui response
			CartPegaResponseUtil1.formatUpdateChatIdResponse(soeResponse, pegaResponse);
			return Mono.just(soeResponse);
		});
	}

	/**
	 * 
	 * @param caseRequest
	 * @return GetCaseResponse @
	 */
	public Mono<GetCaseResponse> getCases(GetCaseRequest caseRequest) {

		GetCasePEGARequest request = new GetCasePEGARequest();

		// convert uiRequest to pega request
		CartPegaRequestUtil6.formatGetCaseRequest(request, caseRequest);
		logger.debug("GetCases PEGA Request: {}", request);

		Mono<GetCasePEGAResponse> responseServiceMono = null;
		try {
			// pega call
			responseServiceMono = services.getCase(request);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		GetCaseResponse soeResponse = new GetCaseResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
			// convert pega response to ui response
			CartPegaResponseUtil1.formatGetCaseResponseResponse(soeResponse, pegaResponse);
			return Mono.just(soeResponse);
		});
	}

	/**
	 * 
	 * @param uiRequest
	 * @return soeResponse
	 */
	public Mono<SaveCartUIResponse> saveCartForLater(SaveCartForLaterUIRequest uiRequest) {
		SaveCartPEGARequest request = new SaveCartPEGARequest();

		// convert uiRequest to pega request
		CartPegaRequestUtil6.formatSaveCartForLaterRequest(request, uiRequest);
		logger.debug("SaveCartForLater PEGA Request: {}", request);
		Mono<SaveCartPEGAResponse> responseServiceMono = null;
		try {
			// pega call
			responseServiceMono = services.saveCart(request);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		SaveCartUIResponse soeResponse = new SaveCartUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
			// convert pega response to ui response
			CartPegaResponseUtil.formatSaveCartResponse(soeResponse, pegaResponse);
			return Mono.just(soeResponse);
		});

	}

	/**
	 * 
	 * @param request
	 * @return soeResponse
	 * 
	 */
	public Mono<ClearCartUIResponse> clearCart(ClearCartUIRequest request, Boolean isSmartPhone) {

		logger.debug("Inside CartServiceBpmHelper --> removeLines");
		ClearCartPEGARequest pegaRequest = new ClearCartPEGARequest();

		// convert ui request to pega request
		pegaRequest = CartPegaRequestUtil7.formatClearCartRequest(pegaRequest, request, isSmartPhone);
		logger.debug("RemoveLines PEGA Request: {}", request);
		Mono<ClearCartPEGAResponse> responseServiceMono = null;
		try {
			// pega call
			responseServiceMono = services.clearCart(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		ClearCartUIResponse soeResponse = new ClearCartUIResponse();
		return responseServiceMono == null ? Mono.just(new ClearCartUIResponse())
				: responseServiceMono.flatMap(pegaResponse -> {

					// convert pega response to ui response
					CartPegaResponseUtil1.formatClearCartResponse(soeResponse, pegaResponse);
					return Mono.just(soeResponse);
				});
	}

	/**
	 *
	 * @param request
	 * @return soeResponse
	 *
	 */
	public Mono<UpdateWFMInfoUIResponse> updateWFMInfo(UpdateWFMInfoUIRequest request) {

		logger.debug("Inside CartServiceBpmHelper --> updateWFMInfo");
		logger.info("Inside CartServiceBpmHelper --> updateWFMInfo");
		UpdateWFMInfoPEGARequest pegaRequest = new UpdateWFMInfoPEGARequest();

		// convert ui request to pega request
		pegaRequest = CartPegaRequestUtil7.formatUpdateWFMInfoRequest(pegaRequest, request);
		logger.debug("updateWFMInfo PEGA Request: {}", request);
		logger.info("updateWFMInfo PEGA Request: {}", request);
		Mono<UpdateWFMInfoPEGAResponse> responseServiceMono = null;
		try {
			// pega call
			responseServiceMono = services.updateWFMInfo(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		UpdateWFMInfoUIResponse soeResponse = new UpdateWFMInfoUIResponse();
		return responseServiceMono == null ? Mono.just(new UpdateWFMInfoUIResponse())
				: responseServiceMono.flatMap(pegaResponse -> {
					logger.info("updateWFMInfo convert pega response to ui response: {}", pegaResponse);
					// convert pega response to ui response
					CartPegaResponseUtil1.formatUpdateWFMInfoResponse(soeResponse, pegaResponse);
					return Mono.just(soeResponse);
				});
	}
	
	/**
	 *
	 * @param uiRequest
	 * @return AccountPinUIResponse @
	 */
	public Mono<AccountPinUIResponse> updateAccountPin(AccountPinUIRequest uiRequest) {

		logger.debug("Inside CartServiceBpmHelper --> updateAccountPin");

		AccountPinPEGARequest pegaRequest = new AccountPinPEGARequest();

		// convert ui request to pega request
		pegaRequest = CartPegaRequestUtil7.formatAccountPinRequest(pegaRequest, uiRequest);
		logger.debug("AccountPin PEGA Request: {}", pegaRequest);
		Mono<AccountPinPEGAResponse> responseServiceMono = null;

		try {
			// pega call
			responseServiceMono = services.updateAccountPin(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}

		AccountPinUIResponse soeResponse = new AccountPinUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {

			CartPegaResponseUtil1.formatAccountPinResponse(soeResponse, pegaResponse);

			return Mono.just(soeResponse);
		});
	}

	/**
	 * 
	 * @param uiRequest
	 * @return SalesOrderAdjustmentUIResponse
	 * 
	 */
	public Mono<SalesOrderAdjustmentUIResponse> salesOrderAdjustment(SalesOrderAdjustmentUIRequest uiRequest) {

		logger.debug("Inside CartServiceBpmHelper --> salesOrderAdjustment");
		SalesOrderAdjustmentPEGARequest request = new SalesOrderAdjustmentPEGARequest();

		// convert ui request to pega request
		CartPegaRequestUtil7.formatSalesOrderAdjustmentRequest(request, uiRequest);

		logger.debug("salesOrderAdjustment PEGA Request: {}", request);
		Mono<SalesOrderAdjustmentPEGAResponse> responseServiceMono = null;
		try {
			// pega call
			responseServiceMono = services.salesOrderAdjustment(request);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		SalesOrderAdjustmentUIResponse soeResponse = new SalesOrderAdjustmentUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {

			// convert pega response to ui response
			CartPegaResponseUtil1.formatSalesOrderAdjustmentResponse(soeResponse, pegaResponse);
			//fix-NSADT-119841
			if(uiRequest.getChannelId()!=null && (CartConstants.OMNI_INDIRECT.equalsIgnoreCase(uiRequest.getChannelId()) ||
					CartConstants.OMNI_INDIRECT_TAB.equalsIgnoreCase(uiRequest.getChannelId()))) {
				if (soeResponse != null && soeResponse.getServiceBody() != null && soeResponse.getServiceBody().getServiceResponse() != null
						&& soeResponse.getServiceBody().getServiceResponse().getContext() != null &&
						soeResponse.getServiceBody().getServiceResponse().getContext().getCartInfo() != null
						&& soeResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getRefundOrderDetails() != null
						&& soeResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getRefundOrderDetails().getLines() != null) {
					LineDetails lines = soeResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getRefundOrderDetails().getLines();
					String lineactivity = null;
					for (LineInfo lineInfo : lines.getLineInfo()) {
						if (lineInfo != null && StringUtilities.isNotEmptyOrNull(lineInfo.getLineActivityType())) {
							lineactivity = lineInfo.getLineActivityType();
						}
					}
					if (StringUtilities.isNotEmptyOrNull(lineactivity)) {
						Map<String, String> sessionData = new HashMap<String, String>();
						sessionData.put(CartConstants.INTENDTYPE, lineactivity);
						redisHelper2.upsertDataInRedis(sessionData);
						logger.info(String.format("updating intendType to redis %s",lineactivity));
					}
				}
			}
			return Mono.just(soeResponse);
		});
	}
	

	/**
	 * 
	 * @param request
	 * @return ReviewOrderTYSUIResponse
	 */
	public Mono<ReviewOrderTYSUIResponse> reviewOrderTys (ReviewOrderTYSUIRequest request) {
			Mono<ReviewOrderPegaResponse> responseServiceMono = null;
			ReviewOrderPegaRequest pegaRequest = new ReviewOrderPegaRequest();
			// convert ui request to pega request
			pegaRequest = CartPegaRequestUtil9.formatOrderReviewRequest(pegaRequest, request);
			logger.debug("Review Order TYS PEGA Request: {}", pegaRequest);
			try {
				// pega call
				responseServiceMono = services.reviewOrderTYS(pegaRequest);
			} catch (SOEHTTPException e) {
				logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
			}
			
			ReviewOrderTYSUIResponse soeResponse = new ReviewOrderTYSUIResponse();
			return responseServiceMono == null ? Mono.just(new ReviewOrderTYSUIResponse())
					: responseServiceMono.flatMap(pegaResponse -> {
				CartPegaResponseUtil.formatOrderReviewTYSResponse(soeResponse, pegaResponse);
				return Mono.just(soeResponse);
			});
	}

	public Mono<AddPlanAndDevicePEGAResponse> addMoversPlanAndDevice(AddPlanAndDevicePEGARequest addPlanAndDevicePEGARequest) {
		AddPlanAndDevicePEGAResponse soeResponse = new AddPlanAndDevicePEGAResponse();
		Mono<AddPlanAndDevicePEGAResponse> addPlanAndDevicePEGAResponseMono = null;
		try {
			addPlanAndDevicePEGAResponseMono = services.moversUpdateCart(addPlanAndDevicePEGARequest);
		} catch(SOEHTTPException exception){
			logger.error("Error at calling pega call : {}", exception.getMessage());
		}
		return addPlanAndDevicePEGAResponseMono == null ? Mono.just(soeResponse) : addPlanAndDevicePEGAResponseMono.flatMap(pegaResponse -> {
			return Mono.just(pegaResponse);
		}).onErrorResume(throwable -> {
			logger.info("Error while calling Pega for addPlanAndDevice : {}", throwable.getMessage());
			SOEHTTPException exception = (SOEHTTPException) throwable;
			List<Error> errors = new ArrayList<>();
			exception.getErrorHolder().getErrors().forEach(soeError -> {
				Error error = new Error();
				error.setMessage(soeError.getMessage());
				error.setId(soeError.getId());
				error.setNamespace(soeError.getNamespace());
				error.setName(soeError.getName());
				error.setDebug_id(soeError.getDebug_id());
				errors.add(error);
			});
			soeResponse.setErrors(errors);
			return Mono.just(soeResponse);
		});
	}
	
	/**
	 * 
	 * @param uiRequest
	 * @return
	 */
	public Mono<AffirmFinancingUIResponse> updateAffirmFinancingStatus(@Valid AffirmFinancingUIRequest uiRequest) {

		logger.debug("Inside CartServiceBpmHelper --> updateAffirmFinancingStatus");
		AffirmFinancingPegaRequest request = new AffirmFinancingPegaRequest();

		// convert ui request to pega request
		CartPegaRequestUtil9.formatAffirmPegaRequest(uiRequest, request);

		logger.debug("updateAffirmFinancingStatus PEGA Request: {}", request);
		Mono<AffirmFinancingPegaResponse> responseServiceMono = null;

		try {
			responseServiceMono = services.updateAffirmStatus(request);
		} catch (SOEHTTPException e) {
			logger.error("Inside CartServiceBpmHelper --> updateAffirmFinancingStatus :: ", e);
		}

		AffirmFinancingUIResponse soeResponse = new AffirmFinancingUIResponse();
		return responseServiceMono == null ? Mono.just(new AffirmFinancingUIResponse())
				: responseServiceMono.flatMap(pegaResponse -> {
					// convert pega response to ui response
					CartPegaResponseUtil.formatAffirmResponse(soeResponse, pegaResponse);
					return Mono.just(soeResponse);
				});
	}

	public Mono<AddReplenishmentToCartUIResponse> addReplenishmentToCart(AddReplenishmentToCartUIRequest uiRequest) {
		AddReplenishmentToCartPEGARequest request = new AddReplenishmentToCartPEGARequest();

		// convert uiRequest to pega request
		CartPegaRequestUtil9.formatAddReplenishmentRequest(uiRequest, request);
		logger.debug("Add Replenishment PEGA Request: {}", request);
		Mono<AddReplenishmentToCartPEGAResponse> responseServiceMono = null;
		try {
			// pega call
			responseServiceMono = services.addReplenishmenttoCart(request);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		AddReplenishmentToCartUIResponse soeResponse = new AddReplenishmentToCartUIResponse();
		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
			// convert pega response to ui response
			CartPegaResponseUtil.formatAddReplenishmentResponse(pegaResponse, soeResponse,uiRequest);			
			return Mono.just(soeResponse);
		});
	}
	
	public Mono<AddTruckRollCartUIResponse> addTruckRollCart(AddTruckRollCartUIRequest addTruckRollCartUIRequest, ServerHttpRequest httpHeaders) throws JsonProcessingException {
		mapper = new ObjectMapper();

		AddTruckRollCartRequest request = new AddTruckRollCartRequest();

		logger.info("Save5GAppointment UI Request After Session Call: {}", mapper.writeValueAsString(addTruckRollCartUIRequest));
		formatAddTruckRollCartBPMRequest(request, addTruckRollCartUIRequest, httpHeaders);
		logger.info("AddDevice PEGA Request: {}", mapper.writeValueAsString(request));
		Mono<AddTruckRollCartBPMResponse> responseServiceMono = null;
		try {
			// pega call
			responseServiceMono = services.addTruckRollCart(request);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		AddTruckRollCartUIResponse soeResponse = new AddTruckRollCartUIResponse();

		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
			// convert pega response to ui response
			CartPegaResponseUtil.formatAddTruckRollCartResponse(pegaResponse, soeResponse);
			return Mono.just(soeResponse);
		});
	}

	public AddTruckRollCartRequest formatAddTruckRollCartBPMRequest(AddTruckRollCartRequest pegaRequest,
																	AddTruckRollCartUIRequest request, ServerHttpRequest httpHeaders) {
		ServiceHeader serviceHeader = new ServiceHeader();
		serviceHeader = addTruckRollServiceHeader(serviceHeader, httpHeaders);

		pegaRequest.setServiceHeader(serviceHeader);

		AddTruckRollCartServiceBody serviceBody = new AddTruckRollCartServiceBody();
		AddTruckRollCartServiceRequest serviceRequest = new AddTruckRollCartServiceRequest();
		AddTruckRollCartContext context = new AddTruckRollCartContext();
		AddTruckRollCartInfo cartinfoData = new AddTruckRollCartInfo();
		AddTruckRollCartCustomerInfo customerInfo = new AddTruckRollCartCustomerInfo();

		ScheduleAppointmentRequest scheduleAppointmentRequest = request.getScheduleAppointmentRequest();
		setMtnDetails(CartConstants.DATA_CIRCUIT_ID,scheduleAppointmentRequest);
		setMtnDetails(CartConstants.DIGITAL_ORDER_TYPE,scheduleAppointmentRequest);


		AddTruckRollCartContextInfo contextInfo = new AddTruckRollCartContextInfo();
		contextInfo.setCallReason(CartConstants.TRUCK_ROLL_ORDER);
		contextInfo.setIntent(CartConstants.TR_INSTALL);
		contextInfo.setProcessStep(CartConstants.SCHEDULE_APPT);
		contextInfo.setProcessAction("AddDateTime");
		contextInfo.setFlowType("TRUCKROLL");
		context.setContextInfo(contextInfo);

		if(null != request.getScheduleAppointmentRequest() && StringUtilities.isNotEmptyOrNull(request.getScheduleAppointmentRequest().getCartLineMtn())) {
			customerInfo.setCartCreator(request.getScheduleAppointmentRequest().getCartLineMtn());
		}
		if(StringUtilities.isNotEmptyOrNull(request.getAccountNumber())) {
			customerInfo.setAccountNumber(request.getAccountNumber());
		}
		if(StringUtilities.isNotEmptyOrNull(request.getCustomerId())) {
			customerInfo.setCustomerId(request.getCustomerId());
		}
		context.setCustomerInfo(customerInfo);

		onevz.soe.wsclient.bpm.model.CartInfo cartInfo = new onevz.soe.wsclient.bpm.model.CartInfo();
		cartinfoData.setCartId(request.getScheduleAppointmentRequest().getCartId());
		cartinfoData.setItemType("SCHEDULE5GAPPT");
		cartinfoData.setChatId("");
		cartinfoData.setSubscriptionType("");
		cartinfoData.setIntendType("AAL_5G");
		cartinfoData.setAction("UPDATE");
		cartinfoData.setCustomerIpAddress("");
		cartinfoData.setScheduleAppointmentRequest(scheduleAppointmentRequest);

		context.setCartInfo(cartinfoData);
		if(StringUtilities.isNotEmptyOrNull(request.getCaseId())) {
			context.setCaseId(request.getCaseId());
		}
		serviceRequest.setContext(context);
		serviceBody.setServiceRequest(serviceRequest);
		pegaRequest.setServiceBody(serviceBody);

		return pegaRequest;
	}

	public ServiceHeader addTruckRollServiceHeader(ServiceHeader serviceHeader, ServerHttpRequest headers) {
		serviceHeader.setStatusMsg(CartConstants.BPM_PEGA_GENERATED_MESSAGE);
		if (StringUtilities.isNotEmptyOrNull(headers.getHeaders().getFirst(CartConstants.CHANNEL_ID))) {
			String clientId = headers.getHeaders().containsKey(CartConstants.CHANNEL_ID)
					? headers.getHeaders().getFirst(CartConstants.CHANNEL_ID)
					: "";
			serviceHeader.setClientId(clientId);
		}

		if(null != headers.getCookies()){
			String sessionId = null != headers.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION)
					? Objects.requireNonNull(headers.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION)).getValue()
					: "";
			serviceHeader.setSessionId(sessionId);
		}
		serviceHeader.setStatusMsg(CartConstants.BPM_PEGA_GENERATED_MESSAGE);

		serviceHeader.setServiceName(CartConstants.TRUCK_ROLL_ORDER);
		serviceHeader.setUserId("");
		serviceHeader.setStatusCode("0");


		return serviceHeader;
	}
	public Mono<AddTruckRollCartUIResponse> updateTruckRollCart(AddTruckRollCartUIRequest updateTruckRollCartUIRequest, ServerHttpRequest httpHeaders) throws JsonProcessingException {
		mapper = new ObjectMapper();

		AddTruckRollCartRequest bpmrequest = new AddTruckRollCartRequest();
		logger.info("Save5GAppointment UI Request After Session Call: {}", mapper.writeValueAsString(updateTruckRollCartUIRequest));
		formatUpdateTruckRollCartBPMRequest(bpmrequest, updateTruckRollCartUIRequest, httpHeaders);
		logger.info("AddDevice PEGA Request: {}", mapper.writeValueAsString(bpmrequest));
		Mono<AddTruckRollCartBPMResponse> responseServiceMono = null;
		try {
			// pega call
			responseServiceMono = services.updateTruckRollCart(bpmrequest);

		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		AddTruckRollCartUIResponse soeResponse = new AddTruckRollCartUIResponse();

		return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
			// convert pega response to ui response
			CartPegaResponseUtil.formatUpdateTruckRollCartResponse(pegaResponse, soeResponse);
			return Mono.just(soeResponse);
		});
	}

	public AddTruckRollCartRequest formatUpdateTruckRollCartBPMRequest(AddTruckRollCartRequest pegaRequest,
																	   AddTruckRollCartUIRequest updateTruckRollCartUIRequest, ServerHttpRequest httpHeaders) {

		ServiceHeader serviceHeader = new ServiceHeader();
		serviceHeader = updateTruckRollServiceHeader(serviceHeader, httpHeaders);

		pegaRequest.setServiceHeader(serviceHeader);

		AddTruckRollCartServiceBody serviceBody = new AddTruckRollCartServiceBody();
		AddTruckRollCartServiceRequest serviceRequest = new AddTruckRollCartServiceRequest();
		AddTruckRollCartContext context = new AddTruckRollCartContext();
		AddTruckRollCartInfo cartinfoData = new AddTruckRollCartInfo();
		AddTruckRollCartCustomerInfo customerInfo = new AddTruckRollCartCustomerInfo();

		ScheduleAppointmentRequest scheduleAppointmentRequest = new ScheduleAppointmentRequest();
		ApptInfo apptInfo = new ApptInfo();
		InstallApptSelectedDate installApptSelectedDate = new InstallApptSelectedDate();


		context.setCaseID(updateTruckRollCartUIRequest.getCaseId());
		AddTruckRollCartContextInfo contextInfo = new AddTruckRollCartContextInfo();
		contextInfo.setCallReason(CartConstants.TRUCK_ROLL_ORDER);
		contextInfo.setIntent("4G_TRUCKROLL");
		contextInfo.setProcessStep(CartConstants.SCHEDULE_APPT);
		contextInfo.setProcessAction("AddDateTime");
		contextInfo.setInstallationType("Repair");


		context.setContextInfo(contextInfo);


		if (null != updateTruckRollCartUIRequest.getScheduleAppointmentRequest() && StringUtilities.isNotEmptyOrNull(updateTruckRollCartUIRequest.getScheduleAppointmentRequest().getCartLineMtn())) {
			customerInfo.setCartCreator(updateTruckRollCartUIRequest.getScheduleAppointmentRequest().getCartLineMtn());
		}
		if (StringUtilities.isNotEmptyOrNull(updateTruckRollCartUIRequest.getAccountNumber())) {
			customerInfo.setAccountNumber(updateTruckRollCartUIRequest.getAccountNumber());
		}
		if (StringUtilities.isNotEmptyOrNull(updateTruckRollCartUIRequest.getCustomerId())) {
			customerInfo.setCustomerId(updateTruckRollCartUIRequest.getCustomerId());
		}
		customerInfo.setFlowType("TRUCKROLL_CANTENNA");
		context.setCustomerInfo(customerInfo);


		onevz.soe.wsclient.bpm.model.CartInfo cartInfo = new onevz.soe.wsclient.bpm.model.CartInfo();
		cartinfoData.setCartId(updateTruckRollCartUIRequest.getScheduleAppointmentRequest().getCartId());
		cartinfoData.setItemType("SCHEDULE5GAPPT");
		cartinfoData.setSubscriptionType("");
		cartinfoData.setIntendType("ACC");
		cartinfoData.setAction("UPDATE");
		cartinfoData.setScheduleAppointmentRequest(updateTruckRollCartUIRequest.getScheduleAppointmentRequest());

		context.setCartInfo(cartinfoData);
		if (StringUtilities.isNotEmptyOrNull(updateTruckRollCartUIRequest.getCaseId())) {
			context.setCaseId(updateTruckRollCartUIRequest.getCaseId());
		}
		serviceRequest.setContext(context);
		serviceBody.setServiceRequest(serviceRequest);
		pegaRequest.setServiceBody(serviceBody);

		return pegaRequest;
	}

	public ServiceHeader updateTruckRollServiceHeader(ServiceHeader serviceHeader, ServerHttpRequest headers) {
		if (StringUtilities.isNotEmptyOrNull(headers.getHeaders().getFirst(CartConstants.CHANNEL_ID))) {
			String clientId = headers.getHeaders().containsKey(CartConstants.CHANNEL_ID)
					? headers.getHeaders().getFirst(CartConstants.CHANNEL_ID)
					: "";
			serviceHeader.setClientId(clientId);
		}

		if (null != headers.getCookies()) {
			String sessionId = null != headers.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION)
					? Objects.requireNonNull(headers.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION)).getValue()
					: "";
			serviceHeader.setSessionId(sessionId);
		}
		serviceHeader.setStatusMsg(CartConstants.BPM_PEGA_GENERATED_MESSAGE);

		serviceHeader.setServiceName(CartConstants.TRUCK_ROLL_ORDER);
		serviceHeader.setUserId("");
		serviceHeader.setStatusCode("0");
		serviceHeader.setCorrelationId("soe-cart-2022.05.27.12.08.38-681.912867477481");


		return serviceHeader;
	}

	public Mono<ScheduleAppointmentRequest> setMtnDetails(String key,ScheduleAppointmentRequest scheduleAppointmentRequest){
		Mono<String> redisData=redisHelper3.getMtnData(key,scheduleAppointmentRequest.getCartLineMtn());
		redisData.subscribe(value->{
			if(CartConstants.DATA_CIRCUIT_ID.equalsIgnoreCase(key)){
				scheduleAppointmentRequest.setDataCircuitId(value);
			}
			else if(CartConstants.DIGITAL_ORDER_TYPE.equalsIgnoreCase(key)){
				scheduleAppointmentRequest.setDigitalOrderType(value);
			}
		});
		return Mono.just(scheduleAppointmentRequest);
	}

	/**
	 *
	 * @param request
	 * @return DeleteCartUIResponse
	 *
	 */
	public Mono<DeleteCartUIResponse> ngdDeleteCart(DeleteCartUIRequest request, Boolean isSmartPhone) {

		logger.info("Inside CartServiceBpmHelper --> delete");
		DeleteCartPegaRequest pegaRequest = new DeleteCartPegaRequest();
		pegaRequest = CartPegaRequestUtil7.ngdCreateDeleteCartPegaRequest(pegaRequest, request, isSmartPhone);
		logger.info("Delete Cart PEGA Request: {}", request);
		Mono<DeleteCartPegaResponse> responseServiceMono = null;
		try {
			responseServiceMono = services.ngdDeleteCart(pegaRequest);
		} catch (SOEHTTPException e) {
			logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
		}
		DeleteCartUIResponse soeResponse = new DeleteCartUIResponse();
		return responseServiceMono == null ? Mono.just(new DeleteCartUIResponse())
				: responseServiceMono.flatMap(pegaResponse -> {
			CartPegaResponseUtil1.formatNgdDeleteCartResponse(soeResponse, pegaResponse);
			return Mono.just(soeResponse);
		});
	}
}

