package onevz.soe.cart.util;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.constants.ConfiguratorConstants;
import onevz.soe.cart.model.addAccessory.AccessoryAction;
import onevz.soe.cart.model.addPromoIntent.AddPromoIntent;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.configurator.add.AddAllConfiguratorContext;
import onevz.soe.cart.model.configurator.add.AddAllConfiguratorServiceBody;
import onevz.soe.cart.model.configurator.add.AddAllConfiguratorServiceRequest;
import onevz.soe.cart.model.retrieveCart.TradeInItem;
import onevz.soe.cart.model.retrieveCart.Triage;
import onevz.soe.cart.model.retrieveCart.TriageInfo;
import onevz.soe.cart.requests.AddAllConfiguratorPEGARequest;
import onevz.soe.cart.ui.common.LineShippingOption;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.common.Shipping;
import onevz.soe.cart.ui.requests.AddAllConfiguratorUIRequest;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * The Class Cart configurator pega request util.
 */
public class CartConfiguratorPegaRequestUtil {
    private static final Logger logger = LoggerFactory.getLogger(CartConfiguratorPegaRequestUtil.class);

    private CartConfiguratorPegaRequestUtil() {

    }

    /**
     * Format add configurator request add all configurator pega request.
     *
     * @param pegaRequest                 the pega request
     * @param request                     the request
     * @param ngdTradeInBulkUpdateEnabled
     * @return the add all configurator pega request
     */
    public static AddAllConfiguratorPEGARequest formatAddConfiguratorRequest(AddAllConfiguratorPEGARequest pegaRequest, AddAllConfiguratorUIRequest request, Boolean ngdTradeInBulkUpdateEnabled) {
        //PEGA Service Header
        addServiceHeader(request, pegaRequest);

        //AddAllConfiguratorServiceRequest start
        AddAllConfiguratorServiceRequest serviceRequest = new AddAllConfiguratorServiceRequest();
        // AddAllConfiguratorServiceRequest end

        // AddAllConfiguratorContext start
        AddAllConfiguratorContext context = new AddAllConfiguratorContext();
        CartServiceCustomerInfo customerInfo = getCustomerInfo(request);
        CartServiceContextInfo contextInfo = addContextInfo(request);
        CartServiceConfiguratorCartInfo cartInfo = getCartServiceConfiguratorCartInfo(request, ngdTradeInBulkUpdateEnabled);
        context.setCartInfo(cartInfo);
        context.setCaseId(Optional.ofNullable(request.getCartInfo().getCaseId()).orElse(CartConstants.EMPTY_STRING));
        context.setContextInfo(contextInfo);
        context.setCustomerInfo(customerInfo);
        // AddAllConfiguratorContext end

        // AddAllConfiguratorServiceBody start
        serviceRequest.setContext(context);
        AddAllConfiguratorServiceBody serviceBody = new AddAllConfiguratorServiceBody();
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);
        // AddAllConfiguratorServiceBody end
        return pegaRequest;
    }

    /**
     * Add service header.
     *
     * @param request     the request
     * @param pegaRequest the pega request
     */
    public static void addServiceHeader(AddAllConfiguratorUIRequest request, AddAllConfiguratorPEGARequest pegaRequest) {
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        serviceHeader.setSessionId(CartConstants.EMPTY_STRING);
        serviceHeader.setStatusMsg(CartConstants.BPM_PEGA_GENERATED_MESSAGE);
        serviceHeader.setServiceName(CartConstants.SALES_ORDER_PURCHASE);
        serviceHeader.setCorrelationId(getCorrelationId());
        serviceHeader.setUserId(CartConstants.EMPTY_STRING);
        serviceHeader.setStatusCode(ConfiguratorConstants.STRING_ZERO);

        serviceHeader.setClientId(request.getChannelId());
        pegaRequest.setServiceHeader(serviceHeader);
    }

    private static String getCorrelationId() {
        return String.format("soe-cart-%s-%s", LocalDateTime.now().format(DateTimeFormatter.ofPattern(ConfiguratorConstants.DATE_FORMAT_YYYY_MM_DD_HH_MM_SS)), generateRandomNumberString());
    }

    private static String generateRandomNumberString() {
        SecureRandom random = new SecureRandom();
        byte[] bytes = new byte[20];
        random.nextBytes(bytes);
        return String.valueOf(1000 * random.nextDouble());
    }

    /**
     * Gets cart service configurator cart info.
     *
     * @param request                     the request
     * @param ngdTradeInBulkUpdateEnabled
     * @return the cart service configurator cart info
     */
    public static CartServiceConfiguratorCartInfo getCartServiceConfiguratorCartInfo(AddAllConfiguratorUIRequest request, Boolean ngdTradeInBulkUpdateEnabled) {
        CartServiceConfiguratorCartInfo cartInfo = new CartServiceConfiguratorCartInfo();

        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getZipCode())) {
            cartInfo.setZipCode(request.getCartInfo().getZipCode());
        }
        List<Line> lines = new ArrayList<>();

        for (Lines reqLine : request.getData().getLines()) {
            Line newLine = new Line();
            if (reqLine.getDepletionLocationCode() != null)
                newLine.setDepletionLocationCode(CartUtil.removeSpecialCharacters(reqLine.getDepletionLocationCode(), request.getChannelId()));
            newLine.setDepletionType(Optional.ofNullable(reqLine.getDepletionType()).orElse(CartConstants.EMPTY_STRING));
            populateAccessoryDetails(reqLine, newLine);
            populatePlanDetails(reqLine, newLine);
            logger.info("ngdTradeInBulkUpdateEnabled : {}", ngdTradeInBulkUpdateEnabled);
            if (ngdTradeInBulkUpdateEnabled) {
                cartInfo.setTradeInShippingType(Optional.ofNullable(reqLine.getTradeInShippingType()).orElse(CartConstants.EMPTY_STRING));
                populateTradeInDetails(reqLine, newLine);
            }
            newLine.setMtn(Optional.ofNullable(reqLine.getMtn()).orElse(CartConstants.EMPTY_STRING));
            newLine.setEstimatedReadyByDate(Optional.ofNullable(reqLine.getEstimatedReadyByDate()).orElse(CartConstants.EMPTY_STRING));
            newLine.setEupNoPromoFlow(false);
            newLine.setIsCommonPDP(false);
            newLine.setIsKeepingExistingEqProtection(Optional.ofNullable(reqLine.getIsKeepingExistingEqProtection()).orElse(false));
            newLine.setNewLineOrAAL(Optional.ofNullable(reqLine.getNewLineOrAAL()).orElse(false));
            newLine.setIspuFlow(Optional.ofNullable(reqLine.getIspuFlow()).orElse(false));
            if (!newLine.getIspuFlow()) {
                Optional<LineShippingOption> lineShipmentInfo = Optional.ofNullable(reqLine.getShipmentInfo());
                if (lineShipmentInfo.isPresent()) {
                    populateShipmentInfo(newLine, lineShipmentInfo.get());
                }
            }
            if (StringUtilities.isNotEmptyOrNull(reqLine.getBuyDeviceLineMtn()))
                newLine.setBuyDeviceLineMtn(reqLine.getBuyDeviceLineMtn());
            if (StringUtilities.isNotEmptyOrNull(reqLine.getPortInNumber())) {
                newLine.setPortInNumber(reqLine.getPortInNumber());
            }
            // Promo Intercept
            if (reqLine.getSim() != null) {
                newLine.setSim(reqLine.getSim());
            }
            newLine.setPromoRejectionIndicator(Optional.ofNullable(reqLine.getPromoRejectionIndicator()).orElse(false));
            newLine.setSelectedPromoType(Optional.ofNullable(reqLine.getSelectedPromoType()).orElse(CartConstants.EMPTY_STRING));
            newLine.setPurchasePath(CartConstants.NSE);
            newLine.setSelectedPromoId(Optional.ofNullable(reqLine.getSelectedPromoId()).orElse(CartConstants.EMPTY_STRING));
            newLine.setBuyDevSorId(Optional.ofNullable(reqLine.getBuyDevSorId()).orElse(CartConstants.EMPTY_STRING));
            newLine.setSelectedSedOfferId(Optional.ofNullable(reqLine.getSelectedSedOfferId()).orElse(CartConstants.EMPTY_STRING));
            if (CollectionUtilities.isNotEmptyOrNull(reqLine.getSelectedOffers()) && request.getChannelId() != null) {
                newLine.setSelectedOffers(reqLine.getSelectedOffers());
            }
            if (CollectionUtilities.isNotEmptyOrNull(reqLine.getPromoIntent())) {
                newLine.setPromoIntent((reqLine.getPromoIntent()).toArray(AddPromoIntent[]::new));
            }
            populateDeviceDetails(reqLine, newLine);

            populateFeatureDetails(reqLine, newLine, cartInfo);
            newLine.setSddZipCode(Optional.ofNullable(reqLine.getSddZipCode()).orElse(CartConstants.EMPTY_STRING));
            newLine.setIsShipToHome(Boolean.FALSE);

            lines.add(newLine);
        }
        Line[] lineArr = new Line[lines.size()];
        lines.toArray(lineArr);
        cartInfo.setLines(lineArr);

        cartInfo.setCartId(Optional.ofNullable(request.getCartInfo().getCartId()).orElse(CartConstants.EMPTY_STRING));
        cartInfo.setCartCreator(request.getCartInfo().getCartCreator());
        cartInfo.setClientAppName(request.getCartInfo().getClientAppName());
        cartInfo.setAction(CartConstants.UPDATE);
        cartInfo.setItemType(ConfiguratorConstants.CONFIGURATOR_ITEM_TYPE);
        cartInfo.setIntendType(CartConstants.NSE);
        cartInfo.setNgdFlow(true);

        return cartInfo;
    }

    /**
     * Populate trade in details.
     *
     * @param reqLine the line in request
     * @param newLine respone line
     * @return the add all configurator pega request
     */
    private static void populateTradeInDetails(Lines reqLine, Line newLine) {

        if (reqLine.getIsTradeInIntentSelected() != null && reqLine.getIsTradeInIntentSelected()) {
            newLine.setIsTradeInIntentSelected(Optional.ofNullable(reqLine.getIsTradeInIntentSelected()).orElse(false));

            List<TradeInItem> tradeInItemList = new ArrayList<>();
            TradeInItem tradeInItem = new TradeInItem();
            tradeInItem.setLineSeqNum("1");
            tradeInItem.setRecycleSeqNum("1");
            tradeInItem.setTradeDeviceMDN(Optional.ofNullable(reqLine.getMtn()).orElse(CartConstants.EMPTY_STRING));
            tradeInItem.setItemId(Optional.ofNullable(reqLine.getModelId()).orElse(CartConstants.EMPTY_STRING));
            tradeInItem.setDeviceId(Optional.ofNullable(reqLine.getTradeDeviceId()).orElse(CartConstants.EMPTY_STRING));
            tradeInItem.setRecycleDeviceSku(Optional.ofNullable(reqLine.getTradeRecycleDeviceSku()).orElse(CartConstants.EMPTY_STRING));
            tradeInItem.setEquipCarrier(Optional.ofNullable(reqLine.getEquipCarrier()).orElse(ConfiguratorConstants.OTHER_EQUIP_CARRIER));
            //Setting triage info with questons and answers based on battery damaged or not
            tradeInItem.setTriageInfo(getTriageInfo(reqLine, tradeInItem));
            tradeInItemList.add(tradeInItem);
            newLine.setTradeInItems(tradeInItemList);
        }
        if(reqLine.getIsRemoveTradeIn() != null && reqLine.getIsRemoveTradeIn()) {
            newLine.setIsRemoveTradeIn(reqLine.getIsRemoveTradeIn());
            TradeInItem tradeInItem = new TradeInItem();
            List<TradeInItem> tradeInItemList = new ArrayList<>();
            tradeInItem.setDeviceId(Optional.ofNullable(reqLine.getTradeDeviceId()).orElse(CartConstants.EMPTY_STRING));
            tradeInItemList.add(tradeInItem);
            newLine.setTradeInItems(tradeInItemList);
            newLine.setIsTradeInIntentSelected(false);
        }
    }

    private static TriageInfo getTriageInfo(Lines reqLine, TradeInItem tradeInItem) {
        TriageInfo triageInfo = new TriageInfo();
        triageInfo.setTriageCount("4");

        Triage triage0 = new Triage();
        triage0.setTriageAnswer(CartConstants.TRIAGE_ANSWER);
        triage0.setTriageQuestionId(CartConstants.TRIAGE_QUES_IND_1);
        triage0.setQuestionText(CartConstants.QUESTION_TEXT_1);

        Triage triage1 = new Triage();
        triage1.setTriageAnswer(CartConstants.TRIAGE_ANSWER);
        triage1.setTriageQuestionId(CartConstants.TRIAGE_QUES_IND_2);
        triage1.setQuestionText(CartConstants.QUESTION_TEXT_2);

        Triage triage2 = new Triage();
        triage2.setTriageAnswer(CartConstants.TRIAGE_ANSWER);
        triage2.setTriageQuestionId(CartConstants.TRIAGE_QUES_IND_5);
        triage2.setQuestionText(CartConstants.QUESTION_TEXT_5);
        if (reqLine.getIsBatteryDamaged() != null && reqLine.getIsBatteryDamaged()) {
            tradeInItem.setDeviceCondition(CartConstants.DEVICE_CONDITION_BAD);
            triage2.setTriageAnswer(CartConstants.TRIAGE_ANSWER_NO);
        } else {
            tradeInItem.setDeviceCondition(CartConstants.DEVICE_CONDITION);
        }
        Triage triage3 = new Triage();
        triage3.setTriageAnswer(CartConstants.TRIAGE_ANSWER);
        triage3.setTriageQuestionId(CartConstants.TRIAGE_QUES_IND_7);
        triage3.setQuestionText(CartConstants.QUESTION_TEXT_7);

        Triage[] triages = new Triage[4];
        triages[0] = triage0;
        triages[1] = triage1;
        triages[2] = triage2;
        triages[3] = triage3;
        triageInfo.setTriage(triages);
        return triageInfo;
    }

    private static void populateShipmentInfo(Line newLine, LineShippingOption lineShippingOption) {
        if (lineShippingOption.getShipping() != null) {
            Shipping shpOptionReq = lineShippingOption.getShipping();
            CartServiceConfiguratorShipmentInfo info = new CartServiceConfiguratorShipmentInfo();
            CartServiceConfiguratorShippingOption shpOption = new CartServiceConfiguratorShippingOption();
            info.setMultiLineSeqNumber(lineShippingOption.getMultiLineSeqNumber());
            shpOption.setDeliveryDate(shpOptionReq.getDeliveryDate());
            shpOption.setShippingCode(shpOptionReq.getShippingCode());
            shpOption.setShippingDescription(shpOptionReq.getShippingDescription());
            shpOption.setShippingCost(shpOptionReq.getShippingCost());
            info.setShipping(shpOption);
            newLine.setShipmentInfo(info);
        }
    }

    private static void populateFeatureDetails(Lines reqLine, Line newLine, CartServiceConfiguratorCartInfo cartInfo) {

        FeatureAction action = new FeatureAction();
        /*adding feature details start*/
        if (reqLine.getAddFeatures() != null && !reqLine.getAddFeatures().isEmpty()) {
            action.setAdd(reqLine.getAddFeatures());
        }
        /*adding feature details end*/
        /*removing feature details start*/
        if (reqLine.getRemoveFeatures() != null && !reqLine.getRemoveFeatures().isEmpty()) {
            action.setRemove(reqLine.getRemoveFeatures());
        }
        /*removing feature details end*/
        newLine.setFeatures(action);
        cartInfo.setTriggerPricingValidation(true);
    }

    private static void populateDeviceDetails(Lines reqLine, Line newLine) {
        /*adding device start*/
        if (reqLine.getDevice() != null) {
            newLine.setDevice(reqLine.getDevice());
            newLine.getDevice().setQty(reqLine.getDevice().getQty());
        }
        /*adding device end*/
    }

    private static void populatePlanDetails(Lines reqLine, Line newLine) {
        /*adding plan start*/
        if (reqLine.getPlan() != null) {
            newLine.setPlan(reqLine.getPlan());
        }
        /*adding plan end*/
    }

    private static void populateAccessoryDetails(Lines reqLine, Line newLine) {
        Accessory[] reqLineAddAccessories = reqLine.getAddAccessories();
        Accessory[] reqLineRemoveAccessories = reqLine.getRemoveAccessories();
        AccessoryAction accessoryAction = new AccessoryAction();
        newLine.setAccessories(accessoryAction);
        /*adding accessories start*/
        if (reqLineAddAccessories != null && reqLineAddAccessories.length > 0) {
            accessoryAction.setAdd(reqLineAddAccessories);
            newLine.getAccessories().setAdd(reqLine.getAddAccessories());

        }
        /*adding accessories end*/
        /*removing accessories start*/
        if (reqLineRemoveAccessories != null && reqLineRemoveAccessories.length > 0) {
            accessoryAction.setRemove(reqLineRemoveAccessories);
        }
        /*removing accessories end*/
    }

    /**
     * Gets customer info.
     *
     * @param request the request
     * @return the customer info
     */
    public static CartServiceCustomerInfo getCustomerInfo(AddAllConfiguratorUIRequest request) {
        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setMtnFlow(Optional.ofNullable(request.getCartInfo().getMtnFlow()).orElse(CartConstants.EMPTY_STRING));
        customerInfo.setIsTradeInSelected(false);
        Lines reqInitialLine = request.getData().getLines().stream().findFirst().orElse(null);
        if (reqInitialLine != null && reqInitialLine.getDevice() != null) {
            customerInfo.setProductId(Optional.ofNullable(reqInitialLine.getDevice().getProductId()).orElse(CartConstants.EMPTY_STRING));
            customerInfo.setCategoryName(Optional.ofNullable(reqInitialLine.getDevice().getCategory()).orElse(CartConstants.EMPTY_STRING));
        }
        customerInfo.setIsPromoPDP(Optional.ofNullable(request.getCartInfo().getIsPromoPDP()).orElse(false));
        customerInfo.setNoPendingOfferExists(Optional.ofNullable(request.getCartInfo().getNoPendingOfferExists()).orElse(false));
        customerInfo.setCustomerType(CartConstants.N);
        customerInfo.setBucketAllocator(ConfiguratorConstants.BAU);
        customerInfo.setAccountNumber(CartConstants.EMPTY_STRING);
        customerInfo.setEditDevice(Optional.ofNullable(request.getCartInfo().getEditDevice()).orElse(false));
        customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
        customerInfo.setGlobalId(request.getCartInfo().getCartCreator());
        customerInfo.setDeviceType(request.getCartInfo().getDeviceType());
        customerInfo.setProcessingMTN(Optional.ofNullable(request.getCartInfo().getProcessingMTN()).orElse(CartConstants.EMPTY_STRING));
        customerInfo.setAmRole(request.getCartInfo().getAmRole());
        customerInfo.setMyvPage(request.getCartInfo().isMyvPage());
        customerInfo.setFlowType(request.getCartInfo().getFlowType());
        return customerInfo;
    }

    /**
     * Add context info cart service context info.
     *
     * @param request the request
     * @return the cart service context info
     */
    public static CartServiceContextInfo addContextInfo(AddAllConfiguratorUIRequest request) {
        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        contextInfo.setCallReason(CartConstants.SALES_ORDER_PURCHASE);
        contextInfo.setItemType(ConfiguratorConstants.CONFIGURATOR_ITEM_TYPE);
        contextInfo.setIntent(CartConstants.NSE);
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessStep()))
            contextInfo.setProcessStep(request.getCartInfo().getProcessStep());
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessAction()))
            contextInfo.setProcessAction(request.getCartInfo().getProcessAction());
        return contextInfo;
    }

}
