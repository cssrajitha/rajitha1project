package onevz.soe.cart.constants;

import onevz.soe.session.constants.SessionConstants;

import java.util.ArrayList;
import java.util.Arrays;

public class RedisConstants {

	public static final String HOME_SALES_ADDRESS = "homeSalesAddress";
	public static final String FLOW_TYPE = "flowType";
	public static final String IS_WFM_FLOW = "isWFMFlow";
	public static final String AI_QUOTE_FLAG = "aiQuoteFlag";

	public static final String HOME_SALES_ADDRESS_LIST = "homeSalesAddressList";
	public static final ArrayList<String> SESSION_GET_ADDR = new ArrayList<String>(Arrays.asList(
			CartConstants.QUOTE_E911_ADDR
			));

}
