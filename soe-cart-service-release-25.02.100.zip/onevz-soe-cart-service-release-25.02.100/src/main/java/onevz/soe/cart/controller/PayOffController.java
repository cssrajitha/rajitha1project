package onevz.soe.cart.controller;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.cxp.helper.PayOffDetailsHelper;
import onevz.soe.cart.exceptions.JsonValidator;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.ui.requests.AddPayOffDetailsUIRequest;
import onevz.soe.cart.util.CartPegaRequestErrorsUtil;
import onevz.soe.utilities.CollectionUtilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import jakarta.validation.Valid;

@RestController
@RequestMapping(value = "cart")
public class PayOffController {
    private static final Logger logger = LoggerFactory.getLogger(PayOffController.class);

    @Autowired
    private PayOffDetailsHelper payOffDetailsHelper;

    @Autowired
    JsonValidator validator;

    @PostMapping("/addPayOffDetails")
    public Mono<ResponseEntity<GenericResponse>> addPayOffDetails(ServerHttpRequest httpRequest,
                                                                  ServerHttpResponse httpResponse, @Valid @RequestBody AddPayOffDetailsUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "addPayOffDetails");
        logger.debug("addPayOffDetails: {}", request);
        ErrorResponse errorResponse = CartPegaRequestErrorsUtil.handleAddPayOffDetailsRequestErrors(request);

        if (CollectionUtilities.isNotEmptyOrNull(errorResponse.getErrors())) {
            ErrorResponse errors = validator.convertObjectToString(errorResponse);
            if (null != errors) {
                return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
            }
        }

        return payOffDetailsHelper.getAddPayOffDetails(httpRequest.getHeaders(), request).flatMap(uiRes-> {
            return Mono.just(ResponseEntity.status(HttpStatus.OK).body(uiRes));
        });
    }

}
