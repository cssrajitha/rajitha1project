package onevz.soe.cart.handler;


import com.nimbusds.oauth2.sdk.util.StringUtils;
import lombok.extern.slf4j.Slf4j;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.helper.RedisHelper2;
import onevz.soe.cart.helper.UpdateCartHelper;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.ui.common.CartInfo;
import onevz.soe.cart.ui.requests.AddDeviceUIRequest;
import onevz.soe.cart.ui.requests.ClearCartUIRequest;
import onevz.soe.cart.ui.responses.ClearCartUIResponse;
import onevz.soe.cart.util.CartUtil;
import onevz.soe.spring.web.filter.RequestAccessContext;
import onevz.soe.utilities.StringUtilities;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseCookie;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.List;

@Service
@Slf4j
public class PreHandleAddDevice {

    @Autowired
    private UpdateCartHelper helper;

    @Autowired
    private RedisHelper redisHelper;

    @Autowired
    private RedisHelper2 redisHelper2;

    @Value("${onevz.soe.cartservice.restrictMultiLine:false}")
    private boolean restrictMultiLine;

    public Mono<Boolean> execute(AddDeviceUIRequest request, CartRedisData data) {
        if (request != null && request.getCartInfo() != null && request.getCartInfo().isRestrictMultiLinePreToPost() && !request.getCartInfo().getEditDevice()) {
            String preToPostPayMigration = RequestAccessContext.obtainCookie(List.of(CartConstants.PREPAID_TO_POSTPAID_MIGRATION));
            String prospectCartCount = RequestAccessContext.obtainCookie(List.of(CartConstants.PROSPECT_CART_COUNT));
            //Call clear cart here
            if (isPrepayToPostpayMigrationFlow(preToPostPayMigration, data.getCartId(), prospectCartCount))
                return clearCart(request).onErrorReturn(Boolean.FALSE);
        }
        return Mono.just(Boolean.TRUE);
    }

    private Mono<Boolean> clearCart(AddDeviceUIRequest request) {
        ClearCartUIRequest clearCartUIRequest = new ClearCartUIRequest();
        clearCartUIRequest.setCartInfo(new CartInfo());
        clearCartUIRequest.setChannelId(request.getChannelId());
        clearCartUIRequest.getCartInfo().setExpressCheckout(false);
        clearCartUIRequest.getCartInfo().setProcessStep(CartConstants.GRIDWALLPDP);
        clearCartUIRequest.getCartInfo().setSessionId(request.getCartInfo().getSessionId());
        clearCartUIRequest.getCartInfo().setIntendType(CartConstants.NSE);
        return helper.clearCart(clearCartUIRequest).flatMap(pegaResponse -> {
            return updateRadisData(request, pegaResponse);
        }).onErrorResume(e -> Mono.just(false));
    }

    private Mono<Boolean> updateRadisData(AddDeviceUIRequest request, ClearCartUIResponse pegaResponse) {
        if (pegaResponse.getErrors() == null) {
            if (pegaResponse != null && pegaResponse.getServiceBody() != null
                    && CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))
                    && pegaResponse.getServiceBody().getServiceResponse() != null
                    && pegaResponse.getServiceBody().getServiceResponse().getContext() != null
                    && pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo() != null) {
                /*Add item count into cookie*/
                request.getHttpResponse().addCookie(ResponseCookie.from(CartConstants.PROSPECT_CART_COUNT,
                                String.valueOf(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartItemCount()))
                        .path("/").httpOnly(false).build());
                pegaResponse.setCartCount(String.valueOf(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartItemCount()));
            }

            Mono<Long> redisData = redisHelper.deleteAddDeviceDataFromRedis(CartConstants.ADD_DEVICE_REQUEST);
            return redisData.flatMap(removedata -> {
                if (StringUtilities.isNotEmptyOrNull(pegaResponse.getCartCount())) {
                    Mono<Boolean> updatedCount = redisHelper2.updateDeviceCartCount(pegaResponse.getCartCount(), Boolean.TRUE);
                    return updatedCount.flatMap(updateddata -> {
                        return Mono.just(true);
                    });
                }
                return Mono.just(true);
            });
        }
        return Mono.just(true);
    }

    private boolean isPrepayToPostpayMigrationFlow(String preToPostPayMigration, String cartId, String prospectCartCount) {
        if (StringUtilities.isNotEmptyOrNull(preToPostPayMigration) && StringUtilities.isNotEmptyOrNull(prospectCartCount)) {
            Integer prospectCartCnt = Integer.parseInt(StringUtils.isNumeric(prospectCartCount) ? prospectCartCount : CartConstants.PROSPECT_COUNT_VAL);
            return Boolean.parseBoolean(preToPostPayMigration) && cartId != null && prospectCartCnt > 0;
        }
        return false;
    }

}
