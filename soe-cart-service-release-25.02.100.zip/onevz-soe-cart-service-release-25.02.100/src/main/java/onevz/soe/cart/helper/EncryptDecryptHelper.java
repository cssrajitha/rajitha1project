package onevz.soe.cart.helper;


import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.common.FiveG.FiveGLTEAddressRedis;
import onevz.soe.cart.model.common.FiveG.MoversRedisData;
import onevz.soe.cart.model.common.UnifiedNBSData;
import onevz.soe.cart.util.CartUtil;
import onevz.soe.utilities.serialization.JacksonMapperFactory;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpCookie;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.ByteBuffer;
import java.security.AlgorithmParameters;
import java.util.Optional;
import java.util.function.Predicate;

@Component
public class EncryptDecryptHelper {
    private static final Logger LOGGER = LoggerFactory.getLogger(EncryptDecryptHelper.class);
    @Autowired
    Environment env;
    public String getUnifiedNbsData(String igSession, FiveGLTEAddressRedis redisData) {
        UnifiedNBSData unifiedNbsData = new UnifiedNBSData();
        Optional.ofNullable(redisData.getCartId()).filter(Predicate.not(String::isBlank)).ifPresent(unifiedNbsData::setCartId);
        return unifiedNBSencryptCall(igSession, unifiedNbsData);
    }

    public String unifiedNBSencryptCall(String igSession, UnifiedNBSData unifiedNbsData ) {
        try {
            String encryptedNbsData = "";
            String sessionData = JacksonMapperFactory.defaultWriter().writeValueAsString(unifiedNbsData);
            Long startTime = System.currentTimeMillis();
            LOGGER.info("SessionData to be encrypted :{}", sessionData);
            if (StringUtils.isNotBlank(sessionData) && StringUtils.isNotBlank(igSession)) {
                encryptedNbsData = encryptWithAES(sessionData, igSession);
                LOGGER.info("TimeTaken for encrypting unifiednbs data :{}ms", (System.currentTimeMillis() - startTime));
                LOGGER.info("SessionData after encryption :{}", encryptedNbsData);
            }
            return encryptedNbsData;
        } catch (Exception e) {
            LOGGER.error("Error occurred in fetching unifiednbsData : {}", e.getMessage());
            return "";
        }
    }

    public String getUnifiedNbsMoversData(String igSession, MoversRedisData redisData) {
        UnifiedNBSData unifiedNbsData = new UnifiedNBSData();
        Optional.ofNullable(redisData.getCartId()).filter(Predicate.not(String::isBlank)).ifPresent(unifiedNbsData::setCartId);
        return unifiedNBSencryptCall(igSession, unifiedNbsData);
    }


    public String encryptWithAES(String textToEncrypt, String sessionId) throws Exception {
        String result = null;
        int pswdIterations = Integer.parseInt(env.getProperty("encrypt.pswdIterations"));
        int keySize = Integer.parseInt(env.getProperty("encrypt.keySize"));
        String salt = env.getProperty("encrypt.key", "");
        byte[] saltBytes = salt.getBytes("UTF-8");
        /* Derive the key, given password and salt. */
        SecretKeyFactory factory = SecretKeyFactory.getInstance(env.getProperty("encrypt.secretKeyFactory.aes"));
        PBEKeySpec spec = new PBEKeySpec(sessionId.toCharArray(), saltBytes, pswdIterations, keySize);
        SecretKey secretKey = factory.generateSecret(spec);
        SecretKeySpec secret = new SecretKeySpec(secretKey.getEncoded(), env.getProperty("encrypt.aesAlgo"));
        // encrypt the message
        Cipher cipher = Cipher.getInstance(env.getProperty("encrypt.cipher"));
        cipher.init(Cipher.ENCRYPT_MODE, secret);
        AlgorithmParameters params = cipher.getParameters();
        byte[] ivBytes = params.getParameterSpec(IvParameterSpec.class).getIV();
        byte[] encryptedTextBytes = cipher.doFinal(textToEncrypt.getBytes("UTF-8"));
        LOGGER.debug("EncryptDecryptUtil.encryptWithAES[] encryptedTextBytes[" + encryptedTextBytes + "]");
        byte[] encryptedTextBytesWithIv = ByteBuffer.allocate(ivBytes.length + encryptedTextBytes.length).put(ivBytes)
                .put(encryptedTextBytes).array();
        LOGGER.debug("EncryptDecryptUtil.encryptWithAES[] encryptedTextBytesWithIv[" + encryptedTextBytesWithIv + "]");
        result = new Base64().encodeAsString(encryptedTextBytesWithIv);
        LOGGER.debug("EncryptDecryptUtil.encryptWithAES[] result[" + result + "]");
        return result;
    }
}
