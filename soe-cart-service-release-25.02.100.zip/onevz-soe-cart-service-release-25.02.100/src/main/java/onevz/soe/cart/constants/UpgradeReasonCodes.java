package onevz.soe.cart.constants;

public enum UpgradeReasonCodes {
	MANAGER_APPROVAL_M2M("MN", "Manager approval - m2m"),
	MANAGER_APPROVAL_M1("M1", "Manager approval - 1yr"),
	MANAGER_APPROVAL_M2("M2", "Manager approval - 2yr"),
	MANAGER_APPROVAL_MX("MX", "Manager approval - m2m"),
	MANAGER_APPROVAL_MR("MR", "MGR APPROVAL, DEVICE PAYMENT TO 2 YR"),
	MANAGER_APPROVAL_MO("MO", "Manager Override w/working equipment"),
	INVALID("", "Invalid Reason Code - 0yr"),
	MANAGER_APPROVAL_MA("MA", "Manager Override w/o working equipment");
	

	private String upgradeReasonCode;
	private String name;
	private String description;
	
	UpgradeReasonCodes(String passedCode, String passedDescription) {
		this.setUpgradeReasonCode(passedCode);
		this.setDescription(passedDescription);
	}
	
	public String getUpgradeReasonCode() {
		return upgradeReasonCode;
	}

	private void setUpgradeReasonCode(String upgradeReasonCode) {
		this.upgradeReasonCode = upgradeReasonCode;
	}
	
	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}

	private void setDescription(String description) {
		this.description = description;
	}
	
	public static UpgradeReasonCodes findByCode(String code) {
		UpgradeReasonCodes reasonCode = UpgradeReasonCodes.INVALID;
		for (UpgradeReasonCodes s : UpgradeReasonCodes.values()) {
			if (s.upgradeReasonCode.equals(code)) {
				reasonCode = s;
				break;
			}
		}
		return reasonCode;
	}
}
