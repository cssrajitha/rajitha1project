package onevz.soe.cart.controller;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.helper.FiveGhomeMoversHelper;
import onevz.soe.cart.helper.RedisHelper3;
import onevz.soe.cart.model.addDevice.AddPlanDeviceCartInfo;
import onevz.soe.cart.model.common.FiveG.MoversCartRequest;
import onevz.soe.cart.requests.GetCartDetailsRequest;
import onevz.soe.cart.requests.MoveDatesRequest;
import onevz.soe.cart.requests.MoversUpdatePlanRequest;
import onevz.soe.cart.responses.AddPlanAndDevicePEGAResponse;
import onevz.soe.cart.responses.FiveGHomeMoversUIResponse;
import onevz.soe.cart.ui.requests.AddPlanAndDeviceUIRequest;
import onevz.soe.cart.ui.responses.AddMoveDatesUIResponse;
import onevz.soe.cart.ui.responses.MoversUpdatePlanResponse;
import onevz.soe.utilities.StringUtilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;


/**
 * Cart Controller class.
 */
@RestController
@RequestMapping(value = "cart")
public class FiveGHomeMoversController {

    private static final Logger logger = LoggerFactory.getLogger(FiveGHomeMoversController.class);

    @Autowired
    private FiveGhomeMoversHelper fiveGMoversHelper;

    @Autowired
    private RedisHelper3 redisHelper3;

    /**
     * @param binder
     */
    @InitBinder("*")
    public void initBinderByName(WebDataBinder binder) {
        binder.setDisallowedFields("genericHeader");
    }

    @PostMapping(path = "/5g/movers/retrieve-cart")
    public Mono<FiveGHomeMoversUIResponse> getMoversRetrieveCart(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse,
                                                                                @RequestBody GetCartDetailsRequest request) {
        return redisHelper3.fiveGRedisMoversData().flatMap(redisData -> {
            String cartId = redisData.getCartId();
            if(StringUtilities.isNotEmptyOrNull(redisData.getCartId()) && ! request.getData().isOrderPlaced()) {
                cartId = redisData.getCartId();
            }
            else if(StringUtilities.isNotEmptyOrNull(redisData.getCompletedCartId()) && request.getData().isOrderPlaced()) {
                cartId = redisData.getCompletedCartId();
            }
            else if(null != request && null != request.getData() && StringUtilities.isNotEmptyOrNull(request.getData().getCartId())) {
                cartId = request.getData().getCartId();
            }
            return fiveGMoversHelper.getMoversCart(cartId, redisData,request,httpHeader);
        });

    }
    @PostMapping(path = {"/5g/movers/updateCustomerMoveDates"})
    public Mono<AddMoveDatesUIResponse> updateMoveDates(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse, @RequestBody MoveDatesRequest request) {
        logger.info("customer Move Dates Request {}", request);
        return fiveGMoversHelper.addCustomerMoveDates(httpHeader,request).flatMap(Mono::just);
    }
    
    @PostMapping(value = {"/5g/movers/updateCart"})
    public Mono<AddPlanAndDevicePEGAResponse> addMoversPlanAndDevice(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse,
                                                                     @RequestBody MoversCartRequest request){
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        AddPlanAndDeviceUIRequest addPlanAndDeviceRequest = new AddPlanAndDeviceUIRequest();
        AddPlanDeviceCartInfo cartInfo = new AddPlanDeviceCartInfo();
        addPlanAndDeviceRequest.setCartInfo(cartInfo);
        addPlanAndDeviceRequest.getCartInfo().setClientAppName(channelId);
        addPlanAndDeviceRequest.setChannelId(channelId);
        return fiveGMoversHelper.addMoversPlanAndDevice(request, addPlanAndDeviceRequest);
    }

    @PostMapping(value = {"/5g/movers/updateCustomerPlan"})
    public Mono<MoversUpdatePlanResponse> updateCustomerMoverPlan(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse,
                                                                  @RequestBody MoversUpdatePlanRequest request){
        return fiveGMoversHelper.updateCustomerMoverPlan(request, httpHeader);
    }


}