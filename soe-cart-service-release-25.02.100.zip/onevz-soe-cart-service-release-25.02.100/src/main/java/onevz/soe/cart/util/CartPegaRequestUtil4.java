package onevz.soe.cart.util;
import onevz.cxp.feature.Flag;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.addAccessory.AccessoryAction;
import onevz.soe.cart.model.addBillingAddress.BillingAddressContext;
import onevz.soe.cart.model.addBillingAddress.BillingAddressServiceBody;
import onevz.soe.cart.model.addBillingAddress.BillingAddressServiceRequest;
import onevz.soe.cart.model.addDevice.AddDeviceContext;
import onevz.soe.cart.model.addDevice.AddDeviceServiceBody;
import onevz.soe.cart.model.addDevice.AddDeviceServiceRequest;
import onevz.soe.cart.model.addE911Address.E911AddressContext;
import onevz.soe.cart.model.addE911Address.E911AddressServiceBody;
import onevz.soe.cart.model.addE911Address.E911AddressServiceRequest;
import onevz.soe.cart.model.addPromoIntent.AddPromoIntent;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.instantCreditDownPayment.InstantCreditDownPaymentContext;
import onevz.soe.cart.model.instantCreditDownPayment.InstantCreditDownPaymentServiceBody;
import onevz.soe.cart.model.instantCreditDownPayment.InstantCreditDownPaymentServiceRequest;
import onevz.soe.cart.requests.*;
import onevz.soe.cart.model.addZipcodePEGA.AddZipcodeContext;
import onevz.soe.cart.model.addZipcodePEGA.AddZipcodeServiceBody;
import onevz.soe.cart.model.addZipcodePEGA.AddZipcodeServiceRequest;
import onevz.soe.cart.ui.common.DeviceCartInfo;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.spring.web.filter.RequestAccessContext;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import java.util.*;
import java.util.stream.Collectors;

import static onevz.soe.cart.util.BulkQuoteUpdatePegaRequestUtil.AI_QUOTE;

public class CartPegaRequestUtil4 {
    private static final Logger logger = LoggerFactory.getLogger(CartPegaRequestUtil4.class);
    @Value("${enableCradleForProspect:true}")
    private static boolean enableCradleForProspect;
    @Value("${enableCradleForExistingCustomer:true}")
    private static boolean enableCradleForExistingCustomer;


    /**
     * @param pegaRequest
     * @param request
     * @return AddDevicePEGARequest
     */
    public static AddDevicePEGARequest formatAddDeviceRequest(AddDevicePEGARequest pegaRequest, AddDeviceUIRequest request,
                                                              String throttleName, Boolean westWorldRouterFlag,
                                                              Boolean isTradeInPromoCheckFlag, Boolean skipResumeCaseFFlag, Flag preToPostActivationFeeFFlag) {
        String preToPostMigrationCookie = RequestAccessContext.obtainCookie(Arrays.asList(CartConstants.PREPAID_TO_POSTPAID_MIGRATION));
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        serviceHeader = CartPegaRequestUtil.addServiceHeader(serviceHeader);
        if (null != request) {
            setServiceHeader(serviceHeader,request);
            pegaRequest.setServiceHeader(serviceHeader);

            AddDeviceServiceBody serviceBody = new AddDeviceServiceBody();
            AddDeviceServiceRequest serviceRequest = new AddDeviceServiceRequest();
            AddDeviceContext context = new AddDeviceContext();

            CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
            //getting BYODESIM from ui request to pega request
            if (null != request.getCartInfo() && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getByodESim())) {
                customerInfo.setBYODESIM(request.getCartInfo().getByodESim());
            }
            if (StringUtilities.isNotEmptyOrNull(request.getExternalId())) {
                customerInfo.setVztExternalAccountId(request.getExternalId());
            }
            if (StringUtilities.isNotEmptyOrNull(request.getVzId())) {
                customerInfo.setVzId(request.getVzId());
            }
            if (StringUtilities.isNotEmptyOrNull(request.getUniversalId())) {
                customerInfo.setUniversalId(request.getUniversalId());
            }
            if (StringUtilities.isNotEmptyOrNull(request.getAppUniversalId())) {
                customerInfo.setAppUniversalId(request.getAppUniversalId());
            }
            if (null != request.getCartInfo()) {
                setCustomerInfo(request,customerInfo);
            }
            if (null != request.getChannelId()
                    && CartConstants.VZW_BBP.equalsIgnoreCase(request.getChannelId())
                    && null != request.getData()
                    && StringUtilities.isNotEmptyOrNull(request.getData().getEsimType())) {
                customerInfo.setEsimType(request.getData().getEsimType());
            }

            if (request.getData() != null) {
                if (request.getData().getIsLGPOEligible() != null && Boolean.TRUE.equals(request.getData().getIsLGPOEligible())) {
                    customerInfo.setIsLGPOEligible(request.getData().getIsLGPOEligible());
                }
            }
            CartServiceContextInfo contextInfo = new CartServiceContextInfo();
            if (null != request.getCartInfo()) {
                contextInfo = CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.ADD_DEVICE, request.getCartInfo().getClientAppName());
                // GTSFN-2160 - New Customer Transaction Prospect - Add device change
                if (CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())
                        || CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())
                        || CartConstants.NSE_5G.equalsIgnoreCase(request.getCartInfo().getIntendType())
                        || (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCustomerType())
                        && CartConstants.PREPAYEXISTINGCUST.equalsIgnoreCase(request.getCartInfo().getCustomerType())
                        && CartConstants.AAL.equalsIgnoreCase(request.getCartInfo().getIntendType())
                        && (null != request.getCartInfo() && null != request.getCartInfo().getIsPrepayCart()
                        && "Y".equalsIgnoreCase(request.getCartInfo().getIsPrepayCart())))

                ) {
                    CartPegaRequestUtil7.newCustomerOverride(contextInfo, customerInfo, request.getCartInfo(), request.getChannelId());
                }
            }

            CartServiceCartInfo cartInfo = new CartServiceCartInfo();
            if (null != request.getCartInfo()) {
                setCartInfo(cartInfo, request, contextInfo, context);
            }
            //RAFR-201
            if (null != request.getData() && StringUtilities.isNotEmptyOrNull(request.getData().getCouponCode()))
                cartInfo.setCouponCode(request.getData().getCouponCode());

            List<Line> lines = new ArrayList<>();
            if (null != request.getData()){
            for (Lines reqLine : request.getData().getLines()) {
                Line newLine = new Line();
                setNewLine(newLine, reqLine, request, customerInfo, preToPostMigrationCookie, throttleName, preToPostActivationFeeFFlag, cartInfo, westWorldRouterFlag, isTradeInPromoCheckFlag);
                lines.add(newLine);
            }
        }
            Line[] lineArr = new Line[lines.size()];
            lines.toArray(lineArr);

            cartInfo.setLines(lineArr);

            if (null!=request.getData() && request.getData().isEnableFcc()) {
                setAddressInfo(request, cartInfo);
            }

            if (StringUtilities.isEmptyOrNull(cartInfo.getClientAppName()))
                cartInfo.setClientAppName(request.getChannelId());

            if (CartConstants.BYOD.equalsIgnoreCase(cartInfo.getIntendType())) {
                customerInfo.setBauByodFlow(isBauByodFlow(request));
                contextInfo.setIntent(CartConstants.BYOD);
                if (request.getCartInfo()!=null && StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessStep()))
                    contextInfo.setProcessStep(request.getCartInfo().getProcessStep());
                if (request.getCartInfo()!=null && StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessAction()))
                    contextInfo.setProcessAction(request.getCartInfo().getProcessAction());

            } else if (CartConstants.AAL.equalsIgnoreCase(cartInfo.getIntendType()) && (null != request && null != request.getData() && CollectionUtils.isNotEmpty(request.getData().getLines()) && null != request.getData().getLines().get(0).getDevice() &&
                    StringUtilities.isNotEmptyOrNull(request.getData().getLines().get(0).getDevice().getNetworkBandwidthType()) &&
                    !("CBD".equalsIgnoreCase(request.getData().getLines().get(0).getDevice().getNetworkBandwidthType()) ||
                            "LTE".equalsIgnoreCase(request.getData().getLines().get(0).getDevice().getNetworkBandwidthType())))) {
                contextInfo.setIntent(CartConstants.AAL);
            } else if (CartConstants.EUP.equalsIgnoreCase(cartInfo.getIntendType())) {
                contextInfo.setIntent(CartConstants.UPGRADE);
            } else if (CartConstants.AAL_5G.equalsIgnoreCase(cartInfo.getIntendType()) ||
                    CartConstants.NSE_5G.equalsIgnoreCase(cartInfo.getIntendType())) {

                contextInfo.setIntent(CartConstants.FIVEG_HOME);
            } else if (null != request && null != request.getData() && CollectionUtils.isNotEmpty(request.getData().getLines()) && null != request.getData().getLines().get(0).getDevice() &&
                    StringUtilities.isNotEmptyOrNull(request.getData().getLines().get(0).getDevice().getNetworkBandwidthType())) {

                if ("CBD".equalsIgnoreCase(
                        request.getData().getLines().get(0).getDevice().getNetworkBandwidthType()) ||
                        "LTE".equalsIgnoreCase(
                                request.getData().getLines().get(0).getDevice().getNetworkBandwidthType())) {
                    contextInfo.setIntent(CartConstants.FIVEG_HOME);
                }
                if (request.getCartInfo()!=null && request.getCartInfo().getIntendType().equalsIgnoreCase(CartConstants.EUP_5G)
                        && null != westWorldRouterFlag && westWorldRouterFlag) {
                    contextInfo.setIntent(CartConstants.EUP_5G);
                    cartInfo.setIntendType(request.getCartInfo().getIntendType());
                    if (null != request.getCartInfo().getOneClick())
                        cartInfo.setOneClick(request.getCartInfo().getOneClick());
                    else cartInfo.setOneClick(false);
                    if (null != request.getCartInfo().getIsReturnRequired()) {
                        cartInfo.setIsReturnRequired(request.getCartInfo().getIsReturnRequired());
                    }
                }
            } else if (CartConstants.DEO.equalsIgnoreCase(cartInfo.getIntendType())) {
                contextInfo.setIntent(CartConstants.DEO);
            } else if (StringUtilities.isNotEmptyOrNull(cartInfo.getClientAppName())
                    && CartConstants.EUPBYOD.equalsIgnoreCase(cartInfo.getIntendType())) {
                if (request.getCartInfo()!=null && ("addSim".equalsIgnoreCase(request.getCartInfo().getProcessAction()))
                        && (CartConstants.VZW_ECOM.equalsIgnoreCase(cartInfo.getClientAppName())
                        || CartConstants.RETAIL_IPAD.equalsIgnoreCase(request.getChannelId())))
                    contextInfo.setIntent(CartConstants.BUYSIM);
                else
                    contextInfo.setIntent(CartConstants.BYOD);
            } else if (request.getCartInfo()!=null && CartConstants.AAL.equalsIgnoreCase(request.getCartInfo().getIntendType()) &&
                    CartConstants.PROCESS_INDICATOR_M.equalsIgnoreCase(request.getCartInfo().getMtnFlow())
                    && StringUtils.isBlank(request.getCartInfo().getProcessingMTN())) {
                contextInfo.setIntent(CartConstants.AAL);
            } else if (request.getCartInfo()!=null && CartConstants.AAL.equalsIgnoreCase(request.getCartInfo().getIntendType()) &&
                    CartConstants.PROCESS_INDICATOR_G.equalsIgnoreCase(request.getCartInfo().getMtnFlow())
                    && StringUtils.isBlank(request.getCartInfo().getProcessingMTN())) {
                contextInfo.setIntent(CartConstants.AAL);
            } else if (CartConstants.ACCOUNT_GROWTH.equalsIgnoreCase(cartInfo.getIntendType())) {
                contextInfo.setIntent(CartConstants.ACCOUNT_GROWTH);
            }
            if (StringUtilities.isNotEmptyOrNull(throttleName)) {
                customerInfo.setCradleFlowJourney(throttleName);
            }
            if (request.getCartInfo()!=null && CartConstants.PROMO_HUB.equalsIgnoreCase(throttleName)) {
                if (StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType())
                        || !request.getCartInfo().getIntendType().equalsIgnoreCase(CartConstants.AAL) ) {
                    cartInfo.setTriggerPricingValidation(true);
                }
                if (request.getPreConfigured() != null && request.getPreConfigured())
                    customerInfo.setPreConfiguredDevice(true);
            } else if (request.getData()!=null && request.getCartInfo()!=null && request.getCartInfo().getEditDevice() != null && request.getCartInfo().getEditDevice()
                    && request.getData().getExpressCheckout() != null && request.getData().getExpressCheckout()) {
                if (enableCradleForExistingCustomer) {
                    customerInfo.setCradleFlowJourney(CartConstants.PROMO_HUB);
                }
                if (StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType())
                        || !request.getCartInfo().getIntendType().equalsIgnoreCase(CartConstants.AAL)) {
                    cartInfo.setTriggerPricingValidation(true);
                }
            }
            // NSADT-45307 - Need to pass trigger price validation false for any intent type
            // as part of add-device
            if(request.getCartInfo()!=null) {
                setTriggerPricingValidation(cartInfo, request);
                setIntent(contextInfo,cartInfo, request);
                setIntentForNSEBYOD(contextInfo, cartInfo, customerInfo, request);
                if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                        && ((CartConstants.REFUND_EXCHANGE).equalsIgnoreCase(request.getCartInfo().getIntendType())
                        || (CartConstants.CONTRACT_CHANGE).equalsIgnoreCase(request.getCartInfo().getIntendType())
                        || (CartConstants.EXCHANGE).equalsIgnoreCase(request.getCartInfo().getIntendType())
                        || (CartConstants.EXCBYOD).equalsIgnoreCase(request.getCartInfo().getIntendType()))
                        || (CartConstants.PAD).equalsIgnoreCase(request.getCartInfo().getIntendType())) {
                    contextInfo.setCallReason(CartConstants.SALES_ORDER_ADJUSTMENT);
                    contextInfo.setIntent(CartConstants.REX);
                }
                setFWARetailExchangeIntent(request, contextInfo);
                //CLNR ADD-DEVICE FLOW
                if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                        && ((CartConstants.CLNR_FLOW).equalsIgnoreCase(request.getCartInfo().getIntendType()))) {
                    contextInfo.setCallReason(CartConstants.SALES_ORDER_ADJUSTMENT);
                    contextInfo.setIntent(CartConstants.CLNR_FLOW);
                    logger.info("Add-Device Intent set for CLNR flow: {}", contextInfo.getIntent());
                }
                if (!enableCradleForProspect &&
                        (CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())
                                || CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType()))) {
                    customerInfo.setCradleFlowJourney("");
                }

                if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getFiveGMUCEligible())) {
                    cartInfo.setFiveGMUCEligible(request.getCartInfo().getFiveGMUCEligible());
                }

                // added for Next Gen NSE_BYOD flow in MVA
                if (CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType()) && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCradleFlowJourney()))
                    customerInfo.setCradleFlowJourney(request.getCartInfo().getCradleFlowJourney());


                // Setting ProcessingMTN for digital Exchange RFEX flow
                if (CartUtil.isDigital(request.getChannelId())
                        && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                        && CartConstants.REX.equalsIgnoreCase(request.getCartInfo().getIntendType())
                        && null != request.getRfexExchangeShopDetails()
                        && StringUtilities.isNotEmptyOrNull(request.getRfexExchangeShopDetails().getMtn())) {
                    customerInfo.setProcessingMTN(request.getRfexExchangeShopDetails().getMtn());
                    logger.info("Add-Device processingMTN set for Digital RFEX flow: {}", customerInfo.getProcessingMTN());
                    if (null != cartInfo.getLines() && cartInfo.getLines().length > 0) {
                        for (Line cartInfoline : cartInfo.getLines()) {
                            logger.info("Line Mtn set for Digital RFEX flow: {}",
                                    request.getRfexExchangeShopDetails().getMtn());
                            cartInfoline.setMtn(request.getRfexExchangeShopDetails().getMtn());
                            logger.info("CartInfo Line Mtn set to : {} for Digital RFEX flow", cartInfoline.getMtn());
                        }
                    }
                }

                //VZWYN-17835 changes
                if (null != request.getChannelId()
                        && CartConstants.VZW_BBP.equalsIgnoreCase(request.getChannelId())
                        && null != request.getData()
                        && StringUtilities.isNotEmptyOrNull(request.getData().getEsimFlowType())
                        && null != request.getCartInfo()
                        && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                        && !(CartConstants.NSE).equalsIgnoreCase(request.getCartInfo().getIntendType())) {
                    customerInfo.setEsimFlowType(request.getData().getEsimFlowType());
                    if (CartConstants.LOST_ICCID_PROFILE.equalsIgnoreCase(request.getData().getEsimFlowType())) {
                        cartInfo.setIntendType(CartConstants.EUPBYOD);
                        contextInfo.setIntent(CartConstants.ICCID.toUpperCase());
                    }
                }
            }
            logger.info("VzId value in addDevice pegaRequest {}", customerInfo.getVzId());
            context.setCustomerInfo(customerInfo);
            //MVP2-GR
            updatesForSalesOrderFlexFlow(request,contextInfo, serviceHeader,cartInfo);

            if (null != request.getData() && null != request.getData().getLines()
                    && CollectionUtils.isNotEmpty(request.getData().getLines())
                    && null != request.getData().getLines().get(0)) {
                if (StringUtilities.isNotEmptyOrNull(request.getData().getLines().get(0).getIdVerifyStatus()))
                    cartInfo.setIdVerifyStatus(request.getData().getLines().get(0).getIdVerifyStatus());
                if (null != cartInfo.getLines() && cartInfo.getLines().length > 0) {
                    for (Line cartInfoline : cartInfo.getLines()) {
                        cartInfoline.setHighRiskSimswapDelayActivation(request.getData().getLines().get(0).getHighRiskSimswapDelayActivation());
                        cartInfoline.setIsCustConsentAcceptedSMSBlast(request.getData().getLines().get(0).getIsCustConsentAcceptedSMSBlast());
                    }
                }
            }

            if (request.getCartInfo() != null && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()) &&
                    request.getCartInfo().getIsPromoPDP() != null && Boolean.TRUE.equals(request.getCartInfo().getIsPromoPDP())) {
                contextInfo.setIntent(request.getCartInfo().getIntendType());
                if (CartConstants.EUP.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
                    contextInfo.setIntent(CartConstants.UPGRADE);
                }
            }
            finalUpdates(cartInfo, contextInfo,context, pegaRequest, skipResumeCaseFFlag,request);
            context.setContextInfo(contextInfo);
            context.setCartInfo(cartInfo);
            serviceRequest.setContext(context);
            serviceBody.setServiceRequest(serviceRequest);
            pegaRequest.setServiceBody(serviceBody);
        }
        return pegaRequest;
    }

    private static void setFWARetailExchangeIntent(AddDeviceUIRequest request, CartServiceContextInfo contextInfo) {
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntent())
                && CartConstants.FIVEG_HOME_RETAIL_RFEX.equalsIgnoreCase(request.getCartInfo().getIntent())){
            contextInfo.setIntent(CartConstants.FIVEG_HOME_RETAIL_RFEX);
        }
    }

    private static void setServiceHeader(CartServiceServiceHeader serviceHeader, AddDeviceUIRequest request) {
        serviceHeader.setClientId(request.getChannelId());

        if (null != request.getCartInfo() && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                && ((CartConstants.REFUND_EXCHANGE).equalsIgnoreCase(request.getCartInfo().getIntendType())
                || (CartConstants.CONTRACT_CHANGE).equalsIgnoreCase(request.getCartInfo().getIntendType())
                || (CartConstants.EXCHANGE).equalsIgnoreCase(request.getCartInfo().getIntendType())
                || (CartConstants.EXCBYOD).equalsIgnoreCase(request.getCartInfo().getIntendType())
                || (CartConstants.PAD).equalsIgnoreCase(request.getCartInfo().getIntendType()))) {
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_ADJUSTMENT);
        }
        //CLNR - ADD-DEVICE FLOW
        if (null != request.getCartInfo() && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                && ((CartConstants.CLNR_FLOW).equalsIgnoreCase(request.getCartInfo().getIntendType()))) {
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_ADJUSTMENT);
            logger.info("Add-Device ServiceName set for CLNR flow: {}", serviceHeader.getServiceName());
        }
    }

    private static void updatesForSalesOrderFlexFlow(AddDeviceUIRequest request, CartServiceContextInfo contextInfo, CartServiceServiceHeader serviceHeader, CartServiceCartInfo cartInfo) {
        if (request.getCartInfo() != null && request.getCartInfo().getCaseId() != null && request.getCartInfo().getCaseId().startsWith("SOF")) {

            logger.info("SalesOrderFlex Prepay add device Request before PEGA call setting Call Reason");
            contextInfo.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_FLEX);
            if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getCaseId())
                    && request.getCartInfo().getCaseId().startsWith("SOF", 0)
                    && request.getCartInfo().getOneClick() != null && request.getCartInfo().getOneClick()) {
                logger.info("CartInfo Line OneClick set to true with Case ID: {}", request.getCartInfo().getCaseId());
                cartInfo.setOneClick(request.getCartInfo().getOneClick());
            }
            if (null != request.getChannelId()
                    && CartConstants.OMNI_TELESALES.equalsIgnoreCase(request.getChannelId())
                    && null != request.getData() && null != request.getData().getLines()
                    && null != request.getData().getLines().get(0)
                    && null != request.getData().getLines().get(0).getDevice()
                    && null != request.getData().getLines().get(0).getDevice().getIsCustomerProvidedEquipment()
                    && request.getData().getLines().get(0).getDevice().getIsCustomerProvidedEquipment()) {
                logger.info("CartInfo setting PrepayCart as true for CustomerProvidedEquipment Flow Telesales");
                cartInfo.setIsPrepayCart(true);
            }

        }
    }

    private static void finalUpdates(CartServiceCartInfo cartInfo, CartServiceContextInfo contextInfo, AddDeviceContext context, AddDevicePEGARequest pegaRequest, Boolean skipResumeCaseFFlag, AddDeviceUIRequest request) {
        if (request.getCartInfo() != null) {
            // Changes to update callreason, flow type, service name for Customer trial flow
            if (CartPegaRequestUtil.isTrialCustomerFlow(request.getCartInfo().getFlowType())) {
                pegaRequest.getServiceHeader().setServiceName(CartConstants.SERVICE_NAME_TRIAL);
                context.getCustomerInfo().setFlowType(CartConstants.FLOW_TYPE_DVM);
                contextInfo.setCallReason(CartConstants.TRIAL_CALLREASON);
            }
            // CXTDT-546382: Fix to add VztExternalAccountId to pega request
            if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getVztExternalAccountId()))
                cartInfo.setVztExternalAccountId(request.getCartInfo().getVztExternalAccountId());

            if (request.getCartInfo().getPastdue() != null)
                cartInfo.setPastdue(request.getCartInfo().getPastdue());
            if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getPastDueAccepted()))
                contextInfo.setPastDueAccepted(request.getCartInfo().getPastDueAccepted());

            setCaseId(context, request);
            if (skipResumeCaseFFlag && request.getCartInfo().getSkipResumeCase()
                    && StringUtilities.isEmptyOrNull(context.getCaseId()) && StringUtilities.isEmptyOrNull(cartInfo.getCartId())) {
                cartInfo.setSkipResumeCase(true);
            }
        }
    }

    private static void setCaseId(AddDeviceContext context, AddDeviceUIRequest request) {
        if (StringUtils.isNoneBlank(request.getRequestApiName()) && "add-step".equalsIgnoreCase(request.getRequestApiName())) {
            context.setCaseId("");
        } else {
            context.setCaseId(request.getCartInfo().getCaseId());
        }
    }

    private static void setIntentForNSEBYOD(CartServiceContextInfo contextInfo, CartServiceCartInfo cartInfo, CartServiceCustomerInfo customerInfo, AddDeviceUIRequest request) {
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                && ((CartConstants.NSE_BYOD).equalsIgnoreCase(request.getCartInfo().getIntendType()))) {
            contextInfo.setIntent(CartConstants.NSE_BYOD);
            cartInfo.setIntendType(CartConstants.NSE_BYOD);
            customerInfo.setBauByodFlow(isBauByodFlow(request));
            if (request.getData() != null && request.getData().getLines() != null //GTSFN-7863 and 7865 BYOD ESIM Flow
                    && CollectionUtilities.isNotEmptyOrNull(request.getData().getLines())) {
                if (request.getData().getLines().get(0).getDevice() != null
                        && request.getData().getLines().get(0).getDevice().getByodESimPhone() != null) {
                    setSim(cartInfo, customerInfo, request);
                }

            }
        }

    }

    private static void setSim(CartServiceCartInfo cartInfo, CartServiceCustomerInfo customerInfo, AddDeviceUIRequest request) {
        if (cartInfo.getLines() != null && cartInfo.getLines().length > 0 && cartInfo.getLines()[0].getDevice() != null) {
            cartInfo.getLines()[0].getDevice().setByodESimPhone(request.getData().getLines().get(0).getDevice().getByodESimPhone());
            if (request.getData().getLines().get(0).getDevice().getByodESimPhone() != null &&
                    request.getData().getLines().get(0).getDevice().getByodESimPhone()) {
                cartInfo.getLines()[0].getSim().setIsCustomerProvidedSIM(request.getData().getLines().get(0).getSim().getIsCustomerProvidedSIM());
                cartInfo.getLines()[0].getDevice().setIsCustomerProvidedSIM(request.getData().getLines().get(0).getSim().getIsCustomerProvidedSIM());
            }
        }
        if (request.getData().getLines().get(0).getEditSim() != null) {
            customerInfo.setEditSim(request.getData().getLines().get(0).getEditSim());
        }
    }

    private static void setIntent(CartServiceContextInfo contextInfo, CartServiceCartInfo cartInfo, AddDeviceUIRequest request) {
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getRpsIntent())) {
            contextInfo.setIntent(request.getCartInfo().getRpsIntent());
        }
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                && ((CartConstants.NSE).equalsIgnoreCase(request.getCartInfo().getIntendType())) &&
                (null != request && null != request.getData() && CollectionUtils.isNotEmpty(request.getData().getLines()) && null != request.getData().getLines().get(0).getDevice() &&
                        StringUtilities.isEmptyOrNull(request.getData().getLines().get(0).getDevice().getNetworkBandwidthType()))) {
            contextInfo.setIntent(CartConstants.NSE);
            cartInfo.setIntendType(CartConstants.NSE);
        } else if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                && ((CartConstants.NSE).equalsIgnoreCase(request.getCartInfo().getIntendType())) &&
                (null != request && null != request.getData() && CollectionUtils.isNotEmpty(request.getData().getLines()) && null != request.getData().getLines().get(0).getDevice() &&
                        !StringUtilities.isEmptyOrNull(request.getData().getLines().get(0).getDevice().getNetworkBandwidthType())) &&
                !("CBD".equalsIgnoreCase(request.getData().getLines().get(0).getDevice().getNetworkBandwidthType()) ||
                        "LTE".equalsIgnoreCase(request.getData().getLines().get(0).getDevice().getNetworkBandwidthType()))) {
            contextInfo.setIntent(CartConstants.NSE);
            cartInfo.setIntendType(CartConstants.NSE);
        } else if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                && ((CartConstants.NSE).equalsIgnoreCase(request.getCartInfo().getIntendType())) &&
                (null != request && null != request.getData() && CollectionUtils.isNotEmpty(request.getData().getLines()) && null != request.getData().getLines().get(0).getDevice() &&
                        !StringUtilities.isEmptyOrNull(request.getData().getLines().get(0).getDevice().getNetworkBandwidthType())) &&
                ("CBD".equalsIgnoreCase(request.getData().getLines().get(0).getDevice().getNetworkBandwidthType()) ||
                        "LTE".equalsIgnoreCase(request.getData().getLines().get(0).getDevice().getNetworkBandwidthType()))) {
            contextInfo.setIntent(CartConstants.FIVEG_HOME);
            cartInfo.setIntendType(CartConstants.NSE);
        }
    }

    private static void setTriggerPricingValidation(CartServiceCartInfo cartInfo, AddDeviceUIRequest request) {
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                && "Y".equalsIgnoreCase(request.getCartInfo().getNumberShareCapable()) && !isAiQuote(request.getCartInfo())){
            cartInfo.setTriggerPricingValidation(false);
        }
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getClientAppName())
                && CartConstants.VZW_RPS.equalsIgnoreCase(request.getCartInfo().getClientAppName())) {
            cartInfo.setTriggerPricingValidation(request.getCartInfo().getTriggerPricingValidation());
        }
        if (null != request.getChannelId() && (CartConstants.RETAIL.equalsIgnoreCase(request.getChannelId())
                || CartConstants.RETAIL_IPAD.equalsIgnoreCase(request.getChannelId())) && request.getCartInfo().getMtnFlow() != null
                && CartConstants.PROMOBUNDLE.equalsIgnoreCase(request.getCartInfo().getMtnFlow())) {
            cartInfo.setTriggerPricingValidation(true);
        }
        if (null != request.getChannelId() && (CartConstants.RETAIL.equalsIgnoreCase(request.getChannelId())
                || CartConstants.RETAIL_IPAD.equalsIgnoreCase(request.getChannelId()))
                && request.getCartInfo().getMtnFlow() != null
                && CartConstants.PROMOBUNDLE.equalsIgnoreCase(request.getCartInfo().getMtnFlow())) {
            cartInfo.setTriggerPricingValidation(true);
        }
    }

    private static void setNewLine(Line newLine, Lines reqLine, AddDeviceUIRequest request, CartServiceCustomerInfo customerInfo, String preToPostMigrationCookie, String throttleName, Flag preToPostActivationFeeFFlag, CartServiceCartInfo cartInfo, Boolean westWorldRouterFlag, Boolean isTradeInPromoCheckFlag) {
        if (reqLine.getMtn() != null)
            newLine.setMtn(reqLine.getMtn());
        if (reqLine.getBuyGetInd() != null)
            newLine.setBuyGetInd(reqLine.getBuyGetInd());
        if (reqLine.getSecondNumber() != null)
            newLine.setSecondNumber(reqLine.getSecondNumber());
        if (reqLine.getUnpairDevice() != null)
            newLine.setUnpairDevice(reqLine.getUnpairDevice());
        if (reqLine.getSkipAutoAttachForBYODCC() != null)
            newLine.setSkipAutoAttachForBYODCC(reqLine.getSkipAutoAttachForBYODCC());
        //fix for NSADT-127418
        if (CollectionUtilities.isNotEmptyOrNull(reqLine.getSelectedOffers())) {
            if (null != request.getChannelId() && (CartConstants.OMNI_INDIRECT.equalsIgnoreCase(request.getChannelId())
                    || CartConstants.OMNI_INDIRECT_TAB.equalsIgnoreCase(request.getChannelId()))) {
                List<BvoOffers> selectedOffers = reqLine.getSelectedOffers();
                logger.info(String.format("selectedoffers before filtering== %s ", selectedOffers.toString()));
                List<BvoOffers> indirectSelectedOffers = selectedOffers.stream()
                        .filter(bvoOffers -> !CartConstants.TRADE.equalsIgnoreCase(bvoOffers.getSubType()))
                        .collect(Collectors.toList());
                logger.info(String.format("selectedoffers after filtering== %s", indirectSelectedOffers.toString()));
                if (indirectSelectedOffers.size() > 0)
                    newLine.setSelectedOffers(indirectSelectedOffers);
            } else {
                newLine.setSelectedOffers(reqLine.getSelectedOffers());
            }

        }
        if (CollectionUtilities.isNotEmptyOrNull(reqLine.getPromoIntent())) {
            newLine.setPromoIntent((reqLine.getPromoIntent()).stream().toArray(AddPromoIntent[]::new));
        }
        if (null != request.getCartInfo() && request.getCartInfo().getMtnFlow() != null && CartConstants.PROMOBUNDLE.equalsIgnoreCase(request.getCartInfo().getMtnFlow())) {
            newLine.setPromoFirstBundleFlow(true);
        }
        if (reqLine.getContractTerm() != null)
            newLine.setContractTerm(reqLine.getContractTerm());
        if (reqLine.getLineDeviceDollar() != null)
            newLine.setLineDeviceDollar(reqLine.getLineDeviceDollar());
        if (reqLine.getUpgradeReasonCode() != null)
            newLine.setUpgradeReasonCode(reqLine.getUpgradeReasonCode());
        if (reqLine.getDevice() != null) {
            newLine.setDevice(reqLine.getDevice());
            newLine.getDevice().setQty(1);
            if (request.getCartInfo() != null && reqLine.getDevice().getConnectedCarDetails() != null && !reqLine.getDevice().getConnectedCarDetails().toString().isEmpty() && CartConstants.CHANNEL_ID_BBP.equalsIgnoreCase(request.getCartInfo().getClientAppName())) {
                customerInfo.setDeviceType(CartConstants.CONNECTED_CAR);
                newLine.getDevice().setConnectedCarDetails(reqLine.getDevice().getConnectedCarDetails());
                newLine.getDevice().setDeviceId(request.getCartInfo().getDeviceId() != null ? request.getCartInfo().getDeviceId() : "");
            }
        }
        if (reqLine.getFiveG() != null) {
            newLine.setFiveG(reqLine.getFiveG());
        }

        if (StringUtilities.isNotEmptyOrNull(preToPostMigrationCookie) && preToPostMigrationCookie.equalsIgnoreCase("true") && preToPostActivationFeeFFlag != null && preToPostActivationFeeFFlag.isEnabled()) {
            Map<String, List<String>> attributeMap = preToPostActivationFeeFFlag.getAttributes();
            List<String> offerCode = attributeMap.get("offerCode");
            if(offerCode != null && offerCode.size() > 0) {
                newLine.setOfferCode(offerCode.get(0));
            }
        }

        AccessoryAction accessoryAction = new AccessoryAction();
        Accessory[] accessories = new Accessory[3];
        accessoryAction.setAdd(accessories);

        if (null != reqLine.getDepletionType() && null != reqLine.getDevice() && null != reqLine.getDevice().getNetworkBandwidthType() && null != reqLine.getAddAccessories()) {
            if (!reqLine.getDepletionType().equalsIgnoreCase(CartConstants.O)
                    && !reqLine.getDevice().getNetworkBandwidthType().equalsIgnoreCase(CartConstants.TGW)) {
                newLine.setAccessories(accessoryAction);
                newLine.getAccessories().setAdd(reqLine.getAddAccessories());
            }
        }
        // numbershare properties
        if (StringUtilities.isNotEmptyOrNull(reqLine.getTrunkMtn()))
            newLine.setTrunkMtn(reqLine.getTrunkMtn());
        if (StringUtilities.isNotEmptyOrNull(reqLine.getMldTrunkMtn()))
            newLine.setMldTrunkMtn(reqLine.getMldTrunkMtn());
        if (reqLine.getCurrentPairingModeChanged() != null) {
            newLine.setCurrentPairingModeChanged(reqLine.getCurrentPairingModeChanged());
        }
        if (StringUtilities.isNotEmptyOrNull(reqLine.getNumbersharePairingMode())) {
            newLine.setNumbersharePairingMode(reqLine.getNumbersharePairingMode());
        }
        if (request.getCartInfo() != null && CartUtil.isDigital(request.getChannelId()) && CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
            if (StringUtilities.isNotEmptyOrNull(throttleName) && !throttleName.contains(CartConstants.ACCESSORIES_INTERSTIAL_PROSPECT)) {
                if (StringUtilities.isNotEmptyOrNull(reqLine.getNumbersharePairingMode())) {
                    newLine.setNumbersharePairingMode("");
                }
            }
        }
        // set e911 address

        if (reqLine.getE911Address() != null) {
            newLine.setE911Address(reqLine.getE911Address());
        }
        if (reqLine.getSim() != null)
            newLine.setSim(reqLine.getSim());

        if (reqLine.getAddFeatures() != null || reqLine.getRemoveFeatures() != null) {
            FeatureAction action = new FeatureAction();
            if (reqLine.getAddFeatures() != null && !reqLine.getAddFeatures().isEmpty())
                action.setAdd(reqLine.getAddFeatures());
            if (reqLine.getRemoveFeatures() != null && !reqLine.getRemoveFeatures().isEmpty())
                action.setRemove(reqLine.getRemoveFeatures());
            newLine.setFeatures(action);
            cartInfo.setTriggerPricingValidation(true);
        } else if (request.getCartInfo() != null && null != request.getCartInfo().getTriggerPricingValidation())
            cartInfo.setTriggerPricingValidation(request.getCartInfo().getTriggerPricingValidation());
        else {
            cartInfo.setTriggerPricingValidation(true);
        }
        if (request.getCartInfo() != null && null != request.getChannelId() && (CartConstants.RETAIL.equalsIgnoreCase(request.getChannelId())
                || CartConstants.RETAIL_IPAD.equalsIgnoreCase(request.getChannelId())) && request.getCartInfo().getMtnFlow() != null
                && CartConstants.PROMOBUNDLE.equalsIgnoreCase(request.getCartInfo().getMtnFlow())) {

            cartInfo.setIncludeNBS("N");
        }
        // my offer changes
        if (reqLine.getRtdOfferId() != null)
            newLine.setRtdOfferId(reqLine.getRtdOfferId());
        if (reqLine.getRestricted() != null)
            newLine.setRestricted(reqLine.getRestricted());
        if (reqLine.getRestrictedProductType() != null)
            newLine.setRestrictedProductType(reqLine.getRestrictedProductType());
        if (StringUtilities.isNotEmptyOrNull(reqLine.getBarCodeId()))
            newLine.setBarCodeId(reqLine.getBarCodeId());
        if (reqLine.getSelectedSedOfferId() != null)
            newLine.setSelectedSedOfferId(reqLine.getSelectedSedOfferId());


        if (reqLine.getEdgeup() != null)
            newLine.setEdgeup(reqLine.getEdgeup());
        if (reqLine.getIsEdgeBuyOut() != null)
            newLine.setIsEdgeBuyOut(reqLine.getIsEdgeBuyOut());
        if (reqLine.getDownPayment() != null)
            newLine.setDownPayment(reqLine.getDownPayment());

        if (reqLine.getIspuFlow() != null)
            newLine.setIspuFlow(reqLine.getIspuFlow());
        if (reqLine.getSddZipCode() != null)
            newLine.setSddZipCode(reqLine.getSddZipCode());
        if (reqLine.getDepletionType() != null)
            newLine.setDepletionType(reqLine.getDepletionType());
        if (null != reqLine.getPreBackOrderDate())
            newLine.setPreBackOrderDate(reqLine.getPreBackOrderDate());
        if (reqLine.getSetUpLater() != null)
            newLine.setSetUpLater(reqLine.getSetUpLater());
        if (reqLine.getSelectedEUPDeviceForBYOD() != null)
            newLine.setSelectedEUPDeviceForBYOD(reqLine.getSelectedEUPDeviceForBYOD());

        if (reqLine.getDepletionLocationCode() != null)
            newLine.setDepletionLocationCode(CartUtil.removeSpecialCharacters(reqLine.getDepletionLocationCode(), request.getChannelId()));
        else
            newLine.setDepletionLocationCode("");
        newLine.setEstimatedReadyByDate(reqLine.getEstimatedReadyByDate());
        if (reqLine.getIsNewLine() != null && reqLine.getFiveG() == null
                && request.getData().getLines().size() == 1) {
            if (reqLine.getIsNewLine() && !("BYOD".equalsIgnoreCase(cartInfo.getIntendType()))) {
                cartInfo.setIntendType(CartConstants.EUP.equalsIgnoreCase(cartInfo.getIntendType()) ? CartConstants.EUP : CartConstants.AAL);
            }

        }
        if (reqLine.isLineWithSkipMDN())
            newLine.setLineWithSkipMDN(true);

        if (null != reqLine.getIsNewLine() && reqLine.getIsNewLine())
            newLine.setNewLineOrAAL(reqLine.getIsNewLine());
        else
            newLine.setNewLineOrAAL(reqLine.getNewLineOrAAL());
        if (null != reqLine.getSellerPrice())
            newLine.setSellerPrice(reqLine.getSellerPrice());

        // Promo Intercept
        if (reqLine.getPromoRejectionIndicator() != null) {
            newLine.setPromoRejectionIndicator(reqLine.getPromoRejectionIndicator());
        }

        if (StringUtilities.isNotEmptyOrNull(reqLine.getSelectedPromoType())) {
            newLine.setSelectedPromoType(reqLine.getSelectedPromoType());
        }
        if (StringUtilities.isNotEmptyOrNull(reqLine.getSelectedPromoId())) {
            newLine.setSelectedPromoId(reqLine.getSelectedPromoId());
        }
        if (StringUtilities.isNotEmptyOrNull(reqLine.getBuyDevSorId())) {
            newLine.setBuyDevSorId(reqLine.getBuyDevSorId());
        }

        if (reqLine.getIsCommonPDP() != null && Boolean.TRUE.equals(reqLine.getIsCommonPDP())) {
            newLine.setIsCommonPDP(true);
        } else {
            newLine.setIsCommonPDP(false);
        }
        if (reqLine.getIsTradeInIntentSelected() != null && Boolean.TRUE.equals(reqLine.getIsTradeInIntentSelected())) {
            newLine.setIsTradeInIntentSelected(true);
        } else {
            newLine.setIsTradeInIntentSelected(false);
        }
        if (StringUtilities.isNotEmptyOrNull(reqLine.getTradeInPromoSelected()) && isTradeInPromoCheckFlag) {
            newLine.setTradeInPromoSelected(reqLine.getTradeInPromoSelected());
        }

        if (StringUtilities.isNotEmptyOrNull(reqLine.getPurchasePath())) {
            newLine.setPurchasePath(reqLine.getPurchasePath());
        }
        if (StringUtilities.isNotEmptyOrNull(reqLine.getSelectedSpoId())) {
            newLine.setSelectedSpoId(reqLine.getSelectedSpoId());
        }

        if (reqLine.isEupNoPromoFlow()) {
            newLine.setEupNoPromoFlow(true);
        } else {
            newLine.setEupNoPromoFlow(false);
        }
        newLine.setSkipPromoChoiceOffer(reqLine.isSkipPromoChoiceOffer());

        if (null != reqLine.getIdu())
            newLine.setIdu(reqLine.getIdu());
        if (null != reqLine.getGiftBox())
            newLine.setGiftBox(reqLine.getGiftBox());
        if (null == reqLine.getQaIconicTesting() || !reqLine.getQaIconicTesting())
            newLine.setQaIconicTesting(false);
        else
            newLine.setQaIconicTesting(true);

        // Adding portin properties for New Customer
        if (reqLine.getCustomerProvidedMtn() != null && !reqLine.getCustomerProvidedMtn().isEmpty()) {
            newLine.setCustomerProvidedMtn(reqLine.getCustomerProvidedMtn());
        }
        if (reqLine.getCustomerProvidedMtnType() != null && !reqLine.getCustomerProvidedMtnType().isEmpty()) {
            newLine.setCustomerProvidedMtnType(reqLine.getCustomerProvidedMtnType());
        }

        if (reqLine.isInWithVerizonOpted()) {
            newLine.setInWithVerizonOpted(CartConstants.TRUE);
        }

        if (null != reqLine.getTradeInInfo() && null != reqLine.getTradeInInfo().getDeviceBrand() &&
                null != reqLine.getTradeInInfo().getDeviceModel()) {
            boolean isValidTradeInPromoReq = (reqLine.getTradeInInfo().getAemOfferIds() != null &&
                    !reqLine.getTradeInInfo().getAemOfferIds().isEmpty()) ||
                    (StringUtils.isNotBlank(reqLine.getTradeInInfo().getTradeinMarketingId()));
            if (isValidTradeInPromoReq) {
                newLine.setTradeInInfo(reqLine.getTradeInInfo());
            }
        }


        if (request.getCartInfo() != null && StringUtils.isNotEmpty(request.getCartInfo().getIconicTestIntent())) {
            newLine.setIconicTestIntent(request.getCartInfo().getIconicTestIntent());
        }

        if (StringUtilities.isNotEmptyOrNull(reqLine.getLineCreatorChannel())) {
            newLine.setLineCreatorChannel(reqLine.getLineCreatorChannel());
        }
        if (request.getCartInfo() != null && reqLine.getPlan() != null &&
                (CartConstants.PROMOBUNDLE.equalsIgnoreCase(request.getCartInfo().getMtnFlow())
                        || CartConstants.AI_QUOTE.equalsIgnoreCase(request.getCartInfo().getMtnFlow()))) {
            newLine.setPlan(reqLine.getPlan());
        }

        //CLNR - Setting ClnrInfo in pega request
        if (request.getCartInfo() != null && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                && CartConstants.CLNR_FLOW.equalsIgnoreCase(request.getCartInfo().getIntendType()) && reqLine.getClnrInfo() != null) {
            newLine.setClnrInfo(reqLine.getClnrInfo());
        }

        if (StringUtilities.isNotEmptyOrNull(reqLine.getBuyDeviceLineMtn()))
            newLine.setBuyDeviceLineMtn(reqLine.getBuyDeviceLineMtn());
        // Story: ACT180-1011
        if (null != request.getCartInfo() && null != request.getCartInfo().getEnableDefaultedShipToHome()) {
            newLine.setIsShipToHome(request.getCartInfo().getEnableDefaultedShipToHome());
        } else {
            newLine.setIsShipToHome(Boolean.FALSE);
        }

        if (null != reqLine.getIsKeepingExistingEqProtection()) {
            newLine.setIsKeepingExistingEqProtection(reqLine.getIsKeepingExistingEqProtection());
        }

        if (null != reqLine.getHighDecileIndicator()) {
            newLine.setHighDecileIndicator(reqLine.getHighDecileIndicator());
        }
        //RAFR-201
        if (StringUtilities.isNotEmptyOrNull(reqLine.getPortInNumber()))
            newLine.setPortInNumber(reqLine.getPortInNumber());

        if (request.getCartInfo() != null && StringUtilities.isEmptyOrNull(reqLine.getMtn()) && request.getCartInfo().getIntendType().equalsIgnoreCase(CartConstants.EUP_5G)
                && null != westWorldRouterFlag && westWorldRouterFlag) {
            if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessingMTN()))
                newLine.setMtn(request.getCartInfo().getProcessingMTN());
            else if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCartCreator()))
                newLine.setMtn(request.getCartInfo().getCartCreator());
            else newLine.setMtn(request.getMtn());
        }

    }

    private static void setCartInfo(CartServiceCartInfo cartInfo, AddDeviceUIRequest request, CartServiceContextInfo contextInfo, AddDeviceContext context) {
            if (StringUtils.isNoneBlank(request.getRequestApiName()) && "add-step".equalsIgnoreCase(request.getRequestApiName())) {
                cartInfo.setCartId("");
            } else {
                cartInfo.setCartId(request.getCartInfo().getCartId());
            }
            addQuickShopPegaRequestFlag(request, cartInfo);
            cartInfo.setClientAppName(request.getCartInfo().getClientAppName());
            cartInfo.setAction(CartConstants.UPDATE);
            if (null != request.getData()) {
                cartInfo.setClearCart(request.getData().getClearCart());
            }
            if (request.getCartInfo().getAuthorizedUser() != null) {
                request.getCartInfo().getAuthorizedUser().setFirstName(request.getCartInfo().getAuthorizedUser().getFirstName().replaceAll("(?=\")", "\\\\"));
                request.getCartInfo().getAuthorizedUser().setLastName(request.getCartInfo().getAuthorizedUser().getLastName().replaceAll("(?=\")", "\\\\"));
                cartInfo.setAuthorizedUser(request.getCartInfo().getAuthorizedUser());
            }
        if (request.isFlexV2ValidationFLag()) {
            if (request.getData() != null && !FlexV2Util.isBYODFlow(request.getData().getLines()) && request.getCartInfo().isFlexV2()) {
                cartInfo.setFlexV2(true);
            }
        } else {
            if (request.getCartInfo().isFlexV2()) {
                cartInfo.setFlexV2(true);
            }
        }


            cartInfo.setFromFreePhoneQV(request.getCartInfo().isFromFreePhoneQV());


            if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getMasterAgentId()) && StringUtilities.isNotEmptyOrNull( request.getCartInfo().getOutletId())){
                BbOrderDetails bbOrderDetails= new BbOrderDetails();
                cartInfo.setBbOrderDetails(bbOrderDetails);
                bbOrderDetails.setOutletId(request.getCartInfo().getOutletId());
                bbOrderDetails.setMasterAgentId(request.getCartInfo().getMasterAgentId());
            }

            //prepaid to postpaid migration flow
            if (null != request.getData() && request.getCartInfo().isPrepaidToPostpaidMigration() && !StringUtilities.isEmptyOrNull(request.getData().getPrepaidMtn())) {
                cartInfo.setPrepaidToPostpaidMigration(true);
                PrepaidToPostpaidMigrationInfo prepaidToPostpaidMigrationInfo = new PrepaidToPostpaidMigrationInfo();
                prepaidToPostpaidMigrationInfo.setNewPreToPostIndicator(CartConstants.PREPAID_TO_POSTPAID_INDICATOR_BPM);
                NewPreToPostMtns newPreToPostMtns = NewPreToPostMtns.builder().accountMembers(new ArrayList<String>()).accountOwner(request.getData().getPrepaidMtn()).build();
                prepaidToPostpaidMigrationInfo.setNewPreToPostMtns(newPreToPostMtns);
                context.setNewPreToPostInfo(prepaidToPostpaidMigrationInfo);
            }


            if (request.getCartInfo().getTotalDeviceDollar() != null)
                cartInfo.setTotalDeviceDollar(request.getCartInfo().getTotalDeviceDollar());
            if (null != request.getData() && request.getData().getTotalDeviceDollar() != null)
                cartInfo.setTotalDeviceDollar(request.getData().getTotalDeviceDollar());
        setItemTypeAndIntendType(cartInfo, request);
        if (CollectionUtilities.isNotEmptyOrNull(request.getCartInfo().getBarCodeIds())) {

                cartInfo.setBarCodeIds(request.getCartInfo().getBarCodeIds());
            }
            if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getZipCode())) {
                cartInfo.setZipCode(request.getCartInfo().getZipCode());

            }

            if (request.getCartInfo().getIsQuoteCart() != null) {
                cartInfo.setIsQuoteCart(request.getCartInfo().getIsQuoteCart());
            }

            if (request.getCartInfo().getIsComboOrderAllowed() != null) {
                cartInfo.setIsComboOrderAllowed(request.getCartInfo().getIsComboOrderAllowed());
            }

            if (request.getCartInfo().getValidateDevicePlanCompatible() != null) {
                cartInfo.setValidateDevicePlanCompatible(request.getCartInfo().getValidateDevicePlanCompatible());
            }

            //VZWYN-22202 Changes Start
            if (CartConstants.VZW_BBP.equalsIgnoreCase(request.getCartInfo().getClientAppName()) && null != request.getCartInfo().getIsConnectedCarRequired()) {
                cartInfo.setIsConnectedCarRequired(request.getCartInfo().getIsConnectedCarRequired());
            }
        setProcessingStep(request, contextInfo);
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessAction()))
                contextInfo.setProcessAction(request.getCartInfo().getProcessAction());
            else
                contextInfo.setProcessAction(CartConstants.ADD_DEVICE);

    }

    private static void setItemTypeAndIntendType(CartServiceCartInfo cartInfo, AddDeviceUIRequest request) {
        if (request.getCartInfo().getItemType() != null)
            cartInfo.setItemType(request.getCartInfo().getItemType());
        else
            cartInfo.setItemType(CartConstants.DEVICE_TYPE);
        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType()))
            cartInfo.setIntendType(request.getCartInfo().getIntendType());
        else
            cartInfo.setIntendType(CartConstants.EUP);

        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                && CartConstants.DEO.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
            cartInfo.setItemType(CartConstants.DEVICEACC);
        }
    }

    private static void setProcessingStep(AddDeviceUIRequest request, CartServiceContextInfo contextInfo) {
        //VZWYN-22202 Changes End
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessStep()))
            contextInfo.setProcessStep(request.getCartInfo().getProcessStep());
        else if (CartConstants.VZW_BBP.equalsIgnoreCase(request.getCartInfo().getClientAppName()))
            contextInfo.setProcessStep("");
            //CLNR ADD-DEVICE FLOW
        else if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                && CartConstants.CLNR_FLOW.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
            contextInfo.setProcessStep("CLNREdit");
            logger.info("Add-Device ProcessStep set for CLNR flow: {}", contextInfo.getProcessStep());
            contextInfo.setProcessAction(CartConstants.CLNR_ADD_DEVICE);
            logger.info("Add-Device ProcessAction set for CLNR flow: {}", contextInfo.getProcessAction());
        } else
            contextInfo.setProcessStep("GridWallPDP");
    }

    private static void setCustomerInfo(AddDeviceUIRequest request, CartServiceCustomerInfo customerInfo) {
        setAmNextGenEnabled(request, customerInfo);
        customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
        customerInfo.setDeviceType(request.getCartInfo().getDeviceType());
        customerInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());
        customerInfo.setAmRole(request.getCartInfo().getAmRole());
        customerInfo.setMyvPage(request.getCartInfo().isMyvPage());
        if (request.getCartInfo().getActivateSwitchFlow() != null)
            customerInfo.setActivateSwitchFlow(request.getCartInfo().getActivateSwitchFlow());
        if (request.getCartInfo().getNumberShareCapable() != null)
            customerInfo.setNumberShareCapable(request.getCartInfo().getNumberShareCapable());
        setEnineAddrIndicator(request, customerInfo);
        if (request.getCartInfo().getTwoYearUpgrade() != null)
            customerInfo.setTwoYearUpgrade(request.getCartInfo().getTwoYearUpgrade());
        if (request.getCartInfo().getMtnFlow() != null)
            customerInfo.setMtnFlow(request.getCartInfo().getMtnFlow());
        if (request.getCartInfo().getSpecialItemType() != null)
            customerInfo.setSpecialItemType(request.getCartInfo().getSpecialItemType());
        if (request.getCartInfo().getEditDeviceConfiguratorClick() != null)
            customerInfo.setEditDeviceConfiguratorClick(request.getCartInfo().getEditDeviceConfiguratorClick());
        if (request.getCartInfo().getShowICPage() != null)
            customerInfo.setShowICPage(request.getCartInfo().getShowICPage());
        if (request.getCartInfo().getEditDevice() != null)
            customerInfo.setEditDevice(request.getCartInfo().getEditDevice());
        if (request.getCartInfo().getIsSmartLocator() != null)
            customerInfo.setIsSmartLocator(request.getCartInfo().getIsSmartLocator());
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getBuyOutFlag()))
            customerInfo.setBuyOutFlag(request.getCartInfo().getBuyOutFlag());
        if (request.getCartInfo().getIsGemini() != null)
            customerInfo.setIsGemini(request.getCartInfo().getIsGemini());
        if (request.getCartInfo().getIsTradeInSelected() != null)
            customerInfo.setIsTradeInSelected(request.getCartInfo().getIsTradeInSelected());
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getSalesRepId()))
            customerInfo.setCartCreatorSalesRepId(request.getCartInfo().getSalesRepId());
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getFlowType()))
            customerInfo.setFlowType(request.getCartInfo().getFlowType());
        if (request.getCartInfo().getReplaceDevice() != null)
            customerInfo.setReplaceDevice(request.getCartInfo().getReplaceDevice());
        setProductIdAndCategoryName(request, customerInfo);
        if (request.getCartInfo().getEditFromPage() != null)
            customerInfo.setEditFromPage(request.getCartInfo().getEditFromPage());
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getRedemptionCode()))
            customerInfo.setRedemptionCode(request.getCartInfo().getRedemptionCode());

        setIsPromoPDP(request, customerInfo);
        setNoPendingOfferExists(request, customerInfo);
    }

    private static void setIsPromoPDP(AddDeviceUIRequest request, CartServiceCustomerInfo customerInfo) {
        if (request.getCartInfo().getIsPromoPDP() != null && request.getCartInfo().getIsPromoPDP()) {
            customerInfo.setIsPromoPDP(true);
        } else {
            customerInfo.setIsPromoPDP(false);
        }
    }

    private static void setAmNextGenEnabled(AddDeviceUIRequest request, CartServiceCustomerInfo customerInfo) {
        if (CartConstants.ACCOUNT_MEMBER_ROLES.contains(request.getCartInfo().getAmRole())) {
            if (null != request.getCartInfo().getIsLineLevelPlanAccount())
                customerInfo.setIsLineLevelPlanAccount(request.getCartInfo().getIsLineLevelPlanAccount());
            customerInfo.setAmNextGenEnabled(request.getCartInfo().getAmNextGenEnabled());
        }
    }

    private static void setEnineAddrIndicator(AddDeviceUIRequest request, CartServiceCustomerInfo customerInfo) {
        if (request.getCartInfo().getENineAddrIndicator() != null)
            customerInfo.setENineAddrIndicator(request.getCartInfo().getENineAddrIndicator());
        else
            customerInfo.setENineAddrIndicator(CartConstants.FALSE);
    }

    private static void setProductIdAndCategoryName(AddDeviceUIRequest request, CartServiceCustomerInfo customerInfo) {
        if (null != request.getData() && null != request.getData().getLines().get(0).getDevice()) {
            if (request.getData().getLines().get(0).getDevice().getProductId() != null)
                customerInfo.setProductId(request.getData().getLines().get(0).getDevice().getProductId());
            if (request.getData().getLines().get(0).getDevice().getCategory() != null)
                customerInfo.setCategoryName(request.getData().getLines().get(0).getDevice().getCategory());
        }
    }

    private static void setNoPendingOfferExists(AddDeviceUIRequest request, CartServiceCustomerInfo customerInfo) {
        if (request.getCartInfo().getNoPendingOfferExists() != null && request.getCartInfo().getNoPendingOfferExists()) {
            customerInfo.setNoPendingOfferExists(true);
        } else {
            customerInfo.setNoPendingOfferExists(false);
        }
    }

    private static boolean isAiQuote(DeviceCartInfo cartInfo) {
        return StringUtilities.isNotEmptyOrNull(cartInfo.getMtnFlow()) && cartInfo.getMtnFlow().equalsIgnoreCase(AI_QUOTE);
    }

    public static String isBauByodFlow(AddDeviceUIRequest request) {
        // setting a flag for CJCM to identify if the add-device request of from BAU BYOD flow
        if(StringUtilities.isNotEmptyOrNull(request.getChannelId()) &&
            CartConstants.DIGITAL_CLIENT_APP.contains(request.getChannelId())) {
            if (request.getData() != null && StringUtilities.isNotEmptyOrNull(request.getData().getSubFlow()) &&
                    request.getData().getSubFlow().contains(CartConstants.NXT_GEN_BYOD_BAU))
                return Boolean.TRUE.toString();
            else
                return Boolean.FALSE.toString();
        }
        return null;
    }

    /**
     * Method to all quick shop pega request flags*
     * @param request
     * @param cartInfo
     */
    public static void addQuickShopPegaRequestFlag(AddDeviceUIRequest request, CartServiceCartInfo cartInfo) {
        if(CartUtil.isDigital(request.getChannelId()) && CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())
                && null != request.getCartInfo().getQuickShop()) {
            cartInfo.setIsQuickShopFlow(request.getCartInfo().getQuickShop());
            if(null != request.getCartInfo().getQuickShopTradeIn()) {
                cartInfo.setQuickShopTradeIn(request.getCartInfo().getQuickShopTradeIn());
            }
            if(null != request.getCartInfo().getEditDevice() && request.getCartInfo().getEditDevice()){
                if(null != request.getCartInfo().getEditFromBYOPlan() && request.getCartInfo().getEditFromBYOPlan()) {
                    cartInfo.setEditFromBYOPlan(request.getCartInfo().getEditFromBYOPlan());
                }
                if(null != request.getCartInfo().getEditFromBYOPerk() && request.getCartInfo().getEditFromBYOPerk()) {
                    cartInfo.setEditFromBYOPerk(request.getCartInfo().getEditFromBYOPerk());
                }
            }
        }
    }

    /**
     * Method to set the address info to the pega request for NSE customer
     *
     * @param request
     * @param cartInfo
     */
    private static void setAddressInfo(AddDeviceUIRequest request, CartServiceCartInfo cartInfo) {
        if (request.getCartInfo() !=null && (CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())
                || CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType()))) {

            Address address = new Address();

            if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getZipCode())) {
                address.setZipCode(request.getCartInfo().getZipCode());
            }
            if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getState())) {
                address.setState(request.getCartInfo().getState());
            }
            if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getAddressLine1())) {
                address.setAddressLine1(request.getCartInfo().getAddressLine1());
            }
            if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCity())) {
                address.setCity(request.getCartInfo().getCity());
            }

            if (cartInfo.getLines() !=null && cartInfo.getLines().length > 0 && CartCxpRequestUtil.validateEmptyAddress(address)) {
                cartInfo.getLines()[0].setAddress(address);
            }
        }
    }


    /**
     * @param pegaRequest
     * @param request
     * @return ServiceAddressPEGARequest
     */
    public static BillingAddressPEGARequest formatBillingAddressRequest(BillingAddressPEGARequest pegaRequest,
                                                                        BillingAddressUIRequest request) {

        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        serviceHeader = CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(request.getChannelId());
        pegaRequest.setServiceHeader(serviceHeader);

        BillingAddressServiceBody serviceBody = new BillingAddressServiceBody();
        BillingAddressServiceRequest serviceRequest = new BillingAddressServiceRequest();
        BillingAddressContext context = new BillingAddressContext();

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
        customerInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getDeviceType())) {
            customerInfo.setDeviceType(request.getCartInfo().getDeviceType());
        }

        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(request.getCartInfo().getCartId());
        cartInfo.setClientAppName(request.getCartInfo().getClientAppName());
        cartInfo.setAction(CartConstants.UPDATE);
        cartInfo.setItemType("BILLING-ADDRESS");
        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType()))
            cartInfo.setIntendType(request.getCartInfo().getIntendType());
        else
            cartInfo.setIntendType(CartConstants.AAL);

        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        contextInfo = CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.ADD_BILLING_ADDRESS,
                request.getCartInfo().getClientAppName());
        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessStep())) {
            contextInfo.setProcessStep(request.getCartInfo().getProcessStep());
        } else {
            contextInfo.setProcessStep(CartConstants.SHOPPING_CART);
        }
        if(CartConstants.CHANNEL_ID_BBP.equalsIgnoreCase(request.getCartInfo().getClientAppName())) {
            contextInfo.setIntent(CartConstants.BYOD);
        }

        List<Line> lines = new ArrayList<>();
        for (Lines reqLine : request.getData().getLines()) {
            Line newLine = new Line();
            newLine.setMtn(reqLine.getMtn());
            BillingAddress billingAddress = new BillingAddress();
            if(reqLine.getBillingAddress() != null)
                billingAddress = reqLine.getBillingAddress();

            Address uiAddress = new Address();
            if(billingAddress != null) {
                uiAddress = billingAddress.getAddress();
                Address address = new Address();
                address.setApartmentNo(uiAddress.getApartmentNo());
                address.setStreetNumber(uiAddress.getStreetNumber());
                address.setStreetName(uiAddress.getStreetName());
                address.setType(uiAddress.getType());
                address.setAddressLine2(uiAddress.getAddressLine2());
                address.setPoBoxNo(uiAddress.getPoBoxNo());
                address.setAddressLine1(uiAddress.getAddressLine1());
                address.setRuralDelNo(uiAddress.getRuralDelNo());
                address.setCity(uiAddress.getCity());
                address.setState(uiAddress.getState());
                address.setZipCode(uiAddress.getZipCode());
                address.setZipCode4(uiAddress.getZipCode4());
                address.setCountryCode(uiAddress.getCountryCode());
                address.setFipsCode(uiAddress.getFipsCode());
                address.setFirmName(uiAddress.getFirmName());
                address.setFirstName(uiAddress.getFirstName());
                address.setLastName(uiAddress.getLastName());
                address.setPhoneNumber(uiAddress.getPhoneNumber());
                address.setEmailId(uiAddress.getEmailId());
                address.setAttention(uiAddress.getAttention());
                billingAddress.setAddress(address);
            }
            newLine.setBillingAddress(billingAddress);
            newLine.setMtn(reqLine.getMtn());
            lines.add(newLine);
        }

        if (CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())
                || CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType()) || CartConstants.NSEACC.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
            CartPegaRequestUtil7.newCustomerOverride(contextInfo, customerInfo, request.getCartInfo(), request.getChannelId());
            contextInfo.setProcessAction(request.getCartInfo().getProcessAction());
            contextInfo.setCallReason(CartConstants.SALES_ORDER_PURCHASE);

        }

        //MVP2-GR
        if(request.getCartInfo()!=null && request.getCartInfo().getCaseId()!=null && request.getCartInfo().getCaseId().startsWith("SOF")){

            logger.info("SalesOrderFlex Prepay billing address Request before PEGA call setting Call Reason");
            contextInfo.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }

        context.setContextInfo(contextInfo);
        if (null != request.getCartInfo().getExpressCheckout() && request.getCartInfo().getExpressCheckout()) {
            customerInfo.setCradleFlowJourney(CartConstants.PROMO_HUB);
        }

        Line[] lineArr = new Line[lines.size()];
        lines.toArray(lineArr);

        cartInfo.setLines(lineArr);

        context.setCustomerInfo(customerInfo);
        context.setCartInfo(cartInfo);
        context.setCaseId(request.getCartInfo().getCaseId());

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);

        //GTSFN-9614 changes for NSE flow
        if (StringUtilities.isNotEmptyOrNull(cartInfo.getIntendType()) && cartInfo.getIntendType().contains("NSE")) {
            Address billingAddressNSE = new Address();
            if(!lines.isEmpty())
                billingAddressNSE = lines.get(0).getBillingAddress().getAddress();
            if(pegaRequest.getServiceBody().getServiceRequest().getContext().getCartInfo() != null) {
                pegaRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().setBillingAddress(billingAddressNSE);
                pegaRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().setLines(null);
            }
            logger.info("NSE-BillingAddress PEGA Request is :{}",pegaRequest);
        }
        return pegaRequest;
    }

    /**
     * @param pegaRequest
     * @param request
     * @return E911AddressPEGARequest
     */
    public static E911AddressPEGARequest formatE911AddressRequest(E911AddressPEGARequest pegaRequest,
                                                                  E911AddressUIRequest request) {
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        serviceHeader = CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(request.getChannelId());
        pegaRequest.setServiceHeader(serviceHeader);

        E911AddressServiceBody serviceBody = new E911AddressServiceBody();
        E911AddressServiceRequest serviceRequest = new E911AddressServiceRequest();
        E911AddressContext context = new E911AddressContext();

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
        customerInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());

        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(request.getCartInfo().getCartId());
        cartInfo.setClientAppName(request.getCartInfo().getClientAppName());
        cartInfo.setAction(CartConstants.UPDATE);
        cartInfo.setItemType("E911ADDRESS");
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getClientAppName())
                && CartConstants.CHANNEL_ID_NUMBERLINK.equalsIgnoreCase(request.getCartInfo().getClientAppName())) {
            serviceHeader.setServiceName(CartConstants.SERVICE_NAME_NUMBERLINK);
        }
        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType()))
            cartInfo.setIntendType(request.getCartInfo().getIntendType());
        else
            cartInfo.setIntendType(CartConstants.AAL);

        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        contextInfo = CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.ADD_E911_ADDRESS,
                request.getCartInfo().getClientAppName());
        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessStep())) {
            contextInfo.setProcessStep(request.getCartInfo().getProcessStep());
        } else {
            contextInfo.setProcessStep(CartConstants.SHOPPING_CART);
        }
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())) {
            contextInfo.setIntent(request.getCartInfo().getIntendType());
        }
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getRpsIntent())) {
            contextInfo.setIntent(request.getCartInfo().getRpsIntent());
        }
        if(CartConstants.EUP.equalsIgnoreCase(contextInfo.getIntent())) {
            contextInfo.setIntent(CartConstants.UPGRADE);
        }
        List<Line> lines = new ArrayList<>();
        for (Lines reqLine : request.getData().getLines()) {
            Line newLine = new Line();
            newLine.setMtn(reqLine.getMtn());
            ServiceAddress serviceAddress = new ServiceAddress();
            Boolean e911AddressSharingOptin = reqLine.getE911Address().getE911AddressSharingOptIn();
            Address uiAddress = reqLine.getE911Address().getAddress();
            Address address = new Address();
            address.setApartmentNo(uiAddress.getApartmentNo());
            address.setStreetNumber(uiAddress.getStreetNumber());
            address.setStreetName(uiAddress.getStreetName());
            address.setType(uiAddress.getType());
            address.setAddressLine2(uiAddress.getAddressLine2());
            address.setAddressLine1(uiAddress.getAddressLine1());
            address.setPoBoxNo(uiAddress.getPoBoxNo());
            address.setRuralDelNo(uiAddress.getRuralDelNo());
            address.setCity(uiAddress.getCity());
            address.setState(uiAddress.getState());
            address.setZipCode(uiAddress.getZipCode());
            address.setZipCode4(uiAddress.getZipCode4());
            address.setCountryCode(uiAddress.getCountryCode());
            address.setFipsCode(uiAddress.getFipsCode());
            address.setFirmName(uiAddress.getFirmName());
            address.setFirstName(uiAddress.getFirstName());
            address.setLastName(uiAddress.getLastName());
            address.setPhoneNumber(uiAddress.getPhoneNumber());
            address.setEmailId(uiAddress.getEmailId());
            address.setAttention(uiAddress.getAttention());
            address.setCounty(uiAddress.getCounty());
            serviceAddress.setAddress(address);
            if (serviceAddress != null) {
                newLine.setE911Address(reqLine.getE911Address());
            }
            lines.add(newLine);
            if(request.getCartInfo()!=null && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getClientAppName()) && e911AddressSharingOptin!=null) {
                if(request.getCartInfo().getClientAppName().equalsIgnoreCase(CartConstants.CHANNEL_ID_NUMBERLINK)) {
                    contextInfo.setProcessAction(CartConstants.ORDERSUBMIT);
                }

            }
        }
        Line[] lineArr = new Line[lines.size()];
        lines.toArray(lineArr);
        cartInfo.setLines(lineArr);
        if (CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())
                || CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
            CartPegaRequestUtil7.newCustomerOverride(contextInfo, customerInfo, request.getCartInfo(), request.getChannelId());
        }

        if (request.getCartInfo() != null) {
            if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getClientAppName())
                    && CartConstants.CHANNEL_ID_NUMBERLINK.equalsIgnoreCase(request.getCartInfo().getClientAppName())) {
                if(request.getCartInfo().getIntent()!=null){
                    contextInfo.setIntent(request.getCartInfo().getIntent());
                }
                else{
                    contextInfo.setIntent("NLA");
                }
                contextInfo.setCallReason("Features");
            }
        }
        //MVP2-GR
        if(request.getCartInfo()!=null && request.getCartInfo().getCaseId()!=null && request.getCartInfo().getCaseId().startsWith("SOF")){

            logger.info("SalesOrderFlex Prepay e911 Request before PEGA call setting Call Reason");
            contextInfo.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }
        context.setContextInfo(contextInfo);
        context.setCustomerInfo(customerInfo);
        context.setCartInfo(cartInfo);
        context.setCaseId(request.getCartInfo().getCaseId());
        //MVP2
        if(request.getCartInfo()!=null &&
                ((request.getCartInfo().getIsPrepayCart()!=null && "Y".equalsIgnoreCase(request.getCartInfo().getIsPrepayCart())) ||
                        (request.getCartInfo().getCaseId()!=null && request.getCartInfo().getCaseId().startsWith("SOF")))){

            logger.info("SalesOrderFlex Prepay formatE911Address before PEGA call setting Call Reason");
            contextInfo.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }
        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);
        return pegaRequest;
    }

    /**
     * @param pegaRequest
     * @param request
     * @return InstantCreditDownPaymentPEGARequest
     */
    public static InstantCreditDownPaymentPEGARequest formatInstantCreditDownPaymenRequest(
            InstantCreditDownPaymentPEGARequest pegaRequest, InstantCreditDownPaymentUIRequest request) {
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(request.getChannelId());
        pegaRequest.setServiceHeader(serviceHeader);

        InstantCreditDownPaymentServiceBody serviceBody = new InstantCreditDownPaymentServiceBody();
        InstantCreditDownPaymentServiceRequest serviceRequest = new InstantCreditDownPaymentServiceRequest();
        InstantCreditDownPaymentContext context = new InstantCreditDownPaymentContext();

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
        customerInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());
        if (null != request.getCartInfo().getMultitrade())
            customerInfo.setMultitrade(request.getCartInfo().getMultitrade());
        context.setCustomerInfo(customerInfo);

        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getCradleFlowJourney())) {
            customerInfo.setCradleFlowJourney(request.getCartInfo().getCradleFlowJourney());
        }
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(request.getCartInfo().getCartId());
        cartInfo.setClientAppName(request.getCartInfo().getClientAppName());
        cartInfo.setAction(CartConstants.UPDATE);
        cartInfo.setItemType("INSTANTCREDITDOWNPAYMENT");
        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType()))
            cartInfo.setIntendType(request.getCartInfo().getIntendType());
        else
            cartInfo.setIntendType(CartConstants.EUP);

        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.ADD_IC_DOWNPAYMENT,
                request.getCartInfo().getClientAppName());
        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessStep())) {
            contextInfo.setProcessStep(request.getCartInfo().getProcessStep());
        } else {
            contextInfo.setProcessStep(CartConstants.SHOPPING_CART);
        }
        context.setContextInfo(contextInfo);
        List<Line> lines = new ArrayList<>();
        for (Lines reqLine : request.getData().getLines()) {
            Line newLine = new Line();
            if (null != reqLine.getMtn()) {
                newLine.setMtn(reqLine.getMtn());
            }
            if (reqLine.getInstantcredit() != null)
                newLine.setInstantcredit(reqLine.getInstantcredit());

            lines.add(newLine);
        }
        Line[] lineArr = new Line[lines.size()];
        lines.toArray(lineArr);
        cartInfo.setLines(lineArr);
        context.setCartInfo(cartInfo);
        context.setCaseId(request.getCartInfo().getCaseId());
        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);
        return pegaRequest;
    }
      public static AddZipcodePEGARequest formatAddZipcodeRequest(AddZipcodePEGARequest pegaRequest,
                                                                  AddZipCodeUIRequest request) {

          CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
          serviceHeader = CartPegaRequestUtil.addServiceHeader(serviceHeader);
          serviceHeader.setClientId(request.getChannelId());
          pegaRequest.setServiceHeader(serviceHeader);
          AddZipcodeServiceBody serviceBody = new AddZipcodeServiceBody();
          AddZipcodeServiceRequest serviceRequest = new AddZipcodeServiceRequest();
          AddZipcodeContext context = new AddZipcodeContext();
          CartServiceCartInfo cartInfo = new CartServiceCartInfo();

          CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
          if (request.getCartInfo() != null) {
              if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessingMTN())) {
                  customerInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());
              }
              if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCartCreator())) {
                  customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
              }
              if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getGlobalId())) {
                  customerInfo.setGlobalId(request.getCartInfo().getGlobalId());
              }
              if (StringUtilities.isNotEmptyOrNull(request.getChannelId())) {
                  cartInfo.setClientAppName(request.getChannelId());
              }
              if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getSessionId())) {
                  if (StringUtilities.isEmptyOrNull(request.getCartInfo().getGlobalId()))
                      customerInfo.setGlobalId(request.getCartInfo().getSessionId());
                  if (StringUtilities.isEmptyOrNull(request.getCartInfo().getCartCreator()))
                      customerInfo.setCartCreator(request.getCartInfo().getSessionId());
              }
              if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCustomerType()) || (request.getCartInfo().getIntendType().toUpperCase().contains(CartConstants.NSE_BYOD)))
                  customerInfo.setCustomerType(CartConstants.NEW_CUSTOMER);
              else
                  customerInfo.setCustomerType("");
              if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType()))
                  cartInfo.setIntendType(request.getCartInfo().getIntendType());

              if (request.getCartId() != null)
                  cartInfo.setCartId(request.getCartId());
              else
                  cartInfo.setCartId(request.getCartInfo().getCartId());
              cartInfo.setAction(CartConstants.UPDATE);
              cartInfo.setItemType(CartConstants.USERCONTACTINFO);

              if (request.getZipCode() != null)
                  cartInfo.setZipCode(request.getZipCode());
              else
                  cartInfo.setZipCode(request.getCartInfo().getZipCode());
          }
          CartServiceContextInfo contextInfo = new CartServiceContextInfo();
          contextInfo = CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.ADD_ZIPCODE,
                  request.getChannelId());

          contextInfo.setProcessStep(CartConstants.LOCATION_DETAILS);
          if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType()))
              contextInfo.setIntent(request.getCartInfo().getIntendType());
          else
              contextInfo.setIntent(CartConstants.BYOD);

          if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getCaseId()))
              context.setCaseId(request.getCartInfo().getCaseId());
          contextInfo.setProcessAction(CartConstants.ADD_ZIPCODE);
          contextInfo.setCallReason(CartConstants.SALES_ORDER_PURCHASE);
          if (request.getCartInfo().getIntendType().toUpperCase().equalsIgnoreCase(CartConstants.NSE_BYOD) ||
                  CartConstants.NEW_CUSTOMER.equalsIgnoreCase(request.getCartInfo().getCustomerType())) {
              CartPegaRequestUtil7.newCustomerOverride(contextInfo, customerInfo, request.getCartInfo(), request.getChannelId());
              // set the address for nse customer
              setAddressInfo(request, cartInfo);
          }
          context.setCustomerInfo(customerInfo);
          context.setCartInfo(cartInfo);
          context.setContextInfo(contextInfo);

          serviceRequest.setContext(context);
          serviceBody.setServiceRequest(serviceRequest);
          pegaRequest.setServiceBody(serviceBody);
          return pegaRequest;

      }
      
      /**
       * Method to set the address info to the pega request for NSE customer
       *
       * @param request
       * @param cartInfo
       */
		private static void setAddressInfo(AddZipCodeUIRequest request, CartServiceCartInfo cartInfo) {
			if (request.isEnableFcc()) {
				Address address = new Address();

				if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getAddressLine1())) {
					address.setAddressLine1(request.getCartInfo().getAddressLine1());
				}
                if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getZipCode())) {
                    address.setZipCode(request.getCartInfo().getZipCode());
                }
				if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getState())) {
					address.setState(request.getCartInfo().getState());
				}
				if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCity())) {
					address.setCity(request.getCartInfo().getCity());
				}

				if (cartInfo.getLines() == null && CartCxpRequestUtil.validateEmptyAddress(address)) {
					Line line = new Line();
					line.setAddress(address);
					cartInfo.setLines(new Line[] { line });
				}
			}
		}

    public static void formatDfoToDppCartRequest(AddDevicePEGARequest pegaRequest, AddDeviceUIRequest uiRequest) {
        CartPegaRequestUtil4.formatAddDeviceRequest(pegaRequest, uiRequest, null, false,false, false, null);
        if (null != uiRequest && null != uiRequest.getCartInfo() &&
                null != pegaRequest && null != pegaRequest.getServiceBody()
                && null != pegaRequest.getServiceBody().getServiceRequest()
                && null != pegaRequest.getServiceBody().getServiceRequest().getContext()
                && null != pegaRequest.getServiceBody().getServiceRequest().getContext().getCartInfo()) {
            if (null != uiRequest.getCartInfo().getItemType()) {
                pegaRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().setItemType(uiRequest.getCartInfo().getItemType());
            }
            if (null != uiRequest.getCartInfo().getVzccStatus()) {
                pegaRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().setVzccStatus(uiRequest.getCartInfo().getVzccStatus());
            }

        }
    }
    public static void addByodMtnToAddDevicePegaReq(String intendType, CartServiceCartInfo cartInfo, String byodMtn,
                                                    Boolean isDeviceFirstEnableForProspectBYODFFlag, Boolean isDeviceFirstEnableForExistingBYODFFlag){
        if((CartConstants.NSE_BYOD.equalsIgnoreCase(intendType)
                && Boolean.TRUE.equals(isDeviceFirstEnableForProspectBYODFFlag))
                || (CartConstants.BYOD.equalsIgnoreCase(intendType)
                && Boolean.TRUE.equals(isDeviceFirstEnableForExistingBYODFFlag))){
            cartInfo.setByodMtn(byodMtn);
        }
    }
}
