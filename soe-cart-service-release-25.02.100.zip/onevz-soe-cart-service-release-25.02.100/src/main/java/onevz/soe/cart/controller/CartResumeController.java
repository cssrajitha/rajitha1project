package onevz.soe.cart.controller;

import jakarta.annotation.PostConstruct;
import onevz.soe.cart.ui.responses.ClearAndContinueUIResponse;
import onevz.soe.cart.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.helper.ResumeCartHelper;
import onevz.soe.cart.model.clearAndContinue.ClearAndContinueContext;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.ui.requests.ClearAndContinueUIRequest;
import onevz.soe.utilities.StringUtilities;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static onevz.soe.cart.constants.CartConstants.EXISTING_CART_COUNT;

@RestController
public class CartResumeController {
    private static final Logger logger = LoggerFactory.getLogger(CartUpdateOperationsController.class);

    @Autowired
    private ResumeCartHelper helper;

    @Autowired
    private RedisHelper redisHelper;
    
    @Autowired
	private CommonUtil util;

    @Autowired
    private CartUpdateOperationsController cartUpdateOperationsController;
    @Value("#{'${sessionCreation.domains:.verizon.com}'.split(',')}")
    private List<String> domains;

    public Mono<ResponseEntity<GenericResponse>> clearAndResume(ServerHttpRequest httpHeader,
                                                                  ServerHttpResponse httpResponse, @RequestBody ClearAndContinueUIRequest clearAndContinueUIRequest) {
        System.setProperty(CartConstants.ENDPOINT, "clearAndResume");
        logger.debug("clear and resume Request: {}", clearAndContinueUIRequest);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        clearAndContinueUIRequest.setChannelId(channelId);
        return helper.clearAndResume(clearAndContinueUIRequest).flatMap(clearAndResumeResponse -> {
            ErrorResponse errors2 = null;
            if (clearAndResumeResponse.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil.handleClearAndContinueResponseErrors(clearAndResumeResponse);
                return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(errors2));
            } else {
                CartRedisData rr = new CartRedisData();
                ClearAndContinueContext context = new ClearAndContinueContext();
                CartAddDeviceUtil.createCookieCartCountClearAndContinue(httpResponse, clearAndResumeResponse, EXISTING_CART_COUNT, domains);
                if (null != clearAndResumeResponse.getServiceBody()
                        && null != clearAndResumeResponse.getServiceBody().getServiceResponse()
                        && null != clearAndResumeResponse.getServiceBody().getServiceResponse().getContext())
                    context = clearAndResumeResponse.getServiceBody().getServiceResponse().getContext();
                rr = util.formatCartRedisData(rr, context);
                return cartUpdateOperationsController.callToUpdateCartIdAndCaseIdIntoRedis(httpResponse, rr, clearAndContinueUIRequest.getCartInfo(),clearAndResumeResponse, true);
            }
        });
    }
}
