package onevz.soe.cart.helper;

import onevz.soe.cart.responses.CartRedisData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import onevz.soe.cart.bpm.helper.CartServiceBpmHelper3;
import onevz.soe.cart.ui.requests.ClearAndContinueUIRequest;
import onevz.soe.cart.ui.responses.ClearAndContinueUIResponse;
import onevz.soe.cart.util.CommonUtil;
import onevz.soe.utilities.StringUtilities;
import reactor.core.publisher.Mono;

import java.util.Optional;

@Service
public class ResumeCartHelper {

    @Autowired
    private RedisHelper redisHelper;

    @Autowired
    private CartServiceBpmHelper3 bpmHelper;
    
    @Autowired
    private CommonUtil util;

    public Mono<ClearAndContinueUIResponse> clearAndResume(ClearAndContinueUIRequest request) {
        return redisHelper.getDataFromRedis().flatMap(data -> {
            Optional.of(data).map(CartRedisData::getUniversalId).filter(StringUtilities::isNotEmptyOrNull).ifPresent(request::setUniversalId);
            if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
                request.getCartInfo().setAccountNumber(data.getAccountNumber());
            if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
                request.getCartInfo().setCartId(data.getCartId());
            //clearAndContinue standalone accessory NSEACC implementation
            if (StringUtilities.isNotEmptyOrNull(data.getProspectCartId()))
                request.getCartInfo().setProspectCartId(data.getProspectCartId());
            //clearAndContinue standalone accessory NSEACC implementation
            util.formatClearAndContinueRequest(request, data);
            if (StringUtilities.isNotEmptyOrNull(data.getIntendType()))
                request.getCartInfo().setIntendType(data.getIntendType());
            if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
                request.getCartInfo().setCartId(data.getCartId());

            return bpmHelper.clearAndResume(request).flatMap(cscResp -> {
            	return util.formatClearAndContinueUIResponse(cscResp);
            });

        });

    }

}
