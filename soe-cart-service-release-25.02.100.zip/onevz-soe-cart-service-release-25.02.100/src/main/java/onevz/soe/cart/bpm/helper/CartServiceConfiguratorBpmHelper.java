package onevz.soe.cart.bpm.helper;

import onevz.soe.cart.bpm.service.CartServiceBPMServices;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.controller.advice.CartServiceExceptionHandler;
import onevz.soe.cart.helper.FeatureFlagHelper;
import onevz.soe.cart.helper.RedisHelper2;
import onevz.soe.cart.requests.AddAllConfiguratorPEGARequest;
import onevz.soe.cart.responses.AddAllConfiguratorPEGAResponse;
import onevz.soe.cart.ui.requests.AddAllConfiguratorUIRequest;
import onevz.soe.cart.ui.responses.AddAllConfiguratorUIResponse;
import onevz.soe.cart.util.CartConfiguratorPegaRequestUtil;
import onevz.soe.cart.util.CartConfiguratorPegaResponseUtil;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
public class CartServiceConfiguratorBpmHelper {
    private static final Logger logger = LoggerFactory.getLogger(CartServiceConfiguratorBpmHelper.class);
    @Autowired
    private CartServiceExceptionHandler exHandler;
    @Autowired
    private CartServiceBPMServices services;
    @Autowired
    private RedisHelper2 redisHelper2;
    @Autowired
    private FeatureFlagHelper featureFlagHelper;

    /**
     * @param uiRequest
     * @return uiResponse
     */
    public Mono<AddAllConfiguratorUIResponse> addAllCartConfigurator(AddAllConfiguratorUIRequest uiRequest) {

        AddAllConfiguratorPEGARequest request = new AddAllConfiguratorPEGARequest();

        // convert uiRequest to pega request

        boolean ngdTradeInEnabled = featureFlagHelper.isNgdTradeInBulkUpdateEnabled();
        logger.info("ngdTradeInEnabled {} ", ngdTradeInEnabled);
        CartConfiguratorPegaRequestUtil.formatAddConfiguratorRequest(request, uiRequest, ngdTradeInEnabled);

        Mono<String> loggedInUser = redisHelper2.getLoggedInUser();
        return loggedInUser.flatMap(data -> {
            if (StringUtilities.isNotEmptyOrNull(data)) request.getServiceHeader().setUserId(data);
            Mono<AddAllConfiguratorPEGAResponse> responseServiceMono = null;
            try {
                // pega call addAllConfigurator
                responseServiceMono = services.addAllConfigurator(request);
            } catch (SOEHTTPException e) {
                logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
            }
            AddAllConfiguratorUIResponse soeResponse = new AddAllConfiguratorUIResponse();
            return responseServiceMono == null ? Mono.just(soeResponse) : responseServiceMono.flatMap(pegaResponse -> {
                // convert pega response to ui response
                CartConfiguratorPegaResponseUtil.formatAddAllConfiguratorResponse(soeResponse, pegaResponse);
                return Mono.just(soeResponse);
            });
        });

    }


}
