package onevz.soe.cart.util;

import onevz.soe.cart.initiatecart.InitiateCartUIResponse;
import onevz.soe.cart.model.addTrialContactInfoAndAddress.AddTrialContactInfoAndAddressUIResponse;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.common.CartErrorDetail;
import onevz.soe.cart.model.initiateValidateDeviceSim.InitiateValidateDeviceSimUIResponse;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.ui.requests.UpdateGiftItemUIResponse;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.exception.ErrorDetail;
import onevz.soe.exception.SOEError;
import onevz.soe.exception.SOEErrorHolder;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CartPegaResponseErrorsUtil2 {


    /**
     *
     * @param response
     * @return ErrorResponse
     */
    public static ErrorResponse handleAccountPinResponseErrors(AccountPinUIResponse response) {

        ErrorResponse errors = null;
        List<CartError> errorList = new ArrayList<>();
        if (response.getErrors() != null) {
            errors = new ErrorResponse();

            for (CartError cxpError : response.getErrors()) {
                CartError error = cxpError;
                errorList.add(error);
            }
            errors.setErrors(errorList);
        }
        return errors == null ? new ErrorResponse() : errors;
    }

    /**
     *
     * @param response
     * @return errorResponse
     */
    public static ErrorResponse handlebbpGetProcessStepErrors(BbpGetProcessStepUIResponse response) {

        ErrorResponse errors = null;
        List<CartError> errorList = new ArrayList<>();
        if (response.getErrors() != null) {
            errors = new ErrorResponse();

            for (CartError cxpError : response.getErrors()) {
                CartError error = cxpError;
                errorList.add(error);
            }
            errors.setErrors(errorList);
        }
        return errors == null ? new ErrorResponse() : errors;
    }

    /**
     *
     * @param response
     * @return ErrorResponse
     */
    public static ErrorResponse handleRemoveLockResponseErrors(RemoveLockUIResponse response) {

        ErrorResponse errors = null;
        List<CartError> errorList = new ArrayList<>();
        if (response.getErrors() != null) {
            errors = new ErrorResponse();

            for (CartError cxpError : response.getErrors()) {
                CartError error = cxpError;
                errorList.add(error);
            }
            errors.setErrors(errorList);
        }
        return errors == null ? new ErrorResponse() : errors;
    }

    /**
     *
     * @param response
     * @return ErrorResponse
     */

    public static ErrorResponse handleRetrieveActivationStatusResponseErrors(
            RetrieveActivationStatusUIResponse response) {

        ErrorResponse errors = null;
        List<CartError> errorList = new ArrayList<>();
        if (response.getErrors() != null) {
            errors = new ErrorResponse();

            for (CartError cxpError : response.getErrors()) {
                CartError error = cxpError;
                errorList.add(error);
            }
            errors.setErrors(errorList);
        }
        return errors == null ? new ErrorResponse() : errors;
    }

    public static ErrorResponse addPlanAndDeviceResponseErrors(AddPlanAndDeviceUIResponse response) {

        ErrorResponse errors = null;
        List<CartError> errorList = new ArrayList<>();
        if (response.getErrors() != null) {
            errors = new ErrorResponse();

            for (CartError cxpError : response.getErrors()) {
                CartError error = cxpError;
                errorList.add(error);
            }
            errors.setErrors(errorList);
        }
        return errors == null ? new ErrorResponse() : errors;
    }

    /**
     *
     * @param response
     * @return
     */
    public static ErrorResponse handleAddDeviceResponseErrorsFiveGHome(AddPlanAndDeviceUIResponse response) {

        ErrorResponse errors = null;
        List<CartError> errorList = null;
        if (response.getErrors() != null && !response.getErrors().isEmpty()) {
            errors = new ErrorResponse();

            errorList = response.getErrors();
        }
        if (errorList != null)
            errors.setErrors(errorList);
        return errors == null ? new ErrorResponse() : errors;
    }

    public static ErrorResponse handleInititeCart(InitiateCartUIResponse response) {

        ErrorResponse errors = null;
        List<CartError> errorList = null;
        if (response.getErrors() != null && !response.getErrors().isEmpty()) {
            errors = new ErrorResponse();

            errorList = response.getErrors();
        }
        if (errorList != null)
            errors.setErrors(errorList);
        return errors == null ? new ErrorResponse() : errors;
    }

    public static AddPlanAndDeviceUIResponse handleCommonErrorFiveGFlow(SOEErrorHolder soeError) {

        AddPlanAndDeviceUIResponse errors = null;
        List<CartError> errorList = new ArrayList<>();
        if (null != soeError) {
            errors = new AddPlanAndDeviceUIResponse();
            formatErrorList(soeError, errorList);
            errors.setErrors(errorList);
        }
        return errors == null ? new AddPlanAndDeviceUIResponse() : errors;
    }

    public static ErrorResponse handleManualDiscountResponseErrors(UpdateManualDiscountUIResponse response) {

        ErrorResponse errors = null;
        List<CartError> errorList = new ArrayList<>();
        if (response.getErrors() != null) {
            errors = new ErrorResponse();

            for (CartError cxpError : response.getErrors()) {
                CartError error = cxpError;
                errorList.add(error);
            }
            errors.setErrors(errorList);
        }
        return errors == null ? new ErrorResponse() : errors;
    }

    public static ErrorResponse handleEffectiveDateResponseErrors(UpdateEffectiveDateUIResponse response) {

        ErrorResponse errors = null;
        List<CartError> errorList = new ArrayList<>();
        if (response.getErrors() != null) {
            errors = new ErrorResponse();

            for (CartError cxpError : response.getErrors()) {
                CartError error = cxpError;
                errorList.add(error);
            }
            errors.setErrors(errorList);
        }
        return errors == null ? new ErrorResponse() : errors;
    }

    /**
     *
     * @param response
     * @return ErrorResponse
     */

    public static ErrorResponse handleGetPairedWatchesResponseErrors(
            GetPairedDevicesUIResponse response) {

        ErrorResponse errors = null;
        List<CartError> errorList = new ArrayList<>();
        if (response.getErrors() != null) {
            errors = new ErrorResponse();

            for (CartError cxpError : response.getErrors()) {
                CartError error = cxpError;
                errorList.add(error);
            }
            errors.setErrors(errorList);
        }
        return errors == null ? new ErrorResponse() : errors;
    }

    /**
     *
     * @param response
     * @return
     */
    public static ErrorResponse handleCrmRetrieveResponseErrorsFiveGHome(CrmRetrieveCartUIResponse response) {

        ErrorResponse errors = new ErrorResponse();
        List<CartError> errorList = new ArrayList<>();
        if (response.getErrors() != null && !response.getErrors().isEmpty()) {
            errors = new ErrorResponse();

            for (CartError cxpError : response.getErrors()) {
                CartError error = cxpError;
                errorList.add(error);
            }
        }
        if (!errorList.isEmpty())
            errors.setErrors(errorList);
        return  errors;
    }

    /**
     *
     * @param response
     * @return
     */
    public static ErrorResponse handleValidateE911AddressResponseErrors(ValidateE911AddressUIResponse response) {

        ErrorResponse errors = null;
        List<CartError> errorList = null;
        if (response.getErrors() != null) {
            errors = new ErrorResponse();

            errorList = Arrays.asList(response.getErrors());
        }
        if (errorList != null)
            errors.setErrors(errorList);
        return errors == null ? new ErrorResponse() : errors;
    }


    /**
     *
     * @param response
     * @return ErrorResponse
     */
    public static ErrorResponse handleCreateCaseResponseErrors(CreateCaseAndGetCustomerInfoUIResponse response) {

        ErrorResponse errors = null;
        List<CartError> errorList = new ArrayList<>();
        if (response.getErrors() != null) {
            errors = new ErrorResponse();

            for (CartError cxpError : response.getErrors()) {
                CartError error = cxpError;
                errorList.add(error);
            }
            errors.setErrors(errorList);
        }
        return errors == null ? new ErrorResponse() : errors;
    }

    /**
     *
     * @param response
     * @return ErrorResponse
     */
    public static ErrorResponse handleGuestChoiceResponseErrors(GuestChoiceUIResponse response) {

        ErrorResponse errors = null;
        List<CartError> errorList = new ArrayList<>();
        if (response.getErrors() != null) {
            errors = new ErrorResponse();

            for (CartError cxpError : response.getErrors()) {
                CartError error = cxpError;
                errorList.add(error);
            }
            errors.setErrors(errorList);
        }
        return errors == null ? new ErrorResponse() : errors;
    }

    /**
     *
     * @param response
     * @return ErrorResponse
     */
    public static ErrorResponse handleCheckExistingCartResponseErrors(CheckExistingCartUIResponse response) {

        ErrorResponse errors = null;
        List<CartError> errorList = new ArrayList<>();
        if (response.getErrors() != null) {
            errors = new ErrorResponse();

            for (CartError cxpError : response.getErrors()) {
                CartError error = cxpError;
                errorList.add(error);
            }
            errors.setErrors(errorList);
        }
        return errors == null ? new ErrorResponse() : errors;
    }


    //VZWYN-20895 changes
    public static ErrorResponse handleInitiateValidateDeviceSimResponseErrors(InitiateValidateDeviceSimUIResponse response) {

        ErrorResponse errors = null;
        List<CartError> errorList = new ArrayList<>();
        if (response.getErrors() != null) {
            errors = new ErrorResponse();

            for (CartError cxpError : response.getErrors()) {
                CartError error = cxpError;
                errorList.add(error);
            }
            errors.setErrors(errorList);
        }
        return errors == null ? new ErrorResponse() : errors;
    }

    /**
     *
     * @param response
     * @return ErrorResponse
     */
    public static ErrorResponse handleUpdateGiftItemResponseErrors(UpdateGiftItemUIResponse response) {

        ErrorResponse errors = null;
        List<CartError> errorList = null;
        if (response.getErrors() != null) {
            errors = new ErrorResponse();

            errorList = response.getErrors();
        }
        if (errorList != null)
            errors.setErrors(errorList);
        return errors == null ? new ErrorResponse() : errors;
    }


    public static ErrorResponse handleAddTrialContactInfoAndAddressResponseErrors(AddTrialContactInfoAndAddressUIResponse response) {

        ErrorResponse errors = null;
        List<CartError> errorList = new ArrayList<>();
        if (response.getErrors() != null) {
            errors = new ErrorResponse();

            for (CartError cxpError : response.getErrors()) {
                CartError error = cxpError;
                errorList.add(error);
            }
            errors.setErrors(errorList);
        }
        return errors == null ? new ErrorResponse() : errors;
    }
    /**
     *
     * @param response
     * @return ErrorResponse
     */
    public static ErrorResponse handleAFOResponseErrors(AccessoryFinancingOffersUIResponse response) {

        ErrorResponse errors = new ErrorResponse();
        List<CartError> errorList = new ArrayList<>();
        if (response.getErrors() != null) {
            errors = new ErrorResponse();

            errorList = response.getErrors();
        }
        if (errorList != null)
            errors.setErrors(errorList);
        return errors;
    }

    public static void handleCrossChannelIdIssue(List<CartError> errorList) {
        String issue = "";
        String id = "";
        if(CollectionUtilities.isNotEmptyOrNull(errorList) && !errorList.isEmpty() && errorList.get(0) != null) {
            id = errorList.get(0).getId();
            if(errorList.get(0).getDetailList() != null && !errorList.get(0).getDetailList().isEmpty() && errorList.get(0).getDetailList().get(0) != null) {
                issue = errorList.get(0).getDetailList().get(0).getIssue();
                if("1004".equalsIgnoreCase(id)) {
                    errorList.get(0).setMessage(issue);
                }
            }
        }
    }

    public static ErrorResponse handleAddReplenishmentToCartResponseErrors(AddReplenishmentToCartUIResponse response) {

        ErrorResponse errors = null;
        List<CartError> errorList = new ArrayList<>();
        if (response.getErrors() != null) {
            errors = new ErrorResponse();

            for (CartError cxpError : response.getErrors()) {
                CartError error = cxpError;
                errorList.add(error);
            }
            errors.setErrors(errorList);
        }
        return errors == null ? new ErrorResponse() : errors;
    }

    public static ErrorResponse handlReviewOrderTysResponseErrors(ReviewOrderTYSUIResponse resp) {

        ErrorResponse errors = null;
        List<CartError> errorList = new ArrayList<>();
        if (resp.getErrors() != null) {
            errors = new ErrorResponse();

            for (CartError cxpError : resp.getErrors()) {
                CartError error = cxpError;
                errorList.add(error);
            }
            errors.setErrors(errorList);
        }
        return errors == null ? new ErrorResponse() : errors;
    }

    protected static void formatErrorList(SOEErrorHolder soeError, List<CartError> errorList) {
        for (SOEError respError : soeError.getErrors()) {
            CartError error = new CartError();
            error.setNamespace(respError.getNamespace());
            error.setId(respError.getId());
            error.setName(respError.getName());
            error.setMessage(respError.getMessage());
            error.setDebug_id(respError.getDebug_id());
            if (StringUtilities.isNotEmptyOrNull(respError.getProactiveChatCustomMSG()))
                error.setProactiveChatCustomMSG(respError.getProactiveChatCustomMSG());
            if (StringUtilities.isNotEmptyOrNull(respError.getProactiveChatIndicator()))
                error.setProactiveChatIndicator(respError.getProactiveChatIndicator());
            if(CollectionUtilities.isNotEmptyOrNull(respError.getDetails())) {
                List<CartErrorDetail> detailList = new ArrayList<>();
                for(ErrorDetail detail: respError.getDetails()) {
                    CartErrorDetail soeDetail = new CartErrorDetail();
                    if(StringUtilities.isNotEmptyOrNull(detail.getIssue()))
                        soeDetail.setIssue(detail.getIssue());
                    if(StringUtilities.isNotEmptyOrNull(detail.getField()))
                        soeDetail.setField(detail.getField());
                    if(StringUtilities.isNotEmptyOrNull(detail.getLocation()))
                        soeDetail.setLocation(detail.getLocation());
                    if(StringUtilities.isNotEmptyOrNull(detail.getValue()))
                        soeDetail.setValue(detail.getValue());
                    detailList.add(soeDetail);
                }
                error.setDetailList(detailList);;
            }

            errorList.add(error);
        }
    }
}
