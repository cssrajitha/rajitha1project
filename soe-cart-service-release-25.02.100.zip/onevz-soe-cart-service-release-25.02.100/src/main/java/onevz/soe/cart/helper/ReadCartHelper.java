package onevz.soe.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.cradle.util.CradleConstants;
import com.vzw.cradle.vo.CradleResponse;
import onevz.cxp.feature.Flag;
import onevz.cxp.feature.util.FeatureFlag;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper3;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.constants.FeatureFlagConstants;
import onevz.soe.cart.constants.UpgradeReasonCodes;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper2;
import onevz.soe.cart.gql.schema.*;
import onevz.soe.cart.gql.schema.bundlebuildercartlightweight.*;
import onevz.soe.cart.model.abandonCart.CXPRetrieveLatestDevice;
import onevz.soe.cart.model.abandonCart.CXPRetrieveLatestPlan;
import onevz.soe.cart.model.abandonCart.CXPRetriveNextGenAbandonCartData;
import onevz.soe.cart.model.addTrialContactInfoAndAddress.AddTrialContactInfoAndAddressUIRequest;
import onevz.soe.cart.model.addTrialContactInfoAndAddress.AddTrialContactInfoAndAddressUIResponse;
import onevz.soe.cart.model.bundleAccessories.BundleAccessoryDetail;
import onevz.soe.cart.model.bundleBuilderCart.BundleBuilderCXPCartVO;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.customerByMtnList.BillAccount;
import onevz.soe.cart.model.deviceIdValidation.DeviceIdValidationLine;
import onevz.soe.cart.model.deviceIdValidation.SearchAttributes;
import onevz.soe.cart.model.deviceIdValidation.SimInfo;
import onevz.soe.cart.model.deviceSimValidation.CustomerReqType;
import onevz.soe.cart.model.eSimDetails.SimEidDetailsData;
import onevz.soe.cart.model.getCase.GetCaseRequest;
import onevz.soe.cart.model.getCase.GetCaseResponse;
import onevz.soe.cart.model.myOffer.MyOfferLine;
import onevz.soe.cart.model.retrieveCart.*;
import onevz.soe.cart.model.retrieveDpp.DppResponse;
import onevz.soe.cart.model.retrieveDpp.RetrieveDppRequest;
import onevz.soe.cart.model.retrieveDpp.RetrieveDppResponse;
import onevz.soe.cart.model.validateCart.CartValidationError;
import onevz.soe.cart.requests.*;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.ui.common.CartInfo;
import onevz.soe.cart.ui.common.GetDepletionTypeData;
import onevz.soe.cart.ui.common.ValidateISPUOrderData;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.cart.ui.responses.v2.FlagDetails;
import onevz.soe.cart.util.CartCxpResponseUtil;
import onevz.soe.cart.util.CartCxpResponseUtil1;
import onevz.soe.cart.util.CartPegaRequestUtil;
import onevz.soe.cart.util.CartPegaRequestUtil8;
import onevz.soe.cart.util.CartUtil;
import onevz.soe.channels.SOEChannels;
import onevz.soe.cradle.constant.Constants;
import onevz.soe.logging.util.LoggerUtil;
import onevz.soe.orderprocess.translator.BundleBuilderResponse;
import onevz.soe.spring.web.filter.RequestAccessContext;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.utilities.serialization.JacksonMapperFactory;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpCookie;
import org.springframework.http.ResponseCookie;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class ReadCartHelper extends ReadCartHelperParent{

	@Autowired
	private CartServiceCxpHelper cxpHelper;

	@Autowired
	private CartServiceCxpHelper2 cxpHelper2;

	@Autowired
	private CartServiceBpmHelper bpmHelper;

	@Autowired
	private CartServiceBpmHelper3 bpmHelper3;

	@Autowired
	private RedisHelper redisHelper;

	@Autowired
	private RedisHelper2 redisHelper2;
	@Autowired
	private RedisHelper3 redisHelper3;
	@Autowired
	private CartRequestBuilder cartRequestBuilder;
	@Autowired
	private FeatureFlagHelper featureFlagHelper;

	@Autowired
	private CradleHelper cradleHelper;

	@Value("${enableMHOffers}")
	private boolean enableMHOffers;

	@Value("${displayCartValidationErrors}")
	private boolean displayCartValidationErrors;


	@Value("${overrideCartIdFromRedis}")
	private boolean overrideCartIdFromRedis;

	@Value("${enableDeviceIdChecksumGenerator}")
	private boolean enableDeviceIdChecksumGenerator;

	@Value("${enableEsimAtlocalInventory}")
	private boolean enableEsimAtlocalInventory;

	//https://onejira.verizon.com/browse/VCGH-4116
	@Value("${enableEsimMigrationChanges}")
	private boolean enableEsimMigrationChanges;
	@Value("#{'${dpp.invalidDeviceTypes:}'.split('~')}")
	private List<String> invalidDeviceTypes;

	@Autowired
	FeatureFlag featureFlag;

	private static final Logger logger = LoggerFactory.getLogger(ReadCartHelper.class);

	private static final ObjectMapper objectMapper = new ObjectMapper();



    public  Mono<BundleAccessoryDetail> populateRedirectionError() {
		BundleAccessoryDetail response =new BundleAccessoryDetail();
		response.setErrors(CartIdErrorResponse());
		return Mono.just(response);
	}

	/*
		Return bundle images, price and discount.
	 */
	public Mono<BundleAccessoryDetail> retrieveBundleAccessoryInfo(RetrieveBundleAccRequest request) {

		return redisHelper.getDataFromRedis().flatMap(data -> {
			if(CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))
					&& StringUtilities.isEmptyOrNull(data.getCartId())){
				return populateRedirectionError();
			}
			logger.debug("Calling retrieveBundleAccessoryInfo cxp helper with redis cart Id {}", data.getCartId());
			return cartServiceCXPServices.retrieveBundleAccessories(data.getCartId()).flatMap(retrieveAccCartCXPResponse -> {
				if(retrieveAccCartCXPResponse!=null && retrieveAccCartCXPResponse.getData()!=null
						&& retrieveAccCartCXPResponse.getData().getCart()!=null  && retrieveAccCartCXPResponse.getData().getCart().getLineDetails()!=null
						&& retrieveAccCartCXPResponse.getData().getCart().getLineDetails().getLineInfo()!=null) {
					return checkAccessoryBundle(retrieveAccCartCXPResponse);
				}
				return Mono.just(new BundleAccessoryDetail());

			});

		});

	}

	/**
	 * @param request
	 * @return RetrieveCartUIResponse
	 */
	public Mono<RetrieveCartUIResponse> retrieveCart(RetrieveCartCXPRequest request) {
		String channelType = CartUtil.getChannelType(request.getChannelId());
		String graphqlType = request.getMeta()!=null ? request.getMeta().get("type"): "";
		return Mono.zip(redisHelper.getDataFromRedis(), redisHelper.getFiveGAddressFromRedis()).flatMap(monoZip -> {
			CartRedisData data = monoZip.getT1();
			retrieveCartCustomLogs(data);
			if(StringUtilities.isNotEmptyOrNull(data.getCustomerType()) && "N".equalsIgnoreCase(data.getCustomerType())){
				request.getData().setNewCustomer(true);
			}
			if(StringUtilities.isNotEmptyOrNull(data.getRepRole())){
				request.getData().setRepRole(data.getRepRole());
			}
			if(StringUtilities.isNotEmptyOrNull(data.getFlowName())){
				request.getData().setFlowName(data.getFlowName());
			}
			readSessionDataForBestbuy(request,data);

			if(CollectionUtilities.isNotEmptyOrNull(data.getPlanTaggingDetails())){
				request.getData().setPlanTaggingDetails(data.getPlanTaggingDetails());
			}
			logger.debug(String.format(CartConstants.LOG_REDIS_ACCOUNT_NUMBER, data.getAccountNumber()));
			if ((null == request.getData().getIsQuote()
					|| (null != request.getData().getIsQuote() && !request.getData().getIsQuote()))
					&& ( null == request.getData().getIsLead() || (null != request.getData().getIsLead() && !request.getData().getIsLead()))
					&& StringUtilities.isNotEmptyOrNull(data.getCartId()))
				request.getData().setCartId(data.getCartId());
			else if(overrideCartIdFromRedis && CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))) {
				request.getData().setCartId(data.getCartId());
				logger.debug("CartId has been updated from redis in request {}", data.getCartId());
			}

			if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED))
				request.getData().setMtnList(null);
			else if (StringUtilities.isNotEmptyOrNull(channelType)
					&& channelType.equalsIgnoreCase(CartConstants.DIGITAL)) {
				if (StringUtilities.isNotEmptyOrNull(data.getVzwRoles())
						&& (data.getVzwRoles().equalsIgnoreCase(CartConstants.MOBILE_SECURE)
						|| data.getVzwRoles().equalsIgnoreCase(CartConstants.ACCOUNT_MEMBER))
						&& StringUtilities.isNotEmptyOrNull(data.getMtn())) {
					List<String> mtnList = new ArrayList<>();
					mtnList.add(data.getMtn());
					request.getData().setMtnList(mtnList);
				}
				if (CartPegaRequestUtil.isDvmConversionFlagExists()
						&& StringUtilities.isNotEmptyOrNull(data.getVzwRoles())
						&& (CartConstants.MOBILE_SECURE.equalsIgnoreCase(data.getVzwRoles())
						|| CartConstants.ACCOUNT_MEMBER.equalsIgnoreCase(data.getVzwRoles()))) {
					request.getData().setMtnList(CartConstants.STRING_EMPTY_LIST);
				}
			}
			if(null != data && null != data.getAutoPayEnrolled()) {
				request.getData().setAutopayEnrolled(data.getAutoPayEnrolled());
			}
			if (StringUtilities.isEmptyOrNull(request.getData().getCartId()))
				return CartCxpResponseUtil1.retrieveCartEmptyResponse();

			Mono<RetrieveCartUIResponse> cxpData= cxpHelper.retrieveCart(request).flatMap(cxpResponse -> {
				CartRedisData rr = new CartRedisData();
				if (null != cxpResponse.getData() && null != cxpResponse.getData().getCart()) {

					CXPCartVO cart = CartUtil.updateGrantorDetails(cxpResponse.getData().getCart());
					if (!request.isSkipUpdateDLLData()) {
						sharedCartFlowName(cart);
					}
					if (StringUtilities.isNotEmptyOrNull(channelType)
							&& channelType.equalsIgnoreCase(CartConstants.ASSISTED)) {
						cart = CartUtil.sumOfLocalTaxes(cart);
						cart = CartUtil.isAssignMtnRequired(cart);
						if (CartConstants.OMNI_INDIRECT.equalsIgnoreCase(request.getChannelId())){
							cart = CartUtil.removeUpgFee(cart);
						}
						if(!request.getData().isNewCustomer()) {
							cart = CartUtil.updateConflicts(cart);
						}
						if(StringUtilities.isNotEmptyOrNull(request.getData().getFlowName()) && ! CartConstants.HYPHEN.equalsIgnoreCase(request.getData().getFlowName()) ) {
							cart.setFlow(request.getData().getFlowName());
						}
						cart.setDisplayCartValidationErrors(displayCartValidationErrors);

						// Set prefer names as null for mtns other than account owner
						if(cart != null && cart.getLineDetails() != null && cart.getLineDetails().getLineInfo() != null) {
							for (CXPLineInfo cxpLineInfo : cart.getLineDetails().getLineInfo()) {
								if(cxpLineInfo != null && StringUtilities.isNotEmptyOrNull(cxpLineInfo.getLineActivityType()) && "AAL".equalsIgnoreCase(cxpLineInfo.getLineActivityType())) {
									formatCxpLineInfo(cxpLineInfo);
								} else {
									if(cart != null && cart.getCustomerProfile() != null && cart.getCustomerProfile().getBillAccounts() != null
											&& !cart.getCustomerProfile().getBillAccounts().isEmpty() && cxpLineInfo != null) {
										List<BillAccountCustomerProfile> billAccounts = cart.getCustomerProfile().getBillAccounts();
										if(billAccounts != null && !billAccounts.isEmpty()) {
											billAccounts.forEach(bA->{
												if(bA != null) {
													List<MobileInfoCustomerProfile> mtns= bA.getMtns();
													if(mtns != null && !mtns.isEmpty()) {
														mtns.forEach(mtn->{
															if(mtn != null && mtn.getMobileInfoAttributes() != null && mtn.getMobileInfoAttributes().getAccessRoles() != null) {
																AccessRolesForProfile accessRoles = mtn.getMobileInfoAttributes().getAccessRoles();
																if(mtn.getMtn() != null && mtn.getMtn().equalsIgnoreCase(cxpLineInfo.getMobileNumber())) {

																	if(accessRoles != null && accessRoles.getOwner() != null && !accessRoles.getOwner()) {
																		formatCxpLineInfo(cxpLineInfo);
																	}
																}
															}
														});
													}
												}
											});
										}
									}
								}
							}
						}
					}

					cxpResponse.getData().setCart((StringUtilities.isEmptyOrNull(graphqlType) || CartConstants.NEWCUSTOMER.equalsIgnoreCase(graphqlType)) ? CartUtil.updateShippingCost(cart): cart);
					if (null != cxpResponse.getData().getCart().getCartHeader()) {
						RetrieveCartHeader header = cxpResponse.getData().getCart().getCartHeader();
						if (StringUtilities.isNotEmptyOrNull(header.getCartCreator()))
							rr.setCartCreator(header.getCartCreator());
						if (StringUtilities.isNotEmptyOrNull(header.getCartId()))
							rr.setCartId(header.getCartId());
						if (StringUtilities.isNotEmptyOrNull(header.getCaseId()))
							rr.setCaseId(header.getCaseId());

						cxpResponse.getData()
								.setCart(CartUtil.calculateMemberCount(cart, request.getMtnList(), data.getVzwRoles()));
						if( channelType.equalsIgnoreCase(CartConstants.DIGITAL) && StringUtilities.isNotEmptyOrNull(graphqlType) && CartConstants.NEWCUSTOMER.equalsIgnoreCase(graphqlType)) {
							if (data.getIsPreQualifiedNBX() == null || CartConstants.FALSE.equalsIgnoreCase(data.getIsPreQualifiedNBX())) {
								if (cxpResponse.getData().getCart().getOrderDetails() != null && cxpResponse.getData().getCart().getOrderDetails().getNbxInfo() != null &&
										cxpResponse.getData().getCart().getOrderDetails().getNbxInfo().getIsPreQualifiedNBX() != null)
									redisHelper2.upsertValueInRedis("isPreQualifiedNBX", cxpResponse.getData().getCart().getOrderDetails().getNbxInfo().getIsPreQualifiedNBX().toString()).subscribeOn(Schedulers.parallel()).subscribe();
							}
						}
						Boolean fiosAuthenticated=false;
						if(enableMHOffers&&StringUtilities.isNotEmptyOrNull(data.getFiosAuthenticated())
								&&CartConstants.AUTHENTICATED.equalsIgnoreCase(data.getFiosAuthenticated())) {
							logger.info("fiosAuthenticated : {}",true);
							fiosAuthenticated=true;
						}
						if(enableMHOffers&&StringUtilities.isNotEmptyOrNull(data.getExternalID())||fiosAuthenticated) {
							logger.info("fiosCustContactPrepopulated : {}",true);
							cxpResponse.getData().getCart().setIsVztExternalAccount(Boolean.TRUE);
						}
						if(enableMHOffers&&StringUtilities.isNotEmptyOrNull(data.getCustomerFiosPlanType())&&cxpResponse.getData()!=null
								&&cxpResponse.getData().getCart()!=null && cxpResponse.getData().getCart().getOrderDetails()!=null && StringUtilities.isNotEmptyOrNull(cxpResponse.getData().getCart().getOrderDetails().getVisionCustomerId())) {
							logger.info("fiosPlanType : {}",data.getCustomerFiosPlanType());
							String customerFiosPlanType = getCustomerFiosPlanType(data.getCustomerFiosPlanType());
							cxpResponse.getData().getCart().setCustomerFiosPlanType(customerFiosPlanType);
							cxpResponse.getData().getCart().getOrderDetails().setVisionCustomerId(null);
						}
						if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId())))
							return redisHelper.updateDataIntoRedisAsString(rr, "").flatMap(redisData -> {
								return Mono.just(cxpResponse);
							});
						//  setting totaldueToday as SubTotalDueMonthly for  RFEX CCH and PAD cases.
						if((CartConstants.OMNI_INDIRECT.equalsIgnoreCase(request.getChannelId()) || CartConstants.OMNI_INDIRECT_TAB.equalsIgnoreCase(request.getChannelId()))
								&& cxpResponse.getData()!=null &&cxpResponse.getData().getCart()!=null && cxpResponse.getData().getCart().getOrderDetails()!=null &&
								StringUtilities.isNotEmptyOrNull(cxpResponse.getData().getCart().getOrderDetails().getOrderType())
								&& "RF".equalsIgnoreCase(cxpResponse.getData().getCart().getOrderDetails().getOrderType())) {
							if (cart != null && cart.getLineDetails() != null && cart.getLineDetails().getLineInfo() != null) {
								for (CXPLineInfo cxpLineInfo : cart.getLineDetails().getLineInfo()) {
									if (cxpLineInfo != null && StringUtilities.isNotEmptyOrNull(cxpLineInfo.getLineActivityType())
											&& (CartConstants.PAD.equalsIgnoreCase(cxpLineInfo.getLineActivityType()) ||
											CartConstants.CONTRACT_CHANGE.equalsIgnoreCase(cxpLineInfo.getLineActivityType()))) {
										cxpResponse.getData().getCart().getOrderDetails().setTotalDueToday(cxpResponse.getData().getCart().getOrderDetails().getSubTotalDueMonthly());
									}
								}
							}
						}
						setTanglewoodLine(cxpResponse,monoZip.getT2());
						setFiOSDiscountCost(cxpResponse);
						return Mono.just(cxpResponse);
					}
				}
				return Mono.just(cxpResponse);
            });

            Mono<Map<String, Flag>> featureFlagsMapMono = featureFlagHelper.fetchMarketingCfgProfile(Arrays.asList(FeatureFlagConstants.APPLE_ONE_CFG_LIST.split(CartConstants.COMMA)));
            cxpData= Mono.zip(cxpData,Mono.just(data), featureFlagsMapMono).flatMap(Response ->
            {
                RetrieveCartUIResponse resp=Response.getT1();
                if(resp.getData() != null)
                {
                   resp.getData().setIsHomeSales(Response.getT2().getIsHomeSales());
                   resp.getData().setHomeSalesAddress(Response.getT2().getHomeSalesAddress());
                   resp.getData().setReasonForVisit(Response.getT2().getReasonForVisit());
                   resp.getData().setIsComboOrderAllowedForNSE(Response.getT2().getIsComboOrderAllowed());

                   Map<String, FlagDetails> featureConfigurationProfileData = new HashMap<>();
                   featureFlagHelper.addDigitalPromoFeatureFlag(Response.getT3(),featureConfigurationProfileData);
                   resp.getData().setFeatureConfigurationProfileData(featureConfigurationProfileData);
                }
                return Mono.just(resp);
            });
            return getRetrieveCartData(cxpData);
        });

    }
	private static void readSessionDataForBestbuy (RetrieveCartCXPRequest request, CartRedisData data) {
		if(StringUtilities.isNotEmptyOrNull(data.getLocationCode())){
			request.getData().setLocationCode(data.getLocationCode());
		}
		if(StringUtilities.isNotEmptyOrNull(data.getUpc())){
			request.getData().setUpc(data.getUpc());
		}
		if(StringUtilities.isNotEmptyOrNull(data.getPriceId())){
			request.getData().setPriceId(data.getPriceId());
		}
		if(StringUtilities.isNotEmptyOrNull(data.getLocationSubType())){
			request.getData().setLocationSubtype(data.getLocationSubType());
		}
		if(StringUtilities.isNotEmptyOrNull(data.getMaid())){
			request.getData().setMaid(data.getMaid());
		}



		//add locsubtype and maid into req by reading from redis data
	}

	private void setTanglewoodLine(RetrieveCartUIResponse cxpResponse, FiveGAddressRedisData data) {
		boolean tanglewoodSelected = data.getAddressRequest() != null ? data.getAddressRequest().isTanglewoodQualified(): false;
		if(tanglewoodSelected)
			Optional.ofNullable(cxpResponse).map(RetrieveCartUIResponse::getData).map(CXPRetrieveCartDataVO::getCart).map(CXPCartVO::getLineDetails)
					.map(CXPLineDetailsVO::getLineInfo).flatMap(cxpLineInfos -> Arrays.stream(cxpLineInfos).filter(cxpLineInfo -> StringUtilities.isNotEmptyOrNull(cxpLineInfo.getDeviceTypeSelected())).filter(lineInfo -> lineInfo.getDeviceTypeSelected().equalsIgnoreCase("5G Internet")).findFirst()).ifPresent(cxpLineInfo -> cxpLineInfo.setTanglewoodSelected("Y"));
	}

	//VZWYN-17463 changes
	public Mono<AddTrialContactInfoAndAddressUIResponse> addTrialContactInfoAndAddress(AddTrialContactInfoAndAddressUIRequest request, CartRedisData redisData) {
		return bpmHelper.addTrialContactInfoAndAddress(request,redisData);
	}

	public void retrieveCartCustomLogs(CartRedisData data) {

		try {

			Map<String, String> fields = new HashMap<>();

			Map<String, String> cartinfo = new HashMap<>();

			if(StringUtilities.isNotEmptyOrNull(data.getCustomerFiosPlanType())) {
				cartinfo.put("fiosCrossSellCustBanner", "true");
			}

			if(StringUtilities.isNotEmptyOrNull(data.getIntent())) {
				cartinfo.put("intent", data.getIntent());
			}

			if(StringUtilities.isNotEmptyOrNull(data.getExternalID())) {
				cartinfo.put("fiosCustContactPrepopulated", "true");
			}

			if(StringUtilities.isNotEmptyOrNull(data.getFiosAuthenticated())) {
				cartinfo.put("retrieveCart.fiosAuthenticated", data.getFiosAuthenticated());
			}else{
				cartinfo.put("retrieveCart.fiosAuthenticated", "Not Authenticated");
			}

			logger.info("About to execute cartinfo logs");
			fields.put("cartInfo", JacksonMapperFactory.defaultWriter().writeValueAsString(cartinfo));
			logger.info("Json parsing Executed");
			LoggerUtil.addCustomPersistField(fields);
			logger.info("Completed executing cartinfo logs");
		}

		catch (Exception e) {
			logger.error("Exception while logging retrieveCart details for Audit", e);
		}
	}

	/**
	 * @param request
	 * @return uiResponse
	 */
	public Mono<ValidateCartUIResponse> validateCart(ValidateCartCXPRequest request) {
		String channelType = CartUtil.getChannelType(request.getChannelId());
		return redisHelper.getDataFromRedis().flatMap(data -> {
			logger.debug(String.format(CartConstants.LOG_REDIS_ACCOUNT_NUMBER, data.getAccountNumber()));

			validateCartCustomLogs(data);

			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				request.setCartId(data.getCartId());

			GetCaseRequest caseRequest = new GetCaseRequest();

			if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				caseRequest.setAccountNumber(data.getAccountNumber());

			if (StringUtilities.isNotEmptyOrNull(request.getQuoteId()))
				caseRequest.setQuoteId(request.getQuoteId());

			if (StringUtilities.isNotEmptyOrNull(data.getMtn()))
				caseRequest.setCartCreator(data.getMtn());

			if (null != request && StringUtilities.isNotEmptyOrNull(channelType)) {

				caseRequest.setChannelType(channelType);
				caseRequest.setClientId(request.getChannelId());
			}
			if (null != request && StringUtilities.isNotEmptyOrNull(caseRequest.getChannelType())
					&& caseRequest.getChannelType().equalsIgnoreCase(CartConstants.ASSISTED))
				request.setMtnList(null);

			if (StringUtilities.isEmptyOrNull(request.getCartId())) {
				logger.info("cartId empty in request & Redis: Calling GetCases");
				if (StringUtilities.isNotEmptyOrNull(caseRequest.getChannelType())
						&& caseRequest.getChannelType().equalsIgnoreCase(CartConstants.DIGITAL)) {
					if ((StringUtilities.isNotEmptyOrNull(caseRequest.getAccountNumber())
							&& StringUtilities.isNotEmptyOrNull(caseRequest.getCartCreator()))
							|| StringUtilities.isNotEmptyOrNull(caseRequest.getQuoteId())) {

						Mono<GetCaseResponse> caseResponse = bpmHelper3.getCases(caseRequest);

						return caseResponse.flatMap(response -> {

							if (response.getErrors() == null && null != response) {

								if (response.getServiceBody() != null
										&& response.getServiceBody().getServiceResponse() != null
										&& response.getServiceBody().getServiceResponse().getContext() != null
										&& response.getServiceBody().getServiceResponse().getContext()
										.getCaseList() != null
										&& response.getServiceBody().getServiceResponse().getContext()
										.getCaseList().length > 0) {
									request.setCartId(
											response.getServiceBody().getServiceResponse().getContext().getCaseList()[0]
													.getCartId());

									CartRedisData rr = new CartRedisData();
									rr.setCartId(
											response.getServiceBody().getServiceResponse().getContext().getCaseList()[0]
													.getCartId());
									rr.setCaseId(
											response.getServiceBody().getServiceResponse().getContext().getCaseList()[0]
													.getCaseID());

									if (StringUtilities.isNotEmptyOrNull(request.getCartId())) {
										logger.info("Calling validateCart after setting cartId from GetCases.");
										if (StringUtilities.isNotEmptyOrNull(request.getPageId())
												&& request.getPageId().equalsIgnoreCase(CartConstants.CART)) {

											if (CollectionUtilities.isEmptyOrNull(request.getMtnList())
													&& StringUtilities.isNotEmptyOrNull(
													response.getServiceBody().getServiceResponse().getContext()
															.getCaseList()[0].getCartCreator())
													&& StringUtilities.isNotEmptyOrNull(data.getVzwRoles())
													&& (data.getVzwRoles().equalsIgnoreCase(CartConstants.MOBILE_SECURE)
													|| data.getVzwRoles()
													.equalsIgnoreCase(CartConstants.ACCOUNT_MEMBER))) {
												List<String> mtnList = new ArrayList<>();
												mtnList.add(response.getServiceBody().getServiceResponse().getContext()
														.getCaseList()[0].getCartCreator());
												request.setMtnList(mtnList);
											}
											return cxpHelper.validateCart(request,data).flatMap(cxpResponse -> {
												formatCxpResponse(cxpResponse, data);
												if (null != cxpResponse.getData()
														&& null != cxpResponse.getData().getValidateCartAndUpdate()) {
													formatValidateCartAndUpdate(cxpResponse, data, request, channelType);
													if (StringUtilities.isNotEmptyOrNull(rr.getCartId())
															&& StringUtilities.isNotEmptyOrNull(rr.getCaseId())) {
														logger.info(CartConstants.UPDATE_CARTID_CASEID);
														return redisHelper.updateCartIdAndCaseIdIntoRedis(rr)
																.flatMap(onSuccess -> {
																	return Mono.just(cxpResponse);
																});
													}
												}

												return Mono.just(cxpResponse);
											});
										} else
											return cxpHelper.validateCart(request,data).flatMap(cxpResponse -> {
												formatCxpResponse(cxpResponse, data);
												if (null != cxpResponse.getData()
														&& null != cxpResponse.getData().getValidateCartAndUpdate()) {
													formatValidateCartAndUpdate(cxpResponse, data, request, channelType);
													logger.info(CartConstants.UPDATE_CARTID_CASEID);

													if (StringUtilities.isNotEmptyOrNull(rr.getCartId())
															&& StringUtilities.isNotEmptyOrNull(rr.getCaseId())) {
														logger.info(CartConstants.UPDATE_CARTID_CASEID);
														return redisHelper.updateCartIdAndCaseIdIntoRedis(rr)
																.flatMap(onSuccess -> {
																	return Mono.just(cxpResponse);
																});
													}
												}
												return Mono.just(cxpResponse);
											});

									}
								}
							}
							return CartUtil.validateCartEmptyResponse();
						});
					}
				}
				return CartUtil.validateCartEmptyResponse();
			}
			if (StringUtilities.isNotEmptyOrNull(request.getPageId())
					&& request.getPageId().equalsIgnoreCase(CartConstants.CART)) {

				if (CollectionUtilities.isEmptyOrNull(request.getMtnList())
						&& StringUtilities.isNotEmptyOrNull(data.getMtn())
						&& StringUtilities.isNotEmptyOrNull(data.getVzwRoles())
						&& (data.getVzwRoles().equalsIgnoreCase(CartConstants.MOBILE_SECURE)
						|| data.getVzwRoles().equalsIgnoreCase(CartConstants.ACCOUNT_MEMBER))) {
					List<String> mtnList = new ArrayList<>();
					mtnList.add(data.getMtn());
					request.setMtnList(mtnList);
				}
				return cxpHelper.validateCart(request,data).flatMap(cxpResponse -> {

					if (null != cxpResponse.getData() && null != cxpResponse.getData().getValidateCartAndUpdate()) {

						updateBarCodes(data, cxpResponse);

						CXPCartVO cart = CartUtil
								.updateGrantorDetails(cxpResponse.getData().getValidateCartAndUpdate());
						cart = CartUtil.calculateMemberCount(cart, request.getMtnList(), data.getVzwRoles());
						cxpResponse.getData().setValidateCartAndUpdate(CartUtil.updateShippingCost(cart));
						if(enableMHOffers&&StringUtilities.isNotEmptyOrNull(data.getCustomerFiosPlanType()) && cxpResponse.getData().getValidateCartAndUpdate()!=null) {
							cxpResponse.getData().getValidateCartAndUpdate().setCustomerFiosPlanType(data.getCustomerFiosPlanType().equalsIgnoreCase("Y") ? "gig" : data.getCustomerFiosPlanType().equalsIgnoreCase("N") ? "nonGig" : null);
						}
						if(cxpResponse.getData()!=null && cxpResponse.getData().getValidateCartAndUpdate()!=null && cxpResponse.getData().getValidateCartAndUpdate().getOrderDetails()!=null &&
								StringUtilities.isNotEmptyOrNull(cxpResponse.getData().getValidateCartAndUpdate().getOrderDetails().getVisionCustomerId())) {
							if(StringUtilities.isNotEmptyOrNull(cxpResponse.getData().getValidateCartAndUpdate().getOrderDetails().getAccountCreateDate()) &&
									StringUtilities.isNotEmptyOrNull(cxpResponse.getData().getValidateCartAndUpdate().getOrderDetails().getExistingSpeed()) &&
									StringUtilities.isEmptyOrNull(data.getCustomerFiosPlanType()) ) {
								cxpResponse.getData().getValidateCartAndUpdate().setIsFiosCustomer(true);
							}
							cxpResponse.getData().getValidateCartAndUpdate().getOrderDetails().setVisionCustomerId(null);
						}
						if (StringUtilities
								.isNotEmptyOrNull(cxpResponse.getData().getValidateCartAndUpdate().getCartId())
								&& StringUtilities.isNotEmptyOrNull(caseRequest.getChannelType())
								&& caseRequest.getChannelType().equalsIgnoreCase(CartConstants.DIGITAL)) {
							return redisHelper2.getAccountInfoEligibleFlagFromRedis()
									.flatMap(accountInfoEligibleFlag -> {
										if(null==accountInfoEligibleFlag.getAccountEligibleForAAL() && null==accountInfoEligibleFlag.getAccountEligibleForBYOD()
												&& null==accountInfoEligibleFlag.getAccountEligibleForEUP()) {
											cxpResponse.getData().getValidateCartAndUpdate()
													.setAccountEligibility(true);
											logger.info("accountEligible true");
										}
										return Mono.just(cxpResponse);

									});
						}
					}
					return Mono.just(cxpResponse);
				});
			}
			if (CollectionUtilities.isEmptyOrNull(request.getMtnList())
					&& StringUtilities.isNotEmptyOrNull(data.getMtn())
					&& StringUtilities.isNotEmptyOrNull(data.getVzwRoles())
					&& (data.getVzwRoles().equalsIgnoreCase(CartConstants.MOBILE_SECURE)
					|| data.getVzwRoles().equalsIgnoreCase(CartConstants.ACCOUNT_MEMBER))) {
				List<String> mtnList = new ArrayList<>();
				mtnList.add(data.getMtn());
				request.setMtnList(mtnList);
			}
			return cxpHelper.validateCart(request,data).flatMap(cxpResponse -> {
				if(cxpResponse.getData()!=null && cxpResponse.getData().getValidateCartAndUpdate()!=null && cxpResponse.getData().getValidateCartAndUpdate().getOrderDetails()!=null &&
						StringUtilities.isNotEmptyOrNull(cxpResponse.getData().getValidateCartAndUpdate().getOrderDetails().getVisionCustomerId())) {
					if(StringUtilities.isNotEmptyOrNull(cxpResponse.getData().getValidateCartAndUpdate().getOrderDetails().getAccountCreateDate()) &&
							StringUtilities.isNotEmptyOrNull(cxpResponse.getData().getValidateCartAndUpdate().getOrderDetails().getExistingSpeed()) &&
							StringUtilities.isEmptyOrNull(data.getCustomerFiosPlanType()) ) {
						cxpResponse.getData().getValidateCartAndUpdate().setIsFiosCustomer(true);
					}
					cxpResponse.getData().getValidateCartAndUpdate().getOrderDetails().setVisionCustomerId(null);
				}
				if (null != cxpResponse.getData() && null != cxpResponse.getData().getValidateCartAndUpdate()) {
					CXPCartVO cart = CartUtil.updateGrantorDetails(cxpResponse.getData().getValidateCartAndUpdate());
					cart = CartUtil.calculateMemberCount(cart, request.getMtnList(), data.getVzwRoles());
					cxpResponse.getData().setValidateCartAndUpdate(CartUtil.updateShippingCost(cart));
					if (StringUtilities
							.isNotEmptyOrNull(cxpResponse.getData().getValidateCartAndUpdate().getCartId())
							&& StringUtilities.isNotEmptyOrNull(caseRequest.getChannelType())
							&& caseRequest.getChannelType().equalsIgnoreCase(CartConstants.DIGITAL)) {
						return redisHelper2.getAccountInfoEligibleFlagFromRedis()
								.flatMap(accountInfoEligibleFlag -> {
									if(null==accountInfoEligibleFlag.getAccountEligibleForAAL() && null==accountInfoEligibleFlag.getAccountEligibleForBYOD()
											&& null==accountInfoEligibleFlag.getAccountEligibleForEUP()) {
										cxpResponse.getData().getValidateCartAndUpdate()
												.setAccountEligibility(true);
										logger.info("accountEligible true");
									}
									return Mono.just(cxpResponse);

								});
					}
				}
				return Mono.just(cxpResponse);
			});
		});
	}

	public void validateCartCustomLogs(CartRedisData data) {

		try {

			Map<String, String> fields = new HashMap<>();

			Map<String, String> cartinfo = new HashMap<>();

			if(StringUtilities.isNotEmptyOrNull(data.getCustomerFiosPlanType())) {
				logger.info("fiosCrossSellCustBanner:true");
				cartinfo.put("fiosCrossSellCustBanner", "true");
			}

			if(StringUtilities.isNotEmptyOrNull(data.getExternalID())) {
				logger.info("fiosCustContactPrepopulated:true");
				cartinfo.put("fiosCustContactPrepopulated", "true");
			}

			if(StringUtilities.isNotEmptyOrNull(data.getIntent())) {
				logger.info("intent: {}",data.getIntent());
				cartinfo.put("intent", data.getIntent());
			}

			logger.info("About to execute cartinfo logs");
			fields.put("cartInfo", JacksonMapperFactory.defaultWriter().writeValueAsString(cartinfo));
			logger.info("Json parsing Executed");
			LoggerUtil.addCustomPersistField(fields);
			logger.info("Completed executing cartinfo logs");
		}

		catch (Exception e) {
			logger.error("Exception while logging validateCart details for Audit", e);
		}
	}

	public void updateBarCodes(CartRedisData data, ValidateCartUIResponse cxpResponse) {
		if (data != null && StringUtils.isNotEmpty(data.getZ1OfferCode()) &&
				cxpResponse.getData().getValidateCartAndUpdate().getOrderDetails() != null &&
				cxpResponse.getData().getValidateCartAndUpdate().getOrderDetails().getBarCodes() != null &&
				cxpResponse.getData().getValidateCartAndUpdate().getOrderDetails().getBarCodes().length > 0) {
			List<String> updatedBarCodes = new ArrayList<>();
			Arrays.stream(cxpResponse.getData().getValidateCartAndUpdate().getOrderDetails().getBarCodes())
					.filter(Objects::nonNull).forEach(barCodeId -> {
				if (StringUtils.equals(barCodeId, data.getZ1OfferCode())) {
					barCodeId = CartConstants.Z1_OFFER_CODE_APPLIED;
					logger.debug("Cart has z1OfferApplied");
				}
				updatedBarCodes.add(barCodeId);
			});
			if(!updatedBarCodes.isEmpty()) {
				cxpResponse.getData().getValidateCartAndUpdate().getOrderDetails()
						.setBarCodes(updatedBarCodes.toArray(new String[updatedBarCodes.size()]));
			}
		}
	}

	/**
	 *
	 * @param request
	 * @return response
	 */
	public Mono<ValidateISPUOrderUIResponse> validateISPUOrder(ValidateISPUOrderUIRequest request) {
		RetrieveCartCXPRequest retrieveCartRequest = new RetrieveCartCXPRequest();
		Map<String, String> meta = new HashMap<>();
		meta.put("type", "");
		retrieveCartRequest.setMeta(meta);

		retrieveCartRequest.setData(new CXPRetrieveCartDataVO());

		return redisHelper.getDataFromRedis().flatMap(data -> {
			logger.debug(String.format(CartConstants.LOG_REDIS_ACCOUNT_NUMBER, data.getAccountNumber()));
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				request.getData().setCartId(data.getCartId());
			retrieveCartRequest.getData().setCartId(request.getData().getCartId());
			return cxpHelper.retrieveCart(retrieveCartRequest).flatMap(responseBody -> {
				ValidateISPUOrderUIResponse resp = new ValidateISPUOrderUIResponse();
				if (responseBody.getErrors() != null) {
					resp.setErrors(responseBody.getErrors());
				} else if (responseBody.getData() != null && responseBody.getErrors() == null) {
					CXPRetrieveCartDataVO responseData = responseBody.getData();
					CXPCartVO cart = responseData.getCart();
					CXPLineDetailsVO lineDetails = cart.getLineDetails();
					Boolean ispuOrder = false;
					if (lineDetails != null && lineDetails.getLineInfo() != null) {
						for (CXPLineInfo lineInfo : lineDetails.getLineInfo()) {
							if (lineInfo.getIspuItem() != null) {
								if (lineInfo.getIspuItem()) {
									ispuOrder = true;
								}
							} else if (lineInfo.getIspuItemBYOD() != null) {
								if (lineInfo.getIspuItemBYOD()) {
									ispuOrder = true;
								}
							}
						}
					}
					resp.setData(new ValidateISPUOrderData());
					resp.getData().setIsIspuItemsInCarts(ispuOrder);

				}
				Mono<ValidateISPUOrderUIResponse> response = Mono.just(resp);
				return response;
			});
		});

	}

	/**
	 *
	 * @param request
	 * @return response
	 *
	 */
	public Mono<GetDepletionTypeUIResponse> getDepletionType(GetDepletionTypeUIRequest request) {
		RetrieveCartCXPRequest retrieveCartRequest = new RetrieveCartCXPRequest();
		Map<String, String> meta = new HashMap<String, String>();
		meta.put("type", "");
		retrieveCartRequest.setMeta(meta);
		retrieveCartRequest.setData(new CXPRetrieveCartDataVO());
		retrieveCartRequest.getData().setCartId(request.getData().getCartId());
		return redisHelper.getDataFromRedis().flatMap(data -> {
			logger.debug(String.format(CartConstants.LOG_REDIS_ACCOUNT_NUMBER, data.getAccountNumber()));
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				request.getData().setCartId(data.getCartId());
			return cxpHelper.retrieveCart(retrieveCartRequest).flatMap(responseBody -> {
				GetDepletionTypeUIResponse resp = new GetDepletionTypeUIResponse();
				if (responseBody.getErrors() != null) {
					resp.setErrors(responseBody.getErrors());
				} else if (responseBody.getData() != null && responseBody.getErrors() == null) {
					CXPRetrieveCartDataVO responseData = responseBody.getData();
					CXPCartVO cart = responseData.getCart();
					Boolean ispuOrder = false;
					Boolean isDfillItem = false;
					Boolean isLocalItem = false;
					CXPLineDetailsVO lineDetails = cart.getLineDetails();
					if (lineDetails != null && lineDetails.getLineInfo() != null) {
						for (CXPLineInfo lineInfo : lineDetails.getLineInfo()) {
							if (lineInfo.getIspuItem() != null) {
								if (lineInfo.getIspuItem()) {
									ispuOrder = true;
								}
							} else if (lineInfo.getIspuItemBYOD() != null) {
								if (lineInfo.getIspuItemBYOD()) {
									ispuOrder = true;
								}
							}
							if (lineInfo.getItemsInfo() != null) {
								for (CXPItemInfo itemInfo : lineInfo.getItemsInfo()) {
									if (null != itemInfo.getDepletionType()) {
										if ("F".equalsIgnoreCase(itemInfo.getDepletionType())) {
											isDfillItem = true;
										}
										if ("L".equalsIgnoreCase(itemInfo.getDepletionType())) {
											isLocalItem = true;
										}
									}
								}
							}

						}
					}
					resp.setData(new GetDepletionTypeData());
					resp.getData().setIsIspuItemsInCarts(ispuOrder);
					resp.getData().setIsDfillItemsInCart(isDfillItem);
					resp.getData().setIsLocalItemsInCart(isLocalItem);

				}
				Mono<GetDepletionTypeUIResponse> response = Mono.just(resp);
				return response;
			});
		});

	}

	/**
	 *
	 * @param request
	 * @return ManualDiscountUIResponse
	 *
	 */
	public Mono<GetUpgradeReasonCodeUIResponse> getUpgradeReasonCodes(GetUpgradeReasonCodeUIRequest request) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			logger.debug(String.format(CartConstants.LOG_REDIS_ACCOUNT_NUMBER, data.getAccountNumber()));
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				request.getData().setCartId(data.getCartId());
			return cxpHelper2.getUpgradeReasonCodes(request);
		});

	}

	/**
	 *
	 * @param request
	 * @return CheckDfillInventoryUIResponse
	 *
	 */
	public Mono<CheckDfillInventoryUIResponse> checkDfillInventory(CheckDfillInventoryUIRequest request) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			logger.debug("Calling cxp helper with redis cart Id {}", data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				request.setCartId(data.getCartId());
			return cxpHelper2.checkDfillInventory(request);
		});

	}

	/**
	 *
	 * @param request
	 * @return uiResponse
	 *
	 */
	public Mono<ESimDetailsUIResponse> eSimDetails(ESimDetailsETNIRequest request) {

		if (StringUtilities.isNotEmptyOrNull(request.getBillerId())) {
			if (request.getBillerId().equalsIgnoreCase("VISION_EAST")
					|| CartConstants.VISION_EAST_VE.equalsIgnoreCase(request.getBillerId())) {
				request.setBillerId("V");
				// https://onejira.verizon.com/browse/VCGH-4116
				if (checkEsimMigrationCondition(request)) {
					request.setTarget_billerId("V");
				}
			} else if (request.getBillerId().equalsIgnoreCase("VISION_WEST")
					|| CartConstants.VISION_WEST_VW.equalsIgnoreCase(request.getBillerId())) {
				request.setBillerId("N");
				// https://onejira.verizon.com/browse/VCGH-4116
				if (checkEsimMigrationCondition(request)) {
					request.setTarget_billerId("N");
				}
			} else if (request.getBillerId().equalsIgnoreCase("VISION_NORTH")
					|| CartConstants.VISION_NORTH_VN.equalsIgnoreCase(request.getBillerId())) {
				request.setBillerId("A");
				// https://onejira.verizon.com/browse/VCGH-4116
				if (checkEsimMigrationCondition(request)) {
					request.setTarget_billerId("A");
				}
			} else if (request.getBillerId().equalsIgnoreCase("VISION_B_2_B")
					|| request.getBillerId().equalsIgnoreCase("VISION_B2B")) {
				request.setBillerId("B");
				// https://onejira.verizon.com/browse/VCGH-4116
				if (checkEsimMigrationCondition(request)) {
					request.setTarget_billerId("B");
				}
			} else if (request.getBillerId().equalsIgnoreCase("EPS")) {
				request.setBillerId("P");
				// https://onejira.verizon.com/browse/VCGH-4116
				if (checkEsimMigrationCondition(request)) {
					request.setTarget_billerId("P");
				}
			}
		}
		if (!StringUtilities.isNotEmptyOrNull(request.getUserId()))
			request.setUserId(CartConstants.DEFAULT_USER_ID);
		//ACT-16 as part of handling default values from service
		if (StringUtilities.isEmptyOrNull(request.getApplicationId()))
			request.setApplicationId(CartConstants.DEFAULT_APPLICATION_ID);

		if (StringUtilities.isEmptyOrNull(request.getFlowInd()))
			request.setFlowInd(CartConstants.DEFAULT_FLOW_IND);

		return cxpHelper.eSimDetails(request);

	}

	/**
	 *
	 * @param request
	 * @return rr
	 *
	 */
	public Mono<RetrieveCartUIResponse> managerApprovalLines(RetrieveCartCXPRequest request) {
		return redisHelper.getDataFromRedis().flatMap(data -> {
			logger.debug(String.format(CartConstants.LOG_REDIS_ACCOUNT_NUMBER, data.getAccountNumber()));
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				request.getData().setCartId(data.getCartId());
			return cxpHelper.retrieveCart(request).flatMap(resp -> {
				if (resp.getErrors() != null) {
					return Mono.just(resp);
				} else {
					RetrieveCartUIResponse newResponse = new RetrieveCartUIResponse();
					newResponse.setData(new CXPRetrieveCartDataVO());
					newResponse.getData().setCart(new CXPCartVO());
					newResponse.getData().getCart().setLineDetails(new CXPLineDetailsVO());
					Optional.ofNullable(resp).map(RetrieveCartUIResponse::getData).map(CXPRetrieveCartDataVO::getCart)
							.map(CXPCartVO::getLineDetails).ifPresent(lineDetails -> {
						newResponse.getData().getCart().setCartId(resp.getData().getCart().getCartId());
						List<CXPLineInfo> newLineInfo = new ArrayList<>();
						Arrays.stream(lineDetails.getLineInfo()).filter(Objects::nonNull).forEach(lineInfo -> {
							if (CartConstants.EUP.equalsIgnoreCase(lineInfo.getLineActivityType()))
								Arrays.stream(lineInfo.getItemsInfo()).filter(Objects::nonNull)
										.forEach(itemsInfo -> {
											Optional.ofNullable(itemsInfo).map(CXPItemInfo::getCartItems)
													.ifPresent(cartItems -> {
														Arrays.stream(cartItems.getCartItem())
																.filter(Objects::nonNull).forEach(cartItem -> {
															if (CartConstants.DEVICE.equalsIgnoreCase(
																	cartItem.getCartItemType())
																	&& cartItem.getUpgradeReasonCode()
																	.startsWith("M")) {
																cartItem.setUpgradeReasonDesc(
																		UpgradeReasonCodes
																				.findByCode(cartItem
																						.getUpgradeReasonCode())
																				.getDescription());
																newLineInfo.add(lineInfo);
															}
														});
													});
										});
						});
						CXPLineInfo[] lineArr = new CXPLineInfo[newLineInfo.size()];
						newLineInfo.toArray(lineArr);
						newResponse.getData().getCart().getLineDetails().setLineInfo(lineArr);
					});
					if (CollectionUtilities.isNotEmptyOrNull(request.getMtnList())) {
						CustomerByMtnListUIRequest customerRequest = new CustomerByMtnListUIRequest();
						customerRequest.setMtnList(request.getMtnList());
						return cxpHelper2.customerByMtnList(customerRequest).flatMap(cr -> {
							if (cr.getErrors() != null) {
								newResponse.setErrors(cr.getErrors());
							} else {
								return redisHelper.getInEligibleUpgradeLinesFromRedis().flatMap(ineligibleLines -> {
									List<BillAccount> billAccounts = null != cr.getData()
											&& null != cr.getData().getCustomerByMtnList()
											&& null != cr.getData().getCustomerByMtnList().getBillAccounts()
											&& cr.getData().getCustomerByMtnList().getBillAccounts().size() > 0
											? cr.getData().getCustomerByMtnList().getBillAccounts()
											: new ArrayList<>();
									List<onevz.soe.cart.model.customerByMtnList.MtnList> updatedmtnList = new ArrayList<>();
									List<BillAccount> updatedBillAccounts = new ArrayList<>();

									if (billAccounts != null && billAccounts.size() > 0)
										billAccounts.forEach(x -> {
											List<onevz.soe.cart.model.customerByMtnList.MtnList> mtnList = x.getMtns();
											if (mtnList != null && mtnList.size() > 0)
												mtnList.forEach(y -> {
													if (null != ineligibleLines && ineligibleLines.size() > 0) {
														ineligibleLines.forEach(ie -> {
															if (ie.getMtn().equals(y.getMtn())) {
																y.setReason(ie.getReason());
															}
														});
													}
													y.setViewedCompass(false);
													updatedmtnList.add(y);
												});

											x.setMtns(updatedmtnList);
											updatedBillAccounts.add(x);
										});

									cr.getData().getCustomerByMtnList().setBillAccounts(updatedBillAccounts);
									newResponse.setCustomerByMtnListResponse(cr);
									return Mono.just(newResponse);
								});

							}
							return Mono.just(newResponse);
						});
					}
					return Mono.just(newResponse);
				}
			});

		});

	}

	private SearchAttributes setSearchAttributesData(SmartImeiDevicesResponse resp, SearchAttributes searchAttributes) {
		if (resp.getData()!=null && resp.getData().getSmartImeiDeviceDetails() != null && !CollectionUtils.isEmpty(resp.getData().getSmartImeiDeviceDetails())) {
			if (StringUtilities.isNotEmptyOrNull(resp.getData().getSmartImeiDeviceDetails().get(0).getDacc()))
				searchAttributes.setDacc(resp.getData().getSmartImeiDeviceDetails().get(0).getDacc());
			if(StringUtilities.isNotEmptyOrNull(resp.getData().getSmartImeiDeviceDetails().get(0).getSorDeviceType()))
				searchAttributes.setDeviceType(resp.getData().getSmartImeiDeviceDetails().get(0).getSorDeviceType());
			if(StringUtilities.isNotEmptyOrNull(resp.getData().getSmartImeiDeviceDetails().get(0).getSorHdVoiceInd()))
				searchAttributes.setHdVoiceInd(resp.getData().getSmartImeiDeviceDetails().get(0).getSorHdVoiceInd());
			if(StringUtilities.isNotEmptyOrNull(resp.getData().getSmartImeiDeviceDetails().get(0).getProdCode1()))
				searchAttributes.setProdCode(resp.getData().getSmartImeiDeviceDetails().get(0).getProdCode1());
			if(StringUtilities.isNotEmptyOrNull(resp.getData().getSmartImeiDeviceDetails().get(0).getSorId()))
				searchAttributes.setSku(resp.getData().getSmartImeiDeviceDetails().get(0).getSorId());

			return searchAttributes;
		}
		logger.info("ReadCartHelper :: setSearchAttributesData :: search attribute obj : {}",searchAttributes);
		return searchAttributes;
	}

	/**
	 * @param deviceIdValidationUIRequest
	 * @return DeviceIdValidationUIResponse
	 */
	public Mono<DeviceIdValidationUIResponse> deviceIdValidation(DeviceIdValidationUIRequest deviceIdValidationUIRequest) {
		String channelType = CartUtil.getChannelType(deviceIdValidationUIRequest.getChannelId());
		String sorDisplayName = deviceIdValidationUIRequest.getData().getLines().get(0).getDevice()!=null?deviceIdValidationUIRequest.getData().getLines().get(0).getDevice().getSorDisplayName():StringUtils.EMPTY;
		String skuCarrier = deviceIdValidationUIRequest.getData().getLines().get(0).getDevice()!=null?deviceIdValidationUIRequest.getData().getLines().get(0).getDevice().getSkuCarrier():StringUtils.EMPTY;

		if(deviceIdValidationUIRequest.getChannelId().contains("VZW-MFA")) { //NSADT-104570
			return getDeviceIdValidationFromCXP(deviceIdValidationUIRequest, sorDisplayName, skuCarrier);

		} else
			return redisHelper.getDataFromRedis().flatMap(data -> {

				if(deviceIdValidationUIRequest.getCartInfo() != null && deviceIdValidationUIRequest.getCartInfo().isFlexV2()) {
					cartRequestBuilder.buildValidateDeviceSimIdRequest(deviceIdValidationUIRequest, data);
				}
				if (StringUtilities.isNotEmptyOrNull(channelType)
						&& channelType.equalsIgnoreCase(CartConstants.ASSISTED)) {
					if ((CartConstants.NSE_BYOD.equalsIgnoreCase(deviceIdValidationUIRequest.getCartInfo().getIntendType())
							|| CartConstants.NSE.equalsIgnoreCase(deviceIdValidationUIRequest.getCartInfo().getIntendType()))
							&& StringUtilities.isNotEmptyOrNull(data.getCreditAppNum())) {
						deviceIdValidationUIRequest.getCartInfo().setCreditAppNum(data.getCreditAppNum());
						deviceIdValidationUIRequest.getCartInfo().setCartCreator(data.getCreditAppNum());
					}
				}
				if (!CartConstants.NSE_BYOD.equalsIgnoreCase(deviceIdValidationUIRequest.getCartInfo().getIntendType())
						&& !CartConstants.NSE.equalsIgnoreCase(deviceIdValidationUIRequest.getCartInfo().getIntendType())
						&& StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
					deviceIdValidationUIRequest.getCartInfo().setAccountNumber(data.getAccountNumber());
				if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
					deviceIdValidationUIRequest.getCartInfo().setCartId(data.getCartId());
				if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
					deviceIdValidationUIRequest.getCartInfo().setCaseId(data.getCaseId());
				if (StringUtilities.isNotEmptyOrNull(data.getLoggedInUser()))
					deviceIdValidationUIRequest.setLoggedInUser(data.getLoggedInUser());
				if (!CartConstants.NSE_BYOD.equalsIgnoreCase(deviceIdValidationUIRequest.getCartInfo().getIntendType())
						&& !CartConstants.NSE.equalsIgnoreCase(deviceIdValidationUIRequest.getCartInfo().getIntendType())
						&& StringUtilities.isNotEmptyOrNull(data.getMtn()))
					deviceIdValidationUIRequest.getCartInfo().setCartCreator(data.getMtn());
				if (!CartConstants.NSE_BYOD.equalsIgnoreCase(deviceIdValidationUIRequest.getCartInfo().getIntendType())
						&& !CartConstants.NSE.equalsIgnoreCase(deviceIdValidationUIRequest.getCartInfo().getIntendType())
						&& StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
						&& StringUtilities.isEmptyOrNull(deviceIdValidationUIRequest.getCartInfo().getProcessingMTN()))
					deviceIdValidationUIRequest.getCartInfo().setProcessingMTN(data.getProcessingMTN());
				if (!CartConstants.NSE_BYOD.equalsIgnoreCase(deviceIdValidationUIRequest.getCartInfo().getIntendType())
						&& !CartConstants.NSE.equalsIgnoreCase(deviceIdValidationUIRequest.getCartInfo().getIntendType())
						&& StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
					deviceIdValidationUIRequest.getCartInfo().setCartCreator(data.getCartCreator());
				if ((CartConstants.BYOD.equalsIgnoreCase(deviceIdValidationUIRequest.getCartInfo().getIntendType())
						|| CartConstants.AAL.equalsIgnoreCase(deviceIdValidationUIRequest.getCartInfo().getIntendType()))
						&& StringUtilities.isNotEmptyOrNull(data.getCustomerType()))
					deviceIdValidationUIRequest.getCartInfo().setCustomerType(data.getCustomerType());

					updateRequestDataFromRedisForMasking(deviceIdValidationUIRequest, data);


				/*
				 * https://onejira.verizon.com/browse/VZWYN-20438
				 *  below is the logic to generate
				 * the checksum for the device id in deviceIdValidationUIRequest if lenth >=15 and send it in the sub sequent calls
				 */
				if (enableDeviceIdChecksumGenerator) {
					if (deviceIdValidationUIRequest.getData().getLines() != null && deviceIdValidationUIRequest.getData().getLines().size()>0) {
						DeviceIdValidationLine line = deviceIdValidationUIRequest.getData().getLines().get(0);
						if (line.getDevice() != null && line.getDevice().getId() != null
								&&  CartConstants.ASSISTED.equalsIgnoreCase(channelType)
								&& line.getDevice().getId().length() >= 15) {
							line.getDevice()
									.setId(CartPegaRequestUtil8.calculateIMEIDeviceIdChecksum(line.getDevice().getId()));
							deviceIdValidationUIRequest.getData().getLines().get(0).getDevice().setId(line.getDevice().getId());
						}

					}
				}

				if(StringUtilities.isNotEmptyOrNull(sorDisplayName) && StringUtilities.isNotEmptyOrNull(skuCarrier)){
					return cxpHelper.getSmartImeiDevices(sorDisplayName, skuCarrier).defaultIfEmpty(new SmartImeiDevicesResponse()).flatMap(res -> {
						logger.info("ReadCartHelper :: deviceIdValidation :: catalog response for smart imei devices : {}", res);
						SearchAttributes attr = setSearchAttributesData(res, setSearchAttributesData(res,new SearchAttributes()));
						return getDeviceIdValidationFromPega(deviceIdValidationUIRequest, channelType, attr);

					});
				}
				return getDeviceIdValidationFromPega(deviceIdValidationUIRequest, channelType, new SearchAttributes());

			});

	}

	private Mono<DeviceIdValidationUIResponse> getDeviceIdValidationFromCXP(DeviceIdValidationUIRequest deviceIdValidationUIRequest, String sorDisplayName, String skuCarrier) {
		if(StringUtilities.isNotEmptyOrNull(sorDisplayName) && StringUtilities.isNotEmptyOrNull(skuCarrier)){
			return cxpHelper.getSmartImeiDevices(sorDisplayName, skuCarrier).defaultIfEmpty(new SmartImeiDevicesResponse()).flatMap(res -> {
				logger.info("ReadCartHelper :: deviceIdValidation :: catalog response for smart imei devices : {}", res);
				return cxpHelper2.deviceIdValidation(deviceIdValidationUIRequest, setSearchAttributesData(res, new SearchAttributes()));
			});
		}
		return cxpHelper2.deviceIdValidation(deviceIdValidationUIRequest, setSearchAttributesData(new SmartImeiDevicesResponse(), new SearchAttributes()));
	}

	private Mono<DeviceIdValidationUIResponse> getDeviceIdValidationFromPega(DeviceIdValidationUIRequest deviceIdValidationUIRequest, String channelType, SearchAttributes attr) {
		return bpmHelper3.deviceIdValidation(deviceIdValidationUIRequest, attr).flatMap(resp -> {
			boolean getTwoImeiForEUPAAL = false;
			deviceIdValidationUIRequest.getCartInfo().setMakeEtniQeidApi(false);
			logger.info(String.format("Processinggg IMEI2 : enableEsimAtlocalInventory - %s", enableEsimAtlocalInventory));
			if (enableEsimAtlocalInventory && !deviceIdValidationUIRequest.isDisableEsimAtLocalInventory()) {
				getTwoImeiForEUPAAL = ((SOEChannels.OMNI_RETAIL.getChannelName().equalsIgnoreCase(deviceIdValidationUIRequest.getChannelId())
						|| SOEChannels.OMNI_RETAIL_TAB.getChannelName().equalsIgnoreCase(deviceIdValidationUIRequest.getChannelId())
						|| SOEChannels.OMNI_INDIRECT.getChannelName().equalsIgnoreCase(deviceIdValidationUIRequest.getChannelId())
						|| SOEChannels.OMNI_INDIRECT_TAB.getChannelName().equalsIgnoreCase(deviceIdValidationUIRequest.getChannelId()))
						&& (CartConstants.AAL.equalsIgnoreCase(deviceIdValidationUIRequest.getCartInfo().getIntendType())
						|| CartConstants.EUP.equalsIgnoreCase(deviceIdValidationUIRequest.getCartInfo().getIntendType())
						|| CartConstants.NSE.equalsIgnoreCase(deviceIdValidationUIRequest.getCartInfo().getIntendType())));
				logger.info(String.format("Processing gg IMEI2 : deviceIdValidationUIRequest.getChannelId() - %s getTwoImeiForEUPAAL - %s", deviceIdValidationUIRequest.getChannelId(), getTwoImeiForEUPAAL));
			}
			if( ( CartConstants.BYOD.equalsIgnoreCase(deviceIdValidationUIRequest.getCartInfo().getIntendType()) && (SOEChannels.OMNI_RETAIL.getChannelName().equalsIgnoreCase(deviceIdValidationUIRequest.getChannelId())
					|| SOEChannels.OMNI_RETAIL_TAB.getChannelName().equalsIgnoreCase(deviceIdValidationUIRequest.getChannelId())
					|| SOEChannels.OMNI_INDIRECT.getChannelName().equalsIgnoreCase(deviceIdValidationUIRequest.getChannelId())
					|| SOEChannels.OMNI_INDIRECT_TAB.getChannelName().equalsIgnoreCase(deviceIdValidationUIRequest.getChannelId())) )){
				deviceIdValidationUIRequest.getCartInfo().setMakeEtniQeidApi(true);

			}
			if (CollectionUtilities.isEmptyOrNull(resp.getErrors())
					&& CartConstants.ASSISTED.equalsIgnoreCase(channelType)
					&& (CartConstants.BYOD.equalsIgnoreCase(deviceIdValidationUIRequest.getCartInfo().getIntendType())
					|| CartConstants.NSE_BYOD.equalsIgnoreCase(deviceIdValidationUIRequest.getCartInfo().getIntendType())
					|| getTwoImeiForEUPAAL)) {
				if (null != resp && null != resp.getServiceBody()
						&& null != resp.getServiceBody().getServiceResponse()
						&& null != resp.getServiceBody().getServiceResponse().getContext()
						&& null != resp.getServiceBody().getServiceResponse().getContext().getDeviceInfo()) {
					resp.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getSimInfo()
							.setMakeEtniPersApi(resp.getServiceBody().getServiceResponse().getContext()
									.getDeviceInfo().getMakeEtniPersApi());
					if (StringUtilities.isNotEmptyOrNull(resp.getServiceBody().getServiceResponse().getContext()
							.getDeviceInfo().getDeviceId()))
						resp.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getSimInfo()
								.setDeviceId(resp.getServiceBody().getServiceResponse().getContext()
										.getDeviceInfo().getDeviceId());

					boolean isNoPreInsertedSimAvail = false;
					String eucciCapable = resp.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getEuiccCapable();
					if (null != resp.getServiceBody().getServiceResponse().getContext().getDeviceInfo()
							&& StringUtilities.isNotEmptyOrNull(resp.getServiceBody().getServiceResponse().getContext()
							.getDeviceInfo().getSimClass4G())
							&& "NP".equalsIgnoreCase(resp.getServiceBody().getServiceResponse().getContext().getDeviceInfo()
							.getSimClass4G())
							&& (StringUtilities.isEmptyOrNull(eucciCapable)
							|| (StringUtilities.isNotEmptyOrNull(eucciCapable) && "N".equalsIgnoreCase(eucciCapable)))) {
						isNoPreInsertedSimAvail = true;
					}

					if (null != deviceIdValidationUIRequest.getData().getLines().get(0).getDevice().getSim() && StringUtilities
							.isNotEmptyOrNull(deviceIdValidationUIRequest.getData().getLines().get(0).getDevice().getSim().getId())
							&& !(isNoPreInsertedSimAvail && getTwoImeiForEUPAAL))
						return Mono.just(resp);
					if (StringUtilities.isNotEmptyOrNull(
							resp.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getImei2())
							&& (CartConstants.BYOD.equalsIgnoreCase(deviceIdValidationUIRequest.getCartInfo().getIntendType())
							|| CartConstants.NSE_BYOD
							.equalsIgnoreCase(deviceIdValidationUIRequest.getCartInfo().getIntendType())
							|| (getTwoImeiForEUPAAL && isNoPreInsertedSimAvail))
					) {
						logger.info("Processing IMEI2 for BYOD");
						logger.debug("Processing IMEI2 for BYOD");
						DeviceIdValidationUIResponse finalResponse = resp;
						finalResponse.getServiceBody().getServiceResponse().getContext().getDeviceInfo()
								.getSimInfo().setMakeEtniPersApi(resp.getServiceBody().getServiceResponse()
								.getContext().getDeviceInfo().getMakeEtniPersApi());
						String imei2 = "";

						if (deviceIdValidationUIRequest.getData().getLines().get(0).getDevice().getId().equalsIgnoreCase(resp
								.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getImei2()))
							imei2 = resp.getServiceBody().getServiceResponse().getContext().getDeviceInfo()
									.getImei1();
						else if (deviceIdValidationUIRequest.getData().getLines().get(0).getDevice().getId().equalsIgnoreCase(resp
								.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getImei1()))
							imei2 = resp.getServiceBody().getServiceResponse().getContext().getDeviceInfo()
									.getImei2();
						deviceIdValidationUIRequest.getData().getLines().get(0).getDevice().setId(imei2);
						if ((getTwoImeiForEUPAAL && isNoPreInsertedSimAvail) ||
								((SOEChannels.OMNI_INDIRECT_TAB.getChannelName().equalsIgnoreCase(deviceIdValidationUIRequest.getChannelId())
										|| SOEChannels.OMNI_INDIRECT.getChannelName().equalsIgnoreCase(deviceIdValidationUIRequest.getChannelId())
								) && isNoPreInsertedSimAvail)) {
							deviceIdValidationUIRequest.setSkipImei1Call(true);
							logger.info("deviceIdValidationUIRequest.setSkipImei1Call ::");
							String sku = "";
							if (StringUtilities.isNotEmptyOrNull(deviceIdValidationUIRequest.getData().getLines().get(0).getDevice().getSku())
									&& StringUtilities.isNotEmptyOrNull(deviceIdValidationUIRequest.getData().getLines().get(0).getEskuId())) {
								sku = deviceIdValidationUIRequest.getData().getLines().get(0).getEskuId();
							}
							deviceIdValidationUIRequest.getData().getLines().get(0).getDevice().setSku(sku);
							logger.info(String.format("deviceIdValidationUIRequest.setSkipImei1Call 11:: eSku : %s", sku));
						}
						// NSADT-133250 Code fix
						if ((CartConstants.BYOD.equalsIgnoreCase(deviceIdValidationUIRequest.getCartInfo().getIntendType()) || CartConstants.EUPBYOD.equalsIgnoreCase(deviceIdValidationUIRequest.getCartInfo().getIntendType()))
								&& null != deviceIdValidationUIRequest.getData() && CollectionUtilities.isNotEmptyOrNull(deviceIdValidationUIRequest.getData().getLines())
								&& null != deviceIdValidationUIRequest.getData().getLines().get(0) && null != deviceIdValidationUIRequest.getData().getLines().get(0).getDevice()
								&& null != deviceIdValidationUIRequest.getData().getLines().get(0).getDevice().getSim() && StringUtilities.isNotEmptyOrNull(deviceIdValidationUIRequest.getData().getLines().get(0).getDevice().getSim().getCurrentSimid())) {
							deviceIdValidationUIRequest.getData().getLines().get(0).getDevice().getSim().setCurrentSimid("");
						}
						// NSADT-133250 Code fix
						logger.info("Making seconddd device validation call with IMEI2");
						logger.debug("Making second device validation call with IMEI2");
						return bpmHelper3.deviceIdValidation(deviceIdValidationUIRequest, attr).flatMap(resp2 -> {
							if (CollectionUtilities.isEmptyOrNull(resp2.getErrors())) {
								if (null != resp.getServiceBody()
										&& null != resp.getServiceBody().getServiceResponse()
										&& null != resp.getServiceBody().getServiceResponse().getContext()
										&& null != resp.getServiceBody().getServiceResponse().getContext()
										.getDeviceInfo()
										&& null != resp.getServiceBody().getServiceResponse().getContext()
										.getDeviceInfo().getSimInfo()) {
									logger.info("IMEI2 data received");
									logger.debug("IMEI2 data received");
									logger.info("Dfillcompatiblesku");
									SimInfo simInfo2 = resp2.getServiceBody().getServiceResponse().getContext()
											.getDeviceInfo().getSimInfo();
									simInfo2.setMakeEtniPersApi(resp2.getServiceBody().getServiceResponse()
											.getContext().getDeviceInfo().getMakeEtniPersApi());
									finalResponse.getServiceBody().getServiceResponse().getContext()
											.getDeviceInfo().setSimInfo2(simInfo2);
									if (StringUtilities.isNotEmptyOrNull(resp2.getServiceBody()
											.getServiceResponse().getContext().getDeviceInfo().getDeviceId()))
										finalResponse.getServiceBody().getServiceResponse().getContext()
												.getDeviceInfo().getSimInfo2()
												.setDeviceId(resp2.getServiceBody().getServiceResponse()
														.getContext().getDeviceInfo().getDeviceId());
								}
							}
							if(deviceIdValidationUIRequest.getCartInfo().isMakeEtniQeidApi()){
								return eidSimDetails(finalResponse,deviceIdValidationUIRequest).flatMap(finalResp -> Mono.just(finalResp));
							}
							return Mono.just(finalResponse);
						});
					}
				}
			}
			if(deviceIdValidationUIRequest.getCartInfo().isMakeEtniQeidApi()){
				return eidSimDetails(resp,deviceIdValidationUIRequest).flatMap(finalResp -> Mono.just(finalResp));
			}
			return Mono.just(resp);
		});
	}

	//VZWCS-17115 changes
	public Mono<InitiateCbandCheckUIResponse> initiateCbandCheck(InitiateCbandCheckUIRequest request){
		logger.info("Calling cxp helper with InitiateCbandCheckUIRequest request: {}", request);
		return cxpHelper2.initiateCbandCheck(request);
	}
	/**
	 * @param request
	 * @return DeviceSimValidationUIResponse
	 */
	public Mono<DeviceSimValidationUIResponse> deviceSimValidation(ServerHttpRequest httpHeader,
																   DeviceSimValidationUIRequest request) {
		logger.debug("Calling cxp helper with DeviceSimValidationUIRequest request: {}", request);
		return cxpHelper2.deviceSimValidation(httpHeader, request);

	}

	/**
	 * @param request
	 * @return ValidateSecureTokenResponse
	 */
	public DeviceSimValidationUIRequest validateSecureToken(ValidateSecureTokenRequest request) {
		logger.debug("Calling IG helper with ValidateSecureTokenRequest request: {}", request);
		return cartIgHelper.validateSecureToken(request);

	}

	/**
	 * @param request
	 * @return RetrieveActivationStatusUIResponse
	 */

	public Mono<RetrieveActivationStatusUIResponse> retrieveActivationStatus(ServerHttpRequest httpHeader,
																			 RetrieveActivationStatusUIRequest request) {
		logger.debug("Calling Pega helper with RetrieveActivationStatusUIRequest request: {}", request);

		CartInfo cartInfo = new CartInfo();

		if (StringUtilities.isNotEmptyOrNull(request.getIntent()))
			cartInfo.setIntendType(request.getIntent());

		String flowPath = String.valueOf(httpHeader.getPath());
		if (CartConstants.VZW_BBP.equalsIgnoreCase(request.getChannelId())) {

			if (StringUtilities.isNotEmptyOrNull(flowPath)) {
				if (flowPath.contains("/nse/retrieveActivationStatus")) {
					cartInfo.setIntendType(CartConstants.NSE_BYOD);
				}
				else if (flowPath.contains("/retrieveActivationStatus")) {
					cartInfo.setIntendType(CartConstants.BYOD);
				}
			}
		}


		if (StringUtilities.isNotEmptyOrNull(request.getProcessStep()))
			cartInfo.setProcessStep(request.getProcessStep());
		if (StringUtilities.isNotEmptyOrNull(request.getProcessAction()))
			cartInfo.setProcessAction(request.getProcessAction());

		return redisHelper.getDataFromRedis().flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber())){
				cartInfo.setAccountNumber(data.getAccountNumber());
			}
			cartInfo.setCartId(StringUtilities.isEmptyOrNull(data.getCartId())?data.getCompletedCartId():data.getCartId());
			cartInfo.setCaseId(StringUtilities.isEmptyOrNull(data.getCaseId())?data.getCompletedCaseId():data.getCaseId());

			if (StringUtilities.isNotEmptyOrNull(data.getMtn()))
				cartInfo.setCartCreator(data.getMtn());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN())
					&& StringUtilities.isEmptyOrNull(cartInfo.getProcessingMTN()))
				cartInfo.setProcessingMTN(data.getProcessingMTN());
			if (StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				cartInfo.setCartCreator(data.getCartCreator());

			if (CartConstants.NSE_BYOD.equalsIgnoreCase(cartInfo.getIntendType())) {
				cartInfo.setProcessingMTN("");
				cartInfo.setAccountNumber("");
				String sessionId = "";
				String channelType = CartUtil.getChannelType(request.getChannelId());
				if (CartConstants.DIGITAL.equalsIgnoreCase(channelType)) {
					sessionId = null != httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION)
							? httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION).getValue()
							: "";
				}
				// Updating cartCreator and globalId with sessionId for New customer flow BBP
				cartInfo.setCartCreator(sessionId);
				cartInfo.setGlobalId(sessionId);
				cartInfo.setSessionId(sessionId);
			}

			request.setCartInfo(cartInfo);
			return bpmHelper.retrieveActivationStatus(request);
		});

	}

	/**
	 *
	 * @param reqType
	 * @return UIResponse
	 *
	 */
	public Mono<CustomerByMtnUIResponse> customerByMtn(CustomerReqType reqType) {
		return cxpHelper2.customerByMtn(reqType);
	}

	public Mono<CustomerProfileUIResponse> salesRepIdProfile(String repId){
		return cxpHelper2.salesRepIdProfile(repId);
	}

	/**
	 * @param channelId
	 * param request
	 * @return RetrieveActivationStatusUIResponse
	 */
	public Mono<RetrieveActivationStatusUIResponse> retrieveActivationStatusFromCXP(String channelId){
		logger.debug("Calling cxpServices to retrieve ActivationStatus Data" );
		return redisHelper.getDataFromRedis().flatMap( data -> {
			RetrieveActivationStatusCXPRequest cxpRequest = new RetrieveActivationStatusCXPRequest();
			CXPRetrieveActivationStatusDataVO dataVO = new CXPRetrieveActivationStatusDataVO();
			dataVO.setCartId(StringUtilities.isEmptyOrNull(data.getCartId())?data.getCompletedCartId():data.getCartId());
			cxpRequest.setData(dataVO);
			try {
				return cartServiceCXPServices
						//						.retrieveActivationStatus(cxpRequest)
						.retrieveActivationStatusOrdering(cxpRequest)
						.flatMap(cxpResponse ->
						{
							RetrieveActivationStatusUIResponse soeResponse = new RetrieveActivationStatusUIResponse();
							CartCxpResponseUtil.formatRetrieveActivationStatusResponse(soeResponse, cxpResponse, channelId);
							return Mono.just(soeResponse);
						});
			} catch (SOEHTTPException e) {
				logger.error("Exception while retrieving activation status", e);
				return Mono.just(null);
			}
		});
	}

	/**
	 * param GuestChoiceUIRequest
	 * @return GuestChoiceUIResponse
	 */
	public Mono<GuestChoiceUIResponse> guestChoiceFromPega(GuestChoiceUIRequest request) {
		logger.debug("Calling pegaService to retrieve guestChoice Data: {}", request);
		return redisHelper.getDataFromRedis().flatMap(data -> {
			if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				request.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getCartId()))
				request.getCartInfo().setCartId(data.getCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCaseId()))
				request.getCartInfo().setCaseId(data.getCaseId());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN()))
				request.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			return bpmHelper.guestChoice(request);
		});
	}

	/**
	 *
	 * @param mtn
	 * @return UIResponse
	 *
	 */
	public Mono<GetParentLinesUIResponse> customerByMtnForParentLines(String mtn) {
		return cxpHelper2.customerByMtnForParentLines(mtn);
	}

	/**
	 * param CheckExistingCartUIRequest
	 * @return CheckExistingCartUIResponse
	 */
	public Mono<CheckExistingCartUIResponse> checkExistingCartFromPega(CheckExistingCartUIRequest request) {
		logger.debug("Calling pegaService to retrieve checkExistingCartFromPega Data: {}", request);
		return redisHelper.getDataFromRedis().flatMap(data -> {
			logger.info("After Login redis data {}", data);
			if (StringUtilities.isNotEmptyOrNull(data.getAccountNumber()))
				request.getCartInfo().setAccountNumber(data.getAccountNumber());
			if (StringUtilities.isNotEmptyOrNull(data.getProspectCartId()))
				request.getCartInfo().setProspectCartId(data.getProspectCartId());
			if (StringUtilities.isNotEmptyOrNull(data.getCartCreator()))
				request.getCartInfo().setCartCreator(data.getCartCreator());
			if (StringUtilities.isNotEmptyOrNull(data.getProcessingMTN()))
				request.getCartInfo().setProcessingMTN(data.getProcessingMTN());
			if (StringUtilities.isNotEmptyOrNull(data.getVzwRoles()))
				request.getCartInfo().setAmRole(data.getVzwRoles());
			return bpmHelper.checkExistingCart(request);
		});
	}

	/**
	 * param AbandonCartSOERequest
	 * @return AbandonCartUIResponse
	 */
	public Mono<RetrieveLatestDeviceCXPResponse> retrieveCartAbandon(ServerHttpResponse httpResponse,AbandonCartSOERequest request) {
		logger.debug("Calling graphQl to retrieve retrieveCartAbandon Data: {}", request);
		String cartId = RequestAccessContext.obtainCookie(Arrays.asList("acid"));
		return redisHelper.getDataFromRedis().flatMap(data -> {
			logger.info(String.format("catt id in redis %s",data.getCartId()));
			if(StringUtils.isEmpty(cartId) || (StringUtils.isNotEmpty(data.getCartId()) && cartId.equals(data.getCartId()))) {
				return Mono.just(new RetrieveLatestDeviceCXPResponse());
			}
			return cartServiceCXPServices.retrieveLatestDevice(cartId,request.getPageId()).flatMap(cxpResp -> {
				if(null != cxpResp && null == cxpResp.getErrors()){
					httpResponse.addCookie(ResponseCookie.from(CartConstants.ACID, "")
							.path("/").httpOnly(true).secure(true).maxAge(Duration.ofDays(0)).build());
					httpResponse.addCookie(ResponseCookie.from(CartConstants.ABANDON_CART_AVAILABLE, "")
							.path("/").httpOnly(false).secure(true).maxAge(Duration.ofDays(0)).build());
					httpResponse.addCookie(ResponseCookie.from(CartConstants.CUSTOMER_ABANDON_CART_AVAILABLE, "")
							.path("/").httpOnly(false).secure(true).maxAge(Duration.ofDays(0)).build());
				}
				return Mono.just(cxpResp);
			});
		});

	}

	/**
	 * param AbandonCartSOERequest
	 * @return AbandonCartUIResponse
	 */
	public Mono<RetrieveNextGenCXPResponse> retrieveNextGenCartAbandon(ServerHttpResponse httpResponse, AbandonCartSOERequest request, ServerHttpRequest httpHeader) {
		logger.info("Calling graphQl to retrieve retrieveNextGenCartAbandon Data: {}", request);
		String encodedCartId = RequestAccessContext.obtainCookie(Arrays.asList(CartConstants.AC_NEXTGEN));
		logger.info("retrieveNextGenCartAbandon encodedCartId: {}", encodedCartId);
		if (StringUtils.isEmpty(encodedCartId)) {
			return Mono.just(new RetrieveNextGenCXPResponse());
		}
		byte[] decoded = Base64.getDecoder().decode(encodedCartId);
		String cartId = new String(decoded, StandardCharsets.UTF_8);
		logger.info("retrieveNextGenCartAbandon cartId: {}", cartId);
		return cartServiceCXPServices.retrieveNextGenLatestDevice(cartId, null, null)
				.flatMap(cxpResp -> formatCXPResponseNextGenAbandonCart(httpResponse, cxpResp, httpHeader));
	}

	private Mono<RetrieveNextGenCXPResponse> formatCXPResponseNextGenAbandonCart(ServerHttpResponse httpResponse, RetrieveNGACartCXPResponse cxpResp, ServerHttpRequest httpHeader) {
		RetrieveNextGenCXPResponse retrieveNextGenCXPResponse = new RetrieveNextGenCXPResponse();

		if (cxpResp == null || cxpResp.getData() == null || cxpResp.getData().getCart() == null ||
				cxpResp.getData().getCart().getLineDetails() == null ||
				cxpResp.getData().getCart().getLineDetails().getLineInfo() == null ||
				cxpResp.getData().getCart().getLineDetails().getLineInfo().length == 0 ||
				cxpResp.getData().getCart().getLineDetails().getLineInfo()[0] == null) {
			httpResponse.addCookie(ResponseCookie.from(CartConstants.AC_NEXTGEN, "")
					.path("/").httpOnly(false).secure(true).maxAge(Duration.ofDays(0)).build());
			return Mono.just(retrieveNextGenCXPResponse);
		}

		CXPRetriveNextGenAbandonCartData data = new CXPRetriveNextGenAbandonCartData();
		CXPRetrieveLatestDevice retrieveLatestDevice = new CXPRetrieveLatestDevice();
		CXPNGACLineInfo[] cxpngacLineInfos = cxpResp.getData().getCart().getLineDetails().getLineInfo();

		for (int i = cxpngacLineInfos.length-1; i >=0 && data.getRetrieveLatestDevice() == null ; --i) {
			CXPNGACLineInfo lineInfo = cxpngacLineInfos[i];
			Optional.ofNullable(lineInfo.getItemsInfo()).stream().flatMap(Arrays::stream)
					.flatMap(itemsInfo -> Arrays.stream(itemsInfo.getCartItems().getCartItem()))
					.filter(cartItemInfo -> isDeviceOfType(cartItemInfo)
							&& isDeviceInStock(cartItemInfo, cxpResp.getData().getCart().getCartValidationErrors()))
					.findFirst()
					.map(firstCartItem -> {
						populateRetrieveLatestDevice(retrieveLatestDevice, firstCartItem);
						data.setRetrieveLatestDevice(retrieveLatestDevice);
						data.setFlowName(lineInfo.getLineActivityType());
						return data;
					})
					.ifPresent(retrieveNextGenCXPResponse::setData);
		}

		if (data.getRetrieveLatestDevice() == null) {
			for (int i = cxpngacLineInfos.length-1; i >=0 && data.getRetrieveLatestPlan() == null ; --i) {
				CXPNGACLineInfo lineInfo = cxpngacLineInfos[i];
				Optional.ofNullable(lineInfo.getServiceInfo())
						.ifPresent(serviceInfo -> {
							PricePlanNGABInfo newPricePlanInfo = serviceInfo.getNewPricePlanInfo();
							if (newPricePlanInfo != null) {
								CXPRetrieveLatestPlan retrieveLatestPlan = new CXPRetrieveLatestPlan();
								retrieveLatestPlan.setPlanPrice(newPricePlanInfo.getPlanPrice());
								retrieveLatestPlan.setPricePlanDisplayName(newPricePlanInfo.getPricePlanDisplayName());
								retrieveLatestPlan.setPlanId(serviceInfo.getNewPricePlanId());
								data.setRetrieveLatestPlan(retrieveLatestPlan);
								data.setFlowName(lineInfo.getLineActivityType());
								retrieveNextGenCXPResponse.setData(data);
							}
						});
			}
		}

		return retrieveNGDCXPResponse(cxpResp, retrieveNextGenCXPResponse, httpResponse, httpHeader);
	}

	private Mono<RetrieveNextGenCXPResponse> retrieveNGDCXPResponse(RetrieveNGACartCXPResponse cxpResp, RetrieveNextGenCXPResponse retrieveNextGenCXPResponse, ServerHttpResponse httpResponse, ServerHttpRequest httpHeader) {
		return featureFlagHelper.isNgdAbandonCartFFlag()
				.zipWith(redisHelper.getRequiredDataFromRedis(List.of(Constants.CRADLE_DATAMAP_KEY)))
				.flatMap(tuple -> {
			logger.info("isNgdAbandonCartFFlag = {}", tuple.getT1());
			if (tuple.getT1()) {
				if (cxpResp != null && cxpResp.getData() != null && cxpResp.getData().getCart() != null &&
						cxpResp.getData().getCart().getOrderDetails() != null && retrieveNextGenCXPResponse.getData() != null) {
					if(cxpResp.getData().getCart().getOrderDetails().getFlowType() != null
							&& cxpResp.getData().getCart().getOrderDetails().getFlowType().equals(CartConstants.FLOW_TYPE_NGD)) {
						Optional.of(cxpResp).map(RetrieveNGACartCXPResponse::getData).map(CXPNGABRetrieveCartDataVO::getCart).map(CXPNGACartVO::getOrderDetails)
										.map(OrderDetailsNGD::getFlowType).ifPresent(flowType -> Optional.of(retrieveNextGenCXPResponse).map(RetrieveNextGenCXPResponse::getData)
										.ifPresent(uiData -> uiData.setFlowType(flowType)));
						if(isNgdRCInThrottleList(tuple.getT2())){
							return Mono.just(retrieveNextGenCXPResponse);
						}
						return updateNGDFlowWithCradleCall(httpResponse, retrieveNextGenCXPResponse, httpHeader);
					}
				}
			}
			return Mono.just(retrieveNextGenCXPResponse);
		});
	}

	public boolean isNgdRCInThrottleList(Map cacheDatamap){
		boolean ngdRcInThrottle =  Optional.ofNullable(cacheDatamap).map(datamap -> datamap.get(Constants.CRADLE_DATAMAP_KEY))
				.map(String::valueOf)
				.map(res -> {
					try {
						return objectMapper.readValue(res,Map.class);
					} catch (JsonProcessingException e) {
						logger.error("json Error in reading Cradle Datamap , {} ", ExceptionUtils.getStackTrace(e));
						return null;
					}
				})
				.map(resMap -> resMap.get(Constants.THROTTLE_LIST))
				.map(String::valueOf)
				.map(throttleList -> throttleList.contains(CartConstants.NGDRC_C) || throttleList.contains(CartConstants.NGDRC_T)).orElse(Boolean.FALSE);
		logger.info("isNgdRCInThrottleList = {}", ngdRcInThrottle);
		return ngdRcInThrottle;
	}

	public Mono<RetrieveNextGenCXPResponse> updateNGDFlowWithCradleCall(ServerHttpResponse httpResponse, RetrieveNextGenCXPResponse retrieveNextGenCXPResponse, ServerHttpRequest requestHeader) {
		if (null != requestHeader && null != requestHeader.getCookies()) {
			Map<String, String> dataMap = new HashMap<>();
			dataMap.put(CradleConstants.PAGE_NAME, CartConstants.NGD_PAGE_NAME);
			String channelId=RequestAccessContext.getRequestHeader(CartConstants.CHANNEL_ID);
			dataMap.put(CradleConstants.CHANNEL, channelId);
			logger.info("updateNGDFlowCraddleCall dataMap -- {}", dataMap);

			return invokeCradle(requestHeader, httpResponse, dataMap, CartConstants.NGD_PAGE_NAME)
					.filter(cradleResponse -> StringUtils.isNotBlank(cradleResponse.getOutPut()))
					.map(cradleResponse -> {
						try {
							updateNGDFLowCradleResponse(retrieveNextGenCXPResponse, cradleResponse);
						} catch (JsonProcessingException e) {
							logger.error("Exception occured at JSON parsing {}", e.getMessage());
						}
						return retrieveNextGenCXPResponse;
					}).defaultIfEmpty(retrieveNextGenCXPResponse);
		} else
			return Mono.just(retrieveNextGenCXPResponse);
	}

	private RetrieveNextGenCXPResponse updateNGDFLowCradleResponse(RetrieveNextGenCXPResponse retrieveNextGenCXPResponse, CradleResponse cradleResponse) throws JsonProcessingException {
		if (StringUtils.isNotBlank(cradleResponse.getOutPut())) {
			JsonNode cradleOutputJsonNode = objectMapper.readTree(cradleResponse.getOutPut());
			if (null != cradleOutputJsonNode && null != cradleOutputJsonNode.get(Constants.THROTTLE_LIST)) {
				String throttleList = cradleOutputJsonNode.get(Constants.THROTTLE_LIST).asText();
				logger.info("Value of throttleList updateNGDFLowCradleResponse --- {} ", throttleList);
				String subFlow = CartConstants.NGDRC_T;
				if (StringUtilities.isNotEmptyOrNull(throttleList) && throttleList.contains(CartConstants.NGDRC_C)) {
					retrieveNextGenCXPResponse.getData().setFlowType(CartConstants.EMPTY_STRING);
					subFlow = CartConstants.NGDRC_C;
				}
				dlUtilityService.upsertVZPageSubFLow(subFlow, true, "").subscribeOn(Schedulers.parallel()).subscribe();
			}
		}
		return retrieveNextGenCXPResponse;
	}

	public boolean isDeviceOfType(CXPNGACartItem cartItem) {
		return CartConstants.DEVICE_TYPE.equals(cartItem != null ? cartItem.getCartItemType() : null);
	}

	public boolean isDeviceInStock(CXPNGACartItem cartItem, List<CartValidationError> cartValidationErrors) {
		return cartItem != null && ( cartValidationErrors == null ||
				cartValidationErrors.stream()
						.noneMatch(error ->
								CartConstants.INVENTORY_NOT_AVAILABLE_ERROR_CODE.equals(error.getErrorCode())
										&& Objects.equals(error.getFieldPath() , cartItem.getSorId())));
	}

	private void populateRetrieveLatestDevice(CXPRetrieveLatestDevice retrieveLatestDevice, CXPNGACartItem cartItem) {
		retrieveLatestDevice.setCanonicalUrl(cartItem.getCanonicalUrl());
		retrieveLatestDevice.setProductDisplayName(cartItem.getDescription());
		retrieveLatestDevice.setSorDeviceCategory(cartItem.getSorDeviceCategory());
		retrieveLatestDevice.setSorId(cartItem.getSorId());

		FullRetailPrice fullRetailPrice = new FullRetailPrice();
		fullRetailPrice.setOriginalPrice(cartItem.getTotalPriceWithDiscount());
		retrieveLatestDevice.setFullRetailPrice(fullRetailPrice);

		Optional.ofNullable(cartItem.getImageUrlMap())
				.map(ImageUrlMap::getDefaultImage)
				.ifPresent(retrieveLatestDevice::setDeviceUrl);
	}

	private void formatCxpResponse(ValidateCartUIResponse cxpResponse, CartRedisData data) {
		if(cxpResponse.getData()!=null && cxpResponse.getData().getValidateCartAndUpdate()!=null && cxpResponse.getData().getValidateCartAndUpdate().getOrderDetails()!=null &&
				StringUtilities.isNotEmptyOrNull(cxpResponse.getData().getValidateCartAndUpdate().getOrderDetails().getVisionCustomerId())) {
			if(StringUtilities.isNotEmptyOrNull(cxpResponse.getData().getValidateCartAndUpdate().getOrderDetails().getAccountCreateDate()) &&
					StringUtilities.isNotEmptyOrNull(cxpResponse.getData().getValidateCartAndUpdate().getOrderDetails().getExistingSpeed()) &&
					StringUtilities.isEmptyOrNull(data.getCustomerFiosPlanType()) ) {
				cxpResponse.getData().getValidateCartAndUpdate().setIsFiosCustomer(true);
			}
			cxpResponse.getData().getValidateCartAndUpdate().getOrderDetails().setVisionCustomerId(null);
		}
	}

	/**
	 * @param request
	 * @return BundleBuilderCXPResponseData
	 */
	public Mono<BundleBuilderCXPResponseData> bundleBuilderCart(BundleBuilderRequest request) {
		return cxpHelper.bundleBuilderCart(request);
	}

	Mono<RetrieveCartUIResponse> getRetrieveCartData(Mono<RetrieveCartUIResponse> cxpData) {
		Mono<MyOfferETRRedisData> moEtrData = redisHelper.getMyOfferETRDataFromRedis();
		Mono<Boolean> conflictsAccepted = redisHelper3.getConflictsStatusFromSession();
		if(null == moEtrData || null == cxpData){
			return cxpData;
		}
		logger.info("Inside ReadCartHelper :: getRetrieveCartData()");
		return Mono.zip(cxpData, moEtrData, conflictsAccepted).flatMap(respData -> {
			if(Optional.ofNullable(respData.getT3()).isPresent()) {
				Optional.ofNullable(respData.getT1().getData().getCart()).ifPresent(cart -> {
					cart.setConflictsAccepted(respData.getT3());
				});
			}
			logger.info("Inside ReadCartHelper :: getRetrieveCartData() - OC offer at redis {}", moEtrData);
			if (null != respData && null != respData.getT2() && CollectionUtilities.isNotEmptyOrNull(respData.getT2().getLines()) &&
					null != respData.getT1() && respData.getT1().getData() != null
					&& respData.getT1().getData().getCart() != null
					&& respData.getT1().getData().getCart().getLineDetails() != null
					&& respData.getT1().getData().getCart().getLineDetails().getLineInfo() != null
					&& respData.getT1().getData().getCart().getLineDetails().getLineInfo().length > 0) {
				List<MyOfferLine> redisLines = respData.getT2().getLines();
				CXPLineInfo[] cxp = respData.getT1().getData().getCart().getLineDetails().getLineInfo();
				for (CXPLineInfo cxpLineInfo : cxp) {
					if (cxpLineInfo.getMultiLineSeqNumber() != null) {
						redisLines.forEach(redisLine -> {
							if (redisLine.getMultiLineSeqNumber() != null
									&& redisLine.getMultiLineSeqNumber().equals(cxpLineInfo.getMultiLineSeqNumber())) {
								cxpLineInfo.setPromotionsAccepted(true);
								List<OcOffer> ocoffr =  redisLine.getOffers().stream().filter(redisOffer -> null != redisOffer
										&& StringUtilities.isNotEmptyOrNull(redisOffer.getDescription())
								).map(ro -> new OcOffer(ro.getDescription())).collect(Collectors.toList());
								if(CollectionUtilities.isNotEmptyOrNull(ocoffr)) {
									cxpLineInfo.setOcOffers(ocoffr);
								}
							}
						});
					}
				}
			}
			logger.info("Inside ReadCartHelper :: getRetrieveCartData() - End");
			return Mono.justOrEmpty(respData.getT1());

		});
	}
	public Mono<ValidateCartUIResponse> getDeviceCategory(ValidateCartCXPRequest request) {

		return redisHelper.getDataFromRedis().flatMap(redisData -> {

			if (StringUtilities.isEmptyOrNull(redisData.getCartId())) {
				ValidateCartUIResponse response=new ValidateCartUIResponse();
				List<CartError> errors=new ArrayList<>();
				CartError cartError=new CartError();
				cartError.setNamespace(CartConstants.SOE_CART_SERVICE);
				cartError.setMessage(CartConstants.CART_ID_MISSING);
				cartError.setName(CartConstants.API_ERROR);
				cartError.setId(CartConstants.CART_ID_MISSING_CODE);
				errors.add(cartError);
				response.setErrors(errors);
				return Mono.just(response);
			}else{
				request.setCartId(redisData.getCartId());
			}
			if (CollectionUtilities.isEmptyOrNull(request.getMtnList())) {
				List<String> mtnList = new ArrayList<>();
				mtnList.add(redisData.getMtn());
				request.setMtnList(mtnList);
			}
			if(null==request.getRetrieveCurrentFeatures()){
				request.setRetrieveCurrentFeatures(Boolean.FALSE);
			}
			if(StringUtilities.isEmptyOrNull(request.getPageId())){
				request.setPageId(CartConstants.CART);
			}
			String graphqlType = "";
			String customerType = "";
			if (request.getMeta() != null && request.getMeta().containsKey("type"))
				graphqlType = request.getMeta().get("type");

			if (StringUtilities.isNotEmptyOrNull(graphqlType) && CartConstants.NEW_CUSTOMER_CAMELCASE.equalsIgnoreCase(graphqlType))
				customerType = CartConstants.NEW_CUSTOMER;

			ValidateCartUIResponse soeResponse = new ValidateCartUIResponse();
			return cartServiceCXPServices.deviceCategory(request.getCartId(),request.getRetrieveCurrentFeatures(), request.getMtnList(),customerType).flatMap(cartResponse -> {
				CartCxpResponseUtil1.formatDeviceCategoryResponse(soeResponse, cartResponse);
				return Mono.just(soeResponse);
			});
		});
	}
	public Mono<ValidateNextgenCartAndCheckoutResponse> validateNextgenCartAndCheckout(ValidateCartCXPRequest request) {

		String channelType = CartUtil.getChannelType(request.getChannelId());
		return redisHelper.getDataFromRedis().flatMap(redisData -> {

			if (StringUtilities.isEmptyOrNull(redisData.getCartId())) {
				ValidateNextgenCartAndCheckoutResponse response=new ValidateNextgenCartAndCheckoutResponse();
				List<CartError> errors=new ArrayList<>();
				CartError cartError=new CartError();
				cartError.setNamespace(CartConstants.SOE_CART_SERVICE);
				cartError.setMessage(CartConstants.CART_ID_MISSING);
				cartError.setName(CartConstants.API_ERROR);
				cartError.setId(CartConstants.CART_ID_MISSING_CODE);
				errors.add(cartError);
				response.setErrors(errors);
				return Mono.just(response);
			}else{
				request.setCartId(redisData.getCartId());
			}
			if (CollectionUtilities.isEmptyOrNull(request.getMtnList())) {
				List<String> mtnList = new ArrayList<>();
				mtnList.add(redisData.getMtn());
				request.setMtnList(mtnList);
			}
			if(null==request.getRetrieveCurrentFeatures()){
				request.setRetrieveCurrentFeatures(Boolean.FALSE);
			}
			if(StringUtilities.isEmptyOrNull(request.getPageId())){
				request.setPageId(CartConstants.CART);
			}
			String customerType="";
			if(request.getMeta()!=null && request.getMeta().get("customerType")!=null){
				customerType= request.getMeta().get("customerType");
			}
			return cartServiceCXPServices.validateNextgenCartAndCheckout(request.getCartId(),channelType,
					request.getPageId(), request.getFlow(), request.getRetrieveCurrentFeatures(), request.getMtnList(),
					customerType);


		});
	}
	public Mono<DeviceIdValidationUIResponse> eidSimDetails(DeviceIdValidationUIResponse finalResponse,DeviceIdValidationUIRequest deviceIdValidationUIRequest) {
		ESimDetailsETNIRequest request = new ESimDetailsETNIRequest();
		String eId="";
		if (finalResponse.getServiceBody()!=null && finalResponse.getServiceBody().getServiceResponse()!=null && finalResponse.getServiceBody().getServiceResponse().getContext()!=null &&
				finalResponse.getServiceBody().getServiceResponse().getContext().getDeviceInfo()!=null && finalResponse.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getPairedImeiData()!=null) {
			eId = StringUtilities.isNotEmptyOrNull(finalResponse.getServiceBody().getServiceResponse().getContext()
					.getDeviceInfo().getPairedImeiData().getEid()) ? finalResponse.getServiceBody().getServiceResponse().getContext()
					.getDeviceInfo().getPairedImeiData().getEid() : "";
		}
		if (StringUtilities.isNotEmptyOrNull(eId)) {
			request.setEid(eId);
			request.setUserId(CartConstants.DEFAULT_USER_ID);
			request.setApplicationId(CartConstants.DEFAULT_APP_ID);
			logger.info("ETNI REQUEST.... " + request);
			return cxpHelper.EidSimDetail(request).flatMap(etniResp -> {
				logger.info("ETNI response.... " + etniResp.getData());
				if (etniResp.getErrors() == null) {
					if(etniResp!=null && etniResp.getData()!=null && etniResp.getData().getSimEidResponseBean()!=null && etniResp.getData().getSimEidResponseBean().size()>0 )
					{
						List<SimEidDetailsData> simEidDetailsData = etniResp.getData().getSimEidResponseBean().get(0).getRowIdList().stream().filter(eidDetails->eidDetails.getMdn().equalsIgnoreCase(deviceIdValidationUIRequest.getData().getLines().get(0).getMtn())).collect(Collectors.toList());
						if(simEidDetailsData!=null && simEidDetailsData.size()>0){
							simEidDetailsData=simEidDetailsData.stream().sorted(Comparator.comparing(SimEidDetailsData::getSimUpdateDate).reversed()).collect(Collectors.toList());
							logger.info("simEidDetailsData  .... " + simEidDetailsData.toString());
							logger.info("simEidDetailsData.get(0).getSimUpdateDate() .... " + simEidDetailsData.get(0).getSimUpdateDate());
							logger.info("profileState.... " + simEidDetailsData.get(0).getProfileState());
							finalResponse.getServiceBody().getServiceResponse().getContext().getDeviceInfo().setProfileState(simEidDetailsData.get(0).getProfileState());
							deviceIdValidationUIRequest.getCartInfo().setMakeEtniQeidApi(false);
						}
					}
				}else{
					finalResponse.getServiceBody().getServiceResponse().getContext().getDeviceInfo().setProfileState("");
				}
				return Mono.just(finalResponse);
			});
		}
		return Mono.just(finalResponse);
	}


	public Mono<RetrieveCartUIResponse> updatePortLaterCraddleCall(RetrieveCartUIResponse retrieveCartResponse, ServerHttpRequest httpReq, ServerHttpResponse httpRes) {
		if(null != httpReq && null != httpReq.getCookies()) {
			HttpCookie cdlThrottleListCookie = httpReq.getCookies().getFirst(CartConstants.CDL_THROTTLE_LIST);
			if(null != cdlThrottleListCookie) {
				String cdlThrottleList = cdlThrottleListCookie.getValue();
				if (StringUtilities.isNotEmptyOrNull(cdlThrottleList) &&
						(cdlThrottleList.contains(CartConstants.NEW_C_PL_E) || cdlThrottleList.contains(CartConstants.NEW_PL_E))) {
					logger.info("Value of throttleList updatePortLaterCraddleCall in redis --- {}", cdlThrottleList);
					if (cdlThrottleList.contains(CartConstants.NEW_PL_E)) {
						retrieveCartResponse.getData().setIsPortInLaterThrottled(true);
					} else {
						retrieveCartResponse.getData().setIsPortInLaterThrottled(false);
					}
					return Mono.just(retrieveCartResponse);
				}
			}
		}

		if (isAalOrByodLinePresent(retrieveCartResponse)){
			Map<String, String> dataMap = new HashMap<>();
			dataMap.put(CradleConstants.PAGE_NAME, CartConstants.PORT_LATER_EXISTING_CRADLE_PAGE);
			dataMap.put(CradleConstants.CHANNEL, CartConstants.DIGITAL);
			logger.info("updatePortLaterCraddleCall dataMap -- {}", dataMap);

			return invokeCradle(httpReq, httpRes, dataMap, CartConstants.PORT_LATER_EXISTING_CRADLE_PAGE)
					.filter(cradleResponse -> StringUtils.isNotBlank(cradleResponse.getOutPut()))
					.map(cradleResponse -> {
						try {
                            updatePortInLaterCradleResponse(retrieveCartResponse, cradleResponse);
                        } catch (JsonProcessingException e) {
							logger.error("Exception occured at JSON parsing {}", e.getMessage());
						}
						return retrieveCartResponse;
					}).defaultIfEmpty(retrieveCartResponse);
		}
		return Mono.just(retrieveCartResponse);
	}

    public RetrieveCartUIResponse updatePortInLaterCradleResponse(RetrieveCartUIResponse retrieveCartResponse, CradleResponse cradleResponse) throws JsonProcessingException {
        if (StringUtils.isNotBlank(cradleResponse.getOutPut())) {
            JsonNode cradleOutputJsonNode = objectMapper.readTree(cradleResponse.getOutPut());
            if (null != cradleOutputJsonNode && null != cradleOutputJsonNode.get(Constants.THROTTLE_LIST)) {
                String throttleList = cradleOutputJsonNode.get(Constants.THROTTLE_LIST).asText();
                logger.info("Value of throttleList updatePortInLaterCradleResponse --- {} ", throttleList);
                if (StringUtilities.isNotEmptyOrNull(throttleList) && throttleList.contains(CartConstants.NEW_PL_E)) {
                    retrieveCartResponse.getData().setIsPortInLaterThrottled(true);
                } else {
                    retrieveCartResponse.getData().setIsPortInLaterThrottled(false);
                }
            }
        }
        return retrieveCartResponse;
    }

    private boolean isAalOrByodLinePresent(RetrieveCartUIResponse retrieveCartResponse) {
		if (retrieveCartResponse != null && retrieveCartResponse.getData() != null
				&& retrieveCartResponse.getData().getCart() != null && retrieveCartResponse.getData().getCart().getLineDetails() != null
				&& retrieveCartResponse.getData().getCart().getLineDetails().getLineInfo() != null) {
			return Arrays.stream(retrieveCartResponse.getData().getCart().getLineDetails().getLineInfo())
					.anyMatch(lineInfo -> StringUtils.isNotEmpty(lineInfo.getLineActivityType()) && CartConstants.PORTIN_LATER_ENABLED_INTENTS.contains(lineInfo.getLineActivityType().toUpperCase()));

		}
		return false;
	}

	public Mono<CradleResponse> invokeCradle(ServerHttpRequest httpReq, ServerHttpResponse httpRes, Map<String, String> dataMap, String pageName) {
		return cradleAllocator.invokeReactiveCradle(httpReq, httpRes, dataMap)
				.doOnError(error -> logger.error("call Craddle for {} failed : {}", pageName, error))
				.doOnSuccess(msg -> logger.info("call Craddle for {} successful : {} ", pageName,  msg))
				.defaultIfEmpty(new CradleResponse());
	}




	public  Optional<String> getProductNameByMTN(String mtn, BundleBuilderCXPCartVO bundleBuilderCXPCartVO) {
		return Optional.ofNullable(bundleBuilderCXPCartVO.getCustomerProfile())
				.map(CustomerProfileLW::getBillAccounts).stream()
				.flatMap(Collection::stream)
				.map(BillAccountCustomerProfileLW::getMtns)
				.flatMap(Collection::stream)
				.filter(mtnObj -> mtnObj.getMtn().equals(mtn))
				.flatMap(mtnObj -> mtnObj.getEquipmentInfos().stream())
				.map(EquipmentInfoLW::getDeviceInfo)
				.map(DeviceInfoLW::getProductName)
				.findFirst();
	}
	public Mono<BundleBuilderResponse> upgradeAutoTradeInFlow(BundleBuilderResponse bundleBuilderResponse, ServerHttpRequest httpReq, ServerHttpResponse httpRes, BundleBuilderRequest bundleBuilderRequest) {
		boolean isFlowEUP = checkFlowNameEUP(httpReq);
		boolean isPageIdOfferInterstitial = checkPageIdOfferInterstitial(bundleBuilderRequest);
		Mono<Boolean> flag = featureFlag.isFeatureEnabled(FeatureFlagConstants.AWS_CONFIG_APP_NAME,
				FeatureFlagConstants.SWIFT_CFG_PROFILE, FeatureFlagConstants.TRADE_IN_PROMOCCheckFFlag, true);
		Mono<Boolean> marketValueFlag = featureFlag.isFeatureEnabled(FeatureFlagConstants.AWS_CONFIG_APP_NAME,
				FeatureFlagConstants.SWIFT_CFG_PROFILE, FeatureFlagConstants.TRADE_IN_MarketValueFFlag, true);
		return Mono.zip(flag,marketValueFlag).flatMap(value->
				{
					bundleBuilderResponse.getFeatureFlags().put("tradeInPromoCheckFFlag",value.getT1());
					bundleBuilderResponse.getFeatureFlags().put("tradeInMarketValueFFlag",value.getT2());
		logger.info("validate isFlowEUP={}, isPageIdOfferInterstitial={}", isFlowEUP, isPageIdOfferInterstitial);
		if(isPageIdOfferInterstitial && isFlowEUP) {
			return callAutoTradeInCradle(httpReq, httpRes).flatMap(cdlThrottleList -> {
				logger.info("Value of throttleList upgradeAutoTradeInFlow cdlThrottleList={}", cdlThrottleList);
				if (StringUtilities.isNotEmptyOrNull(cdlThrottleList) && cdlThrottleList.contains(CartConstants.AUTO_TRADEIN)) {
					bundleBuilderResponse.getData().getCart().getLineDetails().setAutoAddTradeInEnable(Boolean.TRUE);
				}
				return Mono.just(bundleBuilderResponse);
			});
		}
		return Mono.just(bundleBuilderResponse);
		});
		}

	public Mono<String> callAutoTradeInCradle(ServerHttpRequest httpReq, ServerHttpResponse httpRes){
		Map<String, String> dataMap = new HashMap<>();
		dataMap.put(CradleConstants.PAGE_NAME, CartConstants.EUP_AUTO_TRADEIN_PAGEID);
		dataMap.put(CradleConstants.FLOW, CartConstants.EUP);
		return cradleAllocator.invokeReactiveCradle(httpReq, httpRes, dataMap)
				.map(CradleResponse::getOutPut)
				.filter(StringUtils::isNotBlank)
				.map(output -> {
					JsonNode cradleOutputJsonNode = null;
					try {
						cradleOutputJsonNode = objectMapper.readTree(output);
						if (null != cradleOutputJsonNode.get(Constants.THROTTLE_LIST)) {
							String throttleList = cradleOutputJsonNode.get(Constants.THROTTLE_LIST).asText();
							logger.info("Value of throttleList callSkipTradeInCradle ---> {}", throttleList);
						}
						return output;
					} catch (JsonProcessingException e) {
						logger.error("Exception occured at callSkipTradeInCradle JSON parsing", e);
					}
					return StringUtils.EMPTY;
				}).onErrorResume(throwable -> Mono.just(StringUtils.EMPTY));
	}

	public Mono<CradleResponse> invokeReactiveCradle(ServerHttpRequest httpReq, ServerHttpResponse httpRes, Map<String, String> dataMap){
		return cradleAllocator.invokeReactiveCradle(httpReq, httpRes, dataMap);
	}

	public boolean checkFlowNameEUP(ServerHttpRequest httpReq) {
		if(httpReq.getHeaders() != null) {
			String flowNameHeader = httpReq.getHeaders().containsKey(CartConstants.CONST_FLOW_NAME)? httpReq.getHeaders().getFirst(CartConstants.CONST_FLOW_NAME):"";
			if(flowNameHeader!=null && flowNameHeader.equalsIgnoreCase(CartConstants.EUP)){
				return true;
			}
		}
		return false;
	}
	public boolean checkPageIdOfferInterstitial(BundleBuilderRequest bundleBuilderRequest) {
		if(bundleBuilderRequest.getPageId() != null && CartConstants.PAGE_ID_OFFER_INTERSTITIAL.equalsIgnoreCase(bundleBuilderRequest.getPageId())) {
			return true;
		}
		return false;
	}

	public Mono<InventoryStatusCheckResponse> deviceInventoryStatusCheck(InventoryStatusCheckRequest request) {
		return cartServiceCXPServices.deviceInventoryStatusCheck(request);
	}
	public Mono<RetrieveDppResponse> retrieveDppOption(RetrieveDppRequest request) {
		RetrieveDppResponse retrieveDppResponse = new RetrieveDppResponse();
		DppResponse dppResponse = new DppResponse();
		dppResponse.setDppIndicator(false);
		retrieveDppResponse.setData(dppResponse);
		return redisHelper.getDataFromRedis().flatMap(data -> {
			if (data != null && StringUtils.isNotBlank(data.getCartId())) {
				logger.info("CartId {}", data.getCartId());
				Mono<RetrieveCartCXPResponse> responseServiceMono = cartServiceCXPServices.retrieveCartNewCustomer(data.getCartId(),
						true, null);
				return responseServiceMono.flatMap(resp -> {
					if (null != resp && null != resp.getData() && null != resp.getData().getCart() && null != resp.getData().getCart().getLineDetails() && null != resp.getData().getCart().getLineDetails().getLineInfo()
							&& resp.getData().getCart().getLineDetails().getLineInfo().length > 0) {
						Boolean dppInd= filterDeviceType(resp.getData().getCart().getLineDetails().getLineInfo(),request);
						if (Boolean.FALSE.equals(dppInd)) {
							dppResponse.setDppIndicator(true);
							retrieveDppResponse.setData(dppResponse);
						}
						return Mono.just(retrieveDppResponse);
					}
					return Mono.just(retrieveDppResponse);
				}).doOnError(
						error -> logger.error("Error while fetching the data from cxp",error));
			}
			retrieveDppResponse.setErrors(CartIdErrorResponse());
			return Mono.just(retrieveDppResponse);
		}).doOnError(
				error -> logger.error("Error while fetching the cartid from session", error)
		);
	}

	private Boolean filterDeviceType(CXPLineInfo[] lineInfos, RetrieveDppRequest request) {
		for (CXPLineInfo lineInfo : lineInfos) {
			if (StringUtilities.isNotEmptyOrNull(lineInfo.getMobileNumber()) && !request.getData().getMtn().contains(lineInfo.getMobileNumber())) {
				if (StringUtilities.isEmptyOrNull(lineInfo.getDeviceCategoryName())) {
					if (StringUtilities.isNotEmptyOrNull(lineInfo.getDeviceTypeSelected()) && !invalidDeviceTypes.contains(lineInfo.getDeviceTypeSelected().toLowerCase())) {
						return true;
					}
				} else if (!invalidDeviceTypes.contains(lineInfo.getDeviceCategoryName().toLowerCase())) {
					return true;
				}
			}
		}
		return false;
	}
}
