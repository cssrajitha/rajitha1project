package onevz.soe.cart.constants;

public class PlanChangeWarningConstants {
	public static final String FIVEG_PLAN_CHANGE_WARNING_ID = "FIVEG_PLAN_CHANGE_WARNING";
	public static final String FIVEG_PLAN_CHANGE_WARNING_MESSAGE_CARE = "WARNING - This change will disconnect active voice and data sessions. Before processing, ensure that you address all concerns first. Advise the customer to power cycle their device(s) after the change to enjoy the benefits of their new plan.";
	public static final String FIVEG_PLAN_CHANGE_WARNING_MESSAGE_RETAIL_TELE_CHAT = " <b>&#9888; Device powercycle required</b><br/>Before submitting the plan change, please advise the customer they will need to power cycle their device to connect to the network.";
	// PSTGRO-8728, 8797, 8750 story changes - ACB discount warning messages
	public static final String ACB_DISCOUNT_WARNING_MESSAGE = "<b>&#9888; By switching plans, you'll lose your discount.</b> </br> You are currently receiving the Affordable Connectivity Program discount. By switching plans, you will lose that discount.";
	public static final String ACB_STATE_WARNING_MESSAGE = "<b>&#9888; By switching plans, you'll lose these discounts</b> </br> You are currently receiving a Federal level Affordable Connectivity Program discount and you are currently receiving a temporary state level Affordable Connectivity Program discount. By switching plans, you will lose these discounts.";
	public static final String ACB_DQ_WARNING_MESSAGE = "<b>&#9888; By switching plans, you'll lose your discount.</b> </br> You are currently receiving a promotional discount based on your current plan. Switching will end this discount at the end of your next bill cycle. In addition, you are currently receiving the Affordable Connectivity Program discount. By switching plans, you will lose that discount when your plan change becomes effective.";
}

