package onevz.soe.cart.constants;

public enum PropositionsTypes {
	QUALIFIED, DISQUALIFIED;
}
