package onevz.soe.cart.util;

import java.util.List;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.addAccessory.AddAccServiceBody;
import onevz.soe.cart.model.addBillingAddress.BillingAddressContext;
import onevz.soe.cart.model.addBillingAddress.BillingAddressServiceBody;
import onevz.soe.cart.model.addBuyout.AddBuyoutContext;
import onevz.soe.cart.model.addBuyout.AddBuyoutServiceBody;
import onevz.soe.cart.model.addBuyout.AddBuyoutServiceResponse;
import onevz.soe.cart.model.addDevice.AddDeviceServiceBody;
import onevz.soe.cart.model.addDownPayment.DownPaymentServiceBody;
import onevz.soe.cart.model.addE911Address.E911AddressServiceBody;
import onevz.soe.cart.model.addFeature.AddFeaturesServiceBody;
import onevz.soe.cart.model.addFiveGBulkOrder.Add5GBulkOrderServiceBody;
import onevz.soe.cart.model.addPlan.AddPlanServiceBody;
import onevz.soe.cart.model.addPromoIntent.AddPromoIntentPEGAResponse;
import onevz.soe.cart.model.addPromoIntent.AddPromoIntentServiceBody;
import onevz.soe.cart.model.addPromoIntent.AddPromoIntentUIResponse;
import onevz.soe.cart.model.addServiceAddress.ServiceAddressContext;
import onevz.soe.cart.model.addServiceAddress.ServiceAddressServiceBody;
import onevz.soe.cart.model.addreplenishment.AddReplenishMentServiceBody;
import onevz.soe.cart.model.addZipcodePEGA.AddZipcodeServiceBody;
import onevz.soe.cart.model.affirmfinancing.AffirmFinancingPegaResponse;
import onevz.soe.cart.model.affirmfinancing.AffirmFinancingResponseServiceBody;
import onevz.soe.cart.model.assignMtn.AssignMtnContext;
import onevz.soe.cart.model.assignMtn.AssignMtnServiceBody;
import onevz.soe.cart.model.bbpgetProcessStep.ProcessStepServiceBody;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.createLine.CreateLineServiceBody;
import onevz.soe.cart.model.deassignMtn.DeassignMtnServiceBody;
import onevz.soe.cart.model.edgeup.UpdateEdgeupContext;
import onevz.soe.cart.model.edgeup.UpdateEdgeupServiceBody;
import onevz.soe.cart.model.edgeup.UpdateEdgeupServiceResponse;
import onevz.soe.cart.model.instantCreditDownPayment.InstantCreditDownPaymentServiceBody;
import onevz.soe.cart.model.ispuToDfill.IspuToDfillServiceBody;
import onevz.soe.cart.model.manualPairing.ManualPairingServiceBody;
import onevz.soe.cart.model.numberShare.NumberShareServiceBody;
import onevz.soe.cart.model.pastDues.PastDuesServiceBody;
import onevz.soe.cart.model.portinLater.PortinLaterServiceBody;
import onevz.soe.cart.model.removeLines.RemoveLinesServiceBody;
import onevz.soe.cart.model.resumeAndContinue.ResumeAndContinueServiceBody;
import onevz.soe.cart.model.retrieveActivationStatus.RetrieveActivationStatusServiceBody;
import onevz.soe.cart.model.revokeRebate.RevokeRebatesServiceBody;
import onevz.soe.cart.model.saveCart.SaveCartContext;
import onevz.soe.cart.model.saveCart.SaveCartServiceBody;
import onevz.soe.cart.model.updateBvoOffers.UpdateBvoOffersServiceBody;
import onevz.soe.cart.model.updateDeviceSimId.UpdateDeviceSIMIdServiceBody;
import onevz.soe.cart.model.updateEffectiveDateOverride.EffectiveDateOverrideServiceBody;
import onevz.soe.cart.model.updateSellerPrice.UpdateSellerPriceServiceBody;
import onevz.soe.cart.model.voidOrder.VoidOrderServiceBody;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.tys.reviewOrder.ReviewOrderPegaResponse;
import onevz.soe.cart.ui.requests.AddReplenishmentToCartUIRequest;
import onevz.soe.cart.ui.requests.AssignMtnUIRequest;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.bpm.model.ServiceHeader;
import onevz.soe.wsclient.bpm.model.response.ServiceResponse;

/**
 * Response Formatter Helper class.
 */
public class CartPegaResponseUtil {

	private CartPegaResponseUtil() {

	}

	/**
	 * 
	 * @param uiResponse
	 * @param pegaResponse
	 */
	public static void formatAddDownPaymentResponse(AddDownPaymentUIResponse uiResponse,
			AddDownPaymentPEGAResponse pegaResponse) {
		if (pegaResponse.getServiceHeader() != null)
			uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
		if (pegaResponse.getServiceBody() != null) {
			DownPaymentServiceBody serviceBody = pegaResponse.getServiceBody();
			uiResponse.setServiceBody(serviceBody);
		}
		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			uiResponse.setErrors(cartError);
		}
	}

	/**
	 * 
	 * @param uiResponse
	 * @param pegaResponse
	 */
	public static void formatSaveCartResponse(SaveCartUIResponse uiResponse, SaveCartPEGAResponse pegaResponse) {
		if (pegaResponse.getServiceHeader() != null)
			uiResponse.setServiceHeader(pegaResponse.getServiceHeader());

		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			uiResponse.setErrors(cartError);
		}
		
		if (pegaResponse.getServiceBody() != null) {
			SaveCartServiceBody serviceBody = pegaResponse.getServiceBody();
			if(serviceBody.getServiceResponse() != null && serviceBody.getServiceResponse().getContext() != null){
				SaveCartContext context = serviceBody.getServiceResponse().getContext();
				if(context.getCustomerInfo() != null && context.getCustomerInfo().getCustomerType()!=null) {
					if((context.getCustomerInfo().getCustomerType()).equalsIgnoreCase("N")) {
						if(context.getCartInfo() != null)
							context.getCartInfo().setCartId(null);
						context.setCaseId(null);
						if(uiResponse.getServiceHeader() != null)
							uiResponse.getServiceHeader().setClientId(null);
					}
				}
			}	
			uiResponse.setServiceBody(serviceBody);
		}
	}

	/**
	 * 
	 * @param uiResponse
	 * @param pegaResponse
	 */
	public static void formatUpdateEdgeUpResponse(UpdateEdgeupUIResponse uiResponse,
			UpdateEdgeupPEGAResponse pegaResponse) {
		if (pegaResponse.getServiceHeader() != null)
			uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
		if (pegaResponse.getServiceBody() != null) {
			UpdateEdgeupServiceBody serviceBody = pegaResponse.getServiceBody();
			uiResponse.setServiceBody(serviceBody);
		}
		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			uiResponse.setErrors(cartError);
		}

		UpdateEdgeupServiceBody serviceBody = new UpdateEdgeupServiceBody();
		if (uiResponse.getServiceBody() != null) {
			serviceBody = uiResponse.getServiceBody();
		}
		if (serviceBody.getServiceResponse() != null) {
			UpdateEdgeupServiceResponse serviceResponse = uiResponse.getServiceBody().getServiceResponse();
			if (serviceResponse.getContext() != null) {
				UpdateEdgeupContext context = serviceResponse.getContext();
				if (context.getCartInfo() != null) {
					CartServiceCartInfo cartInfo = context.getCartInfo();
					cartInfo.setPromoDisqualificationMessage(buildPromoDisqualificationMessage(cartInfo));
				}
			}
		}
	}

	/**
	 * 
	 * @param uiResponse
	 * @param pegaResponse
	 */
	public static void formatPastDuesResponse(PastDuesUIResponse uiResponse, PastDuesPEGAResponse pegaResponse) {
		if (pegaResponse.getServiceHeader() != null)
			uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
		if (pegaResponse.getServiceBody() != null) {
			PastDuesServiceBody serviceBody = pegaResponse.getServiceBody();
			uiResponse.setServiceBody(serviceBody);
		}
		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			uiResponse.setErrors(cartError);
		}
	}

	/**
	 * 
	 * @param uiResponse
	 * @param pegaResponse
	 */
	public static void formatAddBuyoutResponse(AddBuyoutUIResponse uiResponse, AddBuyoutPEGAResponse pegaResponse) {
		if (pegaResponse.getServiceHeader() != null)
			uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
		if (pegaResponse.getServiceBody() != null) {
			AddBuyoutServiceBody serviceBody = pegaResponse.getServiceBody();
			uiResponse.setServiceBody(serviceBody);
		}
		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			uiResponse.setErrors(cartError);
		}
		AddBuyoutServiceBody serviceBody = new AddBuyoutServiceBody();
		if (uiResponse.getServiceBody() != null) {
			serviceBody = uiResponse.getServiceBody();
		}
		if (serviceBody.getServiceResponse() != null) {
			AddBuyoutServiceResponse serviceResponse = uiResponse.getServiceBody().getServiceResponse();
			if (serviceResponse.getContext() != null) {
				AddBuyoutContext context = serviceResponse.getContext();
				if (context.getCartInfo() != null) {
					CartServiceCartInfo cartInfo = context.getCartInfo();
					cartInfo.setPromoDisqualificationMessage(buildPromoDisqualificationMessage(cartInfo));
				}
			}
		}
	}

	/**
	 * 
	 * @param uiResponse
	 * @param pegaResponse
	 */
	public static void formatInitiateCheckoutResponse(InitiateCheckoutUIResponse uiResponse,
			InitiateCheckoutPEGAResponse pegaResponse) {
		if (pegaResponse.getServiceHeader() != null)
			uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
		if (pegaResponse.getServiceBody() != null) {
			uiResponse.setServiceBody(pegaResponse.getServiceBody());
		}
		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			uiResponse.setErrors(cartError);
		}
	}

	/**
	 * 
	 * @param uiResponse
	 * @param pegaResponse
	 */
	public static void formatAddPlanResponse(AddPlanUIResponse uiResponse, AddPlanPEGAResponse pegaResponse) {
		if (pegaResponse.getServiceHeader() != null)
			uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
		if (pegaResponse.getServiceBody() != null) {
			AddPlanServiceBody serviceBody = pegaResponse.getServiceBody();
			uiResponse.setServiceBody(serviceBody);
		}
		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			uiResponse.setErrors(cartError);
		}
	}

	/**
	 * 
	 * @param uiResponse
	 * @param pegaResponse
	 */
	public static void formatRemoveLinesResponse(RemoveLinesUIResponse uiResponse,
			RemoveLinesPEGAResponse pegaResponse) {
		if (pegaResponse.getServiceHeader() != null)
			uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
		if (pegaResponse.getServiceBody() != null) {
			RemoveLinesServiceBody serviceBody = pegaResponse.getServiceBody();
			uiResponse.setServiceBody(serviceBody);
		}
		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			uiResponse.setErrors(cartError);
		}
	}

	/**
	 * 
	 * @param uiResponse
	 * @param pegaResponse
	 */
	public static void formatAddAccessoriesResponse(AddAccessoriesUIResponse uiResponse,
			AddAccessoriesPEGAResponse pegaResponse) {
		if (pegaResponse.getServiceHeader() != null)
			uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
		if (pegaResponse.getServiceBody() != null) {
			AddAccServiceBody serviceBody = pegaResponse.getServiceBody();
			uiResponse.setServiceBody(serviceBody);
		}
		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			uiResponse.setErrors(cartError);
		}
	}

	/**
	 *
	 * @param uiResponse
	 * @param pegaResponse
	 */
	public static void formatResumeAndContinueResponse(ResumeAndContinueUIResponse uiResponse,
													   ResumeAndContinuePegaResponse pegaResponse) {
		if (pegaResponse.getServiceHeader() != null)
			uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
		if (pegaResponse.getServiceBody() != null) {
			ResumeAndContinueServiceBody serviceBody = pegaResponse.getServiceBody();
			uiResponse.setServiceBody(serviceBody);
		}
		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			uiResponse.setErrors(cartError);
		}
	}

	/**
	 * 
	 * @param uiResponse
	 * @param pegaResponse
	 */
	public static void formatAddDeviceResponse(AddDeviceUIResponse uiResponse, AddDevicePEGAResponse pegaResponse) {
		if (pegaResponse.getServiceHeader() != null)
			uiResponse.setServiceHeader(pegaResponse.getServiceHeader());

		if (CollectionUtilities.isNotEmptyOrNull(pegaResponse.getErrors())) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			uiResponse.setErrors(cartError);
		}

		if (pegaResponse.getServiceBody() != null) {
			AddDeviceServiceBody serviceBody = pegaResponse.getServiceBody();
			uiResponse.setServiceBody(serviceBody);
		}
	}

	/**
	 * 
	 * @param uiResponse
	 * @param pegaResponse
	 */
	public static void formatAddFeaturesResponse(AddFeaturesUIResponse uiResponse,
			AddFeaturesPEGAResponse pegaResponse) {
		if (pegaResponse.getServiceHeader() != null)
			uiResponse.setServiceHeader(pegaResponse.getServiceHeader());

		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			uiResponse.setErrors(cartError);
		}

		if (pegaResponse.getServiceBody() != null) {
			AddFeaturesServiceBody serviceBody = pegaResponse.getServiceBody();
			uiResponse.setServiceBody(serviceBody);
		}

		if(pegaResponse.getErrorData() !=null && pegaResponse.getErrorData().getLines() != null && !pegaResponse.getErrorData().getLines().isEmpty()){
			ErrorData errorData = CartUtil.formatErrorDataResponse(pegaResponse.getErrorData());
			uiResponse.setErrorData(errorData);
		}

	}

	/**
	 * 
	 * @param uiResponse
	 * @param pegaResponse
	 */
	public static void formatCreateLineResponse(CreateLineUIResponse uiResponse, CreateLinePEGAResponse pegaResponse) {
		if (pegaResponse.getServiceHeader() != null)
			uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
		if (pegaResponse.getServiceBody() != null) {
			CreateLineServiceBody serviceBody = pegaResponse.getServiceBody();
			uiResponse.setServiceBody(serviceBody);
		}
		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			uiResponse.setErrors(cartError);
		}
	}

	/**
	 * 
	 * @param uiResponse
	 * @param pegaResponse
	 */
	public static void formatNumberShareResponse(NumberShareUIResponse uiResponse,
			NumberSharePEGAResponse pegaResponse) {
		if (pegaResponse.getServiceHeader() != null)
			uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
		if (pegaResponse.getServiceBody() != null) {
			NumberShareServiceBody serviceBody = pegaResponse.getServiceBody();
			uiResponse.setServiceBody(serviceBody);
		}
		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			uiResponse.setErrors(cartError);
		}
	}

	/**
	 *
	 * @param uiResponse
	 * @param pegaResponse
	 */
	public static void formatServiceAddressResponse(ServiceAddressUIResponse uiResponse,
			ServiceAddressPEGAResponse pegaResponse) {
		if (pegaResponse.getServiceHeader() != null)
			uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
		if (pegaResponse.getServiceBody() != null) {
			ServiceAddressServiceBody serviceBody = pegaResponse.getServiceBody();
			if(serviceBody.getServiceResponse() != null && serviceBody.getServiceResponse().getContext() != null){
				ServiceAddressContext context = serviceBody.getServiceResponse().getContext();
				if(context.getCustomerInfo() != null && StringUtilities.isNotEmptyOrNull(context.getCustomerInfo().getCustomerType()) && (context.getCustomerInfo().getCustomerType()).equalsIgnoreCase("N")) {
					if(context.getCartInfo() != null)
						context.getCartInfo().setCartId(null);
					context.setCaseId(null);
				}
				formatResponseForBBPChannel(pegaResponse.getServiceHeader(),serviceBody.getServiceResponse());
			}
			uiResponse.setServiceBody(serviceBody);
		}
		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			uiResponse.setErrors(cartError);
		}
	}

	/**
	 *
	 * @param uiResponse
	 * @param pegaResponse
	 */
	public static void formatBillingAddressResponse(BillingAddressUIResponse uiResponse,
                                                    BillingAddressPEGAResponse pegaResponse) {
		if (pegaResponse.getServiceHeader() != null)
			uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
		if (pegaResponse.getServiceBody() != null) {
			BillingAddressServiceBody serviceBody = pegaResponse.getServiceBody();
			if(serviceBody.getServiceResponse() != null && serviceBody.getServiceResponse().getContext() != null){
				BillingAddressContext context = serviceBody.getServiceResponse().getContext();
				if(context.getCustomerInfo() != null && StringUtilities.isNotEmptyOrNull(context.getCustomerInfo().getCustomerType()) && (context.getCustomerInfo().getCustomerType()).equalsIgnoreCase("N")) {
					if(context.getCartInfo() != null)
						context.getCartInfo().setCartId(null);
					context.setCaseId(null);
				}
			}
			uiResponse.setServiceBody(serviceBody);
		}
		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			uiResponse.setErrors(cartError);
		}
	}

	/**
	 *
	 * @param uiResponse
	 * @param pegaResponse
	 */
	public static void formatE911AddressResponse(E911AddressUIResponse uiResponse,
			E911AddressPEGAResponse pegaResponse) {
		if (pegaResponse.getServiceHeader() != null)
			uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
		if (pegaResponse.getServiceBody() != null) {
			E911AddressServiceBody serviceBody = pegaResponse.getServiceBody();
			uiResponse.setServiceBody(serviceBody);
		}
		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			uiResponse.setErrors(cartError);
		}
	}

	/**
	 *
	 * @param uiResponse
	 * @param pegaResponse
	 */
	public static void formatInstantCreditDownPaymentResponse(InstantCreditDownPaymentUIResponse uiResponse,
			InstantCreditDownPaymentPEGAResponse pegaResponse) {
		if (pegaResponse.getServiceHeader() != null)
			uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
		if (pegaResponse.getServiceBody() != null) {
			InstantCreditDownPaymentServiceBody serviceBody = pegaResponse.getServiceBody();
			uiResponse.setServiceBody(serviceBody);
		}
		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			uiResponse.setErrors(cartError);
		}
	}

	/**
	 *
	 * @param pegaResponse
	 * @param uiResponse
	 */
	public static void formatEffectiveDateOverrideResponse(EffectiveDateOverridePEGAResponse pegaResponse,
			EffectiveDateOverrideUIResponse uiResponse) {
		if (pegaResponse.getServiceHeader() != null)
			uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
		if (pegaResponse.getServiceBody() != null) {
			EffectiveDateOverrideServiceBody serviceBody = pegaResponse.getServiceBody();
			uiResponse.setServiceBody(serviceBody);
		}
		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			uiResponse.setErrors(cartError);
		}

	}

	/**
	 * 
	 * @param pegaResponse
	 * @param uiResponse
	 */
	public static void formatUpdateDeviceSimIdResponse(UpdateDeviceSIMIdPEGAResponse pegaResponse,
			UpdateDeviceSIMIdUIResponse uiResponse) {
		if (pegaResponse.getServiceHeader() != null)
			uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
		if (pegaResponse.getServiceBody() != null) {
			UpdateDeviceSIMIdServiceBody serviceBody = pegaResponse.getServiceBody();
			uiResponse.setServiceBody(serviceBody);
		}
		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			uiResponse.setErrors(cartError);
		}
	}

	/**
	 *
	 * @param pegaResponse
	 * @param soeResponse
	 */
	public static void formatAssignMtnResponse(AssignMtnPEGAResponse pegaResponse, AssignMtnUIResponse soeResponse, AssignMtnUIRequest uiRequest) {
		if (pegaResponse.getServiceHeader() != null)
			soeResponse.setServiceHeader(pegaResponse.getServiceHeader());
		if (pegaResponse.getServiceBody() != null) {
			AssignMtnServiceBody serviceBody = pegaResponse.getServiceBody();
			if(serviceBody.getServiceResponse() != null && serviceBody.getServiceResponse().getContext() != null){
				AssignMtnContext context = serviceBody.getServiceResponse().getContext();
				if(context.getCustomerInfo() != null) {
                    formatResponseForBBPChannel(pegaResponse.getServiceHeader(),serviceBody.getServiceResponse());
                    if (CartConstants.NSE_BYOD.equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())
							|| CartConstants.NSE.equalsIgnoreCase(uiRequest.getCartInfo().getIntendType())) {
													 
							context.getCartInfo().setCartId(null);
							context.setCaseId(null);
							if(soeResponse.getServiceHeader() != null)
								soeResponse.getServiceHeader().setClientId(null);
					}
				}
			}
			soeResponse.setServiceBody(serviceBody);
		}

		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			soeResponse.setErrors(cartError);
		}
	}
	
	public static void formatAddReplenishmentResponse(AddReplenishmentToCartPEGAResponse pegaResponse , AddReplenishmentToCartUIResponse soeResponse, AddReplenishmentToCartUIRequest uiRequest)
	{
		if (pegaResponse.getServiceHeader() != null)
			soeResponse.setServiceHeader(pegaResponse.getServiceHeader());
		if (pegaResponse.getServiceBody() != null) {
			AddReplenishMentServiceBody serviceBody = pegaResponse.getServiceBody();
			soeResponse.setServiceBody(serviceBody);
		}

		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			soeResponse.setErrors(cartError);
		}
	}

	public static void formatAddTruckRollCartResponse(AddTruckRollCartBPMResponse pegaResponse , AddTruckRollCartUIResponse soeResponse)
	{
		if (pegaResponse.getServiceHeader() != null)
			soeResponse.setServiceHeader(pegaResponse.getServiceHeader());
		if (pegaResponse != null && pegaResponse.getServiceBody() != null
				&& pegaResponse.getServiceBody().getServiceResponse() != null
				&& pegaResponse.getServiceBody().getServiceResponse().getContext() != null
		) {
			AddTruckRollCartUIResponseServiceBody addTruckRollCartUIResponseServiceBody = new AddTruckRollCartUIResponseServiceBody();
			soeResponse.setServiceBody(addTruckRollCartUIResponseServiceBody);
			AddTruckRollCartServiceResponse addTruckRollCartServiceResponse = new AddTruckRollCartServiceResponse();
			addTruckRollCartUIResponseServiceBody.setServiceResponse(addTruckRollCartServiceResponse);
			addTruckRollCartServiceResponse.setContext(pegaResponse.getServiceBody().getServiceResponse().getContext());
		}

		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			soeResponse.setErrors(cartError);
		}
	}

	public static void formatUpdateTruckRollCartResponse(AddTruckRollCartBPMResponse truckRollPegaResponse , AddTruckRollCartUIResponse truckRollSoeResponse)
	{
		if (truckRollPegaResponse.getServiceHeader() != null)
			truckRollSoeResponse.setServiceHeader(truckRollPegaResponse.getServiceHeader());
		if (truckRollPegaResponse != null && truckRollPegaResponse.getServiceBody() != null
				&& truckRollPegaResponse.getServiceBody().getServiceResponse() != null
				&& truckRollPegaResponse.getServiceBody().getServiceResponse().getContext() != null
		) {
			AddTruckRollCartUIResponseServiceBody updateAddTruckRollCartUIResponseServiceBody = new AddTruckRollCartUIResponseServiceBody();
			truckRollSoeResponse.setServiceBody(updateAddTruckRollCartUIResponseServiceBody);
			AddTruckRollCartServiceResponse updateAddTruckRollCartServiceResponse = new AddTruckRollCartServiceResponse();
			updateAddTruckRollCartUIResponseServiceBody.setServiceResponse(updateAddTruckRollCartServiceResponse);
			updateAddTruckRollCartServiceResponse.setContext(truckRollPegaResponse.getServiceBody().getServiceResponse().getContext());
		}

		if (truckRollPegaResponse.getErrors() != null && !truckRollPegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(truckRollPegaResponse.getErrors());
			truckRollSoeResponse.setErrors(cartError);
		}
	}
	/**
	 *
	 * @param pegaResponse
	 * @param soeResponse
	 */
	public static void formatDeassignMtnResponse(DeassignMtnPEGAResponse pegaResponse,
			DeassignMtnUIResponse soeResponse) {
		if (pegaResponse.getServiceHeader() != null)
			soeResponse.setServiceHeader(pegaResponse.getServiceHeader());
		if (pegaResponse.getServiceBody() != null) {

			DeassignMtnServiceBody serviceBody = pegaResponse.getServiceBody();
			soeResponse.setServiceBody(serviceBody);
		}

		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			soeResponse.setErrors(cartError);
		}
	}

	/**
	 * 
	 * @param uiResponse
	 * @param pegaResponse
	 */
	public static void formatAdd5GBulkOrderResponse(Add5GBulkOrderUIResponse uiResponse,
			Add5GBulkOrderPEGAResponse pegaResponse) {
		if (pegaResponse.getServiceHeader() != null)
			uiResponse.setServiceHeader(pegaResponse.getServiceHeader());

		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			uiResponse.setErrors(cartError);
		}

		if (pegaResponse.getServiceBody() != null) {
			Add5GBulkOrderServiceBody serviceBody = pegaResponse.getServiceBody();
			uiResponse.setServiceBody(serviceBody);
		}
	}

	/**
	 * 
	 * @param uiResponse
	 * @param pegaResponse
	 */
	public static void formatManualPairingResponse(ManualPairingUIResponse uiResponse,
			ManualPairingPEGAResponse pegaResponse) {

		if (pegaResponse.getServiceHeader() != null)
			uiResponse.setServiceHeader(pegaResponse.getServiceHeader());

		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			uiResponse.setErrors(cartError);
		}

		if (pegaResponse.getServiceBody() != null) {
			ManualPairingServiceBody serviceBody = pegaResponse.getServiceBody();
			uiResponse.setServiceBody(serviceBody);
		}
	}

	/**
	 * 
	 * @param uiResponse
	 * @param pegaResponse
	 */
	public static void formatRevokeRebatesResponse(RevokeRebatesUIResponse uiResponse,
			RevokeRebatesPEGAResponse pegaResponse) {
		if (pegaResponse.getServiceHeader() != null)
			uiResponse.setServiceHeader(pegaResponse.getServiceHeader());

		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			uiResponse.setErrors(cartError);
		}

		if (pegaResponse.getServiceBody() != null) {
			RevokeRebatesServiceBody serviceBody = pegaResponse.getServiceBody();
			uiResponse.setServiceBody(serviceBody);
		}
	}

	/**
	 * 
	 * @param uiResponse
	 * @param pegaResponse
	 */
	public static void formatUpdatePortInLaterResponse(PortinLaterUIResponse uiResponse,
			PortinLaterPEGAResponse pegaResponse) {
		if (pegaResponse.getServiceHeader() != null)
			uiResponse.setServiceHeader(pegaResponse.getServiceHeader());

		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			uiResponse.setErrors(cartError);
		}

		if (pegaResponse.getServiceBody() != null) {
			PortinLaterServiceBody serviceBody = pegaResponse.getServiceBody();
			uiResponse.setServiceBody(serviceBody);
		}
	}

	private static String buildPromoDisqualificationMessage(CartServiceCartInfo cartInfo) {
		String promoDisqualificationMessage = "";
		if (cartInfo.getPromoLossIndicator() != null)
			if (cartInfo.getPromoLossIndicator()) {
				promoDisqualificationMessage = "The monthly recurring device promotional credit of $"
						+ cartInfo.getMonthlyCreditAmount() + " will be removed from Agreement "
						+ cartInfo.getAgreementNumber() + " at the completion of this transaction.";
			}
		return promoDisqualificationMessage;
	}

	/**
	 *
	 * @param pegaResponse
	 * @param soeResponse
	 */
	public static void formatVoidOrderResponse(VoidOrderPEGAResponse pegaResponse, VoidOrderUIResponse soeResponse) {
		if (pegaResponse.getServiceHeader() != null)
			soeResponse.setServiceHeader(pegaResponse.getServiceHeader());
		if (pegaResponse.getServiceBody() != null) {

			VoidOrderServiceBody serviceBody = pegaResponse.getServiceBody();
			soeResponse.setServiceBody(serviceBody);
		}

		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			soeResponse.setErrors(cartError);
		}
	}

	/**
	 *
	 * @param pegaResponse
	 * @param soeResponse
	 */
	public static void formatIspuToDfillResponse(IspuToDfillPEGAResponse pegaResponse,
			IspuToDfillUIResponse soeResponse) {
		if (pegaResponse.getServiceHeader() != null)
			soeResponse.setServiceHeader(pegaResponse.getServiceHeader());
		if (pegaResponse.getServiceBody() != null) {

			IspuToDfillServiceBody serviceBody = pegaResponse.getServiceBody();
			soeResponse.setServiceBody(serviceBody);
		}

		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			soeResponse.setErrors(cartError);
		}
	}

	/**
	 * 
	 * @param uiResponse
	 * @param pegaResponse
	 */
	public static void formatProcessStepResponse(BbpGetProcessStepUIResponse uiResponse,
			BbpGetProcessStepPEGAResponse pegaResponse) {
		if (pegaResponse.getServiceHeader() != null)
			uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
		if (pegaResponse.getServiceBody() != null) {
			ProcessStepServiceBody serviceBody = pegaResponse.getServiceBody();
            formatResponseForBBPChannel(pegaResponse.getServiceHeader(),serviceBody.getServiceResponse());
            uiResponse.setServiceBody(serviceBody);
		}
        if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			uiResponse.setErrors(cartError);
		}
	}

	/**
	 * 
	 * @param uiResponse
	 * @param pegaResponse
	 */

	public static void formatRetrieveActivationStatusResponse(RetrieveActivationStatusUIResponse uiResponse,
			RetrieveActivationStatusPEGAResponse pegaResponse) {
		if (pegaResponse.getServiceHeader() != null)
			uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
		if (pegaResponse.getServiceBody() != null) {
			RetrieveActivationStatusServiceBody serviceBody = pegaResponse.getServiceBody();
            formatResponseForBBPChannel(pegaResponse.getServiceHeader(),serviceBody.getServiceResponse());
            uiResponse.setServiceBody(serviceBody);
		}
		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			uiResponse.setErrors(cartError);
		}
	}

	/**
	 * 
	 * @param uiResponse
	 * @param pegaResponse
	 */
	public static void formatRemoveBvoOffersResponse(UpdateBvoOffersUIResponse uiResponse,
			UpdateBvoOffersPEGAResponse pegaResponse) {
		if (pegaResponse.getServiceHeader() != null)
			uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
		if (pegaResponse.getServiceBody() != null) {
			UpdateBvoOffersServiceBody serviceBody = pegaResponse.getServiceBody();
			uiResponse.setServiceBody(serviceBody);
		}
		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			uiResponse.setErrors(cartError);
		}
	}
	
	/**
	 * 
	 * @param uiResponse
	 * @param pegaResponse
	 */
	public static void formatUpdateSellerPriceResponse(UpdateSellerPriceUIResponseNew uiResponse,
			UpdateSellerPricePEGAResponse pegaResponse) {
		if (pegaResponse.getServiceHeader() != null)
			uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
		if (pegaResponse.getServiceBody() != null) {
			UpdateSellerPriceServiceBody serviceBody = pegaResponse.getServiceBody();
			uiResponse.setServiceBody(serviceBody);
		}
		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			uiResponse.setErrors(cartError);
		}
	}

	//method to hide sensitive data for BBP channel
	public static void formatResponseForBBPChannel(ServiceHeader serviceHeader, ServiceResponse serviceResponse) {
	    if (serviceHeader !=null && serviceResponse!=null) {
            if (serviceHeader.getClientId().equalsIgnoreCase(CartConstants.CHANNEL_ID_BBP)) {
                if (serviceResponse.getContext() != null) {
                    serviceResponse.getContext().setCaseId("");
                    if (serviceResponse.getContext().getCustomerInfo() != null)
                        serviceResponse.getContext().getCustomerInfo().setAccountNumber("");
                    if (serviceResponse.getContext().getCartInfo() != null)
                        serviceResponse.getContext().getCartInfo().setCartId("");
                }
            }
        }
    }

	public static void formatAffirmResponse(AffirmFinancingUIResponse soeResponse,
			AffirmFinancingPegaResponse pegaResponse) {
		if (pegaResponse.getServiceHeader() != null)
			soeResponse.setServiceHeader(pegaResponse.getServiceHeader());
		if (pegaResponse.getServiceBody() != null) {
			AffirmFinancingResponseServiceBody serviceBody = pegaResponse.getServiceBody();
			soeResponse.setServiceBody(serviceBody);
		}
		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			soeResponse.setErrors(cartError);
		}		
	}
	
	/**
	 * 
	 * @param soeResponse
	 * @param pegaResponse
	 */
	public static void formatOrderReviewTYSResponse(ReviewOrderTYSUIResponse soeResponse,
			ReviewOrderPegaResponse pegaResponse) {
		if (pegaResponse.getServiceHeader() != null)
			soeResponse.setServiceHeader(pegaResponse.getServiceHeader());
		if (pegaResponse.getServiceBody() != null) {
			soeResponse.setServiceBody(pegaResponse.getServiceBody());
		}
		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			soeResponse.setErrors(cartError);
		}
	}
	/**
	 *
	 * @param pegaResponse
	 * @param soeResponse
	 */
	public static void formatAddPromoIntentResponse(AddPromoIntentPEGAResponse pegaResponse,
													AddPromoIntentUIResponse soeResponse) {
		if (pegaResponse.getServiceHeader() != null)
			soeResponse.setServiceHeader(pegaResponse.getServiceHeader());
		if (pegaResponse.getServiceBody() != null) {

			AddPromoIntentServiceBody serviceBody = pegaResponse.getServiceBody();
			soeResponse.setServiceBody(serviceBody);
		}

		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			soeResponse.setErrors(cartError);
		}
	}

		public static void formatAddZipcodeResponse(BBPAddZipcodeResponse soeResponse, AddZipcodePEGAResponse pegaResponse) {
		if (pegaResponse.getServiceHeader() != null)
			soeResponse.setServiceHeader(pegaResponse.getServiceHeader());

		if (CollectionUtilities.isNotEmptyOrNull(pegaResponse.getErrors())) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			soeResponse.setErrors(cartError);
		}

		if (pegaResponse.getServiceBody() != null) {
			AddZipcodeServiceBody serviceBody = pegaResponse.getServiceBody();
			if(serviceBody.getServiceResponse()!=null && serviceBody.getServiceResponse().getContext()!=null && serviceBody.getServiceResponse().getContext().getCaseId()!=null) {
				serviceBody.getServiceResponse().getContext().setCaseId("");
			}
			if(serviceBody.getServiceResponse()!=null && serviceBody.getServiceResponse().getContext()!=null && serviceBody.getServiceResponse().getContext().getCartInfo()!=null && serviceBody.getServiceResponse().getContext().getCartInfo().getCartId()!=null) {
				serviceBody.getServiceResponse().getContext().getCartInfo().setCartId("");
			}
			soeResponse.setServiceBody(serviceBody);
		}
	}

	public static void formatAddUpgradeDetailsResponse(AddDeviceUIResponse uiResponse, AddDevicePEGAResponse pegaResponse) {
		if (pegaResponse.getServiceHeader() != null)
			uiResponse.setServiceHeader(pegaResponse.getServiceHeader());

		if (CollectionUtilities.isNotEmptyOrNull(pegaResponse.getErrors())) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			uiResponse.setErrors(cartError);
		}

		if (pegaResponse.getServiceBody() != null) {
			AddDeviceServiceBody serviceBody = pegaResponse.getServiceBody();
			uiResponse.setServiceBody(serviceBody);
		}
	}

	/**
	 *
	 * @param uiResponse
	 * @param pegaResponse
	 */
	public static void formatAddPayOffDetailsUIResponse(AddPayOffDetailsUIResponse uiResponse,
													AddPayOffDetailsPEGAResponse pegaResponse) {
		if (pegaResponse.getServiceHeader() != null)
			uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
		if (pegaResponse.getServiceBody() != null) {
			PayOffDetailsServiceBody serviceBody = pegaResponse.getServiceBody();
			uiResponse.setServiceBody(serviceBody);
		}
		if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
			List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
			uiResponse.setErrors(cartError);
		}
	}
}
