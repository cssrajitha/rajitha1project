package onevz.soe.cart.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper;
import onevz.soe.cart.bpm.service.CartServiceBPMServices;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.common.Address;
import onevz.soe.cart.responses.AutoPayPegaResponse;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.bpm.model.Context;
import onevz.soe.wsclient.bpm.model.CustomerInfo;
import onevz.soe.wsclient.bpm.model.ServiceHeader;
import onevz.soe.wsclient.bpm.model.request.ContextInfo;
import onevz.soe.wsclient.bpm.model.response.ServiceResponse;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import reactor.core.CoreSubscriber;
import reactor.core.publisher.Mono;
import onevz.soe.cart.ui.requests.AutoPayUIRequest;
import onevz.soe.cart.requests.AutoPayPegaRequest;
import jakarta.validation.Valid;
import java.text.SimpleDateFormat;
import java.util.*;
import onevz.soe.wsclient.bpm.model.ServiceBody;
import onevz.soe.wsclient.bpm.model.request.ServiceRequest;
import onevz.soe.cart.requests.ContactDetails;
import onevz.soe.cart.gql.requests.PaymentInfo;
import onevz.soe.orderprocess.model.checkoutdetails.CreditCardPayment;
import onevz.soe.cart.model.autoPay.AutoPayContext;
import onevz.soe.cart.model.autoPay.AutoPayCartInfo;
import onevz.soe.cart.requests.PaymentData;


@RestController
@RequestMapping(value = "cart")
public class AutoPayController {

    private static final Logger logger = LoggerFactory.getLogger(AutoPayController.class);




    @Autowired
    CartServiceBPMServices cartBPMService;

    @Autowired
    SOELoginSessionBean soeLoginSessionBean;

    @Autowired
    CartServiceBpmHelper cartServiceBpmHelper;

    @PostMapping("/autoPayFlow")
    public Mono<AutoPayPegaResponse> autoPayFlow(ServerHttpRequest httpRequest, ServerHttpResponse httpResponse,
                                                          @RequestBody AutoPayUIRequest request)
    {
        Mono<AutoPayPegaResponse> autoPayUIResponse=null;
        try
        {
            String channelId = httpRequest.getHeaders().containsKey(CartConstants.CHANNEL_ID) ? httpRequest.getHeaders().getFirst(CartConstants.CHANNEL_ID): "";
            autoPayUIResponse=cartServiceBpmHelper.autoPayFlow(request,channelId );
        }
        catch(Exception e)
        {
            logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
        }

        return autoPayUIResponse;
    }

    @InitBinder("*")
    public void initBinderByName(WebDataBinder binder) {
        binder.setDisallowedFields(new String[] { "genericHeader" });
    }
}
