package onevz.soe.cart.controller;

import onevz.soe.cart.helper.BulkUpdateAIQuoteHelper;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.bulkcartupdate.BulkQuoteUIRequest;
import onevz.soe.cart.model.bulkcartupdate.BulkQuoteUIResponse;
import onevz.soe.cart.util.CartUtil;
import onevz.soe.utilities.StringUtilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping(value = "cart")
public class BulkUpdateAIQuoteController {

    private static final Logger logger = LoggerFactory.getLogger(BulkUpdateAIQuoteController.class);

    @Autowired
    BulkUpdateAIQuoteHelper bulkUpdateAIQuoteHelper;

    @PostMapping({ "/bulkUpdateAIQuote" })
    public Mono<ResponseEntity<GenericResponse>> bulkUpdateCartServices(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse,
                                                                        @RequestBody BulkQuoteUIRequest request) throws Exception {
        String channelId = getChannelId(httpHeader);
        request.setChannelId(channelId);
        String sessionId = getSessionId(httpHeader, channelId);
        if (StringUtilities.isNotEmptyOrNull(String.valueOf(httpHeader.getURI())) && CartUtil.isFlexV2(String.valueOf(httpHeader.getURI()))) {
            request.getCartInfo().setFlexV2(true);
        }
        return bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request,sessionId).flatMap(resp->{
            logger.info("Response received from helper is {}",resp);
            ErrorResponse errors = null;
            if (resp.getErrors() != null) {
                errors = handleBulkUpdateCartServicesErrors(resp);
                return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(errors));
            }
            return Mono.just(ResponseEntity.status(HttpStatus.OK).body(resp));
        });
    }

    private String getChannelId(ServerHttpRequest httpHeader) {
        return httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID) ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID) : "";
    }

    private String getSessionId(ServerHttpRequest httpHeader, String channelId) {
        String sessionId = "";
        String channelType = CartUtil.getChannelType(channelId);
        HttpCookie cookieDigitIgSession = httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION);
        if (CartConstants.DIGITAL.equalsIgnoreCase(channelType)
                || CartConstants.EXPRESS_STORE.equalsIgnoreCase(channelType))
            sessionId = null != cookieDigitIgSession ? cookieDigitIgSession.getValue() : "";
        return sessionId;
    }

    public static ErrorResponse handleBulkUpdateCartServicesErrors(BulkQuoteUIResponse resp) {
        ErrorResponse errors = null;
        List<CartError> errorList = new ArrayList<>();
        if (resp.getErrors() != null) {
            errors = new ErrorResponse();
            for (CartError cxpError : resp.getErrors()) {
                CartError error = cxpError;
                errorList.add(error);
            }
            errors.setErrors(errorList);
        }
        return errors == null ? new ErrorResponse() : errors;
    }
}
