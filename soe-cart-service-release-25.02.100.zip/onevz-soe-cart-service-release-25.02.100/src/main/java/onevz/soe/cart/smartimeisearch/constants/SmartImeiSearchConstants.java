package onevz.soe.cart.smartimeisearch.constants;

public interface SmartImeiSearchConstants {

    String TYPE = "best_fields";
    String MAKE = "make_typeahead";
    String MODEL = "model_name_typeahead";
    String DEVICE_CATEGORY_TYPE_AHEAD = "device_category_typeahead";
    String SITE_ID = "site_id";
    String SOR_DISPLAY_NAME = "sor_display_name";
    String SKU_CARRIER = "skus.carrier";
    String EUICC_CAPABLE="euicc_capable";
    String SKUS = "skus";
    String SITE_ID_VALUE = "400001";
	String ENABLED_FLAG = "Y";
	String DIDYOUMEAN = "didYouMean";
	String DID_YOU_MEAN = "did_you_mean";
	String CARRIER = "carrier";
	String SMARTPHONE = "Smartphone";
}
