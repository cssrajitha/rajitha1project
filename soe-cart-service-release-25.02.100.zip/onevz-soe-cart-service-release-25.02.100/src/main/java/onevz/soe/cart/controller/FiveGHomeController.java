package onevz.soe.cart.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.gql.schema.LineInfo;
import onevz.soe.cart.gql.schema.ServiceInfo;
import onevz.soe.cart.helper.*;
import onevz.soe.cart.model.addTruckRoll.AddTruckRollCartResponseContext;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.common.FieldValidationException;
import onevz.soe.cart.model.common.FiveG.CartServiceCartInfo;
import onevz.soe.cart.model.common.FiveG.Line;
import onevz.soe.cart.model.retrieveCart.CXPRetrieveCartDataVO;
import onevz.soe.cart.model.retrieveCart.fiveG.CXPOrderDetailsView;
import onevz.soe.cart.model.reviewOrderInsipico.InspicioResponseOrderInfo;
import onevz.soe.cart.model.reviewOrderInsipico.InspicioTermsAndConditions;
import onevz.soe.cart.model.reviewOrderInsipico.ReviewOrderData;
import onevz.soe.cart.requests.CheckoutDetailsRequest;
import onevz.soe.cart.requests.GetCartDetailsRequest;
import onevz.soe.cart.requests.RetrieveCartCXPRequest;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.AddPlanAndDeviceUIResponse;
import onevz.soe.cart.util.CartPegaResponseErrorsUtil;
import onevz.soe.cart.util.CartPegaResponseErrorsUtil2;
import onevz.soe.cart.util.CartUtil;
import onevz.soe.constants.SOEConstants;
import onevz.soe.logging.util.LoggerUtil;
import onevz.soe.omnidl.util.DLUtilityService;
import onevz.soe.orderprocess.util.CheckoutConstants;
import onevz.soe.utilities.StringUtilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;


/**
 * Cart Controller class.
 */
@RestController
@RequestMapping(value = "cart")
public class FiveGHomeController {

    private static final Logger logger = LoggerFactory.getLogger(FiveGHomeController.class);

    @Autowired
    private FiveGhomeCommonHelper fiveGhomeCommonHelper;

    @Autowired
    private FiveGhomeNSEHelper fiveGhomeNSEHelper;

    @Autowired
    private FiveGhomeAALHelper fiveGhomeAALHelper;

    @Autowired
    private RedisHelper redisHelper;

    @Autowired
    private RedisHelper2 redisHelper2;

    @Autowired
    private RedisHelper3 redisHelper3;

    @Autowired
    private DLUtilityService dlUtilityService;

    @Autowired
    private UpdateCartHelper updateCartHelper;

    @Autowired
    private RemoveHomePhoneHelper removeHomePhoneHelper;

    @Autowired
    UpdateCartWithDatesHelper updateCartWithDatesHelper;

    @Autowired
    private FiveGhomeTechHelper fiveGhomeTechHelper;

    @Autowired
    private ObjectMapper mapper;

    @Value("${sessionCreation.domain:.verizonwireless.com}")
    private String domainName;

    /**
     * @param binder
     */
    @InitBinder("*")
    public void initBinderByName(WebDataBinder binder) {
        binder.setDisallowedFields("genericHeader");
    }

    /**
     * @param httpHeader
     * @param httpResponse
     * @param request
     * @return ResponseEntity
     */
    @PostMapping(path = {"/5g/retrieve-cart", "/nse/5g/retrieve-cart","/5g/cbd/retrieve-cart"})
    public Mono<ResponseEntity<GetCartDetailsUIResponse>> retrieveFiveGCart(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse,
                                                                            @RequestBody GetCartDetailsRequest request) {
        logger.debug(CartConstants.RETRIEVE_CART_REQUEST_LOG, request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        String cjevent = null != httpHeader.getCookies().getFirst(CartConstants.CJEVENT) ? Objects.requireNonNullElse(httpHeader.getCookies().getFirst(CartConstants.CJEVENT), new HttpCookie(CartConstants.CJEVENT, "")).getValue() :  "";
        String affiliate = null != httpHeader.getCookies().getFirst(CartConstants.AFFILIATE) ? Objects.requireNonNullElse(httpHeader.getCookies().getFirst(CartConstants.AFFILIATE), new HttpCookie(CartConstants.AFFILIATE,"")).getValue() : "";
        String igSessionKey = CartUtil.isDigital(channelId) ? CartConstants.DIGITAL_IG_SESSION : CartConstants.ASSISTED_IG_SESSION_ID;
        String sessionId = null != httpHeader.getCookies().getFirst(igSessionKey) ? Objects.requireNonNullElse(httpHeader.getCookies().getFirst(igSessionKey), new HttpCookie(igSessionKey,"")).getValue() : "";
        request.setIgSession(sessionId);

        if(StringUtilities.isNotEmptyOrNull(cjevent) && StringUtilities.isNotEmptyOrNull(affiliate)){
            request.setCjevent(cjevent);
            request.setAffiliate(affiliate);
        }
        request.setChannelId(channelId);
        if (request.getData().isValidateCart()) {
            logger.debug("validateCart flow in retrieveCart with request {}: ", request);
            return fiveGhomeAALHelper.get5GValidateCart(request, httpResponse);
        } else {
            return fiveGhomeNSEHelper.get5GCart(request);
        }


    }
    @PostMapping(path = {"/5g/getDueMonthlyAndDueToday", "/nse/5g/getDueMonthlyAndDueToday"})
    public Mono<GetCartDetailsUIResponse> getDueMonthlyAndDueToday(@RequestBody GetCartDetailsRequest request) {
        logger.info("started getDueMonthlyAndDueToday method.");
        return fiveGhomeNSEHelper.get5GCart(request).flatMap(getCartDetailsUIResponseResponseEntity -> {
            GetCartDetailsUIResponse response = new GetCartDetailsUIResponse();
            GetCartDetailsUIResponse body = getCartDetailsUIResponseResponseEntity.getBody();
            CXPOrderDetailsView orderDetailsView = body.getOrderDetailsView();
            if(null != orderDetailsView) {
                response.setDueTodayAmount(orderDetailsView.getDueTodayAmount());
                response.setDueMonthlyAmount(orderDetailsView.getDueMonthlyAmount());
            } else if (body.getErrors() != null) {
                response.setErrors(body.getErrors());
            }
            return Mono.just(response);
        });

    }
    @SuppressWarnings("deprecation")
    @PostMapping(path = {"/5g/updateCart", "/nse/5g/updateCart", "/5g/cbd/update-cart"}, consumes = "application/json", produces = "application/json")
    public Mono<ResponseEntity<GenericResponse>> addPlanAndDevice(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse,
                                                                  @RequestBody AddPlanAndDeviceUIRequest request) {
        logger.info("Add plan and device request Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);
        String sessionId = "";
        String rylEcpdUrl = "";
        String ecpdToken = "";
        String mucFlow = "";
        // add condition for expressStore
        fiveGhomeCommonHelper.populateCartCreator(httpHeader, request);
        String channelType = CartUtil.getChannelType(channelId);
        if (CartConstants.DIGITAL.equalsIgnoreCase(channelType)
                || CartConstants.EXPRESS_STORE.equalsIgnoreCase(channelType))
            if(httpHeader.getCookies()!=null){
                sessionId = null != httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION)
                        ? Objects.requireNonNull(httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION)).getValue()
                        : "";
                rylEcpdUrl = null != httpHeader.getCookies().getFirst(CartConstants.COOKIE_ECPD_DOMAIN)
                        ? Objects.requireNonNull(httpHeader.getCookies().getFirst(CartConstants.COOKIE_ECPD_DOMAIN)).getValue()
                        : "";
                ecpdToken = null != httpHeader.getCookies().getFirst(CartConstants.COOKIE_ECPD_TOKEN)
                        ? Objects.requireNonNull(httpHeader.getCookies().getFirst(CartConstants.COOKIE_ECPD_TOKEN)).getValue()
                        : "";
                mucFlow =  null != httpHeader.getCookies().getFirst(CartConstants.MUC_FLOW)
                        ? Objects.requireNonNull(httpHeader.getCookies().getFirst(CartConstants.MUC_FLOW)).getValue()
                        : "";
            }
        if (!StringUtils.isEmpty(ecpdToken)) {
            String[] values = ecpdToken.split(":");
            if (null != values && values.length >= 4) {
                ecpdToken = values[3];
            }
        }
        logger.info("ecpdcookie & domainCookie {} & {}", ecpdToken,rylEcpdUrl);
        String finalSessionId = sessionId;
        if(request.getCartInfo() != null) {
            request.getCartInfo().setSessionId(sessionId);
            request.getCartInfo().setRylEcpdUrl(rylEcpdUrl);
            request.getCartInfo().setEcpdToken(ecpdToken);
            if(mucFlow != null && "Y".equalsIgnoreCase(mucFlow)){
                request.getCartInfo().setFiveGMUCEligible("true");
            }
            logger.info("FiveGMUCEligible {}", request.getCartInfo().getFiveGMUCEligible());
        }
        return fiveGhomeCommonHelper.addPlanAndDevice(request).flatMap(pegaResponse -> {
            ErrorResponse errors2 = null;
            if (pegaResponse.getErrors() != null && null != pegaResponse.getErrors().get(0) && StringUtilities.isNotEmptyOrNull(pegaResponse.getErrors().get(0).getMessage()) &&
                    ! pegaResponse.getErrors().get(0).getMessage().equalsIgnoreCase("FiveG qualified address is not available. Please select one.")) {
                errors2 = CartPegaResponseErrorsUtil2.handleAddDeviceResponseErrorsFiveGHome(pegaResponse);
                if(CartConstants.ORDER_NOW.equalsIgnoreCase(request.getCartInfo().getProcessStep()) && StringUtilities.isEmptyOrNull(request.getCartInfo().getAction())) {
                    httpResponse.addCookie(ResponseCookie.from("expressCheckout",CartConstants.N ).path(SOEConstants.SESSION_PATH).domain(domainName).httpOnly(false).build());
                }
                if(org.apache.commons.lang3.StringUtils.isNotBlank(request.getChannelId()) && CartConstants.DIGITAL_DDOT_MOB_TAB_CHANNELS.contains(channelId) )
                    CartPegaResponseErrorsUtil.setErrorCategory(errors2,CartConstants.ERRCAT_CJCM);
                return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errors2));
            } else {
                String flowPath = String.valueOf(httpHeader.getPath());
                CartRedisData rr = new CartRedisData();
                rr.setAccountNumber(request.getCartInfo().getAccountNumber());
                if (request.getCartInfo().getIntendType() != null)
                    rr.setIntendType(request.getCartInfo().getIntendType());
                if (request.getCartInfo().getCartCreator() != null)
                    rr.setCartCreator(request.getCartInfo().getCartCreator());
                if (request.getCartInfo().getCovidQuestionareAnswered() != null && "true".equalsIgnoreCase(String.valueOf(request.getCartInfo().getCovidQuestionareAnswered())))
                    rr.setCovidQuestionareAnswered("Y");
                String cartCookieName = StringUtilities.isNotEmptyOrNull(rr.getAccountNumber())? CheckoutConstants.FWA_AAL_CART_COOKIE : CheckoutConstants.FWA_PROSPECT_CART_COOKIE;
                httpResponse.addCookie(ResponseCookie.from(cartCookieName, "Y").path(SOEConstants.SESSION_PATH).domain(domainName).httpOnly(false).build());
                if (pegaResponse.getServiceBody() != null && (!CartConstants.ASSISTED.equalsIgnoreCase(channelType)
                        && pegaResponse.getServiceBody().getServiceResponse().getContext() != null)) {
                    rr.setCaseId(pegaResponse.getServiceBody().getServiceResponse().getContext().getCaseId());
                    pegaResponse.getServiceBody().getServiceResponse().getContext().setCaseId(null);
                    if (!CartConstants.ASSISTED.equalsIgnoreCase(channelType) && pegaResponse.getServiceBody()
                            .getServiceResponse().getContext().getCartInfo() != null) {
                        rr.setCartId(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()
                                .getCartId());
                        if(StringUtilities.isNotEmptyOrNull(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartId()))
                        {
                            pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setCartExist("Y");
                        }
                        else
                        {
                            pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setCartExist("N");
                        }
                        pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setCartId(null);
                        if (StringUtilities.isNotEmptyOrNull(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()
                                .getEcpdProfileId())) {
                            rr.setEcpdId(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()
                                    .getEcpdProfileId());
                        }
                        if (pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()
                                .getLines() != null) {
                            Line[] lines = pegaResponse.getServiceBody().getServiceResponse().getContext()
                                    .getCartInfo().getLines();

                            if (null != lines && lines.length > 0
                                    && StringUtilities.isNotEmptyOrNull(lines[0].getMtn())) {
                                rr.setProcessingMTN(lines[0].getMtn());
                            }
                        }
                        boolean isFWAExpressCheckout = pegaResponse.getServiceBody().getServiceResponse().getContext().getCustomerInfo().getFwaExpressCheckout();
                        if(CartConstants.ORDER_NOW.equalsIgnoreCase(request.getCartInfo().getProcessStep()) && StringUtilities.isEmptyOrNull(request.getCartInfo().getAction())) {
                            httpResponse.addCookie(ResponseCookie.from("expressCheckout", isFWAExpressCheckout ? CartConstants.Y : CartConstants.N ).path(SOEConstants.SESSION_PATH).domain(domainName).httpOnly(false).build());
                        }
                    } else if (CartConstants.INTENT_EUP_LTE.equalsIgnoreCase(request.getCartInfo().getIntendType()) && "OrderNow".equalsIgnoreCase(request.getCartInfo().getProcessStep())) {
                        rr.setCartId(request.getCartInfo().getCartId());
                        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
                        cartInfo.setCartId(request.getCartInfo().getCartId());
                        pegaResponse.getServiceBody().getServiceResponse().getContext().setCartInfo(cartInfo);
                    }
                    if (pegaResponse.getServiceBody().getServiceResponse().getContext()
                            .getShowAALPromoIntercept() != null)
                        rr.setShowAALPromoIntercept(pegaResponse.getServiceBody().getServiceResponse().getContext()
                                .getShowAALPromoIntercept());
                    if (null != pegaResponse.getServiceBody().getServiceResponse().getContext().getContextInfo()) {
                        rr.setProcessStep(pegaResponse.getServiceBody().getServiceResponse().getContext()
                                .getContextInfo().getProcessStep());
                    }
                }
                if(request.getCartInfo() != null && request.getCartInfo().getFlowType() != null && !(request.getCartInfo().getFlowType().equalsIgnoreCase(CartConstants.FLOW_TYPE_WHW))){
                    rr.setLines(fiveGhomeCommonHelper.transform5GLinesDatatoBAU(request.getData().getLines()));
                }
                rr.setDeviceCartInfo(fiveGhomeCommonHelper.transform5GCartDatatoBAU(request.getCartInfo()));
                rr.setSpokeJourney(CartConstants.FALSE);
                rr.setTransactionType(request.getCartInfo().getTransactionType());
                if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessingMTN()))
                    rr.setProcessingMTN(request.getCartInfo().getProcessingMTN());
                if(StringUtilities.isNotEmptyOrNull(request.getMidnight()))
                    rr.setMidnight(request.getMidnight());

                if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId())))
                    return redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(rr, CartConstants.DEVICE).flatMap(redisData -> {
                        try {
                            logger.info("Inside DL update");

                            if (request.getCartInfo().getIntendType() != null) {
                                if (CartConstants.BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType()))
                                    dlUtilityService.updateDlData(CartConstants.NSO);
                                else
                                    dlUtilityService.updateDlData(request.getCartInfo().getIntendType().toLowerCase());
                            }
                            // Adding for new customer DL object update
                            if (flowPath != null && !flowPath.isEmpty() && flowPath.contains(CartConstants.ADD_DEVICE_ENDPOINT)) {
                                List<HttpCookie> globalId = httpHeader.getCookies().get("GLOBALID");
                                String globalIdVal = globalId != null && !globalId.isEmpty()
                                        ? globalId.get(0).getValue()
                                        : "";
                                logger.info(finalSessionId != null ? finalSessionId : "Empty");
                                logger.info(globalIdVal);

                            }
                        } catch (Exception e) {
                            logger.error(CartConstants.DL_UTILITY_EXCEPTION);
                        }
                        if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId))
                                && httpResponse.getStatusCode().equals(HttpStatus.PARTIAL_CONTENT)) {
                            for (CartError errorResp : pegaResponse.getErrors()) {
                                if ("3226".equals(errorResp.getId())) {
                                    httpResponse.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR);
                                }
                            }
                        }
                        return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(pegaResponse));
                    });
                return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(pegaResponse));
            }


        });
    }

    @PostMapping(path={"/5g/validate-apply-coupon", "/nse/5g/validate-apply-coupon"})
    public Mono<ResponseEntity<GenericResponse>> validateAndApplyCoupon(ServerHttpRequest reqHeader, ServerHttpResponse resHeader,
                                                                        @RequestBody FWAUpdateCouponUIRequest pcouponCodeUIRequest) throws JsonProcessingException {
        logger.debug("Inside the validateAndApplyCoupon Method with Request : {}", pcouponCodeUIRequest);
        logger.info("Inside the validateAndApplyCoupon Method..");
        if(null != reqHeader.getCookies()) {
            String visibleTest = null != reqHeader.getCookies().getFirst("visibleTest")? Objects.requireNonNull(reqHeader.getCookies().getFirst("visibleTest")).getValue():"";
            if(StringUtilities.isNotEmptyOrNull(visibleTest)) {
                Mono<ResponseEntity<GenericResponse>> responseEntityMono = populateAndReturnDummyResponse(visibleTest);
                return responseEntityMono.switchIfEmpty(fiveGhomeCommonHelper.validateAndUpdateCouponToCart(pcouponCodeUIRequest)
                        .flatMap(response -> Mono.just(ResponseEntity.status(resHeader.getStatusCode())
                                .body(response)))).doOnSuccess(resp -> Mono.just(resp));
            }
        }
        return fiveGhomeCommonHelper.validateAndUpdateCouponToCart(pcouponCodeUIRequest)
                .flatMap(response -> Mono.just(ResponseEntity.status(resHeader.getStatusCode())
                        .body(response)));
    }

    public Mono<ResponseEntity<GenericResponse>> populateAndReturnDummyResponse(String visibleTest) throws JsonProcessingException {
        String stringRes =null;
        if(null != visibleTest && visibleTest.equalsIgnoreCase("s1") ) {
            stringRes = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.10.20.08.34.44-784.7116947219431\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-10366523-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"addPromoCode\",\"intent\":\"NSE_LTE\"},\"customerInfo\":{\"throttleName\":\"|\",\"bucketAllocator\":\"BAU\",\"accountNumber\":\"0580569855-00001\",\"cartCreator\":\"6122705939\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"customerIpAddress\":\"\"},\"cartInfo\":{\"statusMsg\":\"Barcode validated successfully\",\"statusCode\":1,\"itemType\":\"OFFERCODE\",\"chatId\":\"\",\"promoType\":\"VISIBLE_PREPAID_FWA_COUPON\",\"redemptionCode\":\"PRPDH0002DI01BB\",\"subscriptionType\":\"\",\"intendType\":\"NSE\",\"cartId\":\"57bf6fac-bc30-4bc5-b967-c0c8e03a82f2\",\"includeExpiryBarcodeStatus\":\"\",\"action\":\"UPDATE\"}}}}}";
        }else if (null != visibleTest && visibleTest.equalsIgnoreCase("e1")) {
            stringRes= "{\"errors\":[{\"namespace\":\"cxp-shopping-services\",\"name\":\"SYSTEM_ERROR\",\"id\":\"3418\",\"debug_id\":\"2022-10-16T13:48:30.+0000:72886054194ce33e:cxp-shopping-services-659d78dbdc-s2fx4:eksnsprode\",\"message\":\"PROMO CODE Invalid \",\"category\":\"BUSINESS_ERR\"}]}";
        } else if (null != visibleTest && visibleTest.equalsIgnoreCase("e2")) {
            stringRes= "{\"errors\":[{\"namespace\":\"cxp-shopping-services\",\"name\":\"SYSTEM_ERROR\",\"id\":\"15510\",\"debug_id\":\"2022-10-16T13:48:30.+0000:72886054194ce33e:cxp-shopping-services-659d78dbdc-s2fx4:eksnsprode\",\"message\":\"Promo code doesn't qualify for this order \",\"category\":\"BUSINESS_ERR\"}]}";
        }
        if(StringUtilities.isNotEmptyOrNull(stringRes))
            return Mono.just(ResponseEntity.status(200).body(mapper.readValue(stringRes, AddPlanAndDeviceUIResponse.class)));
        return Mono.empty();
    }

    @PostMapping(path = {"/5g/updateProcessStep", "/nse/5g/updateProcessStep"}, consumes = "application/json", produces = "application/json")
    public Mono<ResponseEntity<GenericResponse>> updateProcessStep(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse,
                                                                   @RequestBody AddPlanAndDeviceUIRequest request) {

        logger.debug("update Process Step Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);
        String sessionId = "";
        String rylEcpdUrl = "";
        String ecpdToken = "";
        // add condition for expressStore
        fiveGhomeCommonHelper.populateCartCreator(httpHeader, request);
        String channelType = CartUtil.getChannelType(channelId);
        if (CartConstants.DIGITAL.equalsIgnoreCase(channelType)
                || CartConstants.EXPRESS_STORE.equalsIgnoreCase(channelType))
            if(httpHeader.getCookies()!=null){
                sessionId = null != httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION)
                        ? Objects.requireNonNull(httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION)).getValue()
                        : "";
                rylEcpdUrl = null != httpHeader.getCookies().getFirst(CartConstants.COOKIE_ECPD_DOMAIN)
                        ? Objects.requireNonNull(httpHeader.getCookies().getFirst(CartConstants.COOKIE_ECPD_DOMAIN)).getValue()
                        : "";
                ecpdToken = null != httpHeader.getCookies().getFirst(CartConstants.COOKIE_ECPD_TOKEN)
                        ? Objects.requireNonNull(httpHeader.getCookies().getFirst(CartConstants.COOKIE_ECPD_TOKEN)).getValue()
                        : "";
            }
        logger.info("ecpdcookie & domainCookie {} ", ecpdToken + " & " + rylEcpdUrl);
        String finalSessionId = sessionId;
        request.getCartInfo().setSessionId(sessionId);
        request.getCartInfo().setRylEcpdUrl(rylEcpdUrl);
        request.getCartInfo().setEcpdToken(ecpdToken);


        return fiveGhomeCommonHelper.addPlanAndDevice(request).flatMap(pegaResponse -> {
            ErrorResponse errors2 = null;
            if (pegaResponse.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil2.handleAddDeviceResponseErrorsFiveGHome(pegaResponse);
                if(org.apache.commons.lang3.StringUtils.isNotBlank(request.getChannelId()) && CartConstants.DIGITAL_DDOT_MOB_TAB_CHANNELS.contains(channelId) )
                    CartPegaResponseErrorsUtil.setErrorCategory(errors2,CartConstants.ERRCAT_CJCM);
                return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errors2));
            } else {
                String flowPath = String.valueOf(httpHeader.getPath());
                if (flowPath != null && !flowPath.isEmpty() && flowPath.contains("/cart/nse/add-device"))
                    httpResponse.addCookie(
                            ResponseCookie.from("prospectCartAvailable", "true").path("/").httpOnly(false).build());
                CartRedisData rr = new CartRedisData();
                rr.setAccountNumber(request.getCartInfo().getAccountNumber());
                if (request.getCartInfo().getIntendType() != null)
                    rr.setIntendType(request.getCartInfo().getIntendType());
                if (request.getCartInfo().getCartCreator() != null)
                    rr.setCartCreator(request.getCartInfo().getCartCreator());
                if (request.getCartInfo().getCovidQuestionareAnswered() != null && "true".equalsIgnoreCase(String.valueOf(request.getCartInfo().getCovidQuestionareAnswered())))
                    rr.setCovidQuestionareAnswered("Y");

                if (pegaResponse.getServiceBody() != null && !CartConstants.ASSISTED.equalsIgnoreCase(channelType)
                        && pegaResponse.getServiceBody().getServiceResponse().getContext() != null) {
                    rr.setCaseId(pegaResponse.getServiceBody().getServiceResponse().getContext().getCaseId());
                    pegaResponse.getServiceBody().getServiceResponse().getContext().setCaseId(null);
                    if (!CartConstants.ASSISTED.equalsIgnoreCase(channelType) && pegaResponse.getServiceBody()
                            .getServiceResponse().getContext().getCartInfo() != null) {
                        rr.setCartId(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()
                                .getCartId());
                            if(StringUtilities.isNotEmptyOrNull(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartId()))
                            {
                                pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setCartExist("Y");
                            }
                            else
                            {
                                pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setCartExist("N");
                            }
                            pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setCartId(null);
                        if (StringUtilities.isNotEmptyOrNull(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()
                                .getEcpdProfileId())) {
                            rr.setEcpdId(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()
                                    .getEcpdProfileId());
                        }
                    } else if (CartConstants.INTENT_EUP_LTE.equalsIgnoreCase(request.getCartInfo().getIntendType()) && "OrderNow".equalsIgnoreCase(request.getCartInfo().getProcessStep())) {
                        rr.setCartId(request.getCartInfo().getCartId());
                        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
                        cartInfo.setCartId(request.getCartInfo().getCartId());
                        pegaResponse.getServiceBody().getServiceResponse().getContext().setCartInfo(cartInfo);
                    }
                    if (pegaResponse.getServiceBody().getServiceResponse().getContext()
                            .getShowAALPromoIntercept() != null)
                        rr.setShowAALPromoIntercept(pegaResponse.getServiceBody().getServiceResponse().getContext()
                                .getShowAALPromoIntercept());
                    if (null != pegaResponse.getServiceBody().getServiceResponse().getContext().getContextInfo()) {
                        rr.setProcessStep(pegaResponse.getServiceBody().getServiceResponse().getContext()
                                .getContextInfo().getProcessStep());


                    }
                }
                rr.setDeviceCartInfo(fiveGhomeCommonHelper.transform5GCartDatatoBAU(request.getCartInfo()));
                rr.setSpokeJourney(CartConstants.FALSE);
                if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessingMTN()))
                    rr.setProcessingMTN(request.getCartInfo().getProcessingMTN());

                return redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(rr, CartConstants.DEVICE).flatMap(redisData -> {

                    if ( httpResponse.getStatusCode().equals(HttpStatus.PARTIAL_CONTENT)) {
                        for (CartError errorResp : pegaResponse.getErrors()) {
                            if ("3226".equals(errorResp.getId())) {
                                httpResponse.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR);
                            }
                        }
                    }
                    return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(pegaResponse));
                });
            }
        });
    }

    @PostMapping(path = {"/5g/saveCartWithEmail", "/nse/5g/saveCartWithEmail"})
    public Mono<ResponseEntity<GenericResponse>> saveCartWithEmail(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse,
                                                                   @RequestBody SaveCartWithEmailUIRequest request) {
        logger.debug("saveCartWithEmail Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);
        fiveGhomeCommonHelper.populateCartCreator(httpHeader, request);
        return fiveGhomeCommonHelper.saveCartWithEmail(request).flatMap(pegaResponse -> {
            ErrorResponse errors2 = null;
            if (pegaResponse.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil2.handleAddDeviceResponseErrorsFiveGHome(pegaResponse);
                return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errors2));
            } else {
                return Mono.just(ResponseEntity.status(HttpStatus.OK).body(pegaResponse));
            }
        });


    }


    @SuppressWarnings("deprecation")
    @PostMapping(value = {"/5g/crmResumeCart", "/nse/5g/crmResumeCart"})
    public Mono<ResponseEntity<GenericResponse>> crmRetrieveCart(ServerHttpRequest httpHeader,
                                                                 ServerHttpResponse httpResponse,
                                                                 @RequestBody CrmResumeCartUIRequest crmRequest) {
        String cartId = StringUtilities.isNotEmptyOrNull(crmRequest.getCartId())
                ? crmRequest.getCartId() : "";
        String emailId = StringUtilities.isNotEmptyOrNull(crmRequest.getEmailId())
                ? crmRequest.getEmailId() : "";
        String customerType=StringUtilities.isNotEmptyOrNull(crmRequest.getCustomerType())
                ? crmRequest.getCustomerType() : "";
        return redisHelper3.getAccountNumberFromRedis(crmRequest).doOnError(onError ->
                logger.error(" Unable to update request map value into Redis {}", "onError",onError)
        ).doOnSuccess(onSuccess ->
                logger.info("Successfully updated Cart Redis Data: {}", onSuccess)
        ).flatMap(accountNumber -> {
            if (StringUtils.isEmpty(cartId) || "".equals(cartId.trim())) {
                logger.error("Cart Id is Not Present");
            }
            logger.debug("crmRetrieveCart Cart Request: {}", cartId);
            return fiveGhomeCommonHelper.crmRetrieveCart(cartId, emailId,customerType,accountNumber, httpHeader).flatMap(pegaResponse -> {
                if(null != pegaResponse.getServiceBody() && null != pegaResponse.getServiceBody().getServiceResponse()
                        && null != pegaResponse.getServiceBody().getServiceResponse().getContext()
                        && null != pegaResponse.getServiceBody().getServiceResponse().getContext().getCasess()
                        && !pegaResponse.getServiceBody().getServiceResponse().getContext().getCasess().isEmpty() ) {
                    pegaResponse.getServiceBody().getServiceResponse().getContext().getCasess().stream().filter(Objects::nonNull).findFirst().ifPresent(cases -> {
                        if (StringUtilities.isNotEmptyOrNull(cases.getCaseID())) {
                            crmRequest.setCaseId(cases.getCaseID());
                        }
                        cases.setCaseID(null);
                        if (StringUtilities.isNotEmptyOrNull(cases.getCartId())) {
                            crmRequest.setCartId(cases.getCartId());
                            cases.setCartExist("Y");
                        }
                        else{
                            cases.setCartExist("N");
                        }
                        cases.setCartId(null);
                        if (StringUtilities.isNotEmptyOrNull(cases.getCartCreator())) {
                            crmRequest.setCartCreator(cases.getCartCreator());
                        }
                        if (StringUtilities.isNotEmptyOrNull(cases.getIntent())) {
                            crmRequest.setIntendType(cases.getIntent());
                        }
                    });
                } else {
                    ErrorResponse errors2 = null;
                    if (pegaResponse.getErrors() != null) {
                        errors2 = CartPegaResponseErrorsUtil2.handleCrmRetrieveResponseErrorsFiveGHome(pegaResponse);
                        return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errors2));
                    } else {
                        return Mono.just(ResponseEntity.status(HttpStatus.OK).body(pegaResponse));
                    }
                }
                return redisHelper3.updateCrmResumeDataIntoRedisAsString(crmRequest).doOnError(onError ->
                        logger.error(" Unable to update request map value into Redis {}","onError", onError)
                ).doOnSuccess(onSuccess ->
                        logger.info("Successfully updated Cart Redis Data: {}", onSuccess)
                ).flatMap(response -> {
                    ErrorResponse errors2 = null;
                    if (pegaResponse.getErrors() != null) {
                        errors2 = CartPegaResponseErrorsUtil2.handleCrmRetrieveResponseErrorsFiveGHome(pegaResponse);
                        return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errors2));
                    } else {
                        return Mono.just(ResponseEntity.status(HttpStatus.OK).body(pegaResponse));
                    }
                });
            });
        });

    }
    @PostMapping(path = {"/5g/removeHomePhone"})
    public Mono<Object> removeHomePhone(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse,
                                        @RequestBody RemoveHomePhoneUIRequest request) throws Exception {

        FieldValidationException validationError = removeHomePhoneHelper.validateUiRequest(request);
        if (validationError != null) {
            return Mono.just(validationError);
        }
        Mono<CartRedisData> redisData = redisHelper.getDataFromRedis();
        return redisData.flatMap(redisVal -> {
            try {
                if (StringUtilities.isNotEmptyOrNull(redisVal.getCartId())) {
                    request.getCartInfo().setCartId(redisVal.getCartId());
                }
                if (StringUtilities.isNotEmptyOrNull(redisVal.getCaseId())) {
                    request.getCartInfo().setCaseId(redisVal.getCaseId());
                }
                if (StringUtilities.isNotEmptyOrNull(redisVal.getAccountNumber())) {
                    request.getCartInfo().setAccountNumber(redisVal.getAccountNumber());
                }
                if (StringUtilities.isNotEmptyOrNull(redisVal.getProcessingMTN())) {
                    request.getCartInfo().setProcessingMTN(redisVal.getProcessingMTN());
                }
                if (StringUtilities.isNotEmptyOrNull(redisVal.getCartCreator())) {
                    request.getCartInfo().setCartCreator(redisVal.getCartCreator());
                }
                if (StringUtilities.isNotEmptyOrNull(redisVal.getProcessStep())) {
                    request.getCartInfo().setProcessStep(redisVal.getProcessStep());
                }
                return removeHomePhoneHelper.removeHomePhone(request);
            } catch (Exception e) {
                LoggerUtil.logOnError(r -> logger.error("Error occurred while calling Remove HomePhone", e));
            }
            return Mono.empty();
        });
    }

    @PostMapping(path = {"/5g/updateCartWithDates"})
    public Mono<CartWithDatePegaResponse> updateCartWithDateAppointment(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse,
                                                                        @RequestBody CartWithDateUIRequest request) {
        logger.debug("Update Cart With Date request Request: {}", request);
        Mono<CartRedisData> redisData = redisHelper.getDataFromRedis();
        return redisData.flatMap(redisVal -> {
            try {

                if (StringUtilities.isNotEmptyOrNull(redisVal.getCartId())) {
                    request.getCartWithDateContext().getCartInfo().setCartId(redisVal.getCartId());
                }
                if (StringUtilities.isNotEmptyOrNull(redisVal.getCaseId())) {
                    request.getCartWithDateContext().setCaseId(redisVal.getCaseId());
                }
                if (StringUtilities.isNotEmptyOrNull(redisVal.getAccountNumber())) {
                    request.getCartWithDateContext().getCustomerInfo().setAccountNumber(redisVal.getAccountNumber());
                }
                if (StringUtilities.isNotEmptyOrNull(redisVal.getProcessingMTN())) {
                    request.getCartWithDateContext().getCustomerInfo().setProcessingMTN(redisVal.getProcessingMTN());
                }
                if (StringUtilities.isNotEmptyOrNull(redisVal.getCartCreator())) {
                    request.getCartWithDateContext().getCustomerInfo().setCartCreator(redisVal.getCartCreator());
                }
                return updateCartWithDatesHelper.saveCartWithDate(request);
            } catch (Exception e) {
                LoggerUtil.logOnError(r -> logger.error("Error occurred while updating cart with date", e));
            }
            return Mono.empty();
        });
    }

    @PostMapping(path = {"/5g/swap/retrieve-cart"})
    public Mono<ResponseEntity<GenericResponse>> swapFiveGRetrieveCart(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse, @RequestBody GetCartDetailsRequest request) {
        logger.debug("Swap Retrieve Cart Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);
        return fiveGhomeTechHelper.getSwap5GCart(request, httpResponse);
    }

    @PostMapping(path = {"/5g/swap/order-confirmation","/5g/cbd/order-confirmation", "/5g/tech/order-confirmation"})
    public Mono<ResponseEntity<GenericResponse>> swapOrderConfirmation(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse, @RequestBody GetCartDetailsRequest request) {
        logger.debug("Swap Retrieve Cart Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);
        httpResponse.addCookie(ResponseCookie.from(CartConstants.DIGITAL_IG_SESSION,"").maxAge(Duration.ofSeconds(0)).secure(true).build());
        //httpResponse
        return fiveGhomeCommonHelper.swapOrderConfirmation(request, httpResponse);
    }


    @PostMapping(path = {"/5g/swap/updateCart"}, consumes = "application/json", produces = "application/json")
    public Mono<ResponseEntity<GenericResponse>> upgradePlanAndDevice(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse,
                                                                      @RequestBody AddPlanAndDeviceUIRequest request) {
        logger.debug("Upgrade plan and device Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);
        String sessionId = "";
        String rylEcpdUrl = "";
        String ecpdToken = "";
        String channelType = CartUtil.getChannelType(channelId);
        if (CartConstants.DIGITAL.equalsIgnoreCase(channelType))
            if(httpHeader.getCookies()!=null){
                sessionId = null != httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION)
                        ? Objects.requireNonNull(httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION)).getValue()
                        : "";
                rylEcpdUrl = null != httpHeader.getCookies().getFirst(CartConstants.COOKIE_ECPD_DOMAIN)
                        ? Objects.requireNonNull(httpHeader.getCookies().getFirst(CartConstants.COOKIE_ECPD_DOMAIN)).getValue()
                        : "";
                ecpdToken = null != httpHeader.getCookies().getFirst(CartConstants.COOKIE_ECPD_TOKEN)
                        ? Objects.requireNonNull(httpHeader.getCookies().getFirst(CartConstants.COOKIE_ECPD_TOKEN)).getValue()
                        : "";
            }
        logger.info("ecpdcookie & domainCookie", ecpdToken + " & " + rylEcpdUrl);
        request.getCartInfo().setSessionId(sessionId);
        request.getCartInfo().setRylEcpdUrl(rylEcpdUrl);
        request.getCartInfo().setEcpdToken(ecpdToken);

        return fiveGhomeCommonHelper.upgradePlanAndDevice(request).flatMap(pegaResponse -> {
            ErrorResponse errors2 = null;
            if (pegaResponse.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil2.handleAddDeviceResponseErrorsFiveGHome(pegaResponse);
                return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errors2));
            } else {
                CartRedisData rr = new CartRedisData();
                if (request.getCartInfo().getIntendType() != null)
                    rr.setIntendType(request.getCartInfo().getIntendType());
                if (request.getCartInfo().getCartCreator() != null)
                    rr.setCartCreator(request.getCartInfo().getCartCreator());
                rr.setTransactionType(request.getCartInfo().getTransactionType());
                if (pegaResponse.getServiceBody() != null) {
                    if (pegaResponse.getServiceBody().getServiceResponse().getContext() != null) {
                        rr.setCaseId(pegaResponse.getServiceBody().getServiceResponse().getContext().getCaseId());
                        if (pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo() != null) {
                            rr.setCartId(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()
                                    .getCartId());
                            if (pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()
                                    .getLines() != null) {
                                Line[] lines = pegaResponse.getServiceBody().getServiceResponse().getContext()
                                        .getCartInfo().getLines();

                                if (null != lines && lines.length > 0
                                        && StringUtilities.isNotEmptyOrNull(lines[0].getMtn())) {
                                    rr.setProcessingMTN(lines[0].getMtn());
                                }
                            }
                        }
                        if (null != pegaResponse.getServiceBody().getServiceResponse().getContext().getContextInfo()) {
                            rr.setProcessStep(pegaResponse.getServiceBody().getServiceResponse().getContext().getContextInfo().getProcessStep());
                        }
                    }
                }
                rr.setLines(fiveGhomeCommonHelper.transform5GLinesDatatoBAU(request.getData().getLines()));
                rr.setDeviceCartInfo(fiveGhomeCommonHelper.transform5GCartDatatoBAU(request.getCartInfo()));
                rr.setSpokeJourney(CartConstants.FALSE);
                if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessingMTN()))
                    rr.setProcessingMTN(request.getCartInfo().getProcessingMTN());

                return redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(rr, CartConstants.DEVICE).flatMap(redisData -> {
                    try {
                        logger.info("Inside DL update");

                        dlUtilityService.updateDlData(request.getCartInfo().getIntendType());
                    } catch (Exception e) {
                        logger.error("exception while calling dlUtilityService in addDevice");
                    }
                    if (httpResponse.getStatusCode().equals(HttpStatus.PARTIAL_CONTENT)) {
                        for (CartError errorResp : pegaResponse.getErrors()) {
                            if ("3226".equals(errorResp.getId())) {
                                httpResponse.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR);
                            }
                        }
                    }
                    return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(pegaResponse));
                });
            }
        });
    }


    @PostMapping(path = {"/5g/cbd/getReviewOrderData"})
    public Mono<ReviewOrderData> retrieveReviewOrderTechCbandData(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse,
                                                                  @RequestBody GetCartDetailsRequest request) {
        logger.debug("retrieve Cart Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);


        CheckoutDetailsRequest checkoutRequest = new CheckoutDetailsRequest();
        return redisHelper2.getCartIdFromRedis().flatMap(redisData -> {
            RetrieveCartCXPRequest cxprequest = new RetrieveCartCXPRequest();
            CXPRetrieveCartDataVO data = new CXPRetrieveCartDataVO();
            if(StringUtilities.isEmptyOrNull(redisData)){
                redisData= null != request.getData()? request.getData().getCartId():"";
            }
            data.setCartId(redisData);
            cxprequest.setData(data);
            // handle error when cartId is empty
            checkoutRequest.setCartId(redisData);
            checkoutRequest.setInstallmentContracts(true);
            checkoutRequest.setCustomerAgreements(true);
            Mono<InspicioResponseOrderInfo> techCbandCart5GCart = fiveGhomeTechHelper.getTechCbandCart5GCart(cxprequest, httpResponse);
            Mono<InspicioTermsAndConditions> agreementDetails = fiveGhomeCommonHelper.getAgreementDetails(checkoutRequest);
            return techCbandCart5GCart.zipWith(agreementDetails).flatMap(tuple -> {
                InspicioResponseOrderInfo orderInfo = tuple.getT1();
                InspicioTermsAndConditions termsAndConditions = tuple.getT2();
                return combineResponsesForReviewOrderPage(orderInfo,termsAndConditions);
            });
        });
    }

    @PostMapping(value = "/addTruckRollCart")
    public Mono<AddTruckRollCartUIResponse> addTruckRollCart(ServerHttpRequest request, ServerHttpResponse httpResponse,
                                                             @RequestBody AddTruckRollCartUIRequest addTruckRollCartUIRequest) throws JsonProcessingException {
        logger.info("Calling save5GAppointment in AppointmentServiceController");
        AddTruckRollCartUIResponse emptyAddTruckRollCartUIResponse = new AddTruckRollCartUIResponse();
        Mono<AddTruckRollCartUIResponse> addTruckRollCartUIResponse = fiveGhomeCommonHelper.addTruckRollCart(addTruckRollCartUIRequest, request);
        return addTruckRollCartUIResponse == null ? Mono.just(emptyAddTruckRollCartUIResponse) : addTruckRollCartUIResponse.flatMap(addTruckRollResponse -> {
            if(null != addTruckRollResponse) {
                return fiveGhomeCommonHelper.orderReviewDetails(addTruckRollResponse).flatMap(orderReviewDetail -> {
                    Optional.ofNullable(orderReviewDetail).map(OrderReviewDetailsResponse::getData).map(OrderReviewDetails::getCart)
                            .map(Cart::getLineDetails).map(LineDetails::getLineInfo).filter(Objects::nonNull).ifPresent(lineInfo -> {
                                List<LineInfo> lineInfoList = new ArrayList<LineInfo>();
                                LineDetails lineDetails = new LineDetails();
                                Optional.ofNullable(addTruckRollResponse.getServiceBody()).map(AddTruckRollCartUIResponseServiceBody::getServiceResponse)
                                        .map(AddTruckRollCartServiceResponse::getContext).map(AddTruckRollCartResponseContext::getCartInfo).ifPresent(addTruckRollCartResponseContextCartInfo -> {
                                            lineInfo.stream().filter(Objects::nonNull).forEach(line -> {
                                                LineInfo respLine = new LineInfo();
                                                if(null != line.getServiceInfo() && null != line.getServiceInfo().getCart5GAppointment()) {
                                                    ServiceInfo serviceInfo = new ServiceInfo();
                                                    serviceInfo.setCart5GAppointment(line.getServiceInfo().getCart5GAppointment());
                                                    respLine.setServiceInfo(serviceInfo);
                                                }
                                                lineInfoList.add(respLine);
                                            });
                                            lineDetails.setLineInfo(lineInfoList);
                                            addTruckRollCartResponseContextCartInfo.setLineDetails(lineDetails);
                                        });
                            });

                    return Mono.just(addTruckRollResponse);
                });
            }
            return addTruckRollCartUIResponse;
        });

    }


    private Mono<ReviewOrderData> combineResponsesForReviewOrderPage(InspicioResponseOrderInfo orderInfo, InspicioTermsAndConditions termsAndConditions) {
        ReviewOrderData reviewOrderData = new ReviewOrderData();
        reviewOrderData.setOrderInfo(orderInfo);
        reviewOrderData.setTermsAndConditions(termsAndConditions);
        reviewOrderData.setFlowType("FCL");
        return Mono.just(reviewOrderData);
    }

    @PostMapping(value = "/updateCart")
    public Mono<AddTruckRollCartUIResponse> updateTruckRollCart(ServerHttpRequest request, ServerHttpResponse httpResponse,
                                                                @RequestBody AddTruckRollCartUIRequest updateTruckRollCartUIRequest)throws JsonProcessingException{
        logger.info("Calling save5GAppointment in AppointmentServiceController");
        Mono<AddTruckRollCartUIResponse> addTruckRollCartUIResponse = fiveGhomeCommonHelper.updateTruckRollCart(updateTruckRollCartUIRequest, request);
        return addTruckRollCartUIResponse;
    }
}
