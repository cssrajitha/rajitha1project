package onevz.soe.cart.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.vzw.cradle.util.CradleUtil;
import onevz.cxp.feature.util.FeatureFlag;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.constants.FeatureFlagConstants;
import onevz.soe.cart.exceptions.JsonValidator;
import onevz.soe.cart.helper.*;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.common.Vzdl;
import onevz.soe.cart.model.deviceIdValidation.DeviceIdValidationContext;
import onevz.soe.cart.model.deviceIdValidation.DeviceIdValidationLine;
import onevz.soe.cart.model.deviceIdValidation.DeviceIdValidationServiceBody;
import onevz.soe.cart.model.deviceIdValidation.DeviceIdValidationServiceResponse;
import onevz.soe.cart.model.retrieveCart.*;
import onevz.soe.cart.model.retrieveDpp.RetrieveDppRequest;
import onevz.soe.cart.model.validateCart.CXPValidateCartDataVO;
import onevz.soe.cart.requests.*;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.translator.ValidateCartTranslator;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.DeviceIdValidationUIResponse;
import onevz.soe.cart.ui.responses.RetrieveCartUIResponse;
import onevz.soe.cart.ui.responses.ValidateCartUIResponse;
import onevz.soe.cart.ui.responses.v2.FlagDetails;
import onevz.soe.cart.util.*;
import onevz.soe.channels.SOEChannels;
import onevz.soe.cradle.constant.Constants;
import onevz.soe.exception.ErrorType;
import onevz.soe.exception.SOEErrorHolder;
import onevz.soe.omnidl.util.DLUtilityService;
import onevz.soe.security.util.ReCaptchaUtil;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;
import reactor.util.function.*;
import onevz.cxp.feature.ConfigurationProfile;
import onevz.cxp.feature.Flag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;

import static onevz.soe.cart.constants.CartConstants.DIGITAL_CHANNEL;
import static onevz.soe.cart.constants.CartConstants.PROMO_HUB;
import static onevz.soe.cart.constants.FeatureFlagConstants.AWS_CONFIG_APP_NAME;
import static onevz.soe.cart.constants.FeatureFlagConstants.RFEX_ELIGIBILITY_FOR_DFO_FFLAG;
import static onevz.soe.cart.util.CommonUtil.populateLineRedisData;
import static onevz.soe.session.constants.FeatureFlagConstants.SALES;

/**
 * Cart Controller class.
 */
//NSADT-53978 removing CrossOrigin annotation in every service
//@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping(value = "cart")
public class CartReadOperationsController {

	private static final Logger logger = LoggerFactory.getLogger(CartReadOperationsController.class);
	private static final String ABANDON_CART_NAME = "ABANDON_CART";
	private static final String CART_VALIDATION_ERROR_CODE = "1023";
	private static final String CART_VALIDATION_ERROR_MESSAGE = "New PricePlanId is not populated for Add a Line/Bring Your Own Device line.";
	@Autowired
	private UpdateCartHelper helper;

	@Autowired
	private ReadCartHelper readCartHelper;

	@Autowired
	private RedisHelper redisHelper;
	@Autowired
	private RedisHelper2 redisHelper2;
	@Autowired
	private RedisHelper3 redisHelper3;
	@Autowired
	private DLUtilityService dlUtilityService;
    @Autowired
	private CartAddDeviceHelper cartAddDeviceHelper;
	@Autowired
	private CollaborationCodeHelper collaborationCodeHelper;

	@Autowired
	FeatureFlag featureFlag;

	private ObjectMapper mapper = new ObjectMapper();
	@Value("${processingMtnFlag}")
	private String processingMtnFlag;

	@Value("${soe.imeiCheck.captcha.enable:false}")
	private boolean enableIMEIRecaptcha;

	@Value("${enableSecurityForCart}")
	private boolean enableSecurityForCart;

	@Autowired
	ReCaptchaUtil reCaptchaUtil;


	@Value("${soe.cartservice.recaptcha.allowedPageReferrer:enterDeviceIMEI,selectMakeAndModel}")
	public List<String> allowedPageReferrerForCaptcha;

	@Value("${soe.cartservice.recaptcha.skipChannelsForCaptcha:EXPRESS-STORE,VZW-CHATBOT,VZW-RPS,VZW-CHATBOT-MF}")
	public List<String> skipChannelsForCaptcha;

	@Value("${soe.digital.recaptcha.whiteListedIps:}")
	private List<String> captchaWhileListedIps;

	@Value("${soe.qaEnvironment}")
	private String qaEnvironment;

	@Autowired
	private OmniDLHelper omniDLHelper;

	@Autowired
	private CradleHelper cradleHelper;
	@Autowired
	private RetrieveCartHelper retrieveCartHelper;

	@Autowired
	private FeatureFlagHelper featureFlagHelper;

	@Autowired
	JsonValidator validator;

	@Value("${enableMHOffers}")
	private boolean enableMHOffers;

	@Value("#{'${sessionCreation.domains:.verizon.com}'.split(',')}")
	private List<String> domains;
	/**
	 *
	 * @param binder
	 */
	@InitBinder("*")
	public void initBinderByName(WebDataBinder binder) {
		binder.setDisallowedFields(new String[] { "genericHeader" });
	}

	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return ResponseEntity
	 *
	 */
	@PostMapping({ "/validate-deviceSimId", "/nse/validate-deviceSimId", "flexV2/validate-deviceSimId", "flexV2/nse/validate-deviceSimId" })
	public Mono<ResponseEntity<GenericResponse>> deviceIdValidation(ServerHttpRequest httpHeader,
																	ServerHttpResponse httpResponse, @Valid @RequestBody DeviceIdValidationUIRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "validate-deviceSimId");
		String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
				? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
				: "";
		request.setChannelId(channelId);
		// GTSFN-2160 - New Customer Transaction Prospect - Add device change
		String sessionId = "";
		HttpCookie cookieDigitIgSession = httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION);
		HttpCookie captchaCookie = httpHeader.getCookies().getFirst(CartConstants.G_CAPTCHA_COOKIE);
		String channelType = CartUtil.getChannelType(channelId);
		if (CartConstants.DIGITAL.equalsIgnoreCase(channelType)
				|| CartConstants.EXPRESS_STORE.equalsIgnoreCase(CartUtil.getChannelType(channelId)))
			sessionId = null != cookieDigitIgSession
					? cookieDigitIgSession.getValue()
					: "";

		if (StringUtilities.isNotEmptyOrNull((sessionId))) {
			request.getCartInfo().setSessionId(sessionId);
		}
		if (CartConstants.DIGITAL.equalsIgnoreCase(channelType) && !request.getData().getLines().isEmpty()
				&& StringUtils.isNotBlank(request.getData().getLines().get(0).getDevice().getId())
				&& (CartConstants.NSE_BYOD.equals(request.getCartInfo().getIntent()) || CartConstants.BYOD.equals(request.getCartInfo().getIntent()))){
			request.getCartInfo().setAction(request.getCartInfo().getIntent());
		}
		if(StringUtilities.isNotEmptyOrNull(String.valueOf(httpHeader.getURI())) && CartUtil.isFlexV2(String.valueOf(httpHeader.getURI())))
			request.getCartInfo().setFlexV2(true);
		logger.debug("deviceId-simIdValidation Request: {}", request);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleDeviceIdValidationRequestErrors(request);
		if (errors.getErrors() != null)
			return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
		String[] redisKeys = {CartConstants.APPROVED_SECONDCAPTCHA_REDIS_KEY};
		final Mono<DeviceIdValidationUIResponse> deviceIdValidationUIResponseMono = redisHelper3.getDataFromSession(redisKeys)
				.flatMap(secondCaptchaRedisValue -> {
					if (isForceRecaptchaCookieEnabled(captchaCookie) || enableCaptcha(httpHeader, request, channelId)) {
						if (StringUtilities.isEmptyOrNull(request.getCartInfo().getGRecaptchaResponse())) {
							final String isApprovedForSecondStatus = (String) secondCaptchaRedisValue.get(CartConstants.APPROVED_SECONDCAPTCHA_REDIS_KEY);
							logger.info("deviceId-simIdValidation isApprovedForSecondStatus - {} ", isApprovedForSecondStatus);
							if (StringUtilities.isNotEmptyOrNull(isApprovedForSecondStatus)
									&& Boolean.TRUE.equals(Boolean.valueOf(isApprovedForSecondStatus))) {
								setApprovedForSecondCaptchaInRedis(Boolean.FALSE);
								logger.info("deviceIdValidation old flow approved for second flow");
								return readCartHelper.deviceIdValidation(request);
							} else {
								logger.info("received empty captcha response");
								return Mono.error(new SOEHTTPException(500, SOEErrorHolder.builder().errors(CartPegaRequestErrorsUtil.emptyCaptchaErrorresponse()).build()));
							}
						} else {
							return reCaptchaUtil.validateVisibleCaptcha(request.getCartInfo().getGRecaptchaResponse())
									.flatMap(success -> {
										if (!success) {
											logger.info("recaptcha validation failed");
											setApprovedForSecondCaptchaInRedis(Boolean.FALSE);
											return Mono.error(new SOEHTTPException(500, SOEErrorHolder.builder().errors(CartPegaRequestErrorsUtil.emptyCaptchaErrorresponse()).build()));
										} else {
											logger.info("recaptcha validation success");
											setApprovedForSecondCaptchaInRedis(Boolean.TRUE);
											return readCartHelper.deviceIdValidation(request);
										}
									});
						}

					} else {
						List<String> allowedIntend  = new ArrayList<>();
						allowedIntend.add("AAL");
						allowedIntend.add("EUP");
						allowedIntend.add("NSE");
						if (StringUtilities.isNotEmptyOrNull(channelId) && Objects.requireNonNull(channelId).contains(CartConstants.OMNI_INDIRECT)
								&& StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntent()) && allowedIntend.contains(request.getCartInfo().getIntent().toUpperCase())) {
							Mono<DeviceIdValidationUIResponse> deviceIdValidationUIResponseMono1 = readCartHelper.validateDeviceSimId(request);
							return deviceIdValidationUIResponseMono1.flatMap(res -> {
								if (res.getErrors() != null) {
									httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
									return Mono.just(res);
								}
								return readCartHelper.deviceIdValidation(request).flatMap(deviceIdValidationUIResponse -> readCartHelper.imeiValidationCheck(deviceIdValidationUIResponse, request).flatMap(response -> {
									if (response.getErrors() != null) {
										httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
										return Mono.just(response);
									}
									return Mono.just(deviceIdValidationUIResponse);
								}).defaultIfEmpty(deviceIdValidationUIResponse));
							});
						}
					}
					logger.info("deviceIdValidation old flow");
					return readCartHelper.deviceIdValidation(request);
				}).onErrorResume(err-> {
					Mono<DeviceIdValidationUIResponse> resp = null;
					if( null!= request.getCartInfo() && CartUtil.isByodFlow(request.getCartInfo().getIntendType()) && isDigital(request.getChannelId())) {
						resp = constructValidationResponseWithError(err);
					}
					return resp==null ? Mono.error(err): resp;
				});
		return mergeFeatureFlagWithDeviceIdValidationResponse(Mono.zip(deviceIdValidationUIResponseMono,featureFlagHelper.fetchDigitalPerformanceCfgProfile(), featureFlagHelper.fetchDigitalByodProfile())).map(resp -> {
			ErrorResponse errors2 = null;
			if (resp.getErrors() != null && resp.getServiceBody() == null) {
				errors2 = CartPegaResponseErrorsUtil.handleDeviceIdValidationResponseErrors(resp);
			}
			//NSADT-88093 - fix for removing sensitive data from UI response
			if (resp != null && resp.getServiceBody() != null
					&& CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))
					&& resp.getServiceBody().getServiceResponse() != null
					&& resp.getServiceBody().getServiceResponse().getContext() != null) {

				resp.getServiceBody().getServiceResponse().getContext().setCaseId(null);
				if (resp.getServiceBody().getServiceResponse().getContext().getCartInfo() != null)
					resp.getServiceBody().getServiceResponse().getContext().getCartInfo().setCartId(null);
				if (resp.getServiceHeader() != null)
					resp.getServiceHeader().setClientId(null);
				if(CartUtil.isByodFlow(request.getCartInfo().getIntent()) && resp.getServiceBody().getServiceResponse().getContext().getDeviceInfo()!=null)
					redisHelper.setByodDataToRedis(resp.getServiceBody().getServiceResponse().getContext().getDeviceInfo());
				readCartHelper.performMaskingForBYOD(resp, request);
			}
			return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
					: ResponseEntity.status(HttpStatus.OK).body(resp);

		});

	}
	public  Mono<DeviceIdValidationUIResponse> mergeFeatureFlagWithDeviceIdValidationResponse(Mono<Tuple3<DeviceIdValidationUIResponse, ConfigurationProfile, ConfigurationProfile>> zip) {
		return zip.flatMap(tuples -> {
			DeviceIdValidationUIResponse response = tuples.getT1();
			Map<String, FlagDetails> mapOfFeatureFlags = new HashMap<>();
			mapOfFeatureFlags = featureFlagHelper.addConfigurationProfileFeatureFlags(tuples.getT2(), mapOfFeatureFlags);
			mapOfFeatureFlags = featureFlagHelper.addConfigurationProfileFeatureFlags(tuples.getT3(),mapOfFeatureFlags);

			if (null != response.getServiceBody() && null != response.getServiceBody().getServiceResponse()
					&& null != response.getServiceBody().getServiceResponse().getContext()) {
				if (response.getServiceBody().getServiceResponse().getContext().getFeatureConfigurationProfileData() != null
						&& !response.getServiceBody().getServiceResponse().getContext().getFeatureConfigurationProfileData().isEmpty()) {
					if (!mapOfFeatureFlags.isEmpty())
						response.getServiceBody().getServiceResponse().getContext().getFeatureConfigurationProfileData().putAll(mapOfFeatureFlags);
				} else {
					if (!mapOfFeatureFlags.isEmpty())
						response.getServiceBody().getServiceResponse().getContext().setFeatureConfigurationProfileData(mapOfFeatureFlags);
				}
			}

			return Mono.just(response);
		}).doOnError(throwable -> logger.error(String.format("Error fetching configuration profile:", throwable.getMessage())));
	}

	/**
	 *  Check if the captcha needed based on channel , automation ip, killswitch
	 *  For real customer captcha should be executed at any cost
	 * @param httpHeader
	 * @param request
	 * @param channelId
	 * @return
	 */
	private boolean enableCaptcha(ServerHttpRequest httpHeader, DeviceIdValidationUIRequest request, String channelId) {
		return enableIMEIRecaptcha && CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId))
				&& !skipChannelsForCaptcha.contains(channelId) && checkifEligibleForCaptha(httpHeader, request)
				&& checkIfWhiteListedIps(httpHeader);
	}

	private boolean checkIfWhiteListedIps(ServerHttpRequest httpHeader) {
		Boolean captchaEligible = Boolean.TRUE;
		String ipAddress = Optional.ofNullable(httpHeader.getHeaders().getFirst(CartConstants.ORIGINATING_CLIENT_IP)).orElse("");
		if(CollectionUtilities.isNotEmptyOrNull(captchaWhileListedIps)){
			captchaEligible =captchaWhileListedIps.stream().noneMatch(whiteListedIPs -> ipAddress.contains(whiteListedIPs));
		}
		logger.info("checkIfWhiteListedIps captchaEligible {} , ipAddress - {} ",captchaEligible,ipAddress);
		return captchaEligible ;
	}

	/**
	 * Check if the captcha forcing cookie is enabled . this is used for lower env testing
	 * @return true/false
	 */
	public boolean isForceRecaptchaCookieEnabled(HttpCookie captchaCookie){
		return captchaCookie!=null && String.valueOf(Boolean.TRUE).equalsIgnoreCase(captchaCookie.getValue());
	}

	private void setApprovedForSecondCaptchaInRedis(@NotNull Boolean approvedForSecondCaptcha){
		Map<String, String> sessionData = new HashMap<String, String>();
		sessionData.put(CartConstants.APPROVED_SECONDCAPTCHA_REDIS_KEY, approvedForSecondCaptcha.toString());
		redisHelper2.upsertDataInRedis(sessionData);
	}

	private boolean checkifEligibleForCaptha(ServerHttpRequest httpHeader, DeviceIdValidationUIRequest request) {
		String refererURL = Optional.ofNullable(httpHeader.getHeaders().getFirst("Referer")).orElse("");
		if(StringUtilities.isNotEmptyOrNull(refererURL) && !refererURL.toLowerCase().contains(qaEnvironment)){
			final String pageReferer = CartUtil.getPageReferer(refererURL);
			logger.info("checkifElgibleForCaptha allowedPageReferrerForCaptcha - {} , pageReferer {}",allowedPageReferrerForCaptcha,pageReferer);
			return allowedPageReferrerForCaptcha.contains(pageReferer) && isRequestEligibleForCaptcha(request);
		}
		logger.info("checkifElgibleForCaptha -> false refererURL - {} ",refererURL);
		return false;
	}

	private boolean isRequestEligibleForCaptcha(DeviceIdValidationUIRequest request) {
		if(null!= request.getData() &&
				CollectionUtilities.isNotEmptyOrNull(request.getData().getLines())){
			final boolean requestEligibleForCaptcha = request.getData().getLines().stream()
					.map(DeviceIdValidationLine::getDevice)
					.filter(Objects::nonNull)
					.anyMatch(device -> CartConstants.DEVICE.equalsIgnoreCase(device.getFlowtype())
							&& Boolean.FALSE.equals(device.getSmartIMEI())
							&& StringUtilities.isNotEmptyOrNull(device.getId()));
			logger.info("isRequestEligibleForCaptcha requestEligibleForCaptcha {}",String.valueOf(requestEligibleForCaptcha));
			return requestEligibleForCaptcha;
		}
		logger.info("isRequestEligibleForCaptacha Lines are empty hence false");
		return false;
	}

	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return ResponseEntity
	 *
	 */
	@PostMapping({ "/nse/retrieve-cart" })
	public Mono<ResponseEntity<GenericResponse>> nseRetrieveCart(ServerHttpRequest httpHeader,
																 ServerHttpResponse httpResponse, @Valid @RequestBody RetrieveCartCXPRequest request) {
		if (null != request.getData()) {
			request.getData().setCartId(null);
		}

		return retrieveCart(httpHeader, httpResponse, request);
	}

	@PostMapping({ "/nse/retrievePlanBuilderCart","/retrievePlanBuilderCart" })
	public Mono<ResponseEntity<?>> retrieveCartPlanBuilder(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse,
														   @Valid @RequestBody RetrieveCartPlanbuilderRequest request) {
		return collaborationCodeHelper.getDataForLookupPasscode(request.getZipCode(), request.getLookupPasscode()).flatMap(lookupResponse -> {
			if(null == lookupResponse.getData()){
				logger.error("could not find any data for lookupPasscode:{} ", request.getLookupPasscode());
				RetrieveCartPlanbuilderResponse errorResponse = new RetrieveCartPlanbuilderResponse();
				CartError[] cartErrors = new CartError[]{createCartError(ErrorType.API_ERROR, (null != lookupResponse.getErrors()) ? lookupResponse.getErrors().get(0).getMessage(): "Invalid lookupPasscode")};
				errorResponse.setErrors(cartErrors);
				return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse));
			}
			String cartIdForPasscode = lookupResponse.getData().get(CartConstants.CART_ID).asText(CartConstants.EMPTY_STRING);
			String cartIdPayload = request.getData().getCartId();
			if(!cartIdForPasscode.equals(cartIdPayload)){
				logger.error("cartId provided does not match with cart found by lookupPasscode, returning error response");
				RetrieveCartPlanbuilderResponse errorResponse = new RetrieveCartPlanbuilderResponse();
				CartError error = createCartError(ErrorType.VALIDATION_ERROR, CartConstants.CART_INVALID);
				errorResponse.setErrors(new CartError[]{error});
				return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse));
			}

			RetrieveCartCXPRequest cxpRequest = getRetrieveCartCXPRequest(request);
			return retrieveCart(httpHeader, httpResponse, cxpRequest).flatMap(resp -> {
				if(resp.getStatusCode().is2xxSuccessful() && null != resp.getBody() && resp.getBody() instanceof RetrieveCartUIResponse ){
					RetrieveCartUIResponse cartUIResponse = (RetrieveCartUIResponse) resp.getBody();
					// filter and return
					RetrieveCartPlanbuilderResponse soeResponse = populateSOEResponseForRetriveCartPlanbuilder(cartUIResponse);
					return  Mono.just(ResponseEntity.status(HttpStatus.OK).body(soeResponse));
				}
				return  Mono.just(resp);
			});
		});

	}

	private CartError createCartError(ErrorType errorType, String message) {
		CartError error = new CartError();
		error.setMessage(message);
		error.setNamespace(CartConstants.SOE_SERVICE_NAME);
		error.setId(errorType.getId());
		error.setName(errorType.name());
		return error;
	}

	private RetrieveCartPlanbuilderResponse populateSOEResponseForRetriveCartPlanbuilder(RetrieveCartUIResponse cartUIResponse) {
		RetrieveCartPlanbuilderResponse soeResponse = new RetrieveCartPlanbuilderResponse();
		soeResponse.setData(new RetrieveCartDataPbVO());
		soeResponse.getData().setCartId(cartUIResponse.getData().getCartId());
		soeResponse.getData().setRetrieveCurrentFeatures(cartUIResponse.getData().getRetrieveCurrentFeatures());
		soeResponse.getData().setCart(new RetrieveCartDataPbCartVO());
		soeResponse.getData().getCart().setCartHeader(cartUIResponse.getData().getCart().getCartHeader());
		soeResponse.getData().getCart().setOrderDetails(new RetrieveCartDataPbOrderDetails());
		soeResponse.getData().getCart().getOrderDetails().setCustomerType(cartUIResponse.getData().getCart().getOrderDetails().getCustomerType());
		soeResponse.getData().getCart().getOrderDetails().setOrderList(cartUIResponse.getData().getCart().getOrderDetails().getOrderList());
		soeResponse.getData().getCart().getOrderDetails().setOrderType(cartUIResponse.getData().getCart().getOrderDetails().getOrderType());
		return soeResponse;
	}

	private RetrieveCartCXPRequest getRetrieveCartCXPRequest(@RequestBody @Valid RetrieveCartPlanbuilderRequest request) {
		RetrieveCartCXPRequest cxpRequest = new RetrieveCartCXPRequest();
		cxpRequest.setChannelId(request.getChannelId());
		cxpRequest.setMeta(request.getMeta());
		CXPRetrieveCartDataVO data = new CXPRetrieveCartDataVO();
		data.setRetrieveCurrentFeatures(request.getData().getRetrieveCurrentFeatures());
		data.setCartId(request.getData().getCartId());
		cxpRequest.setData(data);
		return cxpRequest;
	}

	/**
	 *
	 * @param httpRequest
	 * @param httpResponse
	 * @param request
	 * @return
	 */
	@PostMapping({ "/retrieve-bundle-acc-cart", "/nse/retrieve-bundle-acc-cart" })
	public Mono<ResponseEntity<GenericResponse>> retrieveAccBundleAccessories(ServerHttpRequest httpRequest,
																			  ServerHttpResponse httpResponse,
																			  @Valid @RequestBody RetrieveBundleAccRequest request) {
		logger.debug("retrieve-bundle-acc-cart Request: {}", request);
		logger.info("Inside retrieve-bundle-acc-cart api");
		List<String> channelIdList = httpRequest.getHeaders().get(CartConstants.CHANNEL_ID);
		if (httpRequest.getHeaders() != null && channelIdList != null
				&& channelIdList.size() > 0)
			request.setChannelId(channelIdList.get(0));

		if (request.getData() != null && "acc-gridwall-bundle".equalsIgnoreCase(request.getData().getPageId())) {
			return readCartHelper.retrieveBundleAccessoryInfo(request).flatMap(k -> {
				RetrieveAccBundleResponse retrieveAccBundleResponse = new RetrieveAccBundleResponse();
				RetrieveAccBundleData retrieveAccBundleData = new RetrieveAccBundleData();
				retrieveAccBundleData.setBundleAccessoryDetail(k);
				retrieveAccBundleResponse.setData(retrieveAccBundleData);
				return Mono.just(ResponseEntity.status(HttpStatus.OK).body(retrieveAccBundleResponse));
			});

		}
		else {
			return cradleHelper.getThrottlingList(request, httpRequest, httpResponse).filter(s -> s != null).flatMap(s -> {
				logger.info("retrieveAccBundleAccessories cradle: {}", s);
				if(s.contains("AccInterestialBundleBuilder")) {
					return readCartHelper.retrieveBundleAccessoryInfo(request).flatMap(k -> {
						RetrieveAccBundleResponse retrieveAccBundleResponse = new RetrieveAccBundleResponse();
						RetrieveAccBundleData retrieveAccBundleData = new RetrieveAccBundleData();
						retrieveAccBundleData.setBundleAccessoryDetail(k);
						retrieveAccBundleData.setThrottleList(s);
						retrieveAccBundleResponse.setData(retrieveAccBundleData);
						return Mono.just(ResponseEntity.status(HttpStatus.OK).body(retrieveAccBundleResponse));
					});
				}
				RetrieveAccBundleResponse retrieveAccBundleResponse = new RetrieveAccBundleResponse();
				RetrieveAccBundleData retrieveAccBundleData = new RetrieveAccBundleData();
				retrieveAccBundleData.setThrottleList(s);
				retrieveAccBundleResponse.setData(retrieveAccBundleData);
				return Mono.just(ResponseEntity.status(HttpStatus.OK).body(retrieveAccBundleResponse));

			});
		}
	}

	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return ResponseEntity
	 *
	 */
	@PostMapping({ "/retrieve-cart" , "/flexV2/retrieve-cart"})
	public Mono<ResponseEntity<GenericResponse>> retrieveCart(ServerHttpRequest httpHeader,
															  ServerHttpResponse httpResponse, @Valid @RequestBody RetrieveCartCXPRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "retrieve-cart");
		logger.debug("retrieve-cart Request: {}", request);
		logger.info("Inside retrieve-cart api");
		List<String> channelIdList = httpHeader.getHeaders().get(CartConstants.CHANNEL_ID);
		if (httpHeader.getHeaders() != null && channelIdList != null
				&& channelIdList.size() > 0)
			request.setChannelId(channelIdList.get(0));
		if (StringUtilities.isNotEmptyOrNull(String.valueOf(httpHeader.getURI())) && CartUtil.isFlexV2(String.valueOf(httpHeader.getURI()))) {
			request.setFlexV2(true);
		}

		ErrorResponse validationResponse = retrieveCartHelper.validateRetrieveCartRequest(httpHeader, request);
		if (validationResponse!=null && CollectionUtilities.isNotEmptyOrNull(validationResponse.getErrors())) {
			ErrorResponse errors2 = null;
			errors2 = RetrieveCartErrorsUtil.handleRetrieveCartRequestErrors(validationResponse);
			return Mono.just(ResponseEntity.status(400).body(errors2));
		}
		return readCartHelper.retrieveCart(request)
				.flatMap(response -> readCartHelper.updatePortLaterCraddleCall(response, httpHeader, httpResponse))
				.flatMap(resp -> {
			ErrorResponse errors2 = null;
			if (resp.getErrors() != null) {
				errors2 = CartCxpResponseErrorsUtil.handleRetrieveCartResponseErrors(resp);
				if (null != errors2.getErrors() && null != errors2.getErrors().get(0)
						&& null != errors2.getErrors().get(0).getNamespace()
						&& errors2.getErrors().get(0).getNamespace().equalsIgnoreCase(CartConstants.SOE_CART_SERVICE)) {

					if (null != errors2.getErrors().get(0).getCode()
							&& errors2.getErrors().get(0).getCode().equalsIgnoreCase("400")) {
						httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
					}
				}
				return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(errors2));
			} else {
				setRetrieveCartFeatureFlagsInResponse(resp);
				if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))
						&& request.getMeta() != null) {
					String graphqlType = request.getMeta().get("type");
					String channelType = CartUtil.getChannelType(request.getChannelId());
					if (channelType.equalsIgnoreCase(CartConstants.DIGITAL) && resp.getData().getCart() != null
							&& resp.getData().getCart().getCartId() != null
							&& StringUtilities.isNotEmptyOrNull(graphqlType)
							&& CartConstants.NEWCUSTOMER.equalsIgnoreCase(graphqlType)) {
						resp.getData().getCart().setCartId(null);
					}
					//hiding sensitive data for BBP channel - VZWYN-18780
					if (StringUtilities.isNotEmptyOrNull(request.getChannelId()) && CartConstants.CHANNEL_ID_BBP.equalsIgnoreCase(request.getChannelId())) {
						if (resp.getData()!=null && resp.getData().getCart()!=null && resp.getData().getCart().getCartHeader()!=null) {
							resp.getData().getCart().getCartHeader().setCartId(null);
							resp.getData().getCart().getCartHeader().setCaseId(null);
							resp.getData().getCart().getCartHeader().setFullAccountNumber(null);
						}
					}
				}

				RetrieveCartRedisData rr = new RetrieveCartRedisData();
				rr.setData(populateLineRedisData(resp));
				Mono<Tuple3<Boolean, Boolean,Boolean>> zippedMono = Mono.zip(
						redisHelper.upsertRetrieveCartDataIntoRedis(rr),
						redisHelper.upsertCartResponseToSession(resp.getData(),request),featureFlagHelper.fetchD2DFeatureFlag());
				return zippedMono.flatMap(updated -> {
					logger.info("upsertRetrieveCartDataIntoRedis ", updated.getT1());
					logger.info("upsertCartResponseToSession ", updated.getT2());
					if(CartUtil.isDigital(request.getChannelId()) && enableSecurityForCart) {
						removeSensitiveDataFromRetrieveCart(resp);
					}
					if(CartUtil.isAssisted(request.getChannelId())) {
						removeSensitiveDataFromRetrieveCart(resp);
						if(updated.getT3() && request.isFlexV2()){
							helper.filterExistingCustomerLineDetails(resp, request);
						}
					}
					helper.checkForBYODMasking(resp);
					return Mono.just(ResponseEntity.status(HttpStatus.OK).body(resp))
							.flatMap(response -> {
								Mono<Tuple2<Boolean, Boolean>> zippedFlagMono = Mono.zip(featureFlagHelper.fetchAssistedTaggingFeatureFlag(), featureFlagHelper.fetchAssistedMFETaggingFeatureFlag());
								return zippedFlagMono.flatMap(tuple2 -> {
									try {
										if (StringUtilities.isNotEmptyOrNull(request.getChannelId()) && CartUtil.isAssisted(request.getChannelId())) {
											if (Boolean.TRUE.equals(tuple2.getT1())) {
												helper.updateTaggingPlanDetails(resp, request);
											}
											if (Boolean.TRUE.equals(tuple2.getT2())) {
												Vzdl vzdl = omniDLHelper.updateVzdlData(resp);
												if (vzdl != null) {
													cartAddDeviceHelper.updateReadAssistedDLData(vzdl);
												}
											}
										}
									} catch (Exception e) {
										logger.error("Error on Tagging", e);
									}
									return Mono.just(ResponseEntity.status(HttpStatus.OK).body(resp));
								});
							});
				});
			}
				});

	}

	private void setRetrieveCartFeatureFlagsInResponse(RetrieveCartUIResponse resp) {
		Map<String, Boolean> featureFlags = new HashMap<>();
		boolean rfExDfoFeatureFlag = featureFlag.isFeatureFlagEnabled(AWS_CONFIG_APP_NAME,
				SALES, RFEX_ELIGIBILITY_FOR_DFO_FFLAG, false);
		featureFlags.put(RFEX_ELIGIBILITY_FOR_DFO_FFLAG, Boolean.valueOf(rfExDfoFeatureFlag));
		if(null!=resp && null!=resp.getData()){
			resp.getData().setFeatureFlags(featureFlags);
		}
	}

	/**
	 *
	 * @param httpRequest
	 * @param httpResponse
	 * @param request
	 * @return ResponseEntity
	 *
	 */
	@PostMapping({ "/nse/v2/validate-cart","/v2/validate-cart", "/nse/v2/retrieve-mini-cart", "/v2/retrieve-mini-cart" })
	public Mono<ResponseEntity<GenericResponse>> nseV2ValidateCart(ServerHttpRequest httpRequest,
																   ServerHttpResponse httpResponse, @Valid @RequestBody ValidateCartCXPRequest request) {
		if (httpRequest != null && httpRequest.getHeaders() != null && httpRequest.getHeaders().getFirst("Channelid") != null) {
			request.setClient(httpRequest.getHeaders().getFirst("Channelid"));
		}
		return redisHelper.getDataFromRedis().flatMap(redisData->{
			request.setCartId(redisData.getCartId());
			if(request.getClient()!=null && isDigital(request.getClient()) && StringUtilities.isNotEmptyOrNull(redisData.getCartId()))
				updateAbondonCartCookie(httpRequest,httpResponse,redisData.getCartId(),CartConstants.CUSTOMER_TYPE_PROSPECT);

			return nseValidateCart(httpRequest, httpResponse, request).flatMap(resObj->{
				onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse resp=ValidateCartTranslator.translateValidateCartUIResponse((onevz.soe.cart.ui.responses.ValidateCartUIResponse) resObj.getBody());
				Boolean isFiosAuthenticated=false; // CXTDT-450316
				if(enableMHOffers&&null!=resp&&null!=resp.getData()&&redisData!=null&&StringUtilities.isNotEmptyOrNull(redisData.getFiosAuthenticated())
						&&redisData.getFiosAuthenticated().contains("authenticated")){
					isFiosAuthenticated=true;
					resp.getData().setFiosAuthenticated(isFiosAuthenticated);

				}
				//https://onejira.verizon.com/browse/PRODDEF-13448
				String graphqlType = "";
				if (request.getMeta() != null && request.getMeta().containsKey("type"))
					graphqlType = request.getMeta().get("type");
				if(resp.getData().getValidateCartAndUpdate()!=null && resp.getData().getValidateCartAndUpdate().getLineDetails()!=null
						&& !CartConstants.RETRIEVE_MINI_CART_CAMELCASE.equalsIgnoreCase(graphqlType)) {
					logger.info("Add the no devices or accessories in the cart into Cookies.");
					httpResponse.addCookie(ResponseCookie.from(CartConstants.PROSPECT_CART_COUNT, String.valueOf(resp.getData().getValidateCartAndUpdate().getLineDetails().getNumOfAccessoryAndDeviceItemsInCart()))
							.path("/").httpOnly(false).build());

					boolean isHubProspectCartCookieDomainIssueFFlagEnabled= featureFlagHelper.isHubProspectCartCookieDomainIssueFFlagEnabled();
					if(resp.getData().getValidateCartAndUpdate().getLineDetails().getStandaloneAccessory()!=null && !resp.getData().getValidateCartAndUpdate().getLineDetails().getStandaloneAccessory()){
						if (resp.getData().getValidateCartAndUpdate().getLineDetails().getNumOfLines() > 0) {
							logger.info("Update hubProspectCart cookie to true when the cart is not empty");
							CartUtil.addHubProspectCartCookieToResponse(httpResponse, isHubProspectCartCookieDomainIssueFFlagEnabled, CartConstants.TRUE_FLAG, domains);
						} else {
							logger.info("Update hubProspectCart cookie to false when the cart is empty");
							CartUtil.addHubProspectCartCookieToResponse(httpResponse, isHubProspectCartCookieDomainIssueFFlagEnabled, CartConstants.FALSE, domains);
						}
					}
				}
				if(resp.getData().getValidateCartAndUpdate()!=null && (
						resp.getData().getValidateCartAndUpdate().getLineDetails() == null ||
								ObjectUtils.isEmpty(resp.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo())))
				{
					logger.info("Remove acNextGen cookie when lineDetails is empty");
					httpResponse.addCookie(ResponseCookie.from(CartConstants.AC_NEXTGEN, null)
							.path("/").httpOnly(false).maxAge(0).build());
				}
				return featureFlagHelper.fetchHolidayReturnPolicyNSEFFlag(FeatureFlagConstants.HOLIDAY_RETURN_POLICY_NSE_FLAG)
						.flatMap(res->
							 mergeFeatureFlagWithResponse(Mono.zip(Mono.just(resp),featureFlagHelper.fetchDigitalPerformanceCfgProfile(),
									featureFlagHelper.fetchMiniCartCfgProfile(),
									featureFlagHelper.fetchMarketingHomeFFlagStatus(FeatureFlagConstants.ALWAYS_ON_STICKEY_ORDER_SUMMARY_FLAG),
									featureFlagHelper.fetchMarketingHomeFFlagStatus(FeatureFlagConstants.ALWAYS_ON_PRICING_AlIGNMENT_FLAG),
									featureFlagHelper.fetchDigitalPromosCfgProfile(Arrays.asList(
											FeatureFlagConstants.DIGITAL_PROMOS_CFG_LIST_FOR_VALIDATE_CART.split(CartConstants.COMMA))),
									featureFlagHelper.fetchMarketingHomeFFlagStatus(FeatureFlagConstants.WIRELESS_CART_DESIGN_FFLAG),
									featureFlagHelper.fetchDigitaByodProfile(Arrays.asList(FeatureFlagConstants.BYOD_PROFILE_FEATURE_FLAGS.split(CartConstants.COMMA))))
									.zipWith(featureFlagHelper.isEnabledFFlagForPreToPostActivationFee(FeatureFlagConstants.FLAG_NAME_ACTIVATION_FEE_WAIVER_FFAG)),res)
						);
			});
		});
	}


	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return ResponseEntity
	 *
	 */
	@PostMapping({ "/nse/validate-cart", "/nse/retrieve-mini-cart" })
	public Mono<ResponseEntity<GenericResponse>> nseValidateCart(ServerHttpRequest httpHeader,
																 ServerHttpResponse httpResponse, @Valid @RequestBody ValidateCartCXPRequest request) {
		request.setCartId(null);
		request.setAccountNumber(null);
		return validateCart(httpHeader, httpResponse, request);
	}

	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return ResponseEntity
	 *
	 */
	@PostMapping({ "/validate-cart", "/retrieve-mini-cart", "/5g/validate-cart", "/nse/5g/validate-cart" ,"/5g/swap/validate-cart" , "/5g/cbd/validate-cart"})
	public Mono<ResponseEntity<GenericResponse>> validateCart(ServerHttpRequest httpHeader,
															  ServerHttpResponse httpResponse, @Valid @RequestBody ValidateCartCXPRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "validate-cart");
		logger.debug("validate-cart Request: {}", request);
		List<String> channelIdList = httpHeader.getHeaders().get(CartConstants.CHANNEL_ID);
		if (httpHeader.getHeaders() != null && channelIdList != null
				&& channelIdList.size() > 0)
			request.setChannelId(channelIdList.get(0));
		return readCartHelper.validateCart(request).flatMap(resp -> {
			ErrorResponse errors2 = null;
			if (resp.getErrors() != null) {
				errors2 = CartCxpResponseErrorsUtil.handleValidateCartResponseErrors(resp);
				if(StringUtils.isNotBlank(request.getChannelId()) && CartConstants.DIGITAL_DDOT_MOB_TAB_CHANNELS.contains(request.getChannelId()))
					CartPegaResponseErrorsUtil.setErrorCategory(errors2,CartConstants.ERRCAT_CJCM);
				return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(errors2));
			} else {
				setValidateCartFeatureFlagsInResponse(resp);
				if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))
						&& request.getMeta() != null) {
					String graphqlType = request.getMeta().get("type");
					if (resp.getData().getValidateCartAndUpdate() != null
							&& resp.getData().getValidateCartAndUpdate().getCartId() != null
							&& resp.getData().getValidateCartAndUpdate().getOrderDetails() != null
							&& StringUtilities.isNotEmptyOrNull(graphqlType)
							&& CartConstants.NEWCUSTOMER.equalsIgnoreCase(graphqlType)) {
						resp.getData().getValidateCartAndUpdate().setCartId(null);
					}
				}
				RetrieveCartRedisData rr = new RetrieveCartRedisData();
				List<LineRedisData> data = new ArrayList<LineRedisData>();
				Optional.ofNullable(resp.getData()).map(CXPValidateCartDataVO::getValidateCartAndUpdate)
						.map(CXPCartVO::getLineDetails).ifPresent(lineDetails -> {
					if (null != lineDetails) {
						if (null != lineDetails.getNumOfAccessoryAndDeviceItemsInCart()
								&& 0 == lineDetails.getNumOfAccessoryAndDeviceItemsInCart()) {
							logger.info("There are no devices or accessories in the cart.");
						}
						logger.info("number of lines in the cart is : {}",lineDetails.getNumOfLines());
						if(lineDetails.getNumOfLines()!=null){
							Map<String,String> sessionDataMap=new HashMap<>();
							sessionDataMap.put(CartConstants.DEVICE_COUNT,String.valueOf(lineDetails.getNumOfLines()));
							redisHelper2.upsertDeviceCartMapInRedis(sessionDataMap).subscribeOn(Schedulers.parallel()).subscribe(dt -> {
								logger.info("device count updated : {}",sessionDataMap);
							});
						}
						helper.nullifyBarCodeForIsDynOfferRebate(resp.getData().getValidateCartAndUpdate());
						Arrays.stream(lineDetails.getLineInfo()).filter(Objects::nonNull).forEach(lineInfo -> {
							if(lineInfo.getItemsInfo() != null && lineInfo.getItemsInfo().length > 0) {
								helper.nullifyBarCodeForUIAtLineLevel(Arrays.asList(lineInfo.getItemsInfo()));
							}
							ServiceInfo serviceInfo = Optional.ofNullable(lineInfo.getServiceInfo())
									.orElse(new ServiceInfo());
							LineRedisData lineData = new LineRedisData();
							lineData.setMtn(serviceInfo.getMtn());
							lineData.setSelectedALPShareList(serviceInfo.getSelectedALPShareList());
							data.add(lineData);
						});
						if (lineDetails.getLineInfo() != null && lineDetails.getLineInfo().length > 0) {
							updateAbondonCartCookie(
									lineDetails.getLineInfo()[lineDetails.getLineInfo().length - 1], httpHeader,
									httpResponse);

							//ACT60-390 - Cookie Update for Customers AbandonCart
							String flowType = CartConstants.EMPTY_STRING;
							String flowPath = httpHeader.getURI().toString();
							if(CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId())) &&
									StringUtilities.isNotEmptyOrNull(flowPath) &&
									!flowPath.contains(CartConstants.NSE_URL) &&
									null!=request.getMeta()) {
								String graphqlType = request.getMeta().get(CartConstants.TYPE);
								if(!CartConstants.NEWCUSTOMER.equalsIgnoreCase(graphqlType) &&
										null!=resp.getData() &&
										null!=resp.getData().getValidateCartAndUpdate() &&
										null!=lineDetails.getLineInfo() &&
										StringUtilities.isNotEmptyOrNull(resp.getData().getValidateCartAndUpdate().getCartId())) {
									List<String> flowTypeList = Arrays.stream(lineDetails.getLineInfo()).filter(lineInfo1 -> StringUtilities.isNotEmptyOrNull(lineInfo1.getLineActivityType())).map(lineInfo -> lineInfo.getLineActivityType())
											.collect(Collectors.toList());
									flowType = getFlowType(flowTypeList);
								}
							}
							if (StringUtilities.isNotEmptyOrNull(flowType))
								updateAbondonCartCookie(httpHeader, httpResponse, resp.getData().getValidateCartAndUpdate().getCartId(), flowType);
						}
					}
				});
				if (resp!=null && resp.getData()!=null && resp.getData().getValidateCartAndUpdate() != null){
					CXPCartVO validateCartAndUpdate = resp.getData().getValidateCartAndUpdate();
					if(resp.getData().getValidateCartAndUpdate().getCartValidationErrors()!= null){
						validateCartAndUpdate.getCartValidationErrors().stream()
								.filter(error -> CART_VALIDATION_ERROR_CODE.equals(error.getErrorCode()))
								.forEach(error -> error.setErrorMessage(CART_VALIDATION_ERROR_MESSAGE));
					}
					helper.nullifyBarCodeForUIAtOrderDetails(validateCartAndUpdate);
					if(validateCartAndUpdate.getOrderDetails()!=null &&
							CartConstants.NEW_CUSTOMER.equalsIgnoreCase(validateCartAndUpdate.getOrderDetails().getCustomerType()) &&
							validateCartAndUpdate.getLineDetails()!=null &&
							validateCartAndUpdate.getLineDetails().getLineInfo()!=null &&
							validateCartAndUpdate.getLineDetails().getLineInfo().length>0){
						httpResponse.addCookie(ResponseCookie.from(CartConstants.PROSPECT_CART_ACTIVE,CartConstants.TRUE_FLAG)
								.path("/").httpOnly(false).maxAge(Duration.ofHours(3)).build());
					}
					CartUtil.isCartContainsOnlyAccessories(validateCartAndUpdate);
					if(validateCartAndUpdate.getLineDetails() != null && validateCartAndUpdate.getLineDetails().getNumofAccessories() != null && validateCartAndUpdate.getLineDetails().getNumofAccessories() > 0)
					{
						httpResponse.addCookie(ResponseCookie.from(CartConstants.ACC_IN_CART,CartConstants.TRUE_FLAG)
								.path("/").httpOnly(false).maxAge(-1).build());
					}
					else {
						httpResponse.addCookie(ResponseCookie.from(CartConstants.ACC_IN_CART,CartConstants.FALSE)
								.path("/").httpOnly(false).maxAge(-1).build());
					}
				}
				rr.setData(data);
				if (resp != null && resp.getData() != null && resp.getData().getValidateCartAndUpdate() != null
						&& resp.getData().getValidateCartAndUpdate().getCartHeader() != null
						&& resp.getData().getValidateCartAndUpdate().getCartHeader().getVisionCustomerType() != null)
					redisHelper2
							.upsertNewCustFlowRedis(
									resp.getData().getValidateCartAndUpdate().getCartHeader().getVisionCustomerType())
							.subscribeOn(Schedulers.parallel()).subscribe(dt -> {
						logger.debug("NewCustOrderFlow updated");
					});

				if (null == rr.getData() || rr.getData().size() == 0)
				{
					if(CartUtil.isDigital(request.getChannelId()) && enableSecurityForCart) {
						removeSensitiveData(resp);
					}
					return Mono.just(ResponseEntity.status(HttpStatus.OK).body(resp));
				}
				return redisHelper2.upsertValueInRedis(CartConstants.PROMOHUB_SPOKE_JOURNEY, CartConstants.FALSE)
						.flatMap(redisResFlag -> {
							Mono<Tuple6<Boolean, Boolean, List<String>,Map, Boolean, Boolean>> zippedMono = Mono.zip(
									redisHelper2.upsertOrderEligibilityInRedis(request.getChannelId(), resp),
									redisHelper2.inFlightOrderCheck(resp),
									redisHelper2.readSoeCradleData(request, resp),
									redisHelper2.barCodeOfferCode(),
									featureFlagHelper.snTaggingFeatureFlag(),
									featureFlagHelper.isAccMemberMigrationEnabled());

							return zippedMono.flatMap(updated -> {
								logger.info("Upsert Order Eligiblity ", updated.getT1());
								logger.info("Upsert Order Inflight Eligiblity ", updated.getT2());
								String key = "z1OfferCode";
								Map<String, String> code = updated.getT4();
								if (code.containsKey(key) && code.get(key) != null) {
									updateBarCodeId(resp, code.get(key));
								}
								Boolean snTaggingFlag = updated.getT5();
								logger.info("second number tagging feature flag value : {}", snTaggingFlag);
								if(snTaggingFlag != null && snTaggingFlag) {
									updateSecondNumberSubFlow(resp);
								}
								Boolean isAccMemMigrationEnabled = updated.getT6();
								if(isAccMemMigrationEnabled != null && isAccMemMigrationEnabled) {
									updateSaveCartEmailIdIntoRedis(resp);
								}
								return redisHelper.upsertRetrieveCartDataIntoRedis(rr).flatMap(redisData -> {
									return redisHelper2.getCartOrderFlowType().flatMap(cartOrderFlowType -> {
										try {
											String graphqlType = "";
											if (request.getMeta() != null)
												graphqlType = request.getMeta().get("type");
											if (!CartConstants.NEWCUSTOMER.equalsIgnoreCase(graphqlType != null ? graphqlType : "")) {
												String flowType = OrderFlowTypeUtil.getFlowTypeValue(cartOrderFlowType);
												Optional.ofNullable(request.getPageId())
														.ifPresent(pageId->{
															if(!pageId.equalsIgnoreCase(PROMO_HUB))
																dlUtilityService.updateDlData(flowType);
														});
											}
											List<String> soiRtCartCountData = updated.getT3();
											setRtCartCount(resp, soiRtCartCountData);

										} catch (Exception e) {
											logger.error("Exception while calling dlUtility in validateCart", e);
										}
										if ("true".equalsIgnoreCase(processingMtnFlag)) {
											return redisHelper
													.deleteProcessingMtnFromRedis(CartConstants.PROCESSING_MTN)
													.flatMap(processingMtn -> {
														if(CartUtil.isDigital(request.getChannelId()) && enableSecurityForCart) {
															removeSensitiveData(resp);
														}
														return Mono
																.just(ResponseEntity.status(HttpStatus.OK).body(resp));
													});
										} else {
											if(CartUtil.isDigital(request.getChannelId()) && enableSecurityForCart) {
												removeSensitiveData(resp);
											}
											return Mono.just(ResponseEntity.status(HttpStatus.OK).body(resp));
										}
									});
								});
							});

						});
			}
		});

	}

	private void setValidateCartFeatureFlagsInResponse(ValidateCartUIResponse resp) {
		Map<String, Boolean> featureFlags = new HashMap<>();
		boolean rfExDfoFeatureFlag = featureFlag.isFeatureFlagEnabled(AWS_CONFIG_APP_NAME,
				SALES, RFEX_ELIGIBILITY_FOR_DFO_FFLAG, false);
		featureFlags.put(RFEX_ELIGIBILITY_FOR_DFO_FFLAG, Boolean.valueOf(rfExDfoFeatureFlag));
		if(null!=resp && null!=resp.getData()){
			resp.getData().setFeatureFlags(featureFlags);
		}
	}

	public void updateSecondNumberSubFlow(ValidateCartUIResponse resp) {
		String snSubFlow = "secnum";
		String empty = "";
			try {
				if (resp.getData().getValidateCartAndUpdate() != null && resp.getData().getValidateCartAndUpdate().getLineDetails() != null
						&& resp.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo() != null
						&& Arrays.stream(resp.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo())
							.anyMatch(lineInfo -> lineInfo.getSecondNumber() != null && CartConstants.NSE_BYOD_LINE_ACTIVITY.equalsIgnoreCase(lineInfo.getLineActivityType()))) {
					dlUtilityService.upsertVZPageSubFLow(snSubFlow, true, empty).subscribeOn(Schedulers.parallel())
							.subscribe();
				} else {
					dlUtilityService.upsertVZPageSubFLow(empty, false, snSubFlow).subscribeOn(Schedulers.parallel())
							.subscribe();
				}
			} catch (Exception e) {
				logger.error("Exception while calling dlService in validateCart to update subFlow value for second number", e);
			}
	}

	public void updateBarCodeId(ValidateCartUIResponse resp, String promoCode) {

		if(resp.getData()!=null && resp.getData().getValidateCartAndUpdate()!=null && resp.getData().getValidateCartAndUpdate().getOrderDetails()!=null && resp.getData().getValidateCartAndUpdate().getOrderDetails().getBarCodes()!=null && Arrays.asList(resp.getData().getValidateCartAndUpdate().getOrderDetails().getBarCodes()).contains(promoCode))
		{
			List<String> barCodes = Arrays.asList(resp.getData().getValidateCartAndUpdate().getOrderDetails().getBarCodes());
			Collections.replaceAll(barCodes,promoCode,"z1OfferApplied");
			resp.getData().getValidateCartAndUpdate().getOrderDetails().setBarCodes(barCodes.toArray(new String[0]));

		}
		if (resp.getData() != null && resp.getData().getValidateCartAndUpdate() != null && resp.getData().getValidateCartAndUpdate().getLineDetails() != null && resp.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo() != null) {
			for (CXPLineInfo cartlineInfo : resp.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()) {
				if (cartlineInfo.getItemsInfo() != null) {
					for (CXPItemInfo itemsInfo : cartlineInfo.getItemsInfo()) {
						if (itemsInfo.getCartItems()!=null && itemsInfo.getCartItems().getCartItem()!=null) {
							for (CXPCartItem cartItem : itemsInfo.getCartItems().getCartItem()) {
								if (cartItem.getSedOfferList() != null) {
									for (PosCartSEDOfferType sedOffer : cartItem.getSedOfferList().getSedOffer()) {
										if (sedOffer.getBarcodeID() != null && sedOffer.getBarcodeID().equalsIgnoreCase(promoCode)) {
											sedOffer.setBarcodeID("z1OfferApplied");
										}
									}
								}

							}
						}

					}
				}

			}
		}

	}

	private void setRtCartCount(ValidateCartUIResponse respObj, List<String> soiRtCartCountData) {
		if (CollectionUtilities.isNotEmptyOrNull(soiRtCartCountData) && respObj.getData().getValidateCartAndUpdate().getLineDetails()!= null
				&& respObj.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()!=null) {
			int count=0;
			for(CXPLineInfo line : respObj.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()) {
				if(line.getItemsInfo()!=null) {
					for(CXPItemInfo item: line.getItemsInfo()) {
						if (item.getCartItems() != null && item.getCartItems().getCartItem() != null)
							for(CXPCartItem cartItem: item.getCartItems().getCartItem()) {
								if(StringUtilities.isNotEmptyOrNull(cartItem.getProductId()) &&
										StringUtilities.isNotEmptyOrNull(soiRtCartCountData.get(count))) {
									cartItem.setRtCartCount(soiRtCartCountData.get(count));
								}
							}
					}
					count++;
				}
			}
		}
	}



	@SuppressWarnings("unchecked")
	private void updateAbondonCartCookie(CXPLineInfo cxpLineInfo, ServerHttpRequest httpHeader,
										 ServerHttpResponse httpResponse) {

		try {
			Map<String, String> cdlCartMap = new HashMap<>();
			CradleUtil cradleUtil = new CradleUtil();
			boolean cdlCartCookieEnabled = false;
			if(httpResponse.getCookies() != null && httpHeader.getCookies().get(Constants.THROTTLE_LIST_COOKIE_NAME) != null
					&& httpHeader.getCookies().get(Constants.THROTTLE_LIST_COOKIE_NAME).size()>0) {
				String cdlThrottleList = httpHeader.getCookies().get(Constants.THROTTLE_LIST_COOKIE_NAME).get(0).getValue();
				cdlCartCookieEnabled = cdlThrottleList!=null && cdlThrottleList.contains(CartConstants.ABANDON_CART);
			}

			if(cdlCartCookieEnabled) {
				if (httpHeader.getCookies().get(CartConstants.CDL_CART_INFO) != null
						&& httpHeader.getCookies().get(CartConstants.CDL_CART_INFO).size() > 0) {
					String cdlCartInfo = CradleUtil
							.getDecryptJSON(httpHeader.getCookies().get(CartConstants.CDL_CART_INFO).get(0).getValue());
					Gson gson = new Gson();
					cdlCartMap.putAll(gson.fromJson(cdlCartInfo, Map.class));
				}

				if(cxpLineInfo != null && cxpLineInfo.getItemsInfo() != null && cxpLineInfo.getItemsInfo().length>0 &&
						cxpLineInfo.getItemsInfo()[0].getCartItems() != null && cxpLineInfo.getItemsInfo()[0].getCartItems().getCartItem() != null) {
					Arrays.stream(cxpLineInfo.getItemsInfo()[0].getCartItems().getCartItem()).filter(
							item -> "DEVICE".equals(item.getCartItemType())).forEach(item -> {
						if (cxpLineInfo.getServiceInfo().getNewPricePlanInfo() != null) {
							cdlCartMap.put(CartConstants.PLAN_ID, cxpLineInfo.getServiceInfo().getNewPricePlanInfo().getPricePlanCode());
							cdlCartMap.put(CartConstants.PLAN, cxpLineInfo.getServiceInfo().getNewPricePlanInfo().getPricePlanDesc());
						} else if(cxpLineInfo.getServiceInfo().getSelectedALPShareList() != null
								&& cxpLineInfo.getServiceInfo().getSelectedALPShareList().getNewAlpShareInfo() != null
								&& cxpLineInfo.getServiceInfo().getSelectedALPShareList().getNewAlpShareInfo().length>0) {
							cdlCartMap.put(CartConstants.PLAN_SOR_ID, cxpLineInfo.getServiceInfo().getSelectedALPShareList().getNewAlpShareInfo()[0].getServicePlanId());
							cdlCartMap.put(CartConstants.PLAN, cxpLineInfo.getServiceInfo().getSelectedALPShareList().getNewAlpShareInfo()[0].getServicePlanDesc());
						}
						if(StringUtilities.isEmptyOrNull(cdlCartMap.get(CartConstants.CART_TYPE))) {
							cdlCartMap.put(CartConstants.CART_TYPE, CartConstants.PLAN);
							httpResponse.addCookie(ResponseCookie.from(CartConstants.CDL_CART_TYPE,CartConstants.PLAN)
									.path("/").httpOnly(false).secure(true).maxAge(Duration.ofDays(15)).build());
						}
						if(httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION) != null) {
							cdlCartMap.put(CartConstants.RTM_SESSION_ID, httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION).getValue());
						}
					});
					httpResponse.addCookie(ResponseCookie.from(CartConstants.CDL_CART_INFO,
							cradleUtil.getEncryptString(validator.convertObjectToString(cdlCartMap)))
							.path("/").httpOnly(false).secure(true).maxAge(Duration.ofDays(15)).build());
				}
			}
		} catch (Exception ex) {
			logger.error("Exception while creating abondon cart cookie in validateCart", ex);
		}
	}

	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return GenericResponse
	 *
	 */
	@PostMapping("/validate-ispuOrder")
	public Mono<ResponseEntity<GenericResponse>> validateISPUOrder(ServerHttpRequest httpHeader,
																   ServerHttpResponse httpResponse, @Valid @RequestBody ValidateISPUOrderUIRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "validate-ispuOrder");
		logger.debug("validate-ispuOrder Request: {}", request);
		return readCartHelper.validateISPUOrder(request).map(soeResonse -> {
			ErrorResponse errors2 = null;
			if (soeResonse.getErrors() != null) {
				errors2 = CartCxpResponseErrorsUtil.handleValidateISPUOrderOrderResponseErrors(soeResonse);
			}
			return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
					: ResponseEntity.status(HttpStatus.OK).body(soeResonse);

		});
	}

	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return GenericResponse
	 *
	 */
	@PostMapping({"/getDepletionType", "/nse/getDepletionType"})
	public Mono<ResponseEntity<GenericResponse>> getDepletionType(ServerHttpRequest httpHeader,
																  ServerHttpResponse httpResponse, @Valid @RequestBody GetDepletionTypeUIRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "getDepletionType");
		logger.debug("getDepletionType Request: {}", request);
		return readCartHelper.getDepletionType(request).map(soeResonse -> {
			ErrorResponse errors2 = null;
			if (soeResonse.getErrors() != null) {
				errors2 = CartCxpResponseErrorsUtil.handleGetDepletionTypeResponseErrors(soeResonse);
			}
			return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
					: ResponseEntity.status(HttpStatus.OK).body(soeResonse);

		});
	}

	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return response
	 *
	 */
	@PostMapping("/getUpgradeReasonCodes")
	public Mono<ResponseEntity<GenericResponse>> getUpgradeReasonCodes(ServerHttpRequest httpHeader,
																	   ServerHttpResponse httpResponse, @Valid @RequestBody GetUpgradeReasonCodeUIRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "getUpgradeReasonCOdes");
		logger.debug("getUpgradeReasonCodes Request: {}", request);
		return readCartHelper.getUpgradeReasonCodes(request).map(resp -> {
			ErrorResponse errors2 = null;
			if (resp.getErrors() != null) {
				errors2 = CartCxpResponseErrorsUtil.handleUpgradeReasonCodesResponseErrors(resp);
			}
			return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
					: ResponseEntity.status(HttpStatus.OK).body(resp);
		});
	}

	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return response
	 *
	 */
	@PostMapping("/check-dfill-inventory")
	public Mono<ResponseEntity<GenericResponse>> checkDfillInventory(ServerHttpRequest httpHeader,
																	 ServerHttpResponse httpResponse, @Valid @RequestBody CheckDfillInventoryUIRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "check-dfill-inventory");
		logger.debug("CheckDfillInventory Request: {}", request);
		return readCartHelper.checkDfillInventory(request).map(resp -> {
			ErrorResponse errors2 = null;
			if (resp.getErrors() != null) {
				errors2 = CartCxpResponseErrorsUtil.handleCheckDfillInventoryResponseErrors(resp);
			}
			return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
					: ResponseEntity.status(HttpStatus.OK).body(resp);
		});
	}

	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return ResponseEntity
	 *
	 */
	@PostMapping("/retrieveURC")
	public Mono<ResponseEntity<GenericResponse>> retrieveURCForCart(ServerHttpRequest httpHeader,
																	ServerHttpResponse httpResponse, @Valid @RequestBody RetrieveURCForCartUIRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "retrieveURC");
		logger.debug("retrieveURC Request: {}", request);

		ErrorResponse errors = CartCxpRequestErrorsUtil.handleRetrieveURCForCartRequestErrors(request);
		if (errors.getErrors() != null) {
			return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
		}
		return helper.retrieveURCForCart(request).map(resp -> {
			ErrorResponse errors2 = null;
			if (resp.getErrors() != null) {
				errors2 = CartCxpResponseErrorsUtil.handleRetrieveURCForCartResponseErrors(resp);
			}
			return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
					: ResponseEntity.status(HttpStatus.OK).body(resp);
		});
	}

	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return ResponseEntity
	 *
	 */
	@PostMapping({ "/nse/validateOrder", "/nse/5g/validateOrder" })
	public Mono<ResponseEntity<GenericResponse>> validateOrderForNSE(ServerHttpRequest httpHeader,
																	 ServerHttpResponse httpResponse, @Valid @RequestBody InitiateCheckoutUIRequest request) {

		if (null != request && null != request.getCartInfo()) {
			request.getCartInfo().setCartId(null);
			request.getCartInfo().setCaseId(null);
			request.getCartInfo().setAccountNumber(null);
		}
		return validateOrder(httpHeader, httpResponse, request);
	}

	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return ResponseEntity
	 */
	@PostMapping({ "/validateOrder", "/5g/validateOrder", "/5g/swap/validateOrder","/5g/cbd/validate-order" })
	public Mono<ResponseEntity<GenericResponse>> validateOrder(ServerHttpRequest httpHeader,
															   ServerHttpResponse httpResponse, @Valid @RequestBody InitiateCheckoutUIRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "validateOrder");
		logger.debug("validateOrder Request: {}", request);
		String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
				? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
				: "";
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleInitiateCheckoutRequestErrors(request);
		if (errors.getErrors() != null) {
			if(StringUtils.isNotBlank(request.getChannelId()) && CartConstants.DIGITAL_DDOT_MOB_TAB_CHANNELS.contains(channelId) )
				CartPegaResponseErrorsUtil.setErrorCategory(errors,CartConstants.ERRCAT_APP);
			return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
		}
		request.setChannelId(channelId);
		if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
				&& request.getCartInfo().getIntendType().toUpperCase().contains("NSE")
				&& StringUtilities.isNotEmptyOrNull(request.getCartInfo().getQuoteId()))
			logger.info("Express checkout (New Customer) with Quote: {}", request.getCartInfo().getQuoteId());
		else if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
				&& request.getCartInfo().getIntendType().toUpperCase().contains("NSE")
				&& CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(channelId)))
			logger.info("Express checkout (New Customer) without Quote");
		else if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getQuoteId()))
			logger.info("Express checkout with Quote: {}", request.getCartInfo().getQuoteId());
		else if (CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(channelId)))
			logger.info("Express checkout without Quote");
		String sessionId = "";
		HttpCookie cookieDigitIgSession = httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION);
		if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId))
				|| CartConstants.EXPRESS_STORE.equalsIgnoreCase(CartUtil.getChannelType(channelId)))
			sessionId = null != cookieDigitIgSession
					? cookieDigitIgSession.getValue()
					: "";
		request.getCartInfo().setSessionId(sessionId);
		return helper.validateOrder(request).map(pegaResponse -> {
			ErrorResponse errors2 = null;
			if (pegaResponse.getErrors() != null) {
				errors2 = CartPegaResponseErrorsUtil.handleInitiateCheckoutResponseErrors(pegaResponse);
				if(null != errors2){
					if(StringUtils.isNotBlank(request.getChannelId()) && CartConstants.DIGITAL_DDOT_MOB_TAB_CHANNELS.contains(channelId) )
						CartPegaResponseErrorsUtil.setErrorCategory(errors2,CartConstants.ERRCAT_APP);
				}
			}
			return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
					: ResponseEntity.status(HttpStatus.OK).body(pegaResponse);
		});

	}

	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return ResponseEntity
	 *
	 */
	@PostMapping({ "/validateCartAndCheckout", "/5g/validateCartAndCheckout", "/nse/5g/validateCartAndCheckout","/flexV2/validateCartAndCheckout" })
	public Mono<ResponseEntity<GenericResponse>> validateCartAndCheckout(ServerHttpRequest httpHeader,
																		 ServerHttpResponse httpResponse, @Valid @RequestBody InitiateCheckoutUIRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "validateCartAndCheckout");
		logger.debug("validateCartAndCheckout Request: {}", request);
		String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
				? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
				: "";
		request.setChannelId(channelId);
		if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
				&& request.getCartInfo().getIntendType().toUpperCase().contains("NSE")) {
			if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getQuoteId()) && (request.getCartInfo().getQuoteWithoutCredit() != null) && (!request.getCartInfo().getQuoteWithoutCredit())){
				logger.info(String.format("Proceed to Order (New Customer) with Credit and with Quote: %s", request.getCartInfo().getQuoteId()));
			} else if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getQuoteId()) && (request.getCartInfo().getQuoteWithoutCredit() != null) && request.getCartInfo().getQuoteWithoutCredit()) {
				logger.info(String.format("Proceed to Order (New Customer) without Credit and with Quote: %s", request.getCartInfo().getQuoteId()));
			}
			else if ((request.getCartInfo().getQuoteWithoutCredit() != null) && (!request.getCartInfo().getQuoteWithoutCredit())) {
				logger.info("Proceed to Order (New Customer) with Credit and with SharedCart");
			} else if((request.getCartInfo().getQuoteWithoutCredit() != null) && request.getCartInfo().getQuoteWithoutCredit()) {
				logger.info("Proceed to Order (New Customer) without Credit and with SharedCart" );
			}
			else if ((request.getCartInfo().getQuoteWithoutCredit() == null) && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getQuoteId())){
				logger.info(String.format("Proceed to Order (New Customer) with Quote: %s", request.getCartInfo().getQuoteId()));
			} else if(StringUtilities.isEmptyOrNull(request.getCartInfo().getQuoteId())){
				logger.info("Proceed to Order (New Customer) without Quote");
			}
		}
		else if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getQuoteId()))
			logger.info(String.format("Proceed to Order with Quote: %s", request.getCartInfo().getQuoteId()));
		else
			logger.info("Proceed to Order without Quote");
		//flexV2 check
		if (StringUtilities.isNotEmptyOrNull(httpHeader.getURI().getPath())) {
			String path = httpHeader.getURI().getPath().toString();
			if (path.contains("flexV2")){
				request.getCartInfo().setFlexV2(true);
			}
		}
		return helper.validateCartAndCheckout(request).flatMap(resp -> {
			return featureFlagHelper.fetchAssistedMFETaggingFeatureFlag()
					.flatMap(isFeatureEnabled -> {
						if (Boolean.TRUE.equals(isFeatureEnabled)
								&& request.getChannelId() != null
								&& CartUtil.isAssisted(request.getChannelId())) {
							return Mono.fromRunnable(() -> {
								dataForOrderReviewHandOffPage(httpHeader,request);
							}).then(Mono.just(resp));
						} else {
							return Mono.just(resp);
						}

					});
		}).map(resp -> {
			ErrorResponse errors2 = null;
			if (resp.getErrors() != null) {
				errors2 = CartPegaResponseErrorsUtil.handleInitiateCheckoutResponseErrors(resp);
			}
			return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
					: ResponseEntity.status(HttpStatus.OK).body(resp);
		});
	}

	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return ResponseEntity
	 *
	 */
	@PostMapping("/validateBYODTool")
	public Mono<ResponseEntity<GenericResponse>> validateBYODTool(ServerHttpRequest httpHeader,
																  ServerHttpResponse httpResponse, @Valid @RequestBody ValidateBYODToolCXPRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "validateBYODTool");
		logger.debug("ValidateBYODTool Request: {}", request);
		return helper.validateBYODTool(request).map(resp -> {
			ErrorResponse errors2 = null;
			if (resp.getErrors() != null) {
				errors2 = CartCxpResponseErrorsUtil.handleValidateBYODToolErrors(resp);
			}
			return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
					: ResponseEntity.status(HttpStatus.OK).body(resp);
		});
	}

	public static void removeSensitiveData(ValidateCartUIResponse resp)
	{
		if(resp!=null && resp.getData()!=null && resp.getData().getValidateCartAndUpdate()!=null) {
			resp.getData().getValidateCartAndUpdate().setCartId(null);
			if(resp.getData().getValidateCartAndUpdate().getLineDetails()!=null)
			{
				resp.getData().getValidateCartAndUpdate().getLineDetails().setCartId(null);
			}
		}
		if(resp!=null && resp.getData()!=null && resp.getData().getValidateCartAndUpdate()!=null &&
				resp.getData().getValidateCartAndUpdate().getCartHeader()!=null) {
			resp.getData().getValidateCartAndUpdate().getCartHeader().setCartId(null);
			resp.getData().getValidateCartAndUpdate().getCartHeader().setCaseId(null);
			resp.getData().getValidateCartAndUpdate().getCartHeader().setFullAccountNumber(null);

		}
	}

	public static void removeSensitiveDataFromRetrieveCart(RetrieveCartUIResponse resp)
	{
		if(resp!=null && resp.getData()!=null)
		{
			resp.getData().setCartId(null);
			if(resp.getData().getCart()!=null)
			{
				resp.getData().getCart().setCartId(null);
				if(resp.getData().getCart().getCartHeader()!=null)
				{
					resp.getData().getCart().getCartHeader().setCartId(null);
					resp.getData().getCart().getCartHeader().setCaseId(null);
				}
				if(resp.getData().getCart().getLineDetails()!=null)
				{
					resp.getData().getCart().getLineDetails().setCartId(null);
				}
			}
		}


	}

	@PostMapping({ "/isMtnEligibleForDisconnect"})
	public Mono<ResponseEntity<GenericResponse>> isMtnEligibleForDisconnect(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse, @Valid @RequestBody DisconnectEligibilityCheckUiRequest request)
	{
		System.setProperty(CartConstants.ENDPOINT, "isMtnEligibleForDisconnect");
		logger.debug("ValidateBYODTool Request: {}", request);
		ErrorResponse errors = CartPegaRequestErrorsUtil.validateDisconnectEligibilityCheckUiRequest(request);
		if(errors.getErrors()!=null)
			return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
		return readCartHelper.validateMtnEligibleForDisconnect(request).map(resp->{
			ErrorResponse errors2 = null;
			if (resp.getErrors() != null) {
				errors2.setErrors(resp.getErrors());
			}
			return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
					: ResponseEntity.status(HttpStatus.OK).body(resp);
		});
	}
	public boolean isDigital(String channelId) {
		if (StringUtils.isNotEmpty(channelId)) {
			SOEChannels channelType = SOEChannels.findByChannelName(channelId);
			if (channelType != null) {
				return DIGITAL_CHANNEL.equalsIgnoreCase(channelType.getChannelType());
			}
		}
		return false;
	}

	private void updateAbondonCartCookie(ServerHttpRequest httpHeader,
										 ServerHttpResponse httpResponse,String cartId,String flowType) {
		try {
			if(CartConstants.CUSTOMER_TYPE_PROSPECT.equals(flowType)) {
				//deleting the customer cookie
				httpResponse.addCookie(ResponseCookie.from(CartConstants.CUSTOMER_ABANDON_CART_AVAILABLE, "")
						.path("/").httpOnly(false).secure(true).maxAge(Duration.ofDays(0)).build());
				//adding prospect cookie
				httpResponse.addCookie(ResponseCookie.from(CartConstants.ACID, cartId)
						.path("/").httpOnly(true).secure(true).maxAge(Duration.ofDays(15)).build());
				httpResponse.addCookie(ResponseCookie.from(CartConstants.ABANDON_CART_AVAILABLE, "true")
						.path("/").httpOnly(false).secure(true).maxAge(Duration.ofDays(15)).build());
			}
			else{
				//deleting the prospect cookie
				httpResponse.addCookie(ResponseCookie.from(CartConstants.ABANDON_CART_AVAILABLE, "")
						.path("/").httpOnly(false).secure(true).maxAge(Duration.ofDays(0)).build());
				//adding customer cookie
				httpResponse.addCookie(ResponseCookie.from(CartConstants.ACID, cartId)
						.path("/").httpOnly(true).secure(true).maxAge(Duration.ofDays(15)).build());
				httpResponse.addCookie(ResponseCookie.from(CartConstants.CUSTOMER_ABANDON_CART_AVAILABLE, flowType)
						.path("/").httpOnly(false).secure(true).maxAge(Duration.ofDays(15)).build());
			}
		} catch (Exception ex) {
			logger.error("Exception while creating abondon cart cookie in validate-cart details", ex);
		}
	}

	private String getFlowType(List<String> flowTypeList){
		String flowType = CartConstants.EMPTY_STRING;
		if(flowTypeList.contains(CartConstants.AAL)) {
			flowType = CartConstants.AAL;
		}
		else if(flowTypeList.contains(CartConstants.EUP)) {
			flowType = CartConstants.EUP;
		}
		else if(flowTypeList.contains(CartConstants.ACC)) {
			flowType = CartConstants.ACC;
		}
		return flowType;
	}

	public void updateSaveCartEmailIdIntoRedis(ValidateCartUIResponse resp) {
		try {
			if(resp.getData() != null && resp.getData().getValidateCartAndUpdate() != null
					&& resp.getData().getValidateCartAndUpdate().getOrderDetails() != null
					&& resp.getData().getValidateCartAndUpdate().getOrderDetails().getSpocs() != null
					&& resp.getData().getValidateCartAndUpdate().getOrderDetails().getSpocs().getNotificationOptions() != null
					&& StringUtilities.isNotEmptyOrNull(resp.getData().getValidateCartAndUpdate().getOrderDetails().getSpocs().getNotificationOptions().getPrimaryEmailId())){
				redisHelper2
						.upsertValueInRedis(CartConstants.SAVE_CART_EMAILID, resp.getData().getValidateCartAndUpdate().getOrderDetails().getSpocs().getNotificationOptions().getPrimaryEmailId())
						.subscribeOn(Schedulers.parallel()).subscribe(dt -> {
							logger.debug("sendCarEmailId updated");
						});
			}
		} catch (Exception e) {
			logger.error("Exception while calling dlService in validateCart to update sendCarEmailId value", e);
		}
	}

	public Mono<ResponseEntity<GenericResponse>> mergeFeatureFlagWithResponse(Mono<Tuple2<Tuple8<onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse,
			ConfigurationProfile, ConfigurationProfile, Boolean, Boolean, Map<String,Flag>, Boolean,Map<String,Flag>>,Boolean>> zip, boolean res) {
		return zip.flatMap(tuples -> {
			var validateCartUIResponse = tuples.getT1().getT1();
			Optional.ofNullable(tuples.getT1().getT2())
					.map(ConfigurationProfile::getFlags)
					.ifPresent(listOfFeatureFlags -> {
						var mapOfFeatureFlags = listOfFeatureFlags
								.stream()
								.collect(Collectors.toMap(Flag::getName, flag -> featureFlagHelper.mapValueToFlagDetails().apply(flag), (oldEntry, newEntry) -> newEntry));
						validateCartUIResponse.getData().setFeatureConfigurationProfileData(mapOfFeatureFlags);
					});

			Optional.ofNullable(tuples.getT1().getT3())
					.map(ConfigurationProfile::getFlags)
					.ifPresent(listOfFeatureFlags -> {
						Map<String, FlagDetails> mapOfFeatureFlags = listOfFeatureFlags
								.stream()
								.collect(Collectors.toMap(Flag::getName, flag -> featureFlagHelper.mapValueToFlagDetails().apply(flag), (oldEntry, newEntry) -> newEntry));
						if(validateCartUIResponse.getData() != null) {
							if(validateCartUIResponse.getData().getFeatureConfigurationProfileData() != null
									&& validateCartUIResponse.getData().getFeatureConfigurationProfileData().size()>0) {
								validateCartUIResponse.getData().getFeatureConfigurationProfileData().putAll(mapOfFeatureFlags);
							} else {
								validateCartUIResponse.getData().setFeatureConfigurationProfileData(mapOfFeatureFlags);
							}
						}
					});

			Map<String, Boolean> featureFlags = new HashMap<>();
			Boolean orderSummaryFlagValue = tuples.getT1().getT4();
			Boolean pricingFlagValue = tuples.getT1().getT5();
			Boolean wirelessCartDesignFlag = tuples.getT1().getT7();
			Boolean preToPostActFeeFlag = tuples.getT2();
			featureFlags.put(FeatureFlagConstants.ALWAYS_ON_STICKEY_ORDER_SUMMARY_FLAG, orderSummaryFlagValue);
			featureFlags.put(FeatureFlagConstants.ALWAYS_ON_PRICING_AlIGNMENT_FLAG, pricingFlagValue);
			featureFlags.put(FeatureFlagConstants.WIRELESS_CART_DESIGN_FFLAG, wirelessCartDesignFlag);
			validateCartUIResponse.getData().setFeatureFlags(featureFlags);
			Map<String, FlagDetails> featureConfigurationProfileData = new HashMap<>();
			featureFlagHelper.addDigitalPromoFeatureFlag(tuples.getT1().getT6(),featureConfigurationProfileData);
			if(null!=tuples.getT1().getT8()){
				featureFlagHelper.addBYODFeatureFlag(tuples.getT1().getT8(),featureConfigurationProfileData);
			}
			featureFlags.put(FeatureFlagConstants.FLAG_NAME_ACTIVATION_FEE_WAIVER_FFAG, preToPostActFeeFlag);
			featureFlags.put(FeatureFlagConstants.HOLIDAY_RETURN_POLICY_NSE_FLAG, res);


			if(validateCartUIResponse.getData() != null) {
					if(validateCartUIResponse.getData().getFeatureConfigurationProfileData() != null
							&& !validateCartUIResponse.getData().getFeatureConfigurationProfileData().isEmpty()) {
							if(!featureConfigurationProfileData.isEmpty())
								validateCartUIResponse.getData().getFeatureConfigurationProfileData().putAll(featureConfigurationProfileData);
					} else {
							if(!featureConfigurationProfileData.isEmpty())
								validateCartUIResponse.getData().setFeatureConfigurationProfileData(featureConfigurationProfileData);
					}
				}
			return Mono.just(ResponseEntity.ok(validateCartUIResponse));
		});
	}

	/*
	private Mono<ResponseEntity<GenericResponse>> mergeFeatureFlagWithResponse(Mono<Tuple2<onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse, ConfigurationProfile, ConfigurationProfile>> zip) {
		return zip.flatMap(tuples -> {
			var validateCartUIResponse = tuples.getT1();
			Optional.ofNullable(tuples.getT2())
					.map(ConfigurationProfile::getFlags)
					.ifPresent(listOfFeatureFlags -> {
						var mapOfFeatureFlags = listOfFeatureFlags
								.stream()
								.collect(Collectors.toMap(Flag::getName, flag -> featureFlagHelper.mapValueToFlagDetails().apply(flag), (oldEntry, newEntry) -> newEntry));
						validateCartUIResponse.getData().setFeatureConfigurationProfileData(mapOfFeatureFlags);
					});
			Optional.ofNullable(tuples.getT3())
					.map(ConfigurationProfile::getFlags)
					.ifPresent(listOfFeatureFlags -> {
						var mapOfFeatureFlags = listOfFeatureFlags
								.stream()
								.collect(Collectors.toMap(Flag::getName, flag -> featureFlagHelper.mapValueToFlagDetails().apply(flag), (oldEntry, newEntry) -> newEntry));
						validateCartUIResponse.getData().setFeatureConfigurationProfileData(mapOfFeatureFlags);
					});

			featureFlagHelper.isDeviceAccessoryFlagEnabled().flatMap(value -> {
				validateCartUIResponse.getData().setFeatureConfigurationProfileData(mapOfFeatureFlags);
			});
			return Mono.just(ResponseEntity.ok(validateCartUIResponse));
		});
	}
	public void setDeviceAccessoryFlag(onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse resp) {
		if(resp.getData() != null && resp.getData().getValidateCartAndUpdate() != null
				&& resp.getData().getValidateCartAndUpdate().getLineDetails() != null
				&& resp.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo() != null
				&& resp.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo().size()>0){
			resp.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo().values().stream().forEach(lineInfo -> {
				if(lineInfo.getAccessories() != null && lineInfo.getAccessories().size()>0
						&& lineInfo.getDeviceItem()!=null) {
					if(resp.getData().getFeatureConfigurationProfileData()==null) {
						String x = "kishor";
						//resp.getData().setFeatureConfigurationProfileData(new HashMap());
					}
					//resp.getData().getFeatureConfigurationProfileData().put(FeatureFlagConstants.FEATURE_FLAG_DEVICE_ACCESSORY, );
				}
			});
		}
	}
	*/

	private void dataForOrderReviewHandOffPage(ServerHttpRequest httpHeader, InitiateCheckoutUIRequest request) {
		try {
			String sessionId = getSessionId(httpHeader, Optional.ofNullable(httpHeader.getHeaders().
					get(CartConstants.CHANNEL_ID)).filter(list->!list.isEmpty()).map(list->list.get(0)).orElse(""));
			String flow= request.getCartInfo().getFlowName();
			Vzdl vzdl = omniDLHelper.getVzdlDataForEventAndPage(sessionId,flow);
			if (vzdl != null) {
				cartAddDeviceHelper.updateDLDataForAssisted(vzdl);
			}
		} catch (Exception e) {
			logger.error("Error on Tagging", e);
		}

	}


	public String getSessionId(ServerHttpRequest httpHeader, String channelId) {
		String sessionId = "";
		HttpCookie cookieAssistedSession = httpHeader.getCookies().getFirst(CartConstants.ASSISTED_IG_SESSION_ID);
		if (StringUtilities.isEmptyOrNull(sessionId) && (CartConstants.RETAIL.equalsIgnoreCase(channelId) || CartConstants.RETAIL_IPAD.equalsIgnoreCase(channelId)
				||CartConstants.OMNI_TELESALES.equalsIgnoreCase(channelId)||CartConstants.OMNI_INDIRECT.equalsIgnoreCase(channelId)||
				CartConstants.OMNI_CARE.equalsIgnoreCase(channelId)))
			sessionId = null != cookieAssistedSession ? cookieAssistedSession.getValue() : "";
		return sessionId;
	}

	public Mono<DeviceIdValidationUIResponse> constructValidationResponseWithError(Throwable err){
		logger.info("Constructing error response with feature flags");
		SOEHTTPException exception = (SOEHTTPException) err;
		List<CartError> errors = new ArrayList<>();
		if(null != exception.getErrorHolder() && CollectionUtilities.isNotEmptyOrNull(exception.getErrorHolder().getErrors())) {
			exception.getErrorHolder().getErrors().forEach(soeError -> {
				var error = new CartError();
				error.setMessage(soeError.getMessage());
				error.setId(soeError.getId());
				error.setNamespace(soeError.getNamespace());
				error.setName(soeError.getName());
				errors.add(error);
			});
			DeviceIdValidationUIResponse response = new DeviceIdValidationUIResponse();
			DeviceIdValidationServiceBody serviceBody = new DeviceIdValidationServiceBody();
			DeviceIdValidationServiceResponse serviceResponse = new DeviceIdValidationServiceResponse();
			DeviceIdValidationContext context = new DeviceIdValidationContext();
			serviceResponse.setContext(context);
			serviceBody.setServiceResponse(serviceResponse);
			response.setServiceBody(serviceBody);

			response.setErrors(errors);
			return Mono.just(response);
		}
		return null;
	}
	@PostMapping({"/retrieve-dpp"})
	public Mono<ResponseEntity<GenericResponse>> retrieveDpp(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse, @Valid @RequestBody RetrieveDppRequest request) {
		logger.debug(" Request: {}", request);
		ErrorResponse errors = CartPegaRequestErrorsUtil.validateRetrieveDpp(request);
		if (errors.getErrors() != null)
			return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
		return readCartHelper.retrieveDppOption(request).map(resp -> {
			ErrorResponse errors2 = new ErrorResponse();
			if (resp.getErrors() != null) {
				errors2.setErrors(resp.getErrors());
			}
			return errors2.getErrors()!=null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
					: ResponseEntity.status(HttpStatus.OK).body(resp);
		});
	}
}
