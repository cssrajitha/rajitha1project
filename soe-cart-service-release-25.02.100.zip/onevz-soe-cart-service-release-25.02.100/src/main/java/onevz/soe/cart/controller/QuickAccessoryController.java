package onevz.soe.cart.controller;

import onevz.soe.cart.helper.AddQuickAccessoryToCartHelper;
import onevz.soe.cart.helper.SaveQuickAccessoryToCartHelper;
import onevz.soe.cart.model.addQuickAccessoryToCart.AddQuickAccessoryRequest;
import onevz.soe.cart.model.addQuickAccessoryToCart.AddQuickAccessoryResponse;
import onevz.soe.cart.ui.requests.SaveQuickAccessoryRequest;
import onevz.soe.cart.ui.responses.SaveQuickAccessoryResponse;
import onevz.soe.exception.SOEError;
import onevz.soe.utilities.StringUtilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping(value = "cart")
public class QuickAccessoryController {

    private static final Logger logger = LoggerFactory.getLogger(QuickAccessoryController.class);

    @Autowired
    private SaveQuickAccessoryToCartHelper quickAccessoryToCartHelper;

    @Autowired
    AddQuickAccessoryToCartHelper addQuickAccessoryToCartHelper;

    @PostMapping(value = {"/saveQuickAccessoryToCart"}, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<SaveQuickAccessoryResponse> saveQuickAccessoryToCart(@RequestBody SaveQuickAccessoryRequest request) {
        logger.info("QuickAccessoryController :saveQuickAccessoryToCart request {}", request);
        SaveQuickAccessoryResponse response = new SaveQuickAccessoryResponse();

        if (StringUtilities.isEmptyOrNull(request.getCartId())) {
            var errorList = createQuickAccessoryError();
            response.setErrors(errorList);
            return Mono.just(response);
        }
        return quickAccessoryToCartHelper.saveQuickAccessory(request);
    }

    @PostMapping("/add-quick-accessory")
    public Mono<AddQuickAccessoryResponse> addQuickAccessory(ServerHttpRequest httpRequest, @RequestBody AddQuickAccessoryRequest request) {
        String channelId = httpRequest.getHeaders().getFirst("channelId");
        return addQuickAccessoryToCartHelper.addQuickAccessoryToCart(channelId, request);
    }

    private List<SOEError> createQuickAccessoryError() {
        List<SOEError> errorList = new ArrayList<>();
        SOEError error = new SOEError();
        error.setMessage("CartId Cannot be Empty/Null");
        errorList.add(error);
        return errorList;
    }
}
