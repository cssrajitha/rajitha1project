package onevz.soe.cart.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.gql.requests.ACPInfoGQL;
import onevz.soe.cart.model.common.Address;
import onevz.soe.cart.model.retrieveCart.*;
import onevz.soe.logging.util.LoggerUtil;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.utilities.serialization.JacksonMapperFactory;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class CommonUtil2 {
    @Value("#{'${soe.fwa.discount.categoryCodes:FWADISCNT}'.split(',')}")
    private List<String> fwaSPOCategoryCodes;

    private static final Logger logger = LoggerFactory.getLogger(CommonUtil.class);
    

    public void populateOrderInfoDetails(CXPCartVO retrieveCartNSEResponse, Map<String, String> orderInfo)
    {
        RetrieveCartHeader cartHeader=retrieveCartNSEResponse.getCartHeader();
        if(cartHeader!=null && StringUtilities.isNotEmptyOrNull(cartHeader.getCartCreatorSalesRepId()))
        {
            orderInfo.put("salesRepId",cartHeader.getCartCreatorSalesRepId());
        }
        if(cartHeader != null && StringUtilities.isNotEmptyOrNull(cartHeader.getRedemptionCode())) {
            orderInfo.put("hasRedemptionCode", "Y");
            orderInfo.put("redemptionType", cartHeader.getRedemptionCode().substring(0,5));
        }
        CXPOrderDetails orderDetails=retrieveCartNSEResponse.getOrderDetails();
        populateOrderInfoDetailsSet(orderDetails,orderInfo);
    }
    private void populateOrderInfoDetailsSet(CXPOrderDetails orderDetails,Map<String, String> orderInfo)
    {
        orderInfo.put("orderStatus", "DSO_COMPLETED");
        if(orderDetails!=null) {
            if (null != orderDetails.getOrderList() && !orderDetails.getOrderList().isEmpty()
                    && orderDetails.getOrderList().get(0).getOrderNumber()!=null) {
                String orderNumber = String.valueOf(orderDetails.getOrderList().get(0).getOrderNumber());
                orderInfo.put("orderNumber", orderNumber);
            }
            if (orderDetails.getTotalDueToday()!=null) {
                String orderTotal = String.valueOf(orderDetails.getTotalDueToday());
                orderInfo.put("orderTotal", orderTotal);
            }
            if (StringUtilities.isNotEmptyOrNull(orderDetails.getLocationCode())) {
                orderInfo.put("locationCode", orderDetails.getLocationCode());
            }
            if (StringUtilities.isNotEmptyOrNull(orderDetails.getOrderType())) {
                orderInfo.put("orderType", orderDetails.getOrderType());
            }
            if (StringUtilities.isNotEmptyOrNull(orderDetails.getBillingState())) {
                orderInfo.put("billingState", orderDetails.getBillingState());
            }
            populateCreditStatusDetails(orderDetails, orderInfo);
        }
    }

    private void populateCreditStatusDetails(CXPOrderDetails orderDetails, Map<String, String> orderInfo) {
        //Credit Status Logging
        StringBuilder creditCode = new StringBuilder();
        if (StringUtilities.isNotEmptyOrNull(orderDetails.getCreditApprovalStatus())) {
            orderInfo.put("creditStatus", orderDetails.getCreditApprovalStatus());
            creditCode.append(orderDetails.getCreditApprovalStatus());
        }
        String creditReason = orderDetails.getCreditStatusReason();
        if (StringUtilities.isNotEmptyOrNull(creditReason)) {
            orderInfo.put("creditReason", creditReason);
            creditCode.append("|").append(creditReason.length() > 3 ? creditReason.substring(0,2) :creditReason);
        }
        if(StringUtils.isNotBlank(creditCode)) {
            orderInfo.put("creditCode", creditCode.toString());
        }
        populateOrOverrideCreditDetails(orderDetails,orderInfo);

    }

    private void populateOrOverrideCreditDetails(CXPOrderDetails orderDetails, Map<String, String> orderInfo) {
        if(null != orderDetails.getOrderList() && CollectionUtilities.isNotEmptyOrNull(orderDetails.getOrderList())) {
            Optional<OrderList> first = orderDetails.getOrderList().stream().filter(Objects::nonNull).findFirst();
            first.ifPresent(subOrder -> {
                CreditApplicationDetails creditApplication = subOrder.getCreditApplication();
                if(null != creditApplication) {
                    orderInfo.put("creditStatus", creditApplication.getCreditApprovalStatus());
                    String statusReason = creditApplication.getCreditStatusReason();
                    if(StringUtilities.isNotEmptyOrNull(statusReason)) {
                        orderInfo.put("creditReason", statusReason);
                        orderInfo.put("creditCode", creditApplication.getCreditApprovalStatus() + "|" +
                                (statusReason.length() > 3 ? statusReason.substring(0,2) : statusReason));
                    }
                }
            });
        }
    }

    public void populateLineInfoDetailsSet(CXPCartVO retrieveCartNSEResponse,Map<String, String> orderInfo)
    {
        StringBuilder stringplanName=new StringBuilder();
        StringBuilder stringplanSkuId=new StringBuilder();
        CXPLineDetailsVO lineDetails=retrieveCartNSEResponse.getLineDetails();
        if (lineDetails!=null && null!=lineDetails.getPayments() && !lineDetails.getPayments().isEmpty()
                && StringUtilities.isNotEmptyOrNull(lineDetails.getPayments().get(0).getPaymentType())) {
            orderInfo.put("paymentType", lineDetails.getPayments().get(0).getPaymentType());
        }
        int deviceCount = 0;
        if (lineDetails!=null && lineDetails.getNumOfLines()!=null) {
            orderInfo.put("numOfLines", String.valueOf(lineDetails.getNumOfLines()));
            deviceCount+=lineDetails.getNumOfLines();
        }
        populateAccessoryInfoDetail(lineDetails,orderInfo, deviceCount);
        if (null != lineDetails && null != lineDetails.getLineInfo()) {
            populateDeviceInfoDetails(lineDetails,orderInfo);
            final int deviceCountFinal = deviceCount;
            Arrays.stream(lineDetails.getLineInfo()).filter(Objects::nonNull).forEach(lineInfo1 -> {
                if(lineInfo1 != null) {
                    if(null != lineInfo1.getServiceInfo()) {
                        if (lineInfo1!=null && StringUtilities.isNotEmptyOrNull(lineInfo1.getServiceInfo().getContractTermId())) {
                            orderInfo.put("contractTerm", lineInfo1.getServiceInfo().getContractTermId());
                        }
                        if (lineInfo1.getServiceInfo().getNewPricePlanInfo() != null && StringUtilities.isNotEmptyOrNull(lineInfo1.getServiceInfo().getNewPricePlanInfo().getPricePlanDesc())) {
                            stringplanName.append(lineInfo1.getServiceInfo().getNewPricePlanInfo().getPricePlanDesc()+" | ");
                        }
                        if (lineInfo1.getServiceInfo().getNewPricePlanInfo() != null && StringUtilities.isNotEmptyOrNull(lineInfo1.getServiceInfo().getNewPricePlanInfo().getPricePlanCode())) {
                            stringplanSkuId.append(lineInfo1.getServiceInfo().getNewPricePlanInfo().getPricePlanCode()+" | ");
                        }
                        if ( StringUtilities.isNotEmptyOrNull(lineInfo1.getServiceInfo().getPrimaryUserInfo().getEmailId())) {
                            orderInfo.put("emailAddress", lineInfo1.getServiceInfo().getPrimaryUserInfo().getEmailId());
                        }
                        Address billingAddress = lineInfo1.getServiceInfo().getPrimaryUserInfo().getAddress();
                        Arrays.stream(lineInfo1.getItemsInfo()).filter(Objects::nonNull).forEach(itemsInfo -> {
                            populateItemsInfoDetailsSet(itemsInfo,billingAddress,orderInfo, deviceCountFinal);
                        });
                        StringBuilder discountString = new StringBuilder("");
                        if(null != lineInfo1.getServiceInfo().getSelectedFeaturesList()
                                && CollectionUtilities.isNotEmptyOrNull(lineInfo1.getServiceInfo().getSelectedFeaturesList().getVisFeature())) {
                            List<VisFeature> spoDiscounts = lineInfo1.getServiceInfo().getSelectedFeaturesList().getVisFeature().stream().filter(Objects::nonNull)
                                    .filter(vf -> "A".equalsIgnoreCase(vf.getAddDeleteInd()) && "L".equalsIgnoreCase(vf.getLevel()) && !Collections.disjoint(fwaSPOCategoryCodes, vf.getCategoryCodes())).collect(Collectors.toList());
                            spoDiscounts.stream().forEach(vf -> {
                                if(null != vf.getFeaturePrice())
                                discountString.append(Math.abs(Double.valueOf(vf.getFeaturePrice()))).append("_").append(vf.getFeatureDesc()).append(" |");
                            });
                        }
                        if(StringUtils.isNotEmpty(discountString)){
                            orderInfo.put("monthlyDiscounts", discountString.toString());
                        }
                    }
                    if (StringUtilities.isNotEmptyOrNull(lineInfo1.getLineActivityType())) {
                        orderInfo.put(CartConstants.INTEND_TYPE, lineInfo1.getLineActivityType());
                    }
                }
            });
            orderInfo.put("planName", stringplanName.toString());
            orderInfo.put("planSkuId", stringplanSkuId.toString());
        }
    }
    private void populateItemsInfoDetailsSet(CXPItemInfo itemsInfo,Address billingAddress,Map<String, String> orderInfo, int deviceCount)
    {
        if (itemsInfo != null) {
            if (StringUtilities.isNotEmptyOrNull(itemsInfo.getDepletionType())) {
                if ((itemsInfo.getDepletionType()).equalsIgnoreCase("F") || (itemsInfo.getDepletionType()).equalsIgnoreCase("L")) {
                    orderInfo.put("installType", "self");
                }
                if ((itemsInfo.getDepletionType()).equalsIgnoreCase("O")) {
                    orderInfo.put("installType", "professional");
                }
            }
            Address shippingAddress = itemsInfo.getShipping().getAddress();
            if (null != billingAddress && null != shippingAddress) {
                if (billingAddress.equals(shippingAddress)) {
                    orderInfo.put(CartConstants.BILLING_SHIPPING_ADDRESS_DIFFERENT_FLAG, CartConstants.FALSE_UPPERCASE);

                } else {
                    orderInfo.put(CartConstants.BILLING_SHIPPING_ADDRESS_DIFFERENT_FLAG, "TRUE");

                }
            } else {
                orderInfo.put(CartConstants.BILLING_SHIPPING_ADDRESS_DIFFERENT_FLAG, "TRUE");
            }
            populateItemsInfoDetails(itemsInfo,orderInfo, deviceCount);
        }
    }
    private void populateItemsInfoDetails(CXPItemInfo itemsInfo,Map<String, String> orderInfo, int deviceCount)
    {
        StringBuilder stringBuilder=new StringBuilder();
        if (itemsInfo.getShipping() != null && itemsInfo.getShipping().getAddress() != null && StringUtilities.isNotEmptyOrNull(itemsInfo.getShipping().getAddress().getAddressLine1())
                && StringUtilities.isNotEmptyOrNull(itemsInfo.getShipping().getAddress().getCity()) && StringUtilities.isNotEmptyOrNull(itemsInfo.getShipping().getAddress().getState())
                && StringUtilities.isNotEmptyOrNull(itemsInfo.getShipping().getAddress().getZipCode())) {
            String shippingAddressDetails = (itemsInfo.getShipping().getAddress().getAddressLine1()) + " " + (itemsInfo.getShipping().getAddress().getCity()) + " " + (itemsInfo.getShipping().getAddress().getState()) + " " + (itemsInfo.getShipping().getAddress().getZipCode());
            orderInfo.put("shippingAddress", shippingAddressDetails);
        }
        if (itemsInfo.getShipping() != null && StringUtilities.isNotEmptyOrNull(itemsInfo.getShipping().getShippingDescription())) {
            orderInfo.put("shippingType", itemsInfo.getShipping().getShippingDescription());
        }
        if (itemsInfo.getShipping() != null && StringUtilities.isNotEmptyOrNull(itemsInfo.getShipping().getShippingCode())) {
            orderInfo.put("shippingOption", itemsInfo.getShipping().getShippingCode());
        }
        CXPCartItemsVO itemsInfoDetails = itemsInfo.getCartItems();
        if(itemsInfoDetails != null)
            Arrays.stream(itemsInfoDetails.getCartItem()).filter(Objects::nonNull).forEach(cartItemInfo -> {
                if ((StringUtilities.isNotEmptyOrNull(cartItemInfo.getCartItemType()) && cartItemInfo.getCartItemType().equalsIgnoreCase(CartConstants.DEVICE_TYPE) &&
                        StringUtilities.isNotEmptyOrNull(cartItemInfo.getDeviceDisplayName()))
                        ||(StringUtilities.isNotEmptyOrNull(cartItemInfo.getNetworkBandwidthType()))) {
                    orderInfo.put("networkBandwidthType",cartItemInfo.getNetworkBandwidthType());
                    stringBuilder.append(cartItemInfo.getDeviceDisplayName()+" | ");
                }
        });
        orderInfo.put("NoOfDevices",String.valueOf(deviceCount));
        orderInfo.put("deviceName", stringBuilder.toString());
    }

    private void populateDeviceInfoDetails(CXPLineDetailsVO lineDetails,Map<String, String> orderInfo)
    {
        StringBuilder stringBuilder=new StringBuilder();
        CXPLineInfo[] lineInfo = Arrays.stream(lineDetails.getLineInfo()).filter(lineInf -> (lineInf.getLineNumber() != null && !"FEA".equalsIgnoreCase(lineInf.getLineActivityType()))).sorted(Comparator.comparing(CXPLineInfo::getLineNumber)).collect(Collectors.toList()).toArray(new CXPLineInfo[lineDetails.getNumOfLines()]);
        Arrays.stream(lineInfo).filter(Objects::nonNull).forEach(lineInfo1 -> {
            if (null != lineInfo1.getServiceInfo().getSelectedFeaturesList() && lineInfo1.getServiceInfo().getSelectedFeaturesList().getFeaturesCount() > 1) {
                lineInfo1.getServiceInfo().getSelectedFeaturesList().getVisFeature().stream().filter(Objects::nonNull).filter(visFeature ->
                        "A".equalsIgnoreCase(visFeature.getAddDeleteInd()) && "User".equalsIgnoreCase(visFeature.getSource())
                                && visFeature.getCategoryCodes().stream().anyMatch(str -> str.equalsIgnoreCase("VZHP"))).findFirst().ifPresent(visFeature -> {
                    if (StringUtilities.isNotEmptyOrNull(visFeature.getFeatureDesc()) && StringUtilities.isNotEmptyOrNull(visFeature.getVisFeatureCode())) {
                        stringBuilder.append(visFeature.getFeatureDesc()+" | "+visFeature.getVisFeatureCode());
                    }
                });
            }
        });
        if(StringUtils.isNotBlank(stringBuilder)) {
            orderInfo.put("protectionDeviceDetails",stringBuilder.toString());
        }
        if (null != lineDetails && null != lineDetails.getAcctMcsSubscription()) {
            lineDetails.getAcctMcsSubscription().stream().filter(Objects::nonNull).findFirst().ifPresent(mcsSubscription -> {
                if(StringUtilities.isNotEmptyOrNull(mcsSubscription.getName())) {
                    orderInfo.put("isYouTubeSubscribed", "True");
                }
            });
        }
    }
    public void populateAccessoryInfoDetail(CXPLineDetailsVO lineDetails,Map<String, String> orderInfo, int deviceCount)
    {
        StringBuilder stringAccessorySkus=new StringBuilder();
        StringBuilder stringAccessoryProductIds=new StringBuilder();
        StringBuilder stringAccessoryDisplayName=new StringBuilder();
        CXPLineInfo[] cartLineList;
        CXPItemInfo[] cartItemInfoList;
        CXPCartItem[] cartItemList;
        StringBuilder stringSkus=new StringBuilder();
        StringBuilder stringProductIds=new StringBuilder();
        if (lineDetails != null
                && lineDetails.getLineInfo() != null) {
            cartLineList = lineDetails.getLineInfo();
            Long accessoryCount = 0L;
            for (CXPLineInfo cartLine : cartLineList) {
                if (cartLine.getBundleAccessoryInfo() != null && !cartLine.getBundleAccessoryInfo().isEmpty()) {
                    accessoryCount = accessoryCount + cartLine.getBundleAccessoryInfo().size();
                }
                if (cartLine.getItemsInfo() != null) {
                    cartItemInfoList = cartLine.getItemsInfo();
                    for (CXPItemInfo cartItemInfo : cartItemInfoList) {
                        if (cartItemInfo.getCartItems() != null
                                && cartItemInfo.getCartItems().getCartItem() != null) {
                            accessoryCount = accessoryCount
                                    + Arrays.stream(cartItemInfo.getCartItems().getCartItem())
                                    .filter(c -> c.getCartItemType() != null
                                            && "ACCESSORY".equalsIgnoreCase(c.getCartItemType()))
                                    .count();
                            cartItemList=cartItemInfo.getCartItems().getCartItem();
                            for(CXPCartItem cart:cartItemList)
                            {
                                if(cart.getCartItemType()!=null && CartConstants.DEVICE_TYPE.equalsIgnoreCase(cart.getCartItemType())
                                        && cart.getSorId()!=null) {
                                    stringSkus.append(cart.getSorId()+" | ");
                                }
                                if(cart.getCartItemType()!=null && CartConstants.DEVICE_TYPE.equalsIgnoreCase(cart.getCartItemType())
                                        && cart.getProductId()!=null) {
                                    stringProductIds.append(cart.getProductId()+" | ");
                                }
                                if (cart.getCartItemType()!=null && "ACCESSORY".equalsIgnoreCase(cart.getCartItemType()))
                                {
                                    if(cart.getQty()!=null) {
                                        deviceCount+=cart.getQty();
                                        if (cart.getQty() >= 5) {
                                            orderInfo.put("is5sameaccessories", "True");
                                        } else {
                                            orderInfo.put("is5sameaccessories", "False");
                                        }
                                    }
                                    if(cart.getProductId()!=null) {
                                        stringAccessoryProductIds.append(cart.getProductId()+" | ");
                                    }
                                    if(cart.getSorId()!=null) {
                                        stringAccessorySkus.append(cart.getSorId()+" | ");
                                    }
                                    if(cart.getDeviceDisplayName()!=null) {
                                        stringAccessoryDisplayName.append(cart.getDeviceDisplayName()+" | ");
                                    }
                                }
                            }
                        }
                    }
                }
            }
            orderInfo.put("deviceSkus",stringSkus.toString());
            orderInfo.put("deviceProductIds",stringProductIds.toString());
            orderInfo.put("accessoryProductIds",stringAccessoryProductIds.toString());
            orderInfo.put("accessorySkus",stringAccessorySkus.toString());
            orderInfo.put("accessoryName",stringAccessoryDisplayName.toString());
            if (accessoryCount > 5) {
                orderInfo.put("is5Morethanaccessories", "TRUE");
            } else {
                orderInfo.put("is5Morethanaccessories", CartConstants.FALSE_UPPERCASE);
            }
            if (accessoryCount > 10) {
                orderInfo.put("is10Morethanaccessories", "TRUE");
            } else {
                orderInfo.put("is10Morethanaccessories", CartConstants.FALSE_UPPERCASE);
            }
        }
    }
    public void generateOrderInfoKibanaLogs(CXPCartVO retrieveCartNSEResponse)
    {
        Map<String, String> orderInfo = new HashMap<>();
        Map<String, String> fields = new HashMap<>();
        try {
            populateOrderInfoDetails(retrieveCartNSEResponse,orderInfo);
            populateLineInfoDetailsSet(retrieveCartNSEResponse,orderInfo);
            populateServiceAddress(retrieveCartNSEResponse.getLineDetails(),orderInfo);
            fields.put("orderinfo", JacksonMapperFactory.defaultWriter().writeValueAsString(orderInfo));
            LoggerUtil.addCustomPersistField(fields);
        } catch (Exception e) {
            logger.info(String.format("Error occurred while generating kibana logs: %s" , e));
        }
    }
    private void populateServiceAddress(CXPLineDetailsVO lineDetails,Map<String, String> orderInfo)
    {
        Arrays.stream(lineDetails.getLineInfo()).findFirst().filter(Objects::nonNull).ifPresent(lineInfo -> {
            Address cart5GAddress = null!= lineInfo.getServiceInfo()? lineInfo.getServiceInfo().getCart5GAddress(): null;
            if(null != cart5GAddress) {
                String serviceAddress = cart5GAddress.getAddressLine1() + (StringUtilities.isNotEmptyOrNull(cart5GAddress.getAddressLine2()) ? (cart5GAddress.getAddressLine2() + " "): (" " ))+ cart5GAddress.getCity() + " " + cart5GAddress.getState() + " " + cart5GAddress.getZipCode();
                orderInfo.put("serviceAddress", serviceAddress);
                orderInfo.put("serviceAddressId", cart5GAddress.getAddressIdNumber());
            }
        });
    }

    private void populateCartInfoDetails(CXPCartVO cart, Map<String, String> orderInfo) {
        RetrieveCartHeader cartHeader = new RetrieveCartHeader();
        if(cart!=null && cart.getCartHeader()!=null) {
            cartHeader = cart.getCartHeader();
        }
        if (cartHeader!=null && StringUtilities.isNotEmptyOrNull(cartHeader.getCartId())) {
            orderInfo.put("cartId", cartHeader.getCartId());
        }
        if(cartHeader != null && StringUtilities.isNotEmptyOrNull(cartHeader.getRedemptionCode())) {
            orderInfo.put("hasRedemptionCode", "Y");
            orderInfo.put("redemptionType", cartHeader.getRedemptionCode().substring(0,5));
            orderInfo.put("redemptionCode", cartHeader.getRedemptionCode());
        }
        if(cart!=null && cart.getOrderDetails() != null)
            populateCreditStatusDetails(cart.getOrderDetails(), orderInfo);

    }

    public void generateCartInfoKibanaLogs(CXPCartVO cart) {
        Map<String, String> cartInfo = new HashMap<>();
        Map<String, String> fields = new HashMap<>();
        populateCartInfoDetails(cart, cartInfo);
        try {
            fields.put("cartInfo", JacksonMapperFactory.defaultWriter().writeValueAsString(cartInfo));
            LoggerUtil.addCustomPersistField(fields);
        } catch (JsonProcessingException e) {
            logger.info(String.format("Error occurred while generating kibana logs: %s" , e));
        }
    }

    public void generateACPInfoKibanaLogs(ACPInfoGQL acpInfoGQL)
    {
        Map<String, String> acpInfo = new HashMap<>();
        Map<String, String> fields = new HashMap<>();
        try {
            acpInfo.put("nladSubscriberId", acpInfoGQL.getNladSubscriberId());
            acpInfo.put("EnrollmentNumber", acpInfoGQL.getEnrollmentNumber());
            acpInfo.put("benefit",acpInfoGQL.getBenefit());
            fields.put("acpInfo", JacksonMapperFactory.defaultWriter().writeValueAsString(acpInfo));
            LoggerUtil.addCustomPersistField(fields);
        } catch (Exception e) {
            logger.info(String.format("Error occurred while generating kibana logs: %s" , e));
        }
    }
}
