package onevz.soe.cart.controller.advice;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.support.WebExchangeBindException;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.common.CartErrorDetail;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.core.api.SOEExceptionHandler;
import onevz.soe.exception.SOEError;
import onevz.soe.exception.SOEErrorHolder;
import onevz.soe.exception.SOEException;
import onevz.soe.utilities.CollectionUtilities;
import reactor.core.publisher.Mono;

@ControllerAdvice(annotations = { RestController.class })
public class CartServiceExceptionHandler extends SOEExceptionHandler {

	@Value("${spring.application.name:soe}")
	private String namespace;

	private String endPoint;

	@ExceptionHandler(WebExchangeBindException.class)
	@ResponseBody
	public final ResponseEntity<ErrorResponse> handleException(WebExchangeBindException exception) {
		return ResponseEntity.badRequest().body(buildExceptionBody(exception));
	}

	private ErrorResponse buildExceptionBody(WebExchangeBindException exception) {

		if (exception.getBindingResult() != null) {
			List<CartError> soeErrorsList = new ArrayList<>();
			List<CartErrorDetail> details = new ArrayList<>();
			CartError soeError = new CartError();

			soeError.setNamespace(namespace);
			soeError.setMessage("Invalid data provided");
			if (CollectionUtilities.isNotEmptyOrNull(exception.getBindingResult().getFieldErrors())) {
				exception.getBindingResult().getFieldErrors().forEach(error -> {
					CartErrorDetail detail = new CartErrorDetail();
					detail.setField(error.getField());
					if (error.getDefaultMessage().contains("null") || error.getDefaultMessage().contains("empty")) {
						soeError.setName(CartConstants.MISSING_FIELDS);
						soeError.setId(CartConstants.MSNG_FLDS_ERR_CODE);
					}
					detail.setIssue(error.getDefaultMessage());
					details.add(detail);
				});
			} else if (CollectionUtilities.isNotEmptyOrNull(exception.getBindingResult().getAllErrors())) {
				exception.getBindingResult().getAllErrors().forEach(error -> {
					CartErrorDetail detail = new CartErrorDetail();
					detail.setField(error.getObjectName());
					if (error.getDefaultMessage().contains("null") || error.getDefaultMessage().contains("empty")) {
						soeError.setName(CartConstants.MISSING_FIELDS);
						soeError.setId(CartConstants.MSNG_FLDS_ERR_CODE);
					}
					detail.setIssue(error.getDefaultMessage());
					details.add(detail);
				});
			}
			soeError.setDetailList(details);
			soeErrorsList.add(soeError);
			return new ErrorResponse(soeErrorsList, null, null, null);
		}
		return null;

	}

	@ExceptionHandler(Exception.class)
	@ResponseBody
	public final ResponseEntity<SOEErrorHolder> handleException(Exception exception) throws URISyntaxException {
		endPoint = System.getProperty(CartConstants.ENDPOINT);
		if ("add-step".equalsIgnoreCase(endPoint)) {
			System.setProperty(CartConstants.ENDPOINT, "");
			SOEErrorHolder errorHolder = new SOEErrorHolder();
			List<SOEError> errors = new ArrayList<>();
			SOEError error = new SOEError();
			error.setNamespace("CartService");
			error.setMessage(exception.getMessage());
			errors.add(error);
			errorHolder.setErrors(errors);
			HttpHeaders responseHeaders = new HttpHeaders();
			URI uri = new URI(System.getProperty(CartConstants.REDIRECT_URI));
			responseHeaders.setLocation(uri);
			return ResponseEntity.status(HttpStatus.FOUND).headers(responseHeaders).body(errorHolder);
		}
		return super.handleException(exception);
	}

	public final Mono<ResponseEntity<SOEErrorHolder>> fetchAEMMessage(SOEException ex) {
		return super.fetchErrorMessage(ex);
	}
}
