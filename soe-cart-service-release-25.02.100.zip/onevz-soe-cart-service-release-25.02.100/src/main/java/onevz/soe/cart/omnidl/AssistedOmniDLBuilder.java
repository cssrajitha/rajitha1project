package onevz.soe.cart.omnidl;


import onevz.soe.cart.model.common.Vzdl;
import onevz.soe.omnidl.data.OmniDLData;
import onevz.soe.omnidl.data.OmniDLDataBuilder;

import java.util.*;

public class AssistedOmniDLBuilder extends OmniDLDataBuilder {
    public void buildData(Vzdl vzdl) {
        if(vzdl != null) {
            OmniDLData cartDLData = new OmniDLData();
            Map<String, Object> customData = new HashMap<>();
            populateTxnVzDLData(vzdl, customData);
            if (!customData.isEmpty()) {
                cartDLData.setCustomData(customData);
            }
            super.dlData = cartDLData;
        }
    }
    public void populateTxnVzDLData(Vzdl vzdl, Map<String, Object> customData) {

        if (vzdl.getTxn() != null) {
            customData.put("txn", vzdl.getTxn());
        }
        if (vzdl.getProduct() != null) {
            customData.put("txn.product", vzdl.getProduct());
        }
        if (vzdl.getPage() != null) {
            customData.put("page", vzdl.getPage());
        }
        if (vzdl.getUser() != null) {
            customData.put("user", vzdl.getUser());
        }
        if (vzdl.getEnv() != null) {
            customData.put("env", vzdl.getEnv());
        }
        if (vzdl.getEvent() != null) {
            customData.put("event", vzdl.getEvent());
        }
        if (vzdl.getUtils() != null) {
            customData.put("utils", vzdl.getUtils());
        }
    }

    public static class AssistedOmniBuilderService {
        public static AssistedOmniDLBuilder fromCartService(Vzdl vzdl) {
            AssistedOmniDLBuilder builder = new AssistedOmniDLBuilder();
            builder.buildData(vzdl);
            return builder;
        }
        public static AssistedOmniDLBuilder fromOrderConfirmationPage(Vzdl vzdl) {
            AssistedOmniDLBuilder builder = new AssistedOmniDLBuilder();
            builder.buildData(vzdl);
            return builder;
        }

    }
}
