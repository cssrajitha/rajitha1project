package onevz.soe.cart.cxp.helper;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.requests.*;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.util.CommonUtil;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.*;

/**
 * CartService Cxp Helper class.
 */
@Service
public class FiveGHomeCartCxpHelper {

	private static final Logger logger = LoggerFactory.getLogger(FiveGHomeCartCxpHelper.class);

	@Autowired
	private CartServiceCXPServices cxpService;
	@Autowired
    private CommonUtil util;
	@Autowired
	private CartServiceCxpHelper cartServiceCxpHelper;

	/**
	 *
	 * @param request
	 * @return RetrieveCartUIResponse
	 *
	 */
	public Mono<RetrieveCartCXPResponse> retrieve5GMoversCart(RetrieveCartCXPRequest request) {

		Mono<RetrieveCartCXPResponse> responseServiceMono;
		responseServiceMono = cxpService.retrieve5GMoversCart(request.getData().getCartId());
		return responseServiceMono.flatMap(retrieveCartCXPResponse -> {
			if (null != retrieveCartCXPResponse && null != retrieveCartCXPResponse.getData()) {
				try {
					cartServiceCxpHelper.updateDLData5g(retrieveCartCXPResponse, null, CartConstants.RETRIEVE, null, null);
				} catch (Exception e) {
					logger.error(CartConstants.RETRIEVE_OMNIDL_EXCEPTION, e);
				}
			}
			return Mono.just(retrieveCartCXPResponse);
		}).onErrorResume(throwable -> {
			SOEHTTPException exception = (SOEHTTPException) throwable;
			List<CartError> errors = new ArrayList<>();
			RetrieveCartCXPResponse response = new RetrieveCartCXPResponse();
			exception.getErrorHolder().getErrors().forEach(soeError -> {
				CartError error = new CartError();
				error.setMessage(soeError.getMessage());
				error.setId(soeError.getId());
				error.setNamespace(soeError.getNamespace());
				error.setName(soeError.getName());
				error.setDebug_id(soeError.getDebug_id());
				errors.add(error);
				response.setErrors(errors.toArray(new CartError[errors.size()]));
			});
			return Mono.just(response);
		});
	}


}
