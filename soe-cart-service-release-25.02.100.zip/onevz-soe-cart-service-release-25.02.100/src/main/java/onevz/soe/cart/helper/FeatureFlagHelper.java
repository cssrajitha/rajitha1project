package onevz.soe.cart.helper;

import onevz.cxp.feature.*;
import onevz.cxp.feature.util.FeatureFlag;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.constants.FeatureFlagConstants;
import onevz.soe.cart.model.addPromoIntent.AddPromoIntentUIResponse;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.RetrieveCartCXPResponse;
import onevz.soe.session.featureflag.FeatureFlagAdapter;
import onevz.soe.spring.web.filter.RequestAccessContext;
import onevz.soe.utilities.StringUtilities;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;
import onevz.soe.cart.ui.responses.v2.FlagDetails;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import reactor.util.function.Tuple2;

import java.util.Map;
import java.util.*;

import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class FeatureFlagHelper {
	
	private static final Logger logger = LoggerFactory.getLogger(FeatureFlagHelper.class);

    @Autowired
    FeatureFlag featureFlag;
    
    @Autowired
    FeatureFlagAdapter featureFlagAdapter;


    public Mono<Boolean> fetchD2DFeatureFlag(){
        return featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_ASSISTED,
                FeatureFlagConstants.PROFILE_ACCOUNTLANDING, FeatureFlagConstants.FLEXV2_D2D_FLAG,
                false);
    }
    public Mono<Boolean> fetchAssistedTaggingFeatureFlag(){
        return featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_ASSISTED,
                FeatureFlagConstants.PROFILE_FRAMEWORK, FeatureFlagConstants.FLEXV2_ASSISTED_TAGGING,
                false);
    }
    public Mono<Boolean> snTaggingFeatureFlag(){
        return featureFlag.isFeatureEnabled(FeatureFlagConstants.AWS_CONFIG_APP_NAME,
                FeatureFlagConstants.SN_AWS_CONFIG_PROFILE, FeatureFlagConstants.SECOND_NUMBER_TAGGING_FLAG, true);
    }

    public Mono<Boolean> isAccMemberMigrationEnabled(){
        return featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_UPG_CFG_PROFILE_NAME, FeatureFlagConstants.BAU_UPG_FLAG, FeatureFlagConstants.ENABLE_ACC_MEM_MIGRATION, "true");
    }
    public Mono<Boolean> fetchDigitalPegaPredictivePrefetchFFlag() {
        return featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_PERFORMANCE_CFG_PROFILE, FeatureFlagConstants.PEGA_PRDEDECTIVE_PREFETCHF_FLAG, false);
    }

    public Mono<ConfigurationProfile> fetchDigitalPerformanceCfgProfile() {
        return featureFlag.getConfigurationProfile(FeatureFlagConstants.APPLICATION_NAME_DIGITAL, FeatureFlagConstants.DIGITAL_PERFORMANCE_CFG_PROFILE);
    }
    public Function<Flag, FlagDetails> mapValueToFlagDetails() {
        return flag -> new FlagDetails(flag.isEnabled(),flag.isFound(),flag.getAttributes());
    }

    public Mono<Boolean> isRouterFlagEnabled() {
        return featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_FWA_DIFITAL,
                FeatureFlagConstants.ROUTER_UPGRADE_CFG_PROFILE, FeatureFlagConstants.ROUTER_UPGRADE_FF_FLAG, false);
    }


    public Mono<Boolean> isTradeInPromoCheckFflagEnabled() {
        return featureFlag.isFeatureEnabled(FeatureFlagConstants.AWS_CONFIG_APP_NAME,
                FeatureFlagConstants.SWIFT_CFG_PROFILE, FeatureFlagConstants.TRADE_IN_PROMOCCheckFFlag, false);
    }

    public boolean isRouterUpgradeFlagEnabled(){
        return featureFlag.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_FWA_DIFITAL,
                FeatureFlagConstants.ROUTER_UPGRADE_CFG_PROFILE, FeatureFlagConstants.ROUTER_UPGRADE_FF_FLAG, false);
    }

    public boolean isMoversUnifiedNBSEnabled() {
        return featureFlag.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_FWA_DIGITAL, FeatureFlagConstants.MOV_PROFILE_CONFIG,
                FeatureFlagConstants.FEATURE_FLAG_MOV_UNIFIED_NBS, false);
    }

    public boolean isMoversOmniCartReqEnabled() {
        return featureFlag.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_FWA_DIGITAL, FeatureFlagConstants.MOV_PROFILE_CONFIG,
                FeatureFlagConstants.FEATURE_FLAG_MOV_OMNI_CART_REQ, false);
    }
    public boolean isFWAUnifiedNBSEnabled() {
        return featureFlag.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_FWA_DIGITAL, FeatureFlagConstants.ENHANCEMENTTRIAGE_PROFILE_CONFIG,
                FeatureFlagConstants.FEATURE_FLAG_FWA_UNIFIED_NBS, false);
    }
    public boolean isAssistedLPMFETaggingFeatureFlag() {
        return featureFlag.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_ASSISTED,
                FeatureFlagConstants.PROFILE_ACCOUNTLANDING, FeatureFlagConstants.ASSISTED_LANDING_MFE_TAGGING_FFLAG,
                false);
    }
    public Mono<Boolean> isTrialHashFflagEnabled() {
        return  featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_MARKETING_HOME, FeatureFlagConstants.CONFIG_PROFILE_SALES,
				FeatureFlagConstants.EXISTING_TRIAL_HASH_VALIDATION_FFLAG, false);
    }
    
    public Mono<Boolean> fetchFiosLoginPDPPearlFFlagStatus() {
        return featureFlag.isFeatureEnabled(FeatureFlagConstants.AWS_CONFIG_APP_NAME,
                FeatureFlagConstants.PEARL_CFG_PROFILE, FeatureFlagConstants.FIOS_LOGIN_PDP_PEARL_FFLAG, false);
    }

    public Mono<Boolean> isWinbackOfferFlagEnabled() {
        return featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_OFFER_CFG_PROFILE, FeatureFlagConstants.ENABLE_WINBACK_OFFER_FFLAG, true);

    }
    public Mono<AddPromoIntentUIResponse> mergeFeatureFlagWithResponse(Mono<Tuple2<AddPromoIntentUIResponse, ConfigurationProfile>> zip) {
        return zip.flatMap(tuples -> {
            AddPromoIntentUIResponse response = tuples.getT1();
            Optional.ofNullable(tuples.getT2())
                    .map(ConfigurationProfile::getFlags)
                    .ifPresent(listOfFeatureFlags -> {
                        var mapOfFeatureFlags = listOfFeatureFlags
                                .stream()
                                .collect(Collectors.toMap(Flag::getName, flag -> mapValueToFlagDetails().apply(flag),(oldEntry, newEntry) -> newEntry));
                        if( response != null) {
                            response.setFeatureConfigurationProfileData(mapOfFeatureFlags);
                        }
                    });
            return Mono.just(response);
        }).doOnError(throwable -> logger.error(String.format("Error fetching configuration profile: {}", throwable.getMessage())));

    }


    //add featureflag for  NSE_returnpolicy
    public Mono<Boolean> fetchHolidayReturnPolicyNSEFFlag(String flagName) {
        return featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_PROMOS_CFG_PROFILE, flagName, false);
    }

    public Mono<Boolean> fetchMarketingHomeFFlagStatus(String flagName) {
        return featureFlag.isFeatureEnabled(FeatureFlagConstants.AWS_CONFIG_APP_NAME,
                FeatureFlagConstants.AWS_CONFIG_PROFILE, flagName, false);
    }

    public Mono<ConfigurationProfile> fetchMiniCartCfgProfile() {
        return featureFlag.getConfigurationProfile(FeatureFlagConstants.APPLICATION_NAME_DIGITAL, FeatureFlagConstants.DIGITAL_MINI_CART_CFG_PROFILE);
    }
    
	//https://onejira.verizon.com/browse/VZWYZDD-2629
    public Mono<Boolean> earlyUpgradeBlockerFeatureFlag(){
        FeatureFlagRequest featureFlagRequest = new FeatureFlagRequest();
        featureFlagRequest.setConfigurationProfile(FeatureFlagConstants.PROFILE_TRADEIN);
        featureFlagRequest.setFlagName(FeatureFlagConstants.EARLY_UPGRADE_BLOCKERF_FLAG);
        return featureFlagAdapter.isAssistedCSFeatureEnabled(featureFlagRequest);
    }

    public Mono<Boolean> fetchAssistedMFETaggingFeatureFlag(){
        return featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_ASSISTED,
                FeatureFlagConstants.PROFILE_FRAMEWORK, FeatureFlagConstants.ASSISTED_MFE_TAGGING_FFLAG,
                false);
    }



    public Mono<ConfigurationProfile> fetchDigitalUpgradeCfgProfile(){
        return featureFlag.getConfigurationProfile(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_UPG_CFG_PROFILE_NAME);
    }

    public Mono<Map<String, Flag>> fetchDigitalPromosCfgProfile(List<String> flagList) {
        return featureFlag.getFeatureFlagList(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_PROMOS_CFG_PROFILE,flagList);
    }

    public Mono<Map<String, Flag>> fetchMarketingCfgProfile(List<String> flagList) {
        return featureFlag.getFeatureFlagList(FeatureFlagConstants.AWS_CONFIG_APP_NAME,
                FeatureFlagConstants.SWIFT_CFG_PROFILE,flagList);
    }

    public Mono<Map<String, Flag>> fetchMarketingChoiceCfrProfile(List<String> flagList) {
        return featureFlag.getFeatureFlagList(FeatureFlagConstants.AWS_CONFIG_APP_NAME,
                FeatureFlagConstants.CHOICE_OFFER_CFG_PROFILE,flagList);
    }

    public Mono<Map<String, Flag>> fetchDigitalUpgradeCfgProfile(List<String> flagList) {
        return featureFlag.getFeatureFlagList(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_UPG_CFG_PROFILE_NAME,flagList);
    }

    public void addDigitalPerformanceFeatureFlag(ConfigurationProfile configurationProfile,
                                                 Map<String, FlagDetails> featureConfigurationProfileData){
        Optional.ofNullable(configurationProfile)
                .map(ConfigurationProfile::getFlags)
                .ifPresent(listOfFeatureFlags -> {
                    var mapOfFeatureFlags = listOfFeatureFlags.stream()
                            .collect(Collectors.toMap(Flag::getName, flag -> mapValueToFlagDetails().apply(flag),(oldEntry, newEntry) -> newEntry));
                    featureConfigurationProfileData.putAll(mapOfFeatureFlags);
                });
    }

    public void addDigitalPromoFeatureFlag(Map<String, Flag> fFlagMap,Map<String, FlagDetails> featureConfigurationProfileData){
        if(fFlagMap != null && !fFlagMap.isEmpty()){
            Map<String, FlagDetails> fFlagMapFinal = fFlagMap.entrySet()
                    .stream()
                    .collect(Collectors.toMap(Map.Entry::getKey, e -> mapValueToFlagDetails().apply(e.getValue())));
            featureConfigurationProfileData.putAll(fFlagMapFinal);
        }
    }

    public Boolean isLineInfoFeatureFlag() {
        return featureFlag.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_MARKETING_HOME,
                FeatureFlagConstants.CONFIG_PROFILE_SALES, FeatureFlagConstants.ENABLE_LINEINFO_FFLAG, false);
    }

    public Mono<Boolean> isNgdAbandonCartFFlag() {
        return featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.CONFIGURATOR, FeatureFlagConstants.NGD_ABANDONCART_FFLAG, false);
    }

    public Boolean isNgdTradeInBulkUpdateEnabled() {
        return featureFlag.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.CONFIGURATOR, FeatureFlagConstants.NGD_PLANS_TRADEIN_FLOW, false);
    }
    public Boolean isNgdProspectClearCartCookiesEnabled() {
        return featureFlag.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.CONFIGURATOR, FeatureFlagConstants.NGD_CLEAR_CART_NSE_FFLAG, false);
    }

    public boolean isMaskingForBYODFFlag() {
        return featureFlag.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.CONFIG_PROFILE_BYOD, FeatureFlagConstants.ENABLE_MASKING_BYOD, false);
    }
    public Mono<Boolean> amNextGenFeatureFlag(){
        return featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL, FeatureFlagConstants.DIGITAL_UPG_CFG_PROFILE_NAME, FeatureFlagConstants.ENABLE_AM_NEXTGEN_FFLAG, false);
    }
    public boolean bmsmFeatureFlag(RetrieveCartCXPResponse cartResponse){
        FeatureFlagRequest featureFlagRequest = new FeatureFlagRequest();
        featureFlagRequest.setApplicationName(FeatureFlagConstants.AWS_CONFIG_APP_NAME);
        featureFlagRequest.setConfigurationProfile(FeatureFlagConstants.AWS_CONFIG_PROFILE);
        featureFlagRequest.setFlagName(FeatureFlagConstants.AWS_FLAG_BMSM_OFFER);
        featureFlagRequest.setDefaultValue(false);
        if(cartResponse != null && cartResponse.getData() != null && cartResponse.getData().getCart() != null
                && cartResponse.getData().getCart().getCartHeader() != null && cartResponse.getData().getCart().getCartHeader().getCartCreatorOrderLocationCode() != null) {
            featureFlagRequest.setLocationCode(cartResponse.getData().getCart().getCartHeader().getCartCreatorOrderLocationCode());
        }
        return featureFlag.isFeatureFlagEnabled(featureFlagRequest);

    }

    public Boolean trade3POChoiceOfferFFlag() {
        return featureFlag.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_ASSISTED,
                FeatureFlagConstants.OFFERS_CFG_PROFILE, FeatureFlagConstants.TRADE_3PO_CHOICE_OFFER_FLAG, false);
    }
    
    public Mono<Boolean> emberDiscountFeatureFlagMono() {
        return featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_MARKETING_HOME,
                FeatureFlagConstants.EMBER_CONFIG_PROFILE_NAME, FeatureFlagConstants.EMBER_DISCOUNT_F_FLAG, false);
    }
    
    public Boolean emberDiscountFeatureFlag() {
        return featureFlag.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_MARKETING_HOME,
                FeatureFlagConstants.EMBER_CONFIG_PROFILE_NAME, FeatureFlagConstants.EMBER_DISCOUNT_F_FLAG, false);
    }

    public boolean getFeatureFlagWithAccNumThrottle(String appName, String configProfile, String flagName, String accNum, String mtn) {
        onevz.cxp.feature.FeatureFlagRequest featureFlagRequest = new onevz.cxp.feature.FeatureFlagRequest();
        featureFlagRequest.setApplicationName(appName);
        featureFlagRequest.setConfigurationProfile(configProfile);
        featureFlagRequest.setFlagName(flagName);
        String formattedAccNo = formatAccNoForFeatureFlag(accNum);
        featureFlagRequest.setCustomerId(formattedAccNo != null ? formattedAccNo : "");
        featureFlagRequest.setMtn(mtn != null ? mtn : "");
        boolean  accNumThrottleFFlag = featureFlag.isFeatureFlagEnabled(featureFlagRequest);
        logger.info("getFeatureFlagWithAccNumThrottle accNumThrottleFFlag value: {}", accNumThrottleFFlag);
        return accNumThrottleFFlag;
    }

    private String formatAccNoForFeatureFlag(String accountNumber) {
        if(StringUtilities.isNotEmptyOrNull(accountNumber) && accountNumber.contains("-")){
            accountNumber = accountNumber.substring(1,accountNumber.indexOf("-"));
        }
        return accountNumber;
    }
    public Boolean isDeviceFirstEnableForProspectBYODFFlag() {
        return featureFlag.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.CONFIG_PROFILE_BYOD, FeatureFlagConstants.ENABLE_DEVICEFIRST_PROSPECT, false);
    }
    public Boolean isDeviceFirstEnableForExistingBYODFFlag() {
        return featureFlag.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.CONFIG_PROFILE_BYOD, FeatureFlagConstants.ENABLE_DEVICEFIRST_EXISTING, false);
    }

    public Mono<Map<String, Flag>> fetchDigitaByodProfile(List<String> flagList) {
        return featureFlag.getFeatureFlagList(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.CONFIG_PROFILE_BYOD,flagList);
    }

    public Mono<Boolean> isEnabledFFlagForPreToPostActivationFee(String flagName) {
        String preToPostMigrationCookie = RequestAccessContext.obtainCookie(Arrays.asList(CartConstants.PREPAID_TO_POSTPAID_MIGRATION));
        if (StringUtilities.isNotEmptyOrNull(flagName)) {
            Mono<Boolean> featureFlagVaue = featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                    FeatureFlagConstants.PRE_TO_POST_CFG_PROFILE_NAME, flagName,
                    Boolean.FALSE);
            if (featureFlagVaue != null &&  StringUtilities.isNotEmptyOrNull(preToPostMigrationCookie)) {
                return featureFlagVaue.flatMap(activationFeeFlag -> {
                    if (BooleanUtils.isTrue(activationFeeFlag)) {
                        return Mono.just(Boolean.TRUE);
                    }
                    return Mono.just(Boolean.FALSE);
                });
            }
        }
        return Mono.just(Boolean.FALSE);
    }

    public Map<String, FlagDetails> addBYODFeatureFlag(Map<String, Flag> fFlagMap,Map<String, FlagDetails> featureConfigurationProfileData){
        if(fFlagMap != null && !fFlagMap.isEmpty()){
            Map<String, FlagDetails> fFlagMapFinal = fFlagMap.entrySet()
                    .stream()
                    .collect(Collectors.toMap(Map.Entry::getKey, e -> mapValueToFlagDetails().apply(e.getValue())));
            featureConfigurationProfileData.putAll(fFlagMapFinal);
        }
        return featureConfigurationProfileData;
    }
    public Mono<ConfigurationProfile> fetchDigitalByodProfile() {
        return featureFlag.getConfigurationProfile(FeatureFlagConstants.APPLICATION_NAME_DIGITAL, FeatureFlagConstants.CONFIG_PROFILE_BYOD);
    }
    public Map<String,FlagDetails> addConfigurationProfileFeatureFlags(ConfigurationProfile profile, Map<String,FlagDetails> mapOfFeatureFlags){
        Optional.ofNullable(profile)
                .map(ConfigurationProfile::getFlags)
                .ifPresent(listOfFeatureFlags ->
                    mapOfFeatureFlags.putAll(listOfFeatureFlags
                            .stream()
                            .collect(Collectors.toMap(Flag::getName, flag -> mapValueToFlagDetails().apply(flag),(oldEntry, newEntry) -> newEntry))));
        return mapOfFeatureFlags;
    }

    public Mono<Boolean> isSkipResumeCaseFFlagEnabled() {
        return featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_UPG_CFG_PROFILE_NAME, FeatureFlagConstants.SKIP_RESUME_CASE_FFLAG, false);
    }

    public Boolean isPOYPEnabled() {
        return featureFlag.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_PROMOS_CFG_PROFILE, FeatureFlagConstants.POYP_OFFER_FFLAG, false);
    }

    public boolean isSkipCartValidationOnUpdateCouponForFWA() {
        return featureFlag.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_FWA_DIFITAL, FeatureFlagConstants.ENHANCEMENTTRIAGE_PROFILE_CONFIG, FeatureFlagConstants.SKIP_VALIDATE_CART_FFLAG, false);
    }
    
    public Mono<Boolean> fetchAiQuoteTaggingFeatureFlag() {
        return featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_ASSISTED,
                FeatureFlagConstants.PROFILE_QUOTECFG, FeatureFlagConstants.AIQUOTE_TAGGING_ENABLED,
                false);
    }

    public Mono<Boolean> isBauUpgPdpTradeinFFlagEnabled() {
        return featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_UPG_CFG_PROFILE_NAME, FeatureFlagConstants.BAU_UPGRADE_PDP_TRADEIN_FFLAG, false);
    }

    public boolean isBYODIMEIRangeFFlagEnabled() {
        return featureFlag.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.CONFIG_PROFILE_BYOD, FeatureFlagConstants.BYOD_IMEI_RANGE_FFLAG, false);
    }

    public Boolean isPlanSelectionProgressivePlansFFlagEnabled() {
        return featureFlag.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_PLANS_CFG_FILE, FeatureFlagConstants.PLAN_SELECTION_PROGRESSIVE_PLANS_FFLAG, false);
    }

    public Mono<Boolean> fetchMonoElvisFeatureFlag(boolean isProspectFlow){
        boolean isElvisEnabled = false;
        if(isProspectFlow){
            FeatureFlagRequest prospectElvisFlagRequest = new FeatureFlagRequest();
            prospectElvisFlagRequest.setFlagName(FeatureFlagConstants.ELVIS_FLAG_NAME);
            prospectElvisFlagRequest.setConfigurationProfile(FeatureFlagConstants.ELVIS_FLAG_PROFILE);
            prospectElvisFlagRequest.setApplicationName(FeatureFlagConstants.SOR_XCIO);
            prospectElvisFlagRequest.setDefaultValue(Boolean.FALSE);
            prospectElvisFlagRequest.setCustomerId(FeatureFlagConstants.PROSPECT);
            isElvisEnabled = featureFlag.isFeatureFlagEnabled(prospectElvisFlagRequest);
        }else{
            isElvisEnabled=featureFlag.isFeatureFlagEnabled(FeatureFlagConstants.SOR_XCIO, FeatureFlagConstants.ELVIS_FLAG_PROFILE, FeatureFlagConstants.ELVIS_FLAG_NAME, Boolean.FALSE);
        }
        return Mono.just(isElvisEnabled);
    }
    public boolean isBYODIMEIInstructionsFFlagEnabled() {
        return featureFlag.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.CONFIG_PROFILE_BYOD, FeatureFlagConstants.ENABLE_IMEI_INSTRUCTIONS_FFLAG, false);
    }

    public boolean isPendingOrderRedirectionFFlagEnabled() {
        return featureFlag.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.ACCOUNT_MANAGEMENT_CX, FeatureFlagConstants.PENDING_ORDER_REDIRECTION_FFLAG, false);
    }


    public Mono<Boolean> fetchBulkUpdateAiQuoteTaggingFeatureFlag() {
        return featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_ASSISTED,
                FeatureFlagConstants.PROFILE_QUOTECFG, FeatureFlagConstants.BULKUPDATE_AIQUOTE_TAGGING_ENABLED,
                false);
    }

    public boolean isPastDueBYODFFlag() {
        return featureFlag.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.CONFIG_PROFILE_BYOD, FeatureFlagConstants.PAST_DUE_BYOD_FLAG, false);
    }

    public Mono<Boolean> fetchUnifiedNBSFeatureFlag(CartRedisData redisData) {
        return featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL, FeatureFlagConstants.UNIFIEDNBS_CONFIG_PROFILE,
                FeatureFlagConstants.FULLBLOWNNBS_THROTTLING, null, redisData.getMtn(), null, redisData.getAccountNumber(),
                null, null, false);
    }

    public boolean isSafeCheckForBuyOutFFlag() {
        return featureFlag.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_UPG_CFG_PROFILE_NAME,
                FeatureFlagConstants.SAFE_CHECK_FOR_BUYOUT_FFLAG,
                false);
    }

    public boolean isOneclkTaggingFFlagEnabled() {
        return featureFlag.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_UPG_CFG_PROFILE_NAME,
                FeatureFlagConstants.ONECLIK_TAGGING_FFLAG,
                false);
    }

    public boolean isHubProspectCartCookieDomainIssueFFlagEnabled() {
        boolean hubProspectCartCookieDomainIssueFFlagEnabled = featureFlag.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_PDP_CFG_PROFILE,
                FeatureFlagConstants.HUB_PROSPECT_CART_COOKIE_DOMAIN_ISSUE_FFLAG,
                false);
        logger.info("hubProspectCartCookieDomainIssueFFlagEnabled is {}", hubProspectCartCookieDomainIssueFFlagEnabled);
        return hubProspectCartCookieDomainIssueFFlagEnabled;
    }

    public Mono<Boolean> isFlexV2ValidationEnabled() {
        return featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_ASSISTED,
                FeatureFlagConstants.PROFILE_FRAMEWORK, FeatureFlagConstants.FLEX_MFE_VALIDATION, false);
    }
}

