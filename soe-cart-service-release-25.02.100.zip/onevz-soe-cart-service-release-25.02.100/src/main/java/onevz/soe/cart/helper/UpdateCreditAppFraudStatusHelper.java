package onevz.soe.cart.helper;

import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.model.updateCreditAppFraud.UpdateCreditAppFraudStatusCxpRequest;
import onevz.soe.cart.ui.requests.UpdateCreditAppFraudStatusRequest;
import onevz.soe.cart.ui.responses.UpdateCreditAppFraudStatusMainResponse;
import onevz.soe.cart.ui.responses.UpdateCreditAppFraudStatusResponse;
import onevz.soe.utilities.StringUtilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
public class UpdateCreditAppFraudStatusHelper {
    private static final Logger logger = LoggerFactory.getLogger(UpdateCreditAppFraudStatusHelper.class);

    @Autowired
    private CartServiceCXPServices cartServiceCXPServices;

    public Mono<UpdateCreditAppFraudStatusMainResponse> updateCreditAppFraudStatus(UpdateCreditAppFraudStatusRequest request) {
        UpdateCreditAppFraudStatusCxpRequest updateCreditAppFraudStatusCxpRequest = new UpdateCreditAppFraudStatusCxpRequest();
        UpdateCreditAppFraudStatusMainResponse updateCreditAppFraudStatusMainResponse=new UpdateCreditAppFraudStatusMainResponse();
        UpdateCreditAppFraudStatusResponse updateCreditAppFraudStatusResponse=new UpdateCreditAppFraudStatusResponse();
        UpdateCreditAppFraudStatusMainResponse.UpdateCreditAppFraudStatusData updateCreditAppFraudStatusData=new UpdateCreditAppFraudStatusMainResponse.UpdateCreditAppFraudStatusData();
        UpdateCreditAppFraudStatusCxpRequest.UpdateCreditAppFraudStatusCxpRequestData updateCreditAppFraudStatusCxpRequestData=new UpdateCreditAppFraudStatusCxpRequest.UpdateCreditAppFraudStatusCxpRequestData();
        if(StringUtilities.isNotEmptyOrNull(request.getCcaAppNum())){
            updateCreditAppFraudStatusCxpRequestData.setCcaAppNum(request.getCcaAppNum());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getFpforId())){
            updateCreditAppFraudStatusCxpRequestData.setFpforId(request.getFpforId());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCustId())){
            updateCreditAppFraudStatusCxpRequestData.setCustId(request.getCustId());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getLinkedCcaAppNum())){
            updateCreditAppFraudStatusCxpRequestData.setLinkedCcaAppNum(request.getLinkedCcaAppNum());
        }
        updateCreditAppFraudStatusCxpRequest.setUpdateCreditAppFraudStatus(updateCreditAppFraudStatusCxpRequestData);
        logger.info("updateCreditAppFraudStatusHelper: updateCreditAPpFraudStatus with updateCreditAppFraudStatusCxpRequest {}",updateCreditAppFraudStatusCxpRequest);
        return cartServiceCXPServices.updateCreditAppFraudStatus(updateCreditAppFraudStatusCxpRequest).flatMap(resp->{
            logger.info("updateCreditAppFraudStatusHelper: updateCreditAPpFraudStatus with cxp response  {}",resp);
            if(resp!=null && resp.getData()!=null){
                updateCreditAppFraudStatusData.setStatus(1);
                updateCreditAppFraudStatusResponse.setStatus(resp.getData().getEnforceStatus());
                updateCreditAppFraudStatusResponse.setCcaAppNum(request.getCcaAppNum());
                updateCreditAppFraudStatusResponse.setFpforId(request.getFpforId());
            }
            updateCreditAppFraudStatusData.setUpdateCreditAppFraudStatusResponse(updateCreditAppFraudStatusResponse);
            updateCreditAppFraudStatusMainResponse.setData(updateCreditAppFraudStatusData);
            return Mono.just(updateCreditAppFraudStatusMainResponse);
        }).onErrorResume(Mono::error);
    }
}
