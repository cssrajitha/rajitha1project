package onevz.soe.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.bpm.helper.CartWithDateServiceBpmHelper;
import onevz.soe.cart.responses.CartWithDatePegaResponse;
import onevz.soe.cart.ui.requests.CartWithDateUIRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.io.IOException;

@Service
public class UpdateCartWithDatesHelper {

    private static final Logger logger = LoggerFactory.getLogger(UpdateCartWithDatesHelper.class);

    @Autowired
    CartWithDateServiceBpmHelper cartWithDateServiceBpmHelper;

    @Autowired
    private ObjectMapper mapper;

    public Mono<CartWithDatePegaResponse> saveCartWithDate(CartWithDateUIRequest cartWithDateRequest) throws IOException {

        logger.debug("Calling saveCartWithDate() for CartWithDateServiceBpmHelper");

       return cartWithDateServiceBpmHelper.saveCartWithDate(cartWithDateRequest).flatMap(data->{
            if(data.getErrors()!=null) {
                logger.error("Error occurred during saving CartWithDate.");
            }
           try {
               logger.debug("SaveCartWithDate PEGA Response: {}", mapper.writeValueAsString(data));
           } catch (JsonProcessingException e) {
               logger.error("Error occurred during Parsing Error{}",e);
           }
           return Mono.just(data);
        });
    }
}
