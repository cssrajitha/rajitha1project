package onevz.soe.cart.omnidl;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.gql.CurrentProfileSPO;
import onevz.soe.cart.gql.schema.CustomerProfile;
import onevz.soe.cart.gql.schema.MobileInfoCustomerProfile;
import onevz.soe.cart.gql.schema.ProductOffers;
import onevz.soe.cart.model.addDevice.AddDeviceContext;
import onevz.soe.cart.model.addPlan.AddPlanContext;
import onevz.soe.cart.model.bundleBuilderCart.*;
import onevz.soe.cart.model.common.CartServiceCartInfo;
import onevz.soe.cart.model.common.CartServiceCustomerInfo;
import onevz.soe.cart.model.common.Line;
import onevz.soe.cart.model.retrieveCart.*;
import onevz.soe.cart.model.retrieveCart.TradeInDetail;
import onevz.soe.cart.model.retrieveCart.TradeInItem;
import onevz.soe.cart.model.validateCart.CXPValidateCartDataVO;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.ui.requests.AddDeviceUIRequest;
import onevz.soe.cart.ui.responses.AddDeviceUIResponse;
import onevz.soe.cart.ui.responses.AddPlanUIResponse;
import onevz.soe.omnidl.client.Cart;
import onevz.soe.omnidl.client.Items;
import onevz.soe.omnidl.client.*;
import onevz.soe.omnidl.data.OmniDLData;
import onevz.soe.omnidl.data.OmniDLDataBuilder;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import jakarta.validation.constraints.NotNull;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static onevz.soe.cart.constants.CartConstants.*;

public class OmniDLBuilder extends OmniDLDataBuilder {

	private List<String> fwaSPOCategoryCodes =List.of("FWADISCNT".split(","));


	private static final Logger logger = LoggerFactory.getLogger(OmniDLBuilder.class);


	public void buildMyData(Cart cart) {
		OmniDLData myData = new OmniDLData();
		Map<String, String> commonData = new HashMap<>();
		commonData.put("myKey", "myValue");
		myData.setAltData(commonData);
		Map<String, Object> customData = new HashMap<>();
		customData.put("cart", cart);
		myData.setCustomData(customData);
		super.dlData = myData;
	}

	public void buildQuickShopData(AddDeviceUIResponse addDeviceUIResponse) {
		OmniDLData qsData = new OmniDLData();
		Map<String, String> vzTxnData = new HashMap<>();
		Map<String, Object> customData = new HashMap<>();
		if(addDeviceUIResponse != null && addDeviceUIResponse.getServiceBody() != null
				&& addDeviceUIResponse.getServiceBody().getServiceResponse() != null) {
			AddDeviceContext contextData = addDeviceUIResponse.getServiceBody().getServiceResponse().getContext();
			if (contextData != null && contextData.getCartInfo() != null) {
				vzTxnData.put(NUMBER_OF_LINES, String.valueOf(contextData.getCartInfo().getCartItemCount()));
			}
			customData.put(OMNI_DL_TXN, vzTxnData);
			qsData.setCustomData(customData);
			super.dlData = qsData;
		}
	}


	public void buildCartObject(RetrieveCartCXPResponse retrieveCartResponse,
								ValidateCartCXPResponse validateCartResponse, String methodType, String flow,
								BundleBuilderCXPResponseData bundleBuilderCXPResponse, CartRedisData data) {

		OmniDLData cartData = new OmniDLData();
		Cart cart = new Cart();
		Product product = new Product();
		Map<String, Object> customData = new HashMap<>();
		Map<String, String> vzPageData = new HashMap<>();
		Map<String, String> vzTxnData = new HashMap<>();
		Map<String, String> vzEventData = new HashMap<>();
		Map<String, String> vzUserData = new HashMap<>();
		CXPLineDetailsVO lineDetails = new CXPLineDetailsVO();
		boolean isFiveg = false;
		int lineCount1 = 0;

		Map<String, String> authValues = new HashMap<>();
		Map<String, String> target = new HashMap<>();
		Map<String,String> vzPageValues=new HashMap<>();




		if(flow.equalsIgnoreCase("fiveG")) {
			//VCGBK-1339 Changes
			Optional.ofNullable(retrieveCartResponse).map(RetrieveCartCXPResponse::getData).map(CXPRetrieveCartDataVO::getCart).
					map(CXPCartVO::getCustomerProfile).filter(customerProfile -> customerProfile.getBillAccounts() != null).
					ifPresent(customerProfile ->
							populateProductOwnsData(customerProfile, product));
			Optional.ofNullable(validateCartResponse).map(ValidateCartCXPResponse::getData).
					map(CXPValidateCartDataVO::getValidateCartAndUpdate).
					map(CXPCartVO::getCustomerProfile).filter(customerProfile -> customerProfile.getBillAccounts() != null).
					ifPresent(customerProfile ->
						populateProductOwnsData(customerProfile, product)
					);
			isFiveg = true;
		}
		//iterate cartItems

		if (CartConstants.RETRIEVE.equalsIgnoreCase(methodType) && null != retrieveCartResponse.getData()) {
			if (null != retrieveCartResponse.getData().getCart()
					&& null != retrieveCartResponse.getData().getCart().getLineDetails())
				lineDetails = retrieveCartResponse.getData().getCart().getLineDetails();
			buildRetrieveCartPageValues(vzPageData, retrieveCartResponse);
			if (null != retrieveCartResponse.getData().getCart().getOrderDetails()
					&& null != retrieveCartResponse.getData().getCart().getOrderDetails().getTotalDueToday()) {
				vzTxnData.put(CartConstants.NON_RECURRING_CHARGES,
						Double.toString(retrieveCartResponse.getData().getCart().getOrderDetails().getTotalDueToday()));
			}
			if (null != retrieveCartResponse.getData().getCart().getOrderDetails()
					&& null != retrieveCartResponse.getData().getCart().getOrderDetails().getCartTotalDiscounts()
					&& null != retrieveCartResponse.getData().getCart().getOrderDetails().getCartTotalDiscounts()
							.getTotalDiscount()) {
				vzTxnData.put("discount", retrieveCartResponse.getData().getCart().getOrderDetails()
						.getCartTotalDiscounts().getTotalDiscount());
			}
			if(isFiveg) {
				buildTargetValuesForProspect(target, retrieveCartResponse.getData().getCart());
				if(retrieveCartResponse.getData().getCart().getOrderDetails() != null) {
					if(retrieveCartResponse.getData().getCart().getOrderDetails().getTotalShippingCost() != null)
						vzTxnData.put("shipping", retrieveCartResponse.getData().getCart().getOrderDetails().getTotalShippingCost().toString());
					if(retrieveCartResponse.getData().getCart().getOrderDetails().getTotalDueToday() != null)
						vzTxnData.put(CartConstants.TOTAL, retrieveCartResponse.getData().getCart().getOrderDetails().getTotalDueToday().toString());
					if(retrieveCartResponse.getData().getCart().getOrderDetails().getTotalDueMonthly() != null)
						vzTxnData.put("recurring", retrieveCartResponse.getData().getCart().getOrderDetails().getTotalDueMonthly().toString());
					if(null != retrieveCartResponse.getData().getCart().getOrderDetails().getOrderList() && retrieveCartResponse.getData().getCart().getOrderDetails().getOrderList().size() >= 1 && retrieveCartResponse.getData().getCart().getOrderDetails().getOrderList().get(0).getOrderNumber() != null) {
						vzTxnData.put("id", fetchDigitalOrderId(retrieveCartResponse.getData().getCart().getOrderDetails().getOrderList().get(0)));
						if(null != retrieveCartResponse.getData().getCart().getOrderDetails().getOrderList().get(0).getCreditApplication()) {
							String creditAppNumber = String.valueOf(retrieveCartResponse.getData().getCart().getOrderDetails().getOrderList().get(0).getCreditApplication().getCreditApplicationNum());
							String status =  retrieveCartResponse.getData().getCart().getOrderDetails().getOrderList().get(0).getCreditApplication().getCreditApprovalStatus();
							String reason = retrieveCartResponse.getData().getCart().getOrderDetails().getOrderList().get(0).getCreditApplication().getCreditStatusReason();
							vzUserData.put("creditAppNum", creditAppNumber);
							vzUserData.put("creditStatusReason", status +"| "+reason);
						}
					}
				}
			}

		} else if (CartConstants.VALIDATE.equalsIgnoreCase(methodType) && null != validateCartResponse.getData()
				&& null != validateCartResponse.getData().getValidateCartAndUpdate()
				&& null != validateCartResponse.getData().getValidateCartAndUpdate().getLineDetails()) {
			CXPOrderDetails validateOrderDetails = validateCartResponse.getData().getValidateCartAndUpdate().getOrderDetails();
			lineDetails = validateCartResponse.getData().getValidateCartAndUpdate().getLineDetails();
			if (validateOrderDetails != null && validateOrderDetails.getTotalDownPaymentAmt() != null)
				vzTxnData.put("totalDownPayment", String.valueOf(validateOrderDetails.getTotalDownPaymentAmt()));
			if(isFiveg) {
				if(validateOrderDetails != null && validateOrderDetails.getTotalShippingCost() != null)
					vzTxnData.put("shipping", validateOrderDetails.getTotalShippingCost().toString());

				if(validateOrderDetails != null && validateOrderDetails.getTotalDueToday() != null)
					vzTxnData.put(CartConstants.TOTAL, validateOrderDetails.getTotalDueToday().toString());

				if(validateOrderDetails != null && validateOrderDetails.getTotalDueMonthly() != null)
					vzTxnData.put("recurring", validateOrderDetails.getTotalDueMonthly().toString());

				if(validateOrderDetails != null && null != validateOrderDetails.getOrderList() && validateOrderDetails.getOrderList().size() >= 1 && validateOrderDetails.getOrderList().get(0).getOrderNumber() != null)
					vzTxnData.put("id", fetchDigitalOrderId(validateOrderDetails.getOrderList().get(0)));

				if (null != validateCartResponse.getData().getValidateCartAndUpdate()
						&& null != validateCartResponse.getData().getValidateCartAndUpdate().getLineDetails())
					lineDetails = validateCartResponse.getData().getValidateCartAndUpdate().getLineDetails();
				if (null != validateOrderDetails
						&& null != validateOrderDetails.getTotalDueToday()) {
					vzTxnData.put(CartConstants.NON_RECURRING_CHARGES,
							Double.toString(validateOrderDetails.getTotalDueToday()));
				}
				if (null != validateOrderDetails
						&& null != validateOrderDetails.getCartTotalDiscounts()
						&& null != validateOrderDetails.getCartTotalDiscounts()
						.getTotalDiscount()) {
					vzTxnData.put("discount", validateOrderDetails
							.getCartTotalDiscounts().getTotalDiscount());
				}
			}
			buildTargetValues(target,validateCartResponse, isFiveg);
			vzTxnData.put(CartConstants.EVAR37, String.valueOf(buildBMSMDiscountId(lineDetails)));
			if (!isFiveg)
			{
				buildValidateCartPageValues(vzPageData, vzPageValues, validateCartResponse);
				buildValidateCartTxnValues(vzTxnData,validateCartResponse );
				if (!vzTxnData.isEmpty()) {
					customData.put(CartConstants.OMNI_DL_TXN, vzTxnData);
					cartData.setCustomData(customData);
					super.dlData = cartData;
				}
		}
		}
		else if("PromoBundleBuilder".equalsIgnoreCase(methodType) && bundleBuilderCXPResponse != null &&
				bundleBuilderCXPResponse.getData()!= null && bundleBuilderCXPResponse.getData().getPromoBundleBuilderCart() != null &&
				bundleBuilderCXPResponse.getData().getPromoBundleBuilderCart().getLineDetails() != null){
			lineDetails = null;
			Engagement engagement = new Engagement();
			List<Items> cartItemsArr = new ArrayList<Items>();
			buildPageValues(vzPageData,vzPageValues, bundleBuilderCXPResponse);
			buildAuthValues(authValues, bundleBuilderCXPResponse);
			buildCartItemsArrForTxn(product, bundleBuilderCXPResponse);
			buildTxnValues(vzTxnData, bundleBuilderCXPResponse);
//			as per PRODDEF-23628, user.numberOfLines is mtn count of user, not cart item
//			buildUserValues(vzUserData,bundleBuilderCXPResponse);
			buildCartValues(cart);
			buildCartItemsArr(cartItemsArr, bundleBuilderCXPResponse);
			buildEngagement(engagement);
			buildTargetValues(target,bundleBuilderCXPResponse);

			if (!vzPageData.isEmpty()) {
				customData.put(CartConstants.OMNI_DL_PAGE, vzPageData);
			}
			if(!vzPageValues.isEmpty()) {
				customData.put(CartConstants.PAGE_PARAMS, vzPageValues);
			}
			if (!authValues.isEmpty()) {
				customData.put(CartConstants.OMNI_DL_AUTH, authValues);
			}
			vzTxnData.values().removeIf(StringUtils::isBlank);

			if (!vzTxnData.isEmpty()) {
				customData.put(CartConstants.OMNI_DL_TXN, vzTxnData);
			}
			if (!vzUserData.isEmpty()) {
				customData.put(CartConstants.OMNI_DL_USER, vzUserData);
			}
			customData.put("cart", cart);
			customData.put(CartConstants.TXN_PRODUCT, product);
			customData.put(CartConstants.TARGET_ENGAGEMENT, engagement);
			customData.put("target.tt", "none");
			customData.put("cart.items", cartItemsArr);
			if (!target.isEmpty()) {
				customData.put(CartConstants.OMNI_DL_TARGET, target);
			}
			cartData.setCustomData(customData);
			super.dlData = cartData;
		}

		cart.setOnlineStore(CartConstants.VZW_DESKTOP_STORE);
		if (null != lineDetails && null != lineDetails.getCartId()) {
			vzTxnData.put(CartConstants.CART_ID, lineDetails.getCartId());
			if(isFiveg) {
				if (lineDetails.getTotalDownPaymentAmt() != null)
					vzTxnData.put("downPay", lineDetails.getTotalDownPaymentAmt().toString());
				if (StringUtilities.isNotEmptyOrNull(lineDetails.getIsAutoPayEnrolled()))
					vzTxnData.put("autoPay", lineDetails.getIsAutoPayEnrolled());
			}
		}

		if(!isFiveg) {
			if (null != lineDetails && null != lineDetails.getLineInfo() && lineDetails.getLineInfo().length > 0) {
				Arrays.stream(lineDetails.getLineInfo()).filter(Objects::nonNull).forEach(lineInfo -> {
					if (null != lineInfo.getBundleAccessoryInfo())
						vzPageData.put("accBundleFlag", "true");
					else
						vzPageData.put("accBundleFlag", CartConstants.FALSE);
				});

			}
		}

		List<String> promosApplied = new ArrayList<>();
		String sedDiscounts = StringUtils.EMPTY;
		if (null != lineDetails && !"PromoBundleBuilder".equalsIgnoreCase(methodType)) {
			if (lineDetails.getTradeInDetail() != null && lineDetails.getTradeInDetail().getTradeInItems() != null) {
				promosApplied = lineDetails.getTradeInDetail().getTradeInItems().stream()
						.filter(tradeDevice -> tradeDevice.getRecycleDeviceOffer() != null
								&& StringUtilities.isNotEmptyOrNull(tradeDevice.getRecycleDeviceOffer().getOfferId()))
						.map(tradeDevice -> tradeDevice.getRecycleDeviceOffer().getOfferId())
						.collect(Collectors.toList());
				if (CollectionUtilities.isNotEmptyOrNull(promosApplied)) {
					customData.put("cart.promosApplied", promosApplied);
				}

			}

			if (null != lineDetails.getLineInfo()) {
				CXPLineInfo[] lineInfoItem = lineDetails.getLineInfo();
				List<Items> cartItemsArr = new ArrayList<Items>();
				List<Current> currentItemsArr = new ArrayList<Current>();
				boolean perksAvailable = false;
				for (CXPLineInfo lineInfoMem : lineInfoItem) {
					if (null != lineInfoMem.getServiceInfo()
							&& CollectionUtilities.isNotEmptyOrNull(lineInfoMem.getServiceInfo().getSbdOffer())) {
						for (SbdOffer sbdOffer : lineInfoMem.getServiceInfo().getSbdOffer()) {
							if (StringUtilities.isNotEmptyOrNull(sbdOffer.getOfferId())
									&& CollectionUtilities.isNotEmptyOrNull(sbdOffer.getPromoBadges())) {
								promosApplied.add(sbdOffer.getOfferId());
							}
						}
					}
					if(null != lineInfoMem.getServiceInfo()) {
						String bayouCombo = setBayouCombo(lineInfoMem.getServiceInfo());
						vzTxnData.put("bayouCombo", bayouCombo);
						if (null != lineInfoMem.getServiceInfo().getPlanPerks() && !lineInfoMem.getServiceInfo().getPlanPerks().isEmpty())
							perksAvailable = true;
					}
					List<VisFeature> visFeatureArr=null;
					CXPItemInfo cxpItemsInfo = null;
					CXPCartItem[] cartItemArray;
					if (lineInfoMem.getItemsInfo() != null)
						cxpItemsInfo = lineInfoMem.getItemsInfo()[0];
					if (null != cxpItemsInfo) {
						if (cxpItemsInfo.getCartItems() != null && cxpItemsInfo.getCartItems().getCartItem() != null) {
							cartItemArray = cxpItemsInfo.getCartItems().getCartItem();
							int lineCount = 1;
							if(isFiveg) {
								if(cxpItemsInfo.getShipping() != null && cxpItemsInfo.getShipping().getShippingCode() != null)
									vzTxnData.put("shippingZip", cxpItemsInfo.getShipping().getShippingCode());
							}
							for (CXPCartItem item : cartItemArray) {
								Items cartItem = new Items();
								Current currentItem = new Current();
								if (CartConstants.DEVICE_TYPE.equalsIgnoreCase(item.getCartItemType())
										|| CartConstants.HELPER_ACCESSORY.equalsIgnoreCase(item.getCartItemType()) || CartConstants.SOFT_SKU.equalsIgnoreCase(item.getCartItemType())) {

									if (CartConstants.DEVICE_TYPE.equalsIgnoreCase(item.getCartItemType()) || CartConstants.SOFT_SKU.equalsIgnoreCase(item.getCartItemType()))
										cartItem.setCategory("5gInternet");
									else
										cartItem.setCategory(CartConstants.HELPER_ACCESSORY);
									cartItem.setPrice(item.getItemPrice());
									cartItem.setName(item.getDescription());
									cartItem.setQuantity("1");
									cartItem.setProductId(item.getSorId());
									cartItem.setBvProductId(item.getProductId());
									cartItemsArr.add(cartItem);
									if(isFiveg) {
										if(item.getTaxAmount() != null)
											vzTxnData.put("tax", item.getTaxAmount().toString());
											logger.info("TXN : DepletionType from cxp = ",item.getDepletionType());
											if ("O".equalsIgnoreCase(item.getDepletionType())) {
												vzTxnData.put("installOptions", "Professional SetUp");
											} else if ("F".equalsIgnoreCase(item.getDepletionType()) || "L".equalsIgnoreCase(item.getDepletionType())) {
												vzTxnData.put("installOptions", "Self SetUp");
											}
                                        if ("Home Solutions".equalsIgnoreCase(item.getCartItemType())) {
                                            if(StringUtilities.isNotEmptyOrNull(item.getManufacturer()))
                                                currentItem.setMerchCat(item.getManufacturer());
                                        }
                                        if ("YouTube TV".equalsIgnoreCase(item.getCartItemType())) {
                                            currentItem.setMerchCat("YouTubeTV Basic Subscription PPH");
                                        }
										/**
										 * Adding Shipping Type
										 */
										currentItem.setShippingType(cxpItemsInfo.getShipping() != null
												? StringUtilities.isNotEmptyOrNull(cxpItemsInfo.getShipping().getShippingDescription())
												? cxpItemsInfo.getShipping().getShippingDescription():
												StringUtils.EMPTY :
												StringUtils.EMPTY);
										if(lineDetails.getPayments() != null && !lineDetails.getPayments().isEmpty()) {
											Optional<CXPPaymentsVO> lineDetailsFirst = lineDetails.getPayments().stream().findFirst();
											if(lineDetailsFirst.isPresent()) {
												vzTxnData.put("paymentType", lineDetailsFirst.get().getPaymentType());
											}
										}

									}
									if (CartConstants.DEVICE_TYPE.equalsIgnoreCase(item.getCartItemType()) || CartConstants.SOFT_SKU.equalsIgnoreCase(item.getCartItemType())) {
										currentItem.setCategory(CartConstants.DEVICE_TYPE);
										currentItem.setLine(String.valueOf(lineCount));
										currentItem.setProductId(item.getProductId());
										if(isFiveg) {
											currentItem.setCategory("5gInternet");
											if(StringUtilities.isNotEmptyOrNull(item.getManufacturer()))
												currentItem.setMerchCat(item.getManufacturer());
										}
										lineCount1 = lineCount;
										if (null != item.getRebateOffers() && item.getRebateOffers().size() > 0) {
											for (RebateOffer rebateOffer : item.getRebateOffers()) {
												if (null != rebateOffer.getCode()) {
													currentItem.setRebate(rebateOffer.getCode());
												}
											}
										}
										if (null != item.getPromoHubOfferList()
												&& null != item.getPromoHubOfferList().getPromoHubOfferList()
												&& item.getPromoHubOfferList().getPromoHubOfferList().size() > 0) {
											String promoId = item.getPromoHubOfferList().getPromoHubOfferList().get(0)
													.getPromotionId();
											String promoType = item.getPromoHubOfferList().getPromoHubOfferList().get(0)
													.getPromoType();
											if (StringUtilities.isNotEmptyOrNull(promoId)
													&& StringUtilities.isNotEmptyOrNull(promoType)) {
												currentItem.setOffer(promoType.concat("-").concat(promoId));
											}

										} else {
											if(!isFiveg){
												currentItem.setOffer("none");
											}
										}
										if(isFiveg) {
											currentItem.setShared("N");
										} else {
											if ((null != lineInfoMem.getServiceInfo()
													&& null != lineInfoMem.getServiceInfo().getSelectedALPShareList()
													&& lineInfoMem.getServiceInfo().getSelectedALPShareList()
													.getAlpShareInfo().length > 0)
													|| (null != lineInfoMem.getServiceInfo()
													&& null != lineInfoMem.getServiceInfo()
													.getSelectedALPShareList()
													&& lineInfoMem.getServiceInfo().getSelectedALPShareList()
													.getNewAlpShareInfo().length > 0)) {
												currentItem.setShared("Y");
											} else if ((null != lineInfoMem.getServiceInfo()
													&& null != lineInfoMem.getServiceInfo().getSelectedALPShareList()
													&& lineInfoMem.getServiceInfo().getSelectedALPShareList()
													.getAlpShareInfo().length == 0)
													|| (null != lineInfoMem.getServiceInfo()
													&& null != lineInfoMem.getServiceInfo()
													.getSelectedALPShareList()
													&& lineInfoMem.getServiceInfo().getSelectedALPShareList()
													.getNewAlpShareInfo().length == 0)) {
												currentItem.setShared("N");
											}
										}
										if (null != promosApplied && !promosApplied.isEmpty()) {
											for (String discountId : promosApplied) {
												if (null != discountId)
													currentItem.setDiscount(discountId);
											}
										}
										if(isFiveg && promosApplied.isEmpty()) {
											currentItem.setDiscount("0.0");
										}
										setDownPaymentInfo(item,lineInfoMem,currentItem);
										lineCount++;
									} else {
										currentItem.setCategory(CartConstants.HELPER_ACCESSORY);
										if(isFiveg) {
											if(!perksAvailable)
                                            	currentItem.setMerchCat("STANDALONE_ACCESSORY");
											else if(perksAvailable) {
												currentItem.setMerchCat("accessories");
											}
											setPlanPathDetails(currentItem,data,lineInfoMem);
										}else {
                                            currentItem.setMerchCat("none");
                                        }
									}
									if(!isFiveg) {
										currentItem.setMerchCat("none");
									}
									currentItem.setSku(item.getSkuId());
									currentItem.setQty(null!=item.getQty()?item.getQty().toString():"1");
									if (null != item.getDeviceDueMonthly()) {
										if(!isFiveg) {
											currentItem.setContractType("DPP");
										}
										currentItem.setRecurringPrice(Double.toString(item.getDeviceDueMonthly()));
										nonRecurringPriceValue(item, currentItem);
									} else {
										if(!isFiveg) {
											currentItem.setContractType("Retail");
										}
										if(null != item.getCatalogPrice())
											nonRecurringPriceValue(item, currentItem);
										currentItem.setRecurringPrice("0.00");
									}
									currentItem.setId(item.getSorId());
									if(null != item.getDescription())
										currentItem.setName(item.getDescription());
									setHashCodeInLines(data,lineInfoMem,currentItem);
									currentItemsArr.add(currentItem);
									//collecting all SED promos in Accessory level
									if (null != item.getSedOfferList() && CollectionUtilities.isNotEmptyOrNull(item.getSedOfferList().getSedOffer())) {
										sedDiscounts = item.getSedOfferList().getSedOffer().stream().filter(Objects::nonNull).map(offer -> offer.getOfferType() + "_" + offer.getOfferId()+ "_" + offer.getDiscAmt()).collect(Collectors.joining("|"));
									}
								}
							}
						}
					}
					if (null != lineInfoMem.getServiceInfo()
							&& ("AAL".equalsIgnoreCase(lineInfoMem.getLineActivityType())
									|| "EUP".equalsIgnoreCase(lineInfoMem.getLineActivityType())
									|| "BYOD".equalsIgnoreCase(lineInfoMem.getLineActivityType())
									|| "AAL_5G".equalsIgnoreCase(lineInfoMem.getLineActivityType())
									|| "AAL_LTE".equalsIgnoreCase(lineInfoMem.getLineActivityType())
									|| CartConstants.ACC.equalsIgnoreCase(lineInfoMem.getLineActivityType())
									||CartConstants.FEA.equalsIgnoreCase(lineInfoMem.getLineActivityType())
									|| CartConstants.EUPBYOD.equalsIgnoreCase(lineInfoMem.getLineActivityType()))
							|| "NSE".equalsIgnoreCase(lineInfoMem.getLineActivityType())
							|| "NSEBYOD".equalsIgnoreCase(lineInfoMem.getLineActivityType())
							|| "NSE_5G".equalsIgnoreCase(lineInfoMem.getLineActivityType())
							|| "NSE_LTE".equalsIgnoreCase(lineInfoMem.getLineActivityType()) || CartConstants.CPC.equalsIgnoreCase(lineInfoMem.getLineActivityType())) {
						if (null != lineInfoMem.getServiceInfo().getSelectedFeaturesList()) {
							visFeatureArr = lineInfoMem.getServiceInfo().getSelectedFeaturesList().getVisFeature();
							if(isFiveg) {
								if(null != lineInfoMem.getServiceInfo().getCart5GAddress() && StringUtilities.isNotEmptyOrNull(lineInfoMem.getServiceInfo().getCart5GAddress().getZipCode()))
									vzTxnData.put("shippingZip", lineInfoMem.getServiceInfo().getCart5GAddress().getZipCode());

								if(null != lineInfoMem.getOneTimeCharges() && !lineInfoMem.getOneTimeCharges().isEmpty()) {
									for(OneTimeCharges otc : lineInfoMem.getOneTimeCharges()) {
										if(otc.getAmount() != null) {
											vzTxnData.put("oneTime", otc.getAmount().toString());
										}
									}
								}
								if("NSE_5G".equalsIgnoreCase(lineInfoMem.getLineActivityType())) {
									if( null != cxpItemsInfo && null != cxpItemsInfo.getShipping() && null != cxpItemsInfo.getShipping().getAddress() && StringUtilities.isNotEmptyOrNull(cxpItemsInfo.getShipping().getAddress().getState()))
										vzTxnData.put("shippingState", cxpItemsInfo.getShipping().getAddress().getState());
									else
									    if(StringUtilities.isNotEmptyOrNull(lineInfoMem.getServiceInfo().getCart5GAddress().getState()))
										vzTxnData.put("shippingState", lineInfoMem.getServiceInfo().getCart5GAddress().getState());
								}
							}
							for (VisFeature visFeature : visFeatureArr) {
								Current currentItem = new Current();
								if ((null != visFeature.getProtection() && (visFeature.getProtection()) || visFeature.isHomeProtect())
										&& (null != visFeature.getAddDeleteInd()
												&& ("A".equalsIgnoreCase(visFeature.getAddDeleteInd())
														|| "Z".equalsIgnoreCase(visFeature.getAddDeleteInd())))) {
									setFeatureCategory(visFeature, currentItem,isFiveg,lineInfoMem.getLineActivityType(), CartConstants.FEATURES,perksAvailable);
									setHashCodeInLines(data, lineInfoMem,currentItem);
									currentItemsArr.add(currentItem);
								}else if ("A".equalsIgnoreCase(visFeature.getAddDeleteInd()) && CartConstants.USER.equalsIgnoreCase(visFeature.getSource())
										&& CollectionUtilities.isNotEmptyOrNull(visFeature.getCategoryCodes()) && visFeature.getCategoryCodes().contains(CartConstants.BYOPERK)) {
									setFeatureCategory(visFeature, currentItem,isFiveg,lineInfoMem.getLineActivityType(), CartConstants.FEATURES,perksAvailable);
									setPlanPathDetails(currentItem,data,lineInfoMem);
									currentItemsArr.add(currentItem);
								} else if (lineInfoMem != null && StringUtilities.isNotEmptyOrNull(lineInfoMem.getLineActivityType()) && lineInfoMem.getLineActivityType().equalsIgnoreCase(CartConstants.FEA) && visFeature.getAddDeleteInd() != null &&
										"A".equalsIgnoreCase(visFeature.getAddDeleteInd())&& CollectionUtilities.isNotEmptyOrNull(visFeature.getCategoryCodes())
										&& (visFeature.getCategoryCodes().contains(CartConstants.WHWPLUS_CATEGORYCODE)
										|| visFeature.getCategoryCodes().contains(CartConstants.WHWHOME_CATEGORYCODE))){
									setFeatureCategory(visFeature, currentItem,isFiveg, lineInfoMem.getLineActivityType(), CartConstants.FEATURES,perksAvailable);
									setPlanPathDetails(currentItem,data,lineInfoMem);
									currentItemsArr.add(currentItem);
								} else if (lineInfoMem != null && StringUtilities.isNotEmptyOrNull(lineInfoMem.getLineActivityType())
										&& ("NSE".equalsIgnoreCase(lineInfoMem.getLineActivityType())
										|| "NSE_5G".equalsIgnoreCase(lineInfoMem.getLineActivityType())
										|| "NSE_LTE".equalsIgnoreCase(lineInfoMem.getLineActivityType()) || "AAL".equalsIgnoreCase(lineInfoMem.getLineActivityType())
										|| "AAL_5G".equalsIgnoreCase(lineInfoMem.getLineActivityType())
										|| "AAL_LTE".equalsIgnoreCase(lineInfoMem.getLineActivityType()))&& visFeature.getAddDeleteInd() != null &&
										"A".equalsIgnoreCase(visFeature.getAddDeleteInd())
										&& CollectionUtilities.isNotEmptyOrNull(visFeature.getCategoryCodes())
										&& (visFeature.getCategoryCodes().contains(CartConstants.WHWPLUS_CATEGORYCODE)
										|| visFeature.getCategoryCodes().contains(CartConstants.WHWHOME_CATEGORYCODE))){
									setFeatureCategory(visFeature, currentItem,isFiveg, lineInfoMem.getLineActivityType(), CartConstants.FEATURES,perksAvailable);
									setPlanPathDetails(currentItem,data,lineInfoMem);
									currentItemsArr.add(currentItem);
								}else if(isFiveg && "A".equalsIgnoreCase(visFeature.getAddDeleteInd())
										&& ("A".equalsIgnoreCase(visFeature.getLevel()) || "L".equalsIgnoreCase(visFeature.getLevel()))
										&& "SPO".equalsIgnoreCase(visFeature.getType())) {
									//PopulateDiscount in Item Discount WHATSNEXT-2735
									if( !CollectionUtils.isEmpty(visFeature.getCategoryCodes()) && !Collections.disjoint(fwaSPOCategoryCodes, visFeature.getCategoryCodes())) {
										setFeatureCategory(visFeature, currentItem,isFiveg, lineInfoMem.getLineActivityType(), CartConstants.HELPER_DISCOUNT,perksAvailable);
										currentItemsArr.add(currentItem);
									}
								}
							}
						}
						//Only for redeem the Accessory
						List<CurrentProfileSPO> currentProfileSPOList = new ArrayList<>();
						List<MobileInfoCustomerProfile> lstMtn = new ArrayList<>();
						if(lineInfoMem != null && lineInfoMem.getLineActivityType() != null && lineInfoMem.getLineActivityType().equalsIgnoreCase(CartConstants.ACC) ) {
							String mtn = "";
							if (lineInfoMem != null && lineInfoMem.getServiceInfo() != null && lineInfoMem.getServiceInfo().getMtn() != null && null != lineInfoMem.getServiceInfo().getMtn()) {
								mtn = lineInfoMem.getServiceInfo().getMtn();
							}
							if (StringUtilities.isNotEmptyOrNull(methodType) && CartConstants.RETRIEVE.equalsIgnoreCase(methodType) && retrieveCartResponse != null && retrieveCartResponse.getData() != null && retrieveCartResponse.getData().getCart() != null && retrieveCartResponse.getData().getCart().getCustomerProfile() != null && retrieveCartResponse.getData().getCart().getCustomerProfile().getBillAccounts() != null && retrieveCartResponse.getData().getCart().getCustomerProfile().getBillAccounts().size() > 0 && retrieveCartResponse.getData().getCart().getCustomerProfile().getBillAccounts().get(0).getMtns() != null) {
								lstMtn = retrieveCartResponse.getData().getCart().getCustomerProfile().getBillAccounts().get(0).getMtns();
							}
							if (StringUtilities.isNotEmptyOrNull(methodType) && VALIDATE.equalsIgnoreCase(methodType) && validateCartResponse != null && validateCartResponse.getData() != null && validateCartResponse.getData().getValidateCartAndUpdate() != null && validateCartResponse.getData().getValidateCartAndUpdate().getCustomerProfile() != null && validateCartResponse.getData().getValidateCartAndUpdate().getCustomerProfile().getBillAccounts() != null && validateCartResponse.getData().getValidateCartAndUpdate().getCustomerProfile().getBillAccounts().size() > 0 && validateCartResponse.getData().getValidateCartAndUpdate().getCustomerProfile().getBillAccounts().get(0).getMtns() != null) {
								lstMtn = validateCartResponse.getData().getValidateCartAndUpdate().getCustomerProfile().getBillAccounts().get(0).getMtns();
							}
							for (MobileInfoCustomerProfile cxpMtn : lstMtn) {
								if (null != cxpMtn && null != cxpMtn.getMtn()
										&& StringUtilities.isNotEmptyOrNull(mtn)
										&& cxpMtn.getMtn().equalsIgnoreCase(mtn)) {
									currentProfileSPOList = cxpMtn.getCurrentSpo();
									for (CurrentProfileSPO currentProfileSpo : currentProfileSPOList) {
										if (currentProfileSpo != null && currentProfileSpo.getSpoId() != null && currentProfileSpo.getSpoId().equalsIgnoreCase(CartConstants.WHWSPO) || currentProfileSpo.getSpoId().equalsIgnoreCase(WHWPLUSSPO)) {
											Current currentItem = new Current();
											setAccessoryCategory(currentProfileSpo, currentItem);
											setPlanPathDetails(currentItem, data, lineInfoMem);
											currentItemsArr.add(currentItem);
										}
									}
								}
							}
						}
						if (null != lineInfoMem.getServiceInfo().getSelectedALPShareList()) {
							if (null != lineInfoMem.getServiceInfo().getSelectedALPShareList().getNewAlpShareInfo()) {
								if (lineInfoMem.getServiceInfo().getSelectedALPShareList()
										.getNewAlpShareInfo().length > 0) {
									AlpShareInfo alpShareInfo = lineInfoMem.getServiceInfo().getSelectedALPShareList()
											.getNewAlpShareInfo()[0];
									Items cartItem = new Items();
									Current currentItem = new Current();
									cartItem.setCategory("Plan");
									cartItem.setPrice(alpShareInfo.getAccessFee());
									cartItem.setName(alpShareInfo.getServicePlanDesc());
									cartItem.setQuantity("1");
									cartItem.setProductId(alpShareInfo.getServicePlanId());
									cartItem.setBvProductId(alpShareInfo.getServicePlanId());// to be mapped to catalog
																								// id
									currentItem.setCategory("Plan");
									currentItem.setId(alpShareInfo.getServicePlanId());
									currentItem.setName(alpShareInfo.getServicePlanDesc());
									currentItem.setQty("1");
									currentItem.setRecurringPrice(alpShareInfo.getAccessFee());
									setPlanPathDetails(currentItem,data,lineInfoMem);
									cartItemsArr.add(cartItem);
									currentItemsArr.add(currentItem);
								}
							}
						}
						if (null != lineInfoMem.getServiceInfo().getNewPricePlanInfo()) {
							PricePlanInfo pricePlanInfo = lineInfoMem.getServiceInfo().getNewPricePlanInfo();
							Items cartItem = new Items();
							Current currentItem = new Current();
							cartItem.setCategory("Plan");
							if (null != pricePlanInfo.getPlanPrice())
								cartItem.setPrice(Double.toString(pricePlanInfo.getPlanPrice()));
							cartItem.setName(pricePlanInfo.getPricePlanDesc());
							cartItem.setQuantity("1");
							cartItem.setProductId(pricePlanInfo.getPricePlanCode());
							cartItem.setBvProductId(pricePlanInfo.getPricePlanCode());// to be mapped to catalog id
							currentItem.setCategory("Plan");
							currentItem.setId(pricePlanInfo.getPricePlanCode());
							currentItem.setName(pricePlanInfo.getPricePlanDesc());
							currentItem.setQty("1");
							currentItem.setRecurringPrice(Double.toString(pricePlanInfo.getPlanPrice()));
							setPlanPathDetails(currentItem,data,lineInfoMem);
							if(isFiveg){
								currentItem.setSku(pricePlanInfo.getPricePlanCode());
								currentItem.setDiscount("0.0");
								currentItem.setShared("N");
								currentItem.setLine(String.valueOf(lineCount1));
								if(perksAvailable) {
									currentItem.setMerchCat("plan");
								} else
								currentItem.setMerchCat("Line Level");
							}
							cartItemsArr.add(cartItem);
							currentItemsArr.add(currentItem);
						}
					}
				}
				Items[] ItemsList = new Items[cartItemsArr.size()];
				cartItemsArr.toArray(ItemsList);

				Current[] currentList = new Current[currentItemsArr.size()];
				currentItemsArr.toArray(currentList);
				product.setCurrent(currentList);
				Engagement engagement = new Engagement();
				if(isFiveg) {
					engagement.setIntent(CartConstants.ORDER);
					RetrieveCartHeader cartHeader = null;
					StringBuilder promos = new StringBuilder();
					if(CartConstants.VALIDATE.equalsIgnoreCase(methodType)){
						populateAllFWADiscounts(validateCartResponse.getData().getValidateCartAndUpdate(), promos);
						cartHeader = validateCartResponse.getData().getValidateCartAndUpdate().getCartHeader();
					} else if (CartConstants.RETRIEVE.equalsIgnoreCase(methodType)) {
						cartHeader = retrieveCartResponse.getData().getCart().getCartHeader();
						populateAllFWADiscounts(retrieveCartResponse.getData().getCart(), promos);
					}
					if(StringUtilities.isEmptyOrNull(vzTxnData.get(CartConstants.EVAR37))){
						vzTxnData.remove(CartConstants.EVAR37);
					}
					if(StringUtils.isNotBlank(promos) && promos.length() > 1)
						vzTxnData.put(CartConstants.EVAR37,promos.toString());
					if(cartHeader != null && cartHeader.getVisionCustomerType() != null)
						vzUserData.put(CartConstants.CUSTOMER_TYPE, cartHeader.getVisionCustomerType());

				} else {
					engagement.setIntent(CartConstants.ORDER);
					vzEventData.put(CartConstants.VALUE, "scView");
				}

				if (cart != null)
					customData.put("cart", cart);
				if (cartItemsArr != null && cartItemsArr.size() > 0)
					customData.put("cart.items", cartItemsArr);
				if (product != null && isFiveg)
					customData.put("txn.5g.product", product);
				else
					customData.put("txn.product", product);
				if (vzPageData != null && !vzPageData.isEmpty() && vzPageData.size() > 0)
					customData.put(CartConstants.VZPAGE, vzPageData);
				if (!target.isEmpty() && !target.containsValue("|")) {
					customData.put(CartConstants.OMNI_DL_TARGET, target);
				}
				cartData = setData(vzUserData, vzEventData, vzTxnData, engagement, isFiveg, customData);
				super.dlData = cartData;
				Map<String, String> altDataMap = new HashMap<>();
				String promosAppliedVal = String.join(", ", promosApplied);
				if (null != altDataMap.get(CartConstants.PROMOS_APPLIED))
					altDataMap.put(CartConstants.PROMOS_APPLIED, altDataMap.get(CartConstants.PROMOS_APPLIED) + ", " + promosAppliedVal);
				else
					altDataMap.put(CartConstants.PROMOS_APPLIED, promosAppliedVal);

				altDataMap.put(CartConstants.TEST_VERSION, "none");
				cartData.setAltData(altDataMap);
				super.dlData = cartData;
			}
		}
		if (!isFiveg && "Validate".equalsIgnoreCase(methodType) && null != validateCartResponse.getData()
				&& null != validateCartResponse.getData().getValidateCartAndUpdate()
				&& null == validateCartResponse.getData().getValidateCartAndUpdate().getLineDetails())
		{
			Product updateProduct = new Product();
			customData.put("txn.product", updateProduct);
			customData.put("txn.numberOfLines","0");
			cartData.setCustomData(customData);
			super.dlData = cartData;
		}
	}

	private String setBayouCombo(ServiceInfo serviceInfo) {
		if (null != serviceInfo.getNewPricePlanId()) {
			String combo = serviceInfo.getNewPricePlanId();
			if (null != serviceInfo.getPlanPerks()) {
				for (PlanPerks perk : serviceInfo.getPlanPerks()) {
					if(null != perk.getVisFeatureCode())
						combo = combo + "|" + perk.getVisFeatureCode();
				}
				return combo;
			} else
				return serviceInfo.getNewPricePlanId();
		}
		return null;
	}

	private void nonRecurringPriceValue(CXPCartItem item, Current currentItem) {
		if (null != item.getDiscountedPrice()) {
			Optional.ofNullable(item.getDiscountedPrice())
					.filter(Objects::nonNull)
					.ifPresent(discountedPrice -> currentItem.setNonRecurringPrice(String.valueOf(discountedPrice)));
		} else {
			Optional.ofNullable(item.getCatalogPrice())
					.filter(Objects::nonNull)
					.ifPresent(catalogPrice -> currentItem.setNonRecurringPrice(String.valueOf(catalogPrice)));
		}
	}

	private StringBuffer buildBMSMDiscountId(CXPLineDetailsVO lineDetailsVO) {
		StringBuffer bmsmId = new StringBuffer();
		if (lineDetailsVO.getLineInfo() != null) {
			Arrays.stream(lineDetailsVO.getLineInfo()).forEach(lineInfo -> {
				String flowType = lineInfo.getLineActivityType();
				if (lineInfo.getItemsInfo() != null) {
					Arrays.stream(lineInfo.getItemsInfo()).forEach(itemsInfo -> {
						if (itemsInfo.getCartItems() != null && itemsInfo.getCartItems().getCartItem() !=null) {
							Arrays.stream(itemsInfo.getCartItems().getCartItem()).forEach(cartItem -> {
								if (cartItem.getSedOfferList() !=null && CollectionUtilities.isNotEmptyOrNull(cartItem.getSedOfferList().getSedOffer())) {
									cartItem.getSedOfferList().getSedOffer().forEach(sedOffer -> {
										if (sedOffer != null && "Y".equalsIgnoreCase(sedOffer.getAccessoryBMSM()) && !bmsmId.toString().contains(CartConstants.ACC_BMSM)) {
											String promotionId = CollectionUtilities.isNotEmptyOrNull(sedOffer.getPromoBadges()) && sedOffer.getPromoBadges().get(0) != null ?
													sedOffer.getPromoBadges().get(0).getPromotionId() : null;
											String strategicOffer = Boolean.TRUE.equals(sedOffer.getIsStrategicOffer()) ? "S" : "N";
											bmsmId.append(CartConstants.ACC_BMSM).append("-").append(promotionId).append("-")
													.append(strategicOffer).append("-").append(CartConstants.IS_BAU_OFFER).append("-").append(flowType).append("-").append(sedOffer.getOfferId()).append("|");
										}
									});
								}
							});
						}
					});
				}
			});
		}

		return bmsmId;
	}
	private void setAccessoryCategory(CurrentProfileSPO currentProfileSpo, Current currentItem) {
		List<Items> cartItemsArr = new ArrayList<Items>();
		Items cartItem = new Items();
		cartItem.setCategory("ACCESSORY");
		cartItem.setPrice(currentProfileSpo.getFinalPrice());
		cartItem.setProductId(currentProfileSpo.getSpoId());
		cartItem.setBvProductId(currentProfileSpo.getSpoId());// VisFeatureCode is unique
		currentItem.setId(currentProfileSpo.getSpoId());
		currentItem.setCategory("ACCESSORY");
		currentItem.setRecurringPrice(currentProfileSpo.getFinalPrice());
		cartItemsArr.add(cartItem);
	}

	private void setFeatureCategory(VisFeature visFeature, Current currentItem, boolean isFiveg, String lineActivityType, @NotNull String featureType, boolean isPerksAvailable) {
		List<Items> cartItemsArr = new ArrayList<Items>();
		Items cartItem = new Items();
		cartItem.setCategory("Feature");
		cartItem.setPrice(visFeature.getFeaturePrice());
		cartItem.setName(visFeature.getFeatureDesc());
		cartItem.setQuantity("1");
		cartItem.setProductId(visFeature.getVisFeatureCode());
		cartItem.setBvProductId(visFeature.getVisFeatureCode());// VisFeatureCode is unique
		currentItem.setCategory("Feature");
		currentItem.setId(visFeature.getVisFeatureCode());
		currentItem.setName(visFeature.getFeatureDesc());
		currentItem.setQty("1");
		currentItem.setRecurringPrice(visFeature.getFeaturePrice());
		if(isFiveg) {
			if(StringUtilities.isNotEmptyOrNull(visFeature.getType()) && !isPerksAvailable)
				currentItem.setMerchCat(visFeature.getType());
			else if(isPerksAvailable) {
				currentItem.setMerchCat("perks");
			}
		}
		if(CartConstants.HELPER_DISCOUNT.equalsIgnoreCase(featureType)) {
			cartItem.setCategory(CartConstants.HELPER_DISCOUNT);
			currentItem.setCategory(CartConstants.HELPER_DISCOUNT);
			currentItem.setOffer(visFeature.getFeatureDesc());
		}

		if (StringUtilities.isNotEmptyOrNull(lineActivityType)
				&& (lineActivityType.equalsIgnoreCase(CartConstants.FEA)|| "NSE".equalsIgnoreCase(lineActivityType)
				|| "NSE_5G".equalsIgnoreCase(lineActivityType) || "NSE_LTE".equalsIgnoreCase(lineActivityType)
				|| "AAL".equalsIgnoreCase(lineActivityType)
				|| "AAL_5G".equalsIgnoreCase(lineActivityType)
				|| "AAL_LTE".equalsIgnoreCase(lineActivityType)) && visFeature.getFeatureDesc() != null
				&& (visFeature.getCategoryCodes().contains(CartConstants.WHWPLUS_CATEGORYCODE)
				|| visFeature.getCategoryCodes().contains(CartConstants.WHWHOME_CATEGORYCODE))){
			if(visFeature.getAttributeNameValue() != null
					&& visFeature.getAttributeNameValue().getNameValue() != null
					&& visFeature.getAttributeNameValue().getNameValue().size() >= 2
					&&  visFeature.getAttributeNameValue().getNameValue().get(1).getProductAttributeValue() != null){
				cartItem.setQuantity(visFeature.getAttributeNameValue().getNameValue().get(1).getProductAttributeValue());
				currentItem.setQty(visFeature.getAttributeNameValue().getNameValue().get(1).getProductAttributeValue());
			}
			cartItem.setCategory("ACCESSORY");
			currentItem.setMerchCat(visFeature.getType());
			currentItem.setCategory("ACCESSORY");

		}

		cartItemsArr.add(cartItem);
	}

	private String fetchDigitalOrderId(OrderList orderlist) {
		if(orderlist.getOrderNumber() != 0)
			return String.valueOf(orderlist.getDigitalOrderId());
		return orderlist.getOrderNumber().toString();
	}

	private void populateProductOwnsData(CustomerProfile customerProfile, Product product) {
		List<Owns> owns = new ArrayList<>();
		customerProfile.getBillAccounts().stream().forEach(billAccount -> {
			if (billAccount.getMtns() !=null && !billAccount.getMtns().isEmpty() ) {
				billAccount.getMtns().stream().forEach(mtn -> {
					//Populate Device Info
					if (null != mtn.getEquipmentInfos()) {
						mtn.getEquipmentInfos().stream().forEach(equipment -> {
							if (equipment.getDeviceInfo() != null) {
								Owns own = new Owns();
								own.setName(equipment.getDeviceInfo().getModelName());
								own.setCategory(CartConstants.DEVICE_TYPE);
								own.setId(equipment.getDeviceInfo().getDeviceSku());
								own.setShared("N");
								owns.add(own);
							}
						});
					}
					//Populate Plan Info
					if(null != mtn.getPricePlanInfo()) {
						Owns own = new Owns();
						own.setCategory("PLAN");
						own.setShared(mtn.getPricePlanInfo().getPlanAttributes() != null && mtn.getPricePlanInfo().getPlanAttributes().getSharePlan() ? "Y" : "N");
						own.setId(mtn.getPricePlanInfo().getPlanId());
						own.setRecurringPrice("monthly price");
						owns.add(own);
					}
				});
			}
		});
		if(!CollectionUtils.isEmpty(owns)) {
			Owns[] ownsList = new Owns[owns.size()];
			owns.toArray(ownsList);
			product.setOwns(ownsList);
		}
	}

	private void setDownPaymentInfo(CXPCartItem item, CXPLineInfo lineInfo, Current currentItem){
		if(StringUtilities.isNotEmptyOrNull(item.getItemPrice())){
			currentItem.setFullRetailPrice(Double.valueOf(item.getItemPrice()));
		}
		if(null!=lineInfo.getInstallmentInfo()){
			if(StringUtilities.isNotEmptyOrNull(lineInfo.getInstallmentInfo().getDownPayment())){
				currentItem.setDownPayment(Double.valueOf(lineInfo.getInstallmentInfo().getDownPayment()));
			}
			currentItem.setFinalDeviceMonthlyPayment(lineInfo.getInstallmentInfo().getFinalDppPrice());
			currentItem.setInitialDeviceMonthlyPayment(lineInfo.getInstallmentInfo().getMonthlyInstallmentBeforeDP());
		}
	}

	public void buildPromoCartObject(RetrieveCartCXPResponse retrieveCartResponse,
			ValidateCartCXPResponse validateCartResponse, String methodType, String promosAppliedVal) {

		OmniDLData cartData = new OmniDLData();
		Map<String, String> altDataMap = new HashMap<>();
		Map<String, Object> customData = new HashMap<>();
		Map<String, String> vzTrgData = new HashMap<>();
		if (null != altDataMap.get(CartConstants.PROMOS_APPLIED)) {
			altDataMap.put(CartConstants.PROMOS_APPLIED, altDataMap.get(CartConstants.PROMOS_APPLIED) + ", " + promosAppliedVal);
			vzTrgData.put(CartConstants.OFFER, altDataMap.get(CartConstants.PROMOS_APPLIED) + ", " + promosAppliedVal);
		} else {
			altDataMap.put(CartConstants.PROMOS_APPLIED, promosAppliedVal);
			vzTrgData.put(CartConstants.OFFER, promosAppliedVal);
		}
		altDataMap.put(CartConstants.TEST_VERSION, "none");
		cartData.setAltData(altDataMap);
		customData.put("target", vzTrgData);
		cartData.setCustomData(customData);
		super.dlData = cartData;
	}

	// Method to build vzDL common data for new customer
	public void buildNewCustVzDl(String sessionId, String globalId, CartServiceCustomerInfo customerInfo) {
		OmniDLData landingDLData = new OmniDLData();
		Map<String, String> vzPageData = new HashMap<String, String>();
		Map<String, Object> customData = new HashMap<String, Object>();

		vzPageData.put("channelSession", sessionId);
		vzPageData.put(CartConstants.SESSION, !"".equals(globalId) ? globalId : customerInfo.getGlobalId());
		vzPageData.put("channel", "");
		vzPageData.put(CartConstants.CUSTOMER_TYPE, customerInfo.getCustomerType());

		if (CollectionUtilities.isNotEmptyOrNull(vzPageData)) {
			customData.put(CartConstants.VZPAGE, vzPageData);
		}

		Map<String, String> vzUserData = new HashMap<>();
		if (customerInfo.getCustomerType() != null)
			vzUserData.put(CartConstants.CUSTOMER_TYPE, customerInfo.getCustomerType());
		vzUserData.put(CartConstants.SESSION, sessionId);
		vzUserData.put(CartConstants.ACCOUNT_TYPE, "");
		vzUserData.put(CartConstants.AUTH_STATUS, "anonymous");
		customData.put("user", vzUserData);

		Engagement engagement = new Engagement();
		engagement.setIntent(CartConstants.ORDER);

		customData.put(CartConstants.TARGET_ENGAGEMENT, engagement);

		landingDLData.setCustomData(customData);
		super.dlData = landingDLData;
	}



	public void buildOmnidlForBBPAddPlan(AddPlanUIResponse response) {
		OmniDLData bbpAddPlanDLData = new OmniDLData();
		Map<String, Object> customData = new HashMap<String, Object>();

		Map<String, String> vzUserData = new HashMap<>();
		updateUserDataToVzdl(response, vzUserData);
		customData.put("user", vzUserData);

		bbpAddPlanDLData.setCustomData(customData);
		super.dlData = bbpAddPlanDLData;

	}

	private void updateUserDataToVzdl(AddPlanUIResponse response, Map<String, String> vzUserData) {

		if (response != null) {
			if (response.getServiceBody() != null && response.getServiceBody().getServiceResponse() != null
					&& response.getServiceBody().getServiceResponse().getContext() != null) {

				AddPlanContext contextData = response.getServiceBody().getServiceResponse().getContext();
				if (contextData != null) {
					setPlanDataToVzdl(vzUserData, contextData.getCartInfo());
				}

			}

		}
	}

	private void setPlanDataToVzdl(Map<String, String> vzUserData, CartServiceCartInfo cartInfo) {

		if (cartInfo != null && cartInfo.getLines() != null && cartInfo.getLines().length > 0) {
			Line[] lineDetails = cartInfo.getLines();
			List<String> planTypeInfo = new ArrayList<String>();

			for (Line planDetails : lineDetails) {
				if (planDetails != null && planDetails.getCurrentPlanType() != null) {
					planTypeInfo.add(planDetails.getCurrentPlanType());
				}
			}
			vzUserData.put("planType", String.join(",", planTypeInfo));

		}
	}

	public void buildOmnidlForBBP(AddDeviceUIResponse response) {
		OmniDLData bbpLandingDLData = new OmniDLData();
		Map<String, Object> customData = new HashMap<String, Object>();

		Map<String, String> event = new HashMap<>();
		updateEventDataForVzDL(event);
		customData.put("event", event);

		Map<String, String> altData = new HashMap<String, String>();
		updatePageDataForVzwDL(response, altData);
		bbpLandingDLData.setAltData(altData);

		Map<String, String> vzEnvData = new HashMap<String, String>();
		updateEnvDataForVzDL(response, vzEnvData);
		customData.put("env", vzEnvData);

		Map<String, String> vzUserData = new HashMap<>();
		updateUserDataForVzDL(response, vzUserData);
		customData.put("user", vzUserData);

		Map<String, String> vzUtilsData = new HashMap<>();
		updateUtilsDataForVzDL(response, vzUtilsData);
		customData.put("utils", vzUtilsData);

		Map<String, String> vzTxnData = new HashMap<>();
		updateTxnDataForVzDL(response, vzTxnData);
		customData.put("txn", vzTxnData);

		Engagement engagement = new Engagement();
		engagement.setIntent("Order");
		engagement.setId("none");
		customData.put(CartConstants.TARGET_ENGAGEMENT, engagement);
		bbpLandingDLData.setCustomData(customData);
		super.dlData = bbpLandingDLData;
	}

	public void buildOmnidlForAddStepUserData() {
		OmniDLData addStepDLData = new OmniDLData();
		Map<String, Object> customData = new HashMap<String, Object>();
		Map<String, String> vzUserData = new HashMap<>();
		vzUserData.put(CartConstants.AUTH_STATUS, "logged in");
		vzUserData.put(CartConstants.ACCOUNT_TYPE, "postpaid");
		customData.put("user", vzUserData);
		addStepDLData.setCustomData(customData);
		super.dlData = addStepDLData;
	}

	private void updatePageDataForVzwDL(AddDeviceUIResponse response, Map<String, String> altData) {
		if (response != null && response.getFlowType() != null) {
			altData.put("flowName", response.getFlowType());
		}

	}

	public void updateEventDataForVzDL(Map<String, String> eventData) {
		eventData.put(CartConstants.VALUE, "none");
		eventData.put(CartConstants.IS_PREVIOUSLY_USED_DEVICE,"false");
	}

	private void updateEnvDataForVzDL(AddDeviceUIResponse response, Map<String, String> vzEnvData) {
		vzEnvData.put("businessUnit", "wireless");
	}

	private void updateUserDataForVzDL(AddDeviceUIResponse response, Map<String, String> vzUserData) {
		if (response != null) {
			if (response.getServiceBody() != null && response.getServiceBody().getServiceResponse() != null
					&& response.getServiceBody().getServiceResponse().getContext() != null
					&& response.getServiceBody().getServiceResponse().getContext().getCustomerInfo() != null
					&& response.getServiceBody().getServiceResponse().getContext().getCustomerInfo()
							.getGlobalId() != null) {

				vzUserData.put(CartConstants.SESSION,
						response.getServiceBody().getServiceResponse().getContext().getCustomerInfo().getGlobalId());
			}
			updateUserDetails(response,vzUserData);
		}
	}
	private void updateUserDetails(AddDeviceUIResponse response, Map<String, String> vzUserData){

		if(response.getFlowType()!=null && response.getFlowType().equalsIgnoreCase("NSE")){
			vzUserData.put(CartConstants.AUTH_STATUS, "anonymous");
			vzUserData.put(CartConstants.ACCOUNT_TYPE, "unauthenticated");
		}else{
			if(response.getFlowType()!=null && response.getFlowType().equalsIgnoreCase("EXISTINGCUSTOMER")) {
				vzUserData.put(CartConstants.AUTH_STATUS, "logged in");
				vzUserData.put(CartConstants.ACCOUNT_TYPE, "postpaid");
			}
		}
		if (response.getValidateCartResponse() != null &&
				response.getValidateCartResponse().getData() != null &&
				response.getValidateCartResponse().getData().getValidateCartAndUpdate() != null &&
				response.getValidateCartResponse().getData().getValidateCartAndUpdate().getEcpdProfile() != null &&
				response.getValidateCartResponse().getData().getValidateCartAndUpdate().getEcpdProfile().getProfileId() != null) {
			vzUserData.put("containsEcpdId", "Y");
		}else{
			vzUserData.put("containsEcpdId", "N");
		}
	}
	private void updateUtilsDataForVzDL(AddDeviceUIResponse response, Map<String, String> vzUtilsData) {
		if (response != null) {
			if (response.getServiceBody() != null && response.getServiceBody().getServiceResponse() != null
					&& response.getServiceBody().getServiceResponse().getContext() != null
					&& response.getServiceBody().getServiceResponse().getContext().getCaseId() != null) {
				vzUtilsData.put("pegaCaseId", response.getServiceBody().getServiceResponse().getContext().getCaseId());
			}

		}

	}
	private void updateTxnDataForVzDL(AddDeviceUIResponse response, Map<String, String> vzTxnData) {
		if (response != null) {
			if (response.getServiceBody() != null && response.getServiceBody().getServiceResponse() != null
					&& response.getServiceBody().getServiceResponse().getContext() != null
					&& response.getServiceBody().getServiceResponse().getContext().getCartInfo() != null
					&& response.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartId() != null) {
				vzTxnData.put(CartConstants.CART_ID,
						response.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartId());

			}
		}
	}
	public void buildOrderConfirm5GObject(OrderConfirmationCXPResponse orderConfirmationResponse, ValidateCartCXPResponse validateCartResponse, String methodType, String flow) {

		OmniDLData cartData = new OmniDLData();
		Map<String, Object> customData = new HashMap<>();
		Cart cart = new Cart();
		Map<String, String> vzTxnData = new HashMap<>();
		Map<String, String> vzEventData = new HashMap<>();
		Map<String, String> vzUserData = new HashMap<>();
		CXPLineDetailsVO lineDetails = new CXPLineDetailsVO();
		boolean isFiveg = false;

		if (flow.equalsIgnoreCase("fiveG")) {
			isFiveg = true;
		}
		if (!CartConstants.RETRIEVE.equalsIgnoreCase(methodType) && null != orderConfirmationResponse.getData()) {
			if (null != orderConfirmationResponse.getData().getCart()
					&& null != orderConfirmationResponse.getData().getCart().getLineDetails())
				lineDetails = orderConfirmationResponse.getData().getCart().getLineDetails();

			if (null != orderConfirmationResponse.getData().getCart().getOrderDetails()
					&& null != orderConfirmationResponse.getData().getCart().getOrderDetails().getTotalDueToday()) {
				vzTxnData.put(CartConstants.NON_RECURRING_CHARGES,
						Double.toString(orderConfirmationResponse.getData().getCart().getOrderDetails().getTotalDueToday()));
			}
		}
		if (isFiveg) {
			if (orderConfirmationResponse.getData().getCart().getOrderDetails() != null && orderConfirmationResponse.getData().getCart().getOrderDetails().getTotalDueToday() != null)
				vzTxnData.put(CartConstants.TOTAL, orderConfirmationResponse.getData().getCart().getOrderDetails().getTotalDueToday().toString());
			if (orderConfirmationResponse.getData().getCart().getOrderDetails() != null
					&& null != orderConfirmationResponse.getData().getCart().getOrderDetails().getOrderList()
					&& orderConfirmationResponse.getData().getCart().getOrderDetails().getOrderList().size() >= 1
					&& orderConfirmationResponse.getData().getCart().getOrderDetails().getOrderList().get(0).getOrderNumber() != null)
				vzTxnData.put("id", orderConfirmationResponse.getData().getCart().getOrderDetails().getOrderList().get(0).getOrderNumber().toString());
		}
		cart.setOnlineStore(CartConstants.VZW_DESKTOP_STORE);
		if (null != lineDetails && null != lineDetails.getCartId()) {
			vzTxnData.put(CartConstants.CART_ID, lineDetails.getCartId());
		}
		if (null != lineDetails && null != lineDetails.getLineInfo()) {
			CXPLineInfo[] lineInfoItem = lineDetails.getLineInfo();
			for (CXPLineInfo lineInfoMem : lineInfoItem) {
				if (isFiveg) {
					vzTxnData.put(CartConstants.ORDER_TYPE, lineInfoMem.getLineActivityType());
				}
				Engagement engagement = new Engagement();
				if (isFiveg) {
					engagement.setIntent(CartConstants.ORDER);
					if (orderConfirmationResponse.getData().getCart().getCartHeader() != null && orderConfirmationResponse.getData().getCart().getCartHeader().getVisionCustomerType() != null)
						vzUserData.put(CartConstants.CUSTOMER_TYPE, orderConfirmationResponse.getData().getCart().getCartHeader().getVisionCustomerType());
				} else {
					engagement.setIntent(CartConstants.ORDER);
					vzEventData.put(CartConstants.VALUE, "scView");
				}
				if (cart != null)
					customData.put("cart", cart);
				cartData = setData(vzUserData, vzEventData, vzTxnData, engagement, isFiveg, customData);
				super.dlData = cartData;
				Map<String, String> altDataMap = new HashMap<>();
				altDataMap.put(CartConstants.TEST_VERSION, "none");
				cartData.setAltData(altDataMap);
				super.dlData = cartData;
			}
		}
	}


	public void buildUserCartCount(RetrieveCartCXPResponse retrieveCartResponse,
									 ValidateCartCXPResponse validateCartResponse, String methodType, String cartCount) {
		OmniDLData cartData = new OmniDLData();
		Map<String, Object> customData = new HashMap<>();
		Map<String, String> vzUserData = new HashMap<>();
		vzUserData.put(CartConstants.NUMBER_OF_LINES,cartCount);
		customData.put(CartConstants.USER, vzUserData);
		cartData.setCustomData(customData);
		super.dlData = cartData;
	}

	public void buildPlansFirstPageData(String processStep) {
		OmniDLData data = new OmniDLData();
		Map<String, Object> customData = new HashMap<>();
		Map<String, String> pageData = new HashMap<>();
		if(CartConstants.NEW_RECOMMENDED_PLAN_SELECTION.equalsIgnoreCase(processStep)) {
			pageData.put(CartConstants.SUB_FLOW, CartConstants.EXPRESS_NSE_PF);
		}else if(CartConstants.PLAN_SELECTION.equalsIgnoreCase(processStep)){
			pageData.put(CartConstants.SUB_FLOW, CartConstants.BAU_PF);
		}
		customData.put(CartConstants.VZPAGE, pageData);
		data.setCustomData(customData);
		super.dlData = data;
	}
	
	private OmniDLData setData(Map<String, String> vzUserData, Map<String, String> vzEventData, Map<String, String> vzTxnData, Engagement engagement, Boolean isFiveg, Map<String, Object> customData) {
		OmniDLData cartData = new OmniDLData();
		if (vzUserData != null && !vzUserData.isEmpty() && vzUserData.size() > 0)
			customData.put("user", vzUserData);
		if (vzEventData != null && !vzEventData.isEmpty() && vzEventData.size() > 0)
			customData.put("event", vzEventData);
		if (vzTxnData != null && !vzTxnData.isEmpty() && vzTxnData.size() > 0) {
			logger.info("TXN : setting txn key : ",vzTxnData);
			customData.put("txn", vzTxnData);
		}
		customData.put(CartConstants.TARGET_ENGAGEMENT, engagement);
		customData.put("target.tt", "none");
		cartData.setCustomData(customData);
		return cartData;
	}

	/**
	 * Taking the addDeviceUIRequest and exisistingSubflow as parameters and updating the data to Vzdl
	 * @param addDeviceUIRequest
	 * @param existingSubFlow
	 */
	public void updateSubFlowNameInVzdl(AddDeviceUIRequest addDeviceUIRequest, String existingSubFlow) {
		OmniDLData byodAddDevicedata = new OmniDLData();
		Map<String, Object> customData = new HashMap<String, Object>();

		Map<String, String> vzPageData = new HashMap<>();
		updatePageDataToVzdl(addDeviceUIRequest,existingSubFlow, vzPageData);
		customData.put(CartConstants.VZPAGE, vzPageData);

		byodAddDevicedata.setCustomData(customData);
		super.dlData = byodAddDevicedata;
	}

	private void updatePageDataToVzdl(AddDeviceUIRequest addDeviceUIRequest, String existingSubFlow, Map<String, String> vzPageData) {
		if (addDeviceUIRequest != null) {
			List<String> finalSubFlowList = new ArrayList();
			// if existing sub flow in redis is not empty or null, split it and add into finalSubFlowList
			if(StringUtilities.isNotEmptyOrNull(existingSubFlow))
				finalSubFlowList=new ArrayList(Arrays.asList(existingSubFlow.split(Pattern.quote("|"))));

			// check if subFlow value sent in request doesn't exist in existing sub flow into redis , then append it
			if(StringUtilities.isNotEmptyOrNull(addDeviceUIRequest.getData().getSubFlow()) &&
					StringUtils.equalsIgnoreCase(CartConstants.INSTANT_SUBFLOW,addDeviceUIRequest.getData().getSubFlow())
					&& !((List)finalSubFlowList).contains(CartConstants.INSTANT_SUBFLOW))
				finalSubFlowList.add(CartConstants.INSTANT_SUBFLOW);

			// determine actual sub flow type based on byodEsimPhone, smartIMEI whether user has selected esim, psim or esimltr.
			// Check if this subflow doesn't already exist in finalSubFlowList, then add it
			String subFlow=determineSubFlowBasedOnUserSelection(addDeviceUIRequest);
			logger.info("OmniDlBuilder :: subFlow based on user's selection is :{} ",subFlow);
			if(StringUtilities.isNotEmptyOrNull(subFlow) && !((List)finalSubFlowList).contains(subFlow))
				finalSubFlowList.add(subFlow);

			// join all the values of finalSubFlowList by | and set it in "subFlow" in vzPage map
			vzPageData.put(CartConstants.SUB_FLOW, finalSubFlowList.stream().collect(Collectors.joining("|")));

			logger.info("OmniDlBuilder :: final subflow is :{} ",finalSubFlowList);
		}
	}

	private String determineSubFlowBasedOnUserSelection(AddDeviceUIRequest addDeviceUIRequest) {
		if(addDeviceUIRequest.getData() !=null && addDeviceUIRequest.getData().getLines() !=null &&
				addDeviceUIRequest.getData().getLines().get(0) != null && addDeviceUIRequest.getData().getLines().get(0).getDevice().getByodESimPhone()!= null &&
				addDeviceUIRequest.getData().getLines().get(0).getDevice().getByodESimPhone()){
			if(addDeviceUIRequest.getData() != null && addDeviceUIRequest.getData().getLines() != null &&
					addDeviceUIRequest.getData().getLines().get(0) != null && addDeviceUIRequest.getData().getLines().get(0).getDevice().getSmartIMEI()!= null &&
					addDeviceUIRequest.getData().getLines().get(0).getDevice().getSmartIMEI())
				return CartConstants.ESIM_INSTANT_ACTIVATION_SUBFLOW;
			return CartConstants.ESIM_LATER_ACTIVATION_SUBFLOW;
		}
		return CartConstants.PSIM_SUBFLOW;
	}

	private void buildPageValues(Map<String, String> pageValues,Map<String,String> vzPageValues, BundleBuilderCXPResponseData response) {
		StringBuilder promoIds = new StringBuilder();
		if (StringUtilities.isNotEmptyOrNull(buildPromoValues(response, promoIds, vzPageValues)))
			pageValues.put(CartConstants.PROMOS_APPLIED, promoIds.toString());
		else
			pageValues.put(CartConstants.PROMOS_APPLIED, "None");
	}
	private String setOrderTypeForDL(BundleBuilderCXPLineInfo lineInfoMem, String orderTypeValue) {
		String orderType = "";
		if (StringUtilities.isNotEmptyOrNull(lineInfoMem.getLineActivityType())) {
			if (CartConstants.BYOD_LINE_ACTIVITY.equalsIgnoreCase(lineInfoMem.getLineActivityType())
					|| CartConstants.EUP_BYOD_LINE_ACTIVITY.equalsIgnoreCase(lineInfoMem.getLineActivityType()))
				orderType = orderTypeValue.contains("cpc")?"eso":"eso+cpc";
			else if (CartConstants.NSE_BYOD_LINE_ACTIVITY.equalsIgnoreCase(lineInfoMem.getLineActivityType()))
				orderType = "nso";
			else if (CartConstants.AAL_LINE_ACTIVITY.equalsIgnoreCase(lineInfoMem.getLineActivityType()))
				orderType = orderTypeValue.contains("cpc")?"aal":"aal+cpc";
			else
				orderType = lineInfoMem.getLineActivityType().toLowerCase();
		}

		if (StringUtilities.isNotEmptyOrNull(orderTypeValue)) {
			if (orderTypeValue.contains(orderType))
				orderType = orderTypeValue;
			else
				orderType = orderTypeValue + "+" + orderType;
		}

		return orderType;
	}
	public String buildPromoValues(ValidateCartCXPResponse response, StringBuilder promoIds) {
		if (response.getData() != null && response.getData().getValidateCartAndUpdate() != null
				&& response.getData().getValidateCartAndUpdate().getLineDetails() != null
				&& response.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()!=null
				&& response.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo().length > 0) {
			for (CXPLineInfo cartItem : response.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()) {
				Integer lineSeqNo = (cartItem.getMultiLineSeqNumber() != null) ? cartItem.getMultiLineSeqNumber() : 0;
				String flowType = evaluteFlowType(null, cartItem);
                Map<String,String> promoToOfferIdMap = new HashMap<>();
				mapValidateCartPromoValuesFromLineInfo(response, cartItem, promoIds, flowType);
				mapValidateCartPromoValuesFromServiceInfo(cartItem, promoIds, flowType,promoToOfferIdMap);
				if (response.getData().getValidateCartAndUpdate().getLineDetails().getTradeInDetail() != null) {
					setStandaloneTradeInPromoInVzdlTargetOffer(response.getData().getValidateCartAndUpdate().getLineDetails().getTradeInDetail(), promoIds, flowType, lineSeqNo,promoToOfferIdMap);
				}
			}
		}
		return promoIds.toString();
	}
	public void mapValidateCartPromoValuesFromLineInfo(ValidateCartCXPResponse response, CXPLineInfo cartItem, StringBuilder promoIds, String flowType) {
		if(cartItem.getItemsInfo()!=null && cartItem.getItemsInfo().length >0) {
			for(CXPItemInfo itemsInfo: cartItem.getItemsInfo()) {
				if (null != itemsInfo.getCartItems() && null != itemsInfo.getCartItems().getCartItem()) {
					for(CXPCartItem cart: itemsInfo.getCartItems().getCartItem()) {
						mapTradeInAndSedOfferInfoValidateCartPromoValue(response, cart, promoIds, flowType);
					}
				}
			}
		}
	}
	public void	mapTradeInAndSedOfferInfoValidateCartPromoValue(ValidateCartCXPResponse response, CXPCartItem cart, StringBuilder promoIds, String flowType){
		if(cart.getPromoHubOfferList() != null && cart.getPromoHubOfferList().getPromoHubOfferList() != null
				&& CollectionUtilities.isNotEmptyOrNull(cart.getPromoHubOfferList().getPromoHubOfferList())){
			cart.getPromoHubOfferList().getPromoHubOfferList().stream().forEach(tradeIn -> {
				if (response.getData().getValidateCartAndUpdate().getLineDetails().getTradeInDetail() != null) {
					setTradeinPromoInVzdlTargetOfferForVC(response.getData().getValidateCartAndUpdate().getLineDetails().getTradeInDetail(), tradeIn, promoIds, flowType);
				}
			});
		}
		if (cart.getSedOfferList() != null && cart.getSedOfferList().getSedOffer() != null
				&& CollectionUtilities.isNotEmptyOrNull(cart.getSedOfferList().getSedOffer())) {
			setSedOfferInfoInVzdlTargetOffer(cart.getSedOfferList(), promoIds, flowType);
		}

		if (cart.getRebateOffers() != null && !cart.getRebateOffers().isEmpty()) {
			cart.getRebateOffers().stream().forEach(rebateOffer ->
					setRebateOfferInfoInVzdlTargetOffer(rebateOffer, promoIds, flowType));
		}
	}
	public void mapValidateCartPromoValuesFromServiceInfo(CXPLineInfo cartItem, StringBuilder promoIds, String flowType,
                                                          Map<String,String> promoToOfferIdMap) {
		if(cartItem.getServiceInfo()!=null){
			if(cartItem.getServiceInfo().getSbdOffer() != null){
				List<SbdOffer> sbdOfferList = cartItem.getServiceInfo().getSbdOffer();
				if (!sbdOfferList.isEmpty()) {
					sbdOfferList.stream().forEach(sbdOffer ->
							setSbdOfferInfoInVzdlTargetOffer(sbdOffer, promoIds,flowType));
				}
			}
			if(cartItem.getServiceInfo().getThirdPartyOffer() != null){
				ThirdPartyOffer[] thirdPartyOfferList = cartItem.getServiceInfo().getThirdPartyOffer();
				if (thirdPartyOfferList != null && thirdPartyOfferList.length > 0) {
					Arrays.stream(thirdPartyOfferList).forEach(thirdPartyOffer ->
							setThirdPartyOfferInfoInVzdlTargetOffer(thirdPartyOffer, promoIds,flowType));
				}
			}
            if (cartItem.getPromoIntent() != null && cartItem.getPromoIntent().length > 0) {
                Arrays.stream(cartItem.getPromoIntent()).forEach(promoIntent -> {
                    if(StringUtils.isNotBlank(promoIntent.getOfferId()) && StringUtils.isNotBlank(promoIntent.getPromotionId())) {
                        promoToOfferIdMap.put(promoIntent.getOfferId(),promoIntent.getPromotionId());
                    }
                });
            }
		}
	}
	public String buildPromoValues(BundleBuilderCXPResponseData response, StringBuilder promoIds, Map<String,String>... vzPageValues) {
		if (response.getData() != null && response.getData().getPromoBundleBuilderCart() != null
				&& response.getData().getPromoBundleBuilderCart().getLineDetails() != null
				&& response.getData().getPromoBundleBuilderCart().getLineDetails().getLineInfo()!=null
				&& response.getData().getPromoBundleBuilderCart().getLineDetails().getLineInfo().length > 0) {
			for (BundleBuilderCXPLineInfo cartItem : response.getData().getPromoBundleBuilderCart().getLineDetails().getLineInfo()) {
				Integer lineSeqNo = (cartItem.getMultiLineSeqNumber() != null) ? cartItem.getMultiLineSeqNumber() : 0;
				String flowType = evaluteFlowType(cartItem, null);
				Map<String, String> vzPageValuesMap = Arrays.stream(vzPageValues).findFirst().orElse(new HashMap<>());
				vzPageValuesMap.put(FLOW, flowType.toLowerCase()); //CXTDT-654600
				mapBundleVuilderPromoValuesFromLineInfo(response, cartItem, promoIds, flowType);
				mapBundleBuilderPromoValuesFromServiceInfo(cartItem, promoIds, flowType);
				if (response.getData().getPromoBundleBuilderCart().getLineDetails().getTradeInDetail() != null) {
					setStandaloneTradeInPromoInVzdlTargetOfferPBB(response.getData().getPromoBundleBuilderCart().getLineDetails().getTradeInDetail(), promoIds, flowType, lineSeqNo);
				}
			}
		}
		return promoIds.toString();
	}
	public void mapBundleVuilderPromoValuesFromLineInfo(BundleBuilderCXPResponseData response, BundleBuilderCXPLineInfo cartItem, StringBuilder promoIds, String flowType) {
		if(cartItem.getItemsInfo()!=null && cartItem.getItemsInfo().length >0) {
			for(BundleBuilderCXPItemInfo itemsInfo: cartItem.getItemsInfo()) {
				if (null != itemsInfo.getCartItems() && null != itemsInfo.getCartItems().getCartItem()) {
					for(BundleBuilderCXPCartItem cart: itemsInfo.getCartItems().getCartItem()) {
						mapTradeInAndSedOfferInfoPromoValue(response, cart, promoIds, flowType);
					}
				}
			}
		}
	}
	public void	mapTradeInAndSedOfferInfoPromoValue(BundleBuilderCXPResponseData response, BundleBuilderCXPCartItem cart, StringBuilder promoIds, String flowType){
		if(cart.getPromoHubOfferList() != null && cart.getPromoHubOfferList().getPromoHubOfferList() != null
				&& CollectionUtilities.isNotEmptyOrNull(cart.getPromoHubOfferList().getPromoHubOfferList())){
			cart.getPromoHubOfferList().getPromoHubOfferList().stream().forEach(tradeIn -> {
				if (response.getData().getPromoBundleBuilderCart().getLineDetails().getTradeInDetail() != null) {
					setTradeinPromoInVzdlTargetOffer(response.getData().getPromoBundleBuilderCart().getLineDetails().getTradeInDetail(), tradeIn, promoIds, flowType);
				}
			});
		}
		if (cart.getSedOfferList() != null && cart.getSedOfferList().getSedOffer() != null
				&& CollectionUtilities.isNotEmptyOrNull(cart.getSedOfferList().getSedOffer())) {
			setSedOfferInfoInVzdlTargetOffer(cart.getSedOfferList(), promoIds, flowType);
		}
	}
	public void mapBundleBuilderPromoValuesFromServiceInfo(BundleBuilderCXPLineInfo cartItem, StringBuilder promoIds, String flowType) {
		if (cartItem.getServiceInfo() != null && cartItem.getServiceInfo().getSbdOffer() != null) {
			List<SbdOffer> sbdOfferList = cartItem.getServiceInfo().getSbdOffer();
			if (!sbdOfferList.isEmpty()) {
				sbdOfferList.stream().forEach(sbdOffer ->
						setSbdOfferInfoInVzdlTargetOffer(sbdOffer, promoIds,flowType));
			}
		}
	}
	private void buildAuthValues(Map<String, String> authValues, BundleBuilderCXPResponseData response) {
		if (response.getData() != null && response.getData().getPromoBundleBuilderCart() != null
				&& response.getData().getPromoBundleBuilderCart().getCartHeader() != null) {
			authValues.put(CartConstants.OMNI_DL_ACC_NO,
					response.getData().getPromoBundleBuilderCart().getCartHeader().getFullAccountNumber());
		}
	}
	public void buildCartItemsArrForTxn(Product product, BundleBuilderCXPResponseData response) {

		if (null != response.getData().getPromoBundleBuilderCart().getLineDetails()
				&& response.getData().getPromoBundleBuilderCart().getLineDetails().getLineInfo()!=null
				&& response.getData().getPromoBundleBuilderCart().getLineDetails().getLineInfo().length > 0) {
			List<Items> cartItemsArr = new ArrayList<Items>();
			BundleBuilderCXPLineInfo[] lineInfoItem = response.getData().getPromoBundleBuilderCart().getLineDetails().getLineInfo();
			List<Current> currentItemsArr = new ArrayList<Current>();
			for (BundleBuilderCXPLineInfo lineInfoMem : lineInfoItem) {
				List<BundleBuilderCXPCartItem> cartItemArray;
				int installmentTerm = 0;
				if (null != lineInfoMem.getInstallmentInfo()) {
					installmentTerm = lineInfoMem.getInstallmentInfo().getInstallmentTerm();
				}
				if(lineInfoMem.getItemsInfo()!=null && lineInfoMem.getItemsInfo().length >0) {
					for (BundleBuilderCXPItemInfo cxpItemsInfo : lineInfoMem.getItemsInfo()) {
						if (null != cxpItemsInfo) {
							if (cxpItemsInfo.getCartItems() != null && cxpItemsInfo.getCartItems().getCartItem() != null) {
								for (BundleBuilderCXPCartItem item : cxpItemsInfo.getCartItems().getCartItem()) {
									Current currentItem = new Current();
									if (CartConstants.DEVICE_TYPE.equalsIgnoreCase(item.getCartItemType())
											|| CartConstants.HELPER_ACCESSORY.equalsIgnoreCase(item.getCartItemType())) {

										if (CartConstants.DEVICE_TYPE.equalsIgnoreCase(item.getCartItemType())) {
											currentItem.setCategory(CartConstants.DEVICE_TYPE);
										}
										currentItem.setMerchCat("none");

										currentItem.setSku(item.getSkuId());
										currentItem.setQty("1");
										currentItem.setId(item.getSorId());
										currentItem.setName(item.getDescription());
										currentItem.setProductId(item.getProductId());
										if ("BYOD".equalsIgnoreCase(lineInfoMem.getLineActivityType())) {
											currentItem.setRecurringPrice("0.0");
											currentItem.setNonRecurringPrice("0.0");
										} else {
											setContractTypeForDL(item, currentItem, installmentTerm);
										}
										StringBuilder promoIds = new StringBuilder();
										if (StringUtilities.isNotEmptyOrNull(buildPromoValues(response, promoIds)))
											currentItem.setOffer(promoIds.toString());
										StringBuilder sbdOfferIds = new StringBuilder();
										if (StringUtils.isNotBlank(buildSBDOfferValues(response, sbdOfferIds)))
											currentItem.setDiscount(sbdOfferIds.toString());
										currentItem.setLine(lineInfoMem.getMultiLineSeqNumber().toString());
										setDownPaymentInfo(item, lineInfoMem, currentItem);
										currentItemsArr.add(currentItem);
									}
								}
							}
						}
					}
				}
			}
			Items[] ItemsList = new Items[cartItemsArr.size()];
			cartItemsArr.toArray(ItemsList);

			Current[] currentList = new Current[currentItemsArr.size()];
			currentItemsArr.toArray(currentList);
			product.setCurrent(currentList);
		}

	}
	private void setContractTypeForDL(BundleBuilderCXPCartItem item, Current currentItem, int installmentTerm) {
		String contractType = "";
		if (StringUtilities.isNotEmptyOrNull(item.getPriceType())) {
			if ("VERIZON_EDGE".equalsIgnoreCase(item.getPriceType())) {
				if (installmentTerm == 36) {
					contractType = "dpp 36m";
				} else if (installmentTerm == 30) {
					contractType = "dpp 30m";
				} else {
					contractType = "dpp";
				}
			} else if ("MONTH_TO_MONTH".equalsIgnoreCase(item.getPriceType()))
				contractType = "retail price";
			else if ("TWO_YEAR".equalsIgnoreCase(item.getPriceType()))
				contractType = "2 year contract";
		}
		currentItem.setContractType(contractType);
	}
	public String buildSBDOfferValues(BundleBuilderCXPResponseData response, StringBuilder promoValue) {
		if (response.getData() != null && response.getData().getPromoBundleBuilderCart() != null
				&& response.getData().getPromoBundleBuilderCart().getLineDetails() != null
				&& response.getData().getPromoBundleBuilderCart().getLineDetails().getLineInfo() != null
				&& response.getData().getPromoBundleBuilderCart().getLineDetails().getLineInfo().length > 0){

			for (BundleBuilderCXPLineInfo lineInfoItem : response.getData().getPromoBundleBuilderCart().getLineDetails().getLineInfo()){
				if(lineInfoItem != null && lineInfoItem.getServiceInfo() != null && lineInfoItem.getServiceInfo().getSbdOffer() != null){
					List<SbdOffer> sbdOfferList = lineInfoItem.getServiceInfo().getSbdOffer();
					for (SbdOffer sbd : sbdOfferList) {
						if (sbd.getDiscAmt() != null) {
							if (StringUtils.isNotBlank(promoValue.toString()))
								promoValue.append(", ").append(sbd.getDiscAmt());
							else
								promoValue.append(sbd.getDiscAmt());
						}
					}
				}
			}
		}

		return promoValue.toString();
	}
	private void setDownPaymentInfo(BundleBuilderCXPCartItem item,BundleBuilderCXPLineInfo lineInfo,Current currentItem){
		if(StringUtilities.isNotEmptyOrNull(item.getItemPrice())){
			currentItem.setFullRetailPrice(Double.valueOf(item.getItemPrice()));
		}
		if(null!=lineInfo.getInstallmentInfo()){
			if(StringUtilities.isNotEmptyOrNull(lineInfo.getInstallmentInfo().getDownPayment())){
				currentItem.setDownPayment(Double.valueOf(lineInfo.getInstallmentInfo().getDownPayment()));
			}
			currentItem.setFinalDeviceMonthlyPayment(lineInfo.getInstallmentInfo().getFinalDppPrice());
			currentItem.setInitialDeviceMonthlyPayment(lineInfo.getInstallmentInfo().getMonthlyInstallmentBeforeDP());
		}
	}
	private void buildTxnValues(Map<String, String> txnValues, BundleBuilderCXPResponseData response) {
		if (response.getData() != null && response.getData().getPromoBundleBuilderCart() != null) {
			BundleBuilderCXPCartVO cartData = response.getData().getPromoBundleBuilderCart();
			if (cartData != null) {
				setLineDetails(txnValues, cartData);
			}
			if(cartData != null && StringUtilities.isNotEmptyOrNull(cartData.getCartId()))
				txnValues.put(CartConstants.CART_ID, cartData.getCartId());
		}
		txnValues.put(CartConstants.ORDER_TYPE, "none");
		txnValues.put(CartConstants.EVAR37, "none");
	}
	private void setLineDetails(Map<String, String> txnValues,BundleBuilderCXPCartVO cartData) {
		BundleBuilderCXPLineDetailsVO cartLineDetails=cartData.getLineDetails();
		if (cartLineDetails != null) {
			if (cartLineDetails.getLineInfo() != null && cartLineDetails.getLineInfo().length > 0) {
				BundleBuilderCXPLineInfo[] cartLineInfo = cartLineDetails.getLineInfo();
				if(cartLineDetails.getNumOfLines()!=null) {
					txnValues.put("numberOfLines",String.valueOf(cartLineDetails.getNumOfLines()));
				}
			}
		}

	}
	private void buildUserValues(Map<String, String> userValues, BundleBuilderCXPResponseData response) {
		if (response!=null && response.getData() != null && response.getData().getPromoBundleBuilderCart() != null
				&& response.getData().getPromoBundleBuilderCart().getLineDetails() != null &&
				response.getData().getPromoBundleBuilderCart().getLineDetails().getNumOfLines() != null) {
			userValues.put(CartConstants.NUMBER_OF_LINES, response.getData().getPromoBundleBuilderCart().getLineDetails().getNumOfLines().toString());
		}
	}
	public void buildCartValues(Cart cart) {
		cart.setOnlineStore(CartConstants.VZW_DESKTOP_STORE);
	}
	public void buildCartItemsArr(List<Items> cartItemsArr, BundleBuilderCXPResponseData response) {
		if (null != response.getData().getPromoBundleBuilderCart().getLineDetails()) {
			BundleBuilderCXPLineInfo[] lineInfoItem = response.getData().getPromoBundleBuilderCart().getLineDetails().getLineInfo();
			List<Current> currentItemsArr = new ArrayList<Current>();
			for (BundleBuilderCXPLineInfo lineInfoMem : lineInfoItem) {
				if (lineInfoMem.getItemsInfo() != null){
					for(BundleBuilderCXPItemInfo cxpItemsInfo:lineInfoMem.getItemsInfo()){
						if (cxpItemsInfo.getCartItems() != null && cxpItemsInfo.getCartItems().getCartItem() != null) {
							for (BundleBuilderCXPCartItem item : cxpItemsInfo.getCartItems().getCartItem()) {
								Items cartItem = new Items();
								Current currentItem = new Current();
								if (CartConstants.DEVICE_TYPE.equalsIgnoreCase(item.getCartItemType())
										|| CartConstants.HELPER_ACCESSORY.equalsIgnoreCase(item.getCartItemType())) {

									if (CartConstants.DEVICE_TYPE.equalsIgnoreCase(item.getCartItemType())){
										cartItem.setCategory("Device");
									}
									cartItem.setPrice(item.getItemPrice());
									cartItem.setName(item.getDescription());
									cartItem.setQuantity("1");
									cartItem.setProductId(item.getSorId());
									cartItem.setBvProductId(item.getProductId());
									cartItem.setSorDeviceCategory(item.getSorDeviceCategory());
									cartItemsArr.add(cartItem);
									currentItem.setMerchCat(item.getManufacturer());
									currentItem.setSku(item.getSkuId());
									currentItem.setQty("1");
									currentItem.setId(item.getSkuId());
									currentItem.setName(item.getDescription());
									currentItemsArr.add(currentItem);
								}}}}}}
			Items[] ItemsList = new Items[cartItemsArr.size()];
			cartItemsArr.toArray(ItemsList);
			Current[] currentList = new Current[currentItemsArr.size()];
			currentItemsArr.toArray(currentList);
		}
	}
	private void setHashCodeInLines(CartRedisData redisData, CXPLineInfo lineInfoMem, Current currentItem) {
		if (redisData != null && CollectionUtilities.isNotEmptyOrNull(redisData.getLandingMtnHashCode())
				&& StringUtilities.isNotEmptyOrNull(redisData.getLandingMtnHashCode().get(lineInfoMem.getMobileNumber())))
			currentItem.setLine(redisData.getLandingMtnHashCode().get(lineInfoMem.getMobileNumber()));
		currentItem.setGroup(String.valueOf(lineInfoMem.getMultiLineSeqNumber()));
	}
	private void setPlanPathDetails(Current currentItem, CartRedisData redisData, CXPLineInfo lineInfoMem) {
		if (redisData != null && CollectionUtilities.isNotEmptyOrNull(redisData.getPlanSelectionPath())) {
			Map<String, String> planSelection =  null;
			if (redisData.getPlanSelectionPath().get(lineInfoMem.getLineNumber()) != null)
				planSelection = redisData.getPlanSelectionPath().get(lineInfoMem.getLineNumber());
			else if (redisData.getPlanSelectionPath().get(lineInfoMem.getMobileNumber()) != null)
				planSelection = redisData.getPlanSelectionPath().get(lineInfoMem.getMobileNumber());
			setPathAndAction(currentItem, planSelection);
		}
		setHashCodeInLines(redisData, lineInfoMem,currentItem);
	}
	private void setPathAndAction(Current currentItem, Map<String, String> planSelection) {
		if (planSelection != null) {
			if (StringUtilities.isNotEmptyOrNull(planSelection.get(CartConstants.PATH)))
				currentItem.setPath(planSelection.get(CartConstants.PATH));
			if (StringUtilities.isNotEmptyOrNull(planSelection.get(CartConstants.ACTION)))
				currentItem.setAction(planSelection.get(CartConstants.ACTION));
		}
	}
	public void buildEngagement(Engagement engagement) {
		engagement.setIntent("Order");
		engagement.setOffered("none");
	}
	private void buildTargetValues(Map<String, String> target, BundleBuilderCXPResponseData response) {
		StringBuilder promoIds = new StringBuilder();
		if (StringUtilities.isNotEmptyOrNull(buildPromoValues(response, promoIds))) {
			target.put(CartConstants.OFFER, promoIds.toString());
		}
	}
	private void buildTargetValues(Map<String, String> target, ValidateCartCXPResponse response, boolean isFiveG) {
		StringBuilder promoIds = new StringBuilder();
		String promos = isFiveG ? populateAllFWADiscounts(response.getData().getValidateCartAndUpdate(), promoIds) : buildPromoValues(response, promoIds);
		if (StringUtilities.isNotEmptyOrNull(promoIds.toString())) {
			target.put(CartConstants.OFFER, promoIds.toString());
		}else{
			target.put(CartConstants.OFFER, "none");
		}
	}

	private void buildTargetValuesForProspect(Map<String, String> target, CXPCartVO response) {
		StringBuilder promoIds = new StringBuilder();
		String promos =  populateAllFWADiscounts(response, promoIds);
		if (StringUtilities.isNotEmptyOrNull(promoIds.toString())) {
			target.put(CartConstants.OFFER, promoIds.toString());
		}else{
			target.put(CartConstants.OFFER, "none");
		}
	}

	/**
	 * Populates the account discounts in the cartVO by iterating through the line details of the cartVO data.
	 * @param  cartVO  the validate cart CXP cartVO containing the line details
	 * @param  promoIds  the string builder to store the promo IDs
	 */
	private String populateAllFWADiscounts(CXPCartVO cartVO, StringBuilder promoIds) {
		if(cartVO.getLineDetails() !=null	 && null!= cartVO.getLineDetails().getLineInfo()) {
			Arrays.asList(cartVO.getLineDetails().getLineInfo()).stream().filter(Objects::nonNull).forEach(lineInfo -> {
					if (cartVO.getEcpdProfile() != null)
						populateServiceInfoDiscounts(lineInfo.getServiceInfo(), promoIds);
					if (null != lineInfo.getServiceInfo() && null != lineInfo.getServiceInfo().getSelectedFeaturesList() &&
							CollectionUtilities.isNotEmptyOrNull(lineInfo.getServiceInfo().getSelectedFeaturesList().getVisFeature())) {
						populateAccountSPODiscounts(lineInfo, promoIds);
						populatePlanDiscounts(lineInfo, promoIds);
					}
					if(null != lineInfo.getItemsInfo()) {
						Arrays.stream(lineInfo.getItemsInfo()).filter(Objects::nonNull).forEach(itemInfo -> populateItemLevelDiscounts(itemInfo.getCartItems(), promoIds));
					}
			});
			if (promoIds.length() > 0)
				if (promoIds.toString().endsWith(CartConstants.DELIMETER_HYPHEN))
					promoIds.deleteCharAt(promoIds.length() - 1);
			promoIds.append("|");
		}
		return promoIds.toString();
	}

	/**
	 * Iterate through cart itesm and fetch the rebate offers and capture it for Tagging purposes
	 * @param cartItems
	 * @param promoIds
	 */
	private void populateItemLevelDiscounts(CXPCartItemsVO cartItems, StringBuilder promoIds) {
		if(cartItems != null && cartItems.getCartItem() != null && cartItems.getCartItem().length > 0) {
			Arrays.stream(cartItems.getCartItem()).filter(Objects::nonNull).forEach(cartItem -> mapRebateOffersFWA(cartItem.getRebateOffers(), promoIds));
		}
	}

	private void mapRebateOffersFWA(List<RebateOffer> rebateOffers, StringBuilder promoIds) {
		if(rebateOffers != null) {
			rebateOffers.stream().filter(Objects::nonNull).forEach(rebateOffer -> {
				promoIds.append("REBATE").append(EMPTY_SPACE);
				promoIds.append(rebateOffer.getPropositionId()).append(CartConstants.EMPTY_SPACE);
				promoIds.append(rebateOffer.getDescription()).append(DELIMETER_HYPHEN);
			});
		}
	}


	/**
	 * Populates the plan discounts into the promoIds StringBuilder.
	 * @param  cxpLineInfo   the CXPLineInfo object containing the service info
	 * @param  promoIds      the StringBuilder to store the discounts
	 */
	private void populatePlanDiscounts(CXPLineInfo cxpLineInfo, StringBuilder promoIds) {
		if(cxpLineInfo.getServiceInfo() != null && StringUtilities.isNotEmptyOrNull(cxpLineInfo.getServiceInfo().getNewPricePlanId())) {
			promoIds.append(cxpLineInfo.getServiceInfo().getNewPricePlanId()).append(CartConstants.DELIMETER_HYPHEN);
			cxpLineInfo.getServiceInfo().getSelectedFeaturesList().getVisFeature().stream().filter(Objects::nonNull).filter(visFeature ->
					"SPO".equalsIgnoreCase(visFeature.getType()) && "L".equalsIgnoreCase(visFeature.getLevel()) &&
							!Collections.disjoint(fwaSPOCategoryCodes, visFeature.getCategoryCodes()) &&
							!(visFeature.getCategoryCodes().contains(CartConstants.PAPER_FREE) || visFeature.getCategoryCodes().contains(CartConstants.AUTOPAY)))
							.forEach(visFeature -> {
								promoIds.append(visFeature.getType()).append(EMPTY_SPACE);
								promoIds.append(visFeature.getVisFeatureCode()).append(EMPTY_SPACE);
								promoIds.append(Math.abs(Double.parseDouble(visFeature.getFeaturePrice()))).append(CartConstants.DELIMETER_HYPHEN);
			});
			if(cxpLineInfo.getServiceInfo().getThirdPartyOffer() != null){
				ThirdPartyOffer[] thirdPartyOfferList = cxpLineInfo.getServiceInfo().getThirdPartyOffer();
				if (thirdPartyOfferList != null && thirdPartyOfferList.length > 0) {
					Arrays.stream(thirdPartyOfferList).forEach(thirdPartyOffer -> {
						promoIds.append(thirdPartyOffer.getOfferType()).append(EMPTY_SPACE);
						promoIds.append(thirdPartyOffer.getOfferID()).append(EMPTY_SPACE);
						promoIds.append(thirdPartyOffer.getOfferName()).append(CartConstants.DELIMETER_HYPHEN);
					});
				}
			}
		}
		if(null != cxpLineInfo && cxpLineInfo.getServiceInfo() != null && cxpLineInfo.getLineActivityType() !=null && (cxpLineInfo.getLineActivityType().equalsIgnoreCase(CartConstants.FEA)
				|| cxpLineInfo.getLineActivityType().equalsIgnoreCase(CartConstants.ACC))
				|| "NSE".equalsIgnoreCase(cxpLineInfo.getLineActivityType())
				|| "NSE_5G".equalsIgnoreCase(cxpLineInfo.getLineActivityType())
				|| "NSE_LTE".equalsIgnoreCase(cxpLineInfo.getLineActivityType())
				|| "AAL".equalsIgnoreCase(cxpLineInfo.getLineActivityType())
				|| "AAL_5G".equalsIgnoreCase(cxpLineInfo.getLineActivityType())
				|| "AAL_LTE".equalsIgnoreCase(cxpLineInfo.getLineActivityType())) {
			cxpLineInfo.getServiceInfo().getSelectedFeaturesList().getVisFeature().stream().filter(Objects::nonNull).filter(visFeature ->
							"SPO".equalsIgnoreCase(visFeature.getType()) && "L".equalsIgnoreCase(visFeature.getLevel()) &&
									"A".equalsIgnoreCase(visFeature.getAddDeleteInd()) &&
									(visFeature.getCategoryCodes().contains(CartConstants.WHWHOME_CATEGORYCODE) || visFeature.getCategoryCodes().contains(CartConstants.WHWPLUS_CATEGORYCODE))
									&& !(visFeature.getCategoryCodes().contains(CartConstants.PAPER_FREE) || visFeature.getCategoryCodes().contains(CartConstants.AUTOPAY)))
					.findFirst().ifPresent(visFeature -> {
						promoIds.append(visFeature.getType()).append(EMPTY_SPACE);
						promoIds.append(visFeature.getVisFeatureCode()).append(EMPTY_SPACE);
						if (null != visFeature.getFeatureDiscounts()
								&& StringUtilities.isNotEmptyOrNull(visFeature.getFeatureDiscounts().get(0).getDiscountId())
								&& StringUtilities.isNotEmptyOrNull(visFeature.getFeatureDiscounts().get(0).getDiscountdescription())
								&& visFeature.getFeatureDiscounts().size() > 0
								&& visFeature.getFeatureDiscounts().get(0).getDiscountdescription().equalsIgnoreCase(CartConstants.WHW_DISCOUNT)) {
							promoIds.append(visFeature.getFeatureDiscounts().get(0).getDiscountId()).append(EMPTY_SPACE);
						}

					});
		}
	}
	/**
	 * Populates the account SPO discounts into the promoIds StringBuilder.
	 * @param  cxpLineInfo   the CXPLineInfo object containing the service info
	 * @param  promoIds      the StringBuilder to store the discounts
	 */
	private void populateAccountSPODiscounts(CXPLineInfo cxpLineInfo, StringBuilder promoIds) {
		if(cxpLineInfo.getServiceInfo() != null && StringUtilities.isNotEmptyOrNull(cxpLineInfo.getServiceInfo().getNewPricePlanId())) {
			cxpLineInfo.getServiceInfo().getSelectedFeaturesList().getVisFeature().stream().filter(Objects::nonNull).filter(visFeature ->
					"SPO".equalsIgnoreCase(visFeature.getType()) && "L".equalsIgnoreCase(visFeature.getLevel()) &&
							visFeature.getCategoryCodes().contains(CartConstants.DISC_PROMO) && visFeature.getCategoryCodes().contains(CartConstants.PAPER_FREE)
							&& visFeature.getCategoryCodes().contains(CartConstants.AUTOPAY)).findFirst().ifPresent(visFeature -> {
								promoIds.append("ACC").append(CartConstants.DELIMETER_HYPHEN);
								promoIds.append(visFeature.getType()).append(CartConstants.DELIMETER_HYPHEN);
								promoIds.append(visFeature.getVisFeatureCode()).append(CartConstants.DELIMETER_HYPHEN);
								promoIds.append(Math.abs(Double.parseDouble(visFeature.getFeaturePrice())));
								promoIds.append("|");
			});
		}
	}
	/**
	 * Populates the discounts for the given service info into the promoIds StringBuilder.
	 * @param serviceInfo the ServiceInfo object containing the plan details and promotions
	 * @param promoIds the StringBuilder to store the discounts
	 */
	private void populateServiceInfoDiscounts(ServiceInfo serviceInfo, StringBuilder promoIds) {
		if (null != serviceInfo && null != serviceInfo.getPlanDetails()
				&& null != serviceInfo.getPlanDetails().getPlanPromotions()
				&& null != serviceInfo.getPlanDetails().getPlanPromotions().getPromos()
				&& serviceInfo.getPlanDetails().getPlanPromotions().getPromos().size() > 0) {
			serviceInfo.getPlanDetails().getPlanPromotions().getPromos().stream()
					.filter(planPromos -> null != planPromos && !CartConstants.HUNDRED.equalsIgnoreCase(planPromos.getPercentageOff())).findFirst().ifPresent(planPromos -> {
						if (null != planPromos.getAmountOff()) {
							promoIds.append("EMP").append(CartConstants.DELIMETER_HYPHEN);
							promoIds.append(planPromos.getId()).append(CartConstants.DELIMETER_HYPHEN);
							promoIds.append(planPromos.getPercentageOff() + "%");
							promoIds.append("|");
						}
					});
		}
	}

	private String evaluteFlowType(BundleBuilderCXPLineInfo lineInfoMem, CXPLineInfo cxpLineInfo) {
		StringBuilder lineActivityType = new StringBuilder();
		if(lineInfoMem != null && StringUtilities.isNotEmptyOrNull(lineInfoMem.getLineActivityType())) {
			lineActivityType.append(lineInfoMem.getLineActivityType());
		}
		if(cxpLineInfo != null && StringUtilities.isNotEmptyOrNull(cxpLineInfo.getLineActivityType())) {
			lineActivityType.append(cxpLineInfo.getLineActivityType());
		}
		if(StringUtilities.isNotEmptyOrNull(lineActivityType.toString())) {
			switch (lineActivityType.toString()) {
				case CartConstants.BYOD_LINE_ACTIVITY, CartConstants.EUP_BYOD_LINE_ACTIVITY:
					return "ESO";
				case CartConstants.NSE_BYOD_LINE_ACTIVITY:
					return "NSO";
				case CartConstants.ACC:
					return "NAO";
				default:
					return lineActivityType.toString();
			}
		}
		return "";
	}

	private void setThirdPartyOfferInfoInVzdlTargetOffer(ThirdPartyOffer thirdPartyOffer, StringBuilder promoIds, String flowType) {
		if(thirdPartyOffer != null) {
			String offerType = CartConstants.NATIONAL_OFFER;
			String promoType =  getPromoTypeForThirdPartyOfferMapping(thirdPartyOffer);
			String promotionId = getPromotionIdForThirdPartyOfferMapping(thirdPartyOffer);
			Boolean isChoiceOffer = getChoiceOffer(thirdPartyOffer);
			String sedOfferId = (StringUtilities.isNotEmptyOrNull(thirdPartyOffer.getOfferID())) ? thirdPartyOffer.getOfferID() : "";
			if(StringUtilities.isNotEmptyOrNull(promoType)){
				mapPromos(promoType,promotionId,sedOfferId,offerType,flowType,promoIds,isChoiceOffer);
			}
		}
	}

	private	String getPromoTypeForThirdPartyOfferMapping(ThirdPartyOffer thirdPartyOffer){
		if(StringUtilities.isNotEmptyOrNull(thirdPartyOffer.getRewardType())){
			return thirdPartyOffer.getRewardType();
		} else if (CollectionUtilities.isNotEmptyOrNull(thirdPartyOffer.getPromoBadges()) && thirdPartyOffer.getPromoBadges().get(0) != null && StringUtilities.isNotEmptyOrNull(thirdPartyOffer.getPromoBadges().get(0).getOfferType())) {
			return thirdPartyOffer.getPromoBadges().get(0).getOfferType();
		}
		return "";
	}
	private	Boolean getChoiceOffer(ThirdPartyOffer thirdPartyOffer){
		if (CollectionUtilities.isNotEmptyOrNull(thirdPartyOffer.getPromoBadges())
				&& thirdPartyOffer.getPromoBadges().get(0) != null){
			return thirdPartyOffer.getPromoBadges().get(0).getChoiceOffer();
		}
		return Boolean.FALSE;
	}
	private	String getPromotionIdForThirdPartyOfferMapping(ThirdPartyOffer thirdPartyOffer){
		if(CollectionUtilities.isNotEmptyOrNull(thirdPartyOffer.getPromoBadges()) && thirdPartyOffer.getPromoBadges().get(0) != null && StringUtilities.isNotEmptyOrNull(thirdPartyOffer.getPromoBadges().get(0).getPromotionId())) {
			return thirdPartyOffer.getPromoBadges().get(0).getPromotionId();
		}
		return "";
	}

	private void mapPromos(String promoType, String promotionId, String sedOfferId,  String offerType, String flowType, StringBuilder promos, Boolean choiceOffer){
		String choiceOrBauOffer = (choiceOffer != null && choiceOffer) ? CartConstants.IS_CHOICE_OFFER : CartConstants.IS_BAU_OFFER;
		if(StringUtilities.isNotEmptyOrNull(promotionId) && StringUtilities.isNotEmptyOrNull(sedOfferId)){
			if (StringUtilities.isNotEmptyOrNull(flowType)) {
				promos.append(promoType).append("-").append(promotionId).append("-").append(offerType).append("-").append(choiceOrBauOffer).append("-").append(flowType).append("-").append(sedOfferId).append("|");
			} else {
				promos.append(promoType).append("-").append(promotionId).append("-").append(offerType).append("-").append(choiceOrBauOffer).append("-").append(sedOfferId).append("|");
			}
		} else if(StringUtilities.isNotEmptyOrNull(sedOfferId)) {
			if (StringUtilities.isNotEmptyOrNull(flowType)) {
				promos.append(promoType).append("-").append(offerType).append("-").append(choiceOrBauOffer).append("-").append(flowType).append("-").append(sedOfferId).append("|");
			} else {
				promos.append(promoType).append("-").append(offerType).append("-").append(choiceOrBauOffer).append("-").append(sedOfferId).append("|");
			}
		} else if(StringUtilities.isNotEmptyOrNull(promotionId)){
			if (StringUtilities.isNotEmptyOrNull(flowType)) {
				promos.append(promoType).append("-").append(promotionId).append("-").append(offerType).append("-").append(choiceOrBauOffer).append("-").append(flowType).append("|");
			} else {
				promos.append(promoType).append("-").append(promotionId).append("-").append(offerType).append("-").append(choiceOrBauOffer).append("|");
			}
		}
	}
    // PRODDEF-15597 - Added flowName Logic for Validate cart API call
	private void buildValidateCartPageValues(Map<String, String> pageValues,Map<String,String> vzPageValues, ValidateCartCXPResponse response) {

		if (response.getData() != null && response.getData().getValidateCartAndUpdate() != null
				&& response.getData().getValidateCartAndUpdate().getLineDetails() != null
				&& response.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo() != null
				&& response.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo().length > 0) {
			String orderTypeValue="";
			CXPLineInfo[] lineInfoItems =response.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo();
			for(CXPLineInfo cartLineInfo:lineInfoItems) {
				orderTypeValue =setOrderTypeForValidateCartDL(cartLineInfo, orderTypeValue);
			}
			//PRODDEF-19375 NEXT_GEN|NSE+Trade-in evar18 Trade-in details not coming in evar from expresscart to orderconfirmation page
			if (null!=response.getData().getValidateCartAndUpdate().getLineDetails().getTradeInDetail()
					&& CollectionUtilities.isNotEmptyOrNull(response.getData().getValidateCartAndUpdate().getLineDetails().getTradeInDetail().getTradeInItems())) {
				if (!orderTypeValue.contains("tradein")) {
					orderTypeValue = orderTypeValue + "+tradein";
				}
			}
			if(StringUtilities.isNotEmptyOrNull(orderTypeValue)) {
				pageValues.put("flow", orderTypeValue);
               //vzPageValues.put("flow", orderTypeValue);
			}
		}
	}
	private String setOrderTypeForValidateCartDL(CXPLineInfo lineInfoMem, String orderTypeValue) {

		String orderType =evaluteFlowType(null, lineInfoMem);
		if (StringUtilities.isNotEmptyOrNull(orderTypeValue)) {
			if (!orderTypeValue.contains(orderType.toLowerCase()))
				orderTypeValue = orderTypeValue + "+" + orderType.toLowerCase();
		}else {
			orderTypeValue = orderType.toLowerCase();
		}
		if (lineInfoMem != null && lineInfoMem.getItemsInfo() != null) {
			for (CXPItemInfo cxpItemsInfo : lineInfoMem.getItemsInfo()) {
				if (cxpItemsInfo.getCartItems() != null && cxpItemsInfo.getCartItems().getCartItem() != null) {
					for (CXPCartItem cartItem : cxpItemsInfo.getCartItems().getCartItem()) {
						if ("ACCESSORY".equalsIgnoreCase(cartItem.getCartItemType().toString())) {
							if (StringUtilities.isNotEmptyOrNull(orderTypeValue)) {
								if (!orderTypeValue.contains("nao"))
									orderTypeValue = orderTypeValue + "+" + "nao";
							}
							else {
								orderTypeValue = "nao";
							}
						}
					}
				}
			}
		}
		return orderTypeValue;
	}

	private void setStandaloneTradeInPromoInVzdlTargetOffer(TradeInDetail tradeInDetail , StringBuilder promoIds, String flowType, Integer lineSeqNo,
															Map<String,String> promoToOfferIdMap) {
		if (promoIds != null && tradeInDetail != null && CollectionUtilities.isNotEmptyOrNull(tradeInDetail.getTradeInItems())) {
			tradeInDetail.getTradeInItems().stream().forEach( tradeInItem -> {
				if(tradeInItem != null && StringUtilities.isNotEmptyOrNull(tradeInItem.getLineSeqNum()) && tradeInItem.getRecycleDeviceOffer() != null
						&& lineSeqNo != null && tradeInItem.getLineSeqNum().equalsIgnoreCase(lineSeqNo.toString())){
					mapStandaloneTradeInPromoInVzdlTargetOffer(tradeInItem,promoIds,flowType,promoToOfferIdMap);
				}
			});
		}
	}

	private	void mapStandaloneTradeInPromoInVzdlTargetOffer(TradeInItem tradeInItem , StringBuilder promoIds, String flowType,Map<String,String> promoToOfferIdMap){
		if (tradeInItem != null && tradeInItem.getRecycleDeviceOffer() != null && StringUtilities.isNotEmptyOrNull(tradeInItem.getRecycleDeviceOffer().getOfferId())
				&& !(promoIds.toString().contains(tradeInItem.getRecycleDeviceOffer().getOfferId()))) {
			String promotionId = promoToOfferIdMap.get(tradeInItem.getRecycleDeviceOffer().getOfferId());
			if(StringUtils.isNotBlank(promotionId)) {
				if (StringUtilities.isNotEmptyOrNull(flowType)) {
					promoIds.append(CartConstants.PROMOTYPE_TRADEIN).append("-").append(promotionId).append("-").append(CartConstants.NATIONAL_OFFER).append("-").append(CartConstants.IS_BAU_OFFER).append("-").append(flowType).append("-").append(tradeInItem.getRecycleDeviceOffer().getOfferId()).append("|");
				} else {
					promoIds.append(CartConstants.PROMOTYPE_TRADEIN).append("-").append(promotionId).append("-").append(CartConstants.NATIONAL_OFFER).append("-").append(CartConstants.IS_BAU_OFFER).append("-").append(tradeInItem.getRecycleDeviceOffer().getOfferId()).append("|");
				}
			}else{
				if (StringUtilities.isNotEmptyOrNull(flowType)) {
					promoIds.append(CartConstants.PROMOTYPE_TRADEIN).append("-").append(CartConstants.NATIONAL_OFFER).append("-").append(CartConstants.IS_BAU_OFFER).append("-").append(flowType).append("-").append(tradeInItem.getRecycleDeviceOffer().getOfferId()).append("|");
				} else {
					promoIds.append(CartConstants.PROMOTYPE_TRADEIN).append("-").append(CartConstants.NATIONAL_OFFER).append("-").append(CartConstants.IS_BAU_OFFER).append("-").append(tradeInItem.getRecycleDeviceOffer().getOfferId()).append("|");
				}
			}
		}
	}

	private void setTradeinPromoInVzdlTargetOfferForVC(TradeInDetail tradeInDetail, PromoHubOffer promohuboffer, StringBuilder promoIds, String flowType) {
		if(promohuboffer != null) {
			String offerType = getStrategicOrNationalOffer(null, null, null, promohuboffer);
			boolean isTradeOfferPresent = isTradeInOfferPresentVC(tradeInDetail);
			StringBuilder sedOfferId = getTradeInSedOfferIdVC(tradeInDetail);
			String promoType = (StringUtilities.isNotEmptyOrNull(promohuboffer.getPromoType())) ? promohuboffer.getPromoType() : "";
			String strSedOfferId = (StringUtilities.isNotEmptyOrNull(sedOfferId.toString()) && StringUtilities.isNotEmptyOrNull(promohuboffer.getOfferId()) && sedOfferId.toString().contains(promohuboffer.getOfferId())) ? promohuboffer.getOfferId() : "";
			String promotionId = (StringUtilities.isNotEmptyOrNull(promohuboffer.getPromotionId())) ? promohuboffer.getPromotionId() : "";
			if (isTradeOfferPresent && StringUtilities.isNotEmptyOrNull(promoType) && CartConstants.PROMOTYPE_TRADEIN.equalsIgnoreCase(promoType)
					&& StringUtilities.isNotEmptyOrNull(strSedOfferId) && CollectionUtilities.isEmptyOrNull(promohuboffer.getPromoBadges())) {
				mapPromos(promoType, promotionId, strSedOfferId, offerType, flowType, promoIds,false);
			}
		}
	}

	private String getStrategicOrNationalOffer(onevz.soe.cart.gql.schema.bundlebuildercartlightweight.PromoHubOffer tradeInOffer, PosCartSEDOfferType sedOffer,
											SbdOffer sbdOffer, PromoHubOffer promoHubOfferVC){
		if((tradeInOffer != null && tradeInOffer.getIsStrategicOffer() != null && tradeInOffer.getIsStrategicOffer()) ||
				(sedOffer != null && sedOffer.getIsStrategicOffer() != null && sedOffer.getIsStrategicOffer()) ||
				(sbdOffer != null && sbdOffer.getIsStrategicOffer() != null && sbdOffer.getIsStrategicOffer()) ||
				(promoHubOfferVC != null && promoHubOfferVC.getIsStrategicOffer() != null && promoHubOfferVC.getIsStrategicOffer())){
			return CartConstants.STRATEGIC_OFFER;
		}
		return CartConstants.NATIONAL_OFFER;
	}

	private void setSedOfferInfoInVzdlTargetOffer(PosSEDOfferListType  sedOffers, StringBuilder promoIds, String flowType) {
		if (sedOffers != null && sedOffers.getSedOffer() != null && CollectionUtilities.isNotEmptyOrNull(sedOffers.getSedOffer())) {
			sedOffers.getSedOffer().stream().forEach(sedOffer ->
				mapSedOfferInfoInVzdlTargetOffer(sedOffer, promoIds, flowType));
		}
	}

	private void mapSedOfferInfoInVzdlTargetOffer(PosCartSEDOfferType sedOffer, StringBuilder promoIds, String flowType) {
		if(sedOffer != null) {
			String offerType = getStrategicOrNationalOffer(null, sedOffer, null, null);
			String promoType = getPromoTypeForSedOfferInfoMapping(sedOffer);
			String promotionId = getPromotionIdForSedOfferInfoMapping(sedOffer);
			String sedOfferId = StringUtilities.isNotEmptyOrNull(sedOffer.getOfferId()) ? sedOffer.getOfferId() : "";
			Boolean isChoiceOffer = getChoiceOfferForSedOffer(sedOffer);
			if ("Y".equalsIgnoreCase(sedOffer.getAccessoryBMSM()) && !promoIds.toString().contains(CartConstants.ACC_BMSM)) {
				mapPromos(CartConstants.ACC_BMSM,promotionId,sedOfferId,offerType,flowType,promoIds,isChoiceOffer);
			}else if(StringUtilities.isNotEmptyOrNull(promoType)){
				mapPromos(promoType,promotionId,sedOfferId,offerType,flowType,promoIds,isChoiceOffer);
			}
		}
	}

	private Boolean getChoiceOfferForSedOffer(PosCartSEDOfferType sedOffer){
		if(CollectionUtilities.isNotEmptyOrNull(sedOffer.getPromoBadges()) && sedOffer.getPromoBadges().get(0) != null) {
			return sedOffer.getPromoBadges().get(0).getChoiceOffer();
		}
        return Boolean.FALSE;
	}

	private	String getPromoTypeForSedOfferInfoMapping(PosCartSEDOfferType sedOffer){
		if(CollectionUtilities.isNotEmptyOrNull(sedOffer.getPromoBadges()) && sedOffer.getPromoBadges().get(0) != null && StringUtilities.isNotEmptyOrNull(sedOffer.getPromoBadges().get(0).getOfferType())) {
			return sedOffer.getPromoBadges().get(0).getOfferType();
		} else if (StringUtilities.isNotEmptyOrNull(sedOffer.getOfferType())) {
			return sedOffer.getOfferType();
		}
		return "";
	}

	private	String getPromotionIdForSedOfferInfoMapping(PosCartSEDOfferType sedOffer){
		if(CollectionUtilities.isNotEmptyOrNull(sedOffer.getPromoBadges()) && sedOffer.getPromoBadges().get(0) != null && StringUtilities.isNotEmptyOrNull(sedOffer.getPromoBadges().get(0).getPromotionId())) {
			return sedOffer.getPromoBadges().get(0).getPromotionId();
		}
		return "";
	}

	private void setRebateOfferInfoInVzdlTargetOffer(RebateOffer rebateOffer, StringBuilder promoIds, String flowType) {
		if(rebateOffer != null) {
			String offerType = CartConstants.NATIONAL_OFFER;
			String promoType = getPromoTypeForRebateOfferMapping(rebateOffer);
			String promotionId = getPromotionIdForRebateOfferMapping(rebateOffer);
			Boolean isChoiceOffer = getChoiceOfferForRebateOffer(rebateOffer);
			String sedOfferId = (StringUtilities.isNotEmptyOrNull(rebateOffer.getPropositionId())) ? rebateOffer.getPropositionId() : "";
			if(StringUtilities.isNotEmptyOrNull(promoType)){
				mapPromos(promoType,promotionId,sedOfferId,offerType,flowType,promoIds,isChoiceOffer);
			}
		}
	}

	private Boolean getChoiceOfferForRebateOffer(RebateOffer rebateOffer){
		if(CollectionUtilities.isNotEmptyOrNull(rebateOffer.getPromoBadges()) && rebateOffer.getPromoBadges().get(0) != null) {
			return rebateOffer.getPromoBadges().get(0).getChoiceOffer();
		}
        return Boolean.FALSE;
	}


	private	String getPromoTypeForRebateOfferMapping(RebateOffer rebateOffer){
		if(CollectionUtilities.isNotEmptyOrNull(rebateOffer.getPromoBadges()) && rebateOffer.getPromoBadges().get(0) != null && StringUtilities.isNotEmptyOrNull(rebateOffer.getPromoBadges().get(0).getOfferType())) {
			return rebateOffer.getPromoBadges().get(0).getOfferType();
		}
		return CartConstants.REBATE_OFFER;
	}

	private	String getPromotionIdForRebateOfferMapping(RebateOffer rebateOffer){
		if(CollectionUtilities.isNotEmptyOrNull(rebateOffer.getPromoBadges()) && rebateOffer.getPromoBadges().get(0) != null && StringUtilities.isNotEmptyOrNull(rebateOffer.getPromoBadges().get(0).getPromotionId())) {
			return rebateOffer.getPromoBadges().get(0).getPromotionId();
		}
		return "";
	}

	private void setSbdOfferInfoInVzdlTargetOffer(SbdOffer sbdOffer, StringBuilder promoIds, String flowType) {
		if(sbdOffer != null) {
			String offerType = getStrategicOrNationalOffer(null, null, sbdOffer, null);
			String promoType =  getPromoTypeForSbdOfferInfoMapping(sbdOffer);
			String promotionId = getPromotionIdForSbdOfferInfoMapping(sbdOffer);
			Boolean isChoiceOffer = getChoiceOfferForSbdOffer(sbdOffer);
			String sedOfferId = (StringUtilities.isNotEmptyOrNull(sbdOffer.getOfferId())) ? sbdOffer.getOfferId() : "";
			if(StringUtilities.isNotEmptyOrNull(promoType)){
				mapPromos(promoType,promotionId,sedOfferId,offerType,flowType,promoIds,isChoiceOffer);
			}
		}
	}

	private Boolean getChoiceOfferForSbdOffer(SbdOffer sbdOffer){
		if(CollectionUtilities.isNotEmptyOrNull(sbdOffer.getPromoBadges()) && sbdOffer.getPromoBadges().get(0) != null) {
			return sbdOffer.getPromoBadges().get(0).getChoiceOffer();
		}
        return Boolean.FALSE;
	}
	private	String getPromoTypeForSbdOfferInfoMapping(SbdOffer sbdOffer){
		if(CollectionUtilities.isNotEmptyOrNull(sbdOffer.getPromoBadges()) && sbdOffer.getPromoBadges().get(0) != null && StringUtilities.isNotEmptyOrNull(sbdOffer.getPromoBadges().get(0).getOfferType())) {
			return sbdOffer.getPromoBadges().get(0).getOfferType();
		} else if (StringUtilities.isNotEmptyOrNull(sbdOffer.getPromoType())){
			return sbdOffer.getPromoType();
		}
		return "";
	}
	private	String getPromotionIdForSbdOfferInfoMapping(SbdOffer sbdOffer){
		if(CollectionUtilities.isNotEmptyOrNull(sbdOffer.getPromoBadges()) && sbdOffer.getPromoBadges().get(0) != null && StringUtilities.isNotEmptyOrNull(sbdOffer.getPromoBadges().get(0).getPromotionId())) {
			return sbdOffer.getPromoBadges().get(0).getPromotionId();
		}
		return "";
	}
	private void setTradeinPromoInVzdlTargetOffer(onevz.soe.cart.model.bundleBuilderCart.TradeInDetail tradeInDetail, onevz.soe.cart.gql.schema.bundlebuildercartlightweight.PromoHubOffer promohuboffer, StringBuilder promoIds, String flowType) {
		if(promohuboffer != null) {
			String offerType = getStrategicOrNationalOffer(promohuboffer, null, null, null);
			boolean isTradeOfferPresent = isTradeInOfferPresent(tradeInDetail);
			StringBuilder sedOfferId = getTradeInSedOfferId(tradeInDetail);
			String promoType = (StringUtilities.isNotEmptyOrNull(promohuboffer.getPromoType())) ? promohuboffer.getPromoType() : "";
			String strSedOfferId = (StringUtilities.isNotEmptyOrNull(sedOfferId.toString()) && StringUtilities.isNotEmptyOrNull(promohuboffer.getOfferId()) && sedOfferId.toString().contains(promohuboffer.getOfferId())) ? promohuboffer.getOfferId() : "";
			String promotionId = (StringUtilities.isNotEmptyOrNull(promohuboffer.getPromotionId())) ? promohuboffer.getPromotionId() : "";
			if (isTradeOfferPresent && StringUtilities.isNotEmptyOrNull(promoType) && CartConstants.PROMOTYPE_TRADEIN.equalsIgnoreCase(promoType)
					&& StringUtilities.isNotEmptyOrNull(strSedOfferId) && CollectionUtilities.isEmptyOrNull(promohuboffer.getPromoBadges())) {
				mapPromos(promoType, promotionId, strSedOfferId, offerType, flowType, promoIds,false);
			}
		}
	}
	private boolean isTradeInOfferPresentVC(TradeInDetail tradeInDetail) {
		return (tradeInDetail != null && tradeInDetail.getTradeInItems() != null && CollectionUtilities.isNotEmptyOrNull(tradeInDetail.getTradeInItems()) &&
				tradeInDetail.getTradeInItems().get(0) != null && tradeInDetail.getTradeInItems().get(0).getRecycleDeviceOffer() != null);
	}

	private boolean isTradeInOfferPresent(onevz.soe.cart.model.bundleBuilderCart.TradeInDetail tradeInDetail) {
		 return (tradeInDetail != null && tradeInDetail.getTradeInItems() != null && CollectionUtilities.isNotEmptyOrNull(tradeInDetail.getTradeInItems()) &&
				tradeInDetail.getTradeInItems().get(0) != null && tradeInDetail.getTradeInItems().get(0).getRecycleDeviceOffer() != null);
	}
	private StringBuilder getTradeInSedOfferId(onevz.soe.cart.model.bundleBuilderCart.TradeInDetail tradeInDetail) {
		StringBuilder sedOfferIds = new StringBuilder();
		if (tradeInDetail != null && tradeInDetail.getTradeInItems() != null && CollectionUtilities.isNotEmptyOrNull(tradeInDetail.getTradeInItems())) {
			tradeInDetail.getTradeInItems().stream().forEach(tradeInItem -> {
				if (tradeInItem.getRecycleDeviceOffer() != null && StringUtilities.isNotEmptyOrNull(tradeInItem.getRecycleDeviceOffer().getOfferId()))
					sedOfferIds.append(tradeInItem.getRecycleDeviceOffer().getOfferId()).append("|");
			});
		}
		return sedOfferIds;
	}
	private StringBuilder getTradeInSedOfferIdVC(TradeInDetail tradeInDetail) {
		StringBuilder sedOfferIds = new StringBuilder();
		if (tradeInDetail != null && tradeInDetail.getTradeInItems() != null && CollectionUtilities.isNotEmptyOrNull(tradeInDetail.getTradeInItems())) {
			tradeInDetail.getTradeInItems().stream().forEach(tradeInItem -> {
				if (tradeInItem.getRecycleDeviceOffer() != null && StringUtilities.isNotEmptyOrNull(tradeInItem.getRecycleDeviceOffer().getOfferId()))
					sedOfferIds.append(tradeInItem.getRecycleDeviceOffer().getOfferId()).append("|");
			});
		}
		return sedOfferIds;
	}

	private void setStandaloneTradeInPromoInVzdlTargetOfferPBB(onevz.soe.cart.model.bundleBuilderCart.TradeInDetail tradeInDetail , StringBuilder promoIds, String flowType, Integer lineSeqNo) {
		if (promoIds != null && tradeInDetail != null && CollectionUtilities.isNotEmptyOrNull(tradeInDetail.getTradeInItems())) {
			tradeInDetail.getTradeInItems().stream().forEach( tradeInItem -> {
				if(tradeInItem != null && StringUtilities.isNotEmptyOrNull(tradeInItem.getLineSeqNum()) && tradeInItem.getRecycleDeviceOffer() != null
						&& lineSeqNo != null && tradeInItem.getLineSeqNum().equalsIgnoreCase(lineSeqNo.toString())){
					mapStandaloneTradeInPromoInVzdlTargetOfferPBB(tradeInItem,promoIds,flowType);
				}
			});
		}
	}
	private	void mapStandaloneTradeInPromoInVzdlTargetOfferPBB(onevz.soe.cart.model.bundleBuilderCart.TradeInItem tradeInItem , StringBuilder promoIds, String flowType){
		if (tradeInItem != null && tradeInItem.getRecycleDeviceOffer() != null && StringUtilities.isNotEmptyOrNull(tradeInItem.getRecycleDeviceOffer().getOfferId())
				&& !(promoIds.toString().contains(tradeInItem.getRecycleDeviceOffer().getOfferId()))) {
			if(StringUtilities.isNotEmptyOrNull(flowType)){
				promoIds.append(CartConstants.PROMOTYPE_TRADEIN).append("-").append(CartConstants.NATIONAL_OFFER).append("-").append(CartConstants.IS_BAU_OFFER).append("-").append(flowType).append("-").append(tradeInItem.getRecycleDeviceOffer().getOfferId()).append("|");
			} else {
				promoIds.append(CartConstants.PROMOTYPE_TRADEIN).append("-").append(CartConstants.NATIONAL_OFFER).append("-").append(CartConstants.IS_BAU_OFFER).append("-").append(tradeInItem.getRecycleDeviceOffer().getOfferId()).append("|");
			}
		}
	}
	//PRODDEF-17200 - Adding Fix for numOfLines based on validateCart Response
	private void buildValidateCartTxnValues(Map<String, String> txnValues,ValidateCartCXPResponse response) {
		if (response.getData() != null && response.getData().getValidateCartAndUpdate() != null
				&& response.getData().getValidateCartAndUpdate().getLineDetails() != null
				&& response.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo() != null
				&& response.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo().length > 0)
			{
				CXPLineDetailsVO lineDetails = response.getData().getValidateCartAndUpdate().getLineDetails();
				if(( lineDetails!= null)&&(lineDetails.getNumOfLines()!=null))
				{
					txnValues.put("numberOfLines",String.valueOf(lineDetails.getNumOfLines()));
				}
			}
			else{
				txnValues.put("numberOfLines","0");
			    }
	}
	public void updateEventDataForVzDL() {
		OmniDLData eventDLData = new OmniDLData();
		Map<String, Object> customData = new HashMap<String, Object>();
		Map<String, String> event = new HashMap<>();
		updateEventDataForVzDL(event);
		customData.put("event", event);
		eventDLData.setCustomData(customData);
		super.dlData = eventDLData;
	}

	/**
	 * Updated eVar18 logic for expresscart to orderconfirmation page
	 *
	 * @param pageValues
	 * @param response
	 */
	private void buildRetrieveCartPageValues(Map<String, String> pageValues, RetrieveCartCXPResponse response) {
		if (response.getData() != null && response.getData().getCart() != null
				&& response.getData().getCart().getLineDetails() != null
				&& response.getData().getCart().getLineDetails().getLineInfo() != null
				&& response.getData().getCart().getLineDetails().getLineInfo().length > 0) {
			AtomicReference<String> orderTypeValue = new AtomicReference<>(StringUtils.EMPTY);
			Set<String> orderTypeSet = new HashSet<>();
			CXPLineInfo[] lineInfoItems = response.getData().getCart().getLineDetails().getLineInfo();
			for(CXPLineInfo cartLineInfo:lineInfoItems) {
				setOrderTypeForRetrieveCartDL(cartLineInfo, orderTypeSet);
			}
			// Setting order flow
			orderTypeSet.stream().filter(f -> !CartConstants.FEA.equalsIgnoreCase(f)).forEach(orderType -> {

				if (StringUtils.isNotBlank(orderTypeValue.get()))
					orderTypeValue.set(orderTypeValue.get() + CartConstants.PLUS + orderType);
				else
					orderTypeValue.set(orderType);
			});
			//PRODDEF-34127 NEXT_GEN|AAL+Trade-in evar18 Trade-in details not coming in evar from expresscart to orderconfirmation page
			if (null!=response.getData().getCart().getLineDetails().getTradeInDetail()
					&& CollectionUtilities.isNotEmptyOrNull(response.getData().getCart().getLineDetails()
					.getTradeInDetail().getTradeInItems())) {
				if(StringUtils.isBlank(orderTypeValue.get()))
				{
					orderTypeValue.set(CartConstants.TRADE_IN);
				}
				else if(!orderTypeValue.get().toLowerCase().contains(TRADE_IN.toLowerCase()))
				{
					orderTypeValue.set(orderTypeValue.get() + CartConstants.PLUS + (CartConstants.TRADE_IN));
				}
			}
			// Setting NAO if accessory added for line
			boolean isAccPresent = Arrays.stream(lineInfoItems)
					.filter(lineInfo -> Optional.ofNullable(lineInfo.getItemsInfo()).isPresent())
					.map(lineInfo -> lineInfo.getItemsInfo())
					.flatMap(Stream::of)
					.filter(itemInfoObj -> Optional.ofNullable(itemInfoObj.getCartItems()).isPresent() && Optional.ofNullable(itemInfoObj.getCartItems().getCartItem()).isPresent())
					.map(itemInfoObj -> itemInfoObj.getCartItems().getCartItem())
					.flatMap(Stream::of)
					.anyMatch(cartItem -> CartConstants.ACCESSORY.equalsIgnoreCase(cartItem.getCartItemType()));

			if (isAccPresent) {
				if(StringUtils.isBlank(orderTypeValue.get()))
				{
					orderTypeValue.set(NAO);
				}
				else if(!orderTypeValue.get().toLowerCase().contains(NAO.toLowerCase()))
				{
					orderTypeValue.set(orderTypeValue.get() + CartConstants.PLUS + (NAO));
				}
			}
			if(StringUtilities.isNotEmptyOrNull(orderTypeValue.toString())) {
				pageValues.put(CartConstants.FLOW, orderTypeValue.get());
			}
		}
	}

	/**
	 * Update ordertype for retrieve-cart api
	 *
	 * @param cxpLineInfo
	 * @param orderTypeSet
	 * @return
	 */
	private Set<String> setOrderTypeForRetrieveCartDL(CXPLineInfo cxpLineInfo, Set<String> orderTypeSet) {
		if(Objects.nonNull(cxpLineInfo)) {
			String orderType = evaluteFlowType(null, cxpLineInfo);
			if(StringUtilities.isNotEmptyOrNull(orderType))
				orderTypeSet.add(orderType.toLowerCase());
		}
		return orderTypeSet;
	}
}
