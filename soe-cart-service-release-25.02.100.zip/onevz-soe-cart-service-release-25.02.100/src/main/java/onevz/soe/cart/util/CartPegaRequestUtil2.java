package onevz.soe.cart.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.cxp.feature.Flag;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.addAccessory.AccessoryAction;
import onevz.soe.cart.model.addBuyout.AddBuyoutContext;
import onevz.soe.cart.model.addBuyout.AddBuyoutServiceBody;
import onevz.soe.cart.model.addBuyout.AddBuyoutServiceRequest;
import onevz.soe.cart.model.addDownPayment.AddDownPaymentContext;
import onevz.soe.cart.model.addDownPayment.DownPaymentServiceBody;
import onevz.soe.cart.model.addDownPayment.DownPaymentServiceRequest;
import onevz.soe.cart.model.addPlan.AddPlanContext;
import onevz.soe.cart.model.addPlan.AddPlanServiceBody;
import onevz.soe.cart.model.addPlan.AddPlanServiceRequest;
import onevz.soe.cart.model.addPromoIntent.AddPromoIntent;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.edgeup.UpdateEdgeupContext;
import onevz.soe.cart.model.edgeup.UpdateEdgeupServiceBody;
import onevz.soe.cart.model.edgeup.UpdateEdgeupServiceRequest;
import onevz.soe.cart.model.initiateCheckout.InitiateCheckoutContext;
import onevz.soe.cart.model.initiateCheckout.InitiateCheckoutServiceBody;
import onevz.soe.cart.model.initiateCheckout.InitiateCheckoutServiceRequest;
import onevz.soe.cart.model.pastDues.PastDuesContext;
import onevz.soe.cart.model.pastDues.PastDuesServiceBody;
import onevz.soe.cart.model.pastDues.PastDuesServiceRequest;
import onevz.soe.cart.model.removeLines.RemoveLinesContext;
import onevz.soe.cart.model.removeLines.RemoveLinesServiceBody;
import onevz.soe.cart.model.removeLines.RemoveLinesServiceRequest;
import onevz.soe.cart.requests.*;
import onevz.soe.cart.ui.common.CartInfo;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.spring.web.filter.RequestAccessContext;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import java.util.*;
import static onevz.soe.cart.constants.CartConstants.OPP_NEXTGEN_CONFIGURATOR_PAGE;
public class CartPegaRequestUtil2 {

    private static final Logger logger = LoggerFactory.getLogger(CartPegaRequestUtil2.class);

    @Value("${enableCradleForProspect:true}")
    private static boolean enableCradleForProspect;

    @Value("${enableCradleForExistingCustomer:true}")
    private static boolean enableCradleForExistingCustomer;
    /**
     * @param pegaRequest
     * @param request
     * @return UpdateEdgeupPEGARequest
     */
    public static UpdateEdgeupPEGARequest formatRemoveEdgeUpRequest(UpdateEdgeupPEGARequest pegaRequest,
                                                                    UpdateEdgeupUIRequest request) {

        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(request.getChannelId());
        pegaRequest.setServiceHeader(serviceHeader);

        UpdateEdgeupServiceBody serviceBody = new UpdateEdgeupServiceBody();
        UpdateEdgeupServiceRequest serviceRequest = new UpdateEdgeupServiceRequest();
        UpdateEdgeupContext context = new UpdateEdgeupContext();

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
        customerInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());

        context.setCustomerInfo(customerInfo);

        CartServiceCartInfo cartServiceCartInfo = new CartServiceCartInfo();
        cartServiceCartInfo.setCartId(request.getCartInfo().getCartId());
        cartServiceCartInfo.setAction(CartConstants.REMOVE);
        cartServiceCartInfo.setItemType("EDGEUP");
        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType()))
            cartServiceCartInfo.setIntendType(request.getCartInfo().getIntendType());
        else
            cartServiceCartInfo.setIntendType(CartConstants.EUP);
        List<Line> linesObj = new ArrayList<>();
        for (Lines reqLine : request.getData().getLines()) {
            Line newLine = new Line();
            newLine.setMtn(reqLine.getMtn());
            linesObj.add(newLine);
        }
        Line[] lineArr = new Line[linesObj.size()];
        linesObj.toArray(lineArr);

        cartServiceCartInfo.setLines(lineArr);

        context.setCaseId(request.getCartInfo().getCaseId());
        context.setCartInfo(cartServiceCartInfo);

        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.CANCEL_EDGE_UP,
                request.getCartInfo().getClientAppName());
        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessStep())) {
            contextInfo.setProcessStep(request.getCartInfo().getProcessStep());
        } else {
            contextInfo.setProcessStep(CartConstants.MTN_SELECTION_PAGE);
        }
        context.setContextInfo(contextInfo);

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);
        return pegaRequest;
    }

    /**
     * @param pegaRequest
     * @param request
     * @return AddPlanPEGARequest
     */
    public static AddPlanPEGARequest formatAddPlanRequest(AddPlanPEGARequest pegaRequest, AddPlanUIRequest request, Boolean enableWHWSPOMode, Boolean isFwaChoiceOfferFeatureFlag, Flag preToPostActivationFeeFFlag,  boolean isOppConfiguratorFlag) {
        CartServiceServiceHeader serviceHeader = CartPegaRequestUtil.addServiceHeader(new CartServiceServiceHeader());
        serviceHeader.setClientId(request.getChannelId());
        logger.info("Before serviceHeader SalesOrderAdjustment");

        Optional.ofNullable(request.getCartInfo()).ifPresent(cartInfo -> {
            // Handle IntendType logic
            Optional.ofNullable(cartInfo.getIntendType())
                    .filter(StringUtilities::isNotEmptyOrNull)
                    .filter(intendType -> CartConstants.CLNR_FLOW.equalsIgnoreCase(intendType) || CartConstants.REFUND_EXCHANGE.equalsIgnoreCase(intendType))
                    .ifPresent(intendType -> {
                        logger.info(String.format("Inside set serviceHeader.setServiceName - {}" , intendType));
                        serviceHeader.setServiceName("SalesOrderAdjustment");
                    });

            // Handle LineActivityType logic
            Optional.ofNullable(cartInfo.getLineActivityType())
                    .filter(StringUtilities::isNotEmptyOrNull)
                    .filter(lineActivityType -> lineActivityType.equalsIgnoreCase("TSE"))
                    .ifPresent(lineActivityType -> serviceHeader.setServiceName("TYSUpdate"));
        });

        pegaRequest.setServiceHeader(serviceHeader);

        AddPlanServiceBody serviceBody = new AddPlanServiceBody();
        AddPlanServiceRequest serviceRequest = new AddPlanServiceRequest();
        AddPlanContext context = new AddPlanContext();
        CartInfo requestCartInfo = request.getCartInfo();
        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();

        //set CustomerInfo Data in Request
        customerInfo = setCustomerInfoData(customerInfo, requestCartInfo);

        boolean isExpressCheckout = Boolean.TRUE.equals(request.getCartInfo().getExpressCheckout());
        boolean isEditPlanClick = Boolean.TRUE.equals(request.getCartInfo().getEditPlanClick());
        boolean isPromoHubJourney = Boolean.TRUE.equals(request.getCartInfo().getPromoHubJourney());
        String intendType = request.getCartInfo().getIntendType();

        if ((isExpressCheckout && isEditPlanClick) || isPromoHubJourney) {
            if (CartConstants.NSE.equalsIgnoreCase(intendType) || CartConstants.NSE_BYOD.equalsIgnoreCase(intendType)) {
                if (enableCradleForProspect) {
                    customerInfo.setCradleFlowJourney(CartConstants.ACCESSORIES_INTERSTIAL_PROSPECT);
                }
            } else {
                if (enableCradleForExistingCustomer) {
                    customerInfo.setCradleFlowJourney(CartConstants.PROMO_HUB);
                }
            }
        }

        Optional.ofNullable(request.getCartInfo().getMtnFlow())
                .ifPresent(customerInfo::setMtnFlow);

        //set CartInfo Data in Request
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        setCartInfoData(cartInfo, request, intendType);

        CartServiceContextInfo contextInfo = new CartServiceContextInfo();

        if(request != null && request.getCartInfo() != null && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getClientAppName()) && CartConstants.CHANNEL_ID_BBP.equalsIgnoreCase(request.getCartInfo().getClientAppName())){
            //add condition to check if request is not null and cartinfo is not null and clientname is not null and unifiedflag is not null
                  contextInfo.setUnifiedNbsFlag(request.isUnifiedNbsFlag());

        }


        if (Optional.ofNullable(request)
                .map(AddPlanUIRequest::getCartInfo)
                .map(CartInfo::getLineActivityType)
                .filter(lineActivityTy -> lineActivityTy.equalsIgnoreCase("TSE"))
                .isPresent()) {
            contextInfo = addContextInfoPlanTYS(contextInfo);
            Optional.ofNullable(request.getCartInfo().getAccountNumber())
                    .ifPresent(customerInfo::setAccountNumber);
            Optional.ofNullable(request.getCartInfo().getCartCreator())
                    .ifPresent(customerInfo::setMtn);
            Optional.ofNullable(request.getCustomerId())
                    .ifPresent(customerInfo::setCustomerId);
            Optional.ofNullable(request.getCartInfo().getUserRole())
                    .ifPresent(customerInfo::setUserRole);
        } else if (isOppConfiguratorFlag &&
                StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessStep()) &&
                OPP_NEXTGEN_CONFIGURATOR_PAGE.equalsIgnoreCase(request.getCartInfo().getProcessStep())) {
            CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.ADD_PLAN_AND_FEATURE, request.getCartInfo().getClientAppName());
        } else {
            CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.ADD_PLAN, request.getCartInfo().getClientAppName());
        }

        addQuickShopPegaRequestFlag(request, cartInfo, contextInfo);

        if (CartConstants.CHANNEL_ID_BBP.equalsIgnoreCase(request.getCartInfo().getClientAppName())) {
            String intent = Optional.ofNullable(request.getCartInfo().getIntent())
                    .filter(CartConstants.INLINE_CPC::equalsIgnoreCase)
                    .orElse(CartConstants.BYOD);
            contextInfo.setIntent(intent);
        } else if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()) &&
                (CartConstants.CLNR_FLOW.equalsIgnoreCase(request.getCartInfo().getIntendType()) ||
                        CartConstants.REFUND_EXCHANGE.equalsIgnoreCase(request.getCartInfo().getIntendType()))) {
            contextInfo.setCallReason("SalesOrderAdjustment");
            String intent = CartConstants.REFUND_EXCHANGE.equalsIgnoreCase(request.getCartInfo().getIntendType())
                    ? CartConstants.REFUND_EXCHANGE
                    : CartConstants.CLNR_FLOW;
            logger.info("inside setIntent in contextInfo");
            contextInfo.setIntent(intent);
            contextInfo.setProcessAction("addPlan");
        } else {
            contextInfo.setIntent(CartConstants.INLINE_CPC);
        }

        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessStep())) {
            contextInfo.setProcessStep(request.getCartInfo().getProcessStep());
        }else {
            contextInfo.setProcessStep(CartConstants.SHOPPING_CART);
        }

        if (request.getData().getLines() != null && request.getData().getLines().length == 0
                && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessStep())) {
            contextInfo.setProcessStep(request.getCartInfo().getProcessStep());
            contextInfo.setProcessAction(CartConstants.KEEP_PLAN);
        }

        Line[] lineArr = populateLinesFromUiToPegaObject(
                request, request.getData().getLines(), enableWHWSPOMode, isFwaChoiceOfferFeatureFlag, preToPostActivationFeeFFlag);
        cartInfo.setLines(lineArr);

        if(request.getData().isEnableFcc()) {
            setAddressInfo(request, cartInfo);
        }

        cartInfo.setEffectiveDate(
                Optional.ofNullable(request.getData().getEffectiveDate())
                        .orElse("")
        );

        cartInfo.setCheckAutoPayDiscountEligible(
                StringUtilities.isEmptyOrNull(request.getData().getCheckAutoPayDiscountEligible())
                        ? "N"
                        : request.getData().getCheckAutoPayDiscountEligible()
        );

        Optional.ofNullable(request.getCartInfo().getRpsIntent())
                .filter(StringUtilities::isNotEmptyOrNull)
                .ifPresent(contextInfo::setIntent);

        if (CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())
                || CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())
                || CartConstants.NSE_LTE.equalsIgnoreCase(request.getCartInfo().getIntendType())
                || CartConstants.NSE_5G.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
            CartPegaRequestUtil7.newCustomerOverride(contextInfo, customerInfo, request.getCartInfo(), request.getChannelId());

            if(!CartConstants.VZW_BBP.equalsIgnoreCase(request.getChannelId()))
                contextInfo.setIntent(CartConstants.INLINE_CPC);
        }
        if( CartUtil.isDigital(request.getChannelId())) {
            List<String> homeIntendTypeValues = Arrays.asList(new String[] {CartConstants.AAL_5G,CartConstants.AAL_LTE,CartConstants.NSE_5G,CartConstants.NSE_LTE,CartConstants.EUP_5G});
            if(homeIntendTypeValues.contains(request.getCartInfo().getIntendType()))
                contextInfo.setIntent(request.getCartInfo().getIntendType());
        }
        //isLGPOEligible
        if(request.getData() != null && request.getData().getIsLGPOEligible() != null)
            customerInfo.setIsLGPOEligible(request.getData().getIsLGPOEligible());
        context.setCustomerInfo(customerInfo);

        //MVP2
        if (request.getCartInfo() != null) {
            boolean isPrepayCart = "Y".equalsIgnoreCase(request.getCartInfo().getIsPrepayCart());
            boolean isSOFCase = request.getCartInfo().getCaseId() != null && request.getCartInfo().getCaseId().startsWith("SOF");
            boolean isOneClick = request.getCartInfo().getOneClick()!=null && request.getCartInfo().getOneClick();

            if (isPrepayCart || isSOFCase) {
                logger.info("SalesOrderFlex Prepay AddPlan before PEGA call setting Call Reason");
                contextInfo.setCallReason(CartConstants.SALES_ORDER_FLEX);
                serviceHeader.setServiceName(CartConstants.SALES_ORDER_FLEX);
            }

            //BVQ - 2616
            if (isSOFCase && isOneClick) {
                logger.info("CartInfo Line Prepay add Plan OneClick set to true with Case ID: {}",  request.getCartInfo().getCaseId());
                cartInfo.setOneClick(request.getCartInfo().getOneClick());
            }
        }

        if(checkReqHasOnlyLineFeatures(request.getData().getLines())){
            cartInfo.setItemType("PLANANDFEATURE");
        }

        Optional.ofNullable(request.getData().getLines())
                .filter(lines -> !requestHasPlan(lines))
                .ifPresent(lines -> {
                    cartInfo.setItemType("FEATURE");
                    cartInfo.setIntendType("FEA");
                });

        if(CartConstants.PLAN_BUILDER.equals(request.getCartInfo().getFlowType())){
            if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntent())){
                contextInfo.setIntent(request.getCartInfo().getIntent());
            }
            if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessStep())){
                contextInfo.setProcessStep(request.getCartInfo().getProcessStep());
            }
            customerInfo.setFlowType(request.getCartInfo().getFlowType());
            customerInfo.setMtnFlow(request.getCartInfo().getMtnFlow());
        }
        
        if(request.getCartInfo() != null && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLineActivityType())
                && request.getCartInfo().getLineActivityType().equalsIgnoreCase("TSE")) {
            cartInfo.setItemType("TRANSFER-SERVICE");
            cartInfo.setIntendType("TSE");
        }
        
        if(request.getCartInfo() != null && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLineActivityType())
                && request.getCartInfo().getLineActivityType().equalsIgnoreCase("TSE")) {
            contextInfo.setProcessStep(CartConstants.PLAN_SELECTION);
            contextInfo.setIntent(CartConstants.TYS_ASSUMER);
            context.setCartData(cartInfo);
        }else {
            context.setCartInfo(cartInfo);
        }
        // Changes to update callreason, flow type, service name for Customer trial flow
        if(CartPegaRequestUtil.isTrialCustomerFlow(request.getCartInfo().getFlowType())) {
        	pegaRequest.getServiceHeader().setServiceName(CartConstants.SERVICE_NAME_TRIAL);
        	context.getCustomerInfo().setFlowType(CartConstants.FLOW_TYPE_DVM);
        	contextInfo.setCallReason(CartConstants.TRIAL_CALLREASON);
        }
        context.setContextInfo(contextInfo);

        context.setCaseId(request.getCartInfo().getCaseId());

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);
        logger.info("Pega add plan request with unifiednbs flag: "+pegaRequest.toString());
logger.info("Pega request contextinfo: " +pegaRequest.getServiceBody().getServiceRequest().getContext().getContextInfo().toString());


        return pegaRequest;

    }

    /**
     * Method to set the address info to the pega request for NSE customer
     *
     * @param request
     * @param cartInfo
     */
    private static void setAddressInfo(AddPlanUIRequest request, CartServiceCartInfo cartInfo) {
        if (request.getCartInfo() !=null && (CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())
                || CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType()))) {

            Address address = new Address();

            if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getAddressLine1())) {
                address.setAddressLine1(request.getCartInfo().getAddressLine1());
            }
            if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCity())) {
                address.setCity(request.getCartInfo().getCity());
            }
            if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getState())) {
                address.setState(request.getCartInfo().getState());
            }

            if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getZipCode())) {
                address.setZipCode(request.getCartInfo().getZipCode());
            }

            if (cartInfo.getLines() !=null && cartInfo.getLines().length > 0 && CartCxpRequestUtil.validateEmptyAddress(address)) {
                cartInfo.getLines()[0].setAddress(address);
            }
        }
    }

    private static boolean checkReqHasOnlyLineFeatures(Lines[] lines) {
        return lines != null && Arrays.asList(lines).stream().filter( line -> line !=null && ((line.getPlan() != null && StringUtilities.isEmptyOrNull(line.getPlan().getId())) || line.getPlan() == null) 
        									&&  (CollectionUtilities.isNotEmptyOrNull(line.getAddFeatures())
        									|| CollectionUtilities.isNotEmptyOrNull(line.getRemoveFeatures()))).findAny().isPresent();
    }
    private static boolean requestHasPlan(Lines[] lines) {
       return  lines != null && Arrays.asList(lines).stream().filter( line -> line !=null &&  line.getPlan() !=null
                                && StringUtilities.isNotEmptyOrNull(line.getPlan().getId())).findAny().isPresent();

    }

    private static CartServiceContextInfo addContextInfoPlanTYS (CartServiceContextInfo contextInfo) {
        contextInfo.setCallReason(CartConstants.TRANSFER_YOUR_SERVICE);
        contextInfo.setIntent(CartConstants.TYS_ASSUMER);
        contextInfo.setProcessAction(CartConstants.ADD_TO_CART);
        contextInfo.setProcessStep(CartConstants.PLAN_SELECTION);
        return contextInfo;
    }

    protected static CartServiceContextInfo addContextInfoReviewOrderTYS (CartServiceContextInfo contextInfo) {
        contextInfo.setCallReason(CartConstants.TRANSFER_YOUR_SERVICE);
        contextInfo.setIntent(CartConstants.TYS_ASSUMER);
        contextInfo.setProcessAction(CartConstants.REVIEW_ORDER);
        contextInfo.setProcessStep(CartConstants.ORDER_LANDING);
        return contextInfo;
    }

    protected static CartServiceContextInfo addContextInfoFeatureTYS(CartServiceContextInfo contextInfo, String addFeature,
                                                                   String clientAppName) {
        contextInfo.setCallReason(CartConstants.TRANSFER_YOUR_SERVICE);
        contextInfo.setIntent(CartConstants.TYS_ASSUMER);
        contextInfo.setProcessAction(CartConstants.ADD_TO_CART);
        contextInfo.setProcessStep(CartConstants.FEATURES_SELECTION_PAGE);
        return contextInfo;
    }

    public static Line[] populateLinesFromUiToPegaObject(AddPlanUIRequest request, Lines[] lines, Boolean enableWHWSPOMode, Boolean isFwaChoiceOfferFeatureFlag, Flag preToPostActivationFeeFFlag){
        String preToPostMigrationCookie = RequestAccessContext.obtainCookie(Arrays.asList(CartConstants.PREPAID_TO_POSTPAID_MIGRATION));
        List<Line> lineList = new ArrayList<>();
        List<AddPromoIntent> addPromoIntent= new ArrayList<>();

        for (Lines reqLine : lines) {
            Line newLine = new Line();
            if (reqLine.getRtdOfferId() != null)
                newLine.setRtdOfferId(reqLine.getRtdOfferId());
            if (reqLine.getRestricted() != null)
                newLine.setRestricted(reqLine.getRestricted());
            if (reqLine.getMtn() != null)
                newLine.setMtn(reqLine.getMtn());
            if(reqLine.getTrialSelected()!=null)
                newLine.setTrialSelected(reqLine.getTrialSelected());
            if(reqLine.getSubscriptionSelected()!=null)
                newLine.setSubscriptionSelected(reqLine.getSubscriptionSelected());
            if(StringUtilities.isNotEmptyOrNull(reqLine.getTrialValidityPeriod()))
                newLine.setTrialValidityPeriod(reqLine.getTrialValidityPeriod());
            if(StringUtilities.isNotEmptyOrNull(reqLine.getTrialAllowance()))
                newLine.setTrialAllowance(reqLine.getTrialAllowance());
            if (reqLine.getContractTerm() != null)
                newLine.setContractTerm(reqLine.getContractTerm());
            if (reqLine.getPlan() != null) {
                newLine.setPlan(reqLine.getPlan());
                if(null != reqLine.getPlan().getSFO()) {
                    FeatureAction features = new FeatureAction();
                    reqLine.getPlan().getSFO().forEach(action->{
                        if(action.getActionindicator().equals("A") && action.getBundlename() != null)
                            newLine.setSelectedPromoBundle(action.getBundlename().toUpperCase());
                        if(action.getActionindicator().equals("A") && action.getActionindicator()!=null && !action.getBundlename().equalsIgnoreCase(CartConstants.ENTERTAINMENT)) {
                            List<Feature> add = new ArrayList<Feature>();
                            Feature feature = new Feature();
                            feature.setQuantity(1);
                            feature.setActionIndicator(action.getActionindicator());
                            feature.setId(action.getId());
                            feature.setType(CartConstants.SPO);
                            add.add(feature);
                            features.setAdd(add);
                        }
                        else if(action.getActionindicator().equals("D") && action.getActionindicator()!=null && !action.getBundlename().equalsIgnoreCase(CartConstants.ENTERTAINMENT)) {
                            List<Feature> remove = new ArrayList<Feature>();
                            Feature removeFeatures = new Feature();
                            removeFeatures.setQuantity(1);
                            removeFeatures.setActionIndicator(action.getActionindicator());
                            removeFeatures.setId(action.getId());
                            removeFeatures.setType(CartConstants.SPO);
                            remove.add(removeFeatures);
                            features.setRemove(remove);
                        }
                        newLine.setFeatures(features);
                        newLine.getPlan().setSFO(null);
                    });
                }

                //simpliSafePromo addition
                if(CollectionUtilities.isNotEmptyOrNull(reqLine.getPlan().getPlanPromoSpo())){
                    FeatureAction features = new FeatureAction();
                    reqLine.getPlan().getPlanPromoSpo().forEach( promoSpo ->{
                        if(promoSpo !=null && promoSpo.getAction().equalsIgnoreCase(CartConstants.ADD)){
                            List<Feature> add = new ArrayList<Feature>();
                            Feature feature = new Feature();
                            feature.setQuantity(1);
                            feature.setActionIndicator("A");
                            feature.setId(promoSpo.getSpoId());
                            feature.setType(CartConstants.SPO);
                            add.add(feature);
                            features.setAdd(add);
                        } else if(promoSpo !=null && promoSpo.getAction().equalsIgnoreCase(CartConstants.REMOVE)){
                            List<Feature> removeFeatures = new ArrayList<Feature>();
                            Feature feature = new Feature();
                            feature.setQuantity(1);
                            feature.setId(promoSpo.getSpoId());
                            feature.setType(CartConstants.SPO);
                            removeFeatures.add(feature);
                            features.setRemove(removeFeatures);
                        }
                        newLine.setFeatures(features);
                    });

                }
            }
            if (reqLine.getNickName() != null)
                newLine.setNickName(reqLine.getNickName());
            if (reqLine.getPromoRejectionIndicator() != null) {
                newLine.setPromoRejectionIndicator(reqLine.getPromoRejectionIndicator());
            }
            if(StringUtilities.isNotEmptyOrNull(reqLine.getNumbersharePairingMode())){
                newLine.setNumbersharePairingMode(reqLine.getNumbersharePairingMode());
            }
            //lgpo changes - validate plan and set Marker SPO in features node
            if(request.getData() != null
                    && request.getData().getIsLGPOEligible() != null
                    && request.getData().getLgpoSpo() != null
                    && Boolean.TRUE.equals(request.getData().getIsLGPOEligible())){
                Feature lgpoMarkerSPO = updateLGPOMarkerSPO(request);
                if(lgpoMarkerSPO != null){
                    reqLine.getAddFeatures().add(lgpoMarkerSPO);
                }
            }
            if(CollectionUtilities.isNotEmptyOrNull(reqLine.getAddFeatures()) || CollectionUtilities.isNotEmptyOrNull(reqLine.getRemoveFeatures())) {
                FeatureAction featureAction = new FeatureAction();
                featureAction.setAdd(reqLine.getAddFeatures());
                featureAction.setRemove(reqLine.getRemoveFeatures());
                newLine.setFeatures(featureAction);
            }
            if(reqLine.getDeviceTypeSelected()!=null &&!reqLine.getDeviceTypeSelected().isEmpty())
                newLine.setDeviceTypeSelected(reqLine.getDeviceTypeSelected());
            if(CollectionUtilities.isNotEmptyOrNull(reqLine.getSelectedOffers()))
                newLine.setSelectedOffers(reqLine.getSelectedOffers());

            if(reqLine.getDevice()!=null) {
                newLine.setDevice(reqLine.getDevice());
            }

            if (StringUtilities.isNotEmptyOrNull(preToPostMigrationCookie) && preToPostMigrationCookie.equalsIgnoreCase("true") && preToPostActivationFeeFFlag != null && preToPostActivationFeeFFlag.isEnabled()) {
                Map<String, List<String>> attributeMap = preToPostActivationFeeFFlag.getAttributes();
                List<String> offerCode = attributeMap.get("offerCode");
                if(offerCode != null && offerCode.size() > 0) {
                    newLine.setOfferCode(offerCode.get(0));
                }
            }

            if (isFwaChoiceOfferFeatureFlag != null && isFwaChoiceOfferFeatureFlag && reqLine.getPromoIntent() != null && !reqLine.getPromoIntent().isEmpty()) {
                reqLine.getPromoIntent()
                        .stream()
                        .filter(Objects::nonNull)
                        .forEach(promo -> {
                            AddPromoIntent promoIntent = new AddPromoIntent();
                            promoIntent.setPromotionId(promo.getPromotionId());
                            promoIntent.setOfferId(promo.getOfferId());
                            promoIntent.setPromoType(promo.getPromoType());
                            promoIntent.setChoiceOffer(promo.getChoiceOffer());
                            addPromoIntent.add(promoIntent);
                        });
                AddPromoIntent[] promoArr = new AddPromoIntent[addPromoIntent.size()];
                newLine.setPromoIntent(addPromoIntent.toArray(promoArr));
            }

            //ACCEX-683 change
            if(CollectionUtilities.isNotEmptyOrNull(reqLine.getOfferInfoList())){
                newLine.setOfferInfoList(reqLine.getOfferInfoList());
            }
            if(reqLine.getSecondNumber() !=null){
                newLine.setSecondNumber(reqLine.getSecondNumber());
            }
            if(Boolean.TRUE.equals(enableWHWSPOMode)){
                AccessoryAction accessoryAction = new AccessoryAction();
                if(reqLine.getAddAccessories()!= null){
                    accessoryAction.setAdd(reqLine.getAddAccessories());
                }
                if(reqLine.getRemoveAccessories()!= null){
                    accessoryAction.setRemove(reqLine.getRemoveAccessories());
                }
                newLine.setAccessories(accessoryAction);
            }

            lineList.add(newLine);
        }
        Line[] lineArr = new Line[lineList.size()];
        lineList.toArray(lineArr);

        return lineArr;
    }

    public static boolean removeDeviceAccessoryFromCart(RemoveLinesUIRequest request) {
        String endPoint = System.getProperty(CartConstants.ENDPOINT);
        logger.info("code for removeDeviceFromCart endPoint={}, deviceAccFlag={}", endPoint, request.isDeviceAccessoryFFlag());
        if(request != null && endPoint != null && endPoint.contains(CartConstants.END_POINT_REMOVE_DEVICE_LINE) && request.isDeviceAccessoryFFlag()
                && request.getCartInfo() != null && CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
            if (request.getData() != null && request.getData().getLines()!=null && request.getData().getLines().length>0
                    && request.getData().getLines()[0].getDevice() != null && StringUtils.isNotBlank(request.getData().getLines()[0].getDevice().getId())) {
                return Boolean.TRUE;
            }
        }
        return Boolean.FALSE;
    }
    /**
     * @param pegaRequest
     * @param request
     * @return RemoveLinesPEGARequest
     */
    public static RemoveLinesPEGARequest formatRemoveLinesRequest(RemoveLinesPEGARequest pegaRequest,
                                                                  RemoveLinesUIRequest request) {
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        serviceHeader = CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(request.getChannelId());
        pegaRequest.setServiceHeader(serviceHeader);

        RemoveLinesServiceBody serviceBody = new RemoveLinesServiceBody();
        RemoveLinesServiceRequest serviceRequest = new RemoveLinesServiceRequest();
        RemoveLinesContext context = new RemoveLinesContext();
        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        contextInfo = CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.REMOVE_LINES, request.getCartInfo().getClientAppName());
        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
        customerInfo.setGlobalId(request.getCartInfo().getGlobalId());
        customerInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());
        customerInfo.setQuoteWithoutCredit(request.getCartInfo().getQuoteWithoutCredit());
        customerInfo.setAccountType(request.getCartInfo().getAccountType());
        if(null != request.getCartInfo().getRegisterNumber())
            customerInfo.setRegisterNumber(request.getCartInfo().getRegisterNumber());
        if (CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())
                || CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())
                || CartConstants.NSE_5G.equalsIgnoreCase(request.getCartInfo().getIntendType())
                || CartConstants.NSE_LTE.equalsIgnoreCase(request.getCartInfo().getIntendType())
        ) {
            CartPegaRequestUtil7.newCustomerOverride(contextInfo, customerInfo, request.getCartInfo(), request.getChannelId());

        }
        if (null != request.getCartInfo().getExpressCheckout() && request.getCartInfo().getExpressCheckout()) {
            if(CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType()) || CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())){
                if(enableCradleForProspect) {
                    customerInfo.setCradleFlowJourney(CartConstants.ACCESSORIES_INTERSTIAL_PROSPECT);
                }
                if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getMtnFlow())) {
                    customerInfo.setMtnFlow(request.getCartInfo().getMtnFlow());
                }
            }
            else {
                if(enableCradleForExistingCustomer){
                    customerInfo.setCradleFlowJourney(CartConstants.PROMO_HUB);
                }
            }
        }
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(request.getCartInfo().getCartId());
        cartInfo.setClientAppName(request.getCartInfo().getClientAppName());
        cartInfo.setAction(CartConstants.UPDATE);
        if (StringUtilities.isNotEmptyOrNull(request.getData().getByodMtn())){
            cartInfo.setByodMtn(request.getData().getByodMtn());
        }
        boolean isDeviceAccessory = removeDeviceAccessoryFromCart(request);
        logger.info("code for removeDeviceFromCart isDeviceAccessory={}", isDeviceAccessory);
        if(isDeviceAccessory) {
            cartInfo.setItemType(CartConstants.ITEM_TYPE_REMOVE_DEVICE);
        } else {
            cartInfo.setItemType(CartConstants.ITEM_TYPE_LINES);
        }
        cartInfo.setZipCode(request.getCartInfo().getZipCode());
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()))
            cartInfo.setIntendType(request.getCartInfo().getIntendType());
        else
            cartInfo.setIntendType("CPC");

        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessStep())) {
            contextInfo.setProcessStep(request.getCartInfo().getProcessStep());
        } else {
            contextInfo.setProcessStep(CartConstants.SHOPPING_CART);
        }
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessAction())) {
            contextInfo.setProcessAction(request.getCartInfo().getProcessAction());
            if (CartConstants.DELETE_ALL_ACCESSORIES.equalsIgnoreCase(request.getCartInfo().getProcessAction())) {
                contextInfo.setIntent(CartConstants.STANDALONEACCESSORY);
                if (StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType()))
                    cartInfo.setIntendType("ACC");
            } else if (CartConstants.REMOVE_DEVICE.equalsIgnoreCase(request.getCartInfo().getProcessAction())) {
                cartInfo.setItemType(CartConstants.CLEAR_ITEMS);
                cartInfo.setAction(CartConstants.REMOVE);
                if (StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType()))
                    cartInfo.setIntendType("AAL");
            }
        }
        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType())
                && ((CartConstants.NSE).equalsIgnoreCase(request.getCartInfo().getIntendType()))) {
            contextInfo.setIntent(CartConstants.NSE);
        }
        if(CartUtil.isDigital(request.getChannelId()) && CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())
                && null != request.getCartInfo().getQuickShop()) {
            contextInfo.setProcessAction(request.getCartInfo().getProcessAction());
            cartInfo.setIsQuickShopFlow(request.getCartInfo().getQuickShop());
        }
        if(CartUtil.isDigital(request.getChannelId()) && CartConstants.BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())){
            contextInfo.setIntent(request.getCartInfo().getIntendType());
        }
        //remove-lines defect fix
        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType())) {
            if((CartConstants.REX).equalsIgnoreCase(request.getCartInfo().getIntendType())) {
                contextInfo.setIntent(CartConstants.REX);
                contextInfo.setCallReason(CartConstants.SALES_ORDER_ADJUSTMENT);
                serviceHeader.setServiceName(CartConstants.SALES_ORDER_ADJUSTMENT);
                cartInfo.setIntendType(CartConstants.REX);
            }
        }


        Lines[] linesArr = request.getData().getLines();
        String[] mtnArr = new String[linesArr.length];
        for (int i = 0; i < linesArr.length; i++) {
            mtnArr[i] = linesArr[i].getMtn();
        }
        ObjectMapper mapper = new ObjectMapper();

        cartInfo.setLines(mapper.convertValue(linesArr, Line[].class));

        // DEO remove device changes
        if (CartConstants.DEO.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
            cartInfo.setItemType(CartConstants.DEVICEACC);
            cartInfo.setIntendType(request.getCartInfo().getIntendType());
            cartInfo.setAction(CartConstants.UPDATE);

            contextInfo.setIntent(CartConstants.DEO);
            contextInfo.setProcessAction(CartConstants.REMOVE_DEVICE);
        }
        if( CartUtil.isDigital(request.getChannelId())) {
            List<String> homeIntendTypeValues = Arrays.asList(new String[] {CartConstants.AAL_5G,CartConstants.AAL_LTE,CartConstants.NSE_5G,CartConstants.NSE_LTE,CartConstants.EUP_5G});
            if(homeIntendTypeValues.contains(request.getCartInfo().getIntendType()))
                contextInfo.setIntent(request.getCartInfo().getIntendType());
        }
        context.setCustomerInfo(customerInfo);

        if(CartConstants.PLAN_BUILDER.equals(request.getCartInfo().getFlowType())){
            if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntent())){
                contextInfo.setIntent(request.getCartInfo().getIntent());
            }
            if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessStep())){
                contextInfo.setProcessStep(request.getCartInfo().getProcessStep());
            }
            customerInfo.setFlowType(request.getCartInfo().getFlowType());
            customerInfo.setMtnFlow(request.getCartInfo().getMtnFlow());
        }

        //MVP2
        if(request.getCartInfo()!=null && request.getCartInfo().getCaseId()!=null && request.getCartInfo().getCaseId().startsWith("SOF")){

            logger.info("SalesOrderFlex Prepay remove lines Request before PEGA call setting Call Reason");
            contextInfo.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }

        context.setCartInfo(cartInfo);
        context.setContextInfo(contextInfo);
        context.setCaseId(request.getCartInfo().getCaseId());

        if(request.getCartInfo()!=null &&
                ((request.getCartInfo().getIsPrepayCart()!=null && "Y".equalsIgnoreCase(request.getCartInfo().getIsPrepayCart())) ||
                        (request.getCartInfo().getCaseId()!=null && request.getCartInfo().getCaseId().startsWith("SOF")))){

            logger.info("SalesOrderFlex Prepay Remove Line before PEGA call setting Call Reason and ServiceName");
            contextInfo.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }
        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);
        return pegaRequest;
    }

    /**
     * @param pegaRequest
     * @param request
     * @return PastDuesPEGARequest
     */
    public static PastDuesPEGARequest formatPastDuesRequest(PastDuesPEGARequest pegaRequest,
                                                            PastDuesUIRequest request) {

        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(request.getChannelId());
        pegaRequest.setServiceHeader(serviceHeader);

        PastDuesServiceBody serviceBody = new PastDuesServiceBody();
        PastDuesServiceRequest serviceRequest = new PastDuesServiceRequest();
        PastDuesContext context = new PastDuesContext();

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
        customerInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());
        context.setCustomerInfo(customerInfo);

        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(request.getCartInfo().getCartId());
        cartInfo.setClientAppName(request.getCartInfo().getClientAppName());
        cartInfo.setAction(CartConstants.UPDATE);
        cartInfo.setItemType("PASTDUE");
        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType()))
            cartInfo.setIntendType(request.getCartInfo().getIntendType());
        else
            cartInfo.setIntendType(CartConstants.EUP);
        cartInfo.setPastdue(request.getData().getPastdue());
        context.setCartInfo(cartInfo);

        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.PAST_DUE, request.getCartInfo().getClientAppName());
        if (request.getCartInfo().getPastDueAccepted() != null)
            contextInfo.setPastDueAccepted(request.getCartInfo().getPastDueAccepted());
        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessStep())) {
            contextInfo.setProcessStep(request.getCartInfo().getProcessStep());
        } else {
            contextInfo.setProcessStep("pastDuePage");
        }

        //MVP2
        if(request.getCartInfo()!=null && request.getCartInfo().getCaseId()!=null && request.getCartInfo().getCaseId().startsWith("SOF")){

            logger.info("SalesOrderFlex Prepay format past due Request before PEGA call setting Call Reason");
            contextInfo.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }

        context.setContextInfo(contextInfo);

        context.setCaseId(request.getCartInfo().getCaseId());

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);
        return pegaRequest;

    }

    /**
     * @param pegaRequest
     * @param request
     * @return InitiateCheckoutPEGARequest
     */
    public static InitiateCheckoutPEGARequest formatInitiateCheckoutRequest(InitiateCheckoutPEGARequest pegaRequest,
                                                                            InitiateCheckoutUIRequest request) {

        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        serviceHeader = CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(request.getChannelId());
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                && ((CartConstants.REFUND_EXCHANGE).equalsIgnoreCase(request.getCartInfo().getIntendType()))) {
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_ADJUSTMENT);
        }
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                && ((CartConstants.CLNR_FLOW).equalsIgnoreCase(request.getCartInfo().getIntendType()))) {
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_ADJUSTMENT);
        }

        pegaRequest.setServiceHeader(serviceHeader);

        InitiateCheckoutServiceBody serviceBody = new InitiateCheckoutServiceBody();
        InitiateCheckoutServiceRequest serviceRequest = new InitiateCheckoutServiceRequest();
        InitiateCheckoutContext context = new InitiateCheckoutContext();

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
        customerInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());
        if (request.getCartInfo().getCreditAppNum() != null)
            customerInfo.setCreditAppNum(request.getCartInfo().getCreditAppNum());
        if (request.getCartInfo().getCreditStatus() != null)
            customerInfo.setCreditStatus(request.getCartInfo().getCreditStatus());
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getSalesRepId()))
            customerInfo.setCartCreatorSalesRepId(request.getCartInfo().getSalesRepId());
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getFlowType()))
            customerInfo.setFlowType(request.getCartInfo().getFlowType());
        if (null != request.getCartInfo().getIsCareRepAssisted())
            customerInfo.setIsCareRepAssisted(request.getCartInfo().getIsCareRepAssisted());
        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        contextInfo = CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.INITIATE_CHECKOUT,
                request.getCartInfo().getClientAppName());
        if (CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())
                || CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())
                || CartConstants.NSE_5G.equalsIgnoreCase(request.getCartInfo().getIntendType())
                || CartConstants.NSEACC.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
            CartPegaRequestUtil7.newCustomerOverride(contextInfo, customerInfo, request.getCartInfo(), request.getChannelId());
        }
        context.setCustomerInfo(customerInfo);

        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(request.getCartInfo().getCartId());
        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getQuoteId()))
            cartInfo.setQuoteId(request.getCartInfo().getQuoteId());
        if(request.getCartInfo().getIsInterimValidation() != null)
            cartInfo.setIsInterimValidation(request.getCartInfo().getIsInterimValidation());
        if(request.getCartInfo().getEffectivedate() != null)
            cartInfo.setEfectivedate(request.getCartInfo().getEffectivedate());

        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()) &&
                "AAL_CBD_TECH".equalsIgnoreCase(request.getCartInfo().getIntendType()))
        {
            cartInfo.setIntendType(CartConstants.AAL_5G);
        }
        context.setCartInfo(cartInfo);

        context.setCaseId(request.getCartInfo().getCaseId());

        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessStep())) {
            contextInfo.setProcessStep(request.getCartInfo().getProcessStep());
        } else {
            contextInfo.setProcessStep(CartConstants.SHOPPING_CART);
        }
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessAction())) {
            contextInfo.setProcessAction(request.getCartInfo().getProcessAction());
        } else {
            if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId())))
                contextInfo.setProcessAction(CartConstants.CHECKOUT);
            else if (CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId())))
                contextInfo.setProcessAction(CartConstants.PROCEED_TO_ORDER);
        }

        if (request.getCartInfo().getIsExpressCheckout() != null && request.getCartInfo().getIsExpressCheckout()) {
            if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                    && CartConstants.EUPBYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
                contextInfo.setIntent(request.getCartInfo().getIntendType());
            } else {
                contextInfo.setIntent(CartConstants.INLINE_CPC);
            }
            contextInfo.setProcessAction(CartConstants.PROCESS_ACTION_EXPRESS_CHECKOUT);
        }
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getRpsIntent())) {
            contextInfo.setIntent(request.getCartInfo().getRpsIntent());
        }
        if (CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())
                || CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
            contextInfo.setIntent(request.getCartInfo().getIntendType());
        } else if(CartConstants.NSE_5G.equalsIgnoreCase(request.getCartInfo().getIntendType()))
            contextInfo.setIntent(CartConstants.NSE);

        contextInfo.setCallReason(CartConstants.SALES_ORDER_PURCHASE);

        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()) &&
                CartConstants.REFUND_EXCHANGE.equalsIgnoreCase(request.getCartInfo().getIntendType())){
            contextInfo.setCallReason(CartConstants.SALES_ORDER_ADJUSTMENT);
            contextInfo.setIntent(CartConstants.REFUND_EXCHANGE);
        }
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()) &&
                CartConstants.CLNR_FLOW.equalsIgnoreCase(request.getCartInfo().getIntendType())){
            contextInfo.setCallReason(CartConstants.SALES_ORDER_ADJUSTMENT);
            contextInfo.setIntent(CartConstants.CLNR_FLOW);
        }

        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()) &&
                CartConstants.EUP_5G.equalsIgnoreCase(request.getCartInfo().getIntendType()))
        {
            contextInfo.setIntent(request.getCartInfo().getIntendType());
            contextInfo.setTransactionType(CartConstants.REPAIRGEN2TOGEN3);
        }

        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()) &&
                "AAL_CBD_TECH".equalsIgnoreCase(request.getCartInfo().getIntendType()))
        {
            contextInfo.setIntent(CartConstants.AAL_5G);
            contextInfo.setTransactionType(CartConstants.CBAND_TECHNICIAN);
        }

        //MVP2
        if(request.getCartInfo()!=null &&
                ((request.getCartInfo().getIsPrepayCart()!=null && "Y".equalsIgnoreCase(request.getCartInfo().getIsPrepayCart())) ||
                        (request.getCartInfo().getCaseId()!=null && request.getCartInfo().getCaseId().startsWith("SOF")))){

            logger.info("SalesOrderFlex Prepay initiateCheckout / validateCartCheckout before PEGA call setting Call Reason");
            contextInfo.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }

        //MVP2
        if(request.getCartInfo()!=null && request.getCartInfo().getCaseId()!=null && request.getCartInfo().getCaseId().startsWith("SOF")){
            logger.info("SalesOrderFlex Prepay format initiate checkout Request before PEGA call setting Call Reason");
            contextInfo.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_FLEX);
            if (request.getCartInfo().getIsExpressCheckout() != null && request.getCartInfo().getIsExpressCheckout()) {
                logger.info("SalesOrderFlex Prepay ExpressCheckout");
                if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())) {
                    contextInfo.setIntent(request.getCartInfo().getIntendType());
                }
                contextInfo.setProcessAction(CartConstants.PROCESS_ACTION_EXPRESS_CHECKOUT);
                cartInfo.setExpressCheckout(true);
                if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getSignatureData()))
                {
                    cartInfo.setSignatureData(request.getCartInfo().getSignatureData());
                }
                if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLanguage()))
                {
                    cartInfo.setLanguage(request.getCartInfo().getLanguage());
                }
                if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getEscAuthInd()))
                {
                    cartInfo.setEscAuthInd(request.getCartInfo().getEscAuthInd());
                }
            }
        }
        //NSADT-135175 CLNR-ACSS FMI Check Validations
        if(request.getCartInfo()!=null && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()) &&
                CartConstants.CLNR_FLOW.equalsIgnoreCase(request.getCartInfo().getIntendType()) ){
            cartInfo.setFmiCheck(request.getCartInfo().isFmiCheck());
            contextInfo.setTransactionType(request.getCartInfo().getTransactionType());
            logger.info("CLNR FMI Check Value is {}", request.getCartInfo().isFmiCheck() ? "true" : CartConstants.FALSE);
            logger.info("CLNR transactionType {}", request.getCartInfo().getTransactionType());
        }

        context.setContextInfo(contextInfo);

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);
        return pegaRequest;
    }

    /**
     * @param pegaRequest
     * @param request
     * @return AddBuyoutPEGARequest
     */
    public static AddBuyoutPEGARequest formatAddBuyoutRequest(AddBuyoutPEGARequest pegaRequest,
                                                              AddBuyoutUIRequest request) {
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(request.getChannelId());
        pegaRequest.setServiceHeader(serviceHeader);

        AddBuyoutServiceBody serviceBody = new AddBuyoutServiceBody();
        AddBuyoutServiceRequest serviceRequest = new AddBuyoutServiceRequest();
        AddBuyoutContext context = new AddBuyoutContext();

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
        customerInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());
        customerInfo.setBuyOutFlag(request.getCartInfo().getBuyOutFlag());
        customerInfo.setBuyOutSelected(request.getCartInfo().getBuyOutSelected());
        customerInfo.setEdgeUpSelected(request.getCartInfo().getEdgeUpSelected());
        if (request.getCartInfo().getMtnFlow() != null)
            customerInfo.setMtnFlow(request.getCartInfo().getMtnFlow());
        if (StringUtilities.isNotEmptyOrNull(request.getData().getRecommDevId()))
            customerInfo.setRecommDevId(request.getData().getRecommDevId());
        if (StringUtilities.isNotEmptyOrNull(request.getData().getRecommSkuId()))
            customerInfo.setRecommSkuId(request.getData().getRecommSkuId());
        if (null != request.getData().getMtnSOIRecommendation())
            customerInfo.setMtnSOIRecommendation(request.getData().getMtnSOIRecommendation());

        //CXTDT-224104
        if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId())) ) {

            logger.info("setting  CradleFlowJourney empty");
            customerInfo.setCradleFlowJourney("");
        }
        context.setCustomerInfo(customerInfo);

        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(request.getCartInfo().getCartId());
        cartInfo.setAction(CartConstants.UPDATE);
        cartInfo.setItemType("EDGEBUYOUT");
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCustomerConsent()))
            cartInfo.setCustomerConsent(request.getCartInfo().getCustomerConsent());
        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType()))
            cartInfo.setIntendType(request.getCartInfo().getIntendType());
        else
            cartInfo.setIntendType(CartConstants.EUP);
        List<Line> lines = new ArrayList<>();
        for (Lines reqLine : request.getData().getLines()) {
            Line newLine = new Line();
            newLine.setMtn(reqLine.getMtn());
            lines.add(newLine);
        }
        Line[] lineArr = new Line[lines.size()];
        lines.toArray(lineArr);

        cartInfo.setLines(lineArr);

        cartInfo.setEffectiveDate(request.getData().getEffectiveDate());
        context.setCartInfo(cartInfo);
        context.setCaseId(request.getCartInfo().getCaseId());

        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.ADD_BUYOUT_AMT,
                request.getCartInfo().getClientAppName());
        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessStep()))
            contextInfo.setProcessStep(request.getCartInfo().getProcessStep());
        else
            contextInfo.setProcessStep("GridWallPDP");
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessAction()))
            contextInfo.setProcessAction(request.getCartInfo().getProcessAction());

        if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))){
            contextInfo.setProcessAction("");
        }
        context.setContextInfo(contextInfo);

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);
        return pegaRequest;

    }

    /**
     * @param pegaRequest
     * @param request
     * @return AddDownPaymentPEGARequest
     */
    public static AddDownPaymentPEGARequest formatAddDownPaymentRequest(AddDownPaymentPEGARequest pegaRequest,
                                                                        DownPaymentUIRequest request) {

        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        serviceHeader = CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(request.getChannelId());
        if(CartConstants.REX.equalsIgnoreCase(request.getCartInfo().getIntendType())){
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_ADJUSTMENT);
        }
        pegaRequest.setServiceHeader(serviceHeader);

        DownPaymentServiceBody serviceBody = new DownPaymentServiceBody();
        DownPaymentServiceRequest serviceRequest = new DownPaymentServiceRequest();
        AddDownPaymentContext context = new AddDownPaymentContext();

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
        customerInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());

        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(request.getCartInfo().getCartId());
        cartInfo.setClientAppName(request.getCartInfo().getClientAppName());
        cartInfo.setAction(CartConstants.UPDATE);
        if (request.getCartInfo().getTotalDeviceDollar() != null)
            cartInfo.setTotalDeviceDollar(request.getCartInfo().getTotalDeviceDollar());
        if (request.getData().getTotalDeviceDollar() != null)
            cartInfo.setTotalDeviceDollar(request.getData().getTotalDeviceDollar());
        cartInfo.setItemType("DOWNPAYMENT");
        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType()))
            cartInfo.setIntendType(request.getCartInfo().getIntendType());
        else
            cartInfo.setIntendType(CartConstants.EUP);
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCallingPage()))
            cartInfo.setCallingPage(request.getCartInfo().getCallingPage());
        List<Line> lines = new ArrayList<>();
        for (Lines reqLine : request.getData().getLines()) {
            Line newLine = new Line();
            if (reqLine.getLineDeviceDollar() != null)
                newLine.setLineDeviceDollar(reqLine.getLineDeviceDollar());
            newLine.setMtn(reqLine.getMtn());
            newLine.setDownPayment(new DownPayment());
            if (newLine.getDownPayment() != null && StringUtilities.isNotEmptyOrNull(String.valueOf(newLine.getDownPayment().getAmount()))) {
                newLine.getDownPayment().setAmount(reqLine.getDownPayment().getAmount());
            }
            newLine.getDownPayment().setPercentage(reqLine.getDownPayment().getPercentage());
            newLine.getDownPayment().setInstallmentTerm(reqLine.getDownPayment().getInstallmentTerm());
            newLine.getDownPayment().setMonthlyInstallment(reqLine.getDownPayment().getMonthlyInstallment());
            newLine.getDownPayment().setFirstInstallment(reqLine.getDownPayment().getFirstInstallment());
            newLine.getDownPayment().setVerizonDollars(reqLine.getDownPayment().getVerizonDollars());
            newLine.getDownPayment().setUserSelectedAmount(reqLine.getDownPayment().getUserSelectedAmount());
            newLine.setAddFeatures(reqLine.getAddFeatures());
            newLine.setIspuFlow(reqLine.getIspuFlow());
            newLine.setIsHumSubscription(reqLine.getIsHumSubscription());
            newLine.setIsVZSecureSubsription(reqLine.getIsVZSecureSubsription());
            if (null != reqLine.getSellerPrice())
                newLine.setSellerPrice(reqLine.getSellerPrice());
            lines.add(newLine);
        }
        Line[] lineArr = new Line[lines.size()];
        lines.toArray(lineArr);

        cartInfo.setLines(lineArr);
        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        contextInfo = CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.ADD_DOWNPAYMENT,
                request.getCartInfo().getClientAppName());
        if (CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())
                || CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
            CartPegaRequestUtil7.newCustomerOverride(contextInfo, customerInfo, request.getCartInfo(), request.getChannelId());
        }
        context.setCustomerInfo(customerInfo);
        context.setCartInfo(cartInfo);
        context.setCaseId(request.getCartInfo().getCaseId());
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessStep())) {
            contextInfo.setProcessStep(request.getCartInfo().getProcessStep());
        } else {
            contextInfo.setProcessStep("DownPayment");
        }
        if (CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())
                || CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
            contextInfo.setIntent(request.getCartInfo().getIntendType());
        }

        if(CartConstants.REX.equalsIgnoreCase(request.getCartInfo().getIntendType())){
            contextInfo.setCallReason(CartConstants.SALES_ORDER_ADJUSTMENT);
            contextInfo.setIntent(CartConstants.SALES_ORDER_ADJUSTMENT);
        }
        context.setContextInfo(contextInfo);
        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);
        return pegaRequest;
    }

    /**
     * Method to all quick shop pega request flags*
     * @param request
     * @param cartInfo
     * @param contextInfo
     */
    public static void addQuickShopPegaRequestFlag(AddPlanUIRequest request, CartServiceCartInfo cartInfo, CartServiceContextInfo contextInfo) {
        if(CartUtil.isDigital(request.getChannelId()) && CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())
                && null != request.getCartInfo().getQuickShop()) {
            contextInfo.setProcessAction(request.getCartInfo().getProcessAction());
            cartInfo.setIsQuickShopFlow(request.getCartInfo().getQuickShop());
            if(null != request.getCartInfo().getEditPlanClick() && request.getCartInfo().getEditPlanClick()){
                if(null != request.getCartInfo().getEditFromBYOPlan() && request.getCartInfo().getEditFromBYOPlan()) {
                    cartInfo.setEditFromBYOPlan(request.getCartInfo().getEditFromBYOPlan());
                }
                if(null != request.getCartInfo().getEditFromBYOPerk() && request.getCartInfo().getEditFromBYOPerk()) {
                    cartInfo.setEditFromBYOPerk(request.getCartInfo().getEditFromBYOPerk());
                }
            }
        }
    }

    public static Feature updateLGPOMarkerSPO(AddPlanUIRequest request){
        Feature feature = null;
        if(request != null && request.getData().getLgpoSpo() != null){
                    feature = new Feature();
                    feature.setQuantity(1);
                    feature.setId(request.getData().getLgpoSpo());
                    feature.setType(CartConstants.SPO);
                    feature.setActionIndicator("A");
        }
         return feature;
    }

    private static CartServiceCustomerInfo setCustomerInfoData (CartServiceCustomerInfo customerInfo, CartInfo requestCartInfo) {
        Optional.ofNullable(requestCartInfo).ifPresent(info -> {
            Optional.ofNullable(info.getCustomerType()).ifPresent(customerInfo::setCustomerType);
            Optional.ofNullable(info.getAccountNumber()).ifPresent(customerInfo::setAccountNumber);
            Optional.ofNullable(info.getCartCreator()).ifPresent(customerInfo::setCartCreator);
            Optional.ofNullable(info.getGlobalId()).ifPresent(customerInfo::setGlobalId);
            Optional.ofNullable(info.getProcessingMTN()).ifPresent(customerInfo::setProcessingMTN);
            Optional.ofNullable(info.getEditPlanClick()).ifPresent(customerInfo::setEditPlanClick);
            Optional.ofNullable(info.getDeviceType()).ifPresent(customerInfo::setDeviceType);
            Optional.ofNullable(info.getAccountLevelPlan()).ifPresent(customerInfo::setAccountLevelPlan);
            Optional.ofNullable(info.getIsSmartLocator()).ifPresent(customerInfo::setIsSmartLocator);
            Optional.ofNullable(info.getRegisterNumber()).ifPresent(customerInfo::setRegisterNumber);
            Optional.ofNullable(info.getQuoteWithoutCredit()).ifPresent(customerInfo::setQuoteWithoutCredit);
            Optional.ofNullable(info.getIsUpgradePlan()).ifPresent(customerInfo::setIsUpgradePlan);
        });
        return customerInfo;
    }

    private static void setCartInfoData (CartServiceCartInfo cartInfo, AddPlanUIRequest request, String intendType) {
        //Passing WIFIBACKUP Indicator to CJCM
        cartInfo.setWifiBackup(request.getCartInfo().isWifiBackup());
        cartInfo.setTransactionType(request.getCartInfo().getTransactionType());
        // Added logic for KeepMyCurrentPlan logic
        cartInfo.setKeepMyCurrentPlan(request.getCartInfo().getKeepMyCurrentPlan());
        cartInfo.setCartId(request.getCartInfo().getCartId());
        cartInfo.setClientAppName(request.getCartInfo().getClientAppName());
        cartInfo.setZipCode(request.getCartInfo().getZipCode());
        cartInfo.setItemType("PLAN");
        cartInfo.setAction(CartConstants.UPDATE);

        String lineActivityType = request.getCartInfo().getLineActivityType();

        if (StringUtilities.isNotEmptyOrNull(intendType)) {
            cartInfo.setIntendType(intendType);
        } else if ("TSE".equalsIgnoreCase(lineActivityType)) {
            cartInfo.setIntendType("TSE");
            cartInfo.setCartCreator(request.getCartInfo().getCartCreator());
        } else {
            cartInfo.setIntendType("CPC");
        }

        Optional.ofNullable(request.getData().getParentMtn())
                .ifPresent(cartInfo::setParentMtn);

        cartInfo.setRetrieveFeatureLossReferenceData(
                StringUtilities.isNotEmptyOrNull(request.getData().getRetrieveFeatureLossReferenceData())
                        ? request.getData().getRetrieveFeatureLossReferenceData()
                        : "Y"
        );

        Optional.ofNullable(request.getCartInfo().getRelinquishAccountNumber())
                .filter(StringUtilities::isNotEmptyOrNull)
                .ifPresent(cartInfo::setRelinquishAccountNumber);

        Optional.ofNullable(request.getCartInfo().getTysLinesCount())
                .filter(StringUtilities::isNotEmptyOrNull)
                .ifPresent(cartInfo::setTysLinesCount);

    }
}
