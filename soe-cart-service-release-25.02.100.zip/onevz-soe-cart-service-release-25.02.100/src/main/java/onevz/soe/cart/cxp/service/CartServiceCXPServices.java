package onevz.soe.cart.cxp.service;

import onevz.soe.cart.gql.requests.*;
import onevz.soe.cart.gql.response.GetPairedDeviceInfoGQLResponse;
import onevz.soe.cart.gql.schema.oneclick.CustomerProfileGraphQLRequest;
import onevz.soe.cart.gql.schema.oneclick.CustomerProfileGraphQLResponse;
import onevz.soe.cart.model.bulkcartupdate.gql.request.RetrieveTradeinGQLRequest;
import onevz.soe.cart.model.bulkcartupdate.gql.response.RetrieveTradeinGQLResponse;
import onevz.soe.cart.model.custProfile.SalesRepCustomer;
import onevz.soe.cart.model.deviceSimValidation.CustomerReqType;
import onevz.soe.cart.model.fipscode.RetrieveFipsCode;
import onevz.soe.cart.model.initiateValidateDeviceSim.CustomerRequestType;
import onevz.soe.cart.model.installmentLoan.LoanManagementSearchCXPResponse;
import onevz.soe.cart.model.installmentLoan.LoanManagementSearchRequest;
import onevz.soe.cart.model.mylink.MylinkReferralInfoRequest;
import onevz.soe.cart.model.mylink.MylinkReferralInfoResponse;
import onevz.soe.cart.model.numberlinkE911Address.AddressRequest;
import onevz.soe.cart.model.taxengine.request.NGDTaxEngineRequest;
import onevz.soe.cart.model.taxengine.response.NGDTaxEngineBaseResponse;
import onevz.soe.cart.model.tradeIn.TradeinAccountDevicesRequest;
import onevz.soe.cart.model.tradeIn.TradeinAccountDevicesResponse;
import onevz.soe.cart.model.tradeIn.appraiseDevice.TradeinAppraisalResponse;
import onevz.soe.cart.model.tradeIn.appraiseDevice.TradeinDeviceAppraisalRequest;
import onevz.soe.cart.model.tradeIn.getTradeinQuestions.TradeinAppraisalQuestionsRequest;
import onevz.soe.cart.model.tradeIn.getTradeinQuestions.TradeinAppraisalQuestionsResponse;
import onevz.soe.cart.model.tradeIn.validateDevice.TradeinValidateDeviceRequest;
import onevz.soe.cart.model.tradeIn.validateDevice.TradeinValidateDeviceResponse;
import onevz.soe.cart.model.updateCreditAppFraud.UpdateCreditAppFraudStatusCxpRequest;
import onevz.soe.cart.model.updateCreditAppFraud.UpdateCreditAppFraudStatusCxpResponse;
import onevz.soe.cart.requests.*;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.ui.requests.CalculateMultilineTaxUIRequest;
import onevz.soe.cart.ui.requests.GetTaxDetailsForConfiguratorUIRequest;
import onevz.soe.cart.ui.requests.RetrieveURCForCartUIRequest;
import onevz.soe.cart.ui.responses.CartExceedsLimitResponse;
import onevz.soe.cart.ui.responses.ValidateNextgenCartAndCheckoutResponse;
import onevz.soe.customerprofile.model.gqlrequest.assisted.CustomerProfileGraphQLAssistedRequest;
import onevz.soe.customerprofile.response.CustomerProfileGraphQLAssistedResponse;
import onevz.soe.orderprocess.response.cxp.ScanIdLookUpInfoCXPResponse;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import onevz.soe.wsclient.http.rest.RestUrlParameter;
import onevz.wsclient.cxp.CXPServices;
import onevz.wsclient.cxp.annotations.*;
import org.springframework.context.annotation.Primary;
import org.springframework.web.bind.annotation.RequestMethod;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;

import static onevz.soe.cart.constants.CartConstants.*;

/**
 *
 * @author pandsi9
 *
 */
@Primary
public interface CartServiceCXPServices extends CXPServices {

	/**
	 *
	 * @param request
	 * @return UpdateUserInfoCXPResponse
	 */
	@CXPJson(component = "cart", urlPostFix = "/shopping/update-cart")
    Mono<UpdateUserInfoCXPResponse> updateUserInfo(UpdateUserInfoCXPRequest request);

	/**
	 *
	 * @param request
	 * @return PaperlessBillingCXPResponse
	 */
	@CXPJson(component = "cart", urlPostFix = "/shopping/update-cart")
    Mono<PaperlessBillingCXPResponse> paperlessBilling(PaperlessBillingCXPRequest request);



	/**
	 *
	 * @param request
	 * @return UpdateTradeinTypeCXPResponse
	 */
	@CXPJson(component = "cart", urlPostFix = "/shopping/update-cart")
    Mono<UpdateTradeinTypeCXPResponse> updateTradeinType(UpdateTradeinTypeCXPRequest request);

	/**
	 *
	 * @param request
	 * @return MacAddressCXPResponse
	 */
	@CXPJson(component = "cart", urlPostFix = "/shopping/update-cart")
    Mono<MacAddressCXPResponse> updateMacAddress(MacAddressCXPRequest request);

	/**
	 *
	 * @param request
	 * @return UpdateSellerPriceCXPResponse
	 */
	@CXPJson(component = "cart", urlPostFix = "/shopping/update-cart")
    Mono<UpdatePurchaseOrderCXPResponse> updatePurchaseOrderNo(UpdatePurchaseOrderCXPRequest request);

	/**
	 *
	 * @param request
	 * @return GiftPurchaseCXPResponse
	 */
	@CXPJson(component = "cart", urlPostFix = "/shopping/update-cart")
    Mono<GiftPurchaseCXPResponse> giftPurchase(GiftPurchaseCXPRequest request);

	/**
	 *
	 * @param request
	 * @return CheckDfillInventoryCXPResponse
	 */
	@CXPJson(component = "cart", urlPostFix = "/shopping/update-cart")
    Mono<CheckDfillInventoryCXPResponse> checkDfillInventory(CheckDfillInventoryCXPRequest request);

	/**
	 *
	 * @param request
	 * @return GetUpgradeReasonCodeCXPResponse
	 */
	@CXPJson(component = "cart", urlPostFix = "/shopping/retrieve-urc")
    Mono<GetUpgradeReasonCodeCXPResponse> getUpgradeReasonCodes(GetUpgradeReasonCodeCXPRequest request);

	/**
	 *
	 * @param request
	 * @return VZCCAppStatusCXPResponse
	 */
	@CXPJson(component = "cart", urlPostFix = "/shopping/update-cart")
    Mono<VZCCAppStatusCXPResponse> updateVZCCAppStatus(VZCCAppStatusCXPRequest request);

	/**
	 *
	 * @param request
	 * @return UpdateVzccNBXInfoResponse
	 */
	@CXPJson(component = "cart", urlPostFix = "/shopping/update-cart")
    Mono<UpdateVzccNBXInfoCXPResponse> updateVzccNBXInfo(UpdateVzccNBXInfoCXPRequest request);

	/**
	 *
	 * @param cartId
	 * @param retrieveCurrentFeatures
	 * @return RetrieveCartCXPResponse
	 */
	@CXPGraphQL(component = "cart", urlPostFix = "/shopping/graphql", clientIdOverride="global")
	@GQLQueryName(value = "cart", requestClass = RetrieveCartNewCustomerGQLRequest.class)
    Mono<RetrieveCartCXPResponse> retrieveCartNewCustomer(@GQLQueryValue(value = CART_ID) String cartId, @GQLQueryValue(value = RETRIEVE_CURRENT_FEATURES) Boolean retrieveCurrentFeatures, @GQLQueryValue(value = "mtnList") List<String> mtnList);

	/**
	 *
	 * @param cartId
	 * @param retrieveCurrentFeatures
	 * @return RetrieveCartCXPResponse
	 */
	@CXPGraphQL(component = "cart", urlPostFix = "/shopping/graphql", clientIdOverride="global")
	@GQLQueryName(value = "cart", requestClass = RetrieveCartGQLRequest.class)
    Mono<RetrieveCartCXPResponse> retrieveCart(@GQLQueryValue(value = CART_ID) String cartId, @GQLQueryValue(value = RETRIEVE_CURRENT_FEATURES) Boolean retrieveCurrentFeatures, @GQLQueryValue(value = "mtnList") List<String> mtnList);

	/**
	 *
	 * @param cartId
	 * @param retrieveCurrentFeatures
	 * @return RetrieveCartCXPResponse
	 */
	@CXPGraphQL(component = "cart", urlPostFix = "/shopping/graphql", clientIdOverride="global")
	@GQLQueryName(value = "cart", requestClass = RetrieveCartOptimsedDigitalGQLRequest.class)
    Mono<RetrieveCartCXPResponse> retrieveCartDigital(@GQLQueryValue(value = CART_ID) String cartId, @GQLQueryValue(value = RETRIEVE_CURRENT_FEATURES) Boolean retrieveCurrentFeatures, @GQLQueryValue(value = "mtnList") List<String> mtnList);

	/**
	 *
	 * @param cartId
	 * @param retrieveCurrentFeatures
	 * @return RetrieveCartCXPResponse
	 */
	@CXPGraphQL(component = "cart", urlPostFix = "/shopping/graphql", clientIdOverride="global")
	@GQLQueryName(value = "cart", requestClass = RetrieveCartNewNumberPortInGQLRequest.class)
    Mono<RetrieveCartCXPResponse> retrieveCartNewNumberPortIn(@GQLQueryValue(value = CART_ID) String cartId, @GQLQueryValue(value = RETRIEVE_CURRENT_FEATURES) Boolean retrieveCurrentFeatures, @GQLQueryValue(value = "mtnList") List<String> mtnList);

	/**
	 *
	 * @param cartId
	 * @param retrieveCurrentFeatures
	 * @return RetrieveCartCXPResponse
	 */
	@CXPGraphQL(component = "billingAddress", urlPostFix = "/shopping/graphql", clientIdOverride="global")
	@GQLQueryName(value = "cart", requestClass = BillingAddressGQLRequest.class)
    Mono<RetrieveCartCXPResponse> billingAddress(@GQLQueryValue(value = CART_ID) String cartId, @GQLQueryValue(value = RETRIEVE_CURRENT_FEATURES) Boolean retrieveCurrentFeatures, @GQLQueryValue(value = "mtnList") List<String> mtnList);

	/**
	 *
	 * @param cartId
	 * @param retrieveCurrentFeatures
	 * @return RetrieveCartCXPResponse
	 */
	@CXPGraphQL(component = "numberShare", urlPostFix = "/shopping/graphql", clientIdOverride="global")
	@GQLQueryName(value = "cart", requestClass = NumberShareGQLRequest.class)
    Mono<RetrieveCartCXPResponse> numberShare(@GQLQueryValue(value = CART_ID) String cartId, @GQLQueryValue(value = RETRIEVE_CURRENT_FEATURES) Boolean retrieveCurrentFeatures, @GQLQueryValue(value = "mtnList") List<String> mtnList);

	/**
	 *
	 * @param cartId
	 * @param retrieveCurrentFeatures
	 * @return RetrieveCartCXPResponse
	 */
	@CXPGraphQL(component = "cartE911Address", urlPostFix = "/shopping/graphql", clientIdOverride="global")
	@GQLQueryName(value = "cart", requestClass = CartE911AddressGQLRequest.class)
    Mono<RetrieveCartCXPResponse> cartE911Address(@GQLQueryValue(value = CART_ID) String cartId, @GQLQueryValue(value = RETRIEVE_CURRENT_FEATURES) Boolean retrieveCurrentFeatures, @GQLQueryValue(value = "mtnList") List<String> mtnList);

	/**
	 *
	 * @param cartId
	 * @param retrieveCurrentFeatures
	 * @return RetrieveCartCXPResponse
	 */
	@CXPGraphQL(component = "getdevicedetails", urlPostFix = "/shopping/graphql", clientIdOverride="global")
	@GQLQueryName(value = "cart", requestClass = DeviceDetailsGQLRequest.class)
    Mono<RetrieveCartCXPResponse> deviceDetails(@GQLQueryValue(value = CART_ID) String cartId, @GQLQueryValue(value = RETRIEVE_CURRENT_FEATURES) Boolean retrieveCurrentFeatures, @GQLQueryValue(value = "mtnList") List<String> mtnList);

	/**
	 *
	 * @param cartId
	 * @param retrieveCurrentFeatures
	 * @return RetrieveCartCXPResponse
	 */
	@CXPGraphQL(component = "validatecartandupdate", urlPostFix = "/shopping/graphql", clientIdOverride="global")
	@GQLQueryName(value = "validateCartAndUpdate", requestClass = ValidateCartGQLRequest.class)
    Mono<ValidateCartCXPResponse> validateCart(@GQLQueryValue(value = CART_ID) String cartId, @GQLQueryValue(value = "channel") String channel, @GQLQueryValue(value = "pageId") String pageId, @GQLQueryValue(value = "flow") String flow, @GQLQueryValue(value = RETRIEVE_CURRENT_FEATURES) Boolean retrieveCurrentFeatures, @GQLQueryValue(value = "mtnList") List<String> mtnList,@GQLQueryValue(value = "skipValidationErrorCodes") String skipValidationErrorCodes,@GQLQueryValue(value = "isFWASimplificationEnabled") Boolean isFWASimplificationEnabled);

	/**
	 *
	 * @param cartId
	 * @param retrieveCurrentFeatures
	 * @return RetrieveCartCXPResponse
	 */
	@CXPGraphQL(component = "validatecartandupdate", urlPostFix = "/shopping/graphql", clientIdOverride="global")
	@GQLQueryName(value = "validateCartAndUpdate", requestClass = ValidateCartNewCustomerGQLRequest.class)
    Mono<ValidateCartCXPResponse> validateCartNewCustomer(@GQLQueryValue(value = CART_ID) String cartId, @GQLQueryValue(value = "channel") String channel, @GQLQueryValue(value = "pageId") String pageId, @GQLQueryValue(value = "flow") String flow, @GQLQueryValue(value = RETRIEVE_CURRENT_FEATURES) Boolean retrieveCurrentFeatures, @GQLQueryValue(value = "mtnList") List<String> mtnList, @GQLQueryValue(value = "customerType") String customerType,@GQLQueryValue(value = "isFWASimplificationEnabled") Boolean isFWASimplificationEnabled);

	/**
	 * 
	 * @param cartId
	 * @param retrieveCurrentFeatures
	 * @return RetrieveCartCXPResponse
	 */
    @CXPGraphQL(component = "validatecartandupdate", urlPostFix = "/shopping/graphql", clientIdOverride="global")
	@GQLQueryName(value = "validateCartAndUpdate", requestClass = RetrieveMiniCartGQLRequest.class)
	Mono<ValidateCartCXPResponse> retrieveValidateMiniCart(@GQLQueryValue(value = CART_ID) String cartId, @GQLQueryValue(value = "channel") String channel, @GQLQueryValue(value = "pageId") String pageId, @GQLQueryValue(value = "flow") String flow, @GQLQueryValue(value = RETRIEVE_CURRENT_FEATURES) Boolean retrieveCurrentFeatures, @GQLQueryValue(value = "mtnList") List<String> mtnList, @GQLQueryValue(value = "customerType") String customerType);

	/**
	 *
	 * @param cartId
	 * @param retrieveCurrentFeatures
	 * @return RetrieveCartCXPResponse
	 */
	@CXPGraphQL(component = "getShippingInfo", urlPostFix = "/shopping/graphql", clientIdOverride="global")
	@GQLQueryName(value = "cart", requestClass = ShippingInfoGQLRequest.class)
    Mono<RetrieveCartCXPResponse> shippingInfo(@GQLQueryValue(value = CART_ID) String cartId, @GQLQueryValue(value = RETRIEVE_CURRENT_FEATURES) Boolean retrieveCurrentFeatures, @GQLQueryValue(value = "mtnList") List<String> mtnList);

	/**
	 *
	 * @param cartId
	 * @param retrieveCurrentFeatures
	 * @return RetrieveCartCXPResponse
	 */
	@CXPGraphQL(component = "getAgreementInfo", urlPostFix = "/shopping/graphql", clientIdOverride="global")
	@GQLQueryName(value = "cart", requestClass = AgreementInfoGQLRequest.class)
    Mono<RetrieveCartCXPResponse> agreementInfo(@GQLQueryValue(value = CART_ID) String cartId, @GQLQueryValue(value = RETRIEVE_CURRENT_FEATURES) Boolean retrieveCurrentFeatures, @GQLQueryValue(value = "mtnList") List<String> mtnList);

	/**
	 *
	 * @param cartId
	 * @param retrieveCurrentFeatures
	 * @return RetrieveCartCXPResponse
	 */
	@CXPGraphQL(component = "deviceCount", urlPostFix = "/shopping/graphql", clientIdOverride="global")
	@GQLQueryName(value = "cart", requestClass = DeviceCountGQLRequest.class)
    Mono<RetrieveCartCXPResponse> deviceCountInCart(@GQLQueryValue(value = CART_ID) String cartId, @GQLQueryValue(value = RETRIEVE_CURRENT_FEATURES) Boolean retrieveCurrentFeatures, @GQLQueryValue(value = "mtnList") List<String> mtnList);

	/**
	 *
	 * @param cartId
	 * @param retrieveCurrentFeatures
	 * @return RetrieveCartCXPResponse
	 */
	@CXPGraphQL(component = "getEffectiveDateDetails", urlPostFix = "/shopping/graphql", clientIdOverride="global")
	@GQLQueryName(value = "cart", requestClass = EffectiveDateDetailsGQLRequest.class)
    Mono<RetrieveCartCXPResponse> effectiveDateDetails(@GQLQueryValue(value = CART_ID) String cartId, @GQLQueryValue(value = RETRIEVE_CURRENT_FEATURES) Boolean retrieveCurrentFeatures, @GQLQueryValue(value = "mtnList") List<String> mtnList);

	/**
	 *
	 * @param cartId
	 * @param retrieveCurrentFeatures
	 * @return RetrieveCartCXPResponse
	 */
	@CXPGraphQL(component = "cartItems", urlPostFix = "/shopping/graphql", clientIdOverride="global")
	@GQLQueryName(value = "cart", requestClass = CartItemsGQLRequest.class)
    Mono<RetrieveCartCXPResponse> cartItems(@GQLQueryValue(value = CART_ID) String cartId, @GQLQueryValue(value = RETRIEVE_CURRENT_FEATURES) Boolean retrieveCurrentFeatures, @GQLQueryValue(value = "mtnList") List<String> mtnList);

	/**
	 *
	 * @param request
	 * @return RetrieveURCForCartCXPResponse
	 */
	@CXPGraphQL(component = "retrieveURC", urlPostFix = "/shopping/graphql", clientIdOverride="global")
	@GQLQueryName(value = "retrieveURCforCartMtnList", requestClass = RetrieveURCForCartGQLRequest.class)
    Mono<RetrieveURCForCartCXPResponse> retrieveURCForCart(@GQLQueryValue("eligibleURCforCartMtnList") RetrieveURCForCartUIRequest request);

	/**
	 *
	 * @param request
	 * @return CalculateMultilineTaxCXPResponse
	 */
	@CXPGraphQL(component = "calculateTaxDetailsforCart", urlPostFix = "/shopping/graphql", clientIdOverride="global")
	@GQLQueryName(value = "calculateMultiLineTaxForCart", requestClass = CalculateMultilineTaxGQLRequest.class)
    Mono<CalculateMultilineTaxCXPResponse> calculateMultiLineTaxForCart(@GQLQueryValue("calculateTaxDetailsforCart") CalculateMultilineTaxUIRequest request);

	/**
	 *
	 * @param deviceId
	 * @return ValidateBYODToolCXPResponse
	 */
	@CXPGraphQL(component = "validateBYOD", urlPostFix = "/accountmaintenance/graphql", clientIdOverride="global")
	@GQLQueryName(value = "validateBYOD", requestClass = ValidateBYODToolGQLRequest.class)
    Mono<ValidateBYODToolCXPResponse> validateBYODTool(@GQLQueryValue(value = "deviceId") String deviceId);

	/**
	 *
	 * @param request
	 * @return ESimDetailsETNIResponse
	 */
	@CXPJson(component = "cart", methodType = RequestMethod.PATCH, domainName = "ETNI", urlPostFix = "/EsimServices/personalizationProvisioning", isDomainCall = true)
    Mono<ESimDetailsETNIResponse> eSimDetails(ESimDetailsETNIRequest request);

	@CXPJson(component = "cart", methodType = RequestMethod.POST, domainName = "ETNI", urlPostFix = "/MDNQueryServices/iccidDetails", isDomainCall = true)
	Mono<IccidDetailsETNIResponse> iccidDetails(IccidDetailsETNIRequest request);

	@CXPJson(component = "ordering", urlPostFix = "/orderManagement/search", methodType = RequestMethod.POST, isDomainCall = true, domainName = "CXP")
	Mono<SearchOrderManagementCXPResponse> search(SearchOrderManagementCXPRequest request);

	/**
	 *
	 * @param request
	 * @return ValidateOffersResponse
	 */
	@CXPJson(component = "promotion", urlPostFix = "/browsing/validate-offers")
    Mono<ValidateOffersResponse> validateOffers(ValidateOffersRequest request);

	/**
	 *
	 * @param request
	 * @return
	 */
	@CXPGraphQL(component = "customerByMtnList", urlPostFix = "/customerprofile/graphql", clientIdOverride="global")
	@GQLQueryName(value = "customerByMtnList", requestClass = CustomerByMtnListGQLRequest.class)
    Mono<CustomerByMtnListCXPResponse> customerByMtnList(@GQLQueryValue("mtnList") String[] request);

	/**
	 *
	 * @param cartId
	 * @param retrieveCurrentFeatures
	 * @return RetrieveCartCXPResponse
	 */
	@CXPGraphQL(component = "taxAndDues", urlPostFix = "/shopping/graphql", clientIdOverride="global")
	@GQLQueryName(value = "cart", requestClass = TaxAndDuesGQLRequest.class)
    Mono<RetrieveCartCXPResponse> taxAndDues(@GQLQueryValue(value = CART_ID) String cartId, @GQLQueryValue(value = RETRIEVE_CURRENT_FEATURES) Boolean retrieveCurrentFeatures, @GQLQueryValue(value = "mtnList") List<String> mtnList);

	/**
	 * Retrieve customer.
	 *
	 * @param customerId customerId
	 * @return the mono - CustomerResponse
	 */
	@CXPGraphQL(component = "customer", urlPostFix = "/customerprofile/graphql", clientIdOverride="global")
	@GQLQueryName(value = "customer", requestClass = RetrieveCustomerGQLRequest.class)
    Mono<RetrieveCustomerCXPResponse> retrieveCustomer(@GQLQueryValue(value = "customerId") String customerId);

	@CXPGraphQL(component = "assisted", urlPostFix = "/customerprofile/graphql", clientIdOverride="global")
	@GQLQueryName(value = "customer", requestClass = CustomerProfileGraphQLAssistedRequest.class)
	Mono<CustomerProfileGraphQLAssistedResponse> getCustomerProfileAssisted(@GQLQueryValue("customerId") String customerId);

	/**
	 *
	 * @param salesRepCustomer
	 * @return the mono - CustomerProfileResponse
	 */
	@CXPGraphQL(component = "customer", urlPostFix = "/userprofiling/graphql")
	@GQLQueryName(value = "mostRecentSalesRepCustomerData", requestClass = CustomerGQLRequest.class)
    Mono<CustomerProfileCXPResponse> customerProfileDigital(@GQLQueryValue("salesRepCustomer") SalesRepCustomer salesRepCustomer);

	/**
	 *
	 * @param request
	 * @return UpdateUserInfoCXPResponse
	 */
	@CXPJson(component = "cart", urlPostFix = "/shopping/update-cart")
    Mono<MyOffersCXPResponse> updateMyOffers(MyOffersCXPRequest request);

	/**
	 *
	 * @param request
	 * @return UpdateUserInfoCXPResponse
	 */
	@CXPJson(component = "ordering", urlPostFix = "/ordering/release-pending-order")
    Mono<RPSReleasePendingOrderCXPResponse> releaseRPSPendingOrder(RPSReleasePendingOrderRequestCXPRequest request);
	/**
	 *
	 * @param cxpRequest
	 * @return RPSE911AddressUpdateCXPResponse
	 */
	@CXPJson(component = "customer", urlPostFix = "/customerprofile/update-e911-address")
    Mono<RPSE911AddressCXPResponse> updateRPSE911Address(RPSE911AddressUpdateCXPRequest cxpRequest);



	/**
	 *
	 * @param cxpRequest
	 * @return RPSE911AddressCXPResponse
	 */
	@CXPJson(component = "customer", urlPostFix = "/customerprofile/retrieve-e911-address")
    Mono<RPSE911AddressCXPResponse> retrieveRPSE911Address(RPSE911AddressRetrieveCxpRequest cxpRequest);

	/**
	 *
	 * @param cxpRequest
	 * @return RPSE911AddressCXPResponse
	 */
	@CXPJson(component = "customer", urlPostFix = "/customerprofile/retrieve-e911-address")
    Mono<NLinlk911AddressCXPResponse> retrieveNLinkE911Address(RPSE911AddressRetrieveCxpRequest cxpRequest);

	/**
	 *
	 * @param request
	 * @return UpdateTradeInOfferCXPResponse
	 */
	@CXPJson(component = "cart", urlPostFix = "/shopping/update-cart")
    Mono<UpdateTradeInOfferCXPResponse> updateTradeInOffer(UpdateTradeInOfferCXPRequest request);

	/**
	 * @param cxpRequest
	 * @return DeviceSimDetailsCxpResponse
	 */
	@CXPJson(component = "customer", urlPostFix = "/customerprofile/customer/device-sim-details")
    Mono<DeviceSimDetailsCxpResponse> deviceSimDetails(DeviceSimDetailsCxpRequest cxpRequest);

	@CXPJson(component = "customer", urlPostFix = "/customerprofile/customer/device-validation")
    Mono<DeviceIdValidationCXPResponse> deviceValidation(DeviceValidationCXPRequest cxpRequest);

	/**
	 *
	 * @param request
	 * @return AddZipcode
	 */
	@CXPJson(component = "cart", urlPostFix = "/shopping/update-cart")
    Mono<AddZipcodeCXPResponse> addZipcodeToCart(AddZipcodeCXPRequest request);

	@CXPJson(component = "customer", urlPostFix = "/customerprofile/customer/device-sim-validation")
    Mono<DeviceSimValidationCXPResponse> deviceSimValidation(DeviceSimValidationCXPRequest cxpRequest);

	//VZWCS-17115
	@CXPJson(component = "customer", urlPostFix = "/customerprofile/customer/initiate-cbandCheck")
    Mono<InitiateCbandCheckCXPResponse> initiateCbandCheck(InitiateCbandCheckCXPRequest cxpRequest);

	/**
     *
     * @param customerReqType
     * @return
     */
    @CXPGraphQL(component = "customerProfile", urlPostFix = "/customerprofile/graphql", clientIdOverride="global")
    @GQLQueryName(value = "customerProfile", requestClass = CustomerByMtnGQLRequest.class)
    Mono<CustomerByMtnCXPResponse> customerByMtn(@GQLQueryValue(value = "customerRequestType") CustomerReqType customerReqType);

	/**
	 *
	 * @param customerReqType
	 * @return
	 */
	@CXPGraphQL(component = "customerProfile", urlPostFix = "/customerprofile/graphql", clientIdOverride="global")
	@GQLQueryName(value = "customerProfile", requestClass = CustomerProfileRequest.class)
    Mono<CustomerByMtnCXPResponse> customerProfile(@GQLQueryValue(value = "customerRequestType") CustomerReqType customerReqType);

    /**
     *
     * @param cartId
     * @return RetrieveCartCXPResponse
     */
	@CXPGraphQL(component = "cart", urlPostFix = "/shopping/graphql", clientIdOverride="global")
	@GQLQueryName(value = "cart", requestClass = FiveGMoversRetrieveCartGQLRequest.class)
    Mono<RetrieveCartCXPResponse> retrieve5GMoversCart(@GQLQueryValue(value = CART_ID) String cartId);

	@CXPGraphQL(component = "orderingconfirmation", urlPostFix = "/orderingconfirmation/graphql")
	@GQLQueryName(value = "getConfirmationPage", requestClass = FWAOrderConfirmationRequest.class)
	Mono<FWAOrderConfirmationCXPResponse> getCJMTagUrl(@GQLQueryValue(value = CART_ID) String cartId, @GQLQueryValue(value = "deviceType") String deviceType, @GQLQueryValue(value = "cjevent") String cjevent, @GQLQueryValue(value = "affiliate") String affiliate);

	/**
	 *
	 * @param cartId
	 * @param retrieveCurrentFeatures
	 * @return RetrieveCartCXPResponse
	 */
	@CXPGraphQL(component = "cart", urlPostFix = "/shopping/graphql", clientIdOverride="global")
	@GQLQueryName(value = "cart", requestClass = FiveGRetrieveCartGQLRequest.class)
    Mono<RetrieveCartCXPResponse> retrieve5GCart(@GQLQueryValue(value = CART_ID) String cartId, @GQLQueryValue(value = RETRIEVE_CURRENT_FEATURES) Boolean retrieveCurrentFeatures, @GQLQueryValue(value = "mtnList") List<String> mtnList);

	@CXPGraphQL(component = "customerNameByMtn", urlPostFix = "/customerprofile/graphql", clientIdOverride="global")
	@GQLQueryName(value = "customerProfile", requestClass = CustomerNameByMtnGQLRequest.class)
    Mono<CustomerNameByMtnCXPResponse> customerNameByMtn(@GQLQueryValue(value = "customerRequestType") CustomerRequestType customerRequestType);

	/**
	 *
	 * @param cartId
	 * @param retrieveCurrentFeatures
	 * @return RetrieveCartCXPResponse
	 */
	@CXPGraphQL(component = "validatecartandupdate", urlPostFix = "/shopping/graphql", clientIdOverride="global")
	@GQLQueryName(value = "validateCartAndUpdate", requestClass = DigitalValidateCartGQLRequest.class)
    Mono<ValidateCartCXPResponse> retrieve5GValidateCart(@GQLQueryValue(value = CART_ID) String cartId,
                                                         @GQLQueryValue(value = RETRIEVE_CURRENT_FEATURES) Boolean retrieveCurrentFeatures,
                                                         @GQLQueryValue(value = "pageId") String pageId,
                                                         @GQLQueryValue(value = "skipValidations") Boolean skipValidations,
														 @GQLQueryValue(value = "validateAppointments") Boolean validateAppointments,
                                                         @GQLQueryValue(value = "fiveGLTEDueMonthly") Boolean fiveGLTEDueMonthly);

	 /** @param cartId
	 * @param retrieveCurrentFeatures
	 * @return RetrieveCartCXPResponse
	 */
	@CXPGraphQL(component = "validatecartandupdate", urlPostFix = "/shopping/graphql", clientIdOverride="global")
	@GQLQueryName(value = "validateCartAndUpdate", requestClass = DigitalValidateCartGQLRequest.class)
    Mono<ValidateCartCXPResponse> retrieveNSE5GValidateCart(@GQLQueryValue(value = CART_ID) String cartId,
                                                            @GQLQueryValue(value = RETRIEVE_CURRENT_FEATURES) Boolean retrieveCurrentFeatures,
                                                            @GQLQueryValue(value = "pageId") String pageId,
                                                            @GQLQueryValue(value = "skipValidations") Boolean skipValidations,
															@GQLQueryValue(value = "validateAppointments") Boolean validateAppointments,
                                                            @GQLQueryValue(value = "customerType") String customerType);

    /**
     *
     * @param salesRepCustomer
     * @return the mono - CustomerProfileResponse
     */
    @CXPGraphQL(component = "customer", urlPostFix = "/userprofiling/graphql")
    @GQLQueryName(value = "mostRecentSalesRepCustomerData", requestClass = SalesRepProfileGQLRequest.class)
    Mono<CustomerProfileCXPResponse> salesRepIdProfile(@GQLQueryValue("salesRepCustomer") SalesRepCustomer salesRepCustomer);

    /**
	 *
	 * @param cartId
	 * @return RetrieveCartCXPResponse
	 */
	@CXPGraphQL(component = "cart", urlPostFix = "/shopping/graphql", clientIdOverride="global")
	@GQLQueryName(value = "cart", requestClass = GetPairedDeviceInfoGQLRequest.class)
    Mono<GetPairedDeviceInfoGQLResponse> getPairedDevices(@GQLQueryValue(value = CART_ID) String cartId);

	/**
	 *
	 * @param request
	 * @return RetrieveActivationStatusCXPResonse
	 */
	@CXPJson(component = "cart", urlPostFix = "/order/retrieve-activation-status")
    Mono<RetrieveActivationStatusCXPResponse> retrieveActivationStatus(RetrieveActivationStatusCXPRequest request);

	@CXPJson(component = "ordering", urlPostFix = "/ordering/retrieve-activation-status")
    Mono<RetrieveActivationStatusCXPResponse> retrieveActivationStatusOrdering(RetrieveActivationStatusCXPRequest request) throws SOEHTTPException;

	/**
	 *
	 * @param addressRequest
	 * @return ValidateE911AddressCXPResponse
	 */
	@CXPGraphQL(component = "validateAddress", urlPostFix = "/address/graphql", clientIdOverride="global")
	@GQLQueryName(value = "validateAddress", requestClass = ValidateE911AddressGQLRequest.class)
    Mono<ValidateE911AddressCXPResponse> getValidateAddress(@GQLQueryValue(value = ADDRESS_REQUEST) AddressRequest addressRequest);

	/**
	 *
	 * @param customerId
	 * @return
	 */
	@CXPGraphQL(component = "getCustomerInfo", urlPostFix = "/customerprofile/graphql", clientIdOverride="global")
	@GQLQueryName(value = "customer", requestClass = GetCustomerInfoGQLRequest.class)
    Mono<GetCustomerInfoCXPResponse> getCustomerInfo(@GQLQueryValue(value = "customerId") String customerId);

	/**
	 * Initiate device sim activation.
	 *
	 * @param cxpRequest the cxp request
	 * @return the mono
	 */
	@CXPJson(component = "customer", urlPostFix = "/accountmaintenance/initiate-device-sim-activation")
    Mono<InitiateDeviceSimActivationCxpResponse> initiateDeviceSimActivation(IntiateDeviceSimActivationCXPRequest cxpRequest);


	/**
	 * Initiate E sim activation.
	 *
	 * @param cxpRequest the cxp request
	 * @return the mono
	 */
	@CXPJson(component = "customer", urlPostFix = "/accountmaintenance/initiate-device-sim-activation")
    Mono<InitiateESimActivationCXPResponse> initiateESimActivation(InitiateESimActivationCXPRequest cxpRequest);


	/**
	 *
	 * @param cxpRequest
	 * @return RPSE911AddressUpdateCXPResponse
	 */
	@CXPJson(component = "customer", urlPostFix = "/accountmaintenance/update-e911-address")
    Mono<RPSE911AddressCXPResponse> updateAccountE911Address(RPSE911AddressUpdateCXPRequest cxpRequest);


	/**
    *
    * @param mtn
    * @return
    */
    @CXPGraphQL(component = "customerByMtn", urlPostFix = "/customerprofile/graphql", clientIdOverride="global")
    @GQLQueryName(value = "customerByMtn", requestClass = GetParentLinesGQLRequest.class)
    Mono<GetParentLinesCXPResponse> customerByMtnForParentLines(@GQLQueryValue(value = "mtn") String mtn);


	/**
	 *
	 * @param cartId
	 * @return OrderConfirmationCXPResponse
	 */
	@CXPGraphQL(component = "cart", urlPostFix = "/shopping/graphql", clientIdOverride="global")
	@GQLQueryName(value = "cart", requestClass = OrderConfirmationGQLRequest.class)
    Mono<OrderConfirmationCXPResponse> getOrderConfirmationData(@GQLQueryValue(value = CART_ID) String cartId);

	/*
	  @return bundle accessories information from the cart.
	 */
	@CXPJson(component = "cart", urlPostFix = "/shoppingcart/retrieveCart/{cartId}?lookUp=SINGLE" , isDomainCall=true, methodType= RequestMethod.GET)
    Mono<RetrieveAccCartCXPResponse> retrieveBundleAccessories(@RestUrlParameter("cartId") String cartId);

	@CXPJson(component = "tradein", urlPostFix = "/tradeinservice/retrieve-devices-on-account")
	Mono<TradeinAccountDevicesResponse> getAccountDevicesData(TradeinAccountDevicesRequest req);

	@CXPJson(component = "tradein", urlPostFix = "/tradeinservice/retrieve-device-questions")
	Mono<TradeinAppraisalQuestionsResponse> getAppraisalQuestionsData(TradeinAppraisalQuestionsRequest req);

	@CXPJson(component = "tradein", urlPostFix = "/tradeinservice/retrieve-device-promo")
	Mono<TradeinAppraisalResponse> appraiseDevice(TradeinDeviceAppraisalRequest req);

	@CXPJson(component = "tradein", urlPostFix = "/tradeinservice/device-validation-and-detail")
	Mono<TradeinValidateDeviceResponse> validateDevice(TradeinValidateDeviceRequest req);

	/**
	 *
	 * @param request
	 * @return UpdateConsentCxpResponse
	 */
	@CXPJson(component = "cart", urlPostFix = "/shopping/update-cart")
    Mono<UpdateConsentCxpResponse> updateCustomerConsent(UpdateConsentCxpRequest request);
	
	/**
	 * @param cartId CartID
	 * @param pageId PageId Form UI
	 * @return Mono Type {@link RetrieveLatestDeviceCXPResponse}
	 */
	@CXPGraphQL(component = "retrieveLatestDevice", urlPostFix = "/shopping/graphql", clientIdOverride = "global")
	@GQLQueryName(value = "retrieveLatestDevice", requestClass = RetrieveLatestDeviceGQLRequest.class)
	Mono<RetrieveLatestDeviceCXPResponse> retrieveLatestDevice(@GQLQueryValue(value = CART_ID) String cartId,
															   @GQLQueryValue(value = PAGE_ID) String pageId);

	/**
	 * @param cartId
	 * @param retrieveCurrentFeatures
	 * @return RetrieveCartCXPResponse
	 */
	@CXPGraphQL(component = "cart", urlPostFix = "/shopping/graphql", clientIdOverride = "global")
	@GQLQueryName(value = "cart", requestClass = RetrieveNGACartGQLRequest.class)
	Mono<RetrieveNGACartCXPResponse> retrieveNextGenLatestDevice(@GQLQueryValue(value = CART_ID) String cartId,
																 @GQLQueryValue(value = RETRIEVE_CURRENT_FEATURES) Boolean retrieveCurrentFeatures,
																 @GQLQueryValue(value = "mtnList") List<String> mtnList);

  /**
	 *
	 * @param nbxCxpRequest
	 * @return NbsDataCXPResponse
	 */
  @CXPJson(component = "billing", urlPostFix = "/nbs/get-next-bill-summary")
  Mono<NbsDataCXPResponse> nbsData(NbsDataCXPRequest nbxCxpRequest);

	/**
	 *
	 * @param cartId
	 * @return AddTruckRollCartBPMResponse
	 * @throws SOEHTTPException
	 */
	@CXPGraphQL(component = "cart", urlPostFix = "/shopping/graphql" ,clientIdOverride="global")
	@GQLQueryName(value = "cart", requestClass = GetOrderDetailsGQLRequest.class)
			//requestClass = OrderDetailsRequest.class)
    Mono<OrderReviewDetailsResponse> getOrderReviewDetails(@GQLQueryValue(value = CART_ID) String cartId,
                                                           @GQLQueryValue(value = RETRIEVE_CURRENT_FEATURES) Boolean retrieveCurrentFeatures) throws SOEHTTPException;
	/**
	 * This function is to get the cart details from the PromoQualificaion trhough cxp shopping cart
	 * for the promo bundle builder cart page
	 * @param cartId Read from Redis usally blank from UI
	 * @param pageId Sent from UI as PromoBundleBuilder
	 * @return RetrieveCartCXPResponse
	 */

	@CXPGraphQL(component = "promobundlebuildercart", urlPostFix = "/shopping/graphql", clientIdOverride="global")
	@GQLQueryName(value = "promoBundleBuilderCart", requestClass = BundleBuilderCartLWGQLRequest.class)
	Mono<BundleBuilderCXPResponseData> bundleBuilderCart(@GQLQueryValue(value = CART_ID) String cartId, @GQLQueryValue(value = "pageId") String pageId, @GQLQueryValue(value = "isCachedOffer") boolean isCachedOffer, @GQLQueryValue(value = "selectedOfferId") String selectedOfferId, @GQLQueryValue(value = "isStrategicOfferEnabled") boolean isStrategicOfferEnabled, @GQLQueryValue(value = "accountNumber") String accountNumber, @GQLQueryValue(value = "mtn") String mtn, @GQLQueryValue(value = "offerFilters") List<String> offerFilters,@GQLQueryValue(value = "disableOMP") boolean disableOMP,@GQLQueryValue(value = "transactionMDN") String transactionMDN ,@GQLNamespace List<String> namespaces);

	@CXPJson(component = "loanManagement", urlPostFix = "/loanManagement/search", methodType = RequestMethod.POST, isDomainCall = true, domainName = "CXP")
	Mono<LoanManagementSearchCXPResponse> loanSearchByDeviceId(LoanManagementSearchRequest loanManagementSearchRequest);
	@CXPJson(component = "accountManagement", urlPostFix = "/locationManagement/retrieveGlobalLocationDetails", isDomainCall = true)
	public Mono<RetrieveGlobalLocationDetailsCxpResponse> retrieveGlobalLocationDetails(RetrieveGlobalLocationDetailsCxpRequest request);

	/**
	 *
	 * @param cartId
	 * @return RetrieveCartCXPResponse
	 */
	@CXPGraphQL(component = "deviceCategory", urlPostFix = "/shopping/graphql", clientIdOverride="global")
	@GQLQueryName(value = "validateCartAndUpdate", requestClass = DeviceCategoryCartGQLRequest.class)
	public Mono<ValidateCartCXPResponse> deviceCategory(@GQLQueryValue(value = CART_ID) String cartId, @GQLQueryValue(value = RETRIEVE_CURRENT_FEATURES) Boolean retrieveCurrentFeatures, @GQLQueryValue(value = "mtnList") List<String> mtnList, @GQLQueryValue(value = "customerType") String customerType);

	@CXPJson(domainName="salesmanagement", component = "partyInteraction", urlPostFix = "/partyInteraction/referral", methodType = RequestMethod.PATCH, isDomainCall = true)
	Mono<MylinkReferralInfoResponse> validateMyLinkReferralInfo(MylinkReferralInfoRequest request);
	@CXPGraphQL(component = "validateNextgenCartAndCheckout", urlPostFix = "/shopping/graphql", clientIdOverride="global")
	@GQLQueryName(value = "validateCartAndUpdate", requestClass = DeviceCategoryCartGQLRequest.class)
	public Mono<ValidateNextgenCartAndCheckoutResponse> validateNextgenCartAndCheckout(@GQLQueryValue(value = CART_ID) String cartId, @GQLQueryValue(value = "channel") String channel, @GQLQueryValue(value = "pageId") String pageId, @GQLQueryValue(value = "flow") String flow, @GQLQueryValue(value = RETRIEVE_CURRENT_FEATURES) Boolean retrieveCurrentFeatures, @GQLQueryValue(value = "mtnList") List<String> mtnList, @GQLQueryValue(value = "customerType") String customerType);

	@CXPJson(component = "enforceAdapter", urlPostFix = "/enforceAdapter/fraudIntercept", methodType = RequestMethod.POST, isDomainCall = true)
	Mono<UpdateCreditAppFraudStatusCxpResponse> updateCreditAppFraudStatus(UpdateCreditAppFraudStatusCxpRequest request);

	@CXPJson(component = "productmgmt", urlPostFix = "/productmgmt/multilineProductInquiry", methodType = RequestMethod.POST, isDomainCall = true, domainName = "epsfeatures")
	public Mono<ProductInquiryEPSResponse> getDeviceProductInquiry(ProductInquiryEPSRequest request);

	@CXPJson(component = "enforceAdapter", urlPostFix = "/enforceAdapter/get-customer-pact-verification-result", methodType = RequestMethod.POST, isDomainCall = true)
	public Mono<ScanIdLookUpInfoCXPResponse> scanIdLookupInfo(ScanIdLookUpInfoRequest request);
	
	@CXPJson(component = "cart", methodType = RequestMethod.POST, urlPostFix = "/MDNQueryServices/simEidDetails", isDomainCall = true)
	Mono<SimEidDetailsETNIResponse> simEidDetails(ESimDetailsETNIRequest request);

	@CXPGraphQL(component = "digital", urlPostFix = "/customerprofile/graphql", clientIdOverride="global")
	@GQLQueryName(value = "customer", requestClass = CustomerByIdGQLRequest.class)
	Mono<CustomerProfileByIdCXPResponse> getCustomerProfileAddress(@GQLQueryValue("customerId") String customerId);

	@CXPGraphQL(component = "digitalwithoutrtd", urlPostFix = "/customerprofile/graphql", clientIdOverride="global")
	@GQLQueryName(value = "customer", requestClass = CustomerProfileGraphQLRequest.class)
	Mono<CustomerProfileGraphQLResponse> getCustomerProfileDigitalwihtoutRTD(@GQLQueryValue("customerId") String customerId);

	@CXPJson(component = "loanManagement", urlPostFix = "/loanManagement/installmentLoan?deviceType=IME&deviceId={deviceId}&&showPendingLoanForDeviceId=Y", methodType = RequestMethod.GET, isDomainCall = true, domainName = "CXP")
	Mono<LoanManagementSearchCXPResponse> pendingLoanSearchByDeviceId(@RestUrlParameter("deviceId") String deviceId);

	@CXPJson(component = "cart", methodType = RequestMethod.POST, urlPostFix = "/sapAdapter/deviceInventoryCheck", isDomainCall = true)
	Mono<InventoryStatusCheckResponse> deviceInventoryStatusCheck(InventoryStatusCheckRequest request);

	@CXPJson(component = "cart", methodType = RequestMethod.POST, urlPostFix = "/shopping/calculate-tax-for-configurator")
	Mono<CalculateTaxCXPResponse> calculateTaxforConfigurator(GetTaxDetailsForConfiguratorUIRequest request);

	@CXPJson (component = "spectrumAdapter", urlPostFix = "/spectrumAdapter/retrieveFipsCode", isDomainCall = true)
	public Mono<RetrieveFipsCode> retrieveFipsCode(Map<String,String> retrieveFipsCode);

	@CXPJson(domainName="unifiedtaxengine", component = "tax", urlPostFix = "/pos/calculate-tax", isDomainCall = true)
	public Mono<NGDTaxEngineBaseResponse> callTaxEngineAPI(NGDTaxEngineRequest request);

	@CXPJson(domainName="vvc", component = "cart", urlPostFix = "/vzcardproductManagement/getTempVvcCreditLimit", isDomainCall = true)
	Mono<CartExceedsLimitResponse> getCartExceedsLimitCXPResponse(CartExceedsLimitRequest request);

    @CXPGraphQL (component = "cart", urlPostFix = "/shopping/graphql", clientIdOverride="global")
    @GQLQueryName (value = "cart", requestClass = RetrieveTradeinGQLRequest.class)
    Mono<RetrieveTradeinGQLResponse> retrieveCartTradeinInfo(@GQLQueryValue (value = "cartId") String cartId);

	@CXPJson(component = "ordering", urlPostFix = "/ordering/initiate-checkout", methodType = RequestMethod.POST)
	public Mono<InitiateCheckoutResponse> initiateCheckout(InitiateCheckoutRequest request);

}
