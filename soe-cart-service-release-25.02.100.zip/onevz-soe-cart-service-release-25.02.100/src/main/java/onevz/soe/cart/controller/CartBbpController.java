package onevz.soe.cart.controller;

import java.util.ArrayList;
import java.util.List;

import jakarta.validation.Valid;

import onevz.soe.cart.helper.*;
import onevz.soe.cart.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.exceptions.JsonValidator;
import onevz.soe.cart.model.common.Device;
import onevz.soe.cart.model.common.SoftSKUItem;
import onevz.soe.cart.omnidl.OmniBuilder;
import onevz.soe.cart.requests.BBPRequestVO;
import onevz.soe.cart.responses.AddZipcodeRedisData;
import onevz.soe.cart.responses.BBPFlowRedisData;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.ui.common.AddDeviceData;
import onevz.soe.cart.ui.common.DeviceCartInfo;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.AddDeviceUIRequest;
import onevz.soe.cart.ui.requests.AddZipCodeUIRequest;
import onevz.soe.cart.ui.requests.BBPGetProcessStepUIRequest;
import onevz.soe.cart.ui.requests.BBPPayloadUIRequest;
import onevz.soe.cart.ui.requests.RPSE911AddressUpdateUIRequest;
import onevz.soe.cart.ui.requests.SalesOrderAdjustmentUIRequest;
import onevz.soe.cart.ui.responses.AddDeviceUIResponse;
import onevz.soe.cart.ui.responses.DeviceSimDetailsUIResponse;
import onevz.soe.omnidl.service.OmniDLService;
import onevz.soe.session.client.model.AccountInfoEligible;
import onevz.soe.utilities.StringUtilities;
import reactor.core.publisher.Mono;

/**
 * Cart Controller class.
 */
//NSADT-53978 removing CrossOrigin annotation in every service
//@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping(value = "cart")
public class CartBbpController {

	private static final Logger logger = LoggerFactory.getLogger(CartBbpController.class);
	
	
	@Autowired
	private UpdateCartHelper helper;

	@Autowired
	private RedisHelper redisHelper;

	@Autowired
	private RedisHelper2 redisHelper2;

	@Autowired
	private CartRpsHelper cartRpsHelper;

	@Value("${processingMtnFlag}")
	private String processingMtnFlag;

	@Value("${orderRestrictionCodes}")
	private String orderRestrictionCodes;
	
	@Autowired
	private CartAddDeviceHelper accDevHelper;

	@Autowired
	JsonValidator validator;
	
	@Autowired
	private Environment environment;
	
	@Autowired
	private OmniDLService dlService;
	
	@Autowired
	private CommonUtil util;

	/**
	 * 
	 * @param binder
	 */
	@InitBinder("*")
	public void initBinderByName(WebDataBinder binder) {
		binder.setDisallowedFields(new String[] { "genericHeader" });
	}

	/**
	 * Bbp payload.
	 *
	 * @param httpHeader   the http header
	 * @param httpResponse the http response
	 * @param request      the request
	 * @return the mono
	 */
	@PostMapping({ "/bbpPayload", "/nse/bbpPayload" })
	public Mono<ResponseEntity<Object>> bbpPayload(ServerHttpRequest httpHeader,
			ServerHttpResponse httpResponse, @Valid @RequestBody BBPPayloadUIRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "bbpPayload");
		BBPFlowRedisData rr = new BBPFlowRedisData();
		// Adding a flag to identify the flow type - start
		String flowPath = String.valueOf(httpHeader.getPath());


		if (StringUtilities.isNotEmptyOrNull(flowPath)) {
			if (flowPath.contains("/nse/bbpPayload")) {
				rr.setFlowType("NSE");
			} else {
				rr.setFlowType("EXISTINGCUSTOMER");
			}
		} else {
			rr.setFlowType("");
		}
		// Adding a flag to identify the flow type - end
		if (StringUtilities.isNotEmptyOrNull(request.getIccid())) {
			rr.setBbpiccid(request.getIccid());
		}

		if (StringUtilities.isNotEmptyOrNull(request.getImei())) {
			rr.setBbpimei(request.getImei());
		}

		if (request.getIsSmartphone() != null) {
			rr.setIsSmartphone(request.getIsSmartphone());
		}
		
		if (StringUtilities.isNotEmptyOrNull(request.getImei2())) {
			rr.setBbpimei2(request.getImei2());
			rr.setIsEsimDevice(true);
		}
		else {
			rr.setIsEsimDevice(false);
		}
		
		if(Boolean.FALSE.equals(request.getIsSmartphone())){
			rr.setBbpDefaultZipcodeForTabletFlow(environment.getProperty("bbpDefaultZipcodeForTabletFlow"));
		}

		Mono<Boolean> rpsFlowRedisData = redisHelper2.upsertBBPFlowDataIntoRedis(rr);
		return rpsFlowRedisData.flatMap(data -> {
			if (data) {
				String res = validator.convertObjectToString(rr);
				return Mono.just(ResponseEntity.status(HttpStatus.OK).body(res));
			} else {
				return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new BBPFlowRedisData()));
			}
		});
	}

	/**
	 * Bbp add zip code.
	 *
	 * @param httpHeader   the http header
	 * @param httpResponse the http response
	 * @param request      the request
	 * @return the mono
	 */
	@PostMapping({ "/bbpAddZipcode", "/nse/bbpAddZipcode" })
	public Mono<ResponseEntity<AddZipcodeRedisData>> bbpAddZipCode(ServerHttpRequest httpHeader,
			ServerHttpResponse httpResponse, @Valid @RequestBody AddZipCodeUIRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "bbpAddZipcode");

		AddZipcodeRedisData rr = new AddZipcodeRedisData();
		return util.formatZipcodeRedisData(request, rr);
	}

	@PostMapping({ "/startBBPFlow", "/nse/startBBPFlow" })
	public Mono<ResponseEntity<GenericResponse>> startBBPFlow(ServerHttpRequest httpHeader,
			ServerHttpResponse httpResponse, @Valid @RequestBody BBPRequestVO bbpRequestVO) {
		System.setProperty(CartConstants.ENDPOINT, "startBBPFlow");
		
		BBPFlowRedisData redisData = new BBPFlowRedisData();
		//Adding a flag to identify the flow type - start
		String flowPath = String.valueOf(httpHeader.getPath());


		if(StringUtilities.isNotEmptyOrNull(flowPath)){
			if(flowPath.contains(CartConstants.NSE_START_BBP_FLOW)){
				redisData.setFlowType("NSE");
			}
			else{
				redisData.setFlowType("EXISTINGCUSTOMER");
			}
		}
		else{
			redisData.setFlowType("");
		}
		//Adding a flag to identify the flow type - end
		if (StringUtilities.isNotEmptyOrNull(bbpRequestVO.getIccid())) {
			redisData.setBbpiccid(bbpRequestVO.getIccid());
		}

		if (StringUtilities.isNotEmptyOrNull(bbpRequestVO.getImei())) {
			redisData.setBbpimei(bbpRequestVO.getImei());
		}

		if (StringUtilities.isNotEmptyOrNull(String.valueOf(bbpRequestVO.getIsSmartphone()))) {
			redisData.setIsSmartphone(bbpRequestVO.getIsSmartphone());
		}
		if (StringUtilities.isNotEmptyOrNull(bbpRequestVO.getImei2())) {
			redisData.setBbpimei2(bbpRequestVO.getImei2());
			redisData.setIsEsimDevice(true);
			}
			else {
			redisData.setIsEsimDevice(false);
			}

			if(Boolean.FALSE.equals(bbpRequestVO.getIsSmartphone())){
				redisData.setBbpDefaultZipcodeForTabletFlow(environment.getProperty("bbpDefaultZipcodeForTabletFlow"));

			}
			if (StringUtilities.isNotEmptyOrNull(bbpRequestVO.getDevid())) {
			    redisData.setDevid(bbpRequestVO.getDevid());
		    }
		   if (StringUtilities.isNotEmptyOrNull(bbpRequestVO.getEid())) {
			   redisData.setEid(bbpRequestVO.getEid());
		   }

		Mono<Boolean> rpsFlowRedisData = redisHelper2.upsertBBPFlowDataIntoRedis(redisData);

		// Read the channelId from header
		String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
				? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
				: "";
               return rpsFlowRedisData.flatMap(redisResponse->{
	
                     if(redisResponse) {
	                 logger.info("Data is stored in redis: {}", redisResponse);
                      }
                     else {
	                 logger.info("Data is not stored in redis");
                      }		



		return redisHelper.getDataFromRedis().flatMap(data -> {
			logger.info("startBBPFLow getDataFromRedis {}", data);
			return helper.initiateBBPFlow(data).flatMap(resp -> {

				AccountInfoEligible accountInfoEligible = new AccountInfoEligible();
				accountInfoEligible.setAccountEligibleForBYOD(true);
				return redisHelper2.upsertAccountInfoEligibleInRedis(accountInfoEligible).flatMap(acc -> {
					logger.info("upsertAccountInfoEligibleInRedis: {}", acc);

					if (resp.getErrors() != null) {
						return Mono.just(ResponseEntity.status(HttpStatus.OK).body(resp));
					}

					//New Customer
					String sessionId = "";
					if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId)))
						sessionId = null != httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION)
								? httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION).getValue()
								: "";

					//setting intent for new customer bbp flow
					String flowPath1 = String.valueOf(httpHeader.getPath());


					AddDeviceUIRequest addDeviceUIRequest = populateAddDeviceflow(resp, data,flowPath1,sessionId,bbpRequestVO);
					addDeviceUIRequest.setChannelId(channelId);

					logger.info("addDeviceUIRequest: {}", addDeviceUIRequest);
					return accDevHelper.addDevice(addDeviceUIRequest,httpResponse).flatMap(addDevicePegaResponse -> {
						ErrorResponse errorResponse = null;
						CartRedisData rr = new CartRedisData();
							
						if (addDevicePegaResponse.getErrors() != null) {
							errorResponse = CartPegaResponseErrorsUtil
									.handleAddDeviceResponseErrors(addDevicePegaResponse);
							return Mono
									.just(ResponseEntity.status(HttpStatus.OK).body(errorResponse));
						} else {
							
							if(StringUtilities.isNotEmptyOrNull(redisData.getFlowType())) {
								addDevicePegaResponse.setFlowType(redisData.getFlowType());
							}
							
							if(addDevicePegaResponse.getServiceBody()!=null && addDevicePegaResponse.getServiceBody()
									.getServiceResponse().getContext() != null && addDevicePegaResponse.getServiceBody()
											.getServiceResponse().getContext().getCustomerInfo()!=null &&
											addDevicePegaResponse.getServiceBody()
											.getServiceResponse().getContext().getCustomerInfo().getDeviceType()==null) {
								addDevicePegaResponse.getServiceBody()
								.getServiceResponse().getContext().getCustomerInfo().setDeviceType(addDeviceUIRequest.getCartInfo().getDeviceType());
							}
							
							if(addDevicePegaResponse.getServiceBody()!=null && addDevicePegaResponse.getServiceBody()
									.getServiceResponse().getContext() != null && addDevicePegaResponse.getServiceBody()
											.getServiceResponse().getContext().getCustomerInfo()!=null &&
											addDevicePegaResponse.getServiceBody()
											.getServiceResponse().getContext().getCustomerInfo().getDeviceType()!=null) {
								rr.setDeviceType(addDevicePegaResponse.getServiceBody()
										.getServiceResponse().getContext().getCustomerInfo().getDeviceType());
							}
							
							if (null != addDevicePegaResponse.getServiceBody() && addDevicePegaResponse.getServiceBody()
									.getServiceResponse().getContext() != null) {
								util.formatRedisData(rr, addDevicePegaResponse, addDeviceUIRequest);
								if(StringUtilities.isNotEmptyOrNull(flowPath) && flowPath.contains(CartConstants.NSE_START_BBP_FLOW)) {
									rr.setBbpIntent(CartConstants.NSE_BYOD);
								}
								else {
									if (StringUtilities
											.isNotEmptyOrNull(addDeviceUIRequest.getCartInfo().getAccountNumber()))
										rr.setAccountNumber(addDeviceUIRequest.getCartInfo().getAccountNumber());
									if (StringUtilities.isNotEmptyOrNull(addDeviceUIRequest.getCartInfo().getCartCreator()))
										rr.setCartCreator(addDeviceUIRequest.getCartInfo().getCartCreator());
									rr.setBbpIntent("BYOD");
								}
								if (resp.getUiData().getDeviceInfo() != null
										&& resp.getUiData().getDeviceInfo().getMfgCode() != null
										&& "APL".equalsIgnoreCase(resp.getUiData().getDeviceInfo().getMfgCode())) {
									rr.setIsAppleDevice(true);

								}
								if (StringUtilities.isNotEmptyOrNull(bbpRequestVO.getEid())) {
									if (StringUtilities
											.isNotEmptyOrNull(resp.getUiData().getDeviceInfo().getDacc())) {
										if(StringUtilities.isNotEmptyOrNull(data.getEsimType())) {
											logger.info("esimType value from redis for bbpflow: {}", data.getEsimType());
											addDevicePegaResponse.setESimType(data.getEsimType());
										}
									}
								}	
								// adding isSmartPhone to add device response
								logger.info("isSmartphone value from redis: {}", data.getIsSmartphone());
								addDevicePegaResponse.getServiceBody().getServiceResponse().getContext()
										.setIsSmartPhone(data.getIsSmartphone());
								//NSADT-145273 changes
								if(StringUtilities.isNotEmptyOrNull(data.getEsimType())) {
									logger.info("esimType value from redis: {}", data.getEsimType());
									addDevicePegaResponse.setESimType(data.getEsimType());
									}
								//hiding sensitive info for BBP - VZWYN-18780
                                CartPegaResponseUtil.formatResponseForBBPChannel(addDevicePegaResponse.getServiceHeader(),addDevicePegaResponse.getServiceBody().getServiceResponse());
							}
						}
						try {
							updateDLData(addDevicePegaResponse);
						} catch (Exception e) {
							logger.error(CartConstants.RETRIEVE_OMNIDL_EXCEPTION, e);
						}
						logger.info("Before storing caseId and cartid in Redis: {} ", rr);
						return redisHelper2.upsertAddDeviceDataIntoRedis(rr).map(data1 -> {
							logger.info("CaseId and cartid stored in Redis: {}", data1);

							return ResponseEntity.status(HttpStatus.OK).body(addDevicePegaResponse);
						});

					});

				});
			});

		});
	});
	}

	/**
	 * 
	 * @param resp
	 * @param data
	 * @return uiRequest
	 */
	public AddDeviceUIRequest populateAddDeviceflow(DeviceSimDetailsUIResponse resp, CartRedisData data,String flowPath,String sessionId,BBPRequestVO bbpRequestVO) {

		AddDeviceUIRequest addDeviceUIRequest = new AddDeviceUIRequest();
		DeviceCartInfo deviceCartInfo = new DeviceCartInfo();
		deviceCartInfo.setAccountNumber(data.getAccountNumber());
		deviceCartInfo.setCartCreator(data.getCartCreator());

		deviceCartInfo.setMtnFlow("");
		deviceCartInfo.setIntendType("BYOD");
		deviceCartInfo.setProcessStep("");
		deviceCartInfo.setProcessAction(CartConstants.ADD_DEVICE);
		deviceCartInfo.setClientAppName(CartConstants.VZW_BBP);
		deviceCartInfo.setNumberShareCapable("Y");
		deviceCartInfo.setENineAddrIndicator("True");
		if(resp.getUiData().getDeviceInfo()!=null && StringUtilities.isNotEmptyOrNull(resp.getUiData().getDeviceInfo().getDeviceCategory()) && resp.getUiData().getDeviceInfo().getDeviceCategory().contains(CartConstants.PHONE)) {
			deviceCartInfo.setDeviceType(CartConstants.DEVICETYPE_PHONE);
		}
		else if( resp.getUiData().getDeviceInfo()!=null && StringUtilities.isNotEmptyOrNull( resp.getUiData().getDeviceInfo().getLaunchPackageSku()) && CartConstants.RING_LAUNCHPACKAGESKU.equalsIgnoreCase(resp.getUiData().getDeviceInfo().getLaunchPackageSku()) 
				||resp.getUiData().getDeviceInfo()!=null && StringUtilities.isNotEmptyOrNull(resp.getUiData().getDeviceInfo().getProdName()) && resp.getUiData().getDeviceInfo().getProdName().toLowerCase().contains(CartConstants.RING_PRODNAME)) {
			deviceCartInfo.setDeviceType(CartConstants.DEVICETYPE_RING);
		}
		else if(resp.getUiData().getDeviceInfo()!=null && StringUtilities.isNotEmptyOrNull(resp.getUiData().getDeviceInfo().getDacc())&& environment.getProperty(CartConstants.SDK_TRACKER_DACCS).contains(resp.getUiData().getDeviceInfo().getDacc()) 
				||resp.getUiData().getDeviceInfo()!=null && StringUtilities.isNotEmptyOrNull(resp.getUiData().getDeviceInfo().getProdType()) && CartConstants.TRACKER_PRODTYPE.equalsIgnoreCase(resp.getUiData().getDeviceInfo().getProdType())) {
			deviceCartInfo.setDeviceType(CartConstants.DEVICETYPE_TRACKER);
		}
		else if(resp.getUiData().getDeviceInfo()!=null && StringUtilities.isNotEmptyOrNull(resp.getUiData().getDeviceInfo().getDacc()) && environment.getProperty(CartConstants.SDK_GIZMO_DACCS).contains(resp.getUiData().getDeviceInfo().getDacc())  
				||resp.getUiData().getDeviceInfo()!=null && StringUtilities.isNotEmptyOrNull(resp.getUiData().getDeviceInfo().getLaunchPackageSku()) && CartConstants.GIZMO_LAUNCHPACKAGESKU.contains(resp.getUiData().getDeviceInfo().getLaunchPackageSku()) 
				) {
			deviceCartInfo.setDeviceType(CartConstants.DEVICETYPE_GIZMO);
		}
		else if (resp.getUiData().getDeviceInfo()!=null && StringUtilities.isNotEmptyOrNull(resp.getUiData().getDeviceInfo().getDacc()) && environment.getProperty(CartConstants.SDK_GARMIN_DACCS).contains(resp.getUiData().getDeviceInfo().getDacc())) {
			deviceCartInfo.setDeviceType(CartConstants.DEVICETYPE_GARMIN);
		}
		else if(resp.getUiData().getDeviceInfo()!=null && StringUtilities.isNotEmptyOrNull(resp.getUiData().getDeviceInfo().getDeviceCategory()) && resp.getUiData().getDeviceInfo().getDeviceCategory().contains(CartConstants.TABLET)
				||resp.getUiData().getDeviceInfo()!=null && StringUtilities.isNotEmptyOrNull(resp.getUiData().getDeviceInfo().getDeviceCategory()) && environment.getProperty(CartConstants.TABLET_DEVICE_CATEGORY).contains(resp.getUiData().getDeviceInfo().getDeviceCategory().toLowerCase())) {
			deviceCartInfo.setDeviceType(CartConstants.DEVICETYPE_TABLET);
		}
		//VZWYN-22202 Changes
		if(null != bbpRequestVO.getIsConnectedCarRequired()) {
			deviceCartInfo.setIsConnectedCarRequired(bbpRequestVO.getIsConnectedCarRequired());
		}
		addDeviceUIRequest.setCartInfo(deviceCartInfo);
		AddDeviceData addDeviceData = new AddDeviceData();
		//VZWYN-17835 changes
		if(null != bbpRequestVO && StringUtilities.isNotEmptyOrNull(bbpRequestVO.getChannelId()) && CartConstants.CHANNEL_ID_BBP.equalsIgnoreCase(bbpRequestVO.getChannelId())) {
			if(StringUtilities.isNotEmptyOrNull(bbpRequestVO.getEsimFlowType())){
				addDeviceData.setEsimFlowType(bbpRequestVO.getEsimFlowType());
			}
			if(null != data
					&& StringUtilities.isNotEmptyOrNull(data.getEsimType())){
				addDeviceData.setEsimType(data.getEsimType());
			}
		}
		List<Lines> lines = new ArrayList<>();
		Lines line = new Lines();
		Device device = new Device();
		if (resp.getUiData().getDeviceInfo() != null && StringUtilities.isNotEmptyOrNull(resp.getUiData().getDeviceInfo().getImSku())) {
			device.setId(resp.getUiData().getDeviceInfo().getImSku());
		}
		else if(resp.getUiData().getDeviceInfo() != null && StringUtilities.isNotEmptyOrNull(resp.getUiData().getDeviceInfo().getLaunchPackageSku())) {
			device.setId(resp.getUiData().getDeviceInfo().getLaunchPackageSku());
		}
		if (resp.getUiData().getDeviceInfo() != null && resp.getUiData().getDeviceInfo().getDeviceId() != null) {
			device.setDeviceId(resp.getUiData().getDeviceInfo().getDeviceId());
		}
		device.setContractTerm("MONTH_TO_MONTH");
		if(bbpRequestVO!=null && StringUtilities.isNotEmptyOrNull(bbpRequestVO.getChannelId()) && CartConstants.CHANNEL_ID_BBP.equalsIgnoreCase(bbpRequestVO.getChannelId()) && resp!=null && resp.getUiData()!=null &&  resp.getUiData().getEsimFlow()!=null && resp.getUiData().getEsimFlow()){
			device.setByodESimPhone(true);
			device.setSmartIMEI(false);
		}
		line.setMtn("");
		if(data!=null && StringUtilities.isNotEmptyOrNull(data.getEsimFlowType()) && CartConstants.LOST_ICCID_PROFILE.equalsIgnoreCase(data.getEsimFlowType()) && StringUtilities.isNotEmptyOrNull(data.getPendingMdn())){
			line.setMtn(data.getPendingMdn());
		}
		line.setDevice(device);

		line.setIspuFlow(false);
		line.setDepletionType("F");
		line.setIsKeepingExistingEqProtection(true);
		line.setDepletionLocationCode("");

		deviceCartInfo.setBbpIntent("BYOD");
		deviceCartInfo.setTriggerPricingValidation(true);
		line.setNumbersharePairingMode("STANDALONE");

		SoftSKUItem softSKUItem = new SoftSKUItem();
		if(resp!=null && resp.getUiData()!=null && resp.getUiData().getSimInfo()!=null && StringUtilities.isNotEmptyOrNull(resp.getUiData().getSimInfo().getImSku())) {
		softSKUItem.setId(resp.getUiData().getSimInfo().getImSku());
		}
		if(bbpRequestVO!=null && StringUtilities.isNotEmptyOrNull(bbpRequestVO.getChannelId()) && CartConstants.CHANNEL_ID_BBP.equalsIgnoreCase(bbpRequestVO.getChannelId()) && resp!=null && resp.getUiData()!=null &&  resp.getUiData().getEsimFlow()!=null && resp.getUiData().getEsimFlow()&& resp.getUiData().getESimInfo()!=null && StringUtilities.isNotEmptyOrNull(resp.getUiData().getESimInfo().getPreferredSoftSim())){
			softSKUItem.setId(resp.getUiData().getESimInfo().getPreferredSoftSim());
		}
		if (resp.getUiData().getSimInfo() != null && resp.getUiData().getSimInfo().getSimId() != null) {
			softSKUItem.setIccid(resp.getUiData().getSimInfo().getSimId());
		}
		softSKUItem.setIsCustomerProvidedSIM(true);

		if (bbpRequestVO != null && StringUtilities.isNotEmptyOrNull(bbpRequestVO.getEid())) {
			softSKUItem.setESIM(bbpRequestVO.getEid());
			
		}
		
		else if(resp!=null && resp.getUiData()!=null && resp.getUiData().getESimInfo()!=null && StringUtilities.isNotEmptyOrNull(resp.getUiData().getESimInfo().getEID())) {
			softSKUItem.setESIM(resp.getUiData().getESimInfo().getEID());
		}
		
		if (bbpRequestVO != null &&  StringUtilities.isNotEmptyOrNull(bbpRequestVO.getImei2())) {
			softSKUItem.setImei2(bbpRequestVO.getImei2());
			
		}
		line.setSim(softSKUItem);
		line.setIspuFlow(false);
		line.setDepletionType("F");
		line.setDepletionLocationCode("");

		if ("BYOD".equalsIgnoreCase(deviceCartInfo.getIntendType())) {

			line.setIsNewLine(true);
			line.setNewLineOrAAL(true);
		}

		if(StringUtilities.isNotEmptyOrNull(flowPath) && flowPath.contains(CartConstants.NSE_START_BBP_FLOW)) {
			deviceCartInfo.setIntendType(CartConstants.NSE_BYOD);
			deviceCartInfo.setBbpIntent(CartConstants.NSE_BYOD);
			// Updating cartCreator and globalId with sessionId for New customer flow NSA

			deviceCartInfo.setCartCreator(sessionId);
			deviceCartInfo.setGlobalId(sessionId);
			}
		deviceCartInfo.setSessionId(sessionId);
		lines.add(line);

		addDeviceData.setLines(lines);
		addDeviceUIRequest.setData(addDeviceData);

		return addDeviceUIRequest;
	}
	

	public void updateDLData(AddDeviceUIResponse addDeviceUIResponse) {
		dlService.buildDLData(OmniBuilder.buildBBPData(addDeviceUIResponse));
	}

	/**
	 * 
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return genericResponse
	 */
	@PostMapping("/salesOrderAdjustment")
	public Mono<ResponseEntity<GenericResponse>> salesOrderAdjustment(ServerHttpRequest httpHeader,
			ServerHttpResponse httpResponse, @Valid @RequestBody SalesOrderAdjustmentUIRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "salesOrderAdjustment");


		// Read the channelId from header
		String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
				? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
				: "";
		request.setChannelId(channelId);

		ErrorResponse errors = CartPegaRequestErrorsUtil.handleSalesOrderAdjustmentRequestErrors(request);
		if (errors.getErrors() != null)
			return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
		return helper.salesOrderAdjustment(request).flatMap(pegaResponse -> {

			return Mono.just(ResponseEntity.status(HttpStatus.OK).body(pegaResponse));

		});
	}

	/**
	 * Bbp get process step.
	 *
	 * @param httpHeader   the http header
	 * @param httpResponse the http response
	 * @param request      the request
	 * @return the mono
	 */
	@PostMapping({ "/bbpGetProcessStep", "/nse/bbpGetProcessStep" })
	public Mono<ResponseEntity<GenericResponse>> bbpGetProcessStep(ServerHttpRequest httpHeader,
			ServerHttpResponse httpResponse, @Valid @RequestBody BBPGetProcessStepUIRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "bbpGetProcessStep");
		String flowPath = String.valueOf(httpHeader.getPath());
		String sessionId = "";
		if (StringUtilities.isNotEmptyOrNull(flowPath) && flowPath.contains("/nse/bbpGetProcessStep")) {
			request.getCartInfo().setCustomerType(CartConstants.NEW_CUSTOMER);
			HttpCookie cookies = httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION);
			sessionId = null != cookies
					? cookies.getValue()
					: "";
			request.getCartInfo().setCartCreator(sessionId);
		}
		logger.debug("bbpGetProcessStep Request: {}", request);

		return helper.bbpGetProcessStep(request).map(pegaResponse -> {
			ErrorResponse errors2 = null;
			if (pegaResponse.getErrors() != null) {
				errors2 = CartPegaResponseErrorsUtil2.handlebbpGetProcessStepErrors(pegaResponse);
			}
			return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
					: ResponseEntity.status(HttpStatus.OK).body(pegaResponse);

		});

	}
	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return ResponseEntity
	 *
	 */
	@PostMapping("/validateE911Address")
	public Mono<ResponseEntity<GenericResponse>> validateE911Address(ServerHttpRequest httpHeader,
																   ServerHttpResponse httpResponse,
																	 @Valid @RequestBody RPSE911AddressUpdateUIRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "e911-address");
		logger.debug("E911Address validate Request: {}", request);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleRPSE911AddressUpdateRequestErrors(request);
		if (errors.getErrors() != null)
			return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
		return cartRpsHelper.validateE911Address(request).map(cxpResponse -> {
			ErrorResponse errors2 = null;
			if (cxpResponse.getErrors() != null && !httpResponse.getStatusCode().is2xxSuccessful()) {
				errors2 = CartPegaResponseErrorsUtil2.handleValidateE911AddressResponseErrors(cxpResponse);
			}
			return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
					: ResponseEntity.status(HttpStatus.OK).body(cxpResponse);
			 });

	}

}
