package onevz.soe.cart.helper;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.common.SecondNumber;
import onevz.soe.cart.model.flexVtwo.SessionResponse;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.DualNumber;
import onevz.soe.cart.responses.FiveGAddressRedisData;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.util.FlexV2Util;
import onevz.soe.customerprofile.model.gql.assisted.Mtn;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class CartRequestBuilder {

    private static final Logger logger = LoggerFactory.getLogger(CartRequestBuilder.class);
    

    public void buildAddDeviceRequest(AddDeviceUIRequest request, CartRedisData cartSession){
        SessionResponse sessionResponse = new SessionResponse();
        FlexV2Util.updateSessionResponseData(cartSession,sessionResponse);

        if(request.getData() != null && request.getData().getLines() != null) {

            if (request.getCartInfo() != null){
                if(StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType())) {
                    request.getCartInfo().setIntendType(CartIntendTypeBuilder.CartActions.ADD_DEVICE.getIntendType(request.getData().getLines(), sessionResponse));
                    logger.info(CartConstants.INTEND_TYPE, request.getCartInfo().getIntendType());
                }
                if(StringUtilities.isEmptyOrNull(request.getCartInfo().getCartCreator())
                        && StringUtilities.isNotEmptyOrNull(FlexV2Util.getCartCreatorFromCart(sessionResponse)) )
                    request.getCartInfo().setCartCreator(FlexV2Util.getCartCreatorFromCart(sessionResponse));

            }
            if(CollectionUtilities.isNotEmptyOrNull(request.getData().getLines())){

                request.getData().getLines().stream().filter(Objects::nonNull).forEach(lineData ->{
                    if(request.getData().getLines().size() > 1){
                        checkAndUpdateDualNumberDetails( lineData, cartSession, request );
                    }
                    if(FlexV2Util.isNewline(request)){
                        lineData.setNewLineOrAAL(true);
                        lineData.setIsNewLine(true);
                    }
                    if(null == lineData.getMultiLineSeqNumber() && lineData.getMtn() != null) {
                        lineData.setMultiLineSeqNumber(FlexV2Util.getMultiLineSeqNumberFromCart(sessionResponse, lineData.getMtn()));
                    }
                    lineData.setTriggerPricingValidation(true); //Always true - Rama
                });
                if(request.getSecondNumber() != null){
                    updateDualNumInSessionObject( request, cartSession );
                }
            }
        }
    }
    public void checkAndUpdateDualNumberDetails(Lines line,CartRedisData sessionResponse,AddDeviceUIRequest request ){
        if(line.getMtn() != null && sessionResponse.getCustomerProfile() != null && FlexV2Util.isAccountHasBillAcc(sessionResponse.getCustomerProfile())){
            sessionResponse.getCustomerProfile().getData().getCustomer().getBillAccounts().forEach(cxpMtnList -> {
                if (cxpMtnList != null && cxpMtnList.getMtns() != null) {
                    cxpMtnList.getMtns().stream().filter(mtnObj ->  mtnObj.getMtn() != null && line.getMtn().equalsIgnoreCase(mtnObj.getMtn())).forEach(obj -> {
                        updateSecondNumberDetails( line , request , obj);
                    });
                }
            });
        }
    }
    public void updateSecondNumberDetails(Lines line , AddDeviceUIRequest request , Mtn obj){

        if(obj.getPrimaryNumber() != null && obj.getPrimaryNumber()){
            line.setPurchasePath("EUP");
            if(request.getSecondNumber() == null){
                request.setSecondNumber(new SecondNumber());
            }
            request.getSecondNumber().setPrimaryMtn(line.getMtn());

        }else if(obj.getSecondaryNumber() != null && obj.getSecondaryNumber()){
            line.setPurchasePath("EUPBYOD");
            if(request.getSecondNumber() == null){
                request.setSecondNumber(new SecondNumber());
            }
            request.getSecondNumber().setSecondMtn(line.getMtn());
            request.getSecondNumber().setIsSecondNumber(true);
        }
    }
    public void updateDualNumInSessionObject(AddDeviceUIRequest request,CartRedisData cartSession){
       if(cartSession.getDualNumber() != null && cartSession.getDualNumber().getSecondNumber() != null && CollectionUtilities.isNotEmptyOrNull(cartSession.getDualNumber().getSecondNumber()) ){
           cartSession.getDualNumber().getSecondNumber().add(request.getSecondNumber());
       }else{
           cartSession.setDualNumber(new DualNumber());
           List<SecondNumber> secondNumber = new ArrayList<>();
           secondNumber.add(request.getSecondNumber());

           cartSession.getDualNumber().setSecondNumber(secondNumber);
       }
    }
    public void buildRemoveLinesRequest(RemoveLinesUIRequest request, CartRedisData cartSession) {
        SessionResponse sessionResponse = new SessionResponse();
        FlexV2Util.updateSessionResponseData(cartSession, sessionResponse);

        if (request.getData() != null && request.getData().getLines() != null && request.getData().getLines().length > 0) {
            List<Lines> lines = Arrays.asList(request.getData().getLines());

            if (request.getCartInfo() != null) {
                if (StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType())) {
                    request.getCartInfo().setIntendType(CartIntendTypeBuilder.CartActions.REMOVE_LINES.getIntendType(lines, sessionResponse));
                    logger.info(CartConstants.INTEND_TYPE, request.getCartInfo().getIntendType());
                }
            }
        }
    }
    public void buildAddPlanRequest(AddPlanUIRequest request, CartRedisData cartSession){
        SessionResponse sessionResponse = new SessionResponse();
        FlexV2Util.updateSessionResponseData(cartSession,sessionResponse);

        if(request.getData() != null && request.getData().getLines() != null) {

            List<Lines> lines = Arrays.asList(request.getData().getLines());
            if (request.getCartInfo() != null) {
                if (StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType())) {
                    request.getCartInfo().setIntendType(CartIntendTypeBuilder.CartActions.ADD_PLAN.getIntendType(lines, sessionResponse));
                    logger.info(CartConstants.INTEND_TYPE, request.getCartInfo().getIntendType());
                }

                if (StringUtilities.isEmptyOrNull(request.getCartInfo().getCartCreator())
                        && StringUtilities.isNotEmptyOrNull(FlexV2Util.getCartCreatorFromCart(sessionResponse)))
                    request.getCartInfo().setCartCreator(FlexV2Util.getCartCreatorFromCart(sessionResponse));

                //Append address Qualification SessionData
                try {
                    if (Optional.ofNullable(cartSession.getAddressQualificationSessionData()).isPresent() && Optional.ofNullable(cartSession.getAddressQualificationSessionData().getData()).isPresent()) {
                        lines.forEach(uiReq -> cartSession.getAddressQualificationSessionData().getData().stream()
                                .filter(sessionData -> uiReq.getMtn() != null && sessionData.getMtn() != null && uiReq.getPlan() != null &&
                                        sessionData.getNetWorkBandwidthType() != null && sessionData.getMtn().equalsIgnoreCase(uiReq.getMtn()))
                                .findFirst()
                                .ifPresent(matchedMap -> uiReq.getPlan().setNetworkBandwidthType(matchedMap.getNetWorkBandwidthType())));
                        logger.info("Session value successfully updated in the request for networkBandwidthType");
                    }
                } catch (Exception e) {
                    logger.error("Exception in updating the session value in the request for networkBandwidthType");
                }
            }
        }
    }

    public void buildCreateLineRequest(CreateLineUIRequest request, CartRedisData cartSession){
        SessionResponse sessionResponse = new SessionResponse();
        FlexV2Util.updateSessionResponseData(cartSession,sessionResponse);

        if(request.getData() != null && request.getData().getLines() != null) {

            List<Lines> lines = request.getData().getLines();

            if(request.getCartInfo() != null){
                if(StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType())) {
                    request.getCartInfo().setIntendType(CartIntendTypeBuilder.CartActions.NEW_LINE.getIntendType(lines, sessionResponse));
                    logger.info(CartConstants.INTEND_TYPE, request.getCartInfo().getIntendType());
                }
                if(cartSession.getDualNumber()!=null){
                    request.getData().setDualNumber(cartSession.getDualNumber());
                }
            }
        }
    }

    public void buildAssignMtnRequest(AssignMtnUIRequest request, CartRedisData cartSession, FiveGAddressRedisData fiveGAddressRedisData){
        SessionResponse sessionResponse = new SessionResponse();
        FlexV2Util.updateSessionResponseData(cartSession,sessionResponse);
        sessionResponse.setChannelId(request.getChannelId());
        if(fiveGAddressRedisData != null)
            sessionResponse.setFiveGAddressRedisData(fiveGAddressRedisData);

        if(request.getData() != null && request.getData().getLines() != null) {
            List<Lines> lines = request.getData().getLines();

            if(request.getCartInfo() != null){
                if(StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType())) {
                    request.getCartInfo().setIntendType(CartIntendTypeBuilder.CartActions.ASSIGN_MTN.getIntendType(lines, sessionResponse));
                    logger.info(CartConstants.INTEND_TYPE, request.getCartInfo().getIntendType());
                }
            }
        }
    }

    public void buildUserInfoRequest(UpdateUserInfoUIRequest request, CartRedisData cartSession) {
//        if(StringUtilities.isEmptyOrNull(request.getCartId()) && StringUtilities.isNotEmptyOrNull(cartSession.getCartId()))
//            request.setCartId(cartSession.getCartId());
        if (StringUtilities.isEmptyOrNull(request.getIntendType())) {
            if (StringUtilities.isNotEmptyOrNull(cartSession.getCustomerType())
                    && CartConstants.NEW_CUSTOMER.equalsIgnoreCase(cartSession.getCustomerType()))
                request.setIntendType(CartConstants.NSE);
            else {
                if (isPreToPostFlow(cartSession)) {
                    if(cartSession.getRetrieveCart().getCart().getLineDetails() != null
                            && cartSession.getRetrieveCart().getCart().getLineDetails().getLineInfo() != null
                            && CollectionUtilities.isNotEmptyOrNull(Arrays.asList(cartSession.getRetrieveCart().getCart().getLineDetails().getLineInfo())))
                        Arrays.stream(cartSession.getRetrieveCart().getCart().getLineDetails().getLineInfo()).forEach(line -> {
                            if (CartConstants.AAL.equalsIgnoreCase(line.getLineActivityType())
                                    || CartConstants.AAL_LTE.equalsIgnoreCase(line.getLineActivityType())
                                    || CartConstants.NSE.equalsIgnoreCase(line.getLineActivityType())
                                    || CartConstants.NSE_LTE.equalsIgnoreCase(line.getLineActivityType())
                                    || CartConstants.BYOD.equalsIgnoreCase(line.getLineActivityType())
                                    || CartConstants.AAL_5G.equalsIgnoreCase(line.getLineActivityType())
                                    || CartConstants.NSE_5G.equalsIgnoreCase(line.getLineActivityType())
                                    ||  CartConstants.NSE_BYOD.equalsIgnoreCase(line.getLineActivityType()))
                                request.setIntendType(line.getLineActivityType());
                            else request.setIntendType(CartConstants.AAL);
                        });
                } else {
                    request.setIntendType(CartConstants.AAL);
                }
            }
        }
    }

    public void buildValidateDeviceSimIdRequest(DeviceIdValidationUIRequest request, CartRedisData cartSession) {
        SessionResponse sessionResponse = new SessionResponse();
        FlexV2Util.updateSessionResponseData(cartSession, sessionResponse);

        List<Lines> lines = new ArrayList<>();
        buildLines(request,lines);

        if (request.getCartInfo() != null && lines != null) {

            if (StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType())) {
                request.getCartInfo().setIntendType(CartIntendTypeBuilder.CartActions.VALIDATE_DEVICE_SIMID.getIntendType(lines, sessionResponse));
                logger.info(CartConstants.INTEND_TYPE, request.getCartInfo().getIntendType());
            }
            if(StringUtilities.isEmptyOrNull(request.getCartInfo().getIntent())){
                request.getCartInfo().setIntent(request.getCartInfo().getIntendType());
                if(StringUtilities.isNotEmptyOrNull(cartSession.getFlow()) && cartSession.getFlow().equalsIgnoreCase(CartConstants.REFUND_EXC))
                    request.getCartInfo().setIntent(CartConstants.REFUND_EXCHANGE);
            }

            if (StringUtilities.isEmptyOrNull(request.getCartInfo().getCartCreator())
                    && StringUtilities.isNotEmptyOrNull(FlexV2Util.getCartCreatorFromCart(sessionResponse))) {
                request.getCartInfo().setCartCreator(FlexV2Util.getCartCreatorFromCart(sessionResponse));
            }
        }
    }

    private void buildLines(DeviceIdValidationUIRequest request, List<Lines> lines){
        Lines line = new Lines();
        if(request.getData() != null && request.getData().getLines() != null && request.getData().getLines().get(0) != null) {
            line.setMtn(request.getData().getLines().get(0).getMtn());

            if(request.getCartInfo() != null) {
                if ("BYODDeviceIDPage".equalsIgnoreCase(request.getCartInfo().getProcessStep()))
                    line.setByod(true);
            }
            lines.add(line);
        }
    }

    private boolean isPreToPostFlow(CartRedisData cartSession){
        return (cartSession.getRetrieveCart() != null && cartSession.getRetrieveCart().getCart() != null
                && cartSession.getRetrieveCart().getCart().getOrderDetails() != null
                && cartSession.getRetrieveCart().getCart().getOrderDetails().getNewPreToPostInfo() != null
                && StringUtilities.isNotEmptyOrNull(cartSession.getRetrieveCart().getCart().getOrderDetails().getNewPreToPostInfo().getNewPreToPostIndicator())
                && "E".equalsIgnoreCase(cartSession.getRetrieveCart().getCart().getOrderDetails().getNewPreToPostInfo().getNewPreToPostIndicator())
                && cartSession.getRetrieveCart().getCart().getOrderDetails().getNewPreToPostInfo().getNewPreToPostMtns() != null
                && (StringUtilities.isNotEmptyOrNull(cartSession.getRetrieveCart().getCart().getOrderDetails().getNewPreToPostInfo().getNewPreToPostMtns().getAccountOwner())
                    || (cartSession.getRetrieveCart().getCart().getOrderDetails().getNewPreToPostInfo().getNewPreToPostMtns().getAccountMembers() != null
                        && CollectionUtilities.isNotEmptyOrNull(Arrays.asList(cartSession.getRetrieveCart().getCart().getOrderDetails().getNewPreToPostInfo().getNewPreToPostMtns().getAccountMembers())))));
    }

    public void setDualNumberForAddDeviceRequest(AddDeviceUIRequest request, DualNumber data) {
        if (request != null && request.getData() != null && CollectionUtilities.isNotEmptyOrNull(request.getData().getLines())) {
            request.getData().getLines().stream().filter(line -> null != line && StringUtilities.isNotEmptyOrNull(line.getMtn())).forEach(line -> {
                if (CollectionUtilities.isNotEmptyOrNull(data.getSecondNumber())) {
                    data.getSecondNumber().stream().filter(dualNumber -> dualNumber != null && StringUtilities.isNotEmptyOrNull(dualNumber.getSecondMtn()) && dualNumber.getSecondMtn().equalsIgnoreCase(line.getMtn())).forEach(line::setSecondNumber);
                }
            });
        }
    }

    public void buildAddAccessoryRequest(AddAccessoriesUIRequest request, CartRedisData cartSession) {
        SessionResponse sessionResponse = new SessionResponse();
        FlexV2Util.updateSessionResponseData(cartSession, sessionResponse);

        if (request.getData() != null && request.getData().getLines() != null && request.getData().getLines().length > 0) {
            List<Lines> lines = Arrays.asList(request.getData().getLines());

            request.getCartInfo().setIntendType(CartIntendTypeBuilder.CartActions.ADD_ACCESSORY.getIntendType(lines, sessionResponse));
            logger.info(CartConstants.INTEND_TYPE, request.getCartInfo().getIntendType());


        }
    }
}
