package onevz.soe.cart.helper;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.addAccessory.AddAccContext;
import onevz.soe.cart.model.addAccessory.AddAccServiceBody;
import onevz.soe.cart.model.addAccessory.AddAccServiceResponse;
import onevz.soe.cart.model.addDevice.AddDeviceContext;
import onevz.soe.cart.model.addDevice.AddDeviceServiceBody;
import onevz.soe.cart.model.addDevice.AddDeviceServiceResponse;
import onevz.soe.cart.model.addPlan.AddPlanContext;
import onevz.soe.cart.model.addPlan.AddPlanServiceBody;
import onevz.soe.cart.model.addPlan.AddPlanServiceResponse;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.retrieveCart.*;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.ui.common.*;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.AddAccessoriesUIResponse;
import onevz.soe.cart.ui.responses.AddPlanUIResponse;
import onevz.soe.cart.ui.responses.RemoveLinesUIResponse;
import onevz.soe.cart.ui.responses.RetrieveCartUIResponse;
import onevz.soe.cart.util.FlexV2Util;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static onevz.soe.cart.util.FlexV2Util.isAccountHasBillAcc;

@Service
public class OmniDLHelper {

    @Autowired
    private RedisHelper redisHelper;

    private static final Logger logger = LoggerFactory.getLogger(OmniDLHelper.class);

    public Vzdl getVzdlDataForAddPlan(AddPlanUIRequest request, AddPlanUIResponse response, CartRedisData rr) {
        boolean reqDataNullCheck = request != null && request.getData() != null;
        boolean resDataNullCheck = response != null && response.getServiceBody() != null;
        Vzdl vzdl = null;
        if (resDataNullCheck && reqDataNullCheck) {
            vzdl = populateVzdlDataForAddPlan(request, response, rr);
        }
        return vzdl;
    }

    public Vzdl populateVzdlDataForAddPlan(AddPlanUIRequest request, AddPlanUIResponse response, CartRedisData rr) {
        Optional<CartServiceCartInfo> cartInfo = Optional.ofNullable(response.getServiceBody()).map(AddPlanServiceBody::getServiceResponse).map(AddPlanServiceResponse::getContext).map(AddPlanContext::getCartInfo);
        Optional<Line> responseLine = cartInfo.map(CartServiceCartInfo :: getLines).map(lines -> lines.length > 0 ? lines[0] : null);
        Optional<Lines> requestLine = Optional.ofNullable(request).map(AddPlanUIRequest::getData).map(AddPlanData::getLines).map(lines -> lines.length!=0 ? lines[0] : null);

        Vzdl vzdl = null;
        if (cartInfo.isPresent() && responseLine.isPresent() && requestLine.isPresent()) {
            vzdl = new Vzdl();
            updateUserData(vzdl, rr, request);
            updatePageData(vzdl, request);
            updateTxnData( vzdl, rr, cartInfo);
            updateProductData(vzdl, rr, request, requestLine, cartInfo);
            updateEvent(vzdl);
            updateUtilsData(vzdl,request);
            updateEngagement(vzdl);
        }
        return vzdl;
    }

    public void updateUserData(Vzdl vzdl,CartRedisData rr,AddPlanUIRequest request){
        if (null != rr && null != rr.getCustomerProfile() && null != rr.getCustomerProfile().getData() && null != rr.getCustomerProfile().getData().getCustomer()) {
            User user = new User();
            onevz.soe.customerprofile.model.gql.assisted.Customer customer = rr.getCustomerProfile().getData().getCustomer();
            if (StringUtilities.isNotEmptyOrNull(rr.getCustomerProfile().getData().getCustomer().getCustomerHash())) {
                user.setAccount(customer.getCustomerHash());
            }
            String accountNo = customer.getAccountNo();
            user.setAcctId_unhashed(accountNo);
            user.setCustId_unhashed(customer.getCustomerId());
            if(StringUtilities.isNotEmptyOrNull(accountNo)) {
                int dashIndex = accountNo.indexOf("-");
                user.setAccountLast2(accountNo.substring(dashIndex - 2, dashIndex));
            }
            if (null != customer.getCustomerAttributes())
                user.setCustomerType(customer.getCustomerAttributes().getCustomerType());

            if (customer.getBillAccounts() != null && !customer.getBillAccounts().isEmpty()) {
                customer.getBillAccounts().stream().filter(Objects::nonNull).forEach(billAccount -> {
                    if (billAccount.getMtns() != null) {
                        user.setNumberOfLines(String.valueOf(billAccount.getMtns().size()));
                        billAccount.getMtns().stream().filter(Objects::nonNull).forEach(mtn -> {
                            if (mtn.getMtn() != null && mtn.getMtn().equalsIgnoreCase(customer.getLookupMtn())) {
                                user.setId(mtn.getMtnHashCode());
                            }
                        });
                    }
                });
            }
            if (null != customer.getAddress()) {
                user.setZip(customer.getAddress().getZipCode());
            }
            user.setSession(request.getCartInfo().getSessionId());

            vzdl.setUser(user);
        }
    }
    public void updateProductData(Vzdl vzdl,CartRedisData rr,AddPlanUIRequest request, Optional<Lines> requestLine, Optional<CartServiceCartInfo> cartInfo) {
        Product product = new Product();
        List<Owns> ownsList = new ArrayList<>();
        List<Current> currentList = new ArrayList<>();
        List<String> requestMtnList = Arrays.stream(request.getData().getLines()).filter(Objects::nonNull).map(Lines::getMtn).collect(Collectors.toList());

        if (isRedisHasBillAcct(rr)) {
            rr.getCustomerProfile().getData().getCustomer().getBillAccounts().stream().filter(Objects::nonNull).forEach(accData -> accData.getMtns().stream().filter(data -> null != data.getMtn() && requestMtnList.contains(data.getMtn())).forEach(matchedLine -> {
                Owns owns = new Owns();
                owns.setCategory("Plan");
                if ( StringUtilities.isNotEmptyOrNull(matchedLine.getPricePlanInfo().getDescription())) {
                    owns.setName(matchedLine.getPricePlanInfo().getDescription());
                }
                if ( StringUtilities.isNotEmptyOrNull(matchedLine.getPricePlanInfo().getPlanId())) {
                    owns.setId(matchedLine.getPricePlanInfo().getPlanId());
                }
                if (StringUtilities.isNotEmptyOrNull(matchedLine.getMtnHashCode())) {
                    owns.setLine(matchedLine.getMtnHashCode());
                }
                ownsList.add(owns);
            }));
        }
        if (requestLine.isPresent()) {
            Optional.ofNullable(request).map(AddPlanUIRequest::getData).map(AddPlanData::getLines).ifPresent(linesList ->
                    Arrays.stream(linesList).filter(lines->lines!=null && StringUtilities.isNotEmptyOrNull(lines.getMtn())).forEach(lines -> {
                        Current current = new Current();
                        PlanTaggingDetails planTaggingDetails= new PlanTaggingDetails();
                        if (lineHasPlan(lines)) {
                            current.setCategory("Plan");
                            current.setId(lines.getPlan().getId());
                            current.setQty("1");
                            if (StringUtilities.isNotEmptyOrNull(lines.getPlan().getPropId())) {
                                current.setPropId(lines.getPlan().getPropId());
                            }
                            if (isRedisHasBillAcct(rr)) {
                                rr.getCustomerProfile().getData().getCustomer().getBillAccounts().stream().filter(Objects::nonNull)
                                        .forEach(accData -> accData.getMtns().stream().filter(data -> requestMtnList.contains(data.getMtn()))
                                                .forEach(matchedLine -> {
                                                    if (null != matchedLine.getMtnHashCode()) {
                                                        current.setLine(matchedLine.getMtnHashCode());
                                                        current.setLineHash(matchedLine.getMtnHashCode());
                                                    }
                                                }));
                            }
                            if (cartInfoHasLines(cartInfo)) {
                                Arrays.stream(cartInfo.get().getLines()).filter(line -> cartHasPlan(line,lines)).forEach(line -> {
                                    if (StringUtilities.isNotEmptyOrNull(line.getPlan().getDiscountedPrice()))
                                        current.setRecurringPrice(line.getPlan().getDiscountedPrice());
                                    else
                                        current.setRecurringPrice(setDefaultPriceNode(line.getPlan().getPrice()));
                                    current.setSku(setDefaultValue(line.getPlan().getProductId()));
                                    current.setName(setDefaultValue(line.getPlan().getName()));
                                    current.setNonRecurringPrice("0.00");
                                    if (StringUtilities.isNotEmptyOrNull(line.getCurrentPlanType())) {
                                        if (line.getCurrentPlanType().equalsIgnoreCase("ALP"))
                                            current.setShared("Y");
                                        else if (line.getCurrentPlanType().equalsIgnoreCase("LLP"))
                                            current.setShared("N");
                                    }
                                });
                            }

                            setActionPathGroup(request,current,lines);
                            PlansPerks planDetails = new PlansPerks();
                            planDetails.setId(current.getId());
                            planDetails.setSharedPlan(current.getShared());
                            planDetails.setSku(current.getSku());
                            planDetails.setPropId(current.getPropId());
                            planTaggingDetails.setPlan(planDetails);
                            currentList.add(current);
                        }
                        List<PlansPerks> perkDetails= new ArrayList<>();
                        if (linesHasFeatures(lines)) {
                            planTaggingDetails.setMtn(lines.getMtn());
                            lines.getAddFeatures().stream().filter(Objects::nonNull).forEach(feature -> {
                                Current featureCurrent = new Current();
                                featureCurrent.setCategory("Features");
                                featureCurrent.setId(feature.getId());
                                featureCurrent.setQty("1");
                                featureCurrent.setNonRecurringPrice("0.00");
                                featureCurrent.setPropId(feature.getPropId());
                                setActionPathGroupForFeatures(current, featureCurrent, request,lines);
                                if (StringUtilities.isNotEmptyOrNull(current.getLine())) {
                                    featureCurrent.setLine(current.getLine());
                                    featureCurrent.setLineHash(current.getLineHash());
                                }
                                if (cartInfoHasLines(cartInfo)) {
                                    Arrays.stream(cartInfo.get().getLines()).filter(line -> isCartHasSameMtn(line, lines)).forEach(line -> Optional.ofNullable(line.getSpos()).ifPresent(spos -> Arrays.stream(spos).filter(spo -> cartHasSPO(spo, feature)).forEach(spo -> {
                                        featureCurrent.setRecurringPrice(setDefaultPriceNode(spo.getPrice()));
                                        featureCurrent.setName(setDefaultValue(spo.getDescription()));
                                        featureCurrent.setSku(setDefaultValue(spo.getSkuId()));
                                    })));
                                }

                                planTaggingDetails.setAction(featureCurrent.getAction());
                                planTaggingDetails.setGroup(StringUtilities.safeParsingInt(featureCurrent.getGroup(), 1));
                                planTaggingDetails.setPath(featureCurrent.getPath());
                                PlansPerks perkTaggingDetails = new PlansPerks();
                                perkTaggingDetails.setId(featureCurrent.getId());
                                perkTaggingDetails.setSku(featureCurrent.getSku());
                                perkTaggingDetails.setPropId(featureCurrent.getPropId());
                                perkDetails.add(perkTaggingDetails);
                                currentList.add(featureCurrent);
                            });
                        }
                        setPlanTaggingDetails(request,planTaggingDetails,perkDetails,lines,current);
                    }));
        }
        Owns[] ownsArray = new Owns[ownsList.size()];
        Current[] currentArray = new Current[currentList.size()];
        product.setOwns(ownsList.toArray(ownsArray));
        product.setCurrent(currentList.toArray(currentArray));
        vzdl.setProduct(product);
    }

    public void updatePageData(Vzdl vzdl,AddPlanUIRequest request){
        Page page= new Page();
        page.setName("plan-selection");
        page.setLanguage("English");
        page.setFlowType("");
        page.setFlowName("");
        page.setContentFragments("");
        page.setRepeatCartVisitor("");
        page.setFireProactiveChat("");
        page.setDetail("-");
        if(StringUtilities.isNotEmptyOrNull(request.getChannelId())) {
            page.setChannel("Order");
            if (request.getChannelId().equalsIgnoreCase(CartConstants.RETAIL) || request.getChannelId().equalsIgnoreCase(CartConstants.RETAIL_IPAD))
                page.setDisplayChannel("retail");
        }
//        if (null != request.getCartInfo() && null != rr.getRetrieveCart()) {
//
//           page.setFlow(getFlow(request,rr.getRetrieveCart()));
//        }
        page.setThrottle("MFE");
        vzdl.setPage(page);
    }

    public void updateTxnData(Vzdl vzdl,CartRedisData rr, Optional<CartServiceCartInfo> cartInfo){
        Map<String,String> txn  = new HashMap<>();
        if(cartInfo.isPresent()) {
            if(StringUtilities.isNotEmptyOrNull(cartInfo.get().getCartId())){
            txn.put("cartId", cartInfo.get().getCartId()); }
            if(StringUtilities.isNotEmptyOrNull(rr.getAutoPayEnrolled()) && "true".equalsIgnoreCase(rr.getAutoPayEnrolled())){
            txn.put("autoPay", "Y"); }
            else { txn.put("autoPay", "N"); }
        }
        if (rr!= null ) {
            if(StringUtilities.isNotEmptyOrNull(rr.getLocationCode())){
            txn.put("outletId", rr.getLocationCode()); }
            if(StringUtilities.isNotEmptyOrNull(rr.getAgentRole())){
                txn.put("agentRole",rr.getAgentRole());
            }
        }
        vzdl.setTxn(txn);
    }

    public void updateEvent(Vzdl vzdl) {
        Event event = new Event();
        event.setValue("event278");
        vzdl.setEvent(event);
    }


    public void updateUtilsData(Vzdl vzdl,AddPlanUIRequest request) {
        vzdl.setUtils(new Utils());
        if (null != request.getCartInfo() && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCaseId())) {
            vzdl.getUtils().setPegaCaseId(request.getCartInfo().getCaseId());
        }
    }
    public String updateNewLineFlowName(CreateLineUIRequest request){
        if(request.getCartInfo() != null && request.getCartInfo().getIntendType() != null
                && request.getData() != null
                && CollectionUtilities.isNotEmptyOrNull(request.getData().getLines())){
            if(request.getFlowName() != null){
                request.setResponseFlowName(request.getFlowName());
            }
            request.getData().getLines().forEach(lines ->
                    updateFlowNameForNewLine(lines, request)
            );
        }
        return request.getResponseFlowName();
    }
    public void updateFlowNameForNewLine(Lines lines ,CreateLineUIRequest request){
        if(lines.getDeviceTypeSelected() != null && lines.getDeviceTypeSelected().equalsIgnoreCase("5G Internet") ){
            request.setResponseFlowName(request.getCartInfo().getIntendType().equalsIgnoreCase("NSE") ? setNewLineFlow(request.getResponseFlowName(), "NSE_5G") : setNewLineFlow(request.getResponseFlowName(), "AAL_5G"));
        }/*else if (lines.getDeviceTypeSelected() != null && lines.getDeviceTypeSelected().equalsIgnoreCase("4G LTE Internet")){
                    request.setResponseFlowName(request.getCartInfo().getIntendType().equalsIgnoreCase("NSE") ? setNewLineFlow(request.getResponseFlowName(), "NSE_5G") : setNewLineFlow(request.getResponseFlowName(), "AAL_5G"));
        } else if (lines.isByod()){
            request.setResponseFlowName(request.getCartInfo().getIntendType().equalsIgnoreCase("NSE") ? setNewLineFlow(request.getResponseFlowName(), "NSO") : setNewLineFlow(request.getResponseFlowName(), "AALBYOD"));
        }*/else {
            request.setResponseFlowName(request.getCartInfo().getIntendType().equalsIgnoreCase("NSE") ? setNewLineFlow(request.getResponseFlowName(), "NSE") : setNewLineFlow(request.getResponseFlowName(), "AAL"));
        }
    }

    public String setNewLineFlow(String redisFlowName, String reqFlowName) {
        if (StringUtilities.isNotEmptyOrNull(redisFlowName) && !redisFlowName.equalsIgnoreCase("-")) {
            String flowName = redisFlowName.contains("|") ? redisFlowName.substring(redisFlowName.lastIndexOf("|") + 1) : redisFlowName;
            if (StringUtilities.isNotEmptyOrNull(reqFlowName) && !flowName.equalsIgnoreCase(reqFlowName)) {
                redisFlowName = redisFlowName.concat("|" + reqFlowName);
            }
        } else if (StringUtilities.isNotEmptyOrNull(reqFlowName)) {
            redisFlowName = reqFlowName;
        }
        return redisFlowName;
    }
    public Mono<String> setFlow(String redisFlowName, String reqFlowName) {
        if (StringUtilities.isNotEmptyOrNull(redisFlowName) && !redisFlowName.equalsIgnoreCase("-")) {
            String flowName = redisFlowName.contains("|") ? redisFlowName.substring(redisFlowName.lastIndexOf("|") + 1) : redisFlowName;
            if (StringUtilities.isNotEmptyOrNull(reqFlowName) && !flowName.equalsIgnoreCase(reqFlowName)) {
                redisFlowName = redisFlowName.concat("|" + reqFlowName);
            }
        } else if (StringUtilities.isNotEmptyOrNull(reqFlowName)) {
            redisFlowName = reqFlowName;
        }
        if (StringUtilities.isNotEmptyOrNull(redisFlowName)){
            String updatedFlow = redisFlowName;
            return redisHelper.addFlowNameToRedis(redisFlowName).flatMap(upserted -> {
                if (upserted)
                    logger.info("FlowName successfully upserted");
                else
                    logger.info("Error while trying to upsert flowName to redis");
                return  Mono.just(updatedFlow);
            });
        }
        if(redisFlowName==null){
            return Mono.just("");
        }
        return Mono.just(redisFlowName);
    }
    public Vzdl getVzdlDataForRemoveDevice(RemoveLinesUIRequest request, RemoveLinesUIResponse response, CartRedisData rr) {
        boolean reqDataNullCheck = request != null && request.getData() != null && request.getCartInfo().getProcessAction() != null && request.getCartInfo().getProcessAction().equalsIgnoreCase("removeDevice");
        boolean resDataNullCheck = response != null && response.getServiceBody() != null;
        Vzdl vzdl = null;
        if (resDataNullCheck && reqDataNullCheck) {
            vzdl = populateVzdlDataForRemoveDevice(request, rr);
        }
        return vzdl;
    }

    public Vzdl populateVzdlDataForRemoveDevice(RemoveLinesUIRequest request, CartRedisData sessionData) {
       Vzdl vzdl = getVzdlTxnDataForRemoveDeviceCart(request, sessionData);
        if (vzdl == null) {
            vzdl = new Vzdl();
        }
        Event event = new Event();
        event.setValue("event62");
        vzdl.setEvent(event);
        setPageDataForRemoveDevice(request, vzdl);
        return vzdl;
    }

   public Vzdl getVzdlTxnDataForRemoveDevice(RemoveLinesUIRequest request,CartRedisData sessionData){
       Optional<Lines> requestLine = Optional.ofNullable(request).map(RemoveLinesUIRequest::getData).map(RemoveLinesData::getLines).map(lines -> !Arrays.asList(lines).isEmpty() ? Arrays.asList(lines).get(0): null);
       Map<String,String> txn;
       Product product = new Product();
       if(requestLine.isPresent() && sessionData.getRetrieveCart() != null && FlexV2Util.isCartHasLine(sessionData.getRetrieveCart())){
          CXPLineInfo macthedLineInfo = Arrays.stream(sessionData.getRetrieveCart().getCart().getLineDetails().getLineInfo()).filter(obj ->
                    obj.getMobileNumber() != null && requestLine.get().getMtn()!= null && obj.getMobileNumber().equalsIgnoreCase(requestLine.get().getMtn())).findAny().orElse(null);

          if(macthedLineInfo != null && macthedLineInfo.getItemsInfo() != null){
              txn = new HashMap<>();
              Vzdl vzdl = new Vzdl();
              List<Current> currentList = new ArrayList<>();
              CXPCartItem[] cxpCartItems = Arrays.stream(macthedLineInfo.getItemsInfo()).filter(obj -> obj.getCartItems() != null && obj.getCartItems().getCartItem() != null).map(CXPItemInfo::getCartItems).map(CXPCartItemsVO::getCartItem).findAny().orElse(null);
              if (cxpCartItems != null) {
                  CXPCartItem cxpCartItem = Arrays.stream(cxpCartItems).filter(obj -> obj.getCartItemType() != null && obj.getCartItemType().equalsIgnoreCase("DEVICE")).findAny().orElse(null);
                  setCurrentDataForRemoveDevice(cxpCartItem, requestLine, txn, sessionData, currentList);

                  Current[] currentsArray = new Current[currentList.size()];
                  product.setCurrent(currentList.toArray(currentsArray));
                  vzdl.setProduct(product);
                  vzdl.setTxn(txn);
              }
              return vzdl;
          }
       }
       return null;
    }
    public Vzdl getVzdlTxnDataForRemoveDeviceCart(RemoveLinesUIRequest request,CartRedisData sessionData){
        List<String> requestLine = Arrays.stream(Optional.ofNullable(request.getData().getLines()).orElse(new Lines[0]))
                .filter(Objects::nonNull)
                .map(Lines::getMtn)
                .collect(Collectors.toList());
        Map<String,String> txn;
        Product product = new Product();
        List<Current> currentList = new ArrayList<>();

        if(requestLine.size() >0 && sessionData.getRetrieveCart() != null && FlexV2Util.isCartHasLine(sessionData.getRetrieveCart())){
            Vzdl vzdl = new Vzdl();
            for (String mtn : requestLine) {
                    CXPLineInfo macthedLineInfo = Arrays.stream(sessionData.getRetrieveCart().getCart().getLineDetails().getLineInfo())
                            .filter(obj -> obj.getMobileNumber() != null && mtn != null && obj.getMobileNumber().equalsIgnoreCase(mtn))
                            .findAny().orElse(null);

                    if (macthedLineInfo != null && macthedLineInfo.getItemsInfo() != null) {
                        txn = new HashMap<>();

                        CXPCartItem[] cxpCartItems = Arrays.stream(macthedLineInfo.getItemsInfo()).filter(obj -> obj.getCartItems() != null && obj.getCartItems().getCartItem() != null).map(CXPItemInfo::getCartItems).map(CXPCartItemsVO::getCartItem).findAny().orElse(null);
                        if (cxpCartItems != null) {
                            CXPCartItem cxpCartItem = Arrays.stream(cxpCartItems).filter(obj -> obj.getCartItemType() != null && obj.getCartItemType().equalsIgnoreCase("DEVICE")).findAny().orElse(null);
                            Optional<Lines> mtnvalue = Optional.ofNullable(mtn).map(mtnStr -> {
                                Lines line = new Lines();
                                line.setMtn(mtnStr);
                                return line;
                            });
                            setCurrentDataForRemoveDevice(cxpCartItem, mtnvalue, txn, sessionData, currentList);

                            Current[] currentsArray = new Current[currentList.size()];
                            product.setCurrent(currentList.toArray(currentsArray));
                            vzdl.setProduct(product);
                            vzdl.setTxn(txn);
                        }

                    }
                }
            return vzdl;
        }
        return null;
    }
    public void setCurrentDataForRemoveDevice(CXPCartItem cxpCartItem, Optional<Lines> requestLine,Map<String,String> txn, CartRedisData sessionData,List<Current> currentList){
        if(cxpCartItem != null) {
            Current current = new Current();
            current.setCategory("Device");
            current.setName(cxpCartItem.getDescription());
            current.setId(cxpCartItem.getSorId());
            current.setSku(cxpCartItem.getSkuId());
            current.setQty("1");
            updateMtnHash(sessionData, current, requestLine);

            if("VERIZON_EDGE".equalsIgnoreCase(cxpCartItem.getPriceType()) && cxpCartItem.getDeviceDueMonthly() != null) {
                txn.put("recurringCharges", String.valueOf(cxpCartItem.getDeviceDueMonthly()));
                current.setRecurringPrice(String.valueOf(cxpCartItem.getDeviceDueMonthly()));
            }
            else {
                txn.put("nonRecurringCharges", String.valueOf(cxpCartItem.getItemPrice()));
                current.setNonRecurringPrice(String.valueOf(cxpCartItem.getItemPrice()));
            }
            currentList.add(current);

        }
    }
    public void updateMtnHash(CartRedisData sessionData, Current current, Optional<Lines> requestLine ){
        if(sessionData.getCustomerProfile() != null && isAccountHasBillAcc(sessionData.getCustomerProfile())) {
            sessionData.getCustomerProfile().getData().getCustomer().getBillAccounts().stream().filter(Objects::nonNull).forEach(accData -> accData.getMtns().stream().filter(data -> requestLine.get().getMtn().equalsIgnoreCase(data.getMtn())).forEach(matchedLine -> {
                if (StringUtilities.isNotEmptyOrNull(matchedLine.getMtnHashCode())) {
                    current.setLineHash(matchedLine.getMtnHashCode());
                }
            }));
        }
    }
   public void setPageDataForRemoveDevice(RemoveLinesUIRequest request,Vzdl vzdl){

       Page page = new Page();
       page.setName("product-detail");
       page.setThrottle("MFE");
       if(request.getCartInfo().getIntendType() != null){
           page.setFlow(request.getCartInfo().getIntendType());
       }
       vzdl.setPage(page);
   }
   public Mono<String> getFlow(AddPlanUIRequest request, CXPRetrieveCartDataVO retrieveCart){
        List<String> upgIntendTypes = new ArrayList<>(Arrays.asList("EUP", "EUPBYOD", "ESO"));
        if(null != request.getData() && null !=request.getData().getLines() && request.getData().getLines().length>0) {
            List<String> mtns = Arrays.stream(request.getData().getLines()).filter(lines -> lines != null && lines.getMtn() != null && lines.getLinechanged() != null && lines.getLinechanged()).map(Lines::getMtn).collect(Collectors.toList());
            Optional<String> op = Optional.empty();
            if (FlexV2Util.isCartHasLine(retrieveCart)) {
                op = Arrays.stream(retrieveCart.getCart().getLineDetails().getLineInfo()).filter(line -> line != null && line.getMobileNumber() != null && line.getLineActivityType() != null && mtns.contains(line.getMobileNumber())).map(CXPLineInfo::getLineActivityType)
                        .filter(upgIntendTypes::contains).findFirst();
            }
            if (op.isPresent() ||
                    null != request.getCartInfo() && (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                            && "CPC".equalsIgnoreCase(request.getCartInfo().getIntendType()))) {
                //request.getCartInfo().setIntendType("CPC");

                return setFlow(request.getFlowName(), "CPC");

            }else{
                return setFlow(request.getFlowName(), "");
            }
        }
        return Mono.empty();
    }

    public void setActionPathGroup(AddPlanUIRequest request, Current current, Lines lines) {
        Optional<PlanTaggingDetails> taggingDetails = Optional.empty();
        if (CollectionUtilities.isNotEmptyOrNull(request.getPlanTaggingDetails())) {
            taggingDetails = isMtnInPlanTagging(request.getPlanTaggingDetails(), lines);
            if (taggingDetails.isPresent()) {
                current.setGroup(String.valueOf(taggingDetails.get().getGroup()));
            } else
                current.setGroup(String.valueOf(setGroupValue(lines.getMtn(), request)));
        } else {
            current.setGroup("1");
            request.setPlanTaggingDetails(new ArrayList<>());
        }
        if (null != lines.getPlan() && StringUtilities.isNotEmptyOrNull(lines.getPlan().getPath())) {
            current.setPath(lines.getPlan().getPath());
            if (lines.getPlan().getPath().equalsIgnoreCase(CartConstants.BUILD_PLAN_PATH)) {
                current.setAction(CartConstants.MODIFY);
            } else
                current.setAction(CartConstants.PRESET);
        } else {
            current.setAction(CartConstants.MODIFY);
            current.setPath(CartConstants.BUILD_PLAN_PATH);
        }
        taggingDetails.ifPresent(planTaggingDetails -> request.getPlanTaggingDetails().remove(planTaggingDetails));
    }

    public Optional<PlanTaggingDetails> isMtnInPlanTagging(List<PlanTaggingDetails> planTaggingDetail, Lines lines) {
        if (CollectionUtilities.isNotEmptyOrNull(planTaggingDetail))
            return planTaggingDetail.stream().filter(planTaggingDetails -> null != planTaggingDetails && null != lines && StringUtilities.isNotEmptyOrNull(planTaggingDetails.getMtn()) && StringUtilities.isNotEmptyOrNull(lines.getMtn()) && planTaggingDetails.getMtn().equalsIgnoreCase(lines.getMtn())).findAny();
        return Optional.empty();
    }

    public String setGroupValue(String mtn, AddPlanUIRequest request) {
        Integer groupValue = 0;
        groupValue = updateTaggingDetails(mtn, request.getRetrieveCart(), request);
        Optional<PlanTaggingDetails> opt = request.getPlanTaggingDetails().stream().filter(taggingNode -> taggingNode != null && StringUtilities.isNotEmptyOrNull(mtn) && StringUtilities.isNotEmptyOrNull(taggingNode.getMtn()) && taggingNode.getMtn().equalsIgnoreCase(mtn)).findAny();
        if (opt.isPresent()) {
            groupValue = opt.get().getGroup();
        }
        if (groupValue == 0) {
            List<PlanTaggingDetails> planTaggingDetailsList = request.getPlanTaggingDetails().stream().filter(Objects::nonNull).toList();
            PlanTaggingDetails planTaggingDetails = Collections.max(planTaggingDetailsList, Comparator.comparing(PlanTaggingDetails::getGroup));
            groupValue = planTaggingDetails.getGroup() != null ? planTaggingDetails.getGroup() + 1 : 1;
        }
        return String.valueOf(groupValue);
    }

    public Integer updateTaggingDetails(String mtn, CXPRetrieveCartDataVO retrieveCart, AddPlanUIRequest request) {
        Integer group = 0;
        if (CollectionUtilities.isNotEmptyOrNull(request.getPlanTaggingDetails()) && null != retrieveCart && FlexV2Util.isCartHasLine(retrieveCart)) {
            List<PlanTaggingDetails> taggingDetails = request.getPlanTaggingDetails();
            Optional<PlanTaggingDetails> planTaggingOpt = taggingDetails.stream().filter(taggingNode -> taggingNode != null && StringUtilities.isNotEmptyOrNull(taggingNode.getMtn()) && Arrays.stream(retrieveCart.getCart().getLineDetails().getLineInfo()).anyMatch(line -> line != null && StringUtilities.isNotEmptyOrNull(mtn) && null != line.getMtnDetails() && StringUtilities.isNotEmptyOrNull(line.getMtnDetails().getLineNumber()) && StringUtilities.isNotEmptyOrNull(line.getMobileNumber()) && mtn.equalsIgnoreCase(line.getMobileNumber()) && !mtn.equalsIgnoreCase(line.getMtnDetails().getLineNumber()) && taggingNode.getMtn().equalsIgnoreCase(line.getMtnDetails().getLineNumber()))).findAny();
            if (planTaggingOpt.isPresent()) {
                taggingDetails.remove(planTaggingOpt.get());
                group = planTaggingOpt.get().getGroup();
            }
        }
        return group;
    }

    public Mono<Boolean> upsertPlanTaggingValueToRedis(List<PlanTaggingDetails> taggingDetails) {
        if (CollectionUtilities.isNotEmptyOrNull(taggingDetails)) {
            GsonBuilder gsonBuilder = new GsonBuilder();
            Gson gsonObject = gsonBuilder.create();
            return redisHelper.addPlanTaggingDetailsToRedis(gsonObject.toJson(taggingDetails));
        }
        return Mono.just(false);
    }

    public  Vzdl updateVzdlData(RetrieveCartUIResponse cxpResponse){
        Vzdl vzdl = new Vzdl();
        Page page= new Page();
        Optional.ofNullable(cxpResponse)
                .map(RetrieveCartUIResponse::getData)
                .map(CXPRetrieveCartDataVO::getCart)
                .map(CXPCartVO::getFlow)
                .filter(this::isNonBlank)
                .map(flow->{
                    Set<String> flowComponents=Arrays.asList(flow.split("\\|"))
                            .stream().filter(this::isNonBlank)
                            .collect(Collectors.toCollection(LinkedHashSet::new));
                    if(flowComponents.contains(CartConstants.STAND_ALONE_TRADEIN)){
                        flowComponents.remove(CartConstants.STAND_ALONE_TRADEIN);
                        String updateFlow="TradeIn";
                        if(!flowComponents.isEmpty()){
                            updateFlow +="|"+String.join("|",flowComponents);
                        }
                        return updateFlow;
                    }
                    return  String.join("|",flowComponents);
                }) .ifPresent(page::setFlow);
        vzdl.setPage(page);
        updateTxnDataForOrderReviewPage( cxpResponse, vzdl);
        updateUserDataPages( cxpResponse, vzdl);
        updateUtilsDataForConfirmationPage(vzdl,cxpResponse);
         return vzdl;
    }

    public Vzdl updateUtilsDataForConfirmationPage( Vzdl vzdl, RetrieveCartUIResponse cxpResponse) {
        vzdl.setUtils(new Utils());
        if(cxpResponse.getData()!=null &&cxpResponse.getData().getCart() !=null && cxpResponse.getData().getCart().getCartHeader()!=null)
        {
            vzdl.getUtils().setPegaCaseId(cxpResponse.getData().getCart().getCartHeader().getCaseId());
        }
        else vzdl.getUtils().setPegaCaseId("");
        return  vzdl;
    }

    public Vzdl updateTxnDataForOrderReviewPage(RetrieveCartUIResponse cxpResponse, Vzdl vzdl) {
        Map<String,String> txn = new HashMap<>();
        Optional.ofNullable(cxpResponse)
                .map(RetrieveCartUIResponse::getData)
                .map(CXPRetrieveCartDataVO::getCart)
                .ifPresent(cart->{
                    Optional.ofNullable(cart.getFlow())
                            .filter(this::isNonBlank)
                            .ifPresent(flow->{
                                Set<String> flowComponents=Arrays.asList(flow.split("\\|"))
                                        .stream().filter(this::isNonBlank)
                                        .collect(Collectors.toCollection(LinkedHashSet::new));
                                String processedFlow;
                                if(flowComponents.contains(CartConstants.STAND_ALONE_TRADEIN)) {
                                    flowComponents.remove(CartConstants.STAND_ALONE_TRADEIN);
                                    processedFlow = "TradeIn";
                                    if (!flowComponents.isEmpty()) {
                                        processedFlow += "+" + String.join("+", flowComponents);
                                    }
                                }
                                else{
                                    processedFlow=String.join("+",flowComponents);
                                }
                                if(processedFlow!=null && !processedFlow.isBlank())
                                    txn.put("orderType",processedFlow);
                            });
                    Optional.ofNullable(cart.getOrderDetails())
                            .ifPresent(orderDetails -> {
                                Optional.ofNullable(orderDetails.getTotalTaxAmount())
                                        .ifPresent(totalTaxAmount -> txn.put("taxAmt", totalTaxAmount.toString()));
                                Optional.ofNullable(orderDetails.getTotalShippingCost())
                                        .ifPresent(totalShippingCost -> txn.put("shippingTotal", totalShippingCost.toString()));
                                Optional.ofNullable(orderDetails.getTotalDueToday())
                                        .ifPresent(totalDueToday -> txn.put("total", totalDueToday.toString()));
                            });

                    Optional.ofNullable(cart.getQuote())
                            .map(Quote::getQuoteId)
                            .ifPresent(quoteId -> txn.put("quoteId", quoteId));

                    Optional.ofNullable(cart.getLineDetails())
                            .ifPresent(lineDetails -> {
                                Optional.ofNullable(lineDetails.getPayments())
                                        .flatMap(payments -> payments.stream().findFirst())
                                        .ifPresent(payment -> {
                                            Optional.ofNullable(payment.getOrderNumber())
                                                    .ifPresent(orderNumber->txn.put("id",orderNumber.toString()));
                                            Optional.ofNullable(payment.getPaymentDetails())
                                                    .ifPresent(paymentDetails -> {
                                                        Optional.ofNullable(paymentDetails.getPaymentType())
                                                                .ifPresent(paymentType -> txn.put("paymentType", paymentType));
                                                        Optional.ofNullable(paymentDetails.getAddress())
                                                                .map(Address::getZipCode4)
                                                                .ifPresent(zipCode4 -> txn.put("shippingZip", zipCode4));
                                                    });
                                        });
                                Optional.ofNullable(lineDetails.getTradeInDetail())
                                        .ifPresent(tradeInDetail -> {Optional.ofNullable(tradeInDetail.getTradeInItems())
                                                .ifPresent(tradeInItems -> {
                                                    if(CollectionUtilities.isNotEmptyOrNull(tradeInItems)){
                                                        txn.put("tradeInQty",String.valueOf(tradeInItems.size()));
                                                        Optional.ofNullable(tradeInItems.get(0))
                                                                .map(TradeInItem::getOrganicPrice)
                                                                .ifPresent(organicPrice->txn.put("tradeInAmt",organicPrice));

                                                    }});
                                        });
                                Optional.ofNullable(lineDetails.getIsAutoPayEnrolled())
                                        .filter(StringUtilities::isNotEmptyOrNull)
                                        .ifPresentOrElse(autoPay->txn.put("autoPay",autoPay),
                                                ()->txn.put("autoPay","N"));
                            });


                    Optional.ofNullable(cart.getLineDetails())
                            .map(CXPLineDetailsVO::getLineInfo)
                            .flatMap(lineInfo -> Stream.of(lineInfo).findFirst())
                            .map(CXPLineInfo::getServiceInfo)
                            .map(onevz.soe.cart.model.retrieveCart.ServiceInfo::getThirdPartyOffer)
                            .flatMap(thirdPartyOffers -> Stream.of(thirdPartyOffers)
                                    .map(ThirdPartyOffer::getOfferName)
                                    .filter(offerName -> offerName != null && !offerName.isEmpty())
                                    .findFirst())
                            .ifPresent(offerName -> txn.put("offer", offerName));

                    Optional.ofNullable(cart.getLineDetails())
                            .map(CXPLineDetailsVO::getLineInfo)
                            .flatMap(lineInfo -> Stream.of(lineInfo).findFirst())
                            .map(CXPLineInfo::getServiceInfo)
                            .map(onevz.soe.cart.model.retrieveCart.ServiceInfo::getSelectedFeaturesList)
                            .map(SelectedFeaturesList::getVisFeature)
                            .flatMap(visFeatures -> visFeatures.stream().findFirst())
                            .flatMap(visFeature -> visFeature.getFeatureDiscounts().stream().findFirst())
                            .map(RetrieveCartDiscounts::getDiscountId)
                            .ifPresent(discountId -> txn.put("discountId", discountId));
                    Optional.ofNullable(cart.getLineDetails())
                            .map(CXPLineDetailsVO::getLineInfo)
                            .filter(lineInfo->lineInfo.length>0)
                            .map(lineInfo->lineInfo[0]).map(CXPLineInfo::getServiceInfo)
                            .map(onevz.soe.cart.model.retrieveCart.ServiceInfo::getPrimaryUserInfo).map(PrimaryUserInfo::getLastName)
                            .ifPresentOrElse(lastName->txn.put("agentRole",lastName)
                                    ,()->txn.put("agentRole",""));
                });


        vzdl.setTxn(txn);
        return vzdl;
    }

    public boolean isRedisHasBillAcct(CartRedisData rr){
        return (null != rr && rr.getCustomerProfile() != null && isAccountHasBillAcc(rr.getCustomerProfile()));
    }

    public boolean lineHasPlan(Lines lines){
        return (lines != null && null != lines.getPlan() && null != lines.getPlan().getId() && Boolean.TRUE.equals(lines.getLinechanged()));
    }

    public boolean linesHasFeatures(Lines lines) {
        return null != lines && CollectionUtilities.isNotEmptyOrNull(lines.getAddFeatures()) && Boolean.TRUE.equals(lines.getLinechanged());
    }

    public boolean cartHasPlan(Line line, Lines lines) {
        return (isCartHasSameMtn(line,lines) && null != line.getPlan() && StringUtilities.isNotEmptyOrNull(line.getPlan().getId()) && line.getPlan().getId().equalsIgnoreCase(lines.getPlan().getId()));
    }

    public boolean cartHasSPO(ConflictedSPO spo, Feature feature) {
        return null != spo && StringUtilities.isNotEmptyOrNull(spo.getId()) && StringUtilities.isNotEmptyOrNull(feature.getId()) && spo.getId().equalsIgnoreCase(feature.getId());
    }

    public boolean isCartHasSameMtn(Line line, Lines lines) {
        return null != line && StringUtilities.isNotEmptyOrNull(line.getMtn()) && StringUtilities.isNotEmptyOrNull(lines.getMtn()) && line.getMtn().equalsIgnoreCase(lines.getMtn());
    }

    public String setDefaultPriceNode(String price){
        return StringUtilities.isNotEmptyOrNull(price) ? price : "0.00";
    }

    public String setDefaultValue( String value){
        return StringUtilities.isNotEmptyOrNull(value) ? value : "";
    }

    public boolean cartInfoHasLines(Optional<CartServiceCartInfo> cartInfo) {
        return cartInfo.isPresent() && cartInfo.get().getLines() != null;
    }
    public void updateEngagement(Vzdl vzdl) {
        vzdl.setEngagement(new Engagement());
        vzdl.getEngagement().setIntent("order");
    }

    public void eventUpdate(Vzdl vzdl) {
        Event event = new Event();
        event.setValue("scView");
        vzdl.setEvent(event);
    }

    private void updatePageData(Vzdl vzdl,String sessionId, String flow){
        Page page= new Page();
        page.setName("order-review-handoff");
        page.setLanguage("English");
        page.setChannel("Order");
        page.setDisplayChannel("retail");
        page.setThrottle("MFE");
        page.setChannelSession(sessionId);
        page.setFlow(flow);
        vzdl.setPage(page);
    }

    public void userDetails(Vzdl vzdl) {
        User user = new User();
        user.setAmid(setIfNull(setEmptyNode(user.getAmid())));
        user.setProspect(setIfNull(setEmptyNode(user.getProspect())));
        user.setChildId(setIfNull(setEmptyNode(user.getChildId())));
        user.setChatId(setIfNull(setEmptyNode(user.getChatId())));
        user.setDeviceDollars(setIfNull(setEmptyNode(user.getDeviceDollars())));
        user.setProductsQualified(setIfNull(setEmptyNode(user.getProductsQualified())));
        user.setVisionAcctID_unhashed(setIfNull(setEmptyNode(user.getAcctId_unhashed())));
        user.setVisionCustID_unhashed(setIfNull(setEmptyNode(user.getVisionCustID_unhashed())));
        user.setCdUserId(setIfNull(setEmptyNode(user.getCdUserId())));
        user.setExistingServices(setIfNull(setEmptyNode(user.getExistingServices())));
        user.setAccountType(setIfNull(setEmptyNode(user.getAccountType())));
        user.setCustomerRole(setIfNull(setEmptyNode(user.getCustomerRole())));
        user.setAuthStatus(setIfNull(setEmptyNode(user.getAuthStatus())));
        user.setAuthType(setIfNull(setEmptyNode(user.getAuthType())));
        user.setTenure(setIfNull(setEmptyNode(user.getTenure())));
        user.setCreditAppNum(setIfNull(setEmptyNode(user.getCreditAppNum())));
        vzdl.setUser(user);


    }

    private Vzdl handOffUtil(Vzdl vzdl){
        vzdl.setUtils(new Utils());
        vzdl.getUtils().setPegaCaseId("");
        return  vzdl;
    }
    private String setIfNull(String value){
        return value==null ?setEmptyNode(null):value;
    }
    public Vzdl getVzdlDataForEventAndPage(String sessionId, String flow) {
        Vzdl vzdl = new Vzdl();
        eventUpdate(vzdl);
        updatePageData(vzdl,sessionId, flow);
        userDetails(vzdl);
        updateEngagement(vzdl);
        handOffUtil(vzdl);
        return  vzdl;

    }

    private String setEmptyNode(String value){
        List<String> parentList= Arrays.asList("-","none");
        if(value==null || parentList.contains(value.toLowerCase()))
            value="";
        return value;
    }
    public void updateUserDataPages(RetrieveCartUIResponse cxpResponse, Vzdl vzdl) {
        User user=new User();
        Optional.ofNullable(cxpResponse)
                .map(RetrieveCartUIResponse::getData)
                .map(CXPRetrieveCartDataVO::getCart)
                .map(CXPCartVO::getOrderDetails)
                .map(CXPOrderDetails::getOrderList)
                .filter(orderList->!orderList.isEmpty())
                .map(orderList->orderList.get(0))
                .map(OrderList ::getCreditApplication)
                .map(CreditApplicationDetails::getCreditApplicationNum)
                .map(Object::toString).ifPresentOrElse(user::setCreditAppNum,
                        ()->user.setCreditAppNum(setEmptyNode(user.getCreditAppNum())));
        Optional.ofNullable(cxpResponse)
                .map(RetrieveCartUIResponse::getData)
                .map(CXPRetrieveCartDataVO::getCart)
                .map(CXPCartVO::getOrderDetails)
                .map(CXPOrderDetails::getIsPrePayCart)
                .map(isPrePayCart->"true".equalsIgnoreCase(isPrePayCart)? "prepaid":"postpaid")
                .ifPresentOrElse(user::setAccountType,()->user.setAccountType(setEmptyNode(user.getAccountType())));
        Optional.ofNullable(cxpResponse)
                .map(RetrieveCartUIResponse::getData)
                .map(CXPRetrieveCartDataVO::getCart)
                .map(CXPCartVO::getOrderDetails)
                .map(CXPOrderDetails::getCustomerType)
                .map(customerType->"N".equals(customerType)?"anonymous":"Logged In")
                .ifPresentOrElse(user::setAuthStatus,()->user.setAuthStatus(setEmptyNode(user.getAuthStatus())));
        vzdl.setUser(user);

    }

    public void setPlanTaggingDetails(AddPlanUIRequest request, PlanTaggingDetails planTaggingDetails, List<PlansPerks> perkDetails, Lines lines, Current current) {
        if (Boolean.TRUE.equals(lines.getLinechanged()) && null != planTaggingDetails && (StringUtilities.isEmptyOrNull(planTaggingDetails.getAction()) || StringUtilities.isEmptyOrNull(planTaggingDetails.getPath()) || null == planTaggingDetails.getGroup())) {
            planTaggingDetails.setAction(current.getAction());
            planTaggingDetails.setGroup(StringUtilities.safeParsingInt(current.getGroup(), 1));
            planTaggingDetails.setPath(current.getPath());
            planTaggingDetails.setMtn(lines.getMtn());
        }
        if (planTaggingDetails != null && CollectionUtilities.isNotEmptyOrNull(perkDetails))
            planTaggingDetails.setPerks(perkDetails);
        if (planTaggingDetails != null && StringUtilities.isNotEmptyOrNull(planTaggingDetails.getMtn())) {
            if (null == request.getPlanTaggingDetails())
                request.setPlanTaggingDetails(new ArrayList<>());
            request.getPlanTaggingDetails().add(planTaggingDetails);
        }
    }

    public void setActionPathGroupForFeatures(Current current, Current featureCurrent, AddPlanUIRequest request, Lines lines) {
        if (StringUtilities.isEmptyOrNull(current.getAction()) || StringUtilities.isEmptyOrNull(current.getPath()) || StringUtilities.isEmptyOrNull(current.getGroup()))
            setActionPathGroup(request, featureCurrent, lines);
        else {
            featureCurrent.setAction(current.getAction());
            featureCurrent.setGroup(current.getGroup());
            featureCurrent.setPath(current.getPath());
        }
    }

    public Vzdl getVzdlDataForAddAccessories(AddAccessoriesUIRequest request, AddAccessoriesUIResponse response) {
        boolean reqDataNullCheck = isReqDataNullCheck(request);
        boolean resDataNullCheck = isResDataNullCheck(response);

        Vzdl vzdl = null;
        if (resDataNullCheck && reqDataNullCheck) {
            vzdl = populateVzdlDataForAddAccessories(request, response);
        }
        return vzdl;
    }

    private boolean isResDataNullCheck(AddAccessoriesUIResponse response) {
        return response != null && response.getServiceBody() != null;
    }

    private boolean isReqDataNullCheck(AddAccessoriesUIRequest request) {
        return request != null && request.getData() != null;
    }

    public Vzdl populateVzdlDataForAddAccessories(AddAccessoriesUIRequest request, AddAccessoriesUIResponse response) {
        Optional<CartServiceCartInfo> cartInfo = getCartInfo(response);
        Optional<Line> responseLine = getResponseLine(cartInfo);
        Optional<Lines> requestLine = getRequestLine(request);
        Vzdl vzdl = null;
        if (checkReqRespData(cartInfo, responseLine, requestLine)) {
            vzdl = new Vzdl();
            updateMFEVzdl(response, vzdl);
        }
        return vzdl;
    }

    private void updateMFEVzdl(AddAccessoriesUIResponse response, Vzdl vzdl) {
        updateProductDataForAccessories(vzdl, response);
        updateEvent(vzdl);
        updatePageDataAcc(vzdl);
    }

    private boolean checkReqRespData(Optional<CartServiceCartInfo> cartInfo, Optional<Line> responseLine, Optional<Lines> requestLine) {
        return cartInfo.isPresent() && responseLine.isPresent() && requestLine.isPresent();
    }

    private Optional<CartServiceCartInfo> getCartInfo(AddAccessoriesUIResponse response) {
        return Optional.ofNullable(response.getServiceBody()).map(AddAccServiceBody::getServiceResponse).map(AddAccServiceResponse::getContext).map(AddAccContext::getCartInfo);
    }

    private Optional<Line> getResponseLine(Optional<CartServiceCartInfo> cartInfo) {
        return cartInfo.map(CartServiceCartInfo::getLines).map(lines -> lines.length > 0 ? lines[0] : null);
    }

    private Optional<Lines> getRequestLine(AddAccessoriesUIRequest request) {
        return Optional.ofNullable(request).map(AddAccessoriesUIRequest::getData).map(AddAccessoriesData::getLines).map(lines -> lines.length != 0 ? lines[0] : null);
    }

    private void updatePageDataAcc(Vzdl vzdl) {
        Page page = new Page();
        page.setName(CartConstants.ORDER_LANDING_TAG);
        vzdl.setPage(page);


    }

    public void updateProductDataForAccessories(Vzdl vzdl, AddAccessoriesUIResponse response) {
        List<Current> currentList = new ArrayList<>();
        Product product = new Product();

        Optional.ofNullable(response).map(AddAccessoriesUIResponse::getServiceBody).map(AddAccServiceBody::getServiceResponse)
                .map(AddAccServiceResponse::getContext).map(AddAccContext::getCartInfo).map(CartServiceCartInfo::getLines)
                .ifPresent(lineList -> Arrays.stream(lineList).filter(lineDet->null!=lineDet && null!=lineDet.getAccessories() && null!= lineDet.getAccessories().getItems()).forEach(lines -> {
                    Current current = new Current();
                    lines.getAccessories().getItems().stream().forEach(items ->
                            updateCurrent(items, current)
                    );
                    currentList.add(current);
                }));

        Current[] currentArray = new Current[currentList.size()];
        product.setCurrent(currentList.toArray(currentArray));
        vzdl.setProduct(product);

    }

    private void updateCurrent(ItemDetails items, Current current) {
        current.setCategory(CartConstants.HELPER_ACCESSORIES);
        current.setId(StringUtilities.isNotEmptyOrNull(items.getId()) ? items.getId() : "");
        current.setQty(String.valueOf(items.getQty()));
        current.setName(StringUtilities.isNotEmptyOrNull(items.getName()) ? items.getName() : "");
        current.setNonRecurringPrice(StringUtilities.isNotEmptyOrNull(items.getItemPrice()) ? items.getItemPrice() : "");
        current.setSku(StringUtilities.isNotEmptyOrNull(items.getSkuId())? items.getSkuId():"");
    }

    private  boolean isNonBlank(String str){
        return str !=null && !str.isBlank();
    }
}

