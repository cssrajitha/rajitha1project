package onevz.soe.cart.controller;

import java.util.Objects;
import jakarta.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.helper.SaveCartHelper;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.ui.requests.SaveCartForLaterUIRequest;
import onevz.soe.cart.ui.requests.SaveCartUIRequest;
import onevz.soe.cart.util.CartPegaResponseErrorsUtil;
import onevz.soe.cart.util.CartUtil;
import onevz.soe.utilities.StringUtilities;
import reactor.core.publisher.Mono;

/**
 * Cart Controller class.
 */
//NSADT-53978 removing CrossOrigin annotation in every service
//@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping(value = "cart")
public class SaveCartController {

	private static final Logger logger = LoggerFactory.getLogger(SaveCartController.class);

	@Autowired
	private SaveCartHelper saveCartHelper;

	/**
	 * 
	 * @param binder
	 */
	@InitBinder("*")
	public void initBinderByName(WebDataBinder binder) {
		binder.setDisallowedFields(new String[] { "genericHeader" });
	}

	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return ResponseEntity
	 *
	 */
	@PostMapping({ "/save-cart", "/nse/save-cart" , "/flexV2/save-cart"})
	public Mono<ResponseEntity<GenericResponse>> saveCart(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse,
			@Valid @RequestBody SaveCartUIRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "save-cart");
		logger.debug("saveCart Request: {}", request);
		String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
				? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
				: "";
		request.setChannelId(channelId);

		setFlexV2(httpHeader, request);
		if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()) && request.getCartInfo().getIntendType().toUpperCase().contains("NSE")) {
			if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getSaveCartEmailId())) {
				logger.info("Saving the cart(Email Quote) for new customer");
			} else {
				logger.info("Saving the cart for new customer");
			}
		} else {
			if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getSaveCartEmailId())) {
				logger.info("Saving the cart(Email Quote) for existing customer");
			} else {
				logger.info("Saving the cart for existing customer");
			}
		}

		request.setHttpRequest(httpHeader);
		
		
		String sessionId = "";
		logger.info("Processing SaveCart Transaction");
		// add condition for expressStore
		if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId))
				|| CartConstants.EXPRESS_STORE.equalsIgnoreCase(CartUtil.getChannelType(channelId)))
			sessionId = null != httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION)
					? Objects.requireNonNull(httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION)).getValue()
					: "";
		if (CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(channelId)))
			sessionId = null != httpHeader.getCookies().getFirst("assisted_ig_session")
					? Objects.requireNonNull(httpHeader.getCookies().getFirst("assisted_ig_session")).getValue()
					: "";

		request.getCartInfo().setSessionId(sessionId);
		if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getSaveCartEmailId()) && StringUtilities.isNotEmptyOrNull(sessionId)) {
			request.setGlobalId(String.join("_",request.getCartInfo().getSaveCartEmailId(),sessionId));
		}else {
			request.setGlobalId(StringUtilities.isNotEmptyOrNull(sessionId) ? sessionId : "");
		}
		return saveCartHelper.saveCart(request).map(resp -> {
			ErrorResponse errors2 = null;
			if (resp.getErrors() != null) {
				errors2 = CartPegaResponseErrorsUtil.handleSaveCartResponseErrors(resp);
			}
			return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
					: ResponseEntity.status(HttpStatus.OK).body(resp);

		});

	}

	private void setFlexV2(ServerHttpRequest httpHeader, SaveCartUIRequest request) {
		if (StringUtilities.isNotEmptyOrNull(String.valueOf(httpHeader.getURI())) && CartUtil.isFlexV2(String.valueOf(httpHeader.getURI()))) {
			request.getCartInfo().setFlexV2(true);
		}
	}

	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return ResponseEntity
	 *
	 */
	@PostMapping({"/saveCartforlater","/nse/saveCartforlater"}) // savecartforlater
	public Mono<ResponseEntity<GenericResponse>> saveCartForLater(ServerHttpRequest httpHeader,
			ServerHttpResponse httpResponse, @Valid @RequestBody SaveCartForLaterUIRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "saveCartForLater");
		logger.debug("saveCartForLater Request: {}", request);
		String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
				? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
				: "";
		request.setChannelId(channelId);
		String sessionId = "";
		String flowPath = String.valueOf(httpHeader.getPath());
		if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId))) {
			sessionId = null != httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION)
					? Objects.requireNonNull(httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION)).getValue()
					: "";
			if(StringUtilities.isNotEmptyOrNull(flowPath) && flowPath.toUpperCase().contains(CartConstants.NSE)){
				request.getCartInfo().setCartCreator(sessionId);
				request.getCartInfo().setGlobalId(sessionId);
			}
		}
		return saveCartHelper.saveCartForLater(request).map(resp -> {
			ErrorResponse errors2 = null;
			if (resp.getErrors() != null) {
				errors2 = CartPegaResponseErrorsUtil.handleSaveCartResponseErrors(resp);
			}
			return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
					: ResponseEntity.status(HttpStatus.OK).body(resp);

		});

	}

}
