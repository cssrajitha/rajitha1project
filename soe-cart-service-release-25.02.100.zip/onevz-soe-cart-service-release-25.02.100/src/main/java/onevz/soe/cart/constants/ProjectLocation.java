package onevz.soe.cart.constants;

/**
 * 
 * @author PANDSI9
 *
 */
public enum ProjectLocation {
    LOCAL,
    DEV,
    QA,
    PROD
}
