package onevz.soe.cart.helper;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.requests.RetrieveCartCXPRequest;

import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.utilities.StringUtilities;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Service
public class RetrieveCartHelper {

    public ErrorResponse validateRetrieveCartRequest(ServerHttpRequest httpHeader, RetrieveCartCXPRequest request) {
        ErrorResponse response = new ErrorResponse();
        response.setErrors(validateRequest(httpHeader,request));
        return response;
    }

    private List<CartError> validateRequest(ServerHttpRequest httpHeader, RetrieveCartCXPRequest request) {
        List<CartError> validationErrors = new ArrayList<>();
        CartError cartErrors=validateUser(httpHeader,request);
        if(cartErrors !=null && StringUtilities.isNotEmptyOrNull(cartErrors.getErrorMessage())) {
            validationErrors.add(cartErrors);
            return validationErrors;
        }

        return validationErrors;
    }

    private CartError validateUser(ServerHttpRequest httpHeader, RetrieveCartCXPRequest request) {
        if (request != null && request.getMeta() !=null && request.getMeta().get("user") != null && StringUtilities.isNotEmptyOrNull(String.valueOf(request.getMeta().get("user")))){
            String name = request.getMeta().get("user");
            boolean isAlphanumericCharacter = name.matches("^[a-zA-Z0-9\\s]+$");
            boolean isInvalidLength = request.getMeta().get("user").length()>25;
            if (!isAlphanumericCharacter || isInvalidLength) {
                CartError validationError = new CartError();
                validationError.setNamespace(CartConstants.SOE_CART_SERVICE);
                validationError.setName(CartConstants.VALIDATION_ERROR);
                validationError.setErrorMessage(CartConstants.INVALID_USER);
                return validationError;
            }
        }
        return null;
    }





}