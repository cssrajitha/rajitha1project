package onevz.soe.cart.util;

import java.util.ArrayList;
import java.util.List;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.constants.PlanChangeWarningConstants;
import onevz.soe.cart.model.common.CartServiceCartInfo;
import onevz.soe.cart.model.common.FeatureMessages;
import onevz.soe.cart.model.common.Line;
import onevz.soe.cart.model.common.PlanChangeWarningMessage;
import onevz.soe.utilities.CollectionUtilities;

public class PlanChangeWarningUtil {

	public static void setFiveGPlanChangeWarning(CartServiceCartInfo cartInfo, String channelId) {
		List<PlanChangeWarningMessage> planChangeWarningMessageList = new ArrayList<PlanChangeWarningMessage>();
		if(CollectionUtilities.isNotEmptyOrNull(cartInfo.getPlanChangeWarningMessages()))
			planChangeWarningMessageList = cartInfo.getPlanChangeWarningMessages();
		if (null != cartInfo.getLines() && cartInfo.getLines().length > 0) {
			for (Line line : cartInfo.getLines()) {
				if (CollectionUtilities.isNotEmptyOrNull(line.getFeatureMessages())) {
					for (FeatureMessages message : line.getFeatureMessages()) {
						if ("5GUWBBOLT".equalsIgnoreCase(message.getName())
								&& ("ADD".equalsIgnoreCase(message.getAction()) || "DROP".equalsIgnoreCase(message.getAction()))) {
							PlanChangeWarningMessage planChangeWarningMessage = new PlanChangeWarningMessage();
							planChangeWarningMessage.setMtn(line.getMtn());
							planChangeWarningMessage.setMessageKey(PlanChangeWarningConstants.FIVEG_PLAN_CHANGE_WARNING_ID);
							if(CartConstants.OMNI_CARE.equalsIgnoreCase(channelId))
								planChangeWarningMessage.setWarningMessage(PlanChangeWarningConstants.FIVEG_PLAN_CHANGE_WARNING_MESSAGE_CARE);
							else
								planChangeWarningMessage.setWarningMessage(PlanChangeWarningConstants.FIVEG_PLAN_CHANGE_WARNING_MESSAGE_RETAIL_TELE_CHAT);
							planChangeWarningMessageList.add(planChangeWarningMessage);
						}
					}
				}
			}
		}
		if(planChangeWarningMessageList.size() > 0)
			cartInfo.setPlanChangeWarningMessages(planChangeWarningMessageList);
	}
}
