package onevz.soe.cart.helper;

import jakarta.validation.Valid;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper3;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper2;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.model.bundleAccessories.AccessoryBundleItem;
import onevz.soe.cart.model.bundleAccessories.BundleAccessoryDetail;
import onevz.soe.cart.model.bundleAccessories.CXPOrderDetails;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.common.Device;
import onevz.soe.cart.model.common.DeviceImeiSimDetails;
import onevz.soe.cart.model.deviceIdValidation.*;
import onevz.soe.cart.model.deviceIdValidation.DeviceIdValidationData;
import onevz.soe.cart.model.installmentLoan.InstallmentLoan;
import onevz.soe.cart.model.installmentLoan.LoanManagementSearchCXPResponse;
import onevz.soe.cart.model.installmentLoan.LoanManagementSearchRequest;
import onevz.soe.cart.model.retrieveCart.CXPCartVO;
import onevz.soe.cart.model.retrieveCart.CXPItemInfo;
import onevz.soe.cart.model.retrieveCart.CXPLineInfo;
import onevz.soe.cart.requests.*;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.ui.requests.DeviceIdValidationUIRequest;
import onevz.soe.cart.ui.requests.DisconnectEligibilityCheckUiRequest;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.cart.util.CartUtil;
import onevz.soe.cradle.CradleAllocator;
import onevz.soe.omnidl.service.OmniDLService;
import onevz.soe.omnidl.util.DLUtilityService;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;
import reactor.util.function.Tuple3;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;


public class ReadCartHelperParent {

    @Autowired
    private CartServiceCxpHelper cxpHelper;

    @Autowired
    private CartServiceCxpHelper2 cxpHelper2;

    @Autowired
    private CartServiceBpmHelper bpmHelper;

    @Autowired
    private CartServiceBpmHelper3 bpmHelper3;

    @Autowired
    private RedisHelper redisHelper;

    @Autowired
    private RedisHelper2 redisHelper2;

    @Autowired
    SOELoginSessionBean sessionBean;

    @Autowired
    CradleAllocator cradleAllocator;

    @Autowired
    OmniDLService dlService;

    @Autowired
    CartIgHelper cartIgHelper;

    @Autowired
    CartServiceCXPServices cartServiceCXPServices;

    @Autowired
    DLUtilityService dlUtilityService;

    @Autowired
    private FeatureFlagHelper featureFlagHelper;

    @Value("${enableMHOffers}")
    private boolean enableMHOffers;

    @Value("${displayCartValidationErrors}")
    private boolean displayCartValidationErrors;


    @Value("${overrideCartIdFromRedis}")
    private boolean overrideCartIdFromRedis;

    @Value("${enableDeviceIdChecksumGenerator}")
    private boolean enableDeviceIdChecksumGenerator;

    @Value("${enableEsimAtlocalInventory}")
    private boolean enableEsimAtlocalInventory;

    //https://onejira.verizon.com/browse/VCGH-4116
    @Value("${enableEsimMigrationChanges}")
    private boolean enableEsimMigrationChanges;

    @Value("${deviceActiveCheck}")
    private boolean deviceActiveCheck;

    @Value("${devicePreorderCheck}")
    private boolean devicePreorderCheck;

    @Value("${deviceActiveLoanCheck}")
    private boolean deviceActiveLoanCheck;

    @Value("${devicePendingLoanCheck}")
    private boolean devicePendingLoanCheck;

    @Value("${imeiCheck}")
    private boolean imeiCheck;

    @Value(("${deviceReturnCheck}"))
    private boolean deviceReturnCheck;

    @Value(("${deviceCheckFor5GHomeOrFWA}"))
    private boolean deviceCheckFor5GHomeOrFWA;

    private static final Logger logger = LoggerFactory.getLogger(ReadCartHelperParent.class);

    protected Mono<BundleAccessoryDetail> checkAccessoryBundle(RetrieveAccCartCXPResponse retrieveAccCartCXPResponse) {
        List<AccessoryBundleItem> lstOfAccessoryItems = Arrays.stream(retrieveAccCartCXPResponse.getData().getCart().getLineDetails().getLineInfo()).filter(f -> f.getItemsInfo() != null).flatMap(s ->
                Arrays.stream(s.getItemsInfo()).filter(c -> c.getCartItems() != null && c.getCartItems().getCartItem() != null).flatMap(b ->
                        Arrays.stream(b.getCartItems().getCartItem()).filter(d -> "ACCESSORY".equalsIgnoreCase(d.getCartItemType()) && "Y".equalsIgnoreCase(d.getAccessoryBMSM())
                                        && d.getImageUrlMap() != null)
                                .map(k -> {
                                    List<AccessoryBundleItem> accessoryBundleItems = new ArrayList<>();
                                    for (int i = 0; i < k.getQty(); i++) {
                                        AccessoryBundleItem accessoryBundleItem = new AccessoryBundleItem();
                                        accessoryBundleItem.setSorId(k.getSorId());
                                        accessoryBundleItem.setThumbImage(k.getImageUrlMap().getThumbImage());
                                        accessoryBundleItem.setMiniImage(k.getImageUrlMap().getMiniImage());
                                        accessoryBundleItem.setDescription(k.getManufacturer() + " " + k.getDescription());
                                        if (null != s.getMtnDetails()) {
                                            accessoryBundleItem.setMtn(s.getMtnDetails().getLineNumber());
                                        }
                                        accessoryBundleItem.setIntentType(s.getLineActivityType());
                                        accessoryBundleItems.add(accessoryBundleItem);
                                    }
                                    return accessoryBundleItems;
                                }))).flatMap(lst -> lst.stream()).collect(Collectors.toList());
        if(lstOfAccessoryItems!=null && !lstOfAccessoryItems.isEmpty()) {
            if(retrieveAccCartCXPResponse.getData().getCart().getOrderDetails()!=null) {
            CXPOrderDetails orderDetails = retrieveAccCartCXPResponse.getData().getCart().getOrderDetails();
            BundleAccessoryDetail bundleAccessoryDetail = new BundleAccessoryDetail();
            bundleAccessoryDetail.setExceedLimit(false);
            if(lstOfAccessoryItems!=null && lstOfAccessoryItems.size()>10) {
                bundleAccessoryDetail.setExceedLimit(true);
                bundleAccessoryDetail.setAccessoryBundleItems(lstOfAccessoryItems.subList(0, 10));
            } else {
                bundleAccessoryDetail.setAccessoryBundleItems(lstOfAccessoryItems);
            }
            bundleAccessoryDetail.setTotalDiscountedPrice(orderDetails.getTotalAccessoryBundleDiscountedPrice());
            bundleAccessoryDetail.setTotalRetailPrice(orderDetails.getTotalAccessoryBunldeRetailPrice());
            bundleAccessoryDetail.setBundleSavingAmount(orderDetails.getBundleSavingAmount());
            return Mono.just(bundleAccessoryDetail);

        }
      }
        return Mono.just(new BundleAccessoryDetail());
    }


    protected void setFiOSDiscountCost(RetrieveCartUIResponse cxpResponse) {
        if(null != cxpResponse.getData().getCart().getOrderDetails() && null != cxpResponse.getData().getCart().getOrderDetails().getFiosAccountInfo() ) {
            if(StringUtilities.isNotEmptyOrNull(cxpResponse.getData().getCart().getOrderDetails().getFiosAccountInfo().getUpSpeedInfo())) {
                String fiosSpeed = cxpResponse.getData().getCart().getOrderDetails().getFiosAccountInfo().getUpSpeedInfo();
            String[] speedDetails = fiosSpeed.split("M");
            if (StringUtilities.isNotEmptyOrNull(speedDetails) && StringUtilities.isNotEmptyOrNull(speedDetails[0])) {
                int speed = Integer.parseInt(speedDetails[0]);
                if (speed >= 1024 && !checkWelcomeUnlimtedPlan(cxpResponse)) {
                    cxpResponse.getData().getCart().getOrderDetails().setFiosDiscountCost("10");
                } else {
                    cxpResponse.getData().getCart().getOrderDetails().setFiosDiscountCost("5");
                }
            }
          }
        }
    }

    /*
     * checking if any line has welcome unlimited plan
     */
    protected Boolean checkWelcomeUnlimtedPlan(RetrieveCartUIResponse cxpResponse) {

        try {
            if (cxpResponse.getData().getCart() != null && cxpResponse.getData().getCart().getLineDetails() != null && cxpResponse.getData().getCart().getLineDetails().getLineInfo() != null) {

                CXPLineInfo[] lineInfo = cxpResponse.getData().getCart().getLineDetails().getLineInfo();
                long lineCount = Arrays.stream(lineInfo).filter(lineDetails -> lineDetails.getServiceInfo() != null && lineDetails.getServiceInfo().getNewPricePlanInfo() != null
                        && "87".equals(lineDetails.getServiceInfo().getNewPricePlanInfo().getCategoryCode())).count();
                if (lineCount > 0) {
                    return true;
                }

            }
        } catch(Exception e) {
            logger.error("Exception in checkWelcomeUnlimtedPlan() method in retrieve cart call: {}" , e.getMessage());
        }
        return false;
    }


    protected void sharedCartFlowName(CXPCartVO cart){
        try {
            StringBuilder builder = new StringBuilder();
            AtomicInteger index = new AtomicInteger(0);
            if(cart.getLineDetails() != null && cart.getLineDetails().getLineInfo() != null ){
                Arrays.stream(cart.getLineDetails().getLineInfo()).filter(loopLineInfo -> StringUtilities.isNotEmptyOrNull(loopLineInfo.getLineActivityType()) && ("EUP".equalsIgnoreCase(loopLineInfo.getLineActivityType()) || "AAL".equalsIgnoreCase(loopLineInfo.getLineActivityType())))
                        .forEach(loopLine -> {
                            builderLineDetails(cart, loopLine, builder, index);
                            dlUtilityService.updateDlData(loopLine.getLineActivityType());
                        });
                /*if(StringUtilities.isNotEmptyOrNull(builder.toString())) {
                    dlUtilityService.updateDlData(builder.toString());
                }*/

            }
        } catch (Exception ex) {
            logger.error("Exception while calling updateDlDataMono method inside retrieve-cart {}", ex.getMessage());
        }
    }

    protected void builderLineDetails(CXPCartVO cart, CXPLineInfo loopLine, StringBuilder builder, AtomicInteger index){
        if (cart.getLineDetails().getLineInfo().length == 1) {
            logger.info("DLUtilityService ::updateDlData method calling started inside retrieve-cart {}", loopLine.getLineActivityType());
            builder.append(loopLine.getLineActivityType());
        } else {
            logger.info("DLUtilityService ::updateDlData method calling started inside retrieve-cart {}", loopLine.getLineActivityType());
            if (index.get() == 0) {
                builder.append(loopLine.getLineActivityType());
            } else {
                builder.append(" w/" + loopLine.getLineActivityType());
            }
        }
        index.getAndIncrement();
    }
    protected String getCustomerFiosPlanType(String customerFiosPlanType) {

        return customerFiosPlanType.equalsIgnoreCase("Y") ? "gig" : customerFiosPlanType.equalsIgnoreCase("N")? "nonGig":null;
    }


    protected boolean checkEsimMigrationCondition(ESimDetailsETNIRequest request) {

        if (enableEsimMigrationChanges && StringUtilities.isNotEmptyOrNull(request.getProcessInd())
                && CartConstants.PROCESS_INDICATOR_M.equalsIgnoreCase(request.getProcessInd())) {
            return true;
        } else {
            return false;
        }
    }

    protected   List<CartError> CartIdErrorResponse() {
        List<CartError> errors = new ArrayList<>();
        CartError error = new CartError();
        error.setName("VALIDATION_ERROR");
        error.setCode("");
        error.setDebug_id("");
        error.setId("R1001");
        error.setMessage("CartId or Case Id is not present in redis");
        errors.add(error);
        return errors;

    }

    protected void formatCxpLineInfo(CXPLineInfo cxpLineInfo) {
        if(cxpLineInfo.getServiceInfo() != null && cxpLineInfo.getServiceInfo().getPrimaryUserInfo() != null) {
            cxpLineInfo.getServiceInfo().getPrimaryUserInfo().setPreferFirstName(null);
            cxpLineInfo.getServiceInfo().getPrimaryUserInfo().setPreferLastName(null);
            cxpLineInfo.getServiceInfo().getPrimaryUserInfo().setPreferPronoun(null);
        }
        if(cxpLineInfo.getItemsInfo() != null) {
            for(CXPItemInfo item: cxpLineInfo.getItemsInfo()){
                if(item != null && item.getShipping() != null && item.getShipping().getAddress() != null) {
                    item.getShipping().getAddress().setPreferFirstName(null);
                    item.getShipping().getAddress().setPreferLastName(null);
                    item.getShipping().getAddress().setPreferPronoun(null);
                }
            }
        }
    }


    protected void formatValidateCartAndUpdate(ValidateCartUIResponse cxpResponse, CartRedisData data, ValidateCartCXPRequest request, String channelType) {
        CXPCartVO cart = CartUtil.updateGrantorDetails(cxpResponse.getData().getValidateCartAndUpdate());
        if (StringUtilities.isNotEmptyOrNull(channelType) && channelType.equalsIgnoreCase(CartConstants.ASSISTED))
            cart = CartUtil.sumOfLocalTaxes(cart);

        cart = CartUtil.calculateMemberCount(cart, request.getMtnList(),data.getVzwRoles());
        cxpResponse.getData().setValidateCartAndUpdate(CartUtil.updateShippingCost(cart));
        cxpResponse.getData().getValidateCartAndUpdate().setAccountEligibility(true);
    }

    public Mono<DeviceIdValidationUIResponse> validateSimId(Device device,DeviceIdValidationUIRequest request) {
        DeviceIdValidationUIResponse deviceIdValidationUIResponse = new DeviceIdValidationUIResponse();
        if (request.isIccidStatusCheck() && StringUtilities.isNotEmptyOrNull(device.getFlowtype()) && device.getFlowtype().contains(CartConstants.FLOW_TYPE_SIM) &&
                device.getSim()!=null && StringUtilities.isNotEmptyOrNull(device.getSim().getId()) ) {
            String[] iccids = {device.getSim().getId()};
            Optional<DeviceIdValidationLine> line = Optional.ofNullable(request).map(DeviceIdValidationUIRequest::getData).map(DeviceIdValidationData::getLines).map(lines -> lines.isEmpty() ? null : lines.get(0));

            IccidDetailsETNIRequest iccidDetailsETNIRequest = new IccidDetailsETNIRequest();
            iccidDetailsETNIRequest.setBillerId("A");
            iccidDetailsETNIRequest.setUserId(request.getLoggedInUser()!=null?request.getLoggedInUser():"tester");
            iccidDetailsETNIRequest.setIccids(iccids);
            Mono<IccidDetailsETNIResponse> etniResponseMono = cartServiceCXPServices.iccidDetails(iccidDetailsETNIRequest);
            return etniResponseMono.flatMap(resp -> {
                logger.info("ETNI response validation for simId");
                if (resp != null && resp.getData() != null && resp.getData().getIccidDetails() != null) {
                    boolean isValidSim = true;
                    String errorMsg = "";
                    IccidDetails[] iccidDetails = resp.getData().getIccidDetails();
                    if (iccidDetails.length > 0) {
                        for (IccidDetails eq : resp.getData().getIccidDetails()) {
                            if(line.isPresent() && StringUtilities.isNotEmptyOrNull(line.get().getMtn()) && line.get().getMtn().equalsIgnoreCase(eq.getMdn())){
                                isValidSim = true;
                                break;
                            }
                            else {
                                List<String> allowedIccidStatus  = new ArrayList<>();
                                allowedIccidStatus.add("AA");
                                allowedIccidStatus.add("AD");
                                if (eq.getIccidStatus() != null && !allowedIccidStatus.contains(eq.getIccidStatus().toUpperCase())) {
                                    isValidSim = false;
                                    errorMsg = CartConstants.SIMID_ALREADY_MAPPED_ERROR_MSG + " " + eq.getMdn();
                                    break;
                                }
                            }
                        }
                        if(!isValidSim){
                            List<CartError> errorList = handleCartError(CartConstants.VALIDATION_ERROR,errorMsg,CartConstants.BUSINESS_ERR);
                            deviceIdValidationUIResponse.setErrors(errorList);
                            return Mono.just(deviceIdValidationUIResponse);
                        }
                    }
                }
                return Mono.just(new DeviceIdValidationUIResponse());
            }).onErrorResume(err -> {
                logger.error(err.getMessage());
                List<CartError> errorList = handleCartError(CartConstants.SOE_CART_SERVICE,CartConstants.CXP_RSPNS_FTCH_EXCPTN_STRNG,CartConstants.ERRCAT_CXP);
                deviceIdValidationUIResponse.setErrors(errorList);
                return Mono.just(deviceIdValidationUIResponse);
            });
        }
        return Mono.just(deviceIdValidationUIResponse);
    }

    public Mono<DeviceIdValidationUIResponse> validateDeviceSimId(DeviceIdValidationUIRequest request) {
        Optional<Device> device = Optional.ofNullable(request).map(DeviceIdValidationUIRequest::getData).map(DeviceIdValidationData::getLines).map(lines -> lines.isEmpty() ? null : lines.get(0)).map(DeviceIdValidationLine::getDevice);
        if (device.isPresent()) {
            Mono<Tuple2<DeviceIdValidationUIResponse, DeviceIdValidationUIResponse>> zippedMono = Mono.zip(
                    validateDeviceId(device.get().getId(), device.get().getFlowtype(), device.get().getExistingDeviceId(), request),
                    validateSimId(device.get(), request)
            );

            return zippedMono.flatMap(resp -> {
                        if (resp.getT1().getErrors() != null) {
                            return Mono.just(resp.getT1());
                        } else if (resp.getT2().getErrors() != null) {
                            return Mono.just(resp.getT2());
                        }
                        return Mono.just(new DeviceIdValidationUIResponse());
                    }
            );
        }
        return Mono.just(new DeviceIdValidationUIResponse());
    }


    public Mono<DeviceIdValidationUIResponse> validateDeviceId(String deviceId, String flowType, String existingDeviceId, DeviceIdValidationUIRequest deviceIdValidationUIRequest) {
        DeviceIdValidationUIResponse deviceIdValidationUIResponse = new DeviceIdValidationUIResponse();
        if ((deviceActiveCheck || devicePreorderCheck|| deviceActiveLoanCheck || deviceReturnCheck) &&
                StringUtilities.isNotEmptyOrNull(flowType) && flowType.contains(CartConstants.FLOW_TYPE_DEVICE) && StringUtilities.isNotEmptyOrNull(deviceId)) {
            if(deviceReturnCheck) {
                String err = existingDeviceMatch(existingDeviceId, deviceId);
                if(StringUtilities.isNotEmptyOrNull(err)) {
                    List<CartError> errorList = handleCartError(CartConstants.VALIDATION_ERROR, err, CartConstants.BUSINESS_ERR);
                    deviceIdValidationUIResponse.setErrors(errorList);
                    return Mono.just(deviceIdValidationUIResponse);
                }
            }
            SearchOrderManagementCXPRequest searchOrderManagementCXPRequest = new SearchOrderManagementCXPRequest();
            Filters filters = new Filters();
            searchOrderManagementCXPRequest.setDeviceId(deviceId);
            searchOrderManagementCXPRequest.setFilters(new Filters[]{filters});
            LoanManagementSearchRequest loanManagementSearchRequest = new LoanManagementSearchRequest();
            onevz.soe.cart.model.installmentLoan.Device device1 = new onevz.soe.cart.model.installmentLoan.Device();
            device1.setId(deviceId);
            loanManagementSearchRequest.setDevice(new onevz.soe.cart.model.installmentLoan.Device[]{device1});
            Mono<Tuple3<String, String, String>> zippedMono = Mono.zip(
                    isDeviceActive(searchOrderManagementCXPRequest, deviceIdValidationUIRequest),
                    loanSearchByDeviceId(loanManagementSearchRequest),
                    loanPendingSearchByDeviceId(deviceId)
            );
            return zippedMono.flatMap(updated -> {
                if (StringUtilities.isNotEmptyOrNull(updated.getT1())) {
                    List<CartError> errorList = handleCartError(CartConstants.VALIDATION_ERROR, updated.getT1(), CartConstants.BUSINESS_ERR);
                    deviceIdValidationUIResponse.setErrors(errorList);
                    return Mono.just(deviceIdValidationUIResponse);
                }
                else if (StringUtilities.isNotEmptyOrNull(updated.getT2())) {
                    List<CartError> errorList = handleCartError(CartConstants.VALIDATION_ERROR, updated.getT2(), CartConstants.BUSINESS_ERR);
                    deviceIdValidationUIResponse.setErrors(errorList);
                    return Mono.just(deviceIdValidationUIResponse);
                }
                else if(StringUtilities.isNotEmptyOrNull(updated.getT3())) {
                    List<CartError> errorList = handleCartError(CartConstants.VALIDATION_ERROR, updated.getT3(), CartConstants.BUSINESS_ERR);
                    deviceIdValidationUIResponse.setErrors(errorList);
                    return Mono.just(deviceIdValidationUIResponse);
                }
                return Mono.just(new DeviceIdValidationUIResponse());
            }).onErrorResume(err -> {
                logger.error(err.getMessage());
                List<CartError> errorList = handleCartError(CartConstants.API_ERROR,CartConstants.CXP_RSPNS_FTCH_EXCPTN_STRNG,CartConstants.ERRCAT_CXP);
                deviceIdValidationUIResponse.setErrors(errorList);
                return Mono.just(deviceIdValidationUIResponse);
            });
        }
        return Mono.just(deviceIdValidationUIResponse);
    }

    public String existingDeviceMatch(String existingDeviceId, String deviceId) {
        String errorMess = "";
        if (existingDeviceId != null && deviceId.equalsIgnoreCase(existingDeviceId)) {
            errorMess = CartConstants.RETURNED_EQUIPMENT_ERROR_MSG;
            logger.info(String.format("For the entered deviceId:the return order is still being processed : %s", deviceId));
        }
        return errorMess;
    }

    public Mono<String> isDeviceActive(SearchOrderManagementCXPRequest request, DeviceIdValidationUIRequest deviceIdValidationUIRequest) {
        if(deviceActiveCheck || devicePreorderCheck || deviceCheckFor5GHomeOrFWA) {
            return cartServiceCXPServices.search(request).flatMap(resp -> {
                String errorMess = "";
                if (resp != null && resp.getData() != null && resp.getData().getOrderDetails() != null) {
                    EquipmentOrders[] equipmentOrders = resp.getData().getOrderDetails().getEquipmentOrders();
                    if (equipmentOrders.length > 0) {
                        for (EquipmentOrders eq : resp.getData().getOrderDetails().getEquipmentOrders()) {
                            if (eq.getStatusCode() != null && eq.getPhoneInfo() != null && request.getDeviceId().equalsIgnoreCase(eq.getPhoneInfo().getDeviceId())) {
                                if (devicePreorderCheck && eq.getStatusCode().getIsOpened()) {
                                    errorMess = CartConstants.PENDING_EQUIPMENT_ERROR_MSG1 + (eq.getOrderingMtn()!= null? eq.getOrderingMtn():"") + CartConstants.PENDING_EQUIPMENT_ERROR_MSG2;
                                    logger.info(String.format("For the entered deviceId there is a pending order on MTN : %s ", eq.getOrderingMtn()));
                                    break;
                                } else if(deviceCheckFor5GHomeOrFWA && deviceIdValidationUIRequest != null && deviceIdValidationUIRequest.getCartInfo() != null
                                        && deviceIdValidationUIRequest.getCartInfo().getAction() != null
                                        && (CartConstants.AAL_5G.equals(deviceIdValidationUIRequest.getCartInfo().getAction()) ||
                                        CartConstants.NSE_5G.equals(deviceIdValidationUIRequest.getCartInfo().getAction()) ||
                                        CartConstants.AAL_LTE.equals(deviceIdValidationUIRequest.getCartInfo().getAction()) ||
                                        CartConstants.NSE_LTE.equals(deviceIdValidationUIRequest.getCartInfo().getAction())
                                )) {
                                    logger.info("The entered deviceId is 4G Home or 5G Home or FWA, Hence allowing to with the execution.");
                                    break;
                                }else if (deviceActiveCheck && eq.getStatusCode().getIsClosed() &&
                                        ("TC".equalsIgnoreCase(eq.getStatusReasonCode()) || "NC".equalsIgnoreCase(eq.getStatusReasonCode()))) {
                                    errorMess = CartConstants.PENDING_EQUIPMENT_ERROR_MSG1 + (eq.getOrderingMtn()!= null? eq.getOrderingMtn():"") + CartConstants.PENDING_EQUIPMENT_ERROR_MSG2;
                                    logger.info(String.format("For the entered deviceId there is a pending order on MTN : %s ", eq.getOrderingMtn()));
                                    break;
                                }
                            }
                        }
                    }
                }
                return Mono.just(errorMess);
            });
        }
        return Mono.just("");
    }

    public Mono<String> loanSearchByDeviceId(LoanManagementSearchRequest loanManagementSearchRequest) {
        if (deviceActiveLoanCheck) {
            Mono<LoanManagementSearchCXPResponse> cxpResponseMono = cartServiceCXPServices.loanSearchByDeviceId(loanManagementSearchRequest);
            return cxpResponseMono.flatMap(resp -> {
                String errorMess = "";
                String mtn;
                if (resp != null && resp.getData() != null && CollectionUtilities.isNotEmptyOrNull(resp.getData().getInstallmentLoans())) {
                    List<InstallmentLoan> installmentLoans = resp.getData().getInstallmentLoans();
                    for (InstallmentLoan installmentLoan : installmentLoans) {
                        if (installmentLoan != null && installmentLoan.getLoanStatus() != null && installmentLoan.getLoanStatus().getIsActive()) {
                            mtn = installmentLoan.getMtnRef() != null && installmentLoan.getMtnRef().getId() != null ? installmentLoan.getMtnRef().getId() : "";
                            errorMess = CartConstants.PENDING_EQUIPMENT_ERROR_MSG1 + mtn + CartConstants.PENDING_EQUIPMENT_ERROR_MSG2;
                            logger.info(String.format("For the entered deviceId there is an active loan on MTN : %s ", mtn));
                            break;
                        }
                    }
                }
                return Mono.just(errorMess);
            }).onErrorResume(err -> {
                SOEHTTPException exception = (SOEHTTPException) err;
                if (exception.getErrorCode() == 404) {
                    logger.error(err.getMessage());
                    return Mono.just("");
                }
                return Mono.error(err);
            });
        }
        return Mono.just("");
    }

    public Mono<String> loanPendingSearchByDeviceId(String deviceId) {
        if (devicePendingLoanCheck) {
            Mono<LoanManagementSearchCXPResponse> cxpResponseMono = cartServiceCXPServices.pendingLoanSearchByDeviceId(deviceId);
            return cxpResponseMono.flatMap(resp -> {
                String errorMess = "";
                String mtn;
                if (resp != null && resp.getData() != null && CollectionUtilities.isNotEmptyOrNull(resp.getData().getInstallmentLoans())) {
                    List<InstallmentLoan> installmentLoans = resp.getData().getInstallmentLoans();
                    for (InstallmentLoan installmentLoan : installmentLoans) {
                        if (installmentLoan != null && "Y".equalsIgnoreCase(installmentLoan.getPendingLoanIndicator())) {
                            mtn = installmentLoan.getMtnRef() != null && installmentLoan.getMtnRef().getId() != null ? installmentLoan.getMtnRef().getId() : "";
                            errorMess = CartConstants.PENDING_LOAN_ERROR_MSG;
                            logger.info(String.format("For the entered deviceId there is an pending loan on MTN : %s ", mtn));
                            break;
                        }
                    }
                }
                return Mono.just(errorMess);
            }).onErrorResume(err -> {
                SOEHTTPException exception = (SOEHTTPException) err;
                if (exception.getErrorCode() == 404) {
                    logger.error(err.getMessage());
                    return Mono.just("");
                }
                return Mono.error(err);
            });
        }
        return Mono.just("");
    }

    public Mono<DisconnectEligibilityCheckUiResponse> validateMtnEligibleForDisconnect(DisconnectEligibilityCheckUiRequest request){

        DisconnectEligibilityCheckUiResponse response = new DisconnectEligibilityCheckUiResponse();
        if(request.getMtn()!=null && request.getMtn().length>0 && StringUtilities.isNotEmptyOrNull(request.getLocationCode())) {
            return Flux.fromIterable(Arrays.asList(request.getMtn())).flatMap(mtn->{
                SearchOrderManagementCXPRequest searchOrderManagementCXPRequest = new SearchOrderManagementCXPRequest();
                Filters filters = new Filters();
                searchOrderManagementCXPRequest.setMtn(mtn);
                FieldsFlag fieldsFlag = new FieldsFlag();
                fieldsFlag.setAllOrders(false);
                fieldsFlag.setRecentOrders(true);
                filters.setFieldsFlag(fieldsFlag);
                searchOrderManagementCXPRequest.setFilters(new Filters[]{filters});
                return checkMtnIsEligibleForDisconnect(searchOrderManagementCXPRequest,request.getLocationCode()).flatMap(res->{
                    DisconnectEligibilityMtnStatus mtnStatus = new DisconnectEligibilityMtnStatus();
                    mtnStatus.setMtn(mtn);
                    mtnStatus.setEligibleForDisconnect(res);
                    return  Mono.just(mtnStatus);
                }).onErrorResume(err-> {
                    logger.error(err.getMessage());
                    DisconnectEligibilityMtnStatus mtnStatus = new DisconnectEligibilityMtnStatus();
                    mtnStatus.setMtn(mtn);
                    mtnStatus.setEligibleForDisconnect(false);
                    return Mono.just(mtnStatus);
                });
            }).collectList().flatMap(mtnstatusList->{
                response.setData(mtnstatusList);
                return Mono.just(response);
            });
        }
        return Mono.just(response);

    }

    public Mono<Boolean> checkMtnIsEligibleForDisconnect(SearchOrderManagementCXPRequest request,String locationCode)
    {
        return cartServiceCXPServices.search(request).flatMap(resp -> {
            if (resp != null && resp.getData() != null && resp.getData().getOrderDetails() != null) {
                EquipmentOrders[] equipmentOrders = resp.getData().getOrderDetails().getEquipmentOrders();
                if (equipmentOrders.length > 0) {
                    for (EquipmentOrders eq : resp.getData().getOrderDetails().getEquipmentOrders()) {
                        if (request.getMtn().equalsIgnoreCase(eq.getOrderingMtn()) && StringUtilities.isEmptyOrNull(eq.getEsnReasonCode()) && CartConstants.DISCONNECT_ELIGIBLE_STATUS_REASON_CODE.equalsIgnoreCase(eq.getStatusReasonCode())) {
                            if (locationCode.equalsIgnoreCase(eq.getLocationCode())) {
                                return  Mono.just(true);
                            } else {
                                Mono<Tuple2<String, String>> masterAgentDatas = Mono.zip(
                                        getMasterAgentIdByLocation(locationCode),
                                        getMasterAgentIdByLocation(eq.getLocationCode())
                                );
                                return masterAgentDatas.flatMap(res -> {
                                    if (StringUtilities.isNotEmptyOrNull(res.getT1()) &&
                                            StringUtilities.isNotEmptyOrNull(res.getT2()) && res.getT1().equalsIgnoreCase(res.getT2())) {
                                        return  Mono.just(true);
                                    }
                                    return  Mono.just(false);
                                });
                            }
                        }
                    }
                }
            }
            return Mono.just(false);
        }).onErrorResume(err -> Mono.error(err));
    }

    public Mono<String> getMasterAgentIdByLocation(String locationCode){
        RetrieveGlobalLocationDetailsCxpRequest request = new RetrieveGlobalLocationDetailsCxpRequest();
        request.setLocationCode(locationCode);
        return cartServiceCXPServices.retrieveGlobalLocationDetails(request).flatMap(resp-> {
            String masterAgentId = "";
            if (resp != null && resp.getData()!=null && resp.getData().getLocationCodeLookup()!=null
                    && resp.getData().getLocationCodeLookup().getResponse()!=null
                    && resp.getData().getLocationCodeLookup().getResponse().getMasterAgentID()!=null ){
                masterAgentId = resp.getData().getLocationCodeLookup().getResponse().getMasterAgentID();
            }
            return Mono.just(masterAgentId);
        }).onErrorResume(err -> Mono.error(err));
    }

    private List<CartError> handleCartError(String name, String msg, String errorCategory){
        CartError cartError = new CartError();
        cartError.setNamespace(CartConstants.SOE_CART_SERVICE);
        cartError.setName(name);
        cartError.setMessage(msg);
        cartError.setErrorCategory(errorCategory);
        List<CartError> errorList = new ArrayList<>();
        errorList.add(cartError);
        return errorList;
    }
    public Mono<DeviceIdValidationUIResponse> imeiValidationCheck(DeviceIdValidationUIResponse deviceIdValidationUIResponse, DeviceIdValidationUIRequest request) {
        Mono<DeviceIdValidationUIResponse> deviceIdValidationUIResponseMono1 = Mono.empty();
        if (imeiCheck) {
            Optional<DeviceInfo> deviceInfo = Optional.ofNullable(deviceIdValidationUIResponse).map(DeviceIdValidationUIResponse::getServiceBody).map(DeviceIdValidationServiceBody::getServiceResponse).map(DeviceIdValidationServiceResponse::getContext).map(DeviceIdValidationContext::getDeviceInfo);
            if (deviceInfo.isPresent() && StringUtilities.isNotEmptyOrNull(deviceInfo.get().getImei1()) && StringUtilities.isNotEmptyOrNull(deviceInfo.get().getImei2())) {
                Optional<Device> device = Optional.ofNullable(request).map(DeviceIdValidationUIRequest::getData).map(DeviceIdValidationData::getLines).map(lines -> lines.isEmpty() ? null : lines.get(0)).map(DeviceIdValidationLine::getDevice);
                if (device.isPresent()) {
                    if (!(deviceInfo.get().getImei1().equalsIgnoreCase(device.get().getId()))) {
                        deviceIdValidationUIResponseMono1 = validateDeviceId(deviceInfo.get().getImei1(), device.get().getFlowtype(), device.get().getExistingDeviceId(), request);
                    } else if (!(deviceInfo.get().getImei2().equalsIgnoreCase(device.get().getId()))) {
                        deviceIdValidationUIResponseMono1 = validateDeviceId(deviceInfo.get().getImei2(), device.get().getFlowtype(), device.get().getExistingDeviceId(), request);
                    }
                    return deviceIdValidationUIResponseMono1;
                }
            }
        }
        return deviceIdValidationUIResponseMono1;
    }

    public void performMaskingForBYOD(DeviceIdValidationUIResponse resp, @Valid DeviceIdValidationUIRequest request) {
        if (CartUtil.isByodFlow(request.getCartInfo().getIntent()) && featureFlagHelper.isMaskingForBYODFFlag()) {
            DeviceInfo deviceInfo = getDeviceInfo(resp);
            if (null != deviceInfo) {
                maskDeviceInfo(deviceInfo);
                maskSimInfo(deviceInfo);
                resp.getServiceBody().getServiceResponse().getContext().setDeviceInfo(deviceInfo);
            }
        }
    }

    private void maskDeviceInfo(DeviceInfo deviceInfo) {
        if (StringUtilities.isNotEmptyOrNull(deviceInfo.getDeviceId())){
            deviceInfo.setDeviceId(CartUtil.maskStringField(deviceInfo.getDeviceId(), 4));
        }
        if (StringUtilities.isNotEmptyOrNull(deviceInfo.getImei1())) {
            deviceInfo.setImei1(CartUtil.maskStringField(deviceInfo.getImei1(), 4));
        }
        if (StringUtilities.isNotEmptyOrNull(deviceInfo.getImei2())) {
            deviceInfo.setImei2(CartUtil.maskStringField(deviceInfo.getImei2(), 4));
        }
        if (null != deviceInfo.getESimInfo() && StringUtilities.isNotEmptyOrNull(deviceInfo.getESimInfo().getEID())) {
            deviceInfo.getESimInfo().setEID(CartUtil.maskStringField(deviceInfo.getESimInfo().getEID(), 4));
        }
        if (null != deviceInfo.getPairedImeiData() && StringUtilities.isNotEmptyOrNull(deviceInfo.getPairedImeiData().getPairedImei())) {
            deviceInfo.getPairedImeiData().setPairedImei(CartUtil.maskStringField(deviceInfo.getPairedImeiData().getPairedImei(), 4));
        }
        if (null != deviceInfo.getPairedImeiData() && StringUtilities.isNotEmptyOrNull(deviceInfo.getPairedImeiData().getEid())) {
            deviceInfo.getPairedImeiData().setEid(CartUtil.maskStringField(deviceInfo.getPairedImeiData().getEid(), 4));
        }
    }

    private void maskSimInfo(DeviceInfo deviceInfo) {
        if(null != deviceInfo.getSimInfo()){
            deviceInfo.setSimInfo(getMaskedSimInfo(deviceInfo.getSimInfo()));
        }
        if(null != deviceInfo.getSimInfo2()){
            deviceInfo.setSimInfo2(getMaskedSimInfo(deviceInfo.getSimInfo2()));
        }
    }

    private SimInfo getMaskedSimInfo(SimInfo simInfo) {
            if (StringUtilities.isNotEmptyOrNull(simInfo.getESimid())){
                simInfo.setESimid(CartUtil.maskStringField(simInfo.getESimid(), 4));
            }
            if (StringUtilities.isNotEmptyOrNull(simInfo.getEID())){
                simInfo.setEID(CartUtil.maskStringField(simInfo.getEID(), 4));
            }
            if (StringUtilities.isNotEmptyOrNull(simInfo.getDeviceId())){
                simInfo.setDeviceId(CartUtil.maskStringField(simInfo.getDeviceId(), 4));
            }
            if (StringUtilities.isNotEmptyOrNull(simInfo.getIccid())){
                simInfo.setIccid(CartUtil.maskStringField(simInfo.getIccid(), 4));
            }
        return simInfo;
    }

    private DeviceInfo getDeviceInfo(DeviceIdValidationUIResponse resp){
        if(resp.getServiceBody() != null && resp.getServiceBody().getServiceResponse() != null
                && resp.getServiceBody().getServiceResponse().getContext() != null
                && resp.getServiceBody().getServiceResponse().getContext().getDeviceInfo() != null){
            return resp.getServiceBody().getServiceResponse().getContext().getDeviceInfo();
        }
        return null;
    }
    public void updateRequestDataFromRedisForMasking(DeviceIdValidationUIRequest deviceIdValidationUIRequest, CartRedisData data) {
        if (featureFlagHelper.isMaskingForBYODFFlag() && CollectionUtilities.isNotEmptyOrNull(deviceIdValidationUIRequest.getData().getLines())) {
            for (DeviceIdValidationLine line : deviceIdValidationUIRequest.getData().getLines()) {
                DeviceImeiSimDetails deviceImeiSimDetails = data.getDeviceImeiSimDetails();
                if(null!=line && null!=deviceImeiSimDetails) {
                    updateForPairedImeiDetailsEmpty(line, deviceImeiSimDetails);
                    updateForInactiveDevices(line, deviceImeiSimDetails);
                }
            }
        }
    }

    private static void updateForInactiveDevices(DeviceIdValidationLine line, DeviceImeiSimDetails deviceImeiSimDetails) {
        if (null!= line.getDevice() && line.getDevice().isInactiveDeviceFlow()){
            String key = line.getDevice().getSorId() + line.getDevice().getId();
            Map<String, String> inactiveDevices = deviceImeiSimDetails.getInactiveDevices();
            if(CollectionUtilities.isNotEmptyOrNull(inactiveDevices)){
                String deviceId = inactiveDevices.get(key);
                if(StringUtilities.isNotEmptyOrNull(deviceId))
                    line.getDevice().setId(deviceId);
            }
        }
    }

    private static void updateForPairedImeiDetailsEmpty(DeviceIdValidationLine line, DeviceImeiSimDetails deviceImeiSimDetails) {
        if(line != null && line.getDevice() != null
                && Boolean.TRUE.equals(line.getDevice().isPairedImeiDetailsEmpty())) {
            if (line.getDevice().getByodESimPhone()) {
                line.getDevice().setId(deviceImeiSimDetails.getImei2());
            } else {
                line.getDevice().setId(deviceImeiSimDetails.getImei1());
            }
        }
    }
}
