package onevz.soe.cart.util;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.flexVtwo.RequestData;
import onevz.soe.cart.model.flexVtwo.SessionResponse;
import onevz.soe.cart.model.retrieveCart.CXPLineInfo;
import onevz.soe.cart.model.retrieveCart.CXPRetrieveCartDataVO;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.AddDeviceUIRequest;
import onevz.soe.customerprofile.model.gql.assisted.BillAccount;
import onevz.soe.customerprofile.response.CustomerProfileResponse;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

public class FlexV2Util {


    private static final Logger logger = LoggerFactory.getLogger(FlexV2Util.class);

    public static String getCartCreatorFromCart(SessionResponse sessionResponse){
        if(sessionResponse.getRetrieveCart() != null && sessionResponse.getRetrieveCart().getCart() != null
                && sessionResponse.getRetrieveCart().getCart().getCartHeader() != null
                && StringUtilities.isNotEmptyOrNull(sessionResponse.getRetrieveCart().getCart().getCartHeader().getCartCreator()))
            return sessionResponse.getRetrieveCart().getCart().getCartHeader().getCartCreator();
        return "";
    }
    public static int getMultiLineSeqNumberFromCart(SessionResponse sessionResponse, String mtn){
        if(sessionResponse.getRetrieveCart() != null && sessionResponse.getRetrieveCart().getCart() != null
                && sessionResponse.getRetrieveCart().getCart().getLineDetails() != null
                && Optional.ofNullable(sessionResponse.getRetrieveCart().getCart().getLineDetails().getLineInfo()).isPresent()) {
            List<CXPLineInfo> lineInfo = Arrays.asList( sessionResponse.getRetrieveCart().getCart().getLineDetails().getLineInfo());
            return lineInfo.stream().filter(line -> null != line.getMobileNumber()
                            && null != line.getMultiLineSeqNumber() && mtn.equalsIgnoreCase(line.getMobileNumber()))
                    .map(CXPLineInfo::getMultiLineSeqNumber)
                    .filter(Objects::nonNull).findAny().orElse(0);
        }
        return 0;
    }
    public static boolean isNewline(AddDeviceUIRequest request){
        List<String> aalIntendList = Arrays.asList("AAL", "BYOD", "NSE", "NSEBYOD");
        return (request.getCartInfo() != null && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                && aalIntendList.contains(request.getCartInfo().getIntendType()));
    /* return ((request.getCartInfo() != null && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()))
             && (request.getCartInfo().getIntendType().equalsIgnoreCase("AAL")
             || request.getCartInfo().getIntendType().equalsIgnoreCase("BYOD")));*/
    }

    public static boolean isCartHasRequestMtn(SessionResponse sessionResponse, RequestData data, List<Lines> lines){

        if (CollectionUtilities.isNotEmptyOrNull(lines)) {
            lines.forEach(line -> {
                if (StringUtilities.isNotEmptyOrNull(line.getMtn()) && sessionResponse.getRetrieveCart() != null && isCartHasLine(sessionResponse.getRetrieveCart())) {
                    checkMtnInCart(sessionResponse.getRetrieveCart(), line.getMtn(), data);
                }
            });
        }
        logger.info("Method -isCartHasRequestMtn : value :{}", data.isCartHasRequestMtn());
        return data.isCartHasRequestMtn();
    }
    public static boolean isAccountHasRequestMtn(SessionResponse sessionResponse, RequestData requestData,List<Lines> lines){

        if (CollectionUtilities.isNotEmptyOrNull(lines)) {
            lines.forEach(line -> {

                if(StringUtilities.isNotEmptyOrNull(line.getMtn()) && sessionResponse.getCustomerProfile() != null
                        && isAccountHasBillAcc(sessionResponse.getCustomerProfile())){
                    sessionResponse.getCustomerProfile().getData().getCustomer().getBillAccounts().forEach(cxpMtnList -> {
                        if (cxpMtnList != null && cxpMtnList.getMtns() != null) {
                            requestData.setAccountHasRequestMtn(checkMtnInAccount(cxpMtnList,line.getMtn()));
                        }
                    });
                }
            });
        }
        logger.info("Method -isAccountHasRequestMtn : value :{}", requestData.isAccountHasRequestMtn());
        return requestData.isAccountHasRequestMtn();
    }
    public static boolean isAccountHasBillAcc(CustomerProfileResponse customerProfile){

        return (customerProfile.getData() != null
                && customerProfile.getData().getCustomer() != null
                && customerProfile.getData().getCustomer().getBillAccounts() != null
                && !customerProfile.getData().getCustomer().getBillAccounts().isEmpty());
    }
    public static boolean checkMtnInAccount(BillAccount cxpMtnList, String requestMtn){
        logger.info("checkMtnInAccount : profile : {}", cxpMtnList);
        return cxpMtnList.getMtns().stream().filter(Objects::nonNull).anyMatch(i -> i.getMtn()!=null && i.getMtn().equalsIgnoreCase(requestMtn) && i.getMtnStatus() != null && i.getMtnStatus().getIsDisconnected() != null && !i.getMtnStatus().getIsDisconnected());

    }
    public static boolean checkMtnInCart(CXPRetrieveCartDataVO cart, String reqLineMtn, RequestData data) {
        List<CXPLineInfo> lineInfo = new ArrayList<>();
        if(isCartHasLine(cart)) {
            lineInfo = Arrays.asList(cart.getCart().getLineDetails().getLineInfo());
        }

        lineInfo.stream().filter(lineObj ->
                null != lineObj && StringUtilities.isNotEmptyOrNull(lineObj.getMobileNumber()) && reqLineMtn.equalsIgnoreCase(lineObj.getMobileNumber())
        ).forEach(lineIntent -> {
            if (lineIntent != null && StringUtilities.isNotEmptyOrNull(lineIntent.getLineActivityType())) {
                data.setCartHasRequestMtn(true);
                data.setCartMatchLineActivityType(lineIntent.getLineActivityType());
            }
        });
        logger.info("Method -checkMtnInCart : isCartHasRequestMtn :{}", data.isCartHasRequestMtn());
        return data.isCartHasRequestMtn();
    }
    public static Map <String, Integer> intendTypePreferenceMap ;
    static {
        intendTypePreferenceMap = new HashMap<>();
        intendTypePreferenceMap.put(CartConstants.AAL,1);
        intendTypePreferenceMap.put(CartConstants.AAL_5G,2);
        intendTypePreferenceMap.put(CartConstants.AAL_LTE,3);
        intendTypePreferenceMap.put(CartConstants.BYOD,4);
        intendTypePreferenceMap.put(CartConstants.EUP,5);
        intendTypePreferenceMap.put(CartConstants.EUP_BYOD_LINE_ACTIVITY,6);
        intendTypePreferenceMap.put(CartConstants.CPC,7);
        intendTypePreferenceMap.put(CartConstants.NSE,8);
        intendTypePreferenceMap.put(CartConstants.NSE_BYOD,9);

    }

    public static Map <String, Integer> intendTypePreferenceMapCart ;
    static {
        intendTypePreferenceMapCart = new HashMap<>();
        intendTypePreferenceMapCart.put(CartConstants.NSE,1);
        intendTypePreferenceMapCart.put(CartConstants.AAL,2);
        intendTypePreferenceMapCart.put(CartConstants.EUP,3);
        intendTypePreferenceMapCart.put(CartConstants.BYOD,4);
        intendTypePreferenceMapCart.put(CartConstants.NSE_BYOD,5);
        intendTypePreferenceMapCart.put(CartConstants.EUP_BYOD_LINE_ACTIVITY,6);
        intendTypePreferenceMapCart.put(CartConstants.AAL_5G,7);
        intendTypePreferenceMapCart.put(CartConstants.NSE_5G,8);
        intendTypePreferenceMapCart.put(CartConstants.ACC,9);
        intendTypePreferenceMapCart.put(CartConstants.FEA,10);
        intendTypePreferenceMapCart.put(CartConstants.CPC,11);
    }
    public static boolean isCartHasLine(CXPRetrieveCartDataVO cart) {

        return (cart.getCart() != null
                && cart.getCart().getLineDetails() != null
                && cart.getCart().getLineDetails().getLineInfo() != null
                && cart.getCart().getLineDetails().getLineInfo().length > 0);
    }

    public static boolean isBYODFlow(List<Lines> lines) {

        if (CollectionUtilities.isNotEmptyOrNull(lines)) {
            return lines.stream().filter(Objects::nonNull).anyMatch(line ->
   /*                 ((line.getDevice() != null &&
                            line.getDevice().getIsCustomerProvidedEquipment())
                            || (line.getSim() != null && line.getSim().getIsCustomerProvidedSIM())));*/
                    line.isByod());
        }
        return false;
    }

    public static Boolean is5GDevice(List<Lines> lines){
        if (CollectionUtilities.isNotEmptyOrNull(lines)) {
            return lines.stream().filter(Objects::nonNull).anyMatch(line ->
                    CartConstants.FIVEG_INTERNET.equalsIgnoreCase(line.getDeviceTypeSelected()));
        }
        return false;
    }

    public static Boolean is5GDeviceAssignMtn(CXPLineInfo[] lines){
        if (CollectionUtilities.isNotEmptyOrNull(Arrays.asList(lines))) {
            return Arrays.stream(lines).filter(Objects::nonNull).anyMatch(line ->
                    CartConstants.FIVEG_INTERNET.equalsIgnoreCase(line.getDeviceTypeSelected()));
        }
        return false;
    }

    public static void updateSessionResponseData(CartRedisData cartSession , SessionResponse sessionResponse){
        if(cartSession.getCartId() != null)
            sessionResponse.setCartId(cartSession.getCartId());
        if(cartSession.getAccountNumber() != null)
            sessionResponse.setAccountNumber(cartSession.getAccountNumber());
        if(cartSession.getCustomerType() != null)
            sessionResponse.setCustomerType(cartSession.getCustomerType());
        if(cartSession.getRetrieveCart() != null)
            sessionResponse.setRetrieveCart(cartSession.getRetrieveCart());
        if(cartSession.getCustomerProfile() != null)
            sessionResponse.setCustomerProfile(cartSession.getCustomerProfile());
        if(StringUtilities.isNotEmptyOrNull(cartSession.getIsHomeSales()))
            sessionResponse.setIsHomeSales(cartSession.getIsHomeSales());
        if(cartSession.getHomeSalesAddress() != null){
            sessionResponse.setHomeSalesAddress(cartSession.getHomeSalesAddress());
        }
        if(cartSession.getAgentRole() != null){
            sessionResponse.setAgentRole(cartSession.getAgentRole());
        }
        if (StringUtilities.isNotEmptyOrNull(cartSession.getFlow())){
            sessionResponse.setFlow(cartSession.getFlow());}

    }
}
