package onevz.soe.cart.helper;

import onevz.soe.cart.constants.RedisConstants;
import onevz.soe.cart.constants.TradeinConstants;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.model.bulkcartupdate.*;
import onevz.soe.cart.model.bulkcartupdate.gql.request.LineDetail;
import onevz.soe.cart.model.bulkcartupdate.gql.response.RetrieveTradeinGQLResponse;
import onevz.soe.cart.model.common.CartServiceServiceHeader;
import onevz.soe.cart.bpm.service.CartServiceBPMServices;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.common.Vzdl;
import onevz.soe.cart.model.tradeIn.appraiseDevice.DeviceOutInfo;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.util.BulkQuoteUpdatePegaRequestUtil;
import onevz.soe.cart.util.CartPegaRequestUtil;
import onevz.soe.cart.util.CartUtil;
import onevz.soe.exception.SOEError;
import onevz.soe.exception.SOEErrorHolder;
import onevz.soe.exception.SOEException;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.tradein.session.model.TradeinSessionData;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple3;

import java.util.*;

@Service
public class BulkUpdateAIQuoteHelper {

    @Autowired
    CartServiceBPMServices cartServiceBPMServices;

    @Autowired
    SOELoginSessionBean sessionBean;

    @Autowired
    TradeInHelper tradeInHelper;

    @Autowired
    private CartServiceCXPServices cxpService;

    @Autowired
    RedisHelper redisHelper;

    @Autowired
    BulkUpdateAIQuoteHelper1 bulkUpdateHelper;

    @Autowired
    CartAddDeviceHelper deviceHelper;

    @Autowired
    FeatureFlagHelper featureFlagHelper;

    private static final Logger logger = LoggerFactory.getLogger(BulkUpdateAIQuoteHelper.class);

    public Mono<BulkQuoteUIResponse> processBulkQuoteUpdate(BulkQuoteUIRequest request, String sessionId) throws Exception {
        if (request == null || request.getCartInfo() == null || request.getCartInfo().getCartId() == null) {
            return Mono.error(new SOEException("Request or CartInfo or CartId cannot be null"));
        }
        String tradeDeviceId = getTradeDeviceIdFromReq(request);
        String cartId = request.getCartInfo().getCartId();
        Mono<CartRedisData> rr = redisHelper.getDataFromRedis();

        logger.info("Fetching session data");
        return sessionBean.getSessionData(RedisConstants.SESSION_GET_ADDR)
                .onErrorReturn(new HashMap<>())
                .defaultIfEmpty(new HashMap<>())
                .flatMap(sessionDataMap -> {
                    logger.info("Fetching session data, {}", sessionDataMap);
                    Mono<TradeinSessionData> tradeSessionData;
                    if (StringUtilities.isNotEmptyOrNull(tradeDeviceId)) {
                        tradeSessionData = getTradeinSessionData(cartId, tradeDeviceId);
                    } else {
                        tradeSessionData = Mono.just(new TradeinSessionData());
                    }
                    return tradeSessionData
                            .onErrorReturn(new TradeinSessionData())
                            .defaultIfEmpty(new TradeinSessionData())
                            .flatMap(tradeSessionDataObj -> {
                                logger.info("Fetching tradeSessionData{}", tradeSessionDataObj);
                                Map<String, String> sessionAddrData = new HashMap<>();
                                if (StringUtilities.isNotEmptyOrNull(tradeDeviceId) && MapUtils.isEmpty(tradeSessionDataObj.getTradeinData())) {
                                    return Mono.error(setErroIdAndErrorMessage(TradeinConstants.ERR_GENERIC_MSG, TradeinConstants.ERR_GENERIC_ID));
                                }
                                if (!sessionDataMap.isEmpty()) {
                                    sessionAddrData.put(CartConstants.QUOTE_E911_ADDR, sessionDataMap.get(CartConstants.QUOTE_E911_ADDR).toString());
                                }
                                logger.info("validations inside flatmap successful");
                                BulkQuoteUIResponse response = new BulkQuoteUIResponse();
                                CreateBulkQuotePegaRequest pegaRequest = new CreateBulkQuotePegaRequest();
                                CartServiceServiceHeader serviceHeader = CartPegaRequestUtil.addServiceHeader(new CartServiceServiceHeader());
                                serviceHeader.setClientId(request.getChannelId());
                                serviceHeader.setSessionId(sessionId);
                                pegaRequest.setServiceHeader(serviceHeader);

                                if (tradeSessionDataObj != null && isTradeInFlow(request)) {
                                    updateTradeInRequest(request, tradeSessionDataObj);
                                }
                                BulkQuoteUpdatePegaRequestUtil.formatBulkPegaRequest(pegaRequest, request, sessionAddrData);
                                logger.info("Formatted Pega Request is {}", pegaRequest);

                                try {
                                    return cartServiceBPMServices.createBulkQuote(pegaRequest)
                                            .flatMap(pegaResponse -> {
                                                logger.info("Response received from pega is {}", pegaResponse);
                                                if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
                                                    response.setErrors(CartUtil.formatErrorResponse(pegaResponse.getErrors()));
                                                } else if (pegaResponse.getTradeinCartErrorData() != null && !pegaResponse.getTradeinCartErrorData().isEmpty()) {
                                                    response.setErrors(CartUtil.formatCartErrorResponse(pegaResponse.getTradeinCartErrorData()));
                                                }
                                                if (pegaResponse.getServiceHeader() != null) {
                                                    response.setServiceHeader(pegaResponse.getServiceHeader());
                                                }
                                                if (pegaResponse.getServiceBody() != null) {
                                                    response.setServiceBody(pegaResponse.getServiceBody());
                                                    Map<String, String> sessionData1 = new HashMap<>();
                                                    sessionData1.put("aiQuoteFlow", "true");

                                                    Mono<Boolean> updateTradeinMono = isTradeInFlow(request)
                                                            ? tradeInHelper.updateTradeinSessionData(cartId, new TradeinSessionData())
                                                            : Mono.just(Boolean.TRUE);
                                                    Mono<Boolean> bulkUpdateFeatureFlag = featureFlagHelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag();
                                                    return Mono.zip(updateTradeinMono, rr, bulkUpdateFeatureFlag)
                                                            .flatMap(data -> sessionBean.setSessionData(sessionData1)
                                                                    .flatMap(sessionResp -> {
                                                                        try {
                                                                            Vzdl vzdl = bulkUpdateHelper.getVzdlDataForBulkUpdate(request, response, data.getT2());
                                                                            logger.info("bulkUpdateAIQuoteTaggingFFlag value is {}", data.getT3());
                                                                            if(data.getT3()){
                                                                                return setFlow(request, data, response, vzdl);
                                                                            }
                                                                            if (vzdl != null) {
                                                                                logger.info(CartConstants.VZDL_OBJ, vzdl);
                                                                                deviceHelper.updateDLDataForAssisted(vzdl);
                                                                            }
                                                                        } catch (Exception e) {
                                                                            logger.error(CartConstants.ERROR_TAGGING, e);
                                                                        }
                                                                        logger.info("Successfully updated values in session:{}", sessionResp);
                                                                        return Mono.just(response);
                                                                    })
                                                                    .onErrorResume(errResp -> {
                                                                        logger.info("Error Updating values in session", errResp);
                                                                        return Mono.just(response);
                                                                    })
                                                            );
                                                }
                                                return Mono.just(response);
                                            });
                                } catch (SOEHTTPException e) {
                                    logger.error("error while calling pega", e);
                                }
                                return Mono.just(response);
                            });
                });
    }

    private Mono<BulkQuoteUIResponse> setFlow(BulkQuoteUIRequest request, Tuple3<Boolean, CartRedisData, Boolean> data, BulkQuoteUIResponse response, Vzdl vzdl) {
        logger.info("setFlow method invoked");
        String existingFlowName = data.getT2().getFlowName();
        String flowName = bulkUpdateHelper.getFlowName(request, response);
        String finalFlowName = getFinalFlowName(flowName, existingFlowName);
        logger.info("Updating flow name to {}", finalFlowName);
        return redisHelper.addFlowNameToRedis(finalFlowName)
                .flatMap((updated) -> {
                    logger.info("Successfully updated flow name in session");
                    if (vzdl != null && vzdl.getPage() != null) {
                        vzdl.getPage().setFlow(finalFlowName);
                    }
                    if (vzdl != null) {
                        logger.info(CartConstants.VZDL_OBJ, vzdl);
                        deviceHelper.updateDLDataForAssisted(vzdl);
                    }
                    return Mono.just(response);
                })
                .doOnError((error) -> logger.info("Error while trying to update flowName to redis"));
    }

    private static String getFinalFlowName(String flowName, String existingFlowName) {
        String finalFlowName;
        if(StringUtilities.isEmptyOrNull(flowName)){
            finalFlowName = StringUtilities.isNotEmptyOrNull(existingFlowName) ? existingFlowName : "";
        }else if(StringUtilities.isEmptyOrNull(existingFlowName)){
            finalFlowName = flowName;
        }else {
            finalFlowName = existingFlowName.concat("|"+ flowName);
        }
        return finalFlowName;
    }

    private Mono<TradeinSessionData> getTradeinSessionData(String cartId, String deviceId) {
        logger.info("Fetching tradeinSessionData: {}", cartId);
        return tradeInHelper.readTradeinSessionData(cartId)
                .flatMap(res -> res.getTradeinData() == null || res.getTradeinData().isEmpty()
                        ? getTradeinDataFromCart(cartId, deviceId)
                        : Mono.just(res));
    }

    private Mono<TradeinSessionData> getTradeinDataFromCart(String cartId, String deviceId) {
        return cxpService.retrieveCartTradeinInfo(cartId)
                .flatMap(cartResponse -> {
                    TradeinSessionData sessionData = buildSessionDataFromCartResponse(cartResponse, deviceId);
                    if (sessionData.getTradeinData().isEmpty()) {
                        return Mono.error(setErroIdAndErrorMessage(TradeinConstants.ERR_GENERIC_MSG, TradeinConstants.ERR_GENERIC_ID));
                    }
                    return Mono.just(sessionData);
                });
    }

    private TradeinSessionData buildSessionDataFromCartResponse(RetrieveTradeinGQLResponse res, String deviceId) {
        logger.info("SessionDataFromCartResponse for tradein is {}", res);
        TradeinSessionData sessionData = new TradeinSessionData();
        sessionData.setTradeinData(new HashMap<>());

        Optional.ofNullable(res.getData().getCart().getLineDetails())
                .map(LineDetail::getTradeInDetail)
                .ifPresent(tradeInDetail -> {
                    tradeInDetail.getTradeInItems().forEach(tradeDevice -> {
                        DeviceOutInfo deviceOutInfo = new DeviceOutInfo();
                        BeanUtils.copyProperties(tradeDevice, deviceOutInfo);
                        deviceOutInfo.setCurrentTradedDevice(StringUtils.isNotBlank(deviceId) && deviceId.equalsIgnoreCase(deviceOutInfo.getDeviceId()));
                        sessionData.getTradeinData().put(tradeDevice.getDeviceId(), deviceOutInfo);
                    });
                    Optional.ofNullable(tradeInDetail.getTradeInShippingType())
                            .filter(StringUtils::isNotEmpty)
                            .ifPresent(sessionData::setTradeInShippingType);
                    Optional.ofNullable(tradeInDetail.getAddress())
                            .ifPresent(sessionData::setAddress);
                });

        Optional.ofNullable(res.getData().getCart().getOrderDetails())
                .ifPresent(orderDetails -> {
                    Optional.ofNullable(orderDetails.getBillingSystem())
                            .filter(StringUtilities::isNotEmptyOrNull)
                            .ifPresent(sessionData::setBillingSystem);
                    Optional.ofNullable(orderDetails.getLocationCode())
                            .filter(StringUtilities::isNotEmptyOrNull)
                            .ifPresent(sessionData::setLocationCode);
                });

        Optional.ofNullable(res.getData().getCart().getLineDetails())
                .filter(this::isStoreInfoPresent)
                .map(lineDetail -> lineDetail.getLineInfo().get(0).getItemsInfo().get(0).getShipping().getStoreinfo())
                .ifPresent(sessionData::setIspuStoreInfo);

        return sessionData;
    }
    private String getTradeDeviceIdFromReq(BulkQuoteUIRequest request) {
        return request.getData().getLines().stream()
                .filter(line -> line.getTradeInItems() != null && !line.getTradeInItems().isEmpty())
                .findFirst()
                .map(line -> line.getTradeInItems().get(0).getDeviceId())
                .orElse(null);
    }
    public boolean isStoreInfoPresent(LineDetail lineDetail) {
        return lineDetail != null
                && lineDetail.getLineInfo() != null && !lineDetail.getLineInfo().isEmpty()
                && lineDetail.getLineInfo().get(0).getItemsInfo() != null && !lineDetail.getLineInfo().get(0).getItemsInfo().isEmpty()
                && lineDetail.getLineInfo().get(0).getItemsInfo().get(0).getShipping() != null;
    }
    public SOEHTTPException setErroIdAndErrorMessage(String errMessage, String errId) {
        SOEError error = SOEError.builder()
                .message(errMessage)
                .name(TradeinConstants.VALIDATION_ERROR)
                .id(errId)
                .namespace(TradeinConstants.TRADEIN_SOE_SERVICE)
                .build();
        return new SOEHTTPException(200, SOEErrorHolder.builder().errors(Collections.singletonList(error)).build());
    }
    public DeviceOutInfo getTradeinNodeFromUIReq(BulkQuoteUIRequest uiRequest) {
        return Optional.ofNullable(uiRequest.getData().getLines())
                .flatMap(lines -> lines.stream()
                        .filter(line -> line.getTradeInItems()!= null && !line.getTradeInItems().isEmpty())
                        .findFirst()
                        .map(line -> line.getTradeInItems().get(0))
                )
                .orElse(null);

    }
    public boolean isTradeInFlow(BulkQuoteUIRequest request) {
        return request.getData().getLines().stream()
                .anyMatch(line -> line.getTradeInItems() != null && !line.getTradeInItems().isEmpty());
    }

    public static void updateTradeInRequest(BulkQuoteUIRequest request, TradeinSessionData tradeinSessionData) {
        if (!request.getData().getLines().isEmpty()) {
            request.getData().getLines().stream()
                    .filter(line -> line.getTradeInItems() != null && !line.getTradeInItems().isEmpty())
                    .flatMap(line -> line.getTradeInItems().stream())
                    .forEach(tradeInNodeUI -> {
                        if (tradeInNodeUI.getDeviceId() != null) {
                            DeviceOutInfo deviceOutSession = tradeinSessionData.getTradeinData().get(tradeInNodeUI.getDeviceId());
                            if (deviceOutSession != null) {
                                tradeInNodeUI.setTriageInfo(deviceOutSession.getTriageInfo());
                                tradeInNodeUI.setRecycleDeviceOffer(deviceOutSession.getRecycleDeviceOffer());
                                if (deviceOutSession.getSubmissionId() != null) {
                                    tradeInNodeUI.setSubmissionId(deviceOutSession.getSubmissionId());
                                }
                            }
                        }
                    });
            // Add remaining items from tradeinSessionData to request
            tradeinSessionData.getTradeinData().forEach((deviceId, deviceOutInfo) -> {
                boolean exists = request.getData().getLines().stream()
                        .flatMap(line -> line.getTradeInItems().stream())
                        .anyMatch(tradeInNodeUI -> tradeInNodeUI.getDeviceId() != null && tradeInNodeUI.getDeviceId().equals(deviceId));
                if (!exists) {
                    // Add the missing deviceOutInfo to the request
                    if (!request.getData().getLines().isEmpty()) {
                        request.getData().getLines().get(0).getTradeInItems().add(deviceOutInfo);
                    }
                }
            });
        }
    }
}
