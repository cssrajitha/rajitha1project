package onevz.soe.cart.constants;


import java.util.Arrays;
import java.util.List;

public enum StreetType {
	
	ALLEY("ALY","AL"),
	ANNEX("ANX",null),
	ARCADE("ARC",null),
	AVENUE("AVE","AV"),
	BAYOU("BYU",null),
	BEACH("BCH",null),
	BEND("BND",null),
	BLUFF("BLF",null),
	BOTTOM("BTM",null),
	BOULEVARD("BLVD","BL"),
	BRANCH("BR",null),
	BRIDGE("BRG",null),
	BROOK("BRK",null),
	BURG("BG",null),
	BYPASS("BYP",null),
	CAMP("CP",null),
	CANYON("CYN",null),
	CAPE("CPE",null),
	CAUSEWAY("CSWY",null),
	CENTER("CTR","CN"),
	CIRCLE("CIR","CI"),
	CLIFF("CLF",null),
	CLUB("CLB",null),
	COMMON("CMN",null),
	CORNER("COR",null),
	COURSE("CRSE",null),
	COURT("CT","CT"),
	COVE("CV","CV"),
	CREEK("CRK","CRK"),
	CRESCENT("CRES","CR"),
	CREST("CRST",null),
	CROSSING("XING","XI"),
	CROSSROAD("XRD",null),
	CURVE("CURV",null),
	DALE("DL","DA"),
	DAM("DM",null),
	DIVIDE("DV",null),
	DRIVE("DR","DR"),
	ESTATE("EST",null),
	EXPRESSWAY("EXPY","EX"),
	EXTENSION("EXT",null),
	FALL("FALL",null),
	FERRY("FRY",null),
	FIELD("FLD",null),
	FLAT("FLT",null),
	FORD("FRD",null),
	FOREST("FRST",null),
	FORGE("FRG",null),
	FORK("FRK",null),
	FORT("FT",null),
	FREEWAY("FWY","FY"),
	GARDEN("GDN","GA"),
	GATEWAY("GTWY",null),
	GLEN("GLN",null),
	GREEN("GRN",null),
	GROVE("GRV","GR"),
	HARBOR("HBR",null),
	HAVEN("HVN",null),
	HEIGHTS("HTS","HT"),
	HIGHWAY("HWY","HY"),
	HILL("HL","HL"),
	HOLLOW("HOLW",null),
	INLET("INLT",null),
	ISLAND("IS",null),
	ISLE("ISLE",null),
	JUNCTION("JCT",null),
	KEY("KY",null),
	KNOLL("KNL","KN"),
	LAKE("LK",null),
	LAND("LAND",null),
	LANDING("LNDG",null),
	LANE("LN","LN"),
	LIGHT("LGT",null),
	LOAF("LF",null),
	LOCK("LCK",null),
	LODGE("LDG",null),
	LOOP("LOOP","LP"),
	MALL("MALL","MA"),
	MANOR("MNR",null),
	MEADOW("MDW",null),
	MEWS("MEWS",null),
	MILL("ML",null),
	MISSION("MSN",null),
	MOTORWAY("MTWY",null),
	MOUNT("MT",null),
	MOUNTAIN("MTN",null),
	NECK("NCK",null),
	ORCHARD("ORCH",null),
	OVAL("OVAL","OV"),
	OVERPASS("OPAS",null),
	PARK("PARK","PK"),
	PARKWAY("PKWY","PY"),
	PASS("PASS","PS"),
	PASSAGE("PSGE",null),
	PATH("PATH","PA"),
	PIKE("PIKE","PI"),
	PINE("PNE",null),
	PLACE("PL","PL"),
	PLAIN("PLN",null),
	PLAZA("PLZ","PZ"),
	POINT("PT","PT"),
	PORT("PRT",null),
	PRAIRIE("PR",null),
	RADIAL("RADL",null),
	RAMP("RAMP",null),
	RANCH("RNCH",null),
	RAPID("RPD",null),
	REST("RST",null),
	RIDGE("RDG",null),
	RIVER("RIV",null),
	ROAD("RD","RD"),
	ROUTE("RTE","RT"),
	ROW("ROW","RO"),
	RUE("RUE",null),
	RUN("RUN","RN"),
	SHOAL("SHL",null),
	SHORE("SHR",null),
	SKYWAY("SKWY",null),
	SPRING("SPG",null),
	SPUR("SPUR",null),
	SQUARE("SQ","SQ"),
	STATION("STA",null),
	STRAVENUE("STRA",null),
	STREAM("STRM",null),
	STREET("ST","ST"),
	SUMMIT("SMT",null),
	TERRACE("TER","TE"),
	THROUGHWAY("TRWY","TY"),
	THRUWAY("TRWY","TY"),
	TRACE("TRCE",null),
	TRACK("TRAK",null),
	TRAFFICWAY("TRFY",null),
	TRAIL("TRL","TR"),
	TRAILER("TRLR",null),
	TUNNEL("TUNL",null),
	TURNPIKE("TPKE","TP"),
	UNDERPASS("UPAS",null),
	UNION("UN",null),
	VALLEY("VLY",null),
	VIADUCT("VIA","VI"),
	VIEW("VW",null),
	VILLAGE("VLG",null),
	VILLE("VL",null),
	VISTA("VIS",null),
	WALK("WALK","WK"),
	WALL("WALL",null),
	WAY("WAY","WY"),
	WELL("WL",null);
	
	private String shortName;
	private String twoCharName;
	
	private StreetType(String shortName,String twoCharName) {
		this.shortName = shortName;
		this.twoCharName = twoCharName;
	}
	
	 

	public String getShortNameFromTwoChar(String twoChar) {
		List<StreetType> allStreet = Arrays.asList(StreetType.values());
		for(StreetType str : allStreet){
			if(str.getTwoCharName()!=null && str.getTwoCharName().equals(twoChar)){
				return str.getShortName();
			}
		}
		return twoChar;
	}
	
	public String getShortName() {
		return shortName;
	}

	

	public String getTwoCharName() {
		return twoCharName;
	}

	
	
	
	
}

