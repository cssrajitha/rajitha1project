package onevz.soe.cart.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.cxp.feature.Flag;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.addAccessory.AccessoryAction;
import onevz.soe.cart.model.addAccessory.AddAccContext;
import onevz.soe.cart.model.addAccessory.AddAccServiceBody;
import onevz.soe.cart.model.addAccessory.AddAccServiceRequest;
import onevz.soe.cart.model.addFeature.AddFeaturesContext;
import onevz.soe.cart.model.addFeature.AddFeaturesServiceBody;
import onevz.soe.cart.model.addFeature.AddFeaturesServiceRequest;
import onevz.soe.cart.model.addServiceAddress.ServiceAddressContext;
import onevz.soe.cart.model.addServiceAddress.ServiceAddressServiceBody;
import onevz.soe.cart.model.addServiceAddress.ServiceAddressServiceRequest;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.createLine.CreateLineContext;
import onevz.soe.cart.model.createLine.CreateLineServiceBody;
import onevz.soe.cart.model.createLine.CreateLineServiceRequest;
import onevz.soe.cart.model.numberShare.NumberShareContext;
import onevz.soe.cart.model.numberShare.NumberShareServiceBody;
import onevz.soe.cart.model.numberShare.NumberShareServiceRequest;
import onevz.soe.cart.model.updateBarcode.UpdateBarcodeBarcodeId;
import onevz.soe.cart.model.updateEffectiveDateOverride.EffectiveDateOverrideContext;
import onevz.soe.cart.model.updateEffectiveDateOverride.EffectiveDateOverrideServiceBody;
import onevz.soe.cart.model.updateEffectiveDateOverride.EffectiveDateOverrideServiceRequest;
import onevz.soe.cart.requests.*;
import onevz.soe.cart.ui.common.ByodLineDetails;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.spring.web.filter.RequestAccessContext;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.bpm.model.MtnInfo;
import onevz.soe.wsclient.bpm.model.request.ActiveMTNList;
import onevz.soe.wsclient.bpm.model.request.ActiveMtn;
import onevz.soe.wsclient.bpm.model.request.Add;
import onevz.soe.wsclient.bpm.model.request.Features;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import java.util.*;

import static onevz.soe.cart.constants.CartConstants.FEATURE_SELECTION;

public class CartPegaRequestUtil3 {

    private static final Logger logger = LoggerFactory.getLogger(CartPegaRequestUtil3.class);

    @Value("${enableCradleForProspect:true}")
    private static boolean enableCradleForProspect;

    @Value("${enableCradleForExistingCustomer:true}")
    private static boolean enableCradleForExistingCustomer;

    public static final String OMNI_RETAIL = "OMNI-RETAIL";

    /**
     * @param pegaRequest
     * @param request
     * @return AddFeaturesPEGARequest
     */

    public static AddFeaturesPEGARequest formatAddFeaturesRequest(AddFeaturesPEGARequest pegaRequest,
                                                                  AddFeaturesUIRequest request, Flag preToPostActivationFeeFFlag) {
        String preToPostMigrationCookie = RequestAccessContext.obtainCookie(Arrays.asList(CartConstants.PREPAID_TO_POSTPAID_MIGRATION));
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        serviceHeader = CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(request.getChannelId());
        pegaRequest.setServiceHeader(serviceHeader);

        AddFeaturesServiceBody serviceBody = new AddFeaturesServiceBody();
        AddFeaturesServiceRequest serviceRequest = new AddFeaturesServiceRequest();
        AddFeaturesContext context = new AddFeaturesContext();
        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        List<Line> lines = new ArrayList<>();
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getClientAppName())
                && CartConstants.CHANNEL_ID_NUMBERLINK.equalsIgnoreCase(request.getCartInfo().getClientAppName())) {
            serviceHeader.setServiceName(CartConstants.SERVICE_NAME_NUMBERLINK);
        }
        if(request !=null && request.getCartInfo() != null && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLineActivityType())
                && request.getCartInfo().getLineActivityType().equalsIgnoreCase("TSE")) {
            serviceHeader.setServiceName(CartConstants.TYS_UPDATE);
        }
        if(isSkipGC(request)) {
            contextInfo = CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.MAY_BE_LATER, request.getCartInfo().getClientAppName());
        } else {
            if(request !=null && request.getCartInfo() != null && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLineActivityType())
                    && request.getCartInfo().getLineActivityType().equalsIgnoreCase("TSE")) {
                contextInfo = CartPegaRequestUtil2.addContextInfoFeatureTYS(contextInfo, CartConstants.ADD_FEATURES, request.getCartInfo().getClientAppName());
            } else if(request!= null && request.getCartInfo() != null && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getFlowType()) &&
                    request.getCartInfo().getFlowType().equalsIgnoreCase("WHW_Redemption") && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessAction())
                    && request.getCartInfo().getProcessAction().equalsIgnoreCase(CartConstants.ADD_FEATURES_AND_ACCESSORY)){
                contextInfo = CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.ADD_FEATURES_AND_ACCESSORY, request.getCartInfo().getClientAppName());
            } else {
                contextInfo = CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.ADD_FEATURES, request.getCartInfo().getClientAppName());
            }
        }



        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getAccountNumber()))
            customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCartCreator()))
            customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessingMTN()))
            customerInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());
        if (request.getCartInfo().getEditDeviceConfiguratorClick() != null)
            customerInfo.setEditDeviceConfiguratorClick(request.getCartInfo().getEditDeviceConfiguratorClick());
        if (request.getCartInfo().getIsSmartLocator() != null)
            customerInfo.setIsSmartLocator(request.getCartInfo().getIsSmartLocator());
        if (request.getCartInfo().getIsfiveGUpSellSelected() != null)
            customerInfo.setIsfiveGUpSellSelected(request.getCartInfo().getIsfiveGUpSellSelected());
        if (request.getCartInfo().getMtnFlow() != null)
            customerInfo.setMtnFlow(request.getCartInfo().getMtnFlow());
        if (request.getCartInfo().getAccountLevelProtection() != null)
            customerInfo.setAccountLevelProtection(request.getCartInfo().getAccountLevelProtection());
        if (CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())
                || CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())
                || CartConstants.NSE_5G.equalsIgnoreCase(request.getCartInfo().getIntendType())
                || CartConstants.NSE_LTE.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
            CartPegaRequestUtil7.newCustomerOverride(contextInfo, customerInfo, request.getCartInfo(), request.getChannelId());
        }
        if(isFeatureOrSPOUpdateOnly(request)){
            pegaRequest.getServiceHeader().setServiceName(CartConstants.CPC);
            contextInfo.setCallReason(CartConstants.CPC);
            contextInfo.setIncludeNBS("Y");
            contextInfo.setIntendType(request.getCartInfo().getIntendType());
            contextInfo.setItemType(CartConstants.FEATURE);
            contextInfo.setProcessStep(request.getCartInfo().getProcessStep());

            MtnInfo mtnInfo = new MtnInfo();
            ActiveMTNList activeMTNList = new ActiveMTNList();
            ActiveMtn activeMtn = new ActiveMtn();
            if(null!=request.getData() &&
                    null!=request.getData().getAccount() &&
                    null!=request.getData().getAccount().getFeatures() &&
                    null!=request.getData().getAccount().getFeatures().getAdd()
             && !request.getData().getAccount().getFeatures().getAdd().isEmpty())
            {
                Features features =new Features();
                List<Add> list=new ArrayList<>();
                request.getData().getAccount().getFeatures().getAdd().stream().filter(Objects::nonNull)
                        .forEach(feature -> {
                    Add featureList =new Add();
                    featureList.setId(feature.getId());
                    featureList.setActionIndicator(feature.getActionIndicator());
                    featureList.setType(feature.getType());
                    featureList.setQuantity(String.valueOf(feature.getQuantity()));
                    list.add(featureList);
                });
                features.setAdd(list);
                activeMtn.setMtn(request.getMtn());
                activeMtn.setFeatures(features);
                activeMTNList.setActiveMTN(Collections.singletonList(activeMtn));
                mtnInfo.setActiveMTNList(activeMTNList);
                customerInfo.setMtnInfo(mtnInfo);
            }
        }
        if (null != request.getCartInfo().getExpressCheckout()
                && null != request.getCartInfo().getEditDeviceConfiguratorClick()
                && request.getCartInfo().getExpressCheckout()
                && request.getCartInfo().getEditDeviceConfiguratorClick()) {
            if (CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())
                    || CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())){
                if(enableCradleForProspect) {
                    customerInfo.setCradleFlowJourney(CartConstants.ACCESSORIES_INTERSTIAL_PROSPECT);
                }
            }else{
                if(enableCradleForExistingCustomer){
                    customerInfo.setCradleFlowJourney(CartConstants.PROMO_HUB);
                }
            }
        } else if (null != request.getCartInfo().getPromoHubJourney() && request.getCartInfo().getPromoHubJourney()) {
            if (CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())
                    || CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())){
                if(enableCradleForProspect) {
                    customerInfo.setCradleFlowJourney(CartConstants.ACCESSORIES_INTERSTIAL_PROSPECT);
                }
            }else{
                if(enableCradleForExistingCustomer){
                    customerInfo.setCradleFlowJourney(CartConstants.PROMO_HUB);
                }
            }
        }else if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCradleFlowJourney())) {
            customerInfo.setCradleFlowJourney(request.getCartInfo().getCradleFlowJourney());
        }

        if(request.getCartInfo() != null && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLineActivityType())
                && request.getCartInfo().getLineActivityType().equalsIgnoreCase("TSE")) {
            customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
            customerInfo.setMtn(request.getMtn());
            customerInfo.setCustomerId(request.getCustomerId());
            customerInfo.setUserRole(request.getCartInfo().getUserRole());
        }

        context.setCustomerInfo(customerInfo);

        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(request.getCartInfo().getCartId());
        cartInfo.setCartCreator(request.getCartInfo().getCartCreator());
        cartInfo.setClientAppName(request.getCartInfo().getClientAppName());
        cartInfo.setAction(CartConstants.UPDATE);
        cartInfo.setItemType("FEATURE");
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()))
            cartInfo.setIntendType(request.getCartInfo().getIntendType());

        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getRelinquishAccountNumber()))
            cartInfo.setRelinquishAccountNumber(request.getCartInfo().getRelinquishAccountNumber());
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getTysLinesCount()))
            cartInfo.setTysLinesCount(request.getCartInfo().getTysLinesCount());

        if (null != request.getChannelId() && request.getChannelId().contains("VZW-CHATBOT")) {
            if (null != request.getCartInfo() && null != request.getCartInfo().getProcessAction()) {
                contextInfo.setProcessAction(request.getCartInfo().getProcessAction());
            }
        }

        if(request.getCartInfo() != null && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLineActivityType())
                && request.getCartInfo().getLineActivityType().equalsIgnoreCase("TSE")) {
            cartInfo.setItemType("TRANSFER-SERVICE");
            cartInfo.setIntendType("TSE");
        }
        addQuickShopPegaRequestFlag(request, cartInfo, contextInfo);
        Line[] lineArr;
        if (request.getData().getLines() != null) {
            for (LineFeature reqLine : request.getData().getLines()) {
                Line newLine = new Line();
                newLine.setMtn(reqLine.getMtn());
                if (reqLine.getFeatures() != null && request.getChannelId()!=null && request.getChannelId().matches(OMNI_RETAIL) && request.getCartInfo().getProcessingMTN() != null && request.getCartInfo().getProcessingMTN().equalsIgnoreCase(reqLine.getMtn())) {
                    newLine.setFeatures(new FeatureAction());
                    FeatureAction reqFeatureAction = reqLine.getFeatures();
                    if (reqFeatureAction.getAdd() != null && !reqFeatureAction.getAdd().isEmpty()) {
                         newLine.getFeatures().setAdd(reqFeatureAction.getAdd());
                    }
                    if (reqFeatureAction.getRemove() != null && !reqFeatureAction.getRemove().isEmpty()) {
                        newLine.getFeatures().setRemove(reqFeatureAction.getRemove());
                    }
                } else if (reqLine.getFeatures() != null) {
                    newLine.setFeatures(new FeatureAction());
                    FeatureAction reqFeatureAction = reqLine.getFeatures();
                    if (reqFeatureAction.getAdd() != null && !reqFeatureAction.getAdd().isEmpty()) {
                        newLine.getFeatures().setAdd(reqFeatureAction.getAdd());
                    }
                    if (reqFeatureAction.getRemove() != null && !reqFeatureAction.getRemove().isEmpty()) {
                        newLine.getFeatures().setRemove(reqFeatureAction.getRemove());
                    }
                }
                if (reqLine.getAccessories() != null) {
                    newLine.setAccessories(new AccessoryAction());
                    AccessoryAction reqAccessoryAction = reqLine.getAccessories();
                    if (reqAccessoryAction.getAdd() != null && reqAccessoryAction.getAdd().length > 0) {
                        newLine.getAccessories().setAdd(reqAccessoryAction.getAdd());
                    }

                }

                if (reqLine.getAccessories() != null) {
                    newLine.setAccessories(new AccessoryAction());
                    AccessoryAction reqAccessoryAction = reqLine.getAccessories();
                    if (reqAccessoryAction.getAdd() != null && reqAccessoryAction.getAdd().length > 0) {
                        newLine.getAccessories().setAdd(reqAccessoryAction.getAdd());
                    }
                    if (reqAccessoryAction.getRemove() != null && reqAccessoryAction.getRemove().length > 0) {
                        newLine.getAccessories().setRemove(reqAccessoryAction.getRemove());
                    }
                }


                if (reqLine.getMcsSubscription() != null) {
                    newLine.setMcsSubscription(reqLine.getMcsSubscription());
                }

                if (StringUtilities.isNotEmptyOrNull(preToPostMigrationCookie) && preToPostMigrationCookie.equalsIgnoreCase("true") && preToPostActivationFeeFFlag != null && preToPostActivationFeeFFlag.isEnabled()) {
                    Map<String, List<String>> attributeMap = preToPostActivationFeeFFlag.getAttributes();
                    List<String> offerCode = attributeMap.get("offerCode");
                    if(offerCode != null && offerCode.size() > 0) {
                        newLine.setOfferCode(offerCode.get(0));
                    }
                }
                
                //New line  CXTDT-387027 depletion type 
                
				if (Objects.nonNull(request.getCartInfo()) && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getDepletionType())) {
					newLine.setDepletionType(request.getCartInfo().getDepletionType());
				}else if(reqLine.getAccessories() != null && null!=reqLine.getFeatures() && "WHW_Redemption".equalsIgnoreCase(request.getCartInfo().getFlowType())){
                    newLine.setDepletionType("F");
                }

                if (Objects.nonNull(request.getCartInfo()) && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getDepletionLocation())) {
                    newLine.setDepletionLocationCode(request.getCartInfo().getDepletionLocation());
                }

                if (null != request.getCartInfo() && null != request.getCartInfo().getIspuFlow()) {
                    newLine.setIspuFlow(request.getCartInfo().getIspuFlow());
                }

                lines.add(newLine);
            }
            lineArr = new Line[lines.size()];
            lines.toArray(lineArr);

            cartInfo.setLines(lineArr);
        }

        cartInfo.setAccount(request.getData().getAccount());
        context.setCaseId(request.getCartInfo().getCaseId());
        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessStep())) {
            if ((CartConstants.FIVEGBOLT).equalsIgnoreCase(request.getCartInfo().getProcessStep())) {
                contextInfo.setProcessAction(CartConstants.ADD_FIVEGBOLT);
            }
            contextInfo.setProcessStep(request.getCartInfo().getProcessStep());
        } else {
            contextInfo.setProcessStep(CartConstants.FEATURES_PDP);
        }
        if ((CartConstants.AAL).equalsIgnoreCase(cartInfo.getIntendType()))
            contextInfo.setIntent(CartConstants.AAL);
        if ((CartConstants.BYOD).equalsIgnoreCase(cartInfo.getIntendType()))
            contextInfo.setIntent(CartConstants.BYOD);
        if ((CartConstants.NSE).equalsIgnoreCase(cartInfo.getIntendType())) {
            if(StringUtilities.isNotEmptyOrNull(request.getChannelId()) && CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId())))
                contextInfo.setIntent(CartConstants.INLINE_CPC);
            else
                contextInfo.setIntent(CartConstants.NSE);
        }
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getRpsIntent())) {
            contextInfo.setIntent(request.getCartInfo().getRpsIntent());
        }
        if(CartConstants.ACC.equalsIgnoreCase(cartInfo.getIntendType())){
            contextInfo.setIntent(CartConstants.STANDALONEACCESSORY);
        }
        if(request != null && request.getCartInfo()!=null && request.getCartInfo().getIntent() != null && CartConstants.FLOW_TYPE_WHW.equalsIgnoreCase(request.getCartInfo().getFlowType())){
            contextInfo.setIntent(request.getCartInfo().getIntent());
        }
        if(request.getCartInfo()!=null) {
            if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getClientAppName()) && CartConstants.CHANNEL_ID_NUMBERLINK.equalsIgnoreCase(request.getCartInfo().getClientAppName())) {
                if(request.getCartInfo().getIntent()!=null){
                    contextInfo.setIntent(request.getCartInfo().getIntent());
                }
                else{
                    contextInfo.setIntent("NLA");
                }
                contextInfo.setCallReason("Features");
            }

        }
        if(StringUtilities.isNotEmptyOrNull(cartInfo.getIntendType()) && (CartConstants.AAL_5G.contentEquals(cartInfo.getIntendType()) || CartConstants.NSE_5G.contentEquals(cartInfo.getIntendType())
                || CartConstants.AAL_LTE.contentEquals(cartInfo.getIntendType()) || CartConstants.NSE_LTE.contentEquals(cartInfo.getIntendType()))
                && null != request.getData()
                && null != request.getData().getAccount()
                && null != request.getData().getAccount().getMcsSubscription()
                && (null != request.getData().getAccount().getMcsSubscription().getAdd() || null != request.getData().getAccount().getMcsSubscription().getRemove())
                && CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId())))
            contextInfo.setIntent(cartInfo.getIntendType());

        //MVP2
        if(request.getCartInfo()!=null && request.getCartInfo().getCaseId()!=null && request.getCartInfo().getCaseId().startsWith("SOF")){

            logger.info("SalesOrderFlex Prepay add features Request before PEGA call setting Call Reason");
            contextInfo.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_FLEX);
            //BVQ - 2616
            if(!StringUtilities.isEmptyOrNull(request.getCartInfo().getCaseId())
                    && request.getCartInfo().getCaseId().startsWith("SOF"))
            {
                if(request.getCartInfo().getOneClick()!=null && request.getCartInfo().getOneClick()) {
                    logger.info("CartInfo Line Prepay add Feature OneClick set to true with Case ID:{}", request.getCartInfo().getCaseId());
                    cartInfo.setOneClick(request.getCartInfo().getOneClick());
                }
                // existingCustomer customerType and OriginalCreditApprovalNumber
                if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                        && CartConstants.AAL.equalsIgnoreCase(request.getCartInfo().getIntendType())
                        || CartConstants.BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())){
                    customerInfo.setCustomerType(CartConstants.PREPAYEXISTINGCUST);
                    customerInfo.setOriginalCreditApprovalNumber(request.getCartInfo().getCreditAppNum());
                }
            }
        }

        if(request !=null && request.getCartInfo() != null && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getLineActivityType())
                && request.getCartInfo().getLineActivityType().equalsIgnoreCase("TSE")) {
            contextInfo.setProcessStep(CartConstants.FEATURES_SELECTION_PAGE);
            contextInfo.setIntent(CartConstants.TYS_ASSUMER);
            context.setCartData(cartInfo);
        }else {
            context.setCartInfo(cartInfo);
        }

        context.setContextInfo(contextInfo);

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);

        return pegaRequest;
    }

    private static boolean isSkipGC(AddFeaturesUIRequest request) {
        return (CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType()) || CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType()))
                && null != request.getSkipGC() && request.getSkipGC();
    }

    /**
     * @param pegaRequest
     * @param request
     * @return AddAccessoryPEGARequest
     */

    public static AddAccessoryPEGARequest formatAddAccessoriesRequest(AddAccessoryPEGARequest pegaRequest,
                                                                      AddAccessoriesUIRequest request, String throttleName, boolean enableCradleFlowJourney) {

        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        serviceHeader = CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(request.getChannelId());
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                && ((CartConstants.REFUND_EXCHANGE).equalsIgnoreCase(request.getCartInfo().getIntendType()))) {
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_ADJUSTMENT);
        }
        pegaRequest.setServiceHeader(serviceHeader);

        AddAccServiceBody serviceBody = new AddAccServiceBody();
        AddAccServiceRequest serviceRequest = new AddAccServiceRequest();
        AddAccContext context = new AddAccContext();

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
        customerInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());
        customerInfo.setAmRole(request.getCartInfo().getAmRole());
        if("WHW_Redemption".equalsIgnoreCase(request.getCartInfo().getFlowType()))
            customerInfo.setFlowType(request.getCartInfo().getFlowType());
        //ONEAPP-5372 changes
        if(null != request.getCartInfo()
                && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getFlowType())
                && CartConstants.SCAN_AND_GO.equalsIgnoreCase(request.getCartInfo().getFlowType())){
            customerInfo.setFlowType(request.getCartInfo().getFlowType());
        }
        if (request.getCartInfo().getPageId() != null)
            customerInfo.setPageId(request.getCartInfo().getPageId());
        else
            customerInfo.setPageId("PROTECTION");
        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        contextInfo = CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.ADD_ACCESSORY,
                request.getCartInfo().getClientAppName());
        customerInfo.setDeviceId("");
        if (request.getData().getMultiAccBogoOffer() != null)
            customerInfo.setMultiAccBogoOffer(request.getData().getMultiAccBogoOffer());
        context.setCaseId(request.getCartInfo().getCaseId());
        if (request.getCartInfo().getIntendType().toUpperCase().contains("NSE") || (CartConstants.ACC.equalsIgnoreCase(request.getCartInfo().getIntendType())
                && CartConstants.NEW_CUSTOMER.equalsIgnoreCase(request.getCartInfo().getCustomerType())) || CartConstants.NSEACC.equalsIgnoreCase(request.getCartInfo().getIntendType()) ) {
            CartPegaRequestUtil7.newCustomerOverride(contextInfo, customerInfo, request.getCartInfo(), request.getChannelId());
        }

        if(StringUtilities.isNotEmptyOrNull(request.getUniversalId())){
            customerInfo.setUniversalId(request.getUniversalId());
        }
        if(StringUtilities.isNotEmptyOrNull(request.getAppUniversalId())){
            customerInfo.setAppUniversalId(request.getAppUniversalId());
        }

        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntent())) {
            contextInfo.setIntent(request.getCartInfo().getIntent());
        } else if (StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessAction())
                && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())) {
            if (CartConstants.AAL.equalsIgnoreCase(request.getCartInfo().getIntendType()))
                contextInfo.setIntent(CartConstants.AAL);
            else if (CartConstants.EUP.equalsIgnoreCase(request.getCartInfo().getIntendType()))
                contextInfo.setIntent(CartConstants.UPGRADE);
        }
        if (StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessStep()))
            contextInfo.setProcessStep(CartConstants.SHOPPING_CART);
        else
            contextInfo.setProcessStep(request.getCartInfo().getProcessStep());
        if (request.getCartInfo().getProcessAction() != null) {
            contextInfo.setProcessAction(request.getCartInfo().getProcessAction());
        } else
            contextInfo.setProcessAction("");
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(request.getCartInfo().getCartId());
        cartInfo.setClientAppName(request.getCartInfo().getClientAppName());
        cartInfo.setAction(CartConstants.UPDATE);
        cartInfo.setClearCart(request.getData().getClearCart());
        //GTSFN-9958  sending zipCode to pega request for ispu orders in add accessory api with NSEACC implementation
        if(CartConstants.NSEACC.equalsIgnoreCase(request.getCartInfo().getIntendType()) && StringUtilities.isNotEmptyOrNull(request.getData().getZipCode()))
            cartInfo.setZipCode(request.getData().getZipCode());
        //GTSFN-9958  sending zipCode to pega request for ispu orders in add accessory api with NSEACC implementation
        //GTSFN-4413 zipcode sending to pega request for nseacc implementation
        if(CartConstants.NSEACC.equalsIgnoreCase(request.getCartInfo().getIntendType()) && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getZipCode()))
            cartInfo.setZipCode(request.getCartInfo().getZipCode());
        //GTSFN-4413 zipcode sending to pega request for nseacc implementation
        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType())) {
            cartInfo.setIntendType(request.getCartInfo().getIntendType());
        } else
            cartInfo.setIntendType(CartConstants.EUP);
         
        /* VZWYZEK-234 changes starts */
        if (null != request.getCartInfo()
                && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getSubscriptionType())) {
            cartInfo.setSubscriptionType(request.getCartInfo().getSubscriptionType());
        }
        if(null != request.getCartInfo()
                && "true".equals(request.getCartInfo().getClearCart())) {
            cartInfo.setClearCart(true);
        }
        /* VZWYZEK-234 changes ends */
         
        // story ACT262-58 
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getGamingGiftCard())) {
           cartInfo.setGamingGiftCard(request.getCartInfo().getGamingGiftCard());
        }
        
        List<Line> lines = new ArrayList<>();

        if(request.getData()!=null && StringUtilities.isNotEmptyOrNull(request.getData().getSedBarCode())) {
            List<UpdateBarcodeBarcodeId> barCodeIds = new ArrayList<UpdateBarcodeBarcodeId>();
            UpdateBarcodeBarcodeId barCodeId = new UpdateBarcodeBarcodeId();
            barCodeId.setBarCodeId(request.getData().getSedBarCode());
            barCodeIds.add(barCodeId);
            cartInfo.setBarCodeIds(barCodeIds);
            cartInfo.setIncludeExpiryBarcodeStatus("Y");
        }

        if (StringUtilities.isEmptyOrNull(contextInfo.getProcessAction())) {
            cartInfo.setItemType("PROMOTION");
            for (Lines reqLine : request.getData().getLines()) {
                Line newLine = new Line();
                newLine.setMtn(reqLine.getMtn());
                lines.add(newLine);
            }
        } else {
            cartInfo.setItemType("ACCESSORY");
            for (Lines reqLine : request.getData().getLines()) {
                Line newLine = new Line();
                newLine.setMtn(reqLine.getMtn());
                newLine.setAccessories(new AccessoryAction());
                if (reqLine.getRestricted() != null)
                    newLine.setRestricted(reqLine.getRestricted());
                if (reqLine.getRestrictedProductType() != null)
                    newLine.setRestrictedProductType(reqLine.getRestrictedProductType());
                if (StringUtilities.isNotEmptyOrNull(reqLine.getBarCodeId()))
                    newLine.setBarCodeId(reqLine.getBarCodeId());
                if (StringUtilities.isNotEmptyOrNull(reqLine.getLineCreatorChannel()))
                    newLine.setLineCreatorChannel(reqLine.getLineCreatorChannel());

                if (reqLine.getAddAccessories() != null) {
                    for (Accessory addAccessory : reqLine.getAddAccessories()) {
                        if (StringUtilities.isNotEmptyOrNull(addAccessory.getId())) {
                            addAccessory.setId(addAccessory.getId().toUpperCase());
                        }
                        //refund exchange change
                        if (StringUtilities.isNotEmptyOrNull(addAccessory.getAdjPrc())) {
                            addAccessory.setAdjPrc(addAccessory.getAdjPrc());
                        }
                        if (CartConstants.DIGITAL.equalsIgnoreCase(request.getChannelId())
                                && CartConstants.NSEACC.equalsIgnoreCase(request.getCartInfo().getIntendType())
                                && StringUtilities.isNotEmptyOrNull(addAccessory.getCustomBundleId())) {
                            addAccessory.setCustomBundleId(addAccessory.getCustomBundleId());
                        }
                        //XBOX Retail Ordering Changes
                        if (StringUtilities.isNotEmptyOrNull(addAccessory.getMacId()) ) {
                            addAccessory.setMacId(addAccessory.getMacId());
                        }

                        //WHW Change
                        if (Objects.nonNull(addAccessory) && addAccessory.getMacIds() != null && CollectionUtilities.isNotEmptyOrNull(Arrays.asList(addAccessory.getMacIds())) ) {
                            addAccessory.setMacIds(addAccessory.getMacIds());
                        } else {
                            addAccessory.setMacIds(null);
                        }

                        if (addAccessory.isAccountLevelAccessory()) {
                            addAccessory.setAccountLevelAccessory(CartConstants.TRUE);
                        }
                        else {
                            addAccessory.setAccountLevelAccessory(false);
                        }
                        if (StringUtilities.isNotEmptyOrNull(addAccessory.getSerialNumber())) {
                            addAccessory.setSerialNumber(addAccessory.getSerialNumber());
                            logger.info(String.format("Serial Number::%s", addAccessory.getSerialNumber()));
                        }
                    }
                    newLine.getAccessories().setAdd(reqLine.getAddAccessories());
                }
                if (reqLine.getRemoveAccessories() != null) {
                    for (Accessory removeAccessory : reqLine.getRemoveAccessories()) {
                        if (StringUtilities.isNotEmptyOrNull(removeAccessory.getId())) {
                            removeAccessory.setId(removeAccessory.getId().toUpperCase());
                        }
                        //XBOX Retail Ordering Changes
                        if (StringUtilities.isNotEmptyOrNull(removeAccessory.getSerialNumber())) {
                            removeAccessory.setSerialNumber(removeAccessory.getSerialNumber());
                        }
                    }
                    newLine.getAccessories().setRemove(reqLine.getRemoveAccessories());
                }
                newLine.setIspuFlow(reqLine.getIspuFlow());
                if(null != reqLine.getDepletionLocationCode())
                    newLine.setDepletionLocationCode(CartUtil.removeSpecialCharacters(reqLine.getDepletionLocationCode(), request.getChannelId()));
                else
                    newLine.setDepletionLocationCode("");
                    newLine.setEstimatedReadyByDate(reqLine.getEstimatedReadyByDate());
                    newLine.setDepletionType(request.getData().getDepletionType());
                if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getCaseId())
                        && request.getCartInfo().getCaseId().startsWith("SOF") && StringUtilities.isNotEmptyOrNull(request.getData().getDepletionLocationCode())){
                    newLine.setDepletionLocationCode(request.getData().getDepletionLocationCode());
                }
                    newLine.setNewLineOrAAL(reqLine.getNewLineOrAAL());
                    lines.add(newLine);

            }

        }
        Line[] lineArr = new Line[lines.size()];
        lines.toArray(lineArr);
        cartInfo.setLines(lineArr);
        if (StringUtilities.isNotEmptyOrNull(throttleName)
                && CartConstants.ONE_CLICK_CHECKOUT_FOR_ACCESSORY.equalsIgnoreCase(throttleName)) {
            if(enableCradleForExistingCustomer){
                customerInfo.setCradleFlowJourney(CartConstants.PROMO_HUB);
            }
            if(CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())){
                customerInfo.setCradleFlowJourney(CartConstants.ACCESSORIES_INTERSTIAL_PROSPECT);
            }
        }else if (StringUtilities.isNotEmptyOrNull(throttleName)) {
            customerInfo.setCradleFlowJourney(throttleName);
            logger.info("Cradle Flow Journey set in Customer info is :{}",throttleName);
        } else if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCradleFlowJourney())) {
            customerInfo.setCradleFlowJourney(request.getCartInfo().getCradleFlowJourney());
        }
        if((CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType()) ||
                CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType()))){
            if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getMtnFlow())) {
                customerInfo.setMtnFlow(request.getCartInfo().getMtnFlow());
            }
        }
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                && ((CartConstants.REFUND_EXCHANGE).equalsIgnoreCase(request.getCartInfo().getIntendType()))) {
            contextInfo.setCallReason(CartConstants.SALES_ORDER_ADJUSTMENT);
            contextInfo.setIntent(CartConstants.REX);
        }

        if(!enableCradleForProspect &&
                (CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType()) ||
                        CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType()))){
            customerInfo.setCradleFlowJourney("");
        }

        // For Digital Refund Exchange
        if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))
                && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                && ((CartConstants.REFUND_EXCHANGE).equalsIgnoreCase(request.getCartInfo().getIntendType()))) {
            logger.info("Setting details for accessory flow for Digital Rfex");
            if(null != request.getRfexExchangeShopDetails()) {
                logger.info("Setting processingMTN inside customerInfo");
                customerInfo.setProcessingMTN(request.getRfexExchangeShopDetails().getMtn());
            }
            Line[] cartInfoLine = cartInfo.getLines();
            logger.info("Checking availability of cartInfoLine for Digital Rfex");
            if (null != cartInfoLine) {
                for (Line line : cartInfoLine) {
                    if(null != line.getMtn() && null != request.getRfexExchangeShopDetails()) {
                        logger.info("Setting mtn for line");
                        line.setMtn(request.getRfexExchangeShopDetails().getMtn());
                    }
                    if (null != line && null != line.getAccessories()) {
                        logger.info("Checking accessory availability in line for Digital Rfex");
                        Accessory[] addAccessory = line.getAccessories().getAdd();
                        Accessory[] removeAccessory = line.getAccessories().getRemove();
                        logger.info("Accessory available in line for Digital Rfex");
                        if (null != addAccessory) {
                            for (Accessory acc : addAccessory) {
                                logger.info("Accessory for adding fetched for Digital Rfex");
                                if(null != request.getRfexExchangeShopDetails()) {
                                    logger.info("About to set returnItemSeq for addAccessory :{}",request.getRfexExchangeShopDetails().getReturnItemSeq());
                                    acc.setReturnItemSeq(request.getRfexExchangeShopDetails().getReturnItemSeq());
                                }
                            }
                        }

                        if (null != removeAccessory) {
                            for (Accessory acc : removeAccessory) {
                                logger.info("Accessory to remove fetched for Digital Rfex");
                                if(null != request.getRfexExchangeShopDetails()) {
                                    logger.info("About to set returnItemSeq for removeAccessory :{}",request.getRfexExchangeShopDetails().getReturnItemSeq());
                                    acc.setReturnItemSeq(request.getRfexExchangeShopDetails().getReturnItemSeq());
                                }
                            }
                        }
                    }
                }
            }
        }

        if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))
                && StringUtilities.isEmptyOrNull(customerInfo.getCartCreator()) && request.getHttpRequest() != null) {
            logger.info("Setting CartCreator inside customerInfo");
            String flowPath =  String.valueOf(request.getHttpRequest().getPath());
            if (flowPath.contains("nse")) {
                customerInfo.setCartCreator(CartUtil.getValueFromHeaders(request.getHttpRequest().getHeaders(), CartConstants.DIGITAL_IG_SESSION));
            } else {
                customerInfo.setCartCreator(CartUtil.getValueFromHeaders(request.getHttpRequest().getHeaders(), CartConstants.MTN));
            }
        }

        if (enableCradleFlowJourney && CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))) {
            customerInfo.setCradleFlowJourney(CartConstants.PROMO_HUB);
        }

        context.setCartInfo(cartInfo);
        context.setCustomerInfo(customerInfo);

        if(request.getCartInfo()!=null && request.getCartInfo().getCaseId()!=null && request.getCartInfo().getCaseId().startsWith("SOF")){

            logger.info("SalesOrderFlex Prepay add Accessories Request before PEGA call setting Call Reason");
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_FLEX);
            contextInfo.setCallReason(CartConstants.SALES_ORDER_FLEX);

            if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getCaseId())
                    && request.getCartInfo().getCaseId().startsWith("SOF")) {
                if (request.getCartInfo().getOneClick() != null && request.getCartInfo().getOneClick()) {
                    logger.info("CartInfo Line Prepay add Accessory OneClick set to true with Case ID:", request.getCartInfo().getCaseId());
                    cartInfo.setOneClick(request.getCartInfo().getOneClick());
                }
                if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                        && CartConstants.AAL.equalsIgnoreCase(request.getCartInfo().getIntendType())
                        || CartConstants.BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
                    contextInfo.setIntent(request.getCartInfo().getIntendType());
                    customerInfo.setCustomerType(CartConstants.PREPAYEXISTINGCUST);
                    customerInfo.setOriginalCreditApprovalNumber(request.getCartInfo().getCreditAppNum());
                }

            }
        }

        context.setContextInfo(contextInfo);
        context.setCaseId(request.getCartInfo().getCaseId());

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);
        return pegaRequest;
    }

    /**
     * @param pegaRequest
     * @param request
     * @return CreateLinePEGARequest
     */
    public static CreateLinePEGARequest formatCreateLineRequest(CreateLinePEGARequest pegaRequest,
                                                                CreateLineUIRequest request) {

        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        serviceHeader = CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(request.getChannelId());
        if(null!=request.getCartInfo() && null!=request.getCartInfo().getIsPrepayCart() &&
                "Y".equalsIgnoreCase(request.getCartInfo().getIsPrepayCart()))
        {
            serviceHeader.setServiceName("SalesOrderFlex");
        }
        pegaRequest.setServiceHeader(serviceHeader);

        CreateLineServiceBody serviceBody = new CreateLineServiceBody();
        CreateLineServiceRequest serviceRequest = new CreateLineServiceRequest();
        CreateLineContext context = new CreateLineContext();

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        setCustomerInfoForCreateLine(request, customerInfo);

        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        contextInfo = setContextInfoForCreateLine(request, contextInfo);
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        setCartInfoForCreateLine(request, cartInfo,customerInfo,contextInfo);

        context.setContextInfo(contextInfo);
        //Changes for CXTDT-433805
        List<Lines> line_data = null;
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                && request.getCartInfo().getIntendType().equalsIgnoreCase("AAL_5G") || request.getCartInfo().getIntendType().equalsIgnoreCase("AAL") ) {
            line_data = request.getData().getLines();
            for (Lines line : line_data) {
                if (line != null) {
                    if(StringUtilities.isNotEmptyOrNull(line.getDeviceTypeSelected())
                            && line.getDeviceTypeSelected().equalsIgnoreCase("5G Internet")){
                        line.setPurchasePath("AAL_5G");
                    } else {
                        line.setPurchasePath("AAL");
                    }
                }
            }
        }

        ObjectMapper mapper = new ObjectMapper();
        cartInfo.setLines(mapper.convertValue(request.getData().getLines(), Line[].class));
        
        if(request.getData().isEnableFcc()) {
            setAddressInfo(request, cartInfo);
        }
        logger.info("vzId value in formatCreateLineRequest pegaRequest: {}", customerInfo.getVzId());
        context.setCustomerInfo(customerInfo);
        context.setCartInfo(cartInfo);
        context.setCaseId(request.getCartInfo().getCaseId());

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);

        return pegaRequest;
    }

    private static CartServiceContextInfo setContextInfoForCreateLine(CreateLineUIRequest request, CartServiceContextInfo contextInfo) {
        contextInfo = CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.CREATE_LINE, request.getCartInfo().getClientAppName());

        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessStep())) {
            contextInfo.setProcessStep(request.getCartInfo().getProcessStep());
        } else {
            contextInfo.setProcessStep(CartConstants.SHOPPING_CART);
        }


        if(null!= request.getCartInfo() && null!= request.getCartInfo().getIsPrepayCart() &&
                "Y".equalsIgnoreCase(request.getCartInfo().getIsPrepayCart()))
        {
            logger.info("SalesOrderFlex Prepay new line before PEGA call");
            contextInfo.setCallReason("SalesOrderFlex");
        }

        if(CartUtil.isDigital(request.getChannelId()) && CartConstants.BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType()))
            contextInfo.setIntent(CartConstants.BYOD);
        return contextInfo;
    }

    private static void setCartInfoForCreateLine(CreateLineUIRequest request, CartServiceCartInfo cartInfo,CartServiceCustomerInfo customerInfo,CartServiceContextInfo contextInfo) {
        cartInfo.setCartId(request.getCartInfo().getCartId());
        cartInfo.setClientAppName(request.getCartInfo().getClientAppName());
        cartInfo.setAction("");
        cartInfo.setItemType("ADDLINE");
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()))
            cartInfo.setIntendType(request.getCartInfo().getIntendType());
        else
            cartInfo.setIntendType(CartConstants.AAL);
        if (request.getCartInfo().getQuoteWithSkipMDN() != null)
            cartInfo.setQuoteWithSkipMDN(request.getCartInfo().getQuoteWithSkipMDN());
        else
            cartInfo.setQuoteWithSkipMDN(false);
        setAdditionalCartInfoForCreateLine(request, cartInfo, customerInfo, contextInfo);

    }

    /**
     * Method to set the address info to the pega request for NSE customer
     *
     * @param request
     * @param cartInfo
     */
    private static void setAddressInfo(CreateLineUIRequest request, CartServiceCartInfo cartInfo) {
        if (request.getCartInfo() !=null && (CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())
                || CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType()))) {

            Address address = new Address();

            if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getAddressLine1())) {
                address.setAddressLine1(request.getCartInfo().getAddressLine1());
            }
            if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getState())) {
                address.setState(request.getCartInfo().getState());
            }
            if (StringUtilities.isNotEmptyOrNull(request.getData().getZipCode())) {
                address.setZipCode(request.getData().getZipCode());
            }
            if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCity())) {
                address.setCity(request.getCartInfo().getCity());
            }

            if (cartInfo.getLines() !=null && cartInfo.getLines().length > 0 && CartCxpRequestUtil.validateEmptyAddress(address)) {
                cartInfo.getLines()[0].setAddress(address);
            }
        }
    }
    
    
    private static void setAdditionalCartInfoForCreateLine(CreateLineUIRequest request, CartServiceCartInfo cartInfo, CartServiceCustomerInfo customerInfo, CartServiceContextInfo contextInfo) {
        if (CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())
                || CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())
                || CartConstants.NSE_5G.equalsIgnoreCase(request.getCartInfo().getIntendType())
                ||
                (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCustomerType())
                        && CartConstants.PREPAYEXISTINGCUST.equalsIgnoreCase(request.getCartInfo().getCustomerType())
                        && CartConstants.AAL.equalsIgnoreCase(request.getCartInfo().getIntendType())
                        && (null!= request.getCartInfo() && null!= request.getCartInfo().getIsPrepayCart()
                        && "Y".equalsIgnoreCase(request.getCartInfo().getIsPrepayCart()))
                )
        )
        {
            CartPegaRequestUtil7.newCustomerOverride(contextInfo, customerInfo, request.getCartInfo(), request.getChannelId());
            //Adding zipcode for create-line
            if (StringUtilities.isNotEmptyOrNull(request.getData().getZipCode()))
                cartInfo.setZipCode(request.getData().getZipCode());
            if (StringUtilities.isNotEmptyOrNull(request.getData().getNumOfLines()))
                cartInfo.setNumOfLines(request.getData().getNumOfLines());
            if (StringUtilities.isNotEmptyOrNull(request.getData().getFriendsAndFamilyCode()))
                cartInfo.setFriendsAndFamilyCode(request.getData().getFriendsAndFamilyCode());
            if (StringUtilities.isNotEmptyOrNull(request.getData().getCouponCode()))
                cartInfo.setCouponCode(request.getData().getCouponCode());
        }
    }

    private static void setCustomerInfoForCreateLine(CreateLineUIRequest request, CartServiceCustomerInfo customerInfo) {
        if(request !=null && StringUtilities.isNotEmptyOrNull(request.getExternalId())) {
            customerInfo.setVztExternalAccountId(request.getExternalId());
        }
        if(request !=null && StringUtilities.isNotEmptyOrNull(request.getAppUniversalId())) {
            customerInfo.setAppUniversalId(request.getAppUniversalId());
        }
        if(request !=null && StringUtilities.isNotEmptyOrNull(request.getVzId())) {
            customerInfo.setVzId(request.getVzId());
        }
        if (request !=null && request.getCartInfo() !=null && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getAccountNumber()))
            customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        if (request !=null && request.getCartInfo() !=null && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCartCreator()))
            customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
        if (request !=null && request.getCartInfo() !=null && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCradleFlowJourney()))
            customerInfo.setCradleFlowJourney(request.getCartInfo().getCradleFlowJourney());
        if (request !=null && request.getCartInfo() !=null && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessingMTN()))
            customerInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());
        if (request !=null && request.getCartInfo() !=null && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getFlowType()))
            customerInfo.setFlowType(request.getCartInfo().getFlowType());

        if (request !=null && request.getCartInfo() !=null && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getRedemptionCode()))
            customerInfo.setRedemptionCode(request.getCartInfo().getRedemptionCode());
        setSkimImei1CallForCreateLine(request, customerInfo);
        setCradleFlowJourneyForCreateLine(request, customerInfo);

    }

    private static void setSkimImei1CallForCreateLine(CreateLineUIRequest request, CartServiceCustomerInfo customerInfo) {
        if(request !=null && request.getCartInfo() !=null && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCustomerType())
                && CartConstants.PREPAYEXISTINGCUST.equalsIgnoreCase(request.getCartInfo().getCustomerType())
                && CartConstants.AAL.equalsIgnoreCase(request.getCartInfo().getIntendType())
                && (null!= request.getCartInfo() && null!= request.getCartInfo().getIsPrepayCart()
                && "Y".equalsIgnoreCase(request.getCartInfo().getIsPrepayCart()))
        )
        {
            customerInfo.setSkipImei1Call(false);
        }
    }

    private static void setCradleFlowJourneyForCreateLine(CreateLineUIRequest request, CartServiceCustomerInfo customerInfo) {
        if(!enableCradleForProspect && request !=null && request.getCartInfo() !=null && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType()) &&
                (CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())
                        || CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType()))){
            customerInfo.setCradleFlowJourney("");
        }
        if(request !=null && request.getCartInfo() !=null && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getExistingCradleFlowJourney()))
            customerInfo.setCradleFlowJourney(request.getCartInfo().getExistingCradleFlowJourney());
    }

    /**
     * @param pegaRequest
     * @param request
     * @return NumberSharePEGARequest
     */
    public static NumberSharePEGARequest formatNumberShareRequest(NumberSharePEGARequest pegaRequest,
                                                                  NumberShareUIRequest request) {

        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(request.getChannelId());
        pegaRequest.setServiceHeader(serviceHeader);

        NumberShareServiceBody serviceBody = new NumberShareServiceBody();
        NumberShareServiceRequest serviceRequest = new NumberShareServiceRequest();
        NumberShareContext context = new NumberShareContext();
        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.ADD_NUMBERSHARE,
                request.getCartInfo().getClientAppName());

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
        customerInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());
        customerInfo.setNumberShareCapable(request.getCartInfo().getNumberShareCapable());
        customerInfo.setENineAddrIndicator(request.getCartInfo().getENineAddrIndicator());
        customerInfo.setIsNumberShareFromCart(request.getCartInfo().getIsNumberShareFromCart());
        if (CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())
                || CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
            CartPegaRequestUtil7.newCustomerOverride(contextInfo, customerInfo, request.getCartInfo(), request.getChannelId());
        }

        context.setCustomerInfo(customerInfo);
        if (null != request.getCartInfo().getPromoHubJourney() && request.getCartInfo().getPromoHubJourney()
                && !CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())
                && !CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
            customerInfo.setCradleFlowJourney(CartConstants.PROMO_HUB);
        }
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(request.getCartInfo().getCartId());
        cartInfo.setClientAppName(request.getCartInfo().getClientAppName());
        cartInfo.setAction(CartConstants.UPDATE);
        cartInfo.setItemType("NUMBERSHARE");
        cartInfo.setOneClick(request.getCartInfo().getOneClick());
        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType()))
            cartInfo.setIntendType(request.getCartInfo().getIntendType());
        else
            cartInfo.setIntendType(CartConstants.AAL);

        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessStep())) {
            contextInfo.setProcessStep(request.getCartInfo().getProcessStep());
        } else {
            contextInfo.setProcessStep(CartConstants.SHOPPING_CART);
        }
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())) {
            if(request.getCartInfo().getIntendType().equalsIgnoreCase(CartConstants.EUP)) {
                contextInfo.setIntent(CartConstants.UPGRADE);
            }else

                contextInfo.setIntent(request.getCartInfo().getIntendType());
        }


        context.setContextInfo(contextInfo);

        Lines[] linesArr = request.getData().getLines();

        ObjectMapper mapper = new ObjectMapper();

        cartInfo.setLines(mapper.convertValue(linesArr, Line[].class));
        context.setCartInfo(cartInfo);
        context.setCaseId(request.getCartInfo().getCaseId());

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);

        return pegaRequest;
    }

    /**
     * @param pegaRequest
     * @param request
     * @return ServiceAddressPEGARequest
     */
    public static ServiceAddressPEGARequest formatServiceAddressRequest(ServiceAddressPEGARequest pegaRequest,
                                                                        ServiceAddressUIRequest request) {

        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(request.getChannelId());
        pegaRequest.setServiceHeader(serviceHeader);

        ServiceAddressServiceBody serviceBody = new ServiceAddressServiceBody();
        ServiceAddressServiceRequest serviceRequest = new ServiceAddressServiceRequest();
        ServiceAddressContext context = new ServiceAddressContext();

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(request.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(request.getCartInfo().getCartCreator());
        customerInfo.setProcessingMTN(request.getCartInfo().getProcessingMTN());
        if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getDeviceType())) {
            customerInfo.setDeviceType(request.getCartInfo().getDeviceType());
        }

        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(request.getCartInfo().getCartId());
        cartInfo.setClientAppName(request.getCartInfo().getClientAppName());
        cartInfo.setItemType("SERVICEADDRESS");
        cartInfo.setAction(CartConstants.UPDATE);
        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getIntendType()))
            cartInfo.setIntendType(request.getCartInfo().getIntendType());
        else
            cartInfo.setIntendType(CartConstants.AAL);

        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.ADD_SERVICE_ADDRESS,
                request.getCartInfo().getClientAppName());
        if (!StringUtilities.isEmptyOrNull(request.getCartInfo().getProcessStep())) {
            contextInfo.setProcessStep(request.getCartInfo().getProcessStep());
        } else {
            contextInfo.setProcessStep(CartConstants.SHOPPING_CART);
        }
        if(CartConstants.CHANNEL_ID_BBP.equalsIgnoreCase(request.getCartInfo().getClientAppName())) {
            contextInfo.setIntent(CartConstants.BYOD);
        }
        context.setContextInfo(contextInfo);

        List<Line> lines = new ArrayList<>();
        for (Lines reqLine : request.getData().getLines()) {
            Line newLine = new Line();
            newLine.setMtn(reqLine.getMtn());
            ServiceAddress serviceAddress = new ServiceAddress();
            Address uiAddress = reqLine.getServiceAddress().getAddress();
            Address address = new Address();
            address.setApartmentNo(uiAddress.getApartmentNo());
            address.setStreetNumber(uiAddress.getStreetNumber());
            address.setStreetName(uiAddress.getStreetName());
            address.setType(uiAddress.getType());
            address.setAddressLine2(uiAddress.getAddressLine2());
            address.setAddressLine1(uiAddress.getAddressLine1());
            address.setPoBoxNo(uiAddress.getPoBoxNo());
            address.setRuralDelNo(uiAddress.getRuralDelNo());
            address.setCity(uiAddress.getCity());
            address.setState(uiAddress.getState());
            address.setZipCode(uiAddress.getZipCode());
            address.setZipCode4(uiAddress.getZipCode4());
            address.setCountryCode(uiAddress.getCountryCode());
            address.setFipsCode(uiAddress.getFipsCode());
            address.setFirmName(uiAddress.getFirmName());
            address.setFirstName(uiAddress.getFirstName());
            address.setLastName(uiAddress.getLastName());
            address.setPhoneNumber(uiAddress.getPhoneNumber());
            address.setEmailId(uiAddress.getEmailId());
            address.setAttention(uiAddress.getAttention());
            serviceAddress.setAddress(address);
            newLine.setServiceAddress(serviceAddress);
            newLine.setMtn(reqLine.getMtn());
            lines.add(newLine);
        }

        if (CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())
                || CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
            CartPegaRequestUtil7.newCustomerOverride(contextInfo, customerInfo, request.getCartInfo(), request.getChannelId());

        }
        if (null != request.getCartInfo().getExpressCheckout() && request.getCartInfo().getExpressCheckout()) {
            customerInfo.setCradleFlowJourney(CartConstants.PROMO_HUB);
        }

        Line[] lineArr = new Line[lines.size()];
        lines.toArray(lineArr);

        cartInfo.setLines(lineArr);

        context.setCustomerInfo(customerInfo);
        context.setCartInfo(cartInfo);
        context.setCaseId(request.getCartInfo().getCaseId());

        //MVP2-GR
        if(request.getCartInfo()!=null && request.getCartInfo().getCaseId()!=null && request.getCartInfo().getCaseId().startsWith("SOF")){

            logger.info("SalesOrderFlex Prepay service address Request before PEGA call setting Call Reason");
            contextInfo.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);

        return pegaRequest;
    }

    /**
     *
     * @param uiRequest
     * @param pegaRequest
     * @return EffectiveDateOverrideUIRequest
     */
    public static EffectiveDateOverridePEGARequest formatEffectiveDateOverrideRequest(
            EffectiveDateOverrideUIRequest uiRequest, EffectiveDateOverridePEGARequest pegaRequest) {

        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        CartPegaRequestUtil.addServiceHeader(serviceHeader);
        serviceHeader.setClientId(uiRequest.getChannelId());
        pegaRequest.setServiceHeader(serviceHeader);

        EffectiveDateOverrideServiceBody serviceBody = new EffectiveDateOverrideServiceBody();
        EffectiveDateOverrideServiceRequest serviceRequest = new EffectiveDateOverrideServiceRequest();
        EffectiveDateOverrideContext context = new EffectiveDateOverrideContext();

        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber(uiRequest.getCartInfo().getAccountNumber());
        customerInfo.setCartCreator(uiRequest.getCartInfo().getCartCreator());
        customerInfo.setProcessingMTN(uiRequest.getCartInfo().getProcessingMTN());
        context.setCustomerInfo(customerInfo);

        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(uiRequest.getCartInfo().getCartId());
        cartInfo.setClientAppName(uiRequest.getCartInfo().getClientAppName());
        cartInfo.setAction(CartConstants.UPDATE);
        cartInfo.setItemType("EFFECTIVE-DATE-OVERRIDE");
        if (!StringUtilities.isEmptyOrNull(uiRequest.getCartInfo().getIntendType()))
            cartInfo.setIntendType(uiRequest.getCartInfo().getIntendType());
        else
            cartInfo.setIntendType(CartConstants.EUP);
        cartInfo.setRetrieveFeatureLossReferenceData(uiRequest.getData().getRetrieveFeatureLossReferenceData());
        cartInfo.setCheckAutoPayDiscountEligible(uiRequest.getData().getCheckAutoPayDiscountEligible());
        cartInfo.setParentMtn(uiRequest.getData().getParentMtn());
        cartInfo.setManagerId(uiRequest.getData().getManagerId());
        cartInfo.setPassword(uiRequest.getData().getPassword());
        cartInfo.setComments(uiRequest.getData().getComments());
        List<Line> lines = new ArrayList<>();
        for (Lines reqLine : uiRequest.getData().getLines()) {
            Line newLine = new Line();
            newLine.setMtn(reqLine.getMtn());
            lines.add(newLine);
        }
        Line[] lineArr = new Line[lines.size()];
        lines.toArray(lineArr);
        cartInfo.setLines(lineArr);
        context.setCartInfo(cartInfo);

        context.setCaseId(uiRequest.getCartInfo().getCaseId());

        CartServiceContextInfo contextInfo = new CartServiceContextInfo();
        CartPegaRequestUtil.addContextInfo(contextInfo, CartConstants.EFFECTIVE_DATE_UPDATE,
                uiRequest.getCartInfo().getClientAppName());
        if (StringUtilities.isNotEmptyOrNull(uiRequest.getCartInfo().getProcessStep())) {
            contextInfo.setProcessStep(uiRequest.getCartInfo().getProcessStep());
        } else {
            contextInfo.setProcessStep(CartConstants.INTERIM_PAGE);
        }

        //MVP2-GR
        if(uiRequest.getCartInfo()!=null && uiRequest.getCartInfo().getCaseId()!=null && uiRequest.getCartInfo().getCaseId().startsWith("SOF")){

            logger.info("SalesOrderFlex Prepay effective date override Request before PEGA call setting Call Reason");
            contextInfo.setCallReason(CartConstants.SALES_ORDER_FLEX);
            serviceHeader.setServiceName(CartConstants.SALES_ORDER_FLEX);
        }

        context.setContextInfo(contextInfo);

        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        pegaRequest.setServiceBody(serviceBody);

        return pegaRequest;

    }

    /**
     * Method to all quick shop pega request flags*
     * @param request
     * @param cartInfo
     * @param contextInfo
     */
    public static void addQuickShopPegaRequestFlag(AddFeaturesUIRequest request, CartServiceCartInfo cartInfo, CartServiceContextInfo contextInfo) {
        if(CartUtil.isDigital(request.getChannelId()) && CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType())
                && null != request.getCartInfo().getQuickShop()) {
            contextInfo.setProcessAction(request.getCartInfo().getProcessAction());
            cartInfo.setIsQuickShopFlow(request.getCartInfo().getQuickShop());
            if(null != request.getCartInfo().getEditDeviceConfiguratorClick() && request.getCartInfo().getEditDeviceConfiguratorClick()){
                if(null != request.getCartInfo().getEditFromBYOPlan() && request.getCartInfo().getEditFromBYOPlan()) {
                    cartInfo.setEditFromBYOPlan(request.getCartInfo().getEditFromBYOPlan());
                }
                if(null != request.getCartInfo().getEditFromBYOPerk() && request.getCartInfo().getEditFromBYOPerk()) {
                    cartInfo.setEditFromBYOPerk(request.getCartInfo().getEditFromBYOPerk());
                }
            }
        }
    }

    public static boolean isFeatureOrSPOUpdateOnly(AddFeaturesUIRequest request) {
        return Objects.nonNull(request.getCartInfo())
                && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())
                && request.getCartInfo().getIntendType().equalsIgnoreCase(CartConstants.FEA)
                && FEATURE_SELECTION.equalsIgnoreCase(request.getCartInfo().getProcessStep())
                && !CartConstants.FLOW_TYPE_WHW.equalsIgnoreCase(request.getCartInfo().getFlowType());
    }

    public static void addByodLineDetailsToPegaReq(String intendType, CartServiceCartInfo cartInfo, List<ByodLineDetails> byodLineDetails,
                                                   Boolean isDeviceFirstEnableForProspectBYODFFlag, Boolean isDeviceFirstEnableForExistingBYODFFlag){
        if((CartConstants.NSE_BYOD.equalsIgnoreCase(intendType)
                && Boolean.TRUE.equals(isDeviceFirstEnableForProspectBYODFFlag))
                || (CartConstants.BYOD.equalsIgnoreCase(intendType)
                && Boolean.TRUE.equals(isDeviceFirstEnableForExistingBYODFFlag))){
            cartInfo.setByodLineDetails(byodLineDetails);
        }
    }
}
