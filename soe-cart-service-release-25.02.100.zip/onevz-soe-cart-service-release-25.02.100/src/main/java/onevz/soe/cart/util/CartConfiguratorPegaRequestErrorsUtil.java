package onevz.soe.cart.util;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.constants.ConfiguratorConstants;
import onevz.soe.cart.model.common.CartErrorDetail;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.AddAllConfiguratorUIRequest;
import onevz.soe.channels.SOEChannels;
import onevz.soe.utilities.StringUtilities;

import java.util.ArrayList;
import java.util.List;

/**
 * The Class Cart configurator pega request errors util.
 */
public class CartConfiguratorPegaRequestErrorsUtil extends CartPegaRequestErrorsUtilParent {

    private CartConfiguratorPegaRequestErrorsUtil() {

    }

    /**
     * Handle add all configurator request errors error response.
     *
     * @param request the request
     * @return the error response
     */
    public static ErrorResponse handleAddAllConfiguratorRequestErrors(AddAllConfiguratorUIRequest request) {

        List<CartErrorDetail> errorDetails = new ArrayList<>();
        if (request.getChannelId() != null && !CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))) {
            // Currently NGD is dealing with digital channels
            errorDetails.add(generateValidationError(CartConstants.CHANNEL));
        }
        if (request.getCartInfo() == null) {
            //Cart Info cannot be null
            errorDetails.add(generateMissingError(CartConstants.CART));
        } else {
            checkIntentTypeValidity(request.getCartInfo().getIntendType(), errorDetails);
            checkProcessStepValidity(request.getCartInfo().getProcessStep(), errorDetails);
            checkProcessActionValidity(request, errorDetails);
            checkItemTypeValidity(request, errorDetails);
            checkCartInfoLineValidity(request, errorDetails);

        }
        ErrorResponse errors = CartCxpRequestErrorsUtil.generateErrorResponse(errorDetails);
        return errors == null ? new ErrorResponse() : errors;
    }

    private static void checkCartInfoLineValidity(AddAllConfiguratorUIRequest request, List<CartErrorDetail> errorDetails) {
        List<Lines> lineData = request.getData().getLines();
        if (lineData == null || lineData.isEmpty()) {
            // Line Data cannot be null
            errorDetails.add(generateMissingError(CartConstants.LINE_DETAILS));
        } else {
            int index = 0;
            for (Lines line : lineData) {
                errorDetails = validateMtn(errorDetails, index, line.getMtn());
                if (line.getDevice() != null && StringUtilities.isNotEmptyOrNull(request.getChannelId()) && SOEChannels.findByChannelName(request.getChannelId()).getChannelType().equals(CartConstants.DIGITAL_CHANNEL)) {
                    errorDetails = validateProductId(errorDetails, index, line.getDevice().getProductId());
                }
                index++;
            }
        }

    }

    private static void checkItemTypeValidity(AddAllConfiguratorUIRequest request, List<CartErrorDetail> errorDetails) {
        if (!ConfiguratorConstants.CONFIGURATOR_ITEM_TYPE.equalsIgnoreCase(request.getCartInfo().getItemType())) {
            //				itemType is "DEVICES-AND-SERVICES"
            errorDetails.add(generateValidationError(CartConstants.ITEM_TYPE));
        }
    }

    private static void checkProcessActionValidity(AddAllConfiguratorUIRequest request, List<CartErrorDetail> errorDetails) {
        if (!ConfiguratorConstants.ADD_TO_CART_FROM_CONFIGURATOR.equalsIgnoreCase(request.getCartInfo().getProcessAction())) {
            //				processAction is "AddAll"
            errorDetails.add(generateValidationError(CartConstants.PROCESS_ACTION));
        }
    }

    private static void checkProcessStepValidity(String processStep, List<CartErrorDetail> errorDetails) {
        if (!ConfiguratorConstants.NGD_CONFIGURATOR.equalsIgnoreCase(processStep)) {
            //		processStep is "Configurator",
            errorDetails.add(generateValidationError(CartConstants.PROCESS_STEP));
        }
    }

    private static void checkIntentTypeValidity(String intendType, List<CartErrorDetail> errorDetails) {
        if (StringUtilities.isEmptyOrNull(intendType)) {
            // intentType should not be null
            errorDetails.add(generateMissingError(CartConstants.INTEND_TYPE));
        }
        if (!CartConstants.NSE.equalsIgnoreCase(intendType)) {
            //Currently in NGD configurator we are dealing with NSE FLOW only
            errorDetails.add(generateValidationError(CartConstants.INTEND_TYPE));
        }
    }
}

