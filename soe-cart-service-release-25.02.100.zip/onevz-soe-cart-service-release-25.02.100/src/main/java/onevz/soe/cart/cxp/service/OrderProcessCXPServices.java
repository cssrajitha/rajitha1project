package onevz.soe.cart.cxp.service;

import onevz.soe.cart.requests.AgreementDetailsCXPRequest;
import onevz.soe.cart.responses.AgreementDetailsCXPResponse;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import onevz.wsclient.cxp.CXPServices;
import onevz.wsclient.cxp.annotations.CXPJson;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

/**
 * @author VZ India
 *
 */
@Service
@Primary
public interface OrderProcessCXPServices extends CXPServices {


	@CXPJson(component = "order", urlPostFix = "/ordering/retrieve-agreements")
	public Mono<AgreementDetailsCXPResponse> getAgreementDetails(AgreementDetailsCXPRequest request) throws SOEHTTPException;

}
