package onevz.soe.cart.controller;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.helper.RedisHelper2;
import onevz.soe.cart.model.common.BvoOffers;
import onevz.soe.cart.requests.DualNumberRedisInfo;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.util.CartPegaRequestErrorsUtil;
import onevz.soe.utilities.CollectionUtilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import jakarta.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Cart Controller class.
 */
//NSADT-53978 removing CrossOrigin annotation in every service
//@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping(value = "cart")
public class CartRedisController {

	private static final Logger logger = LoggerFactory.getLogger(CartRedisController.class);

	@Autowired
	private RedisHelper redisHelper;

	@Autowired
	private RedisHelper2 redisHelper2;

	/**
	 * 
	 * @param binder
	 */
	@InitBinder("*")
	public void initBinderByName(WebDataBinder binder) {
		binder.setDisallowedFields(new String[] { "genericHeader" });
	}

	/**
	 * 
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return redisResponse
	 */
	@PostMapping("/upsert5GAddress")
	public Mono<ResponseEntity<Boolean>> upsert5GAddress(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse,
			@Valid @RequestBody FiveGAddressRedisData request) {
		System.setProperty(CartConstants.ENDPOINT, "upsert5GAddress");
		logger.debug("upsert5GAddress Request: {}", request);
		return redisHelper2.upsertFiveGAddressIntoRedis(request).flatMap(redisResponse -> {
			return redisResponse != null ? Mono.just(ResponseEntity.status(HttpStatus.OK).body(true))
					: Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(false));
		});
	}

	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @return resp
	 *
	 */
	@GetMapping("/removeHexPlanInfofromRedis")
	public Mono<ResponseEntity<Boolean>> removeHexPlanInfofromRedis(ServerHttpRequest httpHeader,
			ServerHttpResponse httpResponse) {
		System.setProperty(CartConstants.ENDPOINT, "removeHexPlanInfofromRedis");
		List<String> keys = new ArrayList<>();
		keys.add(CartConstants.MYOFFER_HEXPLAN_INFO);
		return redisHelper.deleteHexPlanOfferInfoIntoRedis(keys).map(redisResponse -> {
			return redisResponse != null ? ResponseEntity.status(HttpStatus.OK).body(true)
					: ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(false);
		});
	}

	/**
	 * 
	 * 
	 * 
	 * /**
	 * 
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return redisResponse
	 */
	@PostMapping("/upsertRTDData")
	public Mono<ResponseEntity<Boolean>> upsertRTDData(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse,
			@Valid @RequestBody RTDRedisData request) {
		System.setProperty(CartConstants.ENDPOINT, "upsertRTDData");
		logger.debug("upsertRTDData Request: {}", request);
		return redisHelper2.upsertRTDRedisDataIntoRedis(request).flatMap(redisResponse -> {
			return redisResponse != null ? Mono.just(ResponseEntity.status(HttpStatus.OK).body(true))
					: Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(false));
		});
	}

	@PostMapping("/upsertRemoveOfferData")
	public Mono<ResponseEntity<RemoveOfferRedisResponse>> upsertRemoveOfferData(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse,
			@Valid @RequestBody RemoveOfferRedisData request) {
		System.setProperty(CartConstants.ENDPOINT, "upsertRemoveOfferData");
		logger.debug("upsertRemoveOfferData Request: {}", request);
		
		RemoveOfferRedisResponse removeOfferRedisResponse=new RemoveOfferRedisResponse();
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleUpsertRemoveOfferDataRequestErrors(request);
		if (errors.getErrors() != null) {
			removeOfferRedisResponse.setStatus(errors.getErrors().get(0).getDetailList().get(0).getIssue());
			return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(removeOfferRedisResponse));
		}
		return redisHelper2.getRemoveOfferDataIntoRedis().flatMap(existingRemoveOfferDataInRedis ->{
			logger.info("existingRemoveOfferDataInRedis {}",existingRemoveOfferDataInRedis);
			if(existingRemoveOfferDataInRedis.getLines()!= null) {
				//combine all requests
				List<Lines> existingRemoveOfferRedisLine = existingRemoveOfferDataInRedis.getLines();
				List<Lines> differentLines = new ArrayList<>();
				
					request.getLines().stream().forEach(reqLine -> {
						existingRemoveOfferRedisLine.stream().forEach(line ->{
						if(reqLine.getMtn().equalsIgnoreCase(line.getMtn())) {
							List<BvoOffers> differentOffers = new ArrayList<>();
							line.getRemoveOffers().stream().forEach(offer -> {
								reqLine.getRemoveOffers().stream().forEach(reqOffer -> {
									if(!offer.getId().equalsIgnoreCase(reqOffer.getId()) && 
											!differentOffers.stream().filter(differOffer -> reqOffer.getId().equalsIgnoreCase(differOffer.getId())).findAny().isPresent()) {
										differentOffers.add(reqOffer);
									}
								});
							});
							if(CollectionUtilities.isNotEmptyOrNull(differentOffers)) {
								line.getRemoveOffers().addAll(differentOffers);
								differentOffers.clear();
							}
							
						} else if(!existingRemoveOfferRedisLine.stream().filter(redisLine -> reqLine.getMtn().equalsIgnoreCase(redisLine.getMtn())).findAny().isPresent()
								&& !differentLines.stream().filter(differLine -> reqLine.getMtn().equalsIgnoreCase(differLine.getMtn())).findAny().isPresent()){
							differentLines.add(reqLine);
						}
						});	
					});
				
				if(CollectionUtilities.isNotEmptyOrNull(differentLines)) {
					existingRemoveOfferRedisLine.addAll(differentLines);
					differentLines.clear();
				}
				request.setLines(existingRemoveOfferRedisLine);	
			}
			
			return redisHelper2.upsertRemoveOfferDataIntoRedis(request).flatMap(redisResponse -> {
					return redisHelper2.getRemoveOfferDataIntoRedis().flatMap(removeOfferDataInRedis ->{
						if(removeOfferDataInRedis.getLines()!= null) {
							//validate all requests
							List<Lines> removeOfferDataInRedisLines = removeOfferDataInRedis.getLines();
							List<Lines> lines = request.getLines();						
							 Boolean isRedisUpdated=true;
							for (Lines reqLine : removeOfferDataInRedisLines) {
								for (Lines redisLine : lines) {
									if(redisLine.getMtn().equalsIgnoreCase(reqLine.getMtn())) {									
												List<String> redisOffer = redisLine.getRemoveOffers().stream().map(obj -> obj.getId()).collect(Collectors.toList());
												List<String> reqOffer = reqLine.getRemoveOffers().stream().map(obj -> obj.getId()).collect(Collectors.toList());
												if(redisOffer.equals(reqOffer)) {
											isRedisUpdated=true;
										}else {
											isRedisUpdated=false;
										}									
									}
								}
							   }
							if(isRedisUpdated) {
								removeOfferRedisResponse.setStatus(CartConstants.STATUS_SUCCESS);
								return Mono.just(ResponseEntity.status(HttpStatus.OK).body(removeOfferRedisResponse));
							}else {
								removeOfferRedisResponse.setStatus("Failure");
								return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(removeOfferRedisResponse));
							}
						}else {
							removeOfferRedisResponse.setStatus("Failure");
							return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(removeOfferRedisResponse));
						}
						});
					});
		});
	}

	@PostMapping("/removeSecondNumberDetails")
	public Mono<ResponseEntity<Boolean>> removeDualNumberDetailsFromRedis(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse,
													   @Valid @RequestBody DualNumberRedisInfo dualNumberInfo) {
	System.setProperty(CartConstants.ENDPOINT, "removeSecondNumberDetails");
		return redisHelper.deletDualNumberDetailsFromRedis(dualNumberInfo).map(redisResponse -> {
			return redisResponse != null ? ResponseEntity.status(HttpStatus.OK).body(true)
					: ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(false);
		});
	}
}
