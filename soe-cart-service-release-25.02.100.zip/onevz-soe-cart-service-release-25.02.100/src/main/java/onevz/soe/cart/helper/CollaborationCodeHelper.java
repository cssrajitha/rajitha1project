package onevz.soe.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.onevzsoe.peripherals.cassandra.PlanbuilderDatastoreClient;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.responses.LookupColloborationCodeResponse;
import onevz.soe.exception.ErrorType;
import onevz.soe.exception.SOEError;
import onevz.soe.utilities.StringUtilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.Arrays;

@Service
public class CollaborationCodeHelper {

    private static final Logger logger = LoggerFactory.getLogger(CollaborationCodeHelper.class);

    @Autowired
    private PlanbuilderDatastoreClient planbuilderDatastoreClient;

    @Value("${planbuilder.qrExpiryInMinutes:20}")
    private Integer qrExpiryInMinutes;

    @Autowired
    private ObjectMapper objectMapper;

    public Mono<LookupColloborationCodeResponse> getDataForLookupPasscode(String zipCode, String lookupPasscode) {
        return getCassandraKeyForRetailCollaborationCode(lookupPasscode, zipCode).flatMap(key -> {
            return readPlanBuilderData(key);
        });
    }

    private Mono<LookupColloborationCodeResponse> readPlanBuilderData(String key) {
        return planbuilderDatastoreClient.readPlanBuilderData(key, CartConstants.COLLABORATION_QR_CODE)
                .onErrorResume(Mono::error)
                .defaultIfEmpty(CartConstants.NO_CONTENT)
                .flatMap(dataFromCassandra -> {
                    if(CartConstants.NO_CONTENT.equals(dataFromCassandra)){
                        logger.info("No data present in cassandra for the key provided");
                        LookupColloborationCodeResponse response = new LookupColloborationCodeResponse();
                        response.setErrors(Arrays.asList(constructSOEError(ErrorType.API_ERROR,"204", CartConstants.NO_CONTENT)));
                        return Mono.just(response);
                    }else{
                        logger.info("Got response from PlanBuilderDataStoreClient::readPlanBuilderData, data:{}", dataFromCassandra);

                        LookupColloborationCodeResponse response = new LookupColloborationCodeResponse();
                        boolean expired  = false;
                        try {
                            JsonNode jsonNode = objectMapper.readValue(dataFromCassandra, JsonNode.class);
                            response.setData(jsonNode);
                        } catch (JsonProcessingException e) {
                            logger.error("Error while converting cassandra data to response:",e);
                        }
                        return Mono.just(response);
                    }

                });

    }

    private SOEError constructSOEError(ErrorType type, String code, String message){
        SOEError error = new SOEError();
        error.setMessage(message);
        error.setType(type.name());
        error.setId(code);
        error.setNamespace(CartConstants.SOE_SERVICE_NAME);
        return error;
    }

    private Mono<String> getCassandraKeyForRetailCollaborationCode(String digitCode, String zipCode) {
            String reversedZipCode = new StringBuilder(zipCode).reverse().toString();
            return generateKeyForCassandraForPlanBuilder(null,digitCode,reversedZipCode);
    }
    private Mono<String> generateKeyForCassandraForPlanBuilder(String suffix, String... keys){
        StringBuilder cassandraKeyBuilder =  new StringBuilder();
        for(String key : keys){
            cassandraKeyBuilder.append(key).append(CartConstants.HYPHEN);
        }
        cassandraKeyBuilder.append(CartConstants.PLANBUILDER);
        if(StringUtilities.isNotEmptyOrNull(suffix)){
            cassandraKeyBuilder.append(CartConstants.HYPHEN).append(suffix);
        }
        return Mono.just(cassandraKeyBuilder.toString());
    }

}
