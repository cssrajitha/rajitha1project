package onevz.soe.cart.helper;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.cradle.util.CradleConstants;
import com.vzw.cradle.vo.CradleResponse;

import onevz.cxp.feature.util.FeatureFlag;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.constants.FeatureFlagConstants;
import onevz.soe.cart.requests.RetrieveBundleAccRequest;
import onevz.soe.cart.ui.common.RetrieveBundleAccData;
import onevz.soe.cradle.CradleAllocator;
import onevz.soe.cradle.constant.Constants;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.utilities.serialization.JacksonMapperFactory;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.time.Duration;
import java.util.*;
import java.util.stream.Stream;

import static com.vzw.cradle.util.CradleConstants.CHANNEL;

@Service
public class CradleHelper {

    private static final Logger logger = LoggerFactory.getLogger(CradleHelper.class);

    @Autowired
    CradleAllocator cradleAllocator;

    @Autowired
    RedisHelper redisHelper;

    @Autowired
    private FeatureFlag featureFlag;

    private static final String NSA = "NSA";
    private static final String HYPEN = "-";
    private static final String IS_PROSPECT = "isProspect";
    private static final String CRADLE_MTN = "mtn";
    private static final String FLOW = "flow";
    private static final String FLOW_NAO = "NAO";

    public Mono<Boolean> isInFlowCart(ServerHttpRequest httpRequest, ServerHttpResponse httpResponse) {
        return featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,FeatureFlagConstants.CONFIGURATOR,FeatureFlagConstants.INFLOW_CART_FLAG,false).flatMap(isInflowCartEnabled -> {
            if (isInflowCartEnabled) {
                return redisHelper.getRequiredDataFromRedis(List.of(Constants.CRADLE_DATAMAP_KEY)).flatMap(data -> {
                    if (isAnyOfInFlowsPresentInThrottleList(data).isEmpty()) {
                        return cradleAllocator.invokeReactiveCradle(httpRequest,httpResponse,Map.of(CradleConstants.PAGE_NAME,CartConstants.INFLOW_CART_CRADLE_PAGE ))
                                .filter(cradleResponse -> StringUtilities.isNotEmptyOrNull(cradleResponse.getOutPut()))
                                .map(CradleResponse::getOutPut)
                                .map(this::StringToMap)
                                .map(resMap -> resMap.get(Constants.THROTTLE_LIST))
                                .map(String::valueOf)
                                .map(throttleList -> throttleList.contains(CartConstants.INFLOW_CART)).switchIfEmpty(Mono.just(Boolean.FALSE));
                    }
                    boolean isInflowCart = isAnyOfInFlowsPresentInThrottleList(data).map(throttle -> throttle.contains(CartConstants.INFLOW_CART)).orElse(false);
                    return Mono.just(isInflowCart);
                });
            }
            return Mono.just(Boolean.FALSE);
        });
    }

    public Optional<String> isAnyOfInFlowsPresentInThrottleList(Map cradleDatamap){
        return  Optional.ofNullable(cradleDatamap).map(datamap -> datamap.get(Constants.CRADLE_DATAMAP_KEY))
                .map(String::valueOf)
                .map(this::StringToMap)
                .map(resMap -> resMap.get(Constants.THROTTLE_LIST))
                .map(String::valueOf)
                .filter(throttleList -> Stream.of(CartConstants.INFLOW_C_CART,CartConstants.INFLOW_CART).anyMatch(throttleList::contains));
    }

    private Map StringToMap(String res) {
        try {
            return JacksonMapperFactory.defaultReader().readValue(res, Map.class);
        } catch (IOException e) {
            logger.error("json Error in reading Cradle Datamap , {} ", ExceptionUtils.getStackTrace(e));
            return Collections.emptyMap();
        }
    }

    public Mono<String> getThrottlingList(RetrieveBundleAccRequest retrieveBundleAccRequest, ServerHttpRequest httpRequest,
                                          ServerHttpResponse httpResponse ) {
        Map<String, String> dataMap = new HashMap<String, String>();
        if (retrieveBundleAccRequest != null && retrieveBundleAccRequest.getData() != null){
            RetrieveBundleAccData data = retrieveBundleAccRequest.getData();

            String pageId = StringUtils.isNotBlank(data.getPageId()) ? data.getPageId() : "acc-interestial-bundle";

            StringBuilder val= new StringBuilder();
            val.append(NSA);
            val.append(HYPEN);
            val.append(pageId);
            dataMap.put(CradleConstants.PAGE_NAME, "acc-interestial-bundle");


            if(StringUtilities.isNotEmptyOrNull(retrieveBundleAccRequest.getChannelId())) {
                dataMap.put(CHANNEL, retrieveBundleAccRequest.getChannelId());
            }else{
                logger.info(String.format("Empty channel id from UI request defaulting to VZW_DOTCOM %s",retrieveBundleAccRequest));
                dataMap.put(CHANNEL, CartConstants.VZW_DOTCOM);
            }
            String intent = data.getIntent();

            if("NSE".equalsIgnoreCase(intent)) {
                dataMap.put(IS_PROSPECT, "true");
            } else {
                dataMap.put(IS_PROSPECT, CartConstants.FALSE);
                if(StringUtils.isNotBlank(data.getProcessingMTN()))
                    dataMap.put(CRADLE_MTN, data.getProcessingMTN());
            }
            logger.info("getThrottlingList bundle Accessories {}", dataMap);

            if(StringUtils.isNotBlank(data.getEnabledFlow())&&data.getEnabledFlow().equalsIgnoreCase(FLOW_NAO)) {
                dataMap.put(FLOW,FLOW_NAO);
                return getThrottlingList(dataMap,httpRequest,httpResponse);
            }

            return redisHelper.getDataFromRedis().flatMap(sessionData -> {
                if(StringUtils.isNotBlank(sessionData.getIntendType())) {
                    dataMap.put(FLOW,sessionData.getIntendType());
                } else if(StringUtils.isNotBlank(sessionData.getIntent())) {
                    dataMap.put(FLOW,sessionData.getIntent());
                }

                return getThrottlingList(dataMap,httpRequest,httpResponse);

            });
        }
        return Mono.just("");
    }

    public Mono<String> getThrottlingList(Map<String, String> dataMap,
                                          ServerHttpRequest httpRequest, ServerHttpResponse httpResponse ) {

       if (dataMap.isEmpty()){
           return Mono.just("");
       }
        Mono<CradleResponse> cradleResponseMono = cradleAllocator.invokeReactiveCradle(httpRequest, httpResponse, dataMap)
                .timeout(Duration.ofSeconds(3),defaultCradleResponse()).onErrorResume(fallback -> defaultCradleResponse()).switchIfEmpty(defaultCradleResponse());
        if (cradleResponseMono != null) {
            return cradleResponseMono.flatMap(cradleResponse -> getCradleOutput(cradleResponse));
        }


        return Mono.just("");
    }

    public Mono<CradleResponse> defaultCradleResponse(){
        CradleResponse response = new CradleResponse();

        response.setOutPut(null);

        return Mono.just(response);
    }

    public Mono<String> getCradleOutput(CradleResponse cradleResponse) {
        if (null != cradleResponse && null != cradleResponse.getOutPut()) {
            logger.debug(String.format("cradleResponse %s" , cradleResponse.getOutPut()));
            ObjectMapper mapper = new ObjectMapper();
            try {
                JsonNode cradleOutputJsonNode = mapper.readTree(cradleResponse.getOutPut());
                if (null != cradleOutputJsonNode && null != cradleOutputJsonNode.get(CartConstants.THROTTLE_LIST)) {
                    return Mono.just(cradleOutputJsonNode.get(CartConstants.THROTTLE_LIST).asText());
                }
            } catch (JsonProcessingException jpEx) {
                logger.error(String.format("cardle parssing error %s" , jpEx));
            }

        } else {
            logger.debug("Response From cradle is null");
            logger.error("Response From cradle is null");
        }

        return Mono.just("");

    }
}
