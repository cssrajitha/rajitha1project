package onevz.soe.cart.constants;

import java.util.*;


/**
 * Cart Constants class.
 */
public class CartConstants {

    public static final String INFLOW_CART="INFLOW_CART";

    public static final String INFLOW_CART_CRADLE_PAGE="INFLOW_CART";

    public static final String INFLOW_C_CART="INFLOW_C_CART";

    public static final String BUILD_LINE = "buildLine";
    public static final String DEFAULT_CREDIT_HOLD_REASON_CODE = "2Y";
    public static final String ORDER_STATUS_FAILED = "FAILED";

    public static final String ERROR_MSG = "Error while calling cpc initiate cart";
    public static final String PEGA_RSPNS_FTCH_EXCPTN_STRNG = "Exception fetching response from PEGA ";
    public static final String CXP_RSPNS_PRCSS_EXCPTN_STRNG = "Exception processing cxp response ";
    public static final String CXP_RSPNS_FTCH_EXCPTN_STRNG = "Exception fetching response from CXP ";
    public static final String JSON_PRCSSNG_EXCPTN_STRNG = "Exception Processing JSON: ";
    public static final String REDIS_FORMATTED_UI_REQUEST = "UI Request after retrieving from redis: ";
    public static final String UPDATE = "UPDATE";
    public static final String CART_ID = "cartId";
    public static final String TRADE_IN = "tradein";
    public static final String MOVERS_PROCESSSTEP = "moversNextProcessStep";
    public static final String FINAL_PLAN_PRICE = "finalPlanPrice";
    public static final String COMPLETED_CARTID_CONST = "completedCartId";
    public static final String ECPD_PROFILE_ID = "ecpdId";
    public static final String PROMO_TYPE = "promoType";
    public static final String NOPROMO = "NOPROMO";
    public static final String LOGGEDINUSER = "loggedInUser";
    public static final String REMOVEOFFERREDISDATA = "removeOfferRedisData";
    public static final String CHANNEL_ID_BBP = "VZW-DOTCOM-BBP";
    public static final String CART_MTN_LIST = "cartMtnList";
    public static final String INTEND_TYPE = "intendType";
    public static final String FLOW_TYPE_WHW = "WHW_Redemption";
    public static final String FIOS_AUTHENTICATED = "fiosAuthenticated";
    public static final String AUTHENTICATED = "authenticated";
    public static final String ACTION = "action";
    public static final String ENG_US = "eng-us";
    public static final String IS_PLAN_FIRST = "planfirst";
    public static final String CDL_THROTTLE_LIST = "cdlThrottleList";
    public static final String NSA_REDIRECT_TH_PROSPECT_GW_PDP_NSA_ADD_TO_CART_ENABLE_PLAN = "NSA_REDIRECT_TH_PROSPECT_GW_PDP_NSA_ADD_TO_CART_ENABLE_PLAN";
    public static final String SOE_CART_SERVICE = "CartService";
    public static final String BYOD_LANDING_PAGE="BYODLandingPage";
    public static final String MOVERS_SELF = "MOVERSSELF";
    public static final String MOVERS_PRO = "MOVERSPRO";

    public static final String INVALID_MOVE_DATE = "Invalid MoveIn/Out Date";
    public static final String ERROR = "Error";

    public static final String SE_APLICO = "se aplicó";
    public static final String APPLIED = "Applied";
    public static final String DECLINED = "Declined";
    public static final String ADD_DEVICE_CDL_THROTTLE_LIST = "addDevicecdlThrottleList";
    public static final String BLOCKER = "BLOCKER";
    public static final String BLOCKER_CONST = "Blocker";
    public static final String CXP = "CXP";
    public static final String CASE_ID = "caseId";
    public static final String COMPLETED_CASEID_CONST = "completedCaseId";
    public static final String VERIFIED_NAME = "verifiedName";
    public static final String ACCOUNT_NUMBER = "accountNumber";
    public static final String CART_CREATOR = "cartCreator";
    public static final String PROCESSING_MTN = "processingMTN";
    public static final String INTENT = "INTENT";
    public static final String LINE_DETAILS = "lineDetails";
    public static final String MANUAL_DISCOUNT = "manualDiscount";
    public static final String ACTFEEWAIVER = "actFeeWaiver";
    public static final String ADD = "ADD";
    public static final String ADDACTFEEWAIVER = "addActFeeWaiver";
    public static final String REMOVEACTFEEWAIVER = "removeActFeeWaiver";
    public static final String SKU_ID = "skuId";
    public static final String DISCOUNT_REASON_CODE = "discountReasonCode";
    public static final String SHARED_DETAILS = "sharedDetails";
    public static final String BUY_OUT_FLAG = "buyOutFlag";
    public static final String BUY_OUT_SELECTED = "buyOutSelected";
    public static final String EDGE_UP_SELECTED = "edgeUpSelected";
    public static final String AMOUNT = "amount";
    public static final String EXCEPTION_WRITING_RESPONSE = "Exception writing response # {}";
    public static final String ACCESSORIES = "accessories";
    public static final String ACCESSORY = "accessory";
    public static final String ACCESSORY_C = "Accessory";
    public static final String FEATURES = "features";
    public static final String PAY_OFF_YOUR_DEVICE = "Pay Off Your Device";

    public static final String FEATURE = "feature";
    public static final String ACCESSORY_ID = "accessoryId";
    public static final String FEATURE_ID = "featureId";
    public static final String MSNG_FLDS_ERR_CODE = "701";
    public static final String MOBILESECUREERRORCODE = "C1001";
    public static final String ISVALIDCUSTOMERERRORCODE = "C1002";
    public static final String SL_CUSTOMER_ERROR_CODE = "C1003";
    public static final String FIVEG_ADDR_MISSING = "712";
    public static final String MISSING_FIELDS = "MISSING_FIELDS";
    public static final String ADD_DEVICE = "addDevice";
    //CLNR
    public static final String CLNR_ADD_DEVICE = "updateCLNRDevice";
    //
    public static final String SHOPPING_CART = "ShoppingCart";
    public static final String ADD_PLAN = "addPlan";
    public static final String SHIPMENT = "shipment";
    public static final String SHIPMENT_ADDRESS = "shipmentAddress";
    public static final String CHANNEL_ID = "channelId";
    public static final String CUSTOMER_ID = "customerId";
    public static final String MTN = "mtn";
    public static final String ADD_BARCODE_OFFER = "addBarCodeOffer";
    public static final String CLIENT = "client";
    public static final String DATA = "data";
    public static final String DEVICE = "device";
    public static final String SIM = "sim";
    public static final String ID = "id";
    public static final String ADD_IND = "A";
    public static final String DROP_IND = "D";
    public static final String CLIENT_APP_NAME = "clientAppName";
    public static final String CANCEL = "Cancel";
    public static final String RETRIEVE_CURRENT_FEATURES = "retrieveCurrentFeatures";
    public static final String ADD_DEVICE_REQUEST = "addDeviceRequest";
    public static final String INTENT_TOKEN_RESPONSE = "intentTokenResponse";
    public static final String IMEI = "imei";
    public static final String ICCID = "iccid";
    public static final String IMEI2 = "imei2";
    public static final String HAND_OFF_TOKEN = "handOffToken";
    public static final String TECH_CBD_INTENT = "AAL_CBD_TECH";
    //VZWCS-17115 changes
    public static final String IMSI = "imsi";
    public static final String DEVICE_REACHABLE = "deviceReachable";
    public static final String SNR_5G = "snr5G";
    public static final String CASE_MTN = "caseMtn";
    public static final String NETWORK_TYPE = "networkType";
    public static final String SETUP_REASON = "setupReason";
    public static final String POST_MOUNT_5G_SIGNAL = "postMount5GSignal";
    public static final String ADD_SERVICE_ADDRESS = "addServiceAddress";
    public static final String ADD_BILLING_ADDRESS = "addBillingAddress";
    public static final String ADD_E911_ADDRESS = "addE911Address";
    public static final String ADD_IC_DOWNPAYMENT = "addInstantCreditDownPayment";
    public static final String REMOVE_PLAN = "removePlan";
    public static final String SALES_ORDER_PURCHASE = "SalesOrderPurchase";
    public static final String SALES_ORDER_FLEX = "SalesOrderFlex";
    public static final String REMOVE_LINES = "removeLines";
    public static final String REMOVE_ITEM = "removeItem";
    public static final String REMOVE_ACCESSORY = "removeAccessory";
    public static final String ADD_ACCESSORY = "addAccessory";
    public static final String ADD_FEATURES = "addFeatures";
    public static final String MAY_BE_LATER = "mayBeLater";
    public static final String REMOVE_FEATURE = "removeFeature";
    public static final String INITIATE_CHECKOUT = "initiateCheckout";
    public static final String PROCEED_TO_ORDER = "proceedToOrder";
    public static final String ADD_BUYOUT_AMT = "addBuyOutAmt";
    public static final String ADD_EDGEUP_AMT = "addEdgeUpAmt";
    public static final String ADD_DOWNPAYMENT = "addDownPayment";
    public static final String PAST_DUE = "pastDue";
    public static final String CREATE_LINE = "createLine";
    public static final String AAL = "AAL";
    public static final String UPGRADE = "Upgrade";
    public static final String DOWNGRADE = "Downgrade";
    public static final  String promoEnd="END";
    public static final String ADD_NUMBERSHARE = "addNumberShare";
    public static final String UPDATE_DEVICESIMID = "updateDeviceSimId";
    public static final String CLEINT = "client";
    public static final String EUP = "EUP";
    public static final String BYOD = "BYOD";
    public static final String DEO = "DEO";
    public static final String ACCOUNT_GROWTH = "AccountGrowth";
    public static final String DEVICEACC = "DEVICE-ACC";
    public static final String FEATURES_PDP = "FeaturesPDP";
    public static final String FIVEGBOLT = "5GBOLT";
    public static final String ADD_FIVEGBOLT = "add5GBolt";
    public static final String FEATURES_REQUIRED = "Account & Line level features (atleast one required)";
    public static final String FEATURES_AND_SUBSCRIPTIONS = "features & mcsSubscription (atleast one required)";
    public static final String SUBSCRIPTION = "mscSubscription";
    public static final String SUBSCRIPTION_ITEMID_OR_CATID = "mscSubscription itemId or catId";
    public static final String SUBSCRIPTION_PRICEPLANID = "mscSubscription pricePlanId";
    public static final String SUBSCRIPTION_PRICE = "mscSubscription price";
    public static final String SUBSCRIPTION_NAME = "mscSubscription name";
    public static final String SUBSCRIPTION_DESCRIPTION = "mscSubscription description";
    public static final String APPLICABLE_MTNS = "mtns";
    public static final String DISCOUNT_AMT_PRCNT = "discountAmount & discountPercent (atleast one required)";
    public static final String DECODED_TOKEN = "Received decodedSSOToken";
    public static final String PAPERLESSBILLING = "paperlessBilling";
    public static final String TRADEINTYPE = "tradeInType";
    public static final String MULTI_LINE_BOGO = "Multi Line BOGO";
    public static final String MULTI_LINE_BMSM = "Multi Line BMSM";
    public static final String BICT = "BICT";
    public static final String TRADE = "Trade";
    public static final String REMOVE_OFFER = "removeOffer";
    public static final String ADD_SELLER_PRICE = "addSellerPrice";
    public static final String REMOVE_OFFERS_DETAILS = "removeOffersDetails";
    public static final String PROCESS_STEP = "processStep";
    public static final String PROCESS_ACTION = "processAction";
    public static final String PLAN = "plan";
    public static final String DEVICEID = "deviceId";
    public static final String SIMID = "simId";
    public static final String EFFECTIVE_DATE = "effectiveDate";
    public static final String PASTDUE = "pastdue";
    public static final String ASSIGN_MTN = "assignMtn";
    public static final String INTERIM_PAGE = "InterimPage";
    public static final String INTERIM = "Interim";
    public static final String EFFECTIVE_DATE_UPDATE = "EffectiveDateUpdate";
    public static final String ASSIGN_NUMBERS = "AssignNumbers";
    public static final String LINES = "lines";
    public static final String NPANXX = "npaNxx";
    public static final String DEASSIGN_MTN = "deassignMtn";
    public static final String DEASSIGN_NUMBERS = "De-assignNumbers";
    public static final String SAVE_CART = "saveCart";
    public static final String SAVE_CART_AND_QUOTES = "saveCartAndQuotes";
    public static final String ORDERREVIEW_SHIPPING = "OrderReview-Shipping";
    public static final String SELLERPRICE = "SellerPrice";
    public static final String PARSING_ERROR = "error parsing request: ";
    public static final String AAL_5G = "AAL_5G";
    public static final String PLATFORM_TYPE="Sweetener";
    public static final String FIVEGBULK = "FIVEGBULK";
    public static final String GIFT_PURCHASE_FLAG = "giftPurchaseFlag";
    public static final String CHAT_ID = "CHATID";
    public static final String ADD_CHAT_ID = "addChatId";
    public static final String CHAT_ID_FIELD = "chatId";
    public static final String OMNI_CARE = "OMNI-CARE";
    public static final String OMNI_TELESALES = "OMNI-TELESALES";
    public static final String CHANNEL_ASSISTED = "assisted";

    public static final String ASSISTED_IG_SESSION_ID = "assisted_ig_session";
    public static final String CHANNEL_DIGITAL = "digital";
    public static final String REVOKE_REBATES = "REVOKEREBATES";
    public static final String USER = "user";
    public static final String YES = "Y";

    public static final String RETAIL_SCAN_AND_GO_DEPLETION_LOCATION_CODE = "retailScanAndGoDepletionLocationCode";

    public static final String SCAN_AND_GO = "SCAN_AND_GO";
    public static final String PORTIN_LATER = "PORTINLATER";
    public static final String UPDATE_PORTIN_LATER = "PortInLater";
    public static final String ORDER_REVIEW_SHIPPING = "OrderReview-Shipping";
    public static final String VOID_ORDER = "voidOrder";
    public static final String CANCEL_ISPU = "CancelISPU-LocalOrder";
    public static final String ISPU_TO_DFILL = "ispuToDFill";
    public static final String GRIDWALLPDP = "GridWallPDP";
    public static final String MANUAL_PAIRING = "MANUALPAIRING";
    public static final String UPDATE_MANUAL_PAIRING = "Update-ManualPairing";
    public static final String SALES_REP_AND_LOCATION_CODE = "SALESREPANDLOCATIONCODE";
    public static final String UPDATE_SALES_REP = "Update-SalesRepLocation";
    public static final String SPLIT_EXCEEDED_AMOUNT = "splitExceededAmount";
    public static final String CANCEL_CASE = "cancelCase";
    public static final String VZW_ECOM = "VZW-ECOM";
    public static final String CHECKOUT = "checkOut";
    public static final String ADD_ALLOCATION_AMOUNT = "addAllocationAmount";
    public static final String NEGATIVE_BUYOUTAMT = "buyoutAmt";
    public static final String EDGEUP = "edgeup";
    public static final String NEGATIVE_EDGEUP_AMOUNT = "edgeupAmount";
    public static final String STANDALONEACCESSORY = "StandAloneAccessory";
    public static final String STANDALONE = "standalone";
    public static final String DEVICEID_VALIDATION = "deviceIdValidation";
    public static final String ADD_DEVICE_SIM = "addDeviceSim";
    public static final String MYOFFER_DATA = "myOfferData";
    public static final String RETRIEVECART_DATA = "retrieveCartData";
    public static final String CONFLICTED_SPOS = "conflictedSPOs";
    public static final String HUM_WIFI = "humWifiSFOs";
    public static final String ACC = "ACC";
    public static final String CART = "CART";
    public static final String CART_ERROR = "Cart";
    public static final String BARCODE_UNSUCCESSFUL = "Barcode validated un-successfully";
    public static final String SFO = "SFO";

    public static final String MAID = "maid";
    public static final String SPO = "SPO";
    public static final String FIVE_G_UWB_BOLT = "5GUWBBOLT";
    public static final String FIVE_G_UWB_BOLT_ADDED = "5GUWBBOLTGAIN";
    public static final String FIVE_G_UWB_BOLT_DROPPED = "5GUWBBOLTLOST";
    public static final String PAIR_TO = "PAIRTO";
    public static final String PAIR_TO_ADDED = "TABLET-DISCOUNT-ADDED";
    public static final String PAIR_TO_DROPED = "TABLET-DISCOUNT-LOST";
    public static final String PAIR_TO_DROPED_ALL = "TABLET-DISCOUNT-LOST-ALL";
    public static final String FREE_APPLE_MUSIC_LOSS = "FREEAPPLEMUSICLOST";
    public static final String DELETE_ALL_ACCESSORIES = "deleteAllAccessories";
    public static final String SMARTFAM = "SMARTFAM";
    public static final String SMARTFAM_DROPPED = "SMART-FAMILY-DROP";
    public static final String SMARTFAM_ADDED = "SMART-FAMILY-ADD";
    public static final String DISPLAY_IN_DISCOUNT_PORTAL = "DISPLAY_IN_DISCOUNT_PORTAL";
    public static final String APPLY_TO_PLAN_ACCESS = "APPLY_TO_PLAN_ACCESS";
    public static final String KIDS4LINE = "KIDS4LINE";
    public static final String FIRSTRESPD = "FIRSTRESPD";
    public static final String TEACHER = "TEACHER";
    public static final String MILITARY = "MILITARY";
    public static final String AAL_PROMO_INTERCEPT = "aalPromoIntercept";
    public static final String SETUP_LATER = "SetUpLater";
    public static final String ACTIVATE_LATER = "ACTIVATELATER";
    public static final String DISNEY_ENROLLED_SPOID = "1640";
    public static final String FIVEG_UPSELL = "isfiveGUpSellSelected";
    public static final String PASTDUEBALANCE = "mdnselection/pastdue.html";
    public static final String DPPSUMMARY = "dppagreement.html";
    public static final String TWOYEARUPGRADE = "earlytwoyearagreement.html";
    public static final String MTNSELECTIONPAGE = "mdnselection.html";
    public static final String GENERIC_ERROR = "error/genericError.html";
    public static final String ITEM_TYPE = "itemType";
    public static final String DEVICE_ACCESSORY = "Device/Accessory";
    public static final String ADD_ACCESSORY_REQUEST = "addAccessoryRequest";
    public static final String MTN_SELECTION_PAGE = "MTNSelectionPage";
    public static final String GRIDWALL_PDP = "GridWallPDP";
    public static final String ADD_FEATURES_REQUEST = "addFeaturesRequest";
    public static final String MYOFFER_ETR_DATA = "myOfferVzUpETRData";
    public static final String SP = "SP";
    public static final String SR = "SR";
    public static final String ST = "ST";
    public static final String TR = "TR";
    public static final String BG = "BG";
    public static final String BM = "BM";
    public static final String EQP = "EQP";
    public static final String RESTRICTED_PRODUCT_TYPE = "restrictedProductType";
    public static final String DEVICE_DOLLARS = "DEVICE_DOLLARS";
    public static final String VALIDATE_DEVICE_SIM_ID_PAGE = "ValidateDeviceSimIdPage";
    public static final String MTN_TO_PLANID_MAP = "mtnToPlanIdMap";
    public static final String MTN_TO_LOAN_STATUS_MAP = "mtnToLoanStatusMap";
    public static final String ONE_CLICK_CHECKOUT = "oneClickCheckout";
    public static final String PROMOHUB_SPOKE_JOURNEY = "spokeJourney";
    public static final String ACCESSORIES_INTERSTIAL = "AccessoryInterestial";
    public static final String DEVICE_COUNT = "deviceCount";
    public static final String CART_HAS_PCD = "cartHasPCD";
    public static final String DEVICE_BEST_VALUE_OFFER_DATA = "deviceBestValuePromoData";
    public static final String BVP_ACCEPTED = "81";
    public static final String BVP_VIEW = "82";
    public static final String BVP_REJECTED = "83";
    public static final String COMPLIANCE_TYPE = "ComplianceType";
    public static final String MMTIER = "mtier";
    public static final String MYOFFER = "OFFERS";
    public static final String PLAN_SELECTION = "PlanSelection";

    public static final String SORTED_STEPS = "sortedSteps";

    public static final String DEVICE_SELECTION_STEP = "deviceSelection";
    public static final String FEATURES_SELECTION_PAGE = "FeatureSelectionPage";
    public static final String CPC = "CPC";
    public static final String VZW_DOTCOM = "VZW-DOTCOM";
    public static final String FEATURES_RESPONSE = "featuresResponse";
    public static final String REMOVE_LINES_SUCCESS = "Lines Deleted Succesfully!";
    public static final String EXIT_PAGE = "ExitPage";
    public static final String CLEAR_ITEMS = "CLEARITEMS";
    public static final String CLEAR = "Cancel";
    public static final String REMOVE_DEVICE = "removeDevice";
    public static final String REMOVE = "REMOVE";
    public static final String REMOVE_DEVICE_SUCCESS = "Device has been removed successfully..";
    public static final String INELIGIBLE_UPGRADE_LINES = "ineligibleUpgradeLines";
    public static final String HUMAN = "human";
    public static final String TRANSFER_UPGRADE = "TransferUpgrade";
    public static final String COMPLETE_TRANSFER = "completeTransfer";
    public static final String ALTERNATEUPGRADE = "ALTERNATEUPGRADE";
    public static final String CANCEL_TRANSFER_UPGRADE = "cancelTransferUpgrade";
    public static final String TRANSFER_FROM = "transferFrom";
    public static final String CANCEL_EDGE_UP = "cancelEdgeUp";
    public static final String DONOR_MTN = "donorMtn";
    public static final String RECIPIENT_MTN = "recipientMtn";
    public static final String FIVEG_HOME = "5GHome";
    public static final String ORDER_INFORMATION = "ORDERINFORMATION";
    public static final String ADD_NICK_NAME = "addNickName";
    public static final String INACTIVE = "Inactive";
    public static final String PROMO_HUB = "PromoHub";
    public static final String MYOFFER_HEXPLAN_INFO = "myOfferHexPlanInfo";
    public static final String MTN_LIST = "mtnList";
    public static final String EUPBYOD = "EUPBYOD";
    public static final String BUYSIM = "BUYSIM";
    public static final String UPDATE_BARCODE = "updateBarcode";
    public static final String CART_ORDER_FLOW_TYPE = "cartOrderFlowType";
    public static final String CART_COUNT = "cartCount";
    public static final String MTN_FLOW = "mtnFlow";
    public static final String FIVEG_ADDRESS = "fiveGAddress";
    public static final String DEVICE_SOR_ID = "deviceSorId";
    public static final String PLAN_SOR_ID = "planSorId";
    public static final String THROTTLE_LIST = "throttleList";
    public static final String EXPRESS = "express ";
    public static final String VZW_ROLES = "vzwRoles";
    public static final String ROLE = "role";
    public static final String IS_VALID_CUSTOMER = "isValidCustomer";
    public static final String W_AAL = "w/aal";
    public static final String W_EUP = "w/eup";
    public static final String EXPRESS_EUP = "express eup";
    public static final String EXPRESS_AAL = "express aal";
    public static final String EUP_W_AAL = "eup w/aal";
    public static final String AAL_W_EUP = "aal w/eup";
    public static final String S_AAL = "aal";
    public static final String S_EUP = "eup";
    public static final String DEVICE_CATEGORY_NAME = "deviceCategoryName";
    public static final String DEVICE_PRODUCT_ID = "deviceProductId";
    public static final String DEVICE_PROD_ID = "deviceProdId";
    public static final String LOCATION_CODE = "ORDERLOC";
    public static final String VALIDATION_ERROR = " REQUEST VALIDATION ERROR";

    public static final String SKU_NOT_AVAILABLE_ERROR = "SKU NOT AVAILABLE";
    public static final String ACCOUNT_INFO_VALIDATE = "accountInfoValidate";
    public static final String ACCESSORY_SOR_ID = "accessorySorId";
    public static final String NSO = "nso";
    public static final String ESO = "eso";
    public static final String NAO = "nao";
    public static final String ACCESSORY_CATEGORY_NAME = "accessoryCategoryName";
    public static final String CRADLE_FLOW_JOURNEY = "cradleFlowJourney";
    public static final String ONE_CLICK_CHECKOUT_FOR_ACCESSORY = "oneClickCheckoutForAccessory";
    public static final String ACCESSORY_PRODUCT_ID = "accessoryProductId";
    public static final String EXPRESS_FLOW_FOR_ACCESSORY = "expressFlowForAccessory";
    public static final String ACCESSORY_COUNT_LIST = "accessoryCountList";
    public static final String WFM_ORDER_INFO = "WFMORDERINFO";
    public static final String READ_ORDER_PAGE = "ReadOrderPage";
    public static final String UPDATE_WFM = "updateWFM";
    public static final String DP_CHANGED = "DP_CHANGED";
    public static final String DP_INELIGIBLE = "DP_INELIGIBLE";
    public static final String DP_INELIGIBLE_MSG = "Based on your credit history, you'll need to pay the full retail price on your order.";
    public static final String PENDING_EQUIPMENT_ERROR_MSG1 = "This device has a pending equipment order for a different MTN ";
    public static final String PENDING_EQUIPMENT_ERROR_MSG2 = ", process a refund or stand alone RPC if its not needed anymore.";
    public static final String PENDING_LOAN_ERROR_MSG = "Device already has current or pending loan";
    public static final String RETURNED_EQUIPMENT_ERROR_MSG = "This device has a return order being processed for this account. Please process a provision id to reprocess the same device.";

    public static final String SIMID_ALREADY_MAPPED_ERROR_MSG = "Entered SIM is already mapped with";
    public static final String MTN_TYPE_PREPAY_TO_POSTPAY = "preToPostPay";
    public static final String DP_CHANGED_MSG = "Based on your credit history, you'll need to make a down payment on your order which will reduce your monthly payments.";
    public static final String DP_CHANGED_MSG_5G = "<div><h1>So based on your credit, you will need to pay $#price# today.</h1> <div class='margin18 noSideMargin fontSize_5'>" +
            "By paying this amount upfront, you'll pay $#monthlyPrice# less towards your equipment each month. </div></div>";
    // Plan change warning message related code
    public static final String CLOUD_STORAGE_DROPPED_KEY = "CLOUD_STORAGE_DROPPED_KEY";
    public static final String CLOUD_STORAGE_DROPPED_AUTO_ENROLLED_KEY = "CLOUD_STORAGE_DROPPED_AUTO_ENROLLED_KEY";
    public static final String ECPD_DISCOUNT_NOT_CARRY_OVER_KEY = "ECPD_DISCOUNT_NOT_CARRY_OVER_KEY";
    public static final String ECPD_KIDS_DISCOUNT_NOT_CARRY_OVER_KEY = "ECPD_KIDS_DISCOUNT_NOT_CARRY_OVER_KEY";
    public static final String APPLE_MUSIC_NEW_MEXICO_BILLING_KEY = "APPLE_MUSIC_NEW_MEXICO_BILLING_KEY";
    public static final String APPLE_MUSIC_BILLING_KEY = "APPLE_MUSIC_BILLING_KEY";
    public static final String MPP_PAIRED_PHONE_DISCOUNT_KEY = "MPP_PAIRED_PHONE_DISCOUNT_KEY";
    public static final String DISNEY_PLUS_DROPPED_KEY = "DISNEY_PLUS_DROPPED_KEY";
    public static final String DISNEY_BUNDLE_DROP_KEY = "DISNEY_BUNDLE_DROP_KEY";
    public static final String ECPD_ID_MILITARY = "3186257";
    public static final String ECPD_ID_FIRST_RESPONDER = "4769885";
    public static final String ECPD_ID_EMPLOYEE = "815125";
    public static final String HEX_CATEGORY = "67";
    public static final String ABOVE_UNLIMITED_PLAN = "17994";
    public static final String CLOUD_STORAGE_SFO = "86211";
    public static final String APPLE_MUSIC_INCLUDED_SPO = "1464";
    public static final String APPLE_MUSIC_SUBSCRIPTION_SPO = "1381";
    public static final String VZ_VIDEO = "VZVIDEO";
    public static final String NEW_MEXICO = "NM";
    public static final String MPP_LOSS_MSG_FOR_START_PLANS = "26907,26911,26926,39385,39387,39390"; // play more unlimited(269070, do more unlimited(26911), get more unlimited(26926)
    public static final String MPP_LOSS_MSG_SELECTED_PLAN = "26872";
    public static final String FIVE_G_UWB_LOSS_KEY = "5G_UWB_LOSS_KEY";
    public static final String ENFORCE_KIDS_PLAN_KEY = "ENFORCE_KIDS_PLAN_KEY";
    public static final String JUST_KIDS_PROMO_LOSS_KEY = "JUST_KIDS_PROMO_LOSS_KEY";
    public static final String KIDS_PLAN_SOR_COLLECTION_CODE = "VPMET";
    public static final String HEX_PLAN_SOR_COLLECTION_CODE = "VPUNL";
    public static final String HEX_PLAN_SOR_CATEGORY_CODE = "67";

    public static final String RPS_INTENT = "rpsIntent";

    public static final String RETAIL_IPAD = "OMNI-RETAIL-TAB";

    public static final String SAVE_FOR_LATER = "saveForLater";
    public static final String DELETE_SAVE_FOR_LATER = "deleteSaveForLater";
    public static final String REMOVE_SAVE_FOR_LATER = "removeSaveForLater";

    public static final String PRE_CONFIGURE = "preconfigure";
    public static final String PRE_CONFIGURED = "Preconfigured";
    public static final String CLEAR_CART = "CLEARCART";
    public static final String CLEAR_ALL = "ClearAll";
    public static final String REQUEST_VALIDATION_ERROR = "REQUEST_VALIDATION_ERROR";
    public static final String SL_CUSTOMER_ERROR = "SL Customers are not allowed";
    public static final String EXPRESS_STORE = "EXPRESS_STORE";
    public static final String DIGITAL = "digital";
    public static final String ASSISTED = "assisted";
    public static final String ADD_ACCESSORY_AND_CHECKOUT = "addAccessoryAndCheckout";

    public static final String INTERNAL_SERVER_ERROR = "Internal Server Error";
    public static final String EXCEPTION_ERROR_CODE = "500";
    public static final String EXCEPTION = "Exception";

    public static final String RPS_FLOW_PAIRING_MODE = "rpsFlowPairingMode";
    public static final String RPS_FLOW_IMEI = "rpsFlowIMEI";
    public static final String RPS_FLOW_PHONE_MTN = "rpsFlowPhoneMtn";
    public static final String RPS_FLOW_TRANSACTION_ID = "transaction-id";
    public static final String RPS_FLOW_SERVICE_CODE = "service-code";
    public static final String RPS_FLOW_TOKEN = "token";
    public static final String RPS_FLOW_PRIMARY_DEVICE_MDN = "primary-device-mdn";
    public static final String RPS_FLOW_ASSOCIATED_SUBSCRIPTION = "associated-subscription";
    public static final String RPS_FLOW_ESIM_DOWNLOAD_DELAY = "esim-download-delay";
    public static final String RPS_FLOW_DEVICE_USER_AGENT = "device-user-agent";
    public static final String RPS_FLOW_ASSOCIATED_SUBSCRIPTION_TWO = "2";
    public static final String RPS_FLOW_NUMBERSHARE = "numbershare";
    public static final String RPS_FLOW_STANDALONE = "standalone";
    public static final String RPS_USER_FLOW = "rpsUserFlow";
    public static final String RPS_OS_TYPE = "rpsOsType";
    public static final String RPS_DEVICE_MFG = "rpsDeviceMfg";
    public static final String VZW_RPS = "VZW-RPS";
    public static final String FALSE = "false";
    public static final String TRUE_FLAG = "true";

    public static final String FLORIDA_RINGBELL_EXCEPTION = "3246";
    public static final String FEA = "FEA";
    public static final String MOBILE_SECURE = "mobileSecure";
    public static final String ACCOUNT_MEMBER = "accountMember";
    public static final String KEEP_PLAN = "keepPlan";
    public static final String CONFIRMATION = "Confirmation";
    public static final String ENTERTAINMENT = "ENTERTAINMENT";

    public static final String STORE_LOCATION_STATE = "storeLocationState";
    public static final String BILLING_STATE = "billingState";
    public static final String CUSTOMER_ADDRESS_STATE = "customerAddressState";
    public static final String LINELEVEL_DIGITALSECURE_SUBSCRIPTION_COUNT = "lineLevelDigitalSecureSubscriptionCount";

    public static final String NY = "NY";
    public static final String PROTECTING_DIGITAL_SECURE_MORE_THAN_2_LINES_OUTSIDE_NY = "Protecting 3 or more lines requires an upgrade to the account-level subscription for billing address outside of NY.";
    public static final String PROTECTING_DIGITAL_SECURE_MORE_THAN_2_LINES_NY_CUSTOMER = "Protecting 3 or more lines with Digital Secure NY requires an upgrade to the account level subscription.";
    public static final String DIGITAL_SECURE_SUBSCRIPTION_ITEM_ID_LL = "307355196";
    public static final String DIGITAL_SECURE_SUBSCRIPTION_ITEM_ID_AL = "307462196";
    public static final String DIGITAL_SECURE_LL = "Billing address outside of NY will be charged $5.00/month.";
    public static final String DIGITAL_SECURE_AL = "Billing address outside of NY will be charged $10.00/month.";
    public static final String RTD_KEY = "RTD_JSON";
    public static final String MYOFFERS = "MYOFFERS";
    public static final String UPGRADE_FEE = "UPGRADE_FEE";

    public static final String ITEMTYPE_ACCESSORY = "ACCESSORY";
    public static final String ACCESSORY_BONUS_OFFER = "Accessory-Bonus-Offer";


    public static final String REFUND_EXCHANGE = "REX";
    public static final String CLNR_FLOW = "CLNR";
    public static final String CONTRACT_CHANGE = "CCH";
    public static final String EXCHANGE = "EXC";
    public static final String SALES_ORDER_ADJUSTMENT = "SalesOrderAdjustment";
    public static final String NEW_CUSTOMER = "N";
    public static final String NSE = "NSE";
    public static final String NSE_BYOD = "NSEBYOD";
    public static final String NSE_5G = "NSE_5G";
    public static final String FIVEG_INTERNET = "5G Internet";
    public static final String EPP_RESTRICTIONS = "3261";
    public static final String EPP_RESTRICTIONS2 = "3263";
    public static final String EDGE_BUYOUT_KEY = "edgeBuyoutRequest";
    public static final String INDIVIDUAL = "Individual";
    public static final String PLAN_OVERAGE_BACKDATE_MSG = "Choosing the current date will result in overage due to unbilled usage and proration. Recommend picking back date";
    public static final String PLAN_OVERAGE_FUTUREDATE_MSG = "Choosing the current date will result in overage due to unbilled usage and proration. Recommend picking future date";
    public static final String EMPTY_STRING = "";
    public static final String STATUS_UPDATE = "STATUS-UPDATE";

    public static final String BBP_IMEI = "bbpimei";
    public static final String BBP_ICCID = "bbpiccid";
    public static final String IS_SMARTPHONE = "isSmartphone";
    public static final String BBP_IMEI2 = "bbpimei2";
    public static final String IS_ESIMDEVICE = "isEsimDevice";
    public static final String BBP_FLOWTYPE = "bbpFlowType";
    public static final String BBP_DEFAULT_ZIPCODE_FOR_TABLETFLOW = "bbpDefaultZipcodeForTabletFlow";
    public static final String BBP_SDKDEVICE_FIRSTNAME = "bbpSDKDeviceFirstName";
    public static final String BBP_SDKDEVICE_LASTNAME = "bbpSDKDeviceLastName";
    public static final String BBP_SDKDEVICE_PHONENUMBER = "bbpSDKDevicePhoneNumber";
    public static final String BBP_SDKDEVICE_EMAIL = "bbpSDKDeviceEmail";
    public static final String BBP_SDKDEVICE_ZIPCODE = "bbpSDKDeviceZipcode";
    public static final String BBP_DEVICESIMVALIDATION_FLAG = "isDeviceSimValidationAPISuccess";
    public static final String IS_SDKDEVICE = "isSDKDevice";
    public static final String ESIMTYPE = "esimType";
    public static final String ESIMFLOWTYPE = "esimFlowType";
    public static final String PENDING_ORDER = "PendingOrder";
    public static final String ALREADY_ACTIVATED = "AlreadyActivated";
    public static final String LOST_ICCID_PROFILE = "LostICCIdProfile";
    public static final String ACTIVATION = "Activation";
    public static final String PENDING_MDN = "pendingMdn";
    public static final String PENDING_ICCID = "pendingiccid";

    public static final String BBP_ZIPCODE = "bbpZipcode";
    public static final String VZW_BBP = "VZW-DOTCOM-BBP";
    public static final String INTENT_TYPE = "intentType";
    public static final String IS_APPLEDEVICE = "isAppleDevice";
    public static final String TRIAL_ADDRESS = "TRIALADDRESS";
    public static final String COOKIE_ECPD_TOKEN = "ecpdcookie";
    public static final String COOKIE_ECPD_DOMAIN = "domainCookie";
    public static final String COOKIE_SALESREPID = "RepIdCookieText";
    public static final String COOKIE_REFERRAL_VENDOR = "AFFILIATE";
    public static final String ADDACCOUNTPIN = "addAccountPIN";
    public static final String ACCOUNTINFO_ORDERREVIEW = "AccountInfo/OrderReview";
    public static final String API_ERROR = "API_ERROR";
    /*
     * https://onejira.verizon.com/browse/NSADT-55837-fix for the user id
     */
    public static final String DEFAULT_USER_ID = "nsa_tester";
    public static final String FLEX = "Flex";
    public static final String ITEM_DETAILS = "itemDetails";
    public static final String ITEM_CODE = "itemCode";
    public static final String QTY = "quantity";
    public static final String REFUND_TYPE = "refundType";
    public static final String RETURN_TYPE = "returnType";
    public static final String USERCONTACTINFO = "USERCONTACTINFO";

    public static final String CREDIT_APP_NUM = "creditAppNum";


    public static final String RING_LAUNCHPACKAGESKU = "4K11V90ENV";
    public static final String GIZMO_LAUNCHPACKAGESKU = "QTAX53B,QTAX53P,QTAX53SEB,QTAX53SEPU,ZW20P,ZW20B";

    public static final String RING_PRODNAME = "ring";
    public static final String TRACKER_PRODTYPE = "4G_LOCATOR";
    public static final String PHONE = "phone";
    public static final String TABLET = "Tablet";
    public static final String DEVICETYPE_PHONE = "PHONE";
    public static final String DEVICETYPE_TABLET = "TABLET";
    public static final String DEVICETYPE_RING = "RING_DEVICE";
    public static final String DEVICETYPE_TRACKER = "TRACKER_DEVICE";
    public static final String DEVICETYPE_GIZMO = "GIZMO_DEVICE";
    public static final String DEVICETYPE_GARMIN = "GARMIN_DEVICE";
    public static final String DEVICETYPE_BBP = "bbpDeviceType";
    public static final String EXISTING_CUSTOMER = "EXISTINGCUSTOMER";
    public static final String HOST_NAMES_REGEX = "verizon.com|verizonwireless.com|vzwqa1.verizonwireless.com|vzwqa2.verizonwireless.com|vzwqa3.verizonwireless.com|vzwqa4.verizonwireless.com|vzwqa5.verizonwireless.com|vzwqa6.verizonwireless.com|vzwqa7.verizonwireless.com|vzwqa8.verizonwireless.com";
    public static final String TABLET_DEVICE_CATEGORY = "tablet.devicecategory.list";

    public static final String FMI_CHECK = "FMIcheck";
    public static final String FMI_OVERRIDE = "FMI-OVERRIDE";

    public static final String BBP_INTENT_ORDERSELFSERVICE = "vzw.intent.OrderStatusSelfService";
    public static final String DEVID = "devid";
    public static final String EID = "eid";
    public static final String CHAT_STORE = "CHAT-STORE";
    public static final String QUOTE_PRICING = "quotePricingValues";
    public static final String VALIDATE_ORDER_KEY = "voKey";

    public static final String CUST_TYPE = "custType";
    public static final String VISION_CUSTTYPE_PE = "PE";
    public static final String VISION_CUSTTYPE_BE = "BE";
    public static final String VISION_CUSTTYPE_ME = "ME";
    public static final String CUST_TYPE_B2C = "B2C";
    public static final String CUST_TYPE_B2E = "B2E";
    public static final String CUST_TYPE_EPP = "EPP";
    public static final String CUST_TYPE_SL = "SL";
    public static final String REX = "REX";
    public static final String INTENDTYPE = "intendType";
    public static final String INTENTTYPE = "intentType";
    public static final String CASEID = "caseId";
    public static final String CARTID = "cartId";
    public static final String WISHLIST_FLOW = "wishListFlow";
    public static final String BYOD_FLOW_CHECKOUT = "byodFromCheckout";

    // 5G constants

    public static final String PROF_SETUP = "Professional SetUp";
    public static final String SELF_SETUP = "Self SetUp";
    public static final String FIVEG_HOME_QUALIFIED = "fiveGHomeQualified";
    public static final String LTE_HOME_QUALIFIED = "LTEQualified";
    public static final String LAUNCH_TYPE = "launchType";
    public static final String ADDRESS_TYPE = "addressType";
    public static final String INSTALL_TYPE = "installType";
    public static final String EVENTCORRELATIONID = "eventCorrelationId";
    public static final String ADDRESSLINE1 = "addressLine1";
    public static final String ADDRESSLINE2 = "addressLine2";
    public static final String CITY = "city";
    public static final String STATE = "state";
    public static final String ZIPCODE = "zipCode";
    public static final String LONGITUDE = "longitude";
    public static final String LATITUDE = "latitude";
    public static final String FLOOR_NUMBER = "floor";
    public static final String LTEHOMESKU = "LTEHomeSku";
    public static final String BUILDING_ID = "buildingId";
    public static final String BUNDLENAME = "bundleName";
    public static final String BUNDLEID = "bundleId";
    public static final String BUNDLE_TYPE = "bundleType";
    public static final String LTE_ACTION_INDICATOR = "Z";
    public static final String LTE_CONTRACT_TERM = "VERIZON_EDGE";
    public static final String LTE_FRP_PRICETYPE = "FRP";
    public static final String LTE_DPP_PRICETYPE = "DPP";
    public static final String FIVEG_CONTRACT_TERM = "MONTH_TO_MONTH";
    public static final String LAUNCHTYPE_FCL = "FCL";
    public static final String LAUNCHTYPE_4GH = "4GH";
    public static final String FIPS_CODE = "fipsCode";
    public static final String ITEMTYPE_PLAN = "PLAN";
    public static final String ITEMTYPE_SUBSCRIPTION = "SUBSCRIPTION";
    public static final String ITEMTYPE_PROTECTION = "PROTECTION";
    public static final String COVID_QUES_ANSWERED = "covidQuestionareAnswered";
    public static final String INTENT_EUP_LTE = "EUP_LTE";
    public static final String LTE_UPGRADE_SKU = "ASK-NCQ1338";
    public static final String IS_REDESIGN_FLOW = "redesignFlow";
    public static final String MOVERS_SELF_SETUP = "Self setup";

    //5g pega constants

    public static final String BPM_SALES_ORDER_PURCHASE = "SalesOrderPurchase";
    public static final String MOVERS_SERVICE_NAME = "Movers";
    public static final String BPM_PEGA_GENERATED_MESSAGE = "PEGA generated message";
    public static final String FIVEG_THROTTLE_NAME = "HOMESAFETY_TRIAL_WITHOUT_MTNS";


    public static final String ESIM_IPAD_DACCS = "esim.ipad.daccs";
    public static final String ESIM_LAPTOP_DACCS = "esim.laptop.daccs";
    public static final String IPAD = "IPAD";
    public static final String LAPTOP = "LAPTOP";
    public static final String SMARTPHONE = "PHONE";
    public static final String IS_PROPSECT = "isProspect";
    public static final String ESIM_PHONE_DACCS = "esim.phone.daccs";
    public static final Boolean TRUE = true;
    public static final String MANAGE_ACCOUNT = "MANAGEACCOUNT";
    public static final String IN_FLIGHT_ORDER = "inFlightOrder";
    public static final String FWA_IN_FLIGHT_ORDER = "fwaInFlightOrder";
    //PSTGRO-6849
    public static final String EBB_WARNING_COMBO = "By switching plans, you'll lose your discount.You are currently receiving a promotional discount based on your current plan. Switching will end this discount at the end of your next bill cycle. In addition, you are currently receiving a temporary Emergency Broadband discount. By switching plans, you will lose that discount.";
    //PSTGRO-6578
    public static final String EBB_WARNING_NONCOMBO = "You are currently receiving a temporary Emergency Broadband discount. By switching plans, you will lose that discount.";
    public static final String EMERGENCY_BROADBAND_DISCOUNT_SPO_1946 = "1946";
    public static final String EMERGENCY_BROADBAND_DISCOUNT_SPO_1945 = "1945";
    public static final String EBB_DISCOUNT_KEY = "EBB_DISCOUNT_KEY";

    public static final String ADD_MANUAL_DISCOUNT = "addManualDiscount";
    public static final String ADD_EFFECTIVE_DATE = "addEffectiveDate";
    public static final String IS_PRE_QUALIFIED_NBX = "isPreQualifiedNBX";

    public static final String STATUS_SUCCESS = "Success";
    public static final String MYLINK_COOKIE_REP_ID_COOKIE_TEXT = "MyLinkAgentSiteId";
    public static final String MYLINK_COOKIE_MY_LINK_AGENT_SITE_ID = "MyLinkAgentSiteId";
    public static final String MYLINK_COOKIE_MY_LINK_AGENT_OUTLET_ID = "MyLinkAgentOutletId";

    public static final String CHANNEL_ID_NUMBERLINK = "VZW-NUMBERLINK";
    public static final String ORDERSUBMIT = "OrderSubmit";
    public static final String ACCESSORIES_INTERSTIAL_PROSPECT = "AccessoryInterestialProspect";

    public static final String BYOD_ESIM_FLOW = "byodEsimFlow";
    public static final String BYOD_DEVICE_SOR_DISPLAYNAME = "byodDeviceSorDisplayName";

    public static final String EXTERNAL_ID = "externalid";
    public static final String VZID = "vzId";
    public static final String GIG = "gig";
    //esim byod
    public static final String DEVICE_CATEGORY_SMARTPHONE = "Smartphone";

    public static final String DEVICE_CATEGORY_TABLET = "Tablet";
    public static final String DEVICE_CATEGORY_SMARTWATCH = "Connected Devices";
    public static final String ESIM_MODEL_NAME = "eSIM";
    public static final String ESIM_INDICATOR_2 = "-2";
    public static final String PREPAID_MODEL_NAME = " PP";
    public static final String ESIM_INDICATOR = "-E";
    public static final String ESIM_SKU = "esimSKU";
    public static final String PSIM_SKU = "psimSKU";
    public static final String NSE_BYOD_LANDING = "NSEBYODLanding";
    public static final String BYOD_SIMID_PAGE = "BYODSimIDPage";
    public static final String ESIM = "eSim";
    public static final String PSIM = "pSim";
    public static final String VERIZON = "VERIZON";
    public static final String ATT = "AT&T";
    public static final String SPRINT = "SPRINT";
    public static final String TMOBILE = "T-MOBILE";
    public static final String OTHER = "OTHER";
    public static final String IPHONE_13 = "iPhone 13";

    //Abandon cart constants
    public static final String LAST_DEVICE_PROD_ID = "dev_prod_id";
    public static final String LAST_DEVICE_SOR_ID = "dev_sor_id";
    public static final String NAME = "name";
    public static final String MAKE = "make";
    public static final String CATEGORY_ID = "categoryId";
    public static final String CONTRACT_TERM = "contractTerm";
    public static final String DEVICE_IMAGE_URL = "img";
    public static final String PLAN_ID = "plan_id";
    public static final String LAST_ACC_PROD_ID = "acc_prod_id";
    public static final String LAST_ACC_SOR_ID = "acc_sor_id";
    public static final String ACC_IMAGE_URL = "acc_img";
    public static final String ACC_NAME = "acc_name";
    public static final String CDL_CART_INFO = "cdlCartInfo";

    public static final String SMARTPHONES = "smartphones";
    public static final String SMARTPHONE_SINGULAR = "smartphone";
    public static final String TABLETS_LOWERCASE = "tablets";

    public static final String TABLETS_SINGULAR = "tablet";
    public static final String BASICPHONE = "basic";
    public static final String ACC_URL = "acc_url";
    public static final String ACC_CATEGORY_ID = "acc_categoryId";
    public static final String RTM_SESSION_ID = "sessionId";
    public static final String ABANDON_CART = "abandonCart";
    public static final String CART_TYPE = "carttype";

    public static final String LOST_ACC_SOR_ID = "lostAccessorySorId";
    public static final String Z1_OFFER_CODE = "z1OfferCode";
    public static final String Z1_OFFER_CODE_APPLIED = "z1OfferApplied";
    public static final String OMNI_INDIRECT = "OMNI-INDIRECT";
    public static final String UPG_FEE = "UPGRADEFEE";
    public static final String SAFETECH_SESSION_ID = "safeTechSessionId";

    public static final String CDL_CART_TYPE = "cdlCartType";
    public static final String EMAIL_ADDRESS = "prEmailId";/*MVP2*/
    public static final String CBR = "cbr";
    public static final String DIGITAL_IG_SESSION = "digital_ig_session";
    public static final String ADDRESS_REQUEST = "addressRequest";

    public static final String D2D_LOCATION_CODE = "locationId";
    public static final String OUTLET_ID = "outletId";
    public static final String VENDOR_ID = "vendorId";
    public static final String IS_D2D_FLOW = "isD2DFlow";
    public static final String MUC_ELIGIBLE_FLAG = "fiveGMUCEligible";
    public static final String CREDIT_CHECK_FAILURE_COUNTER = "creditCheckFailedCount";
    public static final String CREDIT_CHECK_FAILURE_RESPONSE = "creditCheckMaxAttemptedFailure";
    public static final String FLOW_TYPE_NUMBERLINK = "NUMBERLINK_NEW";
    public static final String FLOW_TYPE_NUMBERLINK_MODIFY = "NUMBERLINK_MODIFY";
    public static final String SUCCESS_URL = "successUrl";
    public static final String EXTERNALID = "externalid";

    public static final String SAMSUNG = "SAMSUNG";
    public static final String MOTOROLA = "MOTOROLA";
    public static final String SONY = "SONY";
    public static final String IPHONE = "IPHONE";
    public static final String SAMSUNG_DEVICENAME = "Samsung";
    public static final String MOTOROLA_DEVICENAME = "Motorola";
    public static final String SONY_DEVICENAME = "Sony";
    public static final String IPHONE_DEVICENAME = "iPhone";

    public static final String INTENT_REDIS = "intent";
    public static final String PSIM_SUBFLOW = "psim";

    public static final String ESIM_INSTANT_ACTIVATION_SUBFLOW = "esim";

    public static final String ESIM_LATER_ACTIVATION_SUBFLOW = "esimltr";

    public static final String INSTANT_SUBFLOW = "instant";
    public static final String VZPH_REMOVED = "vzphRemoved";
    public static final String CART_ID_MISSING = "Cart ID is missing";
    public static final String CART_ID_MISSING_CODE = "1008";
    public static final String CDE_STD_PLAN_OFFR_TYPE_GRP_NO = "0000000015";
    public static final String CDE_VPC_PLAN_OFFR_TYPE_GRP_NO = "0000000002";
    public static final String AUTO_PAY_ENROLLED = "autoPayEnrolled";
    public static final String FIFTY_PERCENT_DISC_DROP_FEATUE_CODE = "1465";
    public static final String AUTOPAY_DISC_DROP_FEATUE_CODE = "1247";
    public static final String NSE_LTE = "NSE_LTE";/*MVP2*/
    public static final String AAL_LTE = "AAL_LTE";/*MVP2*/
    public static final String FLOW_TYPE_NUMBERLINK1 = "NUMBERLINK";
    public static final String IVR = "IVR";
    public static final String PROMO_MAX_COUNT = "promoMaxCount";
    public static final String PROMO_VALID_MAX_COUNT = "promoValidMaxCount";
    public static final String SERVICE_NAME_NUMBERLINK = "NumberLink";
    public static final String PROTECTION_VERSION = "protectionVersion";
    public static final String AUTOPAY_LOST = "AUTOPAY_LOST";
    public static final String AUTOPAY_GAIN = "AUTOPAY_GAIN";
    public static final String AUTOPAY = "AUTOPAY";
    public static final String CHANNEL = "channel";
    public static final String UNDEFINED = "undefined";
    public static final String RING = "RING";
    public static final String GARMIN = "GARMIN";
    public static final String TRACKER = "TRACKER";
    public static final String SDK_RING_DACCS = "sdk.ring.daccs";
    public static final String SDK_GARMIN_DACCS = "sdk.garmin.daccs";
    public static final String SDK_TRACKER_DACCS = "sdk.tracker.daccs";
    public static final String SDK_GIZMO_DACCS = "sdk.gizmo.daccs";
    public static final String PORT_IN = "portIn";
    public static final String EMAIL_ID_REGEX = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
    public static final String D2D_POS_AGENTID = "d2dPosAgentID";
    public static final String NSE_NEW_LINE = "nse/new-line";
    public static final String EXCBYOD = "EXCBYOD";
    public static final String PROSPECT_CART_COUNT = "prospectCartCount";
    public static final String EXISTING_CART_COUNT = "gnCartCount";
    public static final String PROCESS_STEP_MTN_SELECTION_PAGE = "MTNSelectionPage";
    public static final String EXISTING_CASE = "existingCase";
    public static final int ERROR_ID_INT = 412;
    public static final int SUCCESS_ID_INT = 200;
    public static final String SOE_SERVICE_NAME = "onevz-soe-cart-service";
    public static final String ERROR_ID = "R1001";
    public static final String ERROR_NAME = "Precondition Failed";
    public static final String INFORMATION_LINK = "/sales/digital/expressCheckout.html?pageName=cart";
    public static final String NSEACC = "NSEACC";
    public static final String VZW_MFA = "VZW-MFA";
    public static final String ORIGINATING_CLIENT_IP = "OriginatingClientIp";
    public static final String CLIENT_IP = "clientIp";
    public static final String ICONIC_TEST_INTENT = "iconicTestIntent";
    public static final String UUID = "uuid";
    public static final String IS_PROSPECT = "isProspect";
    public static final String IS_DIRECT_APPLY = "isDirectApply";
    public static final String REP_ID = "repId";
    public static final String STORE_NAME = "storeName";
    public static final String ICONIC_TEST_INTENT_FROM_CRADLE = "iconicTestIntentFromCradle";
    //5G-Upgrade
    public static final String EUP_5G_REPAIR = "EUP_5G_REPAIR";
    public static final String EUP_5G_BUNDLE = "BUNDLE";
    public static final String EUP_5G_PROF_SETUP = "5GHomeGeminiProfSetup";
    public static final String EUP_5G_CUSTOMER_PROFILE_ADDRESS = "CustomerProfileAddressGQLResponse";
    //Cband
    public static final String NETWORK_BANDWIDTH_TYPE = "networkBandwidthType";
    public static final String CBAND_SKU = "cBandSku";
    public static final String NUMBER_OF_LINES = "numberOfLines";
    public static final String ACCOUNT_CAP_EXCEEDED = "3238";
    public static final String PAST_DUE_BALANCE = "PAST_DUE_BALANCE";
    //clearAndContinue standalone accessory NSEACC implementation
    public static final String PROSPECT_CARTID = "prospectCartId";
    //clearAndContinue standalone accessory NSEACC implementation
    public static final String CONNECTED_TO_ADDED = "CONNECTED-DEVICE-GAIN";
    public static final String MULTI_LINE = "mulitiline";
    public static final String DIGITAL_CHANNEL = "Digital";
    public static final String GIFTITEM = "GIFTITEM";
    public static final String BOGO_MTN = "bogoMtn";
    public static final String NMC_GOOGLE_PLAY_PASS_LOSS = "NMC-GOOGLE-PLAY-PASS-LOSS";
    public static final String GOOGLE_PLAY_PASS_LOSS = "GOOGLE-PLAY-PASS-LOSS";
    public static final String GOOGLE_PLAY_PASS_GAIN = "GOOGLE-PLAY-PASS-GAIN";
    public static final String STATE_NEW_MEXICO = "STATE_NM";
    public static final String STEP_UP = "STEP_UP";
    public static final String PAID_CONVERSION = "PAIDCONVERSION";
    public static final List<String> GOOGLE_PLAY = Arrays.asList("GOOGLE_PLAY_INCLUSION", "GOOGLEPLAY");
    public static final List<String> APPLE_ARCADE = Arrays.asList("APPLE_ARCADE_INCLUSION", "VZARCADE");
    public static final String NMC_APPLE_ARCADE_LOSS = "NMC-APPLE-ARCADE-LOSS";
    public static final String APPLE_ARCADE_GAIN = "APPLE-ARCADE-GAIN";
    public static final String APPLE_ARCADE_LOSS = "APPLE-ARCADE-LOSS";
    public static final String NMC_APPLE_ARCADE_GOOGLE_PLAY_LOSS = "NMC-APPLE-ARCADE-GOOGLE-PLAY-LOSS";
    public static final String APPLE_ARCADE_GOOGLE_PLAY_LOSS = "APPLE-ARCADE-GOOGLE-PLAY-LOSS";
    public static final String APPLE_ARCADE_GOOGLE_PLAY_GAIN = "APPLE-ARCADE-GOOGLE-PLAY-GAIN";
    public static final String TRAVEL_PASS_LOST = "TRAVEL-PASS-LOSS";
    public static final String TPMIXMATCH = "TPMIXMATCH";
    public static final String DROP = "DROP";
    public static final String VERIZON_CLOUD_DISCOUNT = "VERIZON_CLOUD_DISCOUNT";
    public static final String VZCLOUD_DISCOUNT_GAIN = "VZCLOUD_DISCOUNT_GAIN";
    public static final String VZCLOUD_DISCOUNT_LOSS = "VZCLOUD_DISCOUNT_LOSS";
    public static final String TPFREEDAYS_LONGMSG = "TPFREEDAYS_LONGMSG";
    public static final String TPFREEDAYS_TPMIXMATCH = "TPFREEDAYS_TPMIXMATCH";
    public static final String HOME_INTERNET_DISCOUNT_LOSS = "4G-5G-HOMELINE-DISCOUNT-LOSS";
    public static final String HOME_INTERNET_DISCOUNT_GAIN = "4G-5G-HOMELINE-DISCOUNT-GAIN";
    public static final List<String> HOME_INTERNET_DISCOUNT_SPO = Arrays.asList("2153", "2154", "2156");
    public static final String ACCESSORY_FINANCING_OFFERS_INFO = "accessoryFinancingOfferInfo";
    public static final String FLOW_NAME = "flowName";
    public static final String DIGITAL_CLIENT_APP = "VZW-DOTCOM,VZW-DOTCOM-TAB,VZW-DOTCOM-MOB,VZW-MFA,VZW-MFA-ANDROID,VZW-MFA-IOS";
    public static final String AQ_CASE_ID = "aqCaseId"; //new constant added
    public static final String CRM_RESUME_CART_FLOW = "crmResumeCartFlow";
    public static final String PLAN_SIZE = "planSize";
    public static final String CANCEL_UPPERCASE = "CANCEL";
    public static final String TAX_SOFT_SKU = "TAX80070001";
    public static final String PROSPECT_CART_ACTIVE = "prospectCartActive";
    public static final String RESTART_AND_ADD_DEVICE = "RestartandAddDevice";
    public static final String HUB_PROSPECT_CART = "hubProspectCart";
    public static final String NSE_CART_ITEMS_AVAILABLE = "nseCartItemsAvailable";
    public static final String NEW_RECOMMENDED_PLAN_SELECTION = "NewRecommendedPlanSelection";
    public static final String CUSTOMER_TYPE = "CustomerType";
    public static final String PREPAY_CUSTOMER_TYPE = "customerType";
    public static final String NUM_OF_LINES = "numOfLines";
    public static final String MTN_HASHCODE_MAPPING = "mtnHashCodeMapping";
    public static final String PROSPECT_CART_AVAILABLE = "prospectCartAvailable";
    public static final String NSA_PLAN_FIRST_CL = "NSA_PLAN_FIRST_CL";
    public static final String MUC = "muc";
    public static final String TRAVEL_PASS_GAIN = "TRAVEL-PASS-GAIN";
    public static final String STREET_NAME = "streetName";
    public static final String STREET_NUBMER = "streetNumber";
    public static final String STREET_TYPE = "streetType";
    public static final String SUB_FLOW = "subFlow";
    public static final String EXPRESS_NSE_PF = "ex_pf";
    public static final String BAU_PF = "bau_pf";
    public static final String VZPAGE = "vzPage";
    public static final String DOWNPAYMENT = "DownPayment";
    public static final String OMNI_INDIRECT_TAB = "OMNI-INDIRECT-TAB";
    public static final String RFEX_EXCHANGE_SHOP_DETAILS = "rfexExchangeShopDetails";
    public static final String PAD = "PAD";
    public static final String VZHP_FEATUREID = "1614";
    public static final String MUC_FLOW = "MUCFlow";
    public static final String RETRIEVE_CART_REQUEST_LOG = "retrieve Cart Request: {}";
    //API Endpoints
    public static final String ADD_DEVICE_ENDPOINT = "/cart/nse/add-device";
    public static final String MARKET = "market";
    public static final String PREORDERINSERVICEDATE = "preOrderInServiceDate";
    public static final String TRANSACTION_TYPE_PREORDER = "PREORDER";
    public static final String TRANSACTION_TYPE_WIFIBACKUP = "WIFIBACKUP";
    public static final String DL_UTILITY_EXCEPTION = "exception while calling dlUtilityService in addDevice";
    public static final String EUP_5G = "EUP_5G";
    public static final String LTE_CBD_TRANSACTIONTYPE = "LTE_TO_CBD_UPGRADE";
    public static final String ADD_ACTIONINDICATOR = "A";
    public static final String MONTH_TO_MONTH = "MONTH_TO_MONTH";
    public static final String DEVICE_TYPE = "DEVICE";
    public static final String SOFT_SKU = "SOFT_SKU";
    public static final String HOME_SOLUTIONS = "Home Solutions";
    public static final String HELPER_DISCOUNT_EXCEPTION = "Error while setting fullPriceDiscount value";
    public static final String DISC_PROMO = "DISCPROMO";
    public static final String PAPER_FREE = "PAPERFREE";
    public static final String FIVEG_BUNDLE = "5GBUNDLE";
    public static final String FIVEG_LOYALTY = "5GLOYALTY";
    public static final String LTE_LOYALTY = "LTELOYALTY";
    public static final String DAW01 = "DAW01";
    public static final String VISBLPREPD = "VISBLPREPD";
    public static final String REMKG = "REMKG";
    public static final String CXP_DATE_FORMAT = "yyyymmdd";
    public static final String SOE_DATE_FORMAT = "mm/dd/yyyy";
    public static final String HELPER_DISCOUNT = "DISCOUNT";
    public static final String COUPON_DISCOUNT = "COUPON_DISCOUNT";
    public static final String ACCOUNT_DISCOUNT = "ACCOUNT_DISCOUNT";
    public static final String FIVEG_AUTOPAY = "5GAUTOPAY";
    public static final String HELPER_ACCESSORY = "ACCESSORY";
    public static final String CBAND_TECHNICIAN = "cBand_Technician";
    public static final String HELPER_ACCESSORIES = "Accessories";
    public static final String ORDER_NOW = "orderNow";
    public static final String HUNDRED = "100.0";
    public static final String HELPER_ADD_PLAN_EXCEPTION = "Exception occur in addPlanAndDevice method and error={}";
    public static final String HELPER_ADD_COUPON_EXCEPTION = "Exception occur in Apply Coupon method and error={}";
    public static final String ACC_MGMT = "AcctMgmt";
    public static final String PROFILE_UPDATE = "ProfileUpdate";
    public static final String PROFILE = "Profile";
    public static final String E911ADDRESSCHANGE = "E911AddressChange";
    public static final String SAVE = "Save";
    public static final String UPDATE_TRANSACTION = "UpdateTransaction";
    public static final String EDIT = "Edit";
    public static final String ADDRESS_CHANGE = "AddressChange";
    public static final String SERIAL_NUMBER = "serialNumber";//XBOX Retail Ordering Changes
    public static final String CUSTOMER_EMAILID = "cbandAuthEmailId";
    // eagle cpc tech constants
    public static final String CPC_ORDER_TYPE = "cpcOrderType";
    public static final String CPC_BASIC_TO_BASIC = "basicToBasicCpc";
    public static final String CPC_PLAN_ID = "cpcNewPlanId";
    public static final String VPM_LOCATION_CODE = "VPMLocationCode";
    public static final String TECHFLOW_SERVICE_ADDRESS = "serviceAddress";
    public static final String VPM_ORDER_NUMBER = "VPMOrderNumber";
    public static final String VPM_AUD = "aud";
    public static final String VPM_EXP = "exp";
    public static final String VPM_IAT = "iat";
    public static final String VPM_ISS = "iss";
    public static final String VPM_SALES_ID = "sales_id";
    public static final String VPM_SUB = "sub";
    public static final String CBAND_REP_ID = "cBandRepId";
    public static final String CBAND_OUTLET_ID = "cBandOutletId";
    public static final String FIVEG_PLAN = "fiveGPlan";
    public static final String CBAND_AUTH_MTN = "cBandAuthMTN";
    public static final String EUP_5G_ACCOUNT_NUMBER = "eup_5G_acc_number";
    public static final String CPC_TRANSACTION_TYPE = "Tech_CPC_MMWtoCBD";
    public static final String CPC_FLOW_INITIATOR = "ExpressCPC";
    public static final String NETWORK_TYPE_CBD = "CBD";
    public static final String NETWORK_TYPE_MMW = "MMW";
    public static final String RECOMMENDER_PEGA = "PEGA";
    public static final String CPC_PROVISION_PLAN_PROCESSSTEP = "provisionPlan";
    public static final String CPC_PAGE_CONTEXT = "ExpressCPC_ReviewPage";
    public static final String CPC_PLAN_SUBMIT_STR_ID = "PlanId";
    public static final String SPO_MTN = "spoMtn";
    public static final String COOKIE_TARGET_PRICING_OFFER = "targetPricingOffer";
    public static final String INLINE_CPC = "Inline-CPC";
    public static final String CPC_NAME = "CPC";
    public static final String DIGITAL_DDOT_MOB_TAB_CHANNELS = "VZW-DOTCOM,VZW-DOTCOM-TAB,VZW-DOTCOM-MOB";
    public static final String SUBSCRIPTION_TYPE_GAMINGCONSOLE = "GAMINGCONSOLE";
    public static final String PLAN_PROMO_RECOMMENDATION = "PlanPromoRecommendation";
    public static final String XBOX_MTN_NOT_WHITELIST_ERROR_ID = "3386";
    public static final String REDIS_PLAN_INFO = "redisPlanInfo";
    public static final String RETAIL = "OMNI-RETAIL";

    public static final String OMNI = "OMNI";
    public static final String RETAIL_TANGLEWOOD_SELECTED = "tanglewoodSelected";
    public static final String PROCESS_STEP_DPP_SUMMARY = "DPPSummary";
    public static final String IS_PREPAY_CART = "isPrepayCart";
    public static final String PREPAYEXISTINGCUST = "U";
    //Simplifiedhub
    public static final String SHUBE = "SHubE";
    public static final String SHUB = "SHub";
    public static final String SHUBV2 = "SHubV2";
    //NextGen Flow
    public static final String NEXT_GEN = "NEXTGEN";
    public static final String VVC="VVC";
    //NextGen existing customer Flow
    public static final String NEXTGEN_EC="NEXTGEN_EC";
    public static final String NEXTGEN_EC_C = "NEXTGEN_C_EC";
    public static final String NEXTGEN_EC_BAU="NEXTGEN_EC_BAU";
    public static final String NEXTGEN_PF="NEXTGEN_PF";
    public static final String NXT_GEN = "nxtgen";
    public static final String NEXTGEN_BAU = "nextgen_bau";
    // Abandon cart cookie changes
    public static final String ACID = "acid";
    public static final String ABANDON_CART_AVAILABLE = "acmodal";
    public static final String AFFIRM_FINANCING_OFFER_INFO = "AFFIRM-FINANCING-OFFER-INFO";
    public static final String APPROVED_SECONDCAPTCHA_REDIS_KEY = "approvedForSecondCaptcha";
    public static final String OC_NATIONAL = "OC_NATIONAL";
    public static final String REPLENISHMENT_AMOUNT = "replenishmentAmount";
    public static final String REPLENISHMENT = "REPLENISH";
    public static final String PROMO_FIRST_OFFER = "promoFirstOffer";
    public static final String ERRCAT_CJCM = "CJCMERR";
    public static final String ERRCAT_CXP = "CXPERR";
    public static final String ERRCAT_APP = "APPERR";
    public static final String ENDPOINT = "endPoint";
    public static final String SOF = "SOF";
    public static final String MOVERS_INSTALL_TYPE = "S";
    public static final String MOVERS_DEPLETION_TYPE = "F";
    public static final String PREV_NETWORK_BANDWIDTH_TYPE = "prevNetworkBandwidthType";
    public static final String MOVERS_ADDRES_QUAL_RESPONSE = "moversAddressQualRes";
    public static final String MOVERS_NEXT_PROCESSSTEP = "MoveNow";
    public static final String MOVERS_CALLREASON = "FiveGMovers";
    public static final String MOVERS_PROCESSACTION = "Initiate";
    public static final String MOVERS_INTENT = "MOV_5G";
    public static final String MOVERS_PROCESS_UPDATE_PLAN = "updatePlan";
    public static final String MOVERS_FLOWTYPE = "MOVERS";
    public static final String MOVERS_ITEMTYPE = "ACCESSORY";
    public static final String MOVERS_QTY = "1";
    public static final String MOVERS_ID = "MOVERSSELF";
    public static final String MOVERS_MTN = "moversMtn";
    public static final String MOVERS_TRANSACTIONTYPE = "MOVERS";
    public static final String MOVERS_ACC_INFO_KEY = "moversFWALinesInfo";
    public static final String TRANSFER_YOUR_SERVICE = "TransferYourService";
    public static final String TYS_ASSUMER = "TYS-Assumer";
    public static final String TYS_UPDATE = "TYSUpdate";
    public static final String ADD_TO_CART = "AddtoCart";
    public static final String REVIEW_ORDER = "ReviewOrder";
    public static final String LINE_ACTIVITY_TYPE = "lineActivityType";
    public static final String ORDER_LANDING = "OrderLanding";
    public static final String FEATURE_SELECTION = "FeatureSelection";
    public static final String TYS_INTEND_TYPE = "TSE";
    public static final String USER_ROLE = "userRole";
    public static final String PROMO_BUNDLE_BUILDER = "PromoBundleBuilder";
    public static final String EUP_BYOD_LINE_ACTIVITY = "EUPBYOD";
    public static final String BYOD_LINE_ACTIVITY = "BYOD";
    public static final String AAL_LINE_ACTIVITY = "AAL";
    public static final String NSE_BYOD_LINE_ACTIVITY = "NSEBYOD";
    public static final String OMNI_DL_PAGE = "page";
    public static final String OMNI_DL_ACC_NO = "accountNumber";
    public static final String OMNI_DL_AUTH = "authentication";
    public static final String OMNI_DL_TXN = "txn";
    public static final String PAGE_PARAMS = "vzPage";
    public static final String OMNI_DL_USER = "user";
    public static final String OMNI_DL_TARGET = "target";
    public static final String PROMOTYPE_TRADEIN = "TRADEIN_PROMO";
    public static final String RELINQUISH_ACCOUNT_NUMBER = "relinquishAccountNumber";
    public static final String TYS_LINES_COUNT = "tysLinesCount";
    // https://onejira.verizon.com/browse/VCGH-4116
    public static final String TRUCK_ROLL_ORDER = "TruckRollOrder";
    public static final String NATIONAL_OFFER = "N";
    public static final String STRATEGIC_OFFER = "S";
    public static final String VZW_ACSS = "VZW-ACSS";
    public static final String TR_INSTALL = "TR_Install";
    public static final String SCHEDULE_APPT = "ScheduleAppt";
    public static final String PROCESS_INDICATOR_M = "M";
    public static final String PROCESS_INDICATOR_G = "G";
    public static final String VISION_EAST_VE = "VE";
    public static final String VISION_WEST_VW = "VW";
    public static final String VISION_NORTH_VN = "VN";
    public static final String PROFILE_STATE_C0 = "C0";
    public static final String REP_ROLE = "repRole";
    public static final String Y = "Y";
    public static final String N = "N";
    public static final String STREET_DIRECTION = "streetDirection";
    public static final String BBP_DEFAULT_ZIPCODEFORTABLETFLOW = "bbpDefaultZipcodeForTabletFlow";
    public static final String REPAIRGEN2TOGEN3 = "repairGen2ToGen3";
    public static final String PROMOBUNDLE = "PromoBundle";
    public static final String RESUME = "Resume";
    public static final String RESUME_CASE = "RESUME_CASE";
    public static final String UPDATE_CARTID_CASEID = "Updating cartId and caseId in Redis";
    public static final String LOG_REDIS_ACCOUNT_NUMBER = "Calling cxp helper with redis account number %s";
    public static final String BPM_LOG_REDIS_ACCOUNT_NUMBER = "Calling bpm helper with redis account number %s";
    public static final String LOG_CREDIT_CONTENT = "CreditContent received %s";
    public static final String LOG_CREDIT_FAILED = "Credit Failed Counter in Same Session %s";
    public static final String LOG_CRADLE_OUTPUT = "cradleResponse output is --> %s";
    public static final String LOG_PROMO_FLAG = "promoHubSpokeJourneyFlag %s";
    public static final String LOG_FAIL_SPOS_REDIS = "Failure in Updating SPOS in Redis";
    public static final String NEWCUSTOMER = "NEWCUSTOMER";
    public static final String RETRIEVE_MINI_CART = "retrieveMiniCart";
    public static final String APP_NAME = "appName";
    public static final String SOE_CART_SERVICE_NAME = "SOE CartService";
    public static final String REDIS_DATA_LOG_CONTENT = "Data upserted into Redis: %s | AppName: CartService";
    public static final String REDIS_KEY_FAIL_LOG = "Unable to set Redis key %s";
    public static final String REDIS_KEY_UPDATE_LOG = "Updated Redis key %s";
    public static final String ACCOUNT_INFO_ELIGIBLE = "accountInfoEligible";
    public static final String LINE_ACTIVITY_TYPE_BYOD_EUP_LINES = "byodEUPLines";
    public static final String CART_ITEM_CODE_DEVICE = "DEVICE";
    public static final String CART_ITEM_CODE_SIM = "SIM";
    public static final String CART_ITEM_CODE_WARRANTY = "WARRANTY";
    public static final String CART_ITEM_CODE_SHIPPING = "SHIPPING";
    public static final String CART_ITEM_CODE_ACCESSORIES = "ACCESSORY";
    public static final String CART_ITEM_CODE_UPGRADE_FEE = "UPGRADE_FEE";
    public static final String NSEACC_INTEND = "NSEACC";
    public static final String VERIZON_PROTECT_MD_CODE_1 = "1533";
    public static final String VERIZON_PROTECT_MD_CODE_2 = "1534";
    public static final String VERIZON_PROTECT_MD_CODE_3 = "1973";
    public static final String LINE_ACTIVITY_TYPE_EUP_LINES = "EUP";
    public static final String LINE_ACTIVITY_TYPE_AAL_LINES = "AAL";
    public static final String LINE_ACTIVITY_TYPE_NSE_LINES = "NSE";
    public static final String LINE_ACTIVITY_TYPE_BYOD_LINES = "NSEBYOD";
    public static final String LINE_ACTIVITY_TYPE_BYOD_LINES_LOGIN = "BYOD";
    public static final String CART_ITEM_TYPE_DEVICE = "DEVICE";
    public static final String CART_ITEM_TYPE_ACCESSORY = "ACCESSORY";
    public static final String DISCONNECT_ELIGIBLE_STATUS_REASON_CODE = "RR";
    public static final String FLOW_TYPE_DEVICE = "DEVICE";
    public static final String PARTIAL_SUCCESS = "PARTIAL_SUCCESS";
    public static final String FLOW_TYPE_SIM = "SIM";
    public static final List<String> LOCAL_STORE_OFFER_CAT_CODES = Arrays.asList("VBMOFFER5", DISC_PROMO);
    public static final String SOA_ZERO_ACCNUM = "0000000000-00001";
    public static final String ORDER_REVIEW_SHIPMENT_PAYMENT_AGREEMENT = "OrderReview-Shipping-Payment-Agreement";
    public static final String COMPANION_PHONE_NUMBER = "companionPhoneNumber";
    public static final String BYOPERK = "BYOPERK";
    public static final String FLOW = "flow";
    public static final String REFUND_EXC = "RF";

    public static final String NEXTGEN_C_BYOD_CDL_VALUE = "NG_C_BY_DF";

    public static final String NEXTGEN_C_BYOD_MVA_CDL_VALUE = "NG_C_BY_DF_M";

    public static final String LTE_MOV = "LTE_MOV";
    public static final String LTE = "LTE";
    public static final String REASON_CODE_MS = "MS";
    public static final String CBD_MOV = "C_BAND_MOV";
    public static final String CBD = "C_BAND";
    public static final String OFFER_INTERSTITIAL = "OfferInterstitial";
    public static final String ADD_PROMO_INTENT = "addPromoIntent";
    public static final String PROMO = "PROMO";
    public static final String PROMO_TRADE ="PROMO-TRADE";
    public static final String DEVICE_TYPE_SMARTPHONE = "SMARTPHONE";
    public static final String DEVICE_TYPE_FEATUREPHONE = "FEATUREPHONE";
    public static final String DEVICE_TYPE_BASICPHONE = "BASIC";
    public static final String LOCATION_DETAILS = "LocationDetails";
    public static final String ADD_ZIPCODE = "addZipCode";
    public static final String BRAND_NAME = "brandName";
    public static final String CCAR_WIFI_STATE = "ccarWifiState";
    public static final String CLIENT_ID = "clientId";
    public static final String CHAT_STORE_ORDER_RESTRICTION_PRICE_MSG = "Order Validation Failed Due to Price Restriction";
    public static final String PLAN_BUILDER = "PLAN_BUILDER";
    public static final String CREATE_CART_AND_LINE = "createCartAndLine";
    public static final String LINESELECTION = "LineSelection";
    public static final String ADDLINE = "ADDLINE";
    public static final String P = "P";
    public static final String CREATE_CASE = "createCase";
    public static final String ADDRESS_QUALIFICATION_BY_MTN = "addressQualificationByMTNData";

    public static final String NSE_CUSTOMER_ADDRESS = "nseCustomerAddress";
    public static final String EUP_CPC = "EUP|CPC";
    public static final String TRADEIN = "TRADEIN";
    public static final String NAO_ACCESSORY = "NAO";

    protected static final List<String> VZPH_ID = Arrays.asList("1614");

    public static final String SSO_JWT_UPPERCASE = "SSO_JWT";
    public static final String SSO_JWT_LOWERCASE = "sso_jwt";
    public static final String SSO_JWT_PASCALCASE = "Sso_jwt";
    public static final String GENERICERROR = "genericError";
    public static final String REDIRECT_URI = "redirectUri";
    public static final String LOCATION = "Location";
    public static final String SMARTWATCHES = "SMARTWATCHES";
    public static final String TABLETS = "TABLETS";
    public static final String NSE_START_BBP_FLOW = "/nse/startBBPFlow";
    public static final String RETRIEVE_OMNIDL_EXCEPTION = "Retrieve OmniDL Exception";
    public static final String NEW_CUSTOMER_CAMELCASE = "newCustomer";
    public static final String RETRIEVE_MINI_CART_CAMELCASE = "retrieveMiniCart";
    public static final String RESPONSE_TO_STRING_CONVERSION_EXCEPTION = "Exception occur during converting response to String";
    public static final String CONNECTED_CAR = "CONNECTED_CAR";
    public static final String ADD_DEVICE_LOWERCASE = "add-device";
    public static final String EXCEPTION_OCCURRED = "Exception Occurred";
    public static final String DIGITAL_URL = "digitalurl";
    public static final String HTTPS = "https";
    public static final String SOR_ID = "sorId";

    public static final String IS_COMMON_PDP = "isCommonPDP";
    public static final String TYPE = "type";
    public static final String REDIRECT_URI_LOWERCASE = "redirecturi";
    public static final String CXP_RESPONSE = "cxpResponse";
    public static final String DEVICE_AND_PLAN = "DeviceAndPlan";
    public static final String BUSINESS_ERR = "BUSINESS_ERR";
    public static final String JSON_PARSING_EXCEPTION = "Json parsing exception";
    public static final String RETRIEVE = "Retrieve";
    public static final String NON_RECURRING_CHARGES = "nonRecurringCharges";
    public static final String TOTAL = "total";
    public static final String TARGET_ENGAGEMENT = "target.engagement";
    public static final String VZW_DESKTOP_STORE = "vzw_desktop_store";
    public static final String ORDER_TYPE = "orderType";
    public static final String ORDER = "order";
    public static final String VALUE = "value";
    public static final String PROMOS_APPLIED = "promosApplied";
    public static final String TEST_VERSION = "testVersion";
    public static final String OFFER = "offer";
    public static final String SESSION = "session";
    public static final String ACCOUNT_TYPE = "accountType";
    public static final String AUTH_STATUS = "authStatus";
    public static final String ICC_ID = "IccId";
    public static final String TOKEN = "Token";
    public static final String NUMBER_SHARE = "numberShare";
    public static final String REQUEST = "request";
    public static final String PROMO_ID = "Promo Id";
    public static final String DESCRIPTION = "Description";
    public static final String BILLING_SHIPPING_ADDRESS_DIFFERENT_FLAG = "billingShippingAddressDifferentflag";
    public static final String FALSE_UPPERCASE = "FALSE";
    public static final String ADDRESS_OBJECT = "address object";
    public static final String SESSION_ENDED_REPROCESS = "This session has ended. Please reprocess to proceed";
    public static final String ADD_DEVICE_METHOD_EXCEPTION = EXCEPTION_OCCURRED + " in add-device method and error={}";
    public static final List<String> FLOWS_LIST = Arrays.asList("EXISTING","USER");
    public static final String BULK_QUALIFICATION_QUALIFIED_ADDRESS_LIST = "bulkQualifiedAddressResponse";
    public static final String PLAN_SELECTION_PATH = "planSelectionPath";

    public static final String PAGE_ID = "pageId";
    public static final List<String> _2TB_CLOUD_FEATURES = Arrays.asList("88133", "694453", "694452");
    public static final String TB_PERK_SPO = "2630";
    public static final String LOCATION_SUB_TYPE = "locationSubType";

    public static final String NXT_GEN_BYOD = "Nxtgen-BYOD-Treat";
    public static final String NXT_GEN_BYOD_BAU_ML = "Nxtgen-BYOD-CM";
    public static final String NXT_GEN_BYOD_BAU = "Nxtgen-BYOD-C";
    public final static Set<String> BYODFLOWS= Set.of(NSE_BYOD);
    public static final String DARK_TESTING_BYOU = "isNP";
    public static final String ZERO_DOLLAR_AMOUNT_OFF="0.00";
    public static final String DOLLAR="DOLLAR";
    public static final String TIERED_DOLLAR="TIERED_DOLLAR";
    public static final String CART_PROMO_TYPE = "cartPromoType";
    public static final String CART_DISC_AMT = "cartDiscountAmt";
    public static final String CART_DISC_NAMES = "cartDiscountName";
    public static final String TOTAL_CART_DISCOUNT = "totalCartDiscount";
    public static final String APPLE_MUSIC = "APPLMUS";
    public static final String D2D_IPAD = "OMNI-D2D-TAB";
    public static final String OMNI_D2D = "OMNI-D2D";

    public static final String VERIZON_CLOUD_DISCOUNT_DROP = "VERIZON_CLOUD_DISCOUNT-DROP";
    public static final String VERIZON_CLOUD_DISCOUNT_LEGACY_DROP = "VERIZON_CLOUD_DISCOUNT_LEGACY-DROP";
    public static final String BYOCLOUD_ADD_VERIZON_CLOUD_DISCOUNT_LEGACY_DROP = "BYOCLOUD-ADD-VERIZON_CLOUD_DISCOUNT_LEGACY-DROP";
    public static final String BYOCLOUD_ADD_VERIZON_CLOUD_DISCOUNT_DROP = "BYOCLOUD-ADD-VERIZON_CLOUD_DISCOUNT-DROP";
    public static final String BYOCLOUD_ADD = "BYOCLOUD-ADD";
    public static final String MHS_BAYOU_PLAN_ADD_MHSPERK_DROP = "MHS_BAYOU_PLAN-ADD-MHSPERK-DROP";
    public static final String MHS_BAYOU_PLAN_ADD = "MHS_BAYOU_PLAN-ADD";
    public static final String MHSPERK_DROP =  "MHSPERK-DROP";
    public static final String RETRIEVE_CART_RESPONSE = "retrieveCartResponse";
    public static final String SELECTED_LINE_PROMOLIST = "selectedLinePromoList";

    public static final String PATH = "path";
    public static final String LANDING_MTN_HASHCODE= "landingMtnHashCode";
    //    public static final String BPM_SALES_ORDER_PURCHASE_CASE_ID_PREFIX = "SOP";
    //ACT-16 as part of handling default values from service
    public static final String DEFAULT_APPLICATION_ID= "V-GMDN";
    public static final String DEFAULT_FLOW_IND= "C";
    public static final String RECOMMENDATIONS_DEVICE_SOR_ID = "deviceSorIdForRecommendations";
    public static final String RECOMMENDATIONS_ACCESSORY_SOR_ID = "accessorySorIdForRecommendations";

    public static final String IS_MYLINK_AVAILABLE_FLAG= "isMylinkAvailable";
    public static final String MYLINK_HASH_KEY= "myLinkHashKey";
    public static final String CJEVENT = "CJEVENT";
    public static final String AFFILIATE = "AFFILIATE";
    public static final String DEVICETYPE = "DESKTOP";

    public static final String PERK_SPO_INFO = "perkInfo";
    public static final String PENDING_CANCEL_RESUME = "PENDING_CANCEL_RESUME";
    public static final String PENDING_CANCEL = "PENDING_CANCEL";

    public static final String CUSTOMER_PROFILE = "customerProfile";

    public static final String AAL_BYOD = "AAL_BYOD";
    public static final String DEVICETYPE_5GTABLET= "5G Tablet";
    public static final String DEVICETYPE_4GTABLET= "4G Tablet";

    public static final String DEVICETYPE_5GLAPTOP= "5G Laptop";
    public static final String DEVICETYPE_4GLAPTOP= "4G Laptop";
    public static final String PRODUCT_ID = "productId";
    public static final String INVALID_PRODUCT_ID = "Invalid productId";
    public static final String INVALID_NPANXX = "Invalid npaNxx";

    public static final String PDM_REDIS_KEY = "vzw_pdm_props";

    public static final String RT_CART_COUNT = "rtCartCount";

    public static final String RAF_COUPON_STARTS_WITH = "RFIND";
    public static final String RAF_COUPON_VALIDATION_MESSAGE = "Refer a Friend promo code validated successfully.";
    public static final String ACCESSORY_PDP = "AccessoryPDP";
    public static final String SUG = "SUG";
    public static final String UNABLE_TO_READ_FROM_REDIS_FOR_SESSION = "Unable to read from Redis for session for %s, error: %s";

    public static final String COMBO_MOBILITY_CART_ID = "completedComboMobilityCartId";
    public static final String COMBO_MOBILITY_ORDER_ID = "completedOrderId";
    public static final String COMBO_MOBILITY_LOCATION_CODE = "completedOrderLocCode";
    public static final String COMBO_ORDER_FLAG = "isSequentialComboOrder";
    public static final String IS_JT_COMBO_ORDER = "isJTComboOrder";
    public static final String COMBO_MOBILITY_CREDITAPP_NUM = "creditAppNum";

    public static final String ZIPCODE_INVALID = "Please provide valid ZipCode";

    public static final String INVALID_USER = "Invalid User input";
    public static final String NSE_UPDATE_BARCODE = "nse/updateBarcode";
    public static final String RAFR_PREFIX = "RFIND";
    public static final String RAFR_SUBFLOW = "raf";
    public static final String FWA_QUAL_ADDRESS_ID = "addressId";
    public static final String FWA_QUAL_ADDRESS_LOCATION_ID = "addressLocationId";
    public static final String ACC_BMSM = "AccBMSM";
    public static final String WHW_INTENT ="RedemptionAccessory";
    public static final String VALIDATION_ERROR_ID = "3999";

    public static final String SKU_NOT_AVAILABLE_ERROR_ID = "3000";
    public static final String REBATE_OFFER = "REBATE";
    public static final String EVAR37 = "discountId";
    public static final String CONFLICTS_ACCEPTED_KEY = "conflictsAccepted";

    public static final String EXTENDER = "EXTENDER";

    public static final String REDEEMED = "REDEEMED";

    public static final String WHOLE_HOME_WIFI = "WHM";

    public static final String ACTION_D = "D";

    public static final String ACTION_A = "A";
    public static final String MTN_FLOW_D = "D";
    public static final String CART_CASE_ID_MISSING_ERRORMSG = "Cart accessed by another user or customer, please reprocess.";
    public static final String IS_BAU_OFFER = "B";
    public static final String IS_CHOICE_OFFER = "C";
    public static final String PREPAID_TO_POSTPAID_MIGRATION = "preToPostMigrationFlow";

    public static final String PROSPECT_COUNT_VAL = "0";

    public static final String RESTRICT_MULTILINE = "Restrict Multilne flow failed for preToPostMigration";
    public static final String RESTRICT_MULTILINE_ERROR_ID = "4000";
    public static final String PREPAID_TO_POSTPAID_INDICATOR_BPM = "E";
    public static final String SELECTED_MTN = "selectedMTN";
    public static final String LINE = "line";
    public static final String SHOULD_NOT_BE_EMPTY = " should not be empty";
    public static final String HYPHEN = "-";
    public static final String PASSCODE = "passcode";
    public static final  String COLLABORATION_QR_CODE = "COLLABORATION_QR_CODE";
    public static final String NO_CONTENT = "No content/Data not available";
    public static final String GENERATED_AT_TIMESTAMP = "generatedAtTimestamp";
    public static final String TIME_MILLISECONDS = "timeInMilliseconds";
    public static final String PLANBUILDER = "PLANBUILDER";
    public static final String CART_INVALID = "Invalid cartId";

    public static final String ADD_PLAN_REQUEST_KEY =  "addPlanAndPerksData";
    public static final String DEFAULT_APP_ID = "M-QEID";
    public static final String BILL_ACCOUNT_NO = "billAccountNo";
    public static final String SMARTWATCH = "SmartWatch";
    public static  final List<String> ACCOUNT_MEMBER_ROLES = Arrays.asList(MOBILE_SECURE,ACCOUNT_MEMBER);
    public static final String VALIDATION_ERROR_3993 = "3993";
    public static final String VALIDATION_ERR = "VALIDATION_ERROR";
    public static final String ACC_IN_CART = "accInCart";
    public static final String ACP_INFO = "acpInfo";

    public static final String REGION_CODE = "region_code";
    public static final String X_AKAMAI_EDGESCAPE = "x-akamai-edgescape";

    public static final String REASON_FOR_VISIT = "reasonForVisit";
    public static final String IS_HOME_SALES = "isHomeSales";
    public static final String HOME_SALES_ADDRESS = "homeSalesAddress";
    public static final String ISCOMBOORDERALLOWED = "isComboOrderAllowed";
    public static final String FWA_CUSTOMERID_HASH = "fwaCustomerIdHash";
    public static final String FWA_CUSTOMERMTN_HASH = "fwaCustomerMdnHash";
    public static final String FWA_ACCOUNTTYPE = "fwaAccountType";
    public static final String UPGRADE_BUYOUT_MTN_DETAILS = "upgradeBuyoutMtnDetails";

    public static final String AC_NEXTGEN = "acNextGen";

    public static final String LV_SOFTSKU = "LVSoftsku";

    public static final String O = "O";
    public static final String TGW = "TGW";

    public static final String HUM_CATEGORY = "HUMX";
    public static final String PAUSE_RESUME_ERROR = "pauseResumeError";

    public static final String DIGITAL_ORDER_TYPE="digitalOrderType";

    public static final String DATA_CIRCUIT_ID="dataCircuitId";

    public static final String FWA_SAFE_TECH_SESSION_ID_KEY = "fwaSafeTechSessionId";
    public static final String CUSTOMER_ABANDON_CART_AVAILABLE = "acecmodal";
    public static final String CUSTOMER_TYPE_PROSPECT = "nse";
    public static final String NSE_URL = "/nse/";
    //Joint Transaction
    public static final String JOINT_TRANSACTION_MOBILE_CART_ID ="jointTransactionMobileCartId";
    public static final String JOINT_TRANSACTION_MOBILE_CASE_ID ="jointTransactionMobileCaseId";
    public static final String JOINT_COMBO = "JOINT_COMBO";
    public static final String ZERO_ITEM_PRICE = "0.0";

    public static final String SECOND_NUMBER_PAGE = "SecondNumberPage";
    public static final String QUICK_SHOP_PROSPECT_CART = "quickShopProspectCart";

    public static final String AI_QUOTE = "AIQuote";

    public static final String NPANXX_LIST = "npanxxlist";

    public static final String NSE_ASSIGN_MTN_URL = "cart/nse/assign-mtn";
    public static final String CART_ASSIGN_MTN_URL = "cart/assign-mtn";
    public static final String INVENTORY_NOT_AVAILABLE_ERROR_CODE = "1033";
    public static final String  BAR_CODE_CONSTANT= "BXGY2002024BC7";

    public static final String EARLY_UPGRADE = "EarlyUpgrade";
    public static final String EUP_ITEM_TYPE = "EXPRESS-UPGRADE";

    public static final String ADD_DEVICE_WITH_TRADE_IN = "addDeviceWithTradeIn";


    public static final String EARLY_UPGRADE_ERROR ="Process Action Should be Early Upgrade but it ";
    public static final String ADD_UPGRADE_DETAILS_METHOD_EXCEPTION = EXCEPTION_OCCURRED + " in addUpgradeDetails method and error={}";
    public static final String EXPRESS_UPGRADE = "ExpressUpgrade";

    public static final List<String> ADD_UPGRADE_DETAILS_PROCESS_ACTION = Arrays.asList(EXPRESS_UPGRADE,ADD_DEVICE_WITH_TRADE_IN);
    public static final String TRIAGE_ANSWER = "YES";

    public static final String TRIAGE_ANSWER_NO = "NO";

    public static final String TRIAGE_QUES_IND_1 = "1";
    public static final String TRIAGE_QUES_IND_2 = "2";
    public static final String TRIAGE_QUES_IND_5 = "5";
    public static final String TRIAGE_QUES_IND_7 = "7";
    public static final String QUESTION_TEXT_1 = "The device can be powered on.";
    public static final String QUESTION_TEXT_2 = "The glass is free of cracks and the screen is functioning correctly (both front and back, if applicable).";
    public static final String QUESTION_TEXT_5 = "The device is free of battery damage (typically indicated by swelling, leaking or it being too hot to touch). Devices with battery damage can be recycled at a Verizon store.";
    public static final String QUESTION_TEXT_7 = "The activation lock is turned off (i.e. Find my iPhone/Action lock/Anti-theft protection).";
    public static final String TRADEIN_SHIPPING_TYPE="return_store";
    public static final String TRADEIN_SHIP_TYPE="Home";
    public static final String DEVICE_CONDITION="Good";

    public static final String DEVICE_CONDITION_BAD="Bad";
    public static final String EQUIP_CARRIER="Verizon";
    public static final String BYOD_ADR = "BYOD_ADR";
    public static final String FLOW_TYPE_DVM = "DVM";
    public static final String SERVICE_NAME_TRIAL = "Trial";
    public static final String TRIAL_CALLREASON = "TrialNWTD";
    public static final String BYOD_IMEI_DETAILS = "byodImeiDetails";
    public static final String PAGE_NAME_KEY="pageName";
    public static final String FIVEGCOREPROV_ADD = "5GCOREPROV-ADD";
    public static final String FIVEGUWBBOLT_DROP = "5GUWBBOLT-DROP";
    public static final String CRSP= "crsp";
    public static final String PAGE_NAME_NG_MAKE_AND_MODEL="NGMakeAndModel";
    public static final String DUAL_NUMBER="dualNumber";
    public static final String  HIGH_RISK_MTN_LIST="highRiskMtnList";
    public static final String USERINFO = "USERINFO";
    public static final String  UPDATE_USER_INFO = "UpdateUserInfo";
    public static final String VALIDATION_ERROR_DEVICE_ID = "609";
    public static final String G_CAPTCHA_COOKIE = "g_captcha";
    public static final String PAGEID_LANDING = "Landing";
    public static final String COMMA = ",";
    public static final String ONE_CLICK_UPGRADE = "oneClick";
    public static final String FROM_FREE_PHONES_QV = "fromFreePhoneQV";
    public static final String DELIMETER_HYPHEN = "-";
    public static final String VT_PERKS_STATUS = "vtPerksStatus";
    public static final String VT_PERK_SUBMIT = "VTPERKSSUBMITED";
    public static final String VT_PERK_SELECTED = "Y";
    public static final String EMPTY_SPACE=" ";
    public static final String DVM_CONVERSION_COOKIE = "dvmConversion";
    public static final String DVM_CONVERSION_FLOWTYPE = "DVM_CONVERSION";
    public static final String CRADLEFLOW_JOURNEY_NEXTGEN_BYOD ="NEXTGENBYOD";
    public static final String CRADLEFLOW_JOURNEY_NEXTGEN ="NEXTGEN";

    public static final String QUICK_VIEW = "QUICK_VIEW";

    public static final String QUICK_C_VIEW = "QUICK_C_VIEW";

    public static final String SW_COUPON_CODE = "barCodeId";

    public static final String DVM_CONVERSION_FLAG = "dvmConversion";
    public static final String DVMCONVERSION = "DVM_CONVERSION";
    public static final String COM_VZ_ID = "comvzid";
    public static final String NEXT_BILL = "NB";
    public static final String STEADY_STATE = "SS";
    public static final String PDM_OFFER_RECOMMENDATIONS = "pdmOfferRecommendations";

    public static final String VZHP = "VZHP";
    public static final String PAYOFF_DEVICE = "PAYOFF-DEVICE";
    public static final String PAYOFF_DEVICE_INFO_NODE = "payOffDeviceInfo";


    public static final List<String> STRING_EMPTY_LIST=Collections.EMPTY_LIST;

    public static final String PROMOTION_ID_START_WITH_PROMO = "promo";

    public static final String PORT_LATER_EXISTING_CRADLE_PAGE = "portLaterExisting";
    public static final String NEW_PL_E = "NEW_PL_E";
    public static final String NEW_C_PL_E = "NEW_C_PL_E";
    public static final String ITEMTYPE_WHWPLUS = "WHWPLUS";
    public static final String ITEMTYPE_WHWBASIC= "WHWBASIC";

    public static final String AUTO_TRADEIN = "AUTO_TRADEIN";
    public static final String EUP_AUTO_TRADEIN_PAGEID = "offerinterstitial_autoTradeIn";
    public static final String PAGE_ID_OFFER_INTERSTITIAL = "OfferInterstitial";
    public static final String CONST_FLOW_NAME = "flowName";

    public static final String RESTART = "Restart";
    public static final String CONFIGURATOR = "Configurator";
    public static final String DELETE_CART = "deleteCart";

    public static final String NFL = "nfl";
    public static final String BUILD_PLAN_PATH = "Build Plan";
    public static final String MODIFY= "modify";
    public static final String PRESET= "preset";
    public static final String PLAN_TAGGING_DETAILS = "planTaggingDetails";
    public static final String DEVICES_AND_SERVICES_ITEM = "DEVICES-AND-SERVICES";

    public static final String DEVICES_AND_SERVICES_PROCESS_ACTION = "DEVICES_AND_SERVICES";

    public static final String AC_NEXT_GEN_EXPIRY_DATE = "acNextGenExpiryDate";

    public static final String DATE_FORMAT_MM_DD_YYYY_HH_MM = "MM/dd/yyyyHH:mm";
    public static final String AALBYOD = "AALBYOD";
    public static final String NSO_NSEBYOD = "NSO";
    public static final String ESO_EUPBYOD = "ESO";
    public static final String WHWPLUS_DISCRIPTION = "WHOLE-HOME WI-FI PLUS";
    public static final String WHWBASIC_DESCRIPTION = "WHOLE-HOME WI-FI";
    public static final String WHWPLUS_CATEGORYCODE = "WHWPLUS";
    public static final String WHWHOME_CATEGORYCODE  ="WHWBASIC";
    public static final String PROMOTYPE_BIC = "BIC";
    public static final List<String> D2DRoleIds =Arrays.asList("D2D5GFM", "D2D5GFMEM");
    public static final List<String> INTENT_TYPE_EC =Arrays.asList("AAL", AAL_5G,"BYOD",AAL_LTE);
    
    public static final String BUYOUT_TAG = "-BO";

    public static final String ONECLICK_UPG_TAG = "1CLK-U";

    public static final String PLAN_CHANGE_TAG = "-PC";

    public static final String TRADEIN_TAG = "-T";

    public static final String BIC_TAG = "-B";

    public static final String FIVE_G_INTERNET = "5G Internet";
    public static final List<String> optixRoleIds =Arrays.asList("CSSCREP", "CSSCMGR");

    public static final String INDIRECT_TRADE_WARNING_CODE = "2214";

    public static final String PRICE_TYPE = "MONTH_TO_MONTH";

    public static final String PROSPECT_DEVICE_COUNT = "prospectDeviceCount";
    public static final String LGPO_ELIGIBLE_CUSTOMER= "lgpoEligiblecustomer";

    public static final String LGPO_SPO= "lgpospo";

    public static final boolean DISABLE_OMP = true;

    public static final String SAVE_CART_EMAILID = "saveCartEmailId";

    public static final String PEGA_RESPONSE_RECEIVED_MESSAGE = "Pega response received is: ";

    public static final String RESPONSE_PEGA_CPC = "response Pega for initiate cpc : {}";

    public static final String ERROR_PEGA_CPC = "Error while calling Pega for cpc initiate : {}";

    public static final String ADD_DEVICE_PEGA = "AddDevice PEGA Request: {}";

    public static final String DEVICE_CONFIGURATOR = "DEVICECONFIGURATOR";

    public static final String NEXTGEN_DUE = "nextgenPastDue";

    public static final String NEXTGEN_THRESHOLD = "nextgenThresholdInd";
    public static final String VZDL_OBJ = "VZDL object: {}";
    public static final String ERROR_TAGGING = "Error on Tagging";

    public static final String EMPTY =  "Empty";

    public static final String CART_ADD_DEVICE_HELPER1_FOR_QUICKVIEW = "CartAddDeviceHelper1 inside updateSubFlowInTaggingForQuickView method {}";

    public static final String CXP_AGGREGATE = "CXP-AGGREGATE";

    public static final String SUCCESS = "SUCCESS";

    public static final String VALIDATE = "Validate";
    public static final String TXN_PRODUCT = "txn.product";

    public static final String EVENT = "event";

    public static final String REQUEST_DATA_LINES = "request/data/lines[";

    public static final String ERROR_GEN_KIBANA_LOGS = "Error occurred while generating kibana logs: %s";


    public static final String ON = "ON";

    public static final String OFF = "OFF";
    public static final String DVM_ERROR_URL = "dvmerror.html";
    public static final String SHOPPING_TRIAL_CONVERSION_BUSINESS_EXCEPTION_ID = "4500";
    public static final String SHOPPING_TRIAL_CONVERSION_BUSINESS_EXCEPTION = "SHOPPING_TRIAL_CONVERSION_BUSINESS_EXCEPTION";

    public static final String IS_PREVIOUSLY_USED_DEVICE = "isPreviouslyUsedDevices";
    public static final String ACCESSORY_SORID = "CE1000A";

    public static final String ADD_FEATURES_AND_ACCESSORY="addFeaturesAndAccessory";
    public static final String ITEM_TYPE_LINES = "LINES";
    public static final String ITEM_TYPE_REMOVE_DEVICE = "REMOVE-DEVICE";

    public static final String END_POINT_REMOVE_DEVICE_LINE = "remove-device-line";
    
    public static final String EARLY_UPGRADE_BLOCKER_ERROR_CODE = "1030";
    public static final String STANDALONE_TRADEIN_BLOCKER_ERROR_MESSAGE = "Standalone trade at home orders are not allowed";

    public static final String RETAIL_TAB = "OMNI-RETAIL-TAB";

    public static final String NAME_VALIDATION_ERR = "Invalid Name";

    public static final String EMAIL_ADDRESS_VALIDATION_ERR = "Invalid Email Address.";

    public static final String NAME_EMAIL_NULL_VALIDATION_ERR = "First-Name or Email can not be null";

    public static final String ROUTER = "ROUTER";
    public static final String VZ_INTERNET_GATEWAY = "Verizon Internet Gateway";
    public static final String FLOW_TYPE_FWA_UPGRADE = "FWA_UPGRADE";
    public static final String FOM = "FOM";
    public static final String WHW_DISCOUNT =  "WHOLE-HOME WI-FI DISCOUNT";

    public static final List<String> NO_CART_COUNT_UPDATE_PAGE_LIST =Arrays.asList(PROCESS_STEP_MTN_SELECTION_PAGE, PROCESS_STEP_DPP_SUMMARY);

    public static final String  PLUS = "+";
    public static final List<String> PORTIN_LATER_ENABLED_INTENTS =Arrays.asList(AAL, BYOD);
    public  static final String NGD_HEADER_KEY ="ngd";
    public static final String FLOW_TYPE_NGD="NGD";
    public static final String NGDRC_T="NGDRC_T";
    public static final String NGDRC_C="NGDRC_C";
    public static final String NGD_PAGE_NAME="NGDRC";


    public static final String NR_ROLE_ID = "NR_AGENT";
    public  static  final  String MASTER_AGENT_ID = "CYDCOR-W";
    public static final String QUOTE_E911_ADDR = "isQuoteE911Address";

    public static final String PROSPECT_CART = "Prospect Abandoned Cart";
	public  static final String CUSTOMER_CART = "Customer Abandoned Cart";

    public  static  final  String NULL_STRING = "null";

    public  static  final  String WHWSPO = "3239";
    public  static  final  String WHWPLUSSPO = "3240";
    public static final String RETURN_INDICATOR = "isReturnRequired";

    public static final String FEATURED_PROMO = "FEATURED_PROMO";
    
    public static final String BYOD_NSE = "BYOD_NSE";
    public static final String BYOD_AAL = "BYOD_AAL";
    public static final String BBY_LOCAL_ORDER_LOC_DETAILS = "bbyLocalOrderLocDetails";
    public static final String UPC = "upc";
    public static final String PRICE_ID = "priceId";
    public static final String ENABLE_IMEI_PAGE_ENHANCEMENTS = "enableImeiPageEnhancements";
    public static final String PAGENAME_ENTERDEVICEIMEI = "enterDeviceIMEI";
    public static final String NONE = "none";
    public static  final String REAL_AGENT_CODE = "realAgentCode";
    public static final String MASTER_AGENT_IDS = "masterAgentID";

    public static final String REFERER = "Referer";

    public static final String ORDER_LANDING_TAG = "order-landing";


    public static final String VZTUSER_ERROR = "WIRELINE_ACCESS_BUSINESS_EXCEPTION";
    public static final String VZTUSER_ERROR_CODE = "1390";
    public static final String CART_VZTUSER_MESSAGE = "Please sign in with your mobile number to make changes to your Wireless account.";

    public static final String ERROR_CATEGORY_BUSINESSERR = "BUSINESSERR";
    public static final String VZT = "vzt";


    public static final String SETUPANDGO = "SETUPANDGO";
    public static final String ENABLE_IMEI_INSTRUCTIONS = "enableIMEIInstructions";

    public static final String PENDING_ORDER_URl = "mdnselection/checkEligibility.html";
    public static final String PENDINGORDER = "PENDING_ORDER";
    public static final String GENERIC_ERROR_ADD_STEP_REDIRECT_URL = "expresscart.html";
    public static final String CART_FOR_URL = "cart";
    public static final String FIVEG_HOME_RETAIL_RFEX = "5GHomeRetailRFEX";
    public static final String VALIDATION_ERROR_PASTDUE_ACCEPTED = "611";

    public static final String UPGRADE_NOW = "UpgradeNow";
    public static final String INITIATE = "Initiate";
    public static final String HOMESAFETY_TRIAL_WITHOUT_MTNS = "HOMESAFETY_TRIAL_WITHOUT_MTNS";
    public static final String BAU = "BAU";
    public static final String FIVEG_EXCHANGE = "5G_EXCHANGE";
    public static final String FIVEG_EXCHANGE_UPG = "5G_EXCHANGE_UPG";
    public static final String FWA_DEVICE = "DEVICE";
    public static final String TITAN_SKU = "ASK-NCM1100";
    public static final String AM_ROLE = "accountHolder";
    public static final String FWA_UPGRADE_INTENDTYPE = "EXC";
    public static final String ONECLICK_TAG = "1clk";
    public static final String UNDERSCORE_C = "_c";
    public static final String UNDERSCORE_T = "_t";
    public static final String MH_DISCOUNT_VIZ_FEATURE="MOBILE + HOME DISCOUNT";
    public static final String ACCOUNT_OWNER_REDIS_KEY = "ACCOUNT_OWNER_REDIS_KEY";
    public static final String LOOKUP_MTN = "lookupMTN";
    public static final String SALES_REP_SESSION_KEY = "salesRepId";
    public static final String POS_ROLE_SESSION_KEY = "posRoleId";
    public static final String ORD_LOC_SESSION_KEY = "ordLocation";

    public static final String STAND_ALONE_TRADEIN="STANDALONETRADEIN";

    public static final String ADD_PLAN_AND_FEATURE = "addPlanAndFeatures";

    public static final String OPP_NEXTGEN_CONFIGURATOR_PAGE = "NEXTGENConfiguratorPage";

    public static final String PROCESS_ACTION_EXPRESS_CHECKOUT = "ExpressCheckout";
    private CartConstants() {
    }
}
