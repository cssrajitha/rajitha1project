package onevz.soe.cart.bpm.helper;

import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import onevz.soe.cart.model.common.*;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.constants.PropositionsTypes;
import onevz.soe.cart.gql.schema.SubscriptionInfo;
import onevz.soe.cart.ui.responses.AddPlanUIResponse;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import reactor.core.publisher.Mono;

@Service
public class CartServiceBpmHelperAddPlanHelper {

	private static final Logger logger = LoggerFactory.getLogger(CartServiceBpmHelperAddPlanHelper.class);

	/**
	 * This method add feature change messages to add plan response for UI
	 *
	 * @param addPlanResponse
	 * @return AddPlanUIResponse
	 */
	public Mono<AddPlanUIResponse> updateFeatureChangeDetails(AddPlanUIResponse addPlanResponse, String channelType) {
		logger.debug("Inside CartServiceBpmHelper --> updateFeatureChangeDetails");
		if (addPlanResponse.getServiceBody() == null || addPlanResponse.getServiceBody().getServiceResponse() == null
				|| addPlanResponse.getServiceBody().getServiceResponse().getContext() == null
				|| addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo() == null
				|| ArrayUtils.isEmpty(
				addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getLines())) {
			logger.debug("Inside CartServiceBpmHelper --> updateFeatureChangeDetails --> AddPlanUIResponse is empty");
			return Mono.just(addPlanResponse);
		}

		CartServiceCartInfo cartInfo = addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo();

		setAccountFeatureChangeDetails(cartInfo);

		Line[] lines = addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getLines();
		Arrays.stream(lines).forEach(line -> {
			if (ArrayUtils.isNotEmpty(line.getSpos())) {
				updateSpoDetailsBasedOnPegaResponse(addPlanResponse, line, channelType);
			}
			updateFeatureMessageDetailsV2(cartInfo, line);

		});
		return Mono.just(addPlanResponse);
	}

	private void updateSpoDetailsBasedOnPegaResponse(AddPlanUIResponse addPlanResponse, Line line, String channelType) {
		AtomicBoolean isAutoPayGain = new AtomicBoolean(false);
		AtomicBoolean isAutoPayLoss = new AtomicBoolean(false);
		if (null != line.getSpos() && ArrayUtils.isNotEmpty(line.getSpos())) {
			Arrays.stream(line.getSpos()).forEach(spo -> {
				if (spo != null && CollectionUtilities.isNotEmptyOrNull(
						spo.getParentProductsSorIds())) {
					logger.info("ActionIndicator: {}, spoParentProductIds: {}", spo.getActionIndicator(), spo.getParentProductsSorIds());
					setDisneyEnrolled(addPlanResponse, spo);
					spo.getParentProductsSorIds().stream().forEach(parentSorId -> {
						switch (parentSorId) {
							case CartConstants.AUTOPAY:
								setAutoPayGainOrLoss(addPlanResponse, isAutoPayGain, isAutoPayLoss, line, spo);
								break;
							case CartConstants.SMARTFAM:
								setFeatureLossOrGain(addPlanResponse, line, spo, CartConstants.SMARTFAM, CartConstants.SMARTFAM_ADDED, CartConstants.SMARTFAM_DROPPED);
								break;
							case CartConstants.KIDS4LINE:
								setFeatureLossOrGain(addPlanResponse, line, spo, CartConstants.KIDS4LINE, null, CartConstants.KIDS4LINE);
								break;
							case CartConstants.MILITARY:
								setFeatureLossOrGain(addPlanResponse, line, spo, CartConstants.MILITARY, CartConstants.MILITARY, null);
								break;
							case CartConstants.TEACHER:
								setFeatureLossOrGain(addPlanResponse, line, spo, CartConstants.TEACHER, CartConstants.TEACHER, null);
								break;
							case CartConstants.FIRSTRESPD:
								setFeatureLossOrGain(addPlanResponse, line, spo, CartConstants.FIRSTRESPD, CartConstants.FIRSTRESPD, null);
								break;
							default:
								break;
						}
					});
				}
			});
		}
		// digital check & processing.
		setPromotionWarningMessage(addPlanResponse, channelType);
		cleanUpFeatureAndPromoDetails(addPlanResponse);
	}

	private void updateFeatureMessageDetailsV2(CartServiceCartInfo cartInfo, Line line) {
		logger.info("Inside updateFeatureMessageDetailsV2");
		setFeatureMessageDetailsV2(cartInfo, line, line.getFeatureMessages());

		if (CollectionUtilities.isNotEmptyOrNull(line.getLineSubscriptionInfos())) {
			setSubscriptionChangeFeatureCode(cartInfo, line, line.getLineSubscriptionInfos());
		}
		if (StringUtilities.isNotEmptyOrNull(line.getIsAppleMusicConversion())) {
			setAppleMusicConversion(cartInfo, line);
		}
	}

	private void setAppleMusicConversion(CartServiceCartInfo cartInfo, Line line) {
		String changeFeatureCode = CartConstants.APPLE_MUSIC.concat("-").concat(line.getIsAppleMusicConversion());
		setFeatureChangeDetailsV2(cartInfo, line, changeFeatureCode, null, null);
	}

	private void setFeatureMessageDetailsV2(CartServiceCartInfo cartInfo, Line line, List<FeatureMessages> featureMessagesList) {
		logger.info("Inside setFeatureMessageDetailsV2 method -> Begin");

		List<String> cloudFilterConfig = Arrays.asList(CartConstants.VERIZON_CLOUD_DISCOUNT_DROP, CartConstants.VERIZON_CLOUD_DISCOUNT_LEGACY_DROP, CartConstants.BYOCLOUD_ADD, CartConstants.MHSPERK_DROP, CartConstants.MHS_BAYOU_PLAN_ADD);

		if (CollectionUtilities.isNotEmptyOrNull(featureMessagesList)) {
			List<String> cloudFeatureList = new ArrayList<>();
			List<String> mhsFeatureList = new ArrayList<>();
			featureMessagesList.stream().forEach(featureMessages -> {
				StringBuilder fieldCode = new StringBuilder();
				if (StringUtilities.isNotEmptyOrNull(featureMessages.getName()) && StringUtilities.isNotEmptyOrNull(featureMessages.getAction())) {

					if (CollectionUtilities.isNotEmptyOrNull(featureMessages.getFields())) {
						featureMessages.getFields().stream().forEach(field -> fieldCode.append("-").append(field.getName()).append("-").append(field.getValue()));
					}

					String featureChangeCode = featureMessages.getName().concat("-").concat(featureMessages.getAction());

					if (cloudFilterConfig.contains(featureChangeCode)) {
						cloudMhsFeatureExtract(cloudFeatureList, mhsFeatureList, featureChangeCode);
					}
					String changeFeatureCode = featureChangeCode.concat(fieldCode.toString());
					setFeatureChangeDetailsV2(cartInfo, line, changeFeatureCode, featureMessages.getNextPrice(), null);
				}
			});

			setCloudFeatureChangeMessage(cartInfo, line, cloudFeatureList);
			setMhsFeatureChangeMessage(cartInfo, line, mhsFeatureList);
			//5GUWBBOLT-DROP dropped when cart added 5GCOREPROV-ADD
			updateCartInfoFeature(cartInfo);
		}
		logger.info("Inside setFeatureMessageDetailsV2 method -> End");
	}

	private void updateCartInfoFeature(CartServiceCartInfo cartInfo) {
		boolean is5GCoreAdded = cartInfo.getFeatureChangeDetails().stream()
				.anyMatch(featureChangeDetail ->
						CartConstants.FIVEGCOREPROV_ADD.equalsIgnoreCase(
								featureChangeDetail.getChangedFeatureCode()));
		if (is5GCoreAdded) {
			cartInfo.getFeatureChangeDetails().removeIf(featureChangeDetail ->
					CartConstants.FIVEGUWBBOLT_DROP.equalsIgnoreCase(
							featureChangeDetail.getChangedFeatureCode()));
		}
	}

	private void setMhsFeatureChangeMessage(CartServiceCartInfo cartInfo, Line line, List<String> mhsFeatureList) {
		if (mhsFeatureList.size() > 1) {
			String mhsFeatureCode = CartConstants.MHS_BAYOU_PLAN_ADD_MHSPERK_DROP;
			setFeatureChangeDetailsV2(cartInfo, line, mhsFeatureCode, null, null);
		}
	}

	private void setCloudFeatureChangeMessage(CartServiceCartInfo cartInfo, Line line, List<String> cloudFeatureList) {
		if (cloudFeatureList.size() > 1) {
			String cloudFeatureCode = (cloudFeatureList.contains(CartConstants.VERIZON_CLOUD_DISCOUNT_LEGACY_DROP) && cloudFeatureList.contains(CartConstants.BYOCLOUD_ADD))
					? CartConstants.BYOCLOUD_ADD_VERIZON_CLOUD_DISCOUNT_LEGACY_DROP : CartConstants.BYOCLOUD_ADD_VERIZON_CLOUD_DISCOUNT_DROP;
			setFeatureChangeDetailsV2(cartInfo, line, cloudFeatureCode, null, null);
		}
	}

	private void cloudMhsFeatureExtract(List<String> cloudFeatureList, List<String> mhsFeatureList, String featureChangeCode) {
		switch (featureChangeCode) {
			case CartConstants.VERIZON_CLOUD_DISCOUNT_DROP:
			case CartConstants.VERIZON_CLOUD_DISCOUNT_LEGACY_DROP:
			case CartConstants.BYOCLOUD_ADD:
				setFeatureCodeList(cloudFeatureList, featureChangeCode);
				break;
			case CartConstants.MHS_BAYOU_PLAN_ADD:
			case CartConstants.MHSPERK_DROP:
				setFeatureCodeList(mhsFeatureList, featureChangeCode);
				break;
			default:
				break;
		}
	}

	private void setFeatureCodeList(List<String> featureList, String featureChangeCode) {
		if (!featureList.contains(featureChangeCode)) {
			featureList.add(featureChangeCode);
		}

	}

	private void setAccountFeatureChangeDetails(CartServiceCartInfo cartInfo) {
		logger.info("Inside setFeatureChangeDetailsAccountSubscription method");
		if (CollectionUtilities.isNotEmptyOrNull(cartInfo.getSubscriptionInfos())) {
			setSubscriptionChangeFeatureCode(cartInfo, null, cartInfo.getSubscriptionInfos());
		}
		if (CollectionUtilities.isNotEmptyOrNull(cartInfo.getFeatureMessages())) {
			setFeatureMessageDetailsV2(cartInfo, null, cartInfo.getFeatureMessages());
		}
	}

	private void setSubscriptionChangeFeatureCode(CartServiceCartInfo cartInfo, Line line, List<SubscriptionInfo> subscriptionInfoList) {
		logger.debug("Inside setSubscriptionChangeFeatureCode");
		for (SubscriptionInfo subscriptionInfo : subscriptionInfoList) {
			String nextPrice = null;
			String perkDropDate = null;

			StringBuilder featureCode = formSubscriptionFeatureCode(subscriptionInfo);

			if (StringUtilities.isNotEmptyOrNull(subscriptionInfo.getNextPrice())) {
				nextPrice = subscriptionInfo.getNextPrice();
			}
			if (StringUtilities.isNotEmptyOrNull(subscriptionInfo.getEffectiveDate())) {
				perkDropDate = subscriptionInfo.getPerkDropDate();
			}
			setFeatureChangeDetailsV2(cartInfo, line, featureCode.toString(), nextPrice, perkDropDate);
		}
	}

	private static StringBuilder formSubscriptionFeatureCode(SubscriptionInfo subscriptionInfo) {
		StringBuilder featureCode = new StringBuilder();
		if (StringUtilities.isNotEmptyOrNull(subscriptionInfo.getName())) {
			featureCode = featureCode.append(subscriptionInfo.getName());
		}
		if (StringUtilities.isNotEmptyOrNull(subscriptionInfo.getNextAction())) {
			featureCode = featureCode.append("-").append(subscriptionInfo.getNextAction());
		}
		if (StringUtilities.isNotEmptyOrNull(subscriptionInfo.getNextActionReason())) {
			featureCode = featureCode.append("-").append(subscriptionInfo.getNextActionReason());
		}
		if (StringUtilities.isNotEmptyOrNull(subscriptionInfo.getContentId())) {
			featureCode = featureCode.append("-").append(subscriptionInfo.getContentId());
		}
		logger.info("Inside Subscription Feature Code {}", featureCode);
		return featureCode;
	}


	/**
	 * This method sets message to line
	 *
	 * @param addPlanResponse
	 * @param line
	 * @param messageKey
	 */
	private void setFeatureChangeDetails(AddPlanUIResponse addPlanResponse, Line line, String messageKey,
										 String parentSorCode, String actionInd) {
		logger.debug("Inside CartServiceBpmHelper --> setFeatureChangeDetails");
		try {
			CartServiceCartInfo cartInfo = addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo();
			if (cartInfo.getFeatureChangeDetails() != null) {
				if (cartInfo.getFeatureChangeDetails().stream()
						.anyMatch(featureDetail -> parentSorCode.equalsIgnoreCase(featureDetail.getParentSorCode())
								&& actionInd.equalsIgnoreCase(featureDetail.getActionInd()))) {
					cartInfo.getFeatureChangeDetails().stream()
							.filter(featureDetail -> parentSorCode.equalsIgnoreCase(featureDetail.getParentSorCode())
									&& actionInd.equalsIgnoreCase(featureDetail.getActionInd()))
							.forEach(featureChangeDetail -> {
								if (!featureChangeDetail.getMtnList().contains(line.getMtn())) {
									featureChangeDetail.getMtnList().add(line.getMtn());
									logger.info("FeatureChangeDetails matching:{}", featureChangeDetail.getMtnList());
								}
							});
					return;
				}
				if (cartInfo.getFeatureChangeDetails().stream()
						.anyMatch(featureDetail -> parentSorCode.equalsIgnoreCase(featureDetail.getParentSorCode())
								&& !actionInd.equalsIgnoreCase(featureDetail.getActionInd()))) {
					long count = cartInfo.getFeatureChangeDetails().stream()
							.filter(featureDetail -> parentSorCode.equalsIgnoreCase(featureDetail.getParentSorCode())
									&& !actionInd.equalsIgnoreCase(featureDetail.getActionInd()))
							.flatMap(featureChangeDetail -> featureChangeDetail.getMtnList().stream()).count();
					int integerCountValue = Integer.parseInt(String.valueOf(count));
					logger.info("MtnList IntegerCountValue:{}", integerCountValue);
					if (integerCountValue > 1) {
						cartInfo.getFeatureChangeDetails().stream()
								.filter(featureDetail -> parentSorCode.equalsIgnoreCase(featureDetail.getParentSorCode())
										&& !actionInd.equalsIgnoreCase(featureDetail.getActionInd())).forEach(featureChangeDetail -> {
									featureChangeDetail.getMtnList().remove(integerCountValue - 1);
									logger.info("mtnList removed:{}", featureChangeDetail.getMtnList());
								});
					} else {
						Predicate<FeatureChangeDetail> predicate = value -> parentSorCode.equalsIgnoreCase(
								value.getParentSorCode()) && !actionInd.equalsIgnoreCase(value.getActionInd());
						cartInfo.setFeatureChangeDetails(cartInfo.getFeatureChangeDetails().stream().filter(predicate.negate())
								.collect(Collectors.toList()));
					}
					return;
				}
			}
			List<FeatureChangeDetail> featureChangeDetailList = null;
			FeatureChangeDetail featureChangeDetail = new FeatureChangeDetail();
			featureChangeDetail.setChangedFeatureCode(messageKey);
			if (line != null) {
				featureChangeDetail.setMtn(line.getMtn());
				featureChangeDetail.setMtnList(new ArrayList<>());
				featureChangeDetail.getMtnList().add(line.getMtn());
			}
			featureChangeDetail.setParentSorCode(parentSorCode);
			featureChangeDetail.setActionInd(actionInd);
			if (cartInfo.getFeatureChangeDetails() == null) {
				featureChangeDetailList = new ArrayList<>();
				featureChangeDetailList.add(featureChangeDetail);
				cartInfo.setFeatureChangeDetails(featureChangeDetailList);
			} else if (!cartInfo.getFeatureChangeDetails().stream().anyMatch(fcd -> fcd.getChangedFeatureCode().equalsIgnoreCase(featureChangeDetail.getChangedFeatureCode()))) {
				cartInfo.getFeatureChangeDetails().add(featureChangeDetail);
			}
			logger.debug(String.format("Inside CartServiceBpmHelper --> adding featureChangeDetail %s" , featureChangeDetail));
		} catch (Exception exception){
			logger.debug("Exception occurred in setFeatureChangeDetails", exception);
			return;
		}
	}


	/**
	 * This method to set the feature messages to cart info featureChangeMessage
	 *
	 * @param cartInfo
	 * @param line
	 * @param changeFeatureCode
	 * @param nextPrice
	 * @param perkDropDate
	 */
	private void setFeatureChangeDetailsV2(CartServiceCartInfo cartInfo, Line line, String changeFeatureCode, String nextPrice, String perkDropDate) {
		logger.debug("Inside CartServiceBpmHelper --> setFeatureChangeDetailsV2");
		try {
			logger.info("Inside setFeatureChangeDetailsV2 {}", changeFeatureCode);
			if (line !=null && cartInfo.getFeatureChangeDetails() != null && cartInfo.getFeatureChangeDetails().stream()
					.anyMatch(featureDetail -> changeFeatureCode.equalsIgnoreCase(featureDetail.getChangedFeatureCode()))) {

				cartInfo.getFeatureChangeDetails().stream().filter(featureDetail -> changeFeatureCode.equalsIgnoreCase(featureDetail.getChangedFeatureCode()))
						.forEach(featureChangeDetail -> {
							if (!featureChangeDetail.getMtnList().contains(line.getMtn())) {
								featureChangeDetail.getMtnList().add(line.getMtn());
								logger.info("FeatureChangeDetails matching:{}", featureChangeDetail.getMtnList());
							}
						});
			} else {
				List<FeatureChangeDetail> featureChangeDetailList;
				FeatureChangeDetail featureChangeDetail = new FeatureChangeDetail();
				featureChangeDetail.setChangedFeatureCode(changeFeatureCode);
				featureChangeDetail.setNextPrice(nextPrice);
				featureChangeDetail.setPerkDropDate(perkDropDate);
				if (line != null) {
					featureChangeDetail.setMtn(line.getMtn());
					featureChangeDetail.setMtnList(new ArrayList<>());
					featureChangeDetail.getMtnList().add(line.getMtn());
				}
				if (CollectionUtilities.isEmptyOrNull(cartInfo.getFeatureChangeDetails())) {
					featureChangeDetailList = new ArrayList<>();
					featureChangeDetailList.add(featureChangeDetail);
					cartInfo.setFeatureChangeDetails(featureChangeDetailList);
				} else {
					List<FeatureChangeDetail> featureChangeDetailsList = cartInfo.getFeatureChangeDetails().stream().filter(feature -> StringUtilities.isNotEmptyOrNull(feature.getChangedFeatureCode())).collect(Collectors.toList());
					featureChangeDetailsList.add(featureChangeDetail);
					cartInfo.setFeatureChangeDetails(featureChangeDetailsList);
				}
				logger.debug(String.format("Inside CartServiceBpmHelper -> adding featureChangeDetail %s" , featureChangeDetail));
			}
		} catch (Exception e){
			logger.debug("Exception occurred in setFeatureChangeDetailsV2 {}", e.getMessage());
		}
	}

	/**
	 * This method sets removes the feature change details for AUTO PAY if both Gain ("A) and Loss ("D") available
	 *
	 * @param addPlanResponse
	 */
	private void removeFeatureChangeDetails(AddPlanUIResponse addPlanResponse) {
		logger.debug("Inside CartServiceBpmHelper --> removeFeatureChangeDetails");
		try {
			CartServiceCartInfo cartInfo = addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo();
			List<FeatureChangeDetail> filterFeatureDetails = cartInfo.getFeatureChangeDetails().stream()
					.filter(featureDetail -> CartConstants.AUTOPAY_GAIN.equalsIgnoreCase(featureDetail.getChangedFeatureCode())
							|| CartConstants.AUTOPAY_LOST.equalsIgnoreCase(featureDetail.getChangedFeatureCode()))
					.collect(Collectors.toList());

			if (filterFeatureDetails !=null && !filterFeatureDetails.isEmpty()) {
				cartInfo.getFeatureChangeDetails().removeAll(filterFeatureDetails);
			}
			logger.debug("Inside CartServiceBpmHelper --> removing featureChangeDetail" + filterFeatureDetails);
		} catch (Exception exception) {
			logger.debug("Exception occurred in removeFeatureChangeDetails", exception);
		}
	}

	/**
	 * This method updates feature change details & discount promo totals
	 *
	 * @param addPlanResponse
	 */
	private void cleanUpFeatureAndPromoDetails(AddPlanUIResponse addPlanResponse) {
		logger.debug("Inside CartServiceBpmHelper --> cleanUpFeatureAndPromoDetails");
		verifyFeatureChangeDetails(addPlanResponse);
		updateDiscountPromoTotal(addPlanResponse);
	}


	/**
	 * Method to update tablet discount based on all drop or single drop
	 *
	 * @param addPlanResponse
	 */
	private void verifyFeatureChangeDetails(AddPlanUIResponse addPlanResponse) {
		logger.debug("Inside CartServiceBpmHelper --> verifyFeatureChangeDetails");
		if (CollectionUtilities.isEmptyOrNull(addPlanResponse.getServiceBody().getServiceResponse().getContext()
				.getCartInfo().getFeatureChangeDetails())) {
			return;
		}

		List<FeatureChangeDetail> featureChangeDetails = addPlanResponse.getServiceBody().getServiceResponse()
				.getContext().getCartInfo().getFeatureChangeDetails();
		Iterator<FeatureChangeDetail> iterator = featureChangeDetails.iterator();
		while (iterator.hasNext()) {
			FeatureChangeDetail featureChangeDetail = iterator.next();
			if (CartConstants.PAIR_TO_DROPED.equalsIgnoreCase(featureChangeDetail.getChangedFeatureCode())
					&& !isTabletJetPackDiscountIncludedInAccount(addPlanResponse.getServiceBody().getServiceResponse()
					.getContext().getCartInfo().getLines())) {
				featureChangeDetail.setChangedFeatureCode(CartConstants.PAIR_TO_DROPED_ALL);
				break;
			}
		}
	}

	/**
	 * Method to update discount promo total
	 *
	 * @param addPlanResponse
	 */
	private void updateDiscountPromoTotal(AddPlanUIResponse addPlanResponse) {
		logger.debug("Inside CartServiceBpmHelper --> updateDiscountPromoTotal");
		if (CollectionUtilities.isEmptyOrNull(
				addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getDiscountPromo())) {
			return;
		}

		List<DiscountPromo> discountPromoList = addPlanResponse.getServiceBody().getServiceResponse().getContext()
				.getCartInfo().getDiscountPromo();
		addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()
				.setDiscountPromoTotal(discountPromoList.stream()
						.mapToDouble(promo -> StringUtilities.safeParsingDouble(promo.getPrice(), 0)).sum());
	}

	/**
	 * Method to check whether account has any lines with tablet jetpack discount
	 *
	 * @param lines
	 * @return
	 */
	private boolean isTabletJetPackDiscountIncludedInAccount(Line[] lines) {
		return Arrays.stream(lines).anyMatch(
				line -> line.getTabletJetPackDiscountIncluded() != null && line.getTabletJetPackDiscountIncluded());
	}

	/**
	 * Sets the warning message for the promotions.
	 *
	 * @param addPlanResponse - add plan response
	 */
	public void setPromotionWarningMessage(AddPlanUIResponse addPlanResponse, String channelType) {
		logger.debug("Inside CartServiceBpmHelper --> setPromotionWarningMessage");
		if (ArrayUtils.isNotEmpty(
				addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getLines())) {
			Arrays.stream(addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getLines())
					.forEach(line -> {
						if (line != null) {
							Map<String, List<PropositionsWithType>> propositionsMap = constructPropositionsMap(line);
							for (Map.Entry<String, List<PropositionsWithType>> entry : propositionsMap.entrySet()) {
								List<PropositionsWithType> propositionsList = entry.getValue();
								if (CollectionUtils.isNotEmpty(propositionsList)) {
									if (propositionsList.size() == 1) {
										addWarningMessage(propositionsList.get(0), addPlanResponse, channelType, line);
										if (StringUtils.isNotEmpty(channelType)
												&& CartConstants.ASSISTED.equalsIgnoreCase(channelType)) {
											addWarningMessageDQ(propositionsList.get(0), addPlanResponse, channelType,
													line);
										}
									} else {
										PropositionsWithType qualifiedPropositions = null;
										PropositionsWithType disqualifiedPropositions = null;
										for (PropositionsWithType propositions : propositionsList) {
											if (propositions.getPropositionsType()
													.equalsIgnoreCase(PropositionsTypes.QUALIFIED.name())) {
												qualifiedPropositions = propositions;
											} else if (propositions.getPropositionsType()
													.equalsIgnoreCase(PropositionsTypes.DISQUALIFIED.name())) {
												disqualifiedPropositions = propositions;
											}
											addWarningMessage(qualifiedPropositions, disqualifiedPropositions,
													addPlanResponse, channelType, line);
											if (StringUtils.isNotEmpty(channelType)
													&& CartConstants.ASSISTED.equalsIgnoreCase(channelType)) {
												addWarningMessageDQ(qualifiedPropositions, disqualifiedPropositions,
														addPlanResponse, channelType, line);
											}
										}
									}
								}
							}
						}
					});
		}
	}

	/**
	 * Sets the warning message based on the qualifiedPropositions and
	 * disqualifiedPropositions.
	 *
	 * @param qualifiedPropositions
	 * @param disqualifiedPropositions
	 * @param addPlanResponse
	 * @param line
	 */
	private void addWarningMessage(PropositionsWithType qualifiedPropositions,
								   PropositionsWithType disqualifiedPropositions, AddPlanUIResponse addPlanResponse, String channelType,
								   Line line) {
		StringBuffer warningMessage = new StringBuffer();
		if (Objects.nonNull(qualifiedPropositions) && null == disqualifiedPropositions
				&& Objects.nonNull(qualifiedPropositions.getActionCode())
				&& qualifiedPropositions.getActionCode().equalsIgnoreCase("C")) {
			warningMessage.append(
					"Good news, your customer's promo will continue through the reminder of the promo term as long as the requirements are met.");
			if (StringUtils.isNotEmpty(warningMessage.toString())) {
				if (!"WP".equalsIgnoreCase(qualifiedPropositions.getOfferTypeCd())) {
					if (StringUtilities.isNotEmptyOrNull(qualifiedPropositions.getId()))
						warningMessage.append("  " + CartConstants.PROMO_ID + ": ").append(qualifiedPropositions.getId());
					if (StringUtilities.isNotEmptyOrNull(qualifiedPropositions.getDescription()))
						warningMessage.append(", " + CartConstants.DESCRIPTION + ": ").append(qualifiedPropositions.getDescription());
				}
				addWarningMessageToResponse(warningMessage.toString(), addPlanResponse, channelType, line);
			}
		} else if (null == qualifiedPropositions && Objects.nonNull(disqualifiedPropositions)
				&& Objects.nonNull(disqualifiedPropositions.getActionCode())
				&& Objects.nonNull(disqualifiedPropositions.getOfferTypeCd())
				&& Objects.nonNull(disqualifiedPropositions.getPriorDQ())
				&& disqualifiedPropositions.getActionCode().equalsIgnoreCase("D")) {

			if (disqualifiedPropositions.getPriorDQ().equalsIgnoreCase("N")) {
				if ("WP".equalsIgnoreCase(disqualifiedPropositions.getOfferTypeCd()))
					warningMessage.append(
							"By processing this change, your customer's promo will end as of their next bill.");
				else
					warningMessage.append(
							"By processing this change, your customer's promo will end as of their next full bill cycle.");
			} else if (disqualifiedPropositions.getPriorDQ().equalsIgnoreCase("Y")) {
				warningMessage.append(
						"By processing this change, your customer's promo will end once the price plan change goes into effect.");
			}

			if (StringUtils.isNotEmpty(warningMessage.toString())) {
				if (!"WP".equalsIgnoreCase(disqualifiedPropositions.getOfferTypeCd())) {
					if (StringUtilities.isNotEmptyOrNull(disqualifiedPropositions.getId()))
						warningMessage.append("  " + CartConstants.PROMO_ID + ": ").append(disqualifiedPropositions.getId());
					if (StringUtilities.isNotEmptyOrNull(disqualifiedPropositions.getDescription()))
						warningMessage.append(", " + CartConstants.DESCRIPTION + ": ").append(disqualifiedPropositions.getDescription());
				}
				addWarningMessageToResponse(warningMessage.toString(), addPlanResponse, channelType, line);
			}
		} else if (Objects.nonNull(qualifiedPropositions) && Objects.nonNull(disqualifiedPropositions)) {
			if (Objects.nonNull(qualifiedPropositions.getActionCode())
					&& Objects.nonNull(qualifiedPropositions.getAmount())
					&& Objects.nonNull(disqualifiedPropositions.getActionCode())
					&& Objects.nonNull(disqualifiedPropositions.getAmount())
					&& qualifiedPropositions.getActionCode().equalsIgnoreCase("A")
					&& disqualifiedPropositions.getActionCode().equalsIgnoreCase("D")) {

				if (qualifiedPropositions.getAmount() > disqualifiedPropositions.getAmount()) {
					warningMessage.append("Good news, your customer qualifies for a better promotion.")
							.append(" By processing this change, your customer's promo will be adjusted from $")
							.append(String.format("%.2f", disqualifiedPropositions.getAmount())).append(" to $")
							.append(String.format("%.2f", qualifiedPropositions.getAmount()));
				} else if (qualifiedPropositions.getAmount() < disqualifiedPropositions.getAmount()) {
					warningMessage.append("By processing this change, your customer's promo will be adjusted from $")
							.append(String.format("%.2f", disqualifiedPropositions.getAmount())).append(" to $")
							.append(String.format("%.2f", qualifiedPropositions.getAmount()));
				}

				if (StringUtils.isNotEmpty(warningMessage.toString())) {
					if (!"WP".equalsIgnoreCase(disqualifiedPropositions.getOfferTypeCd())) {
						if (StringUtilities.isNotEmptyOrNull(disqualifiedPropositions.getId()))
							warningMessage.append("  " + CartConstants.PROMO_ID + ": ").append(disqualifiedPropositions.getId());
						if (StringUtilities.isNotEmptyOrNull(disqualifiedPropositions.getDescription()))
							warningMessage.append(", " + CartConstants.DESCRIPTION + ": ").append(disqualifiedPropositions.getDescription());
					}
					addWarningMessageToResponse(warningMessage.toString(), addPlanResponse, channelType, line);
				}
			}
		}
	}

	/**
	 * Sets the warning message based on the propositions.
	 *
	 * @param propositions
	 * @param addPlanResponse
	 */
	private void addWarningMessage(PropositionsWithType propositions, AddPlanUIResponse addPlanResponse,
								   String channelType, Line line) {
		StringBuffer warningMessage = new StringBuffer();
		if (propositions.getPropositionsType().equalsIgnoreCase(PropositionsTypes.QUALIFIED.name())
				&& Objects.nonNull(propositions.getActionCode())
				&& propositions.getActionCode().equalsIgnoreCase("C")) {
			warningMessage.append(
							"Good news, your customer's promo will continue through the reminder of the promo term as long as the requirements are met.")
					.append("If the MTN is moved to an ineligible plan, the promo will be disqualified and unable to be re-added.");
		} else if (propositions.getPropositionsType().equalsIgnoreCase(PropositionsTypes.DISQUALIFIED.name())
				&& Objects.nonNull(propositions.getActionCode()) && Objects.nonNull(propositions.getOfferTypeCd())
				&& Objects.nonNull(propositions.getPriorDQ()) && propositions.getActionCode().equalsIgnoreCase("D")) {

			if (propositions.getPriorDQ().equalsIgnoreCase("N")) {
				if ("WP".equalsIgnoreCase(propositions.getOfferTypeCd()))
					warningMessage.append(
							"By processing this change, your customer's promo will end as of their next bill.");
				else
					warningMessage.append(
							"By processing this change, your customer's promo will end as of their next full bill cycle.");
			} else if (propositions.getPriorDQ().equalsIgnoreCase("Y")) {
				warningMessage.append(
						"By processing this change, your customer's promo will end once the price plan change goes into effect.");
			}
		}

		if (StringUtils.isNotEmpty(warningMessage.toString())) {
			if (!"WP".equalsIgnoreCase(propositions.getOfferTypeCd())) {
				if (StringUtilities.isNotEmptyOrNull(propositions.getId()))
					warningMessage.append("  " + CartConstants.PROMO_ID + ": ").append(propositions.getId());
				if (StringUtilities.isNotEmptyOrNull(propositions.getDescription()))
					warningMessage.append(", " + CartConstants.DESCRIPTION + ": ").append(propositions.getDescription());
			}
			addWarningMessageToResponse(warningMessage.toString(), addPlanResponse, channelType, line);
		}
	}

	/**
	 * Sets the warning message based on the propositions.
	 *
	 * @param propositions
	 * @param addPlanResponse
	 */
	private void addWarningMessageDQ(PropositionsWithType propositions, AddPlanUIResponse addPlanResponse,
									 String channelType, Line line) {
		StringBuffer warningMessage = new StringBuffer();
		if (propositions.getPropositionsType().equalsIgnoreCase(PropositionsTypes.DISQUALIFIED.name())
				&& Objects.nonNull(propositions.getOfferTypeCd())
				&& propositions.getOfferTypeCd().equalsIgnoreCase("RB") && Objects.nonNull(propositions.getActionCode())
				&& propositions.getActionCode().equalsIgnoreCase("D")) {
			warningMessage.append(
					"You are currently eligible for a rebate based on your current plan. Switching will invalidate your current rebate offer.");

		}

		// PSTGRO - 8750 story changes - To set ACB and DQ promo warning message
		if (null != addPlanResponse && null != addPlanResponse.getServiceBody()
				&& null != addPlanResponse.getServiceBody().getServiceResponse()
				&& null != addPlanResponse.getServiceBody().getServiceResponse().getContext()
				&& null != addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()
				&& CollectionUtilities.isNotEmptyOrNull(addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getDiscountLossIndicators())) {

			if (propositions.getPropositionsType().equalsIgnoreCase(PropositionsTypes.DISQUALIFIED.name())
					&& Objects.nonNull(propositions.getActionCode()) && propositions.getActionCode().equalsIgnoreCase("D")
					&& getAcbDiscountLossIndicator(addPlanResponse)) {
				warningMessage.append(
						"By switching plans, you'll lose your discount. You are currently receiving a promotional discount based on your current plan. Switching will end this discount at the end of your next bill cycle. In addition, you are currently receiving the Affordable Connectivity Program discount. By switching plans, you will lose that discount when your plan change becomes effective.");
			}
		}
		if (StringUtils.isNotEmpty(warningMessage.toString())) {
			if (!"WP".equalsIgnoreCase(propositions.getOfferTypeCd())) {
				if (StringUtilities.isNotEmptyOrNull(propositions.getDescription()))
					warningMessage.append(" " + CartConstants.DESCRIPTION + ": ").append(propositions.getDescription());
			}
			addWarningMessageToResponse(warningMessage.toString(), addPlanResponse, channelType, line);
		}
	}

	/**
	 * This method updates the plan warning message in add plan response
	 *
	 * @param message         - message
	 * @param addPlanResponse - add plan response
	 */
	private void addWarningMessageToResponse(String message, AddPlanUIResponse addPlanResponse, String channelType,
											 Line line) {
		logger.debug("Inside CartServiceBpmHelper --> addWarningMessageToResponse");
		CartServiceCartInfo cartInfo = new CartServiceCartInfo();
		if (null != addPlanResponse && null != addPlanResponse.getServiceBody()
				&& null != addPlanResponse.getServiceBody().getServiceResponse()
				&& null != addPlanResponse.getServiceBody().getServiceResponse().getContext()
				&& null != addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo())
			cartInfo = addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo();
		if (StringUtils.isNotEmpty(channelType) && CartConstants.CHANNEL_ASSISTED.equalsIgnoreCase(channelType)) {
			List<PlanChangeWarningMessage> planChangeWarningMessages = CollectionUtilities
					.isNotEmptyOrNull(cartInfo.getPlanChangeWarningMessages()) ? cartInfo.getPlanChangeWarningMessages()
					: new ArrayList<>();
			PlanChangeWarningMessage planChangeWarningMessage = new PlanChangeWarningMessage();
			planChangeWarningMessage.setWarningMessage(message);
			planChangeWarningMessage.setMtn(line.getMtn());
			planChangeWarningMessages.add(planChangeWarningMessage);
			cartInfo.setPlanChangeWarningMessages(planChangeWarningMessages);
		} else {
			List<FeatureChangeDetail> featureChangeDetails = CollectionUtilities.isNotEmptyOrNull(
					cartInfo.getFeatureChangeDetails()) ? cartInfo.getFeatureChangeDetails() : new ArrayList<>();
			FeatureChangeDetail featureChangeDetail = new FeatureChangeDetail();
			featureChangeDetails.add(featureChangeDetail);
			cartInfo.setFeatureChangeDetails(featureChangeDetails);
		}
	}

	public boolean getAcbDiscountLossIndicator(AddPlanUIResponse addPlanResponse) {

		return addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getDiscountLossIndicators().stream()
				.filter(discountLossIndicators -> null != discountLossIndicators.getDiscountIndicator()
						&& discountLossIndicators.getDiscountIndicator().equalsIgnoreCase("ACBDISCNT_DISCOUNT"))
				.findAny().isPresent();

	}

	private void addWarningMessageDQ(PropositionsWithType qualifiedPropositions,
									 PropositionsWithType disqualifiedPropositions, AddPlanUIResponse addPlanResponse, String channelType,
									 Line line) {
		StringBuffer warningMessage = new StringBuffer();
		if (Objects.nonNull(disqualifiedPropositions) && Objects.nonNull(disqualifiedPropositions.getOfferTypeCd())
				&& disqualifiedPropositions.getOfferTypeCd().equalsIgnoreCase("RB")
				&& Objects.nonNull(disqualifiedPropositions.getActionCode())
				&& disqualifiedPropositions.getActionCode().equalsIgnoreCase("D")) {
			warningMessage.append(
					"You are currently eligible for a rebate based on your current plan. Switching will invalidate your current rebate offer.");
			if (StringUtils.isNotEmpty(warningMessage.toString())) {
				if (!"WP".equalsIgnoreCase(disqualifiedPropositions.getOfferTypeCd())) {
					if (StringUtilities.isNotEmptyOrNull(disqualifiedPropositions.getDescription()))
						warningMessage.append(" " + CartConstants.DESCRIPTION + ": ").append(disqualifiedPropositions.getDescription());
				}
				addWarningMessageToResponse(warningMessage.toString(), addPlanResponse, channelType, line);
			}
		}

	}

	/**
	 * constructs propositions map from the add plan response.
	 *
	 * @param line
	 * @return
	 */
	private Map<String, List<PropositionsWithType>> constructPropositionsMap(Line line) {
		logger.debug("Inside CartServiceBpmHelper --> constructPropositionsMap");
		Map<String, List<PropositionsWithType>> propositionsMap = new HashMap<>();
		// add qualified propositions to the map
		if (CollectionUtils.isNotEmpty(line.getQualifiedPropositions())) {
			addToMap(line.getQualifiedPropositions(), PropositionsTypes.QUALIFIED.name(), propositionsMap);
		}
		// add disqualified propositions to the map
		if (CollectionUtils.isNotEmpty(line.getDisqualifiedPropositions())) {
			addToMap(line.getDisqualifiedPropositions(), PropositionsTypes.DISQUALIFIED.name(), propositionsMap);
		}
		return propositionsMap;
	}

	/**
	 * Adds the elements from the propositionsList to the propositionsMap
	 *
	 * @param propositionsList
	 * @param propositionTypeCode
	 * @param propositionsMap
	 */
	private void addToMap(List<Propositions> propositionsList, String propositionTypeCode,
						  Map<String, List<PropositionsWithType>> propositionsMap) {
		logger.debug("Inside CartServiceBpmHelper --> addToMap");
		propositionsList.stream().forEach(propositions -> {
			PropositionsWithType propositionsWithType = constructPropositions(propositions, propositionTypeCode);
			if (Objects.nonNull(propositionsWithType) && Objects.nonNull(propositionsWithType.getOfferTypeCd())) {
				if (propositionsMap.containsKey(propositionsWithType.getOfferTypeCd())) {
					propositionsMap.get(propositionsWithType.getOfferTypeCd()).add(propositionsWithType);
				} else {
					List<PropositionsWithType> propositionsTypeList = new ArrayList<>();
					propositionsTypeList.add(propositionsWithType);
					propositionsMap.put(propositionsWithType.getOfferTypeCd(), propositionsTypeList);
				}
			}
		});
	}

	/**
	 * Constructs proposition with type.
	 *
	 * @param propositions        Propositions
	 * @param propositionTypeCode String
	 * @return PropositionsType
	 */
	private PropositionsWithType constructPropositions(Propositions propositions, String propositionTypeCode) {
		logger.debug("Inside CartServiceBpmHelper --> constructPropositions");
		PropositionsWithType propositionsWithType = new PropositionsWithType();
		propositionsWithType.setDescription(propositions.getDescription());
		propositionsWithType.setOfferTypeCd(propositions.getOfferTypeCd());
		propositionsWithType.setId(propositions.getId());
		propositionsWithType.setActionCode(propositions.getActionCode());
		propositionsWithType.setPriorDQ(propositions.getPriorDQ());
		propositionsWithType.setAmount(propositions.getAmount());
		propositionsWithType.setPropositionsType(propositionTypeCode);
		return propositionsWithType;
	}

	private void setAutoPayGainOrLoss(AddPlanUIResponse addPlanResponse, AtomicBoolean isAutoPayGain, AtomicBoolean isAutoPayLoss, Line line, ConflictedSPO Spo) {
		if ("A".equalsIgnoreCase(Spo.getActionIndicator())) {
			isAutoPayGain.set(true);
			setFeatureChangeDetails(addPlanResponse, line, CartConstants.AUTOPAY_GAIN,
					CartConstants.AUTOPAY, "A");
		}
		if ("D".equalsIgnoreCase(Spo.getActionIndicator())) {
			isAutoPayLoss.set(true);
			setFeatureChangeDetails(addPlanResponse, line, CartConstants.AUTOPAY_LOST,
					CartConstants.AUTOPAY, "D");
		}
		if (isAutoPayGain.get() && isAutoPayLoss.get()) {
			removeFeatureChangeDetails(addPlanResponse);
		}
	}

	/**
	 * Method to set the feature loss and Gain
	 *
	 * @param addPlanResponse
	 * @param line
	 * @param spo
	 * @param featureName
	 * @param featureGain
	 * @param featureLoss
	 */
	private void setFeatureLossOrGain(AddPlanUIResponse addPlanResponse, Line line, ConflictedSPO spo, String featureName, String featureGain, String featureLoss) {
		String featureGainOrLoss = StringUtils.EMPTY;
		if("A".equalsIgnoreCase(spo.getActionIndicator()) && spo.getSuccess() != null && spo.getSuccess()) {
			featureGainOrLoss = featureGain;
		} else if("D".equalsIgnoreCase(spo.getActionIndicator())) {
			featureGainOrLoss = featureLoss;
		}
		if (StringUtilities.isNotEmptyOrNull(featureGainOrLoss)) {
			setFeatureChangeDetails(addPlanResponse, line, featureGainOrLoss, featureName, spo.getActionIndicator());
		}
	}

	private static void setDisneyEnrolled(AddPlanUIResponse addPlanResponse, ConflictedSPO spo) {
		if (CartConstants.DISNEY_ENROLLED_SPOID.equalsIgnoreCase(spo.getId())
				&& "D".equalsIgnoreCase(spo.getActionIndicator())) {
			addPlanResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()
					.setIsDisneyPlusPromoLoss(true);
		}
	}
}


