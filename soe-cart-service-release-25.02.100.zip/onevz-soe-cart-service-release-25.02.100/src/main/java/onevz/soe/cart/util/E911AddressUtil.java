/*package onevz.soe.cart.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import onevz.soe.cart.constants.StreetType;
import onevz.soe.cart.model.common.Address;
import onevz.soe.cart.model.common.ServiceAddress;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;

public class E911AddressUtil {

	private static final Logger logger = LoggerFactory.getLogger(E911AddressUtil.class);
	
	public static ServiceAddress formatE911Address(ServiceAddress e911Address) {
		ServiceAddress newE911Address = new ServiceAddress();
		Address newAddress = new Address();
		if(null != e911Address.getAddress()) {
			Address address = e911Address.getAddress();
			newAddress = e911Address.getAddress();
			if(StringUtilities.isNotEmptyOrNull(address.getAddressLine1())) {
				List<String> splitString = getSplitAddress(address.getAddressLine1());
				List<StreetType> allStreet = Arrays.asList(StreetType.values());
				String streetType = "";
				String streetName = "";
				String apptNo = StringUtilities.isNotEmptyOrNull(address.getApartmentNo())? address.getApartmentNo().trim(): "";		
				newAddress.setApartmentNo(apptNo);
				
				String zipCd = StringUtilities.isNotEmptyOrNull(address.getZipCode())? address.getZipCode().trim(): "";
				newAddress.setZipCode(zipCd);
				if(CollectionUtilities.isNotEmptyOrNull(splitString) && splitString.size() >= 2){
					
					if(StringUtilities.isNotEmptyOrNull(splitString.get(0)))
					newAddress.setStreetNumber(splitString.get(0).trim());
					if(null != splitString.get(splitString.size() - 1) && splitString.get(splitString.size() - 1).length() == 2){
						for(StreetType str : allStreet){
							if(str.getTwoCharName()!=null && str.getTwoCharName().equalsIgnoreCase(splitString.get(splitString.size() -1 ))){
								 streetType =  str.getShortName();
								 break;
							}
						}
						//address.setStreetName(splitAddress.get(1)+" "+streetType);
					}else{
						//address.setStreetName(splitAddress.get(1)+" "+splitAddress.get(2) );
						//address.setStreetNumberSuffix(splitAddress.get(2));
						streetType = splitString.get(splitString.size() - 1);
					}
					newAddress.setType(streetType);
					if(splitString.size() == 2) {
						streetName += splitString.get(1).trim();
						streetType="";
					} else {
						//skim till -1 and append everything in streetname. last one gets added as type.
						for(int i =1; i < splitString.size() - 1; i++){
							streetName += splitString.get(i).trim()+" ";
						}
					}
				    
					if(StringUtilities.isNotEmptyOrNull(streetType) && StringUtilities.isNotEmptyOrNull(streetName)){
						newAddress.setStreetName(streetName.toUpperCase()+streetType.trim().toUpperCase());
					}
					else if(StringUtilities.isNotEmptyOrNull(streetName))
					{
						newAddress.setStreetName(streetName.toUpperCase());
					}
					
					if(StringUtilities.isNotEmptyOrNull(address.getCity())){
						newAddress.setCity(address.getCity().trim().toUpperCase());
					}

					
				}
			}
			
		}
		newAddress.setAddressLine1("");
		newE911Address.setAddress(newAddress);
		return newE911Address;
	}
	
	private static List<String> getSplitAddress(String address) {
		
		if(StringUtilities.isEmptyOrNull(address))
			return null;
		
		ArrayList<String> stringArray = new ArrayList<String>();

        String[] tokens = address.split("\\s+");
        stringArray.ensureCapacity(stringArray.size() + tokens.length); // prevent unnecessary resizes
        for(String s : tokens) {
            if(!s.isEmpty()) stringArray.add(s);
        }
        return stringArray;
	}
}*/
