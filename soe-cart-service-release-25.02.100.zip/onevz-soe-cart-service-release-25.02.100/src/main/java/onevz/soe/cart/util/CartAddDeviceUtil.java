package onevz.soe.cart.util;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import jakarta.annotation.PostConstruct;
import onevz.soe.cart.model.addAccessory.AccessoryAction;
import onevz.soe.cart.model.addAccessory.AddAccContext;
import onevz.soe.cart.model.addAccessory.AddAccServiceBody;
import onevz.soe.cart.model.addAccessory.AddAccServiceResponse;
import onevz.soe.cart.model.addDevice.*;
import onevz.soe.cart.model.clearAndContinue.ClearAndContinueContext;
import onevz.soe.cart.model.clearAndContinue.ClearAndContinueServiceBody;
import onevz.soe.cart.model.clearAndContinue.ClearAndContinueServiceResponse;
import onevz.soe.cart.model.clearCart.ClearCartContext;
import onevz.soe.cart.model.clearCart.ClearCartServiceBody;
import onevz.soe.cart.model.clearCart.ClearCartServiceResponse;
import onevz.soe.cart.model.common.Accessory;
import onevz.soe.cart.model.retrieveCart.CXPLineInfo;
import onevz.soe.cart.model.retrieveCart.CXPRetrieveCartDataVO;
import onevz.soe.cart.responses.FiveGAddressRedisData;
import onevz.soe.cart.ui.responses.AddAccessoriesUIResponse;
import onevz.soe.cart.ui.responses.AddDeviceUIResponse;
import onevz.soe.cart.ui.responses.ClearAndContinueUIResponse;
import onevz.soe.cart.ui.responses.ClearCartUIResponse;
import onevz.soe.channels.SOEChannels;
import onevz.soe.utilities.CollectionUtilities;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.addE911Address.E911Address;
import onevz.soe.cart.model.common.ServiceAddress;
import onevz.soe.cart.model.common.FiveG.BundleDetails;
import onevz.soe.cart.model.common.FiveG.Device;
import onevz.soe.cart.model.common.FiveG.FiveGLTEAddressRedis;
import onevz.soe.cart.model.common.FiveG.Line;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.ui.requests.AddDeviceUIRequest;
import onevz.soe.cart.ui.requests.AddPlanAndDeviceUIRequest;
import onevz.soe.utilities.StringUtilities;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseCookie;
import org.springframework.http.server.reactive.ServerHttpResponse;
import reactor.core.publisher.Mono;

import static onevz.soe.cart.constants.CartConstants.*;

public class CartAddDeviceUtil {

	private static final Logger logger = LoggerFactory.getLogger(CartAddDeviceUtil.class);


	/**
	 * Populates FiveG Address from Redis to Request
	 * @param request
	 * @param redisAddress
	 */
	public static void populateFiveGAddress(AddDeviceUIRequest request, FiveGAddress redisAddress) {
		if (null != request.getData().getLines().get(0).getFiveG()) {
			FiveGAddress requestAddress = new FiveGAddress();
			String eventCorrelationId = "";
			if(null != request.getData().getLines().get(0).getFiveG().getAddress())
				requestAddress = request.getData().getLines().get(0).getFiveG().getAddress();
			if (CartConstants.NSE_5G.equalsIgnoreCase(request.getCartInfo().getIntendType()) || CartConstants.AAL_5G.equalsIgnoreCase(request.getCartInfo().getIntendType()) || null == request.getData().getLines().get(0).getFiveG().getAddress()) {
				if(StringUtilities.isNotEmptyOrNull(requestAddress.getEventCorrelationId()))
					eventCorrelationId = requestAddress.getEventCorrelationId();
				request.getData().getLines().get(0).getFiveG().setAddress(redisAddress);
				requestAddress = redisAddress;
			}
			if(StringUtilities.isNotEmptyOrNull(redisAddress.getAddressLine1()))
				requestAddress.setAddressLine1(redisAddress.getAddressLine1());
			
			else if("AAL".equalsIgnoreCase(request.getCartInfo().getIntendType())) {
				String addressLine1 = "";
				if(null != request.getData().getLines().get(0).getFiveG().getAddress())
					requestAddress = request.getData().getLines().get(0).getFiveG().getAddress();
				else {
					if(StringUtilities.isNotEmptyOrNull(requestAddress.getStreetNumber()))
						addressLine1 = requestAddress.getStreetNumber() +" ";
					if(StringUtilities.isNotEmptyOrNull(requestAddress.getStreetName()))
						addressLine1 += requestAddress.getStreetName() +" ";
					if(StringUtilities.isNotEmptyOrNull(requestAddress.getStreetType()))
						addressLine1 += requestAddress.getStreetType();
					if(StringUtilities.isNotEmptyOrNull(addressLine1))
						requestAddress.setAddressLine1(addressLine1.trim());
				}
			}
			request.getData().getLines().get(0).getFiveG().setAddress(requestAddress);
			
			if (StringUtilities.isNotEmptyOrNull(redisAddress.getLaunchType())) {
				request.getData().getLines().get(0).getFiveG()
						.setLaunchType(redisAddress.getLaunchType());
			}
			if (null != redisAddress.getFixedWirelessRequest()) {
				if (StringUtilities.isNotEmptyOrNull(
						redisAddress.getFixedWirelessRequest().getLatitude()))
					request.getData().getLines().get(0).getFiveG().getAddress().setLatitude(
							redisAddress.getFixedWirelessRequest().getLatitude());
				if (StringUtilities.isNotEmptyOrNull(
						redisAddress.getFixedWirelessRequest().getLongitude()))
					request.getData().getLines().get(0).getFiveG().getAddress().setLongitude(
							redisAddress.getFixedWirelessRequest().getLongitude());
				if (StringUtilities.isNotEmptyOrNull(
						redisAddress.getFixedWirelessRequest().getVendorKey()))
					request.getData().getLines().get(0).getFiveG().getAddress().setBuildingId(
							redisAddress.getFixedWirelessRequest().getVendorKey());
			}
			if(StringUtilities.isNotEmptyOrNull(eventCorrelationId)) {
				request.getData().getLines().get(0).getFiveG().getAddress().setEventCorrelationId(eventCorrelationId);
			}
		}
	}

	/**Is Device Edit for Oneclick
	 *
	 * @param request
	 * @param oneClickCheckout
	 * @return
	 */
	public static boolean isEditDeviceOneClick(AddDeviceUIRequest request, String oneClickCheckout) {
		return StringUtilities.isNotEmptyOrNull(oneClickCheckout) && Boolean.valueOf(oneClickCheckout)
				&& request.getCartInfo().getEditDevice() != null && request.getCartInfo().getEditDevice()
				&& request.getData().getExpressCheckout() != null && request.getData().getExpressCheckout();
	}

	/**
	 * AllowCradle Check.
	 * @param request
	 * @param intent
	 * @return
	 */

	public static boolean AllowCradleCheck(AddDeviceUIRequest request, String intent) {
		return StringUtilities.isNotEmptyOrNull(intent)
				&& (((intent.equalsIgnoreCase(EUP) || intent.equalsIgnoreCase("upgrade"))
						&& StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessingMTN()))
						|| intent.equalsIgnoreCase(AAL) || intent.equalsIgnoreCase("BYOD"))
				&& (request.getCartInfo().getEditDevice() == null
						|| (request.getCartInfo().getEditDevice() != null && !request.getCartInfo().getEditDevice()))
				&& (request.getData().getExpressCheckout() == null
						|| (request.getData().getExpressCheckout() != null && !request.getData().getExpressCheckout()))
				&& (request.getData()!=null && request.getData().getLines()!=null &&
				request.getData().getLines().get(0).getDevice() != null &&
				StringUtilities.isNotEmptyOrNull(request.getData().getLines().get(0).getDevice().getCategory()));
	}

	/**
	 * Logs the E911 address to Kibana
	 * @param address
	 */
	public static void logE911Address(ServiceAddress address) {
		String logMsg = "";
		ObjectMapper mapper = new ObjectMapper();
		if (null != address.getAddress()) {
			try {
				logMsg = mapper.writeValueAsString(address.getAddress());
			} catch (JsonProcessingException e) {
				logger.error("E911Address could not be parsed: {}", e);
			}
		}
		if (StringUtilities.isNotEmptyOrNull(logMsg))
			logger.info("E911Address: {}", logMsg);
	}

	/**
	 * Why Edit Scenario
	 * @param request
	 * @param oneClickCheckout
	 * @return
	 */
	public static boolean isEditDeviceOneClickFiveGFlow(AddPlanAndDeviceUIRequest request, String oneClickCheckout) {
		return StringUtilities.isNotEmptyOrNull(oneClickCheckout) && Boolean.valueOf(oneClickCheckout)
				&& request.getCartInfo().getEditDevice() != null && request.getCartInfo().getEditDevice()
				&& request.getData().getExpressCheckout() != null && request.getData().getExpressCheckout();
	}

	/**
	 * Cradle checks.
	 * @param request
	 * @param intent
	 * @return
	 */
	public static boolean AllowCradleCheckFiveGFlow(AddPlanAndDeviceUIRequest request, String intent) {
		return StringUtilities.isNotEmptyOrNull(intent)
				&& (((intent.equalsIgnoreCase(EUP) || intent.equalsIgnoreCase("upgrade"))
				&& StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessingMTN()))
				|| intent.equalsIgnoreCase(AAL))
				&& (request.getCartInfo().getEditDevice() == null
				|| (request.getCartInfo().getEditDevice() != null && !request.getCartInfo().getEditDevice()))
				&& (request.getData().getExpressCheckout() == null
				|| (request.getData().getExpressCheckout() != null && !request.getData().getExpressCheckout()))
				&& (request.getData()!=null && request.getData().getLines()!=null &&
				StringUtilities.isNotEmptyOrNull(request.getData().getLines().get(0).getDevice().getCategory()));
	}

	/**
	 * Logs the E911 address to Kibana
	 * @param address
	 */
	public static void logE911Address5GFlow(E911Address address) {
		String logMsg = "";
		ObjectMapper mapper = new ObjectMapper();
		if (null != address) {
			try {
				logMsg = mapper.writeValueAsString(address);
			} catch (JsonProcessingException e) {
				logger.error("E911Address could not be parsed: {}", e);
			}
		}
		if (StringUtilities.isNotEmptyOrNull(logMsg))
			logger.info("E911Address: {}", logMsg);
	}

	/**
	 * Popualtes the address from Redis to request.
	 * @param request
	 * @param address
	 * @param data
	 */
	public static void populateFiveGAddressFiveGHomeFlow(AddPlanAndDeviceUIRequest request, FiveGLTEAddressRedis address, CartRedisData data) {

		List<Line> lines = request.getData() != null ? request.getData().getLines() : null;

		if(null == lines || (null != lines && lines.size()<1)) {
			lines = new ArrayList<>();
		}
		FiveGAddress fiveGAdd = new FiveGAddress();
		fiveGAdd.setAddressLine1(address.getAddressLine1());
		fiveGAdd.setAddressLine2(address.getAddressLine2());
		fiveGAdd.setCity(address.getCity());
		fiveGAdd.setState(address.getState());
		fiveGAdd.setZipCode(address.getZipCode());
		fiveGAdd.setLatitude(address.getLatitude());
		fiveGAdd.setLongitude(address.getLongitude());
		fiveGAdd.setFloor(String.valueOf(address.getFloor()));
		fiveGAdd.setFipsCode(address.getFipsCode());
		fiveGAdd.setBuildingId(address.getBuildingId());
		fiveGAdd.setStreetName(address.getStreetName());
		fiveGAdd.setStreetNumber(address.getStreetNumber());
		fiveGAdd.setStreetType(address.getStreetType());
		fiveGAdd.setEmailId(address.getEmailAddress());
		fiveGAdd.setPhoneNumber(address.getCbr());
		fiveGAdd.setEventCorrelationId(data.getEventCorrelationId());
		fiveGAdd.setAddressIdNumber(address.getAddressId());
		if("TGW".equalsIgnoreCase(request.getCartInfo().getNetworkBandwidthType())) {
			fiveGAdd.setBaselocationId(address.getAddressId());
			fiveGAdd.setLocationId(address.getLocationId());
		}
		if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getAddressRecordIdentifier()) || "Y".equalsIgnoreCase(request.getCartInfo().getBulkQualIndicator())){
			fiveGAdd.setEventCorrelationId(address.getEventCorrelationId());
		}
		if(StringUtilities.isNotEmptyOrNull(address.getStreetDirection())) {
			fiveGAdd.setStreetDirection(address.getStreetDirection());
		}else{
			fiveGAdd.setStreetDirection("");
		}
		lines.forEach(line -> {
			FiveG fiveG = new FiveG();
			fiveG.setAddress(fiveGAdd);
			if(!CartConstants.HELPER_ACCESSORIES.equalsIgnoreCase(request.getCartInfo().getProcessStep())
					&& !CartConstants.INTENT_EUP_LTE.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
				line.setFiveG(fiveG);
			}
			line.setMtn(request.getCartInfo().getProcessingMTN());
			line.setIsNewLine(true);
			line.setNewLineOrAAL(true);
			if(CartConstants.INTENT_EUP_LTE.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
				line.setIsLTEDevice(true);
				line.setIsEdgeBuyOut(true);
			}
			if(!CartConstants.HELPER_ACCESSORIES.equalsIgnoreCase(request.getCartInfo().getProcessStep())
					&& !CartConstants.NSE_LTE.equalsIgnoreCase(request.getCartInfo().getIntendType())
					&& !CartConstants.AAL_LTE.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
				request.getData().setEligible5GHomeBundle(address.getBundleList());
			}

			// populate device details
			Device device = new Device();
			if(null != request.getCartInfo().getBundleInstallType()
					&& ((CartConstants.LAUNCHTYPE_FCL.equalsIgnoreCase(address.getLaunchType()) && request.getCartInfo().getIntendType().contains("5G"))
					|| "true".equalsIgnoreCase(address.getIsD2DFlow())
					|| "TGW".equalsIgnoreCase(request.getCartInfo().getNetworkBandwidthType())
					|| ("true".equalsIgnoreCase(request.getCartInfo().getCrmResumeCartFlow()) && request.getCartInfo().getIntendType().contains("5G")))
					&& !CartConstants.HELPER_ACCESSORIES.equalsIgnoreCase(request.getCartInfo().getProcessStep()) && null != address.getBundleList()) {
                address.getBundleList().stream().filter(bundleDetails ->
                    request.getCartInfo().getBundleInstallType().equalsIgnoreCase(bundleDetails.getBundleName())).findFirst().ifPresent(bundleDetails -> {
                    device.setId(bundleDetails.getId());
                    device.setContractTerm(CartConstants.FIVEG_CONTRACT_TERM);
                    device.setNetworkBandwidthType(request.getCartInfo().getNetworkBandwidthType());
                });
				line.setDevice(device);
            }
			else if((Boolean.valueOf(address.getLTEHomeQualified()) && !CartConstants.HELPER_ACCESSORIES.equalsIgnoreCase(request.getCartInfo().getProcessStep()))||
					CartConstants.INTENT_EUP_LTE.equalsIgnoreCase(request.getCartInfo().getIntendType()) || "CBD".equalsIgnoreCase(request.getCartInfo().getNetworkBandwidthType())) {
                device.setId(address.getLTEHomeSku());
				if(CartConstants.INTENT_EUP_LTE.equalsIgnoreCase(request.getCartInfo().getIntendType())){
					device.setId(CartConstants.LTE_UPGRADE_SKU);// TO BE REMOVED AFTER CUSTOM GW SKU DONE
				}
                device.setNetworkBandwidthType(request.getCartInfo().getNetworkBandwidthType());
                if(StringUtilities.isNotEmptyOrNull(request.getCartInfo().getPriceType())) {
					device.setContractTerm(request.getCartInfo().getPriceType());
					if("VERIZON_EDGE".equalsIgnoreCase(request.getCartInfo().getPriceType())) {
						if(StringUtilities.isNotEmptyOrNull(device.getDppMonths())) {
							device.setDppMonths(request.getCartInfo().getDppMonths());
						} else {
							device.setDppMonths("24");
						}
					} else {
						device.setDppMonths("");
					}
				}
				if("CBD".equalsIgnoreCase(request.getCartInfo().getNetworkBandwidthType()) || "LTE".equalsIgnoreCase(request.getCartInfo().getNetworkBandwidthType()))
					device.setContractTerm(CartConstants.FIVEG_CONTRACT_TERM);
				if(CartConstants.TECH_CBD_INTENT.equalsIgnoreCase(data.getIntendType())) {
					device.setDefaultPlanType(request.getCBandData().getFiveGPlan());
				}
                device.setActionIndicator(CartConstants.LTE_ACTION_INDICATOR);
                device.setType(CartConstants.SPO);
                line.setDevice(device);
            }
			if(CartConstants.LTE_CBD_TRANSACTIONTYPE.equalsIgnoreCase(request.getCartInfo().getTransactionType())
					&& CartConstants.EUP_5G.equalsIgnoreCase(request.getCartInfo().getIntendType())){
				device.setNetworkBandwidthType("CBD");
				device.setDefaultPlanType("5GHENTRY");
			}
			if(request.getCartInfo().getBundleInstallType() != null){
				String bundleInstallType = request.getCartInfo().getBundleInstallType();
				List<BundleDetails> bundleDetailsList = address.getBundleList();
				if(bundleInstallType.toLowerCase().contains("cbandprofsetup")){
					device.setSorType("BUNDLE");
					device.setId(bundleDetailsList.get(1).getId());
				}
			}
			//ACT141-1628
			boolean is5GFlow = request.getCartInfo().getIntendType().endsWith("_5G") || ((CartConstants.NSE_LTE).equalsIgnoreCase(request.getCartInfo().getIntendType())) || ((CartConstants.AAL_LTE).equalsIgnoreCase(request.getCartInfo().getIntendType()));
			if (StringUtilities.isNotEmptyOrNull(data.getLvSoftSku()) && StringUtilities.isNotEmptyOrNull(line.getDepletionType()) && !line.getDepletionType().equalsIgnoreCase(CartConstants.O) && is5GFlow){
				AccessoryAction accessoryAction = new AccessoryAction();
				Accessory accessory = new Accessory();
				accessory.setId(data.getLvSoftSku());
				accessory.setQty("1");
				accessory.setIsSoftSku(true);
				Accessory[] accessoryList = {accessory};
				accessoryAction.setAdd(accessoryList);
				line.setAccessories(accessoryAction);
			}
		});
		request.setEmailAddress(address.getEmailAddress());/*MVP2*/
		request.setCbr(address.getCbr());
	}

	/**
	 * Populates Gen2 To Gen3 SWAP flow address
	 * @param request
	 * @param address
	 */
	public static void populateSwapFiveGAddressFlow(AddPlanAndDeviceUIRequest request, FiveGLTEAddressRedis address) {
		List<Line> lines = request.getData().getLines();
		if (null == lines || (null != lines && lines.size() < 1)) {
			lines = new ArrayList<>();
		}
		FiveGAddress fiveGAdd = new FiveGAddress();
		fiveGAdd.setAddressLine1(address.getAddressLine1()!=null?address.getAddressLine1():StringUtils.EMPTY);
		fiveGAdd.setAddressLine2(address.getAddressLine2()!=null?address.getAddressLine2():StringUtils.EMPTY);
		fiveGAdd.setCity(address.getCity()!=null?address.getCity():StringUtils.EMPTY);
		fiveGAdd.setState(address.getState()!=null?address.getState():StringUtils.EMPTY);
		fiveGAdd.setZipCode(address.getZipCode()!=null?address.getZipCode():StringUtils.EMPTY);
		fiveGAdd.setFloor(address.getFloor()!=null?String.valueOf(address.getFloor()):StringUtils.EMPTY);
		fiveGAdd.setFipsCode(address.getFipsCode()!=null?address.getFipsCode():StringUtils.EMPTY);
		lines.forEach(line -> {
			FiveG fiveG = new FiveG();
			fiveG.setAddress(fiveGAdd);
			line.setFiveG(fiveG);
			line.setIsNewLine(false);
			line.setNewLineOrAAL(false);
			line.setIsLTEDevice(false);
			request.getData().setEligible5GHomeBundle(address.getBundleList());
			request.getCartInfo().setD2dFlag("N");
			// populate device details
			Device device = new Device();
			List<BundleDetails> bundleIds = address.getBundleList();
			if (null != bundleIds && bundleIds.size() > 0) {
				bundleIds.stream().findFirst().ifPresent(bundleDetails -> {
					device.setId(bundleDetails.getId());
				});
			}
			device.setNetworkBandwidthType("MMW");
			device.setContractTerm(CartConstants.FIVEG_CONTRACT_TERM);
			device.setSorType(CartConstants.EUP_5G_BUNDLE);
			line.setDevice(device);
		});
		request.getData().setLines(lines);
	}

	public static void checkAndUpdateNetworkBdType(CartRedisData data, AddDeviceUIRequest request, FiveGAddressRedisData address){

		List<String> fiveGIntendTypes = new ArrayList<>(Arrays.asList(CartConstants.AAL_5G, CartConstants.AAL_LTE, CartConstants.NSE_5G, CartConstants.NSE_LTE));

		boolean isFiveGIntendType = request.getCartInfo() != null && request.getCartInfo().getIntendType() != null
				&& fiveGIntendTypes.contains(request.getCartInfo().getIntendType());

		boolean homeSalesAddressNotNull = data != null && data.getIsHomeSales() != null && data.getIsHomeSales().equalsIgnoreCase("true") &&
				data.getHomeSalesAddress() != null;

		boolean requestLinesPresent = request.getData() != null &&
		CollectionUtilities.isNotEmptyOrNull( request.getData().getLines()) && request.getData().getLines().get(0).getDevice() != null;

		boolean fiveGAddressNotNull = address != null && address.getAddressRequest() != null;

		boolean isLTEQualified = (fiveGAddressNotNull && address.getAddressRequest().isLTEQualified())
				|| (homeSalesAddressNotNull && data.getHomeSalesAddress().isLTEQualified());

		if(requestLinesPresent && data != null &&  (isFiveGIntendType || isDeviceType5G(request, data))
				&&  StringUtilities.isEmptyOrNull(request.getData().getLines().get(0).getDevice().getNetworkBandwidthType())){

			checkAndUpdateFiveGNBT(request,address,isLTEQualified, fiveGAddressNotNull);

			if(StringUtilities.isEmptyOrNull(request.getData().getLines().get(0).getDevice().getNetworkBandwidthType()) && homeSalesAddressNotNull){
				checkAndUpdateHomeSalesFiveGNBT(data,request);

			}
		}
	}

	public static void checkAndUpdateHomeSalesFiveGNBT(CartRedisData data,AddDeviceUIRequest request){
		if(data.getHomeSalesAddress().isCBandQualified()) {
			request.getData().getLines().get(0).getDevice().setNetworkBandwidthType("CBD");
		} else if (data.getHomeSalesAddress().isFiveGHomeQualified()) {
			request.getData().getLines().get(0).getDevice().setNetworkBandwidthType("MMW");
		}
	}
	public static void checkAndUpdateFiveGNBT(AddDeviceUIRequest request,FiveGAddressRedisData address,boolean isLTEQualified,boolean fiveGAddressNotNull){
		if((request.getCartInfo().getIntendType().equalsIgnoreCase(CartConstants.AAL_LTE) ||
				request.getCartInfo().getIntendType().equalsIgnoreCase(CartConstants.NSE_LTE))
				|| isLTEQualified){
			request.getData().getLines().get(0).getDevice().setNetworkBandwidthType("LTE");
		}else if(fiveGAddressNotNull){
			if(address.getAddressRequest().isCBandQualified()) {
				request.getData().getLines().get(0).getDevice().setNetworkBandwidthType("CBD");
			} else if (address.getAddressRequest().isFiveGHomeQualified()) {
				request.getData().getLines().get(0).getDevice().setNetworkBandwidthType("MMW");
			}
		}
	}

	public static boolean isDeviceType5G(AddDeviceUIRequest request, CartRedisData sessionResponse) {

		boolean mtnNotEmptyOrNull = StringUtilities.isNotEmptyOrNull(request.getData().getLines().get(0).getMtn());
		if (mtnNotEmptyOrNull && sessionResponse.getRetrieveCart() != null
				&& isCartHasLine(sessionResponse.getRetrieveCart())) {

			return Arrays.stream(sessionResponse.getRetrieveCart().getCart().getLineDetails().getLineInfo())
					.filter(cxpLineInfo -> null != cxpLineInfo
							&& StringUtilities.isNotEmptyOrNull(cxpLineInfo.getMobileNumber())
							&& cxpLineInfo.getMobileNumber().equalsIgnoreCase(request.getData().getLines().get(0).getMtn()))
					.anyMatch(CartAddDeviceUtil::isFiveGLine);

		}
		return false;
	}
	public static boolean isCartHasLine(CXPRetrieveCartDataVO cart) {

		return (cart.getCart() != null
				&& cart.getCart().getLineDetails() != null
				&& cart.getCart().getLineDetails().getLineInfo() != null
				&& cart.getCart().getLineDetails().getLineInfo().length > 0);
	}
	public static boolean isFiveGLine(CXPLineInfo line) {
		List<String> fiveGIntendTypes = new ArrayList<>(Arrays.asList(CartConstants.AAL_5G, CartConstants.AAL_LTE, CartConstants.NSE_5G, CartConstants.NSE_LTE));
		return (fiveGIntendTypes.contains(line.getLineActivityType()) || CartConstants.FIVE_G_INTERNET.equalsIgnoreCase(line.getDeviceTypeSelected()));
	}
	public static boolean pegaResponseEmptyOrNot(AddDeviceUIResponse pegaAddDeviceResp) {
		return pegaAddDeviceResp!=null && pegaAddDeviceResp.getServiceBody()!=null
				&& pegaAddDeviceResp.getServiceBody().getServiceResponse()!=null
				&& pegaAddDeviceResp.getServiceBody().getServiceResponse().getContext()!=null
				&& pegaAddDeviceResp.getServiceBody().getServiceResponse().getContext().getCartInfo()!=null;
	}

	public static void createCookieCartCount(ServerHttpResponse httpResponse, AddDeviceUIResponse pegaResponse, String cartCount, List<String> domainsList) {
		if(domainsList!=null){
			for (String domainName : domainsList){
				Optional.ofNullable(pegaResponse.getServiceBody())
						.map(AddDeviceServiceBody::getServiceResponse)
						.map(AddDeviceServiceResponse::getContext)
						.map(AddDeviceContext::getCartInfo)
						.ifPresent(cartInfo -> httpResponse.addCookie(ResponseCookie.from(cartCount, String.valueOf(cartInfo.getCartItemCount())).path("/").domain(domainName).httpOnly(false).build()));
			}
		}
	}

	public static void createCookieCartCountClearAndContinue(ServerHttpResponse httpResponse, ClearAndContinueUIResponse pegaResponse, String cartCount, List<String> domainsList) {
		if(domainsList!=null){
			for (String domainName : domainsList){
				Optional.ofNullable(pegaResponse.getServiceBody())
						.map(ClearAndContinueServiceBody::getServiceResponse)
						.map(ClearAndContinueServiceResponse::getContext)
						.map(ClearAndContinueContext::getCartInfo)
						.ifPresent(cartInfo -> httpResponse.addCookie(ResponseCookie.from(cartCount, String.valueOf(cartInfo.getCartItemCount())).path("/").domain(domainName).httpOnly(false).build()));
			}
		}
	}

	public static void createCookieCartCountAccessories(ServerHttpResponse httpResponse, AddAccessoriesUIResponse pegaResponse, String cartCount, List<String> domainsList) {
		if(domainsList!=null){
			for (String domainName : domainsList){
				Optional.ofNullable(pegaResponse.getServiceBody())
						.map(AddAccServiceBody::getServiceResponse)
						.map(AddAccServiceResponse::getContext)
						.map(AddAccContext::getCartInfo)
						.ifPresent(cartInfo -> httpResponse.addCookie(ResponseCookie.from(cartCount, String.valueOf(cartInfo.getCartItemCount())).path("/").domain(domainName).httpOnly(false).build()));
			}
		}
	}
	public static void createClearCartCookies(ServerHttpResponse httpResponse, ClearCartUIResponse pegaResponse, String cartCount, List<String> domainsList) {
		if(domainsList!=null){
			for (String domainName : domainsList){
				Optional.ofNullable(pegaResponse.getServiceBody())
						.map(ClearCartServiceBody::getServiceResponse)
						.map(ClearCartServiceResponse::getContext)
						.map(ClearCartContext::getCartInfo)
						.ifPresent(cartInfo -> httpResponse.addCookie(ResponseCookie.from(cartCount, String.valueOf(cartInfo.getCartItemCount())).path("/").domain(domainName).httpOnly(false).maxAge(-1).build()));
			}
		}
	}
}