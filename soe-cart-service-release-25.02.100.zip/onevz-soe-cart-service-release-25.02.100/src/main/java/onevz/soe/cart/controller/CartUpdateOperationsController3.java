package onevz.soe.cart.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.vzw.cradle.util.CradleConstants;
import com.vzw.cradle.util.CradleUtil;

import onevz.cxp.feature.util.FeatureFlag;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.constants.FeatureFlagConstants;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper2;
import onevz.soe.cart.cxp.helper.CatalogServiceHelper;
import onevz.soe.cart.exceptions.JsonValidator;
import onevz.soe.cart.helper.*;
import onevz.soe.cart.model.addAccessory.AddAccContext;
import onevz.soe.cart.model.addAccessory.AddAccServiceBody;
import onevz.soe.cart.model.addAccessory.AddAccServiceResponse;
import onevz.soe.cart.model.addDevice.AddDeviceContext;
import onevz.soe.cart.model.addDevice.AddDeviceServiceBody;
import onevz.soe.cart.model.addDevice.AddDeviceServiceResponse;
import onevz.soe.cart.model.catalog.FeatureCatalogItem;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.createLine.CreateLineContext;
import onevz.soe.cart.model.createLine.CreateLineServiceBody;
import onevz.soe.cart.model.createLine.CreateLineServiceResponse;
import onevz.soe.cart.model.myOffer.MyOfferLine;
import onevz.soe.cart.model.myOffer.Offer;
import onevz.soe.cart.model.removeLines.RemoveLinesContext;
import onevz.soe.cart.model.removeLines.RemoveLinesServiceBody;
import onevz.soe.cart.model.removeLines.RemoveLinesServiceResponse;
import onevz.soe.cart.model.retrieveCart.CXPCartVO;
import onevz.soe.cart.model.validateCart.CXPValidateCartDataVO;
import onevz.soe.cart.omnidl.OmniBuilder;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.ui.common.AddDeviceData;
import onevz.soe.cart.ui.common.CreateLineData;
import onevz.soe.cart.ui.common.DownPaymentData;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.cart.util.*;
import onevz.soe.cradle.constant.Constants;
import onevz.soe.logging.util.LoggerUtil;
import onevz.soe.omnidl.service.OmniDLService;
import onevz.soe.omnidl.util.DLUtilityService;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.session.constants.SessionConstants;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.utilities.serialization.JacksonMapperFactory;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.util.CollectionUtils;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import jakarta.validation.Valid;
import java.io.UnsupportedEncodingException;
import java.time.Duration;
import java.util.*;

@RestController
@RequestMapping(value = "cart")
public class CartUpdateOperationsController3 {

    private static final Logger logger = LoggerFactory.getLogger(CartUpdateOperationsController.class);


    @Autowired
    private RedisHelper redisHelper;
    @Autowired
    private RedisHelper2 redisHelper2;

    @Autowired
    private CatalogServiceHelper catalogServiceHelper;

    @Autowired
    private CartServiceCxpHelper2 cartServiceCxpHelper2;
    @Autowired
    private RedisHelper3 redisHelper3;
    @Autowired
    JsonValidator validator;
    @Autowired
    private UpdateCartHelper helper;
    @Autowired
    private CartAddDeviceHelper deviceHelper;
    @Autowired
    private FeatureFlag featureFlag;
    @Autowired
    private OmniDLHelper omniDlHelper;
    @Autowired
    private FeatureFlagHelper featureFlagHelper;

    @Value("${soe.quickshop.enableQuickShopFlow:false}")
    private boolean enableQuickShopFlow;
    @Value("#{'${sessionCreation.domains:.verizon.com}'.split(',')}")
    private List<String> domains;

    @Autowired
    private CartAddDeviceHelper1 deviceHelper2;
    @Autowired
    private ObjectMapper mapper;

    @Autowired
    private CartServiceCxpHelper cxpHelper;
    @Autowired
    private DLUtilityService dlUtilityService;
    @Autowired
    private OmniDLService dlService;
    @Autowired
    private OmniDLHelperForAIQuote dlHelper;
    private final List<String> prospectHubCartCookieTrueList = Arrays.asList(CartConstants.ACCESSORIES_INTERSTIAL, CartConstants.PROMO_HUB,
            CartConstants.PROMO_BUNDLE_BUILDER, CartConstants.PLAN_PROMO_RECOMMENDATION);
    private final List<String> prospectHubCartCookieTruePageList  = Arrays.asList(CartConstants.NEW_RECOMMENDED_PLAN_SELECTION, CartConstants.BYOD_LANDING_PAGE);

    private final List<String> cradleFlowJourneyList = Arrays.asList(CartConstants.NEXT_GEN, CartConstants.SHUBV2);
    @Value("${enableSecurityForCart}")
    private boolean enableSecurityForCart;
    @Value("${redemptionCode}")
    private String redemptionCode;
    @Autowired
    private TradeInHelper tradeInHelper;
    @Autowired
    private CartAccessoryHelper accessoryHelper;
    @Autowired
    private Environment env;
    @Autowired
    private CartAccessoryLoggingHelper cartAccessoryLoggingHelper;
    @Autowired
    private CradleHelper cradleHelper;
    @Value("${xboxTrialPage:false}")
    private boolean xboxTrialPage;
    @Autowired
    SOELoginSessionBean soeLoginSessionBean;

    @Value("${soe.digital.recaptcha.whiteListedIps:}")
    private List<String> captchaWhileListedIps;

    @Value("${maxDurationForCookie:14}")
    private String maxDurationForCookie;
    @Value("${maxDurationForMVACookie:30}")
    private String maxDurationForMVACookie;

    @InitBinder("*")
    public void initBinderByName(WebDataBinder binder) {
        binder.setDisallowedFields(new String[]{"genericHeader"});
    }


    public Mono<Boolean> updateOfferDataIntoRedis(AddDeviceUIRequest request) {
        logger.info("Inside updateOfferDataIntoRedis");
        if (null != request && null != request.getData() && CollectionUtilities.isNotEmptyOrNull(request.getData().getLines()) &&
                null != request.getData().getLines().get(0) && CollectionUtilities.isNotEmptyOrNull(request.getData().getLines().get(0).getSelectedOffers())
                && null != request.getData().getLines().get(0).getSelectedOffers().get(0)) {
            MyOfferETRRedisData ocpbOffer = new MyOfferETRRedisData();
            List<MyOfferLine> offerLines = new ArrayList<>();
            MyOfferLine line = new MyOfferLine();

            Lines lines = request.getData().getLines().get(0);
            line.setMtn(lines.getMtn());

            List<Offer> offers = new ArrayList<>();
            Offer offer = new Offer();
            offer.setSku(lines.getSelectedOffers().get(0).getId());
            offer.setDescription(lines.getSelectedOffers().get(0).getDescription());

            String offerType = "";
            String subType = StringUtilities.isNotEmptyOrNull(lines.getSelectedOffers().get(0).getSubType()) ?
                    lines.getSelectedOffers().get(0).getSubType().toUpperCase() : "";

            switch (subType) {
                case "TRADE":
                    offerType = "TRADEIN";
                    break;
                case "SIMPLE":
                    offerType = "BIC";
                    break;
                case "MULTI LINE BOGO":
                    offerType = "BOGO";
                    break;
                case "MULTI LINE BMSM":
                    offerType = "BMSM";
                    break;
                default:
                    offerType = "OFFERS";
                    break;
            }
            String delimiter = "_";
            offer.setOfferType(subType);
            offers.add(offer);
            line.setOffers(offers);
            offerLines.add(line);
            ocpbOffer.setLines(offerLines);
            if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getOfferSourceSystem()))
                ocpbOffer.setOfferSourceSystem(String.join(delimiter, request.getCartInfo().getOfferSourceSystem(), offerType));
            return redisHelper2.updatePromoFirstOfferData(ocpbOffer).flatMap(data -> {
                return Mono.just(data);
            });
        }
        return Mono.just(true);
    }

    private Mono<ResponseEntity<GenericResponse>> formatTradeIn(AddDeviceUIRequest request, ServerHttpResponse httpResponse) {
        return tradeInHelper.validateAndAddTrade(request, httpResponse).flatMap(tradeRes -> {
            ErrorResponse tradeError1 = null;
            if (tradeRes.getErrors() != null) {
                tradeError1 = CartPegaResponseErrorsUtil.handleAddDeviceResponseErrors(tradeRes);
                return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(tradeError1));
            } else {
                return updateOfferDataIntoRedis(request).flatMap(data -> {
                    return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(tradeRes));
                });
            }
        });
    }

    @PostMapping({"/billing-address", "/nse/billing-address"})
    public Mono<ResponseEntity<GenericResponse>> addBillingAddress(ServerHttpRequest httpHeader,
                                                                   ServerHttpResponse httpResponse, @Valid @RequestBody BillingAddressUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "billing-address");
        logger.debug("billingAddress Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);
        String sessionId = "";
        HttpCookie cookieDigitIgSession = httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION);
        if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId))
                || CartConstants.EXPRESS_STORE.equalsIgnoreCase(CartUtil.getChannelType(channelId)))
            sessionId = null != cookieDigitIgSession
                    ? cookieDigitIgSession.getValue()
                    : "";

        request.getCartInfo().setSessionId(sessionId);

        ErrorResponse errors = CartPegaRequestErrorsUtil.handleBillingAddressRequestErrors(request);
        if (errors.getErrors() != null)
            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
        return helper.addBillingAddress(request).map(pegaResponse -> {
            ErrorResponse errors2 = null;
            if (pegaResponse.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil.handleBillingAddressResponseErrors(pegaResponse);
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(pegaResponse);
        });
    }

    @PostMapping({"/number-share", "/nse/number-share"})
    public Mono<ResponseEntity<GenericResponse>> numberShare(ServerHttpRequest httpHeader,
                                                             ServerHttpResponse httpResponse, @Valid @RequestBody NumberShareUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "number-share");
        logger.debug("number-share Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);
        String sessionId = "";
        HttpCookie cookieDigitIgSession = httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION);
        if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId))
                || CartConstants.EXPRESS_STORE.equalsIgnoreCase(CartUtil.getChannelType(channelId)))
            sessionId = null != cookieDigitIgSession
                    ? cookieDigitIgSession.getValue()
                    : "";
        request.getCartInfo().setSessionId(sessionId);
        if (CartConstants.NSE.equals(request.getCartInfo().getIntendType())
                && CartConstants.VZW_DOTCOM.equals(channelId)) {
            request.getCartInfo().setCartCreator(sessionId);
            request.getCartInfo().setGlobalId(sessionId);
        }
        ErrorResponse errors = CartPegaRequestErrorsUtil.handleNumberShareRequestErrors(request);
        if (errors.getErrors() != null)
            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
        return helper.numberShare(request).map(pegaResponse -> {
            ErrorResponse errors2 = null;
            if (pegaResponse.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil.handleNumberShareResponseErrors(pegaResponse);
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(pegaResponse);
        });
    }

    @PostMapping("/deviceSimId")
    public Mono<ResponseEntity<GenericResponse>> updateDeviceSIMId(ServerHttpRequest httpHeader,
                                                                   ServerHttpResponse httpResponse, @Valid @RequestBody UpdateDeviceSIMIdUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "deviceSimId");
        logger.debug("update-cart Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);
        ErrorResponse errors = CartPegaRequestErrorsUtil.handleUpdateDeviceSimIdRequestErrors(request);
        if (errors.getErrors() != null)
            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));

        logger.debug("update-cart Request: {}", request);
        return helper.updateDeviceSIMId(request).map(pegaResponse -> {
            ErrorResponse errors2 = null;
            if (pegaResponse.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil.handleUpdateDeviceSimIdResponseErrors(pegaResponse);
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(pegaResponse);
        });

    }

    @PostMapping({"/add-downpayment", "/nse/add-downpayment"})
    public Mono<ResponseEntity<GenericResponse>> addDownPayment(ServerHttpRequest httpHeader,
                                                                ServerHttpResponse httpResponse, @Valid @RequestBody DownPaymentUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "add-downpayment");
        logger.debug("add-downpayment Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);
        String sessionId = "";
        HttpCookie cookieDigitIgSession = httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION);
        if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId))
                || CartConstants.EXPRESS_STORE.equalsIgnoreCase(CartUtil.getChannelType(channelId)))
            sessionId = null != cookieDigitIgSession
                    ? cookieDigitIgSession.getValue()
                    : "";

        request.getCartInfo().setSessionId(sessionId);
        ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDownPaymentRequestErrors(request);
        if (errors.getErrors() != null)
            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));

        if (StringUtilities.isNotEmptyOrNull(channelId) && channelId.contains(CartConstants.OMNI_INDIRECT)) {
            try {
                double sellerPrice = 0.0;
                double downpayment = 0.0;
                int termValue = 36;
                if (request != null && request.getData() != null && ArrayUtils.isNotEmpty(request.getData().getLines())) {
                    for (Lines line : request.getData().getLines()) {
                        if (StringUtilities.isNotEmptyOrNull(String.valueOf(line.getSellerPrice()))) {
                            sellerPrice = line.getSellerPrice();
                        }
                        if (line.getDownPayment() != null && StringUtilities.isNotEmptyOrNull(String.valueOf(line.getDownPayment().getUserSelectedAmount()))) {
                            downpayment = line.getDownPayment().getUserSelectedAmount();
                        }
                        else if (line.getDownPayment() != null && StringUtilities.isNotEmptyOrNull(String.valueOf(line.getDownPayment().getAmount()))) {
                            downpayment = line.getDownPayment().getAmount();
                        }
                        if ((((sellerPrice - downpayment) * 100) / termValue) < 1) {
                            double minLoanAmount = termValue / 100.0;
                            String errMsg = "Minimum loan amount price allowed is $" + minLoanAmount + " for the line:" + line.getMtn();
                            ErrorResponse errorresp = CartPegaRequestErrorsUtil.handleSoeServiceValidationErrors("addDownPayment", errMsg, "sellerPrice", String.valueOf(sellerPrice));
                            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorresp));
                        }
                    }
                }


            } catch (Exception e) {
                logger.error("Exception while Dp calculation");
            }
        }
        return helper.addDownPayment(request).map(pegaResponse -> {
            ErrorResponse errors2 = null;
            if (pegaResponse.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil.handleAddDownPaymentResponseErrors(pegaResponse);
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(pegaResponse);
        });
    }

    @PostMapping("/removeEdgeUp")
    public Mono<ResponseEntity<GenericResponse>> removeEdgeUp(ServerHttpRequest httpHeader,
                                                              ServerHttpResponse httpResponse, @Valid @RequestBody UpdateEdgeupUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "removeEdgeUp");
        logger.debug("removeEdgeUp Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);

        ErrorResponse errorResponse = CartPegaRequestErrorsUtil.handleRemoveEdgeUpRequestErrors(request);
        if (CollectionUtilities.isNotEmptyOrNull(errorResponse.getErrors())) {
            ErrorResponse errors = validator.convertObjectToString(errorResponse);
            if (null != errors) {
                return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
            }
        }
        return helper.removeEdgeup(request).map(pegaResponse -> {
            ErrorResponse errors2 = null;
            if (pegaResponse.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil.handleUpdateEdgeUpResponseErrors(pegaResponse);
            } else {
                if (request.getCartInfo().getIntendType().equals(CartConstants.EUP)
                        && null != pegaResponse.getServiceBody()
                        && null != pegaResponse.getServiceBody().getServiceResponse()
                        && null != pegaResponse.getServiceBody().getServiceResponse().getContext()
                        && null != pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()
                        && pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()
                        .getIsEmptyLine() != null
                        && pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()
                        .getIsEmptyLine()) {
                    RemoveLinesUIRequest removeLinesUIrequest = mapper.convertValue(request,
                            RemoveLinesUIRequest.class);
                    removeLinesUIrequest = CartPegaRequestUtil6.formatRemoveLinesUIRequest(removeLinesUIrequest);
//                    helper.removeLines(removeLinesUIrequest).map(resp -> {
//                        ErrorResponse errors3 = null;
//                        if (resp.getErrors() != null) {
//                            errors3 = CartPegaResponseErrorsUtil.handleRemoveLinesResponseErrors(resp);
//                        } else {
//                            Optional.ofNullable(resp.getServiceBody()).map(RemoveLinesServiceBody::getServiceResponse)
//                                    .map(RemoveLinesServiceResponse::getContext).map(RemoveLinesContext::getCartInfo)
//                                    .map(CartServiceCartInfo::getStatusMsg).ifPresent(statusMsg -> {
//                                        if (StringUtilities.isNotEmptyOrNull(statusMsg)
//                                                && (CartConstants.REMOVE_LINES_SUCCESS.equalsIgnoreCase(statusMsg)
//                                                || CartConstants.REMOVE_DEVICE_SUCCESS
//                                                .equalsIgnoreCase(statusMsg))) {
//                                            // this subscribe has to be removed.
//                                            redisHelper.deleteAddDeviceDataFromRedis(CartConstants.ADD_DEVICE_REQUEST)
//                                                    .subscribeOn(Schedulers.parallel()).subscribe(deleted -> {
//                                                        logger.info("addDeviceData deleted from Redis {}", deleted);
//                                                    });
//                                        }
//                                    });
//                        }
//                        return errors3 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors3)
//                                : ResponseEntity.status(HttpStatus.OK).body(pegaResponse);
//                    });
                }
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(pegaResponse);
        });

    }

    @PostMapping("/add-edgeup")
    public Mono<ResponseEntity<GenericResponse>> addEdgeUp(ServerHttpRequest httpHeader,
                                                           ServerHttpResponse httpResponse, @Valid @RequestBody UpdateEdgeupUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "add-edgeup");
        logger.debug("add-edgeup Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);

        ErrorResponse errorResponse = CartPegaRequestErrorsUtil.handleAddEdgeUpRequestErrors(request);
        if (CollectionUtilities.isNotEmptyOrNull(errorResponse.getErrors())) {
            ErrorResponse errors = validator.convertObjectToString(errorResponse);
            if (null != errors) {
                return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
            }
        }
        return helper.addEdgeup(request).map(pegaResponse -> {
            ErrorResponse errors2 = null;
            if (pegaResponse.getErrors() != null && !httpResponse.getStatusCode().is2xxSuccessful()) {
                errors2 = CartPegaResponseErrorsUtil.handleUpdateEdgeUpResponseErrors(pegaResponse);
            } else if ("M".equalsIgnoreCase(request.getCartInfo().getMtnFlow())) {
                CartRedisData rr = new CartRedisData();
                rr.setEdgeUpData(request.getData());
                rr.setCartInfo(request.getCartInfo());
                redisHelper2.upsertEdgeBuyoutDataIntoRedis(request.getCartInfo().getProcessingMTN(), rr)
                        .subscribeOn(Schedulers.parallel()).subscribe(data -> {
                            logger.info("EdgeUpData upserted successfully");
                        });
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(httpResponse.getStatusCode()).body(pegaResponse);
        });

    }

    @PostMapping("/add-buyout")
    public Mono<ResponseEntity<GenericResponse>> addBuyout(ServerHttpRequest httpHeader,
                                                           ServerHttpResponse httpResponse, @Valid @RequestBody AddBuyoutUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "add-buyout");
        logger.debug("add-buyout Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);

        ErrorResponse errorResponse = CartPegaRequestErrorsUtil.handleAddBuyoutRequestErrors(request);
        if (CollectionUtilities.isNotEmptyOrNull(errorResponse.getErrors())) {
            ErrorResponse errors = validator.convertObjectToString(errorResponse);
            if (null != errors) {
                return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
            }
        }
        return helper.addBuyout(request).map(pegaResponse -> {
            ErrorResponse errors2 = null;
            if (pegaResponse.getErrors() != null && !httpResponse.getStatusCode().is2xxSuccessful()) {
                errors2 = CartPegaResponseErrorsUtil.handleAddBuyoutResponseErrors(pegaResponse);
            } else if ("M".equalsIgnoreCase(request.getCartInfo().getMtnFlow())) {
                CartRedisData rr = new CartRedisData();
                rr.setBuyOutData(request.getData());
                rr.setCartInfo(request.getCartInfo());
                redisHelper2.upsertEdgeBuyoutDataIntoRedis(request.getCartInfo().getProcessingMTN(), rr)
                        .subscribeOn(Schedulers.parallel()).subscribe(data -> {
                            logger.info("BuyoutData upserted successfully");
                        });
            }
            addVZDLDataForBuyout(httpHeader, request, channelId, pegaResponse);
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(httpResponse.getStatusCode()).body(pegaResponse);
        });

    }

    private void addVZDLDataForBuyout(ServerHttpRequest httpHeader, AddBuyoutUIRequest request, String channelId, AddBuyoutUIResponse pegaResponse) {
        if (CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(channelId))) {
            String flowNameHeader = httpHeader.getHeaders().containsKey(CartConstants.FLOW_NAME) ? httpHeader.getHeaders().getFirst(CartConstants.FLOW_NAME) : "";
            if (flowNameHeader != null && flowNameHeader.equalsIgnoreCase(CartConstants.AI_QUOTE)) {
                try {
                    Vzdl vzdl = dlHelper.getVzdlDataForAddBuyout(request, pegaResponse);
                    if (vzdl != null) {
                        logger.info(CartConstants.VZDL_OBJ, vzdl);
                        deviceHelper.updateDLDataForAssisted(vzdl);
                    }
                } catch (Exception e) {
                    logger.error(CartConstants.ERROR_TAGGING, e);
                }
            }
        }
    }

    @PostMapping("/past-dues")
    public Mono<ResponseEntity<GenericResponse>> pastDues(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse,
                                                          @Valid @RequestBody PastDuesUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "past-dues");
        logger.debug("Past-Dues Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);
        ErrorResponse errors = helper.checkForBYODANDPastDueFlag(request)? new ErrorResponse() : CartPegaRequestErrorsUtil.handlePastDuesRequestErrors(request);
        if (errors.getErrors() != null)
            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
        return helper.pastDues(request).map(pegaResponse -> {
            ErrorResponse errors2 = null;
            if (pegaResponse.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil.handlePastDuesResponseErrors(pegaResponse);
            } else {
                PastDueRedisData pastDueRedisData = new PastDueRedisData();
                if (request.getCartInfo() != null
                        && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getPastDueAccepted()))
                    pastDueRedisData.setPastDueAccepted(request.getCartInfo().getPastDueAccepted());
                if (request.getData()!=null && request.getData().getPastdue() != null
                        && StringUtilities.isNotEmptyOrNull(request.getData().getPastdue().getAmount()))
                    pastDueRedisData.setAmount(request.getData().getPastdue().getAmount());

                redisHelper3.updatePastDueDataInRedis(pastDueRedisData).subscribeOn(Schedulers.parallel()).subscribe(data -> {
                    logger.info("PastDueData upserted successfully");
                });
            }
            return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(pegaResponse);
        });
    }

    /**
     * @param httpHeader
     * @param httpResponse
     * @param request
     * @return ResponseEntity
     */
    @SuppressWarnings("deprecation")
    @PostMapping({"/add-accessories", "/nse/add-accessories", "/5g/add-accessories", "/nse/5g/add-accessories","/flexV2/add-accessories"})
    public Mono<ResponseEntity<GenericResponse>> addAccessory(ServerHttpRequest httpHeader,
                                                              ServerHttpResponse httpResponse, @Valid @RequestBody AddAccessoriesUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, httpHeader.getPath().value());
        logger.debug("add-accessories Request: {}", request);
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        String flowNameHeader = httpHeader.getHeaders().containsKey(CartConstants.FLOW_NAME) ? httpHeader.getHeaders().getFirst(CartConstants.FLOW_NAME) : "";
        request.setChannelId(channelId);

        setFlexv2(httpHeader, request);
        String sessionId = "";
        sessionId = getSessionId(httpHeader, request, channelId, sessionId);
        if ("WHW_Redemption".equalsIgnoreCase(flowNameHeader))
            request.getCartInfo().setFlowType(flowNameHeader);
        String digitalIgSession = "";
        if ((CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId))
                || CartConstants.EXPRESS_STORE.equalsIgnoreCase(CartUtil.getChannelType(channelId)))
                && CartConstants.NSEACC.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
            digitalIgSession = httpHeader.getHeaders().getFirst(CartConstants.DIGITAL_IG_SESSION);
            logger.info("##sessionId## express store: {}", digitalIgSession);
            request.getCartInfo().setCartCreator(digitalIgSession);
            request.getCartInfo().setGlobalId(digitalIgSession);
            request.getCartInfo().setCartCreatorOrderLocationCode(request.getCartInfo().getCartCreatorOrderLocationCode());
            logger.info("NSEACC  CartCreatorOrderLocationCode: {}", request.getCartInfo().getCartCreatorOrderLocationCode());
        }
        // GTSFN-9713- setting up ecpdToken for RYL flow - standaloneAccessory as guest
        String requestUri = httpHeader.getPath().value();
        logger.debug("requestUri: {}", requestUri);
        setCookies(httpHeader, request, requestUri, channelId);

        ErrorResponse errorResponse = CartPegaRequestErrorsUtil.handleAddAccessoriesRequestErrors(request);
        if (CollectionUtilities.isNotEmptyOrNull(errorResponse.getErrors())) {
            ErrorResponse errors = validator.convertObjectToString(errorResponse);
            if (null != errors) {
                return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
            }
        }
        request.setHttpRequest(httpHeader);
        request.setHttpResponse(httpResponse);
        String finalSessionId = sessionId;

        return isMtnWhitelistedAddAccessoryRequired(httpHeader, httpResponse, channelId, request).flatMap(addAccessoryRequired -> {
            ErrorResponse errors3 = null;
            if (Boolean.TRUE.equals(addAccessoryRequired)) {
                return isAddAccessoryRequired(httpHeader, httpResponse, request, channelId, requestUri, finalSessionId);
            } else {
                errors3 = validator.convertObjectToString(CartPegaRequestErrorsUtil.handleWhitelistMtnError());
                return Mono.just(ResponseEntity.status(HttpStatus.OK).body(errors3));
            }
        });
    }

    private Mono<ResponseEntity<GenericResponse>> isAddAccessoryRequired(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse, AddAccessoriesUIRequest request, String channelId, String requestUri, String finalSessionId) {
        Mono<Map> redisRequiredDataMono = redisHelper.getRequiredDataFromRedis(Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE));
        Mono<AddAccessoriesUIResponse> addAccPegaResponse = accessoryHelper.addAccessory(request);
        return Mono.zip(redisRequiredDataMono, addAccPegaResponse).flatMap(tuple -> {
            Map redisRequiredDataMap = tuple.getT1();
            AddAccessoriesUIResponse pegaResponse = tuple.getT2();
            ErrorResponse errors2 = null;
            if (pegaResponse.getErrors() != null && !httpResponse.getStatusCode().is2xxSuccessful()) {
                errors2 = CartPegaResponseErrorsUtil.handleAddAccessoriesResponseErrors(pegaResponse);
                if (StringUtils.isNotBlank(request.getChannelId()) && CartConstants.DIGITAL_DDOT_MOB_TAB_CHANNELS.contains(channelId))
                    CartPegaResponseErrorsUtil.setErrorCategory(errors2, CartConstants.ERRCAT_CJCM);
                return Mono.just(ResponseEntity.status(processHttpStatusForPega((HttpStatus) httpResponse.getStatusCode())).body(errors2));
            } else {
                if (request != null && request.getData() != null && StringUtilities.isNotEmptyOrNull(request.getData().getSedBarCode())) {
                    Map<String, String> fields = new HashMap<>();
                    Map<String, String> cartinfo = new HashMap<>();
                    cartinfo.put("isJTOoffer", "true");
                    logger.info("About to execute cartinfo logs");
                    try {
                        fields.put("cartInfo", JacksonMapperFactory.defaultWriter().writeValueAsString(cartinfo));
                    } catch (JsonProcessingException e) {
                        logger.error("Exception while logging JTO details for Add Accessory for Audit", e);
                    }
                    logger.info("Json parsing Executed");
                    LoggerUtil.addCustomPersistField(fields);
                    logger.info("Completed executing cartinfo logs");
                }
                // added new code for logging accessories
                logAccessories(request, channelId);
                CartRedisData rr = new CartRedisData();
                setCartRedisData(httpResponse, request, requestUri, rr, pegaResponse, redisRequiredDataMap);

                if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId())))
                    return updateDataIntoRedisAsString(httpHeader, httpResponse, request, channelId, finalSessionId, rr, pegaResponse);
                Mono<Boolean> aiQuoteTaggingFeatureFlag = featureFlagHelper.fetchAiQuoteTaggingFeatureFlag();

                return aiQuoteTaggingFeatureFlag.flatMap(aiQuoteTaggingFFlag->{
                    if(aiQuoteTaggingFFlag && checkIfSetupAndGo(request)){
                        Mono<CatalogResponse> catalogResponseMono = getCatalogResponseData(request);
                        return catalogResponseMono
                                .flatMap(catalogResponse -> addVzdlDataAndUpdateFlow(httpHeader, request, channelId, pegaResponse, catalogResponse))
                                .onErrorResume(err-> addVzdlDataAndUpdateFlow(httpHeader, request, channelId, pegaResponse, null));
                    }
                    else{
                        return addVzdlDataAndUpdateFlow(httpHeader, request, channelId, pegaResponse, null);
                    }
                }).onErrorResume(err-> addVzdlDataAndUpdateFlow(httpHeader, request, channelId, pegaResponse, null));

            }
        });
    }

    private boolean checkIfSetupAndGo(AddAccessoriesUIRequest addAccessoriesUIRequest) {
        List<Lines> lines = fetchLines(addAccessoriesUIRequest);

        return lines.stream().anyMatch(lines1 -> lines1.getAddAccessories() != null
                && Arrays.stream(lines1.getAddAccessories()).anyMatch(accessory -> accessory.getId() != null && accessory.getId().contains(CartConstants.SETUPANDGO)));

    }

    private List<Lines> fetchLines(AddAccessoriesUIRequest addAccessoriesUIRequest){
        return addAccessoriesUIRequest != null && addAccessoriesUIRequest.getData() != null
                && addAccessoriesUIRequest.getData().getLines() != null ?
                Arrays.asList(addAccessoriesUIRequest.getData().getLines()) : Collections.emptyList();
    }

    private Mono<CatalogResponse> getCatalogResponseData(AddAccessoriesUIRequest addAccessoriesUIRequest){
        List<Lines> lines = fetchLines(addAccessoriesUIRequest);
        List<String> sorIds = lines.stream()
                .filter(Objects::nonNull)
                .flatMap(lines1 -> Optional.ofNullable(lines1.getAddAccessories()).stream().flatMap(Arrays::stream))
                .filter(accessory -> accessory != null && accessory.getId() != null && accessory.getId().contains(CartConstants.SETUPANDGO))
                .map(Accessory::getId)
                .toList();

        return catalogServiceHelper.getCatalogDomainData(null, null,null,null,sorIds);
    }

    private Mono<ResponseEntity<GenericResponse>> addVzdlDataAndUpdateFlow(ServerHttpRequest httpHeader, AddAccessoriesUIRequest request, String channelId, AddAccessoriesUIResponse pegaResponse,CatalogResponse catalogResponse) {
        addVZDLDataForAccessories(httpHeader, request, channelId, pegaResponse,catalogResponse);

        updateVZDLMfeLandingAccessories(request, pegaResponse, httpHeader);

        if (StringUtils.isNotBlank(request.getChannelId()) && CartConstants.DIGITAL_DDOT_MOB_TAB_CHANNELS.contains(channelId))
            CartPegaResponseErrorsUtil.setErrorCategory(pegaResponse.getErrors(), CartConstants.ERRCAT_CJCM);

        if (StringUtilities.isNotEmptyOrNull(request.getChannelId()) &&
                CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))) {
            return featureFlagHelper.fetchAssistedTaggingFeatureFlag().flatMap(assistedTaggingFeatureFlag -> {
                if (assistedTaggingFeatureFlag != null && assistedTaggingFeatureFlag) {
                    return updateFlowForAssisted(request, pegaResponse);
                }
                return Mono.just(ResponseEntity.status(HttpStatus.OK).body(pegaResponse));
            });
        }

        return Mono.just(ResponseEntity.status(HttpStatus.OK).body(pegaResponse));
    }

    private void logAccessories(AddAccessoriesUIRequest request, String channelId) {
        if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId))
                && null != env.getProperty("isLoggingAccessorySku")
                && Boolean.parseBoolean(env.getProperty("isLoggingAccessorySku"))) {
            logger.info("accessory flow  channel id");
            cartAccessoryLoggingHelper.logAccessoryInkibana(request).subscribeOn(Schedulers.parallel());
        }
    }

    private Mono<ResponseEntity<GenericResponse>> updateDataIntoRedisAsString(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse, AddAccessoriesUIRequest request, String channelId, String finalSessionId, CartRedisData rr, AddAccessoriesUIResponse pegaResponse) {
        return redisHelper.updateDataIntoRedisAsString(rr, CartConstants.ACCESSORY).flatMap(redisData -> {
            httpResponse.addCookie(ResponseCookie.from(CartConstants.ACC_IN_CART, CartConstants.TRUE_FLAG)
                    .path("/").httpOnly(false).maxAge(-1).build());

            try {
                if (pegaResponse != null && pegaResponse.getServiceBody() != null
                        && pegaResponse.getServiceBody().getServiceResponse() != null
                        && pegaResponse.getServiceBody().getServiceResponse().getContext() != null
                        && pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo() != null
                        && pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartItemCount() == 0)
                    redisHelper2.deleteSessionDataKeyFromRedis("cartOrderFlowType");
                else
                    dlUtilityService.updateDlData(CartConstants.NAO);

                if (request.getData().getRtm() != null) {
                    updateRTMCdlCartCookie(httpHeader, httpResponse, request.getData().getRtm(), finalSessionId, false);
                }
            } catch (Exception e) {
                logger.error("exception while calling dlUtilityService in addDevice");
            }
            if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId))
                    && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getAccountNumber()) &&
                    (null == request.getCartInfo().getDisableMyLink() || !request.getCartInfo().getDisableMyLink())) {
                logger.info("Inside Customer Profile Digital with disableLink Value :{}", request.getCartInfo().getDisableMyLink());
                removeSensitiveData(pegaResponse);
                return helper.populateCustomerProfileCookieIfPresent(httpResponse, request.getCartInfo().getAccountNumber(), pegaResponse);
            }
            removeSensitiveData(pegaResponse);
            return Mono.just(ResponseEntity.status(HttpStatus.OK).body(pegaResponse));
        });
    }

    private void setCartRedisData(ServerHttpResponse httpResponse, AddAccessoriesUIRequest request, String requestUri, CartRedisData rr, AddAccessoriesUIResponse pegaResponse, Map redisRequiredDataMap) {
        if (request.getCartInfo().getIntendType() != null && !soeLoginSessionBean.isFWADigitalFlow())
            rr.setIntendType(request.getCartInfo().getIntendType());
        if (pegaResponse.getServiceBody() != null) {
            if (!(soeLoginSessionBean.isFWADigitalFlow()) && pegaResponse.getServiceBody().getServiceResponse().getContext() != null) {
                rr.setCaseId(pegaResponse.getServiceBody().getServiceResponse().getContext().getCaseId());
                if (pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo() != null) {
                    rr.setCartId(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()
                            .getCartId());
                }
                if (null != pegaResponse.getServiceBody().getServiceResponse().getContext().getCustomerInfo()
                        && StringUtilities.isNotEmptyOrNull(pegaResponse.getServiceBody().getServiceResponse()
                        .getContext().getCustomerInfo().getProcessingMTN()))
                    rr.setProcessingMTN(request.getCartInfo().getProcessingMTN());
            }
            if (request != null && request.getCartInfo() != null &&
                    null != request.getCartInfo().getIntendType() &&
                    (request.getCartInfo().getIntendType().equalsIgnoreCase("NSE") || (request.getCartInfo().getIntendType().equalsIgnoreCase(CartConstants.NSE_BYOD)))) {
                pegaResponse.getServiceBody().getServiceResponse().getContext().setCaseId(null);
                if (pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo() != null)
                    pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setCartId(null);
                if (pegaResponse.getServiceHeader() != null) {
                    pegaResponse.getServiceHeader().setClientId(null);
                }
                if (pegaResponse.getValidateCartResponse() != null && pegaResponse.getValidateCartResponse().getData() != null
                        && pegaResponse.getValidateCartResponse().getData().getValidateCartAndUpdate() != null) {
                    pegaResponse.getValidateCartResponse().getData().getValidateCartAndUpdate().setCartId(null);
                }

            }
        }

        /*Add No of Item in cart into cookie*/
        String cookieName = CartConstants.EXISTING_CART_COUNT;
        boolean setCookie = true;
        boolean nseFlow = false;
        if (requestUri != null && !"".equals(requestUri) && requestUri.contains("nse")) {
            cookieName = CartConstants.PROSPECT_CART_COUNT;
            nseFlow = true;
        }

        if (pegaResponse != null && pegaResponse.getServiceBody() != null
                && CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))
                && pegaResponse.getServiceBody().getServiceResponse() != null
                && pegaResponse.getServiceBody().getServiceResponse().getContext() != null) {
            if (pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo() != null) {
                CartAddDeviceUtil.createCookieCartCountAccessories(httpResponse, pegaResponse, cookieName, domains);
                if (nseFlow) {
                    if (pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartItemCount() != 0) {
                        httpResponse.addCookie(ResponseCookie.from(CartConstants.PROSPECT_CART_ACTIVE, "true")
                                .path("/").httpOnly(false).build());
                    } else
                        httpResponse.addCookie(ResponseCookie.from(CartConstants.PROSPECT_CART_ACTIVE, CartConstants.FALSE)
                                .path("/").httpOnly(false).build());
                }
                setCookie = false;
            }
        }

        if (setCookie && CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))
                && pegaResponse.getValidateCartResponse() != null && pegaResponse.getValidateCartResponse().getData() != null
                && pegaResponse.getValidateCartResponse().getData().getValidateCartAndUpdate() != null &&
                pegaResponse.getValidateCartResponse().getData().getValidateCartAndUpdate().getLineDetails() != null) {
            logger.info("Add the no devices or accessories in the cart into Cookies.");
            httpResponse.addCookie(ResponseCookie.from(cookieName,
                            String.valueOf(pegaResponse.getValidateCartResponse().getData().getValidateCartAndUpdate().
                                    getLineDetails().getNumOfAccessoryAndDeviceItemsInCart()))
                    .path("/").httpOnly(false).build());
            if (nseFlow) {
                if (pegaResponse.getValidateCartResponse().getData().getValidateCartAndUpdate().
                        getLineDetails().getNumOfAccessoryAndDeviceItemsInCart() != 0) {
                    httpResponse.addCookie(ResponseCookie.from(CartConstants.PROSPECT_CART_ACTIVE, "true")
                            .path("/").httpOnly(false).build());
                } else
                    httpResponse.addCookie(ResponseCookie.from(CartConstants.PROSPECT_CART_ACTIVE, CartConstants.FALSE)
                            .path("/").httpOnly(false).build());
            }
        }


        if (pegaResponse != null && pegaResponse.getServiceBody() != null
                && pegaResponse.getServiceBody().getServiceResponse() != null
                && pegaResponse.getServiceBody().getServiceResponse().getContext() != null
                && pegaResponse.getServiceBody().getServiceResponse().getContext().getContextInfo() != null) {

            if (CartUtil.isDigital(request.getChannelId()) && nseFlow &&
                    (CartConstants.PROMO_HUB.equalsIgnoreCase(pegaResponse.getServiceBody().getServiceResponse().getContext().getContextInfo().getProcessStep())
                            || CartConstants.ACCESSORIES_INTERSTIAL.equalsIgnoreCase(pegaResponse.getServiceBody().getServiceResponse().getContext().getContextInfo().getProcessStep()))) {
                boolean isHubProspectCartCookieDomainIssueFFlagEnabled = featureFlagHelper.isHubProspectCartCookieDomainIssueFFlagEnabled();
                CartUtil.addHubProspectCartCookieToResponse(httpResponse, isHubProspectCartCookieDomainIssueFFlagEnabled, CartConstants.TRUE_FLAG, domains);
            }
        }

        List<Lines> lineList = Arrays.asList(request.getData().getLines());
        rr.setLines(lineList);
        rr.setAccessoryCartInfo(request.getCartInfo());
        if (StringUtilities.isNotEmptyOrNull(request.getData().getDepletionType()))
            rr.setDepletionType(request.getData().getDepletionType());
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessingMTN()))
            rr.setProcessingMTN(request.getCartInfo().getProcessingMTN());

        if (CartConstants.ACCESSORY_PDP.equalsIgnoreCase(request.getCartInfo().getProcessStep())
                && lineList != null && lineList.size() > 0 && lineList.get(0).getAddAccessories() != null && lineList.get(0).getAddAccessories().length > 0
                && StringUtilities.isNotEmptyOrNull(lineList.get(0).getAddAccessories()[0].getId())) {
            rr.setAccessorySorIdForRecommendations(lineList.get(0).getAddAccessories()[0].getId());
        }

        StringBuilder finalFlowName = new StringBuilder();
        if (redisRequiredDataMap != null && redisRequiredDataMap.containsKey(CartConstants.CART_ORDER_FLOW_TYPE)) {
            if (redisRequiredDataMap.get(CartConstants.CART_ORDER_FLOW_TYPE) == null || StringUtilities.isEmptyOrNull(redisRequiredDataMap.get(CartConstants.CART_ORDER_FLOW_TYPE).toString()))
                finalFlowName.append(CartConstants.NAO);
            else {
                finalFlowName.append(redisRequiredDataMap.get(CartConstants.CART_ORDER_FLOW_TYPE).toString());
                if (!isNAOExistInCartFlowType(redisRequiredDataMap.get(CartConstants.CART_ORDER_FLOW_TYPE).toString()))
                    finalFlowName.append(" w/").append(CartConstants.NAO);
            }
        } else {
            finalFlowName.append(CartConstants.NAO);
        }

        rr.setCartOrderFlowType(finalFlowName.toString());
    }

    private static void setCookies(ServerHttpRequest httpHeader, AddAccessoriesUIRequest request, String requestUri, String channelId) {
        if (requestUri != null && !"".equals(requestUri) && requestUri.contains("cart/nse/add-accessories")
                && request.getCartInfo().getIntendType().equalsIgnoreCase(CartConstants.NSEACC) && (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId)))
                && request.getCartInfo().getIntent().equalsIgnoreCase(CartConstants.STANDALONEACCESSORY)) {
            HttpCookie cookieCcpdToken = httpHeader.getCookies().getFirst(CartConstants.COOKIE_ECPD_TOKEN);
            String ecpdToken = null != httpHeader.getCookies()
                    && null != cookieCcpdToken
                    ? cookieCcpdToken.getValue()
                    : "";
            HttpCookie cookieCcpdDomain = httpHeader.getCookies().getFirst(CartConstants.COOKIE_ECPD_DOMAIN);
            String ecpdDomainCookie = null != httpHeader.getCookies()
                    && null != cookieCcpdDomain
                    ? cookieCcpdDomain.getValue()
                    : "";
            HttpCookie salesRepIdCookie = httpHeader.getCookies().getFirst(CartConstants.COOKIE_SALESREPID);
            String salesRepId = null != httpHeader.getCookies()
                    && null != salesRepIdCookie
                    ? salesRepIdCookie.getValue()
                    : "";
            if (!StringUtils.isEmpty(ecpdToken)) {
                String[] values = ecpdToken.split(":");
                if (null != values && values.length >= 4) {
                    ecpdToken = values[3];
                }
            }
            request.getCartInfo().setEcpdToken(ecpdToken);
            request.getCartInfo().setRylEcpdUrl(ecpdDomainCookie);
            request.getCartInfo().setCartCreatorSalesRepId(salesRepId);
            request.getCartInfo().setReferralSaleRepId(salesRepId);
        }
    }

    private static String getSessionId(ServerHttpRequest httpHeader, AddAccessoriesUIRequest request, String channelId, String sessionId) {
        HttpCookie cookieDigitIgSession = httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION);
        if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId))
                || CartConstants.EXPRESS_STORE.equalsIgnoreCase(CartUtil.getChannelType(channelId)))
            sessionId = null != cookieDigitIgSession
                    ? cookieDigitIgSession.getValue()
                    : "";

        request.getCartInfo().setSessionId(sessionId);
        return sessionId;
    }

    public Mono<ResponseEntity<GenericResponse>> updateVZDLMfeLandingAccessories(AddAccessoriesUIRequest request, AddAccessoriesUIResponse pegaResponse, ServerHttpRequest httpHeader) {
        String refererHeader = httpHeader.getHeaders().containsKey(CartConstants.REFERER) ? httpHeader.getHeaders().getFirst(CartConstants.REFERER):"";

        if(null!= refererHeader && refererHeader.contains("landing.html")&&
                StringUtilities.isNotEmptyOrNull(request.getChannelId()) &&
                CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))
                && request.getCartInfo().isFlexV2()
                && Boolean.TRUE.equals(featureFlagHelper.isAssistedLPMFETaggingFeatureFlag())) {
            Vzdl vzdl = omniDlHelper.getVzdlDataForAddAccessories(request, pegaResponse);
            if (vzdl != null) {
                logger.info(CartConstants.VZDL_OBJ, vzdl);
                deviceHelper.updateDLDataForAssisted(vzdl);
            }
            return updateFlowForAssisted(request, pegaResponse);
        }
        return Mono.just(ResponseEntity.status(HttpStatus.OK).body(pegaResponse));
    }

    private void setFlexv2(ServerHttpRequest httpHeader, AddAccessoriesUIRequest request) {
        if (StringUtilities.isNotEmptyOrNull(String.valueOf(httpHeader.getURI())) && CartUtil.isFlexV2(String.valueOf(httpHeader.getURI()))) {
            request.getCartInfo().setFlexV2(true);
        }
    }

    public boolean isNAOExistInCartFlowType(String cartOrderFlowType)
    {
        if(StringUtilities.isNotEmptyOrNull(cartOrderFlowType))
            return Arrays.asList((cartOrderFlowType.split(" w/"))).stream()
                    .map(String::trim)
                    .map(String::toLowerCase)
                    .anyMatch(flow -> StringUtilities.isNotEmptyOrNull(flow) && flow.equalsIgnoreCase(CartConstants.NAO));
        return false;
    }


    public Mono<ResponseEntity<GenericResponse>> updateFlowForAssisted(AddAccessoriesUIRequest request, AddAccessoriesUIResponse pegaResponse){

        if (accessoryHelper.isPegaResponseValid(pegaResponse))
        {
            try {
                return omniDlHelper.setFlow(request.getFlowName(), "NAO").flatMap(redisFlowName->
                {
                    pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setFlow(redisFlowName);
                    return Mono.just(ResponseEntity.status(HttpStatus.OK).body(pegaResponse));
                });
            } catch (Exception e) {
                logger.info("Exception in tagging flow name to session : {}", e.getMessage());
            }

        }
        return Mono.just(ResponseEntity.status(HttpStatus.OK).body(pegaResponse));
    }

    private void addVZDLDataForAccessories(ServerHttpRequest httpHeader, AddAccessoriesUIRequest request, String channelId, AddAccessoriesUIResponse pegaResponse, CatalogResponse catalogResponse) {
        if (CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(channelId))) {
            String flowNameHeader = httpHeader.getHeaders().containsKey(CartConstants.FLOW_NAME) ? httpHeader.getHeaders().getFirst(CartConstants.FLOW_NAME) : "";
            if (flowNameHeader != null && flowNameHeader.equalsIgnoreCase(CartConstants.AI_QUOTE)) {
                try {
                    Vzdl vzdl = dlHelper.getVzdlDataForAddAccessories(request, pegaResponse,catalogResponse);
                    if (vzdl != null) {
                        logger.info(CartConstants.VZDL_OBJ, vzdl);
                        deviceHelper.updateDLDataForAssisted(vzdl);
                    }
                } catch (Exception e) {
                    logger.error(CartConstants.ERROR_TAGGING, e);
                }
            }
        }
    }

    public Mono<Boolean> isMtnWhitelistedAddAccessoryRequired(ServerHttpRequest httpRequest,
                                                              ServerHttpResponse httpResponse, String channelId, AddAccessoriesUIRequest request) {
        if (CartConstants.DIGITAL_DDOT_MOB_TAB_CHANNELS.contains(channelId)
                && null != request.getCartInfo() && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getSubscriptionType())
                && CartConstants.SUBSCRIPTION_TYPE_GAMINGCONSOLE.equals(request.getCartInfo().getSubscriptionType())
                && xboxTrialPage) {
            Map<String, String> cradleDataMap = new HashMap<>();
            cradleDataMap.put(CradleConstants.PAGE_NAME, "xbox");
            cradleDataMap.put(CradleConstants.CHANNEL, channelId);
            String[] sessionKeys = {SessionConstants.MTN_KEY};
            return redisHelper3.getMTNFromRedis(sessionKeys).flatMap(dataMap -> {
                if (dataMap.containsKey(SessionConstants.MTN_KEY) && null != dataMap.get(SessionConstants.MTN_KEY)) {
                    cradleDataMap.put(CradleConstants.MTN, (String) dataMap.get(SessionConstants.MTN_KEY));
                } else {
                    cradleDataMap.put(CradleConstants.MTN,
                            httpRequest.getHeaders().containsKey(SessionConstants.MTN_KEY)
                                    ? httpRequest.getHeaders().getFirst(SessionConstants.MTN_KEY)
                                    : "");
                }
                return cradleHelper.getThrottlingList(cradleDataMap, httpRequest, httpResponse).flatMap(throttleList -> {
                    return checkXboxInThrottledList(throttleList);
                });
            });
        }
        return Mono.just(true);
    }

    private Mono<Boolean> checkXboxInThrottledList(String throttleList) {
        return Mono.just(throttleList.contains("XBOX"));
    }

    public void removeSensitiveData(AddAccessoriesUIResponse response) {
        if (response.getServiceBody() != null && response.getServiceBody().getServiceResponse() != null
                && response.getServiceBody().getServiceResponse().getContext() != null) {
            response.getServiceBody().getServiceResponse().getContext().setCaseId(null);
        }
        Optional<AddAccContext> addAccContextOptional = Optional.of(response).map(AddAccessoriesUIResponse::getServiceBody).map(AddAccServiceBody::getServiceResponse).map(AddAccServiceResponse::getContext);
        addAccContextOptional.map(AddAccContext::getCustomerInfo).ifPresent(customerInfo -> customerInfo.setAccountNumber(null));
        addAccContextOptional.map(AddAccContext::getCartInfo).ifPresent(cartInfo -> cartInfo.setCartId(null));
        Optional<CXPCartVO> cxpCartVOOptional = Optional.of(response).map(AddAccessoriesUIResponse::getValidateCartResponse).map(ValidateCartUIResponse::getData).map(CXPValidateCartDataVO::getValidateCartAndUpdate);
        cxpCartVOOptional.map(CXPCartVO::getCartHeader).ifPresent(cartHeader -> {
            cartHeader.setCartId(null);
            cartHeader.setFullAccountNumber(null);
            cartHeader.setCaseId(null);
        });
        cxpCartVOOptional.ifPresent(validateCartAndUpdate -> validateCartAndUpdate.setCartId(null));
        cxpCartVOOptional.map(CXPCartVO::getLineDetails).ifPresent(lineDetails -> {
            lineDetails.setCartId(null);
        });
    }

    @PostMapping({"/add-device", "/nse/add-device", "flexV2/add-device", "flexV2/nse/add-device"})
    public Mono<ResponseEntity<GenericResponse>> addDevice(ServerHttpRequest httpHeader,
                                                           ServerHttpResponse httpResponse, @Valid @RequestBody AddDeviceUIRequest request) {
        // reducing duplication changes
        ErrorResponse errors = settingErrorResponse(httpHeader, request, "add-device");
        System.out.println("CartUpdateOperationsController.addDevice :: return BAD_REQUEST");
        if (null != errors)
            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
        // GTSFN-2160 - New Customer Transaction Prospect - Add device change
        String sessionId = "";
        String channelType = CartUtil.getChannelType(request.getChannelId());
        HttpCookie cookieDigitIgSession = httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION);
        HttpCookie preToPostMigrationCookie = httpHeader.getCookies().getFirst(CartConstants.PREPAID_TO_POSTPAID_MIGRATION);
        Boolean isDvmFlow = CartPegaRequestUtil.isDvmConversionFlagExists();
        if (CartConstants.DIGITAL.equalsIgnoreCase(channelType)
                || CartConstants.EXPRESS_STORE.equalsIgnoreCase(channelType))
            sessionId = null != cookieDigitIgSession
                    ? cookieDigitIgSession.getValue()
                    : "";

        getCookieValues(httpHeader, null, request);
        // Updating cartCreator and globalId with sessionId for New customer flow NSA
        if (CartConstants.NSE.equals(request.getCartInfo().getIntendType())
                && (CartConstants.VZW_DOTCOM.equals(request.getChannelId()) || request.getChannelId().contains(CartConstants.VZW_MFA))) {
            request.getCartInfo().setCartCreator(sessionId);
            request.getCartInfo().setGlobalId(sessionId);
        }
		CartRedisData rr = new CartRedisData();
		if (isDvmFlow && StringUtilities.isNotEmptyOrNull(CartPegaRequestUtil.fetchComVzIdFromHeader())) {
			request.setVzId(CartPegaRequestUtil.fetchComVzIdFromHeader());
            rr.setFiosAuthenticated(CartConstants.AUTHENTICATED);
		}
        request.getCartInfo().setSessionId(sessionId);
        String finalSessionId = sessionId;
        request.setHttpRequest(httpHeader);
        request.setHttpResponse(httpResponse);
        setFlexv2(httpHeader, request);

        if (null != preToPostMigrationCookie)
            request.getCartInfo().setPrepaidToPostpaidMigration(true);
        Mono<AddDeviceUIResponse> pegaResponseMono = deviceHelper.addDevice(request,httpResponse);
        Mono<Boolean> isCartOperationWithUUIDEnabledMono = featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART,FeatureFlagConstants.FLAG_NAME_CART_OPERATION_WITH_UUID,true);
        Mono<Boolean> setAcNextGenCookieForMVAMono = featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART,FeatureFlagConstants.FLAG_NAME_SET_ACNEXTGEN_FOR_MVA,false);
        return Mono.zip(pegaResponseMono, isCartOperationWithUUIDEnabledMono,setAcNextGenCookieForMVAMono).flatMap(tuple -> {
            AddDeviceUIResponse pegaResponse = tuple.getT1();
            boolean isCartOperationWithUUIDAndAcNextGenCookieMVA = tuple.getT2() && tuple.getT3();

            ErrorResponse errors2 = null;
            if (pegaResponse.getErrors() != null && !httpResponse.getStatusCode().is2xxSuccessful()) {
                errors2 = CartPegaResponseErrorsUtil.handleAddDeviceResponseErrors(pegaResponse);
                return Mono.just(ResponseEntity.status(processHttpStatusForPega((HttpStatus) httpResponse.getStatusCode())).body(errors2));
            } else {
                if ((request.getData().getLines().get(0).getDevice() != null) && StringUtilities.isNotEmptyOrNull(request.getData().getLines().get(0).getDevice().getNetworkBandwidthType()))
                    logger.info("Device added to cart: {}", request.getData().getLines().get(0).getDevice().getNetworkBandwidthType());
                String flowPath = String.valueOf(httpHeader.getPath());
                addCartItemCountToCookie(httpHeader, httpResponse, request, flowPath, channelType, pegaResponse);

                updateIntendTypeAndPurchasePath(request);
                updateRedis(httpResponse, request, rr, pegaResponse, channelType, isCartOperationWithUUIDAndAcNextGenCookieMVA);

                HttpCookie cdlThrottleListCookie = request.getHttpRequest().getCookies().getFirst(CartConstants.CDL_THROTTLE_LIST);
                String cdlThrottleList = cdlThrottleListCookie != null ? cdlThrottleListCookie.getValue() : "";

                updateRedis2(request, rr, pegaResponse);
                if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId())))
                    return updateDataIntoRedisAsString(httpHeader, httpResponse, request, rr, cdlThrottleList, pegaResponse, isDvmFlow, flowPath, finalSessionId);

                return addVzdlDataForAddDevice(httpResponse, request, channelType, pegaResponse, rr);
            }
        });
    }

    private static void setFlexv2(ServerHttpRequest httpHeader, AddDeviceUIRequest request) {
        if (StringUtilities.isNotEmptyOrNull(String.valueOf(httpHeader.getURI())) && CartUtil.isFlexV2(String.valueOf(httpHeader.getURI()))) {
            request.getCartInfo().setFlexV2(true);
        }
    }

    private Mono<ResponseEntity<GenericResponse>> updateDataIntoRedisAsString(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse, AddDeviceUIRequest request, CartRedisData rr, String cdlThrottleList, AddDeviceUIResponse pegaResponse, Boolean isDvmFlow, String flowPath, String finalSessionId) {
        return redisHelper.updateDataIntoRedisAsString(rr, CartConstants.DEVICE).flatMap(redisData ->
                deviceHelper2.updateSubFlowInTaggingForNextgen(cdlThrottleList, pegaResponse, request).flatMap(subflow -> {
                    try {
                        logger.info("Inside DL update");

                        if (request.getCartInfo().getIntendType() != null) {
                            if (CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
                                dlUtilityService.updateDlData(CartConstants.NSO);
                            } else if (CartConstants.BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())) {
                                dlUtilityService.updateDlData(CartConstants.ESO);
                            } else {
                                String intendType = request.getCartInfo().getIntendType().toLowerCase();
                                if (CartConstants.NSE.equalsIgnoreCase(intendType) &&
                                        null != pegaResponse && null != pegaResponse.getServiceBody()
                                        && null != pegaResponse.getServiceBody().getServiceResponse()
                                        && null != pegaResponse.getServiceBody().getServiceResponse().getContext()
                                        && null != pegaResponse.getServiceBody().getServiceResponse().getContext()
                                        .getContextInfo()) {
                                    String pegaStep = pegaResponse
                                            .getServiceBody()
                                            .getServiceResponse()
                                            .getContext()
                                            .getContextInfo()
                                            .getProcessStep();
                                    if (!(CartConstants.PROMO_HUB.equalsIgnoreCase(pegaStep) ||
                                            CartConstants.ACCESSORIES_INTERSTIAL.equalsIgnoreCase(pegaStep))) {
                                        dlUtilityService.updateDlData(intendType);
                                    } else {
                                        if (pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo() != null) {
                                            int cartCount = pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartItemCount();
                                            if (cartCount > 1) {
                                                Mono<Map<String, String>> pageData = dlUtilityService.getFlowDLData();
                                                pageData.flatMap(response -> {
                                                    if (response != null && response.size() > 0) {
                                                        if (response.get(CartConstants.FLOW_NAME) != null) {
                                                            dlUtilityService.updateDlData(response.get(CartConstants.FLOW_NAME) + "+" + intendType);
                                                        }
                                                    }
                                                    return null;
                                                });
                                            } else {
                                                dlUtilityService.updateDlData(CartConstants.EXPRESS + intendType);
                                            }
                                        }
                                    }
                                } else {
                                    String mtnFlow = request.getCartInfo().getMtnFlow() != null ? request.getCartInfo().getMtnFlow() : "";
                                    if (CartConstants.IVR.equalsIgnoreCase(mtnFlow)) {
                                        dlUtilityService.updateDlData(mtnFlow);
                                    } else {
                                        dlUtilityService.updateDlData(intendType);
                                    }
                                }

                            }
                            dlService.buildDLData(OmniBuilder.updateEventData());
                            if (CartUtil.isByodFlow(request.getCartInfo().getIntendType()))
                                redisHelper2.deleteSessionDataKeyFromRedis(CartConstants.BYOD_IMEI_DETAILS);
                        }
                        if (isDvmFlow) {
                            dlUtilityService.upsertVZPageSubFLow(CartConstants.FLOW_TYPE_DVM, true, "");
                        }
                        // Adding for new customer DL object update
                        if (flowPath != null && !flowPath.isEmpty() && flowPath.contains("/cart/nse/add-device")) {

                            List<HttpCookie> globalId = httpHeader.getCookies().get("GLOBALID");
                            String globalIdVal = globalId != null && !globalId.isEmpty()
                                    ? globalId.get(0).getValue()
                                    : "";
                            logger.info(finalSessionId != null ? finalSessionId : CartConstants.EMPTY);
                            logger.info(globalIdVal);

                        }

                        if (request.getData().getRtm() != null) {
                            updateRTMCdlCartCookie(httpHeader, httpResponse, request.getData().getRtm(), finalSessionId, true);
                        }
                    } catch (Exception e) {
                        logger.error("exception while calling dlUtilityService in addDevice");
                    }
                    if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))
                            && httpResponse.getStatusCode().equals(HttpStatus.PARTIAL_CONTENT)) {
                        for (CartError errorResp : pegaResponse.getErrors()) {
                            if ("3226".equals(errorResp.getId())) {
                                httpResponse.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR);
                            }
                        }
                    }
                    if (CartUtil.isDigital(request.getChannelId())) {
                        try {
                            return helper.populateConflictedSPOsIfPresent(request, pegaResponse).
                                    flatMap(spoResponse ->
                                            helper.populateHumWifiConflictedSFosWithCheck(request, pegaResponse)).
                                    flatMap(humResponse -> {
                                        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getAccountNumber()) &&
                                                (null == request.getCartInfo().getDisableMyLink() || !request.getCartInfo().getDisableMyLink())) {
                                            logger.info("Inside Customer Profile Digital with disableLink Value :{}", request.getCartInfo().getDisableMyLink());
                                            return helper.populateCustomerProfileCookieIfPresent(httpResponse, request.getCartInfo().getAccountNumber(), pegaResponse).
                                                    flatMap(res ->
                                                    {
                                                        if (enableSecurityForCart)
                                                            removeSensitiveInfo(request, pegaResponse);
                                                        return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(pegaResponse));
                                                    });
                                        }
                                        removeSensitiveInfo(request, pegaResponse);
                                        return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(pegaResponse));
                                    });
                        } catch (Exception e) {
                            logger.error("Exception while updating Customer profile Cookie in addDevice");

                        }
                    }
                    /* NSADT-72401 : F&S - NSA NC - Sensitive Info Disclosure - Case id, ClientID and Client */
                    removeSensitiveInfo(request, pegaResponse);
                    return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(pegaResponse));

                }));
    }

    private Mono<ResponseEntity<GenericResponse>> addVzdlDataForAddDevice(ServerHttpResponse httpResponse, AddDeviceUIRequest request, String channelType, AddDeviceUIResponse pegaResponse, CartRedisData rr) {
        if (CartConstants.ASSISTED.equalsIgnoreCase(channelType)
                && StringUtilities.isNotEmptyOrNull(request.getCartInfo().getMtnFlow())
                && request.getCartInfo().getMtnFlow().equalsIgnoreCase(CartConstants.AI_QUOTE)) {
            try {
                Vzdl vzdl = dlHelper.getVzdlDataForAddDevice(request, pegaResponse, rr);
                Mono<Boolean> bulkUpdateAiQuoteTaggingFeatureFlag = featureFlagHelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag();
                return bulkUpdateAiQuoteTaggingFeatureFlag.flatMap(taggingFlag -> {
                    if (taggingFlag) {
                        String indentType = deviceHelper2.mapIntendType(request.getCartInfo(), request.getData());
                        return omniDlHelper.setFlow(request.getFlowName(), indentType).flatMap(flowName -> {
                            vzdl.getPage().setFlow(flowName);
                            return updateVzdlDataForAiQuote(httpResponse, request, vzdl, channelType, pegaResponse, rr);
                        });
                    }
                    return updateVzdlDataForAiQuote(httpResponse, request, vzdl, channelType, pegaResponse, rr);
                }).onErrorResume(err -> {
                    logger.info("Failed to fetchBulkUpdateAiQuoteTaggingFeatureFlag");
                    return updateDLDataForAssistedAddDevice(httpResponse, request, channelType, pegaResponse, rr);
                });
            } catch (Exception e) {
                logger.error(CartConstants.ERROR_TAGGING, e);

            }
        }
        return updateDLDataForAssistedAddDevice(httpResponse, request, channelType, pegaResponse, rr);
    }

    private static void updateIntendTypeAndPurchasePath(AddDeviceUIRequest request) {
        if(CartConstants.ACCOUNT_GROWTH.equalsIgnoreCase(request.getCartInfo().getIntendType())){
            request.getCartInfo().setIntendType(CartConstants.EUP);
        }
        List<Lines> cartLines = request.getData().getLines();
        if (cartLines != null) {
            for (Lines cartLine : cartLines) {
                if (CartConstants.ACCOUNT_GROWTH.equalsIgnoreCase(cartLine.getPurchasePath())) {
                    cartLine.setPurchasePath(CartConstants.EUP);
                }
            }
        }
    }

    private static void updateRedis2(AddDeviceUIRequest request, CartRedisData rr, AddDeviceUIResponse pegaResponse) {
        if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getProcessingMTN()))
            rr.setProcessingMTN(request.getCartInfo().getProcessingMTN());

        setOneClickCheckout(request, rr, pegaResponse);
        rr.setIconicTestIntent(request.getCartInfo().getIconicTestIntent());
        setDeviceCount(rr, pegaResponse);
    }

    private static void setOneClickCheckout(AddDeviceUIRequest request, CartRedisData rr, AddDeviceUIResponse pegaResponse) {
        if (CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType()) &&
                null != pegaResponse && null != pegaResponse.getServiceBody()
                && null != pegaResponse.getServiceBody().getServiceResponse()
                && null != pegaResponse.getServiceBody().getServiceResponse().getContext()
                && null != pegaResponse.getServiceBody().getServiceResponse().getContext()
                .getContextInfo()) {
            String pegaStep = pegaResponse
                    .getServiceBody()
                    .getServiceResponse()
                    .getContext()
                    .getContextInfo()
                    .getProcessStep();
            if (!(CartConstants.PROMO_HUB.equalsIgnoreCase(pegaStep) ||
                    CartConstants.ACCESSORIES_INTERSTIAL.equalsIgnoreCase(pegaStep))) {
                rr.setOneClickCheckout(CartConstants.FALSE);
            }
        }
    }

    private static void setDeviceCount(CartRedisData rr, AddDeviceUIResponse pegaResponse) {
        if (pegaResponse != null && pegaResponse.getServiceBody() != null
                && pegaResponse.getServiceBody().getServiceResponse() != null
                && pegaResponse.getServiceBody().getServiceResponse().getContext() != null
                && pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo() != null) {
            rr.setDeviceCount(String.valueOf(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartItemCount()));
        }
    }

    private void updateRedis(ServerHttpResponse httpResponse, AddDeviceUIRequest request, CartRedisData rr, AddDeviceUIResponse pegaResponse, String channelType, boolean isCartOperationWithUUIDAndAcNextGenCookieMVA) {
        if (request.getCartInfo().getIntendType() != null)
            rr.setIntendType(request.getCartInfo().getIntendType());

        if (request.getData().getLines().get(0).getDevice() != null && StringUtilities.isNotEmptyOrNull(request.getData().getLines().get(0).getDevice().getId())) {
            rr.setDeviceSorIdForRecommendations(request.getData().getLines().get(0).getDevice().getId());
        }

        setDataFromServiceBody(httpResponse, request, rr, pegaResponse, channelType, isCartOperationWithUUIDAndAcNextGenCookieMVA);
        rr.setLines(request.getData().getLines());
        rr.setDeviceCartInfo(request.getCartInfo());
        rr.setSpokeJourney(CartConstants.FALSE);
    }

    private void setDataFromServiceBody(ServerHttpResponse httpResponse, AddDeviceUIRequest request, CartRedisData rr, AddDeviceUIResponse pegaResponse, String channelType, boolean isCartOperationWithUUIDAndAcNextGenCookieMVA) {
        if (pegaResponse.getServiceBody() != null) {
            if (!CartConstants.ASSISTED.equalsIgnoreCase(channelType)
                    && pegaResponse.getServiceBody().getServiceResponse().getContext() != null) {
                rr.setCaseId(pegaResponse.getServiceBody().getServiceResponse().getContext().getCaseId());
                setDataFromCartInfo(httpResponse, request, rr, pegaResponse, channelType, isCartOperationWithUUIDAndAcNextGenCookieMVA);
                if (pegaResponse.getServiceBody().getServiceResponse().getContext()
                        .getShowAALPromoIntercept() != null)
                    rr.setShowAALPromoIntercept(pegaResponse.getServiceBody().getServiceResponse().getContext()
                            .getShowAALPromoIntercept());
                if (null != pegaResponse.getServiceBody().getServiceResponse().getContext().getContextInfo()) {
                    rr.setProcessStep(pegaResponse.getServiceBody().getServiceResponse().getContext()
                            .getContextInfo().getProcessStep());
                    rr.setCradleFlowJourney(pegaResponse.getServiceBody().getServiceResponse().getContext().getContextInfo().getCradleFlowJourney());

                }

                setExistingCase(rr, pegaResponse);
            }
        }
    }

    private void setDataFromCartInfo(ServerHttpResponse httpResponse, AddDeviceUIRequest request, CartRedisData rr, AddDeviceUIResponse pegaResponse, String channelType, boolean isCartOperationWithUUIDAndAcNextGenCookieMVA) {
        if (!CartConstants.ASSISTED.equalsIgnoreCase(channelType) && pegaResponse.getServiceBody()
                .getServiceResponse().getContext().getCartInfo() != null) {
            setAcNextGenCookie(httpResponse, request, pegaResponse, isCartOperationWithUUIDAndAcNextGenCookieMVA);
            rr.setCartId(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()
                    .getCartId());
            if (StringUtilities.isNotEmptyOrNull(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()
                    .getEcpdProfileId())) {
                rr.setEcpdId(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()
                        .getEcpdProfileId());
            }
            setDataFromLines(rr, pegaResponse);
        }
    }

    private static void setDataFromLines(CartRedisData rr, AddDeviceUIResponse pegaResponse) {
        if (pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()
                .getLines() != null) {
            Line[] lines = pegaResponse.getServiceBody().getServiceResponse().getContext()
                    .getCartInfo().getLines();

            if (null != lines && lines.length > 0
                    && StringUtilities.isNotEmptyOrNull(lines[0].getMtn())) {
                rr.setProcessingMTN(lines[0].getMtn());
            }

            if (null != lines && lines.length > 0 && lines[0].getDevice() != null
                    && StringUtilities.isNotEmptyOrNull(lines[0].getDevice().getId())) {
                rr.setDeviceSorIdForRecommendations(lines[0].getDevice().getId());
            }
        }
    }

    private static void setExistingCase(CartRedisData rr, AddDeviceUIResponse pegaResponse) {
        if (null != pegaResponse.getServiceBody().getServiceResponse().getContext().getContextInfo() &&
                null != pegaResponse.getServiceBody().getServiceResponse().getContext().getCustomerInfo()) {
            if (StringUtilities.isNotEmptyOrNull(pegaResponse.getServiceBody().getServiceResponse().getContext().getCustomerInfo().getExistingCase())) {
                rr.setExistingCase(pegaResponse.getServiceBody().getServiceResponse().getContext().getCustomerInfo().getExistingCase());
            } else {
                rr.setExistingCase(CartConstants.FALSE);
            }
        }
    }

    private void addCartItemCountToCookie(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse, AddDeviceUIRequest request, String flowPath, String channelType, AddDeviceUIResponse pegaResponse) {
        if (flowPath != null && !flowPath.isEmpty() && flowPath.contains("/cart/nse/add-device")) {
            httpResponse.addCookie(
                    ResponseCookie.from(CartConstants.PROSPECT_CART_AVAILABLE, CartConstants.TRUE_FLAG).path("/").httpOnly(false).build());
            if (CartConstants.DIGITAL.equalsIgnoreCase(channelType) && request != null && request.getCartInfo() != null &&
                    request.getCartInfo().getIntendType() != null && (CartConstants.NSE.equalsIgnoreCase(request.getCartInfo().getIntendType()) ||
                    CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType()))) {
                if (pegaResponse != null && pegaResponse.getServiceBody() != null
                        && pegaResponse.getServiceBody().getServiceResponse() != null
                        && pegaResponse.getServiceBody().getServiceResponse().getContext() != null
                        && pegaResponse.getServiceBody().getServiceResponse().getContext().getContextInfo() != null &&
                        pegaResponse.getServiceBody().getServiceResponse().getContext().getContextInfo().getProcessStep() != null) {
                    boolean isHubProspectCartCookieDomainIssueFFlagEnabled = featureFlagHelper.isHubProspectCartCookieDomainIssueFFlagEnabled();
                    if (prospectHubCartCookieTrueList.contains(pegaResponse.getServiceBody().getServiceResponse().getContext().getContextInfo().getProcessStep()) ||
                            cradleFlowJourneyList.contains(pegaResponse.getServiceBody().getServiceResponse().getContext().getContextInfo().getCradleFlowJourney())) {
                        CartUtil.addHubProspectCartCookieToResponse(httpResponse, isHubProspectCartCookieDomainIssueFFlagEnabled, CartConstants.TRUE_FLAG, domains);
                    } else {
                        httpResponse.addCookie(
                                ResponseCookie.from(CartConstants.NSE_CART_ITEMS_AVAILABLE, CartConstants.TRUE_FLAG).path("/").httpOnly(false).build());
                        CartUtil.addHubProspectCartCookieToResponse(httpResponse, isHubProspectCartCookieDomainIssueFFlagEnabled, CartConstants.FALSE, domains);
                    }
                }
            }
            /*Add cartItem count in cookie*/
            CartAddDeviceUtil.createCookieCartCount(httpResponse, pegaResponse, CartConstants.PROSPECT_CART_COUNT,domains);
            createCookieDeviceCount(httpResponse, request, pegaResponse, CartConstants.PROSPECT_DEVICE_COUNT);
            addQuickShopProspectCookie(request, pegaResponse, httpHeader, httpResponse);
        } else {
            String processStep = Optional.ofNullable(pegaResponse.getServiceBody())
                    .map(AddDeviceServiceBody::getServiceResponse)
                    .map(AddDeviceServiceResponse::getContext)
                    .map(AddDeviceContext::getContextInfo)
                    .map(CartServiceContextInfo::getProcessStep)
                    .orElse("");
            if(StringUtilities.isNotEmptyOrNull(processStep) && !CartConstants.NO_CART_COUNT_UPDATE_PAGE_LIST.contains(processStep))
            {
                CartAddDeviceUtil.createCookieCartCount(httpResponse, pegaResponse, CartConstants.EXISTING_CART_COUNT,domains);
            }
        }
    }

    private Mono<ResponseEntity<GenericResponse>> updateVzdlDataForAiQuote(ServerHttpResponse httpResponse, AddDeviceUIRequest request, Vzdl vzdl, String channelType, AddDeviceUIResponse pegaResponse, CartRedisData rr) {
        if (vzdl != null) {
            logger.info(CartConstants.VZDL_OBJ, vzdl);
            deviceHelper.updateDLDataForAssisted(vzdl);
        }
        return updateDLDataForAssistedAddDevice(httpResponse, request, channelType, pegaResponse, rr);
    }

    private Mono<ResponseEntity<GenericResponse>> updateDLDataForAssistedAddDevice(ServerHttpResponse httpResponse, AddDeviceUIRequest request, String channelType, AddDeviceUIResponse pegaResponse, CartRedisData rr) {
        if (CartConstants.ASSISTED.equalsIgnoreCase(channelType)) {
            try {
                return featureFlagHelper.fetchAssistedTaggingFeatureFlag().flatMap(taggingEnabled -> updateDLDataForAssisted(httpResponse, request, pegaResponse, rr, taggingEnabled));

            } catch (Exception e) {
                logger.error("Error on  Tagging", e);
            }
        }

        return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(pegaResponse));
    }

    private Mono<ResponseEntity<GenericResponse>> updateDLDataForAssisted(ServerHttpResponse httpResponse, AddDeviceUIRequest request, AddDeviceUIResponse pegaResponse, CartRedisData rr, Boolean taggingEnabled) {
        if (taggingEnabled && request.getData().getEnableAssistedTagging() && deviceHelper.flexV2(request)) {
            return updateDLDataForAssistedFlexV2(httpResponse, request, pegaResponse, rr);
        }
        return updateDLDataForAssistedNonFlexV2(httpResponse, request, pegaResponse, rr, taggingEnabled);
    }

    private Mono<ResponseEntity<GenericResponse>> updateDLDataForAssistedFlexV2(ServerHttpResponse httpResponse, AddDeviceUIRequest request, AddDeviceUIResponse pegaResponse, CartRedisData rr) {
        Optional<Lines> requestLine = Optional.ofNullable(request).map(AddDeviceUIRequest::getData).map(AddDeviceData::getLines).map(lines -> !lines.isEmpty() ? lines.get(0) : null);
        String featureId = deviceHelper.fetchFeatureId(requestLine);
        List<String> featureIds = new ArrayList<>();
        featureIds.add(featureId);
        return catalogServiceHelper.getCatalogDomainData(null, null, null, featureIds, null)
                .flatMap(domainCatalogRes -> {
                    FeatureCatalogItem featureCatalogItem = cartServiceCxpHelper2.fetchFeatureCatalogResp(featureId, domainCatalogRes);
                    Vzdl vzdl = deviceHelper.getVzdlData(request, pegaResponse, rr, featureCatalogItem);
                    String indentType = deviceHelper2.mapIntendType(request.getCartInfo(), request.getData());
                    if (indentType != null) {
                        if (vzdl != null && vzdl.getPage() != null) {
                            return omniDlHelper.setFlow(request.getFlowName(), indentType).flatMap(flowName -> {
                                vzdl.getPage().setFlow(flowName);
                                deviceHelper.updateDLDataForAssisted(vzdl);
                                return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(pegaResponse));
                            });
                        }
                    }
                    if (vzdl != null) {
                        deviceHelper.updateDLDataForAssisted(vzdl);
                    }
                    return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(pegaResponse));
                });
    }

    private Mono<ResponseEntity<GenericResponse>> updateDLDataForAssistedNonFlexV2(ServerHttpResponse httpResponse, AddDeviceUIRequest request, AddDeviceUIResponse pegaResponse, CartRedisData rr, Boolean taggingEnabled) {
        if (taggingEnabled && !request.getCartInfo().isFlexV2()) {
            String indentType = deviceHelper2.mapIntendType(request.getCartInfo(), request.getData());
            Vzdl vzdl = deviceHelper.getVzdlData(request, pegaResponse, rr, null);
            if (vzdl != null) {
                deviceHelper.updateDLDataForAssisted(vzdl);
            }
            if (indentType != null && pegaResponse.getServiceBody() != null) {
                return omniDlHelper.setFlow(request.getFlowName(), indentType).flatMap(flow -> {
                    if (CartAddDeviceUtil.pegaResponseEmptyOrNot(pegaResponse)) {
                        pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setFlow(flow);
                    }
                    return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(pegaResponse));
                });
            }
        }
        return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(pegaResponse));
    }

    private void setAcNextGenCookie(ServerHttpResponse httpResponse, @RequestBody @Valid AddDeviceUIRequest request, AddDeviceUIResponse pegaResponse,boolean isCartOperationWithUUIDAndAcNextGenCookieMVA ) {
        try {
            if(CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId())) && "NSE".equals(request.getCartInfo().getIntendType())
                    && StringUtilities.isNotEmptyOrNull(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartId())) {
                byte[] bytes = pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()
                        .getCartId().getBytes("UTF-8");
                String encodedCartId = Base64.getEncoder().encodeToString(bytes);

                if (isCartOperationWithUUIDAndAcNextGenCookieMVA
                        && request.getChannelId().contains(CartConstants.VZW_MFA)
                        && request.getHttpRequest() != null
                        && !request.getHttpRequest().getCookies().isEmpty()
                        && request.getHttpRequest().getCookies().getFirst(CartConstants.UUID) != null) {
                    logger.info("maximum duration for cookie in MVA: {}", maxDurationForMVACookie);
                    httpResponse.addCookie(ResponseCookie.from(CartConstants.AC_NEXTGEN, encodedCartId)
                            .path("/").httpOnly(false).secure(true).maxAge(Duration.ofDays(Long.parseLong(maxDurationForMVACookie))).build());
                    /* We are setting the acNextGenExpireDate for MVA cookie and if the date not expired then
					we are going to populate the cart icon with red dot/ abondan cart popup in prospect page in next sessions*/
                    httpResponse.addCookie(ResponseCookie.from(CartConstants.AC_NEXT_GEN_EXPIRY_DATE,CartUtil.generateExpireDate(CartConstants.DATE_FORMAT_MM_DD_YYYY_HH_MM,30) )
                            .path("/").httpOnly(false).secure(true).build());
                }else {
                    logger.info("maximum duration for cookie: {}", maxDurationForCookie);
                    httpResponse.addCookie(ResponseCookie.from(CartConstants.AC_NEXTGEN, encodedCartId)
                            .path("/").httpOnly(false).secure(true).maxAge(Duration.ofDays(Long.parseLong(maxDurationForCookie))).build());
                }
                logger.info("acNextGen Cookie added: {}", encodedCartId);
            }
        } catch (Exception e) {
            logger.error("Exception while setting acNextGen cookie", e);
        }
    }


    @SuppressWarnings("unchecked")
    public void updateRTMCdlCartCookie(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse
            , Map<String, String> cdlCartMap, String sessionId, boolean addDevice) {
        try {
            boolean cdlCartCookieEnabled = false;
            if(httpResponse.getCookies() != null && httpResponse.getCookies().get(Constants.THROTTLE_LIST_COOKIE_NAME) != null
                    && httpResponse.getCookies().get(Constants.THROTTLE_LIST_COOKIE_NAME).size()>0) {
                String cdlThrottleList = httpResponse.getCookies().get(Constants.THROTTLE_LIST_COOKIE_NAME).get(0).getValue();
                cdlCartCookieEnabled = cdlThrottleList!=null && cdlThrottleList.contains(CartConstants.ABANDON_CART);
            }

            if(cdlCartCookieEnabled) {
                CradleUtil cradleUtil = new CradleUtil();
                Map<String, String> cdlUpdatedMap = new HashMap<>();
                if (httpHeader.getCookies().get(CartConstants.CDL_CART_INFO) != null
                        && !httpHeader.getCookies().get(CartConstants.CDL_CART_INFO).isEmpty()) {
                    String cdlCartInfo = CradleUtil.getDecryptJSON(httpHeader.getCookies().get(CartConstants.CDL_CART_INFO).get(0).getValue());
                    Gson gson = new Gson();
                    Map<String, String> oldCart = gson.fromJson(cdlCartInfo, Map.class);
                    if(oldCart!=null && oldCart.get(CartConstants.RTM_SESSION_ID) != null
                            && oldCart.get(CartConstants.RTM_SESSION_ID).equalsIgnoreCase(sessionId)) {
                        cdlUpdatedMap.putAll(oldCart);
                    }
                }

                if (cdlCartMap != null && !cdlCartMap.isEmpty()) {
                    if (cdlUpdatedMap.isEmpty()) {
                        cdlUpdatedMap.putAll(cdlCartMap);
                    } else if (addDevice) {
                        boolean newPhone = CartConstants.SMARTPHONES.equalsIgnoreCase(cdlCartMap.get(CartConstants.CATEGORY_ID));
                        boolean existingPhone = CartConstants.SMARTPHONES.equalsIgnoreCase(cdlUpdatedMap.get(CartConstants.CATEGORY_ID));
                        if (newPhone) {
                            cdlUpdatedMap.putAll(cdlCartMap);
                        } else if (false == existingPhone) {
                            cdlUpdatedMap.putAll(cdlCartMap);
                        }
                    }
                    cdlUpdatedMap.put(CartConstants.CART_TYPE, CartConstants.DEVICE);
                    cdlUpdatedMap.put(CartConstants.RTM_SESSION_ID, sessionId);
                    httpResponse.addCookie(ResponseCookie.from(CartConstants.CDL_CART_TYPE,CartConstants.DEVICE)
                            .path("/").httpOnly(false).secure(true).maxAge(Duration.ofDays(15)).build());
                }
                httpResponse.addCookie(ResponseCookie.from(CartConstants.CDL_CART_INFO,
                                cradleUtil.getEncryptString(validator.convertObjectToString(cdlUpdatedMap)))
                        .path("/").httpOnly(false).secure(true).maxAge(Duration.ofDays(15)).build());
            }
        } catch (Exception ex) {
            logger.error("Exception while creating abondon cart cookie", ex);
        }
    }

    private void removeSensitiveInfo(AddDeviceUIRequest request, AddDeviceUIResponse pegaResponse) {
        if (pegaResponse != null && pegaResponse.getServiceBody() != null
                && CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))
                && pegaResponse.getServiceBody().getServiceResponse() != null
                && pegaResponse.getServiceBody().getServiceResponse().getContext() != null) {

            pegaResponse.getServiceBody().getServiceResponse().getContext().setCaseId(null);
            Optional.of(pegaResponse.getServiceBody().getServiceResponse().getContext()).map(AddDeviceContext::getCustomerInfo).ifPresent(customerInfo -> customerInfo.setAccountNumber(null));
            Optional<CXPCartVO> cxpCartVOOptional = Optional.of(pegaResponse).map(AddDeviceUIResponse::getValidateCartResponse).map(ValidateCartUIResponse::getData).map(CXPValidateCartDataVO::getValidateCartAndUpdate);
            cxpCartVOOptional.map(CXPCartVO::getCartHeader).ifPresent(cartHeader -> {
                cartHeader.setCartId(null);
                cartHeader.setFullAccountNumber(null);
            });
            if (pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo() != null)
                pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setCartId(null);
            if (pegaResponse.getServiceHeader() != null)
                pegaResponse.getServiceHeader().setClientId(null);
        }
    }

    private ErrorResponse settingErrorResponse(ServerHttpRequest httpHeader, AddDeviceUIRequest request, String methodName) {
        System.setProperty(CartConstants.ENDPOINT, methodName);
        logger.debug(methodName+" Request: {}", request);
        formatHttpHeader(httpHeader, request);
        ErrorResponse errorResponse = CartPegaRequestErrorsUtil.handleAddDeviceRequestErrors(request);
        if (CollectionUtilities.isNotEmptyOrNull(errorResponse.getErrors())) {
            ErrorResponse errors = validator.convertObjectToString(errorResponse);
            if (null != errors) {
                return errors;
            }
        }
        return null;
    }

    @SuppressWarnings("deprecation")
    public void getCookieValues(ServerHttpRequest httpHeader, CreateLineUIRequest createLineRequest,
                                AddDeviceUIRequest addDeviceRequest) {
        HttpCookie cookieCpdToken = httpHeader.getCookies().getFirst(CartConstants.COOKIE_ECPD_TOKEN);
        String ecpdToken = null != httpHeader.getCookies()
                && null != cookieCpdToken
                ? cookieCpdToken.getValue()
                : "";
        String ecpdProfileId =null;
        HttpCookie cookieCpdDomain = httpHeader.getCookies().getFirst(CartConstants.COOKIE_ECPD_DOMAIN);
        String ecpdDomainCookie = null != httpHeader.getCookies()
                && null != cookieCpdDomain
                ? cookieCpdDomain.getValue()
                : "";
        HttpCookie salesRepIdCookie = httpHeader.getCookies().getFirst(CartConstants.COOKIE_SALESREPID);
        String salesRepId = null != httpHeader.getCookies()
                && null != salesRepIdCookie
                ? salesRepIdCookie.getValue()
                : "";
        HttpCookie referralVendorIdCookie = httpHeader.getCookies().getFirst(CartConstants.COOKIE_REFERRAL_VENDOR);
        String referralVendorId = null != httpHeader.getCookies()
                && null != referralVendorIdCookie
                ? referralVendorIdCookie.getValue()
                : "";
        HttpCookie targetPricingOfferCookie = httpHeader.getCookies().getFirst(CartConstants.COOKIE_TARGET_PRICING_OFFER);
        Boolean targetPricingOffer = null != targetPricingOfferCookie
                && Boolean.parseBoolean(targetPricingOfferCookie.getValue());
        if (!StringUtils.isEmpty(ecpdToken)) {
            String[] values = ecpdToken.split(":");
            if (null != values
                    && values.length >= 4) {
                ecpdToken =values[3];
                if (StringUtils.isEmpty(ecpdToken)
                        || (!StringUtils.isEmpty(ecpdToken)
                        && "NULL".equalsIgnoreCase(ecpdToken)) ) {
                    ecpdProfileId = values[0];
                    ecpdToken = null;
                }
            }
        }
        if (createLineRequest != null) {
            createLineRequest.getCartInfo().setReferralSaleRepId(salesRepId);
            if(!StringUtils.isEmpty(ecpdToken))	{
                createLineRequest.getCartInfo().setEcpdToken(ecpdToken);
            }
            if(!StringUtils.isEmpty(ecpdProfileId)) {
                createLineRequest.getCartInfo().setEcpdProfileId(ecpdProfileId);
            }
            createLineRequest.getCartInfo().setRylEcpdUrl(ecpdDomainCookie);
            createLineRequest.getCartInfo().setReferralVendorId(referralVendorId);
            if(CartConstants.NSE.equalsIgnoreCase(createLineRequest.getCartInfo().getIntendType()) && Boolean.TRUE.equals(targetPricingOffer)) {
                createLineRequest.getCartInfo().setRedemptionCode(redemptionCode);
            }
        } else {
            addDeviceRequest.getCartInfo().setReferralSaleRepId(salesRepId);
            addDeviceRequest.getCartInfo().setCartCreatorSalesRepId(salesRepId);
            if(!StringUtils.isEmpty(ecpdToken))	{
                addDeviceRequest.getCartInfo().setEcpdToken(ecpdToken);
            }
            if(!StringUtils.isEmpty(ecpdProfileId)) {
                addDeviceRequest.getCartInfo().setEcpdProfileId(ecpdProfileId);
            }
            addDeviceRequest.getCartInfo().setRylEcpdUrl(ecpdDomainCookie);
            addDeviceRequest.getCartInfo().setReferralVendorId(referralVendorId);
            if(CartConstants.NSE.equalsIgnoreCase(addDeviceRequest.getCartInfo().getIntendType()) && Boolean.TRUE.equals(targetPricingOffer)) {
                addDeviceRequest.getCartInfo().setRedemptionCode(redemptionCode);
            }
        }
    }

    private void formatHttpHeader(ServerHttpRequest httpHeader, AddDeviceUIRequest request) {
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);
        String path = String.valueOf(httpHeader.getPath());
        if(StringUtilities.isNotEmptyOrNull(path)) {
            logger.info("Path is: {}",path);
            request.setPath(path);
        }
    }

    @PostMapping({ "/new-line", "/nse/new-line", "flexV2/new-line" })
    public Mono<ResponseEntity<GenericResponse>> createLine(ServerHttpRequest httpHeader,
                                                            ServerHttpResponse httpResponse, @Valid @RequestBody CreateLineUIRequest request) {
        System.setProperty(CartConstants.ENDPOINT, "new-line");
        logger.debug("new-line Request: {}", request);
        ErrorResponse errors = CartPegaRequestErrorsUtil.handleCreateLineRequestErrors(request);
        if (errors.getErrors() != null)
            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
        String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
                ? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
                : "";
        request.setChannelId(channelId);

        String path = String.valueOf(httpHeader.getPath());
        if(StringUtilities.isNotEmptyOrNull(path)) {
            request.setPath(path);
        }
        String sessionId = "";
        HttpCookie cookieDigitIgSession = httpHeader.getCookies().getFirst(CartConstants.DIGITAL_IG_SESSION);
        Boolean isDvmFlow = CartPegaRequestUtil.isDvmConversionFlagExists();
        if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId)))
            sessionId = null != httpHeader.getCookies()
                    && null != cookieDigitIgSession
                    ? cookieDigitIgSession.getValue()
                    : "";

        getCookieValues(httpHeader, request, null);
        String intendType=request.getCartInfo().getIntendType();
        // Updating cartCreator and globalId with sessionId for New customer flow
        if (CartConstants.NSE.equals(intendType)
                && CartConstants.VZW_DOTCOM.equals(channelId)) {
            request.getCartInfo().setCartCreator(sessionId);
            request.getCartInfo().setGlobalId(sessionId);
        }
        request.getCartInfo().setSessionId(sessionId);
        String finalSessionId = sessionId;
        request.setHttpRequest(httpHeader);
        request.setHttpResponse(httpResponse);
        if (StringUtilities.isNotEmptyOrNull(String.valueOf(httpHeader.getURI())) && CartUtil.isFlexV2(String.valueOf(httpHeader.getURI()))) {
            request.getCartInfo().setFlexV2(true);
        }
        CartRedisData rr = new CartRedisData();
		if (isDvmFlow && StringUtilities.isNotEmptyOrNull(CartPegaRequestUtil.fetchComVzIdFromHeader())) {
			request.setVzId(CartPegaRequestUtil.fetchComVzIdFromHeader());
			rr.setFiosAuthenticated(CartConstants.AUTHENTICATED);
		}
        //isCartOperationWithUUIDEnabledMono  contains the global flag to control overall feature of MVA Prospect flow
        Mono<Boolean> isCartOperationWithUUIDEnabledMono = featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL, FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART, FeatureFlagConstants.FLAG_NAME_CART_OPERATION_WITH_UUID,true);
        //setAcNextGenCookieForMVAMono contains the sub flag to control specific acNextGen cookie feature
        Mono<Boolean> setAcNextGenCookieForMVAMono = featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL, FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART, FeatureFlagConstants.FLAG_NAME_SET_ACNEXTGEN_FOR_MVA,false);
        return Mono.zip(helper.createLine(request), isCartOperationWithUUIDEnabledMono, setAcNextGenCookieForMVAMono).flatMap(tuple -> {
            CreateLineUIResponse pegaResponse = tuple.getT1();
            boolean isCartOperationWithUUIDEnabledPlansFirstFlow = tuple.getT2() && tuple.getT3();
            ErrorResponse errors2 = null;
            if (pegaResponse.getErrors() != null) {
                errors2 = CartPegaResponseErrorsUtil.handleCreateLineResponseErrors(pegaResponse);
            } else {
                logger.info("Inside DL Update method");
                CreateLineContext context = new CreateLineContext();
                if (null != pegaResponse.getServiceBody() && null != pegaResponse.getServiceBody().getServiceResponse()
                        && null != pegaResponse.getServiceBody().getServiceResponse().getContext()) {
                    context = pegaResponse.getServiceBody().getServiceResponse().getContext();
                    setEncodedCookieforNewLine(pegaResponse,request,httpResponse,isCartOperationWithUUIDEnabledPlansFirstFlow);
                }
                String caseId = null != context.getCaseId() ? context.getCaseId() : "";
                String cartId = null != context.getCartInfo() && null != context.getCartInfo().getCartId()
                        ? context.getCartInfo().getCartId()
                        : "";
                String cartCreator = null != context.getCustomerInfo() && null != context.getCustomerInfo().getCartCreator()
                        ? context.getCustomerInfo().getCartCreator()
                        : "";
                logger.info("cartCreator value from pega", null != cartCreator ? cartCreator :CartConstants.EMPTY);
                rr.setCartId(cartId);
                rr.setCaseId(caseId);
                rr.setCartCreator(cartCreator);
                getTanglewoodLine(request,rr);
                if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId())) && (CartConstants.NSE.equalsIgnoreCase(intendType) || CartConstants.NSE_BYOD.equals(intendType))) {
                    var numOfLines=request.getData().getLines().size();
                    logger.info("Setting intendType and deviceCount in cart redis data as : {} {}", intendType,numOfLines);
                    rr.setIntendType(intendType);
                    rr.setDeviceCount(String.valueOf(numOfLines));
                }

                if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId())) && CartConstants.NSE_BYOD.equalsIgnoreCase(request.getCartInfo().getIntendType())){
                    logger.info("Calling dl utility service to update flow");
                    dlUtilityService.updateDlData(CartConstants.NSO);
                }
                if (isDvmFlow){
                    dlUtilityService.upsertVZPageSubFLow(CartConstants.FLOW_TYPE_DVM, true, "");
                }
                boolean isAssisted = StringUtilities.isNotEmptyOrNull(request.getChannelId()) &&
                        CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()));
                if(null !=pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()) {
                    if(StringUtilities.isNotEmptyOrNull(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()
                            .getEcpdProfileId())) {
                        rr.setEcpdId(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()
                                .getEcpdProfileId());
                    }
                }
                if(null!=context&&null!=context.getContextInfo()){
                    rr.setCradleFlowJourney(context.getContextInfo().getCradleFlowJourney());
                }
                if(context!=null && context.getContextInfo()!=null
                        && StringUtilities.isNotEmptyOrNull(context.getContextInfo().getProcessStep())){
                    boolean isHubProspectCartCookieDomainIssueFFlagEnabled = featureFlagHelper.isHubProspectCartCookieDomainIssueFFlagEnabled();
                    if(prospectHubCartCookieTruePageList.contains(context.getContextInfo().getProcessStep())){
                        httpResponse.addCookie(ResponseCookie.from(CartConstants.PROSPECT_CART_AVAILABLE, CartConstants.TRUE_FLAG).path("/").httpOnly(false).build());
                        CartUtil.addHubProspectCartCookieToResponse(httpResponse, isHubProspectCartCookieDomainIssueFFlagEnabled, CartConstants.TRUE_FLAG, domains);
                        rr.setOneClickCheckout(CartConstants.TRUE_FLAG);
                    }

                    else{
                        CartUtil.addHubProspectCartCookieToResponse(httpResponse, isHubProspectCartCookieDomainIssueFFlagEnabled, CartConstants.FALSE, domains);
                    }
                    if (!isAssisted && !CartConstants.NSE_BYOD.equals(intendType)) {
                        cxpHelper.updateDLData(null, null, CartConstants.CREATE_LINE, context.getContextInfo().getProcessStep(), null,null);
                    }
                    if (null != request.getCartInfo() && request.getCartInfo().isFlexV2()) {
                        rr.setDualNumber(redisHelper2.upsertDualNumToRedis(request,context));
                    }
                }
                // Adding for new customer DL object update
                String flowPath = String.valueOf(httpHeader.getPath());

                String globalIdVal = "";
                if (flowPath != null && !flowPath.isEmpty() && flowPath.contains("/cart/nse/new-line")) {
                    if (pegaResponse.getServiceBody().getServiceResponse().getContext().getCustomerInfo()
                            .getGlobalId() == null) {
                        List<HttpCookie> globalId = httpHeader.getCookies().get("GLOBALID");
                        globalIdVal = globalId != null
                                && !globalId.isEmpty()
                                ? globalId.get(0).getValue()
                                : "";
                    }
                    logger.info(finalSessionId != null
                            ? finalSessionId
                            :CartConstants.EMPTY);
                    logger.info(globalIdVal);

                }
                // adding subflow for RAFR
                if(context!=null && context.getCartInfo()!=null && StringUtilities.isNotEmptyOrNull(context.getCartInfo().getCouponCode())
                        && context.getCartInfo().getCouponCode().startsWith(CartConstants.RAFR_PREFIX)){
                    logger.debug("adding {} subflow in vzPageDl",CartConstants.RAFR_SUBFLOW);
                    cxpHelper.appendDlVZPageSubflow(CartConstants.RAFR_SUBFLOW);
                }
                if (CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId())) || (CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId())))) {
                    Mono<Boolean> redisUpsert = redisHelper.updateCartIdAndCaseIdIntoRedis(rr);
                    Mono<CreateLineUIResponse> response = updateSessionForFlowName(request, pegaResponse);
                    return Mono.zip(redisUpsert, response).flatMap(tuple1 -> {
                        logger.info("cartId/caseId upserted in redis {}", tuple1.getT1());
                        return Mono.just(ResponseEntity.status(HttpStatus.OK).body(this.checkIfEligibleForCaptcha(tuple1.getT2(), httpHeader, intendType)));
                    });
                }
            }
            return Mono.just(errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
                    : ResponseEntity.status(HttpStatus.OK).body(this.checkIfEligibleForCaptcha(pegaResponse, httpHeader, intendType)));
        });
    }

    public Mono<CreateLineUIResponse> updateSessionForFlowName(CreateLineUIRequest request, CreateLineUIResponse response) {
        return featureFlagHelper.fetchAssistedTaggingFeatureFlag().flatMap(assistedTagging -> {
            try {
                if (null != assistedTagging && assistedTagging && StringUtilities.isNotEmptyOrNull(request.getChannelId()) &&
                        CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))) {
                    return omniDlHelper.setFlow(omniDlHelper.updateNewLineFlowName(request), "").flatMap(flow -> {
                        if (null != response.getServiceBody() && null != response.getServiceBody().getServiceResponse() &&
                                null != response.getServiceBody().getServiceResponse().getContext() &&
                                null != response.getServiceBody().getServiceResponse().getContext().getCartInfo() & StringUtilities.isNotEmptyOrNull(flow))
                            response.getServiceBody().getServiceResponse().getContext().getCartInfo().setFlow(flow);
                        return Mono.just(response);
                    });
                }
            } catch (Exception e) {
                logger.info("Error while trying to update flow name to redis {}", e);
            }
            return Mono.just(response);
        });
    }

    private void getTanglewoodLine(CreateLineUIRequest request, CartRedisData rr) {
        Optional.ofNullable(request).map(CreateLineUIRequest::getData).map(CreateLineData::getLines).flatMap(lines -> lines.stream().filter(lines1 -> "Y".equalsIgnoreCase(lines1.getTanglewoodSelected())).findFirst()).ifPresent(lines1 -> {
            rr.setTanglewoodSelected("newLine1");
        });
    }
    private void setEncodedCookieforNewLine(CreateLineUIResponse pegaResponse, CreateLineUIRequest request, ServerHttpResponse httpResponse, boolean isCartOperationWithUUIDEnabledPlansFirstFlow) {
        if(CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId())) && "NSE".equals(request.getCartInfo().getIntendType())
                && StringUtilities.isNotEmptyOrNull(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getCartId())){
            try{
                byte[] bytes = pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo()
                        .getCartId().getBytes("UTF-8");
                String acNextGen = Base64.getEncoder().encodeToString(bytes);
                /*
                 * We are setting the expiry date for MVA cookie to 30 days in the if condition
                 * otherwise the cookie is set to 14 days in else part
                 */
                if (isCartOperationWithUUIDEnabledPlansFirstFlow
                        && request.getChannelId().contains(CartConstants.VZW_MFA)
                        && request.getHttpRequest() != null
                        && !request.getHttpRequest().getCookies().isEmpty()
                        && request.getHttpRequest().getCookies().getFirst(CartConstants.UUID) != null) {
                    logger.info("maximum duration for cookie in MVA: {}", maxDurationForMVACookie);
                    httpResponse.addCookie(ResponseCookie.from(CartConstants.AC_NEXTGEN, acNextGen)
                            .path("/").httpOnly(false).secure(true).maxAge(Duration.ofDays(Long.parseLong(maxDurationForMVACookie))).build());
                    /* We are setting the acNextGenExpireDate for MVA cookie and if the date not expired then
					we are going to populate the cart icon with red dot/ abondan cart popup in prospect page in next sessions*/
                    httpResponse.addCookie(ResponseCookie.from(CartConstants.AC_NEXT_GEN_EXPIRY_DATE,CartUtil.generateExpireDate(CartConstants.DATE_FORMAT_MM_DD_YYYY_HH_MM,30) )
                            .path("/").httpOnly(false).secure(true).build());
                } else {
                    logger.info("maximum duration for cookie: {}", maxDurationForCookie);
                    httpResponse.addCookie(ResponseCookie.from(CartConstants.AC_NEXTGEN, acNextGen)
                            .path("/").httpOnly(false).secure(true).maxAge(Duration.ofDays(Long.parseLong(maxDurationForCookie))).build());
                }
            } catch (UnsupportedEncodingException e) {
                logger.error("Exception while setting nextgen cookie",e);
            }
        }

    }

    private CreateLineUIResponse checkIfEligibleForCaptcha(CreateLineUIResponse response, ServerHttpRequest httpHeader,String intendType) {
        final boolean isNOC = !checkIfWhiteListedIps(httpHeader);
        logger.info("checkIfEligibleForCaptcha isNOC - {} ",isNOC);
        if(Boolean.TRUE.equals(isNOC)) {
            Optional.ofNullable(response).map(CreateLineUIResponse::getServiceBody)
                    .map(CreateLineServiceBody::getServiceResponse)
                    .map(CreateLineServiceResponse::getContext)
                    .map(CreateLineContext::getCustomerInfo)
                    .ifPresent(customerInfo ->{
                        if(CartConstants.NSE_BYOD.equalsIgnoreCase(intendType))
                            customerInfo.setNocByod(Boolean.TRUE);
                        else
                        customerInfo.setNoc(Boolean.TRUE);
                    });
        }
        return response;
    }

    private boolean checkIfWhiteListedIps(ServerHttpRequest httpHeader) {
        if(CollectionUtilities.isNotEmptyOrNull(captchaWhileListedIps)){
            String ipAddress = Optional.ofNullable(httpHeader.getHeaders().getFirst(CartConstants.ORIGINATING_CLIENT_IP)).orElse("");
            Boolean captchaEligible =captchaWhileListedIps.stream().noneMatch(whiteListedIPs -> ipAddress.contains(whiteListedIPs));
            logger.info("checkIfWhiteListedIps captchaEligible {} , ipAddress - {} ",captchaEligible,ipAddress);
            return captchaEligible;
        }
        return true ;
    }

    /**
     *
     * @param httpHeader
     * @param httpResponse
     * @param request
     * @return ResponseEntity
     *
     */
    @PostMapping({ "/addDeviceAndPlan", "/nse/addDeviceAndPlan" })
    public Mono<ResponseEntity<GenericResponse>> addDeviceAndPlan(ServerHttpRequest httpHeader,
                                                                  ServerHttpResponse httpResponse, @Valid @RequestBody AddDeviceUIRequest request) {
        // reducing duplication changes
        ErrorResponse errors = settingErrorResponse(httpHeader, request, "addDeviceAndPlan");
        System.out.println("CartUpdateOperationsController.addDeviceAndPlan :: return BAD_REQUEST");
        if (null != errors)
            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
        // GTSFN-2160 - New Customer Transaction Prospect - Add device change
        String sessionId = "";
        String channelType = CartUtil.getChannelType(request.getChannelId());
        HttpCookie cookieAsIgSession = httpHeader.getCookies().getFirst("assisted_ig_session");
        if (CartConstants.ASSISTED.equalsIgnoreCase(channelType))
            sessionId = null != cookieAsIgSession
                    ? cookieAsIgSession.getValue()
                    : "";


        request.getCartInfo().setSessionId(sessionId);

        request.setHttpRequest(httpHeader);
        request.setHttpResponse(httpResponse);
        if ("Y".equalsIgnoreCase(request.getCartInfo().getBuyOutSelected())
                || (request.getCartInfo().getCustomerConsent() != null
                && request.getCartInfo().getCustomerConsent())) {

            Mono<AddDeviceUIResponse> addBuyoutAndConsentResponse = helper.addBuyoutAndConsent(request);
            return addBuyoutAndConsentResponse.flatMap(res -> {
                ErrorResponse errors2 = null;
                if (res.getErrors() != null) {
                    errors2 = CartPegaResponseErrorsUtil.handleAddDeviceResponseErrors(res);
                    return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(errors2));
                } else {
                    if (res.getIsBuyOutAdded() != null || res.getIsConsentUpdated() != null) {
                        if(request.getCartInfo().getSkipTradeIn() != null && !request.getCartInfo().getSkipTradeIn()){
                            return formatTradeIn(request, httpResponse);
                        }else {

                            return deviceHelper.addDevice(request,httpResponse).flatMap(pegaResponse -> {
                                ErrorResponse errors3 = null;
                                if (pegaResponse.getErrors() != null && !httpResponse.getStatusCode().is2xxSuccessful()) {
                                    errors3 = CartPegaResponseErrorsUtil.handleAddDeviceResponseErrors(pegaResponse);
                                    return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(errors3));

                                } else {
                                    return updateOfferDataIntoRedis(request).flatMap(data -> {
                                        return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(pegaResponse));
                                    });

                                }
                            });
                        }

                    } else {
                        List<CartError> error= new ArrayList<>();
                        CartError err = new CartError();
                        err.setNamespace("cxp-cart");
                        err.setMessage("Buyout/Consent not added to cart");
                        error.add(err);
                        res.setErrors(error);
                        return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(res));
                    }
                }
            });
        }else {
            if(request.getCartInfo().getSkipTradeIn() != null && !request.getCartInfo().getSkipTradeIn()){
                return formatTradeIn(request, httpResponse);
            }
            else {

                return deviceHelper.addDevice(request, httpResponse).flatMap(pegaResponse -> {
                    ErrorResponse errors2 = null;
                    if (pegaResponse.getErrors() != null && !httpResponse.getStatusCode().is2xxSuccessful()) {
                        errors2 = CartPegaResponseErrorsUtil.handleAddDeviceResponseErrors(pegaResponse);
                        return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(errors2));
                    } else {
                        return updateOfferDataIntoRedis(request).flatMap(data -> {
                            return Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(pegaResponse));
                        });
                    }
                });
            }
        }
    }

    public HttpStatus processHttpStatusForPega(HttpStatus statusCode)
    {
        if(statusCode!=null && statusCode.equals(HttpStatus.NOT_FOUND))
        {
            statusCode = HttpStatus.OK;
        }
        return statusCode;
    }

    /**
     * *
     * @param request
     * @param pegaResponse
     * @param httpHeader
     * @param httpResponse
     */
    public void addQuickShopProspectCookie(@Valid AddDeviceUIRequest request, AddDeviceUIResponse pegaResponse, ServerHttpRequest httpHeader, ServerHttpResponse httpResponse) {
        /*Add quickShopProspectCart in cookie*/
        if(enableQuickShopFlow && CollectionUtils.isEmpty(pegaResponse.getErrors()) && CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))) {
            if (null != request.getCartInfo().getQuickShop()) {
                logger.info("Update quickShopProspectCart cookie to {} when the customer enters quick shop flow", request.getCartInfo().getQuickShop());
                httpResponse.addCookie(ResponseCookie.from(CartConstants.QUICK_SHOP_PROSPECT_CART, CartConstants.TRUE_FLAG)
                        .path("/").httpOnly(false).build());
                if (featureFlag.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                        FeatureFlagConstants.CONFIG_PROFILE_QUICKSHOP_PDP, FeatureFlagConstants.FLAG_NAME_FOR_QUICKSHOP_TRADEIN,false)) {
                    dlService.buildDLData(OmniBuilder.buildAddDeviceDataForQuickShopFlow(pegaResponse));
                }
            } else {
                MultiValueMap<String, HttpCookie> cookie = httpHeader.getCookies();
                if (null != cookie && null != httpResponse.getCookies() && null != cookie.get(CartConstants.QUICK_SHOP_PROSPECT_CART)) {
                    httpResponse.addCookie(ResponseCookie.from(CartConstants.QUICK_SHOP_PROSPECT_CART, "")
                            .maxAge(0).path("/").httpOnly(false).build());
                }
            }
        }
    }

    public void createCookieDeviceCount(ServerHttpResponse httpResponse, AddDeviceUIRequest request, AddDeviceUIResponse pegaResponse, String cartCount) {
        if (pegaResponse != null && pegaResponse.getServiceBody() != null
                && CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(request.getChannelId()))
                && pegaResponse.getServiceBody().getServiceResponse() != null
                && pegaResponse.getServiceBody().getServiceResponse().getContext() != null
                && pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo() != null
                && pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getLineDevices() != null) {
            httpResponse.addCookie(ResponseCookie.from(cartCount,
                            String.valueOf(pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getLineDevices().length))
                    .path("/").httpOnly(false).build());
        }
    }


    @PostMapping({"/dfoToDppCart"})
    public Mono<ResponseEntity<GenericResponse>> dfoToDppCart(ServerHttpRequest httpHeader,
                                                           ServerHttpResponse httpResponse,
                                                                     @Valid @RequestBody AddDeviceUIRequest request) throws SOEHTTPException {
        return deviceHelper.dfoToDppCart(httpHeader,httpResponse,request);

    }


}
