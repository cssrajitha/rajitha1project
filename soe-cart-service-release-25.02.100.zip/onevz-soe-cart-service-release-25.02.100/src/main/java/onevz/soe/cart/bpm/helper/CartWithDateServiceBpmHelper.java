package onevz.soe.cart.bpm.helper;

import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.bpm.service.CartServiceBPMServices;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.cartwithdate.*;
import onevz.soe.cart.requests.CartWithDatePegaRequest;
import onevz.soe.cart.responses.CartWithDatePegaResponse;
import onevz.soe.cart.ui.requests.CartWithDateUIRequest;
import onevz.soe.cart.util.CommonUtil;
import onevz.soe.wsclient.bpm.model.CustomerInfo;
import onevz.soe.wsclient.bpm.model.response.Error;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class CartWithDateServiceBpmHelper {

    @Autowired
    private CartServiceBPMServices services;

    @Autowired
    private ObjectMapper mapper;
    
    @Autowired
    private CommonUtil util;

    private static final Logger logger = LoggerFactory.getLogger(CartWithDateServiceBpmHelper.class);

    /**
     * @param uiRequest
     * @return UpdateCartWithDatePegaResponse
     * @throws IOException
     */
    public Mono<CartWithDatePegaResponse> saveCartWithDate(CartWithDateUIRequest uiRequest)
            throws IOException {

        CartWithDatePegaRequest request = formatSaveApptRequest(uiRequest);
        logger.info("UpdateCartWithDate PEGA Request: {}", mapper.writeValueAsString(request));
        logger.info("UpdateCartWithDate UI Request After Session Call: {}", mapper.writeValueAsString(uiRequest));

        Mono<CartWithDatePegaResponse> responseServiceMono = null;
        try {
            // pega call
            responseServiceMono = services.updateCartWithDate(request);
        } catch (SOEHTTPException e) {
            logger.error(CartConstants.PEGA_RSPNS_FTCH_EXCPTN_STRNG, e);
        }
        return responseServiceMono==null?Mono.just(new CartWithDatePegaResponse()):responseServiceMono.flatMap(pegaResponse->{
            logger.info("Pega response for UpdateCartWithDate : {}", pegaResponse);
            return Mono.just(pegaResponse);
        }).onErrorResume(err -> {
            logger.info("Error while calling Pega for UpdateCartWithDate : {}", err.getMessage());
            SOEHTTPException exception = (SOEHTTPException) err;
            List<Error> errors = new ArrayList<>();
            CartWithDatePegaResponse  errorResponse= new CartWithDatePegaResponse();
            errors = util.formatError(exception, errors);
            errorResponse.setErrors(errors);
            return Mono.just(errorResponse);
        });
    }


    /**
     * @return ServiceHeader
     */
    public CartWithDatePegaResServiceHeader addServiceHeader() {
        CartWithDatePegaResServiceHeader serviceHeader = new CartWithDatePegaResServiceHeader();
        serviceHeader.setStatusMsg("PEGA generated message");
        serviceHeader.setSessionId("");
        serviceHeader.setServiceName(CartConstants.SALES_ORDER_PURCHASE);
        serviceHeader.setUserId("");
        serviceHeader.setStatusCode("0");
        return serviceHeader;
    }

    /**
     * @param request
     * @return UpdateCartWithDatePegaRequest
     */
    public CartWithDatePegaRequest formatSaveApptRequest(CartWithDateUIRequest request) {

        CartWithDatePegaReqServiceBody serviceBody = new CartWithDatePegaReqServiceBody();
        CartWithDatePegaReqServiceRequest serviceRequest = new CartWithDatePegaReqServiceRequest();
        CartWithDatePegaReqContext context = new CartWithDatePegaReqContext();
        CartWithDatePegaReqContextInfo pegaContextInfo = getContextInfo(request);

        CustomerInfo customerInfo = getCustomerInfoForUpdateCartWithDatePega(request);
        CartWithDatePegaReqCartInfo cartInfo = getCartInfoForUpdateCartWithDatePega(request);

        context.setContextInfo(pegaContextInfo);
        context.setCartInfo(cartInfo);
        context.setCustomerInfo(customerInfo);
        context.setCaseId(request.getCartWithDateContext().getCaseId());
        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        CartWithDatePegaRequest pegaRequest = new CartWithDatePegaRequest();
        pegaRequest.setServiceHeader(addServiceHeader());
        pegaRequest.setServiceBody(serviceBody);

        return pegaRequest;
    }

    private CartWithDatePegaReqContextInfo getContextInfo(CartWithDateUIRequest request) {
        CartWithDatePegaReqContextInfo contextInfo = new CartWithDatePegaReqContextInfo();
        contextInfo.setCallReason(null != request.getCartWithDateContext().getContextInfo().getCallReason() ?
                request.getCartWithDateContext().getContextInfo().getCallReason() : "");
        contextInfo.setProcessStep(null != request.getCartWithDateContext().getContextInfo().getProcessStep() ?
                request.getCartWithDateContext().getContextInfo().getProcessStep() : "");
        contextInfo.setProcessAction(null != request.getCartWithDateContext().getContextInfo().getProcessAction() ?
                request.getCartWithDateContext().getContextInfo().getProcessAction() : "");
        contextInfo.setIntent(null != request.getCartWithDateContext().getContextInfo().getIntent() ?
                request.getCartWithDateContext().getContextInfo().getIntent() : "");
        return contextInfo;

    }

    private CartWithDatePegaReqCartInfo getCartInfoForUpdateCartWithDatePega(CartWithDateUIRequest request) {

        CartWithDatePegaReqCartInfo ci = new CartWithDatePegaReqCartInfo();
        ci.setCartId(null != request.getCartWithDateContext().getCartInfo().getCartId() ? request.getCartWithDateContext().getCartInfo().getCartId() : "");
        ci.setItemType(null != request.getCartWithDateContext().getCartInfo().getItemType() ? request.getCartWithDateContext().getCartInfo().getItemType() : "");
        ci.setIntendType(null != request.getCartWithDateContext().getCartInfo().getIntendType() ? request.getCartWithDateContext().getCartInfo().getIntendType() : "");
        CartWithDatePegaReqScheduleAppointmentInfo scheduleAppointmentInfo = null != request.getCartWithDateContext().getCartInfo().getScheduleAppointmentInfo() ?
                getScheduleAppointmentInfoNotNull(request) : getScheduleAppointmentInfoNull();
        CartWithDateUIMoversInfo moversInfo = null != request.getCartWithDateContext().getCartInfo().getMoversInfo() ?
                getMoversInfoNotNull(request.getCartWithDateContext().getCartInfo().getMoversInfo()) : getMoversInfoNull();
        ci.setScheduleAppointmentRequest(scheduleAppointmentInfo);
        ci.setMoversInfoRequest(moversInfo);
        return ci;
    }

    private CartWithDateUIMoversInfo getMoversInfoNull() {
        CartWithDateUIMoversInfo moversInfo = new CartWithDateUIMoversInfo();
        moversInfo.setMoveInDate("");
        moversInfo.setMoveOutDate("");
        return moversInfo;
    }

    private CartWithDateUIMoversInfo getMoversInfoNotNull(CartWithDateUIMoversInfo moversInfoUi) {
        CartWithDateUIMoversInfo moversInfo = new CartWithDateUIMoversInfo();
        moversInfo.setMoveInDate(moversInfoUi.getMoveInDate());
        moversInfo.setMoveOutDate(moversInfoUi.getMoveOutDate());
        return moversInfo;
    }

    private CartWithDatePegaReqScheduleAppointmentInfo getScheduleAppointmentInfoNull() {
        CartWithDatePegaReqScheduleAppointmentInfo scheduleAppointmentInfo = new CartWithDatePegaReqScheduleAppointmentInfo();
        scheduleAppointmentInfo.setCartLineMtn("");
        scheduleAppointmentInfo.setCartId("");
        scheduleAppointmentInfo.setApptInfo(getPegaFormatAaptInfoNull());
        return scheduleAppointmentInfo;
    }

    private CartWithDatePegaReqScheduleAppointmentInfo getScheduleAppointmentInfoNotNull(CartWithDateUIRequest request) {
        CartWithDatePegaReqScheduleAppointmentInfo scheduleAppointmentInfo = new CartWithDatePegaReqScheduleAppointmentInfo();
        scheduleAppointmentInfo.setCartLineMtn(null != request.getCartWithDateContext()
                .getCartInfo().getScheduleAppointmentInfo().getCartLineMtn() ? request.getCartWithDateContext().getCartInfo().
                getScheduleAppointmentInfo().getCartLineMtn() : "");
        scheduleAppointmentInfo.setCartId(null != request.getCartWithDateContext()
                .getCartInfo().getScheduleAppointmentInfo().getCartLineMtn() ? request.getCartWithDateContext().getCartInfo().
                getScheduleAppointmentInfo().getCartId() : "");
        CartWithDatePegaReqApptInfo apptinfo = null != request.getCartWithDateContext().getCartInfo().getScheduleAppointmentInfo().getApptInfo() ?
                getPegaFormatAaptInfoNotNull(request.getCartWithDateContext().getCartInfo().getScheduleAppointmentInfo().getApptInfo()) :
                getPegaFormatAaptInfoNull();
        scheduleAppointmentInfo.setApptInfo(apptinfo);

        return scheduleAppointmentInfo;

    }

    private CartWithDatePegaReqApptInfo getPegaFormatAaptInfoNull() {
        CartWithDatePegaReqApptInfo apptinfo = new CartWithDatePegaReqApptInfo();
        apptinfo.setHomePhone("");
        apptinfo.setPrimaryPhoneType("");
        apptinfo.setPreferredContactType("");
        apptinfo.setEmailAddress("");
        apptinfo.setFirstName("");
        apptinfo.setLastName("");
        apptinfo.setInstallationFloor("");
        apptinfo.setLanguagePref("");
        apptinfo.setCustomerInstructions("");
        apptinfo.setEventCorrelationId("");
        apptinfo.setInstallApptSelectedDateInfo(getInstallApptNull());
        return apptinfo;
    }

    private CartWithDatePegaReqApptInfo getPegaFormatAaptInfoNotNull(CartWithDatePegaReqApptInfo uiApptInfo) {
        CartWithDatePegaReqApptInfo apptinfo = new CartWithDatePegaReqApptInfo();
        apptinfo.setHomePhone(null != uiApptInfo.getHomePhone() ? uiApptInfo.getHomePhone() : "");
        apptinfo.setPrimaryPhoneType(null != uiApptInfo.getPrimaryPhoneType() ? uiApptInfo.getPrimaryPhoneType() : "");
        apptinfo.setPreferredContactType(null != uiApptInfo.getPreferredContactType() ? uiApptInfo.getPreferredContactType() : "");
        apptinfo.setEmailAddress(null != uiApptInfo.getEmailAddress() ? uiApptInfo.getEmailAddress() : "");
        apptinfo.setFirstName(null != uiApptInfo.getFirstName() ? uiApptInfo.getFirstName() : "");
        apptinfo.setLastName(null != uiApptInfo.getLastName() ? uiApptInfo.getLastName() : "");
        apptinfo.setInstallationFloor(null != uiApptInfo.getInstallationFloor() ? uiApptInfo.getInstallationFloor() : "");
        apptinfo.setLanguagePref(null != uiApptInfo.getLanguagePref() ? uiApptInfo.getLanguagePref() : "");
        apptinfo.setCustomerInstructions(null != uiApptInfo.getCustomerInstructions() ? uiApptInfo.getCustomerInstructions() : "");
        apptinfo.setEventCorrelationId(null != uiApptInfo.getEventCorrelationId() ? uiApptInfo.getEventCorrelationId() : "");
        CartWithDateUIInstallApptSelectedDateInfo installApptSelectedDateInfo = null != uiApptInfo.getInstallApptSelectedDateInfo() ?
                getInstallApptNotNull(uiApptInfo) : getInstallApptNull();
        apptinfo.setInstallApptSelectedDateInfo(installApptSelectedDateInfo);
        return apptinfo;
    }

    private CartWithDateUIInstallApptSelectedDateInfo getInstallApptNull() {
        CartWithDateUIInstallApptSelectedDateInfo installApptSelectedDateInfo = new CartWithDateUIInstallApptSelectedDateInfo();
        installApptSelectedDateInfo.setAvailableDate("");
        installApptSelectedDateInfo.setAvailableDay("");
        installApptSelectedDateInfo.setAvailableType("");
        installApptSelectedDateInfo.setServiceProviderAccount("");
        installApptSelectedDateInfo.setServiceProviderName("");
        installApptSelectedDateInfo.setSlotLength("");
        installApptSelectedDateInfo.setSlotStartTime("");
        return installApptSelectedDateInfo;
    }

    private CartWithDateUIInstallApptSelectedDateInfo getInstallApptNotNull(CartWithDatePegaReqApptInfo uiApptInfo) {
        CartWithDateUIInstallApptSelectedDateInfo installApptSelectedDateInfo = new CartWithDateUIInstallApptSelectedDateInfo();
        installApptSelectedDateInfo.setAvailableDate(null != uiApptInfo.
                getInstallApptSelectedDateInfo().getAvailableDate() ? uiApptInfo.
                getInstallApptSelectedDateInfo().getAvailableDate() : "");
        installApptSelectedDateInfo.setAvailableDay(null != uiApptInfo.
                getInstallApptSelectedDateInfo().getAvailableDay() ? uiApptInfo.
                getInstallApptSelectedDateInfo().getAvailableDay() : "");
        installApptSelectedDateInfo.setAvailableType(null != uiApptInfo.
                getInstallApptSelectedDateInfo().getAvailableType() ? uiApptInfo.
                getInstallApptSelectedDateInfo().getAvailableType() : "");
        installApptSelectedDateInfo.setServiceProviderAccount(null != uiApptInfo.
                getInstallApptSelectedDateInfo().getServiceProviderAccount() ? uiApptInfo.
                getInstallApptSelectedDateInfo().getServiceProviderAccount() : "");
        installApptSelectedDateInfo.setServiceProviderName(null != uiApptInfo.
                getInstallApptSelectedDateInfo().getServiceProviderName() ? uiApptInfo.
                getInstallApptSelectedDateInfo().getServiceProviderName() : "");
        installApptSelectedDateInfo.setSlotLength(null != uiApptInfo.
                getInstallApptSelectedDateInfo().getSlotLength() ? uiApptInfo.
                getInstallApptSelectedDateInfo().getSlotLength() : "");
        installApptSelectedDateInfo.setSlotStartTime(null != uiApptInfo.
                getInstallApptSelectedDateInfo().getSlotStartTime() ? uiApptInfo.
                getInstallApptSelectedDateInfo().getSlotStartTime() : "");
        return installApptSelectedDateInfo;
    }

    private CustomerInfo getCustomerInfoForUpdateCartWithDatePega(CartWithDateUIRequest request) {

        CustomerInfo cf = new CustomerInfo();
        cf.setAccountNumber(null != request.getCartWithDateContext().getCustomerInfo().getAccountNumber() ? request.getCartWithDateContext().getCustomerInfo().getAccountNumber() : "");
        cf.setCartCreator(null != request.getCartWithDateContext().getCustomerInfo().getCartCreator() ? request.getCartWithDateContext().getCustomerInfo().getCartCreator() : "");
        cf.setProcessingMTN(null != request.getCartWithDateContext().getCustomerInfo().getProcessingMTN() ? request.getCartWithDateContext().getCustomerInfo().getProcessingMTN() : "");
        cf.setRegisterNumber(request.getCartWithDateContext().getCustomerInfo().getRegisterNumber());
        return cf;
    }
}