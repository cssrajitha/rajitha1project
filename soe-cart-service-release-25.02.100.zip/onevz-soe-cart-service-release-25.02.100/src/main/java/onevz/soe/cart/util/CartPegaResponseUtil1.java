package onevz.soe.cart.util;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.initiatecart.CpcFeatureResponse;
import onevz.soe.cart.initiatecart.InitiateCartUIResponse;
import onevz.soe.cart.model.AccessoryFinancingOffers.AccessoryFinancingOffersPegaResponse;
import onevz.soe.cart.model.accountPin.AccountPinContext;
import onevz.soe.cart.model.accountPin.AccountpinServiceBody;
import onevz.soe.cart.model.activateLater.ActivateLaterServiceBody;
import onevz.soe.cart.model.addDevice.AddPlanAndDeviceServiceBody;
import onevz.soe.cart.model.addNickName.AddNickNameServiceBody;
import onevz.soe.cart.model.addTrialContactInfoAndAddress.AddTrialContactInfoAndAddressServiceBody;
import onevz.soe.cart.model.addTrialContactInfoAndAddress.AddTrialContactInfoAndAddressUIResponse;
import onevz.soe.cart.model.cancelCase.CancelCaseServiceBody;
import onevz.soe.cart.model.checkExistingCart.CheckExistingCartServiceBody;
import onevz.soe.cart.model.clearAndContinue.ClearAndContinueServiceBody;
import onevz.soe.cart.model.clearCart.ClearCartServiceBody;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.common.CartServiceAvailablePaths;
import onevz.soe.cart.model.createCase.*;
import onevz.soe.cart.model.crmRetrieveCart.CrmRetrieveCartBody;
import onevz.soe.cart.model.deleteCart.DeleteCartServiceBody;
import onevz.soe.cart.model.deviceIdValidation.DeviceIdValidationServiceBody;
import onevz.soe.cart.model.getCase.GetCaseResponse;
import onevz.soe.cart.model.getCase.GetCaseServiceBody;
import onevz.soe.cart.model.getCustomerInfo.GraphqlData;
import onevz.soe.cart.model.guestChoice.GuestChoiceServiceBody;
import onevz.soe.cart.model.initiateValidateDeviceSim.InitiateValidateDeviceSimUIResponse;
import onevz.soe.cart.model.manualDiscount.ManualDiscountServiceBody;
import onevz.soe.cart.model.removeLock.RemoveLockServiceBody;
import onevz.soe.cart.model.salesOrderAdjustment.SalesOrderAdjustmentServiceBody;
import onevz.soe.cart.model.salesRepAndLocationCode.SalesRepAndLocationCodeServiceBody;
import onevz.soe.cart.model.splitExceededAmount.SplitExceededAmountServiceBody;
import onevz.soe.cart.model.transferUpgrade.UpdateTransferUpgradeServiceBody;
import onevz.soe.cart.model.updateBarcode.UpdateBarCodeServiceBody;
import onevz.soe.cart.model.updateChatId.UpdateChatIdServiceBody;
import onevz.soe.cart.model.updateEffectiveDate.EffectiveDateServiceBody;
import onevz.soe.cart.model.updateGiftItem.UpdateGiftItemServiceBody;
import onevz.soe.cart.model.updateWFMInfo.UpdateWFMInfoServiceBody;
import onevz.soe.cart.requests.AddMoveDatesPegaResponse;
import onevz.soe.cart.requests.MoversUpdatePlanPegaResponse;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.ui.requests.UpdateGiftItemUIResponse;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.bpm.model.ServiceBody;
import onevz.soe.wsclient.bpm.model.response.AvailablePaths;
import java.util.ArrayList;
import java.util.List;

public class CartPegaResponseUtil1 {

    private CartPegaResponseUtil1() {
    }

    public static void formatUpdateBarCodeResponse(UpdateBarcodeUIResponse uiResponse,
                                                   UpdateBarCodePEGAResponse pegaResponse) {
        if (pegaResponse.getServiceHeader() != null)
            uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
        if (pegaResponse.getServiceBody() != null) {
            UpdateBarCodeServiceBody serviceBody = pegaResponse.getServiceBody();
            if (null != pegaResponse.getServiceHeader() && StringUtilities.isNotEmptyOrNull(pegaResponse.getServiceHeader().getClientId()) &&
                    (pegaResponse.getServiceHeader().getClientId().equalsIgnoreCase(CartConstants.RETAIL) || pegaResponse.getServiceHeader().getClientId().equalsIgnoreCase(CartConstants.RETAIL_IPAD) ||
                            pegaResponse.getServiceHeader().getClientId().equalsIgnoreCase(CartConstants.OMNI_CARE) || pegaResponse.getServiceHeader().getClientId().equalsIgnoreCase(CartConstants.OMNI_INDIRECT) ||
                            pegaResponse.getServiceHeader().getClientId().equalsIgnoreCase(CartConstants.OMNI_INDIRECT_TAB) || pegaResponse.getServiceHeader().getClientId().equalsIgnoreCase(CartConstants.OMNI_TELESALES))) {
                if (serviceBody != null && serviceBody.getServiceResponse() != null && serviceBody.getServiceResponse().getContext() != null
                        && serviceBody.getServiceResponse().getContext().getCartInfo() != null
                        && StringUtilities.isNotEmptyOrNull(serviceBody.getServiceResponse().getContext().getCartInfo().getCouponCode())
                        && serviceBody.getServiceResponse().getContext().getCartInfo().getCouponCode().startsWith(CartConstants.RAF_COUPON_STARTS_WITH)) {
                    serviceBody.getServiceResponse().getContext().getCartInfo().setStatusMsg(CartConstants.RAF_COUPON_VALIDATION_MESSAGE);
                }
            }
            
            uiResponse.setServiceBody(serviceBody);
        }
        if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
            List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
            uiResponse.setErrors(cartError);
        }
    }

    public static void formatDeviceIdValidationResponse(DeviceIdValidationPEGAResponse pegaResponse,
                                                        DeviceIdValidationUIResponse uiResponse) {
        if (pegaResponse.getServiceHeader() != null)
            uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
        if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
            List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
            uiResponse.setErrors(cartError);
        }
        if (pegaResponse.getServiceBody() != null) {
            DeviceIdValidationServiceBody serviceBody = pegaResponse.getServiceBody();
            uiResponse.setServiceBody(serviceBody);
        }
    }

    public static void formatUpdateSalesRepAndLocationCodeResponse(SalesRepAndLocationCodeUIResponse uiResponse,
                                                                   SalesRepAndLocationCodePEGAResponse pegaResponse) {
        if (pegaResponse.getServiceHeader() != null)
            uiResponse.setServiceHeader(pegaResponse.getServiceHeader());

        if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
            List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
            uiResponse.setErrors(cartError);
        }

        if (pegaResponse.getServiceBody() != null) {
            SalesRepAndLocationCodeServiceBody serviceBody = pegaResponse.getServiceBody();
            uiResponse.setServiceBody(serviceBody);
        }
    }

    public static void formatSplitExceededAmountResponse(SplitExceededAmountUIResponse uiResponse,
                                                         SplitExceededAmountPEGAResponse pegaResponse) {
        if (pegaResponse.getServiceHeader() != null)
            uiResponse.setServiceHeader(pegaResponse.getServiceHeader());

        if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
            List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
            uiResponse.setErrors(cartError);
        }

        if (pegaResponse.getServiceBody() != null) {
            SplitExceededAmountServiceBody serviceBody = pegaResponse.getServiceBody();
            uiResponse.setServiceBody(serviceBody);
        }
    }

    public static void formatCancelCaseResponse(CancelCaseUIResponse uiResponse, CancelCasePEGAResponse pegaResponse) {
        if (pegaResponse.getServiceHeader() != null)
            uiResponse.setServiceHeader(pegaResponse.getServiceHeader());

        if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
            List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
            uiResponse.setErrors(cartError);
        }

        if (pegaResponse.getServiceBody() != null) {
            CancelCaseServiceBody serviceBody = pegaResponse.getServiceBody();
            uiResponse.setServiceBody(serviceBody);
        }
    }

    public static void formatActivateLaterResponse(ActivateLaterUIResponse uiResponse,
                                                   ActivateLaterPEGAResponse pegaResponse) {
        if (pegaResponse.getServiceHeader() != null)
            uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
        if (pegaResponse.getServiceBody() != null) {
            ActivateLaterServiceBody serviceBody = pegaResponse.getServiceBody();
            uiResponse.setServiceBody(serviceBody);
        }
        if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
            List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
            uiResponse.setErrors(cartError);
        }
    }

    public static void formatUpdateTransferUpgradeResponse(UpdateTransferUpgradeUIResponse uiResponse,
                                                           UpdateTransferUpgradePEGAResponse pegaResponse) {
        if (pegaResponse.getServiceHeader() != null)
            uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
        if (pegaResponse.getServiceBody() != null) {
            UpdateTransferUpgradeServiceBody serviceBody = pegaResponse.getServiceBody();
            uiResponse.setServiceBody(serviceBody);
        }
        if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
            List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
            uiResponse.setErrors(cartError);
        }
    }


    public static void formatAddNickNameResponse(AddNickNameUIResponse uiResponse,
                                                 AddNickNamePEGAResponse pegaResponse) {
        if (pegaResponse.getServiceHeader() != null)
            uiResponse.setServiceHeader(pegaResponse.getServiceHeader());

        if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
            List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
            uiResponse.setErrors(cartError);
        }

        if (pegaResponse.getServiceBody() != null) {
            AddNickNameServiceBody serviceBody = pegaResponse.getServiceBody();
            uiResponse.setServiceBody(serviceBody);
        }
    }

    public static void formatUpdateChatIdResponse(UpdateChatIdUIResponse uiResponse,
                                                  UpdateChatIdPEGAResponse pegaResponse) {
        if (pegaResponse.getServiceHeader() != null)
            uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
        if (pegaResponse.getServiceBody() != null) {
            UpdateChatIdServiceBody serviceBody = pegaResponse.getServiceBody();
            uiResponse.setServiceBody(serviceBody);
        }
        if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
            List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
            uiResponse.setErrors(cartError);
        }
    }

    public static void formatGetCaseResponseResponse(GetCaseResponse response, GetCasePEGAResponse pegaResponse) {
        if (pegaResponse.getServiceHeader() != null)
            response.setServiceHeader(pegaResponse.getServiceHeader());

        if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
            List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
            response.setErrors(cartError);
        }

        if (pegaResponse.getServiceBody() != null) {
            GetCaseServiceBody serviceBody = pegaResponse.getServiceBody();
            response.setServiceBody(serviceBody);
        }
    }

    public static void formatClearCartResponse(ClearCartUIResponse uiResponse, ClearCartPEGAResponse pegaResponse) {
        if (pegaResponse.getServiceHeader() != null)
            uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
        if (pegaResponse.getServiceBody() != null) {
            ClearCartServiceBody serviceBody = pegaResponse.getServiceBody();
            uiResponse.setServiceBody(serviceBody);
        }
        if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
            List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
            uiResponse.setErrors(cartError);
        }
    }

    public static void formatNgdDeleteCartResponse(DeleteCartUIResponse uiResponse, DeleteCartPegaResponse pegaResponse) {
        if (pegaResponse.getServiceHeader() != null)
            uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
        if (pegaResponse.getServiceBody() != null) {
            DeleteCartServiceBody serviceBody = pegaResponse.getServiceBody();
            uiResponse.setServiceBody(serviceBody);
        }
        if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
            List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
            uiResponse.setErrors(cartError);
        }
    }

    public static void formatUpdateWFMInfoResponse(UpdateWFMInfoUIResponse uiResponse,
                                                   UpdateWFMInfoPEGAResponse pegaResponse) {
        if (pegaResponse.getServiceHeader() != null)
            uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
        if (pegaResponse.getServiceBody() != null) {
            UpdateWFMInfoServiceBody serviceBody = pegaResponse.getServiceBody();
            uiResponse.setServiceBody(serviceBody);
        }
        if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
            List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
            uiResponse.setErrors(cartError);
        }
    }

    public static void formatAccountPinResponse(AccountPinUIResponse uiResponse, AccountPinPEGAResponse pegaResponse) {
        if (pegaResponse.getServiceHeader() != null)
            uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
        if (pegaResponse.getServiceBody() != null) {
            AccountpinServiceBody serviceBody = pegaResponse.getServiceBody();
            if(serviceBody.getServiceResponse() != null && serviceBody.getServiceResponse().getContext() != null){
                AccountPinContext context = serviceBody.getServiceResponse().getContext();
                if(context.getCartInfo() != null)
                    context.getCartInfo().setCartId(null);
                context.setCaseId(null);
            }
            uiResponse.setServiceBody(serviceBody);
        }
        if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
            List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
            uiResponse.setErrors(cartError);
        }
    }

    public static void formatSalesOrderAdjustmentResponse(SalesOrderAdjustmentUIResponse uiResponse,
                                                          SalesOrderAdjustmentPEGAResponse pegaResponse) {
        if (pegaResponse.getServiceHeader() != null)
            uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
        if (pegaResponse.getServiceBody() != null) {
            SalesOrderAdjustmentServiceBody serviceBody = pegaResponse.getServiceBody();
            uiResponse.setServiceBody(serviceBody);
        }
    }

    public static void formatClearAndContinueResponse(ClearAndContinueUIResponse uiResponse,
                                                      ClearAndContinuePegaResponse pegaResponse) {
        if (pegaResponse.getServiceHeader() != null)
            uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
        if (pegaResponse.getServiceBody() != null) {
            ClearAndContinueServiceBody serviceBody = pegaResponse.getServiceBody();
            uiResponse.setServiceBody(serviceBody);
        }
        if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
            List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
            uiResponse.setErrors(cartError);
        }
    }

    public static void formatRemoveLockResponse(RemoveLockUIResponse uiResponse,
                                                RemoveLockPEGAResponse pegaResponse) {
        if (pegaResponse.getServiceHeader() != null)
            uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
        if (pegaResponse.getServiceBody() != null) {
            RemoveLockServiceBody serviceBody = pegaResponse.getServiceBody();
            uiResponse.setServiceBody(serviceBody);
        }
        if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
            List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
            uiResponse.setErrors(cartError);
        }
    }

    public static void formataddPlanAndDeviceResponse(AddPlanAndDeviceUIResponse uiResponse,
                                                      AddPlanAndDevicePEGAResponse pegaResponse) {
        if (pegaResponse.getServiceHeader() != null)
            uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
        if (pegaResponse.getServiceBody() != null) {
            AddPlanAndDeviceServiceBody serviceBody = pegaResponse.getServiceBody();
            uiResponse.setServiceBody(serviceBody);
        }
        if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
            List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
            uiResponse.setErrors(cartError);
        }
    }

    public static void formatMoveDatesResponse(AddMoveDatesUIResponse uiResponse,
                                               AddMoveDatesPegaResponse pegaResponse) {
        if (pegaResponse.getServiceHeader() != null)
            uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
        if (pegaResponse.getServiceBody() != null) {
            AddPlanAndDeviceServiceBody serviceBody = pegaResponse.getServiceBody();
            uiResponse.setServiceBody(serviceBody);
        }
        if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
            List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
            uiResponse.setErrors(cartError);
        }
    }

    public static void formatUpdatePlanResponse(MoversUpdatePlanResponse uiResponse, MoversUpdatePlanPegaResponse pegaResponse) {
        if (pegaResponse.getServiceHeader() != null)
            uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
        if (pegaResponse.getServiceBody() != null) {
            AddPlanAndDeviceServiceBody serviceBody = pegaResponse.getServiceBody();
            uiResponse.setServiceBody(serviceBody);
        }
        if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
            List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
            uiResponse.setErrors(cartError);
        }
    }

    public static void formatManualDiscountResponse(UpdateManualDiscountUIResponse uiResponse, ManualDiscountPEGAResponse pegaResponse) {
        if (pegaResponse.getServiceHeader() != null)
            uiResponse.setServiceHeader(pegaResponse.getServiceHeader());

        if (CollectionUtilities.isNotEmptyOrNull(pegaResponse.getErrors())) {
            List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
            uiResponse.setErrors(cartError);
        }

        if (pegaResponse.getServiceBody() != null) {
            ManualDiscountServiceBody serviceBody = pegaResponse.getServiceBody();
            uiResponse.setServiceBody(serviceBody);
        }
    }

    public static void formatEffectiveDateResponse(UpdateEffectiveDateUIResponse uiResponse, EffectiveDatePEGAResponse pegaResponse) {
        if (pegaResponse.getServiceHeader() != null)
            uiResponse.setServiceHeader(pegaResponse.getServiceHeader());

        if (CollectionUtilities.isNotEmptyOrNull(pegaResponse.getErrors())) {
            List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
            uiResponse.setErrors(cartError);
        }

        if (pegaResponse.getServiceBody() != null) {
            EffectiveDateServiceBody serviceBody = pegaResponse.getServiceBody();
            uiResponse.setServiceBody(serviceBody);
        }
    }

    public static void formataddPlanAndDeviceFromCRMResponse(CrmRetrieveCartUIResponse uiResponse, CrmRetrieveCartPegaResponse pegaResponse) {
        if (pegaResponse.getServiceHeader() != null)
            uiResponse.setServiceHeader(pegaResponse.getServiceHeader());

        if (CollectionUtilities.isNotEmptyOrNull(pegaResponse.getErrors())) {
            List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
            uiResponse.setErrors(cartError);
        }

        if (pegaResponse.getServiceBody() != null) {
            CrmRetrieveCartBody serviceBody = pegaResponse.getServiceBody();
            uiResponse.setServiceBody(serviceBody);
        }


    }

    public static void formatCreateCaseResponse(CreateCaseAndGetCustomerInfoUIResponse uiResponse, CreateCasePEGAResponse pegaResponse, String mtn) {

        GraphqlData data = new GraphqlData();

        if (pegaResponse.getServiceHeader() != null)
            uiResponse.setServiceHeader(pegaResponse.getServiceHeader());

        if (pegaResponse.getServiceBody() != null) {
            CreateCaseServiceBody serviceBody = pegaResponse.getServiceBody();
            if(serviceBody.getServiceResponse() != null && serviceBody.getServiceResponse().getContext() != null){
                CreateCaseContext context = serviceBody.getServiceResponse().getContext();
                CreateCaseCustomerInfo customerInfo = context.getCustomerInfo();
                CreateCaseContextInfo contextInfo = context.getContextInfo();
                context.setCaseId(pegaResponse.getServiceBody().getServiceResponse().getContext().getCaseId());
                if(context.getCustomerInfo() != null) {
                    context.getCustomerInfo().setAccountNumber(pegaResponse.getServiceBody().getServiceResponse().getContext().getCustomerInfo().getAccountNumber());
                    context.getCustomerInfo().setMtn(null);
                    context.setCustomerInfo(customerInfo);
                }

                if (serviceBody.getServiceResponse().getContext().getContextInfo() != null) {
                    //setting line level pending order flag
                    if (contextInfo.getOrderRestrictions() != null) {
                        for(LineLevelChangeEligibility eachLine : pegaResponse.getServiceBody().getServiceResponse().getContext().getContextInfo().getOrderRestrictions().get(0).getLineLevelChangeEligibility()){
                            if (eachLine.getMtn().equalsIgnoreCase(mtn)){
                                contextInfo.setLineLevelPendingOrder(eachLine.getEquipmentUpgradeEligibility().getInEligibility().getLineLevelPendingOrder());
                                break;
                            }
                        }
                    }

                    contextInfo.setCallReason(contextInfo.getCallReason());
                    AvailablePaths availablePath = new AvailablePaths() ;
                    List<AvailablePaths> availablePathsList = new ArrayList<>();
                    CartServiceAvailablePaths serviceAvailablePaths;
                    int size = pegaResponse.getServiceBody().getServiceResponse().getContext().getContextInfo().getCartServiceAvailablePaths().size();
                    for(int i=0; i<size; i++) {
                        serviceAvailablePaths = pegaResponse.getServiceBody().getServiceResponse().getContext().getContextInfo().getCartServiceAvailablePaths().get(i);
                        if(serviceAvailablePaths.getPath()!=null) {
                            availablePath.setPath(serviceAvailablePaths.getPath());
                            availablePathsList.add(availablePath);
                        }
                    }
                    contextInfo.setAvailablePaths(availablePathsList);
                    contextInfo.setProcessStep(pegaResponse.getServiceBody().getServiceResponse().getContext().getContextInfo().getProcessStep());

                    if(contextInfo.getProcessAction()==null)
                        contextInfo.setProcessAction("");
                    else
                        contextInfo.setProcessAction(contextInfo.getProcessAction());
                }
                context.setContextInfo(contextInfo);
                data.setContext(context);
                uiResponse.setData(data);
            }

        }
        if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
            List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
            CartError[] cartErrorArr = new CartError[1];
            cartErrorArr[0] = cartError.get(0);
            uiResponse.setErrors(cartErrorArr);
        }
    }


    public static void formatInitiateValidateDeviceSimResponse(InitiateValidateDeviceSimUIResponse uiResponse, InitiateValidateDeviceSimPEGAResponse pegaResponse) {


        if (pegaResponse.getServiceHeader() != null)
            uiResponse.setServiceHeader(pegaResponse.getServiceHeader());

        if (pegaResponse.getServiceBody() != null) {
            if(pegaResponse.getServiceBody().getServiceResponse() != null && pegaResponse.getServiceBody().getServiceResponse().getContext() != null){
                uiResponse.setServiceBody(pegaResponse.getServiceBody());
            }
        }

        if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
            List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
            uiResponse.setErrors(cartError);
        }

    }

    public static void formatGuestChoiceResponse(GuestChoicePEGAResponse pegaResponse,
                                                 GuestChoiceUIResponse soeResponse) {
        if (pegaResponse.getServiceHeader() != null)
            soeResponse.setServiceHeader(pegaResponse.getServiceHeader());

        if (CollectionUtilities.isNotEmptyOrNull(pegaResponse.getErrors())) {
            List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
            soeResponse.setErrors(cartError);
        }

        if (pegaResponse.getServiceBody() != null) {
            GuestChoiceServiceBody serviceBody = pegaResponse.getServiceBody();
            soeResponse.setServiceBody(serviceBody);
        }
    }

    public static void formatCheckExistingCartPegaResponse(CheckExistingCartPEGAResponse pegaResponse,
                                                           CheckExistingCartUIResponse soeResponse) {
        if (pegaResponse.getServiceHeader() != null)
            soeResponse.setServiceHeader(pegaResponse.getServiceHeader());
        if (CollectionUtilities.isNotEmptyOrNull(pegaResponse.getErrors())) {
            List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
            soeResponse.setErrors(cartError);
        }
        if (pegaResponse.getServiceBody() != null) {
            CheckExistingCartServiceBody serviceBody = pegaResponse.getServiceBody();
            soeResponse.setServiceBody(serviceBody);
        }
    }

    /**
     *
     * @param pegaResponse
     * @param uiResponse
     */
    public static void formatUpdateGiftItemResponse(UpdateGiftItemPEGAResponse pegaResponse,
                                                    UpdateGiftItemUIResponse uiResponse) {
        if (pegaResponse.getServiceHeader() != null)
            uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
        if (pegaResponse.getServiceBody() != null) {
            UpdateGiftItemServiceBody serviceBody = pegaResponse.getServiceBody();
            uiResponse.setServiceBody(serviceBody);
        }
        if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
            List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
            uiResponse.setErrors(cartError);
        }
    }

    public static void formatAccessoryFinancingOffersResponse(AccessoryFinancingOffersUIResponse soeResponse,
                                                              AccessoryFinancingOffersPegaResponse pegaResponse) {
        if (pegaResponse.getServiceHeader() != null)
            soeResponse.setServiceHeader(pegaResponse.getServiceHeader());
        if (pegaResponse.getServiceBody() != null) {
            AFOResponseServiceBody serviceBody = pegaResponse.getServiceBody();
            soeResponse.setServiceBody(serviceBody);
        }
        if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
            List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
            soeResponse.setErrors(cartError);
        }
    }
    /**
     *
     * @param pegaResponse
     * @param soeResponse
     */
    public static void formatUpdateAddressChangeUiResponse(UpdateAddressChangePEGAResponse pegaResponse,
                                                           RPSE911AddressUpdateUIResponse soeResponse) {
        RPSE911AddressData status = new RPSE911AddressData();
        if(pegaResponse!=null && pegaResponse.getServiceBody()!=null && pegaResponse.getServiceBody().getServiceResponse()!=null && pegaResponse.getServiceBody().getServiceResponse().getContext()!=null && pegaResponse.getServiceBody().getServiceResponse().getContext().getAccountUpdates()!=null && pegaResponse.getServiceBody().getServiceResponse().getContext().getAccountUpdates().get(0).getUpdateDetails()!=null && pegaResponse.getServiceBody().getServiceResponse().getContext().getAccountUpdates().get(0).getUpdateDetails().getStatus()!=null)
            status.setStatus(pegaResponse.getServiceBody().getServiceResponse().getContext().getAccountUpdates().get(0).getUpdateDetails().getStatus());
        soeResponse.setData(status);
        if (pegaResponse != null && pegaResponse.getServiceHeader() != null)
            soeResponse.setServiceHeader(pegaResponse.getServiceHeader());

        if (pegaResponse != null && pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
            List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
            soeResponse.setErrors(cartError);
        }

    }

    //VZWYN-17463 changes
    public static void formatAddTrialContactInfoAndAddressPegaResponse(AddTrialContactInfoAndAddressPEGAResponse pegaResponse,
                                                                       AddTrialContactInfoAndAddressUIResponse uiResponse) {
        if (pegaResponse.getServiceHeader() != null)
            uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
        if (pegaResponse.getServiceBody() != null) {
            AddTrialContactInfoAndAddressServiceBody serviceBody = pegaResponse.getServiceBody();
            uiResponse.setServiceBody(serviceBody);
        }
        if (pegaResponse.getErrors() != null && !pegaResponse.getErrors().isEmpty()) {
            List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
            uiResponse.setErrors(cartError);
        }
    }

    public static void formatInitiateCartPegaResponse(CpcFeatureResponse pegaResponse,
                                                      InitiateCartUIResponse uiResponse) {
        if (pegaResponse.getServiceHeader() != null)
            uiResponse.setServiceHeader(pegaResponse.getServiceHeader());
        if (pegaResponse.getServiceBody() != null) {
            ServiceBody serviceBody = pegaResponse.getServiceBody();
            uiResponse.setServiceBody(serviceBody);
        }
        if (pegaResponse.getErrors() != null) {
            List<CartError> cartError = CartUtil.formatErrorResponse(pegaResponse.getErrors());
            uiResponse.setErrors(cartError);
        }
    }


}
