package onevz.soe.cart.bpm.helper;

import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.bpm.service.CartServiceBPMServices;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.removehomephone.*;
import onevz.soe.cart.requests.RemoveHomePhonePegaRequest;
import onevz.soe.cart.responses.RemoveHomePhonePegaResponse;
import onevz.soe.cart.ui.requests.RemoveHomePhoneUIRequest;
import onevz.soe.cart.util.CommonUtil;
import onevz.soe.wsclient.bpm.model.response.Error;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.assertj.core.util.Lists;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class RemoveHomePhoneServiceBpmHelper {


    @Autowired
    private CartServiceBPMServices services;

    @Autowired
    private ObjectMapper mapper;
    
    @Autowired
    private CommonUtil util;

    private static final Logger logger = LoggerFactory.getLogger(RemoveHomePhoneServiceBpmHelper.class);

    /**
     * @param uiRequest
     * @return RemoveHomePhonePegaResponse
     * @throws IOException
     */
    public Mono<RemoveHomePhonePegaResponse> removeHomePhone(RemoveHomePhoneUIRequest uiRequest)
            throws IOException {

        RemoveHomePhonePegaRequest request = formatRemoveHomePhoneRequest(uiRequest);
        logger.info("RemoveHomePhone PEGA Request: {}", mapper.writeValueAsString(request));
        logger.info("RemoveHomePhoneUIRequest UI Request After Session Call: {}", mapper.writeValueAsString(uiRequest));
        Mono<RemoveHomePhonePegaResponse> uiPegaResponse=null;
        try {
            uiPegaResponse = services.removeLine(request);
        } catch (SOEHTTPException e) {
        	logger.error(CartConstants.EXCEPTION_OCCURRED + ": {}", e);
        }
        return uiPegaResponse==null?Mono.just(new RemoveHomePhonePegaResponse()): uiPegaResponse.flatMap(pegaResponse -> {
            logger.info("Pega response for Remove HomePhone : {}", pegaResponse);
            return Mono.just(pegaResponse);
        }).onErrorResume(err -> {
            logger.info("Error while calling Pega for Remove HomePhone : {}", err.getMessage());
            SOEHTTPException exception = (SOEHTTPException) err;
            List<Error> errors = new ArrayList<>();
            RemoveHomePhonePegaResponse  errorResponse= new RemoveHomePhonePegaResponse();
            errors = util.formatError(exception, errors);
            errorResponse.setErrors(errors);
           return Mono.just(errorResponse);
        });
    }


    /**
     * @return ServiceHeader
     */
    public RemoveHomePhoneServiceHeaderPegaReq addServiceHeader(RemoveHomePhoneUIRequest request) {
        RemoveHomePhoneServiceHeaderPegaReq serviceHeader = new RemoveHomePhoneServiceHeaderPegaReq();
        serviceHeader.setClientId(request.getCartInfo().getClientAppName());
        serviceHeader.setStatusMsg("PEGA generated message");
        serviceHeader.setSessionId("");
        serviceHeader.setServiceName(CartConstants.SALES_ORDER_PURCHASE);
        serviceHeader.setUserId("");
        return serviceHeader;
    }

    /**
     * @param request
     * @return RemoveHomePhonePegaRequest
     */
    public RemoveHomePhonePegaRequest formatRemoveHomePhoneRequest(RemoveHomePhoneUIRequest request) {

        RemoveHomePhonePegaReqServiceBody serviceBody = new RemoveHomePhonePegaReqServiceBody();
        RemoveHomePhonePegaReqServiceRequest serviceRequest = new RemoveHomePhonePegaReqServiceRequest();
        RemoveHomePhonePegaReqContext context = new RemoveHomePhonePegaReqContext();
        RemoveHomePhonePegaReqContextInfo pegaContextInfo = getContextInfo(request);

        RemoveHomePhonePegaReqResCustomerInfo customerInfo = getCustomerInfo(request);
        RemoveHomePhonePegaReqCartInfo cartInfo = getCartInfo(request);

        context.setContextInfo(pegaContextInfo);
        context.setCartInfo(cartInfo);
        context.setCustomerInfo(customerInfo);
        context.setCaseId(request.getCartInfo().getCaseId());
        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        RemoveHomePhonePegaRequest pegaRequest = new RemoveHomePhonePegaRequest();
        pegaRequest.setServiceHeader(addServiceHeader(request));
        pegaRequest.setServiceBody(serviceBody);

        return pegaRequest;
    }

    private RemoveHomePhonePegaReqContextInfo getContextInfo(RemoveHomePhoneUIRequest request) {
        RemoveHomePhonePegaReqContextInfo contextInfo = new RemoveHomePhonePegaReqContextInfo();
        contextInfo.setProcessStep(null != request.getCartInfo().getProcessStep() ?
                request.getCartInfo().getProcessStep() : "");
        contextInfo.setProcessAction(null != request.getCartInfo().getProcessAction() ?
                request.getCartInfo().getProcessAction() : "");
        contextInfo.setIntent(null != request.getCartInfo().getIntendType() ?
                request.getCartInfo().getIntendType() : "");
        return contextInfo;
    }

    private RemoveHomePhonePegaReqCartInfo getCartInfo(RemoveHomePhoneUIRequest request) {

        RemoveHomePhonePegaReqCartInfo ci = new RemoveHomePhonePegaReqCartInfo();
        ci.setCartCreator(null != request.getCartInfo().getCartCreator() ? request.getCartInfo().getCartCreator() : "");
        ci.setIntendType(null != request.getCartInfo().getIntendType() ? request.getCartInfo().getIntendType() : "");
        ci.setCartId(null != request.getCartInfo().getCartId() ? request.getCartInfo().getCartId() : "");
        ci.setAction(null != request.getCartInfo().getAction() ? request.getCartInfo().getAction() : "");
        ci.setLines(getLines(request));
        return ci;
    }

    private List<RemoveHomePhonePegaReqLines> getLines(RemoveHomePhoneUIRequest request) {
        RemoveHomePhonePegaReqLines line = new RemoveHomePhonePegaReqLines();
        line.setMtn(request.getCartInfo().getHomePhoneMTN());
        return Lists.newArrayList(line);
    }

    private RemoveHomePhonePegaReqResCustomerInfo getCustomerInfo(RemoveHomePhoneUIRequest request) {
        RemoveHomePhonePegaReqResCustomerInfo cf = new RemoveHomePhonePegaReqResCustomerInfo();
        cf.setAccountNumber(null != request.getCartInfo().getAccountNumber() ? request.getCartInfo().getAccountNumber() : "");
        cf.setCartCreator(null != request.getCartInfo().getCartCreator() ? request.getCartInfo().getCartCreator() : "");
        cf.setProcessingMTN(null != request.getCartInfo().getProcessingMTN() ? request.getCartInfo().getProcessingMTN() : "");
        return cf;
    }
}
