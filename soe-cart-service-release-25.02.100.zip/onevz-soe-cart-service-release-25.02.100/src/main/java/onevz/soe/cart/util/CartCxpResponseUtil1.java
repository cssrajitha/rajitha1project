package onevz.soe.cart.util;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.catalog.PlanCatalogItems;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.deviceSimValidation.DeviceSimValidationUIResponseData;
import onevz.soe.cart.model.initiateValidateDeviceSim.InitiateValidateDeviceSimUIResponse;
import onevz.soe.cart.model.retrieveCart.ServiceInfo;
import onevz.soe.cart.model.retrieveCart.*;
import onevz.soe.cart.model.validateCart.CXPValidateCartDataVO;
import onevz.soe.cart.model.validateCart.CartValidationError;
import onevz.soe.cart.requests.RetrieveCartCXPRequest;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.ui.common.RPSAddressData;
import onevz.soe.cart.ui.requests.DeviceSimValidationUIRequest;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.exception.SOEError;
import onevz.soe.orderprocess.model.checkoutdetails.DiscountsAndPromotions;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.server.reactive.ServerHttpRequest;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class CartCxpResponseUtil1 {
    private static final Logger logger = LoggerFactory.getLogger(CartCxpResponseUtil.class);
    public static final List<String> CDE_PLAN_EQUIP_CODES = Arrays.asList("JPK","USJ","IHP","JTP","CAN");

    @Value("${offerTypes:referafriend,perk}")
    private static List<String> offerTypes;

    private CartCxpResponseUtil1() {
    }

    public static void formatRetrieveCartResponse(RetrieveCartUIResponse soeResponse,
                                                  RetrieveCartCXPResponse retrieveCartResponse, boolean unifiedNbsFlag, boolean bmsmFlag) {
        if (retrieveCartResponse.getWarnings() != null)
            soeResponse.setWarnings(retrieveCartResponse.getWarnings());
        if (retrieveCartResponse.getMeta() != null)
            soeResponse.setMeta(retrieveCartResponse.getMeta());
        if (retrieveCartResponse.getErrors() != null)
            soeResponse.setErrors(retrieveCartResponse.getErrors());
        else {
            if (retrieveCartResponse.getData() != null) {
                soeResponse.setData(retrieveCartResponse.getData());
                //Added to remove cart id to UI request
                soeResponse.getData().setCartId(null);
                if(retrieveCartResponse.getData().getCart()!=null)
                    soeResponse.getData().getCart().setCartId(null);
            }

            Optional.ofNullable(soeResponse).map(RetrieveCartUIResponse::getData).map(CXPRetrieveCartDataVO::getCart)
                    .ifPresent(cartDtls -> {
                        setEMIVerizonPymtDataNew(cartDtls);
                        setPayTodayData(cartDtls.getOrderDetails());
                        setDfoTotalSalesTaxDataNew(cartDtls);

                    });



            Optional.ofNullable(soeResponse).map(RetrieveCartUIResponse::getData).map(CXPRetrieveCartDataVO::getCart)
                    .map(CXPCartVO::getOrderDetails).ifPresent(orderDetails -> {
                if(orderDetails.getTotalDueTodayFlag()!= null && orderDetails.getTotalDueTodayFlag())
                    orderDetails.setTotalDueToday(orderDetails.getRunningTotalDueToday());
                if (orderDetails.getSubAccountInfo() != null && !orderDetails.getSubAccountInfo().isEmpty()) {
                    for (SubAccountInfo subAccountInfo : orderDetails.getSubAccountInfo()) {

                        if (subAccountInfo.getSubAccountType().equalsIgnoreCase("New")) {
                            subAccountInfo.setSubAccountDisplayName(subAccountInfo.getSubAccountId());
                        } else if (subAccountInfo.getSubAccountType().equalsIgnoreCase("EXISTING")
                                && StringUtilities.isNotEmptyOrNull(subAccountInfo.getSubAccountId())) {
                            String[] id = subAccountInfo.getSubAccountId().split("-");
                            if (id.length > 1)
                                subAccountInfo.setSubAccountDisplayName("SubAccount" + " " + id[1]);
                        }
                    }
                }
            });
            Optional.ofNullable(soeResponse).map(RetrieveCartUIResponse::getData).map(CXPRetrieveCartDataVO::getCart)
                    .map(CXPCartVO::getLineDetails).ifPresent(lineDetails -> {
                TradeInDetail tradeInDetail = Optional.ofNullable(lineDetails.getTradeInDetail())
                        .orElse(new TradeInDetail());
                Double totalAppliedPrice = 0.0;
                if (tradeInDetail.getTradeInItems() != null) {
                    for (TradeInItem item : tradeInDetail.getTradeInItems()) {
                        if (StringUtilities.isNotEmptyOrNull(item.getPromoValue())
                                && Double.valueOf(item.getPromoValue()) > 0.0) {
                            totalAppliedPrice = totalAppliedPrice + Double.valueOf(item.getAppliedPrice());
                        }
                    }
                }
                if (totalAppliedPrice > 0.0)
                    tradeInDetail.setTotalAppliedPrice(Double.toString(totalAppliedPrice));
                lineDetails.setTradeInDetail(tradeInDetail);
                if (lineDetails.getLineInfo() != null) {
                    List<CXPLineInfo> newLineInfo = new ArrayList<>();
                    Arrays.stream(lineDetails.getLineInfo()).filter(Objects::nonNull).forEach(lineInfo -> {
                        ServiceInfo serviceInfo = Optional.ofNullable(lineInfo.getServiceInfo())
                                .orElse(new ServiceInfo());
                        // promos with amountOff not equal to zero and awardType DOLLAR or TIERED_DOLLAR
                        List<PlanPromos> planPromosList = new ArrayList<>();

                        if(null != soeResponse.getData().getCart().getCartHeader() && StringUtilities.isNotEmptyOrNull(soeResponse.getData().getCart().getCartHeader().getCaseId()) &&
                                soeResponse.getData().getCart().getCartHeader().getCaseId().startsWith("SOF")) {
                            if (null != serviceInfo.getPlanDetails() && null != serviceInfo.getPlanDetails().getPlanPromotions() && null != serviceInfo.getPlanDetails()
                                    .getPlanPromotions().getPromos()) {
                                serviceInfo.getPlanDetails().getPlanPromotions().getPromos().forEach(p -> {
                                    PlanPromos planPromos = new PlanPromos();
                                    if (StringUtilities.isNotEmptyOrNull(p.getAmountOff()) && !p.getAmountOff().equals(CartConstants.ZERO_DOLLAR_AMOUNT_OFF)
                                            && StringUtilities.isNotEmptyOrNull(p.getType()) && (p.getType().equals(CartConstants.DOLLAR) || p.getType().equals(CartConstants.TIERED_DOLLAR))) {
                                        planPromos.setId(p.getId());
                                        planPromos.setDescription(p.getDescription());
                                        planPromos.setAmountOff(p.getAmountOff());
                                        planPromos.setType(p.getType());
                                        planPromosList.add(planPromos);
                                        serviceInfo.getPlanDetails().getPlanPromotions().setPromos(planPromosList);
                                        logger.info("Promo ID : {}  added with non $0.00 value and type DOLLAR or TIERED_DOLLAR", p.getId());
                                    } else {
                                        logger.info("Promo ID : {} skipping due to $0.00 value or type other than DOLLAR or TIERED_DOLLAR", p.getId());
                                    }
                                });
                            }

                        }

                        PrimaryUserInfo primaryUserInfo = Optional.ofNullable(serviceInfo.getPrimaryUserInfo())
                                .orElse(new PrimaryUserInfo());
                        if (primaryUserInfo.getAddress() != null) {
                            primaryUserInfo.getAddress().setCountryCode("US");
                        }
                        serviceInfo.setPrimaryUserInfo(primaryUserInfo);
                        lineInfo = formatLineInfo(lineInfo, serviceInfo);
                        newLineInfo.add(lineInfo);
                    });
                    CXPLineInfo[] lineArr = new CXPLineInfo[newLineInfo.size()];
                    newLineInfo.toArray(lineArr);
                    lineDetails.setLineInfo(lineArr);
                }
                setPlanPerks(lineDetails.getLineInfo());
                settingLineDetails(lineDetails, bmsmFlag);
                //OBPNBS-842 Populate SOE subAccountNbsInfo from new SOE subAccountNbsDetails response
                logger.info("unifiedNbsFlag : {} ", unifiedNbsFlag);
                if(unifiedNbsFlag) {
                    Optional.ofNullable(lineDetails.getSubAccountNbsDetails()).ifPresent(subAccountNbsDetails -> {
                        List<NbsInfo> subAccountNbsInfoList = getNbsInfos(subAccountNbsDetails);
                        lineDetails.setSubAccountNBSInfo(subAccountNbsInfoList);
                    });
                }
                lineDetails.setSubAccountNbsDetails(new ArrayList<>());

                soeResponse.getData().getCart().setLineDetails(lineDetails);
            });
        }
    }

    public static void settingLineDetails(CXPLineDetailsVO lineDetails, boolean bmsmFlag) {
        if(bmsmFlag && lineDetails.getLineInfo() != null) {
            Arrays.stream(lineDetails.getLineInfo())
                    .filter(Objects::nonNull)
                    .filter(lineInfo -> lineInfo.getItemsInfo() != null)
                    .flatMap(lineInfo -> Arrays.stream(lineInfo.getItemsInfo()))
                    .filter(Objects::nonNull)
                    .filter(itemInfo-> itemInfo.getCartItems() != null && itemInfo.getCartItems().getCartItem() != null)
                    .forEach(itemInfo ->
                            Arrays.stream(itemInfo.getCartItems().getCartItem())
                                    .filter(cartItem-> cartItem.getPromoHubOfferList() != null
                                                        && cartItem.getPromoHubOfferList().getPromoHubOfferList() != null
                                                        && StringUtilities.isNotEmptyOrNull(cartItem.getCartItemType())
                                                        && cartItem.getCartItemType().equalsIgnoreCase(CartConstants.ITEMTYPE_ACCESSORY))
                                    .flatMap(cartItem -> Stream.of(cartItem.getPromoHubOfferList().getPromoHubOfferList()))
                                    .forEach(offer -> settingBmsmBonusFlag(lineDetails, offer))
                    );
        }
    }

    private static void settingBmsmBonusFlag(CXPLineDetailsVO lineDetails, List<PromoHubOffer> offer) {
        boolean matchFound;
        if(offer != null && !offer.isEmpty() && offer.get(0) != null && offer.get(0).getPromoType() != null &&
                offer.get(0).getPromoType().equalsIgnoreCase(CartConstants.ACCESSORY_BONUS_OFFER) &&
                offer.get(0).getEligibleSkuList() != null && !offer.get(0).getEligibleSkuList().isEmpty()) {
            String skuList = offer.get(0).getEligibleSkuList().get(0);

            matchFound = Arrays.stream(lineDetails.getLineInfo())
                    .filter(lineInfo -> lineInfo.getItemsInfo() != null)
                    .flatMap(lineInfo -> Arrays.stream(lineInfo.getItemsInfo()))
                    .filter(itemsInfo -> itemsInfo.getCartItems() != null && itemsInfo.getCartItems().getCartItem() != null)
                    .flatMap(itemsInfo -> Arrays.stream(itemsInfo.getCartItems().getCartItem()))
                    .anyMatch(cartItem -> StringUtilities.isNotEmptyOrNull(cartItem.getCartItemType())
                            && StringUtilities.isNotEmptyOrNull(cartItem.getSorId())
                            && cartItem.getCartItemType().equalsIgnoreCase(CartConstants.ITEMTYPE_ACCESSORY) && skuList != null &&
                            skuList.equalsIgnoreCase(cartItem.getSorId()));

            Arrays.stream(lineDetails.getLineInfo())
                    .filter(lineInfo -> lineInfo.getItemsInfo() != null)
                    .forEach(lineInfos -> {
                        Arrays.stream(lineInfos.getItemsInfo())
                                .filter(itemInfos -> itemInfos.getCartItems() != null && itemInfos.getCartItems().getCartItem() != null)
                                .forEach(itemInfos ->{
                                    Arrays.stream(itemInfos.getCartItems().getCartItem())
                                            .forEach(cartItem -> cartItem.setBmsmBonusSelected(matchFound));
                                });
                    });
        }
    }

    /**
     * Get Unified NbsDetails from SOE and set SOE NbsInfo
     * @param subAccountNbsDetails subAccountNbsDetails soe
     * @return nbsInfo soe
     */
    private static List<NbsInfo> getNbsInfos(List< NbsDetails> subAccountNbsDetails) {
        logger.info("Inside CartCxpResponseUtil1 getNbsInfos method");
        List<NbsInfo> subAccountNbsInfoList = new ArrayList<>();

        if (CollectionUtilities.isNotEmptyOrNull(subAccountNbsDetails) && null != subAccountNbsDetails.get(0)
                && null != subAccountNbsDetails.get(0).getCustomerDetails()) {
            CustomerDetails customer = subAccountNbsDetails.get(0).getCustomerDetails();
            BillSummary billSummary = getBillSummary(customer);

            // SOE Response Objects
            NbsInfo subAccountNbsInfo = new NbsInfo();
            List<BillAccount> billAccountList = new ArrayList<>();
            BillAccount billAccount = new BillAccount();

            if (null != billSummary.getGrandTotal() && null != billSummary.getGrandTotal().getNextMonthCharge()) {
                Nbs nbs = new Nbs();
                MonthlyTotalsInfo monthlyTotalsInfo = new MonthlyTotalsInfo();
                // set estimated next bill
                monthlyTotalsInfo.setNextMonthCharge(billSummary.getGrandTotal().getNextMonthCharge());
                nbs.setMonthlyTotalsInfo(monthlyTotalsInfo);
                billAccount.setNbs(nbs);
            }

            billAccount.setBillSummary(billSummary);

            billAccountList.add(billAccount);

            subAccountNbsInfo.setBillAccounts(billAccountList);
            subAccountNbsInfoList.add(subAccountNbsInfo);
        }
        return subAccountNbsInfoList;
    }

    /**
     * Set SOE Bill Summary using customer from SOE NbsDetails
     * @param customer customer soe
     * @return billSummary soe
     */
    private static BillSummary getBillSummary(CustomerDetails customer) {
        logger.info("Inside CartCxpResponseUtil1 getBillSummary method");
        BillSummary billSummary = new BillSummary();

        if (null != customer.getBillSummary()) {
            NBSAmount surcharges = customer.getBillSummary().getSurcharges();
            NBSAmount taxesAndFees = customer.getBillSummary().getTaxesAndFees();

            // set surcharges and taxesAndFees
            if (null != surcharges && null != surcharges.getOngoingBillAmount()) {
                NBSTotal surchargesTotal = new NBSTotal();
                surchargesTotal.setNewMonthCharge(surcharges.getOngoingBillAmount());
                billSummary.setSurcharges(surchargesTotal);
            }
            if (null != taxesAndFees && null != taxesAndFees.getOngoingBillAmount()) {
                NBSTotal taxesAndFeesTotal = new NBSTotal();
                taxesAndFeesTotal.setNewMonthCharge(taxesAndFees.getOngoingBillAmount());
                billSummary.setTaxesAndFees(taxesAndFeesTotal);
            }

        }
        if (CollectionUtilities.isNotEmptyOrNull(customer.getTabs())) {
            NBSTotal grandTotal = new NBSTotal();
            customer.getTabs().stream().filter(Objects::nonNull).forEach(tab -> {
                //set estimated next bill and estimated new monthly
                if (null != tab.getTotalAmount() && tab.getTabType().equalsIgnoreCase(CartConstants.NEXT_BILL)) {
                    grandTotal.setNextMonthCharge(tab.getTotalAmount());
                } else if (null != tab.getTotalAmount() && tab.getTabType().equalsIgnoreCase(CartConstants.STEADY_STATE)) {
                    grandTotal.setNewMonthCharge(tab.getTotalAmount());
                }
            });
            if ( null !=  grandTotal.getNextMonthCharge() || null != grandTotal.getNewMonthCharge())
                billSummary.setGrandTotal(grandTotal);
        }
        return billSummary;
    }

    public static void formatValidateCartResponse(ValidateCartUIResponse soeResponse,
                                                  ValidateCartCXPResponse validateCartResponse) {
        logger.info("Inside CartCxpResponseUtil1 formatValidateCartResponse method");
        validateCartResponse(soeResponse, validateCartResponse.getMeta(), validateCartResponse.getErrors(),validateCartResponse.getData());
    }

    public static void formatDeviceCategoryResponse(ValidateCartUIResponse soeResponse,
                                                  ValidateCartCXPResponse validateCartResponse) {
        logger.info("Inside CartCxpResponseUtil1 formatDeviceCategoryResponse method");
        validateDeviceCategoryResponse(soeResponse, validateCartResponse.getMeta(), validateCartResponse.getErrors(),validateCartResponse.getData());
    }

    private static void validateDeviceCategoryResponse(ValidateCartUIResponse soeResponse, Map<String, Object> meta, List<CartError> errors, CXPValidateCartDataVO data) {
        if (meta != null)
            soeResponse.setMeta(meta);
        if (errors != null)
            soeResponse.setErrors(errors);
        if (data != null)
            soeResponse.setData(data);
    }

    public static void formatValidateCart5GResponse(ValidateCartUIResponse soeResponse,
                                                    ValidateCartCXPResponse validateCartResponse) {
        logger.info("Inside CartCxpResponseUtil1 formatValidateCart5GResponse method");
        validateCartResponse(soeResponse, validateCartResponse.getMeta(), validateCartResponse.getErrors(),validateCartResponse.getData());
    }

    public static void formatNbsDataResponse(NbsDataCXPResponse cxpResponse,
                                             AddDeviceUIResponse soeResponse) {
        if (cxpResponse.getData() != null && cxpResponse.getData().getNbsSubAccounts() != null
                && cxpResponse.getData().getNbsSubAccounts().get(0) != null
                && cxpResponse.getData().getNbsSubAccounts().get(0).getCustomer()!= null
                && cxpResponse.getData().getNbsSubAccounts().get(0).getCustomer().getBillAccounts() != null) {

            if(soeResponse.getServiceBody() != null
                    && soeResponse.getServiceBody().getServiceResponse().getContext() != null
                    && soeResponse.getServiceBody().getServiceResponse().getContext().getCustomerInfo() != null )
                soeResponse.getServiceBody().getServiceResponse().getContext().getCustomerInfo().setBillAccounts(cxpResponse.getData().getNbsSubAccounts().get(0).getCustomer().getBillAccounts());

            if(soeResponse.getServiceBody() != null
                    && soeResponse.getServiceBody().getServiceResponse().getContext() != null
                    && soeResponse.getServiceBody().getServiceResponse().getContext().getCartInfo() != null ) {

                if(cxpResponse.getData().getNbsSubAccounts().get(0).getCustomer().getBillAccounts().getBillSummary() != null
                        && cxpResponse.getData().getNbsSubAccounts().get(0).getCustomer().getBillAccounts().getBillSummary().getGrandTotal() != null
                        && cxpResponse.getData().getNbsSubAccounts().get(0).getCustomer().getBillAccounts().getBillSummary().getGrandTotal().getNextMonthCharge() != null)
                    soeResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setTotalDueMonthly(Double.parseDouble(cxpResponse.getData().getNbsSubAccounts().get(0).getCustomer().getBillAccounts().getBillSummary().getGrandTotal().getThisMonthCharge()));
            }
        }

        if (cxpResponse.getErrors() != null && !cxpResponse.getErrors().isEmpty()) {
            soeResponse.setErrors(cxpResponse.getErrors());
        }

    }

    public static void formatCheckDfillInventoryResponse(CheckDfillInventoryCXPResponse cxpResponse,
                                                         CheckDfillInventoryUIResponse soeResponse) {
        if (cxpResponse.getData() != null)
            soeResponse.setData(cxpResponse.getData());
        if (cxpResponse.getErrors() != null && !cxpResponse.getErrors().isEmpty())
            soeResponse.setErrors(cxpResponse.getErrors());
        if (cxpResponse.getMeta() != null)
            soeResponse.setMeta(cxpResponse.getMeta());
    }

    public static void formatGetUpgradeReasonCodesResponse(GetUpgradeReasonCodeCXPResponse cxpResponse,
                                                           GetUpgradeReasonCodeUIResponse soeResponse) {
        if (cxpResponse.getData() != null)
            soeResponse.setData(cxpResponse.getData());
        if (cxpResponse.getErrors() != null && !cxpResponse.getErrors().isEmpty())
            soeResponse.setErrors(cxpResponse.getErrors());
        if (cxpResponse.getMeta() != null)
            soeResponse.setMeta(cxpResponse.getMeta());
    }

    public static void formatRetrieveURCForCartResponse(RetrieveURCForCartUIResponse soeResponse,
                                                        RetrieveURCForCartCXPResponse cxpResponse) {

        if (cxpResponse.getErrors() != null)
            soeResponse.setErrors(cxpResponse.getErrors());
        if (cxpResponse.getMeta() != null)
            soeResponse.setMeta(cxpResponse.getMeta());
        if (cxpResponse.getData() != null) {
            soeResponse.setData(cxpResponse.getData());
        }
    }

    public static void formatCalculateMultilineTaxResponse(CalculateMultilineTaxUIResponse soeResponse,
                                                           CalculateMultilineTaxCXPResponse cxpResponse) {

        if (cxpResponse.getErrors() != null)
            soeResponse.setErrors(cxpResponse.getErrors());
        if (cxpResponse.getMeta() != null)
            soeResponse.setMeta(cxpResponse.getMeta());
        if (cxpResponse.getData() != null) {
            soeResponse.setData(cxpResponse.getData());
        }
    }

    public static void formatValidateBYODTool(ValidateBYODToolUIResponse soeResponse,
                                              ValidateBYODToolCXPResponse cxpResponse) {

        if (cxpResponse.getErrors() != null)
            soeResponse.setErrors(cxpResponse.getErrors());
        if (cxpResponse.getMeta() != null)
            soeResponse.setMeta(cxpResponse.getMeta());
        if (cxpResponse.getData() != null) {
            soeResponse.setData(cxpResponse.getData());
        }
    }

    public static void formatESimDetails(ESimDetailsUIResponse soeResponse, ESimDetailsETNIResponse cxpResponse) {

        if (cxpResponse.getStatusMessage() != null)
            soeResponse.setStatusMessage(cxpResponse.getStatusMessage());
        if (cxpResponse.getServiceName() != null)
            soeResponse.setServiceName(cxpResponse.getServiceName());
        if (cxpResponse.getStatusCode() != null)
            soeResponse.setStatusCode(cxpResponse.getStatusCode());
        if (cxpResponse.getErrors() != null && cxpResponse.getErrors().getErrorCode() != 200)
            soeResponse.setErrors(cxpResponse.getErrors());
        if (cxpResponse.getData() != null) {
            soeResponse.setData(cxpResponse.getData());
        }
    }

    public static void formatCustomerNameByMtnResponse(InitiateValidateDeviceSimUIResponse soeResponse,
                                                       CustomerNameByMtnCXPResponse cxpResponse) {

        String greetingName;
        String customerType;
        if (cxpResponse.getErrors() != null)
            soeResponse.setErrors(cxpResponse.getErrors());
        if (cxpResponse.getData() != null){
            if(cxpResponse.getData().getCustomerProfile()!=null && cxpResponse.getData().getCustomerProfile().getCustomerName()!=null && cxpResponse.getData().getCustomerProfile().getCustomerName().getFirstName()!=null) {
                greetingName = cxpResponse.getData().getCustomerProfile().getCustomerName().getFirstName();
                soeResponse.setGreetingName(greetingName);
            }
            //VZWYN-21969 changes
            if(null != cxpResponse.getData().getCustomerProfile() && null != cxpResponse.getData().getCustomerProfile().getCustomerAttributes() && StringUtilities.isNotEmptyOrNull(cxpResponse.getData().getCustomerProfile().getCustomerAttributes().getCustomerType())){
                customerType = cxpResponse.getData().getCustomerProfile().getCustomerAttributes().getCustomerType();
                if(CartConstants.CUST_TYPE_SL.equalsIgnoreCase(customerType)){
                    CartError error = new CartError();
                    List<CartError> errorList = new ArrayList<>();
                    error.setNamespace(CartConstants.SOE_CART_SERVICE);
                    error.setId(CartConstants.SL_CUSTOMER_ERROR_CODE);
                    error.setName(CartConstants.API_ERROR);
                    error.setMessage(CartConstants.SL_CUSTOMER_ERROR);
                    errorList.add(error);
                    soeResponse.setErrors(errorList);
                }
            }
        }
    }

    public static Map<String, String> getDeviceCartObj(RetrieveCartCXPResponse retrieveCartResponse) {
        try {
            if (null != retrieveCartResponse) {
                Map<String, String> cartMap = new HashMap<String, String>();
                String intendType = null;
                Integer deviceCount = 0;
                String hasBlockers = CartConstants.FALSE;
                String cartHasPCD = CartConstants.FALSE;
                if (null != retrieveCartResponse.getData()
                        && checkConditionForcomputeDeviceCount(retrieveCartResponse)) {
                    if (null != retrieveCartResponse.getData().getCart()) {
                        if (null != retrieveCartResponse.getData().getCart().getLineDetails()) {
                            if (null != retrieveCartResponse.getData().getCart().getLineDetails().getLineInfo()) {
                                CXPLineInfo[] lineInfoItem = retrieveCartResponse.getData().getCart().getLineDetails()
                                        .getLineInfo();
                                for (CXPLineInfo lineInfoMem : lineInfoItem) {
                                    if ("EUP".equalsIgnoreCase(lineInfoMem.getLineActivityType())
                                            || "AAL".equalsIgnoreCase(lineInfoMem.getLineActivityType())
                                            || "BYOD".equalsIgnoreCase(lineInfoMem.getLineActivityType())) {
                                        CXPItemInfo cxpItemsInfo = null;
                                        CXPCartItem[] cartItemArray;
                                        if (lineInfoMem.getItemsInfo() != null)
                                            cxpItemsInfo = lineInfoMem.getItemsInfo()[0];

                                        if (null != cxpItemsInfo && cxpItemsInfo.getCartItems() != null
                                                && cxpItemsInfo.getCartItems().getCartItem() != null) {
                                            cartItemArray = cxpItemsInfo.getCartItems().getCartItem();
                                            for (CXPCartItem item : cartItemArray) {

                                                if (StringUtilities.isNotEmptyOrNull(item.getCartItemType())
                                                        && "DEVICE".equalsIgnoreCase(item.getCartItemType())) {
                                                    deviceCount++;
                                                }
                                                if (!cartHasPCD.equalsIgnoreCase("true")
                                                        && null != item.getIsPreconfigureEnabled()
                                                        && item.getIsPreconfigureEnabled()) {
                                                    cartHasPCD = "true";
                                                }

                                            }
                                        }
                                        if (deviceCount == 1) {
                                            intendType = lineInfoMem.getLineActivityType();
                                        }
                                    }
                                }

                                if (deviceCount > 0) {
                                    List<CartValidationError> cartValidationErrorList = retrieveCartResponse.getData()
                                            .getCart().getCartValidationErrors();
                                    if (cartValidationErrorList != null && !cartValidationErrorList.isEmpty()) {
                                        hasBlockers = (cartValidationErrorList.stream().filter(
                                                cartValidationError -> cartValidationError.getErrorLevel() != null
                                                        && cartValidationError.getErrorLevel()
                                                        .equalsIgnoreCase("Blocker"))
                                                .findFirst().isPresent()) ? "true" : CartConstants.FALSE;
                                    }
                                }

                            }
                        }
                    }
                }
                cartMap.put("deviceCount", deviceCount.toString());
                if (StringUtilities.isNotEmptyOrNull(intendType)) {
                    cartMap.put(CartConstants.INTEND_TYPE, intendType);
                }
                cartMap.put("hasBlockers", hasBlockers);
                cartMap.put("cartHasPCD", cartHasPCD);
                return cartMap;

            } else {
                return null;
            }
        } catch (Exception e) {
            return null;
        }
    }

    private static boolean checkConditionForcomputeDeviceCount(RetrieveCartCXPResponse cartResponse) {
        return null != cartResponse.getData().getCart() && null != cartResponse.getData().getCart().getLineDetails()
                && null != cartResponse.getData().getCart().getLineDetails().getLineInfo();
    }

    public static Mono<ValidateCartUIResponse> validateCartEmptyResponse() {
        ValidateCartUIResponse response = new ValidateCartUIResponse();
        CXPValidateCartDataVO data = new CXPValidateCartDataVO();
        CXPCartVO validateCartAndUpdate = new CXPCartVO();
        validateCartAndUpdate.setLineDetails(null);
        data.setValidateCartAndUpdate(validateCartAndUpdate);
        response.setData(data);
        return Mono.just(response);
    }

    public static Map<String, String> getAccessoryCartObj(RetrieveCartCXPResponse retrieveCartResponse) {
        try {
            if (null != retrieveCartResponse) {
                Map<String, String> cartMap = new HashMap<String, String>();
                String intendType = null;
                Integer accessoryCount = 0;
                Integer deviceCount = 0;
                if (null != retrieveCartResponse.getData()) {
                    if (null != retrieveCartResponse.getData().getCart()) {
                        if (null != retrieveCartResponse.getData().getCart().getLineDetails()) {
                            if (null != retrieveCartResponse.getData().getCart().getLineDetails().getLineInfo()) {
                                CXPLineInfo[] lineInfoItem = retrieveCartResponse.getData().getCart().getLineDetails()
                                        .getLineInfo();
                                for (CXPLineInfo lineInfoMem : lineInfoItem) {
                                    CXPItemInfo cxpItemsInfo = null;
                                    CXPCartItem[] cartItemArray;
                                    if (lineInfoMem.getItemsInfo() != null)
                                        cxpItemsInfo = lineInfoMem.getItemsInfo()[0];

                                    if (null != cxpItemsInfo && cxpItemsInfo.getCartItems() != null
                                            && cxpItemsInfo.getCartItems().getCartItem() != null) {
                                        cartItemArray = cxpItemsInfo.getCartItems().getCartItem();
                                        for (CXPCartItem item : cartItemArray) {
                                            if ("ACCESSORY".equalsIgnoreCase(item.getCartItemType()))
                                                accessoryCount += 1;
                                            if ("DEVICE".equalsIgnoreCase(item.getCartItemType()))
                                                deviceCount += 1;
                                        }
                                    }
                                    if (accessoryCount == 1) {
                                        intendType = lineInfoMem.getLineActivityType();
                                    }
                                }
                            }
                        }
                    }
                }
                cartMap.put("accessoryCount", accessoryCount.toString());
                cartMap.put("deviceCount", deviceCount.toString());
                if (StringUtilities.isNotEmptyOrNull(intendType)) {
                    cartMap.put(CartConstants.INTEND_TYPE, intendType);
                }
                return cartMap;

            } else {
                return null;
            }
        } catch (Exception e) {
            return null;
        }

    }

    public static Mono<RetrieveCartUIResponse> retrieveCartEmptyResponse() {

        RetrieveCartUIResponse response = new RetrieveCartUIResponse();
        CXPRetrieveCartDataVO data = new CXPRetrieveCartDataVO();
        CXPCartVO cart = new CXPCartVO();
        cart.setLineDetails(null);
        data.setCart(cart);
        response.setData(data);
        return Mono.just(response);
    }

    public static void formatRetrieveNLinkE911AddressResponse(NLinlk911AddressCXPResponse cxpResponse,
                                                              RPSE911AddressRetrieveUIResponse soeResponse) {
        if (cxpResponse.getErrors() != null && !cxpResponse.getErrors().isEmpty())
            soeResponse.setErrors(cxpResponse.getErrors());
        RPSE911AddressUpdateStatus statusObj = new RPSE911AddressUpdateStatus();
        RPSAddressData rpsAddressData = new RPSAddressData();
        RPSE911AddressData data = new RPSE911AddressData();
        if(cxpResponse.getData()!=null){
            cxpResponse.getData().getE911AddressInfo().stream().findFirst().ifPresent(addressData->{
                statusObj.setMessage(addressData.getStatus());
                data.setMtn(addressData.getMtn());
                data.setStatus(addressData.getStatus());
                rpsAddressData.setAddressLine1(addressData.getAddressLine1());
                rpsAddressData.setAddressLine2(addressData.getAddressLine2());
                rpsAddressData.setApartmentNo(addressData.getApartmentNo());
                rpsAddressData.setStreetNumber(addressData.getStreetNumber());
                rpsAddressData.setStreetName(addressData.getStreetName());
                rpsAddressData.setCity(addressData.getCity());
                rpsAddressData.setCityName(addressData.getCityName());
                rpsAddressData.setState(addressData.getState());
                rpsAddressData.setZipCode(addressData.getZipCode());
                rpsAddressData.setCountryCode(addressData.getCountryCode());
                data.setEp11Address(rpsAddressData);
            });
        }
        soeResponse.setData(data);
        statusObj.setCode("200");
        soeResponse.setStatus(statusObj);
    }

    public static void formatDeviceSimValidationResponse(ServerHttpRequest httpHeader, DeviceSimValidationUIRequest uiRequest, DeviceSimValidationCXPResponse cxpResponse,
                                                         DeviceSimValidationUIResponse soeResponse) {
        DeviceSimValidationUIResponseData soeResponseData = new DeviceSimValidationUIResponseData();
        if (cxpResponse.getData() != null) {
            String flowPath = String.valueOf(httpHeader.getPath());
            if (StringUtilities.isNotEmptyOrNull(flowPath)) {
                if (flowPath.contains("/nse/deviceSimValidation")) {
                    soeResponseData.setFlowType(CartConstants.NSE);
                } else {
                    soeResponseData.setFlowType(CartConstants.EXISTING_CUSTOMER);
                }
            } else {
                soeResponseData.setFlowType("");
            }

            if (StringUtilities.isNotEmptyOrNull(uiRequest.getChannelId())) {
                soeResponseData.setChannelId(uiRequest.getChannelId());
            }
            if (StringUtilities.isNotEmptyOrNull(uiRequest.getTechType())) {
                soeResponseData.setTechType(uiRequest.getTechType());
            }
            if (StringUtilities.isNotEmptyOrNull(uiRequest.getMdn())) {
                soeResponseData.setMdn(uiRequest.getMdn());
            }
            if (uiRequest.getSkipUserAgent() != null) {
                soeResponseData.setSkipUserAgent(uiRequest.getSkipUserAgent());
            }

            if (StringUtilities.isNotEmptyOrNull(uiRequest.getImei())) {
                soeResponseData.setImei(uiRequest.getImei());
                soeResponseData.setIsEsimDevice(false);
            }
            if (StringUtilities.isEmptyOrNull(uiRequest.getImei())) {
                if (StringUtilities.isNotEmptyOrNull(uiRequest.getImei2())) {
                    soeResponseData.setImei2(uiRequest.getImei2());
                    soeResponseData.setIsEsimDevice(true);
                }
            }
            if (StringUtilities.isNotEmptyOrNull(uiRequest.getIccid())) {
                soeResponseData.setIccid(uiRequest.getIccid());
            }
            if (StringUtilities.isNotEmptyOrNull(uiRequest.getBillingId())) {
                soeResponseData.setBillingId(uiRequest.getBillingId());
            }

            if (StringUtilities.isNotEmptyOrNull(uiRequest.getEid())) {
                soeResponseData.setEid(uiRequest.getEid());
                soeResponseData.setIsEsimDevice(true);
            }
            if (cxpResponse.getData().getEsimInfo() != null) {
                if (StringUtilities.isNotEmptyOrNull(cxpResponse.getData().getEsimInfo().getEId())) {
                    soeResponseData.setEid(cxpResponse.getData().getEsimInfo().getEId());
                }
            }
            if (uiRequest.getIsSmartphone() != null) {
                soeResponseData.setIsSmartphone(uiRequest.getIsSmartphone());
            }
            if(cxpResponse!=null && cxpResponse.getData()!=null && cxpResponse.getData().getDeviceInfo()!=null && cxpResponse.getData().getDeviceInfo().getDeviceAttributes()!=null && StringUtilities.isNotEmptyOrNull(cxpResponse.getData().getDeviceInfo().getDeviceAttributes().getDeviceCategory()) && cxpResponse.getData().getDeviceInfo().getDeviceAttributes().getDeviceCategory().toLowerCase().contains(CartConstants.PHONE)) {
                soeResponseData.setIsSmartphone(true);
            } else {
                soeResponseData.setIsSmartphone(false);
            }
            if (StringUtilities.isNotEmptyOrNull(uiRequest.getFirstName())) {
                soeResponseData.setFirstName(uiRequest.getFirstName());
            }

            if (StringUtilities.isNotEmptyOrNull(uiRequest.getLastName())) {
                soeResponseData.setLastName(uiRequest.getLastName());
            }

            if (StringUtilities.isNotEmptyOrNull(uiRequest.getPhoneNumber())) {
                soeResponseData.setPhoneNumber(uiRequest.getPhoneNumber());
            }

            if (StringUtilities.isNotEmptyOrNull(uiRequest.getEmail())) {
                soeResponseData.setEmail(uiRequest.getEmail());
            }

            if (StringUtilities.isNotEmptyOrNull(uiRequest.getZipcode())) {
                soeResponseData.setZipcode(uiRequest.getZipcode());
            }

            if (StringUtilities.isNotEmptyOrNull(uiRequest.getFirstName())
                    || StringUtilities.isNotEmptyOrNull(uiRequest.getLastName())
                    || StringUtilities.isNotEmptyOrNull(uiRequest.getPhoneNumber())
                    || StringUtilities.isNotEmptyOrNull(uiRequest.getZipcode())
                    || StringUtilities.isNotEmptyOrNull(uiRequest.getEmail())) {
                soeResponseData.setIsSDKDevice(true);
            } else {
                soeResponseData.setIsSDKDevice(false);
            }

            if (StringUtilities.isNotEmptyOrNull(uiRequest.getDevid())) {
                soeResponseData.setDevid(uiRequest.getDevid());
            }

            soeResponseData.setIsValidationSuccess(true);
        }
        if (cxpResponse.getErrors() != null && cxpResponse.getErrors().isEmpty()) {
            soeResponse.getMeta().put("Error", cxpResponse.getErrors().toString());
            soeResponseData.setIsValidationSuccess(false);
        }
        if (cxpResponse.getMeta() != null) {

            soeResponse.setMeta(cxpResponse.getMeta());
        }

        soeResponse.setData(soeResponseData);
    }

    public static void formatValidateSecureTokenResponse(ValidateSecureTokenResponse validateSecureTokenResponse,
                                                         DeviceSimValidationUIRequest deviceSimValidationUIRequest) {
        if (validateSecureTokenResponse != null) {
            if(StringUtilities.isNotEmptyOrNull(validateSecureTokenResponse.getChannelId())) {
                deviceSimValidationUIRequest.setChannelId(validateSecureTokenResponse.getChannelId());
            }
            if(StringUtilities.isNotEmptyOrNull(validateSecureTokenResponse.getTechType())) {
                deviceSimValidationUIRequest.setTechType(validateSecureTokenResponse.getTechType());
            }
            if(StringUtilities.isNotEmptyOrNull(validateSecureTokenResponse.getMdn())) {
                deviceSimValidationUIRequest.setMdn(validateSecureTokenResponse.getMdn());
            }
            if(StringUtilities.isNotEmptyOrNull(validateSecureTokenResponse.getIccid())) {
                deviceSimValidationUIRequest.setIccid(validateSecureTokenResponse.getIccid());
            }
            if(StringUtilities.isNotEmptyOrNull(validateSecureTokenResponse.getImei())) {
                deviceSimValidationUIRequest.setImei(validateSecureTokenResponse.getImei());
            }
            if(StringUtilities.isNotEmptyOrNull(validateSecureTokenResponse.getImei2())) {
                deviceSimValidationUIRequest.setImei2(validateSecureTokenResponse.getImei2());
            }
            if(StringUtilities.isNotEmptyOrNull(validateSecureTokenResponse.getBillingId())) {
                deviceSimValidationUIRequest.setBillingId(validateSecureTokenResponse.getBillingId());
            }
            if(validateSecureTokenResponse.getSkipUserAgent()!=null) {
                deviceSimValidationUIRequest.setSkipUserAgent(validateSecureTokenResponse.getSkipUserAgent());
            }
            if(validateSecureTokenResponse.getIsSmartphone()!=null) {
                deviceSimValidationUIRequest.setIsSmartphone(validateSecureTokenResponse.getIsSmartphone());
            }
            if(StringUtilities.isNotEmptyOrNull(validateSecureTokenResponse.getFirstName())) {
                deviceSimValidationUIRequest.setFirstName(validateSecureTokenResponse.getFirstName());
            }
            if(StringUtilities.isNotEmptyOrNull(validateSecureTokenResponse.getLastName())) {
                deviceSimValidationUIRequest.setLastName(validateSecureTokenResponse.getLastName());
            }
            if(StringUtilities.isNotEmptyOrNull(validateSecureTokenResponse.getPhoneNumber())) {
                deviceSimValidationUIRequest.setPhoneNumber(validateSecureTokenResponse.getPhoneNumber());
            }
            if(StringUtilities.isNotEmptyOrNull(validateSecureTokenResponse.getZipcode())) {
                deviceSimValidationUIRequest.setZipcode(validateSecureTokenResponse.getZipcode());
            }
            if(StringUtilities.isNotEmptyOrNull(validateSecureTokenResponse.getEmail())) {
                deviceSimValidationUIRequest.setEmail(validateSecureTokenResponse.getEmail());
            }
            if(StringUtilities.isNotEmptyOrNull(validateSecureTokenResponse.getResponse())) {
                deviceSimValidationUIRequest.setResponse(validateSecureTokenResponse.getResponse());
            }
            if(StringUtilities.isNotEmptyOrNull(validateSecureTokenResponse.getEid())) {
                deviceSimValidationUIRequest.setEid(validateSecureTokenResponse.getEid());
            }
            if(StringUtilities.isNotEmptyOrNull(validateSecureTokenResponse.getDevid())) {
                deviceSimValidationUIRequest.setDevid(validateSecureTokenResponse.getDevid());
            }

        }
    }

    public static void setWarningMessageonCDEPlanchange(CatalogResponse planCatalogRes, RetrieveCartCXPRequest request,
                                                        RetrieveCartUIResponse soeResponse){

        try{
            Set<String> warningMessages=new HashSet<String>();
            for(CXPLineInfo cxpLineinfo: soeResponse.getData().getCart().getLineDetails().getLineInfo()) {
                // plan change happens
                if(cxpLineinfo != null && cxpLineinfo.getServiceInfo() != null && StringUtilities.isNotEmptyOrNull(cxpLineinfo.getServiceInfo().getOldPricePlanId())
                        && StringUtilities.isNotEmptyOrNull(cxpLineinfo.getServiceInfo().getNewPricePlanId())){
                    if(planCatalogRes.getData()!=null && CollectionUtilities.isNotEmptyOrNull(planCatalogRes.getData().getPlanCatalogItems())) {
                        //existingPlan check
                        Optional<PlanCatalogItems> existingCDEPlan = planCatalogRes.getData().getPlanCatalogItems().stream().filter(plancatalogitem -> plancatalogitem.getId() != null
                                && plancatalogitem.getId().equalsIgnoreCase(cxpLineinfo.getServiceInfo().getOldPricePlanId())
                                && isFixedCompanionPlan(plancatalogitem)

                                && isCDEExpansionSTDPlan(plancatalogitem)).findAny();
                        //selectedPlan check
                        Optional<PlanCatalogItems> selectedCDEPlan = planCatalogRes.getData().getPlanCatalogItems().stream().filter(plancatalogitem -> plancatalogitem.getId() != null
                                && plancatalogitem.getId().equalsIgnoreCase(cxpLineinfo.getServiceInfo().getNewPricePlanId())
                                && isVariableCompanionPlan(plancatalogitem)
                                && isCDEExpansionVPCPlan(plancatalogitem)).findAny();

                        //50% banner discount drop if the STD plan to VPC plan changes for jetpack/hotspot devices
                        if(existingCDEPlan.isPresent() && selectedCDEPlan.isPresent() && isFiftyPercentDiscountDrop(cxpLineinfo)) {
                            warningMessages.add("CDE_50_PERCENT_DISCOUNT_DROP");
                        }

                        //existingPlan check
                        Optional<PlanCatalogItems> existingUNLPlan = planCatalogRes.getData().getPlanCatalogItems().stream().filter( plancatalogitem -> plancatalogitem.getId() != null
                                && plancatalogitem.getId().equalsIgnoreCase(cxpLineinfo.getServiceInfo().getOldPricePlanId())
                                && isUnlimitedCatgCode(plancatalogitem)
                                && isCPCollectionCode(plancatalogitem)).findAny();

                        //AutoPay discount drop if the plan changes for jetpack/hotspot devices
                        if(null != request && null != request.getData() && null!=request.getData().getAutopayEnrolled()
                                &&  ("true").equalsIgnoreCase(request.getData().getAutopayEnrolled())
                                &&  existingUNLPlan.isPresent()
                                && (isAutopayDiscountDrop(planCatalogRes,cxpLineinfo.getServiceInfo().getNewPricePlanId())
                                || isAutoPayDiscountFeatureDrop(cxpLineinfo))) {
                            warningMessages.add("CDE_AUTOPAY_DISCOUNT_DROP");
                        }

                    }
                }

            }
            soeResponse.getData().setWarningMessages(warningMessages);
        }catch(Exception e) {
            logger.error(String.format("Exception while setWarningMessageonCDEPlanchange:... %s",e.getMessage()));
        }
    }

    private static boolean isFiftyPercentDiscountDrop(CXPLineInfo cxpLineinfo) {
        if(null != cxpLineinfo.getServiceInfo().getSelectedFeaturesList() &&
                CollectionUtilities.isNotEmptyOrNull(cxpLineinfo.getServiceInfo().getSelectedFeaturesList().getVisFeature())){
            return cxpLineinfo.getServiceInfo().getSelectedFeaturesList().getVisFeature().stream().filter( feature -> feature != null
                    && feature.getVisFeatureCode() != null && feature.getVisFeatureCode().equalsIgnoreCase(CartConstants.FIFTY_PERCENT_DISC_DROP_FEATUE_CODE)
                    && feature.getAddDeleteInd() != null && feature.getAddDeleteInd().equalsIgnoreCase("D")).findAny().isPresent();
        }
        return false;
    }

    private static boolean isAutoPayDiscountFeatureDrop(CXPLineInfo cxpLineinfo) {
        if(null != cxpLineinfo.getServiceInfo().getSelectedFeaturesList() &&
                CollectionUtilities.isNotEmptyOrNull(cxpLineinfo.getServiceInfo().getSelectedFeaturesList().getVisFeature())){
            return cxpLineinfo.getServiceInfo().getSelectedFeaturesList().getVisFeature().stream().filter( feature -> feature != null
                    && feature.getVisFeatureCode() != null && feature.getVisFeatureCode().equalsIgnoreCase(CartConstants.AUTOPAY_DISC_DROP_FEATUE_CODE)
                    && feature.getAddDeleteInd() != null && feature.getAddDeleteInd().equalsIgnoreCase("D")).findAny().isPresent();
        }
        return false;
    }

    /**
     * @param planCatalogRes
     * @param selectedNewPlan
     * @return
     */
    private static boolean isAutopayDiscountDrop(CatalogResponse planCatalogRes, String selectedNewPlan) {
        return planCatalogRes.getData().getPlanCatalogItems().stream().filter(plancatalogitem ->  plancatalogitem.getId()!=null
                && plancatalogitem.getId().equalsIgnoreCase(selectedNewPlan)
                &&  isUnlimitedCatgCode(plancatalogitem)
                &&  isCPCollectionCode(plancatalogitem)
                && 	(isSTDprcProcCatCd(plancatalogitem) || isVPCprcProcCatCd(plancatalogitem) )
                &&  (isCDEExpansionSTDPlan(plancatalogitem) || isCDEExpansionVPCPlan(plancatalogitem))).findAny().isPresent();
    }

    /**
     * @param plancatalogitem
     * @return
     */
    private static boolean isFixedCompanionPlan(PlanCatalogItems plancatalogitem) {
        return isUnlimitedCatgCode(plancatalogitem)	&& isCPCollectionCode(plancatalogitem)	&& isSTDprcProcCatCd(plancatalogitem);
    }

    /**
     * @param plancatalogitem
     * @return
     */
    private static boolean isVariableCompanionPlan(PlanCatalogItems plancatalogitem) {
        return isUnlimitedCatgCode(plancatalogitem)	&& isCPCollectionCode(plancatalogitem)	&& isVPCprcProcCatCd(plancatalogitem);
    }

    /**
     * @param plancatalogitem
     * @return
     */
    private static boolean isCDEExpansionSTDPlan(PlanCatalogItems plancatalogitem) {
        return plancatalogitem.getOffrTypGrpNo()!=null
                && plancatalogitem.getOffrTypGrpNo().equalsIgnoreCase(CartConstants.CDE_STD_PLAN_OFFR_TYPE_GRP_NO);
    }

    private static boolean isCDEExpansionVPCPlan(PlanCatalogItems plancatalogitem) {

        return  plancatalogitem.getIsShowcase() && plancatalogitem.getIsActive() && CollectionUtilities.isNotEmptyOrNull(plancatalogitem.getPlanEquipCode())
                && plancatalogitem.getPlanEquipCode().containsAll(CDE_PLAN_EQUIP_CODES)
                && plancatalogitem.getOffrTypGrpNo()!=null && plancatalogitem.getOffrTypGrpNo().equalsIgnoreCase(CartConstants.CDE_VPC_PLAN_OFFR_TYPE_GRP_NO);
    }

    private static boolean isSTDprcProcCatCd(PlanCatalogItems plancatalogitem) {
        return plancatalogitem.getPrcProcCatCd()!=null && plancatalogitem.getPrcProcCatCd().equalsIgnoreCase("STD");
    }

    private static boolean isVPCprcProcCatCd(PlanCatalogItems plancatalogitem) {
        return plancatalogitem.getPrcProcCatCd()!=null && plancatalogitem.getPrcProcCatCd().equalsIgnoreCase("VPC");
    }

    private static boolean isCPCollectionCode(PlanCatalogItems plancatalogitem) {
        return plancatalogitem.getCollectionCode()!=null && plancatalogitem.getCollectionCode().equalsIgnoreCase("CPUNL");
    }

    private static boolean isUnlimitedCatgCode(PlanCatalogItems plancatalogitem) {
        return plancatalogitem.getCategoryCode()!=null && ( plancatalogitem.getCategoryCode().equalsIgnoreCase("67") || plancatalogitem.getCategoryCode().equalsIgnoreCase("87")
                || plancatalogitem.getCategoryCode().equalsIgnoreCase("88"));
    }

    public static Mono<OrderConfirmationUIResponse> formatOrderConfirmationErrorResponse() {
        OrderConfirmationUIResponse orderConfirmUIresponse = new OrderConfirmationUIResponse();
        CartError cartError = new CartError();
        cartError.setNamespace(CartConstants.SOE_CART_SERVICE);
        cartError.setName(CartConstants.REQUEST_VALIDATION_ERROR);
        cartError.setCode("400");
        cartError.setMessage("CartId missing in request or redis");
        CartError[] cartErrorArr = new CartError[1];
        cartErrorArr[0] = cartError;
        orderConfirmUIresponse.setErrors(cartErrorArr);
        return Mono.just(orderConfirmUIresponse);
    }

    public static Mono<OrderConfirmationUIResponse> formatOrderConfirmationResponse(OrderConfirmationCXPResponse orderConfirmResponse) {
        OrderConfirmationUIResponse soeResponse = new OrderConfirmationUIResponse();
        if (orderConfirmResponse.getWarnings() != null)
            soeResponse.setWarnings(orderConfirmResponse.getWarnings());
        if (orderConfirmResponse.getMeta() != null)
            soeResponse.setMeta(orderConfirmResponse.getMeta());
        if (orderConfirmResponse.getErrors() != null)
            soeResponse.setErrors(orderConfirmResponse.getErrors());
        else {
            if (orderConfirmResponse.getData() != null) {
                soeResponse.setData(orderConfirmResponse.getData());
                //Added to remove cart id to UI request
                soeResponse.getData().setCartId(null);
                if (orderConfirmResponse.getData().getCart() != null)
                    soeResponse.getData().getCart().setCartId(null);
            }
        }
        return Mono.just(soeResponse);
    }

    public static Mono<OrderConfirmationUIResponse> formatOrderConfirmationUIErrorResponse(List<SOEError> errorList) {
        OrderConfirmationUIResponse orderConfirmUIresponse = new OrderConfirmationUIResponse();
        CartError cartError = new CartError();
        cartError.setNamespace(CartConstants.SOE_CART_SERVICE);
        cartError.setName(CartConstants.REQUEST_VALIDATION_ERROR);
        cartError.setCode(CartConstants.EXCEPTION_ERROR_CODE !=null ? CartConstants.EXCEPTION_ERROR_CODE:"500");
        if(errorList !=null && errorList.size()>0){
            errorList.stream().forEach(err -> {
                cartError.setMessage(err.getMessage());
            });
        }
        CartError[] cartErrorArr = new CartError[1];
        cartErrorArr[0] = cartError;
        orderConfirmUIresponse.setErrors(cartErrorArr);
        return Mono.just(orderConfirmUIresponse);
    }

    private static CXPLineInfo formatLineInfo(CXPLineInfo lineInfo, ServiceInfo serviceInfo) {
        lineInfo.setServiceInfo(serviceInfo);
        settingLineInfo(lineInfo);
        return lineInfo;
    }

    private static CXPLineDetailsVO formatLineDetails(Double totalAppliedPrice, TradeInDetail tradeInDetail, CXPLineDetailsVO lineDetails, String tradeInDeviceId) {
        if (totalAppliedPrice > 0.0)
            tradeInDetail.setTotalAppliedPrice(Double.toString(totalAppliedPrice));
        lineDetails.setTradeInDetail(tradeInDetail);

        if (lineDetails.getLineInfo() != null) {
            List<CXPLineInfo> newLineInfo = new ArrayList<>();
            String finalTradeInDeviceId = tradeInDeviceId;
            Arrays.stream(lineDetails.getLineInfo()).filter(Objects::nonNull).forEach(lineInfo -> {
                ServiceInfo serviceInfo = Optional.ofNullable(lineInfo.getServiceInfo())
                        .orElse(new ServiceInfo());
                PrimaryUserInfo primaryUserInfo = Optional.ofNullable(serviceInfo.getPrimaryUserInfo())
                        .orElse(new PrimaryUserInfo());
                if (primaryUserInfo.getAddress() != null) {
                    primaryUserInfo.getAddress().setCountryCode("US");
                }
                String currentDeviceId = "";
                CurrentDevice currentDevice = Optional.ofNullable(serviceInfo.getCurrentDevice())
                        .orElse(new CurrentDevice());
                OldLteVoraEquipInfo oldLteVoraEquipInfo = Optional
                        .ofNullable(currentDevice.getOldLteVoraEquipInfo())
                        .orElse(new OldLteVoraEquipInfo());
                LteVoraDeviceInfo lteVoraDeviceInfo = Optional
                        .ofNullable(oldLteVoraEquipInfo.getLteVoraDeviceInfo())
                        .orElse(new LteVoraDeviceInfo());

                if (StringUtilities.isNotEmptyOrNull(lteVoraDeviceInfo.getDeviceId()))
                    currentDeviceId = lteVoraDeviceInfo.getDeviceId();

                if (StringUtilities.isNotEmptyOrNull(lineInfo.getLineActivityType())
                        && lineInfo.getLineActivityType().equals(CartConstants.EUP)) {
                    if (lineInfo.getByodCapable() != null && lineInfo.getByodCapable()) {
                        if (currentDeviceId.equals(finalTradeInDeviceId)) {
                            lineInfo.setDisplayBYODOffer(false);
                        } else if (lineInfo.getSelectedEUPDeviceForBYOD() != null
                                && lineInfo.getSelectedEUPDeviceForBYOD()) {
                            lineInfo.setDisplayBYODOffer(false);
                        } else {
                            lineInfo.setDisplayBYODOffer(true);
                        }
                    }
                }

                serviceInfo.setPrimaryUserInfo(primaryUserInfo);
                lineInfo = formatLineInfo(lineInfo, serviceInfo);
                newLineInfo.add(lineInfo);
            });
            CXPLineInfo[] lineArr = new CXPLineInfo[newLineInfo.size()];
            newLineInfo.toArray(lineArr);
            lineDetails.setLineInfo(lineArr);
        }
        return lineDetails;
    }

    public static void settingLineInfo(CXPLineInfo lineInfo){
        if (lineInfo.getItemsInfo() != null) {
            Arrays.stream(lineInfo.getItemsInfo()).filter(Objects::nonNull)
                    .forEach(itemsInfo -> {
                        Optional.ofNullable(itemsInfo).map(CXPItemInfo::getCartItems)
                                .ifPresent(cartItems -> {
                                    Arrays.stream(cartItems.getCartItem())
                                            .filter(Objects::nonNull).forEach(cartItem -> {
                                        String replacedStr = "";
                                        if (StringUtilities.isNotEmptyOrNull(
                                                cartItem.getCartItemType())
                                                && StringUtilities.isNotEmptyOrNull(
                                                cartItem.getManufacturer())
                                                && CartConstants.DEVICE
                                                .equalsIgnoreCase(cartItem
                                                        .getCartItemType())
                                                && !Objects.isNull(cartItem
                                                .getNumberShareCapabilityInfo())
                                                && cartItem
                                                .getNumberShareCapabilityInfo()
                                                .getIsNumberShareMandatory()
                                                && "APPLE".equalsIgnoreCase(
                                                cartItem.getManufacturer())
                                                && cartItem.getDescription()
                                                .startsWith("Apple&reg;")) {

                                            replacedStr = cartItem.getDescription()
                                                    .replaceFirst("Apple&reg;", "");
                                            cartItem.setDescription(replacedStr);
                                        }
                                    });
                                });
                    });
        }
    }

    private static void validateCartResponse(ValidateCartUIResponse soeResponse, Map<String, Object> meta, List<CartError> errors, CXPValidateCartDataVO data)  {
        if (meta != null)
            soeResponse.setMeta(meta);
        if (errors != null)
            soeResponse.setErrors(errors);
        else {
            if (data != null)
                soeResponse.setData(data);

            Optional.ofNullable(soeResponse).map(ValidateCartUIResponse::getData).map(CXPValidateCartDataVO::getValidateCartAndUpdate)
                    .map(CXPCartVO::getOrderDetails).ifPresent(orderDetails -> {
                if(CartConstants.Y.equalsIgnoreCase(orderDetails.getIsComboOrder())) {
                    calculateSubTotalMonthlyWithAutoPayDisc(soeResponse.getData().getValidateCartAndUpdate()); }
                if(orderDetails.getTotalDueTodayFlag()!= null && orderDetails.getTotalDueTodayFlag())
                    orderDetails.setTotalDueToday(orderDetails.getRunningTotalDueToday());
            });

            Optional.ofNullable(soeResponse).map(ValidateCartUIResponse::getData)
                    .map(CXPValidateCartDataVO::getValidateCartAndUpdate).map(CXPCartVO::getLineDetails)
                    .ifPresent(lineDetails -> {
                        TradeInDetail tradeInDetail = Optional.ofNullable(lineDetails.getTradeInDetail())
                                .orElse(new TradeInDetail());
                        Double totalAppliedPrice = 0.0;
                        String tradeInDeviceId = "";
                        if (tradeInDetail.getTradeInItems() != null) {
                            for (TradeInItem item : tradeInDetail.getTradeInItems()) {
                                if (StringUtilities.isNotEmptyOrNull(item.getDeviceId()))
                                    tradeInDeviceId = item.getDeviceId();
                                logger.info("About to retrieve promo value from response");
                                if (StringUtilities.isNotEmptyOrNull(item.getPromoValue()) || Double.valueOf(item.getPromoValue()) > 0.0) {
                                    logger.info("Retrieved the promo value from response and about to retrieve applied price from response");
                                    totalAppliedPrice = totalAppliedPrice + Double.valueOf(item.getAppliedPrice());
                                    logger.info("Retrieved the applied price from response");
                                }
                            }
                        }
                        setPlanPerks(lineDetails.getLineInfo());
                        lineDetails = formatLineDetails(totalAppliedPrice, tradeInDetail, lineDetails, tradeInDeviceId);
                        calculateTotalItemMonthlyDiscountedPrice(lineDetails);
                        soeResponse.getData().getValidateCartAndUpdate().setCartHasOnlyAccessories(checkCartHasOnlyAccessories(lineDetails));
                        soeResponse.getData().getValidateCartAndUpdate().setLineDetails(lineDetails);
                    });
        }

    }

    //ACT114-2136 - calculate sub total amount to display in autopay banner by applying autopay discount
    private static void calculateSubTotalMonthlyWithAutoPayDisc(CXPCartVO cart) {

        Optional<Double> subTotalDueMonthlyOpt = Optional.ofNullable(cart.getOrderDetails()).map(CXPOrderDetails::getSubTotalDueMonthly);
        Optional<String> totalAPDiscountOpt = Optional.ofNullable(cart.getLineDetails()).map(CXPLineDetailsVO::getTotalEligibleAutoPayPaperLessDiscount);

        if(subTotalDueMonthlyOpt.isPresent() && totalAPDiscountOpt.isPresent() && StringUtilities.isNotEmptyOrNull(totalAPDiscountOpt.get())){
            cart.getLineDetails().setSubTotalDueMonthlyWithAutoPayDisc(subTotalDueMonthlyOpt.get() - Double.parseDouble(totalAPDiscountOpt.get()));
        }
    }

    //https://onejira.verizon.com/browse/CXTDT-408752
    private static void calculateTotalItemMonthlyDiscountedPrice(CXPLineDetailsVO lineDetails) {
        Optional.ofNullable(lineDetails)
                .filter(l -> Objects.nonNull(l.getLineInfo()))
                .ifPresent(l ->
                        Arrays.stream(l.getLineInfo()).filter(Objects::nonNull).forEach(lineInfo -> {
                            Optional.ofNullable(lineInfo.getServiceInfo())
                                    .filter(s -> CollectionUtilities.isNotEmptyOrNull(s.getSbdOffer()))
                                    .map(ServiceInfo::getSbdOffer)
                                    .ifPresent(so -> {
                                        BigDecimal calculateTotalItemMonthlyDiscountedPrice = so.stream()
                                                .filter(x -> StringUtilities.isNotEmptyOrNull(x.getOfferSubType()))
                                                .filter(x -> CollectionUtilities.isNotEmptyOrNull(offerTypes) && !offerTypes.contains(x.getOfferSubType().toLowerCase()))
                                                .map(SbdOffer::getItemMonthlyDiscount)
                                                .reduce(BigDecimal.ZERO, BigDecimal::add);

                                        lineInfo.setCalculateTotalItemMonthlyDiscountedPrice(calculateTotalItemMonthlyDiscountedPrice);
                                    });


                            Optional.ofNullable(l.getTradeInDetail())
                                    .filter(td -> Objects.nonNull(td.getTradeInItems()))
                                    .ifPresent(td -> {

                                        String multiLineSeqNumberString = Optional.ofNullable(lineInfo.getMultiLineSeqNumber())
                                                .map(Object::toString).orElse("");

                                        td.getTradeInItems().stream()
                                                .map(TradeInItem::getRecycleDeviceOffer)
                                                .filter(Objects::nonNull)
                                                .filter(recycleDeviceOffer -> Objects.nonNull(recycleDeviceOffer.getBuyMldSeqNum()))
                                                .filter(recycleDeviceOffer -> recycleDeviceOffer.getBuyMldSeqNum().equalsIgnoreCase(multiLineSeqNumberString))
                                                .forEach(recycleDeviceOffer -> {
                                                    if(null != lineInfo.getCalculateTotalItemMonthlyDiscountedPrice()) {
                                                        String dppCredit = Optional.ofNullable(recycleDeviceOffer.getDppCredit()).orElse("0");
                                                        lineInfo.setCalculateTotalItemMonthlyDiscountedPrice(lineInfo.getCalculateTotalItemMonthlyDiscountedPrice().add(new BigDecimal(dppCredit)));
                                                    }
                                                    if(null != lineInfo.getInstallmentInfo()){
                                                        recycleDeviceOffer.setPurchaseDeviceDPP(lineInfo.getInstallmentInfo().getFinalDppPrice());
                                                    }
                                                });

                                    });
                            if(null != lineInfo.getCalculateTotalItemMonthlyDiscountedPrice())
                                lineInfo.setTotalItemMonthlyDiscountedPrice(String.valueOf(lineInfo.getCalculateTotalItemMonthlyDiscountedPrice()));
                        })
                );
    }
    /**
     * This method to update PlanPerks
     */
    private static void setPlanPerks(CXPLineInfo[] lineInfo) {
        logger.debug("Inside CartCxpResponseUtil1.setBayouPlanPerks");
        try {
            for (CXPLineInfo line :lineInfo) {
                if (line.getServiceInfo() != null && line.getServiceInfo().getSelectedFeaturesList() != null
                        && CollectionUtilities.isNotEmptyOrNull(line.getServiceInfo().getSelectedFeaturesList().getVisFeature())) {
                    List<PlanPerks> planPerksList = line.getServiceInfo().getSelectedFeaturesList().getVisFeature().stream()
                            .filter(visFeatures -> CartConstants.FLOWS_LIST.contains(visFeatures.getSource()))
                            .filter(visFeatures ->  CollectionUtilities.isNotEmptyOrNull(visFeatures.getCategoryCodes()) && visFeatures.getCategoryCodes().contains(CartConstants.BYOPERK))
                            .filter(visFeatures -> "A".equalsIgnoreCase(visFeatures.getAddDeleteInd()) || "Z".equalsIgnoreCase(visFeatures.getAddDeleteInd()))
                            .map(visFeature -> createPlanPerk(visFeature, line.getServiceInfo().getOtherPromotions()))
                            .sorted(Comparator.comparing(PlanPerks::getRank,Comparator.nullsLast((l1, l2) -> {
                                if (l1 == 0) return 1;
                                if (l2 == 0) return -1;
                                return l1 - l2;
                            })))
                            .collect(Collectors.toList());
                    line.getServiceInfo().setPlanPerks(planPerksList);
                }
            }
        }catch (Exception npe) {
            logger.error("setBayouPlanPerks is null");
        }
    }


    /**
     * This method to create PlanPerks
     */
    private static PlanPerks createPlanPerk(VisFeature bayouVisFeatures, OtherPromotions[] otherPromotions){
        PlanPerks planPerks = new PlanPerks();
        planPerks.setLevel(bayouVisFeatures.getLevel());
        planPerks.setFeatureDesc(bayouVisFeatures.getFeatureDesc());
        planPerks.setType(bayouVisFeatures.getType());
        planPerks.setVisFeatureCode(bayouVisFeatures.getVisFeatureCode());
        planPerks.setFeaturePrice(bayouVisFeatures.getFeaturePrice());
        planPerks.setPerkOriginalPrice(bayouVisFeatures.getPerkOriginalPrice());
        planPerks.setRank(bayouVisFeatures.getRank());

        if (otherPromotions != null && otherPromotions.length > 0) {
            List.of(otherPromotions).stream().forEach(otherPromo -> {
                if (bayouVisFeatures.getVisFeatureCode().equalsIgnoreCase(otherPromo.getElementId())) {
                    DiscountsAndPromotions discountsAndPromotions = new DiscountsAndPromotions();
                    discountsAndPromotions.setFinalPrice(otherPromo.getFinalPrice());
                    discountsAndPromotions.setActualPrice(otherPromo.getActualPrice());
                    discountsAndPromotions.setPromos(otherPromo.getPromos());
                    planPerks.setDiscountsAndPromotions(discountsAndPromotions);
                }
            });
        }
        return planPerks;
    }

    private static boolean checkCartHasOnlyAccessories(CXPLineDetailsVO lineDetails) {
        if (null != lineDetails.getNumOfAccessoryAndDeviceItemsInCart() && lineDetails.getNumOfAccessoryAndDeviceItemsInCart() > 0 && null != lineDetails.getNumofAccessories()) {
            int numOfAccessories = lineDetails.getNumOfAccessoryAndDeviceItemsInCart() - lineDetails.getNumofAccessories();
            return numOfAccessories == 0;
        }
        return false;
    }
	public static void formatEidSimDetails(EidSimDetailsUIResponse soeResponse, SimEidDetailsETNIResponse cxpResponse) {
        if (cxpResponse.getErrors() != null )
            soeResponse.setErrors(cxpResponse.getErrors());
        if (cxpResponse.getData() != null) {
            soeResponse.setData(cxpResponse.getData());
        }
    }


    private static void setEMIVerizonPymtDataNew( CXPCartVO cartDtls) {
        if (null != cartDtls && null != cartDtls.getOrderDetails() && null != cartDtls.getLineDetails()) {

            CXPOrderDetails orderDetails = cartDtls.getOrderDetails();
            CXPLineDetailsVO cxpLineDtls = cartDtls.getLineDetails();

            if (null != orderDetails.getAccessoryFinancingOfferInfo()
                    && null != orderDetails.getAccessoryFinancingOfferInfo().getDfoInstallmentInfo()
                    && null != orderDetails.getAccessoryFinancingOfferInfo().getDfoInstallmentInfo().getInstallmentTerm()) {
                int installmentTerm = Integer.parseInt(orderDetails.getAccessoryFinancingOfferInfo().getDfoInstallmentInfo().getInstallmentTerm());
                AccessoryFinancingInfo accsFinOferInfo =
                        orderDetails.getAccessoryFinancingOfferInfo();
                if (null != accsFinOferInfo.getSplitPaymentInfo()) {
                    accsFinOferInfo.getSplitPaymentInfo().forEach(splitInfo -> {
                        if (null!=splitInfo.getIsDfo() && splitInfo.getIsDfo() && (null != cxpLineDtls.getLineInfo())) {
                            for (CXPLineInfo cxpLineInfo : cxpLineDtls.getLineInfo()) {
                                if (null != splitInfo.getMtn() && null != cxpLineInfo.getMobileNumber() &&
                                        splitInfo.getMtn().equals(cxpLineInfo.getMobileNumber())) {
                                    for (CXPItemInfo cxpItemInfo : cxpLineInfo.getItemsInfo()) {
                                        for (CXPCartItem cxpCartItem : cxpItemInfo.getCartItems().getCartItem()) {
                                            if (CartConstants.DEVICE.equalsIgnoreCase(cxpCartItem.getCartItemType()) &&
                                                    CartConstants.PRICE_TYPE.equalsIgnoreCase(cxpCartItem.getPriceType())) {
                                                cxpCartItem.setIsDfoSelected(true);
                                                String itemPriceString = cxpCartItem.getItemPrice();
                                                String discountString = String.valueOf(cxpCartItem.getDiscountAmount());
                                                BigDecimal itemPrice = new BigDecimal(itemPriceString);
                                                BigDecimal discount = new BigDecimal(discountString);
                                                BigDecimal term = new BigDecimal(installmentTerm);
                                                BigDecimal effectiveItemPrice = itemPrice.subtract(discount);
                                                //effectiveItemPrice = effectiveItemPrice.setScale(2, RoundingMode.HALF_UP);
                                                BigDecimal emiVerizonPayment = effectiveItemPrice.divide(term,2,RoundingMode.FLOOR);
                                                cxpCartItem.setEMIVerizonPayment(String.valueOf(emiVerizonPayment));

                                            }

                                        }

                                    }

                                }
                            }
                        }
                    });
                }
            }

        }

    }

    private static void setPayTodayData(CXPOrderDetails orderDetails) {
        Float payTodayWithoutDfo = 0f;
        if (null != orderDetails && null != orderDetails.getAccessoryFinancingOfferInfo()
                && null != orderDetails.getAccessoryFinancingOfferInfo().getDfoInstallmentInfo()) {
            if (orderDetails.getTotalDueTodayFlag() &&
                    null != orderDetails.getRunningTotalDueToday()
                    && null != orderDetails.getAccessoryFinancingOfferInfo().getDfoInstallmentInfo().getDfoDevicesTotal()
                    && orderDetails.getRunningTotalDueToday() > orderDetails.getAccessoryFinancingOfferInfo().getDfoInstallmentInfo().getDfoDevicesTotal()) {
                payTodayWithoutDfo = (float) (orderDetails.getRunningTotalDueToday() - orderDetails.getAccessoryFinancingOfferInfo().getDfoInstallmentInfo().getDfoDevicesTotal());
            } else if (null != orderDetails.getTotalDueToday()
                    && null != orderDetails.getAccessoryFinancingOfferInfo().getDfoInstallmentInfo().getDfoDevicesTotal()
                    && orderDetails.getTotalDueToday() > orderDetails.getAccessoryFinancingOfferInfo().getDfoInstallmentInfo().getDfoDevicesTotal()) {
                payTodayWithoutDfo = (float) (orderDetails.getTotalDueToday() - orderDetails.getAccessoryFinancingOfferInfo().getDfoInstallmentInfo().getDfoDevicesTotal());
            }
            orderDetails.setPayTodayWithoutDfo(payTodayWithoutDfo);

        }

    }


    private static void setDfoTotalSalesTaxDataNew(CXPCartVO cartDtls) {

        if (null != cartDtls && null != cartDtls.getOrderDetails() && null != cartDtls.getLineDetails()) {
            CXPOrderDetails orderDetails = cartDtls.getOrderDetails();
            CXPLineDetailsVO cxpLineDtls = cartDtls.getLineDetails();
            double totalSalesTaxAmt = 0;
            if (null != orderDetails.getAccessoryFinancingOfferInfo()) {
                AccessoryFinancingInfo accsFinOferInfo =
                        orderDetails.getAccessoryFinancingOfferInfo();
                if (null != accsFinOferInfo.getSplitPaymentInfo()) {

                    for (SplitPaymentInfoDFO splitInfo : accsFinOferInfo.getSplitPaymentInfo()) {

                        if (null!=splitInfo.getIsDfo() && splitInfo.getIsDfo() && (null != cxpLineDtls.getLineInfo())) {
                            for (CXPLineInfo cxpLineInfo : cxpLineDtls.getLineInfo()) {
                                if (null != splitInfo.getMtn() && null != cxpLineInfo.getMobileNumber() &&
                                        splitInfo.getMtn().equals(cxpLineInfo.getMobileNumber())) {
                                    for (CXPItemInfo cxpItemInfo : cxpLineInfo.getItemsInfo()) {
                                        for (CXPCartItem cxpCartItem : cxpItemInfo.getCartItems().getCartItem()) {
                                            if (CartConstants.DEVICE.equalsIgnoreCase(cxpCartItem.getCartItemType()) &&
                                                    CartConstants.PRICE_TYPE.equalsIgnoreCase(cxpCartItem.getPriceType())) {
                                                totalSalesTaxAmt += cxpCartItem.getTaxAmount();

                                            }

                                        }

                                    }

                                }
                            }
                        }
                    }

                }
                if(null!=accsFinOferInfo.getDfoInstallmentInfo()){
                    orderDetails.getAccessoryFinancingOfferInfo().getDfoInstallmentInfo().setDfoTotalSalesTax(totalSalesTaxAmt);
                }

            }

        }

    }


}
