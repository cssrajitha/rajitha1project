package onevz.soe.cart.util;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.retrieveCart.ServiceInfo;
import onevz.soe.cart.model.retrieveCart.*;
import onevz.soe.cart.model.validateCart.CXPValidateCartDataVO;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.DownPaymentUIRequest;
import onevz.soe.cart.ui.responses.ValidateCartUIResponse;
import onevz.soe.channels.SOEChannels;
import onevz.soe.exception.SOEError;
import onevz.soe.exception.SOEErrorHolder;
import onevz.soe.security.exception.SOESecurityException;
import onevz.soe.security.model.SsoJwtDTO;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.bpm.model.response.Detail;
import onevz.soe.wsclient.bpm.model.response.Error;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseCookie;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

@Service
public class CartUtil {
	private static final Logger logger = LoggerFactory.getLogger(CartUtil.class);
	/**
	 * 
	 * @param cart
	 * @return cart
	 */
	public static CXPCartVO updateGrantorDetails(CXPCartVO cart) {
		if (null != cart.getLineDetails() && null != cart.getLineDetails().getLineInfo()
				&& cart.getLineDetails().getLineInfo().length > 0) {
			CXPLineInfo[] lineInfoArray = cart.getLineDetails().getLineInfo();
			for (CXPLineInfo lineInfo : lineInfoArray) {
				LinePairingInfo pairingInfo = lineInfo.getServiceInfo().getPairingInfo();
				if (null != lineInfo.getServiceInfo() && null != lineInfo.getServiceInfo().getPairingInfo()
						&& StringUtilities
								.isNotEmptyOrNull(lineInfo.getServiceInfo().getPairingInfo().getGrantorLineItem())) {

					String grantorMtn = pairingInfo.getGrantorLineItem();
					for (CXPLineInfo loopLineInfo : cart.getLineDetails().getLineInfo()) {
						if (StringUtilities.isNotEmptyOrNull(loopLineInfo.getMobileNumber())
								&& grantorMtn.equalsIgnoreCase(loopLineInfo.getMobileNumber())) {
							if(null != loopLineInfo.getItemsInfo() && loopLineInfo.getItemsInfo().length > 0) {
								for (CXPItemInfo itemsInfo : loopLineInfo.getItemsInfo()) {
									if (null != itemsInfo.getCartItems() && null != itemsInfo.getCartItems().getCartItem()
											&& itemsInfo.getCartItems().getCartItem().length > 0) {
										for (CXPCartItem cartItem : itemsInfo.getCartItems().getCartItem()) {
											if (StringUtilities.isNotEmptyOrNull(loopLineInfo.getLineActivityType())
													&& (CartConstants.EUP
															.equalsIgnoreCase(loopLineInfo.getLineActivityType())
															|| CartConstants.AAL
																	.equalsIgnoreCase(loopLineInfo.getLineActivityType()))
													&& StringUtilities.isNotEmptyOrNull(cartItem.getCartItemType())
													&& "DEVICE".equalsIgnoreCase(cartItem.getCartItemType())
													&& StringUtilities.isNotEmptyOrNull(cartItem.getDescription())) {
												pairingInfo.setGrantorDevice(cartItem.getDescription());
											} else {
												if (null != loopLineInfo.getServiceInfo()
														&& null != loopLineInfo.getServiceInfo().getCurrentDevice()) {
													CurrentDevice currentDevice = loopLineInfo.getServiceInfo()
															.getCurrentDevice();
													if (null != currentDevice.getOldLteVoraEquipInfo()
															&& null != currentDevice.getOldLteVoraEquipInfo()
																	.getLteVoraDeviceInfo()) {
														LteVoraDeviceInfo lteVoraDeviceInfo = currentDevice
																.getOldLteVoraEquipInfo().getLteVoraDeviceInfo();
														if (StringUtilities
																.isNotEmptyOrNull(lteVoraDeviceInfo.getDescription())) {
															pairingInfo
																	.setGrantorDevice(lteVoraDeviceInfo.getDescription());
														}
													}
												}
											}
										}
									}
								}
							}
							if (null != loopLineInfo.getServiceInfo()) {
								ServiceInfo serviceInfo = loopLineInfo.getServiceInfo();
								if (null != serviceInfo.getPricePlanInfo() && StringUtilities
										.isNotEmptyOrNull(serviceInfo.getPricePlanInfo().getPricePlanDesc())) {
									pairingInfo.setGrantorPlan(serviceInfo.getPricePlanInfo().getPricePlanDesc());
								} else if (null != serviceInfo.getNewPricePlanInfo() && StringUtilities
										.isNotEmptyOrNull(serviceInfo.getNewPricePlanInfo().getPricePlanDesc())) {
									pairingInfo.setGrantorPlan(serviceInfo.getNewPricePlanInfo().getPricePlanDesc());
								} else if (null != serviceInfo.getSelectedALPShareList()) {
									SelectedALPShareList shareList = serviceInfo.getSelectedALPShareList();
									if (null != shareList.getAlpShareInfo() && shareList.getAlpShareInfo().length > 0
											&& StringUtilities.isNotEmptyOrNull(
													shareList.getAlpShareInfo()[0].getServicePlanDesc())) {
										pairingInfo.setGrantorPlan(shareList.getAlpShareInfo()[0].getServicePlanDesc());
									} else if (null != shareList.getNewAlpShareInfo()
											&& shareList.getNewAlpShareInfo().length > 0
											&& StringUtilities.isNotEmptyOrNull(
													shareList.getNewAlpShareInfo()[0].getServicePlanDesc())) {
										pairingInfo
												.setGrantorPlan(shareList.getNewAlpShareInfo()[0].getServicePlanDesc());
									}
								}
							}
						}
					}
				}
				lineInfo.getServiceInfo().setPairingInfo(pairingInfo);
			}
			cart.getLineDetails().setLineInfo(lineInfoArray);
		}

		return cart;
	}

	public static CXPCartVO updateShippingCost(CXPCartVO cart) {
		if (null != cart.getLineDetails() && null != cart.getLineDetails().getLineInfo()
				&& cart.getLineDetails().getLineInfo().length > 0) {
			Double totalShippingCost = 0.0;
			Double totalDiscountedShippingCost = 0.0;
			for (CXPLineInfo loopLineInfo : cart.getLineDetails().getLineInfo()) {
				if (loopLineInfo.getItemsInfo() != null && loopLineInfo.getItemsInfo().length > 0) {
					for (CXPItemInfo itemsInfo : loopLineInfo.getItemsInfo()) {
						if (null != itemsInfo.getCartItems() && null != itemsInfo.getCartItems().getCartItem()
								&& itemsInfo.getCartItems().getCartItem().length > 0) {
							for (CXPCartItem cartItem : itemsInfo.getCartItems().getCartItem()) {
								if ("SHIPPING".equalsIgnoreCase(cartItem.getCartItemType())) {
									if (StringUtilities.isNotEmptyOrNull(cartItem.getItemPrice()))
										totalShippingCost += Double.valueOf(cartItem.getItemPrice());
									if (cartItem.getDiscountedPrice() != null)
										totalDiscountedShippingCost += cartItem.getDiscountedPrice();
								}
							}
						}
					}
				}
			}
			cart.getOrderDetails().setTotalShippingCost(totalShippingCost);
			cart.getOrderDetails().setTotalDiscountedShippingCost(totalDiscountedShippingCost);
		}
		return cart;
	}
	
	public static CXPCartVO removeUpgFee(CXPCartVO cart) {

		if (null != cart.getLineDetails() && null != cart.getLineDetails().getLineInfo()
				&& cart.getLineDetails().getLineInfo().length > 0) {
			for (CXPLineInfo loopLineInfo : cart.getLineDetails().getLineInfo()) {
				if (loopLineInfo.getItemsInfo() != null && loopLineInfo.getItemsInfo().length > 0) {
					for (CXPItemInfo itemsInfo : loopLineInfo.getItemsInfo()) {
						if (null != itemsInfo.getCartItems() && null != itemsInfo.getCartItems().getCartItem()
								&& itemsInfo.getCartItems().getCartItem().length > 0) {

							CXPCartItem[] cartItems = itemsInfo.getCartItems().getCartItem();
							List<CXPCartItem> itemList = new ArrayList<CXPCartItem>();

							itemList = Arrays.stream(cartItems).collect(Collectors.toList());
							itemList.removeIf(item -> CartConstants.UPG_FEE.equalsIgnoreCase(item.getSorId()));
							CXPCartItem[] cartItem = new CXPCartItem[itemList.size()];
							itemsInfo.getCartItems().setCartItem(itemList.toArray(cartItem));
						}
					}
				}
			}
		}
		return cart;
	}
	private static boolean isConflict(VisFeature featureInfo) {
		boolean isConflict=false;

		if("SPO".equals(featureInfo.getType())){
			if("A".equalsIgnoreCase(featureInfo.getLevel()) && "USER".equalsIgnoreCase(featureInfo.getSource())){
				isConflict=true;
			}else if("FOM".equalsIgnoreCase(featureInfo.getSource()) && (!"Z".equalsIgnoreCase(featureInfo.getAddDeleteInd()))){
				isConflict=true;
			}
		}else if("SFO".equals(featureInfo.getType())){
			if("EQ".equalsIgnoreCase(featureInfo.getSfopackageGroupCode())  && (!"Z".equalsIgnoreCase(featureInfo.getAddDeleteInd()))){
				isConflict=true;
			} else if("FOM".equalsIgnoreCase(featureInfo.getSource()) && (!"Z".equalsIgnoreCase(featureInfo.getAddDeleteInd()))
					&& (StringUtilities.isNotEmptyOrNull(featureInfo.getFeaturePrice()) && StringUtilities.safeParsingDouble(featureInfo.getFeaturePrice(), 0.0) > 0)){
				isConflict=true;
			}
		}
		return isConflict;
	}
	public static CXPCartVO updateConflicts(CXPCartVO cart) {

		Optional.ofNullable(cart.getLineDetails()).map(CXPLineDetailsVO::getLineInfo).ifPresent(lineInfo ->
				Arrays.stream(lineInfo).forEach(cartLines -> {
					Optional.ofNullable(cartLines.getServiceInfo().getSelectedFeaturesList()).map(SelectedFeaturesList::getVisFeature)
							.ifPresent(features -> {
								features.stream().forEach(feature ->{
									if(isConflict(feature)){
									cart.setCartHasConflicts(true);
									}
								});
							});
				}));
		return cart;
	}
	
	public static CXPCartVO updateInstallmentInfo(CXPCartVO cart) {

			if (null != cart.getLineDetails() && null != cart.getLineDetails().getLineInfo()
					&& cart.getLineDetails().getLineInfo().length > 0) {
				
				for (CXPLineInfo loopLineInfo : cart.getLineDetails().getLineInfo()) {
					if (loopLineInfo.getInstallmentInfo() != null ) {
						InstallmentInfo installmentInfo = loopLineInfo.getInstallmentInfo();
						if (StringUtilities.isNotEmptyOrNull( installmentInfo.getDownPayment() ) ) {
							if(null !=installmentInfo.getVerizonDollarsDownpayment()){
							installmentInfo.setDownPayment(String.valueOf(Double.parseDouble(installmentInfo.getDownPayment( ))+ 
									installmentInfo.getVerizonDollarsDownpayment())); }
							if(null != installmentInfo.getDeviceDollarDownpayment()){
								installmentInfo.setDownPayment(String.valueOf( Double.parseDouble(installmentInfo.getDownPayment()) + 
									installmentInfo.getDeviceDollarDownpayment()));
							}
						}
					}
											
				
				
			}
			}
			return cart;
		}


	public static CXPCartVO sumOfLocalTaxes(CXPCartVO cart) {
		if (null != cart.getLineDetails() && null != cart.getLineDetails().getLineInfo()
				&& cart.getLineDetails().getLineInfo().length > 0) {
			for (CXPLineInfo loopLineInfo : cart.getLineDetails().getLineInfo()) {
				if (loopLineInfo.getItemsInfo() != null && loopLineInfo.getItemsInfo().length > 0) {
					for (CXPItemInfo itemsInfo : loopLineInfo.getItemsInfo()) {
						if (null != itemsInfo.getCartItems() && null != itemsInfo.getCartItems().getCartItem()
								&& itemsInfo.getCartItems().getCartItem().length > 0) {

							for (CXPCartItem cartItem : itemsInfo.getCartItems().getCartItem()) {
								if (null != cartItem.getTaxDetailsList() && cartItem.getTaxDetailsList().length > 0) {
									ArrayList<TaxDetailsList> taxArr = new ArrayList<TaxDetailsList>();
									TaxDetailsList newTaxDetailsList = new TaxDetailsList();
									Double sumOfLocalTax = 0.0, sumOfLocalTax_S = 0.0;
									Integer taxSequenceNum = 0, taxSequenceNum_S = 0;
									String taxPassType = "", taxPassType_S = "";
									String taxDescription = "", taxDescription_S = "";
									String taxType = "", taxType_S = "";
									Integer mldSequenceNum = 0, mldSequenceNum_S = 0;
									String delimiter = "", delimiter_S = "";
									String taxSurcharge = "", taxSurcharge_S = "",tax ="";
									Boolean containsLocalTaxes = false;
									for (TaxDetailsList taxDetailsList : cartItem.getTaxDetailsList()) {
										if (taxDetailsList.getTaxDescription() != null && taxDetailsList
												.getTaxDescription().toLowerCase().contains("Local".toLowerCase())) {
												tax = "";
												if(taxDetailsList.getTaxSurcharge() != null) 
													tax = taxDetailsList.getTaxSurcharge();
												if(tax.equalsIgnoreCase("T") || tax.isEmpty()) {
													containsLocalTaxes = true;
													sumOfLocalTax += Double.valueOf(taxDetailsList.getTaxAmount());
													taxDescription = taxDetailsList.getTaxDescription();
													taxType = String.join(delimiter, taxType, taxDetailsList.getTaxType());
													taxPassType = String.join(delimiter, taxDetailsList.getTaxPassType(),
															taxPassType);
													mldSequenceNum = Integer.parseInt(String.valueOf(mldSequenceNum)
															+ String.valueOf(taxDetailsList.getMldSequenceNum()));
													taxSequenceNum = Integer.parseInt(String.valueOf(taxSequenceNum)
															+ String.valueOf(taxDetailsList.getTaxSequenceNum()));
													taxSurcharge = tax;
													if(taxSurcharge.isEmpty())
														taxSurcharge = "T";
													delimiter = "_";
													
												}
												else if(tax.equalsIgnoreCase("S")){
													containsLocalTaxes = true;
													sumOfLocalTax_S += Double.valueOf(taxDetailsList.getTaxAmount());
													taxDescription_S = taxDetailsList.getTaxDescription();
													taxType_S = String.join(delimiter_S, taxType_S, taxDetailsList.getTaxType());
													taxPassType_S = String.join(delimiter_S, taxDetailsList.getTaxPassType(),
															taxPassType_S);
													mldSequenceNum_S = Integer.parseInt(String.valueOf(mldSequenceNum_S)
															+ String.valueOf(taxDetailsList.getMldSequenceNum()));
													taxSequenceNum_S = Integer.parseInt(String.valueOf(taxSequenceNum_S)
															+ String.valueOf(taxDetailsList.getTaxSequenceNum()));
													taxSurcharge_S = tax;
													delimiter_S = "_";
												}

											taxDetailsList = null;

										}
										if (taxDetailsList != null)
											taxArr.add(taxDetailsList);
									}
									DecimalFormat decimalFormat = new DecimalFormat("0.00");
									if(!taxSurcharge.isEmpty()) {
										newTaxDetailsList.setTaxAmount(decimalFormat.format(sumOfLocalTax).toString());
										newTaxDetailsList.setTaxDescription(taxDescription);
										newTaxDetailsList.setTaxType(taxType);
										newTaxDetailsList.setTaxPassType(taxPassType);
										newTaxDetailsList.setMldSequenceNum(mldSequenceNum);
										newTaxDetailsList.setTaxSequenceNum(taxSequenceNum);
										newTaxDetailsList.setTaxSurcharge(taxSurcharge);
										taxArr.add(newTaxDetailsList);
									}
									if(!taxSurcharge_S.isEmpty()) {
										newTaxDetailsList = new TaxDetailsList();
										newTaxDetailsList.setTaxAmount(decimalFormat.format(sumOfLocalTax_S).toString());
										newTaxDetailsList.setTaxDescription(taxDescription_S);
										newTaxDetailsList.setTaxType(taxType_S);
										newTaxDetailsList.setTaxPassType(taxPassType_S);
										newTaxDetailsList.setMldSequenceNum(mldSequenceNum_S);
										newTaxDetailsList.setTaxSequenceNum(taxSequenceNum_S);
										newTaxDetailsList.setTaxSurcharge(taxSurcharge_S);
										taxArr.add(newTaxDetailsList);
									}
									if (containsLocalTaxes) {
										TaxDetailsList[] taxDetailsList1 = new TaxDetailsList[taxArr.size()];
										cartItem.setTaxDetailsList(taxArr.toArray(taxDetailsList1));
									}

								}
							}
						}
					}
				}
			}
		}
		return cart;
	}
	
	/**
	 * 
	 * @param channelId
	 * @return channelType
	 */
	public static String getChannelType(String channelId) {
		if (channelId != null && SOEChannels.findByChannelName(channelId) != null) {
			return SOEChannels.findByChannelName(channelId).getChannelType();
		}
		return "";
	}
	
	public static CXPCartVO calculateMemberCount(CXPCartVO cart, List<String> mtnList, String vzwRoles) {
		if (CollectionUtilities.isEmptyOrNull(mtnList) || StringUtilities.isEmptyOrNull(mtnList.get(0)))
			return cart;
		boolean isFlowTypeDvmConversion =  (null != cart.getOrderDetails() && CartConstants.DVM_CONVERSION_FLOWTYPE.equalsIgnoreCase(cart.getOrderDetails().getFlowType()));
		if ((null != vzwRoles && (!vzwRoles.equalsIgnoreCase(CartConstants.ACCOUNT_MEMBER)
				&& !vzwRoles.equalsIgnoreCase(CartConstants.MOBILE_SECURE))) || isFlowTypeDvmConversion)
			return cart;
		else if (null != cart && null != cart.getLineDetails() && null != cart.getLineDetails().getLineInfo()) {
			CXPLineInfo[] lines = cart.getLineDetails().getLineInfo();
			AtomicInteger totalAALLines = new AtomicInteger(0);
			AtomicInteger totalEUPLines = new AtomicInteger(0);
			AtomicInteger totalACCLines = new AtomicInteger(0);
			AtomicInteger totalItemCount = new AtomicInteger();
			AtomicReference<Double> totalTaxAmountMembers = new AtomicReference<Double>(java.lang.Double.valueOf(0.0));
			Arrays.stream(lines).filter(Objects::nonNull).forEach(line -> {
				logger.info("Inside count method : lines");
				if (StringUtilities.isNotEmptyOrNull(line.getLineCreator())
						&& CollectionUtilities.isNotEmptyOrNull(mtnList)
						&& line.getLineCreator().equalsIgnoreCase(mtnList.get(0))) {
					logger.info("starting count for lines");
					switch (line.getLineActivityType()) {
					case CartConstants.AAL: {
						totalAALLines.getAndIncrement();
						Arrays.stream(line.getItemsInfo()).filter(Objects::nonNull).forEach(itemsInfo -> {
							// Adding up lineLevelTax of all lines in cart
							Arrays.stream(itemsInfo.getCartItems().getCartItem()).filter(Objects::nonNull)
									.forEach(cartItem -> {
										if (StringUtilities.isNotEmptyOrNull(cartItem.getCartItemType())
												&& (CartConstants.DEVICE.equalsIgnoreCase(cartItem.getCartItemType())
														|| CartConstants.ACCESSORY
																.equalsIgnoreCase(cartItem.getCartItemType())
														|| CartConstants.UPGRADE_FEE
																.equalsIgnoreCase(cartItem.getCartItemType())))
											totalTaxAmountMembers.compareAndSet(totalTaxAmountMembers.get(),
													totalTaxAmountMembers.get() + (cartItem.getTaxAmount() !=null ? cartItem.getTaxAmount() : 0.0));
									});
						});
						break;
					}
					case CartConstants.EUP: {
						totalEUPLines.getAndIncrement();
						Arrays.stream(line.getItemsInfo()).filter(Objects::nonNull).forEach(itemsInfo -> {
							// Adding up lineLevelTax of all lines in cart
							Arrays.stream(itemsInfo.getCartItems().getCartItem()).filter(Objects::nonNull)
									.forEach(cartItem -> {
										if (StringUtilities.isNotEmptyOrNull(cartItem.getCartItemType())
												&& (CartConstants.DEVICE.equalsIgnoreCase(cartItem.getCartItemType())
														|| CartConstants.ACCESSORY
																.equalsIgnoreCase(cartItem.getCartItemType())
														|| CartConstants.UPGRADE_FEE
																.equalsIgnoreCase(cartItem.getCartItemType())))
											totalTaxAmountMembers.compareAndSet(totalTaxAmountMembers.get(),
													totalTaxAmountMembers.get() + (cartItem.getTaxAmount() !=null ? cartItem.getTaxAmount() : 0.0));
									});
						});
						break;
					}
					case CartConstants.ACC: {
						totalACCLines.getAndIncrement();
						Arrays.stream(line.getItemsInfo()).filter(Objects::nonNull).forEach(itemsInfo -> {
							// Adding up lineLevelTax of all lines in cart
							Arrays.stream(itemsInfo.getCartItems().getCartItem()).filter(Objects::nonNull)
									.forEach(cartItem -> {
										if (StringUtilities.isNotEmptyOrNull(cartItem.getCartItemType())
												&& (CartConstants.DEVICE.equalsIgnoreCase(cartItem.getCartItemType())
														|| CartConstants.ACCESSORY
																.equalsIgnoreCase(cartItem.getCartItemType())
														|| CartConstants.UPGRADE_FEE
																.equalsIgnoreCase(cartItem.getCartItemType())))
											totalTaxAmountMembers.compareAndSet(totalTaxAmountMembers.get(),
													totalTaxAmountMembers.get() + (cartItem.getTaxAmount() !=null ? cartItem.getTaxAmount() : 0.0));
									});
						});
						break;
					}
					}
					Arrays.stream(line.getItemsInfo()).filter(Objects::nonNull).forEach(item -> {
						totalItemCount.getAndAdd(item.getItemCount());
						logger.info("Calculating ItemCount for AAL or ACC: {}", totalItemCount.intValue());
					});

				} else if (StringUtilities.isNotEmptyOrNull(line.getLineActivityType())
						&& CartConstants.EUP.equalsIgnoreCase(line.getLineActivityType())
						&& StringUtilities.isNotEmptyOrNull(line.getLineCreator())
						&& CollectionUtilities.isNotEmptyOrNull(mtnList)
						&& !line.getLineCreator().equalsIgnoreCase(mtnList.get(0))
						&& StringUtilities.isNotEmptyOrNull(line.getMobileNumber())
						&& mtnList.get(0).equalsIgnoreCase(line.getMobileNumber())) {

					totalEUPLines.getAndIncrement();
					Arrays.stream(line.getItemsInfo()).filter(Objects::nonNull).forEach(itemsInfo -> {
						// Adding up lineLevelTax of all lines in cart
						Arrays.stream(itemsInfo.getCartItems().getCartItem()).filter(Objects::nonNull)
								.forEach(cartItem -> {
									if (StringUtilities.isNotEmptyOrNull(cartItem.getCartItemType())
											&& (CartConstants.DEVICE.equalsIgnoreCase(cartItem.getCartItemType())
													|| CartConstants.ACCESSORY
															.equalsIgnoreCase(cartItem.getCartItemType())
													|| CartConstants.UPGRADE_FEE
															.equalsIgnoreCase(cartItem.getCartItemType())))
										totalTaxAmountMembers.compareAndSet(totalTaxAmountMembers.get(),
												totalTaxAmountMembers.get() + (cartItem.getTaxAmount() !=null ? cartItem.getTaxAmount() : 0.0));
								});
					});
					Arrays.stream(line.getItemsInfo()).filter(Objects::nonNull).forEach(item -> {
						totalItemCount.getAndAdd(item.getItemCount());
						logger.info("Calculating ItemCount for EUP: {}", totalItemCount.intValue());
					});
				} 
				if (totalItemCount.intValue() != 0)
					cart.getLineDetails().setNumOfAccessoryAndDeviceItemsInCart(totalItemCount.intValue());
				else if (totalAALLines.intValue() == 0 && totalACCLines.intValue() == 0
						&& totalEUPLines.intValue() == 0)
					cart.getLineDetails().setNumOfAccessoryAndDeviceItemsInCart(0);
				cart.getLineDetails().setNumofLinesAAL(totalAALLines.intValue());
				cart.getLineDetails().setNumofLinesEUP(totalEUPLines.intValue());
				cart.getLineDetails().setNumOfLines(
						cart.getLineDetails().getNumofLinesEUP() + totalAALLines.intValue() + totalACCLines.intValue());
				logger.info("totalAALLines : {}, totalEUPLines: {}, totalACCLines: {}, totalLines: {}", totalAALLines,
						totalEUPLines, totalACCLines, cart.getLineDetails().getNumOfLines());
				cart.getOrderDetails().setMemberTotalTaxAmount(totalTaxAmountMembers.get().toString());
				logger.info("Setting tax amount: {}", cart.getOrderDetails().getMemberTotalTaxAmount());
			});
		}
		return cart;
	}

	public static Mono<ValidateCartUIResponse> validateCartEmptyResponse() {
		logger.info("cartId empty in request & Redis: Sending Empty Response.");
		ValidateCartUIResponse validateResponse = new ValidateCartUIResponse();
		CXPValidateCartDataVO cartData = new CXPValidateCartDataVO();
		CXPCartVO validateCartAndUpdate = new CXPCartVO();
		validateCartAndUpdate.setLineDetails(null);
		cartData.setValidateCartAndUpdate(validateCartAndUpdate);
		validateResponse.setData(cartData);
		return Mono.just(validateResponse);
	}

	/**
	 * 
	 * @param channelId
	 * @return channelType
	 */
	public static String getChannel(String channelId) {

		if (channelId != null && SOEChannels.findByChannelName(channelId) != null) {
			return SOEChannels.findByChannelName(channelId).getChannelType();
		}
		return null;
	}
	
	/**
	 * 
	 * @param depletionLocationCode
	 * @param channelId
	 * @return result
	 */
	public static String removeSpecialCharacters(String depletionLocationCode, String channelId) {
		String result = depletionLocationCode;
		if(CartConstants.ASSISTED.equalsIgnoreCase(getChannelType(channelId)))	
			result = depletionLocationCode.replaceAll("[-+.^:,]","");
		
		return result;
	}

	public static boolean isDigital(String channelId) {
		return CartConstants.DIGITAL.equalsIgnoreCase(CartUtil.getChannelType(channelId));
	}

	public static boolean isAssisted(String channelId) {
		return CartConstants.ASSISTED.equalsIgnoreCase(CartUtil.getChannelType(channelId));
	}

	public static String getPageReferer(String referer) {
		String pagereferer = referer;
		if (referer.contains(".html")) {
			pagereferer = StringUtils.substringBefore(referer, ".html");
		} else if (referer.contains("/?")) {
			pagereferer = StringUtils.substringBefore(referer, "/?");
		} else {
			pagereferer = StringUtils.substringBefore(referer, "/]");
		}
		pagereferer = StringUtils.substringAfterLast(pagereferer, "/");
		return pagereferer;
	}


	/**
	 * 
	 * @param cart
	 * @return CXPCartVO
	 */
	public static CXPCartVO isAssignMtnRequired(CXPCartVO cart) {
		Boolean isAssignMtnRequired = Boolean.FALSE;
		List<Integer> unassignedMtnLineSeqList = new ArrayList<>();
		if (null != cart.getLineDetails() && null != cart.getLineDetails().getLineInfo()
				&& cart.getLineDetails().getLineInfo().length > 0) {
			for (CXPLineInfo loopLineInfo : cart.getLineDetails().getLineInfo()) {
				if(StringUtilities.isNotEmptyOrNull(loopLineInfo.getMobileNumber()) && loopLineInfo.getMobileNumber().toLowerCase().contains("newline")) {
					isAssignMtnRequired = true;
					unassignedMtnLineSeqList.add(loopLineInfo.getMultiLineSeqNumber());
				}
			}
		}
		if(isAssignMtnRequired) {
			cart.getOrderDetails().setIsAssignMtnRequired(isAssignMtnRequired);
			cart.getOrderDetails().setUnassignedMtnLineSeqList(unassignedMtnLineSeqList);
			
		} else {
			cart.getOrderDetails().setIsAssignMtnRequired(isAssignMtnRequired);
		}
		return cart;
	}

	public static SOESecurityException handleInvalidSession(String channelID) {
		logger.info("No cart found with the sales session.");
		SOEError errors = new SOEError();
		int errorId=CartConstants.ERROR_ID_INT;
		if (isDigitalChannel(channelID)) {
			errors = SOEError.builder().debug_id("").namespace(CartConstants.SOE_SERVICE_NAME)
					.name(CartConstants.ERROR_NAME).id(CartConstants.ERROR_ID)
					.information_link(CartConstants.INFORMATION_LINK).message("Cart Id is required").build();
			errorId=CartConstants.SUCCESS_ID_INT;
		} else {
			errors = SOEError.builder().debug_id("").namespace(CartConstants.SOE_SERVICE_NAME)
					.name(CartConstants.ERROR_NAME).id(CartConstants.ERROR_ID).information_link("")
					.message("Cart Id is required").build();
		}
		List<SOEError> soeErrorsList = new ArrayList<>();
		soeErrorsList.add(errors);
		SOEErrorHolder errorHolder = new SOEErrorHolder(soeErrorsList);
		SOESecurityException exceptionObject = new SOESecurityException(errorId,
				errorHolder);
		return exceptionObject;
	}

	private static boolean isDigitalChannel(String channelId) {
		boolean isDigitalChannel = Boolean.FALSE;
		if (SOEChannels.findByChannelName(channelId) != null
				&& "Digital".equalsIgnoreCase(SOEChannels.findByChannelName(channelId).getChannelType()))
			isDigitalChannel = Boolean.TRUE;
		return isDigitalChannel;
	}
	
	
	public static CXPCartVO updatePrepayOrderDetails(CXPCartVO cart) {
		logger.info("Inside updatePrepayOrderDetails method : lines");
		String isPrePayCart = "N";
		List<UserMembers> accountMemberList = new ArrayList<>();
		UserMembers accountOwner=new UserMembers();
		 populateAccountOwnerInfo(cart, accountOwner);
		if(null!=cart.getOrderDetails().getPostPayToNewPreMtns().getAccountMembers() && null!=cart.getOrderDetails().getIsPrePayCart() && 
				"Y".equalsIgnoreCase(cart.getOrderDetails().getIsPrePayCart()) && !cart.getOrderDetails().getPostPayToNewPreMtns().getAccountMembers().isEmpty())
		{
		for (UserMembers accountMemberInfo : cart.getOrderDetails().getPostPayToNewPreMtns().getAccountMembers()) {
			if (null!=accountMemberInfo && StringUtilities.isNotEmptyOrNull(accountMemberInfo.getMtn())) {
				isPrePayCart = "Y";
				accountMemberList.add(accountMemberInfo);
			}
		}
		}
		else
		{
			logger.info("Inside updatePrepayOrderDetails method with isPrepayCart as N");
		}
		if ("Y".equalsIgnoreCase(isPrePayCart)) {
			cart.getOrderDetails().setIsPrePayCart(isPrePayCart);
			cart.getOrderDetails().getPostPayToNewPreMtns().setAccountMembers(accountMemberList);
		} 
		else {
			cart.getOrderDetails().setIsPrePayCart(isPrePayCart);
		}
		return cart;
	}
	
	
	
	private static void populateAccountOwnerInfo(CXPCartVO cart, UserMembers accountOwner) {
		if (null != cart.getOrderDetails() && null!=cart.getOrderDetails().getIsPrePayCart() && 
				"Y".equalsIgnoreCase(cart.getOrderDetails().getIsPrePayCart()) && null != cart.getOrderDetails().getPostPayToNewPreMtns()
				&& null!=cart.getOrderDetails().getPostPayToNewPreMtns().getAccountOwner()) 
		{
			logger.info("Inside populateAccountOwnerInfo method : with isPrepayCart as {}",cart.getOrderDetails().getIsPrePayCart());
			accountOwner.setMtn(StringUtilities.isNotEmptyOrNull(cart.getOrderDetails().getPostPayToNewPreMtns().getAccountOwner().getMtn()) ? cart.getOrderDetails().getPostPayToNewPreMtns().getAccountOwner().getMtn():"");
			accountOwner.setDevice(null!=cart.getOrderDetails().getPostPayToNewPreMtns().getAccountOwner().getDevice() ? cart.getOrderDetails().getPostPayToNewPreMtns().getAccountOwner().getDevice():new PrepayDevice());
			accountOwner.setSim(null!=cart.getOrderDetails().getPostPayToNewPreMtns().getAccountOwner().getSim() ? cart.getOrderDetails().getPostPayToNewPreMtns().getAccountOwner().getSim():new PrepaySim());
			cart.getOrderDetails().getPostPayToNewPreMtns().setAccountOwner(accountOwner);
		}
		else
		{
			logger.info("Inside populateAccountOwnerInfo method : with isPrepayCart as N updating isPrepayCart OrderDetails as N");
			cart.getOrderDetails().setPostPayToNewPreMtns(new PostPayToNewPreMtns());
			cart.getOrderDetails().setIsPrePayCart("N");
		}
	}

	public static List<CartError> formatErrorResponse(List<Error> errors) {
		return errors.stream().map(error -> {
			CartError cartError1 = new CartError();
			cartError1.setMessage(error.getMessage());
			if (error.getId() != null)
				cartError1.setId(error.getId());
			cartError1.setDebug_id(error.getDebug_id());
			cartError1.setName(error.getName());
			if (error.getDetails() != null) {
				CartErrorDetail errorDetail = new CartErrorDetail();
				List<CartErrorDetail> cartErrorDetails = new ArrayList<>();
				for (Detail detail : error.getDetails()) {
					errorDetail.setField(detail.getField());
					errorDetail.setIssue(detail.getIssue());
					errorDetail.setLocation(detail.getLocation());
					errorDetail.setValue(detail.getValue());
					errorDetail.setLockedChannelID(detail.getLockedChannelID());
					cartErrorDetails.add(errorDetail);
				}
				cartError1.setDetailList(cartErrorDetails);
			}
			return cartError1;
		}).collect(Collectors.toList());
	}

	public static boolean hasCustomerSwitchedfromREXToPurchase(CartRedisData data, String  channelId, String requestIntendType,
															  List<String> existingCustomerFlows){

		if(null != SOEChannels.findByChannelName(channelId)){
			return SOEChannels.findByChannelName(channelId).getChannelType().
					equalsIgnoreCase(CartConstants.CHANNEL_DIGITAL) &&
					data.getIntendType() != null &&
					CartConstants.REX.contains(data.getIntendType()) &&
					existingCustomerFlows.contains(requestIntendType);
		}
		return false;
	}

	public static boolean hasProspectCustomerChangedLoggedIn(CartRedisData data, String  channelId, String intendType,
															 List<String> prospectFlows, List<String> existingCustomerFlows){

		if(null != SOEChannels.findByChannelName(channelId)){
			return SOEChannels.findByChannelName(channelId).getChannelType().
					equalsIgnoreCase(CartConstants.CHANNEL_DIGITAL) &&
					data.getIntendType() != null &&
					prospectFlows.contains(data.getIntendType()) &&
					existingCustomerFlows.contains(intendType);
		}
		return false;
	}
	public static boolean isFlexV2(String URI){
		if(URI != null)
			return URI.contains("flexV2") ? true : false;
		return false;
	}

	public static void isCartContainsOnlyAccessories(CXPCartVO validateCartAndUpdate) {
		logger.info("start isCartContainsOnlyAccessories()");
		List<CXPCartItem> deviceCartItems = new ArrayList<>();
		List<CXPCartItem> accessoryCartItems = new ArrayList<>();

		if(validateCartAndUpdate.getLineDetails() != null &&
				validateCartAndUpdate.getLineDetails().getLineInfo() != null) {
			Arrays.asList(validateCartAndUpdate.getLineDetails().getLineInfo()).stream().filter(cartLineInfo -> ArrayUtils.isNotEmpty(cartLineInfo.getItemsInfo())).
					forEach(lineInfo -> Arrays.asList(lineInfo.getItemsInfo()).stream().forEach(itemsInfo -> {
								if(itemsInfo.getCartItems() != null && ArrayUtils.isNotEmpty(itemsInfo.getCartItems().getCartItem())) {
									Arrays.asList(itemsInfo.getCartItems().getCartItem()).stream().forEach(cartItem -> {
										if ("DEVICE".equalsIgnoreCase(cartItem.getCartItemType())) {
											deviceCartItems.add(cartItem);
										} else if ("ACCESSORY".equalsIgnoreCase(cartItem.getCartItemType())) {
											accessoryCartItems.add(cartItem);
										}
									});
								}
							}
					));
			if(deviceCartItems.isEmpty() && accessoryCartItems.size() > 0){
				validateCartAndUpdate.getLineDetails().setStandaloneAccessory(true);
			}else {
				validateCartAndUpdate.getLineDetails().setStandaloneAccessory(false);
			}
			logger.info("vhdeviceLineItems {}, vhaccessoryLineItems {}",deviceCartItems.isEmpty(), accessoryCartItems.size() );
		}
		logger.info("start isCartContainsOnlyAccessories()");
	}

	public static String getValueFromHeaders(HttpHeaders headers, String key) {
		if (headers != null && headers.getFirst(key) != null)
			return headers.getFirst(key);
		return "";
	}

	public static ErrorData formatErrorDataResponse(ErrorData data) {
		ErrorData errorData = new ErrorData();
		List<LinesInfo> linesInfoList = new ArrayList<>();
		if(StringUtilities.isNotEmptyOrNull(data.getStatusCode())){
			errorData.setStatusCode(data.getStatusCode());
		}
		if(data.getLines() !=null && !data.getLines().isEmpty()){
			for(LinesInfo lineData :  data.getLines()){
				LinesInfo linesInfo = new LinesInfo();
				if("E".equalsIgnoreCase(lineData.getAnySpoOrSfoChangeIndicator())){
					linesInfo.setAnySpoOrSfoChangeIndicator(lineData.getAnySpoOrSfoChangeIndicator());
					if(StringUtilities.isNotEmptyOrNull(lineData.getMtn())){
						linesInfo.setMtn(lineData.getMtn());
					}
					if(StringUtilities.isNotEmptyOrNull(lineData.getPlanValidationFailed())){
						linesInfo.setPlanValidationFailed(lineData.getPlanValidationFailed());
					}
					if(lineData.getFomSfoActivity() != null){
						FomSFOActivity fomSfoActivity = new FomSFOActivity();
						if(StringUtilities.isNotEmptyOrNull(lineData.getFomSfoActivity().getFomActionSFO1())){
							fomSfoActivity.setFomActionSFO1(lineData.getFomSfoActivity().getFomActionSFO1());
						}
						if(StringUtilities.isNotEmptyOrNull(lineData.getFomSfoActivity().getFomActionSFO2())){
							fomSfoActivity.setFomActionSFO2(lineData.getFomSfoActivity().getFomActionSFO2());
						}
						if(StringUtilities.isNotEmptyOrNull(lineData.getFomSfoActivity().getFomActionSFO1Desc())){
							fomSfoActivity.setFomActionSFO1Desc(lineData.getFomSfoActivity().getFomActionSFO1Desc());
						}
						if(StringUtilities.isNotEmptyOrNull(lineData.getFomSfoActivity().getFomActionFeature1())){
							fomSfoActivity.setFomActionFeature1(lineData.getFomSfoActivity().getFomActionFeature1());
						}
						if(StringUtilities.isNotEmptyOrNull(lineData.getFomSfoActivity().getFomActionReasonCode())){
							fomSfoActivity.setFomActionReasonCode(lineData.getFomSfoActivity().getFomActionReasonCode());
						}
						if(StringUtilities.isNotEmptyOrNull(lineData.getFomSfoActivity().getFomReasonCodeDescription())){
							fomSfoActivity.setFomReasonCodeDescription(lineData.getFomSfoActivity().getFomReasonCodeDescription());
						}
						linesInfo.setFomSfoActivity(fomSfoActivity);
					}
					linesInfoList.add(linesInfo);
				}
			}
			errorData.setLines(linesInfoList);
		}
		return errorData;
	}

	public static List<CartError> formatCartErrorResponse(List<CartError> errors) {
		return errors.stream().map(error -> {
			CartError cartError1 = new CartError();
			cartError1.setMessage(error.getMessage());
			if (error.getId() != null)
				cartError1.setId(error.getId());
			cartError1.setDebug_id(error.getDebug_id());
			cartError1.setName(error.getName());
			if (error.getDetailList() != null) {
				CartErrorDetail errorDetail = new CartErrorDetail();
				List<CartErrorDetail> cartErrorDetails = new ArrayList<>();
				for (CartErrorDetail detail : error.getDetailList()) {
					errorDetail.setField(detail.getField());
					errorDetail.setIssue(detail.getIssue());
					errorDetail.setLocation(detail.getLocation());
					errorDetail.setValue(detail.getValue());
					errorDetail.setLockedChannelID(detail.getLockedChannelID());
					cartErrorDetails.add(errorDetail);
				}
				cartError1.setDetailList(cartErrorDetails);
			}
			return cartError1;
		}).collect(Collectors.toList());
	}

	public static boolean isByodFlow(String flow) {
		return CartConstants.NSE_BYOD.equalsIgnoreCase(flow) || CartConstants.BYOD.equalsIgnoreCase(flow);
	}

	public static String generateExpireDate(String dateFormat,long plusNoOfDays) {
		String expireDate = null;
		try {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern(dateFormat);
			LocalDateTime now = LocalDateTime.now().plusDays(plusNoOfDays);
			expireDate = formatter.format(now);
			logger.info("generateExpireDate in MVA: {}", expireDate);
		} catch (Exception e) {
			logger.error("Exception while generateExpireDate ");
		}
		return expireDate;
	}

	public Mono<Boolean> validateAccessUser(SsoJwtDTO ssoJwtDTO, String channelId) {
		if(isDigitalChannel(channelId)) {
			if(CartConstants.VZT.equalsIgnoreCase(ssoJwtDTO.getLob())) {
				SOESecurityException vztUserAccessError = prepareErrorResponse(
						CartConstants.CART_VZTUSER_MESSAGE,
						200, CartConstants.VZTUSER_ERROR,
						CartConstants.VZTUSER_ERROR_CODE, CartConstants.ERROR_CATEGORY_BUSINESSERR);
				return Mono.error(vztUserAccessError);
			}
		}

		return Mono.just(Boolean.TRUE);
	}

	public static SOESecurityException prepareErrorResponse(String errorMessage, Integer statusCode,String errorName,String errorId,String errorCategory) {
		SOEError errors = SOEError.builder().debug_id("").namespace(CartConstants.SOE_SERVICE_NAME).name(errorName).errorCategory(errorCategory)
				.id(errorId).message(errorMessage).build();
		List<SOEError> soeErrorsList=new ArrayList<>();
		soeErrorsList.add(errors);
		SOEErrorHolder errorHolder=new SOEErrorHolder(soeErrorsList);
		return new SOESecurityException(statusCode,errorHolder);
	}

	public static String maskStringField(String str, int digitsToShow){
		if(StringUtilities.isNotEmptyOrNull(str) && str.length() >= digitsToShow){
			return StringUtils.right(str, digitsToShow);
		}
		return str;
	}

	public static void addHubProspectCartCookieToResponse(ServerHttpResponse httpResponse, boolean isHubProspectCartCookieDomainIssueFFlagEnabled, String cookieValue, List<String> domainsList) {
		if (isHubProspectCartCookieDomainIssueFFlagEnabled) {
			for (String domain : domainsList) {
				httpResponse.addCookie(ResponseCookie.from(CartConstants.HUB_PROSPECT_CART, cookieValue)
						.path("/").domain(domain).httpOnly(false).build());
			}
		} else {
			httpResponse.addCookie(ResponseCookie.from(CartConstants.HUB_PROSPECT_CART, cookieValue)
					.path("/").httpOnly(false).build());
		}
	}
}
