package onevz.soe.cart.helper;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.addAccessory.AddAccContext;
import onevz.soe.cart.model.addAccessory.AddAccServiceBody;
import onevz.soe.cart.model.addAccessory.AddAccServiceResponse;
import onevz.soe.cart.model.addBuyout.AddBuyoutContext;
import onevz.soe.cart.model.addBuyout.AddBuyoutServiceBody;
import onevz.soe.cart.model.addBuyout.AddBuyoutServiceResponse;
import onevz.soe.cart.model.addDevice.AddDeviceContext;
import onevz.soe.cart.model.addDevice.AddDeviceServiceBody;
import onevz.soe.cart.model.addDevice.AddDeviceServiceResponse;
import onevz.soe.cart.model.addFeature.AddFeaturesContext;
import onevz.soe.cart.model.addFeature.AddFeaturesServiceBody;
import onevz.soe.cart.model.addFeature.AddFeaturesServiceResponse;
import onevz.soe.cart.model.addPlan.AddPlanContext;
import onevz.soe.cart.model.addPlan.AddPlanServiceBody;
import onevz.soe.cart.model.addPlan.AddPlanServiceResponse;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.CatalogResponse;
import onevz.soe.cart.ui.common.*;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.customerprofile.model.gql.assisted.Customer;
import onevz.soe.customerprofile.model.gql.assisted.Mtn;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.util.*;
import java.util.stream.Collectors;

import static onevz.soe.cart.util.FlexV2Util.isAccountHasBillAcc;

@Service
public class OmniDLHelperForAIQuote {
    public void updateUserData(Vzdl vzdl, CartRedisData rr, AddDeviceUIRequest request) {
        if (null != rr && null != rr.getCustomerProfile() && null != rr.getCustomerProfile().getData() && !ObjectUtils.isEmpty(rr.getCustomerProfile().getData().getCustomer())) {
            User user = new User();
            onevz.soe.customerprofile.model.gql.assisted.Customer assistedCustomer = rr.getCustomerProfile().getData().getCustomer();
            setAccount(rr, user , assistedCustomer);
            String accountNumber = assistedCustomer.getAccountNo();
            user.setCustomerType(assistedCustomer.getCustomerAttributes().getCustomerType());
            user.setAcctId_unhashed(accountNumber);
            user.setCustId_unhashed(assistedCustomer.getCustomerId());
            setAccountLast2(accountNumber, user);
            setNumberOfLinesAndId(assistedCustomer, user);
            if (!ObjectUtils.isEmpty(assistedCustomer.getAddress())) {
                user.setZip(assistedCustomer.getAddress().getZipCode());
            }
            user.setSession(request.getCartInfo().getSessionId());

            vzdl.setUser(user);
        }
    }

    private void setAccount(CartRedisData rr, User user, Customer assistedCustomer){
        if (StringUtilities.isNotEmptyOrNull(rr.getCustomerProfile().getData().getCustomer().getCustomerHash())) {
            user.setAccount(assistedCustomer.getCustomerHash());
        }
    }

    private  void setAccountLast2(String accountNumber, User user){
        if (StringUtilities.isNotEmptyOrNull(accountNumber)) {
            int dashIndex = accountNumber.indexOf("-");
            user.setAccountLast2(accountNumber.substring(dashIndex - 2, dashIndex));
        }

    }

    private void setNumberOfLinesAndId(onevz.soe.customerprofile.model.gql.assisted.Customer assistedCustomer, User user ){
        if (assistedCustomer.getBillAccounts() != null && !assistedCustomer.getBillAccounts().isEmpty()) {
            assistedCustomer.getBillAccounts().stream().filter(Objects::nonNull).forEach(billAccount -> {
                if (billAccount.getMtns() != null) {
                    user.setNumberOfLines(String.valueOf(billAccount.getMtns().size()));
                    billAccount.getMtns().stream().filter(Objects::nonNull).forEach(mtn -> {
                        if (mtn.getMtn() != null && mtn.getMtn().equalsIgnoreCase(assistedCustomer.getLookupMtn())) {
                            user.setId(mtn.getMtnHashCode());
                        }
                    });
                }
            });
        }
    }

    public void updatePageData(Vzdl vzdl, AddDeviceUIRequest request) {
        Page vzdlPage = new Page();
        vzdlPage.setName("ai-quote-selection");
        vzdlPage.setLanguage("English");
        vzdlPage.setFlowType("");
        vzdlPage.setFlowName("Aiquote");
        if (StringUtilities.isNotEmptyOrNull(request.getChannelId())) {
            vzdlPage.setChannel("Order");
            if (request.getChannelId().equalsIgnoreCase(CartConstants.RETAIL) || request.getChannelId().equalsIgnoreCase(CartConstants.RETAIL_IPAD))
                vzdlPage.setDisplayChannel("retail");
        }
        if (null != request.getCartInfo()) {
            if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getIntendType())) {
                vzdlPage.setFlow(request.getCartInfo().getIntendType());
            }
            if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCaseId())) {
                vzdlPage.setPegaCaseId(request.getCartInfo().getCaseId());
            }
            if (StringUtilities.isNotEmptyOrNull(request.getCartInfo().getCartId())) {
                vzdlPage.setCartId(request.getCartInfo().getCartId());
            }
        }
        vzdlPage.setThrottle("MFE");
        vzdl.setPage(vzdlPage);
    }

    public void updateTxnData(Vzdl vzdl, CartRedisData redisData, AddDeviceUIRequest addDeviceUIRequest, Optional<CartServiceCartInfo> cartInfo) {
        Map<String, String> txn = new HashMap<>();
        if (cartInfo.isPresent()) {
            if (StringUtilities.isNotEmptyOrNull(cartInfo.get().getCartId())) {
                txn.put("cartId", cartInfo.get().getCartId());
            }
            if (StringUtilities.isNotEmptyOrNull(redisData.getAutoPayEnrolled())) {
                txn.put("autoPay", redisData.getAutoPayEnrolled());
            }
        }
        if (redisData != null) {
            if (StringUtilities.isNotEmptyOrNull(redisData.getLocationCode())) {
                txn.put("outletId", redisData.getLocationCode());
            }
            if (null != addDeviceUIRequest.getCartInfo() && StringUtilities.isNotEmptyOrNull(addDeviceUIRequest.getCartInfo().getIntendType())) {
                txn.put("orderType", addDeviceUIRequest.getCartInfo().getIntendType());
            }
            if (StringUtilities.isNotEmptyOrNull(redisData.getAgentRole())) {
                txn.put("agentRole", redisData.getAgentRole());
            }
        }
        vzdl.setTxn(txn);
    }

    public void updateEvent(Vzdl vzdl) {
        Event event = new Event();
        event.setValue("");
        vzdl.setEvent(event);
    }

    public Vzdl getVzdlDataForAddDevice(AddDeviceUIRequest request, AddDeviceUIResponse response, CartRedisData rr) {
        boolean reqDataNullCheck = request != null && request.getData() != null;
        boolean resDataNullCheck = response != null && response.getServiceBody() != null;
        Vzdl vzdl = null;
        if (resDataNullCheck && reqDataNullCheck) {
            vzdl = populateVzdlDataForAddDevice(request, response, rr);
        }
        return vzdl;
    }

    public Vzdl getVzdlDataForAddPlanAndPerks(AddPlanUIRequest request, AddPlanUIResponse response, boolean aiQuoteTaggingEnabledFFlag) {
        boolean reqDataNullCheck = request != null && request.getData() != null;
        boolean resDataNullCheck = response != null && response.getServiceBody() != null;
        Vzdl vzdl = null;
        if (resDataNullCheck && reqDataNullCheck) {
            vzdl = populateVzdlDataForAddPlanAndPerks(request, response , aiQuoteTaggingEnabledFFlag);
        }
        return vzdl;
    }
    public Vzdl getVzdlDataForAddAccessories(AddAccessoriesUIRequest request, AddAccessoriesUIResponse response, CatalogResponse catalogResponse) {
        boolean reqDataNullCheck = request != null && request.getData() != null;
        boolean resDataNullCheck = response != null && response.getServiceBody() != null;
        Vzdl vzdl = null;
        if (resDataNullCheck && reqDataNullCheck) {
            vzdl = populateVzdlDataForAddAccessories(request, response, catalogResponse);
        }
        return vzdl;
    }

    public Vzdl populateVzdlDataForAddAccessories(AddAccessoriesUIRequest request, AddAccessoriesUIResponse response, CatalogResponse catalogResponse) {
        Optional<CartServiceCartInfo> cartInfo = Optional.ofNullable(response.getServiceBody()).map(AddAccServiceBody::getServiceResponse).map(AddAccServiceResponse::getContext).map(AddAccContext::getCartInfo);
        Optional<Line> responseLine = cartInfo.map(CartServiceCartInfo::getLines).map(lines -> lines.length > 0 ? lines[0] : null);
        Optional<Lines> requestLine = Optional.ofNullable(request).map(AddAccessoriesUIRequest::getData).map(AddAccessoriesData::getLines).map(lines -> lines.length != 0 ? lines[0] : null);
        Vzdl vzdl = null;
        if (cartInfo.isPresent() && responseLine.isPresent() && requestLine.isPresent()) {
            vzdl = new Vzdl();
            updateProductDataForAccessories(vzdl, request, requestLine, cartInfo, catalogResponse);
            updateEvent(vzdl);
        }
        return vzdl;
    }

    public void updateProductDataForAccessories(Vzdl vzdl, AddAccessoriesUIRequest request, Optional<Lines> requestLine, Optional<CartServiceCartInfo> cartInfo, CatalogResponse catalogResponse) {
        List<Current> currentList = new ArrayList<>();
        Product product = new Product();
        if(requestLine.isPresent()) {
            Optional.ofNullable(request).map(AddAccessoriesUIRequest::getData).map(AddAccessoriesData::getLines).ifPresent(linesList ->
                    Arrays.stream(linesList).forEach(lines -> {
                        Current current = new Current();
                        if (null != lines.getAddAccessories() && lines.getAddAccessories().length>0 ) {
                            for(Accessory accessory:lines.getAddAccessories()){
                                current.setCategory("Accessories");
                                current.setId(accessory.getId());
                                current.setLine(lines.getMtn());
                                current.setQty("1");
                                setRecurringPriceNameAndSkuForAccessories(cartInfo, lines, accessory, current);
                                setSetupPriceAndNameFromCatalogResponse(accessory, catalogResponse, current);
                                currentList.add(current);
                            }
                        }
                    }));
        }
        Current[] currentArray = new Current[currentList.size()];
        product.setCurrent(currentList.toArray(currentArray));
        vzdl.setProduct(product);
    }

    private void setRecurringPriceNameAndSkuForAccessories(Optional<CartServiceCartInfo> cartInfo, Lines lines, Accessory accessory, Current current) {
        if (cartInfo.isPresent() && cartInfo.get().getLines() != null) {
            Arrays.stream(cartInfo.get().getLines()).filter(line -> null != line && matchingMtn(line, lines)).forEach(line -> Optional.ofNullable(line.getSpos()).ifPresent(spos -> Arrays.stream(spos).filter(spo -> isMatchingSpo(spo,accessory)).forEach(spo -> {
                setRecurringPriceNameAndSkuForAccessories(current, spo);
            })));
        }
    }

    private void setRecurringPriceNameAndSkuForAccessories(Current current, ConflictedSPO spo){
        current.setRecurringPrice(StringUtilities.isNotEmptyOrNull(spo.getPrice()) ? spo.getPrice() : "0.00");
        current.setName(StringUtilities.isNotEmptyOrNull(spo.getDescription()) ? spo.getDescription() : "");
        current.setSku(StringUtilities.isNotEmptyOrNull(spo.getSkuId()) ? spo.getSkuId() : "");
    }

    private boolean isMatchingSpo(ConflictedSPO spo, Accessory accessory) {
        return   null != spo && StringUtilities.isNotEmptyOrNull(spo.getId()) && StringUtilities.isNotEmptyOrNull(accessory.getId()) && spo.getId().equalsIgnoreCase(accessory.getId());
    }

    private void setSetupPriceAndNameFromCatalogResponse(Accessory accessory, CatalogResponse catalogResponse, Current current) {
        if (accessory.getId() != null && accessory.getId().contains(CartConstants.SETUPANDGO) && catalogResponse != null && catalogResponse.getData() != null &&
                CollectionUtilities.isNotEmptyOrNull(catalogResponse.getData().getSoftSkuCatalogItems())) {
            catalogResponse.getData().getSoftSkuCatalogItems().stream().filter(softSkuCatalogItem -> StringUtilities.isNotEmptyOrNull(softSkuCatalogItem.getSorId()) && softSkuCatalogItem.getSorId().equalsIgnoreCase(accessory.getId()))
                    .findFirst().ifPresent(catalogItem -> {
                        current.setName(StringUtilities.isNotEmptyOrNull(catalogItem.getSkuDisplayName()) ? catalogItem.getSkuDisplayName() : "");
                        String originalPrice = catalogItem.getPrice() != null
                                && catalogItem.getPrice().getFullRetailPrice() != null &&
                                catalogItem.getPrice().getFullRetailPrice().getOriginalPrice() != null ?
                                String.valueOf(catalogItem.getPrice().getFullRetailPrice().getOriginalPrice()) : "0.00";
                        current.setNonRecurringPrice(originalPrice);
                    });


        }
    }

    public Vzdl getVzdlDataForAddFeatures(AddFeaturesUIRequest request, AddFeaturesUIResponse response) {
        boolean reqDataNullCheck = request != null && request.getData() != null;
        boolean resDataNullCheck = response != null && response.getServiceBody() != null;
        Vzdl vzdl = null;
        if (resDataNullCheck && reqDataNullCheck) {
            vzdl = populateVzdlDataForAddFeatures(request, response);
        }
        return vzdl;
    }

    public Vzdl populateVzdlDataForAddFeatures(AddFeaturesUIRequest request, AddFeaturesUIResponse response) {
        Optional<CartServiceCartInfo> cartInfo = Optional.ofNullable(response.getServiceBody()).map(AddFeaturesServiceBody::getServiceResponse).map(AddFeaturesServiceResponse::getContext).map(AddFeaturesContext::getCartInfo);
        Optional<Line> responseLine = cartInfo.map(CartServiceCartInfo::getLines).map(lines -> lines.length > 0 ? lines[0] : null);
        Optional<LineFeature> requestLine = Optional.ofNullable(request).map(AddFeaturesUIRequest::getData).map(AddFeaturesData::getLines).map(lines -> lines.length != 0 ? lines[0] : null);
        Vzdl vzdl = null;
        if (cartInfo.isPresent() && responseLine.isPresent() && requestLine.isPresent()) {
            vzdl = new Vzdl();
            updateProductDataForFeatures(vzdl, request, requestLine, cartInfo);
            updateEvent(vzdl);
        }
        return vzdl;
    }
    public void updateProductDataForFeatures(Vzdl vzdl, AddFeaturesUIRequest request, Optional<LineFeature> requestLine, Optional<CartServiceCartInfo> cartInfo) {
        List<Current> currentList = new ArrayList<>();
        Product product = new Product();
        if(requestLine.isPresent()) {
            Optional.ofNullable(request).map(AddFeaturesUIRequest::getData).map(AddFeaturesData::getLines).ifPresent(linesList ->
                    Arrays.stream(linesList).forEach(lines -> {
                        Current current = new Current();
                        if (null != lines.getFeatures() && lines.getFeatures().getAdd()!=null
                                && CollectionUtilities.isNotEmptyOrNull(lines.getFeatures().getAdd()) ) {
                            for(Feature feature:lines.getFeatures().getAdd()){
                                updateFeatureAction(currentList, lines, current, feature, cartInfo);
                            }
                            for(Feature feature:lines.getFeatures().getRemove()){
                                updateFeatureAction(currentList, lines, current, feature, cartInfo);
                            }

                        }
                    }));
        }
        Current[] currentArray = new Current[currentList.size()];
        product.setCurrent(currentList.toArray(currentArray));
        vzdl.setProduct(product);
    }

    public void updateProductDataForFeatures(Vzdl vzdl, AddPlanUIRequest request, Optional<Lines> requestLine, Optional<CartServiceCartInfo> cartInfo) {
        List<Current> currentList = new ArrayList<>();
        Product product = new Product();
        if(requestLine.isPresent()) {
            Optional.ofNullable(request).map(AddPlanUIRequest::getData).map(AddPlanData::getLines).ifPresent(linesList ->
                    Arrays.stream(linesList).forEach(lines -> {
                        updateFeatureActionForAddFeatures(currentList, lines, cartInfo);
                        updateFeatureActionForRemoveFeatures(currentList, lines, cartInfo);
                    }));
        }
        if (CollectionUtilities.isNotEmptyOrNull(currentList)) {
            Current[] currentArray = new Current[currentList.size()];
            product.setCurrent(currentList.toArray(currentArray));
            vzdl.setProduct(product);
        }
    }

    private void updateFeatureActionForAddFeatures(List<Current> currentList, Lines lines, Optional<CartServiceCartInfo> cartInfo) {
        if (CollectionUtilities.isNotEmptyOrNull(lines.getAddFeatures())) {
            for (Feature feature : lines.getAddFeatures()) {
                Current current = new Current();
                updateFeatureAction(currentList, lines, current, feature, cartInfo);
            }
        }
    }

    private void updateFeatureActionForRemoveFeatures(List<Current> currentList, Lines lines, Optional<CartServiceCartInfo> cartInfo) {
        if (CollectionUtilities.isNotEmptyOrNull(lines.getRemoveFeatures())) {
            for (Feature feature : lines.getRemoveFeatures()) {
                Current current = new Current();
                updateFeatureAction(currentList, lines, current, feature, cartInfo);
            }
        }
    }

    private void updateFeatureAction(List<Current> currentList, LineFeature lineFeature, Current currentObject, Feature feature, Optional<CartServiceCartInfo> cartInfo) {
        currentObject.setCategory("Accessories");
        if(feature.getActionIndicator()!=null){
            currentObject.setAction(feature.getActionIndicator());
        }
        currentObject.setId(feature.getId());
        currentObject.setLine(lineFeature.getMtn());
        currentObject.setPropId(feature.getPropId());
        currentObject.setQty(String.valueOf(feature.getQuantity()));
        setSpoDetailsToCurrent(cartInfo, currentObject, lineFeature, feature);
        currentList.add(currentObject);
    }

    private void setSpoDetailsToCurrent(Optional<CartServiceCartInfo> cartInfo, Current currentObject, LineFeature lineFeature, Feature feature){
        if (cartInfo.isPresent() && cartInfo.get().getLines() != null)
            Arrays.stream(cartInfo.get().getLines()).filter(line -> null != line && isMatchingMtn(line, lineFeature)).forEach(line -> Optional.ofNullable(line.getSpos()).ifPresent(spos -> Arrays.stream(spos).filter(spo -> isMatchingSpo(spo, feature)).forEach(spo -> {
                mapSpoData(currentObject, spo);
            })));
    }

    private void mapSpoData(Current currentObject, ConflictedSPO spo){
        currentObject.setRecurringPrice(StringUtilities.isNotEmptyOrNull(spo.getPrice()) ? spo.getPrice() : "0.00");
        currentObject.setName(StringUtilities.isNotEmptyOrNull(spo.getDescription()) ? spo.getDescription() : "");
        currentObject.setSku(StringUtilities.isNotEmptyOrNull(spo.getSkuId()) ? spo.getSkuId() : "");

    }

    private boolean isMatchingSpo(ConflictedSPO spo, Feature feature){
        return null != spo && StringUtilities.isNotEmptyOrNull(spo.getId()) && StringUtilities.isNotEmptyOrNull(feature.getId()) && spo.getId().equalsIgnoreCase(feature.getId());
    }
    private boolean isMatchingMtn(Line line, LineFeature lineFeature){
        return StringUtilities.isNotEmptyOrNull(line.getMtn()) && line.getMtn().equalsIgnoreCase(lineFeature.getMtn());
    }

    private void updateFeatureAction(List<Current> currentList, Lines lines, Current current, Feature feature, Optional<CartServiceCartInfo> cartInfo) {
        current.setCategory("Features");
        if(feature.getActionIndicator()!=null){
            current.setAction(feature.getActionIndicator());
        }
        current.setId(feature.getId());
        current.setLine(lines.getMtn());
        current.setQty(String.valueOf(feature.getQuantity()));
        current.setPropId(feature.getPropId());
        setSpoData(cartInfo, current, lines, feature);
        currentList.add(current);
    }
    private void setSpoData(Optional<CartServiceCartInfo> cartInfo, Current current, Lines lines, Feature feature){
        if (cartInfo.isPresent() && cartInfo.get().getLines() != null)
            Arrays.stream(cartInfo.get().getLines()).filter(line -> null != line && isMatchingMtn(line, lines)).forEach(line -> Optional.ofNullable(line.getSpos()).ifPresent(spos -> Arrays.stream(spos).filter(spo -> isMatchingSpo(spo, feature)).forEach(spo -> {
                mapSpoData(current, spo);
            })));
    }

    private boolean isMatchingMtn(Line line, Lines lines){
        return  StringUtilities.isNotEmptyOrNull(line.getMtn()) && line.getMtn().equalsIgnoreCase(lines.getMtn());
    }

    public Vzdl getVzdlDataForAddBuyout(AddBuyoutUIRequest request, AddBuyoutUIResponse response) {
        boolean reqDataNullCheck = request != null && request.getData() != null;
        boolean resDataNullCheck = response != null && response.getServiceBody() != null;
        Vzdl vzdl = null;
        if (resDataNullCheck && reqDataNullCheck) {
            vzdl = populateVzdlDataForAddBuyout(request, response);
        }
        return vzdl;
    }
    public Vzdl populateVzdlDataForAddBuyout(AddBuyoutUIRequest request, AddBuyoutUIResponse response) {
        Optional<CartServiceCartInfo> cartInfo = Optional.ofNullable(response.getServiceBody()).map(AddBuyoutServiceBody::getServiceResponse).map(AddBuyoutServiceResponse::getContext).map(AddBuyoutContext::getCartInfo);
        Optional<Lines> requestLine = Optional.ofNullable(request).map(AddBuyoutUIRequest::getData).map(AddBuyoutData::getLines).map(lines -> lines.length != 0 ? lines[0] : null);
        Vzdl vzdl = null;
        if (cartInfo.isPresent() && requestLine.isPresent()) {
            vzdl = new Vzdl();
            updateProductDataForBuyout(vzdl, request, requestLine);
            updateEvent(vzdl);
        }
        return vzdl;
    }
    public void updateProductDataForBuyout(Vzdl vzdl, AddBuyoutUIRequest request, Optional<Lines> requestLine) {
        List<Current> currentList = new ArrayList<>();
        Product product = new Product();
        if(requestLine.isPresent()) {
            Optional.ofNullable(request).map(AddBuyoutUIRequest::getData).map(AddBuyoutData::getLines).ifPresent(linesList ->
                    Arrays.stream(linesList).forEach(lines -> {
                        Current current = new Current();
                        if (null != lines.getMtn()) {
                            current.setCategory("Add Buyout");
                            current.setLine(lines.getMtn());
                            currentList.add(current);
                        }
                    }));
        }
        Current[] currentArray = new Current[currentList.size()];
        product.setCurrent(currentList.toArray(currentArray));
        vzdl.setProduct(product);
    }

    public Vzdl populateVzdlDataForAddPlanAndPerks(AddPlanUIRequest request, AddPlanUIResponse response, boolean aiQuoteTaggingEnabledFFlag) {
        Optional<CartServiceCartInfo> cartInfo = Optional.ofNullable(response.getServiceBody()).map(AddPlanServiceBody::getServiceResponse).map(AddPlanServiceResponse::getContext).map(AddPlanContext::getCartInfo);
        Optional<Line> responseLine = cartInfo.map(CartServiceCartInfo::getLines).map(lines -> lines.length > 0 ? lines[0] : null);
        Optional<Lines> requestLine = Optional.ofNullable(request).map(AddPlanUIRequest::getData).map(AddPlanData::getLines).map(lines -> lines.length != 0 ? lines[0] : null);
        Vzdl vzdl = null;
        if (cartInfo.isPresent() && responseLine.isPresent() && requestLine.isPresent()) {
            vzdl = new Vzdl();
            updateProductDataForPlan(vzdl, request, requestLine, cartInfo);
            if(aiQuoteTaggingEnabledFFlag){
                updateProductDataForFeatures(vzdl,request,requestLine,cartInfo);
            }
            updateEvent(vzdl);
        }
        return vzdl;
    }

    public void updateProductDataForPlan(Vzdl vzdl, AddPlanUIRequest request, Optional<Lines> requestLine, Optional<CartServiceCartInfo> serviceCartInfo) {
        List<Current> currentList = new ArrayList<>();
        Product product = new Product();
        if(requestLine.isPresent()) {
            Optional.ofNullable(request).map(AddPlanUIRequest::getData).map(AddPlanData::getLines).ifPresent(linesList ->
                    Arrays.stream(linesList).forEach(lines -> {
                        Current currentObject = new Current();
                        setCurrent(currentList,currentObject, lines, serviceCartInfo);
                    }));
        }
        Current[] currentArray = new Current[currentList.size()];
        product.setCurrent(currentList.toArray(currentArray));
        vzdl.setProduct(product);
    }

    private void setCurrent(List<Current> currentList, Current currentObject, Lines lines, Optional<CartServiceCartInfo> serviceCartInfo){
        if (null != lines.getPlan() && null != lines.getPlan().getId()) {
            currentObject.setCategory("Plan");
            currentObject.setId(lines.getPlan().getId());
            currentObject.setQty("1");
            currentObject.setPropId(StringUtilities.isNotEmptyOrNull(lines.getPlan().getPropId()) ? lines.getPlan().getPropId() : "");
            if (StringUtilities.isNotEmptyOrNull(lines.getPlan().getPath())) {
                currentObject.setPath(lines.getPlan().getPath());
            }
            setPlanDetailsToCurrent(serviceCartInfo, currentObject, lines);
            currentList.add(currentObject);
        }
    }

    private void setPlanDetailsToCurrent(Optional<CartServiceCartInfo> serviceCartInfo, Current currentObject, Lines lines){
        if (serviceCartInfo.isPresent() && serviceCartInfo.get().getLines() != null) {
            Arrays.stream(serviceCartInfo.get().getLines()).filter(line -> null != line && matchingMtn(line, lines) && matchingPlan(line, lines)).forEach(line -> {
                setRecurringPrice(line, currentObject);
                currentObject.setSku(StringUtilities.isNotEmptyOrNull(line.getPlan().getProductId()) ? line.getPlan().getProductId() : "");
                currentObject.setName(StringUtilities.isNotEmptyOrNull(line.getPlan().getName()) ? line.getPlan().getName() : "");
                currentObject.setNonRecurringPrice("0.00");
            });
        }
    }

    private boolean matchingMtn(Line line, Lines lines ){
        return StringUtilities.isNotEmptyOrNull(line.getMtn()) && line.getMtn().equalsIgnoreCase(lines.getMtn());
    }

    private boolean matchingPlan(Line line, Lines lines){
        return null != line.getPlan() && StringUtilities.isNotEmptyOrNull(line.getPlan().getId()) && line.getPlan().getId().equalsIgnoreCase(lines.getPlan().getId());
    }

    private void setRecurringPrice(Line line, Current currentObject){
        if (StringUtilities.isNotEmptyOrNull(line.getPlan().getDiscountedPrice()))
            currentObject.setRecurringPrice(line.getPlan().getDiscountedPrice());
        else
            currentObject.setRecurringPrice(StringUtilities.isNotEmptyOrNull(line.getPlan().getPrice()) ? line.getPlan().getPrice() : "0.00");

    }

    public Vzdl populateVzdlDataForAddDevice(AddDeviceUIRequest request, AddDeviceUIResponse response, CartRedisData rr) {
        Optional<CartServiceCartInfo> cartInfo = Optional.ofNullable(response.getServiceBody()).map(AddDeviceServiceBody::getServiceResponse).map(AddDeviceServiceResponse::getContext).map(AddDeviceContext::getCartInfo);
        Optional<Line> responseLine = cartInfo.map(CartServiceCartInfo::getLines).map(lines -> lines.length > 0 ? lines[0] : null);
        Optional<Lines> requestLine = Optional.ofNullable(request).map(AddDeviceUIRequest::getData).map(AddDeviceData::getLines).map(lines -> lines.size() != 0 ? lines.get(0) : null);

        Vzdl vzdl = null;
        if (cartInfo.isPresent() && responseLine.isPresent() && requestLine.isPresent()) {
            vzdl = new Vzdl();
            updateUserData(vzdl, rr, request);
            updatePageData(vzdl, request);
            updateTxnData(vzdl, rr, request, cartInfo);
            updateProductDataForDevice(vzdl, rr, request, requestLine, cartInfo);
            updateEvent(vzdl);
        }
        return vzdl;
    }

    public void updateProductDataForDevice(Vzdl vzdl, CartRedisData rr, AddDeviceUIRequest request, Optional<Lines> requestLine, Optional<CartServiceCartInfo> serviceCartInfo) {
        Product product = new Product();
        List<Owns> ownsArrayList = new ArrayList<>();
        List<Current> currentList = new ArrayList<>();
        List<String> requestMtnList = request.getData().getLines().stream().filter(Objects::nonNull).map(Lines::getMtn).collect(Collectors.toList());
        addOwnsToList(rr, requestMtnList, ownsArrayList);

        if (requestLine.isPresent()) {
            addLineCurrentToList(request, rr, serviceCartInfo, requestMtnList,  currentList);
        }
        Owns[] ownsArray = new Owns[ownsArrayList.size()];
        Current[] currents = new Current[currentList.size()];
        product.setOwns(ownsArrayList.toArray(ownsArray));
        product.setCurrent(currentList.toArray(currents));
        vzdl.setProduct(product);
    }

    private void addLineCurrentToList(AddDeviceUIRequest request, CartRedisData rr, Optional<CartServiceCartInfo> serviceCartInfo, List<String> requestMtnList, List<Current> currentList) {
        Optional.ofNullable(request).map(AddDeviceUIRequest::getData).map(AddDeviceData::getLines).ifPresent(linesList ->
                linesList.forEach(lines -> {
                    addDeviceCurrentToList(lines, rr, serviceCartInfo, requestMtnList, currentList);
                    addPlanCurrentToList(lines, rr, serviceCartInfo, requestMtnList, currentList);
                    addFeaturesCurrentToList(lines, serviceCartInfo, currentList);

                }));
    }

    private void addDeviceCurrentToList(Lines lines, CartRedisData rr, Optional<CartServiceCartInfo> serviceCartInfo, List<String> requestMtnList, List<Current> currentList) {
        if (null != lines.getDevice() && null != lines.getDevice().getId()) {
            Current currentObject = new Current();
            currentObject.setCategory("Device");
            currentObject.setId(lines.getDevice().getId());
            currentObject.setQty("1");
            setCurrentObjectLine(rr, requestMtnList, currentObject);
            if (serviceCartInfo.isPresent() && serviceCartInfo.get().getLines() != null) {
                Arrays.stream(serviceCartInfo.get().getLines()).filter(line -> null != line && matchingMtn(line, lines)
                        && matchingDevice(line, lines)).forEach(line -> {
                    if (StringUtilities.isNotEmptyOrNull(line.getDevice().getDiscountAmount()))
                        currentObject.setDiscount(line.getDevice().getDiscountAmount());
                    currentObject.setSku(StringUtilities.isNotEmptyOrNull(line.getDevice().getSkuId()) ? line.getDevice().getSkuId() : "");
                    currentObject.setId(line.getDevice().getId());
                    currentObject.setName(StringUtilities.isNotEmptyOrNull(line.getDevice().getSkuDisplayName()) ? line.getDevice().getSkuDisplayName() : "");
                    currentObject.setRecurringPrice(String.valueOf(line.getMonthlyInstallment()));
                    currentObject.setNonRecurringPrice(StringUtilities.isNotEmptyOrNull(line.getDevice().getItemPrice()) ? line.getDevice().getItemPrice() : "");
                });
            }
            currentList.add(currentObject);
        }
    }

    private boolean matchingDevice(Line line, Lines lines){
        return null != line.getDevice() && StringUtilities.isNotEmptyOrNull(line.getDevice().getId()) && line.getDevice().getId().equalsIgnoreCase(lines.getDevice().getId());
    }

    private void setCurrentObjectLine(CartRedisData rr, List<String> requestMtnList, Current currentObject) {
        if (rr.getCustomerProfile() != null && isAccountHasBillAcc(rr.getCustomerProfile())) {
            rr.getCustomerProfile().getData().getCustomer().getBillAccounts().stream().filter(Objects::nonNull)
                    .forEach(accData -> accData.getMtns().stream().filter(data -> requestMtnList.contains(data.getMtn()))
                            .forEach(matchedLine -> {
                                if (null != matchedLine.getMtnHashCode()) {
                                    currentObject.setLine(matchedLine.getMtnHashCode());
                                }
                            }));
        }
    }

    private void addPlanCurrentToList(Lines lines, CartRedisData rr, Optional<CartServiceCartInfo> serviceCartInfo, List<String> requestMtnList, List<Current> currentList) {
        if(null != lines.getPlan() && null != lines.getPlan().getId()){
            Current current = new Current();
            current.setCategory("Plan");
            current.setId(lines.getPlan().getId());
            current.setQty("1");
            current.setPropId(StringUtilities.isNotEmptyOrNull(lines.getPlan().getPropId()) ? lines.getPlan().getPropId() : "");
            if (StringUtilities.isNotEmptyOrNull(lines.getPlan().getPath())) {
                current.setPath(lines.getPlan().getPath());
            }
            if(rr.getCustomerProfile()!= null && isAccountHasBillAcc(rr.getCustomerProfile())){
                rr.getCustomerProfile().getData().getCustomer().getBillAccounts().stream().filter(Objects::nonNull)
                        .forEach(accData -> accData.getMtns().stream().filter(data -> requestMtnList.contains(data.getMtn()))
                                .forEach(matchedLine -> {
                                    if(null != matchedLine.getMtnHashCode()) {
                                        current.setLine(matchedLine.getMtnHashCode()); }}));}
            if (serviceCartInfo.isPresent() && serviceCartInfo.get().getLines() != null) {
                Arrays.stream(serviceCartInfo.get().getLines()).filter(line -> null != line && StringUtilities.isNotEmptyOrNull(line.getMtn()) && line.getMtn().equalsIgnoreCase(lines.getMtn()) && null != line.getPlan() && StringUtilities.isNotEmptyOrNull(line.getPlan().getId()) && line.getPlan().getId().equalsIgnoreCase(lines.getPlan().getId())).forEach(line -> {
                    if (StringUtilities.isNotEmptyOrNull(line.getPlan().getDiscountedPrice()))
                        current.setRecurringPrice(line.getPlan().getDiscountedPrice());
                    else
                        current.setRecurringPrice(StringUtilities.isNotEmptyOrNull(line.getPlan().getPrice())?line.getPlan().getPrice():"0.00");
                    current.setSku(StringUtilities.isNotEmptyOrNull(line.getPlan().getProductId())?line.getPlan().getProductId():"");
                    current.setName(StringUtilities.isNotEmptyOrNull(line.getPlan().getName())?line.getPlan().getName():"");
                    current.setNonRecurringPrice("0.00");
                });
            }
            currentList.add(current);
        }
    }

    private void addFeaturesCurrentToList(Lines lines, Optional<CartServiceCartInfo> serviceCartInfo, List<Current> currentList) {
        if(null != lines.getAddFeatures() && !lines.getAddFeatures().isEmpty() ){
            Current current = new Current();
            lines.getAddFeatures().stream().filter(Objects::nonNull).forEach(feature -> {
                Current featureCurrent = new Current();
                featureCurrent.setCategory("Features");
                featureCurrent.setId(feature.getId());
                featureCurrent.setQty("1");
                featureCurrent.setNonRecurringPrice("0.00");
                if(StringUtilities.isNotEmptyOrNull(current.getLine())) {
                    featureCurrent.setLine(current.getLine());
                }
                if (null != lines.getPlan() && StringUtilities.isNotEmptyOrNull(lines.getPlan().getPath())) {
                    featureCurrent.setPath(lines.getPlan().getPath());
                }
                if (serviceCartInfo.isPresent() && serviceCartInfo.get().getLines() != null) {
                    Arrays.stream(serviceCartInfo.get().getLines()).filter(line -> null != line && StringUtilities.isNotEmptyOrNull(line.getMtn()) && line.getMtn().equalsIgnoreCase(lines.getMtn())).forEach(line -> Optional.ofNullable(line.getSpos()).ifPresent(spos -> Arrays.stream(spos).filter(spo -> null != spo && StringUtilities.isNotEmptyOrNull(spo.getId()) && StringUtilities.isNotEmptyOrNull(feature.getId()) && spo.getId().equalsIgnoreCase(feature.getId())).forEach(spo -> {
                        featureCurrent.setRecurringPrice(StringUtilities.isNotEmptyOrNull(spo.getPrice()) ? spo.getPrice() : "0.00");
                        featureCurrent.setName(StringUtilities.isNotEmptyOrNull(spo.getDescription()) ? spo.getDescription() : "");
                        featureCurrent.setSku(StringUtilities.isNotEmptyOrNull(spo.getSkuId()) ? spo.getSkuId() : "");
                    })));
                }
                currentList.add(featureCurrent);
            });
        }
    }

    private void addOwnsToList(CartRedisData rr, List<String> requestMtnList, List<Owns> ownsArrayList) {
        if (null != rr && rr.getCustomerProfile() != null && isAccountHasBillAcc(rr.getCustomerProfile())) {

            rr.getCustomerProfile().getData().getCustomer().getBillAccounts().stream().filter(Objects::nonNull).forEach(accData -> accData.getMtns().stream().filter(data -> requestMtnList.contains(data.getMtn())).forEach(matchedLine -> {
                Owns ownsObject = new Owns();
                ownsObject.setCategory("Plan");
                setOwnsObject(ownsObject, matchedLine);
                ownsArrayList.add(ownsObject);
            }));
        }
    }

    private void setOwnsObject(Owns ownsObject, Mtn matchedLine){
        if (StringUtilities.isNotEmptyOrNull(matchedLine.getPricePlanInfo().getDescription())) {
            ownsObject.setName(matchedLine.getPricePlanInfo().getDescription());
        }
        if (StringUtilities.isNotEmptyOrNull(matchedLine.getPricePlanInfo().getPlanId())) {
            ownsObject.setId(matchedLine.getPricePlanInfo().getPlanId());
        }
        if (StringUtilities.isNotEmptyOrNull(matchedLine.getMtnHashCode())) {
            ownsObject.setLine(matchedLine.getMtnHashCode());
        }
    }

}

