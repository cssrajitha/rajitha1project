package onevz.soe.cart.controller;

import java.io.UnsupportedEncodingException;
import java.security.SignatureException;
import java.util.ArrayList;
import java.util.List;

import jakarta.validation.Valid;

import onevz.soe.cart.helper.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.exceptions.JsonValidator;
import onevz.soe.cart.model.common.Device;
import onevz.soe.cart.model.common.SoftSKUItem;
import onevz.soe.cart.requests.RPSRequestVO;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.responses.InitiateAddressChangePEGAResponse;
import onevz.soe.cart.responses.RPSFlowRedisData;
import onevz.soe.cart.responses.RPSRedisData;
import onevz.soe.cart.ui.common.AddDeviceData;
import onevz.soe.cart.ui.common.DeviceCartInfo;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.AddDeviceUIRequest;
import onevz.soe.cart.ui.requests.DeviceSimValidationUIRequest;
import onevz.soe.cart.ui.requests.RPSApplePayloadUIRequest;
import onevz.soe.cart.ui.requests.RPSE911AddressRetrieveUIRequest;
import onevz.soe.cart.ui.requests.RPSE911AddressUpdateUIRequest;
import onevz.soe.cart.ui.requests.RPSReleasePendingOrderUIRequest;
import onevz.soe.cart.util.CartPegaRequestErrorsUtil;
import onevz.soe.cart.util.CartPegaResponseErrorsUtil;
import onevz.soe.cart.util.CommonUtil;
import onevz.soe.session.client.model.AccountInfoEligible;
import onevz.soe.utilities.StringUtilities;
import reactor.core.publisher.Mono;

/**
 * Cart Controller class.
 */
//NSADT-53978 removing CrossOrigin annotation in every service
//@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping(value = "cart")
public class CartRpsController {

	private static final Logger logger = LoggerFactory.getLogger(CartRpsController.class);

	@Autowired
	private CartRpsHelper cartRpsHelper;

	@Autowired
	private RedisHelper2 redisHelper2;

	@Autowired
	JsonValidator validator;

	@Value("${processingMtnFlag}")
	private String processingMtnFlag;

	@Value("${orderRestrictionCodes}")
	private String orderRestrictionCodes;

	@Autowired
	private CartAddDeviceHelper accDevHelper;

	@Autowired
	private CommonUtil util;

	/**
	 *
	 * @param binder
	 */
	@InitBinder("*")
	public void initBinderByName(WebDataBinder binder) {
		binder.setDisallowedFields(new String[] { "genericHeader" });
	}

	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param rpsRequestVO
	 * @return
	 */

	@SuppressWarnings("null")
	@PostMapping("/startRPSFlow")
	public Mono<ResponseEntity<GenericResponse>> startRPSFlow(ServerHttpRequest httpHeader,
			ServerHttpResponse httpResponse, @Valid @RequestBody RPSRequestVO rpsRequestVO) {
		System.setProperty(CartConstants.ENDPOINT, "startRPSFlow");
		logger.debug("startRPSFlow Request: {}", rpsRequestVO);

		return redisHelper2.getRPSDataFromRedisAsString().flatMap(rpsData -> {
			if (null != rpsRequestVO) {
				if (StringUtilities.isEmptyOrNull(rpsRequestVO.getPairingMode()) &&
						StringUtilities.isNotEmptyOrNull(rpsData.getCarrierPostData().getAssociatedSubscriprion())) {
					if (CartConstants.RPS_FLOW_ASSOCIATED_SUBSCRIPTION_TWO
							.equalsIgnoreCase(rpsData.getCarrierPostData().getAssociatedSubscriprion())) {
						rpsRequestVO.setPairingMode(CartConstants.RPS_FLOW_STANDALONE);
					} else {
						rpsRequestVO.setPairingMode(CartConstants.RPS_FLOW_NUMBERSHARE);
					}
				}
				if (StringUtilities.isEmptyOrNull(rpsRequestVO.getDeviceImei()) &&
							StringUtilities.isNotEmptyOrNull(rpsData.getSecondaryDeviceActive().getDeviceImei())) {
					 rpsRequestVO.setDeviceImei(rpsData.getSecondaryDeviceActive().getDeviceImei());
				}
			} else {
				if (StringUtilities.isNotEmptyOrNull(rpsData.getCarrierPostData().getAssociatedSubscriprion())){
				  	 rpsRequestVO.setPairingMode(CartConstants.RPS_FLOW_ASSOCIATED_SUBSCRIPTION_TWO
						  .equalsIgnoreCase(rpsData.getCarrierPostData().getAssociatedSubscriprion())?
						  CartConstants.RPS_FLOW_STANDALONE:CartConstants.RPS_FLOW_NUMBERSHARE);
				}
				if (StringUtilities.isNotEmptyOrNull(rpsData.getSecondaryDeviceActive().getDeviceImei())) {
					 rpsRequestVO.setDeviceImei(rpsData.getSecondaryDeviceActive().getDeviceImei());
				}

				if (StringUtilities.isNotEmptyOrNull(rpsData.getCarrierPostData().getPrimaryDeviceMTN())) {
					 rpsRequestVO.setUpgradeMtn(rpsData.getCarrierPostData().getPrimaryDeviceMTN());
				}

			}

			if ("standalone".equalsIgnoreCase(rpsRequestVO.getPairingMode())) {
				rpsRequestVO.setStandalone(true);
			}

			return cartRpsHelper.initiateRPSFlow(rpsRequestVO.isStandalone(), rpsRequestVO.getDeviceImei())
					.flatMap(resp -> {
						AccountInfoEligible accountInfoEligible = new AccountInfoEligible();
						accountInfoEligible.setAccountEligibleForBYOD(true);
						String cartId = resp.getServiceBody().getServiceResponse().getContext().getCartInfo()
								.getCartId();
						String caseId = resp.getServiceBody().getServiceResponse().getContext().getCaseId();

						return redisHelper2.upsertAccountInfoEligibleInRedis(accountInfoEligible, cartId, caseId)
								.flatMap(data -> {
                                    DeviceSimValidationUIRequest uiRequest = new DeviceSimValidationUIRequest();
                                    uiRequest.setDevid(rpsRequestVO.getDeviceImei());
                                    uiRequest.setEid(rpsData.getSecondaryDeviceActive().getEid());
                                    return cartRpsHelper.deviceSimValidationWithEid(resp,uiRequest).flatMap(eidUpdateResponse -> {
									AddDeviceUIRequest addDeviceUIRequest = new AddDeviceUIRequest();
									String accNumber = resp.getServiceBody().getServiceResponse().getContext()
											.getCustomerInfo().getAccountNumber();
									String cartCreator = resp.getServiceBody().getServiceResponse().getContext()
											.getCustomerInfo().getCartCreator();
									DeviceCartInfo deviceCartInfo = new DeviceCartInfo();
									deviceCartInfo.setAccountNumber(accNumber);
									deviceCartInfo.setCartCreator(cartCreator);
									deviceCartInfo.setCartId(cartId);
									deviceCartInfo.setCaseId(caseId);
									deviceCartInfo.setMtnFlow("M");
									if (StringUtilities.isNotEmptyOrNull(rpsRequestVO.getUpgradeMtn())) {
										deviceCartInfo.setProcessingMTN(rpsRequestVO.getUpgradeMtn());
										deviceCartInfo.setIntendType(CartConstants.EUPBYOD);
									} else {
										deviceCartInfo.setIntendType("BYOD");
									}
									deviceCartInfo.setProcessStep("RPSBYODLandingPage");
									deviceCartInfo.setProcessAction(CartConstants.ADD_DEVICE);
									deviceCartInfo.setClientAppName(CartConstants.VZW_RPS);
									deviceCartInfo.setNumberShareCapable("Y");
									try {
                                        if (null != resp.getServiceBody() && null !=resp.getServiceBody().getServiceResponse()
                                                && null !=resp.getServiceBody().getServiceResponse().getContext()
                                                && null != resp.getServiceBody().getServiceResponse().getContext().getDeviceInfo()){
                                                if (StringUtilities.isEmptyOrNull(resp.getServiceBody().getServiceResponse()
                                                .getContext().getDeviceInfo().getE911AddrInd()) || (!"Y".equalsIgnoreCase(resp.getServiceBody().getServiceResponse()
                                                .getContext().getDeviceInfo().getE911AddrInd()))) {
                                            deviceCartInfo.setENineAddrIndicator(CartConstants.FALSE);
                                        } else {
                                            deviceCartInfo.setENineAddrIndicator("True");
                                        }
                                        }
                                    }catch(Exception ex){
									    logger.info(ex.getMessage());
                                        deviceCartInfo.setENineAddrIndicator("True");
                                    }
									addDeviceUIRequest.setCartInfo(deviceCartInfo);
									AddDeviceData addDeviceData = new AddDeviceData();
									List<Lines> lines = new ArrayList<>();
									Lines line = new Lines();
									Device device = new Device();

									device.setId(resp.getServiceBody().getServiceResponse().getContext().getDeviceInfo()
											.getDeviceSku());
									device.setDeviceId(rpsRequestVO.getDeviceImei());
									device.setContractTerm("MONTH_TO_MONTH");
									device.setByodESimPhone(true);

									if (StringUtilities.isNotEmptyOrNull(deviceCartInfo.getProcessingMTN())) {
										line.setMtn(deviceCartInfo.getProcessingMTN());
									} else {
										line.setMtn("");
									}
									line.setDevice(device);

									line.setIspuFlow(false);
									line.setDepletionType("F");
									line.setIsKeepingExistingEqProtection(true);
									line.setDepletionLocationCode("");

									if (!rpsRequestVO.isStandalone()) {
										deviceCartInfo.setRpsIntent("BYOD-RPS-NS");
										deviceCartInfo.setTriggerPricingValidation(true);
										line.setNumbersharePairingMode("PAIR");
										if (StringUtilities.isNotEmptyOrNull(rpsRequestVO.getTrunkMtn())){
											line.setTrunkMtn(rpsRequestVO.getTrunkMtn());
										} else {
											line.setTrunkMtn(cartCreator);
										}
										if (CartConstants.EUPBYOD.equalsIgnoreCase(deviceCartInfo.getIntendType())
												&& !rpsRequestVO.isUpgradeMtnPaired()) {
											line.setCurrentPairingModeChanged(true);
										}

									} else {
										deviceCartInfo.setRpsIntent("BYOD-RPS-SA");
										deviceCartInfo.setTriggerPricingValidation(true);
										line.setNumbersharePairingMode("STANDALONE");
										if (CartConstants.EUPBYOD.equalsIgnoreCase(deviceCartInfo.getIntendType())
												&& (rpsRequestVO.isUpgradeMtnPaired() || CartConstants.NUMBER_SHARE.equalsIgnoreCase(rpsRequestVO.getOldPairingMode()))) {
											line.setNumbersharePairingMode("UNPAIR");
											line.setCurrentPairingModeChanged(true);
										}
									}

									SoftSKUItem softSKUItem = new SoftSKUItem();

									softSKUItem.setId(resp.getServiceBody().getServiceResponse().getContext()
											.getDeviceInfo().getSimInfo().getPreferredSoftSim());
									softSKUItem.setIccid(resp.getServiceBody().getServiceResponse().getContext()
											.getDeviceInfo().getSimInfo().getIccid());
									softSKUItem.setIsCustomerProvidedSIM(true);
									softSKUItem.setESIM(resp.getServiceBody().getServiceResponse().getContext()
											.getDeviceInfo().getSimInfo().getEID());
                                        if (null != eidUpdateResponse && null != eidUpdateResponse.getData()
                                                && null != eidUpdateResponse.getData().getEsimInfo()) {
                                            if (StringUtilities.isNotEmptyOrNull(eidUpdateResponse.getData().getEsimInfo().getEId())) {
												logger.info("New Eid pupulated to request object: {}", eidUpdateResponse.getData().getEsimInfo().getEId());
												softSKUItem.setESIM(eidUpdateResponse.getData().getEsimInfo().getEId());
											}
                                            if (StringUtilities.isNotEmptyOrNull(eidUpdateResponse.getData().getEsimInfo().getPreferredSoftSim())) {
												logger.info("New PreferredsoftSim pupulated to request object: {}", eidUpdateResponse.getData().getEsimInfo().getPreferredSoftSim());
												softSKUItem.setId(eidUpdateResponse.getData().getEsimInfo().getPreferredSoftSim());
											}
                                        }
                                            line.setSim(softSKUItem);
                                            line.setIspuFlow(false);
                                            line.setDepletionType("F");
                                            line.setDepletionLocationCode("");

                                            if ("BYOD".equalsIgnoreCase(deviceCartInfo.getIntendType())) {

                                                line.setIsNewLine(true);
                                                line.setNewLineOrAAL(true);
                                            }
                                            lines.add(line);

                                            addDeviceData.setLines(lines);
                                            addDeviceUIRequest.setData(addDeviceData);
                                            if (resp.getErrors() != null) {
                                                return Mono.just(ResponseEntity.status(HttpStatus.OK).body(resp));
                                            }
                                            return accDevHelper.addDevice(addDeviceUIRequest,httpResponse).flatMap(addDevicePegaResponse -> {
                                                ErrorResponse errorResponse = null;
                                                CartRedisData rr = new CartRedisData();
                                                if (addDevicePegaResponse.getErrors() != null) {
                                                    errorResponse = CartPegaResponseErrorsUtil
                                                            .handleAddDeviceResponseErrors(addDevicePegaResponse);
                                                    return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                                            .body(errorResponse));
                                                } else {
                                                    if (null != addDevicePegaResponse.getServiceBody() && addDevicePegaResponse
                                                            .getServiceBody().getServiceResponse().getContext() != null) {
                                                    	util.formatRedisData(rr, addDevicePegaResponse, addDeviceUIRequest);
                                                        if (StringUtilities.isNotEmptyOrNull(
                                                                addDeviceUIRequest.getCartInfo().getAccountNumber()))
                                                            rr.setAccountNumber(
                                                                    addDeviceUIRequest.getCartInfo().getAccountNumber());
                                                        if (StringUtilities.isNotEmptyOrNull(
                                                                addDeviceUIRequest.getCartInfo().getCartCreator()))
                                                            rr.setCartCreator(
                                                                    addDeviceUIRequest.getCartInfo().getCartCreator());

                                                        if (rpsRequestVO.isStandalone()) {
                                                            rr.setRpsIntent("BYOD-RPS-SA");

                                                        } else {
                                                            rr.setRpsIntent("BYOD-RPS-NS");
                                                        }
                                                    }
                                                }
                                                RPSFlowRedisData rpsFlowRedisData = new RPSFlowRedisData();
                                                try {
													if (null != resp.getServiceBody() && null !=resp.getServiceBody().getServiceResponse()
															&& null !=resp.getServiceBody().getServiceResponse().getContext()
															&& null != resp.getServiceBody().getServiceResponse().getContext().getDeviceInfo()
													        && null != resp.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getDeviceAttributes()
													        && StringUtilities.isNotEmptyOrNull(resp.getServiceBody().getServiceResponse().getContext()
															.getDeviceInfo().getDeviceAttributes().getMfgName())) {
														rpsFlowRedisData.setRpsOsType(resp.getServiceBody().getServiceResponse().getContext()
																.getDeviceInfo().getDeviceAttributes().getMfgName());
														addDevicePegaResponse.getServiceBody().getServiceResponse().getContext().setRpsDeviceMfg(resp.getServiceBody().getServiceResponse().getContext()
																.getDeviceInfo().getDeviceAttributes().getMfgName());
														rpsFlowRedisData.setRpsDeviceMfg(resp.getServiceBody().getServiceResponse().getContext()
																.getDeviceInfo().getDeviceAttributes().getMfgName());
														addDevicePegaResponse.getServiceBody().getServiceResponse().getContext().setRpsOsType(resp.getServiceBody().getServiceResponse().getContext()
																.getDeviceInfo().getDeviceAttributes().getMfgName());
													}
                                                    rpsFlowRedisData.setRpsUserFlow(StringUtilities.isNotEmptyOrNull(rpsRequestVO.getUpgradeMtn()) ? "Replace Device" : "Add Device");
													addDevicePegaResponse.getServiceBody().getServiceResponse().getContext().setRpsUserFlow(StringUtilities.isNotEmptyOrNull(rpsRequestVO.getUpgradeMtn()) ? "Replace Device" : "Add Device");
													addDevicePegaResponse.getServiceBody().getServiceResponse().getContext().setRpsDeviceFlowType(rpsRequestVO.isStandalone()?"Standalone":"Numbershare");


                                                } catch (Exception ex) {
                                                    logger.info("Exception on populate device info on UI response and redis field ",ex);
                                                    rpsFlowRedisData.setRpsOsType("");
                                                    rpsFlowRedisData.setRpsDeviceMfg("");
                                                    rpsFlowRedisData.setRpsUserFlow("");
                                                }
                                                if (StringUtilities.isNotEmptyOrNull(rpsRequestVO.getPairingMode())) {
                                                    addDevicePegaResponse.getServiceBody().getServiceResponse().getContext()
                                                            .setRpsPairingMode(rpsRequestVO.getPairingMode());
                                                    rpsFlowRedisData.setRpsFlowPairingMode(rpsRequestVO.getPairingMode());

                                                } else {
                                                    addDevicePegaResponse.getServiceBody().getServiceResponse().getContext()
                                                            .setRpsPairingMode(CartConstants.RPS_FLOW_ASSOCIATED_SUBSCRIPTION_TWO
                                                                    .equalsIgnoreCase(rpsData.getCarrierPostData().getAssociatedSubscriprion()) ?
                                                                    CartConstants.RPS_FLOW_STANDALONE : CartConstants.RPS_FLOW_NUMBERSHARE);
                                                }
                                                if (StringUtilities.isNotEmptyOrNull(rpsRequestVO.getDeviceImei())) {
                                                    addDevicePegaResponse.getServiceBody().getServiceResponse().getContext()
                                                            .setRpsDeviceId(rpsRequestVO.getDeviceImei());
                                                    rpsFlowRedisData.setRpsFlowIMEI(rpsRequestVO.getDeviceImei());

                                                } else if (null != rpsData && null != rpsData.getSecondaryDeviceActive() && StringUtilities.isNotEmptyOrNull(rpsData.getSecondaryDeviceActive().getDeviceImei())) {
                                                    addDevicePegaResponse.getServiceBody().getServiceResponse().getContext()
                                                            .setRpsDeviceId(rpsData.getSecondaryDeviceActive().getDeviceImei());
                                                }
                                                if (null != rpsData && null != rpsData.getCarrierPostData() && StringUtilities.isNotEmptyOrNull(rpsData.getCarrierPostData().getPrimaryDeviceMTN())) {
                                                    addDevicePegaResponse.getServiceBody().getServiceResponse().getContext()
                                                            .setRpsPhoneMtn(rpsData.getCarrierPostData().getPrimaryDeviceMTN());
                                                }

                                                return redisHelper2.upsertAddDeviceDataIntoRedis(rr, rpsFlowRedisData).map(data1 -> {
                                                    return ResponseEntity.status(HttpStatus.OK).body(addDevicePegaResponse);
                                                });

                                            });

                                        });
								});

					});
		});

	}

	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return ResponseEntity
	 *
	 */
	@PostMapping("/rpsupdatee911address")
	public Mono<ResponseEntity<GenericResponse>> updateE911Address(ServerHttpRequest httpHeader,
			ServerHttpResponse httpResponse, @Valid @RequestBody RPSE911AddressUpdateUIRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "e911-address");
		logger.debug("E911Address Update Request: {}", request);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleRPSE911AddressUpdateRequestErrors(request);
		if (errors.getErrors() != null)
			return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
		String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
				? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
				: "";
		request.setChannelId(channelId);

		if(CartConstants.CHANNEL_ID_NUMBERLINK.equalsIgnoreCase(channelId)) {

			Mono<InitiateAddressChangePEGAResponse> initiateAddressChangePEGAResponseMono = cartRpsHelper.initiateAddressChange(channelId);

			return initiateAddressChangePEGAResponseMono.flatMap(initiateAddressChangePEGAResponse-> {

				String caseId = "";

				if(initiateAddressChangePEGAResponse!=null && initiateAddressChangePEGAResponse.getServiceBody()!=null &&initiateAddressChangePEGAResponse.getServiceBody().getServiceResponse()!=null && initiateAddressChangePEGAResponse.getServiceBody().getServiceResponse().getContext()!=null && initiateAddressChangePEGAResponse.getServiceBody().getServiceResponse().getContext().getCaseId()!=null)
					caseId = initiateAddressChangePEGAResponse.getServiceBody().getServiceResponse().getContext().getCaseId();
				return cartRpsHelper.updateAddressChange(request,caseId).map(pegaResp-> {
					ErrorResponse errors3 = null;
					if (pegaResp.getErrors() != null && !httpResponse.getStatusCode().is2xxSuccessful()) {
						errors3 = CartPegaResponseErrorsUtil.handleRPSE911AddressUpdateResponseErrors(pegaResp);
					}
					return errors3 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors3)
							: ResponseEntity.status(HttpStatus.OK).body(pegaResp);
				});
			});
		}
		return cartRpsHelper.updateRPSE911Address(request).map(cxpResponse -> {
			ErrorResponse errors2 = null;

			if (cxpResponse.getErrors() != null && !httpResponse.getStatusCode().is2xxSuccessful()) {
				errors2 = CartPegaResponseErrorsUtil.handleRPSE911AddressUpdateResponseErrors(cxpResponse);
			}
			return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
					: ResponseEntity.status(HttpStatus.OK).body(cxpResponse);
		});
	}

	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return response
	 */
	@PostMapping("/rleasePendingOrder")
	public Mono<ResponseEntity<GenericResponse>> releasePendingOrder(ServerHttpRequest httpHeader,
			ServerHttpResponse httpResponse, @Valid @RequestBody RPSReleasePendingOrderUIRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "releasePendingOrder");
		logger.debug("Release PendingOrder Request: {}", request);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleRPSReleasePendingOrderRequestErrors(request);
		if (errors.getErrors() != null)
			return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors));
		return cartRpsHelper.releaseRPSPendingOrder(request).map(cxpResponse -> {
			ErrorResponse errors2 = null;

			if (cxpResponse.getErrors() != null && !httpResponse.getStatusCode().is2xxSuccessful()) {
				errors2 = CartPegaResponseErrorsUtil.handleRPSReleasePendingOrderResponseErrors(cxpResponse);
			}
			return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
					: ResponseEntity.status(HttpStatus.OK).body(cxpResponse);
		});
	}

	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @param request
	 * @return ResponseEntity
	 *
	 */
	@PostMapping("/rpsretrievee911address")
	public Mono<ResponseEntity<GenericResponse>> rpsRetrieveE911address(ServerHttpRequest httpHeader,
			ServerHttpResponse httpResponse, @Valid @RequestBody RPSE911AddressRetrieveUIRequest request) {
		System.setProperty(CartConstants.ENDPOINT, "e911-address");
		logger.debug("E911Address Retrieve Request: {}", request);
		String channelId = httpHeader.getHeaders().containsKey(CartConstants.CHANNEL_ID)
				? httpHeader.getHeaders().getFirst(CartConstants.CHANNEL_ID)
				: "";
		if (CartConstants.CHANNEL_ID_NUMBERLINK.equalsIgnoreCase(channelId)) {
			return cartRpsHelper.updateProspectSessionDataForNumberlink().flatMap((data) -> {
				return cartRpsHelper.retrieveRPSE911Address(request).map(cxpResponse -> {
					ErrorResponse errors2 = null;

					if (cxpResponse.getErrors() != null && !httpResponse.getStatusCode().is2xxSuccessful()) {
						errors2 = CartPegaResponseErrorsUtil.handleRPSE911AddressRetrieveResponseErrors(cxpResponse);
					}
					return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
							: ResponseEntity.status(HttpStatus.OK).body(cxpResponse);
				});
			});
		} else {
			return cartRpsHelper.retrieveRPSE911Address(request).map(cxpResponse -> {
				ErrorResponse errors2 = null;

				if (cxpResponse.getErrors() != null && !httpResponse.getStatusCode().is2xxSuccessful()) {
					errors2 = CartPegaResponseErrorsUtil.handleRPSE911AddressRetrieveResponseErrors(cxpResponse);
				}
				return errors2 != null ? ResponseEntity.status(httpResponse.getStatusCode()).body(errors2)
						: ResponseEntity.status(HttpStatus.OK).body(cxpResponse);
			});
		}
	}

	@PostMapping("/rpsDeviceDetail")
	public Mono<ResponseEntity<RPSApplePayloadUIRequest>> rpsApplePayload(ServerHttpRequest httpHeader,
																		  ServerHttpResponse httpResponse, @Valid @RequestBody RPSApplePayloadUIRequest request,
																		  @RequestParam(required = false) String encryptedPayloadReq) throws UnsupportedEncodingException, SignatureException {
		System.setProperty(CartConstants.ENDPOINT, "rpsApplePayload");
		logger.debug("rpsApplePayload Request: {}", request);


		RPSRedisData rr = cartRpsHelper.formatRPSRedisData(request,"");
		Mono<Boolean> rpsFlowRedisData = redisHelper2.upsertRPSFlowDataIntoRedis(rr);
		return rpsFlowRedisData.flatMap(data -> {
			RPSApplePayloadUIRequest response = validator.sanitizeRPSApplePayloadUIRequest(request);
			if (data) {
				return Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));
			} else {
				return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new RPSApplePayloadUIRequest()));
			}
		});
	}

}
