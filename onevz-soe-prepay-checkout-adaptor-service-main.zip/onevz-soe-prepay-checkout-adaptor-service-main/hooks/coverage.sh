#!/bin/sh

Color_Off='\033[0m' 
BRed="\033[1;31m"         # Red
BGreen="\033[1;32m"       # Green
BYellow="\033[1;33m"      # Yellow
BBlue="\033[1;34m"        # Blue


calc() { awk "BEGIN{print $*}"; }
MSG_FILE=$1
FILE_CONTENT="$(cat $MSG_FILE)"
# Initialize constants here
INPUT=./target/site/jacoco/jacoco.csv
coverageTarget=80
ex="$(date) ### Exception"

#printf "${BGreen}[Pre-Commit] Code Coverage analysis in progress...${Color_Off}\n" 
echo "$(date) [Pre-Commit] Code Coverage analysis in progress...\n"
for fileVal in $(git diff --name-only --cached \*.java); do
stagedFile=${fileVal}
stagedFileName=$(basename "$stagedFile")
# echo $stagedFileArray
# stagedFileName=(${stagedFileArray[-1]})
# echo $stagedFileName
#echo ${stagedFileName}
fileArr=(${stagedFileName//./ })
fileName=${fileArr[0]}

coveragePassed=default

if [[ -f "$INPUT" ]]; then
    echo "$INPUT exists"
else
	echo "FAIL" >> hooks/COVERAGE_STATUS.txt
	git config core.coveragestatus FAIL
	echo "$ex - $INPUT file not found. Please generate the coverage report in local. command: mvn clean verify"
 	exit 1   
fi

OLDIFS=$IFS
IFS=,
[ ! -f $INPUT ] && { echo "$INPUT file not found"; exit 99; }
while read GROUP PACKAGE CLASS INSTRUCTION_MISSED INSTRUCTION_COVERED BRANCH_MISSED BRANCH_COVERED LINE_MISSED LINE_COVERED COMPLEXITY_MISSED
do
	if [[ $CLASS == $fileName ]]; then
		total=$(($BRANCH_COVERED + $BRANCH_MISSED))
		if [[ "$total" -gt "0" ]]; then
		 coveragePercent=$((100*$BRANCH_COVERED/$total))
		 if [[ "$coveragePercent" -gt "$coverageTarget" ]]; then
		   #printf "${BGreen} Code coverage is successful for the file $CLASS and current coverage is $coveragePercent ${Color_Off}\n"
		   echo "Code coverage is successful for the file $CLASS and current coverage is $coveragePercent% \n"
		   coveragePassed=true 
		 else
		   printf "${BRed} Code coverage is less than $coverageTarget percent for the class ${fileName} and the actual value is $coveragePercent percent. ${Color_Off}\n"
		   echo "$ex - Code coverage is less than $coverageTarget% for the class $fileName and the actual value is $coveragePercent%"
		   coveragePassed=false
		   break
		 fi
		 else
		   printf "${BRed} No Unit Testing for the file $CLASS.${Color_Off}\n"
		   echo "$ex - No Unit Testing for the file $CLASS.\n"
		   coveragePassed=false
		   break
		fi
	fi	
done < $INPUT
IFS=$OLDIFS
done

if [[ $coveragePassed == false ]]; then
 echo "$ex - Commit failed due to the above failure(s).\n"
 echo "FAIL" >> hooks/COVERAGE_STATUS.txt 
 git config core.coveragestatus FAIL
 exit 1
 else
 git config core.coveragestatus PASS
 echo "PASS" >> hooks/COVERAGE_STATUS.txt
fi