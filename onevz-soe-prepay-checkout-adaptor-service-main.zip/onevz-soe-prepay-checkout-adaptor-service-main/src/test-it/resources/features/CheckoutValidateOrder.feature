@prepayCheckoutAdaptorService @checkoutValidateOrder
Feature: CheckoutValidateOrder SOE Services
  Description: Test scenarios of CheckoutValidateOrder SOE API services

  Background:
    Given request builder creation for "<APIName>"
    When "SSOJWT" API is called with "SSOJWTPayload" to extract token value

  @checkoutValidateOrderSuccessScenario
  Scenario Outline: CheckoutValidateOrder Positive Test Scenario
    And add required headers along with token header to "<APIName>" request
    And "<APIPayload>" is added to request for "<APIName>"
    When request is sent using "<HTTP_Method>" method to "<APIName>"
    Then validate response status code should be <expectedStatusCode> for "<APIName>"
    And validate "<APIName>" response for "<JSONPath>" with "<expectedValue>"

    Examples:
      | expectedStatusCode | APIName      | HTTP_Method | APIPayload   | JSONPath        | expectedValue         |
      |                200 | checkoutValidateOrder | POST        | checkoutValidateOrder | serviceHeader.statusMsg | SUCCESS |

  @checkoutValidateOrderNegativeScenario
  Scenario Outline: CheckoutValidateOrder '<HTTP_Method>' '<Scenario_Name>' Negative Test Scenario
    And add required headers along with token header to "<APIName>" request without "<Header>"
    When request is sent using "<HTTP_Method>" method to "<APIName>"
    Then validate response status code should be <expectedStatusCode> for "<APIName>"
    And validate response with "<errorStatusMessage>"

    @checkoutValidateOrderInvalidHttpMethod
    Examples:
      | Scenario_Name       | expectedStatusCode |  HTTP_Method | APIName      | errorStatusMessage |
      | Invalid Http Method |                405 |  GET         | checkoutValidateOrder |                    |

    @checkoutValidateOrderCookieHeaderMissing
    Examples:
      | Scenario_Name         | expectedStatusCode |  Header | HTTP_Method | APIName      | errorStatusMessage  |
      | Cookie Header Missing |                401 | Cookie | POST        | checkoutValidateOrder | Invalid Session.Please redirect to logout page  |
