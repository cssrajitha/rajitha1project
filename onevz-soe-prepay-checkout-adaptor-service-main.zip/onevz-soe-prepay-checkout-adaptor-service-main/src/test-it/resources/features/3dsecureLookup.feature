@prepayCheckoutAdaptorService @3dsecureLookup
Feature: 3dsecureLookup SOE Services
  Description: Test scenarios of 3dsecureLookup SOE API services

  Background:
    Given request builder creation for "<APIName>"
    When "SSOJWT" API is called with "SSOJWTPayload" to extract token value

  @3dsecureLookupSuccessScenario
  Scenario Outline: 3dsecureLookup Positive Test Scenario
    And add required headers along with token header to "<APIName>" request
    And "<APIPayload>" is added to request for "<APIName>"
    When request is sent using "<HTTP_Method>" method to "<APIName>"
    Then validate response status code should be <expectedStatusCode> for "<APIName>"

    Examples:
      | expectedStatusCode | APIName      | HTTP_Method | APIPayload   |
      |                200 | Payment3dsecureLookup | POST        | Payment3dsecureLookup |

  @3dsecureLookupNegativeScenario
  Scenario Outline: 3dsecureLookup '<HTTP_Method>' '<Scenario_Name>' Negative Test Scenario
    And add required headers along with token header to "<APIName>" request without "<Header>"
    When request is sent using "<HTTP_Method>" method to "<APIName>"
    Then validate response status code should be <expectedStatusCode> for "<APIName>"
    And validate response with "<errorStatusMessage>"

    @3dsecureLookupInvalidHttpMethod
    Examples:
      | Scenario_Name       | expectedStatusCode |  HTTP_Method | APIName      | errorStatusMessage |
      | Invalid Http Method |                405 |  GET         | Payment3dsecureLookup |                    |

    @3dsecureLookupCookieHeaderMissing
    Examples:
      | Scenario_Name         | expectedStatusCode |  Header | HTTP_Method | APIName      | errorStatusMessage  |
      | Cookie Header Missing |                401 |  Cookie | POST        | Payment3dsecureLookup | Invalid Session.Please redirect to logout page |
