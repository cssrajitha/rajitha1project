@prepayCheckoutAdaptorService @addRefillCard
Feature: addRefillCard SOE Services
  Description: Test scenarios of addRefillCard SOE API services

  Background:
    Given request builder creation for "<APIName>"
    When "SSOJWT" API is called with "SSOJWTPayload" to extract token value

  @addRefillCardSuccessScenario
  Scenario Outline: addRefillCard Positive Test Scenario
    And add required headers along with token header to "<APIName>" request
    And "<APIPayload>" is added to request for "<APIName>"
    When request is sent using "<HTTP_Method>" method to "<APIName>"
    Then validate response status code should be <expectedStatusCode> for "<APIName>"

    Examples:
      | expectedStatusCode | APIName      | HTTP_Method | APIPayload   |
      |                200 | addRefillCard | POST        | addRefillCard |

  @addRefillCardNegativeScenario
  Scenario Outline: addRefillCard '<HTTP_Method>' '<Scenario_Name>' Negative Test Scenario
    And add required headers along with token header to "<APIName>" request without "<Header>"
    When request is sent using "<HTTP_Method>" method to "<APIName>"
    Then validate response status code should be <expectedStatusCode> for "<APIName>"
    And validate response with "<errorStatusMessage>"

    @addRefillCardInvalidHttpMethod
    Examples:
      | Scenario_Name       | expectedStatusCode |  HTTP_Method | APIName      | errorStatusMessage |
      | Invalid Http Method |                405 |  GET         | addRefillCard |                    |

    @addRefillCardCookieHeaderMissing
    Examples:
      | Scenario_Name         | expectedStatusCode |  Header | HTTP_Method | APIName      | errorStatusMessage  |
      | Cookie Header Missing |                401 | Cookie | POST        | addRefillCard | Invalid Session.Please redirect to logout page |
