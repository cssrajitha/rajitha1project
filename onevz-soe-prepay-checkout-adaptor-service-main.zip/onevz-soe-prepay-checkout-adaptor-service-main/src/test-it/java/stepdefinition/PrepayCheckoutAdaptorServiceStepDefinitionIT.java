package stepdefinition;

import com.apiautomation.stepdefinitions.APIStepDefinitions;
import onevz.soe.prepay.adaptor.checkout.PrepayAdaptorCheckoutBootstrap;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.spring.CucumberContextConfiguration;
import onevz.soe.prepay.adaptor.checkout.apiconfig.CucumberConfigTestIT;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import io.cucumber.java.After;
import io.cucumber.java.Scenario;
import java.io.IOException;
import java.util.Map;
import io.cucumber.java.Before;

@CucumberContextConfiguration
//@SpringBootTest(classes = CucumberConfigTestIT.class)
@SpringBootTest(classes = {PrepayAdaptorCheckoutBootstrap.class}, webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)
public class PrepayCheckoutAdaptorServiceStepDefinitionIT {

    @Autowired
    public APIStepDefinitions apiStepDefinitions;

@Before
    public static void beforeScenario(Scenario scenario) {
        APIStepDefinitions.beforeScenario(scenario);
    }

    @After
    public static void afterScenario(Scenario scenario) {
        APIStepDefinitions.afterScenario(scenario);
    }

    // Building request
    @Given("request builder creation for {string}")
    public void request_builder_creation(String apiName) throws IOException {
        apiStepDefinitions.request_builder_creation(apiName);
    }

    // Adding headers without token header
    @Given("add headers to {string} request")
    public void add_headers_to_request(String apiName) {
        apiStepDefinitions.add_headers_to_request(apiName);
    }

    // removing specific headers from required header list without token header
    @Given("add headers to {string} request without {string}")
    public void add_headers_to_request_without_header(String apiName, String headerName) {
        apiStepDefinitions.add_headers_to_request_without_header(apiName, headerName);
    }

    // Adding headers with sso_jwt token
    @Then("add required headers along with token header to {string} request")
    public void add_required_headers_along_with_token_header_to_request(String apiName) {
        apiStepDefinitions.add_required_headers_along_with_token_header_to_request(apiName);
    }

    // removing header and adding remaining headers with token header
    @Then("add required headers along with token header to {string} request without {string}")
    public void add_required_headers_along_with_token_header_to_request_without(String apiName, String headerName) {
        apiStepDefinitions.add_required_headers_along_with_token_header_to_request_without(apiName, headerName);
    }

    @Given("{string} is added to request")
    public void is_added_to_request(String payloadFilePath)
            throws IOException, ProcessingException, InterruptedException {
        apiStepDefinitions.is_added_to_request(payloadFilePath);
    }

    // Adding request also generating schema
    @Given("{string} is added to request for {string}")
    public void is_added_to_request(String payloadFilePath, String apiName)
            throws IOException, ProcessingException, InterruptedException {
        apiStepDefinitions.is_added_to_request(payloadFilePath,apiName);
    }

    // Adding request and replacing value of a key from request
    @Given("{string} is modified with {string} on {string}")
    public void payload_modified_with_newValue(String payloadFilePath, String newValue, String jsonPath)
            throws IOException, InterruptedException, ProcessingException {
        apiStepDefinitions.payload_modified_with_newValue(payloadFilePath,newValue,jsonPath);
    }

    // Adding xml request
    @Given("XML {string} is added to request")
    public void xml_is_added_to_request(String payloadFilePath)
            throws IOException, ProcessingException, InterruptedException {
        apiStepDefinitions.xml_is_added_to_request(payloadFilePath);
    }

    // Adding xml request and replacing value of a key from request
    @Given("XML {string} is modified with {string} on {string}")
    public void xml_is_modified_with_on(String payloadFilePath, String newValue, String xmlPath) throws IOException {
        apiStepDefinitions.xml_is_modified_with_on(payloadFilePath,newValue,xmlPath);
    }

    // Adding query params for get http method
    @Given("add query params to request")
    public void add_query_params_to_request(Map<String, String> queryParams) {
        apiStepDefinitions.add_query_params_to_request(queryParams);
    }

    // Adding query params
    @Given("add query params {string} {string} for {string}")
    public void add_query_params_to_request_without_queryParams(String queryParamKey, String queryParamValue,String apiName) {
        apiStepDefinitions.add_query_params_to_request_without_queryParams(queryParamKey, queryParamValue, apiName);
    }

    // adding request for graphql API
    @When("{string} is added to request for graphql {string} API")
    public void is_added_to_request_for_graphql_api(String payloadFilePath, String apiName)
            throws IOException, ProcessingException, InterruptedException {
        apiStepDefinitions.is_added_to_request_for_graphql_api(payloadFilePath, apiName);
    }

    // Calling GET http method
    @When("request is sent using GET method to {string}")
    public void request_is_sent_using_get_method_to(String resource) {
        apiStepDefinitions.request_is_sent_using_get_method_to(resource);
    }

    // Calling http method other than GET
    @When("request is sent using {string} method to {string}")
    public void request_is_sent_using_http_method_to(String http_method, String resource) {
        apiStepDefinitions.request_is_sent_using_http_method_to(http_method, resource);

    }

    // Calling http method other than GET without resource in http method
    @When("request is sent using {string} method")
    public void request_is_sent_using_http_method_to(String http_method) throws JsonProcessingException {
        apiStepDefinitions.request_is_sent_using_http_method_to(http_method);
    }

    // Updating payload
    @When("update the {string} with {string}")
    public void update_payload(String payloadFilePath, String newValue, String jsonPath)
            throws IOException {
        apiStepDefinitions.update_payload(payloadFilePath, newValue, jsonPath);
    }

    // Validation of response code, error message, responsejsonpath
    @Then("validate response status code should be {int} for {string}")
    public void validate_response_status_code_should_be(Integer expectedStatusCode, String apiName) {
        apiStepDefinitions.validate_response_status_code_should_be(expectedStatusCode, apiName);
    }

    @Then("validate {string} response for {string} with {string}")
    public void validate_response_with_expected(String apiName, String jsonPath, String expectedValue)
            throws IOException, InterruptedException {
        apiStepDefinitions.validate_response_with_expected(apiName, jsonPath, expectedValue);
    }

    @Then("validate response with {string}")
    public void validate_response_with_expected(String errorStatusMessage) throws IOException {
        apiStepDefinitions.validate_response_with_expected(errorStatusMessage);
    }

    @Then("validate {string} xml response for {string} with {string}")
    public void validate_xml_response_for_with(String apiName, String xmlPath, String expectedValue) {
        apiStepDefinitions.validate_xml_response_for_with(apiName, xmlPath, expectedValue);
    }

    @Then("extract {string} values from response")
    public void extract_values_from_response(String key) {
        apiStepDefinitions.extract_values_from_response(key);
    }

    @Then("validate response status code should be {int}")
    public void validate_response_status_code_should_be(Integer expectedStatusCode) {
        apiStepDefinitions.validate_response_status_code_should_be(expectedStatusCode);
    }

    @Given("update the {string} with data fetched on {string}")
    public void update_payload(String payloadFilePath, String jsonPath) throws IOException {
        apiStepDefinitions.update_payload(payloadFilePath, jsonPath);
    }

    // Calling SSO_JWT API and extracting token value
    @When("{string} API is called with {string} to extract token value")
    public void api_is_called_with_to_extract_token_value(String resource, String payloadFilePath) throws IOException {
        apiStepDefinitions.api_is_called_with_to_extract_token_value(resource, payloadFilePath);
    }

    @When("request is sent using {string} method to {string} request")
    public void request_is_sent_using_https_method_to_service(String resource, String apiEndPointName) throws IOException {
        apiStepDefinitions.request_is_sent_using_http_method_to_service(resource, apiEndPointName);
    }
    @And("add required {string} to {string}")
    public void add_required_headers(String headerfilePath,String apiName) throws IOException {
        apiStepDefinitions.add_required_headers_to_the_request(headerfilePath,apiName);
    }

    @And("add required {string} along with token header to {string} request")
    public void add_required_headers_along_with_token_header_to_request(String headersFilePath, String apiName)
            throws IOException {
        apiStepDefinitions.add_required_headers_along_with_token_header_to_request(headersFilePath,apiName);
    }

    @Then("add required {string} along with token header to {string} request without {string}")
    public void add_required_headers_along_with_token_header_to_request_without_header(String headersContent,
    String apiName, String headerName) throws IOException {
        apiStepDefinitions.add_required_headers_along_with_token_header_to_request_without_header(headersContent,apiName,headerName);
    }

}
