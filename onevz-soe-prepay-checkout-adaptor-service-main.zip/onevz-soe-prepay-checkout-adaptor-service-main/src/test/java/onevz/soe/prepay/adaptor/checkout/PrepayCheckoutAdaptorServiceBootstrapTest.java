package onevz.soe.prepay.adaptor.checkout;

import onevz.soe.prepay.adaptor.checkout.config.PrepayCheckoutAdaptorServiceTestConfig;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { PrepayCheckoutAdaptorServiceTestConfig.class })
@WebFluxTest(PrepayAdaptorCheckoutBootstrap.class)
public class PrepayCheckoutAdaptorServiceBootstrapTest {

	@Test
	public void test() {
		String[] args = new String[2];
		args[0] = "Test";
		args[1] = "Run";
		PrepayAdaptorCheckoutBootstrap.main(args);
		StepVerifier.create(Mono.just("")).assertNext(d -> Assert.assertNotNull(d));
	}

}