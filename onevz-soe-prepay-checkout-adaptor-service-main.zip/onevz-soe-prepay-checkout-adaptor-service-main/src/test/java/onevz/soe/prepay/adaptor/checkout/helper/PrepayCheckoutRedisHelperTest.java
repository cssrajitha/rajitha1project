package onevz.soe.prepay.adaptor.checkout.helper;

import com.fasterxml.jackson.databind.ObjectMapper;
import net.jcip.annotations.NotThreadSafe;
import onevz.soe.session.bean.SOELoginSessionBean;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.util.Map;

import static onevz.soe.prepay.adaptor.checkout.constants.PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
@NotThreadSafe
@RunWith(SpringJUnit4ClassRunner.class)
@WebFluxTest
public class PrepayCheckoutRedisHelperTest {

    @Autowired
    private ObjectMapper mapper;

    @MockBean
    SOELoginSessionBean sessionBean;

    @Autowired
    private PrepayCheckoutRedisHelper prepayCheckoutRedisHelper;

    private String orderWriteHelperMock = "/adaptor/helper/";

    @Test
    public void upsertDataIntoRedisAsStrTest() throws IOException {
       String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"27513\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"SMG996UZVV\",\"deviceId\":\"dev15400037\",\"deviceSkuId\":\"sku4420079\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":30,\"productId\":\"dev15400037\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}]}}";
        String str="prepay_odRequestData";
        Object request = mapper.readValue(requestString, Object.class);
        Mono<Boolean> responseMono = Mono.just(true);
        when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
        Mono<Boolean> actual = prepayCheckoutRedisHelper.upsertDataIntoRedisAsStr(str,request);
        StepVerifier.create(actual).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void getDataFromRedisAsStringTest() {
        String str="{\"ecommSessionId\":\"1kjhlkliueijrlwkjelrjwl88lijeljrlkwjel\",\"curr_line\":1,\"lines\":[{\"mtn\":\"newLine1\",\"lineItemId\":\"newLine1\",\"deviceId\":\"dev16720145\",\"deviceSkuId\":\"sku4750108\",\"deviceSorId\":\"MLA73LL/A\",\"completedProcessSteps\":[\"GridWallPDP\"]}],\"pcsrfToken\":\"3iqjhlwekjqlwjelqkwjelqhwekuhwqijlwk\",\"paypalPaRes\":\"4512154\",\"paypalMD\":\"21654\"})";
        when(this.sessionBean.getSessionData(Mockito.anyString(),Mockito.any())).thenReturn(Mono.just(str));
        Mono<String> redisDataString =  prepayCheckoutRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA);
        StepVerifier.create(redisDataString).assertNext(junit.framework.Assert::assertNotNull).expectComplete().verify();
    }
    @Test
    public void handleRedisDataTest() {
        String requestString = "{\"ecommSessionId\":\"1kjhlkliueijrlwkjelrjwl88lijeljrlkwjel\",\"curr_line\":1,\"lines\":[{\"mtn\":\"newLine1\",\"lineItemId\":\"newLine1\",\"deviceId\":\"dev16720145\",\"deviceSkuId\":\"sku4750108\",\"deviceSorId\":\"MLA73LL/A\",\"completedProcessSteps\":[\"GridWallPDP\"]}],\"pcsrfToken\":\"3iqjhlwekjqlwjelqkwjelqhwekuhwqijlwk\",\"paypalPaRes\":\"4512154\",\"paypalMD\":\"21654\"})";;
        Mono<Boolean> responseMono = Mono.just(true);
        when(sessionBean.setSessionData(Mockito.any(), Mockito.any())).thenReturn(responseMono);
        Map<String,String> actual = prepayCheckoutRedisHelper.handleRedisData(requestString);
        StepVerifier.create(Mono.just(actual)).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void handleRedisData_emptyPcrfTokenTest() {
        String requestString = "{\"ecommSessionId\":\"1kjhlkliueijrlwkjelrjwl88lijeljrlkwjel\",\"curr_line\":1,\"lines\":[{\"mtn\":\"newLine1\",\"lineItemId\":\"newLine1\",\"deviceId\":\"dev16720145\",\"deviceSkuId\":\"sku4750108\",\"deviceSorId\":\"MLA73LL/A\",\"completedProcessSteps\":[\"GridWallPDP\"]}],\"paypalPaRes\":\"4512154\",\"paypalMD\":\"21654\"}";
        Mono<Boolean> responseMono = Mono.just(true);
        when(sessionBean.setSessionData(Mockito.any(), Mockito.any())).thenReturn(responseMono);
        Map<String,String> actual = prepayCheckoutRedisHelper.handleRedisData(requestString);
        StepVerifier.create(Mono.just(actual)).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void handleRedisData_emptyPaypalResTest() {
        String requestString = "{\"ecommSessionId\":\"1kjhlkliueijrlwkjelrjwl88lijeljrlkwjel\",\"curr_line\":1,\"lines\":[{\"mtn\":\"newLine1\",\"lineItemId\":\"newLine1\",\"deviceId\":\"dev16720145\",\"deviceSkuId\":\"sku4750108\",\"deviceSorId\":\"MLA73LL/A\",\"completedProcessSteps\":[\"GridWallPDP\"]}],\"pcsrfToken\":\"3iqjhlwekjqlwjelqkwjelqhwekuhwqijlwk\",\"paypalPaRes\":\"\",\"paypalMD\":\"\"}";
        Mono<Boolean> responseMono = Mono.just(true);
        when(sessionBean.setSessionData(Mockito.any(), Mockito.any())).thenReturn(responseMono);
        Map<String,String> actual = prepayCheckoutRedisHelper.handleRedisData(requestString);
        StepVerifier.create(Mono.just(actual)).assertNext(map -> Assert.assertFalse(map.containsKey("PaRes"))).expectComplete().verify();
    }

    @Test
    public void handleRedisData_emptyPaypalMDTest() {
        String requestString = "{\"ecommSessionId\":\"1kjhlkliueijrlwkjelrjwl88lijeljrlkwjel\",\"curr_line\":1,\"lines\":[],\"pcsrfToken\":\"3iqjhlwekjqlwjelqkwjelqhwekuhwqijlwk\",\"paypalPaRes\":\"123456\",\"paypalMD\":\"\"}";
        Mono<Boolean> responseMono = Mono.just(true);
        when(sessionBean.setSessionData(Mockito.any(), Mockito.any())).thenReturn(responseMono);
        Map<String,String> actual = prepayCheckoutRedisHelper.handleRedisData(requestString);
        StepVerifier.create(Mono.just(actual)).assertNext(map -> Assert.assertFalse(map.containsKey("MD"))).expectComplete().verify();
    }

    @Test
    public void handleRedisData_exceptionTest() {
        String requestString = "{\"ecommSessionId\":\"1kjhlkliueijrlwkjelrjwl88lijeljrlkwjel\",\"curr_line\":1,\"lines\":[,\"pcsrfToken\":\"3iqjhlwekjqlwjelqkwjelqhwekuhwqijlwk\",\"paypalPaRes\":\"123456\",\"paypalMD\":\"\"}";
        Mono<Boolean> responseMono = Mono.just(true);
        when(sessionBean.setSessionData(Mockito.any(), Mockito.any())).thenReturn(responseMono);
        Map<String,String> actual = prepayCheckoutRedisHelper.handleRedisData(requestString);
        StepVerifier.create(Mono.just(actual)).assertNext(map -> Assert.assertTrue(map.isEmpty())).expectComplete().verify();
    }

    @Test
    public void handleRedisDataTestTwo() {
        String requestString = "{\"curr_line\":1,\"lines\":[{\"mtn\":\"newLine1\",\"lineItemId\":\"newLine1\",\"deviceId\":\"dev16720145\",\"deviceSkuId\":\"sku4750108\",\"deviceSorId\":\"MLA73LL/A\",\"completedProcessSteps\":[\"GridWallPDP\"]}],\"pcsrfToken\":\"3iqjhlwekjqlwjelqkwjelqhwekuhwqijlwk\",\"paypalPaRes\":\"4512154\",\"paypalMD\":\"21654\"})";;
        Mono<Boolean> responseMono = Mono.just(true);
        when(sessionBean.setSessionData(Mockito.any(), Mockito.any())).thenReturn(responseMono);
        Map<String,String> actual = prepayCheckoutRedisHelper.handleRedisData(requestString);
        StepVerifier.create(Mono.just(actual)).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void convertObjectToStringTest() {
        Object mockItem = mock(Object.class);
        when(mockItem.toString()).thenReturn(mockItem.getClass().getName());
        String actual = ReflectionTestUtils.invokeMethod(prepayCheckoutRedisHelper, "convertObjectToString", mockItem);
        Assert.assertEquals("{}", actual);
    }

}