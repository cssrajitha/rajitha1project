package onevz.soe.prepay.adaptor.checkout.exceptions;

import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.responses.AddZipcodeRedisData;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.ui.requests.RPSApplePayloadUIRequest;
import onevz.soe.prepay.adaptor.checkout.config.PrepayCheckoutAdaptorServiceTestConfig;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {PrepayCheckoutAdaptorServiceTestConfig.class})
@WebFluxTest(JsonValidator.class)
public class JsonValidatorTest {

    @Autowired
    private JsonValidator validator;

    @Test
    public void convertObjectToString_Test() {
        String actual = validator.convertObjectToString(new Object());
        Assert.assertNotNull(actual);
    }

    @Test
    public void convertObjectToString_exceptionTest() {
        Object mockItem = mock(Object.class);
        when(mockItem.toString()).thenReturn(mockItem.getClass().getName());
        String actual = validator.convertObjectToString(mockItem);
        Assert.assertNotNull(actual);
    }

    @Test
    public void convertObjectToString_Test2() {
        ErrorResponse  errorResponse = new ErrorResponse();
        List<CartError> list = new ArrayList<>();
        CartError cartError = new CartError();
        cartError.setErrorCode("05");
        list.add(cartError);
        errorResponse.setErrors(list);
        ErrorResponse actual = validator.convertObjectToString(errorResponse);
        Assert.assertNotNull(actual);
    }

    @Test
    public void convertObjectToString_exceptionTest2() {
        ErrorResponse mockItem = mock(ErrorResponse.class);
        when(mockItem.toString()).thenReturn(mockItem.getClass().getName());
        ErrorResponse actual = validator.convertObjectToString(mockItem);
        Assert.assertNotNull(actual);
    }

    @Test
    public void convertObjectToString_Test3() {
        AddZipcodeRedisData actual = validator.convertObjectToString(new AddZipcodeRedisData());
        Assert.assertNotNull(actual);
    }

    @Test
    public void convertObjectToString_exceptionTest3() {
        AddZipcodeRedisData mockItem = mock(AddZipcodeRedisData.class);
        when(mockItem.toString()).thenReturn(mockItem.getClass().getName());
        AddZipcodeRedisData actual = validator.convertObjectToString(mockItem);
        Assert.assertNotNull(actual);
    }

    @Test
    public void convertRPSStringToObjectTest() {
        RPSApplePayloadUIRequest actual = validator.convertRPSStringToObject("{\"encryptedPayload\" : \"xxxyyy\", \"nsaFlow\" : true}");
        Assert.assertTrue(actual.isNsaFlow());
    }

}