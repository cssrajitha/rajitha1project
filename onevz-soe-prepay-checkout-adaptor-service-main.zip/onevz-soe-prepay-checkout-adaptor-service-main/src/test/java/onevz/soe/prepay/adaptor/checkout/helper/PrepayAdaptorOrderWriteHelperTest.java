package onevz.soe.prepay.adaptor.checkout.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.model.initiateCheckout.OrderWrite;
import onevz.soe.cart.model.initiateCheckout.OrderWriteContext;
import onevz.soe.cart.model.initiateCheckout.OrderWriteRequest;
import onevz.soe.cart.model.initiateCheckout.OrderWriteResponse;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.constants.SOEConstants;
import onevz.soe.od.model.AddressVO;
import onevz.soe.od.model.VZWPrepayOrderSubmitResponse;
import onevz.soe.od.model.VZWPrepayOrderVO;
import onevz.soe.prepay.adaptor.checkout.config.PrepayCheckoutAdaptorServiceTestConfig;
import onevz.soe.prepay.adaptor.checkout.constants.PrepayAdaptorCheckoutConstants;
import onevz.soe.prepay.adaptor.checkout.model.payment.request.ConfirmSubmit3DCXPRequest;
import onevz.soe.prepay.adaptor.checkout.model.payment.request.ValidateCardCXPRequest;
import onevz.soe.prepay.adaptor.checkout.model.payment.response.ConfirmSubmit3DCXPResponse;
import onevz.soe.prepay.adaptor.checkout.model.payment.response.SubmitConfirmationResponse;
import onevz.soe.prepay.adaptor.checkout.model.payment.response.ValidateCardPaymentCXPResponse;
import onevz.soe.prepay.adaptor.checkout.model.paypal.request.CMPILookupCXPRequest;
import onevz.soe.prepay.adaptor.checkout.model.paypal.request.PreauthDigitalPayCXPRequest;
import onevz.soe.prepay.adaptor.checkout.model.paypal.response.CMPILookupCXPResponse;
import onevz.soe.prepay.adaptor.checkout.model.paypal.response.PreauthDigitalPayCXPResponse;
import onevz.soe.prepay.adaptor.checkout.util.FileReaderUtil;
import onevz.soe.prepay.payment.request.cxp.ProcessApplePaySessionCxpRequest;
import onevz.soe.prepay.payment.response.cxp.GetApplePaySessionCXPResponse;
import onevz.soe.prepay.payment.response.cxp.ProcessApplePaySessionCXPResponse;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import onevz.soe.wsclient.prepay.webclient.model.PrepaidAdaptorWebClientRequest;
import org.apache.hc.core5.http.ContentType;
import org.junit.Assert;
import org.junit.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {PrepayCheckoutAdaptorServiceTestConfig.class})
@WebFluxTest(PrepayAdaptorOrderWriteHelper.class)
public class PrepayAdaptorOrderWriteHelperTest {

    @Autowired
    private ObjectMapper mapper;

    @Autowired
    private PrepayAdaptorOrderWriteHelper prepayAdaptorOrderWriteHelper;

    @MockBean
    private PrepayCheckoutRedisHelper prepayCheckoutRedisHelper;

    @MockBean
    private PrepayAdaptorWebClient prepayAdaptorWebClient;

    @Value("${onevz.soe.prepay.checkout.test.mock}")
    private String mockDataLocation;

    private String orderWriteHelperMock = "/adaptor/helper/";

    @Test
    public void orderWriteTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/helper/orderWriteRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/adaptor/helper/orderWriteResponse.json");
        String responseSession = FileReaderUtil.readFromFile("data/adaptor/helper/responseSession.json");
        String str = "prepay_odRequestData";
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        OrderWriteRequest request = mapper.readValue(requestString, OrderWriteRequest.class);
        request.getOrderWriteServiceBody().getOrderWriteServiceRequest().getOrderWriteContext().getEnforceData().getDeviceFingerPrint().getHttpRequestHeaders().setOrderLanguage("English");
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<String> getDataResponse = Mono.just(str);
        Map<String, String> requestData = new HashMap<>();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseSession));
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(Mono.just(responseString));
        when(prepayCheckoutRedisHelper.handleRedisData(Mockito.any())).thenReturn(requestData);
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        Mono<ResponseEntity<OrderWriteResponse>> responseMono = prepayAdaptorOrderWriteHelper.orderWrite(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> org.junit.Assert.assertNotNull(d));
    }
    @Test
    public void orderWriteErrorCode400Test() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/helper/orderWriteRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/adaptor/helper/orderWriteResponse.json");
        String responseSession = FileReaderUtil.readFromFile("data/adaptor/helper/orderWriteErrorResponse.json");
        String str = "prepay_odRequestData";
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        OrderWriteRequest request = mapper.readValue(requestString, OrderWriteRequest.class);
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<String> getDataResponse = Mono.just(str);
        Map<String, String> requestData = new HashMap<>();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseSession));
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(Mono.just(responseString));
        when(prepayCheckoutRedisHelper.handleRedisData(Mockito.any())).thenReturn(requestData);
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        Mono<ResponseEntity<OrderWriteResponse>> responseMono = prepayAdaptorOrderWriteHelper.orderWrite(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> org.junit.Assert.assertNotNull(d));
    }

    @Test
    public void orderWriteErrorCode500Test() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/helper/orderWriteRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/adaptor/helper/orderWriteResponse.json");
        String responseSession = FileReaderUtil.readFromFile("data/adaptor/helper/orderWriteErrorResponse500.json");
        String str = "prepay_odRequestData";
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        OrderWriteRequest request = mapper.readValue(requestString, OrderWriteRequest.class);
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<String> getDataResponse = Mono.just(str);
        Map<String, String> requestData = new HashMap<>();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseSession));
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(Mono.just(responseString));
        when(prepayCheckoutRedisHelper.handleRedisData(Mockito.any())).thenReturn(requestData);
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        Mono<ResponseEntity<OrderWriteResponse>> responseMono = prepayAdaptorOrderWriteHelper.orderWrite(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> org.junit.Assert.assertNotNull(d));
    }

    @Test
    public void orderWriteifblockTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/helper/orderWriteRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/adaptor/helper/orderWriteResponse.json");
        String responseSession = FileReaderUtil.readFromFile("data/adaptor/helper/payloadNull.json");
        String str = "prepay_odRequestData";
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        OrderWriteRequest request = mapper.readValue(requestString, OrderWriteRequest.class);
        request.getOrderWriteServiceBody().getOrderWriteServiceRequest().getOrderWriteContext().getEnforceData().getDeviceFingerPrint().getHttpRequestHeaders().setOrderLanguage("Spanish");
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<String> getDataResponse = Mono.just(str);
        Map<String, String> requestData = new HashMap<>();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseSession));
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(Mono.just(responseString));
        when(prepayCheckoutRedisHelper.handleRedisData(Mockito.any())).thenReturn(requestData);
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        Mono<ResponseEntity<OrderWriteResponse>> responseMono = prepayAdaptorOrderWriteHelper.orderWrite(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> org.junit.Assert.assertNotNull(d));
    }

    @Test
    public void orderWritegetStatusCodeNullTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/helper/orderWriteRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/adaptor/helper/orderWriteResponse.json");
        String responseSession = FileReaderUtil.readFromFile("data/adaptor/helper/responseSession.json");
        String str = "prepay_odRequestData";
        OrderWriteRequest request = mapper.readValue(requestString, OrderWriteRequest.class);
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<String> getDataResponse = Mono.just(str);
        Map<String, String> requestData = new HashMap<>();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(responseSession));
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(Mono.just(responseString));
        when(prepayCheckoutRedisHelper.handleRedisData(Mockito.any())).thenReturn(requestData);
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        Mono<ResponseEntity<OrderWriteResponse>> responseMono = prepayAdaptorOrderWriteHelper.orderWrite(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> org.junit.Assert.assertNotNull(d));
    }

    @Test
    public void orderWriteRedisNullTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/helper/orderWriteRequest.json");
        String responseString = "";
        OrderWriteRequest request = mapper.readValue(requestString, OrderWriteRequest.class);
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(Mono.just(responseString));
        Mono<ResponseEntity<OrderWriteResponse>> responseMono = prepayAdaptorOrderWriteHelper.orderWrite(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> org.junit.Assert.assertNotNull(d));
    }

    @Test
    public void orderWrite_emptySafeTechDataTest() {
        Mono<String> getDataResponse = Mono.just("prepay_odRequestData");
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(eq(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA))).thenReturn(getDataResponse);
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(eq(PrepayAdaptorCheckoutConstants.PREPAY_SAFETECH_SESSION_ID))).thenReturn(Mono.just(""));
        Mono<ResponseEntity<OrderWriteResponse>> actual = prepayAdaptorOrderWriteHelper.orderWrite(null, null);
        StepVerifier.create(actual).assertNext(resp -> Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), resp.getStatusCodeValue())).expectComplete().verify();
    }

    @Test
    public void orderWrite_errorStatusCodeTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/helper/orderWriteRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/adaptor/helper/orderWriteResponse.json");
        String responseSession = FileReaderUtil.readFromFile("data/adaptor/helper/responseSession.json");
        VZWPrepayOrderSubmitResponse submitOrderResponse = mapper.readValue(responseSession, VZWPrepayOrderSubmitResponse.class);
        submitOrderResponse.setErrors(null);
        submitOrderResponse.getPayload().getPageData().setOrderSubmitted(false);
        responseSession = mapper.writeValueAsString(submitOrderResponse);
        String str = "prepay_odRequestData";
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        OrderWriteRequest request = mapper.readValue(requestString, OrderWriteRequest.class);
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url)
                .header("e2eRequestId", "123-fdsfd-erw2fd-32")
                .header(PrepayAdaptorCheckoutConstants.PREPAY_DIGITAL_IG_SESSION, "sample-session-id").build();
        Mono<String> getDataResponse = Mono.just(str);
        Map<String, String> requestData = new HashMap<>();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseSession));
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(Mono.just(responseString));
        when(prepayCheckoutRedisHelper.handleRedisData(Mockito.any())).thenReturn(requestData);
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        Mono<ResponseEntity<OrderWriteResponse>> actual = prepayAdaptorOrderWriteHelper.orderWrite(httpRequest, request);
        StepVerifier.create(actual).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void orderWrite_exceptionTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/helper/orderWriteRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/adaptor/helper/orderWriteResponse.json");
        String responseSession = FileReaderUtil.readFromFile("data/adaptor/helper/responseSession.json");
        responseSession = responseSession.replace("}", "");
        String str = "prepay_odRequestData";
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        OrderWriteRequest request = mapper.readValue(requestString, OrderWriteRequest.class);
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<String> getDataResponse = Mono.just(str);
        Map<String, String> requestData = new HashMap<>();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseSession));
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(Mono.just(responseString));
        when(prepayCheckoutRedisHelper.handleRedisData(Mockito.any())).thenReturn(requestData);
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        Mono<ResponseEntity<OrderWriteResponse>> actual = prepayAdaptorOrderWriteHelper.orderWrite(httpHeader, request);
        StepVerifier.create(actual).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void setPrepaidLegacyServiceHeaders_reqNullTest() throws IOException {
        PrepaidAdaptorWebClientRequest webClientRequest = new PrepaidAdaptorWebClientRequest();
        String orderWriteRequestStr = FileReaderUtil.readFromFile("data/adaptor/helper/orderWriteRequest.json");
        OrderWriteRequest orderWriteRequest = mapper.readValue(orderWriteRequestStr, OrderWriteRequest.class);
        Map<String, String> headerParams = new HashMap<>();
        webClientRequest = ReflectionTestUtils.invokeMethod(prepayAdaptorOrderWriteHelper, "setPrepaidLegacyServiceHeaders",
                headerParams, SOEConstants.EMPTY_STRING, webClientRequest, null,orderWriteRequest);
        Assert.assertNull(webClientRequest.getHeader().get(PrepayAdaptorCheckoutConstants.PREPAY_E2E_REQUEST_ID));
    }

    @Test
    public void getOrderWritePEGAResponseTest() throws IOException {
        String orderWriteRequestStr = FileReaderUtil.readFromFile("data/adaptor/helper/orderWriteRequest.json");
        String responseSession = FileReaderUtil.readFromFile("data/adaptor/helper/responseSession.json");
        OrderWriteRequest orderWriteRequest = mapper.readValue(orderWriteRequestStr, OrderWriteRequest.class);
        VZWPrepayOrderSubmitResponse submitOrderResponse = mapper.readValue(responseSession, VZWPrepayOrderSubmitResponse.class);
        submitOrderResponse.getPayload().getPageData().setOrderSubmitted(true);
        submitOrderResponse.getPayload().getPageData().setSuccess(false);
        OrderWriteResponse orderWriteResponse = ReflectionTestUtils.invokeMethod(prepayAdaptorOrderWriteHelper, "getOrderWritePEGAResponse",
                submitOrderResponse, orderWriteRequest);
        Assert.assertEquals(PrepayAdaptorCheckoutConstants.PREPAY_CHECKOUT_SERVICES_HEADER_STATUS_CODE_FAILURE, orderWriteResponse.getServiceHeader().getStatusCode());
    }

    @Test
    public void getResponseContext_emptyPaymentMethodTest() throws IOException {
        String orderWriteRequestStr = FileReaderUtil.readFromFile("data/adaptor/helper/orderWriteRequest.json");
        String responseSession = FileReaderUtil.readFromFile("data/adaptor/helper/responseSession.json");
        OrderWriteRequest orderWriteRequest = mapper.readValue(orderWriteRequestStr, OrderWriteRequest.class);
        VZWPrepayOrderSubmitResponse submitOrderResponse = mapper.readValue(responseSession, VZWPrepayOrderSubmitResponse.class);
        submitOrderResponse.getPayload().getPageData().getOrderVo().setFlow("NSE");
        submitOrderResponse.getPayload().getPageData().getOrderVo().setPaymentMethod(SOEConstants.EMPTY_STRING);
        OrderWriteContext orderWriteContext = ReflectionTestUtils.invokeMethod(prepayAdaptorOrderWriteHelper, "getResponseContext",
                orderWriteRequest, submitOrderResponse);
        Assert.assertNull(orderWriteContext.getPaymentOptions());
    }

    @ParameterizedTest
    @CsvSource({"paypal", "applepay", "AMERICANEXPRESS CC", "master cc"})
    public void getResponseContext_paymentMethodTest(String paymentMethod) throws IOException {
        String orderWriteRequestStr = FileReaderUtil.readFromFile("data/adaptor/helper/orderWriteRequest.json");
        String responseSession = FileReaderUtil.readFromFile("data/adaptor/helper/responseSession.json");
        OrderWriteRequest orderWriteRequest = mapper.readValue(orderWriteRequestStr, OrderWriteRequest.class);
        VZWPrepayOrderSubmitResponse submitOrderResponse = mapper.readValue(responseSession, VZWPrepayOrderSubmitResponse.class);
        submitOrderResponse.getPayload().getPageData().getOrderVo().setPaymentMethod(paymentMethod);
        OrderWriteContext orderWriteContext = ReflectionTestUtils.invokeMethod(prepayAdaptorOrderWriteHelper, "getResponseContext",
                orderWriteRequest, submitOrderResponse);
        Assert.assertNotNull(orderWriteContext.getPaymentOptions());
    }

    @Test
    public void getResponseContext_exceptionTest() throws IOException {
        String orderWriteRequestStr = FileReaderUtil.readFromFile("data/adaptor/helper/orderWriteRequest.json");
        String responseSession = FileReaderUtil.readFromFile("data/adaptor/helper/responseSession.json");
        OrderWriteRequest orderWriteRequest = mapper.readValue(orderWriteRequestStr, OrderWriteRequest.class);
        VZWPrepayOrderSubmitResponse submitOrderResponse = mapper.readValue(responseSession, VZWPrepayOrderSubmitResponse.class);
        submitOrderResponse.getPayload().getPageData().setOrderVo(null);
        OrderWriteContext orderWriteContext = ReflectionTestUtils.invokeMethod(prepayAdaptorOrderWriteHelper, "getResponseContext",
                orderWriteRequest, submitOrderResponse);
        Assert.assertNull(orderWriteContext.getPaymentOptions());
    }

    @ParameterizedTest
    @CsvSource({"NSP", "PUP", "PAL", ","})
    public void getOrderDetails_orderTypeTest(String orderType) throws IOException {
        String responseSession = FileReaderUtil.readFromFile("data/adaptor/helper/responseSession.json");
        VZWPrepayOrderSubmitResponse submitOrderResponse = mapper.readValue(responseSession, VZWPrepayOrderSubmitResponse.class);
        submitOrderResponse.getPayload().getPageData().getVzwDL().getPurchase().setOrderType(orderType);
        OrderWrite orderWrite = ReflectionTestUtils.invokeMethod(prepayAdaptorOrderWriteHelper, "getOrderDetails", submitOrderResponse);
        String expected = "";
        if("NSP".equalsIgnoreCase(orderType)) {
            expected = "NSEBYOD";
        } else if("PUP".equalsIgnoreCase(orderType)) {
            expected = "EUP";
        } else if("PAL".equalsIgnoreCase(orderType)) {
            expected = "AAL";
        } else {
            expected = "NSE";
        }
        Assert.assertEquals(expected, orderWrite.getOrderDetails().get(0).getOrderType());
    }

    @Test
    public void getUpdatePaymentSuccessTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile( "data/adaptor/helper/orderWriteGetPaypalAuthRequest.json");
        String responseString = FileReaderUtil.readFromFile( "data/adaptor/helper/responseSessionSuccess.json");
        String str = "prepay_odRequestData";
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");

        ValidateCardCXPRequest request = mapper.readValue(requestString, ValidateCardCXPRequest.class);
        ResponseEntity<String> responseEntity1 = ResponseEntity.status(HttpStatus.OK).body(responseString);

        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<String> getDataResponse = Mono.just(str);
        Map<String, String> requestData = new HashMap<>();
        Map<String, String> headers = new HashMap<>();
        String cookies = "ECOMM_SESSION=" + "eCommSessionId" + "; p_csrftkn="
                + "pcsrfToken";
        headers.put("Cookie", cookies);
        headers.put("p-csrf-token", requestData.get("pcsrfToken"));
        headers.put("Content-Type", String.valueOf(ContentType.APPLICATION_JSON));
        headers.put("channelId", "VZW-DOTCOM");
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        when(prepayCheckoutRedisHelper.handleRedisData(Mockito.any())).thenReturn(requestData);
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(responseEntity1));
        Mono<ResponseEntity<ValidateCardPaymentCXPResponse>> responseMono = prepayAdaptorOrderWriteHelper.getUpdatePayment(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> org.junit.Assert.assertNotNull(d));


    }
    @Test
    public void getUpdatePaymentUnSuccessTest() throws IOException{
        String requestString = FileReaderUtil.readFromFile( "data/adaptor/helper/orderWriteGetPaypalAuthRequest.json");
        String responseString = FileReaderUtil.readFromFile( "data/adaptor/helper/responseSessionUnsuccess.json");
        String dataResponseString = "prepay_odRequestData";
        ResponseEntity<String> responseEntity = ResponseEntity.status(HttpStatus.OK).body(responseString);

        ValidateCardCXPRequest request = mapper.readValue(requestString, ValidateCardCXPRequest.class);
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest mockServerHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<String> dataResponse = Mono.just(dataResponseString);
        Map<String, String> requestData = new HashMap<>();

        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(dataResponse);
        when(prepayCheckoutRedisHelper.handleRedisData(Mockito.any())).thenReturn(requestData);
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(responseEntity));
        Mono<ResponseEntity<ValidateCardPaymentCXPResponse>> responseMono2 = prepayAdaptorOrderWriteHelper.getUpdatePayment(mockServerHttpRequest, request);
        responseMono2.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono2).assertNext(d -> org.junit.Assert.assertNotNull(d));

    }

    @Test
    public void getUpdatePayment_errorTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile( "data/adaptor/helper/orderWriteGetPaypalAuthRequest.json");
        String str = "prepay_odRequestData";
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        ValidateCardCXPRequest request = mapper.readValue(requestString, ValidateCardCXPRequest.class);
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<String> getDataResponse = Mono.just(str);
        Map<String, String> requestData = new HashMap<>();
        Map<String, String> headers = new HashMap<>();
        String cookies = "ECOMM_SESSION=" + "eCommSessionId" + "; p_csrftkn="
                + "pcsrfToken";
        headers.put("Cookie", cookies);
        ObjectMapper mapperMock = Mockito.mock(ObjectMapper.class);
        when(mapperMock.readTree(Mockito.anyString())).thenThrow(JsonProcessingException.class);
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        when(prepayCheckoutRedisHelper.handleRedisData(Mockito.any())).thenReturn(requestData);
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.error(new RuntimeException()));
        Mono<ResponseEntity<ValidateCardPaymentCXPResponse>> actual = prepayAdaptorOrderWriteHelper.getUpdatePayment(httpHeader, request);
        StepVerifier.create(actual).expectError().verify();
    }

    @Test
    public void getUpdatePayment_errorStatusTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile( "data/adaptor/helper/orderWriteGetPaypalAuthRequest.json");
        String responseString = FileReaderUtil.readFromFile( "data/adaptor/helper/responseSessionSuccess.json");
        String str = "prepay_odRequestData";
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        ValidateCardCXPRequest request = mapper.readValue(requestString, ValidateCardCXPRequest.class);
        ResponseEntity<String> responseEntity1 = ResponseEntity.status(HttpStatus.BAD_REQUEST).body(responseString);
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<String> getDataResponse = Mono.just(str);
        Map<String, String> requestData = new HashMap<>();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        when(prepayCheckoutRedisHelper.handleRedisData(Mockito.any())).thenReturn(requestData);
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(responseEntity1));
        Mono<ResponseEntity<ValidateCardPaymentCXPResponse>> responseMono = prepayAdaptorOrderWriteHelper.getUpdatePayment(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> org.junit.Assert.assertNotNull(d));
    }

    @Test
    public void getUpdatePayment_notSecureCardTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile( "data/adaptor/helper/orderWriteGetPaypalAuthRequest.json");
        String responseString = FileReaderUtil.readFromFile( "data/adaptor/helper/responseSessionSuccess.json");
        SubmitConfirmationResponse submitConfirmationResponse = mapper.readValue(responseString, SubmitConfirmationResponse.class);
        submitConfirmationResponse.getPayload().getPageData().setSecureCard(false);
        responseString = mapper.writeValueAsString(submitConfirmationResponse);
        String str = "prepay_odRequestData";
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        ValidateCardCXPRequest request = mapper.readValue(requestString, ValidateCardCXPRequest.class);
        ResponseEntity<String> responseEntity1 = ResponseEntity.status(HttpStatus.OK).body(responseString);
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<String> getDataResponse = Mono.just(str);
        Map<String, String> requestData = new HashMap<>();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        when(prepayCheckoutRedisHelper.handleRedisData(Mockito.any())).thenReturn(requestData);
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(responseEntity1));
        Mono<ResponseEntity<ValidateCardPaymentCXPResponse>> responseMono = prepayAdaptorOrderWriteHelper.getUpdatePayment(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> org.junit.Assert.assertNotNull(d));
    }

    @Test
    public void getUpdatePayment_exceptionTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile( "data/adaptor/helper/orderWriteGetPaypalAuthRequest.json");
        String responseString = FileReaderUtil.readFromFile( "data/adaptor/helper/responseSessionSuccess.json");
        responseString = responseString.replace("}", "");
        String str = "prepay_odRequestData";
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        ValidateCardCXPRequest request = mapper.readValue(requestString, ValidateCardCXPRequest.class);
        ResponseEntity<String> responseEntity1 = ResponseEntity.status(HttpStatus.OK).body(responseString);
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<String> getDataResponse = Mono.just(str);
        Map<String, String> requestData = new HashMap<>();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        when(prepayCheckoutRedisHelper.handleRedisData(Mockito.any())).thenReturn(requestData);
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(responseEntity1));
        Mono<ResponseEntity<ValidateCardPaymentCXPResponse>> responseMono = prepayAdaptorOrderWriteHelper.getUpdatePayment(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> org.junit.Assert.assertNotNull(d));
    }

    @Test
    public void getFourDigitsTest() {
        String actual = ReflectionTestUtils.invokeMethod(prepayAdaptorOrderWriteHelper, "getFourDigits", "SOETestCase data");
        Assert.assertEquals("Case", actual);
    }

    @Test
    public void getPayPalLookUpTest() throws IOException{
        String cMPILookupCXPRequest = "{\"ipAddress\":\"ipAddress\",\"cartId\":\"cartId\",\"termUrl\":\"termUrl\",\"shippingOptionId\":\"shippingOptionId\"}";
        String str = "prepay_odRequestData";

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        CMPILookupCXPRequest request = mapper.readValue(cMPILookupCXPRequest, CMPILookupCXPRequest.class);
        Mono<String> getDataResponse = Mono.just(str);

        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(cMPILookupCXPRequest));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(),Mockito.any())).thenReturn(webClientResponse);
        Mono<ResponseEntity<CMPILookupCXPResponse>> responseMono1 = prepayAdaptorOrderWriteHelper.getPayPalLookUp(null,request);
        responseMono1.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono1).assertNext(d -> org.junit.Assert.assertNotNull(d));
    }

    @Test
    public void getPayPalLookUp_emptyRedisTest() throws JsonProcessingException {
        String cMPILookupCXPRequest = "{\"ipAddress\":\"ipAddress\",\"cartId\":\"cartId\",\"termUrl\":\"termUrl\",\"shippingOptionId\":\"shippingOptionId\"}";
        CMPILookupCXPRequest request = mapper.readValue(cMPILookupCXPRequest, CMPILookupCXPRequest.class);
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(Mono.just(SOEConstants.EMPTY_STRING));
        Mono<ResponseEntity<CMPILookupCXPResponse>> actual = prepayAdaptorOrderWriteHelper.getPayPalLookUp(null, request);
        StepVerifier.create(actual).expectError().verify();
    }

    @Test
    public void getPayPalLookUp_exceptionTest() throws IOException {
        String cMPILookupCXPRequest = "{\"ipAddress\":\"ipAddress\",\"cartId\":\"cartId\",\"termUrl\":\"termUrl\",\"shippingOptionId\":\"shippingOptionId\"}";
        String str = "prepay_odRequestData";
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        CMPILookupCXPRequest request = mapper.readValue(cMPILookupCXPRequest, CMPILookupCXPRequest.class);
        Mono<String> getDataResponse = Mono.just(str);
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        cMPILookupCXPRequest = cMPILookupCXPRequest.replace("}", "");
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(cMPILookupCXPRequest));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(),Mockito.any())).thenReturn(webClientResponse);
        Mono<ResponseEntity<CMPILookupCXPResponse>> responseMono1 = prepayAdaptorOrderWriteHelper.getPayPalLookUp(null,request);
        responseMono1.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono1).assertNext(d -> org.junit.Assert.assertNotNull(d));
    }

    @Test
    public void getPaypalAuthTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile( "data/adaptor/helper/orderWriteGetPaypalAuthRequest.json");

        String str = "prepay_odRequestData";

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");

        PreauthDigitalPayCXPRequest request = mapper.readValue(requestString, PreauthDigitalPayCXPRequest.class);

        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<String> getDataResponse = Mono.just(str);
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(requestString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(),Mockito.any())).thenReturn(webClientResponse);
        Mono<ResponseEntity<PreauthDigitalPayCXPResponse>> responseMono = prepayAdaptorOrderWriteHelper.getPaypalAuth(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> org.junit.Assert.assertNotNull(d));
    }

    @Test
    public void getPaypalAuth_emptyRedisTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile( "data/adaptor/helper/orderWriteGetPaypalAuthRequest.json");
        PreauthDigitalPayCXPRequest request = mapper.readValue(requestString, PreauthDigitalPayCXPRequest.class);
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(Mono.just(SOEConstants.EMPTY_STRING));
        Mono<ResponseEntity<PreauthDigitalPayCXPResponse>> actual = prepayAdaptorOrderWriteHelper.getPaypalAuth(null, request);
        StepVerifier.create(actual).expectError().verify();
    }

    @Test
    public void getPaypalAuth_exceptionTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile( "data/adaptor/helper/orderWriteGetPaypalAuthRequest.json");
        String str = "prepay_odRequestData";
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        PreauthDigitalPayCXPRequest request = mapper.readValue(requestString, PreauthDigitalPayCXPRequest.class);
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<String> getDataResponse = Mono.just(str);
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        requestString = requestString.replace("}", "");
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(requestString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(),Mockito.any())).thenReturn(webClientResponse);
        Mono<ResponseEntity<PreauthDigitalPayCXPResponse>> responseMono = prepayAdaptorOrderWriteHelper.getPaypalAuth(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> org.junit.Assert.assertNotNull(d));
    }

    @Test
    public void getAuthPayloadTest() {
        Object object = ReflectionTestUtils.invokeMethod(prepayAdaptorOrderWriteHelper, "getAuthPayload", new PreauthDigitalPayCXPRequest(), null);
        Assert.assertNotNull(object);
    }

    @Test
    public void confirmSubmit3DTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile( "data/adaptor/helper/orderWriteConfirmSubmit3DRequest.json");
        String str = "prepay_odRequestData";

        ConfirmSubmit3DCXPRequest request = mapper.readValue(requestString, ConfirmSubmit3DCXPRequest.class);
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<String> getDataResponse = Mono.just(str);
        Map<String, String> requestData = new HashMap<>();

        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        when(prepayCheckoutRedisHelper.handleRedisData(Mockito.any())).thenReturn(requestData);

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(requestString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(),Mockito.any())).thenReturn(webClientResponse);
        Mono<ResponseEntity<ConfirmSubmit3DCXPResponse>> responseMono = prepayAdaptorOrderWriteHelper.confirmSubmit3D(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> org.junit.Assert.assertNotNull(d));
    }

    @Test
    public void confirmSubmit3DSuccessTest() throws IOException {
        String confirmSubmitRequestString = FileReaderUtil.readFromFile( "data/adaptor/helper/orderWriteConfirmSubmit3DTest1Request.json");
        String str = "prepay_odRequestData";
        ConfirmSubmit3DCXPRequest confirmSubmit3DCXPRequest = mapper.readValue(confirmSubmitRequestString, ConfirmSubmit3DCXPRequest.class);
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<String> getDataResponse = Mono.just(str);
        Map<String, String> requestData = new HashMap<>();

        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        when(prepayCheckoutRedisHelper.handleRedisData(Mockito.any())).thenReturn(requestData);
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(confirmSubmitRequestString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(),Mockito.any())).thenReturn(webClientResponse);
        Mono<ResponseEntity<ConfirmSubmit3DCXPResponse>> confirmSubmit3DCXPResponse =  prepayAdaptorOrderWriteHelper.confirmSubmit3D(httpHeader, confirmSubmit3DCXPRequest);
        confirmSubmit3DCXPResponse.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(confirmSubmit3DCXPResponse).assertNext(d -> org.junit.Assert.assertNotNull(d));
    }

    @Test
    public void confirmSubmit3DUnSuccessTest() throws IOException {
        String confirmSubmit3DRequest = FileReaderUtil.readFromFile( "data/adaptor/helper/orderWriteConfirmSubmit3DErrorTest2Request.json");
        String str = "prepay_odRequestData";
        ConfirmSubmit3DCXPRequest confirmSubmit3DCXPRequest = mapper.readValue(confirmSubmit3DRequest, ConfirmSubmit3DCXPRequest.class);
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Map<String, String> requestData = new HashMap<>();
        Mono<String> getDataResponse = Mono.just(str);
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(confirmSubmit3DRequest));
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        when(prepayCheckoutRedisHelper.handleRedisData(Mockito.any())).thenReturn(requestData);
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(),Mockito.any())).thenReturn(webClientResponse);
        Mono<ResponseEntity<ConfirmSubmit3DCXPResponse>> responseMono2 =  prepayAdaptorOrderWriteHelper.confirmSubmit3D(httpHeader, confirmSubmit3DCXPRequest);
        responseMono2.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono2).assertNext(d -> org.junit.Assert.assertNotNull(d));
    }

    @Test
    public void confirmSubmit3DUnSuccessTest_1() throws IOException {
        String confirmSubmit3DRequest = FileReaderUtil.readFromFile( "data/adaptor/helper/orderWriteConfirmSubmit3DErrorTest2Request.json");
        String str = "prepay_odRequestData";
        ConfirmSubmit3DCXPRequest confirmSubmit3DCXPRequest = mapper.readValue(confirmSubmit3DRequest, ConfirmSubmit3DCXPRequest.class);
        String errorResp="{\"output\":null,\"maxAttemptsReached\":\"true\",\"errorMap\":{\"01\":\"We’resorry,you’veexceededthemaximumamountofattempts.PleasevisityournearestVerizonstoretoprocessyourorder.\"},\"statusMessage\":null,\"statusCode\":\"01\"}";
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Map<String, String> requestData = new HashMap<>();
        Mono<String> getDataResponse = Mono.just(str);
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(errorResp));
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        when(prepayCheckoutRedisHelper.handleRedisData(Mockito.any())).thenReturn(requestData);
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(),Mockito.any())).thenReturn(webClientResponse);
        Mono<ResponseEntity<ConfirmSubmit3DCXPResponse>> responseMono2 =  prepayAdaptorOrderWriteHelper.confirmSubmit3D(httpHeader, confirmSubmit3DCXPRequest);
        responseMono2.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono2).assertNext(d -> org.junit.Assert.assertNotNull(d));
    }

    @Test
    public void confirmSubmit3DUnSuccessTest_2() throws IOException {
        String confirmSubmit3DRequest = FileReaderUtil.readFromFile( "data/adaptor/helper/orderWriteConfirmSubmit3DErrorTest2Request.json");
        String str = "prepay_odRequestData";
        ConfirmSubmit3DCXPRequest confirmSubmit3DCXPRequest = mapper.readValue(confirmSubmit3DRequest, ConfirmSubmit3DCXPRequest.class);
        String errorResp="{\"status\":500,\"statusCode\":\"01\",\"errors\":{\"error\":[{\"errorKey\":\"GENERIC_SERVICE_EXCEPTION\",\"errorMsg\":\"Your card issuing bank has indicated that it couldn't successfully authenticate this transaction. Please try again with another card.\"}]}}";
        URI url = URI.create("http://localhost/confirmSubmit");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Map<String, String> requestData = new HashMap<>();
        Mono<String> getDataResponse = Mono.just(str);
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(errorResp));
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        when(prepayCheckoutRedisHelper.handleRedisData(Mockito.any())).thenReturn(requestData);
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(),Mockito.any())).thenReturn(webClientResponse);
        Mono<ResponseEntity<ConfirmSubmit3DCXPResponse>> responseMono2 =  prepayAdaptorOrderWriteHelper.confirmSubmit3D(httpHeader, confirmSubmit3DCXPRequest);
        responseMono2.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono2).assertNext(d -> org.junit.Assert.assertNotNull(d));
    }
    @Test
    public void confirmSubmit3DUnSuccessTest_3() throws IOException {
        String confirmSubmit3DRequest = FileReaderUtil.readFromFile( "data/adaptor/helper/orderWriteConfirmSubmit3DErrorTest2Request.json");
        String str = "prepay_odRequestData";
        ConfirmSubmit3DCXPRequest confirmSubmit3DCXPRequest = mapper.readValue(confirmSubmit3DRequest, ConfirmSubmit3DCXPRequest.class);
        String errorResp="{\"status\":500,\"statusCode\":\"01\",\"errors\":{\"status\":500,\"ecommApiErrorList\":[{\"statusCode\":\"01\",\"message\":\"We're sorry, it looks like there is an issue with your card. Please contact your institution for assistance.\",\"developerMessage\":\"We're sorry, it looks like there is an issue with your card. Please contact your institution for assistance.\",\"moreInfo\":null,\"homeSafetyInfo\":null}]}}";
        URI url = URI.create("http://localhost/confirmSubmit");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Map<String, String> requestData = new HashMap<>();
        Mono<String> getDataResponse = Mono.just(str);
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(errorResp));
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        when(prepayCheckoutRedisHelper.handleRedisData(Mockito.any())).thenReturn(requestData);
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(),Mockito.any())).thenReturn(webClientResponse);
        Mono<ResponseEntity<ConfirmSubmit3DCXPResponse>> responseMono2 =  prepayAdaptorOrderWriteHelper.confirmSubmit3D(httpHeader, confirmSubmit3DCXPRequest);
        responseMono2.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono2).assertNext(d -> org.junit.Assert.assertNotNull(d));
    }

    @Test
    public void confirmSubmit3D_emptyRedisTest() {
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(Mono.just(SOEConstants.EMPTY_STRING));
        Mono<ResponseEntity<ConfirmSubmit3DCXPResponse>> actual = prepayAdaptorOrderWriteHelper.confirmSubmit3D(null, null);
        StepVerifier.create(actual).assertNext(resp -> Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), resp.getStatusCodeValue())).expectComplete().verify();
    }

    @Test
    public void confirmSubmit3D_errorTest() throws IOException {
        String confirmSubmitRequestString = FileReaderUtil.readFromFile( "data/adaptor/helper/orderWriteConfirmSubmit3DTest1Request.json");
        String str = "prepay_odRequestData";
        ConfirmSubmit3DCXPRequest confirmSubmit3DCXPRequest = mapper.readValue(confirmSubmitRequestString, ConfirmSubmit3DCXPRequest.class);
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<String> getDataResponse = Mono.just(str);
        Map<String, String> requestData = new HashMap<>();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        when(prepayCheckoutRedisHelper.handleRedisData(Mockito.any())).thenReturn(requestData);
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(),Mockito.any())).thenReturn(Mono.error(new RuntimeException()));
        Mono<ResponseEntity<ConfirmSubmit3DCXPResponse>> actual =  prepayAdaptorOrderWriteHelper.confirmSubmit3D(httpHeader, confirmSubmit3DCXPRequest);
        actual.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(actual).expectError().verify();
    }

    @Test
    public void confirmSubmit3D_errorStatusTest() throws IOException {
        String confirmSubmitRequestString = FileReaderUtil.readFromFile( "data/adaptor/helper/orderWriteConfirmSubmit3DTest1Request.json");
        String str = "prepay_odRequestData";
        ConfirmSubmit3DCXPRequest confirmSubmit3DCXPRequest = mapper.readValue(confirmSubmitRequestString, ConfirmSubmit3DCXPRequest.class);
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<String> getDataResponse = Mono.just(str);
        Map<String, String> requestData = new HashMap<>();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        when(prepayCheckoutRedisHelper.handleRedisData(Mockito.any())).thenReturn(requestData);
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.CONFLICT).body(confirmSubmitRequestString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(),Mockito.any())).thenReturn(webClientResponse);
        Mono<ResponseEntity<ConfirmSubmit3DCXPResponse>> confirmSubmit3DCXPResponse =  prepayAdaptorOrderWriteHelper.confirmSubmit3D(httpHeader, confirmSubmit3DCXPRequest);
        confirmSubmit3DCXPResponse.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(confirmSubmit3DCXPResponse).assertNext(d -> Assert.assertNotNull(d));
    }

    @Test
    public void confirmSubmit3D_exceptionTest() throws IOException {
        String confirmSubmitRequestString = FileReaderUtil.readFromFile( "data/adaptor/helper/orderWriteConfirmSubmit3DTest1Request.json");
        String str = "prepay_odRequestData";
        ConfirmSubmit3DCXPRequest confirmSubmit3DCXPRequest = mapper.readValue(confirmSubmitRequestString, ConfirmSubmit3DCXPRequest.class);
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<String> getDataResponse = Mono.just(str);
        Map<String, String> requestData = new HashMap<>();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        when(prepayCheckoutRedisHelper.handleRedisData(Mockito.any())).thenReturn(requestData);
        confirmSubmitRequestString = confirmSubmitRequestString.replace("}", "");
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(confirmSubmitRequestString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(),Mockito.any())).thenReturn(webClientResponse);
        Mono<ResponseEntity<ConfirmSubmit3DCXPResponse>> confirmSubmit3DCXPResponse =  prepayAdaptorOrderWriteHelper.confirmSubmit3D(httpHeader, confirmSubmit3DCXPRequest);
        confirmSubmit3DCXPResponse.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(confirmSubmit3DCXPResponse).assertNext(d -> Assert.assertNotNull(d));
    }

    @Test
    public void getUpdatePaymentErrorTest() throws IOException{
        String requestString = FileReaderUtil.readFromFile( "data/adaptor/helper/orderWriteGetUpdatePaymentErrorRequest.json");
        String str = "";
        ValidateCardCXPRequest request = mapper.readValue(requestString, ValidateCardCXPRequest.class);
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<String> getDataResponse = Mono.just(str);
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        Mono<ResponseEntity<ValidateCardPaymentCXPResponse>> responseMono = prepayAdaptorOrderWriteHelper.getUpdatePayment(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(Mono.just("Exception").map(element -> {throw new RuntimeException();})).expectError().verify();
    }

    @Test
    public void kibanaCustomOrderWriteLogsTest() throws IOException {
        String responseSession = FileReaderUtil.readFromFile("data/adaptor/helper/responseSession.json");
        VZWPrepayOrderSubmitResponse submitOrderResponse = mapper.readValue(responseSession, VZWPrepayOrderSubmitResponse.class);
        submitOrderResponse.getPayload().getPageData().setOrderVo(new VZWPrepayOrderVO());
        ReflectionTestUtils.setField(prepayAdaptorOrderWriteHelper, "enableOrderLog", false);
        ReflectionTestUtils.invokeMethod(prepayAdaptorOrderWriteHelper, "kibanaCustomOrderWriteLogs", submitOrderResponse);
        submitOrderResponse.getPayload().getPageData().setOrderVo(null);
        ReflectionTestUtils.invokeMethod(prepayAdaptorOrderWriteHelper, "kibanaCustomOrderWriteLogs", submitOrderResponse);
        StepVerifier.create(Mono.just("Exception")).assertNext(d -> Assert.assertNotNull(d));
    }

    @ParameterizedTest
    @CsvSource({"NSP", "BYOD", "PASO", "AAL", "EUP", "PUP", "PAL"})
    public void getFlowDataTest(String flowName) {
        String actual = ReflectionTestUtils.invokeMethod(prepayAdaptorOrderWriteHelper, "getFlowData", flowName);
        assertNotNull(actual);
    }

    @Test
    public void getApplePaySessionDetailsTest() throws IOException {
    	String request="domainName=www.verizon.com&url=https://apple-pay-gateway.apple.com/paymentservices/startSession";
        String responseString = FileReaderUtil.readFromFile("data/adaptor/helper/GetApplePaySessionResponse.json");
        String responseSession = FileReaderUtil.readFromFile("data/adaptor/helper/responseSession.json");
        String str = "prepay_odRequestData";
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        URI url = URI.create("http://localhost/getApplePaySession");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<String> getDataResponse = Mono.just(str);
        Map<String, String> requestData = new HashMap<>();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(Mono.just(responseSession));
        when(prepayCheckoutRedisHelper.handleRedisData(Mockito.any())).thenReturn(requestData);
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        Mono<ResponseEntity<GetApplePaySessionCXPResponse>> responseMono = prepayAdaptorOrderWriteHelper.getApplePaySessionDetails(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> org.junit.Assert.assertNotNull(d));
    }
    
    @Test
    public void getApplePaySessionDetailsRedisNullTest() throws IOException {
    	String request="domainName=www.verizon.com&url=https://apple-pay-gateway.apple.com/paymentservices/startSession";
        String responseSession = FileReaderUtil.readFromFile("data/adaptor/helper/responseSession.json");
        String str = "";
        URI url = URI.create("http://localhost/getApplePaySession");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<String> getDataResponse = Mono.just(str);
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseSession));
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        Mono<ResponseEntity<GetApplePaySessionCXPResponse>> responseMono = prepayAdaptorOrderWriteHelper.getApplePaySessionDetails(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(Mono.just("Exception").map(element -> {throw new RuntimeException();})).expectError().verify();
    }
    
    @Test
    public void getApplePaySessionDetailsErrorTest() throws IOException {
    	String request=null;
    	String str = "prepay_odRequestData";
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        URI url = URI.create("http://localhost/getApplePaySession");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<String> getDataResponse = Mono.just(str);
        ResponseEntity<String> webClientResponse= new ResponseEntity("", HttpStatus.GATEWAY_TIMEOUT);
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(webClientResponse));
        Mono<ResponseEntity<GetApplePaySessionCXPResponse>> responseMono = prepayAdaptorOrderWriteHelper.getApplePaySessionDetails(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(Mono.just("Exception").map(element -> {throw new RuntimeException();})).expectError().verify();
    }
    
    @Test
    public void processApplePayTokenDetailsTest() throws IOException {
    	String requestString = FileReaderUtil.readFromFile("data/adaptor/helper/ProcessApplePaySessionRequest.json");
    	String responseString = FileReaderUtil.readFromFile("data/adaptor/helper/ProcessApplePaySessionResponse.json");
    	String responseSession = FileReaderUtil.readFromFile("data/adaptor/helper/responseSession.json");
        String str = "prepay_odRequestData";
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        ProcessApplePaySessionCxpRequest request = mapper.readValue(requestString, ProcessApplePaySessionCxpRequest.class);
        URI url = URI.create("http://localhost/processApplePayToken");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<String> getDataResponse = Mono.just(str);
        Map<String, String> requestData = new HashMap<>();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseSession));
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(Mono.just(responseString));
        when(prepayCheckoutRedisHelper.handleRedisData(Mockito.any())).thenReturn(requestData);
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        Mono<ResponseEntity<ProcessApplePaySessionCXPResponse>> responseMono = prepayAdaptorOrderWriteHelper.processApplePayTokenDetails(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> org.junit.Assert.assertNotNull(d));
    	
    }
   
    @Test
    public void processApplePayTokenDetailsRedisNullTest() throws IOException {
    	String requestString = FileReaderUtil.readFromFile("data/adaptor/helper/ProcessApplePaySessionRequest.json");
    	String responseString = "";
        String str = "";
        ProcessApplePaySessionCxpRequest request = mapper.readValue(requestString, ProcessApplePaySessionCxpRequest.class);
        URI url = URI.create("http://localhost/processApplePayToken");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<String> getDataResponse = Mono.just(str);
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(Mono.just(responseString));
        Mono<ResponseEntity<ProcessApplePaySessionCXPResponse>> responseMono = prepayAdaptorOrderWriteHelper.processApplePayTokenDetails(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> org.junit.Assert.assertNotNull(d));
    	
    }
    
    @Test
    public void processApplePayTokenDetailsErrorTest() throws IOException {
    	String requestString = FileReaderUtil.readFromFile("data/adaptor/helper/ProcessApplePaySessionRequest.json");
    	String responseString = FileReaderUtil.readFromFile("data/adaptor/helper/ProcessApplePaySessionResponse.json");
    	String str = "prepay_odRequestData";
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        ProcessApplePaySessionCxpRequest request = mapper.readValue(requestString, ProcessApplePaySessionCxpRequest.class);
        URI url = URI.create("http://localhost/processApplePayToken");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<String> getDataResponse = Mono.just(str);
        ResponseEntity<String> webClientResponse= new ResponseEntity("", HttpStatus.GATEWAY_TIMEOUT);
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(Mono.just(responseString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(webClientResponse));
        Mono<ResponseEntity<ProcessApplePaySessionCXPResponse>> responseMono = prepayAdaptorOrderWriteHelper.processApplePayTokenDetails(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> org.junit.Assert.assertNotNull(d));
    	
    }

    @Test
    public void orderWritWithNotEqualAddressTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/helper/orderWriteRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/adaptor/helper/orderWriteResponse.json");
        String responseSession = FileReaderUtil.readFromFile("data/adaptor/helper/responseSession.json");
        VZWPrepayOrderSubmitResponse submitOrderResponse = mapper.readValue(responseSession, VZWPrepayOrderSubmitResponse.class);
        submitOrderResponse.setErrors(null);
        submitOrderResponse.getPayload().getPageData().setOrderSubmitted(false);
        submitOrderResponse.getPayload().getPageData().getOrderVo().getBillingAddress().getAddress().setAddressLine1("testAddressLine1");
        responseSession = mapper.writeValueAsString(submitOrderResponse);
        String str = "prepay_odRequestData";
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        OrderWriteRequest request = mapper.readValue(requestString, OrderWriteRequest.class);
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url)
                .header("e2eRequestId", "123-fdsfd-erw2fd-32")
                .header(PrepayAdaptorCheckoutConstants.PREPAY_DIGITAL_IG_SESSION, "sample-session-id").build();
        Mono<String> getDataResponse = Mono.just(str);
        Map<String, String> requestData = new HashMap<>();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseSession));
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(Mono.just(responseString));
        when(prepayCheckoutRedisHelper.handleRedisData(Mockito.any())).thenReturn(requestData);
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        Mono<ResponseEntity<OrderWriteResponse>> actual = prepayAdaptorOrderWriteHelper.orderWrite(httpRequest, request);
        StepVerifier.create(actual).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void orderWritWithNewAddressVOTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/helper/orderWriteRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/adaptor/helper/orderWriteResponse.json");
        String responseSession = FileReaderUtil.readFromFile("data/adaptor/helper/responseSession.json");
        VZWPrepayOrderSubmitResponse submitOrderResponse = mapper.readValue(responseSession, VZWPrepayOrderSubmitResponse.class);
        submitOrderResponse.setErrors(null);
        submitOrderResponse.getPayload().getPageData().setOrderSubmitted(false);
        submitOrderResponse.getPayload().getPageData().getOrderVo().getBillingAddress().setAddress(new AddressVO());
        responseSession = mapper.writeValueAsString(submitOrderResponse);
        String str = "prepay_odRequestData";
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        OrderWriteRequest request = mapper.readValue(requestString, OrderWriteRequest.class);
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url)
                .header("e2eRequestId", "123-fdsfd-erw2fd-32")
                .header(PrepayAdaptorCheckoutConstants.PREPAY_DIGITAL_IG_SESSION, "sample-session-id").build();
        Mono<String> getDataResponse = Mono.just(str);
        Map<String, String> requestData = new HashMap<>();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseSession));
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(Mono.just(responseString));
        when(prepayCheckoutRedisHelper.handleRedisData(Mockito.any())).thenReturn(requestData);
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        Mono<ResponseEntity<OrderWriteResponse>> actual = prepayAdaptorOrderWriteHelper.orderWrite(httpRequest, request);
        StepVerifier.create(actual).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void orderWritWithNullAddressTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/helper/orderWriteRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/adaptor/helper/orderWriteResponse.json");
        String responseSession = FileReaderUtil.readFromFile("data/adaptor/helper/responseSession.json");
        VZWPrepayOrderSubmitResponse submitOrderResponse = mapper.readValue(responseSession, VZWPrepayOrderSubmitResponse.class);
        submitOrderResponse.setErrors(null);
        submitOrderResponse.getPayload().getPageData().setOrderSubmitted(false);
        submitOrderResponse.getPayload().getPageData().getOrderVo().getBillingAddress().setAddress(null);
        responseSession = mapper.writeValueAsString(submitOrderResponse);
        String str = "prepay_odRequestData";
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        OrderWriteRequest request = mapper.readValue(requestString, OrderWriteRequest.class);
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url)
                .header("e2eRequestId", "123-fdsfd-erw2fd-32")
                .header(PrepayAdaptorCheckoutConstants.PREPAY_DIGITAL_IG_SESSION, "sample-session-id").build();
        Mono<String> getDataResponse = Mono.just(str);
        Map<String, String> requestData = new HashMap<>();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseSession));
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(Mono.just(responseString));
        when(prepayCheckoutRedisHelper.handleRedisData(Mockito.any())).thenReturn(requestData);
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        Mono<ResponseEntity<OrderWriteResponse>> actual = prepayAdaptorOrderWriteHelper.orderWrite(httpRequest, request);
        StepVerifier.create(actual).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void orderWritWithOrderAccessoryListLogTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/helper/orderWriteRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/adaptor/helper/orderWriteResponse.json");
        String responseSession = FileReaderUtil.readFromFile("data/adaptor/helper/responseSession.json");
        VZWPrepayOrderSubmitResponse submitOrderResponse = mapper.readValue(responseSession, VZWPrepayOrderSubmitResponse.class);
        submitOrderResponse.setErrors(null);
        submitOrderResponse.getPayload().getPageData().setOrderSubmitted(false);
        submitOrderResponse.getPayload().getPageData().getOrderVo().getAccessoryList().get(0).setSkuDisplayName("testSkuDisplayName");
        submitOrderResponse.getPayload().getPageData().getOrderVo().getAccessoryList().get(0).setProductId("101");
        responseSession = mapper.writeValueAsString(submitOrderResponse);
        String str = "prepay_odRequestData";
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        OrderWriteRequest request = mapper.readValue(requestString, OrderWriteRequest.class);
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url)
                .header("e2eRequestId", "123-fdsfd-erw2fd-32")
                .header(PrepayAdaptorCheckoutConstants.PREPAY_DIGITAL_IG_SESSION, "sample-session-id").build();
        Mono<String> getDataResponse = Mono.just(str);
        Map<String, String> requestData = new HashMap<>();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseSession));
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(Mono.just(responseString));
        when(prepayCheckoutRedisHelper.handleRedisData(Mockito.any())).thenReturn(requestData);
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        Mono<ResponseEntity<OrderWriteResponse>> actual = prepayAdaptorOrderWriteHelper.orderWrite(httpRequest, request);
        StepVerifier.create(actual).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void orderWritWithOrderDeviceListLogTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/helper/orderWriteRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/adaptor/helper/orderWriteResponse.json");
        String responseSession = FileReaderUtil.readFromFile("data/adaptor/helper/responseSession.json");
        VZWPrepayOrderSubmitResponse submitOrderResponse = mapper.readValue(responseSession, VZWPrepayOrderSubmitResponse.class);
        submitOrderResponse.setErrors(null);
        submitOrderResponse.getPayload().getPageData().setOrderSubmitted(true);
        submitOrderResponse.getPayload().getPageData().getOrderVo().getDeviceList().get(0).setSkuDisplayName("testSkuDisplayName");
        submitOrderResponse.getPayload().getPageData().getOrderVo().getDeviceList().get(0).setProductId("101");
        submitOrderResponse.getPayload().getPageData().getOrderVo().getDeviceList().get(0).setBrandName("testBrandName");
        submitOrderResponse.getPayload().getPageData().getOrderVo().getDeviceList().get(0).setItemType("testItemType");
        submitOrderResponse.getPayload().getPageData().getOrderVo().getDeviceList().get(0).setSkuId("01");
        responseSession = mapper.writeValueAsString(submitOrderResponse);
        String str = "prepay_odRequestData";
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        OrderWriteRequest request = mapper.readValue(requestString, OrderWriteRequest.class);
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url)
                .header("e2eRequestId", "123-fdsfd-erw2fd-32")
                .header(PrepayAdaptorCheckoutConstants.PREPAY_DIGITAL_IG_SESSION, "sample-session-id").build();
        Mono<String> getDataResponse = Mono.just(str);
        Map<String, String> requestData = new HashMap<>();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseSession));
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(Mono.just(responseString));
        when(prepayCheckoutRedisHelper.handleRedisData(Mockito.any())).thenReturn(requestData);
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        Mono<ResponseEntity<OrderWriteResponse>> actual = prepayAdaptorOrderWriteHelper.orderWrite(httpRequest, request);
        StepVerifier.create(actual).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void getApplePaySessionDetailsWith500ErrorTest() throws IOException {
        String request="domainName=www.verizon.com&url=https://apple-pay-gateway.apple.com/paymentservices/startSession";
        String responseString = FileReaderUtil.readFromFile("data/adaptor/helper/GetApplePaySessionResponse.json");
        String responseSession = FileReaderUtil.readFromFile("data/adaptor/helper/responseSession.json");
        String str = "prepay_odRequestData";
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        URI url = URI.create("http://localhost/getApplePaySession");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<String> getDataResponse = Mono.just(str);
        Map<String, String> requestData = new HashMap<>();
        Mono<ResponseEntity<String>> webClientResponse =
                Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(responseString));
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(Mono.just(responseSession));
        when(prepayCheckoutRedisHelper.handleRedisData(Mockito.any())).thenReturn(requestData);
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        Mono<ResponseEntity<GetApplePaySessionCXPResponse>> responseMono = prepayAdaptorOrderWriteHelper.getApplePaySessionDetails(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> org.junit.Assert.assertNotNull(d));
    }

    @Test
    public void getApplePaySessionDetailsWithJsonProcessingExceptionTest() throws IOException {
        String request="domainName=www.verizon.com&url=https://apple-pay-gateway.apple.com/paymentservices/startSession";
        String responseSession = FileReaderUtil.readFromFile("data/adaptor/helper/responseSession.json");
        String str = "prepay_odRequestData";
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        URI url = URI.create("http://localhost/getApplePaySession");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<String> getDataResponse = Mono.just(str);
        Map<String, String> requestData = new HashMap<>();
        Mono<ResponseEntity<String>> webClientResponse =
                Mono.just(ResponseEntity.status(HttpStatus.OK).body(""));
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(getDataResponse);
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(Mono.just(responseSession));
        when(prepayCheckoutRedisHelper.handleRedisData(Mockito.any())).thenReturn(requestData);
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        Mono<ResponseEntity<GetApplePaySessionCXPResponse>> responseMono = prepayAdaptorOrderWriteHelper.getApplePaySessionDetails(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> org.junit.Assert.assertNotNull(d));
    }

    @Test
    public void checkAddressMatchesExceptionTest() {
        Assert.assertFalse(ReflectionTestUtils
                .invokeMethod(prepayAdaptorOrderWriteHelper, "checkAddressMatches", new AddressVO(), null));
    }

    @Test
    public void compareExceptionTest() {
        Assert.assertFalse(ReflectionTestUtils.invokeMethod(prepayAdaptorOrderWriteHelper, "compare", "test", "null"));
        Assert.assertFalse(ReflectionTestUtils.invokeMethod(prepayAdaptorOrderWriteHelper, "compare", null, "test")) ;
    }


}