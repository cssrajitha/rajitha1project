package onevz.soe.prepay.adaptor.checkout.helper;

import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.checkout.request.bpm.UpdateLineSecurityInfoRequest;
import onevz.soe.checkout.response.bpm.UpdateLineSecurityInfoResponse;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.prepay.adaptor.checkout.config.PrepayCheckoutAdaptorServiceTestConfig;
import onevz.soe.prepay.adaptor.checkout.util.FileReaderUtil;
import onevz.soe.prepay.adaptor.checkout.util.PrepayUpdateLineSecurityInfoFormatterUtil;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import onevz.soe.wsclient.prepay.webclient.model.PrepaidAdaptorWebClientRequest;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.net.URI;

import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {PrepayCheckoutAdaptorServiceTestConfig.class})
@WebFluxTest(PrepayAdaptorUpdateLineSecurityInfoHelper.class)
public class PrepayAdaptorUpdateLineSecurityInfoHelperTest {

    @Autowired
    private PrepayAdaptorUpdateLineSecurityInfoHelper prepayAdaptorUpdateLineSecurityInfoHelper;

    @MockBean
    private PrepayCheckoutRedisHelper updateLineSecurityInfoRedisHelper;

    @MockBean
    private PrepayUpdateLineSecurityInfoFormatterUtil prepayUpdateLineSecurityInfoFormatterUtil;

    @Autowired
    private ObjectMapper mapper;

    @MockBean
    private PrepayAdaptorWebClient prepayAdaptorWebClient;

    @Value("${onevz.soe.prepay.checkout.test.mock}")
    private String mockDataLocation;

    private String orderWriteHelperMock = "/adaptor/helper/";
    @Test
    public void testUpdateLineSecurityInfoPositive() throws IOException {

        String requestString = FileReaderUtil.readFromFile("data/adaptor/helper/updateLineSecurityInfoRequest.json");
        String response ="{\"ecommSessionId\":\"1kjhlkliueijrlwkjelrjwl88lijeljrlkwjel\",\"curr_line\":1,\"lines\":[{\"mtn\":\"newLine1\",\"lineItemId\":\"newLine1\",\"deviceId\":\"dev16720145\",\"deviceSkuId\":\"sku4750108\",\"deviceSorId\":\"MLA73LL/A\",\"completedProcessSteps\":[\"GridWallPDP\"]}],\"pcsrfToken\":\"3iqjhlwekjqlwjelqkwjelqhwekuhwqijlwk\"})";
        String str = "prepay_odRequestData";
       // String prepayOdResponse = FileReaderUtil.readFromFile("data/adaptor/helper/updateLineSecurityInfoResponse.json");
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest mockServerHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        UpdateLineSecurityInfoRequest updateLineSecurityInfoRequest =  mapper.readValue(requestString, UpdateLineSecurityInfoRequest.class);
       //PrepaidODRequestData  redisData = mapper.readValue(response, PrepaidODRequestData.class);
        when(updateLineSecurityInfoRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<UpdateLineSecurityInfoResponse>> responseMono = prepayAdaptorUpdateLineSecurityInfoHelper.updateLineSecurityInfo(mockServerHttpRequest, updateLineSecurityInfoRequest);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> org.junit.Assert.assertNotNull(d));
        }
    @Test
    public void testUpdateLineSecurityInfoEmptyResponse() throws IOException {
        String prepayOdErrorResponseString = FileReaderUtil.readFromFile("data/adaptor/helper/updateLineSecurityInfoErrorRequest.json");
        String str = "prepay_odRequestData";
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest mockServerHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        when(updateLineSecurityInfoRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(Mono.just(str));
        UpdateLineSecurityInfoRequest updateLineSecurityInfoErrorRequest =  mapper.readValue(prepayOdErrorResponseString, UpdateLineSecurityInfoRequest.class);
        Mono<ResponseEntity<UpdateLineSecurityInfoResponse>> responseMono = prepayAdaptorUpdateLineSecurityInfoHelper.updateLineSecurityInfo(mockServerHttpRequest, updateLineSecurityInfoErrorRequest);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> org.junit.Assert.assertNotNull(d));
    }

    @Test
    public void updateLineSecurityTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/helper/updateLineSecurityInfoRequest.json");
        String redisString ="{\"ecommSessionId\":\"1kjhlkliueijrlwkjelrjwl88lijeljrlkwjel\",\"curr_line\":1,\"lines\":[{\"mtn\":\"mtn\",\"lineItemId\":\"newLine1\",\"deviceId\":\"dev16720145\",\"deviceSkuId\":\"sku4750108\",\"deviceSorId\":\"MLA73LL/A\",\"completedProcessSteps\":[\"GridWallPDP\"]}],\"pcsrfToken\":\"3iqjhlwekjqlwjelqkwjelqhwekuhwqijlwk\"})";
        String prepaidAdaptorWebClientRequest = FileReaderUtil.readFromFile("data/adaptor/helper/updateLineSecurityPrepaidAdaptorWebClientRequest.json");
        UpdateLineSecurityInfoRequest updateLineSecurityInfoRequest =  mapper.readValue(requestString, UpdateLineSecurityInfoRequest.class);
        PrepaidODRequestData redisStringMapper =  mapper.readValue(redisString, PrepaidODRequestData.class);
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest mockServerHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(prepaidAdaptorWebClientRequest));
        PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequestMapper =  mapper.readValue(prepaidAdaptorWebClientRequest, PrepaidAdaptorWebClientRequest.class);
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(),Mockito.any())).thenReturn(justResponse);
        when(updateLineSecurityInfoRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<UpdateLineSecurityInfoResponse>> responseMono = prepayAdaptorUpdateLineSecurityInfoHelper.updateLineSecurity(mockServerHttpRequest, prepaidAdaptorWebClientRequestMapper,redisStringMapper,updateLineSecurityInfoRequest);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> org.junit.Assert.assertNotNull(d));
    }

    @Test
    public void updateLineSecurityNotSuccessTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/helper/updateLineSecurityInfoRequest.json");
        String redisString ="{\"ecommSessionId\":\"1kjhlkliueijrlwkjelrjwl88lijeljrlkwjel\",\"curr_line\":1,\"lines\":[{\"mtn\":\"mtn\",\"lineItemId\":\"newLine1\",\"deviceId\":\"dev16720145\",\"deviceSkuId\":\"sku4750108\",\"deviceSorId\":\"MLA73LL/A\",\"completedProcessSteps\":[\"GridWallPDP\"]}],\"pcsrfToken\":\"3iqjhlwekjqlwjelqkwjelqhwekuhwqijlwk\"})";
        String prepaidAdaptorWebClientRequest = FileReaderUtil.readFromFile("data/adaptor/helper/updateLineSecurityPrepaidAdaptorWebClientRequest.json");
        UpdateLineSecurityInfoRequest updateLineSecurityInfoRequest =  mapper.readValue(requestString, UpdateLineSecurityInfoRequest.class);
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest mockServerHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        PrepaidODRequestData redisStringMapper =  mapper.readValue(redisString, PrepaidODRequestData.class);
        Mono<ResponseEntity<String>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(prepaidAdaptorWebClientRequest));
        PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequestMapper =  mapper.readValue(prepaidAdaptorWebClientRequest, PrepaidAdaptorWebClientRequest.class);
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(),Mockito.any())).thenReturn(justResponse);
     //   when(updateLineSecurityInfoRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<UpdateLineSecurityInfoResponse>> responseMono = prepayAdaptorUpdateLineSecurityInfoHelper.updateLineSecurity(mockServerHttpRequest, prepaidAdaptorWebClientRequestMapper,redisStringMapper,updateLineSecurityInfoRequest);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> org.junit.Assert.assertNotNull(d));
    }

    @Test
    public void updateLineSecurityInfo_emptyRedisTest() {
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest mockServerHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(updateLineSecurityInfoRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(Mono.just(""));
        Mono<ResponseEntity<UpdateLineSecurityInfoResponse>> actual = prepayAdaptorUpdateLineSecurityInfoHelper.updateLineSecurityInfo(mockServerHttpRequest, null);
        StepVerifier.create(actual).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void updateLineSecurityInfo_errorTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/helper/updateLineSecurityInfoRequest.json");
        String response ="{\"ecommSessionId\":\"1kjhlkliueijrlwkjelrjwl88lijeljrlkwjel\",\"curr_line\":1,\"lines\":[{\"mtn\":\"mtn\",\"lineItemId\":\"newLine1\",\"deviceId\":\"dev16720145\",\"deviceSkuId\":\"sku4750108\",\"deviceSorId\":\"MLA73LL/A\",\"completedProcessSteps\":[\"GridWallPDP\"]}],\"pcsrfToken\":\"3iqjhlwekjqlwjelqkwjelqhwekuhwqijlwk\"})";
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest mockServerHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        UpdateLineSecurityInfoRequest updateLineSecurityInfoRequest =  mapper.readValue(requestString, UpdateLineSecurityInfoRequest.class);
        when(updateLineSecurityInfoRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<UpdateLineSecurityInfoResponse>> actual = prepayAdaptorUpdateLineSecurityInfoHelper.updateLineSecurityInfo(mockServerHttpRequest, updateLineSecurityInfoRequest);
        StepVerifier.create(actual).expectError().verify();
    }

    @Test
    public void updateLineSecurityInfo_emptyRedisLinesTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/helper/updateLineSecurityInfoRequest.json");
        String response ="{\"ecommSessionId\":\"1kjhlkliueijrlwkjelrjwl88lijeljrlkwjel\",\"curr_line\":1,\"pcsrfToken\":\"3iqjhlwekjqlwjelqkwjelqhwekuhwqijlwk\"})";
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest mockServerHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        UpdateLineSecurityInfoRequest updateLineSecurityInfoRequest =  mapper.readValue(requestString, UpdateLineSecurityInfoRequest.class);
        when(updateLineSecurityInfoRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<UpdateLineSecurityInfoResponse>> actual = prepayAdaptorUpdateLineSecurityInfoHelper.updateLineSecurityInfo(mockServerHttpRequest, updateLineSecurityInfoRequest);
        StepVerifier.create(actual).expectError().verify();
    }

    @Test
    public void updateLineSecurity_exceptionTest() {
        Mono<ResponseEntity<String>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body("{\"payload\": {}"));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(justResponse);
        Mono<ResponseEntity<UpdateLineSecurityInfoResponse>> actual = prepayAdaptorUpdateLineSecurityInfoHelper.updateLineSecurity(null, new PrepaidAdaptorWebClientRequest(), null, null);
        StepVerifier.create(actual).assertNext(resp -> Assert.assertEquals(resp.getStatusCodeValue(), HttpStatus.INTERNAL_SERVER_ERROR.value())).expectComplete().verify();
    }

    @Test
    public void updateLineSecurity_successTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/helper/updateLineSecurityInfoRequest.json");
        UpdateLineSecurityInfoRequest request =  mapper.readValue(requestString, UpdateLineSecurityInfoRequest.class);
        String redisStr ="{\"ecommSessionId\":\"1kjhlkliueijrlwkjelrjwl88lijeljrlkwjel\",\"curr_line\":1,\"lines\":[{\"mtn\":\"mtn\",\"lineItemId\":\"newLine1\",\"deviceId\":\"dev16720145\",\"deviceSkuId\":\"sku4750108\",\"deviceSorId\":\"MLA73LL/A\",\"completedProcessSteps\":[\"GridWallPDP\"]},{\"mtn\":\"newline1\",\"lineItemId\":\"newLine1\",\"deviceId\":\"dev16720145\",\"deviceSkuId\":\"sku4750108\",\"deviceSorId\":\"MLA73LL/A\",\"completedProcessSteps\":[\"GridWallPDP\"]}],\"pcsrfToken\":\"3iqjhlwekjqlwjelqkwjelqhwekuhwqijlwk\"}";
        PrepaidODRequestData redisData = mapper.readValue(redisStr, PrepaidODRequestData.class);
        Mono<ResponseEntity<String>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body("{\"payload\": {}}"));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(justResponse);
        when(updateLineSecurityInfoRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<UpdateLineSecurityInfoResponse>> actual = prepayAdaptorUpdateLineSecurityInfoHelper.updateLineSecurity(null, new PrepaidAdaptorWebClientRequest(), redisData, request);
        StepVerifier.create(actual).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

}