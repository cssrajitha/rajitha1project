package onevz.soe.prepay.adaptor.checkout.exceptions;

import onevz.soe.prepay.adaptor.checkout.config.PrepayCheckoutAdaptorServiceTestConfig;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {PrepayCheckoutAdaptorServiceTestConfig.class})
@WebFluxTest(CommonPrepayServiceException.class)
public class CommonPrepayServiceExceptionTest {

    @Test
    public void exceptionTest() {
        try {
            throw new CommonPrepayServiceException(HttpStatus.CONFLICT, "Test exception");
        } catch(Exception e) {
            Assert.assertTrue(e instanceof CommonPrepayServiceException);
        }
    }

}