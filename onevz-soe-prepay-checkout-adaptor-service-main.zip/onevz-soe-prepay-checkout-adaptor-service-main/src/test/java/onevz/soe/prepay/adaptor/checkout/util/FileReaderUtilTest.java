package onevz.soe.prepay.adaptor.checkout.util;

import onevz.soe.prepay.adaptor.checkout.config.PrepayCheckoutAdaptorServiceTestConfig;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {PrepayCheckoutAdaptorServiceTestConfig.class})
@WebFluxTest(FileReaderUtil.class)
public class FileReaderUtilTest {

    @Test(expected=IllegalAccessException.class)
    public void testConstructorPrivate() throws Exception {
        FileReaderUtil.class.newInstance();
    }

    @Test
    public void readFromFileValidPathTest() {
        String response = FileReaderUtil.readFromFile("data/mockresponses/Checkout/MockResponse.json");
        Assert.assertNotNull(response);
        Assert.assertNotEquals("{}", response);
    }

    @Test
    public void readFromFileInvalidPathTest() {
        String response = FileReaderUtil.readFromFile("test/MockResponse.json");
        Assert.assertEquals("{}", response);
    }

}