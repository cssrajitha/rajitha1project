package onevz.soe.prepay.adaptor.checkout.config;

import onevz.soe.datastore.annotations.EnableDatastoreClients;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.test.context.TestPropertySource;

@Configuration
@ComponentScan(basePackages = { "onevz.spring.config","onevz.cxp.feature", "onevzw.soe.core.config", "onevz.soe.session","onevz.aem.errorhandling",
        "onevz.soe.spring.web.filter", "onevz.soe.cradle.client", "onevz.soe.wsclient.prepay.api.impl", "onevz.soe.wsclient.prepay.webclient", "onevz.soe.prepay.adaptor.checkout","onevz.soe.prepay.payment"})
@EnableDatastoreClients(value = {"onevz.soe.cradle", "onevz.soe.core.exception.datastore.client", "onevz.soe.security", "onevz.soe.session", "onevz.soe.cart.datastore.client", "onevz.aem.errorhandling",})
@TestPropertySource("classpath:application.properties")
public class PrepayCheckoutAdaptorServiceTestConfig {

	@Bean
    public MessageSource messageSource() {
        ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
 
        messageSource.setBasename("i18n/messages");
        messageSource.setUseCodeAsDefaultMessage(true);
 
        return messageSource;
    }
}
