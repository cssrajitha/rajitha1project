package onevz.soe.prepay.adaptor.checkout.helper;

import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.model.common.CartServiceCartInfo;
import onevz.soe.cart.model.common.CartServiceContextInfo;
import onevz.soe.cart.model.common.CartServiceCustomerInfo;
import onevz.soe.cart.model.common.CartServiceServiceHeader;
import onevz.soe.cart.model.initiateCheckout.InitiateCheckoutContext;
import onevz.soe.cart.model.initiateCheckout.InitiateCheckoutServiceBody;
import onevz.soe.cart.model.initiateCheckout.InitiateCheckoutServiceResponse;
import onevz.soe.cart.model.initiateCheckout.ValidateOrder;
import onevz.soe.cart.requests.InitiateCheckoutPEGARequest;
import onevz.soe.cart.responses.InitiateCheckoutPEGAResponse;
import onevz.soe.prepay.adaptor.checkout.config.PrepayCheckoutAdaptorServiceTestConfig;
import onevz.soe.prepay.adaptor.checkout.util.FileReaderUtil;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.net.URI;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {PrepayCheckoutAdaptorServiceTestConfig.class})
@WebFluxTest(PrepayAdaptorValidateOrderHelper.class)
public class PrepayAdaptorValidateOrderHelperTest {

    @Autowired
    private ObjectMapper mapper;

    @Autowired
    private PrepayAdaptorValidateOrderHelper prepayAdaptorValidateOrderHelper;

    @Value("${onevz.soe.prepay.checkout.test.mock}")
    private String mockDataLocation;

    private String orderWriteHelperMock = "/adaptor/helper/";


    @Test
    public void validateOrderTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/helper/validateOrderRequestString.json");
        String str="00";
        String str1="SUCCESS";

        InitiateCheckoutPEGARequest validateOrderPEGARequest = mapper.readValue(requestString, InitiateCheckoutPEGARequest.class);
        InitiateCheckoutPEGAResponse response = new InitiateCheckoutPEGAResponse();

        CartServiceServiceHeader validateOrderCartServiceHeader = new CartServiceServiceHeader();
        validateOrderCartServiceHeader.setStatusCode(str);
        validateOrderCartServiceHeader.setStatusMsg(str1);
        validateOrderCartServiceHeader.setServiceName(validateOrderPEGARequest.getServiceHeader().getServiceName());
        validateOrderCartServiceHeader.setUserId(validateOrderPEGARequest.getServiceHeader().getUserId());
        validateOrderCartServiceHeader.setSessionId(validateOrderPEGARequest.getServiceHeader().getSessionId());
        validateOrderCartServiceHeader.setCorrelationId(validateOrderPEGARequest.getServiceHeader().getCorrelationId());

        response.setServiceHeader(validateOrderCartServiceHeader);

        InitiateCheckoutServiceBody validateOrderServiceBody = new InitiateCheckoutServiceBody();
        InitiateCheckoutServiceResponse validateOrderServiceResponse = new InitiateCheckoutServiceResponse();
        InitiateCheckoutContext validateOrderServiceContext = new InitiateCheckoutContext();

        CartServiceContextInfo validateOrderContextInfo = new CartServiceContextInfo();
        CartServiceCartInfo validateOrderCartInfo = new CartServiceCartInfo();
        CartServiceCustomerInfo validateOrderCustomerInfo = new CartServiceCustomerInfo();

        validateOrderCustomerInfo.setCustomerType(validateOrderPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCustomerType());
        validateOrderCustomerInfo.setAccountNumber(validateOrderPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getAccountNumber());
        validateOrderCustomerInfo.setCartCreator(validateOrderPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCartCreator());
        validateOrderCustomerInfo.setProcessingMTN(validateOrderPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getProcessingMTN());
        validateOrderCustomerInfo.setRegisterNumber(validateOrderPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getRegisterNumber());
        validateOrderCustomerInfo.setGlobalId(validateOrderPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getGlobalId());
        String cradleFlowJourney = "qwe12s";
        validateOrderCustomerInfo.setCradleFlowJourney(cradleFlowJourney);
        validateOrderContextInfo.setCallReason(validateOrderPEGARequest.getServiceBody().getServiceRequest().getContext().getContextInfo().getCallReason());
        // TBD: Hardcoded Process Step value need to be read from Redis
        validateOrderContextInfo.setProcessStep("OrderReview");

        ValidateOrder validateOrder = new ValidateOrder();

        validateOrderServiceContext.setCartServiceContextInfo(validateOrderContextInfo);
        validateOrderServiceContext.setCartServiceCartInfo(validateOrderCartInfo);
        validateOrderServiceContext.setCustomerInfo(validateOrderCustomerInfo);
        validateOrderServiceContext.setValidateOrder(validateOrder);

        validateOrderServiceResponse.setContext(validateOrderServiceContext);

        validateOrderServiceBody.setServiceResponse(validateOrderServiceResponse);

        response.setServiceBody(validateOrderServiceBody);

        URI url = URI.create("http://localhost:15115/prepaid-adaptor/checkout/test");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<InitiateCheckoutPEGAResponse>>  actual = prepayAdaptorValidateOrderHelper.validateOrder(validateOrderPEGARequest);
        Mono<ResponseEntity<InitiateCheckoutPEGAResponse>>  responseMono = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));
               actual.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(actual).assertNext(d -> org.junit.Assert.assertNotNull(d));
    }

    @Test
    public void getCartServiceCustomerInfoTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/helper/validateOrderRequestString.json");
        InitiateCheckoutPEGARequest validateOrderPEGARequest = mapper.readValue(requestString, InitiateCheckoutPEGARequest.class);
        validateOrderPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().setThrottleName("|VZW|XYZ|");
        CartServiceCustomerInfo validateOrderCustomerInfo = ReflectionTestUtils.invokeMethod(prepayAdaptorValidateOrderHelper, "getCartServiceCustomerInfo", validateOrderPEGARequest);
        Assert.assertEquals("VZW", validateOrderCustomerInfo.getCradleFlowJourney());
    }

}