package onevz.soe.prepay.adaptor.checkout.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.channels.SOEChannels;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.constants.SOEConstants;
import onevz.soe.prepay.adaptor.checkout.config.PrepayCheckoutAdaptorServiceTestConfig;
import onevz.soe.wsclient.bpm.model.response.Error;
import org.junit.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { PrepayCheckoutAdaptorServiceTestConfig.class })
@WebFluxTest(PrepayAdaptorCheckoutUtil.class)
public class PrepayAdaptorCheckoutUtilTest {

    @Autowired
    private ObjectMapper mapper;

    @Autowired
    private PrepayAdaptorCheckoutUtil prepayAdaptorCheckoutUtil;

    @Test
    public void getChannelTest() {
        String channelId ="ACSS-NEXTGEN";
        SOEChannels soeChannels = SOEChannels.findByChannelName(channelId);
        assertNotNull(soeChannels.getChannelType());
        String actual = prepayAdaptorCheckoutUtil.getChannel(channelId);
        assertNotNull(actual);
    }

    @Test
    public void getChannelEmptyTest() {
        String actual = prepayAdaptorCheckoutUtil.getChannel(SOEConstants.EMPTY_STRING);
        assertNull(actual);
    }

    @Test
    public void getChannelErrorTest() {
        String channelId =null;
        SOEChannels soeChannels = null;
        assertNull(soeChannels);
        String actual = prepayAdaptorCheckoutUtil.getChannel(channelId);
        assertEquals(null, channelId);
    }

    @Test
    public void getChannelTypeTest() {
        String channelId ="ACSS-NEXTGEN";
        SOEChannels soeChannels = SOEChannels.findByChannelName(channelId);
        assertNotNull(soeChannels.getChannelType());
        String actual = prepayAdaptorCheckoutUtil.getChannelType(channelId);
        assertNotNull(actual);
    }

    @Test
    public void getChannelTypeErrorTest() {
        String channelId =null;
        SOEChannels soeChannels = null;
        assertNull(soeChannels);
        String actual = prepayAdaptorCheckoutUtil.getChannelType(channelId);
        assertEquals(null, channelId);
    }

    @Test
    public void removeSpecialCharactersTest() {
        String depletionLocationCode ="US-FL:FL";
        String channelId ="ACSS-NEXTGEN";
        String result = depletionLocationCode.replaceAll("[-+.^:,]","");
        assertNotNull(result);
        String actual = prepayAdaptorCheckoutUtil.removeSpecialCharacters(depletionLocationCode,channelId);
        assertNotNull(actual);
    }

    @Test
    public void removeSpecialCharactersDigitalTest() {
        String depletionLocationCode = "US-FL:FL";
        String channelId = "VZW-DOTCOM";
        String actual = prepayAdaptorCheckoutUtil.removeSpecialCharacters(depletionLocationCode, channelId);
        assertEquals(depletionLocationCode, actual);
    }

    @Test
    public void isDigitalTest() {
        String channelId ="VZW-DOTCOM";
        String channelType= prepayAdaptorCheckoutUtil.getChannelType(channelId);
        assertSame("Digital",channelType);
        boolean actual = prepayAdaptorCheckoutUtil.isDigital(channelId);
        assertTrue(actual);
    }

    @Test
    public void isDigitalTest1() {
        String channelId ="VZW-DOT";
        String channelType= prepayAdaptorCheckoutUtil.getChannelType(channelId);
        boolean actual = prepayAdaptorCheckoutUtil.isDigital(channelId);
        assertFalse(actual);
    }

    @Test
    public void isDigitalChannelTest() {
        String channelId ="VZW-DOTCOM";
        SOEChannels soeChannels = SOEChannels.findByChannelName(channelId);
        assertSame("Digital",soeChannels.getChannelType());
        boolean actual = prepayAdaptorCheckoutUtil.isDigitalChannel(channelId);
        assertTrue(actual);
    }

    @Test
    public void isDigitalChannelTest1() {
        String channelId ="VZW-DOT";
        SOEChannels soeChannels = SOEChannels.findByChannelName(channelId);
        boolean actual = prepayAdaptorCheckoutUtil.isDigitalChannel(channelId);
        assertFalse(actual);
    }

    @Test
    public void isDigitalChannelTest2() {
        String channelId = "ACSS-NEXTGEN";
        boolean actual = prepayAdaptorCheckoutUtil.isDigitalChannel(channelId);
        assertFalse(actual);
    }
   /* @Test
    public void responseToJsonEntityConverterTest() {
        List<HttpMessageConverter<?>> messageConverters = new ArrayList<HttpMessageConverter<?>>();
        MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        converter.setSupportedMediaTypes(Collections.singletonList(MediaType.ALL));
        messageConverters.add(converter);
        assertNotNull(messageConverters);
        List<HttpMessageConverter<?>> actual = prepayAdaptorCheckoutUtil.responseToJsonEntityConverter();
        assertNotNull(actual);
    }*/

    @Test
    public void firstStringWithInPipesTest() throws Exception {
        String throttleText ="|VZW|DOTCOM|";
        String response = "";
        final Pattern pattern = Pattern.compile("(?<=\\|)[^|]++(?=\\|)");
        final Matcher matcher = pattern.matcher(throttleText);
        assertTrue(matcher.find());
        assertNotNull(response);
        String actual = prepayAdaptorCheckoutUtil.firstStringWithInPipes(throttleText);
        assertNotNull(actual);
    }

    @Test
    public void firstStringWithInPipesFalseTest() {
        String throttleText = "VZW-DOTCOM";
        String actual = prepayAdaptorCheckoutUtil.firstStringWithInPipes(throttleText);
        assertEquals(SOEConstants.EMPTY_STRING, actual);
    }

    @Test
    public void buildErrorResponseTest() throws Exception{
        String name = "Error";
        String id = "12134";
        String message = "Test Error Mesaage";
        String errorCategory = "Client Error";
        List<Error> actual = prepayAdaptorCheckoutUtil.buildErrorResponse(name,id,message,errorCategory);
        assertNotNull(actual);
        assertTrue(!actual.isEmpty());
    }

    @Test
    public void getPrepayODServiceCommonHeadersTest() throws Exception{
        PrepaidODRequestData prepaidODRequestData = new PrepaidODRequestData();
        prepaidODRequestData.setEcommSessionId("123");
        prepaidODRequestData.setPCsrfToken("abc");
        String flow = "NSE";
        Map<String,String> actual = prepayAdaptorCheckoutUtil.getPrepayODServiceCommonHeaders(prepaidODRequestData,flow);
        assertNotNull(actual);
        assertEquals("application/json",actual.get("Content-Type"));
    }
    @Test
    public void getPrepayODServiceCommonHeadersTest2() throws Exception{
        PrepaidODRequestData prepaidODRequestData = new PrepaidODRequestData();
        prepaidODRequestData.setEcommSessionId("123");
        prepaidODRequestData.setPCsrfToken("abc");
        String flow = "NSEBYOD";
        Map<String,String> actual = prepayAdaptorCheckoutUtil.getPrepayODServiceCommonHeaders(prepaidODRequestData,flow);
        assertNotNull(actual);
        assertEquals("application/json",actual.get("Content-Type"));
    }
    @Test
    public void getPrepayODServiceCommonHeadersTest3() throws Exception{
        PrepaidODRequestData prepaidODRequestData = new PrepaidODRequestData();
        prepaidODRequestData.setEcommSessionId("123");
        prepaidODRequestData.setPCsrfToken("abc");
        String flow = "ESO";
        Map<String,String> actual = prepayAdaptorCheckoutUtil.getPrepayODServiceCommonHeaders(prepaidODRequestData,flow);
        assertNotNull(actual);
        assertEquals("application/json",actual.get("Content-Type"));
    }

    @ParameterizedTest
    @CsvSource({"NSP", "BYOD", "PASO", "AAL", "EUP", "NONE"})
    public void getPrepayODServiceCommonHeadersTest4(String flowName) {
        PrepaidODRequestData prepaidODRequestData = new PrepaidODRequestData();
        prepaidODRequestData.setEcommSessionId("");
        prepaidODRequestData.setPCsrfToken("");
        Map<String,String> actual = prepayAdaptorCheckoutUtil.getPrepayODServiceCommonHeaders(prepaidODRequestData,flowName);
        assertNotNull(actual);
    }

}