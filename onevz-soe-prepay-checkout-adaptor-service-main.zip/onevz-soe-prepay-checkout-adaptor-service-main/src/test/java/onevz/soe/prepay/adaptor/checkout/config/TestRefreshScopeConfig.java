package onevz.soe.prepay.adaptor.checkout.config;

import org.springframework.beans.factory.config.CustomScopeConfigurer;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.cloud.context.scope.refresh.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;

/**
 * Test configuration class for setting up a custom "refresh" scope.
 * This configuration is used in test environments to provide a
 * `RefreshScope` bean for Spring's context.
 */
@TestConfiguration
public class TestRefreshScopeConfig {
    /**
     * Creates and configures a `CustomScopeConfigurer` bean with a "refresh" scope.
     *
     * @return a `CustomScopeConfigurer` instance with the "refresh" scope added.
     */
    @Bean
    @Primary
    public static CustomScopeConfigurer customScopeConfigurer() {
        CustomScopeConfigurer configurer = new CustomScopeConfigurer();
        configurer.addScope("refresh", new RefreshScope());
        return configurer;
    }


}
