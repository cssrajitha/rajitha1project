package onevz.soe.prepay.adaptor.checkout.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.checkout.request.bpm.UpdateLineSecurityInfoRequest;
import onevz.soe.checkout.response.bpm.UpdateLineSecurityInfoResponse;
import onevz.soe.checkout.response.bpm.UpdateLineSecurityInfoServiceBody;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.common.model.PrepaidODRequestDataAccessorySkuIds;
import onevz.soe.common.model.PrepaidODRequestDataLines;
import onevz.soe.constants.SOEConstants;
import onevz.soe.prepay.adaptor.checkout.config.PrepayCheckoutAdaptorServiceTestConfig;
import onevz.soe.prepay.adaptor.checkout.model.updatelinesecurityinfo.request.UpdateLineSecurityInfoPrepayOdRequest;
import onevz.soe.prepay.adaptor.checkout.model.updatelinesecurityinfo.response.UpdateLineSecurityInfoPrepayOdResponse;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { PrepayCheckoutAdaptorServiceTestConfig.class })
@WebFluxTest(PrepayUpdateLineSecurityInfoFormatterUtil.class)
public class PrepayUpdateLineSecurityInfoFormatterUtilTest {

    @MockBean
    private PrepayUpdateLineSecurityInfoFormatterUtil prepayUpdateLineSecurityInfoFormatterUtil;

    @MockBean
    private PrepaidODRequestData prepaidODRequestData;

    @MockBean
    private UpdateLineSecurityInfoServiceBody updateLineSecurityInfoServiceBody;

    @Autowired
    private ObjectMapper mapper;

    @Value("${onevz.soe.prepay.checkout.test.mock}")
    private String mockDataLocation;

    private String utilMock = "/util/";

    @Test
    public void formatLineSecurityInfoRequestTest() throws JsonProcessingException, IOException {
        String requestString = FileReaderUtil.readFromFile("data/util/utilFormatLineSecurityInfoRequest.json");
        String redisDataString = FileReaderUtil.readFromFile("data/util/utilFormatLineSecurityInfoRedisData.json");
        UpdateLineSecurityInfoRequest request =mapper.readValue(requestString, UpdateLineSecurityInfoRequest.class);
        PrepaidODRequestData redisData = mapper.readValue(redisDataString, PrepaidODRequestData.class);
        UpdateLineSecurityInfoPrepayOdRequest  actual = prepayUpdateLineSecurityInfoFormatterUtil.formatLineSecurityInfoRequest(request, redisData);
        Mono.just(actual).subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(Mono.just(actual)).assertNext(d -> org.junit.Assert.assertNotNull(d));

    }

    @Test
    public void formatUpdateLineSecurityInfoResponseTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/util/utilFormatLineSecurityInfoRequest.json");
        String redisDataString = FileReaderUtil.readFromFile("data/util/utilFormatLineSecurityInfoRedisData.json");
        String restResponse = FileReaderUtil.readFromFile("data/util/utilFormatLineSecurityInfoRestResponse.json");
        UpdateLineSecurityInfoRequest validateOrderPEGARequest = mapper.readValue(requestString, UpdateLineSecurityInfoRequest.class);
        PrepaidODRequestData prepaidODRequestData = mapper.readValue(redisDataString,PrepaidODRequestData.class);
        UpdateLineSecurityInfoPrepayOdResponse updateLineSecurityInfoPrepayOdResponse = mapper.readValue(restResponse,UpdateLineSecurityInfoPrepayOdResponse.class);

        UpdateLineSecurityInfoResponse  actual = prepayUpdateLineSecurityInfoFormatterUtil.formatUpdateLineSecurityInfoResponse(prepaidODRequestData, validateOrderPEGARequest);
        Mono.just(actual).subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(Mono.just(actual)).assertNext(d -> org.junit.Assert.assertNotNull(d));
        }


    @Test
    public void formatUpdateLineSecurityInfoResponseTest_withAccountPin() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/util/utilFormatLineSecurityInfoRequest.json");
        String redisDataString = FileReaderUtil.readFromFile("data/util/utilFormatLineSecurityInfoRedisData.json");
        String restResponse = FileReaderUtil.readFromFile("data/util/utilFormatLineSecurityInfoRestResponse.json");
        UpdateLineSecurityInfoRequest validateOrderPEGARequest = mapper.readValue(requestString, UpdateLineSecurityInfoRequest.class);
        PrepaidODRequestData prepaidODRequestData = mapper.readValue(redisDataString,PrepaidODRequestData.class);
        prepaidODRequestData.setAccountPinAssignedtoAllLines(true);
        UpdateLineSecurityInfoPrepayOdResponse updateLineSecurityInfoPrepayOdResponse = mapper.readValue(restResponse,UpdateLineSecurityInfoPrepayOdResponse.class);

        UpdateLineSecurityInfoResponse  actual = prepayUpdateLineSecurityInfoFormatterUtil.formatUpdateLineSecurityInfoResponse(prepaidODRequestData, validateOrderPEGARequest);
        Mono.just(actual).subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(Mono.just(actual)).assertNext(d -> org.junit.Assert.assertNotNull(d));
    }

    @Test
    public void formatUpdateLineSecurityInfoResponseTest_Esim() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/util/utilFormatLineSecurityInfoRequest.json");
        String redisDataString = FileReaderUtil.readFromFile("data/util/utilFormatLineSecurityInfoRedisData.json");
        String restResponse = FileReaderUtil.readFromFile("data/util/utilFormatLineSecurityInfoRestResponse.json");
        UpdateLineSecurityInfoRequest validateOrderPEGARequest = mapper.readValue(requestString, UpdateLineSecurityInfoRequest.class);
        PrepaidODRequestData prepaidODRequestData = mapper.readValue(redisDataString,PrepaidODRequestData.class);
        prepaidODRequestData.setAccountPinAssignedtoAllLines(true);
        PrepaidODRequestDataLines prepaidODRequestDataLines= prepaidODRequestData.getLines().get(0);
        prepaidODRequestDataLines.setESimOnly(true);
        prepaidODRequestDataLines.setAccessorySkuIds(null);
        UpdateLineSecurityInfoPrepayOdResponse updateLineSecurityInfoPrepayOdResponse = mapper.readValue(restResponse,UpdateLineSecurityInfoPrepayOdResponse.class);

        UpdateLineSecurityInfoResponse  actual = prepayUpdateLineSecurityInfoFormatterUtil.formatUpdateLineSecurityInfoResponse(prepaidODRequestData, validateOrderPEGARequest);
        Mono.just(actual).subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(Mono.just(actual)).assertNext(d -> org.junit.Assert.assertNotNull(d));
    }

    @Test
    public void formatUpdateLineSecurityInfoResponseTest_Esim1() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/util/utilFormatLineSecurityInfoRequest.json");
        String redisDataString = FileReaderUtil.readFromFile("data/util/utilFormatLineSecurityInfoRedisData.json");
        String restResponse = FileReaderUtil.readFromFile("data/util/utilFormatLineSecurityInfoRestResponse.json");
        UpdateLineSecurityInfoRequest validateOrderPEGARequest = mapper.readValue(requestString, UpdateLineSecurityInfoRequest.class);
        PrepaidODRequestData prepaidODRequestData = mapper.readValue(redisDataString,PrepaidODRequestData.class);
        prepaidODRequestData.setAccountPinAssignedtoAllLines(true);
        PrepaidODRequestDataLines prepaidODRequestDataLines= prepaidODRequestData.getLines().get(0);
        prepaidODRequestDataLines.setESimEnabledDevice(true);
        UpdateLineSecurityInfoPrepayOdResponse updateLineSecurityInfoPrepayOdResponse = mapper.readValue(restResponse,UpdateLineSecurityInfoPrepayOdResponse.class);

        UpdateLineSecurityInfoResponse  actual = prepayUpdateLineSecurityInfoFormatterUtil.formatUpdateLineSecurityInfoResponse(prepaidODRequestData, validateOrderPEGARequest);
        Mono.just(actual).subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(Mono.just(actual)).assertNext(d -> org.junit.Assert.assertNotNull(d));
    }

    @Test
    public void formatUpdateLineSecurityInfoResponseTest_simId() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/util/utilFormatLineSecurityInfoRequest.json");
        String redisDataString = FileReaderUtil.readFromFile("data/util/utilFormatLineSecurityInfoRedisData.json");
        String restResponse = FileReaderUtil.readFromFile("data/util/utilFormatLineSecurityInfoRestResponse.json");
        UpdateLineSecurityInfoRequest validateOrderPEGARequest = mapper.readValue(requestString, UpdateLineSecurityInfoRequest.class);
        PrepaidODRequestData prepaidODRequestData = mapper.readValue(redisDataString,PrepaidODRequestData.class);
        prepaidODRequestData.setAccountPinAssignedtoAllLines(true);
        PrepaidODRequestDataLines prepaidODRequestDataLines= prepaidODRequestData.getLines().get(0);
        prepaidODRequestDataLines.setSimId("simId");
        UpdateLineSecurityInfoPrepayOdResponse updateLineSecurityInfoPrepayOdResponse = mapper.readValue(restResponse,UpdateLineSecurityInfoPrepayOdResponse.class);

        UpdateLineSecurityInfoResponse  actual = prepayUpdateLineSecurityInfoFormatterUtil.formatUpdateLineSecurityInfoResponse(prepaidODRequestData, validateOrderPEGARequest);
        Mono.just(actual).subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(Mono.just(actual)).assertNext(d -> org.junit.Assert.assertNotNull(d));
    }

    @Test
    public void formatUpdateLineSecurityInfoResponseTest_smartwatch() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/util/utilFormatLineSecurityInfoRequest.json");
        String redisDataString="{\"ecommSessionId\":\"eyJhbGciOiJIUzI1NiJ9.eyJkYXRhIjp7ImNvcnJlbGF0aW9uSWQiOiJQT1MtRC01MDkwNTc4NC00YTYwLTRiOGEtYmE2Mi1jMTBhNGJkYjJmYzF7ZDR9IiwiU0VTU0lPTl9JRCI6IlBPUy1ELTUwOTA1Nzg0LTRhNjAtNGI4YS1iYTYyLWMxMGE0YmRiMmZjMXtkNH0iLCJwbGF5U2Vzc2lvbiI6IlBPUy1ELTUwOTA1Nzg0LTRhNjAtNGI4YS1iYTYyLWMxMGE0YmRiMmZjMXtkNH0ifSwibmJmIjoxNzA2ODAyNDA5LCJpYXQiOjE3MDY4MDI0MDl9.ODRLMrFFzDb6kfeZCXnXgzZkzkveBreaKz3cv2rgZLQ\",\"curr_line\":1,\"lines\":[{\"mtn\":\"newLine1\",\"deviceId\":\"dev14080075\",\"deviceSkuId\":\"sku4080156\",\"deviceSorId\":\"MYYR2LL/A\",\"completedProcessSteps\":[\"BYODLandingPage\"],\"checkoutFlag\":false,\"imageUrl\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_SE_Nike_LTE_40mm_Silver_Aluminum_Pure_Platinum_Black_Nike_Sport_Band_1?\",\"displayName\":\"WatchSESilverAluminumCasewithPurePlatinumNikeSportBand40MM\",\"capacity\":\"\",\"color\":\"Silver(Aluminum)\",\"manufacturer\":\"Apple\",\"planSorId\":\"28445\",\"description\":\"WatchSESilverAluminumCasewithPurePlatinumNikeSportBand40MM\",\"numAssigned\":false,\"securityPinAssigned\":false,\"accountOwner\":false,\"flow\":\"NSEBYOD\",\"imei\":\"352933119570873\",\"stageCheckpointFlag\":true,\"uniqueDeviceId\":\"dev14080075_64855074\",\"smartPhone\":false,\"smartWatch\":true,\"basicPhone\":false,\"dataDevice\":false,\"connectedCar\":false,\"planUpdated\":false,\"osType\":\"APPLEIOS\",\"trackIsNumberShareBanner\":false,\"numbershareEligibleOS\":\"APPLEIOS\",\"numberShareEligibile\":true,\"standaloneEligibile\":true,\"transferNumberEligible\":true,\"esimOnly\":true,\"numShared\":false,\"esimEnabledDevice\":false,\"paired\":false,\"esimCompatibleDevice\":false}],\"numberAssignedToAllLines\":false,\"numberSharedToAllLines\":false,\"totalNumAssignedLines\":0,\"accountPinAssignedtoAllLines\":false,\"zipCode\":\"30004\",\"autoPay\":false,\"accountOwner\":\"newLine1\",\"refillCardNumbers\":{},\"loggedIn\":false,\"enableSWNumberSelectionBanner\":false,\"orderConfirmation\":false,\"pcsrfToken\":\"d113658fbd30a0bc1dcfeb76795eef6ba9ced7e0-1706802409121-6d7ae25fc76622871574f6fe\"}";
        //String redisDataString = FileReaderUtil.readFromFile("data/util/utilFormatLineSecurityInfoRedisData.json");
        String restResponse = FileReaderUtil.readFromFile("data/util/utilFormatLineSecurityInfoRestResponse.json");
        UpdateLineSecurityInfoRequest validateOrderPEGARequest = mapper.readValue(requestString, UpdateLineSecurityInfoRequest.class);
        PrepaidODRequestData prepaidODRequestData = mapper.readValue(redisDataString,PrepaidODRequestData.class);
        prepaidODRequestData.setAccountPinAssignedtoAllLines(true);
        PrepaidODRequestDataLines prepaidODRequestDataLines= prepaidODRequestData.getLines().get(0);
        UpdateLineSecurityInfoPrepayOdResponse updateLineSecurityInfoPrepayOdResponse = mapper.readValue(restResponse,UpdateLineSecurityInfoPrepayOdResponse.class);

        UpdateLineSecurityInfoResponse  actual = prepayUpdateLineSecurityInfoFormatterUtil.formatUpdateLineSecurityInfoResponse(prepaidODRequestData, validateOrderPEGARequest);
        Mono.just(actual).subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(Mono.just(actual)).assertNext(d -> org.junit.Assert.assertNotNull(d));
    }

    @Test
    public void formatUpdateLineSecurityInfoResponseTest_accessory() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/util/utilFormatLineSecurityInfoRequest.json");
        String redisDataString = FileReaderUtil.readFromFile("data/util/utilFormatLineSecurityInfoRedisData.json");
        String restResponse = FileReaderUtil.readFromFile("data/util/utilFormatLineSecurityInfoRestResponse.json");
        UpdateLineSecurityInfoRequest validateOrderPEGARequest = mapper.readValue(requestString, UpdateLineSecurityInfoRequest.class);
        PrepaidODRequestData prepaidODRequestData = mapper.readValue(redisDataString,PrepaidODRequestData.class);
        prepaidODRequestData.setAccountPinAssignedtoAllLines(true);
        PrepaidODRequestDataLines prepaidODRequestDataLines= prepaidODRequestData.getLines().get(0);
        prepaidODRequestDataLines.setSimId("simId");
        List<PrepaidODRequestDataAccessorySkuIds> list=new ArrayList<>();
        prepaidODRequestDataLines.setAccessorySkuIds(list);
        UpdateLineSecurityInfoPrepayOdResponse updateLineSecurityInfoPrepayOdResponse = mapper.readValue(restResponse,UpdateLineSecurityInfoPrepayOdResponse.class);

        UpdateLineSecurityInfoResponse  actual = prepayUpdateLineSecurityInfoFormatterUtil.formatUpdateLineSecurityInfoResponse(prepaidODRequestData, validateOrderPEGARequest);
        Mono.just(actual).subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(Mono.just(actual)).assertNext(d -> org.junit.Assert.assertNotNull(d));
    }

    @Test
    public void nextProcessingMtnTest() {
        String actual = ReflectionTestUtils.invokeMethod(prepayUpdateLineSecurityInfoFormatterUtil, "nextProcessingMtn", SOEConstants.EMPTY_STRING, null);
        Assert.assertEquals(SOEConstants.EMPTY_STRING, actual);
    }

    @Test
    public void nextProcessingMtn_withRedisDataTest() throws JsonProcessingException {
        String redisString = "{\"ecommSessionId\":\"1kjhlkliueijrlwkjelrjwl88lijeljrlkwjel\",\"curr_line\":1,\"lines\":[{\"mtn\":\"newLine1\", \"securityPinAssigned\":true,\"lineItemId\":\"newLine1\",\"deviceId\":\"dev16720145\",\"deviceSkuId\":\"sku4750108\",\"deviceSorId\":\"MLA73LL/A\",\"completedProcessSteps\":[\"GridWallPDP\"]},{\"mtn\":\"newLine2\", \"securityPinAssigned\":false,\"lineItemId\":\"newLine1\",\"deviceId\":\"dev16720145\",\"deviceSkuId\":\"sku4750108\",\"deviceSorId\":\"MLA73LL/A\",\"completedProcessSteps\":[\"GridWallPDP\"]}],\"pcsrfToken\":\"3iqjhlwekjqlwjelqkwjelqhwekuhwqijlwk\",\"paypalPaRes\":\"\",\"paypalMD\":\"\"}";
        PrepaidODRequestData redisData = mapper.readValue(redisString, PrepaidODRequestData.class);
        String actual = ReflectionTestUtils.invokeMethod(prepayUpdateLineSecurityInfoFormatterUtil, "nextProcessingMtn", "newLine1", redisData);
        Assert.assertEquals("newLine2", actual);
    }

}