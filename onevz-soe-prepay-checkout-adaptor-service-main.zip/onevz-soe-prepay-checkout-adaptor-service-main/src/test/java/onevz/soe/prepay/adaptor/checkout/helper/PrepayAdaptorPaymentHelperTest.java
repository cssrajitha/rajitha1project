package onevz.soe.prepay.adaptor.checkout.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.channels.SOEChannels;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.constants.SOEConstants;
import onevz.soe.od.model.VZWPrepayRefillCardVO;
import onevz.soe.prepay.adaptor.checkout.constants.PrepayAdaptorCheckoutConstants;
import onevz.soe.prepay.adaptor.checkout.model.payment.request.RequestMeta;
import onevz.soe.prepay.adaptor.checkout.model.payment.request.ValidateCardCXPRequest;
import onevz.soe.prepay.adaptor.checkout.util.FileReaderUtil;
import onevz.soe.prepay.payment.request.common.PaymentsSessionData;
import onevz.soe.prepay.payment.request.cxp.RefillCardCXPRequest;
import onevz.soe.prepay.payment.response.cxp.RefillCardCXPResponse;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.session.constants.SessionConstants;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import org.apache.hc.core5.http.ContentType;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.net.URI;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static onevz.soe.prepay.payment.constants.PaymentConstants.SAFE_TECH_SESSION_ID_KEY;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@WebFluxTest(PrepayAdaptorPaymentHelper.class)
public class PrepayAdaptorPaymentHelperTest {


    @Autowired
    private ObjectMapper objectMapper;

    @InjectMocks
    PrepayAdaptorPaymentHelper prepayAdaptorPaymentHelper;

    @Mock
    ObjectMapper mapper;

    @Mock
    PrepayAdaptorWebClient prepayAdaptorWebClient;

    @Mock
    SOELoginSessionBean sessionBean;

    @Mock
    private PrepayCheckoutRedisHelper prepayCheckoutRedisHelper;

    @Value("${onevz.soe.prepay.checkout.test.mock}")
    private String mockDataLocation;

    private String paymentWriteHelperMock = "/payment/helper/";
    private PaymentsSessionData sessionData = null;

    @Before
    public void setup() {
        objectMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        when(sessionBean.setSessionData(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(sessionBean.getSessionData(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new HashMap<>()));
        try {
            String sessionDataStr = FileReaderUtil.readFromFile("data/payment/redisResponse.json");
            sessionData = objectMapper.readValue(sessionDataStr, PaymentsSessionData.class);
            final String token = UUID.randomUUID().toString();
            sessionData.setCartId(token);
            sessionData.setChannelId(SOEChannels.VZW_DOTCOM.getChannelName());
            sessionData.setCaseId(token);

        } catch (Exception e) {
            e.printStackTrace();
        }

        when(sessionBean.getSessionData(Arrays.asList(SessionConstants.MTN_KEY, SessionConstants.ACCOUNT_NUMBER_KEY,SAFE_TECH_SESSION_ID_KEY))).thenReturn(Mono.just(new HashMap<>()));
        when(sessionBean.getSessionData(Mockito.any(), Mockito.any())).thenReturn(Mono.just(sessionData));
    }
    @Test
    public void getUpdatePaymentTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/helper/paymentGetUpdatePaymentRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/helper/paymentGetUpdatePaymentResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestData.json");
        String str = "prepay_odRequestData";

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");

        ResponseEntity<String> responseEntity = ResponseEntity.status(HttpStatus.OK).body(responseString);

        String mockRedisData = objectMapper.writeValueAsString(redisData);
        ValidateCardCXPRequest request = objectMapper.readValue(requestString, ValidateCardCXPRequest.class);
        Object response = objectMapper.readValue(responseString,  Object.class);
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        ServerHttpRequest serverHttpRequest = mock(ServerHttpRequest.class);
        Mono<String> getDataResponse = Mono.just(str);
        Map<String, String> requestData = new HashMap<>();

        Map<String, String> headers = new HashMap<>();
        String cookies = "ECOMM_SESSION=" + "eCommSessionId" + "; p_csrftkn="
                + "pcsrfToken";
        headers.put("Cookie", cookies);
        headers.put("p-csrf-token", requestData.get("pcsrfToken"));
        headers.put("Content-Type", String.valueOf(ContentType.APPLICATION_JSON));
        headers.put("channelId", "VZW-DOTCOM");

        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        //when(prepayCheckoutRedisHelper.handleRedisData(Mockito.any())).thenReturn(requestData);
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(requestString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(),Mockito.any())).thenReturn(webClientResponse);

        ValidateCardCXPRequest validateCardCXPRequest = new ValidateCardCXPRequest();
        RequestMeta requestMeta = new RequestMeta();
        requestMeta.setClient("VZW");
        requestMeta.setUser("23wdw2");
        requestMeta.setClientCorrrelationId("sd2324");
        requestMeta.setTimestamp("23");
        validateCardCXPRequest.setMeta(requestMeta);

        Mono<Object> responseMono = prepayAdaptorPaymentHelper.getUpdatePayment(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> org.junit.Assert.assertNotNull(d));
    }

    @Test
    public void getUpdatePaymentErrorTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/helper/paymentGetUpdatePaymentRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/helper/paymentGetUpdatePaymentResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestData.json");

        ValidateCardCXPRequest request = objectMapper.readValue(requestString, ValidateCardCXPRequest.class);
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<String> getDataResponse = Mono.just(prepaidODRequestDataString);
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        Mono<Object> responseMono = prepayAdaptorPaymentHelper.getUpdatePayment(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> org.junit.Assert.assertNotNull(d));
    }

    @Test
    public void getUpdatePayment_errorTest() {
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(SOEConstants.EMPTY_STRING));
        Mono<Object> actual = prepayAdaptorPaymentHelper.getUpdatePayment(null, null);
        StepVerifier.create(actual).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void getUpdatePayment_statusErrorTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/helper/paymentGetUpdatePaymentRequest.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestData.json");
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        ValidateCardCXPRequest request = objectMapper.readValue(requestString, ValidateCardCXPRequest.class);
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Map<String, String> requestData = new HashMap<>();
        Map<String, String> headers = new HashMap<>();
        String cookies = "ECOMM_SESSION=" + "eCommSessionId" + "; p_csrftkn="
                + "pcsrfToken";
        headers.put("Cookie", cookies);
        headers.put("p-csrf-token", requestData.get("pcsrfToken"));
        headers.put("Content-Type", String.valueOf(ContentType.APPLICATION_JSON));
        headers.put("channelId", "VZW-DOTCOM");
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(requestString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(),Mockito.any())).thenReturn(webClientResponse);

        ValidateCardCXPRequest validateCardCXPRequest = new ValidateCardCXPRequest();
        RequestMeta requestMeta = new RequestMeta();
        requestMeta.setClient("VZW");
        requestMeta.setUser("23wdw2");
        requestMeta.setClientCorrrelationId("sd2324");
        requestMeta.setTimestamp("23");
        validateCardCXPRequest.setMeta(requestMeta);
        Mono<Object> actual = prepayAdaptorPaymentHelper.getUpdatePayment(httpHeader, request);
        StepVerifier.create(actual).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void getUpdatePayment_exceptionTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/helper/paymentGetUpdatePaymentRequest.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestData.json");
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        ValidateCardCXPRequest request = objectMapper.readValue(requestString, ValidateCardCXPRequest.class);
        URI url = URI.create("http://localhost/addportin");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Map<String, String> requestData = new HashMap<>();

        Map<String, String> headers = new HashMap<>();
        String cookies = "ECOMM_SESSION=" + "eCommSessionId" + "; p_csrftkn="
                + "pcsrfToken";
        headers.put("Cookie", cookies);
        headers.put("p-csrf-token", requestData.get("pcsrfToken"));
        headers.put("Content-Type", String.valueOf(ContentType.APPLICATION_JSON));
        headers.put("channelId", "VZW-DOTCOM");

        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        requestString = requestString.replace("{", "");
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(requestString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(),Mockito.any())).thenReturn(webClientResponse);

        ValidateCardCXPRequest validateCardCXPRequest = new ValidateCardCXPRequest();
        RequestMeta requestMeta = new RequestMeta();
        requestMeta.setClient("VZW");
        requestMeta.setUser("23wdw2");
        requestMeta.setClientCorrrelationId("sd2324");
        requestMeta.setTimestamp("23");
        validateCardCXPRequest.setMeta(requestMeta);
        Mono<Object> actual = prepayAdaptorPaymentHelper.getUpdatePayment(httpHeader, request);
        StepVerifier.create(actual).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addRefillCardTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/helper/addRefillCardRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/helper/prepaidOD-addRefillCardResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestData.json");
        Object request = objectMapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = objectMapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = objectMapper.readValue(responseString, RefillCardCXPResponse.class);
        PrepaidODRequestData prepaidODRequestData = objectMapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        VZWPrepayRefillCardVO prepaidODAddRefillCardResponse = objectMapper.readValue(responseString, VZWPrepayRefillCardVO.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/addRefillCard");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(responseString, HttpStatus.OK)));
        when(prepayCheckoutRedisHelper.upsertDataIntoRedisAsStr(eq(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(mapper.readValue(Mockito.anyString(), eq(PrepaidODRequestData.class))).thenReturn(prepaidODRequestData);
        when(mapper.readValue(Mockito.anyString(), eq(VZWPrepayRefillCardVO.class))).thenReturn(prepaidODAddRefillCardResponse);
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentHelper.addRefillCard(httpRequest,refillCardCXPRequest);

        StepVerifier.create(controllerResp).assertNext(resp-> Assert.assertNotNull(resp)).verifyComplete();
    }

    @Test
    public void addRefillCardStatus500Test() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/helper/addRefillCardRequest.json");
        String responseString = "{\"status\":\"500\",\"payload\":{\"cqContent\":{},\"pageData\":{\"paymentGrpIdList\":[{\"balance\":0.0,\"paymentGrpId\":\"Sbe8384c300b133b5aeb5e68fc2270ab2{as1}_pin_586599070\",\"amounApplied\":50.0,\"pincard\":\"9777680205\"}],\"remainingDue\":25.0}}}";
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestData.json");
        Object request = objectMapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = objectMapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = objectMapper.readValue(responseString, RefillCardCXPResponse.class);
        PrepaidODRequestData prepaidODRequestData = objectMapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        VZWPrepayRefillCardVO prepaidODAddRefillCardErrResponse = objectMapper.readValue(responseString, VZWPrepayRefillCardVO.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/addRefillCard");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(responseString, HttpStatus.OK)));
        when(mapper.readValue(Mockito.anyString(), eq(PrepaidODRequestData.class))).thenReturn(prepaidODRequestData);
        when(mapper.readValue(Mockito.anyString(), eq(VZWPrepayRefillCardVO.class))).thenReturn(prepaidODAddRefillCardErrResponse);
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentHelper.addRefillCard(httpRequest,refillCardCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> Assert.assertNotNull(resp)).verifyComplete();
    }

    @Test
    public void addRefillCardStatus00Test() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/helper/addRefillCardRequest.json");
        String responseString = "{\"status\":\"00\",\"payload\":{\"cqContent\":{},\"pageData\":{\"paymentGrpIdList\":[{\"balance\":0.0,\"paymentGrpId\":\"Sbe8384c300b133b5aeb5e68fc2270ab2{as1}_pin_586599070\",\"amounApplied\":50.0,\"pincard\":\"9777680205\"}],\"remainingDue\":25.0}}}";
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestData.json");
        Object request = objectMapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = objectMapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = objectMapper.readValue(responseString, RefillCardCXPResponse.class);
        PrepaidODRequestData prepaidODRequestData = objectMapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        VZWPrepayRefillCardVO prepaidODAddRefillCardErrResponse = objectMapper.readValue(responseString, VZWPrepayRefillCardVO.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/addRefillCard");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(responseString, HttpStatus.OK)));
        when(mapper.readValue(Mockito.anyString(), eq(PrepaidODRequestData.class))).thenReturn(prepaidODRequestData);
        when(mapper.readValue(Mockito.anyString(), eq(VZWPrepayRefillCardVO.class))).thenReturn(prepaidODAddRefillCardErrResponse);
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentHelper.addRefillCard(httpRequest,refillCardCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> Assert.assertNotNull(resp)).verifyComplete();
    }

    @Test
    public void addRefillCardExceptionTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/helper/addRefillCardRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/helper/prepaidOD-addRefillCardResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestData.json");
        Object request = objectMapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = objectMapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = objectMapper.readValue(responseString, RefillCardCXPResponse.class);
        PrepaidODRequestData prepaidODRequestData = objectMapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/addRefillCard");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(responseString, HttpStatus.OK)));
        when(mapper.readValue(Mockito.anyString(), eq(PrepaidODRequestData.class))).thenReturn(prepaidODRequestData);
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentHelper.addRefillCard(httpRequest,refillCardCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> Assert.assertNotNull(resp)).verifyComplete();
    }

    @Test
    public void addRefillCardRedisErrorTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/helper/addRefillCardRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/helper/addRefillCardResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestData.json");
        Object request = objectMapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = objectMapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = objectMapper.readValue(responseString, RefillCardCXPResponse.class);
        //PrepaidODRequestData prepaidODRequestData = mapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/addRefillCard");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(""));
        //when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(responseString, HttpStatus.OK)));
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentHelper.addRefillCard(httpRequest, refillCardCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> Assert.assertNotNull(new RefillCardCXPResponse())).verifyComplete();
    }

    @Test
    public void addRefillCardRedisInvalidTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/helper/addRefillCardRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/helper/addRefillCardResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestData.json");
        Object request = objectMapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = objectMapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = objectMapper.readValue(responseString, RefillCardCXPResponse.class);
        //PrepaidODRequestData prepaidODRequestData = mapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/addRefillCard");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just("failed"));
        //when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(responseString, HttpStatus.OK)));
        when(mapper.readValue(Mockito.anyString(), eq(PrepaidODRequestData.class))).thenThrow(JsonProcessingException.class);
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentHelper.addRefillCard(httpRequest, refillCardCXPRequest);

        StepVerifier.create(controllerResp).assertNext(resp-> Assert.assertNotNull(new RefillCardCXPResponse())).verifyComplete();
    }

    @Test
    public void addRefillCardServiceErrorStatusTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/helper/addRefillCardRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/helper/addRefillCardResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestData.json");
        Object request = objectMapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = objectMapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = objectMapper.readValue(responseString, RefillCardCXPResponse.class);
        PrepaidODRequestData prepaidODRequestData = objectMapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/addRefillCard");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>("", HttpStatus.INTERNAL_SERVER_ERROR)));
        when(mapper.readValue(Mockito.anyString(), eq(PrepaidODRequestData.class))).thenReturn(prepaidODRequestData);
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentHelper.addRefillCard(httpRequest, refillCardCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> resp.getStatusCode().equals(HttpStatus.INTERNAL_SERVER_ERROR)).verifyComplete();
    }

    @Test
    public void addRefillCardServiceErrorTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/helper/addRefillCardRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/helper/addRefillCardResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestData.json");
        Object request = objectMapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = objectMapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = objectMapper.readValue(responseString, RefillCardCXPResponse.class);
        PrepaidODRequestData prepaidODRequestData = objectMapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/addRefillCard");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>("", HttpStatus.OK)));
        when(mapper.readValue(Mockito.anyString(), eq(PrepaidODRequestData.class))).thenReturn(prepaidODRequestData);
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentHelper.addRefillCard(httpRequest, refillCardCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> Assert.assertNotNull(resp)).verifyComplete();
    }

    @Test
    public void addRefillCardServiceErrorRespTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/helper/addRefillCardRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/helper/addRefillCardResponse.json");
        String prepaidODAddRefillErrRespString = FileReaderUtil.readFromFile("data/payment/helper/prepaidOD-addRefillCardErrResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestData.json");
        Object request = objectMapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = objectMapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = objectMapper.readValue(responseString, RefillCardCXPResponse.class);
        PrepaidODRequestData prepaidODRequestData = objectMapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/addRefillCard");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(prepaidODAddRefillErrRespString, HttpStatus.INTERNAL_SERVER_ERROR)));
        when(mapper.readValue(Mockito.anyString(), eq(PrepaidODRequestData.class))).thenReturn(prepaidODRequestData);
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentHelper.addRefillCard(httpRequest, refillCardCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> Assert.assertNotNull(resp)).verifyComplete();
    }

    @Test
    public void addRefillCardServiceCaptchErrorRespTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/helper/addRefillCardRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/helper/addRefillCardResponse.json");
        String prepaidODAddRefillErrRespString = FileReaderUtil.readFromFile("data/payment/helper/prepaidOD-addRefillCardCaptchaErrResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestData.json");
        Object request = objectMapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = objectMapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = objectMapper.readValue(responseString, RefillCardCXPResponse.class);
        PrepaidODRequestData prepaidODRequestData = objectMapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        VZWPrepayRefillCardVO prepaidODAddRefillErrResponse = objectMapper.readValue(prepaidODAddRefillErrRespString, VZWPrepayRefillCardVO.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/addRefillCard");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(prepaidODAddRefillErrRespString, HttpStatus.INTERNAL_SERVER_ERROR)));
        when(mapper.readValue(Mockito.anyString(), eq(PrepaidODRequestData.class))).thenReturn(prepaidODRequestData);
        when(mapper.readValue(Mockito.anyString(), eq(VZWPrepayRefillCardVO.class))).thenReturn(prepaidODAddRefillErrResponse);
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentHelper.addRefillCard(httpRequest, refillCardCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> Assert.assertNotNull(resp)).verifyComplete();
    }

    @Test
    public void addRefillCardServiceDuplicateErrorRespTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/helper/addRefillCardRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/helper/addRefillCardResponse.json");
        String prepaidODAddRefillErrRespString = FileReaderUtil.readFromFile("data/payment/helper/prepaidOD-addRefillCardErrResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestDataWithMultipleRefillCards.json");
        Object request = objectMapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = objectMapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = objectMapper.readValue(responseString, RefillCardCXPResponse.class);
        PrepaidODRequestData prepaidODRequestData = objectMapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/addRefillCard");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(prepaidODAddRefillErrRespString, HttpStatus.INTERNAL_SERVER_ERROR)));
        when(mapper.readValue(Mockito.anyString(), eq(PrepaidODRequestData.class))).thenReturn(prepaidODRequestData);
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentHelper.addRefillCard(httpRequest, refillCardCXPRequest);
        Mockito.mockingDetails(mapper).printInvocations();
        StepVerifier.create(controllerResp).assertNext(resp-> Assert.assertNotNull(resp)).verifyComplete();
    }

    @Test
    public void removeRefillCardTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/helper/removeRefillCardRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/helper/removeRefillCardResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestData.json");
        String prepaidODRemoveRefillCardResponseStr = FileReaderUtil.readFromFile("data/payment/helper/prepaidOD-removeRefillCardResponse.json");
        Object request = objectMapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = objectMapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = objectMapper.readValue(responseString, RefillCardCXPResponse.class);
        PrepaidODRequestData prepaidODRequestData = objectMapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        VZWPrepayRefillCardVO prepaidODRemoveRefillCardResponse = objectMapper.readValue(prepaidODRemoveRefillCardResponseStr, VZWPrepayRefillCardVO.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/removeRefillCard");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any(),eq(true))).thenReturn(Mono.just(new ResponseEntity<>(responseString, HttpStatus.OK)));
        when(prepayCheckoutRedisHelper.upsertDataIntoRedisAsStr(eq(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(mapper.readValue(Mockito.anyString(), eq(PrepaidODRequestData.class))).thenReturn(prepaidODRequestData);
        when(mapper.readValue(Mockito.anyString(), eq(VZWPrepayRefillCardVO.class))).thenReturn(prepaidODRemoveRefillCardResponse);
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentHelper.removeRefillCard(httpRequest, refillCardCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> Assert.assertNotNull(resp)).verifyComplete();
    }

    @Test
    public void removeRefillCardStatus500Test() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/helper/removeRefillCardRequest.json");
        String responseString = "{\"status\":\"500\",\"payload\":{\"cqContent\":{},\"pageData\":{\"paymentGrpIdList\":[{\"balance\":0.0,\"paymentGrpId\":\"Sbe8384c300b133b5aeb5e68fc2270ab2{as1}_pin_586599070\",\"amounApplied\":50.0,\"pincard\":\"9777680205\"}],\"remainingDue\":25.0}}}";
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestDataWithOneRefillCard.json");
        String prepaidODRemoveRefillCardRespErrStr = FileReaderUtil.readFromFile("data/payment/helper/prepaidOD-removeRefillCardErrorResponse.json");
        Object request = objectMapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = objectMapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = objectMapper.readValue(responseString, RefillCardCXPResponse.class);
        PrepaidODRequestData prepaidODRequestData = objectMapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        VZWPrepayRefillCardVO prepaidODRemoveRefillCardResponse = objectMapper.readValue(prepaidODRemoveRefillCardRespErrStr, VZWPrepayRefillCardVO.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/removeRefillCard");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any(),eq(true))).thenReturn(Mono.just(new ResponseEntity<>(responseString, HttpStatus.OK)));
        when(prepayCheckoutRedisHelper.upsertDataIntoRedisAsStr(eq(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(mapper.readValue(Mockito.anyString(), eq(PrepaidODRequestData.class))).thenReturn(prepaidODRequestData);
        when(mapper.readValue(Mockito.anyString(), eq(VZWPrepayRefillCardVO.class))).thenReturn(prepaidODRemoveRefillCardResponse);
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentHelper.removeRefillCard(httpRequest, refillCardCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> Assert.assertNotNull(resp)).verifyComplete();
    }

    @Test
    public void removeRefillCardStatus00Test() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/helper/removeRefillCardRequest.json");
        String responseString = "{\"status\":\"00\",\"payload\":{\"cqContent\":{},\"pageData\":{\"paymentGrpIdList\":[{\"balance\":0.0,\"paymentGrpId\":\"Sbe8384c300b133b5aeb5e68fc2270ab2{as1}_pin_586599070\",\"amounApplied\":50.0,\"pincard\":\"9777680205\"}],\"remainingDue\":25.0}}}";
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestData.json");
        Object request = objectMapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = objectMapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = objectMapper.readValue(responseString, RefillCardCXPResponse.class);
        //PrepaidODRequestData prepaidODRequestData = mapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/removeRefillCard");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(responseString, HttpStatus.OK)));
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentHelper.removeRefillCard(httpRequest, refillCardCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> Assert.assertNotNull(resp)).verifyComplete();
    }

    @Test
    public void removeRefillCardExceptionTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/helper/removeRefillCardRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/helper/removeRefillCardResponse.json");
        String prepaidODRequestDataString = "{\"serviceHeader\":{\"statusMsg\":\"Success\"}";
        Object request = objectMapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = objectMapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = objectMapper.readValue(responseString, RefillCardCXPResponse.class);
        //PrepaidODRequestData prepaidODRequestData = mapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/removeRefillCard");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(responseString, HttpStatus.OK)));
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentHelper.removeRefillCard(httpRequest, refillCardCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> Assert.assertNotNull(resp)).verifyComplete();
    }

    @Test
    public void removeRefillCard_status500Test() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/helper/removeRefillCardRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/helper/removeRefillCardResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestData.json");
        String prepaidODRemoveRefillCardResponseStr = FileReaderUtil.readFromFile("data/payment/helper/prepaidOD-removeRefillCardResponse.json");
        RefillCardCXPRequest refillCardCXPRequest = objectMapper.readValue(requestString, RefillCardCXPRequest.class);
        PrepaidODRequestData prepaidODRequestData = objectMapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        VZWPrepayRefillCardVO prepaidODRemoveRefillCardResponse = objectMapper.readValue(prepaidODRemoveRefillCardResponseStr, VZWPrepayRefillCardVO.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/removeRefillCard");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any(),eq(true))).thenReturn(Mono.just(new ResponseEntity<>(responseString, HttpStatus.BAD_REQUEST)));
        when(prepayCheckoutRedisHelper.upsertDataIntoRedisAsStr(eq(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(mapper.readValue(Mockito.anyString(), eq(PrepaidODRequestData.class))).thenReturn(prepaidODRequestData);
        when(mapper.readValue(Mockito.anyString(), eq(VZWPrepayRefillCardVO.class))).thenReturn(prepaidODRemoveRefillCardResponse);
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentHelper.removeRefillCard(httpRequest, refillCardCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> Assert.assertNotNull(resp)).verifyComplete();
    }

    @Test
    public void removeRefillCard_exceptionTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/helper/removeRefillCardRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/helper/removeRefillCardResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestData.json");
        String prepaidODRemoveRefillCardResponseStr = FileReaderUtil.readFromFile("data/payment/helper/prepaidOD-removeRefillCardResponse.json");
        RefillCardCXPRequest refillCardCXPRequest = objectMapper.readValue(requestString, RefillCardCXPRequest.class);
        PrepaidODRequestData prepaidODRequestData = objectMapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        VZWPrepayRefillCardVO prepaidODRemoveRefillCardResponse = objectMapper.readValue(prepaidODRemoveRefillCardResponseStr, VZWPrepayRefillCardVO.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/removeRefillCard");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any(),eq(true))).thenReturn(Mono.just(new ResponseEntity<>(responseString, HttpStatus.OK)));
        when(prepayCheckoutRedisHelper.upsertDataIntoRedisAsStr(eq(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA), Mockito.any())).thenThrow(RuntimeException.class);
        when(mapper.readValue(Mockito.anyString(), eq(PrepaidODRequestData.class))).thenReturn(prepaidODRequestData);
        when(mapper.readValue(Mockito.anyString(), eq(VZWPrepayRefillCardVO.class))).thenReturn(prepaidODRemoveRefillCardResponse);
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentHelper.removeRefillCard(httpRequest, refillCardCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> Assert.assertNotNull(resp)).verifyComplete();
    }

    @Test
    public void removeRefillCardRedisErrorTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/helper/removeRefillCardRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/helper/addRefillCardResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestData.json");
        Object request = objectMapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = objectMapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = objectMapper.readValue(responseString, RefillCardCXPResponse.class);
        //PrepaidODRequestData prepaidODRequestData = mapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/removeRefillCard");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.empty());
        //when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(responseString, HttpStatus.OK)));
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentHelper.removeRefillCard(httpRequest, refillCardCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> Assert.assertNotNull(new RefillCardCXPResponse())).verifyComplete();
    }

    @Test
    public void removeRefillCardServiceErrorStatusTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/helper/removeRefillCardRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/helper/addRefillCardResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestData.json");
        Object request = objectMapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = objectMapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = objectMapper.readValue(responseString, RefillCardCXPResponse.class);
        //PrepaidODRequestData prepaidODRequestData = mapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/removeRefillCard");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>("", HttpStatus.INTERNAL_SERVER_ERROR)));
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentHelper.removeRefillCard(httpRequest, refillCardCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> resp.getStatusCode().equals(HttpStatus.INTERNAL_SERVER_ERROR)).verifyComplete();
    }

    @Test
    public void removeRefillCardServiceErrorTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/helper/removeRefillCardRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/helper/addRefillCardResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestData.json");
        Object request = objectMapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = objectMapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = objectMapper.readValue(responseString, RefillCardCXPResponse.class);
        //PrepaidODRequestData prepaidODRequestData = mapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/removeRefillCard");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>("", HttpStatus.OK)));
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentHelper.removeRefillCard(httpRequest, refillCardCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> Assert.assertNotNull(resp)).verifyComplete();
    }

    @Test
    public void removeRefillCardServiceErrorRespTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/helper/removeRefillCardRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/helper/addRefillCardResponse.json");
        String prepaidODAddRefillErrRespString = FileReaderUtil.readFromFile("data/payment/helper/prepaidOD-addRefillCardErrResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestData.json");
        Object request = objectMapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = objectMapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = objectMapper.readValue(responseString, RefillCardCXPResponse.class);
        //PrepaidODRequestData prepaidODRequestData = mapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/removeRefillCard");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(prepaidODAddRefillErrRespString, HttpStatus.INTERNAL_SERVER_ERROR)));
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentHelper.removeRefillCard(httpRequest, refillCardCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> Assert.assertNotNull(resp)).verifyComplete();
    }

    @Test
    public void removeAllRefillCardsWithOneTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/helper/addRefillCardRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/helper/removeRefillCardResponse.json");
        String prepaidODRemoveAllResponseString = FileReaderUtil.readFromFile("data/payment/helper/prepaidOD-removeAllRefillCardsResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestDataWithOneRefillCard.json");
        String prepaidODRequestOrg = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestData.json");
        PrepaidODRequestData prepaidODRequestDataOrg = objectMapper.readValue(prepaidODRequestOrg, PrepaidODRequestData.class);
        Object request = objectMapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = objectMapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = objectMapper.readValue(responseString, RefillCardCXPResponse.class);
        VZWPrepayRefillCardVO prepaidODRemoveAllResponse = objectMapper.readValue(prepaidODRemoveAllResponseString, VZWPrepayRefillCardVO.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/removeAllRefillCards");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.GET, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(responseString, HttpStatus.OK)));
        when(prepayCheckoutRedisHelper.upsertDataIntoRedisAsStr(eq(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(mapper.readValue(Mockito.anyString(), eq(PrepaidODRequestData.class))).thenReturn(prepaidODRequestDataOrg);
        when(mapper.readValue(Mockito.anyString(), eq(VZWPrepayRefillCardVO.class))).thenReturn(prepaidODRemoveAllResponse);
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentHelper.removeAllRefillCards(httpRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> Assert.assertNotNull(resp)).verifyComplete();
    }

    @Test
    public void removeAllRefillCardsException() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/helper/addRefillCardRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/helper/removeRefillCardResponse.json");
       // String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestDataWithOneRefillCard.json");
        String prepaidODRequestDataString = "{\"serviceHeader\":{\"statusMsg\":\"Success\"}";
        String prepaidODRequestOrg = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestData.json");
        PrepaidODRequestData prepaidODRequestDataOrg = objectMapper.readValue(prepaidODRequestOrg, PrepaidODRequestData.class);
        Object request = objectMapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = objectMapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = objectMapper.readValue(responseString, RefillCardCXPResponse.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/removeAllRefillCards");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.GET, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(responseString, HttpStatus.OK)));
        when(prepayCheckoutRedisHelper.upsertDataIntoRedisAsStr(eq(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(mapper.readValue(Mockito.anyString(), eq(PrepaidODRequestData.class))).thenReturn(prepaidODRequestDataOrg);
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentHelper.removeAllRefillCards(httpRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> Assert.assertNotNull(resp)).verifyComplete();
    }

    @Test
    public void removeAllRefillCardsEmptyResp() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/helper/addRefillCardRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/helper/removeRefillCardResponse.json");
        String prepaidODRequestOrg = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestData.json");
        PrepaidODRequestData prepaidODRequestDataOrg = objectMapper.readValue(prepaidODRequestOrg, PrepaidODRequestData.class);
        Object request = objectMapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = objectMapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = objectMapper.readValue(responseString, RefillCardCXPResponse.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/removeAllRefillCards");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.GET, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestOrg));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(responseString, HttpStatus.OK)));
        when(prepayCheckoutRedisHelper.upsertDataIntoRedisAsStr(eq(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentHelper.removeAllRefillCards(httpRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> Assert.assertNotNull(resp)).verifyComplete();
    }

    @Test
    public void removeAllRefillCardsUpsertFailedWithOneTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/helper/addRefillCardRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/helper/removeRefillCardResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestDataWithOneRefillCard.json");
        Object request = objectMapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = objectMapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = objectMapper.readValue(responseString, RefillCardCXPResponse.class);
        //PrepaidODRequestData prepaidODRequestData = mapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/removeAllRefillCards");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.GET, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(responseString, HttpStatus.OK)));
        when(prepayCheckoutRedisHelper.upsertDataIntoRedisAsStr(eq(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA), Mockito.any())).thenReturn(Mono.just(Boolean.FALSE));
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentHelper.removeAllRefillCards(httpRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> Assert.assertNotNull(resp)).verifyComplete();
    }

    @Test
    public void removeAllRefillCardsWithMultipleTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/helper/addRefillCardRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/helper/removeRefillCardResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestDataWithMultipleRefillCards.json");
        Object request = objectMapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = objectMapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = objectMapper.readValue(responseString, RefillCardCXPResponse.class);
        //PrepaidODRequestData prepaidODRequestData = mapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/removeAllRefillCards");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.GET, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(responseString, HttpStatus.OK)));
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentHelper.removeAllRefillCards(httpRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> Assert.assertNotNull(resp)).verifyComplete();
    }

    @Test
    public void removeAllRefillCardsEmptyErrorTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/helper/addRefillCardRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/helper/removeRefillCardResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestData.json");
        Object request = objectMapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = objectMapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = objectMapper.readValue(responseString, RefillCardCXPResponse.class);
        //PrepaidODRequestData prepaidODRequestData = mapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/removeAllRefillCards");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.GET, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(responseString, HttpStatus.OK)));
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentHelper.removeAllRefillCards(httpRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> Assert.assertNotNull(resp)).verifyComplete();
    }

    @Test
    public void removeAllRefillCardsRedisErrorTest() throws IOException {
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/removeAllRefillCards");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.GET, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(""));
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentHelper.removeAllRefillCards(httpRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> Assert.assertNotNull(resp)).verifyComplete();
    }


    @Test
    public void removeAllRefillCardsErrRespTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/helper/addRefillCardRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/helper/removeRefillCardResponse.json");
        String prepaidODRemoveAllResponseString = FileReaderUtil.readFromFile("data/payment/helper/prepaidOD-removeAllRefillCardsErrorResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestDataWithOneRefillCard.json");
        String prepaidODRequestOrg = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestData.json");
        PrepaidODRequestData prepaidODRequestDataOrg = objectMapper.readValue(prepaidODRequestOrg, PrepaidODRequestData.class);
        Object request = objectMapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = objectMapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = objectMapper.readValue(responseString, RefillCardCXPResponse.class);
        VZWPrepayRefillCardVO prepaidODRemoveAllResponse = objectMapper.readValue(prepaidODRemoveAllResponseString, VZWPrepayRefillCardVO.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/removeAllRefillCards");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.GET, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(prepaidODRemoveAllResponseString, HttpStatus.OK)));
        when(prepayCheckoutRedisHelper.upsertDataIntoRedisAsStr(eq(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(mapper.readValue(Mockito.anyString(), eq(PrepaidODRequestData.class))).thenReturn(prepaidODRequestDataOrg);
        when(mapper.readValue(Mockito.anyString(), eq(VZWPrepayRefillCardVO.class))).thenReturn(prepaidODRemoveAllResponse);
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentHelper.removeAllRefillCards(httpRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> Assert.assertNotNull(resp)).verifyComplete();
    }

    @Test
    public void removeAllRefillCards_status400Test() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/helper/addRefillCardRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/helper/removeRefillCardResponse.json");
        String prepaidODRemoveAllResponseString = FileReaderUtil.readFromFile("data/payment/helper/prepaidOD-removeAllRefillCardsResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestDataWithOneRefillCard.json");
        String prepaidODRequestOrg = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestData.json");
        PrepaidODRequestData prepaidODRequestDataOrg = objectMapper.readValue(prepaidODRequestOrg, PrepaidODRequestData.class);
        VZWPrepayRefillCardVO prepaidODRemoveAllResponse = objectMapper.readValue(prepaidODRemoveAllResponseString, VZWPrepayRefillCardVO.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/removeAllRefillCards");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.GET, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(responseString, HttpStatus.BAD_REQUEST)));
        when(prepayCheckoutRedisHelper.upsertDataIntoRedisAsStr(eq(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(mapper.readValue(Mockito.anyString(), eq(PrepaidODRequestData.class))).thenReturn(prepaidODRequestDataOrg);
        when(mapper.readValue(Mockito.anyString(), eq(VZWPrepayRefillCardVO.class))).thenReturn(prepaidODRemoveAllResponse);
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentHelper.removeAllRefillCards(httpRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> Assert.assertNotNull(resp)).verifyComplete();
    }

}