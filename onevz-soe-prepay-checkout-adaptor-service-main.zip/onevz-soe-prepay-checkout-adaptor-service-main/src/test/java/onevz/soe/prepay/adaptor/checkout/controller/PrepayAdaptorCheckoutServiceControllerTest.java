package onevz.soe.prepay.adaptor.checkout.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.model.initiateCheckout.OrderWriteRequest;
import onevz.soe.cart.model.initiateCheckout.OrderWriteResponse;
import onevz.soe.cart.requests.InitiateCheckoutPEGARequest;
import onevz.soe.cart.responses.InitiateCheckoutPEGAResponse;
import onevz.soe.checkout.request.bpm.UpdateLineSecurityInfoRequest;
import onevz.soe.checkout.response.bpm.UpdateLineSecurityInfoResponse;
import onevz.soe.prepay.adaptor.checkout.config.PrepayCheckoutAdaptorServiceTestConfig;
import onevz.soe.prepay.adaptor.checkout.helper.PrepayAdaptorCheckoutHelper;
import onevz.soe.prepay.adaptor.checkout.helper.PrepayAdaptorOrderWriteHelper;
import onevz.soe.prepay.adaptor.checkout.helper.PrepayAdaptorUpdateLineSecurityInfoHelper;
import onevz.soe.prepay.adaptor.checkout.helper.PrepayAdaptorValidateOrderHelper;
import onevz.soe.prepay.adaptor.checkout.model.payment.request.ConfirmSubmit3DCXPRequest;
import onevz.soe.prepay.adaptor.checkout.model.payment.request.ValidateCardCXPRequest;
import onevz.soe.prepay.adaptor.checkout.model.payment.response.ConfirmSubmit3DCXPResponse;
import onevz.soe.prepay.adaptor.checkout.model.payment.response.ValidateCardPaymentCXPResponse;
import onevz.soe.prepay.adaptor.checkout.model.paypal.request.CMPILookupCXPRequest;
import onevz.soe.prepay.adaptor.checkout.model.paypal.request.PreauthDigitalPayCXPRequest;
import onevz.soe.prepay.adaptor.checkout.model.paypal.response.CMPILookupCXPResponse;
import onevz.soe.prepay.adaptor.checkout.model.paypal.response.PreauthDigitalPayCXPResponse;
import onevz.soe.prepay.adaptor.checkout.util.FileReaderUtil;
import onevz.soe.prepay.payment.request.cxp.ProcessApplePaySessionCxpRequest;
import onevz.soe.prepay.payment.response.cxp.GetApplePaySessionCXPResponse;
import onevz.soe.prepay.payment.response.cxp.ProcessApplePaySessionCXPResponse;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.bind.WebDataBinder;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.net.URI;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {PrepayCheckoutAdaptorServiceTestConfig.class})
@WebFluxTest(PrepayAdaptorCheckoutServiceController.class)
public class PrepayAdaptorCheckoutServiceControllerTest {

    @MockBean
    private PrepayAdaptorCheckoutHelper prepayAdaptorCheckoutHelper;

    @MockBean
    private PrepayAdaptorOrderWriteHelper orderWriteHelper;

    @MockBean
    private PrepayAdaptorValidateOrderHelper validateOrderHelper;

    @Autowired
    private PrepayAdaptorCheckoutServiceController checkoutServiceController;

    @Autowired
    private ObjectMapper mapper;

    @MockBean
    private PrepayAdaptorUpdateLineSecurityInfoHelper updateLineSecurityInfoHelper;

    @Value("${onevz.soe.prepay.checkout.test.mock}")
    private String mockDataLocation;

    private String orderWriteControllerMock = "/adaptor/controller/";

    @Test
    public void checkoutValidationTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/controller/CheckoutControllerRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/adaptor/controller/CheckoutControllerResponse.json");
        Object request = mapper.readValue(requestString, Object.class);
        URI url = URI.create("http://localhost:15115/prepaid-adaptor/checkout/test");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<String>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorCheckoutHelper.templateMethod(Mockito.any())).thenReturn(justResponse);
        Mono<ResponseEntity<String>> actual = checkoutServiceController.checkoutValidation(request);
        StepVerifier.create(actual).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void checkoutValidationErrorTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/controller/CheckoutControllerRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/adaptor/controller/CheckoutControllerResponse.json");
        Object request = mapper.readValue(requestString, Object.class);
        URI url = URI.create("http://localhost:15115/prepaid-adaptor/checkout/test");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<String>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorCheckoutHelper.templateMethod(Mockito.any())).thenReturn(justResponse);
        Mono<ResponseEntity<String>> actual = checkoutServiceController.checkoutValidation(request);
        StepVerifier.create(Mono.just("Exception").map(element -> {throw new RuntimeException();})).expectError().verify();
    }

    @Test
    public void checkoutValidation2Test() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/controller/CheckoutControllerRequest.json");
        String responseString = FileReaderUtil.readFromFile( "data/adaptor/controller/CheckoutControllerResponse.json");
        Object request = mapper.readValue(requestString, Object.class);
        URI url = URI.create("http://localhost:15115/prepaid-adaptor/checkout/test2");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<String>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorCheckoutHelper.templateMethod(Mockito.any())).thenReturn(justResponse);
        Mono<ResponseEntity<String>> actual = checkoutServiceController.checkoutValidation2(request);
        StepVerifier.create(actual).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void checkoutValidation2ErrorTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/controller/CheckoutControllerRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/adaptor/controller/CheckoutControllerResponse.json");
        Object request = mapper.readValue(requestString, Object.class);
        URI url = URI.create("http://localhost:15115/prepaid-adaptor/checkout/test2");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<String>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorCheckoutHelper.templateMethod(Mockito.any())).thenReturn(justResponse);
        Mono<ResponseEntity<String>> actual = checkoutServiceController.checkoutValidation2(request);
        StepVerifier.create(Mono.just("Exception").map(element -> {throw new RuntimeException();})).expectError().verify();
    }

    @Test
    public void orderWriteTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/controller/CheckoutControllerRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/adaptor/controller/CheckoutControllerResponse.json");
        OrderWriteRequest request = mapper.readValue(requestString, OrderWriteRequest.class);
        OrderWriteResponse response = mapper.readValue(responseString, OrderWriteResponse.class);
        URI url = URI.create("http://localhost:15115/orderWrite");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<OrderWriteResponse>>  justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));
        when(orderWriteHelper.orderWrite(Mockito.any(), Mockito.any())).thenReturn(justResponse);
        Mono<ResponseEntity<OrderWriteResponse>> actual = checkoutServiceController.orderWrite(httpHeader, null, request);
        StepVerifier.create(actual).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void orderWriteErrorTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/controller/CheckoutControllerRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/adaptor/controller/CheckoutControllerResponse.json");
        OrderWriteRequest request = mapper.readValue(requestString, OrderWriteRequest.class);
        OrderWriteResponse response = mapper.readValue(responseString, OrderWriteResponse.class);
        URI url = URI.create("http://localhost:15115/orderWrite");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<OrderWriteResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));
        when(orderWriteHelper.orderWrite(Mockito.any(), Mockito.any())).thenReturn(justResponse);
        Mono<ResponseEntity<OrderWriteResponse>> actual = checkoutServiceController.orderWrite(httpHeader, null, request);
        StepVerifier.create(Mono.just("Exception").map(element -> {throw new RuntimeException();})).expectError().verify();
    }

    @Test
    public void validateOrderTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/controller/CheckoutControllerRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/adaptor/controller/CheckoutControllerResponse.json");
        InitiateCheckoutPEGARequest request = mapper.readValue(requestString, InitiateCheckoutPEGARequest.class);
        InitiateCheckoutPEGAResponse response = mapper.readValue(responseString, InitiateCheckoutPEGAResponse.class);
        URI url = URI.create("http://localhost:15115/orderWrite");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<InitiateCheckoutPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));
        when(validateOrderHelper.validateOrder(Mockito.any())).thenReturn(justResponse);
        Mono<ResponseEntity<InitiateCheckoutPEGAResponse>> actual = checkoutServiceController.validateOrder(httpHeader, null, request);
        StepVerifier.create(actual).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void validateOrderErrorTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/controller/CheckoutControllerRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/adaptor/controller/CheckoutControllerResponse.json");
        InitiateCheckoutPEGARequest request = mapper.readValue(requestString, InitiateCheckoutPEGARequest.class);
        InitiateCheckoutPEGAResponse response = mapper.readValue(responseString, InitiateCheckoutPEGAResponse.class);
        URI url = URI.create("http://localhost:15115/orderWrite");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<InitiateCheckoutPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));
        when(validateOrderHelper.validateOrder(Mockito.any())).thenReturn(justResponse);
        Mono<ResponseEntity<InitiateCheckoutPEGAResponse>> actual = checkoutServiceController.validateOrder(httpHeader, null, request);
        StepVerifier.create(Mono.just("Exception").map(element -> {throw new RuntimeException();})).expectError().verify();
    }

    @Test
    public void getUpdatePaymentTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/controller/CheckoutControllerRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/adaptor/controller/CheckoutControllerResponse.json");
        ValidateCardCXPRequest request = mapper.readValue(requestString, ValidateCardCXPRequest.class);
        ValidateCardPaymentCXPResponse response = mapper.readValue(responseString, ValidateCardPaymentCXPResponse.class);
        URI url = URI.create("http://localhost:15116/prepaid-adaptor/payment/update-payment");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<ValidateCardPaymentCXPResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));
        when(orderWriteHelper.getUpdatePayment(Mockito.any(),Mockito.any())).thenReturn(justResponse);
        Mono<ResponseEntity<ValidateCardPaymentCXPResponse>> actual = checkoutServiceController.getUpdatePayment(httpHeader, null, request);
        StepVerifier.create(actual).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void getUpdatePaymentErrorTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/controller/CheckoutControllerRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/adaptor/controller/CheckoutControllerResponse.json");
        ValidateCardCXPRequest request = mapper.readValue(requestString, ValidateCardCXPRequest.class);
        ValidateCardPaymentCXPResponse response = mapper.readValue(responseString, ValidateCardPaymentCXPResponse.class);
        URI url = URI.create("http://localhost:15116/prepaid-adaptor/payment/update-payment");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<ValidateCardPaymentCXPResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));
        when(orderWriteHelper.getUpdatePayment(Mockito.any(),Mockito.any())).thenReturn(justResponse);
        Mono<ResponseEntity<ValidateCardPaymentCXPResponse>> actual = checkoutServiceController.getUpdatePayment(httpHeader, null, request);
        StepVerifier.create(Mono.just("Exception").map(element -> {throw new RuntimeException();})).expectError().verify();
    }

    @Test
    public void doPaypalLookUpTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/controller/CheckoutControllerRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/adaptor/controller/CheckoutControllerResponse.json");
        CMPILookupCXPRequest request = mapper.readValue(requestString, CMPILookupCXPRequest.class);
        CMPILookupCXPResponse response = mapper.readValue(responseString, CMPILookupCXPResponse.class);
        URI url = URI.create("http://localhost:15116/prepaid-adaptor/payment/update-payment");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<CMPILookupCXPResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));
        when(orderWriteHelper.getPayPalLookUp(Mockito.any(),Mockito.any())).thenReturn(justResponse);
        Mono<ResponseEntity<CMPILookupCXPResponse>> actual = checkoutServiceController.doPaypalLookUp(httpHeader, null, request);
        StepVerifier.create(actual).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void doPaypalLookUpErrorTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/controller/CheckoutControllerRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/adaptor/controller/CheckoutControllerResponse.json");
        CMPILookupCXPRequest request = mapper.readValue(requestString, CMPILookupCXPRequest.class);
        CMPILookupCXPResponse response = mapper.readValue(responseString, CMPILookupCXPResponse.class);
        URI url = URI.create("http://localhost:15116/prepaid-adaptor/payment/update-payment");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<CMPILookupCXPResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));
        when(orderWriteHelper.getPayPalLookUp(Mockito.any(),Mockito.any())).thenReturn(justResponse);
        Mono<ResponseEntity<CMPILookupCXPResponse>> actual = checkoutServiceController.doPaypalLookUp(httpHeader, null, request);
        StepVerifier.create(Mono.just("Exception").map(element -> {throw new RuntimeException();})).expectError().verify();
    }

    @Test
    public void doPaypalAuthenticateTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/controller/CheckoutControllerRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/adaptor/controller/CheckoutControllerResponse.json");
        PreauthDigitalPayCXPRequest request = mapper.readValue(requestString, PreauthDigitalPayCXPRequest.class);
        PreauthDigitalPayCXPResponse response = mapper.readValue(responseString, PreauthDigitalPayCXPResponse.class);
        URI url = URI.create("http://localhost:15116/prepaid-adaptor/payment/update-payment");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<PreauthDigitalPayCXPResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));
        when(orderWriteHelper.getPaypalAuth(Mockito.any(),Mockito.any())).thenReturn(justResponse);
        Mono<ResponseEntity<PreauthDigitalPayCXPResponse>> actual = checkoutServiceController.doPaypalAuthenticate(httpHeader, null, request);
        StepVerifier.create(actual).assertNext(Assert::assertNotNull).expectComplete().verify();
    }
    @Test
    public void doPaypalAuthenticateErrorTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/controller/CheckoutControllerRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/adaptor/controller/CheckoutControllerResponse.json");
        PreauthDigitalPayCXPRequest request = mapper.readValue(requestString, PreauthDigitalPayCXPRequest.class);
        PreauthDigitalPayCXPResponse response = mapper.readValue(responseString, PreauthDigitalPayCXPResponse.class);
        URI url = URI.create("http://localhost:15116/prepaid-adaptor/payment/update-payment");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<PreauthDigitalPayCXPResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));
        when(orderWriteHelper.getPaypalAuth(Mockito.any(),Mockito.any())).thenReturn(justResponse);
        Mono<ResponseEntity<PreauthDigitalPayCXPResponse>> actual = checkoutServiceController.doPaypalAuthenticate(httpHeader, null, request);
        StepVerifier.create(Mono.just("Exception").map(element -> {throw new RuntimeException();})).expectError().verify();
    }

    @Test
    public void upsertConfirmSubmit3DTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/controller/CheckoutControllerRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/adaptor/controller/CheckoutControllerResponse.json");
        ConfirmSubmit3DCXPRequest request = mapper.readValue(requestString, ConfirmSubmit3DCXPRequest.class);
        ConfirmSubmit3DCXPResponse response = mapper.readValue(responseString, ConfirmSubmit3DCXPResponse.class);
        URI url = URI.create("http://localhost:15116/prepaid-adaptor/payment/update-payment");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<ConfirmSubmit3DCXPResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));
        when(orderWriteHelper.confirmSubmit3D(Mockito.any(),Mockito.any())).thenReturn(justResponse);
        Mono<ResponseEntity<ConfirmSubmit3DCXPResponse>> actual = checkoutServiceController.upsertConfirmSubmit3D(httpHeader, null, request);
        StepVerifier.create(actual).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void upsertConfirmSubmit3DErrorTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/controller/CheckoutControllerRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/adaptor/controller/CheckoutControllerResponse.json");
        ConfirmSubmit3DCXPRequest request = mapper.readValue(requestString, ConfirmSubmit3DCXPRequest.class);
        ConfirmSubmit3DCXPResponse response = mapper.readValue(responseString, ConfirmSubmit3DCXPResponse.class);
        URI url = URI.create("http://localhost:15116/prepaid-adaptor/payment/update-payment");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<ConfirmSubmit3DCXPResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));
        when(orderWriteHelper.confirmSubmit3D(Mockito.any(),Mockito.any())).thenReturn(justResponse);
        Mono<ResponseEntity<ConfirmSubmit3DCXPResponse>> actual = checkoutServiceController.upsertConfirmSubmit3D(httpHeader, null, request);
        StepVerifier.create(Mono.just("Exception").map(element -> {throw new RuntimeException();})).expectError().verify();
    }

    @Test
    public void updateLineSecurityInfoTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/adaptor/controller/CheckoutControllerRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/adaptor/controller/CheckoutControllerResponse.json");
        UpdateLineSecurityInfoRequest request = mapper.readValue(requestString, UpdateLineSecurityInfoRequest.class);
        UpdateLineSecurityInfoResponse response = mapper.readValue(responseString, UpdateLineSecurityInfoResponse.class);
        URI url = URI.create("http://localhost:15116/prepaid-adaptor/payment/update-payment");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<UpdateLineSecurityInfoResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));
        when(updateLineSecurityInfoHelper.updateLineSecurityInfo(Mockito.any(),Mockito.any())).thenReturn(justResponse);
        Mono<UpdateLineSecurityInfoResponse> actual = checkoutServiceController.updateLineSecurityInfo(httpHeader,request);
        StepVerifier.create(actual).assertNext(Assert::assertNotNull).expectComplete().verify();
    }
    
    @Test
    public void getApplePaySessionDetailsTest() throws IOException {
    	String request="domainName=www.verizon.com&url=https://apple-pay-gateway.apple.com/paymentservices/startSession";
    	String responseString = FileReaderUtil.readFromFile("data/adaptor/controller/GetApplePaySessionResponse.json");
    	GetApplePaySessionCXPResponse response=mapper.readValue(responseString, GetApplePaySessionCXPResponse.class);
    	URI url = URI.create("http://localhost:15116/prepaid-adaptor/payment/getApplePaySession");
    	MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
    	Mono<ResponseEntity<GetApplePaySessionCXPResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));
    	when(orderWriteHelper.getApplePaySessionDetails(Mockito.any(),Mockito.any())).thenReturn(justResponse);
        Mono<ResponseEntity<GetApplePaySessionCXPResponse>> actual = checkoutServiceController.getApplePaySessionDetails(httpHeader,null, request);
        StepVerifier.create(actual).assertNext(Assert::assertNotNull).expectComplete().verify();
    }
    
    @Test
    public void getApplePaySessionDetailsErrorTest() throws IOException {
    	String request="domainName=www.verizon.com&url=https://apple-pay-gateway.apple.com/paymentservices/startSession";
    	String responseString = FileReaderUtil.readFromFile("data/adaptor/controller/GetApplePaySessionResponse.json");
    	GetApplePaySessionCXPResponse response=mapper.readValue(responseString, GetApplePaySessionCXPResponse.class);
    	URI url = URI.create("http://localhost:15116/prepaid-adaptor/payment/getApplePaySession");
    	MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
    	Mono<ResponseEntity<GetApplePaySessionCXPResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));
    	when(orderWriteHelper.getApplePaySessionDetails(Mockito.any(),Mockito.any())).thenReturn(justResponse);
        Mono<ResponseEntity<GetApplePaySessionCXPResponse>> actual = checkoutServiceController.getApplePaySessionDetails(httpHeader,null, request);
        StepVerifier.create(Mono.just("Exception").map(element -> {throw new RuntimeException();})).expectError().verify();
    }
    
    @Test
    public void processApplePayTokenDetailsTest() throws IOException {
    	String requestString = FileReaderUtil.readFromFile("data/adaptor/controller/ProcessApplePaySessionRequest.json");
    	String responseString = FileReaderUtil.readFromFile("data/adaptor/controller/ProcessApplePaySessionResponse.json");
    	ProcessApplePaySessionCxpRequest request = mapper.readValue(requestString, ProcessApplePaySessionCxpRequest.class);
    	ProcessApplePaySessionCXPResponse response=mapper.readValue(responseString, ProcessApplePaySessionCXPResponse.class);
    	URI url = URI.create("http://localhost:15116/prepaid-adaptor/payment/processApplePayToken");
    	MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
    	Mono<ResponseEntity<ProcessApplePaySessionCXPResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));
    	when(orderWriteHelper.processApplePayTokenDetails(Mockito.any(),Mockito.any())).thenReturn(justResponse);
        Mono<ResponseEntity<ProcessApplePaySessionCXPResponse>> actual = checkoutServiceController.processApplePayTokenDetails(httpHeader,null, request);
        StepVerifier.create(actual).assertNext(Assert::assertNotNull).expectComplete().verify();
    }
    
    @Test
    public void processApplePayTokenDetailsErrorTest() throws IOException {
    	String requestString = FileReaderUtil.readFromFile("data/adaptor/controller/ProcessApplePaySessionRequest.json");
    	String responseString = FileReaderUtil.readFromFile("data/adaptor/controller/ProcessApplePaySessionResponse.json");
    	ProcessApplePaySessionCxpRequest request = mapper.readValue(requestString, ProcessApplePaySessionCxpRequest.class);
    	ProcessApplePaySessionCXPResponse response=mapper.readValue(responseString, ProcessApplePaySessionCXPResponse.class);
    	URI url = URI.create("http://localhost:15116/prepaid-adaptor/payment/processApplePayToken");
    	MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
    	Mono<ResponseEntity<ProcessApplePaySessionCXPResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));
    	when(orderWriteHelper.processApplePayTokenDetails(Mockito.any(),Mockito.any())).thenReturn(justResponse);
        Mono<ResponseEntity<ProcessApplePaySessionCXPResponse>> actual = checkoutServiceController.processApplePayTokenDetails(httpHeader,null, request);
        StepVerifier.create(Mono.just("Exception").map(element -> {throw new RuntimeException();})).expectError().verify();
    }

    @Test
    public void initBinderByNameTest() throws NoSuchMethodException {
        Assert.assertNotNull(checkoutServiceController.getClass().getMethod("initBinderByName", WebDataBinder.class).getName());
        checkoutServiceController.initBinderByName(new WebDataBinder(null));
    }

    @Test
    public void updateLineSecurityInfo_exceptionTest() {
        UpdateLineSecurityInfoResponse mockItem = mock(UpdateLineSecurityInfoResponse.class);
        Mono<ResponseEntity<UpdateLineSecurityInfoResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(mockItem));
        when(updateLineSecurityInfoHelper.updateLineSecurityInfo(Mockito.any(),Mockito.any())).thenReturn(justResponse);
        when(mockItem.toString()).thenReturn(mockItem.getClass().getName());
        Mono<UpdateLineSecurityInfoResponse> actual = checkoutServiceController.updateLineSecurityInfo(null, null);
        StepVerifier.create(actual).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

}