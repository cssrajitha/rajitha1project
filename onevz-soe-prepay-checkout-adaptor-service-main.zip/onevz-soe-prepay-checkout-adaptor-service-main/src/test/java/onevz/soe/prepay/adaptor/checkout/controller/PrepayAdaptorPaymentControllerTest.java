package onevz.soe.prepay.adaptor.checkout.controller;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.channels.SOEChannels;
import onevz.soe.prepay.adaptor.checkout.config.PrepayCheckoutAdaptorServiceTestConfig;
import onevz.soe.prepay.adaptor.checkout.constants.PrepayAdaptorCheckoutConstants;
import onevz.soe.prepay.adaptor.checkout.exceptions.JsonValidator;
import onevz.soe.prepay.adaptor.checkout.helper.PrepayCheckoutRedisHelper;
import onevz.soe.prepay.adaptor.checkout.util.FileReaderUtil;
import onevz.soe.prepay.payment.request.common.PaymentsSessionData;
import onevz.soe.prepay.payment.request.cxp.RefillCardCXPRequest;
import onevz.soe.prepay.payment.response.cxp.RefillCardCXPResponse;
import onevz.soe.security.TokenProcessor;
import onevz.soe.security.model.SsoJwtDTO;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.session.constants.SessionConstants;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpRequestDecorator;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.ServerWebExchangeDecorator;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URI;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static onevz.soe.prepay.payment.constants.PaymentConstants.SAFE_TECH_SESSION_ID_KEY;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {PrepayCheckoutAdaptorServiceTestConfig.class})
@WebFluxTest(PrepayAdaptorPaymentController.class)

public class PrepayAdaptorPaymentControllerTest {

    @Autowired
    private ObjectMapper mapper;

    @Autowired
    JsonValidator validator;

    @Autowired
    private Environment env;

    @Autowired
    private ApplicationContext context;

    @MockBean
    SOELoginSessionBean sessionBean;

    @MockBean
    private PrepayAdaptorWebClient prepayAdaptorWebClient;

    @Autowired
    private PrepayAdaptorPaymentController prepayAdaptorPaymentController;

    @Autowired
    PrepayCheckoutRedisHelper prepayCheckoutRedisHelper;


    @Autowired
    private WebTestClient webTestClient;

    @MockBean
    TokenProcessor tokenProcessor;

    @Value("${onevz.soe.prepay.checkout.test.mock}")
    private String mockDataLocation;

    private String paymentWriteControllerMock = "/payment/controller/";

    private String token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiJNQ0YiLCJjbGllbnRJRCI6IlZaVy1QUk9TUEVDVCIsImlzcyI6Imh0dHBzOlwvXC9zc28tbnAuZWJpei52ZXJpem9uLmNvbSIsImV4cCI6MTYzMzY0MjA1NSwiaWF0IjoxNjMzNjM4NDU1LCJpbnRlbnQiOiJzeXN0ZW10b3N5c3RlbS5wcm9zcGVjdC5mbG9hdGluZ3Rva2VuIiwiZmxvdyI6Ik5PVEFVVEgifQ.pguu0mYfiHTtHVt3nXkWfjzxhDazo0coo5PLjRyNqI3p6cOXaRgofJsrwaoqRXhDsWN4Xvf0rgN5rhc6h0Ust0ipGR9KaNOxHuUhxTR9fTOhFz-jnTqK8T2S9T-Jh-vg3K1ZUoMF-OmZm8IcE7FVbXDoELw-Z-slcQTele7IyMJQKExU6qo3352ssmbUdQ8amA5VArp5UhbVBe-ZTV8WN5trDThItGheuPbQHRXpuZ23fzUz1cBXHUelcXDSKHVx_ymeTPQvS_nDCB_aaL5-_3jeJwgkStGsRbwYwDMwdliZVmiCLw-ObpfYuCjvCzuSY9kSxzannvVOQ_6ya4muVw";
    private String x_soe_apikey = "uFWjzl4du5e46whYg73iCGqriX2l62C9";
    private String xsrf_token = "f4f5e923-e4ce-4b10-b517-1714015252ab";
    SsoJwtDTO decodedSSOToken = null;
    private PaymentsSessionData sessionData = null;
    Map<String,String> mp = new HashMap<>();

    @Before
    public void setup() {
        token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiJNQ0YiLCJjbGllbnRJRCI6IlZaVy1QUk9TUEVDVCIsImlzcyI6Imh0dHBzOlwvXC9zc28tbnAuZWJpei52ZXJpem9uLmNvbSIsImV4cCI6MTYzMzY0MjA1NSwiaWF0IjoxNjMzNjM4NDU1LCJpbnRlbnQiOiJzeXN0ZW10b3N5c3RlbS5wcm9zcGVjdC5mbG9hdGluZ3Rva2VuIiwiZmxvdyI6Ik5PVEFVVEgifQ.pguu0mYfiHTtHVt3nXkWfjzxhDazo0coo5PLjRyNqI3p6cOXaRgofJsrwaoqRXhDsWN4Xvf0rgN5rhc6h0Ust0ipGR9KaNOxHuUhxTR9fTOhFz-jnTqK8T2S9T-Jh-vg3K1ZUoMF-OmZm8IcE7FVbXDoELw-Z-slcQTele7IyMJQKExU6qo3352ssmbUdQ8amA5VArp5UhbVBe-ZTV8WN5trDThItGheuPbQHRXpuZ23fzUz1cBXHUelcXDSKHVx_ymeTPQvS_nDCB_aaL5-_3jeJwgkStGsRbwYwDMwdliZVmiCLw-ObpfYuCjvCzuSY9kSxzannvVOQ_6ya4muVw";
        x_soe_apikey = "uFWjzl4du5e46whYg73iCGqriX2l62C9";
        xsrf_token = "f4f5e923-e4ce-4b10-b517-1714015252ab";
        decodedSSOToken = new SsoJwtDTO();
        mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        when(sessionBean.setSessionData(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(sessionBean.getSessionData(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new HashMap<>()));
        try {
            String sessionDataStr = FileReaderUtil.readFromFile("data/payment/redisResponse.json");
            sessionData = mapper.readValue(sessionDataStr, PaymentsSessionData.class);
            final String token = UUID.randomUUID().toString();
            sessionData.setCartId(token);
            sessionData.setChannelId(SOEChannels.VZW_DOTCOM.getChannelName());
            sessionData.setCaseId(token);

        } catch (Exception e) {
            e.printStackTrace();
        }

        when(sessionBean.getSessionData(Arrays.asList(SessionConstants.MTN_KEY, SessionConstants.ACCOUNT_NUMBER_KEY,SAFE_TECH_SESSION_ID_KEY))).thenReturn(Mono.just(new HashMap<>()));
        when(sessionBean.getSessionData(Mockito.any(), Mockito.any())).thenReturn(Mono.just(sessionData));
    }

    static class SetRemoteAddressWebFilterTest implements WebFilter {

        private String host;

        public SetRemoteAddressWebFilterTest(String host) {
            this.host = host;
        }

        @Override
        public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
            return chain.filter(decorate(exchange));
        }

        private ServerWebExchange decorate(ServerWebExchange exchange) {
            final ServerHttpRequest decorated = new ServerHttpRequestDecorator(exchange.getRequest()) {
                @Override
                public InetSocketAddress getRemoteAddress() {
                    return new InetSocketAddress(host, 80);
                }
            };

            return new ServerWebExchangeDecorator(exchange) {
                @Override
                public ServerHttpRequest getRequest() {
                    return decorated;
                }
            };
        }
    }
/*
    @Test
    public void addRefillCardTest() throws IOException, SignatureException {
        webTestClient = WebTestClient
                .bindToApplicationContext(context)
                .webFilter(new SetRemoteAddressWebFilterTest("127.0.0.1"))
                .configureClient()
                .build();
        String requestString = FileReaderUtil.readFromFile("data/payment/controller/addRefillCardRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/controller/addRefillCardResponse.json");
        Object request = mapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = mapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = mapper.readValue(responseString, RefillCardCXPResponse.class);
        //To get the xsrf token use the options call
        this.webTestClient.options().uri("/prepaid-adaptor/payment/addRefillCard").accept(MediaType.APPLICATION_JSON)
                .header("token", this.token).header("channelId", "VZW-DOTCOM").header("x-soe-apikey", x_soe_apikey)
                .exchange().expectBody().consumeWith(resp -> {
                    if (env.getProperty("enableCsrf") != null && ("true").equalsIgnoreCase(env.getProperty("enableCsrf"))) {
                        xsrf_token = resp.getResponseCookies().getFirst("XSRF-TOKEN").getValue();
                    }
                });
        when(tokenProcessor.decodeSSOJWTToken(Mockito.any())).thenReturn(decodedSSOToken);
        //main call
        this.webTestClient
                .post()
                .uri("/prepaid-adaptor/payment/addRefillCard")
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON)
                .header("token", token)
                .header("channelId", "VZW-DOTCOM")
                .header("x-soe-apikey", x_soe_apikey)
                .header("X-XSRF-TOKEN", xsrf_token)
                .header("prospect_jwt", token)
                .header("digital_ig_session", "digital_ig_session")
                .cookie("XSRF-TOKEN", xsrf_token)
                //.body(refillCardCXPRequest, RefillCardCXPRequest.class)
                .bodyValue(refillCardCXPRequest)
                .exchange()
                .expectStatus()
                .isOk();
    }
*/

    @Test
    public void initBinderByNameTest() throws NoSuchMethodException {
        Assert.assertNotNull(prepayAdaptorPaymentController.getClass().getMethod("initBinderByName", WebDataBinder.class).getName());
        prepayAdaptorPaymentController.initBinderByName(new WebDataBinder(null));
    }

    @Test
    public void addRefillCardTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/controller/addRefillCardRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/controller/addRefillCardResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestData.json");
        Object request = mapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = mapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = mapper.readValue(responseString, RefillCardCXPResponse.class);
        //PrepaidODRequestData prepaidODRequestData = mapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/addRefillCard");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(responseString, HttpStatus.OK)));
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentController.addRefillCard(httpRequest,null, refillCardCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> Assert.assertNotNull(resp)).verifyComplete();
    }

    @Test
    public void addRefillCardRedisErrorTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/controller/addRefillCardRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/controller/addRefillCardResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestData.json");
        Object request = mapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = mapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = mapper.readValue(responseString, RefillCardCXPResponse.class);
        //PrepaidODRequestData prepaidODRequestData = mapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/addRefillCard");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.empty());
        //when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(responseString, HttpStatus.OK)));
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentController.addRefillCard(httpRequest, null, refillCardCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> Assert.assertNotNull(new RefillCardCXPResponse())).verifyComplete();
    }

    @Test
    public void addRefillCardServiceErrorStatusTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/controller/addRefillCardRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/controller/addRefillCardResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestData.json");
        Object request = mapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = mapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = mapper.readValue(responseString, RefillCardCXPResponse.class);
        //PrepaidODRequestData prepaidODRequestData = mapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/addRefillCard");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>("", HttpStatus.INTERNAL_SERVER_ERROR)));
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentController.addRefillCard(httpRequest, null, refillCardCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> resp.getStatusCode().equals(HttpStatus.INTERNAL_SERVER_ERROR)).verifyComplete();
    }

    @Test
    public void addRefillCardServiceErrorTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/controller/addRefillCardRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/controller/addRefillCardResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestData.json");
        Object request = mapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = mapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = mapper.readValue(responseString, RefillCardCXPResponse.class);
        //PrepaidODRequestData prepaidODRequestData = mapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/addRefillCard");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>("", HttpStatus.OK)));
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentController.addRefillCard(httpRequest, null, refillCardCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> Assert.assertNotNull(resp)).verifyComplete();
    }

    @Test
    public void removeRefillCardTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/controller/addRefillCardRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/controller/removeRefillCardResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestDataWithOneRefillCard.json");
        Object request = mapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = mapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = mapper.readValue(responseString, RefillCardCXPResponse.class);
        //PrepaidODRequestData prepaidODRequestData = mapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/removeRefillCard");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any(), eq(true))).thenReturn(Mono.just(new ResponseEntity<>(responseString, HttpStatus.OK)));
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentController.removeRefillCard(httpRequest,null, refillCardCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> Assert.assertNotNull(resp)).verifyComplete();
    }

    @Test
    public void removeRefillCardRedisErrorTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/controller/addRefillCardRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/controller/removeRefillCardResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestData.json");
        Object request = mapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = mapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = mapper.readValue(responseString, RefillCardCXPResponse.class);
        //PrepaidODRequestData prepaidODRequestData = mapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/removeRefillCard");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.empty());
        //when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(responseString, HttpStatus.OK)));
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentController.removeRefillCard(httpRequest, null, refillCardCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> Assert.assertNotNull(new RefillCardCXPResponse())).verifyComplete();
    }

    @Test
    public void removeRefillCardServiceErrorStatusTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/controller/addRefillCardRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/controller/removeRefillCardResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestData.json");
        Object request = mapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = mapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = mapper.readValue(responseString, RefillCardCXPResponse.class);
        //PrepaidODRequestData prepaidODRequestData = mapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/removeRefillCard");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any(), eq(true))).thenReturn(Mono.just(new ResponseEntity<>("", HttpStatus.INTERNAL_SERVER_ERROR)));
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentController.removeRefillCard(httpRequest, null, refillCardCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> resp.getStatusCode().equals(HttpStatus.INTERNAL_SERVER_ERROR)).verifyComplete();
    }

    @Test
    public void removeRefillCardServiceErrorTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/controller/addRefillCardRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/controller/removeRefillCardResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestData.json");
        Object request = mapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = mapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = mapper.readValue(responseString, RefillCardCXPResponse.class);
        //PrepaidODRequestData prepaidODRequestData = mapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/removeRefillCard");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any(), eq(true))).thenReturn(Mono.just(new ResponseEntity<>("", HttpStatus.OK)));
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentController.removeRefillCard(httpRequest, null, refillCardCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> Assert.assertNotNull(resp)).verifyComplete();
    }

    @Test
    public void removeAllRefillCardsTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/payment/controller/addRefillCardRequest.json");
        String responseString = FileReaderUtil.readFromFile("data/payment/controller/removeRefillCardResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/payment/redisPrepaidODRequestDataWithMultipleRefillCards.json");
        Object request = mapper.readValue(requestString, Object.class);
        RefillCardCXPRequest refillCardCXPRequest = mapper.readValue(requestString, RefillCardCXPRequest.class);
        RefillCardCXPResponse refillCardCXPResponse = mapper.readValue(responseString, RefillCardCXPResponse.class);
        //PrepaidODRequestData prepaidODRequestData = mapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/payment/removeAllRefillCards");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.GET, url).build();
        when(prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(responseString, HttpStatus.OK)));
        Mono<ResponseEntity<RefillCardCXPResponse>> controllerResp = prepayAdaptorPaymentController.removeAllRefillCards(httpRequest,null);
        StepVerifier.create(controllerResp).assertNext(resp-> Assert.assertNotNull(resp)).verifyComplete();
    }

}
