package onevz.soe.prepay.adaptor.checkout.helper;

import onevz.soe.prepay.adaptor.checkout.helper.PrepayAdaptorCheckoutHelper;
import onevz.soe.prepay.adaptor.checkout.config.PrepayCheckoutAdaptorServiceTestConfig;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import static org.junit.Assert.*;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {PrepayCheckoutAdaptorServiceTestConfig.class})
@WebFluxTest(PrepayAdaptorCheckoutHelper.class)
public class PrepayAdaptorCheckoutHelperTest {

    @Autowired
    PrepayAdaptorCheckoutHelper prepayAdaptorCheckoutHelper;

    @Test
    public void templateMethodTest() {
        String src ="123";
        Mono<ResponseEntity<String>> responseMono = Mono.just(ResponseEntity.status(HttpStatus.OK).body(src));
        Mono<ResponseEntity<String>> actual = prepayAdaptorCheckoutHelper.templateMethod(src);
        StepVerifier.create(actual).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        assertNotNull(responseMono);
    }

    @Test
    public void templateMethodErrorTest() {
        String src =null;
        Mono<ResponseEntity<String>> responseMono = null;
        Mono<ResponseEntity<String>> actual = prepayAdaptorCheckoutHelper.templateMethod(src);
        StepVerifier.create(Mono.just("Exception").map(element -> {throw new RuntimeException();})).expectError().verify();
        assertNull(responseMono);
    }
}
