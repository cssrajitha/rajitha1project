package onevz.soe.prepay.adaptor.checkout.model.payment.response;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@ToString
@Data
public class FeatureList {
	private boolean binDetection; 
}
