package onevz.soe.prepay.adaptor.checkout.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;


public class CommonPrepayServiceException extends ResponseStatusException{

	/**
	 * 
	 * @param status
	 * @param message
	 */
	public CommonPrepayServiceException(HttpStatus status,String message) {
		super(status, message);
	}


}
