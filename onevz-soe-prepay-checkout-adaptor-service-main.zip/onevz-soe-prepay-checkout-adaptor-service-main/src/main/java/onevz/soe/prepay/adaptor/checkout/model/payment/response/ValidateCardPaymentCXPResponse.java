package onevz.soe.prepay.adaptor.checkout.model.payment.response;

import java.util.ArrayList;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;



/**
 * 
 * Pojo of validate Card
 *
 */
@Getter
@Setter
@NoArgsConstructor
public class ValidateCardPaymentCXPResponse {
	private ResponseMeta meta;
	private ValidateCardResponse data;
	private ArrayList<ErrorResponse> errors;
}
