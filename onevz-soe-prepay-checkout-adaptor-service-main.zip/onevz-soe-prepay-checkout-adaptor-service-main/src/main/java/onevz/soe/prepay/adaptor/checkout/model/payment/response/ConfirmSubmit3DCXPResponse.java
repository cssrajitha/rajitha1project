package onevz.soe.prepay.adaptor.checkout.model.payment.response;

import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


/**
 * Developed By: Manikanta Kv Copyright (c) 2019. All right reserved
 * 
 * @author kvma
 * 
 *         POJO class.
 *
 */
@Getter
@Setter
@NoArgsConstructor
public class ConfirmSubmit3DCXPResponse {
	private ResponseMeta meta;
	private ConfirmSubmit3DCXPResponseData data;
	private List<ErrorResponse> errors;
}
