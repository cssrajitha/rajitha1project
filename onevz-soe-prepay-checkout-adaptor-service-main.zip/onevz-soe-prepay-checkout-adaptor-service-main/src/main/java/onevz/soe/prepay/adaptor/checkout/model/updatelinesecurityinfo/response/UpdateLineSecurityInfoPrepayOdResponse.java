package onevz.soe.prepay.adaptor.checkout.model.updatelinesecurityinfo.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import onevz.soe.od.model.Errors;

@Setter
@Getter
@NoArgsConstructor
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UpdateLineSecurityInfoPrepayOdResponse {

    public int status;
    public String statusCode;
    public Payload payload;
    public Errors errors;

}
