package onevz.soe.prepay.adaptor.checkout.model.paypal.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import onevz.soe.prepay.adaptor.checkout.model.payment.response.SOEResponse;

import java.util.ArrayList;

/**
 * Developed By: Rativardhan Singh Sengar
 * 
 * Last Modified 10/24/19 1:39 PM
 * Copyright (c) 2019. All right reserved
 * @author sengara
 * 
 * POJO class.
 *
 */
@Getter
@Setter
@NoArgsConstructor
public class ErrorResponse implements SOEResponse {
	
	@JsonInclude(Include.ALWAYS)
	private String namespace;
	@JsonInclude(Include.ALWAYS)
	private String name;
	@JsonInclude(Include.ALWAYS)
	private String id;
	@JsonProperty(value="debug_id")
	private String debugId;
	@JsonInclude(Include.ALWAYS)
	private String message;
	private String type;
	private String errorCategory;
	
	private ArrayList<DetailsErrorResponse> details = new ArrayList<>();
	
}

