package onevz.soe.prepay.adaptor.checkout.model.bpm.response.orderwrite;

import lombok.Data;


@Data
public class DeviceFingerPrint {
	private HttpHeaderData httpRequestHeaders;
	private ScreenResolution screenResolution;
	private String touchSupport;
	private String listOfInstalledFonts;
	private String[] listOfMimeTypes;
	private String cookieStatus;
	private String nsaPrepayOrder;
}