package onevz.soe.prepay.adaptor.checkout.model.payment.request.paymenttype;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
/**
 * Developed By: Rativardhan Singh Sengar
 * 
 * Last Modified 10/24/19 1:39 PM
 * Copyright (c) 2019. All right reserved
 * @author sengara
 * 
 * POJO class.
 *
 */
@Getter
@Setter
@NoArgsConstructor
public class CardAdditionalInfo implements Serializable{
	private static final long serialVersionUID = -1830511093832018665L;
	private String firstName;
	private String midInitials;
	private String lastName;
	private String suffix;
	private Prefix prefix;
	//@NotEmpty(message = "AddressLine1 should not be null/empty")
	private String addressLine1;
	private String addressLine2;
	private String city;
	private String state;
	private String countryCode;
	private String zipCode;
}
