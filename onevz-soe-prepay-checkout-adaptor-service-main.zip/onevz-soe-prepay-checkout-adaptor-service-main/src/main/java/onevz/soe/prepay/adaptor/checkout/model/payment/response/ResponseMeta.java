package onevz.soe.prepay.adaptor.checkout.model.payment.response;

import java.util.Date;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
/**
 * Developed By: Rativardhan Singh Sengar
 * 
 * Last Modified 10/24/19 1:39 PM
 * Copyright (c) 2019. All right reserved
 * @author sengara
 *
 * POJO class
 */
@Getter
@Setter
@NoArgsConstructor
public class ResponseMeta {
	
	private Date timestamp;
	private String cxpCorrelationId;

}
