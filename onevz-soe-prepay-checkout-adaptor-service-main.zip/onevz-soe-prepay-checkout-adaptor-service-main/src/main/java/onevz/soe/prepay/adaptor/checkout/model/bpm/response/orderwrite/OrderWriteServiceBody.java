package onevz.soe.prepay.adaptor.checkout.model.bpm.response.orderwrite;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.*;
import onevz.soe.prepay.adaptor.checkout.model.bpm.request.OrderWriteServiceRequest;
import onevz.soe.wsclient.bpm.model.ServiceBody;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(callSuper=true)
public class OrderWriteServiceBody extends ServiceBody{
	@JsonInclude(Include.NON_NULL)
	private OrderWriteServiceRequest orderWriteServiceRequest;
	
	@JsonInclude(Include.NON_NULL)
	private OrderWriteServiceResponse orderWriteServiceResponse;

}
