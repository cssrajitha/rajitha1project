package onevz.soe.prepay.adaptor.checkout.model.payment.request.paymenttype;
/**
 * Developed By: Rativardhan Singh Sengar
 * 
 * Last Modified 10/24/19 1:39 PM
 * Copyright (c) 2019. All right reserved
 * @author sengara
 * 
 * About success, and error messages
 *
 */
public final class MessageConstants {

	// Move into erroConstants class and extends here
	public static final String	SOMETHING_WENT_WRONG		= "Something went wrong.";
	public static final String	EMPTY_META					= "META obj is missing.";
	public static final String	EMPTY_OBJ					= "Obj is empty.";
	public static final String	EMPTY_CLIENT_APP_NAME		= "Client Id is missing.";
	public static final String	EMPTY_CART_ID				= "Cart Id is missing";
	public static final String	EMPTY_CASE_ID				= "Case Id is missing";
	public static final String	EMPTY_LOCATION_CODE			= "Location Code is missing";
	public static final String	EMPTY_ORDER_NUM				= "Order Number is missing";
	public static final String	EMPTY_CARD_NUMBER			= "Card Number is missing";
	public static final String	EMPTY_CARD_EXP_DATE			= "Card Exp/Date is missing";
	public static final String	EMPTY_ENCRYPT_TYPE			= "Encrypt Type is missing";
	public static final String	EMPTY_ENCRYPTED_CARD_DATA	= "Encrypted Card Data is missing";
	public static final String	EMPTY_ENCRYPTED_CARD_DATA2	= "Encrypted Card Data2 is missing";
	public static final String	EMPTY_PIN					= "Card PIN is missing";
	public static final String	EMPTY_REG_NO				= "REG No is missing";
	public static final String	INVALID_SWEEP_AMOUNT		= "Invalid sweep amount.";
	public static final String	EMPTY_SALES_REP				= "SalesRep is missing ";
	public static final String	EMPTY_PAYMENT_TYPE			= "PaymentType is missing";
	public static final String	INVALID_PAYMENT_AMOUNT		= "Invalid payment amount";
	public static final String	EMPTY_CARD_EXP_YEAR			= "Card exp year is missing";
	public static final String	EMPTY_CARD_EXP_MONTH		= "Card exp month is missing";
	public static final String	EMPTY_CARD_ADDRESS_ZIP		= "Card Address Zip is missing";
	public static final String	EMPTY_CARD_TYPE				= "Card Type is missing";
	public static final String	EMPTY_ORDER_TYPE			= "Order Type is missing";
	public static final String	EMPTY_USER_ID				= "User Id is missing";
	public static final String	EMPTY_PAYMENT_VOID			= "Payment Void is missing";
	public static final String	EMPTY_CUSTOMER_INFO			= "Customer Info is missing";
	public static final String	EMPTY_PAYMENT_VOID_USER		= "Payment Void User is missing";
	public static final String	EMPTY_PAYMENT_SEQ_NO		= "Payment Sequence Number is invalid";
	public static final String	EMPTY_GROUP_ID				= "Group Id is missing";
	public static final String  EMPTY_CHECK_NUMBER          = "Check Number is missing";
	public static final String  EMPTY_CHECK_DATE            = "Check Date is missing";
	
	public static final String	EMPTY_CREDIT_APP_NUM		= "Credit Application Num is missing";
	public static final String	EMPTY_CASH_CHANGE_DUE		= "Cash Change Due is invalid";
	public static final String	EMPTY_MTN_LEVEL_CHARGE		= "MTN LevelCharge is missing";
	
	public static final String	EMPTY_TRIGGER_FROM			= "TriggerFrom is missing";
	public static final String	EMPTY_ACTION				= "Action is missing or Empty";
	public static final String	EMPTY_3D_SECURE_ENABLED		= "3d Secure Enabled is missing";
	public static final String	EMPTY_CARDINAL_JWT_TOKEN	= "Cardinal JWT Token is missing";
	
	public static final String  EMPTY_TRANSACTION_ID   		 = "Transaction ID is missing";
	public static final String  EMPTY_CHECK_ID         		 = "Check ID is missing";
	public static final String  EMPTY_ENCRIPTION_INDICATOR   = "Encryption Indicator is missing";
	
	public static final String EMPTY_END_POINT_URL           = "EndPointURL is missing";
	public static final String EMPTY_TRANSACTION_IDENTIFIER  = "Transaction Identifier is missing";
	public static final String EMPTY_SECURE_JWT_TOKEN		 = "secureJwtToken is missing";
	
	public static final String EMPTY_CUSTOMER_ID			 = "customerId is missing";
 	
	public static final String EMPTY_ACC_NO					 = "Account Number is missing";
	public static final String EMPTY_MTN					 = "MTN is missing";
	public static final String EMPTY_PROCESS_STEP			 = "Missing Process step";
	public static final String EMPTY_PAYMENT_INFO			 = "Payment info Cannot be empty ";
	public static final String EMPTY_INSTALL_LOAN_NUMBER	 = "Installment Loan Number cannot be empty ";
	public static final String EMPTY_EMAIL_ID				 = "Email ID cannot Be Empty";
	
	public static final String MAX_PAYMENT_SUBMIT_NOT_ALLOWED = "We’re sorry, you’ve exceeded the maximum amount of attempts. Please visit your nearest Verizon store to process your order.";
	// Common Message
	public static final String	INVALID_DATE_FORMAT	= "Date Format should be %s";
	public static final String	OBJECT_MISSING		= "%s is missing or Empty.";

	// Move into SuccessConstants class and extends here
	public static final String ERROR_OCCURRED_WHILE_PROCESSING	= "Error occurred while processing : {} ";

	public static final String NO_DATA_RETURNED_FROM_CXP_SERVICE = "NO data returned from CXP service";

	private MessageConstants() {

	}

}
