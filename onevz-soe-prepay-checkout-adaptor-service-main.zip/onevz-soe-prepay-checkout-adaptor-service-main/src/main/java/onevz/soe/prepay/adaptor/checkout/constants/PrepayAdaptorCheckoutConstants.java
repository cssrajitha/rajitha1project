package onevz.soe.prepay.adaptor.checkout.constants;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;


/**
 * Cart Constants class.
 */
public class PrepayAdaptorCheckoutConstants {

	public static final String DIGITAL = "digital";
	public static final String ASSISTED = "assisted";
	
	public static final String PREPAY_OD_REQUEST_DATA = "prepay_odRequestData";
	public static final String PREPAY_OD_REQUEST_ECOMM_SESSION = "ECOMM_SESSION";
	public static final String PREPAY_OD_REQUEST_P_CSRF_TKN = "pcsrfToken";

	public static final String PREPAY_OD_ECOMM_SESSION="eCommSessionId";

	public static final String PREPAY_OD_ORDER_LANGUAGE="orderLanguage";

	public static final String PREPAY_OD_COOKIE="Cookie";

	public static final String PREPAY_CHECKOUT_ADAPTOR="Checkout-Adaptor";

	public static final String PREPAY_OD="Prepaid";
	public static final String PREPAY_OD_REQUEST_P_CSRF_TOKEN = "p-csrf-token";
	public static final String PREPAY_E2E_REQUEST_ID = "E2erequestid";

	public static final String PREPAY_ORIGIN = "Origin";
	public static final String PREPAY_DIGITAL_IG_SESSION = "digital_ig_session";
	
	public static final String PREPAY_SAFETECH_SESSION_ID = "safeTechSessionId";

	public static final String PREPAY_MTN_NEWLINE_PREFIX = "newLine";
	
	public static final String PREPAY_CART_SERVICES_HEADER_STATUS_MSG_SUCCESS = "SUCCESS";
	public static final String PREPAY_CART_SERVICES_HEADER_STATUS_CODE_SUCCESS = "00";
	public static final String PREPAY_CHECKOUT_SERVICES_HEADER_STATUS_MSG_SUCCESS = "SUCCESS";
	public static final String PREPAY_CHECKOUT_SERVICES_HEADER_STATUS_CODE_SUCCESS = "00";
	public static final String PREPAY_CHECKOUT_SERVICES_HEADER_STATUS_MSG_FAILURE = "FAILURE";
	public static final String PREPAY_CHECKOUT_SERVICES_HEADER_STATUS_CODE_FAILURE = "01";
	public static final String PREPAY_CHECKOUT_SERVICES_ORDER_WRITE_PROCESS_STEP_SUCCESS = "Confirmation";
	public static final String PREPAY_CHECKOUT_SERVICES_ORDER_WRITE_PROCESS_STEP_FAILURE = "Agreement";
	
	public static final List<String> CR_PAYMENT_METHODS = Collections.unmodifiableList(Arrays.asList("VISA", "MASTERCARD", "DISCOVER", "AMERICANEXPRESS"));
	public static final String PAYMENT_METHOD_PAYPAL = "paypal";
	public static final String PAYMENT_METHOD_APPLEPAY = "applepay";
	public static final String PAYMENT_OPTION_CREDITCARD_TYPE = "CR";
	public static final String PAYMENT_OPTION_PAYPAL_TYPE = "PY";
	public static final String PAYMENT_OPTION_APPLEPAY_TYPE = "AP";
	
	public static final String ORDERWRITE_OD_SERVICE_ERR_NAME = "ORDER_WRITE_OD_SERVICE_ERROR";
	public static final String ORDERWRITE_OD_BUSINESS_ERR_NAME = "ORDER_WRITE_OD_BUSINESS_ERROR";
	public static final String ORDERWRITE_OD_SERVICE_ERR_ID = "7255";
	public static final String ORDERWRITE_OD_BUSINESS_ERR_ID = "7250";
	public static final String ORDERWRITE_OD_SERVICE_ERR_MSG = "Order Write OD Service Request Error";

	public static final String ORDERWRITE_OD_BUSINESS_ERR_MSG = "At this time, Verizon is not able to complete your transaction with your current payment method";

	public static final String ORDERWRITE_OD_ERROR_CATEGORY = "SERVICEERR";
	public static final String ORDERWRITE_OD_BUSINESS_ERROR_CATEGORY = "BUSINESS_ERR";
	public static final String PROACTIVE_CHAT_CUSTOMER_ERR_MSG="We see you are experiencing issues with your order. Chat now to connect to a live agent for further assistance";
	public static final String PROACTIVE_CHAT_INDICATOR="Y";

	public static final String NSE ="NSE";
	public static final String PREPAY_OD_REQUEST_FLOW = "FLOW";
	
	public static final String UPDATE_SECURITY_PIN_SERVICE_ERR_NAME = "UPDATE_SECURITY_PIN_SERVICE_ERROR";
	public static final String UPDATE_SECURITY_PIN_BUSINESS_ERR_NAME = "UPDATE_SECURITY_PIN_BUSINESS_ERROR";
	public static final String UPDATE_SECURITY_PIN_SERVICE_ERR_ID = "7265";
	public static final String UPDATE_SECURITY_PIN_BUSINESS_ERR_ID = "7260";
	public static final String UPDATE_SECURITY_PIN_SERVICE_ERR_MSG = "Update Security PIN Service Error";
	public static final String UPDATE_SECURITY_PIN_ERROR_CATEGORY = "SERVICEERR";
	public static final String UPDATE_SECURITY_PIN_BUSINESS_ERROR_CATEGORY = "BUSINESS_ERR";
	
	public static final String SHIPMENT_PROCESS_STEP = "Shipment";

	public static final String NUMBER_SHARE = "numbershare";
	public static final String PAYMENT_PROCESS_STEP = "Payment";
	public static final String ACCOUNT_PIN_PROCESS_STEP = "accountpin";
	public static final String NSE_PREPAY_INTEND_TYPE="NSE-Prepay";

	public static final String CONVERT_OBJECT_TO_STRING_LOG_MSG="Exception occur during converting response to String";
	public static final String CONVERT_OBJECT_TO_STRING_ERR_MSG="Exception occur during converting response to String {}";
	public static final String CONST_ENDPOINT="endPoint";

	public static final String REFILLCARD_FAILURE_NAME = "REFILL_CARD_FAILURE";
	public static final String REFILLCARD_FAILURE_ID = "8000";
	public static final String REFILLCARD_FAILURE_MSG = "Failure to process the refill card";
	public static final String REFILLCARD_FAILURE_BUSINESS = "BUSINESSERR";
	public static final String REFILLCARD_FAILURE_SYSTEM = "SYSTEMERR";
	public static final String REFILLCARD_DUPLICATE_FAILURE_MSG = "This Refill Pin is already applied in this order. Please try with a new one.";
	public static final String REFILLCARD_EMPTY_FAILURE_MSG = "There are no refill cards in cart to process";
	public static final String REFILLCARD_REMOVEALL_FAILURE_MSG = "Failed to remove all refill cards from cart";
	public static final String REFILLCARD_REMOVEALL_REDIS_FAILURE_MSG = "Failed to remove all refill cards from Redis";
	public static final String REFILLCARD_REDIS_FAILURE_MSG = "Failed to retrieve data from Redis";
	public static final String REFILLCARD_REDIS_FAILURE_PARSE_MSG = "Failed to parse the Redis data";
	public static final String PREPAY_OD_REQUEST_P_CSRFTKN = "p_csrftkn";
	public static final String NSE_BYOD = "NSEBYOD";
	public static final String NSP = "NSP";
	public static final String PASO = "PASO";

	public static final String PAL = "PAL";

	public static final String AAL = "AAL";

	public static final String EUP = "EUP";

	public static final String PUP = "PUP";
	public static final String ESO = "ESO";
	public static final String BYOD = "BYOD";

	public static final String NEW_PLANS_PROCESS_STEP = "NewRecommendedPlanSelection";

	private PrepayAdaptorCheckoutConstants() {

	}
}


