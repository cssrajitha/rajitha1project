package onevz.soe.prepay.adaptor.checkout.model.bpm.response.orderwrite;

import lombok.Data;

@Data
public class EnforceData {
	private DeviceFingerPrint deviceFingerPrint;
	private String vzSessionId;
	private String vzOrderId;
	private String visitorId;
	private String orderStartTime;
	private String orderEndTime;
	private String shareCartIndicator;
}