package onevz.soe.prepay.adaptor.checkout.model.bpm.response.orderwrite;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString

public class SubmitOrderPageData {
	@JsonInclude(Include.NON_NULL)
	private String orderId;
	private Boolean orderSubmitted;
	private Boolean success;
	private String errorMap;
	private SubmitOrderPageDataOrderVo orderVo;


}
