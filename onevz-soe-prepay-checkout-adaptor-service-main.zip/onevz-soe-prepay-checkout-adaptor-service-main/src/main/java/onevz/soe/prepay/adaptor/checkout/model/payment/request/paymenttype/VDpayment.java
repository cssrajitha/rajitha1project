package onevz.soe.prepay.adaptor.checkout.model.payment.request.paymenttype;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@NoArgsConstructor
public class VDpayment implements Serializable {

	private String mobileNumber;
	private String accountNumber;
	private String accountSubNumber;
	private String billingSystem;
	private String marketId;
	private double dueTodayVerizonDollarAmount;
	private List<DownPaymentVerizonDollarAmount> downPaymentVerizonDollarAmount;
	private boolean mtnLevelCharge;
}
