package onevz.soe.prepay.adaptor.checkout.model.applepay.response;

import lombok.Data;
import onevz.soe.prepay.adaptor.checkout.model.payment.response.Payload;

@Data
public class ProcessApplePaySessionPlayResponse {
	
	private String status;
	private String statusCode;
	private Payload payload;

}
