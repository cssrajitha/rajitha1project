package onevz.soe.prepay.adaptor.checkout.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.model.initiateCheckout.*;
import onevz.soe.logging.util.LoggerUtil;
import onevz.soe.od.model.Errors;
import onevz.soe.od.model.*;
import onevz.soe.prepay.adaptor.checkout.constants.PrepayAdaptorCheckoutConstants;
import onevz.soe.prepay.adaptor.checkout.model.applepay.request.*;
import onevz.soe.prepay.adaptor.checkout.model.applepay.response.GetApplePaySessionResponse;
import onevz.soe.prepay.adaptor.checkout.model.bpm.response.orderwrite.DeviceFingerPrintResponse;
import onevz.soe.prepay.adaptor.checkout.model.payment.request.ConfirmSubmit3DCXPRequest;
import onevz.soe.prepay.adaptor.checkout.model.payment.request.ConfirmSubmit3DSecureCXPRequestData;
import onevz.soe.prepay.adaptor.checkout.model.payment.request.ValidateCardCXPRequest;
import onevz.soe.prepay.adaptor.checkout.model.payment.response.*;
import onevz.soe.prepay.adaptor.checkout.model.paypal.request.CMPILookupCXPRequest;
import onevz.soe.prepay.adaptor.checkout.model.paypal.request.PreauthDigitalPayCXPRequest;
import onevz.soe.prepay.adaptor.checkout.model.paypal.response.CMPILookupCXPResponse;
import onevz.soe.prepay.adaptor.checkout.model.paypal.response.CMPILookupCXPResponseData;
import onevz.soe.prepay.adaptor.checkout.model.paypal.response.CmpiLookupReponse;
import onevz.soe.prepay.adaptor.checkout.model.paypal.response.PreauthDigitalPayCXPResponse;
import onevz.soe.prepay.adaptor.checkout.util.PrepayAdaptorCheckoutUtil;
import onevz.soe.prepay.payment.request.cxp.DecryptTokenRequest;
import onevz.soe.prepay.payment.request.cxp.ProcessApplePaySessionCxpRequest;
import onevz.soe.prepay.payment.request.ui.paymentdata.BillingContact;
import onevz.soe.prepay.payment.request.ui.paymentdata.Header;
import onevz.soe.prepay.payment.request.ui.paymentdata.ShippingContact;
import onevz.soe.prepay.payment.response.cxp.GetApplePaySessionCXPResponse;
import onevz.soe.prepay.payment.response.cxp.ProcessApplePaySessionCXPResponse;
import onevz.soe.prepay.payment.response.cxp.ProcessApplePaySessionResponseData;
import onevz.soe.prepay.payment.response.ui.paymentdata.ApplePayResponseInfo;
import onevz.soe.prepay.payment.response.ui.paymentdata.GetSessionResponse;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.bpm.model.CartInfo;
import onevz.soe.wsclient.bpm.model.ServiceHeader;
import onevz.soe.wsclient.bpm.model.request.ContextInfo;
import onevz.soe.wsclient.bpm.model.response.AvailablePaths;
import onevz.soe.wsclient.bpm.model.response.Error;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import onevz.soe.wsclient.prepay.webclient.model.PrepaidAdaptorWebClientRequest;
import org.apache.commons.lang3.StringUtils;
import org.apache.hc.core5.http.ContentType;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import jakarta.validation.Valid;
import java.util.*;

import static onevz.soe.prepay.adaptor.checkout.constants.PrepayAdaptorCheckoutConstants.*;
import static onevz.soe.prepay.personalization.constants.PrepayConstants.*;

@Service
public class PrepayAdaptorOrderWriteHelper {

	@Autowired
	private ObjectMapper mapper;

	@Autowired
	private PrepayAdaptorWebClient prepayAdaptorWebClient;

	@Autowired
	PrepayCheckoutRedisHelper prepayCheckoutRedisHelper;

	@Autowired
	SOELoginSessionBean sessionBean;

	@Value("${orderWritePrepaidLegacyServiceUrl}")
	private String orderWritePrepaidLegacyServiceUrl;

	@Value("${prepaidUpdatePayment}")
	private String prepaidUpdatePayment;
	
	@Value("${paypalCmpiLookup}")
	private String paypalCmpiLookup;
	
	@Value("${paypalAuth}")
	private String paypalAuth;
	
	@Value("${deviceFingetPrintPrepaidLegacyServiceUrl}")
	private String deviceFingetPrintPrepaidLegacyServiceUrl;
		
	@Value("${enablerLog}")
	private boolean enableOrderLog;
	
	@Value("${getApplePaySession}")
	private String getApplePaySession;
	
	@Value("${getApplePaySessionEndPoint}")
	private String getApplePaySessionEndPoint;
	
	@Value("${processApplePaySession}")
	private String processApplePaySession;

	public static final String HEADER_P_CSRFTKN = "; " + PREPAY_OD_REQUEST_P_CSRFTKN + "=";
	private static final Logger logger = LoggerFactory.getLogger(PrepayAdaptorOrderWriteHelper.class);

	public Mono<ResponseEntity<OrderWriteResponse>> orderWrite(ServerHttpRequest httpRequest,
			OrderWriteRequest orderWriteRequest) {
		logger.info("Started orderWrite Service");
		
		return prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)
			.doOnError(err -> logger.error("OrderWrite service Redis Failed and return error", err))
			.defaultIfEmpty("")
			.flatMap(redisData -> {
			
				OrderWriteResponse orderWrtResp = new OrderWriteResponse();
					
				if (null == redisData || redisData.isEmpty()) {
					logger.error("Redis data in Orderwrite service: {} of the key is empty ",PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA);
					List<Error> errResp = PrepayAdaptorCheckoutUtil.buildErrorResponse(PrepayAdaptorCheckoutConstants.ORDERWRITE_OD_SERVICE_ERR_NAME, 
                    																   PrepayAdaptorCheckoutConstants.ORDERWRITE_OD_SERVICE_ERR_ID, 
                    																   PrepayAdaptorCheckoutConstants.ORDERWRITE_OD_SERVICE_ERR_MSG, 
                    																   PrepayAdaptorCheckoutConstants.ORDERWRITE_OD_ERROR_CATEGORY);
                    orderWrtResp.setErrors(errResp);
               		return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(orderWrtResp));
				} else {
					return prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_SAFETECH_SESSION_ID)
						.doOnError(err -> logger.error("Failed and return error", err))
						.defaultIfEmpty("")
						.flatMap(safeTechData -> {
						
							if (null == safeTechData || safeTechData.isEmpty()) {
								logger.error("Safetech Session ID in Redis: {} is empty",PrepayAdaptorCheckoutConstants.PREPAY_SAFETECH_SESSION_ID);
								List<Error> errResp = PrepayAdaptorCheckoutUtil.buildErrorResponse(PrepayAdaptorCheckoutConstants.ORDERWRITE_OD_SERVICE_ERR_NAME, 
										   PrepayAdaptorCheckoutConstants.ORDERWRITE_OD_SERVICE_ERR_ID, 
										   PrepayAdaptorCheckoutConstants.ORDERWRITE_OD_SERVICE_ERR_MSG, 
										   PrepayAdaptorCheckoutConstants.ORDERWRITE_OD_ERROR_CATEGORY);
								orderWrtResp.setErrors(errResp);
								return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(orderWrtResp));	
							}
							logger.info("SafeTech Session ID from Redis: {}", safeTechData);


							Map<String, String> requestData = prepayCheckoutRedisHelper.handleRedisData(redisData);

							return invokeDeviceFingerPrint(httpRequest,requestData,safeTechData,orderWriteRequest)
								.doOnError(error -> logger.error("Failed to get Device FingerPrint OD response, check exception for details:",error))
								.flatMap(deviceFPResp-> {
								if (!deviceFPResp.getStatusCode().is2xxSuccessful()) {
									logger.error("Error while calling Device Finger Print OD with status code: {}", deviceFPResp.getStatusCode());
								}
								logger.info("DeviceFingerPrint OD call response body: {}",deviceFPResp.getBody());
						
								PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = new PrepaidAdaptorWebClientRequest();
								prepaidAdaptorWebClientRequest = setPrepaidLegacyServiceHeaders(requestData, safeTechData, prepaidAdaptorWebClientRequest,httpRequest,orderWriteRequest);
								prepaidAdaptorWebClientRequest.setUrl(orderWritePrepaidLegacyServiceUrl);
								prepaidAdaptorWebClientRequest.setRequestBody("{}");
								prepaidAdaptorWebClientRequest.setRequestType(HttpMethod.POST.toString());
								logger.info("SubmitOrder OD Request Headers: {}", prepaidAdaptorWebClientRequest.getHeader());
								logger.info("SubmitOrder OD Request Data: {}",prepaidAdaptorWebClientRequest);
								// add method to call deviceFingerPrint on OD	
								
								return prepayAdaptorWebClient
									.getPrepayServiceResponse(httpRequest, prepaidAdaptorWebClientRequest)
									.doOnError(error -> logger.error("Failed to get Submit Order OD response, check exception for details:",error))
									.flatMap(responseEntity -> {
										logger.info("SubmitOrder OD Response Code: {} \nSubmitOrder OD Response Body: {}" ,responseEntity.getStatusCode(),responseEntity.getBody());
										OrderWriteResponse orderWriteResponse = new OrderWriteResponse();
										VZWPrepayOrderSubmitResponse submitOrderResponse;

                                        try {
                                            submitOrderResponse = mapper.readValue(responseEntity.getBody(), VZWPrepayOrderSubmitResponse.class);
                                            if ((!responseEntity.getStatusCode().is2xxSuccessful() || responseEntity.getBody().contains("errors"))) {
                                                logger.error("Error while calling SubmitOrder OD with status code: {}", responseEntity.getStatusCode());

                                                orderWriteResponse = getOrderWriteErrorPEGAResponse(submitOrderResponse, orderWriteRequest);
                                                if (submitOrderResponse.getStatus().equals("400")) {
                                                    logger.error("Error while calling SubmitOrder OD with status code: {}", responseEntity.getStatusCode());
                                                    List<Error> errResp = PrepayAdaptorCheckoutUtil.buildErrorResponse(PrepayAdaptorCheckoutConstants.ORDERWRITE_OD_SERVICE_ERR_NAME,
                                                            PrepayAdaptorCheckoutConstants.ORDERWRITE_OD_SERVICE_ERR_ID,
                                                            PrepayAdaptorCheckoutConstants.ORDERWRITE_OD_BUSINESS_ERR_MSG,
                                                            PrepayAdaptorCheckoutConstants.ORDERWRITE_OD_ERROR_CATEGORY);
                                                    orderWriteResponse.setErrors(errResp);
                                                } else {
                                                    Errors errors = submitOrderResponse.getErrors();
                                                    List<EcommApiErrorList> errorsList = errors.getEcommApiErrorList();
                                                    EcommApiErrorList ecommError = errorsList.get(0);
                                                    List<Error> errResp = PrepayAdaptorCheckoutUtil.buildErrorResponse(PrepayAdaptorCheckoutConstants.ORDERWRITE_OD_BUSINESS_ERR_NAME,
                                                            PrepayAdaptorCheckoutConstants.ORDERWRITE_OD_SERVICE_ERR_ID,
                                                            ecommError.getMessage(),
                                                            PrepayAdaptorCheckoutConstants.ORDERWRITE_OD_ERROR_CATEGORY);
                                                    orderWriteResponse.setErrors(errResp);

                                                }

                                                return Mono.just(ResponseEntity.status(HttpStatus.OK).body(orderWriteResponse));


                                            }
                                        else {

												logger.info("Submit Order Play response : {}", mapper.writeValueAsString(submitOrderResponse));
											
												if(submitOrderResponse.getErrors()!=null && submitOrderResponse.getPayload() == null ) {
													Errors errors = submitOrderResponse.getErrors();
													List<EcommApiErrorList> errorsList = errors.getEcommApiErrorList();
													EcommApiErrorList ecommError = errorsList.get(0);
													List<Error> errResp = PrepayAdaptorCheckoutUtil.buildErrorResponse(PrepayAdaptorCheckoutConstants.ORDERWRITE_OD_BUSINESS_ERR_NAME, 
															   PrepayAdaptorCheckoutConstants.ORDERWRITE_OD_BUSINESS_ERR_ID, 
															   ecommError.getMessage(), 
															   PrepayAdaptorCheckoutConstants.ORDERWRITE_OD_BUSINESS_ERROR_CATEGORY);
													orderWriteResponse.setErrors(errResp);
													return Mono.just(ResponseEntity.status(HttpStatus.OK).body(orderWriteResponse));
												}
												orderWriteResponse = getOrderWritePEGAResponse(submitOrderResponse,	orderWriteRequest);

												if(orderWriteResponse.getServiceHeader().getStatusCode().equalsIgnoreCase("01")&&(orderWriteResponse.getErrors() == null))
												{
	                    List<Error> errResp = PrepayAdaptorCheckoutUtil.buildErrorResponse(PrepayAdaptorCheckoutConstants.ORDERWRITE_OD_SERVICE_ERR_NAME,
			             PrepayAdaptorCheckoutConstants.ORDERWRITE_OD_BUSINESS_ERR_ID,
			             PrepayAdaptorCheckoutConstants.ORDERWRITE_OD_BUSINESS_ERR_MSG,
			             PrepayAdaptorCheckoutConstants.ORDERWRITE_OD_ERROR_CATEGORY);
	                   orderWriteResponse.setErrors(errResp);
												}
												kibanaCustomOrderWriteLogs(submitOrderResponse);
												
											}
                                        } catch (JsonProcessingException e) {
												logger.error("Error while mapping SubmitOrder OD Response to OrderWrite service response", e);
											}

										logger.info("OrderWrite Response from adaptor brefore returning from CheckoutAdaptor: {}", orderWriteResponse);
										return Mono.just(ResponseEntity.status(responseEntity.getStatusCode()).body(orderWriteResponse));
								});
							});
						});
					}
				});
	}
	
	public Mono<ResponseEntity<DeviceFingerPrintResponse>> invokeDeviceFingerPrint(ServerHttpRequest httpRequest, Map<String, String> requestData, String safeTechData, OrderWriteRequest orderWriteRequest) {
		// TODO Auto-generated method stub
		PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = new PrepaidAdaptorWebClientRequest();
		setPrepaidLegacyServiceHeaders(requestData, safeTechData, prepaidAdaptorWebClientRequest,httpRequest,orderWriteRequest);
		prepaidAdaptorWebClientRequest.setRequestType(HttpMethod.POST.toString());
		prepaidAdaptorWebClientRequest.setUrl(deviceFingetPrintPrepaidLegacyServiceUrl);
		
		VZWPrepayDeviceFingerPrintRequest deviceFPODRequest = new VZWPrepayDeviceFingerPrintRequest();
		deviceFPODRequest.setOrderStartTime(orderWriteRequest.getOrderWriteServiceBody().getOrderWriteServiceRequest().getOrderWriteContext().getEnforceData().getOrderStartTime());
		deviceFPODRequest.setOrderEndTime(orderWriteRequest.getOrderWriteServiceBody().getOrderWriteServiceRequest().getOrderWriteContext().getEnforceData().getOrderEndTime());
		deviceFPODRequest.setShareCartIndicator(orderWriteRequest.getOrderWriteServiceBody().getOrderWriteServiceRequest().getOrderWriteContext().getEnforceData().getShareCartIndicator());
		deviceFPODRequest.setVzOrderId(orderWriteRequest.getOrderWriteServiceBody().getOrderWriteServiceRequest().getOrderWriteContext().getEnforceData().getVzOrderId());
		deviceFPODRequest.setVzSessionId(orderWriteRequest.getOrderWriteServiceBody().getOrderWriteServiceRequest().getOrderWriteContext().getEnforceData().getVzSessionId());
		
		DeviceFingerPrint deviceFP = new DeviceFingerPrint();
		deviceFP.setCookieStatus(orderWriteRequest.getOrderWriteServiceBody().getOrderWriteServiceRequest().getOrderWriteContext().getEnforceData().getDeviceFingerPrint().getCookieStatus());
		deviceFP.setHttpRequestHeaders(orderWriteRequest.getOrderWriteServiceBody().getOrderWriteServiceRequest().getOrderWriteContext().getEnforceData().getDeviceFingerPrint().getHttpRequestHeaders());
		deviceFP.setListOfInstalledFonts(orderWriteRequest.getOrderWriteServiceBody().getOrderWriteServiceRequest().getOrderWriteContext().getEnforceData().getDeviceFingerPrint().getListOfInstalledFonts());
		deviceFP.setListOfMimeTypes(orderWriteRequest.getOrderWriteServiceBody().getOrderWriteServiceRequest().getOrderWriteContext().getEnforceData().getDeviceFingerPrint().getListOfMimeTypes());
		deviceFP.setTouchSupport(orderWriteRequest.getOrderWriteServiceBody().getOrderWriteServiceRequest().getOrderWriteContext().getEnforceData().getDeviceFingerPrint().getTouchSupport());
		deviceFP.setScreenResolution(orderWriteRequest.getOrderWriteServiceBody().getOrderWriteServiceRequest().getOrderWriteContext().getEnforceData().getDeviceFingerPrint().getScreenResolution());
		deviceFP.setNsaFlag("Y");
		deviceFPODRequest.setDeviceFingerPrint(deviceFP);
		prepaidAdaptorWebClientRequest.setRequestBody(deviceFPODRequest);
		logger.info("DeviceFingerPrint OD Request Endpoint:{} \n Request Body: {} \nHeaders: {}\n",prepaidAdaptorWebClientRequest.getUrl(), prepaidAdaptorWebClientRequest.getRequestBody(),prepaidAdaptorWebClientRequest.getHeader());
		DeviceFingerPrintResponse deviceFpResp = new DeviceFingerPrintResponse();
		return prepayAdaptorWebClient
			.getPrepayServiceResponse(httpRequest, prepaidAdaptorWebClientRequest)
			.doOnError(error -> logger.error("Failed to get DeviceFingerPrint OD response, check exception for details",error))
			.flatMap(responseEntity -> {
				logger.info("Device Fingeprint OD Response Code: {} \nDevice Fingeprint OD Response Body: {}" ,responseEntity.getStatusCode(),responseEntity.getBody());
				if(Objects.nonNull(responseEntity)) {
					deviceFpResp.setSubmitted(true);
				} else {
					deviceFpResp.setSubmitted(false);
				}
				return Mono.just(ResponseEntity.status(HttpStatus.OK).body(deviceFpResp));
			});
	}
	
	private PrepaidAdaptorWebClientRequest setPrepaidLegacyServiceHeaders(Map<String, String> headerParams, String safeTechSession,
			PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest,ServerHttpRequest httpRequest,OrderWriteRequest orderWriteRequest) {
		logger.info("Inside setPrepaidLegacyServiceHeaders method for OrderWriteApi");
		
		Map<String, String> serviceHeaders = new HashMap<>();
		String cookies = PREPAY_OD_REQUEST_ECOMM_SESSION+"=" + headerParams.get(PREPAY_OD_ECOMM_SESSION) + HEADER_P_CSRFTKN
				+ headerParams.get(PREPAY_OD_REQUEST_P_CSRF_TKN);
		serviceHeaders.put(PrepayAdaptorCheckoutConstants.PREPAY_SAFETECH_SESSION_ID, safeTechSession);
		serviceHeaders.put(PrepayAdaptorCheckoutConstants.PREPAY_OD_COOKIE, cookies);
		serviceHeaders.put(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_P_CSRF_TOKEN,(headerParams.get(PREPAY_OD_REQUEST_P_CSRF_TKN)));
		serviceHeaders.put(CONTENT_TYPE, "application/json");
		String e2eRequestId = null;
	    
		if (null != httpRequest && null != httpRequest.getHeaders().getFirst("e2eRequestId")) {
			logger.info("Headers {}", httpRequest.getHeaders());
			logger.info("Uri {}",httpRequest.getURI());
	             e2eRequestId = httpRequest.getHeaders().getFirst("e2eRequestId");
	    }
		if(Objects.nonNull(orderWriteRequest.getOrderWriteServiceBody().getOrderWriteServiceRequest().getOrderWriteContext().getEnforceData().getDeviceFingerPrint().getHttpRequestHeaders().getOrderLanguage())){
			String language= orderWriteRequest.getOrderWriteServiceBody().getOrderWriteServiceRequest().getOrderWriteContext().getEnforceData().getDeviceFingerPrint().getHttpRequestHeaders().getOrderLanguage();
			serviceHeaders.put(PrepayAdaptorCheckoutConstants.PREPAY_OD_ORDER_LANGUAGE,language);
			logger.info("orderLanguage is found in header, value is #{}", language);
		}
	    String digitalIgSession = null;
	    
	    if (null != httpRequest && StringUtils.isBlank(digitalIgSession)
	       && httpRequest.getHeaders().containsKey(PrepayAdaptorCheckoutConstants.PREPAY_DIGITAL_IG_SESSION)
	       && null != httpRequest.getHeaders().getFirst(PrepayAdaptorCheckoutConstants.PREPAY_DIGITAL_IG_SESSION)) {
	       digitalIgSession = httpRequest.getHeaders().getFirst(PrepayAdaptorCheckoutConstants.PREPAY_DIGITAL_IG_SESSION);
	    }
	    serviceHeaders.put(PrepayAdaptorCheckoutConstants.PREPAY_E2E_REQUEST_ID,e2eRequestId);
	    serviceHeaders.put(PrepayAdaptorCheckoutConstants.PREPAY_E2E_REQUEST_ID,e2eRequestId);
        serviceHeaders.put(PrepayAdaptorCheckoutConstants.PREPAY_DIGITAL_IG_SESSION,digitalIgSession);
		prepaidAdaptorWebClientRequest.setHeader(serviceHeaders);
		return prepaidAdaptorWebClientRequest;
	}

	private OrderWriteResponse getOrderWritePEGAResponse(VZWPrepayOrderSubmitResponse submitOrderResponse,
			OrderWriteRequest orderWriteRequest) {
		
		OrderWriteResponse orderWritePEGAResponse = new OrderWriteResponse();
		ServiceHeader orderWriteHeader = new ServiceHeader();
		orderWriteHeader.setClientId(orderWriteRequest.getServiceHeader().getClientId());
		orderWriteHeader.setCorrelationId(orderWriteRequest.getServiceHeader().getCorrelationId());
		orderWriteHeader.setServiceName(orderWriteRequest.getServiceHeader().getServiceName());
		orderWriteHeader.setSessionId(orderWriteRequest.getServiceHeader().getSessionId());
		orderWriteHeader.setUserId(orderWriteRequest.getServiceHeader().getUserId());
	
		if(submitOrderResponse.getPayload().getPageData().isOrderSubmitted()
				&& submitOrderResponse.getPayload().getPageData().isSuccess()) {
			orderWriteHeader.setStatusMsg(PrepayAdaptorCheckoutConstants.PREPAY_CHECKOUT_SERVICES_HEADER_STATUS_MSG_SUCCESS);
			orderWriteHeader.setStatusCode(PrepayAdaptorCheckoutConstants.PREPAY_CHECKOUT_SERVICES_HEADER_STATUS_CODE_SUCCESS);
		} else {
			orderWriteHeader.setStatusMsg(PrepayAdaptorCheckoutConstants.PREPAY_CHECKOUT_SERVICES_HEADER_STATUS_MSG_FAILURE);
			orderWriteHeader.setStatusCode(PrepayAdaptorCheckoutConstants.PREPAY_CHECKOUT_SERVICES_HEADER_STATUS_CODE_FAILURE);
		}  
		
		orderWritePEGAResponse.setServiceHeader(orderWriteHeader);
		orderWritePEGAResponse.setServiceBody(getServiceBody(orderWriteRequest, submitOrderResponse));
		return orderWritePEGAResponse;
	}
    private OrderWriteResponse getOrderWriteErrorPEGAResponse(VZWPrepayOrderSubmitResponse submitOrderResponse,
                                                              OrderWriteRequest orderWriteRequest) {

        OrderWriteResponse orderWritePEGAResponse = new OrderWriteResponse();
        ServiceHeader orderWriteHeader = new ServiceHeader();
        orderWriteHeader.setClientId(orderWriteRequest.getServiceHeader().getClientId());
        orderWriteHeader.setCorrelationId(orderWriteRequest.getServiceHeader().getCorrelationId());
        orderWriteHeader.setServiceName(orderWriteRequest.getServiceHeader().getServiceName());
        orderWriteHeader.setSessionId(orderWriteRequest.getServiceHeader().getSessionId());
        orderWriteHeader.setUserId(orderWriteRequest.getServiceHeader().getUserId());
        orderWriteHeader.setStatusMsg(PrepayAdaptorCheckoutConstants.PREPAY_CHECKOUT_SERVICES_HEADER_STATUS_MSG_FAILURE);
        orderWriteHeader.setStatusCode(PrepayAdaptorCheckoutConstants.PREPAY_CHECKOUT_SERVICES_HEADER_STATUS_CODE_FAILURE);
        orderWritePEGAResponse.setServiceHeader(orderWriteHeader);
        return orderWritePEGAResponse;
    }


    private OrderWriteServiceBody getServiceBody(OrderWriteRequest orderWriteRequest,
			VZWPrepayOrderSubmitResponse submitOrderResponse) {
		OrderWriteServiceBody orderWriteServiceBody = new OrderWriteServiceBody();
		orderWriteServiceBody.setServiceResponse(getServiceResponse(orderWriteRequest, submitOrderResponse));
		return orderWriteServiceBody;
	}

	private OrderWriteServiceResponse getServiceResponse(OrderWriteRequest orderWriteRequest,
			VZWPrepayOrderSubmitResponse submitOrderResponse) {
		OrderWriteServiceResponse orderWriteServiceResponse = new OrderWriteServiceResponse();
		orderWriteServiceResponse.setContext(getResponseContext(orderWriteRequest, submitOrderResponse));
		return orderWriteServiceResponse;
	}

	private OrderWriteContext getResponseContext(OrderWriteRequest orderWriteRequest,
			VZWPrepayOrderSubmitResponse submitOrderResponse) {
		OrderWriteContext orderWriteContext = new OrderWriteContext();
		try {
			orderWriteContext.setCaseId(orderWriteRequest.getServiceBody().getServiceRequest().getContext().getCaseId());
			orderWriteContext.setContextInfo(getContextInfo(orderWriteRequest,submitOrderResponse));
			orderWriteContext.setCartInfo(getCartInfo(orderWriteRequest));
			orderWriteContext.setCustomerInfo(getCustomerInfo(orderWriteRequest,submitOrderResponse));
			String paymentMethod = submitOrderResponse.getPayload().getPageData().getOrderVo().getPaymentMethod();
			String paymentOption = "";
			if(StringUtilities.isNotEmptyOrNull(paymentMethod)) {
				if(PrepayAdaptorCheckoutConstants.PAYMENT_METHOD_PAYPAL.equalsIgnoreCase(paymentMethod)){
	                paymentOption = PrepayAdaptorCheckoutConstants.PAYMENT_OPTION_PAYPAL_TYPE;
	            } else if(PrepayAdaptorCheckoutConstants.PAYMENT_METHOD_APPLEPAY.equalsIgnoreCase(paymentMethod)) {
	            	paymentOption = PrepayAdaptorCheckoutConstants.PAYMENT_OPTION_APPLEPAY_TYPE;
	            } else { 
	                paymentMethod = paymentMethod.toUpperCase();
	                String[] paymentMethodTokens = paymentMethod.split(" ");
	                if(2 == paymentMethodTokens.length && (PrepayAdaptorCheckoutConstants.CR_PAYMENT_METHODS.contains(paymentMethodTokens[0].trim().toUpperCase()))) {
	                    	paymentOption = PrepayAdaptorCheckoutConstants.PAYMENT_OPTION_CREDITCARD_TYPE;
	                    }
			}
				
			PaymentOptions payOption = new PaymentOptions();
			payOption.setPaymentType(paymentOption);
			payOption.setBtaOrderTotal(String.valueOf(submitOrderResponse.getPayload().getPageData().getOrderVo().getOrderTotal()));
			payOption.setSavedCC(String.valueOf(submitOrderResponse.getPayload().getPageData().getOrderVo().isSaveCreditCard()));
			PaymentOptions[] payOptions = new PaymentOptions[1];
			payOptions[0] = payOption;
			orderWriteContext.setPaymentOptions(payOptions);
			}
			orderWriteContext.setOrderWrite(getOrderDetails(submitOrderResponse));
		} catch (Exception ex) {
			logger.error("Exception in building OrderWrite response context", ex);
		}
		return orderWriteContext;
	}
	
	private CartInfo getCartInfo(OrderWriteRequest orderWriteRequest) {
		CartInfo cartInfo = new CartInfo();
		cartInfo.setCartId(orderWriteRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getCartId());
		return cartInfo;
	}
	private ContextInfo getContextInfo(OrderWriteRequest orderWriteRequest,VZWPrepayOrderSubmitResponse submitOrderResponse) {
		ContextInfo contextInfo = new ContextInfo();
		AvailablePaths availablePaths = new AvailablePaths();
		contextInfo.setCallReason(
				orderWriteRequest.getServiceBody().getServiceRequest().getContext().getContextInfo().getCallReason());
		if(submitOrderResponse.getPayload().getPageData().isOrderSubmitted()
				&& submitOrderResponse.getPayload().getPageData().isSuccess()) {
			contextInfo.setProcessStep(PrepayAdaptorCheckoutConstants.PREPAY_CHECKOUT_SERVICES_ORDER_WRITE_PROCESS_STEP_SUCCESS);
			availablePaths.setPath(PrepayAdaptorCheckoutConstants.PREPAY_CHECKOUT_SERVICES_ORDER_WRITE_PROCESS_STEP_SUCCESS);
		} else {
			contextInfo.setProcessStep(PrepayAdaptorCheckoutConstants.PREPAY_CHECKOUT_SERVICES_ORDER_WRITE_PROCESS_STEP_FAILURE);
			availablePaths.setPath(PrepayAdaptorCheckoutConstants.PREPAY_CHECKOUT_SERVICES_ORDER_WRITE_PROCESS_STEP_FAILURE);
		}
		contextInfo.setProcessAction("");
		return contextInfo;
	}

	private OrderWriteCustomerInfo getCustomerInfo(OrderWriteRequest orderWriteRequest, VZWPrepayOrderSubmitResponse submitOrderResponse) {
		OrderWriteCustomerInfo orderWriteCustomerInfo = new OrderWriteCustomerInfo();
		orderWriteCustomerInfo.setCartCreator(
				orderWriteRequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCartCreator());
		orderWriteCustomerInfo.setRegisterNumber(orderWriteRequest.getServiceBody().getServiceRequest().getContext()
				.getCustomerInfo().getRegisterNumber());
		orderWriteCustomerInfo.setGlobalId(
				orderWriteRequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCartCreator());
		orderWriteCustomerInfo.setIsOrderAlreadySubmitted(String.valueOf(submitOrderResponse.getPayload().getPageData().isOrderSubmitted()));
		orderWriteCustomerInfo.setMtnFlow("D");
		String customerType = "NSE".equalsIgnoreCase(submitOrderResponse.getPayload().getPageData().getOrderVo().getFlow())?"N":"";
		orderWriteCustomerInfo.setCustomerType(customerType);
		orderWriteCustomerInfo.setProcessingMTN("");
		orderWriteCustomerInfo.setPaperlessIndicator(false);
		orderWriteCustomerInfo.setServiceWriteRequired(false);
		orderWriteCustomerInfo.setAccountNumber("");
		orderWriteCustomerInfo.setIsReadOrder(false);
		orderWriteCustomerInfo.setOrderNum(submitOrderResponse.getPayload().getPageData().getOrderVo().getOrderNumber());
		orderWriteCustomerInfo.setEmail(submitOrderResponse.getPayload().getPageData().getOrderVo().getAccountInfo().getAddress().getEmailAddress());
		orderWriteCustomerInfo.setGlobalId(submitOrderResponse.getPayload().getPageData().getOrderVo().getSessionId());
		return orderWriteCustomerInfo;
	}

	private OrderWrite getOrderDetails(VZWPrepayOrderSubmitResponse submitOrderResponse) {
		OrderWrite orderWrite = new OrderWrite();
		orderWrite.setCustomerAgreement(FALSE);
		orderWrite.setOrderNum(submitOrderResponse.getPayload().getPageData().getOrderVo().getOrderNumber());
		orderWrite.setBillingSys("");
		orderWrite.setCreditApp("");
		orderWrite.setLocationCode("");
		orderWrite.setStatus(String.valueOf(submitOrderResponse.getPayload().getPageData().isSuccess()));
		orderWrite.setMgrApprovalReq(FALSE);
		orderWrite.setMobileNumber(submitOrderResponse.getPayload().getPageData().getOrderVo().getAccountInfo().getAddress().getAltPhoneNumber());
		orderWrite.setOrderTotal(String.valueOf(submitOrderResponse.getPayload().getPageData().getOrderVo().getOrderTotal()));
		orderWrite.setSalesRep("");
		List <OrderDetails> orderDetailsList = new ArrayList<>();
		OrderDetails orderDetails = new OrderDetails();
		orderDetails.setOrderNum(submitOrderResponse.getPayload().getPageData().getOrderVo().getOrderNumber());
		logger.info("Order ID inside OrderVO: {} whereas Order ID outside Order VO: {}",submitOrderResponse.getPayload().getPageData().getOrderVo().getOrderId(),submitOrderResponse.getPayload().getPageData().getOrderId());
		orderDetails.setDigitalOrderId(submitOrderResponse.getPayload().getPageData().getOrderVo().getOrderId());
		orderDetails.setOrderTotal(String.valueOf(submitOrderResponse.getPayload().getPageData().getOrderVo().getOrderTotal()));
		orderDetails.setFullAuthSuccess(submitOrderResponse.getPayload().getPageData().isSuccess());
		String oType = StringUtilities.isNotEmptyOrNull(submitOrderResponse.getPayload().getPageData().getVzwDL().getPurchase().getOrderType())?submitOrderResponse.getPayload().getPageData().getVzwDL().getPurchase().getOrderType():"NSE";
		String orderType="";

		if("NSP".equalsIgnoreCase(oType)) {
			orderType = "NSEBYOD";
		} else if("PUP".equalsIgnoreCase(oType)) {
			orderType = "EUP";
		} else if("PAL".equalsIgnoreCase(oType)) {
			orderType = "AAL";
		} else {
			orderType = "NSE";
		}
		//orderDetails.setOrderType(submitOrderResponse.getPayload().getPageData().getVzwDL().getPurchase().getOrderType());
		orderDetails.setOrderType(orderType);
		orderDetailsList.add(orderDetails);
		orderWrite.setOrderDetails(orderDetailsList);
		return orderWrite;
	}

	public Mono<ResponseEntity<ValidateCardPaymentCXPResponse>> getUpdatePayment(ServerHttpRequest httpRequest,
			ValidateCardCXPRequest request) {
		return prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)
				.doOnError(err -> logger.error("Failed and return error", err))
				.defaultIfEmpty("")
				.flatMap(redisData -> {
					if (null == redisData || redisData.isEmpty()) {
						logger.error("Error in fetching redis data");
						return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
								.body(new ValidateCardPaymentCXPResponse()));
					} else {
						Map<String, String> requestData = prepayCheckoutRedisHelper.handleRedisData(redisData);
						Map<String, String> headers = new HashMap<>();
						String cookies = PREPAY_OD_REQUEST_ECOMM_SESSION+"=" + requestData.get(PREPAY_OD_ECOMM_SESSION) + HEADER_P_CSRFTKN
								+ requestData.get(PREPAY_OD_REQUEST_P_CSRF_TKN);
						headers.put(PrepayAdaptorCheckoutConstants.PREPAY_OD_COOKIE, cookies);
						headers.put(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_P_CSRF_TOKEN, requestData.get(PREPAY_OD_REQUEST_P_CSRF_TKN));
						headers.put(CONTENT_TYPE, String.valueOf(ContentType.APPLICATION_JSON));
						headers.put(CHANNEL_ID, VZW_DOTCOM);
						PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = new PrepaidAdaptorWebClientRequest();
						prepaidAdaptorWebClientRequest.setUrl(prepaidUpdatePayment);
						prepaidAdaptorWebClientRequest.setHeader(headers);
						try {
							prepaidAdaptorWebClientRequest.setRequestBody(getRequestJSONMapping(request));
						}  catch (JsonProcessingException e1) {
							logger.error(e1.getMessage());
						}
						prepaidAdaptorWebClientRequest.setRequestType(HttpMethod.POST.toString());					
						 logger.info("getUpdatePayment ::Play call payload: {}" , prepaidAdaptorWebClientRequest.getRequestBody());
						return prepayAdaptorWebClient
								.getPrepayServiceResponse(httpRequest, prepaidAdaptorWebClientRequest)
								.doOnError(error -> 
								logger.error("Failed to get response, check exception for details.",
										error))
								.flatMap(responseEntity -> {
									logger.info("getUpdatePayment ::Play call response: {}" , responseEntity);
									ValidateCardPaymentCXPResponse validateCardPaymentCXPResponse = new ValidateCardPaymentCXPResponse();
									ErrorResponseMapper errorResponseMapper = new ErrorResponseMapper();
									SubmitConfirmationResponse submitConfirmationResponse = new SubmitConfirmationResponse();
									if (!responseEntity.getStatusCode().is2xxSuccessful()) {
										logger.error("Error while calling endpoint: {} with status code: {}",
												prepaidAdaptorWebClientRequest.getUrl(),
												responseEntity.getStatusCode());
										return Mono.just(ResponseEntity.status(responseEntity.getStatusCode())
												.body(validateCardPaymentCXPResponse));
									} else {
										try {
											submitConfirmationResponse = mapper.readValue(responseEntity.getBody(),
													SubmitConfirmationResponse.class);											
											if (submitConfirmationResponse.getStatusCode().equals("00")) {
												if(submitConfirmationResponse.getPayload().getPageData().isSecureCard())
												{
													ValidateCardResponse data = new ValidateCardResponse();
													data.setCardinalInfo(submitConfirmationResponse.getPayload().getPageData().getCardinalInfo());													
													data.set3DSecureCard(submitConfirmationResponse.getPayload().getPageData().isSecureCard());													
													data.setPreAuthSuccess("true");
													data.setAcsUrl("/od/nse/handleCardinal3DResponse");
													validateCardPaymentCXPResponse.setData(data);													
												}else {
												submitConfirmationResponse = mapper.readValue(responseEntity.getBody(),
														SubmitConfirmationResponse.class);
												ValidateCardResponse data = new ValidateCardResponse();
												data.setBillingInfo(submitConfirmationResponse.getPayload().getPageData().getBillingInfo());
												data.setPreAuthSuccess("true");
												validateCardPaymentCXPResponse.setData(data);
												}
											} else if (submitConfirmationResponse.getStatusCode().equals("01")) {
												errorResponseMapper = mapper.readValue(responseEntity.getBody(),
														ErrorResponseMapper.class);

												ValidateCardResponse data = new ValidateCardResponse();
												data.setPreAuthSuccess(FALSE);
												validateCardPaymentCXPResponse.setData(data);
											}
										} catch (JsonProcessingException e) {
											logger.error("Error while mapping to service response", e);
										}
									}
									return Mono.just(ResponseEntity.status(responseEntity.getStatusCode())
											.body(validateCardPaymentCXPResponse));
								});
					}
				});
	}

	private Object getRequestJSONMapping(ValidateCardCXPRequest request)
			throws JsonProcessingException {
		Map<String, Object> creditCardInfo = new HashMap<>();
		Map<String, Object> binData = new HashMap<>();
		Map<String, Object> mergedRequestParam = new HashMap<>();
		String[] creditCardNumber=request.getData().getPayment().getPaymentDetails().get(0).getCreditCardPayment().getEncryptedCardData().split(" ");
		String[] verficationNumber=request.getData().getPayment().getPaymentDetails().get(0).getCreditCardPayment().getEncryptedCardData2().split(" ");
		creditCardInfo.put("creditCardNumber",
				creditCardNumber[0]);
		creditCardInfo.put("creditCardVerificationNumber", verficationNumber[0]);
		creditCardInfo.put("creditCardType",
				request.getData().getPayment().getPaymentDetails().get(0).getCreditCardPayment().getCreditCardType());
		creditCardInfo.put("billingZipCode",
				request.getData().getPayment().getPaymentDetails().get(0).getCreditCardPayment().getCardAddressZip());
		creditCardInfo.put("creditCardExpMonth",
				request.getData().getPayment().getPaymentDetails().get(0).getCreditCardPayment().getCardExpMonth());
		creditCardInfo.put("creditCardExpYear",
				request.getData().getPayment().getPaymentDetails().get(0).getCreditCardPayment().getCardExpYear());
		creditCardInfo.put("lastFourDigits", getFourDigits(request.getData().getPayment().getPaymentDetails().get(0)
				.getCreditCardPayment().getEncryptedCardData()));
		creditCardInfo.put("isCCPIEEncryptionSuccess", true);
		creditCardInfo.put("isAutoPay", false);
		creditCardInfo.put("jwt", "");
		creditCardInfo.put("cardinalSetUpComplete", "true");
		binData.put("binProcessEventTime", request.getData().getPayment().getPaymentDetails().get(0)
				.getCreditCardPayment().getSecureInfo().getBinProcessEventTime());
		binData.put("binProcessEventSuccess", request.getData().getPayment().getPaymentDetails().get(0)
				.getCreditCardPayment().getSecureInfo().isBinProcessEventSuccess());
		binData.put("binProcessEventTimedOut", request.getData().getPayment().getPaymentDetails().get(0)
				.getCreditCardPayment().getSecureInfo().isBinProcessEventTimedOut());
		mergedRequestParam.put("creditCardInfo", creditCardInfo);
		mergedRequestParam.put("binData", binData);
		mergedRequestParam.put("BrowserJavaScriptEnabled", true);
		return toJsonNode(mapper.writeValueAsString(mergedRequestParam));
	}

	private String getFourDigits(String encryptedCardData) {
		String[] words = encryptedCardData.split(" ");
		int length = words[0].length();
		if (length > 4) {
			return words[0].substring(length - 4, length);
		}
		return null;
	}

	private Object toJsonNode(String data) throws JsonProcessingException {
		JsonNode jsonNode = mapper.readTree(data);
		return mapper.readValue(jsonNode.toString(), JsonNode.class);
	}

	public Mono<ResponseEntity<CMPILookupCXPResponse>> getPayPalLookUp(ServerHttpRequest httpRequest,
			@Valid CMPILookupCXPRequest pReq) {

		return prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)
				.doOnError(err -> logger.error("Failed and return error from redis", err)).defaultIfEmpty("")
				.flatMap(redisValue -> {
					if (null == redisValue || redisValue.isEmpty()) {
						logger.error("Error in fetching redis data");
						return Mono.just(null);
					} else {
						Map<String, String> requestData = prepayCheckoutRedisHelper.handleRedisData(redisValue);
						Map<String, String> headersData = new HashMap<>();
						String cookies = PREPAY_OD_REQUEST_ECOMM_SESSION+"=" + requestData.get(PREPAY_OD_ECOMM_SESSION) + HEADER_P_CSRFTKN
								+ requestData.get(PREPAY_OD_REQUEST_P_CSRF_TKN);
						headersData.put(PrepayAdaptorCheckoutConstants.PREPAY_OD_COOKIE, cookies);
						headersData.put(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_P_CSRF_TOKEN, requestData.get(PREPAY_OD_REQUEST_P_CSRF_TKN));
						headersData.put(CONTENT_TYPE, String.valueOf(ContentType.APPLICATION_JSON));
						headersData.put(CHANNEL_ID, VZW_DOTCOM);
						PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = new PrepaidAdaptorWebClientRequest();
						prepaidAdaptorWebClientRequest.setUrl(paypalCmpiLookup);
						prepaidAdaptorWebClientRequest.setHeader(headersData);
						prepaidAdaptorWebClientRequest.setRequestBody(getRequestBodyForLookup(pReq));
						prepaidAdaptorWebClientRequest.setRequestType(HttpMethod.GET.toString());
						 
						return prepayAdaptorWebClient
								.getPrepayServiceResponse(httpRequest, prepaidAdaptorWebClientRequest)
								.doOnError(error -> logger.error("Failed to get response, check exception for details.",
										error))
								.flatMap(responseEntity -> {
									CMPILookupCXPResponse cmpiLookupCXPResponse = new CMPILookupCXPResponse();
									try {
										CmpiLookupReponse	cmpiLookupReponse = mapper.readValue(responseEntity.getBody(),CmpiLookupReponse.class);
										CMPILookupCXPResponseData  data = new CMPILookupCXPResponseData();
										data.setSandboxUrl(cmpiLookupReponse.getResult());
										cmpiLookupCXPResponse.setData(data);
									}  catch (JsonProcessingException e) {
										// TODO Auto-generated catch block
										logger.error("Error while mapping to service response", e);
									}
									
									return Mono.just(ResponseEntity.status(responseEntity.getStatusCode()).body(cmpiLookupCXPResponse));
								});
					}
				});
	}

	private Object getRequestBodyForLookup(@Valid CMPILookupCXPRequest pReq) {
		
		String jsonString = new JSONObject()
                .put("shippingOptionId", pReq.getShippingOptionId())
                .put("termUrl", pReq.getTermUrl())                
                .toString();
		
		return new JSONObject(jsonString);
	}


	
	public Mono<ResponseEntity<PreauthDigitalPayCXPResponse>> getPaypalAuth(ServerHttpRequest httpRequest,
			@Valid  PreauthDigitalPayCXPRequest request) {
		logger.info("getPaypalAuth ::Play call paypal auth:");
		return prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)
				.doOnError(err -> logger.error("Failed and return error", err)).defaultIfEmpty("")
				.flatMap(redisData -> {
					if (null == redisData || redisData.isEmpty()) {
						logger.error("Error in fetching redis data");
						return Mono.just(null);
					} else {
						Map<String, String> requestData = prepayCheckoutRedisHelper.handleRedisData(redisData);
						Map<String, String> headers = new HashMap<>();
						String cookies = PREPAY_OD_REQUEST_ECOMM_SESSION+"=" + requestData.get(PREPAY_OD_ECOMM_SESSION) + HEADER_P_CSRFTKN
								+ requestData.get(PREPAY_OD_REQUEST_P_CSRF_TKN);
						headers.put(PrepayAdaptorCheckoutConstants.PREPAY_OD_COOKIE, cookies);
						headers.put(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_P_CSRF_TOKEN, requestData.get(PREPAY_OD_REQUEST_P_CSRF_TKN));
						headers.put(CONTENT_TYPE, String.valueOf(ContentType.APPLICATION_JSON));
						headers.put(CHANNEL_ID, VZW_DOTCOM);
						
						PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = new PrepaidAdaptorWebClientRequest();
						prepaidAdaptorWebClientRequest.setUrl(paypalAuth);
						prepaidAdaptorWebClientRequest.setHeader(headers);						
						try {
							prepaidAdaptorWebClientRequest.setRequestBody(getAuthPayload(request,requestData));
						}  catch (JsonProcessingException e1) {
							logger.error("Error while mapping to service request", e1);
						} 
						prepaidAdaptorWebClientRequest.setRequestType(HttpMethod.POST.toString());
						 
						return prepayAdaptorWebClient
								.getPrepayServiceResponse(httpRequest, prepaidAdaptorWebClientRequest)
								.doOnError(error -> logger.error("Failed to get response, check exception for details.",
										error))
								.flatMap(responseEntity -> {
									PreauthDigitalPayCXPResponse preauthDigitalPayCXPResponse = new PreauthDigitalPayCXPResponse();
									try {

										preauthDigitalPayCXPResponse = mapper.readValue(responseEntity.getBody(),PreauthDigitalPayCXPResponse.class);

									}  catch (JsonProcessingException e) {
										// TODO Auto-generated catch block
										logger.error("Error while mapping to service response", e);
									}
									return Mono.just(ResponseEntity.status(responseEntity.getStatusCode()).body(preauthDigitalPayCXPResponse));
								});
					}
				});
	}

	private Object getAuthPayload(@Valid PreauthDigitalPayCXPRequest request, Map<String, String> requestData) throws JsonProcessingException {
		Map<String, Object> meta = new HashMap<>();
		Map<String, Object> data = new HashMap<>();
		Map<String, Object> mergedRequestParam = new HashMap<>();
		try
		{
		meta.put("clientCorrrelationId", request.getMeta().getClientCorrrelationId());
		meta.put("timestamp", request.getMeta().getTimestamp());
		data.put("cartId", request.getData().getCartId());
		data.put("triggerFrom", request.getData().getTriggerFrom());
		data.put("paymentType", request.getData().getPaymentType());
		data.put("PaRes", requestData.get("PaRes"));
		data.put("MD", requestData.get("MD"));
		}catch(Exception ex)
		{
			logger.error("Error while mapping to service request", ex);
		}
		mergedRequestParam.put("meta", meta);
		mergedRequestParam.put("data", data);
		return toJsonNode(mapper.writeValueAsString(mergedRequestParam));
	}
	public Mono<ResponseEntity<ConfirmSubmit3DCXPResponse>> confirmSubmit3D(ServerHttpRequest httpRequest,
																			@Valid ConfirmSubmit3DCXPRequest request) {
		return prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)
				.doOnError(err -> logger.error("Failed and return error", err)).defaultIfEmpty("")
				.flatMap(redisData -> {
					if (null == redisData || redisData.isEmpty()) {
						logger.error("Error in fetching redis data");
						return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
								.body(new ConfirmSubmit3DCXPResponse()));
					} else {
						Map<String, String> requestData = prepayCheckoutRedisHelper.handleRedisData(redisData);
						Map<String, String> headers = new HashMap<>();
						String cookies = PREPAY_OD_REQUEST_ECOMM_SESSION+"=" + requestData.get(PREPAY_OD_ECOMM_SESSION) + HEADER_P_CSRFTKN
								+ requestData.get(PREPAY_OD_REQUEST_P_CSRF_TKN);
						headers.put(PrepayAdaptorCheckoutConstants.PREPAY_OD_COOKIE, cookies);
						headers.put(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_P_CSRF_TOKEN, requestData.get(PREPAY_OD_REQUEST_P_CSRF_TKN));
						headers.put(CONTENT_TYPE, String.valueOf(ContentType.APPLICATION_JSON));
						PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = new PrepaidAdaptorWebClientRequest();
						prepaidAdaptorWebClientRequest.setUrl(prepaidUpdatePayment);
						prepaidAdaptorWebClientRequest.setHeader(headers);
						try {							
							prepaidAdaptorWebClientRequest.setRequestBody(getRequest3DJSONMapping(request));
						}  catch (JsonProcessingException e1) {
							logger.error(e1.getMessage());
						}

						logger.error(prepaidAdaptorWebClientRequest.getRequestBody().toString());

						prepaidAdaptorWebClientRequest.setRequestType(HttpMethod.POST.toString());					
						 logger.info("getUpdatePayment ::Play call payload: {}" , prepaidAdaptorWebClientRequest.getRequestBody());
						return prepayAdaptorWebClient
								.getPrepayServiceResponse(httpRequest, prepaidAdaptorWebClientRequest)
								.doOnError(error -> 
								logger.error("Failed to get response, check exception for details.",error))
								.flatMap(responseEntity -> {
									ConfirmSubmit3DCXPResponse confirmSubmit3DCXPResponse = new ConfirmSubmit3DCXPResponse();
									ErrorResponseMapper errorResponseMapper = new ErrorResponseMapper();
									SubmitConfirmationResponse submitConfirmationResponse = new SubmitConfirmationResponse();
									logger.error(responseEntity.getBody());
									if (!responseEntity.getStatusCode().is2xxSuccessful()) {
										logger.error("Error while calling endpoint: {} with status code: {}",
												prepaidAdaptorWebClientRequest.getUrl(),
												responseEntity.getStatusCode());
										return Mono.just(ResponseEntity.status(responseEntity.getStatusCode())
												.body(confirmSubmit3DCXPResponse));
									} else {
										try {
											submitConfirmationResponse = mapper.readValue(responseEntity.getBody(),
													SubmitConfirmationResponse.class);											
											if (submitConfirmationResponse.getStatusCode().equals("00")) {
												if(submitConfirmationResponse.getPayload().getPageData().isSecureCard())
												{
													ConfirmSubmit3DCXPResponseData data = new ConfirmSubmit3DCXPResponseData();
													data.setAcsUrl(submitConfirmationResponse.getPayload().getPageData().getCardinalInfo().getAcsUrl());
													data.setPayload(submitConfirmationResponse.getPayload().getPageData().getCardinalInfo().getPayload());
													data.setJwtProcessorTransactionId(submitConfirmationResponse.getPayload().getPageData().getCardinalInfo().getJwtToken());
													data.setStatus(submitConfirmationResponse.getStatus());
													data.setCmpiTransId(submitConfirmationResponse.getPayload().getPageData().getCardinalInfo().getTransactionId());											
													data.setEnrolled("Y");
													data.setAction("LOOKUP");
													
													confirmSubmit3DCXPResponse.setData(data);													
												}else {
												submitConfirmationResponse = mapper.readValue(responseEntity.getBody(), SubmitConfirmationResponse.class);
												ConfirmSubmit3DCXPResponseData data = new ConfirmSubmit3DCXPResponseData();													
												data.setPreAuthSuccess("true");
												confirmSubmit3DCXPResponse.setData(data);
												}
												
											} else if (submitConfirmationResponse.getStatusCode().equals("01")) {
												try
												{

													errorResponseMapper = mapper.readValue(responseEntity.getBody(),
														ErrorResponseMapper.class);
												}catch(Exception ex)
												{
													logger.error("Error while mapping to service response", ex);
												}
												ConfirmSubmit3DCXPResponseData data = new ConfirmSubmit3DCXPResponseData();	
												data.setPreAuthSuccess(FALSE);
												confirmSubmit3DCXPResponse.setData(data);
												ErrorResponse errResponse = new ErrorResponse();
												if(Objects.nonNull(errorResponseMapper.getErrors())) {
													if (Objects.nonNull(errorResponseMapper.getErrors().getEcommApiErrorList())) {
														for (EcommApiErrorList errList : errorResponseMapper.getErrors().getEcommApiErrorList()) {
															errResponse.setMessage(errList.getMessage());
														}
													} else if (Objects.nonNull(errorResponseMapper.getErrors().getError())) {
														onevz.soe.od.model.Error[] errList = errorResponseMapper.getErrors().getError();
														errResponse.setMessage(Arrays.stream(errList).findFirst().get().getErrorMsg());
													}
												}

													else if (Objects.nonNull(errorResponseMapper.getErrorMap())) {
														errResponse.setMessage(errorResponseMapper.getErrorMap().getMessage());
													}
												List<ErrorResponse> errors = new ArrayList<>();
												errResponse.setName("confirmSubmit3d");
												errResponse.setNamespace(PrepayAdaptorCheckoutConstants.PREPAY_OD);
												errors.add(errResponse);
												confirmSubmit3DCXPResponse.setErrors(errors);
																
											}

										} catch (JsonProcessingException e) {
											logger.error("Error while mapping to service response", e);
										}
									
									return Mono.just(ResponseEntity.status(responseEntity.getStatusCode()).body(confirmSubmit3DCXPResponse));
									}
								});
					}
				});
	}
				


	private Object getRequest3DJSONMapping(@Valid ConfirmSubmit3DCXPRequest request) throws JsonProcessingException {		
		Map<String, Object> creditCardInfo = new HashMap<>();		
		Map<String, Object> mergedRequestParam = new HashMap<>();	
		String[] creditCardNumber=request.getData().getPayments().get(0).getCreditCardPayment().getEncryptedCardData().split(" ");
		String[] verficationNumber=request.getData().getPayments().get(0).getCreditCardPayment().getEncryptedCardData2().split(" ");
		creditCardInfo.put("creditCardNumber",
				creditCardNumber[0]);
		creditCardInfo.put("creditCardVerificationNumber", verficationNumber[0]);
		creditCardInfo.put("creditCardType",
				request.getData().getPayments().get(0).getCreditCardPayment().getCreditCardType());
		creditCardInfo.put("billingZipCode",
				request.getData().getPayments().get(0).getCreditCardPayment().getCardAddressZip());
		creditCardInfo.put("creditCardExpMonth",
				request.getData().getPayments().get(0).getCreditCardPayment().getCardExpMonth());
		creditCardInfo.put("creditCardExpYear",
				request.getData().getPayments().get(0).getCreditCardPayment().getCardExpYear());
		creditCardInfo.put("lastFourDigits", getFourDigits(request.getData().getPayments().get(0).getCreditCardPayment().getEncryptedCardData()));
		creditCardInfo.put("isCCPIEEncryptionSuccess", true);
		creditCardInfo.put("isAutoPay", request.getData().isAutoPay());
		creditCardInfo.put("jwt", request.getData().getPayments().get(0).getCreditCardPayment().getSecureInfo().getSecureJwtToken());		
		mergedRequestParam.put("creditCardInfo", creditCardInfo);
		mergedRequestParam.put("BrowserJavaScriptEnabled", true);
		populateBrowserdetails(request, mergedRequestParam);
		return toJsonNode(mapper.writeValueAsString(mergedRequestParam));

	
	}

	private void populateBrowserdetails(ConfirmSubmit3DCXPRequest request, Map<String, Object> mergedRequestParam) {
		if(null!= request.getData()){
			ConfirmSubmit3DSecureCXPRequestData data = request.getData();
			mergedRequestParam.put("browserColorDepth",data.getBrowserColorDepth());
			mergedRequestParam.put("browserJavaEnabled",data.isBrowserJavaEnabled());
			mergedRequestParam.put("browserLanguage", data.getBrowserLanguage());
			mergedRequestParam.put("browserScreenHeight", data.getBrowserScreenHeight());
			mergedRequestParam.put("browserScreenWidth", data.getBrowserScreenWidth());
			mergedRequestParam.put("browserTimeZone",data.getBrowserTimeZone());
		}
	}

	private void kibanaCustomOrderWriteLogs(VZWPrepayOrderSubmitResponse submitOrderResponse) {
		logger.info("Started executing orderinfo logs");
		Map<String, String> orderinfo=new HashMap<>();
		Map<String, String> fields = new HashMap<>();
		try {
			if(StringUtilities.isNotEmptyOrNull(submitOrderResponse.getPayload().getPageData().getOrderVo().getOrderId())){
				logger.info("orderId : {}", submitOrderResponse.getPayload().getPageData().getOrderVo().getOrderId());
				orderinfo.put("orderId", submitOrderResponse.getPayload().getPageData().getOrderVo().getOrderId());
			}
			if(StringUtilities.isNotEmptyOrNull(submitOrderResponse.getPayload().getPageData().getOrderVo().getOrderNumber())) {
				logger.info("orderNumber : {}", submitOrderResponse.getPayload().getPageData().getOrderVo().getOrderId());
				orderinfo.put("orderNumber", submitOrderResponse.getPayload().getPageData().getOrderVo().getOrderNumber());
			}
			String flowName = StringUtilities.isNotEmptyOrNull(submitOrderResponse.getPayload().getPageData().getOrderVo().getFlow())?submitOrderResponse.getPayload().getPageData().getOrderVo().getFlow():"NSE";

			String flow=getFlowData(flowName);

			if(StringUtilities.isNotEmptyOrNull(flow)) {
				logger.info("order intendType : {}", flow);
				logger.info("order NSE_Prepay_intendType : {}", PrepayAdaptorCheckoutConstants.NSE_PREPAY_INTEND_TYPE);
				orderinfo.put("intendType", flow);
			}
			orderinfo.put("OrderTotal", String.valueOf(submitOrderResponse.getPayload().getPageData().getOrderVo().getOrderTotal()));
			orderinfo.put("OrderTax", String.valueOf(submitOrderResponse.getPayload().getPageData().getOrderVo().getOrderTax()));
			orderDeviceListLogs(submitOrderResponse,orderinfo);
			orderAccessoryLogs(submitOrderResponse,orderinfo);
			orderPlansLogs(submitOrderResponse,orderinfo);
			orderBillingAndShippingAddressLogs(submitOrderResponse,orderinfo);
			if(StringUtilities.isNotEmptyOrNull(submitOrderResponse.getPayload().getPageData().getOrderVo().getPaymentMethod())) {
				logger.info("paymentType {}", submitOrderResponse.getPayload().getPageData().getOrderVo().getPaymentMethod());

				orderinfo.put("paymentType", submitOrderResponse.getPayload().getPageData().getOrderVo().getPaymentMethod());
			}
			if(StringUtilities.isNotEmptyOrNull(submitOrderResponse.getPayload().getPageData().getOrderVo().getPaypalInfo())) {
				logger.info("PaypalInfo {}", submitOrderResponse.getPayload().getPageData().getOrderVo().getPaypalInfo());

				orderinfo.put("paypalInfo", submitOrderResponse.getPayload().getPageData().getOrderVo().getPaypalInfo());
			}
			if(StringUtilities.isNotEmptyOrNull(submitOrderResponse.getPayload().getPageData().getOrderVo().getOrderZipcode())) {
			orderinfo.put("locationCode", submitOrderResponse.getPayload().getPageData().getOrderVo().getOrderZipcode());
			}
			if(StringUtilities.isNotEmptyOrNull(submitOrderResponse.getPayload().getPageData().getOrderVo().getShippingMethod())) {
				orderinfo.put("ShippingInfo", submitOrderResponse.getPayload().getPageData().getOrderVo().getShippingMethod());
			}
			if(StringUtilities.isNotEmptyOrNull(submitOrderResponse.getPayload().getPageData().getOrderVo().getShippingOptionId())) {
				orderinfo.put("shippingOptionId", submitOrderResponse.getPayload().getPageData().getOrderVo().getShippingOptionId());
			}
			if(enableOrderLog) {
			fields.put("orderinfo", mapper.writeValueAsString(orderinfo));
			logger.info("orderinfo : {}", mapper.writeValueAsString(orderinfo));
			LoggerUtil.addCustomPersistField(fields);
			}
			logger.info("Completed executing orderinfo logs");
		}catch(Exception e) {
			logger.error("Exception while logging OrderConfirmation details for Audit", e);
		}
		
	}

	private String getFlowData(String flowName){
		String flow="";
		if(flowName.equalsIgnoreCase("NSP")) {
			flow = "NSEBYOD";
		} else if(flowName.equalsIgnoreCase("PASO")) {
			flow = "BYOD";
		} else if(flowName.equalsIgnoreCase("PUP")) {
			flow = "EUP";
		} else if(flowName.equalsIgnoreCase("PAL")) {
			flow = "AAL";
		} else {
			flow = "NSE";
		}
		return flow;
	}
	
	

	private void orderDeviceListLogs(VZWPrepayOrderSubmitResponse submitOrderResponse, Map<String, String> orderinfo) {
		List<String> deviceLists=new ArrayList<>();
		List<String> listDeviceBrandNames=new ArrayList<>();
		List<String> listDeviceProductIds=new ArrayList<>();
		List<String> listDeviceCategory=new ArrayList<>();
		List<String> listDeviceSkuIds=new ArrayList<>();
		try {
		if(!submitOrderResponse.getPayload().getPageData().getOrderVo().getDeviceList().isEmpty()) { 
			submitOrderResponse.getPayload().getPageData().getOrderVo().getDeviceList().stream().forEach(deviceList->{
				 if(StringUtilities.isNotEmptyOrNull(deviceList.getSkuDisplayName())) {
				 deviceLists.add(deviceList.getSkuDisplayName());
				 }
				 if(StringUtilities.isNotEmptyOrNull(deviceList.getProductId()))
				 {
					 listDeviceProductIds.add(deviceList.getProductId()); 
				 }
				 if(StringUtilities.isNotEmptyOrNull(deviceList.getBrandName()))
				 {
					 listDeviceBrandNames.add(deviceList.getBrandName()); 
				 }
				 if(StringUtilities.isNotEmptyOrNull(deviceList.getItemType()))
				 {
					 listDeviceCategory.add(deviceList.getItemType()); 
				 }
				 if(StringUtilities.isNotEmptyOrNull(deviceList.getSkuId()))
				 {
					 listDeviceSkuIds.add(deviceList.getSkuId()); 
				 }
			 });
			 if(!deviceLists.isEmpty()) {
				 String deviceNames=String.join("-", deviceLists);
				 logger.info("deviceName : {}", deviceNames);
				 orderinfo.put("deviceName",deviceNames);
			 }
			 if(!listDeviceProductIds.isEmpty()) {
				 String deviceProductIds=String.join("-", listDeviceProductIds);
				 logger.info("deviceProductIds : {}", deviceProductIds);
				 orderinfo.put("deviceProductIds",deviceProductIds);
			 }
			 if(!listDeviceBrandNames.isEmpty()) {
				 String deviceBrandNames=String.join("-", listDeviceBrandNames);
				 logger.info("DeviceBrand : {}", deviceBrandNames);
				 orderinfo.put("DeviceBrand",deviceBrandNames);
			 }
			 if(!listDeviceCategory.isEmpty()) {
				 String deviceCategory=String.join("-", listDeviceCategory);
				 logger.info("deviceCategory : {}", deviceCategory);
				 orderinfo.put("deviceCategory",deviceCategory);
			 }
			 if(!listDeviceSkuIds.isEmpty()) {
				 String deviceSkuid=String.join("-", listDeviceSkuIds);
				 logger.info("deviceSkuid : {}", deviceSkuid);
				 orderinfo.put("deviceSkus",deviceSkuid);
			 }
			 
			}
		}catch(Exception e) {
			logger.info("Exception wirting in orderDeviceListLogs");
		}
	}
	
	private void orderAccessoryLogs(VZWPrepayOrderSubmitResponse submitOrderResponse, Map<String, String> orderinfo) {
		try { 
			List<String> listAccessories=new ArrayList<>();
			List<String> listAccessoryProductId=new ArrayList<>();
		if(!submitOrderResponse.getPayload().getPageData().getOrderVo().getAccessoryList().isEmpty()) {
			 submitOrderResponse.getPayload().getPageData().getOrderVo().getAccessoryList().stream().forEach(accessoryList ->{
				 if(StringUtilities.isNotEmptyOrNull(accessoryList.getSkuDisplayName())){
				 listAccessories.add(accessoryList.getSkuDisplayName());
				 }
				 if(StringUtilities.isNotEmptyOrNull(accessoryList.getProductId()))
				 {
					 listAccessoryProductId.add(accessoryList.getProductId());
				 }
			 });
			 if(!listAccessories.isEmpty()) {
				 String accessoryNames=String.join("-", listAccessories);
				 logger.info("orderDetails accessoryNames : {}", accessoryNames);
				 orderinfo.put("accessoriesName",accessoryNames);
			 }
			 if(!listAccessoryProductId.isEmpty()) {
				 String accessoryProductIds=String.join("-", listAccessoryProductId);
				 logger.info("orderDetails AccessoryProductIds : {}", accessoryProductIds);
				 orderinfo.put("AccessoryProductIds",accessoryProductIds);
			 }
			 
		 }
		}catch(Exception e) {
			logger.info("Exception wirting in orderAccessoryLogs");
		}
	}
	
	private void orderPlansLogs(VZWPrepayOrderSubmitResponse submitOrderResponse, Map<String, String> orderinfo) {
		List<String> listPlans=new ArrayList<>();
		List<String> listPlansProductId=new ArrayList<>();
		List<String> listPlanSkuIds=new ArrayList<>();
		try { 
		if(!submitOrderResponse.getPayload().getPageData().getOrderVo().getPlanList().isEmpty()) {
			 submitOrderResponse.getPayload().getPageData().getOrderVo().getPlanList().stream().forEach(planList->{
				if(StringUtilities.isNotEmptyOrNull(planList.getDescription())) {
				 listPlans.add(planList.getDescription());
				}
				 if(StringUtilities.isNotEmptyOrNull(planList.getProductId())){
					 listPlansProductId.add(planList.getProductId());
				}
				 if(StringUtilities.isNotEmptyOrNull(planList.getSorId())){
					 listPlanSkuIds.add(planList.getSorId());
				}
			 });
			 
			 if(!listPlans.isEmpty()) {
				 String planNames=String.join("-", listPlans);
				 logger.info("orderDetails planNames : {}", planNames);
				 orderinfo.put("PlanNames",planNames);
			 }
			 if(!listPlansProductId.isEmpty()) {
				 String planProductIds=String.join("-", listPlansProductId);
				 logger.info("orderDetails planProductIds : {}", planProductIds);
				 orderinfo.put("PlanProductIds",planProductIds);
			 }
			 if(!listPlanSkuIds.isEmpty()) {
				 String planSkuid=String.join("-", listPlanSkuIds);
				 logger.info("orderDetails planSkuid : {}", planSkuid);
				 orderinfo.put("planSkuid",planSkuid);
			 }
			 
		 }
		}catch(Exception e) {
			logger.info("Exception wirting in orderPlansLogs");
		}
	}
	
	private void orderBillingAndShippingAddressLogs(VZWPrepayOrderSubmitResponse submitOrderResponse,
			Map<String, String> orderinfo) {
		try {
			List<String> entireShippingAddressList = new ArrayList<>();
			String entireShippingAddress = null;
    		if(null!=submitOrderResponse.getPayload().getPageData().getOrderVo().getAccountInfo() &&
				null!=submitOrderResponse.getPayload().getPageData().getOrderVo().getAccountInfo().getAddress() &&
				null!= submitOrderResponse.getPayload().getPageData().getOrderVo().getBillingAddress() &&
				null!= submitOrderResponse.getPayload().getPageData().getOrderVo().getBillingAddress().getAddress()) {
			if(StringUtilities.isNotEmptyOrNull(submitOrderResponse.getPayload().getPageData().getOrderVo().getAccountInfo().getAddress().getEmailAddress())) {
				logger.info("emailAddress {}", submitOrderResponse.getPayload().getPageData().getOrderVo().getAccountInfo().getAddress().getEmailAddress());

				orderinfo.put("emailAddress", submitOrderResponse.getPayload().getPageData().getOrderVo().getAccountInfo().getAddress().getEmailAddress());
			}
			if(StringUtilities.isNotEmptyOrNull(submitOrderResponse.getPayload().getPageData().getOrderVo().getBillingAddress().getAddress().getState())) {
				logger.info("billingState {}", submitOrderResponse.getPayload().getPageData().getOrderVo().getBillingAddress().getAddress().getState());
				orderinfo.put("billingState", submitOrderResponse.getPayload().getPageData().getOrderVo().getBillingAddress().getAddress().getState());
			}
			if(StringUtilities.isNotEmptyOrNull(submitOrderResponse.getPayload().getPageData().getOrderVo().getBillingAddress().getAddress().getZip())) {
				logger.info("BillingAddressZipCode {}", submitOrderResponse.getPayload().getPageData().getOrderVo().getBillingAddress().getAddress().getZip());

				orderinfo.put("BillingAddressZipCode", submitOrderResponse.getPayload().getPageData().getOrderVo().getBillingAddress().getAddress().getZip());
			}
			if(StringUtilities.isNotEmptyOrNull(submitOrderResponse.getPayload().getPageData().getOrderVo().getAccountInfo().getAddress().getState())) {
				logger.info("ShippingAddressState {}", submitOrderResponse.getPayload().getPageData().getOrderVo().getAccountInfo().getAddress().getState());
				entireShippingAddressList.add(submitOrderResponse.getPayload().getPageData().getOrderVo().getAccountInfo().getAddress().getState());
			}
			if(StringUtilities.isNotEmptyOrNull(submitOrderResponse.getPayload().getPageData().getOrderVo().getAccountInfo().getAddress().getZip())) {
				logger.info("ShippingAddressZipCode {}", submitOrderResponse.getPayload().getPageData().getOrderVo().getAccountInfo().getAddress().getZip());
				entireShippingAddressList.add(submitOrderResponse.getPayload().getPageData().getOrderVo().getAccountInfo().getAddress().getZip());
			}
			if(StringUtilities.isNotEmptyOrNull(submitOrderResponse.getPayload().getPageData().getOrderVo().getAccountInfo().getAddress().getAddressLine1())) {
				logger.info("ShippingAddress1 {}", submitOrderResponse.getPayload().getPageData().getOrderVo().getAccountInfo().getAddress().getAddressLine1());
				entireShippingAddressList.add(submitOrderResponse.getPayload().getPageData().getOrderVo().getAccountInfo().getAddress().getAddressLine1());
			}
			if(StringUtilities.isNotEmptyOrNull(submitOrderResponse.getPayload().getPageData().getOrderVo().getAccountInfo().getAddress().getAddressLine2())) {
				logger.info("ShippingAddressZipCode {}", submitOrderResponse.getPayload().getPageData().getOrderVo().getAccountInfo().getAddress().getAddressLine2());
				entireShippingAddressList.add(submitOrderResponse.getPayload().getPageData().getOrderVo().getAccountInfo().getAddress().getAddressLine2());
			}
			if (entireShippingAddressList != null && !entireShippingAddressList.isEmpty()) {
				entireShippingAddress = String.join(" ", entireShippingAddressList);

			}
			if (null != entireShippingAddress) {
				logger.info("ShippingAddress {}", entireShippingAddress);

				orderinfo.put("shippingAddress", entireShippingAddress);
			}
			if(checkAddressMatches(submitOrderResponse.getPayload().getPageData().getOrderVo().getBillingAddress().getAddress(),submitOrderResponse.getPayload().getPageData().getOrderVo().getAccountInfo().getAddress()))
			{
				logger.info("BillingShippingAddressDifferentflag {}", "FALSE");

				orderinfo.put("billingShippingAddressDifferentflag", "FALSE");
			}else {
				logger.info("BillingShippingAddressDifferentflag {}", "TRUE");

				orderinfo.put("billingShippingAddressDifferentflag", "TRUE");
			}
			
		}	
		}catch(Exception e) {
			logger.info("Exception wirting in orderBillingAndShippingAddressLogs");
		}
	}
	
	private boolean checkAddressMatches(AddressVO billingAddress , AddressVO shippingAddress) {
		try {
        if(compare(billingAddress.getZip(),shippingAddress.getZip())
                && compare(billingAddress.getCity(),shippingAddress.getCity())
                && compare( billingAddress.getState(),shippingAddress.getState())
                && compare(billingAddress.getAddressLine1(),shippingAddress.getAddressLine1())){
            return true;
        }
		}catch(Exception e) {
			logger.info("Exception wirting in checkAddressMatches");
			return false;
		}
        return false;
    }
	private boolean compare(String str1,String str2){
		try {
		if(str1!=null && str2!=null && str1.trim().equalsIgnoreCase(str2.trim())){
			return true;
		}
		}catch(Exception e) {
			logger.info("Exception wirting in checkAddressMatches");
			return false;
		}
		return  false;
	}
public Mono<ResponseEntity<GetApplePaySessionCXPResponse>> getApplePaySessionDetails(ServerHttpRequest httpRequest,Object request) {
		
		return prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)
				.doOnError(err -> logger.error("Failed and return error", err))
				.defaultIfEmpty("")
				.flatMap(redisData -> {
					GetApplePaySessionCXPResponse getApplePaySessionCXPResponse=new GetApplePaySessionCXPResponse();
					if (null == redisData || redisData.isEmpty()) {
						logger.error("Error in fetching redis data");
						List<onevz.soe.prepay.payment.response.ErrorResponse> errors = new ArrayList<>();
						onevz.soe.prepay.payment.response.ErrorResponse errorResponse=new onevz.soe.prepay.payment.response.ErrorResponse();
						errorResponse.setId("9080");
						errorResponse.setMessage("Exception : redis is empty");
						errorResponse.setName(PrepayAdaptorCheckoutConstants.PREPAY_CHECKOUT_ADAPTOR);
						errorResponse.setNamespace(PrepayAdaptorCheckoutConstants.PREPAY_OD);
						errors.add(errorResponse);
						getApplePaySessionCXPResponse.setErrors(errors);
						return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
								.body(new GetApplePaySessionCXPResponse()));
					} else {
						Map<String, String> requestData = prepayCheckoutRedisHelper.handleRedisData(redisData);
						Map<String, String> headers = new HashMap<>();
						String cookies = PREPAY_OD_REQUEST_ECOMM_SESSION+"=" + requestData.get(PREPAY_OD_ECOMM_SESSION) + HEADER_P_CSRFTKN
								+ requestData.get(PREPAY_OD_REQUEST_P_CSRF_TKN);
						headers.put(PrepayAdaptorCheckoutConstants.PREPAY_OD_COOKIE, cookies);
						headers.put(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_P_CSRF_TOKEN, requestData.get(PREPAY_OD_REQUEST_P_CSRF_TKN));
						headers.put(CONTENT_TYPE, String.valueOf(ContentType.APPLICATION_JSON));
						PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = new PrepaidAdaptorWebClientRequest();
						prepaidAdaptorWebClientRequest.setUrl(getApplePaySession);
						prepaidAdaptorWebClientRequest.setHeader(headers);
						GetApplePaySessionRequest getApplePaySessionRequest=new GetApplePaySessionRequest();
						getApplePaySessionRequest.setEndPointURL(request.toString());
						prepaidAdaptorWebClientRequest.setRequestBody(getApplePaySessionRequest);
						prepaidAdaptorWebClientRequest.setRequestType(HttpMethod.POST.toString());
						return prepayAdaptorWebClient
								.getPrepayServiceResponse(httpRequest, prepaidAdaptorWebClientRequest)
								.doOnError(error -> logger.error("Failed to get Apple Pay Order OD response, please check exception for details",error))
								.flatMap(responseEntity -> {
									if (!responseEntity.getStatusCode().is2xxSuccessful()) {
										logger.info("Get apple pay error : {}" , responseEntity.getBody());
										List<onevz.soe.prepay.payment.response.ErrorResponse> errorList = new ArrayList<>();
										onevz.soe.prepay.payment.response.ErrorResponse errorResponseData=new onevz.soe.prepay.payment.response.ErrorResponse();
										errorResponseData.setId("8492");
										errorResponseData.setMessage("Exception in play response");
										errorResponseData.setName(PrepayAdaptorCheckoutConstants.PREPAY_CHECKOUT_ADAPTOR);
										errorResponseData.setNamespace(PrepayAdaptorCheckoutConstants.PREPAY_OD);
										errorList.add(errorResponseData);
										getApplePaySessionCXPResponse.setErrors(errorList);
										return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
												.body(getApplePaySessionCXPResponse));
									}else {
										logger.info("Get apple pay response : {}", responseEntity.getBody());
										try {
											GetApplePaySessionResponse getApplePaySessionResponse=mapper.readValue(responseEntity.getBody(),GetApplePaySessionResponse.class);
											setApplePaySessionResponse(getApplePaySessionResponse,getApplePaySessionCXPResponse);
										}  catch (JsonProcessingException e) {
											logger.info("Error in mapping GetApplePaySessionResponse");
										}
									}
									return Mono.just(ResponseEntity.status(HttpStatus.OK)
											.body(getApplePaySessionCXPResponse));
								});
					}
				});
	}

	private void setApplePaySessionResponse(GetApplePaySessionResponse getApplePaySessionResponse,GetApplePaySessionCXPResponse getApplePaySessionCXPResponse){
		if(null!=getApplePaySessionResponse) {
			GetSessionResponse getSessionResponse=new GetSessionResponse();
			getSessionResponse.setDisplayName(getApplePaySessionResponse.getPayload().getPageData().getSvcBdy().getGetSessionRes().getDisplayName());
			getSessionResponse.setDomainName(getApplePaySessionResponse.getPayload().getPageData().getSvcBdy().getGetSessionRes().getDomainName());
			getSessionResponse.setEpochTimestamp(getApplePaySessionResponse.getPayload().getPageData().getSvcBdy().getGetSessionRes().getEpochTimestamp());
			getSessionResponse.setMerchantIdentifier(getApplePaySessionResponse.getPayload().getPageData().getSvcBdy().getGetSessionRes().getMerchantIdentifier());
			getSessionResponse.setMerchantSessionIdentifier(getApplePaySessionResponse.getPayload().getPageData().getSvcBdy().getGetSessionRes().getMerchantSessionIdentifier());
			getSessionResponse.setNonce(getApplePaySessionResponse.getPayload().getPageData().getSvcBdy().getGetSessionRes().getNonce());
			getSessionResponse.setSignature(getApplePaySessionResponse.getPayload().getPageData().getSvcBdy().getGetSessionRes().getSignature());
			getApplePaySessionCXPResponse.setData(getSessionResponse);
			logger.info("Get apple pay success");
		}
	}


	public Mono<ResponseEntity<ProcessApplePaySessionCXPResponse>> processApplePayTokenDetails(
			ServerHttpRequest httpRequest,ProcessApplePaySessionCxpRequest request) {

		return prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)
				.doOnError(err -> logger.error("Failed and return error", err)).defaultIfEmpty("")
				.flatMap(redisData -> {
					ProcessApplePaySessionCXPResponse processApplePaySessionCXPResponse=new ProcessApplePaySessionCXPResponse();
					if (null == redisData || redisData.isEmpty()) {
						logger.error("Error in fetching redis data");
						List<onevz.soe.prepay.payment.response.ErrorResponse> errors = new ArrayList<>();
						onevz.soe.prepay.payment.response.ErrorResponse errorResponse=new onevz.soe.prepay.payment.response.ErrorResponse();
						errorResponse.setId("9080");
						errorResponse.setMessage("Exception : redis is empty");
						errorResponse.setName(PrepayAdaptorCheckoutConstants.PREPAY_CHECKOUT_ADAPTOR);
						errorResponse.setNamespace(PrepayAdaptorCheckoutConstants.PREPAY_OD);
						errors.add(errorResponse);
						processApplePaySessionCXPResponse.setErrors(errors);
						return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
								.body(new ProcessApplePaySessionCXPResponse()));
					} else {
						Map<String, String> requestData = prepayCheckoutRedisHelper.handleRedisData(redisData);
						Map<String, String> headers = new HashMap<>();
						String cookies = PREPAY_OD_REQUEST_ECOMM_SESSION+"=" + requestData.get(PREPAY_OD_ECOMM_SESSION) + HEADER_P_CSRFTKN
								+ requestData.get(PREPAY_OD_REQUEST_P_CSRF_TKN);
						headers.put(PrepayAdaptorCheckoutConstants.PREPAY_OD_COOKIE, cookies);
						headers.put(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_P_CSRF_TOKEN, requestData.get(PREPAY_OD_REQUEST_P_CSRF_TKN));
						headers.put(CONTENT_TYPE, String.valueOf(ContentType.APPLICATION_JSON));
						PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = new PrepaidAdaptorWebClientRequest();
						prepaidAdaptorWebClientRequest.setUrl(processApplePaySession);
						prepaidAdaptorWebClientRequest.setHeader(headers);
						prepaidAdaptorWebClientRequest.setRequestType("POST");
						prepaidAdaptorWebClientRequest.setRequestBody(getProcessApplePrepayODSessionRequest(request));
						logger.info(String.format("PrepaidAdaptorWebClientRequest:%s", prepaidAdaptorWebClientRequest.toString()));
						return prepayAdaptorWebClient
								.getPrepayServiceResponse(httpRequest, prepaidAdaptorWebClientRequest)
								.doOnError(error -> logger.error("Failed to get Submit Order OD response, check exception for details:",error))
								.flatMap(responseEntity -> {
									if (!responseEntity.getStatusCode().is2xxSuccessful()) {
										logger.info("Process apple pay error : {}" , responseEntity.getBody());
										List<onevz.soe.prepay.payment.response.ErrorResponse> errors = new ArrayList<>();
										onevz.soe.prepay.payment.response.ErrorResponse errorResponse=new onevz.soe.prepay.payment.response.ErrorResponse();
										errorResponse.setId("8492");
										errorResponse.setMessage("Exception in play response");
										errorResponse.setName(PrepayAdaptorCheckoutConstants.PREPAY_CHECKOUT_ADAPTOR);
										errorResponse.setNamespace(PrepayAdaptorCheckoutConstants.PREPAY_OD);
										errors.add(errorResponse);
										processApplePaySessionCXPResponse.setErrors(errors);
										return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
												.body(processApplePaySessionCXPResponse));
									}else {
										logger.info("Process apple pay response : {}", responseEntity.getBody());
										ProcessApplePaySessionResponseData data=new ProcessApplePaySessionResponseData();
										ApplePayResponseInfo applePayResponseInfo=new ApplePayResponseInfo();
										applePayResponseInfo.setTransactionId(request.getDecryptTokenReq().getHeader().getTransactionId());
										data.setApplePayResponseInfo(applePayResponseInfo);
										processApplePaySessionCXPResponse.setData(data);
										logger.info("Play process apple pay success");
										
									}
									return Mono.just(ResponseEntity.status(HttpStatus.OK).body(processApplePaySessionCXPResponse));
								});
					}
				});
	}

	public ProcessApplePaySessionPlayRequest getProcessApplePrepayODSessionRequest(ProcessApplePaySessionCxpRequest processApplePaySessionCxpRequest){
		ProcessApplePaySessionPlayRequest processApplePaySessionPlayRequest = new ProcessApplePaySessionPlayRequest();
		if(null==processApplePaySessionCxpRequest) return processApplePaySessionPlayRequest;

		BillingContact billingContact = processApplePaySessionCxpRequest.getBillingContact();
		if(null!=billingContact){
			BillingContactDetails billingContactDetails = new BillingContactDetails();
			BillingShippingContact billingShippingContact = new BillingShippingContact();
			billingShippingContact.setAddressLines(billingContact.getAddressLines());
			billingShippingContact.setLocality(billingContact.getLocality());
			billingShippingContact.setCountry(billingContact.getCountry());
			billingShippingContact.setCountryCode(billingContact.getCountryCode());
			billingShippingContact.setFamilyName(billingContact.getFamilyName());
			billingShippingContact.setGivenName(billingContact.getGivenName());
			billingShippingContact.setLocality(billingContact.getLocality());
			billingShippingContact.setPostalCode(billingContact.getPostalCode());
			billingShippingContact.setSubAdministrativeArea(billingContact.getSubAdArea());
			billingShippingContact.setSubLocality(billingContact.getSubLocality());
			billingContactDetails.setBillingContact(billingShippingContact);
			processApplePaySessionPlayRequest.setBillingContact(billingContactDetails);
		}
		ShippingContact  shippingContract =  processApplePaySessionCxpRequest.getShippingContact();
		if(null!=shippingContract){
			ShippingContactDetails shippingContactDetails = new ShippingContactDetails();
			BillingShippingContact billingShippingContact = new BillingShippingContact();
			billingShippingContact.setEmailAddress(shippingContract.getEmailAddress());
			billingShippingContact.setFamilyName(shippingContract.getFamilyName());
			billingShippingContact.setGivenName(shippingContract.getFamilyName());
			shippingContactDetails.setShippingContact(billingShippingContact);
			processApplePaySessionPlayRequest.setShippingContact(shippingContactDetails);
		}
		DecryptTokenRequest decryptTokenRequest = processApplePaySessionCxpRequest.getDecryptTokenReq();
		if(null!=decryptTokenRequest){
			ApplePayToken applePayToken = new ApplePayToken();

			PaymentData paymentData = new PaymentData();
			paymentData.setData(decryptTokenRequest.getData());
			paymentData.setSignature(decryptTokenRequest.getSignature());
			paymentData.setVersion(decryptTokenRequest.getVersion());

			Header header = decryptTokenRequest.getHeader();
			if(null!=header){
				PaymentHeader paymentHeader = new PaymentHeader();
				paymentHeader.setPublicKeyHash(header.getPublicKeyHash());
				paymentHeader.setEphemeralPublicKey(header.getEphemeralPublicKey());
				paymentHeader.setTransactionId(header.getTransactionId());
				paymentData.setHeader(paymentHeader);
			}
			applePayToken.setPaymentData(paymentData);
			processApplePaySessionPlayRequest.setToken(applePayToken);
		}
		return processApplePaySessionPlayRequest;
	}
}