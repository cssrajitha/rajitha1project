package onevz.soe.prepay.adaptor.checkout.model.payment.request;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
/**
 * Developed By: Rativardhan Singh Sengar
 * 
 * Last Modified 10/24/19 1:39 PM
 * Copyright (c) 2019. All right reserved
 * @author sengara
 *
 */
@Getter
@Setter
@NoArgsConstructor
public class RequestMeta {
	
	private String client;
	private String user;
	private String clientCorrrelationId;
	private String timestamp;

}
