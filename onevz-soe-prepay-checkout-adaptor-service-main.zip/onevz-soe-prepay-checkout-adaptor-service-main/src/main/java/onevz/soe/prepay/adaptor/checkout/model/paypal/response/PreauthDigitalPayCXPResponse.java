package onevz.soe.prepay.adaptor.checkout.model.paypal.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import onevz.soe.prepay.adaptor.checkout.model.payment.request.RequestMeta;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class PreauthDigitalPayCXPResponse {
    private RequestMeta meta;
    private PaypalResponsePayload  payload;
    private List<ErrorResponse> errors;
    private String statusCode;
    private String statusCodeValue;
    @JsonIgnore
    private String triggerFrom;
    @JsonIgnore
    private String domainName;
    @JsonIgnore
    private String oneClickCheckout;
}
