package onevz.soe.prepay.adaptor.checkout.model.payment.request.paymenttype;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
/**
 * Developed By: Rativardhan Singh Sengar
 * 
 * Last Modified 10/24/19 1:39 PM
 * Copyright (c) 2019. All right reserved
 * @author sengara
 *
 * POJO class
 */
@Getter
@Setter
@NoArgsConstructor
public class GiftCardPayment {
	private String id;
	private String cardNumber;
	private String giftCardExpDate;
	private String encryptType;
	private double cardBalanceAmount;
	private String encryptedCardData;
	private String pin;
	private double amountApplied;
	private String tokenizedValue;

}
