package onevz.soe.prepay.adaptor.checkout.controller;

import onevz.soe.prepay.adaptor.checkout.helper.PrepayAdaptorPaymentHelper;
import onevz.soe.prepay.payment.request.cxp.RefillCardCXPRequest;
import onevz.soe.prepay.payment.response.cxp.RefillCardCXPResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import jakarta.validation.Valid;

@RestController
@RequestMapping(value = "/prepaid-adaptor")
public class PrepayAdaptorPaymentController {

	private static final Logger logger = LoggerFactory.getLogger(PrepayAdaptorPaymentController.class);

	@Autowired
	PrepayAdaptorPaymentHelper paymentHelper;

    @InitBinder("*")
	public void initBinderByName(WebDataBinder binder) {
		binder.setDisallowedFields("genericHeader");
	}


	@PostMapping({"/payment/addRefillCard"})
	public Mono<ResponseEntity<RefillCardCXPResponse>> addRefillCard(ServerHttpRequest httpRequest, ServerHttpResponse httpResponse,
																	 @Valid @RequestBody RefillCardCXPRequest refillCardCXPRequest){
		logger.debug("addRefillCard and request {}", refillCardCXPRequest);
		return paymentHelper.addRefillCard(httpRequest, refillCardCXPRequest);

	}

	@PostMapping({"/payment/removeRefillCard"})
	public Mono<ResponseEntity<RefillCardCXPResponse>> removeRefillCard(ServerHttpRequest httpRequest, ServerHttpResponse httpResponse,
																			 @Valid @RequestBody RefillCardCXPRequest refillCardCXPRequest){
		logger.debug("removeRefillCard and request {}", refillCardCXPRequest);
		return paymentHelper.removeRefillCard(httpRequest, refillCardCXPRequest);

	}

	@PostMapping({"/payment/removeAllRefillCards"})
	public Mono<ResponseEntity<RefillCardCXPResponse>> removeAllRefillCards(ServerHttpRequest httpRequest, ServerHttpResponse httpResponse){
		logger.debug("removeAllRefillCards and request");
		return paymentHelper.removeAllRefillCards(httpRequest);

	}

}
