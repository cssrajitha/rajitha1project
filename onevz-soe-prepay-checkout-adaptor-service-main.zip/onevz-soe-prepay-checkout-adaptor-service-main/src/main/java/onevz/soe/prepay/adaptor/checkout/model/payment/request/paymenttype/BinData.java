package onevz.soe.prepay.adaptor.checkout.model.payment.request.paymenttype;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
/**
 * Developed By: Rativardhan Singh Sengar
 * 
 * Last Modified 10/24/19 1:39 PM
 * Copyright (c) 2019. All right reserved
 * @author sengara
 * 
 * POJO class.
 *
 */
@Getter
@Setter
@NoArgsConstructor
public class BinData implements Serializable{

	private static final long serialVersionUID = 4781653547660392990L;
	@JsonInclude(JsonInclude.Include.NON_NULL) // ignore null field on this property only
	private int		binProcessEventTime;
	@JsonInclude(JsonInclude.Include.NON_NULL) // ignore null field on this property only
	private boolean	binProcessEventSuccess;
	@JsonInclude(JsonInclude.Include.NON_NULL) // ignore null field on this property only
	private boolean	binProcessEventTimedOut;

	@JsonProperty("eCommerceIndicator")
	private String	eCommerceIndicator;
	private String	authenticationValue;
	private String	secureTxnId;
	private String secureJwtToken;
	private String eciSafetechFlag;
	private String dsTransactionID;
	private String cardHolderInfo;
	private String threeDSVersion;
	private String prgProtocol;
}
