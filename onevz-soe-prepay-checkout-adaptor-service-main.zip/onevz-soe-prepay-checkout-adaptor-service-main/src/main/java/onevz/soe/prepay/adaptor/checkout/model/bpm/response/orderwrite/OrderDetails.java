package onevz.soe.prepay.adaptor.checkout.model.bpm.response.orderwrite;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class OrderDetails {

	@JsonProperty(value="orderType")
	private String orderType;
	
	@JsonProperty(value="depletionType")
	private String depletionType;
	
	@JsonProperty(value="orderNum")
	private String orderNum;
	
	@JsonProperty(value="orderTotal")
	private String orderTotal;
	
	@JsonProperty(value="digitalOrderId")
	private String digitalOrderId;
	
	@JsonProperty(value="preOrderNumber")
	private String preOrderNumber;

	@JsonProperty(value="isFullAuthSuccess")
	private boolean isFullAuthSuccess;


}
