package onevz.soe.prepay.adaptor.checkout.model.payment.response;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@ToString
public class Payload {

	private PageData pageData;
}
