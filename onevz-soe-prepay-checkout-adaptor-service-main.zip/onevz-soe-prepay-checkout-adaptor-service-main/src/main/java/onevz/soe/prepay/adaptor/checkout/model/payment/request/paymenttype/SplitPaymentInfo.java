package onevz.soe.prepay.adaptor.checkout.model.payment.request.paymenttype;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class SplitPaymentInfo {
	
	private String orderNumber;
	
	private String orderActivityType;
	
	private double nonAccessoryTotal;
	
	private double accessoryTotal;
	
	private boolean nonAccessoryPaid;
	
	private boolean accessoryPaid;


}
