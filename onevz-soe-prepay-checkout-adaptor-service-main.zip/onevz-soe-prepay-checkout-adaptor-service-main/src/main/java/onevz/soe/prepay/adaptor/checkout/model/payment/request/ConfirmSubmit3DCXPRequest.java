package onevz.soe.prepay.adaptor.checkout.model.payment.request;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Developed By: Manikanta Kv Copyright (c) 2019. All right reserved
 * 
 * @author kvma
 * 
 *         POJO class.
 *
 */
@Getter
@Setter
@NoArgsConstructor
public class ConfirmSubmit3DCXPRequest {
	private RequestMeta meta;
	private ConfirmSubmit3DSecureCXPRequestData data;
	
}