package onevz.soe.prepay.adaptor.checkout.model.applepay.response;

import lombok.Data;

@Data
public class GetSessionRes {

	
	private String displayName;
	private String domainName;
	private String epochTimestamp;
	private String signature;
	private String merchantSessionIdentifier;
	private String nonce;
	private String merchantIdentifier;
}
