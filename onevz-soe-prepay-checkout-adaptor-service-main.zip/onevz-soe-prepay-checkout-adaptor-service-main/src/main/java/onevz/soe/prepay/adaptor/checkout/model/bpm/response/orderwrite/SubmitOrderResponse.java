package onevz.soe.prepay.adaptor.checkout.model.bpm.response.orderwrite;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.*;
import onevz.soe.wsclient.bpm.model.response.BPMServiceResponse;

@lombok.Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(callSuper=true)
public class SubmitOrderResponse extends BPMServiceResponse{

	@JsonInclude(Include.NON_NULL)
    private String status;
    private SubmitOrderPayload payload;
}
