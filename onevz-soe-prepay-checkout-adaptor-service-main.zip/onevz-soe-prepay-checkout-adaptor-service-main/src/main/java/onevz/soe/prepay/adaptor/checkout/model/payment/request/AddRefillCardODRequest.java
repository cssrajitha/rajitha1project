package onevz.soe.prepay.adaptor.checkout.model.payment.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class AddRefillCardODRequest {
    private String refillCardNumber;
    private String gRecaptchaResponse;

    @JsonProperty("g-recaptcha-response")
    public String getRecaptchaResponse(){
        return gRecaptchaResponse;
    }
}
