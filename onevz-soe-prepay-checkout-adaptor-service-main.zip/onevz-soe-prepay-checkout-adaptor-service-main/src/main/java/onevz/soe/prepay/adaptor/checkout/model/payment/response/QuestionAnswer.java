package onevz.soe.prepay.adaptor.checkout.model.payment.response;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class QuestionAnswer {
    private String questionNumber;
    private String questionText;
    List<ChoiceForQuestion> choiceForQuestions;
}
