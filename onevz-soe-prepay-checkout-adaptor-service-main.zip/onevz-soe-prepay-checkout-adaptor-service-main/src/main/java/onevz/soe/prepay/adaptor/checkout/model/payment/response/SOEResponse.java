package onevz.soe.prepay.adaptor.checkout.model.payment.response;

public interface SOEResponse {
}
