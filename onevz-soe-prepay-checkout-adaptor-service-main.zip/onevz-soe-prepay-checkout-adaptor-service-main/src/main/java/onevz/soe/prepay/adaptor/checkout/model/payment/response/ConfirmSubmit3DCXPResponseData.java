package onevz.soe.prepay.adaptor.checkout.model.payment.response;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Developed By: Manikanta Kv Copyright (c) 2019. All right reserved
 * 
 * @author kvma
 * 
 *         POJO class.
 *
 */
@Getter
@Setter
@NoArgsConstructor
public class ConfirmSubmit3DCXPResponseData {
	private String acsUrl;
	private String payload;
	private String cmpiTransId;
	private String jwtProcessorTransactionId;
	private String preAuthSuccess;
	private String status;
	private String enrolled;
	private String action;   
	private String eidQuestionnaireSubmitted;
	private String actionScore;
	private RiskScore riskScore;
	private InnovisPhoneNumber innovisPhoneNumber;
	private EIDQuestionnaire eidVerifier;
	private String tokenizedValue;
	private String cardHolderInfo;
	private String dsTransactionID;
	private String threeDSVersion;
	
}
