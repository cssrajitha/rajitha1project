package onevz.soe.prepay.adaptor.checkout.model.payment.response;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class InnovisPhoneNumber {
    private String phoneRecommendation;
    private List<PhoneList> phoneList;
}
