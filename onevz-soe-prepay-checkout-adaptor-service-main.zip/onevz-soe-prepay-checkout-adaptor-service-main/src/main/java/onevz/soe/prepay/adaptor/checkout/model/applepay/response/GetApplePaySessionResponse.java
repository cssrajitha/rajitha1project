package onevz.soe.prepay.adaptor.checkout.model.applepay.response;

import lombok.Data;

@Data
public class GetApplePaySessionResponse {
	
	private String status;
	private String statusCode;
	private ApplePayPayLoad payload;

}
