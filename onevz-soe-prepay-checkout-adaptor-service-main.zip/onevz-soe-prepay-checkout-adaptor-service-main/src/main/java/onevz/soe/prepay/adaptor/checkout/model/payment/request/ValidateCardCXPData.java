/*
 * Developed By: Rativardhan Singh Sengar
 * 
 * Last Modified 10/062/19 3:30 PM
 * Copyright (c) 2019. All right reserved
 */
package onevz.soe.prepay.adaptor.checkout.model.payment.request;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
/**
 * 
 * Pojo of validate Card
 *
 */
@Getter
@Setter
@NoArgsConstructor
public class ValidateCardCXPData {
	private String cartId;
	private String action;
	private String itemType;
	private String intendType;
	private String numOfAttempts;
	
	private ValidateCardCXPDataPayment payment;
	private boolean accessoryFinancingOfferAccepted;
}
