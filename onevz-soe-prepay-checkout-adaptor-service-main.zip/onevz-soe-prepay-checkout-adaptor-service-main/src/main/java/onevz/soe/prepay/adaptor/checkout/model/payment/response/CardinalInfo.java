package onevz.soe.prepay.adaptor.checkout.model.payment.response;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@ToString
@Data
public class CardinalInfo {

	private String jwtToken;
	private String acsUrl;
	private String payload;
	private String transactionId;
	private FeatureList featureList;
	private String maskedCardNumber;
	private String handlePost3DCardinalUrl;
	
}
