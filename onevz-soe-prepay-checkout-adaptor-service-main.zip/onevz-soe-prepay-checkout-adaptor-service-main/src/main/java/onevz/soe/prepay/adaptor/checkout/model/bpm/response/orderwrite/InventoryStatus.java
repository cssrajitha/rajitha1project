package onevz.soe.prepay.adaptor.checkout.model.bpm.response.orderwrite;

import lombok.Data;

@Data
public class InventoryStatus {

	String itemCode;
	String qtyAvailable;
}
