package onevz.soe.prepay.adaptor.checkout.model.payment.request;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@NoArgsConstructor
public class CreditCardRequest {

	private String creditCardNumber;
	
	private String creditCardVerificationNumber;
	
	private String creditCardType;
	
	private String billingZipCode;
	
	private String creditCardExpMonth;
	
	private String creditCardExpYear;
	
	private String lastFourDigits;
	
	private boolean isCCPIEEncryptionSuccess;
	
	private boolean isAutoPay;
	
	private String jwt;
	
	private String cardinalSetUpComplete;	
	
	
}
