package onevz.soe.prepay.adaptor.checkout.util;

import io.micrometer.core.instrument.util.IOUtils;
import io.micrometer.core.instrument.util.StringUtils;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/**
 * class File Reader util class is general class
 * to read the files.
 *
 */
public class FileReaderUtil {

    private FileReaderUtil() {
        throw new IllegalAccessError("Utility class");
    }


    /**
     * method fore read file.
     * @param fileName
     * @return string
     */
    public static String readFromFile(String fileName) {
        String jsonContent = null;
        ClassLoader classLoader = FileReaderUtil.class.getClassLoader();
        if(null != classLoader){
            InputStream inputStream = classLoader.getResourceAsStream(fileName);
            jsonContent = IOUtils.toString(inputStream, StandardCharsets.UTF_8);
        }
        if(StringUtils.isNotBlank(jsonContent)){
            return jsonContent;
        }
        return "{}";
    }
}

