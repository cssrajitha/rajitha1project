package onevz.soe.prepay.adaptor.checkout.model.payment.request.paymenttype;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class DownPaymentVerizonDollarAmount  implements Serializable{
	private String mtn;
	private double amount;
}
