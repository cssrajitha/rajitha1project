package onevz.soe.prepay.adaptor.checkout.model.updatelinesecurityinfo.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UpdateLineSecurityInfoPrepayOdRequest {

    public String deviceLineItemId;
    public String lineSecurityPin;
    public String securityQuestion;
    public String securityAnswer;
    public boolean pieEncryptionSuccess;
}
