package onevz.soe.prepay.adaptor.checkout.model.payment.request.paymenttype;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * POJO Class for card swipe data
 * @author PADMASN
 *
 */
@Getter
@Setter
@NoArgsConstructor
public class SwipeRequest {

	private String cardSwipeData ; 
	private String cardSwipeTrack2Data ;
	private String entryMode ; 
	private String emvAttached ; 
	private String emvDeviceCapability ; 
	private String emvUsed ;
	private String emvFallback ; 
	private String fallbackEntryMode ;
	private String emvDevice ;
	private String cardNfcData ;
	private String cardPin ;
	private String keySerialNumber ;
	private String posKey;
}
