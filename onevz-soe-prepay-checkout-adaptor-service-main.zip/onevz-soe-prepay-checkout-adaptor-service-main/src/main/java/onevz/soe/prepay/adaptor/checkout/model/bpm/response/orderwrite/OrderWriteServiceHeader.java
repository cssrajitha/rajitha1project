package onevz.soe.prepay.adaptor.checkout.model.bpm.response.orderwrite;

import lombok.EqualsAndHashCode;
import lombok.ToString;
import onevz.soe.wsclient.bpm.model.ServiceHeader;

@ToString
@EqualsAndHashCode(callSuper = true)
public class OrderWriteServiceHeader extends ServiceHeader {

}
