package onevz.soe.prepay.adaptor.checkout.model.payment.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@ToString
public class ErrorMap {

	@JsonProperty(value= "01")
	private String message;
}
