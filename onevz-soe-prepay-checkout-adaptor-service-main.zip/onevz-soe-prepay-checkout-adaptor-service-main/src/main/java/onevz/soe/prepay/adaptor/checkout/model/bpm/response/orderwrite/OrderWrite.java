package onevz.soe.prepay.adaptor.checkout.model.bpm.response.orderwrite;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class OrderWrite {
	
	@JsonInclude(Include.NON_NULL)
	@JsonProperty(value="twoYear")
	private String twoYear;
	
	@JsonProperty(value="salesRep")
	private String salesRep;
	
	@JsonProperty(value="customerAgreement")
	private String customerAgreement;
	
	@JsonProperty(value="mobileNumber")
	private String mobileNumber;
	
	@JsonProperty(value="mgrApprovalReq")
	private String mgrApprovalReq;
	
	@JsonProperty(value="btaEligibleAmount")
	private String btaEligibleAmount;
	
	@JsonProperty(value="orderNum")
	private String orderNum;
	
	@JsonProperty(value="billingSys")
	private String billingSys;
	
	@JsonProperty(value="edgeOrder")
	private String edgeOrder;
	
	@JsonProperty(value="orderTotal")
	private String orderTotal;
	
	@JsonProperty(value="orderDetails")
	private List<OrderDetails> orderDetails;
	
	@JsonProperty(value="fullAccountNumber")
	private String fullAccountNumber;
	
	@JsonProperty(value="btaEligible")
	private String btaEligible;
	
	@JsonProperty(value="renderType")
	private String renderType;
	
	@JsonProperty(value="creditApp")
	private String creditApp;
	
	@JsonProperty(value="locationCode")
	private String locationCode;
	
	@JsonProperty(value="loanNumber")
	private String loanNumber;
	
	@JsonProperty(value="status")
	private String status;
	
	@JsonProperty(value="fivegOrder")
	private String fivegOrder;

	@JsonProperty(value="activationInfo")
	private ActivationInfo activationInfo;
	
}
