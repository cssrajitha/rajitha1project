package onevz.soe.prepay.adaptor.checkout.model.applepay.request;

import lombok.Data;

@Data
public class BillingContactDetails {
	
	private BillingShippingContact billingContact;

}
