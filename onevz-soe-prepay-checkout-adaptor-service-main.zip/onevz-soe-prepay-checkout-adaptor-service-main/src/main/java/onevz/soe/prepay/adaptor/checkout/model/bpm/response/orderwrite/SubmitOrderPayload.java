package onevz.soe.prepay.adaptor.checkout.model.bpm.response.orderwrite;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.*;
import onevz.soe.od.model.VZWPrepayOrderSubmitVO;

@lombok.Data
@NoArgsConstructor
@AllArgsConstructor
@ToString

public class SubmitOrderPayload {
	@JsonInclude(Include.NON_NULL)
	private VZWPrepayOrderSubmitVO pageData;

}
