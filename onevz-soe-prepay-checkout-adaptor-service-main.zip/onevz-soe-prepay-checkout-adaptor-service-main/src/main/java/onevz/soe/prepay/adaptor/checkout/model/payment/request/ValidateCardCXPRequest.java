package onevz.soe.prepay.adaptor.checkout.model.payment.request;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


/**
 * 
 * Pojo of validate Card
 *
 */
@Getter
@Setter
@NoArgsConstructor
public class ValidateCardCXPRequest {
	private RequestMeta meta;
	private ValidateCardCXPData data;

}
