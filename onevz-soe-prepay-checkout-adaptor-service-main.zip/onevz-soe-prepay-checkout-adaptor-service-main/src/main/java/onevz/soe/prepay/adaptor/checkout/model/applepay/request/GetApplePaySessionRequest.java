package onevz.soe.prepay.adaptor.checkout.model.applepay.request;

import lombok.Data;

@Data
public class GetApplePaySessionRequest {
	
	private String endPointURL;

}
