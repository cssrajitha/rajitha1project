package onevz.soe.prepay.adaptor.checkout.model.payment.request.paymenttype;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Developed By: Rativardhan Singh Sengar
 * 
 * Last Modified 10/24/19 1:39 PM
 * Copyright (c) 2019. All right reserved
 * @author sengara
 * 
 * POJO class.
 *
 */
@Getter
@Setter
@NoArgsConstructor
public class BTAData {
	
	private String mobileNumber;
	private String accountNumber;
	private String accountSubNumber;
	private String billingSystem;
	//@JsonProperty(value = "mtnLevelCharge")
	
	private String marketId;
	// This will only come from UI
	private boolean mtnLevelCharge;
	
}
