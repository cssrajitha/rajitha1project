package onevz.soe.prepay.adaptor.checkout.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.checkout.request.bpm.UpdateLineSecurityInfoRequest;
import onevz.soe.checkout.response.bpm.UpdateLineSecurityInfoResponse;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.common.model.PrepaidODRequestDataLines;
import onevz.soe.prepay.adaptor.checkout.constants.PrepayAdaptorCheckoutConstants;
import onevz.soe.prepay.adaptor.checkout.model.updatelinesecurityinfo.request.UpdateLineSecurityInfoPrepayOdRequest;
import onevz.soe.prepay.adaptor.checkout.model.updatelinesecurityinfo.response.UpdateLineSecurityInfoPrepayOdResponse;
import onevz.soe.prepay.adaptor.checkout.util.PrepayAdaptorCheckoutUtil;
import onevz.soe.prepay.adaptor.checkout.util.PrepayUpdateLineSecurityInfoFormatterUtil;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.bpm.model.response.Error;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import onevz.soe.wsclient.prepay.webclient.model.PrepaidAdaptorWebClientRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static onevz.soe.prepay.adaptor.checkout.constants.PrepayAdaptorCheckoutConstants.NSE;
import static onevz.soe.prepay.adaptor.checkout.constants.PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA;

@Service
public class PrepayAdaptorUpdateLineSecurityInfoHelper {

    private static final Logger logger = LoggerFactory.getLogger(PrepayAdaptorUpdateLineSecurityInfoHelper.class);

    @Autowired
    private ObjectMapper mapper;

    @Value("${updateLineSecurityInfo}")
    private String updateLineSecurityInfoPrepaidLegacyServiceUrl;

    @Autowired
    private PrepayAdaptorWebClient prepayAdaptorWebClient;

    @Autowired
    private PrepayCheckoutRedisHelper updateLineSecurityInfoRedisHelper;

    public Mono<ResponseEntity<UpdateLineSecurityInfoResponse>> updateLineSecurityInfo(ServerHttpRequest httpRequest, UpdateLineSecurityInfoRequest request) {
        return updateLineSecurityInfoRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)
                .flatMap(response -> {
                    if (StringUtilities.isNotEmptyOrNull(response)) {
                        logger.info("Redis Data From Redis:: {}", response);
                        PrepaidODRequestData redisData = null;
                        try {
                            redisData = mapper.readValue(response, PrepaidODRequestData.class);
                        } catch (JsonProcessingException e) {
                            logger.error("Failed to parse data from redis:", e);
                            return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new UpdateLineSecurityInfoResponse()));
                        }
                        /*String intendType = Objects.nonNull(request) && Objects.nonNull(request.getServiceBody()) && Objects.nonNull(request.getServiceBody().getServiceRequest())
                                                && Objects.nonNull(request.getServiceBody().getServiceRequest().getContext())
                                                && Objects.nonNull(request.getServiceBody().getServiceRequest().getContext().getCartInfo())?request.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType():NSE; */
                        String intendType = Objects.nonNull(redisData) && CollectionUtilities.isNotEmptyOrNull(redisData.getLines())?redisData.getLines().get(redisData.getCurr_line()-1).getFlow():NSE;
                        logger.info("Flowname in the UpdateSecurityInfohelper: {}",intendType);
                        UpdateLineSecurityInfoPrepayOdRequest updateLineSecurityInfoPPrepayOdRequest = PrepayUpdateLineSecurityInfoFormatterUtil.formatLineSecurityInfoRequest(request,redisData);
                        PrepaidAdaptorWebClientRequest prepaidLegacyServiceRequest = getPrepaidLegacyServiceRequest(updateLineSecurityInfoPPrepayOdRequest, redisData, intendType);
                        return updateLineSecurity(httpRequest, prepaidLegacyServiceRequest, redisData, request);
                    } else {
                        UpdateLineSecurityInfoResponse updateLineSecurityInfoResponse = new UpdateLineSecurityInfoResponse();
                        return Mono.just(ResponseEntity.status(HttpStatus.OK).body(updateLineSecurityInfoResponse));
                    }
                });
    }

    public Mono<ResponseEntity<UpdateLineSecurityInfoResponse>> updateLineSecurity(ServerHttpRequest httpRequest, PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest, PrepaidODRequestData redisData, UpdateLineSecurityInfoRequest request) {
        return prepayAdaptorWebClient.getPrepayServiceResponse(httpRequest, prepaidAdaptorWebClientRequest)
                .doOnError(error -> logger.error("Failed to get response", error))
                .flatMap(responseEntity -> {
                    UpdateLineSecurityInfoResponse updateLineSecurityInfoResponse = new UpdateLineSecurityInfoResponse();
                    UpdateLineSecurityInfoPrepayOdResponse restResponse = new UpdateLineSecurityInfoPrepayOdResponse();
                    try {
                        if (!responseEntity.getStatusCode().is2xxSuccessful()) {
                           logger.error(" UpdateLineSecurityInfo Error while calling endpoint: {} with status code: {}",
                                    prepaidAdaptorWebClientRequest.getUrl(), responseEntity.getStatusCode());
                           List<Error> errors = PrepayAdaptorCheckoutUtil.buildErrorResponse(PrepayAdaptorCheckoutConstants.UPDATE_SECURITY_PIN_BUSINESS_ERR_NAME, 
                        		   PrepayAdaptorCheckoutConstants.UPDATE_SECURITY_PIN_BUSINESS_ERR_ID, PrepayAdaptorCheckoutConstants.UPDATE_SECURITY_PIN_SERVICE_ERR_MSG, PrepayAdaptorCheckoutConstants.UPDATE_SECURITY_PIN_BUSINESS_ERROR_CATEGORY);
                           updateLineSecurityInfoResponse.setErrors(errors);
                           return Mono.just(ResponseEntity.status(HttpStatus.OK).body(updateLineSecurityInfoResponse));
                        } else {
                            String responseString = responseEntity.getBody();
                            restResponse = mapper.readValue(responseString, UpdateLineSecurityInfoPrepayOdResponse.class);
                            if (Objects.nonNull(restResponse)) {
                            	String mtn = request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).getMtn();
						        String mtnRedis = "";
						        List<PrepaidODRequestDataLines> dataLines = redisData.getLines();
						        List<PrepaidODRequestDataLines> linesToProcess = redisData.getLines().stream().filter(line-> line.getMtn().equalsIgnoreCase(mtn)).collect(Collectors.toList());
					             PrepaidODRequestDataLines lineToProcess = linesToProcess.get(0);
                                 mtnRedis = Objects.nonNull(lineToProcess)?lineToProcess.getMtn():"";
                                 logger.info("mtn of the line in Redis: {}",mtnRedis);
                                 lineToProcess.setSecurityPinAssigned(true);
                                 int currNumNotAccountPinLines = redisData.getLines().stream().filter(line-> !(line.isSecurityPinAssigned())).collect(Collectors.toList()).size();
                                 dataLines.set(dataLines.indexOf(lineToProcess), lineToProcess);
                                 redisData.setLines(dataLines);
 
                                 if(currNumNotAccountPinLines>0) {
                                	 redisData.setAccountPinAssignedtoAllLines(false);
                                 } else {
                                	 redisData.setAccountPinAssignedtoAllLines(true);
                                 }
                                 
                                 return updateLineSecurityInfoRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, redisData)
							    		  .doOnError(err -> logger.error("Failed to update the PrepaidODRequestData to Redis", err))
							    		  .flatMap(upsertResp -> 
							    		  {
							    			  logger.info("Successfully inserted updated Redis Data: {}",upsertResp);
							    			  UpdateLineSecurityInfoResponse lineSecurityInfoResponse = PrepayUpdateLineSecurityInfoFormatterUtil.formatUpdateLineSecurityInfoResponse(redisData, request);
							    			  return Mono.justOrEmpty(ResponseEntity.status(HttpStatus.OK).body(lineSecurityInfoResponse));
							    		  });
                            }
                            else {
                                logger.info("No Response returned for UpdateLineSecurity Pin");
                                List<Error> errors = PrepayAdaptorCheckoutUtil.buildErrorResponse(PrepayAdaptorCheckoutConstants.UPDATE_SECURITY_PIN_SERVICE_ERR_NAME, 
                             		   PrepayAdaptorCheckoutConstants.UPDATE_SECURITY_PIN_SERVICE_ERR_ID, PrepayAdaptorCheckoutConstants.UPDATE_SECURITY_PIN_SERVICE_ERR_MSG, PrepayAdaptorCheckoutConstants.UPDATE_SECURITY_PIN_ERROR_CATEGORY);
                                updateLineSecurityInfoResponse.setErrors(errors);
                                return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(updateLineSecurityInfoResponse));
                            }

                        }
                    } catch (JsonProcessingException e) {
                        logger.info("{}", e.getMessage());
                        List<Error> errors = PrepayAdaptorCheckoutUtil.buildErrorResponse(PrepayAdaptorCheckoutConstants.UPDATE_SECURITY_PIN_SERVICE_ERR_NAME, 
                      		   PrepayAdaptorCheckoutConstants.UPDATE_SECURITY_PIN_SERVICE_ERR_ID, PrepayAdaptorCheckoutConstants.UPDATE_SECURITY_PIN_SERVICE_ERR_MSG, PrepayAdaptorCheckoutConstants.UPDATE_SECURITY_PIN_ERROR_CATEGORY);
                         updateLineSecurityInfoResponse.setErrors(errors);
                         return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(updateLineSecurityInfoResponse));
                    }

                });
    }

    private PrepaidAdaptorWebClientRequest getPrepaidLegacyServiceRequest(UpdateLineSecurityInfoPrepayOdRequest request, PrepaidODRequestData prepaidODRequestData, String flow) {
        PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = new PrepaidAdaptorWebClientRequest();
        prepaidAdaptorWebClientRequest.setUrl(updateLineSecurityInfoPrepaidLegacyServiceUrl);
        prepaidAdaptorWebClientRequest.setRequestBody(request);
        prepaidAdaptorWebClientRequest.setRequestType("POST");
        prepaidAdaptorWebClientRequest.setHeader(PrepayAdaptorCheckoutUtil.getPrepayODServiceCommonHeaders(prepaidODRequestData,flow));
        return prepaidAdaptorWebClientRequest;
    }
}
