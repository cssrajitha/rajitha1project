package onevz.soe.prepay.adaptor.checkout.model.payment.response;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Developed By: Rativardhan Singh Sengar
 *
 * Last Modified 10/24/19 1:39 PM
 * Copyright (c) 2019. All right reserved
 * @author sengara
 *
 * POJO class.
 *
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.ALWAYS)
public class DetailsErrorResponse {

	private String issue;
	private String field;
	private String location;
	private String value;

	/**
	 * Constructor to create error detail with just Issue and field location
	 * @param issue
	 * @param location
	 */
	public DetailsErrorResponse(String issue, String location){
		this.issue = issue;
		this.location = location;
	}

}
