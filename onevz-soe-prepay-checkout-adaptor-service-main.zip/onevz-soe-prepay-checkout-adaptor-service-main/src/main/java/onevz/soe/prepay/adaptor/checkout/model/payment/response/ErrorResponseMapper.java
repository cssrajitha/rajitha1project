package onevz.soe.prepay.adaptor.checkout.model.payment.response;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@ToString
public class ErrorResponseMapper {
	
	private String status;
	private String statusCode;
	private Errors errors;
	private String output;
	private String maxAttemptsReached;
	private String statusMessage;
	private ErrorMap errorMap;
}
