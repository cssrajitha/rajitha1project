package onevz.soe.prepay.adaptor.checkout.model.paypal.request;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Developed By: Manikanta Kv Copyright (c) 2019. All right reserved
 * 
 * @author kvma
 * 
 *         POJO class.
 *
 */
@Getter
@Setter
@NoArgsConstructor
public class CMPILookupCXPRequest {
	private String ipAddress;
	private String cartId;	
	private String termUrl;
	private String shippingOptionId;
}