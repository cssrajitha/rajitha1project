package onevz.soe.prepay.adaptor.checkout.model.applepay.response;

import lombok.Data;

@Data
public class ApplePayPageData{
	
	private SvcBdy svcBdy;

}
