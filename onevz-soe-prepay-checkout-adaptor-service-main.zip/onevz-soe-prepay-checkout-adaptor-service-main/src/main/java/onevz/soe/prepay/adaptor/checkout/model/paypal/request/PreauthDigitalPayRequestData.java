package onevz.soe.prepay.adaptor.checkout.model.paypal.request;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class PreauthDigitalPayRequestData {
    private String cartId;
    private String triggerFrom;
    private String paymentType;    
}
