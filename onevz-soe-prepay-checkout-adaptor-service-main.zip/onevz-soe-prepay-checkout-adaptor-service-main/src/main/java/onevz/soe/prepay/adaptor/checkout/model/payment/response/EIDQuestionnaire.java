package onevz.soe.prepay.adaptor.checkout.model.payment.response;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class EIDQuestionnaire {
    private String numOfQuestions;
    private String messageId;
    private List<QuestionAnswer> questionAnswer;
}
