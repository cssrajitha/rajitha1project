package onevz.soe.prepay.adaptor.checkout;

import onevz.soe.core.annotations.SOEBootApplication;
import onevz.soe.datastore.annotations.EnableDatastoreClients;
import org.springframework.boot.SpringApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * CartService Bootstrap class.
 */
@SOEBootApplication
@ComponentScan(basePackages = { "onevz.spring.config", "onevzw.soe.core.config", "onevz.soe.session","onevz.aem.errorhandling",
		 "onevz.soe.spring.web.filter", "onevz.soe.cradle.client", "onevz.soe.wsclient.prepay.api.impl", "onevz.soe.wsclient.prepay.webclient", "onevz.soe.prepay.adaptor.checkout", "onevz.soe.cart.model.common","onevz.nsa"})
@EnableDatastoreClients(value = {"onevz.soe.cradle", "onevz.soe.core.exception.datastore.client", "onevz.soe.security", "onevz.soe.session", "onevz.soe.cart.datastore.client", "onevz.aem.errorhandling",})
public class PrepayAdaptorCheckoutBootstrap {

	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(PrepayAdaptorCheckoutBootstrap.class, args);
	}
}
