package onevz.soe.prepay.adaptor.checkout.model.bpm.response.orderwrite;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.*;
import onevz.soe.cart.model.common.ProcessMTNList;
import onevz.soe.wsclient.bpm.model.Context;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(callSuper=true)
public class OrderWriteContext extends Context{

	@JsonInclude(Include.NON_NULL)
	private OrderWriteCustomerInfo orderWriteCustomerInfo;

	@JsonInclude(Include.NON_NULL)
	private ProcessMTNList[] processMTNList;
	
	@JsonInclude(Include.NON_NULL)
	private OrderWrite orderWrite;
	
	@JsonInclude(Include.NON_NULL)
	PaymentOptions[] paymentOptions;
	
	private EnforceData enforceData;
	
	private List<InventoryStatus> inventoryStatus;

	private ActivationInfo activationInfo;

}
