/*
 * Developed By: Rativardhan Singh Sengar
 * 
 * Last Modified 10/062/19 3:30 PM
 * Copyright (c) 2019. All right reserved
 */
package onevz.soe.prepay.adaptor.checkout.model.payment.request.paymenttype;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


/**
 * 
 * Pojo of validate Card
 *
 */
@Getter
@Setter
@NoArgsConstructor
public class ValidateCardPaymentDetails {
	private String			paymRegisterNum;
	private String			paymentAmount;
	private String 			paymentType;
	private boolean 		savedCC;
	private CardData		creditCardPayment;
	private GiftCardPayment	giftCardPayment;
	private BTAData			acPayment; //BTA Model from UI 
	private VDpayment		vdPayment;
	private BTAData			ddPayment;
	// Adding it to implement the delete the payment option from cart
	private String paymentSequence;
}
