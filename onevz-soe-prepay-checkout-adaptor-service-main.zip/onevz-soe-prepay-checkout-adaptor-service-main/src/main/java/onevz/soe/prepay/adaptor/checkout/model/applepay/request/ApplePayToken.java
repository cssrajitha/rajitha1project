package onevz.soe.prepay.adaptor.checkout.model.applepay.request;

import lombok.Data;

@Data
public class ApplePayToken {
	
	private PaymentData paymentData;
	private PaymentMethod paymentMethod;
	private String transactionIdentifier;

}
