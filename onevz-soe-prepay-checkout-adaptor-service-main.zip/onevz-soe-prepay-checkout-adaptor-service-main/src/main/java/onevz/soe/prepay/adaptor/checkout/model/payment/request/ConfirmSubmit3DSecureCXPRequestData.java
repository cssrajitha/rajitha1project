package onevz.soe.prepay.adaptor.checkout.model.payment.request;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import onevz.soe.prepay.adaptor.checkout.model.payment.request.paymenttype.ValidateCardPaymentDetails;


/**
 * Developed By: Manikanta Kv Copyright (c) 2019. All right reserved
 * 
 * @author kvma
 * 
 *         POJO class.
 *
 */
@Getter
@Setter
@NoArgsConstructor
public class ConfirmSubmit3DSecureCXPRequestData {
	private String cartId;
	private String action;
	private String itemType;
	private String locationCode;
	private String orderNum;
	private String orderType;
	private String vendorId;
	private String intendType;
	
	private String selectedpaymentType;
	@JsonProperty(value= "isEncrypted")
	private boolean isEncrypted;
	private String sessionId;
	private String amount;
	private String transactionPwd;
	private String callEnforceApi;
	private String numOfAttempts;
	private String attempts3DSCount;
	private String originatingClientIp;
	private String safeTechSessionId;
	private String referenceId;
	private String transactionId;
	
	private List<ValidateCardPaymentDetails> payments;
	private EIdCXPRequest eIdRequest;
	private String messageId;
	private String phoneNumber;
	private String paymentSubAction;
	private boolean browserJavaScriptEnabled;
	private String browserHeader;
	@Schema(description = "browserColorDepth to send to cardinal service")
	private Integer browserColorDepth;
	@Schema(description = "Boolean value that represents the ability of the cardholder browser to execute Java")
	private boolean browserJavaEnabled;
	@Schema(description = "browserLanguage to send to cardinal service")
	private String browserLanguage;
	@Schema(description = "browserScreenHeight to send to cardinal service")
	private Integer browserScreenHeight;
	@Schema(description = "browserScreenWidth to send to cardinal service")
	private Integer browserScreenWidth;
	@Schema(description = "browserTimeZone to send to cardinal service")
	private Integer browserTimeZone;
	private boolean accessoryFinancingOfferAccepted;
	private boolean autoPay;
}