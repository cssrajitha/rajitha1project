package onevz.soe.prepay.adaptor.checkout.model.payment.request;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import onevz.soe.prepay.adaptor.checkout.model.payment.request.paymenttype.BinData;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ConfirmPaymentRequest {

	private CreditCardRequest creditCardInfo;
	
	private BinData binData;
	
	private boolean browserJavaScriptEnabled;
	
}
