package onevz.soe.prepay.adaptor.checkout.helper;

import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.model.common.CartServiceCartInfo;
import onevz.soe.cart.model.common.CartServiceContextInfo;
import onevz.soe.cart.model.common.CartServiceCustomerInfo;
import onevz.soe.cart.model.common.CartServiceServiceHeader;
import onevz.soe.cart.model.initiateCheckout.*;
import onevz.soe.cart.requests.InitiateCheckoutPEGARequest;
import onevz.soe.cart.responses.InitiateCheckoutPEGAResponse;
import onevz.soe.prepay.adaptor.checkout.constants.PrepayAdaptorCheckoutConstants;
import onevz.soe.prepay.adaptor.checkout.util.PrepayAdaptorCheckoutUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;

@Service
public class PrepayAdaptorValidateOrderHelper {
	
	@Autowired
	private ObjectMapper mapper;
	
	@Autowired
	private PrepayCheckoutRedisHelper prepayCheckoutRedisHelper;

	@Value("${readyForOrderSubmit}")
	private Boolean readyForOrderSubmit;
	
	private static final Logger logger = LoggerFactory.getLogger(PrepayAdaptorValidateOrderHelper.class);

	/**
	 * @param validateOrderPEGARequest
	 * @return AddPlanPEGAResponse
	 */
	public Mono<ResponseEntity<InitiateCheckoutPEGAResponse>> validateOrder(InitiateCheckoutPEGARequest validateOrderPEGARequest) {
		
		InitiateCheckoutPEGAResponse requestResponse = getValidateOrderPEGAResponse(validateOrderPEGARequest);
		
		return Mono.just(ResponseEntity.status(HttpStatus.OK).body(requestResponse));
		
	}
	
	private InitiateCheckoutPEGAResponse getValidateOrderPEGAResponse(InitiateCheckoutPEGARequest validateOrderPEGARequest) {
		
		InitiateCheckoutPEGAResponse response = new InitiateCheckoutPEGAResponse();
		response.setServiceHeader(getServiceHeader(validateOrderPEGARequest));
		response.setServiceBody(getServiceBody(validateOrderPEGARequest));
		return response;
	}
	
	private CartServiceServiceHeader getServiceHeader(InitiateCheckoutPEGARequest validateOrderPEGARequest) {
		CartServiceServiceHeader validateOrderCartServiceHeader = new CartServiceServiceHeader();
		validateOrderCartServiceHeader.setStatusCode(PrepayAdaptorCheckoutConstants.PREPAY_CART_SERVICES_HEADER_STATUS_CODE_SUCCESS);
		validateOrderCartServiceHeader.setStatusMsg(PrepayAdaptorCheckoutConstants.PREPAY_CART_SERVICES_HEADER_STATUS_MSG_SUCCESS);
		validateOrderCartServiceHeader.setServiceName(validateOrderPEGARequest.getServiceHeader().getServiceName());
		validateOrderCartServiceHeader.setUserId(validateOrderPEGARequest.getServiceHeader().getUserId());
		validateOrderCartServiceHeader.setSessionId(validateOrderPEGARequest.getServiceHeader().getSessionId());
		validateOrderCartServiceHeader.setCorrelationId(validateOrderPEGARequest.getServiceHeader().getCorrelationId());
		
		return validateOrderCartServiceHeader;
	}

	private InitiateCheckoutServiceBody getServiceBody(InitiateCheckoutPEGARequest validateOrderPEGARequest) {
		InitiateCheckoutServiceBody validateOrderServiceBody = new InitiateCheckoutServiceBody();
		validateOrderServiceBody.setServiceResponse(getServiceResponse(validateOrderPEGARequest));	
		return validateOrderServiceBody;
	}

	private InitiateCheckoutServiceResponse getServiceResponse(InitiateCheckoutPEGARequest validateOrderPEGARequest) {
		InitiateCheckoutServiceResponse validateOrderServiceResponse = new InitiateCheckoutServiceResponse();
		validateOrderServiceResponse.setContext(getServiceContext(validateOrderPEGARequest));
				
		return validateOrderServiceResponse;
	}
	
	private InitiateCheckoutContext getServiceContext(InitiateCheckoutPEGARequest validateOrderPEGARequest) {
		InitiateCheckoutContext validateOrderServiceContext = new InitiateCheckoutContext();
		validateOrderServiceContext.setCartServiceContextInfo(getCartServiceContextInfo(validateOrderPEGARequest));
		validateOrderServiceContext.setCartServiceCartInfo(getCartServiceCartInfo());
		validateOrderServiceContext.setCustomerInfo(getCartServiceCustomerInfo(validateOrderPEGARequest));
		validateOrderServiceContext.setValidateOrder(getValidateOrder(validateOrderPEGARequest));

		return validateOrderServiceContext;
	}

	private ValidateOrder getValidateOrder(InitiateCheckoutPEGARequest validateOrderPEGARequest) {
		ValidateOrder validateOrder = new ValidateOrder();
		validateOrder.setOrderDetails(getValidateOrderOrderDetails(validateOrderPEGARequest));
		validateOrder.setReadyForOrderSubmit(readyForOrderSubmit);
		return validateOrder;
	}

	private List<OrderDetail> getValidateOrderOrderDetails(InitiateCheckoutPEGARequest validateOrderPEGARequest) {
		List<OrderDetail> orderDetailList = new ArrayList<>();
		OrderDetail orderDet = new OrderDetail();
		orderDet.setLineActivityType(validateOrderPEGARequest.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
		orderDet.setOrderActivityType(validateOrderPEGARequest.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
		orderDet.setOrderStatus(PrepayAdaptorCheckoutConstants.PREPAY_CART_SERVICES_HEADER_STATUS_MSG_SUCCESS);
		orderDetailList.add(orderDet);
		return orderDetailList;
	}

	private CartServiceContextInfo getCartServiceContextInfo(InitiateCheckoutPEGARequest validateOrderPEGARequest) {
		CartServiceContextInfo validateOrderContextInfo = new CartServiceContextInfo();
		validateOrderContextInfo.setCallReason(validateOrderPEGARequest.getServiceBody().getServiceRequest().getContext().getContextInfo().getCallReason());
		// TBD: Hardcoded Process Step value need to be read from Redis
		validateOrderContextInfo.setProcessStep("OrderReview");
		return validateOrderContextInfo;
	}
	
	private CartServiceCartInfo getCartServiceCartInfo() {
		return new CartServiceCartInfo();

	}
	
	private CartServiceCustomerInfo getCartServiceCustomerInfo(InitiateCheckoutPEGARequest validateOrderPEGARequest) {
		CartServiceCustomerInfo validateOrderCustomerInfo = new CartServiceCustomerInfo();
		validateOrderCustomerInfo.setCustomerType(validateOrderPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCustomerType());
		validateOrderCustomerInfo.setAccountNumber(validateOrderPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getAccountNumber());
		validateOrderCustomerInfo.setCartCreator(validateOrderPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCartCreator());
		validateOrderCustomerInfo.setProcessingMTN(validateOrderPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getProcessingMTN());
		validateOrderCustomerInfo.setRegisterNumber(validateOrderPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getRegisterNumber());
	    validateOrderCustomerInfo.setGlobalId(validateOrderPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getGlobalId());
	    String cradleFlowJourney = "";
	    try {
	    	String throttleName = validateOrderPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getThrottleName();
	    	if(throttleName != null) {
	    	cradleFlowJourney = PrepayAdaptorCheckoutUtil.firstStringWithInPipes(throttleName);
	    	}
	    	else {
	    		logger.debug("Throttle Name in the request is null");
	    	}
	    }catch(Exception e)
	    {
	    	logger.debug("Exception while getting cradleFlow Journey value from request:", e);
	    }
	    validateOrderCustomerInfo.setCradleFlowJourney(cradleFlowJourney);
		return validateOrderCustomerInfo;
	}
	
	
}
