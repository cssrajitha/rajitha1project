package onevz.soe.prepay.adaptor.checkout.model.payment.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@ToString
public class PageData {
	private BillingInfo billingInfo;
	private CardinalInfo cardinalInfo;
	@JsonProperty("is3DSecureCard")
	private boolean secureCard; 
}
