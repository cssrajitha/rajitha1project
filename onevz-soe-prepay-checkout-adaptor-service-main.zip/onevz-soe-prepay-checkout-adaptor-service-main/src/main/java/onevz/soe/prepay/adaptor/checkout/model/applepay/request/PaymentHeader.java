package onevz.soe.prepay.adaptor.checkout.model.applepay.request;

import lombok.Data;

@Data
public class PaymentHeader {
	
	private String publicKeyHash;
	private String ephemeralPublicKey;
	private String transactionId;

}
