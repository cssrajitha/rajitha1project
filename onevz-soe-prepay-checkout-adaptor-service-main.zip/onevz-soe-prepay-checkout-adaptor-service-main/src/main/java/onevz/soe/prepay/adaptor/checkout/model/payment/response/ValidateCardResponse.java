package onevz.soe.prepay.adaptor.checkout.model.payment.response;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import onevz.soe.prepay.adaptor.checkout.model.payment.response.BillingInfo;
import onevz.soe.prepay.adaptor.checkout.model.payment.response.CardinalInfo;

/**
 * 
 * Pojo of validate Card
 *
 */
@Getter
@Setter
@NoArgsConstructor
public class ValidateCardResponse {
	 private String locationCode; 
	 private String orderNum;
	 private String preAuthSuccess; 
	 private String tokenizedvalue;
	 private String statusMsg;
	 private BillingInfo billingInfo;
	 private CardinalInfo cardinalInfo;
	 private boolean is3DSecureCard;
	 private String acsUrl;
}
