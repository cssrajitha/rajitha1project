package onevz.soe.prepay.adaptor.checkout.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.prepay.adaptor.checkout.constants.PrepayAdaptorCheckoutConstants;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Service
public class PrepayCheckoutRedisHelper {

	@Autowired
	SOELoginSessionBean sessionBean;

	@Autowired
	private ObjectMapper mapper;



	private static final Logger logger = LoggerFactory.getLogger(PrepayCheckoutRedisHelper.class);

	/**
	 * @param key
	 * @param data
	 * @return boolean
	 */
	public Mono<Boolean> upsertDataIntoRedisAsStr(String key, Object data) {
		Map<String,String> reqMap=new HashMap<>();
		reqMap.put(key, convertObjectToString(data));
		return sessionBean.setSessionData(reqMap).doOnError(onError -> 	logger.error(" Unable to add/update data into Redis", onError))
				.doOnSuccess(onSuccess -> logger.info("Successfully updated data to Redis: {}", onSuccess))
				.flatMap(response -> {
			logger.info("data upserted to redis response : {}",response);
			return Mono.just(response);
		});
	}

	/**
	 *
	 * @return getDataFromRedisAsString
	 */
	public Mono<String> getDataFromRedisAsString(String key) {
		return sessionBean.getSessionData(key, String.class)
				.doOnError(onError -> logger.error(" Unable to get data from Redis", onError))
				.doOnSuccess(onSuccess -> logger.info("Successfully retrieved data from Redis: {}", onSuccess))
				.flatMap(Mono::just);
	}

	private String convertObjectToString(Object obj){
		String requestString="";
		try {
			requestString = mapper.writeValueAsString(obj);
		} catch (JsonProcessingException err) {
			logger.error("Unable to convert object to String", err);
		}
		return requestString;
	}

	public Map<String,String> handleRedisData(String redisData) {
		Map<String,String> requestHeaders=new HashMap<>();
		try {
			PrepaidODRequestData prepaidODRequestData=mapper.readValue(redisData, PrepaidODRequestData.class);
			if(null!=prepaidODRequestData.getEcommSessionId() && null!=prepaidODRequestData.getPCsrfToken()) {
				String eCommSessionId=prepaidODRequestData.getEcommSessionId();
				String pcsrfToken=prepaidODRequestData.getPCsrfToken();
				requestHeaders.put("eCommSessionId", eCommSessionId);
				requestHeaders.put("pcsrfToken", pcsrfToken);
				String flow = Objects.nonNull(prepaidODRequestData) && CollectionUtilities.isNotEmptyOrNull(prepaidODRequestData.getLines())?prepaidODRequestData.getLines().get(prepaidODRequestData.getCurr_line()-1).getFlow():PrepayAdaptorCheckoutConstants.NSE;
				logger.info("Flow name of latest line: {}",flow);
				requestHeaders.put("flow", flow);

				if(!StringUtilities.isEmptyOrNull(prepaidODRequestData.getPaypalPaRes()) && !StringUtilities.isEmptyOrNull(prepaidODRequestData.getPaypalMD()))
				{
				requestHeaders.put("PaRes", prepaidODRequestData.getPaypalPaRes());
				requestHeaders.put("MD", prepaidODRequestData.getPaypalMD());
				}
			}
			else {
				logger.info("ECOMM_SESSION and p_csrftkn are empty");
			}
		} catch (JsonProcessingException e) {
			logger.error("Unable to convert object to String", e);
		}
		return requestHeaders;
	}
}
