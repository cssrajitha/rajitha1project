package onevz.soe.prepay.adaptor.checkout.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.model.initiateCheckout.OrderWriteRequest;
import onevz.soe.cart.model.initiateCheckout.OrderWriteResponse;
import onevz.soe.cart.requests.InitiateCheckoutPEGARequest;
import onevz.soe.cart.responses.InitiateCheckoutPEGAResponse;
import onevz.soe.checkout.request.bpm.UpdateLineSecurityInfoRequest;
import onevz.soe.checkout.response.bpm.UpdateLineSecurityInfoResponse;
import onevz.soe.prepay.adaptor.checkout.exceptions.JsonValidator;
import onevz.soe.prepay.adaptor.checkout.helper.PrepayAdaptorCheckoutHelper;
import onevz.soe.prepay.adaptor.checkout.helper.PrepayAdaptorOrderWriteHelper;
import onevz.soe.prepay.adaptor.checkout.helper.PrepayAdaptorUpdateLineSecurityInfoHelper;
import onevz.soe.prepay.adaptor.checkout.helper.PrepayAdaptorValidateOrderHelper;
import onevz.soe.prepay.adaptor.checkout.model.payment.request.ConfirmSubmit3DCXPRequest;
import onevz.soe.prepay.adaptor.checkout.model.payment.request.ValidateCardCXPRequest;
import onevz.soe.prepay.adaptor.checkout.model.payment.response.ConfirmSubmit3DCXPResponse;
import onevz.soe.prepay.adaptor.checkout.model.payment.response.ValidateCardPaymentCXPResponse;
import onevz.soe.prepay.adaptor.checkout.model.paypal.request.CMPILookupCXPRequest;
import onevz.soe.prepay.adaptor.checkout.model.paypal.request.PreauthDigitalPayCXPRequest;
import onevz.soe.prepay.adaptor.checkout.model.paypal.response.CMPILookupCXPResponse;
import onevz.soe.prepay.adaptor.checkout.model.paypal.response.PreauthDigitalPayCXPResponse;
import onevz.soe.prepay.payment.request.cxp.ProcessApplePaySessionCxpRequest;
import onevz.soe.prepay.payment.response.cxp.GetApplePaySessionCXPResponse;
import onevz.soe.prepay.payment.response.cxp.ProcessApplePaySessionCXPResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import jakarta.validation.Valid;

import static onevz.soe.prepay.adaptor.checkout.constants.PrepayAdaptorCheckoutConstants.CONST_ENDPOINT;


/**
 * Prepay Adaptor Checkout Controller class.
 */
//NSADT-53978 removing CrossOrigin annotation in every service.
//@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping(value = "/prepaid-adaptor")
public class PrepayAdaptorCheckoutServiceController {

	private static final Logger logger = LoggerFactory.getLogger(PrepayAdaptorCheckoutServiceController.class);

	@Autowired
	private PrepayAdaptorCheckoutHelper prepayAdaptorCheckoutHelper;

	@Autowired
	private ObjectMapper mapper;

	@Autowired
	JsonValidator validator;

	@Autowired
	private Environment env;

	@Autowired
	private PrepayAdaptorValidateOrderHelper validateOrderHelper;
	
	@Autowired
	private PrepayAdaptorOrderWriteHelper orderWriteHelper;

	@Autowired
	private PrepayAdaptorUpdateLineSecurityInfoHelper updateLineSecurityInfoHelper;
	/**
	 * 
	 * @param binder
	 */
	@InitBinder("*")
	public void initBinderByName(WebDataBinder binder) {
		binder.setDisallowedFields("genericHeader");
	}

	/**
	 *
	 * @param request
	 * @return ResponseEntity
	 *
	 */
	@PostMapping({"/checkout/test"})
	public Mono<ResponseEntity<String>> checkoutValidation(@Valid @RequestBody Object request) {
		System.setProperty(CONST_ENDPOINT, "checkoutValidation");
		logger.debug("checkoutValidation Request: {}", request);
		
		return prepayAdaptorCheckoutHelper.templateMethod("initial");
	}

	@PostMapping({"/checkout/test2"})
	public Mono<ResponseEntity<String>> checkoutValidation2(@Valid @RequestBody Object request) {
		System.setProperty(CONST_ENDPOINT, "checkoutValidation");
		logger.debug("checkoutValidation Request: {}", request);

		return prepayAdaptorCheckoutHelper.templateMethod( "2nd test");
	}

	/**
	 *
	 * @param httpRequest
	 * @param httpResponse
	 * @param orderWriteRequest
	 * @return ResponseEntity
	 *
	 */
	@PostMapping({"/checkout/orderWrite"})
	public Mono<ResponseEntity<OrderWriteResponse>> orderWrite(ServerHttpRequest httpRequest,
															   ServerHttpResponse httpResponse,
															   @Valid @RequestBody OrderWriteRequest orderWriteRequest) {
		System.setProperty(CONST_ENDPOINT, "orderWrite");
		logger.debug("orderWrite Request: {}", orderWriteRequest);

		return orderWriteHelper.orderWrite(httpRequest, orderWriteRequest);
	}


    //Mono<ResponseEntity<ValidateCardPaymentCXPResponse>>
    @PostMapping({"/payment/update-payment"})
    public Mono<ResponseEntity<ValidateCardPaymentCXPResponse>> getUpdatePayment(ServerHttpRequest httpRequest,
                                                                                 ServerHttpResponse httpResponse,
                                                                            @Valid @RequestBody ValidateCardCXPRequest pReq) {
        logger.debug("inside of PrepayAdaptorPaymentController.getUpdatePayment");
      return orderWriteHelper.getUpdatePayment(httpRequest,pReq);
    }


	/**
	 *
	 * @param httpRequest
	 * @param httpResponse
	 * @param validateOrderPEGARequest
	 * @return ResponseEntity
	 *
	 */
	@PostMapping({"/checkout/validateOrder"})
	public Mono<ResponseEntity<InitiateCheckoutPEGAResponse>> validateOrder(ServerHttpRequest httpRequest,
															   ServerHttpResponse httpResponse,
															   @Valid @RequestBody InitiateCheckoutPEGARequest validateOrderPEGARequest) {
		System.setProperty(CONST_ENDPOINT, "validateOrder");
		logger.debug("validateOrder Request: {}", validateOrderPEGARequest);

		return validateOrderHelper.validateOrder(validateOrderPEGARequest);
	}

    @PostMapping({"/paypal/lookup"})
    public Mono<ResponseEntity<CMPILookupCXPResponse>> doPaypalLookUp(ServerHttpRequest httpRequest,
                                                                                 ServerHttpResponse httpResponse,
                                                                            @Valid @RequestBody CMPILookupCXPRequest pReq) {
        logger.debug("inside of PrepayAdaptorPaymentController.lookup");
      return orderWriteHelper.getPayPalLookUp(httpRequest,pReq);
    }

    @PostMapping({"/paypal/preauth-paypal"})
    public Mono<ResponseEntity<PreauthDigitalPayCXPResponse>> doPaypalAuthenticate(ServerHttpRequest httpRequest,
                                                                                 ServerHttpResponse httpResponse,
                                                                            @Valid @RequestBody PreauthDigitalPayCXPRequest request) {
        logger.debug("inside of PrepayAdaptorPaymentController.lookup");
      return orderWriteHelper.getPaypalAuth(httpRequest,request);
    }

    @PostMapping({"/payment/3dsecure-lookup"})
    public Mono<ResponseEntity<ConfirmSubmit3DCXPResponse>> upsertConfirmSubmit3D(ServerHttpRequest httpRequest,
                                                                                 ServerHttpResponse httpResponse,
                                                                            @Valid @RequestBody ConfirmSubmit3DCXPRequest request) {
        logger.debug("inside of PrepayAdaptorPaymentController.upsertConfirmSubmit3D");
      return orderWriteHelper.confirmSubmit3D(httpRequest,request);
    }

	/**
	 * Update contact info details like email and phone number.
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@PostMapping("/checkout/updateLineSecurityInfo")
	public Mono<UpdateLineSecurityInfoResponse> updateLineSecurityInfo(ServerHttpRequest httpRequest,@RequestBody UpdateLineSecurityInfoRequest request){
		logger.info("Start Adapter updateLineSecurityInfo");
		logger.debug("updateLineSecurityInfo Request: {}", request);
		Mono<ResponseEntity<UpdateLineSecurityInfoResponse>> responseEntity = updateLineSecurityInfoHelper.updateLineSecurityInfo(httpRequest, request);
		return responseEntity.flatMap(dataResponse-> {
			UpdateLineSecurityInfoResponse response = new UpdateLineSecurityInfoResponse();
			response = dataResponse.getBody();
			String responseString = "";
			try {
				responseString = mapper.writeValueAsString(response);
			} catch (JsonProcessingException e){
				logger.error(e.getMessage());
			}
			logger.info("updateLineSecurityInfo response :  {}", responseString);
			return Mono.just(response);
		});
	}
	@PostMapping({"/payment/getApplePaySession"})
	public Mono<ResponseEntity<GetApplePaySessionCXPResponse>> getApplePaySessionDetails(ServerHttpRequest httpRequest,
															   ServerHttpResponse httpResponse,
															   @RequestBody Object request) {
		 
		 logger.info("inside of PrepayAdaptorPaymentController.getApplePaySessionDetails"); 
		 return orderWriteHelper.getApplePaySessionDetails(httpRequest,request);
		 
	 }
	 
	 @PostMapping({"/payment/processApplePayToken"})
	 public Mono<ResponseEntity<ProcessApplePaySessionCXPResponse>> processApplePayTokenDetails(ServerHttpRequest httpRequest,
															   ServerHttpResponse httpResponse,
															   @RequestBody ProcessApplePaySessionCxpRequest request){
		 
		 logger.info("inside of PrepayAdaptorPaymentController.processApplePayTokenDetails"); 
		 return orderWriteHelper.processApplePayTokenDetails(httpRequest, request);
		 
	 }
}

