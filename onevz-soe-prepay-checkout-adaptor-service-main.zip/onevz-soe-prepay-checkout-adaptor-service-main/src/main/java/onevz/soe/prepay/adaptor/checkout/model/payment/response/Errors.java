package onevz.soe.prepay.adaptor.checkout.model.payment.response;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import onevz.soe.od.model.EcommApiErrorList;
import onevz.soe.od.model.Error;


@Setter
@Getter
@NoArgsConstructor
@ToString
public class Errors {
	private String status;
	private EcommApiErrorList[] ecommApiErrorList;
	private Error[] error;
}
