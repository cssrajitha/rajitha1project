package onevz.soe.prepay.adaptor.checkout.model.paypal.request;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import onevz.soe.prepay.adaptor.checkout.model.payment.request.RequestMeta;

@Getter
@Setter
@NoArgsConstructor
public class PreauthDigitalPayCXPRequest {
    private RequestMeta meta;
    private PreauthDigitalPayRequestData data;
}
