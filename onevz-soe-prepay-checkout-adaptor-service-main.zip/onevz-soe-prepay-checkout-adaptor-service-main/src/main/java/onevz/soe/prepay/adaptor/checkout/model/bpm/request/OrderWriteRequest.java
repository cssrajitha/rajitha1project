package onevz.soe.prepay.adaptor.checkout.model.bpm.request;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import onevz.soe.prepay.adaptor.checkout.model.bpm.response.orderwrite.OrderWriteServiceBody;
import onevz.soe.prepay.adaptor.checkout.model.bpm.response.orderwrite.OrderWriteServiceHeader;
import onevz.soe.wsclient.bpm.model.request.BPMServiceRequest;


@ToString
@EqualsAndHashCode(callSuper = true)

@Data
public class OrderWriteRequest extends BPMServiceRequest {
	
	OrderWriteServiceHeader orderWriteServiceHeader;
	OrderWriteServiceBody orderWriteServiceBody;

}
