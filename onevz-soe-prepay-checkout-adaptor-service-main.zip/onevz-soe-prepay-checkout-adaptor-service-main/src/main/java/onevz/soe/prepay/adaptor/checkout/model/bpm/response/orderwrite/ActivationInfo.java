package onevz.soe.prepay.adaptor.checkout.model.bpm.response.orderwrite;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ActivationInfo {

    @JsonProperty(value = "isActivationStatus")
    private String isActivationStatus;
    @JsonProperty(value="activationCode")
    private String activationCode;
    @JsonProperty(value = "imei")
    private String imei;
    @JsonProperty(value = "iccid")
    private String iccid;
    @JsonProperty(value="eid")
    private String eid;
    @JsonProperty(value="newMDN")
    private String newMDN;

}
