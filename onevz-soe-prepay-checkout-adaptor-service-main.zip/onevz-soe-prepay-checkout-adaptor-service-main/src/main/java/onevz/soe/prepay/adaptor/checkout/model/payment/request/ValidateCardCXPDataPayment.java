/*
 * Developed By: Rativardhan Singh Sengar
 * 
 * Last Modified 10/062/19 3:30 PM
 * Copyright (c) 2019. All right reserved
 */
package onevz.soe.prepay.adaptor.checkout.model.payment.request;

import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import onevz.soe.prepay.adaptor.checkout.model.payment.request.paymenttype.ValidateCardPaymentDetails;

/**
 * 
 * Pojo of validate Card
 *
 */
@Getter
@Setter
@NoArgsConstructor
public class ValidateCardCXPDataPayment {
	private String locationCode;
	private String orderNum;
	private String orderType;
	private String safeTechSessionId;
	private List<ValidateCardPaymentDetails> paymentDetails;
	private String paymentSubAction;
}
