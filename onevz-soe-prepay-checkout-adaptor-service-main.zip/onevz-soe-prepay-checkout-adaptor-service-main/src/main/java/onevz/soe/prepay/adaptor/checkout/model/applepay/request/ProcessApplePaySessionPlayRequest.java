package onevz.soe.prepay.adaptor.checkout.model.applepay.request;

import lombok.Data;

@Data
public class ProcessApplePaySessionPlayRequest {
	
	private BillingContactDetails billingContact;
	private ShippingContactDetails shippingContact;
	private ApplePayToken token;
}
