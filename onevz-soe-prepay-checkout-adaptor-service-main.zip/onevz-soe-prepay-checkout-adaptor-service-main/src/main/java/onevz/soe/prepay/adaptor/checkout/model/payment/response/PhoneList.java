package onevz.soe.prepay.adaptor.checkout.model.payment.response;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class PhoneList {
    private String phoneSource;
    private String phone;
    private String phoneType;
    private String totalOccurrences;
    private String activeOccurrences;
    private String refId;
}
