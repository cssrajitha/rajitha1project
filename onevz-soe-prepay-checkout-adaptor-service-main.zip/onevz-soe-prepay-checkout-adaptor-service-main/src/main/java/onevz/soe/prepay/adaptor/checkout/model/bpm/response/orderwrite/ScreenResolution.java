package onevz.soe.prepay.adaptor.checkout.model.bpm.response.orderwrite;

import lombok.Data;

@Data
public class ScreenResolution {
	private String availableWidth;
	private String availableHeight;
	private String actualWidth;
	private String actualHeight;
	private String pixelDensity;
}