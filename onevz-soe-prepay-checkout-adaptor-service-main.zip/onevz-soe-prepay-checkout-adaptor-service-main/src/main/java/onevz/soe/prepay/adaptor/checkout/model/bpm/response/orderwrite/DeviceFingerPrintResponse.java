package onevz.soe.prepay.adaptor.checkout.model.bpm.response.orderwrite;

import lombok.Data;
import onevz.soe.wsclient.bpm.model.response.ServiceResponse;

@Data
public class DeviceFingerPrintResponse extends ServiceResponse{
	boolean isSubmitted;
}
