package onevz.soe.prepay.adaptor.checkout.model.payment.request;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class EIdCXPRequest {
    private String messageId;
    private String customerReferenceNumber;
}
