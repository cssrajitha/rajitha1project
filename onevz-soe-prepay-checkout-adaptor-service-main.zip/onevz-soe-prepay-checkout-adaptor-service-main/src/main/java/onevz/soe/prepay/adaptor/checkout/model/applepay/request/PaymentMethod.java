package onevz.soe.prepay.adaptor.checkout.model.applepay.request;

import lombok.Data;

@Data
public class PaymentMethod {
	
	private String displayName;
	private String network;
	private String type;

}
