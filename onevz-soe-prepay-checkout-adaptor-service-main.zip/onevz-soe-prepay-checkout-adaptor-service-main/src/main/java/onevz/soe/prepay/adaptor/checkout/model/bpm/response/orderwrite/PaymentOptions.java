package onevz.soe.prepay.adaptor.checkout.model.bpm.response.orderwrite;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class PaymentOptions {
	
	@JsonProperty(value="rfexPaymentDetails")
	String rfexPaymentDetails;
	
	@JsonProperty(value="btaRemainingBalance")
	String btaRemainingBalance;
	
	@JsonProperty(value="savedCC")
	String savedCC;
	
	@JsonProperty(value="btaOrderTotal")
	String btaOrderTotal;
	
	@JsonProperty(value="maxPaymentAmount")
	String maxPaymentAmount;
	
	@JsonProperty(value="paymentType")
	String paymentType;
	
		
}
