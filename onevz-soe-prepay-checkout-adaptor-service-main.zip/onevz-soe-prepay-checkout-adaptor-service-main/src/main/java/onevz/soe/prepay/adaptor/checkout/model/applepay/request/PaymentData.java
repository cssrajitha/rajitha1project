package onevz.soe.prepay.adaptor.checkout.model.applepay.request;

import lombok.Data;

@Data
public class PaymentData {
	
	private String data;
	private String signature;
	private String version;
	private PaymentHeader header;

}
