package onevz.soe.prepay.adaptor.checkout.model.bpm.response.orderwrite;

import lombok.Data;

@Data
public class HttpHeaderData {

	private String host;
	private String accept;
	private String acceptEncoding;
	private String acceptLanguage;
	private String referer;
	private String connection;
}
