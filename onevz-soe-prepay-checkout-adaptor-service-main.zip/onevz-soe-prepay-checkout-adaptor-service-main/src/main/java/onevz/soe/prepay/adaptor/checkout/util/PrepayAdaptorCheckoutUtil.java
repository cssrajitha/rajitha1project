package onevz.soe.prepay.adaptor.checkout.util;

import onevz.soe.channels.SOEChannels;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.prepay.adaptor.checkout.constants.PrepayAdaptorCheckoutConstants;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.bpm.model.response.Error;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static onevz.soe.prepay.adaptor.checkout.constants.PrepayAdaptorCheckoutConstants.AAL;
import static onevz.soe.prepay.adaptor.checkout.constants.PrepayAdaptorCheckoutConstants.BYOD;
import static onevz.soe.prepay.adaptor.checkout.constants.PrepayAdaptorCheckoutConstants.ESO;
import static onevz.soe.prepay.adaptor.checkout.constants.PrepayAdaptorCheckoutConstants.EUP;
import static onevz.soe.prepay.adaptor.checkout.constants.PrepayAdaptorCheckoutConstants.NSE;
import static onevz.soe.prepay.adaptor.checkout.constants.PrepayAdaptorCheckoutConstants.NSE_BYOD;
import static onevz.soe.prepay.adaptor.checkout.constants.PrepayAdaptorCheckoutConstants.NSP;
import static onevz.soe.prepay.adaptor.checkout.constants.PrepayAdaptorCheckoutConstants.PAL;
import static onevz.soe.prepay.adaptor.checkout.constants.PrepayAdaptorCheckoutConstants.PASO;
import static onevz.soe.prepay.adaptor.checkout.constants.PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_ECOMM_SESSION;
import static onevz.soe.prepay.adaptor.checkout.constants.PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_FLOW;
import static onevz.soe.prepay.adaptor.checkout.constants.PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_P_CSRFTKN;
import static onevz.soe.prepay.adaptor.checkout.constants.PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_P_CSRF_TOKEN;
import static onevz.soe.prepay.adaptor.checkout.constants.PrepayAdaptorCheckoutConstants.PUP;

@Service
public class PrepayAdaptorCheckoutUtil {
	private static final Logger logger = LoggerFactory.getLogger(PrepayAdaptorCheckoutUtil.class);
	
	


	private PrepayAdaptorCheckoutUtil(){

	}
	/**
	 * 
	 * @param channelId
	 * @return channelType
	 */
	public static String getChannelType(String channelId) {
		if (channelId != null && SOEChannels.findByChannelName(channelId) != null) {
			return SOEChannels.findByChannelName(channelId).getChannelType();
		}
		return "";
	}

	/**
	 * 
	 * @param channelId
	 * @return channelType
	 */
	public static String getChannel(String channelId) {

		if (channelId != null && SOEChannels.findByChannelName(channelId) != null) {
			return SOEChannels.findByChannelName(channelId).getChannelType();
		}
		return null;
	}
	
	/**
	 * 
	 * @param depletionLocationCode
	 * @param channelId
	 * @return result
	 */
	public static String removeSpecialCharacters(String depletionLocationCode, String channelId) {
		String result = depletionLocationCode;
		if(PrepayAdaptorCheckoutConstants.ASSISTED.equalsIgnoreCase(getChannelType(channelId)))	
			result = depletionLocationCode.replaceAll("[-+.^:,]","");
		
		return result;
	}

	public static boolean isDigital(String channelId) {
		return PrepayAdaptorCheckoutConstants.DIGITAL.equalsIgnoreCase(PrepayAdaptorCheckoutUtil.getChannelType(channelId));
	}
	
	public static boolean isDigitalChannel(String channelId) {
		boolean isDigitalChannel = Boolean.FALSE;
		if (SOEChannels.findByChannelName(channelId) != null
				&& "Digital".equalsIgnoreCase(SOEChannels.findByChannelName(channelId).getChannelType()))
			isDigitalChannel = Boolean.TRUE;
		return isDigitalChannel;
	}
	
	/*public static List<HttpMessageConverter<?>> responseToJsonEntityConverter(){
		List<HttpMessageConverter<?>> messageConverters = new ArrayList<>();

		MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();

		converter.setSupportedMediaTypes(Collections.singletonList(MediaType.ALL));
		messageConverters.add(converter);
		return messageConverters;
	}*/
	
	/**
	 * 
	 * @param throttleText
	 * @return String
	 */
	public static String firstStringWithInPipes(String throttleText)
	{
		logger.debug("firstStringWithInPipes: String from which text between first 2 pipes to be stripped: {}", throttleText);
		String response = "";
		final Pattern pattern = Pattern.compile("(?<=\\|)[^|]++(?=\\|)");
		final Matcher matcher = pattern.matcher(throttleText);
		
		if(matcher.find()) {
			response = matcher.group();
		}
		logger.debug("firstStringWithInPipes: Stripped text between first 2 pipes: {}", response);
		return response;
	}
	
	public static List<Error> buildErrorResponse(String name, String id, String message, String errorCategory) {
		
        List<Error> errors = new ArrayList<>();
        Error error = new Error();
        error.setName(name);
        error.setId(id);
        error.setMessage(message);
        error.setErrorCategory(errorCategory);
        error.setErrorCode(errorCategory);
        error.setProactiveChatCustomMSG(PrepayAdaptorCheckoutConstants.PROACTIVE_CHAT_CUSTOMER_ERR_MSG);
        error.setProactiveChatIndicator(PrepayAdaptorCheckoutConstants.PROACTIVE_CHAT_INDICATOR);
        errors.add(error);
        return errors;
	}

/*	public static Map<String,String> getPrepayODServiceCommonHeaders(PrepaidODRequestData prepaidODRequestData) {
		String prepaidODRequestCookieStr = null;
		Map<String,String> headers=new HashMap<>();
		if(StringUtilities.isNotEmptyOrNull(prepaidODRequestData.getEcommSessionId())){
			prepaidODRequestCookieStr = PREPAY_OD_REQUEST_ECOMM_SESSION + "="+prepaidODRequestData.getEcommSessionId()+";"
					+ PREPAY_OD_REQUEST_FLOW +"="+NSE+";";
		}
		if(StringUtilities.isNotEmptyOrNull(prepaidODRequestData.getPCsrfToken())){
			prepaidODRequestCookieStr = prepaidODRequestCookieStr + PREPAY_OD_REQUEST_P_CSRF_TKN +"="+prepaidODRequestData.getPCsrfToken()+";";
			headers.put(PREPAY_OD_REQUEST_P_CSRF_TOKEN, prepaidODRequestData.getPCsrfToken());
		}
		if(StringUtilities.isNotEmptyOrNull(prepaidODRequestCookieStr)){
			headers.put(HttpHeaders.COOKIE, prepaidODRequestCookieStr);
		}
		headers.put(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);

		return headers;
	} */

	public static Map<String,String> getPrepayODServiceCommonHeaders(PrepaidODRequestData prepaidODRequestData, String flowName) {
		String prepaidODRequestCookieStr = null;
		Map<String,String> headers=new HashMap<>();
		String flow="";
		if(NSE.equalsIgnoreCase(flowName)){
			flow = NSE;
		} else if(NSE_BYOD.equalsIgnoreCase(flowName) || NSP.equalsIgnoreCase(flowName)){
			flow = NSP;
		} else if(ESO.equalsIgnoreCase(flowName) || BYOD.equalsIgnoreCase(flowName) || PASO.equalsIgnoreCase(flowName)) {
			flow = PASO;
		}else if(AAL.equalsIgnoreCase(flowName)) {
			flow = PAL;
		} else if(EUP.equalsIgnoreCase(flowName)) {
			flow = PUP;
		} else {
			flow = NSE;
		}

		if(StringUtilities.isNotEmptyOrNull(prepaidODRequestData.getEcommSessionId())){
			prepaidODRequestCookieStr = PREPAY_OD_REQUEST_ECOMM_SESSION + "="+prepaidODRequestData.getEcommSessionId()+";"
					+ PREPAY_OD_REQUEST_FLOW +"="+ flow +";";
		}
		if(StringUtilities.isNotEmptyOrNull(prepaidODRequestData.getPCsrfToken())){
			prepaidODRequestCookieStr = prepaidODRequestCookieStr + PREPAY_OD_REQUEST_P_CSRFTKN +"="+prepaidODRequestData.getPCsrfToken()+";";
			headers.put(PREPAY_OD_REQUEST_P_CSRF_TOKEN, prepaidODRequestData.getPCsrfToken());
		}
		if(StringUtilities.isNotEmptyOrNull(prepaidODRequestCookieStr)){
			headers.put(HttpHeaders.COOKIE, prepaidODRequestCookieStr);
		}
		headers.put(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);

		return headers;
	}

}
