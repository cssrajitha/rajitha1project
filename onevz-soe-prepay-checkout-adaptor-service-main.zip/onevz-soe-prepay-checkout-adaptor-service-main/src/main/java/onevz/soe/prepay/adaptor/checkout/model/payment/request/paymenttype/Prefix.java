package onevz.soe.prepay.adaptor.checkout.model.payment.request.paymenttype;
import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
/**
 * Developed By: Rativardhan Singh Sengar
 * 
 * Last Modified 10/24/19 1:39 PM
 * Copyright (c) 2019. All right reserved
 * @author sengara
 *
 * POJO class
 */
@Getter
@Setter
@NoArgsConstructor
public class Prefix implements Serializable {
	private static final long serialVersionUID = 1L;
	private String prefixString;
	
}
