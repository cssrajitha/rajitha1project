package onevz.soe.prepay.adaptor.checkout.model.bpm.request;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.*;
import onevz.soe.prepay.adaptor.checkout.model.bpm.response.orderwrite.OrderWriteContext;
import onevz.soe.wsclient.bpm.model.request.ServiceRequest;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(callSuper=true)
public class OrderWriteServiceRequest extends ServiceRequest {

	@JsonInclude(Include.NON_NULL)
	private OrderWriteContext orderWriteContext;
}

