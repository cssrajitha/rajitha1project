package onevz.soe.prepay.adaptor.checkout.model.bpm.response.orderwrite;

import lombok.*;
import onevz.soe.wsclient.bpm.model.CustomerInfo;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor	
@ToString
@EqualsAndHashCode(callSuper=true)
public class OrderWriteDNISOrderData extends CustomerInfo{
	
	String acdCallId;
	String ani;
	String dnis;
	String ivrCallerId;
	String originatingDn; 

}
