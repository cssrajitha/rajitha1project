package onevz.soe.prepay.adaptor.checkout.model.paypal.response;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class PaypalResponsePayload {
private PreauthDigitalPayCXPDataResponse pageData;
}
