package onevz.soe.prepay.adaptor.checkout.helper;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
public class PrepayAdaptorCheckoutHelper {

	public Mono<ResponseEntity<String>> templateMethod(String src) {
		return Mono.just(ResponseEntity.status(HttpStatus.OK).body(src));
	}

}
