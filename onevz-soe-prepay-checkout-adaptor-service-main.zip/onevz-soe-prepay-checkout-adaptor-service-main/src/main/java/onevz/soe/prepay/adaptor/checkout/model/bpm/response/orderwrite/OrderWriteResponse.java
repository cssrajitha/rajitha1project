package onevz.soe.prepay.adaptor.checkout.model.bpm.response.orderwrite;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.*;
import onevz.soe.wsclient.bpm.model.response.BPMServiceResponse;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(callSuper=true)
public class OrderWriteResponse extends BPMServiceResponse{

	@JsonInclude(Include.NON_NULL)
    OrderWriteServiceBody orderWriteServiceBody;
	 
}
