package onevz.soe.prepay.adaptor.checkout.model.bpm.response.orderwrite;

import lombok.*;
import onevz.soe.wsclient.bpm.model.CustomerInfo;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(callSuper=true)
public class OrderWriteCustomerInfo extends CustomerInfo{

	String creditAppNum;
	String creditStatus;
	String orderNum;
	String locationCode;
	String email;
	String smsDestination;
	String safeTechSessionId;
	String isOrderAlreadySubmitted;
	String globalId;
	String customerType;
	private String big6MasterId;
	private String big6OutletId;
	private Integer attempts3DS;
	private Integer cards3DS;
	private String originalCreditApprovalNumber;
	private String purchaseOrderNumber;
	private boolean paperlessIndicator;
	private String paperLessEmail;
	private boolean serviceWriteRequired;
	
	OrderWriteDNISOrderData dnisOrderData;
	private String mtnFlow;
	private String indirectDepletionType;
	private boolean isIsReadOrder;

}
