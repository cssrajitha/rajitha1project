package onevz.soe.prepay.adaptor.checkout.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.od.error.EcommValidationError;
import onevz.soe.od.model.VZWPrepayPaymentVO;
import onevz.soe.od.model.VZWPrepayRefillCardPayloadVO;
import onevz.soe.od.model.VZWPrepayRefillCardVO;
import onevz.soe.prepay.adaptor.checkout.constants.PrepayAdaptorCheckoutConstants;
import onevz.soe.prepay.adaptor.checkout.model.bpm.response.orderwrite.OrderWriteResponse;
import onevz.soe.prepay.adaptor.checkout.model.payment.request.AddRefillCardODRequest;
import onevz.soe.prepay.adaptor.checkout.model.payment.request.ValidateCardCXPRequest;
import onevz.soe.prepay.adaptor.checkout.model.payment.response.ValidateCardPaymentCXPResponse;
import onevz.soe.prepay.adaptor.checkout.util.PrepayAdaptorCheckoutUtil;
import onevz.soe.prepay.payment.request.cxp.RefillCardCXPRequest;
import onevz.soe.prepay.payment.request.cxp.RefillCardRequestData;
import onevz.soe.prepay.payment.response.ErrorResponse;
import onevz.soe.prepay.payment.response.cxp.RefillCardCXPResponse;
import onevz.soe.prepay.payment.response.cxp.RefillCardResponseData;
import onevz.soe.prepay.payment.response.ui.RefillCardInfo;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import onevz.soe.wsclient.prepay.webclient.model.PrepaidAdaptorWebClientRequest;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;

@Service
public class PrepayAdaptorPaymentHelper {
	

    @Autowired
    private ObjectMapper mapper;
	
	@Autowired
	private PrepayAdaptorWebClient prepayBusinessCartWebclient;
	
	@Autowired
	private PrepayAdaptorWebClient prepayAdaptorWebClient;

	@Autowired
	PrepayCheckoutRedisHelper prepayCheckoutRedisHelper;
	
	@Value("${prepaidUpdatePayment}")
	private String prepaidUpdatePayment;

	@Value("${refillCardAddUrl}")
	private String addRefillCardUrl;

	@Value("${refillCardRemoveUrl}")
	private String removeRefillCardUrl;

	@Value("${refillCardRemoveAllUrl}")
	private String removeAllRefillCardsUrl;

	private static final Logger logger = LoggerFactory.getLogger(PrepayAdaptorPaymentHelper.class);
	
	public Mono<Object> getUpdatePayment(ServerHttpRequest httpRequest, ValidateCardCXPRequest request) {
		return prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)
				.doOnError(err -> logger.error("Failed and return error", err))
				.defaultIfEmpty("")
				.flatMap(redisData -> {					
					if (null == redisData || redisData.isEmpty()) {
						logger.error("Error in fetching redis data");
						return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new OrderWriteResponse()));
					} else {

						PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = new PrepaidAdaptorWebClientRequest();
						prepaidAdaptorWebClientRequest.setUrl(prepaidUpdatePayment);
						prepaidAdaptorWebClientRequest.setRequestBody(getRequestMapping(request));
						prepaidAdaptorWebClientRequest.setRequestType(HttpMethod.POST.toString());
						logger.info("updatePayment OD Request: Endpoint: {}, Request Body: {}, Request Headers: {}",prepaidAdaptorWebClientRequest.getUrl(),prepaidAdaptorWebClientRequest.getRequestBody(), prepaidAdaptorWebClientRequest.getHeader());
						return prepayAdaptorWebClient.getPrepayServiceResponse(httpRequest, prepaidAdaptorWebClientRequest)
								.doOnError(error -> logger.error("Failed to get response, check exception for details", error))
								.flatMap(responseEntity -> {
									ValidateCardPaymentCXPResponse validateCardPaymentCXPResponse = new ValidateCardPaymentCXPResponse();									
									if (!responseEntity.getStatusCode().is2xxSuccessful()) {
										logger.error("Error while calling endpoint: {} with status code: {}", prepaidAdaptorWebClientRequest.getUrl(), responseEntity.getStatusCode());
										return Mono.just(ResponseEntity.status(responseEntity.getStatusCode()).body(validateCardPaymentCXPResponse));
									} else {
										try {
											logger.info("UpdatePayment OD Response: {}, Status Code: {}",responseEntity.getBody(), responseEntity.getStatusCode());
											validateCardPaymentCXPResponse = mapper.readValue(responseEntity.getBody(), ValidateCardPaymentCXPResponse.class);
											logger.info("Validate Card Payment CXP Response: {}",validateCardPaymentCXPResponse);
										} catch (JsonProcessingException e) {
											logger.error("Error while mapping to service response", e);
										}
									}
									return Mono.just(ResponseEntity.status(responseEntity.getStatusCode()).body(validateCardPaymentCXPResponse));
								});
					}					
				});		
	}


	private Object getRequestMapping(ValidateCardCXPRequest request) {
		JSONObject data = new JSONObject();
		Map<String, String> creditCardInfo = new HashMap<>();
		Map<String, String> binData = new HashMap<>();
		creditCardInfo.put("creditCardNumber", request.getData().getPayment().getPaymentDetails().get(0).getCreditCardPayment().getCardNumber());
		creditCardInfo.put("creditCardVerificationNumber", "");
		creditCardInfo.put("creditCardType", request.getData().getPayment().getPaymentDetails().get(0).getCreditCardPayment().getCreditCardType());
		creditCardInfo.put("billingZipCode", request.getData().getPayment().getPaymentDetails().get(0).getCreditCardPayment().getCardAddressZip());
		creditCardInfo.put("creditCardExpMonth", "");
		creditCardInfo.put("creditCardExpYear", "");
		creditCardInfo.put("lastFourDigits", "");
		creditCardInfo.put("isCCPIEEncryptionSuccess", "");
		creditCardInfo.put("isAutoPay", "false");
		creditCardInfo.put("jwt", "");
		creditCardInfo.put("cardinalSetUpComplete", "true");
		binData.put("binProcessEventTime", ""+request.getData().getPayment().getPaymentDetails().get(0).getCreditCardPayment().getSecureInfo().getBinProcessEventTime());
		binData.put("binProcessEventSuccess", "");
		binData.put("binProcessEventTimedOut", "");
		data.append("creditCardInfo", creditCardInfo);
		data.append("binData", binData);
		data.append("BrowserJavaScriptEnabled","true");
		return data;
	}

	public Mono<ResponseEntity<RefillCardCXPResponse>> addRefillCard(ServerHttpRequest httpRequest, RefillCardCXPRequest refillCardCXPRequest){
		return prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)
				.doOnError(err -> logger.error("AddRefillCard: Failed to get the RedisData and returned error", err))
				.defaultIfEmpty("")
				.flatMap(response -> {
					if (StringUtilities.isNotEmptyOrNull(response)) {
						logger.info("AddRefillCard: Redis Data From Redis:: {}", response);
						PrepaidODRequestData prepaidODRequestData = null;
						try {
							prepaidODRequestData = mapper.readValue(response, PrepaidODRequestData.class);
						} catch (JsonProcessingException e) {
							logger.error("AddRefillCard: Failed to parse data from redis:", e);
							return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(buildRefillCardMiscErrorResponse(PrepayAdaptorCheckoutConstants.REFILLCARD_REDIS_FAILURE_PARSE_MSG)));
						}
						PrepaidAdaptorWebClientRequest prepaidLegacyServiceRequestForAddRefill = getPrepaidLegacyServiceRequestForAddRefill(refillCardCXPRequest, prepaidODRequestData);
						//return error if it is duplicate refillcard
						if(prepaidODRequestData.getRefillCardNumbers().values().contains( ((AddRefillCardODRequest)prepaidLegacyServiceRequestForAddRefill.getRequestBody()).getRefillCardNumber())){
							logger.error("AddRefillCard: Refill Card is already added to cart");
							RefillCardCXPResponse refillCardCXPResponseForAddRefill = buildRefillCardMiscErrorResponse(PrepayAdaptorCheckoutConstants.REFILLCARD_DUPLICATE_FAILURE_MSG);
							refillCardCXPResponseForAddRefill.getData().setStatus("200");
							return Mono.just(ResponseEntity.status(HttpStatus.OK).body(refillCardCXPResponseForAddRefill));
						}
						PrepaidODRequestData updatedPrepaidODRequestData = prepaidODRequestData;
						logger.info("Add Refill Card OD Request: Endpoint: {}, Request Body: {}, Request Headers: {}",prepaidLegacyServiceRequestForAddRefill.getUrl(),prepaidLegacyServiceRequestForAddRefill.getRequestBody(), prepaidLegacyServiceRequestForAddRefill.getHeader());
						return prepayAdaptorWebClient.getPrepayServiceResponse(httpRequest, prepaidLegacyServiceRequestForAddRefill)
								.doOnError(error -> logger.error("AddRefillCard: Failed to get response, check exception for details.", error))
								.flatMap(responseEntity -> {
									RefillCardCXPResponse addRrefillCardCXPResponse = null;
									VZWPrepayRefillCardVO  vzwPrepayRefillCardVO = null;
									try {
										logger.info("Add Refill Card OD Response: {}, Status Code: {}",responseEntity.getBody(), responseEntity.getStatusCode());
										vzwPrepayRefillCardVO = mapper.readValue(responseEntity.getBody(), VZWPrepayRefillCardVO.class);
										logger.info("Add Refill Card Response VO: {}",vzwPrepayRefillCardVO);
										if (!responseEntity.getStatusCode().is2xxSuccessful()) {
											logger.error("AddRefillCard: Error while calling endpoint: {} with status code: {}", prepaidLegacyServiceRequestForAddRefill.getUrl(), responseEntity.getStatusCode());
											addRrefillCardCXPResponse = buildRefillCardErrorResponse(vzwPrepayRefillCardVO);
										} else {
											if(! ("00".equalsIgnoreCase(vzwPrepayRefillCardVO.getStatus()) || "ok".equalsIgnoreCase(vzwPrepayRefillCardVO.getStatus()))){
												logger.error("AddRefillCard: Received Failure response from OD service: {}", vzwPrepayRefillCardVO.getStatus());
												addRrefillCardCXPResponse = buildRefillCardErrorResponse(vzwPrepayRefillCardVO);
												return Mono.just(ResponseEntity.status(responseEntity.getStatusCode()).body(addRrefillCardCXPResponse));
											}
											addRrefillCardCXPResponse = buildRefillCardResponse(vzwPrepayRefillCardVO);
											//upsert the refillcard information to redis
											AtomicReference<String> paymentGrpIdAtomic = new AtomicReference<>();
											addRrefillCardCXPResponse.getData().getRefillCardInfoList().stream()
													.filter(refillCardInfo -> refillCardInfo.getPincard().equals(refillCardCXPRequest.getData().getRefillCardNumber()))
													.findFirst().ifPresent(refillCardInfo -> paymentGrpIdAtomic.set(refillCardInfo.getPaymentGrpId()));
											RefillCardCXPResponse finalAddRefillCardCXPResponse = addRrefillCardCXPResponse;

											if (Objects.nonNull(addRrefillCardCXPResponse.getData()) && CollectionUtilities.isNotEmptyOrNull(addRrefillCardCXPResponse.getData().getRefillCardInfoList())
													&& StringUtilities.isNotEmptyOrNull(paymentGrpIdAtomic.get())) {
												updatedPrepaidODRequestData.getRefillCardNumbers().put(paymentGrpIdAtomic.get(), refillCardCXPRequest.getData().getRefillCardNumber());
												return prepayCheckoutRedisHelper.upsertDataIntoRedisAsStr(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA, updatedPrepaidODRequestData)
														.doOnError(err -> logger.error("AddRefillCard: Failed to update redis and return error ", err))
														.flatMap(redisUpdateResp -> {
															logger.info("AddRefillCard: PrepaidODRequestData From Redis after upsert::  {}", redisUpdateResp);
															return Mono.just(ResponseEntity.status(responseEntity.getStatusCode()).body(finalAddRefillCardCXPResponse));
														});
											}
										}
										return Mono.just(ResponseEntity.status(responseEntity.getStatusCode()).body(addRrefillCardCXPResponse));
									}catch (Exception ex){
										logger.error("AddRefillCard: Error while processing, calling endpoint: {} with status code: {}", prepaidLegacyServiceRequestForAddRefill.getUrl(), responseEntity.getStatusCode());
										return Mono.just(ResponseEntity.status(responseEntity.getStatusCode()).body(addRrefillCardCXPResponse));
									}
								});
					} else {
						logger.error("AddRefillCard: Error while fetching redis data, Redis response Empty");
						return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(buildRefillCardMiscErrorResponse(PrepayAdaptorCheckoutConstants.REFILLCARD_REDIS_FAILURE_MSG)));
					}
				});
	}

	public Mono<ResponseEntity<RefillCardCXPResponse>> removeRefillCard(ServerHttpRequest httpRequest, RefillCardCXPRequest refillCardCXPRequest){
		return prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)
				.doOnError(err -> logger.error("RemoveRefillCard: Failed to get the RedisData and returned error", err))
				.defaultIfEmpty("")
				.flatMap(response -> {
					if (StringUtilities.isNotEmptyOrNull(response)) {
						logger.info("RemoveRefillCard: Redis Data From Redis:: {}", response);
						PrepaidODRequestData redisData = null;
						PrepaidAdaptorWebClientRequest prepaidLegacyServiceRequest = null;
						try {
							redisData = mapper.readValue(response, PrepaidODRequestData.class);
							prepaidLegacyServiceRequest = getPrepaidLegacyServiceRequestForRemoveRefill(refillCardCXPRequest, redisData);
						} catch (Exception e) {
							logger.error("RemoveRefillCard: Failed to parse data from redis:", e);
							return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(buildRefillCardMiscErrorResponse(PrepayAdaptorCheckoutConstants.REFILLCARD_REDIS_FAILURE_PARSE_MSG)));
						}
						final PrepaidAdaptorWebClientRequest prepaidLegacyServiceRequestFinal = prepaidLegacyServiceRequest;
						PrepaidODRequestData updatedRedisData = redisData;
						logger.info("Remove Refill Card OD Request: Endpoint: {}, Request Body: {}, Request Headers: {}",prepaidLegacyServiceRequest.getUrl(),prepaidLegacyServiceRequest.getRequestBody(), prepaidLegacyServiceRequest.getHeader());

						return prepayAdaptorWebClient.getPrepayServiceResponse(httpRequest, prepaidLegacyServiceRequest, true)
								.doOnError(error -> logger.error("RemoveRefillCard: Failed to get response, check exception for details.", error))
								.flatMap(responseEntity -> {
									RefillCardCXPResponse refillCardCXPResponse = null;
									VZWPrepayRefillCardVO  prepayRefillCardVO = null;
									try {
										logger.info("Remove Refill Card OD Response: {}, Status Code: {}",responseEntity.getBody(), responseEntity.getStatusCode());
										prepayRefillCardVO = mapper.readValue(responseEntity.getBody(), VZWPrepayRefillCardVO.class);
										logger.info("Remove Refill Card Response VO: {}",prepayRefillCardVO);
										if (!responseEntity.getStatusCode().is2xxSuccessful()) {
											logger.error("RemoveRefillCard: Error while calling endpoint: {} with status code: {}", prepaidLegacyServiceRequestFinal.getUrl(), responseEntity.getStatusCode());
											refillCardCXPResponse = buildRefillCardErrorResponse(prepayRefillCardVO);
										} else {
											if(! ("00".equalsIgnoreCase(prepayRefillCardVO.getStatus()) || "ok".equalsIgnoreCase(prepayRefillCardVO.getStatus()))){
												refillCardCXPResponse = buildRefillCardErrorResponse(prepayRefillCardVO);
												return Mono.just(ResponseEntity.status(responseEntity.getStatusCode()).body(refillCardCXPResponse));
											}
											refillCardCXPResponse = buildRefillCardResponse(prepayRefillCardVO);
											//upsert the redis to remove refillcard info
											RefillCardCXPResponse finalRefillCardCXPResponse = refillCardCXPResponse;
											if (Objects.nonNull(refillCardCXPRequest.getData()) && StringUtilities.isNotEmptyOrNull(refillCardCXPRequest.getData().getPaymentGrpId())) {
												updatedRedisData.getRefillCardNumbers().remove(refillCardCXPRequest.getData().getPaymentGrpId());
												return prepayCheckoutRedisHelper.upsertDataIntoRedisAsStr(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA, updatedRedisData)
														.doOnError(err -> logger.error("RemoveRefillCard: Failed to update redis and return error", err))
														.flatMap(redisUpdateResp -> {
															logger.info("RemoveRefillCard: PrepaidODRequestData From Redis is updated:: {}", redisUpdateResp);
															return Mono.just(ResponseEntity.status(responseEntity.getStatusCode()).body(finalRefillCardCXPResponse));
														});
											}
										}
										return Mono.just(ResponseEntity.status(responseEntity.getStatusCode()).body(refillCardCXPResponse));
									}catch (Exception ex){
										logger.error("RemoveRefillCard: Error while processing, calling endpoint: {} with status code: {}", prepaidLegacyServiceRequestFinal.getUrl(), responseEntity.getStatusCode());
										return Mono.just(ResponseEntity.status(responseEntity.getStatusCode()).body(refillCardCXPResponse));
									}
								});
					} else {
						logger.error("RemoveRefillCard: Error while fetching redis data");
						return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(buildRefillCardMiscErrorResponse(PrepayAdaptorCheckoutConstants.REFILLCARD_REDIS_FAILURE_MSG)));
					}
				});
	}

	public Mono<ResponseEntity<RefillCardCXPResponse>> removeAllRefillCards(ServerHttpRequest httpRequest){
		return prepayCheckoutRedisHelper.getDataFromRedisAsString(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA)
				.doOnError(err -> logger.error("RemoveAllRefillCards: Failed to get the RedisData and returned error", err))
				.defaultIfEmpty("")
				.flatMap(response -> {
					if (StringUtilities.isNotEmptyOrNull(response)) {
						logger.info("RemoveAllRefillCards: Redis Data From Redis:: {}", response);
						PrepaidODRequestData prepaidODRequestData = null;
						PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = null;
						try {
							prepaidODRequestData = mapper.readValue(response, PrepaidODRequestData.class);
							prepaidAdaptorWebClientRequest = getPrepaidLegacyServiceRequestForRemoveAllRefillCards(prepaidODRequestData);
						} catch (Exception e) {
							logger.error("RemoveAllRefillCards: Failed to parse data from redis:", e);
							return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(buildRefillCardMiscErrorResponse(PrepayAdaptorCheckoutConstants.REFILLCARD_REDIS_FAILURE_PARSE_MSG)));
						}
						final PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequestFinal = prepaidAdaptorWebClientRequest;
						PrepaidODRequestData updatedRedisData = prepaidODRequestData;
						logger.info("Remove Refill Card OD Request: Endpoint: {}, Request Body: {}, Request Headers: {}",prepaidAdaptorWebClientRequest.getUrl(),prepaidAdaptorWebClientRequest.getRequestBody(), prepaidAdaptorWebClientRequest.getHeader());

						return prepayAdaptorWebClient.getPrepayServiceResponse(httpRequest, prepaidAdaptorWebClientRequest)
								.doOnError(error -> logger.error("RemoveAllRefillCards: Failed to get response, check exception for details.", error))
								.flatMap(responseEntity -> {
									RefillCardCXPResponse removeAllRefillCardsCXPResponse = null;
									VZWPrepayRefillCardVO  vzwPrepayRefillCardVOForRemoveAll = null;
									try {
										logger.info("Remove All Refill Card OD Response: {}, Status Code: {}",responseEntity.getBody(), responseEntity.getStatusCode());
										vzwPrepayRefillCardVOForRemoveAll = mapper.readValue(responseEntity.getBody(), VZWPrepayRefillCardVO.class);
										logger.info("Remove All Refill Card Response VO: {}",vzwPrepayRefillCardVOForRemoveAll);
										if (!responseEntity.getStatusCode().is2xxSuccessful()) {
											logger.error("RemoveAllRefillCards: Error while calling endpoint: {} with status code: {}", prepaidAdaptorWebClientRequestFinal.getUrl(), responseEntity.getStatusCode());
											removeAllRefillCardsCXPResponse = buildRefillCardErrorResponse(vzwPrepayRefillCardVOForRemoveAll);
										} else {
											if(! ("00".equalsIgnoreCase(vzwPrepayRefillCardVOForRemoveAll.getStatus()) || "ok".equalsIgnoreCase(vzwPrepayRefillCardVOForRemoveAll.getStatus()))){
												removeAllRefillCardsCXPResponse = buildRefillCardErrorResponse(vzwPrepayRefillCardVOForRemoveAll);
												return Mono.just(ResponseEntity.status(responseEntity.getStatusCode()).body(removeAllRefillCardsCXPResponse));
											}
											RefillCardCXPResponse finalRemoveAllRefillCardsCXPResponse = buildRefillCardResponse(vzwPrepayRefillCardVOForRemoveAll);
											updatedRedisData.setRefillCardNumbers(new HashMap<>());
											return prepayCheckoutRedisHelper.upsertDataIntoRedisAsStr(PrepayAdaptorCheckoutConstants.PREPAY_OD_REQUEST_DATA, updatedRedisData)
													.doOnError(err -> logger.error("RemoveAllRefillCards: Failed to update redis and return error", err))
													.flatMap(redisUpdateResp -> {
														logger.info("RemoveAllRefillCards: PrepaidODRequestData From Redis is updated:: {}", redisUpdateResp);
														return Mono.just(ResponseEntity.status(responseEntity.getStatusCode()).body(finalRemoveAllRefillCardsCXPResponse));
													});
										}
										return Mono.just(ResponseEntity.status(responseEntity.getStatusCode()).body(removeAllRefillCardsCXPResponse));
									}catch (Exception ex){
										logger.error("RemoveAllRefillCards: Error while processing, calling endpoint: {} with status code: {}", prepaidAdaptorWebClientRequestFinal.getUrl(), responseEntity.getStatusCode());
										return Mono.just(ResponseEntity.status(responseEntity.getStatusCode()).body(removeAllRefillCardsCXPResponse));
									}
								});
					} else {
						logger.error("RemoveAllRefillCards: Error while fetching redis data");
						return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(buildRefillCardMiscErrorResponse(PrepayAdaptorCheckoutConstants.REFILLCARD_REDIS_FAILURE_MSG)));
					}
				});
	}

	private PrepaidAdaptorWebClientRequest getPrepaidLegacyServiceRequestForRemoveAllRefillCards(PrepaidODRequestData prepaidODRequestData) {
		PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = new PrepaidAdaptorWebClientRequest();
		prepaidAdaptorWebClientRequest.setUrl(removeAllRefillCardsUrl);
		prepaidAdaptorWebClientRequest.setRequestType(HttpMethod.GET.toString());
		String flow = Objects.nonNull(prepaidODRequestData) && CollectionUtilities.isNotEmptyOrNull(prepaidODRequestData.getLines())?prepaidODRequestData.getLines().get(prepaidODRequestData.getCurr_line()-1).getFlow():PrepayAdaptorCheckoutConstants.NSE;
		logger.info("Flow name of latest line in RemoveAll Refill cards Service Request: {}",flow);
		prepaidAdaptorWebClientRequest.setHeader(PrepayAdaptorCheckoutUtil.getPrepayODServiceCommonHeaders(prepaidODRequestData,flow));
		return prepaidAdaptorWebClientRequest;
	}

	private PrepaidAdaptorWebClientRequest getPrepaidLegacyServiceRequestForRemoveRefill(RefillCardCXPRequest request, PrepaidODRequestData prepaidODRequestData) throws UnsupportedEncodingException {
		PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = new PrepaidAdaptorWebClientRequest();
		prepaidAdaptorWebClientRequest.setUrl(removeRefillCardUrl + URLEncoder.encode(Optional.ofNullable(request).map(req -> Optional.ofNullable(req.getData()).orElse(new RefillCardRequestData())).map(RefillCardRequestData::getPaymentGrpId).orElse(""), "UTF-8"));
		prepaidAdaptorWebClientRequest.setRequestType(HttpMethod.GET.toString());
		String flow = Objects.nonNull(prepaidODRequestData) && CollectionUtilities.isNotEmptyOrNull(prepaidODRequestData.getLines())?prepaidODRequestData.getLines().get(prepaidODRequestData.getCurr_line()-1).getFlow():PrepayAdaptorCheckoutConstants.NSE;
		logger.info("Flow name of latest line in Remove Refill cards Service Request: {}",flow);
		prepaidAdaptorWebClientRequest.setHeader(PrepayAdaptorCheckoutUtil.getPrepayODServiceCommonHeaders(prepaidODRequestData,flow));
		return prepaidAdaptorWebClientRequest;
	}

	private PrepaidAdaptorWebClientRequest getPrepaidLegacyServiceRequestForAddRefill(RefillCardCXPRequest request, PrepaidODRequestData prepaidODRequestData) {
		AddRefillCardODRequest addRefillCardODRequest = new AddRefillCardODRequest();
		addRefillCardODRequest.setRefillCardNumber(Optional.ofNullable(request).map(req->Optional.ofNullable(req.getData()).orElse(new RefillCardRequestData())).map(RefillCardRequestData::getRefillCardNumber).orElse(""));
		addRefillCardODRequest.setGRecaptchaResponse(Optional.ofNullable(request).map(req->Optional.ofNullable(req.getData()).orElse(new RefillCardRequestData())).map(RefillCardRequestData::getCaptcha).orElse(""));
		PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = new PrepaidAdaptorWebClientRequest();
		prepaidAdaptorWebClientRequest.setUrl(addRefillCardUrl);
		prepaidAdaptorWebClientRequest.setRequestBody(addRefillCardODRequest);
		prepaidAdaptorWebClientRequest.setRequestType(HttpMethod.POST.toString());
		String flow = Objects.nonNull(prepaidODRequestData) && CollectionUtilities.isNotEmptyOrNull(prepaidODRequestData.getLines())?prepaidODRequestData.getLines().get(prepaidODRequestData.getCurr_line()-1).getFlow():PrepayAdaptorCheckoutConstants.NSE;
		logger.info("Flow name of latest line in Add Refill cards Service Request: {}",flow);
		prepaidAdaptorWebClientRequest.setHeader(PrepayAdaptorCheckoutUtil.getPrepayODServiceCommonHeaders(prepaidODRequestData,flow));
		return prepaidAdaptorWebClientRequest;
	}

	private RefillCardCXPResponse buildRefillCardResponse(VZWPrepayRefillCardVO prepayRefillCardVO){
		RefillCardCXPResponse refillCardCXPResponse = new RefillCardCXPResponse();
		RefillCardResponseData refillCardResponseData = new RefillCardResponseData();
		Optional.ofNullable(prepayRefillCardVO)
				.map(refillCardVO -> Optional.ofNullable(refillCardVO.getPayload()).orElse(new VZWPrepayRefillCardPayloadVO()))
				.map(vzwPrepayRefillCardPayloadVO -> Optional.ofNullable(vzwPrepayRefillCardPayloadVO.getPageData()).orElse(new VZWPrepayPaymentVO()))
				.map(vzwPrepayPaymentVO -> Optional.ofNullable(vzwPrepayPaymentVO.getPaymentGrpIdList()).orElse(new ArrayList<>()))
				.ifPresent(vzwPrepayRefillCardPaymentVOList -> {
					List<RefillCardInfo> refillCardInfoList = new ArrayList<>();
					vzwPrepayRefillCardPaymentVOList.stream().forEach(vzwPrepayRefillCardPaymentVO -> {
						RefillCardInfo refillCardInfo = new RefillCardInfo();
						refillCardInfo.setPaymentGrpId(vzwPrepayRefillCardPaymentVO.getPaymentGrpId());
						refillCardInfo.setBalance(vzwPrepayRefillCardPaymentVO.getBalance());
						refillCardInfo.setPincard(vzwPrepayRefillCardPaymentVO.getPincard());
						refillCardInfo.setAmounApplied(vzwPrepayRefillCardPaymentVO.getAmounApplied());
						refillCardInfoList.add(refillCardInfo);
					});
					refillCardResponseData.setRefillCardInfoList(refillCardInfoList);

				});
		Optional.ofNullable(prepayRefillCardVO)
				.map(refillCardVO -> Optional.ofNullable(refillCardVO.getPayload()).orElse(new VZWPrepayRefillCardPayloadVO()))
				.map(vzwPrepayRefillCardPayloadVO -> Optional.ofNullable(vzwPrepayRefillCardPayloadVO.getPageData()).orElse(new VZWPrepayPaymentVO()))
						.ifPresent(vzwPrepayPaymentVO ->refillCardResponseData.setRemainDue(vzwPrepayPaymentVO.getRemainingDue()));

		refillCardResponseData.setStatus(Optional.ofNullable(prepayRefillCardVO).map(VZWPrepayRefillCardVO::getStatus).orElse("ok"));
		refillCardCXPResponse.setData(refillCardResponseData);
		return refillCardCXPResponse;
	}

	private RefillCardCXPResponse buildRefillCardErrorResponse(VZWPrepayRefillCardVO errorResponse){
		RefillCardCXPResponse refillCardErrCXPResponse = new RefillCardCXPResponse();
		Optional.ofNullable(errorResponse)
				.map(errResp->Optional.ofNullable(errorResponse.getErrors()).orElse(new EcommValidationError()))
				.map(ecommValidationError -> Optional.ofNullable(ecommValidationError.getEcommApiErrorList()).orElse(new ArrayList<>()))
				.ifPresent(ecommApiErrors -> {
					//iterate over apierrors and form the cxprespon
					List<ErrorResponse> errorResponseList = new ArrayList<>();
					ecommApiErrors.stream().forEach(ecommApiError -> {
						ErrorResponse cxpErrResp = new ErrorResponse();
						cxpErrResp.setName(PrepayAdaptorCheckoutConstants.REFILLCARD_FAILURE_NAME);
						cxpErrResp.setId(ecommApiError.getStatusCode());
						cxpErrResp.setMessage(ecommApiError.getMessage());
						cxpErrResp.setErrorCategory(PrepayAdaptorCheckoutConstants.REFILLCARD_FAILURE_SYSTEM);
						errorResponseList.add(cxpErrResp);
					});
					refillCardErrCXPResponse.setErrors(errorResponseList);
				});
		//ErrorMap check(Captch errors)
		if(null!=errorResponse && null!=errorResponse.getErrorMap() && CollectionUtilities.isNotEmptyOrNull(errorResponse.getErrorMap().keySet())){
			List<ErrorResponse> errorResponseList = new ArrayList<>();
			errorResponse.getErrorMap().keySet().stream().forEach(key -> {
				ErrorResponse cxpErrResp = new ErrorResponse();
				cxpErrResp.setName(PrepayAdaptorCheckoutConstants.REFILLCARD_FAILURE_NAME);
				cxpErrResp.setId(key);
				cxpErrResp.setMessage(errorResponse.getErrorMap().get(key));
				cxpErrResp.setErrorCategory(PrepayAdaptorCheckoutConstants.REFILLCARD_FAILURE_SYSTEM);
				errorResponseList.add(cxpErrResp);
			});
			refillCardErrCXPResponse.setErrors(errorResponseList);
		}

		RefillCardResponseData refillCardResponseData = new RefillCardResponseData();
		refillCardResponseData.setStatus(Optional.ofNullable(errorResponse).map(VZWPrepayRefillCardVO::getStatus).orElse("500"));
		refillCardErrCXPResponse.setData(refillCardResponseData);
		return refillCardErrCXPResponse;
	}

	private RefillCardCXPResponse buildRefillCardMiscErrorResponse(String errorMsg){
		RefillCardCXPResponse refillCardErrCXPResponse = new RefillCardCXPResponse();
		List<ErrorResponse> errorResponseList = new ArrayList<>();
		ErrorResponse cxpErrResp = new ErrorResponse();
		cxpErrResp.setName(PrepayAdaptorCheckoutConstants.REFILLCARD_FAILURE_NAME);
		cxpErrResp.setId("01");
		cxpErrResp.setMessage(errorMsg);
		cxpErrResp.setErrorCategory(PrepayAdaptorCheckoutConstants.REFILLCARD_FAILURE_SYSTEM);
		errorResponseList.add(cxpErrResp);
		refillCardErrCXPResponse.setErrors(errorResponseList);
		RefillCardResponseData refillCardResponseData = new RefillCardResponseData();
		refillCardResponseData.setStatus("500");
		refillCardErrCXPResponse.setData(refillCardResponseData);
		return refillCardErrCXPResponse;
	}

}
