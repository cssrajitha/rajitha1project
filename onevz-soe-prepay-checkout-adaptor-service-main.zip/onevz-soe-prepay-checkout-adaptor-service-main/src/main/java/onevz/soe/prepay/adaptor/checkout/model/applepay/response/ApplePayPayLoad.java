package onevz.soe.prepay.adaptor.checkout.model.applepay.response;

import lombok.Data;

@Data
public class ApplePayPayLoad {

	private ApplePayPageData pageData;
}
