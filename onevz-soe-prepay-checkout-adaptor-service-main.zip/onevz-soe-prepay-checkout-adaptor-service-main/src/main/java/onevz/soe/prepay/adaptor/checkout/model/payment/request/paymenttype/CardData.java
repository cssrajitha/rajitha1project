package onevz.soe.prepay.adaptor.checkout.model.payment.request.paymenttype;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import onevz.soe.validation.constraints.NotEmpty;

import java.util.List;

/**
 * Developed By: Rativardhan Singh Sengar
 * 
 * Last Modified 10/24/19 1:39 PM
 * Copyright (c) 2019. All right reserved
 * @author sengara
 * 
 * POJO class.
 *
 */
@Getter
@Setter
@NoArgsConstructor
public class CardData {
	@NotEmpty(message = MessageConstants.EMPTY_CARD_NUMBER)
	private String cardNumber;
	
	private String appleAccountID;
	
	@JsonInclude(JsonInclude.Include.NON_NULL) //ignore null field on this property only
	//@NotEmpty(message = MessageConstants.EMPTY_CARD_EXP_MONTH)
	private String cardExpMonth;
	@JsonInclude(JsonInclude.Include.NON_NULL) //ignore null field on this property only
	//@NotEmpty(message = MessageConstants.EMPTY_CARD_EXP_YEAR)
	private String cardExpYear;
	@JsonInclude(JsonInclude.Include.NON_NULL) //ignore null field on this property only
	private String cardExpDate;
	@NotEmpty(message = MessageConstants.EMPTY_ENCRYPTED_CARD_DATA)
	private String encryptedCardData;
	private String encryptedCardData2;
	
	//@NotEmpty(message = MessageConstants.EMPTY_ENCRYPT_TYPE) //it can be optional for swipe-card
	private String encryptType;
	
	//@Zipcode(message = "cardAddressZip is either invalid or empty")
	private String cardAddressZip;
	//@NotEmpty(message = MessageConstants.EMPTY_CARD_TYPE)
	private String creditCardType;
	
	private String safeTechSessionId;
	private String ipAddresss;
	
	@JsonInclude(JsonInclude.Include.NON_NULL) //ignore null field on this property only
	private BinData binData;
	@JsonInclude(JsonInclude.Include.NON_NULL) //ignore null field on this property only
	private BinData secureInfo;
	@JsonInclude(JsonInclude.Include.NON_NULL) //ignore null field on this property only
	private EmvRequestData emvRequestData;
	private CardAdditionalInfo cardAdditionalInfo;
	
	private SwipeRequest swipeRequest;
	private String walletType;
	private String creditAppNumber;
	private boolean verizonIssuedCard;
	private List<SplitPaymentInfo> splitPaymentInfo;
}
