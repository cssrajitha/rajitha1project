package onevz.soe.prepay.adaptor.checkout.util;

import onevz.soe.checkout.model.Line;
import onevz.soe.checkout.model.ProcessMTNListNSE;
import onevz.soe.checkout.request.bpm.UpdateLineSecurityInfoRequest;
import onevz.soe.checkout.response.bpm.*;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.common.model.PrepaidODRequestDataLines;
import onevz.soe.prepay.adaptor.checkout.constants.PrepayAdaptorCheckoutConstants;
import onevz.soe.prepay.adaptor.checkout.model.updatelinesecurityinfo.request.UpdateLineSecurityInfoPrepayOdRequest;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.bpm.model.ServiceHeader;
import onevz.soe.wsclient.bpm.model.request.ContextInfo;
import onevz.soe.wsclient.bpm.model.response.AvailablePaths;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.stream.Collectors;

public class PrepayUpdateLineSecurityInfoFormatterUtil {

    private PrepayUpdateLineSecurityInfoFormatterUtil(){

    }
	
	private static final Logger logger = LoggerFactory.getLogger(PrepayUpdateLineSecurityInfoFormatterUtil.class);

    public static UpdateLineSecurityInfoPrepayOdRequest formatLineSecurityInfoRequest(UpdateLineSecurityInfoRequest request, PrepaidODRequestData redisData) {
        UpdateLineSecurityInfoPrepayOdRequest updateLineSecurityInfoPrepayOdRequest = new UpdateLineSecurityInfoPrepayOdRequest();
        Optional<Line> requestLines = request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().stream().findFirst();
        String requestMtn = requestLines.orElse(new Line()).getMtn();
        List<PrepaidODRequestDataLines> filterRedisLine = redisData.getLines().stream().filter(lines->lines.getMtn().equalsIgnoreCase(requestMtn)).collect(Collectors.toList());
        String lineItemId = filterRedisLine.get(0).getLineItemId();
        logger.info("Line Item ID to be updated for Account Security Pin: {}",lineItemId);
        updateLineSecurityInfoPrepayOdRequest.setDeviceLineItemId(lineItemId);
        updateLineSecurityInfoPrepayOdRequest.setLineSecurityPin(requestLines.orElse(new Line()).getLineSecurityPin());
        updateLineSecurityInfoPrepayOdRequest.setSecurityQuestion(requestLines.orElse(new Line()).getSecurityQuestion());
        updateLineSecurityInfoPrepayOdRequest.setSecurityAnswer(requestLines.orElse(new Line()).getSecurityAnswer());
        updateLineSecurityInfoPrepayOdRequest.setPieEncryptionSuccess(requestLines.orElse(new Line()).isPieEncryptionSuccess());
        return updateLineSecurityInfoPrepayOdRequest;
    }

    public static UpdateLineSecurityInfoResponse formatUpdateLineSecurityInfoResponse(PrepaidODRequestData redisData, UpdateLineSecurityInfoRequest request) {
        UpdateLineSecurityInfoResponse updateLineSecurityInfoResponse = new UpdateLineSecurityInfoResponse();
        updateLineSecurityInfoResponse.setServiceHeader(getServiceHeader(request));
        updateLineSecurityInfoResponse.setServiceBody(getServiceBody(request,redisData));
        return updateLineSecurityInfoResponse;
    }

    private static ServiceHeader getServiceHeader(UpdateLineSecurityInfoRequest request) {
        ServiceHeader serviceHeader = new ServiceHeader();
        serviceHeader.setStatusMsg(PrepayAdaptorCheckoutConstants.PREPAY_CHECKOUT_SERVICES_HEADER_STATUS_MSG_SUCCESS);
        serviceHeader.setStatusCode(PrepayAdaptorCheckoutConstants.PREPAY_CHECKOUT_SERVICES_HEADER_STATUS_CODE_SUCCESS);
        serviceHeader.setClientId(request.getServiceHeader().getClientId());
        serviceHeader.setCorrelationId(request.getServiceHeader().getCorrelationId());
        serviceHeader.setSessionId(request.getServiceHeader().getSessionId());
        serviceHeader.setServiceName(request.getServiceHeader().getServiceName());
        serviceHeader.setUserId(request.getServiceHeader().getUserId());
        return serviceHeader;
    }

    private static UpdateLineSecurityInfoServiceBody getServiceBody(UpdateLineSecurityInfoRequest request, PrepaidODRequestData redisData) {
        UpdateLineSecurityInfoServiceBody updateLineSecurityInfoResponseBody = new UpdateLineSecurityInfoServiceBody();
        updateLineSecurityInfoResponseBody.setServiceResponse(getServiceResponse(request,redisData));
        return  updateLineSecurityInfoResponseBody;
    }

    private static UpdateLineSecurityInfoServiceResponse getServiceResponse(UpdateLineSecurityInfoRequest request, PrepaidODRequestData redisData) {
        UpdateLineSecurityInfoServiceResponse updateLineSecurityInfoServiceResponse = new UpdateLineSecurityInfoServiceResponse();
        updateLineSecurityInfoServiceResponse.setContext(getContext(request,redisData));
        return updateLineSecurityInfoServiceResponse;
    }

    private static UpdateLineSecurityInfoContext getContext(UpdateLineSecurityInfoRequest request, PrepaidODRequestData redisData) {
        UpdateLineSecurityInfoContext updateLineSecurityInfoContext = new UpdateLineSecurityInfoContext();
        
        UpdateLineSecurityInfoCartInfo cartInfo = new UpdateLineSecurityInfoCartInfo();
        UpdateLineSecurityInfoCustomerInfo customerInfo = new UpdateLineSecurityInfoCustomerInfo();
        ContextInfo contextInfo = new ContextInfo();
        ProcessMTNListNSE processMtnNSE = new ProcessMTNListNSE();
        String requestMtn = request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).getMtn();
        
        customerInfo.setAccountNumber(request.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getAccountNumber());
        customerInfo.setCartCreator(request.getServiceHeader().getSessionId());
        customerInfo.setRegisterNumber(request.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getRegisterNumber());
        customerInfo.setProcessingMTN(nextProcessingMtn(requestMtn, redisData));
        customerInfo.setGlobalId(request.getServiceHeader().getSessionId());
        customerInfo.setCustomerType(request.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCustomerType());
        
        contextInfo.setCallReason(Objects.nonNull(request.getServiceBody().getServiceRequest().getContext().getContextInfo())?request.getServiceBody().getServiceRequest().getContext().getContextInfo().getCallReason():"");
        AvailablePaths availablePath = new AvailablePaths();
        if(Objects.nonNull(redisData)) {
            if (redisData.isAccountPinAssignedtoAllLines()) {

                if(redisData.isLoggedIn()){
                    contextInfo.setProcessStep(PrepayAdaptorCheckoutConstants.NEW_PLANS_PROCESS_STEP);
                    availablePath.setPath(PrepayAdaptorCheckoutConstants.NEW_PLANS_PROCESS_STEP);
                } else {

                    List<String> nonBYODLines = redisData.getLines().stream().filter(line -> (null != line.getSimId() || line.isESimEnabledDevice() || line.isESimOnly()))
                            .map(filteredLines -> filteredLines.getMtn()).collect(Collectors.toList());

                    List<String> linesWithAccessories = redisData.getLines().stream().filter(line -> (null != line.getAccessorySkuIds() && line.getAccessorySkuIds().size() > 0))
                            .map(filteredLines -> filteredLines.getMtn()).collect(Collectors.toList());

                    Optional<PrepaidODRequestDataLines> numberShareLines = redisData.getLines().stream().filter
                            (line -> line.isSmartWatch() && "28445".equals(line.getPlanSorId())).findFirst();

                    List<PrepaidODRequestDataLines> smartWatchOnCart=redisData.getLines().stream().filter(lines->lines.isSmartWatch() && StringUtilities.isNotEmptyOrNull(lines.getPlanSorId()) && lines.getPlanSorId().equals("28445")).collect(Collectors.toList());
                    List<PrepaidODRequestDataLines> smartPhoneOnCart=redisData.getLines().stream().filter(lines->lines.isSmartPhone()).collect(Collectors.toList());

                    if(numberShareLines.isPresent() && (!(CollectionUtils.size(smartWatchOnCart)==1 && CollectionUtils.size(smartPhoneOnCart)==1 && (!smartPhoneOnCart.stream().filter(lines-> Arrays.stream(smartWatchOnCart.get(0).getNumbershareEligibleOS().split(",")).anyMatch(eligibleOS->eligibleOS.contains(lines.getOsType()))).collect(Collectors.toList()).isEmpty())))){
                        contextInfo.setProcessStep(PrepayAdaptorCheckoutConstants.NUMBER_SHARE);
                        availablePath.setPath(PrepayAdaptorCheckoutConstants.NUMBER_SHARE);
                    }else if (nonBYODLines.size() != redisData.getLines().size() || linesWithAccessories.size() > 0) {
                        contextInfo.setProcessStep(PrepayAdaptorCheckoutConstants.SHIPMENT_PROCESS_STEP);
                        availablePath.setPath(PrepayAdaptorCheckoutConstants.SHIPMENT_PROCESS_STEP);
                    }else {
                        contextInfo.setProcessStep(PrepayAdaptorCheckoutConstants.PAYMENT_PROCESS_STEP);
                        availablePath.setPath(PrepayAdaptorCheckoutConstants.PAYMENT_PROCESS_STEP);
                    }
                }

            } else {
                contextInfo.setProcessStep(PrepayAdaptorCheckoutConstants.ACCOUNT_PIN_PROCESS_STEP);
                availablePath.setPath(PrepayAdaptorCheckoutConstants.ACCOUNT_PIN_PROCESS_STEP);
            }
        }
    	List<AvailablePaths> availablePaths = new ArrayList<>();
        availablePaths.add(availablePath);
        contextInfo.setAvailablePaths(availablePaths);
        contextInfo.setProcessAction("");
        contextInfo.setIntent(Objects.nonNull(request.getServiceBody().getServiceRequest().getContext().getContextInfo())?request.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent():"");
        updateLineSecurityInfoContext.setContextInfo(contextInfo);
        updateLineSecurityInfoContext.setCustomerInfo(customerInfo);
        updateLineSecurityInfoContext.setCartInfo(cartInfo);

        List <ProcessMTNListNSE> mtnList = new ArrayList<>();
        processMtnNSE.setMtn(nextProcessingMtn(requestMtn,redisData));
        mtnList.add(processMtnNSE);
        
        updateLineSecurityInfoContext.setProcessMTNList(mtnList);
        return updateLineSecurityInfoContext;
    }

   private static String nextProcessingMtn(String requestMtn, PrepaidODRequestData redisData) {
    	
    	logger.info("Mtn in Update Line Security Pin request: {}", requestMtn);
    	String nextMtn = "";
    	
    	if(Objects.nonNull(redisData)) {
    		
	    	if(redisData.isAccountPinAssignedtoAllLines()) {
                Optional<PrepaidODRequestDataLines> numberShareLines = redisData.getLines().stream().filter
                        (line -> line.isSmartWatch() && "28445".equals(line.getPlanSorId())).findFirst();
                if(numberShareLines.isPresent()){
                    nextMtn = numberShareLines.get().getMtn();
                } else {
                    nextMtn = redisData.getLines().get(0).getMtn();
                }
	    	} else {
	    		
	    		 List<String> remainingMtns = redisData.getLines().stream().filter(line -> !line.isSecurityPinAssigned())
	    		 							  .map(PrepaidODRequestDataLines::getMtn).collect(Collectors.toList());

	    		 nextMtn = remainingMtns.get(0);
	    	}
    	}
    	logger.info("Next Processing Mtn for UpdateLineSecurity Pin service: {}", nextMtn);
    	return nextMtn;
    }
}
