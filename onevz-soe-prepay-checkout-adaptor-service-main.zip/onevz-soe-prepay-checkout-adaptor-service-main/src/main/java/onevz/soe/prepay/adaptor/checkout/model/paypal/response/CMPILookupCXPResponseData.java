package onevz.soe.prepay.adaptor.checkout.model.paypal.response;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Developed By: Manikanta Kv Copyright (c) 2019. All right reserved
 * 
 * @author kvma
 * 
 * POJO class.
 *
 */
@Getter
@Setter
@NoArgsConstructor
public class CMPILookupCXPResponseData {
	private String sandboxUrl;
}
