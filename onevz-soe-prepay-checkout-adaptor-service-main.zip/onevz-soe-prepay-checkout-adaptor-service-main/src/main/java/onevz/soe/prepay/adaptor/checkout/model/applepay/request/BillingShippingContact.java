package onevz.soe.prepay.adaptor.checkout.model.applepay.request;

import java.util.List;

import lombok.Data;

@Data
public class BillingShippingContact {
	
	private List<String> addressLines;
	private String administrativeArea;
	private String country;
	private String countryCode;
	private String familyName;
	private String givenName;
	private String locality;
	private String postalCode;
	private String emailAddress;
	private String phoneNumber;
	private String subAdministrativeArea;
	private String subLocality;

}
