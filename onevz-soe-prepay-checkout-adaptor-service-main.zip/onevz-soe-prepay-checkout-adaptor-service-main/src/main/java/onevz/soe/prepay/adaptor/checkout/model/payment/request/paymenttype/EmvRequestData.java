package onevz.soe.prepay.adaptor.checkout.model.payment.request.paymenttype;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
/**
 * Developed By: Rativardhan Singh Sengar
 * 
 * Last Modified 10/24/19 1:39 PM
 * Copyright (c) 2019. All right reserved
 * @author sengara
 * 
 * POJO class
 */
@Getter
@Setter
@NoArgsConstructor
public class EmvRequestData {

	private String	entryMode;
	private String	_57;
	private String	_9F33;
	private String	_5A;
	private String	_5F25;
	private String	_4F;
	private String	_5F2D;
	private String	_50;
	private String	_9F39;
	private String	_5F34;
	private String	_5F24;
	private String	_5F30;
	private String	_5F28;
	private String	_5F20;
	private String	_9A;
	private String	_5F56;
	private String	_9F10;
	private String	_95;
	private String	_9B;
	private String	_9F26;
	private String	_9F36;
	private String	_9F27;
	private String	pinEntryStatus;
	private String	ksn;
	private String	crypto;
	private String	_9F37;
	private String	_9C;
	private String	_9F07;
	private String	_9F03;
	private String	_5F2A;
	private String	_9F02;
	private String	_9F1A;
	private String	_82;
	private String	_9F35;
	private String	_9F09;
	private String	_9F41;
	private String	_9F34;
	private String	_9F1F;
	private String	_9F06;
	private String	_9F11;
	private String	_9F66;
	private String	_9F6C;
	private String	_9F6E;
	private String	_9F21;
	private String	_84;
	private String	previousTxnBadChipRead;
	private String	emvAttached;
	private String	responseCode;
	private String	commandFailed;
	private String	_9F12;
	private String	_C2;
	private String	_8A;
	private String	_9F7C;
	private String	_9F5B;
	private String	posKey;
	private String	pinKeySerialNumber;
	private String	cardPin;
	private String	emvFallback;
	private String	track1;
	private String	track2;
	private String	track3;
	private String	maskedCardNumber;
	private String	expMonth;
	private String	expYear;
	private String	emvUsed;
	private String	cardTapped;
	@JsonProperty("Tag9F30")
	private String	Tag9F30;
	@JsonProperty("CVM")
	private String	CVM;
	@JsonProperty("TransCategoryCode")
	private String	TransCategoryCode;
	@JsonProperty("TransCurrencyCode")
	private String	TransCurrencyCode;
	@JsonProperty("InternalAuth")
	private String	InternalAuth;
	@JsonProperty("IssuerActionCode")
	private String	IssuerActionCode;
	@JsonProperty("IssuerActionCodeDenial")
	private String	IssuerActionCodeDenial;
	@JsonProperty("IssuerActionCodeOnline")
	private String	IssuerActionCodeOnline;
	@JsonProperty("AppVerNo")
	private String	AppVerNo;
	
	private String	_9F08;
	private String	_9F53;
	
	//Additional fields found in ms code
	private String _9F1E;
	private String _1001;
	private String _9000;
	
	private String fallbackEntryMode;
	private String debitCardKeySerialNumber;
	private String debitCardPin;
	private String emvDevice;
	
	private String pinBypassed;
	private String offlinePin; 
	// End of Additional fields
	
	private String emvDeviceCapability;
	
	private String aidName;
	

}
