package onevz.soe.prepay.adaptor.checkout.model.bpm.response.orderwrite;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.*;
import onevz.soe.wsclient.bpm.model.response.ServiceResponse;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(callSuper=true)
public class OrderWriteServiceResponse extends ServiceResponse {

	@JsonInclude(Include.NON_NULL)
	private OrderWriteContext orderWriteContext;

  
}
