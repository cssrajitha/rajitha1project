import React from 'react';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import { fireEvent, render, screen, waitFor } from '../../modules/test-utils/renderHelper';
import Header from './Header';
// import { expect } from '@jest/globals';

describe(' Header component render', () => {
  const navigateCombinedGridwall = jest.fn().mockName('navigateCombinedGridwall');
  const initialState = {
    data: {
      header: 'Hum Prequalification',
      mdn: '9998877665544',
    },
  };

  beforeEach(() => {
    render(<Header navigateCombinedGridwall={navigateCombinedGridwall} {...initialState} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('renders prequalification Header or not', () => {
    const dataTest = screen.getByTestId('preQualification-Header');
    expect(dataTest).toBeInTheDocument();
  });
  it('should click continue button', () => {
    const mockNavigate = jest.fn();
    jest.mock('react-router-dom', () => ({ useNavigate: () => mockNavigate }));
    const testContinueGridwall = screen.getByTestId('humPreQualificationClickable');
    expect(testContinueGridwall).toBeInTheDocument();
    fireEvent.click(testContinueGridwall);
    waitFor(() => expect(mockNavigate).toBeCalledWith(-1));
  });
});
