import React from 'react';
import styled from 'styled-components';
import { Input } from '@vds/inputs';
import { DropdownSelect } from '@vds/selects';
import { Button } from '@vds/buttons';
import { Body } from '@vds/typography';

const PrimaryUserInformationLabel = styled.div`
  margin-top: 100px;
  font-weight: bold;
  font-size: 16px;
  padding-bottom: 0.875rem !important;
`;
const EmailWrappers = styled.div`
  display: grid;
  grid-template-columns: repeat(2, minmax(33%, 40%));
  column-gap: 40px;

  .label {
    font-weight: bold;
    font-size: 15px !important;
  }
`;

const DropDownWrapper = styled.div`
  margin-top: 10px;
`;
const ValidateStyledButton = styled(Button)`
  margin: 0 auto;
`;

const ValidateButtonwrapper = styled.div`
  margin-top: 1.75rem !important;
`;

const InputWrapper = styled.div`
  width: 100%;
  margin: '10px 0px';
  max-width: 'none';
  margin-top: 10px;
`;

const OtherMDNWrapper = styled.div`
  margin-top: 20px;
  width: 40%;
`;

const PrimaryUserInformation = (props) => {
  return (
    <>
      <PrimaryUserInformationLabel data-testid='primaryUserInformationId'>
        <h2>{props?.secondTitle}</h2>
      </PrimaryUserInformationLabel>
      <div>
        <EmailWrappers>
          <div>
            <Body size='medium' bold>
              {props?.emailLabel}
            </Body>
            <InputWrapper>
              <Input
                id={'email'}
                data-testid='emailInput'
                type={'text'}
                placeholder={props?.emailLabel}
                error={props.formErrors.email ? true : false}
                errorText={props.formErrors.email ? props.formErrors.email : ''}
                value={props?.email ? props?.email : ''}
                name={'email'}
                onChange={props.handleEmailChange}
                aria-label={props?.email ? props?.email : 'please enter email Id'}
                className={'emailInput contains-PII'}
                containsPii
              />
            </InputWrapper>
          </div>
          <div>
            <Body size='medium' bold>
              {props?.registeredEmailLabel}
            </Body>
            {props.customerType !== 'N' && (
              <DropDownWrapper>
                {props?.registeredMdns && props?.registeredMdns.length > 0 ? (
                  <DropdownSelect
                    size='small'
                    className={'mdnDropdown contains-PII'}
                    value={props?.selectedMdn ? props?.selectedMdn : 'Select MDN'}
                    onChange={props.handleMdnsSelection}
                    data-testid='mdn-selection'
                  >
                    <option value='' selected>
                      {'Select MDN'}
                    </option>
                    {props?.registeredMdns.map((item) => (
                      <option key={item} style={{ width: '100%' }} value={item}>
                        {item}
                      </option>
                    ))}
                  </DropdownSelect>
                ) : (
                  <DropdownSelect size='small' label='Mdn not available' className={''} error={''} disabled={''}>
                    <option onSelect={null}>No items</option>
                  </DropdownSelect>
                )}
              </DropDownWrapper>
            )}
            {props.customerType === 'N' && (
              <InputWrapper>
                <Input
                  type={'text'}
                  data-testid='New-customer-otherMdn'
                  placeholder={props?.registeredEmailLabel}
                  error={props.formErrors.otherMdn ? true : false}
                  errorText={props.formErrors.otherMdn ? props.formErrors.otherMdn : ''}
                  value={props.otherMdn}
                  name={'otherMdn'}
                  onChange={props?.handleOtherMdnChange}
                />
              </InputWrapper>
            )}
          </div>
        </EmailWrappers>
        {props.selectedMdn === 'Other' ? (
          <OtherMDNWrapper>
            <Body size='medium' bold>
              {'Registered MDN  *'}
            </Body>
            <InputWrapper>
              <Input
                id={'email'}
                data-testid='emailInput'
                type={'text'}
                placeholder={'Registered MDN'}
                error={props.formErrors.otherMdn ? true : false}
                errorText={props.formErrors.otherMdn ? props.formErrors.otherMdn : ''}
                value={props.otherMdn}
                name={'email'}
                onChange={props.handleOtherMdnChange}
                aria-label={props?.formErrors?.otherMdn ? props?.formErrors?.otherMdn : 'please enter MDN'}
                className={'emailInput contains-PII'}
                containsPii
              />
            </InputWrapper>
          </OtherMDNWrapper>
        ) : null}
        <ValidateButtonwrapper>
          <ValidateStyledButton
            id='validateEmail'
            data-testid='validateEmail'
            onClick={props.emailMdnValidate}
            disabled={props.validateEmail() && props.validateRegisteredMdn()}
          >
            {' '}
            {props?.validateEmailBtnLabel}{' '}
          </ValidateStyledButton>
        </ValidateButtonwrapper>
      </div>
    </>
  );
};

export default PrimaryUserInformation;
