import React from 'react';
import styled from 'styled-components';
import { DropdownSelect } from '@vds/selects';
import { Button } from '@vds/buttons';
import { Body } from '@vds/typography';

const FlexWrap = styled.div`
  display: grid;
  grid-template-columns: repeat(2, minmax(33%, 40%));
  column-gap: 40px;
  margin-bottom: 30px;
`;
const DropDownWrapper = styled.div`
  margin-top: 10px;
`;
const ValidateStyledButton = styled(Button)`
  margin: 0 auto;
`;

const ValidateButtonwrapper = styled.div`
  margin-top: 1.75rem !important;
`;

const vehicleInfo = (props) => {
  console.log('props', props);
  return (
    <>
      <vehicleInfoLabel data-testid='VehicleInfoId'>
        <h2 tabIndex='0'>{props?.vehicleInfoTitle}</h2>
        <h3 className='headingMTN contains-PII'>
          {props.selectedMdn && props?.selectedMdn !== 'Other' ? props.selectedMdn : props.otherMdn} info
        </h3>
      </vehicleInfoLabel>
      <FlexWrap>
        <div>
          <Body size='medium' bold>
            {'Year'}
          </Body>
          <DropDownWrapper>
            <DropdownSelect
              size='small'
              data-testid='year-dropdown'
              className={'mdnDropdown contains-PII'}
              value={props?.selectedYear ? props?.selectedYear : 'Year'}
              onChange={(e) => props.handleYearChange(e)}
            >
              <option value='' selected>
                {'Year'}
              </option>
              {props?.getYears.map((item, index) => (
                <option key={index} style={{ width: '100%' }} value={item}>
                  {item}
                </option>
              ))}
            </DropdownSelect>
          </DropDownWrapper>
        </div>
        <div>
          <Body size='medium' bold>
            {'Make'}
          </Body>
          <DropDownWrapper>
            <DropdownSelect
              size='small'
              data-testid='make-dropdown'
              className={'mdnDropdown contains-PII'}
              value={props?.selectedMake ? props?.selectedMake : 'Select Make'}
              onChange={(e) => props.handleMakeChange(e)}
            >
              <option value='' selected>
                {'Make'}
              </option>
              {props?.getMakes.map((item, index) => (
                <option key={index} style={{ width: '100%' }} value={item}>
                  {item}
                </option>
              ))}
            </DropdownSelect>
          </DropDownWrapper>
        </div>
      </FlexWrap>
      <FlexWrap>
        <div>
          <Body size='medium' bold>
            {'Model'}
          </Body>
          <DropDownWrapper>
            <DropdownSelect
              size='small'
              data-testid='modal-dropdown'
              className={'mdnDropdown contains-PII'}
              value={props?.selectedModal ? props?.selectedModal : 'Select Modal'}
              onChange={(e) => props.handleModelChange(e)}
            >
              <option value='' selected>
                {'Model'}
              </option>
              {props?.getModels.map((item, index) => (
                <option key={index} style={{ width: '100%' }} value={item}>
                  {item}
                </option>
              ))}
            </DropdownSelect>
          </DropDownWrapper>
        </div>
        <div>
          <Body size='medium' bold>
            {'Color'}
          </Body>
          <DropDownWrapper>
            <DropdownSelect
              size='small'
              data-testid='color-dropdown'
              className={'mdnDropdown contains-PII'}
              value={props?.selectedColor ? props?.selectedColor : 'Select Color'}
              onChange={(e) => props.handleColorChange(e)}
            >
              <option value='' selected>
                {'Color'}
              </option>
              {props?.colors.map((item, index) => (
                <option key={index} style={{ width: '100%' }} value={item}>
                  {item}
                </option>
              ))}
            </DropdownSelect>
          </DropDownWrapper>
        </div>
      </FlexWrap>
      <ValidateButtonwrapper>
        <ValidateStyledButton
          id='validateVehicle'
          data-testid='validateHumComp'
          onClick={props.validateHumComp}
          disabled={!props?.continueVehicleValidateButton}
        >
          {'Validate Vehicle Info'}
        </ValidateStyledButton>
      </ValidateButtonwrapper>
    </>
  );
};

export default vehicleInfo;
