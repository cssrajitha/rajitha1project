import React from 'react';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import userEvent from '@testing-library/user-event';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import { fireEvent, render, screen, act, waitFor } from '../../modules/test-utils/renderHelper';
import HumPreQualification from './HumPreQualification';
import data from './_mocks_/HumPreQualificationResponse.json';
// import { expect } from '@jest/globals';

jest.mock(
  '../../modules/services/APIService/APIServiceHooks',
  () => {
    let index = 1;
    return {
      __esModule: true,
      ...jest.requireActual('../../modules/services/APIService/APIServiceHooks'),
      useLazyValidateEmailAddressQuery: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'Success',
              isUninitialized: false,
              isLoading: false,
              isSuccess: true,
              isError: false,
              isFetching: false,
              data: {
                data: {
                  retrieveURCforCartMtnList: {
                    mtnUpgradeReasonCodes: [
                      {
                        mtn: '2405085984',
                        upgradeReasonCodes: [
                          {
                            code: 'EA',
                            description: 'Device Payment Upgrade',
                            contractTermDetails: {
                              contractTerm: 'VERIZON_EDGE',
                            },
                            defaultReasonCode: true,
                          },
                        ],
                      },
                    ],
                  },
                },
              },
            },
          ];
        }
        return [() => {}, { data: {} }];
      },
    };
  },
  { virtual: true },
);

jest.mock('onevzsoemfecommon/Helpers', () => ({
  getQueryParamByName: jest.fn(() => ({
    isByodUpdate: true,
  })),
  getUIContextPath: jest.fn(() => {}),
  getUIContextPathBAU: jest.fn(() => {}),
}));

const handlers = [
  rest.post(`*/deviceconfigservice/telematics/validateEmailAddress`, (res, ctx) => {
    console.log('inside /deviceconfigservice/telematics/validateEmailAddress');
    return res(ctx.status(200), ctx.json(data.yearsResponse));
  }),
  rest.post(`*/deviceconfigservice/telematics/getYears`, (res, ctx) => {
    console.log('inside /deviceconfigservice/telematics/getYears');
    return res(ctx.status(200), ctx.json(data.yearsResponse));
  }),
  rest.post(`*/deviceconfigservice/telematics/getMakes`, (res, ctx) => {
    console.log('inside /deviceconfigservice/telematics/getMakes');
    return res(ctx.status(200), ctx.json(data.makesResponse));
  }),
  rest.post(`*/deviceconfigservice/telematics/getModels`, (res, ctx) => {
    console.log('inside /deviceconfigservice/telematics/getModels');
    return res(ctx.status(200), ctx.json(data.modelsResponse));
  }),
  rest.post(`*/deviceconfigservice/telematics/validateHumCompatibility`, (res, ctx) => {
    console.log('inside /deviceconfigservice/telematics/validateHumCompatibility');
    return res(ctx.status(200), ctx.json(data.validateHumCompatableResponse));
  }),
];
const server = setupServer(...handlers);
describe(' HumPreQualification component render', () => {
  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });
  afterAll(() => {
    server.close();
    sessionStorage.setItem('APIContext', '');
  });
  const handleEmailChange = jest.fn().mockName('handleEmailChange');
  const handleMdnsSelection = jest.fn().mockName('handleMdnsSelection');
  const validateEmail = jest.fn().mockName('validateEmail');
  const validateRegisteredMdn = jest.fn().mockName('validateRegisteredMdn');
  const handleOtherMdnChange = jest.fn().mockName('handleOtherMdnChange');
  const handleYearChange = jest.fn().mockName('handleYearChange');
  const handleMakeChange = jest.fn().mockName('handleMakeChange');
  const handleModelChange = jest.fn().mockName('handleModelChange');
  const handleColorChange = jest.fn().mockName('handleColorChange');
  const validateHumComp = jest.fn().mockName('validateHumComp');
  const navigateToPDPPAge = jest.fn();
  const emailValidateRequestBody = jest.fn();
  const getYearsRequestBody = jest.fn();
  const getMakesRequestBody = jest.fn();
  const getModelsRequestBody = jest.fn();
  const getHumCompatibilityBody = jest.fn().mockName('getHumCompatibilityBody');

  const props = {
    btnLabel: 'AddToCart',
    customerEmail: 'abc@verizon.com',
    channel: 'OMNI-RETAIL',
    activeMtn: '123456789',
    registeredMdns: ['123456789', '987654321'],
  };

  beforeEach(() => {
    Object.defineProperty(window, 'location', {
      value: new URL(
        'http://example.com/sales/assisted/new/hummodal.html?offerEligible=Y&activeMtn=2812530682&productId=dev9880019&defaultSku=VZ-0410-001-US',
      ),
      configurable: true,
    });
    render(
      <HumPreQualification
        handleOtherMdnChange={handleOtherMdnChange}
        handleEmailChange={handleEmailChange}
        handleMdnsSelection={handleMdnsSelection}
        validateEmail={validateEmail}
        validateRegisteredMdn={validateRegisteredMdn}
        handleYearChange={handleYearChange}
        handleMakeChange={handleMakeChange}
        handleModelChange={handleModelChange}
        handleColorChange={handleColorChange}
        validateHumComp={validateHumComp}
        navigateToPDPPAge={navigateToPDPPAge}
        emailValidateRequestBody={emailValidateRequestBody}
        EmailValidateResponse={data.validateEmailResponse}
        getYearsRequestBody={getYearsRequestBody}
        GetYearsResponse={data.yearsResponse}
        getModelsRequestBody={getModelsRequestBody}
        GetModelsResponse={data.modelsResponse}
        getMakesRequestBody={getMakesRequestBody}
        GetMakesResponse={data.makesResponse}
        getHumCompatibilityBody={getHumCompatibilityBody}
        HumCompatibilityResponse={data.validateHumCompatableResponse}
        {...props}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
  });

  test('renders HumPreQualification  or not', async () => {
    const dataTest = screen.getByTestId('HumPreQualificationId');
    expect(dataTest).toBeInTheDocument();
    const emailInputId = screen.getByTestId('emailInput');
    act(() => {
      fireEvent.change(emailInputId);
    });

    const validateEmailButton = screen.getByTestId('validateEmail');
    fireEvent.click(validateEmailButton);
    act(() => {
      fireEvent.change(validateEmailButton);
    });
  });
  test('renders VehicleInfo  or not', () => {
    const emailInputId = screen.getByTestId('emailInput');
    act(() => {
      fireEvent.change(emailInputId);
    });
  });
  test('renders VehicleInfo  or not', () => {
    const dataTest = screen.getByTestId('year-dropdown');
    const selectedyear = screen.getByRole('option', {
      name: '2006 item 20 of 2',
    });
    userEvent.selectOptions(dataTest, selectedyear);
    const makeDropdown = screen.getByTestId('make-dropdown');
    const selectedModal = screen.getByRole('option', {
      name: 'Xpeditor item 2 of 2',
    });
    const modalDropdown = screen.getByTestId('modal-dropdown');
    const selectedMake = screen.getByRole('option', {
      name: 'Acura item 2 of 2',
    });
    const colorDropdown = screen.getByTestId('color-dropdown');
    const optionSelected = screen.getByRole('option', {
      name: 'green item 6 of 2',
    });
    userEvent.selectOptions(makeDropdown, selectedMake);
    userEvent.selectOptions(modalDropdown, selectedModal);
    userEvent.selectOptions(colorDropdown, optionSelected);
    const dataTest1 = screen.getByTestId('validateHumComp');
    fireEvent.click(dataTest1);
  });
  test('renders VehicleInfo  or not', () => {
    const dataTest = screen.getByTestId('make-dropdown');
    act(() => {
      fireEvent.change(dataTest);
    });
  });
  test('renders VehicleInfo  or not', () => {
    const dataTest = screen.getByTestId('modal-dropdown');
    act(() => {
      fireEvent.change(dataTest);
    });
  });
  test('renders VehicleInfo  or not', () => {
    const dataTest = screen.getByTestId('color-dropdown');
    act(() => {
      fireEvent.change(dataTest);
    });
  });

  test('renders VehicleInfo  or not', () => {
    const dataTest = screen.getByTestId('validateHumComp');
    fireEvent.click(dataTest);
    act(() => {
      fireEvent.change(dataTest);
    });
  });

  test('renders VehicleInfo  or not', () => {
    const dataTest = screen.getByTestId('mdn-selection');
    act(() => {
      fireEvent.change(dataTest);
    });
  });
});

describe(' HumPreQualification component render', () => {
  beforeAll(() => {
    server.listen();
    window.history.pushState(
      {},
      'PDP',
      '/sales/assisted/new/device/pdp.html?activeMtn=5139074854&iSscan=true&deviceSKU=MQ8R3LL/A&isLocal=true&hummodal.html?offerEligible=Y&activeMtn=2812530682&productId=dev9880019&defaultSku=VZ-0410-001-US',
    );
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });
  afterAll(() => {
    server.close();
    sessionStorage.setItem('APIContext', '');
  });
  const handleEmailChange = jest.fn().mockName('handleEmailChange');
  const handleMdnsSelection = jest.fn().mockName('handleMdnsSelection');
  const validateEmail = jest.fn().mockName('validateEmail');
  const validateRegisteredMdn = jest.fn().mockName('validateRegisteredMdn');
  const handleOtherMdnChange = jest.fn().mockName('handleOtherMdnChange');
  const handleYearChange = jest.fn().mockName('handleYearChange');
  const handleMakeChange = jest.fn().mockName('handleMakeChange');
  const handleModelChange = jest.fn().mockName('handleModelChange');
  const handleColorChange = jest.fn().mockName('handleColorChange');
  const validateHumComp = jest.fn().mockName('validateHumComp');
  const navigateToPDPPAge = jest.fn();
  const emailValidateRequestBody = jest.fn();
  const getYearsRequestBody = jest.fn();
  const getMakesRequestBody = jest.fn();
  const getModelsRequestBody = jest.fn();
  const getHumCompatibilityBody = jest.fn().mockName('getHumCompatibilityBody');

  const props = {
    btnLabel: 'AddToCart',
    customerEmail: 'abc@verizon.com',
    channel: 'OMNI-RETAIL',
    activeMtn: '123456789',
    registeredMdns: ['123456789', '987654321'],
  };

  beforeEach(() => {
    Object.defineProperty(window, 'location', {
      value: new URL(
        'http://example.com/sales/assisted/new/hummodal.html?offerEligible=Y&activeMtn=2812530682&productId=dev9880019&defaultSku=VZ-0410-001-US',
      ),
      configurable: true,
    });
    render(
      <HumPreQualification
        handleOtherMdnChange={handleOtherMdnChange}
        handleEmailChange={handleEmailChange}
        handleMdnsSelection={handleMdnsSelection}
        validateEmail={validateEmail}
        validateRegisteredMdn={validateRegisteredMdn}
        handleYearChange={handleYearChange}
        handleMakeChange={handleMakeChange}
        handleModelChange={handleModelChange}
        handleColorChange={handleColorChange}
        validateHumComp={validateHumComp}
        navigateToPDPPAge={navigateToPDPPAge}
        emailValidateRequestBody={emailValidateRequestBody}
        EmailValidateResponse={data.validateEmailResponse}
        getYearsRequestBody={getYearsRequestBody}
        GetYearsResponse={data.yearsResponse}
        getModelsRequestBody={getModelsRequestBody}
        GetModelsResponse={data.modelsResponse}
        getMakesRequestBody={getMakesRequestBody}
        GetMakesResponse={data.makesResponse}
        getHumCompatibilityBody={getHumCompatibilityBody}
        HumCompatibilityResponse={data.validateHumCompatableResponse}
        customerType='N'
        {...props}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
  });

  test('renders HumPreQualification  or not', async () => {
    const dataTest = screen.getByTestId('HumPreQualificationId');
    expect(dataTest).toBeInTheDocument();
    const emailInputId = screen.getByTestId('emailInput');
    act(() => {
      fireEvent.change(emailInputId);
    });

    const validateEmailButton = screen.getByTestId('validateEmail');
    fireEvent.click(validateEmailButton);
    act(() => {
      fireEvent.change(validateEmailButton);
    });
  });
  test('renders HumPreQualification  or not', async () => {
    const dataTest = screen.getByTestId('HumPreQualificationId');
    expect(dataTest).toBeInTheDocument();
    const emailInputId = screen.getByTestId('emailInput');
    act(() => {
      fireEvent.change(emailInputId);
    });

    const validateEmailButton = screen.getByTestId('validateEmail');
    act(() => {
      fireEvent.click(validateEmailButton);
    });
  });
  test('renders VehicleInfo  or not', () => {
    const emailInputId = screen.getByTestId('emailInput');
    act(() => {
      fireEvent.change(emailInputId);
    });
  });
  test('renders VehicleInfo  or not', () => {
    const dataTest = screen.getByTestId('year-dropdown');
    act(() => {
      fireEvent.change(dataTest);
    });
  });
  test('renders VehicleInfo  or not', () => {
    const dataTest = screen.getByTestId('make-dropdown');
    act(() => {
      fireEvent.change(dataTest);
    });
  });
  test('renders VehicleInfo  or not', () => {
    const dataTest = screen.getByTestId('modal-dropdown');
    act(() => {
      fireEvent.change(dataTest);
    });
  });
  test('renders VehicleInfo  or not', () => {
    const dataTest = screen.getByTestId('color-dropdown');
    act(() => {
      fireEvent.change(dataTest);
    });
  });

  test('renders VehicleInfo  or not', () => {
    const dataTest = screen.getByTestId('validateHumComp');
    act(() => {
      fireEvent.change(dataTest);
    });
    fireEvent.click(dataTest);
  });

  test('renders VehicleInfo  or not', () => {
    const dataTest = screen.getByTestId('New-customer-otherMdn');
    waitFor(() => {
      fireEvent.change(dataTest);
    });
    fireEvent.change(dataTest, { target: { value: '123' } });
    fireEvent.change(dataTest, { target: { value: '123-456-7890' } });
    const validateEmailButton = screen.getByTestId('validateEmail');
    fireEvent.click(validateEmailButton);
    act(() => {
      fireEvent.change(validateEmailButton);
    });
  });
  test('renders VehicleInfo  or not', () => {
    const dataTest = screen.getByTestId('New-customer-otherMdn');
    waitFor(() => {
      fireEvent.change(dataTest, { target: { value: '9685679632' } });
    });
  });
  test('renders VehicleInfo  or not', () => {
    const dataTest = screen.getByTestId('New-customer-otherMdn');
    waitFor(() => {
      fireEvent.change(dataTest, { target: { value: '968EE7632' } });
    });
  });
  test('renders prequalification footer or not', () => {
    const mockNavigate = jest.fn();
    jest.mock('react-router-dom', () => ({ useNavigate: () => mockNavigate }));
    const dataTest = screen.getByTestId('hum-footer-button');
    expect(dataTest).toBeInTheDocument();
    act(() => {
      fireEvent.change(dataTest);
    });
  });
});

describe(' HumPreQualification component render', () => {
  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });
  afterAll(() => {
    server.close();
    sessionStorage.setItem('APIContext', '');
  });
  const handleEmailChange = jest.fn().mockName('handleEmailChange');
  const handleMdnsSelection = jest.fn().mockName('handleMdnsSelection');
  const validateEmail = jest.fn().mockName('validateEmail');
  const validateRegisteredMdn = jest.fn().mockName('validateRegisteredMdn');
  const handleOtherMdnChange = jest.fn().mockName('handleOtherMdnChange');
  const handleYearChange = jest.fn().mockName('handleYearChange');
  const handleMakeChange = jest.fn().mockName('handleMakeChange');
  const handleModelChange = jest.fn().mockName('handleModelChange');
  const handleColorChange = jest.fn().mockName('handleColorChange');
  const validateHumComp = jest.fn().mockName('validateHumComp');
  const navigateToPDPPAge = jest.fn();
  const emailValidateRequestBody = jest.fn();
  const getYearsRequestBody = jest.fn();
  const getMakesRequestBody = jest.fn();
  const getModelsRequestBody = jest.fn();
  const getHumCompatibilityBody = jest.fn().mockName('getHumCompatibilityBody');

  const props = {
    btnLabel: 'AddToCart',
    customerEmail: '',
    channel: 'OMNI-RETAIL',
    activeMtn: '123456789',
    registeredMdns: '',
    selectedMdn: '',
  };

  beforeEach(() => {
    Object.defineProperty(window, 'location', {
      value: new URL(
        'http://example.com/sales/assisted/new/hummodal.html?offerEligible=Y&activeMtn=2812530682&productId=dev9880019&defaultSku=VZ-0410-001-US',
      ),
      configurable: true,
    });
    render(
      <HumPreQualification
        handleOtherMdnChange={handleOtherMdnChange}
        handleEmailChange={handleEmailChange}
        handleMdnsSelection={handleMdnsSelection}
        validateEmail={validateEmail}
        validateRegisteredMdn={validateRegisteredMdn}
        handleYearChange={handleYearChange}
        handleMakeChange={handleMakeChange}
        handleModelChange={handleModelChange}
        handleColorChange={handleColorChange}
        validateHumComp={validateHumComp}
        navigateToPDPPAge={navigateToPDPPAge}
        emailValidateRequestBody={emailValidateRequestBody}
        EmailValidateResponse={data.validateEmailResponse}
        getYearsRequestBody={getYearsRequestBody}
        GetYearsResponse={data.yearsResponse}
        getModelsRequestBody={getModelsRequestBody}
        GetModelsResponse={data.modelsResponse}
        getMakesRequestBody={getMakesRequestBody}
        GetMakesResponse={data.makesResponse}
        getHumCompatibilityBody={getHumCompatibilityBody}
        HumCompatibilityResponse={data.validateHumCompatableResponse}
        customerType='N'
        {...props}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
  });

  test('renders HumPreQualification  or not', async () => {
    const dataTest = screen.getByTestId('HumPreQualificationId');
    expect(dataTest).toBeInTheDocument();
    const emailInputId = screen.getByTestId('emailInput');
    act(() => {
      fireEvent.change(emailInputId);
    });

    const validateEmailButton = screen.getByTestId('validateEmail');
    fireEvent.click(validateEmailButton);
    act(() => {
      fireEvent.change(validateEmailButton);
    });
  });
});

describe(' HumPreQualification component render', () => {
  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });
  afterAll(() => {
    server.close();
    sessionStorage.setItem('APIContext', '');
  });
  const handleEmailChange = jest.fn().mockName('handleEmailChange');
  const handleMdnsSelection = jest.fn().mockName('handleMdnsSelection');
  const validateEmail = jest.fn().mockName('validateEmail');
  const validateRegisteredMdn = jest.fn().mockName('validateRegisteredMdn');
  const handleOtherMdnChange = jest.fn().mockName('handleOtherMdnChange');
  const handleYearChange = jest.fn().mockName('handleYearChange');
  const handleMakeChange = jest.fn().mockName('handleMakeChange');
  const handleModelChange = jest.fn().mockName('handleModelChange');
  const handleColorChange = jest.fn().mockName('handleColorChange');
  const validateHumComp = jest.fn().mockName('validateHumComp');
  const navigateToPDPPAge = jest.fn();
  const emailValidateRequestBody = jest.fn();
  const getYearsRequestBody = jest.fn();
  const getMakesRequestBody = jest.fn();
  const getModelsRequestBody = jest.fn();
  const getHumCompatibilityBody = jest.fn().mockName('getHumCompatibilityBody');

  const props = {
    btnLabel: 'AddToCart',
    customerEmail: 'abcemail',
    channel: 'OMNI-RETAIL',
    activeMtn: '123456789',
    registeredMdns: '',
    selectedMdn: '',
  };

  beforeEach(() => {
    Object.defineProperty(window, 'location', {
      value: new URL(
        'http://example.com/sales/assisted/new/hummodal.html?offerEligible=Y&activeMtn=2812530682&productId=dev9880019&defaultSku=VZ-0410-001-US',
      ),
      configurable: true,
    });
    render(
      <HumPreQualification
        handleOtherMdnChange={handleOtherMdnChange}
        handleEmailChange={handleEmailChange}
        handleMdnsSelection={handleMdnsSelection}
        validateEmail={validateEmail}
        validateRegisteredMdn={validateRegisteredMdn}
        handleYearChange={handleYearChange}
        handleMakeChange={handleMakeChange}
        handleModelChange={handleModelChange}
        handleColorChange={handleColorChange}
        validateHumComp={validateHumComp}
        navigateToPDPPAge={navigateToPDPPAge}
        emailValidateRequestBody={emailValidateRequestBody}
        EmailValidateResponse={data.validateEmailResponse}
        getYearsRequestBody={getYearsRequestBody}
        GetYearsResponse={data.yearsResponse}
        getModelsRequestBody={getModelsRequestBody}
        GetModelsResponse={data.modelsResponse}
        getMakesRequestBody={getMakesRequestBody}
        GetMakesResponse={data.makesResponse}
        getHumCompatibilityBody={getHumCompatibilityBody}
        HumCompatibilityResponse={data.validateHumCompatableResponse}
        customerType='N'
        {...props}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
  });

  test('renders HumPreQualification  or not', async () => {
    const dataTest = screen.getByTestId('HumPreQualificationId');
    expect(dataTest).toBeInTheDocument();
    const emailInputId = screen.getByTestId('emailInput');
    act(() => {
      fireEvent.change(emailInputId);
    });
  });
});
