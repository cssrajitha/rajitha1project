import styled from 'styled-components';
import { Title } from '@vds/typography';
import { Icon } from '@vds/icons';
import { Line } from '@vds/lines';
import PropTypes from 'prop-types';
import { getUIContextPathBAU } from 'onevzsoemfecommon/Helpers';
import { useNavigate } from 'react-router-dom';
import { BackClickable } from '../CombinedGridwall/FlexGlobalStyledConstants';

const FlexBoxGrowOne = styled.div`
  display: flex;
  flex-grow: 1;
`;
const ShopWrapper = styled.div`
  padding: 1.5rem 0.5rem;
`;
const LineWrapper = styled.div`
  padding: 0 0rem;
`;
export const FlexAlignContainerItemsCenter = styled.div`
  display: flex;
  align-items: center;
  padding: 0 2rem;
  justify-content: space-between;
`;
const LineSeperator = styled.div`
  width: 1px;
  height: 27px;
  background: #000000;
  top: 1.5rem;
  position: relative;
`;
const MinimizeDisplayName = styled.div`
  white-space: nowrap;
  overflow: hidden;
  float: left;
  text-overflow: ellipsis;
`;

function Header(props) {
  const navigate = useNavigate();
  const { header, mdn } = props.data;

  const navigateCombinedGridwall = () => {
    navigate(`${getUIContextPathBAU()}/combinedgridwall.html?activeMtn=${mdn}`);
  };
  return (
    <>
      <FlexAlignContainerItemsCenter data-testid='preQualification-Header'>
        <FlexBoxGrowOne>
          <BackClickable
            data-testid='humPreQualificationClickable'
            onClick={navigateCombinedGridwall}
            tabIndex={0}
            role='button'
            data-track='humPreQualification-back'
          >
            <Icon name='left-caret' size='XLarge' medium='true' />
          </BackClickable>
          <LineSeperator />
          <ShopWrapper>
            <Title size='small' bold primitive='h1'>
              <MinimizeDisplayName>{header}</MinimizeDisplayName>
            </Title>
          </ShopWrapper>
        </FlexBoxGrowOne>
      </FlexAlignContainerItemsCenter>
      <LineWrapper>
        <Line type='secondary' />
      </LineWrapper>
    </>
  );
}
Header.propTypes = {
  data: PropTypes.shape({
    mdn: PropTypes.string,
    header: PropTypes.string,
  }),
};
export default Header;
