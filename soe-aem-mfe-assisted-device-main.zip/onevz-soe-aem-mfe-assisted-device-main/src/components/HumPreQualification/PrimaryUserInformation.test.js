import React from 'react';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import { fireEvent, render, screen, act } from '../../modules/test-utils/renderHelper';
import PrimaryUserInformation from './PrimaryUserInformation';
// import { expect } from '@jest/globals';

describe(' PrimaryUserInformation component render', () => {
  const handleEmailChange = jest.fn().mockName('handleEmailChange');
  const handleMdnsSelection = jest.fn().mockName('handleMdnsSelection');
  const validateEmail = jest.fn().mockName('validateEmail');
  const validateRegisteredMdn = jest.fn().mockName('validateRegisteredMdn');
  const handleOtherMdnChange = jest.fn().mockName('handleOtherMdnChange');

  const initialState = {
    secondTitle: 'Primary Information',
    emailLabel: 'Enter emailID',
    formErrors: {
      email: 'abc@verizon.com',
    },
    registeredEmailLabel: 'abc@verizon.com',
    registeredMdns: ['123456789', '987654321'],
    selectedMdn: '123456789',
    validateEmailBtnLabel: 'validateEmail',
  };

  beforeEach(() => {
    render(
      <PrimaryUserInformation
        handleOtherMdnChange={handleOtherMdnChange}
        handleEmailChange={handleEmailChange}
        handleMdnsSelection={handleMdnsSelection}
        validateEmail={validateEmail}
        validateRegisteredMdn={validateRegisteredMdn}
        {...initialState}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      }
    );
  });

  it('renders PrimaryUserInformation  or not', () => {
    const PrimaryUserInformation = screen.getByTestId('primaryUserInformationId');
    expect(PrimaryUserInformation).toBeInTheDocument();
  });
});

describe(' PrimaryUserInformation component render', () => {
  const handleEmailChange = jest.fn().mockName('handleEmailChange');
  const handleMdnsSelection = jest.fn().mockName('handleMdnsSelection');
  const validateEmail = jest.fn().mockName('validateEmail');
  const validateRegisteredMdn = jest.fn().mockName('validateRegisteredMdn');
  const handleOtherMdnChange = jest.fn().mockName('handleOtherMdnChange');

  const initialState = {
    email: 'abc@verizon.com',
    secondTitle: 'Primary Information',
    emailLabel: 'Enter emailID',
    formErrors: {
      email: 'abc@verizon.com',
    },
    registeredEmailLabel: 'abc@verizon.com',
    registeredMdns: [],
    selectedMdn: 'other',
    validateEmailBtnLabel: 'validateEmail',
    customerType: 'N',
  };

  beforeEach(() => {
    render(
      <PrimaryUserInformation
        handleOtherMdnChange={handleOtherMdnChange}
        handleEmailChange={handleEmailChange}
        handleMdnsSelection={handleMdnsSelection}
        validateEmail={validateEmail}
        validateRegisteredMdn={validateRegisteredMdn}
        {...initialState}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      }
    );
  });

  it('renders PrimaryUserInformation  or not', () => {
    const PrimaryUserInformation = screen.getByTestId('primaryUserInformationId');
    expect(PrimaryUserInformation).toBeInTheDocument();
    const dataTest = screen.getByTestId('emailInput');
    act(() => {
      fireEvent.change(dataTest);
    });
  });
});

describe(' PrimaryUserInformation component render', () => {
  const handleEmailChange = jest.fn().mockName('handleEmailChange');
  const handleMdnsSelection = jest.fn().mockName('handleMdnsSelection');
  const validateEmail = jest.fn().mockName('validateEmail');
  const validateRegisteredMdn = jest.fn().mockName('validateRegisteredMdn');
  const handleOtherMdnChange = jest.fn().mockName('handleOtherMdnChange');

  const initialState = {
    email: 'abc@verizon.com',
    secondTitle: 'Primary Information',
    emailLabel: 'Enter emailID',
    formErrors: {
      email: '',
    },
    registeredEmailLabel: 'abc@verizon.com',
    registeredMdns: [],
    selectedMdn: '',
    validateEmailBtnLabel: 'validateEmail',
  };

  beforeEach(() => {
    render(
      <PrimaryUserInformation
        handleOtherMdnChange={handleOtherMdnChange}
        handleEmailChange={handleEmailChange}
        handleMdnsSelection={handleMdnsSelection}
        validateEmail={validateEmail}
        validateRegisteredMdn={validateRegisteredMdn}
        {...initialState}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      }
    );
  });

  it('renders PrimaryUserInformation  or not', () => {
    const PrimaryUserInformation = screen.getByTestId('primaryUserInformationId');
    expect(PrimaryUserInformation).toBeInTheDocument();
    const dataTest = screen.getByTestId('emailInput');
    act(() => {
      fireEvent.change(dataTest);
    });
  });
});

describe(' PrimaryUserInformation component render', () => {
  const handleEmailChange = jest.fn().mockName('handleEmailChange');
  const handleMdnsSelection = jest.fn().mockName('handleMdnsSelection');
  const validateEmail = jest.fn().mockName('validateEmail');
  const validateRegisteredMdn = jest.fn().mockName('validateRegisteredMdn');
  const handleOtherMdnChange = jest.fn().mockName('handleOtherMdnChange');

  const initialState = {
    secondTitle: 'Primary Information',
    emailLabel: 'Enter emailID',
    formErrors: {
      email: 'abc@verizon.com',
    },
    registeredEmailLabel: 'abc@verizon.com',
    registeredMdns: ['123456789', '987654321', 'Other'],
    selectedMdn: 'Other',
    validateEmailBtnLabel: 'validateEmail',
  };

  beforeEach(() => {
    render(
      <PrimaryUserInformation
        handleOtherMdnChange={handleOtherMdnChange}
        handleEmailChange={handleEmailChange}
        handleMdnsSelection={handleMdnsSelection}
        validateEmail={validateEmail}
        validateRegisteredMdn={validateRegisteredMdn}
        {...initialState}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      }
    );
  });

  it('renders PrimaryUserInformation  or not', () => {
    const PrimaryUserInformation = screen.getByTestId('primaryUserInformationId');
    expect(PrimaryUserInformation).toBeInTheDocument();
  });
});

describe(' PrimaryUserInformation component render', () => {
  const handleEmailChange = jest.fn().mockName('handleEmailChange');
  const handleMdnsSelection = jest.fn().mockName('handleMdnsSelection');
  const validateEmail = jest.fn().mockName('validateEmail');
  const validateRegisteredMdn = jest.fn().mockName('validateRegisteredMdn');
  const handleOtherMdnChange = jest.fn().mockName('handleOtherMdnChange');

  const initialState = {
    secondTitle: 'Primary Information',
    emailLabel: 'Enter emailID',
    formErrors: {
      email: 'abc@verizon.com',
      otherMdn: 'error',
    },
    registeredEmailLabel: 'abc@verizon.com',
    registeredMdns: ['123456789', '987654321', 'Other'],
    selectedMdn: 'Other',
    validateEmailBtnLabel: 'validateEmail',
  };

  beforeEach(() => {
    render(
      <PrimaryUserInformation
        handleOtherMdnChange={handleOtherMdnChange}
        handleEmailChange={handleEmailChange}
        handleMdnsSelection={handleMdnsSelection}
        validateEmail={validateEmail}
        validateRegisteredMdn={validateRegisteredMdn}
        {...initialState}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      }
    );
  });

  it('renders PrimaryUserInformation  or not', () => {
    const PrimaryUserInformation = screen.getByTestId('primaryUserInformationId');
    expect(PrimaryUserInformation).toBeInTheDocument();
  });
});
describe(' PrimaryUserInformation component render', () => {
  const handleEmailChange = jest.fn().mockName('handleEmailChange');
  const handleMdnsSelection = jest.fn().mockName('handleMdnsSelection');
  const validateEmail = jest.fn().mockName('validateEmail');
  const validateRegisteredMdn = jest.fn().mockName('validateRegisteredMdn');
  const handleOtherMdnChange = jest.fn().mockName('handleOtherMdnChange');

  const initialState = {
    email: 'abc@verizon.com',
    secondTitle: 'Primary Information',
    emailLabel: 'Enter emailID',
    formErrors: {
      email: 'abc@verizon.com',
      otherMdn: 'error',
    },
    registeredEmailLabel: 'abc@verizon.com',
    registeredMdns: [],
    selectedMdn: 'other',
    validateEmailBtnLabel: 'validateEmail',
    customerType: 'N',
    otherMdn: 'other',
  };

  beforeEach(() => {
    render(
      <PrimaryUserInformation
        handleOtherMdnChange={handleOtherMdnChange}
        handleEmailChange={handleEmailChange}
        handleMdnsSelection={handleMdnsSelection}
        validateEmail={validateEmail}
        validateRegisteredMdn={validateRegisteredMdn}
        {...initialState}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      }
    );
  });

  it('renders PrimaryUserInformation  or not', () => {
    const PrimaryUserInformation = screen.getByTestId('primaryUserInformationId');
    expect(PrimaryUserInformation).toBeInTheDocument();
  });
});
