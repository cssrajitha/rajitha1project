import React from 'react';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import { fireEvent, render, screen, act } from '../../modules/test-utils/renderHelper';
import Footer from './Footer';
// import { expect } from '@jest/globals';

describe(' footer component render', () => {
  const navigateToPDPPAge = jest.fn();
  const props = {
    btnLabel: 'AddToCart',
    continueButtonEnable: false,
  };

  beforeEach(() => {
    render(<Footer navigateToPDPPAge={navigateToPDPPAge} {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('renders prequalification footer or not', () => {
    const dataTest = screen.getByTestId('prequalification-footer');
    expect(dataTest).toBeInTheDocument();
  });
});

describe(' footer component render', () => {
  const navigateToPDPPAge = jest.fn();
  const props = {
    btnLabel: 'AddToCart',
    continueButtonEnable: false,
  };

  beforeEach(() => {
    render(<Footer navigateToPDPPAge={navigateToPDPPAge} {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('renders prequalification footer or not', () => {
    const dataTest = screen.getByTestId('prequalification-footer');
    expect(dataTest).toBeInTheDocument();
  });

  test('renders prequalification footer or not', () => {
    const dataTest = screen.getByTestId('hum-footer-button');
    expect(dataTest).toBeInTheDocument();
    act(() => {
      fireEvent.change(dataTest);
    });
  });
});
