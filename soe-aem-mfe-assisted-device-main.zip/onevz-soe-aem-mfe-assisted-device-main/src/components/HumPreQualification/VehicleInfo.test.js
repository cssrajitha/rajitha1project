import React from 'react';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import { fireEvent, render, screen, act } from '../../modules/test-utils/renderHelper';
import VehicleInfo from './VehicleInfo';
// import { expect } from '@jest/globals';

describe(' VehicleInfo component render', () => {
  const handleYearChange = jest.fn().mockName('handleYearChange');
  const handleMakeChange = jest.fn().mockName('handleMakeChange');
  const handleModelChange = jest.fn().mockName('handleModelChange');
  const handleColorChange = jest.fn().mockName('handleColorChange');
  const validateHumComp = jest.fn().mockName('validateHumComp');

  const props = {
    vehicleInfoTitle: 'Primary Information',
    emailLabel: 'Enter emailID',
    formErrors: {
      email: 'abc@verizon.com',
    },
    registeredEmailLabel: 'abc@verizon.com',
    getYears: ['2019', '2020'],
    getMakes: ['Honda', 'Acura'],
    getModels: ['Ex', 'Sport'],
    colors: ['blue', 'red'],
    selectedMdn: '123456789',
    validateEmailBtnLabel: 'validateEmail',
  };

  beforeEach(() => {
    render(
      <VehicleInfo
        handleYearChange={handleYearChange}
        handleMakeChange={handleMakeChange}
        handleModelChange={handleModelChange}
        handleColorChange={handleColorChange}
        validateHumComp={validateHumComp}
        {...props}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      }
    );
  });

  it('renders VehicleInfo  or not', () => {
    const VehicleInfoID = screen.getByTestId('VehicleInfoId');
    expect(VehicleInfoID).toBeInTheDocument();
  });
});

describe(' VehicleInfo component render', () => {
  const handleYearChange = jest.fn().mockName('handleYearChange');
  const handleMakeChange = jest.fn().mockName('handleMakeChange');
  const handleModelChange = jest.fn().mockName('handleModelChange');
  const handleColorChange = jest.fn().mockName('handleColorChange');
  const validateHumComp = jest.fn().mockName('validateHumComp');

  const props = {
    vehicleInfoTitle: 'Primary Information',
    emailLabel: 'Enter emailID',
    formErrors: {
      email: 'abc@verizon.com',
    },
    registeredEmailLabel: 'abc@verizon.com',
    getYears: ['2019', '2020'],
    getMakes: ['Honda', 'Acura'],
    getModels: ['Ex', 'Sport'],
    colors: ['blue', 'red'],
    selectedMdn: 'Other',
    validateEmailBtnLabel: 'validateEmail',
    selectedYear: '2019',
    selectedMake: 'Honda',
    selectedModal: 'Sport',
    selectedColor: 'red',
    continueVehicleValidateButton: true,
  };

  beforeEach(() => {
    render(
      <VehicleInfo
        handleYearChange={handleYearChange}
        handleMakeChange={handleMakeChange}
        handleModelChange={handleModelChange}
        handleColorChange={handleColorChange}
        validateHumComp={validateHumComp}
        {...props}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      }
    );
  });

  it('renders VehicleInfo  or not', () => {
    const dataTest = screen.getByTestId('year-dropdown');
    act(() => {
      fireEvent.change(dataTest);
    });
  });
  it('renders VehicleInfo  or not', () => {
    const dataTest = screen.getByTestId('make-dropdown');
    act(() => {
      fireEvent.change(dataTest);
    });
  });
  it('renders VehicleInfo  or not', () => {
    const dataTest = screen.getByTestId('modal-dropdown');
    act(() => {
      fireEvent.change(dataTest);
    });
  });
  it('renders VehicleInfo  or not', () => {
    const dataTest = screen.getByTestId('color-dropdown');
    act(() => {
      fireEvent.change(dataTest);
    });
  });

  it('renders VehicleInfo  or not', () => {
    const dataTest = screen.getByTestId('validateHumComp');
    act(() => {
      fireEvent.change(dataTest);
    });
  });
});
