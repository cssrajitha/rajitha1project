import styled from 'styled-components';
import { Button } from '@vds/buttons';
import PropTypes from 'prop-types';

const FooterArea = styled.div`
  margin-top: 1.75rem !important;
  padding: 0 8px 16px;
  background-color: rgb(255, 255, 255);
  bottom: 0px;
  display: flex;
  flex-wrap: wrap;
  width: 252px;
  margin: auto;
  button:enabled:focus {
    color: white;
  }
`;
const ValidateStyledButton = styled(Button)`
  margin: 0 auto;
`;

function Footer(props) {
  const { btnLabel, continueButtonEnable, navigateToPDPPAge } = props;
  return (
    <>
      <FooterArea data-testid='prequalification-footer'>
        <ValidateStyledButton
          data-testid='hum-footer-button'
          width='154px'
          size='large'
          inverted
          secondary
          onClick={navigateToPDPPAge}
          disabled={!continueButtonEnable}
          data-track={btnLabel}
        >
          {btnLabel}
        </ValidateStyledButton>
      </FooterArea>
    </>
  );
}
export default Footer;

Footer.propTypes = {
  btnLabel: PropTypes.string,
};
