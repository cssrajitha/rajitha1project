import React, { useEffect, useState } from 'react';
import styled from 'styled-components';
import { getQueryParamByName, getUIContextPathBAU, isValidEmail } from 'onevzsoemfecommon/Helpers';
import { useNavigate } from 'react-router-dom';
import Header from './Header';
import PrimaryUserInformation from './PrimaryUserInformation';
import Footer from './Footer';
import VehicleInfo from './VehicleInfo';

const HeaderWraper = styled.div`
  position: fixed;
  background-color: white;
  width: 100%;
  top: 0;
  z-index: 9;
  max-width: 1133px;
`;
const FooterWrapper = styled.div`
  border-bottom: 1px solid #d8dada;
  border-top: 1px solid #d8dada;
`;
const HumPreQualificationWrapper = styled.div`
  padding: 0.875rem 6.3125rem 0.875rem 6.3125rem !important;
`;

const HumPreQualification = (props) => {
  const navigate = useNavigate();
  const {
    emailValidateRequestBody,
    EmailValidateResponse,
    getYearsRequestBody,
    GetYearsResponse,
    getModelsRequestBody,
    GetModelsResponse,
    getMakesRequestBody,
    GetMakesResponse,
    getHumCompatibilityBody,
    HumCompatibilityResponse,
  } = props;
  const [formErrors, setFormErrors] = useState({ otherMdn: null, email: null });
  const [selectedEmail, setSelectedEmail] = useState(props?.customerEmail);
  const [selectedMdn, setSelectedMdn] = useState('');
  const [otherMdn, setOtherMdn] = useState('');
  const [selectedYear, setSelectedYear] = useState('');
  const [selectedMake, setSelectedMake] = useState('');
  const [selectedModal, setSelectedModal] = useState('');
  const [selectedColor, setSelectedColor] = useState('');
  const [emailValidated, setEmailValidated] = useState(false);
  const [getYaers, setYears] = useState([]);
  const [getVehicleMakes, setVehicleMakes] = useState([]);
  const [getVehicleModals, setVehicleModals] = useState([]);
  const [continueVehicleValidateButton, setContinueVehicleValidateButton] = useState(false);
  const [continueButtonEnable, setContinueBuutonEnable] = useState(false);

  useEffect(() => {
    if (EmailValidateResponse?.data) {
      const reqBody = {
        channel: props.channel,
      };
      setEmailValidated(EmailValidateResponse?.data?.payload?.valid);
      getYearsRequestBody({
        body: reqBody,
      });
    }
  }, [EmailValidateResponse, EmailValidateResponse?.status]);

  useEffect(() => {
    if (GetYearsResponse?.data) {
      setYears(GetYearsResponse?.data?.payload?.years);
    }
  }, [GetYearsResponse]);

  useEffect(() => {
    if (GetMakesResponse?.data) {
      setVehicleMakes(GetMakesResponse?.data?.payload?.makes);
    }
  }, [GetMakesResponse]);

  useEffect(() => {
    if (GetModelsResponse?.data) {
      setVehicleModals(GetModelsResponse?.data?.payload?.models);
    }
  }, [GetModelsResponse]);

  useEffect(() => {
    if (HumCompatibilityResponse?.data) {
      setContinueBuutonEnable(true);
    }
  }, [HumCompatibilityResponse]);

  const headerData = {
    header: 'HUM line pre-qualification',
    mdn: props?.activeMtn,
  };

  const validateMdn = (value) => {
    let isValid = false;
    isValid = value.match(/^\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})$/);
    return isValid ? null : 'Please enter valid MDN';
  };
  /* istanbul ignore next */
  const handleEmailChange = (e) => {
    const email = e.target.value;
    setSelectedEmail(email);
    if (!isValidEmail(email)) {
      setFormErrors({ ...formErrors, email: 'Please enter valid email' });
    } else {
      setFormErrors({ ...formErrors, email: null });
    }
    resetVehicleContent();
  };
  const handleMdnsSelection = (e) => {
    const mdns = e.target.value;
    setSelectedMdn(mdns);
    resetVehicleContent();
  };
  const handleOtherMdnChange = (e) => {
    const phone = e.target.value;
    setOtherMdn(phone);
    setFormErrors({ ...formErrors, otherMdn: validateMdn(phone) });
  };
  const validateEmail = () => {
    /* istanbul ignore else */
    if (selectedEmail === '') {
      return true;
    }
    /* istanbul ignore else */
    if (selectedMdn === 'Other' || selectedMdn === '') {
      return true;
    }
    /* istanbul ignore else */
    if (formErrors.email !== null) {
      return true;
    }
  };
  /* istanbul ignore next */
  const validateRegisteredMdn = () => {
    if (formErrors.email !== null) {
      return true;
    }
    if (otherMdn && selectedEmail !== '') {
      if (formErrors.otherMdn === null) {
        return false;
      }
      return true;
    } if (selectedEmail && props?.customerType === 'N' && otherMdn && formErrors.otherMdn === null) {
      return false;
    } 
      return true;
    
  };
  const emailMdnValidate = () => {
    const formData = {
      email: selectedEmail,
      mdn: selectedMdn !== 'Other' ? selectedMdn : otherMdn,
      channel: props.channel,
    };
    emailValidateRequestBody({ body: formData });
  };
  const handleMakeChange = (value) => {
    setSelectedMake(value.target.value);
    const reqBody = {
      year: selectedYear,
      channel: props.channel,
      make: value.target.value,
    };
    getModelsRequestBody({
      body: reqBody,
    });
  };
  const handleModelChange = (value) => {
    setSelectedModal(value.target.value);
  };
  const handleColorChange = (value) => {
    setSelectedColor(value.target.value);
    /* istanbul ignore if */
    if (selectedYear && selectedMake && selectedModal) {
      setContinueVehicleValidateButton(true);
    }
  };

  const handleYearChange = (value) => {
    setSelectedYear(value.target.value);
    const reqBody = {
      year: value.target.value,
      channel: props.channel,
    };
    getMakesRequestBody({
      body: reqBody,
    });
  };
  const validateHumComp = () => {
    const reqBody = {
      year: selectedYear,
      channel: props.channel,
      make: selectedMake,
      model: selectedModal,
    };
    getHumCompatibilityBody({ body: reqBody });
  };

  const resetVehicleContent = () => {
    setEmailValidated(false);
    setSelectedYear('');
    setSelectedMake('');
    setSelectedModal('');
    setSelectedColor('');
    setYears([]);
    setVehicleMakes([]);
    setVehicleModals([]);
    setContinueVehicleValidateButton(false);
    setContinueBuutonEnable(false);
  };
  /* istanbul ignore next */
  const navigateToPDPPAge = () => {
    const productId = getQueryParamByName('productId') ? getQueryParamByName('productId') : '';
    const activeMtn = getQueryParamByName('activeMtn') ? `&activeMtn=${  getQueryParamByName('activeMtn')}` : '';
    const isBundledGW = getQueryParamByName('isBundledGW') ? '&isBundledGW=true' : '';
    const defaultSku = getQueryParamByName('defaultSku') ? `&defaultSku=${  getQueryParamByName('defaultSku')}` : '';

    const isLocal = Boolean(getQueryParamByName('isLocal'));
    const scanFromLanding = Boolean(getQueryParamByName('scanFromLanding'));
    const deviceSKU = getQueryParamByName('deviceSKU');
    const deviceId = getQueryParamByName('deviceId');
    if (isLocal === true && scanFromLanding === true) {
      navigate(
        `${getUIContextPathBAU()}/product-detail.html?deviceSKU=${deviceSKU}&isLocal=true&deviceId=${deviceId}&scanFromLanding=${scanFromLanding}&isHumDevice=true`,
      );
    } else {
      navigate(
        `${getUIContextPathBAU()}/product-detail.html?productId=${  productId  }${isBundledGW  }${defaultSku  }${activeMtn}`,
      );
    }
  };
  return (
    <>
      <HeaderWraper data-testid='HumPreQualificationId'>
        <Header data={headerData} />
      </HeaderWraper>
      <HumPreQualificationWrapper>
        <PrimaryUserInformation
          secondTitle="Primary user information"
          emailLabel="Email"
          email={selectedEmail}
          handleEmailChange={handleEmailChange}
          registeredEmailLabel="Registered MDN"
          customerType={props?.customerType}
          registeredMdns={props?.registeredMdns || []}
          handleMdnsSelection={handleMdnsSelection}
          selectedMdn={selectedMdn}
          formErrors={formErrors}
          otherMdn={otherMdn}
          handleOtherMdnChange={handleOtherMdnChange}
          validateEmailBtnLabel="Validate Email"
          emailMdnValidate={emailMdnValidate}
          validateEmail={validateEmail}
          validateRegisteredMdn={validateRegisteredMdn}
        />
        {emailValidated && (
          <VehicleInfo
            vehicleInfoTitle="Vehicle Info"
            selectedMdn={selectedMdn}
            otherMdn={otherMdn}
            handleMakeChange={handleMakeChange}
            handleColorChange={handleColorChange}
            handleModelChange={handleModelChange}
            handleYearChange={handleYearChange}
            selectedColor={selectedColor}
            selectedYear={selectedYear}
            selectedMake={selectedMake}
            selectedModal={selectedModal}
            getYears={getYaers}
            getMakes={getVehicleMakes}
            getModels={getVehicleModals}
            colors={['blue', 'red', 'orange', 'purple', 'green', 'yellow', 'white', 'black', 'silver']}
            validateHumComp={validateHumComp}
            continueVehicleValidateButton={continueVehicleValidateButton}
          />
        )}
      </HumPreQualificationWrapper>
      <FooterWrapper>
        <Footer
          btnLabel="Continue"
          continueButtonEnable={continueButtonEnable}
          navigateToPDPPAge={navigateToPDPPAge}
        />
      </FooterWrapper>
    </>
  );
};

export default HumPreQualification;
