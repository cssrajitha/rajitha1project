import React from 'react';
import '@testing-library/jest-dom';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import { fireEvent, render, screen, waitFor } from '../../../modules/test-utils/renderHelper';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import ProtectionGridwall from './ProtectionGridwall';
import { CHANNELS, setupChannel } from '../../../modules/test-utils/utils';
import ProtectionFeaturesResult from './__mocks__/getProtectionFeaturesmock.json';

// Mock the API hooks
jest.mock(
  'onevzsoemfecommon/APIService',
  () => {
    let index = 1;
    return {
      __esModule: true,
      ...jest.requireActual('onevzsoemfecommon/APIService'),
      useAddFeaturesMutation: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'Success',
              isUninitialized: false,
              isLoading: false,
              isSuccess: true,
              isError: true,
              isFetching: false,
              data: {
                status: 'Success',
                downPayment: 400,
                remainingMonthPrice: 300,
                firstMonthPrice: 200,
              },
            },
          ];
        }
        return [() => {}, { data: {} }];
      },
    };
  },
  { virtual: true },
);

const Test = (channel) => {
  setupChannel(channel);

  describe(`<ProtectionGridwall component -> ${channel}`, () => {
    const handlers = [
      rest.post(`*/deviceconfigservice/device-config/flexV2/getProtectionFeatures`, (req, res, ctx) =>
        res(ctx.status(200), ctx.json(ProtectionFeaturesResult)),
      ),
    ];
    const server = setupServer(...handlers);
    beforeAll(() => {
      server.listen();
    });
    afterAll(() => {
      server.close();
    });

    const defaultProps = {
      onBackClick: jest.fn(),
      activeMtn: '6308709368',
      selectedInsuranceForAIQuote: '',
      handleBackButton: jest.fn(),
    };

    test('should display protection cards when data is loaded', async () => {
      render(<ProtectionGridwall {...defaultProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      await waitFor(() => {
        expect(screen.getByText('Verizon Mobile Protect Multi-Device')).toBeInTheDocument();
        expect(screen.getByText('$68.00/mo')).toBeInTheDocument();
      });
    });

    test('should toggle protection selection when Select button is clicked', async () => {
      render(<ProtectionGridwall {...defaultProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      await waitFor(() => {
        expect(screen.getByText('Verizon Mobile Protect Multi-Device')).toBeInTheDocument();
      });

      const selectButtons = screen.getAllByText('Select');
      fireEvent.click(selectButtons[0]);

      // Check if the checkmark icon appears (selected state)
      await waitFor(() => {
        const selectedIcon = document.querySelector('svg path[d="M13.3346 4L6.0013 11.3333L2.66797 8"]');
        expect(selectedIcon).toBeInTheDocument();
      });
    });

    test('should deselect protection when clicking on selected protection', async () => {
      render(<ProtectionGridwall {...defaultProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      await waitFor(() => {
        expect(screen.getByText('Verizon Mobile Protect Multi-Device')).toBeInTheDocument();
      });

      const selectButtons = screen.getAllByText('Select');
      fireEvent.click(selectButtons[0]);

      await waitFor(() => {
        const selectedIcon = document.querySelector('svg path[d="M13.3346 4L6.0013 11.3333L2.66797 8"]');
        expect(selectedIcon).toBeInTheDocument();
      });

      // Click the selected protection to deselect
      const checkmarkButton = screen.getByRole('button', { name: 'Select protection' });
      fireEvent.click(checkmarkButton);

      await waitFor(() => {
        const selectButton = screen.getAllByText('Select')[0];
        expect(selectButton).toBeInTheDocument();
      });
    });

    test('should handle keyboard navigation on selected protection toggle', async () => {
      render(<ProtectionGridwall {...defaultProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      await waitFor(() => {
        expect(screen.getByText('Verizon Mobile Protect Multi-Device')).toBeInTheDocument();
      });

      const selectButtons = screen.getAllByText('Select');
      fireEvent.click(selectButtons[0]);

      await waitFor(() => {
        const checkmarkButton = screen.getByRole('button', { name: 'Select protection' });
        expect(checkmarkButton).toBeInTheDocument();
      });

      const checkmarkButton = screen.getByRole('button', { name: 'Select protection' });

      // Test Enter key
      fireEvent.keyDown(checkmarkButton, { key: 'Enter' });
      await waitFor(() => {
        expect(screen.getAllByText('Select')[0]).toBeInTheDocument();
      });

      // Select again
      fireEvent.click(screen.getAllByText('Select')[0]);
      await waitFor(() => {
        const checkmarkButton2 = screen.getByRole('button', { name: 'Select protection' });
        expect(checkmarkButton2).toBeInTheDocument();
      });

      // Test Space key
      const checkmarkButton2 = screen.getByRole('button', { name: 'Select protection' });
      fireEvent.keyDown(checkmarkButton2, { key: ' ' });
      await waitFor(() => {
        expect(screen.getAllByText('Select')[0]).toBeInTheDocument();
      });
    });

    test('should switch selection when selecting a different protection', async () => {
      render(<ProtectionGridwall {...defaultProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      await waitFor(() => {
        expect(screen.getByText('Verizon Mobile Protect Multi-Device')).toBeInTheDocument();
      });

      const selectButtons = screen.getAllByText('Select');

      // Select first protection
      fireEvent.click(selectButtons[0]);

      await waitFor(() => {
        const selectedIcon = document.querySelector('svg path[d="M13.3346 4L6.0013 11.3333L2.66797 8"]');
        expect(selectedIcon).toBeInTheDocument();
      });

      // Select second protection (should replace first)
      fireEvent.click(selectButtons[1]);

      await waitFor(() => {
        // Only one checkmark should exist
        const selectedIcons = document.querySelectorAll('svg path[d="M13.3346 4L6.0013 11.3333L2.66797 8"]');
        expect(selectedIcons.length).toBe(1);
      });
    });

    test('should open protection details modal when Details link is clicked', async () => {
      render(<ProtectionGridwall {...defaultProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      await waitFor(() => {
        expect(screen.getByText('Verizon Mobile Protect Multi-Device')).toBeInTheDocument();
      });

      const detailsLinks = screen.getAllByText('Details');
      fireEvent.click(detailsLinks[0]);
      await new Promise((res) => {
        setTimeout(res, 2000);
      });
      // const detailsModal = screen.getByTestId('protection-details-modal');
      // expect(detailsModal).toBeInTheDocument();
      //   expect(screen.getByTestId('modal-protection-id')).toHaveTextContent('2579');
      // });
      expect(screen.getByTestId('modal-close-button')).toBeInTheDocument();
      fireEvent.click(screen.getByTestId('modal-close-button'));
    });

    test.skip('should close protection details modal when close is clicked', async () => {
      render(<ProtectionGridwall {...defaultProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      await waitFor(() => {
        expect(screen.getByText('Verizon Mobile Protect Multi-Device')).toBeInTheDocument();
      });

      const detailsLinks = screen.getAllByText('Details');
      fireEvent.click(detailsLinks[0]);

      await waitFor(() => {
        expect(screen.getByTestId('protection-details-modal')).toBeInTheDocument();
      });

      const closeButton = screen.getByTestId('close-modal');
      fireEvent.click(closeButton);

      await waitFor(() => {
        expect(screen.queryByTestId('protection-details-modal')).not.toBeInTheDocument();
      });
    });

    test('should call handleBackButton and clear selections when Cancel button is clicked', async () => {
      const mockHandleBackButton = jest.fn();
      const testHeaderTitle = 'Test Header Title';
      const propsWithHandlers = {
        ...defaultProps,
        handleBackButton: mockHandleBackButton,
        headerTitle: testHeaderTitle,
      };

      render(<ProtectionGridwall {...propsWithHandlers} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      await waitFor(() => {
        expect(screen.getByText('Verizon Mobile Protect Multi-Device')).toBeInTheDocument();
      });

      // Select a protection first
      const selectButtons = screen.getAllByText('Select');
      fireEvent.click(selectButtons[0]);

      await waitFor(() => {
        const selectedIcon = document.querySelector('svg path[d="M13.3346 4L6.0013 11.3333L2.66797 8"]');
        expect(selectedIcon).toBeInTheDocument();
      });

      // Click Cancel button
      const cancelButton = screen.getByText('Cancel');
      fireEvent.click(cancelButton);

      // Verify selections are cleared
      await waitFor(() => {
        const selectedIcon = document.querySelector('svg path[d="M13.3346 4L6.0013 11.3333L2.66797 8"]');
        expect(selectedIcon).not.toBeInTheDocument();
      });
    });

    test('should call addFeature API when Apply button is clicked with selection', async () => {
      render(<ProtectionGridwall {...defaultProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      await waitFor(() => {
        expect(screen.getByText('Verizon Mobile Protect Multi-Device')).toBeInTheDocument();
      });

      const selectButtons = screen.getAllByText('Select');
      fireEvent.click(selectButtons[0]);

      await waitFor(() => {
        const selectedIcon = document.querySelector('svg path[d="M13.3346 4L6.0013 11.3333L2.66797 8"]');
        expect(selectedIcon).toBeInTheDocument();
      });

      const applyButton = screen.getByText('Apply');
      fireEvent.click(applyButton);
    });

    test('should include remove feature when selectedInsuranceForAIQuote is provided', async () => {
      const propsWithExistingInsurance = {
        ...defaultProps,
        selectedInsuranceForAIQuote: {
          sorId: '88689',
          featureType: 'SPO',
        },
      };

      render(<ProtectionGridwall {...propsWithExistingInsurance} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      await waitFor(() => {
        expect(screen.getByText('Verizon Mobile Protect Multi-Device')).toBeInTheDocument();
      });

      const selectButtons = screen.getAllByText('Select');
      fireEvent.click(selectButtons[0]);

      await waitFor(() => {
        const selectedIcon = document.querySelector('svg path[d="M13.3346 4L6.0013 11.3333L2.66797 8"]');
        expect(selectedIcon).toBeInTheDocument();
      });

      const applyButton = screen.getByText('Apply');
      fireEvent.click(applyButton);
    });

    test('should use default featureType when selectedInsuranceForAIQuote has no featureType', async () => {
      const propsWithExistingInsurance = {
        ...defaultProps,
        selectedInsuranceForAIQuote: {
          sorId: '88689',
          // no featureType provided
        },
      };

      render(<ProtectionGridwall {...propsWithExistingInsurance} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      await waitFor(() => {
        expect(screen.getByText('Verizon Mobile Protect Multi-Device')).toBeInTheDocument();
      });

      const selectButtons = screen.getAllByText('Select');
      fireEvent.click(selectButtons[0]);

      await waitFor(() => {
        const selectedIcon = document.querySelector('svg path[d="M13.3346 4L6.0013 11.3333L2.66797 8"]');
        expect(selectedIcon).toBeInTheDocument();
      });

      const applyButton = screen.getByText('Apply');
      fireEvent.click(applyButton);
    });

    test('should display features for each protection card', async () => {
      render(<ProtectionGridwall {...defaultProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      await waitFor(() => {
        expect(screen.getByText('Verizon Mobile Protect Multi-Device')).toBeInTheDocument();
      });
    });

    test('should render protection cards with proper styling', async () => {
      render(<ProtectionGridwall {...defaultProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      await waitFor(() => {
        expect(screen.getByText('Verizon Mobile Protect Multi-Device')).toBeInTheDocument();
      });

      const protectionCardsGrid = document.querySelector('[style*="display: flex"]');
      expect(protectionCardsGrid).toBeInTheDocument();
    });

    test('should handle empty features array', async () => {
      render(<ProtectionGridwall {...defaultProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      await waitFor(() => {
        // Decline Device Protection has empty features array
        expect(screen.getByText('Decline Device Protection')).toBeInTheDocument();
      });

      // Should still render the card without errors
      expect(screen.getByText('$0.00/mo')).toBeInTheDocument();
    });

    test('should filter only showCaseFlag true features', async () => {
      render(<ProtectionGridwall {...defaultProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      await waitFor(() => {
        expect(screen.getByText('Verizon Mobile Protect Multi-Device')).toBeInTheDocument();
      });
    });

    test('should map protection data correctly from API response', async () => {
      render(<ProtectionGridwall {...defaultProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      await waitFor(() => {
        // Check if mapped data includes all required fields
        expect(screen.getByText('Verizon Mobile Protect Multi-Device')).toBeInTheDocument();
        expect(screen.getByText('$68.00/mo')).toBeInTheDocument();
      });

      // Verify multiple protection cards are rendered
      const detailsLinks = screen.getAllByText('Details');
      expect(detailsLinks.length).toBeGreaterThan(1);
    });

    test('should have proper page layout with header, content, and footer', () => {
      render(<ProtectionGridwall {...defaultProps} />, {
        reducers: rootReducer,
        sagas: rootSaga,
      });

      // Verify page structure
      expect(screen.getByText('Cancel')).toBeInTheDocument(); // Footer
      expect(screen.getByText('Apply')).toBeInTheDocument(); // Footer
    });
  });
};

// Test with different channel scenarios
describe('ProtectionGridwall - Channel Tests', () => {
  Test(CHANNELS.OMNI_RETAIL);
});

// Additional edge case tests without channel setup
describe('ProtectionGridwall - Edge Cases', () => {
  const handlers = [
    rest.post(`*/deviceconfigservice/device-config/flexV2/getProtectionFeatures`, (req, res, ctx) =>
      res(ctx.status(200), ctx.json(ProtectionFeaturesResult)),
    ),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });
  afterAll(() => {
    server.close();
  });

  const defaultProps = {
    onBackClick: jest.fn(),
    activeMtn: '6308709368',
    selectedInsuranceForAIQuote: null,
    handleBackButton: jest.fn(),
  };

  test.skip('should handle protectionFeaturesResult with pending status', () => {
    jest.resetModules();

    jest.mock('../../modules/services/APIService/APIServiceHooks', () => ({
      useLazyGetProtectionFeaturesQuery: () => [
        jest.fn(),
        {
          status: 'pending',
          payload: null,
        },
      ],
    }));

    render(<ProtectionGridwall {...defaultProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    // Should render without protection cards
    expect(screen.getByText('All Protections')).toBeInTheDocument();
    expect(screen.queryByText('Verizon Mobile Protect Multi-Device')).not.toBeInTheDocument();
  });

  test('should handle missing feature in allProtectionFeatures', async () => {
    render(<ProtectionGridwall {...defaultProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    await waitFor(() => {
      expect(screen.getByText('Verizon Mobile Protect Multi-Device')).toBeInTheDocument();
    });

    // Protection cards should render even if some features are missing
    const protectionCards = screen.getAllByText('Details');
    expect(protectionCards.length).toBeGreaterThan(0);
  });

  test('should apply button be clickable even without selection', async () => {
    render(<ProtectionGridwall {...defaultProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    const applyButton = screen.getByText('Apply');
    fireEvent.click(applyButton);
  });

  test('should handle multiple rapid clicks on protection toggle', async () => {
    render(<ProtectionGridwall {...defaultProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    await waitFor(() => {
      expect(screen.getByText('Verizon Mobile Protect Multi-Device')).toBeInTheDocument();
    });

    const selectButtons = screen.getAllByText('Select');

    // Rapid clicks
    fireEvent.click(selectButtons[0]);
    fireEvent.click(selectButtons[0]);
    fireEvent.click(selectButtons[0]);

    await waitFor(() => {
      // Should handle rapid clicks gracefully
      const selectedIcon = document.querySelector('svg path[d="M13.3346 4L6.0013 11.3333L2.66797 8"]');
      expect(selectedIcon).toBeInTheDocument();
    });
  });

  test('should render all protection types from mock data', async () => {
    render(<ProtectionGridwall {...defaultProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    await waitFor(() => {
      expect(screen.getByText('Verizon Mobile Protect Multi-Device')).toBeInTheDocument();
      expect(screen.getByText('Decline Device Protection')).toBeInTheDocument();
    });
  });
});
