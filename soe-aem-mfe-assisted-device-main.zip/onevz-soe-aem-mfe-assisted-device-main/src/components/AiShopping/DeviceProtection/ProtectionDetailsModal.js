import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { Modal, ModalTitle, ModalBody } from '@vds/modals';
import { Title } from '@vds/typography';

const ModalSubTitle = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  margin-top: 1.5rem;
`;
function ProtectionDetailsModal({ isOpen, protectionId, protectionsData, onClose }) {
  const selectedProtectionDetail = protectionsData?.find((p) => p?.sorId === protectionId);

  return (
    <Modal
      opened={isOpen}
      surface='light'
      fullScreenDialog={false}
      disableAnimation={false}
      disableOutsideClick
      width='560px'
      ariaLabel='Protection Details Modal'
      onOpenedChange={(opened) => {
        if (!opened) onClose();
      }}
    >
      <ModalTitle>{selectedProtectionDetail?.name}</ModalTitle>
      <ModalSubTitle>
        <Title size='large'>${selectedProtectionDetail?.price}/mo</Title>
      </ModalSubTitle>
      <ModalBody>
        <div
          dangerouslySetInnerHTML={{
            __html: selectedProtectionDetail?.description,
          }}
        />
      </ModalBody>
    </Modal>
  );
}

ProtectionDetailsModal.propTypes = {
  isOpen: PropTypes.bool,
  protectionId: PropTypes.string,
  protectionsData: PropTypes.array,
  onClose: PropTypes.func,
};

export default ProtectionDetailsModal;
