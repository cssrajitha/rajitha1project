import React, { useState, useEffect } from 'react';
import { Button, TextLink } from '@vds/buttons';
import styled from 'styled-components';
import PropTypes from 'prop-types';
import { useGetProtectionFeaturesQuery } from 'onevzsoemfecommon/DeviceAPIService';
import { useAddFeaturesMutation } from 'onevzsoemfecommon/APIService';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import { useDispatch } from 'react-redux';
import DOMPurify from 'dompurify';
import ProtectionDetailsModal from './ProtectionDetailsModal';

// import ProtectionFeaturesResult from './__mocks__/getProtectionFeaturesmock.json';

// Button group container
const ButtonGroup = styled.div`
  display: flex;
  align-items: center;
  gap: 0.75rem; /* 12px */
`;

const ListContainer = styled.ul`
  display: flex;
  flex-direction: column;
  gap: 0.7rem;
  font-size: 1rem;
`;

function ProtectionGridwall({ handleBackButton, activeMtn, lineLevelData, selectedInsuranceForAIQuote, headerTitle }) {
  const dispatch = useDispatch();
  const [selectedProtections, setSelectedProtections] = useState({});
  const [protectionsData, setProtectionsData] = useState([]);
  const [openProtectionDetailsModal, setOpenProtectionDetailsModal] = useState({ isOpen: false, protectionId: null });
  const [addFeature, addFeatureResult] = useAddFeaturesMutation();
  const activeMtnLine = lineLevelData?.find((line) => line?.mtn === activeMtn);
  const deviceSorId = activeMtnLine?.existingDevice?.sorId;
  const initialRequestBodyProtectionFeatures = {
    mtn: activeMtn,
    deviceSorId,
    getHomeProtectionEligibility: false,
  };
  const ProtectionFeaturesResult = useGetProtectionFeaturesQuery({ body: initialRequestBodyProtectionFeatures });

  useEffect(() => {
    if (addFeatureResult?.isSuccess === true) {
      handleBackButton(headerTitle);
    }
    if (addFeatureResult?.isError === true) {
      dispatch(
        appMessageActions.addAppMessage(
          'Sorry could not add device protection, please try again after sometime.',
          'error',
          true,
          true,
        ),
      );
    }
  }, [addFeatureResult?.isError, addFeatureResult?.isSuccess, addFeatureResult?.data]);

  useEffect(() => {
    /* istanbul ignore else */
    if (ProtectionFeaturesResult?.data?.payload) {
      const protectionData = ProtectionFeaturesResult?.data?.payload?.features
        ?.filter((feature) => feature?.showCaseFlag === true)
        ?.map((feature) => ({
          sorId: feature?.sorId,
          name: feature?.displayName,
          tier: feature?.featureFamily,
          description: feature?.description,
          featureType: feature?.featureType,
          price: feature?.price?.regularPrice,
        }));
      setProtectionsData(protectionData);
    }
  }, [ProtectionFeaturesResult?.data?.payload]);

  useEffect(() => {}, [selectedProtections]);

  const handleProtectionToggle = (protection) => {
    if (selectedProtections?.sorId === protection?.sorId) {
      setSelectedProtections({});
    } else {
      setSelectedProtections(protection);
    }
  };

  const handleApply = () => {
    const request = {
      cartInfo: {
        intendType: 'EUP',
        processStep: 'FeaturesPDP',
        processingMTN: activeMtn,
      },
      data: {
        lines: [
          {
            features: {
              add: [
                {
                  actionIndicator: 'A',
                  id: selectedProtections?.sorId,
                  quantity: '1',
                  type: selectedProtections?.featureType,
                },
              ],
              ...(selectedInsuranceForAIQuote?.sorId
                ? {
                    remove: [
                      {
                        actionIndicator: 'D',
                        id: selectedInsuranceForAIQuote?.sorId,
                        quantity: '1',
                        type: selectedInsuranceForAIQuote?.featureType
                          ? selectedInsuranceForAIQuote?.featureType
                          : selectedProtections?.featureType,
                      },
                    ],
                  }
                : {}),
            },
            mtn: activeMtn,
          },
        ],
      },
    };

    addFeature({ body: request });
  };

  const handleCancel = () => {
    setSelectedProtections({});
    handleBackButton(headerTitle);
  };

  const handleViewDetails = (protectionId) => {
    setOpenProtectionDetailsModal({ isOpen: true, protectionId });
  };

  const protectionCardPoints = (htmlString) => {
    const cleanHtml = DOMPurify.sanitize(htmlString);
    const parser = new DOMParser();
    const doc = parser.parseFromString(cleanHtml, 'text/html');
    const strongElements = doc.querySelectorAll('strong');
    const points = Array.from(strongElements)
      .map((el) => el.textContent.trim())
      .filter((point) => !point.endsWith(':'));
    return points;
  };

  return (
    <>
      <div style={styles.pageWrapper}>
        {/* Scrollable Content */}
        <div style={styles.scrollableContent}>
          {/* Content Container */}
          <div style={styles.contentContainer}>
            {/* Header Section with Icon */}
            {/* Protection Cards Grid */}
            <div style={styles.protectionCardsGrid}>
              {protectionsData?.map((protection) => (
                <div
                  key={protection.sorId}
                  style={{
                    ...styles.protectionCard,
                    ...(selectedProtections[protection.sorId] ? styles.protectionCardSelected : {}),
                  }}
                >
                  <div style={styles.protectionCardInner}>
                    {/* Protection Header */}
                    <div style={styles.protectionCardHeader}>
                      <h3 style={styles.protectionName}>{protection.name}</h3>
                    </div>

                    {/* Price */}
                    <p style={styles.price}>${protection.price}/mo</p>

                    {/* Features */}
                    {protection?.description && (
                      <div style={styles.features}>
                        <ListContainer>
                          {protectionCardPoints(protection?.description)?.map((feature) => (
                            <li key={`${protection?.sorId}-${feature}`}>{feature}</li>
                          ))}
                        </ListContainer>
                      </div>
                    )}

                    {/* Card Footer */}
                    <div style={styles.protectionCardFooter}>
                      <TextLink
                        size='Large'
                        style={{
                          color: 'var(--vds-color-element-primary, #000)',
                          fontFamily: 'var(--vds-typography-body-large-fontfamily, "Verizon NHG eDS")',
                          fontSize: 'var(--vds-typography-body-large-fontsize, 18px)',
                          fontStyle: 'normal',
                          fontWeight: 400,
                          lineHeight: 'var(--vds-typography-body-large-lineheight, 20px)',
                          letterSpacing: 'var(--vds-typography-body-large-letterspacing-regular, 0.5px)',
                        }}
                        onClick={() => handleViewDetails(protection.sorId)}
                      >
                        Details
                      </TextLink>
                      <div style={styles.selectButtonWrapper}>
                        {selectedProtections?.sorId === protection?.sorId ? (
                          <button
                            type='button'
                            style={{
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              width: '32px',
                              height: '32px',
                              borderRadius: '50%',
                              backgroundColor: '#000000',
                              cursor: 'pointer',
                              border: 'none',
                              padding: 0,
                            }}
                            onClick={() => handleProtectionToggle(protection)}
                            aria-label='Select protection'
                          >
                            <svg
                              width='16'
                              height='16'
                              viewBox='0 0 16 16'
                              fill='none'
                              xmlns='http://www.w3.org/2000/svg'
                            >
                              <path
                                d='M13.3346 4L6.0013 11.3333L2.66797 8'
                                stroke='white'
                                strokeWidth='2'
                                strokeLinecap='round'
                                strokeLinejoin='round'
                              />
                            </svg>
                          </button>
                        ) : (
                          <Button
                            kind='secondary'
                            size='small'
                            onClick={() => handleProtectionToggle(protection)}
                            style={{
                              display: 'flex',
                              minWidth: '44px',
                              minHeight: '32px',
                              justifyContent: 'center',
                              alignItems: 'center',
                              backgroundColor: '#FFFFFF',
                              color: '#000000',
                            }}
                          >
                            Select
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div style={styles.footer}>
          <div style={styles.footerContent}>
            <ButtonGroup>
              <Button
                use='secondary'
                size='large'
                ariaLabel='Cancel'
                onClick={() => handleCancel()}
                data-track='Protection_Cancel'
              >
                Cancel
              </Button>
              <Button
                use='primary'
                size='large'
                ariaLabel='Apply'
                onClick={() => handleApply()}
                data-track='Protection_Apply'
              >
                Apply
              </Button>
            </ButtonGroup>
          </div>
        </div>
      </div>
      <ProtectionDetailsModal
        isOpen={openProtectionDetailsModal?.isOpen}
        protectionId={openProtectionDetailsModal?.protectionId}
        protectionsData={protectionsData}
        onClose={() => setOpenProtectionDetailsModal({ isOpen: false, protectionId: null })}
      />
    </>
  );
}

const styles = {
  pageWrapper: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    display: 'flex',
    flexDirection: 'column',
    backgroundColor: 'var(--vds-color-background, #F8F7F5)',
    overflow: 'hidden',
  },
  header: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    height: '88px',
    backgroundColor: 'var(--vds-color-surface, #FFFFFF)',
    borderBottom: '1px solid var(--vds-color-border, #E0E0E0)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1000,
    boxSizing: 'border-box',
  },
  headerContent: {
    width: '100%',
    maxWidth: '1085px',
    padding: '0 24px',
    display: 'flex',
    alignItems: 'center',
    gap: '16px',
    boxSizing: 'border-box',
  },
  backButton: {
    backgroundColor: 'transparent',
    border: 'none',
    padding: '8px',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    width: '40px',
    height: '40px',
    borderRadius: '4px',
    transition: 'background-color 0.2s',
  },
  backIcon: {
    width: '24px',
    height: '24px',
    transform: 'rotate(360deg)',
  },
  headerTitle: {
    margin: 0,
    color: '#000000',
    fontFamily: 'Verizon NHG eDS, Arial, sans-serif',
    fontWeight: 700,
    fontSize: '18px',
    lineHeight: '24px',
    letterSpacing: 0,
  },
  scrollableContent: {
    position: 'absolute',
    top: '88px',
    bottom: '84px',
    left: '24px',
    right: '24px',
    overflowY: 'auto',
    backgroundColor: 'var(--vds-color-background, #F8F7F5)',
  },
  contentContainer: {
    width: '100%',
    maxWidth: '1085px',
    margin: '0 auto 15px',
    padding: '20px 24px',
    backgroundColor: 'var(--vds-color-surface, #FFFFFF)',
    borderRadius: 'var(--vds-size-border-radius-400, 16px)',
    display: 'flex',
    flexDirection: 'column',
    gap: '24px',
    boxSizing: 'border-box',
    height: 'stretch',
  },
  headerSection: {
    display: 'flex',
    flexDirection: 'column',
    gap: '16px',
  },
  headerTitleWrapper: {
    display: 'flex',
    alignItems: 'flex-start',
    gap: '12px',
    marginBottom: '16px',
  },
  contentHeaderTitle: {
    margin: 0,
    color: 'var(--beta-vds-color-black, #000)',
    fontFamily: 'var(--beta-vds-typography-title-xsmall-fontfamily, "Verizon NHG DS")',
    fontSize: 'var(--beta-vds-typography-title-xsmall-fontsize, 20px)',
    fontStyle: 'normal',
    fontWeight: 700,
    lineHeight: 'var(--beta-vds-typography-title-xsmall-lineheight, 24px)',
    letterSpacing: 'var(--beta-vds-typography-title-xsmall-letterspacing-bold, 0)',
  },
  headerSubtitle: {
    margin: '4px 0 0 0',
    color: 'var(--vds-color-text-secondary, #6F7171)',
    fontFamily: 'var(--vds-typography-body-medium-fontfamily, "Verizon NHG eDS")',
    fontSize: 'var(--vds-typography-body-medium-fontsize, 14px)',
    fontStyle: 'normal',
    fontWeight: 400,
    lineHeight: 'var(--vds-typography-body-medium-lineheight, 18px)',
    letterSpacing: 'var(--vds-typography-body-medium-letterspacing, 0.5px)',
  },
  headerLinks: {
    display: 'flex',
    flexWrap: 'wrap',
    gap: '24px',
  },
  headerLinkWrapper: {
    display: 'inline-block',
  },
  protectionCardsGrid: {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: '24px',
    alignSelf: 'stretch',
    overflowX: 'auto',
    overflowY: 'hidden',
    height: '90%',
  },
  protectionCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: '12px',
    border: '1px solid #DDDAD4',
    overflow: 'hidden',
    flexShrink: 0,
    width: '320px',
    transition: 'all 0.2s ease',
    height: '95%',
    position: 'relative', // Added for absolute positioning of footer
  },
  protectionCardSelected: {
    border: '2px solid #000000',
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.12)',
  },
  protectionCardInner: {
    padding: '16px',
    display: 'flex',
    flexDirection: 'column',
    height: '100%',
    minHeight: '320px',
  },
  protectionCardHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: '4px',
    gap: '8px',
  },
  protectionName: {
    margin: 0,
    color: 'var(--beta-vds-color-black, #000)',
    fontFeatureSettings: "'liga' off, 'clig' off",
    fontFamily: 'Verizon NHG eDS',
    fontSize: '20px',
    fontStyle: 'normal',
    fontWeight: 600,
    lineHeight: '26px',
    letterSpacing: '0.5px',
    flex: 1,
    alignSelf: 'stretch',
  },
  recommendedBadge: {
    display: 'inline-block',
    padding: '2px 8px',
    backgroundColor: '#000000',
    borderRadius: '4px',
    color: '#FFFFFF',
    fontFamily: 'var(--vds-typography-label-small-fontfamily, "Verizon NHG eDS")',
    fontSize: '11px',
    fontStyle: 'normal',
    fontWeight: 700,
    lineHeight: '16px',
    letterSpacing: '0.5px',
    textTransform: 'uppercase',
    flexShrink: 0,
  },
  price: {
    margin: '0 0 8px 0',
    color: 'var(--beta-vds-color-black, #000)',
    fontFamily: 'var(--vds-typography-title-xsmall-fontfamily, "Verizon NHG eDS")',
    fontSize: 'var(--vds-typography-title-xsmall-fontsize, 24px)',
    fontStyle: 'normal',
    fontWeight: 400,
    lineHeight: 'var(--vds-typography-title-xsmall-lineheight, 24px)',
    letterSpacing: 'var(--vds-typography-title-xsmall-letterspacing-regular, 0)',
  },
  features: {
    display: 'flex',
    flexDirection: 'column',
    gap: '8px',
    height: '62%',
  },
  feature: {
    display: 'flex',
    alignItems: 'flex-start',
    gap: '12px',
  },
  featureIcon: {
    flexShrink: 0,
    width: '16px',
    height: '16px',
    marginTop: '2px',
  },
  featureText: {
    display: 'flex',
    alignItems: 'flex-start',
    gap: 'var(--vds-space-2-x, 8px)',
    alignSelf: 'stretch',
    color: '#000000',
    fontFamily: 'Verizon-NHG-eDS, Helvetica, Arial, sans-serif',
    fontSize: '13px',
    fontStyle: 'normal',
    fontWeight: 400,
    lineHeight: '17px',
    letterSpacing: '0.25px',
  },
  deductibleInfo: {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    gap: '4px',
    padding: '8px 12px',
    backgroundColor: '#F8F7F5',
    borderRadius: '6px',
    marginBottom: '12px',
  },
  deductibleLabel: {
    color: '#6F7171',
    fontFamily: 'var(--vds-typography-body-medium-fontfamily, "Verizon NHG eDS")',
    fontSize: '13px',
    fontStyle: 'normal',
    fontWeight: 400,
    lineHeight: '18px',
    letterSpacing: '0.25px',
  },
  deductibleValue: {
    color: '#000000',
    fontFamily: 'var(--vds-typography-body-medium-fontfamily, "Verizon NHG eDS")',
    fontSize: '13px',
    fontStyle: 'normal',
    fontWeight: 700,
    lineHeight: '18px',
    letterSpacing: '0.25px',
  },
  protectionCardFooter: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: '20px', // Padding from bottom
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: '12px',
    paddingLeft: '16px',
    paddingRight: '16px',
    paddingBottom: 0,
    background: 'transparent',
    boxSizing: 'border-box',
  },
  selectButtonWrapper: {
    minWidth: '100px',
    display: 'flex',
    justifyContent: 'flex-end',
  },
  footer: {
    position: 'fixed',
    bottom: 0,
    left: 0,
    right: 0,
    height: '84px',
    backgroundColor: 'var(--vds-color-surface, #FFFFFF)',
    borderTop: '1px solid var(--vds-color-border, #E0E0E0)',
    display: 'flex',
    alignItems: 'right',
    justifyContent: 'center',
    boxShadow: '0 -2px 8px rgba(0, 0, 0, 0.1)',
    zIndex: 1000,
    boxSizing: 'border-box',
  },
  footerContent: {
    width: '100%',
    maxWidth: '1085px',
    padding: '0 24px',
    display: 'flex',
    justifyContent: 'flex-end',
    gap: '12px',
    boxSizing: 'border-box',
  },
  cancelButton: {
    minWidth: '120px',
  },
  applyButton: {
    minWidth: '200px',
  },
};

ProtectionGridwall.propTypes = {
  // onApply: PropTypes.func,
  // onCancel: PropTypes.func,
  activeMtn: PropTypes.string,
  selectedInsuranceForAIQuote: PropTypes.object,
  handleBackButton: PropTypes.func,
  lineLevelData: PropTypes.array,
  headerTitle: PropTypes.string,
};

export default ProtectionGridwall;
