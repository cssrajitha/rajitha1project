import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import { useDispatch } from 'react-redux';
import { Body } from '@vds/typography';
import { Button, TextLink } from '@vds/buttons';
import { Icon } from '@vds/icons';
import { GenerativeAiFilled } from '@vds/core/icons';
import PropTypes from 'prop-types';
import { ButtonIcon } from '@vds/button-icons';
import { useLazyAddAccessoryQuery } from 'onevzsoemfecommon/CartAPIService';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import { BREAKPOINTS } from '../DeviceGridWall/DeviceGridWall.styles';
import { useLazyGetProductListQuery } from '../../../modules/services/APIService/APIServiceHooks';
import { transformAddAccessoryRequest, transformProductListRequest } from '../../../utils/commonFunctions';

const PageContainer = styled.div`
  // position: fixed;
  // min-height: 100vh;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  padding: 0;
  background-color: #f8f7f5;
  display: flex;
  flex-direction: column;
  overflow: auto;
  // z-index: 1000;
`;

// const TopHeaderWrapper = styled.div`
//   width: 100%;
//   background-color: #ffffff;
//   border-bottom: 1px solid #d8dada;
//   flex-shrink: 0;
// `;

// // Inner header content with max-width for centering
// const TopHeader = styled.div`
//   width: 100%;
//   max-width: 70.8125rem; /* 1133px */
//   height: 4.25rem; /* 68px */
//   display: flex;
//   align-items: center;
//   gap: 1rem;
//   padding: 0 1.5rem;
//   margin: 0 auto;
//   box-sizing: border-box;

//   @media (max-width: ${BREAKPOINTS.tablet}) {
//     max-width: 100%;
//     height: 3.75rem; /* 60px */
//     padding: 0 1.25rem;
//   }

//   @media (max-width: ${BREAKPOINTS.ipadMini}) {
//     height: 3.5rem; /* 56px */
//     gap: 0.75rem;
//     padding: 0 1rem;
//   }
// `;

// // Back button container for proper alignment
// const BackButtonContainer = styled.div`
//   display: flex;
//   align-items: center;
//   flex-shrink: 0;

//   @media (max-width: ${BREAKPOINTS.ipadMini}) {
//     width: 2.25rem;
//     height: 2.25rem;
//   }
// `;

// Content wrapper for main body area
const ContentWrapper = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  padding: 1.5rem;
  overflow: auto;

  @media (max-width: ${BREAKPOINTS.tablet}) {
    padding: 1.25rem;
  }

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    padding: 1rem;
  }
`;

// Main content card - 1085 x 462px per Figma
const ContentCard = styled.div`
  width: 100%;
  max-width: 67.8125rem; /* 1085px */
  height: 30rem; /* 462px */
  background-color: #ffffff;
  border-radius: 1rem; /* 16px - VDS size/border/radius/400 */
  padding: 1.25rem; /* 20px */
  display: flex;
  flex-direction: column;
  box-sizing: border-box;
  overflow: hidden;
  margin: 0 auto;

  @media (max-width: ${BREAKPOINTS.tablet}) {
    max-width: 100%;
    height: auto;
    min-height: 26rem;
    padding: 1rem;
  }

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    padding: 0.875rem;
    border-radius: 0.75rem;
    min-height: 24rem;
  }
`;

// Header section - responsive layout with space-between
const HeaderSection = styled.div`
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: nowrap;
  gap: 1rem; /* 16px - spacing between left and right sections */

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    flex-direction: column;
    align-items: flex-start;
    gap: 0.75rem;
  }
`;

// Left side of header with sparkle icon and title (hidden but maintains space)
const HeaderLeft = styled.div`
  display: flex;
  align-items: center;
  gap: 0.5rem; /* 8px */
  flex-shrink: 0;
  opacity: 0; /* Hide the left section but maintain space for layout consistency */
  visibility: hidden;

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    display: none;
  }
`;

const SparkleIconWrapper = styled.span`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;

  /* Apply gradient to the icon */
  svg {
    path {
      fill: url(#sparkle-gradient);
    }
  }

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    svg {
      width: 20px;
      height: 20px;
    }
  }
`;

// SVG gradient definition for sparkle icon
const SparkleGradientDef = () => (
  <svg width='0' height='0' style={{ position: 'absolute' }}>
    <defs>
      <linearGradient id='sparkle-gradient' x1='0%' y1='100%' x2='100%' y2='0%' gradientTransform='rotate(-42.78)'>
        <stop offset='41.43%' stopColor='#E10014' />
        <stop offset='95.35%' stopColor='rgba(255, 194, 32, 0.7)' />
      </linearGradient>
    </defs>
  </svg>
);

// Right side of header with brand filters and action icons
const HeaderRight = styled.div`
  display: flex;
  align-items: center;
  gap: 1.5rem; /* 24px between filter group and action icons */
  flex-wrap: nowrap;
  flex: 1;
  overflow: hidden;

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    width: 100%;
    justify-content: flex-start;
    gap: 0.75rem;
  }
`;

const CategoryFilters = styled.div`
  display: flex;
  align-items: center;
  gap: 0.3rem; /* 12px */
  flex-wrap: nowrap;
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;

  /* Hide scrollbar */
  &::-webkit-scrollbar {
    display: none;
  }
  -ms-overflow-style: none;
  scrollbar-width: none;

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    gap: 0.5rem;
  }
`;

// Styled wrapper for VDS Button to add custom border-radius for filter buttons
const FilterButtonWrapper = styled.div`
  flex-shrink: 0;

  /* Override VDS Button styles for compact filter pill appearance */
  button {
    border: none !important;
    border-radius: 0.5rem !important; /* 6px pill shape */
    min-width: auto !important;
    height: 2.75rem !important; /* 44px */
    padding: 0 !important; /* 10px 20px */
    font-size: 1rem !important;
    line-height: 1.25rem !important;
    background-color: ${(props) => (props.children.props.use === 'secondary' ? '#f8f7f5' : '#000')} !important;
  }

  @media (max-width: ${BREAKPOINTS.tablet}) {
    button {
      height: 2.5rem !important;
      padding: 0 !important;
      font-size: 0.9375rem !important;
    }
  }

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    button {
      height: 2.25rem !important;
      padding: 0 !important;
      font-size: 0.875rem !important;
      border-radius: 1.125rem !important;
    }
  }
`;

const HeaderActions = styled.div`
  display: flex;
  align-items: center;
  gap: 1.5rem; /* 24px between icons per Figma */
  flex-shrink: 0;

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    gap: 0.75rem;
  }
`;

const IconActionButton = styled.button`
  width: 2.75rem; /* 44px */
  height: 2.75rem; /* 44px */
  border-radius: 50%;
  border: 1px solid rgba(0, 0, 0, 0.12);
  background: #f8f7f5;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.2s ease;
  flex-shrink: 0;

  &:hover {
    background-color: #ebebeb;
    border-color: rgba(0, 0, 0, 0.22);
  }

  &:focus {
    outline: 2px solid #000000;
    outline-offset: 2px;
  }

  @media (max-width: ${BREAKPOINTS.tablet}) {
    width: 2.5rem;
    height: 2.5rem;
  }

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    width: 2.25rem;
    height: 2.25rem;

    svg {
      width: 18px;
      height: 18px;
    }
  }
`;

// Accessories container - responsive
const AccessoriesContainer = styled.div`
  flex: 1;
  width: 100%;
  margin-top: 1.25rem; /* 20px */
  display: flex;
  gap: 1.25rem; /* 20px */
  overflow-x: auto;
  overflow-y: hidden;
  -webkit-overflow-scrolling: touch;
  align-items: stretch;

  /* Scrollbar styling */
  &::-webkit-scrollbar {
    /* height: 0.375rem; */
    display: none;
  }

  -ms-overflow-style: none;
  scrollbar-width: none;

  &::-webkit-scrollbar-track {
    background: transparent;
  }

  &::-webkit-scrollbar-thumb {
    background-color: rgba(0, 0, 0, 0.2);
    border-radius: 0.1875rem;
  }

  @media (max-width: ${BREAKPOINTS.tablet}) {
    margin-top: 1rem;
    gap: 1rem;
  }

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    margin-top: 0.75rem;
    gap: 0.75rem;
  }
`;

// Individual accessory card - approx 240px width per Figma
const AccessoryCard = styled.div`
  width: 15rem; /* 240px */
  // min-width: 18rem;
  height: 100%;
  background-color: #ffffff;
  border-radius: 1rem; /* 16px */
  border: 1px solid #d8dada;
  padding: 1rem; /* 16px */
  display: flex;
  flex-direction: column;
  flex-shrink: 0;
  box-sizing: border-box;
  transition: all 0.2s ease;

  &:hover {
    border-color: rgba(0, 0, 0, 0.3);
    box-shadow: 0 0.25rem 0.75rem rgba(0, 0, 0, 0.08);
  }

  @media (max-width: ${BREAKPOINTS.tablet}) {
    width: 13.5rem;
    min-width: 13.5rem;
    padding: 0.875rem;
  }

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    width: 12rem;
    min-width: 12rem;
    padding: 0.75rem;
    border-radius: 0.75rem;
  }
`;

// Accessory info section at top of card
const AccessoryInfoSection = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.25rem; /* 4px */
`;

const AccessoryName = styled.p`
  font-size: 0.875rem;
  font-weight: 700;
  line-height: 1.125rem;
  font-family: Verizon-NHG-eDS, Helvetica, Arial, sans-serif;
  letter-spacing: 0.03125rem;
  color: rgb(0, 0, 0);
  margin: 0px;
  text-decoration: none;
  min-height: 3.5rem !important; /* 56px to maintain space even if name is short */
`;

const AccessoryPriceRow = styled.div`
  display: flex;
  align-items: baseline;
  gap: 0.25rem;
  flex-wrap: wrap;
`;

// Accessory image container
const AccessoryImageContainer = styled.div`
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 1rem 0;
  min-height: 3rem; /* 176px */

  @media (max-width: ${BREAKPOINTS.tablet}) {
    padding: 0.75rem 0;
    min-height: 9.5rem;
  }

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    padding: 0.5rem 0;
    min-height: 8rem;
  }
`;

const AccessoryImage = styled.div`
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: transparent;

  svg {
    width: auto;
    height: 100%;
    max-width: 140px;
    max-height: 180px;
  }

  @media (max-width: ${BREAKPOINTS.tablet}) {
    svg {
      max-width: 120px;
      max-height: 150px;
    }
  }

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    svg {
      max-width: 100px;
      max-height: 130px;
    }
  }
`;

const ColorVariantWrapper = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
  align-items: center;
  text-align: center;
  min-height: 2.5rem; /* Fixed height to maintain consistency */
`;

const ColorName = styled(Body)`
  font-size: 0.875rem;
  line-height: 1.125rem;
  color: #000000;
  font-weight: 400;
  height: 1.125rem; /* Fixed height for alignment */
`;

const SkuText = styled(Body)`
  font-size: 0.875rem;
  line-height: 1.125rem;
  color: #6f7171;
  font-weight: 400;
  height: 1.125rem; /* Fixed height for alignment */
`;

// Bottom actions container - responsive
// Full-width footer wrapper with white background
const BottomActionsWrapper = styled.div`
  width: 100%;
  background-color: #ffffff;
  border-top: 1px solid #d8dada;
  margin-top: auto;
  flex-shrink: 0;
`;

// Inner footer content with max-width for centering
const BottomActions = styled.div`
  width: 100%;
  max-width: 70.8125rem; /* 1133px */
  display: flex;
  justify-content: flex-end;
  align-items: center;
  gap: 1rem; /* 16px */
  padding: 1rem 1.5rem;
  margin: 0 auto;
  box-sizing: border-box;

  @media (max-width: ${BREAKPOINTS.tablet}) {
    max-width: 100%;
    padding: 1rem 1.25rem;
    gap: 0.75rem;
  }

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    padding: 0.75rem 1rem;
    gap: 0.5rem;
  }
`;

const ActionsWrapper = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  gap: 0.5rem;
  margin-top: auto;
`;

const ConfigureLink = styled(TextLink)`
  text-align: center;
  font-size: 0.875rem;
`;

const QuantityContainer = styled.div`
  cursor: pointer;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  border: 1px solid #000000;
  border-radius: 1.5rem;
  padding: 0 0.25rem;
  gap: 0.25rem;
`;

const QuantityWrapper = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  height: 2.25rem; /* Match the height of small Button */
  // min-width: 6.5rem;
`;

function AccessoryGridwall({
  processingMTN = '7249772172',
  retrieveCartResult,
  fetchLandingDataForAiShoppingResult = {},
  headerTitle,
  onBack,
}) {
  const dispatch = useDispatch();
  const [accessoriesList, setAccessoriesList] = useState([]);
  const [activeCategory, setActiveCategory] = useState('');
  // const [selectedAccessories, setSelectedAccessories] = useState([]);
  const [triggerProductList, productListResult] = useLazyGetProductListQuery({ productType: 'accessory' });
  const [addAccessory, addAccessoryResult] = useLazyAddAccessoryQuery();
  // const selectedAccIds = selectedAccessories.map((acc) => acc?.id);
  const activeLine = retrieveCartResult?.data?.data?.cart?.lineDetails?.lineInfo?.filter(
    (item) => item?.mtnDetails?.lineNumber === processingMTN,
  )?.[0];
  const isIspuCheck = activeLine?.ispuItem || false;
  const aciveLineDepletionType = activeLine?.itemsInfo?.[0]?.depletionType || '';
  console.log(fetchLandingDataForAiShoppingResult, 'fetchLandingDataForAiShoppingResult in AccessoryGridwall');
  const defaultCategories = [
    { id: 'cases', label: 'Cases' },
    { id: 'screen-protectors', label: 'Screen Protectors' },
    { id: 'charging', label: 'Charging' },
    { id: 'audio', label: 'Audio' },
    { id: 'gaming', label: 'Gaming' },
  ];

  const getAccessories = (category = '') => {
    const productListRequestBody = transformProductListRequest({ productType: 'accessory', category });
    triggerProductList({
      body: productListRequestBody,
      customHeaders: { flowName: 'WorkspaceQuote' },
      showErrorBanner: true,
    });
  };
  useEffect(() => {
    getAccessories();
  }, []);

  useEffect(() => {
    if (['fulfilled', 'rejected'].includes(productListResult?.status)) {
      /* istanbul ignore else */
      if (['fulfilled'].includes(productListResult?.status)) {
        const accessoryGridwallData = productListResult?.data?.data?.gridWall?.accessoryList || [];
        const formattedAccessoriesList = accessoryGridwallData.map((accessory) => {
          const defaultAccessoryObject = accessory.defaultSKUObj || {};
          return {
            id: accessory?.defaultSKU || defaultAccessoryObject?.sorId || '',
            name: accessory?.productDisplayName || '',
            colorVariant: defaultAccessoryObject?.color?.displayName || '',
            price: defaultAccessoryObject?.price?.fullRetailPrice?.originalPrice || 0,
            image:
              defaultAccessoryObject?.imageUrlMap?.defaultImage ||
              defaultAccessoryObject?.imageUrlMap?.mediumImage ||
              null,
            isInstorePickupEligible: defaultAccessoryObject?.isInstorePickupEligible || false,
            dFillInventory: { ...defaultAccessoryObject?.inventoryDetails?.dFillInventory },
            qty: 0,
          };
        });
        setAccessoriesList(formattedAccessoriesList);
      }
    }
  }, [productListResult?.status]);
  const handleCategoryChange = (categoryName) => {
    console.log('Category changed to:', categoryName);
    setActiveCategory(categoryName);
    // Filter accessories based on category
  };

  useEffect(() => {
    if (activeCategory) {
      console.log('Category changed to:', activeCategory);
      getAccessories(activeCategory);
    }
  }, [activeCategory]);

  const updateAccessoryQuantity = (accessoryId, updatedQuantity) => {
    setAccessoriesList((prevList) =>
      prevList?.map((acc) => (acc?.id === accessoryId ? { ...acc, qty: updatedQuantity } : acc)),
    );
  };

  const handleAccessorySelect = (accessoryId) => {
    console.log('Selected accessory:', accessoryId);
    updateAccessoryQuantity(accessoryId, 1);
  };

  const handleAccessoryIncrement = (id, qty) => {
    console.log('Increased accessory with id:', id);
    updateAccessoryQuantity(id, qty + 1);
  };

  const handleAccessoryDecrement = (id, qty) => {
    console.log('Decreased accessory with id:', id);
    updateAccessoryQuantity(id, qty - 1);
  };
  const handleConfigure = (accessory) => {
    console.log('Configure:', accessory);
    // Open configuration modal or navigate to configuration page
  };

  const getSelectedAccessoriesList = () => accessoriesList.filter((accessory) => accessory.qty > 0);

  const handleSearch = () => {
    console.log('Search clicked');
    // Open search modal
  };

  const handleScan = () => {
    console.log('Scan clicked');
    // Open barcode scanner
  };

  const handleCancel = () => {
    console.log('Cancel clicked');
    onBack(headerTitle);
    // Reset selections or navigate back
  };

  const handleApply = () => {
    const addAccessoryRequestBody = transformAddAccessoryRequest({
      mtn: processingMTN,
      addAccessoriesList: [...getSelectedAccessoriesList()],
      isIspuCheck,
      aciveLineDepletionType,
    });
    addAccessory({
      body: addAccessoryRequestBody,
      customHeaders: { flowName: 'WorkspaceQuote' },
      showErrorBanner: true,
    });
  };

  useEffect(() => {
    if (addAccessoryResult?.isSuccess === true) {
      onBack(headerTitle);
    }
    if (addAccessoryResult?.isError === true) {
      dispatch(
        appMessageActions.addAppMessage(
          'Sorry could not add accessory , please try again after sometime.',
          'error',
          true,
          true,
        ),
      );
    }
  }, [addAccessoryResult?.isError, addAccessoryResult?.isSuccess, addAccessoryResult?.data]);
  return (
    <PageContainer>
      {/* <TopHeaderWrapper>
        <TopHeader>
          <BackButtonContainer>
            <ButtonIcon
              kind="ghost"
              size={24}
              renderIcon={(props) => <Icon name="left-caret" size={24} />}
              onClick={() => onBack()}
              aria-label="Go back"
              data-track="AllAccessories_Back"
            />
          </BackButtonContainer>
          <Body size="large" color="#000000" bold>All accessories</Body>
        </TopHeader>
      </TopHeaderWrapper> */}

      {/* Content wrapper for scrollable area */}
      <ContentWrapper>
        {/* Main content card */}
        <ContentCard>
          {/* SVG gradient definition for sparkle icon */}
          <SparkleGradientDef />

          {/* Header row with title and filters */}
          <HeaderSection>
            <HeaderLeft>
              <SparkleIconWrapper>
                <GenerativeAiFilled size={24} />
              </SparkleIconWrapper>
              <Body size='large' color='#000000' bold>
                Accessory recommendations
              </Body>
            </HeaderLeft>

            <HeaderRight>
              <CategoryFilters>
                {defaultCategories.map((category) => (
                  <FilterButtonWrapper key={category.label} activeCategory={activeCategory}>
                    <Button
                      size='medium'
                      use={activeCategory === category.label ? 'primary' : 'secondary'}
                      ariaLabel={`Filter by ${category.label}`}
                      data-track={`AllAccessories_Filter_${category.label}`}
                      onClick={() => handleCategoryChange(category.label)}
                    >
                      {category.label}
                    </Button>
                  </FilterButtonWrapper>
                ))}
              </CategoryFilters>
              <HeaderActions>
                <IconActionButton aria-label='Search Accessories' onClick={() => handleSearch()}>
                  <Icon name='search' size={20} color='#000000' />
                </IconActionButton>
                <IconActionButton aria-label='Scan barcode' onClick={() => handleScan()}>
                  <Icon name='barcode' size={20} color='#000000' />
                </IconActionButton>
              </HeaderActions>
            </HeaderRight>
          </HeaderSection>

          {/* Device tiles */}
          <AccessoriesContainer>
            {accessoriesList.map((accessory) => (
              <AccessoryCard key={accessory?.id}>
                <AccessoryInfoSection>
                  <AccessoryName size='medium' color='#000000' bold>
                    {accessory?.name}
                  </AccessoryName>
                  <AccessoryPriceRow>
                    <Body size='large' color='#000000' bold primitive='span'>
                      {`$${accessory?.price}`}
                    </Body>
                  </AccessoryPriceRow>
                </AccessoryInfoSection>

                <AccessoryImageContainer>
                  <AccessoryImage>
                    {accessory?.image ? (
                      <img
                        src={accessory?.image}
                        alt={accessory?.name}
                        style={{ width: '100%', height: '100%', objectFit: 'contain' }}
                      />
                    ) : (
                      <Icon name='accessory' size={120} color='#d8dada' />
                    )}
                  </AccessoryImage>
                </AccessoryImageContainer>

                <ColorVariantWrapper>
                  <ColorName>{accessory?.colorVariant || '\u00A0'}</ColorName>
                  <SkuText>{accessory?.id || '\u00A0'}</SkuText>
                </ColorVariantWrapper>

                <ActionsWrapper>
                  <ConfigureLink
                    onClick={() => handleConfigure(accessory)}
                    size='small'
                    aria-label={`Configure ${accessory?.name}`}
                  >
                    Configure
                  </ConfigureLink>

                  <QuantityWrapper>
                    {accessory?.qty > 0 ? (
                      <QuantityContainer>
                        <ButtonIcon
                          kind='ghost'
                          size={48}
                          data-testid='trashAcc'
                          // fitToIcon={true}
                          renderIcon={() => <Icon color='#000000' name='minus' size='medium' />}
                          ariaLabel='Remove Accessory'
                          tabIndex={0}
                          onClick={() => handleAccessoryDecrement(accessory?.id, accessory?.qty)}
                        />

                        <Body size='large' color='#000000'>
                          {accessory?.qty}
                        </Body>

                        <ButtonIcon
                          kind='ghost'
                          size={48}
                          data-testid='addAccessory'
                          // fitToIcon={true}
                          renderIcon={() => <Icon color='#000000' name='plus' size='medium' />}
                          ariaLabel='Add Accessory'
                          tabIndex={0}
                          onClick={() =>
                            /* istanbul ignore next */
                            handleAccessoryIncrement(accessory?.id, accessory?.qty)
                          }
                        />
                      </QuantityContainer>
                    ) : (
                      <Button
                        onClick={() => handleAccessorySelect(accessory?.id)}
                        // variant={accessory?.buttonVariant}
                        use='secondary'
                        size='small'
                        aria-label={`Add ${accessory?.name}`}
                      >
                        Add
                      </Button>
                    )}
                  </QuantityWrapper>
                </ActionsWrapper>
              </AccessoryCard>
            ))}
          </AccessoriesContainer>
        </ContentCard>
      </ContentWrapper>
      {/* Bottom actions footer - full width white background */}
      <BottomActionsWrapper>
        <BottomActions>
          <Button use='secondary' size='medium' ariaLabel='Cancel' onClick={() => handleCancel()}>
            Cancel
          </Button>
          <Button
            use='primary'
            size='medium'
            ariaLabel='Apply '
            onClick={() => handleApply()}
            disabled={getSelectedAccessoriesList().length === 0}
          >
            Apply
          </Button>
        </BottomActions>
      </BottomActionsWrapper>
    </PageContainer>
  );
}

AccessoryGridwall.propTypes = {
  onBack: PropTypes.func,
};
export default AccessoryGridwall;
