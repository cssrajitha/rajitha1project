import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import AccessoryGridwall from './AccessoryGridwall';

// Mock react-redux
jest.mock('react-redux', () => ({
  useDispatch: jest.fn(),
}));

// Mock appMessageActions
jest.mock('onevzsoemfecommon/AppMessageActions', () => ({
  addAppMessage: jest.fn((message, type, show, auto) => ({
    type: 'ADD_APP_MESSAGE',
    payload: { message, type, show, auto },
  })),
}));

// Mock the API hooks
jest.mock('../../../modules/services/APIService/APIServiceHooks', () => ({
  useLazyGetProductListQuery: jest.fn(() => [jest.fn(), { status: 'idle', data: null }]),
}));

jest.mock('onevzsoemfecommon/CartAPIService', () => ({
  useLazyAddAccessoryQuery: jest.fn(() => [jest.fn(), { status: 'idle', data: null }]),
}));

// Mock utility functions
jest.mock('../../../utils/commonFunctions', () => ({
  transformProductListRequest: jest.fn((params) => params),
  transformAddAccessoryRequest: jest.fn((params) => params),
}));

// Get references to mocked modules
const CartAPIService = require('onevzsoemfecommon/CartAPIService');
const { useDispatch } = require('react-redux');
const appMessageActions = require('onevzsoemfecommon/AppMessageActions');
const utilsModule = require('../../../utils/commonFunctions');
const APIServiceHooks = require('../../../modules/services/APIService/APIServiceHooks');

// Mock VDS components
jest.mock('@vds/icons', () => {
  /* eslint-disable global-require */
  const MockReact = require('react');
  const PropTypes = require('prop-types');

  function Icon({ name, size, color, ...props }) {
    return MockReact.createElement('svg', {
      'data-testid': `icon-${name}`,
      'data-size': size,
      'data-color': color,
      ...props,
    });
  }
  Icon.propTypes = {
    name: PropTypes.string,
    size: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
    color: PropTypes.string,
  };
  return { Icon };
});

jest.mock('@vds/button-icons', () => {
  /* eslint-disable global-require */
  const MockReact = require('react');
  const PropTypes = require('prop-types');

  function ButtonIcon({ onClick, renderIcon, ariaLabel, kind, size, ...props }) {
    return MockReact.createElement(
      'button',
      { type: 'button', onClick, 'aria-label': ariaLabel, 'data-kind': kind, 'data-size': size, ...props },
      renderIcon && renderIcon(),
    );
  }
  ButtonIcon.propTypes = {
    onClick: PropTypes.func,
    renderIcon: PropTypes.func,
    ariaLabel: PropTypes.string,
    kind: PropTypes.string,
    size: PropTypes.number,
  };
  return { ButtonIcon };
});

jest.mock('@vds/buttons', () => {
  /* eslint-disable global-require */
  const MockReact = require('react');
  const PropTypes = require('prop-types');

  function Button({ children, onClick, disabled, use, size, ariaLabel, ...props }) {
    return MockReact.createElement(
      'button',
      { type: 'button', disabled, onClick, 'data-use': use, 'data-size': size, 'aria-label': ariaLabel, ...props },
      children,
    );
  }
  Button.propTypes = {
    children: PropTypes.node,
    onClick: PropTypes.func,
    disabled: PropTypes.bool,
    use: PropTypes.string,
    size: PropTypes.string,
    ariaLabel: PropTypes.string,
  };

  function TextLink({ children, onClick, size, ariaLabel, ...props }) {
    return MockReact.createElement(
      'a',
      { onClick, 'data-size': size, 'aria-label': ariaLabel, role: 'button', ...props },
      children,
    );
  }
  TextLink.propTypes = {
    children: PropTypes.node,
    onClick: PropTypes.func,
    size: PropTypes.string,
    ariaLabel: PropTypes.string,
  };

  return { Button, TextLink };
});

jest.mock('@vds/typography', () => {
  /* eslint-disable global-require */
  const MockReact = require('react');
  const PropTypes = require('prop-types');

  function Body({ children, size, color, bold, primitive = 'p', ...props }) {
    const Component = primitive;
    return MockReact.createElement(
      Component,
      { 'data-size': size, 'data-color': color, 'data-bold': bold, ...props },
      children,
    );
  }
  Body.propTypes = {
    children: PropTypes.node,
    size: PropTypes.string,
    color: PropTypes.string,
    bold: PropTypes.bool,
    primitive: PropTypes.string,
  };
  return { Body };
});

jest.mock('@vds/core/icons', () => {
  /* eslint-disable global-require */
  const MockReact = require('react');
  const PropTypes = require('prop-types');

  function GenerativeAiFilled({ size, ...props }) {
    return MockReact.createElement('svg', {
      'data-testid': 'generative-ai-icon',
      'data-size': size,
      ...props,
    });
  }
  GenerativeAiFilled.propTypes = {
    size: PropTypes.number,
  };
  return { GenerativeAiFilled };
});

describe('AccessoryGridwall Component', () => {
  let mockTriggerProductList;
  let mockAddAccessory;
  let mockOnBack;
  let mockDispatch;

  const mockRetrieveCartResult = {
    data: {
      data: {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                mtnDetails: {
                  lineNumber: '9143930197',
                },
                ispuItem: false,
                itemsInfo: [
                  {
                    depletionType: 'WAREHOUSE',
                  },
                ],
              },
            ],
          },
        },
      },
    },
  };

  const mockAccessoriesData = {
    data: {
      gridWall: {
        accessoryList: [
          {
            productDisplayName: 'Premium Case',
            defaultSKU: 'CASE001',
            defaultSKUObj: {
              sorId: 'CASE001',
              color: {
                displayName: 'Black',
              },
              price: {
                fullRetailPrice: {
                  originalPrice: 29.99,
                },
              },
              imageUrlMap: {
                defaultImage: 'https://example.com/case.jpg',
                mediumImage: 'https://example.com/case-medium.jpg',
              },
              isInstorePickupEligible: true,
              inventoryDetails: {
                dFillInventory: {
                  available: 10,
                },
              },
            },
          },
          {
            productDisplayName: 'Screen Protector',
            defaultSKU: 'PROT001',
            defaultSKUObj: {
              sorId: 'PROT001',
              color: {
                displayName: 'Clear',
              },
              price: {
                fullRetailPrice: {
                  originalPrice: 19.99,
                },
              },
              imageUrlMap: {
                defaultImage: 'https://example.com/protector.jpg',
              },
              isInstorePickupEligible: false,
              inventoryDetails: {
                dFillInventory: {},
              },
            },
          },
          {
            productDisplayName: 'Wireless Charger',
            defaultSKU: 'CHRG001',
            defaultSKUObj: {
              sorId: 'CHRG001',
              price: {
                fullRetailPrice: {
                  originalPrice: 39.99,
                },
              },
              imageUrlMap: {},
              inventoryDetails: {
                dFillInventory: {},
              },
            },
          },
        ],
      },
    },
  };

  beforeEach(() => {
    jest.clearAllMocks();

    mockTriggerProductList = jest.fn();
    mockAddAccessory = jest.fn();
    mockOnBack = jest.fn();
    mockDispatch = jest.fn();

    useDispatch.mockReturnValue(mockDispatch);

    jest
      .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
      .mockReturnValue([mockTriggerProductList, { status: 'idle', data: null }]);

    jest
      .spyOn(CartAPIService, 'useLazyAddAccessoryQuery')
      .mockReturnValue([mockAddAccessory, { status: 'idle', data: null }]);

    utilsModule.transformProductListRequest.mockImplementation((params) => params);
    utilsModule.transformAddAccessoryRequest.mockImplementation((params) => params);
  });

  afterEach(() => {
    jest.restoreAllMocks();
    jest.clearAllMocks();
  });

  const renderComponent = (props = {}) =>
    render(
      <AccessoryGridwall
        processingMTN='9143930197'
        retrieveCartResult={mockRetrieveCartResult}
        fetchLandingDataForAiShoppingResult={{}}
        headerTitle='Accessories'
        onBack={mockOnBack}
        {...props}
      />,
    );

  describe('Initial Rendering', () => {
    it('should render the component successfully', () => {
      renderComponent();
      expect(screen.getByText('Cases')).toBeInTheDocument();
      expect(screen.getByText('Screen Protectors')).toBeInTheDocument();
      expect(screen.getByText('Charging')).toBeInTheDocument();
      expect(screen.getByText('Audio')).toBeInTheDocument();
      expect(screen.getByText('Gaming')).toBeInTheDocument();
    });

    it('should call triggerProductList on mount with no category', () => {
      renderComponent();
      expect(mockTriggerProductList).toHaveBeenCalledWith({
        body: { productType: 'accessory', category: '' },
        customHeaders: { flowName: 'WorkspaceQuote' },
        showErrorBanner: true,
      });
    });

    it('should render search and scan icons', () => {
      renderComponent();
      expect(screen.getByLabelText('Search Accessories')).toBeInTheDocument();
      expect(screen.getByLabelText('Scan barcode')).toBeInTheDocument();
    });

    it('should render Cancel and Apply buttons', () => {
      renderComponent();
      expect(screen.getByLabelText('Cancel')).toBeInTheDocument();
      expect(screen.getByLabelText('Apply')).toBeInTheDocument();
    });

    it('should disable Apply button initially', () => {
      renderComponent();
      const applyButton = screen.getByLabelText('Apply');
      expect(applyButton).toBeDisabled();
    });

    it('should render GenerativeAi icon (hidden)', () => {
      renderComponent();
      expect(screen.getByTestId('generative-ai-icon')).toBeInTheDocument();
    });
  });

  describe('Category Filtering', () => {
    it('should handle category selection - Cases', async () => {
      renderComponent();
      const casesButton = screen.getByText('Cases');

      fireEvent.click(casesButton);

      await waitFor(() => {
        expect(mockTriggerProductList).toHaveBeenCalledWith({
          body: { productType: 'accessory', category: 'Cases' },
          customHeaders: { flowName: 'WorkspaceQuote' },
          showErrorBanner: true,
        });
      });
    });

    it('should handle category selection - Screen Protectors', async () => {
      renderComponent();
      const screenProtectorsButton = screen.getByText('Screen Protectors');

      fireEvent.click(screenProtectorsButton);

      await waitFor(() => {
        expect(mockTriggerProductList).toHaveBeenCalledWith({
          body: { productType: 'accessory', category: 'Screen Protectors' },
          customHeaders: { flowName: 'WorkspaceQuote' },
          showErrorBanner: true,
        });
      });
    });

    it('should handle category selection - Charging', async () => {
      renderComponent();
      const chargingButton = screen.getByText('Charging');

      fireEvent.click(chargingButton);

      await waitFor(() => {
        expect(mockTriggerProductList).toHaveBeenCalledWith({
          body: { productType: 'accessory', category: 'Charging' },
          customHeaders: { flowName: 'WorkspaceQuote' },
          showErrorBanner: true,
        });
      });
    });

    it('should handle category selection - Audio', async () => {
      renderComponent();
      const audioButton = screen.getByText('Audio');

      fireEvent.click(audioButton);

      await waitFor(() => {
        expect(mockTriggerProductList).toHaveBeenCalledWith({
          body: { productType: 'accessory', category: 'Audio' },
          customHeaders: { flowName: 'WorkspaceQuote' },
          showErrorBanner: true,
        });
      });
    });

    it('should handle category selection - Gaming', async () => {
      renderComponent();
      const gamingButton = screen.getByText('Gaming');

      fireEvent.click(gamingButton);

      await waitFor(() => {
        expect(mockTriggerProductList).toHaveBeenCalledWith({
          body: { productType: 'accessory', category: 'Gaming' },
          customHeaders: { flowName: 'WorkspaceQuote' },
          showErrorBanner: true,
        });
      });
    });
  });

  describe('Product List API Integration', () => {
    it('should process and display accessories when API returns fulfilled status', async () => {
      // Set mock BEFORE rendering
      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: mockAccessoriesData }]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByText('Premium Case')).toBeInTheDocument();
        expect(screen.getByText('Screen Protector')).toBeInTheDocument();
        expect(screen.getByText('Wireless Charger')).toBeInTheDocument();
      });
    });

    it('should display accessory prices correctly', async () => {
      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: mockAccessoriesData }]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByText('$29.99')).toBeInTheDocument();
        expect(screen.getByText('$19.99')).toBeInTheDocument();
        expect(screen.getByText('$39.99')).toBeInTheDocument();
      });
    });

    it('should display accessory color variants', async () => {
      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: mockAccessoriesData }]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByText('Black')).toBeInTheDocument();
        expect(screen.getByText('Clear')).toBeInTheDocument();
      });
    });

    it('should display accessory SKUs', async () => {
      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: mockAccessoriesData }]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByText('CASE001')).toBeInTheDocument();
        expect(screen.getByText('PROT001')).toBeInTheDocument();
        expect(screen.getByText('CHRG001')).toBeInTheDocument();
      });
    });

    it('should render accessory images when available', async () => {
      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: mockAccessoriesData }]);

      renderComponent();

      await waitFor(() => {
        const images = screen.getAllByRole('img');
        expect(images.length).toBeGreaterThan(0);
      });
    });

    it('should render placeholder icon when image not available', async () => {
      const dataWithoutImages = {
        ...mockAccessoriesData,
        data: {
          ...mockAccessoriesData.data,
          gridWall: {
            ...mockAccessoriesData.data.gridWall,
            accessoryList: [
              {
                ...mockAccessoriesData.data.gridWall.accessoryList[0],
                defaultSKUObj: {
                  ...mockAccessoriesData.data.gridWall.accessoryList[0].defaultSKUObj,
                  imageUrlMap: {
                    defaultImage: null,
                    mediumImage: null,
                  },
                },
              },
            ],
          },
        },
      };

      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: dataWithoutImages }]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId('icon-accessory')).toBeInTheDocument();
      });
    });

    it('should handle rejected API status', async () => {
      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'rejected', data: null }]);

      renderComponent();

      await waitFor(() => {
        // Component should still render without crashing
        expect(screen.getByLabelText('Cancel')).toBeInTheDocument();
      });
    });

    it('should handle empty accessories list', async () => {
      const emptyData = {
        data: {
          gridWall: {
            accessoryList: [],
          },
        },
      };

      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: emptyData }]);

      renderComponent();

      await waitFor(() => {
        expect(screen.queryByText('Premium Case')).not.toBeInTheDocument();
      });
    });

    it('should handle missing gridWall in response', async () => {
      const malformedData = {
        data: {},
      };

      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: malformedData }]);

      renderComponent();

      await waitFor(() => {
        // Should not crash
        expect(screen.getByLabelText('Cancel')).toBeInTheDocument();
      });
    });
  });

  describe('Accessory Selection and Quantity Management', () => {
    beforeEach(() => {
      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: mockAccessoriesData }]);
    });

    it('should show Add button initially for each accessory', async () => {
      renderComponent();

      await waitFor(() => {
        const addButtons = screen.getAllByText('Add');
        expect(addButtons.length).toBe(3);
      });
    });

    it('should add accessory when Add button is clicked', async () => {
      renderComponent();

      await waitFor(() => {
        const addButtons = screen.getAllByText('Add');
        fireEvent.click(addButtons[0]);
      });

      await waitFor(() => {
        expect(screen.getByText('1')).toBeInTheDocument();
      });
    });

    it('should show quantity controls after adding accessory', async () => {
      renderComponent();

      await waitFor(() => {
        const addButtons = screen.getAllByText('Add');
        fireEvent.click(addButtons[0]);
      });

      await waitFor(() => {
        expect(screen.getByLabelText('Remove Accessory')).toBeInTheDocument();
        expect(screen.getByLabelText('Add Accessory')).toBeInTheDocument();
      });
    });

    it('should increment quantity when plus button is clicked', async () => {
      renderComponent();

      await waitFor(() => {
        const addButtons = screen.getAllByText('Add');
        fireEvent.click(addButtons[0]);
      });

      await waitFor(() => {
        const plusButton = screen.getByLabelText('Add Accessory');
        fireEvent.click(plusButton);
      });

      await waitFor(() => {
        expect(screen.getByText('2')).toBeInTheDocument();
      });
    });

    it('should decrement quantity when minus button is clicked', async () => {
      renderComponent();

      await waitFor(() => {
        const addButtons = screen.getAllByText('Add');
        fireEvent.click(addButtons[0]);
      });

      await waitFor(() => {
        const plusButton = screen.getByLabelText('Add Accessory');
        fireEvent.click(plusButton);
      });

      await waitFor(() => {
        const minusButton = screen.getByLabelText('Remove Accessory');
        fireEvent.click(minusButton);
      });

      await waitFor(() => {
        expect(screen.getByText('1')).toBeInTheDocument();
      });
    });

    it('should show Add button again when quantity reaches 0', async () => {
      renderComponent();

      await waitFor(() => {
        const addButtons = screen.getAllByText('Add');
        fireEvent.click(addButtons[0]);
      });

      await waitFor(() => {
        const minusButton = screen.getByLabelText('Remove Accessory');
        fireEvent.click(minusButton);
      });

      await waitFor(() => {
        expect(screen.getAllByText('Add').length).toBe(3);
      });
    });

    it('should enable Apply button when accessories are selected', async () => {
      renderComponent();

      const applyButton = screen.getByLabelText('Apply');
      expect(applyButton).toBeDisabled();

      await waitFor(() => {
        const addButtons = screen.getAllByText('Add');
        fireEvent.click(addButtons[0]);
      });

      await waitFor(() => {
        expect(applyButton).not.toBeDisabled();
      });
    });

    it('should handle multiple accessories selection', async () => {
      renderComponent();

      await waitFor(() => {
        const addButtons = screen.getAllByText('Add');
        fireEvent.click(addButtons[0]);
        fireEvent.click(addButtons[1]);
      });

      await waitFor(() => {
        const quantities = screen.getAllByText('1');
        expect(quantities.length).toBe(2);
      });
    });
  });

  describe('Configure Link', () => {
    beforeEach(() => {
      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: mockAccessoriesData }]);
    });

    it('should render Configure link for each accessory', async () => {
      renderComponent();

      await waitFor(() => {
        const configureLinks = screen.getAllByText('Configure');
        expect(configureLinks.length).toBe(3);
      });
    });

    it('should handle Configure link click', async () => {
      const consoleSpy = jest.spyOn(console, 'log').mockImplementation();
      renderComponent();

      await waitFor(() => {
        const configureLinks = screen.getAllByText('Configure');
        fireEvent.click(configureLinks[0]);
      });

      expect(consoleSpy).toHaveBeenCalledWith('Configure:', expect.any(Object));
      consoleSpy.mockRestore();
    });
  });

  describe('Search and Scan Actions', () => {
    it('should handle search button click', () => {
      const consoleSpy = jest.spyOn(console, 'log').mockImplementation();
      renderComponent();

      const searchButton = screen.getByLabelText('Search Accessories');
      fireEvent.click(searchButton);

      expect(consoleSpy).toHaveBeenCalledWith('Search clicked');
      consoleSpy.mockRestore();
    });

    it('should handle scan button click', () => {
      const consoleSpy = jest.spyOn(console, 'log').mockImplementation();
      renderComponent();

      const scanButton = screen.getByLabelText('Scan barcode');
      fireEvent.click(scanButton);

      expect(consoleSpy).toHaveBeenCalledWith('Scan clicked');
      consoleSpy.mockRestore();
    });

    it('should render search icon', () => {
      renderComponent();
      expect(screen.getByTestId('icon-search')).toBeInTheDocument();
    });

    it('should render barcode icon', () => {
      renderComponent();
      expect(screen.getByTestId('icon-barcode')).toBeInTheDocument();
    });
  });

  describe('Cancel and Apply Actions', () => {
    it('should call onBack when Cancel button is clicked', () => {
      renderComponent();

      const cancelButton = screen.getByLabelText('Cancel');
      fireEvent.click(cancelButton);

      expect(mockOnBack).toHaveBeenCalledWith('Accessories');
    });

    it('should call addAccessory API when Apply button is clicked with selections', async () => {
      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: mockAccessoriesData }]);

      renderComponent();

      await waitFor(() => {
        const addButtons = screen.getAllByText('Add');
        fireEvent.click(addButtons[0]);
      });

      await waitFor(() => {
        const applyButton = screen.getByLabelText('Apply');
        fireEvent.click(applyButton);
      });

      expect(mockAddAccessory).toHaveBeenCalledWith({
        body: expect.any(Object),
        customHeaders: { flowName: 'WorkspaceQuote' },
        showErrorBanner: true,
      });
    });

    it('should not call addAccessory API when Apply is clicked without selections', () => {
      renderComponent();

      const applyButton = screen.getByLabelText('Apply');
      // Button is disabled, so click won't trigger
      expect(applyButton).toBeDisabled();
    });

    it('should call transformAddAccessoryRequest with correct parameters', async () => {
      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: mockAccessoriesData }]);

      renderComponent();

      await waitFor(() => {
        const addButtons = screen.getAllByText('Add');
        fireEvent.click(addButtons[0]);
      });

      await waitFor(() => {
        const applyButton = screen.getByLabelText('Apply');
        fireEvent.click(applyButton);
      });

      expect(utilsModule.transformAddAccessoryRequest).toHaveBeenCalledWith({
        mtn: '9143930197',
        addAccessoriesList: expect.arrayContaining([
          expect.objectContaining({
            id: 'CASE001',
            qty: 1,
          }),
        ]),
        isIspuCheck: false,
        aciveLineDepletionType: 'WAREHOUSE',
      });
    });

    it('should call onBack when addAccessoryResult.isSuccess is true', async () => {
      const successResult = { status: 'fulfilled', isSuccess: true, isError: false, data: {} };

      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: mockAccessoriesData }]);

      jest.spyOn(CartAPIService, 'useLazyAddAccessoryQuery').mockReturnValue([mockAddAccessory, successResult]);

      render(
        <AccessoryGridwall
          processingMTN='9143930197'
          retrieveCartResult={mockRetrieveCartResult}
          headerTitle='Accessories'
          onBack={mockOnBack}
        />,
      );

      await waitFor(() => {
        expect(mockOnBack).toHaveBeenCalledWith('Accessories');
      });
    });

    it('should show error message when addAccessoryResult.isError is true', async () => {
      const errorResult = { status: 'rejected', isSuccess: false, isError: true, data: null };

      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: mockAccessoriesData }]);

      jest.spyOn(CartAPIService, 'useLazyAddAccessoryQuery').mockReturnValue([mockAddAccessory, errorResult]);

      render(
        <AccessoryGridwall
          processingMTN='9143930197'
          retrieveCartResult={mockRetrieveCartResult}
          headerTitle='Accessories'
          onBack={mockOnBack}
        />,
      );

      await waitFor(() => {
        expect(mockDispatch).toHaveBeenCalled();
      });

      expect(appMessageActions.addAppMessage).toHaveBeenCalledWith(
        'Sorry could not add accessory , please try again after sometime.',
        'error',
        true,
        true,
      );
    });

    it('should not call onBack when addAccessoryResult.isSuccess is false', async () => {
      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: mockAccessoriesData }]);

      jest
        .spyOn(CartAPIService, 'useLazyAddAccessoryQuery')
        .mockReturnValue([mockAddAccessory, { status: 'idle', isSuccess: false, isError: false }]);

      render(
        <AccessoryGridwall
          processingMTN='9143930197'
          retrieveCartResult={mockRetrieveCartResult}
          headerTitle='Accessories'
          onBack={mockOnBack}
        />,
      );

      await waitFor(() => {
        expect(screen.getByLabelText('Cancel')).toBeInTheDocument();
      });

      // onBack should not be called when isSuccess is false
      expect(mockOnBack).not.toHaveBeenCalled();
    });

    it('should react to changes in addAccessoryResult dependencies', async () => {
      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: mockAccessoriesData }]);

      // Start with idle
      jest
        .spyOn(CartAPIService, 'useLazyAddAccessoryQuery')
        .mockReturnValue([mockAddAccessory, { status: 'idle', isSuccess: false, isError: false, data: null }]);

      const { rerender } = render(
        <AccessoryGridwall
          processingMTN='9143930197'
          retrieveCartResult={mockRetrieveCartResult}
          headerTitle='Accessories'
          onBack={mockOnBack}
        />,
      );

      // Change to success with different data
      jest
        .spyOn(CartAPIService, 'useLazyAddAccessoryQuery')
        .mockReturnValue([
          mockAddAccessory,
          { status: 'fulfilled', isSuccess: true, isError: false, data: { success: true } },
        ]);

      rerender(
        <AccessoryGridwall
          processingMTN='9143930197'
          retrieveCartResult={mockRetrieveCartResult}
          headerTitle='Accessories'
          onBack={mockOnBack}
        />,
      );

      await waitFor(() => {
        expect(mockOnBack).toHaveBeenCalledWith('Accessories');
      });
    });
  });

  describe('Cart Result Processing', () => {
    it('should extract active line from retrieveCartResult', () => {
      renderComponent();
      // Component should process cart data without errors
      expect(screen.getByLabelText('Cancel')).toBeInTheDocument();
    });

    it('should handle ispu item flag', () => {
      const ispuCartResult = {
        data: {
          data: {
            cart: {
              lineDetails: {
                lineInfo: [
                  {
                    mtnDetails: {
                      lineNumber: '9143930197',
                    },
                    ispuItem: true,
                    itemsInfo: [
                      {
                        depletionType: 'STORE',
                      },
                    ],
                  },
                ],
              },
            },
          },
        },
      };

      renderComponent({ retrieveCartResult: ispuCartResult });
      expect(screen.getByLabelText('Cancel')).toBeInTheDocument();
    });

    it('should handle missing lineInfo gracefully', () => {
      const emptyCartResult = {
        data: {
          data: {
            cart: {
              lineDetails: {
                lineInfo: [],
              },
            },
          },
        },
      };

      renderComponent({ retrieveCartResult: emptyCartResult });
      expect(screen.getByLabelText('Cancel')).toBeInTheDocument();
    });

    it('should handle different processingMTN', () => {
      renderComponent({ processingMTN: '9999999999' });
      expect(screen.getByLabelText('Cancel')).toBeInTheDocument();
    });
  });

  describe('Props Validation', () => {
    it('should use default processingMTN when not provided', () => {
      const { container } = render(
        <AccessoryGridwall
          retrieveCartResult={mockRetrieveCartResult}
          fetchLandingDataForAiShoppingResult={{}}
          headerTitle='Accessories'
          onBack={mockOnBack}
        />,
      );
      expect(container).toBeInTheDocument();
    });

    it('should handle empty fetchLandingDataForAiShoppingResult', () => {
      renderComponent({ fetchLandingDataForAiShoppingResult: {} });
      expect(screen.getByLabelText('Cancel')).toBeInTheDocument();
    });

    it('should log fetchLandingDataForAiShoppingResult on render', () => {
      const consoleSpy = jest.spyOn(console, 'log').mockImplementation();
      const mockFetchResult = { someData: 'test' };

      renderComponent({ fetchLandingDataForAiShoppingResult: mockFetchResult });

      expect(consoleSpy).toHaveBeenCalledWith(
        mockFetchResult,
        'fetchLandingDataForAiShoppingResult in AccessoryGridwall',
      );
      consoleSpy.mockRestore();
    });

    it('should handle missing headerTitle prop', () => {
      const { container } = render(
        <AccessoryGridwall
          processingMTN='9143930197'
          retrieveCartResult={mockRetrieveCartResult}
          fetchLandingDataForAiShoppingResult={{}}
          onBack={mockOnBack}
        />,
      );
      expect(container).toBeInTheDocument();
    });
  });

  describe('Edge Cases and Error Handling', () => {
    it('should handle missing defaultSKUObj properties', async () => {
      const incompleteData = {
        data: {
          gridWall: {
            accessoryList: [
              {
                productDisplayName: 'Minimal Accessory',
                defaultSKU: 'ACC999',
                defaultSKUObj: {},
              },
            ],
          },
        },
      };

      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: incompleteData }]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByText('Minimal Accessory')).toBeInTheDocument();
      });
    });

    it('should handle accessory without defaultSKU but with sorId', async () => {
      const dataWithSorId = {
        data: {
          gridWall: {
            accessoryList: [
              {
                productDisplayName: 'SorId Accessory',
                defaultSKU: '',
                defaultSKUObj: {
                  sorId: 'SOR123',
                  price: {
                    fullRetailPrice: {
                      originalPrice: 25,
                    },
                  },
                  inventoryDetails: {
                    dFillInventory: {},
                  },
                },
              },
            ],
          },
        },
      };

      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: dataWithSorId }]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByText('SorId Accessory')).toBeInTheDocument();
        expect(screen.getByText('SOR123')).toBeInTheDocument();
      });
    });

    it('should handle accessory with mediumImage but no defaultImage', async () => {
      const dataWithMediumImage = {
        data: {
          gridWall: {
            accessoryList: [
              {
                productDisplayName: 'Medium Image Accessory',
                defaultSKU: 'ACC777',
                defaultSKUObj: {
                  sorId: 'ACC777',
                  price: {
                    fullRetailPrice: {
                      originalPrice: 15,
                    },
                  },
                  imageUrlMap: {
                    mediumImage: 'http://example.com/medium.jpg',
                  },
                  inventoryDetails: {
                    dFillInventory: {},
                  },
                },
              },
            ],
          },
        },
      };

      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: dataWithMediumImage }]);

      renderComponent();

      await waitFor(() => {
        const images = screen.getAllByRole('img');
        expect(images.length).toBeGreaterThan(0);
      });
    });

    it('should initialize accessories with qty 0', async () => {
      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: mockAccessoriesData }]);

      renderComponent();

      await waitFor(() => {
        const applyButton = screen.getByLabelText('Apply');
        expect(applyButton).toBeDisabled();
      });
    });

    it('should handle rapid category changes', async () => {
      renderComponent();

      const casesButton = screen.getByText('Cases');
      const audioButton = screen.getByText('Audio');

      fireEvent.click(casesButton);
      fireEvent.click(audioButton);
      fireEvent.click(casesButton);

      await waitFor(() => {
        expect(mockTriggerProductList).toHaveBeenCalledTimes(4); // Initial + 3 category changes
      });
    });

    it('should handle null price value', async () => {
      const dataWithNullPrice = {
        data: {
          gridWall: {
            accessoryList: [
              {
                productDisplayName: 'Free Accessory',
                defaultSKU: 'ACC000',
                defaultSKUObj: {
                  sorId: 'ACC000',
                  price: {
                    fullRetailPrice: {
                      originalPrice: 0,
                    },
                  },
                  imageUrlMap: {},
                  inventoryDetails: {
                    dFillInventory: {},
                  },
                },
              },
            ],
          },
        },
      };

      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: dataWithNullPrice }]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByText('$0')).toBeInTheDocument();
      });
    });
  });

  describe('useEffect Hooks', () => {
    it('should call getAccessories only once on mount', () => {
      renderComponent();
      expect(mockTriggerProductList).toHaveBeenCalledTimes(1);
    });

    it('should update accessoriesList when productListResult status changes to fulfilled', async () => {
      const { rerender } = render(
        <AccessoryGridwall
          processingMTN='9143930197'
          retrieveCartResult={mockRetrieveCartResult}
          fetchLandingDataForAiShoppingResult={{}}
          headerTitle='Accessories'
          onBack={mockOnBack}
        />,
      );

      // Update mock to return fulfilled status
      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: mockAccessoriesData }]);

      rerender(
        <AccessoryGridwall
          processingMTN='9143930197'
          retrieveCartResult={mockRetrieveCartResult}
          fetchLandingDataForAiShoppingResult={{}}
          headerTitle='Accessories'
          onBack={mockOnBack}
        />,
      );

      await waitFor(() => {
        expect(screen.getByText('Premium Case')).toBeInTheDocument();
      });
    });

    it('should not update accessoriesList when productListResult status is idle', () => {
      renderComponent();
      expect(screen.queryByText('Premium Case')).not.toBeInTheDocument();
    });

    it('should trigger getAccessories when activeCategory changes', async () => {
      renderComponent();

      const initialCalls = mockTriggerProductList.mock.calls.length;

      const casesButton = screen.getByText('Cases');
      fireEvent.click(casesButton);

      await waitFor(() => {
        expect(mockTriggerProductList).toHaveBeenCalledTimes(initialCalls + 1);
      });
    });
  });

  describe('Accessibility', () => {
    beforeEach(() => {
      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: mockAccessoriesData }]);
    });

    it('should have proper aria-labels for action buttons', () => {
      renderComponent();
      expect(screen.getByLabelText('Search Accessories')).toBeInTheDocument();
      expect(screen.getByLabelText('Scan barcode')).toBeInTheDocument();
      expect(screen.getByLabelText('Cancel')).toBeInTheDocument();
      expect(screen.getByLabelText('Apply')).toBeInTheDocument();
    });

    it('should have proper aria-labels for filter buttons', () => {
      renderComponent();
      expect(screen.getByLabelText('Filter by Cases')).toBeInTheDocument();
      expect(screen.getByLabelText('Filter by Screen Protectors')).toBeInTheDocument();
      expect(screen.getByLabelText('Filter by Charging')).toBeInTheDocument();
      expect(screen.getByLabelText('Filter by Audio')).toBeInTheDocument();
      expect(screen.getByLabelText('Filter by Gaming')).toBeInTheDocument();
    });

    it('should have proper aria-labels for Add buttons', async () => {
      renderComponent();

      await waitFor(() => {
        expect(screen.getByLabelText('Add Premium Case')).toBeInTheDocument();
        expect(screen.getByLabelText('Add Screen Protector')).toBeInTheDocument();
        expect(screen.getByLabelText('Add Wireless Charger')).toBeInTheDocument();
      });
    });

    it('should have proper aria-labels for quantity controls', async () => {
      renderComponent();

      await waitFor(() => {
        const addButtons = screen.getAllByText('Add');
        fireEvent.click(addButtons[0]);
      });

      await waitFor(() => {
        expect(screen.getByLabelText('Remove Accessory')).toBeInTheDocument();
        expect(screen.getByLabelText('Add Accessory')).toBeInTheDocument();
      });
    });

    it('should have proper aria-labels for Configure links', async () => {
      renderComponent();

      await waitFor(() => {
        expect(screen.getByLabelText('Configure Premium Case')).toBeInTheDocument();
        expect(screen.getByLabelText('Configure Screen Protector')).toBeInTheDocument();
        expect(screen.getByLabelText('Configure Wireless Charger')).toBeInTheDocument();
      });
    });
  });

  describe('Styled Components Rendering', () => {
    it('should render PageContainer', () => {
      const { container } = renderComponent();
      expect(container.firstChild).toBeInTheDocument();
    });

    it('should render ContentWrapper', () => {
      renderComponent();
      expect(screen.getByLabelText('Cancel').closest('div')).toBeInTheDocument();
    });

    it('should render category filters with correct use prop', () => {
      renderComponent();
      const casesButton = screen.getByText('Cases');
      expect(casesButton).toHaveAttribute('data-use', 'secondary');

      fireEvent.click(casesButton);
      // After click, it should become primary (in real implementation)
    });
  });

  describe('Console Logs', () => {
    it('should log category change', () => {
      const consoleSpy = jest.spyOn(console, 'log').mockImplementation();
      renderComponent();

      const casesButton = screen.getByText('Cases');
      fireEvent.click(casesButton);

      expect(consoleSpy).toHaveBeenCalledWith('Category changed to:', 'Cases');
      consoleSpy.mockRestore();
    });

    it('should log accessory selection', async () => {
      const consoleSpy = jest.spyOn(console, 'log').mockImplementation();
      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: mockAccessoriesData }]);

      renderComponent();

      await waitFor(() => {
        const addButtons = screen.getAllByText('Add');
        fireEvent.click(addButtons[0]);
      });

      expect(consoleSpy).toHaveBeenCalledWith('Selected accessory:', 'CASE001');
      consoleSpy.mockRestore();
    });

    it('should log quantity increment', async () => {
      const consoleSpy = jest.spyOn(console, 'log').mockImplementation();
      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: mockAccessoriesData }]);

      renderComponent();

      await waitFor(() => {
        const addButtons = screen.getAllByText('Add');
        fireEvent.click(addButtons[0]);
      });

      await waitFor(() => {
        const plusButton = screen.getByLabelText('Add Accessory');
        fireEvent.click(plusButton);
      });

      expect(consoleSpy).toHaveBeenCalledWith('Increased accessory with id:', 'CASE001');
      consoleSpy.mockRestore();
    });

    it('should log quantity decrement', async () => {
      const consoleSpy = jest.spyOn(console, 'log').mockImplementation();
      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: mockAccessoriesData }]);

      renderComponent();

      await waitFor(() => {
        const addButtons = screen.getAllByText('Add');
        fireEvent.click(addButtons[0]);
      });

      await waitFor(() => {
        const minusButton = screen.getByLabelText('Remove Accessory');
        fireEvent.click(minusButton);
      });

      expect(consoleSpy).toHaveBeenCalledWith('Decreased accessory with id:', 'CASE001');
      consoleSpy.mockRestore();
    });

    it('should log cancel action', () => {
      const consoleSpy = jest.spyOn(console, 'log').mockImplementation();
      renderComponent();

      const cancelButton = screen.getByLabelText('Cancel');
      fireEvent.click(cancelButton);

      expect(consoleSpy).toHaveBeenCalledWith('Cancel clicked');
      consoleSpy.mockRestore();
    });
  });

  describe('Complex Interactions', () => {
    beforeEach(() => {
      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: mockAccessoriesData }]);
    });

    it('should handle adding multiple quantities of same accessory', async () => {
      renderComponent();

      await waitFor(() => {
        const addButtons = screen.getAllByText('Add');
        fireEvent.click(addButtons[0]);
      });

      await waitFor(() => {
        const plusButton = screen.getByLabelText('Add Accessory');
        fireEvent.click(plusButton);
        fireEvent.click(plusButton);
        fireEvent.click(plusButton);
      });

      await waitFor(() => {
        expect(screen.getByText('4')).toBeInTheDocument();
      });
    });

    it('should handle adding and removing multiple accessories', async () => {
      renderComponent();

      await waitFor(() => {
        const addButtons = screen.getAllByText('Add');
        fireEvent.click(addButtons[0]);
        fireEvent.click(addButtons[1]);
        fireEvent.click(addButtons[2]);
      });

      await waitFor(() => {
        const quantities = screen.getAllByText('1');
        expect(quantities.length).toBe(3);
      });

      await waitFor(() => {
        const minusButtons = screen.getAllByLabelText('Remove Accessory');
        fireEvent.click(minusButtons[0]);
      });

      await waitFor(() => {
        const quantities = screen.getAllByText('1');
        expect(quantities.length).toBe(2);
      });
    });

    it('should maintain selections after category change', async () => {
      renderComponent();

      await waitFor(() => {
        const addButtons = screen.getAllByText('Add');
        fireEvent.click(addButtons[0]);
      });

      const audioButton = screen.getByText('Audio');
      fireEvent.click(audioButton);

      // Note: In real implementation, selections might be cleared or maintained
      // This test documents current behavior
      await waitFor(() => {
        expect(mockTriggerProductList).toHaveBeenCalledWith({
          body: { productType: 'accessory', category: 'Audio' },
          customHeaders: { flowName: 'WorkspaceQuote' },
          showErrorBanner: true,
        });
      });
    });

    it('should enable Apply when any accessory has quantity > 0', async () => {
      renderComponent();

      const applyButton = screen.getByLabelText('Apply');
      expect(applyButton).toBeDisabled();

      await waitFor(() => {
        const addButtons = screen.getAllByText('Add');
        fireEvent.click(addButtons[1]);
      });

      await waitFor(() => {
        expect(applyButton).not.toBeDisabled();
      });
    });
  });

  describe('Utility Functions', () => {
    it('should call transformProductListRequest correctly', () => {
      renderComponent();

      expect(utilsModule.transformProductListRequest).toHaveBeenCalledWith({
        productType: 'accessory',
        category: '',
      });
    });

    it('should call transformProductListRequest with category', async () => {
      renderComponent();

      const casesButton = screen.getByText('Cases');
      fireEvent.click(casesButton);

      await waitFor(() => {
        expect(utilsModule.transformProductListRequest).toHaveBeenCalledWith({
          productType: 'accessory',
          category: 'Cases',
        });
      });
    });
  });

  describe('Branch Coverage - Missing Branches', () => {
    it('should handle accessory with no defaultSKU falling back to sorId', async () => {
      const dataWithOnlySorId = {
        data: {
          gridWall: {
            accessoryList: [
              {
                productDisplayName: 'Test Accessory',
                defaultSKU: '',
                defaultSKUObj: {
                  sorId: 'SORID123',
                  price: {
                    fullRetailPrice: {
                      originalPrice: 10,
                    },
                  },
                  inventoryDetails: {
                    dFillInventory: {},
                  },
                },
              },
            ],
          },
        },
      };

      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: dataWithOnlySorId }]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByText('SORID123')).toBeInTheDocument();
      });
    });

    it('should handle accessory with no defaultSKU and no sorId', async () => {
      const dataWithNoIds = {
        data: {
          gridWall: {
            accessoryList: [
              {
                productDisplayName: 'No ID Accessory',
                defaultSKU: '',
                defaultSKUObj: {
                  sorId: '',
                  price: {
                    fullRetailPrice: {
                      originalPrice: 10,
                    },
                  },
                  inventoryDetails: {
                    dFillInventory: {},
                  },
                },
              },
            ],
          },
        },
      };

      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: dataWithNoIds }]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByText('No ID Accessory')).toBeInTheDocument();
      });
    });

    it('should handle accessory with no productDisplayName', async () => {
      const dataWithNoName = {
        data: {
          gridWall: {
            accessoryList: [
              {
                productDisplayName: '',
                defaultSKU: 'TEST001',
                defaultSKUObj: {
                  sorId: 'TEST001',
                  price: {
                    fullRetailPrice: {
                      originalPrice: 10,
                    },
                  },
                  inventoryDetails: {
                    dFillInventory: {},
                  },
                },
              },
            ],
          },
        },
      };

      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: dataWithNoName }]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByText('TEST001')).toBeInTheDocument();
      });
    });

    it('should handle accessory with no color displayName', async () => {
      const dataWithNoColor = {
        data: {
          gridWall: {
            accessoryList: [
              {
                productDisplayName: 'No Color Accessory',
                defaultSKU: 'TEST002',
                defaultSKUObj: {
                  sorId: 'TEST002',
                  color: {
                    displayName: '',
                  },
                  price: {
                    fullRetailPrice: {
                      originalPrice: 10,
                    },
                  },
                  inventoryDetails: {
                    dFillInventory: {},
                  },
                },
              },
            ],
          },
        },
      };

      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: dataWithNoColor }]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByText('No Color Accessory')).toBeInTheDocument();
      });
    });

    it('should handle accessory with defaultImage preference over mediumImage', async () => {
      const dataWithBothImages = {
        data: {
          gridWall: {
            accessoryList: [
              {
                productDisplayName: 'Both Images Accessory',
                defaultSKU: 'IMG001',
                defaultSKUObj: {
                  sorId: 'IMG001',
                  price: {
                    fullRetailPrice: {
                      originalPrice: 10,
                    },
                  },
                  imageUrlMap: {
                    defaultImage: 'https://example.com/default.jpg',
                    mediumImage: 'https://example.com/medium.jpg',
                  },
                  inventoryDetails: {
                    dFillInventory: {},
                  },
                },
              },
            ],
          },
        },
      };

      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: dataWithBothImages }]);

      renderComponent();

      await waitFor(() => {
        const images = screen.getAllByRole('img');
        const accessoryImage = images.find((img) => img.src.includes('default.jpg'));
        expect(accessoryImage).toBeTruthy();
      });
    });

    it('should not call getAccessories when activeCategory is empty', () => {
      renderComponent();

      const initialCallCount = mockTriggerProductList.mock.calls.length;

      // activeCategory is empty by default, useEffect should not call getAccessories again
      expect(mockTriggerProductList).toHaveBeenCalledTimes(initialCallCount);
    });

    it('should handle retrieveCartResult with missing nested properties', () => {
      const emptyCartResult = {
        data: {},
      };

      render(
        <AccessoryGridwall
          processingMTN='9143930197'
          retrieveCartResult={emptyCartResult}
          fetchLandingDataForAiShoppingResult={{}}
          headerTitle='Accessories'
          onBack={mockOnBack}
        />,
      );

      // Should render without crashing
      expect(screen.getByText('Cases')).toBeInTheDocument();
    });

    it('should handle activeLine with no ispuItem property', () => {
      const cartResultWithoutIspu = {
        data: {
          data: {
            cart: {
              lineDetails: {
                lineInfo: [
                  {
                    mtnDetails: {
                      lineNumber: '9143930197',
                    },
                    itemsInfo: [
                      {
                        depletionType: 'WAREHOUSE',
                      },
                    ],
                  },
                ],
              },
            },
          },
        },
      };

      render(
        <AccessoryGridwall
          processingMTN='9143930197'
          retrieveCartResult={cartResultWithoutIspu}
          fetchLandingDataForAiShoppingResult={{}}
          headerTitle='Accessories'
          onBack={mockOnBack}
        />,
      );

      expect(screen.getByText('Cases')).toBeInTheDocument();
    });

    it('should handle activeLine with no depletionType', () => {
      const cartResultWithoutDepletion = {
        data: {
          data: {
            cart: {
              lineDetails: {
                lineInfo: [
                  {
                    mtnDetails: {
                      lineNumber: '9143930197',
                    },
                    ispuItem: false,
                    itemsInfo: [
                      {
                        depletionType: '',
                      },
                    ],
                  },
                ],
              },
            },
          },
        },
      };

      render(
        <AccessoryGridwall
          processingMTN='9143930197'
          retrieveCartResult={cartResultWithoutDepletion}
          fetchLandingDataForAiShoppingResult={{}}
          headerTitle='Accessories'
          onBack={mockOnBack}
        />,
      );

      expect(screen.getByText('Cases')).toBeInTheDocument();
    });

    it('should handle accessory without isInstorePickupEligible property', async () => {
      const dataWithoutIspu = {
        data: {
          gridWall: {
            accessoryList: [
              {
                productDisplayName: 'No ISPU Property',
                defaultSKU: 'NOISPU001',
                defaultSKUObj: {
                  sorId: 'NOISPU001',
                  price: {
                    fullRetailPrice: {
                      originalPrice: 10,
                    },
                  },
                  inventoryDetails: {
                    dFillInventory: {},
                  },
                },
              },
            ],
          },
        },
      };

      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: dataWithoutIspu }]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByText('No ISPU Property')).toBeInTheDocument();
      });
    });

    it('should render non-breaking space for empty colorVariant', async () => {
      const dataWithNoColorVariant = {
        data: {
          gridWall: {
            accessoryList: [
              {
                productDisplayName: 'No Variant',
                defaultSKU: 'NOVAR001',
                defaultSKUObj: {
                  sorId: 'NOVAR001',
                  price: {
                    fullRetailPrice: {
                      originalPrice: 10,
                    },
                  },
                  inventoryDetails: {
                    dFillInventory: {},
                  },
                },
              },
            ],
          },
        },
      };

      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: dataWithNoColorVariant }]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByText('No Variant')).toBeInTheDocument();
      });
    });

    it('should render non-breaking space for empty id', async () => {
      const dataWithNoId = {
        data: {
          gridWall: {
            accessoryList: [
              {
                productDisplayName: 'Empty ID Accessory',
                defaultSKU: '',
                defaultSKUObj: {
                  sorId: '',
                  price: {
                    fullRetailPrice: {
                      originalPrice: 10,
                    },
                  },
                  inventoryDetails: {
                    dFillInventory: {},
                  },
                },
              },
            ],
          },
        },
      };

      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: dataWithNoId }]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByText('Empty ID Accessory')).toBeInTheDocument();
      });
    });

    it('should use default processingMTN when not provided', () => {
      render(
        <AccessoryGridwall
          retrieveCartResult={mockRetrieveCartResult}
          fetchLandingDataForAiShoppingResult={{}}
          headerTitle='Accessories'
          onBack={mockOnBack}
        />,
      );

      expect(screen.getByText('Cases')).toBeInTheDocument();
    });

    it('should use default fetchLandingDataForAiShoppingResult when not provided', () => {
      render(
        <AccessoryGridwall
          processingMTN='9143930197'
          retrieveCartResult={mockRetrieveCartResult}
          headerTitle='Accessories'
          onBack={mockOnBack}
        />,
      );

      expect(screen.getByText('Cases')).toBeInTheDocument();
    });

    it('should handle accessory with null defaultSKUObj', async () => {
      const dataWithNullSKUObj = {
        data: {
          gridWall: {
            accessoryList: [
              {
                productDisplayName: 'Null SKU Object',
                defaultSKU: 'NULLSKU001',
                defaultSKUObj: null,
              },
            ],
          },
        },
      };

      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: dataWithNullSKUObj }]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByText('Null SKU Object')).toBeInTheDocument();
      });
    });

    it('should handle accessory with undefined defaultSKUObj', async () => {
      const dataWithUndefinedSKUObj = {
        data: {
          gridWall: {
            accessoryList: [
              {
                productDisplayName: 'Undefined SKU Object',
                defaultSKU: 'UNDEFSKU001',
              },
            ],
          },
        },
      };

      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { status: 'fulfilled', data: dataWithUndefinedSKUObj }]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByText('Undefined SKU Object')).toBeInTheDocument();
      });
    });
  });
});
