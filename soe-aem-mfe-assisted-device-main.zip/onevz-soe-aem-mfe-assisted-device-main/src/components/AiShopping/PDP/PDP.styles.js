import styled from 'styled-components';
import { Body } from '@vds/typography';
import { BREAKPOINTS } from './PDP.constants';

// Full page container
export const PageContainer = styled.div`
  height: 100vh;
  display: flex;
  flex-direction: column;
  background-color: #f8f7f5;
  overflow: hidden;
`;

// Header wrapper with white background - sticky at top
export const HeaderWrapper = styled.div`
  position: sticky;
  top: 0;
  z-index: 100;
  width: 100%;
  background-color: #ffffff;
  border-bottom: 1px solid #d8dada;
  flex-shrink: 0;
`;

// Header content
export const Header = styled.div`
  width: 100%;
  max-width: 70.8125rem; /* 1133px */
  height: 4.25rem; /* 68px */
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 0 1.5rem;
  margin: 0 auto;
  box-sizing: border-box;

  @media (max-width: ${BREAKPOINTS.tablet}) {
    max-width: 100%;
    height: 3.75rem;
    padding: 0 1.25rem;
  }

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    height: 3.5rem;
    gap: 0.75rem;
    padding: 0 1rem;
  }
`;

// Back button container
export const BackButtonContainer = styled.div`
  display: flex;
  align-items: center;
  flex-shrink: 0;
`;

// Content wrapper - scrollable body with padding for fixed footer
export const ContentWrapper = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  padding: 1.5rem;
  padding-bottom: 5.5rem; /* Space for fixed footer (reduced since we removed monthly total) */
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;

  @media (max-width: ${BREAKPOINTS.tablet}) {
    padding: 1.25rem;
    padding-bottom: 5rem;
  }

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    padding: 1rem;
    padding-bottom: 4.5rem;
  }
`;

// Content card
export const ContentCard = styled.div`
  width: 100%;
  max-width: 67.8125rem; /* 1085px */
  background-color: #ffffff;
  border-radius: 1rem; /* 16px */
  padding: 1rem 1.5rem; /* 16px 24px */
  display: flex;
  flex-direction: column;
  gap: 2rem; /* 32px */
  box-sizing: border-box;
  margin: 0 auto;

  @media (max-width: ${BREAKPOINTS.tablet}) {
    max-width: 100%;
    padding: 1rem;
    gap: 1.5rem;
  }

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    padding: 0.875rem;
    gap: 1rem;
    border-radius: 0.75rem;
  }
`;

// Section header
export const SectionHeader = styled.div`
  display: flex;
  width: 100%;
  align-items: center;
  gap: 0.5rem; /* 8px */
`;

// Main content layout
export const MainContent = styled.div`
  display: flex;
  width: 100%;
  gap: 1.5rem; /* 24px */
  flex-wrap: wrap;

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    gap: 1rem;
  }
`;

// Left section - device info
export const LeftSection = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1.5rem; /* 24px */
  width: 322px;
  flex-shrink: 0;

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    width: 100%;
  }
`;

// Device name section
export const DeviceNameSection = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.75rem; /* 12px */
  width: 277px;

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    width: 100%;
  }
`;

// Device image container
export const DeviceImageContainer = styled.div`
  width: 189px;
  height: 235px;
  display: flex;
  align-items: center;
  justify-content: center;

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    width: 150px;
    height: 186px;
    margin: 0 auto;
  }
`;

// Device image
export const DeviceImg = styled.img`
  width: 100%;
  height: 100%;
  object-fit: contain;
`;

// Comparison section
export const ComparisonSection = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem; /* 8px */
  width: 322px;

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    width: 100%;
  }
`;

// Value props list
export const ValueProps = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.25rem; /* 4px */
`;

// Right section - color & storage
export const RightSection = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1.5rem; /* 24px */
  flex: 1;
  min-width: 280px;
`;

// Color section
export const ColorSection = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.75rem; /* 12px */
  width: 218px;

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    width: 100%;
  }
`;

// Swatch container
export const SwatchContainer = styled.div`
  display: flex;
  align-items: center;
  gap: 14px;
`;

// Color swatch button
export const Swatch = styled.button`
  width: 44px;
  height: 44px;
  border-radius: 50%;
  cursor: pointer;
  transition: all 0.2s ease;
  padding: 0;
  background-color: ${(props) => props.$color};
  border: ${(props) => (props.$selected ? '2px solid #000000' : '2px solid rgba(0, 0, 0, 0.15)')};
  box-shadow: ${(props) => (props.$selected ? 'inset 0 0 0 4px #F2EAE4' : 'none')};

  &:hover {
    border-color: rgba(0, 0, 0, 0.4);
  }

  &:focus {
    outline: 2px solid #000000;
    outline-offset: 2px;
  }
`;

// Storage section
export const StorageSection = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.75rem; /* 12px */
`;

// Purchase Options section
export const PurchaseOptionsSection = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.75rem; /* 12px */
`;

// Fulfillment Method section
export const FulfillmentMethodSection = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.75rem; /* 12px */
`;

// Enter Device ID section
export const EnterDeviceIdSection = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.75rem; /* 12px */
`;

// Device ID input row with barcode button
export const DeviceIdInputRow = styled.div`
  display: flex;
  align-items: flex-end;
  gap: 0.75rem; /* 12px */
`;

// Section label with VDS Body Small styling
export const SectionLabel = styled(Body)`
  color: var(--vds-color-element-primary, #000);
  font-family: var(--vds-typography-body-small-fontfamily, 'Verizon NHG eTX');
  font-size: var(--vds-typography-body-small-fontsize, 12px);
  font-style: normal;
  font-weight: 400;
  line-height: var(--vds-typography-body-small-lineheight, 16px);
  letter-spacing: var(--vds-typography-body-small-letterspacing-regular, 0);
`;

// RadioBox container for storage/purchase/fulfillment options
export const RadioBoxContainer = styled.div`
  display: flex;
  flex-direction: row;
  gap: 12px;
  flex-wrap: wrap;
`;

export const RadioBox = styled.div`
  display: flex;
  flex-direction: column;
  align-items: ${(props) => (props.$hasSubtitle ? 'flex-start' : 'center')};
  justify-content: center;
  padding: ${(props) => (props.$hasSubtitle ? '12px 16px' : '12px')};
  min-width: ${(props) => (props.$hasSubtitle ? '150px' : '100px')};
  height: ${(props) => (props.$hasSubtitle ? '64px' : '56px')};
  border-radius: 8px;
  border: 2px solid ${(props) => (props.$selected ? '#000000' : 'rgba(0, 0, 0, 0.15)')};
  background-color: ${(props) => (props.$selected ? '#FFFFFF' : 'transparent')};
  cursor: ${(props) => (props.$disabled ? 'not-allowed' : 'pointer')};
  transition: all 0.2s ease;
  opacity: ${(props) => (props.$disabled ? '0.5' : '1')};
  pointer-events: ${(props) => (props.$disabled ? 'none' : 'auto')};

  &:hover {
    border-color: ${(props) => (props.$disabled ? 'rgba(0, 0, 0, 0.15)' : '#000000')};
  }
`;

export const RadioBoxText = styled(Body)`
  font-size: 16px;
  font-weight: ${(props) => (props.$selected ? '700' : '400')};
  line-height: 20px;
  letter-spacing: 0.5px;
  color: #000000;
  font-family:
    'Verizon NHG eDS',
    -apple-system,
    BlinkMacSystemFont,
    'Segoe UI',
    Roboto,
    sans-serif;
`;

export const RadioBoxSubtitle = styled(Body)`
  font-size: 12px;
  font-weight: 400;
  line-height: 16px;
  letter-spacing: 0.5px;
  color: #000000;
  opacity: 0.77;
  font-family:
    'Verizon NHG eDS',
    -apple-system,
    BlinkMacSystemFont,
    'Segoe UI',
    Roboto,
    sans-serif;
`;

// Fixed footer wrapper
export const FooterWrapper = styled.div`
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  z-index: 100;
`;

// Footer container
export const Footer = styled.div`
  width: 100%;
  max-width: 70.8125rem; /* 1133px */
  margin: 0 auto;
  background-color: #ffffff;
  border-radius: 1.5rem 1.5rem 0 0; /* 24px - rounded top corners */
  box-shadow: 0 2px 20px rgba(0, 0, 0, 0.16);
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  padding: 1.25rem 1.5rem 0.75rem; /* 20px 24px top, 12px bottom for home indicator */
  box-sizing: border-box;
  position: relative;
  min-height: 5rem;

  @media (max-width: ${BREAKPOINTS.tablet}) {
    max-width: 100%;
    padding: 1rem 1.25rem 0.625rem;
    min-height: 4.5rem;
  }

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    padding: 0.875rem 1rem 0.5rem;
    border-radius: 1rem 1rem 0 0;
    min-height: 4rem;
  }
`;

// Button group container - right aligned
export const ButtonGroup = styled.div`
  display: flex;
  align-items: center;
  gap: 0.75rem; /* 12px */
  margin-bottom: 0.75rem;
  width: 100%;
  justify-content: flex-end;

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    gap: 0.5rem;
    margin-bottom: 0.5rem;
  }
`;

// Home indicator / Swipe bar - centered at bottom
export const HomeIndicator = styled.div`
  width: 134px;
  height: 5px;
  background-color: #000000;
  border-radius: 2.5px;
  margin: 0 auto;
  flex-shrink: 0;
  position: absolute;
  bottom: 0.5rem;
  left: 50%;
  transform: translateX(-50%);

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    width: 120px;
    height: 4px;
    bottom: 0.375rem;
  }
`;

export const AvailabilityText = styled.div`
  font-size: 12px;
  font-weight: 400;
  line-height: 16px;
  letter-spacing: 0.5px;
  color: #008331;
  margin-top: 4px;
  font-family: 'Verizon NHG eDS', sans-serif;
`;
