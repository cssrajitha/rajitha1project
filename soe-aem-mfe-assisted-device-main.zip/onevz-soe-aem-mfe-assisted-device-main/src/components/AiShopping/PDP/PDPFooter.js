import React from 'react';
import PropTypes from 'prop-types';
import { Button } from '@vds/buttons';
import { FooterWrapper, Footer, ButtonGroup, HomeIndicator } from './PDP.styles';

const PDPFooter = ({ onCancel, onApply }) => (
  <FooterWrapper>
    <Footer>
      <ButtonGroup>
        <Button size='large' use='secondary' onClick={onCancel} data-testid='cancel-btn' data-track='DevicePDP_Cancel'>
          Cancel
        </Button>
        <Button size='large' use='primary' onClick={onApply} data-testid='apply-btn' data-track='DevicePDP_Apply'>
          Apply
        </Button>
      </ButtonGroup>
      <HomeIndicator />
    </Footer>
  </FooterWrapper>
);

PDPFooter.propTypes = {
  onCancel: PropTypes.func.isRequired,
  onApply: PropTypes.func.isRequired,
};

export default PDPFooter;
