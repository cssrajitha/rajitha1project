import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { PageContainer } from './PDP.styles';
import PDPBody from './PDPBody';
import PDPFooter from './PDPFooter';
import {
  useDeviceData,
  useColors,
  useStorageOptions,
  useCurrentSku,
  usePurchaseOptions,
  useFulfillmentAvailability,
  useFulfillmentOptions,
  useAddDeviceApi,
  buildAddDeviceRequest,
  getSelectedDeviceSkuId,
} from './PDP.utils';

function DeviceConfiguration({ defaultSku, productId, processingMTN, onCancel }) {
  // Fetch device data
  const deviceData = useDeviceData(defaultSku, productId, processingMTN);

  // Derive options from device data
  const colors = useColors(deviceData);
  const storageOptions = useStorageOptions(deviceData);

  // Local state
  const [selectedColor, setSelectedColor] = useState('');
  const [selectedStorage, setSelectedStorage] = useState('');
  const [purchaseOption, setPurchaseOption] = useState('');
  const [fulfillmentOption, setFulfillmentOption] = useState('');
  const [deviceId, setDeviceId] = useState('');

  // Get current SKU based on selections
  const currentSku = useCurrentSku(deviceData, selectedColor, selectedStorage);

  // Derive options from current SKU
  const purchaseOptions = usePurchaseOptions(currentSku);
  const fulfillmentAvailability = useFulfillmentAvailability(currentSku);
  const fulfillmentOptions = useFulfillmentOptions(fulfillmentAvailability);
  const { triggerAddDevice } = useAddDeviceApi();

  // Set initial selections when colors/storage options are loaded
  useEffect(() => {
    if (colors.length > 0 && !colors.find((c) => c.id === selectedColor)) {
      setSelectedColor(colors[0].id);
    }
  }, [colors, selectedColor]);

  useEffect(() => {
    if (storageOptions.length > 0 && !storageOptions.find((s) => s.value === selectedStorage)) {
      setSelectedStorage(storageOptions[0].value);
    }
  }, [storageOptions, selectedStorage]);

  // Auto-select first available fulfillment option when availability changes
  useEffect(() => {
    if (!fulfillmentAvailability[fulfillmentOption]) {
      const firstAvailable = fulfillmentOptions.find((opt) => !opt.disabled);
      if (firstAvailable) {
        setFulfillmentOption(firstAvailable.id);
      }
    }
  }, [fulfillmentAvailability, fulfillmentOptions, fulfillmentOption]);

  // Product info from device data
  const productName = deviceData?.productDisplayName || 'Apple iPhone 17 Pro';
  const productImage = currentSku?.imageUrlMap?.largeImage || deviceData?.imageUrlMap?.largeImage || '';
  const selectedColorData = colors.find((c) => c.id === selectedColor);
  const selectedDeviceSkuId = getSelectedDeviceSkuId(deviceData, selectedColor, selectedStorage);

  // Event handlers
  const handleCancel = () => {
    onCancel?.();
  };

  const handleApply = async () => {
    const requestBody = buildAddDeviceRequest({
      processingMTN,
      selectedDeviceSkuId,
      currentSku,
      purchaseOption,
      fulfillmentOption,
      deviceId,
    });

    await triggerAddDevice(requestBody);
  };

  const handleScanDeviceId = () => {
    // console.log('Scan device id clicked');
  };

  return (
    <PageContainer data-testid='device-configuration-page'>
      <PDPBody
        productName={productName}
        productImage={productImage}
        colors={colors}
        selectedColor={selectedColor}
        selectedColorData={selectedColorData}
        onColorSelect={setSelectedColor}
        storageOptions={storageOptions}
        selectedStorage={selectedStorage}
        onStorageSelect={setSelectedStorage}
        purchaseOptions={purchaseOptions}
        purchaseOption={purchaseOption}
        onPurchaseOptionSelect={setPurchaseOption}
        fulfillmentOptions={fulfillmentOptions}
        fulfillmentOption={fulfillmentOption}
        fulfillmentAvailability={fulfillmentAvailability}
        onFulfillmentOptionSelect={setFulfillmentOption}
        deviceId={deviceId}
        onDeviceIdChange={setDeviceId}
        onScanDeviceId={handleScanDeviceId}
      />

      <PDPFooter onCancel={handleCancel} onApply={handleApply} />
    </PageContainer>
  );
}

DeviceConfiguration.propTypes = {
  defaultSku: PropTypes.string,
  productId: PropTypes.string,
  processingMTN: PropTypes.string,
  onCancel: PropTypes.func,
};

DeviceConfiguration.defaultProps = {
  defaultSku: '',
  productId: '',
  processingMTN: '',
  onCancel: undefined,
};

export default DeviceConfiguration;
