import React from 'react';
import PropTypes from 'prop-types';
import { Title } from '@vds/typography';
import { Line } from '@vds/lines';
import { Input } from '@vds/inputs';
import { ButtonIcon } from '@vds/button-icons';
import { Icon } from '@vds/icons';

import {
  ContentWrapper,
  ContentCard,
  SectionHeader,
  MainContent,
  LeftSection,
  RightSection,
  DeviceNameSection,
  DeviceImageContainer,
  DeviceImg,
  // ComparisonSection,
  // ValueProps,
  ColorSection,
  SwatchContainer,
  Swatch,
  StorageSection,
  PurchaseOptionsSection,
  FulfillmentMethodSection,
  EnterDeviceIdSection,
  DeviceIdInputRow,
  SectionLabel,
  RadioBoxContainer,
  RadioBox,
  RadioBoxText,
  RadioBoxSubtitle,
  AvailabilityText,
} from './PDP.styles';

const PDPBody = ({
  productName,
  productImage,
  colors,
  selectedColor,
  selectedColorData,
  onColorSelect,
  storageOptions,
  selectedStorage,
  onStorageSelect,
  purchaseOptions,
  purchaseOption,
  onPurchaseOptionSelect,
  fulfillmentOptions,
  fulfillmentOption,
  fulfillmentAvailability,
  onFulfillmentOptionSelect,
  deviceId,
  onDeviceIdChange,
  onScanDeviceId,
}) => (
  <ContentWrapper>
    <ContentCard>
      {/* Section Header */}
      <SectionHeader>
        <Title size='XSmall' bold>
          Pick your color and storage
        </Title>
      </SectionHeader>

      {/* Main Content */}
      <MainContent>
        {/* Left Section - Device Info */}
        <LeftSection>
          {/* Device Name */}
          <DeviceNameSection>
            <Title size='XSmall' bold>
              {productName}
            </Title>
          </DeviceNameSection>

          {/* Device Image */}
          <DeviceImageContainer>
            {productImage ? (
              <DeviceImg src={productImage} alt={productName} data-testid='product-image' />
            ) : (
              <div style={{ width: '100%', height: '100%', backgroundColor: '#F8F7F5', borderRadius: '8px' }} />
            )}
          </DeviceImageContainer>

          {/* compare section will be dynamically derived once api ready */}
          {/* Comparison Section */}
          {/* <ComparisonSection>
              <Body size='medium' bold color='#333332'>
                Compared to your iPhone 14 Pro
              </Body>
              <ValueProps>
                <Body size='medium' color='#000000' style={{ opacity: 0.77 }}>
                  Higher quality 48MP camera
                </Body>
                <Body size='medium' color='#000000' style={{ opacity: 0.77 }}>
                  A larger 6.3 inch display
                </Body>
                <Body size='medium' color='#000000' style={{ opacity: 0.77 }}>
                  4x faster
                </Body>
                <Body size='medium' color='#000000' style={{ opacity: 0.77 }}>
                  2x storage
                </Body>
              </ValueProps>
            </ComparisonSection> */}
        </LeftSection>

        {/* Right Section - Color & Storage */}
        <RightSection>
          {/* Color Selection */}
          <ColorSection>
            <SectionLabel size='medium' data-testid='selected-color-name'>
              {selectedColorData?.name || 'Select color'}
            </SectionLabel>
            <SwatchContainer>
              {colors.map((color) => (
                <Swatch
                  key={color.id}
                  $color={color.hex}
                  $selected={selectedColor === color.id}
                  onClick={() => onColorSelect(color.id)}
                  aria-label={`Select ${color.name}`}
                  aria-pressed={selectedColor === color.id}
                  data-testid={`color-swatch-${color.id}`}
                />
              ))}
            </SwatchContainer>
          </ColorSection>

          {/* Storage Selection */}
          <StorageSection>
            <SectionLabel size='medium'>Storage</SectionLabel>
            <RadioBoxContainer>
              {storageOptions.map((option) => (
                <RadioBox
                  key={option.id}
                  $selected={selectedStorage === option.value}
                  $hasSubtitle={false}
                  $disabled={false}
                  onClick={() => onStorageSelect(option.value)}
                  role='radio'
                  aria-checked={selectedStorage === option.value}
                  data-testid={`storage-${option.value}`}
                >
                  <RadioBoxText $selected={selectedStorage === option.value}>{option.label}</RadioBoxText>
                </RadioBox>
              ))}
            </RadioBoxContainer>
          </StorageSection>

          {/* Purchase Options */}
          <PurchaseOptionsSection>
            <SectionLabel size='medium'>Purchase options</SectionLabel>
            <RadioBoxContainer>
              {purchaseOptions.map((option) => (
                <RadioBox
                  key={option.id}
                  $selected={purchaseOption === option.id}
                  $hasSubtitle
                  $disabled={false}
                  onClick={() => onPurchaseOptionSelect(option.id)}
                  role='radio'
                  aria-checked={purchaseOption === option.id}
                  data-testid={`purchase-${option.id}`}
                >
                  <RadioBoxText $selected={purchaseOption === option.id}>{option.title}</RadioBoxText>
                  <RadioBoxSubtitle>{option.subtitle}</RadioBoxSubtitle>
                </RadioBox>
              ))}
            </RadioBoxContainer>
          </PurchaseOptionsSection>

          {/* Fulfillment Method */}
          <FulfillmentMethodSection>
            <SectionLabel size='medium'>Fulfillment method</SectionLabel>
            <RadioBoxContainer>
              {fulfillmentOptions.map((option) => (
                <RadioBox
                  key={option.id}
                  $selected={!option.disabled && fulfillmentOption === option.id}
                  $hasSubtitle
                  $disabled={option.disabled}
                  onClick={() => !option.disabled && onFulfillmentOptionSelect(option.id)}
                  role='radio'
                  aria-checked={fulfillmentOption === option.id}
                  aria-disabled={option.disabled}
                  data-testid={`fulfillment-${option.id}`}
                >
                  <RadioBoxText $selected={!option.disabled && fulfillmentOption === option.id}>
                    {option.title}
                  </RadioBoxText>
                  <RadioBoxSubtitle>{option.subtitle}</RadioBoxSubtitle>
                </RadioBox>
              ))}
            </RadioBoxContainer>
            {fulfillmentOption === 'ship' && fulfillmentAvailability.shipDetails?.shippingDate && (
              <AvailabilityText data-testid='ship-availability-text'>
                {fulfillmentAvailability.shipDetails.isPreOrder
                  ? `Pre-order - Ships by ${fulfillmentAvailability.shipDetails.shippingDate.date}`
                  : 'Available to ship'}
              </AvailabilityText>
            )}
            {fulfillmentOption === 'local' && fulfillmentAvailability.local && (
              <AvailabilityText data-testid='local-availability-text'>Available for local fulfillment</AvailabilityText>
            )}
            {fulfillmentOption === 'instore' && fulfillmentAvailability.instore && (
              <AvailabilityText data-testid='instore-availability-text'>Available for in-store pickup</AvailabilityText>
            )}
          </FulfillmentMethodSection>

          {/* Divider */}
          <Line type='secondary' />

          {/* Enter Device ID */}
          <EnterDeviceIdSection>
            <SectionLabel size='medium'>Enter Device ID</SectionLabel>
            <DeviceIdInputRow>
              <Input
                label=''
                value={deviceId}
                onChange={(e) => onDeviceIdChange(e.target.value)}
                placeholder='Enter SIM ID'
                aria-label='Device ID'
                width='100%'
                data-testid='device-id-input'
              />
              <ButtonIcon
                kind='lowContrast'
                size='large'
                renderIcon={() => <Icon name='barcode' size={24} color='#ffffff' />}
                onClick={onScanDeviceId}
                ariaLabel='Scan device id'
              />
            </DeviceIdInputRow>
          </EnterDeviceIdSection>
        </RightSection>
      </MainContent>
    </ContentCard>
  </ContentWrapper>
);

PDPBody.propTypes = {
  productName: PropTypes.string.isRequired,
  productImage: PropTypes.string,
  colors: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.string.isRequired,
      name: PropTypes.string.isRequired,
      hex: PropTypes.string.isRequired,
    }),
  ).isRequired,
  selectedColor: PropTypes.string.isRequired,
  selectedColorData: PropTypes.shape({
    name: PropTypes.string,
  }),
  onColorSelect: PropTypes.func.isRequired,
  storageOptions: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.string.isRequired,
      label: PropTypes.string.isRequired,
      value: PropTypes.string.isRequired,
    }),
  ).isRequired,
  selectedStorage: PropTypes.string.isRequired,
  onStorageSelect: PropTypes.func.isRequired,
  purchaseOptions: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.string.isRequired,
      title: PropTypes.string.isRequired,
      subtitle: PropTypes.string.isRequired,
    }),
  ).isRequired,
  purchaseOption: PropTypes.string.isRequired,
  onPurchaseOptionSelect: PropTypes.func.isRequired,
  fulfillmentOptions: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.string.isRequired,
      title: PropTypes.string.isRequired,
      subtitle: PropTypes.string.isRequired,
      disabled: PropTypes.bool.isRequired,
    }),
  ).isRequired,
  fulfillmentOption: PropTypes.string.isRequired,
  fulfillmentAvailability: PropTypes.shape({
    local: PropTypes.bool,
    instore: PropTypes.bool,
    ship: PropTypes.bool,
    shipDetails: PropTypes.object,
    localDetails: PropTypes.object,
  }).isRequired,
  onFulfillmentOptionSelect: PropTypes.func.isRequired,
  deviceId: PropTypes.string.isRequired,
  onDeviceIdChange: PropTypes.func.isRequired,
  onScanDeviceId: PropTypes.func.isRequired,
};

export default PDPBody;
