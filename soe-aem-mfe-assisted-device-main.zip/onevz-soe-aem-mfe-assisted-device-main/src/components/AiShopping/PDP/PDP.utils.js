import { useState, useEffect, useMemo } from 'react';
import { useAddDeviceMutation } from 'onevzsoemfecommon/APIService';
import { useLazyGetDeviceDetailsQuery } from '../../../modules/services/APIService/APIServiceHooks';
// import mockGetDetails from "./mocks/getDetails.json";

/**
 * Custom hook to fetch and manage device data
 */
export const useDeviceData = (defaultSku, productId, processingMTN) => {
  const [getDetails, detailsResult] = useLazyGetDeviceDetailsQuery();
  const [deviceData, setDeviceData] = useState(null);

  useEffect(() => {
    const params = {
      data: {
        bogoEnabled: 'False',
        correlationId: '',
        defaultSku,
        enableAssistedTagging: true,
        enableBPM: true,
        market: '',
        masterAgentCode: '',
        mtnList: { eup: [], aal: [] },
        aal: [],
        eup: [],
        productId,
        productType: 'device',
        seoUrlName: '',
        siteId: '',
        skuSearch: false,
        zipCode: '',
        processingMTN,
      },
    };
    getDetails({ body: params, spinner: true }, false);
  }, []);

  useEffect(() => {
    if (detailsResult?.data?.data?.deviceProduct) {
      setDeviceData(detailsResult.data.data.deviceProduct);
    }
    // fallback for local till landing api is ready
    // else {
    //   setDeviceData(mockGetDetails.data.deviceProduct);
    // }
  }, [detailsResult]);

  return deviceData;
};

/**
 * Build add-device API request body from PDP selections
 */
export const buildAddDeviceRequest = ({
  processingMTN,
  selectedDeviceSkuId,
  currentSku,
  purchaseOption,
  fulfillmentOption,
  deviceId,
}) => {
  const resolvedMtn = processingMTN || '';
  const resolvedDeviceSku =
    selectedDeviceSkuId || currentSku?.sorId || currentSku?.id || currentSku?.sku || currentSku?.skuId || '';
  const resolvedContractTerm = purchaseOption === 'retail' ? 'FRP' : 'DPP';
  const resolvedDppMonths = Number(currentSku?.price?.devicePaymentPrice?.[0]?.contractDuration) || 36;
  const resolvedCategory = currentSku?.category || 'Smartphones';
  const resolvedDepletionType = fulfillmentOption === 'ship' ? 'F' : 'L';
  const resolvedSimSku = currentSku?.simSku || '';

  return {
    cartInfo: {
      cartCreator: resolvedMtn,
      processingMTN: resolvedMtn,
      processStep: 'GridWallPDP',
      processAction: 'addDevice',
      intendType: 'EUP',
      mtnFlow: 'AIQuote',
    },
    data: {
      lines: [
        {
          mtn: resolvedMtn,
          mdnFilterValue: resolvedMtn,
          isByod: false,
          device: {
            id: resolvedDeviceSku,
            deviceId: deviceId || '',
            contractTerm: resolvedContractTerm,
            dppMonths: resolvedDppMonths,
            isCustomerProvidedEquipment: false,
            category: resolvedCategory,
          },
          sim: {
            id: resolvedSimSku,
            iccid: '',
          },
          isKeepingExistingEqProtection: true,
          triggerPricingValidation: true,
          depletionType: resolvedDepletionType,
          amount: '0.0',
        },
      ],
    },
  };
};

/**
 * Resolve selected device SKU id from color/storage selection
 */
export const getSelectedDeviceSkuId = (deviceData, selectedColor, selectedStorage) => {
  const childSkus = deviceData?.childSkus || [];
  if (!childSkus.length) return '';

  const selectedSku =
    childSkus.find((sku) => {
      const colorMatch = sku.color?.displayName?.toLowerCase().replace(/\s+/g, '-') === selectedColor;
      const storageMatch = sku.capacity?.replace(/\s+/g, '') === selectedStorage;
      return colorMatch && storageMatch;
    }) || childSkus[0];

  return selectedSku?.sorId || selectedSku?.id || selectedSku?.sku || selectedSku?.skuId || '';
};

/**
 * Trigger add-device API from PDP flow
 */
export const useAddDeviceApi = () => {
  const [addDevice, addDeviceResult] = useAddDeviceMutation();

  const triggerAddDevice = (requestBody) => addDevice({ body: requestBody });

  return { triggerAddDevice, addDeviceResult };
};

/**
 * Derive colors from device data
 */
export const useColors = (deviceData) =>
  useMemo(() => {
    if (!deviceData?.childSkus) return [];
    const colorMap = new Map();
    deviceData.childSkus.forEach((sku) => {
      /* istanbul ignore else */
      if (sku.color && !colorMap.has(sku.color.displayName)) {
        colorMap.set(sku.color.displayName, {
          id: sku.color.displayName.toLowerCase().replace(/\s+/g, '-'),
          name: sku.color.displayName,
          hex: sku.color.colorCssStyle,
        });
      }
    });
    return Array.from(colorMap.values());
  }, [deviceData]);

/**
 * Derive storage options from device data
 */
export const useStorageOptions = (deviceData) =>
  useMemo(() => {
    if (!deviceData?.childSkus) return [];
    const storageMap = new Map();
    deviceData.childSkus.forEach((sku) => {
      if (sku.capacity && !storageMap.has(sku.capacity)) {
        storageMap.set(sku.capacity, {
          id: sku.capacity.replace(/\s+/g, ''),
          label: sku.capacity,
          value: sku.capacity.replace(/\s+/g, ''),
        });
      }
    });
    return Array.from(storageMap.values());
  }, [deviceData]);

/**
 * Get current SKU based on selected color and storage
 */
export const useCurrentSku = (deviceData, selectedColor, selectedStorage) =>
  useMemo(() => {
    if (!deviceData?.childSkus) return null;
    return (
      deviceData.childSkus.find((sku) => {
        const colorMatch = sku.color?.displayName.toLowerCase().replace(/\s+/g, '-') === selectedColor;
        const storageMatch = sku.capacity?.replace(/\s+/g, '') === selectedStorage;
        return colorMatch && storageMatch;
      }) || deviceData.childSkus[0]
    );
  }, [deviceData, selectedColor, selectedStorage]);

/**
 * Derive purchase options from current SKU
 */
export const usePurchaseOptions = (currentSku) =>
  useMemo(() => {
    if (!currentSku?.price) {
      return [];
    }
    const options = [];
    const dpPrice = currentSku.price.devicePaymentPrice?.[0];
    if (dpPrice) {
      options.push({
        id: 'monthly',
        title: `$${dpPrice.originalPrice}/mo for ${dpPrice.contractDuration}mos`,
        subtitle: 'Monthly payment',
      });
    }
    const retailPrice = currentSku.price.fullRetailPrice;
    if (retailPrice) {
      options.push({
        id: 'retail',
        title: `$${retailPrice.originalPrice}`,
        subtitle: 'Full retail price',
      });
    }
    return options;
  }, [currentSku]);

/**
 * Derive fulfillment options availability from current SKU
 */
export const useFulfillmentAvailability = (currentSku) =>
  useMemo(() => {
    if (!currentSku) {
      return { local: false, instore: false, ship: false };
    }

    const inventoryDetails = currentSku.inventoryDetails || {};
    const dFillInventory = inventoryDetails.dFillInventory || {};
    const localInventory = inventoryDetails.localInventory || {};

    const isShipAvailable =
      dFillInventory.isInStock || dFillInventory.isAvailable || dFillInventory.isPreOrder || dFillInventory.isBackorder;

    const isLocalAvailable = localInventory.isInStock || localInventory.isAvailable;

    const isInstoreAvailable = currentSku.isInstorePickup === true;

    return {
      local: isLocalAvailable,
      instore: isInstoreAvailable,
      ship: isShipAvailable,
      shipDetails: dFillInventory,
      localDetails: localInventory,
    };
  }, [currentSku]);

/**
 * Get fulfillment options array
 */
export const useFulfillmentOptions = (fulfillmentAvailability) =>
  useMemo(() => {
    const shipSubtitle = (() => {
      if (!fulfillmentAvailability.ship) return 'Not available';
      if (fulfillmentAvailability.shipDetails?.isPreOrder) return 'Pre-order';
      return 'Available to ship';
    })();

    return [
      {
        id: 'local',
        title: 'Local fulfillment',
        disabled: !fulfillmentAvailability.local,
        subtitle: fulfillmentAvailability.local ? 'Available' : 'Not available',
      },
      {
        id: 'instore',
        title: 'In Store pickup',
        disabled: !fulfillmentAvailability.instore,
        subtitle: fulfillmentAvailability.instore ? 'Available' : 'Not available',
      },
      {
        id: 'ship',
        title: 'Ship this device',
        disabled: !fulfillmentAvailability.ship,
        subtitle: shipSubtitle,
      },
    ];
  }, [fulfillmentAvailability]);
