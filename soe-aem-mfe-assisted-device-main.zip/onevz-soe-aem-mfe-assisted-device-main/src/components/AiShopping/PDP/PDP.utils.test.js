import { renderHook, act, waitFor } from '@testing-library/react';
import {
  useDeviceData,
  buildAddDeviceRequest,
  getSelectedDeviceSkuId,
  useAddDeviceApi,
  useColors,
  useStorageOptions,
  useCurrentSku,
  usePurchaseOptions,
  useFulfillmentAvailability,
  useFulfillmentOptions,
} from './PDP.utils';

const mockGetDetails = jest.fn();
const mockAddDevice = jest.fn();
let mockDetailsResult = {};
let mockAddDeviceResult = { isLoading: false };

jest.mock('../../../modules/services/APIService/APIServiceHooks', () => ({
  useLazyGetDeviceDetailsQuery: () => [mockGetDetails, mockDetailsResult],
}));

jest.mock('onevzsoemfecommon/APIService', () => ({
  useAddDeviceMutation: () => [mockAddDevice, mockAddDeviceResult],
}));

const createSku = (overrides = {}) => ({
  sorId: 'MFXH4LL/A',
  skuId: 'sku6037281',
  capacity: '256 GB',
  color: { displayName: 'Cosmic Orange', colorCssStyle: '#F77E2D' },
  price: {
    devicePaymentPrice: [{ originalPrice: 33.33, contractDuration: 36 }],
    fullRetailPrice: { originalPrice: 1199.99 },
  },
  inventoryDetails: {
    dFillInventory: { isInStock: false, isAvailable: false, isPreOrder: false, isBackorder: false },
    localInventory: { isInStock: false, isAvailable: false },
  },
  isInstorePickup: false,
  ...overrides,
});

describe('PDP.utils', () => {
  beforeEach(() => {
    mockGetDetails.mockClear();
    mockAddDevice.mockClear();
    mockDetailsResult = {};
    mockAddDeviceResult = { isLoading: false };
  });

  describe('useDeviceData', () => {
    test('triggers getDetails on mount with expected request', async () => {
      renderHook(() => useDeviceData('MFXH4LL/A', 'dev21413629', '2032146295'));

      await waitFor(() => {
        expect(mockGetDetails).toHaveBeenCalledWith(
          expect.objectContaining({
            body: expect.objectContaining({
              data: expect.objectContaining({
                defaultSku: 'MFXH4LL/A',
                productId: 'dev21413629',
                processingMTN: '2032146295',
                productType: 'device',
              }),
            }),
            spinner: true,
          }),
          false,
        );
      });
    });

    test('sets deviceData only when details response has deviceProduct', async () => {
      const { result, rerender } = renderHook(() => useDeviceData('MFXH4LL/A', 'dev21413629', '2032146295'));
      expect(result.current).toBeNull();

      mockDetailsResult = { data: { data: { deviceProduct: { productDisplayName: 'Test Device' } } } };
      rerender();

      await waitFor(() => {
        expect(result.current).toEqual({ productDisplayName: 'Test Device' });
      });
    });
  });

  describe('buildAddDeviceRequest', () => {
    test('builds DPP + Local payload and prioritizes selectedDeviceSkuId', () => {
      const payload = buildAddDeviceRequest({
        processingMTN: '2032146295',
        selectedDeviceSkuId: 'SELECTED-SKU',
        currentSku: createSku({ sorId: 'MFXA4LL/A' }),
        purchaseOption: 'monthly',
        fulfillmentOption: 'local',
        deviceId: '',
      });

      expect(payload.data.lines[0].device.id).toBe('SELECTED-SKU');
      expect(payload.data.lines[0].device.contractTerm).toBe('DPP');
      expect(payload.data.lines[0].depletionType).toBe('L');
      expect(payload.cartInfo.processingMTN).toBe('2032146295');
    });

    test('builds FRP + Ship payload and resolves fallback values', () => {
      const payload = buildAddDeviceRequest({
        processingMTN: undefined,
        selectedDeviceSkuId: '',
        currentSku: createSku({
          sorId: undefined,
          id: undefined,
          sku: undefined,
          skuId: 'sku6037281',
          category: undefined,
          price: { devicePaymentPrice: [{ contractDuration: undefined }] },
        }),
        purchaseOption: 'retail',
        fulfillmentOption: 'ship',
        deviceId: undefined,
      });

      expect(payload.cartInfo.processingMTN).toBe('');
      expect(payload.cartInfo.cartCreator).toBe('');
      expect(payload.data.lines[0].device.id).toBe('sku6037281');
      expect(payload.data.lines[0].device.contractTerm).toBe('FRP');
      expect(payload.data.lines[0].device.dppMonths).toBe(36);
      expect(payload.data.lines[0].device.category).toBe('Smartphones');
      expect(payload.data.lines[0].device.deviceId).toBe('');
      expect(payload.data.lines[0].depletionType).toBe('F');
    });

    test('handles empty sku resolution when selectedDeviceSkuId and currentSku are missing', () => {
      const payload = buildAddDeviceRequest({
        processingMTN: '2032146295',
        selectedDeviceSkuId: '',
        currentSku: undefined,
        purchaseOption: 'monthly',
        fulfillmentOption: 'local',
        deviceId: '',
      });
      expect(payload.data.lines[0].device.id).toBe('');
    });

    test('falls through device id chain when only sorId/id/sku are present', () => {
      expect(
        buildAddDeviceRequest({
          processingMTN: '1',
          selectedDeviceSkuId: '',
          currentSku: createSku({ sorId: 'SOR-ONLY', id: undefined, sku: undefined, skuId: undefined }),
          purchaseOption: 'monthly',
          fulfillmentOption: 'instore',
          deviceId: 'abc',
        }).data.lines[0].device.id,
      ).toBe('SOR-ONLY');

      expect(
        buildAddDeviceRequest({
          processingMTN: '1',
          selectedDeviceSkuId: '',
          currentSku: createSku({ sorId: undefined, id: 'ID-ONLY', sku: undefined, skuId: undefined }),
          purchaseOption: 'monthly',
          fulfillmentOption: 'local',
          deviceId: 'abc',
        }).data.lines[0].device.id,
      ).toBe('ID-ONLY');

      expect(
        buildAddDeviceRequest({
          processingMTN: '1',
          selectedDeviceSkuId: '',
          currentSku: createSku({ sorId: undefined, id: undefined, sku: 'SKU-ONLY', skuId: undefined }),
          purchaseOption: 'monthly',
          fulfillmentOption: 'local',
          deviceId: 'abc',
        }).data.lines[0].device.id,
      ).toBe('SKU-ONLY');
    });
  });

  describe('getSelectedDeviceSkuId', () => {
    test('returns empty string when childSkus missing', () => {
      expect(getSelectedDeviceSkuId(null, 'deep-blue', '256GB')).toBe('');
      expect(getSelectedDeviceSkuId({}, 'deep-blue', '256GB')).toBe('');
    });

    test('returns matching sku sorId for selected color/storage', () => {
      const deviceData = {
        childSkus: [
          createSku({ sorId: 'MFXU4LL/A', color: { displayName: 'Deep Blue' }, capacity: '1 TB' }),
          createSku({ sorId: 'MFXH4LL/A', color: { displayName: 'Cosmic Orange' }, capacity: '256 GB' }),
        ],
      };
      expect(getSelectedDeviceSkuId(deviceData, 'cosmic-orange', '256GB')).toBe('MFXH4LL/A');
    });

    test('falls back to first sku and resolves id fallbacks', () => {
      const deviceData = {
        childSkus: [createSku({ sorId: undefined, id: undefined, sku: undefined, skuId: 'sku6037395' })],
      };
      expect(getSelectedDeviceSkuId(deviceData, 'not-found', '999GB')).toBe('sku6037395');
    });

    test('covers return fallback chain: id, sku, and empty string', () => {
      expect(
        getSelectedDeviceSkuId(
          { childSkus: [createSku({ sorId: undefined, id: 'ID-ONLY', sku: undefined, skuId: undefined })] },
          'not-found',
          '999GB',
        ),
      ).toBe('ID-ONLY');

      expect(
        getSelectedDeviceSkuId(
          { childSkus: [createSku({ sorId: undefined, id: undefined, sku: 'SKU-ONLY', skuId: undefined })] },
          'not-found',
          '999GB',
        ),
      ).toBe('SKU-ONLY');

      expect(
        getSelectedDeviceSkuId(
          { childSkus: [createSku({ sorId: undefined, id: undefined, sku: undefined, skuId: undefined })] },
          'not-found',
          '999GB',
        ),
      ).toBe('');
    });
  });

  describe('useAddDeviceApi', () => {
    test('exposes addDevice result and wraps trigger payload', async () => {
      mockAddDevice.mockResolvedValue({ data: { serviceHeader: { statusMsg: 'SUCCESS' } } });
      mockAddDeviceResult = { isLoading: true };
      const { result } = renderHook(() => useAddDeviceApi());
      const requestBody = { cartInfo: { processingMTN: '2032146295' } };

      await act(async () => {
        await result.current.triggerAddDevice(requestBody);
      });

      expect(result.current.addDeviceResult).toEqual({ isLoading: true });
      expect(mockAddDevice).toHaveBeenCalledWith({ body: requestBody });
    });
  });

  describe('option derivation hooks', () => {
    test('useColors handles empty and deduplicates colors', () => {
      const { result: empty } = renderHook(() => useColors(null));
      expect(empty.current).toEqual([]);

      const { result } = renderHook(() =>
        useColors({
          childSkus: [
            createSku({ color: { displayName: 'Deep Blue', colorCssStyle: '#394673' } }),
            createSku({ color: { displayName: 'Deep Blue', colorCssStyle: '#394673' } }),
            createSku({ color: null }),
          ],
        }),
      );
      expect(result.current).toHaveLength(1);
      expect(result.current[0]).toEqual({ id: 'deep-blue', name: 'Deep Blue', hex: '#394673' });
    });

    test('useStorageOptions handles empty and deduplicates capacity', () => {
      const { result: empty } = renderHook(() => useStorageOptions(null));
      expect(empty.current).toEqual([]);

      const { result } = renderHook(() =>
        useStorageOptions({
          childSkus: [
            createSku({ capacity: '256 GB' }),
            createSku({ capacity: '256 GB' }),
            createSku({ capacity: '' }),
          ],
        }),
      );
      expect(result.current).toHaveLength(1);
      expect(result.current[0]).toEqual({ id: '256GB', label: '256 GB', value: '256GB' });
    });

    test('useCurrentSku handles empty, exact match, and fallback to first', () => {
      const { result: empty } = renderHook(() => useCurrentSku(null, 'deep-blue', '1TB'));
      expect(empty.current).toBeNull();

      const skus = [
        createSku({ sorId: 'FIRST', color: { displayName: 'Silver' }, capacity: '256 GB' }),
        createSku({ sorId: 'MATCHED', color: { displayName: 'Deep Blue' }, capacity: '1 TB' }),
      ];

      const { result: matched } = renderHook(() => useCurrentSku({ childSkus: skus }, 'deep-blue', '1TB'));
      expect(matched.current.sorId).toBe('MATCHED');

      const { result: fallback } = renderHook(() => useCurrentSku({ childSkus: skus }, 'not-exist', '999GB'));
      expect(fallback.current.sorId).toBe('FIRST');
    });

    test('usePurchaseOptions covers no price, monthly only, retail only, and both', () => {
      expect(renderHook(() => usePurchaseOptions(null)).result.current).toEqual([]);

      expect(
        renderHook(() =>
          usePurchaseOptions({ price: { devicePaymentPrice: [{ originalPrice: 10, contractDuration: 36 }] } }),
        ).result.current,
      ).toHaveLength(1);

      expect(
        renderHook(() => usePurchaseOptions({ price: { fullRetailPrice: { originalPrice: 999 } } })).result.current,
      ).toHaveLength(1);

      expect(
        renderHook(() =>
          usePurchaseOptions({
            price: {
              devicePaymentPrice: [{ originalPrice: 10, contractDuration: 36 }],
              fullRetailPrice: { originalPrice: 999 },
            },
          }),
        ).result.current,
      ).toHaveLength(2);
    });

    test('useFulfillmentAvailability and useFulfillmentOptions cover all subtitle branches', () => {
      expect(renderHook(() => useFulfillmentAvailability(null)).result.current).toEqual({
        local: false,
        instore: false,
        ship: false,
      });

      const preOrderAvailability = renderHook(() =>
        useFulfillmentAvailability(
          createSku({
            inventoryDetails: { dFillInventory: { isPreOrder: true }, localInventory: { isAvailable: true } },
            isInstorePickup: true,
          }),
        ),
      ).result.current;

      const optionsPreOrder = renderHook(() => useFulfillmentOptions(preOrderAvailability)).result.current;
      expect(optionsPreOrder.find((o) => o.id === 'ship').subtitle).toBe('Pre-order');

      const noShipAvailability = renderHook(() =>
        useFulfillmentAvailability(
          createSku({ inventoryDetails: { dFillInventory: {}, localInventory: {} }, isInstorePickup: false }),
        ),
      ).result.current;
      const optionsNoShip = renderHook(() => useFulfillmentOptions(noShipAvailability)).result.current;
      expect(optionsNoShip.find((o) => o.id === 'ship').subtitle).toBe('Not available');

      const shipAvailability = renderHook(() =>
        useFulfillmentAvailability(
          createSku({
            inventoryDetails: { dFillInventory: { isInStock: true }, localInventory: {} },
            isInstorePickup: false,
          }),
        ),
      ).result.current;
      const optionsShip = renderHook(() => useFulfillmentOptions(shipAvailability)).result.current;
      expect(optionsShip.find((o) => o.id === 'ship').subtitle).toBe('Available to ship');

      const missingInventoryAvailability = renderHook(() =>
        useFulfillmentAvailability(createSku({ inventoryDetails: undefined })),
      ).result.current;
      expect(missingInventoryAvailability).toEqual(
        expect.objectContaining({
          local: undefined,
          instore: false,
          ship: undefined,
        }),
      );
    });
  });
});
