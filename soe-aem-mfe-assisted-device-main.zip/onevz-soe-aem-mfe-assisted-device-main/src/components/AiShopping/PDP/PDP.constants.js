// Breakpoints
export const BREAKPOINTS = {
  tablet: '1024px',
  ipadMini: '768px',
};
