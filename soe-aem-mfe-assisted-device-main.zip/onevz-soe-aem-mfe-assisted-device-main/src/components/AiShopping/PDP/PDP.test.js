import React from 'react';
import { renderHook, act } from '@testing-library/react';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import { fireEvent, render, screen, waitFor } from '../../../modules/test-utils/renderHelper';
import { CHANNELS, setupChannel } from '../../../modules/test-utils/utils';
import DeviceConfiguration from './PDP';
import {
  useDeviceData,
  buildAddDeviceRequest,
  getSelectedDeviceSkuId,
  useAddDeviceApi,
  useColors,
  useStorageOptions,
  useCurrentSku,
  usePurchaseOptions,
  useFulfillmentAvailability,
  useFulfillmentOptions,
} from './PDP.utils';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import getDetailsJSON from './mocks/getDetails.json';

// --- Mock RTK Query hook for reliable data control ---
const mockGetDetails = jest.fn();
const mockAddDevice = jest.fn();
let mockAddDeviceResult = { isLoading: false };
let mockDetailsResult = {};

jest.mock('../../../modules/services/APIService/APIServiceHooks', () => ({
  useLazyGetDeviceDetailsQuery: () => [mockGetDetails, mockDetailsResult],
}));

jest.mock('onevzsoemfecommon/APIService', () => ({
  useAddDeviceMutation: () => [mockAddDevice, mockAddDeviceResult],
}));

beforeEach(() => {
  mockAddDevice.mockClear();
  mockAddDeviceResult = { isLoading: false };
});

/* eslint-disable react/prop-types, no-shadow */
jest.mock('@vds/typography', () => ({
  Body: ({ children, ...props }) => <div {...props}>{children}</div>,
  Title: ({ children, ...props }) => <div {...props}>{children}</div>,
}));

jest.mock('@vds/lines', () => ({
  Line: () => <hr />,
}));

jest.mock('@vds/buttons', () => ({
  Button: ({ children, onClick, ...props }) => (
    <button type='button' onClick={onClick} {...props}>
      {children}
    </button>
  ),
}));

jest.mock('@vds/icons', () => ({
  Icon: ({ name, onClick, ...props }) => (
    <button type='button' data-testid={`icon-${name}`} onClick={onClick} {...props}>
      icon-{name}
    </button>
  ),
}));

jest.mock('@vds/button-icons', () => ({
  ButtonIcon: ({ ariaLabel, onClick, renderIcon, ...props }) => (
    <button type='button' aria-label={ariaLabel} onClick={onClick} {...props}>
      {renderIcon ? renderIcon() : 'button-icon'}
    </button>
  ),
}));
/* eslint-enable react/prop-types, no-shadow */

// --- Test data helpers ---
const createDeviceProduct = (overrides = {}) => ({
  productDisplayName: 'Test Phone',
  imageUrlMap: { largeImage: 'device-image' },
  childSkus: [],
  ...overrides,
});

const createSku = (overrides = {}) => ({
  id: 'MFXH4LL/A',
  sorId: 'MFXH4LL/A',
  skuId: 'sku6037281',
  color: { displayName: 'Cosmic Orange', colorCssStyle: '#F77E2D' },
  capacity: '256 GB',
  category: 'Smartphones',
  imageUrlMap: { largeImage: 'sku-image' },
  price: {
    devicePaymentPrice: [{ originalPrice: 10, contractDuration: 36 }],
    fullRetailPrice: { originalPrice: 100 },
  },
  inventoryDetails: {
    dFillInventory: {
      isPreOrder: true,
      shippingDate: { date: '03/31/2026' },
      isInStock: false,
      isAvailable: false,
      isBackorder: false,
    },
    localInventory: { isInStock: true },
  },
  isInstorePickup: true,
  ...overrides,
});

const renderWithDetails = (deviceProduct, props = {}) => {
  mockDetailsResult = deviceProduct ? { data: { data: { deviceProduct } } } : {};
  const defaultProps = {
    defaultSku: 'MG7U4LL/A',
    productId: 'dev21413633',
    processingMTN: '7402328882',
    ...props,
  };
  return render(<DeviceConfiguration {...defaultProps} />, {
    reducers: rootReducer,
    sagas: rootSaga,
  });
};

// --- Channel-based test suite (follows index.test.js pattern) ---
const Test = (channel) => {
  setupChannel(channel);

  const handlers = [rest.post('*/getDetails', (req, res, ctx) => res(ctx.status(200), ctx.json(getDetailsJSON)))];
  const server = setupServer(...handlers);

  describe(`<DeviceConfiguration (PDP) -> ${channel}`, () => {
    const consoleSpy = jest.spyOn(console, 'log').mockImplementation(() => {});

    beforeAll(() => server.listen());
    afterEach(() => server.resetHandlers());
    afterAll(() => server.close());

    // ============================================================
    // Group 1: Full device data with two SKUs
    // ============================================================
    describe('with full device data (two SKUs)', () => {
      beforeEach(() => {
        mockGetDetails.mockClear();
        consoleSpy.mockClear();
        mockDetailsResult = {
          data: {
            data: {
              deviceProduct: createDeviceProduct({
                childSkus: [
                  createSku(),
                  createSku({
                    color: { displayName: 'Deep Blue', colorCssStyle: '#394673' },
                    imageUrlMap: { largeImage: 'sku-image-blue' },
                  }),
                ],
              }),
            },
          },
        };
        render(<DeviceConfiguration defaultSku='MG7U4LL/A' productId='dev21413633' processingMTN='7402328882' />, {
          reducers: rootReducer,
          sagas: rootSaga,
        });
      });

      test('it should render the page', async () => {
        const container = await screen.findByTestId('device-configuration-page');
        expect(container).toBeInTheDocument();
      });

      test('it should call getDetails API on mount', async () => {
        await waitFor(() => {
          expect(mockGetDetails).toHaveBeenCalledWith(
            expect.objectContaining({
              body: expect.objectContaining({
                data: expect.objectContaining({ productId: 'dev21413633' }),
              }),
              spinner: true,
            }),
            false,
          );
        });
      });

      test('it should display device name and image', async () => {
        expect(screen.getByText('Test Phone')).toBeInTheDocument();
        expect(screen.getByAltText('Test Phone')).toHaveAttribute('src', 'sku-image');
      });

      test('it should switch to local fulfillment and show availability', async () => {
        fireEvent.click(screen.getByText('Local fulfillment'));
        expect(screen.getByText('Available for local fulfillment')).toBeInTheDocument();
      });

      test('it should switch to in-store fulfillment and show availability', async () => {
        fireEvent.click(screen.getByText('In Store pickup'));
        expect(screen.getByText('Available for in-store pickup')).toBeInTheDocument();
      });

      test('it should change color selection', async () => {
        fireEvent.click(screen.getByLabelText('Select Deep Blue'));
        const selectedColorElement = screen.getByTestId('selected-color-name');
        expect(selectedColorElement).toHaveTextContent('Deep Blue');
      });

      test('it should switch to full retail price', async () => {
        fireEvent.click(screen.getByText('Full retail price'));
        await waitFor(() => {
          expect(screen.getByTestId('purchase-retail')).toBeTruthy();
        });
      });

      test('it should handle device ID input', async () => {
        fireEvent.change(screen.getByLabelText('Device ID'), { target: { value: 'ABC123' } });
        expect(screen.getByLabelText('Device ID').value).toBe('ABC123');
      });

      test('it should handle scan button click', async () => {
        fireEvent.click(screen.getByLabelText('Scan device id'));
      });

      test('it should handle cancel button', async () => {
        fireEvent.click(screen.getByText('Cancel'));
      });

      test('it should handle apply button with selections', async () => {
        await waitFor(() => {
          const selectedColorElement = screen.getByTestId('selected-color-name');
          expect(selectedColorElement).toHaveTextContent('Cosmic Orange');
        });
        fireEvent.click(screen.getByText('Apply'));
        await waitFor(() => {
          expect(mockAddDevice).toHaveBeenCalledTimes(1);
          expect(mockAddDevice).toHaveBeenCalledWith(
            expect.objectContaining({
              body: expect.objectContaining({
                cartInfo: expect.objectContaining({
                  cartCreator: '7402328882',
                  processingMTN: '7402328882',
                  processStep: 'GridWallPDP',
                  processAction: 'addDevice',
                  intendType: 'EUP',
                  mtnFlow: 'AIQuote',
                }),
                data: expect.objectContaining({
                  lines: expect.arrayContaining([
                    expect.objectContaining({
                      mtn: '7402328882',
                      mdnFilterValue: '7402328882',
                      depletionType: 'L',
                      device: expect.objectContaining({
                        id: 'MFXH4LL/A',
                        contractTerm: 'DPP',
                        dppMonths: 36,
                        isCustomerProvidedEquipment: false,
                        category: 'Smartphones',
                      }),
                    }),
                  ]),
                }),
              }),
            }),
          );
        });
      });

      test('it should handle back button click', async () => {
        fireEvent.click(screen.getByTestId('icon-left-caret'));
      });

      // Footer monthly total test removed: footer monthly label is no longer rendered in DOM.
    });

    // ============================================================
    // Group 2: SKU without image (device image fallback)
    // ============================================================
    describe('with SKU missing imageUrlMap (device image fallback)', () => {
      beforeEach(() => {
        mockGetDetails.mockClear();
        consoleSpy.mockClear();
        renderWithDetails(
          createDeviceProduct({
            childSkus: [
              createSku({
                color: { displayName: 'Blue', colorCssStyle: '#394673' },
                capacity: '128 GB',
                imageUrlMap: undefined,
                price: { devicePaymentPrice: [{ originalPrice: 12, contractDuration: 24 }] },
                inventoryDetails: {
                  dFillInventory: { isInStock: false, isAvailable: false, isPreOrder: false, isBackorder: false },
                  localInventory: { isAvailable: true },
                },
                isInstorePickup: false,
              }),
            ],
          }),
        );
      });

      test('it should fall back to device-level image', async () => {
        await waitFor(() => {
          expect(screen.getByAltText('Test Phone')).toHaveAttribute('src', 'device-image');
        });
      });

      test('it should auto-select local fulfillment when ship is unavailable', async () => {
        await waitFor(() => {
          expect(screen.getByText('Available for local fulfillment')).toBeInTheDocument();
        });
      });

      test('it should show correct monthly price format', async () => {
        expect(screen.getByText('$12/mo for 24mos')).toBeInTheDocument();
      });

      test('it should not show full retail price when missing', async () => {
        expect(screen.queryByText('Full retail price')).toBeNull();
      });

      test('it should show disabled ship option', async () => {
        const shipOption = screen.getByText('Ship this device').closest('[aria-disabled="true"]');
        expect(shipOption).toBeTruthy();
      });

      test('it should auto-select first storage when default not found', async () => {
        // Default selectedStorage is empty, should auto-select '128GB'
        await waitFor(() => {
          const selectedColorElement = screen.getByTestId('selected-color-name');
          expect(selectedColorElement).toHaveTextContent('Blue');
        });
      });
    });

    // ============================================================
    // Group 3: Ship availability OR conditions
    // ============================================================
    describe('ship fulfillment availability branches', () => {
      beforeEach(() => {
        mockGetDetails.mockClear();
        consoleSpy.mockClear();
      });

      test('it should show available to ship when isInStock is true', async () => {
        renderWithDetails(
          createDeviceProduct({
            childSkus: [
              createSku({
                inventoryDetails: { dFillInventory: { isInStock: true }, localInventory: {} },
                isInstorePickup: false,
              }),
            ],
          }),
        );
        await waitFor(() => {
          expect(screen.getByText('Available to ship')).toBeInTheDocument();
        });
      });

      test('it should show available to ship when isAvailable is true', async () => {
        renderWithDetails(
          createDeviceProduct({
            childSkus: [
              createSku({
                inventoryDetails: { dFillInventory: { isAvailable: true }, localInventory: {} },
                isInstorePickup: false,
              }),
            ],
          }),
        );
        await waitFor(() => {
          expect(screen.getByText('Available to ship')).toBeInTheDocument();
        });
      });

      test('it should show available to ship when isBackorder is true', async () => {
        renderWithDetails(
          createDeviceProduct({
            childSkus: [
              createSku({
                inventoryDetails: { dFillInventory: { isBackorder: true }, localInventory: {} },
                isInstorePickup: false,
              }),
            ],
          }),
        );
        await waitFor(() => {
          expect(screen.getByText('Available to ship')).toBeInTheDocument();
        });
      });

      test('it should show Pre-order subtitle when isPreOrder is true and ship available', async () => {
        renderWithDetails(
          createDeviceProduct({
            childSkus: [
              createSku({
                inventoryDetails: {
                  dFillInventory: { isPreOrder: true, shippingDate: { date: '04/15/2026' } },
                  localInventory: {},
                },
                isInstorePickup: false,
              }),
            ],
          }),
        );
        await waitFor(() => {
          expect(screen.getByText('Pre-order - Ships by 04/15/2026')).toBeInTheDocument();
        });
      });

      test('it should show "Available to ship" in availability text when ship available, not preorder, with shippingDate', async () => {
        renderWithDetails(
          createDeviceProduct({
            childSkus: [
              createSku({
                inventoryDetails: {
                  dFillInventory: {
                    isInStock: true,
                    isPreOrder: false,
                    shippingDate: { date: '04/20/2026' },
                  },
                  localInventory: {},
                },
                isInstorePickup: false,
              }),
            ],
          }),
        );
        await waitFor(() => {
          const availText = screen.getByTestId('ship-availability-text');
          expect(availText).toHaveTextContent('Available to ship');
        });
      });
    });

    // ============================================================
    // Group 4: Local fulfillment OR conditions
    // ============================================================
    describe('local fulfillment availability branches', () => {
      beforeEach(() => {
        mockGetDetails.mockClear();
        consoleSpy.mockClear();
      });

      test('it should show local available when localInventory.isInStock is true', async () => {
        renderWithDetails(
          createDeviceProduct({
            childSkus: [
              createSku({
                inventoryDetails: {
                  dFillInventory: {},
                  localInventory: { isInStock: true },
                },
                isInstorePickup: false,
              }),
            ],
          }),
        );
        await waitFor(() => {
          fireEvent.click(screen.getByText('Local fulfillment'));
          expect(screen.getByText('Available for local fulfillment')).toBeInTheDocument();
        });
      });

      test('it should show local available when localInventory.isAvailable is true', async () => {
        renderWithDetails(
          createDeviceProduct({
            childSkus: [
              createSku({
                inventoryDetails: {
                  dFillInventory: {},
                  localInventory: { isAvailable: true },
                },
                isInstorePickup: false,
              }),
            ],
          }),
        );
        await waitFor(() => {
          fireEvent.click(screen.getByText('Local fulfillment'));
          expect(screen.getByText('Available for local fulfillment')).toBeInTheDocument();
        });
      });
    });

    // ============================================================
    // Group 5: All fulfillment disabled
    // ============================================================
    describe('with all fulfillment disabled', () => {
      beforeEach(() => {
        mockGetDetails.mockClear();
        consoleSpy.mockClear();
        renderWithDetails(
          createDeviceProduct({
            childSkus: [
              createSku({
                color: { displayName: 'Red', colorCssStyle: '#FF0000' },
                capacity: '128 GB',
                price: { fullRetailPrice: { originalPrice: 55 } },
                inventoryDetails: {},
                isInstorePickup: false,
              }),
            ],
          }),
        );
      });

      test('it should show Not available for all three fulfillment options', async () => {
        await waitFor(() => {
          const selectedColorElement = screen.getByTestId('selected-color-name');
          expect(selectedColorElement).toHaveTextContent('Red');
        });
        expect(screen.getAllByText('Not available')).toHaveLength(3);
      });

      test('it should show retail price when only fullRetailPrice is available', async () => {
        await waitFor(() => {
          expect(screen.getByText('$55')).toBeInTheDocument();
        });
        expect(screen.getByText('Full retail price')).toBeInTheDocument();
      });

      test('it should handle apply with normalised storage in selections', async () => {
        await waitFor(() => {
          const selectedColorElement = screen.getByTestId('selected-color-name');
          expect(selectedColorElement).toHaveTextContent('Red');
        });
        fireEvent.click(screen.getByText('Apply'));
      });
    });

    // ============================================================
    // Group 6: Purchase option branches
    // ============================================================
    describe('purchase option edge cases', () => {
      beforeEach(() => {
        mockGetDetails.mockClear();
        consoleSpy.mockClear();
      });

      test('it should show only monthly when no fullRetailPrice', async () => {
        renderWithDetails(
          createDeviceProduct({
            childSkus: [
              createSku({
                price: { devicePaymentPrice: [{ originalPrice: 20, contractDuration: 36 }] },
              }),
            ],
          }),
        );
        expect(screen.getByText('$20/mo for 36mos')).toBeInTheDocument();
        expect(screen.queryByText('Full retail price')).toBeNull();
      });
    });

    // ============================================================
    // Group 7: Fallback to mock data (no API data)
    // ============================================================
    describe('with no API data (fallback to mock)', () => {
      beforeEach(() => {
        mockGetDetails.mockClear();
        consoleSpy.mockClear();
        renderWithDetails(null);
      });

      test('it should fall back to mock device data', async () => {
        await waitFor(() => {
          const productNameElement = screen.queryByText('iPhone 17 Pro Max');
          // When there's no API data, it uses default "Apple iPhone 17 Pro"
          const defaultProductName = screen.queryByText('Apple iPhone 17 Pro');
          expect(productNameElement || defaultProductName).toBeInTheDocument();
        });
        expect(mockGetDetails).toHaveBeenCalled();
      });
    });

    // ============================================================
    // Group 8: Empty device data (all defaults)
    // ============================================================
    describe('with empty device data (defaults)', () => {
      beforeEach(() => {
        mockGetDetails.mockClear();
        consoleSpy.mockClear();
        renderWithDetails({});
      });

      test('it should show default product name', async () => {
        await waitFor(() => {
          expect(screen.getByText('Apple iPhone 17 Pro')).toBeInTheDocument();
        });
      });

      test('it should show Not available for all fulfillment', async () => {
        expect(screen.getAllByText('Not available')).toHaveLength(3);
      });
    });

    // ============================================================
    // Group 8a: Fallback div for missing product image (lines 712-713)
    // ============================================================
    describe('product image rendering fallback', () => {
      beforeEach(() => {
        mockGetDetails.mockClear();
        consoleSpy.mockClear();
      });

      test('it should render product image when available', async () => {
        // Coverage for image rendering - truthy path
        renderWithDetails(
          createDeviceProduct({
            imageUrlMap: { largeImage: 'test-device-image.png' },
            childSkus: [
              createSku({
                imageUrlMap: { largeImage: 'test-sku-image.png' },
              }),
            ],
          }),
        );

        await waitFor(() => {
          const productImageElement = screen.queryByTestId('product-image');
          expect(productImageElement).toBeInTheDocument();
          expect(productImageElement).toHaveAttribute('src', 'test-sku-image.png');
        });
      });

      test('it should render fallback div when productImage is falsy', async () => {
        // Coverage for lines 712-713: fallback div when productImage is falsy
        // Set environment variable to force empty placeholder
        const originalEnv = process.env.TEST_EMPTY_IMAGE;
        process.env.TEST_EMPTY_IMAGE = 'true';

        renderWithDetails(
          createDeviceProduct({
            imageUrlMap: undefined,
            childSkus: [
              createSku({
                imageUrlMap: undefined,
              }),
            ],
          }),
        );

        await waitFor(() => {
          // With TEST_EMPTY_IMAGE set and no image sources, productImage is falsy
          // The fallback div should render instead of DeviceImg
          const productImageElement = screen.queryByTestId('product-image');
          expect(productImageElement).not.toBeInTheDocument();

          // Verify the component still renders
          expect(screen.getByTestId('device-configuration-page')).toBeInTheDocument();
        });

        // Restore environment variable
        if (originalEnv) {
          process.env.TEST_EMPTY_IMAGE = originalEnv;
        } else {
          delete process.env.TEST_EMPTY_IMAGE;
        }
      });
    });

    // ============================================================
    // Group 8b: SKU with no inventoryDetails property
    // ============================================================
    describe('with SKU missing inventoryDetails entirely', () => {
      beforeEach(() => {
        mockGetDetails.mockClear();
        consoleSpy.mockClear();
        renderWithDetails(
          createDeviceProduct({
            childSkus: [
              createSku({
                inventoryDetails: undefined,
                isInstorePickup: false,
              }),
            ],
          }),
        );
      });

      test('it should default to all fulfillment unavailable', async () => {
        expect(screen.getAllByText('Not available')).toHaveLength(3);
      });
    });

    // ============================================================
    // Group 9: Auto-select behaviour
    // ============================================================
    describe('auto-select behaviour', () => {
      beforeEach(() => {
        mockGetDetails.mockClear();
        consoleSpy.mockClear();
      });

      test('it should auto-select the first color when default color not in list', async () => {
        // Default selectedColor is 'cosmic-orange'; only 'Deep Blue' is available
        renderWithDetails(
          createDeviceProduct({
            childSkus: [
              createSku({
                color: { displayName: 'Deep Blue', colorCssStyle: '#394673' },
              }),
            ],
          }),
        );
        await waitFor(() => {
          const selectedColorElement = screen.getByTestId('selected-color-name');
          expect(selectedColorElement).toHaveTextContent('Deep Blue');
        });
      });

      test('it should auto-select the first storage when default storage not in list', async () => {
        // Default selectedStorage is '256GB'; only '128 GB' (128GB) is available
        renderWithDetails(
          createDeviceProduct({
            childSkus: [
              createSku({
                capacity: '128 GB',
              }),
            ],
          }),
        );
        await waitFor(() => {
          expect(screen.getByText('128 GB')).toBeInTheDocument();
        });
      });

      test('it should auto-select first available fulfillment when current is disabled', async () => {
        // ship disabled, local available → should auto-select local
        renderWithDetails(
          createDeviceProduct({
            childSkus: [
              createSku({
                inventoryDetails: {
                  dFillInventory: { isInStock: false, isAvailable: false, isPreOrder: false, isBackorder: false },
                  localInventory: { isInStock: true },
                },
                isInstorePickup: false,
              }),
            ],
          }),
        );
        await waitFor(() => {
          expect(screen.getByText('Available for local fulfillment')).toBeInTheDocument();
        });
      });
    });

    // ============================================================
    // Group 10: In-store pickup
    // ============================================================
    describe('in-store pickup availability', () => {
      beforeEach(() => {
        mockGetDetails.mockClear();
        consoleSpy.mockClear();
      });

      test('it should enable in-store when isInstorePickup is true', async () => {
        renderWithDetails(
          createDeviceProduct({
            childSkus: [
              createSku({
                inventoryDetails: { dFillInventory: {}, localInventory: {} },
                isInstorePickup: true,
              }),
            ],
          }),
        );
        fireEvent.click(screen.getByText('In Store pickup'));
        expect(screen.getByText('Available for in-store pickup')).toBeInTheDocument();
      });

      test('it should disable in-store when isInstorePickup is false', async () => {
        renderWithDetails(
          createDeviceProduct({
            childSkus: [
              createSku({
                inventoryDetails: { dFillInventory: {}, localInventory: {} },
                isInstorePickup: false,
              }),
            ],
          }),
        );
        const instoreOption = screen.getByText('In Store pickup').closest('[aria-disabled="true"]');
        expect(instoreOption).toBeTruthy();
      });
    });

    // ============================================================
    // Group 11: Multiple interactions in sequence
    // ============================================================
    describe('sequential user interactions', () => {
      beforeEach(() => {
        mockGetDetails.mockClear();
        consoleSpy.mockClear();
        renderWithDetails(
          createDeviceProduct({
            childSkus: [
              createSku(),
              createSku({
                color: { displayName: 'Deep Blue', colorCssStyle: '#394673' },
                capacity: '256 GB',
                imageUrlMap: { largeImage: 'sku-image-blue-256' },
                inventoryDetails: {
                  dFillInventory: { isInStock: true, shippingDate: { date: '05/01/2026' } },
                  localInventory: { isAvailable: true },
                },
                isInstorePickup: true,
              }),
            ],
          }),
        );
      });

      test('it should update image when color changes', async () => {
        fireEvent.click(screen.getByLabelText('Select Deep Blue'));
        await waitFor(() => {
          expect(screen.getByAltText('Test Phone')).toHaveAttribute('src', 'sku-image-blue-256');
        });
      });

      test('it should update when clicking a storage option', async () => {
        // Both SKUs share 256 GB; click the 256 GB storage radio
        const storageOption = screen.getByTestId('storage-256GB');
        fireEvent.click(storageOption);
        expect(storageOption).toBeInTheDocument();
      });

      test('it should handle full interaction flow: color, storage, fulfillment, apply', async () => {
        fireEvent.click(screen.getByLabelText('Select Deep Blue'));
        fireEvent.click(screen.getByText('Full retail price'));
        fireEvent.click(screen.getByText('Local fulfillment'));
        fireEvent.change(screen.getByLabelText('Device ID'), { target: { value: 'DEV-001' } });
        fireEvent.click(screen.getByText('Apply'));
      });
    });
  });
};

Test(CHANNELS.OMNI_RETAIL);

describe('PDP.utils coverage in PDP.test', () => {
  describe('useDeviceData', () => {
    test('triggers getDetails on mount with expected request', async () => {
      renderHook(() => useDeviceData('MFXH4LL/A', 'dev21413629', '2032146295'));

      await waitFor(() => {
        expect(mockGetDetails).toHaveBeenCalledWith(
          expect.objectContaining({
            body: expect.objectContaining({
              data: expect.objectContaining({
                defaultSku: 'MFXH4LL/A',
                productId: 'dev21413629',
                processingMTN: '2032146295',
                productType: 'device',
              }),
            }),
            spinner: true,
          }),
          false,
        );
      });
    });

    test('sets deviceData only when details response has deviceProduct', async () => {
      mockDetailsResult = {};
      const { result, rerender } = renderHook(() => useDeviceData('MFXH4LL/A', 'dev21413629', '2032146295'));
      await waitFor(() => {
        expect(result.current).toBeNull();
      });

      mockDetailsResult = { data: { data: { deviceProduct: { productDisplayName: 'Test Device' } } } };
      rerender();

      await waitFor(() => {
        expect(result.current).toEqual({ productDisplayName: 'Test Device' });
      });
    });
  });

  describe('buildAddDeviceRequest', () => {
    test('builds DPP + Local payload and prioritizes selectedDeviceSkuId', () => {
      const payload = buildAddDeviceRequest({
        processingMTN: '2032146295',
        selectedDeviceSkuId: 'SELECTED-SKU',
        currentSku: createSku({ sorId: 'MFXA4LL/A' }),
        purchaseOption: 'monthly',
        fulfillmentOption: 'local',
        deviceId: '',
      });

      expect(payload.data.lines[0].device.id).toBe('SELECTED-SKU');
      expect(payload.data.lines[0].device.contractTerm).toBe('DPP');
      expect(payload.data.lines[0].depletionType).toBe('L');
      expect(payload.cartInfo.processingMTN).toBe('2032146295');
    });

    test('builds FRP + Ship payload and resolves fallback values', () => {
      const payload = buildAddDeviceRequest({
        processingMTN: undefined,
        selectedDeviceSkuId: '',
        currentSku: createSku({
          sorId: undefined,
          id: undefined,
          sku: undefined,
          skuId: 'sku6037281',
          category: undefined,
          price: { devicePaymentPrice: [{ contractDuration: undefined }] },
        }),
        purchaseOption: 'retail',
        fulfillmentOption: 'ship',
        deviceId: undefined,
      });

      expect(payload.cartInfo.processingMTN).toBe('');
      expect(payload.cartInfo.cartCreator).toBe('');
      expect(payload.data.lines[0].device.id).toBe('sku6037281');
      expect(payload.data.lines[0].device.contractTerm).toBe('FRP');
      expect(payload.data.lines[0].device.dppMonths).toBe(36);
      expect(payload.data.lines[0].device.category).toBe('Smartphones');
      expect(payload.data.lines[0].device.deviceId).toBe('');
      expect(payload.data.lines[0].depletionType).toBe('F');
    });

    test('handles empty sku resolution when selectedDeviceSkuId and currentSku are missing', () => {
      const payload = buildAddDeviceRequest({
        processingMTN: '2032146295',
        selectedDeviceSkuId: '',
        currentSku: undefined,
        purchaseOption: 'monthly',
        fulfillmentOption: 'local',
        deviceId: '',
      });
      expect(payload.data.lines[0].device.id).toBe('');
    });

    test('falls through device id chain when only sorId/id/sku are present', () => {
      expect(
        buildAddDeviceRequest({
          processingMTN: '1',
          selectedDeviceSkuId: '',
          currentSku: createSku({ sorId: 'SOR-ONLY', id: undefined, sku: undefined, skuId: undefined }),
          purchaseOption: 'monthly',
          fulfillmentOption: 'instore',
          deviceId: 'abc',
        }).data.lines[0].device.id,
      ).toBe('SOR-ONLY');

      expect(
        buildAddDeviceRequest({
          processingMTN: '1',
          selectedDeviceSkuId: '',
          currentSku: createSku({ sorId: undefined, id: 'ID-ONLY', sku: undefined, skuId: undefined }),
          purchaseOption: 'monthly',
          fulfillmentOption: 'local',
          deviceId: 'abc',
        }).data.lines[0].device.id,
      ).toBe('ID-ONLY');

      expect(
        buildAddDeviceRequest({
          processingMTN: '1',
          selectedDeviceSkuId: '',
          currentSku: createSku({ sorId: undefined, id: undefined, sku: 'SKU-ONLY', skuId: undefined }),
          purchaseOption: 'monthly',
          fulfillmentOption: 'local',
          deviceId: 'abc',
        }).data.lines[0].device.id,
      ).toBe('SKU-ONLY');
    });
  });

  describe('getSelectedDeviceSkuId', () => {
    test('returns empty string when childSkus missing', () => {
      expect(getSelectedDeviceSkuId(null, 'deep-blue', '256GB')).toBe('');
      expect(getSelectedDeviceSkuId({}, 'deep-blue', '256GB')).toBe('');
    });

    test('returns matching sku sorId for selected color/storage', () => {
      const deviceData = {
        childSkus: [
          createSku({ sorId: 'MFXU4LL/A', color: { displayName: 'Deep Blue' }, capacity: '1 TB' }),
          createSku({ sorId: 'MFXH4LL/A', color: { displayName: 'Cosmic Orange' }, capacity: '256 GB' }),
        ],
      };
      expect(getSelectedDeviceSkuId(deviceData, 'cosmic-orange', '256GB')).toBe('MFXH4LL/A');
    });

    test('falls back to first sku and resolves id fallbacks', () => {
      const deviceData = {
        childSkus: [createSku({ sorId: undefined, id: undefined, sku: undefined, skuId: 'sku6037395' })],
      };
      expect(getSelectedDeviceSkuId(deviceData, 'not-found', '999GB')).toBe('sku6037395');
    });

    test('covers return fallback chain: id, sku, and empty string', () => {
      expect(
        getSelectedDeviceSkuId(
          { childSkus: [createSku({ sorId: undefined, id: 'ID-ONLY', sku: undefined, skuId: undefined })] },
          'not-found',
          '999GB',
        ),
      ).toBe('ID-ONLY');

      expect(
        getSelectedDeviceSkuId(
          { childSkus: [createSku({ sorId: undefined, id: undefined, sku: 'SKU-ONLY', skuId: undefined })] },
          'not-found',
          '999GB',
        ),
      ).toBe('SKU-ONLY');

      expect(
        getSelectedDeviceSkuId(
          { childSkus: [createSku({ sorId: undefined, id: undefined, sku: undefined, skuId: undefined })] },
          'not-found',
          '999GB',
        ),
      ).toBe('');
    });
  });

  describe('useAddDeviceApi', () => {
    test('exposes addDevice result and wraps trigger payload', async () => {
      mockAddDevice.mockResolvedValue({ data: { serviceHeader: { statusMsg: 'SUCCESS' } } });
      mockAddDeviceResult = { isLoading: true };
      const { result } = renderHook(() => useAddDeviceApi());
      const requestBody = { cartInfo: { processingMTN: '2032146295' } };

      await act(async () => {
        await result.current.triggerAddDevice(requestBody);
      });

      expect(result.current.addDeviceResult).toEqual({ isLoading: true });
      expect(mockAddDevice).toHaveBeenCalledWith({ body: requestBody });
    });
  });

  describe('option derivation hooks', () => {
    test('useColors handles empty and deduplicates colors', () => {
      const { result: empty } = renderHook(() => useColors(null));
      expect(empty.current).toEqual([]);

      const { result } = renderHook(() =>
        useColors({
          childSkus: [
            createSku({ color: { displayName: 'Deep Blue', colorCssStyle: '#394673' } }),
            createSku({ color: { displayName: 'Deep Blue', colorCssStyle: '#394673' } }),
            createSku({ color: null }),
          ],
        }),
      );
      expect(result.current).toHaveLength(1);
      expect(result.current[0]).toEqual({ id: 'deep-blue', name: 'Deep Blue', hex: '#394673' });
    });

    test('useStorageOptions handles empty and deduplicates capacity', () => {
      const { result: empty } = renderHook(() => useStorageOptions(null));
      expect(empty.current).toEqual([]);

      const { result } = renderHook(() =>
        useStorageOptions({
          childSkus: [
            createSku({ capacity: '256 GB' }),
            createSku({ capacity: '256 GB' }),
            createSku({ capacity: '' }),
          ],
        }),
      );
      expect(result.current).toHaveLength(1);
      expect(result.current[0]).toEqual({ id: '256GB', label: '256 GB', value: '256GB' });
    });

    test('useCurrentSku handles empty, exact match, and fallback to first', () => {
      const { result: empty } = renderHook(() => useCurrentSku(null, 'deep-blue', '1TB'));
      expect(empty.current).toBeNull();

      const skus = [
        createSku({ sorId: 'FIRST', color: { displayName: 'Silver' }, capacity: '256 GB' }),
        createSku({ sorId: 'MATCHED', color: { displayName: 'Deep Blue' }, capacity: '1 TB' }),
      ];

      const { result: matched } = renderHook(() => useCurrentSku({ childSkus: skus }, 'deep-blue', '1TB'));
      expect(matched.current.sorId).toBe('MATCHED');

      const { result: fallback } = renderHook(() => useCurrentSku({ childSkus: skus }, 'not-exist', '999GB'));
      expect(fallback.current.sorId).toBe('FIRST');
    });

    test('usePurchaseOptions covers no price, monthly only, retail only, and both', () => {
      expect(renderHook(() => usePurchaseOptions(null)).result.current).toEqual([]);

      expect(
        renderHook(() =>
          usePurchaseOptions({ price: { devicePaymentPrice: [{ originalPrice: 10, contractDuration: 36 }] } }),
        ).result.current,
      ).toHaveLength(1);

      expect(
        renderHook(() => usePurchaseOptions({ price: { fullRetailPrice: { originalPrice: 999 } } })).result.current,
      ).toHaveLength(1);

      expect(
        renderHook(() =>
          usePurchaseOptions({
            price: {
              devicePaymentPrice: [{ originalPrice: 10, contractDuration: 36 }],
              fullRetailPrice: { originalPrice: 999 },
            },
          }),
        ).result.current,
      ).toHaveLength(2);
    });

    test('useFulfillmentAvailability and useFulfillmentOptions cover all subtitle branches', () => {
      expect(renderHook(() => useFulfillmentAvailability(null)).result.current).toEqual({
        local: false,
        instore: false,
        ship: false,
      });

      const preOrderAvailability = renderHook(() =>
        useFulfillmentAvailability(
          createSku({
            inventoryDetails: { dFillInventory: { isPreOrder: true }, localInventory: { isAvailable: true } },
            isInstorePickup: true,
          }),
        ),
      ).result.current;

      const optionsPreOrder = renderHook(() => useFulfillmentOptions(preOrderAvailability)).result.current;
      expect(optionsPreOrder.find((o) => o.id === 'ship').subtitle).toBe('Pre-order');

      const noShipAvailability = renderHook(() =>
        useFulfillmentAvailability(
          createSku({ inventoryDetails: { dFillInventory: {}, localInventory: {} }, isInstorePickup: false }),
        ),
      ).result.current;
      const optionsNoShip = renderHook(() => useFulfillmentOptions(noShipAvailability)).result.current;
      expect(optionsNoShip.find((o) => o.id === 'ship').subtitle).toBe('Not available');

      const shipAvailability = renderHook(() =>
        useFulfillmentAvailability(
          createSku({
            inventoryDetails: { dFillInventory: { isInStock: true }, localInventory: {} },
            isInstorePickup: false,
          }),
        ),
      ).result.current;
      const optionsShip = renderHook(() => useFulfillmentOptions(shipAvailability)).result.current;
      expect(optionsShip.find((o) => o.id === 'ship').subtitle).toBe('Available to ship');

      const missingInventoryAvailability = renderHook(() =>
        useFulfillmentAvailability(createSku({ inventoryDetails: undefined })),
      ).result.current;
      expect(missingInventoryAvailability).toEqual(
        expect.objectContaining({
          local: undefined,
          instore: true,
          ship: undefined,
        }),
      );
    });
  });
});
