import { useEffect, useState } from 'react';
import { useLazyGetTypeAheadQuery } from 'onevzsoemfecommon/APIService';
import {
  useLazyGetProductListQuery,
  useLazyGetSkuDetailsQuery,
} from '../../../modules/services/APIService/APIServiceHooks';
import { transformProductListRequest } from '../../../utils/commonFunctions';

export default function useProductApi(initialBrand = 'Apple', processingMtn = '') {
  const [devices, setDevices] = useState([]);
  const [activeBrand, setActiveBrand] = useState(initialBrand);
  const [typeAheadResults, setTypeAheadResults] = useState([]);
  const [lastTypeAheadHadProductList, setLastTypeAheadHadProductList] = useState(false);
  const [triggerProductList, productListResult] = useLazyGetProductListQuery();
  const [getTypeAheadList, TypeAheadListResult] = useLazyGetTypeAheadQuery();
  const [getSkuDetails, skuDetailsResult] = useLazyGetSkuDetailsQuery();

  // Helper to map API product objects into the device shape used by the grid
  function mapProductListToDevices(productList) {
    return productList.map((product) => {
      const defaultSku = product.defaultSKUObj || {};
      const imageUrlMap = defaultSku.imageUrlMap || {};
      const colorInfo = defaultSku.color || {};
      const priceInfo = defaultSku.price || {};
      const devicePayments = priceInfo.devicePaymentPrice || [];

      return {
        id: product.defaultSKU || product.productId,
        productId: product.productId,
        defaultSku: defaultSku.sorId || product.defaultSKU || '',
        name: product.productDisplayName || product.name,
        brand: product?.brandName,
        color: colorInfo.displayName || '',
        storage: defaultSku.capacity || '',
        price: devicePayments[0]?.originalPrice ? `$${devicePayments[0].originalPrice}/mo` : '$0/mo',
        term: devicePayments[0]?.contractDuration ? `for ${devicePayments[0].contractDuration} mos` : 'for 36 mos',
        image: imageUrlMap.mediumImage || imageUrlMap.defaultImage || null,
      };
    });
  }

  // load product list on brand change
  useEffect(() => {
    const requestBody = transformProductListRequest({ brand: activeBrand, category: 'Smartphones' });
    triggerProductList({ body: requestBody }, false);
  }, [activeBrand, triggerProductList]);

  // process product list result
  useEffect(() => {
    if (productListResult.isSuccess && productListResult.data) {
      const gridWallData = productListResult.data?.data?.gridWall;
      const productList = gridWallData?.productList || [];

      const mappedDevices = mapProductListToDevices(productList);

      setDevices(mappedDevices);
    } else if (productListResult.isError) {
      setDevices([]);
    }
  }, [productListResult, activeBrand]);

  // process type ahead results
  useEffect(() => {
    const productList = TypeAheadListResult?.data?.data?.productList || TypeAheadListResult?.data?.productList || [];
    const typeAheadArray =
      TypeAheadListResult?.data?.data?.typeAheadResults || TypeAheadListResult?.data?.typeAheadResults || [];

    if (TypeAheadListResult?.isSuccess && Array.isArray(productList) && productList.length > 0) {
      const mappedDevices = mapProductListToDevices(productList);

      setDevices(mappedDevices);

      const results = productList.map((item) => ({
        productId: item.productId || '',
        productDisplayName: item.productDisplayName || '',
      }));
      setTypeAheadResults(results);
      setLastTypeAheadHadProductList(true);
    } else if (TypeAheadListResult?.isSuccess && Array.isArray(typeAheadArray) && typeAheadArray.length > 0) {
      // Fallback: use simple typeAhead entries
      const results = typeAheadArray.map((item) => ({
        productId: item.productId || item.id || '',
        productDisplayName: item.productDisplayName || item.displayName || '',
      }));
      setTypeAheadResults(results);
      setLastTypeAheadHadProductList(false);
    } else if (TypeAheadListResult?.isSuccess) {
      setTypeAheadResults([]);
      setLastTypeAheadHadProductList(false);
    }
  }, [TypeAheadListResult]);

  // process sku details
  useEffect(() => {
    if (skuDetailsResult?.isSuccess && skuDetailsResult?.data) {
      const skuDetails = skuDetailsResult?.data?.data?.deviceSku?.parentProducts;
      if (skuDetails && skuDetails.length > 0) {
        const mappedDevices = skuDetails.map((product) => ({
          id: product.productId,
          productId: product.productId,
          defaultSku: product.childSkus?.[0]?.sorId || '',
          name: product.productDisplayName,
          brand: product.manufacturerName || activeBrand,
          color: product.childSkus?.[0]?.color?.description || 'N/A',
          storage: product.childSkus?.[0]?.memoryCapacityDesc || 'N/A',
          price: product.childSkus?.[0]?.devicePricing?.dppPrice || 'N/A',
          term: 'for 36 mos',
          image: product.childSkus?.[0]?.imageUrlMap?.defaultImage || null,
        }));
        setDevices(mappedDevices);
      }
    }
  }, [skuDetailsResult, activeBrand]);

  function triggerTypeAhead(searchStr) {
    const trimmed = searchStr?.trim();
    if (!trimmed) return;
    const productType = 'device';
    const params = {
      searchText: trimmed,
      productType,
    };
    getTypeAheadList({ body: params, customHeaders: { flowName: 'AIGuidedShopping' } }, false);
  }

  function getSkuDetailsBySorId(sorId) {
    const params = {
      data: {
        channel: 'assisted',
        sorId,
        cartId: '',
        caseId: '',
        orderType: '',
        intentType: 'EUP',
        locationCode: '',
        processingMTN: processingMtn || '',
        mtn: '',
        productType: 'device',
      },
    };
    getSkuDetails({ body: params, customHeaders: { flowName: 'AIGuidedShopping' }, spinner: true }, false);
  }
  function getAllDevices() {
    return devices;
  }

  return {
    devices,
    setDevices,
    activeBrand,
    setActiveBrand,
    typeAheadResults,
    triggerTypeAhead,
    getSkuDetailsBySorId,
    clearTypeAhead: () => setTypeAheadResults([]),
    getAllDevices,
    lastTypeAheadHadProductList,
  };
}
