import React from 'react';
import { render, screen, fireEvent, waitFor, renderHook } from '@testing-library/react';
import '@testing-library/jest-dom';
import { BrowserRouter as Router } from 'react-router-dom';

import AllDevicesGridwall, { performSearch, productDisplayNameMatches } from './DeviceGridWall';
import useProductApi from './useProductApi';

// Mock the local APIServiceHooks (for useLazyGetProductListQuery, useLazyGetSkuDetailsQuery)
jest.mock('../../../modules/services/APIService/APIServiceHooks', () => ({
  useLazyGetProductListQuery: jest.fn(() => [jest.fn(), { isSuccess: false, isError: false, data: null }]),
  useLazyGetSkuDetailsQuery: jest.fn(() => [jest.fn(), { isSuccess: false, isError: false, data: null }]),
}));

// Mock the common MFE APIServiceHooks (for useLazyGetTypeAheadQuery)
// Resolve the mock directly to avoid relying on Jest moduleNameMapper expansion
jest.mock('onevzsoemfecommon/APIService', () => ({
  useLazyGetTypeAheadQuery: jest.fn(() => [jest.fn(), { isSuccess: false, isError: false, data: null }]),
}));

// Get references to mocked modules for spying/updating in tests
const CommonAPIServiceHooks = require('onevzsoemfecommon/APIService');
const APIServiceHooks = require('../../../modules/services/APIService/APIServiceHooks');

jest.mock('../../../utils/commonFunctions', () => ({
  transformProductListRequest: jest.fn((params) => params),
}));
const utilsModule = require('../../../utils/commonFunctions');

jest.mock('@vds/icons', () => {
  /* eslint-disable global-require */
  const MockReact = require('react');
  const PropTypes = require('prop-types');

  function Icon({ name, size, color, ...props }) {
    return MockReact.createElement('svg', {
      'data-testid': `icon-${name}`,
      'data-size': size,
      'data-color': color,
      ...props,
    });
  }
  Icon.propTypes = {
    name: PropTypes.string,
    size: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
    color: PropTypes.string,
  };
  return { Icon };
});

jest.mock('@vds/button-icons', () => {
  /* eslint-disable global-require */
  const MockReact = require('react');
  const PropTypes = require('prop-types');

  function ButtonIcon({ onClick, renderIcon, ariaLabel, kind, size, ...props }) {
    return MockReact.createElement(
      'button',
      { type: 'button', onClick, 'aria-label': ariaLabel, 'data-kind': kind, 'data-size': size, ...props },
      renderIcon && renderIcon(),
    );
  }
  ButtonIcon.propTypes = {
    onClick: PropTypes.func,
    renderIcon: PropTypes.func,
    ariaLabel: PropTypes.string,
    kind: PropTypes.string,
    size: PropTypes.number,
  };
  return { ButtonIcon };
});

jest.mock('@vds/buttons', () => {
  /* eslint-disable global-require */
  const MockReact = require('react');
  const PropTypes = require('prop-types');

  function Button({ children, onClick, disabled, kind, size, ariaLabel, ...props }) {
    return MockReact.createElement(
      'button',
      { type: 'button', disabled, onClick, 'data-kind': kind, 'data-size': size, 'aria-label': ariaLabel, ...props },
      children,
    );
  }
  Button.propTypes = {
    children: PropTypes.node,
    onClick: PropTypes.func,
    disabled: PropTypes.bool,
    kind: PropTypes.string,
    size: PropTypes.string,
    ariaLabel: PropTypes.string,
  };
  return { Button };
});

jest.mock('@vds/core/icons', () => {
  /* eslint-disable global-require */
  const MockReact = require('react');

  function GenerativeAiFilled(props) {
    return MockReact.createElement('svg', { 'data-testid': 'generative-ai-filled', ...props });
  }
  return { GenerativeAiFilled };
});

jest.mock('@vds/core', () => {
  /* eslint-disable global-require */
  const MockReact = require('react');
  const PropTypes = require('prop-types');

  function Button({ children, onClick, disabled, kind, ...props }) {
    return MockReact.createElement(
      'button',
      { type: 'button', disabled, onClick, 'data-kind': kind, ...props },
      children,
    );
  }
  Button.propTypes = {
    children: PropTypes.node,
    onClick: PropTypes.func,
    disabled: PropTypes.bool,
    kind: PropTypes.string,
  };

  function ButtonIcon({ onClick, renderIcon, ariaLabel, ...props }) {
    return MockReact.createElement(
      'button',
      { type: 'button', onClick, 'aria-label': ariaLabel, ...props },
      renderIcon && renderIcon(),
    );
  }
  ButtonIcon.propTypes = {
    onClick: PropTypes.func,
    renderIcon: PropTypes.func,
    ariaLabel: PropTypes.string,
  };

  function Body({ children, size, color, bold, primitive = 'div', ...props }) {
    const Component = primitive;
    return MockReact.createElement(
      Component,
      { 'data-size': size, 'data-color': color, 'data-bold': bold, ...props },
      children,
    );
  }
  Body.propTypes = {
    children: PropTypes.node,
    size: PropTypes.string,
    color: PropTypes.string,
    bold: PropTypes.bool,
    primitive: PropTypes.oneOfType([PropTypes.string, PropTypes.func]),
  };

  return { Button, ButtonIcon, Body };
});

jest.mock('@vds/inputs', () => {
  /* eslint-disable global-require */
  const MockReact = require('react');
  const PropTypes = require('prop-types');

  function Input({ id, value, onChange, onKeyDown, placeholder, type, ...props }) {
    return MockReact.createElement('input', {
      id,
      value,
      onChange,
      onKeyDown,
      placeholder,
      type,
      'data-testid': props['data-testid'] || 'input',
      ...props,
    });
  }
  Input.propTypes = {
    id: PropTypes.string,
    value: PropTypes.string,
    onChange: PropTypes.func,
    onKeyDown: PropTypes.func,
    placeholder: PropTypes.string,
    type: PropTypes.string,
  };

  return { Input };
});

// Mock styled components
jest.mock('./DeviceGridWall', () => {
  const actualModule = jest.requireActual('./DeviceGridWall');
  return actualModule;
});

// Mock useProductApi - delegate to real impl by default for branch coverage tests
jest.mock('./useProductApi', () => {
  const actual = jest.requireActual('./useProductApi');
  const mockUseProductApi = jest.fn();
  mockUseProductApi.mockImplementation((...args) => actual.default(...args));
  return { __esModule: true, default: mockUseProductApi };
});
const useProductApiModule = require('./useProductApi');

const mockHandlers = {
  onDeviceSelect: jest.fn(),
  onFilterChange: jest.fn(),
  onSearchClick: jest.fn(),
  onScanClick: jest.fn(),
  onBack: jest.fn(),
  onCancel: jest.fn(),
  onConfigureDevice: jest.fn(),
};

const mockProductData = {
  data: {
    gridWall: {
      productList: [
        {
          defaultSKU: 'iphone-1',
          productId: 'prod-1',
          productDisplayName: 'iPhone 15 Pro',
          name: 'iPhone 15 Pro',
          brandName: 'Apple',
          defaultSKUObj: {
            color: { displayName: 'Space Black' },
            capacity: '256GB',
            imageUrlMap: {
              mediumImage: 'https://example.com/iphone-medium.jpg',
              defaultImage: 'https://example.com/iphone-default.jpg',
            },
            price: {
              devicePaymentPrice: [
                {
                  originalPrice: 35,
                  contractDuration: 36,
                },
              ],
            },
          },
        },
        {
          defaultSKU: 'galaxy-1',
          productId: 'prod-2',
          productDisplayName: 'Galaxy S24',
          name: 'Galaxy S24',
          brandName: 'Samsung',
          defaultSKUObj: {
            color: { displayName: 'Phantom Black' },
            capacity: '256GB',
            imageUrlMap: {
              mediumImage: 'https://example.com/galaxy-medium.jpg',
              defaultImage: 'https://example.com/galaxy-default.jpg',
            },
            price: {
              devicePaymentPrice: [
                {
                  originalPrice: 32,
                  contractDuration: 36,
                },
              ],
            },
          },
        },
        {
          defaultSKU: 'pixel-1',
          productId: 'prod-3',
          productDisplayName: 'Pixel 8 Pro',
          name: 'Pixel 8 Pro',
          brandName: 'Google',
          defaultSKUObj: {
            color: { displayName: 'Obsidian' },
            capacity: '256GB',
            imageUrlMap: {
              mediumImage: 'https://example.com/pixel-medium.jpg',
            },
            price: {
              devicePaymentPrice: [
                {
                  originalPrice: 30,
                  contractDuration: 24,
                },
              ],
            },
          },
        },
      ],
    },
  },
};

const renderComponent = (handlers = mockHandlers) =>
  render(
    <Router>
      <AllDevicesGridwall {...handlers} />
    </Router>,
  );

describe('AllDevicesGridwall Component - Comprehensive Coverage', () => {
  let mockTriggerProductList;

  beforeEach(() => {
    jest.clearAllMocks();

    mockTriggerProductList = jest.fn();
    jest.spyOn(APIServiceHooks, 'useLazyGetProductListQuery').mockReturnValue([
      mockTriggerProductList,
      {
        isSuccess: false,
        isError: false,
        data: null,
      },
    ]);

    // Mock useLazyGetTypeAheadQuery from Common MFE
    const mockGetTypeAhead = jest.fn();
    jest
      .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
      .mockReturnValue([mockGetTypeAhead, { isSuccess: false, isError: false, data: null }]);

    // Mock useLazyGetSkuDetailsQuery from local APIServiceHooks
    const mockGetSkuDetails = jest.fn();
    jest
      .spyOn(APIServiceHooks, 'useLazyGetSkuDetailsQuery')
      .mockReturnValue([mockGetSkuDetails, { isSuccess: false, isError: false, data: null }]);

    utilsModule.transformProductListRequest.mockImplementation((params) => params);

    // Restore useProductApi to real impl (restoreAllMocks may clear it)
    const actualUseProductApi = jest.requireActual('./useProductApi').default;
    useProductApiModule.default.mockImplementation((...args) => actualUseProductApi(...args));
  });

  afterEach(() => {
    jest.restoreAllMocks();
    jest.clearAllMocks();
  });

  describe('Component Rendering & Initialization', () => {
    it('should render component with all main sections', () => {
      renderComponent();

      expect(screen.getByTestId('gridwall-container')).toBeInTheDocument();
      expect(screen.getByTestId('top-header-wrapper')).toBeInTheDocument();
      expect(screen.getByTestId('content-wrapper')).toBeInTheDocument();
      expect(screen.getByTestId('bottom-actions-wrapper')).toBeInTheDocument();
    });

    it('should render all brand filter buttons', () => {
      renderComponent();

      expect(screen.getByTestId('filter-button-apple')).toBeInTheDocument();
      expect(screen.getByTestId('filter-button-samsung')).toBeInTheDocument();
      expect(screen.getByTestId('filter-button-google')).toBeInTheDocument();
      expect(screen.getByTestId('filter-button-motorola')).toBeInTheDocument();
    });

    it('should render Apple filter as primary by default', () => {
      renderComponent();

      const appleFilter = screen.getByTestId('filter-button-apple');
      // VDS Button does not use data-kind; verify it renders and has correct aria-label
      expect(appleFilter).toHaveAttribute('aria-label', 'Filter by Apple');
    });

    it('should render non-Apple filters as secondary by default', () => {
      renderComponent();

      const samsungFilter = screen.getByTestId('filter-button-samsung');
      const googleFilter = screen.getByTestId('filter-button-google');

      // VDS Button does not use data-kind; verify they render with correct aria-labels
      expect(samsungFilter).toHaveAttribute('aria-label', 'Filter by Samsung');
      expect(googleFilter).toHaveAttribute('aria-label', 'Filter by Google');
    });

    it('should render header with title and icons', () => {
      renderComponent();

      expect(screen.getByTestId('header-section')).toBeInTheDocument();
      expect(screen.getByTestId('recommendations-title')).toHaveTextContent('Device recommendations');
      expect(screen.getByTestId('generative-ai-filled')).toBeInTheDocument();
    });

    it('should render search and scan buttons', () => {
      renderComponent();

      expect(screen.getByTestId('search-button')).toBeInTheDocument();
      expect(screen.getByTestId('scan-button')).toBeInTheDocument();
      expect(screen.getByTestId('icon-search')).toBeInTheDocument();
      expect(screen.getByTestId('icon-barcode')).toBeInTheDocument();
    });

    it('should render SparkleGradientDef SVG element', () => {
      const { container } = renderComponent();

      // SparkleGradientDef renders a hidden SVG with gradient defs
      const gradientSvg = container.querySelector('svg defs linearGradient#sparkle-gradient');
      expect(gradientSvg).toBeInTheDocument();
    });

    it('should render default devices', () => {
      renderComponent();

      // Default devices removed; expect no device cards by default
      const deviceCards = screen.queryAllByTestId(/^device-card-/);
      expect(deviceCards.length).toBe(0);
    });

    it('should render bottom action buttons', () => {
      renderComponent();

      expect(screen.getByTestId('cancel-button')).toBeInTheDocument();
      expect(screen.getByTestId('configure-button')).toBeInTheDocument();
    });
  });

  describe('Device Selection - All Branches', () => {
    // Ensure tests in this block have real devices available (no more default devices)
    beforeEach(() => {
      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { isSuccess: true, isError: false, data: mockProductData }]);
    });
    it('should have configure button disabled when no device selected', () => {
      renderComponent();

      expect(screen.getByTestId('configure-button')).toBeDisabled();
    });

    it('should enable configure button when device is selected', async () => {
      renderComponent();

      const selectButton = screen.getAllByTestId(/^select-button-/)[0];
      fireEvent.click(selectButton);

      await waitFor(() => {
        expect(screen.getByTestId('configure-button')).not.toBeDisabled();
      });
    });

    it('should call onDeviceSelect callback with device ID', async () => {
      const handlers = { ...mockHandlers };
      renderComponent(handlers);

      const selectButton = screen.getAllByTestId(/^select-button-/)[0];
      fireEvent.click(selectButton);

      await waitFor(() => {
        expect(handlers.onDeviceSelect).toHaveBeenCalled();
      });
    });

    it('should handle selecting device with handleSelectDevice', async () => {
      const handlers = { ...mockHandlers };
      renderComponent(handlers);

      const selectButton = screen.getAllByTestId(/^select-button-/)[0];
      fireEvent.click(selectButton);

      await waitFor(() => {
        expect(handlers.onDeviceSelect).toHaveBeenCalledWith(expect.any(String));
      });
    });
  });

  // ======================================================
  // 3. BRAND FILTERING - BRANCHING LOGIC
  // ======================================================

  describe('Brand Filtering - All Branches', () => {
    it('should call handleFilterClick and update active brand', async () => {
      const handlers = { ...mockHandlers };
      renderComponent(handlers);

      const samsungFilter = screen.getByTestId('filter-button-samsung');
      fireEvent.click(samsungFilter);

      await waitFor(() => {
        expect(handlers.onFilterChange).toHaveBeenCalledWith('Samsung');
      });
    });

    it('should change filter button styles when brand changes', async () => {
      renderComponent();

      const appleFilter = screen.getByTestId('filter-button-apple');
      const samsungFilter = screen.getByTestId('filter-button-samsung');

      // VDS Button does not use data-kind; verify buttons are in the document initially
      expect(appleFilter).toBeInTheDocument();
      expect(samsungFilter).toBeInTheDocument();

      fireEvent.click(samsungFilter);

      await waitFor(() => {
        // After click, both filters should still be present
        expect(appleFilter).toBeInTheDocument();
        expect(samsungFilter).toBeInTheDocument();
      });
    });

    // it('should clear device selection when filter changes', async () => {
    //   renderComponent();

    //   // Select device first
    //   const selectButtons = screen.getAllByTestId(/^select-button-/);
    //   fireEvent.click(selectButtons[0]);

    //   await waitFor(() => {
    //     expect(selectButtons[0]).toHaveTextContent('Selected');
    //   });

    //   // Change filter
    //   const samsungFilter = screen.getByTestId('filter-button-samsung');
    //   fireEvent.click(samsungFilter);

    //   await waitFor(() => {
    //     const newSelectButtons = screen.getAllByTestId(/^select-button-/);
    //     expect(newSelectButtons[0]).toHaveTextContent('Select');
    //   });
    // });

    it('should trigger API call when brand changes', async () => {
      renderComponent();

      const samsungFilter = screen.getByTestId('filter-button-samsung');
      fireEvent.click(samsungFilter);

      await waitFor(() => {
        expect(utilsModule.transformProductListRequest).toHaveBeenCalledWith(
          expect.objectContaining({
            brand: 'Samsung',
            category: 'Smartphones',
          }),
        );
      });
    });

    it('should handle all four brand filters', async () => {
      const handlers = { ...mockHandlers };
      renderComponent(handlers);

      const brands = ['Apple', 'Samsung', 'Google', 'Motorola'];

      const promises = brands.map((brand) => {
        const filter = screen.getByTestId(`filter-button-${brand.toLowerCase()}`);
        fireEvent.click(filter);
        return waitFor(() => expect(handlers.onFilterChange).toHaveBeenCalledWith(brand));
      });

      await Promise.all(promises);
    });

    it('should render correct data-track attribute for each filter', () => {
      renderComponent();

      expect(screen.getByTestId('filter-button-apple')).toHaveAttribute('data-track', 'AllDevices_Filter_Apple');
      expect(screen.getByTestId('filter-button-samsung')).toHaveAttribute('data-track', 'AllDevices_Filter_Samsung');
      expect(screen.getByTestId('filter-button-google')).toHaveAttribute('data-track', 'AllDevices_Filter_Google');
      expect(screen.getByTestId('filter-button-motorola')).toHaveAttribute('data-track', 'AllDevices_Filter_Motorola');
    });
  });

  describe('Action Buttons - Event Handlers', () => {
    it('should call onBack when back button clicked', async () => {
      const handlers = { ...mockHandlers };
      renderComponent(handlers);

      const backButton = screen.getByTestId('back-button');
      fireEvent.click(backButton);

      await waitFor(() => {
        expect(handlers.onBack).toHaveBeenCalled();
      });
    });

    it('should call onCancel when cancel button clicked', async () => {
      const handlers = { ...mockHandlers };
      renderComponent(handlers);

      const cancelButton = screen.getByTestId('cancel-button');
      fireEvent.click(cancelButton);

      await waitFor(() => {
        expect(handlers.onCancel).toHaveBeenCalled();
      });
    });

    it('should call onScanClick when scan button clicked', async () => {
      const handlers = { ...mockHandlers };
      renderComponent(handlers);

      const scanButton = screen.getByTestId('scan-button');
      fireEvent.click(scanButton);

      await waitFor(() => {
        expect(handlers.onScanClick).toHaveBeenCalled();
      });
    });

    it('should pass correct brand to transformProductListRequest on search', async () => {
      renderComponent();

      const samsungFilter = screen.getByTestId('filter-button-samsung');
      fireEvent.click(samsungFilter);

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      await waitFor(() => {
        expect(utilsModule.transformProductListRequest).toHaveBeenCalledWith(
          expect.objectContaining({
            brand: 'Samsung',
            category: 'Smartphones',
          }),
        );
      });
    });

    // it('should call configure handler when configure button clicked', async () => {
    //   const handlers = { ...mockHandlers };
    //   renderComponent(handlers);

    //   // Select device first
    //   const selectButton = screen.getAllByTestId(/^select-button-/)[0];
    //   fireEvent.click(selectButton);

    //   await waitFor(() => {
    //     const configureButton = screen.getByTestId('configure-button');
    //     fireEvent.click(configureButton);
    //   });
    //   await waitFor(() => {
    //     expect(handlers.onConfigureDevice).toHaveBeenCalledWith(
    //       expect.objectContaining({ productId: 'prod-1', defaultSku: 'iphone-1' }),
    //     );
    //   });
    // });

    it('should not call configure handler when button disabled', () => {
      const handlers = { ...mockHandlers };
      renderComponent(handlers);

      const configureButton = screen.getByTestId('configure-button');
      fireEvent.click(configureButton);

      expect(handlers.onConfigureDevice).not.toHaveBeenCalled();
    });
  });

  describe('Device Card Information Display', () => {
    // Provide real product data for these display tests
    beforeEach(() => {
      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { isSuccess: true, isError: false, data: mockProductData }]);
    });
    it('should display device name correctly', () => {
      renderComponent();

      const deviceNames = screen.getAllByTestId(/^device-name-/);
      expect(deviceNames.length).toBeGreaterThan(0);
      deviceNames.forEach((name) => {
        expect(name).toHaveTextContent(/\S+/);
      });
    });

    it('should display device price correctly', () => {
      renderComponent();

      const devicePrices = screen.getAllByTestId(/^device-price-/);
      expect(devicePrices.length).toBeGreaterThan(0);
      devicePrices.forEach((price) => {
        expect(price).toHaveTextContent(/\$/);
      });
    });

    it('should display device term correctly', () => {
      renderComponent();

      const deviceTerms = screen.getAllByTestId(/^device-term-/);
      expect(deviceTerms.length).toBeGreaterThan(0);
      deviceTerms.forEach((term) => {
        expect(term).toHaveTextContent(/for/);
      });
    });

    it('should display device specifications', () => {
      renderComponent();

      const deviceSpecs = screen.getAllByTestId(/^device-specs-/);
      expect(deviceSpecs.length).toBeGreaterThan(0);
    });

    it('should display all device info sections', () => {
      renderComponent();

      const deviceInfos = screen.getAllByTestId(/^device-info-/);
      expect(deviceInfos.length).toBeGreaterThan(0);
    });

    it('should display device image containers', () => {
      renderComponent();

      const imageContainers = screen.getAllByTestId(/^device-image-container-/);
      expect(imageContainers.length).toBeGreaterThan(0);
    });

    it('should display device images', () => {
      renderComponent();

      const deviceImages = screen.getAllByTestId(/^device-image-/);
      expect(deviceImages.length).toBeGreaterThan(0);
    });

    it('should display device price row with price and term', () => {
      renderComponent();

      const priceRows = screen.getAllByTestId(/^device-price-row-/);
      expect(priceRows.length).toBeGreaterThan(0);
    });
  });

  describe('useEffect Hooks - API Calls & Data Processing', () => {
    it('should trigger API call on mount with default Apple brand', async () => {
      renderComponent();

      await waitFor(() => {
        expect(utilsModule.transformProductListRequest).toHaveBeenCalledWith(
          expect.objectContaining({
            brand: 'Apple',
            category: 'Smartphones',
          }),
        );
      });
    });

    it('should trigger API call when brand changes', async () => {
      renderComponent();

      jest.clearAllMocks();

      const samsungFilter = screen.getByTestId('filter-button-samsung');
      fireEvent.click(samsungFilter);

      await waitFor(() => {
        expect(utilsModule.transformProductListRequest).toHaveBeenCalledWith(
          expect.objectContaining({
            brand: 'Samsung',
            category: 'Smartphones',
          }),
        );
      });
    });

    it('should call triggerProductList with correct parameters', async () => {
      renderComponent();

      await waitFor(() => {
        expect(mockTriggerProductList).toHaveBeenCalled();
      });
    });

    it('should handle API success response - isSuccess branch', async () => {
      jest.spyOn(APIServiceHooks, 'useLazyGetProductListQuery').mockReturnValue([
        mockTriggerProductList,
        {
          isSuccess: true,
          isError: false,
          data: mockProductData,
        },
      ]);

      renderComponent();

      await waitFor(() => {
        // Component should still render
        expect(screen.getByTestId('gridwall-container')).toBeInTheDocument();
      });
    });

    it('should handle API error response - isError branch', async () => {
      jest.spyOn(APIServiceHooks, 'useLazyGetProductListQuery').mockReturnValue([
        mockTriggerProductList,
        {
          isSuccess: false,
          isError: true,
          data: null,
        },
      ]);

      renderComponent();

      await waitFor(() => {
        // With default devices removed, expect no device cards on API error
        const deviceCards = screen.queryAllByTestId(/^device-card-/);
        expect(deviceCards.length).toBe(0);
      });
    });

    it('should render no devices when API returns empty list', async () => {
      jest.spyOn(APIServiceHooks, 'useLazyGetProductListQuery').mockReturnValue([
        mockTriggerProductList,
        {
          isSuccess: true,
          isError: false,
          data: { data: { gridWall: { productList: [] } } },
        },
      ]);

      renderComponent();

      await waitFor(() => {
        const deviceCards = screen.queryAllByTestId(/^device-card-/);
        expect(deviceCards.length).toBe(0);
      });
    });

    it('should process product mapping when isSuccess is true', async () => {
      jest.spyOn(APIServiceHooks, 'useLazyGetProductListQuery').mockReturnValue([
        mockTriggerProductList,
        {
          isSuccess: true,
          isError: false,
          data: mockProductData,
        },
      ]);

      renderComponent();

      // Devices should be displayed
      await waitFor(() => {
        expect(screen.getAllByTestId(/^device-card-/)).toBeDefined();
      });
    });

    it('should not process data when both isSuccess and isError are false', async () => {
      jest.spyOn(APIServiceHooks, 'useLazyGetProductListQuery').mockReturnValue([
        mockTriggerProductList,
        {
          isSuccess: false,
          isError: false,
          data: null,
        },
      ]);

      renderComponent();

      // Component should still render (no devices expected)
      await waitFor(() => {
        const deviceCards = screen.queryAllByTestId(/^device-card-/);
        expect(deviceCards.length).toBe(0);
      });
    });
  });

  describe('Optional Chaining & Fallback Handling', () => {
    // it('should handle undefined callbacks gracefully', async () => {
    //   const handlersWithUndefined = {
    //     onDeviceSelect: undefined,
    //     onFilterChange: undefined,
    //     onSearchClick: undefined,
    //     onScanClick: undefined,
    //     onBack: undefined,
    //     onCancel: undefined,
    //     onConfigureDevice: undefined,
    //   };

    //   renderComponent(handlersWithUndefined);

    //   const selectButton = screen.getAllByTestId(/^select-button-/)[0];
    //   fireEvent.click(selectButton);

    //   // Should not throw error
    //   expect(screen.getByTestId('gridwall-container')).toBeInTheDocument();
    // });

    it('should use fallback device icon when image not available', () => {
      renderComponent();

      const deviceIcons = screen.queryAllByTestId(/^device-icon-/);
      // Must at least query without throwing
      expect(deviceIcons).toBeDefined();
    });

    it('should display fallback text for missing color', async () => {
      jest.spyOn(APIServiceHooks, 'useLazyGetProductListQuery').mockReturnValue([
        mockTriggerProductList,
        {
          isSuccess: true,
          isError: false,
          data: {
            data: {
              gridWall: {
                productList: [
                  {
                    defaultSKU: 'test-1',
                    productId: 'prod-1',
                    productDisplayName: 'Test Phone',
                    brandName: 'Apple',
                    defaultSKUObj: {
                      color: {},
                      capacity: '256GB',
                      imageUrlMap: {},
                      price: {
                        devicePaymentPrice: [{ originalPrice: 35, contractDuration: 36 }],
                      },
                    },
                  },
                ],
              },
            },
          },
        },
      ]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId('gridwall-container')).toBeInTheDocument();
      });
    });

    it('should handle missing price information', async () => {
      jest.spyOn(APIServiceHooks, 'useLazyGetProductListQuery').mockReturnValue([
        mockTriggerProductList,
        {
          isSuccess: true,
          isError: false,
          data: {
            data: {
              gridWall: {
                productList: [
                  {
                    defaultSKU: 'test-1',
                    productId: 'prod-1',
                    productDisplayName: 'Test Phone',
                    brandName: 'Apple',
                    defaultSKUObj: {
                      color: { displayName: 'Black' },
                      capacity: '256GB',
                      imageUrlMap: {},
                      price: {
                        devicePaymentPrice: [],
                      },
                    },
                  },
                ],
              },
            },
          },
        },
      ]);

      renderComponent();

      await waitFor(() => {
        const prices = screen.getAllByTestId(/^device-price-/);
        expect(prices.length).toBeGreaterThan(0);
      });
    });

    it('should handle missing brandName by using activeBrand', async () => {
      jest.spyOn(APIServiceHooks, 'useLazyGetProductListQuery').mockReturnValue([
        mockTriggerProductList,
        {
          isSuccess: true,
          isError: false,
          data: {
            data: {
              gridWall: {
                productList: [
                  {
                    defaultSKU: 'test-1',
                    productId: 'prod-1',
                    productDisplayName: 'Test Phone',
                    defaultSKUObj: {
                      color: { displayName: 'Black' },
                      capacity: '256GB',
                      imageUrlMap: {},
                      price: {
                        devicePaymentPrice: [{ originalPrice: 35, contractDuration: 36 }],
                      },
                    },
                  },
                ],
              },
            },
          },
        },
      ]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId('gridwall-container')).toBeInTheDocument();
      });
    });

    it('should handle null gridWallData', async () => {
      jest.spyOn(APIServiceHooks, 'useLazyGetProductListQuery').mockReturnValue([
        mockTriggerProductList,
        {
          isSuccess: true,
          isError: false,
          data: { data: {} },
        },
      ]);

      renderComponent();

      await waitFor(() => {
        // Default devices removed — expect no device cards
        const deviceCards = screen.queryAllByTestId(/^device-card-/);
        expect(deviceCards.length).toBe(0);
      });
    });

    it('should handle null productList', async () => {
      jest.spyOn(APIServiceHooks, 'useLazyGetProductListQuery').mockReturnValue([
        mockTriggerProductList,
        {
          isSuccess: true,
          isError: false,
          data: { data: { gridWall: {} } },
        },
      ]);

      renderComponent();

      await waitFor(() => {
        const deviceCards = screen.queryAllByTestId(/^device-card-/);
        expect(deviceCards.length).toBe(0);
      });
    });
  });

  describe('useMemo - Device Filtering', () => {
    // Provide product data for memo/filter tests
    beforeEach(() => {
      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { isSuccess: true, isError: false, data: mockProductData }]);
    });
    it('should filter devices by active brand', async () => {
      jest.spyOn(APIServiceHooks, 'useLazyGetProductListQuery').mockReturnValue([
        mockTriggerProductList,
        {
          isSuccess: true,
          isError: false,
          data: mockProductData,
        },
      ]);

      renderComponent();

      // Change to Samsung
      const samsungFilter = screen.getByTestId('filter-button-samsung');
      fireEvent.click(samsungFilter);

      await waitFor(() => {
        // Should filter correctly
        expect(screen.getByTestId('gridwall-container')).toBeInTheDocument();
      });
    });

    it('should only show devices matching active brand', () => {
      renderComponent();

      const deviceCards = screen.getAllByTestId(/^device-card-/);
      expect(deviceCards.length).toBeGreaterThan(0);

      // All displayed devices should match brand
      deviceCards.forEach((card) => {
        expect(card).toBeInTheDocument();
      });
    });

    it('should re-compute filtered devices when brand changes', async () => {
      renderComponent();

      const samsungFilter = screen.getByTestId('filter-button-samsung');
      fireEvent.click(samsungFilter);

      await waitFor(() => {
        // Devices should be updated (may be different count or same)
        expect(screen.getAllByTestId(/^device-card-/)).toBeDefined();
      });
    });

    it('should re-compute when devices list changes', async () => {
      renderComponent();

      // Trigger device list change
      jest.spyOn(APIServiceHooks, 'useLazyGetProductListQuery').mockReturnValue([
        mockTriggerProductList,
        {
          isSuccess: true,
          isError: false,
          data: mockProductData,
        },
      ]);

      // Component should handle device list updates
      await waitFor(() => {
        expect(screen.getByTestId('gridwall-container')).toBeInTheDocument();
      });
    });
  });

  describe('PropTypes & Default Props', () => {
    it('should render with no prop callbacks passed', () => {
      renderComponent({});

      expect(screen.getByTestId('gridwall-container')).toBeInTheDocument();
    });

    it('should handle partial callbacks', () => {
      const partialHandlers = {
        onDeviceSelect: jest.fn(),
        onFilterChange: jest.fn(),
      };

      renderComponent(partialHandlers);

      expect(screen.getByTestId('gridwall-container')).toBeInTheDocument();
    });

    it('should accept all callback types', () => {
      renderComponent(mockHandlers);

      expect(screen.getByTestId('gridwall-container')).toBeInTheDocument();
    });
  });

  describe('Complete User Flow Scenarios', () => {
    it('should handle cancel action', async () => {
      const handlers = { ...mockHandlers };
      renderComponent(handlers);

      const cancelButton = screen.getByTestId('cancel-button');
      fireEvent.click(cancelButton);

      await waitFor(() => {
        expect(handlers.onCancel).toHaveBeenCalled();
      });
    });

    it('should handle back navigation', async () => {
      const handlers = { ...mockHandlers };
      renderComponent(handlers);

      const backButton = screen.getByTestId('back-button');
      fireEvent.click(backButton);

      await waitFor(() => {
        expect(handlers.onBack).toHaveBeenCalled();
      });
    });
  });

  describe('Fallback Branch Coverage - defaultSKUObj and nested properties', () => {
    beforeEach(() => {
      mockTriggerProductList = jest.fn();
    });

    it('should use empty object fallback when defaultSKUObj is undefined', async () => {
      jest.spyOn(APIServiceHooks, 'useLazyGetProductListQuery').mockReturnValue([
        mockTriggerProductList,
        {
          isSuccess: true,
          isError: false,
          data: {
            data: {
              gridWall: {
                productList: [
                  {
                    defaultSKU: 'test-device-1',
                    productId: 'prod-1',
                    productDisplayName: 'Test Device',
                    brandName: 'Apple',
                    defaultSKUObj: undefined, // undefined triggers || {} fallback
                  },
                ],
              },
            },
          },
        },
      ]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId('device-card-test-device-1')).toBeInTheDocument();
        // Fallback values: empty color, empty storage, $0/mo price, for 36 mos term
        expect(screen.getByTestId('device-specs-test-device-1').textContent).toMatch(/,/);
        expect(screen.getByTestId('device-price-test-device-1')).toHaveTextContent('$0/mo');
        expect(screen.getByTestId('device-term-test-device-1')).toHaveTextContent('for 36 mos');
      });
    });

    it('should use empty object fallback when defaultSKUObj is null', async () => {
      jest.spyOn(APIServiceHooks, 'useLazyGetProductListQuery').mockReturnValue([
        mockTriggerProductList,
        {
          isSuccess: true,
          isError: false,
          data: {
            data: {
              gridWall: {
                productList: [
                  {
                    defaultSKU: 'test-device-2',
                    productId: 'prod-2',
                    productDisplayName: 'Test Device Null',
                    brandName: 'Apple',
                    defaultSKUObj: null, // null triggers || {} fallback
                  },
                ],
              },
            },
          },
        },
      ]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId('device-card-test-device-2')).toBeInTheDocument();
        expect(screen.getByTestId('device-price-test-device-2')).toHaveTextContent('$0/mo');
      });
    });

    it('should use empty object fallback when imageUrlMap is undefined', async () => {
      jest.spyOn(APIServiceHooks, 'useLazyGetProductListQuery').mockReturnValue([
        mockTriggerProductList,
        {
          isSuccess: true,
          isError: false,
          data: {
            data: {
              gridWall: {
                productList: [
                  {
                    defaultSKU: 'test-device-3',
                    productId: 'prod-3',
                    productDisplayName: 'Test Device No Image',
                    brandName: 'Apple',
                    defaultSKUObj: {
                      imageUrlMap: undefined, // undefined triggers || {} fallback
                      color: { displayName: 'Black' },
                      capacity: '128GB',
                      price: {
                        devicePaymentPrice: [{ originalPrice: 25, contractDuration: 24 }],
                      },
                    },
                  },
                ],
              },
            },
          },
        },
      ]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId('device-card-test-device-3')).toBeInTheDocument();
        // Should show device icon since no image available
        expect(screen.getByTestId('device-icon-test-device-3')).toBeInTheDocument();
      });
    });

    it('should use empty object fallback when color is undefined', async () => {
      jest.spyOn(APIServiceHooks, 'useLazyGetProductListQuery').mockReturnValue([
        mockTriggerProductList,
        {
          isSuccess: true,
          isError: false,
          data: {
            data: {
              gridWall: {
                productList: [
                  {
                    defaultSKU: 'test-device-4',
                    productId: 'prod-4',
                    productDisplayName: 'Test Device No Color',
                    brandName: 'Apple',
                    defaultSKUObj: {
                      imageUrlMap: { mediumImage: 'https://example.com/img.jpg' },
                      color: undefined, // undefined triggers || {} fallback
                      capacity: '256GB',
                      price: {
                        devicePaymentPrice: [{ originalPrice: 30, contractDuration: 36 }],
                      },
                    },
                  },
                ],
              },
            },
          },
        },
      ]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId('device-card-test-device-4')).toBeInTheDocument();
        // Empty color with storage
        expect(screen.getByTestId('device-specs-test-device-4')).toHaveTextContent(', 256GB');
      });
    });

    it('should use empty object fallback when price is undefined', async () => {
      jest.spyOn(APIServiceHooks, 'useLazyGetProductListQuery').mockReturnValue([
        mockTriggerProductList,
        {
          isSuccess: true,
          isError: false,
          data: {
            data: {
              gridWall: {
                productList: [
                  {
                    defaultSKU: 'test-device-5',
                    productId: 'prod-5',
                    productDisplayName: 'Test Device No Price',
                    brandName: 'Apple',
                    defaultSKUObj: {
                      imageUrlMap: { mediumImage: 'https://example.com/img.jpg' },
                      color: { displayName: 'Silver' },
                      capacity: '512GB',
                      price: undefined, // undefined triggers || {} fallback
                    },
                  },
                ],
              },
            },
          },
        },
      ]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId('device-card-test-device-5')).toBeInTheDocument();
        // Fallback price
        expect(screen.getByTestId('device-price-test-device-5')).toHaveTextContent('$0/mo');
        expect(screen.getByTestId('device-term-test-device-5')).toHaveTextContent('for 36 mos');
      });
    });

    it('should use empty array fallback when devicePaymentPrice is undefined', async () => {
      jest.spyOn(APIServiceHooks, 'useLazyGetProductListQuery').mockReturnValue([
        mockTriggerProductList,
        {
          isSuccess: true,
          isError: false,
          data: {
            data: {
              gridWall: {
                productList: [
                  {
                    defaultSKU: 'test-device-6',
                    productId: 'prod-6',
                    productDisplayName: 'Test Device No Payment',
                    brandName: 'Apple',
                    defaultSKUObj: {
                      imageUrlMap: { mediumImage: 'https://example.com/img.jpg' },
                      color: { displayName: 'Gold' },
                      capacity: '128GB',
                      price: {
                        devicePaymentPrice: undefined, // undefined triggers || [] fallback
                      },
                    },
                  },
                ],
              },
            },
          },
        },
      ]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId('device-card-test-device-6')).toBeInTheDocument();
        // Fallback price since devicePayments[0] is undefined
        expect(screen.getByTestId('device-price-test-device-6')).toHaveTextContent('$0/mo');
        expect(screen.getByTestId('device-term-test-device-6')).toHaveTextContent('for 36 mos');
      });
    });

    it('should use empty array fallback when devicePaymentPrice is null', async () => {
      jest.spyOn(APIServiceHooks, 'useLazyGetProductListQuery').mockReturnValue([
        mockTriggerProductList,
        {
          isSuccess: true,
          isError: false,
          data: {
            data: {
              gridWall: {
                productList: [
                  {
                    defaultSKU: 'test-device-7',
                    productId: 'prod-7',
                    productDisplayName: 'Test Device Null Payment',
                    brandName: 'Apple',
                    defaultSKUObj: {
                      imageUrlMap: { defaultImage: 'https://example.com/default.jpg' },
                      color: { displayName: 'Rose' },
                      capacity: '64GB',
                      price: {
                        devicePaymentPrice: null, // null triggers || [] fallback
                      },
                    },
                  },
                ],
              },
            },
          },
        },
      ]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId('device-card-test-device-7')).toBeInTheDocument();
        expect(screen.getByTestId('device-price-test-device-7')).toHaveTextContent('$0/mo');
      });
    });

    it('should handle all nested properties being undefined simultaneously', async () => {
      jest.spyOn(APIServiceHooks, 'useLazyGetProductListQuery').mockReturnValue([
        mockTriggerProductList,
        {
          isSuccess: true,
          isError: false,
          data: {
            data: {
              gridWall: {
                productList: [
                  {
                    defaultSKU: 'test-device-8',
                    productId: 'prod-8',
                    productDisplayName: 'Test Device All Undefined',
                    brandName: 'Apple',
                    defaultSKUObj: {
                      imageUrlMap: undefined,
                      color: undefined,
                      capacity: undefined,
                      price: undefined,
                    },
                  },
                ],
              },
            },
          },
        },
      ]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId('device-card-test-device-8')).toBeInTheDocument();
        expect(screen.getByTestId('device-specs-test-device-8').textContent).toMatch(/,/);
        expect(screen.getByTestId('device-price-test-device-8')).toHaveTextContent('$0/mo');
        expect(screen.getByTestId('device-term-test-device-8')).toHaveTextContent('for 36 mos');
        expect(screen.getByTestId('device-icon-test-device-8')).toBeInTheDocument();
      });
    });

    it('should handle all nested properties being null simultaneously', async () => {
      jest.spyOn(APIServiceHooks, 'useLazyGetProductListQuery').mockReturnValue([
        mockTriggerProductList,
        {
          isSuccess: true,
          isError: false,
          data: {
            data: {
              gridWall: {
                productList: [
                  {
                    defaultSKU: 'test-device-9',
                    productId: 'prod-9',
                    productDisplayName: 'Test Device All Null',
                    brandName: 'Apple',
                    defaultSKUObj: {
                      imageUrlMap: null,
                      color: null,
                      capacity: null,
                      price: null,
                    },
                  },
                ],
              },
            },
          },
        },
      ]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId('device-card-test-device-9')).toBeInTheDocument();
        expect(screen.getByTestId('device-price-test-device-9')).toHaveTextContent('$0/mo');
        expect(screen.getByTestId('device-icon-test-device-9')).toBeInTheDocument();
      });
    });

    it('should use defaultImage when mediumImage is undefined', async () => {
      jest.spyOn(APIServiceHooks, 'useLazyGetProductListQuery').mockReturnValue([
        mockTriggerProductList,
        {
          isSuccess: true,
          isError: false,
          data: {
            data: {
              gridWall: {
                productList: [
                  {
                    defaultSKU: 'test-device-10',
                    productId: 'prod-10',
                    productDisplayName: 'Test Device Default Image',
                    brandName: 'Apple',
                    defaultSKUObj: {
                      imageUrlMap: {
                        mediumImage: undefined,
                        defaultImage: 'https://example.com/default-fallback.jpg',
                      },
                      color: { displayName: 'Blue' },
                      capacity: '256GB',
                      price: {
                        devicePaymentPrice: [{ originalPrice: 40, contractDuration: 36 }],
                      },
                    },
                  },
                ],
              },
            },
          },
        },
      ]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId('device-card-test-device-10')).toBeInTheDocument();
        const img = screen.getByTestId('device-img-test-device-10');
        expect(img).toHaveAttribute('src', 'https://example.com/default-fallback.jpg');
      });
    });

    it('should use productId fallback when defaultSKU is undefined', async () => {
      jest.spyOn(APIServiceHooks, 'useLazyGetProductListQuery').mockReturnValue([
        mockTriggerProductList,
        {
          isSuccess: true,
          isError: false,
          data: {
            data: {
              gridWall: {
                productList: [
                  {
                    defaultSKU: undefined, // undefined triggers || productId fallback
                    productId: 'fallback-prod-id-1',
                    productDisplayName: 'Test Device with ProductId Fallback',
                    brandName: 'Apple',
                    defaultSKUObj: {
                      imageUrlMap: { mediumImage: 'https://example.com/img.jpg' },
                      color: { displayName: 'Red' },
                      capacity: '128GB',
                      price: {
                        devicePaymentPrice: [{ originalPrice: 25, contractDuration: 36 }],
                      },
                    },
                  },
                ],
              },
            },
          },
        },
      ]);

      renderComponent();

      await waitFor(() => {
        // Device card should use productId as the id
        expect(screen.getByTestId('device-card-fallback-prod-id-1')).toBeInTheDocument();
        expect(screen.getByTestId('device-name-fallback-prod-id-1')).toHaveTextContent(
          'Test Device with ProductId Fallback',
        );
      });
    });

    it('should use productId fallback when defaultSKU is null', async () => {
      jest.spyOn(APIServiceHooks, 'useLazyGetProductListQuery').mockReturnValue([
        mockTriggerProductList,
        {
          isSuccess: true,
          isError: false,
          data: {
            data: {
              gridWall: {
                productList: [
                  {
                    defaultSKU: null, // null triggers || productId fallback
                    productId: 'fallback-prod-id-2',
                    productDisplayName: 'Test Device Null SKU',
                    brandName: 'Apple',
                    defaultSKUObj: {
                      imageUrlMap: { mediumImage: 'https://example.com/img2.jpg' },
                      color: { displayName: 'Blue' },
                      capacity: '256GB',
                      price: {
                        devicePaymentPrice: [{ originalPrice: 30, contractDuration: 24 }],
                      },
                    },
                  },
                ],
              },
            },
          },
        },
      ]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId('device-card-fallback-prod-id-2')).toBeInTheDocument();
        expect(screen.getByTestId('device-name-fallback-prod-id-2')).toHaveTextContent('Test Device Null SKU');
      });
    });

    it('should use productId fallback when defaultSKU is empty string', async () => {
      jest.spyOn(APIServiceHooks, 'useLazyGetProductListQuery').mockReturnValue([
        mockTriggerProductList,
        {
          isSuccess: true,
          isError: false,
          data: {
            data: {
              gridWall: {
                productList: [
                  {
                    defaultSKU: '', // empty string triggers || productId fallback
                    productId: 'fallback-prod-id-3',
                    productDisplayName: 'Test Device Empty SKU',
                    brandName: 'Apple',
                    defaultSKUObj: {
                      color: { displayName: 'Green' },
                      capacity: '512GB',
                    },
                  },
                ],
              },
            },
          },
        },
      ]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId('device-card-fallback-prod-id-3')).toBeInTheDocument();
      });
    });

    it('should use product.name fallback when productDisplayName is undefined', async () => {
      jest.spyOn(APIServiceHooks, 'useLazyGetProductListQuery').mockReturnValue([
        mockTriggerProductList,
        {
          isSuccess: true,
          isError: false,
          data: {
            data: {
              gridWall: {
                productList: [
                  {
                    defaultSKU: 'test-device-name-fallback-1',
                    productId: 'prod-name-1',
                    productDisplayName: undefined, // undefined triggers || name fallback
                    name: 'Fallback Device Name',
                    brandName: 'Apple',
                    defaultSKUObj: {
                      imageUrlMap: { mediumImage: 'https://example.com/img3.jpg' },
                      color: { displayName: 'Silver' },
                      capacity: '128GB',
                      price: {
                        devicePaymentPrice: [{ originalPrice: 20, contractDuration: 36 }],
                      },
                    },
                  },
                ],
              },
            },
          },
        },
      ]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId('device-card-test-device-name-fallback-1')).toBeInTheDocument();
        // Should use the fallback name
        expect(screen.getByTestId('device-name-test-device-name-fallback-1')).toHaveTextContent('Fallback Device Name');
      });
    });

    it('should use product.name fallback when productDisplayName is null', async () => {
      jest.spyOn(APIServiceHooks, 'useLazyGetProductListQuery').mockReturnValue([
        mockTriggerProductList,
        {
          isSuccess: true,
          isError: false,
          data: {
            data: {
              gridWall: {
                productList: [
                  {
                    defaultSKU: 'test-device-name-fallback-2',
                    productId: 'prod-name-2',
                    productDisplayName: null, // null triggers || name fallback
                    name: 'Another Fallback Name',
                    brandName: 'Apple',
                    defaultSKUObj: {
                      imageUrlMap: { defaultImage: 'https://example.com/img4.jpg' },
                      color: { displayName: 'Gold' },
                      capacity: '256GB',
                      price: {
                        devicePaymentPrice: [{ originalPrice: 35, contractDuration: 24 }],
                      },
                    },
                  },
                ],
              },
            },
          },
        },
      ]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId('device-card-test-device-name-fallback-2')).toBeInTheDocument();
        expect(screen.getByTestId('device-name-test-device-name-fallback-2')).toHaveTextContent(
          'Another Fallback Name',
        );
      });
    });

    it('should use product.name fallback when productDisplayName is empty string', async () => {
      jest.spyOn(APIServiceHooks, 'useLazyGetProductListQuery').mockReturnValue([
        mockTriggerProductList,
        {
          isSuccess: true,
          isError: false,
          data: {
            data: {
              gridWall: {
                productList: [
                  {
                    defaultSKU: 'test-device-name-fallback-3',
                    productId: 'prod-name-3',
                    productDisplayName: '', // empty string triggers || name fallback
                    name: 'Empty Display Name Fallback',
                    brandName: 'Apple',
                    defaultSKUObj: {
                      color: { displayName: 'Black' },
                      capacity: '64GB',
                    },
                  },
                ],
              },
            },
          },
        },
      ]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId('device-card-test-device-name-fallback-3')).toBeInTheDocument();
        expect(screen.getByTestId('device-name-test-device-name-fallback-3')).toHaveTextContent(
          'Empty Display Name Fallback',
        );
      });
    });

    it('should use both fallbacks when defaultSKU and productDisplayName are undefined', async () => {
      jest.spyOn(APIServiceHooks, 'useLazyGetProductListQuery').mockReturnValue([
        mockTriggerProductList,
        {
          isSuccess: true,
          isError: false,
          data: {
            data: {
              gridWall: {
                productList: [
                  {
                    defaultSKU: undefined, // triggers productId fallback
                    productId: 'both-fallback-id',
                    productDisplayName: undefined, // triggers name fallback
                    name: 'Both Fallbacks Device',
                    brandName: 'Apple',
                    defaultSKUObj: {
                      imageUrlMap: { mediumImage: 'https://example.com/both.jpg' },
                      color: { displayName: 'Purple' },
                      capacity: '128GB',
                      price: {
                        devicePaymentPrice: [{ originalPrice: 22, contractDuration: 36 }],
                      },
                    },
                  },
                ],
              },
            },
          },
        },
      ]);

      renderComponent();

      await waitFor(() => {
        // Should use productId as id
        expect(screen.getByTestId('device-card-both-fallback-id')).toBeInTheDocument();
        // Should use name as display name
        expect(screen.getByTestId('device-name-both-fallback-id')).toHaveTextContent('Both Fallbacks Device');
      });
    });
  });
  describe('TypeAhead Functionality - Complete Coverage', () => {
    let mockGetTypeAhead;
    let mockGetSkuDetails;

    beforeEach(() => {
      mockTriggerProductList = jest.fn();
      mockGetTypeAhead = jest.fn();
      mockGetSkuDetails = jest.fn();

      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { isSuccess: false, isError: false, data: null }]);

      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: false, isError: false, data: null }]);

      jest
        .spyOn(APIServiceHooks, 'useLazyGetSkuDetailsQuery')
        .mockReturnValue([mockGetSkuDetails, { isSuccess: false, isError: false, data: null }]);
    });

    it('should show search input when search button is clicked', async () => {
      renderComponent();

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      await waitFor(() => {
        const searchInput = screen.getByTestId('device-search-input');
        expect(searchInput).toBeInTheDocument();
      });
    });

    it('should hide search input when search button is clicked again', async () => {
      renderComponent();

      const searchButton = screen.getByTestId('search-button');

      // First click - show
      fireEvent.click(searchButton);
      await waitFor(() => {
        expect(screen.getByTestId('device-search-input')).toBeInTheDocument();
      });

      // Second click - hide
      fireEvent.click(searchButton);
      // Input wrapper should have show=false
      expect(screen.getByTestId('search-input-wrapper')).toBeInTheDocument();
    });

    it('should not call search when input is empty', async () => {
      jest.useFakeTimers();

      renderComponent();

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      const searchInput = screen.getByTestId('device-search-input');

      // Type something then clear it
      fireEvent.change(searchInput, { target: { value: 'test' } });
      fireEvent.change(searchInput, { target: { value: '' } });

      jest.advanceTimersByTime(500);

      // Should not call with empty value
      expect(mockGetTypeAhead).not.toHaveBeenCalledWith(
        expect.objectContaining({
          body: expect.objectContaining({ searchText: '' }),
        }),
        expect.anything(),
      );

      jest.useRealTimers();
    });

    it('should trigger search on Enter key press with non-empty input', async () => {
      const handlers = { ...mockHandlers };
      renderComponent(handlers);

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      const searchInput = screen.getByTestId('device-search-input');
      fireEvent.change(searchInput, { target: { value: 'Galaxy' } });
      fireEvent.keyDown(searchInput, { keyCode: 13 });

      await waitFor(() => {
        expect(mockGetTypeAhead).toHaveBeenCalled();
        expect(handlers.onSearchClick).toHaveBeenCalled();
      });
    });

    it('should not trigger search on Enter key press with empty input', async () => {
      const handlers = { ...mockHandlers };
      renderComponent(handlers);

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      const searchInput = screen.getByTestId('device-search-input');
      fireEvent.change(searchInput, { target: { value: '   ' } }); // whitespace only
      fireEvent.keyDown(searchInput, { keyCode: 13 });

      expect(handlers.onSearchClick).not.toHaveBeenCalled();
    });

    it('should not trigger search on non-Enter key press', async () => {
      renderComponent();

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      const searchInput = screen.getByTestId('device-search-input');
      fireEvent.change(searchInput, { target: { value: 'test' } });
      fireEvent.keyDown(searchInput, { keyCode: 65 }); // 'A' key

      // Should not have been called with Enter-specific logic
      expect(mockGetTypeAhead).not.toHaveBeenCalledWith(
        expect.objectContaining({
          body: expect.objectContaining({ searchText: 'test' }),
        }),
        false,
      );
    });

    it('performSearch returns early when search string trims to empty', () => {
      const localMockGetTypeAhead = jest.fn();

      // Empty string should return early and not call the API
      const res1 = performSearch(localMockGetTypeAhead, '');
      expect(res1).toBeUndefined();
      expect(localMockGetTypeAhead).not.toHaveBeenCalled();

      // Whitespace-only should also return early
      const res2 = performSearch(localMockGetTypeAhead, '   ');
      expect(res2).toBeUndefined();
      expect(localMockGetTypeAhead).not.toHaveBeenCalled();
    });

    it('performSearch calls getTypeAheadListFn with valid non-empty search string', () => {
      const localMockGetTypeAhead = jest.fn();

      // Valid search string should call the API
      performSearch(localMockGetTypeAhead, 'Galaxy S24');

      expect(localMockGetTypeAhead).toHaveBeenCalledTimes(1);
      expect(localMockGetTypeAhead).toHaveBeenCalledWith(
        {
          body: { searchText: 'Galaxy S24', productType: 'device' },
          customHeaders: { flowName: 'AIGuidedShopping' },
        },
        false,
      );
    });

    it('performSearch trims whitespace from search string before calling API', () => {
      const localMockGetTypeAhead = jest.fn();

      // String with surrounding whitespace should be trimmed
      performSearch(localMockGetTypeAhead, '  iPhone 15  ');

      expect(localMockGetTypeAhead).toHaveBeenCalledTimes(1);
      expect(localMockGetTypeAhead).toHaveBeenCalledWith(
        {
          body: { searchText: 'iPhone 15', productType: 'device' },
          customHeaders: { flowName: 'AIGuidedShopping' },
        },
        false,
      );
    });

    it('productDisplayNameMatches uses empty string fallback when displayName is undefined/null', () => {
      expect(productDisplayNameMatches(undefined, 'test')).toBe(false);
      expect(productDisplayNameMatches(undefined, '')).toBe(true); // '' includes ''
      expect(productDisplayNameMatches(null, 'search')).toBe(false);
      expect(productDisplayNameMatches(null, '')).toBe(true);
      expect(productDisplayNameMatches('iPhone 15 Pro', 'iphone')).toBe(true);
      expect(productDisplayNameMatches('iPhone 15 Pro', 'galaxy')).toBe(false);
    });

    it('should clear search and hide input when clear button is clicked', async () => {
      renderComponent();

      // Show search input and type something
      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      const searchInput = screen.getByTestId('device-search-input');
      fireEvent.change(searchInput, { target: { value: 'test search' } });

      // Click clear button (close icon)
      const closeIcon = screen.getByTestId('icon-close');
      fireEvent.click(closeIcon.parentElement);

      await waitFor(() => {
        expect(searchInput.value).toBe('');
      });
    });

    it('should display typeAhead results when API returns products', async () => {
      const typeAheadData = {
        data: {
          productList: [
            { productId: 'prod-1', productDisplayName: 'iPhone 15 Pro' },
            { productId: 'prod-2', productDisplayName: 'iPhone 15' },
          ],
        },
      };

      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: true, isError: false, data: typeAheadData }]);

      renderComponent();

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      const searchInput = screen.getByTestId('device-search-input');
      fireEvent.change(searchInput, { target: { value: 'iPhone' } });

      await waitFor(() => {
        expect(screen.getByTestId('search-dropdown')).toBeInTheDocument();
        expect(screen.getByTestId('search-result-prod-1')).toBeInTheDocument();
        expect(screen.getByTestId('search-result-prod-2')).toBeInTheDocument();
      });
    });

    it('should handle typeAhead with typeAheadResults response shape', async () => {
      const typeAheadData = {
        data: {
          typeAheadResults: [{ id: 'type-1', displayName: 'TypeAhead Result 1' }],
        },
      };

      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: true, isError: false, data: typeAheadData }]);

      renderComponent();

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      const searchInput = screen.getByTestId('device-search-input');
      fireEvent.change(searchInput, { target: { value: 'TypeAhead' } });

      await waitFor(() => {
        expect(screen.getByTestId('search-result-type-1')).toBeInTheDocument();
      });
    });

    it('should handle typeAhead with products response shape', async () => {
      // The hook expects productList or typeAheadResults shapes; adapt test to productList
      const typeAheadData = {
        data: {
          productList: [{ productId: 'sku-1', productDisplayName: 'SKU Product' }],
        },
      };

      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: true, isError: false, data: typeAheadData }]);

      renderComponent();

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      const searchInput = screen.getByTestId('device-search-input');
      fireEvent.change(searchInput, { target: { value: 'SKU' } });

      await waitFor(() => {
        expect(screen.getByTestId('search-result-sku-1')).toBeInTheDocument();
      });
    });

    it('should use "Unknown product" fallback when no display name fields exist', async () => {
      const typeAheadData = {
        data: {
          productList: [
            { productId: 'unknown-1' }, // No display name fields
          ],
        },
      };

      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: true, isError: false, data: typeAheadData }]);

      renderComponent();

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      const searchInput = screen.getByTestId('device-search-input');
      fireEvent.change(searchInput, { target: { value: 'Unknown' } });

      // Component doesn't synthesize 'Unknown product' displayName — expect no dropdown entry
      await waitFor(() => {
        expect(screen.queryByTestId('search-result-unknown-1')).not.toBeInTheDocument();
      });
    });

    it('should render dropdown when productDisplayName is empty string and evaluate fallback to empty string in filter', async () => {
      const typeAheadData = {
        data: {
          productList: [{ productId: 'empty-1', productDisplayName: '' }],
        },
      };

      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: true, isError: false, data: typeAheadData }]);

      renderComponent();

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      const searchInput = screen.getByTestId('device-search-input');
      fireEvent.change(searchInput, { target: { value: 'a' } });

      await waitFor(() => {
        expect(screen.getByTestId('search-dropdown')).toBeInTheDocument();
      });

      // But because productDisplayName is empty string, the specific result should not be shown
      expect(screen.queryByTestId('search-result-empty-1')).not.toBeInTheDocument();
    });

    it('should clear typeAhead results when API success but no products', async () => {
      // First set some results
      const initialData = {
        data: {
          productList: [{ productId: 'temp-1', productDisplayName: 'Temp' }],
        },
      };

      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: true, isError: false, data: initialData }]);

      const { rerender } = render(
        <Router>
          <AllDevicesGridwall {...mockHandlers} />
        </Router>,
      );

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      const searchInput = screen.getByTestId('device-search-input');
      fireEvent.change(searchInput, { target: { value: 'Temp' } });

      // Now mock empty response
      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: true, isError: false, data: { data: { productList: [] } } }]);

      rerender(
        <Router>
          <AllDevicesGridwall {...mockHandlers} />
        </Router>,
      );

      // Dropdown should not be visible when no results
      expect(screen.queryByTestId('search-dropdown')).not.toBeInTheDocument();
    });

    it('should select typeAhead result and call getSkuDetails', async () => {
      const typeAheadData = {
        data: {
          productList: [{ productId: 'select-prod-1', productDisplayName: 'Selected Product' }],
        },
      };

      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: true, isError: false, data: typeAheadData }]);

      renderComponent();

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      const searchInput = screen.getByTestId('device-search-input');
      fireEvent.change(searchInput, { target: { value: 'Selected' } });

      await waitFor(() => {
        expect(screen.getByTestId('search-result-select-prod-1')).toBeInTheDocument();
      });

      // Select the result
      const resultItem = screen.getByTestId('search-result-select-prod-1');
      fireEvent.mouseDown(resultItem);

      await waitFor(() => {
        expect(mockGetSkuDetails).toHaveBeenCalledWith(
          expect.objectContaining({
            body: expect.objectContaining({
              data: expect.objectContaining({
                channel: 'assisted',
                sorId: 'select-prod-1',
                productType: 'device',
                intentType: 'EUP',
              }),
            }),
            spinner: true,
          }),
          false,
        );
      });
    });

    it('should update search input with selected product name after selection', async () => {
      const typeAheadData = {
        data: {
          productList: [{ productId: 'name-prod-1', productDisplayName: 'Product Name To Show' }],
        },
      };

      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: true, isError: false, data: typeAheadData }]);

      renderComponent();

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      const searchInput = screen.getByTestId('device-search-input');
      fireEvent.change(searchInput, { target: { value: 'Product' } });

      await waitFor(() => {
        expect(screen.getByTestId('search-result-name-prod-1')).toBeInTheDocument();
      });

      fireEvent.mouseDown(screen.getByTestId('search-result-name-prod-1'));

      await waitFor(() => {
        expect(searchInput.value).toBe('Product Name To Show');
      });
    });

    it('should filter devices by selectedSearchProductId when selection made', async () => {
      const typeAheadData = {
        data: {
          productList: [{ productId: 'iphone-1', productDisplayName: 'iPhone 17 Pro' }],
        },
      };

      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: true, isError: false, data: typeAheadData }]);

      renderComponent();

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      const searchInput = screen.getByTestId('device-search-input');
      fireEvent.change(searchInput, { target: { value: 'iPhone 17' } });

      await waitFor(() => {
        expect(screen.getByTestId('search-result-iphone-1')).toBeInTheDocument();
      });

      fireEvent.mouseDown(screen.getByTestId('search-result-iphone-1'));
      await waitFor(() => {
        const deviceCards = screen.getAllByTestId(/^device-card-/);
        expect(deviceCards.length).toBe(1);
        expect(screen.getByTestId('device-card-iphone-1')).toBeInTheDocument();
      });
    });

    it('should filter dropdown results by current search input', async () => {
      const typeAheadData = {
        data: {
          productList: [
            { productId: 'prod-1', productDisplayName: 'iPhone 15 Pro' },
            { productId: 'prod-2', productDisplayName: 'iPhone 15' },
            { productId: 'prod-3', productDisplayName: 'Galaxy S24' },
          ],
        },
      };

      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: true, isError: false, data: typeAheadData }]);

      renderComponent();

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      const searchInput = screen.getByTestId('device-search-input');
      fireEvent.change(searchInput, { target: { value: 'iPhone 15' } });

      await waitFor(() => {
        // Should show iPhone results but not Galaxy
        expect(screen.getByTestId('search-result-prod-1')).toBeInTheDocument();
        expect(screen.getByTestId('search-result-prod-2')).toBeInTheDocument();
        expect(screen.queryByTestId('search-result-prod-3')).not.toBeInTheDocument();
      });
    });

    it('should limit dropdown results to 10 items', async () => {
      const manyProducts = Array.from({ length: 15 }, (_, i) => ({
        productId: `prod-${i}`,
        productDisplayName: `Test Product ${i}`,
      }));

      const typeAheadData = {
        data: {
          productList: manyProducts,
        },
      };

      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: true, isError: false, data: typeAheadData }]);

      renderComponent();

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      const searchInput = screen.getByTestId('device-search-input');
      fireEvent.change(searchInput, { target: { value: 'Test' } });

      await waitFor(() => {
        const results = screen.getAllByTestId(/^search-result-prod-/);
        expect(results.length).toBeLessThanOrEqual(10);
      });
    });
  });

  // ======================================================
  // SKU DETAILS PROCESSING TESTS
  // ======================================================
  describe('SKU Details Processing - Complete Coverage', () => {
    let mockGetSkuDetails;

    beforeEach(() => {
      mockTriggerProductList = jest.fn();
      const mockGetTypeAhead = jest.fn();
      mockGetSkuDetails = jest.fn();

      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { isSuccess: false, isError: false, data: null }]);

      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: false, isError: false, data: null }]);

      jest
        .spyOn(APIServiceHooks, 'useLazyGetSkuDetailsQuery')
        .mockReturnValue([mockGetSkuDetails, { isSuccess: false, isError: false, data: null }]);
    });

    it('should process SKU details and update devices when successful', async () => {
      const skuDetailsData = {
        data: {
          deviceSku: {
            parentProducts: [
              {
                productId: 'sku-device-1',
                productDisplayName: 'SKU Device 1',
                manufacturerName: 'Apple',
                childSkus: [
                  {
                    color: { description: 'Space Gray' },
                    memoryCapacityDesc: '256GB',
                    devicePricing: { dppPrice: '$35/mo' },
                    imageUrlMap: { defaultImage: 'https://example.com/sku1.jpg' },
                  },
                ],
              },
            ],
          },
        },
      };

      jest
        .spyOn(APIServiceHooks, 'useLazyGetSkuDetailsQuery')
        .mockReturnValue([mockGetSkuDetails, { isSuccess: true, isError: false, data: skuDetailsData }]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId('device-card-sku-device-1')).toBeInTheDocument();
        expect(screen.getByTestId('device-name-sku-device-1')).toHaveTextContent('SKU Device 1');
      });
    });

    it('should use activeBrand when manufacturerName is missing', async () => {
      const skuDetailsData = {
        data: {
          deviceSku: {
            parentProducts: [
              {
                productId: 'no-manufacturer-1',
                productDisplayName: 'No Manufacturer Device',
                // manufacturerName is missing
                childSkus: [
                  {
                    color: { description: 'Black' },
                    memoryCapacityDesc: '128GB',
                    devicePricing: { dppPrice: '$25/mo' },
                  },
                ],
              },
            ],
          },
        },
      };

      jest
        .spyOn(APIServiceHooks, 'useLazyGetSkuDetailsQuery')
        .mockReturnValue([mockGetSkuDetails, { isSuccess: true, isError: false, data: skuDetailsData }]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId('device-card-no-manufacturer-1')).toBeInTheDocument();
      });
    });

    it('should use N/A fallback when childSkus color is missing', async () => {
      const skuDetailsData = {
        data: {
          deviceSku: {
            parentProducts: [
              {
                productId: 'no-color-sku-1',
                productDisplayName: 'No Color SKU Device',
                manufacturerName: 'Apple',
                childSkus: [
                  {
                    // color is missing
                    memoryCapacityDesc: '256GB',
                    devicePricing: { dppPrice: '$30/mo' },
                  },
                ],
              },
            ],
          },
        },
      };

      jest
        .spyOn(APIServiceHooks, 'useLazyGetSkuDetailsQuery')
        .mockReturnValue([mockGetSkuDetails, { isSuccess: true, isError: false, data: skuDetailsData }]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId('device-specs-no-color-sku-1')).toHaveTextContent('N/A');
      });
    });

    it('should use N/A fallback when childSkus memoryCapacityDesc is missing', async () => {
      const skuDetailsData = {
        data: {
          deviceSku: {
            parentProducts: [
              {
                productId: 'no-memory-sku-1',
                productDisplayName: 'No Memory SKU Device',
                manufacturerName: 'Apple',
                childSkus: [
                  {
                    color: { description: 'Silver' },
                    // memoryCapacityDesc is missing
                    devicePricing: { dppPrice: '$28/mo' },
                  },
                ],
              },
            ],
          },
        },
      };

      jest
        .spyOn(APIServiceHooks, 'useLazyGetSkuDetailsQuery')
        .mockReturnValue([mockGetSkuDetails, { isSuccess: true, isError: false, data: skuDetailsData }]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId('device-specs-no-memory-sku-1')).toHaveTextContent('N/A');
      });
    });

    it('should use N/A fallback when devicePricing is missing', async () => {
      const skuDetailsData = {
        data: {
          deviceSku: {
            parentProducts: [
              {
                productId: 'no-pricing-sku-1',
                productDisplayName: 'No Pricing SKU Device',
                manufacturerName: 'Apple',
                childSkus: [
                  {
                    color: { description: 'Gold' },
                    memoryCapacityDesc: '512GB',
                    // devicePricing is missing
                  },
                ],
              },
            ],
          },
        },
      };

      jest
        .spyOn(APIServiceHooks, 'useLazyGetSkuDetailsQuery')
        .mockReturnValue([mockGetSkuDetails, { isSuccess: true, isError: false, data: skuDetailsData }]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId('device-price-no-pricing-sku-1')).toHaveTextContent('N/A');
      });
    });

    it('should use null image when imageUrlMap is missing', async () => {
      const skuDetailsData = {
        data: {
          deviceSku: {
            parentProducts: [
              {
                productId: 'no-image-sku-1',
                productDisplayName: 'No Image SKU Device',
                manufacturerName: 'Apple',
                childSkus: [
                  {
                    color: { description: 'Blue' },
                    memoryCapacityDesc: '256GB',
                    devicePricing: { dppPrice: '$32/mo' },
                    // imageUrlMap is missing
                  },
                ],
              },
            ],
          },
        },
      };

      jest
        .spyOn(APIServiceHooks, 'useLazyGetSkuDetailsQuery')
        .mockReturnValue([mockGetSkuDetails, { isSuccess: true, isError: false, data: skuDetailsData }]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId('device-icon-no-image-sku-1')).toBeInTheDocument();
      });
    });

    it('should not update devices when SKU details has empty parentProducts', async () => {
      const skuDetailsData = {
        data: {
          deviceSku: {
            parentProducts: [],
          },
        },
      };

      jest
        .spyOn(APIServiceHooks, 'useLazyGetSkuDetailsQuery')
        .mockReturnValue([mockGetSkuDetails, { isSuccess: true, isError: false, data: skuDetailsData }]);

      renderComponent();
      await waitFor(() => {
        const deviceCards = screen.queryAllByTestId(/^device-card-/);
        expect(deviceCards.length).toBe(0);
      });
    });

    it('should not update devices when SKU details data is null', async () => {
      jest
        .spyOn(APIServiceHooks, 'useLazyGetSkuDetailsQuery')
        .mockReturnValue([mockGetSkuDetails, { isSuccess: true, isError: false, data: null }]);

      renderComponent();
      await waitFor(() => {
        const deviceCards = screen.queryAllByTestId(/^device-card-/);
        expect(deviceCards.length).toBe(0);
      });
    });

    it('should handle SKU details with empty childSkus array', async () => {
      const skuDetailsData = {
        data: {
          deviceSku: {
            parentProducts: [
              {
                productId: 'empty-child-sku-1',
                productDisplayName: 'Empty Child SKU Device',
                manufacturerName: 'Apple',
                childSkus: [],
              },
            ],
          },
        },
      };

      jest
        .spyOn(APIServiceHooks, 'useLazyGetSkuDetailsQuery')
        .mockReturnValue([mockGetSkuDetails, { isSuccess: true, isError: false, data: skuDetailsData }]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId('device-card-empty-child-sku-1')).toBeInTheDocument();
        expect(screen.getByTestId('device-specs-empty-child-sku-1')).toHaveTextContent('N/A, N/A');
      });
    });

    it('should handle SKU details with undefined childSkus', async () => {
      const skuDetailsData = {
        data: {
          deviceSku: {
            parentProducts: [
              {
                productId: 'undef-child-sku-1',
                productDisplayName: 'Undefined Child SKU Device',
                manufacturerName: 'Apple',
                // childSkus is undefined
              },
            ],
          },
        },
      };

      jest
        .spyOn(APIServiceHooks, 'useLazyGetSkuDetailsQuery')
        .mockReturnValue([mockGetSkuDetails, { isSuccess: true, isError: false, data: skuDetailsData }]);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId('device-card-undef-child-sku-1')).toBeInTheDocument();
      });
    });
  });

  describe('Search Text Filtering - filteredDevices Branch Coverage', () => {
    beforeEach(() => {
      mockTriggerProductList = jest.fn();
      const mockGetTypeAhead = jest.fn();
      const mockGetSkuDetails = jest.fn();

      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { isSuccess: false, isError: false, data: null }]);

      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: false, isError: false, data: null }]);

      jest
        .spyOn(APIServiceHooks, 'useLazyGetSkuDetailsQuery')
        .mockReturnValue([mockGetSkuDetails, { isSuccess: false, isError: false, data: null }]);
    });

    it('should filter devices by search text when no selection made', async () => {
      // Provide product data for this test
      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { isSuccess: true, isError: false, data: mockProductData }]);

      renderComponent();

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      const searchInput = screen.getByTestId('device-search-input');
      fireEvent.change(searchInput, { target: { value: 'iPhone 15' } });

      await waitFor(() => {
        // Should only show devices matching "iPhone 15"
        const deviceCards = screen.getAllByTestId(/^device-card-/);
        deviceCards.forEach((card) => {
          const deviceId = card.getAttribute('data-testid').replace('device-card-', '');
          const nameEl = screen.getByTestId(`device-name-${deviceId}`);
          expect(nameEl.textContent.toLowerCase()).toContain('iphone 15');
        });
      });
    });

    it('should show no devices when search text matches nothing', async () => {
      renderComponent();

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      const searchInput = screen.getByTestId('device-search-input');
      fireEvent.change(searchInput, { target: { value: 'NonExistentDevice12345' } });

      await waitFor(() => {
        const deviceCards = screen.queryAllByTestId(/^device-card-/);
        expect(deviceCards.length).toBe(0);
      });
    });

    it('should be case-insensitive when filtering by search text', async () => {
      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { isSuccess: true, isError: false, data: mockProductData }]);

      renderComponent();

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      const searchInput = screen.getByTestId('device-search-input');
      fireEvent.change(searchInput, { target: { value: 'IPHONE' } });

      await waitFor(() => {
        const deviceCards = screen.getAllByTestId(/^device-card-/);
        expect(deviceCards.length).toBeGreaterThan(0);
      });
    });

    it('should trim search text before filtering', async () => {
      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { isSuccess: true, isError: false, data: mockProductData }]);

      renderComponent();

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      const searchInput = screen.getByTestId('device-search-input');
      fireEvent.change(searchInput, { target: { value: '   iPhone   ' } });

      await waitFor(() => {
        const deviceCards = screen.getAllByTestId(/^device-card-/);
        expect(deviceCards.length).toBeGreaterThan(0);
      });
    });

    it('should handle devices with null/undefined names gracefully', async () => {
      jest.spyOn(APIServiceHooks, 'useLazyGetProductListQuery').mockReturnValue([
        mockTriggerProductList,
        {
          isSuccess: true,
          isError: false,
          data: {
            data: {
              gridWall: {
                productList: [
                  {
                    defaultSKU: 'null-name-device',
                    productId: 'null-name-1',
                    productDisplayName: null,
                    name: null,
                    brandName: 'Apple',
                    defaultSKUObj: {
                      color: { displayName: 'Black' },
                      capacity: '128GB',
                    },
                  },
                ],
              },
            },
          },
        },
      ]);

      renderComponent();

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      const searchInput = screen.getByTestId('device-search-input');
      fireEvent.change(searchInput, { target: { value: 'test' } });

      await waitFor(() => {
        expect(screen.getByTestId('gridwall-container')).toBeInTheDocument();
      });
    });

    it('should return full devices when selectedSearchProductId set but no matching device exists', async () => {
      // Setup typeAhead to return a product id that does NOT match any device id
      const typeAheadData = {
        data: {
          productList: [{ productId: 'non-existent-id', productDisplayName: 'No Match Device' }],
        },
      };

      const mockGetTypeAhead = jest.fn();
      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: true, isError: false, data: typeAheadData }]);

      // Provide product data so filteredDevices can fall back to full list
      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { isSuccess: true, isError: false, data: mockProductData }]);

      renderComponent();

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      const searchInput = screen.getByTestId('device-search-input');
      fireEvent.change(searchInput, { target: { value: 'No Match' } });

      await waitFor(() => {
        // Select the non-matching result which will set selectedSearchProductId to 'non-existent-id'
        expect(screen.getByTestId('search-result-non-existent-id')).toBeInTheDocument();
      });

      fireEvent.mouseDown(screen.getByTestId('search-result-non-existent-id'));

      await waitFor(() => {
        // Because there is no device with id 'non-existent-id', filteredDevices should fall back and return the full devices list
        const deviceCards = screen.getAllByTestId(/^device-card-/);
        expect(deviceCards.length).toBeGreaterThan(0);
      });
    });

    it('should handle device.brand fallback when brand is undefined (covering (device.brand || "").toLowerCase())', async () => {
      // Mock the useProductApi hook to return a device without the brand property
      const useProductApiModuleLocal = require('./useProductApi');
      const mockedDevices = [
        {
          id: 'no-brand-1',
          name: 'NoBrand Phone',
          /* brand intentionally omitted */ color: '',
          storage: '',
          price: '$0/mo',
          term: 'for 36 mos',
          image: null,
        },
      ];

      jest.spyOn(useProductApiModuleLocal, 'default').mockReturnValue({
        devices: mockedDevices,
        activeBrand: 'Apple',
        setActiveBrand: jest.fn(),
        typeAheadResults: [],
        triggerTypeAhead: jest.fn(),
        getSkuDetailsBySorId: jest.fn(),
        clearTypeAhead: jest.fn(),
        getAllDevices: () => mockedDevices,
        lastTypeAheadHadProductList: false,
      });

      // Render the component which will now use the mocked hook
      render(
        <Router>
          <AllDevicesGridwall {...mockHandlers} />
        </Router>,
      );

      // Open search and enter a query that does NOT match the device name
      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);
      const searchInput = screen.getByTestId('device-search-input');
      fireEvent.change(searchInput, { target: { value: 'NonMatchingQuery' } });

      await waitFor(() => {
        // Because neither name nor brand (brand missing uses fallback '') match, the component should return the devices fallback (full list)
        const deviceCards = screen.getAllByTestId(/^device-card-/);
        expect(deviceCards.length).toBeGreaterThan(0);
      });

      // Restore the original hook implementation for subsequent tests
      jest.restoreAllMocks();
    });

    it('should clear selectedSearchProductId when typing after a typeAhead selection', async () => {
      // This test selects a real matching product, then types into the search input and expects the selection to be cleared (so filtered devices update)
      const typeAheadData = {
        data: {
          productList: [{ productId: 'iphone-1', productDisplayName: 'iPhone 17 Pro' }],
        },
      };

      const mockGetTypeAhead = jest.fn();
      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: true, isError: false, data: typeAheadData }]);

      // Provide product data for this flow
      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { isSuccess: true, isError: false, data: mockProductData }]);

      renderComponent();

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      const searchInput = screen.getByTestId('device-search-input');
      fireEvent.change(searchInput, { target: { value: 'iPhone 17' } });

      await waitFor(() => {
        expect(screen.getByTestId('search-result-iphone-1')).toBeInTheDocument();
      });

      // Select the result - now selectedSearchProductId is set and filteredDevices shows only one card
      fireEvent.mouseDown(screen.getByTestId('search-result-iphone-1'));

      await waitFor(() => {
        const deviceCards = screen.getAllByTestId(/^device-card-/);
        expect(deviceCards.length).toBe(1);
        expect(screen.getByTestId('device-card-iphone-1')).toBeInTheDocument();
      });

      // Now type into the input which should clear selectedSearchProductId and re-run filtering
      fireEvent.change(searchInput, { target: { value: 'Galaxy' } });

      await waitFor(() => {
        // After typing, the selection should be cleared and the filtered results should reflect the new query (may show multiple cards)
        const deviceCardsAfter = screen.getAllByTestId(/^device-card-/);
        expect(deviceCardsAfter.length).toBeGreaterThan(0);
      });
    });
  });
  describe('Debounce Cleanup - useEffect Cleanup', () => {
    beforeEach(() => {
      mockTriggerProductList = jest.fn();
      const mockGetTypeAhead = jest.fn();
      const mockGetSkuDetails = jest.fn();

      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { isSuccess: false, isError: false, data: null }]);

      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: false, isError: false, data: null }]);

      jest
        .spyOn(APIServiceHooks, 'useLazyGetSkuDetailsQuery')
        .mockReturnValue([mockGetSkuDetails, { isSuccess: false, isError: false, data: null }]);
    });

    it('should cleanup debounce on unmount', () => {
      const { unmount } = renderComponent();
      expect(() => unmount()).not.toThrow();
    });

    it('should cancel pending debounced calls when input cleared', async () => {
      jest.useFakeTimers();

      renderComponent();

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      const searchInput = screen.getByTestId('device-search-input');
      fireEvent.change(searchInput, { target: { value: 'iPhone' } });
      fireEvent.change(searchInput, { target: { value: '' } });
      jest.advanceTimersByTime(600);
      jest.useRealTimers();
    });
  });
  describe('Search Function Edge Cases', () => {
    let mockGetTypeAhead;

    beforeEach(() => {
      mockTriggerProductList = jest.fn();
      mockGetTypeAhead = jest.fn();
      const mockGetSkuDetails = jest.fn();

      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { isSuccess: false, isError: false, data: null }]);

      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: false, isError: false, data: null }]);

      jest
        .spyOn(APIServiceHooks, 'useLazyGetSkuDetailsQuery')
        .mockReturnValue([mockGetSkuDetails, { isSuccess: false, isError: false, data: null }]);
    });

    it('should not call API when search string is only whitespace', async () => {
      jest.useFakeTimers();

      renderComponent();

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      const searchInput = screen.getByTestId('device-search-input');
      fireEvent.change(searchInput, { target: { value: '     ' } });

      jest.advanceTimersByTime(600);

      expect(mockGetTypeAhead).not.toHaveBeenCalled();

      jest.useRealTimers();
    });

    it('should not call API when search string is null-ish after trim', async () => {
      jest.useFakeTimers();

      renderComponent();

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      const searchInput = screen.getByTestId('device-search-input');
      fireEvent.change(searchInput, { target: { value: '' } });

      jest.advanceTimersByTime(600);

      expect(mockGetTypeAhead).not.toHaveBeenCalled();

      jest.useRealTimers();
    });

    it('should call getTypeAheadList when debounced search fires with valid input', async () => {
      renderComponent();

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      const searchInput = screen.getByTestId('device-search-input');
      fireEvent.change(searchInput, { target: { value: 'Galaxy S24' } });

      // Wait for the real 500ms debounce delay to fire
      await waitFor(
        () => {
          expect(mockGetTypeAhead).toHaveBeenCalledWith(
            expect.objectContaining({
              body: expect.objectContaining({
                searchText: 'Galaxy S24',
                productType: 'device',
              }),
              customHeaders: { flowName: 'AIGuidedShopping' },
            }),
            false,
          );
        },
        { timeout: 2000 },
      );
    });

    it('should clear typeAheadResults when input becomes empty', async () => {
      // Setup with some initial results
      const typeAheadData = {
        data: {
          productList: [{ productId: 'prod-1', productDisplayName: 'iPhone 15' }],
        },
      };

      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: true, isError: false, data: typeAheadData }]);

      renderComponent();

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      const searchInput = screen.getByTestId('device-search-input');
      fireEvent.change(searchInput, { target: { value: 'iPhone' } });
      await waitFor(() => {
        expect(screen.getByTestId('search-dropdown')).toBeInTheDocument();
      });
      fireEvent.change(searchInput, { target: { value: '' } });
      await waitFor(() => {
        expect(screen.queryByTestId('search-dropdown')).not.toBeInTheDocument();
      });
    });
  });

  describe('Dropdown Filter Function - Line 998 Coverage', () => {
    let mockGetTypeAhead;

    beforeEach(() => {
      mockTriggerProductList = jest.fn();
      mockGetTypeAhead = jest.fn();
      const mockGetSkuDetails = jest.fn();

      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { isSuccess: false, isError: false, data: null }]);

      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: false, isError: false, data: null }]);

      jest
        .spyOn(APIServiceHooks, 'useLazyGetSkuDetailsQuery')
        .mockReturnValue([mockGetSkuDetails, { isSuccess: false, isError: false, data: null }]);
    });

    it('should filter dropdown results using productDisplayName', async () => {
      const typeAheadData = {
        data: {
          productList: [
            { productId: 'prod-1', productDisplayName: 'iPhone 15 Pro Max' },
            { productId: 'prod-2', productDisplayName: 'iPhone 15 Pro' },
            { productId: 'prod-3', productDisplayName: 'Galaxy S24' },
          ],
        },
      };
      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: true, isError: false, data: typeAheadData }]);
      renderComponent();
      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);
      const searchInput = screen.getByTestId('device-search-input');
      fireEvent.change(searchInput, { target: { value: 'Pro' } });
      await waitFor(() => {
        expect(screen.getByTestId('search-result-prod-1')).toBeInTheDocument();
        expect(screen.getByTestId('search-result-prod-2')).toBeInTheDocument();
        expect(screen.queryByTestId('search-result-prod-3')).not.toBeInTheDocument();
      });
    });

    it('should handle null productDisplayName in filter (fallback to empty string)', async () => {
      const typeAheadData = {
        data: {
          productList: [
            { productId: 'null-name-1', productDisplayName: null },
            { productId: 'valid-1', productDisplayName: 'Valid Product' },
          ],
        },
      };

      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: true, isError: false, data: typeAheadData }]);

      renderComponent();
      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);
      const searchInput = screen.getByTestId('device-search-input');
      fireEvent.change(searchInput, { target: { value: 'Valid' } });

      await waitFor(() => {
        expect(screen.getByTestId('search-result-valid-1')).toBeInTheDocument();
        expect(screen.queryByTestId('search-result-null-name-1')).not.toBeInTheDocument();
      });
    });

    it('should handle undefined productDisplayName in filter (fallback to empty string)', async () => {
      const typeAheadData = {
        data: {
          productList: [
            { productId: 'undef-name-1' }, // productDisplayName is undefined
            { productId: 'valid-2', productDisplayName: 'Another Valid Product' },
          ],
        },
      };
      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: true, isError: false, data: typeAheadData }]);
      renderComponent();
      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);
      const searchInput = screen.getByTestId('device-search-input');
      fireEvent.change(searchInput, { target: { value: 'Another' } });
      await waitFor(() => {
        expect(screen.getByTestId('search-result-valid-2')).toBeInTheDocument();
        expect(screen.queryByTestId('search-result-undef-name-1')).not.toBeInTheDocument();
      });
    });

    it('should be case-insensitive when filtering dropdown results', async () => {
      const typeAheadData = {
        data: {
          productList: [
            { productId: 'case-1', productDisplayName: 'UPPERCASE Device' },
            { productId: 'case-2', productDisplayName: 'lowercase device' },
            { productId: 'case-3', productDisplayName: 'MixedCase Device' },
          ],
        },
      };

      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: true, isError: false, data: typeAheadData }]);

      renderComponent();

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      const searchInput = screen.getByTestId('device-search-input');
      // Search with mixed case - should match all
      fireEvent.change(searchInput, { target: { value: 'DEVICE' } });

      await waitFor(() => {
        expect(screen.getByTestId('search-result-case-1')).toBeInTheDocument();
        expect(screen.getByTestId('search-result-case-2')).toBeInTheDocument();
        expect(screen.getByTestId('search-result-case-3')).toBeInTheDocument();
      });
    });
  });

  // ======================================================
  // SEARCH HANDLERSEARCHCLICK TOGGLE COVERAGE
  // ======================================================
  describe('handleSearchClick Toggle - Complete Coverage', () => {
    beforeEach(() => {
      mockTriggerProductList = jest.fn();
      const mockGetTypeAhead = jest.fn();
      const mockGetSkuDetails = jest.fn();

      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { isSuccess: false, isError: false, data: null }]);

      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: false, isError: false, data: null }]);

      jest
        .spyOn(APIServiceHooks, 'useLazyGetSkuDetailsQuery')
        .mockReturnValue([mockGetSkuDetails, { isSuccess: false, isError: false, data: null }]);
    });

    it('should focus search input after showing it', async () => {
      jest.useFakeTimers();

      renderComponent();

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);
      jest.advanceTimersByTime(150);
      const searchInput = screen.getByTestId('device-search-input');
      expect(searchInput).toBeInTheDocument();
      jest.useRealTimers();
    });

    it('should not focus input when hiding search', async () => {
      jest.useFakeTimers();
      renderComponent();
      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);
      jest.advanceTimersByTime(150);
      fireEvent.click(searchButton);
      jest.advanceTimersByTime(150);
      expect(screen.getByTestId('device-search-input')).toBeInTheDocument();
      jest.useRealTimers();
    });
  });

  // ======================================================
  // EDGE CASES FOR 100% COVERAGE
  // ======================================================
  describe('Edge Cases for 100% Branch Coverage', () => {
    beforeEach(() => {
      mockTriggerProductList = jest.fn();
      const mockGetTypeAhead = jest.fn();
      const mockGetSkuDetails = jest.fn();

      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { isSuccess: false, isError: false, data: null }]);

      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: false, isError: false, data: null }]);

      jest
        .spyOn(APIServiceHooks, 'useLazyGetSkuDetailsQuery')
        .mockReturnValue([mockGetSkuDetails, { isSuccess: false, isError: false, data: null }]);
    });

    it('should handle empty search input in triggerTypeAhead via Enter key', async () => {
      // Coverage for line 107 in useProductApi.js: if (!trimmed) return;
      const mockGetTypeAhead = jest.fn();
      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: false, isError: false, data: null }]);

      renderComponent();

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      const searchInput = screen.getByTestId('device-search-input');

      // Test with empty string + Enter key (should not call API)
      fireEvent.change(searchInput, { target: { value: '' } });
      fireEvent.keyDown(searchInput, { keyCode: 13 });

      // API should not be called with empty string
      expect(mockGetTypeAhead).not.toHaveBeenCalled();

      // Test with whitespace only + Enter key (should not call API)
      fireEvent.change(searchInput, { target: { value: '   ' } });
      fireEvent.keyDown(searchInput, { keyCode: 13 });

      // API should still not be called
      expect(mockGetTypeAhead).not.toHaveBeenCalled();
    });

    it('should handle configure button when no device is selected', () => {
      // Coverage for DeviceGridWall.js handleConfigure with no selectedDevice
      renderComponent();

      const configureButton = screen.getByTestId('configure-button');

      // Button should be disabled when no device is selected
      expect(configureButton).toBeDisabled();

      // Click should not trigger callback
      fireEvent.click(configureButton);
      expect(mockHandlers.onConfigureDevice).not.toHaveBeenCalled();
    });

    it('should test productDisplayNameMatches helper with edge cases', () => {
      // Test with null/undefined displayName
      expect(productDisplayNameMatches(null, 'test')).toBe(false);
      expect(productDisplayNameMatches(undefined, 'test')).toBe(false);
      expect(productDisplayNameMatches('', 'test')).toBe(false);

      // Test with whitespace in search
      expect(productDisplayNameMatches('iPhone 15 Pro', '  iPhone  ')).toBe(true);

      // Test case insensitivity
      expect(productDisplayNameMatches('iPhone 15 Pro', 'IPHONE')).toBe(true);
      expect(productDisplayNameMatches('iPhone 15 Pro', 'iphone')).toBe(true);
    });

    it('should test performSearch helper with empty string', () => {
      // Coverage for performSearch function
      const mockGetTypeAhead = jest.fn();

      // Test with empty string
      performSearch(mockGetTypeAhead, '');
      expect(mockGetTypeAhead).not.toHaveBeenCalled();

      // Test with whitespace
      performSearch(mockGetTypeAhead, '   ');
      expect(mockGetTypeAhead).not.toHaveBeenCalled();

      // Test with null
      performSearch(mockGetTypeAhead, null);
      expect(mockGetTypeAhead).not.toHaveBeenCalled();

      // Test with undefined
      performSearch(mockGetTypeAhead, undefined);
      expect(mockGetTypeAhead).not.toHaveBeenCalled();

      // Test with valid string
      performSearch(mockGetTypeAhead, 'iPhone');
      expect(mockGetTypeAhead).toHaveBeenCalledWith(
        {
          body: {
            searchText: 'iPhone',
            productType: 'device',
          },
          customHeaders: { flowName: 'AIGuidedShopping' },
        },
        false,
      );
    });
  });

  // ======================================================
  // USEPRODUCTAPI HOOK DIRECT TESTS
  // ======================================================
  describe('useProductApi Hook - Direct Tests', () => {
    beforeEach(() => {
      mockTriggerProductList = jest.fn();
      const mockGetTypeAhead = jest.fn();
      const mockGetSkuDetails = jest.fn();

      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { isSuccess: false, isError: false, data: null }]);

      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: false, isError: false, data: null }]);

      jest
        .spyOn(APIServiceHooks, 'useLazyGetSkuDetailsQuery')
        .mockReturnValue([mockGetSkuDetails, { isSuccess: false, isError: false, data: null }]);
    });

    it('should use default initialBrand parameter when not provided', () => {
      // Coverage for line 18 in useProductApi.js: initialBrand = 'Apple'
      const { result } = renderHook(() => useProductApi());

      // Default brand should be 'Apple'
      expect(result.current.activeBrand).toBe('Apple');

      // Should have triggered product list with Apple
      expect(mockTriggerProductList).toHaveBeenCalled();
    });

    it('should use provided initialBrand parameter', () => {
      const { result } = renderHook(() => useProductApi('Samsung'));

      // Brand should be the provided value
      expect(result.current.activeBrand).toBe('Samsung');
    });

    it('should handle triggerTypeAhead with empty/whitespace string', () => {
      // Coverage for line 107 in useProductApi.js: if (!trimmed) return;
      const mockGetTypeAhead = jest.fn();
      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: false, isError: false, data: null }]);

      const { result } = renderHook(() => useProductApi());

      // Test with empty string
      result.current.triggerTypeAhead('');
      expect(mockGetTypeAhead).not.toHaveBeenCalled();

      // Test with whitespace
      result.current.triggerTypeAhead('   ');
      expect(mockGetTypeAhead).not.toHaveBeenCalled();

      // Test with null
      result.current.triggerTypeAhead(null);
      expect(mockGetTypeAhead).not.toHaveBeenCalled();

      // Test with undefined
      result.current.triggerTypeAhead(undefined);
      expect(mockGetTypeAhead).not.toHaveBeenCalled();

      // Test with valid string
      result.current.triggerTypeAhead('iPhone');
      expect(mockGetTypeAhead).toHaveBeenCalledWith(
        {
          body: {
            searchText: 'iPhone',
            productType: 'device',
          },
          customHeaders: { flowName: 'AIGuidedShopping' },
        },
        false,
      );
    });

    it('should map typeAheadResults entries that use id/displayName fallback', async () => {
      const mockGetTypeAhead = jest.fn();
      jest.spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery').mockReturnValue([
        mockGetTypeAhead,
        {
          isSuccess: true,
          isError: false,
          data: { data: { typeAheadResults: [{ id: 'ta-1', displayName: 'TA Display 1' }] } },
        },
      ]);

      const { result } = renderHook(() => useProductApi());

      await waitFor(() => {
        expect(result.current.typeAheadResults).toEqual([{ productId: 'ta-1', productDisplayName: 'TA Display 1' }]);
        expect(result.current.lastTypeAheadHadProductList).toBe(false);
      });
    });

    it('should produce empty string for missing displayName in typeAheadResults', async () => {
      const mockGetTypeAhead = jest.fn();
      jest.spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery').mockReturnValue([
        mockGetTypeAhead,
        {
          isSuccess: true,
          isError: false,
          data: { data: { typeAheadResults: [{ id: 'ta-2' }] } },
        },
      ]);

      const { result } = renderHook(() => useProductApi());

      await waitFor(() => {
        expect(result.current.typeAheadResults).toEqual([{ productId: 'ta-2', productDisplayName: '' }]);
      });
    });

    it('should fallback to empty strings when typeAheadResults items have no id/productId/displayName', async () => {
      const mockGetTypeAhead = jest.fn();
      jest.spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery').mockReturnValue([
        mockGetTypeAhead,
        {
          isSuccess: true,
          isError: false,
          data: { data: { typeAheadResults: [{}] } },
        },
      ]);

      const { result } = renderHook(() => useProductApi());

      await waitFor(() => {
        expect(result.current.typeAheadResults).toEqual([{ productId: '', productDisplayName: '' }]);
      });
    });

    it('should map productList entries to empty strings when productId/productDisplayName missing', async () => {
      const mockGetTypeAhead = jest.fn();
      jest.spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery').mockReturnValue([
        mockGetTypeAhead,
        {
          isSuccess: true,
          isError: false,
          data: { data: { productList: [{ productId: null, productDisplayName: null }] } },
        },
      ]);

      const { result } = renderHook(() => useProductApi());

      await waitFor(() => {
        expect(result.current.typeAheadResults).toEqual([{ productId: '', productDisplayName: '' }]);
        expect(result.current.lastTypeAheadHadProductList).toBe(true);
      });
    });

    it('should handle clearTypeAhead function', () => {
      const { result } = renderHook(() => useProductApi());

      // Initially empty
      expect(result.current.typeAheadResults).toEqual([]);

      // Clear should work even if already empty
      result.current.clearTypeAhead();
      expect(result.current.typeAheadResults).toEqual([]);
    });
  });

  // ======================================================
  // CLEANUP AND UNMOUNT TESTS FOR 100% FUNCTION COVERAGE
  // ======================================================
  describe('Component Cleanup and Unmount', () => {
    beforeEach(() => {
      mockTriggerProductList = jest.fn();
      const mockGetTypeAhead = jest.fn();
      const mockGetSkuDetails = jest.fn();

      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { isSuccess: false, isError: false, data: null }]);

      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: false, isError: false, data: null }]);

      jest
        .spyOn(APIServiceHooks, 'useLazyGetSkuDetailsQuery')
        .mockReturnValue([mockGetSkuDetails, { isSuccess: false, isError: false, data: null }]);
    });

    it('should cleanup debounced search on unmount', () => {
      const { unmount } = renderComponent();

      // Open search
      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      const searchInput = screen.getByTestId('device-search-input');
      fireEvent.change(searchInput, { target: { value: 'iPhone' } });

      // Unmount should trigger cleanup
      unmount();

      // Test passes if no errors thrown during cleanup
      expect(true).toBe(true);
    });

    it('should cancel debounced search when clearing search input', () => {
      renderComponent();

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      const searchInput = screen.getByTestId('device-search-input');

      // Type something to trigger delayed search
      fireEvent.change(searchInput, { target: { value: 'iPhone' } });

      // Clear the input immediately (should cancel debounced call)
      fireEvent.change(searchInput, { target: { value: '' } });

      // Verify input is cleared
      expect(searchInput.value).toBe('');
    });

    it('should handle configure button click without selected device', () => {
      renderComponent();

      const configureButton = screen.getByTestId('configure-button');

      // Button should be disabled
      expect(configureButton).toBeDisabled();

      // Try to click (should not call handler)
      fireEvent.click(configureButton);

      expect(mockHandlers.onConfigureDevice).not.toHaveBeenCalled();
    });

    it('should handle configure when onConfigureDevice is undefined - line 91 optional chaining', async () => {
      // Render without onConfigureDevice callback
      const handlers = {
        ...mockHandlers,
        onConfigureDevice: undefined,
      };

      // Ensure we have product data to select
      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { isSuccess: true, isError: false, data: mockProductData }]);

      render(
        <Router>
          <AllDevicesGridwall {...handlers} />
        </Router>,
      );

      // Wait for devices to render
      await waitFor(() => {
        const selectButton = screen.getByTestId('select-button-iphone-1');
        expect(selectButton).toBeInTheDocument();
      });

      // Select a device
      const selectButton = screen.getByTestId('select-button-iphone-1');
      fireEvent.click(selectButton);

      // Configure button should be enabled
      const configureButton = screen.getByTestId('configure-button');
      await waitFor(() => {
        expect(configureButton).not.toBeDisabled();
      });

      // Click configure - this should not throw because of optional chaining
      fireEvent.click(configureButton);

      // No error should occur
      expect(true).toBe(true);
    });

    // it('should handle configure button click with selected device', async () => {
    //   // Provide product data for selection
    //   jest.spyOn(APIServiceHooks, 'useLazyGetProductListQuery').mockReturnValue([
    //     mockTriggerProductList,
    //     { isSuccess: true, isError: false, data: mockProductData },
    //   ]);

    //   renderComponent();

    //   // Wait for devices to render (from API)
    //   await waitFor(() => {
    //     const selectButton = screen.getByTestId('select-button-iphone-1');
    //     expect(selectButton).toBeInTheDocument();
    //   });

    //   // Select a device by clicking the select button
    //   const selectButton = screen.getByTestId('select-button-iphone-1');
    //   fireEvent.click(selectButton);

    //   await waitFor(() => {
    //     expect(mockHandlers.onDeviceSelect).toHaveBeenCalledWith('iphone-1');
    //   });

    //   // Configure button should be enabled now
    //   const configureButton = screen.getByTestId('configure-button');
    //   expect(configureButton).not.toBeDisabled();

    //   // Click configure - this tests line 91
    //   fireEvent.click(configureButton);

    //   expect(mockHandlers.onConfigureDevice).toHaveBeenCalledWith('iphone-1');
    // });

    it('should render and call renderIcon function for back button', () => {
      renderComponent();

      const backButton = screen.getByTestId('back-button');
      expect(backButton).toBeInTheDocument();

      // The renderIcon should have been called by ButtonIcon component
      // Verify the icon is rendered inside - the mock calls renderIcon()
      // which renders the Icon component
      const icon = backButton.querySelector('[data-testid="icon-left-caret"]');
      expect(icon).toBeTruthy();
    });

    it('should handle debounce cancel when delayedSearch has cancel method', () => {
      renderComponent();

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      const searchInput = screen.getByTestId('device-search-input');

      // Type to trigger debounce - this covers line 117 (truthy path)
      fireEvent.change(searchInput, { target: { value: 'test' } });

      // Clear immediately to trigger cancel - this covers line 117 (else with cancel)
      fireEvent.change(searchInput, { target: { value: '' } });

      // Type again
      fireEvent.change(searchInput, { target: { value: 'another' } });

      // Clear again
      fireEvent.change(searchInput, { target: { value: '' } });

      expect(searchInput.value).toBe('');
    });

    it('should test search with non-empty value to cover line 117 truthy path', async () => {
      const mockGetTypeAhead = jest.fn();
      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: false, isError: false, data: null }]);

      renderComponent();

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      await waitFor(() => {
        const searchInput = screen.getByTestId('device-search-input');
        expect(searchInput).toBeInTheDocument();
      });

      const searchInput = screen.getByTestId('device-search-input');

      // Type a value with trimmed length > 0 - covers line 117 truthy branch
      fireEvent.change(searchInput, { target: { value: 'iPhone 15' } });

      expect(searchInput.value).toBe('iPhone 15');

      // The code path has been executed, wait for debounce to potentially trigger
      await new Promise((resolve) => {
        setTimeout(resolve, 600);
      });
    });

    it('should cleanup debounced search when component unmounts - covers line 105 truthy path', async () => {
      jest.useFakeTimers();
      const mockGetTypeAhead = jest.fn();
      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: false, isError: false, data: null }]);

      const { unmount } = renderComponent();

      // Open search and type to create a debounced search
      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      jest.advanceTimersByTime(150);

      const searchInput = screen.getByTestId('device-search-input');
      fireEvent.change(searchInput, { target: { value: 'iPhone' } });

      // Wait a bit for debounce to be set up
      await waitFor(() => {
        expect(searchInput.value).toBe('iPhone');
      });

      // Unmount should trigger cleanup function which calls delayedSearch.cancel() - line 105 truthy
      unmount();

      // Test passes if no errors thrown during cleanup
      expect(true).toBe(true);
      jest.useRealTimers();
    });

    it('should handle handleConfigure when device is selected - covers line 91 truthy path', async () => {
      const handlers = { ...mockHandlers };
      // Provide product data for selection
      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { isSuccess: true, isError: false, data: mockProductData }]);

      renderComponent(handlers);

      // Wait for devices to render (from API)
      await waitFor(() => {
        const selectButton = screen.getByTestId('select-button-iphone-1');
        expect(selectButton).toBeInTheDocument();
      });

      // Select a device
      const selectButton = screen.getByTestId('select-button-iphone-1');
      fireEvent.click(selectButton);

      // Wait for selection
      await waitFor(() => {
        expect(handlers.onDeviceSelect).toHaveBeenCalledWith('iphone-1');
      });

      // Configure button should be enabled
      const configureButton = screen.getByTestId('configure-button');
      expect(configureButton).not.toBeDisabled();

      // Click configure - this explicitly tests line 91: if (selectedDevice) onConfigureDevice?.(selectedDevice);
      fireEvent.click(configureButton);

      // Verify the callback was called with the selected device
      expect(handlers.onConfigureDevice).toHaveBeenCalledWith(
        expect.objectContaining({ productId: 'prod-1', defaultSku: 'iphone-1' }),
      );
    });

    it('should use selectedDevice as productId and empty string as defaultSku when device lacks productId/defaultSku - lines 94-95 fallback branches', async () => {
      useProductApiModule.default.mockImplementation(() => ({
        devices: [
          {
            id: 'fallback-device-id',
            name: 'Test Device',
            brand: 'Apple',
            color: 'Black',
            storage: '128GB',
            price: '$20/mo',
            term: 'for 36 mos',
            image: null,
          },
        ],
        activeBrand: 'Apple',
        setActiveBrand: jest.fn(),
        typeAheadResults: [],
        triggerTypeAhead: jest.fn(),
        getSkuDetailsBySorId: jest.fn(),
        clearTypeAhead: jest.fn(),
      }));

      const handlers = { ...mockHandlers };
      renderComponent(handlers);

      await waitFor(() => {
        const selectButton = screen.getByTestId('select-button-fallback-device-id');
        expect(selectButton).toBeInTheDocument();
      });

      fireEvent.click(screen.getByTestId('select-button-fallback-device-id'));

      await waitFor(() => {
        expect(handlers.onDeviceSelect).toHaveBeenCalledWith('fallback-device-id');
      });

      const configureButton = screen.getByTestId('configure-button');
      fireEvent.click(configureButton);

      expect(handlers.onConfigureDevice).toHaveBeenCalledWith({
        productId: 'fallback-device-id',
        defaultSku: '',
      });
    });

    it('should call delayedSearch when value has content - line 117 truthy', async () => {
      const mockGetTypeAhead = jest.fn();
      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: false, isError: false, data: null }]);

      renderComponent();

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      await waitFor(() => {
        const searchInput = screen.getByTestId('device-search-input');
        expect(searchInput).toBeInTheDocument();
      });

      const searchInput = screen.getByTestId('device-search-input');

      // This should trigger line 117: if (value && value.trim().length > 0) delayedSearch(value);
      fireEvent.change(searchInput, { target: { value: 'iPhone Pro' } });

      expect(searchInput.value).toBe('iPhone Pro');

      // Wait for debounce delay
      await new Promise((resolve) => {
        setTimeout(resolve, 600);
      });
    });

    it('should cancel delayedSearch and clear typeahead when value is empty - line 117 else path', () => {
      const mockGetTypeAhead = jest.fn();
      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: false, isError: false, data: null }]);

      renderComponent();

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      const searchInput = screen.getByTestId('device-search-input');

      // First type something
      fireEvent.change(searchInput, { target: { value: 'test' } });

      // Then clear it - this should trigger line 117 else: cancel and clearTypeAhead
      fireEvent.change(searchInput, { target: { value: '' } });

      expect(searchInput.value).toBe('');
    });
  });

  // ======================================================
  // DEBOUNCE CALLBACK COVERAGE (line 101)
  // Waits for the real debounce timer (500ms) to fire.
  // ======================================================
  describe('Debounce callback execution (line 101)', () => {
    let mockGetTypeAhead;

    beforeEach(() => {
      mockTriggerProductList = jest.fn();
      mockGetTypeAhead = jest.fn();
      const mockGetSkuDetails = jest.fn();

      jest
        .spyOn(APIServiceHooks, 'useLazyGetProductListQuery')
        .mockReturnValue([mockTriggerProductList, { isSuccess: false, isError: false, data: null }]);

      jest
        .spyOn(CommonAPIServiceHooks, 'useLazyGetTypeAheadQuery')
        .mockReturnValue([mockGetTypeAhead, { isSuccess: false, isError: false, data: null }]);

      jest
        .spyOn(APIServiceHooks, 'useLazyGetSkuDetailsQuery')
        .mockReturnValue([mockGetSkuDetails, { isSuccess: false, isError: false, data: null }]);
    });

    it('should execute the debounced callback after delay, calling triggerTypeAhead', async () => {
      renderComponent();

      const searchButton = screen.getByTestId('search-button');
      fireEvent.click(searchButton);

      const searchInput = screen.getByTestId('device-search-input');
      fireEvent.change(searchInput, { target: { value: 'Galaxy S24' } });

      // Wait for the real 500ms debounce to fire
      await waitFor(
        () => {
          expect(mockGetTypeAhead).toHaveBeenCalledWith(
            expect.objectContaining({
              body: expect.objectContaining({
                searchText: 'Galaxy S24',
                productType: 'device',
              }),
            }),
            false,
          );
        },
        { timeout: 2000 },
      );
    });
  });
});
