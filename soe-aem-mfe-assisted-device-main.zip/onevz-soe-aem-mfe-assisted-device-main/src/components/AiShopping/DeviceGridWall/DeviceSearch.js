import React from 'react';
import PropTypes from 'prop-types';
import { Input } from '@vds/inputs';
import { Icon } from '@vds/icons';
import { SearchInputWrapper, SearchIconWrapper, SearchDropdown, SearchResultItem, Body } from './DeviceGridWall.styles';

export default function DeviceSearch({
  show,
  value,
  onChange,
  onKeyDown,
  onClear,
  typeAheadResults,
  onTypeAheadSelect,
  productDisplayNameMatches,
}) {
  return (
    <SearchInputWrapper show={show} data-testid='search-input-wrapper'>
      <Input
        type='text'
        id='device-search-input'
        placeholder='Search device'
        value={value}
        onChange={onChange}
        onKeyDown={onKeyDown}
        required={false}
        error={false}
        errorText={undefined}
        aria-label='Search devices'
        data-testid='device-search-input'
      />
      {show && (
        <SearchIconWrapper onClick={onClear} style={{ cursor: 'pointer', pointerEvents: 'auto' }}>
          <Icon name='close' size={16} color='#000000' />
        </SearchIconWrapper>
      )}

      {typeAheadResults && typeAheadResults.length > 0 && value.trim() && (
        <SearchDropdown data-testid='search-dropdown'>
          {typeAheadResults
            .filter((result) => productDisplayNameMatches(result.productDisplayName, value))
            .slice(0, 10)
            .map((result) => (
              <SearchResultItem
                key={result.productId}
                onMouseDown={() => onTypeAheadSelect(result)}
                data-testid={`search-result-${result.productId}`}
              >
                <Body size='small' color='#000000' bold>
                  {result.productDisplayName}
                </Body>
              </SearchResultItem>
            ))}
        </SearchDropdown>
      )}
    </SearchInputWrapper>
  );
}

DeviceSearch.propTypes = {
  show: PropTypes.bool,
  value: PropTypes.string,
  onChange: PropTypes.func.isRequired,
  onKeyDown: PropTypes.func,
  onClear: PropTypes.func.isRequired,
  typeAheadResults: PropTypes.array,
  onTypeAheadSelect: PropTypes.func.isRequired,
  productDisplayNameMatches: PropTypes.func.isRequired,
};
