import React from 'react';
import PropTypes from 'prop-types';
import { Icon } from '@vds/icons';
import {
  DeviceCardStyled,
  DeviceInfoSection,
  DevicePriceRow,
  DeviceImageContainer,
  DeviceImage,
  SelectButton,
  SelectedOverlay,
  Body,
} from './DeviceGridWall.styles';

export default function DeviceCard({ device, selectedDevice, onSelect }) {
  return (
    <DeviceCardStyled data-testid={`device-card-${device.id}`}>
      <DeviceInfoSection data-testid={`device-info-${device.id}`}>
        <Body size='medium' color='#000000' bold data-testid={`device-name-${device.id}`}>
          {device.name}
        </Body>
        <DevicePriceRow data-testid={`device-price-row-${device.id}`}>
          <Body size='large' color='#000000' bold primitive='span' data-testid={`device-price-${device.id}`}>
            {device.price}
          </Body>
          <Body size='small' color='#000000' primitive='span' data-testid={`device-term-${device.id}`}>
            {device.term}
          </Body>
        </DevicePriceRow>
      </DeviceInfoSection>

      <DeviceImageContainer data-testid={`device-image-container-${device.id}`}>
        <DeviceImage data-testid={`device-image-${device.id}`}>
          {device.image ? (
            <img
              src={device.image}
              alt={device.name}
              data-testid={`device-img-${device.id}`}
              style={{ width: '100%', height: '100%', objectFit: 'contain' }}
            />
          ) : (
            <Icon name='device' size={120} color='#d8dada' data-testid={`device-icon-${device.id}`} />
          )}
        </DeviceImage>
      </DeviceImageContainer>

      <Body size='small' color='#6F7171' data-testid={`device-specs-${device.id}`}>
        {device.color}, {device.storage}
      </Body>

      {selectedDevice === device.id ? (
        <SelectedOverlay data-testid={`selected-overlay-${device.id}`} aria-hidden='true'>
          <svg viewBox='0 0 24 24' width='18' height='18' aria-hidden='true' focusable='false'>
            <polyline
              points='5 13 10 18 19 7'
              stroke='#ffffff'
              strokeWidth='2'
              fill='none'
              strokeLinecap='round'
              strokeLinejoin='round'
            />
          </svg>
        </SelectedOverlay>
      ) : (
        <SelectButton
          use='secondary'
          size='small'
          aria-label={`Select ${device.name}`}
          data-testid={`select-button-${device.id}`}
          onClick={() => onSelect(device.id)}
        >
          Select
        </SelectButton>
      )}
    </DeviceCardStyled>
  );
}

DeviceCard.propTypes = {
  device: PropTypes.object.isRequired,
  selectedDevice: PropTypes.string,
  onSelect: PropTypes.func.isRequired,
};
