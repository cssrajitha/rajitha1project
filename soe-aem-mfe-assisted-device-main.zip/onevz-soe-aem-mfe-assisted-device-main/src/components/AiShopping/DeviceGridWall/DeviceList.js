import React from 'react';
import PropTypes from 'prop-types';
import { DevicesContainer } from './DeviceGridWall.styles';
import DeviceCard from './DeviceCard';

export default function DeviceList({ devices, selectedDevice, onSelect }) {
  return (
    <DevicesContainer data-testid='devices-container'>
      {devices.map((device) => (
        <DeviceCard key={device.id} device={device} selectedDevice={selectedDevice} onSelect={onSelect} />
      ))}
    </DevicesContainer>
  );
}

DeviceList.propTypes = {
  devices: PropTypes.array.isRequired,
  selectedDevice: PropTypes.string,
  onSelect: PropTypes.func.isRequired,
};
