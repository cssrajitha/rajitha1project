import React, { useMemo, useState, useCallback, useEffect, useRef } from 'react';
import debounce from 'lodash/debounce';
import PropTypes from 'prop-types';
import { Button } from '@vds/buttons';
import { ButtonIcon } from '@vds/button-icons';
import { Icon } from '@vds/icons';
import DeviceGridHeader from './DeviceGridHeader';
import DeviceSearch from './DeviceSearch';
import DeviceList from './DeviceList';
import useProductApi from './useProductApi';
import {
  PageContainer,
  TopHeaderWrapper,
  TopHeader,
  BackButtonContainer,
  ContentWrapper,
  ContentCard,
  BottomActionsWrapper,
  BottomActions,
} from './DeviceGridWall.styles';

// Helper for test coverage
export function productDisplayNameMatches(displayName, searchText) {
  return (displayName || '').toLowerCase().includes(searchText.trim().toLowerCase());
}

// Helper exported for tests to cover (keeps old API)
export function performSearch(getTypeAheadListFn, searchStr) {
  const trimmed = searchStr?.trim();
  if (!trimmed) return;
  const productType = 'device';
  const params = {
    searchText: trimmed,
    productType,
  };
  getTypeAheadListFn({ body: params, customHeaders: { flowName: 'AIGuidedShopping' } }, false);
}

export default function AllDevicesGridwall({
  onDeviceSelect,
  onFilterChange,
  onSearchClick,
  onScanClick,
  onBack,
  onCancel,
  onConfigureDevice,
  processingMtn,
  brand,
}) {
  const brandFilters = ['Apple', 'Samsung', 'Google', 'Motorola'];
  const initialBrandToUse = brand || brandFilters[0];

  const {
    devices,
    activeBrand,
    setActiveBrand,
    typeAheadResults,
    triggerTypeAhead,
    getSkuDetailsBySorId,
    clearTypeAhead,
    getAllDevices,
    lastTypeAheadHadProductList,
  } = useProductApi(initialBrandToUse, processingMtn);

  const [selectedDevice, setSelectedDevice] = useState(null);
  const [showSearchInput, setShowSearchInput] = useState(false);
  const [searchInput, setSearchInput] = useState('');
  const [selectedSearchProductId, setSelectedSearchProductId] = useState(null);
  const [isSearchActive, setIsSearchActive] = useState(false);

  const filteredDevices = useMemo(() => {
    const q = (searchInput || '').trim().toLowerCase();

    if (selectedSearchProductId) {
      const matchedDevice = devices.find((device) => device.id === selectedSearchProductId);
      /* istanbul ignore else */
      if (matchedDevice) return [matchedDevice];
    }

    if (isSearchActive && q.length > 0) {
      // Filter devices that match the search query
      const filtered = devices.filter(
        (device) => (device.name || '').toLowerCase().includes(q) || (device.brand || '').toLowerCase().includes(q),
      );
      return filtered.length > 0 ? filtered : devices;
    }
    if (isSearchActive) {
      return getAllDevices();
    }

    return devices.filter((device) => device.brand === activeBrand);
  }, [devices, activeBrand, searchInput, selectedSearchProductId, isSearchActive, getAllDevices]);

  const handleSelectDevice = (deviceId) => {
    setSelectedDevice(deviceId);
    onDeviceSelect?.(deviceId);
  };

  const handleFilterClick = (selectedBrand) => {
    setActiveBrand(selectedBrand);
    setSelectedDevice(null);
    onFilterChange?.(selectedBrand);
  };

  const handleConfigure = () => {
    /* istanbul ignore else */
    if (selectedDevice) {
      const selectedDeviceObj = filteredDevices?.find((d) => d.id === selectedDevice);
      const productId = selectedDeviceObj?.productId ?? selectedDevice;
      const defaultSku = selectedDeviceObj?.defaultSku ?? '';
      onConfigureDevice?.({ productId, defaultSku });
    }
  };

  const handleSearchClick = () => {
    const newShowSearchInput = !showSearchInput;
    setShowSearchInput(newShowSearchInput);
    setIsSearchActive(newShowSearchInput);

    if (newShowSearchInput) {
      setTimeout(() => document.getElementById('device-search-input')?.focus(), 100);
    } else {
      setSearchInput('');
      setSelectedSearchProductId(null);
      clearTypeAhead();
    }
  };

  const triggerTypeAheadRef = useRef(triggerTypeAhead);
  triggerTypeAheadRef.current = triggerTypeAhead;

  const delayedSearch = useCallback(
    debounce((s) => triggerTypeAheadRef.current(s), 500),
    [],
  );

  useEffect(
    () => () => {
      /* istanbul ignore else */
      if (delayedSearch && delayedSearch.cancel) delayedSearch.cancel();
    },
    [delayedSearch],
  );

  useEffect(() => {
    if (lastTypeAheadHadProductList && searchInput && searchInput.trim().length > 0) {
      setShowSearchInput(true);
      setIsSearchActive(true);
    }
  }, [lastTypeAheadHadProductList, searchInput]);

  const handleSearchChange = (e) => {
    const { value } = e.target;
    if (selectedSearchProductId) setSelectedSearchProductId(null);
    setSearchInput(value);

    if (value && value.trim().length > 0) delayedSearch(value);
    else {
      /* istanbul ignore else */
      if (delayedSearch && delayedSearch.cancel) delayedSearch.cancel();
      clearTypeAhead();
    }
  };

  const handleSearchKeyDown = (e) => {
    if (e.keyCode === 13 && searchInput.trim()) {
      triggerTypeAhead(searchInput);
      onSearchClick?.();
    }
  };

  const handleClearSearch = () => {
    setSearchInput('');
    setShowSearchInput(false);
    setIsSearchActive(false);
    clearTypeAhead();
    setSelectedSearchProductId(null);
  };

  const handleTypeAheadSelect = (result) => {
    setSearchInput(result.productDisplayName);
    clearTypeAhead();
    setSelectedSearchProductId(result.productId);
    /* istanbul ignore else */
    if (result.productId) {
      getSkuDetailsBySorId(result.productId);
    }
  };
  const handleCancel = () => {
    onCancel?.();
  };

  return (
    <PageContainer data-testid='gridwall-container'>
      <TopHeaderWrapper data-testid='top-header-wrapper'>
        <TopHeader data-testid='top-header'>
          <BackButtonContainer data-testid='back-button-container'>
            <ButtonIcon
              kind='ghost'
              size={24}
              renderIcon={() => <Icon name='left-caret' size={24} />}
              onClick={onBack}
              ariaLabel='Go back'
              data-testid='back-button'
              data-track='AllDevices_Back'
            />
          </BackButtonContainer>
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <span style={{ fontWeight: 700, fontSize: '1rem' }} data-testid='all-devices-title'>
              All devices
            </span>
          </div>
        </TopHeader>
      </TopHeaderWrapper>

      <ContentWrapper data-testid='content-wrapper'>
        <ContentCard data-testid='content-card'>
          <DeviceGridHeader
            brandFilters={brandFilters}
            activeBrand={activeBrand}
            onFilterClick={handleFilterClick}
            onSearchClick={handleSearchClick}
            onScanClick={onScanClick}
            showSearchInput={showSearchInput}
            isSearchActive={isSearchActive}
          >
            <DeviceSearch
              show={showSearchInput}
              value={searchInput}
              onChange={handleSearchChange}
              onKeyDown={handleSearchKeyDown}
              onClear={handleClearSearch}
              typeAheadResults={typeAheadResults}
              onTypeAheadSelect={handleTypeAheadSelect}
              productDisplayNameMatches={productDisplayNameMatches}
            />
          </DeviceGridHeader>

          <DeviceList devices={filteredDevices} selectedDevice={selectedDevice} onSelect={handleSelectDevice} />
        </ContentCard>
      </ContentWrapper>

      <BottomActionsWrapper data-testid='bottom-actions-wrapper'>
        <BottomActions data-testid='bottom-actions'>
          <Button use='secondary' size='large' ariaLabel='Cancel' data-testid='cancel-button' onClick={handleCancel}>
            Cancel
          </Button>
          <Button
            kind='primary'
            size='medium'
            ariaLabel='Configure device'
            data-testid='configure-button'
            onClick={handleConfigure}
            disabled={!selectedDevice}
          >
            Configure Device
          </Button>
        </BottomActions>
      </BottomActionsWrapper>
    </PageContainer>
  );
}

AllDevicesGridwall.propTypes = {
  onDeviceSelect: PropTypes.func,
  onFilterChange: PropTypes.func,
  onSearchClick: PropTypes.func,
  onScanClick: PropTypes.func,
  onBack: PropTypes.func,
  onCancel: PropTypes.func,
  onConfigureDevice: PropTypes.func,
  processingMtn: PropTypes.string,
  brand: PropTypes.string,
};

AllDevicesGridwall.defaultProps = {
  onDeviceSelect: undefined,
  onFilterChange: undefined,
  onSearchClick: undefined,
  onScanClick: undefined,
  onBack: undefined,
  onCancel: undefined,
  onConfigureDevice: undefined,
  processingMtn: '',
  brand: '',
};
