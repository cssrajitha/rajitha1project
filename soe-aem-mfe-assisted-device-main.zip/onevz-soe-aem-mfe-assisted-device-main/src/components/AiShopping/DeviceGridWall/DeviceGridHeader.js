import React from 'react';
import PropTypes from 'prop-types';
import { Icon } from '@vds/icons';
import { GenerativeAiFilled } from '@vds/core/icons';
import { Button } from '@vds/buttons';
import {
  HeaderSection,
  HeaderLeft,
  SparkleIconWrapper,
  SparkleGradientDef,
  HeaderRight,
  BrandFilters,
  FilterButtonWrapper,
  HeaderActions,
  IconActionButton,
  Body,
} from './DeviceGridWall.styles';

export default function DeviceGridHeader({
  brandFilters,
  activeBrand,
  onFilterClick,
  onSearchClick,
  onScanClick,
  children,
  isSearchActive,
}) {
  return (
    <HeaderSection data-testid='header-section'>
      <HeaderLeft data-testid='header-left'>
        <SparkleGradientDef />
        <SparkleIconWrapper data-testid='sparkle-icon-wrapper'>
          <GenerativeAiFilled size={24} />
        </SparkleIconWrapper>
        <Body size='large' color='#000000' bold data-testid='recommendations-title'>
          Device recommendations
        </Body>
      </HeaderLeft>

      <HeaderRight data-testid='header-right'>
        {!isSearchActive && (
          <BrandFilters data-testid='brand-filters'>
            {brandFilters.map((brand) => (
              <FilterButtonWrapper key={brand} data-testid={`filter-button-wrapper-${brand.toLowerCase()}`}>
                <Button
                  size='medium'
                  use={activeBrand === brand ? 'primary' : 'secondary'}
                  ariaLabel={`Filter by ${brand}`}
                  data-testid={`filter-button-${brand.toLowerCase()}`}
                  data-track={`AllDevices_Filter_${brand}`}
                  onClick={() => onFilterClick(brand)}
                >
                  {brand}
                </Button>
              </FilterButtonWrapper>
            ))}
          </BrandFilters>
        )}
        <HeaderActions data-testid='header-actions'>
          <IconActionButton aria-label='Search devices' data-testid='search-button' onClick={onSearchClick}>
            <Icon name='search' size={20} color='#000000' />
          </IconActionButton>
          <IconActionButton aria-label='Scan barcode' data-testid='scan-button' onClick={onScanClick}>
            <Icon name='barcode' size={20} color='#000000' />
          </IconActionButton>
          {children}
        </HeaderActions>
      </HeaderRight>
    </HeaderSection>
  );
}

DeviceGridHeader.propTypes = {
  brandFilters: PropTypes.array.isRequired,
  activeBrand: PropTypes.string.isRequired,
  onFilterClick: PropTypes.func.isRequired,
  onSearchClick: PropTypes.func.isRequired,
  onScanClick: PropTypes.func,
  children: PropTypes.node,
  isSearchActive: PropTypes.bool,
};
