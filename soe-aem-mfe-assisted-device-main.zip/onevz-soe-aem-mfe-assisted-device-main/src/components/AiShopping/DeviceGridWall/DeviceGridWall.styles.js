import styled from 'styled-components';
import { Body } from '@vds/typography';
import { Button } from '@vds/buttons';

// Breakpoints
export const BREAKPOINTS = {
  tablet: '1024px',
  ipadMini: '768px',
};

export const PageContainer = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  padding: 0;
  background-color: #f8f7f5;
  display: flex;
  flex-direction: column;
  overflow: auto;
  z-index: 1000;
`;

export const TopHeaderWrapper = styled.div`
  width: 100%;
  background-color: #ffffff;
  border-bottom: 1px solid #d8dada;
  flex-shrink: 0;
`;

export const TopHeader = styled.div`
  width: 100%;
  max-width: 70.8125rem; /* 1133px */
  height: 4.25rem; /* 68px */
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 0 1.5rem;
  margin: 0 auto;
  box-sizing: border-box;

  @media (max-width: ${BREAKPOINTS.tablet}) {
    max-width: 100%;
    height: 3.75rem; /* 60px */
    padding: 0 1.25rem;
  }

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    height: 3.5rem; /* 56px */
    gap: 0.75rem;
    padding: 0 1rem;
  }
`;

export const BackButtonContainer = styled.div`
  display: flex;
  align-items: center;
  flex-shrink: 0;

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    width: 2.25rem;
    height: 2.25rem;
  }
`;

export const ContentWrapper = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  padding: 1.5rem;
  overflow: auto;

  @media (max-width: ${BREAKPOINTS.tablet}) {
    padding: 1.25rem;
  }

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    padding: 1rem;
  }
`;

export const ContentCard = styled.div`
  width: 100%;
  max-width: 67.8125rem; /* 1085px */
  height: 28.875rem; /* 462px */
  background-color: #ffffff;
  border-radius: 1rem; /* 16px - VDS size/border/radius/400 */
  padding: 1.25rem; /* 20px */
  display: flex;
  flex-direction: column;
  box-sizing: border-box;
  overflow: hidden;
  margin: 0 auto;

  @media (max-width: ${BREAKPOINTS.tablet}) {
    max-width: 100%;
    height: auto;
    min-height: 26rem;
    padding: 1rem;
  }

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    padding: 0.875rem;
    border-radius: 0.75rem;
    min-height: 24rem;
  }
`;

export const HeaderSection = styled.div`
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: nowrap;
  gap: 1rem;

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    flex-direction: column;
    align-items: flex-start;
    gap: 0.75rem;
  }
`;

export const HeaderLeft = styled.div`
  display: flex;
  align-items: center;
  gap: 0.5rem; /* 8px */
  flex-shrink: 0;
`;

export const SparkleIconWrapper = styled.span`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;

  svg {
    path {
      fill: url(#sparkle-gradient);
    }
  }
  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    svg {
      width: 20px;
      height: 20px;
    }
  }
`;

export function SparkleGradientDef() {
  return (
    <svg width='0' height='0' style={{ position: 'absolute' }}>
      <defs>
        <linearGradient id='sparkle-gradient' x1='0%' y1='100%' x2='100%' y2='0%' gradientTransform='rotate(-42.78)'>
          <stop offset='41.43%' stopColor='#E10014' />
          <stop offset='95.35%' stopColor='rgba(255, 194, 32, 0.7)' />
        </linearGradient>
      </defs>
    </svg>
  );
}

export const HeaderRight = styled.div`
  display: flex;
  align-items: center;
  gap: 0.75rem; /* 12px */
  flex-wrap: nowrap;
  flex-shrink: 0;

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    width: 100%;
    justify-content: space-between;
    gap: 0.5rem;
  }
`;

export const BrandFilters = styled.div`
  display: flex;
  align-items: center;
  gap: 0.5rem; /* 8px */
  flex-wrap: nowrap;
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;

  &::-webkit-scrollbar {
    display: none;
  }
  -ms-overflow-style: none;
  scrollbar-width: none;

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    gap: 0.375rem;
  }
`;

export const FilterButtonWrapper = styled.div`
  flex-shrink: 0;

  button {
    border-radius: 1.375rem !important; /* 22px pill shape */
    min-width: auto !important;
    height: 2.75rem !important; /* 44px */
    padding: 0.625rem 1.25rem !important; /* 10px 20px */
    font-size: 1rem !important;
    line-height: 1.25rem !important;
  }

  @media (max-width: ${BREAKPOINTS.tablet}) {
    button {
      height: 2.5rem !important;
      padding: 0.5rem 1rem !important;
      font-size: 0.9375rem !important;
    }
  }

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    button {
      height: 2.25rem !important;
      padding: 0.375rem 0.875rem !important;
      font-size: 0.875rem !important;
      border-radius: 1.125rem !important;
    }
  }
`;

export const HeaderActions = styled.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  flex-shrink: 0;
  position: relative;
`;

export const SearchInputWrapper = styled.div`
  position: absolute;
  right: 100%;
  margin-right: 0.5rem;
  width: 220px;
  display: ${(props) => (props.show ? 'block' : 'none')};

  @media (max-width: ${BREAKPOINTS.tablet}) {
    width: 180px;
  }

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    width: 150px;
  }
`;

export const SearchIconWrapper = styled.div`
  position: absolute;
  right: 8px;
  top: 50%;
  transform: translateY(-50%);
  pointer-events: none;
`;

export const SearchDropdown = styled.div`
  position: absolute;
  top: calc(100% + 4px);
  left: 0;
  right: 0;
  background: white;
  border: 1px solid #d8dada;
  border-radius: 0.5rem;
  max-height: 300px;
  overflow-y: auto;
  z-index: 1000;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);

  &::-webkit-scrollbar {
    width: 6px;
  }

  &::-webkit-scrollbar-track {
    background: transparent;
  }

  &::-webkit-scrollbar-thumb {
    background-color: rgba(0, 0, 0, 0.2);
    border-radius: 3px;
  }
`;

export const SearchResultItem = styled.div`
  padding: 0.75rem 1rem;
  cursor: pointer;
  border-bottom: 1px solid #f0f0f0;
  transition: background-color 0.2s ease;

  &:last-child {
    border-bottom: none;
  }

  &:hover {
    background-color: #f8f7f5;
  }

  &:active {
    background-color: #ebebeb;
  }
`;

export const IconActionButton = styled.button`
  width: 2.75rem; /* 44px */
  height: 2.75rem; /* 44px */
  border-radius: 50%;
  border: 1px solid rgba(0, 0, 0, 0.12);
  background: #f8f7f5;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.2s ease;
  flex-shrink: 0;

  &:hover {
    background-color: #ebebeb;
    border-color: rgba(0, 0, 0, 0.22);
  }

  &:focus {
    outline: 2px solid #000000;
    outline-offset: 2px;
  }

  @media (max-width: ${BREAKPOINTS.tablet}) {
    width: 2.5rem;
    height: 2.5rem;
  }

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    width: 2.25rem;
    height: 2.25rem;

    svg {
      width: 18px;
      height: 18px;
    }
  }
`;

export const DevicesContainer = styled.div`
  flex: 1;
  width: 100%;
  margin-top: 1.25rem; /* 20px */
  display: flex;
  gap: 1.25rem; /* 20px */
  overflow-x: auto;
  overflow-y: hidden;
  -webkit-overflow-scrolling: touch;
  align-items: stretch;

  &::-webkit-scrollbar {
    height: 0.375rem;
  }

  &::-webkit-scrollbar-track {
    background: transparent;
  }

  &::-webkit-scrollbar-thumb {
    background-color: rgba(0, 0, 0, 0.2);
    border-radius: 0.1875rem;
  }

  @media (max-width: ${BREAKPOINTS.tablet}) {
    margin-top: 1rem;
    gap: 1rem;
  }

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    margin-top: 0.75rem;
    gap: 0.75rem;
  }
`;

export const DeviceCardStyled = styled.div`
  position: relative;
  width: 15rem; /* 240px */
  min-width: 15rem;
  height: 100%;
  background-color: #ffffff;
  border-radius: 1rem; /* 16px */
  border: 1px solid #d8dada;
  padding: 1rem; /* 16px */
  display: flex;
  flex-direction: column;
  flex-shrink: 0;
  box-sizing: border-box;
  transition: all 0.2s ease;

  &:hover {
    border-color: rgba(0, 0, 0, 0.3);
    box-shadow: 0 0.25rem 0.75rem rgba(0, 0, 0, 0.08);
  }

  @media (max-width: ${BREAKPOINTS.tablet}) {
    width: 13.5rem;
    min-width: 13.5rem;
    padding: 0.875rem;
  }

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    width: 12rem;
    min-width: 12rem;
    padding: 0.75rem;
    border-radius: 0.75rem;
  }
`;

export const DeviceInfoSection = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.25rem; /* 4px */
`;

export const DevicePriceRow = styled.div`
  display: flex;
  align-items: baseline;
  gap: 0.25rem;
  flex-wrap: wrap;
`;

export const DeviceImageContainer = styled.div`
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 1rem 0;
  min-height: 11rem; /* 176px */

  @media (max-width: ${BREAKPOINTS.tablet}) {
    padding: 0.75rem 0;
    min-height: 9.5rem;
  }

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    padding: 0.5rem 0;
    min-height: 8rem;
  }
`;

export const DeviceImage = styled.div`
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: transparent;

  svg {
    width: auto;
    height: 100%;
    max-width: 140px;
    max-height: 180px;
  }

  @media (max-width: ${BREAKPOINTS.tablet}) {
    svg {
      max-width: 120px;
      max-height: 150px;
    }
  }

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    svg {
      max-width: 100px;
      max-height: 130px;
    }
  }
`;

export const SelectButton = styled(Button)`
  && {
    width: auto;
    min-width: 4rem; /* 64px - smaller */
    align-self: flex-end;
    margin-right: 0.5rem;
    border-radius: 1.25rem; /* slightly smaller pill */
    padding: 0.375rem 0.75rem; /* reduced padding */
    font-size: 0.8125rem; /* 13px */
    font-weight: 700;
    text-transform: none;
  }

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    && {
      min-width: 3.75rem;
      padding: 0.3125rem 0.625rem;
      font-size: 0.75rem;
      border-radius: 1rem;
      margin-right: 0.375rem;
    }
  }
`;

export const SelectedOverlay = styled.div`
  position: absolute;
  right: 0.875rem; /* 14px */
  bottom: 0.875rem; /* 14px */
  width: 2.25rem; /* 36px */
  height: 2.25rem; /* 36px */
  border-radius: 50%;
  background: #000000;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  z-index: 2;

  svg {
    width: 18px;
    height: 18px;
    fill: #ffffff;
  }

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    right: 0.625rem;
    bottom: 0.625rem;
    width: 1.875rem;
    height: 1.875rem;

    svg {
      width: 14px;
      height: 14px;
    }
  }
`;

export const BottomActionsWrapper = styled.div`
  width: 100%;
  background-color: #ffffff;
  border-top: 1px solid #d8dada;
  margin-top: auto;
  flex-shrink: 0;
`;

export const BottomActions = styled.div`
  width: 100%;
  max-width: 70.8125rem; /* 1133px */
  display: flex;
  justify-content: flex-end;
  align-items: center;
  gap: 1rem; /* 16px */
  padding: 1rem 1.5rem;
  margin: 0 auto;
  box-sizing: border-box;

  @media (max-width: ${BREAKPOINTS.tablet}) {
    max-width: 100%;
    padding: 1rem 1.25rem;
    gap: 0.75rem;
  }

  @media (max-width: ${BREAKPOINTS.ipadMini}) {
    padding: 0.75rem 1rem;
    gap: 0.5rem;
  }
`;

export { Body };
