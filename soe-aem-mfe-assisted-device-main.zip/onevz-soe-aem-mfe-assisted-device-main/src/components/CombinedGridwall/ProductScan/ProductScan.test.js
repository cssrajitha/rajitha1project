/* eslint-disable no-promise-executor-return */
import React from 'react';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import { isIpad } from 'onevzsoemfeframework/DomService';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import { fireEvent, render, screen, waitFor, cleanup } from '../../../modules/test-utils/renderHelper';
import { setUserAgentIPad } from '../../../modules/test-utils/utils';
import ProductScan from './ProductScan';
import data from '../__mocks__/mockCombinedGridwallData.json';
import mockGridwall from '../__mocks__/mockGridwallDevices.json';

describe('ProductScan component render', () => {
  const handlers = [
    rest.post(`*/flexV2/productList`, (req, res, ctx) => {
      console.log('inside /flexV2/productList');
      return res(ctx.status(200), ctx.json(data.data));
    }),
    rest.post(`*/cartservice/cart/flexV2/retrieve-cart`, (req, res, ctx) => {
      console.log('2nd time inside /cartservice/cart/flexV2/retrieve-cart');
      return res(ctx.status(200), ctx.json({ data: mockGridwall.cartDetails }));
    }),
    rest.post(`*/accountlandingservice/flexV2/customerProfile`, (req, res, ctx) => {
      console.log('inside /accountlandingservice/flexV2/customerProfile');
      return res(ctx.status(200), ctx.json({ data: mockGridwall.landingData }));
    }),
    rest.post(`*/cart/validate-deviceSimId`, (req, res, ctx) => {
      console.log('inside /cart/validate-deviceSimId');
      return res(ctx.status(200), ctx.json(data.validateDeviceSimIdResponse));
    }),
  ];
  const server = setupServer(...handlers);

  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });
  afterAll(() => {
    server.close();
    sessionStorage.setItem('APIContext', '');
  });

  const props = {
    validateDeviceSimIdRequest: jest.fn(),
    mtn: '5155547979',
    ScanFromLanding: false,
    bestBuyIntegrationFFlag: 'TRUE',
  };
  beforeEach(() => {
    jest.resetModules();
    jest.resetAllMocks();
    render(<ProductScan {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  afterEach(cleanup);
  test('component should render', () => {
    const text = screen.getByText(/Enter Device ID/i);
    expect(text).toBeInTheDocument();
  });

  test('it should update device id on change', async () => {
    const fields = screen.getByRole('textbox', {
      name: 'Enter Device ID Optional Input Field',
    });
    fireEvent.change(fields, { target: { value: '355479501380262' } });
    fireEvent.blur(fields, { target: { value: '355479501380262' } });
    await waitFor(() => expect(fields).toHaveValue('355479501380262'));
  });

  test('it should update device id on change with empty device id', async () => {
    const fields = screen.getByRole('textbox', {
      name: 'Enter Device ID Optional Input Field',
    });
    fireEvent.blur(fields, { target: { value: '' } });
    await waitFor(() => expect(fields).toHaveValue(''));
  });

  test('it should throw error for invalid device id', async () => {
    const fields = screen.getByRole('textbox', {
      name: 'Enter Device ID Optional Input Field',
    });
    fireEvent.blur(fields, { target: { value: '35345' } });
    await waitFor(() => expect(fields).toHaveValue('35345'));
  });
});

describe(`Ipad Scan`, () => {
  setUserAgentIPad();
  jest.setTimeout(50000);
  const props = {
    validateDeviceSimIdRequest: jest.fn(),
    handleChangeDeviceID: jest.fn(),
    scanDeviceIdBarCode: jest.fn(),
    executeShellFunction: jest.fn(),
    mtn: '5155547979',
    ScanFromLanding: true,
    showScanner: true,
    setUpcCode: jest.fn(),
    bestBuyIntegrationFFlag: 'TRUE',
  };
  beforeEach(() => {
    render(<ProductScan {...props} />, { reducers: rootReducer, sagas: rootSaga });
    jest.spyOn(console, 'error');
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockImplementation(() => null);
  });

  it('Scan Device on click of Icon', async () => {
    expect(isIpad()).toBeTruthy();
    expect(screen.getByTestId('isFullFillment')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('isFullFillment'));
    const fields = screen.getByRole('textbox', { name: 'Enter Device ID Optional Input Field' });
    fireEvent.change(fields, { target: { value: '351048916755931' } });
    fireEvent.blur(fields, { target: { value: '351048916755931' } });
    fireEvent.click(screen.getByTestId('isFullFillment'));
    // waitFor(() => expect(props.scanDeviceIdBarCode).toHaveBeenCalled());
    // waitFor(() => expect(props.executeShellFunction).toHaveBeenCalled());
    await new Promise((r) => setTimeout(r, 40001));
  });
  it('Scan Device on key press of Icon', async () => {
    expect(isIpad()).toBeTruthy();
    expect(screen.getByTestId('isFullFillment')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('isFullFillment'));
    const fields = screen.getByRole('textbox', { name: 'Enter Device ID Optional Input Field' });
    fireEvent.change(fields, { target: { value: '351048916755931' } });
    fireEvent.blur(fields, { target: { value: '351048916755931' } });
    fireEvent.keyPress(screen.getByTestId('isFullFillment'), {
      key: 'Enter',
      charCode: 32,
    });

    // waitFor(() => expect(props.scanDeviceIdBarCode).toHaveBeenCalled());
    // await new Promise((r) => setTimeout(r, 20001));
    // waitFor(() => expect(props.executeShellFunction).toHaveBeenCalled());
    await new Promise((r) => setTimeout(r, 20001));
  });
});
describe(`Scan device click on ICon Scan`, () => {
  setUserAgentIPad();
  jest.setTimeout(50000);
  const props = {
    updateDWOS: jest.fn(),
    validateDeviceSimIdRequest: jest.fn(),
    handleChangeDeviceID: jest.fn(),
    scanDeviceIdBarCode: jest.fn(),
    executeShellFunction: jest.fn(),
    setUpcCode: jest.fn(),
    mtn: '5155547979',
    ScanFromLanding: false,
    showScanner: true,
    isDWOS: true,
    toggleBarcode: true,
    bestBuyIntegrationFFlag: 'TRUE',
    addressValidation: {
      bundles: {
        bundleName: 'smartphones',
      },
    },
    homeSalesBundles: [
      {
        bundleName: '5gHome',
      },
      {
        bundleName: 'smartphones',
      },
    ],
  };
  beforeEach(() => {
    render(<ProductScan {...props} />, { reducers: rootReducer, sagas: rootSaga });

    jest.spyOn(console, 'error');
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockImplementation(() => null);
  });

  it('Scan Device on click of Icon', async () => {
    expect(isIpad()).toBeTruthy();
    expect(screen.getByTestId('isFullFillment')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('isFullFillment'));
    const fields = screen.getByRole('textbox', { name: 'Enter Device ID Optional Input Field' });
    fireEvent.change(fields, { target: { value: '351048916755931' } });
    fireEvent.blur(fields, { target: { value: '351048916755931' } });
    fireEvent.click(screen.getByTestId('isFullFillment'));
    waitFor(() => expect(props.scanDeviceIdBarCode).toHaveBeenCalled());
    waitFor(() => expect(props.executeShellFunction).toHaveBeenCalled());
    // await new Promise((r) => setTimeout(r, 20001));
  });
});
describe(`5G Internet Home bundle flow`, () => {
  setUserAgentIPad();
  jest.setTimeout(50000);
  const props = {
    validateDeviceSimIdRequest: jest.fn(),
    handleChangeDeviceID: jest.fn(),
    scanDeviceIdBarCode: jest.fn(),
    executeShellFunction: jest.fn(),
    setUpcCode: jest.fn(),
    mtn: '5155547979',
    ScanFromLanding: false,
    bestBuyIntegrationFFlag: 'TRUE',
    showScanner: true,
    homeSalesBundles: [
      {
        bundleName: '5gHome',
      },
      {
        bundleName: 'smartphones',
      },
    ],
    combinedGridwall: {
      activeMtn: '1234567891',
    },
    totalLines: [
      {
        mobileNumber: '1234567891',
        deviceTypeSelected: '5G Internet',
      },
      {
        mobileNumber: '01234567891',
        deviceTypeSelected: '5G Internet',
      },
    ],
  };
  beforeEach(() => {
    render(<ProductScan {...props} />, { reducers: rootReducer, sagas: rootSaga });

    jest.spyOn(console, 'error');
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockImplementation(() => null);
  });

  it('Scan Device on click of Icon', async () => {
    expect(isIpad()).toBeTruthy();
    expect(screen.getByTestId('isFullFillment')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('isFullFillment'));
    const fields = screen.getByRole('textbox', { name: 'Enter Device ID Optional Input Field' });
    fireEvent.change(fields, { target: { value: '351048916755931' } });
    fireEvent.blur(fields, { target: { value: '351048916755931' } });
    fireEvent.click(screen.getByTestId('isFullFillment'));
    waitFor(() => expect(props.scanDeviceIdBarCode).toHaveBeenCalled());
    // await new Promise((r) => setTimeout(r, 101));
    waitFor(() => expect(props.executeShellFunction).toHaveBeenCalled());
    // await new Promise((r) => setTimeout(r, 20001));
  });
});
describe(`5G Internet Home bundle flow`, () => {
  setUserAgentIPad();
  jest.setTimeout(50000);
  const props = {
    validateDeviceSimIdRequest: jest.fn(),
    handleChangeDeviceID: jest.fn(),
    scanDeviceIdBarCode: jest.fn(),
    executeShellFunction: jest.fn(),
    setUpcCode: jest.fn(),
    mtn: '5155547979',
    ScanFromLanding: false,
    bestBuyIntegrationFFlag: 'TRUE',
    showScanner: true,
    homeSalesBundles: [
      {
        bundleName: '5GHomeSelfInstall',
      },
      {
        bundleName: 'smartphones',
      },
    ],
    combinedGridwall: {
      activeMtn: '1234567891',
    },
    totalLines: [
      {
        mobileNumber: '1234567891',
        deviceTypeSelected: '5G Internet',
      },
      {
        mobileNumber: '01234567891',
        deviceTypeSelected: '5G Internet',
      },
    ],
  };
  beforeEach(() => {
    render(<ProductScan {...props} />, { reducers: rootReducer, sagas: rootSaga });

    jest.spyOn(console, 'error');
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockImplementation(() => null);
  });

  it('Scan Device on click of Icon', async () => {
    expect(isIpad()).toBeTruthy();
    expect(screen.getByTestId('isFullFillment')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('isFullFillment'));
    const fields = screen.getByRole('textbox', { name: 'Enter Device ID Optional Input Field' });
    fireEvent.change(fields, { target: { value: '351048916755931' } });
    fireEvent.blur(fields, { target: { value: '351048916755931' } });
    fireEvent.click(screen.getByTestId('isFullFillment'));
    waitFor(() => expect(props.scanDeviceIdBarCode).toHaveBeenCalled());
    // await new Promise((r) => setTimeout(r, 101));
    waitFor(() => expect(props.executeShellFunction).toHaveBeenCalled());
  });
});
describe(`5G Internet Home bundle flow`, () => {
  setUserAgentIPad();
  jest.setTimeout(50000);
  const props = {
    validateDeviceSimIdRequest: jest.fn(),
    handleChangeDeviceID: jest.fn(),
    scanDeviceIdBarCode: jest.fn(),
    executeShellFunction: jest.fn(),
    setUpcCode: jest.fn(),
    mtn: '5155547979',
    ScanFromLanding: false,
    bestBuyIntegrationFFlag: 'TRUE',
    showScanner: true,
    homeSalesBundles: [
      {
        bundleName: '5GHomeSelfInstall',
      },
      {
        bundleName: 'smartphones',
      },
    ],
    combinedGridwall: {
      activeMtn: '1234567891',
    },
    totalLines: [
      {
        mobileNumber: '1234567891',
        deviceTypeSelected: '5G Internet',
      },
      {
        mobileNumber: '01234567891',
        deviceTypeSelected: '5G Internet',
      },
    ],
  };
  beforeEach(() => {
    render(<ProductScan {...props} />, { reducers: rootReducer, sagas: rootSaga });

    jest.spyOn(console, 'error');
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockImplementation(() => null);
  });

  it('Scan Device on click of Icon', async () => {
    expect(isIpad()).toBeTruthy();
    expect(screen.getByTestId('isFullFillment')).toBeInTheDocument();
    fireEvent.click(screen.getByTestId('isFullFillment'));
    const fields = screen.getByRole('textbox', { name: 'Enter Device ID Optional Input Field' });
    fireEvent.change(fields, { target: { value: '351048916755931' } });
    fireEvent.blur(fields, { target: { value: '351048916755931' } });
    fireEvent.click(screen.getByTestId('isFullFillment'));
    waitFor(() => expect(props.scanDeviceIdBarCode).toHaveBeenCalled());
    // await new Promise((r) => setTimeout(r, 101));
    waitFor(() => expect(props.executeShellFunction).toHaveBeenCalled());
    // await new Promise((r) => setTimeout(r, 20001));
  });
  test('test deviceIdBarCodeScannerCallback ', () => {
    const data1 = { dataset: { barcode: '{"GENERIC":true}' } };
    window.deviceIdBarCodeScannerCallback(data1);
  });
  test('test deviceIdBarCodeScannerCallback ', () => {
    const data2 = { dataset: { barcode: '{"MEID":true}' } };
    window.deviceIdBarCodeScannerCallback(data2);
  });
  test('test deviceIdBarCodeScannerCallback ', () => {
    const data3 = { dataset: { barcode: 'cancel' } };
    window.deviceIdBarCodeScannerCallback(data3);
  });
  test('test deviceIdBarCodeScannerCallback ', () => {
    const data1 = { dataset: { barcode: '{"GENERIC":true}' } };
    window.deviceIdBarCodeScannerCallback(data1);
  });
  test('test deviceIdBarCodeScannerCallback ', () => {
    const data2 = { dataset: { barcode: '{"MEID":true}' } };
    window.deviceIdBarCodeScannerCallback(data2);
  });
  test('test deviceIdBarCodeScannerCallback ', () => {
    const data3 = { dataset: { barcode: 'cancel' } };
    window.deviceIdBarCodeScannerCallback(data3);
  });
  test('test deviceIdBarCodeScannerCallback ', () => {
    const data3 = { dataset: { barcode: '{"UPC":"8787877"}' } };
    window.deviceIdBarCodeScannerCallback(data3);
  });
});
describe(`Best buy integrationn upc scan functin check`, () => {
  setUserAgentIPad();
  jest.setTimeout(50000);
  const props = {
    validateDeviceSimIdRequest: jest.fn(),
    handleChangeDeviceID: jest.fn(),
    scanDeviceIdBarCode: jest.fn(),
    executeShellFunction: jest.fn(),
    setUpcCode: jest.fn(),
    mtn: '5155547979',
    ScanFromLanding: false,
    bestBuyUpcImeiCheckFFlag: 'TRUE',
    showScanner: true,
    homeSalesBundles: [
      {
        bundleName: '5GHomeSelfInstall',
      },
      {
        bundleName: 'smartphones',
      },
    ],
    combinedGridwall: {
      activeMtn: '1234567891',
    },
    totalLines: [
      {
        mobileNumber: '1234567891',
        deviceTypeSelected: '5G Internet',
      },
      {
        mobileNumber: '01234567891',
        deviceTypeSelected: '5G Internet',
      },
    ],
  };
  beforeEach(() => {
    sessionStorage.setItem('channel', 'OMNI-INDIRECT');
    render(<ProductScan {...props} />, { reducers: rootReducer, sagas: rootSaga });

    jest.spyOn(console, 'error');
    console.error.mockImplementation(() => null);
  });

  it('Scan Device on click of Icon', async () => {
    const fields = screen.getByRole('textbox', { name: /Enter Device ID/ });
    fireEvent.change(fields, { target: { value: '351048916755' } });
    fireEvent.blur(fields, { target: { value: '351048916755' } });
    const fields1 = screen.getByRole('textbox', { name: /Enter Device ID/ });
    fireEvent.change(fields1, { target: { value: '351048916755' } });
    fireEvent.blur(fields1, { target: { value: '351048916755' } });
    const fields2 = screen.getByRole('textbox', { name: /Enter Device ID/ });
    fireEvent.change(fields2, { target: { value: '35104891675599' } });
    fireEvent.blur(fields2, { target: { value: '35104891675599' } });
  });
  it('Scan Device on click of Icon', async () => {
    const fields = screen.getByRole('textbox', { name: /Enter Device ID/ });
    fireEvent.change(fields, { target: { value: '35104891675599' } });
    fireEvent.blur(fields, { target: { value: '35104891675599' } });
  });
});
describe(`Best buy integrationn upc and device id  input functin check`, () => {
  setUserAgentIPad();
  jest.setTimeout(50000);
  const props = {
    validateDeviceSimIdRequest: jest.fn(),
    handleChangeDeviceID: jest.fn(),
    scanDeviceIdBarCode: jest.fn(),
    executeShellFunction: jest.fn(),
    setUpcCode: jest.fn(),
    mtn: '5155547979',
    ScanFromLanding: false,
    bestBuyUpcImeiCheckFFlag: 'TRUE',
    showScanner: true,
    homeSalesBundles: [
      {
        bundleName: '5GHomeSelfInstall',
      },
      {
        bundleName: 'smartphones',
      },
    ],
    combinedGridwall: {
      activeMtn: '1234567891',
    },
    totalLines: [
      {
        mobileNumber: '1234567891',
        deviceTypeSelected: '5G Internet',
      },
      {
        mobileNumber: '01234567891',
        deviceTypeSelected: '5G Internet',
      },
    ],
  };
  beforeEach(() => {
    sessionStorage.setItem('channel', 'OMNI-INDIRECT');
    render(<ProductScan {...props} />, { reducers: rootReducer, sagas: rootSaga });
    jest.spyOn(console, 'error');
    console.error.mockImplementation(() => null);
  });

  it('Scan Device on click of Icon', async () => {
    const fields = screen.getByRole('textbox', { name: /Enter Device ID/ });
    fireEvent.change(fields, { target: { value: '35104891675599' } });
    fireEvent.blur(fields, { target: { value: '35104891675599' } });
    const fields1 = screen.getByRole('textbox', { name: /Enter Device ID/ });
    fireEvent.change(fields1, { target: { value: '351048916755' } });
    fireEvent.blur(fields1, { target: { value: '351048916755' } });
  });
});
describe(`Best buy integrationn upc and device id  input functin check`, () => {
  setUserAgentIPad();
  jest.setTimeout(50000);
  const props = {
    validateDeviceSimIdRequest: jest.fn(),
    handleChangeDeviceID: jest.fn(),
    scanDeviceIdBarCode: jest.fn(),
    executeShellFunction: jest.fn(),
    setUpcCode: jest.fn(),
    mtn: '5155547979',
    ScanFromLanding: false,
    bestBuyUpcImeiCheckFFlag: 'TRUE',
    showScanner: true,
    homeSalesBundles: [
      {
        bundleName: '5GHomeSelfInstall',
      },
      {
        bundleName: 'smartphones',
      },
    ],
    combinedGridwall: {
      activeMtn: '1234567891',
    },
    totalLines: [
      {
        mobileNumber: '1234567891',
        deviceTypeSelected: '5G Internet',
      },
      {
        mobileNumber: '01234567891',
        deviceTypeSelected: '5G Internet',
      },
    ],
  };
  beforeEach(() => {
    sessionStorage.setItem('channel', 'OMNI-INDIRECT');
    render(<ProductScan {...props} />, { reducers: rootReducer, sagas: rootSaga });
    jest.spyOn(console, 'error');
    console.error.mockImplementation(() => null);
  });

  it('Scan Device on click of Icon', async () => {
    const fields2 = screen.getByRole('textbox', { name: /Enter Device ID/ });
    fireEvent.change(fields2, { target: { value: '351048' } });
    fireEvent.blur(fields2, { target: { value: '351048' } });
  });
});
