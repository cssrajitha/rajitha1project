import { Input } from '@vds/inputs';
import React, { useState, useEffect, useRef } from 'react';
import { useDispatch } from 'react-redux';
import styled from 'styled-components';
import { isIpad, executeShellFunction } from 'onevzsoemfeframework/DomService';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import TimeoutManager from 'onevzsoemfecommon/TimeoutManager';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import { isEmpty } from 'lodash';

const IconWrapper = styled.div`
  display: flex;
  position: relative;
  span {
    cursor: pointer;
  }
`;

// const BarcodeIconWrapper = styled.div`
//   display: flex;
//   padding-top: 2rem;
//   padding-left: 1rem;
// `;

const ProductScan = (props) => {
  const inputRegEx = /^[a-zA-Z0-9]{10,16}$/;

  const spanRef = useRef(null);

  const [deviceId, setDeviceId] = useState('');
  const [deviceError, setDeviceError] = useState(false);
  // const [simError, setSimError] = useState(false);
  const [isScanActive, setScanActive] = useState(false);
  const [isSimIdScanActive, setSimIdScanActive] = useState(false);
  const [showInput, setShowInput] = useState(false);
  const [simId, setSimId] = useState('');
  const [upcScanned, setUpcScanned] = useState(false);
  const [IMEIScanned, setIMEIScanned] = useState(false);
  const [BBYDeviceId, setBBYDeviceId] = useState('');
  const dispatch = useDispatch();
  const {
    fromCpe,
    isCustomerProvidedEquipment,
    combinedGridwall = {},
    addressValidation = {},
    ScanFromLanding,
    validateDeviceSimIdRequest,
    showScanner,
    totalLines,
    homeSalesBundles,
    toggleBarcode,
  } = props;

  let device;

  const cleanUpEmitterFFlag = /true/i.test(getAssistedCradlePropertyV2(['cleanUpEmitterFFlag'])?.[0]);
  const timeoutManagerForSetTimeout = new TimeoutManager({ fileName: 'ProductScan.js', enableFF: cleanUpEmitterFFlag });
  const lineInfo = totalLines || [];
  const activeLine =
    lineInfo && lineInfo.length > 0 && lineInfo.filter((line) => line?.mobileNumber === combinedGridwall?.activeMtn);
  const fiveGDetails =
    activeLine &&
    activeLine.length > 0 &&
    activeLine.filter((line) => line && line.deviceTypeSelected && line.deviceTypeSelected === '5G Internet');
  const isFiveG = !!(fiveGDetails && fiveGDetails.length > 0);
  const bundleNameFromAddressValidation =
    addressValidation && addressValidation.bundles && addressValidation.bundles.bundleName
      ? addressValidation.bundles.bundleName
      : '';
  const bundleNameFromHomeSales = [];
  if (homeSalesBundles) {
    homeSalesBundles.map((nameBundle) => {
      bundleNameFromHomeSales.push(nameBundle.bundleName);
      return nameBundle;
    });
  }
  const bundleName = !isEmpty(bundleNameFromAddressValidation)
    ? bundleNameFromAddressValidation
    : bundleNameFromHomeSales.toString();
  // const showScannerForIndirect = true; // (channelName?.includes("OMNI-INDIRECT")) ? (isIpad() || (!ScanFromLanding && isprepaycart)) : true;
  // const isIndirectIpad = channelName?.includes('OMNI-INDIRECT') && isIpad();
  // const isCCHorPADFlow =
  //   this.props.isIndirect &&
  //   this.props.isRfexFlow &&
  //   (this.props.lineActivityType === 'CCH' || this.props.lineActivityType === 'PAD');
  const channelName = sessionStorage.getItem('channel');
  const deviceIdLabel = `Enter Device ID ${props?.bestBuyUpcImeiCheckFFlag === 'TRUE' && channelName?.includes('OMNI-INDIRECT') ? ' or UPC' : ''}`;
  const handleChangeDeviceID = (e) => {
    const input = e.target.value.trim();
    setDeviceId(input);
  };

  const handleOnBlurDeviceID = (e) => {
    const input = e.target.value.trim();
    // const channelName = sessionStorage.getItem('channel');
    const isValid = inputRegEx.test(input);
    setDeviceId(input);
    if (input === '') {
      return true;
    }
    if (!isValid) {
      dispatch(
        appMessageActions.addAppMessage(
          `${input} was scanned, please scan a valid device id${
            props?.bestBuyUpcImeiCheckFFlag === 'TRUE' && channelName?.includes('OMNI-INDIRECT') ? ' or UPC' : ''
          }`,
          'error',
          true,
          true,
        ),
      );
      return;
    }
    // Check if the device type requires a UPC scan
    if (props?.bestBuyUpcImeiCheckFFlag === 'TRUE' && channelName?.includes('OMNI-INDIRECT')) {
      // If input is a 12-digit UPC
      if (!upcScanned && input.length === 12) {
        props?.setUpcCode(input);
        setUpcScanned(true);
        if (!IMEIScanned) {
          dispatch(
            appMessageActions.addAppMessage(`UPC entered is valid, please scan the device id`, 'info', true, true),
          );
        } else {
          // If IMEI was already scanned, validate both
          callValidateDeviceAndSIM(BBYDeviceId);
        }
        setDeviceId('');
        return;
      }
      // If input is an IMEI/device ID
      if (input.length > 12) {
        setDeviceId(input);
        setIMEIScanned(true);
        setBBYDeviceId(input);
        setDeviceId('');
        // If UPC hasn't been scanned yet, store the IMEI and show message
        if (!upcScanned) {
          dispatch(
            appMessageActions.addAppMessage(
              `Device ID stored, please scan a valid 12-digit UPC to proceed`,
              'info',
              true,
              true,
            ),
          );
          return;
        }
        // If UPC was already scanned, proceed with validation
        callValidateDeviceAndSIM(input);
      }
      if (upcScanned && input.length === 12) {
        props?.setUpcCode(input);
        setDeviceId('');
        dispatch(appMessageActions.addAppMessage(`UPC updated, please scan the device id`, 'success', true, true));
      }
    } else {
      // For devices that do NOT require a UPC (RETAIL flow)
      callValidateDeviceAndSIM(input);
    }
  };

  const callValidateDeviceAndSIM = (val = '') => {
    const { fromInterim = '', isDWOS = '' } = combinedGridwall || {};
    const sku = '';
    // sku = (ScanFromLanding === false && !isCustomerProvidedEquipment && !fromCpe) || fromInterim === true ? sku : '';
    const eskuId = ''; // Todo for PDP scanner

    validateDeviceSimIdRequest({
      mtn: props.mtn,
      deviceId: val !== '' ? val : deviceId,
      simId, // Todo for Indirect Sim Scan
      cpSimCard: false,
      fromCpe,
      isCustomerProvidedEquipment,
      fromInterim,
      sku,
      eskuId,
      deviceFlow: true,
      isDWOS,
      scanFromLanding: ScanFromLanding,
    });
  };

  const deviceIdBarCodeScannerCallback = (data) => {
    console.log(`devicescan -1 - inside callback function , ${JSON.stringify(data)}`);
    try {
      if (isIpad()) {
        if (data.dataset.barcode === 'cancel') {
          setScanActive(false);
          setSimIdScanActive(false);
        } else {
          const barcodeData = data.dataset.barcode.replace(/'/g, '"');
          const barcode = JSON.parse(barcodeData);
          console.log(
            `devicescan -1a - inside callback , ${JSON.stringify(data)} , ${barcode}, ${barcode?.MEID} , ${
              barcode?.ICCID
            }`,
          );
          if (barcode?.MEID || barcode?.GENERIC) {
            console.log(
              `devicescan -2 - ,data , barcode ,barcode.MEID ,barcode.ICCID , ${JSON.stringify(data)} , ${barcode}, ${
                barcode?.MEID
              } , ${barcode?.ICCID}`,
            );
            setDeviceId(barcode.GENERIC ? barcode.GENERIC : barcode.MEID);
            setSimId(barcode.ICCID ? barcode.ICCID : '');
            setDeviceError(false);
            // setSimError(false);
            setScanActive(false);
            setSimIdScanActive(false);
            callValidateDeviceAndSIM(barcode.MEID || barcode.GENERIC);
          }
          if (barcode?.UPC) {
            props?.setUpcCode(barcode?.UPC);
          }
        }
      } else {
        // handled desktop scan data
        handleChangeDeviceID(data);
      }
    } catch (e) {
      console.log(`error in catch block, ${e}`);
    }
  };

  useEffect(() => {
    window.deviceIdBarCodeScannerCallback = deviceIdBarCodeScannerCallback;
    if (spanRef.current && isIpad() && toggleBarcode && showScanner) {
      spanRef.current.click();
    }
    return () => {
      timeoutManagerForSetTimeout.clearAllTimeouts();
    };
  }, []);

  const scanDeviceIdBarCode = (e) => {
    // const channelName = sessionStorage.getItem('channel');
    const newLocal = 'deviceIdScanner';
    // let isSimIdScanActive = this.state.isSimIdScanActive;
    const isDeviceID = e?.currentTarget?.id === newLocal;
    let scanActive;
    // eslint-disable-next-line no-unused-expressions
    if (isDeviceID) {
      setScanActive({
        isScanActive: !simId ? !isScanActive : isScanActive,
      });
      scanActive = true;
    } else {
      setSimIdScanActive({
        isSimIdScanActive: !simId ? !isSimIdScanActive : isSimIdScanActive,
      });
    }
    if (ScanFromLanding && !channelName?.includes('OMNI-INDIRECT')) {
      setShowInput({ showInput: !simId ? !showInput : showInput });
    }
    if (props.isDWOS) {
      props.updateDWOS();
    }
    if (e) e.preventDefault();

    if (isIpad()) {
      const str = 'window.deviceIdBarCodeScannerCallback';
      timeoutManagerForSetTimeout.scheduleTimeout(() => {
        if (scanActive || isSimIdScanActive) {
          /* istanbul ignore next */
          if (isFiveG && bundleName.includes('5GHomeSelfInstall')) {
            const params = { barcodeLength: '9' };
            executeShellFunction('HolsterManager', 'activateBarcodeGeneric', str, params);
            timeoutManagerForSetTimeout.scheduleTimeout(() => {
              executeShellFunction('HolsterManager', 'deactivateBarcode', 'none', null);
            }, 20000);
          } else {
            const activeBarCode = isDeviceID ? 'activateBarcodeMulti' : 'activateBarcodeICCID';
            executeShellFunction('HolsterManager', activeBarCode, str, null);
            timeoutManagerForSetTimeout.scheduleTimeout(() => {
              executeShellFunction('HolsterManager', 'deactivateBarcode', 'none', null);
            }, 20000);
          }
        } else {
          executeShellFunction('HolsterManager', 'deactivateBarcode', 'none', null);
        }
      }, 100);
    } else {
      // desktop: set callback function first, then init scanner events for barcode scanning

      device?.barcodeScan?.registerBarcodeCallback(deviceIdBarCodeScannerCallback);
      device?.barcodeScan?.scanBarcode();
    }
  };

  const scanOnKeyPress = (e) => {
    if (e.charCode === 13 || e.charCode === 32) {
      scanDeviceIdBarCode();
    }
  };

  return (
    <IconWrapper data-testid='device-scan'>
      <Input
        type='text'
        name='deviceId'
        id='deviceId'
        data-testid='handleChangeDeviceID'
        placeholder={deviceIdLabel}
        value={deviceId}
        onChange={handleChangeDeviceID}
        onBlur={handleOnBlurDeviceID}
        autoComplete='off'
        label={deviceIdLabel}
        required={false}
        width={300}
        error={deviceError}
      />
      {showScanner && isIpad() && (
        <span
          data-testid='isFullFillment'
          data-track='customer-provided equipment_scan'
          ref={spanRef}
          tabIndex='0'
          aria-label='scanner'
          role='button'
          onClick={(e) => {
            scanDeviceIdBarCode(e);
          }}
          onKeyPress={(e) => scanOnKeyPress(e)}
          id='deviceIdScanner'
        >
          {/* <BarcodeIconWrapper>
            <Icon color={isScanActive ? '#0096E4' : '#000000'} name='barcode' size='31' />
          </BarcodeIconWrapper> */}
        </span>
      )}
    </IconWrapper>
  );
};

export default ProductScan;
