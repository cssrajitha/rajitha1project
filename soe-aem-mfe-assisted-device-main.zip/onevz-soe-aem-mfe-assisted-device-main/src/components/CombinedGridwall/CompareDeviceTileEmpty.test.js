import React from 'react';
import { render, fireEvent, act, screen } from '@testing-library/react';
import { setupChannel, setUserAgentIPad, CHANNELS } from '../../modules/test-utils/utils';
import CompareDeviceTileEmpty from './CompareDeviceTileEmpty';

// const Test = (channel) => {
//   setupChannel(channel);
// };

const CompareDeviceTile = (channel) => {
  setupChannel(channel);
  setUserAgentIPad();
  describe(`AutoPay Component  - ${channel}`, () => {
    let history;
    beforeEach(() => {
      jest.spyOn(console, 'error');
      // @ts-ignore jest.spyOn adds this functionallity
      console.error.mockImplementation(() => null);
      ({ history } = render(<CompareDeviceTileEmpty history={history} channel={channel} />));
    });

    test('renders when scrolled is equal to true', () => {
      // const { container } = render(<CompareDeviceTileEmpty scrolled hideCompareDevicesModal={jest.fn()} />);
      const dataTest = screen.getAllByTestId('emptyTile')[0];
      act(() => {
        fireEvent.click(dataTest);
      });
    });

    test('renders hideCompareDevicesModal', () => {
      // const { container } = render(<CompareDeviceTileEmpty hideCompareDevicesModal={jest.fn()} />);
      const dataTest = screen.getAllByTestId('emptyTile')[0];
      act(() => {
        fireEvent.click(dataTest);
      });
    });
  });
  describe(`AutoPay Component  - ${channel}`, () => {
    let history;
    beforeEach(() => {
      jest.spyOn(console, 'error');
      // @ts-ignore jest.spyOn adds this functionallity
      console.error.mockImplementation(() => null);
      ({ history } = render(<CompareDeviceTileEmpty history={history} channel={channel} scrolled />));
    });

    test('renders when scrolled is equal to true', () => {
      // const { container } = render(<CompareDeviceTileEmpty scrolled hideCompareDevicesModal={jest.fn()} />);
      const dataTest = screen.getAllByTestId('emptyTile')[0];
      act(() => {
        fireEvent.click(dataTest);
      });
    });

    test('renders hideCompareDevicesModal', () => {
      // const { container } = render(<CompareDeviceTileEmpty hideCompareDevicesModal={jest.fn()} />);
      const dataTest = screen.getAllByTestId('emptyTile')[0];
      act(() => {
        fireEvent.click(dataTest);
      });
    });
  });
};
CompareDeviceTile(CHANNELS.OMNI_TELESALES);
CompareDeviceTile(CHANNELS.OMNI_RETAIL);
CompareDeviceTile(CHANNELS.OMNI_INDIRECT);
