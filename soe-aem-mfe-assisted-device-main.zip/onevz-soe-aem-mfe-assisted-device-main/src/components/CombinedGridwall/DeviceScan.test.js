import React from 'react';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import Emitter from 'onevzsoemfeframework/Emitter';
import { trainingFlag } from 'onevzsoemfecommon/Helpers/validation';
import * as DomService from 'onevzsoemfeframework/DomService';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import { render, screen, fireEvent, act, waitFor } from '../../modules/test-utils/renderHelper';
import DeviceScan from './DeviceScan';
import { setUserAgentIPad } from '../../modules/test-utils/utils';

jest.mock('onevzsoemfecommon/Helpers/validation', () => ({
  __esModule: true,
  ...jest.requireActual('onevzsoemfecommon/Helpers/validation'),
  trainingFlag: jest.fn(),
}));

jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    isAsurion: () => true,
    isIpad: () => true,
    getQueryParamByName: (value) => {
      if (value === 'isWSAPCpeError') return true;
    },
  }),
  { virtual: true },
);

jest.mock(
  '../../../modules/services/APIService/APIServiceHooks',
  () => {
    let index = 1;
    return {
      __esModule: true,
      ...jest.requireActual('../../../modules/services/APIService/APIServiceHooks'),
      useLazyDeviceInventoryStatusCheckQuery: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'fulfilled',
              data: {
                status: 'success',
                data: {
                  isDeviceAvailableInStoreInventory: true,
                },
              },
            },
          ];
        }
        return [() => {}, { data: {} }];
      },
    };
  },
  { virtual: true },
);

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getAssistedCradlePropertyV2: () => ['TRUE'],
  }),
  { virtual: true },
);
describe('DeviceScan component', () => {
  const props = {
    setDeviceInput: jest.fn(),
    setRepSelectedSimType: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    ivrDeviceId: true,
    handleChangeDeviceIDs: jest.fn(),
    LineDeviceId: '4567',
    isPdpPage: false,
    lineActivityType: 'PAD',
    isIndirect: true,
    isRfexFlow: true,
    ScanFromLanding: false,
    isprepaycart: true,
    isFiveG: true,
    activeMtn:
      '8482470044 cartDetails?.cart?.lineDetails?.lineInfo?.[0]?.itemsInfo?.[0].cartItems?.cartItem?.[0].imei2',
    cartDetails: {
      cart: { lineDetails: { lineInfo: [{ itemsInfo: [{ cartItems: { cartItem: [{ imei2: '1212122121' }] } }] }] } },
      lineInfo: [
        {
          mobileNumber: '8482470044',
          deviceTypeSelected: '5G Internet',
        },
      ],
    },
    CustomerData: {
      channel: 'OMNI-RETAIL',
      qualificationDetails: {
        fiveGHomebundle: [
          {
            bundleName: 'Gen4',
          },
        ],
        cBandQualified: true,
      },
      homeSalesAddress: {
        bundles: [],
      },
      billAccounts: [
        {
          mtns: [
            {
              mtn: '12345',
            },
          ],
        },
      ],
    },
    validateDeviceSimIdRequest: jest.fn(),
    isPDPMFEEnabledTS: 'TRUE',
    isDeviceInputDisabled: jest.fn(),
    isFromPDPPage: true,
    isNewlyAddedLine: true,
    isByodUpdate: true,
    isDisabled: false,
  };
  const handlers = [
    rest.post(`*/flexV2/deviceInventoryStatusCheck`, (req, res, ctx) => {
      console.log('inside /flexV2/deviceInventoryStatusCheck');
      return res(
        ctx.status(200),
        ctx.json({ data: { isDeviceAvailableInStoreInventory: false }, status: 'fulfilled' }),
      );
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    sessionStorage.setItem('refundexchange', 'true');
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    sessionStorage.setItem('isPearl', 'true');
    sessionStorage.setItem('APP_PROPERTIES', '{"blockLocalInventoryRetailBYOD": "TRUE", "pearlBYODFlow": "TRUE"}');
    sessionStorage.getItem('Qualification_type', 'CBD');
    render(<DeviceScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('Find by DeviceId text', () => {
    Emitter.emit('CONT_SIM_VALIDATION', '354615755195390');
    const deviceIdText = screen.getByTestId('handleChangeDeviceID');
    expect(deviceIdText).toBeInTheDocument();
  });

  test('Find by DeviceId text', () => {
    Emitter.emit('CONT_SIM_VALIDATION', { respCode: '354615755195390' });
    const deviceIdText = screen.getByTestId('handleChangeDeviceID');
    expect(deviceIdText).toBeInTheDocument();
  });

  test('Device Scan testing by entering device Id', async () => {
    const deviceTextBox = await screen.getByTestId('handleChangeDeviceID');
    expect(deviceTextBox).toBeInTheDocument();

    fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
    fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
    // expect(deviceTextBox).toHaveValue('350669643749367');
  });

  test('Device Scan testing by entering incorrect device Id ', async () => {
    const deviceTextBox = await screen.getByTestId('handleChangeDeviceID');
    expect(deviceTextBox).toBeInTheDocument();

    fireEvent.change(deviceTextBox, { target: { value: '35066964374936' } });
    fireEvent.blur(deviceTextBox, { target: { value: '35066964374936' } });
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
    // expect(deviceTextBox).toHaveValue('35066964374936');
  });

  test('it should render handleChangeDeviceID', () => {
    const handleChangeDeviceID = screen.getByTestId('handleChangeDeviceID');
    expect(handleChangeDeviceID).toBeInTheDocument();
    fireEvent.click(handleChangeDeviceID);
  });
  test('DeviceScan component should render', () => {
    const testid = screen.getByRole('textbox');
    fireEvent.change(testid, { target: { value: '4567' } });
    fireEvent.blur(testid, { target: { value: '4567' } });
  });
});
describe('DeviceScan component', () => {
  setUserAgentIPad();
  const props = {
    setRepSelectedSimType: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    ivrDeviceId: true,
    handleChangeDeviceIDs: jest.fn(),
    LineDeviceId: '4567',
    isPdpPage: false,
    lineActivityType: 'PAD',
    isIndirect: true,
    isRfexFlow: true,
    ScanFromLanding: false,
    isprepaycart: true,
    isFiveG: true,
    activeMtn: '8482470044',
    cartDetails: {
      lineInfo: [
        {
          mobileNumber: '8482470044',
          deviceTypeSelected: '5G Internet',
        },
      ],
    },
    CustomerData: {
      qualificationDetails: {},
      homeSalesAddress: {
        bundles: [],
      },
      channel: 'OMNI-RETAIL',
      billAccounts: [
        {
          mtns: [
            {
              mtn: '12345',
            },
          ],
        },
      ],
    },
    validateDeviceSimIdRequest: jest.fn(),
    isPDPMFEEnabledTS: 'TRUE',
    isDeviceInputDisabled: jest.fn(),
    isDisabled: true,
  };
  const handlers = [
    rest.post(`*/flexV2/deviceInventoryStatusCheck`, (req, res, ctx) => {
      console.log('inside /flexV2/deviceInventoryStatusCheck');
      return res(
        ctx.status(200),
        ctx.json({ data: { data: { data: { isDeviceAvailableInStoreInventory: true } } }, status: 'fulfilled' }),
      );
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    sessionStorage.setItem('refundexchange', 'false');
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    sessionStorage.setItem('isPearl', 'true');
    sessionStorage.setItem('APP_PROPERTIES', '{"blockLocalInventoryRetailBYOD": "TRUE", "pearlBYODFlow": "TRUE"}');
    sessionStorage.getItem('Qualification_type', 'CBD');
    render(<DeviceScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('Find by DeviceId text', () => {
    const deviceIdText = screen.getByTestId('handleChangeDeviceID');
    expect(deviceIdText).toBeInTheDocument();
  });

  test('Device Scan testing by entering device Id', async () => {
    const deviceTextBox = await screen.getByTestId('handleChangeDeviceID');
    expect(deviceTextBox).toBeInTheDocument();

    fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
    fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
    // expect(deviceTextBox).toHaveValue('350669643749367');
  });

  test('Device Scan testing by entering incorrect device Id ', async () => {
    const deviceTextBox = await screen.getByTestId('handleChangeDeviceID');
    expect(deviceTextBox).toBeInTheDocument();

    fireEvent.change(deviceTextBox, { target: { value: '35066964374936' } });
    fireEvent.blur(deviceTextBox, { target: { value: '35066964374936' } });
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
    // expect(deviceTextBox).toHaveValue('35066964374936');
  });

  test('it should render handleChangeDeviceID', () => {
    const handleChangeDeviceID = screen.getByTestId('handleChangeDeviceID');
    expect(handleChangeDeviceID).toBeInTheDocument();
    fireEvent.click(handleChangeDeviceID);
  });
  test('DeviceScan component should render', () => {
    const testid = screen.getByRole('textbox');
    fireEvent.change(testid, { target: { value: '4567' } });
    fireEvent.blur(testid, { target: { value: '4567' } });
  });
});
describe('DeviceScan component 2nd time', () => {
  setUserAgentIPad();
  const props = {
    setRepSelectedSimType: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    ivrDeviceId: true,
    handleChangeDeviceIDs: jest.fn(),
    LineDeviceId: '4567',
    isPdpPage: true,
    showScanner: true,
    selectedDeviceId: true,
    isIndirect: true,
    isRfexFlow: true,
    lineActivityType: 'CCH',
    ScanFromLanding: true,
    isDeviceFromCart: true,
    activeMtn: '8482470044',
    SecNumFlow: true,
    primaryMtnofSecondNumber: '8482470044',
    imeiOfPrimaryMtn: {
      pairedImei: '3659365923650',
    },
    isSelectedDevice: true,
    cartDetails: {
      lineInfo: [
        {
          mobileNumber: '8482470044',
          deviceTypeSelected: '5G Internet',
        },
      ],
      featureFlags: {
        posSNDeviceIdFixFFlag: true,
      },
    },
    CustomerData: {
      qualificationDetails: {
        fiveGHomebundle: [
          {
            bundleName: 'Gen4',
          },
        ],
        fiveGHomeQualified: true,
      },
      homeSalesAddress: {
        bundles: [],
      },
      channel: 'OMNI-RETAIL',
      billAccounts: [
        {
          mtns: [],
        },
      ],
    },
    validateDeviceSimIdRequest: jest.fn(),
    isPDPMFEEnabledTS: 'TRUE',
    isDeviceInputDisabled: jest.fn(),
  };
  const handlers = [
    rest.post(`*/flexV2/deviceInventoryStatusCheck`, (req, res, ctx) => {
      console.log('inside /flexV2/deviceInventoryStatusCheck');
      return res(ctx.status(500), ctx.json({ data: { isDeviceAvailableInStoreInventory: false }, status: 'rejected' }));
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    sessionStorage.getItem('Qualification_type', 'MMW');
    sessionStorage.setItem('isPearl', 'true');
    sessionStorage.setItem('APP_PROPERTIES', '{"blockLocalInventoryRetailBYOD": "TRUE", "pearlBYODFlow": "TRUE"}');
    render(<DeviceScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('it should render handleChangeDeviceID', () => {
    const handleChangeDeviceID = screen.getByTestId('handleChangeDeviceID');
    expect(handleChangeDeviceID).toBeInTheDocument();
    fireEvent.click(handleChangeDeviceID);
  });
  test('DeviceScan component should render', () => {
    const testid = screen.getAllByRole('textbox')[0];
    fireEvent.change(testid, { target: { value: '4567' } });
    fireEvent.change(testid, { target: { value: '4567456745674567' } });
    fireEvent.blur(testid, { target: { value: '4567456745674567' } });
  });

  test('DeviceScan component should render with handleDeviceChangeID func return', () => {
    const testid = screen.getAllByRole('textbox')[0];
    fireEvent.change(testid, { target: { value: '4567' } });
    fireEvent.blur(testid, { target: { value: '4567' } });
  });

  test('isFullFillment testing', async () => {
    jest.setTimeout(20000);
    const isFullFillment = screen.getByTestId('isFullFillment');
    expect(isFullFillment).toBeInTheDocument();
    fireEvent.keyPress(isFullFillment, { key: 'Enter', charCode: 32 });
    fireEvent.click(isFullFillment);
  });
});
describe('DeviceScan component 2nd time testing simIdScanner', () => {
  setUserAgentIPad();
  const props = {
    ivrDeviceId: true,
    setRepSelectedSimType: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    handleChangeDeviceIDs: jest.fn(),
    LineDeviceId: '4567',
    isPdpPage: true,
    showScanner: true,
    selectedDeviceId: true,
    isIndirect: true,
    isRfexFlow: true,
    lineActivityType: 'CCH',
    ScanFromLanding: true,
    isDeviceFromCart: false,
    activeMtn: '8482470044',
    SecNumFlow: true,
    primaryMtnofSecondNumber: '8482470044',
    imeiOfPrimaryMtn: {
      pairedImei: '3659365923650',
    },
    isSelectedDevice: false,
    cartDetails: {
      lineInfo: [
        {
          mobileNumber: '8482470044',
          deviceTypeSelected: '5G Internet',
        },
      ],
    },
    CustomerData: {
      qualificationDetails: {
        fiveGHomebundle: [
          {
            bundleName: 'Gen4',
          },
        ],
        fiveGHomeQualified: true,
      },
      homeSalesAddress: {},
      channel: 'OMNI-RETAIL',
      billAccounts: [
        {
          mtns: [
            {
              mtn: '12345',
            },
          ],
        },
      ],
    },
    validateDeviceSimIdRequest: jest.fn(),
    isPDPMFEEnabledTS: 'TRUE',
    isDeviceInputDisabled: jest.fn(),
  };
  const handlers = [
    rest.post(`*/flexV2/deviceInventoryStatusCheck`, (req, res, ctx) => {
      console.log('inside /flexV2/deviceInventoryStatusCheck');
      return res(
        ctx.status(200),
        ctx.json({ data: { data: { data: { isDeviceAvailableInStoreInventory: false } } }, status: 'fulfilled' }),
      );
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    sessionStorage.getItem('Qualification_type', 'MMW');
    sessionStorage.setItem('isPearl', 'true');
    sessionStorage.setItem('APP_PROPERTIES', '{"blockLocalInventoryRetailBYOD": "TRUE", "pearlBYODFlow": "TRUE"}');
    render(<DeviceScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('simIdScanner testing', async () => {
    jest.setTimeout(20000);
    const simIDScanner = await screen.findByTestId('simIDScanner');
    expect(simIDScanner).toBeInTheDocument();
    fireEvent.keyPress(simIDScanner, { key: 'Enter', charCode: 32 });
    fireEvent.click(simIDScanner);
    // waitFor(() => expect(props.scanDeviceIdBarCode).toHaveBeenCalled());
    // await new Promise((r) => setTimeout(r, 101));
    const simIdInput = await screen.findByTestId('SimId-Input-element');
    expect(simIdInput).toBeInTheDocument();
    fireEvent.change(simIdInput, { target: { value: '' } });
    fireEvent.blur(simIdInput, { target: { value: '' } });
    fireEvent.change(simIdInput, { target: { value: '4567456745674567123' } });
    fireEvent.blur(simIdInput);
  });
});
describe('DeviceScan component 2nd time', () => {
  const props = {
    ivrDeviceId: true,
    setRepSelectedSimType: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    handleChangeDeviceIDs: jest.fn(),
    LineDeviceId: '4567',
    isPdpPage: true,
    showScanner: true,
    selectedDeviceId: true,
    isIndirect: true,
    isRfexFlow: true,
    lineActivityType: 'CCH',
    ScanFromLanding: true,
    isDeviceFromCart: false,
    activeMtn: '8482470044',
    cartDetails: {
      lineInfo: [
        {
          mobileNumber: '8482470044',
          deviceTypeSelected: '5G Internet',
        },
      ],
    },
    CustomerData: {
      qualificationDetails: {
        fiveGHomebundle: [
          {
            bundleName: 'Gen4',
          },
        ],
        fiveGHomeQualified: true,
      },
      homeSalesAddress: {
        bundles: [],
      },
      channel: 'OMNI-RETAIL',
      billAccounts: [
        {
          mtns: [
            {
              mtn: '12345',
            },
          ],
        },
      ],
    },
    validateDeviceSimIdRequest: jest.fn(),
    isPDPMFEEnabledTS: 'TRUE',
    isDeviceInputDisabled: jest.fn(),
    fromCpe: true,
    fromInterim: true,
    isDWOS: true,
    isCustomerProvidedEquipment: true,
  };
  const handlers = [
    rest.post(`*/flexV2/deviceInventoryStatusCheck`, (req, res, ctx) => {
      console.log('inside /flexV2/deviceInventoryStatusCheck');
      return res(
        ctx.status(200),
        ctx.json({ data: { data: { data: { isDeviceAvailableInStoreInventory: false } } }, status: 'fulfilled' }),
      );
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    sessionStorage.getItem('Qualification_type', 'MMW');
    sessionStorage.setItem('isPearl', 'true');
    sessionStorage.setItem('APP_PROPERTIES', '{"blockLocalInventoryRetailBYOD": "TRUE", "pearlBYODFlow": "TRUE"}');
    render(<DeviceScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('it should render handleChangeDeviceID', () => {
    const handleChangeDeviceID = screen.getByTestId('handleChangeDeviceID');
    expect(handleChangeDeviceID).toBeInTheDocument();
    fireEvent.click(handleChangeDeviceID);
  });
  test('DeviceScan component should render', () => {
    const testid = screen.getAllByRole('textbox')[0];
    fireEvent.change(testid, { target: { value: '4567' } });
    fireEvent.change(testid, { target: { value: '4567456745674567' } });
    fireEvent.blur(testid, { target: { value: '4567456745674567' } });
  });

  test('DeviceScan component should render with handleDeviceChangeID func return', () => {
    const testid = screen.getAllByRole('textbox')[0];
    fireEvent.change(testid, { target: { value: '4567' } });
    fireEvent.blur(testid, { target: { value: '4567' } });
  });

  test('isFullFillment testing', async () => {
    const isFullFillment = screen.getByTestId('isFullFillment');
    expect(isFullFillment).toBeInTheDocument();
    fireEvent.keyPress(isFullFillment, { key: 'Enter', charCode: 13 });
    fireEvent.click(isFullFillment);
    const simIDScanner = await screen.findByTestId('simIDScanner');
    expect(simIDScanner).toBeInTheDocument();
    fireEvent.keyPress(simIDScanner, { key: 'Enter', charCode: 13 });
    fireEvent.click(simIDScanner);

    const simIdInput = await screen.findByTestId('SimId-Input-element');
    expect(simIdInput).toBeInTheDocument();
    fireEvent.change(simIdInput, { target: { value: '' } });
    fireEvent.blur(simIdInput, { target: { value: '' } });
    fireEvent.change(simIdInput, { target: { value: '4567456745674567123' } });
    fireEvent.blur(simIdInput);
  });
});

describe('DeviceScan component for handleOnBlurDeviceID function test', () => {
  const props = {
    isFiveG: false,
    ivrDeviceId: true,
    setRepSelectedSimType: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    handleChangeDeviceIDs: jest.fn(),
    LineDeviceId: '4567456745674567',
    isPdpPage: false,
    showScanner: true,
    selectedDeviceId: true,
    isIndirect: true,
    isRfexFlow: true,
    lineActivityType: 'CCH',
    ScanFromLanding: true,
    isDeviceFromCart: false,
    activeMtn: '8482470044',
    cartDetails: {
      lineInfo: [
        {
          mobileNumber: '8482470044',
          deviceTypeSelected: '5G Internet',
        },
      ],
    },
    CustomerData: {
      qualificationDetails: {
        fiveGHomebundle: [
          {
            bundleName: 'Gen4',
          },
        ],
        fiveGHomeQualified: true,
      },
      homeSalesAddress: {
        bundles: [],
      },
      channel: 'OMNI-RETAIL',
      billAccounts: [
        {
          mtns: [
            {
              mtn: '12345',
            },
          ],
        },
      ],
    },
    validateDeviceSimIdRequest: jest.fn(),
    isPDPMFEEnabledTS: 'TRUE',
    isDeviceInputDisabled: jest.fn(),
  };
  const handlers = [
    rest.post(`*/flexV2/deviceInventoryStatusCheck`, (req, res, ctx) => {
      console.log('inside /flexV2/deviceInventoryStatusCheck');
      return res(
        ctx.status(200),
        ctx.json({ data: { data: { data: { isDeviceAvailableInStoreInventory: false } } }, status: 'fulfilled' }),
      );
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    sessionStorage.getItem('Qualification_type', 'MMW');
    sessionStorage.setItem('isPearl', 'true');
    sessionStorage.setItem('APP_PROPERTIES', '{"blockLocalInventoryRetailBYOD": "TRUE", "pearlBYODFlow": "TRUE"}');
    render(<DeviceScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('handleOnBlurDeviceID testings should throw warning when value is empty string', () => {
    const testid = screen.getAllByRole('textbox')[0];
    fireEvent.change(testid, { target: { value: '' } });
    fireEvent.blur(testid, { target: { value: '' } });
    expect(screen.getByText('Please scan or enter a valid device ID')).toBeInTheDocument();
  });
  test('handleOnBlurDeviceID testings', () => {
    const testid = screen.getAllByRole('textbox')[0];
    fireEvent.change(testid, { target: { value: '4567' } });
    fireEvent.change(testid, { target: { value: '4567456745674567' } });
    fireEvent.blur(testid, { target: { value: '4567456745674567' } });
  });
  test('test deviceIdBarCodeScannerCallback ', () => {
    const data4 = { dataset: { barcode: '{"GENERIC":true}' } };
    window.deviceIdBarCodeScannerCallback(data4);
  });
  test('test deviceIdBarCodeScannerCallback ', () => {
    const data5 = { dataset: { barcode: '{"MEID":true}' } };
    window.deviceIdBarCodeScannerCallback(data5);
  });
  test('test deviceIdBarCodeScannerCallback ', () => {
    const data5 = { dataset: { barcode: '{"MEID":true,"ICCID":true}' } };
    window.deviceIdBarCodeScannerCallback(data5);
  });
  test('test deviceIdBarCodeScannerCallback ', () => {
    const data6 = { dataset: { barcode: 'cancel' } };
    window.deviceIdBarCodeScannerCallback(data6);
  });
});
describe('DeviceScan component for handleOnBlurDeviceID function test', () => {
  setUserAgentIPad();
  const props = {
    isFiveG: false,
    ivrDeviceId: true,
    setRepSelectedSimType: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    handleChangeDeviceIDs: jest.fn(),
    LineDeviceId: '4567456745674567',
    isPdpPage: false,
    showScanner: true,
    selectedDeviceId: true,
    isIndirect: true,
    isRfexFlow: true,
    lineActivityType: 'CCH',
    ScanFromLanding: true,
    isDeviceFromCart: false,
    activeMtn: '8482470044',
    cartDetails: {
      lineInfo: [
        {
          mobileNumber: '8482470044',
          deviceTypeSelected: '5G Internet',
        },
      ],
    },
    CustomerData: {
      qualificationDetails: {
        fiveGHomebundle: [
          {
            bundleName: 'Gen4',
          },
        ],
        fiveGHomeQualified: true,
      },
      homeSalesAddress: {
        bundles: [],
      },
      channel: 'OMNI-RETAIL',
      billAccounts: [
        {
          mtns: [
            {
              mtn: '12345',
            },
          ],
        },
      ],
    },
    validateDeviceSimIdRequest: jest.fn(),
    isPDPMFEEnabledTS: 'TRUE',
    isDeviceInputDisabled: jest.fn(),
  };
  const handlers = [
    rest.post(`*/flexV2/deviceInventoryStatusCheck`, (req, res, ctx) => {
      console.log('inside /flexV2/deviceInventoryStatusCheck');
      return res(
        ctx.status(200),
        ctx.json({ data: { data: { data: { isDeviceAvailableInStoreInventory: true } } }, status: 'fulfilled' }),
      );
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    sessionStorage.getItem('Qualification_type', 'MMW');
    sessionStorage.setItem('isPearl', 'true');
    sessionStorage.setItem('APP_PROPERTIES', '{"blockLocalInventoryRetailBYOD": "TRUE", "pearlBYODFlow": "TRUE"}');
    render(<DeviceScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('handleOnBlurDeviceID testings', () => {
    const testid = screen.getAllByRole('textbox')[0];
    fireEvent.change(testid, { target: { value: '4567' } });
    fireEvent.change(testid, { target: { value: '4567456745674567' } });
    fireEvent.blur(testid, { target: { value: '4567456745674567' } });
  });
  test('test deviceIdBarCodeScannerCallback ', () => {
    const data = { dataset: { barcode: '{"GENERIC":true}' } };
    window.deviceIdBarCodeScannerCallback(data);
  });
  test('test deviceIdBarCodeScannerCallback ', () => {
    const data1 = { dataset: { barcode: '{"MEID":true}' } };
    window.deviceIdBarCodeScannerCallback(data1);
  });
  test('test deviceIdBarCodeScannerCallback ', () => {
    const data2 = { dataset: { barcode: 'cancel' } };
    window.deviceIdBarCodeScannerCallback(data2);
  });
});

describe('DeviceScan component', () => {
  const props = {
    ivrDeviceId: true,
    setRepSelectedSimType: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    handleChangeDeviceIDs: jest.fn(),
    LineDeviceId: '4567',
    isPdpPage: false,
    lineActivityType: 'PAD',
    isIndirect: false,
    isRfexFlow: true,
    ScanFromLanding: false,
    isprepaycart: true,
    isFiveG: true,
    activeMtn: '8482470044',
    cartDetails: {
      lineInfo: [
        {
          mobileNumber: '8482470044',
          deviceTypeSelected: '5G Internet',
        },
      ],
    },
    CustomerData: {
      qualificationDetails: {
        fiveGHomebundle: [
          {
            bundleName: 'Gen4',
          },
        ],
        cBandQualified: true,
      },
      homeSalesAddress: {
        bundles: [],
      },
      channel: 'OMNI-RETAIL',
      billAccounts: [
        {
          mtns: [
            {
              mtn: '12345',
            },
          ],
        },
      ],
    },
    validateDeviceSimIdRequest: jest.fn(),
    isPDPMFEEnabledTS: 'TRUE',
    isDeviceInputDisabled: jest.fn(),
  };
  const handlers = [
    rest.post(`*/flexV2/deviceInventoryStatusCheck`, (req, res, ctx) => {
      console.log('inside /flexV2/deviceInventoryStatusCheck');
      return res(
        ctx.status(200),
        ctx.json({ data: { data: { data: { isDeviceAvailableInStoreInventory: false } } }, status: 'fulfilled' }),
      );
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    sessionStorage.getItem('Qualification_type', 'CBD');
    sessionStorage.setItem('isPearl', 'true');
    sessionStorage.setItem('APP_PROPERTIES', '{"blockLocalInventoryRetailBYOD": "TRUE", "pearlBYODFlow": "TRUE"}');
    render(<DeviceScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('it should render handleChangeDeviceID', () => {
    const handleChangeDeviceID = screen.getByTestId('handleChangeDeviceID');
    expect(handleChangeDeviceID).toBeInTheDocument();
    fireEvent.click(handleChangeDeviceID);
  });
});

describe('DeviceScan component for handleOnBlurDeviceID function test', () => {
  const props = {
    isFiveG: true,
    ivrDeviceId: true,
    setRepSelectedSimType: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    handleChangeDeviceIDs: jest.fn(),
    LineDeviceId: '4567456745674567',
    isPdpPage: false,
    showScanner: true,
    selectedDeviceId: true,
    lineActivityType: 'PAD',

    isIndirect: true,
    isRfexFlow: true,
    deviceError: false,
    ScanFromLanding: false,
    isPDPMFEEnabledTS: 'TRUE',
    isDeviceInputDisabled: jest.fn(),
    isDeviceFromCart: true,
    activeMtn: '8482470044',
    cartDetails: {
      lineInfo: [
        {
          mobileNumber: '8482470044',
          deviceTypeSelected: '5G Internet',
        },
      ],
    },
    CustomerData: {
      qualificationDetails: {
        fiveGHomebundle: [
          {
            bundleName: 'Gen4',
          },
        ],
        fiveGHomeQualified: true,
      },
      homeSalesAddress: {
        bundles: [],
      },
      channel: 'OMNI-RETAIL',
      billAccounts: [
        {
          mtns: [
            {
              mtn: '12345',
            },
          ],
        },
      ],
    },
    isFromPDPPage: true,
    isNewlyAddedLine: true,
    isByodUpdate: true,
    validateDeviceSimIdRequest: jest.fn(),
  };
  const handlers = [
    rest.post(`*/flexV2/deviceInventoryStatusCheck`, (req, res, ctx) => {
      console.log('inside /flexV2/deviceInventoryStatusCheck');
      return res(
        ctx.status(200),
        ctx.json({ data: { data: { data: { isDeviceAvailableInStoreInventory: false } } }, status: 'fulfilled' }),
      );
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    sessionStorage.getItem('Qualification_type', 'MMW');
    sessionStorage.setItem('isPearl', 'true');
    sessionStorage.setItem('APP_PROPERTIES', '{"blockLocalInventoryRetailBYOD": "TRUE", "pearlBYODFlow": "TRUE"}');
    render(<DeviceScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('handleOnBlurDeviceID testings', () => {
    const testid = screen.getAllByRole('textbox')[0];
    fireEvent.change(testid, { target: { value: '4567' } });
    fireEvent.change(testid, { target: { value: '4567456745674567' } });
    fireEvent.blur(testid, { target: { value: '4567456745674567' } });
  });
});
describe('DeviceScan component 2nd time', () => {
  setUserAgentIPad();
  const props = {
    setRepSelectedSimType: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    ivrDeviceId: true,
    handleChangeDeviceIDs: jest.fn(),
    LineDeviceId: '4567',
    isPdpPage: true,
    showScanner: true,
    selectedDeviceId: true,
    isIndirect: true,
    isRfexFlow: true,
    lineActivityType: 'CCH',
    ScanFromLanding: true,
    isDeviceFromCart: true,
    activeMtn: '8482470044',
    SecNumFlow: true,
    primaryMtnofSecondNumber: '8482470044',
    isSelectedDevice: true,
    cartDetails: {
      cart: {
        lineDetails: {
          lineInfo: [
            {
              mobileNumber: '8482470044',
              deviceTypeSelected: '5G Internet',
            },
          ],
        },
      },
    },
    CustomerData: {
      qualificationDetails: {
        fiveGHomebundle: [
          {
            bundleName: 'Gen4',
          },
        ],
        fiveGHomeQualified: true,
      },
      homeSalesAddress: {
        bundles: [],
      },
      channel: 'OMNI-RETAIL',
      billAccounts: [
        {
          mtns: [
            {
              mtn: '12345',
            },
          ],
        },
      ],
    },
    validateDeviceSimIdRequest: jest.fn(),
    isPDPMFEEnabledTS: 'TRUE',
    isDeviceInputDisabled: jest.fn(),
  };
  const handlers = [
    rest.post(`*/flexV2/deviceInventoryStatusCheck`, (req, res, ctx) => {
      console.log('inside /flexV2/deviceInventoryStatusCheck');
      return res(
        ctx.status(200),
        ctx.json({ data: { data: { data: { isDeviceAvailableInStoreInventory: true } } }, status: 'fulfilled' }),
      );
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    sessionStorage.getItem('Qualification_type', 'MMW');
    sessionStorage.setItem('secondNumber', true);
    sessionStorage.setItem('isPearl', 'true');
    sessionStorage.setItem('APP_PROPERTIES', '{"blockLocalInventoryRetailBYOD": "TRUE", "pearlBYODFlow": "TRUE"}');
    render(<DeviceScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('it should render handleChangeDeviceID', () => {
    const handleChangeDeviceID = screen.getByTestId('handleChangeDeviceID');
    expect(handleChangeDeviceID).toBeInTheDocument();
    fireEvent.click(handleChangeDeviceID);
  });
});

describe('DeviceScan component for handleOnBlurDeviceID function test with ACSS', () => {
  const props = {
    isFiveG: true,
    ivrDeviceId: true,
    setRepSelectedSimType: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    handleChangeDeviceIDs: jest.fn(),
    LineDeviceId: '4567456745674567',
    isPdpPage: false,
    showScanner: true,
    selectedDeviceId: true,
    lineActivityType: 'PAD',

    isIndirect: true,
    isRfexFlow: true,
    deviceError: false,
    ScanFromLanding: false,
    isPDPMFEEnabledTS: 'TRUE',
    isDeviceInputDisabled: jest.fn(),
    isDeviceFromCart: true,
    activeMtn: '8482470044',
    cartDetails: {
      lineInfo: [
        {
          mobileNumber: '8482470044',
          deviceTypeSelected: '5G Internet',
        },
      ],
    },
    CustomerData: {
      qualificationDetails: {
        fiveGHomebundle: [
          {
            bundleName: 'Gen4',
          },
        ],
        fiveGHomeQualified: true,
      },
      homeSalesAddress: {
        bundles: [],
      },
      channel: 'OMNI-RETAIL',
      billAccounts: [
        {
          mtns: [
            {
              mtn: '12345',
            },
          ],
        },
      ],
    },
    isFromPDPPage: true,
    isNewlyAddedLine: true,
    isByodUpdate: true,
    validateDeviceSimIdRequest: jest.fn(),
    isDisabled: false,
  };
  const handlers = [
    rest.post(`*/flexV2/deviceInventoryStatusCheck`, (req, res, ctx) => {
      console.log('inside /flexV2/deviceInventoryStatusCheck');
      return res(
        ctx.status(200),
        ctx.json({ data: { data: { data: { isDeviceAvailableInStoreInventory: false } } }, status: 'fulfilled' }),
      );
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    window.mfe = { scmDeviceMfeEnable: true };
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    sessionStorage.getItem('Qualification_type', 'MMW');
    render(<DeviceScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('handleOnBlurDeviceID testings', () => {
    const testid = screen.getAllByRole('textbox')[0];
    fireEvent.change(testid, { target: { value: '4567' } });
    fireEvent.change(testid, { target: { value: '4567456745674567' } });
    fireEvent.blur(testid, { target: { value: '4567456745674567' } });
  });
});

describe('DeviceScan component', () => {
  setUserAgentIPad();
  const props = {
    setRepSelectedSimType: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    ivrDeviceId: true,
    handleChangeDeviceIDs: jest.fn(),
    LineDeviceId: '4567',
    isPdpPage: false,
    lineActivityType: 'PAD',
    isIndirect: true,
    isRfexFlow: true,
    ScanFromLanding: false,
    isprepaycart: true,
    isFiveG: true,
    activeMtn: '8482470044',
    cartDetails: {
      lineInfo: [
        {
          mobileNumber: '8482470044',
          deviceTypeSelected: '5G Internet',
        },
      ],
    },
    CustomerData: {
      qualificationDetails: {},
      homeSalesAddress: {
        bundles: [],
      },
      channel: 'OMNI-RETAIL',
      billAccounts: [
        {
          mtns: [
            {
              mtn: '12345',
            },
          ],
        },
      ],
    },
    validateDeviceSimIdRequest: jest.fn(),
    isPDPMFEEnabledTS: 'TRUE',
    isNewlyAddedLine: false,
    isDeviceInputDisabled: jest.fn(),
  };
  const handlers = [
    rest.post(`*/flexV2/deviceInventoryStatusCheck`, (req, res, ctx) => {
      console.log('inside /flexV2/deviceInventoryStatusCheck');
      return res(
        ctx.status(200),
        ctx.json({ data: { data: { data: { isDeviceAvailableInStoreInventory: true } } }, status: 'fulfilled' }),
      );
    }),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
    window.mfe = { scmDeviceMfeEnable: true, isDark: true, isProspectNewCustomerTab: true };
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    sessionStorage.setItem('enableSimValidation', 'false');
    sessionStorage.setItem('refundexchange', 'false');

    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    sessionStorage.setItem('isPearl', 'true');
    sessionStorage.setItem('APP_PROPERTIES', '{"blockLocalInventoryRetailBYOD": "TRUE", "pearlBYODFlow": "TRUE"}');
    sessionStorage.getItem('Qualification_type', 'CBD');
    render(<DeviceScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('Find by DeviceId text', () => {
    const deviceIdText = screen.getByTestId('handleChangeDeviceID');
    expect(deviceIdText).toBeInTheDocument();
  });

  test('Device Scan testing by entering device Id', async () => {
    const deviceTextBox = await screen.getByTestId('handleChangeDeviceID');
    expect(deviceTextBox).toBeInTheDocument();

    fireEvent.change(deviceTextBox, { target: { value: '350669643749367' } });
    fireEvent.blur(deviceTextBox, { target: { value: '350669643749367' } });
  });
});

describe('DeviceScan component for handleOnBlurDeviceID - fraud risk validation without auth', () => {
  const props = {
    simSwapNotify: 'Y',
    enableEnforceApi: 'Y',
    setDeviceInput: jest.fn(),
    deviceInput: '4567456745674567',
    simSkuInput: '123',
    isFiveG: true,
    ivrDeviceId: true,
    setRepSelectedSimType: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    handleChangeDeviceIDs: jest.fn(),
    LineDeviceId: '3567456745674567',
    isPdpPage: false,
    showScanner: true,
    selectedDeviceId: true,
    lineActivityType: 'PAD',

    isIndirect: true,
    isRfexFlow: true,
    deviceError: false,
    ScanFromLanding: false,
    isPDPMFEEnabledTS: 'TRUE',
    isDeviceInputDisabled: jest.fn(),
    isDeviceFromCart: true,
    activeMtn: '8482470044',
    cartDetails: {
      lineInfo: [
        {
          mobileNumber: '8482470044',
          deviceTypeSelected: '5G Internet',
        },
      ],
    },
    CustomerData: {
      qualificationDetails: {
        fiveGHomebundle: [
          {
            bundleName: 'Gen4',
          },
        ],
        fiveGHomeQualified: true,
      },
      homeSalesAddress: {
        bundles: [],
      },
      channel: 'OMNI-RETAIL',
      billAccounts: [
        {
          mtns: [
            {
              mtn: '12345',
            },
          ],
        },
      ],
    },
    isFromPDPPage: true,
    isNewlyAddedLine: false,
    isByodUpdate: true,
    validateDeviceSimIdRequest: jest.fn(),
  };
  const handlers = [
    rest.post(`*/flexV2/deviceInventoryStatusCheck`, (req, res, ctx) => {
      console.log('inside /flexV2/deviceInventoryStatusCheck');
      return res(
        ctx.status(200),
        ctx.json({ data: { data: { data: { isDeviceAvailableInStoreInventory: false } } }, status: 'fulfilled' }),
      );
    }),
    rest.post(`*/cpc/fraudRiskScore`, (req, res, ctx) =>
      res(
        ctx.status(200),
        ctx.json({
          responseInfo: {
            errors: [],
            timeStamp: '15-11-2024 05:12:07',
            correlationId: 'smock_enforce_test',
            responseCode: '00',
            responseMessage: 'SUCCESS',
          },
          data: {
            sessionId: 'fcce4b0e-cbe3-4912-bcf0-9c7f4c671537',
            custId: '0725665601',
            acctNum: '1',
            fraudRiskScore: '0',
            fraudRiskLevel: 'High Risk',
            loa: '0',
            mdn: '2153709209',
            notificationIndicator: 'Y',
            invokeIdScan: 'N',
          },
          status: 'fulfilled',
        }),
      ),
    ),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    window.mfe = { scmDeviceMfeEnable: true };
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    sessionStorage.getItem('Qualification_type', 'MMW');
    sessionStorage.setItem('isPearl', 'true');
    sessionStorage.setItem('APP_PROPERTIES', '{"blockLocalInventoryRetailBYOD": "TRUE", "pearlBYODFlow": "TRUE"}');
    sessionStorage.setItem('enableSimValidation', 'false');
    render(<DeviceScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('handleOnBlurDeviceID testings', async () => {
    const testid = screen.getByTestId('handleChangeDeviceID');
    fireEvent.change(testid, { target: { value: '4567' } });
    fireEvent.change(testid, { target: { value: '4567456745674567' } });
    fireEvent.blur(testid, { target: { value: '4567456745674567' } });
    await new Promise((res) => {
      setTimeout(res, 3000);
    });
  });
});

describe('DeviceScan component for handleOnBlurDeviceID - fraud risk validation error without auth', () => {
  const props = {
    simSwapNotify: 'Y',
    enableEnforceApi: 'Y',
    setDeviceInput: jest.fn(),
    deviceInput: '4567456745674567',
    simSkuInput: '123',
    isFiveG: true,
    ivrDeviceId: true,
    setRepSelectedSimType: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    handleChangeDeviceIDs: jest.fn(),
    LineDeviceId: '3567456745674567',
    isPdpPage: false,
    showScanner: true,
    selectedDeviceId: true,
    lineActivityType: 'PAD',

    isIndirect: true,
    isRfexFlow: true,
    deviceError: false,
    ScanFromLanding: false,
    isPDPMFEEnabledTS: 'TRUE',
    isDeviceInputDisabled: jest.fn(),
    isDeviceFromCart: true,
    activeMtn: '8482470044',
    cartDetails: {
      lineInfo: [
        {
          mobileNumber: '8482470044',
          deviceTypeSelected: '5G Internet',
        },
      ],
    },
    CustomerData: {
      qualificationDetails: {
        fiveGHomebundle: [
          {
            bundleName: 'Gen4',
          },
        ],
        fiveGHomeQualified: true,
      },
      homeSalesAddress: {
        bundles: [],
      },
      channel: 'OMNI-RETAIL',
      billAccounts: [
        {
          mtns: [
            {
              mtn: '12345',
            },
          ],
        },
      ],
    },
    isFromPDPPage: true,
    isNewlyAddedLine: false,
    isByodUpdate: true,
    validateDeviceSimIdRequest: jest.fn(),
  };
  const handlers = [
    rest.post(`*/flexV2/deviceInventoryStatusCheck`, (req, res, ctx) => {
      console.log('inside /flexV2/deviceInventoryStatusCheck');
      return res(
        ctx.status(200),
        ctx.json({ data: { data: { data: { isDeviceAvailableInStoreInventory: false } } }, status: 'fulfilled' }),
      );
    }),
    rest.post(`*/cpc/fraudRiskScore`, (req, res, ctx) =>
      res(
        ctx.status(200),
        ctx.json({
          responseInfo: {
            errors: [
              {
                externalErrorCode: '74',
                externalErrorMessage: '500null',
                apiName: 'refSimSwapService',
                system: 'CXPREST',
                errorHolder: {},
              },
            ],
            timeStamp: '13-12-2024 02:25:44',
            correlationId: '9ce78c5a-46f1-426e-88c7-5e7e1c066bdb',
            responseCode: '99',
            responseMessage: 'FAILURE',
          },
          data: {},
          status: 'fulfilled',
        }),
      ),
    ),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    window.mfe = { scmDeviceMfeEnable: true };
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    sessionStorage.getItem('Qualification_type', 'MMW');
    sessionStorage.setItem('isPearl', 'true');
    sessionStorage.setItem('APP_PROPERTIES', '{"blockLocalInventoryRetailBYOD": "TRUE", "pearlBYODFlow": "TRUE"}');
    sessionStorage.setItem('enableSimValidation', 'false');
    render(<DeviceScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('handleOnBlurDeviceID testings', async () => {
    const testid = screen.getByTestId('handleChangeDeviceID');
    fireEvent.change(testid, { target: { value: '4567' } });
    fireEvent.change(testid, { target: { value: '4567456745674567' } });
    fireEvent.blur(testid, { target: { value: '4567456745674567' } });
    await new Promise((res) => {
      setTimeout(res, 5000);
    });
  }, 7000);
});

describe('DeviceScan component for handleOnBlurDeviceID - fraud risk validation with auth', () => {
  const props = {
    simSwapNotify: 'Y',
    enableEnforceApi: 'Y',
    setDeviceInput: jest.fn(),
    deviceInput: '4567456745674567',
    simSkuInput: '123',
    isFiveG: true,
    ivrDeviceId: true,
    setRepSelectedSimType: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    handleChangeDeviceIDs: jest.fn(),
    LineDeviceId: '3567456745674567',
    isPdpPage: false,
    showScanner: true,
    selectedDeviceId: true,
    lineActivityType: 'PAD',

    isIndirect: true,
    isRfexFlow: true,
    deviceError: false,
    ScanFromLanding: false,
    isPDPMFEEnabledTS: 'TRUE',
    isDeviceInputDisabled: jest.fn(),
    isDeviceFromCart: true,
    activeMtn: '8482470044',
    cartDetails: {
      lineInfo: [
        {
          mobileNumber: '8482470044',
          deviceTypeSelected: '5G Internet',
        },
      ],
    },
    CustomerData: {
      qualificationDetails: {
        fiveGHomebundle: [
          {
            bundleName: 'Gen4',
          },
        ],
        fiveGHomeQualified: true,
      },
      homeSalesAddress: {
        bundles: [],
      },
      channel: 'OMNI-RETAIL',
      billAccounts: [
        {
          mtns: [
            {
              mtn: '12345',
            },
          ],
        },
      ],
    },
    isFromPDPPage: true,
    isNewlyAddedLine: false,
    isByodUpdate: true,
    validateDeviceSimIdRequest: jest.fn(),
  };
  const handlers = [
    rest.post(`*/flexV2/deviceInventoryStatusCheck`, (req, res, ctx) => {
      console.log('inside /flexV2/deviceInventoryStatusCheck');
      return res(
        ctx.status(200),
        ctx.json({ data: { data: { data: { isDeviceAvailableInStoreInventory: false } } }, status: 'fulfilled' }),
      );
    }),
    rest.post(`*/cpc/fraudRiskScore`, (req, res, ctx) =>
      res(
        ctx.status(200),
        ctx.json({
          responseInfo: {
            errors: [],
            timeStamp: '15-11-2024 05:12:07',
            correlationId: 'smock_enforce_test',
            responseCode: '00',
            responseMessage: 'SUCCESS',
          },
          data: {
            sessionId: 'fcce4b0e-cbe3-4912-bcf0-9c7f4c671537',
            custId: '0725665601',
            acctNum: '1',
            fraudRiskScore: '0',
            fraudRiskLevel: 'High Risk',
            loa: '0',
            mdn: '2153709209',
            notificationIndicator: 'Y',
            invokeIdScan: 'N',
          },
          status: 'fulfilled',
        }),
      ),
    ),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    window.mfe = { scmDeviceMfeEnable: true };
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    sessionStorage.getItem('Qualification_type', 'MMW');
    sessionStorage.setItem('isPearl', 'true');
    sessionStorage.setItem('APP_PROPERTIES', '{"blockLocalInventoryRetailBYOD": "TRUE", "pearlBYODFlow": "TRUE"}');
    sessionStorage.setItem('enableSimValidation', 'true');
    render(<DeviceScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('handleOnBlurDeviceID testings', async () => {
    const testid = screen.getByTestId('handleChangeDeviceID');
    fireEvent.change(testid, { target: { value: '4567' } });
    fireEvent.change(testid, { target: { value: '4567456745674567' } });
    fireEvent.blur(testid, { target: { value: '4567456745674567' } });
    await new Promise((res) => {
      setTimeout(res, 3000);
    });
  });
});

describe('DeviceScan component for handleOnBlurDeviceID - fraud risk validation with auth and isAAEnabledAAL true', () => {
  const props = {
    simSwapNotify: 'Y',
    enableEnforceApi: 'Y',
    setDeviceInput: jest.fn(),
    deviceInput: '4567456745674567',
    simSkuInput: '123',
    isFiveG: true,
    ivrDeviceId: true,
    setRepSelectedSimType: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    handleChangeDeviceIDs: jest.fn(),
    LineDeviceId: '3567456745674567',
    isPdpPage: false,
    showScanner: true,
    selectedDeviceId: true,
    lineActivityType: 'PAD',

    isIndirect: true,
    isRfexFlow: true,
    deviceError: false,
    ScanFromLanding: false,
    isPDPMFEEnabledTS: 'TRUE',
    isDeviceInputDisabled: jest.fn(),
    isDeviceFromCart: true,
    activeMtn: '8482470044',
    cartDetails: {
      lineInfo: [
        {
          mobileNumber: '8482470044',
          deviceTypeSelected: '5G Internet',
        },
      ],
    },
    CustomerData: {
      qualificationDetails: {
        fiveGHomebundle: [
          {
            bundleName: 'Gen4',
          },
        ],
        fiveGHomeQualified: true,
      },
      homeSalesAddress: {
        bundles: [],
      },
      channel: 'OMNI-RETAIL',
      billAccounts: [
        {
          mtns: [
            {
              mtn: '12345',
            },
          ],
        },
      ],
    },
    isFromPDPPage: true,
    isNewlyAddedLine: true,
    isByodUpdate: true,
    validateDeviceSimIdRequest: jest.fn(),
  };
  const handlers = [
    rest.post(`*/flexV2/deviceInventoryStatusCheck`, (req, res, ctx) => {
      console.log('inside /flexV2/deviceInventoryStatusCheck');
      return res(
        ctx.status(200),
        ctx.json({ data: { data: { data: { isDeviceAvailableInStoreInventory: false } } }, status: 'fulfilled' }),
      );
    }),
    rest.post(`*/cpc/fraudRiskScore`, (req, res, ctx) =>
      res(
        ctx.status(200),
        ctx.json({
          responseInfo: {
            errors: [],
            timeStamp: '15-11-2024 05:12:07',
            correlationId: 'smock_enforce_test',
            responseCode: '00',
            responseMessage: 'SUCCESS',
          },
          data: {
            sessionId: 'fcce4b0e-cbe3-4912-bcf0-9c7f4c671537',
            custId: '0725665601',
            acctNum: '1',
            fraudRiskScore: '0',
            fraudRiskLevel: 'High Risk',
            loa: '0',
            mdn: '2153709209',
            notificationIndicator: 'Y',
            invokeIdScan: 'N',
          },
          status: 'fulfilled',
        }),
      ),
    ),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    window.mfe = { scmDeviceMfeEnable: true, isAAEnabledAAL: true };
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    sessionStorage.getItem('Qualification_type', 'MMW');
    sessionStorage.setItem('isPearl', 'true');
    sessionStorage.setItem('APP_PROPERTIES', '{"blockLocalInventoryRetailBYOD": "TRUE", "pearlBYODFlow": "TRUE"}');
    sessionStorage.setItem('enableSimValidation', 'true');
    render(<DeviceScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('handleOnBlurDeviceID testings', async () => {
    const testid = screen.getByTestId('handleChangeDeviceID');
    fireEvent.change(testid, { target: { value: '4567' } });
    fireEvent.change(testid, { target: { value: '4567456745674567' } });
    fireEvent.blur(testid, { target: { value: '4567456745674567' } });
    await new Promise((res) => {
      setTimeout(res, 3000);
    });
  });
});


describe('DeviceScan component for handleOnBlurDeviceID - fraud risk validation with auth and isNotfnIndAA true', () => {
  const props = {
    simSwapNotify: 'Y',
    enableEnforceApi: 'Y',
    setDeviceInput: jest.fn(),
    deviceInput: '4567456745674567',
    simSkuInput: '123',
    isFiveG: true,
    ivrDeviceId: true,
    setRepSelectedSimType: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    handleChangeDeviceIDs: jest.fn(),
    LineDeviceId: '3567456745674567',
    isPdpPage: false,
    showScanner: true,
    selectedDeviceId: true,
    lineActivityType: 'PAD',

    isIndirect: true,
    isRfexFlow: true,
    deviceError: false,
    ScanFromLanding: false,
    isPDPMFEEnabledTS: 'TRUE',
    isDeviceInputDisabled: jest.fn(),
    isDeviceFromCart: true,
    activeMtn: '8482470044',
    cartDetails: {
      lineInfo: [
        {
          mobileNumber: '8482470044',
          deviceTypeSelected: '5G Internet',
        },
      ],
    },
    CustomerData: {
      qualificationDetails: {
        fiveGHomebundle: [
          {
            bundleName: 'Gen4',
          },
        ],
        fiveGHomeQualified: true,
      },
      homeSalesAddress: {
        bundles: [],
      },
      channel: 'OMNI-RETAIL',
      billAccounts: [
        {
          mtns: [
            {
              mtn: '12345',
            },
          ],
        },
      ],
    },
    isFromPDPPage: true,
    isNewlyAddedLine: true,
    isByodUpdate: true,
    validateDeviceSimIdRequest: jest.fn(),
  };
  const handlers = [
    rest.post(`*/flexV2/deviceInventoryStatusCheck`, (req, res, ctx) => {
      console.log('inside /flexV2/deviceInventoryStatusCheck');
      return res(
        ctx.status(200),
        ctx.json({ data: { data: { data: { isDeviceAvailableInStoreInventory: false } } }, status: 'fulfilled' }),
      );
    }),
    rest.post(`*/cpc/fraudRiskScore`, (req, res, ctx) =>
      res(
        ctx.status(200),
        ctx.json({
          responseInfo: {
            errors: [],
            timeStamp: '15-11-2024 05:12:07',
            correlationId: 'smock_enforce_test',
            responseCode: '00',
            responseMessage: 'SUCCESS',
          },
          data: {
            sessionId: 'fcce4b0e-cbe3-4912-bcf0-9c7f4c671537',
            custId: '0725665601',
            acctNum: '1',
            fraudRiskScore: '0',
            fraudRiskLevel: 'Low Risk',
            loa: '0',
            mdn: '2153709209',
            notificationIndicator: 'N',
            invokeIdScan: 'N',
          },
          status: 'fulfilled',
        }),
      ),
    ),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    window.mfe = { scmDeviceMfeEnable: true, isNotfnIndAA: true };
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    sessionStorage.getItem('Qualification_type', 'MMW');
    sessionStorage.setItem('isPearl', 'true');
    sessionStorage.setItem('APP_PROPERTIES', '{"blockLocalInventoryRetailBYOD": "TRUE", "pearlBYODFlow": "TRUE"}');
    sessionStorage.setItem('enableSimValidation', 'true');
    render(<DeviceScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('handleOnBlurDeviceID testings', async () => {
    const testid = screen.getByTestId('handleChangeDeviceID');
    fireEvent.change(testid, { target: { value: '4567' } });
    fireEvent.change(testid, { target: { value: '4567456745674567' } });
    fireEvent.blur(testid, { target: { value: '4567456745674567' } });
    await new Promise((res) => {
      setTimeout(res, 3000);
    });
  });
});

describe('DeviceScan component for handleOnBlurDeviceID - fraud risk validation error with auth', () => {
  const props = {
    simSwapNotify: 'Y',
    enableEnforceApi: 'Y',
    setDeviceInput: jest.fn(),
    deviceInput: '4567456745674567',
    simSkuInput: '123',
    isFiveG: true,
    ivrDeviceId: true,
    setRepSelectedSimType: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    handleChangeDeviceIDs: jest.fn(),
    LineDeviceId: '3567456745674567',
    isPdpPage: false,
    showScanner: true,
    selectedDeviceId: true,
    lineActivityType: 'PAD',

    isIndirect: true,
    isRfexFlow: true,
    deviceError: false,
    ScanFromLanding: false,
    isPDPMFEEnabledTS: 'TRUE',
    isDeviceInputDisabled: jest.fn(),
    isDeviceFromCart: true,
    activeMtn: '8482470044',
    cartDetails: {
      lineInfo: [
        {
          mobileNumber: '8482470044',
          deviceTypeSelected: '5G Internet',
        },
      ],
    },
    CustomerData: {
      qualificationDetails: {
        fiveGHomebundle: [
          {
            bundleName: 'Gen4',
          },
        ],
        fiveGHomeQualified: true,
      },
      homeSalesAddress: {
        bundles: [],
      },
      channel: 'OMNI-RETAIL',
      billAccounts: [
        {
          mtns: [
            {
              mtn: '12345',
            },
          ],
        },
      ],
    },
    isFromPDPPage: true,
    isNewlyAddedLine: false,
    isByodUpdate: true,
    validateDeviceSimIdRequest: jest.fn(),
  };
  const handlers = [
    rest.post(`*/flexV2/deviceInventoryStatusCheck`, (req, res, ctx) => {
      console.log('inside /flexV2/deviceInventoryStatusCheck');
      return res(
        ctx.status(200),
        ctx.json({ data: { data: { data: { isDeviceAvailableInStoreInventory: false } } }, status: 'fulfilled' }),
      );
    }),
    rest.post(`*/cpc/fraudRiskScore`, (req, res, ctx) =>
      res(
        ctx.status(200),
        ctx.json({
          responseInfo: {
            errors: [
              {
                externalErrorCode: '74',
                externalErrorMessage: '500null',
                apiName: 'refSimSwapService',
                system: 'CXPREST',
                errorHolder: {},
              },
            ],
            timeStamp: '13-12-2024 02:25:44',
            correlationId: '9ce78c5a-46f1-426e-88c7-5e7e1c066bdb',
            responseCode: '99',
            responseMessage: 'FAILURE',
          },
          data: {},
          status: 'fulfilled',
        }),
      ),
    ),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    window.mfe = { scmDeviceMfeEnable: true };
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    sessionStorage.getItem('Qualification_type', 'MMW');
    sessionStorage.setItem('isPearl', 'true');
    sessionStorage.setItem('APP_PROPERTIES', '{"blockLocalInventoryRetailBYOD": "TRUE", "pearlBYODFlow": "TRUE"}');
    sessionStorage.setItem('enableSimValidation', 'true');
    render(<DeviceScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('handleOnBlurDeviceID testings', async () => {
    const testid = screen.getByTestId('handleChangeDeviceID');
    fireEvent.change(testid, { target: { value: '4567' } });
    fireEvent.change(testid, { target: { value: '4567456745674567' } });
    fireEvent.blur(testid, { target: { value: '4567456745674567' } });
    await new Promise((res) => {
      setTimeout(res, 5000);
    });
  }, 7000);
});

describe('DeviceScan component for handleOnBlurDeviceID - fraud risk validation error with auth <rejected response>', () => {
  const props = {
    simSwapNotify: 'Y',
    enableEnforceApi: 'Y',
    setDeviceInput: jest.fn(),
    deviceInput: '4567456745674567',
    simSkuInput: '123',
    isFiveG: true,
    ivrDeviceId: true,
    setRepSelectedSimType: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    handleChangeDeviceIDs: jest.fn(),
    LineDeviceId: '3567456745674567',
    isPdpPage: false,
    showScanner: true,
    selectedDeviceId: true,
    lineActivityType: 'PAD',

    isIndirect: true,
    isRfexFlow: true,
    deviceError: false,
    ScanFromLanding: false,
    isPDPMFEEnabledTS: 'TRUE',
    isDeviceInputDisabled: jest.fn(),
    isDeviceFromCart: true,
    activeMtn: '8482470044',
    cartDetails: {
      lineInfo: [
        {
          mobileNumber: '8482470044',
          deviceTypeSelected: '5G Internet',
        },
      ],
    },
    CustomerData: {
      qualificationDetails: {
        fiveGHomebundle: [
          {
            bundleName: 'Gen4',
          },
        ],
        fiveGHomeQualified: true,
      },
      homeSalesAddress: {
        bundles: [],
      },
      channel: 'OMNI-RETAIL',
      billAccounts: [
        {
          mtns: [
            {
              mtn: '12345',
            },
          ],
        },
      ],
    },
    isFromPDPPage: true,
    isNewlyAddedLine: false,
    isByodUpdate: true,
    validateDeviceSimIdRequest: jest.fn(),
  };
  const handlers = [
    rest.post(`*/flexV2/deviceInventoryStatusCheck`, (req, res, ctx) => {
      console.log('inside /flexV2/deviceInventoryStatusCheck');
      return res(
        ctx.status(200),
        ctx.json({ data: { data: { data: { isDeviceAvailableInStoreInventory: false } } }, status: 'fulfilled' }),
      );
    }),
    rest.post(`*/cpc/fraudRiskScore`, (req, res, ctx) =>
      res(
        ctx.status(500),
        ctx.json({
          responseInfo: {
            errors: [
              {
                externalErrorCode: '74',
                externalErrorMessage: '500null',
                apiName: 'refSimSwapService',
                system: 'CXPREST',
                errorHolder: {},
              },
            ],
            timeStamp: '13-12-2024 02:25:44',
            correlationId: '9ce78c5a-46f1-426e-88c7-5e7e1c066bdb',
            responseCode: '99',
            responseMessage: 'FAILURE',
          },
          data: {},
          status: 'rejected',
        }),
      ),
    ),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    window.mfe = { scmDeviceMfeEnable: true };
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    sessionStorage.getItem('Qualification_type', 'MMW');
    sessionStorage.setItem('isPearl', 'true');
    sessionStorage.setItem('APP_PROPERTIES', '{"blockLocalInventoryRetailBYOD": "TRUE", "pearlBYODFlow": "TRUE"}');
    sessionStorage.setItem('enableSimValidation', 'true');
    render(<DeviceScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('handleOnBlurDeviceID testings', async () => {
    const testid = screen.getByTestId('handleChangeDeviceID');
    fireEvent.change(testid, { target: { value: '4567' } });
    fireEvent.change(testid, { target: { value: '4567456745674567' } });
    fireEvent.blur(testid, { target: { value: '4567456745674567' } });
    await new Promise((res) => {
      setTimeout(res, 5000);
    });
  }, 7000);
});

describe('DeviceScan component for handleOnBlurDeviceID - fraud risk validation with auth = Low Risk', () => {
  const props = {
    simSwapNotify: 'Y',
    enableEnforceApi: 'Y',
    setDeviceInput: jest.fn(),
    deviceInput: '4567456745674567',
    simSkuInput: '123',
    isFiveG: true,
    ivrDeviceId: true,
    setRepSelectedSimType: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    handleChangeDeviceIDs: jest.fn(),
    LineDeviceId: '3567456745674567',
    isPdpPage: false,
    showScanner: true,
    selectedDeviceId: true,
    lineActivityType: 'PAD',

    isIndirect: true,
    isRfexFlow: true,
    deviceError: false,
    ScanFromLanding: false,
    isPDPMFEEnabledTS: 'TRUE',
    isDeviceInputDisabled: jest.fn(),
    isDeviceFromCart: true,
    activeMtn: '8482470044',
    cartDetails: {
      lineInfo: [
        {
          mobileNumber: '8482470044',
          deviceTypeSelected: '5G Internet',
        },
      ],
    },
    CustomerData: {
      qualificationDetails: {
        fiveGHomebundle: [
          {
            bundleName: 'Gen4',
          },
        ],
        fiveGHomeQualified: true,
      },
      homeSalesAddress: {
        bundles: [],
      },
      channel: 'OMNI-RETAIL',
      billAccounts: [
        {
          mtns: [
            {
              mtn: '12345',
            },
          ],
        },
      ],
    },
    isFromPDPPage: true,
    isNewlyAddedLine: false,
    isByodUpdate: true,
    validateDeviceSimIdRequest: jest.fn(),
  };
  const handlers = [
    rest.post(`*/flexV2/deviceInventoryStatusCheck`, (req, res, ctx) => {
      console.log('inside /flexV2/deviceInventoryStatusCheck');
      return res(
        ctx.status(200),
        ctx.json({ data: { data: { data: { isDeviceAvailableInStoreInventory: false } } }, status: 'fulfilled' }),
      );
    }),
    rest.post(`*/cpc/fraudRiskScore`, (req, res, ctx) =>
      res(
        ctx.status(200),
        ctx.json({
          responseInfo: {
            errors: [],
            timeStamp: '15-11-2024 05:12:07',
            correlationId: 'smock_enforce_test',
            responseCode: '00',
            responseMessage: 'SUCCESS',
          },
          data: {
            sessionId: 'fcce4b0e-cbe3-4912-bcf0-9c7f4c671537',
            custId: '0725665601',
            acctNum: '1',
            fraudRiskScore: '0',
            fraudRiskLevel: 'Low Risk',
            loa: '0',
            mdn: '2153709209',
            notificationIndicator: 'Y',
            invokeIdScan: 'N',
          },
          status: 'fulfilled',
        }),
      ),
    ),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    window.mfe = { scmDeviceMfeEnable: true };
    console.log();
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    sessionStorage.getItem('Qualification_type', 'MMW');
    sessionStorage.setItem('isPearl', 'true');
    sessionStorage.setItem('APP_PROPERTIES', '{"blockLocalInventoryRetailBYOD": "TRUE", "pearlBYODFlow": "TRUE"}');
    sessionStorage.setItem('enableSimValidation', 'true');
    render(<DeviceScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('handleOnBlurDeviceID testings', async () => {
    const testid = screen.getByTestId('handleChangeDeviceID');
    fireEvent.change(testid, { target: { value: '4567' } });
    fireEvent.change(testid, { target: { value: '4567456745674567' } });
    fireEvent.blur(testid, { target: { value: '4567456745674567' } });
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
  });
});

describe('DeviceScan component for handleOnBlurDeviceID - fraud risk validation with auth = Low Risk with notificationindicator = N', () => {
  const props = {
    simSwapNotify: 'Y',
    enableEnforceApi: 'Y',
    setDeviceInput: jest.fn(),
    deviceInput: '4567456745674567',
    simSkuInput: '123',
    isFiveG: true,
    ivrDeviceId: true,
    setRepSelectedSimType: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    handleChangeDeviceIDs: jest.fn(),
    LineDeviceId: '3567456745674567',
    isPdpPage: false,
    showScanner: true,
    selectedDeviceId: true,
    lineActivityType: 'PAD',

    isIndirect: true,
    isRfexFlow: true,
    deviceError: false,
    ScanFromLanding: false,
    isPDPMFEEnabledTS: 'TRUE',
    isDeviceInputDisabled: jest.fn(),
    isDeviceFromCart: true,
    activeMtn: '8482470044',
    cartDetails: {
      lineInfo: [
        {
          mobileNumber: '8482470044',
          deviceTypeSelected: '5G Internet',
        },
      ],
    },
    CustomerData: {
      qualificationDetails: {
        fiveGHomebundle: [
          {
            bundleName: 'Gen4',
          },
        ],
        fiveGHomeQualified: true,
      },
      homeSalesAddress: {
        bundles: [],
      },
      channel: 'OMNI-RETAIL',
      billAccounts: [
        {
          mtns: [
            {
              mtn: '12345',
            },
          ],
        },
      ],
    },
    isFromPDPPage: true,
    isNewlyAddedLine: false,
    isByodUpdate: true,
    validateDeviceSimIdRequest: jest.fn(),
  };
  const handlers = [
    rest.post(`*/flexV2/deviceInventoryStatusCheck`, (req, res, ctx) => {
      console.log('inside /flexV2/deviceInventoryStatusCheck');
      return res(
        ctx.status(200),
        ctx.json({ data: { data: { data: { isDeviceAvailableInStoreInventory: false } } }, status: 'fulfilled' }),
      );
    }),
    rest.post(`*/cpc/fraudRiskScore`, (req, res, ctx) =>
      res(
        ctx.status(200),
        ctx.json({
          responseInfo: {
            errors: [],
            timeStamp: '15-11-2024 05:12:07',
            correlationId: 'smock_enforce_test',
            responseCode: '00',
            responseMessage: 'SUCCESS',
          },
          data: {
            sessionId: 'fcce4b0e-cbe3-4912-bcf0-9c7f4c671537',
            custId: '0725665601',
            acctNum: '1',
            fraudRiskScore: '0',
            fraudRiskLevel: 'Low Risk',
            loa: '0',
            mdn: '2153709209',
            notificationIndicator: 'N',
            invokeIdScan: 'N',
          },
          status: 'fulfilled',
        }),
      ),
    ),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    window.mfe = { scmDeviceMfeEnable: true };
    console.log();
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    sessionStorage.getItem('Qualification_type', 'MMW');
    sessionStorage.setItem('isPearl', 'true');
    sessionStorage.setItem('APP_PROPERTIES', '{"blockLocalInventoryRetailBYOD": "TRUE", "pearlBYODFlow": "TRUE"}');
    sessionStorage.setItem('enableSimValidation', 'true');
    render(<DeviceScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('handleOnBlurDeviceID testings', async () => {
    const testid = screen.getByTestId('handleChangeDeviceID');
    fireEvent.change(testid, { target: { value: '4567' } });
    fireEvent.change(testid, { target: { value: '4567456745674567' } });
    fireEvent.blur(testid, { target: { value: '4567456745674567' } });
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
  });
});

describe('DeviceScan component for handleOnBlurDeviceID - fraud risk validation without auth = Low Risk', () => {
  const props = {
    setDeviceInput: jest.fn(),
    deviceInput: '4567456745674567',
    simSkuInput: '123',
    isFiveG: true,
    ivrDeviceId: true,
    setRepSelectedSimType: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    handleChangeDeviceIDs: jest.fn(),
    LineDeviceId: '3567456745674567',
    isPdpPage: false,
    showScanner: true,
    selectedDeviceId: true,
    lineActivityType: 'PAD',

    isIndirect: true,
    isRfexFlow: true,
    deviceError: false,
    ScanFromLanding: false,
    isPDPMFEEnabledTS: 'TRUE',
    isDeviceInputDisabled: jest.fn(),
    isDeviceFromCart: true,
    activeMtn: '8482470044',
    simSwapNotify: 'Y',
    enableEnforceApi: 'Y',
    cartDetails: {
      lineInfo: [
        {
          mobileNumber: '8482470044',
          deviceTypeSelected: '5G Internet',
        },
      ],
    },
    CustomerData: {
      qualificationDetails: {
        fiveGHomebundle: [
          {
            bundleName: 'Gen4',
          },
        ],
        fiveGHomeQualified: true,
      },
      homeSalesAddress: {
        bundles: [],
      },
      channel: 'OMNI-RETAIL',
      billAccounts: [
        {
          mtns: [
            {
              mtn: '12345',
            },
          ],
        },
      ],
    },
    isFromPDPPage: true,
    isNewlyAddedLine: false,
    isByodUpdate: true,
    validateDeviceSimIdRequest: jest.fn(),
  };
  const handlers = [
    rest.post(`*/flexV2/deviceInventoryStatusCheck`, (req, res, ctx) => {
      console.log('inside /flexV2/deviceInventoryStatusCheck');
      return res(
        ctx.status(200),
        ctx.json({ data: { data: { data: { isDeviceAvailableInStoreInventory: false } } }, status: 'fulfilled' }),
      );
    }),
    rest.post(`*/cpc/fraudRiskScore`, (req, res, ctx) =>
      res(
        ctx.status(200),
        ctx.json({
          responseInfo: {
            errors: [],
            timeStamp: '15-11-2024 05:12:07',
            correlationId: 'smock_enforce_test',
            responseCode: '00',
            responseMessage: 'SUCCESS',
          },
          data: {
            sessionId: 'fcce4b0e-cbe3-4912-bcf0-9c7f4c671537',
            custId: '0725665601',
            acctNum: '1',
            fraudRiskScore: '0',
            fraudRiskLevel: 'Low Risk',
            loa: '0',
            mdn: '2153709209',
            notificationIndicator: 'Y',
            invokeIdScan: 'N',
          },
          status: 'fulfilled',
        }),
      ),
    ),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    window.mfe = { scmDeviceMfeEnable: true };

    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    sessionStorage.getItem('Qualification_type', 'MMW');
    sessionStorage.setItem('isPearl', 'true');
    sessionStorage.setItem('APP_PROPERTIES', '{"blockLocalInventoryRetailBYOD": "TRUE", "pearlBYODFlow": "TRUE"}');
    sessionStorage.setItem('enableSimValidation', 'false');
    render(<DeviceScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('handleOnBlurDeviceID testings', async () => {
    const testid = screen.getByTestId('handleChangeDeviceID');
    fireEvent.change(testid, { target: { value: '4567' } });
    fireEvent.change(testid, { target: { value: '4567456745674567' } });
    fireEvent.blur(testid, { target: { value: '4567456745674567' } });
    await new Promise((res) => {
      setTimeout(res, 3000);
    });
  });
});

describe('DeviceScan component for handleOnBlurDeviceID - fraud risk validation without auth = Low Risk', () => {
  const props = {
    setDeviceInput: jest.fn(),
    deviceInput: '4567456745674567',
    simSkuInput: '123',
    isFiveG: true,
    ivrDeviceId: true,
    setRepSelectedSimType: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    handleChangeDeviceIDs: jest.fn(),
    LineDeviceId: '3567456745674567',
    isPdpPage: false,
    showScanner: true,
    selectedDeviceId: true,
    lineActivityType: 'PAD',

    isIndirect: true,
    isRfexFlow: true,
    deviceError: false,
    ScanFromLanding: false,
    isPDPMFEEnabledTS: 'TRUE',
    isDeviceInputDisabled: jest.fn(),
    isDeviceFromCart: true,
    activeMtn: '8482470044',
    simSwapNotify: 'Y',
    enableEnforceApi: 'Y',
    cartDetails: {
      lineInfo: [
        {
          mobileNumber: '8482470044',
          deviceTypeSelected: '5G Internet',
        },
      ],
    },
    CustomerData: {
      qualificationDetails: {
        fiveGHomebundle: [
          {
            bundleName: 'Gen4',
          },
        ],
        fiveGHomeQualified: true,
      },
      homeSalesAddress: {
        bundles: [],
      },
      channel: 'OMNI-RETAIL',
      billAccounts: [
        {
          mtns: [
            {
              mtn: '12345',
            },
          ],
        },
      ],
    },
    isFromPDPPage: true,
    isNewlyAddedLine: false,
    isByodUpdate: true,
    validateDeviceSimIdRequest: jest.fn(),
  };
  const handlers = [
    rest.post(`*/flexV2/deviceInventoryStatusCheck`, (req, res, ctx) => {
      console.log('inside /flexV2/deviceInventoryStatusCheck');
      return res(
        ctx.status(200),
        ctx.json({ data: { data: { data: { isDeviceAvailableInStoreInventory: false } } }, status: 'fulfilled' }),
      );
    }),
    rest.post(`*/cpc/fraudRiskScore`, (req, res, ctx) =>
      res(
        ctx.status(200),
        ctx.json({
          responseInfo: {
            errors: [],
            timeStamp: '15-11-2024 05:12:07',
            correlationId: 'smock_enforce_test',
            responseCode: '00',
            responseMessage: 'SUCCESS',
          },
          data: {
            sessionId: 'fcce4b0e-cbe3-4912-bcf0-9c7f4c671537',
            custId: '0725665601',
            acctNum: '1',
            fraudRiskScore: '0',
            fraudRiskLevel: 'Low Risk',
            loa: '0',
            mdn: '2153709209',
            notificationIndicator: 'N',
            invokeIdScan: 'N',
          },
          status: 'fulfilled',
        }),
      ),
    ),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    window.mfe = { scmDeviceMfeEnable: true, isNotfnIndAA: true };

    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    sessionStorage.getItem('Qualification_type', 'MMW');
    sessionStorage.setItem('isPearl', 'true');
    sessionStorage.setItem('APP_PROPERTIES', '{"blockLocalInventoryRetailBYOD": "TRUE", "pearlBYODFlow": "TRUE"}');
    sessionStorage.setItem('enableSimValidation', 'false');
    render(<DeviceScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('handleOnBlurDeviceID testings', async () => {
    const testid = screen.getByTestId('handleChangeDeviceID');
    fireEvent.change(testid, { target: { value: '4567' } });
    fireEvent.change(testid, { target: { value: '4567456745674567' } });
    fireEvent.blur(testid, { target: { value: '4567456745674567' } });
    await new Promise((res) => {
      setTimeout(res, 3000);
    });
  });
});


describe('DeviceScan component for inside sales user check', () => {
  const props = {
    simSwapNotify: 'Y',
    enableEnforceApi: 'Y',
    setDeviceInput: jest.fn(),
    deviceInput: '4567456745674567',
    simSkuInput: '123',
    isFiveG: true,
    ivrDeviceId: true,
    setRepSelectedSimType: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    handleChangeDeviceIDs: jest.fn(),
    LineDeviceId: '3567456745674567',
    isPdpPage: false,
    showScanner: true,
    selectedDeviceId: true,
    lineActivityType: 'PAD',

    isIndirect: true,
    isRfexFlow: true,
    deviceError: false,
    ScanFromLanding: false,
    isPDPMFEEnabledTS: 'TRUE',
    isDeviceInputDisabled: jest.fn(),
    isDeviceFromCart: true,
    activeMtn: '8482470044',
    cartDetails: {
      lineInfo: [
        {
          mobileNumber: '8482470044',
          deviceTypeSelected: '5G Internet',
        },
      ],
    },
    CustomerData: {
      qualificationDetails: {
        fiveGHomebundle: [
          {
            bundleName: 'Gen4',
          },
        ],
        fiveGHomeQualified: true,
      },
      homeSalesAddress: {
        bundles: [],
      },
      channel: 'OMNI-RETAIL',
      billAccounts: [
        {
          mtns: [
            {
              mtn: '12345',
            },
          ],
        },
      ],
    },
    isFromPDPPage: true,
    isNewlyAddedLine: false,
    isByodUpdate: true,
    validateDeviceSimIdRequest: jest.fn(),
  };
  const handlers = [
    rest.post(`*/flexV2/deviceInventoryStatusCheck`, (req, res, ctx) => {
      console.log('inside /flexV2/deviceInventoryStatusCheck');
      return res(
        ctx.status(200),
        ctx.json({ data: { data: { data: { isDeviceAvailableInStoreInventory: false } } }, status: 'fulfilled' }),
      );
    }),
    rest.post(`*/cpc/fraudRiskScore`, (req, res, ctx) =>
      res(
        ctx.status(200),
        ctx.json({
          responseInfo: {
            errors: [
              {
                externalErrorCode: '74',
                externalErrorMessage: '500null',
                apiName: 'refSimSwapService',
                system: 'CXPREST',
                errorHolder: {},
              },
            ],
            timeStamp: '13-12-2024 02:25:44',
            correlationId: '9ce78c5a-46f1-426e-88c7-5e7e1c066bdb',
            responseCode: '99',
            responseMessage: 'FAILURE',
          },
          data: {},
          status: 'fulfilled',
        }),
      ),
    ),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    window.mfe = { isInsideSalesUser : true };
    server.listen();
  });
  afterAll(() => {
    server.close();
  });
  beforeEach(() => {
    sessionStorage.getItem('Qualification_type', 'MMW');
    sessionStorage.setItem('isPearl', 'true');
    sessionStorage.setItem('APP_PROPERTIES', '{"blockLocalInventoryRetailBYOD": "TRUE", "pearlBYODFlow": "TRUE"}');
    sessionStorage.setItem('enableSimValidation', 'true');
    render(<DeviceScan {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('should set isInsideSalesUser to false when the window.mfe flag is true, and the device input field should disabled', () => {
    const deviceIdInput = screen.getByTestId('handleChangeDeviceID');
    expect(deviceIdInput).toBeDisabled();
  });
});

// Test cases for trainingFlag functionality
describe('DeviceScan - trainingFlag Tests', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  const mockProps = {
    setDeviceInput: jest.fn(),
    setRepSelectedSimType: jest.fn(),
    setEnableBYODbtn: jest.fn(),
    ivrDeviceId: true,
    handleChangeDeviceIDs: jest.fn(),
    LineDeviceId: '',
    isPdpPage: false,
    lineActivityType: 'PAD',
    isIndirect: true,
    isRfexFlow: true,
    ScanFromLanding: false,
    isprepaycart: true,
    isFiveG: true,
    activeMtn: '8482470044',
    cartDetails: {
      cart: { lineDetails: { lineInfo: [{ itemsInfo: [{ cartItems: { cartItem: [{ imei2: '' }] } }] }] } },
      lineInfo: [
        {
          mobileNumber: '8482470044',
          deviceTypeSelected: '5G Internet',
        },
      ],
    },
    CustomerData: {
      channel: 'OMNI-RETAIL',
      qualificationDetails: {
        fiveGHomebundle: [
          {
            bundleName: 'Gen4',
          },
        ],
      },
    },
  };

  test('should call trainingFlag when component renders', () => {
    trainingFlag.mockReturnValue(true);

    render(<DeviceScan {...mockProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    expect(trainingFlag).toHaveBeenCalled();
  });

  test('should disable Device ID input when trainingFlag returns true', () => {
    trainingFlag.mockReturnValue(true);

    render(<DeviceScan {...mockProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    const deviceIdInput = screen.getByTestId('handleChangeDeviceID');
    expect(deviceIdInput).toBeDisabled();
    expect(trainingFlag).toHaveBeenCalled();
  });

  test('should not disable Device ID input when trainingFlag returns false', () => {
    trainingFlag.mockReturnValue(false);

    render(<DeviceScan {...mockProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    const deviceIdInput = screen.getByTestId('handleChangeDeviceID');
    expect(deviceIdInput).not.toBeDisabled();
    expect(trainingFlag).toHaveBeenCalled();
  });

  test('should handle undefined trainingFlag value (defaults to not disabled)', () => {
    trainingFlag.mockReturnValue(undefined);

    render(<DeviceScan {...mockProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    const deviceIdInput = screen.getByTestId('handleChangeDeviceID');
    // undefined || false = false, so isPosTrainingEnabled = false
    expect(deviceIdInput).not.toBeDisabled();
    expect(trainingFlag).toHaveBeenCalled();
  });

  test('should verify className remains "contains-PII" regardless of trainingFlag', () => {
    trainingFlag.mockReturnValue(true);

    render(<DeviceScan {...mockProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    const deviceScanDiv = screen.getByTestId('device-scan');
    expect(deviceScanDiv).toHaveClass('contains-PII');
  });
});

/**
 * Test coverage for lines 566-569: checkProvisionalId function
 * This test covers the scenario when provisional ID checkbox is checked/unchecked
 * with flexFlowServiceChange enabled and eSIM regeneration flag is set
 */
describe('DeviceScan - checkProvisionalId with eSIM regeneration (Lines 566-569)', () => {
  let mockSetIsESimRegenerated;
  let mockSetEnableBYODbtn;
  let mockSetIsProvisionalIdChecked;

  beforeEach(() => {
    mockSetIsESimRegenerated = jest.fn();
    mockSetEnableBYODbtn = jest.fn();
    mockSetIsProvisionalIdChecked = jest.fn();
    
    sessionStorage.clear();
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({
      flexFlowServiceChangeFFlag: 'TRUE',
      esimAPIskipFFlag: 'TRUE'
    }));
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  test('should call setIsESimRegenerated(false) when provisional ID checkbox is toggled', async () => {
    // Mock getQueryParamByName to enable flexFlowServiceChange
    jest.spyOn(DomService, 'getQueryParamByName').mockImplementation((param) => {
      if (param === 'etrServiceChanges') return 'true';
      if (param === 'deviceSKU') return 'APPLEIPHON14PRO256GBDEEPPURPLE-A';
      if (param === 'deviceId') return '352766390095123';
      if (param === 'isByodUpdate') return 'true';
      return null;
    });

    const mockProps = {
      setRepSelectedSimType: jest.fn(),
      setEnableBYODbtn: mockSetEnableBYODbtn,
      setIsESimRegenerated: mockSetIsESimRegenerated,
      setIsProvisionalIdChecked: mockSetIsProvisionalIdChecked,
      ivrDeviceId: false,
      handleChangeDeviceIDs: jest.fn(),
      LineDeviceId: '352766390095123',
      isPdpPage: true,
      lineActivityType: 'BYOD',
      isIndirect: false,
      isRfexFlow: false,
      ScanFromLanding: false,
      isprepaycart: false,
      isFiveG: false,
      activeMtn: '8482470044',
      isProvisionalId: true,
      cartDetails: {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                mobileNumber: '8482470044',
                itemsInfo: [{ cartItems: { cartItem: [{ imei2: '352766390095123' }] } }]
              }
            ]
          }
        }
      },
      CustomerData: {
        channel: 'OMNI-RETAIL',
        billAccounts: [
          {
            mtns: [
              {
                mtn: '8482470044',
              },
            ],
          },
        ],
      },
      validateDeviceSimIdRequest: jest.fn(),
      isPDPMFEEnabledTS: 'TRUE',
      isDeviceInputDisabled: jest.fn(() => false),
      isDisabled: false,
    };

    render(<DeviceScan {...mockProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    // Find the provisional ID checkbox - VDS Checkbox uses different testid internally
    const provisionalCheckbox = screen.getByLabelText(/Provisional ID/i);

    await act(async () => {
      fireEvent.click(provisionalCheckbox);
    });

    await waitFor(() => {
      // Line 568: Clear eSIM regeneration flag when provisional ID is checked/unchecked
      expect(mockSetIsESimRegenerated).toHaveBeenCalledWith(false);
    });
  });

  test('should emit PROVISIONAL_ID_UNCHECK event when provisional ID is unchecked with flexFlowServiceChange', async () => {
    // Mock getQueryParamByName to return required values
    jest.spyOn(DomService, 'getQueryParamByName').mockImplementation((param) => {
      if (param === 'deviceSKU') return 'APPLEIPHON14PRO256GBDEEPPURPLE-A';
      if (param === 'deviceId') return '352766390095123';
      if (param === 'isByodUpdate') return 'true';
      if (param === 'etrServiceChanges') return 'true';
      return null;
    });

    const mockProps = {
      setRepSelectedSimType: jest.fn(),
      setEnableBYODbtn: mockSetEnableBYODbtn,
      setIsESimRegenerated: mockSetIsESimRegenerated,
      setIsProvisionalIdChecked: mockSetIsProvisionalIdChecked,
      ivrDeviceId: false,
      handleChangeDeviceIDs: jest.fn(),
      LineDeviceId: '352766390095123',
      isPdpPage: true,
      lineActivityType: 'BYOD',
      isIndirect: false,
      isRfexFlow: false,
      ScanFromLanding: false,
      isprepaycart: false,
      isFiveG: false,
      activeMtn: '8482470044',
      isProvisionalId: true,
      cartDetails: {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                mobileNumber: '8482470044',
                itemsInfo: [{ cartItems: { cartItem: [{ imei2: '352766390095123' }] } }]
              }
            ]
          }
        }
      },
      CustomerData: {
        channel: 'OMNI-RETAIL',
        billAccounts: [
          {
            mtns: [
              {
                mtn: '8482470044',
              },
            ],
          },
        ],
      },
      validateDeviceSimIdRequest: jest.fn(),
      isPDPMFEEnabledTS: 'TRUE',
      isDeviceInputDisabled: jest.fn(() => false),
      isDisabled: false,
    };

    render(<DeviceScan {...mockProps} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    // Find the provisional ID checkbox using label text
    const provisionalCheckbox = screen.getByLabelText(/Provisional ID/i);

    await act(async () => {
      fireEvent.click(provisionalCheckbox);
    });

    await waitFor(() => {
      // Lines 571-585: When provisional ID is checked with flexFlowServiceChange
      // Verify side effects: sessionStorage and setEnableBYODbtn are called
      
      // Line 584: Set provisonalUncheckedBox in sessionStorage
      expect(sessionStorage.getItem('provisonalUncheckedBox')).toBe('true');
      
      // Line 585: Call setEnableBYODbtn(false)
      expect(mockSetEnableBYODbtn).toHaveBeenCalledWith(false);
      
      // Line 587: Call setIsProvisionalIdChecked
      expect(mockSetIsProvisionalIdChecked).toHaveBeenCalled();
    });
  });

  test('should handle case when setIsESimRegenerated is not provided', async () => {
    // Mock getQueryParamByName to enable flexFlowServiceChange
    jest.spyOn(DomService, 'getQueryParamByName').mockImplementation((param) => {
      if (param === 'etrServiceChanges') return 'true';
      if (param === 'deviceSKU') return 'APPLEIPHON14PRO256GBDEEPPURPLE-A';
      if (param === 'deviceId') return '352766390095123';
      if (param === 'isByodUpdate') return 'true';
      return null;
    });

    const mockPropsWithoutESim = {
      setRepSelectedSimType: jest.fn(),
      setEnableBYODbtn: mockSetEnableBYODbtn,
      setIsESimRegenerated: undefined,
      setIsProvisionalIdChecked: mockSetIsProvisionalIdChecked,
      ivrDeviceId: false,
      handleChangeDeviceIDs: jest.fn(),
      LineDeviceId: '352766390095123',
      isPdpPage: true,
      lineActivityType: 'BYOD',
      isIndirect: false,
      isRfexFlow: false,
      ScanFromLanding: false,
      isprepaycart: false,
      isFiveG: false,
      activeMtn: '8482470044',
      isProvisionalId: true,
      cartDetails: {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                mobileNumber: '8482470044',
                itemsInfo: [{ cartItems: { cartItem: [{ imei2: '352766390095123' }] } }]
              }
            ]
          }
        }
      },
      CustomerData: {
        channel: 'OMNI-RETAIL',
        billAccounts: [
          {
            mtns: [
              {
                mtn: '8482470044',
              },
            ],
          },
        ],
      },
      validateDeviceSimIdRequest: jest.fn(),
      isPDPMFEEnabledTS: 'TRUE',
      isDeviceInputDisabled: jest.fn(() => false),
      isDisabled: false,
    };

    render(<DeviceScan {...mockPropsWithoutESim} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    // Should not throw error when setIsESimRegenerated is not provided
    const provisionalCheckbox = screen.getByLabelText(/Provisional ID/i);
    
    await act(async () => {
      fireEvent.click(provisionalCheckbox);
    });

    // Test passes if no error is thrown
    expect(provisionalCheckbox).toBeInTheDocument();
  });
});
