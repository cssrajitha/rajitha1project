import React, { useState, useEffect, useMemo } from 'react';
import styled from 'styled-components';
import { Body } from '@vds/typography';
import { TileContainer } from '@vds/tiles';
import PropTypes from 'prop-types';
import { getQueryParamByName, isOmniCare } from 'onevzsoemfeframework/DomService';
import Emitter from 'onevzsoemfeframework/Emitter';
import { Icon } from '@vds/icons';
import { Checkbox } from '@vds/checkboxes';
import { useNavigate } from 'react-router-dom';
import { getUIContextPathBAU, decodeHTMLEntities, acssMfeBasePath } from 'onevzsoemfecommon/Helpers';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { isVbg, isVbgAem } from 'onevzsoemfeframework/VbgAemUtil';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import { useDispatch } from 'react-redux';
import { useCheckEnrollmentMutation,useCheckHuntGroupMutation} from 'onevzsoemfecommon/APIService';
import { fiveGProfInstallCharges } from '../../constants/DeviceConstants';
import { TileWrapper, ImgWrapper, FlexJustify, SelfProfInstallWrapper } from '../FlexGlobalStyledConstants';
import { isDWOSAllowed } from '../../FlexPDP/pdputils';
import { getPricingPriority, getDpTermIndex } from '../../../modules/utils/devicePricingUtils';
import { getVbgFwaProfInstallOrderingFlag } from '../../../modules/utils/vbgUtils';
import DisplayName from './DisplayName';

const StyledImg = styled.img`
  width: 100px;
  height: 132px;
  margin-right: 0px !important;
`;

const CheckboxWrapper = styled.div`
  label {
    display: inline-flex;
    flex-direction: row-reverse;
    gap: 0.5rem;
  }
`;
const UpgradeAfterBadge = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  width: 160px;
  height: 26px;
  background: #000000;
  border-radius: 8px 0px 0px 0px;
  padding-left: 0.5rem;
  padding-top: 0.5rem;
`;
const Width100 = styled.div`
  width: 100%;
`;
const DeviceWrapper = styled.div`
  display: flex;
  flex-direction: column;
  height: 100%;
`;
const LabelWrapper = styled.div`
  position: relative;
  top: 2px;
`;
const DetailsWrapper = styled.div`
  padding-bottom: 1rem;
`;
const SelectedWrapper = styled.div`
  position: absolute;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  height: 20px;
  background: #00ac3e;
  border-radius: 24px;
  right: 12px;
  top: 12px;
`;
const Ellipsis = styled.div`
  display: -webkit-box;
  min-height: 3.375rem;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
`;

const RecommendedTag = styled.div`
  position: absolute;
  color: #0088ce;
  border-radius: 6px;
  font-size: 16px;
  z-index: 2;
  font-family: Verizon-NHG-eDS;
`;
const ProfessionalInstallTag = styled.div`
  position: absolute;
  color: #000;
  font-size: 16px;
  z-index: 2;
  font-family: Verizon-NHG-eDS;
  background-color: rgb(227, 242, 253);
  display: flex;
  box-sizing: border-box;
  padding: 5px;
  top: 6px;
  font-weight: bold;
  width: 100%;
  left: 0;
  justify-content: center;
`;

let navigate = '';

const isVbgFwaMLOrderingFFlag = () => {
  const vbgFwaMLOrderingFFlag = isVbgAem() && JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.vbgFwaMLOrderingFFlag === 'TRUE';
  return vbgFwaMLOrderingFFlag;
};

const count5GInternetLines = (cartDetails) => {
  const FIVE_G_INTERNET_TYPE = '5G Internet';
  const lineInfo = cartDetails?.cart?.lineDetails?.lineInfo;
  
  const fiveGLines = lineInfo?.filter(line => line?.deviceTypeSelected === FIVE_G_INTERNET_TYPE);
  return fiveGLines?.length || 0;
};

function useNavigateMFE() {
  navigate = useNavigate();
}

// Helper: builds the 5G PDP/Product Detail URL (extracted to reduce cognitive complexity)
function buildFiveGPdpUrl({ productId, isBundledGWFiveG, pdpExtraParams, activeMtn, defaultSku, fleRedesignParams, fiveGLinesCount }) {
  const base = getUIContextPathBAU();
  const page = isVbg() ? 'product-detail.html' : 'pdp.html';
  return `${base}/${page}?productId=${productId}${isBundledGWFiveG}${pdpExtraParams}&activeMtn=${activeMtn}${defaultSku}${fleRedesignParams}${fiveGLinesCount}`;
}

const checkOneTalk = (device, checkEnrolled, navigateToProductDetails) => {
  const isOneTalkDeviceCategory = device?.sorDeviceCategory === 'IP DP' || device?.sorDeviceCategory === 'IP Virtual Device';
  if ((device?.isOneTalkDevice && JSON.parse(device.isOneTalkDevice)) || isOneTalkDeviceCategory) {
    const defaultSKU = device?.defaultSKU || '';
    checkEnrolled(defaultSKU);
  } else {
    navigateToProductDetails();
  }
};

export const handleEnrollmentSuccess = (data, currentDefaultSKU, checkHuntGroup, navigateToProductDetails) => {
  const DEFAULTSKU = 'STKHG';
  const { statusCode, isOneTalkEnrollmentRequired, errors } = data;
  const firstError = errors?.[0];

  // Branch A: Success Status
  if (statusCode === '1') {
    if (currentDefaultSKU === DEFAULTSKU) {
      return checkHuntGroup({ body: {} });
    }
    return navigateToProductDetails();
  }

  // Branch B: Enrollment Required
  if (statusCode === '-1' && isOneTalkEnrollmentRequired) {
    return Emitter.emit('ONETALK_DEVICEC_REQ', {
      status: 'enrollment_required',
      message: 'Customer needs to be enrolled in One Talk. Please enroll by using this link.',
    });
  }

  // Branch C: Info/Error Messages
  const msgType = firstError?.msgType?.toLowerCase();
  if (statusCode === '-1' && (msgType === 'info' || msgType === 'error')) {
    Emitter.emit('ONETALK_DEVICEC_REQ', {
      status: `message-${msgType}`,
      message: firstError.message,
    });
  }
};

const handleTileClick = ({
  isPearl,
  trialProductDisplayName,
  callValidateDeviceSimID,
  vbgnsaOneTalkFFlag,
  isVbgFlag,
  checkOneTalkFn,
  navigateToProductDetails,
  device,
  checkEnrolled,
}) => {
  const shouldCheckOneTalk = isVbgFlag && vbgnsaOneTalkFFlag;
  if (isPearl && trialProductDisplayName) {
    callValidateDeviceSimID();
  } else if (shouldCheckOneTalk) {
    checkOneTalkFn(device, checkEnrolled, navigateToProductDetails);
  } else {
    navigateToProductDetails();
  }
};

export const determineHuntGroupAction = (responseData) => {
  const { statusCode, isOneTalkEnrollmentRequired, errors } = responseData || {};

  if (statusCode === '1') {
    return { type: 'NAVIGATE_TO_DETAILS' };
  }

  if (statusCode === '-1' && isOneTalkEnrollmentRequired === false) {
    return {
      type: 'EMIT_ERROR',
      payload: {
        status: 'message-error',
        message: errors?.[0]?.message || 'Unknown error occurred',
      },
    };
  }

  return { type: 'NO_ACTION' };
};

export const handleScreenTakeover = (shouldTakeOverScreen, TakeOverScreenFunc) => {
  if (shouldTakeOverScreen()) {
    TakeOverScreenFunc();
    return true; // Takeover occurred
  }
  return false;
};

const handleEnrollmentConditions = ({
  resultData,
  isSuccess,
  isError,
  error,
  currentDefaultSKU,
  checkHuntGroup,
  navigateToProductDetails,
  dispatch,
}) => {
  // Logic check: Ensure we have the nested data object
  if (isSuccess && resultData?.data) {
    handleEnrollmentSuccess(resultData.data, currentDefaultSKU, checkHuntGroup, navigateToProductDetails);
  }

  if (isError && error) {
    dispatch(
      appMessageActions.addAppMessage('Failed to check OneTalk enrollment. Please try again.', 'error', true, true)
    );
  }
};

const handleHuntGroupConditions = (data, isSuccess, isError, error, navigateToProductDetails, dispatch) => {
  if (isSuccess && data?.data) {
    const result = determineHuntGroupAction(data.data);

    switch (result.type) {
      case 'NAVIGATE_TO_DETAILS':
        navigateToProductDetails();
        break;
      case 'EMIT_ERROR':
        Emitter.emit('ONETALK_DEVICEC_REQ', result.payload);
        break;
      default:
        break;
    }
  }

  if (isError && error) {
    // Prefer any structured API error message if present (errors array or top-level message)
    const apiErrorMsg =
      error?.data?.errors?.[0]?.message || error?.response?.data?.errors?.[0]?.message ||
      error?.data?.message || error?.message;

    if (apiErrorMsg) {
      Emitter.emit('ONETALK_DEVICEC_REQ', {
        status: 'message-error',
        message: apiErrorMsg,
      });
    } else {
      dispatch(
        appMessageActions.addAppMessage(
          'Failed to check hunt group. Please try again.',
          'error',
          true,
          true
        )
      );
    }
  }
}


function DeviceTile(props) {
  const {
    device,
    commonInfo,
    deviceSelection,
    activeMtn,
    devicestocompare,
    handleCompareCheckboxChange,
    handleRemoveProductFromCompareInGW,
    totalLines,
    lineActivityType,
    isBundleGW,
    installmentTerm,
    trialDeviceId,
    trialProductImageUrl,
    trialProductDisplayName,
    isPearl,
    validateDeviceSimIdRequest,
    isBytdDeviceAdded,
    cartDetails,
    TakeOverScreenFunc,
    channel,
    isDWOS,
    recommendedSetup,
  } = props;
  const scmDeviceEnable = window?.mfe?.scmDeviceMfeEnable;
  const dispatch = useDispatch();
  try {
    useNavigateMFE();
  } catch (e) {
    /* istanbul ignore next */
    console.log('');
  }

  const elvisFromSession = sessionStorage.getItem('elvisFFlag');
  const elvisFFlag = /true/i.test(elvisFromSession);

  const isRecommended = device?.productId === recommendedSetup;

  const gridwallAccessibleFFlag = /true/i.test(getAssistedCradlePropertyV2(['gridwallAccessibleFFlag'])?.[0]);
  const vbgnsaOneTalkFFlag  = /true/i.test(JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.vbgnsaOneTalkFFlag?.toLowerCase() ?? 'false');

  const [checkBoxSelectedValue, setCheckBoxSelectedValue] = useState(false);
  const [checkBoxDisabled, setCheckBoxDisabled] = useState(false);
  // Initialize CheckEnrollment API lazy hook for OneTalk
  const [checkEnrollmentAPI, CheckEnrollmentResult] = useCheckEnrollmentMutation();
  const [checkHuntGroup, CheckHuntGroupResult] = useCheckHuntGroupMutation();
  // Store defaultSKU for use in useEffect
  const [currentDefaultSKU, setCurrentDefaultSKU] = useState('');

  // us-449 - Grid - Self Install
  const isVbgFlag = isVbg();

  const defaultSKUObj = device?.defaultSKUObj ? device?.defaultSKUObj : device;

  const isByod = lineActivityType?.includes('BYOD');
  const selectedLine = (totalLines?.length && totalLines?.find((line) => line?.mobileNumber === activeMtn)) || {};
  const deviceInCart =
    selectedLine?.itemsInfo?.[0]?.cartItems?.cartItem?.find((item) => item?.cartItemType === 'DEVICE') || {};
  const simInCart =
    selectedLine?.itemsInfo?.[0]?.cartItems?.cartItem?.find((item) => item?.cartItemType === 'SIM') || {};
  const selectedChildSku = deviceSelection?.childSkus?.find((child) => child?.skuId === props?.selectedSkuId);

  const isTGWFCLFlow = device?.childSkus?.find((item) => item?.canonicalUrl?.includes('VSHIProsetup'))
    ? true
    : defaultSKUObj?.canonicalUrl?.includes('VSHIProsetup');
  const isTGWPilot = device?.childSkus?.find((item) => item?.canonicalUrl?.includes('TanglewoodProfSetup'))
    ? true
    : defaultSKUObj?.canonicalUrl?.includes('TanglewoodProfSetup');
  let isTGWFlow = isTGWPilot || isTGWFCLFlow;

  // us-449 - Grid - Self Install
  const checkInstallFlow = useMemo(
    () => (keyword) =>
      device?.childSkus?.some((item) => item?.canonicalUrl?.includes(keyword)) ||
      defaultSKUObj?.canonicalUrl?.includes(keyword),
    [device, defaultSKUObj],
  );

  const is5GSelfInstallFlow = checkInstallFlow('SelfSetup');
  const is5GProInstallflow = checkInstallFlow('profsetup');

  const checkProfessionalInstallDevice = (deviceObj) => 
    getVbgFwaProfInstallOrderingFlag() && deviceObj?.isProfessionalInstallDevice;

  let selfProfChildren = null;
  let canShowToastMessage = false;
  if (isVbgFlag) {
    switch (true) {
      case is5GSelfInstallFlow:
        selfProfChildren = (
          <SelfProfInstallWrapper data-testid='self-install-wrapper'>
            <Body size='medium' color='#004B1C' bold>
              Self Installation
            </Body>
          </SelfProfInstallWrapper>
        );
        break;

      case is5GProInstallflow:
        selfProfChildren = (
          <SelfProfInstallWrapper data-testid='professional-install-wrapper' professional>
            <Body size='medium' color='#003E6C' bold>
              <Icon name='professional-services-case' size='small' color='#003E6C' /> &nbsp; Professional Installation
            </Body>
          </SelfProfInstallWrapper>
        );
        canShowToastMessage = true;
        break;

      default:
        // No action needed
        break;
    }
  }

  const flexRedesign5GFFlag = /true/i.test(getAssistedCradlePropertyV2(['flexRedesign5GFFlag'])?.[0]);
  const [tgwD2DAssignMtnFixFFlag, dwosIndirectFFlag] = getAssistedCradlePropertyV2([
    'tgwD2DAssignMtnFixFFlag',
    'dwosIndirectFFlag',
  ]);
  if (tgwD2DAssignMtnFixFFlag === 'TRUE') {
    const isTGWPilotSetup =
      device?.childSkus?.find((item) => item?.canonicalUrl?.toLowerCase()?.includes('tanglewoodprofsetup')) ||
      defaultSKUObj?.canonicalUrl?.toLowerCase()?.includes('tanglewoodprofsetup');
    const isTGWFCL =
      device?.childSkus?.find((child) => child?.canonicalUrl?.toLowerCase()?.includes('vshiprosetup')) ||
      defaultSKUObj?.canonicalUrl?.toLowerCase()?.includes('vshiprosetup');
    isTGWFlow = !!(isTGWPilotSetup || isTGWFCL);
  }

  const priceObj = selectedChildSku?.price || deviceSelection?.price || defaultSKUObj?.price;
  const imageSrc =
    selectedChildSku?.imageUrlMap?.thumbImage ||
    (defaultSKUObj ? defaultSKUObj?.imageUrlMap?.thumbImage : deviceSelection?.imageUrlMap?.thumbImage) ||
    trialProductImageUrl;
  const capacity = deviceSelection?.capacity || defaultSKUObj?.capacity;
  const fiveGDetails =
    totalLines &&
    totalLines.length > 0 &&
    totalLines.filter((line) => line && line?.mobileNumber && line.mobileNumber === activeMtn);
  const is5gLine = fiveGDetails && fiveGDetails.length > 0 && fiveGDetails[0].deviceTypeSelected === '5G Internet';
  const deviceName = device?.productDisplayName || device?.skuDisplayName || device?.description || '';
  const displayProfSetupCharges = true; // we need to check with team
  const dpTermPreferredIndex = isVbg() ? getDpTermIndex(priceObj) : 0;
  let pricingPriority = '';
  if(isVbg() && dpTermPreferredIndex === -1) {
    pricingPriority = getPricingPriority(priceObj);
  }
  const { firstMonthPrice, dpTerm, remainingMonthPrice } =
    priceObj?.devicePaymentPrice && priceObj?.devicePaymentPrice?.[dpTermPreferredIndex]
      ? // eslint-disable-next-line no-unsafe-optional-chaining
        priceObj?.devicePaymentPrice?.[dpTermPreferredIndex]?.dpTermPrices
      : {};
  let contractTerm = '24';
  if (installmentTerm) {
    contractTerm = installmentTerm;
  } else if (firstMonthPrice) {
    if (priceObj?.preferredTerm) {
      contractTerm = priceObj?.preferredTerm;
    } else if (priceObj?.contractDuration) {
      contractTerm = priceObj?.contractDuration;
    } else if (dpTerm) {
      contractTerm = dpTerm;
    }
  }
  let dp24UpgOff = null;
  if (priceObj?.devicePaymentPrice) {
    dp24UpgOff = priceObj?.devicePaymentPrice[0]?.dpTermPrices?.upgradeOptionPercentage || null;
  }
  const [isFiveGProductDetailEnabled, bestBuyIntegrationFFlag, oneTimeOfferProInstallFFlag, bestBuyDfillIndirectFFlag, bestBuyISPUEnableLocalOrderFFlag] =
    getAssistedCradlePropertyV2([
      'isFiveGProductDetailEnabled',
      'bestBuyIntegrationFFlag',
      'oneTimeOfferProInstallFFlag',
      'bestBuyDfillIndirectFFlag',
      'bestBuyISPUEnableLocalOrderFFlag'
    ]);
  const callValidateDeviceSimID = () => {
    const payload = {
      deviceId: trialDeviceId,
      cpSimCard: false,
      mtn: sessionStorage.getItem('activeMTN'),
    };
    validateDeviceSimIdRequest(payload);
  };

  // PDP Redirection method, will be modified once finalised reducer is available for it.
  /* istanbul ignore next */
  const navigateToProductDetails = () => {
    if (canShowToastMessage) {
      dispatch(
        appMessageActions.addAppMessage(
          'Professional Install is not compatible for this flow. Please switch to B360',
          'error',
          true,
          true,
        ),
      );
      return;
    }

    if (shouldTakeOverScreen()) {
      TakeOverScreenFunc();
      return;
    }
    const childSkus = device?.childSkus || [];
    const productId = device?.productId || device?.parentProducts?.[0]?.productId || '';
    const productDisplayName = device?.productDisplayName || device?.skuDisplayName || device?.description || '';
    let pdpExtraParams = '';
    // HUM logic needs to be updated as per the API response, currently we are not getting the flag in productlist API.
    const isBundledGW = getQueryParamByName('isBundledGW') ? '&isBundledGW=true' : '';
    handleScreenTakeover(shouldTakeOverScreen, TakeOverScreenFunc);
    const isBundledGWFiveG = isBundleGW ? '&isBundledGW=true' : '';
    let defaultSku = '';
    let UpcCodeData = ''; // defaultSKUObj.upcCodeData
    let defSorId = '';
    if (
      device?.searchedSku &&
      childSkus &&
      childSkus.filter((sku) => sku && sku?.sorId === device?.searchedSku).length
    ) {
      defaultSku = `&defaultSku=${device?.searchedSku}`;
      UpcCodeData = `&upcCodeValue=${device?.defaultSKUObj?.upcCodeFull || ''}`;
      defSorId = device?.searchedSku;
    } else if (device?.defaultSKU || device?.sorId) {
      defaultSku = `&defaultSku=${device?.defaultSKU || device?.sorId || ''}`;
      defSorId = device?.defaultSKU || device?.sorId || '';
      UpcCodeData = `&upcCodeValue=${device?.defaultSKUObj?.upcCodeFull || ''}`;
    }

    if (productDisplayName?.indexOf('Hum') !== -1) {
      navigate(
        `${getUIContextPathBAU()}/hummodal.html?offerEligible=Y&activeMtn=${activeMtn}&productId=${productId}${defaultSku}${isBundledGW}`,
      );
    } else {
      const DWOSParams = isDWOSAllowed(dwosIndirectFFlag, isDWOS) ? ' &isDWOS=true' : '';
      // passing needed params to navigate to pdp for added device
      if (deviceSelection) {
        defaultSku = `&deviceSKU=${deviceInCart?.itemCode}`;
        const deviceParams = `&deviceId=${deviceInCart?.deviceId}&simId=${simInCart?.simId ? simInCart?.simId : ''}`;
        let queryParamsIsFromCpe = '&isFromCPE=true';
        if (isOmniCare) queryParamsIsFromCpe = '';
        if (isByod) {
          pdpExtraParams += `&isByodUpdate=true&isEditAndView=true&fromPage=CombinedGridwall${deviceParams}${queryParamsIsFromCpe}`;
        } else {
          pdpExtraParams += `&deviceFromCart=true&isEditAndView=true&fromPage=CombinedGridwall${deviceParams}${DWOSParams}`;
        }
      }

      if (window.location.href.includes('/sales/assisted/new/device/gridwall.html')) {
        navigate(
          `/sales/assisted/new/pdp.html?offerEligible=Y&activeMtn=${activeMtn}&productId=${productId}${defaultSku}${pdpExtraParams}${UpcCodeData}`,
        );
      } else if (is5gLine && isFiveGProductDetailEnabled === 'FALSE') {
        if (window?.mfe?.scmUpgradeMfeEnable) {
          Emitter.emit('ACSS_SCM_DEVICE_SUBTAB_FWA', {
            productId,
            isBundledGWFiveG,
            pdpExtraParams,
            activeMtn,
            defaultSku,
          });
        } else {
          let fleRedesignParams = '';
          let fiveGLinesCount = '';
          if (flexRedesign5GFFlag) fleRedesignParams = `&preferredSoftSim=${simInCart?.sorId}`;
          if (isVbgFwaMLOrderingFFlag()) {
            const linesCount = count5GInternetLines(cartDetails);
            fiveGLinesCount = `&fiveGLinesCount=${linesCount}`;
          }
          navigate(
            buildFiveGPdpUrl({
              productId,
              isBundledGWFiveG,
              pdpExtraParams,
              activeMtn,
              defaultSku,
              fleRedesignParams,
              fiveGLinesCount
            }),
          ); /* istanbul ignore next */
        }
      } else if (scmDeviceEnable)
        window?.mfe?.historyRef.push(
          `${acssMfeBasePath}/product-detail.html?offerEligible=Y&activeMtn=${activeMtn}&productId=${productId}${defaultSku}${pdpExtraParams}${UpcCodeData}`,
        );
      else if (/true/i.test(bestBuyDfillIndirectFFlag))
        navigate(
          `${getUIContextPathBAU()}/product-detail.html?offerEligible=Y&activeMtn=${activeMtn}&productId=${productId}${defaultSku}${pdpExtraParams}&iSscan=true&isLocal=true&upcCodeValue=887276817927`,
        );
      else
        navigate(
          `${getUIContextPathBAU()}/product-detail.html?offerEligible=Y&activeMtn=${activeMtn}&productId=${productId}${defaultSku}${pdpExtraParams}${DWOSParams}${UpcCodeData}`,
        );
    }
    sessionStorage.setItem('tagSorID', defSorId);
  };

  const shouldTakeOverScreen = () => {
    if (bestBuyIntegrationFFlag === 'TRUE' &&
      !/true/i.test(bestBuyDfillIndirectFFlag) &&
      !/true/i.test(bestBuyISPUEnableLocalOrderFFlag)) {
      const showMessage =
        cartDetails?.cart?.lineDetails?.lineInfo?.[0]?.itemsInfo?.[0]?.depletionType === 'L' &&
        cartDetails?.cart?.cartHeader?.locationSubType === 'GN' &&
        cartDetails?.cart?.cartHeader?.maid === 'BBX' &&
        !(channel === 'OMNI-RETAIL' || channel === 'OMNI-RETAIL-TAB');
      const channelCheck = channel === 'OMNI-INDIRECT' || channel === 'OMNI-INDIRECT-TAB';
      return showMessage || channelCheck;
    }
  };
  useEffect(() => {
    if (devicestocompare?.length > 0) {
      const productId = device?.productId || device?.parentProducts?.[0]?.productId || '';
      const isProIdPresent = devicestocompare.filter((dev) => dev.productId === productId);
      if (isProIdPresent?.length === 0) {
        setCheckBoxSelectedValue(false);
      } else {
        setCheckBoxSelectedValue(true);
      }
      disableCheckbox();
    } else {
      setCheckBoxSelectedValue(false);
      setCheckBoxDisabled(false);
    }
  }, [checkBoxSelectedValue, devicestocompare, device]);

  const disableCheckbox = () => {
    const productId = device?.productId || device?.parentProducts?.[0]?.productId || '';
    const isProIdPresent = devicestocompare.filter((product) => product.productId === productId);

    if (isProIdPresent?.length > 0) {
      setCheckBoxDisabled(false);
    } else if (devicestocompare.length >= 4) {
      setCheckBoxDisabled(true);
    } else if (devicestocompare.length < 4) {
      setCheckBoxDisabled(false);
    }
  };

  const addDevicetoCompare = () => {
    const deviceDetails = {};
    deviceDetails.productId = device?.productId || device?.parentProducts?.[0]?.productId || '';
    deviceDetails.imgSrc = imageSrc;
    deviceDetails.brandName = device?.brandName || device?.manufacturer || '';
    deviceDetails.productDisplayName =
      device?.productDisplayName || device?.skuDisplayName || device?.description || '';
    handleCompareCheckboxChange(deviceDetails);
  };

  const removeDeviceFromCompare = () => {
    const productId = device?.productId || device?.parentProducts?.[0]?.productId || '';
    handleRemoveProductFromCompareInGW(productId);
  };

  const handleCheckBoxChange = () => {
    setCheckBoxSelectedValue(!checkBoxSelectedValue);

    if (!checkBoxSelectedValue) {
      addDevicetoCompare();
    } else {
      removeDeviceFromCompare();
    }
  };

  const wifiBackupDisclaimerHandler = () => {
      const sessionValueForWifiBackup = sessionStorage.getItem('fiveGHomeInternetSelectedFlow') === 'WiFi-Backup';
      if (deviceSelection && sessionValueForWifiBackup && is5gLine) {
        sessionStorage.setItem('showWifiDisclaimer', 'TRUE');
      } else {
        sessionStorage.removeItem('showWifiDisclaimer');
      }
  };

  useEffect(() => {
    wifiBackupDisclaimerHandler();
  }, [deviceSelection, is5gLine]);

  const getDeviceDisplayName = () =>
    `${device?.brandName || device?.manufacturer || ''} ${
      device?.productDisplayName ||
      deviceSelection?.description ||
      device?.skuDisplayName ||
      deviceSelection?.deviceDisplayName ||
      trialProductDisplayName ||
      ''
    }`;
  const calMonthlyPrice = remainingMonthPrice || deviceSelection?.deviceDueMonthly || '';
  const itemCost = deviceSelection ? `$${deviceSelection?.itemCost}` : '';
  let contractPrice = '';
  let contractText = '';
  if (
    isVbg() &&
    !calMonthlyPrice &&
    pricingPriority &&
    priceObj?.[pricingPriority]?.originalPrice
  ) {
    contractPrice = `$${priceObj?.[pricingPriority]?.originalPrice}`;
    contractText = priceObj?.[pricingPriority]?.contractText;
  }

  const checkEnrolled = (defaultSKU) => {
    // Store the defaultSKU for later use in useEffect
    setCurrentDefaultSKU(defaultSKU);
    const requestParams = {};

    // Trigger the lazy query hook - This will reset the state and make a fresh call
    checkEnrollmentAPI({
      body: requestParams,
    });
  };

  useEffect(() => {
    const { isSuccess, isError, data, error } = CheckEnrollmentResult;

    handleEnrollmentConditions({
      resultData: data,
      isSuccess,
      isError,
      error,
      currentDefaultSKU,
      checkHuntGroup,
      navigateToProductDetails,
      dispatch,
    });
  }, [CheckEnrollmentResult, currentDefaultSKU]);

  useEffect(() => {
    const { isSuccess, isError, data, error } = CheckHuntGroupResult;
    handleHuntGroupConditions(data, isSuccess, isError, error, navigateToProductDetails, dispatch);
  }, [CheckHuntGroupResult]);

  return (
    <TileWrapper
      data-testid='testDeviceTile'
      onClick={() =>
        handleTileClick({
          isPearl,
          trialProductDisplayName,
          callValidateDeviceSimID,
          vbgnsaOneTalkFFlag,
          isVbgFlag,
          checkOneTalkFn: checkOneTalk,
          navigateToProductDetails,
          device,
          checkEnrolled,
        })
      }
      data-track={`Gridwall-Device-${device?.brandName || ''} ${
        device?.productDisplayName || device?.skuDisplayName || device?.description || ''
      }, ${capacity || ''}`}
    >
      <TileContainer data-testid='testDeviceTileContainer' padding='16px' height='342px' width='100%'>
        {isRecommended && <RecommendedTag>Recommended</RecommendedTag>}
        <Width100>
          {dp24UpgOff && dp24UpgOff === 50 && !isByod && !activeMtn?.includes('newLine') ? (
            <UpgradeAfterBadge>
              <Body size='medium' color='#ffffff' bold>
                Upgrade after 50%
              </Body>
            </UpgradeAfterBadge>
          ) : null}
          {selfProfChildren}
          {isByod && (
            <Body size='medium' color='#000000' bold>
              {isBytdDeviceAdded ? '' : 'BYOD device'}
            </Body>
          )}
          {deviceSelection?.productId && (
            <SelectedWrapper>
              <Icon name='checkmark' size='small' color='#ffffff' />
            </SelectedWrapper>
          )}
          <DeviceWrapper>
            <ImgWrapper>
              <StyledImg
                src={imageSrc}
                tabIndex={gridwallAccessibleFFlag ? '0' : ''}
                role={gridwallAccessibleFFlag ? 'button' : ''}
                aria-label={gridwallAccessibleFFlag ? `${getDeviceDisplayName()}` : ''}
                alt='deviceslogo'
              />
            </ImgWrapper>
            {checkProfessionalInstallDevice(device) && (
              <ProfessionalInstallTag>Professional Installation</ProfessionalInstallTag>
            )}
            <DetailsWrapper>
              <Ellipsis role={gridwallAccessibleFFlag ? 'heading' : ''}>
                <Body size='medium' color='#000000' bold style={{ marginTop: '20px' }}>
                    <DisplayName displayName={getDeviceDisplayName()}/>
                </Body>
              </Ellipsis>
              <Body style={{ overflow: 'visible' }}>
                {isPearl && (
                  <LabelWrapper>
                    <Body size='large' className='bold'>
                      {isBytdDeviceAdded || trialProductDisplayName ? 'Bring your trial Device' : ''}
                    </Body>
                  </LabelWrapper>
                )}
                {is5gLine &&
                  displayProfSetupCharges &&
                  !oneTimeOfferProInstallFFlag &&
                  deviceName?.includes('Professional') &&
                  !isTGWFlow && (
                    <div style={{ marginTop: '-24px' }}>
                      <span
                        className='font-18 w-100 bold u-textLineHeightNormal'
                        dangerouslySetInnerHTML={{
                          __html: decodeHTMLEntities(
                            `${fiveGProfInstallCharges?.profInstallCharge}<br/>${fiveGProfInstallCharges?.taxesAndFees}`
                          ),
                        }}
                      />
                      <span
                        className='labelHeight font-13'
                        dangerouslySetInnerHTML={{
                          __html: decodeHTMLEntities(`<br />${fiveGProfInstallCharges?.installDescription}`),
                        }}
                      />
                    </div>
                  )}
                {is5gLine &&
                  displayProfSetupCharges &&
                  oneTimeOfferProInstallFFlag &&
                  deviceName?.includes('Professional') &&
                  !isTGWFlow && (
                    <div style={{ marginTop: '-24px' }}>
                      <span
                        className='font-18 w-100 u-textLineHeightNormal strikeText'
                        style={{ textDecoration: 'line-through', color: '#959595' }}
                        data-testid='displayStrikedOffCharge'
                        dangerouslySetInnerHTML={{
                          __html: decodeHTMLEntities(`${fiveGProfInstallCharges?.profInstallStrikedAmt}`),
                        }}
                      />
                      <span
                        className='font-19 bold'
                        data-testid='displayZeroCharge'
                        dangerouslySetInnerHTML={{
                          __html: decodeHTMLEntities(`${fiveGProfInstallCharges?.zeroDollarAmount}`),
                        }}
                      />
                      <br />
                      <span
                        className='labelHeight font-14'
                        dangerouslySetInnerHTML={{
                          __html: decodeHTMLEntities(`${fiveGProfInstallCharges?.limitedTimeOffer}`),
                        }}
                      />
                    </div>
                  )}
                {is5gLine && displayProfSetupCharges && deviceName?.includes('Professional') && isTGWFlow && (
                  <div>
                    <span
                      className='labelHeight font-13'
                      dangerouslySetInnerHTML={{
                        __html: decodeHTMLEntities(`<br />${fiveGProfInstallCharges?.freeofCharge}`),
                      }}
                    />
                  </div>
                )}
              </Body>
            </DetailsWrapper>
            {!(
              cartDetails?.cart?.cartHeader?.locationSubType === 'GN' &&
              cartDetails?.cart?.cartHeader?.maid === 'BBX' &&
              bestBuyIntegrationFFlag === 'TRUE'
            ) && (
              <DetailsWrapper>
                {commonInfo?.showPrice && !isByod && (
                  <>
                    <FlexJustify>
                      {!is5gLine && (
                        <Body size='medium' bold>
                          {calMonthlyPrice ? `$${calMonthlyPrice}/mo.` : contractPrice}
                        </Body>
                      )}
                      {!is5gLine && (
                        <Body size='medium' bold>
                          {priceObj?.fullRetailPrice?.originalPrice
                            ? `$${priceObj?.fullRetailPrice?.originalPrice}`
                            : itemCost}
                        </Body>
                      )}
                    </FlexJustify>
                    <FlexJustify>
                      {!is5gLine && (
                        <Body size='medium' color='#6F7171'>
                          {calMonthlyPrice ? `for ${contractTerm} mos` : contractText}
                        </Body>
                      )}
                      {!is5gLine && (priceObj?.fullRetailPrice?.originalPrice || deviceSelection) && (
                        <Body size='medium' color='#6F7171'>
                          Retail price
                        </Body>
                      )}
                      {is5gLine && priceObj?.fullRetailPrice?.originalPrice >= 0 && (
                        <Body size='medium' color='#6F7171'>
                          <div
                            className='bold'
                            style={
                              is5gLine
                                ? {
                                    position: 'absolute',
                                    bottom: 20,
                                    right: 20,
                                    width: '100px',
                                    textAlign: 'right',
                                  }
                                : ''
                            }
                          >
                            ${priceObj?.fullRetailPrice?.originalPrice}
                            <p>Retail price </p>
                          </div>
                        </Body>
                      )}
                    </FlexJustify>
                    {elvisFFlag === true && (
                      <Body size='small' color='#6F7171'>
                        may incl. interest
                      </Body>
                    )}
                  </>
                )}
              </DetailsWrapper>
            )}
            {!isByod && !is5gLine && (
              <CheckboxWrapper data-testid='checkbox'>
                <Checkbox
                  name='default'
                  width='auto'
                  label=''
                  error={false}
                  selected={checkBoxSelectedValue}
                  disabled={checkBoxDisabled || isPearl}
                  onChange={() => handleCheckBoxChange()}
                  data-track={`Gridwall-Comapre Device-${device?.brandName || ''} ${
                    device?.productDisplayName || device?.skuDisplayName || device?.description || ''
                  }, ${capacity || ''}`}
                >
                  <LabelWrapper>
                    <Body size='medium' color='#6F7171'>
                      <span aria-label={gridwallAccessibleFFlag ? `${getDeviceDisplayName()}` : ''} />
                      Compare
                    </Body>
                  </LabelWrapper>
                </Checkbox>
              </CheckboxWrapper>
            )}
          </DeviceWrapper>
        </Width100>
      </TileContainer>
    </TileWrapper>
  );
}
DeviceTile.propTypes = {
  cartDetails: PropTypes.shape({
    cart: PropTypes.shape({
      cartHeader: PropTypes.shape({
        maid: PropTypes.string.isRequired,
      }),
    }),
  }),
  activeMtn: PropTypes.string,
};
export default DeviceTile;
