import { fireEvent, render, screen } from '../../../modules/test-utils/renderHelper';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import TakeOverScreen from './TakeOverScreen';

describe('ESimUI', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });
  const depletionType = 'L';
  it('should test ESimUI', async () => {
    const handleClickDone = jest.fn();
    const handleCloseFunc = jest.fn();

    render(
      <TakeOverScreen
        isDualSimEntiLookupModalVisible
        handleCloseFunc={handleCloseFunc}
        disableESIM
        handleClickDone={handleClickDone}
        depletionType={depletionType}
        isBYOD='BYOD'
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(await screen.findByRole('button', { name: 'Close' }));
    expect(handleClickDone).toBeCalledTimes(0);
  });
  it('should test ESimUI and disableESIM is false ', async () => {
    const handleClickDone = jest.fn();
    const handleCloseFunc = jest.fn();
    render(<TakeOverScreen disableESIM={false} handleClickDone={handleClickDone} handleCloseFunc={handleCloseFunc} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    fireEvent.click(await screen.findByRole('button', { name: 'Close' }));
    expect(handleClickDone).toBeCalledTimes(0);
    // fireEvent.click(screen.getByText('A physical SIM card'));
  });
  it('should display the correct message for depletionType F', async () => {
    const handleCloseFunc = jest.fn();
    render(<TakeOverScreen handleCloseFunc={handleCloseFunc} depletionType='F' />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    expect(
      await screen.findByText('Local and Direct Fulfillment Orders must be processed separately'),
    ).toBeInTheDocument();
  });
  it('should display the correct message for depletionType F', async () => {
    const handleCloseFunc = jest.fn();
    render(<TakeOverScreen handleCloseFunc={handleCloseFunc} channel='OMNI-INDIRECT' />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    expect(await screen.findByText('Cannot place d-fill order by clicking Local Order button')).toBeInTheDocument();
  });
  it('should display the correct message for BYOD', async () => {
    const handleCloseFunc = jest.fn();
    render(<TakeOverScreen handleCloseFunc={handleCloseFunc} isBYOD='BYOD' />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    expect(await screen.findByText('Cannot place BYOD order by clicking Local Order button')).toBeInTheDocument();
  });

  it('should call handleCloseFunc when Close button is clicked', async () => {
    const handleCloseFunc = jest.fn();
    render(<TakeOverScreen handleCloseFunc={handleCloseFunc} depletionType='L' />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    fireEvent.click(await screen.findByRole('button', { name: 'Close' }));
    expect(handleCloseFunc).toBeCalledTimes(1);
  });
});
