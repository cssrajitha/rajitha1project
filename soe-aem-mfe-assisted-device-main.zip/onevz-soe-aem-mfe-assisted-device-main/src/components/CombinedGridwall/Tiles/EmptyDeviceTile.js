import React from 'react';
import styled from 'styled-components';
import { Title } from '@vds/typography';
import { TileContainer } from '@vds/tiles';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { FlexBoxColumn, TileWrapper, ImgWrapper } from '../FlexGlobalStyledConstants';
import CustomDeviceLogo from './customdevice.svg';

const TitleWrapper = styled.div`
  text-align: center;
  width: 8rem;
`;

const EmptyDeviceTile = ({ isPearl, addYourDevice, elvisFFlag, TakeOverScreenFunc, channel }) => {
  const [bestBuyIntegrationFFlag] = getAssistedCradlePropertyV2(['bestBuyIntegrationFFlag']);
  return (
    <TileWrapper data-track='Gridwall-BYOD-Tile' data-testid='EmptyDeviceTile'>
      <TileContainer
        padding='1rem'
        height={elvisFFlag === true ? '358px' : '342px'}
        onClick={() => {
          // Check if we need to take over screen (based on your DeviceTile logic)
          if (bestBuyIntegrationFFlag === 'TRUE' && (channel === 'OMNI-INDIRECT' || channel === 'OMNI-INDIRECT-TAB')) {
            TakeOverScreenFunc('BYOD');
          } else {
            addYourDevice();
          }
        }}
        ariaLabel='Bring Your Own Device'
      >
        <FlexBoxColumn>
          <ImgWrapper>
            <img src={CustomDeviceLogo} alt='custom Device' width='62px' height='132px' />
          </ImgWrapper>
          <TitleWrapper>
            {isPearl ? (
              <Title bold size='small'>
                Bring a new Device
              </Title>
            ) : (
              <Title bold size='small'>
                Bring Your Own Device
              </Title>
            )}
          </TitleWrapper>
        </FlexBoxColumn>
      </TileContainer>
    </TileWrapper>
  );
};
export default EmptyDeviceTile;
