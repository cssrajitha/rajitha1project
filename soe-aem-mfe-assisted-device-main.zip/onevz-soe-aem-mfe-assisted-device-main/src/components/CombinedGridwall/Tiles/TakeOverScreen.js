import React from 'react';
import { Button } from '@vds/buttons';
import styled from 'styled-components';
import { Modal, ModalBody } from '@vds/modals';

const ButtonWrapper = styled.div`
  display: flex;
  justify-content: flex-start;
  gap: 0.75rem;
  padding-bottom: 2px;
  margin-top: 1.5rem;
`;

const ButtonStyle = styled.div`
  [class^='StyledButton-'] {
    padding: 0.125rem 1.3125rem;
    min-width: 9.375rem;
  }
`;

function TakeOverSCreen(props) {
  const handleClickDone = () => {
    props.handleCloseFunc();
  };
  console.log('props from takeover', props);
  let message = '';

  if (props.depletionType === 'L') {
    message = 'Multiline ordering is not available. Please create a separate order.';
  } else if (props.depletionType === 'F') {
    message = 'Local and Direct Fulfillment Orders must be processed separately';
  } else if (props?.isBYOD === 'BYOD') {
    message = 'This is not supported in the Local Order flow. Please initiate order from "Shop" button.';
  } else if (props.channel === 'OMNI-INDIRECT' || props.channel === 'OMNI-INDIRECT-TAB') {
    message = 'Cannot place d-fill order by clicking Local Order button';
  }

  return (
    <div data-testid='IdSecureScan' className='IdModalScan' style={{ zIndex: '999' }}>
      <Modal
        surface='light'
        fullScreenDialog={false}
        disableAnimation={false}
        hideCloseButton={false}
        disableOutsideClick
        ariaLabel='Testing Modal'
        opened
        width='100%'
        onOpenedChange={() => handleClickDone}
      >
        <ModalBody>
          <div className='Col Col-lg-12 u-text18 u-paddingTop u-marginTop'>{message}</div>
        </ModalBody>
        <ButtonWrapper>
          <ButtonStyle>
            <Button
              data-track='eSIM_Continue'
              data-testid='continue-button'
              size='large'
              inverted={false}
              disabled={false}
              use='secondary'
              onClick={() => handleClickDone()}
            >
              Close
            </Button>
          </ButtonStyle>
        </ButtonWrapper>
      </Modal>
    </div>
  );
}

export default TakeOverSCreen;
