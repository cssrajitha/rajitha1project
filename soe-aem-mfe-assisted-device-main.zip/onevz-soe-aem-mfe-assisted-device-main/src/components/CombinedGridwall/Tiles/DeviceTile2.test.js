import React from 'react';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import DeviceTile from './DeviceTile';
import { fireEvent, render, screen } from '../../../modules/test-utils/renderHelper';

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradleProperty: () => ['TRUE', 'TRUE'],
  }),
  { virtual: true },
);
jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    getQueryParamByName: () => null,
    isIndirect: () => true,
  }),
  { virtual: true },
);

describe('device model component disclaimer', () => {
  const props = {
    deviceSelection: {
      price: { devicePaymentPrice: [{ dpTermPrices: { firstMonthPrice: {}, dpTerm: {} } }], preferredTerm: {} },
      productId: '123',
    },
    devicestocompare: [{ productId: '123' }],
    device: {
      productId: '123',
      searchedSku: '123',
      childSkus: [{ sorId: '123' }],
      productDisplayName: 'Professional',
    },
    activeMtn: '123',
    totalLines: [
      {
        mobileNumber: '123',
        deviceTypeSelected: '5G Internet',
        tanglewoodSelected: 'Y',
      },
    ],
    handleCompareCheckboxChange: jest.fn(),
  };
  beforeEach(() => {
    Object.defineProperty(window, 'mfe', {
      value: { scmDeviceMfeEnable: false },
      configurable: true,
    });
    window.sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'WiFi-Backup');

    window.mfe.historyRef = jest.fn();
    render(<DeviceTile {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('component should render', () => {
    const text = screen.getByRole('img', { name: /checkmark icon/i });
    expect(text).toBeInTheDocument();
  });
  test('navigate to product details functiona call', () => {
    window.mfe.scmDeviceMfeEnable = false;
    window.mfe.scmUpgradeMfeEnable = false;
    const productDetails = screen.getByTestId('testDeviceTile');
    expect(productDetails).toBeInTheDocument();
    fireEvent.click(productDetails);
  });
});
describe('device model component without disclaimer', () => {
  const props = {
    deviceSelection: {
      price: { devicePaymentPrice: [{ dpTermPrices: { firstMonthPrice: {}, dpTerm: {} } }], preferredTerm: {} },
      productId: '123',
    },
    devicestocompare: [{ productId: '123' }],
    device: {
      productId: '123',
      searchedSku: '123',
      childSkus: [{ sorId: '123' }],
      productDisplayName: 'Professional',
    },
    activeMtn: '123',
    totalLines: [
      {
        mobileNumber: '123',
        deviceTypeSelected: '5G Internet',
        tanglewoodSelected: 'Y',
      },
    ],
    handleCompareCheckboxChange: jest.fn(),
  };
  beforeEach(() => {
    Object.defineProperty(window, 'mfe', {
      value: { scmDeviceMfeEnable: false },
      configurable: true,
    });
    window.sessionStorage.setItem('fiveGHomeInternetSelectedFlow', '5G-Internet');

    window.mfe.historyRef = jest.fn();
    render(<DeviceTile {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('component should render', () => {
    const text = screen.getByRole('img', { name: /checkmark icon/i });
    expect(text).toBeInTheDocument();
  });
  test('navigate to product details functiona call', () => {
    window.mfe.scmDeviceMfeEnable = false;
    window.mfe.scmUpgradeMfeEnable = false;
    const productDetails = screen.getByTestId('testDeviceTile');
    expect(productDetails).toBeInTheDocument();
    fireEvent.click(productDetails);
  });
});
