import React from 'react';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import { render, screen, fireEvent } from '../../../modules/test-utils/renderHelper';
import EmptyDeviceTile from './EmptyDeviceTile';

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradlePropertyV2: () => ['TRUE', 'TRUE'],
  }),
  { virtual: true },
);
describe('EmptyDeviceTile component', () => {
  const isPearl = true;
  const addYourDevice = jest.fn();
  const TakeOverScreenFunc = jest.fn();
  const props = {
    cartDetails: {
      cart: {
        cartHeader: { locationSubType: 'GN', maid: 'BBX' },
        lineDetails: { lineInfo: [{ itemsInfo: [{ depletionType: 'L' }] }] },
      },
    },
  };
  beforeEach(() => {
    render(
      <EmptyDeviceTile
        isPearl={isPearl}
        addYourDevice={addYourDevice}
        TakeOverScreenFunc={TakeOverScreenFunc}
        props={props}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
  });

  test('it should render EmptyDeviceTile for pearl', () => {
    const EmptyDeviceTiles = screen.getByTestId('EmptyDeviceTile');
    expect(EmptyDeviceTiles).toBeInTheDocument();
  });
});

describe('EmptyDeviceTile component for non Pearl', () => {
  const isPearl = false;
  const addYourDevice = jest.fn();
  const TakeOverScreenFunc = jest.fn();
  const props = {
    cartDetails: {
      cart: {
        cartHeader: { locationSubType: 'GN', maid: 'BBX' },
        lineDetails: { lineInfo: [{ itemsInfo: [{ depletionType: 'L' }] }] },
      },
    },
  };
  beforeEach(() => {
    render(
      <EmptyDeviceTile
        isPearl={isPearl}
        addYourDevice={addYourDevice}
        TakeOverScreenFunc={TakeOverScreenFunc}
        props={props}
        channel='OMNI-INDIRECT-TAB'
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
  });

  test('it should render EmptyDeviceTile', () => {
    const EmptyDeviceTiles = screen.getByTestId('EmptyDeviceTile');
    expect(EmptyDeviceTiles).toBeInTheDocument();
  });
  test('it should render EmptyDeviceTile for pearl', () => {
    const EmptyDeviceTiles = screen.getByTestId('EmptyDeviceTile');
    expect(EmptyDeviceTiles).toBeInTheDocument();
  });
  test('it should render EmptyDeviceTile', () => {
    const EmptyDeviceTiles = screen.getByRole('button', { name: 'Bring Your Own Device' });
    expect(EmptyDeviceTiles).toBeInTheDocument();
    fireEvent.click(EmptyDeviceTiles);
  });
});

describe('EmptyDeviceTile component with Elvis true', () => {
  const isPearl = true;
  const addYourDevice = jest.fn();
  const TakeOverScreenFunc = jest.fn();
  const props = {
    cartDetails: {
      cart: {
        cartHeader: { locationSubType: 'GN', maid: 'BBX' },
        lineDetails: { lineInfo: [{ itemsInfo: [{ depletionType: 'L' }] }] },
      },
    },
  };
  beforeEach(() => {
    render(
      <EmptyDeviceTile
        isPearl={isPearl}
        addYourDevice={addYourDevice}
        elvisFFlag
        TakeOverScreenFunc={TakeOverScreenFunc}
        props={props}
        channel='OMNI-INDIRECT-TAB'
      />,
    );
  });

  test('it should render EmptyDeviceTile', () => {
    const EmptyDeviceTiles = screen.getByTestId('EmptyDeviceTile');
    expect(EmptyDeviceTiles).toBeInTheDocument();
  });
});
