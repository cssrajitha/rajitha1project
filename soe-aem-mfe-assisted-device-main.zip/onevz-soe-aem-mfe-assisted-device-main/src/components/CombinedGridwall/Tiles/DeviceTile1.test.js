import React from 'react';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import DeviceTile from './DeviceTile';
import { fireEvent, render, screen } from '../../../modules/test-utils/renderHelper';
import { getDpTermIndex, getPricingPriority } from '../../../modules/utils/devicePricingUtils';
import { isVbg } from 'onevzsoemfeframework/VbgAemUtil';

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradleProperty: () => ['FALSE', 'TRUE'],
  }),
  { virtual: true },
);
jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    getQueryParamByName: () => null,
    isIndirect: () => true,
  }),
  { virtual: true },
);

jest.mock('onevzsoemfeframework/VbgAemUtil', () => ({
  __esModule: true,
  ...jest.requireActual('onevzsoemfeframework/VbgAemUtil'),
  isVbg: jest.fn().mockReturnValue(false),
}));

jest.mock('../../../modules/utils/devicePricingUtils', () => ({
  getPricingPriority: jest.fn().mockReturnValue(null),
  getDpTermIndex: jest.fn().mockReturnValue(-1),
}));

describe('device model component render', () => {
  const props = {
    deviceSelection: {
      price: { devicePaymentPrice: [{ dpTermPrices: { firstMonthPrice: {}, dpTerm: {} } }], preferredTerm: {} },
      productId: '123',
    },
    devicestocompare: [{ productId: '123' }],
    device: {
      productId: '123',
      searchedSku: '123',
      childSkus: [{ sorId: '123' }],
      productDisplayName: 'Professional',
    },
    activeMtn: '123',
    isDWOS: true,
    totalLines: [
      {
        mobileNumber: '123',
        deviceTypeSelected: '5G Internet',
        tanglewoodSelected: 'Y',
      },
    ],
    handleCompareCheckboxChange: jest.fn(),
  };
  beforeAll(() => {
    window.mfe = {
      historyRef: {
        push: jest.fn(), // Mock the push method
      },
    };
  });
  beforeEach(() => {
    Object.defineProperty(window, 'mfe', {
      value: { scmDeviceMfeEnable: true },
      configurable: true,
    });
    window.mfe.historyRef = jest.fn();
    isVbg.mockReturnValue(true);
    render(<DeviceTile {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('component should render', () => {
    const text = screen.getByRole('img', { name: /checkmark icon/i });
    expect(text).toBeInTheDocument();
  });
  test('navigate to product details functiona call failed test', () => {
    window.mfe.scmDeviceMfeEnable = true;
    window.mfe.historyRef.push = jest.fn();
    const productDetails = screen.getByTestId('testDeviceTile');
    expect(productDetails).toBeInTheDocument();
    fireEvent.click(productDetails);
  });
});
describe('device model component render 11', () => {
  const props = {
    deviceSelection: {
      price: { devicePaymentPrice: [{ dpTermPrices: { firstMonthPrice: {}, dpTerm: {} } }], preferredTerm: {} },
      productId: '123',
    },
    devicestocompare: [{ productId: '123' }],
    device: {
      productId: '123',
      searchedSku: '123',
      childSkus: [{ sorId: '123' }],
      productDisplayName: 'Professional',
    },
    activeMtn: '123',
    totalLines: [
      {
        mobileNumber: '123',
        deviceTypeSelected: '5G Internet',
        tanglewoodSelected: 'Y',
      },
    ],
    handleCompareCheckboxChange: jest.fn(),
  };
  beforeEach(() => {
    Object.defineProperty(window, 'mfe', {
      value: { scmDeviceMfeEnable: false },
      configurable: true,
    });
    window.mfe.historyRef = jest.fn();
    isVbg.mockReturnValue(false);
    render(<DeviceTile {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('component should render', () => {
    const text = screen.getByRole('img', { name: /checkmark icon/i });
    expect(text).toBeInTheDocument();
  });
  test('navigate to product details functiona call', () => {
    window.mfe.scmDeviceMfeEnable = false;
    window.mfe.scmUpgradeMfeEnable = false;
    const productDetails = screen.getByTestId('testDeviceTile');
    expect(productDetails).toBeInTheDocument();
    fireEvent.click(productDetails);
  });
});
describe('device model component render 111', () => {
  const props = {
    deviceSelection: {
      price: { devicePaymentPrice: [{ dpTermPrices: { firstMonthPrice: {}, dpTerm: {} } }], preferredTerm: {} },
      productId: '123',
    },
    devicestocompare: [{ productId: '123' }],
    device: {
      productId: '123',
      searchedSku: '123',
      childSkus: [{ sorId: '123' }],
      productDisplayName: 'Professional',
    },
    activeMtn: '123',
    totalLines: [
      {
        mobileNumber: '',
        deviceTypeSelected: '4G Internet',
        tanglewoodSelected: 'Y',
      },
    ],
    handleCompareCheckboxChange: jest.fn(),
  };
  beforeAll(() => {
    window.mfe = {
      historyRef: {
        push: jest.fn(), // Mock the push method
      },
    };
  });
  beforeEach(() => {
    Object.defineProperty(window, 'mfe', {
      value: { scmUpgradeMfeEnable: true, scmDeviceMfeEnable: true },
      configurable: true,
    });
    window.mfe.historyRef = jest.fn();
    isVbg.mockReturnValue(false);
    render(<DeviceTile {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('component should render', () => {
    const text = screen.getByRole('img', { name: /checkmark icon/i });
    expect(text).toBeInTheDocument();
  });
  test('navigate to product details functiona call', () => {
    window.mfe.scmDeviceMfeEnable = true;
    window.mfe.scmUpgradeMfeEnable = true;
    window.mfe.historyRef.push = jest.fn();
    const productDetails = screen.getByTestId('testDeviceTile');
    expect(productDetails).toBeInTheDocument();
    fireEvent.click(productDetails);
  });
});
describe('device model component render 1', () => {
  const props = {
    deviceSelection: {
      price: { devicePaymentPrice: [{ dpTermPrices: { firstMonthPrice: {}, dpTerm: {} } }], preferredTerm: {} },
      productId: '123',
      childSkus: [{ skuId: 'IPXL' }],
    },
    selectedSkuId: 'IPXL',
    devicestocompare: [{ productId: '123' }],
    device: {
      productId: '',
      searchedSku: '123',
      childSkus: [{ sorId: '123' }],
      productDisplayName: 'Professional',
    },
    activeMtn: '123',
    totalLines: [
      {
        mobileNumber: '123',
        deviceTypeSelected: '5G Internet',
      },
    ],
    handleCompareCheckboxChange: jest.fn(),
  };
  beforeAll(() => {
    window.mfe = {
      historyRef: {
        push: jest.fn(), // Mock the push method
      },
    };
  });
  beforeEach(() => {
    window.mfe.historyRef = jest.fn();
    isVbg.mockReturnValue(false);
    render(<DeviceTile {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('component should render', () => {
    const text = screen.getByRole('img', { name: /checkmark icon/i });
    expect(text).toBeInTheDocument();
  });
  test('navigate to product details functiona call', () => {
    const productDetails = screen.getByTestId('testDeviceTile');
    expect(productDetails).toBeInTheDocument();
    fireEvent.click(productDetails);
  });
});
describe('device model component render 2', () => {
  const props = {
    deviceSelection: {
      price: {
        devicePaymentPrice: [{ dpTermPrices: { firstMonthPrice: {}, dpTerm: {}, upgradeOptionPercentage: 50 } }],
        fullRetailPrice: { originalPrice: 123 },
      },
    },
    device: {
      productId: '',
      defaultSKU: '123',
      childSkus: [{ sorId: '123' }],
      productDisplayName: 'Hum',
    },
    isBundleGW: true,
    handleCompareCheckboxChange: jest.fn(),
    commonInfo: { showPrice: true },
  };
  beforeEach(() => {
    window.mfe.historyRef = jest.fn();
    Object.defineProperty(window, 'location', {
      value: new URL('http://example.com/sales/assisted/new/device/gridwall.html?isBundledGW=true'),
      configurable: true,
    });
    isVbg.mockReturnValue(false);
    render(<DeviceTile {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('component should render', () => {
    const text = screen.getByText(/Compare/i);
    expect(text).toBeInTheDocument();
  });
  test('navigate to product details functiona call', () => {
    const productDetails = screen.getByTestId('testDeviceTile');
    const checkbox = screen.getByRole('checkbox');
    fireEvent.click(productDetails);
    expect(checkbox).toBeInTheDocument();
    fireEvent.click(checkbox, { target: { value: 'name' } });
    expect(checkbox).toBeInTheDocument();
  });
});
describe('device model component render 3', () => {
  const props = {
    deviceSelection: {
      price: { devicePaymentPrice: [{ dpTermPrices: { firstMonthPrice: {}, dpTerm: {} } }], preferredTerm: {} },
      productId: '123',
      childSkus: [{ skuId: 'IPXL' }],
    },
    selectedSkuId: 'IPXL',
    devicestocompare: [{ productId: '123' }],
    activeMtn: '123',
    totalLines: [
      {
        mobileNumber: '123',
        deviceTypeSelected: '5G Internet',
        itemsInfo: [{ cartItems: { cartItem: [{ cartItemType: 'SIM' }] }, simId: '87898798798798797' }],
      },
    ],
    handleCompareCheckboxChange: jest.fn(),
  };
  beforeEach(() => {
    window.mfe.historyRef = jest.fn();
    isVbg.mockReturnValue(false);
    render(<DeviceTile {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('component should render', () => {
    const text = screen.getByRole('img', { name: /checkmark icon/i });
    expect(text).toBeInTheDocument();
  });
  test('navigate to product details functiona call', () => {
    const productDetails = screen.getByTestId('testDeviceTile');
    expect(productDetails).toBeInTheDocument();
    fireEvent.click(productDetails);
  });
});
describe('device model component render for isPearl as true', () => {
  const props = {
    deviceSelection: {
      price: { devicePaymentPrice: [{ dpTermPrices: { firstMonthPrice: {}, dpTerm: {} } }], preferredTerm: {} },
      productId: '123',
      childSkus: [{ skuId: 'IPXL' }],
    },
    selectedSkuId: 'IPXL2',
    devicestocompare: [{ productId: '123' }],
    activeMtn: '123',
    trialProductDisplayName: 'iPhone 14 Pro',
    isPearl: true,
    totalLines: [
      {
        mobileNumber: '123',
        deviceTypeSelected: '5G Internet',
        itemsInfo: [{ cartItems: { cartItem: [{ cartItemType: 'SIM' }] }, simId: '87898798798798797' }],
      },
    ],
    validateDeviceSimIdRequest: jest.fn(),
    handleCompareCheckboxChange: jest.fn(),
  };
  beforeEach(() => {
    window.mfe.historyRef = jest.fn();
    isVbg.mockReturnValue(false);
    render(<DeviceTile {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('component should render', () => {
    const text = screen.getByRole('img', { name: /checkmark icon/i });
    expect(text).toBeInTheDocument();
  });
  test('navigate to product details functiona call', () => {
    const productDetails = screen.getByTestId('testDeviceTile');
    expect(productDetails).toBeInTheDocument();
    fireEvent.click(productDetails);
  });
});
describe('DeviceTile DPP and contractPrice logic', () => {
  it('should show next DPP price available when isVbg() is true and pricingPriority is devicePaymentPrice', () => {
    const priceObj = {
      devicePaymentPrice: [
        {
          dpTermPrices: {
            firstMonthPrice: 300,
            dpTerm: 24,
            remainingMonthPrice: 100,
          },
        },
      ],
      fullRetailPrice: { originalPrice: 2000, contractText: 'Full Retail Price' },
    };

    const device = {
      productId: 'p1',
      brandName: 'Brand',
      productDisplayName: 'Device Name',
      defaultSKUObj: {
        price: priceObj,
        imageUrlMap: { thumbImage: 'img.png' },
        capacity: '128GB',
      },
      imageUrlMap: { thumbImage: 'img.png' },
      capacity: '128GB',
      childSkus: [{ skuId: 'sku1', price: priceObj }],
    };

    const deviceSelection = {
      childSkus: [{ skuId: 'sku1', price: priceObj }],
      price: priceObj,
      capacity: '128GB',
      productId: 'p1',
      itemCost: 2000,
    };

    isVbg.mockReturnValue(true);
    getPricingPriority.mockReturnValue('devicePaymentPrice');
    getDpTermIndex.mockReturnValue(0);

    render(
      <DeviceTile
        device={device}
        deviceSelection={deviceSelection}
        activeMtn="123"
        devicestocompare={[]}
        totalLines={[]}
        handleCompareCheckboxChange={jest.fn()}
        commonInfo={{ showPrice: true }}
      />
    );

    // contractPrice and contractText should be rendered
    expect(screen.getByText('$100/mo.')).toBeInTheDocument();
    expect(screen.getByText('for 24 mos')).toBeInTheDocument();
    expect(screen.getByText('$2000')).toBeInTheDocument();
    expect(screen.getByText('Retail price')).toBeInTheDocument();
  });
  it('should show one year price when isVbg() is true and pricingPriority is not devicePaymentPrice', () => {
    const priceObj = {
      devicePaymentPrice: [],
      oneYearPrice: {
        originalPrice: 500,
        contractText: 'One Year Price',
      },
      fullRetailPrice: {
        originalPrice: 2000,
        contractText: 'Full Retail Price'
      },
    };

    const device = {
      productId: 'p1',
      brandName: 'Brand',
      productDisplayName: 'Device Name',
      defaultSKUObj: {
        price: priceObj,
        imageUrlMap: { thumbImage: 'img.png' },
        capacity: '128GB',
      },
      imageUrlMap: { thumbImage: 'img.png' },
      capacity: '128GB',
      childSkus: [{ skuId: 'sku1', price: priceObj }],
    };

    const deviceSelection = {
      childSkus: [{ skuId: 'sku1', price: priceObj }],
      price: priceObj,
      capacity: '128GB',
      productId: 'p1',
      itemCost: 2000,
    };

    isVbg.mockReturnValue(true);
    getPricingPriority.mockReturnValue('oneYearPrice');
    getDpTermIndex.mockReturnValue(-1);

    render(
      <DeviceTile
        device={device}
        deviceSelection={deviceSelection}
        activeMtn="123"
        devicestocompare={[]}
        totalLines={[]}
        handleCompareCheckboxChange={jest.fn()}
        commonInfo={{ showPrice: true }}
      />
    );

    // contractPrice and contractText should be rendered
    expect(screen.getByText('$500')).toBeInTheDocument();
    expect(screen.getByText('One Year Price')).toBeInTheDocument();
    expect(screen.getByText('$2000')).toBeInTheDocument();
    expect(screen.getByText('Retail price')).toBeInTheDocument();
  });
  it('should show 36 month DPP price when isVbg() is false', () => {
    const priceObj = {
      devicePaymentPrice: [
        {
          dpTermPrices: {
            firstMonthPrice: 300,
            dpTerm: 36,
            remainingMonthPrice: 100,
          },
        },
      ],
      fullRetailPrice: { originalPrice: 2000, contractText: 'Full Retail Price' },
    };

    const device = {
      productId: 'p1',
      brandName: 'Brand',
      productDisplayName: 'Device Name',
      defaultSKUObj: {
        price: priceObj,
        imageUrlMap: { thumbImage: 'img.png' },
        capacity: '128GB',
      },
      imageUrlMap: { thumbImage: 'img.png' },
      capacity: '128GB',
      childSkus: [{ skuId: 'sku1', price: priceObj }],
    };

    const deviceSelection = {
      childSkus: [{ skuId: 'sku1', price: priceObj }],
      price: priceObj,
      capacity: '128GB',
      productId: 'p1',
      itemCost: 2000,
    };

    isVbg.mockReturnValue(false);
    getPricingPriority.mockReturnValue('');
    getDpTermIndex.mockReturnValue(-1);

    render(
      <DeviceTile
        device={device}
        deviceSelection={deviceSelection}
        activeMtn="123"
        devicestocompare={[]}
        totalLines={[]}
        handleCompareCheckboxChange={jest.fn()}
        commonInfo={{ showPrice: true }}
      />
    );

    // contractPrice and contractText should be rendered
    expect(screen.getByText('$100/mo.')).toBeInTheDocument();
    expect(screen.getByText('for 36 mos')).toBeInTheDocument();
    expect(screen.getByText('$2000')).toBeInTheDocument();
    expect(screen.getByText('Retail price')).toBeInTheDocument();
  })
});
