import React from 'react';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import {  decodeHTMLEntities } from 'onevzsoemfecommon/Helpers';


function DisplayName ({ displayName })  {
    const gridwalHtmlParserFFlag = /true/i.test(getAssistedCradlePropertyV2(['gridwalHtmlParserFFlag'])?.[0]);

    return (
        <div>
            {gridwalHtmlParserFFlag ?
                <span dangerouslySetInnerHTML={{ __html: decodeHTMLEntities(displayName) }} /> :
                displayName
            }
        </div>
    )
};

export default DisplayName;