export const brandName = [
  {
    label: 'Samsung',
    value: 'Samsung',
  },
  {
    label: 'Apple',
    value: 'Apple',
  },
  {
    label: 'Motorola',
    value: 'Motorola',
  },
  {
    label: 'Google',
    value: 'Google',
  },
  {
    label: 'Kyocera',
    value: 'Kyocera',
  },
  {
    label: 'Nokia',
    value: 'Nokia',
  },
  {
    label: 'TCL',
    value: 'TCL',
  },
  {
    label: 'Alcatel',
    value: 'Alcatel',
  },
  {
    label: 'CAT',
    value: 'CAT',
  },
  {
    label: 'LG',
    value: 'LG',
  },
  {
    label: 'ODI Device',
    value: 'ODI Device',
  },
  {
    label: 'Orbic',
    value: 'Orbic',
  },
  {
    label: 'Palm',
    value: 'Palm',
  },
  {
    label: 'Sonim',
    value: 'Sonim',
  },
  {
    label: 'Zebra',
    value: 'Zebra',
  },
];

export const categories = [
  {
    label: 'All devices',
    value: 'All devices',
  },
  {
    label: 'Connected Devices',
    value: 'Connected Devices',
  },
  {
    label: 'Smartphones',
    value: 'Smartphones',
  },
  {
    label: 'Tablets',
    value: 'Tablets',
  },
  {
    label: 'Business Solutions',
    value: 'Business Solutions',
  },
  {
    label: 'Internet Devices',
    value: 'Internet Devices',
  },
  {
    label: 'Basic Phones',
    value: 'Basic Phones',
  },
  {
    label: 'Home/Office Solutions',
    value: 'Home/Office Solutions',
  },
  {
    label: 'Connected Cars',
    value: 'Connected Cars',
  },
  {
    label: 'Certified Pre-owned',
    value: 'Certified Pre-owned',
  },
  {
    label: 'Connected Smartwatches',
    value: 'Connected Smartwatches',
  },
];

export const osName = [
  {
    label: 'Android',
    value: 'Android',
  },
  {
    label: 'Apple iOS',
    value: 'Apple iOS',
  },
  {
    label: 'BlackBerry',
    value: 'BlackBerry',
  },
];

export const sortOption = [
  {
    label: 'Price Low To High',
    value: 'product_min_fullRetailPrice_f asc',
    isSelected: false,
  },
  {
    label: 'Price High To Low',
    value: 'product_min_fullRetailPrice_f desc',
    isSelected: false,
  },
  {
    label: 'Customer Rating',
    value: 'product_average_rating_f desc',
    isSelected: false,
  },
  {
    label: 'Featured',
    value: '',
    isSelected: true,
  },
];

export const typeAheadSearch = [
  {
    productDisplayName: 'iPhone 11',
    skuSorId: 'MHCH3LL/A',
    productStartDate: '',
    productSeoUrlName: 'apple-iphone-11',
    skuSeoUrlName: 'apple-iphone-11-256gb-black',
    productId: 'dev12360040',
  },
  {
    productDisplayName: 'iPhone 12 Pro Max',
    skuSorId: 'MG9K3LL/A',
    productStartDate: '',
    productSeoUrlName: 'apple-iphone-12-pro-max',
    skuSeoUrlName: 'apple-iphone-12-pro-max-512gb-in-graphite',
    productId: 'dev14240056',
  },
  {
    productDisplayName: 'iPhone SE',
    skuSorId: 'MLY62LL/A',
    productStartDate: '',
    productSeoUrlName: 'apple-iphone-se',
    skuSeoUrlName: 'apple-iphone-se-16gb-in-rose-gold',
    productId: 'dev6000008',
  },
  {
    productDisplayName: 'iPhone SE (2020)',
    skuSorId: 'MHGD3LL/A',
    productStartDate: '',
    productSeoUrlName: 'apple-iphone-se-2020',
    skuSeoUrlName: 'apple-iphone-se-2020-256gb-in-red',
    productId: 'dev13320013',
  },
  {
    productDisplayName: 'iPhone 12',
    skuSorId: 'MGFC3LL/A',
    productStartDate: '2020-10-16T04:00:00Z',
    productSeoUrlName: 'apple-iphone-12',
    skuSeoUrlName: 'apple-iphone-12-128gb-in-red',
    productId: 'dev14240058',
  },
  {
    productDisplayName: 'iPhone XS',
    skuSorId: 'MTAV2LL/A',
    productStartDate: '',
    productSeoUrlName: 'apple-iphone-xs',
    skuSeoUrlName: 'apple-iphone-xs-512gb-in-gold',
    productId: 'dev10640020',
  },
  {
    productDisplayName: 'iPhone 13',
    skuSorId: 'MLC93LL/A',
    productStartDate: '2021-09-17T16:30:00Z',
    productSeoUrlName: 'apple-iphone-13',
    skuSeoUrlName: 'apple-iphone-13-512gb-in-red',
    productId: 'dev16720001',
  },
  {
    productDisplayName: 'iPhone XR',
    skuSorId: 'MT372LL/A',
    productStartDate: '',
    productSeoUrlName: 'apple-iphone-xr',
    skuSeoUrlName: 'apple-iphone-xr-128gb-in-white-2018',
    productId: 'dev10680044',
  },
  {
    productDisplayName: 'iPhone 13 Pro',
    skuSorId: 'MNDH3LL/A',
    productStartDate: '2021-09-18T02:00:00Z',
    productSeoUrlName: 'apple-iphone-13-pro',
    skuSeoUrlName: 'apple-iphone-13-pro-128gb-in-alpine-green',
    productId: 'dev16720003',
  },
  {
    productDisplayName: 'iPhone 13 Pro Max',
    skuSorId: 'MLFE3LL/A',
    productStartDate: '2021-09-17T16:30:00Z',
    productSeoUrlName: 'apple-iphone-13-pro-max',
    skuSeoUrlName: 'apple-iphone-13-pro-max-512gb-in-sierra-blue',
    productId: 'dev16720004',
  },
];
