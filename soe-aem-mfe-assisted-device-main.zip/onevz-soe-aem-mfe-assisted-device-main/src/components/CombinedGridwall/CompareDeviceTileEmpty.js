import React from 'react';
import styled from 'styled-components';
import { TileContainer } from '@vds/tiles';
// import { Input } from '@vds/inputs';
import { FlexBoxColumn, TileWrapper, PaddingBottom16 } from './FlexGlobalStyledConstants';
import CustomDeviceLogo from './Tiles/customdevice.svg';

const InputWrapper = styled.div`
  display: flex;
  flex-direction: column;
`;
const ImgWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 110px;
  margin-top: 10px;
  margin-bottom: 1rem;
`;

function CompareDeviceTileEmpty(props) {
  const { scrolled = false } = props;

  return (
    <TileWrapper data-testid='emptyTile' onClick={props.hideCompareDevicesModal}>
      <TileContainer
        padding='1rem'
        height={scrolled ? '150px' : '318px'}
        width='240px'
        // onClick={(e) => alert("Tile is clicked")}
      >
        <FlexBoxColumn>
          <ImgWrapper>
            <img
              src={CustomDeviceLogo}
              alt='custom Device'
              width='52px'
              height='110px'
              style={{ 'margin-right': '0px' }}
            />
          </ImgWrapper>
          {!scrolled && (
            <InputWrapper>
              <PaddingBottom16>
                {/* <Input
                    type="text"
                    width="208px"
                    label="Brand"
                    readOnly={false}
                    required={true}
                    disabled={true}
                    error={false}
                    errorText="Select Brand"
                  /> */}
              </PaddingBottom16>
              {/* <Input
                  type="text"
                  width="208px"
                  label="Device"
                  readOnly={false}
                  required={true}
                  disabled={true}
                  error={false}
                  errorText="Select Device"
                /> */}
            </InputWrapper>
          )}
        </FlexBoxColumn>
      </TileContainer>
    </TileWrapper>
  );
}
export default CompareDeviceTileEmpty;
