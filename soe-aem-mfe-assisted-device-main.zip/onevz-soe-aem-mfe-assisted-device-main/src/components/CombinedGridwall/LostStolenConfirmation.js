import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { useDispatch } from 'react-redux';
import { ConfirmationDialogBox } from 'onevzsoemfecommon/ConfirmationDialogBox';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import * as appLoaderActions from 'onevzsoemfecommon/AppLoaderActions';
import { useLazyAllowDeviceIdToReuseQuery } from '../../modules/services/APIService/APIServiceHooks';

function LostStolenConfirmation({ isVisible, onSuccess, onCancel, deviceId, customerInfo }) {
  const dispatch = useDispatch();
  const [isProcessing, setIsProcessing] = useState(false);
  const [allowDeviceIdToReuse] = useLazyAllowDeviceIdToReuseQuery();

  const displayLostStolenError = () => {
    dispatch(
      appMessageActions.addAppMessage(
        `Could not remove the device ID ${deviceId} from the Lost/Stolen list, please try again`,
        'error',
        true
      )
    );
  };

const handleConfirmationClick = async (action) => {
    if (action === 'yes') {
      setIsProcessing(true);
      dispatch(appLoaderActions.show());

      try {
        const response = await allowDeviceIdToReuse({
          customHeaders: {
            'enable-deviceid': deviceId,
          },
          body: {
            transactionType: 'StolenDelete',
            locationCode: customerInfo?.orderLocationCode,
            cartCreator: customerInfo?.lookupMtn,
          },
        });

        if (response?.data?.devices?.[0]?.statusCode === "00" || response?.devices?.[0]?.statusCode === "00") {
          onSuccess(deviceId);
        } else {
          displayLostStolenError();
          onCancel();
        }
      } catch (error) {
        displayLostStolenError();
        onCancel();
      } finally {
        setIsProcessing(false);
        dispatch(appLoaderActions.hide());
      }
    } else {
      onCancel();
    }
  };

  if (!isVisible) {
    return null;
  }

  const message = `Device ID ${deviceId} is on the Lost/Stolen list.  Do you wish to delete this device from the list?`;

  return (
    <ConfirmationDialogBox
      message={message}
      btnYesText='Continue'
      btnNoText='Cancel'
      isNoBtnDisabled={isProcessing}
      isYesBtnDisabled={isProcessing}
      handleConfirmationDialogBoxClick={handleConfirmationClick}
      data-testid='lost-stolen-confirmation-dialog'
      dataTrackYes='deleteLostStolenDevice_continue'
      dataTrackNo='deleteLostStolenDevice_cancel'
    />
  );
}

LostStolenConfirmation.propTypes = {
  isVisible: PropTypes.bool.isRequired,
  onSuccess: PropTypes.func.isRequired,
  onCancel: PropTypes.func.isRequired,
  deviceId: PropTypes.string.isRequired,
};

export default LostStolenConfirmation;
