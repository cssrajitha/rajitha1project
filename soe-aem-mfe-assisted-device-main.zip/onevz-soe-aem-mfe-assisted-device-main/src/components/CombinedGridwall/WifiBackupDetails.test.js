import React from 'react';
import { render, screen } from '../../modules/test-utils/renderHelper';
import WiFiBackupDetails from './WifiBackupDetails';
describe('SwitchModal Component', () => {
  const onCloseMock = jest.fn();
  const onContinueMock = jest.fn();

  const wiFiBackupPlanMock = {
    overview: 'Reliable backup when your primary internet goes down.',
    features: [
      {
        subtitle: 'Unlimited data for 7 days a month',
        details:
          'Stay connected in case your primary internet service provider goes down with unlimited backup data for up to 7 days a month.',
        subDetails:
          "Download speeds up to 32 Mbps; upload speeds up to 5 Mbps. For backup use in the event of primary internet provider network outage. Backup power source required for use during power outage. When network is experiencing heavy traffic, your data may be temporarily slowed. Data usage is subject to Verizon's Customer Agreement.",
      },
      {
        subtitle: 'Router included',
        details:
          'The included state-of-the-art router provides coverage for multiple devices so you get optimal performance in case your primary internet service provider goes down.',
        subDetails:
          "Verizon owns the equipment provided with your plan, including the router. If you choose to disconnect service, you must return equipment within 30 days or you'll incur an unreturned equipment fee(s).",
      },
      {
        subtitle: 'Easy to setup & use',
        details:
          'Keep your router plugged in and if your primary internet connection goes out, connect your devices to Wi-Fi Backup to start a 24-hour session. You can check your usage at anytime.',
        subDetails: null,
      },
    ],
    title: 'Wi-Fi Backup',
    monthlyPrice: '$30/mo',
  };

  const defaultProps = {
    onClose: onCloseMock,
    onContinue: onContinueMock,
    isOpen: true,
    wiFiBackupPlan: wiFiBackupPlanMock,
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should not render the modal if isOpen is true', () => {
    render(<WiFiBackupDetails {...defaultProps} isOpen={true} />);
    expect(screen.queryByTestId('ContinueButton-WiFi')).toBeInTheDocument();
    expect(screen.queryByTestId('wifi-back-close')).toBeInTheDocument();
  });

  it('should not render the modal if isOpen is false', () => {
    render(<WiFiBackupDetails {...defaultProps} isOpen={false} />);
    expect(screen.queryByTestId('ContinueButton-WiFi')).not.toBeInTheDocument();
    expect(screen.queryByTestId('ContinueButton')).not.toBeInTheDocument();
  });
});
