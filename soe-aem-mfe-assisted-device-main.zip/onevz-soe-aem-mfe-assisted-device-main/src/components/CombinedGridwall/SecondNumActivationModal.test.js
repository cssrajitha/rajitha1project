import React from 'react';
import SecondNumActivationModal from './SecondNumActivationModal';
import { fireEvent, render, screen } from '../../modules/test-utils/renderHelper';

describe("Initial render", () => {
    test("render the modal ", () => {
        const props = {
            showSecondNumberActivationModal: true,
            setShowSecondNumberActivationModal: jest.fn(),
        }
        render(<SecondNumActivationModal {...props} />)
        const doneBtn = screen.getByRole('button', { name: 'Done' });
        expect(doneBtn).toBeInTheDocument();
        fireEvent.click(doneBtn);
    })
    test("click on close icon", () => {
        const props = {
            showSecondNumberActivationModal: true,
            setShowSecondNumberActivationModal: jest.fn(),
        }
        render(<SecondNumActivationModal {...props} />)
        const closeBtn = screen.getByTestId("modal-close-button");
        expect(closeBtn).toBeInTheDocument();
        fireEvent.click(closeBtn);
    })
})