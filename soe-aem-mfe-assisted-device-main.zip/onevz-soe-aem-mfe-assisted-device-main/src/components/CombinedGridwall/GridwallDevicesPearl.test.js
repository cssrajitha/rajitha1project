import React from 'react';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import { fireEvent, render, screen } from '../../modules/test-utils/renderHelper';
import GridwallDevices from './GridwallDevices';
import data from './__mocks__/mockCombinedGridwallData.json';
import myOffers from './__mocks__/getMyOffers.json';
import deviceProps from './__mocks__/mockGridwallDevices.json';
import mockOffers from './__mocks__/getMyOffersWithoutBYOD.json';
import mockTrialDeviceDetail from './__mocks__/getTrialDeviceDetail.json';

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradleProperty: () => ['FALSE', 'TRUE'],
  }),
  { virtual: true },
);

jest.mock(
  '../../modules/utils/getPDPEnable',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('../../modules/utils/getPDPEnable'),
    getPDPEnable: () => false,
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    isAsurion: () => true,
    isIpad: () => true,
    getQueryParamByName: (value) => {
      if (value === 'searchByName') return false;
      if (value === 'isByodUpdate') return false;
    },
  }),
  { virtual: true },
);

const handlers = [
  rest.post(`*/flexV2/productList`, (req, res, ctx) => {
    console.log('inside /flexV2/productList');
    return res(ctx.status(200), ctx.json(data.data));
  }),
  rest.post(`*/accountlandingservice/nse/getTrialDeviceDetail`, (req, res, ctx) => {
    console.log('inside /accountlandingservice/nse/getTrialDeviceDetail');
    return res(ctx.status(200), ctx.json(mockTrialDeviceDetail));
  }),
  rest.post(`*/grid/typeAhead`, (req, res, ctx) => {
    console.log('inside /grid/typeAhead');
    return res(ctx.status(200), ctx.json(data.responseTypeAhead));
  }),
  rest.post(`*/browseservice/getSkuDetails`, (req, res, ctx) => {
    console.log('inside /browseservice/getSkuDetails');
    return res(ctx.status(200), ctx.json(data.responseGetSkuDetails));
  }),
  rest.post(`*/accountlandingservice/getMyOffers`, (req, res, ctx) => {
    console.log('inside /accountlandingservice/getMyOffers');
    return res(ctx.status(200), ctx.json(myOffers));
  }),
  rest.post(`*/accountlandingservice/flexV2/customerProfile`, (req, res, ctx) => {
    console.log('inside /accountlandingservice/flexV2/customerProfile');
    return res(ctx.status(200), ctx.json({ data: deviceProps.landingData }));
  }),
];
const server = setupServer(...handlers);

describe('device List component render for pearl', () => {
  const trialdevice = {
    tdd: {
      equipmentInfos: [
        {
          deviceInfo: {
            deviceId: '354615755195390',
            deviceSku: 'IPHONE14PRO-NVZW',
            deviceUrl: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a',
            displayName: 'IPHONE14 PRO GENERIC NVZW',
          },
        },
      ],
    },
  };
  const props = {
    totalLines: [
      {
        lineActivityType: 'DEO',
        itemsInfo: [
          {
            cartItems: {
              cartItem: [
                {
                  cartItemType: 'DEVICE',
                  deviceId: '354615755195390',
                },
              ],
            },
          },
        ],
      },
    ],
    trialDeviceDetail: trialdevice,
    CustomerData: { channel: 'OMNI-TELESALES' },
    devicePayload: {
      formattedDeviceId: '354615755742126',
      simId: '12345A',
      cpSimCard: 'SB3456',
      data: {
        lines: [{ device: { sim: { CurrentSimid: 123 }, Flowtype: 'DEVICE' } }],
      },
    },
    idScanModalValue: jest.fn(true),
    sourcefrom: 'combinedgridwall',
    ProspectByodFlow: '&prospectByodFlow=true',
    deviceInfo: {
      invokeIdScan: 'Y',
    },
    setLoadMore: jest.fn(),
    scanCheck: 'EUP',
    ValidateDeviceSimIdResultStatus: 'fulfilled',
    ValidateDeviceSimIdResult: {
      serviceHeader: {
        clientId: 'OMNI-RETAIL',
        statusMsg: 'SUCCESS',
        serviceName: 'SalesOrderPurchase',
        userId: '',
        statusCode: '00',
        sessionId: '',
        correlationId: 'soe-cart-2024.09.18.09.51.40-412.0166586677088',
      },
      serviceBody: {
        serviceResponse: {
          context: {
            caseId: 'SOP-15792935-E01',
            contextInfo: {
              callReason: 'SalesOrderPurchase',
              processStep: 'GridWallPDP',
              processAction: '',
              availablePaths: [
                {
                  path: 'GridWallPDP',
                },
              ],
            },
            customerInfo: {
              nocByod: false,
              accountNumber: '',
              cartCreator: '3143040921',
              processingMTN: '',
              registerNumber: 0,
              noc: false,
              myvPage: false,
            },
            cartInfo: {
              cartItemCount: 0,
              cartId: '05caf95d-4b57-4dd5-87de-2b4ccfbcc9d7',
              discountPromoTotal: 0.0,
              registerNumber: 0,
              protectionNotRequired: false,
              fmiCheck: false,
              isFlexV2: false,
              isPrepaidToPostpaidMigration: false,
              instantCreditAmount: 0,
              ngdFlow: false,
            },
            deviceInfo: {
              makeEtniPersApi: false,
              simInfo: {
                iccid: '123',
                mfgCode: '',
                launchPackageSku: 'IPHONE14PRO-NVZW',
                prodName: '',
                preferredSoftSim: 'UNIVESIM5G-SA-D',
                ispuCompatibleSIM: 'UNIVESIM5G',
                pairedIccid: '',
                type: '',
                mtn: '',
                mobileNumber: '',
                active: false,
                aging: false,
                available: false,
                retired: false,
                grandFathered: false,
                status: '',
                euimid: '',
                imsiv: '',
                imsivf: '',
                iccIdStat: '',
                min: '',
                makeEtniPersApi: true,
                deviceId: '354615755195390',
                dfillCompatibleSim: '',
                esimid: '',
              },
              simInfo2: {
                makeEtniPersApi: true,
                iccid: '',
                mfgCode: '',
                launchPackageSku: 'IPHONE14PRO-NVZW',
                prodName: '',
                preferredSoftSim: 'UNIVESIM5G-SA-D',
                launchPackageSkuType: 'IPHONE14PRO-NVZW',
                pairedIccid: '',
                type: '',
                mtn: '',
                mobileNumber: '',
                active: false,
                aging: false,
                available: false,
                retired: false,
                grandFathered: false,
                status: '',
                euimid: '',
                imsiv: '',
                imsivf: '',
                iccIdStat: '',
                min: '',
                ispuCompatibleSIM: '',
                deviceId: '354615755742126',
                dfillCompatibleSim: '',
                esimid: '',
                eID: '89049032007108888100136113581639',
              },
              invokeIdScan: '',
              deviceSimCompatible: 'N',
              deviceSimM2MPair: 'N',
              deviceESimCompatible: 'N',
              deviceESimM2MPair: 'N',
              deviceId: '354615755195390',
              color: {
                colorId: '',
                displayName: '',
                description: '',
                colorCssStyle: '',
              },
              imageName: 'iphone-14-pro-space-black-fall22-a',
              imageUrlMap: {
                defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a',
                largeImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-lg$',
                mediumImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-med$',
                miniImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-mini$',
                thumbImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-thumb$',
              },
              deviceSku: 'IPHONE14PRO-NVZW',
              isRestrictedDevice: 'N',
              deviceAttributes: {
                mfgCode: 'APL',
                prodName: 'IPHONE14 PRO GENERIC NVZW',
                equipModeCode: '5GE',
                equipMode: '5GDevice',
                gpsIndicator: 'Y',
                daccCode: '01791',
                deviceType: '5GE',
                deviceCategory: '5G Smartphone',
                productId: 'dev19920041',
                postpaidRestrictStartDate: '',
                prepayRestrictStartDate: '',
                wholesaleRestrictStartDate: '',
              },
              lostAndStolen: {
                lostStolen: 'N',
                nonPay: 'N',
              },
              numbershareCapability: '',
              price: {
                fullRetailPrice: {
                  contractText: '',
                },
                oneYearPrice: {
                  contractText: '',
                },
                devicePaymentPrice: [],
              },
              skipSimIdFlag: true,
              appleWatchFlag: false,
              fmipLocked: false,
              appleCarrieLock: true,
              e911AddrInd: '',
              simClass4G: 'NR',
              softMessages: [
                'If this is not a Verizon device, it may be carrier locked. Please contact the previous carrier for assistance.',
              ],
              standalonePairingEligible: true,
              deviceFamilyType: 'Phone',
              osType: 'Apple iOS',
              euiccCapable: 'Y',
              imei1: '354615755742126',
              imei2: '354615755195390',
              productFamily: 'iPhone 14 Pro NON VZW NA',
              productDisplayName: 'iPhone 14 Pro NON VZW NA',
              pairedImeiData: {
                pairedImei: '',
                eid: '',
                sku: '',
                preferredSim: '',
                devicePreferredSoftSim: '',
                simClass4G: '',
                euiccCapable: false,
              },
              simswapSessionId: '',
              eSIMOnly: true,
            },
          },
        },
      },
    },
    validateDeviceSimId: jest.fn(),
    resetToggleOptions: jest.fn(),
    popUp: true,
    updateDevicePayload: jest.fn(),
    devicestocompare: [
      {
        imgSrc: '',
        productDisplayName: 'sdfdsf',
        brandName: 'fdsfsd',
        productId: 123,
      },
    ],
    offers: mockOffers,
    getDevices: jest.fn(),
    showToogle: true,
    products: deviceProps.products,
    selectedSkuId: 'sku5811679',
    existingSortOptions: [
      { label: 'Customer Rating', value: 'product_average_rating_f desc', isSelected: false },
      { label: 'Featured', value: '', isSelected: true },
      { label: 'Price High To Low', value: 'product_min_fullRetailPrice_f desc', isSelected: false },
      { label: 'Price Low To High', value: 'product_min_fullRetailPrice_f asc', isSelected: false },
    ],
    cartDetails: deviceProps.cartDetails,
    errorMessage: '',
    landingData: deviceProps.landingData,
    lineHasOffer: true,
    isDWOS: false,
    offerSourceSystem: 'national',
    offerSubType: 'Virtual Reward',
    intentCheck: true,
    isOffersStacked: false,
    UpdateBYODCheck: jest.fn(),
    eSimDetailsResultStatus: 'fulfilled',
    initSimDetailsResp: jest.fn(),
    updateToggleOptions: jest.fn(),
    setToggle: jest.fn(),
    requestBody: {
      data: {
        paginationData: {
          offset: 2,
        },
      },
    },
  };

  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });
  afterAll(() => {
    server.close();
    sessionStorage.setItem('APIContext', '');
  });

  beforeEach(() => {
    Object.defineProperty(window, 'location', {
      value: new URL('http://example.com/sales/assisted/new/device/gridwall.html'),
      configurable: true,
    });

    sessionStorage.setItem('isPearl', 'true');
    sessionStorage.setItem('APP_PROPERTIES', '{"pearlBYODFlow": "TRUE"}');
    render(<GridwallDevices {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });

  test('gridwall component', async () => {
    const category = await screen.findByTestId('testCategoryFilter');
    fireEvent.change(category, { target: { value: 'All devices' } });
  });
});
