import React from 'react';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import { isMobile } from 'onevzsoemfecommon/Helpers/useragent';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import { fireEvent, render, screen } from '../../modules/test-utils/renderHelper';
import GridwallDevices from './GridwallDevices';
import data from './__mocks__/mockCombinedGridwallData.json';
import myOffers from './__mocks__/getMyOffers.json';
import deviceProps from './__mocks__/mockGridwallDevices.json';
import mockOffers from './__mocks__/getMyOffersWithoutBYOD.json';
import mockTrialDeviceDetail from './__mocks__/getTrialDeviceDetail.json';

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradleProperty: () => ['TRUE', 'TRUE'],
  }),
  { virtual: true },
);

const handlers = [
  rest.post(`*/flexV2/productList`, (req, res, ctx) => {
    console.log('inside /flexV2/productList');
    return res(ctx.status(200), ctx.json(data.data));
  }),
  rest.post(`*/accountlandingservice/nse/getTrialDeviceDetail`, (req, res, ctx) => {
    console.log('inside /accountlandingservice/nse/getTrialDeviceDetail');
    return res(ctx.status(200), ctx.json(mockTrialDeviceDetail));
  }),
  rest.post(`*/grid/typeAhead`, (req, res, ctx) => {
    console.log('inside /grid/typeAhead');
    return res(ctx.status(200), ctx.json(data.responseTypeAhead));
  }),
  rest.post(`*/browseservice/getSkuDetails`, (req, res, ctx) => {
    console.log('inside /browseservice/getSkuDetails');
    return res(ctx.status(200), ctx.json(data.responseGetSkuDetails));
  }),
  rest.post(`*/accountlandingservice/getMyOffers`, (req, res, ctx) => {
    console.log('inside /accountlandingservice/getMyOffers');
    return res(ctx.status(200), ctx.json(myOffers));
  }),
  rest.post(`*/accountlandingservice/flexV2/customerProfile`, (req, res, ctx) => {
    console.log('inside /accountlandingservice/flexV2/customerProfile');
    return res(ctx.status(200), ctx.json({ data: deviceProps.landingData }));
  }),
];
const server = setupServer(...handlers);

describe('device List component render for pearl', () => {
  jest.mock(
    'onevzsoemfeframework/AssistedCradleService',
    () => ({
      __esModule: true,
      ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
      getAssistedCradleProperty: () => ['FALSE'],
    }),
    { virtual: true },
  );
  const props = {
    devicePayload: {
      formattedDeviceId: '354615755742126',
      simId: '12345A',
      cpSimCard: 'SB3456',
      data: {
        lines: [{ device: { sim: { CurrentSimid: 123 }, Flowtype: 'DEVICE' } }],
      },
    },
    idScanModalValue: jest.fn(true),
    sourcefrom: 'combinedgridwall',
    ProspectByodFlow: '&prospectByodFlow=true',
    deviceInfo: {
      invokeIdScan: 'Y',
    },
    setLoadMore: jest.fn(),
    scanCheck: 'EUP',
    ValidateDeviceSimIdResultStatus: 'fulfilled',
    ValidateDeviceSimIdResult: {
      serviceHeader: {
        clientId: 'OMNI-RETAIL',
        statusMsg: 'SUCCESS',
        serviceName: 'SalesOrderPurchase',
        userId: '',
        statusCode: '00',
        sessionId: '',
        correlationId: 'soe-cart-2024.09.18.09.51.40-412.0166586677088',
      },
      serviceBody: {
        serviceResponse: {
          context: {
            caseId: 'SOP-15792935-E01',
            contextInfo: {
              callReason: 'SalesOrderPurchase',
              processStep: 'GridWallPDP',
              processAction: '',
              availablePaths: [
                {
                  path: 'GridWallPDP',
                },
              ],
            },
            customerInfo: {
              nocByod: false,
              accountNumber: '',
              cartCreator: '3143040921',
              processingMTN: '',
              registerNumber: 0,
              noc: false,
              myvPage: false,
            },
            cartInfo: {
              cartItemCount: 0,
              cartId: '05caf95d-4b57-4dd5-87de-2b4ccfbcc9d7',
              discountPromoTotal: 0.0,
              registerNumber: 0,
              protectionNotRequired: false,
              fmiCheck: false,
              isFlexV2: false,
              isPrepaidToPostpaidMigration: false,
              instantCreditAmount: 0,
              ngdFlow: false,
            },
            deviceInfo: {
              makeEtniPersApi: false,
              simInfo: {
                iccid: '123',
                mfgCode: '',
                launchPackageSku: 'IPHONE14PRO-NVZW',
                prodName: '',
                preferredSoftSim: 'UNIVESIM5G-SA-D',
                launchPackageSkuType: 'IPHONE14PRO-NVZW',
                pairedIccid: '',
                type: '',
                mtn: '',
                mobileNumber: '',
                active: false,
                aging: false,
                available: false,
                retired: false,
                grandFathered: false,
                status: '',
                euimid: '',
                imsiv: '',
                imsivf: '',
                iccIdStat: '',
                min: '',
                ispuCompatibleSIM: '',
                makeEtniPersApi: true,
                deviceId: '354615755195390',
                dfillCompatibleSim: '',
                esimid: '',
                eID: '89049032007108888100136113581639',
              },
              simInfo2: {
                makeEtniPersApi: true,
                iccid: '',
                mfgCode: '',
                launchPackageSku: 'IPHONE14PRO-NVZW',
                prodName: '',
                preferredSoftSim: 'UNIVESIM5G-SA-D',
                launchPackageSkuType: 'IPHONE14PRO-NVZW',
                pairedIccid: '',
                type: '',
                mtn: '',
                mobileNumber: '',
                active: false,
                aging: false,
                available: false,
                retired: false,
                grandFathered: false,
                status: '',
                euimid: '',
                imsiv: '',
                imsivf: '',
                iccIdStat: '',
                min: '',
                ispuCompatibleSIM: '',
                deviceId: '354615755742126',
                dfillCompatibleSim: '',
                esimid: '',
                eID: '89049032007108888100136113581639',
              },
              invokeIdScan: '',
              deviceSimCompatible: 'N',
              deviceSimM2MPair: 'N',
              deviceESimCompatible: 'N',
              deviceESimM2MPair: 'N',
              deviceId: '354615755195390',
              color: {
                colorId: '',
                displayName: '',
                description: '',
                colorCssStyle: '',
              },
              imageName: 'iphone-14-pro-space-black-fall22-a',
              imageUrlMap: {
                defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a',
                largeImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-lg$',
                mediumImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-med$',
                miniImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-mini$',
                thumbImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-thumb$',
              },
              skuDisplayName: 'IPHONE14 PRO GENERIC NVZW',
              deviceSku: 'IPHONE14PRO-NVZW',
              isRestrictedDevice: 'N',
              deviceAttributes: {
                mfgCode: 'APL',
                mfgName: 'Apple',
                prodName: 'IPHONE14 PRO GENERIC NVZW',
                prodType: '5GSmartphone',
                equipModeCode: '5GE',
                equipMode: '5GDevice',
                gpsIndicator: 'Y',
                daccCode: '01791',
                deviceType: '5GE',
                deviceCategory: '5G Smartphone',
                productId: 'dev19920041',
                postpaidRestrictStartDate: '',
                prepayRestrictStartDate: '',
                wholesaleRestrictStartDate: '',
              },
              lostAndStolen: {
                lostStolen: 'N',
                nonPay: 'N',
              },
              numbershareCapability: '',
              price: {
                fullRetailPrice: {
                  contractText: '',
                },
                oneYearPrice: {
                  contractText: '',
                },
                devicePaymentPrice: [],
              },
              skipSimIdFlag: true,
              appleWatchFlag: false,
              fmipLocked: false,
              appleCarrieLock: true,
              e911AddrInd: '',
              simClass4G: 'NR',
              softMessages: [
                'If this is not a Verizon device, it may be carrier locked. Please contact the previous carrier for assistance.',
              ],
              standalonePairingEligible: true,
              deviceFamilyType: 'Phone',
              osType: 'Apple iOS',
              euiccCapable: 'Y',
              imei1: '354615755742126',
              imei2: '354615755195390',
              productFamily: 'iPhone 14 Pro NON VZW NA',
              productDisplayName: 'iPhone 14 Pro NON VZW NA',
              pairedImeiData: {
                pairedImei: '',
                eid: '',
                sku: '',
                preferredSim: '',
                devicePreferredSoftSim: '',
                simClass4G: '',
                euiccCapable: false,
              },
              simswapSessionId: '',
              eSIMOnly: true,
            },
          },
        },
      },
    },
    validateDeviceSimId: jest.fn(),
    resetToggleOptions: jest.fn(),
    popUp: true,
    updateDevicePayload: jest.fn(),
    devicestocompare: [
      {
        imgSrc: '',
        productDisplayName: 'sdfdsf',
        brandName: 'fdsfsd',
        productId: 123,
      },
    ],
    offers: mockOffers,
    getDevices: jest.fn(),
    showToogle: true,
    totalLines: [{ mobileNumber: 4782303946 }],
    activeMtn: '4782303946',
    products: deviceProps.products,
    selectedSkuId: 'sku5811679',
    existingSortOptions: [
      { label: 'Customer Rating', value: 'product_average_rating_f desc', isSelected: false },
      { label: 'Featured', value: '', isSelected: true },
      { label: 'Price High To Low', value: 'product_min_fullRetailPrice_f desc', isSelected: false },
      { label: 'Price Low To High', value: 'product_min_fullRetailPrice_f asc', isSelected: false },
    ],
    cartDetails: deviceProps.cartDetails,
    errorMessage: '',
    landingData: deviceProps.landingData,
    lineHasOffer: true,
    isDWOS: false,
    offerSourceSystem: 'national',
    offerSubType: 'Virtual Reward',
    intentCheck: true,
    isOffersStacked: false,
    UpdateBYODCheck: jest.fn(),
    eSimDetailsResultStatus: 'fulfilled',
    initSimDetailsResp: jest.fn(),
    updateToggleOptions: jest.fn(),
    setToggle: jest.fn(),
    requestBody: {
      data: {
        paginationData: {
          offset: 2,
        },
      },
    },
  };

  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });
  afterAll(() => {
    server.close();
    sessionStorage.setItem('APIContext', '');
  });

  beforeEach(() => {
    window.vzdl = {
      ...window.vzdl,
      event: {
        value: '',
      },
      page: {
        detail: '',
      },
      user: {},
    };
    Object.defineProperty(window, 'location', {
      value: new URL('http://example.com/sales/assisted/new/device/gridwall.html'),
      configurable: true,
    });

    sessionStorage.setItem('isPearl', 'true');
    sessionStorage.setItem('APP_PROPERTIES', '{"pearlBYODFlow": "TRUE"}');
    render(<GridwallDevices {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });

  test('gridwall component', async () => {
    const category = await screen.findByTestId('testCategoryFilter');
    fireEvent.change(category, { target: { value: 'All devices' } });
  });
});

describe('Samsung Carrier Lock - device List component render for pearl', () => {
  jest.mock(
    'onevzsoemfeframework/AssistedCradleService',
    () => ({
      __esModule: true,
      ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
      getAssistedCradleProperty: () => ['FALSE'],
    }),
    { virtual: true },
  );
  const props = {
    devicePayload: {
      formattedDeviceId: '354615755742126',
      simId: '12345A',
      cpSimCard: 'SB3456',
      data: {
        lines: [{ device: { sim: { CurrentSimid: 123 }, Flowtype: 'DEVICE' } }],
      },
    },
    idScanModalValue: jest.fn(true),
    sourcefrom: 'combinedgridwall',
    ProspectByodFlow: '&prospectByodFlow=true',
    deviceInfo: {
      invokeIdScan: 'Y',
    },
    setLoadMore: jest.fn(),
    scanCheck: 'EUP',
    ValidateDeviceSimIdResultStatus: 'fulfilled',
    ValidateDeviceSimIdResult: {
      serviceHeader: {
        clientId: 'OMNI-RETAIL',
        statusMsg: 'SUCCESS',
        serviceName: 'SalesOrderPurchase',
        userId: '',
        statusCode: '00',
        sessionId: '',
        correlationId: 'soe-cart-2024.09.18.09.51.40-412.0166586677088',
      },
      serviceBody: {
        serviceResponse: {
          context: {
            caseId: 'SOP-15792935-E01',
            contextInfo: {
              callReason: 'SalesOrderPurchase',
              processStep: 'GridWallPDP',
              processAction: '',
              availablePaths: [
                {
                  path: 'GridWallPDP',
                },
              ],
            },
            customerInfo: {
              nocByod: false,
              accountNumber: '',
              cartCreator: '3143040921',
              processingMTN: '',
              registerNumber: 0,
              noc: false,
              myvPage: false,
            },
            cartInfo: {
              cartItemCount: 0,
              cartId: '05caf95d-4b57-4dd5-87de-2b4ccfbcc9d7',
              discountPromoTotal: 0.0,
              registerNumber: 0,
              protectionNotRequired: false,
              fmiCheck: false,
              isFlexV2: false,
              isPrepaidToPostpaidMigration: false,
              instantCreditAmount: 0,
              ngdFlow: false,
            },
            deviceInfo: {
              carrierLock: true,
              makeEtniPersApi: false,
              simInfo: {
                iccid: '123',
                mfgCode: '',
                launchPackageSku: 'IPHONE14PRO-NVZW',
                prodName: '',
                preferredSoftSim: 'UNIVESIM5G-SA-D',
                launchPackageSkuType: 'IPHONE14PRO-NVZW',
                pairedIccid: '',
                type: '',
                mtn: '',
                mobileNumber: '',
                active: false,
                aging: false,
                available: false,
                retired: false,
                grandFathered: false,
                status: '',
                euimid: '',
                imsiv: '',
                imsivf: '',
                iccIdStat: '',
                min: '',
                ispuCompatibleSIM: '',
                makeEtniPersApi: true,
                deviceId: '354615755195390',
                dfillCompatibleSim: '',
                esimid: '',
                eID: '89049032007108888100136113581639',
              },
              simInfo2: {
                makeEtniPersApi: true,
                iccid: '',
                mfgCode: '',
                launchPackageSku: 'IPHONE14PRO-NVZW',
                prodName: '',
                preferredSoftSim: 'UNIVESIM5G-SA-D',
                launchPackageSkuType: 'IPHONE14PRO-NVZW',
                pairedIccid: '',
                type: '',
                mtn: '',
                mobileNumber: '',
                active: false,
                aging: false,
                available: false,
                retired: false,
                grandFathered: false,
                status: '',
                euimid: '',
                imsiv: '',
                imsivf: '',
                iccIdStat: '',
                min: '',
                ispuCompatibleSIM: '',
                deviceId: '354615755742126',
                dfillCompatibleSim: '',
                esimid: '',
                eID: '89049032007108888100136113581639',
              },
              invokeIdScan: '',
              deviceSimCompatible: 'N',
              deviceSimM2MPair: 'N',
              deviceESimCompatible: 'N',
              deviceESimM2MPair: 'N',
              deviceId: '354615755195390',
              color: {
                colorId: '',
                displayName: '',
                description: '',
                colorCssStyle: '',
              },
              imageName: 'iphone-14-pro-space-black-fall22-a',
              imageUrlMap: {
                defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a',
                largeImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-lg$',
                mediumImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-med$',
                miniImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-mini$',
                thumbImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-thumb$',
              },
              skuDisplayName: 'IPHONE14 PRO GENERIC NVZW',
              deviceSku: 'IPHONE14PRO-NVZW',
              isRestrictedDevice: 'N',
              deviceAttributes: {
                mfgCode: 'APL',
                mfgName: 'Apple',
                prodName: 'IPHONE14 PRO GENERIC NVZW',
                prodType: '5GSmartphone',
                equipModeCode: '5GE',
                equipMode: '5GDevice',
                gpsIndicator: 'Y',
                daccCode: '01791',
                deviceType: '5GE',
                deviceCategory: '5G Smartphone',
                productId: 'dev19920041',
                postpaidRestrictStartDate: '',
                prepayRestrictStartDate: '',
                wholesaleRestrictStartDate: '',
              },
              lostAndStolen: {
                lostStolen: 'N',
                nonPay: 'N',
              },
              numbershareCapability: '',
              price: {
                fullRetailPrice: {
                  contractText: '',
                },
                oneYearPrice: {
                  contractText: '',
                },
                devicePaymentPrice: [],
              },
              skipSimIdFlag: true,
              appleWatchFlag: false,
              fmipLocked: false,
              appleCarrieLock: true,
              e911AddrInd: '',
              simClass4G: 'NR',
              softMessages: [
                'If this is not a Verizon device, it may be carrier locked. Please contact the previous carrier for assistance.',
              ],
              standalonePairingEligible: true,
              deviceFamilyType: 'Phone',
              osType: 'Apple iOS',
              euiccCapable: 'Y',
              imei1: '354615755742126',
              imei2: '354615755195390',
              productFamily: 'iPhone 14 Pro NON VZW NA',
              productDisplayName: 'iPhone 14 Pro NON VZW NA',
              pairedImeiData: {
                pairedImei: '',
                eid: '',
                sku: '',
                preferredSim: '',
                devicePreferredSoftSim: '',
                simClass4G: '',
                euiccCapable: false,
              },
              simswapSessionId: '',
              eSIMOnly: true,
            },
          },
        },
      },
    },
    validateDeviceSimId: jest.fn(),
    resetToggleOptions: jest.fn(),
    popUp: true,
    updateDevicePayload: jest.fn(),
    devicestocompare: [
      {
        imgSrc: '',
        productDisplayName: 'sdfdsf',
        brandName: 'fdsfsd',
        productId: 123,
      },
    ],
    offers: mockOffers,
    getDevices: jest.fn(),
    showToogle: true,
    totalLines: [{ mobileNumber: 4782303946 }],
    activeMtn: '4782303946',
    products: deviceProps.products,
    selectedSkuId: 'sku5811679',
    existingSortOptions: [
      { label: 'Customer Rating', value: 'product_average_rating_f desc', isSelected: false },
      { label: 'Featured', value: '', isSelected: true },
      { label: 'Price High To Low', value: 'product_min_fullRetailPrice_f desc', isSelected: false },
      { label: 'Price Low To High', value: 'product_min_fullRetailPrice_f asc', isSelected: false },
    ],
    cartDetails: deviceProps.cartDetails,
    errorMessage: '',
    landingData: deviceProps.landingData,
    lineHasOffer: true,
    isDWOS: false,
    offerSourceSystem: 'national',
    offerSubType: 'Virtual Reward',
    intentCheck: true,
    isOffersStacked: false,
    UpdateBYODCheck: jest.fn(),
    eSimDetailsResultStatus: 'fulfilled',
    initSimDetailsResp: jest.fn(),
    updateToggleOptions: jest.fn(),
    setToggle: jest.fn(),
    requestBody: {
      data: {
        paginationData: {
          offset: 2,
        },
      },
    },
  };

  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });
  afterAll(() => {
    server.close();
    sessionStorage.setItem('APIContext', '');
  });

  beforeEach(() => {
    window.vzdl = {
      ...window.vzdl,
      event: {
        value: '',
      },
      page: {
        detail: '',
      },
      user: {},
    };
    Object.defineProperty(window, 'location', {
      value: new URL('http://example.com/sales/assisted/new/device/gridwall.html'),
      configurable: true,
    });

    sessionStorage.setItem('isPearl', 'true');
    sessionStorage.setItem('APP_PROPERTIES', '{"pearlBYODFlow": "TRUE", "samsungPOSFFlag": "TRUE"}');
    render(<GridwallDevices {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });

  test('gridwall component', async () => {
    const category = await screen.findByTestId('testCategoryFilter');
    fireEvent.change(category, { target: { value: 'All devices' } });
  });
});

describe('device List component render for pearl for handleClickForPearl', () => {
  jest.mock(
    'onevzsoemfeframework/AssistedCradleService',
    () => ({
      __esModule: true,
      ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
      getAssistedCradleProperty: () => ['FALSE'],
    }),
    { virtual: true },
  );
  jest.mock(
    'onevzsoemfeframework/DomService',
    () => ({
      __esModule: true,
      default: jest.fn(() => ({})),
      ...jest.requireActual('onevzsoemfeframework/DomService'),
      isAsurion: () => true,
      isIpad: () => true,
      getQueryParamByName: (value) => {
        if (value === 'searchByName') return false;
      },
    }),
    { virtual: true },
  );

  const props = {
    devicePayload: {
      formattedDeviceId: '354615755742126',
      simId: '12345A',
      cpSimCard: 'SB3456',
      data: {
        lines: [{ device: { sim: { CurrentSimid: 123 }, Flowtype: 'SIM' } }],
      },
    },
    idScanModalValue: jest.fn(true),
    sourcefrom: 'combinedgridwall',
    ProspectByodFlow: '&prospectByodFlow=true',
    deviceInfo: {
      invokeIdScan: 'Y',
    },
    setLoadMore: jest.fn(),
    scanCheck: 'EUP',
    ValidateDeviceSimIdResultStatus: 'fulfilled',
    ValidateDeviceSimIdResult: {
      serviceHeader: {
        clientId: 'OMNI-RETAIL',
        statusMsg: 'SUCCESS',
        serviceName: 'SalesOrderPurchase',
        userId: '',
        statusCode: '00',
        sessionId: '',
        correlationId: 'soe-cart-2024.09.18.09.51.40-412.0166586677088',
      },
      serviceBody: {
        serviceResponse: {
          context: {
            caseId: 'SOP-15792935-E01',
            contextInfo: {
              callReason: 'SalesOrderPurchase',
              processStep: 'GridWallPDP',
              processAction: '',
              availablePaths: [
                {
                  path: 'GridWallPDP',
                },
              ],
            },
            customerInfo: {
              nocByod: false,
              accountNumber: '',
              cartCreator: '3143040921',
              processingMTN: '',
              registerNumber: 0,
              noc: false,
              myvPage: false,
            },
            cartInfo: {
              cartItemCount: 0,
              cartId: '05caf95d-4b57-4dd5-87de-2b4ccfbcc9d7',
              discountPromoTotal: 0.0,
              registerNumber: 0,
              protectionNotRequired: false,
              fmiCheck: false,
              isFlexV2: false,
              isPrepaidToPostpaidMigration: false,
              instantCreditAmount: 0,
              ngdFlow: false,
            },
            deviceInfo: {
              makeEtniPersApi: false,
              simInfo: {
                iccid: '',
                mfgCode: '',
                launchPackageSku: 'IPHONE14PRO-NVZW',
                prodName: '',
                preferredSoftSim: 'UNIVESIM5G-SA-D',
                launchPackageSkuType: 'IPHONE14PRO-NVZW',
                pairedIccid: '',
                type: '',
                mtn: '',
                mobileNumber: '',
                active: false,
                aging: false,
                available: false,
                retired: false,
                grandFathered: false,
                status: '',
                euimid: '',
                imsiv: '',
                imsivf: '',
                iccIdStat: '',
                min: '',
                ispuCompatibleSIM: '',
                makeEtniPersApi: true,
                deviceId: '354615755195390',
                dfillCompatibleSim: '',
                esimid: '',
                eID: '89049032007108888100136113581639',
              },
              simInfo2: {
                makeEtniPersApi: true,
                iccid: '',
                mfgCode: '',
                launchPackageSku: 'IPHONE14PRO-NVZW',
                prodName: '',
                preferredSoftSim: 'UNIVESIM5G-SA-D',
                launchPackageSkuType: 'IPHONE14PRO-NVZW',
                pairedIccid: '',
                type: '',
                mtn: '',
                mobileNumber: '',
                active: false,
                aging: false,
                available: false,
                retired: false,
                grandFathered: false,
                status: '',
                euimid: '',
                imsiv: '',
                imsivf: '',
                iccIdStat: '',
                min: '',
                ispuCompatibleSIM: '',
                deviceId: '354615755742126',
                dfillCompatibleSim: '',
                esimid: '',
                eID: '89049032007108888100136113581639',
              },
              invokeIdScan: '',
              deviceSimCompatible: 'N',
              deviceSimM2MPair: 'N',
              deviceESimCompatible: 'N',
              deviceESimM2MPair: 'N',
              deviceId: '354615755195390',
              color: {
                colorId: '',
                displayName: '',
                description: '',
                colorCssStyle: '',
              },
              imageName: 'iphone-14-pro-space-black-fall22-a',
              imageUrlMap: {
                defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a',
                largeImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-lg$',
                mediumImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-med$',
                miniImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-mini$',
                thumbImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-thumb$',
              },
              skuDisplayName: 'IPHONE14 PRO GENERIC NVZW',
              deviceSku: 'IPHONE14PRO-NVZW',
              isRestrictedDevice: 'N',
              deviceAttributes: {
                mfgCode: 'APL',
                mfgName: 'Apple',
                prodName: 'IPHONE14 PRO GENERIC NVZW',
                prodType: '5GSmartphone',
                equipModeCode: '5GE',
                equipMode: '5GDevice',
                gpsIndicator: 'Y',
                daccCode: '01791',
                deviceType: '5GE',
                deviceCategory: '5G Smartphone',
                productId: 'dev19920041',
                postpaidRestrictStartDate: '',
                prepayRestrictStartDate: '',
                wholesaleRestrictStartDate: '',
              },
              lostAndStolen: {
                lostStolen: 'N',
                nonPay: 'N',
              },
              numbershareCapability: '',
              price: {
                fullRetailPrice: {
                  contractText: '',
                },
                oneYearPrice: {
                  contractText: '',
                },
                devicePaymentPrice: [],
              },
              skipSimIdFlag: true,
              appleWatchFlag: false,
              fmipLocked: false,
              appleCarrieLock: true,
              e911AddrInd: '',
              simClass4G: 'NR',
              softMessages: [
                'If this is not a Verizon device, it may be carrier locked. Please contact the previous carrier for assistance.',
              ],
              standalonePairingEligible: true,
              deviceFamilyType: 'Phone',
              osType: 'Apple iOS',
              euiccCapable: 'Y',
              imei1: '354615755742126',
              imei2: '354615755195390',
              productFamily: 'iPhone 14 Pro NON VZW NA',
              productDisplayName: 'iPhone 14 Pro NON VZW NA',
              pairedImeiData: {
                pairedImei: '',
                eid: '',
                sku: '',
                preferredSim: '',
                devicePreferredSoftSim: '',
                simClass4G: '',
                euiccCapable: false,
              },
              simswapSessionId: '',
              eSIMOnly: true,
            },
          },
        },
      },
    },
    validateDeviceSimId: jest.fn(),
    resetToggleOptions: jest.fn(),
    popUp: true,
    updateDevicePayload: jest.fn(),
    devicestocompare: [
      {
        imgSrc: '',
        productDisplayName: 'sdfdsf',
        brandName: 'fdsfsd',
        productId: 123,
      },
    ],
    offers: mockOffers,
    getDevices: jest.fn(),
    showToogle: true,
    totalLines: [{ mobileNumber: 4782303946 }],
    activeMtn: '4782303946',
    products: deviceProps.products,
    selectedSkuId: 'sku5811679',
    existingSortOptions: [
      { label: 'Customer Rating', value: 'product_average_rating_f desc', isSelected: false },
      { label: 'Featured', value: '', isSelected: true },
      { label: 'Price High To Low', value: 'product_min_fullRetailPrice_f desc', isSelected: false },
      { label: 'Price Low To High', value: 'product_min_fullRetailPrice_f asc', isSelected: false },
    ],
    cartDetails: deviceProps.cartDetails,
    errorMessage: '',
    landingData: deviceProps.landingData,
    lineHasOffer: true,
    isDWOS: false,
    offerSourceSystem: 'national',
    offerSubType: 'Virtual Reward',
    intentCheck: true,
    isOffersStacked: false,
    UpdateBYODCheck: jest.fn(),
    eSimDetailsResultStatus: 'fulfilled',
    initSimDetailsResp: jest.fn(),
    updateToggleOptions: jest.fn(),
    setToggle: jest.fn(),
    requestBody: {
      data: {
        paginationData: {
          offset: 2,
        },
      },
    },
  };

  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });
  afterAll(() => {
    server.close();
    sessionStorage.setItem('APIContext', '');
  });

  beforeEach(() => {
    window.vzdl = {
      ...window.vzdl,
      event: {
        value: '',
      },
      page: {
        detail: '',
      },
      user: {},
    };
    Object.defineProperty(window, 'location', {
      value: new URL('http://example.com/sales/assisted/new/device/gridwall.html'),
      configurable: true,
    });

    sessionStorage.setItem('isPearl', 'true');
    sessionStorage.setItem('APP_PROPERTIES', '{"pearlBYODFlow": "TRUE"}');
    render(<GridwallDevices {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });

  test('gridwall component', async () => {
    const category = await screen.findByTestId('testCategoryFilter');
    fireEvent.change(category, { target: { value: 'All devices' } });
  });
});

describe('device List component render for pearl for deviceInfo', () => {
  jest.mock(
    'onevzsoemfeframework/AssistedCradleService',
    () => ({
      __esModule: true,
      ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
      getAssistedCradleProperty: () => ['FALSE'],
    }),
    { virtual: true },
  );
  jest.mock(
    'onevzsoemfeframework/DomService',
    () => ({
      __esModule: true,
      default: jest.fn(() => ({})),
      ...jest.requireActual('onevzsoemfeframework/DomService'),
      isAsurion: () => true,
      isIpad: () => true,
      getQueryParamByName: (value) => {
        if (value === 'deviceFromCart') return 'isLocal';
        if (value === 'isByodUpdate') return false;
      },
    }),
    { virtual: true },
  );

  const props = {
    scanCheck: 'EUP',
    devicePayload: {
      formattedDeviceId: '354615755742126',
      simId: '12345A',
      cpSimCard: 'SB3456',
      fromCpe: true,
      isCustomerProvidedEquipment: true,
      data: {
        lines: [{ device: { sim: { CurrentSimid: 123 }, Flowtype: 'TEST' } }],
      },
    },
    idScanModalValue: jest.fn(true),
    sourcefrom: 'combinedgridwall',
    ProspectByodFlow: '&prospectByodFlow=true',
    deviceInfo: {
      invokeIdScan: 'Y',
      simClass4G: 'NP',
    },
    setLoadMore: jest.fn(),
    ValidateDeviceSimIdResultStatus: 'fulfilled',
    ValidateDeviceSimIdResult: {
      serviceHeader: {
        clientId: 'OMNI-RETAIL',
        statusMsg: 'SUCCESS',
        serviceName: 'SalesOrderPurchase',
        userId: '',
        statusCode: '00',
        sessionId: '',
        correlationId: 'soe-cart-2024.09.18.09.51.40-412.0166586677088',
      },
      serviceBody: {
        serviceResponse: {
          context: {
            caseId: 'SOP-15792935-E01',
            contextInfo: {
              callReason: 'SalesOrderPurchase',
              processStep: 'GridWallPDP',
              processAction: '',
              availablePaths: [
                {
                  path: 'GridWallPDP',
                },
              ],
            },
            customerInfo: {
              nocByod: false,
              accountNumber: '',
              cartCreator: '3143040921',
              processingMTN: '',
              registerNumber: 0,
              noc: false,
              myvPage: false,
            },
            cartInfo: {
              cartItemCount: 0,
              cartId: '05caf95d-4b57-4dd5-87de-2b4ccfbcc9d7',
              discountPromoTotal: 0.0,
              registerNumber: 0,
              protectionNotRequired: false,
              fmiCheck: false,
              isFlexV2: false,
              isPrepaidToPostpaidMigration: false,
              instantCreditAmount: 0,
              ngdFlow: false,
            },
            deviceInfo: {
              simClass4G: 'NP',
              makeEtniPersApi: false,
              simInfo: {
                iccid: '',
                mfgCode: '',
                launchPackageSku: 'IPHONE14PRO-NVZW',
                prodName: '',
                preferredSoftSim: 'UNIVESIM5G-SA-D',
                launchPackageSkuType: 'IPHONE14PRO-NVZW',
                pairedIccid: '',
                type: '',
                mtn: '',
                mobileNumber: '',
                active: false,
                aging: false,
                available: false,
                retired: false,
                grandFathered: false,
                status: '',
                euimid: '',
                imsiv: '',
                imsivf: '',
                iccIdStat: '',
                min: '',
                ispuCompatibleSIM: 'test',
                makeEtniPersApi: true,
                deviceId: '354615755195390',
                dfillCompatibleSim: '',
                esimid: '',
              },
              simInfo2: {
                makeEtniPersApi: true,
                iccid: '',
                mfgCode: '',
                launchPackageSku: 'IPHONE14PRO-NVZW',
                prodName: '',
                preferredSoftSim: 'UNIVESIM5G-SA-D',
                launchPackageSkuType: 'IPHONE14PRO-NVZW',
                pairedIccid: '',
                type: '',
                mtn: '',
                mobileNumber: '',
                active: false,
                aging: false,
                available: false,
                retired: false,
                grandFathered: false,
                status: '',
                euimid: '',
                imsiv: '',
                imsivf: '',
                iccIdStat: '',
                min: '',
                ispuCompatibleSIM: '',
                deviceId: '354615755742126',
                dfillCompatibleSim: '',
                esimid: '',
                eID: '89049032007108888100136113581639',
              },
              invokeIdScan: '',
              deviceSimCompatible: 'N',
              deviceSimM2MPair: 'N',
              deviceESimCompatible: 'N',
              deviceESimM2MPair: 'N',
              deviceId: '354615755195390',
              color: {
                colorId: '',
                displayName: '',
                description: '',
                colorCssStyle: '',
              },
              imageName: 'iphone-14-pro-space-black-fall22-a',
              imageUrlMap: {
                defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a',
                largeImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-lg$',
                mediumImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-med$',
                miniImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-mini$',
                thumbImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-thumb$',
              },
              skuDisplayName: 'IPHONE14 PRO GENERIC NVZW',
              deviceSku: 'IPHONE14PRO-NVZW',
              isRestrictedDevice: 'N',
              deviceAttributes: {
                mfgCode: 'APL',
                mfgName: 'Apple',
                prodName: 'IPHONE14 PRO GENERIC NVZW',
                prodType: '5GSmartphone',
                equipModeCode: '5GE',
                equipMode: '5GDevice',
                gpsIndicator: 'Y',
                daccCode: '01791',
                deviceType: '5GE',
                deviceCategory: '5G Smartphone',
                productId: 'dev19920041',
                postpaidRestrictStartDate: '',
                prepayRestrictStartDate: '',
                wholesaleRestrictStartDate: '',
              },
              lostAndStolen: {
                lostStolen: 'N',
                nonPay: 'N',
              },
              numbershareCapability: '',
              price: {
                fullRetailPrice: {
                  contractText: '',
                },
                oneYearPrice: {
                  contractText: '',
                },
                devicePaymentPrice: [],
              },
              skipSimIdFlag: true,
              appleWatchFlag: false,
              fmipLocked: false,
              appleCarrieLock: true,
              e911AddrInd: '',
              softMessages: [
                'If this is not a Verizon device, it may be carrier locked. Please contact the previous carrier for assistance.',
              ],
              standalonePairingEligible: true,
              deviceFamilyType: 'Phone',
              osType: 'Apple iOS',
              euiccCapable: 'Y',
              imei1: '354615755742126',
              imei2: '354615755195390',
              productFamily: 'iPhone 14 Pro NON VZW NA',
              productDisplayName: 'iPhone 14 Pro NON VZW NA',
              pairedImeiData: {
                pairedImei: '',
                eid: '',
                sku: '',
                preferredSim: '',
                devicePreferredSoftSim: '',
                simClass4G: '',
                euiccCapable: false,
              },
              simswapSessionId: '',
              eSIMOnly: true,
            },
          },
        },
      },
    },
    validateDeviceSimId: jest.fn(),
    resetToggleOptions: jest.fn(),
    popUp: true,
    updateDevicePayload: jest.fn(),
    devicestocompare: [
      {
        imgSrc: '',
        productDisplayName: 'sdfdsf',
        brandName: 'fdsfsd',
        productId: 123,
      },
    ],
    offers: mockOffers,
    getDevices: jest.fn(),
    showToogle: true,
    totalLines: [{ mobileNumber: 4782303946 }],
    activeMtn: '4782303946',
    products: deviceProps.products,
    selectedSkuId: 'sku5811679',
    existingSortOptions: [
      { label: 'Customer Rating', value: 'product_average_rating_f desc', isSelected: false },
      { label: 'Featured', value: '', isSelected: true },
      { label: 'Price High To Low', value: 'product_min_fullRetailPrice_f desc', isSelected: false },
      { label: 'Price Low To High', value: 'product_min_fullRetailPrice_f asc', isSelected: false },
    ],
    cartDetails: deviceProps.cartDetails,
    errorMessage: '',
    landingData: deviceProps.landingData,
    lineHasOffer: true,
    isDWOS: false,
    offerSourceSystem: 'national',
    offerSubType: 'Virtual Reward',
    intentCheck: true,
    isOffersStacked: false,
    UpdateBYODCheck: jest.fn(),
    eSimDetailsResultStatus: 'fulfilled',
    initSimDetailsResp: jest.fn(),
    updateToggleOptions: jest.fn(),
    setToggle: jest.fn(),
    requestBody: {
      data: {
        paginationData: {
          offset: 2,
        },
      },
    },
  };

  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });
  afterAll(() => {
    server.close();
    sessionStorage.setItem('APIContext', '');
  });

  beforeEach(() => {
    window.vzdl = {
      ...window.vzdl,
      event: {
        value: '',
      },
      page: {
        detail: '',
      },
      user: {},
    };
    Object.defineProperty(window, 'location', {
      value: new URL('http://example.com/sales/assisted/new/device/gridwall.html'),
      configurable: true,
    });

    sessionStorage.setItem('isPearl', 'true');
    sessionStorage.setItem('APP_PROPERTIES', '{"pearlBYODFlow": "TRUE"}');
    render(<GridwallDevices {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });

  test('gridwall component', async () => {
    const category = await screen.findByTestId('testCategoryFilter');
    fireEvent.change(category, { target: { value: 'All devices' } });
  });
});

describe('device List component render for pearl deviceInfo', () => {
  jest.mock(
    'onevzsoemfeframework/AssistedCradleService',
    () => ({
      __esModule: true,
      ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
      getAssistedCradleProperty: () => ['FALSE'],
    }),
    { virtual: true },
  );
  const props = {
    devicePayload: {
      formattedDeviceId: '354615755742126',
      data: {
        lines: [{ device: { sim: { CurrentSimid: 123 } } }],
      },
    },
    idScanModalValue: jest.fn(true),
    sourcefrom: 'combinedgridwall',
    ProspectByodFlow: '&prospectByodFlow=true',
    deviceInfo: {
      invokeIdScan: 'Y',
    },
    setLoadMore: jest.fn(),
    scanCheck: 'EUP',
    ValidateDeviceSimIdResultStatus: 'fulfilled',
    ValidateDeviceSimIdResult: {
      serviceHeader: {
        clientId: 'OMNI-RETAIL',
        statusMsg: 'SUCCESS',
        serviceName: 'SalesOrderPurchase',
        userId: '',
        statusCode: '00',
        sessionId: '',
        correlationId: 'soe-cart-2024.09.18.09.51.40-412.0166586677088',
      },
      serviceBody: {
        serviceResponse: {
          context: {
            caseId: 'SOP-15792935-E01',
            contextInfo: {
              callReason: 'SalesOrderPurchase',
              processStep: 'GridWallPDP',
              processAction: '',
              availablePaths: [
                {
                  path: 'GridWallPDP',
                },
              ],
            },
            customerInfo: {
              nocByod: false,
              accountNumber: '',
              cartCreator: '3143040921',
              processingMTN: '',
              registerNumber: 0,
              noc: false,
              myvPage: false,
            },
            cartInfo: {
              cartItemCount: 0,
              cartId: '05caf95d-4b57-4dd5-87de-2b4ccfbcc9d7',
              discountPromoTotal: 0.0,
              registerNumber: 0,
              protectionNotRequired: false,
              fmiCheck: false,
              isFlexV2: false,
              isPrepaidToPostpaidMigration: false,
              instantCreditAmount: 0,
              ngdFlow: false,
            },
            deviceInfo: {
              makeEtniPersApi: true,
              simInfo: {
                iccid: '',
                mfgCode: '',
                launchPackageSku: 'IPHONE14PRO-NVZW',
                prodName: '',
                preferredSoftSim: 'UNIVESIM5G-SA-D',
                launchPackageSkuType: 'IPHONE14PRO-NVZW',
                pairedIccid: '',
                type: '',
                mtn: '',
                mobileNumber: '',
                active: false,
                aging: false,
                available: false,
                retired: false,
                grandFathered: false,
                status: '',
                euimid: '',
                imsiv: '',
                imsivf: '',
                iccIdStat: '',
                min: '',
                ispuCompatibleSIM: '',
                makeEtniPersApi: true,
                deviceId: '354615755195390',
                dfillCompatibleSim: false,
                esimid: '',
                eID: '89049032007108888100136113581639',
              },
              simInfo2: {
                makeEtniPersApi: true,
                iccid: '',
                mfgCode: '',
                launchPackageSku: 'IPHONE14PRO-NVZW',
                prodName: '',
                preferredSoftSim: 'UNIVESIM5G-SA-D',
                launchPackageSkuType: 'IPHONE14PRO-NVZW',
                pairedIccid: '',
                type: '',
                mtn: '',
                mobileNumber: '',
                active: false,
                aging: false,
                available: false,
                retired: false,
                grandFathered: false,
                status: '',
                euimid: '',
                imsiv: '',
                imsivf: '',
                iccIdStat: '',
                min: '',
                ispuCompatibleSIM: '',
                deviceId: '354615755742126',
                dfillCompatibleSim: '',
                esimid: '',
                eID: '89049032007108888100136113581639',
              },
              invokeIdScan: '',
              deviceSimCompatible: 'N',
              deviceSimM2MPair: 'N',
              deviceESimCompatible: 'N',
              deviceESimM2MPair: 'N',
              deviceId: '354615755195390',
              color: {
                colorId: '',
                displayName: '',
                description: '',
                colorCssStyle: '',
              },
              imageName: 'iphone-14-pro-space-black-fall22-a',
              imageUrlMap: {
                defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a',
                largeImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-lg$',
                mediumImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-med$',
                miniImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-mini$',
                thumbImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-thumb$',
              },
              skuDisplayName: 'IPHONE14 PRO GENERIC NVZW',
              deviceSku: 'IPHONE14PRO-NVZW',
              isRestrictedDevice: 'N',
              deviceAttributes: {
                mfgCode: 'APL',
                mfgName: 'Apple',
                prodName: 'IPHONE14 PRO GENERIC NVZW',
                prodType: '5GSmartphone',
                equipModeCode: '5GE',
                equipMode: '5GDevice',
                gpsIndicator: 'Y',
                daccCode: '01791',
                deviceType: '5GE',
                deviceCategory: '5G Smartphone',
                productId: 'dev19920041',
                postpaidRestrictStartDate: '',
                prepayRestrictStartDate: '',
                wholesaleRestrictStartDate: '',
              },
              lostAndStolen: {
                lostStolen: 'N',
                nonPay: 'N',
              },
              numbershareCapability: '',
              price: {
                fullRetailPrice: {
                  contractText: '',
                },
                oneYearPrice: {
                  contractText: '',
                },
                devicePaymentPrice: [],
              },
              skipSimIdFlag: true,
              appleWatchFlag: false,
              fmipLocked: false,
              appleCarrieLock: true,
              e911AddrInd: '',
              simClass4G: 'NR',
              softMessages: [
                'If this is not a Verizon device, it may be carrier locked. Please contact the previous carrier for assistance.',
              ],
              standalonePairingEligible: true,
              deviceFamilyType: 'Phone',
              osType: 'Apple iOS',
              euiccCapable: 'Y',
              imei1: '354615755742126',
              imei2: '354615755195390',
              productFamily: 'iPhone 14 Pro NON VZW NA',
              productDisplayName: 'iPhone 14 Pro NON VZW NA',
              pairedImeiData: {
                pairedImei: '',
                eid: '',
                sku: '',
                preferredSim: '',
                devicePreferredSoftSim: '',
                simClass4G: '',
                euiccCapable: false,
              },
              simswapSessionId: '',
              eSIMOnly: true,
            },
          },
        },
      },
    },
    validateDeviceSimId: jest.fn(),
    resetToggleOptions: jest.fn(),
    popUp: true,
    updateDevicePayload: jest.fn(),
    devicestocompare: [
      {
        imgSrc: '',
        productDisplayName: 'sdfdsf',
        brandName: 'fdsfsd',
        productId: 123,
      },
    ],
    offers: mockOffers,
    getDevices: jest.fn(),
    showToogle: true,
    totalLines: [{ mobileNumber: 4782303946 }],
    activeMtn: '4782303946',
    products: deviceProps.products,
    selectedSkuId: 'sku5811679',
    existingSortOptions: [
      { label: 'Customer Rating', value: 'product_average_rating_f desc', isSelected: false },
      { label: 'Featured', value: '', isSelected: true },
      { label: 'Price High To Low', value: 'product_min_fullRetailPrice_f desc', isSelected: false },
      { label: 'Price Low To High', value: 'product_min_fullRetailPrice_f asc', isSelected: false },
    ],
    cartDetails: deviceProps.cartDetails,
    errorMessage: '',
    landingData: deviceProps.landingData,
    lineHasOffer: true,
    isDWOS: false,
    offerSourceSystem: 'national',
    offerSubType: 'Virtual Reward',
    intentCheck: true,
    isOffersStacked: false,
    UpdateBYODCheck: jest.fn(),
    eSimDetailsResultStatus: 'fulfilled',
    initSimDetailsResp: jest.fn(),
    updateToggleOptions: jest.fn(),
    setToggle: jest.fn(),
    requestBody: {
      data: {
        paginationData: {
          offset: 2,
        },
      },
    },
  };

  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });
  afterAll(() => {
    server.close();
    sessionStorage.setItem('APIContext', '');
  });

  beforeEach(() => {
    window.vzdl = {
      ...window.vzdl,
      event: {
        value: '',
      },
      page: {
        detail: '',
      },
      user: {},
    };
    Object.defineProperty(window, 'location', {
      value: new URL('http://example.com/sales/assisted/new/device/gridwall.html'),
      configurable: true,
    });

    sessionStorage.setItem('isPearl', 'true');
    sessionStorage.setItem('APP_PROPERTIES', '{"pearlBYODFlow": "TRUE"}');
    render(<GridwallDevices {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });

  test('gridwall component', async () => {
    const category = await screen.findByTestId('testCategoryFilter');
    fireEvent.change(category, { target: { value: 'All devices' } });
  });
});

describe('device List component render for pearl for isBothSlotsESimCompatible', () => {
  const props = {
    formattedDeviceId: '1234',
    idScanModalValue: jest.fn(true),
    ProspectByodFlow: '',
    deviceInfo: {
      invokeIdScan: 'Y',
    },
    setLoadMore: jest.fn(),
    scanCheck: 'EUP',
    ValidateDeviceSimIdResultStatus: 'fulfilled',
    ValidateDeviceSimIdResult: {
      serviceHeader: {
        clientId: 'OMNI-RETAIL',
        statusMsg: 'SUCCESS',
        serviceName: 'SalesOrderPurchase',
        userId: '',
        statusCode: '00',
        sessionId: '',
        correlationId: 'soe-cart-2024.09.18.09.51.40-412.0166586677088',
      },
      serviceBody: {
        serviceResponse: {
          context: {
            caseId: 'SOP-15792935-E01',
            contextInfo: {
              callReason: 'SalesOrderPurchase',
              processStep: 'GridWallPDP',
              processAction: '',
              availablePaths: [
                {
                  path: 'GridWallPDP',
                },
              ],
            },
            customerInfo: {
              nocByod: false,
              accountNumber: '',
              cartCreator: '3143040921',
              processingMTN: '',
              registerNumber: 0,
              noc: false,
              myvPage: false,
            },
            cartInfo: {
              cartItemCount: 0,
              cartId: '05caf95d-4b57-4dd5-87de-2b4ccfbcc9d7',
              discountPromoTotal: 0.0,
              registerNumber: 0,
              protectionNotRequired: false,
              fmiCheck: false,
              isFlexV2: false,
              isPrepaidToPostpaidMigration: false,
              instantCreditAmount: 0,
              ngdFlow: false,
            },
            deviceInfo: {
              makeEtniPersApi: false,
              simInfo: {
                iccid: '',
                mfgCode: '',
                launchPackageSku: 'IPHONE14PRO-NVZW',
                prodName: '',
                preferredSoftSim: 'UNIVESIM5G-SA-D',
                launchPackageSkuType: 'IPHONE14PRO-NVZW',
                pairedIccid: '',
                type: '',
                mtn: '',
                mobileNumber: '',
                active: false,
                aging: false,
                available: false,
                retired: false,
                grandFathered: false,
                status: '',
                euimid: '',
                imsiv: '',
                imsivf: '',
                iccIdStat: '',
                min: '',
                ispuCompatibleSIM: '',
                makeEtniPersApi: false,
                deviceId: '354615755195390',
                dfillCompatibleSim: '',
                esimid: '',
                eID: '89049032007108888100136113581639',
              },
              simInfo2: {
                makeEtniPersApi: true,
                iccid: '',
                mfgCode: '',
                launchPackageSku: 'IPHONE14PRO-NVZW',
                prodName: '',
                preferredSoftSim: 'UNIVESIM5G-SA-D',
                launchPackageSkuType: 'IPHONE14PRO-NVZW',
                pairedIccid: '',
                type: '',
                mtn: '',
                mobileNumber: '',
                active: false,
                aging: false,
                available: false,
                retired: false,
                grandFathered: false,
                status: '',
                euimid: '',
                imsiv: '',
                imsivf: '',
                iccIdStat: '',
                min: '',
                ispuCompatibleSIM: '',
                deviceId: '354615755742126',
                dfillCompatibleSim: '',
                esimid: '',
                eID: '89049032007108888100136113581639',
              },
              invokeIdScan: '',
              deviceSimCompatible: 'N',
              deviceSimM2MPair: 'N',
              deviceESimCompatible: 'N',
              deviceESimM2MPair: 'N',
              deviceId: '354615755195390',
              color: {
                colorId: '',
                displayName: '',
                description: '',
                colorCssStyle: '',
              },
              imageName: 'iphone-14-pro-space-black-fall22-a',
              imageUrlMap: {
                defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a',
                largeImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-lg$',
                mediumImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-med$',
                miniImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-mini$',
                thumbImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-thumb$',
              },
              skuDisplayName: 'IPHONE14 PRO GENERIC NVZW',
              deviceSku: 'IPHONE14PRO-NVZW',
              isRestrictedDevice: 'N',
              deviceAttributes: {
                mfgCode: 'APL',
                mfgName: 'Apple',
                prodName: 'IPHONE14 PRO GENERIC NVZW',
                prodType: '5GSmartphone',
                equipModeCode: '5GE',
                equipMode: '5GDevice',
                gpsIndicator: 'Y',
                daccCode: '01791',
                deviceType: '5GE',
                deviceCategory: '5G Smartphone',
                productId: 'dev19920041',
                postpaidRestrictStartDate: '',
                prepayRestrictStartDate: '',
                wholesaleRestrictStartDate: '',
              },
              lostAndStolen: {
                lostStolen: 'N',
                nonPay: 'N',
              },
              numbershareCapability: '',
              price: {
                fullRetailPrice: {
                  contractText: '',
                },
                oneYearPrice: {
                  contractText: '',
                },
                devicePaymentPrice: [],
              },
              skipSimIdFlag: true,
              appleWatchFlag: false,
              fmipLocked: false,
              appleCarrieLock: true,
              e911AddrInd: '',
              simClass4G: 'NR',
              softMessages: [
                'If this is not a Verizon device, it may be carrier locked. Please contact the previous carrier for assistance.',
              ],
              standalonePairingEligible: true,
              deviceFamilyType: 'Phone',
              osType: 'Apple iOS',
              euiccCapable: 'Y',
              imei1: '354615755742126',
              imei2: '354615755195390',
              productFamily: 'iPhone 14 Pro NON VZW NA',
              productDisplayName: 'iPhone 14 Pro NON VZW NA',
              pairedImeiData: {
                pairedImei: '',
                eid: '',
                sku: '',
                preferredSim: '',
                devicePreferredSoftSim: '',
                simClass4G: '',
                euiccCapable: false,
              },
              simswapSessionId: '',
              eSIMOnly: true,
            },
          },
        },
      },
    },
    validateDeviceSimId: jest.fn(),
    resetToggleOptions: jest.fn(),
    popUp: true,
    updateDevicePayload: jest.fn(),
    devicestocompare: [
      {
        imgSrc: '',
        productDisplayName: 'sdfdsf',
        brandName: 'fdsfsd',
        productId: 123,
      },
    ],
    offers: mockOffers,
    getDevices: jest.fn(),
    showToogle: true,
    totalLines: [{ mobileNumber: 4782303946 }],
    activeMtn: '4782303946',
    products: deviceProps.products,
    selectedSkuId: 'sku5811679',
    existingSortOptions: [
      { label: 'Customer Rating', value: 'product_average_rating_f desc', isSelected: false },
      { label: 'Featured', value: '', isSelected: true },
      { label: 'Price High To Low', value: 'product_min_fullRetailPrice_f desc', isSelected: false },
      { label: 'Price Low To High', value: 'product_min_fullRetailPrice_f asc', isSelected: false },
    ],
    cartDetails: deviceProps.cartDetails,
    errorMessage: '',
    landingData: deviceProps.landingData,
    lineHasOffer: true,
    isDWOS: false,
    offerSourceSystem: 'national',
    offerSubType: 'Virtual Reward',
    intentCheck: true,
    isOffersStacked: false,
    UpdateBYODCheck: jest.fn(),
    eSimDetailsResultStatus: 'fulfilled',
    initSimDetailsResp: jest.fn(),
    updateToggleOptions: jest.fn(),
    setToggle: jest.fn(),
    requestBody: {
      data: {
        paginationData: {
          offset: 2,
        },
      },
    },
  };
  //   jest.mock("./GridwallDevices", () => ({
  //     VAR1: 10,
  //     VAR2: 20,
  //  }));
  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });
  afterAll(() => {
    server.close();
    sessionStorage.setItem('APIContext', '');
  });

  beforeEach(() => {
    window.vzdl = {};
    Object.defineProperty(window, 'location', {
      value: new URL('http://example.com/sales/assisted/new/device/gridwall.html'),
      configurable: true,
    });

    sessionStorage.setItem('isPearl', 'true');
    sessionStorage.setItem('APP_PROPERTIES', '{"pearlBYODFlow": "TRUE"}');
    render(<GridwallDevices {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });

  test('gridwall component', async () => {
    const category = await screen.findByTestId('testCategoryFilter');
    fireEvent.change(category, { target: { value: 'All devices' } });
    fireEvent.change(category, { target: { value: 'Basic Phones' } });
    fireEvent.change(category, { target: { value: 'Business Solutions' } });
    fireEvent.change(category, { target: { value: 'Certified Pre-owned' } });
    fireEvent.change(category, { target: { value: 'Unlocked Phones' } });
    fireEvent.change(category, { target: { value: 'Connected Smartwatches' } });
    fireEvent.change(category, { target: { value: 'Smartwatches' } });
  });
  test('Filter onClick function', () => {
    const brand = screen.getByTestId('test-toggle');
    fireEvent.click(brand);
  });
});

describe('device List component render', () => {
  const props = {
    formattedDeviceId: '354615755742126',
    idScanModalValue: jest.fn(true),
    setLoadMore: jest.fn(),
    scanCheck: 'EUP',
    ValidateDeviceSimIdResultStatus: 'fulfilled',
    ValidateDeviceSimIdResult: {
      serviceHeader: {
        clientId: 'OMNI-RETAIL',
        statusMsg: 'SUCCESS',
        serviceName: 'SalesOrderPurchase',
        userId: '',
        statusCode: '00',
        sessionId: '',
        correlationId: 'soe-cart-2024.09.18.09.51.40-412.0166586677088',
      },
      serviceBody: {
        serviceResponse: {
          context: {
            caseId: 'SOP-15792935-E01',
            contextInfo: {
              callReason: 'SalesOrderPurchase',
              processStep: 'GridWallPDP',
              processAction: '',
              availablePaths: [
                {
                  path: 'GridWallPDP',
                },
              ],
            },
            customerInfo: {
              nocByod: false,
              accountNumber: '',
              cartCreator: '3143040921',
              processingMTN: '',
              registerNumber: 0,
              noc: false,
              myvPage: false,
            },
            cartInfo: {
              cartItemCount: 0,
              cartId: '05caf95d-4b57-4dd5-87de-2b4ccfbcc9d7',
              discountPromoTotal: 0.0,
              registerNumber: 0,
              protectionNotRequired: false,
              fmiCheck: false,
              isFlexV2: false,
              isPrepaidToPostpaidMigration: false,
              instantCreditAmount: 0,
              ngdFlow: false,
            },
            deviceInfo: {
              simInfo: {
                iccid: '',
                mfgCode: '',
                launchPackageSku: 'IPHONE14PRO-NVZW',
                prodName: '',
                preferredSoftSim: 'UNIVESIM5G-SA-D',
                launchPackageSkuType: 'IPHONE14PRO-NVZW',
                pairedIccid: '',
                type: '',
                mtn: '',
                mobileNumber: '',
                active: false,
                aging: false,
                available: false,
                retired: false,
                grandFathered: false,
                status: '',
                euimid: '',
                imsiv: '',
                imsivf: '',
                iccIdStat: '',
                min: '',
                ispuCompatibleSIM: '',
                makeEtniPersApi: true,
                deviceId: '354615755195390',
                dfillCompatibleSim: '',
                esimid: '',
                eID: '89049032007108888100136113581639',
              },
              simInfo2: {
                iccid: '',
                mfgCode: '',
                launchPackageSku: 'IPHONE14PRO-NVZW',
                prodName: '',
                preferredSoftSim: 'UNIVESIM5G-SA-D',
                launchPackageSkuType: 'IPHONE14PRO-NVZW',
                pairedIccid: '',
                type: '',
                mtn: '',
                mobileNumber: '',
                active: false,
                aging: false,
                available: false,
                retired: false,
                grandFathered: false,
                status: '',
                euimid: '',
                imsiv: '',
                imsivf: '',
                iccIdStat: '',
                min: '',
                ispuCompatibleSIM: '',
                makeEtniPersApi: true,
                deviceId: '354615755742126',
                dfillCompatibleSim: '',
                esimid: '',
                eID: '89049032007108888100136113581639',
              },
              invokeIdScan: '',
              deviceSimCompatible: 'N',
              deviceSimM2MPair: 'N',
              deviceESimCompatible: 'N',
              deviceESimM2MPair: 'N',
              deviceId: '354615755195390',
              color: {
                colorId: '',
                displayName: '',
                description: '',
                colorCssStyle: '',
              },
              imageName: 'iphone-14-pro-space-black-fall22-a',
              imageUrlMap: {
                defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a',
                largeImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-lg$',
                mediumImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-med$',
                miniImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-mini$',
                thumbImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-thumb$',
              },
              skuDisplayName: 'IPHONE14 PRO GENERIC NVZW',
              deviceSku: 'IPHONE14PRO-NVZW',
              isRestrictedDevice: 'N',
              deviceAttributes: {
                mfgCode: 'APL',
                mfgName: 'Apple',
                prodName: 'IPHONE14 PRO GENERIC NVZW',
                prodType: '5GSmartphone',
                equipModeCode: '5GE',
                equipMode: '5GDevice',
                gpsIndicator: 'Y',
                daccCode: '01791',
                deviceType: '5GE',
                deviceCategory: '5G Smartphone',
                productId: 'dev19920041',
                postpaidRestrictStartDate: '',
                prepayRestrictStartDate: '',
                wholesaleRestrictStartDate: '',
              },
              lostAndStolen: {
                lostStolen: 'N',
                nonPay: 'N',
              },
              numbershareCapability: '',
              price: {
                fullRetailPrice: {
                  contractText: '',
                },
                oneYearPrice: {
                  contractText: '',
                },
                devicePaymentPrice: [],
              },
              skipSimIdFlag: true,
              appleWatchFlag: false,
              fmipLocked: false,
              appleCarrieLock: true,
              e911AddrInd: '',
              simClass4G: 'NR',
              makeEtniPersApi: false,
              softMessages: [
                'If this is not a Verizon device, it may be carrier locked. Please contact the previous carrier for assistance.',
              ],
              standalonePairingEligible: true,
              deviceFamilyType: 'Phone',
              osType: 'Apple iOS',
              euiccCapable: 'Y',
              imei1: '354615755742126',
              imei2: '354615755195390',
              productFamily: 'iPhone 14 Pro NON VZW NA',
              productDisplayName: 'iPhone 14 Pro NON VZW NA',
              pairedImeiData: {
                pairedImei: '',
                eid: '',
                sku: '',
                preferredSim: '',
                devicePreferredSoftSim: '',
                simClass4G: '',
                euiccCapable: false,
              },
              simswapSessionId: '',
              eSIMOnly: true,
            },
          },
        },
      },
    },
    validateDeviceSimId: jest.fn(),
    resetToggleOptions: jest.fn(),
    popUp: true,
    devicestocompare: [
      {
        imgSrc: '',
        productDisplayName: 'sdfdsf',
        brandName: 'fdsfsd',
        productId: 123,
      },
    ],
    offers: mockOffers,
    getDevices: jest.fn(),
    showToogle: true,
    totalLines: [{ mobileNumber: 4782303946 }],
    activeMtn: '4782303946',
    products: deviceProps.products,
    selectedSkuId: 'sku5811679',
    existingSortOptions: [
      { label: 'Customer Rating', value: 'product_average_rating_f desc', isSelected: false },
      { label: 'Featured', value: '', isSelected: true },
      { label: 'Price High To Low', value: 'product_min_fullRetailPrice_f desc', isSelected: false },
      { label: 'Price Low To High', value: 'product_min_fullRetailPrice_f asc', isSelected: false },
    ],
    cartDetails: deviceProps.cartDetails,
    errorMessage: '',
    landingData: deviceProps.landingData,
    lineHasOffer: true,
    isDWOS: false,
    offerSourceSystem: 'national',
    offerSubType: 'Virtual Reward',
    intentCheck: true,
    isOffersStacked: false,
    UpdateBYODCheck: jest.fn(),
    eSimDetailsResultStatus: 'fulfilled',
    initSimDetailsResp: jest.fn(),
    updateToggleOptions: jest.fn(),
    setToggle: jest.fn(),
    requestBody: {
      data: {
        paginationData: {
          offset: 2,
        },
      },
    },
  };

  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });
  afterAll(() => {
    server.close();
    sessionStorage.setItem('APIContext', '');
  });

  beforeEach(() => {
    sessionStorage.setItem('isPearl', 'false');
    sessionStorage.setItem('APP_PROPERTIES', '{"pearlBYODFlow": "TRUE"}');
    Object.defineProperty(window, 'location', {
      value: new URL('http://example.com/sales/assisted/new/device/gridwall.html'),
      configurable: true,
    });
    render(<GridwallDevices {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('should click search button', () => {
    const testBackButton = screen.getByTestId('ShopNavSearchText');
    expect(testBackButton).toBeInTheDocument();
    fireEvent.click(testBackButton);
  });
  test('gridwall component', async () => {
    const category = await screen.findByTestId('testCategoryFilter');
    fireEvent.change(category, { target: { value: 'All devices' } });
    fireEvent.change(category, { target: { value: 'Basic Phones' } });
    fireEvent.change(category, { target: { value: 'Business Solutions' } });
    fireEvent.change(category, { target: { value: 'Certified Pre-owned' } });
    fireEvent.change(category, { target: { value: 'Unlocked Phones' } });
    fireEvent.change(category, { target: { value: 'Connected Smartwatches' } });
    fireEvent.change(category, { target: { value: 'Smartwatches' } });
  });
  test('Filter onClick function', () => {
    const brand = screen.getByTestId('testBrandFilter');
    fireEvent.change(brand, { target: { value: 'name' } });
  });
  test('Filter onClick function', () => {
    const brand = screen.getByTestId('test-toggle');
    fireEvent.click(brand);
  });
  test('Filter onClick function', () => {
    const osFilter = screen.getByTestId('testOsFilter');
    const icon = screen.getByRole('img', { name: /switch icon/i });
    const resetDevices = screen.getByTestId('testResetLink');
    fireEvent.change(osFilter, { target: { value: 'name' } });
    fireEvent.click(resetDevices);
    fireEvent.click(icon);
  });
  test('should keyDown on input', () => {
    const testSearch = screen.getByTestId('ShopNavSearchText');
    fireEvent.change(testSearch, { target: { value: 'name' } });
    fireEvent.keyPress(testSearch, { key: 'Enter', charCode: 13 });
  });
  test('search item testing', async () => {
    const searchBox = screen.getByTestId('ShopNavSearchText');
    fireEvent.change(searchBox, { target: { value: 'STK' } });
  });
  test('search item testing', async () => {
    const searchBox = screen.getByTestId('ShopNavSearchText');
    fireEvent.change(searchBox, { target: { value: 'STK' } });
    fireEvent.keyDown(searchBox, { key: 'Enter', keyCode: '13' });
  });
  test('search item testing and click sku', async () => {
    const searchBox = screen.getByTestId('ShopNavSearchText');
    fireEvent.change(searchBox, { target: { value: 'STKA' } });
  });
  test('sort item testing', async () => {
    const osFilter = screen.getByTestId('testOsFilter');
    const icon = screen.getByRole('img', { name: /switch icon/i });
    const resetDevices = screen.getByTestId('testResetLink');
    fireEvent.change(osFilter, { target: { value: 'name' } });
    fireEvent.click(resetDevices);
    fireEvent.click(icon);
    const sort = await screen.findAllByTestId('sort-item');
    expect(sort[0]).toBeInTheDocument();
    fireEvent.click(sort[0]);
  });
  test('should locate toggle option', async () => {
    const toggle = screen.getByTestId('test-toggle');
    expect(toggle).toBeInTheDocument();
    fireEvent.change(toggle, { target: { checked: true } });
  });
});

describe('GridwallDevices component -  mobile', () => {
  const deviceData = { ...deviceProps };

  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });
  afterAll(() => {
    server.close();
    sessionStorage.setItem('APIContext', '');
  });

  beforeEach(() => {
    sessionStorage.setItem('isPearl', 'false');
    sessionStorage.setItem('APP_PROPERTIES', '{"pearlBYODFlow": "TRUE"}');
    Object.defineProperty(window, 'navigator', {
      value: {
        userAgent: 'MY_VZW_APP',
      },
      writable: true,
      configurable: true,
    });
    Object.defineProperty(window, 'location', {
      value: new URL('http://example.com/sales/assisted/new/device/gridwall.html'),
      configurable: true,
    });
  });

  test('should check mobile device', () => {
    const props = {
      setLoadMore: jest.fn(),
      offers: myOffers,
      getDevices: jest.fn(),
      showToogle: true,
      totalLines: [{ mobileNumber: 4782303946 }],
      activeMtn: '4782303946',
      products: deviceData.products,
      selectedSkuId: 'sku5811679',
      existingSortOptions: [
        { label: 'Customer Rating', value: 'product_average_rating_f desc', isSelected: false },
        { label: 'Featured', value: '', isSelected: true },
        { label: 'Price High To Low', value: 'product_min_fullRetailPrice_f desc', isSelected: false },
        { label: 'Price Low To High', value: 'product_min_fullRetailPrice_f asc', isSelected: false },
      ],
      cartDetails: deviceData.cartDetails,
      errorMessage: '',
      landingData: deviceData.landingData,
      lineHasOffer: false,
      UpdateBYODCheck: jest.fn(),
      setToggle: jest.fn(),
    };
    render(<GridwallDevices {...props} />, { reducers: rootReducer, sagas: rootSaga });
    expect(isMobile()).toBe(true);
  });

  test('should refinement null', () => {
    const props = {
      setLoadMore: jest.fn(),
      offers: myOffers,
      getDevices: jest.fn(),
      showToogle: true,
      totalLines: [{ mobileNumber: 4782303946 }],
      activeMtn: '4782303946',
      products: deviceData.products,
      selectedSkuId: 'sku5811679',
      existingSortOptions: [
        { label: 'Customer Rating', value: 'product_average_rating_f desc', isSelected: false },
        { label: 'Featured', value: '', isSelected: true },
        { label: 'Price High To Low', value: 'product_min_fullRetailPrice_f desc', isSelected: false },
        { label: 'Price Low To High', value: 'product_min_fullRetailPrice_f asc', isSelected: false },
      ],
      cartDetails: deviceData.cartDetails,
      errorMessage: '',
      landingData: deviceData.landingData,
      lineHasOffer: false,
      UpdateBYODCheck: jest.fn(),
      setToggle: jest.fn(),
    };
    props.products['4782303946'].gridWall.refinements = [];
    render(<GridwallDevices {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });

  it('should test ESim functionality when simInfo is true and when scmDeviceMfeEnable is enabled', async () => {
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateDevicePayload = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    const UpdateBYODCheck = jest.fn();
    const setLoadMore = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    // window.mfe.scmDeviceMfeEnable = true;

    render(
      <GridwallDevices
        initSimDetailsCall={mockinitSimDetailsCall}
        totalLines={[
          {
            isCommonPDP: false,
            isTradeInIntentSelected: false,
            multiLineSeqNumber: 1,
            lineActivityType: 'NSE',
            totalDueToday: 400.0,
            totalDueTodayWithoutTax: 400.0,
            totalDueTodayWithoutTaxWithoutDiscount: 400.0,
            totalDueMonthly: 0.0,
            mobileNumber: 'newLine1',
            showGlobalChoiceOffer: false,
            serviceInfo: {
              serviceAddress: {
                addressLine1: '16 MAYNARD RD ',
                zipCode: '02026',
                zipCode4: '1819',
                firstName: 'FIRSTNAME',
                lastName: 'LASTNAME',
                city: 'DEDHAM',
                state: 'MA',
              },
              comparePlan: false,
              primaryUserInfo: {
                firstName: 'FIRSTNAME',
                lastName: 'LASTNAME',
                address: {
                  type: 'RD',
                  streetNumber: '16',
                  streetName: 'MAYNARD',
                  addressLine1: '16 MAYNARD RD ',
                  city: 'DEDHAM',
                  state: 'MA',
                  zipCode: '02026',
                  zipCode4: '1819',
                  county: '',
                  countryCode: 'US',
                  fipsCode: '2502100000',
                  firstName: 'FIRSTNAME',
                  lastName: 'LASTNAME',
                  emailId: 'TALARI.GEETHAMRUTHA1@VERIZON.COM',
                  phoneNumber: '6024763358',
                  streetType: 'RD',
                },
                contactPersonPhone: '6024763358',
                emailId: 'TALARI.GEETHAMRUTHA1@VERIZON.COM',
              },
              mtn: 'newLine1',
              isSharePlanAdded: false,
              isE911AddressValidated: false,
              kidsPlanParentMtn: false,
              mcsSubscription: [],
              fiveGUpSell: false,
              e911AddressSameAsServiceAddress: false,
              unpairedGrantor: false,
              totalAddedFeaturesPrice: '0.0',
            },
            mtnDetails: {
              dummyMTNForDomain: '9999999901',
              lineNumber: 'newLine1',
              mobileNumber: '0000000000',
            },
            securityDepositAmount: '400',
            lineNumber: 'newLine1',
            fiveGToFourGDownGrade: false,
            deviceTypeSelected: 'Smartphones',
            lineRefundTotal: 0.0,
            lineExchangeTotal: 400.0,
            totalDueMonthlyBeforeCredit: 0.0,
            sugAllowed: false,
            totalDueAddOnMonthly: 0.0,
            totalPriceOfPlanAndPerks: '0.0',
            isCpe: false,
            isLTEHomeLine: false,
            isDevicePlanCompatible: false,
            portinMtnAssignment: false,
            impactedLine: false,
            preOrBackOrder: false,
            ispuItem: false,
            ispuItemBYOD: false,
            isModConnected: false,
            modDevice: false,
            byodCapable: false,
            isCarLine: false,
            buySimOnly: false,
            broadBandInd: false,
            ispuDownPaymentAdjstRequired: false,
            ispuDownPaymentAmount: 0.0,
            lineWithSkipMDN: true,
            protectionNotRequired: false,
          },
        ]}
        // totalLines={{
        //   eSimPopUpData: { deviceInfo: { simInfo: { eId: '76876aj', makeEtniPersApi: true } } },
        // }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateDevicePayload={mockupdateDevicePayload}
        updateSetUpPopUp={mockupdateSetUpPopUp}
        UpdateBYODCheck={UpdateBYODCheck}
        setLoadMore={setLoadMore}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
  });

  test('should productlist null', () => {
    const props = {
      setLoadMore: jest.fn(),
      offers: myOffers,
      getDevices: jest.fn(),
      showToogle: true,
      totalLines: [{ mobileNumber: 4782303946 }],
      activeMtn: '4782303946',
      products: deviceData.products,
      selectedSkuId: 'sku5811679',
      existingSortOptions: [
        { label: 'Customer Rating', value: 'product_average_rating_f desc', isSelected: false },
        { label: 'Featured', value: '', isSelected: true },
        { label: 'Price High To Low', value: 'product_min_fullRetailPrice_f desc', isSelected: false },
        { label: 'Price Low To High', value: 'product_min_fullRetailPrice_f asc', isSelected: false },
      ],
      cartDetails: deviceData.cartDetails,
      errorMessage: '',
      landingData: deviceData.landingData,
      lineHasOffer: false,
      UpdateBYODCheck: jest.fn(),
      setToggle: jest.fn(),
    };
    props.products['4782303946'].gridWall.productList = [];
    render(<GridwallDevices {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });

  test('should gridWall null', () => {
    const props = {
      setLoadMore: jest.fn(),
      offers: myOffers,
      getDevices: jest.fn(),
      showToogle: true,
      totalLines: [{ mobileNumber: 4782303946 }],
      activeMtn: '4782303946',
      products: deviceData.products,
      selectedSkuId: 'sku5811679',
      existingSortOptions: [
        { label: 'Customer Rating', value: 'product_average_rating_f desc', isSelected: false },
        { label: 'Featured', value: '', isSelected: true },
        { label: 'Price High To Low', value: 'product_min_fullRetailPrice_f desc', isSelected: false },
        { label: 'Price Low To High', value: 'product_min_fullRetailPrice_f asc', isSelected: false },
      ],
      cartDetails: deviceData.cartDetails,
      errorMessage: '',
      landingData: deviceData.landingData,
      lineHasOffer: false,
      UpdateBYODCheck: jest.fn(),
      setToggle: jest.fn(),
    };
    props.products['4782303946'].gridWall = {};
    render(<GridwallDevices {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });

  test('should pagination null', () => {
    const props = {
      setLoadMore: jest.fn(),
      offers: myOffers,
      getDevices: jest.fn(),
      showToogle: true,
      totalLines: [{ mobileNumber: 4782303946 }],
      activeMtn: '4782303946',
      products: deviceData.products,
      selectedSkuId: 'sku5811679',
      existingSortOptions: [
        { label: 'Customer Rating', value: 'product_average_rating_f desc', isSelected: false },
        { label: 'Featured', value: '', isSelected: true },
        { label: 'Price High To Low', value: 'product_min_fullRetailPrice_f desc', isSelected: false },
        { label: 'Price Low To High', value: 'product_min_fullRetailPrice_f asc', isSelected: false },
      ],
      cartDetails: deviceData.cartDetails,
      errorMessage: '',
      landingData: deviceData.landingData,
      lineHasOffer: false,
      UpdateBYODCheck: jest.fn(),
      setToggle: jest.fn(),
    };
    props.products['4782303946'].gridWall.pagination = {};
    render(<GridwallDevices {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });

  test('should sortOptions null', () => {
    const props = {
      setLoadMore: jest.fn(),
      offers: myOffers,
      getDevices: jest.fn(),
      showToogle: true,
      totalLines: [{ mobileNumber: 4782303946 }],
      activeMtn: '4782303946',
      products: deviceData.products,
      selectedSkuId: 'sku5811679',
      existingSortOptions: [
        { label: 'Customer Rating', value: 'product_average_rating_f desc', isSelected: false },
        { label: 'Featured', value: '', isSelected: true },
        { label: 'Price High To Low', value: 'product_min_fullRetailPrice_f desc', isSelected: false },
        { label: 'Price Low To High', value: 'product_min_fullRetailPrice_f asc', isSelected: false },
      ],
      cartDetails: deviceData.cartDetails,
      errorMessage: '',
      landingData: deviceData.landingData,
      lineHasOffer: false,
      UpdateBYODCheck: jest.fn(),
      setToggle: jest.fn(),
    };
    props.products['4782303946'].gridWall.sortOptions = {};
    render(<GridwallDevices {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });

  test('should products null', () => {
    const props = {
      setLoadMore: jest.fn(),
      offers: myOffers,
      getDevices: jest.fn(),
      showToogle: true,
      totalLines: [{ mobileNumber: 4782303946 }],
      activeMtn: '4782303946',
      products: deviceData.products,
      selectedSkuId: 'sku5811679',
      existingSortOptions: [
        { label: 'Customer Rating', value: 'product_average_rating_f desc', isSelected: false },
        { label: 'Featured', value: '', isSelected: true },
        { label: 'Price High To Low', value: 'product_min_fullRetailPrice_f desc', isSelected: false },
        { label: 'Price Low To High', value: 'product_min_fullRetailPrice_f asc', isSelected: false },
      ],
      cartDetails: deviceData.cartDetails,
      errorMessage: '',
      landingData: deviceData.landingData,
      lineHasOffer: false,
      UpdateBYODCheck: jest.fn(),
      setToggle: jest.fn(),
    };
    props.products = {};
    render(<GridwallDevices {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });

  test('should total lines null', () => {
    const props = {
      setLoadMore: jest.fn(),
      offers: myOffers,
      getDevices: jest.fn(),
      showToogle: true,
      totalLines: [{ mobileNumber: 4782303946 }],
      activeMtn: '4782303946',
      products: deviceData.products,
      selectedSkuId: 'sku5811679',
      existingSortOptions: [
        { label: 'Customer Rating', value: 'product_average_rating_f desc', isSelected: false },
        { label: 'Featured', value: '', isSelected: true },
        { label: 'Price High To Low', value: 'product_min_fullRetailPrice_f desc', isSelected: false },
        { label: 'Price Low To High', value: 'product_min_fullRetailPrice_f asc', isSelected: false },
      ],
      cartDetails: deviceData.cartDetails,
      errorMessage: '',
      landingData: deviceData.landingData,
      lineHasOffer: false,
      UpdateBYODCheck: jest.fn(),
      setToggle: jest.fn(),
    };
    delete props.totalLines;
    render(<GridwallDevices {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
});

describe('should call filter component', () => {
  const props = {
    formattedDeviceId: '354615755742126',
    idScanModalValue: jest.fn(true),
    setLoadMore: jest.fn(),
    setToggle: jest.fn(),
    UpdateBYODCheck: jest.fn(),
    getDevices: jest.fn(),
    resetToggleOptions: jest.fn(),
    isDWOS: false,
    showToogle: true,
    offerSourceCheck: true,
    offerSubType: 'Virtual Reward',
    offerSourceSystem: 'national',
    rebeaBYODCheck: false,
    intentCheck: true,
    isOffersStacked: false,
    offerMessage: true,
    isProductListLoading: false,
    ValidateDeviceSimIdResult: {
      serviceHeader: {
        clientId: 'OMNI-RETAIL',
        statusMsg: 'SUCCESS',
        serviceName: 'SalesOrderPurchase',
        userId: '',
        statusCode: '00',
        sessionId: '',
        correlationId: 'soe-cart-2024.09.18.09.51.40-412.0166586677088',
      },
      serviceBody: {
        serviceResponse: {
          context: {
            caseId: 'SOP-15792935-E01',
            contextInfo: {
              callReason: 'SalesOrderPurchase',
              processStep: 'GridWallPDP',
              processAction: '',
              availablePaths: [
                {
                  path: 'GridWallPDP',
                },
              ],
            },
            customerInfo: {
              nocByod: false,
              accountNumber: '',
              cartCreator: '3143040921',
              processingMTN: '',
              registerNumber: 0,
              noc: false,
              myvPage: false,
            },
            cartInfo: {
              cartItemCount: 0,
              cartId: '05caf95d-4b57-4dd5-87de-2b4ccfbcc9d7',
              discountPromoTotal: 0.0,
              registerNumber: 0,
              protectionNotRequired: false,
              fmiCheck: false,
              isFlexV2: false,
              isPrepaidToPostpaidMigration: false,
              instantCreditAmount: 0,
              ngdFlow: false,
            },
            deviceInfo: {
              simInfo: {
                iccid: '',
                mfgCode: '',
                launchPackageSku: 'IPHONE14PRO-NVZW',
                prodName: '',
                preferredSoftSim: 'UNIVESIM5G-SA-D',
                launchPackageSkuType: 'IPHONE14PRO-NVZW',
                pairedIccid: '',
                type: '',
                mtn: '',
                mobileNumber: '',
                active: false,
                aging: false,
                available: false,
                retired: false,
                grandFathered: false,
                status: '',
                euimid: '',
                imsiv: '',
                imsivf: '',
                iccIdStat: '',
                min: '',
                ispuCompatibleSIM: '',
                makeEtniPersApi: true,
                deviceId: '354615755195390',
                dfillCompatibleSim: '',
                esimid: '',
                eID: '89049032007108888100136113581639',
              },
              simInfo2: {
                iccid: '',
                mfgCode: '',
                launchPackageSku: 'IPHONE14PRO-NVZW',
                prodName: '',
                preferredSoftSim: 'UNIVESIM5G-SA-D',
                launchPackageSkuType: 'IPHONE14PRO-NVZW',
                pairedIccid: '',
                type: '',
                mtn: '',
                mobileNumber: '',
                active: false,
                aging: false,
                available: false,
                retired: false,
                grandFathered: false,
                status: '',
                euimid: '',
                imsiv: '',
                imsivf: '',
                iccIdStat: '',
                min: '',
                ispuCompatibleSIM: '',
                makeEtniPersApi: false,
                deviceId: '354615755742126',
                dfillCompatibleSim: '',
                esimid: '',
                eID: '89049032007108888100136113581639',
              },
              invokeIdScan: 'Y',
              deviceSimCompatible: 'N',
              deviceSimM2MPair: 'N',
              deviceESimCompatible: 'N',
              deviceESimM2MPair: 'N',
              deviceId: '354615755195390',
              color: {
                colorId: '',
                displayName: '',
                description: '',
                colorCssStyle: '',
              },
              imageName: 'iphone-14-pro-space-black-fall22-a',
              imageUrlMap: {
                defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a',
                largeImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-lg$',
                mediumImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-med$',
                miniImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-mini$',
                thumbImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-thumb$',
              },
              skuDisplayName: 'IPHONE14 PRO GENERIC NVZW',
              deviceSku: 'IPHONE14PRO-NVZW',
              isRestrictedDevice: 'N',
              deviceAttributes: {
                mfgCode: 'APL',
                mfgName: 'Apple',
                prodName: 'IPHONE14 PRO GENERIC NVZW',
                prodType: '5GSmartphone',
                equipModeCode: '5GE',
                equipMode: '5GDevice',
                gpsIndicator: 'Y',
                daccCode: '01791',
                deviceType: '5GE',
                deviceCategory: '5G Smartphone',
                productId: 'dev19920041',
                postpaidRestrictStartDate: '',
                prepayRestrictStartDate: '',
                wholesaleRestrictStartDate: '',
              },
              lostAndStolen: {
                lostStolen: 'N',
                nonPay: 'N',
              },
              numbershareCapability: '',
              price: {
                fullRetailPrice: {
                  contractText: '',
                },
                oneYearPrice: {
                  contractText: '',
                },
                devicePaymentPrice: [],
              },
              skipSimIdFlag: true,
              appleWatchFlag: false,
              fmipLocked: false,
              appleCarrieLock: true,
              e911AddrInd: '',
              simClass4G: 'NR',
              makeEtniPersApi: true,
              softMessages: [
                'If this is not a Verizon device, it may be carrier locked. Please contact the previous carrier for assistance.',
              ],
              standalonePairingEligible: true,
              deviceFamilyType: 'Phone',
              osType: 'Apple iOS',
              euiccCapable: 'Y',
              imei1: '354615755742126',
              imei2: '354615755195390',
              productFamily: 'iPhone 14 Pro NON VZW NA',
              productDisplayName: 'iPhone 14 Pro NON VZW NA',
              pairedImeiData: {
                pairedImei: '',
                eid: '',
                sku: '',
                preferredSim: '',
                devicePreferredSoftSim: '',
                simClass4G: '',
                euiccCapable: false,
              },
              simswapSessionId: '',
              eSIMOnly: true,
            },
          },
        },
      },
    },
  };

  beforeEach(() => {
    sessionStorage.setItem('isPearl', 'false');
    sessionStorage.setItem('APP_PROPERTIES', '{"pearlBYODFlow": "TRUE"}');
    jest.spyOn(console, 'error');
    // const ispdpenable = jest.fn();
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockImplementation(() => null);
    render(<GridwallDevices {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });

  it('should mount Filter component', () => {
    const testBrandFilter = screen.getByTestId('testBrandFilter');
    expect(testBrandFilter).toBeInTheDocument();
    fireEvent.change(testBrandFilter);
  });

  it('should mount Filter component for reset', () => {
    const testResetLink = screen.getByTestId('testResetLink');
    expect(testResetLink).toBeInTheDocument();
    fireEvent.click(testResetLink);
  });

  it('should mount Filter component for Dropdown Category', async () => {
    const category = await screen.findByTestId('testCategoryFilter');
    fireEvent.change(category, { target: { value: 'All devices' } });
    fireEvent.change(category, { target: { value: 'Basic Phones' } });
    fireEvent.change(category, { target: { value: 'Business Solutions' } });
    fireEvent.change(category, { target: { value: 'Certified Pre-owned' } });
    fireEvent.change(category, { target: { value: 'Unlocked Phones' } });
    fireEvent.change(category, { target: { value: 'Connected Smartwatches' } });
    fireEvent.change(category, { target: { value: 'Smartwatches' } });
  });

  it('should mount Filter component for Dropdown Os', () => {
    const osFilter = screen.getByTestId('testOsFilter');
    const icon = screen.getByRole('img', { name: /switch icon/i });
    const resetDevices = screen.getByTestId('testResetLink');
    fireEvent.change(osFilter, { target: { value: 'name' } });
    fireEvent.click(resetDevices);
    fireEvent.click(icon);
  });

  it.skip('sort item testing', async () => {
    const sort = await screen.findAllByTestId('sort-item');
    expect(sort[0]).toBeInTheDocument();
    fireEvent.click(sort[0]);
  });

  afterAll(() => {
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockRestore();
  });
});

describe('should call filter component for false', () => {
  const props = {
    formattedDeviceId: '354615755742126',
    idScanModalValue: jest.fn(true),
    setLoadMore: jest.fn(),
    setToggle: jest.fn(),
    UpdateBYODCheck: jest.fn(),
    getDevices: jest.fn(),
    resetToggleOptions: jest.fn(),
    isDWOS: false,
    showToogle: true,
    offerSourceCheck: true,
    offerSubType: 'Virtual Reward',
    offerSourceSystem: 'national',
    rebeaBYODCheck: false,
    intentCheck: true,
    isOffersStacked: false,
    offerMessage: true,
    isProductListLoading: false,
    ValidateDeviceSimIdResult: {
      serviceHeader: {
        clientId: 'OMNI-RETAIL',
        statusMsg: 'SUCCESS',
        serviceName: 'SalesOrderPurchase',
        userId: '',
        statusCode: '00',
        sessionId: '',
        correlationId: 'soe-cart-2024.09.18.09.51.40-412.0166586677088',
      },
      serviceBody: {
        serviceResponse: {
          context: {
            caseId: 'SOP-15792935-E01',
            contextInfo: {
              callReason: 'SalesOrderPurchase',
              processStep: 'GridWallPDP',
              processAction: '',
              availablePaths: [
                {
                  path: 'GridWallPDP',
                },
              ],
            },
            customerInfo: {
              nocByod: false,
              accountNumber: '',
              cartCreator: '3143040921',
              processingMTN: '',
              registerNumber: 0,
              noc: false,
              myvPage: false,
            },
            cartInfo: {
              cartItemCount: 0,
              cartId: '05caf95d-4b57-4dd5-87de-2b4ccfbcc9d7',
              discountPromoTotal: 0.0,
              registerNumber: 0,
              protectionNotRequired: false,
              fmiCheck: false,
              isFlexV2: false,
              isPrepaidToPostpaidMigration: false,
              instantCreditAmount: 0,
              ngdFlow: false,
            },
            deviceInfo: {
              simInfo: {
                iccid: '',
                mfgCode: '',
                launchPackageSku: 'IPHONE14PRO-NVZW',
                prodName: '',
                preferredSoftSim: 'UNIVESIM5G-SA-D',
                launchPackageSkuType: 'IPHONE14PRO-NVZW',
                pairedIccid: '',
                type: '',
                mtn: '',
                mobileNumber: '',
                active: false,
                aging: false,
                available: false,
                retired: false,
                grandFathered: false,
                status: '',
                euimid: '',
                imsiv: '',
                imsivf: '',
                iccIdStat: '',
                min: '',
                ispuCompatibleSIM: '',
                makeEtniPersApi: false,
                deviceId: '354615755195390',
                dfillCompatibleSim: '',
                esimid: '',
                eID: '89049032007108888100136113581639',
              },
              simInfo2: {
                iccid: '',
                mfgCode: '',
                launchPackageSku: 'IPHONE14PRO-NVZW',
                prodName: '',
                preferredSoftSim: 'UNIVESIM5G-SA-D',
                launchPackageSkuType: 'IPHONE14PRO-NVZW',
                pairedIccid: '',
                type: '',
                mtn: '',
                mobileNumber: '',
                active: false,
                aging: false,
                available: false,
                retired: false,
                grandFathered: false,
                status: '',
                euimid: '',
                imsiv: '',
                imsivf: '',
                iccIdStat: '',
                min: '',
                ispuCompatibleSIM: '',
                makeEtniPersApi: false,
                deviceId: '354615755742126',
                dfillCompatibleSim: '',
                esimid: '',
                eID: '89049032007108888100136113581639',
              },
              invokeIdScan: 'Y',
              deviceSimCompatible: 'N',
              deviceSimM2MPair: 'N',
              deviceESimCompatible: 'N',
              deviceESimM2MPair: 'N',
              deviceId: '354615755195390',
              color: {
                colorId: '',
                displayName: '',
                description: '',
                colorCssStyle: '',
              },
              imageName: 'iphone-14-pro-space-black-fall22-a',
              imageUrlMap: {
                defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a',
                largeImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-lg$',
                mediumImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-med$',
                miniImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-mini$',
                thumbImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-thumb$',
              },
              skuDisplayName: 'IPHONE14 PRO GENERIC NVZW',
              deviceSku: 'IPHONE14PRO-NVZW',
              isRestrictedDevice: 'N',
              deviceAttributes: {
                mfgCode: 'APL',
                mfgName: 'Apple',
                prodName: 'IPHONE14 PRO GENERIC NVZW',
                prodType: '5GSmartphone',
                equipModeCode: '5GE',
                equipMode: '5GDevice',
                gpsIndicator: 'Y',
                daccCode: '01791',
                deviceType: '5GE',
                deviceCategory: '5G Smartphone',
                productId: 'dev19920041',
                postpaidRestrictStartDate: '',
                prepayRestrictStartDate: '',
                wholesaleRestrictStartDate: '',
              },
              lostAndStolen: {
                lostStolen: 'N',
                nonPay: 'N',
              },
              numbershareCapability: '',
              price: {
                fullRetailPrice: {
                  contractText: '',
                },
                oneYearPrice: {
                  contractText: '',
                },
                devicePaymentPrice: [],
              },
              skipSimIdFlag: true,
              appleWatchFlag: false,
              fmipLocked: false,
              appleCarrieLock: true,
              e911AddrInd: '',
              simClass4G: 'NR',
              makeEtniPersApi: false,
              softMessages: [
                'If this is not a Verizon device, it may be carrier locked. Please contact the previous carrier for assistance.',
              ],
              standalonePairingEligible: true,
              deviceFamilyType: 'Phone',
              osType: 'Apple iOS',
              euiccCapable: 'Y',
              imei1: '354615755742126',
              imei2: '354615755195390',
              productFamily: 'iPhone 14 Pro NON VZW NA',
              productDisplayName: 'iPhone 14 Pro NON VZW NA',
              pairedImeiData: {
                pairedImei: '',
                eid: '',
                sku: '',
                preferredSim: '',
                devicePreferredSoftSim: '',
                simClass4G: '',
                euiccCapable: false,
              },
              simswapSessionId: '',
              eSIMOnly: true,
            },
          },
        },
      },
    },
  };

  beforeEach(() => {
    sessionStorage.setItem('isPearl', 'false');
    sessionStorage.setItem('APP_PROPERTIES', '{"pearlBYODFlow": "TRUE"}');
    jest.spyOn(console, 'error');
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockImplementation(() => null);
    render(<GridwallDevices {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });

  it('should mount Filter component', () => {
    const testBrandFilter = screen.getByTestId('testBrandFilter');
    expect(testBrandFilter).toBeInTheDocument();
    fireEvent.change(testBrandFilter);
  });

  it('should mount Filter component for reset', () => {
    const testResetLink = screen.getByTestId('testResetLink');
    expect(testResetLink).toBeInTheDocument();
    fireEvent.click(testResetLink);
  });

  it('should mount Filter component for Dropdown Category', async () => {
    const category = await screen.findByTestId('testCategoryFilter');
    fireEvent.change(category, { target: { value: 'All devices' } });
    fireEvent.change(category, { target: { value: 'Basic Phones' } });
    fireEvent.change(category, { target: { value: 'Business Solutions' } });
    fireEvent.change(category, { target: { value: 'Certified Pre-owned' } });
    fireEvent.change(category, { target: { value: 'Unlocked Phones' } });
    fireEvent.change(category, { target: { value: 'Connected Smartwatches' } });
    fireEvent.change(category, { target: { value: 'Smartwatches' } });
  });

  it('should mount Filter component for Dropdown Os', () => {
    const osFilter = screen.getByTestId('testOsFilter');
    const icon = screen.getByRole('img', { name: /switch icon/i });
    const resetDevices = screen.getByTestId('testResetLink');
    fireEvent.change(osFilter, { target: { value: 'name' } });
    fireEvent.click(resetDevices);
    fireEvent.click(icon);
  });

  it.skip('sort item testing', async () => {
    const sort = await screen.findAllByTestId('sort-item');
    expect(sort[0]).toBeInTheDocument();
    fireEvent.click(sort[0]);
  });

  afterAll(() => {
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockRestore();
  });
});

describe('device List component render', () => {
  const props = {
    formattedDeviceId: '354615755742126',
    idScanModalValue: jest.fn(true),
    setLoadMore: jest.fn(),
    ValidateDeviceSimIdResultStatus: 'fulfilled',
    ValidateDeviceSimIdResult: {
      serviceHeader: {
        clientId: 'OMNI-RETAIL',
        statusMsg: 'SUCCESS',
        serviceName: 'SalesOrderPurchase',
        userId: '',
        statusCode: '00',
        sessionId: '',
        correlationId: 'soe-cart-2024.09.18.09.51.40-412.0166586677088',
      },
      serviceBody: {
        serviceResponse: {
          context: {
            caseId: 'SOP-15792935-E01',
            contextInfo: {
              callReason: 'SalesOrderPurchase',
              processStep: 'GridWallPDP',
              processAction: '',
              availablePaths: [
                {
                  path: 'GridWallPDP',
                },
              ],
            },
            customerInfo: {
              nocByod: false,
              accountNumber: '',
              cartCreator: '3143040921',
              processingMTN: '',
              registerNumber: 0,
              noc: false,
              myvPage: false,
            },
            cartInfo: {
              cartItemCount: 0,
              cartId: '05caf95d-4b57-4dd5-87de-2b4ccfbcc9d7',
              discountPromoTotal: 0.0,
              registerNumber: 0,
              protectionNotRequired: false,
              fmiCheck: false,
              isFlexV2: false,
              isPrepaidToPostpaidMigration: false,
              instantCreditAmount: 0,
              ngdFlow: false,
            },
            deviceInfo: {
              simInfo: {
                iccid: '',
                mfgCode: '',
                launchPackageSku: 'IPHONE14PRO-NVZW',
                prodName: '',
                preferredSoftSim: 'UNIVESIM5G-SA-D',
                launchPackageSkuType: 'IPHONE14PRO-NVZW',
                pairedIccid: '',
                type: '',
                mtn: '',
                mobileNumber: '',
                active: false,
                aging: false,
                available: false,
                retired: false,
                grandFathered: false,
                status: '',
                euimid: '',
                imsiv: '',
                imsivf: '',
                iccIdStat: '',
                min: '',
                ispuCompatibleSIM: '',
                makeEtniPersApi: true,
                deviceId: '354615755195390',
                dfillCompatibleSim: '',
                esimid: '',
                eID: '89049032007108888100136113581639',
              },
              simInfo2: {
                iccid: '',
                mfgCode: '',
                launchPackageSku: 'IPHONE14PRO-NVZW',
                prodName: '',
                preferredSoftSim: 'UNIVESIM5G-SA-D',
                launchPackageSkuType: 'IPHONE14PRO-NVZW',
                pairedIccid: '',
                type: '',
                mtn: '',
                mobileNumber: '',
                active: false,
                aging: false,
                available: false,
                retired: false,
                grandFathered: false,
                status: '',
                euimid: '',
                imsiv: '',
                imsivf: '',
                iccIdStat: '',
                min: '',
                ispuCompatibleSIM: '',
                makeEtniPersApi: false,
                deviceId: '354615755742126',
                dfillCompatibleSim: '',
                esimid: '',
                eID: '89049032007108888100136113581639',
              },
              invokeIdScan: 'Y',
              deviceSimCompatible: 'N',
              deviceSimM2MPair: 'N',
              deviceESimCompatible: 'N',
              deviceESimM2MPair: 'N',
              deviceId: '354615755195390',
              color: {
                colorId: '',
                displayName: '',
                description: '',
                colorCssStyle: '',
              },
              imageName: 'iphone-14-pro-space-black-fall22-a',
              imageUrlMap: {
                defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a',
                largeImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-lg$',
                mediumImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-med$',
                miniImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-mini$',
                thumbImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-thumb$',
              },
              skuDisplayName: 'IPHONE14 PRO GENERIC NVZW',
              deviceSku: 'IPHONE14PRO-NVZW',
              isRestrictedDevice: 'N',
              deviceAttributes: {
                mfgCode: 'APL',
                mfgName: 'Apple',
                prodName: 'IPHONE14 PRO GENERIC NVZW',
                prodType: '5GSmartphone',
                equipModeCode: '5GE',
                equipMode: '5GDevice',
                gpsIndicator: 'Y',
                daccCode: '01791',
                deviceType: '5GE',
                deviceCategory: '5G Smartphone',
                productId: 'dev19920041',
                postpaidRestrictStartDate: '',
                prepayRestrictStartDate: '',
                wholesaleRestrictStartDate: '',
              },
              lostAndStolen: {
                lostStolen: 'N',
                nonPay: 'N',
              },
              numbershareCapability: '',
              price: {
                fullRetailPrice: {
                  contractText: '',
                },
                oneYearPrice: {
                  contractText: '',
                },
                devicePaymentPrice: [],
              },
              skipSimIdFlag: true,
              appleWatchFlag: false,
              fmipLocked: false,
              appleCarrieLock: true,
              e911AddrInd: '',
              simClass4G: 'NR',
              makeEtniPersApi: true,
              softMessages: [
                'If this is not a Verizon device, it may be carrier locked. Please contact the previous carrier for assistance.',
              ],
              standalonePairingEligible: true,
              deviceFamilyType: 'Phone',
              osType: 'Apple iOS',
              euiccCapable: 'Y',
              imei1: '354615755742126',
              imei2: '354615755195390',
              productFamily: 'iPhone 14 Pro NON VZW NA',
              productDisplayName: 'iPhone 14 Pro NON VZW NA',
              pairedImeiData: {
                pairedImei: '',
                eid: '',
                sku: '',
                preferredSim: '',
                devicePreferredSoftSim: '',
                simClass4G: '',
                euiccCapable: false,
              },
              simswapSessionId: '',
              eSIMOnly: true,
            },
          },
        },
      },
    },
    validateDeviceSimId: jest.fn(),
    resetToggleOptions: jest.fn(),
    scanCheck: 'EUP',
    popUp: true,
    devicestocompare: [
      {
        imgSrc: '',
        productDisplayName: 'sdfdsf',
        brandName: 'fdsfsd',
        productId: 123,
      },
    ],
    offers: mockOffers,
    getDevices: jest.fn(),
    showToogle: true,
    totalLines: [{ mobileNumber: 4782303946 }],
    activeMtn: '4782303946',
    products: deviceProps.products,
    selectedSkuId: 'sku5811679',
    existingSortOptions: [
      { label: 'Customer Rating', value: 'product_average_rating_f desc', isSelected: false },
      { label: 'Featured', value: '', isSelected: true },
      { label: 'Price High To Low', value: 'product_min_fullRetailPrice_f desc', isSelected: false },
      { label: 'Price Low To High', value: 'product_min_fullRetailPrice_f asc', isSelected: false },
    ],
    cartDetails: deviceProps.cartDetails,
    errorMessage: '',
    landingData: deviceProps.landingData,
    lineHasOffer: true,
    isDWOS: false,
    offerSourceSystem: 'national',
    offerSubType: 'Virtual Reward',
    intentCheck: true,
    isOffersStacked: false,
    UpdateBYODCheck: jest.fn(),
    eSimDetailsResultStatus: 'fulfilled',
    initSimDetailsResp: jest.fn(),
    updateToggleOptions: jest.fn(),
    setToggle: jest.fn(),
    isProductListLoading: true,
    requestBody: {
      data: {
        paginationData: {
          offset: 0,
        },
      },
    },
  };

  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });
  afterAll(() => {
    server.close();
    sessionStorage.setItem('APIContext', '');
  });

  beforeEach(() => {
    sessionStorage.setItem('isPearl', 'false');
    sessionStorage.setItem('APP_PROPERTIES', '{"pearlBYODFlow": "TRUE"}');
    Object.defineProperty(window, 'location', {
      value: new URL('http://example.com/sales/assisted/new/device/gridwall.html'),
      configurable: true,
    });
    render(<GridwallDevices {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('should click search button', () => {
    const testBackButton = screen.getByTestId('ShopNavSearchText');
    expect(testBackButton).toBeInTheDocument();
    fireEvent.click(testBackButton);
  });
  test('gridwall component', async () => {
    const category = await screen.findByTestId('testCategoryFilter');
    fireEvent.change(category, { target: { value: 'All devices' } });
    fireEvent.change(category, { target: { value: 'Basic Phones' } });
    fireEvent.change(category, { target: { value: 'Business Solutions' } });
    fireEvent.change(category, { target: { value: 'Certified Pre-owned' } });
    fireEvent.change(category, { target: { value: 'Unlocked Phones' } });
    fireEvent.change(category, { target: { value: 'Connected Smartwatches' } });
    fireEvent.change(category, { target: { value: 'Smartwatches' } });
  });
  test('Filter onClick function', () => {
    const brand = screen.getByTestId('testBrandFilter');
    fireEvent.change(brand, { target: { value: 'name' } });
  });
  test('Filter onClick function', () => {
    const brand = screen.getByTestId('test-toggle');
    fireEvent.click(brand);
  });
  test('Filter onClick function', () => {
    const osFilter = screen.getByTestId('testOsFilter');
    const icon = screen.getByRole('img', { name: /switch icon/i });
    const resetDevices = screen.getByTestId('testResetLink');
    fireEvent.change(osFilter, { target: { value: 'name' } });
    fireEvent.click(resetDevices);
    fireEvent.click(icon);
  });
  test('should keyDown on input', () => {
    const testSearch = screen.getByTestId('ShopNavSearchText');
    fireEvent.change(testSearch, { target: { value: 'name' } });
    fireEvent.keyPress(testSearch, { key: 'Enter', charCode: 13 });
  });
  test('search item testing', async () => {
    const searchBox = screen.getByTestId('ShopNavSearchText');
    fireEvent.change(searchBox, { target: { value: 'STK' } });
  });
  test('search item testing', async () => {
    const searchBox = screen.getByTestId('ShopNavSearchText');
    fireEvent.change(searchBox, { target: { value: 'STK' } });
    fireEvent.keyDown(searchBox, { key: 'Enter', keyCode: '13' });
  });
  test('search item testing and click sku', async () => {
    const searchBox = screen.getByTestId('ShopNavSearchText');
    fireEvent.change(searchBox, { target: { value: 'STKA' } });
  });
});
