import { render } from '../../modules/test-utils/renderHelper';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import SetDeviceListHook from './SetDeviceListHook';

describe('SetDeviceListHook', () => {
  it('should test hook when product list have 1 item', () => {
    const mockSetDeviceList = jest.fn();
    const props = {
      SkuListResult: { data: { data: { productList: [{ item: 'item 1' }] } } },
      setDeviceList: mockSetDeviceList,
    };
    render(<SetDeviceListHook {...props} />, { reducers: rootReducer, sagas: rootSaga });
    expect(mockSetDeviceList).toBeCalledWith([]);
  });
  it('should test hook when product list have more than 1 item', () => {
    const mockSetDeviceList = jest.fn();
    const props = {
      SkuListResult: { data: { data: { productList: [{ item: 'item 1' }, { item: 'item 2' }] } } },
      setDeviceList: mockSetDeviceList,
    };
    render(<SetDeviceListHook {...props} />, { reducers: rootReducer, sagas: rootSaga });
    expect(mockSetDeviceList).toBeCalledWith([{ item: 'item 1' }, { item: 'item 2' }]);
  });
});
