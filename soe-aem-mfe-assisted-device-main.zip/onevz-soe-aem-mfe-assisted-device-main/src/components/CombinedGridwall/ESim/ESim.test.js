import { fireEvent, render, screen } from '../../../modules/test-utils/renderHelper';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import ESim from './ESim';
import * as AssistedCradleService from 'onevzsoemfeframework/AssistedCradleService';
import * as DomService from 'onevzsoemfeframework/DomService';
// import { RadioButtonGroup } from '@vds/radio-buttons';

const mockFn = jest.fn();
const mockNavigate = jest.fn();
let mockQueryParams = {
  SecondNumber: 'true',
  searchByName: 'false',
};

jest.mock('react-router-dom', () => ({
  __esModule: true,
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => mockNavigate,
}));
jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradlePropertyV2: jest.fn(() => ['TRUE', 'TRUE']),
  }),
  { virtual: true },
);
jest.mock('onevzsoemfeframework/DomService', () => ({
  getQueryParamByName: (value) => mockQueryParams[value],
  isIpad: jest.fn(() => false),
}));

jest.mock('./ESimUI', () => (props) => {
  mockFn(props);
  return (
    <div>
      <label htmlFor='esim'>
        eSIM (Recommended)
        <input type='radio' id='esim' value='esim' onChange={props.handleRadioButon} />
      </label>
      <label htmlFor='physicalSim'>
        A physical SIM card
        <input type='radio' id='physicalSim' value='physicalSim' onChange={props.handleRadioButon} />
      </label>
      <button type='button' onClick={() => props.handleClick('Continue')}>
        Continue
      </button>
      <button type='button' onClick={() => props.onCloseOfferAcceptedModal()}>
        Cancel
      </button>
    </div>
  );
});

describe('ESim EsimActivationEnabled gating', () => {
  const baseProps = {
    totalLines: {
      eSimPopUpData: {
        deviceInfo: {
          simInfo: { eID: '76876aj', makeEtniPersApi: true, deviceId: 'device-1' },
        },
        sagaPayload: {},
        channel: 'OMNI-CARE',
      },
    },
    eSimModelData: {
      channel: 'OMNI-CARE',
      deviceInfo: { simInfo: { eID: '76876aj', makeEtniPersApi: true, deviceId: 'device-1' } },
    },
    updateDevicePayload: jest.fn(),
    updateSetUpPopUp: jest.fn(),
    isDualSimEntiLookupModalVisibleUpdate: jest.fn(),
    initSimDetailsCall: jest.fn(),
  };

  beforeEach(() => {
    window.mfe = { scmDeviceMfeEnable: true };
    mockNavigate.mockClear();
    mockQueryParams = {
      SecondNumber: 'true',
      searchByName: 'false',
    };
    localStorage.removeItem('featureEnablement');
    AssistedCradleService.getAssistedCradlePropertyV2.mockImplementation((params) => {
      if (params.includes('skipICCIDFFlag')) return ['FALSE'];
      if (params.includes('skipIccidCall')) return ['FALSE', 'FALSE'];
      if (params.includes('isMitekDeviceSwapEnabled')) return ['FALSE', 'FALSE'];
      return ['FALSE'];
    });
  });

  afterEach(() => {
    localStorage.removeItem('featureEnablement');
  });

  it('calls setEnableBYODbtn when EsimActivationEnabled is Y', () => {
    localStorage.setItem(
      'featureEnablement',
      JSON.stringify({ scmMiscFixFFlag: { EsimActivationEnabled: ['Y'] } }),
    );
    const setEnableBYODbtn = jest.fn();

    render(
      <ESim
        {...baseProps}
        setEnableBYODbtn={setEnableBYODbtn}
        isDeviceIMEIChange
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );

    fireEvent.click(screen.getByText('Continue'));

    expect(setEnableBYODbtn).toHaveBeenCalledWith(true);
    expect(baseProps.initSimDetailsCall).not.toHaveBeenCalled();
  });

  it('falls back to initSimDetailsCall when EsimActivationEnabled is not Y', () => {
    localStorage.setItem(
      'featureEnablement',
      JSON.stringify({ scmMiscFixFFlag: { EsimActivationEnabled: ['N'] } }),
    );
    const setEnableBYODbtn = jest.fn();

    render(
      <ESim
        {...baseProps}
        setEnableBYODbtn={setEnableBYODbtn}
        isDeviceIMEIChange
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );

    fireEvent.click(screen.getByText('Continue'));

    expect(setEnableBYODbtn).not.toHaveBeenCalled();
    expect(baseProps.initSimDetailsCall).toHaveBeenCalled();
  });
});

describe('ESim when radio button is ESim', () => {
  beforeEach(() => {
    // window.mfe = {scmDeviceMfeEnable : true};
    mockNavigate.mockClear();
    mockQueryParams = {
      SecondNumber: 'true',
      searchByName: 'false',
    };
  });

  it('should test ESim functionality when simInfo is true', async () => {
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateDevicePayload = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    const mockinitSimDetailsCall = jest.fn();

    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        totalLines={{
          eSimPopUpData: { deviceInfo: { simInfo: { eId: '76876aj', makeEtniPersApi: true } } },
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateDevicePayload={mockupdateDevicePayload}
        updateSetUpPopUp={mockupdateSetUpPopUp}
        ProspectByodFlow
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    expect(mockFn).toBeCalledWith(expect.objectContaining({ disableESIM: true }));
  });

  it('should test ESim functionality when simInfo is true and when scmDeviceMfeEnable is enabled', async () => {
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateDevicePayload = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    window.mfe = { scmDeviceMfeEnable: true };

    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        totalLines={{
          eSimPopUpData: { deviceInfo: { simInfo: { eId: '76876aj', makeEtniPersApi: true } } },
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateDevicePayload={mockupdateDevicePayload}
        updateSetUpPopUp={mockupdateSetUpPopUp}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    expect(mockFn).toBeCalledWith(expect.objectContaining({ disableESIM: true }));
  });

  it('should test ESim functionality when simInfo2 is true', async () => {
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateDevicePayload = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    window.mfe = { scmDeviceMfeEnable: true };
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        totalLines={{
          eSimPopUpData: { deviceInfo: { simInfo2: { eId: '76876aj', makeEtniPersApi: true } } },
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateDevicePayload={mockupdateDevicePayload}
        updateSetUpPopUp={mockupdateSetUpPopUp}
        ProspectByodFlow
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    expect(mockFn).toBeCalledWith(expect.objectContaining({ disableESIM: true }));
  });
  it('should test ESim functionality when simInfo2 is true 1', async () => {
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateDevicePayload = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    window.mfe = { scmDeviceMfeEnable: false };
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        totalLines={{
          eSimPopUpData: { deviceInfo: { simInfo2: { eId: '76876aj', makeEtniPersApi: true } } },
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateDevicePayload={mockupdateDevicePayload}
        updateSetUpPopUp={mockupdateSetUpPopUp}
        ProspectByodFlow
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    expect(mockFn).toBeCalledWith(expect.objectContaining({ disableESIM: true }));
  });

  it('should test ESim functionality when simInfo is empty object', async () => {
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateDevicePayload = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        totalLines={{
          eSimPopUpData: { deviceInfo: { simInfo: {} } },
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateDevicePayload={mockupdateDevicePayload}
        updateSetUpPopUp={mockupdateSetUpPopUp}
        ProspectByodFlow
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    expect(mockFn).toBeCalledWith(expect.objectContaining({ disableESIM: false }));
  });

  it('should test ESim updateSetUpPopUp should be called when cancel button is clicked', async () => {
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    const mockupdateDevicePayload = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        totalLines={{
          eSimPopUpData: { deviceInfo: { simInfo: {} } },
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateDevicePayload={mockupdateDevicePayload}
        updateSetUpPopUp={mockupdateSetUpPopUp}
        ProspectByodFlow
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(mockupdateSetUpPopUp).toBeCalled();
    expect(mockisDualSimEntiLookupModalVisibleUpdate).toBeCalled();
  });

  it('should test ESim when totallines is defined', async () => {
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    const mockupdateDevicePayload = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        totalLines={{
          eSimPopUpData: {
            deviceInfo: { simInfo: { makeEtniPersApi: true }, simInfo2: { makeEtniPersApi: true } },
          },
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateDevicePayload={mockupdateDevicePayload}
        updateSetUpPopUp={mockupdateSetUpPopUp}
        ProspectByodFlow
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(mockupdateSetUpPopUp).toBeCalled();
    expect(mockisDualSimEntiLookupModalVisibleUpdate).toBeCalled();
  });

  it('should test ESim when totallines is undefined', async () => {
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();

    const mockupdateDevicePayload = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        eSimModelData={{
          isFrom: 'isLocal',
          formattedDeviceId: 'abc123',
          apiRequest: { data: { lines: [{ device: { sim: { CurrentSimId: '' } } }] } },
          requestFlowType: 'DEVICE',
          scanFromLanding: false,
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateDevicePayload={mockupdateDevicePayload}
        updateSetUpPopUp={mockupdateSetUpPopUp}
        ProspectByodFlow
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(mockupdateSetUpPopUp).toBeCalled();
    expect(mockisDualSimEntiLookupModalVisibleUpdate).toBeCalled();
  });

  it('should test ESim when totallines is undefined and isBothSlotsESimCompatible is false', async () => {
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    const mockupdateDevicePayload = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    const setRepSelectedSimType = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        eSimModelData={{
          deviceInfo: { simInfo: { makeEtniPersApi: false }, simInfo2: { makeEtniPersApi: true } },
          sagaPayload: {},
          isByodUpdate: false,
          notRetailAndInDirect: false,
          channel: '',
          isFrom: 'isLocal',
          formattedDeviceId: '',
          apiRequest: { data: { lines: [{ device: { sim: { CurrentSimId: '' } } }] } },
          requestFlowType: '',
          scanFromLanding: false,
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateDevicePayload={mockupdateDevicePayload}
        updateSetUpPopUp={mockupdateSetUpPopUp}
        setRepSelectedSimType={setRepSelectedSimType}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
  });

  it('should test ESim when totallines is defined but linedetails.activeMtn is undefined and isBothSlotsESimCompatible is true', async () => {
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();

    const mockupdateDevicePayload = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        eSimModelData={{
          isFrom: '',
          requestFlowType: '',
          scanFromLanding: '',
        }}
        activeMtn='abcd'
        totalLines={{
          lineDetails: [{ mtn: 'abcd', isNewlyAddedLine: true }],
          eSimPopUpData: {
            apiRequest: { data: { lines: [{ device: { sim: { CurrentSimId: '' } } }] } },
            deviceInfo: { simInfo: { makeEtniPersApi: true }, simInfo2: { makeEtniPersApi: true, deviceId: 'abc123' } },
            formattedDeviceId: 'abc123',
          },
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateDevicePayload={mockupdateDevicePayload}
        updateSetUpPopUp={mockupdateSetUpPopUp}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(mockupdateSetUpPopUp).toBeCalled();
    expect(mockisDualSimEntiLookupModalVisibleUpdate).toBeCalled();
  });
  it('should test ESim when totallines is defined but linedetails is undefined and isBothSlotsESimCompatible is true', async () => {
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();

    const mockupdateDevicePayload = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        eSimModelData={{}}
        totalLines={{
          activeMtn: 'abcd',
          lineDetails: [{ mtn: 'abcd', isNewlyAddedLine: true }],
          eSimPopUpData: {
            sendSimFromLanding: false,
            apiRequest: { data: { lines: [{ device: { sim: { CurrentSimId: '' } } }] } },
            deviceInfo: {
              skuDisplayName: 'Iphone 11',
              simInfo: {
                makeEtniPersApi: true,
                dfillCompatibleSim: false,
                ispuCompatibleSIM: true,
                launchPackageSku: false,
                preferredSoftSim: true,
                iccid: 'abc123',
                eId: 'abc13f',
              },
              simInfo2: { makeEtniPersApi: true, deviceId: 'abc123' },
            },
            channel: 'CHAT-STORE',
            formattedDeviceId: 'abc123',
            isFrom: 'isLocal',
            scanFromLanding: false,
            sagaPayload: {
              simId: 'abcd',
              fromCpe: false,
              isCustomerProvidedEquipment: false,
            },
            requestFlowType: 'SIM',
            isByodUpdate: true,
          },
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateDevicePayload={mockupdateDevicePayload}
        updateSetUpPopUp={mockupdateSetUpPopUp}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(mockupdateSetUpPopUp).toBeCalled();
    expect(mockisDualSimEntiLookupModalVisibleUpdate).toBeCalled();
  });
});

describe('ESim when radio button is a physical sim card', () => {
  beforeEach(() => {
    mockNavigate.mockClear();
    mockQueryParams = {
      SecondNumber: 'true',
      searchByName: 'false',
    };
  });
  it('should test ESim when default parameters are used of eSimModelData', async () => {
    const mockupdateDevicePayload = jest.fn();
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    const setRepSelectedSimType = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        eSimModelData={{
          isFrom: '',
          formattedDeviceId: 'abc123',
          apiRequest: { data: { lines: [{ device: { sim: { CurrentSimId: '' } } }] } },
          requestFlowType: '',
          scanFromLanding: '',
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateSetUpPopUp={mockupdateSetUpPopUp}
        updateDevicePayload={mockupdateDevicePayload}
        setRepSelectedSimType={setRepSelectedSimType}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('radio', { name: 'A physical SIM card' }));
    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(mockupdateSetUpPopUp).toBeCalled();
    expect(mockisDualSimEntiLookupModalVisibleUpdate).toBeCalled();
    // expect(mockNavigation).toBeCalled();
  });

  it('should test ESim when isByodUpdate is true', async () => {
    window.vzdl = {
      user: {
        deviceDetail: '',
      },
    };
    const mockupdateDevicePayload = jest.fn();
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    const setRepSelectedSimType = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        eSimModelData={{
          isByodUpdate: true,
          isFrom: 'isLocal',
          formattedDeviceId: 'abc123',
          apiRequest: { data: { lines: [{ device: { sim: { CurrentSimId: '' } } }] } },
          requestFlowType: '',
          scanFromLanding: false,
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateSetUpPopUp={mockupdateSetUpPopUp}
        updateDevicePayload={mockupdateDevicePayload}
        setRepSelectedSimType={setRepSelectedSimType}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('radio', { name: 'A physical SIM card' }));
    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(mockupdateSetUpPopUp).toBeCalled();
    expect(mockisDualSimEntiLookupModalVisibleUpdate).toBeCalled();
    // expect(mockNavigation).toBeCalled();
  });

  it('should test ESim when sendSimFromLanding is true', async () => {
    const mockupdateDevicePayload = jest.fn();
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    const setRepSelectedSimType = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        eSimModelData={{
          isByodUpdate: true,
          isFrom: 'isLocal',
          formattedDeviceId: 'abc123',
          apiRequest: { data: { lines: [{ device: { sim: { CurrentSimId: '' } } }] } },
          requestFlowType: '',
          scanFromLanding: false,
          sendSimFromLanding: true,
          isIndirect: true,
          deviceInfo: { deviceSimCompatible: 'Y' },
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateSetUpPopUp={mockupdateSetUpPopUp}
        updateDevicePayload={mockupdateDevicePayload}
        setRepSelectedSimType={setRepSelectedSimType}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('radio', { name: 'A physical SIM card' }));
    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(mockupdateSetUpPopUp).toBeCalled();
    expect(mockisDualSimEntiLookupModalVisibleUpdate).toBeCalled();
  });

  it('should test ESim when totallines is undefined and isBothSlotsESimCompatible is false', async () => {
    const mockupdateDevicePayload = jest.fn();
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    const setRepSelectedSimType = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        eSimModelData={{
          deviceInfo: { simInfo: { makeEtniPersApi: true }, simInfo2: { makeEtniPersApi: false, deviceId: 'abc123' } },
          sagaPayload: {},
          isByodUpdate: false,
          notRetailAndInDirect: false,
          channel: '',
          isFrom: '',
          formattedDeviceId: 'abc123',
          apiRequest: { data: { lines: [{ device: { sim: { CurrentSimId: '' } } }] } },
          requestFlowType: '',
          scanFromLanding: '',
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateSetUpPopUp={mockupdateSetUpPopUp}
        updateDevicePayload={mockupdateDevicePayload}
        setRepSelectedSimType={setRepSelectedSimType}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('radio', { name: 'A physical SIM card' }));
    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(mockupdateSetUpPopUp).toBeCalled();
    expect(mockisDualSimEntiLookupModalVisibleUpdate).toBeCalled();
    // expect(mockNavigation).toBeCalled();
  });
  it('should test ESim when totallines is undefined and isBothSlotsESimCompatible is false with default parameters', async () => {
    const mockupdateDevicePayload = jest.fn();
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    const setRepSelectedSimType = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        eSimModelData={{
          contextUrl: '',
          isFrom: '',
          formattedDeviceId: '',
          apiRequest: { data: { lines: [{ device: { sim: { CurrentSimId: '' } } }] } },
          requestFlowType: '',
          scanFromLanding: '',
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateSetUpPopUp={mockupdateSetUpPopUp}
        updateDevicePayload={mockupdateDevicePayload}
        setRepSelectedSimType={setRepSelectedSimType}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('radio', { name: 'A physical SIM card' }));
    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(mockupdateSetUpPopUp).toBeCalled();
    expect(mockisDualSimEntiLookupModalVisibleUpdate).toBeCalled();
    // expect(mockNavigation).toBeCalled();
  });
  it('should test ESim when totallines is undefined and isBothSlotsESimCompatible is true', async () => {
    const mockupdateDevicePayload = jest.fn();
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    const setRepSelectedSimType = jest.fn();

    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        eSimModelData={{
          deviceInfo: { simInfo: { makeEtniPersApi: true }, simInfo2: { makeEtniPersApi: true, deviceId: '' } },
          sagaPayload: {},
          isByodUpdate: false,
          notRetailAndInDirect: false,
          channel: '',
          isFrom: '',
          formattedDeviceId: '',
          apiRequest: { data: { lines: [{ device: { sim: { CurrentSimId: '' } } }] } },
          requestFlowType: '',
          scanFromLanding: '',
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateSetUpPopUp={mockupdateSetUpPopUp}
        updateDevicePayload={mockupdateDevicePayload}
        setRepSelectedSimType={setRepSelectedSimType}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('radio', { name: 'A physical SIM card' }));
    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(mockupdateSetUpPopUp).toBeCalled();
    expect(mockisDualSimEntiLookupModalVisibleUpdate).toBeCalled();
    // expect(mockNavigation).toBeCalled();
  });
  it('should test ESim when totallines is undefined and isBothSlotsESimCompatible is true and simInfo iccid is not empty string', async () => {
    const mockupdateDevicePayload = jest.fn();
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    const setRepSelectedSimType = jest.fn();

    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        eSimModelData={{
          deviceInfo: {
            simInfo: { makeEtniPersApi: true, iccid: 'abc' },
            simInfo2: { makeEtniPersApi: true, deviceId: 'abc123' },
          },
          sagaPayload: {},
          isByodUpdate: false,
          notRetailAndInDirect: false,
          channel: '',
          isFrom: '',
          formattedDeviceId: 'abc123',
          apiRequest: { data: { lines: [{ device: { sim: { CurrentSimId: '' } } }] } },
          requestFlowType: '',
          scanFromLanding: '',
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateSetUpPopUp={mockupdateSetUpPopUp}
        updateDevicePayload={mockupdateDevicePayload}
        setRepSelectedSimType={setRepSelectedSimType}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('radio', { name: 'A physical SIM card' }));
    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(mockupdateSetUpPopUp).toBeCalled();
    expect(mockisDualSimEntiLookupModalVisibleUpdate).toBeCalled();
    // expect(mockNavigation).toBeCalled();
  });
  it('should test ESim when totallines is undefined and isBothSlotsESimCompatible is true and simInfo iccid is  empty string', async () => {
    const mockupdateDevicePayload = jest.fn();
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    const setRepSelectedSimType = jest.fn();

    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        eSimModelData={{
          deviceInfo: {
            simInfo: { makeEtniPersApi: true, iccid: '' },
            simInfo2: { makeEtniPersApi: true, deviceId: 'abc123' },
          },
          sagaPayload: {},
          isByodUpdate: false,
          notRetailAndInDirect: false,
          channel: '',
          isFrom: '',
          formattedDeviceId: 'abc123',
          apiRequest: { data: { lines: [{ device: { sim: { CurrentSimId: '' } } }] } },
          requestFlowType: '',
          scanFromLanding: '',
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateSetUpPopUp={mockupdateSetUpPopUp}
        updateDevicePayload={mockupdateDevicePayload}
        setRepSelectedSimType={setRepSelectedSimType}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('radio', { name: 'A physical SIM card' }));
    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(mockupdateSetUpPopUp).toBeCalled();
    expect(mockisDualSimEntiLookupModalVisibleUpdate).toBeCalled();
    // expect(mockNavigation).toBeCalled();
  });
  it('should test ESim when totallines is undefined and isBothSlotsESimCompatible is true and simInfo iccid is  empty string 1', async () => {
    const mockupdateDevicePayload = jest.fn();
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    const setRepSelectedSimType = jest.fn();
    // window.mfe.scmDeviceMfeEnable = false;
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        eSimModelData={{
          deviceInfo: {
            invokeIdScan: 'Y',
            makeEtniPersApi: true,
            simClass4G: 'NP',
            skuDisplayName: 'xyz',
            simInfo: {
              makeEtniPersApi: true,
              iccid: '',
              dfillCompatibleSim: '',
              eID: '',
              preferredSoftSim: 'ABC',
              ispuCompatibleSIM: '',
            },
            simInfo2: { makeEtniPersApi: true, deviceId: 'abc123' },
          },
          sagaPayload: {},
          isByodUpdate: false,
          notRetailAndInDirect: false,
          channel: 'OMNI-RETAIL',
          isFrom: '',
          formattedDeviceId: 'abc123',
          apiRequest: { data: { lines: [{ device: { sim: { CurrentSimId: '' } } }] } },
          requestFlowType: 'SIM',
          scanFromLanding: '',
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateSetUpPopUp={mockupdateSetUpPopUp}
        updateDevicePayload={mockupdateDevicePayload}
        setRepSelectedSimType={setRepSelectedSimType}
        sourcefrom='combinedgridwall'
        activeMtn='9867543579'
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    const mockNavigate = jest.fn().mockImplementation(() => {
      throw new Error('Test Error');
    });
    jest.mock('react-router-dom', () => ({
      ...jest.requireActual('react-router-dom'),
      useNavigate: () => mockNavigate,
    }));
    sessionStorage?.setItem('isACSSFlexRedesign', true);

    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(mockupdateSetUpPopUp).toBeCalled();
    expect(mockisDualSimEntiLookupModalVisibleUpdate).toBeCalled();
  });
});

describe('ESim uncovered branches', () => {
  beforeEach(() => {
    mockNavigate.mockClear();
    mockQueryParams = {
      SecondNumber: 'false',
      searchByName: 'false',
    };
    window.mfe = { scmDeviceMfeEnable: false };
  });

  it('covers simInfo2 eSim path, idScanModalValue, and vzdl update', () => {
    const updateDevicePayload = jest.fn();
    const updateSetUpPopUp = jest.fn();
    const isDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const idScanModalValue = jest.fn();
    window.vzdl = { user: {} };
    AssistedCradleService.getAssistedCradlePropertyV2.mockImplementation((params) => {
      if (params.includes('skipICCIDFFlag')) return ['FALSE'];
      if (params.includes('skipIccidCall')) return ['FALSE', 'TRUE'];
      if (params.includes('isMitekDeviceSwapEnabled')) return ['FALSE', 'TRUE'];
      return ['FALSE'];
    });
    DomService.isIpad.mockReturnValue(true);

    render(
      <ESim
        totalLines={{
          activeMtn: '5551234567',
          lineDetails: [{ mtn: '5551234567', isNewlyAddedLine: true }],
          eSimPopUpData: {
            deviceInfo: {
              deviceAttributes: { prodType: 'Phone', prodName: 'Test', mfgName: 'Acme' },
              deviceSku: 'sku-1',
              simInfo: { makeEtniPersApi: false },
              simInfo2: { makeEtniPersApi: true, deviceId: 'device-2', eID: 'eid-2' },
            },
            sagaPayload: {},
            channel: 'OMNI-CARE',
            contextUrl: '',
          },
        }}
        eSimModelData={{ channel: 'OMNI-CARE' }}
        deviceInfo={{ invokeIdScan: 'Y' }}
        idScanModalValue={idScanModalValue}
        updateDevicePayload={updateDevicePayload}
        updateSetUpPopUp={updateSetUpPopUp}
        isDualSimEntiLookupModalVisibleUpdate={isDualSimEntiLookupModalVisibleUpdate}
        initSimDetailsCall={jest.fn()}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );

    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));

    expect(idScanModalValue).toHaveBeenCalledWith(true);
    expect(updateDevicePayload).toHaveBeenCalledWith(
      expect.objectContaining({ deviceId: 'device-2', eid: 'eid-2' }),
    );
    expect(window.vzdl.user.deviceDetail).toBe('Phone_Acme_Test_sku-1_eSim-pSim_eSimSelected');
  });

  it('covers combinedgridwall cancel navigation', () => {
    mockQueryParams.fromPage = 'combinedgridwall';
    render(
      <ESim
        totalLines={{}}
        eSimModelData={{ channel: 'OMNI-CARE', contextUrl: '/context' }}
        activeMtn='9990001111'
        updateDevicePayload={jest.fn()}
        updateSetUpPopUp={jest.fn()}
        isDualSimEntiLookupModalVisibleUpdate={jest.fn()}
        initSimDetailsCall={jest.fn()}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );

    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));

    expect(mockNavigate).toHaveBeenCalledWith('/context/combinedgridwall.html?activeMtn=9990001111');
  });

  it('covers setRepSelectedSimType in handleRadioButon', () => {
    const setRepSelectedSimType = jest.fn();
    render(
      <ESim
        totalLines={{}}
        eSimModelData={{ channel: 'OMNI-CARE' }}
        updateDevicePayload={jest.fn()}
        updateSetUpPopUp={jest.fn()}
        isDualSimEntiLookupModalVisibleUpdate={jest.fn()}
        initSimDetailsCall={jest.fn()}
        setRepSelectedSimType={setRepSelectedSimType}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );

    fireEvent.click(screen.getByRole('radio', { name: 'A physical SIM card' }));

    expect(setRepSelectedSimType).toHaveBeenCalledWith('physicalSim');
  });
});
