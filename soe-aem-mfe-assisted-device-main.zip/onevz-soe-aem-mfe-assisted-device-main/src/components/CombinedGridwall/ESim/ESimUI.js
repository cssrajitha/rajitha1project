import React from 'react';
import { Body, Title } from '@vds/typography';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { Modal, ModalTitle } from '@vds/modals';
import styled from 'styled-components';
import { RadioButtonGroup } from '@vds/radio-buttons';
import { Button } from '@vds/buttons';
import { DARK_THEME_COLOR, LIGHT_THEME_COLOR } from '../../../constants/constants';

const titleCare = 'The BYOD device ID entered can be activated using a physical SIM card and also an eSIM.';
const subTitleCare = 'Please make a selection based on the customer preference to proceed with the transaction';
const eSimSubTextCare =
  "To activate and download an eSIM profile, the customers's device must be connected to Wi-Fi. Visit OST 353215 for eSIM activation";

const titleModal = 'Select a SIM type.';
const modalSubTitle = 'Entered device ID is eSIM and Physical SIM capable.';
const modalBody = 'Please make a selection based on the customer preference to proceed with the transaction.';
const esimsubTextDefault = "Connect customer's device to Wi-Fi to activate eSIM. Visit OST 353215.";
const eSimtext = 'eSIM (Recommended)';

const Wrapper = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 0.75rem;
  align-self: stretch;
  align-items: stretch;
`;
const SubStyle = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  margin-bottom: 1.5rem;
  > p {
    margin-bottom: 0.75rem;
  }
`;

const ButtonWrapper = styled.div`
  display: flex;
  justify-content: flex-start;
  gap: 0.75rem;
  padding-bottom: 2px;
  margin-top: 1.5rem;
`;

const ButtonStyle = styled.div`
  [class^='StyledButton-'] {
    padding: 0.125rem 1.3125rem;
    min-width: 9.375rem;
  }
`;

const ModalBodyWrapper = styled.div`
  display: flex;
  align-items: flex-start;
  margin-bottom: 2.75rem;
  [class^='RadioButtonGroupWrapper-'] > .radioWrapper {
    margin-top: 0.75rem;

    input[type='radio'] + label::before,
    input[type='radio']:hover + label::before,
    input[type='radio']:checked + label::before,
    input[type='radio']:checked:hover + label::before {
      content: none;
    }
  }
`;

function ESimUI(props) {
  const {
    isDualSimEntiLookupModalVisible,
    handleRadioButon,
    disableESIM,
    disablePSIM,
    handleClick,
    onCloseOfferAcceptedModal,
    disableContinueBtn,
    radioDefaultValue,
  } = props;
  let [enableEsimContent] = getAssistedCradlePropertyV2(['enableEsimContent']);
  enableEsimContent = /true/i.test(enableEsimContent);
  const esimsubText = disableESIM ? <p style={{ color: '#E0E0E0' }}> {esimsubTextDefault} </p> : esimsubTextDefault;
  const esimLabelText = disableESIM ? <p style={{ color: '#E0E0E0' }}> {eSimtext} </p> : eSimtext;
  const title = enableEsimContent ? titleModal : titleCare;
  const titleSub = enableEsimContent ? modalSubTitle : subTitleCare;
  const titleBody = enableEsimContent ? modalBody : '';
  const bodySubText = enableEsimContent ? esimsubText : eSimSubTextCare;
  const eSIMLabel = enableEsimContent ? esimLabelText : 'eSIM';
  const isDark = (window?.mfe?.scmDeviceMfeEnable && window?.mfe?.isDark) || false;

  const byodRadioSubText = (
    <Body color={isDark ? DARK_THEME_COLOR : LIGHT_THEME_COLOR} size='large' bold={false}>
      {bodySubText}
    </Body>
  );

  return (
    <Modal
      surface={isDark ? 'dark' : 'light'}
      opened={isDualSimEntiLookupModalVisible}
      fullScreenDialog={false}
      disableAnimation
      disableOutsideClick
      ariaLabel='Select sim type'
      width='560px'
      closeButton={<div />}
    >
      <Wrapper data-testid='eSimModal'>
        <ModalTitle>
          <Title color={isDark ? DARK_THEME_COLOR : LIGHT_THEME_COLOR} size='large' bold>
            {title}
          </Title>
        </ModalTitle>
        <SubStyle>
          <Body color={isDark ? DARK_THEME_COLOR : LIGHT_THEME_COLOR} size='large' primitive='p'>
            {titleSub}
          </Body>
          <Body color={isDark ? DARK_THEME_COLOR : LIGHT_THEME_COLOR} size='large' primitive='p'>
            {titleBody}
          </Body>
        </SubStyle>
      </Wrapper>

      <ModalBodyWrapper data-testid='RadioOptions'>
        <RadioButtonGroup
          // defaultValue={this.state.radioOptionSelected}
          data-testid='radio-button'
          surface={isDark ? 'dark' : 'light'}
          onChange={(e) => handleRadioButon(e)}
          error={false}
          defaultValue={radioDefaultValue || true}
          data={[
            {
              name: 'eSimBODYRadioGroup',
              'data-track': 'eSimSelect',
              label: eSIMLabel,
              children: byodRadioSubText,
              value: 'eSim',
              ariaLabel: 'eSim',
              disabled: disableESIM,
            },
            {
              name: 'eSimBODYRadioGroup',
              'data-track': 'pSimSelect',
              label: 'A physical SIM card',
              value: 'physicalSim',
              ariaLabel: 'physicalSim',
              disabled: disablePSIM,
            },
          ]}
        />
      </ModalBodyWrapper>

      <ButtonWrapper>
        <ButtonStyle>
          <Button
            data-track={radioDefaultValue === 'physicalSim' ? 'pSIM_Continue' : 'eSIM_Continue'}
            data-testid='continue-button'
            size='large'
            inverted={false}
            disabled={disableContinueBtn}
            use='primary'
            surface={isDark ? 'dark' : 'light'}
            onClick={() => handleClick('Continue')}
          >
            Continue
          </Button>
        </ButtonStyle>
        <ButtonStyle>
          <Button
            size='large'
            data-track='eSimCancel_button'
            data-testid='Cancel'
            inverted={false}
            disabled={false}
            use='secondary'
            surface={isDark ? 'dark' : 'light'}
            onClick={() => onCloseOfferAcceptedModal()}
          >
            Cancel
          </Button>
        </ButtonStyle>
      </ButtonWrapper>
    </Modal>
  );
}
export default ESimUI;
