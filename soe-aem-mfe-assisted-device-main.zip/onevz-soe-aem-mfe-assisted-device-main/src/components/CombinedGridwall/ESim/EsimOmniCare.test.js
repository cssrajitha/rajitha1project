import { fireEvent, render, screen } from '../../../modules/test-utils/renderHelper';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import ESim from './ESim';
// import { RadioButtonGroup } from '@vds/radio-buttons';

const mockFn = jest.fn();
jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradlePropertyV2: () => ['FALSE', 'FALSE'],
  }),
  { virtual: true },
);
jest.mock('onevzsoemfecommon/Helpers', () => ({
  getQueryParamByName: jest.fn(() => ({
    searchByName: false,
  })),
}));

jest.mock('./ESimUI', () => (props) => {
  mockFn(props);
  return (
    <div>
      <label htmlFor='eSim'>
        eSIM (Recommended)
        <input type='radio' id='eSim' value='eSim' onChange={props.handleRadioButon} />
      </label>
      <label htmlFor='physicalSim'>
        A physical SIM card
        <input type='radio' id='physicalSim' value='physicalSim' onChange={props.handleRadioButon} />
      </label>
      <button type='button' onClick={() => props.handleClick('Continue')}>
        Continue
      </button>
      <button type='button' onClick={() => props.onCloseOfferAcceptedModal()}>
        Cancel
      </button>
    </div>
  );
});

describe('ESim when radio button is a physical sim card', () => {
  it('should test ESim when default parameters are used of eSimModelData', async () => {
    const mockupdateDevicePayload = jest.fn();
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        eSimModelData={{
          isFrom: '',
          formattedDeviceId: 'abc123',
          apiRequest: { data: { lines: [{ device: { sim: { CurrentSimId: '' } } }] } },
          requestFlowType: '',
          scanFromLanding: '',
          channel: 'OMNI-CARE',
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateSetUpPopUp={mockupdateSetUpPopUp}
        updateDevicePayload={mockupdateDevicePayload}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('radio', { name: 'A physical SIM card' }));
    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(mockupdateSetUpPopUp).toBeCalled();
    expect(mockisDualSimEntiLookupModalVisibleUpdate).toBeCalled();
    // expect(mockNavigation).toBeCalled();
  });

  it('should redirect to gridwall page on click of cancel CTA', async () => {
    const mockupdateDevicePayload = jest.fn();
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        eSimModelData={{
          isFrom: '',
          formattedDeviceId: 'abc123',
          apiRequest: { data: { lines: [{ device: { sim: { CurrentSimId: '' } } }] } },
          requestFlowType: '',
          scanFromLanding: '',
          channel: 'OMNI-CARE',
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateSetUpPopUp={mockupdateSetUpPopUp}
        updateDevicePayload={mockupdateDevicePayload}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
  });

  it('should test ESim when isByodUpdate is true', async () => {
    const mockupdateDevicePayload = jest.fn();
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        eSimModelData={{
          isByodUpdate: true,
          isFrom: 'isLocal',
          formattedDeviceId: 'abc123',
          apiRequest: { data: { lines: [{ device: { sim: { CurrentSimId: '' } } }] } },
          requestFlowType: '',
          scanFromLanding: false,
          channel: 'OMNI-CARE',
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateSetUpPopUp={mockupdateSetUpPopUp}
        updateDevicePayload={mockupdateDevicePayload}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('radio', { name: 'A physical SIM card' }));
    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(mockupdateSetUpPopUp).toBeCalled();
    expect(mockisDualSimEntiLookupModalVisibleUpdate).toBeCalled();
    // expect(mockNavigation).toBeCalled();
  });

  it('should test ESim when sendSimFromLanding is true', async () => {
    const mockupdateDevicePayload = jest.fn();
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        eSimModelData={{
          isByodUpdate: true,
          isFrom: 'isLocal',
          formattedDeviceId: 'abc123',
          apiRequest: { data: { lines: [{ device: { sim: { CurrentSimId: '' } } }] } },
          requestFlowType: '',
          scanFromLanding: false,
          sendSimFromLanding: true,
          isIndirect: true,
          deviceInfo: { deviceSimCompatible: 'Y' },
          channel: 'OMNI-CARE',
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateSetUpPopUp={mockupdateSetUpPopUp}
        updateDevicePayload={mockupdateDevicePayload}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('radio', { name: 'A physical SIM card' }));
    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(mockupdateSetUpPopUp).toBeCalled();
    expect(mockisDualSimEntiLookupModalVisibleUpdate).toBeCalled();
  });

  it('should test ESim when totallines is undefined and isBothSlotsESimCompatible is false', async () => {
    const mockupdateDevicePayload = jest.fn();
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        eSimModelData={{
          deviceInfo: { simInfo: { makeEtniPersApi: true }, simInfo2: { makeEtniPersApi: false, deviceId: 'abc123' } },
          sagaPayload: {},
          isByodUpdate: false,
          notRetailAndInDirect: false,
          isFrom: '',
          formattedDeviceId: 'abc123',
          apiRequest: { data: { lines: [{ device: { sim: { CurrentSimId: '' } } }] } },
          requestFlowType: '',
          scanFromLanding: '',
          channel: 'OMNI-CARE',
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateSetUpPopUp={mockupdateSetUpPopUp}
        updateDevicePayload={mockupdateDevicePayload}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('radio', { name: 'A physical SIM card' }));
    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(mockupdateSetUpPopUp).toBeCalled();
    expect(mockisDualSimEntiLookupModalVisibleUpdate).toBeCalled();
    // expect(mockNavigation).toBeCalled();
  });
  it('should test ESim when totallines is undefined and isBothSlotsESimCompatible is false with default parameters', async () => {
    const mockupdateDevicePayload = jest.fn();
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        eSimModelData={{
          contextUrl: '',
          isFrom: '',
          formattedDeviceId: '',
          apiRequest: { data: { lines: [{ device: { sim: { CurrentSimId: '' } } }] } },
          requestFlowType: '',
          scanFromLanding: '',
          channel: 'OMNI-CARE',
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateSetUpPopUp={mockupdateSetUpPopUp}
        updateDevicePayload={mockupdateDevicePayload}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('radio', { name: 'A physical SIM card' }));
    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(mockupdateSetUpPopUp).toBeCalled();
    expect(mockisDualSimEntiLookupModalVisibleUpdate).toBeCalled();
    // expect(mockNavigation).toBeCalled();
  });
  it('should test ESim when totallines is undefined and isBothSlotsESimCompatible is true', async () => {
    const mockupdateDevicePayload = jest.fn();
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        eSimModelData={{
          deviceInfo: { simInfo: { makeEtniPersApi: true }, simInfo2: { makeEtniPersApi: true, deviceId: '' } },
          sagaPayload: {},
          isByodUpdate: false,
          notRetailAndInDirect: false,
          isFrom: '',
          formattedDeviceId: '',
          apiRequest: { data: { lines: [{ device: { sim: { CurrentSimId: '' } } }] } },
          requestFlowType: '',
          scanFromLanding: '',
          channel: 'OMNI-CARE',
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateSetUpPopUp={mockupdateSetUpPopUp}
        updateDevicePayload={mockupdateDevicePayload}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('radio', { name: 'A physical SIM card' }));
    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(mockupdateSetUpPopUp).toBeCalled();
    expect(mockisDualSimEntiLookupModalVisibleUpdate).toBeCalled();
    // expect(mockNavigation).toBeCalled();
  });
  it('should test ESim when totallines is undefined and isBothSlotsESimCompatible is true and simInfo iccid is not empty string', async () => {
    const mockupdateDevicePayload = jest.fn();
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        eSimModelData={{
          deviceInfo: {
            simInfo: { makeEtniPersApi: true, iccid: 'abc' },
            simInfo2: { makeEtniPersApi: true, deviceId: 'abc123' },
          },
          sagaPayload: {},
          isByodUpdate: false,
          notRetailAndInDirect: false,
          channel: 'OMNI-CARE',
          isFrom: '',
          formattedDeviceId: 'abc123',
          apiRequest: { data: { lines: [{ device: { sim: { CurrentSimId: '' } } }] } },
          requestFlowType: '',
          scanFromLanding: '',
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateSetUpPopUp={mockupdateSetUpPopUp}
        updateDevicePayload={mockupdateDevicePayload}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('radio', { name: 'A physical SIM card' }));
    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(mockupdateSetUpPopUp).toBeCalled();
    expect(mockisDualSimEntiLookupModalVisibleUpdate).toBeCalled();
    // expect(mockNavigation).toBeCalled();
  });
  it('should test ESim when totallines is undefined and isBothSlotsESimCompatible is true and simInfo iccid is  empty string', async () => {
    const mockupdateDevicePayload = jest.fn();
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        eSimModelData={{
          deviceInfo: {
            simInfo: { makeEtniPersApi: true, iccid: '' },
            simInfo2: { makeEtniPersApi: true, deviceId: 'abc123' },
          },
          sagaPayload: {},
          isByodUpdate: false,
          notRetailAndInDirect: false,
          isFrom: '',
          formattedDeviceId: 'abc123',
          apiRequest: { data: { lines: [{ device: { sim: { CurrentSimId: '' } } }] } },
          requestFlowType: '',
          scanFromLanding: '',
          channel: 'OMNI-CARE',
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateSetUpPopUp={mockupdateSetUpPopUp}
        updateDevicePayload={mockupdateDevicePayload}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('radio', { name: 'A physical SIM card' }));
    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(mockupdateSetUpPopUp).toBeCalled();
    expect(mockisDualSimEntiLookupModalVisibleUpdate).toBeCalled();
    // expect(mockNavigation).toBeCalled();
  });

  it('Should disable continue button when selected eSim option EUP BYOD', async () => {
    const mockupdateDevicePayload = jest.fn();
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        eSimModelData={{
          deviceInfo: {
            simInfo: { makeEtniPersApi: true, iccid: '' },
            simInfo2: { makeEtniPersApi: true, deviceId: 'abc123' },
          },
          sagaPayload: {},
          isByodUpdate: true,
          notRetailAndInDirect: false,
          isFrom: '',
          formattedDeviceId: 'abc123',
          apiRequest: { data: { lines: [{ device: { sim: { CurrentSimId: '' } } }] } },
          requestFlowType: '',
          scanFromLanding: '',
          channel: 'OMNI-CARE',
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateSetUpPopUp={mockupdateSetUpPopUp}
        updateDevicePayload={mockupdateDevicePayload}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('radio', { name: 'eSIM (Recommended)' }));
    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(mockupdateSetUpPopUp).toBeCalled();
    expect(mockisDualSimEntiLookupModalVisibleUpdate).toBeCalled();
  });
});
