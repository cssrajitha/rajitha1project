import { fireEvent, render, screen } from '../../../modules/test-utils/renderHelper';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import ESim from './ESim';
// import { RadioButtonGroup } from '@vds/radio-buttons';

const mockFn = jest.fn();
jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradlePropertyV2: () => ['TRUE', 'TRUE'],
  }),
  { virtual: true },
);
jest.mock('onevzsoemfeframework/DomService', () => ({
  getQueryParamByName: (value) => {
    if (value === 'SecondNumber') {
      return 'true';
    }
    if (value === 'etrServiceChanges') {
      return true;
    }
    if (value === 'searchByName') {
      return 'false';
    }
  },
}));

jest.mock('./ESimUI', () => (props) => {
  mockFn(props);
  return (
    <div>
      <label htmlFor='esim'>
        eSIM (Recommended)
        <input type='radio' id='esim' value='esim' onChange={props.handleRadioButon} />
      </label>
      <label htmlFor='physicalSim'>
        A physical SIM card
        <input type='radio' id='physicalSim' value='physicalSim' onChange={props.handleRadioButon} />
      </label>
      <button type='button' onClick={() => props.handleClick('Continue')}>
        Continue
      </button>
      <button type='button' onClick={() => props.onCloseOfferAcceptedModal()}>
        Cancel
      </button>
    </div>
  );
});

describe('ESim when radio button is ESim', () => {
  beforeEach(() => {
    // 1. Ensure any previous mocks are cleared
    jest.restoreAllMocks();
      window.mfe = {historyRef:{push:jest.fn()}};
  });

  it('should test ESim functionality when simInfo is true', async () => {
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateDevicePayload = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    const mockinitSimDetailsCall = jest.fn();

    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        totalLines={{
          eSimPopUpData: { deviceInfo: { simInfo: { eId: '76876aj', makeEtniPersApi: true } } },
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateDevicePayload={mockupdateDevicePayload}
        updateSetUpPopUp={mockupdateSetUpPopUp}
        ProspectByodFlow
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    expect(mockFn).toBeCalledWith(expect.objectContaining({ disableESIM: true }));
  });

  it('should test ESim functionality when simInfo is true and when scmDeviceMfeEnable is enabled', async () => {
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateDevicePayload = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    window.mfe.scmDeviceMfeEnable = true;

    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        totalLines={{
          eSimPopUpData: { deviceInfo: { simInfo: { eId: '76876aj', makeEtniPersApi: true } } },
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateDevicePayload={mockupdateDevicePayload}
        updateSetUpPopUp={mockupdateSetUpPopUp}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    expect(mockFn).toBeCalledWith(expect.objectContaining({ disableESIM: true }));
  });

  it('should test ESim functionality when simInfo2 is true', async () => {
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateDevicePayload = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        totalLines={{
          eSimPopUpData: { deviceInfo: { simInfo2: { eId: '76876aj', makeEtniPersApi: true } } },
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateDevicePayload={mockupdateDevicePayload}
        updateSetUpPopUp={mockupdateSetUpPopUp}
        ProspectByodFlow
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    expect(mockFn).toBeCalledWith(expect.objectContaining({ disableESIM: true }));
  });

  it('should test ESim functionality when simInfo is empty object', async () => {
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateDevicePayload = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        totalLines={{
          eSimPopUpData: { deviceInfo: { simInfo: {} } },
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateDevicePayload={mockupdateDevicePayload}
        updateSetUpPopUp={mockupdateSetUpPopUp}
        ProspectByodFlow
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    expect(mockFn).toBeCalledWith(expect.objectContaining({ disableESIM: false }));
  });

  it('should test ESim updateSetUpPopUp should be called when cancel button is clicked', async () => {
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    const mockupdateDevicePayload = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        totalLines={{
          eSimPopUpData: { deviceInfo: { simInfo: {} } },
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateDevicePayload={mockupdateDevicePayload}
        updateSetUpPopUp={mockupdateSetUpPopUp}
        ProspectByodFlow
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(mockupdateSetUpPopUp).toBeCalled();
    expect(mockisDualSimEntiLookupModalVisibleUpdate).toBeCalled();
  });

  it('should test ESim when totallines is defined', async () => {
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    const mockupdateDevicePayload = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        totalLines={{
          eSimPopUpData: {
            deviceInfo: { simInfo: { makeEtniPersApi: true }, simInfo2: { makeEtniPersApi: true } },
          },
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateDevicePayload={mockupdateDevicePayload}
        updateSetUpPopUp={mockupdateSetUpPopUp}
        ProspectByodFlow
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(mockupdateSetUpPopUp).toBeCalled();
    expect(mockisDualSimEntiLookupModalVisibleUpdate).toBeCalled();
  });

  it('should test ESim when totallines is undefined', async () => {
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();

    const mockupdateDevicePayload = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        eSimModelData={{
          isFrom: 'isLocal',
          formattedDeviceId: 'abc123',
          apiRequest: { data: { lines: [{ device: { sim: { CurrentSimId: '' } } }] } },
          requestFlowType: 'DEVICE',
          scanFromLanding: false,
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateDevicePayload={mockupdateDevicePayload}
        updateSetUpPopUp={mockupdateSetUpPopUp}
        ProspectByodFlow
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(mockupdateSetUpPopUp).toBeCalled();
    expect(mockisDualSimEntiLookupModalVisibleUpdate).toBeCalled();
  });

  it('should test ESim when totallines is undefined and isBothSlotsESimCompatible is false', async () => {
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    const mockupdateDevicePayload = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    const setRepSelectedSimType = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        eSimModelData={{
          deviceInfo: { simInfo: { makeEtniPersApi: false }, simInfo2: { makeEtniPersApi: true } },
          sagaPayload: {},
          isByodUpdate: false,
          notRetailAndInDirect: false,
          channel: '',
          isFrom: 'isLocal',
          formattedDeviceId: '',
          apiRequest: { data: { lines: [{ device: { sim: { CurrentSimId: '' } } }] } },
          requestFlowType: '',
          scanFromLanding: false,
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateDevicePayload={mockupdateDevicePayload}
        updateSetUpPopUp={mockupdateSetUpPopUp}
        setRepSelectedSimType={setRepSelectedSimType}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
  });

  it('should test ESim when totallines is defined but linedetails.activeMtn is undefined and isBothSlotsESimCompatible is true', async () => {
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();

    const mockupdateDevicePayload = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        eSimModelData={{
          isFrom: '',
          requestFlowType: '',
          scanFromLanding: '',
        }}
        activeMtn='abcd'
        totalLines={{
          lineDetails: [{ mtn: 'abcd', isNewlyAddedLine: true }],
          eSimPopUpData: {
            apiRequest: { data: { lines: [{ device: { sim: { CurrentSimId: '' } } }] } },
            deviceInfo: { simInfo: { makeEtniPersApi: true }, simInfo2: { makeEtniPersApi: true, deviceId: 'abc123' } },
            formattedDeviceId: 'abc123',
          },
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateDevicePayload={mockupdateDevicePayload}
        updateSetUpPopUp={mockupdateSetUpPopUp}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(mockupdateSetUpPopUp).toBeCalled();
    expect(mockisDualSimEntiLookupModalVisibleUpdate).toBeCalled();
  });
  it('should test ESim when totallines is defined but linedetails is undefined and isBothSlotsESimCompatible is true', async () => {
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();

    const mockupdateDevicePayload = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        eSimModelData={{}}
        totalLines={{
          activeMtn: 'abcd',
          lineDetails: [{ mtn: 'abcd', isNewlyAddedLine: true }],
          eSimPopUpData: {
            sendSimFromLanding: false,
            apiRequest: { data: { lines: [{ device: { sim: { CurrentSimId: '' } } }] } },
            deviceInfo: {
              skuDisplayName: 'Iphone 11',
              simInfo: {
                makeEtniPersApi: true,
                dfillCompatibleSim: false,
                ispuCompatibleSIM: true,
                launchPackageSku: false,
                preferredSoftSim: true,
                iccid: 'abc123',
                eId: 'abc13f',
              },
              simInfo2: { makeEtniPersApi: true, deviceId: 'abc123' },
            },
            channel: 'CHAT-STORE',
            formattedDeviceId: 'abc123',
            isFrom: 'isLocal',
            scanFromLanding: false,
            sagaPayload: {
              simId: 'abcd',
              fromCpe: false,
              isCustomerProvidedEquipment: false,
            },
            requestFlowType: 'SIM',
            isByodUpdate: true,
          },
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateDevicePayload={mockupdateDevicePayload}
        updateSetUpPopUp={mockupdateSetUpPopUp}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(mockupdateSetUpPopUp).toBeCalled();
    expect(mockisDualSimEntiLookupModalVisibleUpdate).toBeCalled();
  });
});

describe('ESim when radio button is ESim from combinedgridwall', () => {

  const MOCK_URL = 'http://localhost:4001/acss/care/assisted/combinedgridwall.html?activeMtn=78798908098&deviceId=dev19920005&offerEligible=Y&preferredSoftSim=Y&mtn=newLine1';
  const MOCK_PATHNAME = '/acss/care/assisted/combinedgridwall.html';
  const MOCK_SEARCH = '?activeMtn=78798908098&deviceId=dev19920005&offerEligible=Y&preferredSoftSim=Y&mtn=newLine1';

  beforeEach(() => {
    // 1. Ensure any previous mocks are cleared
    jest.restoreAllMocks();
      window.mfe = {scmDeviceMfeEnable:true,historyRef:{push:jest.fn()}};

    // 2. Use jest.spyOn to mock the read-only properties of window.location
    jest.spyOn(window, 'location', 'get').mockReturnValue({
      // The full URL, returned when code accesses window.location.href
      href: MOCK_URL,

      // This is the CRUCIAL part you need: the path component
      pathname: MOCK_PATHNAME,

      // The query string component
      search: MOCK_SEARCH,

      // Mock the functions to prevent JSDOM errors if your code calls them
      assign: jest.fn(),
      replace: jest.fn(),
      reload: jest.fn(),

      // Ensure toString also returns the full URL
      toString: () => MOCK_URL,
    });
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  it('should test ESim when totallines is undefined', async () => {
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();

    const mockupdateDevicePayload = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        eSimModelData={{
          isFrom: 'isLocal',
          formattedDeviceId: 'abc123',
          apiRequest: { data: { lines: [{ device: { sim: { CurrentSimId: '' } } }] } },
          requestFlowType: 'DEVICE',
          scanFromLanding: false,
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateDevicePayload={mockupdateDevicePayload}
        updateSetUpPopUp={mockupdateSetUpPopUp}
        ProspectByodFlow
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(mockupdateSetUpPopUp).toBeCalled();
    expect(mockisDualSimEntiLookupModalVisibleUpdate).toBeCalled();
  });

  it('should test ESim when totallines is undefined', async () => {
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    window.location.pathname = '/acss/care/assisted/combinedgridwall';
    const mockupdateDevicePayload = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        eSimModelData={{
          isFrom: 'isLocal',
          formattedDeviceId: 'abc123',
          apiRequest: { data: { lines: [{ device: { sim: { CurrentSimId: '' } } }] } },
          requestFlowType: 'DEVICE',
          scanFromLanding: false,
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateDevicePayload={mockupdateDevicePayload}
        updateSetUpPopUp={mockupdateSetUpPopUp}
        ProspectByodFlow
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(mockupdateSetUpPopUp).toBeCalled();
    expect(mockisDualSimEntiLookupModalVisibleUpdate).toBeCalled();
  });

  it('should test ESim when totallines is undefined && scmCombinedGridwallFlow', async () => {
    window.mfe.scmCombinedGridwallFlow  = true;
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();

    const mockupdateDevicePayload = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        eSimModelData={{
          isFrom: 'isLocal',
          formattedDeviceId: 'abc123',
          apiRequest: { data: { lines: [{ device: { sim: { CurrentSimId: '' } } }] } },
          requestFlowType: 'DEVICE',
          scanFromLanding: false,
          isByodUpdate: true,
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateDevicePayload={mockupdateDevicePayload}
        updateSetUpPopUp={mockupdateSetUpPopUp}
        ProspectByodFlow={false}
        sourcefrom="combinedgridwall"
        activeMtn="78798908098"
        
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(mockupdateSetUpPopUp).toBeCalled();
    expect(mockisDualSimEntiLookupModalVisibleUpdate).toBeCalled();
    window.mfe.scmCombinedGridwallFlow = false;
  });
});

describe('Psim when radio button is Psim from combinedgridwall', () => {
  const MOCK_URL =
    'http://localhost:4001/acss/care/assisted/combinedgridwall.html?activeMtn=78798908098&deviceId=dev19920005&offerEligible=Y&preferredSoftSim=Y&mtn=newLine1';
  const MOCK_PATHNAME = '/acss/care/assisted/combinedgridwall.html';
  const MOCK_SEARCH = '?activeMtn=78798908098&deviceId=dev19920005&offerEligible=Y&preferredSoftSim=Y&mtn=newLine1';

  beforeEach(() => {
    // 1. Ensure any previous mocks are cleared
    jest.restoreAllMocks();
    window.mfe = { scmDeviceMfeEnable: true, historyRef: { push: jest.fn() } };

    // 2. Use jest.spyOn to mock the read-only properties of window.location
    jest.spyOn(window, 'location', 'get').mockReturnValue({
      // The full URL, returned when code accesses window.location.href
      href: MOCK_URL,

      // This is the CRUCIAL part you need: the path component
      pathname: MOCK_PATHNAME,

      // The query string component
      search: MOCK_SEARCH,

      // Mock the functions to prevent JSDOM errors if your code calls them
      assign: jest.fn(),
      replace: jest.fn(),
      reload: jest.fn(),

      // Ensure toString also returns the full URL
      toString: () => MOCK_URL,
    });
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  it('should test ESim when totallines is undefined', async () => {
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();

    const mockupdateDevicePayload = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        eSimModelData={{
          isFrom: 'isLocal',
          formattedDeviceId: 'abc123',
          apiRequest: { data: { lines: [{ device: { sim: { CurrentSimId: '' } } }] } },
          requestFlowType: 'DEVICE',
          scanFromLanding: false,
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateDevicePayload={mockupdateDevicePayload}
        updateSetUpPopUp={mockupdateSetUpPopUp}
        ProspectByodFlow
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('radio', { name: 'A physical SIM card' }));
    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(mockupdateSetUpPopUp).toBeCalled();
    expect(mockisDualSimEntiLookupModalVisibleUpdate).toBeCalled();
  });

  it('should test ESim when totallines is undefined', async () => {
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();
    window.location.pathname = '/acss/care/assisted/combinedgridwall';
    const mockupdateDevicePayload = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        eSimModelData={{
          isFrom: 'isLocal',
          formattedDeviceId: 'abc123',
          apiRequest: { data: { lines: [{ device: { sim: { CurrentSimId: '' } } }] } },
          requestFlowType: 'DEVICE',
          scanFromLanding: false,
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateDevicePayload={mockupdateDevicePayload}
        updateSetUpPopUp={mockupdateSetUpPopUp}
        ProspectByodFlow
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('radio', { name: 'A physical SIM card' }));
    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(mockupdateSetUpPopUp).toBeCalled();
    expect(mockisDualSimEntiLookupModalVisibleUpdate).toBeCalled();
  });

  it('should test ESim when totallines is undefined && scmCombinedGridwallFlow', async () => {
    window.mfe.scmCombinedGridwallFlow = true;
    const mockisDualSimEntiLookupModalVisibleUpdate = jest.fn();
    const mockupdateSetUpPopUp = jest.fn();

    const mockupdateDevicePayload = jest.fn();
    const mockinitSimDetailsCall = jest.fn();
    render(
      <ESim
        initSimDetailsCall={mockinitSimDetailsCall}
        eSimModelData={{
          isFrom: 'isLocal',
          formattedDeviceId: 'abc123',
          apiRequest: { data: { lines: [{ device: { sim: { CurrentSimId: '' } } }] } },
          requestFlowType: 'DEVICE',
          scanFromLanding: false,
          isByodUpdate: true,
        }}
        isDualSimEntiLookupModalVisibleUpdate={mockisDualSimEntiLookupModalVisibleUpdate}
        isDualSimEntiLookupModalVisible
        updateDevicePayload={mockupdateDevicePayload}
        updateSetUpPopUp={mockupdateSetUpPopUp}
        ProspectByodFlow={false}
        sourcefrom='combinedgridwall'
        activeMtn='78798908098'
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(screen.getByRole('radio', { name: 'A physical SIM card' }));
    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(mockupdateSetUpPopUp).toBeCalled();
    expect(mockisDualSimEntiLookupModalVisibleUpdate).toBeCalled();
    window.mfe.scmCombinedGridwallFlow = false;
  });
});
