import React, { useState, useEffect } from 'react';
import { getQueryParamByName, isIpad } from 'onevzsoemfeframework/DomService';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { sendCustomEvent } from 'onevzsoemfeframework/Tagging';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import { cloneDeep } from 'lodash';
import { acssMfeBasePath } from 'onevzsoemfecommon/Helpers';
import FFLAGS from '../../../constants/fFlag.constant';
import { isFunctionalityEnabled } from '../../../modules/utils';
import ESimUI from './ESimUI';
import getPDPEnable from '../../../modules/utils/getPDPEnable';

let navigate = '';

function useNavigateMFE() {
  navigate = useNavigate();
}

function ESim(props) {
  const {
    totalLines,
    eSimModelData,
    initSimDetailsCall,
    ProspectByodFlow,
    updateDevicePayload,
    isDualSimEntiLookupModalVisibleUpdate,
    updateSetUpPopUp,
    scanCheck,
    setRepSelectedSimType,
    resetInput,
  } = props;
  const scmDeviceEnable = window?.mfe?.scmDeviceMfeEnable || false;
  // const navigate = scmDeviceEnable ? "" :useNavigate();

  try {
    useNavigateMFE();
  } catch (e) {
    /* istanbul ignore next */
    console.log('');
  }

  const dispatch = useDispatch();
  const isOmniCare = eSimModelData?.channel === 'OMNI-CARE' || scmDeviceEnable;
  const [disableContinueBtn, setDisableContinueBtn] = useState(scmDeviceEnable ? false : isOmniCare); // by default CTA will be disabled
  const [radioOptionSelected, setRadioOptionSelected] = useState('eSim');
  const ispdpenable = getPDPEnable();
  const isEsimActivationEnabled = isFunctionalityEnabled(
    FFLAGS?.scmMiscFixFFlag?.name,
    FFLAGS?.scmMiscFixFFlag?.attribute?.EsimActivationEnabled,
    FFLAGS?.scmMiscFixFFlag?.attribute?.eSimDbFlag,
  );
  const [skipIccidCall, isMitekDeviceSwapEnabled] = getAssistedCradlePropertyV2([
    'skipIccidCall',
    'isMitekDeviceSwapEnabled',
  ]);
  const skipICCIDFFlag = /true/i.test(getAssistedCradlePropertyV2(['skipICCIDFFlag'])?.[0]);
  const [flexFlowServiceChangeFFlag] = getAssistedCradlePropertyV2(['flexFlowServiceChangeFFlag']);
  const flexFlowServiceChange = /true/i.test(flexFlowServiceChangeFFlag) && getQueryParamByName('etrServiceChanges');
  let { eSimPopUpData = {} } = totalLines || {};
  let disableESIM = false;
  let disablePSIM = false;
  const isSecondNum = getQueryParamByName('SecondNumber') === 'true';

  useEffect(() => {
    if (disableESIM && isSecondNum) {
      setRadioOptionSelected('physicalSim');
    } else if (isSecondNum) {
      setRadioOptionSelected('eSim');
    }
  }, []);
  if (
    (eSimPopUpData?.deviceInfo?.simInfo?.makeEtniPersApi === true && !eSimPopUpData?.deviceInfo?.simInfo?.eID) ||
    (eSimPopUpData?.deviceInfo?.simInfo2?.makeEtniPersApi === true && !eSimPopUpData?.deviceInfo?.simInfo2?.eID)
  ) {
    disableESIM = true;
  }
  if (eSimModelData?.deviceInfo?.simInfo?.makeEtniPersApi === true && isSecondNum) {
    disablePSIM = true;
  } else if (eSimModelData?.deviceInfo?.simInfo?.makeEtniPersApi === false && isSecondNum) {
    disableESIM = true;
  }

  const handleClick = async (val) => {/* NOSONAR: Legacy large component retained; complexity refactor deferred to avoid functional risk */
    /* istanbul ignore else */
    if (val === 'Continue') {
      const landing = totalLines;
      if (!landing?.eSimPopUpData) {
        eSimPopUpData = eSimModelData;
      }
      let isBothSlotsESimCompatible = false;
      const { deviceInfo = {} } = cloneDeep(eSimPopUpData);
      const iccid = deviceInfo?.simInfo?.iccid;
      if (eSimPopUpData?.deviceInfo?.simInfo2?.makeEtniPersApi && eSimPopUpData?.deviceInfo?.simInfo?.makeEtniPersApi) {
        isBothSlotsESimCompatible = true;
      }
      const searchByName = getQueryParamByName('searchByName') === 'false' ? 'searchByName=false&' : '';
      let skuId = deviceInfo?.simInfo?.launchPackageSkuType ?? '';
      let preferredSoftSim = deviceInfo?.simInfo?.preferredSoftSim;
      let eId = '';
      if (ispdpenable) {
        skuId =
          !deviceInfo?.makeEtniPersApi && !deviceInfo?.simInfo?.makeEtniPersApi && radioOptionSelected === 'physicalSim'
            ? deviceInfo?.simInfo?.launchPackageSku
            : deviceInfo?.simInfo2?.launchPackageSku;
        preferredSoftSim =
          !deviceInfo?.makeEtniPersApi && deviceInfo?.simInfo?.makeEtniPersApi
            ? deviceInfo?.simInfo?.preferredSoftSim
            : deviceInfo?.simInfo2?.preferredSoftSim;
      }
      const deviceType = deviceInfo?.deviceAttributes?.prodType || '';
      const deviceName = deviceInfo?.deviceAttributes?.prodName || '';
      const deviceSku = deviceInfo?.deviceSku || '';
      const deviceMfgName = deviceInfo?.deviceAttributes?.mfgName || '';
      let deviceId = '';
      if (radioOptionSelected === 'eSim') {
        // eslint-disable-next-line no-shadow, prefer-const
        if (deviceInfo?.simInfo?.makeEtniPersApi) {
          deviceId = deviceInfo?.simInfo?.deviceId;
          eId = deviceInfo?.simInfo?.eID;
        } else if (deviceInfo?.simInfo2?.makeEtniPersApi) {
          deviceId = deviceInfo?.simInfo2?.deviceId;
          eId = deviceInfo?.simInfo2?.eID;
        }
        if (/true/i.test(isMitekDeviceSwapEnabled) && props?.deviceInfo?.invokeIdScan === 'Y' && isIpad()) {
          props?.idScanModalValue(true);
        }
        const { activeMtn = '' } = landing || {};
        let { lineDetails = '' } = landing || {};
        if (!landing?.lineDetails) {
          lineDetails = landing;
        }
        const {
          sagaPayload = {},
          isByodUpdate = false,
          notRetailAndInDirect = false,
          channel = '',
          isFrom,
          formattedDeviceId,
          apiRequest,
          requestFlowType,
          scanFromLanding,
          contextUrl,
        } = eSimPopUpData;

        if (deviceInfo?.simInfo2?.makeEtniPersApi === true && !isBothSlotsESimCompatible) {
          deviceInfo.simInfo = deviceInfo?.simInfo2;
        }
        /* istanbul ignore else */
        if (isBothSlotsESimCompatible) {
          if (deviceInfo?.simInfo2?.deviceId === formattedDeviceId) {
            deviceInfo.simInfo = deviceInfo?.simInfo2;
          }
        }

        const lineInfo =
          (activeMtn || props?.activeMtn) &&
          lineDetails &&
          lineDetails.filter((line) => line.mtn === totalLines.activeMtn || activeMtn);
        const value = !!(
          lineInfo &&
          lineInfo.length > 0 &&
          lineInfo[0].isNewlyAddedLine &&
          lineInfo[0].isNewlyAddedLine === true
        );
        const softSim = deviceInfo?.simInfo?.preferredSoftSim;
        const preferredSim = notRetailAndInDirect ? softSim : '';
        const SIM = iccid || preferredSim;
        const payload = {
          eSimOnlyDevice: !!(
            deviceInfo?.makeEtniPersApi &&
            deviceInfo?.simInfo?.makeEtniPersApi &&
            deviceInfo.simInfo &&
            !deviceInfo.simInfo.dfillCompatibleSim
          ),
          skuId: deviceInfo?.simInfo?.launchPackageSkuType ?? '',
          skuDisplayName: deviceInfo.skuDisplayName ? deviceInfo.skuDisplayName : '',
          simId: SIM, // Entered SIM IDx``
          simLocalId: deviceInfo?.simInfo?.iccid,
          fmipLocked: deviceInfo?.fmipLocked,
          manualEntrySimId: sagaPayload.simId ? sagaPayload.simId : '',
          cpSimCard:
            ((channel === 'OMNI-TELESALES' || channel === 'OMNI-CARE' || scmDeviceEnable || channel === 'CHAT-STORE') &&
              sagaPayload.simId) ||
            (requestFlowType === 'DEVICE' && deviceInfo?.simInfo?.iccid) ||
            sagaPayload.cpSimCard, // If the device has inbuilt sim, set customerProvidedSim as true
          cpSimCheckboxSelected: sagaPayload.cpSimCard,
          eid: deviceInfo && deviceInfo?.simInfo && deviceInfo?.simInfo?.eID ? deviceInfo?.simInfo?.eID : '',
          launchPackageSku:
            requestFlowType === 'SIM'
              ? (deviceInfo && deviceInfo.simInfo && deviceInfo.simInfo.launchPackageSku) || ''
              : '',
          preferredSoftSim:
            deviceInfo && deviceInfo.simInfo && deviceInfo.simInfo.preferredSoftSim
              ? deviceInfo.simInfo.preferredSoftSim
              : '',
          ispuCompatibleSIM:
            deviceInfo && deviceInfo.simInfo && deviceInfo.simInfo.ispuCompatibleSIM
              ? deviceInfo.simInfo.ispuCompatibleSIM
              : '',
          etniApi: true,
          currentSimIdInRequest: formattedDeviceId ? apiRequest.data.lines[0].device.sim.CurrentSimid : '',
          scanFromPDPLocalFlow: !!(
            isFrom === 'isLocal' &&
            scanFromLanding === false &&
            !sagaPayload.fromCpe &&
            !sagaPayload.isCustomerProvidedEquipment &&
            !isByodUpdate
          ),
          deviceId,
          ...(deviceInfo?.simClass4G === 'NP' &&
          ['OMNI-INDIRECT', 'OMNI-INDIRECT-TAB', 'OMNI-RETAIL', 'OMNI-RETAIL-TAB'].includes(channel) &&
          scanCheck === 'EUP'
            ? { setOdaIndicatorforEsimCall: true }
            : {}),
        };
        updateDevicePayload(payload);
        const vzdl = window?.vzdl || {};
        if (vzdl?.user)
          vzdl.user.deviceDetail = `${deviceType}_${deviceMfgName}_${deviceName}_${deviceSku}_eSim-pSim_eSimSelected`;
        window.vzdl = vzdl;
        sendCustomEvent('openView', window?.vzdl);
        isDualSimEntiLookupModalVisibleUpdate();
        const MTN = getQueryParamByName('activeMtn') || '';
        /* istanbul ignore else */
        if (skipIccidCall === 'TRUE' || skipICCIDFFlag) {
          const redirectUrl = flexFlowServiceChange
            ? 'combinedgridwall.html?etrServiceChanges=true&'
            : 'product-detail.html?';

          /* NOSONAR: Legacy large component retained; complexity refactor deferred to avoid functional risk */
          if (scmDeviceEnable) {
            if (window?.location?.pathname?.includes('combinedgridwall.html')){
              window?.mfe?.historyRef.push(
                `${acssMfeBasePath}/${redirectUrl}${searchByName}${
                  props?.sourcefrom === 'combinedgridwall' ? '&offerEligible=Y' : ''
                }&activeMtn=${props?.activeMtn ? props?.activeMtn : MTN}&deviceSKU=${skuId}&${
                  isByodUpdate ? 'isByodUpdate=true' : 'isFromCPE=true'
                }&deviceId=${deviceId}&eId=${eId}&preferredSoftSim=${preferredSoftSim}&eSim=true${
                  ProspectByodFlow ? '&prospectByodFlow=true' : ''
                }&fromPage=${props?.sourcefrom}${window?.mfe?.scmCombinedGridwallFlow ? '&isFromCombinedGridWall=true' : ''}`,
              );
            }
          } else {
            navigate(
              `${contextUrl}/${redirectUrl}${searchByName}${
                props?.sourcefrom === 'combinedgridwall' ? '&offerEligible=Y' : ''
              }&activeMtn=${props?.activeMtn ? props?.activeMtn : MTN}&deviceSKU=${skuId}&${
                isByodUpdate ? 'isByodUpdate=true' : 'isFromCPE=true'
              }&deviceId=${deviceId}&eId=${eId}&preferredSoftSim=${preferredSoftSim}&eSim=true${
                ProspectByodFlow ? '&prospectByodFlow=true' : ''
              }&fromPage=${props?.sourcefrom}`,
            );
          }
        } else if (
          isEsimActivationEnabled &&
          radioOptionSelected === 'eSim' &&
          scmDeviceEnable &&
          props?.isDeviceIMEIChange &&
          typeof props?.setEnableBYODbtn === 'function'
        ) {
          props.setEnableBYODbtn(true);
        } else {
          initSimDetailsCall({ isCustomerProvidedEquipment: ProspectByodFlow || value }, payload);
        }
        updateSetUpPopUp();
      } else if (radioOptionSelected === 'physicalSim') {/* istanbul ignore else */
        const {
          sagaPayload = {},
          isByodUpdate = false,
          sendSimFromLanding = false,
          notRetailAndInDirect = false,
          channel = '',
          isIndirect = false,
          isFrom,
          formattedDeviceId,
          apiRequest,
          requestFlowType,
          scanFromLanding,
          contextUrl,
        } = eSimPopUpData;
        // device id set based on the sim object which contains psim (makeEtniPersApi = false)
        if (!deviceInfo?.simInfo?.makeEtniPersApi) {
          deviceId = deviceInfo?.simInfo?.deviceId;
        } else if (!deviceInfo?.simInfo2?.makeEtniPersApi) {
          deviceId = deviceInfo?.simInfo2?.deviceId;
        } else {
          // samsung dual sim device, 1 sim supports both esim/psim
          // if psim is selected, deviceid is assigned from siminfo object
          deviceId = deviceInfo?.simInfo?.deviceId;
        }

        if (deviceInfo?.simInfo2?.makeEtniPersApi === false && !isBothSlotsESimCompatible) {
          deviceInfo.simInfo = deviceInfo?.simInfo2;
        }

        if (isBothSlotsESimCompatible) {
          if (deviceInfo?.simInfo?.iccid !== '') {
            deviceInfo.simInfo.iccid = '';
          } else if (deviceInfo?.simInfo2?.iccid !== '') {/* istanbul ignore else */
            deviceInfo.simInfo = deviceInfo?.simInfo2;
            deviceInfo.simInfo.iccid = '';
          }
        }

        const bothSlotEsimCompatible = isBothSlotsESimCompatible
          ? deviceInfo?.simInfo?.dfillCompatibleSim ?? deviceInfo?.simInfo?.preferredSoftSim ?? ''
          : deviceInfo?.simInfo?.preferredSoftSim;
        const isNotRetailandIndirect = notRetailAndInDirect ? bothSlotEsimCompatible : '';
        const simId = iccid && !sendSimFromLanding ? deviceInfo?.simInfo?.iccid : isNotRetailandIndirect;
/* istanbul ignore else */
        if (
          !sendSimFromLanding ||
          (sendSimFromLanding === true && isIndirect && isByodUpdate && deviceInfo?.deviceSimCompatible === 'Y')
        ) {
          sessionStorage.setItem('physicalSimFromCPE', true);
          const simInfo =
            deviceInfo && deviceInfo?.simInfo && deviceInfo?.simInfo?.preferredSoftSim
              ? deviceInfo?.simInfo?.preferredSoftSim
              : '';
          const payload = {
            eSimOnlyDevice: !!(
              deviceInfo?.makeEtniPersApi &&
              deviceInfo?.simInfo?.makeEtniPersApi &&
              deviceInfo?.simInfo &&
              !deviceInfo?.simInfo?.dfillCompatibleSim
            ),
            skuId: deviceInfo?.simInfo?.launchPackageSkuType ?? '',
            skuDisplayName: deviceInfo.skuDisplayName ? deviceInfo.skuDisplayName : '',
            deviceId,
            simId: iccid || isNotRetailandIndirect, // Entered SIM IDx``
            simLocalId: deviceInfo?.simInfo?.iccid,
            fmipLocked: deviceInfo.fmipLocked,
            manualEntrySimId: sagaPayload.simId ? sagaPayload.simId : '',
            cpSimCard:
              ((channel === 'OMNI-TELESALES' ||
                channel === 'OMNI-CARE' ||
                scmDeviceEnable ||
                channel === 'CHAT-STORE') &&
                sagaPayload.simId) ||
              (requestFlowType === 'DEVICE' && deviceInfo?.simInfo?.iccid) ||
              sagaPayload.cpSimCard, // If the device has inbuilt sim, set customerProvidedSim as true
            cpSimCheckboxSelected: sagaPayload.cpSimCard,
            eid: '',
            launchPackageSku:
              requestFlowType === 'SIM'
                ? (deviceInfo && deviceInfo.simInfo && deviceInfo.simInfo.launchPackageSku) || ''
                : '',

            preferredSoftSim: isBothSlotsESimCompatible
              ? deviceInfo?.simInfo?.dfillCompatibleSim ?? deviceInfo?.simInfo?.preferredSoftSim ?? ''
              : simInfo,
            ispuCompatibleSIM:
              deviceInfo && deviceInfo.simInfo && deviceInfo.simInfo.ispuCompatibleSIM
                ? deviceInfo.simInfo.ispuCompatibleSIM
                : '',
            etniApi: false,
            currentSimIdInRequest: formattedDeviceId ? apiRequest.data.lines[0].device.sim.CurrentSimid : '',
            scanFromPDPLocalFlow: !!(
              isFrom === 'isLocal' &&
              scanFromLanding === false &&
              !sagaPayload.fromCpe &&
              !sagaPayload.isCustomerProvidedEquipment &&
              !isByodUpdate
            ),
            selectedRadioButton: radioOptionSelected,
          };
          updateDevicePayload(payload);
        }
        const vzdl = window?.vzdl || {};
        /* istanbul ignore next */
        if (vzdl?.user)
          vzdl.user.deviceDetail = `${deviceType}_${deviceMfgName}_${deviceName}_${deviceSku}_eSim-pSim_pSimSelected`;
        window.vzdl = vzdl;
        sendCustomEvent('openView', window?.vzdl);
        isDualSimEntiLookupModalVisibleUpdate();
        updateSetUpPopUp();

        const MTN = getQueryParamByName('activeMtn') || '';
        const activeMTN = props?.activeMtn ? props?.activeMtn : MTN;
        // need to get cradle props
        // for now navigating to pdp 2.0
        // navigate(`${contextUrl}${/true/i.test(appPropsFromSession?.isProductDetailEnabled) ?"/product-detail.html":"/pdp.html"}?${searchByName}deviceSKU=${skuId}&${isByodUpdate ? "isByodUpdate=true" : "isFromCPE=true"}&deviceId=${deviceId}&simId=${simId}${props.ProspectByodFlow?"&prospectByodFlow=true":""}&activeMtn=${activeMTN}${props?.sourcefrom === "combinedgridwall" ? "&offerEligible=Y":""}`);
        /* istanbul ignore else */
        if (!scmDeviceEnable) {
          const redirectUrlPsim = flexFlowServiceChange
            ? 'combinedgridwall.html?etrServiceChanges=true&'
            : 'product-detail.html?';
          navigate(
            `${contextUrl}/${redirectUrlPsim}${searchByName}deviceSKU=${skuId}&${
              isByodUpdate ? 'isByodUpdate=true' : 'isFromCPE=true'
            }&deviceId=${deviceId}&simId=${simId}${
              ProspectByodFlow ? '&prospectByodFlow=true' : ''
            }&activeMtn=${activeMTN}${
              props?.sourcefrom === 'combinedgridwall' ? '&offerEligible=Y' : ''
            }&ispuCompatibleSIM=${deviceInfo?.simInfo?.ispuCompatibleSIM}&fromPage=${props?.sourcefrom}`
          );
        }

        if (scmDeviceEnable) {
          if (window?.location?.pathname?.includes('combinedgridwall.html')) {
            window?.mfe?.historyRef?.push(
              `${acssMfeBasePath}/product-detail.html?${searchByName}&deviceSKU=${skuId}&${
                isByodUpdate ? 'isByodUpdate=true' : 'isFromCPE=true'
              }&deviceId=${deviceId}&simId=${simId}${
                ProspectByodFlow ? '&prospectByodFlow=true' : ''
              }&activeMtn=${activeMTN}${
                props?.sourcefrom === 'combinedgridwall' ? '&offerEligible=Y' : ''
              }&ispuCompatibleSIM=${deviceInfo?.simInfo?.ispuCompatibleSIM}&fromPage=${props?.sourcefrom}
              ${window?.mfe?.scmCombinedGridwallFlow ? '&isFromCombinedGridWall=true' : ''}`,
            );
          }
        }
      }
    }
  };

  const onCloseOfferAcceptedModal = () => {
    const closeModalSelected = true;
    isDualSimEntiLookupModalVisibleUpdate(closeModalSelected);
    updateSetUpPopUp();
    // start redirect to previous page on click of CANCEL CTA from eSim + pSim modal
    if (isOmniCare) {
      const contextUrl = props?.eSimModelData?.contextUrl;
      /* istanbul ignore else */
      if (getQueryParamByName('fromPage') === 'combinedgridwall') {
        navigate(`${contextUrl}/combinedgridwall.html?activeMtn=${props.activeMtn}`);
      } else if (!scmDeviceEnable) {
        navigate(`${contextUrl}/landing.html`);
      } else if (scmDeviceEnable && typeof resetInput === 'function') {
        resetInput();
      }
    }
    // end redirect to previous page on click of CANCEL CTA from eSim + pSim modal
  };

  const handleRadioButon = (e) => {
    const simType = e?.target?.value;
    let disbaledBtn = false;
    setRadioOptionSelected(simType);
    if (isOmniCare && !scmDeviceEnable) {
      // show banner messaage and disable CTA if it's not add line flow.
      const alowedTypes = ['AAL', 'NSE', 'BYOD', 'NSEBYOD'];
      const propsLineActivityType = props.lineActivityType;
      if (simType === 'eSim' && !alowedTypes.includes(propsLineActivityType)) {
        let msg = '';
        msg =
          'We can not proceed further with eSim in this flow, please select physical sim or Please access the following path in ACSS to complete an add a line order when the customer is using an existing device and SIM/eSIM: Devices tab> Links/Action> Add line/CPE(NSO)';
        // disabling esim option in case of EUP BYOD
        disbaledBtn = true;
        dispatch(appMessageActions.addAppMessage(msg));
      } else {
        dispatch(appMessageActions.clearAppMessages());
      }
    }
    // enablning CTA button as rep selected eSim/pSim
    setDisableContinueBtn(disbaledBtn);
    if (typeof setRepSelectedSimType === 'function') {
      setRepSelectedSimType(e?.target?.value);
    }
  };

  return (
    <ESimUI
      isDualSimEntiLookupModalVisible={props.isDualSimEntiLookupModalVisible}
      handleRadioButon={handleRadioButon}
      disableESIM={disableESIM}
      disablePSIM={disablePSIM}
      handleClick={handleClick}
      onCloseOfferAcceptedModal={onCloseOfferAcceptedModal}
      disableContinueBtn={disableContinueBtn}
      radioDefaultValue={isOmniCare && !scmDeviceEnable ? '' : radioOptionSelected}
    />
  );
}
export default ESim;
