import { fireEvent, render, screen } from '../../../modules/test-utils/renderHelper';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import ESimUI from './ESimUI';

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    default: jest.fn(() => ({})),
    getAssistedCradleProperty: () => [true, true],
  }),
  { virtual: true },
);
jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradlePropertyV2: () => ['FALSE', 'FALSE'],
  }),
  { virtual: true },
);

describe('ESimUI', () => {
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });
  it('should test ESimUI', async () => {
    const mockhandleClick = jest.fn();
    const mockonCloseOfferAcceptedModal = jest.fn();
    const mockhandleRadioButon = jest.fn();
    render(
      <ESimUI
        isDualSimEntiLookupModalVisible
        handleRadioButon={mockhandleRadioButon}
        disableESIM
        handleClick={mockhandleClick}
        onCloseOfferAcceptedModal={mockonCloseOfferAcceptedModal}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(await screen.findByRole('button', { name: 'Cancel' }));
    expect(mockonCloseOfferAcceptedModal).toBeCalled();
    fireEvent.click(await screen.findByRole('button', { name: 'Continue' }));
    expect(mockhandleClick).toBeCalled();
    fireEvent.click(screen.getByText('A physical SIM card'));
  });
  it('should test ESimUI and disableESIM is false ', async () => {
    const mockhandleClick = jest.fn();
    const mockonCloseOfferAcceptedModal = jest.fn();
    const mockhandleRadioButon = jest.fn();
    render(
      <ESimUI
        isDualSimEntiLookupModalVisible
        handleRadioButon={mockhandleRadioButon}
        disableESIM={false}
        handleClick={mockhandleClick}
        onCloseOfferAcceptedModal={mockonCloseOfferAcceptedModal}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    fireEvent.click(await screen.findByRole('button', { name: 'Cancel' }));
    expect(mockonCloseOfferAcceptedModal).toBeCalled();
    fireEvent.click(await screen.findByRole('button', { name: 'Continue' }));
    expect(mockhandleClick).toBeCalled();
    fireEvent.click(screen.getByText('A physical SIM card'));
  });
});
