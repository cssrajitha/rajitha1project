import React from 'react';
import { Modal, ModalTitle, ModalFooter, ModalBody } from '@vds/modals';
import { Title, Body } from '@vds/typography';
import { Button } from '@vds/buttons';
import styled from 'styled-components';
import { isIpad } from 'onevzsoemfeframework/DomService';
const TextLinkWrapper = styled.div`
  padding: 1rem 0 0.5rem 0;
  display: flex;
  margin: 0 1rem 0 0;
  width: 50%;
`;

const ModalGroup = styled.div`
  display: flex;
`;

const ModalHeight = styled.div`
  min-height: 160px;
`;

function SwitchModal({ onClose, onContinue, data, title, isOpen }) {
  return (
    <Modal
      surface='light'
      onOpenedChange={(opened) => {
        if (!opened) onClose(false);
      }}
      hideCloseButton={false}
      disableAnimation={false}
      fullScreenDialog={isIpad()}
      disableOutsideClick={false}
      ariaLabel='Wifi Backup Switch Modal'
      opened={isOpen}
      width='500px'
    >
      <ModalHeight>
        <ModalTitle>
          <Title size='large' primitive='span' bold>
            {title}
          </Title>
        </ModalTitle>
        <ModalBody>
          <Body use='primary' size='large'>
            {data}
          </Body>
          <ModalGroup>
            <TextLinkWrapper>
              <Button
                primary
                size='large'
                onClick={() => {
                  onContinue();
                }}
                data-testid='ContinueButton-Switch'
                width={'100%'}
              >
                Continue
              </Button>
            </TextLinkWrapper>
            <TextLinkWrapper>
              <Button
                secondary
                size='large'
                onClick={() => onClose(false)}
                data-testid='CancelButton-Switch'
                width={'100%'}
              >
                Cancel
              </Button>
            </TextLinkWrapper>
          </ModalGroup>
        </ModalBody>
      </ModalHeight>
    </Modal>
  );
}

export default SwitchModal;
