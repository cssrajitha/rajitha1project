import React, { useState, useEffect, Fragment } from 'react';
import styled, { keyframes } from 'styled-components';
import { isIndirect } from 'onevzsoemfeframework/DomService';
import { Title, Body } from '@vds/typography';
import { Line } from '@vds/lines';
import { TileContainer } from '@vds/tiles';
import { Icon } from '@vds/icons';
import has from 'lodash/has';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import CompareDeviceTileEmpty from './CompareDeviceTileEmpty';
import { FlexBox, ShopWrapper } from './FlexGlobalStyledConstants';
import { getDpTermIndex, getPricingPriority } from '../../modules/utils/devicePricingUtils';
import { isVbg } from 'onevzsoemfeframework/VbgAemUtil';

const StyledPaddingTopBot32 = styled.div`
  padding: 2rem 0;
`;

const PaddingBot24 = styled.div`
  padding: 0 0 1.5rem 0;
`;

const PriceWrapperDPP = styled.div`
  display: flex;
  flex-direction: column;
  position: absolute;
  bottom: 1rem;
  gap: 2px;
`;
const PriceWrapperRetail = styled.div`
  display: flex;
  flex-direction: column;
  position: absolute;
  bottom: 1rem;
  left: 130px;
  gap: 2px;
`;
const IconWrapper = styled.div`
  position: absolute;
  top: 1rem;
  right: 1rem;
`;
const FadeIn = keyframes`
  0% { opacity: 0; }
  100% { opacity: 1; }
`;
const ImgWrapper = styled.div`
  display: flex;
  justify-content: center;
  margin-bottom: 1rem;
  animation: ${FadeIn} 400ms ease-in;
`; // margin-top: 2rem;

const ProductDisplayName = styled.p`
  font-size: 1rem;
  font-weight: 700;
  line-height: 1rem;
  font-family: Verizon-NHG-eDS, Helvetica, Arial, Sans-serif;
  -webkit-letter-spacing: 0.03125rem;
  -moz-letter-spacing: 0.03125rem;
  -ms-letter-spacing: 0.03125rem;
  letter-spacing: 0.03125rem;
  color: #000000;
  margin: 0;
  -webkit-text-decoration: none;
  text-decoration: none;
`;

export const FlexAlignContainerItemsCenter = styled.div`
  display: flex;
  align-items: center;
  padding: 0px 1rem;
  justify-content: space-between;
  position: fixed;
  width: 97%;
  height: 5rem;
  background-color: white;
  top: 0;
`;
const TileSectionWrapper = styled.div`
  position: fixed;
  background-color: white;
  width: 97%;
  margin: 4rem 1.25rem 0px;
`;
const LineWrapper = styled.div`
  padding-top: 0.75rem;
  padding-bottom: 0.1rem;
`;
const TileWrapperr = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  padding-top: 420px;
  margin: 0px 1.25rem;
  background-color: #ffffff;
`;

const RowWrapper = styled.div`
  display: flex;
  flex-direction: row;
  gap: 3rem;
`;
const BodyWrapper = styled.div`
  width: 13rem;
`;
const TileWrapper2nd = styled.div`
  display: flex;
  flex-direction: row;
  gap: 0.5rem;
`;

const TileWrappers5th = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
`;
const Img = styled.img`
  margin-right: 0px;
  width: 93px;
  height: 110px;
`;

const tableList = [
  { id: 1, header: 'Usage time - Up to', key: 'Usage Time' },
  { id: 2, header: 'Front Camera', key: 'Front Camera' },
  { id: 3, header: 'Rear Camera', key: 'Rear Camera' },
  { id: 4, header: 'Screen', key: 'Screen' },
  { id: 5, header: 'Operating system', key: 'Operating System' },
  { id: 6, header: 'Storage', key: 'Storage' },
  { id: 7, header: 'Colors', key: 'Colors' },
  { id: 8, header: 'SAR', key: 'SAR' },
  { id: 9, header: 'Hearing aid compatibility', key: 'Auditory' },
  { id: 10, header: '5G Nationwide', key: '5G Nationwide' },
  { id: 11, header: 'Weight', key: 'Weight' },
  { id: 12, header: 'Width', key: 'Width' },
  { id: 13, header: 'Height', key: 'Height' },
  { id: 14, header: 'Battery', key: 'Battery' },
];

const getDppAndTerm = (priceObj, devicePaymentPrice) => {
  let preferredTerm = '';
  let dpp = null;
  if(devicePaymentPrice?.length > 0) {
    if(isVbg()) {
      dpp = devicePaymentPrice?.[getDpTermIndex(priceObj)];
      preferredTerm = dpp?.dpTermPrices?.dpTerm || '';
    } else {
      preferredTerm = priceObj?.preferredTerm || '';
      dpp = devicePaymentPrice?.find(dpp1 => dpp1.contractDuration === preferredTerm);
    }
  }
  return { dpp, preferredTerm };
};

const getPriceDisplay = (product) => {
  let contractPrice = '';
  let contractText = '';
  const priceObj = product?.childSkus[0]?.price;
  const devicePaymentPrice = priceObj?.devicePaymentPrice || [];
  const { dpp, preferredTerm } = getDppAndTerm(priceObj, devicePaymentPrice);
  const dpFirstMonthPrice = dpp?.dpTermPrices?.remainingMonthPrice ? dpp.dpTermPrices.remainingMonthPrice : '';
  if(isVbg() && !dpFirstMonthPrice) {
    const pricingPriority = getPricingPriority(priceObj);
    if (
      pricingPriority &&
      priceObj?.[pricingPriority]?.originalPrice
    ) {
      contractPrice = `$${priceObj?.[pricingPriority]?.originalPrice}`;
      contractText = priceObj?.[pricingPriority]?.contractText || '';
    }
  }
  return { contractPrice, contractText, dpFirstMonthPrice, preferredTerm, priceObj };
};

function CompareGridwallDevices(props) {
  const { showCompareData } = props;

  const [filterNull, setFilterNull] = useState();
  const [bestBuyIntegrationFFlag, flexRedesignFFlag, gridwallAccessibleFFlag] = getAssistedCradlePropertyV2([
    'bestBuyIntegrationFFlag',
    'flexRedesignFFlag',
    'gridwallAccessibleFFlag',
  ]);
  const hidePriceDetails = /true/i.test(flexRedesignFFlag) && isIndirect();

  useEffect(() => {
    const filterNullData =
      showCompareData?.compareList?.length > 0 && showCompareData.compareList.filter((product) => product !== null);
    setFilterNull(filterNullData);
  }, [showCompareData]);

  return (
    <>
      <FlexAlignContainerItemsCenter data-testid='compareGridwallDevices'>
        <FlexBox>
          <ShopWrapper>
            <Title size='small' bold primitive='h1'>
              Compare devices
            </Title>
          </ShopWrapper>
        </FlexBox>
        <FlexBox>
          <IconWrapper onClick={props.hideCompareDevicesModal}>
            <Icon name='close' size='large' />
          </IconWrapper>
        </FlexBox>
      </FlexAlignContainerItemsCenter>

      <TileSectionWrapper>
        <TileWrapper2nd>
          {filterNull?.length > 0 &&
            filterNull?.map((product) => {
              const { contractPrice, contractText, dpFirstMonthPrice, preferredTerm, priceObj } = getPriceDisplay(product);
              return (
                <TileContainer
                  key={`child${product?.productId}`}
                  padding='1rem'
                  height={props?.scrolled ? '150px' : '318px'}
                  width='240px'
                >
                  <TileWrappers5th>
                    <IconWrapper>
                      <span
                        data-testid='removebutton_compare'
                        tabIndex={0}
                        role='button'
                        onKeyDown={{}}
                        onClick={() => props?.handleRemoveProductFromCompare(product?.productId)}
                      >
                        <Icon name='close' size='large' />
                      </span>
                    </IconWrapper>
                    {!props?.scrolled && (
                      <ImgWrapper>
                        <Img
                          src={product?.childSkus[0]?.imageUrlMap?.defaultImage}
                          tabIndex={gridwallAccessibleFFlag === 'TRUE' ? '0' : ''}
                          aria-label={
                            gridwallAccessibleFFlag === 'TRUE'
                              ? `${`${product?.brandName} ${product?.productDisplayName}`}`
                              : ''
                          }
                          role={gridwallAccessibleFFlag === 'TRUE' ? 'button' : ''}
                          alt='deviceslogo'
                        />
                      </ImgWrapper>
                    )}
                    <span
                      role={gridwallAccessibleFFlag === 'TRUE' ? 'heading' : ''}
                      aria-level={gridwallAccessibleFFlag === 'TRUE' ? '3' : ''}
                      aria-label={
                        gridwallAccessibleFFlag === 'TRUE'
                          ? `${`${product?.brandName} ${product?.productDisplayName}`}`
                          : ''
                      }
                    >
                      <Body size='large' bold>
                        {product?.brandName}
                      </Body>
                      <ProductDisplayName size='large' bold>
                        {product?.productDisplayName}
                      </ProductDisplayName>
                    </span>
                  </TileWrappers5th>
                  {!(
                    props.cartDetails?.cart?.cartHeader?.locationSubType === 'GN' &&
                    props.cartDetails?.cart?.cartHeader?.maid === 'BBX' &&
                    bestBuyIntegrationFFlag === 'TRUE'
                  ) &&
                    !hidePriceDetails && (
                      <>
                        <PriceWrapperDPP>
                          <Body size='large' bold>
                            {dpFirstMonthPrice ? `$${dpFirstMonthPrice}/mo` : contractPrice}
                          </Body>
                          <Body size='small'>{dpFirstMonthPrice ? `for ${preferredTerm} months` : contractText}</Body>
                        </PriceWrapperDPP>

                        <PriceWrapperRetail>
                          <Body size='large' bold>
                            $
                            {has(product, 'childSkus[0].price.fullRetailPrice.originalPrice')
                              ? priceObj?.fullRetailPrice?.originalPrice
                              : ''}
                          </Body>
                          <Body size='small'>Retail Price</Body>
                        </PriceWrapperRetail>
                      </>
                    )}
                </TileContainer>
              );
            })}
          {filterNull?.length > 3 ? (
            ''
          ) : (
            <CompareDeviceTileEmpty
              scrolled={props?.scrolled}
              hideCompareDevicesModal={props?.hideCompareDevicesModal}
            />
          )}
        </TileWrapper2nd>

        <LineWrapper>
          <Line surface='light' />
        </LineWrapper>
      </TileSectionWrapper>

      <TileWrapperr>
        {tableList?.map((item) => (
          <Fragment>
            <PaddingBot24>
              <Title key={`key-${item?.header}`} size='small'>
                {item?.header}
              </Title>
            </PaddingBot24>

            <RowWrapper>
              {filterNull?.map((product) => {
                if (product !== null && product !== undefined) {
                  if (product?.techSpecs && product?.techSpecs[item.key]) {
                    return (
                      <BodyWrapper key={product?.productId}>
                        <Body size='medium'>{product?.techSpecs[item.key]}</Body>
                      </BodyWrapper>
                    );
                  }
                  return (
                    <BodyWrapper key={product?.productId}>
                      <Body size='medium'>-</Body>
                    </BodyWrapper>
                  );
                }
                return null;
              })}
            </RowWrapper>

            <StyledPaddingTopBot32>
              <Line type='secondary' surface='light' />
            </StyledPaddingTopBot32>
          </Fragment>
        ))}
      </TileWrapperr>
    </>
  );
}
export default CompareGridwallDevices;
