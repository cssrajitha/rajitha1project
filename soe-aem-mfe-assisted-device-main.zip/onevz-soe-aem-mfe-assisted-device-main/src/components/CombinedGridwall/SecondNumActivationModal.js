import React from 'react';
import { Modal, ModalBody, ModalTitle, ModalFooter } from '@vds/modals';
import PropTypes from 'prop-types';
import { secondNumberActivationHeaderText, secondNumberActivationSubText } from '../constants/DeviceConstants';

function SecondNumActivationModal(props) {
  const { showSecondNumberActivationModal, setShowSecondNumberActivationModal } = props;
  const closeModal = (opened) => {
    if (!opened) {
      setShowSecondNumberActivationModal(false);
    }
  }
  return (
    <Modal
      surface='light'
      opened={showSecondNumberActivationModal}
      fullScreenDialog={false}
      disableAnimation
      disableOutsideClick
      onOpenedChange={closeModal}
      showCloseButton
      ariaLabel='SecondNumActivationModal'
    >
      <ModalTitle>{secondNumberActivationHeaderText}</ModalTitle>
      <ModalBody>
        {secondNumberActivationSubText}
      </ModalBody>
      <ModalFooter
        buttonData={{
          primary: {
            width: '100%',
            children: 'Done',
            onClick: () => setShowSecondNumberActivationModal(false),
          },
        }}
      />
    </Modal>
  );
}

SecondNumActivationModal.propTypes = {
  showSecondNumberActivationModal: PropTypes.bool,
  setShowSecondNumberActivationModal: PropTypes.func,
};

export default SecondNumActivationModal;
