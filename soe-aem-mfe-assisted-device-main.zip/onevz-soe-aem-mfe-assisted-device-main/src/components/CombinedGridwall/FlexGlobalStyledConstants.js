import styled from 'styled-components';

export const FlexBox = styled.div`
  display: flex;
`;
export const StyledPaddingLeft8 = styled.div`
  padding-left: 0.5rem;
`;
export const PaddingBottom8 = styled.div`
  padding-bottom: 0.5rem;
`;
export const FlexContainerAlignItemsCenter = styled.div`
  display: flex;
  align-items: center !important;
  padding: 0 2rem 0 1rem;
  justify-content: space-between;
`;
export const BackClickable = styled.a`
  cursor: pointer;
  color: #000000 !important;
  align-items: center;
  padding: 1.5rem 1.5rem 1.5rem 0;
`;
export const HeaderBackClickable = styled.a`
  display: flex;
  cursor: pointer;
  color: #000000 !important;
  align-items: center;
  padding: 1.5rem 1.5rem 1.5rem 0;
`;

export const PaddingY24 = styled.div`
  padding: 1.5rem 0 1.5rem 0;
`;
export const Padding24 = styled.div`
  padding: 1.5rem;
`;
export const PaddingLeft24 = styled.div`
  padding: 0 0 0 1.5rem;
`;
export const PaddingRight32 = styled.div`
  padding: 0 2rem 0 0;
`;
export const PaddingRight12 = styled.div`
  padding: 0 0.75rem 0 0;
`;
export const StyledPaddingRight8 = styled.div`
  padding-right: 0.5rem;
`;
export const PaddingBottom16 = styled.div`
  padding: 0 0 1rem 0;
`;
export const FlexAlignCenter = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
`;
export const FlexBaseLine = styled.div`
  display: flex;
  align-items: baseline;
`;
export const FlexJustify = styled.div`
  display: flex;
  justify-content: space-between;
`;
export const Padding12 = styled.div`
  padding: 0.75rem 0 0.75rem 0;
`;
export const PaddingTop4 = styled.div`
  padding-top: 0.25rem;
`;
export const PaddingBottom2 = styled.div`
  padding-bottom: 0.125rem;
`;
export const PaddingTop12 = styled.div`
  padding: 0.75rem 0 0 0;
`;
export const PaddingBottom12 = styled.div`
  padding: 0 0 0.75rem 0;
`;
export const Padding8 = styled.div`
  padding: 0.5rem 0 0.5rem 0;
`;
export const PaddingTop2 = styled.div`
  padding-top: 0.125rem;
`;
export const FlexBoxContainer = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;
export const MaxWidth72 = styled.div`
  max-width: 72px;
`;
export const PaddingTopBottom16 = styled.div`
  padding-top: 1rem;
  padding-bottom: 1rem;
`;
export const PaddingTop16 = styled.div`
  padding-top: 1rem;
`;
export const PaddingLeft4 = styled.span`
  padding-left: 0.25rem;
`;
export const PaddingLeftRight4 = styled.div`
  padding: 0 0.25rem 0 0.25rem;
`;
export const FlexAlignCenterBox = styled.div`
  display: flex;
  align-items: center;
`;
export const PaddingLeft12 = styled.div`
  padding: 0 0 0 0.75rem;
`;

export const FlexBoxColumn = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
`;
export const Padding36 = styled.div`
  padding: 1.5rem 2rem;
`;
export const TileWrapper = styled.div`
  flex: 0 1 calc(33.33% - 1em);
  position: relative;
  > div:first-child {
    transition: all 0.2s ease 0s;
    &:hover {
      transform: scale(1.02) translate(0px, 0px) perspective(1px);
      cursor: pointer;
    }
  }
`;
// For future ref.
// export const TileWrapper = styled.div`
//   @media only screen and (min-width: 1401px) {
//     flex: 0 1 calc(20% - 1em);
//   }
//   @media only screen and (min-width: 1201px) and (max-width: 1400px) {
//     flex: 0 1 calc(25% - 1em);
//   }
//   @media only screen and (max-width: 1200px) {
//     flex: 0 1 calc(33.33% - 1em);
//   }
// `;
export const ImgWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 116px;
  margin-top: 2.125rem;
  margin-bottom: 1rem;
`;
export const Padding16 = styled.div`
  padding: 1rem 0 1rem 0;
`;
export const PaddingRight16 = styled.div`
  padding-right: 1rem;
`;
export const Padding70 = styled.div`
  padding: 0 4.375rem 0 4.375rem;
`;
export const Padding32 = styled.div`
  padding: 0 2rem 0 2rem;
`;
export const PaddingAll = styled.div`
  padding: 2rem;
`;
export const PaddingTop6 = styled.div`
  padding: 0.375rem 0 0 0;
`;
export const PaddingTop8 = styled.div`
  padding: 0.5rem 0 0 0;
`;
export const StyledBorder = styled.div`
  flex: 1;
`;
export const PaddingTop20 = styled.div`
  padding-top: 1.25rem;
`;
export const PaddingTop24 = styled.div`
  padding-top: 1.5rem;
`;
export const StyledPaddingTop32 = styled.div`
  padding: 2rem 0 0 0;
`;
export const StyledPaddingBot32 = styled.div`
  padding-bottom: 2rem;
`;
export const StyledPaddingTopBot32 = styled.div`
  padding: 2rem 0;
`;
export const StyledPaddingTop20Bot16 = styled.div`
  padding: 1.25rem 0 1rem;
`;
export const StyledPaddingTop8Bot8 = styled.div`
  padding: 0.5rem 0 0.5rem;
`;
export const StyledPaddingTop8Bot16 = styled.div`
  padding: 0.5rem 0 1rem;
`;
export const PaddingBot24 = styled.div`
  padding: 0 0 1.5rem 0;
`;
export const StyledFlexContainer = styled.div`
  display: flex;
  flex-direction: row;
  align-items: flex-end;
`;
export const PaddingLeft16 = styled.div`
  padding-left: 1rem;
`;
export const TileIconWrapper = styled.div`
  position: absolute;
  right: 1rem;
  top: 1rem;
`;

export const ShopWrapper = styled.div`
  padding: 1.5rem 0.5rem;
`;
export const StyledTextRight = styled.div`
  text-align: right;
`;
export const IconWrapper = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  cursor: pointer;
  padding-right: 2rem;
`;

export const Padding48 = styled.div`
  padding: 0 3rem 0 3rem;
`;
export const Padding4 = styled.div`
  padding: 0.25rem 0 0.25rem 0;
`;
export const TrashWrapper = styled.span`
  cursor: pointer;
  width: 3rem;
  height: 1.5rem;
  display: flex;
  align-items: center;
  position: absolute;
  bottom: 1rem;
`;
export const MarginRight4 = styled.div`
  margin-right: 0.25rem;
`;

export const StyledHeaderWithClose = styled.div`
  @media (min-width: 1272px) {
    font-size-adjust: 1.25rem;
  }
  width: 100%;
  margin-left: 0;
  margin-right: 0;
  border-bottom: 1px solid #d8dada;
  background: white;
`;
export const HeadFlexContainerAlignItemsCenter = styled.div`
  display: flex;
  align-items: center !important;
  padding-right: 36px;
  padding-left: 36px;
`;
export const LinkPointer = styled.a`
  cursor: pointer !important;
  text-decoration: none;
  color: #000000;
  &:focus {
    outline: 1px dotted #000000 !important;
  }
`;
export const BlackClickable = styled.a`
  cursor: pointer;
  color: #000000 !important;
`;

export const PaddingTopBot32 = styled.div`
  padding: 2rem 0 2rem 0;
`;
export const PaddingTopBot48 = styled.div`
  padding: 3rem 0 3rem 0;
`;
export const PaddingTop28 = styled.div`
  padding: 1.75rem 0 0 0;
`;

export const OverflowEllipsis = styled.div`
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: ${(props) => props.lineCount};
  line-clamp: ${(props) => props.lineCount};
  -webkit-box-orient: vertical;
`;

export const RemoveLineModalDiv = styled.div`
  z-index: 1000;
  position: fixed;
  width: 100%;
  height: 100%;
  left: 0;
  right: 0;
  bottom: 0;
  margin: auto;
  overflow-y: auto;
  background-color: #ffffff;
  .removeLine-modal-inner {
    width: 64rem;
    top: 0%;
    min-height: 100%;
    bottom: auto;
    margin: 0 auto;
    right: 0%;
    background: #ffffff;
  }

  .removeLine-modal-inner .bodyPart {
    margin: 90px;
  }
  .removeLine-modal-inner .bodyPart .bodyPartInner {
    padding-top: 50px;
  }

  .removeLineMessage {
    font-size: 30px !important;
  }

  .removeLine-modal-inner .buttonPart {
    margin-left: 90px;
    margin-top: 60px;
  }

  .buttonPart .p-button.p-button-text-only .p-button-text {
    padding: 1rem 3.7rem;
  }

  .line-height-35 {
    line-height: 35px;
  }

  .button-secondary {
    color: #000000 !important;
    background-color: #ffffff !important;
    border-color: #000000;
    font-weight: 400 !important;
  }

  .button-primary {
    color: #ffffff !important;
    background-color: #000000 !important;
    border-color: #000000 !important ;
    font-weight: 400 !important;
  }
`;

export const SelfProfInstallWrapper = styled.div`
  width: 100%;
  height: 34px;
  position: absolute;
  top: 0;
  left: 0;
  text-align: center;
  padding-top: 0.5rem;
  background-image: ${(props) =>
    props.professional ? 'linear-gradient(to right, #e3f2fd 100%)' : 'linear-gradient(to right, #dcf5e6 100%)'};
`;
