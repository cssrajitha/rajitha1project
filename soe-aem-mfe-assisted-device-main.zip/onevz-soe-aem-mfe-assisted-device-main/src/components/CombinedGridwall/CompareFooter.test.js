import React from 'react';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import { fireEvent, render, screen, act, waitFor } from '../../modules/test-utils/renderHelper';
import CompareFooter from './CompareFooter';

// Mock the AssistedCradleService
jest.mock('onevzsoemfeframework/AssistedCradleService', () => ({
  getAssistedCradlePropertyV2: jest.fn(),
}));

// Global setup to ensure mock always returns a value
beforeEach(() => {
  // Set default mock return value if not already set
  if (!getAssistedCradlePropertyV2.mock.calls.length || getAssistedCradlePropertyV2.mockReturnValue() === undefined) {
    getAssistedCradlePropertyV2.mockReturnValue(['FALSE']);
  }
});
describe('Compare footer component render', () => {
  const initialState = {
    closeCompareDevicesoptions: jest.fn(),
    handleRemoveProductFromFooter: jest.fn(),
    compareDevices: jest.fn(),
    devicestocompare: [
      {
        mgSrc: '',
        productDisplayName: 'sdfdsf',
        brandName: 'fdsfsd',
        productId: 123,
      },
      {
        imgSrc: '',
        productDisplayName: 'mnbvcx',
        brandName: 'mnbvcx',
        productId: 456,
      },
      {
        imgSrc: '',
        productDisplayName: 'sdfdsf',
        brandName: 'fdsfsd',
        productId: 123,
      },
    ],
    devicestocompare1: [
      {
        imgSrc: '',
        productDisplayName: 'sdfdsf',
        brandName: 'fdsfsd',
        productId: 123,
      },
    ],
    devicestocompare2: [
      {
        imgSrc: '',
        productDisplayName: 'sdfdsf',
        brandName: 'fdsfsd',
        productId: 123,
      },
      {
        imgSrc: '',
        // productDisplayName:"device image",
        brandName: 'lkjhgf',
        productId: 546,
      },
    ],
  };

  beforeEach(() => {
    Object.defineProperty(window, 'location', {
      value: new URL('http://example.com/sales/assisted/new/device/gridwall.html'),
      configurable: true,
    });
    render(<CompareFooter {...initialState} />, { reducers: rootReducer, sagas: rootSaga });
  });

  test('renders compareDevices', async () => {
    const dataTest = await waitFor(() => screen.getByTestId('compareDevices'));
    act(() => {
      fireEvent.click(dataTest);
    });
  });

  test('renders closeCompareDevicesoptions', async () => {
    const dataTest = await waitFor(() => screen.getByTestId('closeButton'));
    act(() => {
      fireEvent.click(dataTest);
    });
  });
});

describe('Compare footer component render devices to compare length 1', () => {
  const initialState = {
    closeCompareDevicesoptions: jest.fn(),
    handleRemoveProductFromFooter: jest.fn(),
    compareDevices: jest.fn(),
    devicestocompare: [
      {
        imgSrc: '',
        productDisplayName: 'sdfdsf',
        brandName: 'fdsfsd',
        productId: 123,
      },
    ],
  };

  beforeEach(() => {
    Object.defineProperty(window, 'location', {
      value: new URL('http://example.com/sales/assisted/new/device/gridwall.html'),
      configurable: true,
    });
    render(<CompareFooter {...initialState} />, { reducers: rootReducer, sagas: rootSaga });
  });

  test('renders compareDevices', async () => {
    const dataTest = await waitFor(() => screen.getByTestId('compareDevices'));
    act(() => {
      fireEvent.click(dataTest);
    });
  });

  test('renders closeCompareDevicesoptions', async () => {
    const dataTest = await waitFor(() => screen.getByTestId('closeButton'));
    act(() => {
      fireEvent.click(dataTest);
    });
  });
});

describe('Compare footer component render devices to compare length 2', () => {
  const initialState = {
    closeCompareDevicesoptions: jest.fn(),
    handleRemoveProductFromFooter: jest.fn(),
    compareDevices: jest.fn(),
    devicestocompare: [
      {
        imgSrc: '',
        productDisplayName: 'sdfdsf',
        brandName: 'fdsfsd',
        productId: 123,
      },
      {
        imgSrc: '',
        // productDisplayName:"device image",
        brandName: 'lkjhgf',
        productId: 546,
      },
    ],
  };

  beforeEach(() => {
    Object.defineProperty(window, 'location', {
      value: new URL('http://example.com/sales/assisted/new/device/gridwall.html'),
      configurable: true,
    });
    render(<CompareFooter {...initialState} />, { reducers: rootReducer, sagas: rootSaga });
  });

  test('renders compareDevices', async () => {
    const dataTest = await waitFor(() => screen.getByTestId('compareDevices'));
    act(() => {
      fireEvent.click(dataTest);
    });
  });

  test('renders closeCompareDevicesoptions', async () => {
    const dataTest = await waitFor(() => screen.getByTestId('closeButton'));
    act(() => {
      fireEvent.click(dataTest);
    });
  });

  test('renders removebutton', async () => {
    const dataTest = await waitFor(() => screen.getAllByTestId('removebutton'));
    act(() => {
      fireEvent.click(dataTest[0]);
    });
  });
});

describe('CompareFooter - Feature Flag optmzCompareFooterFFlag Tests', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('optmzCompareFooterFFlag is TRUE - Optimized Empty Tiles Rendering', () => {
    beforeEach(() => {
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE']);
      Object.defineProperty(window, 'location', {
        value: new URL('http://example.com/sales/assisted/new/device/gridwall.html'),
        configurable: true,
      });
    });

    test('should render optimized empty tiles when flag is TRUE with 3 device', async () => {
      const initialState = {
        closeCompareDevicesoptions: jest.fn(),
        handleRemoveProductFromFooter: jest.fn(),
        compareDevices: jest.fn(),
        devicestocompare: [
          {
            imgSrc: 'device1.jpg',
            productDisplayName: 'iPhone 14',
            brandName: 'Apple',
            productId: 123,
          },
          {
            imgSrc: 'device2.jpg',
            productDisplayName: 'iPhone 15',
            brandName: 'Apple',
            productId: 456,
          },
          {
            imgSrc: 'device3.jpg',
            productDisplayName: 'iPhone 16',
            brandName: 'Apple',
            productId: 789,
          },
        ],
      };

      render(<CompareFooter {...initialState} />, { reducers: rootReducer, sagas: rootSaga });

      await waitFor(() => {
        const emptyTiles = screen.getAllByText('Add device');
        expect(emptyTiles).toHaveLength(1);
      });
    });

    test('should render 4 empty tiles when flag is TRUE with empty devices array', async () => {
      const initialState = {
        closeCompareDevicesoptions: jest.fn(),
        handleRemoveProductFromFooter: jest.fn(),
        compareDevices: jest.fn(),
        devicestocompare: [],
      };

      render(<CompareFooter {...initialState} />, { reducers: rootReducer, sagas: rootSaga });

      await waitFor(() => {
        const emptyTiles = screen.getAllByText('Add device');
        expect(emptyTiles).toHaveLength(4);
      });
    });

    test('should render 4 empty tiles when flag is TRUE with null devices', async () => {
      const initialState = {
        closeCompareDevicesoptions: jest.fn(),
        handleRemoveProductFromFooter: jest.fn(),
        compareDevices: jest.fn(),
        devicestocompare: null,
      };

      render(<CompareFooter {...initialState} />, { reducers: rootReducer, sagas: rootSaga });

      await waitFor(() => {
        const emptyTiles = screen.getAllByText('Add device');
        expect(emptyTiles).toHaveLength(4);
      });
    });
  });
});
