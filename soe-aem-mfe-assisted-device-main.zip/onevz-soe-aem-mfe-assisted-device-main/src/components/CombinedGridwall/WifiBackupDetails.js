import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { Title, Body } from '@vds/typography';
import { Button } from '@vds/buttons';
import styled from 'styled-components';
import { Icon } from '@vds/icons';
import * as types from '../constants/DeviceConstants';

const TextLinkWrapper = styled.div`
  padding: 1rem 0 0.5rem 0;
  display: flex;
  margin: 0 0 20px 20px;
`;

const AdvisoryText = styled.p`
  font-size: 14px;
  color: #000;
  font-weight: 700;
  margin: 0;
  line-height: 40px;
  background-color: #e0f7fa;
  padding: 10px 20px;
  border-bottom: 1px solid #e0e0e0;
  border-radius: 4px;
  display: flex;
  align-items: center;
  justify-content: left;
`;
const TitleWrapper = styled.div`
  flex: 1;
  text-align: left;
  margin: 20px;
`;
const TitleText = styled.div`
  font-size: 2.25rem;
  line-height: 1.25rem;
  font-family: Verizon-NHG-eDS, Helvetica, Ariel, sans-serif;
  color: rgb(0, 0, 0);
  margin: 0px;
  text-decoration: none;
`;

const PriceTextPrimary = styled.span`
  font-size: 36px;
  color: rgb(0, 0, 0);
  text-align: right;
  flex-shrink: 0;
  margin-left: 20px;
  line-height: 12px;
`;

const BodyContainer = styled.div`
  display: flex;
  justify-content: space-between;
  gap: 20px;
  margin: 0 20px 0 20px;
`;
const Column = styled.div`
  flex: 1;
  padding-right: 10px;
`;
const ColumnHeading = styled.h3`
  font-size: 16px;
  font-weight: bold;
  margin-bottom: 10px;
`;
const ColumnContent = styled.p`
  font-size: 14px;
  color: #222;
  margin-bottom: 8px;
`;
const ColumnContent1 = styled.p`
  font-size: 14px;
  color: #999;
`;
const WifiWrapper = styled.div`
  width: 80%;
  max-width: 1133px;
  z-index: 8;
  background-color: white;
  height: 100vh;
  position: fixed;
  top: 0;
  left: 10%;
  right: 10%;
  overflow: auto;
`;

const WifiNavigation = styled.div`
  display: flex;
  -webkit-box-align: center;
  align-items: center;
  -webkit-box-pack: justify;
  justify-content: space-between;
  padding: 0.5rem 1.25rem;
  height: 60px;
`;

const NavigationBorder = styled.div`
  height: 0.0625rem;
  width: 100%;
  background-color: rgb(216, 218, 218);
`;

const Seperator = styled.div`
  height: 1px;
  width: 100%;
  background-color: #000;
  margin: 20px;
`;
const ExitWrapper = styled.div`
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 0.75rem;
`;
const ExitContainer = styled.div`
  padding-top: 0.25rem;
`;
const SubTitle = styled.div`
  display: flex;
  -webkit-box-pack: justify;
  justify-content: space-between;
  margin: 20px;
`;
const MainContent = styled.div`
  padding: 20px;
  margin-bottom: 20%;
`;
const IconStyle = styled.span`
  margin-right: 8px;
`;
function WiFiBackupDetails({ onSelect, onClose, isOpen }) {
  if (!isOpen) {
    return;
  }
  return (
    <WifiWrapper>
      <WifiNavigation>
        <ExitWrapper data-testid='wifi-back-close' onClick={onClose} role='button' aria-label='back'>
          <ExitContainer className='exitIconFlex'>
            <Icon name='left-caret' size='small' color='#000000' weight='medium' />
          </ExitContainer>
          <Body size='large' bold>
            <div>Back</div>
          </Body>
        </ExitWrapper>
      </WifiNavigation>
      <NavigationBorder />
      <MainContent>
        <TitleWrapper>
          <TitleText>{types?.WIFI_BACKUP_DETAILS?.title}</TitleText>
        </TitleWrapper>
        <div style={{ margin: '0 20px' }}>
          <AdvisoryText>
            <IconStyle>
              <Icon name='info' />
            </IconStyle>{' '}
            {types?.WIFI_BACKUP_DETAILS?.subtitle}
          </AdvisoryText>
        </div>
        <SubTitle>
          {types?.WIFI_BACKUP_DETAILS?.advisory}
          <div>
            <PriceTextPrimary>{types?.WIFI_BACKUP_DETAILS?.monthlyPrice}</PriceTextPrimary>
          </div>
        </SubTitle>
        <Seperator />
        <BodyContainer>
          <Column>
            <ColumnHeading>{types?.WIFI_BACKUP_DETAILS?.data1?.heading}</ColumnHeading>
            <ColumnContent>{types?.WIFI_BACKUP_DETAILS?.data1?.content}</ColumnContent>
          </Column>
          <Column>
            <ColumnHeading>{types?.WIFI_BACKUP_DETAILS?.data2?.heading}</ColumnHeading>
            <ColumnContent>{types?.WIFI_BACKUP_DETAILS?.data2?.content}</ColumnContent>
          </Column>
          <Column>
            <ColumnHeading>{types?.WIFI_BACKUP_DETAILS?.data3?.heading}</ColumnHeading>
            <ColumnContent>{types?.WIFI_BACKUP_DETAILS?.data3?.content}</ColumnContent>
          </Column>
        </BodyContainer>
        <TextLinkWrapper>
          <Button primary size='large' onClick={onSelect} data-testid='ContinueButton-WiFi'>
            Select
          </Button>
        </TextLinkWrapper>
      </MainContent>
    </WifiWrapper>
  );
}

WiFiBackupDetails.propTypes = {
  isOpen: PropTypes.bool,
  onClose: PropTypes.func,
  onSelect: PropTypes.func,
};

export default WiFiBackupDetails;
