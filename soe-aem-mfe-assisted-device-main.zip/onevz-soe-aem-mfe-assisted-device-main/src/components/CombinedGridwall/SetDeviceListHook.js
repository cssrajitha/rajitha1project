import {useEffect} from 'react';
import { isEmpty } from 'lodash';

const SetDeviceListHook = ({ SkuListResult, setDeviceList }) => {
  useEffect(() => {
    if (!isEmpty(SkuListResult?.data?.data?.productList)) {
      const skuListData = SkuListResult?.data?.data;
      console.log({skuListData})
      const deviceSkuList = skuListData?.productList ? skuListData.productList : [];
      console.log({deviceSkuList})
      const parentProducts = deviceSkuList && deviceSkuList.length > 1 ? deviceSkuList : [];
      console.log({parentProducts})
      setDeviceList(parentProducts);
      sessionStorage.setItem('scrollY', 0);
    }
  }, [SkuListResult]);

  return null;
};

export default SetDeviceListHook;
