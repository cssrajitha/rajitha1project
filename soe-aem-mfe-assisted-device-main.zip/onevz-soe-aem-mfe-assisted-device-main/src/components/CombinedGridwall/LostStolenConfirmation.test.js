import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { Provider } from 'react-redux';
import { configureStore } from '@reduxjs/toolkit';
import '@testing-library/jest-dom';
import LostStolenConfirmation from './LostStolenConfirmation';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import * as appLoaderActions from 'onevzsoemfecommon/AppLoaderActions';
import { useLazyAllowDeviceIdToReuseQuery } from '../../modules/services/APIService/APIServiceHooks';
import { sendCustomEvent } from 'onevzsoemfeframework/Tagging';

// Mock the external dependencies
jest.mock('onevzsoemfecommon/ConfirmationDialogBox', () => ({
  ConfirmationDialogBox: ({
    message,
    btnYesText,
    btnNoText,
    isNoBtnDisabled,
    isYesBtnDisabled,
    handleConfirmationDialogBoxClick,
  }) => (
    <div data-testid='confirmation-dialog'>
      <div data-testid='dialog-message'>{message}</div>
      <button
        data-testid='yes-button'
        disabled={isYesBtnDisabled}
        onClick={() => handleConfirmationDialogBoxClick('yes')}
      >
        {btnYesText}
      </button>
      <button data-testid='no-button' disabled={isNoBtnDisabled} onClick={() => handleConfirmationDialogBoxClick('no')}>
        {btnNoText}
      </button>
    </div>
  ),
}));

jest.mock('onevzsoemfecommon/AppMessageActions', () => ({
  addAppMessage: jest.fn(),
}));

jest.mock('onevzsoemfecommon/AppLoaderActions', () => ({
  show: jest.fn(),
  hide: jest.fn(),
}));

jest.mock('../../modules/services/APIService/APIServiceHooks', () => ({
  useLazyAllowDeviceIdToReuseQuery: jest.fn(),
}));

jest.mock('onevzsoemfeframework/Tagging', () => ({
  sendCustomEvent: jest.fn(),
}));

// Create a mock store
const createMockStore = () => {
  return configureStore({
    reducer: {
      test: (state = {}) => state,
    },
  });
};

describe('LostStolenConfirmation Component', () => {
  let mockStore;
  let mockDispatch;
  let mockAllowDeviceIdToReuse;
  let mockOnSuccess;
  let mockOnCancel;

  const defaultProps = {
    isVisible: true,
    onSuccess: jest.fn(),
    onCancel: jest.fn(),
    deviceId: 'TEST12345',
  };

  beforeEach(() => {
    // Reset all mocks
    jest.clearAllMocks();

    mockStore = createMockStore();
    mockDispatch = jest.fn();
    mockAllowDeviceIdToReuse = jest.fn();
    mockOnSuccess = jest.fn();
    mockOnCancel = jest.fn();

    // Mock the Redux store dispatch
    jest.spyOn(mockStore, 'dispatch').mockImplementation(mockDispatch);

    // Mock the API hook
    useLazyAllowDeviceIdToReuseQuery.mockReturnValue([mockAllowDeviceIdToReuse]);

    // Mock the action creators
    appMessageActions.addAppMessage.mockReturnValue({ type: 'ADD_APP_MESSAGE' });
    appLoaderActions.show.mockReturnValue({ type: 'SHOW_LOADER' });
    appLoaderActions.hide.mockReturnValue({ type: 'HIDE_LOADER' });
  });

  const renderComponent = (props = {}) => {
    const mergedProps = { ...defaultProps, ...props };
    return render(
      <Provider store={mockStore}>
        <LostStolenConfirmation {...mergedProps} />
      </Provider>
    );
  };

  describe('Component Rendering', () => {
    test('renders confirmation dialog when isVisible is true', () => {
      renderComponent();

      expect(screen.getByTestId('confirmation-dialog')).toBeInTheDocument();
      expect(screen.getByTestId('dialog-message')).toHaveTextContent(
        'Device ID TEST12345 is on the Lost/Stolen list. Do you wish to delete this device from the list?'
      );
      expect(screen.getByTestId('yes-button')).toHaveTextContent('Continue');
      expect(screen.getByTestId('no-button')).toHaveTextContent('Cancel');
    });

    test('does not render when isVisible is false', () => {
      renderComponent({ isVisible: false });

      expect(screen.queryByTestId('confirmation-dialog')).not.toBeInTheDocument();
    });

    test('renders with correct device ID in message', () => {
      const testDeviceId = 'DEVICE123';
      renderComponent({ deviceId: testDeviceId });

      expect(screen.getByTestId('dialog-message')).toHaveTextContent(
        `Device ID ${testDeviceId} is on the Lost/Stolen list. Do you wish to delete this device from the list?`
      );
    });

    test('buttons are initially enabled', () => {
      renderComponent();

      expect(screen.getByTestId('yes-button')).not.toBeDisabled();
      expect(screen.getByTestId('no-button')).not.toBeDisabled();
    });
  });

  describe('User Interactions - Cancel Action', () => {
    test('calls onCancel when no button is clicked', () => {
      const onCancel = jest.fn();
      renderComponent({ onCancel });

      fireEvent.click(screen.getByTestId('no-button'));

      expect(onCancel).toHaveBeenCalledTimes(1);
    });

    test('does not dispatch any actions when cancel is clicked', () => {
      renderComponent();

      fireEvent.click(screen.getByTestId('no-button'));

      expect(mockDispatch).not.toHaveBeenCalled();
    });
  });

  describe('User Interactions - Confirm Action Success', () => {
    test('calls onSuccess with deviceId and only dispatches loader actions — no success addAppMessage', async () => {
      const onSuccess = jest.fn();
      mockAllowDeviceIdToReuse.mockResolvedValue({
        data: { devices: [{ statusCode: '00' }] },
      });

      renderComponent({ onSuccess });

      fireEvent.click(screen.getByTestId('yes-button'));

      await waitFor(() => {
        expect(mockAllowDeviceIdToReuse).toHaveBeenCalledWith({
          customHeaders: { 'enable-deviceid': 'TEST12345' },
          body: expect.objectContaining({
            transactionType: 'StolenDelete',
            locationCode: undefined,
            cartCreator: undefined,
          }),
        });
      });

      await waitFor(() => {
        expect(onSuccess).toHaveBeenCalledWith('TEST12345');
      });
      await waitFor(() => {
        expect(mockDispatch).toHaveBeenCalledTimes(2);
      });
      expect(mockDispatch).toHaveBeenNthCalledWith(1, appLoaderActions.show());
      expect(mockDispatch).toHaveBeenNthCalledWith(2, appLoaderActions.hide());
      expect(appMessageActions.addAppMessage).not.toHaveBeenCalledWith(
        expect.stringContaining('successfully removed from the Lost/Stolen list'),
        'success',
        true
      );
    });

    test('calls onSuccess with deviceId via response.devices path', async () => {
      const onSuccess = jest.fn();
      mockAllowDeviceIdToReuse.mockResolvedValue({
        devices: [{ statusCode: '00' }],
      });

      renderComponent({ onSuccess });

      fireEvent.click(screen.getByTestId('yes-button'));

      await waitFor(() => {
        expect(onSuccess).toHaveBeenCalledWith('TEST12345');
      });
    });

    test('calls onSuccess with correct deviceId for different device IDs', async () => {
      const testDeviceId = 'CUSTOM123';
      const onSuccess = jest.fn();
      mockAllowDeviceIdToReuse.mockResolvedValue({
        data: { devices: [{ statusCode: '00' }] },
      });

      renderComponent({ deviceId: testDeviceId, onSuccess });

      fireEvent.click(screen.getByTestId('yes-button'));

      await waitFor(() => {
        expect(onSuccess).toHaveBeenCalledWith(testDeviceId);
      });

      expect(appMessageActions.addAppMessage).not.toHaveBeenCalledWith(
        expect.stringContaining(testDeviceId),
        'success',
        true
      );
    });

    test('calls onCancel and shows error when API returns non-success statusCode', async () => {
      const onCancel = jest.fn();
      mockAllowDeviceIdToReuse.mockResolvedValue({
        data: { devices: [{ statusCode: '99' }] },
      });

      renderComponent({ onCancel });

      fireEvent.click(screen.getByTestId('yes-button'));

      await waitFor(() => {
        expect(onCancel).toHaveBeenCalledTimes(1);
      });
      expect(appMessageActions.addAppMessage).toHaveBeenCalledWith(
        'Could not remove the device ID TEST12345 from the Lost/Stolen list, please try again',
        'error',
        true
      );
    });
  });

  describe('User Interactions - API Error Handling', () => {
    test('handles API non-200 status response and calls onCancel', async () => {
      const onCancel = jest.fn();
      mockAllowDeviceIdToReuse.mockResolvedValue({
        status: 400,
        data: { error: 'Bad Request' },
      });

      renderComponent({ onCancel });

      fireEvent.click(screen.getByTestId('yes-button'));

      await waitFor(() => {
        expect(mockDispatch).toHaveBeenCalledWith(
          appMessageActions.addAppMessage(
            'Could not remove the device ID TEST12345 from the Lost/Stolen list, please try again',
            'error',
            true
          )
        );
      });

      expect(mockDispatch).toHaveBeenCalledWith(appLoaderActions.show());
      expect(mockDispatch).toHaveBeenCalledWith(appLoaderActions.hide());
      expect(onCancel).toHaveBeenCalledTimes(1);
    });

    test('handles API 500 status response and calls onCancel', async () => {
      const onCancel = jest.fn();
      mockAllowDeviceIdToReuse.mockResolvedValue({
        status: 500,
        data: { error: 'Internal Server Error' },
      });

      renderComponent({ onCancel });

      fireEvent.click(screen.getByTestId('yes-button'));

      await waitFor(() => {
        expect(mockDispatch).toHaveBeenCalledWith(
          appMessageActions.addAppMessage(
            'Could not remove the device ID TEST12345 from the Lost/Stolen list, please try again',
            'error',
            true
          )
        );
      });

      expect(mockDispatch).toHaveBeenCalledWith(appLoaderActions.show());
      expect(mockDispatch).toHaveBeenCalledWith(appLoaderActions.hide());
      expect(onCancel).toHaveBeenCalledTimes(1);
    });

    test('displays error message with correct device ID for non-200 status', async () => {
      const testDeviceId = 'ERROR123';
      mockAllowDeviceIdToReuse.mockResolvedValue({
        status: 404,
        data: { error: 'Not Found' },
      });

      renderComponent({ deviceId: testDeviceId });

      fireEvent.click(screen.getByTestId('yes-button'));

      await waitFor(() => {
        expect(appMessageActions.addAppMessage).toHaveBeenCalledWith(
          `Could not remove the device ID ${testDeviceId} from the Lost/Stolen list, please try again`,
          'error',
          true
        );
      });
    });

    test('handles API rejection and calls onCancel', async () => {
      const onCancel = jest.fn();
      mockAllowDeviceIdToReuse.mockRejectedValue(new Error('API Error'));

      renderComponent({ onCancel });

      fireEvent.click(screen.getByTestId('yes-button'));

      await waitFor(() => {
        expect(mockDispatch).toHaveBeenCalledWith(
          appMessageActions.addAppMessage(
            'Could not remove the device ID TEST12345 from the Lost/Stolen list, please try again',
            'error',
            true
          )
        );
      });

      expect(mockDispatch).toHaveBeenCalledWith(appLoaderActions.show());
      expect(mockDispatch).toHaveBeenCalledWith(appLoaderActions.hide());
      expect(onCancel).toHaveBeenCalledTimes(1);
    });

    test('displays error message with correct device ID', async () => {
      const testDeviceId = 'ERROR123';
      mockAllowDeviceIdToReuse.mockRejectedValue(new Error('API Error'));

      renderComponent({ deviceId: testDeviceId });

      fireEvent.click(screen.getByTestId('yes-button'));

      await waitFor(() => {
        expect(appMessageActions.addAppMessage).toHaveBeenCalledWith(
          `Could not remove the device ID ${testDeviceId} from the Lost/Stolen list, please try again`,
          'error',
          true
        );
      });
    });
  });

  describe('Loading States', () => {
    test('disables buttons during processing', async () => {
      // Mock a delayed API response
      mockAllowDeviceIdToReuse.mockImplementation(
        () => new Promise((resolve) => setTimeout(() => resolve({ data: { success: true } }), 100))
      );

      renderComponent();

      fireEvent.click(screen.getByTestId('yes-button'));

      // Check that buttons are disabled immediately after click
      expect(screen.getByTestId('yes-button')).toBeDisabled();
      expect(screen.getByTestId('no-button')).toBeDisabled();

      // Wait for completion
      await waitFor(() => {
        expect(mockDispatch).toHaveBeenCalledWith(appLoaderActions.hide());
      });
    });

    test('shows and hides loader during API call', async () => {
      mockAllowDeviceIdToReuse.mockResolvedValue({
        status: 200,
        data: { success: true },
      });

      renderComponent();

      fireEvent.click(screen.getByTestId('yes-button'));

      await waitFor(() => {
        expect(mockDispatch).toHaveBeenCalledWith(appLoaderActions.show());
      });

      await waitFor(() => {
        expect(mockDispatch).toHaveBeenCalledWith(appLoaderActions.hide());
      });
    });

    test('hides loader even when API call fails', async () => {
      mockAllowDeviceIdToReuse.mockRejectedValue(new Error('API Error'));

      renderComponent();

      fireEvent.click(screen.getByTestId('yes-button'));

      await waitFor(() => {
        expect(mockDispatch).toHaveBeenCalledWith(appLoaderActions.show());
      });

      await waitFor(() => {
        expect(mockDispatch).toHaveBeenCalledWith(appLoaderActions.hide());
      });
    });
  });

  describe('API Service Integration', () => {
    test('calls API with correct parameters', async () => {
      const testDeviceId = 'API123';
      mockAllowDeviceIdToReuse.mockResolvedValue({
        status: 200,
        data: { success: true },
      });

      renderComponent({ deviceId: testDeviceId });

      fireEvent.click(screen.getByTestId('yes-button'));

      await waitFor(() => {
        expect(mockAllowDeviceIdToReuse).toHaveBeenCalledWith({
          customHeaders: {
            'enable-deviceid': testDeviceId,
          },
          body: expect.objectContaining({
            transactionType: 'StolenDelete',
            locationCode: undefined,
            cartCreator: undefined,
          }),
        });
      });
    });

    test('useLazyAllowDeviceIdToReuseQuery hook is called', () => {
      renderComponent();

      expect(useLazyAllowDeviceIdToReuseQuery).toHaveBeenCalledTimes(1);
    });
  });

  describe('Redux Integration', () => {
    test('dispatches only loader actions on success — no addAppMessage from this component', async () => {
      const onSuccess = jest.fn();
      mockAllowDeviceIdToReuse.mockResolvedValue({
        data: { devices: [{ statusCode: '00' }] },
      });

      renderComponent({ onSuccess });

      fireEvent.click(screen.getByTestId('yes-button'));

      await waitFor(() => {
        expect(mockDispatch).toHaveBeenCalledTimes(2);
      });

      expect(mockDispatch).toHaveBeenNthCalledWith(1, appLoaderActions.show());
      expect(mockDispatch).toHaveBeenNthCalledWith(2, appLoaderActions.hide());
      expect(onSuccess).toHaveBeenCalledWith('TEST12345');
    });

    test('dispatches correct error actions', async () => {
      mockAllowDeviceIdToReuse.mockRejectedValue(new Error('API Error'));

      renderComponent();

      fireEvent.click(screen.getByTestId('yes-button'));

      await waitFor(() => {
        expect(mockDispatch).toHaveBeenCalledTimes(3);
      });

      expect(mockDispatch).toHaveBeenNthCalledWith(1, appLoaderActions.show());
      expect(mockDispatch).toHaveBeenNthCalledWith(
        2,
        appMessageActions.addAppMessage(
          'Could not remove the device ID TEST12345 from the Lost/Stolen list, please try again',
          'error',
          true
        )
      );
      expect(mockDispatch).toHaveBeenNthCalledWith(3, appLoaderActions.hide());
    });
  });

  describe('Notification Analytics Tracking', () => {
    test('calls sendCustomEvent and sets vzdl.target.message when target exists', async () => {
      const mockVzdl = { target: { message: '' } };
      window.vzdl = mockVzdl;

      mockAllowDeviceIdToReuse.mockResolvedValue({ status: 200, data: { success: true } });

      renderComponent();
      fireEvent.click(screen.getByTestId('yes-button'));

      await waitFor(() => {
        expect(mockVzdl.target.message).toBe(
          ''
        );
      });
    });

    test('calls sendCustomEvent without setting message when vzdl.target does not exist', async () => {
      const mockVzdl = {};
      window.vzdl = mockVzdl;

      mockAllowDeviceIdToReuse.mockResolvedValue({ status: 200, data: { success: true } });

      renderComponent();
      fireEvent.click(screen.getByTestId('yes-button'));

      await waitFor(() => {
        expect(mockVzdl.target).toBeUndefined();
      });
    });
  });

  describe('Component State Management', () => {
    test('manages isProcessing state correctly during success flow', async () => {
      mockAllowDeviceIdToReuse.mockResolvedValue({
        status: 200,
        data: { success: true },
      });

      renderComponent();

      // Initially buttons should be enabled
      expect(screen.getByTestId('yes-button')).not.toBeDisabled();
      expect(screen.getByTestId('no-button')).not.toBeDisabled();

      fireEvent.click(screen.getByTestId('yes-button'));

      // During processing, buttons should be disabled
      expect(screen.getByTestId('yes-button')).toBeDisabled();
      expect(screen.getByTestId('no-button')).toBeDisabled();

      // Wait for completion - buttons should remain disabled as component likely unmounts
      await waitFor(() => {
        expect(mockDispatch).toHaveBeenCalledWith(appLoaderActions.hide());
      });
    });

    test('manages isProcessing state correctly during error flow', async () => {
      mockAllowDeviceIdToReuse.mockRejectedValue(new Error('API Error'));

      renderComponent();

      fireEvent.click(screen.getByTestId('yes-button'));

      // During processing, buttons should be disabled
      expect(screen.getByTestId('yes-button')).toBeDisabled();
      expect(screen.getByTestId('no-button')).toBeDisabled();

      await waitFor(() => {
        expect(mockDispatch).toHaveBeenCalledWith(appLoaderActions.hide());
      });
    });
  });

  describe('PropTypes and Edge Cases', () => {
    test('handles empty device ID', () => {
      renderComponent({ deviceId: '' });

      expect(screen.getByTestId('dialog-message')).toHaveTextContent(
        'Device ID is on the Lost/Stolen list. Do you wish to delete this device from the list?'
      );
    });

    test('handles special characters in device ID', () => {
      const specialDeviceId = 'DEV-123_456@test';
      renderComponent({ deviceId: specialDeviceId });

      expect(screen.getByTestId('dialog-message')).toHaveTextContent(
        `Device ID ${specialDeviceId} is on the Lost/Stolen list. Do you wish to delete this device from the list?`
      );
    });

    test('handles multiple rapid clicks gracefully', async () => {
      mockAllowDeviceIdToReuse.mockResolvedValue({
        status: 200,
        data: { success: true },
      });

      renderComponent();

      const yesButton = screen.getByTestId('yes-button');

      fireEvent.click(yesButton);
      fireEvent.click(yesButton);
      fireEvent.click(yesButton);

      await waitFor(() => {
        expect(mockAllowDeviceIdToReuse).toHaveBeenCalledTimes(1);
      });
    });
  });

  describe('Component Lifecycle', () => {
    test('component unmounts cleanly', () => {
      const { unmount } = renderComponent();

      expect(() => unmount()).not.toThrow();
    });

    test('re-renders correctly when props change', () => {
      const { rerender } = renderComponent({ deviceId: 'INITIAL123' });

      expect(screen.getByTestId('dialog-message')).toHaveTextContent('INITIAL123');

      rerender(
        <Provider store={mockStore}>
          <LostStolenConfirmation {...defaultProps} deviceId='UPDATED456' />
        </Provider>
      );

      expect(screen.getByTestId('dialog-message')).toHaveTextContent('UPDATED456');
    });

    test('maintains functionality when isVisible toggles', () => {
      const { rerender } = renderComponent({ isVisible: true });

      expect(screen.getByTestId('confirmation-dialog')).toBeInTheDocument();

      rerender(
        <Provider store={mockStore}>
          <LostStolenConfirmation {...defaultProps} isVisible={false} />
        </Provider>
      );

      expect(screen.queryByTestId('confirmation-dialog')).not.toBeInTheDocument();

      rerender(
        <Provider store={mockStore}>
          <LostStolenConfirmation {...defaultProps} isVisible={true} />
        </Provider>
      );

      expect(screen.getByTestId('confirmation-dialog')).toBeInTheDocument();
    });
  });
});
