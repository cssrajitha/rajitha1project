import React from 'react';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import Emitter from 'onevzsoemfeframework/Emitter';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import { render, screen, fireEvent } from '../../../modules/test-utils/renderHelper';
import GridwallHeader from './GridwallContinueButton';
import customerData from '../__mocks__/customerProfile.json';
import retrieveCartInitial from '../__mocks__/retrieveCartInitial.json';
import retrieveCartByod from '../__mocks__/retrieveCartByod.json';
import retrieveCartByod1 from '../__mocks__/retrieveCartByod1.json';

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradleProperty: () => ['TRUE'],
    getAssistedCradlePropertyV2: () => ['TRUE'],
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfecommon/APIService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfecommon/APIService'),
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    getQueryParamByName: (val) => {
      if (val === 'deviceId' || val === 'simId') {
        return false;
      } if (val === 'isPlanTabSelect') {
        return true;
      } if (val === 'activeMtn') {
        return '6095773280';
      }
    },
    isIndirect: () => true,
  }),
  { virtual: true },
);

describe('GridwallHeader component - New Customer', () => {
  const handleBackNavigation = jest.fn().mockName('handleBackNavigation');
  const handleContinue = jest.fn().mockName('handleContinue');
  const handlers = [
    rest.post(`*/accountlandingservice/flexV2/customerProfile`, (req, res, ctx) => {
      console.log('inside /accountlandingservice/flexV2/customerProfile');
      return res(ctx.status(200), ctx.json(customerData));
    }),
    rest.post(`*/cartservice/cart/flexV2/retrieve-cart`, (req, res, ctx) => res(ctx.status(200), ctx.json(retrieveCartInitial))),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('isEtrServiceChangesFlow', true);
  });
  afterAll(() => {
    server.close();
    sessionStorage.removeItem('isEtrServiceChangesFlow');
  });
  beforeEach(() => {
    window.history.pushState({}, 'Gridwall', '/sales/assisted/new/gridwall.html?fromPromotions=true');

    jest.spyOn(console, 'error');
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockImplementation(() => null);

    render(<GridwallHeader handleBackNavigation={handleBackNavigation} handleContinue={handleContinue} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  it('should click continue button', async () => {
    await new Promise((res) => {
      setTimeout(res, 4000);
    });
    Emitter.emit('ProspectBYODTile', true);
    Emitter.emit('Update_dwos', true);
    const testContinueGridwall = screen.getByTestId('testContinueGridwall');
    expect(testContinueGridwall).toBeInTheDocument();
    const testContinueGridwallBtn = screen.getByTestId('testContinueGridwallBtn');
    expect(testContinueGridwallBtn).toBeInTheDocument();
    fireEvent.click(testContinueGridwallBtn);
  });

  afterAll(() => {
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockRestore();
  });
});

describe('GridwallHeader component - New Customer', () => {
  const handleBackNavigation = jest.fn().mockName('handleBackNavigation');
  const handleContinue = jest.fn().mockName('handleContinue');
  const handlers = [
    rest.post(`*/accountlandingservice/flexV2/customerProfile`, (req, res, ctx) => {
      console.log('inside /accountlandingservice/flexV2/customerProfile');
      return res(ctx.status(200), ctx.json(customerData));
    }),
    rest.post(`*/cartservice/cart/flexV2/retrieve-cart`, (req, res, ctx) => res(ctx.status(200), ctx.json(retrieveCartByod))),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('isEtrServiceChangesFlow', true);
  });
  afterAll(() => {
    server.close();
    sessionStorage.removeItem('isEtrServiceChangesFlow');
  });
  beforeEach(() => {
    window.history.pushState({}, 'Gridwall', '/sales/assisted/new/gridwall.html?fromPromotions=true');

    jest.spyOn(console, 'error');
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockImplementation(() => null);

    render(<GridwallHeader handleBackNavigation={handleBackNavigation} handleContinue={handleContinue} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  it('should click continue button', async () => {
    await new Promise((res) => {
      setTimeout(res, 4000);
    });
    Emitter.emit('ProspectBYODTile', true);
    Emitter.emit('Update_dwos', true);
    const testContinueGridwall = screen.getByTestId('testContinueGridwall');
    expect(testContinueGridwall).toBeInTheDocument();
    const testContinueGridwallBtn = screen.getByTestId('testContinueGridwallBtn');
    expect(testContinueGridwallBtn).toBeInTheDocument();
    fireEvent.click(testContinueGridwallBtn);
  });

  afterAll(() => {
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockRestore();
  });
});
describe('GridwallHeader component - New Customer', () => {
  const handleBackNavigation = jest.fn().mockName('handleBackNavigation');
  const handleContinue = jest.fn().mockName('handleContinue');
  const handlers = [
    rest.post(`*/accountlandingservice/flexV2/customerProfile`, (req, res, ctx) => {
      console.log('inside /accountlandingservice/flexV2/customerProfile');
      return res(ctx.status(200), ctx.json(customerData));
    }),
    rest.post(`*/cartservice/cart/flexV2/retrieve-cart`, (req, res, ctx) => res(ctx.status(200), ctx.json(retrieveCartByod1))),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('isEtrServiceChangesFlow', true);
  });
  afterAll(() => {
    server.close();
    sessionStorage.removeItem('isEtrServiceChangesFlow');
  });
  beforeEach(() => {
    window.history.pushState({}, 'Gridwall', '/sales/assisted/new/gridwall.html?fromPromotions=true');

    jest.spyOn(console, 'error');
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockImplementation(() => null);

    render(<GridwallHeader handleBackNavigation={handleBackNavigation} handleContinue={handleContinue} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  it('should click continue button', async () => {
    await new Promise((res) => {
      setTimeout(res, 4000);
    });
    Emitter.emit('ProspectBYODTile', true);
    Emitter.emit('Update_dwos', true);
    const testContinueGridwall = screen.getByTestId('testContinueGridwall');
    expect(testContinueGridwall).toBeInTheDocument();
    const testContinueGridwallBtn = screen.getByTestId('testContinueGridwallBtn');
    expect(testContinueGridwallBtn).toBeInTheDocument();
    fireEvent.click(testContinueGridwallBtn);
  });

  afterAll(() => {
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockRestore();
  });
});
