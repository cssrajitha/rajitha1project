import React from 'react';
import { isRetail } from 'onevzsoemfeframework/DomService';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import { fireEvent, render, screen } from '../../../modules/test-utils/renderHelper';
import Header from './Header';

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradlePropertyV2: () => ['FALSE', 'FALSE', 'FALSE'],
  }),
  { virtual: true },
);

describe('Header component render', () => {
  const props = {
    onAutoCompleteItemSkuSearch: jest.fn(),
    deviceCategory: 'smartphone',
    showToogle: true,
    offerMessage: 'Requirement 3 BIC Simple',
    existingSortOptions: [],
    toggle: false,
    categoryValue: '',
    path: '',
    is5GDevice: false,
    selectedTab: -1,
    offerSourceSystem: 'OC_PROSPECT',
    propositionMessage: 'Requirement 3 BIC Simple',
    offerSubType: 'Simple',
    isDWOS: false,
    intentCheck: true,
    rebeaBYODCheck: false,
    isOffersStacked: false,
    setToggle: jest.fn(),
    setUpcCode: jest.fn(),
  };
  beforeAll(() => {
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
  });

  beforeEach(() => {
    render(<Header {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('component should render', () => {
    const text = screen.getByRole('img', { name: /switch icon/i });
    fireEvent.click(text);
  });
  test('switch_icon test id returns', () => {
    const icon = screen.getByRole('img', { name: /switch icon/i });
    expect(icon).toBeInTheDocument();
    fireEvent.click(icon);
  });
  test('should click scan icon', () => {
    expect(isRetail()).toBeTruthy();
    const ScanIcon = screen.getByTestId('testScanBtn');
    expect(ScanIcon).toBeInTheDocument();
    fireEvent.click(ScanIcon);
    const text = screen.getByText(/Enter Device ID/i);
    expect(text).toBeInTheDocument();
  });
});
describe('Header component render', () => {
  const props = {
    cartDetails: {
      cart: {
        cartHeader: { locationSubType: 'GN', maid: 'BBX' },
      },
    },
    onAutoCompleteItemSkuSearch: jest.fn(),
    deviceCategory: 'smartphone',
    showToogle: true,
    offerMessage: 'Requirement 3 BIC Simple',
    existingSortOptions: [],
    toggle: false,
    categoryValue: '',
    path: '',
    is5GDevice: false,
    selectedTab: -1,
    offerSourceSystem: 'OC_PROSPECT',
    propositionMessage: 'Requirement 3 BIC Simple',
    offerSubType: 'Simple',
    isDWOS: false,
    intentCheck: true,
    rebeaBYODCheck: false,
    isOffersStacked: false,
    setToggle: jest.fn(),
    TakeOverScreenFunc: jest.fn(),
    setUpcCode: jest.fn(),
  };
  sessionStorage.setItem('APP_PROPERTIES', '{"bestBuyIntegrationFFlag": "TRUE", "pearlBYODFlow": "TRUE"}');
  beforeAll(() => {
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
  });

  beforeEach(() => {
    render(<Header {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('component should render', () => {
    const text = screen.getByRole('img', { name: /switch icon/i });
    fireEvent.click(text);
  });
  test('switch_icon test id returns', () => {
    const icon = screen.getByRole('img', { name: /switch icon/i });
    expect(icon).toBeInTheDocument();
    fireEvent.click(icon);
  });
  test('should click scan icon', () => {
    expect(isRetail()).toBeTruthy();
    const ScanIcon = screen.getByTestId('testScanBtn');
    expect(ScanIcon).toBeInTheDocument();
    fireEvent.click(ScanIcon);
  });
});
describe('Header component render 1', () => {
  const props = {
    onAutoCompleteItemSkuSearch: jest.fn(),
    showToogle: true,
    offerMessage: 'Requirement 3 BIC Simple',
    existingSortOptions: [],
    toggle: false,
    categoryValue: '',
    path: '',
    is5GDevice: false,
    selectedTab: -1,
    offerSourceSystem: 'OC_PROSPECT',
    propositionMessage: 'Requirement 3 BIC Simple',
    offerSubType: 'Simple',
    isDWOS: false,
    intentCheck: true,
    rebeaBYODCheck: false,
    isOffersStacked: true,
    setToggle: jest.fn(),
    TakeOverScreenFunc: jest.fn(),
  };
  beforeAll(() => {
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
  });

  beforeEach(() => {
    render(<Header {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('component should render', () => {
    const text = screen.getByRole('img', { name: /switch icon/i });
    fireEvent.click(text);
  });
  test('switch_icon test id returns', () => {
    const icon = screen.getByRole('img', { name: /switch icon/i });
    expect(icon).toBeInTheDocument();
    fireEvent.click(icon);
  });
  test('should click scan icon', () => {
    expect(isRetail()).toBeTruthy();
    const ScanIcon = screen.getByTestId('testScanBtn');
    expect(ScanIcon).toBeInTheDocument();
    fireEvent.click(ScanIcon);
    const text = screen.getByText(/Enter Device ID/i);
    expect(text).toBeInTheDocument();
  });
  test('isFullFillment testing', async () => {
    jest.setTimeout(20000);
    expect(isRetail()).toBeTruthy();
    const ScanIcon = screen.getByTestId('testScanBtn');
    expect(ScanIcon).toBeInTheDocument();
    fireEvent.keyPress(ScanIcon, { key: 'Enter', charCode: 32 });
    fireEvent.click(ScanIcon);
  });
});

describe('Header component scan icon should not be in the document', () => {
  const props = {
    onAutoCompleteItemSkuSearch: jest.fn(),
    showToogle: true,
    offerMessage: 'Requirement 3 BIC Simple',
    existingSortOptions: [],
    toggle: false,
    categoryValue: '',
    path: '',
    is5GDevice: true,
    selectedTab: -1,
    offerSourceSystem: 'OC_PROSPECT',
    propositionMessage: 'Requirement 3 BIC Simple',
    offerSubType: 'Simple',
    isDWOS: false,
    intentCheck: true,
    rebeaBYODCheck: false,
    isOffersStacked: true,
    setToggle: jest.fn(),
    TakeOverScreenFunc: jest.fn(),
  };
  sessionStorage.setItem('APP_PROPERTIES', '{"hideScanIconInGridwallFor5GFFlag": "TRUE"}');

  beforeAll(() => {
    sessionStorage.setItem('channel', 'OMNI-RETAIL');
  });

  beforeEach(() => {
    render(<Header {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('scan icon should not be in the document', () => {
    expect(isRetail()).toBeTruthy();
    const ScanIcon = screen.queryByText('barcode');
    expect(ScanIcon).not.toBeInTheDocument();
  });
});
