import { Input } from '@vds/inputs';
import { Icon } from '@vds/icons';
import styled from 'styled-components';
import { Body } from '@vds/typography';
import PropTypes from 'prop-types';
import { useCallback, useEffect, useState } from 'react';
import { debounce, isEmpty } from 'lodash';
import { decodeHTMLEntities } from 'onevzsoemfecommon/Helpers';
import { isVbg } from 'onevzsoemfeframework/VbgAemUtil';
import { useLazyGetTypeAheadQuery } from 'onevzsoemfecommon/APIService';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { isIpad, executeShellFunction } from 'onevzsoemfeframework/DomService';

const Wrap = styled.span`
  position: absolute;
  width: 200px;
  right: 100%;
  bottom: -0.02rem;
`;

const IconWrap = styled.div`
  position: absolute;
  right: 8px;
  bottom: 6px;
`;

const BottomBorder = styled.div`
  padding: 0.75rem 0;
  border-bottom: 1px solid #d9d9d9;
`;

const CustomBoxArrow = styled.div`
  border: 1px solid #d9d9d9;
  border-width: 1px 0 0 1px;
  background: white;
  width: 0.675rem;
  height: 0.675rem;
  position: absolute;
  margin-top: 1.2rem;
  right: calc(100% + 5.5rem);
  -webkit-transform: rotate(45deg);
  transform: rotate(45deg);
  z-index: 10001;
`;

const CustomBox = styled.div`
  box-sizing: border-box;
  background-color: rgb(255, 255, 255);
  border: 0.0625rem solid #d9d9d9;
  border-radius: 0.8rem;
  top: calc(100% + 1px);
  left: -6.5rem;
  position: absolute;
  overflow-y: auto;
  padding: 0.75rem 0.75rem 0;
  max-height: 14.8rem;
  height: fit-content;
  width: 18rem;
  min-width: 16.5rem;
  text-align: left;
  transform: translateX(-50%);
  visibility: visible;
  will-change: transform, left;
  z-index: 998;
  outline: none;
  bottom: 1.875rem;
  ::-webkit-scrollbar {
    display: none;
  }
`;

function Search(props) {
  const { cartDetails, customerData, activeMtn } = props;
  const [state, setState] = useState({
    searchResult: null,
    showAutoComplete: false,
    enableAutoComplete: true,
    searchText: '',
    isValid: false,
  });
  const [searchDropDown, setSearchDropDown] = useState(true);
  const [is5GLine, setIs5GLine] = useState(false);
  const [getTypeAheadList, TypeAheadListResult] = useLazyGetTypeAheadQuery();
  const searchFromShellFFlag = /true/i.test(getAssistedCradlePropertyV2(['searchFromShellFFlag'])?.[0]);
  const scmDeviceMfeEnable = window?.mfe?.scmDeviceMfeEnable;
  const scmUpgradeMfeEnable = window?.mfe?.scmUpgradeMfeEnable;

  useEffect(() => {
    searchFromShellFFlag && (window.searchFromShell = searchFromShell);
  }, []);

  useEffect(() => {
    setState({
      searchResult: null,
      showAutoComplete: false,
      enableAutoComplete: true,
      searchText: '',
      isValid: false,
    });
  }, [props.selectedTab]);

  useEffect(() => {
    setState({
      searchResult: null,
      showAutoComplete: false,
      enableAutoComplete: true,
      searchText: props.searchStrValue,
      isValid: false,
    });
    if (isValidSkuId(props.searchStrValue)) {
      props.onAutoCompleteItemSkuSearch(props.searchStrValue);
    }
  }, [props.searchStrValue]);

  useEffect(() => {
    const lineInfo = cartDetails?.cart?.lineDetails?.lineInfo || [];
    let activeLine = lineInfo?.filter((line) => line?.mobileNumber === activeMtn);
    const mtns = customerData?.billAccounts?.[0]?.mtns || [];
    if (activeLine?.length < 1) {
      activeLine = mtns?.filter((line) => line?.mtn === activeMtn);
    }
    setIs5GLine(activeLine?.length > 0 && activeLine[0].deviceTypeSelected === '5G Internet');
  }, [cartDetails, customerData, activeMtn]);

  useEffect(() => {
    if (!isEmpty(TypeAheadListResult?.data?.data?.typeAheadResults)) {
      const searchResult = TypeAheadListResult?.data?.data?.typeAheadResults;
      setState({ ...state, searchText, searchResult, showAutoComplete: true });
      props.setShowSearchResults(true);
      setSearchDropDown(true);
    } else if (searchText !== '') {
      const searchResult = [];
      setState({ ...state, searchText, searchResult, showAutoComplete: true });
      props.setShowNoResults(true);
      props.setShowSearchResults(true);
      setSearchDropDown(true);
    }
  }, [TypeAheadListResult]);

  const isValidSkuId = (skuId) => /^[^(<>)|\t\r\n\f]*$/.test(skuId);

  const isVbgAndFiveG = () => isVbg() && props.is5GDevice;

  const search = (searchText) => {
    let productType = window.location.pathname.includes('gridwall') ? 'device' : 'accessory'; // we need to check with team how we will pass route value
    if (scmUpgradeMfeEnable && scmDeviceMfeEnable && props?.productTypeForSearch) {
      productType = props.productTypeForSearch;
    }
    const params = {
      searchText,
      productType,
      ...(isVbg() && is5GLine ? { deviceTypeSelected: "5G Internet" } : {})
    };
    getTypeAheadList({ body: params, spinner: false }, false);
    props?.setToggle(false);
  };
  const delayedSearch = useCallback(debounce(search, 500), [is5GLine]);
  const onSearchChange = (event) => {
    const searchStr = event.target.value.trimLeft();
    setState({ ...state, searchText: searchStr });
    if (props.path === 'feature') {
      props.onSearchTxtChange(event);
    } else if (isValidSkuId(searchStr)) {
      props.onSearchTxtChange(event);
      if (state.enableAutoComplete) {
        delayedSearch(searchStr);
      }
    } else if (searchStr === '') {
      props.onSearchTxtChange(event);
    }
  };

  const searchFromShell = (searchStr = null) => {
    setState({ ...state, searchText: searchStr });
    if (searchStr !== null) {
      props?.getSkuList(searchStr, true);
    }
}

  const getPlaceholderText = () => {
    if (window.location.pathname.includes('Gridwall')) return 'Search devices';
    if (window.location.pathname.includes('accessories')) return 'Search accessories';
    if (window.location.pathname.includes('addons')) return 'Search add-ons';
    return 'Search';
  };

  const getSkuList = () => {
    const { searchText } = state;
    if (searchText !== '') {
      props?.getSkuList(searchText, true);
    }
  };

  const onKeyDown = (e) => {
    if (e.keyCode === 13) {
      if (window.location.pathname.includes('gridwall') || window.location.pathname.includes('accessories')) {
        setState({ ...state, searchResult: null });
        getSkuList();
        props.setShowSearchResults(false);
        props.setShowNoResults(false);
      }
    }
  };
  const { searchText } = state;
  const placeholderText = getPlaceholderText();

  const crossButtonClick = () => {
    setState({ ...state, searchText: '', searchResult: null });
  };
  const handleSearchText = (item) => {
    props.onAutoCompleteItemSkuSearch(item);
    setSearchDropDown(false);
  };

  const searchUsingVoice = (e) => {
    if (e) e.preventDefault();
    executeShellFunction('Shell', 'searchFromShellUsingVoice', 'none', null);
  }

  const isSearchDisabled = isVbgAndFiveG() ? false : props.is5GDevice;

  return (
    <>
    <span>
      {' '}
      {/* onMouseLeave={onSearchClick} */}
      <Wrap>
        <Input
          type='text'
          onKeyDown={(e) => {
            onKeyDown(e);
          }}
          aria-label={placeholderText}
          placeholder={placeholderText}
          data-testid='ShopNavSearchText'
          onChange={onSearchChange}
          value={searchText}
          disabled={isSearchDisabled}
          required={false}
          id='searchInputBox'
        />
        <IconWrap
          data-testid='testCrossBtn'
          onClick={() => {
            crossButtonClick();
          }}
        >
          <Icon name={searchText || state.searchResult?.length > 0 ? 'close' : 'search'} />
        </IconWrap>
      </Wrap>
      {state.searchResult && props.showSearchResults && searchDropDown && (
        <>
          <CustomBoxArrow />
          <CustomBox data-testid='dropdownbox'>
            {state.searchResult.slice(0, 10).map((item) => (
              <BottomBorder
                key={`${item.skuSorId}-sample`}
                // onClick={() => props.data.handleSearchText(data.model)}
                onMouseDown={() => {
                  handleSearchText(item.skuSorId);
                }}
                data-testid='SearchSuggestion'
              >
                <Body size='large' key={item.skuSorId} data-testid={item.skuSorId}>
                  {`${item.skuSorId} (${decodeHTMLEntities(item.productDisplayName)})`}
                </Body>
              </BottomBorder>
            ))}
          </CustomBox>
        </>
      )}
      {state.searchResult && props.showNoResults && state.searchResult?.length === 0 && (
        <>
          <CustomBoxArrow />
          <CustomBox>
            <BottomBorder>
              <Body data-testid='NoSearchResults' size='large'>
                No search results
              </Body>
            </BottomBorder>
          </CustomBox>
        </>
      )}
      </span>
      {(searchFromShellFFlag && isIpad() &&
            <span data-testid='micIcon' onClick={(e) => searchUsingVoice(e) }>
              <Icon name='microphone' size="XLarge" color='#000000'/>
            </span>
      )}
    </>
  );
}
Search.propTypes = {
  channel: PropTypes.string.isRequired,
};
export default Search;
