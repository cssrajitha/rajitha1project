import { Icon } from '@vds/icons';
import { Body } from '@vds/typography';
import { useState, useEffect } from 'react';
import styled from 'styled-components';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import TimeoutManager from 'onevzsoemfecommon/TimeoutManager';

const BottomBorder = styled.div`
  padding: 0.75rem 0;
  border-bottom: 1px solid lightgray;
  cursor: pointer;
`;

const CustomBoxArrow = styled.div`
  border: 1px solid #d9d9d9;
  border-width: 1px 0 0 1px;
  background: white;
  width: 0.675rem;
  height: 0.675rem;
  position: absolute;
  margin-top: 1.78rem;
  right: 1%;
  -webkit-transform: rotate(45deg);
  transform: rotate(45deg);
  z-index: 10001;
`;

const CustomBox = styled.div`
  box-sizing: border-box;
  border-radius: 4px;
  background-color: rgb(255, 255, 255);
  border: 0.0625rem solid #d9d9d9;
  border-radius: 1rem;
  left: 10%;
  top: calc(100% + 2px);
  position: absolute;
  padding: 0.75rem 0.75rem 0;
  min-height: 12rem;
  height: fit-content;
  max-width: 15rem;
  min-width: 12.5rem;
  text-align: left;
  transform: translateX(-50%);
  visibility: visible;
  width: 9rem;
  // will-change: transform, left;
  z-index: 998;
  outline: none;
  bottom: 1.875rem;
`;
const CheckWraper = styled.span`
  position: absolute;
  right: 15%;
`;

function Sort(props) {
  const [sortOptions, setSortOptions] = useState(props.existingSortOptions);
  const cleanUpEmitterFFlag = /true/i.test(getAssistedCradlePropertyV2(['cleanUpEmitterFFlag'])?.[0]);
  const timeoutManager = new TimeoutManager({ fileName: "Sort.js", enableFF: cleanUpEmitterFFlag });

  useEffect(() => {
    // Cleanup function to clear the timeout
    return () =>
    {
      timeoutManager.clearAllTimeouts();
    }
  }, []);

  const sortItemSelected = (value) => {
    const updateSelect = sortOptions.map((opt) => {
      if (opt.value === value) {
        return { ...opt, isSelected: true };
      }
      return { ...opt, isSelected: false };
    });
    setSortOptions(updateSelect);
    props.handleSortChange(value);
    timeoutManager.scheduleTimeout(() => {
      props.setShowSort(false);
    }, 350);
  };

  return (
    <>
          {!props?.is5GDevice && <CustomBoxArrow />}
      {!props?.is5GDevice && (
      <CustomBox data-testid='testSortGridwall'>
        {sortOptions.map((sortopt) => (
          <BottomBorder
            data-testid='sort-item'
            onClick={() => sortItemSelected(sortopt.value)}
            key={`${sortopt.value}_sort`}
          >
            <Body data-testid='testSortOption' size='large' key={sortopt.value}>
              {sortopt.label}
              {sortopt.isSelected && (
                <CheckWraper>
                  <Icon name='checkmark' color='#0077B4' size='medium' />
                </CheckWraper>
              )}
            </Body>
          </BottomBorder>
        ))}
      </CustomBox>
       )}
    </>
  );
}
export default Sort;
