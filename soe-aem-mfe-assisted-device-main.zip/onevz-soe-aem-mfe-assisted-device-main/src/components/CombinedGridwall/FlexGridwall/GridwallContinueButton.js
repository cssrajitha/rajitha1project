/* eslint-disable no-unused-expressions */
import styled from 'styled-components';
import { Button } from '@vds/buttons';
import { getUIContextPathBAU, getUrlName } from 'onevzsoemfecommon/Helpers';
import { useGetCustomerProfileQuery, useGetCartDetailsQuery } from 'onevzsoemfecommon/APIService';
import Emitter from 'onevzsoemfeframework/Emitter';
import { sendCustomEvent } from 'onevzsoemfeframework/Tagging';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { getQueryParamByName, isIndirect } from 'onevzsoemfeframework/DomService';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { isDWOSAllowed } from '../../FlexPDP/pdputils';
import WifiBackupDisclaimerModal from './WifiBackupDisclaimerModal';
// import GridwallButtonApiCallHook from './GridwallButtonAPIHook';

const ButtonWrapper = styled.div`
  padding: 1.5rem 0.5rem 1.5rem 0rem;
  margin-left: auto;
  display: flex;
`;
export const FlexAlignContainerItemsCenter = styled.div`
  display: flex;
  align-items: center !important;
  padding: 0 1rem 0 1rem;
`;

let navigate = '';
function useNavigateMFE() {
  navigate = useNavigate();
}

function GridwallHeader() {
  try {
    useNavigateMFE();
  } catch (e) {
    /* istanbul ignore next */
    console.log('');
  }

  const dwosIndirectFFlag = getAssistedCradlePropertyV2(['dwosIndirectFFlag'])[0] === 'TRUE';
  const cleanUpEmitterFFlag = /true/i.test(getAssistedCradlePropertyV2(['cleanUpEmitterFFlag'])?.[0]);
  
  const [byodCheck, setByodCheck] = useState(false);
  const [showWifibackupDisclaimer, setShowWifibackupDisclaimer] = useState(false);
  const [isDWOS, setIsDWOS] = useState(isDWOSAllowed(dwosIndirectFFlag, getQueryParamByName('isDWOS')));
  const isETRserviceOnly = /true/i.test(sessionStorage.getItem('isEtrServiceChangesFlow'));
  const isEtrServiceOnlyFlow =
    isETRserviceOnly && /true/i.test(getAssistedCradlePropertyV2(['flexFlowServiceChangeFFlag'])?.[0]);
  const isFromPlansTab = /true/i.test(getQueryParamByName('isPlanTabSelect'));

  const urlName = getUrlName(window.location.href);
  const skipOnProductDetials = isEtrServiceOnlyFlow && urlName === 'product-detail';

  const requestBodyCustomerProf = {
    enableAssistedTagging: true,
  };
  const requestBodyRetriveCart = {
    meta: {
      client: 'CXP',
    },
    data: {
      cartId: '',
      retrieveCurrentFeatures: true,
      isFloridaDiscountEnabled: true,
      adobeSubkey: sessionStorage.getItem('adobe-sessionId') || '',
    },
  };

  const CustomerProfileResult = useGetCustomerProfileQuery(
    {
      body: requestBodyCustomerProf,
    },
    { skip: !isEtrServiceOnlyFlow || skipOnProductDetials },
  );

  const CartDetailsResult = useGetCartDetailsQuery(
    { body: requestBodyRetriveCart },
    { skip: (!CustomerProfileResult?.isSuccess && !isEtrServiceOnlyFlow) || skipOnProductDetials },
  );

  const handleETRServiceChanges = () => {
    if (isEtrServiceOnlyFlow && isFromPlansTab && CustomerProfileResult?.data?.data && CartDetailsResult?.data?.data) {
      const activeMtn = getQueryParamByName('activeMtn');
      const mtns = CustomerProfileResult?.data?.data?.customer?.billAccounts?.[0]?.mtns;
      const mtn = mtns?.filter((line) => line?.mtn === activeMtn)?.[0];
      const profileDeviceId = mtn?.equipmentInfos?.[0]?.deviceInfo?.deviceId;
      const profileDeviceSku = mtn?.equipmentInfos?.[0]?.deviceInfo?.deviceSku;
      const profileSimId = mtn?.equipmentInfos?.[0]?.simInfo?.simId;

      const lineInfo = CartDetailsResult?.data?.data?.cart?.lineDetails?.lineInfo || [];
      const cartLineDetails = lineInfo?.find(
        (x) => x?.mobileNumber === activeMtn && x?.lineActivityType?.includes?.('BYOD'),
      );
      const byodCartItems = cartLineDetails?.itemsInfo?.[0]?.cartItems?.cartItem;

      const deviceIdFromCart = byodCartItems?.find((CartItem) => CartItem.cartItemType === 'DEVICE')?.deviceId || '';
      const deviceSkuFromCart = byodCartItems?.find((CartItem) => CartItem.cartItemType === 'DEVICE')?.sorId || '';
      const simItem = byodCartItems?.find((CartItem) => CartItem.cartItemType === 'SIM');
      let simIdFromCart = '';
      if (simItem?.simId) {
        simIdFromCart = simItem.simId;
      } else if (simItem?.itemCode) {
        simIdFromCart = simItem.itemCode;
      }
      const finalDeviceId = deviceIdFromCart?.length > 0 ? deviceIdFromCart : profileDeviceId;
      const finalSimId = simIdFromCart?.length > 0 ? simIdFromCart : profileSimId;
      const finalSku = deviceSkuFromCart?.length > 0 ? deviceSkuFromCart : profileDeviceSku;

      const refreshParam = `?etrServiceChanges=true&isByodUpdate=true&isEditAndView=true&isPlanTabSelect=true&activeMtn=${activeMtn}&deviceId=${finalDeviceId}&deviceSKU=${finalSku}&simId=${finalSimId}`;
      navigate(`${getUIContextPathBAU()}/combinedgridwall.html${refreshParam}`);
    }
  };

  useEffect(() => {
    handleETRServiceChanges();
  }, [CustomerProfileResult?.isSuccess, CartDetailsResult?.isSuccess]);

  useEffect(() => {
    const handleByodCheck = (newValue) => {
      if (newValue === true) {
        setByodCheck(true);
      } else {
        setByodCheck(false);
      }
    };
    const handleDwos = (value) => {
      /* istanbul ignore else */
      if (/true/i.test(dwosIndirectFFlag) && isIndirect()) {
        setIsDWOS(value);
      }
    };
    Emitter.on('ProspectBYODTile', handleByodCheck);
    Emitter.on('Update_dwos', handleDwos);
    return () => {
      cleanUpEmitterFFlag && Emitter.off('ProspectBYODTile', handleByodCheck);
      cleanUpEmitterFFlag && Emitter.off('Update_dwos', handleDwos);
    };
  }, []);

  const handleWifiBackupDisclaimer = () => {
    const showDisclaimerSessionValue = sessionStorage.getItem('showWifiDisclaimer') === 'TRUE';
    const vzdl = window?.vzdl || {};
    if (showDisclaimerSessionValue) {
      setShowWifibackupDisclaimer(true);
      if (vzdl?.event) vzdl.event.value = '';
      if (vzdl?.page) vzdl.page.detail = 'wifi backup modal';
      window.vzdl = vzdl;
      sendCustomEvent('openView', window?.vzdl);
    } else {
      handleContinue();
    }
  };

  const handleContinue = () => {
    console.log('Device MFE');
    const vzdl = window?.vzdl || {};
    if (vzdl?.page) vzdl.page.detail = '';
    window.vzdl = vzdl;
    sendCustomEvent('closeView', window?.vzdl);
    navigate(`${getUIContextPathBAU()}/landing.html?${isDWOS ? 'isDWOS=true' : ''}`);
  };
  const isSecondNumberFlow = getQueryParamByName('SecondNumber') || false;

  return (
    <>
      <ButtonWrapper data-testid='testContinueGridwall'>
        <Button
          data-testid='testContinueGridwallBtn'
          type='secondary'
          size='small'
          width='auto'
          surface='light'
          data-track='CombinedGridwall-Continue'
          onClick={handleWifiBackupDisclaimer}
          disabled={byodCheck || isSecondNumberFlow}
        >
          Continue
        </Button>
      </ButtonWrapper>
        <WifiBackupDisclaimerModal
          showWifibackupDisclaimer={showWifibackupDisclaimer}
          handleWifiBackupDisclaimer={setShowWifibackupDisclaimer}
          handleContinue={handleContinue}
        />
    </>
  );
}
export default GridwallHeader;
