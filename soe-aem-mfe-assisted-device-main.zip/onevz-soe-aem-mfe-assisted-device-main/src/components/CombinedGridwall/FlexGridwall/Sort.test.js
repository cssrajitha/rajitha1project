import React from 'react';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import { fireEvent, render, screen } from '../../../modules/test-utils/renderHelper';
import Sort from './Sort';

describe('Header component render', () => {
  const props = {
    existingSortOptions: [{ isSelected: true }],
    handleSortChange: jest.fn().mockName('handleSortChange'),
    setShowSort: jest.fn().mockName('setShowSort'),
    sortItemSelected: jest.fn().mockName('sortItemSelected'),
    sortOption: [
      {
        label: 'Price Low To High',
        value: 'product_min_fullRetailPrice_f asc',
        isSelected: false,
      },
      {
        label: 'Price High To Low',
        value: 'product_min_fullRetailPrice_f desc',
        isSelected: false,
      },
      {
        label: 'Customer Rating',
        value: 'product_average_rating_f desc',
        isSelected: false,
      },
      {
        label: 'Featured',
        value: '',
        isSelected: true,
      },
    ],
  };
  beforeEach(() => {
    render(<Sort {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('component should render', () => {
    const text = screen.getByTestId('testSortGridwall');
    expect(text).toBeInTheDocument();
    fireEvent.click(text);
  });

  test('component should render with sort data', async () => {
    const text = screen.getByTestId('sort-item');
    expect(text).toBeInTheDocument();
    fireEvent.click(text);
    await new Promise((res) => {
      setTimeout(res, 500);
    });
  });
});
describe('Header component render', () => {
  const props = {
    existingSortOptions: [{ isSelected: true }],
    handleSortChange: jest.fn().mockName('handleSortChange'),
    setShowSort: jest.fn().mockName('setShowSort'),
    sortItemSelected: jest.fn().mockName('sortItemSelected'),
    sortOption: [
      {
        label: 'Price Low To High',
        value: 'product_min_fullRetailPrice_f asc',
        isSelected: false,
      },
      {
        label: 'Price High To Low',
        value: 'product_min_fullRetailPrice_f desc',
        isSelected: false,
      },
      {
        label: 'Customer Rating',
        value: 'product_average_rating_f desc',
        isSelected: false,
      },
      {
        label: 'Featured',
        value: '',
        isSelected: true,
      },
    ],
    is5GDevice: false,
  };
  beforeEach(() => {
    render(<Sort {...props} />, { reducers: rootReducer, sagas: rootSaga });
  });
  test('component should render', () => {
    const text = screen.getByTestId('testSortOption');
    expect(text).toBeInTheDocument();
  });
});
