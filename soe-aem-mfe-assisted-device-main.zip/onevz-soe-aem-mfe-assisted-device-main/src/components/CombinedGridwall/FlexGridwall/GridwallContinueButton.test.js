import React from 'react';
import Emitter from 'onevzsoemfeframework/Emitter';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import { render, screen, fireEvent } from '../../../modules/test-utils/renderHelper';
import GridwallHeader from './GridwallContinueButton';

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradleProperty: () => ['TRUE'],
    getAssistedCradlePropertyV2: () => ['TRUE'],
  }),
  { virtual: true },
);

jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    isIndirect: () => true,
  }),
  { virtual: true },
);

describe('GridwallHeader component - New Customer', () => {
  const handleBackNavigation = jest.fn().mockName('handleBackNavigation');
  const handleContinue = jest.fn().mockName('handleContinue');
  beforeEach(() => {
    window.history.pushState({}, 'Gridwall', '/sales/assisted/new/gridwall.html?fromPromotions=true');

    jest.spyOn(console, 'error');
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockImplementation(() => null);

    render(<GridwallHeader handleBackNavigation={handleBackNavigation} handleContinue={handleContinue} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  it('should click continue button', () => {
    Emitter.emit('ProspectBYODTile', true);
    Emitter.emit('Update_dwos', true);
    const testContinueGridwall = screen.getByTestId('testContinueGridwall');
    expect(testContinueGridwall).toBeInTheDocument();
    const testContinueGridwallBtn = screen.getByTestId('testContinueGridwallBtn');
    expect(testContinueGridwallBtn).toBeInTheDocument();
    fireEvent.click(testContinueGridwallBtn);
  });

  afterAll(() => {
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockRestore();
  });
});
describe('GridwallHeader component - Existing Customer', () => {
  const handleBackNavigation = jest.fn().mockName('handleBackNavigation');
  const handleContinue = jest.fn().mockName('handleContinue');
  beforeEach(() => {
    Emitter.emit('ProspectBYODTile', false);
    window.history.pushState({}, 'Gridwall', '/sales/assisted/new/gridwall.html');
    jest.spyOn(console, 'error');
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockImplementation(() => null);

    render(<GridwallHeader handleBackNavigation={handleBackNavigation} handleContinue={handleContinue} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  it('should click continue button', () => {
    Emitter.emit('ProspectBYODTile', false);
    const testContinueGridwall = screen.getByTestId('testContinueGridwall');
    expect(testContinueGridwall).toBeInTheDocument();
    fireEvent.click(testContinueGridwall);
  });

  afterAll(() => {
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockRestore();
  });
});
