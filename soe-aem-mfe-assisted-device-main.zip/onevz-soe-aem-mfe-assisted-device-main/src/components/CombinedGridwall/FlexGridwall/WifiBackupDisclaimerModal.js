import React from 'react';
import { Modal, ModalBody, ModalTitle } from '@vds/modals';
import styled from 'styled-components';
import { GetAppConfig } from 'onevzsoemfeframework/GetAppConfig';
import { Button } from '@vds/buttons';

const SpacingDiv = styled.div`
  margin-top: 10px;
`;

const GroupButtons = styled.div`
  margin-top: 20px;
  display: flex;
  flex-direction: column;
`;
export default function WifiBackupDisclaimerModal(props) {
  const appConfig = GetAppConfig();

  return (
    <div id='wifi-disclaimer-modal' data-testid='wifi-disclaimer-modal'>
      <Modal
        className='wifi-disclaimer-modal'
        closeButtonId="close"
        opened={props?.showWifibackupDisclaimer}
        hideCloseButton={false}
        disableOutsideClick
        onOpenedChange={(opened) => {
          if (!opened) {
            props?.handleWifiBackupDisclaimer(false);
          }
        }}
      >
        <ModalTitle primitive='h6'>{appConfig?.messages?.wifiBackupAcknowledgment?.subtitle}</ModalTitle>
        <ModalBody>
          {appConfig?.messages?.wifiBackupAcknowledgment?.points?.map((point) => (
            <li>{point}</li>
          ))}
          <GroupButtons>
            <Button
              size='large'
              surface='light'
              disabled={false}
              use='primary'
              data-testid='wifi-disclaimer-modal-continue'
              onClick={() => props?.handleContinue()}
            >
              {appConfig?.messages?.wifiBackupAcknowledgment?.buttons?.proceed}
            </Button>
            <SpacingDiv />
            <Button
              size='large'
              surface='light'
              disabled={false}
              use='secondary'
              data-testid='wifi-disclaimer-modal-cancel'
              onClick={() => props?.handleWifiBackupDisclaimer(false)}
            >
              {appConfig?.messages?.wifiBackupAcknowledgment?.buttons?.cancel}
            </Button>
          </GroupButtons>
        </ModalBody>
      </Modal>
    </div>
  );
}
