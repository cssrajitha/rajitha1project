import React from 'react';
import { isVbg } from 'onevzsoemfeframework/VbgAemUtil';
import { render, screen } from '../../../modules/test-utils/renderHelper';
import * as filters from '../__mocks__/mockFilterData';
import Filter from './Filter';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';

jest.mock('onevzsoemfeframework/VbgAemUtil', () => ({
  __esModule: true,
  ...jest.requireActual('onevzsoemfeframework/VbgAemUtil'),
  isVbg: jest.fn(),
}));

describe('Filter component', () => {
  const handleCategoryChange = jest.fn().mockName('handleCategoryChange');
  const handleBrandChange = jest.fn().mockName('handleBrandChange');
  const handleOSChange = jest.fn().mockName('handleOSChange');
  const handleSortChange = jest.fn().mockName('handleSortChange');
  const handleResetChange = jest.fn().mockName('handleResetChange');
  const resetDevices = jest.fn().mockName('handleCategoryChange');
  beforeEach(() => {
    jest.spyOn(console, 'error');
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockImplementation(() => null);

    render(
      <Filter
        brandName={filters.brandName}
        brandValue=''
        categories={filters.categories}
        categoryValue={filters.categories[2].label}
        osName={filters.osName}
        osValue=''
        sortValue=''
        existingSortOptions={filters.sortOption}
        handleCategoryChange={handleCategoryChange}
        handleBrandChange={handleBrandChange}
        handleOSChange={handleOSChange}
        handleSortChange={handleSortChange}
        handleResetChange={handleResetChange}
        resetDevices={resetDevices}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });

  it('should mount Filter component', () => {
    const filterWrapper = screen.getByTestId('filterWrapper');
    expect(filterWrapper).toBeInTheDocument();
  });

  it('should mount category, brand, os filter and reset link', () => {
    const testCategoryFilter = screen.getByTestId('testCategoryFilter');
    const testBrandFilter = screen.getByTestId('testBrandFilter');
    const testOsFilter = screen.getByTestId('testOsFilter');
    const testResetLink = screen.getByTestId('testResetLink');

    expect(testCategoryFilter).toBeInTheDocument();
    expect(testBrandFilter).toBeInTheDocument();
    expect(testOsFilter).toBeInTheDocument();
    expect(testResetLink).toBeInTheDocument();
  });

  it('should category filter have Smartphones', () => {
    expect(screen.getByText('Smartphones')).toBeInTheDocument();
  });

  afterAll(() => {
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockRestore();
  });
});

describe('Filter component', () => {
  const handleCategoryChange = jest.fn().mockName('handleCategoryChange');
  const handleBrandChange = jest.fn().mockName('handleBrandChange');
  const handleOSChange = jest.fn().mockName('handleOSChange');
  const handleSortChange = jest.fn().mockName('handleSortChange');
  const handleResetChange = jest.fn().mockName('handleResetChange');
  const resetDevices = jest.fn().mockName('handleCategoryChange');
  beforeEach(() => {
    jest.spyOn(console, 'error');
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockImplementation(() => null);

    render(
      <Filter
        brandName={filters.brandName}
        brandValue=''
        categories={filters.categories}
        categoryValue={filters.categories[2].label}
        osName={filters.osName}
        osValue=''
        sortValue=''
        is5GDevice
        existingSortOptions={filters.sortOption}
        handleCategoryChange={handleCategoryChange}
        handleBrandChange={handleBrandChange}
        handleOSChange={handleOSChange}
        handleSortChange={handleSortChange}
        handleResetChange={handleResetChange}
        resetDevices={resetDevices}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });

  it('should mount Filter component', () => {
    const filterWrapper = screen.getByTestId('filterWrapper');
    expect(filterWrapper).toBeInTheDocument();
  });
  afterAll(() => {
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockRestore();
  });
});
describe('Filter component', () => {
  const handleCategoryChange = jest.fn().mockName('handleCategoryChange');
  const handleBrandChange = jest.fn().mockName('handleBrandChange');
  const handleOSChange = jest.fn().mockName('handleOSChange');
  const handleSortChange = jest.fn().mockName('handleSortChange');
  const handleResetChange = jest.fn().mockName('handleResetChange');
  const resetDevices = jest.fn().mockName('handleCategoryChange');
  beforeEach(() => {
    jest.spyOn(console, 'error');
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockImplementation(() => null);
    isVbg.mockReturnValue(true);
    render(
      <Filter
        brandName={filters.brandName}
        brandValue=''
        categories={filters.categories}
        categoryValue={filters.categories[2].label}
        osName={filters.osName}
        osValue=''
        sortValue=''
        is5GDevice
        existingSortOptions={filters.sortOption}
        handleCategoryChange={handleCategoryChange}
        handleBrandChange={handleBrandChange}
        handleOSChange={handleOSChange}
        handleSortChange={handleSortChange}
        handleResetChange={handleResetChange}
        resetDevices={resetDevices}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });

  it('should mount Filter component', () => {
    const filterWrapper = screen.getByTestId('filterWrapper');
    expect(filterWrapper).toBeInTheDocument();
  });
  afterAll(() => {
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockRestore();
  });
});
