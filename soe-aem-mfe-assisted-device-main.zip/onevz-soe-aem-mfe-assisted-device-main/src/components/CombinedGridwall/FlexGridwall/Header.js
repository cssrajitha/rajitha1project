/* eslint-disable jsx-a11y/no-static-element-interactions */

import { useState, useRef, useEffect } from 'react';
import { Icon } from '@vds/icons';
import { Body } from '@vds/typography';
import { Toggle } from '@vds/toggles';
import styled from 'styled-components';
import { Tooltip } from '@vds/tooltips';
import { isRetail, isD2D, isIndirect } from 'onevzsoemfeframework/DomService';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { PaddingTopBottom16, FlexBox, PaddingLeft12 } from '../FlexGlobalStyledConstants';
import Search from './Search';
import Sort from './Sort';
import ProductScan from '../ProductScan/ProductScan';

const Wrapper = styled.div`
  display: flex;
  justify-content: space-between;
  padding-top: 1rem;
`;
const IconWrapper = styled.div`
  display: flex;
  gap: 1.2rem;
  right: 1rem;
  position: relative;
  span {
    cursor: pointer;
  }
`;
const BadgeDiv = styled.div`
  display: inline-flex;
  text-overflow: ellipsis;
  background-color: #0077b4;
  color: #ffffff;
  border-radius: 4px;
  align-items: center;
  padding: 2px 0.25rem;
`;
const TooltipWrapper = styled.div`
  display: flex;
  padding-right: 0.25rem;
`;
const SwitchIconWrap = styled.div`
  transform: rotate(90deg);
`;
const BarCodeContainer = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: flex-end;
  margin-top: 0.5rem;
`;
const Container = styled.div`
  position: relative;
  .scanBtn {
    cursor: pointer;
  }
`;
const BlankDiv = styled.div`
  display: inline-flex;
  text-overflow: ellipsis;
  color: #ffffff;
  border-radius: 4px;
  align-items: center;
  padding: 2px 0.5rem;
`;

function Header(props) {
  const [showSearchResults, setShowSearchResults] = useState(false);
  const [showNoResults, setShowNoResults] = useState(false);
  const [showSort, setShowSort] = useState(false);
  const [toggleBarcode, setToggleBarcode] = useState(false);
  const {
    offerMessage,
    toggle,
    showToogle,
    sortValue,
    existingSortOptions,
    handleSortChange,
    handleToggleState,
    onSearchTxtChange,
    onAutoCompleteItemSkuSearch,
    getSkuList,
    deviceCategory,
    selectedTab,
    offerSourceSystem,
    isOffersStacked,
    propositionMessage,
    isDWOS,
    offerSubType,
    intentCheck,
    totalLines,
    activeMtn,
    validateDeviceSimIdRequest,
    is5GDevice,
    setToggle,
    isSecondNumberPlan,
    cartDetails,
    CustomerData: customerData,
    // TakeOverScreenFunc,
    productTypeForSearch,
  } = props;
  const menuRef = useRef();
  const [hideScanIconInGridwallFor5GFFlag, bestBuyUpcImeiCheckFFlag, bestBuyIntegrationFFlag] =
    getAssistedCradlePropertyV2([
      'hideScanIconInGridwallFor5GFFlag',
      'bestBuyUpcImeiCheckFFlag',
      'bestBuyIntegrationFFlag',
    ]);

  useEffect(() => {
    const handler = (e) => {
      if (!menuRef?.current?.contains(e.target)) {
        setShowSort(false);
        setShowSearchResults(false);
        setShowNoResults(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => {
      document.removeEventListener('mousedown', handler);
    };
  }, []);

  const switchIconClicked = () => {
    setShowNoResults(false);
    setShowSearchResults(false);
    setShowSort(!showSort);
  };

  const handleBarcodeClick = () => {
    setToggleBarcode(!toggleBarcode);
  };

  /**
   * whether to show or hide scan icon for indirect channel
   * @returns boolean (true/false)
   */
  // for indirect always show scan icon as retail, so removing condition
  const showScanIconForIndirect = () => isIndirect();

  /**
   * Determines whether to show or hide the scan icon.
   *
   * @returns {boolean} True if the scan icon should be shown, false otherwise.
   */
  const showOrHideScanIcon = () => {
    const channelData = sessionStorage.getItem('channel');
    if (
      (hideScanIconInGridwallFor5GFFlag === 'TRUE' && is5GDevice) ||
      (bestBuyIntegrationFFlag === 'TRUE' && (!/indirect/i.test(channelData) || !isIndirect()))
    ) {
      return false;
    }
    if ((isRetail() || showScanIconForIndirect()) && !isD2D() && !isSecondNumberPlan) {
      return true;
    }
  };

  const offerSourceCheck =
    offerSourceSystem?.toLowerCase().includes('national') || offerSourceSystem?.toLowerCase().includes('prospect');

  const showEligibleToggle =
    !isDWOS &&
    !is5GDevice &&
    showToogle &&
    offerSourceCheck &&
    offerSubType !== 'BYOD' &&
    !props?.rebeaBYODCheck &&
    intentCheck &&
    !isOffersStacked;

  return (
    <Container data-testid='header'>
      <PaddingTopBottom16 id='tooltipParent'>
        {(!isDWOS && offerMessage && offerSourceCheck && (
          <BadgeDiv fillColor='blue'>
            <Body primitive='span' size='small' color='#ffffff' bold>
              {isOffersStacked ? 'Offer' : `Offer: ${offerMessage}`}
            </Body>

            {propositionMessage && !isOffersStacked && (
              <TooltipWrapper>
                <Tooltip title='Offer Description' size='small' iconFillColor='#FFFFFF' containerId='tooltipParent'>
                  {propositionMessage}
                </Tooltip>
              </TooltipWrapper>
            )}
          </BadgeDiv>
        )) || <BlankDiv />}
      </PaddingTopBottom16>
      <Wrapper>
        <FlexBox>
          {showEligibleToggle && (
            <>
              <Body size='large'>Eligible {deviceCategory || 'device'} for this offer</Body>
              <PaddingLeft12>
                <div data-testid='offereligibletoggle'>
                  <Toggle
                    disabled={false}
                    showText={false}
                    value='default'
                    onChange={handleToggleState}
                    on={toggle}
                    data-track={`CombinedGridwall-OfferToggle-${toggle ? 'off' : 'on'}`}
                  />
                </div>
              </PaddingLeft12>
            </>
          )}
        </FlexBox>

        <IconWrapper ref={menuRef}>
          <Search
            onSearchTxtChange={onSearchTxtChange}
            onCancelSearchInput={() => onSearchTxtChange('')}
            onAutoCompleteItemSkuSearch={onAutoCompleteItemSkuSearch}
            path=''
            getSkuList={getSkuList}
            is5GDevice={is5GDevice}
            selectedTab={selectedTab}
            searchStrValue=''
            setShowSearchResults={setShowSearchResults}
            showSearchResults={showSearchResults}
            showNoResults={showNoResults}
            setShowNoResults={setShowNoResults}
            setToggle={setToggle}
            productTypeForSearch={productTypeForSearch}
            cartDetails={cartDetails}
            customerData={customerData}
            activeMtn={activeMtn}
          />
          {showOrHideScanIcon() && (
            <span data-testid='testScanBtn' onClick={handleBarcodeClick} onKeyPress={() => handleBarcodeClick()}>
              <Icon color={toggleBarcode ? '#0096E4' : '#000000'} name='barcode' size='XLarge' />
            </span>
          )}
          <SwitchIconWrap onClick={switchIconClicked}>
            <Icon name='switch' />
          </SwitchIconWrap>
          {showSort && (
            <Sort
              setShowSort={setShowSort}
              sortValue={sortValue}
              existingSortOptions={existingSortOptions}
              handleSortChange={handleSortChange}
              is5GDevice={is5GDevice}
            />
          )}
        </IconWrapper>
      </Wrapper>
      {toggleBarcode && (
        <BarCodeContainer>
          <ProductScan
            toggleBarcode={toggleBarcode}
            totalLines={totalLines}
            mtn={activeMtn}
            validateDeviceSimIdRequest={validateDeviceSimIdRequest}
            ScanFromLanding
            fromCpe={false}
            bestBuyUpcImeiCheckFFlag={bestBuyUpcImeiCheckFFlag}
            showScanner
            isCustomerProvidedEquipment={false}
            setUpcCode={props?.setUpcCode}
          />
        </BarCodeContainer>
      )}
    </Container>
  );
}

export default Header;
