import React from 'react';
import Emitter from 'onevzsoemfeframework/Emitter';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import { render, screen, fireEvent } from '../../../modules/test-utils/renderHelper';
import GridwallHeader from './GridwallContinueButton';

jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/DomService'),
    getQueryParamByName: (value) => {
      if (value === 'aal') {
        return 'Y';
      }
      if (value === 'isDWOS') {
        return 'true';
      }
      return null;
    },
    isProd: jest.fn(),
    isIndirect: () => true,
    isIpad: jest.fn(),
  }),
  { virtual: true }
);

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getAssistedCradleProperty: () => ['TRUE'],
    getAssistedCradlePropertyV2: () => ['TRUE'],
  }),
  { virtual: true }
);
describe('GridwallHeader component - Existing Customer', () => {
  const handleBackNavigation = jest.fn().mockName('handleBackNavigation');
  const handleContinue = jest.fn().mockName('handleContinue');
  beforeEach(() => {
    Emitter.emit('Update_dwos', true);
    window.history.pushState({}, 'Gridwall', '/sales/assisted/new/gridwall.html');
    jest.spyOn(console, 'error');
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockImplementation(() => null);

    render(<GridwallHeader handleBackNavigation={handleBackNavigation} handleContinue={handleContinue} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  it('should click continue button', () => {
    Emitter.emit('Update_dwos', true);
    const testContinueGridwall = screen.getByTestId('testContinueGridwallBtn');
    expect(testContinueGridwall).toBeInTheDocument();
    fireEvent.click(testContinueGridwall);
  });

  afterAll(() => {
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockRestore();
  });
});
describe('GridwallHeader component - Existing Customer Wifibackup disclaimer', () => {
  const handleBackNavigation = jest.fn().mockName('handleBackNavigation');
  const handleContinue = jest.fn().mockName('handleContinue');
  beforeEach(() => {
    Emitter.emit('Update_dwos', true);
    window.history.pushState({}, 'Gridwall', '/sales/assisted/new/gridwall.html');
    jest.spyOn(console, 'error');
    sessionStorage.setItem('showWifiDisclaimer', 'TRUE');
	//  const vzdl = window?.vzdl || {};
    //  vzdl.page = {
    //    detail: "",
    //  };

		
	
    // if(vzdl?.page) vzdl.page.detail ='wifi backup modal';
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockImplementation(() => null);

    render(<GridwallHeader handleBackNavigation={handleBackNavigation} handleContinue={handleContinue} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  it('should click continue button', () => {
    Emitter.emit('Update_dwos', true);
    const testContinueGridwall = screen.getByTestId('testContinueGridwallBtn');
    expect(testContinueGridwall).toBeInTheDocument();
    fireEvent.click(testContinueGridwall);
  });

  afterAll(() => {
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockRestore();
  });
});

describe('GridwallHeader component - Existing Customer Wifibackup disclaimer vzdl empty', () => {
  const handleBackNavigation = jest.fn().mockName('handleBackNavigation');
  const handleContinue = jest.fn().mockName('handleContinue');
  beforeEach(() => {
    Emitter.emit('Update_dwos', true);
    window.history.pushState({}, 'Gridwall', '/sales/assisted/new/gridwall.html');
    jest.spyOn(console, 'error');
    sessionStorage.setItem('showWifiDisclaimer', 'TRUE');
      const vzdl = {};
     expect(vzdl).toEqual({});
     vzdl.name = {
       detail: "",
     };
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockImplementation(() => null);

    render(<GridwallHeader handleBackNavigation={handleBackNavigation} handleContinue={handleContinue} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  it('should click continue button', () => {
    Emitter.emit('Update_dwos', true);
    const testContinueGridwall = screen.getByTestId('testContinueGridwallBtn');
    expect(testContinueGridwall).toBeInTheDocument();
    fireEvent.click(testContinueGridwall);
  });

  afterAll(() => {
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockRestore();
  });
});

describe('GridwallHeader component - Existing Customer Wifibackup disclaimer vzdl', () => {
  const handleBackNavigation = jest.fn().mockName('handleBackNavigation');
  const handleContinue = jest.fn().mockName('handleContinue');
  beforeEach(() => {
    Emitter.emit('Update_dwos', true);
    window.history.pushState({}, 'Gridwall', '/sales/assisted/new/gridwall.html');
    jest.spyOn(console, 'error');
    sessionStorage.setItem('showWifiDisclaimer', 'TRUE');
	 const vzdl = window?.vzdl;
     vzdl.page = {
       detail: "",
     };
	
    if(vzdl?.page) vzdl.page.detail ='wifi backup modal';
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockImplementation(() => null);

    render(<GridwallHeader handleBackNavigation={handleBackNavigation} handleContinue={handleContinue} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  it('should click continue button', () => {
    Emitter.emit('Update_dwos', true);
    const testContinueGridwall = screen.getByTestId('testContinueGridwallBtn');
    expect(testContinueGridwall).toBeInTheDocument();
    fireEvent.click(testContinueGridwall);
  });

  afterAll(() => {
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockRestore();
  });
});

describe('GridwallHeader component - Existing Customer Wifibackup disclaimer vzdl value', () => {
  const handleBackNavigation = jest.fn().mockName('handleBackNavigation');
  const handleContinue = jest.fn().mockName('handleContinue');
  beforeEach(() => {
    Emitter.emit('Update_dwos', true);
    window.history.pushState({}, 'Gridwall', '/sales/assisted/new/gridwall.html');
    jest.spyOn(console, 'error');
    sessionStorage.setItem('showWifiDisclaimer', 'TRUE');
	 const vzdl = window?.vzdl;
     vzdl.event = {
       value: "some value",
     };

    if(vzdl?.event) vzdl.event.value ='';
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockImplementation(() => null);

    render(<GridwallHeader handleBackNavigation={handleBackNavigation} handleContinue={handleContinue} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  it('should click continue button', () => {
    Emitter.emit('Update_dwos', true);
    const testContinueGridwall = screen.getByTestId('testContinueGridwallBtn');
    expect(testContinueGridwall).toBeInTheDocument();
    fireEvent.click(testContinueGridwall);
  });

  afterAll(() => {
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockRestore();
  });
});


