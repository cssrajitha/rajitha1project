import { GetAppConfig } from 'onevzsoemfeframework/GetAppConfig';
import WifiBackupDisclaimerModal from './WifiBackupDisclaimerModal';
import { screen, fireEvent, render } from '../../../modules/test-utils/renderHelper';

jest.mock('onevzsoemfeframework/GetAppConfig', () => ({ GetAppConfig: jest.fn() }));

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getAssistedCradleProperty: (keys) => keys.map(() => undefined),
  }),
  { virtual: true },
);
const appConfigWifibackup = {
  messages: {
    wifiBackupAcknowledgment: {
      subtitle: 'Important Information',
      points: ['Point 1: This is the first important point.', 'Point 2: This is the second important point.'],
      buttons: {
        proceed: 'Continue',
        cancel: 'Cancel',
      },
    },
  },
};

const intialMocks = () => {
  GetAppConfig.mockReturnValue(appConfigWifibackup);
};

describe(`<WifiBackupDisclaimerModal component thunder plans 1`, () => {
  const handleWifiBackupDisclaimer = jest.fn().mockName('handleWifiBackupDisclaimer');
  const handleContinue = jest.fn().mockName('handleContinue');
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  beforeEach(() => {
    intialMocks();
    render(
      <WifiBackupDisclaimerModal
        showWifibackupDisclaimer
        handleWifiBackupDisclaimer={handleWifiBackupDisclaimer}
        handleContinue={handleContinue}
      />,
      // { reducers: rootReducer, sagas: rootSaga }
    );
  });
  test('component should mount', async () => {
    const btn = await screen.getByTestId('modal-close-button');
    expect(btn).toBeInTheDocument();
    fireEvent.click(btn);
  });

  test('component should mount', async () => {
    const btn = await screen.getByTestId('wifi-disclaimer-modal-continue');
    expect(btn).toBeInTheDocument();
    fireEvent.click(btn);
  });

  test('component should mount', async () => {
    const btn = await screen.getByTestId('wifi-disclaimer-modal-cancel');
    expect(btn).toBeInTheDocument();
    fireEvent.click(btn);
  });
});
