import styled from 'styled-components';
import { Title } from '@vds/typography';
import { Icon } from '@vds/icons';
import { Line } from '@vds/lines';
import { Button } from '@vds/buttons';
import { getUIContextPathBAU, getQueryParamByName } from 'onevzsoemfecommon/Helpers';
import Emitter from 'onevzsoemfeframework/Emitter';
import { getAssistedCradlePropertyV2  } from 'onevzsoemfeframework/AssistedCradleService';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { BackClickable } from '../FlexGlobalStyledConstants';

const ShopWrapper = styled.div`
  padding: 1.5rem 0.5rem 1.5rem 0rem;
`;
const ButtonWrapper = styled.div`
  padding: 1.5rem 0.5rem 1.5rem 0rem;
  margin-left: auto;
  display: flex;
`;
export const FlexAlignContainerItemsCenter = styled.div`
  display: flex;
  align-items: center !important;
  padding: 0 1rem 0 1rem;
`;

function GridwallHeader(props) {
  const navigate = useNavigate();
  const [byodCheck, setByodCheck] = useState(false);
  const cleanUpEmitterFFlag = /true/i.test(getAssistedCradlePropertyV2(['cleanUpEmitterFFlag'])?.[0]);

  useEffect(() => {
    const handleByodCheck = (newValue) => {
      const SecNumFlow = Boolean(getQueryParamByName('SecondNumber')) || false;
      if (newValue === true || SecNumFlow) {
        setByodCheck(true);
      } else {
        setByodCheck(false);
      }
    };
    Emitter.on('ProspectBYODTile', handleByodCheck);
    return () => {
      cleanUpEmitterFFlag && Emitter.off('ProspectBYODTile', handleByodCheck);
    };
  }, []);
  const goBack = () => {
    const fromPromotions = getQueryParamByName('fromPromotions');
    if (fromPromotions) {
      navigate(`${getUIContextPathBAU()}/promotions.html`);
    } else {
      navigate(`${getUIContextPathBAU()}/landing.html`);
    }
    sessionStorage.setItem('isFromBack', true);
    sessionStorage.setItem('isSecondNumLocal', false);
  };

  const handleContinue = () => {
    navigate(`${getUIContextPathBAU()}/landing.html`);
  };

  return (
    <>
      <FlexAlignContainerItemsCenter data-testid='testGridwallHeader'>
        <BackClickable data-testid='testBackGridwall' onClick={goBack} data-track='CombinedGridwall-BackIcon'>
          <Icon name='left-caret' size='XLarge' medium='true' />
        </BackClickable>
        <ShopWrapper>
          <Title size='small' bold primitive='h1'>
            {props?.title ?? 'Shop devices'}
          </Title>
        </ShopWrapper>
        <ButtonWrapper data-testid='testContinueGridwall' onClick={handleContinue}>
          <Button
            type='secondary'
            size='small'
            width='auto'
            surface='light'
            data-track='CombinedGridwall-Continue'
            disabled={byodCheck}
          >
            {props?.button?.text ?? 'Continue'}
          </Button>
        </ButtonWrapper>
      </FlexAlignContainerItemsCenter>
      <Line type='secondary' />
    </>
  );
}
export default GridwallHeader;
