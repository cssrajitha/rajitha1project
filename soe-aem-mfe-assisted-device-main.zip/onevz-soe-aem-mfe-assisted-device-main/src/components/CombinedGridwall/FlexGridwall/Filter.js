import { DropdownSelect } from '@vds/selects';
import { TextLink } from '@vds/buttons';
import styled from 'styled-components';
import { isEmpty } from 'lodash';
import { isVbg } from 'onevzsoemfeframework/VbgAemUtil';
import { PaddingLeft12 } from '../FlexGlobalStyledConstants';
import categoryDropdown from '../Tiles/categoryDropdown.json';

const FilterWrapper = styled.div`
  padding: 1rem;
  background: #f6f6f6;
  border-radius: 8px;
  margin-top: 1rem;
  display: flex;
  flex-direction: row;
  align-items: center;
`;
const ResetElement = styled.div`
  padding: 1rem 0 0 1rem;
`;

function Filter(props) {
  const {
    brandName,
    brandValue,
    categories,
    categoryValue,
    osName,
    osValue,
    handleCategoryChange,
    handleBrandChange,
    handleOSChange,
    resetDevices,
    is5GDevice,
    refinementOptions,
    brandOptions,
    OSOptions,
  } = props;

  // Mock data for Dropdowns
  const refinementsData = categoryDropdown?.data?.gridWall?.refinements;
  const CategoryData = refinementsData && refinementsData?.filter((data) => data.refinementName === 'Category');

  const categoryValues =
    CategoryData &&
    CategoryData[0].refinementOptions.map((cat) => ({
      label: cat.displayName,
      value: cat.displayName,
    }));

  const categoriesAvailable = isEmpty(refinementOptions);
  const categoryDropdownOption = !categoriesAvailable ? categories : categoryValues;

  const brandRefinementsData = categoryDropdown?.branddata?.gridWall?.refinements;
  const brandData = brandRefinementsData && brandRefinementsData?.filter((data) => data.refinementName === 'Brand');
  const brandValues =
    brandData &&
    brandData[0].refinementOptions.map((brand) => ({
      label: brand.displayName,
      value: brand.displayName,
    }));
  const brandAvailable = isEmpty(brandOptions);
  const brandDropdownOption = !brandAvailable ? brandName : brandValues;

  const osRefinementsData = categoryDropdown?.osdata?.gridWall?.refinements;
  const osData = osRefinementsData && osRefinementsData?.filter((data) => data.refinementName === 'OS');
  const OSValues =
    osData &&
    osData[0].refinementOptions.map((os) => ({
      label: os.displayName,
      value: os.displayName,
    }));
  const osAvailable = isEmpty(OSOptions);
  const osDropdownOption = !osAvailable ? osName : OSValues;
  const vbg5GDevice = isVbg() && is5GDevice;
  const fwaCategory = vbg5GDevice ? '5G Internet' : '5G Home Internet';
  return (
    <FilterWrapper data-testid='filterWrapper'>
      <DropdownSelect
        data-testid='testCategoryFilter'
        label='Category'
        errorText='Select a category'
        error={false}
        disabled={false}
        readOnly={is5GDevice}
        inlineLabel={false}
        width='212px'
        value={categoryValue}
        onChange={handleCategoryChange}
      >
        {categoryDropdownOption &&
          categoryDropdownOption.map((category) => (
            <option
              key={category.value}
              value={category.value}
              data-track={`${`Gridwall-Filter-Category-${category.value}`}`}
            >
              {is5GDevice ? fwaCategory : category.label}{' '}
            </option>
          ))}
      </DropdownSelect>
      <PaddingLeft12>
        <DropdownSelect
          data-testid='testBrandFilter'
          label='Brand'
          errorText='Select a brand'
          error={false}
          disabled={false}
          readOnly={is5GDevice}
          inlineLabel={false}
          width='163px'
          value={brandValue}
          onChange={handleBrandChange}
        >
          {brandDropdownOption &&
            brandDropdownOption.map((brand) => (
              <option key={brand.value} value={brand.value} data-track={`Gridwall_Brand_${brand?.value}`}>
                {brand.label}{' '}
              </option>
            ))}
        </DropdownSelect>
      </PaddingLeft12>
      {!vbg5GDevice && (
        <PaddingLeft12>
          <DropdownSelect
            data-testid='testOsFilter'
            label='OS'
            errorText='Select a os'
            error={false}
            disabled={false}
            readOnly={is5GDevice}
            inlineLabel={false}
            width='137px'
            value={osValue}
            onChange={handleOSChange}
          >
            {osDropdownOption &&
              osDropdownOption.map((os) => (
                <option key={os.value} value={os.value} data-track={`Gridwall_Brand_${os?.value}`}>
                  {os.label}{' '}
                </option>
              ))}
          </DropdownSelect>
        </PaddingLeft12>
      )}
      <ResetElement>
        <TextLink
          data-testid='testResetLink'
          disabled={is5GDevice}
          type='standAlone'
          onClick={resetDevices}
          data-track='Gridwall-Filter-Reset'
        >
          Reset
        </TextLink>
      </ResetElement>
    </FilterWrapper>
  );
}

export default Filter;
