/* eslint-disable no-promise-executor-return */
import React from 'react';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import { isIpad } from 'onevzsoemfeframework/DomService';
import { isVbg } from 'onevzsoemfeframework/VbgAemUtil';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import { fireEvent, render, screen } from '../../../modules/test-utils/renderHelper';
import { setUserAgentIPad } from '../../../modules/test-utils/utils';
import Search from './Search';
import data from '../__mocks__/mockCombinedGridwallData.json';
import myOffers from '../__mocks__/getMyOffers.json';
import deviceProps from '../__mocks__/mockGridwallDevices.json';

const handlers = [
  rest.post(`*/flexV2/productList`, (req, res, ctx) => {
    console.log('inside /flexV2/productList');
    return res(ctx.status(200), ctx.json(data.data));
  }),
  rest.post(`*/grid/typeAhead`, (req, res, ctx) => {
    console.log('inside /grid/typeAhead');
    return res(ctx.status(200), ctx.json(data.responseTypeAhead));
  }),
  rest.post(`*/browseservice/getSkuDetails`, (req, res, ctx) => {
    console.log('inside /browseservice/getSkuDetails');
    return res(ctx.status(200), ctx.json(data.responseGetSkuDetails));
  }),
  rest.post(`*/accountlandingservice/getMyOffers`, (req, res, ctx) => {
    console.log('inside /accountlandingservice/getMyOffers');
    return res(ctx.status(200), ctx.json(myOffers));
  }),
  rest.post(`*/accountlandingservice/flexV2/customerProfile`, (req, res, ctx) => {
    console.log('inside /accountlandingservice/flexV2/customerProfile');
    return res(ctx.status(200), ctx.json({ data: deviceProps.landingData }));
  }),
];
const server = setupServer(...handlers);
jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradleProperty: () => ['TRUE'],
    getAssistedCradlePropertyV2: () => ['TRUE'],
  }),
  { virtual: true },
);
jest.mock('onevzsoemfeframework/VbgAemUtil', () => ({
  __esModule: true,
  ...jest.requireActual('onevzsoemfeframework/VbgAemUtil'),
  isVbg: jest.fn(),
}));
describe('Search component', () => {
  setUserAgentIPad();
  const onSearchTxtChange = jest.fn().mockName('onSearchTxtChange');
  const onCancelSearchInput = jest.fn().mockName('onCancelSearchInput');
  const onAutoCompleteItemSkuSearch = jest.fn().mockName('onAutoCompleteItemSkuSearch');
  const onSearchClick = jest.fn().mockName('onSearchClick');
  const getSkuList = jest.fn().mockName('getSkuList');
  const setShowSearchResults = jest.fn().mockName('setShowSearchResults');
  const setShowNoResults = jest.fn().mockName('setShowNoResults');
  const setToggle = jest.fn().mockName('setToggle');

  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
    sessionStorage.setItem('APP_PROPERTIES', '{"bestBuyIntegrationFFlag": "TRUE"}');
  });
  afterAll(() => {
    server.close();
    sessionStorage.setItem('APIContext', '');
    sessionStorage.setItem('APP_PROPERTIES', '{"bestBuyIntegrationFFlag": "TRUE"}');
  });
  afterEach(() => {
    server.resetHandlers();
  });

  beforeEach(() => {
    Object.defineProperty(window, 'location', {
      value: new URL('http://example.com/combinedgridwall'),
      configurable: true,
    });
    jest.spyOn(console, 'error');
    isVbg.mockReturnValue(true);
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockImplementation(() => null);

    render(
      <Search
        onSearchTxtChange={onSearchTxtChange}
        onCancelSearchInput={onCancelSearchInput}
        onAutoCompleteItemSkuSearch={onAutoCompleteItemSkuSearch}
        path=''
        getSkuList={getSkuList}
        is5GDevice={false}
        onSearchClick={onSearchClick}
        setShowSearchResults={setShowSearchResults}
        showSearchResults
        setShowNoResults={setShowNoResults}
        setToggle={setToggle}
        showNoResults
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });

  it('should mount Search component', () => {
    const testSearch = screen.getByTestId('ShopNavSearchText');
    expect(testSearch).toBeInTheDocument();
  });

  it('should change the input value', async () => {
    const testSearch = screen.getByTestId('ShopNavSearchText');
    fireEvent.change(testSearch, {
      target: { value: 'iphone' },
    });
    await new Promise((res) => setTimeout(res, 1000));
  });

  it('should change input value - No result found', () => {
    const testSearch = screen.getByTestId('ShopNavSearchText');
    fireEvent.change(testSearch, {
      target: { value: 'ASDFGHJKLOIUY' },
    });
  });

  it('should onblur on input', async () => {
    const testSearch = screen.getByTestId('ShopNavSearchText');
    fireEvent.focus(testSearch);
    fireEvent.change(testSearch, {
      target: { value: 'iphone' },
    });
    await new Promise((res) => setTimeout(res, 1000));
    testSearch.blur(testSearch);
  });

  it('should keyDown on input', async () => {
    const testSearch = screen.getByTestId('ShopNavSearchText');
    fireEvent.keyDown(testSearch, { key: 'keydown', keyCode: 13 });
    await new Promise((res) => setTimeout(res, 1000));
  });

  it('should click cross button on input', async () => {
    const testCrossBtn = screen.getByTestId('testCrossBtn');
    const testSearch = screen.getByTestId('ShopNavSearchText');
    fireEvent.change(testSearch, {
      target: { value: 'iphone' },
    });
    await new Promise((res) => setTimeout(res, 1000));
    fireEvent.click(testCrossBtn);
  });
  it('should change input value - No result found', async () => {
    const testSearch = screen.getByTestId('ShopNavSearchText');
    const emptyTAResponse = rest.post(`*/grid/typeAhead`, (req, res, ctx) => {
      console.log('inside empty /grid/typeAhead');
      return res(ctx.status(200), ctx.json(data.emptyResponseTypeAhead));
    });
    server.use(emptyTAResponse);
    fireEvent.focus(testSearch);
    fireEvent.change(testSearch, {
      target: { value: 'ASDFGHJKLOIUY' },
    });
    await new Promise((res) => setTimeout(res, 1000));

    const noSearchResults = screen.getByTestId('NoSearchResults');
    expect(noSearchResults).toBeInTheDocument();
  });

  it('Shouls search using mic icon', async () => {
    expect(isIpad()).toBeTruthy();
    const micIcon = await screen.findByTestId('micIcon');
    expect(micIcon).toBeInTheDocument();
    fireEvent.click(micIcon);
  });

  it('test searchFromShell', async () => {
    window.searchFromShell('iphone');
    await new Promise((res) => setTimeout(res, 1000));
  });

  it('test searchFromShell without params', () => {
    window.searchFromShell();
  });

  afterAll(() => {
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockRestore();
  });
});

describe('Search component - props change', () => {
  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
    sessionStorage.setItem('APP_PROPERTIES', '{"bestBuyIntegrationFFlag": "TRUE"}');
  });
  afterAll(() => {
    server.close();
    sessionStorage.setItem('APIContext', '');
    sessionStorage.removeItem('APP_PROPERTIES');
  });

  const getSkuList = jest.fn().mockName('getSkuList');
  const onSearchTxtChange = jest.fn().mockName('onSearchTxtChange');
  const onCancelSearchInput = jest.fn().mockName('onCancelSearchInput');
  const onAutoCompleteItemSkuSearch = jest.fn().mockName('onAutoCompleteItemSkuSearch');
  const onSearchClick = jest.fn().mockName('onSearchClick');
  const setShowSearchResults = jest.fn().mockName('setShowSearchResults');
  const setShowNoResults = jest.fn().mockName('setShowNoResults');
  const setToggle = jest.fn().mockName('setToggle');

  it('should return search devices for placeholder - combinedgridwall', () => {
    Object.defineProperty(window, 'location', {
      value: new URL('http://example.com/combinedgridwall'),
      configurable: true,
    });
    render(
      <Search
        onSearchTxtChange={onSearchTxtChange}
        onCancelSearchInput={onCancelSearchInput}
        onAutoCompleteItemSkuSearch={onAutoCompleteItemSkuSearch}
        path=''
        getSkuList={getSkuList}
        is5GDevice={false}
        onSearchClick={onSearchClick}
        setShowSearchResults={setShowSearchResults}
        showSearchResults
        setShowNoResults={setShowNoResults}
        setToggle={setToggle}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
    expect(window.location.pathname).toBe('/combinedgridwall');
  });

  it('should return Search accessories for placeholder - accessories', () => {
    delete window.location;
    Object.defineProperty(window, 'location', {
      value: new URL('http://example.com/accessories'),
      configurable: true,
    });
    render(
      <Search
        onSearchTxtChange={onSearchTxtChange}
        onCancelSearchInput={onCancelSearchInput}
        onAutoCompleteItemSkuSearch={onAutoCompleteItemSkuSearch}
        path=''
        getSkuList={getSkuList}
        is5GDevice={false}
        onSearchClick={onSearchClick}
        setShowSearchResults={setShowSearchResults}
        showSearchResults
        setShowNoResults={setShowNoResults}
        setToggle={setToggle}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
    expect(window.location.pathname).toBe('/accessories');
  });

  it('should return Search add-ons for placeholder - addons', () => {
    delete window.location;
    Object.defineProperty(window, 'location', {
      value: new URL('http://example.com/addons'),
      configurable: true,
    });
    render(
      <Search
        onSearchTxtChange={onSearchTxtChange}
        onCancelSearchInput={onCancelSearchInput}
        onAutoCompleteItemSkuSearch={onAutoCompleteItemSkuSearch}
        path=''
        getSkuList={getSkuList}
        is5GDevice={false}
        onSearchClick={onSearchClick}
        setShowSearchResults={setShowSearchResults}
        showSearchResults
        setShowNoResults={setShowNoResults}
        setToggle={setToggle}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
    expect(window.location.pathname).toBe('/addons');
  });

  it('should return Search add-ons for placeholder - addons', () => {
    delete window.location;
    Object.defineProperty(window, 'location', {
      value: new URL('http://example.com/nothing'),
      configurable: true,
    });
    render(
      <Search
        onSearchTxtChange={onSearchTxtChange}
        onCancelSearchInput={onCancelSearchInput}
        onAutoCompleteItemSkuSearch={onAutoCompleteItemSkuSearch}
        path=''
        getSkuList={getSkuList}
        is5GDevice={false}
        onSearchClick={onSearchClick}
        setShowSearchResults={setShowSearchResults}
        showSearchResults
        setShowNoResults={setShowNoResults}
        setToggle={setToggle}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
    expect(window.location.pathname).toBe('/nothing');
  });

  it('should have accessories in path while searching', () => {
    delete window.location;
    Object.defineProperty(window, 'location', {
      value: new URL('http://example.com/accessories'),
      configurable: true,
    });
    render(
      <Search
        onSearchTxtChange={onSearchTxtChange}
        onCancelSearchInput={onCancelSearchInput}
        onAutoCompleteItemSkuSearch={onAutoCompleteItemSkuSearch}
        path=''
        getSkuList={getSkuList}
        is5GDevice={false}
        onSearchClick={onSearchClick}
        setShowSearchResults={setShowSearchResults}
        showSearchResults
        setShowNoResults={setShowNoResults}
        setToggle={setToggle}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
    const testSearch = screen.getByTestId('ShopNavSearchText');
    fireEvent.change(testSearch, {
      target: { value: 'iphone' },
    });
    fireEvent.keyDown(testSearch, { key: 'keydown', keyCode: 13 });
  });

  it('should have path as feature prop', async () => {
    delete window.location;
    Object.defineProperty(window, 'location', {
      value: new URL('http://example.com/feature'),
      configurable: true,
    });
    render(
      <Search
        onSearchTxtChange={onSearchTxtChange}
        onCancelSearchInput={onCancelSearchInput}
        onAutoCompleteItemSkuSearch={onAutoCompleteItemSkuSearch}
        path='feature'
        getSkuList={getSkuList}
        is5GDevice={false}
        onSearchClick={onSearchClick}
        setShowSearchResults={setShowSearchResults}
        showSearchResults
        setShowNoResults={setShowNoResults}
        setToggle={setToggle}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
    const testSearch = screen.getByTestId('ShopNavSearchText');
    fireEvent.change(testSearch, {
      target: { value: 'iphone' },
    });
  });
});

const onSearchTxtChange = jest.fn().mockName('onSearchTxtChange');
const onCancelSearchInput = jest.fn().mockName('onCancelSearchInput');
const onAutoCompleteItemSkuSearch = jest.fn().mockName('onAutoCompleteItemSkuSearch');
const onSearchClick = jest.fn().mockName('onSearchClick');
const getSkuList = jest.fn().mockName('getSkuList');
const setShowSearchResults = jest.fn().mockName('setShowSearchResults');
const setShowNoResults = jest.fn().mockName('setShowNoResults');
const setToggle = jest.fn().mockName('setToggle');

describe('Search component', () => {
  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
    sessionStorage.setItem('APP_PROPERTIES', '{"bestBuyIntegrationFFlag": "TRUE"}');
  });
  afterAll(() => {
    server.close();
    sessionStorage.setItem('APIContext', '');
    sessionStorage.setItem('APP_PROPERTIES', '{"bestBuyIntegrationFFlag": "TRUE"}');
  });
  afterEach(() => {
    server.resetHandlers();
  });

  beforeEach(() => {
    Object.defineProperty(window, 'location', {
      value: new URL('http://example.com/accessory'),
      configurable: true,
    });
    jest.spyOn(console, 'error');
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockImplementation(() => null);

    render(
      <Search
        onSearchTxtChange={onSearchTxtChange}
        onCancelSearchInput={onCancelSearchInput}
        onAutoCompleteItemSkuSearch={onAutoCompleteItemSkuSearch}
        path=''
        getSkuList={getSkuList}
        is5GDevice={false}
        onSearchClick={onSearchClick}
        setShowSearchResults={setShowSearchResults}
        showSearchResults
        setShowNoResults={setShowNoResults}
        setToggle={setToggle}
        showNoResults
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });

  it('should change the input value', async () => {
    const testSearch = screen.getByTestId('ShopNavSearchText');
    fireEvent.change(testSearch, {
      target: { value: '<' },
    });
    await new Promise((res) => setTimeout(res, 1000));
  });

  it('should change the input value', async () => {
    const testSearch = screen.getByTestId('ShopNavSearchText');
    fireEvent.change(testSearch, {
      target: { value: 'iphone' },
    });
    await new Promise((res) => setTimeout(res, 1000));
  });

  it('should not press enter button', async () => {
    const testSearch = screen.getByTestId('ShopNavSearchText');
    fireEvent.keyDown(testSearch, { key: 'keydown', keyCode: 14 });
    await new Promise((res) => setTimeout(res, 1000));
  });

  it('should not press enter button with value', async () => {
    const testSearch = screen.getByTestId('ShopNavSearchText');
    fireEvent.change(testSearch, {
      target: { value: 'iphone' },
    });
    fireEvent.keyDown(testSearch, { key: 'keydown', keyCode: 13 });
    await new Promise((res) => setTimeout(res, 1000));
  });

  it('should not press enter button woth no value', async () => {
    const testSearch = screen.getByTestId('ShopNavSearchText');
    fireEvent.change(testSearch, {
      target: { value: '' },
    });
    fireEvent.keyDown(testSearch, { key: 'keydown', keyCode: 13 });
    await new Promise((res) => setTimeout(res, 1000));
  });

  afterAll(() => {
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockRestore();
  });
});

describe('Search component with no valid search text', () => {
  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
    sessionStorage.setItem('APP_PROPERTIES', '{"bestBuyIntegrationFFlag": "TRUE"}');
  });
  afterAll(() => {
    server.close();
    sessionStorage.setItem('APIContext', '');
    sessionStorage.setItem('APP_PROPERTIES', '{"bestBuyIntegrationFFlag": "TRUE"}');
  });
  afterEach(() => {
    server.resetHandlers();
  });

  beforeEach(() => {
    Object.defineProperty(window, 'location', {
      value: new URL('http://example.com/Gridwall'),
      configurable: true,
    });
    jest.spyOn(console, 'error');
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockImplementation(() => null);

    render(
      <Search
        searchStrValue='<'
        onSearchTxtChange={onSearchTxtChange}
        onCancelSearchInput={onCancelSearchInput}
        onAutoCompleteItemSkuSearch={onAutoCompleteItemSkuSearch}
        path=''
        getSkuList={getSkuList}
        is5GDevice={false}
        onSearchClick={onSearchClick}
        setShowSearchResults={setShowSearchResults}
        showSearchResults
        setShowNoResults={setShowNoResults}
        setToggle={setToggle}
        showNoResults
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });

  it('should change the input value', async () => {
    const testSearch = screen.getByTestId('ShopNavSearchText');
    fireEvent.change(testSearch, {
      target: { value: '<' },
    });
    await new Promise((res) => setTimeout(res, 1000));
  });

  it('should change the input value', async () => {
    const testSearch = screen.getByTestId('ShopNavSearchText');
    fireEvent.change(testSearch, {
      target: { value: 'iphone' },
    });
    await new Promise((res) => setTimeout(res, 1000));
  });

  afterAll(() => {
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockRestore();
  });
});

describe('Search component with no valid search text', () => {
  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
    sessionStorage.setItem('APP_PROPERTIES', '{"bestBuyIntegrationFFlag": "TRUE"}');
  });
  afterAll(() => {
    server.close();
    sessionStorage.setItem('APIContext', '');
    sessionStorage.setItem('APP_PROPERTIES', '{"bestBuyIntegrationFFlag": "TRUE"}');
  });
  afterEach(() => {
    server.resetHandlers();
  });

  beforeEach(() => {
    Object.defineProperty(window, 'location', {
      value: new URL('http://example.com/Gridwall'),
      configurable: true,
    });
    isVbg.mockImplementation(() => true);
    jest.spyOn(console, 'error');
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockImplementation(() => null);

    render(
      <Search
        searchStrValue='<'
        onSearchTxtChange={onSearchTxtChange}
        onCancelSearchInput={onCancelSearchInput}
        onAutoCompleteItemSkuSearch={onAutoCompleteItemSkuSearch}
        path=''
        getSkuList={getSkuList}
        is5GDevice={true}
        onSearchClick={onSearchClick}
        setShowSearchResults={setShowSearchResults}
        showSearchResults
        setShowNoResults={setShowNoResults}
        setToggle={setToggle}
        showNoResults
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });

  it('should change the input value', async () => {
    const testSearch = screen.getByTestId('ShopNavSearchText');
    fireEvent.change(testSearch, {
      target: { value: '<' },
    });
    await new Promise((res) => setTimeout(res, 1000));
  });

  it('should change the input value', async () => {
    const testSearch = screen.getByTestId('ShopNavSearchText');
    fireEvent.change(testSearch, {
      target: { value: 'iphone' },
    });
    await new Promise((res) => setTimeout(res, 1000));
  });

  afterAll(() => {
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockRestore();
  });
});

describe('Search component with scmDeviceMfeEnable', () => {
  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
    sessionStorage.setItem('APP_PROPERTIES', '{"bestBuyIntegrationFFlag": "TRUE"}');
  });
  afterAll(() => {
    server.close();
    sessionStorage.setItem('APIContext', '');
    sessionStorage.setItem('APP_PROPERTIES', '{"bestBuyIntegrationFFlag": "TRUE"}');
  });
  afterEach(() => {
    server.resetHandlers();
  });

  beforeEach(() => {
    Object.defineProperty(window, 'location', {
      value: new URL('http://example.com/Gridwall'),
      configurable: true,
    });
    window.mfe = {};
    window.mfe = { scmDeviceMfeEnable: true, scmUpgradeMfeEnable: true };
    jest.spyOn(console, 'error');
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockImplementation(() => null);

    render(
      <Search
        searchStrValue='<'
        onSearchTxtChange={onSearchTxtChange}
        onCancelSearchInput={onCancelSearchInput}
        onAutoCompleteItemSkuSearch={onAutoCompleteItemSkuSearch}
        path=''
        getSkuList={getSkuList}
        is5GDevice={false}
        onSearchClick={onSearchClick}
        setShowSearchResults={setShowSearchResults}
        showSearchResults
        setShowNoResults={setShowNoResults}
        setToggle={setToggle}
        showNoResults
        productTypeForSearch={'device'}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });

  it('should change the input value', async () => {
    const testSearch = screen.getByTestId('ShopNavSearchText');
    fireEvent.change(testSearch, {
      target: { value: 'iPhone14 Pro' },
    });
    await new Promise((res) => setTimeout(res, 1000));
  });
});

describe('Search component with scmDeviceMfeEnable', () => {
  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
    sessionStorage.setItem('APP_PROPERTIES', '{"bestBuyIntegrationFFlag": "TRUE"}');
  });
  afterAll(() => {
    server.close();
    sessionStorage.setItem('APIContext', '');
    sessionStorage.setItem('APP_PROPERTIES', '{"bestBuyIntegrationFFlag": "TRUE"}');
  });
  afterEach(() => {
    server.resetHandlers();
  });

  beforeEach(() => {
    Object.defineProperty(window, 'location', {
      value: new URL('http://example.com/Gridwall'),
      configurable: true,
    });
    window.mfe = {};
    window.mfe = { scmDeviceMfeEnable: true, scmUpgradeMfeEnable: true };
    jest.spyOn(console, 'error');
    isVbg.mockReturnValue(true);
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockImplementation(() => null);

    render(
      <Search
        searchStrValue='<'
        onSearchTxtChange={onSearchTxtChange}
        onCancelSearchInput={onCancelSearchInput}
        onAutoCompleteItemSkuSearch={onAutoCompleteItemSkuSearch}
        path=''
        getSkuList={getSkuList}
        is5GDevice={true}
        onSearchClick={onSearchClick}
        setShowSearchResults={setShowSearchResults}
        showSearchResults
        setShowNoResults={setShowNoResults}
        setToggle={setToggle}
        showNoResults
        productTypeForSearch={'device'}
      />,
      { reducers: rootReducer, sagas: rootSaga },
    );
  });

  it('should change the input value', async () => {
    const testSearch = screen.getByTestId('ShopNavSearchText');
    fireEvent.change(testSearch, {
      target: { value: 'iPhone14 Pro' },
    });
    await new Promise((res) => setTimeout(res, 1000));
  });
});
