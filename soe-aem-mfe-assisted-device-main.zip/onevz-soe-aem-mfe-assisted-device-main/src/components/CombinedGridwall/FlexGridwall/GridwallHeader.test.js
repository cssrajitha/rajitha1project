import React from 'react';
import Emitter from 'onevzsoemfeframework/Emitter';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import { render, screen, fireEvent } from '../../../modules/test-utils/renderHelper';
import GridwallHeader from './GridwallHeader';

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getAssistedCradlePropertyV2: () => ['TRUE'],
  }),
  { virtual: true },
);

describe('GridwallHeader component - New Customer', () => {
  const handleBackNavigation = jest.fn().mockName('handleBackNavigation');
  const handleContinue = jest.fn().mockName('handleContinue');
  beforeEach(() => {
    window.history.pushState({}, 'Gridwall', '/sales/assisted/new/gridwall.html?fromPromotions=true');
    Emitter.emit('ProspectBYODTile', true);
    jest.spyOn(console, 'error');
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockImplementation(() => null);

    render(<GridwallHeader handleBackNavigation={handleBackNavigation} handleContinue={handleContinue} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  it('should mount Filter component', () => {
    Emitter.emit('ProspectBYODTile', true);
    const testGridwallHeader = screen.getByTestId('testGridwallHeader');
    expect(testGridwallHeader).toBeInTheDocument();
  });

  it('should click continue button', () => {
    const testContinueGridwall = screen.getByTestId('testContinueGridwall');
    expect(testContinueGridwall).toBeInTheDocument();
    fireEvent.click(testContinueGridwall);
  });

  it('should click back button', () => {
    const testBackGridwall = screen.getByTestId('testBackGridwall');
    expect(testBackGridwall).toBeInTheDocument();
    fireEvent.click(testBackGridwall);
  });

  afterAll(() => {
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockRestore();
  });
});
describe('GridwallHeader component - Existing Customer', () => {
  const handleBackNavigation = jest.fn().mockName('handleBackNavigation');
  const handleContinue = jest.fn().mockName('handleContinue');
  beforeEach(() => {
    Emitter.emit('ProspectBYODTile', false);
    window.history.pushState({}, 'Gridwall', '/sales/assisted/new/gridwall.html');
    jest.spyOn(console, 'error');
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockImplementation(() => null);

    render(<GridwallHeader handleBackNavigation={handleBackNavigation} handleContinue={handleContinue} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  it('should mount Filter component', () => {
    Emitter.emit('ProspectBYODTile', false);
    const testGridwallHeader = screen.getByTestId('testGridwallHeader');
    expect(testGridwallHeader).toBeInTheDocument();
  });

  it('should click continue button', () => {
    const testContinueGridwall = screen.getByTestId('testContinueGridwall');
    expect(testContinueGridwall).toBeInTheDocument();
    fireEvent.click(testContinueGridwall);
  });

  it('should click back button', () => {
    const testBackGridwall = screen.getByTestId('testBackGridwall');
    expect(testBackGridwall).toBeInTheDocument();
    fireEvent.click(testBackGridwall);
  });

  afterAll(() => {
    // @ts-ignore jest.spyOn adds this functionallity
    console.error.mockRestore();
  });
});
