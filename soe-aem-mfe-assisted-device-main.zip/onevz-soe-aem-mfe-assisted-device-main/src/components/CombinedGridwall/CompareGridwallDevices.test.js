import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import CompareGridwallDevices from './CompareGridwallDevices';
import { getDpTermIndex, getPricingPriority } from '../../modules/utils/devicePricingUtils';
import { isVbg } from 'onevzsoemfeframework/VbgAemUtil';

jest.mock('onevzsoemfeframework/AssistedCradleService', () => ({
  getAssistedCradlePropertyV2: jest.fn(),
}));
jest.mock('onevzsoemfeframework/VbgAemUtil', () => ({
  __esModule: true,
  ...jest.requireActual('onevzsoemfeframework/VbgAemUtil'),
  isVbg: jest.fn(),
}));
jest.mock('../../modules/utils/devicePricingUtils', () => ({
  getPricingPriority: jest.fn(),
  getDpTermIndex: jest.fn(),
}));
describe('CompareGridwallDevices component', () => {
  test('it should render CompareGridwallDevices', () => {
    getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE']);
    isVbg.mockReturnValue(false);
    getPricingPriority.mockReturnValue(null);

    const props = {
      cartDetails: { cart: { cartHeader: { locationSubType: 'GN', maid: 'BBX' } } },
      showCompareData: [11, 222, 333],
      clearSelectedPaymentType: jest.fn(),
      landing: {
        customerInfo: { channel: 'OMNI-INDIRECT' },
        lineDetails: [{ mtn: '123' }],
      },
      isBundledGW: true,
      setHumDeviceType: jest.fn(),
      handleRemoveProductFromCompare: jest.fn(),
      hideCompareDevicesModal: jest.fn(),
      history: {
        length: 50,
        action: 'PUSH',
        location: {
          pathname: '/content/vcg/assisted/pdp.html',
          search: '?productId=dev12400034&defaultSku=MWGR2LL/A',
          hash: '',
          key: 'e8vdhw',
        },
      },
    };
    const props2 = {
      showCompareData: {
        compareList: [
          {
            productId: 'dev19920005',
            specifications: {
              battery: null,
              depth: 0.31,
              height: 5.81,
              screenSize: '6.1"',
              size: '5.81,2.81,0.31',
              weight: 7.27,
              width: 2.81,
            },
            rating: {
              numberOfReviews: null,
              averageRating: null,
              productId: null,
              batteryLife: null,
              callQuality: null,
              design: null,
              display: null,
              easeOfUse: null,
              features: null,
              percentRecommended: null,
              performance: null,
            },
            brandName: 'Apple',
            productDisplayName: 'iPhone 14 Pro',
            sorDeviceType: '5GE',
            techSpecs: {
              'Video Playback': 'Up to 23 hrs.',
              Overall: 'Accessibility Shortcut, Siri, Guided Access, Per App Setting',
              'Wi-Fi': 'Yes',
              Screen:
                'Super Retina XDR display; 6.1-inch (diagonal) all-screen OLED display; 2556-by-1179-pixel resolution at 460 ppi',
              '5G Ultra Wideband': 'n260/ n261 (high-band / mmWave) | n77 (mid-band / C-band)',
              'Hearing Aid Compatibility': 'M3/T4',
              Depth: '0.31 in.',
              Weight: '7.27 oz.',
              Type: 'Built-in rechargeable lithium-ion battery',
              '4G': '13, 4, 2, 5, 66, 46, 48',
              Colors: 'Space Black, Silver, Gold, Deep Purple',
              Storage: '128GB, 256GB, 512GB, 1TB (Subject to availability)',
              Auditory: 'Made for iPhone hearing devices, Sound Recognition, Headphone Accommodations, Live Captions',
              'Usage Time': 'Streamed: Up to 20 hrs; Audio playback: Up to 75 hrs.',
              'Rear Camera':
                'Main: 24 mm, ƒ/1.78 aperture, second-generation sensor-shift optical image stabilization, seven-element lens, 100% Focus Pixels',
              'Mobility/Cognitive': 'Voice Control, Switch Control, AssistiveTouch, Back Tap',
              'FCC ID': 'BCG-E4000A',
              'Global & Roaming Network':
                'LTE Roaming 1, 3, 7, 20, 28, 12, 26 | GSM/UMTS 850, 900, 1700/2100, 1900, 2100 MHz) | GSM/EDGE (850, 900, 1800, 1900 Mhz)',
              '5G Nationwide': 'n2/n5/n48/n66',
              Height: '5.81 in.',
              'Operating System': 'Apple iOS',
              camera: '48MP ',
              Width: '2.81 in.',
              Visual: 'VoiceOver, Zoom, Color Filters, Spoken Content',
            },
            childSkus: [
              {
                skuId: 'sku5600273',
                color: {
                  colorCssStyle: '#1E1D1B',
                  colorId: 'clr12240018',
                  description: 'Black',
                  displayName: 'Space Black',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 27.77,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $27.77/mo. for 36 months; 0% APR. Retail Price: $999.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 28.04,
                        remainingMonthPrice: 27.77,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 999.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 999.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MPXT3LL/A',
                skuDisplayName: 'iPhone 14 Pro 128GB in Space Black',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 51969,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600274',
                color: {
                  colorCssStyle: '#C0C0C0',
                  colorId: 'clr40012',
                  description: 'Silver',
                  displayName: 'Silver',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a',
                  largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-med$',
                  miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 27.77,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $27.77/mo. for 36 months; 0% APR. Retail Price: $999.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 28.04,
                        remainingMonthPrice: 27.77,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 999.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 999.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ003LL/A',
                skuDisplayName: 'iPhone 14 Pro 128GB in Silver',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 52841,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600275',
                color: {
                  colorCssStyle: '#D0C2AE',
                  colorId: 'clr3360032',
                  description: 'Gold',
                  displayName: 'Gold',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a',
                  largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-lg$',
                  mediumImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-med$',
                  miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-mini$',
                  thumbImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 27.77,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $27.77/mo. for 36 months; 0% APR. Retail Price: $999.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 28.04,
                        remainingMonthPrice: 27.77,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 999.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 999.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ063LL/A',
                skuDisplayName: 'iPhone 14 Pro 128GB in Gold',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: true,
                    isShipBy: true,
                    isInStock: false,
                    locationCode: '9999999',
                    qtyAvailable: 0,
                    shippingDate: {
                      date: '12/29/2023',
                      dateTime: '12-29-2023 08:00:00 AM',
                      dateLong: 1703836800000,
                    },
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600276',
                color: {
                  colorCssStyle: '#655D6C',
                  colorId: 'clr12200029',
                  description: 'Purple',
                  displayName: 'Deep Purple',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 27.77,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $27.77/mo. for 36 months; 0% APR. Retail Price: $999.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 28.04,
                        remainingMonthPrice: 27.77,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 999.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 999.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ0E3LL/A',
                skuDisplayName: 'iPhone 14 Pro 128GB in Deep Purple',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 47025,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600277',
                color: {
                  colorCssStyle: '#1E1D1B',
                  colorId: 'clr12240018',
                  description: 'Black',
                  displayName: 'Space Black',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 30.55,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $30.55/mo. for 36 months; 0% APR. Retail Price: $1099.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 30.74,
                        remainingMonthPrice: 30.55,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 1099.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 1099.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ0N3LL/A',
                skuDisplayName: 'iPhone 14 Pro 256GB in Space Black',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 49578,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600278',
                color: {
                  colorCssStyle: '#C0C0C0',
                  colorId: 'clr40012',
                  description: 'Silver',
                  displayName: 'Silver',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a',
                  largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-med$',
                  miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 30.55,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $30.55/mo. for 36 months; 0% APR. Retail Price: $1099.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 30.74,
                        remainingMonthPrice: 30.55,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 1099.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 1099.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ0X3LL/A',
                skuDisplayName: 'iPhone 14 Pro 256GB in Silver',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 52868,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600279',
                color: {
                  colorCssStyle: '#D0C2AE',
                  colorId: 'clr3360032',
                  description: 'Gold',
                  displayName: 'Gold',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a',
                  largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-lg$',
                  mediumImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-med$',
                  miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-mini$',
                  thumbImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 30.55,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $30.55/mo. for 36 months; 0% APR. Retail Price: $1099.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 30.74,
                        remainingMonthPrice: 30.55,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 1099.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 1099.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ163LL/A',
                skuDisplayName: 'iPhone 14 Pro 256GB in Gold',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 49849,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600280',
                color: {
                  colorCssStyle: '#655D6C',
                  colorId: 'clr12200029',
                  description: 'Purple',
                  displayName: 'Deep Purple',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 30.55,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $30.55/mo. for 36 months; 0% APR. Retail Price: $1099.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 30.74,
                        remainingMonthPrice: 30.55,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 1099.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 1099.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ1D3LL/A',
                skuDisplayName: 'iPhone 14 Pro 256GB in Deep Purple',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 49767,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600180',
                color: {
                  colorCssStyle: '#1E1D1B',
                  colorId: 'clr12240018',
                  description: 'Black',
                  displayName: 'Space Black',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 36.11,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $36.11/mo. for 36 months; 0% APR. Retail Price: $1299.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 36.14,
                        remainingMonthPrice: 36.11,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 1299.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 1299.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ1K3LL/A',
                skuDisplayName: 'iPhone 14 Pro 512GB in Space Black',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 49686,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600281',
                color: {
                  colorCssStyle: '#C0C0C0',
                  colorId: 'clr40012',
                  description: 'Silver',
                  displayName: 'Silver',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a',
                  largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-med$',
                  miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 36.11,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $36.11/mo. for 36 months; 0% APR. Retail Price: $1299.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 36.14,
                        remainingMonthPrice: 36.11,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 1299.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 1299.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ1U3LL/A',
                skuDisplayName: 'iPhone 14 Pro 512GB in Silver',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 59951,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600282',
                color: {
                  colorCssStyle: '#D0C2AE',
                  colorId: 'clr3360032',
                  description: 'Gold',
                  displayName: 'Gold',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a',
                  largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-lg$',
                  mediumImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-med$',
                  miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-mini$',
                  thumbImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 36.11,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $36.11/mo. for 36 months; 0% APR. Retail Price: $1299.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 36.14,
                        remainingMonthPrice: 36.11,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 1299.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 1299.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ213LL/A',
                skuDisplayName: 'iPhone 14 Pro 512GB in Gold',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 52953,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600181',
                color: {
                  colorCssStyle: '#655D6C',
                  colorId: 'clr12200029',
                  description: 'Purple',
                  displayName: 'Deep Purple',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 36.11,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $36.11/mo. for 36 months; 0% APR. Retail Price: $1299.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 36.14,
                        remainingMonthPrice: 36.11,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 1299.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 1299.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ273LL/A',
                skuDisplayName: 'iPhone 14 Pro 512GB in Deep Purple',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: true,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: true,
                    isInStock: false,
                    locationCode: '9999999',
                    qtyAvailable: 0,
                    shippingDate: {
                      date: '12/12/2023',
                      dateTime: '12-12-2023 08:00:00 AM',
                      dateLong: 1702368000000,
                    },
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600182',
                color: {
                  colorCssStyle: '#655D6C',
                  colorId: 'clr12200029',
                  description: 'Purple',
                  displayName: 'Deep Purple',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 41.66,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $41.66/mo. for 36 months; 0% APR. Retail Price: $1499.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 41.89,
                        remainingMonthPrice: 41.66,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 1499.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 1499.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ303LL/A',
                skuDisplayName: 'iPhone 14 Pro 1TB in Deep Purple',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 49899,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600283',
                color: {
                  colorCssStyle: '#1E1D1B',
                  colorId: 'clr12240018',
                  description: 'Black',
                  displayName: 'Space Black',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 41.66,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $41.66/mo. for 36 months; 0% APR. Retail Price: $1499.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 41.89,
                        remainingMonthPrice: 41.66,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 1499.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 1499.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ2E3LL/A',
                skuDisplayName: 'iPhone 14 Pro 1TB in Space Black',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 49776,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600284',
                color: {
                  colorCssStyle: '#C0C0C0',
                  colorId: 'clr40012',
                  description: 'Silver',
                  displayName: 'Silver',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a',
                  largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-med$',
                  miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 41.66,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $41.66/mo. for 36 months; 0% APR. Retail Price: $1499.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 41.89,
                        remainingMonthPrice: 41.66,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 1499.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 1499.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ2L3LL/A',
                skuDisplayName: 'iPhone 14 Pro 1TB in Silver',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 49891,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600285',
                color: {
                  colorCssStyle: '#D0C2AE',
                  colorId: 'clr3360032',
                  description: 'Gold',
                  displayName: 'Gold',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a',
                  largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-lg$',
                  mediumImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-med$',
                  miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-mini$',
                  thumbImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 41.66,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $41.66/mo. for 36 months; 0% APR. Retail Price: $1499.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 41.89,
                        remainingMonthPrice: 41.66,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 1499.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 1499.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ2T3LL/A',
                skuDisplayName: 'iPhone 14 Pro 1TB in Gold',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 52920,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
            ],
            defaultSKU: 'MQ0E3LL/A',
            seo: {
              canonicalUrl: 'smartphones/apple-iphone-14-pro/',
            },
            defaultSKUObj: {
              skuId: 'sku5600276',
              color: {
                colorCssStyle: '#655D6C',
                colorId: 'clr12200029',
                description: 'Purple',
                displayName: 'Deep Purple',
              },
              imageUrlMap: {
                defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a',
                largeImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-lg$',
                mediumImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-med$',
                miniImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-mini$',
                thumbImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-thumb$',
                imageSetUrl:
                  'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
              },
              price: {
                devicePaymentPrice: [
                  {
                    originalPrice: 27.77,
                    contractDuration: 36,
                    contractText:
                      'Monthly payments shown are for customers who qualify to pay $0 Down, $27.77/mo. for 36 months; 0% APR. Retail Price: $999.99',
                    dpTermPrices: {
                      downPayment: 0,
                      downPaymentRequired: false,
                      upgradeOptionPercentage: 50,
                      upgradeOptionCode: 'UO',
                      dpTerm: 36,
                      ugradeEligibilityCategory: [
                        {
                          categoryCode: '4',
                          categories: ['5G Smartphone~4G Smartphone'],
                        },
                      ],
                      firstMonthPrice: 28.04,
                      remainingMonthPrice: 27.77,
                    },
                  },
                ],
                fullRetailPrice: {
                  originalPrice: 999.99,
                  contractText: 'Full Retail Price',
                },
                preferredTerm: 36,
                prepayPrice: {
                  originalPrice: 999.99,
                  contractText: 'Prepay Price',
                },
              },
              sorId: 'MQ0E3LL/A',
              skuDisplayName: 'iPhone 14 Pro 128GB in Deep Purple',
              inventoryDetails: {
                dFillInventory: {
                  isAvailable: false,
                  isBackorder: false,
                  isDeliverBy: false,
                  isPreOrder: false,
                  isShipBy: false,
                  isInStock: true,
                  locationCode: '9999999',
                  qtyAvailable: 47025,
                },
              },
              prodCode1: '5GD',
              prodCode2: 'SMT',
              prodCode3: 'DIG',
              prodCode4: 'VDS',
              prodCode5: 'ISL',
            },
          },
          {
            productId: 'dev19920006',
            specifications: {
              battery: null,
              depth: 0.31,
              height: 6.33,
              screenSize: '6.7"',
              size: '6.33,3.05,0.31',
              weight: 8.47,
              width: 3.05,
            },
            rating: {
              numberOfReviews: null,
              averageRating: null,
              productId: null,
              batteryLife: null,
              callQuality: null,
              design: null,
              display: null,
              easeOfUse: null,
              features: null,
              percentRecommended: null,
              performance: null,
            },
            brandName: 'Apple',
            productDisplayName: 'iPhone 14 Pro Max',
            sorDeviceType: '5GE',
            techSpecs: {
              'Video Playback': 'Up to 29 hours | Streamed: Up to 25 hours',
              Overall: 'Accessibility Shortcut, Siri, Guided Access, Per App Setting',
              'Wi-Fi': 'Yes',
              Screen:
                'Super Retina XDR display; 6.7-inch (diagonal) all-screen OLED display; 2796-by-1290-pixel resolution at 460 ppi',
              'Hearing Aid Compatibility': 'M3/T4',
              '5G Ultra Wideband': 'n260/ n261 (high-band / mmWave) | n77 (mid-band / C-band)',
              Depth: '0.31 in.',
              Weight: '8.47 oz.',
              Type: 'Built-in rechargeable lithium-ion battery',
              Auditory: 'Made for iPhone hearing devices, Sound Recognition, Headphone Accommodations, Live Captions',
              '4G': '13, 4, 2, 5, 66, 46, 48',
              Colors: 'Space Black, Silver, Gold, Deep Purple',
              Storage: '128GB, 256GB, 512GB, 1TB (Subject to availability)',
              'Main Lens': '48MP',
              'Usage Time': 'Audio playback: Up to 95 hours',
              'Rear Camera':
                'Main: 24 mm, ƒ/1.78 aperture, second-generation sensor-shift optical image stabilization, seven-element lens, 100% Focus Pixels',
              'Mobility/Cognitive': 'Voice Control, Switch Control, AssistiveTouch, Back Tap',
              'Global & Roaming Network':
                'LTE Roaming 1, 3, 7, 20, 28, 12, 26 | GSM/UMTS 850, 900, 1700/2100, 1900, 2100 MHz) | GSM/EDGE (850, 900, 1800, 1900 Mhz)',
              'FCC ID': 'BCG-E4003A',
              '5G Nationwide': 'n2/n5/n48/n66',
              Height: '6.33 in.',
              'Operating System': 'Apple iOS',
              Width: '3.05 in.',
              Visual: 'VoiceOver, Zoom, Color Filters, Spoken Content',
            },
            childSkus: [
              {
                skuId: 'sku5600286',
                color: {
                  colorCssStyle: '#1E1D1B',
                  colorId: 'clr12240018',
                  description: 'Black',
                  displayName: 'Space Black',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-space-black-fall22-a',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-space-black-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-space-black-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-space-black-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-space-black-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-max-space-black-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 30.55,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $30.55/mo. for 36 months; 0% APR. Retail Price: $1099.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 30.74,
                        remainingMonthPrice: 30.55,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 1099.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 1099.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ8N3LL/A',
                skuDisplayName: 'Apple iPhone 14 Pro Max 128GB in Space Black',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 64496,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600287',
                color: {
                  colorCssStyle: '#C0C0C0',
                  colorId: 'clr40012',
                  description: 'Silver',
                  displayName: 'Silver',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-silver-fall22-a',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-silver-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-silver-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-silver-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-silver-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-max-silver-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 30.55,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $30.55/mo. for 36 months; 0% APR. Retail Price: $1099.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 30.74,
                        remainingMonthPrice: 30.55,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 1099.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 1099.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ8P3LL/A',
                skuDisplayName: 'Apple iPhone 14 Pro Max 128GB in Silver',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 50983,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600183',
                color: {
                  colorCssStyle: '#D0C2AE',
                  colorId: 'clr3360032',
                  description: 'Gold',
                  displayName: 'Gold',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-gold-fall22-a',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-gold-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-gold-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-gold-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-gold-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-max-gold-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 30.55,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $30.55/mo. for 36 months; 0% APR. Retail Price: $1099.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 30.74,
                        remainingMonthPrice: 30.55,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 1099.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 1099.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ8Q3LL/A',
                skuDisplayName: 'Apple iPhone 14 Pro Max 128GB in Gold',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 49873,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600288',
                color: {
                  colorCssStyle: '#655D6C',
                  colorId: 'clr12200029',
                  description: 'Purple',
                  displayName: 'Deep Purple',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 30.55,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $30.55/mo. for 36 months; 0% APR. Retail Price: $1099.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 30.74,
                        remainingMonthPrice: 30.55,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 1099.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 1099.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ8R3LL/A',
                skuDisplayName: 'Apple iPhone 14 Pro Max 128GB in Deep Purple',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 41169,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600184',
                color: {
                  colorCssStyle: '#1E1D1B',
                  colorId: 'clr12240018',
                  description: 'Black',
                  displayName: 'Space Black',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-space-black-fall22-a',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-space-black-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-space-black-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-space-black-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-space-black-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-max-space-black-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 33.33,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $33.33/mo. for 36 months; 0% APR. Retail Price: $1199.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 33.44,
                        remainingMonthPrice: 33.33,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 1199.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 1199.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ8T3LL/A',
                skuDisplayName: 'Apple iPhone 14 Pro Max 256GB in Space Black',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 49782,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600289',
                color: {
                  colorCssStyle: '#C0C0C0',
                  colorId: 'clr40012',
                  description: 'Silver',
                  displayName: 'Silver',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-silver-fall22-a',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-silver-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-silver-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-silver-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-silver-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-max-silver-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 33.33,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $33.33/mo. for 36 months; 0% APR. Retail Price: $1199.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 33.44,
                        remainingMonthPrice: 33.33,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 1199.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 1199.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ8U3LL/A',
                skuDisplayName: 'Apple iPhone 14 Pro Max 256GB in Silver',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 52835,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600290',
                color: {
                  colorCssStyle: '#D0C2AE',
                  colorId: 'clr3360032',
                  description: 'Gold',
                  displayName: 'Gold',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-gold-fall22-a',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-gold-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-gold-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-gold-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-gold-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-max-gold-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 33.33,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $33.33/mo. for 36 months; 0% APR. Retail Price: $1199.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 33.44,
                        remainingMonthPrice: 33.33,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 1199.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 1199.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ8V3LL/A',
                skuDisplayName: 'Apple iPhone 14 Pro Max 256GB in Gold',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: true,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: true,
                    isInStock: false,
                    locationCode: '9999999',
                    qtyAvailable: 0,
                    shippingDate: {
                      date: '06/07/2023',
                      dateTime: '06-07-2023 07:00:00 AM',
                      dateLong: 1686121200000,
                    },
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600291',
                color: {
                  colorCssStyle: '#655D6C',
                  colorId: 'clr12200029',
                  description: 'Purple',
                  displayName: 'Deep Purple',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 33.33,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $33.33/mo. for 36 months; 0% APR. Retail Price: $1199.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 33.44,
                        remainingMonthPrice: 33.33,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 1199.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 1199.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ8W3LL/A',
                skuDisplayName: 'Apple iPhone 14 Pro Max 256GB in Deep Purple',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 49489,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600185',
                color: {
                  colorCssStyle: '#1E1D1B',
                  colorId: 'clr12240018',
                  description: 'Black',
                  displayName: 'Space Black',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-space-black-fall22-a',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-space-black-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-space-black-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-space-black-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-space-black-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-max-space-black-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 38.88,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $38.88/mo. for 36 months; 0% APR. Retail Price: $1399.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 39.19,
                        remainingMonthPrice: 38.88,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 1399.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 1399.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ8X3LL/A',
                skuDisplayName: 'Apple iPhone 14 Pro Max 512GB in Space Black',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 59738,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600292',
                color: {
                  colorCssStyle: '#C0C0C0',
                  colorId: 'clr40012',
                  description: 'Silver',
                  displayName: 'Silver',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-silver-fall22-a',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-silver-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-silver-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-silver-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-silver-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-max-silver-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 38.88,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $38.88/mo. for 36 months; 0% APR. Retail Price: $1399.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 39.19,
                        remainingMonthPrice: 38.88,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 1399.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 1399.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ8Y3LL/A',
                skuDisplayName: 'Apple iPhone 14 Pro Max 512GB in Silver',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 49842,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600293',
                color: {
                  colorCssStyle: '#D0C2AE',
                  colorId: 'clr3360032',
                  description: 'Gold',
                  displayName: 'Gold',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-gold-fall22-a',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-gold-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-gold-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-gold-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-gold-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-max-gold-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 38.88,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $38.88/mo. for 36 months; 0% APR. Retail Price: $1399.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 39.19,
                        remainingMonthPrice: 38.88,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 1399.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 1399.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ903LL/A',
                skuDisplayName: 'Apple iPhone 14 Pro Max 512GB in Gold',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: true,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: true,
                    isInStock: false,
                    locationCode: '9999999',
                    qtyAvailable: 0,
                    shippingDate: {
                      date: '12/12/2023',
                      dateTime: '12-12-2023 08:00:00 AM',
                      dateLong: 1702368000000,
                    },
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600186',
                color: {
                  colorCssStyle: '#655D6C',
                  colorId: 'clr12200029',
                  description: 'Purple',
                  displayName: 'Deep Purple',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 38.88,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $38.88/mo. for 36 months; 0% APR. Retail Price: $1399.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 39.19,
                        remainingMonthPrice: 38.88,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 1399.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 1399.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ913LL/A',
                skuDisplayName: 'Apple iPhone 14 Pro Max 512GB in Deep Purple',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 49738,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600187',
                color: {
                  colorCssStyle: '#D0C2AE',
                  colorId: 'clr3360032',
                  description: 'Gold',
                  displayName: 'Gold',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-gold-fall22-a',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-gold-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-gold-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-gold-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-gold-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-max-gold-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 44.44,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $44.44/mo. for 36 months; 0% APR. Retail Price: $1599.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 44.59,
                        remainingMonthPrice: 44.44,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 1599.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 1599.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ943LL/A',
                skuDisplayName: 'Apple iPhone 14 Pro Max 1TB in Gold',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 52933,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600294',
                color: {
                  colorCssStyle: '#1E1D1B',
                  colorId: 'clr12240018',
                  description: 'Black',
                  displayName: 'Space Black',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-space-black-fall22-a',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-space-black-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-space-black-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-space-black-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-space-black-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-max-space-black-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 44.44,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $44.44/mo. for 36 months; 0% APR. Retail Price: $1599.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 44.59,
                        remainingMonthPrice: 44.44,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 1599.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 1599.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ923LL/A',
                skuDisplayName: 'Apple iPhone 14 Pro Max 1TB in Space Black',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 49811,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600295',
                color: {
                  colorCssStyle: '#C0C0C0',
                  colorId: 'clr40012',
                  description: 'Silver',
                  displayName: 'Silver',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-silver-fall22-a',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-silver-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-silver-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-silver-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-silver-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-max-silver-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 44.44,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $44.44/mo. for 36 months; 0% APR. Retail Price: $1599.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 44.59,
                        remainingMonthPrice: 44.44,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 1599.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 1599.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ933LL/A',
                skuDisplayName: 'Apple iPhone 14 Pro Max 1TB in Silver',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 59901,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600296',
                color: {
                  colorCssStyle: '#655D6C',
                  colorId: 'clr12200029',
                  description: 'Purple',
                  displayName: 'Deep Purple',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 44.44,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $44.44/mo. for 36 months; 0% APR. Retail Price: $1599.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 44.59,
                        remainingMonthPrice: 44.44,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 1599.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 1599.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ953LL/A',
                skuDisplayName: 'Apple iPhone 14 Pro Max 1TB in Deep Purple',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 49923,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
            ],
            defaultSKU: 'MQ8R3LL/A',
            seo: {
              canonicalUrl: 'smartphones/apple-iphone-14-pro-max/',
            },
            defaultSKUObj: {
              skuId: 'sku5600288',
              color: {
                colorCssStyle: '#655D6C',
                colorId: 'clr12200029',
                description: 'Purple',
                displayName: 'Deep Purple',
              },
              imageUrlMap: {
                defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a',
                largeImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-lg$',
                mediumImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-med$',
                miniImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-mini$',
                thumbImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a?$device-thumb$',
                imageSetUrl:
                  'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-max-deep-purple-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
              },
              price: {
                devicePaymentPrice: [
                  {
                    originalPrice: 30.55,
                    contractDuration: 36,
                    contractText:
                      'Monthly payments shown are for customers who qualify to pay $0 Down, $30.55/mo. for 36 months; 0% APR. Retail Price: $1099.99',
                    dpTermPrices: {
                      downPayment: 0,
                      downPaymentRequired: false,
                      upgradeOptionPercentage: 50,
                      upgradeOptionCode: 'UO',
                      dpTerm: 36,
                      ugradeEligibilityCategory: [
                        {
                          categoryCode: '4',
                          categories: ['5G Smartphone~4G Smartphone'],
                        },
                      ],
                      firstMonthPrice: 30.74,
                      remainingMonthPrice: 30.55,
                    },
                  },
                ],
                fullRetailPrice: {
                  originalPrice: 1099.99,
                  contractText: 'Full Retail Price',
                },
                preferredTerm: 36,
                prepayPrice: {
                  originalPrice: 1099.99,
                  contractText: 'Prepay Price',
                },
              },
              sorId: 'MQ8R3LL/A',
              skuDisplayName: 'Apple iPhone 14 Pro Max 128GB in Deep Purple',
              inventoryDetails: {
                dFillInventory: {
                  isAvailable: false,
                  isBackorder: false,
                  isDeliverBy: false,
                  isPreOrder: false,
                  isShipBy: false,
                  isInStock: true,
                  locationCode: '9999999',
                  qtyAvailable: 41169,
                },
              },
              prodCode1: '5GD',
              prodCode2: 'SMT',
              prodCode3: 'DIG',
              prodCode4: 'VDS',
              prodCode5: 'ISL',
            },
          },
          {
            productId: 'dev19920011',
            specifications: {
              battery: null,
              depth: 0.31,
              height: 6.33,
              screenSize: '6.7"',
              size: '6.33,3.07,0.31',
              weight: 7.16,
              width: 3.07,
            },
            rating: {
              numberOfReviews: null,
              averageRating: null,
              productId: null,
              batteryLife: null,
              callQuality: null,
              design: null,
              display: null,
              easeOfUse: null,
              features: null,
              percentRecommended: null,
              performance: null,
            },
            brandName: 'Apple',
            productDisplayName: 'iPhone 14 Plus',
            sorDeviceType: '5GE',
            techSpecs: {
              'Video Playback': 'Up to 26 hrs.',
              Overall: 'Accessibility Shortcut, Siri, Guided Access, Per App Setting',
              'Wi-Fi': 'Yes',
              Screen:
                'Super Retina XDR display; 6.7-inch (diagonal) all-screen OLED display; 2778-by-1284-pixel resolution at 458 ppi',
              'Hearing Aid Compatibility': 'M3/T4',
              '5G Ultra Wideband': 'n260/ n261 (high-band / mmWave) | n77 (mid-band / C-band)',
              Depth: '0.31 in.',
              Weight: '7.16 oz.',
              Type: 'Built-in rechargeable lithium-ion battery',
              Storage: '128GB, 256GB, or 512GB (Subject to availability)',
              Auditory: 'Made for iPhone hearing devices, Sound Recognition, Headphone Accommodations, Live Captions',
              '4G': '13, 4, 2, 5, 66, 46, 48',
              Colors: 'Midnight, Purple, Starlight, (PRODUCT)RED, Blue, Yellow',
              'Usage Time': 'Streamed: Up to 20 hrs; Audio playback: Up to 100 hrs.',
              'Rear Camera':
                '12MP Main: 26 mm, ƒ/1.5 aperture, sensor-shift optical image stabilization, seven-element lens, 100% Focus Pixels',
              'Mobility/Cognitive': 'Voice Control, Switch Control, AssistiveTouch, Back Tap',
              'Global & Roaming Network':
                'LTE Roaming 1, 3, 7, 20, 28, 12, 26 | GSM/UMTS 850, 900, 1700/2100, 1900, 2100 MHz) | GSM/EDGE (850, 900, 1800, 1900 Mhz)',
              '5G Nationwide': 'n2/n5/n48/n66',
              'Operating System': 'Apple iOS',
              Height: '6.33 in.',
              Width: '3.07 in.',
              Visual: 'VoiceOver, Zoom, Color Filters, Spoken Content',
            },
            childSkus: [
              {
                skuId: 'sku5600258',
                color: {
                  colorCssStyle: '#1C3846',
                  colorId: 'clr9560003',
                  description: 'Black',
                  displayName: 'Midnight',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-midnight-fall22-a',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-midnight-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-midnight-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-midnight-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-midnight-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-plus-midnight-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 24.99,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $24.99/mo. for 36 months; 0% APR. Retail Price: $899.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 25.34,
                        remainingMonthPrice: 24.99,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 899.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 899.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ3R3LL/A',
                skuDisplayName: 'Apple iPhone 14 Plus 128GB in Midnight',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: false,
                    locationCode: '9999999',
                    qtyAvailable: 0,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600259',
                color: {
                  colorCssStyle: '#FAF6F2',
                  colorId: 'clr10520005',
                  description: 'White',
                  displayName: 'Starlight',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-starlight-fall22-a',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-starlight-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-starlight-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-starlight-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-starlight-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-plus-starlight-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 24.99,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $24.99/mo. for 36 months; 0% APR. Retail Price: $899.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 25.34,
                        remainingMonthPrice: 24.99,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 899.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 899.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ3T3LL/A',
                skuDisplayName: 'Apple iPhone 14 Plus 128GB in Starlight',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: false,
                    locationCode: '9999999',
                    qtyAvailable: 0,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600260',
                color: {
                  colorCssStyle: '#BCB3EA',
                  colorId: 'clr11800003',
                  description: 'Purple',
                  displayName: 'Purple',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-purple-fall22-a',
                  largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-purple-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-purple-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-purple-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-purple-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-plus-purple-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 24.99,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $24.99/mo. for 36 months; 0% APR. Retail Price: $899.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 25.34,
                        remainingMonthPrice: 24.99,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 899.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 899.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ3U3LL/A',
                skuDisplayName: 'Apple iPhone 14 Plus 128GB in Purple',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 78755,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600261',
                color: {
                  colorCssStyle: '#BF0013',
                  colorId: 'clr10560020',
                  description: 'Red',
                  displayName: '(PRODUCT)RED',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-productred-fall22-a',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-productred-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-productred-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-productred-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-productred-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-plus-productred-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 24.99,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $24.99/mo. for 36 months; 0% APR. Retail Price: $899.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 25.34,
                        remainingMonthPrice: 24.99,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 899.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 899.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ3V3LL/A',
                skuDisplayName: 'Apple iPhone 14 Plus 128GB in (PRODUCT) RED',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 50378,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600262',
                color: {
                  colorCssStyle: '#9BB0C3',
                  colorId: 'clr12200030',
                  description: 'Blue',
                  displayName: 'Blue  ',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-blue-fall22-a',
                  largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-blue-fall22-a?$device-lg$',
                  mediumImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-blue-fall22-a?$device-med$',
                  miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-blue-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-blue-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-plus-blue-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 24.99,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $24.99/mo. for 36 months; 0% APR. Retail Price: $899.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 25.34,
                        remainingMonthPrice: 24.99,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 899.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 899.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ3W3LL/A',
                skuDisplayName: 'Apple iPhone 14 Plus 128GB in Blue',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 57613,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600263',
                color: {
                  colorCssStyle: '#1C3846',
                  colorId: 'clr9560003',
                  description: 'Black',
                  displayName: 'Midnight',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-midnight-fall22-a',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-midnight-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-midnight-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-midnight-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-midnight-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-plus-midnight-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 27.77,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $27.77/mo. for 36 months; 0% APR. Retail Price: $999.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 28.04,
                        remainingMonthPrice: 27.77,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 999.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 999.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ3X3LL/A',
                skuDisplayName: 'Apple iPhone 14 Plus 256GB in Midnight',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: false,
                    locationCode: '9999999',
                    qtyAvailable: 0,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600264',
                color: {
                  colorCssStyle: '#FAF6F2',
                  colorId: 'clr10520005',
                  description: 'White',
                  displayName: 'Starlight',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-starlight-fall22-a',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-starlight-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-starlight-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-starlight-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-starlight-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-plus-starlight-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 27.77,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $27.77/mo. for 36 months; 0% APR. Retail Price: $999.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 28.04,
                        remainingMonthPrice: 27.77,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 999.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 999.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ3Y3LL/A',
                skuDisplayName: 'Apple iPhone 14 Plus 256GB in Starlight',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 49903,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600265',
                color: {
                  colorCssStyle: '#BCB3EA',
                  colorId: 'clr11800003',
                  description: 'Purple',
                  displayName: 'Purple',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-purple-fall22-a',
                  largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-purple-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-purple-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-purple-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-purple-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-plus-purple-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 27.77,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $27.77/mo. for 36 months; 0% APR. Retail Price: $999.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 28.04,
                        remainingMonthPrice: 27.77,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 999.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 999.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ403LL/A',
                skuDisplayName: 'Apple iPhone 14 Plus 256GB in Purple',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 49808,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600266',
                color: {
                  colorCssStyle: '#BF0013',
                  colorId: 'clr10560020',
                  description: 'Red',
                  displayName: '(PRODUCT)RED',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-productred-fall22-a',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-productred-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-productred-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-productred-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-productred-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-plus-productred-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 27.77,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $27.77/mo. for 36 months; 0% APR. Retail Price: $999.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 28.04,
                        remainingMonthPrice: 27.77,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 999.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 999.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ413LL/A',
                skuDisplayName: 'Apple iPhone 14 Plus 256GB in (PRODUCT) RED',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 49852,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600267',
                color: {
                  colorCssStyle: '#9BB0C3',
                  colorId: 'clr12200030',
                  description: 'Blue',
                  displayName: 'Blue  ',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-blue-fall22-a',
                  largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-blue-fall22-a?$device-lg$',
                  mediumImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-blue-fall22-a?$device-med$',
                  miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-blue-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-blue-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-plus-blue-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 27.77,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $27.77/mo. for 36 months; 0% APR. Retail Price: $999.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 28.04,
                        remainingMonthPrice: 27.77,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 999.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 999.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ423LL/A',
                skuDisplayName: 'Apple iPhone 14 Plus 256GB in Blue',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 49819,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5910364',
                color: {
                  colorCssStyle: '#F9E479',
                  colorId: 'clr13040001',
                  description: 'Yellow',
                  displayName: 'Yellow',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-yellow-spring2023',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-yellow-spring2023?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-yellow-spring2023?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-yellow-spring2023?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-yellow-spring2023?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-plus-yellow-spring2023_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 24.99,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $24.99/mo. for 36 months; 0% APR. Retail Price: $899.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 25.34,
                        remainingMonthPrice: 24.99,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 899.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 899.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MR5N3LL/A',
                skuDescription: ' ',
                skuDisplayName: 'Apple iPhone 14 Plus 128GB in Yellow',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: false,
                    locationCode: '9999999',
                    qtyAvailable: 0,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5910360',
                color: {
                  colorCssStyle: '#F9E479',
                  colorId: 'clr13040001',
                  description: 'Yellow',
                  displayName: 'Yellow',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-yellow-spring2023',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-yellow-spring2023?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-yellow-spring2023?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-yellow-spring2023?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-yellow-spring2023?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-plus-yellow-spring2023_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 27.77,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $27.77/mo. for 36 months; 0% APR. Retail Price: $999.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 28.04,
                        remainingMonthPrice: 27.77,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 999.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 999.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MR5T3LL/A',
                skuDescription: ' ',
                skuDisplayName: 'Apple iPhone 14 Plus 256GB in Yellow',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: false,
                    locationCode: '9999999',
                    qtyAvailable: 0,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5910354',
                color: {
                  colorCssStyle: '#F9E479',
                  colorId: 'clr13040001',
                  description: 'Yellow',
                  displayName: 'Yellow',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-yellow-spring2023',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-yellow-spring2023?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-yellow-spring2023?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-yellow-spring2023?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-yellow-spring2023?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-plus-yellow-spring2023_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 33.33,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $33.33/mo. for 36 months; 0% APR. Retail Price: $1199.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 33.44,
                        remainingMonthPrice: 33.33,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 1199.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 1199.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MR5W3LL/A',
                skuDescription: ' ',
                skuDisplayName: 'Apple iPhone 14 Plus 512GB in Yellow',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: true,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: true,
                    isInStock: false,
                    locationCode: '9999999',
                    qtyAvailable: 0,
                    shippingDate: {
                      date: '05/26/2023',
                      dateTime: '05-26-2023 07:00:00 AM',
                      dateLong: 1685084400000,
                    },
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600268',
                color: {
                  colorCssStyle: '#1C3846',
                  colorId: 'clr9560003',
                  description: 'Black',
                  displayName: 'Midnight',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-midnight-fall22-a',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-midnight-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-midnight-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-midnight-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-midnight-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-plus-midnight-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 33.33,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $33.33/mo. for 36 months; 0% APR. Retail Price: $1199.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 33.44,
                        remainingMonthPrice: 33.33,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 1199.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 1199.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ433LL/A',
                skuDisplayName: 'Apple iPhone 14 Plus 512GB in Midnight',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: false,
                    locationCode: '9999999',
                    qtyAvailable: 0,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600269',
                color: {
                  colorCssStyle: '#FAF6F2',
                  colorId: 'clr10520005',
                  description: 'White',
                  displayName: 'Starlight',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-starlight-fall22-a',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-starlight-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-starlight-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-starlight-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-starlight-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-plus-starlight-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 33.33,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $33.33/mo. for 36 months; 0% APR. Retail Price: $1199.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 33.44,
                        remainingMonthPrice: 33.33,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 1199.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 1199.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ443LL/A',
                skuDisplayName: 'Apple iPhone 14 Plus 512GB in Starlight',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: true,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: true,
                    isInStock: false,
                    locationCode: '9999999',
                    qtyAvailable: 0,
                    shippingDate: {
                      date: '12/12/2023',
                      dateTime: '12-12-2023 08:00:00 AM',
                      dateLong: 1702368000000,
                    },
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600270',
                color: {
                  colorCssStyle: '#BCB3EA',
                  colorId: 'clr11800003',
                  description: 'Purple',
                  displayName: 'Purple',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-purple-fall22-a',
                  largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-purple-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-purple-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-purple-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-purple-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-plus-purple-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 33.33,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $33.33/mo. for 36 months; 0% APR. Retail Price: $1199.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 33.44,
                        remainingMonthPrice: 33.33,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 1199.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 1199.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ463LL/A',
                skuDisplayName: 'Apple iPhone 14 Plus 512GB in Purple',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 49917,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600271',
                color: {
                  colorCssStyle: '#BF0013',
                  colorId: 'clr10560020',
                  description: 'Red',
                  displayName: '(PRODUCT)RED',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-productred-fall22-a',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-productred-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-productred-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-productred-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-productred-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-plus-productred-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 33.33,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $33.33/mo. for 36 months; 0% APR. Retail Price: $1199.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 33.44,
                        remainingMonthPrice: 33.33,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 1199.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 1199.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ473LL/A',
                skuDisplayName: 'Apple iPhone 14 Plus 512GB in (PRODUCT) RED',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 49874,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
              {
                skuId: 'sku5600272',
                color: {
                  colorCssStyle: '#9BB0C3',
                  colorId: 'clr12200030',
                  description: 'Blue',
                  displayName: 'Blue  ',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-blue-fall22-a',
                  largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-blue-fall22-a?$device-lg$',
                  mediumImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-blue-fall22-a?$device-med$',
                  miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-blue-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-blue-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-plus-blue-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 33.33,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $33.33/mo. for 36 months; 0% APR. Retail Price: $1199.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 33.44,
                        remainingMonthPrice: 33.33,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 1199.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 1199.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ493LL/A',
                skuDisplayName: 'Apple iPhone 14 Plus 512GB in Blue',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: false,
                    locationCode: '9999999',
                    qtyAvailable: 0,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
            ],
            defaultSKU: 'MQ3U3LL/A',
            seo: {
              canonicalUrl: 'smartphones/apple-iphone-14-plus/',
            },
            defaultSKUObj: {
              skuId: 'sku5600260',
              color: {
                colorCssStyle: '#BCB3EA',
                colorId: 'clr11800003',
                description: 'Purple',
                displayName: 'Purple',
              },
              imageUrlMap: {
                defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-purple-fall22-a',
                largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-purple-fall22-a?$device-lg$',
                mediumImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-purple-fall22-a?$device-med$',
                miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-purple-fall22-a?$device-mini$',
                thumbImage:
                  'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-plus-purple-fall22-a?$device-thumb$',
                imageSetUrl:
                  'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-plus-purple-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
              },
              price: {
                devicePaymentPrice: [
                  {
                    originalPrice: 24.99,
                    contractDuration: 36,
                    contractText:
                      'Monthly payments shown are for customers who qualify to pay $0 Down, $24.99/mo. for 36 months; 0% APR. Retail Price: $899.99',
                    dpTermPrices: {
                      downPayment: 0,
                      downPaymentRequired: false,
                      upgradeOptionPercentage: 50,
                      upgradeOptionCode: 'UO',
                      dpTerm: 36,
                      ugradeEligibilityCategory: [
                        {
                          categoryCode: '4',
                          categories: ['5G Smartphone~4G Smartphone'],
                        },
                      ],
                      firstMonthPrice: 25.34,
                      remainingMonthPrice: 24.99,
                    },
                  },
                ],
                fullRetailPrice: {
                  originalPrice: 899.99,
                  contractText: 'Full Retail Price',
                },
                preferredTerm: 36,
                prepayPrice: {
                  originalPrice: 899.99,
                  contractText: 'Prepay Price',
                },
              },
              sorId: 'MQ3U3LL/A',
              skuDisplayName: 'Apple iPhone 14 Plus 128GB in Purple',
              inventoryDetails: {
                dFillInventory: {
                  isAvailable: false,
                  isBackorder: false,
                  isDeliverBy: false,
                  isPreOrder: false,
                  isShipBy: false,
                  isInStock: true,
                  locationCode: '9999999',
                  qtyAvailable: 78755,
                },
              },
              prodCode1: '5GD',
              prodCode2: 'SMT',
              prodCode3: 'DIG',
              prodCode4: 'VDS',
              prodCode5: 'ISL',
            },
          },
          null,
          null,
          null,
        ],
        deviceList: {
          data: {
            Apple: [
              {
                productId: 'dev20360003',
                productDisplayName: 'iPad (10th Generation)',
                brandName: 'Apple',
              },
              {
                productId: 'dev20360001',
                productDisplayName: 'iPad Pro 11-inch (4th Generation)',
                brandName: 'Apple',
              },
              {
                productId: 'dev20360002',
                productDisplayName: 'iPad Pro 12.9-inch (6th Generation)',
                brandName: 'Apple',
              },
              {
                productId: 'dev19920011',
                productDisplayName: 'iPhone 14 Plus',
                brandName: 'Apple',
              },
              {
                productId: 'dev19920006',
                productDisplayName: 'iPhone 14 Pro Max',
                brandName: 'Apple',
              },
              {
                productId: 'dev19920002',
                productDisplayName: 'iPhone 14',
                brandName: 'Apple',
              },
              {
                productId: 'dev19920005',
                productDisplayName: 'iPhone 14 Pro',
                brandName: 'Apple',
              },
              {
                productId: 'dev20000011',
                productDisplayName: 'Watch Series 8 45mm Gold Stainless Steel Case with Gold Milanese Loop',
                brandName: 'Apple',
              },
              {
                productId: 'dev20000026',
                productDisplayName: 'Watch Series 8 41mm Starlight Aluminum Case Starlight Sport Band - SM',
                brandName: 'Apple',
              },
              {
                productId: 'dev20000027',
                productDisplayName: 'Watch Series 8 41mm Starlight Aluminum Case Starlight Sport Band - ML',
                brandName: 'Apple',
              },
              {
                productId: 'dev20000031',
                productDisplayName: 'Watch Series 8 41mm Silver Stainless Steel Case with White Sport Band - SM',
                brandName: 'Apple',
              },
              {
                productId: 'dev20000037',
                productDisplayName: 'Watch Series 8 41mm Gold Stainless Steel Case with Starlight Sport Band - ML',
                brandName: 'Apple',
              },
              {
                productId: 'dev20000028',
                productDisplayName: 'Watch Series 8 41mm (PRODUCT)RED Aluminum Case with (PRODUCT)RED Sport Band - SM',
                brandName: 'Apple',
              },
              {
                productId: 'dev20000070',
                productDisplayName: 'Watch Series 8 41mm Graphite Stainless Steel Case with Midnight Sport Band - SM',
                brandName: 'Apple',
              },
              {
                productId: 'dev20000048',
                productDisplayName: 'Watch Series 8 45mm (PRODUCT)RED Aluminum Case with (PRODUCT)RED Sport Band - ML',
                brandName: 'Apple',
              },
              {
                productId: 'dev20000060',
                productDisplayName: 'Watch Series 8 45mm Gold Stainless Steel Case with Starlight Sport Band - SM',
                brandName: 'Apple',
              },
              {
                productId: 'dev20000063',
                productDisplayName: 'Watch Series 8 45mm Graphite Stainless Steel Case with Midnight Sport Band - ML',
                brandName: 'Apple',
              },
              {
                productId: 'dev20000066',
                productDisplayName: 'Watch Series 8 45mm Silver Aluminum Case with White Sport Band - SM',
                brandName: 'Apple',
              },
              {
                productId: 'dev19920009',
                productDisplayName: 'Watch SE (2nd Gen)',
                brandName: 'Apple',
              },
              {
                productId: 'dev19960038',
                productDisplayName: 'Watch SE (2nd Gen) 40mm Midnight Aluminum Case with Midnight Sport Band - ML',
                brandName: 'Apple',
              },
              {
                productId: 'dev19960018',
                productDisplayName: 'Watch Ultra 49mm Titanium Case with Midnight Ocean Band',
                brandName: 'Apple',
              },
              {
                productId: 'dev19960039',
                productDisplayName: 'Watch SE (2nd Gen) 40mm Silver Aluminum Case with White Sport Band - SM',
                brandName: 'Apple',
              },
              {
                productId: 'dev20000064',
                productDisplayName: 'Watch Series 8 41mm Silver Aluminum Case with White Sport Band - SM',
                brandName: 'Apple',
              },
              {
                productId: 'dev20000039',
                productDisplayName: 'Watch Series 8 41mm Graphite Stainless Steel Case with Midnight Sport Band - ML',
                brandName: 'Apple',
              },
            ],
          },
        },
      },
    };

    render(<CompareGridwallDevices {...props} {...props2} />);
    const imageClick = screen.getByTestId('compareGridwallDevices');
    expect(imageClick).toBeInTheDocument();
  });
});

describe('CompareGridwallDevices component', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE']);
    isVbg.mockReturnValue(false);
    getPricingPriority.mockReturnValue(null);
  });
  const baseProduct = {
              productId: 'dev19920005',
              specifications: {
                battery: null,
                depth: 0.31,
                height: 5.81,
                screenSize: '6.1"',
                size: '5.81,2.81,0.31',
                weight: 7.27,
                width: 2.81,
              },
              rating: {
                numberOfReviews: null,
                averageRating: null,
                productId: null,
                batteryLife: null,
                callQuality: null,
                design: null,
                display: null,
                easeOfUse: null,
                features: null,
                percentRecommended: null,
                performance: null,
              },
              brandName: 'Apple',
              productDisplayName: 'iPhone 14 Pro',
              sorDeviceType: '5GE',
              techSpecs: {
                'Video Playback': 'Up to 23 hrs.',
                Overall: 'Accessibility Shortcut, Siri, Guided Access, Per App Setting',
                'Wi-Fi': 'Yes',
                Screen:
                  'Super Retina XDR display; 6.1-inch (diagonal) all-screen OLED display; 2556-by-1179-pixel resolution at 460 ppi',
                '5G Ultra Wideband': 'n260/ n261 (high-band / mmWave) | n77 (mid-band / C-band)',
                'Hearing Aid Compatibility': 'M3/T4',
                Depth: '0.31 in.',
                Weight: '7.27 oz.',
                Type: 'Built-in rechargeable lithium-ion battery',
                '4G': '13, 4, 2, 5, 66, 46, 48',
                Colors: 'Space Black, Silver, Gold, Deep Purple',
                Storage: '128GB, 256GB, 512GB, 1TB (Subject to availability)',
                Auditory: 'Made for iPhone hearing devices, Sound Recognition, Headphone Accommodations, Live Captions',
                'Usage Time': 'Streamed: Up to 20 hrs; Audio playback: Up to 75 hrs.',
                'Rear Camera':
                  'Main: 24 mm, ƒ/1.78 aperture, second-generation sensor-shift optical image stabilization, seven-element lens, 100% Focus Pixels',
                'Mobility/Cognitive': 'Voice Control, Switch Control, AssistiveTouch, Back Tap',
                'FCC ID': 'BCG-E4000A',
                'Global & Roaming Network':
                  'LTE Roaming 1, 3, 7, 20, 28, 12, 26 | GSM/UMTS 850, 900, 1700/2100, 1900, 2100 MHz) | GSM/EDGE (850, 900, 1800, 1900 Mhz)',
                '5G Nationwide': 'n2/n5/n48/n66',
                Height: '5.81 in.',
                'Operating System': 'Apple iOS',
                camera: '48MP ',
                Width: '2.81 in.',
                Visual: 'VoiceOver, Zoom, Color Filters, Spoken Content',
              },
              childSkus: [
                {
                  skuId: 'sku5600273',
                  color: {
                    colorCssStyle: '#1E1D1B',
                    colorId: 'clr12240018',
                    description: 'Black',
                    displayName: 'Space Black',
                  },
                  imageUrlMap: {
                    defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a',
                    largeImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-lg$',
                    mediumImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-med$',
                    miniImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-mini$',
                    thumbImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-thumb$',
                    imageSetUrl:
                      'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                  },
                  price: {
                    fullRetailPrice: {
                      originalPrice: 999.99,
                      contractText: 'Full Retail Price',
                    },
                    prepayPrice: {
                      originalPrice: 999.99,
                      contractText: 'Prepay Price',
                    },
                  },
                  sorId: 'MPXT3LL/A',
                  skuDisplayName: 'iPhone 14 Pro 128GB in Space Black',
                  inventoryDetails: {
                    dFillInventory: {
                      isAvailable: false,
                      isBackorder: false,
                      isDeliverBy: false,
                      isPreOrder: false,
                      isShipBy: false,
                      isInStock: true,
                      locationCode: '9999999',
                      qtyAvailable: 51969,
                    },
                  },
                  prodCode1: '5GD',
                  prodCode2: 'SMT',
                  prodCode3: 'DIG',
                  prodCode4: 'VDS',
                  prodCode5: 'ISL',
                },
                {
                  skuId: 'sku5600274',
                  color: {
                    colorCssStyle: '#C0C0C0',
                    colorId: 'clr40012',
                    description: 'Silver',
                    displayName: 'Silver',
                  },
                  imageUrlMap: {
                    defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a',
                    largeImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-lg$',
                    mediumImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-med$',
                    miniImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-mini$',
                    thumbImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-thumb$',
                    imageSetUrl:
                      'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                  },
                  price: {
                    devicePaymentPrice: [
                      {
                        originalPrice: 27.77,
                        contractDuration: 36,
                        contractText:
                          'Monthly payments shown are for customers who qualify to pay $0 Down, $27.77/mo. for 36 months; 0% APR. Retail Price: $999.99',
                        dpTermPrices: {
                          downPayment: 0,
                          downPaymentRequired: false,
                          upgradeOptionPercentage: 50,
                          upgradeOptionCode: 'UO',
                          dpTerm: 36,
                          ugradeEligibilityCategory: [
                            {
                              categoryCode: '4',
                              categories: ['5G Smartphone~4G Smartphone'],
                            },
                          ],
                          firstMonthPrice: 28.04,
                          remainingMonthPrice: 27.77,
                        },
                      },
                    ],
                    fullRetailPrice: {
                      originalPrice: 999.99,
                      contractText: 'Full Retail Price',
                    },
                    preferredTerm: 36,
                    prepayPrice: {
                      originalPrice: 999.99,
                      contractText: 'Prepay Price',
                    },
                  },
                  sorId: 'MQ003LL/A',
                  skuDisplayName: 'iPhone 14 Pro 128GB in Silver',
                  inventoryDetails: {
                    dFillInventory: {
                      isAvailable: false,
                      isBackorder: false,
                      isDeliverBy: false,
                      isPreOrder: false,
                      isShipBy: false,
                      isInStock: true,
                      locationCode: '9999999',
                      qtyAvailable: 52841,
                    },
                  },
                  prodCode1: '5GD',
                  prodCode2: 'SMT',
                  prodCode3: 'DIG',
                  prodCode4: 'VDS',
                  prodCode5: 'ISL',
                },
                {
                  skuId: 'sku5600275',
                  color: {
                    colorCssStyle: '#D0C2AE',
                    colorId: 'clr3360032',
                    description: 'Gold',
                    displayName: 'Gold',
                  },
                  imageUrlMap: {
                    defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a',
                    largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-lg$',
                    mediumImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-med$',
                    miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-mini$',
                    thumbImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-thumb$',
                    imageSetUrl:
                      'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                  },
                  price: {
                    devicePaymentPrice: [
                      {
                        originalPrice: 27.77,
                        contractDuration: 36,
                        contractText:
                          'Monthly payments shown are for customers who qualify to pay $0 Down, $27.77/mo. for 36 months; 0% APR. Retail Price: $999.99',
                        dpTermPrices: {
                          downPayment: 0,
                          downPaymentRequired: false,
                          upgradeOptionPercentage: 50,
                          upgradeOptionCode: 'UO',
                          dpTerm: 36,
                          ugradeEligibilityCategory: [
                            {
                              categoryCode: '4',
                              categories: ['5G Smartphone~4G Smartphone'],
                            },
                          ],
                          firstMonthPrice: 28.04,
                          remainingMonthPrice: 27.77,
                        },
                      },
                    ],
                    fullRetailPrice: {
                      originalPrice: 999.99,
                      contractText: 'Full Retail Price',
                    },
                    preferredTerm: 36,
                    prepayPrice: {
                      originalPrice: 999.99,
                      contractText: 'Prepay Price',
                    },
                  },
                  sorId: 'MQ063LL/A',
                  skuDisplayName: 'iPhone 14 Pro 128GB in Gold',
                  inventoryDetails: {
                    dFillInventory: {
                      isAvailable: false,
                      isBackorder: false,
                      isDeliverBy: false,
                      isPreOrder: true,
                      isShipBy: true,
                      isInStock: false,
                      locationCode: '9999999',
                      qtyAvailable: 0,
                      shippingDate: {
                        date: '12/29/2023',
                        dateTime: '12-29-2023 08:00:00 AM',
                        dateLong: 1703836800000,
                      },
                    },
                  },
                  prodCode1: '5GD',
                  prodCode2: 'SMT',
                  prodCode3: 'DIG',
                  prodCode4: 'VDS',
                  prodCode5: 'ISL',
                },
                {
                  skuId: 'sku5600276',
                  color: {
                    colorCssStyle: '#655D6C',
                    colorId: 'clr12200029',
                    description: 'Purple',
                    displayName: 'Deep Purple',
                  },
                  imageUrlMap: {
                    defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a',
                    largeImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-lg$',
                    mediumImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-med$',
                    miniImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-mini$',
                    thumbImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-thumb$',
                    imageSetUrl:
                      'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                  },
                  price: {
                    devicePaymentPrice: [
                      {
                        originalPrice: 27.77,
                        contractDuration: 36,
                        contractText:
                          'Monthly payments shown are for customers who qualify to pay $0 Down, $27.77/mo. for 36 months; 0% APR. Retail Price: $999.99',
                        dpTermPrices: {
                          downPayment: 0,
                          downPaymentRequired: false,
                          upgradeOptionPercentage: 50,
                          upgradeOptionCode: 'UO',
                          dpTerm: 36,
                          ugradeEligibilityCategory: [
                            {
                              categoryCode: '4',
                              categories: ['5G Smartphone~4G Smartphone'],
                            },
                          ],
                          firstMonthPrice: 28.04,
                          remainingMonthPrice: 27.77,
                        },
                      },
                    ],
                    fullRetailPrice: {
                      originalPrice: 999.99,
                      contractText: 'Full Retail Price',
                    },
                    preferredTerm: 36,
                    prepayPrice: {
                      originalPrice: 999.99,
                      contractText: 'Prepay Price',
                    },
                  },
                  sorId: 'MQ0E3LL/A',
                  skuDisplayName: 'iPhone 14 Pro 128GB in Deep Purple',
                  inventoryDetails: {
                    dFillInventory: {
                      isAvailable: false,
                      isBackorder: false,
                      isDeliverBy: false,
                      isPreOrder: false,
                      isShipBy: false,
                      isInStock: true,
                      locationCode: '9999999',
                      qtyAvailable: 47025,
                    },
                  },
                  prodCode1: '5GD',
                  prodCode2: 'SMT',
                  prodCode3: 'DIG',
                  prodCode4: 'VDS',
                  prodCode5: 'ISL',
                },
                {
                  skuId: 'sku5600277',
                  color: {
                    colorCssStyle: '#1E1D1B',
                    colorId: 'clr12240018',
                    description: 'Black',
                    displayName: 'Space Black',
                  },
                  imageUrlMap: {
                    defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a',
                    largeImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-lg$',
                    mediumImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-med$',
                    miniImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-mini$',
                    thumbImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-thumb$',
                    imageSetUrl:
                      'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                  },
                  price: {
                    devicePaymentPrice: [
                      {
                        originalPrice: 30.55,
                        contractDuration: 36,
                        contractText:
                          'Monthly payments shown are for customers who qualify to pay $0 Down, $30.55/mo. for 36 months; 0% APR. Retail Price: $1099.99',
                        dpTermPrices: {
                          downPayment: 0,
                          downPaymentRequired: false,
                          upgradeOptionPercentage: 50,
                          upgradeOptionCode: 'UO',
                          dpTerm: 36,
                          ugradeEligibilityCategory: [
                            {
                              categoryCode: '4',
                              categories: ['5G Smartphone~4G Smartphone'],
                            },
                          ],
                          firstMonthPrice: 30.74,
                          remainingMonthPrice: 30.55,
                        },
                      },
                    ],
                    fullRetailPrice: {
                      originalPrice: 1099.99,
                      contractText: 'Full Retail Price',
                    },
                    preferredTerm: 36,
                    prepayPrice: {
                      originalPrice: 1099.99,
                      contractText: 'Prepay Price',
                    },
                  },
                  sorId: 'MQ0N3LL/A',
                  skuDisplayName: 'iPhone 14 Pro 256GB in Space Black',
                  inventoryDetails: {
                    dFillInventory: {
                      isAvailable: false,
                      isBackorder: false,
                      isDeliverBy: false,
                      isPreOrder: false,
                      isShipBy: false,
                      isInStock: true,
                      locationCode: '9999999',
                      qtyAvailable: 49578,
                    },
                  },
                  prodCode1: '5GD',
                  prodCode2: 'SMT',
                  prodCode3: 'DIG',
                  prodCode4: 'VDS',
                  prodCode5: 'ISL',
                },
                {
                  skuId: 'sku5600278',
                  color: {
                    colorCssStyle: '#C0C0C0',
                    colorId: 'clr40012',
                    description: 'Silver',
                    displayName: 'Silver',
                  },
                  imageUrlMap: {
                    defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a',
                    largeImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-lg$',
                    mediumImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-med$',
                    miniImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-mini$',
                    thumbImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-thumb$',
                    imageSetUrl:
                      'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                  },
                  price: {
                    devicePaymentPrice: [
                      {
                        originalPrice: 30.55,
                        contractDuration: 36,
                        contractText:
                          'Monthly payments shown are for customers who qualify to pay $0 Down, $30.55/mo. for 36 months; 0% APR. Retail Price: $1099.99',
                        dpTermPrices: {
                          downPayment: 0,
                          downPaymentRequired: false,
                          upgradeOptionPercentage: 50,
                          upgradeOptionCode: 'UO',
                          dpTerm: 36,
                          ugradeEligibilityCategory: [
                            {
                              categoryCode: '4',
                              categories: ['5G Smartphone~4G Smartphone'],
                            },
                          ],
                          firstMonthPrice: 30.74,
                          remainingMonthPrice: 30.55,
                        },
                      },
                    ],
                    fullRetailPrice: {
                      originalPrice: 1099.99,
                      contractText: 'Full Retail Price',
                    },
                    preferredTerm: 36,
                    prepayPrice: {
                      originalPrice: 1099.99,
                      contractText: 'Prepay Price',
                    },
                  },
                  sorId: 'MQ0X3LL/A',
                  skuDisplayName: 'iPhone 14 Pro 256GB in Silver',
                  inventoryDetails: {
                    dFillInventory: {
                      isAvailable: false,
                      isBackorder: false,
                      isDeliverBy: false,
                      isPreOrder: false,
                      isShipBy: false,
                      isInStock: true,
                      locationCode: '9999999',
                      qtyAvailable: 52868,
                    },
                  },
                  prodCode1: '5GD',
                  prodCode2: 'SMT',
                  prodCode3: 'DIG',
                  prodCode4: 'VDS',
                  prodCode5: 'ISL',
                },
                {
                  skuId: 'sku5600279',
                  color: {
                    colorCssStyle: '#D0C2AE',
                    colorId: 'clr3360032',
                    description: 'Gold',
                    displayName: 'Gold',
                  },
                  imageUrlMap: {
                    defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a',
                    largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-lg$',
                    mediumImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-med$',
                    miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-mini$',
                    thumbImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-thumb$',
                    imageSetUrl:
                      'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                  },
                  price: {
                    devicePaymentPrice: [
                      {
                        originalPrice: 30.55,
                        contractDuration: 36,
                        contractText:
                          'Monthly payments shown are for customers who qualify to pay $0 Down, $30.55/mo. for 36 months; 0% APR. Retail Price: $1099.99',
                        dpTermPrices: {
                          downPayment: 0,
                          downPaymentRequired: false,
                          upgradeOptionPercentage: 50,
                          upgradeOptionCode: 'UO',
                          dpTerm: 36,
                          ugradeEligibilityCategory: [
                            {
                              categoryCode: '4',
                              categories: ['5G Smartphone~4G Smartphone'],
                            },
                          ],
                          firstMonthPrice: 30.74,
                          remainingMonthPrice: 30.55,
                        },
                      },
                    ],
                    fullRetailPrice: {
                      originalPrice: 1099.99,
                      contractText: 'Full Retail Price',
                    },
                    preferredTerm: 36,
                    prepayPrice: {
                      originalPrice: 1099.99,
                      contractText: 'Prepay Price',
                    },
                  },
                  sorId: 'MQ163LL/A',
                  skuDisplayName: 'iPhone 14 Pro 256GB in Gold',
                  inventoryDetails: {
                    dFillInventory: {
                      isAvailable: false,
                      isBackorder: false,
                      isDeliverBy: false,
                      isPreOrder: false,
                      isShipBy: false,
                      isInStock: true,
                      locationCode: '9999999',
                      qtyAvailable: 49849,
                    },
                  },
                  prodCode1: '5GD',
                  prodCode2: 'SMT',
                  prodCode3: 'DIG',
                  prodCode4: 'VDS',
                  prodCode5: 'ISL',
                },
                {
                  skuId: 'sku5600280',
                  color: {
                    colorCssStyle: '#655D6C',
                    colorId: 'clr12200029',
                    description: 'Purple',
                    displayName: 'Deep Purple',
                  },
                  imageUrlMap: {
                    defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a',
                    largeImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-lg$',
                    mediumImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-med$',
                    miniImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-mini$',
                    thumbImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-thumb$',
                    imageSetUrl:
                      'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                  },
                  price: {
                    devicePaymentPrice: [
                      {
                        originalPrice: 30.55,
                        contractDuration: 36,
                        contractText:
                          'Monthly payments shown are for customers who qualify to pay $0 Down, $30.55/mo. for 36 months; 0% APR. Retail Price: $1099.99',
                        dpTermPrices: {
                          downPayment: 0,
                          downPaymentRequired: false,
                          upgradeOptionPercentage: 50,
                          upgradeOptionCode: 'UO',
                          dpTerm: 36,
                          ugradeEligibilityCategory: [
                            {
                              categoryCode: '4',
                              categories: ['5G Smartphone~4G Smartphone'],
                            },
                          ],
                          firstMonthPrice: 30.74,
                          remainingMonthPrice: 30.55,
                        },
                      },
                    ],
                    fullRetailPrice: {
                      originalPrice: 1099.99,
                      contractText: 'Full Retail Price',
                    },
                    preferredTerm: 36,
                    prepayPrice: {
                      originalPrice: 1099.99,
                      contractText: 'Prepay Price',
                    },
                  },
                  sorId: 'MQ1D3LL/A',
                  skuDisplayName: 'iPhone 14 Pro 256GB in Deep Purple',
                  inventoryDetails: {
                    dFillInventory: {
                      isAvailable: false,
                      isBackorder: false,
                      isDeliverBy: false,
                      isPreOrder: false,
                      isShipBy: false,
                      isInStock: true,
                      locationCode: '9999999',
                      qtyAvailable: 49767,
                    },
                  },
                  prodCode1: '5GD',
                  prodCode2: 'SMT',
                  prodCode3: 'DIG',
                  prodCode4: 'VDS',
                  prodCode5: 'ISL',
                },
                {
                  skuId: 'sku5600180',
                  color: {
                    colorCssStyle: '#1E1D1B',
                    colorId: 'clr12240018',
                    description: 'Black',
                    displayName: 'Space Black',
                  },
                  imageUrlMap: {
                    defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a',
                    largeImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-lg$',
                    mediumImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-med$',
                    miniImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-mini$',
                    thumbImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-thumb$',
                    imageSetUrl:
                      'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                  },
                  price: {
                    devicePaymentPrice: [
                      {
                        originalPrice: 36.11,
                        contractDuration: 36,
                        contractText:
                          'Monthly payments shown are for customers who qualify to pay $0 Down, $36.11/mo. for 36 months; 0% APR. Retail Price: $1299.99',
                        dpTermPrices: {
                          downPayment: 0,
                          downPaymentRequired: false,
                          upgradeOptionPercentage: 50,
                          upgradeOptionCode: 'UO',
                          dpTerm: 36,
                          ugradeEligibilityCategory: [
                            {
                              categoryCode: '4',
                              categories: ['5G Smartphone~4G Smartphone'],
                            },
                          ],
                          firstMonthPrice: 36.14,
                          remainingMonthPrice: 36.11,
                        },
                      },
                    ],
                    fullRetailPrice: {
                      originalPrice: 1299.99,
                      contractText: 'Full Retail Price',
                    },
                    preferredTerm: 36,
                    prepayPrice: {
                      originalPrice: 1299.99,
                      contractText: 'Prepay Price',
                    },
                  },
                  sorId: 'MQ1K3LL/A',
                  skuDisplayName: 'iPhone 14 Pro 512GB in Space Black',
                  inventoryDetails: {
                    dFillInventory: {
                      isAvailable: false,
                      isBackorder: false,
                      isDeliverBy: false,
                      isPreOrder: false,
                      isShipBy: false,
                      isInStock: true,
                      locationCode: '9999999',
                      qtyAvailable: 49686,
                    },
                  },
                  prodCode1: '5GD',
                  prodCode2: 'SMT',
                  prodCode3: 'DIG',
                  prodCode4: 'VDS',
                  prodCode5: 'ISL',
                },
                {
                  skuId: 'sku5600281',
                  color: {
                    colorCssStyle: '#C0C0C0',
                    colorId: 'clr40012',
                    description: 'Silver',
                    displayName: 'Silver',
                  },
                  imageUrlMap: {
                    defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a',
                    largeImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-lg$',
                    mediumImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-med$',
                    miniImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-mini$',
                    thumbImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-thumb$',
                    imageSetUrl:
                      'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                  },
                  price: {
                    devicePaymentPrice: [
                      {
                        originalPrice: 36.11,
                        contractDuration: 36,
                        contractText:
                          'Monthly payments shown are for customers who qualify to pay $0 Down, $36.11/mo. for 36 months; 0% APR. Retail Price: $1299.99',
                        dpTermPrices: {
                          downPayment: 0,
                          downPaymentRequired: false,
                          upgradeOptionPercentage: 50,
                          upgradeOptionCode: 'UO',
                          dpTerm: 36,
                          ugradeEligibilityCategory: [
                            {
                              categoryCode: '4',
                              categories: ['5G Smartphone~4G Smartphone'],
                            },
                          ],
                          firstMonthPrice: 36.14,
                          remainingMonthPrice: 36.11,
                        },
                      },
                    ],
                    fullRetailPrice: {
                      originalPrice: 1299.99,
                      contractText: 'Full Retail Price',
                    },
                    preferredTerm: 36,
                    prepayPrice: {
                      originalPrice: 1299.99,
                      contractText: 'Prepay Price',
                    },
                  },
                  sorId: 'MQ1U3LL/A',
                  skuDisplayName: 'iPhone 14 Pro 512GB in Silver',
                  inventoryDetails: {
                    dFillInventory: {
                      isAvailable: false,
                      isBackorder: false,
                      isDeliverBy: false,
                      isPreOrder: false,
                      isShipBy: false,
                      isInStock: true,
                      locationCode: '9999999',
                      qtyAvailable: 59951,
                    },
                  },
                  prodCode1: '5GD',
                  prodCode2: 'SMT',
                  prodCode3: 'DIG',
                  prodCode4: 'VDS',
                  prodCode5: 'ISL',
                },
                {
                  skuId: 'sku5600282',
                  color: {
                    colorCssStyle: '#D0C2AE',
                    colorId: 'clr3360032',
                    description: 'Gold',
                    displayName: 'Gold',
                  },
                  imageUrlMap: {
                    defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a',
                    largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-lg$',
                    mediumImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-med$',
                    miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-mini$',
                    thumbImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-thumb$',
                    imageSetUrl:
                      'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                  },
                  price: {
                    devicePaymentPrice: [
                      {
                        originalPrice: 36.11,
                        contractDuration: 36,
                        contractText:
                          'Monthly payments shown are for customers who qualify to pay $0 Down, $36.11/mo. for 36 months; 0% APR. Retail Price: $1299.99',
                        dpTermPrices: {
                          downPayment: 0,
                          downPaymentRequired: false,
                          upgradeOptionPercentage: 50,
                          upgradeOptionCode: 'UO',
                          dpTerm: 36,
                          ugradeEligibilityCategory: [
                            {
                              categoryCode: '4',
                              categories: ['5G Smartphone~4G Smartphone'],
                            },
                          ],
                          firstMonthPrice: 36.14,
                          remainingMonthPrice: 36.11,
                        },
                      },
                    ],
                    fullRetailPrice: {
                      originalPrice: 1299.99,
                      contractText: 'Full Retail Price',
                    },
                    preferredTerm: 36,
                    prepayPrice: {
                      originalPrice: 1299.99,
                      contractText: 'Prepay Price',
                    },
                  },
                  sorId: 'MQ213LL/A',
                  skuDisplayName: 'iPhone 14 Pro 512GB in Gold',
                  inventoryDetails: {
                    dFillInventory: {
                      isAvailable: false,
                      isBackorder: false,
                      isDeliverBy: false,
                      isPreOrder: false,
                      isShipBy: false,
                      isInStock: true,
                      locationCode: '9999999',
                      qtyAvailable: 52953,
                    },
                  },
                  prodCode1: '5GD',
                  prodCode2: 'SMT',
                  prodCode3: 'DIG',
                  prodCode4: 'VDS',
                  prodCode5: 'ISL',
                },
                {
                  skuId: 'sku5600181',
                  color: {
                    colorCssStyle: '#655D6C',
                    colorId: 'clr12200029',
                    description: 'Purple',
                    displayName: 'Deep Purple',
                  },
                  imageUrlMap: {
                    defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a',
                    largeImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-lg$',
                    mediumImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-med$',
                    miniImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-mini$',
                    thumbImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-thumb$',
                    imageSetUrl:
                      'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                  },
                  price: {
                    devicePaymentPrice: [
                      {
                        originalPrice: 36.11,
                        contractDuration: 36,
                        contractText:
                          'Monthly payments shown are for customers who qualify to pay $0 Down, $36.11/mo. for 36 months; 0% APR. Retail Price: $1299.99',
                        dpTermPrices: {
                          downPayment: 0,
                          downPaymentRequired: false,
                          upgradeOptionPercentage: 50,
                          upgradeOptionCode: 'UO',
                          dpTerm: 36,
                          ugradeEligibilityCategory: [
                            {
                              categoryCode: '4',
                              categories: ['5G Smartphone~4G Smartphone'],
                            },
                          ],
                          firstMonthPrice: 36.14,
                          remainingMonthPrice: 36.11,
                        },
                      },
                    ],
                    fullRetailPrice: {
                      originalPrice: 1299.99,
                      contractText: 'Full Retail Price',
                    },
                    preferredTerm: 36,
                    prepayPrice: {
                      originalPrice: 1299.99,
                      contractText: 'Prepay Price',
                    },
                  },
                  sorId: 'MQ273LL/A',
                  skuDisplayName: 'iPhone 14 Pro 512GB in Deep Purple',
                  inventoryDetails: {
                    dFillInventory: {
                      isAvailable: false,
                      isBackorder: true,
                      isDeliverBy: false,
                      isPreOrder: false,
                      isShipBy: true,
                      isInStock: false,
                      locationCode: '9999999',
                      qtyAvailable: 0,
                      shippingDate: {
                        date: '12/12/2023',
                        dateTime: '12-12-2023 08:00:00 AM',
                        dateLong: 1702368000000,
                      },
                    },
                  },
                  prodCode1: '5GD',
                  prodCode2: 'SMT',
                  prodCode3: 'DIG',
                  prodCode4: 'VDS',
                  prodCode5: 'ISL',
                },
                {
                  skuId: 'sku5600182',
                  color: {
                    colorCssStyle: '#655D6C',
                    colorId: 'clr12200029',
                    description: 'Purple',
                    displayName: 'Deep Purple',
                  },
                  imageUrlMap: {
                    defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a',
                    largeImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-lg$',
                    mediumImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-med$',
                    miniImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-mini$',
                    thumbImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-thumb$',
                    imageSetUrl:
                      'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                  },
                  price: {
                    devicePaymentPrice: [
                      {
                        originalPrice: 41.66,
                        contractDuration: 36,
                        contractText:
                          'Monthly payments shown are for customers who qualify to pay $0 Down, $41.66/mo. for 36 months; 0% APR. Retail Price: $1499.99',
                        dpTermPrices: {
                          downPayment: 0,
                          downPaymentRequired: false,
                          upgradeOptionPercentage: 50,
                          upgradeOptionCode: 'UO',
                          dpTerm: 36,
                          ugradeEligibilityCategory: [
                            {
                              categoryCode: '4',
                              categories: ['5G Smartphone~4G Smartphone'],
                            },
                          ],
                          firstMonthPrice: 41.89,
                          remainingMonthPrice: 41.66,
                        },
                      },
                    ],
                    fullRetailPrice: {
                      originalPrice: 1499.99,
                      contractText: 'Full Retail Price',
                    },
                    preferredTerm: 36,
                    prepayPrice: {
                      originalPrice: 1499.99,
                      contractText: 'Prepay Price',
                    },
                  },
                  sorId: 'MQ303LL/A',
                  skuDisplayName: 'iPhone 14 Pro 1TB in Deep Purple',
                  inventoryDetails: {
                    dFillInventory: {
                      isAvailable: false,
                      isBackorder: false,
                      isDeliverBy: false,
                      isPreOrder: false,
                      isShipBy: false,
                      isInStock: true,
                      locationCode: '9999999',
                      qtyAvailable: 49899,
                    },
                  },
                  prodCode1: '5GD',
                  prodCode2: 'SMT',
                  prodCode3: 'DIG',
                  prodCode4: 'VDS',
                  prodCode5: 'ISL',
                },
                {
                  skuId: 'sku5600283',
                  color: {
                    colorCssStyle: '#1E1D1B',
                    colorId: 'clr12240018',
                    description: 'Black',
                    displayName: 'Space Black',
                  },
                  imageUrlMap: {
                    defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a',
                    largeImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-lg$',
                    mediumImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-med$',
                    miniImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-mini$',
                    thumbImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a?$device-thumb$',
                    imageSetUrl:
                      'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-space-black-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                  },
                  price: {
                    devicePaymentPrice: [
                      {
                        originalPrice: 41.66,
                        contractDuration: 36,
                        contractText:
                          'Monthly payments shown are for customers who qualify to pay $0 Down, $41.66/mo. for 36 months; 0% APR. Retail Price: $1499.99',
                        dpTermPrices: {
                          downPayment: 0,
                          downPaymentRequired: false,
                          upgradeOptionPercentage: 50,
                          upgradeOptionCode: 'UO',
                          dpTerm: 36,
                          ugradeEligibilityCategory: [
                            {
                              categoryCode: '4',
                              categories: ['5G Smartphone~4G Smartphone'],
                            },
                          ],
                          firstMonthPrice: 41.89,
                          remainingMonthPrice: 41.66,
                        },
                      },
                    ],
                    fullRetailPrice: {
                      originalPrice: 1499.99,
                      contractText: 'Full Retail Price',
                    },
                    preferredTerm: 36,
                    prepayPrice: {
                      originalPrice: 1499.99,
                      contractText: 'Prepay Price',
                    },
                  },
                  sorId: 'MQ2E3LL/A',
                  skuDisplayName: 'iPhone 14 Pro 1TB in Space Black',
                  inventoryDetails: {
                    dFillInventory: {
                      isAvailable: false,
                      isBackorder: false,
                      isDeliverBy: false,
                      isPreOrder: false,
                      isShipBy: false,
                      isInStock: true,
                      locationCode: '9999999',
                      qtyAvailable: 49776,
                    },
                  },
                  prodCode1: '5GD',
                  prodCode2: 'SMT',
                  prodCode3: 'DIG',
                  prodCode4: 'VDS',
                  prodCode5: 'ISL',
                },
                {
                  skuId: 'sku5600284',
                  color: {
                    colorCssStyle: '#C0C0C0',
                    colorId: 'clr40012',
                    description: 'Silver',
                    displayName: 'Silver',
                  },
                  imageUrlMap: {
                    defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a',
                    largeImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-lg$',
                    mediumImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-med$',
                    miniImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-mini$',
                    thumbImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a?$device-thumb$',
                    imageSetUrl:
                      'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-silver-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                  },
                  price: {
                    devicePaymentPrice: [
                      {
                        originalPrice: 41.66,
                        contractDuration: 36,
                        contractText:
                          'Monthly payments shown are for customers who qualify to pay $0 Down, $41.66/mo. for 36 months; 0% APR. Retail Price: $1499.99',
                        dpTermPrices: {
                          downPayment: 0,
                          downPaymentRequired: false,
                          upgradeOptionPercentage: 50,
                          upgradeOptionCode: 'UO',
                          dpTerm: 36,
                          ugradeEligibilityCategory: [
                            {
                              categoryCode: '4',
                              categories: ['5G Smartphone~4G Smartphone'],
                            },
                          ],
                          firstMonthPrice: 41.89,
                          remainingMonthPrice: 41.66,
                        },
                      },
                    ],
                    fullRetailPrice: {
                      originalPrice: 1499.99,
                      contractText: 'Full Retail Price',
                    },
                    preferredTerm: 36,
                    prepayPrice: {
                      originalPrice: 1499.99,
                      contractText: 'Prepay Price',
                    },
                  },
                  sorId: 'MQ2L3LL/A',
                  skuDisplayName: 'iPhone 14 Pro 1TB in Silver',
                  inventoryDetails: {
                    dFillInventory: {
                      isAvailable: false,
                      isBackorder: false,
                      isDeliverBy: false,
                      isPreOrder: false,
                      isShipBy: false,
                      isInStock: true,
                      locationCode: '9999999',
                      qtyAvailable: 49891,
                    },
                  },
                  prodCode1: '5GD',
                  prodCode2: 'SMT',
                  prodCode3: 'DIG',
                  prodCode4: 'VDS',
                  prodCode5: 'ISL',
                },
                {
                  skuId: 'sku5600285',
                  color: {
                    colorCssStyle: '#D0C2AE',
                    colorId: 'clr3360032',
                    description: 'Gold',
                    displayName: 'Gold',
                  },
                  imageUrlMap: {
                    defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a',
                    largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-lg$',
                    mediumImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-med$',
                    miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-mini$',
                    thumbImage:
                      'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a?$device-thumb$',
                    imageSetUrl:
                      'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-gold-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                  },
                  price: {
                    devicePaymentPrice: [
                      {
                        originalPrice: 41.66,
                        contractDuration: 36,
                        contractText:
                          'Monthly payments shown are for customers who qualify to pay $0 Down, $41.66/mo. for 36 months; 0% APR. Retail Price: $1499.99',
                        dpTermPrices: {
                          downPayment: 0,
                          downPaymentRequired: false,
                          upgradeOptionPercentage: 50,
                          upgradeOptionCode: 'UO',
                          dpTerm: 36,
                          ugradeEligibilityCategory: [
                            {
                              categoryCode: '4',
                              categories: ['5G Smartphone~4G Smartphone'],
                            },
                          ],
                          firstMonthPrice: 41.89,
                          remainingMonthPrice: 41.66,
                        },
                      },
                    ],
                    fullRetailPrice: {
                      originalPrice: 1499.99,
                      contractText: 'Full Retail Price',
                    },
                    preferredTerm: 36,
                    prepayPrice: {
                      originalPrice: 1499.99,
                      contractText: 'Prepay Price',
                    },
                  },
                  sorId: 'MQ2T3LL/A',
                  skuDisplayName: 'iPhone 14 Pro 1TB in Gold',
                  inventoryDetails: {
                    dFillInventory: {
                      isAvailable: false,
                      isBackorder: false,
                      isDeliverBy: false,
                      isPreOrder: false,
                      isShipBy: false,
                      isInStock: true,
                      locationCode: '9999999',
                      qtyAvailable: 52920,
                    },
                  },
                  prodCode1: '5GD',
                  prodCode2: 'SMT',
                  prodCode3: 'DIG',
                  prodCode4: 'VDS',
                  prodCode5: 'ISL',
                },
              ],
              defaultSKU: 'MQ0E3LL/A',
              seo: {
                canonicalUrl: 'smartphones/apple-iphone-14-pro/',
              },
              defaultSKUObj: {
                skuId: 'sku5600276',
                color: {
                  colorCssStyle: '#655D6C',
                  colorId: 'clr12200029',
                  description: 'Purple',
                  displayName: 'Deep Purple',
                },
                imageUrlMap: {
                  defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a',
                  largeImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-lg$',
                  mediumImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-med$',
                  miniImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-mini$',
                  thumbImage:
                    'https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a?$device-thumb$',
                  imageSetUrl:
                    'https://mobile.vzw.com/hybridClient/is/image/VerizonWireless/iphone-14-pro-deep-purple-fall22-a_IMAGESETS?req=set,json,UTF-8&labelkey=label&handler=s7sdkJSONResponse',
                },
                price: {
                  devicePaymentPrice: [
                    {
                      originalPrice: 27.77,
                      contractDuration: 36,
                      contractText:
                        'Monthly payments shown are for customers who qualify to pay $0 Down, $27.77/mo. for 36 months; 0% APR. Retail Price: $999.99',
                      dpTermPrices: {
                        downPayment: 0,
                        downPaymentRequired: false,
                        upgradeOptionPercentage: 50,
                        upgradeOptionCode: 'UO',
                        dpTerm: 36,
                        ugradeEligibilityCategory: [
                          {
                            categoryCode: '4',
                            categories: ['5G Smartphone~4G Smartphone'],
                          },
                        ],
                        firstMonthPrice: 28.04,
                        remainingMonthPrice: 27.77,
                      },
                    },
                  ],
                  fullRetailPrice: {
                    originalPrice: 999.99,
                    contractText: 'Full Retail Price',
                  },
                  preferredTerm: 36,
                  prepayPrice: {
                    originalPrice: 999.99,
                    contractText: 'Prepay Price',
                  },
                },
                sorId: 'MQ0E3LL/A',
                skuDisplayName: 'iPhone 14 Pro 128GB in Deep Purple',
                inventoryDetails: {
                  dFillInventory: {
                    isAvailable: false,
                    isBackorder: false,
                    isDeliverBy: false,
                    isPreOrder: false,
                    isShipBy: false,
                    isInStock: true,
                    locationCode: '9999999',
                    qtyAvailable: 47025,
                  },
                },
                prodCode1: '5GD',
                prodCode2: 'SMT',
                prodCode3: 'DIG',
                prodCode4: 'VDS',
                prodCode5: 'ISL',
              },
            };
  it('should test component with ', () => {
    render(
      <CompareGridwallDevices
        showCompareData={{
          compareList: [
            baseProduct
          ],
        }}
      />
    );
    const imageClick = screen.getByTestId('compareGridwallDevices');
    expect(imageClick).toBeInTheDocument();
  });
  it('should render nothing if product is undefined', () => {
    const showCompareData = { compareList: [undefined] };
    render(
      <CompareGridwallDevices
        showCompareData={showCompareData}
        handleRemoveProductFromCompare={jest.fn()}
        hideCompareDevicesModal={jest.fn()}
        cartDetails={{}}
      />
    );
  });
  it('should take the pricing priority as devicePaymentPrice if it returns null', () => {
    getPricingPriority.mockReturnValue(null);
    const showCompareData = { compareList: [baseProduct] };
    render(
      <CompareGridwallDevices
        showCompareData={showCompareData}
        handleRemoveProductFromCompare={jest.fn()}
        hideCompareDevicesModal={jest.fn()}
        cartDetails={{}}
      />
    );
  });
});

describe('CompareGridwallDevices contractPrice and contractText logic', () => {
  const baseProduct = {
    productId: '1',
    brandName: 'Brand',
    productDisplayName: 'Test Device',
    childSkus: [
      {
        price: {
          devicePaymentPrice: [
            {
              contractDuration: 24,
              dpTermPrices: { remainingMonthPrice: 25, dpTerm: 24 },
            },
          ],
          preferredTerm: 24,
          fullRetailPrice: { originalPrice: 1200 },
        },
        imageUrlMap: { defaultImage: 'img.jpg' },
      },
    ],
    techSpecs: {},
  };
  const baseProduct1 = {
    productId: '2',
    brandName: 'Brand',
    productDisplayName: 'Test Device 2',
    childSkus: [
      {
        price: {
          devicePaymentPrice: [
            {
              contractDuration: 24,
              dpTermPrices: { remainingMonthPrice: 30 },
            },
          ],
          preferredTerm: 24,
          oneYearPrice: {},
        },
        imageUrlMap: { defaultImage: 'img2.jpg' },
      },
    ],
    techSpecs: {},
  };

  const baseProduct2 = {
    productId: '2',
    brandName: 'Brand',
    productDisplayName: 'Test Device 2',
    childSkus: [
      {
        price: {
          devicePaymentPrice: [
            {
              contractDuration: 24,
              dpTermPrices: { remainingMonthPrice: 30 },
            },
          ],
          preferredTerm: 24,
        },
        imageUrlMap: { defaultImage: 'img2.jpg' },
      },
    ],
    techSpecs: {},
  };

  const baseProduct3 = {
    productId: '3',
    brandName: 'Brand',
    productDisplayName: 'Test Device 3',
    childSkus: [
      {
        price: {
          devicePaymentPrice: [
            {
              contractDuration: 24,
              dpTermPrices: { remainingMonthPrice: 35 },
            },
          ],
          preferredTerm: 24,
          fullRetailPrice: { originalPrice: 1400 },
        },
        imageUrlMap: { defaultImage: 'img3.jpg' },
      },
    ],
    techSpecs: {
      height: '6.1 inches',
      weight: '5.5 ounces',
    },
  };

  it('should display DPP price when isVbg() is true and dpFirstMonthPrice exists', () => {
    isVbg.mockReturnValue(true);
    getAssistedCradlePropertyV2.mockReturnValue([true, true, true]);
    getPricingPriority.mockReturnValue(null);
    getDpTermIndex.mockReturnValue(0);

    const showCompareData = { compareList: [baseProduct] };
    const { getByText } = render(
      <CompareGridwallDevices
        showCompareData={showCompareData}
        handleRemoveProductFromCompare={jest.fn()}
        hideCompareDevicesModal={jest.fn()}
        cartDetails={{}}
        scrolled
      />
    );
    expect(getByText('$25/mo')).toBeInTheDocument();
    expect(getByText('for 24 months')).toBeInTheDocument();
  });

  it('should display retail contractPrice and contractText when isVbg() is true and pricingPriority is not devicePaymentPrice', () => {
    getAssistedCradlePropertyV2.mockReturnValue([true, true, true]);
    isVbg.mockReturnValue(true);
    getPricingPriority.mockReturnValue('fullRetailPrice');
    getDpTermIndex.mockReturnValue(-1);
    const showCompareData = { compareList: [baseProduct] };
    const { getAllByText } = render(
      <CompareGridwallDevices
        showCompareData={showCompareData}
        handleRemoveProductFromCompare={jest.fn()}
        hideCompareDevicesModal={jest.fn()}
        cartDetails={{}}
      />
    );
    const element = getAllByText('$1200');
    expect(element?.[0]).toBeInTheDocument();
    // contractText is empty in this mock, so not asserting it
  });

  it('should display retail contractPrice and contractText when isVbg() is true and pricingPriority is not devicePaymentPrice', () => {
    getAssistedCradlePropertyV2.mockReturnValue([true, true, true]);
    isVbg.mockReturnValue(true);
    getPricingPriority.mockReturnValueOnce('fullRetailPrice')
      .mockReturnValueOnce('oneYearPrice').mockReturnValueOnce('fullRetailPrice')
      .mockReturnValueOnce(null);
    getDpTermIndex.mockReturnValue(-1);
    const showCompareData = { compareList: [baseProduct, baseProduct1, baseProduct2, baseProduct3] };
    const { getAllByText } = render(
      <CompareGridwallDevices
        showCompareData={showCompareData}
        handleRemoveProductFromCompare={jest.fn()}
        hideCompareDevicesModal={jest.fn()}
        cartDetails={{}}
      />
    );
    const element = getAllByText('$1200');
    expect(element?.[0]).toBeInTheDocument();
    // contractText is empty in this mock, so not asserting it
  });

  it('should fallback to DPP price when isVbg() is false', () => {
    getAssistedCradlePropertyV2.mockReturnValue([false, false, false]);
    isVbg.mockReturnValue(false);
    getPricingPriority.mockReturnValue(null);
    getDpTermIndex.mockReturnValue(0);
    const showCompareData = { compareList: [baseProduct] };
    const { getByText } = render(
      <CompareGridwallDevices
        showCompareData={showCompareData}
        handleRemoveProductFromCompare={jest.fn()}
        hideCompareDevicesModal={jest.fn()}
        cartDetails={{}}
      />
    );
    expect(getByText('$25/mo')).toBeInTheDocument();
    expect(getByText('for 24 months')).toBeInTheDocument();
  });

  it('should set contractPrice and contractText when isVbg() is true and pricingPriority and originalPrice exist', () => {
    getAssistedCradlePropertyV2.mockReturnValue([true, true, true]);
    isVbg.mockReturnValue(true);
    getPricingPriority.mockReturnValue('oneYearPrice');

    const product = {
      productId: '1',
      brandName: 'Brand',
      productDisplayName: 'Test Device',
      childSkus: [
        {
          price: {
            oneYearPrice: {
              originalPrice: 1100,
              contractText: 'One Year Price',
            },
          },
          imageUrlMap: { defaultImage: 'img.jpg' },
        },
      ],
      techSpecs: {},
    };

    const props = {
      showCompareData: { compareList: [product] },
      cartDetails: { cart: { cartHeader: {} } },
      handleRemoveProductFromCompare: jest.fn(),
      hideCompareDevicesModal: jest.fn(),
    };

    render(<CompareGridwallDevices {...props} />);

    expect(screen.getByText('$1100')).toBeInTheDocument();
    expect(screen.getByText('One Year Price')).toBeInTheDocument();
  });

  it('should not set contractPrice and contractText if pricingPriority is missing or originalPrice is missing', () => {
    getAssistedCradlePropertyV2.mockReturnValue([true, true, true]);
    isVbg.mockReturnValue(true);
    getPricingPriority.mockReturnValue('oneYearPrice');

    const product = {
      productId: '2',
      brandName: 'Brand',
      productDisplayName: 'Test Device 2',
      childSkus: [
        {
          price: {
            oneYearPrice: {},
          },
          imageUrlMap: { defaultImage: 'img2.jpg' },
        },
      ],
      techSpecs: {},
    };

    const props = {
      showCompareData: { compareList: [product] },
      cartDetails: { cart: { cartHeader: {} } },
      handleRemoveProductFromCompare: jest.fn(),
      hideCompareDevicesModal: jest.fn(),
    };

    render(<CompareGridwallDevices {...props} />);
    // Should not display a price
    expect(screen.queryByText('One Year Price')).not.toBeInTheDocument();
  });

  it('should not set contractPrice and contractText when isVbg() is false', () => {
    getAssistedCradlePropertyV2.mockReturnValue([true, true, true]);
    isVbg.mockReturnValue(false);
    getPricingPriority.mockReturnValue('twoYearPrice');

    const product = {
      productId: '3',
      brandName: 'Brand',
      productDisplayName: 'Test Device 3',
      childSkus: [
        {
          price: {
            twoYearPrice: {
              originalPrice: 1000,
              contractText: 'Two Year Price',
            },
          },
          imageUrlMap: { defaultImage: 'img3.jpg' },
        },
      ],
      techSpecs: {},
    };

    const props = {
      showCompareData: { compareList: [product] },
      cartDetails: { cart: { cartHeader: {} } },
      handleRemoveProductFromCompare: jest.fn(),
      hideCompareDevicesModal: jest.fn(),
    };

    render(<CompareGridwallDevices {...props} />);

    expect(screen.queryByText('Two Year Price')).not.toBeInTheDocument();
  });

  it('should set contractText to empty if contract text is missing', () => {
    getAssistedCradlePropertyV2.mockReturnValue([true, true, true]);
    isVbg.mockReturnValue(true);
    getPricingPriority.mockReturnValue('oneYearPrice');

    const product = {
      productId: '2',
      brandName: 'Brand',
      productDisplayName: 'Test Device 2',
      childSkus: [
        {
          price: {
            oneYearPrice: {
              originalPrice: 1100,
            },
          },
          imageUrlMap: { defaultImage: 'img2.jpg' },
        },
      ],
      techSpecs: {},
    };

    const props = {
      showCompareData: { compareList: [product] },
      cartDetails: { cart: { cartHeader: {} } },
      handleRemoveProductFromCompare: jest.fn(),
      hideCompareDevicesModal: jest.fn(),
    };

    render(<CompareGridwallDevices {...props} />);
    expect(screen.getByText('$1100')).toBeInTheDocument();
    expect(screen.queryByText('One Year Price')).not.toBeInTheDocument();
  });

  it('should not display DPP when isVbg() is false and preferredTerm is missing', () => {
    isVbg.mockReturnValue(false);
    getAssistedCradlePropertyV2.mockReturnValue([true, true, true]);
    getPricingPriority.mockReturnValue(null);
    getDpTermIndex.mockReturnValue(0);
    baseProduct.childSkus[0].price.preferredTerm = null;

    const showCompareData = { compareList: [baseProduct] };
    const { queryByText } = render(
      <CompareGridwallDevices
        showCompareData={showCompareData}
        handleRemoveProductFromCompare={jest.fn()}
        hideCompareDevicesModal={jest.fn()}
        cartDetails={{}}
      />
    );

    expect(queryByText('$25/mo')).not.toBeInTheDocument();
    expect(queryByText('for months')).not.toBeInTheDocument();
  });
});

describe('CompareGridwallDevices handleRemoveProductFromCompare', () => {
  const baseProduct = {
    productId: '1',
    brandName: 'Brand',
    productDisplayName: 'Test Device',
    childSkus: [
      {
        price: {
          devicePaymentPrice: [
            {
              contractDuration: 24,
              dpTermPrices: { remainingMonthPrice: 25, dpTerm: 24 },
            },
          ],
          preferredTerm: 24,
          fullRetailPrice: { originalPrice: 1200 },
        },
        imageUrlMap: { defaultImage: 'img.jpg' },
      },
    ],
    techSpecs: {},
  };

  it('calls handleRemoveProductFromCompare with correct productId when remove button is clicked', () => {
    isVbg.mockReturnValue(false);
    getAssistedCradlePropertyV2.mockReturnValue([true, true, true]);
    getPricingPriority.mockReturnValue(null);
    const handleRemoveProductFromCompare = jest.fn();
    const showCompareData = { compareList: [baseProduct] };

    const { getByTestId } = render(
      <CompareGridwallDevices
        showCompareData={showCompareData}
        handleRemoveProductFromCompare={handleRemoveProductFromCompare}
        hideCompareDevicesModal={jest.fn()}
        cartDetails={{}}
      />
    );

    const removeButton = getByTestId('removebutton_compare');
    fireEvent.click(removeButton);

    expect(handleRemoveProductFromCompare).toHaveBeenCalledWith('1');
  });
});