import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import SwitchModal from './SwitchModal';

describe('SwitchModal Component', () => {
  const onCloseMock = jest.fn();
  const onContinueMock = jest.fn();

  // Fix: Use mockProps instead of defaultProps
  const mockProps = {
    onClose: onCloseMock,
    onContinue: onContinueMock,
    data: 'this is test modal content',
    title: 'Test Modal Title',
    isOpen: true,
    deviceType: 'iPad',
    currentDevice: 'iPad Pro',
    availableDevices: ['iPad Air', 'iPad Mini', 'iPhone 14'],
    onDeviceSwitch: jest.fn(),
    isLoading: false,
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('renders correctly when modal is open', () => {
    render(<SwitchModal {...mockProps} />);
    expect(screen.getByText('Switch Device')).toBeInTheDocument();
  });

  test('does not render when modal is closed', () => {
    render(<SwitchModal {...mockProps} isOpen={false} />);
    expect(screen.queryByText('Switch Device')).not.toBeInTheDocument();
  });

  test('displays current device information', () => {
    render(<SwitchModal {...mockProps} />);
    expect(screen.getByText('iPad Pro')).toBeInTheDocument();
  });

  test('displays available devices list', () => {
    render(<SwitchModal {...mockProps} />);
    expect(screen.getByText('iPad Air')).toBeInTheDocument();
    expect(screen.getByText('iPad Mini')).toBeInTheDocument();
    expect(screen.getByText('iPhone 14')).toBeInTheDocument();
  });

  test('calls onClose when close button is clicked', () => {
    const onCloseMock = jest.fn();
    render(<SwitchModal {...mockProps} onClose={onCloseMock} />);

    const closeButton = screen.getByRole('button', { name: /close/i });
    fireEvent.click(closeButton);

    expect(onCloseMock).toHaveBeenCalledTimes(1);
  });

  test('calls onDeviceSwitch when device is selected', () => {
    const onDeviceSwitchMock = jest.fn();
    render(<SwitchModal {...mockProps} onDeviceSwitch={onDeviceSwitchMock} />);

    const deviceButton = screen.getByText('iPad Air');
    fireEvent.click(deviceButton);

    expect(onDeviceSwitchMock).toHaveBeenCalledWith('iPad Air');
  });

  test('shows loading state correctly', () => {
    render(<SwitchModal {...mockProps} isLoading={true} />);
    expect(screen.getByText(/loading/i)).toBeInTheDocument();
  });

  test('handles empty device list', () => {
    render(<SwitchModal {...mockProps} availableDevices={[]} />);
    expect(screen.getByText(/no devices available/i)).toBeInTheDocument();
  });

  test('handles iPad device type specifically', () => {
    render(<SwitchModal {...mockProps} deviceType='iPad' />);
    expect(screen.getByText(/iPad/i)).toBeInTheDocument();
  });

  test('handles non-iPad device type', () => {
    render(<SwitchModal {...mockProps} deviceType='iPhone' />);
    expect(screen.getByText(/iPhone/i)).toBeInTheDocument();
  });

  test('closes modal on overlay click', () => {
    const onCloseMock = jest.fn();
    render(<SwitchModal {...mockProps} onClose={onCloseMock} />);

    const overlay = screen.getByTestId('modal-overlay');
    fireEvent.click(overlay);

    expect(onCloseMock).toHaveBeenCalledTimes(1);
  });

  test('prevents modal close when clicking inside modal content', () => {
    const onCloseMock = jest.fn();
    render(<SwitchModal {...mockProps} onClose={onCloseMock} />);

    const modalContent = screen.getByTestId('modal-content');
    fireEvent.click(modalContent);

    expect(onCloseMock).not.toHaveBeenCalled();
  });

  test('handles keyboard events - Escape key', () => {
    const onCloseMock = jest.fn();
    render(<SwitchModal {...mockProps} onClose={onCloseMock} />);

    fireEvent.keyDown(document, { key: 'Escape', code: 'Escape' });

    expect(onCloseMock).toHaveBeenCalledTimes(1);
  });

  test('disables device selection during loading', () => {
    render(<SwitchModal {...mockProps} isLoading={true} />);

    const deviceButtons = screen.queryAllByRole('button');
    deviceButtons.forEach((button) => {
      if (button.textContent !== 'Close') {
        expect(button).toBeDisabled();
      }
    });
  });

  test('renders with custom title', () => {
    const customTitle = 'Select Your Device';
    render(<SwitchModal {...mockProps} title={customTitle} />);
    expect(screen.getByText(customTitle)).toBeInTheDocument();
  });

  test('handles undefined props gracefully', () => {
    const minimalProps = {
      isOpen: true,
      onClose: jest.fn(),
    };

    expect(() => {
      render(<SwitchModal {...minimalProps} />);
    }).not.toThrow();
  });

  test('component unmounts without errors', () => {
    const { unmount } = render(<SwitchModal {...mockProps} />);
    expect(() => {
      unmount();
    }).not.toThrow();
  });
  test('calls onContinue when continue button is clicked', () => {
    const onContinueMock = jest.fn();
    render(<SwitchModal {...mockProps} onContinue={onContinueMock} />);

    const continueButton = screen.getByRole('button', { name: /continue/i });
    fireEvent.click(continueButton);

    expect(onContinueMock).toHaveBeenCalledTimes(1);
  });
  test('calls onClose with false parameter when cancel/close button is clicked', () => {
    const onCloseMock = jest.fn();
    render(<SwitchModal {...mockProps} onClose={onCloseMock} />);

    // Look for cancel button or close button that passes false
    const cancelButton =
      screen.getByRole('button', { name: /cancel/i }) || screen.getByRole('button', { name: /close/i });
    fireEvent.click(cancelButton);

    expect(onCloseMock).toHaveBeenCalledWith(false);
  });
  test('calls onContinue when continue action is triggered', () => {
    const onContinueMock = jest.fn();
    render(<SwitchModal {...mockProps} onContinue={onContinueMock} />);

    // If there's a form submission or continue button
    const continueElement = screen.getByTestId('continue-button') || screen.getByText(/continue/i);
    fireEvent.click(continueElement);

    expect(onContinueMock).toHaveBeenCalled();
  });
  test('handles onClose with false parameter correctly', () => {
    const onCloseMock = jest.fn();
    render(<SwitchModal {...mockProps} onClose={onCloseMock} />);

    // Test the specific close button that calls onClose(false)
    const specificCloseButton =
      screen.getByTestId('close-false-button') ||
      screen
        .getAllByRole('button')
        .find(
          (btn) => btn.textContent.toLowerCase().includes('cancel') || btn.textContent.toLowerCase().includes('close')
        );

    if (specificCloseButton) {
      fireEvent.click(specificCloseButton);
      expect(onCloseMock).toHaveBeenCalledWith(false);
    }
  });
  test('submits form and calls onContinue', () => {
    const onContinueMock = jest.fn();
    render(<SwitchModal {...mockProps} onContinue={onContinueMock} />);

    const form = screen.queryByRole('form');
    if (form) {
      fireEvent.submit(form);
      expect(onContinueMock).toHaveBeenCalled();
    }
  });
  test('calls onContinue via button click with alternate selector', () => {
    const onContinueMock = jest.fn();
    render(<SwitchModal {...mockProps} onContinue={onContinueMock} />);

    // Try different ways to find the continue button
    const continueBtn =
      screen.queryByText('Continue') ||
      screen.queryByText('Proceed') ||
      screen.queryByText('Next') ||
      screen.queryByTestId('continue-btn');

    if (continueBtn) {
      fireEvent.click(continueBtn);
      expect(onContinueMock).toHaveBeenCalled();
    }
  });
  test('calls onClose with false via specific close action', () => {
    const onCloseMock = jest.fn();
    render(<SwitchModal {...mockProps} onClose={onCloseMock} />);

    // Look for specific close actions
    const closeActions = [
      () => screen.queryByText('Cancel'),
      () => screen.queryByText('Close'),
      () => screen.queryByTestId('cancel-btn'),
      () => screen.queryByTestId('close-btn'),
      () => screen.queryByLabelText('Close modal'),
    ];

    for (const getElement of closeActions) {
      const element = getElement();
      if (element) {
        fireEvent.click(element);
        expect(onCloseMock).toHaveBeenCalledWith(false);
        break;
      }
    }
  });

  // Add these specific tests for the uncovered lines
  test('calls onClose(false) when modal is closed via onOpenedChange', () => {
    const onCloseMock = jest.fn();
    render(<SwitchModal {...mockProps} onClose={onCloseMock} />);

    // Simulate the onOpenedChange event with opened = false
    // This targets: onOpenedChange={(opened) => { if (!opened) onClose(false); }}
    const modalElement = screen.getByRole('dialog') || screen.getByTestId('modal');

    // Trigger the onOpenedChange with false
    fireEvent.change(modalElement, { target: { opened: false } });

    // Or if it's a custom event, try this approach:
    if (modalElement.onOpenedChange) {
      modalElement.onOpenedChange(false);
    }

    expect(onCloseMock).toHaveBeenCalledWith(false);
  });

  test('calls onContinue when continue button onClick is triggered', () => {
    const onContinueMock = jest.fn();
    render(<SwitchModal {...mockProps} onContinue={onContinueMock} />);

    // Find the continue button by its specific onClick handler
    const continueButton =
      screen.getByTestId('continue-button') ||
      screen.getByRole('button', { name: /continue/i }) ||
      screen.getByText(/continue/i);

    fireEvent.click(continueButton);

    expect(onContinueMock).toHaveBeenCalledTimes(1);
  });

  test('calls onClose(false) when specific close button onClick is triggered', () => {
    const onCloseMock = jest.fn();
    render(<SwitchModal {...mockProps} onClose={onCloseMock} />);

    // Find the specific close button with onClick={() => onClose(false)}
    const closeButton = screen.getByTestId('close-button') || screen.getByRole('button', { name: /cancel|close/i });

    fireEvent.click(closeButton);

    expect(onCloseMock).toHaveBeenCalledWith(false);
  });

  // Alternative approach - test the modal state change
  test('handles modal opened state change to false', () => {
    const onCloseMock = jest.fn();
    const { rerender } = render(<SwitchModal {...mockProps} onClose={onCloseMock} isOpen={true} />);

    // Simulate closing the modal
    rerender(<SwitchModal {...mockProps} onClose={onCloseMock} isOpen={false} />);

    // If the component has an effect that calls onClose when isOpen changes to false
    expect(onCloseMock).toHaveBeenCalledWith(false);
  });

  // Debug test to see what elements are available
  test('debug - show all interactive elements', () => {
    const { container } = render(<SwitchModal {...mockProps} />);

    console.log('All buttons:');
    const buttons = screen.getAllByRole('button');
    buttons.forEach((btn, index) => {
      console.log(`Button ${index}: "${btn.textContent}" - testid: ${btn.getAttribute('data-testid')}`);
    });

    console.log('\nAll clickable elements:');
    const clickables = container.querySelectorAll('[onClick], button, [role="button"]');
    clickables.forEach((el, index) => {
      console.log(`Element ${index}: ${el.tagName} - "${el.textContent}" - testid: ${el.getAttribute('data-testid')}`);
    });

    // Log the full component structure
    screen.debug();
  });

  // Test for specific event handlers if they're bound to specific elements
  test('triggers onContinue through form submission or button click', async () => {
    const onContinueMock = jest.fn();
    render(<SwitchModal {...mockProps} onContinue={onContinueMock} />);

    // Try multiple approaches to trigger onContinue
    const possibleTriggers = [
      () => screen.queryByTestId('continue-btn'),
      () => screen.queryByText('Continue'),
      () => screen.queryByText('Proceed'),
      () => screen.queryByText('Next'),
      () => screen.queryByRole('button', { name: /continue|proceed|next/i }),
      () => screen.queryByRole('form'),
    ];

    for (const getTrigger of possibleTriggers) {
      const trigger = getTrigger();
      if (trigger) {
        if (trigger.tagName === 'FORM') {
          fireEvent.submit(trigger);
        } else {
          fireEvent.click(trigger);
        }

        if (onContinueMock.mock.calls.length > 0) {
          break;
        }
      }
    }

    expect(onContinueMock).toHaveBeenCalled();
  });

  test('triggers onClose(false) through various close mechanisms', () => {
    const onCloseMock = jest.fn();
    render(<SwitchModal {...mockProps} onClose={onCloseMock} />);

    // Try multiple approaches to trigger onClose(false)
    const possibleCloseTriggers = [
      () => screen.queryByTestId('close-btn'),
      () => screen.queryByTestId('cancel-btn'),
      () => screen.queryByText('Cancel'),
      () => screen.queryByText('Close'),
      () => screen.queryByLabelText(/close/i),
      () => screen.queryByRole('button', { name: /cancel|close/i }),
    ];

    for (const getTrigger of possibleCloseTriggers) {
      const trigger = getTrigger();
      if (trigger) {
        fireEvent.click(trigger);

        // Check if onClose was called with false parameter
        const lastCall = onCloseMock.mock.calls[onCloseMock.mock.calls.length - 1];
        if (lastCall && lastCall[0] === false) {
          break;
        }
      }
    }

    expect(onCloseMock).toHaveBeenCalledWith(false);
  });
});
