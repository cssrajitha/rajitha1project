import React, { useEffect, useState, useMemo } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useLazyRemoveLinesQuery, useOneTalkEnrollmentMutation} from 'onevzsoemfecommon/APIService';
import styled from 'styled-components';
import { debounce, isEmpty } from 'lodash';
import PropTypes from 'prop-types';
import * as DOMPurify from 'dompurify';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import Emitter from 'onevzsoemfeframework/Emitter';
import DeviceTile from './Tiles/DeviceTile';
import EmptyDeviceTile from './Tiles/EmptyDeviceTile';
import Header from './FlexGridwall/Header';
import Filter from './FlexGridwall/Filter';
import TakeOverScreen from './Tiles/TakeOverScreen';
import { TextLink } from '@vds/buttons';
import { Body } from '@vds/typography';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import WiFiBackupDetails from './WifiBackupDetails';
import SwitchModal from './SwitchModal';
import * as types from '../constants/DeviceConstants';
import { isFunctionalityEnabled } from '../../../src/modules/utils';

const DeviceGrid = styled.div`
  margin-bottom: 2rem !important;
  display: flex;
  flex-flow: row wrap;
  margin: -1rem 0 0 -1rem;
  width: calc(100% + 1rem);
  padding-top: 1rem;
  > * {
    margin: 1rem 0 0 1rem;
  }
`;

const NoDeviceWrapper = styled.div`
  margin-top: 2rem !important;
  font-size: 1.5rem;
  font-weight: 700;
`;
const LinkWrapperSwitch = styled.div`
  display: flex;
  height: 3rem;
  align-items: flex-end;
  cursor: pointer;
  padding: 0 0.5rem 0.75rem 0.5rem;
  margin-bottom: -0.75rem;
  margin-left: auto;
  a {
    place-self: unset;
  }
  flex-direction: row-reverse;
`;

function DeviceListTab(props) {/* NOSONAR: Legacy large component retained; complexity refactor deferred to avoid functional risk */
  const {
    toggle,
    setToggle,
    showToogle,
    saveTempDeviceSelectionData,
    selectedTab,
    brandName,
    brandValue,
    categories,
    categoryValue,
    osName,
    osValue,
    sortValue,
    existingSortOptions,
    handleCategoryChange,
    handleBrandChange,
    handleOSChange,
    handleSortChange,
    handleResetChange,
    handleToggleState,
    // resetSortOptions,
    products,
    getDevices,
    pagination,
    productList,
    techRecommendation,
    totalLines,
    landingData,
    activeMtn,
    landingLinesInfo,
    offerMessage,
    deviceCategory,
    // pdpSelectedDevice,
    deviceSelection,
    errMessage,
    // updateCompareDeviceData,
    offerSourceSystem,
    propositionMessage,
    isLoadMore,
    offerSubType,
    selectedSkuId,
    lineActivityType,
    hasIteminCart,
    handleByodflag,
    showProspectTile,
    isDWOS,
    intentCheck,
    rebeaBYODCheck,
    isOffersStacked,
    sortOptions,
    trialDeviceDetail,
    is5GDevice,
    CustomerData,
    validateDeviceSimIdRequest,
    prospectByodFlow,
    isGWByodEUPEnabledFlag,
    installmentTerm,
    isPearl,
  } = props;
  const dispatch = useDispatch();
  const selectedDevice = props?.cartDetails?.cart?.lineDetails?.deviceDetails?.selectedDevice;
  const [removeLinesAPI, RemoveLinesAPIResult] = useLazyRemoveLinesQuery();
  const [transientDeviceSelection, setTransientDeviceSelection] = useState(props.deviceSelection);
  const [addEnrollmentAPI, AddEnrollmentResult] = useOneTalkEnrollmentMutation();
  const [count, setCount] = useState({
    startCount: productList?.length || 0,
    endCount: 24,
  });
  const scmUpgradeMfeEnable = window?.mfe?.scmUpgradeMfeEnable || false;
  const [showWifiBackupDetailsModal, setShowWifiBackupDetailsModal] = useState(false);
  const [showFlowChangePopup, setShowFlowChangePopup] = useState(false);
  const [takeOverScreen, setTakeOverScreen] = useState(false);
  const getPlansPriceResult = useSelector((state) => state?.plans?.data?.getPlansPriceResult || '');
  const activeMtnInfo = getPlansPriceResult?.data?.lines?.find((x) => x.mtn === activeMtn);
  let isBytdDeviceAdded = false;
  const trialDeviceInfo = trialDeviceDetail?.tdd?.equipmentInfos?.[0]?.deviceInfo;
  const bytdDeviceId = totalLines?.[0]?.itemsInfo?.[0]?.cartItems?.cartItem?.filter(
    (item) => item?.deviceId === trialDeviceInfo?.deviceId
  );
  const [fiveGSelectedFlow, setFiveGSelectedFlow] = useState(sessionStorage.getItem('fiveGHomeInternetSelectedFlow'));
  const qualificationType = sessionStorage.getItem('Qualification_type');
  const depletionType = props?.cartDetails?.cart?.lineDetails?.lineInfo?.[0]?.itemsInfo?.[0]?.depletionType;
  if (isPearl && bytdDeviceId?.length > 0) {
    isBytdDeviceAdded = true;
  }

  const fwaTechRecommenderCBandSOEAssistedFFlag = /true/i.test(
    getAssistedCradlePropertyV2(['fwaTechRecommenderCBandSOEAssistedFFlag'])?.[0]
  );
  const fwaTechRecommenderCBandAssistedCriticalFFlag = /true/i.test(
    getAssistedCradlePropertyV2(['fwaTechRecommenderCBandAssistedCriticalFFlag'])?.[0]
  );
  const getTechRecommender = () => (typeof techRecommendation === 'string' ? techRecommendation.toLowerCase() : null);

  const getTechRecommendedSetup = () => {
    const techRecommender = getTechRecommender();
    if (techRecommender && techRecommender === 'high' && productList?.length === 2) {
      const professionalSetup = productList?.find(
        (device) =>
          typeof device?.productDisplayName === 'string' &&
          device?.productDisplayName?.toLowerCase().includes('professional')
      )?.productId;
      return professionalSetup || '';
    }

    return '';
  };

  const techRecommendedSetup = fwaTechRecommenderCBandSOEAssistedFFlag ? getTechRecommendedSetup() : '';

  function getFilteredDeviceList(deviceList) {
    const techRecommender = getTechRecommender();
    const isProandSelf =
      deviceList &&
      deviceList.length === 2 &&
      deviceList.some(
        (device) =>
          typeof device?.productDisplayName === 'string' &&
          device.productDisplayName.toLowerCase().includes('professional')
      ) &&
      deviceList.some(
        (device) =>
          typeof device?.productDisplayName === 'string' && device.productDisplayName.toLowerCase().includes('self')
      );
    if (fwaTechRecommenderCBandAssistedCriticalFFlag && techRecommender && techRecommender === 'critical') {
      if (isProandSelf) {
        return deviceList.filter((device) => device?.productDisplayName?.toLowerCase().includes('professional'));
      }
      return deviceList;
    }

    if (
      techRecommendedSetup &&
      deviceList?.length === 2 &&
      deviceList[1]?.productDisplayName?.toLowerCase().includes('professional') &&
      deviceList[0]?.productDisplayName?.toLowerCase().includes('self')
    ) {
      return [deviceList[1], deviceList[0]];
    }
    return deviceList;
  }

  const elvisFromSession = sessionStorage.getItem('elvisFFlag');
  const elvisFFlag = /true/i.test(elvisFromSession);

  useEffect(() => {
    handleScroll();
  }, [isLoadMore]);

  useEffect(() => {
    setCount({ startCount: 0, endCount: 24 });
  }, [activeMtn]); // Ipad scroll issue fix

  useEffect(() => {
    if (scmUpgradeMfeEnable && RemoveLinesAPIResult?.data && RemoveLinesAPIResult?.status === 'fulfilled') {
      Emitter.emit('ADD_SELECTED_DEVICE_TO_CART', {});
      Emitter.emit('ACSS_SCM_CLEAR_LEFT_RAIL', true);


      props.getDevices(toggle, 0, 24, categoryValue, brandValue, osValue, sortValue, false, sortOptions);

    }
  }, [RemoveLinesAPIResult, RemoveLinesAPIResult?.status]);

  useEffect(() => {
    setTransientDeviceSelection(props.deviceSelection);
  }, [props.deviceSelection]);



 useEffect(() => {
    
    const handleEnrollementAPI = (data) => {

     const requestParams = {};
    
    addEnrollmentAPI({
      body: requestParams,
    });
    };

    // Add listener for success events
    Emitter.on('ONETALK_DEVICE_API_CALL', handleEnrollementAPI);

    // Cleanup listener on unmount
    return () => {
      Emitter.off('ONETALK_DEVICE_API_CALL', handleEnrollementAPI);
    };
  }, []);


  useEffect(() => {
    // Prefer explicit handlers to make success/error handling clearer
    const handleAddEnrollmentResponse = (result) => {
      // Some API shapes put payload under data.data, preserve both lookups
    const payload = result?.data?.data || result?.data || {};
      const statusCode = payload?.statusCode;

      if (statusCode === '00') {
        // Handle successful enrollment (business message preserved)
        Emitter.emit('ONETALK_DEVICEC_REQ', {
          status: 'message-info',
          message:
            'One Talk enrollment is in progress. Please contact the BFO if enrollment is not completed within the next 24 hour',
        });
      } else if (statusCode === '-1') {
        // Preserve existing error message behavior
        Emitter.emit('ONETALK_DEVICEC_REQ', {
          status: 'message-error',
          message:
            'There was an issue updating the customer profile, please try again or contact Customer Service for assistance',
        });
      }
    };

    const handleAddEnrollmentError = () => {
      dispatch(
        appMessageActions.addAppMessage('Failed to make OneTalk enrollment. Please try again.', 'error', true, true),
      );
    };

    // Run handlers based on the mutation result
    if (AddEnrollmentResult?.data) {
      handleAddEnrollmentResponse(AddEnrollmentResult.data);
    }

    if (AddEnrollmentResult?.isError || AddEnrollmentResult?.error) {
      handleAddEnrollmentError();
    }
  }, [AddEnrollmentResult]);

  const DEODevices = useMemo(
    () => !isEmpty(totalLines) && totalLines?.filter((item) => /deo/i.test(item?.lineActivityType)),
    [totalLines]
  );
  const DEOItems = useMemo(
    () => DEODevices?.[0]?.itemsInfo?.[0]?.cartItems?.cartItem?.filter((item) => /device/i.test(item?.cartItemType)),
    [DEODevices]
  );
  const DEODevice = !isEmpty(DEOItems?.length);
  const handleScroll = () => {
    if (pagination && pagination?.totalNumberRecords && productList?.length > 0 && isLoadMore) {
      const totalRecords = pagination?.totalNumberRecords;
      const currentCount = count.startCount + count.endCount;
      sessionStorage.setItem('griddiv.totalRecords', totalRecords);
      sessionStorage.setItem('griddiv.currentCount', currentCount);
      if (totalRecords > currentCount) {
        loadMoreDevice();
      }
    }
  };

  const loadMoreDevice = () => {
    const start = count.startCount === 0 ? count.endCount + 1 : count.startCount + count.endCount;
    setCount({ startCount: start, endCount: count.endCount });
    getDevices(toggle, start, count.endCount, categoryValue, brandValue, osValue, sortValue, true, sortOptions);
  };

  const resetDevices = () => {
    // resetSortOptions(); // reset sort options on reset click
    setCount({ startCount: 0, endCount: 24 });
    handleResetChange();
    props.resetToggleOptions();
  };

  const delayedCallback = debounce((e) => handleSearchTxtChangeAfterDebounce(e), 500);

  const onSearchTxtChange = (event, param) => {
    if (param === 'clearBtn') {
      props.onSearchTxtChange('');
    } else {
      event.persist();
      delayedCallback(event);
    }
  };

  const handleSearchTxtChangeAfterDebounce = (event) => {
    if (props.onSearchTxtChange) props.onSearchTxtChange(event.target.value);
  };

  const handleGetSKUList = (searchText, isSearchText = false) => {
    props.getSkuList(searchText, isSearchText);
    setCount({ startCount: 0, endCount: 24 });
  };

  const handleCloseFunc = () => {
    setTakeOverScreen(false);
  };

  const TakeOverScreenFunc = (param) => {
    if (param === 'BYOD') {
      // Here you can update your state
      setTakeOverScreen('BYOD');
    } else {
      // Reset or perform a different action if needed.
      setTakeOverScreen(!takeOverScreen);
    }
  };

  // CXTDT-576121 : only considering active lines as existing lines
  const exsistingmtns =
    CustomerData?.billAccounts?.[0]?.mtns?.filter(
      (mtn) => mtn?.mtnStatus?.isActive && !mtn?.mtnStatus?.isDisconnected
    ) || [];
  let isSecondNumberPlan = false;
  let isexsistingline = false;
  exsistingmtns.map((item) => {
    if (item.mtn === activeMtn) {
      isexsistingline = true;
      if (item?.pricePlanInfo?.planId === '70995') {
        isSecondNumberPlan = true;
      }
    }
    return;
  });
  let hideDeviceList = false;
  const newPricePlanId = props?.selectedLine?.[0]?.serviceInfo?.newPricePlanInfo?.pricePlanCode || '';
  const currentPlanId = activeMtnInfo?.planId?.toString() || '';
  if (currentPlanId === '70995') {
    hideDeviceList = true;
  } else if (!currentPlanId && (newPricePlanId === '70995' || (!newPricePlanId && isSecondNumberPlan))) {
    hideDeviceList = true;
  }

  if (hideDeviceList) {
    return (
      <NoDeviceWrapper>
        <span data-testid='no-device-sn'>Devices cannot be added to Second Number</span>
      </NoDeviceWrapper>
    );
  }

  const handleSwitch5GWifiToggleBtn = () => {

    const devicesForMtn = props?.cartDetails?.cart?.lineDetails?.lineInfo
      ?.filter(line => line?.mobileNumber === activeMtn)
      .flatMap(line => line?.itemsInfo ?? [])
      .flatMap(itemsInfo => itemsInfo?.cartItems?.cartItem ?? [])
      .filter(item => item?.cartItemType === "DEVICE");

    let newFlow;

    const isVHILiteQualified = sessionStorage.getItem('vhiLiteQualified') === 'true';
    if (isVHILiteQualified) {

      newFlow = (fiveGSelectedFlow === "WiFi-Backup") ? "VHILite" : "WiFi-Backup";
    } else {
      newFlow = fiveGSelectedFlow === '5G-Internet' ? 'WiFi-Backup' : '5G-Internet';
    }

    setFiveGSelectedFlow(newFlow);
    sessionStorage.setItem('fiveGHomeInternetSelectedFlow', newFlow);

    setTransientDeviceSelection(null);

    if (devicesForMtn[0]?.sorId) {
      removeLinesHandler(fiveGSelectedFlow);
    } else {
      props.getDevices(toggle, 0, 24, categoryValue, brandValue, osValue, sortValue, false, sortOptions);

    }

  };
  const removeLinesHandler = (fiveGSelectedFlow) => {
    const activityType = props?.cartDetails?.cart?.lineDetails?.lineInfo?.[0]?.lineActivityType;
    const isNewLineCreated = !!(activityType?.includes('AAL') || activityType?.includes('NSE'));

    const request = {
      cartInfo: {
        clientAppName: 'VZW-ACSS',
        creditAppNum: '',
        processStep: 'ShoppingCart',
        intendType: 'AAL',

        processingMTN: activeMtn,
        processAction: isNewLineCreated ? 'removeDevice' : '',
      },
      data: {
        lines: [
          {
            mtn: activeMtn,
          },
        ],
      },
    };
    if (fiveGSelectedFlow === 'WiFi-Backup' || fiveGSelectedFlow === 'VHILite') {

      request.cartInfo.transactionType = 'WIFIBACKUP';
      request.data.lines[0].transactionType = 'WIFIBACKUP';
    }

    removeLinesAPI({ body: request });
  };
  const renderSwitch5GWifiToggleBtn = () => {
    const wifibackUpAvailable =
      sessionStorage.getItem('wifiBackupCbandQualified') === 'true' ||
      sessionStorage.getItem('wifiBackupLteQualified') === 'true';

    const activeLine = props?.cartDetails?.cart?.lineDetails?.lineInfo?.find(
      (line) => line.mobileNumber === activeMtn
    );
    const is5GLine = activeLine?.deviceTypeSelected === '5G Internet';



    const {
      LTEQualified = false,
      cBandQualified = false,
      fiveGHomeQualified = false,
      VHILiteQualified = false,
    } = CustomerData?.qualificationDetails?.addressRequest || {};
    const LTEorCBandorMMWQualified =
      fiveGHomeQualified ||
      LTEQualified ||
      cBandQualified ||
      qualificationType === 'MMW' ||
      qualificationType === 'LTE' ||
      qualificationType === 'CBD';
    const isVHILiteQualified = (sessionStorage.getItem('vhiLiteQualified') === 'true' || VHILiteQualified);
    if (!(is5GLine && wifibackUpAvailable && (isVHILiteQualified || LTEorCBandorMMWQualified))) {
      return;
    }
    let switchBtnText = '';
    if (fiveGSelectedFlow === '5G-Internet') {
      switchBtnText = 'View Wi-Fi Backup';
    } else if (LTEQualified) {
      switchBtnText = 'View LTE Home Internet';
    } else {
      switchBtnText = 'View 5G Home Internet';
    }

    if (isVHILiteQualified) {
      switchBtnText = fiveGSelectedFlow === 'VHILite' ? 'View Wi-Fi Backup' : 'View Verizon Home Internet Lite';
    }
    return (
      <LinkWrapperSwitch
        data-testid='5g-wifi-btn'
        onClick={(e) => {
          if (fiveGSelectedFlow === 'VHILite' || fiveGSelectedFlow === '5G-Internet') {
            setShowWifiBackupDetailsModal(true);
          } else {
            setShowFlowChangePopup(true);
          }
        }}
      >
        <TextLink
          data-track='{"type":"link", "name":"order-landing_shop devices", "event":"event117"}'
          size='large'
          ariaLabel={switchBtnText}
          role='button'
        >
          <Body size='large'>{switchBtnText}</Body>
        </TextLink>
      </LinkWrapperSwitch>
    );
  };
  const LTEQualified = CustomerData?.qualificationDetails?.LTEQualified;

  const getSwitchModalTitle = () => {
    const isVHILiteQualified = sessionStorage.getItem("vhiLiteQualified") === "true";

    if (isVHILiteQualified) {
      if (fiveGSelectedFlow === "VHILite") {
        return types?.VHI_LITE_SWITCH_WIFI_BACKUP?.header;
      } else if (fiveGSelectedFlow === "WiFi-Backup") {
        return types?.WIFI_BACKUP_SWITCH_VHI_LITE?.header;
      }
    }

    if (fiveGSelectedFlow === "5G-Internet") {
      return LTEQualified
        ? types?.WIFI_BACKUP_SWITCH_LTE?.header
        : types?.WIFI_BACKUP_SWITCH_5G?.header;
    }

    return LTEQualified
      ? types?.SWITCH_MODAL_LTE?.header
      : types?.SWITCH_MODAL_5G?.header;
  };

  const getSwitchModalBody = () => {
    const isVHILiteQualified = sessionStorage.getItem("vhiLiteQualified") === "true";

    if (isVHILiteQualified) {
      if (fiveGSelectedFlow === "VHILite") {
        return types?.VHI_LITE_SWITCH_WIFI_BACKUP?.body;
      } else if (fiveGSelectedFlow === "WiFi-Backup") {
        return types?.WIFI_BACKUP_SWITCH_VHI_LITE?.body;
      }
    }

    if (fiveGSelectedFlow === "5G-Internet") {
      return LTEQualified ? types?.WIFI_BACKUP_SWITCH_LTE?.body : types?.WIFI_BACKUP_SWITCH_5G?.body;
    }

    return LTEQualified ? types?.SWITCH_MODAL_LTE?.body
      : types?.SWITCH_MODAL_5G?.body;
  };

  return (
    <React.Fragment>
      <Header
        isSecondNumberPlan={isSecondNumberPlan}
        offerMessage={offerMessage}
        toggle={toggle}
        setToggle={setToggle}
        showToogle={showToogle}
        sortValue={sortValue}
        existingSortOptions={existingSortOptions}
        handleSortChange={handleSortChange}
        categoryValue={categoryValue}
        handleToggleState={handleToggleState}
        onSearchTxtChange={onSearchTxtChange}
        onCancelSearchInput={() => props.onSearchTxtChange('')}
        onAutoCompleteItemSkuSearch={props.onAutoCompleteItemSkuSearch}
        path=''
        getSkuList={handleGetSKUList}
        is5GDevice={is5GDevice}
        deviceCategory={deviceCategory}
        selectedTab={selectedTab}
        offerSourceSystem={offerSourceSystem}
        propositionMessage={propositionMessage}
        offerSubType={offerSubType}
        isDWOS={isDWOS}
        intentCheck={intentCheck}
        rebeaBYODCheck={rebeaBYODCheck}
        isOffersStacked={isOffersStacked}
        totalLines={totalLines}
        activeMtn={activeMtn}
        landingLinesInfo={landingLinesInfo}
        validateDeviceSimIdRequest={validateDeviceSimIdRequest}
        CustomerData={CustomerData}
        showSort={!is5GDevice}
        cartDetails={props?.cartDetails}
        setUpcCode={props?.setUpcCode}
        TakeOverScreenFunc={TakeOverScreenFunc}
        channel={CustomerData?.channel}
        productTypeForSearch='device'
      />
      <Filter
        brandName={brandName}
        brandValue={brandValue}
        categories={categories}
        categoryValue={categoryValue}
        osName={osName}
        osValue={osValue}
        sortValue={sortValue}
        existingSortOptions={existingSortOptions}
        handleCategoryChange={handleCategoryChange}
        handleBrandChange={handleBrandChange}
        handleOSChange={handleOSChange}
        handleSortChange={handleSortChange}
        handleResetChange={handleResetChange}
        resetDevices={resetDevices}
        is5GDevice={is5GDevice}
        refinementOptions={props?.refinementOptions}
        brandOptions={props?.brandOptions}
        OSOptions={props?.OSOptions}
      />

      {errMessage && <div>{errMessage}</div>}
      {scmUpgradeMfeEnable && isFunctionalityEnabled('scmCommonFixFFlag', 'enableFWAWifiBackUpLink') && renderSwitch5GWifiToggleBtn()}
      <DeviceGrid>
        {isPearl && trialDeviceInfo && !isBytdDeviceAdded && (
          <DeviceTile
            key={trialDeviceInfo?.deviceId}
            trialDeviceId={trialDeviceInfo?.deviceId}
            trialProductImageUrl={trialDeviceInfo?.deviceUrl}
            trialProductDisplayName={trialDeviceInfo?.displayName}
            saveTempDeviceSelectionData={saveTempDeviceSelectionData}
            handleCompareCheckboxChange={props.handleCompareCheckboxChange}
            handleRemoveProductFromCompareInGW={props.handleRemoveProductFromCompareInGW}
            devicestocompare={props.devicestocompare}
            isPearl={isPearl}
            validateDeviceSimIdRequest={validateDeviceSimIdRequest}
            cartDetails={props?.cartDetails}
            channel={CustomerData?.channel}
            TakeOverScreenFunc={TakeOverScreenFunc}
            isDWOS={isDWOS}
          />
        )}
        {deviceSelection?.productId && isPearl && isBytdDeviceAdded && (
          <DeviceTile
            key={deviceSelection.productId}
            selectedSkuId={selectedSkuId}
            device={deviceSelection}
            commonInfo={products?.commonInfo}
            deviceSelection={deviceSelection}
            selectedTab={selectedTab}
            totalLines={totalLines}
            activeMtn={activeMtn}
            saveTempDeviceSelectionData={saveTempDeviceSelectionData}
            handleCompareCheckboxChange={props.handleCompareCheckboxChange}
            handleRemoveProductFromCompareInGW={props.handleRemoveProductFromCompareInGW}
            devicestocompare={props.devicestocompare}
            lineActivityType={lineActivityType}
            isBundleGW={products?.gridWall?.isBundleGW}
            installmentTerm={installmentTerm}
            isPearl={isPearl}
            isBytdDeviceAdded={isBytdDeviceAdded}
            trialDeviceId={trialDeviceInfo?.deviceId}
            validateDeviceSimIdRequest={validateDeviceSimIdRequest}
            cartDetails={props?.cartDetails}
            channel={CustomerData?.channel}
            TakeOverScreenFunc={TakeOverScreenFunc}
            isDWOS={isDWOS}
          />
        )}
        {((!is5GDevice &&
          showProspectTile &&
          !isDWOS &&
          !prospectByodFlow &&
          !(lineActivityType?.includes('BYOD') && hasIteminCart) &&
          (lineActivityType === 'NSE' ||
            lineActivityType?.includes('AAL') ||
            (isexsistingline && isGWByodEUPEnabledFlag) ||
            (lineActivityType?.includes('BYOD') && !hasIteminCart))) ||
          isBytdDeviceAdded) && (
            <EmptyDeviceTile
              isPearl={isPearl}
              addYourDevice={() => handleByodflag(isexsistingline, categoryValue)}
              elvisFFlag={elvisFFlag}
              cartDetails={props?.cartDetails}
              channel={CustomerData?.channel}
              TakeOverScreenFunc={TakeOverScreenFunc}
            />
          )}

        {isDWOS &&
          DEODevice &&
          DEOItems.map(() => (
            <DeviceTile
              key={deviceSelection.productId}
              device={deviceSelection}
              commonInfo={products?.commonInfo}
              deviceSelection={deviceSelection}
              selectedTab={selectedTab}
              totalLines={totalLines}
              activeMtn={activeMtn}
              saveTempDeviceSelectionData={saveTempDeviceSelectionData}
              handleCompareCheckboxChange={props.handleCompareCheckboxChange}
              handleRemoveProductFromCompareInGW={props.handleRemoveProductFromCompareInGW}
              devicestocompare={props.devicestocompare}
              isDWOS={isDWOS}
              cartDetails={props?.cartDetails}
              channel={CustomerData?.channel}
              TakeOverScreenFunc={TakeOverScreenFunc}
            />
          ))}

        {transientDeviceSelection?.productId && !isBytdDeviceAdded && (
          <DeviceTile
            key={deviceSelection.productId}
            selectedSkuId={selectedSkuId}
            device={deviceSelection}
            commonInfo={products?.commonInfo}
            deviceSelection={deviceSelection}
            selectedTab={selectedTab}
            totalLines={totalLines}
            activeMtn={activeMtn}
            saveTempDeviceSelectionData={saveTempDeviceSelectionData}
            handleCompareCheckboxChange={props.handleCompareCheckboxChange}
            handleRemoveProductFromCompareInGW={props.handleRemoveProductFromCompareInGW}
            devicestocompare={props.devicestocompare}
            lineActivityType={lineActivityType}
            isBundleGW={products?.gridWall?.isBundleGW}
            installmentTerm={installmentTerm}
            isPearl={isPearl}
            cartDetails={props?.cartDetails}
            channel={CustomerData?.channel}
            TakeOverScreenFunc={TakeOverScreenFunc}
            isDWOS={isDWOS}
          />
        )}
        {showWifiBackupDetailsModal && (
          <WiFiBackupDetails
            onClose={() => setShowWifiBackupDetailsModal(false)}
            onSelect={() => {
              setShowFlowChangePopup(true);
            }}
            isOpen={showWifiBackupDetailsModal}
          />
        )}
        {showFlowChangePopup && (
          <SwitchModal
            title={getSwitchModalTitle()}
            data={getSwitchModalBody()}
            onClose={() => {
              setShowFlowChangePopup(false);
            }}
            onContinue={() => {
              handleSwitch5GWifiToggleBtn();
              setShowFlowChangePopup(false);
              setShowWifiBackupDetailsModal(false);
            }}
            isOpen={showFlowChangePopup}
          />
        )}
        {!(transientDeviceSelection?.productId && ['AAL_5G', 'NSE_5G', 'AAL_LTE', 'NSE_LTE'].includes(lineActivityType)) &&
          getFilteredDeviceList(productList)?.map((device) => (
            <DeviceTile
              key={device.productId}
              device={device}
              commonInfo={products?.commonInfo}
              deviceSelection={null}
              recommendedSetup={techRecommendedSetup}
              selectedTab={selectedTab}
              totalLines={totalLines}
              landingData={landingData?.customer?.billAccounts?.[0]?.mtns || []}
              activeMtn={activeMtn}
              saveTempDeviceSelectionData={saveTempDeviceSelectionData}
              handleCompareCheckboxChange={props.handleCompareCheckboxChange}
              handleRemoveProductFromCompareInGW={props.handleRemoveProductFromCompareInGW}
              devicestocompare={props.devicestocompare}
              isBundleGW={products?.gridWall?.isBundleGW}
              cartDetails={props?.cartDetails}
              channel={CustomerData?.channel}
              TakeOverScreenFunc={TakeOverScreenFunc}
              isDWOS={isDWOS}
            />
          ))}
      </DeviceGrid>
      {takeOverScreen || /byod/i.test(takeOverScreen) ? (
        <TakeOverScreen
          handleCloseFunc={handleCloseFunc}
          depletionType={depletionType}
          channel={CustomerData?.channel}
          isBYOD={takeOverScreen}
        />
      ) : (
        ''
      )}
    </React.Fragment>
  );
}
DeviceListTab.propTypes = {
  CustomerData: PropTypes.shape({
    channel: PropTypes.string.isRequired,
  }).isRequired,
};
export default DeviceListTab;
