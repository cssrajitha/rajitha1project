import React from 'react';
import { fireEvent, render, screen } from '../../../modules/test-utils/renderHelper';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import CarrierLockModal from './CarrierLockModal';

describe(`<CarrierLockModal component`, () => {
  const props = {
    setShowCarrierLockPopup: jest.fn(),
    showCarrierLockPopup: true,
  };

  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });
  beforeEach(() => {
    render(<CarrierLockModal {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('should mount component', async () => {
    const modalHeading = screen.getByText('Contact Previous Carrier of Locked Device');
    expect(modalHeading).toBeInTheDocument();
    const NoBtn = screen.getByRole('button', { name: 'No' });
    expect(NoBtn).toBeInTheDocument();
    fireEvent.click(NoBtn);
    const ackBtn = await screen.getByRole('button', { name: 'Acknowledge' });
    expect(ackBtn).toBeInTheDocument();
    fireEvent.click(ackBtn);
  });
  test('should mount component', async () => {
    const modalHeading = screen.getByText('Contact Previous Carrier of Locked Device');
    expect(modalHeading).toBeInTheDocument();
    const YesBtn = screen.getByRole('button', { name: 'Yes' });
    expect(YesBtn).toBeInTheDocument();
    fireEvent.click(YesBtn);
  });
});
