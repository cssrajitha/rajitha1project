/* eslint-disable jsx-a11y/no-static-element-interactions */
import React, { useState, useEffect } from 'react';
import { ButtonGroup } from '@vds/buttons';
import { Checkbox } from '@vds/checkboxes';
import { Body, Title } from '@vds/typography';
import { Notification } from '@vds/notifications';
import { useNavigate } from 'react-router-dom';
import { getUIContextPath, getUIContextPathBAU } from 'onevzsoemfecommon/Helpers';
import Emitter from 'onevzsoemfeframework/Emitter';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { getQueryParamByName, isRetail, isD2D, isAsurion, isIndirect } from 'onevzsoemfeframework/DomService';
import styled from 'styled-components';
import { useDispatch } from 'react-redux';
import { Input } from '@vds/inputs';
import { DropdownSelect } from '@vds/selects';
import { ConfirmationDialogBox } from 'onevzsoemfecommon/ConfirmationDialogBox';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import { sendCustomEvent } from 'onevzsoemfeframework/Tagging';
import { Tooltip } from '@vds/tooltips';
import { useLazySmartimeiTypeaheadQuery, useLazyESimDetailsQuery } from 'onevzsoemfecommon/CartAPIService';
import PropTypes from 'prop-types';
import CarrierLockModal from './CarrierLockModal';

// import {
// useLazyESimDetailsQuery,
// useLazySmartimeiTypeaheadQuery,
// } from '../../../modules/services/APIService/APIServiceHooks';
import {
  MTN_TYPE_PRE_TO_POST,
  MTN_TYPE_YAHOO,
  MTN_TYPE_VISIBLE,
  MTN_TYPE_HARMONY,
} from '../../constants/DeviceConstants';

import {
  PaddingTop20,
  PaddingTop24,
  StyledPaddingTop32,
  PaddingLeft16,
  Padding16,
  PaddingTopBottom16,
} from '../FlexGlobalStyledConstants';
import DeviceScan from '../DeviceScan';
import ESim from '../ESim/ESim';
import './AutoComplete.css';
import getPDPEnable from '../../../modules/utils/getPDPEnable';
import { isFunctionalityEnabled } from '../../../modules/utils';

const scmUpgradeMfeEnable = window?.mfe?.scmUpgradeMfeEnable || false;
const scmCombinedGridwallFlow = window?.mfe?.scmCombinedGridwallFlow || false;
const StyledTitleName = styled.div`
  margin-top: 2.5 rem;
`;

const CpeInpuField = styled.div`
  width: 400 px;
`;

const AutoCompleteItems = styled.div`
  & {
    position: relative;
  }
  &:before {
    content: '';
    border-right: 10px solid transparent;
    border-left: 10px solid transparent;
    border-bottom: 10px solid #d4d4d4;
    height: 0px;
    width: 0px;
    position: absolute;
    left: 200px;
    top: -10px;
    background-color: transparent;
  }
  &:after {
    content: '';
    border-right: 9px solid transparent;
    border-left: 9px solid transparent;
    border-bottom: 9px solid white;
    height: 0px;
    width: 0px;
    position: absolute;
    left: 201px;
    top: -9px;
    background-color: transparent;
  }
  & div {
    padding: 10px;
    cursor: pointer;
    background-color: #fff;
    border-bottom: 1px solid #d4d4d4;
    &:hover {
      background-color: #e9e9e9;
    }
  }
`;

const BadgeDiv = styled.div`
  display: inline-flex;
  text-overflow: ellipsis;
  background-color: #0077b4;
  color: #ffffff;
  border-radius: 4px;
  align-items: center;
  padding: 2px 0.25rem;
`;

const TooltipWrapper = styled.div`
  display: flex;
  padding-left: 0.25rem;
`;

const BlankDiv = styled.div`
  display: inline-flex;
  text-overflow: ellipsis;
  color: #ffffff;
  border-radius: 4px;
  align-items: center;
  padding: 2px 0.5rem;
`;
let navigate = '';
function useNavigateMFE() {
  navigate = useNavigate();
}

const isScmfullScreenFix = isFunctionalityEnabled('scmPactCommonFixFFlag', 'scmfullScreenFix');

const Cpe = (props) => { /* NOSONAR: Legacy large component retained; complexity refactor deferred to avoid functional risk */
  const {
    lineActivityType,
    selectedLine,
    totalLines,
    cartDetails,
    isProspectflow,
    deviceIdInCart,
    simIdInCart,
    CustomerData,
    ScanFromLanding,
    prospectByodFlow,
    ValidateDeviceSimIdResult,
    validateDeviceSimIdRequest,
    devicePayload,
    updateDevicePayload,
    ValidateDeviceSimIdResultStatus,
    updateSetUpPopUp,
    popUp,
    activeMtn,
    scanCheck,
    deviceCategory,
    primaryMtnofSecondNumber,
    SecNumFlow,
    landingLinesInfo,
    showCarrierLockPopup,
    setShowCarrierLockPopup,
  } = props;
  const isByodUpdate = !!getQueryParamByName('isByodUpdate');
  const fiveGDetails =
    selectedLine &&
    selectedLine?.length > 0 &&
    selectedLine?.filter((line) => line && line.deviceTypeSelected && line.deviceTypeSelected === '5G Internet');
  const isFiveG = !!(fiveGDetails && fiveGDetails.length > 0);
  const lineInfoFind = totalLines?.find((x) => x.mobileNumber === activeMtn);
  const ivrDeviceIds = '';
  try {
    useNavigateMFE();
  } catch (e) {
    /* istanbul ignore next */
    console.log('');
  }
  const dispatch = useDispatch();
  const inputRegEx = /^\d{14,16}$/;
  // states
  const [cpeCheckbox, setCpeCheckbox] = useState(true);
  const [carrierName, setCarrierName] = useState('');
  const [deviceName, setDeviceName] = useState('');
  const [selectedDeviceName, setSelectedDeviceName] = useState('');
  const [byodHumClearErrMsg, setByodHumClearErrMsg] = useState();
  const [deviceId, setDeviceId] = useState('');
  const [showAutoComplete, setShowAutoComplete] = useState(false);
  const [disableButton, setDisableButton] = useState(true);
  const [deviceError, setDeviceError] = useState(false);
  const [selectCarrierList, setSelectCarrierList] = useState([]);
  const [eSimData, eSimDataResults] = useLazyESimDetailsQuery();
  const [selectedDeviceData, setSelectedDeviceData] = useState({});
  const [getSmartImeiTypeAheadList, SmartImeiTypeAheadListResult] = useLazySmartimeiTypeaheadQuery();
  const [skipIccidCall] = getAssistedCradlePropertyV2(['skipIccidCall']);
  const skipICCIDFFlag = /true/i.test(getAssistedCradlePropertyV2(['skipICCIDFFlag'])?.[0]);
  const lineDetailsOfPrimaryMtn =
    landingLinesInfo && landingLinesInfo.filter((line) => line.mtn === primaryMtnofSecondNumber);
  const cartDetailsOfPrimaryMtn = cartDetails?.cart?.lineDetails?.lineInfo?.find(
    (line) => line?.mobileNumber === primaryMtnofSecondNumber
  );
  const cartDetailsOfActiveMtn = cartDetails?.cart?.lineDetails?.lineInfo?.find(
    (line) => line?.mobileNumber === activeMtn
  );
  const selectedDevice = cartDetailsOfActiveMtn?.deviceTypeSelected;
  const imeiOfPrimaryMtn =
    lineDetailsOfPrimaryMtn &&
    lineDetailsOfPrimaryMtn.length > 0 &&
    lineDetailsOfPrimaryMtn[0]?.equipmentInfos &&
    lineDetailsOfPrimaryMtn[0]?.equipmentInfos.length > 0 &&
    lineDetailsOfPrimaryMtn[0].equipmentInfos[0]?.deviceInfo &&
    lineDetailsOfPrimaryMtn[0].equipmentInfos[0].deviceInfo?.pairedDeviceDetails &&
    lineDetailsOfPrimaryMtn[0].equipmentInfos[0].deviceInfo?.pairedDeviceDetails.length > 0 &&
    lineDetailsOfPrimaryMtn[0].equipmentInfos[0].deviceInfo.pairedDeviceDetails[0];
  const isSelectedDevice =
    cartDetailsOfPrimaryMtn?.lineActivityType === 'EUP' ||
    cartDetailsOfPrimaryMtn?.lineActivityType === 'AAL' ||
    cartDetailsOfPrimaryMtn?.lineActivityType === 'NSE' ||
    cartDetailsOfPrimaryMtn?.lineActivityType === 'EUPBYOD' ||
    false;
  const cpeDeviceId = String(getQueryParamByName('deviceId')) || '';
  // const showScanner = commonInfo?.showScanner;
  const [isSingleSimEntiLookupModalVisibleByod, setIsSingleSimEntiLookupModalVisibleByod] = useState(false);
  const [isDualSimEntiLookupModalVisible, setIsDualSimEntiLookupModalVisible] = useState(false);
  const eSimDeviceInfo = ValidateDeviceSimIdResult?.serviceBody?.serviceResponse?.context?.deviceInfo;
  const eSimOnlyDevice = !!(
    eSimDeviceInfo &&
    eSimDeviceInfo.makeEtniPersApi &&
    eSimDeviceInfo.simInfo &&
    !eSimDeviceInfo.simInfo.dfillCompatibleSim
  );
  const isWSAPCpeError = Boolean(getQueryParamByName('isWSAPCpeError')) || false;
  const ispdpenable = getPDPEnable();
  const eSimPopUpData = {
    deviceInfo: eSimDeviceInfo,
    channel: CustomerData?.channel,
    isFrom: getQueryParamByName('deviceFromCart'),

    formattedDeviceId: devicePayload?.formattedDeviceId,
    apiRequest: devicePayload, // need to check
    requestFlowType: devicePayload?.data?.lines[0]?.device?.Flowtype,

    sagaPayload: devicePayload,
    isByodUpdate,
    scanFromLanding: false,
    sendSimFromLanding: false,
    notRetailAndInDirect: !isRetail() && !isIndirect(),
    contextUrl: getUIContextPath(),
  };

  const isSingleLookUpModel = () => {
    const { sendSimFromLanding = false } = devicePayload || {};
    const eSimInfo =
      eSimDeviceInfo?.simInfo?.makeEtniPersApi === true && eSimDeviceInfo?.simInfo2?.makeEtniPersApi === true;
    const connectedSimInfo =
      eSimDeviceInfo?.simInfo?.makeEtniPersApi === true &&
      eSimDeviceInfo?.makeEtniPersApi &&
      sendSimFromLanding === false;
    const notification =
      eSimDeviceInfo?.simInfo2 && (eSimDeviceInfo?.simInfo.makeEtniPersApi || eSimDeviceInfo?.simInfo2.makeEtniPersApi);
    const conectedDeviceNotification =
      eSimDeviceInfo && eSimDeviceInfo?.makeEtniPersApi && sendSimFromLanding === false;
    const dfillCompatibleSim =
      !eSimDeviceInfo?.simInfo.dfillCompatibleSim && !eSimDeviceInfo?.simInfo2?.dfillCompatibleSim;
    if (ValidateDeviceSimIdResult) {
      if (notification || conectedDeviceNotification) {
        if ((eSimInfo && dfillCompatibleSim && eSimDeviceInfo?.eSIMOnly) || connectedSimInfo) {
          // esim only
          setIsSingleSimEntiLookupModalVisibleByod(true);
          const vzdl = window?.vzdl || {};
          if (vzdl?.event) vzdl.event.value = '';
          if (vzdl?.page) vzdl.page.detail = `CombinedGridwall | eSIM activation`;
          window.vzdl = vzdl;
          sendCustomEvent('openView', window?.vzdl);
        } else if (
          (eSimDeviceInfo?.simInfo2?.makeEtniPersApi === true || eSimDeviceInfo?.simInfo?.makeEtniPersApi === true) &&
          !eSimDeviceInfo?.eSIMOnly
        ) {
          // dual sim: psim or esim
          setIsDualSimEntiLookupModalVisible(true);
          const vzdl = window?.vzdl || {};
          if (vzdl?.event) vzdl.event.value = '';
          if (vzdl?.page) vzdl.page.detail = `CombinedGridwall-Esim-Psim-popup`;
          window.vzdl = vzdl;
          sendCustomEvent('openView', window?.vzdl);
        }
      }
    }
  };
  const searchByName = getQueryParamByName('searchByName') === 'false' ? 'searchByName=false&' : '';
  const skuId = eSimDeviceInfo?.deviceSku?.trim() || ''; // removing extra space
  const deviceIdFromPayload = devicePayload?.deviceId;
  const { sendSimFromLanding = false } = devicePayload || {};
  const simSlot = !isIndirect() && !isRetail() ? eSimDeviceInfo?.simInfo.preferredSoftSim : '';
  const simId = eSimDeviceInfo?.simInfo.iccid && !sendSimFromLanding ? eSimDeviceInfo?.simInfo.iccid : simSlot;
  const eId = eSimDeviceInfo?.simInfo?.eID ? eSimDeviceInfo?.simInfo?.eID : '';
  const mtnNotGenerated = activeMtn?.includes('newLine');
  const imie2 = cartDetailsOfPrimaryMtn?.itemsInfo?.[0]?.cartItems?.cartItem?.[0]?.imei2;
  const secondImei = imie2 || '';

  const [samsungPOSFFlag] = getAssistedCradlePropertyV2(['samsungPOSFFlag']);
  const samsungPOSFFlagEnabled = /true/i.test(samsungPOSFFlag);
  const carrierLockInResponse =
    ValidateDeviceSimIdResultStatus === 'fulfilled' &&
    ValidateDeviceSimIdResult?.serviceBody?.serviceResponse?.context?.deviceInfo?.carrierLock;
  const carrierLock = (samsungPOSFFlagEnabled && carrierLockInResponse) || false;

  const navigateToProductDetails = () => {  /* NOSONAR: Legacy large component retained; complexity refactor deferred to avoid functional risk */
    if (devicePayload?.deviceName && devicePayload?.carrier) {
      /* istanbul ignore next */
      if (window?.mfe?.isProspectNewCustomerTab || (scmUpgradeMfeEnable && scmCombinedGridwallFlow)) {
        window?.mfe?.historyRef?.push(
          `/content/vcg/assisted/product-detail.html?offerEligible=Y&${searchByName}activeMtn=${activeMtn}&deviceSKU=${skuId}&${
            isByodUpdate ? 'isByodUpdate=true' : 'isFromCPE=true'
          }&deviceId=${deviceIdFromPayload}&mtn=${activeMtn}&simId=${simId}${
            prospectByodFlow ? '&prospectByodFlow=true&ByodDeviceCompitable=true' : ''
          }${scmCombinedGridwallFlow ? '&isFromCombinedGridWall=true' : ''}`
        );
      } else {
        navigate(
          `${getUIContextPathBAU()}/product-detail.html?$iSscan=true&offerEligible=Y&${searchByName}activeMtn=${activeMtn}&deviceSKU=${skuId}&${
            isByodUpdate ? 'isByodUpdate=true' : 'isFromCPE=true'
          }&deviceId=${deviceIdFromPayload}&mtn=${activeMtn}&simId=${simId}${
            prospectByodFlow ? '&prospectByodFlow=true&ByodDeviceCompitable=true' : ''
          }`
        );
      }
    } else if (
      eSimDeviceInfo &&
      !(
        eSimDeviceInfo?.simInfo2?.makeEtniPersApi ||
        eSimDeviceInfo?.eSIMOnly ||
        eSimDeviceInfo?.simInfo?.makeEtniPersApi
      )
    ) {
      // psim only or dual sim unlocked/international devices: navigate to pdp
      // added this param as we are getting iccid value for psim flow of watch
      // eslint-disable-next-line no-restricted-globals
      const preferredSoftSimWatch =
        ispdpenable &&
        // eslint-disable-next-line no-restricted-globals
        !isNaN(simId) &&
        eSimDeviceInfo?.deviceAttributes?.deviceCategory?.toLowerCase()?.includes('connected device')
          ? `&preferredSoftSim=${eSimDeviceInfo?.simInfo?.preferredSoftSim}&isConnectedDevice=true`
          : '';        

    if (window?.mfe?.scmUpgradeMfeEnable && window?.mfe?.scmCombinedGridwallFlow) {    /* NOSONAR: Legacy large component retained; complexity refactor deferred to avoid functional risk */
        window?.mfe?.historyRef?.push(
        `/content/vcg/assisted/product-detail.html?$iSscan=true&offerEligible=Y&${searchByName}activeMtn=${activeMtn}&deviceSKU=${skuId}&${
          isByodUpdate ? 'isByodUpdate=true' : 'isFromCPE=true'
        }&deviceId=${deviceIdFromPayload}&mtn=${activeMtn}&simId=${simId}${
          prospectByodFlow ? '&prospectByodFlow=true&ByodDeviceCompitable=true' : ''
        }&ispuCompatibleSIM=${eSimDeviceInfo?.simInfo?.ispuCompatibleSIM}${preferredSoftSimWatch}&isFromCombinedGridWall=true`
      );
    } else {
      navigate(
        `${getUIContextPathBAU()}/product-detail.html?$iSscan=true&offerEligible=Y&${searchByName}activeMtn=${activeMtn}&deviceSKU=${skuId}&${
          isByodUpdate ? 'isByodUpdate=true' : 'isFromCPE=true'
        }&deviceId=${deviceIdFromPayload}&mtn=${activeMtn}&simId=${simId}${
          prospectByodFlow ? '&prospectByodFlow=true&ByodDeviceCompitable=true' : ''
        }&ispuCompatibleSIM=${eSimDeviceInfo?.simInfo?.ispuCompatibleSIM}${preferredSoftSimWatch}`
      );
    }
    }
  };

  useEffect(() => {
    if (mtnNotGenerated) {
      const vzdl = window?.vzdl || {};
      if (vzdl?.target) vzdl.target.message = `Please generate MDN for the line ${activeMtn} to proceed`;
      window.vzdl = vzdl;
      sendCustomEvent('openView', window?.vzdl);
    }
  }, [mtnNotGenerated]);

  useEffect(() => {
    if (ValidateDeviceSimIdResultStatus === 'fulfilled' && !carrierLock) {
      if (popUp) isSingleLookUpModel();

      const deviceInfo = ValidateDeviceSimIdResult?.serviceBody?.serviceResponse?.context?.deviceInfo;
      const requestFlowType = 'DEVICE';
      const payload = devicePayload;
      if (!scmUpgradeMfeEnable) {
        window.store.dispatch(
          validateDeviceSimIdSuccess({
            eSimOnlyDevice: !!(
              deviceInfo &&
              deviceInfo.makeEtniPersApi &&
              deviceInfo.simInfo &&
              !deviceInfo.simInfo.dfillCompatibleSim
            ),
            skuId: deviceInfo.deviceSku,
            skuDisplayName: deviceInfo.skuDisplayName ? deviceInfo.skuDisplayName : '',
            deviceId: deviceInfo.deviceId,
            simId: deviceInfo.simInfo.iccid ? deviceInfo.simInfo.iccid : '',
            simLocalId: deviceInfo.simInfo.iccid,
            fmipLocked: deviceInfo.fmipLocked,
            manualEntrySimId: '',
            cpSimCard: !!deviceInfo.simInfo.iccid, // If the device has inbuilt sim, set customerProvidedSim as true
            cpSimCheckboxSelected: !!deviceInfo.simInfo.iccid,
            eid: deviceInfo && deviceInfo.simInfo && deviceInfo.simInfo.eID ? deviceInfo.simInfo.eID : '',
            launchPackageSku:
              requestFlowType === 'SIM'
                ? (deviceInfo && deviceInfo.simInfo && deviceInfo.simInfo.launchPackageSku) || ''
                : '',
            preferredSoftSim:
              deviceInfo && deviceInfo.simInfo && deviceInfo.simInfo.preferredSoftSim
                ? deviceInfo.simInfo.preferredSoftSim
                : '',
            ispuCompatibleSIM:
              deviceInfo && deviceInfo.simInfo && deviceInfo.simInfo.ispuCompatibleSIM
                ? deviceInfo.simInfo.ispuCompatibleSIM
                : '',
            isEmbeddedSim: payload?.isEmbeddedSimCall ?? false,
            etniApi: deviceInfo?.simInfo2 ? false : deviceInfo.makeEtniPersApi,
            currentSimIdInRequest: '',
            scanFromPDPLocalFlow: false,
          })
        );
      }
    }
    if (carrierLock) {
      dispatch(appMessageActions.addAppMessage('Carrier Lock is on, please unlock to continue.', 'error'));
    }
  }, [ValidateDeviceSimIdResult?.serviceBody, ValidateDeviceSimIdResultStatus]);

  useEffect(() => {
    if (!carrierLock) {
      navigateToProductDetails();
    }
  }, [eSimDeviceInfo]);

  useEffect(() => {
    if (secondImei && secondImei !== '') {
      setDeviceId(secondImei);
    }
  }, []);

  useEffect(() => {
    if (imie2 && imie2 !== '') {
      setDeviceId(imie2);
    }
  }, [imie2]);

  useEffect(() => {   /* NOSONAR: Legacy large component retained; complexity refactor deferred to avoid functional risk */
    if (eSimDataResults?.data?.data && eSimDataResults?.status === 'fulfilled') {
      const iccid = eSimDataResults.data.data.iccid || '';

      let eSimInfo = {};
      if (eSimDeviceInfo?.simInfo?.makeEtniPersApi) {
        eSimInfo = eSimDeviceInfo?.simInfo;
      } else if (eSimDeviceInfo?.simInfo2?.makeEtniPersApi) {
        eSimInfo = eSimDeviceInfo?.simInfo2;
      }
      const deviceIds = eSimInfo?.deviceId || '';

      if (!scmUpgradeMfeEnable) {
        window.store.dispatch(
          updateEsimData({
            simLocalId: iccid,
            deviceIds,
          })
        );
      }
      if (ispdpenable) {
        const preferredSoftSim = eSimInfo?.preferredSoftSim;
        const deviceID = eSimInfo.launchPackageSku;
        /* istanbul ignore next */
        if (window?.mfe?.isProspectNewCustomerTab || (scmUpgradeMfeEnable && scmCombinedGridwallFlow)) {
            let isByodUpdateQueryParam = '';
            if (window?.mfe?.isProspectNewCustomerTab &&  getQueryParamByName('defaultTab') && getQueryParamByName('defaultTab') === 'GR') {
              isByodUpdateQueryParam = 'isFromCPE=true';
            } else {
              isByodUpdateQueryParam = isByodUpdate ? 'isByodUpdate=true' : 'isFromCPE=true';
            }
          window?.mfe?.historyRef?.push(
            `/content/vcg/assisted/product-detail.html?offerEligible=Y&${searchByName}activeMtn=${activeMtn}&deviceSKU=${deviceID}&preferredSoftSim=${preferredSoftSim}&${
              isByodUpdateQueryParam
            }&eSimOnlyDevice=${eSimOnlyDevice}&eSim=true&deviceId=${deviceIdFromPayload}&mtn=${activeMtn}&simId=${iccid}${
              prospectByodFlow ? '&prospectByodFlow=true&ByodDeviceCompitable=true' : ''
            }&fromPage=combinedgridwall${scmCombinedGridwallFlow ? '&isFromCombinedGridWall=true' : ''}`
          );
        } else {
          navigate(
            `${getUIContextPathBAU()}/product-detail.html?$iSscan=true&offerEligible=Y&${searchByName}activeMtn=${activeMtn}&deviceSKU=${deviceID}&preferredSoftSim=${preferredSoftSim}&${
              isByodUpdate ? 'isByodUpdate=true' : 'isFromCPE=true'
            }&eSimOnlyDevice=${eSimOnlyDevice}&eSim=true&deviceId=${deviceIdFromPayload}&mtn=${activeMtn}&simId=${iccid}${
              prospectByodFlow ? '&prospectByodFlow=true&ByodDeviceCompitable=true' : ''
            }&fromPage=combinedgridwall`
          );
        }
      } else {
        const preferredSoftSim = eSimDeviceInfo?.simInfo?.preferredSoftSim;
        /* istanbul ignore next */
        if (window?.mfe?.isProspectNewCustomerTab || (scmUpgradeMfeEnable && scmCombinedGridwallFlow)) {
          window?.mfe?.historyRef?.push(
            `/content/vcg/assisted/product-detail.html?offerEligible=Y&${searchByName}activeMtn=${activeMtn}&deviceSKU=${skuId}&preferredSoftSim=${preferredSoftSim}&${
              isByodUpdate ? 'isByodUpdate=true' : 'isFromCPE=true'
            }&eSimOnlyDevice=${eSimOnlyDevice}&eSim=true&deviceId=${deviceIdFromPayload}&mtn=${activeMtn}&simId=${iccid}${
              prospectByodFlow ? '&prospectByodFlow=true&ByodDeviceCompitable=true' : ''
            }${scmCombinedGridwallFlow ? '&isFromCombinedGridWall=true' : ''}`
          );
        } else {
          navigate(
            `${getUIContextPathBAU()}/product-detail.html?$iSscan=true&offerEligible=Y&${searchByName}activeMtn=${activeMtn}&deviceSKU=${skuId}&preferredSoftSim=${preferredSoftSim}&${
              isByodUpdate ? 'isByodUpdate=true' : 'isFromCPE=true'
            }&eSimOnlyDevice=${eSimOnlyDevice}&eSim=true&deviceId=${deviceIdFromPayload}&mtn=${activeMtn}&simId=${iccid}${
              prospectByodFlow ? '&prospectByodFlow=true&ByodDeviceCompitable=true' : ''
            }`
          );
        }
      }
    }
  }, [eSimDataResults, eSimDataResults?.status]);

  // esim call for PDP
  const updateEsimData = (data) => ({
    type: 'UPDATE_ESIM_DATA',
    payload: data,
  });

  const validateDeviceSimIdSuccess = (payload) => ({
    type: 'VALIDATE_DEVICE_SIMID_SUCCESS',
    payload,
  });
  // end of PDP action check

  const isprepaycart = !!(
    cartDetails &&
    cartDetails?.cart &&
    cartDetails?.cart?.orderDetails &&
    cartDetails?.cart?.orderDetails?.isPrePayCart === 'Y'
  );
  const isRfexFlow =
    (sessionStorage.getItem('refundexchange') && sessionStorage.getItem('refundexchange') === 'true') || false;
  const lineDeviceIdFromLanding =
    selectedLine &&
    selectedLine?.length > 0 &&
    selectedLine[0]?.equipmentInfos &&
    selectedLine[0]?.equipmentInfos?.length > 0 &&
    selectedLine[0]?.equipmentInfos[0]?.deviceInfo &&
    selectedLine[0]?.equipmentInfos[0]?.deviceInfo.deviceId &&
    selectedLine[0]?.equipmentInfos[0]?.deviceInfo.deviceId !== '' &&
    selectedLine[0]?.equipmentInfos[0]?.deviceInfo.deviceId != null &&
    selectedLine[0]?.equipmentInfos[0]?.deviceInfo.deviceId !== undefined
      ? selectedLine[0]?.equipmentInfos[0]?.deviceInfo.deviceId
      : '';
  const deviceFromCart =
    lineActivityType &&
    lineActivityType !== 'DEO' &&
    lineInfoFind?.itemsInfo &&
    lineInfoFind?.itemsInfo.length > 0 &&
    lineInfoFind?.itemsInfo[0]?.cartItems &&
    lineInfoFind?.itemsInfo[0]?.cartItems?.cartItem
      ? lineInfoFind?.itemsInfo[0]?.cartItems?.cartItem?.find((x) => x.cartItemType === 'DEVICE')
      : null;
  const LineDeviceId =
    selectedLine?.[0]?.equipmentInfos && selectedLine?.[0]?.equipmentInfos.length > 0
      ? selectedLine?.[0]?.equipmentInfos[0]?.deviceInfo && selectedLine?.[0]?.equipmentInfos[0]?.deviceInfo?.deviceId
      : null;
  let selectedDeviceId = '';
  let selectedSimId = '';
  if (deviceFromCart && deviceFromCart?.deviceId) {
    selectedDeviceId = deviceIdInCart;
    selectedSimId = simIdInCart;
    if (props?.assistedFlag?.disableEsimAtLocalInventory !== 'TRUE' && isIndirect() && deviceFromCart.eDeviceId) {
      selectedDeviceId = deviceFromCart?.eDeviceId;
      selectedSimId = totalLines?.filter((cartSim) => cartSim.cartItemType === 'SIM')?.[0]?.eSIM;
    }
    //   } else if (indirectDeviceSimDetails) {
    //     const { deviceId = '', simId = '' } = indirectDeviceSimDetails;
    //     selectedDeviceId = deviceId;
    //     currentSimCompatible = indirectDeviceSimDetails?.currentSimCompatible ?? false;
    //     selectedSimId = simId;
    //   } else if (isRfexFlow && CHANNELS.OMNI_INDIRECT) {
    //     // selectedDeviceId = this.props.rpcDeviceIdInCart;
    //     // selectedSimId = this.props.rpcSimIdInCart;
  }
  const byodHumClearErrMsgFlag = () => {
    setByodHumClearErrMsg('');
  };
  const cancelOnKeyPress = (e) => {
    if (e.charCode === 13 || e.charCode === 32) {
      setDeviceName('');
      setShowAutoComplete(false);
    }
  };

  const cancelButton = () => {
    setDeviceName('');
    setShowAutoComplete(false);
  };
  const validateSimIdRequestFlag = () => {
    const payload = {
      mtn: activeMtn,
      deviceId: cpeDeviceId,
      simId: '',
      cpSimCard: false,
      fromCpe: true,
      isCustomerProvidedEquipment: true,
    };
    validateDeviceSimIdRequest(payload);
  };
  const validateSimIdRequestFlag1 = () => {
    const updatedDeviceName = selectedDeviceName || deviceName;
    const payload = {
      deviceName: updatedDeviceName,
      carrier: carrierName,
      mtn: activeMtn,
      deviceId: '',
      cpeWthoutDevIdFlag: true,
    };
    validateDeviceSimIdRequest(payload);
  };

  const onCheckBoxChange = () => {
    setCpeCheckbox(!cpeCheckbox);
    validateSimIdRequestFlag(); // validateSimIDcall
  };
  const updateCarrier = (item) => {
    let disableBtn = true;
    if (item?.carrier?.length > 0) {
      disableBtn = false;
      dispatch(appMessageActions.clearAppMessages());
    } else {
      dispatch(
        appMessageActions.addAppMessage(
          'Please enter device ID to proceed for non Verizon device',
          'ERROR',
          true,
          true,
          true
        )
      );
    }
    let deviceNameDetails = '';
    item?.deviceAndCarrier?.map((data) => {
      if (data.carrierName === item.carrier[0]) {
        deviceNameDetails = data.deviceName;
      }
      return deviceNameDetails;
    });
    setDisableButton(disableBtn);
    setDeviceName(deviceNameDetails);
    setShowAutoComplete(false);
    setSelectCarrierList(item?.carrier ? item?.carrier : '');
    setCarrierName(item?.carrier?.[0] ? item?.carrier?.[0] : '');
    setSelectedDeviceData(item);
  };

  const onContinueClicked = () => {
    if (carrierName !== '' && deviceName !== '') {
      validateSimIdRequestFlag1();
    } else if (getQueryParamByName('SecondNumber') || (deviceId && scmUpgradeMfeEnable)) {
      validateDeviceSimIdRequest({
        mtn: activeMtn,
        deviceId: secondImei || deviceId,
        cpSimCard: false,
        isCustomerProvidedEquipment: true,
        fromCpe: true,
        deviceFlow: true,
        scanFromLanding: false,
        fromInterim: '',
      });
    }
  };
  const isDualSimEntiLookupModalVisibleUpdate = () => {
    setIsDualSimEntiLookupModalVisible(!isDualSimEntiLookupModalVisible);
  };
  const handleChangeDeviceName = (e) => {
    const input = e.target.value;
    setDeviceName(input);
    if (input === '') {
      byodHumClearErrMsgFlag();
      setShowAutoComplete(false);
      setDisableButton(true);
      return true;
    }
    if (!input.length) {
      setDeviceError(false);
    } else if (CustomerData?.byodHumErrMsg || deviceError) {
      byodHumClearErrMsgFlag();
      setDeviceError(false);
    } else if (!deviceError) {
      const requestBodySmartImeiTypeAhead = {
        model: input,
        deviceCategory: deviceCategory?.toLowerCase()?.includes('smartwatch')
          ? 'Connected Devices'
          : deviceCategory || selectedDevice,
      };
      getSmartImeiTypeAheadList({ body: requestBodySmartImeiTypeAhead, spinner: false });
      setShowAutoComplete(true);
      setCarrierName('');
      setDisableButton(true);
      setSelectCarrierList([]);
      dispatch(appMessageActions.clearAppMessages());
    }
  };

  const handleValidateDeviceSimId = (carrierValue) => {
    setCarrierName(carrierValue);
    selectedDeviceData?.deviceAndCarrier?.forEach((item) => {
      if (carrierValue === item.carrierName) {
        setSelectedDeviceName(item.deviceName);
      }
    });
    if (CustomerData?.byodHumErrMsg) {
      byodHumClearErrMsg(); // need to check
      dispatch(appMessageActions.clearAppMessages());
    }
  };

  const getImei2FromMtnDetails = () => {
    const snPerkInPSFlowFFlag =
      JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.snPerkInPSFlowFFlag === 'TRUE' || false;
    let imei2 = null;
    if (snPerkInPSFlowFFlag) {
      const isPrimaryNoAsNewLine = cartDetails?.cart?.lineDetails?.lineInfo?.find(
        (line) =>
          line?.mtnDetails?.lineNumber === primaryMtnofSecondNumber &&
          ['EUP', 'AAL', 'NSE', 'EUPBYOD'].includes(line?.lineActivityType)
      );
      const cartItems = isPrimaryNoAsNewLine?.itemsInfo?.[0]?.cartItems?.cartItem;
      imei2 = cartItems?.length > 0 ? cartItems[0]?.imei2 : null;
    }
    return imei2;
  };

  const handleChangeDeviceIDs = (e, ivrDeviceId) => {
    const input = getImei2FromMtnDetails() || ivrDeviceId || e.target.value.trim();
    const isValid = inputRegEx.test(input);
    setDeviceId(input);
    setDeviceError(!isValid);
  };
  const goBackToGridwall = () => {
    props?.setIsCloseByod(true);
    props?.handleByodflag();
    sessionStorage.removeItem('secondNumber');
    sessionStorage.setItem('isFromBack', true);
    sessionStorage.setItem('isSecondNumLocal', false);
  };

  const initSimDetailsCall = (val, payload) => {
    const isActiveLineMtnType = lineInfoFind?.mtnDetails?.mtnType
      ? lineInfoFind?.mtnDetails?.mtnType.toUpperCase()
      : '';
    const isMtnTypePreToPost = isActiveLineMtnType === MTN_TYPE_PRE_TO_POST;
    const isMtnTypeVisible = isActiveLineMtnType === MTN_TYPE_VISIBLE;
    const isMtnTypeYahoo = isActiveLineMtnType === MTN_TYPE_YAHOO;
    const isMtnTypeHarmony = isActiveLineMtnType === MTN_TYPE_HARMONY;
    const isMtnTypePortIn = lineInfoFind?.portinMtnAssignment || false;
    const updatedSimInfo = eSimDeviceInfo?.simInfo?.eID ? eSimDeviceInfo?.simInfo : eSimDeviceInfo?.simInfo2;
    const { preferredSoftSim } = payload?.preferredSoftSim ? payload : updatedSimInfo;
    const eID = payload?.preferredSoftSim ? payload?.eid : updatedSimInfo?.eID;
    const billingSystemFromCart = cartDetails?.cart?.orderDetails?.billingSystem ?? '';
    let billerId = '';
    if (CustomerData?.billingSystem) {
      billerId = CustomerData.billingSystem;
    } else if (billingSystemFromCart) {
      billerId = billingSystemFromCart;
    } else if (prospectByodFlow && cartDetails?.cart?.orderDetails?.billingSystem) {
      billerId = cartDetails?.cart?.orderDetails?.billingSystem;
    }
    const isBYODFlow = prospectByodFlow ? 'N' : 'D';
    const eSimRequestBody = {
      billerId,
      mdn: activeMtn,
      sku: preferredSoftSim,
      eid: eID,
      processInd: val ? 'N' : isBYODFlow,
    };
    if (
      isMtnTypePreToPost ||
      isMtnTypeVisible ||
      isMtnTypeYahoo ||
      isMtnTypeHarmony ||
      isMtnTypePortIn ||
      isprepaycart
    ) {
      eSimRequestBody.processInd = 'M';
    }
    eSimData({ body: eSimRequestBody });
  };

  const onClickEntiLookupOption = (option) => {     /* NOSONAR: Legacy large component retained; complexity refactor deferred to avoid functional risk */
    if (option === 'yes') {
      const lineInfo = activeMtn && selectedLine;
      const preferredSoftSim = eSimDeviceInfo?.simInfo?.preferredSoftSim;
      const val = !!(
        lineInfo &&
        lineInfo.length > 0 &&
        lineInfo[0].isNewlyAddedLine &&
        lineInfo[0].isNewlyAddedLine === true
      );
      setIsSingleSimEntiLookupModalVisibleByod(!isSingleSimEntiLookupModalVisibleByod);
      if (skipIccidCall === 'TRUE' || /true/i.test(sessionStorage.getItem('isSecondNumFlow')) || skipICCIDFFlag) {
        /* istanbul ignore next */
        if (window?.mfe?.isProspectNewCustomerTab || (scmUpgradeMfeEnable && scmCombinedGridwallFlow)) {
          window?.mfe?.historyRef?.push(
            `/content/vcg/assisted/product-detail.html?${searchByName}&offerEligible=Y&activeMtn=${activeMtn}&deviceSKU=${skuId}&isFromCPE=true&deviceId=${deviceId}&eId=${eId}&preferredSoftSim=${preferredSoftSim}&eSim=true${
              prospectByodFlow ? '&prospectByodFlow=true' : ''
            }${scmCombinedGridwallFlow ? '&isFromCombinedGridWall=true' : ''}`
          );
        } else {
          navigate(
            `${getUIContextPathBAU()}/product-detail.html?${searchByName}&offerEligible=Y&activeMtn=${activeMtn}&deviceSKU=${skuId}&isFromCPE=true&deviceId=${deviceId}&eId=${eId}&preferredSoftSim=${preferredSoftSim}&eSim=true${
              prospectByodFlow ? '&prospectByodFlow=true' : ''
            }`
          );
        }
      } else {
        initSimDetailsCall({ isCustomerProvidedEquipment: val });
      }
      updateSetUpPopUp();
    } else if (option === 'no') {
      setIsSingleSimEntiLookupModalVisibleByod(!isSingleSimEntiLookupModalVisibleByod);
      updateSetUpPopUp();
    }
  };

  let renderNoDevice = '';
  if (getQueryParamByName('searchByName') !== 'false' && (!isD2D() || isAsurion())) {
    renderNoDevice = (
      <div className='u-text14'>
        <div className='u-positionRelative'>
          <Padding16>
            <Body color='#000000' size='large' primitive='p'>
              or
            </Body>
          </Padding16>
          <Body color='#000000' size='large' primitive='p' bold>
            {props?.notDeviceLabel ? props?.notDeviceLabel : `Do not have Device ID? You can search by name`}
          </Body>
          <Body color='#000000' size='large' primitive='p'>
            {props?.quoteLabel
              ? props?.quoteLabel
              : `(Quote can still be created, but cannot proceed to order without the device ID)`}
          </Body>
          <PaddingTop24>
            <CpeInpuField>
              <Input
                data-testid='HandleChangeDeviceName'
                label='Search by name'
                placeholder='searchName'
                name='searchName'
                id='searchName'
                onChange={(e) => handleChangeDeviceName(e)}
                value={deviceName}
                className='bold'
                style={{ fontSize: '16px', color: '#000', width: '100%' }}
                iconName=''
                width='50%'
              />
              {deviceName.length > 0 && showAutoComplete && (
                <span
                  style={{ bottom: '30px', padding: '0px!important', marginRight: '10px', visibility: 'hidden' }}
                  className='Col Col--4 u-floatRight font-13 Icon Icon--close'
                  onClick={() => cancelButton()}
                  onKeyDown={(e) => cancelOnKeyPress(e)}
                  data-testid='HandleChangeDeviceNameClose'
                />
              )}
              <div
                className='autocomplete cpeInpuField'
                style={{ visibility: showAutoComplete ? 'visible' : 'hidden', top: '194px', width: '51%' }}
              >
                <AutoCompleteItems data-testid='UpdateCarrier'>
                  {SmartImeiTypeAheadListResult?.data?.data &&
                    SmartImeiTypeAheadListResult?.data?.data.slice(0, 5).map((item) => (
                      <div
                        key={item}
                        data-testid={`options-${item.modifiedName}`}
                        onMouseDown={() => {
                          updateCarrier(item);
                        }}
                      >
                        {item?.modifiedName}
                      </div>
                    ))}
                </AutoCompleteItems>
              </div>
            </CpeInpuField>
          </PaddingTop24>
          <PaddingTop24>
            {selectCarrierList && selectCarrierList.length > 0 && deviceName && (
              <CpeInpuField>
                <div>Select carrier</div>
                <DropdownSelect
                  value={carrierName}
                  onChange={(e) => handleValidateDeviceSimId(e.target.value)}
                  width='62%'
                >
                  {selectCarrierList.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </DropdownSelect>
              </CpeInpuField>
            )}
          </PaddingTop24>
        </div>
        <div style={{ paddingBottom: showAutoComplete ? '120px' : '35px' }} />
      </div>
    );
  }
  const offersLine = props?.offers?.lines?.filter(
    (item) => item?.mtn?.replace('New line ', 'newLine') === props.activeMtn
  );

  
  return (
    <PaddingLeft16 data-testid='Cpe' {...(window?.mfe?.scmDeviceMfeEnable && isScmfullScreenFix && {style:{ height: '62vh'}})}>
      <PaddingTopBottom16 id='tooltipParent'>
        {mtnNotGenerated && (
          <div>
            <Notification
              type='error'
              title={`Please generate MDN for the line ${activeMtn} to proceed`}
              fullBleed={false}
              inline={false}
              disableFocus
              layout='horizontal'
              buttonData={[
                {
                  children: 'Assign Number',
                  onClick: () => {
                    Emitter.emit('update_validate_and_review');
                    navigate(`${getUIContextPathBAU()}/numberselection.html?fromPage=CombinedGridwall`);
                  },
                },
              ]}
            />
          </div>
        )}
        {(offersLine?.length > 0 && props.lineHasOffer && props.nationalCheck && (
          <BadgeDiv fillColor='blue' data-testid='offer-div'>
            <Body primitive='span' size='small' color='#ffffff' bold>
              Offer: {offersLine[0]?.offers[0]?.description}
            </Body>
            {offersLine[0]?.offers[0]?.propositionMessage && (
              <TooltipWrapper>
                <Tooltip title='Offer Description' size='small' iconFillColor='#FFFFFF' containerId='tooltipParent'>
                  {offersLine[0]?.offers[0]?.propositionMessage}
                </Tooltip>
              </TooltipWrapper>
            )}
          </BadgeDiv>
        )) || <BlankDiv />}
      </PaddingTopBottom16>
      <StyledTitleName>
        <PaddingTopBottom16>
          <Title id='title-name' size='small' bold color='#000000'>
            Add customer-provided equipment
          </Title>
        </PaddingTopBottom16>
      </StyledTitleName>
      <PaddingTop20>
        <Checkbox
          name='SIMCardProvided'
          width='auto'
          selected={cpeCheckbox}
          disabled={!isWSAPCpeError}
          surface='light'
          error={false}
          errorText='Please agree to the terms and conditions.'
          onChange={onCheckBoxChange}
          inputProps={{ 'data-testid': 'CheckBoxChange' }}
        >
          This device is customer-provider equipment
        </Checkbox>
      </PaddingTop20>
      <PaddingTop24>
        <Body size='medium' primitive='span' bold color='#000000'>
          Device Id
        </Body>
        <CpeInpuField>
          <DeviceScan
            ScanFromLanding={ScanFromLanding}
            lineDeviceIdFromLanding={lineDeviceIdFromLanding}
            lineActivityType={lineActivityType}
            isRfexFlow={isRfexFlow}
            selectedDeviceId={selectedDeviceId}
            ivrDeviceId={ivrDeviceIds}
            handleChangeDeviceIDs={(e, ivrDeviceId) => handleChangeDeviceIDs(e, ivrDeviceId)}
            isDeviceFromCart={!!deviceFromCart}
            LineDeviceId={LineDeviceId}
            isPdpPage
            showScanner={false}
            isprepaycart={isprepaycart}
            isDWOS='true'
            activeMtn={activeMtn}
            isFiveG={isFiveG}
            isProspectflow={isProspectflow}
            isIndirect={!!isIndirect()}
            validateDeviceSimIdRequest={validateDeviceSimIdRequest}
            cartDetails={cartDetails}
            CustomerData={CustomerData}
            selectedSimId={selectedSimId}
            SecNumFlow={SecNumFlow}
            imeiOfPrimaryMtn={imeiOfPrimaryMtn}
            isSelectedDevice={isSelectedDevice}
            primaryMtnofSecondNumber={primaryMtnofSecondNumber}
          />
        </CpeInpuField>
      </PaddingTop24>
      {CustomerData?.byodHumErrMsg && deviceName === '' && (
        <span className='u-textBold u-paddingLeftSmall font-12' style={{ color: '#F50A23' }}>
          {CustomerData?.byodHumErrMsg}
        </span>
      )}
      {renderNoDevice}
      {/* footer */}
      <StyledPaddingTop32>
        <ButtonGroup
          childWidth='100%'
          rowQuantity={{ desktop: 2 }}
          data={[
            {
              'data-testid': 'CpeClickContinue',
              'data-track': 'ByodContinue',
              children: 'Continue',
              size: 'small',
              use: 'primary',
              width: 'auto',
              onClick: () => onContinueClicked(),
              disabled:
                (CustomerData?.byodHumErrMsg && deviceId !== '' && deviceName === '') ||
                deviceError ||
                (deviceId === '' && disableButton) ||
                carrierLock,
            },
            {
              'data-testid': 'CpeClickClose',
              'data-track': 'ByodClose',
              children: 'Close',
              size: 'small',
              use: 'secondary',
              width: 'auto',
              onClick: () => goBackToGridwall(),
            },
          ]}
          alignment='left'
        />
      </StyledPaddingTop32>
      {isDualSimEntiLookupModalVisible && (
        <ESim
          lineActivityType={lineActivityType}
          eSimModelData={eSimPopUpData}
          totalLines={totalLines}
          updateDevicePayload={updateDevicePayload}
          activeMtn={activeMtn}
          sourcefrom='combinedgridwall'
          initSimDetailsCall={initSimDetailsCall}
          isDualSimEntiLookupModalVisible={isDualSimEntiLookupModalVisible}
          isDualSimEntiLookupModalVisibleUpdate={isDualSimEntiLookupModalVisibleUpdate}
          updateSetUpPopUp={updateSetUpPopUp}
          ProspectByodFlow={prospectByodFlow}
          scanCheck={scanCheck}
        />
      )}
      {isSingleSimEntiLookupModalVisibleByod && (
        <ConfirmationDialogBox
          data-testid='confirmationBox'
          message='This device requires an eSim for activation, do you wish to continue?'
          btnYesText='Yes'
          btnNoText='No'
          isNoBtnDisabled={false}
          handleConfirmationDialogBoxClick={(val) => {
            onClickEntiLookupOption(val);
          }}
        />
      )}
      {showCarrierLockPopup && (
        <CarrierLockModal
          data-testid='carrierLockModal'
          showCarrierLockPopup={showCarrierLockPopup}
          setShowCarrierLockPopup={setShowCarrierLockPopup}
        />
      )}
    </PaddingLeft16>
  );
};
Cpe.propTypes = {
  cartDetails: PropTypes.shape({
    cart: PropTypes.shape({
      lineDetails: PropTypes.shape({
        lineInfo: PropTypes.arrayOf(
          PropTypes.shape({
            // New properties added:
            isNewlyAddedLine: PropTypes.bool,
            mobileNumber: PropTypes.string,
            equipmentInfos: PropTypes.arrayOf(
              PropTypes.shape({
                deviceInfo: PropTypes.shape({
                  deviceId: PropTypes.string,
                }),
              })
            ),
          })
        ),
      }),
    }),
  }),
  ValidateDeviceSimIdResult: PropTypes.shape({
    serviceBody: PropTypes.shape({
      serviceResponse: PropTypes.shape({
        context: PropTypes.shape({
          deviceInfo: PropTypes.shape({
            carrierLock: PropTypes.any, // Adjust type if needed (e.g., PropTypes.string)
          }),
        }),
      }),
    }),
  }),
  deviceCategory: PropTypes.string,
  setShowCarrierLockPopup: PropTypes.func,
  showCarrierLockPopup: PropTypes.bool,
};

export default Cpe;
