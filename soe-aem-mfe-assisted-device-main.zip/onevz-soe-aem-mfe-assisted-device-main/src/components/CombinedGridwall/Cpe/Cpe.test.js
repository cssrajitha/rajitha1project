import React from 'react';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import { render, screen, fireEvent } from '../../../modules/test-utils/renderHelper';
import Cpe from './Cpe';
import customerProfile from '../../../pages/PDP/mocks/api/customerProfile.json';
import data from '../__mocks__/mockCombinedGridwallData.json';
import * as APIServiceHooks from '../../../modules/services/APIService/APIServiceHooks';

const mockedUsedNavigate = jest.fn();

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => mockedUsedNavigate,
}));
jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    getAssistedCradlePropertyV2: () => ['TRUE'],
  }),
  { virtual: true },
);
jest.mock(
  '../../../modules/utils',
  () => ({
    __esModule: true,
    ...jest.requireActual('../../../modules/utils'),
    isFunctionalityEnabled: () => true,
  }),
  { virtual: true },
);
jest.mock(
  '../../../modules/services/APIService/APIServiceHooks',
  () => {
    let index = 1;
    return {
      __esModule: true,
      ...jest.requireActual('../../../modules/services/APIService/APIServiceHooks'),
      useLazyESimDetailsQuery: () => {
        if (index === 1) {
          return [
            () => {
              index += 1;
              return {};
            },
            {
              status: 'fulfilled',
              isUninitialized: false,
              isLoading: false,
              isSuccess: true,
              isError: false,
              isFetching: false,
              data: {
                status: 'success',
                data: {
                  iccid: '12345678909876',
                },
              },
            },
          ];
        }
        return [() => {}, { data: {} }];
      },
    };
  },
  { virtual: true },
);

const handlers = [
  rest.post(`*/cart/smartimei-typeahead`, (req, res, ctx) => {
    console.log('inside /cart/smartimei-typeahead');
    return res(ctx.status(200), ctx.json(data.smartimeiTypeahead));
  }),

  rest.post(`*/cart/validate-deviceSimId`, (req, res, ctx) => {
    console.log('inside /cart/validate-deviceSimId');
    return res(ctx.status(200), ctx.json(data.validateDeviceSimId));
  }),
  rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
    console.log('inside /cart/eSimDetails');
    return res(ctx.status(200), ctx.json(data.eSimDetails));
  }),
];

const handlers1 = [
  rest.post(`*/cart/smartimei-typeahead`, (req, res, ctx) => {
    console.log('inside /cart/smartimei-typeahead');
    return res(ctx.status(200), ctx.json(data.smartimeiTypeahead));
  }),
  rest.post(`*/cart/validate-deviceSimId`, (req, res, ctx) => {
    console.log('inside /cart/validate-deviceSimId');
    return res(ctx.status(200), ctx.json(data.validateDeviceSimId2));
  }),
  rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
    console.log('inside /cart/eSimDetails');
    return res(ctx.status(200), ctx.json(data.eSimDetails));
  }),
];
const customerProfData = customerProfile.data.customer;
customerProfData.homeSalesAddress = {
  bundles: {
    bundleName: '5GHomeSelfInstall',
  },
};
const props = {
  activeMtn: '8482470044',
  prospectByodFlow: true,
  updateSetUpPopUp: jest.fn(),
  setIsCloseByod: jest.fn(),
  popUp: true,
  showCarrierLockPopup: true,
  setShowCarrierLockPopup: jest.fn(),
  ValidateDeviceSimIdResultStatus: 'fulfilled',
  devicePayload: {
    deviceName: 'IPHONE 11',
    carrier: 'VERIZON',
    deviceId: '354245334007682',
  },
  ValidateDeviceSimIdResult: {
    data: data.validateDeviceSimId,
    ...data.validateDeviceSimId,
  },
  assistedFlag: {
    disableEsimAtLocalInventory: 'FALSE',
  },
  selectedLine: [
    {
      deviceTypeSelected: '5G Internet',
      equipmentInfos: [
        {
          deviceInfo: {
            deviceId: '354245334007682',
          },
        },
      ],
    },
  ],
  lineActivityType: 'VSO',
  totalLines: [
    {
      mobileNumber: '8482470044',
      equipmentInfos: [
        {
          simInfo: {
            simId: '123456',
          },
          deviceInfo: {
            deviceId: '354245334007682',
          },
        },
      ],
      itemsInfo: [
        {
          cartItems: {
            cartItem: [{ cartItemType: 'DEVICE', deviceId: '354245334007682', eDeviceId: '354245334007682' }],
          },
        },
      ],
    },
  ],
  appPropertiesFromSessionStorage: {
    isLandingRedesignFlow: true,
    handleChangeDeviceIDs: jest.fn(),
  },
  CustomerData: customerProfData,
  commonInfo: customerProfile.data.commonInfo,
  cartDetails: {
    cartHeader: {},
    orderDetails: {},
    cart: {
      lineDetails: { lineInfo: [{ itemsInfo: [{ cartItems: { cartItem: [{ imei2: '1212122121' }] } }] }] },
      orderDetails: { isPrePayCart: 'Y' },
    },
  },
  handleByodflag: jest.fn(),
  offers: {
    lines: [
      {
        mtn: '8482470044',
        offers: [
          {
            complianceType: 'EQP',
            sku: '594981',
            description: '$540 over 36 mos BYOD BIC on Unlimited Ultimate PP',
            compatibleIndicator: 'N',
            propId: '2841',
            aal: 'Y',
            offerCompliance: 'N',
            propositionMessage: 'BYOD BIC $540 over 36 months on Unlimited Ultimate Bic No',
            buyGetInd: 'G',
            offerSubType: 'BYOD',
          },
        ],
        deviceCategory: 'smartphone',
      },
    ],
  },
  validateDeviceSimIdRequest: jest.fn(),
  lineHasOffer: true,
  nationalCheck: true,
  deviceCategory: 'smartwatch',
};
const offerComponentProps = {
  activeMtn: 'newLine1',
  updateSetUpPopUp: jest.fn(),
  setIsCloseByod: jest.fn(),
  popUp: true,
  showCarrierLockPopup: true,
  setShowCarrierLockPopup: jest.fn(),
  ValidateDeviceSimIdResultStatus: 'fulfilled',
  devicePayload: {
    deviceName: 'IPHONE 11',
    carrier: 'VERIZON',
    deviceId: '354245334007682',
  },
  ValidateDeviceSimIdResult: {
    data: data.validateDeviceSimId,
    ...data.validateDeviceSimId,
  },
  assistedFlag: {
    disableEsimAtLocalInventory: 'FALSE',
  },
  selectedLine: [
    {
      deviceTypeSelected: '5G Internet',
      equipmentInfos: [
        {
          deviceInfo: {
            deviceId: '354245334007682',
          },
        },
      ],
    },
  ],
  lineActivityType: 'VSO',
  totalLines: [
    {
      mobileNumber: 'newLine1',
      equipmentInfos: [
        {
          simInfo: {
            simId: '123456',
          },
          deviceInfo: {
            deviceId: '354245334007682',
          },
        },
      ],
      itemsInfo: [
        {
          cartItems: {
            cartItem: [{ cartItemType: 'DEVICE', deviceId: '354245334007682', eDeviceId: '354245334007682' }],
          },
        },
      ],
    },
  ],
  appPropertiesFromSessionStorage: {
    isLandingRedesignFlow: true,
    handleChangeDeviceIDs: jest.fn(),
  },
  CustomerData: customerProfData,
  commonInfo: customerProfile.data.commonInfo,
  cartDetails: { cartHeader: {}, orderDetails: {}, cart: { orderDetails: { isPrePayCart: 'Y' } } },
  handleByodflag: jest.fn(),
  offers: {
    lines: [
      {
        mtn: 'New line 1',
        offers: [
          {
            complianceType: 'EQP',
            sku: '594981',
            description: '$540 over 36 mos BYOD BIC on Unlimited Ultimate PP',
            compatibleIndicator: 'N',
            propId: '2841',
            aal: 'Y',
            offerCompliance: 'N',
            propositionMessage: 'BYOD BIC $540 over 36 months on Unlimited Ultimate Bic No',
            buyGetInd: 'G',
            offerSubType: 'BYOD',
          },
        ],
        deviceCategory: '5G Smartphone',
      },
    ],
    offerSourceSystem: 'OC_NATIONAL',
  },
  lineHasOffer: true,
  nationalCheck: true,
  validateDeviceSimIdRequest: jest.fn(),
};

const props1 = {
  activeMtn: '8482470044',
  updateSetUpPopUp: jest.fn(),
  setIsCloseByod: jest.fn(),
  popUp: true,
  showCarrierLockPopup: true,
  setShowCarrierLockPopup: jest.fn(),
  ValidateDeviceSimIdResultStatus: 'fulfilled',
  ValidateDeviceSimIdResult: {
    serviceBody: {
      serviceResponse: {
        context: {
          deviceInfo: {
            eSIMOnly: false,
            makeEtniPersApi: true,
            simInfo2: { makeEtniPersApi: true },
            simInfo: { iccid: '3456' },
          },
        },
      },
    },
  },
  appPropertiesFromSessionStorage: {
    isLandingRedesignFlow: true,
    handleChangeDeviceIDs: jest.fn(),
  },
  CustomerData: customerProfData,
  commonInfo: customerProfile.data.commonInfo,
  cartDetails: { cartHeader: {}, orderDetails: {}, cart: { orderDetails: { isPrePayCart: 'Y' } } },
  handleByodflag: jest.fn(),
  offers: {
    lines: [
      {
        mtn: '8482470044',
        offers: [
          {
            complianceType: 'EQP',
            sku: '594981',
            description: '$540 over 36 mos BYOD BIC on Unlimited Ultimate PP',
            compatibleIndicator: 'N',
            propId: '2841',
            aal: 'Y',
            offerCompliance: 'N',
            propositionMessage: 'BYOD BIC $540 over 36 months on Unlimited Ultimate Bic No',
            buyGetInd: 'G',
            offerSubType: 'BYOD',
          },
        ],
        deviceCategory: 'smartphone',
      },
    ],
  },
  validateDeviceSimIdRequest: jest.fn(),
  lineHasOffer: true,
  nationalCheck: true,
};
const props2 = {
  ...props,
  prospectByodFlow: true,
  activeMtn: '8482470044',
  deviceCategory: 'smartphone',
};
const props3 = {
  ...props,
  prospectByodFlow: true,
  activeMtn: '8482470044',
  devicePayload: {
    deviceName: 'IPHONE 11',
    carrier: '',
    deviceId: '354245334007682',
  },
  ValidateDeviceSimIdResult: {
    data: data.validateDeviceSimId,
    ...data.validateDeviceSimId,
  },
};
const props4 = {
  ...props,
  prospectByodFlow: true,
  activeMtn: '8482470044',
  devicePayload: {
    deviceName: 'IPHONE 11',
    carrier: '',
    deviceId: '354245334007682',
  },
  ValidateDeviceSimIdResult: {
    data: data.validateDeviceSimId3,
    ...data.validateDeviceSimId3,
  },
  notDeviceLabel: 'no device found',
  quoteLabel: 'quoteLabel',
  CustomerData: customerProfile.data.customer2,
};

const props5 = {
  activeMtn: 'newLine',
  updateSetUpPopUp: jest.fn(),
  setIsCloseByod: jest.fn(),
  popUp: true,
  showCarrierLockPopup: true,
  setShowCarrierLockPopup: jest.fn(),
  ValidateDeviceSimIdResultStatus: 'fulfilled',
  devicePayload: {
    deviceName: 'IPHONE 11',
    carrier: 'VERIZON',
    deviceId: '354245334007682',
  },
  ValidateDeviceSimIdResult: {
    data: data.validateDeviceSimId,
    ...data.validateDeviceSimId,
  },
  assistedFlag: {
    disableEsimAtLocalInventory: 'FALSE',
  },
  selectedLine: [
    {
      deviceTypeSelected: '5G Internet',
      equipmentInfos: [
        {
          deviceInfo: {
            deviceId: '354245334007682',
          },
        },
      ],
    },
  ],
  lineActivityType: 'VSO',
  totalLines: [
    {
      mobileNumber: '8482470044',
      equipmentInfos: [
        {
          simInfo: {
            simId: '123456',
          },
          deviceInfo: {
            deviceId: '354245334007682',
          },
        },
      ],
      itemsInfo: [
        {
          cartItems: {
            cartItem: [{ cartItemType: 'DEVICE', deviceId: '354245334007682', eDeviceId: '354245334007682' }],
          },
        },
      ],
    },
  ],
  appPropertiesFromSessionStorage: {
    isLandingRedesignFlow: true,
    handleChangeDeviceIDs: jest.fn(),
  },
  CustomerData: customerProfData,
  commonInfo: customerProfile.data.commonInfo,
  cartDetails: { cartHeader: {}, orderDetails: {}, cart: { orderDetails: { isPrePayCart: 'Y' } } },
  handleByodflag: jest.fn(),
  offers: {
    lines: [
      {
        mtn: '8482470044',
        offers: [
          {
            complianceType: 'EQP',
            sku: '594981',
            description: '$540 over 36 mos BYOD BIC on Unlimited Ultimate PP',
            compatibleIndicator: 'N',
            propId: '2841',
            aal: 'Y',
            offerCompliance: 'N',
            propositionMessage: 'BYOD BIC $540 over 36 months on Unlimited Ultimate Bic No',
            buyGetInd: 'G',
            offerSubType: 'BYOD',
          },
        ],
        deviceCategory: 'smartphone',
      },
    ],
  },
  validateDeviceSimIdRequest: jest.fn(),
  lineHasOffer: true,
  nationalCheck: true,
};

const props6 = {
  ...props,
  primaryMtnofSecondNumber: '5185673926',
  SecNumFlow: true,
  landingLinesInfo: customerProfData.billAccounts[0].mtns,
  prospectByodFlow: true,
  activeMtn: '8482470044',
  devicePayload: {
    deviceName: 'IPHONE 11',
    carrier: '',
    deviceId: '354245334007682',
  },
  ValidateDeviceSimIdResult: {
    data: data.validateDeviceSimId3,
    ...data.validateDeviceSimId3,
  },
  notDeviceLabel: 'no device found',
  quoteLabel: 'quoteLabel',
  CustomerData: customerProfile.data.customer2,
};
const server = setupServer(...handlers);
const server1 = setupServer(...handlers1);

const dispatchedActions = [];
const mockStore = {
  dispatch: (action) => {
    dispatchedActions.push(action);
  },
};

describe('Validate sim component 1st', () => {
  window.mfe = { isProspectNewCustomerTab: true };
  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });
  afterAll(() => {
    server.close();
    sessionStorage.setItem('APIContext', '');
  });
  beforeEach(() => {
    window.vzdl = {};
    // Object.defineProperty(window, 'store', mockStore);
    window.store = mockStore;
    const location = {
      ...window.location,
      search: '?activeMtn=8482470044',
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost/?activeMtn=8482470044&isWSAPCpeError=${true}`;
    window.location.href = `http://localhost/combinedgridwall.html?fromAssignMtn=true&SecondNumber=true&primaryMtn=${true}&activeMtn=${true}&imei2=125055454858`;
    sessionStorage.setItem('secondImei', '125055454858');
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ isBYODCarrierLockFFlag: 'TRUE' }));
    render(<Cpe {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('simple render test', async () => {
    const testid = await screen.findByText('Add customer-provided equipment');
    expect(testid).toBeInTheDocument();
  });

  test('checking  HandleChangeDeviceName function', () => {
    const result = screen.getByTestId('HandleChangeDeviceName');
    expect(result).toBeDefined();
    fireEvent.change(result, { target: { value: 'name' } });
    fireEvent.change(result, { target: { value: '' } });
  });

  test('Chcekbox click testing', async () => {
    const CheckBoxChange = await screen.findByRole('checkbox', { name: 'This device is customer-provider equipment' });
    fireEvent.change(CheckBoxChange, { target: { checked: true } });
  });

  test('CheckBoxChange button to be rendered on screen', () => {
    const CpeClick = screen.getByTestId('test-child-wrapper');
    fireEvent.click(CpeClick);
  });
  test('CheckBoxChange button to be rendered on screen', () => {
    window.sessionStorage.setItem('secondImei', '350143163823135');
    window.sessionStorage.setItem('isSecondNumFlow', 'true');
    const CpeClickContinue = screen.getByTestId('CpeClickContinue');
    fireEvent.click(CpeClickContinue);
    fireEvent.change(CpeClickContinue, { target: { value: 'name' } });
  });

  test('CpeClickClose button to be rendered on screen', () => {
    const CpeClickClose = screen.getByTestId('CpeClickClose');
    fireEvent.click(CpeClickClose);
    fireEvent.change(CpeClickClose, { target: { value: 'name' } });
  });
  test('handleChangeDeviceID to be rendered on screen', async () => {
    const testid = screen.getAllByRole('textbox')[0];
    fireEvent.change(testid, { target: { value: 'name' } });
  });

  test('Checkbox checked testing', async () => {
    const changeDeviceNameInput = await screen.findByTestId('HandleChangeDeviceName');
    expect(changeDeviceNameInput).toBeDefined();
    fireEvent.change(changeDeviceNameInput, { target: { value: 'iPhone' } });

    const modifiedText2 = await screen.findByText('iPhone 11');
    expect(modifiedText2).toBeDefined();

    const closeIcon = await screen.findByTestId('HandleChangeDeviceNameClose');
    expect(closeIcon).toBeInTheDocument();
    // fireEvent.click(closeIcon);
    fireEvent.keyDown(closeIcon, {
      key: 'Escape',
      code: 'Escape',
      keyCode: 27,
      charCode: 32,
    });

    fireEvent.change(changeDeviceNameInput, { target: { value: 'iPhone' } });

    const modifiedText3 = await screen.findByText('iPhone 11');
    expect(modifiedText3).toBeDefined();

    const closeIcon2 = await screen.findByTestId('HandleChangeDeviceNameClose');
    expect(closeIcon2).toBeInTheDocument();
    fireEvent.click(closeIcon2);

    fireEvent.change(changeDeviceNameInput, { target: { value: 'iPhone' } });

    const modifiedText = await screen.findByText('iPhone 11');
    expect(modifiedText).toBeDefined();

    const optionType = await screen.findByTestId('options-iPhone 11');
    expect(optionType).toBeDefined();
    fireEvent.mouseDown(optionType);

    const droDwn = await screen.findAllByRole('combobox');
    fireEvent.change(droDwn[0], { target: { value: 'TMOBILE' } });

    const continueBtn = await screen.findByTestId('CpeClickContinue');
    expect(continueBtn).toBeDefined();
    fireEvent.click(continueBtn);

    const closeBtn = await screen.findByTestId('CpeClickClose');
    expect(closeBtn).toBeDefined();
    fireEvent.click(closeBtn);
  });
});

describe('Validate sim component 1st onContinueClicked', () => {
  window.mfe = { isProspectNewCustomerTab: true , scmDeviceMfeEnable : true};
  beforeAll(() => {
    window.mfe = { scmUpgradeMfeEnable: true, scmDeviceMfeEnable : true };
    server.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });
  afterAll(() => {
    window.mfe = { scmUpgradeMfeEnable: false };
    server.close();
    sessionStorage.setItem('APIContext', '');
  });
  beforeEach(() => {
    window.vzdl = {};
    // Object.defineProperty(window, 'store', mockStore);
    window.store = mockStore;
    const location = {
      ...window.location,
      search: '?activeMtn=8482470044',
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost/?activeMtn=8482470044&isWSAPCpeError=${true}`;
    window.location.href = `http://localhost/combinedgridwall.html?fromAssignMtn=true&primaryMtn=${true}&activeMtn=${true}&imei2=null`;
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ isBYODCarrierLockFFlag: 'TRUE' }));
    const propsNew  = props;
     propsNew.cartDetails.cart = {
      lineDetails: {
        lineInfo: [],
      },
    };
    render(<Cpe {...propsNew} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('simple render test', async () => {

    const testid = await screen.findByText('Add customer-provided equipment');
    expect(testid).toBeInTheDocument();
  });

  test('checking  HandleChangeDeviceName function', () => {
    const result = screen.getByTestId('HandleChangeDeviceName');
    expect(result).toBeDefined();
    fireEvent.change(result, { target: { value: 'name' } });
    fireEvent.change(result, { target: { value: '' } });
  });

  test('Chcekbox click testing', async () => {
    const CheckBoxChange = await screen.findByRole('checkbox', { name: 'This device is customer-provider equipment' });
    fireEvent.change(CheckBoxChange, { target: { checked: true } });
  });

  test('CheckBoxChange button to be rendered on screen', () => {
    const CpeClick = screen.getByTestId('test-child-wrapper');
    fireEvent.click(CpeClick);
  });
  test('CheckBoxChange button to be rendered on screen', async () => {
    sessionStorage.setItem('secondImei', null);
    const input = await screen.findByTestId('handleChangeDeviceID');
    expect(input).toBeInTheDocument();
    fireEvent.change(input, { target: { value: '359433584231757' } });
    const CpeClickContinue = screen.getByTestId('CpeClickContinue');
    fireEvent.click(CpeClickContinue);
    fireEvent.change(CpeClickContinue, { target: { value: 'name' } });
  });

  test('CpeClickClose button to be rendered on screen', () => {
    const CpeClickClose = screen.getByTestId('CpeClickClose');
    fireEvent.click(CpeClickClose);
    fireEvent.change(CpeClickClose, { target: { value: 'name' } });
  });
  test('handleChangeDeviceID to be rendered on screen', async () => {
    const testid = screen.getAllByRole('textbox')[0];
    fireEvent.change(testid, { target: { value: 'name' } });
  });

});

describe('Validate sim component 1st with scmUpgradeEnable flag true', () => {
  window.mfe = { isProspectNewCustomerTab: true };
  beforeAll(() => {
    window.mfe = { scmUpgradeMfeEnable: true };
    server.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });
  afterAll(() => {
    window.mfe = { scmUpgradeMfeEnable: false };
    server.close();
    sessionStorage.setItem('APIContext', '');
  });
  beforeEach(() => {
    window.vzdl = {};
    // Object.defineProperty(window, 'store', mockStore);
    window.store = mockStore;
    const location = {
      ...window.location,
      search: '?activeMtn=8482470044',
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost/?activeMtn=8482470044&isWSAPCpeError=${true}`;
    window.location.href = `http://localhost/combinedgridwall.html?fromAssignMtn=true&SecondNumber=true&primaryMtn=${true}&activeMtn=${true}&imei2=125055454858`;
    sessionStorage.setItem('secondImei', '125055454858');
    render(<Cpe {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('simple render test', async () => {
    const testid = await screen.findByText('Add customer-provided equipment');
    expect(testid).toBeInTheDocument();
  });

  test('checking  HandleChangeDeviceName function', () => {
    const result = screen.getByTestId('HandleChangeDeviceName');
    expect(result).toBeDefined();
    fireEvent.change(result, { target: { value: 'name' } });
    fireEvent.change(result, { target: { value: '' } });
  });

  test('Chcekbox click testing', async () => {
    const CheckBoxChange = await screen.findByRole('checkbox', { name: 'This device is customer-provider equipment' });
    fireEvent.change(CheckBoxChange, { target: { checked: true } });
  });

  test('CheckBoxChange button to be rendered on screen', () => {
    const CpeClick = screen.getByTestId('test-child-wrapper');
    fireEvent.click(CpeClick);
  });
  test('CheckBoxChange button to be rendered on screen', () => {
    window.sessionStorage.setItem('secondImei', '350143163823135');
    window.sessionStorage.setItem('isSecondNumFlow', 'true');
    const CpeClickContinue = screen.getByTestId('CpeClickContinue');
    fireEvent.click(CpeClickContinue);
    fireEvent.change(CpeClickContinue, { target: { value: 'name' } });
  });

  test('CpeClickClose button to be rendered on screen', () => {
    const CpeClickClose = screen.getByTestId('CpeClickClose');
    fireEvent.click(CpeClickClose);
    fireEvent.change(CpeClickClose, { target: { value: 'name' } });
  });
  test('handleChangeDeviceID to be rendered on screen', () => {
    const testid = screen.getAllByRole('textbox')[0];
    fireEvent.change(testid, { target: { value: 'name' } });
  });
});

describe('ConfirmationDialogBox component', () => {
  window.mfe = { isProspectNewCustomerTab: false };
  beforeAll(() => {
    server1.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });
  afterAll(() => {
    server1.close();
    sessionStorage.setItem('APIContext', '');
  });
  beforeEach(() => {
    window.vzdl = {
      ...window.vzdl,
      event: {
        value: '',
      },
      page: {
        detail: '',
      },
    };
    // Object.defineProperty(window, 'store', mockStore);
    window.store = mockStore;
    const location = {
      ...window.location,
      search: '?activeMtn=8482470044',
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost/?activeMtn=8482470044&isWSAPCpeError=${true}`;
    window.location.href = `http://localhost/combinedgridwall.html?fromAssignMtn=true&SecondNumber=true&primaryMtn=${true}&activeMtn=${true}`;
    sessionStorage.setItem('secondImei', '125055454858');
    const propsNew = props;
    propsNew.ValidateDeviceSimIdResult = {
      data: data.validateDeviceSimId2,
      ...data.validateDeviceSimId2,
    };
    propsNew.eSimDetails = {
      data: data.eSimDetails,
      ...data.eSimDetails,
    };

    render(<Cpe {...propsNew} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('simple render test', async () => {
    const testid = await screen.findByText('Add customer-provided equipment');
    expect(testid).toBeInTheDocument();

    const yeBtn = await screen.findAllByRole('button', { name: 'Yes' });
    expect(yeBtn.length).toBeGreaterThan(0);
    fireEvent.click(yeBtn[0]);
    await new Promise((res) => {
      setTimeout(res, 1000);
    });
  });
  test('click on No button test', async () => {
    const noBtn = await screen.findAllByRole('button', { name: 'No' });
    expect(noBtn).toBeDefined();
    expect(noBtn.length).toBeGreaterThan(0);
    fireEvent.click(noBtn[0]);
  });
});

describe('ConfirmationDialogBox component', () => {
  window.mfe = { isProspectNewCustomerTab: true };
  beforeAll(() => {
    server1.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });
  afterAll(() => {
    server1.close();
    sessionStorage.setItem('APIContext', '');
  });
  beforeEach(() => {
    window.vzdl = {
      ...window.vzdl,
      event: {
        value: '',
      },
      page: {
        detail: '',
      },
    };
    // Object.defineProperty(window, 'store', mockStore);
    window.store = mockStore;
    const location = {
      ...window.location,
      search: '?activeMtn=8482470044',
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost/?activeMtn=8482470044&isWSAPCpeError=${true}`;
    window.location.href = `http://localhost/combinedgridwall.html?fromAssignMtn=true&SecondNumber=true&primaryMtn=${true}&activeMtn=${true}`;
    sessionStorage.setItem('secondImei', '125055454858');
    const propsNew = props1;
    render(<Cpe {...propsNew} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('ESim component render', () => {
    const Cancel = screen.getByText('Close');
    expect(Cancel).toBeInTheDocument();
    fireEvent.click(Cancel);
  });
});

describe('ConfirmationDialogBox component', () => {
  beforeAll(() => {
    server1.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });
  afterAll(() => {
    server1.close();
    sessionStorage.setItem('APIContext', '');
  });
  beforeEach(() => {
    window.vzdl = {
      ...window.vzdl,
      event: {
        value: '',
      },
      page: {
        detail: '',
      },
    };
    // Object.defineProperty(window, 'store', mockStore);
    window.store = mockStore;
    const location = {
      ...window.location,
      search: '?activeMtn=8482470044',
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost/?activeMtn=8482470044&isWSAPCpeError=${true}`;
    window.location.href = `http://localhost/combinedgridwall.html?fromAssignMtn=true&SecondNumber=true&primaryMtn=${true}&activeMtn=${true}`;
    sessionStorage.setItem('secondImei', '125055454858');
    const propsNew = offerComponentProps;
    render(<Cpe {...propsNew} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('Offer Message component render', async () => {
    const offerMessageId = await screen.findByTestId('offer-div');
    expect(offerMessageId).toBeInTheDocument();
  });
});

describe('Validate sim component 2nd', () => {
  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });
  afterAll(() => {
    server.close();
    sessionStorage.setItem('APIContext', '');
  });
  beforeEach(() => {
    window.vzdl = {
      ...window.vzdl,
      event: {
        value: '',
      },
      page: {
        detail: '',
      },
    };
    // Object.defineProperty(window, 'store', mockStore);
    window.store = mockStore;
    const location = {
      ...window.location,
      search: '?activeMtn=8482470044',
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost/?activeMtn=8482470044&isWSAPCpeError=${true}&isByodUpdate=${true}`;
    window.location.href = `http://localhost/combinedgridwall.html?fromAssignMtn=true&SecondNumber=true&primaryMtn=${true}&activeMtn=${true}`;
    sessionStorage.setItem('secondImei', '125055454858');
    render(<Cpe {...props2} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('simple render test', async () => {
    const testid = await screen.findByText('Add customer-provided equipment');
    expect(testid).toBeInTheDocument();
  });

  test('checking  HandleChangeDeviceName function', () => {
    const result = screen.getByTestId('HandleChangeDeviceName');
    expect(result).toBeDefined();
    fireEvent.change(result, { target: { value: 'name' } });
    fireEvent.change(result, { target: { value: '' } });
  });

  test('Chcekbox click testing', async () => {
    const CheckBoxChange = await screen.findByRole('checkbox', { name: 'This device is customer-provider equipment' });
    fireEvent.change(CheckBoxChange, { target: { checked: true } });
  });

  test('CheckBoxChange button to be rendered on screen', () => {
    const CpeClick = screen.getByTestId('test-child-wrapper');
    fireEvent.click(CpeClick);
  });
  test('CheckBoxChange button to be rendered on screen', () => {
    window.sessionStorage.setItem('secondImei', '350143163823135');
    const CpeClickContinue = screen.getByTestId('CpeClickContinue');
    fireEvent.click(CpeClickContinue);
    fireEvent.change(CpeClickContinue, { target: { value: 'name' } });
  });

  test('CpeClickClose button to be rendered on screen', () => {
    const CpeClickClose = screen.getByTestId('CpeClickClose');
    fireEvent.click(CpeClickClose);
    fireEvent.change(CpeClickClose, { target: { value: 'name' } });
  });
  test('handleChangeDeviceID to be rendered on screen', () => {
    const testid = screen.getAllByRole('textbox')[0];
    fireEvent.change(testid, { target: { value: 'name' } });
  });

  test('Checkbox checked testing', async () => {
    const changeDeviceNameInput = await screen.findByTestId('HandleChangeDeviceName');
    expect(changeDeviceNameInput).toBeDefined();
    fireEvent.change(changeDeviceNameInput, { target: { value: 'name' } });
  });
});
describe('Validate sim component 2nd', () => {
  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });
  afterAll(() => {
    server.close();
    sessionStorage.setItem('APIContext', '');
  });
  beforeEach(() => {
    window.vzdl = {
      ...window.vzdl,
      event: {
        value: '',
      },
      page: {
        detail: '',
      },
    };
    // Object.defineProperty(window, 'store', mockStore);
    window.store = mockStore;
    const location = {
      ...window.location,
      search: '?activeMtn=8482470044',
    };

    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost/?activeMtn=8482470044&isWSAPCpeError=${true}&isByodUpdate=${true}`;
    window.location.href = `http://localhost/combinedgridwall.html?fromAssignMtn=true&SecondNumber=true&primaryMtn=${true}&activeMtn=${true}`;
    sessionStorage.setItem('secondImei', '125055454858');
    render(<Cpe {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('selectedDeviceFFlag is true', () => {
    sessionStorage.setItem('APP_PROPERTIES', '{"selectedDeviceFFlag": "TRUE"}');
  });
});

describe('Validate sim component 3rd', () => {
  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });
  afterAll(() => {
    server.close();
    sessionStorage.setItem('APIContext', '');
  });
  beforeEach(() => {
    window.vzdl = {
      ...window.vzdl,
      event: {
        value: '',
      },
      page: {
        detail: '',
      },
    };
    // Object.defineProperty(window, 'store', mockStore);
    window.store = mockStore;
    const location = {
      ...window.location,
      search: '?activeMtn=8482470044',
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost/?activeMtn=8482470044&isWSAPCpeError=${true}&isByodUpdate=${true}`;
    window.location.href = `http://localhost/combinedgridwall.html?fromAssignMtn=true&SecondNumber=true&primaryMtn=${true}&activeMtn=${true}`;
    sessionStorage.setItem('secondImei', '125055454858');
    render(<Cpe {...props3} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('simple render test', async () => {
    const testid = await screen.findByText('Add customer-provided equipment');
    expect(testid).toBeInTheDocument();
  });

  test('checking  HandleChangeDeviceName function', () => {
    const result = screen.getByTestId('HandleChangeDeviceName');
    expect(result).toBeDefined();
    fireEvent.change(result, { target: { value: 'name' } });
    fireEvent.change(result, { target: { value: '' } });
  });

  test('Chcekbox click testing', async () => {
    const CheckBoxChange = await screen.findByRole('checkbox', { name: 'This device is customer-provider equipment' });
    fireEvent.change(CheckBoxChange, { target: { checked: true } });
  });

  test('CheckBoxChange button to be rendered on screen', () => {
    const CpeClick = screen.getByTestId('test-child-wrapper');
    fireEvent.click(CpeClick);
  });
  test('CheckBoxChange button to be rendered on screen', () => {
    window.sessionStorage.setItem('secondImei', '350143163823135');
    const CpeClickContinue = screen.getByTestId('CpeClickContinue');
    fireEvent.click(CpeClickContinue);
    fireEvent.change(CpeClickContinue, { target: { value: 'name' } });
  });

  test('CpeClickClose button to be rendered on screen', () => {
    const CpeClickClose = screen.getByTestId('CpeClickClose');
    fireEvent.click(CpeClickClose);
    fireEvent.change(CpeClickClose, { target: { value: 'name' } });
  });
  test('handleChangeDeviceID to be rendered on screen', () => {
    const testid = screen.getAllByRole('textbox')[0];
    fireEvent.change(testid, { target: { value: 'name' } });
  });

  test('Checkbox checked testing', async () => {
    const changeDeviceNameInput = await screen.findByTestId('HandleChangeDeviceName');
    expect(changeDeviceNameInput).toBeDefined();
    fireEvent.change(changeDeviceNameInput, { target: { value: 'name' } });
  });
});

describe('Validate sim component 4th', () => {
  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });
  afterAll(() => {
    server.close();
    sessionStorage.setItem('APIContext', '');
  });
  beforeEach(() => {
    window.vzdl = {};
    // Object.defineProperty(window, 'store', mockStore);
    window.store = mockStore;
    const location = {
      ...window.location,
      search: '?activeMtn=8482470044',
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost/?activeMtn=8482470044&isWSAPCpeError=${true}&isByodUpdate=${true}`;
    window.location.href = `http://localhost/combinedgridwall.html?fromAssignMtn=true&SecondNumber=true&primaryMtn=${true}&activeMtn=${true}`;
    sessionStorage.setItem('secondImei', '125055454858');
    render(<Cpe {...props4} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('simple render test', async () => {
    const testid = await screen.findByText('Add customer-provided equipment');
    expect(testid).toBeInTheDocument();
  });

  test('checking  HandleChangeDeviceName function', () => {
    const result = screen.getByTestId('HandleChangeDeviceName');
    expect(result).toBeDefined();
    fireEvent.change(result, { target: { value: 'name' } });
    fireEvent.change(result, { target: { value: '' } });
  });

  test('Chcekbox click testing', async () => {
    const CheckBoxChange = await screen.findByRole('checkbox', { name: 'This device is customer-provider equipment' });
    fireEvent.change(CheckBoxChange, { target: { checked: true } });
  });

  test('CheckBoxChange button to be rendered on screen', () => {
    const CpeClick = screen.getByTestId('test-child-wrapper');
    fireEvent.click(CpeClick);
  });
  test('CheckBoxChange button to be rendered on screen', () => {
    window.sessionStorage.setItem('secondImei', '350143163823135');
    const CpeClickContinue = screen.getByTestId('CpeClickContinue');
    fireEvent.click(CpeClickContinue);
    fireEvent.change(CpeClickContinue, { target: { value: 'name' } });
  });

  test('CpeClickClose button to be rendered on screen', () => {
    const CpeClickClose = screen.getByTestId('CpeClickClose');
    fireEvent.click(CpeClickClose);
    fireEvent.change(CpeClickClose, { target: { value: 'name' } });
  });
  test('handleChangeDeviceID to be rendered on screen', () => {
    const testid = screen.getAllByRole('textbox')[0];
    fireEvent.change(testid, { target: { value: 'name' } });
  });

  test('Checkbox checked testing', async () => {
    const changeDeviceNameInput = await screen.findByTestId('HandleChangeDeviceName');
    expect(changeDeviceNameInput).toBeDefined();
    fireEvent.change(changeDeviceNameInput, { target: { value: 'name' } });
  });
});

describe('Validate sim component 5th', () => {
  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });
  afterAll(() => {
    server.close();
    sessionStorage.setItem('APIContext', '');
    window.mfe = {scmUpgradeMfeEnable:false,scmCombinedGridwallFlow:false, historyRef: { push: jest.fn()}}
  });
  beforeEach(() => {
    window.mfe = {scmUpgradeMfeEnable:true,scmCombinedGridwallFlow:true, historyRef: { push: jest.fn()}}
    window.vzdl = {};
    // Object.defineProperty(window, 'store', mockStore);
    window.store = mockStore;
    const location = {
      ...window.location,
      search: '?activeMtn=8482470044',
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost/combinedgridwall.html?fromAssignMtn=true&SecondNumber=true&primaryMtn=${true}&activeMtn=${true}&isByodUpdate=${true}`;
    sessionStorage.setItem('secondImei', '125055454858');
    render(<Cpe {...props4} prospectByodFlow={false} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('Checkbox checked testing', async () => {
    const changeDeviceNameInput = await screen.findByTestId('HandleChangeDeviceName');
    expect(changeDeviceNameInput).toBeDefined();
    fireEvent.change(changeDeviceNameInput, { target: { value: 'name' } });
  });
  test('Checkbox checked testing', async () => {
    const changeDeviceNameInput = await screen.findByTestId('HandleChangeDeviceName');
    expect(changeDeviceNameInput).toBeDefined();
    fireEvent.change(changeDeviceNameInput, { target: { value: 'name' } });
  });
});

describe('Validate sim component 6th', () => {
  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });
  afterAll(() => {
    server.close();
    sessionStorage.setItem('APIContext', '');
    window.mfe = {scmUpgradeMfeEnable:false,scmCombinedGridwallFlow:false, historyRef: { push: jest.fn()}}
  });
  beforeEach(() => {
    window.vzdl = {};
    // Object.defineProperty(window, 'store', mockStore);
    window.store = mockStore;
    const location = {
      ...window.location,
      search: '?activeMtn=8482470044',
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost/combinedgridwall.html?fromAssignMtn=true&SecondNumber=true&primaryMtn=${true}&activeMtn=${true}`;
    sessionStorage.setItem('secondImei', '125055454858');
    window.mfe = {scmUpgradeMfeEnable:true,scmCombinedGridwallFlow:true, historyRef: { push: jest.fn()}}
    render(<Cpe {...props4} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
  test('Checkbox checked testing with scmUpgradeMfeEnable', async () => {
    const changeDeviceNameInput = await screen.findByTestId('HandleChangeDeviceName');
    expect(changeDeviceNameInput).toBeDefined();
    fireEvent.change(changeDeviceNameInput, { target: { value: 'name' } });
  });
});

describe('Validate sim component with newLine1', () => {
  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });
  afterAll(() => {
    server.close();
    sessionStorage.setItem('APIContext', '');
  });
  beforeEach(() => {
    window.vzdl = {
      ...window.vzdl,
      target: {
        message: '',
      },
      event: {
        value: '',
      },
      page: {
        detail: '',
      },
    };
    // Object.defineProperty(window, 'store', mockStore);
    window.store = mockStore;
    const location = {
      ...window.location,
      search: '?activeMtn=newLine1',
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost/?activeMtn=newLine1&isWSAPCpeError=${true}`;
    window.location.href = `http://localhost/combinedgridwall.html?fromAssignMtn=true&SecondNumber=true&primaryMtn=${true}&activeMtn=${true}`;
    sessionStorage.setItem('secondImei', '125055454858');
    render(<Cpe {...props5} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('simple render test', async () => {
    const testid = await screen.findByText('Add customer-provided equipment');
    expect(testid).toBeInTheDocument();
    const temp = await screen.getByText('Assign Number');
    expect(temp).toBeInTheDocument();
    fireEvent.click(temp);
  });
});

describe('Validate sim component 6th', () => {
  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });
  afterAll(() => {
    server.close();
    sessionStorage.setItem('APIContext', '');
  });
  beforeEach(() => {
    window.store = mockStore;
    const location = {
      ...window.location,
      search: '?activeMtn=8482470044',
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost/?activeMtn=8482470044&isWSAPCpeError=${true}&isByodUpdate=${true}`;
    window.location.href = `http://localhost/combinedgridwall.html?fromAssignMtn=true&SecondNumber=true&primaryMtn=${true}&activeMtn=${true}`;
    sessionStorage.setItem('secondImei', '125055454858');
  });

  test('simple render test - SecNumFlow true', async () => {
    render(<Cpe {...props6} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    const testid = await screen.findByText('Add customer-provided equipment');
    expect(testid).toBeInTheDocument();
  });

  test('simple render test - SecNumFlow false', async () => {
    const propsSecNum = { ...props6, SecNumFlow: false };
    render(<Cpe {...propsSecNum} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });

    const testid = await screen.findByText('Add customer-provided equipment');
    expect(testid).toBeInTheDocument();
  });
});

describe('Validate sim component 1st', () => {
  beforeAll(() => {
    server.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });
  afterAll(() => {
    server.close();
    sessionStorage.setItem('APIContext', '');
  });
  beforeEach(() => {
    window.vzdl = {
      ...window.vzdl,
      event: {
        value: 'event24',
      },
    };
    // Object.defineProperty(window, 'store', mockStore);
    window.store = mockStore;
    const location = {
      ...window.location,
      search: '?activeMtn=8482470044',
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost/?activeMtn=8482470044&isWSAPCpeError=${true}`;
    window.location.href = `http://localhost/combinedgridwall.html?fromAssignMtn=true&SecondNumber=true&primaryMtn=${true}&activeMtn=${true}&imei2=true&imei2=${true}`;

    render(<Cpe {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('simple render test', async () => {
    const testid = await screen.findByText('Add customer-provided equipment');
    expect(testid).toBeInTheDocument();
  });

  test('checking  HandleChangeDeviceName function', () => {
    const result = screen.getByTestId('HandleChangeDeviceName');
    expect(result).toBeDefined();
    fireEvent.change(result, { target: { value: 'name' } });
    fireEvent.change(result, { target: { value: '' } });
  });

  test('Chcekbox click testing', async () => {
    const CheckBoxChange = await screen.findByRole('checkbox', { name: 'This device is customer-provider equipment' });
    fireEvent.change(CheckBoxChange, { target: { checked: true } });
  });

  test('CheckBoxChange button to be rendered on screen', () => {
    const CpeClick = screen.getByTestId('test-child-wrapper');
    fireEvent.click(CpeClick);
  });
  test('CheckBoxChange button to be rendered on screen', () => {
    window.sessionStorage.setItem('secondImei', '350143163823135');
    const CpeClickContinue = screen.getByTestId('CpeClickContinue');
    fireEvent.click(CpeClickContinue);
    fireEvent.change(CpeClickContinue, { target: { value: 'name' } });
  });

  test('CpeClickClose button to be rendered on screen', () => {
    const CpeClickClose = screen.getByTestId('CpeClickClose');
    fireEvent.click(CpeClickClose);
    fireEvent.change(CpeClickClose, { target: { value: 'name' } });
  });
  test('handleChangeDeviceID to be rendered on screen', () => {
    const testid = screen.getAllByRole('textbox')[0];
    fireEvent.change(testid, { target: { value: 'name' } });
  });
});

describe('ConfirmationDialogBox component', () => {
  beforeAll(() => {
    server1.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });
  afterAll(() => {
    server1.close();
    sessionStorage.setItem('APIContext', '');
  });
  beforeEach(() => {
    // Object.defineProperty(window, 'store', mockStore);
    window.store = mockStore;
    const location = {
      ...window.location,
      search: '?activeMtn=8482470044',
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost/?activeMtn=8482470044&isWSAPCpeError=${true}`;
    window.location.href = `http://localhost/combinedgridwall.html?fromAssignMtn=true&primaryMtn=${true}&activeMtn=${true}&imei2=${true}`;

    const propsNew = props;
    propsNew.ValidateDeviceSimIdResult = {
      data: data.validateDeviceSimId2,
      ...data.validateDeviceSimId2,
    };
    propsNew.eSimDetails = {
      data: data.eSimDetails,
      ...data.eSimDetails,
    };
    render(<Cpe {...propsNew} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('simple render test', async () => {
    window.sessionStorage.removeItem('isSecondNumFlow');
    const testid = await screen.findByText('Add customer-provided equipment');
    expect(testid).toBeInTheDocument();

    const yeBtn = await screen.findAllByRole('button', { name: 'Yes' });
    expect(yeBtn.length).toBeGreaterThan(0);
    fireEvent.click(yeBtn[0]);
    await new Promise((res) => {
      setTimeout(res, 1000);
    });
  });
  test('click on No button test', async () => {
    const noBtn = await screen.findAllByRole('button', { name: 'No' });
    expect(noBtn.length).toBeGreaterThan(0);
    fireEvent.click(noBtn[0]);
  });

  // test for changing device id
  test('change device id test', async () => {
    const input = await screen.findByTestId('handleChangeDeviceID');
    expect(input).toBeInTheDocument();
    fireEvent.change(input, { target: { value: '359433584231757' } });
    expect(input.value).toBe('359433584231757');
  });
});

describe('Samsung Carrier Lock - ConfirmationDialogBox component - carrierLock false', () => {
  beforeAll(() => {
    server1.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });
  afterAll(() => {
    server1.close();
    sessionStorage.setItem('APIContext', '');
  });
  beforeEach(() => {
    // Object.defineProperty(window, 'store', mockStore);
    window.store = mockStore;
    const location = {
      ...window.location,
      search: '?activeMtn=8482470044',
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost/?activeMtn=8482470044&isWSAPCpeError=${true}`;
    window.location.href = `http://localhost/combinedgridwall.html?fromAssignMtn=true&primaryMtn=${true}&activeMtn=${true}&imei2=${true}`;

    const propsNew = props;
    propsNew.popUp = false;
    propsNew.ValidateDeviceSimIdResult = {
      data: data.validateDeviceSimId2,
      ...data.validateDeviceSimId2,
    };
    propsNew.eSimDetails = {
      data: data.eSimDetails,
      ...data.eSimDetails,
    };
    render(<Cpe {...propsNew} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('simple render test', async () => {
    window.sessionStorage.removeItem('isSecondNumFlow');
    const testid = await screen.findByText('Add customer-provided equipment');
    expect(testid).toBeInTheDocument();
  });
});

describe('Samsung Carrier Lock - ConfirmationDialogBox component', () => {
  beforeAll(() => {
    server1.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });
  afterAll(() => {
    server1.close();
    sessionStorage.setItem('APIContext', '');
  });
  beforeEach(() => {
    // Object.defineProperty(window, 'store', mockStore);
    window.store = mockStore;
    window.mfe = { scmUpgradeMfeEnable: true };
    const location = {
      ...window.location,
      search: '?activeMtn=8482470044',
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost/?activeMtn=8482470044&isWSAPCpeError=${true}`;
    window.location.href = `http://localhost/combinedgridwall.html?fromAssignMtn=true&primaryMtn=${true}&activeMtn=${true}&imei2=${true}`;

    const propsNew = props;
    propsNew.popUp = true;
    propsNew.ValidateDeviceSimIdResult = {
      data: data.validateDeviceSimId4,
      ...data.validateDeviceSimId4,
    };
    propsNew.eSimDetails = {
      data: data.eSimDetails,
      ...data.eSimDetails,
    };
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ samsungPOSFFlag: 'TRUE' }));
    render(<Cpe {...propsNew} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  // test for changing device id
  test('change device id test', async () => {
    const input = await screen.findByTestId('handleChangeDeviceID');
    expect(input).toBeInTheDocument();
    fireEvent.change(input, { target: { value: '359433584231757' } });
    expect(input.value).toBe('359433584231757');
  });
});

describe('getImei2FromMtnDetails', () => {
  beforeAll(() => {
    server1.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });
  afterAll(() => {
    server1.close();
    sessionStorage.setItem('APIContext', '');
  });
  beforeEach(() => {
    // Object.defineProperty(window, 'store', mockStore);
    window.store = mockStore;
    const location = {
      ...window.location,
      search: '?activeMtn=8482470044',
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost/?activeMtn=8482470044&isWSAPCpeError=${true}`;
    window.location.href = `http://localhost/combinedgridwall.html?fromAssignMtn=true&primaryMtn=${true}&activeMtn=${true}&imei2=${true}`;

    const propsNew = props;
    propsNew.popUp = true;
    propsNew.cartDetails.cart = {
      lineDetails: {
        lineInfo: [
          {
            lineActivityType: 'AAL',
            mtnDetails: { lineNumber: 'newLine1' },
            itemsInfo: [
              {
                cartItems: {
                  cartItem: [{ imei2: '1212122121' }],
                },
              },
            ],
          },
        ],
      },
    };
    propsNew.ValidateDeviceSimIdResult = {
      data: data.validateDeviceSimId4,
      ...data.validateDeviceSimId4,
    };
    propsNew.eSimDetails = {
      data: data.eSimDetails,
      ...data.eSimDetails,
    };
    propsNew.primaryMtnofSecondNumber = 'newLine1';
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ samsungPOSFFlag: 'TRUE' }));
    render(<Cpe {...propsNew} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  // test for changing device id
  test('snPerkInPSFlowFFlag TRUE', async () => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ snPerkInPSFlowFFlag: 'TRUE' }));
    const input = await screen.findByTestId('handleChangeDeviceID');
    expect(input).toBeInTheDocument();
    fireEvent.change(input, { target: { value: '359433584231757' } });
    expect(input.value).toBe('359433584231757');
  });
  test('snPerkInPSFlowFFlag FALSE', async () => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ snPerkInPSFlowFFlag: 'FALSE' }));
    const input = await screen.findByTestId('handleChangeDeviceID');
    expect(input).toBeInTheDocument();
    fireEvent.change(input, { target: { value: '359433584231757' } });
    expect(input.value).toBe('359433584231757');
  });
});

describe('getImei2FromMtnDetails', () => {
  beforeAll(() => {
    server1.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
  });
  afterAll(() => {
    server1.close();
    sessionStorage.setItem('APIContext', '');
  });
  beforeEach(() => {
    // Object.defineProperty(window, 'store', mockStore);
    jest.spyOn(APIServiceHooks, 'useLazyESimDetailsQuery').mockReturnValue([
      jest.fn(),
      {
        status: 'fulfilled',
        data: {
          data: {
            caseId: 'CCD-13031324-C01',
            customerInfo: {
              applicationStatus: 'Application-Initiated',
              mtn: '4232626151',
              accountNumber: '0413704717-00001',
              applicationId: 'U5U5UDT2TQUNTQM4M',
            },
          },
        },
      },
    ]);
    window.store = mockStore;
    const location = {
      ...window.location,
      search: '?activeMtn=8482470044',
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost/?activeMtn=8482470044&isWSAPCpeError=${true}`;
    window.location.href = `http://localhost/combinedgridwall.html?fromAssignMtn=true&primaryMtn=${true}&activeMtn=${true}&imei2=${true}`;

    const propsNew = props;
    propsNew.popUp = true;
    propsNew.cartDetails.cart = {
      lineDetails: {
        lineInfo: [
          {
            lineActivityType: 'AAL',
            mtnDetails: { lineNumber: 'newLine1' },
            itemsInfo: [
              {
                cartItems: {
                  cartItem: [],
                },
              },
            ],
          },
        ],
      },
    };
    propsNew.ValidateDeviceSimIdResult = {
      data: data.validateDeviceSimId4,
      ...data.validateDeviceSimId4,
    };
    propsNew.eSimDetails = {
      data: data.eSimDetails,
      ...data.eSimDetails,
    };
    propsNew.primaryMtnofSecondNumber = 'newLine1';
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ samsungPOSFFlag: 'TRUE' }));
    render(<Cpe {...propsNew} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  // test for changing device id
  test('snPerkInPSFlowFFlag TRUE', async () => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ snPerkInPSFlowFFlag: 'TRUE' }));
    const input = await screen.findByTestId('handleChangeDeviceID');
    expect(input).toBeInTheDocument();
    fireEvent.change(input, { target: { value: '359433584231757' } });
    expect(input.value).toBe('359433584231757');
  });
  test('snPerkInPSFlowFFlag FALSE', async () => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ snPerkInPSFlowFFlag: 'FALSE' }));
    const input = await screen.findByTestId('handleChangeDeviceID');
    expect(input).toBeInTheDocument();
    fireEvent.change(input, { target: { value: '359433584231757' } });
    expect(input.value).toBe('359433584231757');
  });
});
