import React, { useState } from 'react';
import { Modal, ModalBody, ModalTitle, ModalFooter } from '@vds/modals';
import PropTypes from 'prop-types';
import { carrierModalText, carrierModalSubText, carrierModalAcknowledgementext } from '../../constants/DeviceConstants';
import { PaddingTop24 } from '../../CombinedGridwall/FlexGlobalStyledConstants';

function CarrierLockModal(props) {
  const { setShowCarrierLockPopup, showCarrierLockPopup } = props;
  const [isNoClicked, setIsNoClicked] = useState(false);
  const carrierModalTitle = isNoClicked ? 'BYOD is Carrier Locked' : 'Contact Previous Carrier of Locked Device';
  return (
    <Modal
      surface='light'
      opened={showCarrierLockPopup}
      fullScreenDialog={false}
      disableAnimation={false}
      disableOutsideClick
      hideCloseButton
      closeButton={null}
      ariaLabel='carrierLockModal'
    >
      <ModalTitle>{carrierModalTitle}</ModalTitle>
      <ModalBody>
        {isNoClicked ? carrierModalAcknowledgementext : carrierModalText}
        {!isNoClicked && (
          <PaddingTop24>
            {carrierModalSubText}
          </PaddingTop24>
        )}
      </ModalBody>
      <ModalFooter
        buttonData={{
          primary: {
            width: '100%',
            children: isNoClicked ? 'Acknowledge' : 'No',
            onClick: () => (isNoClicked ? setShowCarrierLockPopup(false) : setIsNoClicked(true)),
          },
          ...(!isNoClicked && {
            close: {
              width: '100%',
              children: 'Yes',
              onClick: () => setShowCarrierLockPopup(false),
            },
          }),
        }}
      />
    </Modal>
  );
}

CarrierLockModal.propTypes = {
  setShowCarrierLockPopup: PropTypes.func,
  showCarrierLockPopup: PropTypes.bool,
};

export default CarrierLockModal;
