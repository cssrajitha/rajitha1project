import React from 'react';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import rootReducer from '../../../modules/store/reducer';
import { rootSaga } from '../../../modules/store/saga';
import { render, screen, fireEvent } from '../../../modules/test-utils/renderHelper';
import Cpe from './Cpe';
import customerProfile from '../../../pages/PDP/mocks/api/customerProfile.json';
import data from '../__mocks__/mockCombinedGridwallData.json';

jest.setTimeout(30000);
const handlers = [
  rest.post(`*/cart/smartimei-typeahead`, (req, res, ctx) => {
    console.log('inside /cart/smartimei-typeahead');
    return res(ctx.status(200), ctx.json(data.smartimeiTypeahead));
  }),
  rest.post(`*/cart/validate-deviceSimId`, (req, res, ctx) => {
    console.log('inside /cart/validate-deviceSimId');
    return res(ctx.status(200), ctx.json(data.validateDeviceSimId));
  }),
  rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
    console.log('inside /cart/eSimDetails');
    return res(ctx.status(200), ctx.json(data.eSimDetails));
  }),
];

const handlers1 = [
  rest.post(`*/cart/smartimei-typeahead`, (req, res, ctx) => {
    console.log('inside /cart/smartimei-typeahead');
    return res(ctx.status(200), ctx.json(data.smartimeiTypeahead));
  }),
  rest.post(`*/cart/validate-deviceSimId`, (req, res, ctx) => {
    console.log('inside /cart/validate-deviceSimId');
    return res(ctx.status(200), ctx.json(data.validateDeviceSimId2));
  }),
  rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
    console.log('inside /cart/eSimDetails');
    return res(ctx.status(200), ctx.json(data.eSimDetails));
  }),
];

const customerProfData = customerProfile.data.customer;
customerProfData.homeSalesAddress = {
  bundles: {
    bundleName: '5GHomeSelfInstall',
  },
};
const props = {
  activeMtn: '8482470044',
  prospectByodFlow: true,
  updateSetUpPopUp: jest.fn(),
  setIsCloseByod: jest.fn(),
  popUp: true,
  ValidateDeviceSimIdResultStatus: 'fulfilled',
  devicePayload: {},
  ValidateDeviceSimIdResult: {
    data: data.validateDeviceSimId,
    ...data.validateDeviceSimId,
  },
  assistedFlag: {
    disableEsimAtLocalInventory: 'FALSE',
  },
  selectedLine: [
    {
      deviceTypeSelected: '5G Internet',
      equipmentInfos: [
        {
          deviceInfo: {
            deviceId: '354245334007682',
          },
        },
      ],
    },
  ],
  lineActivityType: 'VSO',
  totalLines: [
    {
      mobileNumber: '8482470044',
      equipmentInfos: [
        {
          simInfo: {
            simId: '123456',
          },
          deviceInfo: {
            deviceId: '354245334007682',
          },
        },
      ],
      itemsInfo: [
        {
          cartItems: {
            cartItem: [{ cartItemType: 'DEVICE', deviceId: '354245334007682', eDeviceId: '354245334007682' }],
          },
        },
      ],
    },
  ],
  appPropertiesFromSessionStorage: {
    isLandingRedesignFlow: true,
    handleChangeDeviceIDs: jest.fn(),
  },
  CustomerData: customerProfData,
  commonInfo: customerProfile.data.commonInfo,
  cartDetails: {
    cartHeader: {},
    orderDetails: {},
    cart: {
      lineDetails: { lineInfo: [{ itemsInfo: [{ cartItems: { cartItem: [{ imei2: '1212122121' }] } }] }] },
      orderDetails: { isPrePayCart: 'Y' },
    },
  },
  handleByodflag: jest.fn(),
  offers: {
    lines: [
      {
        mtn: '8482470044',
        offers: [
          {
            complianceType: 'EQP',
            sku: '594981',
            description: '$540 over 36 mos BYOD BIC on Unlimited Ultimate PP',
            compatibleIndicator: 'N',
            propId: '2841',
            aal: 'Y',
            offerCompliance: 'N',
            propositionMessage: 'BYOD BIC $540 over 36 months on Unlimited Ultimate Bic No',
            buyGetInd: 'G',
            offerSubType: 'BYOD',
          },
        ],
        deviceCategory: 'smartphone',
      },
    ],
  },
  validateDeviceSimIdRequest: jest.fn(),
  lineHasOffer: true,
  nationalCheck: true,
  deviceCategory: 'smartwatch',
};

const server = setupServer(...handlers);
const server1 = setupServer(...handlers1);

const dispatchedActions = [];
const mockStore = {
  dispatch: (action) => {
    dispatchedActions.push(action);
  },
};

describe('ConfirmationDialogBox component', () => {
  beforeAll(() => {
    server1.listen();
    sessionStorage.setItem('APIContext', 'http://localhost:3002/api');
    sessionStorage?.setItem('isACSSFlexRedesign', true);
  });
  afterAll(() => {
    server1.close();
    sessionStorage.setItem('APIContext', '');
  });
  beforeEach(() => {
    sessionStorage?.setItem('isACSSFlexRedesign', true);
    window.vzdl = {
      ...window.vzdl,
      event: {
        value: '',
      },
      page: {
        detail: '',
      },
    };
    // Object.defineProperty(window, 'store', mockStore);
    window.store = mockStore;
    const location = {
      ...window.location,
      search: '?activeMtn=8482470044',
    };
    Object.defineProperty(window, 'location', {
      writable: true,
      value: location,
    });
    window.location.href = `http://localhost/?activeMtn=8482470044&isWSAPCpeError=${true}`;
    window.location.href = `http://localhost/combinedgridwall.html?fromAssignMtn=true&SecondNumber=true&primaryMtn=${true}&activeMtn=${true}`;
    sessionStorage.setItem('secondImei', '125055454858');
    const propsNew = props;
    propsNew.ValidateDeviceSimIdResult = {
      data: data.validateDeviceSimId2,
      ...data.validateDeviceSimId2,
    };
    propsNew.eSimDetails = {
      data: data.eSimDetails,
      ...data.eSimDetails,
    };
    render(<Cpe {...propsNew} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });

  test('simple render test', async () => {
    server.use(
      rest.post(`*/cart/eSimDetails`, (req, res, ctx) => {
        console.log('inside /cart/eSimDetails');
        return res(ctx.status(200), ctx.json(data.eSimDetails));
      }),
    );
    const testid = await screen.findByText('Add customer-provided equipment');
    expect(testid).toBeInTheDocument();

    const yeBtn = await screen.findByRole('button', { name: 'Yes' });
    expect(yeBtn).toBeInTheDocument();
    fireEvent.click(yeBtn);
    await new Promise((res) => {
      setTimeout(res, 20000);
    });
  });
  test('click on No button test', async () => {
    const noBtn = await screen.findByRole('button', { name: 'No' });
    expect(noBtn).toBeInTheDocument();
    fireEvent.click(noBtn);
  });
});
